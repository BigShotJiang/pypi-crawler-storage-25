from __future__ import annotations

import asyncio
import contextvars
import functools
import traceback
from datetime import datetime, timezone

from .database import _SessionLocal
from .models import TriggerType, Workflow, WorkflowRun, WorkflowStatus
from .trigger_context import TriggerContext

# Holds the mutable node-collection context for the currently-executing workflow.
# Shape: {"nodes": list[dict], "plan": list[str], "logs": list[dict]}  — None when not inside a workflow.
_active_run_ctx: contextvars.ContextVar[dict | None] = contextvars.ContextVar(
    "_active_run_ctx", default=None
)

# Holds the log-line buffer for the currently-executing node — None outside a node.
_active_node_logs: contextvars.ContextVar[list | None] = contextvars.ContextVar(
    "_active_node_logs", default=None
)

# ---------------------------------------------------------------------------
# Per-workflow pending-run drain queue
# ---------------------------------------------------------------------------
# When max_concurrent_runs is hit, triggers are saved as pending WorkflowRun
# rows. A drain loop task per workflow wakes up after each run completes and
# executes the next pending run in FIFO order.

_drain_tasks: dict[str, asyncio.Task] = {}
_drain_events: dict[str, asyncio.Event] = {}

# Maps run_id -> the asyncio Task currently executing that run's user function.
# Used by the cancel endpoint to interrupt in-flight executions.
_running_tasks: dict[int, asyncio.Task] = {}


def _get_drain_event(name: str) -> asyncio.Event:
    if name not in _drain_events:
        _drain_events[name] = asyncio.Event()
    return _drain_events[name]


def _notify_drain(name: str) -> None:
    """Signal the drain loop for *name* that a slot may have opened."""
    event = _drain_events.get(name)
    if event is not None:
        event.set()


def _ensure_drain_task(name: str, fn) -> None:
    """Idempotently start a drain loop task for *name* if one is not running."""
    task = _drain_tasks.get(name)
    if task is None or task.done():
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        _drain_tasks[name] = loop.create_task(
            _drain_loop(name, fn), name=f"gtm_drain_{name}"
        )


async def _drain_loop(name: str, fn) -> None:
    """Drain pending runs for *name*, respecting the concurrency limit.

    On each wake-up, computes how many slots are currently free and fires off
    that many _execute_existing_run tasks in parallel. This ensures a limit
    increase (e.g. 1 → 10) immediately fills all newly-available slots rather
    than trickling through one run at a time.
    """
    from sqlalchemy import func as _func
    from sqlmodel import select

    event = _get_drain_event(name)
    while True:
        await event.wait()
        event.clear()
        if _SessionLocal is None:
            continue
        async with _SessionLocal() as session:
            cfg = (await session.exec(
                select(Workflow).where(Workflow.name == name)
            )).first()

            if cfg is None:
                continue

            # Determine how many pending runs we can start right now.
            if cfg.max_concurrent_runs is not None and cfg.max_concurrent_runs > 0:
                running_count: int = (await session.execute(
                    select(_func.count(WorkflowRun.id)).where(
                        WorkflowRun.workflow_id == cfg.id,
                        WorkflowRun.status == WorkflowStatus.running,
                        WorkflowRun.parent_id == None,  # noqa: E711
                    )
                )).scalar_one()
                free_slots = max(0, cfg.max_concurrent_runs - running_count)
            else:
                # No concurrency limit — start everything that's waiting.
                free_slots = None

            if free_slots == 0:
                continue

            q = (
                select(WorkflowRun)
                .join(Workflow, WorkflowRun.workflow_id == Workflow.id)
                .where(
                    Workflow.name == name,
                    WorkflowRun.status == WorkflowStatus.pending,
                )
                .order_by(WorkflowRun.created_at)
            )
            if free_slots is not None:
                q = q.limit(free_slots)

            pending_list = list((await session.exec(q)).all())

        if not pending_list:
            continue

        # Fire all eligible runs as independent tasks so they execute in parallel.
        # Each task calls _notify_drain when it finishes, keeping the loop going.
        for run in pending_list:
            asyncio.create_task(
                _execute_existing_run(fn, run.id, name),
                name=f"gtm_run_{name}_{run.id}",
            )


async def _execute_existing_run(fn, run_id: int, workflow_name: str) -> None:
    """Transition a pending run to running, execute *fn*, and persist the result.

    Called by the drain loop. Mirrors the execution logic in make_workflow_wrapper
    but reuses an existing WorkflowRun row rather than creating a new one.
    Calls _notify_drain when done so the drain loop picks up the next pending run.
    """
    from .broadcast import manager
    from sqlmodel import select

    if _SessionLocal is None:
        return

    async with _SessionLocal() as session:
        run = await session.get(WorkflowRun, run_id)
        if run is None or run.status != WorkflowStatus.pending:
            # Was cancelled or already picked up by another task.
            _notify_drain(workflow_name)
            return

        cfg = (await session.exec(
            select(Workflow).where(Workflow.id == run.workflow_id)
        )).first()

        # Re-check the concurrency limit now that we hold the session — the limit
        # may have been reduced since this run was queued, or another run may have
        # claimed the last slot in the window between the drain waking and here.
        if cfg is not None and cfg.max_concurrent_runs is not None and cfg.max_concurrent_runs > 0:
            from sqlalchemy import func as _func
            running_count: int = (await session.execute(
                select(_func.count(WorkflowRun.id)).where(
                    WorkflowRun.workflow_id == cfg.id,
                    WorkflowRun.status == WorkflowStatus.running,
                    WorkflowRun.parent_id == None,  # noqa: E711
                )
            )).scalar_one()
            if running_count >= cfg.max_concurrent_runs:
                # Still at the limit — leave the run pending and wait for the next slot.
                return

        inputs = (run.data or {}).get("inputs", {})
        run.status = WorkflowStatus.running
        run.started_at = datetime.now(timezone.utc)
        session.add(run)
        await session.commit()
        await session.refresh(run)

        await manager.broadcast("workflow_list", {"type": "run_updated", "data": _run_summary(run, workflow_name)})

        ctx: dict = {"nodes": [], "plan": [], "logs": []}
        token = _active_run_ctx.set(ctx)
        failure_exc: Exception | None = None
        was_cancelled = False
        timeout = cfg.timeout_seconds if cfg else None
        coro = fn(inputs)
        fn_task = asyncio.create_task(
            asyncio.wait_for(coro, timeout=timeout) if timeout else coro
        )
        _running_tasks[run.id] = fn_task
        try:
            result = await fn_task
            run.status = WorkflowStatus.success
            _inject_pending(ctx)
            wf_outputs = result if isinstance(result, dict) else {}
            nodes = ctx["nodes"] or [
                {
                    "id": run.id, "name": workflow_name, "status": "success",
                    "inputs": inputs, "outputs": wf_outputs,
                    "duration_ms": int((datetime.now(timezone.utc) - run.started_at).total_seconds() * 1000),
                }
            ]
            run.data = {**run.data, "nodes": nodes, "outputs": wf_outputs, "logs": ctx["logs"]}
        except asyncio.CancelledError:
            was_cancelled = True
            result = None
        except Exception as exc:
            failure_exc = exc
            run.status = WorkflowStatus.failed
            _inject_pending(ctx)
            nodes = ctx["nodes"] or [
                {
                    "id": run.id, "name": workflow_name, "status": "failed",
                    "inputs": inputs, "outputs": {},
                    "duration_ms": int((datetime.now(timezone.utc) - run.started_at).total_seconds() * 1000),
                    "logs": [{
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "body": traceback.format_exc(),
                        "type": "error", "json": False,
                    }],
                }
            ]
            run.data = {**run.data, "nodes": nodes, "outputs": {}, "logs": ctx["logs"]}
            result = None
        finally:
            _running_tasks.pop(run.id, None)
            _active_run_ctx.reset(token)

        if not was_cancelled:
            run.finished_at = datetime.now(timezone.utc)
            session.add(run)
            await session.commit()

            await manager.broadcast("workflow_list", {"type": "run_updated", "data": _run_summary(run, workflow_name)})
            await manager.broadcast(f"workflow_detail:{run.id}", {"type": "run_updated", "data": _run_detail(run, workflow_name)})

    # Notify outside the session so the drain loop can open its own session cleanly.
    _notify_drain(workflow_name)


def log(message: str, *, type: str = "info", json: bool = False) -> None:
    """Append a structured log entry to the active log buffer.

    When called inside a ``@gtm.node``, writes to that node's log buffer.
    When called inside a ``@gtm.workflow`` but outside any node, writes to
    the workflow-level log buffer (visible as the run's top-level logs).
    Silently dropped when called outside a workflow.

    Args:
        message: The log message text.  If the text is a raw JSON string,
                 pass ``json=True`` so the frontend can pretty-print it.
        type:    ``"info"`` (default), ``"warning"``, or ``"error"``.
        json:    Set to ``True`` when *message* is a JSON string.
    """
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "body": str(message),
        "type": type,
        "json": json,
    }
    node_buf = _active_node_logs.get()
    if node_buf is not None:
        node_buf.append(entry)
        return
    run_ctx = _active_run_ctx.get()
    if run_ctx is not None:
        run_ctx["logs"].append(entry)


def plan(*names: str) -> None:
    """Declare the ordered list of nodes this workflow intends to run.

    Any node names in the plan that have not completed when the workflow
    finishes (due to an earlier failure) will be recorded with
    ``status = "pending"`` in the dashboard.

    Call once at the top of a ``@gtm.workflow`` function body.
    """
    ctx = _active_run_ctx.get()
    if ctx is not None:
        ctx["plan"] = list(names)


def _inject_pending(ctx: dict) -> None:
    """Append pending entries for any planned-but-not-executed nodes."""
    executed = {n["name"] for n in ctx["nodes"]}
    for name in ctx.get("plan", []):
        if name not in executed:
            ctx["nodes"].append({
                "id": len(ctx["nodes"]) + 1,
                "name": name,
                "status": "pending",
                "inputs": {},
                "outputs": {},
                "duration_ms": 0,
            })


def _run_summary(run: WorkflowRun, workflow_name: str) -> dict:
    """Serialise a WorkflowRun to the camelCase summary shape expected by the frontend."""
    d = run.data or {}
    return {
        "id": run.id,
        "name": workflow_name,
        "status": run.status.value,
        "triggeredBy": run.triggered_by.value if hasattr(run.triggered_by, "value") else run.triggered_by,
        "triggerContext": d.get("trigger_context", {}),
        "inputs": d.get("inputs", {}),
        "outputs": d.get("outputs", {}),
        "startedAt": run.started_at.isoformat() if run.started_at else None,
        "finishedAt": run.finished_at.isoformat() if run.finished_at else None,
        "createdAt": run.created_at.isoformat(),
        "parentId": run.parent_id,
        "children": [],
    }


def _run_detail(run: WorkflowRun, workflow_name: str) -> dict:
    """Serialise a WorkflowRun to the full camelCase detail shape (includes nodes)."""
    d = run.data or {}
    nodes = [
        {
            "id": n.get("id", run.id),
            "name": n.get("name", workflow_name),
            "status": n.get("status", run.status.value),
            "inputs": n.get("inputs", {}),
            "outputs": n.get("outputs", {}),
            "durationMs": n.get("duration_ms", 0),
            "logs": n.get("logs"),
        }
        for n in d.get("nodes", [])
    ]
    return {**_run_summary(run, workflow_name), "nodes": nodes}


def make_node_wrapper(fn):
    """Wrap *fn* so each call is recorded as a node in the active workflow run.

    If called outside a workflow (no active run context), the function runs
    transparently with no tracking overhead.
    """

    @functools.wraps(fn)
    async def wrapper(inputs: dict):
        ctx = _active_run_ctx.get()
        if ctx is None:
            return await fn(inputs)

        node_start = datetime.now(timezone.utc)
        node_logs: list[dict] = []
        logs_token = _active_node_logs.set(node_logs)

        # Reserve a slot now (before any await) so the list order reflects start order.
        slot: dict = {
            "id": len(ctx["nodes"]) + 1,
            "name": fn.__name__,
            "status": "running",
            "inputs": inputs,
            "outputs": {},
            "duration_ms": 0,
            "logs": None,
        }
        ctx["nodes"].append(slot)

        try:
            result = await fn(inputs)
            duration_ms = int((datetime.now(timezone.utc) - node_start).total_seconds() * 1000)
            slot.update({
                "status": "success",
                "outputs": result if isinstance(result, dict) else {},
                "duration_ms": duration_ms,
                "logs": node_logs if node_logs else None,
            })
            return result
        except Exception:
            duration_ms = int((datetime.now(timezone.utc) - node_start).total_seconds() * 1000)
            tb_entry = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "body": traceback.format_exc(),
                "type": "error",
                "json": False,
            }
            slot.update({
                "status": "failed",
                "duration_ms": duration_ms,
                "logs": [*node_logs, tb_entry],
            })
            raise
        finally:
            _active_node_logs.reset(logs_token)

    wrapper._gtm_fn = fn
    return wrapper


def make_workflow_wrapper(fn):
    @functools.wraps(fn)
    async def wrapper(inputs: dict, *, _ctx: TriggerContext | None = None):
        if _ctx is None:
            _ctx = TriggerContext("manual", inputs)

        if _SessionLocal is None:
            return await fn(inputs)

        from .broadcast import manager
        from sqlmodel import func, select

        _parent_ctx = _active_run_ctx.get()
        _parent_run_id: int | None = _parent_ctx.get("run_id") if _parent_ctx else None

        async with _SessionLocal() as session:
            cfg = (await session.exec(
                select(Workflow).where(Workflow.name == fn.__name__)
            )).first()

            if cfg is not None and cfg.max_concurrent_runs is not None:
                # max_concurrent_runs=0 is a degenerate "never run" value — skip unconditionally.
                if cfg.max_concurrent_runs == 0:
                    return None
                running_count: int = (await session.execute(
                    select(func.count(WorkflowRun.id)).where(
                        WorkflowRun.workflow_id == cfg.id,
                        WorkflowRun.status == WorkflowStatus.running,
                        WorkflowRun.parent_id == None,  # noqa: E711
                    )
                )).scalar_one()
                if running_count >= cfg.max_concurrent_runs:
                    # Queue: persist a pending run and wake the drain loop when a slot opens.
                    trigger_type = TriggerType(_ctx.type) if _ctx.type in TriggerType._value2member_map_ else TriggerType.manual
                    queued = WorkflowRun(
                        workflow_id=cfg.id,
                        status=WorkflowStatus.pending,
                        triggered_by=trigger_type,
                        data={"trigger_context": _ctx.to_db(), "nodes": [], "inputs": inputs, "outputs": {}},
                    )
                    session.add(queued)
                    await session.commit()
                    await session.refresh(queued)
                    await manager.broadcast("workflow_list", {"type": "run_created", "data": _run_summary(queued, fn.__name__)})
                    _ensure_drain_task(fn.__name__, fn)
                    return None

            if cfg is None:
                # Workflow not yet registered in DB — create a row on-the-fly.
                cfg = Workflow(name=fn.__name__)
                session.add(cfg)
                await session.commit()
                await session.refresh(cfg)

            trigger_type = TriggerType(_ctx.type) if _ctx.type in TriggerType._value2member_map_ else TriggerType.manual
            run = WorkflowRun(
                workflow_id=cfg.id,
                status=WorkflowStatus.running,
                triggered_by=trigger_type,
                parent_id=_parent_run_id,
                data={"trigger_context": _ctx.to_db(), "nodes": [], "inputs": inputs, "outputs": {}},
                started_at=datetime.now(timezone.utc),
            )
            session.add(run)
            await session.commit()
            await session.refresh(run)

            await manager.broadcast("workflow_list", {"type": "run_created", "data": _run_summary(run, fn.__name__)})

            ctx: dict = {"nodes": [], "plan": [], "logs": [], "run_id": run.id}
            token = _active_run_ctx.set(ctx)
            failure_exc: Exception | None = None
            was_cancelled = False
            timeout = cfg.timeout_seconds if cfg else None
            coro = fn(inputs)
            fn_task = asyncio.create_task(
                asyncio.wait_for(coro, timeout=timeout) if timeout else coro
            )
            _running_tasks[run.id] = fn_task
            try:
                result = await fn_task
                run.status = WorkflowStatus.success
                _inject_pending(ctx)
                wf_outputs = result if isinstance(result, dict) else {}
                nodes = ctx["nodes"] or [
                    {
                        "id": run.id, "name": fn.__name__, "status": "success",
                        "inputs": inputs, "outputs": wf_outputs,
                        "duration_ms": int((datetime.now(timezone.utc) - run.started_at).total_seconds() * 1000),
                    }
                ]
                run.data = {**run.data, "nodes": nodes, "outputs": wf_outputs, "logs": ctx["logs"]}
            except asyncio.CancelledError:
                # The cancel endpoint already persisted status=cancelled and broadcast — skip DB save.
                was_cancelled = True
                result = None
            except Exception as exc:
                failure_exc = exc
                run.status = WorkflowStatus.failed
                _inject_pending(ctx)
                nodes = ctx["nodes"] or [
                    {
                        "id": run.id, "name": fn.__name__, "status": "failed",
                        "inputs": inputs, "outputs": {},
                        "duration_ms": int((datetime.now(timezone.utc) - run.started_at).total_seconds() * 1000),
                        "logs": [{
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            "body": traceback.format_exc(),
                            "type": "error", "json": False,
                        }],
                    }
                ]
                run.data = {**run.data, "nodes": nodes, "outputs": {}, "logs": ctx["logs"]}
                result = None
            finally:
                _running_tasks.pop(run.id, None)
                _active_run_ctx.reset(token)

            if not was_cancelled:
                run.finished_at = datetime.now(timezone.utc)
                session.add(run)
                await session.commit()

                await manager.broadcast("workflow_list", {"type": "run_updated", "data": _run_summary(run, fn.__name__)})
                await manager.broadcast(f"workflow_detail:{run.id}", {"type": "run_updated", "data": _run_detail(run, fn.__name__)})

                if _parent_ctx is not None:
                    duration_ms = int((run.finished_at - run.started_at).total_seconds() * 1000) if run.started_at else 0
                    _parent_ctx["nodes"].append({
                        "id": len(_parent_ctx["nodes"]) + 1,
                        "name": fn.__name__,
                        "type": "workflow",
                        "status": run.status.value,
                        "inputs": inputs,
                        "outputs": (run.data or {}).get("outputs", {}),
                        "duration_ms": duration_ms,
                        "child_run_id": run.id,
                    })

        # Wake the drain loop (outside the session) so it can pick up the next pending run.
        _notify_drain(fn.__name__)

        if failure_exc is not None:
            raise failure_exc

        return result

    wrapper._gtm_fn = fn
    return wrapper
