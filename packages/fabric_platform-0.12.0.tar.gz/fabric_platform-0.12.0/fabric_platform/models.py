"""Pydantic models for the Fabric REST API.

All response types are typed so consumers get autocomplete, validation,
and IDE support. Models use ``model_config = ConfigDict(extra="allow")``
to tolerate new fields added by the server without breaking.

Usage::

    from fabric_platform.models import Organization, WorkflowRun, DomainEvent

    org: Organization = Organization(**data)
    print(org.id, org.name)
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict


class _Base(BaseModel):
    """Base model with permissive config — ignores unknown fields."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)


# ── Auth ──────────────────────────────────────────────────────────────────

class AuthUser(_Base):
    id: str
    email: str | None = None
    display_name: str | None = None
    email_verified: bool = False


class AuthResponse(_Base):
    access_token: str
    refresh_token: str | None = None
    token_type: str = "bearer"
    expires_in: int = 7200
    user: AuthUser | None = None


class TotpEnrollResponse(_Base):
    """Response from POST /v1/auth/totp/enroll."""
    otpauth_uri: str
    recovery_codes: list[str] = []


class TotpVerifyResponse(_Base):
    """Response from POST /v1/auth/totp/verify."""
    enrolled: bool | None = None
    message: str | None = None
    valid: bool | None = None


class TotpRecoveryResponse(_Base):
    """Response from POST /v1/auth/totp/recovery."""
    valid: bool
    message: str


# Backwards-compatible aliases (deprecated)
MfaEnrollResponse = TotpEnrollResponse
MfaChallengeResponse = TotpVerifyResponse  # no challenge step in Fabric TOTP
MfaVerifyResponse = TotpVerifyResponse


# ── Organizations ─────────────────────────────────────────────────────────

class Organization(_Base):
    id: str
    slug: str
    name: str
    archived: bool = False
    created_at: str | None = None
    updated_at: str | None = None


class Membership(_Base):
    id: str
    principal_id: str
    organization_id: str
    team_id: str | None = None
    role: str
    active: bool = True
    created_at: str | None = None


class Team(_Base):
    id: str
    organization_id: str
    slug: str
    name: str
    archived: bool = False
    created_at: str | None = None


class OrgSettings(_Base):
    id: str
    organization_id: str
    display_name: str | None = None
    logo_url: str | None = None
    email_from_name: str | None = None
    webhook_url: str | None = None
    webhook_events: list[str] | None = None
    max_pending_invitations: int = 100
    max_invitations_per_hour: int = 20


class OrgUsageSummary(_Base):
    organization_id: str
    total_runs: int = 0
    total_cost_usd: float = 0.0
    period_start: str | None = None
    period_end: str | None = None


class OrgBudget(_Base):
    organization_id: str
    monthly_limit_usd: float | None = None
    current_spend_usd: float = 0.0


class OrgSecret(_Base):
    name: str
    created_at: str | None = None
    updated_at: str | None = None


# ── Workflows ─────────────────────────────────────────────────────────────

# ── Wiring report (Plan 055) ─────────────────────────────────────────


class WiringIssue(_Base):
    """A single validation finding from build-time wiring analysis."""

    level: str  # "error" | "warning" | "info"
    category: str
    source_task: str
    target_task: str
    key: str | None = None
    message: str = ""
    suggestion: str | None = None


class WiringReport(_Base):
    """Result of build-time wiring validation for a workflow."""

    errors: list[WiringIssue] = []
    warnings: list[WiringIssue] = []
    info: list[WiringIssue] = []
    coverage: float = 0.0
    task_count: int = 0
    validated_connections: int = 0
    unchecked_connections: int = 0


# ── Workflow registry ────────────────────────────────────────────────


class RegistryEntry(_Base):
    id: str
    organization_id: str | None = None
    team_id: str | None = None
    name: str
    language: str
    source: str
    entry_point: str | None = None
    compose_from: list[str] | None = None
    version: str = "1"
    description: str | None = None
    wiring_report: WiringReport | None = None
    wiring_hash: str | None = None
    created_at: str | None = None


class AssetRef(_Base):
    """Typed reference to a file input for a workflow.

    Exactly one of ``asset_id``, ``url``, or ``path`` must be set.

    - ``asset_id`` — a previously uploaded Fabric asset
      (resolved via ``GET /v1/assets/{id}/download``).
    - ``url`` — any directly fetchable HTTP(S) URL.
    - ``path`` — a local filesystem path the worker can read
      (used by ``fab-workflow`` CLI runs and intra-workflow hand-off).

    The workflow-SDK counterpart is ``fabric_workflow_sdk.AssetRef``
    (same shape, stricter validation). Use this model when building
    typed workflow inputs from the client side::

        from fabric_platform.models import AssetRef

        result = client.submit_workflow_run(
            "video/avatar",
            input={
                "actor": AssetRef(asset_id="018f...").model_dump(),
                "audio": AssetRef(url="https://cdn.example.com/vo.mp3").model_dump(),
            },
        )
    """

    asset_id: str | None = None
    """Fabric asset id — resolved via GET /v1/assets/{id}/download."""

    url: str | None = None
    """Directly fetchable HTTP(S) URL."""

    path: str | None = None
    """Local filesystem path the worker can read."""


class RunProgress(_Base):
    total_tasks: int = 0
    completed_tasks: int = 0
    current_task: str | None = None
    percentage: float = 0.0


class WorkflowRun(_Base):
    id: str
    sayiir_instance_id: str | None = None
    organization_id: str | None = None
    team_id: str | None = None
    registry_entry_id: str | None = None
    workflow_name: str | None = None
    created_by: str | None = None
    metadata: dict[str, Any] | None = None
    status: str = "pending"
    progress: RunProgress | None = None
    output: Any | None = None
    error: str | None = None
    created_at: str | None = None


class RunArtifact(_Base):
    id: str
    run_id: str
    asset_id: str | None = None
    task_id: str
    filename: str
    content_type: str | None = None
    produced_by: str | None = None
    consumed_from: list[str] | None = None
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    download_url: str | None = None


class WorkflowCostEstimate(_Base):
    total_estimated_usd: float = 0.0
    per_node: dict[str, float] | None = None
    best_case_usd: float = 0.0
    worst_case_usd: float = 0.0
    source: str = "none"


# ── Stage Inputs ─────────────────────────────────────────────────────────


class FaceSwapInput(_Base):
    """Input for the video/face-swap workflow."""
    source_url: str
    target_url: str | None = None
    persona_gallery_id: str | None = None
    persona_index: int = 0


class MotionTransferInput(_Base):
    """Input for the video/motion-transfer workflow."""
    source_image_url: str | None = None
    driving_video_url: str
    persona_gallery_id: str | None = None
    persona_index: int = 0
    motion_model: str | None = None
    prompt: str | None = None


# ── Events ────────────────────────────────────────────────────────────────

class DomainEvent(_Base):
    id: str
    kind: str
    organization_id: str | None = None
    job_id: str | None = None
    workflow_id: str | None = None
    run_id: str | None = None
    node_key: str | None = None
    payload: dict[str, Any] = {}
    timestamp: str | None = None


# ── Assets ────────────────────────────────────────────────────────────────

class Asset(_Base):
    id: str
    organization_id: str | None = None
    kind: str | None = None
    content_type: str | None = None
    size_bytes: int = 0
    created_at: str | None = None


class SignedUrlResponse(_Base):
    url: str
    expires_at: str | None = None


# ── API Keys ──────────────────────────────────────────────────────────────

class ApiKey(_Base):
    id: str
    prefix: str
    organization_id: str
    team_id: str | None = None
    description: str | None = None
    scopes: list[str] = []
    disabled: bool = False
    expires_at: str | None = None
    created_at: str | None = None


class CreateApiKeyResponse(_Base):
    id: str
    key: str
    prefix: str
    organization_id: str
    scopes: list[str] = []


# ── Permissions ───────────────────────────────────────────────────────────

class Permission(_Base):
    id: str
    principal_id: str | None = None
    organization_id: str | None = None
    team_id: str | None = None
    effect: str = "allow"
    action: str | None = None
    resource_type: str | None = None
    resource_id: str | None = None


class AuthzCheckResponse(_Base):
    allowed: bool = False
    reason: str | None = None


# ── Webhooks ──────────────────────────────────────────────────────────────

class Webhook(_Base):
    id: str
    organization_id: str
    url: str
    description: str | None = None
    event_filter: list[str] = []
    resource_filter: dict[str, str] | None = None
    active: bool = True
    max_retries: int = 3
    created_at: str | None = None


class WebhookDelivery(_Base):
    id: str
    webhook_id: str
    event_id: str
    event_kind: str
    status: str
    status_code: int | None = None
    error_message: str | None = None
    attempt: int = 1
    created_at: str | None = None


# ── Invitations ───────────────────────────────────────────────────────────

class Invitation(_Base):
    id: str
    organization_id: str
    team_id: str | None = None
    email: str
    role: str
    status: str = "pending"
    expires_at: str | None = None
    created_at: str | None = None


# ── Schedules ─────────────────────────────────────────────────────────────

class WorkflowSchedule(_Base):
    id: str
    workflow_definition_id: str | None = None
    cron_expression: str
    timezone: str = "UTC"
    enabled: bool = True
    concurrency_policy: str = "allow"
    created_at: str | None = None


# ── Apps ──────────────────────────────────────────────────────────────────

class AppInfo(_Base):
    id: str
    name: str
    slug: str
    auto_create_org: bool = True
    allowed_origins: list[str] = []
    metadata: dict[str, Any] | None = None
    created_at: str | None = None
    updated_at: str | None = None


class CreateAppResponse(AppInfo):
    client_id: str
    client_secret: str


class AppUsage(_Base):
    app_id: str
    total_runs: int = 0
    total_orgs: int = 0
    total_members: int = 0


class RotateSecretResponse(_Base):
    app_id: str
    client_id: str
    client_secret: str


# ── Providers ─────────────────────────────────────────────────────────────

class ProviderCapability(_Base):
    provider_id: str
    modality: str
    model: str
    supports_streaming: bool = False


class ProviderExecuteResponse(_Base):
    provider_id: str
    model: str
    modality: str
    output: Any = None
    usage: dict[str, Any] = {}


# ── OAuth ─────────────────────────────────────────────────────────────────

class OAuthClient(_Base):
    id: str
    organization_id: str
    name: str
    client_id: str
    scopes: list[str] = []
    disabled: bool = False
    created_at: str | None = None


class OAuthTokenResponse(_Base):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = 7200
    refresh_token: str | None = None
    scope: str = ""


# ── Me ────────────────────────────────────────────────────────────────────

class MeResponse(_Base):
    principal_id: str
    authenticated: bool = True
    email: str | None = None
    display_name: str | None = None


class MyOrgSummary(_Base):
    id: str
    slug: str
    name: str
    role: str | None = None


class MyTeamSummary(_Base):
    id: str
    organization_id: str
    slug: str
    name: str
    role: str | None = None


# ── Sinks ────────────────────────────────────────────────────────────────

class Sink(_Base):
    id: str
    organization_id: str
    sink_type: str  # "http" | "cron"
    workflow_name: str
    active: bool = True
    path: str | None = None
    cron_expression: str | None = None
    timezone: str | None = None
    created_at: str | None = None


class TriggerResponse(_Base):
    run_id: str | None = None
    accepted: bool = False
    message: str = ""
