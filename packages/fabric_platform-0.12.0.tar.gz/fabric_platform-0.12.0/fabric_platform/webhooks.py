"""Webhook signature verification utilities.

The Fabric backend signs every webhook delivery with HMAC-SHA256.
Headers sent with each delivery:
    - ``X-Fabric-Signature``: ``sha256=<hex>`` — HMAC of the raw body
    - ``X-Fabric-Event``: event kind (e.g. ``workflow.run.completed``)
    - ``X-Fabric-Delivery``: unique delivery/event ID

These helpers mirror the TypeScript SDK's ``verifyWebhookSignature`` /
``constructWebhookEvent`` functions exactly — same HMAC scheme, same
header format, same constant-time comparison. See
``sdks/typescript/src/verify-webhook.ts`` for the canonical reference.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any

from fabric_platform.models import DomainEvent


def verify_signature(raw_body: str | bytes, signature: str, secret: str) -> bool:
    """Verify a Fabric webhook signature.

    Args:
        raw_body: The raw request body as received on the wire. Must not
            be re-serialized before verification — JSON key ordering and
            whitespace affect the HMAC.
        signature: The ``X-Fabric-Signature`` header value. Format is
            ``sha256=<hex>``.
        secret: The webhook signing secret (from the org settings page
            or rotated via ``rotate_webhook_secret``).

    Returns:
        True if the signature is valid, False otherwise. Uses
        ``hmac.compare_digest`` for constant-time comparison.
    """
    if isinstance(raw_body, str):
        body_bytes = raw_body.encode("utf-8")
    else:
        body_bytes = raw_body

    expected = _compute_signature(body_bytes, secret)
    return hmac.compare_digest(expected, signature)


def construct_event(
    raw_body: str | bytes,
    signature: str,
    secret: str,
) -> DomainEvent:
    """Verify the signature and parse the webhook payload in one call.

    Mirrors the Stripe SDK pattern. Raises ``ValueError`` if the
    signature is invalid.

    Args:
        raw_body: The raw request body string or bytes.
        signature: The ``X-Fabric-Signature`` header value.
        secret: Your webhook signing secret.

    Returns:
        The parsed ``DomainEvent``.

    Raises:
        ValueError: If the signature is invalid.

    Example:
        >>> from fabric_platform import webhooks
        >>> event = webhooks.construct_event(
        ...     raw_body=request.body,
        ...     signature=request.headers["x-fabric-signature"],
        ...     secret=os.environ["FABRIC_WEBHOOK_SECRET"],
        ... )
        >>> if event.kind == "workflow.run.completed":
        ...     handle_completion(event)
    """
    if not verify_signature(raw_body, signature, secret):
        raise ValueError("Invalid webhook signature")

    if isinstance(raw_body, bytes):
        raw_body = raw_body.decode("utf-8")
    payload: dict[str, Any] = json.loads(raw_body)
    return DomainEvent(**payload)


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------


def _compute_signature(body: bytes, secret: str) -> str:
    mac = hmac.new(secret.encode("utf-8"), body, hashlib.sha256)
    return f"sha256={mac.hexdigest()}"
