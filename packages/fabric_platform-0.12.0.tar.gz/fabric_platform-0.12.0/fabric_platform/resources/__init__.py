"""Resource classes — one per REST resource group."""

from fabric_platform.resources.admin import AdminResource
from fabric_platform.resources.api_keys import ApiKeysResource
from fabric_platform.resources.apps import AppsResource
from fabric_platform.resources.assets import AssetsResource
from fabric_platform.resources.auth import AuthResource
from fabric_platform.resources.events import EventsResource
from fabric_platform.resources.galleries import GalleriesResource
from fabric_platform.resources.invitations import InvitationsResource
from fabric_platform.resources.me import MeResource
from fabric_platform.resources.oauth import OAuthResource
from fabric_platform.resources.organizations import OrganizationsResource
from fabric_platform.resources.packages import PackagesResource
from fabric_platform.resources.permissions import PermissionsResource
from fabric_platform.resources.providers import ProvidersResource
from fabric_platform.resources.schedules import SchedulesResource
from fabric_platform.resources.service_accounts import ServiceAccountsResource
from fabric_platform.resources.sinks import SinksResource
from fabric_platform.resources.teams import TeamsResource
from fabric_platform.resources.webhooks_resource import WebhooksResource
from fabric_platform.resources.workflows import (
    WorkflowRegistryResource,
    WorkflowRunsResource,
    WorkflowsResource,
)

__all__ = [
    "AdminResource",
    "ApiKeysResource",
    "AppsResource",
    "AssetsResource",
    "AuthResource",
    "EventsResource",
    "GalleriesResource",
    "InvitationsResource",
    "MeResource",
    "OAuthResource",
    "OrganizationsResource",
    "PackagesResource",
    "PermissionsResource",
    "ProvidersResource",
    "SchedulesResource",
    "ServiceAccountsResource",
    "SinksResource",
    "TeamsResource",
    "WebhooksResource",
    "WorkflowRegistryResource",
    "WorkflowRunsResource",
    "WorkflowsResource",
]
