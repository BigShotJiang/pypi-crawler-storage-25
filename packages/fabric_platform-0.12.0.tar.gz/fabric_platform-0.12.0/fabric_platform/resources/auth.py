from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class AuthResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    # -- helpers for auto-storing tokens ------------------------------------

    def _store_token(self, data: Any) -> Any:
        if data and data.get("access_token"):
            self._http._client.headers["Authorization"] = f"Bearer {data['access_token']}"
        return data

    # -- public API ---------------------------------------------------------

    def signup(self, email: str, password: str) -> Any:
        data = self._http.unwrap(
            self._http.post("/v1/auth/signup", json={"email": email, "password": password})
        )
        return self._store_token(data)

    def login(self, email: str, password: str) -> Any:
        data = self._http.unwrap(
            self._http.post("/v1/auth/login", json={"email": email, "password": password})
        )
        return self._store_token(data)

    def logout(self, access_token: str | None = None) -> None:
        token = access_token or str(
            self._http._client.headers.get("Authorization", "")
        ).removeprefix("Bearer ")
        self._http.post("/v1/auth/logout", json={"access_token": token}).raise_for_status()
        self._http._client.headers.pop("Authorization", None)

    def refresh(self, refresh_token: str) -> Any:
        data = self._http.unwrap(
            self._http.post("/v1/auth/token/refresh", json={"refresh_token": refresh_token})
        )
        return self._store_token(data)

    def magic_link(self, email: str) -> None:
        self._http.post("/v1/auth/magic-link", json={"email": email}).raise_for_status()

    def forgot_password(self, email: str) -> None:
        self._http.post("/v1/auth/forgot-password", json={"email": email}).raise_for_status()

    def reset_password(self, access_token: str, new_password: str) -> None:
        self._http.post(
            "/v1/auth/reset-password",
            json={"access_token": access_token, "new_password": new_password},
        ).raise_for_status()

    def social_login_url(self, provider: str) -> str:
        return f"{self._http.base_url}/v1/auth/social/{provider}"

    def social_login(
        self,
        provider: str,
        provider_user_id: str,
        email: str,
        display_name: str | None = None,
        avatar_url: str | None = None,
    ) -> Any:
        body: dict[str, Any] = {
            "provider": provider,
            "provider_user_id": provider_user_id,
            "email": email,
        }
        if display_name is not None:
            body["display_name"] = display_name
        if avatar_url is not None:
            body["avatar_url"] = avatar_url
        data = self._http.unwrap(self._http.post("/v1/auth/social-login", json=body))
        return self._store_token(data)

    def resend_verification(self, email: str) -> None:
        self._http.post("/v1/auth/resend-verification", json={"email": email}).raise_for_status()

    def change_password(self, current_password: str, new_password: str) -> None:
        self._http.post(
            "/v1/auth/change-password",
            json={"current_password": current_password, "new_password": new_password},
        ).raise_for_status()

    def logout_all(self) -> None:
        self._http.post("/v1/auth/logout-all", json={}).raise_for_status()

    def verify(self, token: str) -> None:
        raise_for_envelope(self._http.post("/v1/auth/verify", json={"token": token}))

    def totp_enroll(self) -> Any:
        return self._http.unwrap(self._http.post("/v1/auth/totp/enroll"))

    def totp_verify(self, code: str) -> Any:
        return self._http.unwrap(self._http.post("/v1/auth/totp/verify", json={"code": code}))

    def totp_disable(self) -> None:
        raise_for_envelope(self._http.delete("/v1/auth/totp"))

    def totp_recovery(self, code: str) -> Any:
        return self._http.unwrap(self._http.post("/v1/auth/totp/recovery", json={"code": code}))
