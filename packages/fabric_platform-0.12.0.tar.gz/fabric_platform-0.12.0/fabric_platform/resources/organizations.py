from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class OrganizationsResource:
    """Organization lifecycle, settings, secrets, assets, and usage."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    # ── CRUD ─────────────────────────────────────────────────────────

    def create(self, slug: str, name: str) -> Any:
        return self._http.unwrap(
            self._http.post(
                "/v1/organizations", json={"slug": slug, "name": name}
            )
        )

    def list(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/organizations"))

    def get(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}")
        )

    def update(self, org_id: str | None = None, **fields: Any) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.patch(f"/v1/organizations/{org}", json=fields)
        )

    def archive(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.post(f"/v1/organizations/{org}/archive")
        )

    def request_deletion(self, org_id: str | None = None) -> None:
        org = self._http.resolve_org_id(org_id)
        raise_for_envelope(
            self._http.post(f"/v1/organizations/{org}/request-deletion")
        )

    def export(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/export")
        )

    # ── Teams / members / permissions ────────────────────────────────

    def teams(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/teams")
        )

    def members(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/members")
        )

    def permissions(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/permissions")
        )

    # ── Settings ─────────────────────────────────────────────────────

    def get_settings(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/settings")
        )

    def update_settings(self, org_id: str | None = None, **settings: Any) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.patch(
                f"/v1/organizations/{org}/settings", json=settings
            )
        )

    # ── Budget ───────────────────────────────────────────────────────

    def get_budget(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/budget")
        )

    def set_budget(
        self, org_id: str | None = None, *, monthly_limit_usd: float
    ) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.put(
                f"/v1/organizations/{org}/budget",
                json={"monthly_limit_usd": monthly_limit_usd},
            )
        )

    # ── Secrets ──────────────────────────────────────────────────────

    def list_secrets(self, org_id: str | None = None) -> list[str]:
        org = self._http.resolve_org_id(org_id)
        data = self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/secrets")
        )
        return [s["name"] for s in (data or [])]

    def create_secret(
        self, name: str, value: str, org_id: str | None = None
    ) -> None:
        org = self._http.resolve_org_id(org_id)
        raise_for_envelope(
            self._http.post(
                f"/v1/organizations/{org}/secrets",
                json={"name": name, "value": value},
            )
        )

    def delete_secret(self, name: str, org_id: str | None = None) -> None:
        org = self._http.resolve_org_id(org_id)
        raise_for_envelope(
            self._http.delete(f"/v1/organizations/{org}/secrets/{name}")
        )

    # ── Org assets ───────────────────────────────────────────────────

    def create_asset(
        self,
        org_id: str | None = None,
        *,
        asset_type: str,
        name: str,
        provider: str | None = None,
        provider_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        team_id: str | None = None,
    ) -> Any:
        org = self._http.resolve_org_id(org_id)
        body: dict[str, Any] = {"asset_type": asset_type, "name": name}
        if provider is not None:
            body["provider"] = provider
        if provider_id is not None:
            body["provider_id"] = provider_id
        if metadata is not None:
            body["metadata"] = metadata
        if team_id is not None:
            body["team_id"] = team_id
        return self._http.unwrap(
            self._http.post(f"/v1/organizations/{org}/assets", json=body)
        )

    def list_assets(
        self,
        org_id: str | None = None,
        *,
        asset_type: str | None = None,
        team_id: str | None = None,
    ) -> Any:
        org = self._http.resolve_org_id(org_id)
        params: dict[str, Any] = {}
        if asset_type is not None:
            params["asset_type"] = asset_type
        if team_id is not None:
            params["team_id"] = team_id
        return self._http.unwrap(
            self._http.get(
                f"/v1/organizations/{org}/assets", params=params or None
            )
        )

    def get_asset(self, org_id: str | None = None, *, asset_id: str) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/assets/{asset_id}")
        )

    def delete_asset(self, org_id: str | None = None, *, asset_id: str) -> None:
        org = self._http.resolve_org_id(org_id)
        raise_for_envelope(
            self._http.delete(f"/v1/organizations/{org}/assets/{asset_id}")
        )

    # ── Usage & spending ─────────────────────────────────────────────

    def usage(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/usage")
        )

    def usage_daily(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/usage/daily")
        )

    def usage_records(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/usage/records")
        )

    def spending(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/usage/spending")
        )

    # ── Audit & webhooks ─────────────────────────────────────────────

    def audit_logs(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/audit-logs")
        )

    def rotate_webhook_secret(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.post(
                f"/v1/organizations/{org}/webhook-secret/rotate"
            )
        )
