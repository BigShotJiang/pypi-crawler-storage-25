from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class InvitationsResource:
    """Operations on invitations."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def create(self, org_id: str | None = None, *, email: str, role: str) -> Any:
        return self._http.unwrap(
            self._http.post(
                "/v1/invitations",
                json={
                    "organization_id": self._http.resolve_org_id(org_id),
                    "email": email,
                    "role": role,
                },
            )
        )

    def accept(self, invitation_id: str) -> None:
        raise_for_envelope(self._http.post(f"/v1/invitations/{invitation_id}/accept"))

    def revoke(self, invitation_id: str) -> None:
        raise_for_envelope(self._http.post(f"/v1/invitations/{invitation_id}/revoke"))
