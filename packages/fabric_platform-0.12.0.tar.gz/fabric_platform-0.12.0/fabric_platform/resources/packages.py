from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport


class PackagesResource:
    """Operations on packages."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/packages"))
