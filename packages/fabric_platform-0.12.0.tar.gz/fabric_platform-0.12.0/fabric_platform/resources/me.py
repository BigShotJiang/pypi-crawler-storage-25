from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class MeResource:
    """Operations on the authenticated user."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def get(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/me"))

    def organizations(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/me/organizations"))

    def teams(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/me/teams"))

    def permissions(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/me/permissions"))

    def social_connections(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/me/social-connections"))

    def disconnect_social(self, provider: str) -> None:
        raise_for_envelope(self._http.delete(f"/v1/me/social-connections/{provider}"))
