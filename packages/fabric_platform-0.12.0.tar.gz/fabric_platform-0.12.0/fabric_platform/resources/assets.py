from __future__ import annotations

from pathlib import Path
from typing import Any, Union

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class AssetsResource:
    """File-asset upload, listing, and download."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def upload(
        self,
        file: Union[bytes, str, Path],
        *,
        filename: str | None = None,
        content_type: str | None = None,
        organization_id: str | None = None,
    ) -> Any:
        if isinstance(file, (str, Path)):
            path = Path(file)
            data = path.read_bytes()
            filename = filename or path.name
        else:
            data = file
            if not filename:
                raise ValueError("filename is required when uploading raw bytes")

        headers: dict[str, str] = {}
        if content_type:
            headers["Content-Type"] = content_type

        params: dict[str, Any] = {"filename": filename}
        if organization_id:
            params["organization_id"] = organization_id

        return self._http.unwrap(
            self._http.post(
                "/v1/assets",
                content=data,
                params=params,
                headers=headers,
            )
        )

    def list(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        organization_id: str | None = None,
    ) -> Any:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if organization_id:
            params["organization_id"] = organization_id
        return self._http.unwrap(
            self._http.get("/v1/assets", params=params)
        )

    def signed_url(
        self, asset_id: str, *, ttl_seconds: int | None = None
    ) -> Any:
        json_body: dict[str, Any] = {}
        if ttl_seconds is not None:
            json_body["ttl_seconds"] = ttl_seconds
        return self._http.unwrap(
            self._http.post(
                f"/v1/assets/{asset_id}/signed-url",
                json=json_body or None,
            )
        )

    def download(self, asset_id: str) -> bytes:
        resp = self._http.get(f"/v1/assets/{asset_id}")
        raise_for_envelope(resp)
        return resp.content
