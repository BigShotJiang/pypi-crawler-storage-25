from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class ApiKeysResource:
    """Operations on API keys."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def create(
        self,
        name: str,
        org_id: str | None = None,
        scopes: list[str] | None = None,
    ) -> Any:
        body: dict[str, Any] = {
            "name": name,
            "organization_id": self._http.resolve_org_id(org_id),
        }
        if scopes is not None:
            body["scopes"] = scopes
        return self._http.unwrap(self._http.post("/v1/api-keys", json=body))

    def list(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/api-keys"))

    def get(self, key_id: str) -> Any:
        return self._http.unwrap(self._http.get(f"/v1/api-keys/{key_id}"))

    def delete(self, key_id: str) -> None:
        raise_for_envelope(self._http.delete(f"/v1/api-keys/{key_id}"))

    def disable(self, key_id: str) -> None:
        raise_for_envelope(self._http.post(f"/v1/api-keys/{key_id}/disable"))

    def rotate(self, key_id: str) -> Any:
        return self._http.unwrap(self._http.post(f"/v1/api-keys/{key_id}/rotate"))
