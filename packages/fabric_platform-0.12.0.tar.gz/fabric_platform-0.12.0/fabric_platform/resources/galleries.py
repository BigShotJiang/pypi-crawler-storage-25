from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class GalleriesResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def create(
        self,
        *,
        kind: str,
        name: str,
        organization_id: str | None = None,
        team_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        body: dict[str, Any] = {
            "kind": kind,
            "name": name,
            "organization_id": self._http.resolve_org_id(organization_id),
        }
        if team_id is not None:
            body["team_id"] = team_id
        if metadata is not None:
            body["metadata"] = metadata
        return self._http.unwrap(self._http.post("/v1/galleries", json=body))

    def list(
        self,
        kind: str | None = None,
        organization_id: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
    ) -> Any:
        params: dict[str, Any] = {
            "organization_id": self._http.resolve_org_id(organization_id),
            "limit": limit,
        }
        if kind:
            params["kind"] = kind
        if cursor:
            params["cursor"] = cursor
        return self._http.unwrap(self._http.get("/v1/galleries", params=params))

    def get(self, gallery_id: str) -> Any:
        return self._http.unwrap(self._http.get(f"/v1/galleries/{gallery_id}"))

    def delete(self, gallery_id: str) -> None:
        raise_for_envelope(self._http.delete(f"/v1/galleries/{gallery_id}"))

    def list_items(self, gallery_id: str, tags: list[str] | None = None) -> Any:
        params: dict[str, str] = {}
        if tags:
            params["tags"] = ",".join(tags)
        return self._http.unwrap(
            self._http.get(f"/v1/galleries/{gallery_id}/items", params=params)
        )

    def add_item(
        self,
        gallery_id: str,
        *,
        asset_id: str | None = None,
        url: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        body: dict[str, Any] = {}
        if asset_id is not None:
            body["asset_id"] = asset_id
        if url is not None:
            body["url"] = url
        if tags is not None:
            body["tags"] = tags
        if metadata is not None:
            body["metadata"] = metadata
        return self._http.unwrap(
            self._http.post(f"/v1/galleries/{gallery_id}/items", json=body)
        )

    def remove_item(self, item_id: str) -> None:
        raise_for_envelope(self._http.delete(f"/v1/gallery-items/{item_id}"))
