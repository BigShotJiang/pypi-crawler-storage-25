from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport


class TeamsResource:
    """Operations on teams."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def create(self, org_id: str | None = None, *, slug: str, name: str) -> Any:
        return self._http.unwrap(
            self._http.post(
                "/v1/teams",
                json={
                    "organization_id": self._http.resolve_org_id(org_id),
                    "slug": slug,
                    "name": name,
                },
            )
        )

    def get(self, team_id: str) -> Any:
        return self._http.unwrap(self._http.get(f"/v1/teams/{team_id}"))
