from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport


class ProvidersResource:
    """Operations on AI providers."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/providers"))

    def execute(
        self,
        modality: str,
        input: Any,
        model: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        body: dict[str, Any] = {"modality": modality, "input": input}
        if model is not None:
            body["model"] = model
        if params is not None:
            body["params"] = params
        return self._http.unwrap(self._http.post("/v1/providers/execute", json=body))

    def estimate(
        self,
        modality: str,
        input: Any,
        model: str | None = None,
    ) -> Any:
        body: dict[str, Any] = {"modality": modality, "input": input}
        if model is not None:
            body["model"] = model
        return self._http.unwrap(self._http.post("/v1/providers/estimate", json=body))
