from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class AdminResource:
    """Platform administration operations."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def bootstrap(self) -> Any:
        return self._http.unwrap(self._http.post("/v1/admin/bootstrap"))

    def system_info(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/system/info"))

    def system_status(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/system/status"))

    def health_check(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/health"))

    def audit_logs(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/audit-logs"))

    def list_concurrency_limits(self) -> Any:
        return self._http.unwrap(
            self._http.get("/v1/admin/concurrency-limits")
        )

    def set_concurrency_limit(
        self, scope: str, max_concurrent_runs: int
    ) -> Any:
        return self._http.unwrap(
            self._http.put(
                "/v1/admin/concurrency-limits",
                json={"scope": scope, "max_concurrent_runs": max_concurrent_runs},
            )
        )

    def list_users(self, *, limit: int = 20, offset: int = 0) -> Any:
        return self._http.unwrap(
            self._http.get(
                "/v1/admin/users",
                params={"limit": limit, "offset": offset},
            )
        )

    def get_user(self, user_id: str) -> Any:
        return self._http.unwrap(
            self._http.get(f"/v1/admin/users/{user_id}")
        )

    def delete_user(self, user_id: str) -> None:
        raise_for_envelope(self._http.delete(f"/v1/admin/users/{user_id}"))

    def unlock_user(self, user_id: str) -> None:
        raise_for_envelope(
            self._http.post(f"/v1/admin/users/{user_id}/unlock")
        )

    def verify_user(self, user_id: str) -> None:
        raise_for_envelope(
            self._http.post(f"/v1/admin/users/{user_id}/verify")
        )

    def force_logout_user(self, user_id: str) -> None:
        raise_for_envelope(
            self._http.post(f"/v1/admin/users/{user_id}/logout-all")
        )
