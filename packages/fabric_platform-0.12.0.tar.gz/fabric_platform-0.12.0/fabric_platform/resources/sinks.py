from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class SinksResource:
    """Event sink management and trigger endpoints."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def create(
        self,
        org_id: str | None = None,
        *,
        sink_type: str,
        workflow_name: str,
        active: bool = True,
        path: str | None = None,
        cron_expression: str | None = None,
        timezone: str | None = None,
        verification: dict[str, Any] | None = None,
        default_payload: dict[str, Any] | None = None,
        input_context: dict[str, Any] | None = None,
    ) -> Any:
        """Create a sink registration for an organization."""
        org = self._http.resolve_org_id(org_id)
        body: dict[str, Any] = {
            "sink_type": sink_type,
            "workflow_name": workflow_name,
            "active": active,
        }
        if path is not None:
            body["path"] = path
        if cron_expression is not None:
            body["cron_expression"] = cron_expression
        if timezone is not None:
            body["timezone"] = timezone
        if verification is not None:
            body["verification"] = verification
        if default_payload is not None:
            body["default_payload"] = default_payload
        if input_context is not None:
            body["input_context"] = input_context
        return self._http.unwrap(
            self._http.post(f"/v1/organizations/{org}/sinks", json=body)
        )

    def list(self, org_id: str | None = None) -> Any:
        """List sink registrations for an organization."""
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/sinks")
        )

    def get(self, sink_id: str) -> Any:
        """Get a sink registration by ID."""
        return self._http.unwrap(
            self._http.get(f"/v1/sinks/{sink_id}")
        )

    def delete(self, sink_id: str) -> None:
        """Delete a sink registration."""
        raise_for_envelope(self._http.delete(f"/v1/sinks/{sink_id}"))

    def trigger_http(
        self,
        org_id: str,
        path: str,
        payload: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Trigger an HTTP sink by organization ID and path.

        This is the public trigger endpoint — authentication is handled
        by the sink's own verification method, not the API key.
        """
        clean_path = path.lstrip("/")
        return self._http.unwrap(
            self._http.post(
                f"/v1/sinks/trigger/{org_id}/{clean_path}",
                json=payload,
                headers=headers,
            )
        )
