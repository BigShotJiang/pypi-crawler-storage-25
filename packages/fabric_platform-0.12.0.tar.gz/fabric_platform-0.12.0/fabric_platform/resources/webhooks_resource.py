from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class WebhooksResource:
    """Webhook endpoint management and delivery inspection."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def create(
        self,
        org_id: str | None = None,
        *,
        url: str,
        events: list[str],
        resource_filter: dict[str, Any] | None = None,
    ) -> Any:
        org = self._http.resolve_org_id(org_id)
        body: dict[str, Any] = {"url": url, "events": events}
        if resource_filter is not None:
            body["resource_filter"] = resource_filter
        return self._http.unwrap(
            self._http.post(
                f"/v1/organizations/{org}/webhooks", json=body
            )
        )

    def list(self, org_id: str | None = None) -> Any:
        org = self._http.resolve_org_id(org_id)
        return self._http.unwrap(
            self._http.get(f"/v1/organizations/{org}/webhooks")
        )

    def get(self, webhook_id: str) -> Any:
        return self._http.unwrap(
            self._http.get(f"/v1/webhooks/{webhook_id}")
        )

    def update(self, webhook_id: str, **kwargs: Any) -> Any:
        return self._http.unwrap(
            self._http.patch(f"/v1/webhooks/{webhook_id}", json=kwargs)
        )

    def delete(self, webhook_id: str) -> None:
        raise_for_envelope(self._http.delete(f"/v1/webhooks/{webhook_id}"))

    def deliveries(
        self,
        webhook_id: str,
        *,
        limit: int = 50,
        offset: int = 0,
    ) -> Any:
        return self._http.unwrap(
            self._http.get(
                f"/v1/webhooks/{webhook_id}/deliveries",
                params={"limit": limit, "offset": offset},
            )
        )
