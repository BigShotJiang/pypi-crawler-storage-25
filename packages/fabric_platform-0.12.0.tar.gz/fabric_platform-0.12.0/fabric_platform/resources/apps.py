from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport


class AppsResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def create(self, name: str, slug: str | None = None, **kwargs: Any) -> Any:
        body: dict[str, Any] = {"name": name}
        if slug:
            body["slug"] = slug
        body.update(kwargs)
        return self._http.unwrap(self._http.post("/v1/apps", json=body))

    def list(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/apps"))

    def get(self, app_id: str) -> Any:
        return self._http.unwrap(self._http.get(f"/v1/apps/{app_id}"))

    def update(self, app_id: str, **kwargs: Any) -> Any:
        return self._http.unwrap(self._http.patch(f"/v1/apps/{app_id}", json=kwargs))

    def rotate_secret(self, app_id: str) -> Any:
        return self._http.unwrap(self._http.post(f"/v1/apps/{app_id}/rotate-secret", json={}))

    def usage(self, app_id: str) -> Any:
        return self._http.unwrap(self._http.get(f"/v1/apps/{app_id}/usage"))
