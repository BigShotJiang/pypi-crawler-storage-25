from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class ServiceAccountsResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def create(
        self,
        *,
        name: str,
        organization_id: str | None = None,
        team_id: str | None = None,
    ) -> Any:
        body: dict[str, Any] = {
            "name": name,
            "organization_id": self._http.resolve_org_id(organization_id),
        }
        if team_id is not None:
            body["team_id"] = team_id
        return self._http.unwrap(self._http.post("/v1/service-accounts", json=body))

    def list(self, *, organization_id: str | None = None) -> Any:
        params = {"organization_id": self._http.resolve_org_id(organization_id)}
        return self._http.unwrap(self._http.get("/v1/service-accounts", params=params))

    def get(self, service_account_id: str) -> Any:
        return self._http.unwrap(
            self._http.get(f"/v1/service-accounts/{service_account_id}")
        )

    def disable(self, service_account_id: str) -> None:
        raise_for_envelope(
            self._http.post(f"/v1/service-accounts/{service_account_id}/disable", json={})
        )

    def enable(self, service_account_id: str) -> None:
        raise_for_envelope(
            self._http.post(f"/v1/service-accounts/{service_account_id}/enable", json={})
        )

    def create_api_key(
        self,
        service_account_id: str,
        *,
        description: str | None = None,
        scopes: list[str] | None = None,
        expires_in_days: int | None = None,
    ) -> Any:
        body: dict[str, Any] = {}
        if description is not None:
            body["description"] = description
        if scopes is not None:
            body["scopes"] = scopes
        if expires_in_days is not None:
            body["expires_in_days"] = expires_in_days
        return self._http.unwrap(
            self._http.post(
                f"/v1/service-accounts/{service_account_id}/api-keys", json=body
            )
        )

    def list_api_keys(self, service_account_id: str) -> Any:
        return self._http.unwrap(
            self._http.get(f"/v1/service-accounts/{service_account_id}/api-keys")
        )

    def revoke_api_key(self, service_account_id: str, key_id: str) -> None:
        raise_for_envelope(
            self._http.delete(
                f"/v1/service-accounts/{service_account_id}/api-keys/{key_id}"
            )
        )

    def rotate_api_key(self, service_account_id: str, key_id: str) -> Any:
        return self._http.unwrap(
            self._http.post(
                f"/v1/service-accounts/{service_account_id}/api-keys/{key_id}/rotate",
                json={},
            )
        )
