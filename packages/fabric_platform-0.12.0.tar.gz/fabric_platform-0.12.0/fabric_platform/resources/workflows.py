"""Workflow registry, runs, and artifacts."""

from __future__ import annotations

import time
from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope

# Sentinel for "argument not passed" vs. "explicitly None".
_UNSET: Any = object()


class WorkflowRegistryResource:
    """``workflows.registry`` — manage workflow definitions."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(
        self,
        *,
        organization_id: str | None = None,
        team_id: str | None = _UNSET,
    ) -> list[dict[str, Any]]:
        resolved_team = self._http.team_id if team_id is _UNSET else team_id
        params: dict[str, Any] = {
            "organization_id": organization_id or self._http.organization_id,
        }
        if resolved_team is not None:
            params["team_id"] = resolved_team
        return self._http.unwrap(
            self._http.get("/v1/workflow-registry", params=params)
        )

    def get(self, name: str, *, organization_id: str | None = None) -> dict[str, Any]:
        params = {"organization_id": organization_id or self._http.organization_id}
        return self._http.unwrap(
            self._http.get(f"/v1/workflow-registry/{name}", params=params)
        )

    def delete(self, name: str, *, organization_id: str | None = None) -> None:
        params = {"organization_id": organization_id or self._http.organization_id}
        raise_for_envelope(
            self._http.delete(f"/v1/workflow-registry/{name}", params=params)
        )

    def get_schemas(self, name: str, *, organization_id: str | None = None) -> dict[str, Any]:
        params = {"organization_id": organization_id or self._http.organization_id}
        return self._http.unwrap(
            self._http.get(f"/v1/workflow-schemas/{name}", params=params)
        )

    def upsert(self, name: str, body: dict[str, Any]) -> dict[str, Any]:
        payload = {**body, "name": name}
        return self._http.unwrap(
            self._http.post("/v1/workflow-registry", json=payload)
        )

    def compose(
        self, name: str, steps: list[str], *, description: str | None = None
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name, "steps": steps}
        if description is not None:
            body["description"] = description
        return self._http.unwrap(
            self._http.post("/v1/workflows/compose", json=body)
        )


class WorkflowRunsResource:
    """``workflows.runs`` — submit, monitor, and control runs."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def submit(
        self,
        workflow_name: str,
        *,
        input: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        priority: int | None = None,
        organization_id: str | None = None,
        team_id: str | None = _UNSET,
        validate: bool = False,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "name": workflow_name,
            "organization_id": organization_id or self._http.organization_id,
        }
        resolved_team = self._http.team_id if team_id is _UNSET else team_id
        if resolved_team is not None:
            params["team_id"] = resolved_team
        if validate:
            params["validate"] = "true"
        body: dict[str, Any] = {"input": input or {}}
        if metadata is not None:
            body["metadata"] = metadata
        if priority is not None:
            body["priority"] = priority
        return self._http.unwrap(
            self._http.post("/v1/workflows/run", params=params, json=body)
        )

    def submit_and_wait(
        self,
        workflow_name: str,
        *,
        input: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        priority: int | None = None,
        timeout: float = 900.0,
        poll_interval: float = 1.0,
    ) -> dict[str, Any]:
        run = self.submit(
            workflow_name, input=input, metadata=metadata, priority=priority,
        )
        return self.wait(run["id"], poll_interval=poll_interval, timeout=timeout)

    def list(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        organization_id: str | None = None,
        team_id: str | None = _UNSET,
        created_by: str | None = _UNSET,
    ) -> list[dict[str, Any]]:
        resolved_team = self._http.team_id if team_id is _UNSET else team_id
        resolved_user = self._http.user_id if created_by is _UNSET else created_by
        params: dict[str, Any] = {
            "organization_id": organization_id or self._http.organization_id,
            "limit": limit,
            "offset": offset,
        }
        if resolved_team is not None:
            params["team_id"] = resolved_team
        if resolved_user is not None:
            params["created_by"] = resolved_user
        return self._http.unwrap(
            self._http.get("/v1/workflows/runs", params=params)
        )

    def list_waiting(
        self,
        *,
        organization_id: str | None = None,
        team_id: str | None = _UNSET,
        created_by: str | None = _UNSET,
    ) -> list[dict[str, Any]]:
        resolved_team = self._http.team_id if team_id is _UNSET else team_id
        resolved_user = self._http.user_id if created_by is _UNSET else created_by
        params: dict[str, Any] = {
            "organization_id": organization_id or self._http.organization_id,
        }
        if resolved_team is not None:
            params["team_id"] = resolved_team
        if resolved_user is not None:
            params["created_by"] = resolved_user
        return self._http.unwrap(
            self._http.get("/v1/workflows/runs/waiting", params=params)
        )

    def get(self, run_id: str) -> dict[str, Any]:
        return self._http.unwrap(
            self._http.get(f"/v1/workflows/runs/{run_id}")
        )

    def get_output(
        self, run_id: str, *, expires_in: int | None = None
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if expires_in is not None:
            params["expires_in"] = expires_in
        return self._http.unwrap(
            self._http.get(f"/v1/workflows/runs/{run_id}/output", params=params)
        )

    def cancel(self, run_id: str, reason: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if reason is not None:
            body["reason"] = reason
        return self._http.unwrap(
            self._http.post(f"/v1/workflows/runs/{run_id}/cancel", json=body)
        )

    def bulk_cancel(self, run_ids: list[str]) -> dict[str, Any]:
        return self._http.unwrap(
            self._http.post(
                "/v1/workflow-runs/bulk-cancel", json={"run_ids": run_ids}
            )
        )

    def pause(self, run_id: str, reason: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if reason is not None:
            body["reason"] = reason
        return self._http.unwrap(
            self._http.post(f"/v1/workflows/runs/{run_id}/pause", json=body)
        )

    def resume(self, run_id: str) -> dict[str, Any]:
        return self._http.unwrap(
            self._http.post(f"/v1/workflows/runs/{run_id}/resume", json={})
        )

    def recover(self, run_id: str) -> dict[str, Any]:
        return self._http.unwrap(
            self._http.post(f"/v1/workflows/runs/{run_id}/recover", json={})
        )

    def signal(
        self,
        run_id: str,
        signal_name: str,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self._http.unwrap(
            self._http.post(
                f"/v1/workflows/runs/{run_id}/signal",
                json={"signal_name": signal_name, "payload": payload or {}},
            )
        )

    def approve(
        self,
        run_id: str,
        *,
        approved: bool = True,
        reason: str | None = None,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"approved": approved}
        if reason is not None:
            body["reason"] = reason
        if data is not None:
            body["data"] = data
        return self._http.unwrap(
            self._http.post(f"/v1/workflows/runs/{run_id}/approve", json=body)
        )

    def wait(
        self,
        run_id: str,
        poll_interval: float = 1.0,
        timeout: float = 300.0,
    ) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            run = self.get(run_id)
            if run.get("status") in ("completed", "failed", "cancelled"):
                return run
            time.sleep(poll_interval)
        raise TimeoutError(f"Run {run_id} did not complete within {timeout}s")

    def log(self, run_id: str) -> dict[str, Any]:
        return self._http.unwrap(
            self._http.get(f"/v1/workflow-runs/{run_id}/log")
        )

    def children(self, run_id: str) -> list[dict[str, Any]]:
        return self._http.unwrap(
            self._http.get(f"/v1/workflow-runs/{run_id}/children")
        )

    def resume_node(
        self, run_id: str, node_key: str, data: dict[str, Any] | None = None
    ) -> None:
        self._http.post(
            f"/v1/workflow-runs/{run_id}/nodes/{node_key}/resume",
            json=data or {},
        ).raise_for_status()

    def artifacts(self, run_id: str) -> list[dict[str, Any]]:
        return self._http.unwrap(
            self._http.get(f"/v1/workflows/runs/{run_id}/artifacts")
        )

    def record_artifact(
        self,
        run_id: str,
        *,
        task_id: str,
        filename: str,
        content_type: str | None = None,
        asset_id: str | None = None,
        produced_by: str | None = None,
        consumed_from: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"task_id": task_id, "filename": filename}
        if content_type is not None:
            body["content_type"] = content_type
        if asset_id is not None:
            body["asset_id"] = asset_id
        if produced_by is not None:
            body["produced_by"] = produced_by
        if consumed_from is not None:
            body["consumed_from"] = consumed_from
        if metadata is not None:
            body["metadata"] = metadata
        return self._http.unwrap(
            self._http.post(
                f"/v1/workflows/runs/{run_id}/artifacts", json=body
            )
        )


class WorkflowsResource:
    """``workflows`` — registry, runs, and cost estimation."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http
        self.registry = WorkflowRegistryResource(http)
        self.runs = WorkflowRunsResource(http)

    def estimate(
        self,
        name: str,
        *,
        cost_profile: dict[str, Any] | None = None,
        input: dict[str, Any] | None = None,
        organization_id: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {
            "name": name,
            "organization_id": self._http.resolve_org_id(organization_id),
        }
        body: dict[str, Any] = {}
        if cost_profile:
            body["cost_profile"] = cost_profile
        if input:
            body["input"] = input
        return self._http.unwrap(
            self._http.post("/v1/workflows/estimate", params=params, json=body)
        )
