from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class PermissionsResource:
    """Operations on permissions and authorization checks."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def check(self, action: str, resource: str | None = None) -> bool:
        body: dict[str, Any] = {"action": action}
        if resource is not None:
            body["resource"] = resource
        data = self._http.unwrap(self._http.post("/v1/authz/check", json=body))
        return bool(data.get("allowed")) if isinstance(data, dict) else False

    def check_batch(self, checks: list[dict[str, Any]]) -> Any:
        return self._http.unwrap(
            self._http.post("/v1/authz/check-batch", json={"checks": checks})
        )

    def grant(
        self,
        *,
        principal_id: str,
        action: str,
        resource: str | None = None,
        effect: str = "allow",
        organization_id: str | None = None,
    ) -> Any:
        body: dict[str, Any] = {
            "principal_id": principal_id,
            "action": action,
            "effect": effect,
        }
        if resource is not None:
            body["resource"] = resource
        if organization_id is not None:
            body["organization_id"] = organization_id
        return self._http.unwrap(self._http.post("/v1/permissions", json=body))

    def list(
        self,
        *,
        organization_id: str | None = None,
        principal_id: str | None = None,
    ) -> Any:
        params: dict[str, str] = {}
        if organization_id is not None:
            params["organization_id"] = organization_id
        if principal_id is not None:
            params["principal_id"] = principal_id
        return self._http.unwrap(self._http.get("/v1/permissions", params=params))

    def revoke(self, permission_id: str) -> None:
        raise_for_envelope(self._http.delete(f"/v1/permissions/{permission_id}"))

    def resolve_workspace_role(
        self,
        *,
        principal_id: str,
        organization_id: str,
        team_id: str | None = None,
    ) -> Any:
        params: dict[str, str] = {
            "principal_id": principal_id,
            "organization_id": organization_id,
        }
        if team_id is not None:
            params["team_id"] = team_id
        return self._http.unwrap(
            self._http.get("/v1/permissions/resolve/workspace", params=params)
        )

    def resolve_org_role(
        self,
        *,
        principal_id: str,
        organization_id: str,
    ) -> Any:
        params = {
            "principal_id": principal_id,
            "organization_id": organization_id,
        }
        return self._http.unwrap(
            self._http.get("/v1/permissions/resolve/org", params=params)
        )
