from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class OAuthResource:
    """OAuth client management and token operations."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def create_client(
        self,
        *,
        name: str,
        redirect_uris: list[str],
        scopes: list[str] | None = None,
        organization_id: str | None = None,
    ) -> Any:
        body: dict[str, Any] = {
            "name": name,
            "redirect_uris": redirect_uris,
        }
        if scopes is not None:
            body["scopes"] = scopes
        if organization_id:
            body["organization_id"] = organization_id
        else:
            body["organization_id"] = self._http.resolve_org_id(None)
        return self._http.unwrap(
            self._http.post("/v1/oauth/clients", json=body)
        )

    def list_clients(self) -> Any:
        return self._http.unwrap(self._http.get("/v1/oauth/clients"))

    def delete_client(self, client_id: str) -> None:
        raise_for_envelope(
            self._http.delete(f"/v1/oauth/clients/{client_id}")
        )

    def token(self, client_id: str, client_secret: str) -> Any:
        return self._http.unwrap(
            self._http.post(
                "/v1/oauth/token",
                json={
                    "grant_type": "client_credentials",
                    "client_id": client_id,
                    "client_secret": client_secret,
                },
            )
        )

    def refresh(self, refresh_token: str) -> Any:
        return self._http.unwrap(
            self._http.post(
                "/v1/oauth/token",
                json={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                },
            )
        )

    def token_exchange(
        self,
        *,
        client_id: str,
        client_secret: str,
        subject_token: str,
        subject_token_type: str = "urn:fabric:user_id",
    ) -> Any:
        """Exchange a user UUID for a user-scoped access token.

        The app authenticates with its client credentials, then receives a
        short-lived JWT scoped to the given user. This enables consumer apps
        to act on behalf of their users from server-side code.
        """
        return self._http.unwrap(
            self._http.post(
                "/v1/oauth/token",
                json={
                    "grant_type": "token_exchange",
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "subject_token": subject_token,
                    "subject_token_type": subject_token_type,
                },
            )
        )

    def revoke(self, token: str) -> None:
        raise_for_envelope(
            self._http.post("/v1/oauth/revoke", json={"token": token})
        )
