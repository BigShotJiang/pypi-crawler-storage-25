from __future__ import annotations

from typing import Any

from fabric_platform._transport import HttpTransport
from fabric_platform.errors import raise_for_envelope


class SchedulesResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def create(
        self, workflow_definition_id: str, cron_expression: str, **kwargs: Any
    ) -> Any:
        body: dict[str, Any] = {"cron_expression": cron_expression, **kwargs}
        return self._http.unwrap(
            self._http.post(
                f"/v1/workflow-definitions/{workflow_definition_id}/schedules",
                json=body,
            )
        )

    def list(self, workflow_definition_id: str) -> Any:
        return self._http.unwrap(
            self._http.get(
                f"/v1/workflow-definitions/{workflow_definition_id}/schedules"
            )
        )

    def get(self, schedule_id: str) -> Any:
        return self._http.unwrap(self._http.get(f"/v1/schedules/{schedule_id}"))

    def update(self, schedule_id: str, **kwargs: Any) -> Any:
        return self._http.unwrap(
            self._http.patch(f"/v1/schedules/{schedule_id}", json=kwargs)
        )

    def delete(self, schedule_id: str) -> None:
        raise_for_envelope(self._http.delete(f"/v1/schedules/{schedule_id}"))

    def trigger(self, schedule_id: str) -> Any:
        return self._http.unwrap(
            self._http.post(f"/v1/schedules/{schedule_id}/trigger")
        )

    def history(self, schedule_id: str) -> Any:
        return self._http.unwrap(
            self._http.get(f"/v1/schedules/{schedule_id}/history")
        )
