from __future__ import annotations

from typing import Any, Iterator

from fabric_platform._transport import HttpTransport


class EventsResource:
    """SSE event streaming."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def stream(self, *, include_internal: bool = False) -> Iterator[dict[str, Any]]:
        yield from self._http.stream_sse(
            "/v1/events/stream", include_internal=include_internal
        )

    def stream_run(
        self, run_id: str, *, include_internal: bool = False
    ) -> Iterator[dict[str, Any]]:
        yield from self._http.stream_sse(
            f"/v1/workflow-runs/{run_id}/events",
            include_internal=include_internal,
        )

    def stream_job(
        self, job_id: str, *, include_internal: bool = False
    ) -> Iterator[dict[str, Any]]:
        yield from self._http.stream_sse(
            f"/v1/jobs/{job_id}/events",
            include_internal=include_internal,
        )
