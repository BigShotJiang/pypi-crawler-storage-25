"""Fabric HTTP client — resource-oriented SDK mirroring the TypeScript SDK.

Usage::

    from fabric_platform import FabricClient

    fabric = FabricClient(api_key="fab_xxx")

    # Submit a workflow
    run = fabric.workflows.runs.submit("research/trends", input={"topic": "AI"})

    # Organizations
    org = fabric.organizations.get()
"""

from __future__ import annotations

import time
from typing import Any

import httpx

from fabric_platform._transport import HttpTransport
from fabric_platform.resources.admin import AdminResource
from fabric_platform.resources.api_keys import ApiKeysResource
from fabric_platform.resources.apps import AppsResource
from fabric_platform.resources.assets import AssetsResource
from fabric_platform.resources.auth import AuthResource
from fabric_platform.resources.events import EventsResource
from fabric_platform.resources.galleries import GalleriesResource
from fabric_platform.resources.invitations import InvitationsResource
from fabric_platform.resources.me import MeResource
from fabric_platform.resources.oauth import OAuthResource
from fabric_platform.resources.organizations import OrganizationsResource
from fabric_platform.resources.packages import PackagesResource
from fabric_platform.resources.permissions import PermissionsResource
from fabric_platform.resources.providers import ProvidersResource
from fabric_platform.resources.schedules import SchedulesResource
from fabric_platform.resources.service_accounts import ServiceAccountsResource
from fabric_platform.resources.sinks import SinksResource
from fabric_platform.resources.teams import TeamsResource
from fabric_platform.resources.webhooks_resource import WebhooksResource
from fabric_platform.resources.workflows import WorkflowsResource


class FabricClient:
    """Synchronous Fabric API client with resource namespaces."""

    def __init__(
        self,
        base_url: str = "http://localhost:3001",
        api_key: str | None = None,
        principal_id: str | None = None,
        organization_id: str = "00000000-0000-0000-0000-000000000010",
        timeout: float = 30.0,
        *,
        team_id: str | None = None,
        user_id: str | None = None,
        app_client_id: str | None = None,
        app_client_secret: str | None = None,
    ):
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        if principal_id:
            headers["X-Principal-Id"] = principal_id
        if app_client_id:
            headers["X-Fabric-App-Id"] = app_client_id

        self.base_url = base_url.rstrip("/")
        self._app_client_id = app_client_id
        self._app_client_secret = app_client_secret
        self._user_token_cache: dict[str, tuple[str, float]] = {}

        self._http_client = httpx.Client(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
        )
        self._transport = HttpTransport(
            self._http_client,
            organization_id=organization_id,
            team_id=team_id,
            user_id=user_id,
        )

        # ── Resource namespaces ──────────────────────────────────────
        self.admin = AdminResource(self._transport)
        self.api_keys = ApiKeysResource(self._transport)
        self.apps = AppsResource(self._transport)
        self.assets = AssetsResource(self._transport)
        self.auth = AuthResource(self._transport)
        self.events = EventsResource(self._transport)
        self.galleries = GalleriesResource(self._transport)
        self.invitations = InvitationsResource(self._transport)
        self.me = MeResource(self._transport)
        self.oauth = OAuthResource(self._transport)
        self.organizations = OrganizationsResource(self._transport)
        self.packages = PackagesResource(self._transport)
        self.permissions = PermissionsResource(self._transport)
        self.providers = ProvidersResource(self._transport)
        self.schedules = SchedulesResource(self._transport)
        self.service_accounts = ServiceAccountsResource(self._transport)
        self.sinks = SinksResource(self._transport)
        self.teams = TeamsResource(self._transport)
        self.webhooks = WebhooksResource(self._transport)
        self.workflows = WorkflowsResource(self._transport)

    # ── Lifecycle ────────────────────────────────────────────────────

    def close(self) -> None:
        self._http_client.close()

    def __enter__(self) -> "FabricClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── Principal context ────────────────────────────────────────────

    @property
    def organization_id(self) -> str:
        return self._transport.organization_id

    def set_organization_id(self, organization_id: str) -> None:
        self._transport.organization_id = organization_id

    def set_team_id(self, team_id: str | None) -> None:
        self._transport.team_id = team_id

    def set_user_id(self, user_id: str | None) -> None:
        self._transport.user_id = user_id

    def get_organization_id(self) -> str:
        return self._transport.organization_id

    def get_team_id(self) -> str | None:
        return self._transport.team_id

    def get_user_id(self) -> str | None:
        return self._transport.user_id

    # ── User-scoped client (token exchange) ──────────────────────────

    def as_user(self, user_id: str) -> "FabricClient":
        """Get a user-scoped client via token exchange.

        Requires ``app_client_id`` and ``app_client_secret`` to be set.
        Caches tokens and auto-refreshes 30s before expiry.
        """
        if not self._app_client_id or not self._app_client_secret:
            raise ValueError("as_user() requires app_client_id and app_client_secret")

        now = time.monotonic()
        if user_id in self._user_token_cache:
            token, expires_at = self._user_token_cache[user_id]
            if expires_at > now + 30:
                return FabricClient(
                    base_url=self.base_url,
                    api_key=token,
                    organization_id=self.organization_id,
                )

        resp = httpx.post(
            f"{self.base_url}/v1/oauth/token",
            json={
                "grant_type": "token_exchange",
                "client_id": self._app_client_id,
                "client_secret": self._app_client_secret,
                "subject_token": user_id,
                "subject_token_type": "urn:fabric:user_id",
            },
            timeout=30.0,
        )
        resp.raise_for_status()
        data = resp.json().get("data", {})
        access_token = data["access_token"]
        expires_in = data.get("expires_in", 7200)

        self._user_token_cache[user_id] = (access_token, now + expires_in)

        return FabricClient(
            base_url=self.base_url,
            api_key=access_token,
            organization_id=self.organization_id,
        )
