"""Shared HTTP transport layer for resource classes.

Every resource class receives a reference to a single ``HttpTransport``
instance owned by :class:`~fabric_platform.client.FabricClient`. The
transport holds the underlying ``httpx.Client``, principal-scoping
defaults, and common helpers (envelope unwrapping, SSE streaming, org-id
resolution).
"""

from __future__ import annotations

import json
from typing import Any, Iterator

import httpx

from fabric_platform.errors import raise_for_envelope


class HttpTransport:
    """Low-level HTTP plumbing shared by every resource class."""

    def __init__(
        self,
        client: httpx.Client,
        *,
        organization_id: str = "",
        team_id: str | None = None,
        user_id: str | None = None,
    ) -> None:
        self._client = client
        self.organization_id = organization_id
        self.team_id = team_id
        self.user_id = user_id

    @property
    def base_url(self) -> str:
        return str(self._client.base_url).rstrip("/")

    # ── Envelope helpers ──────────────────────────────────────────────

    def unwrap(self, resp: httpx.Response) -> Any:
        """Parse a Fabric envelope, raise on error, return ``data``."""
        raise_for_envelope(resp)
        if not resp.content:
            return None
        try:
            body = resp.json()
        except Exception:
            return None
        if isinstance(body, dict):
            return body.get("data")
        return body

    # ── Org-id resolution ─────────────────────────────────────────────

    def resolve_org_id(self, org_id: str | None = None) -> str:
        """Resolve from explicit arg or client default; raise if neither."""
        resolved = org_id or self.organization_id
        if not resolved:
            raise ValueError(
                "org_id required — pass it or set it on the client"
            )
        return resolved

    # ── SSE streaming ─────────────────────────────────────────────────

    def stream_sse(
        self,
        path: str,
        *,
        include_internal: bool = False,
    ) -> Iterator[dict[str, Any]]:
        params = {"include_internal": "true"} if include_internal else None
        with self._client.stream("GET", path, params=params) as resp:
            resp.raise_for_status()
            for line in resp.iter_lines():
                if line.startswith("data: "):
                    payload = line[len("data: "):]
                    if payload.strip():
                        yield json.loads(payload)

    # ── Raw httpx access (for resources that need it) ─────────────────

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return self._client.get(path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> httpx.Response:
        return self._client.post(path, **kwargs)

    def put(self, path: str, **kwargs: Any) -> httpx.Response:
        return self._client.put(path, **kwargs)

    def patch(self, path: str, **kwargs: Any) -> httpx.Response:
        return self._client.patch(path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        return self._client.delete(path, **kwargs)
