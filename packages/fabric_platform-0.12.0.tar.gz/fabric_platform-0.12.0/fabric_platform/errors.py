"""Typed error hierarchy for the Fabric Python SDK.

Mirrors the TypeScript SDK's error classes (``FabricApiError``,
``FabricNotFoundError``, ``FabricRateLimitError``, etc.) so consumers can
``except FabricNotFoundError:`` instead of inspecting HTTP status codes
manually. Every error carries the original status code, response body
envelope (when present), and optional ``Retry-After`` for rate limits.

The HTTP layer (``FabricClient._unwrap``) parses error envelopes of the
shape ``{"error": {"code": "...", "message": "..."}}`` and dispatches to
the right subclass via :func:`raise_for_status_envelope`. Anything that
isn't a Fabric envelope falls through to the underlying ``httpx``
exception unchanged — we don't try to type errors from middleware
layers we don't own.
"""

from __future__ import annotations

from typing import Any

import httpx


class FabricError(Exception):
    """Base class for every Fabric SDK exception.

    All typed errors inherit from this so callers can catch the whole
    family with a single ``except FabricError:`` if they don't care
    about the specific status.

    Attributes:
        status_code: HTTP status code from the response.
        code: The Fabric error code from the envelope (e.g. ``"not_found"``,
            ``"unauthorized"``). May be ``None`` for non-envelope errors.
        message: Human-readable message from the envelope.
        request_id: Request id from the response meta block (if present),
            useful for cross-referencing server logs.
        response: The raw ``httpx.Response`` for callers who need to dig
            into headers / body bytes themselves.
    """

    status_code: int
    code: str | None
    request_id: str | None
    response: httpx.Response | None

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 0,
        code: str | None = None,
        request_id: str | None = None,
        response: httpx.Response | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.request_id = request_id
        self.response = response


class FabricValidationError(FabricError):
    """400 Bad Request — request body or parameters failed validation."""


class FabricAuthError(FabricError):
    """401 Unauthorized — missing, invalid, or expired credentials."""


class FabricForbiddenError(FabricError):
    """403 Forbidden — authenticated but lacking permission for this action."""


class FabricNotFoundError(FabricError):
    """404 Not Found — resource doesn't exist or isn't visible to the caller."""


class FabricConflictError(FabricError):
    """409 Conflict — uniqueness violation or state-machine conflict."""


class FabricRateLimitError(FabricError):
    """429 Too Many Requests — rate limit exceeded.

    Carries the parsed ``Retry-After`` header (in seconds) when the server
    provides one. ``None`` means no hint was given.
    """

    retry_after: float | None

    def __init__(
        self,
        message: str,
        *,
        retry_after: float | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class FabricServerError(FabricError):
    """5xx — server-side error. Retry may help; the cause is upstream."""


# ---------------------------------------------------------------------------
# Status → exception class lookup
# ---------------------------------------------------------------------------

_STATUS_MAP: dict[int, type[FabricError]] = {
    400: FabricValidationError,
    401: FabricAuthError,
    403: FabricForbiddenError,
    404: FabricNotFoundError,
    409: FabricConflictError,
    422: FabricValidationError,
    429: FabricRateLimitError,
}


def _exception_for_status(status: int) -> type[FabricError]:
    """Pick the right error class for an HTTP status code."""
    if status in _STATUS_MAP:
        return _STATUS_MAP[status]
    if 500 <= status < 600:
        return FabricServerError
    return FabricError


def raise_for_envelope(response: httpx.Response) -> None:
    """Raise a typed :class:`FabricError` for any non-2xx response.

    Parses Fabric's standard envelope shape::

        {
          "meta":  {"status": 404, "request_id": "..."},
          "error": {"code": "not_found", "message": "Run not found"},
          "data":  null
        }

    and uses the ``error.code`` / ``error.message`` to populate the
    exception. If the response body isn't JSON or doesn't match that
    shape, we fall back to a synthetic message built from the status
    code so the caller still gets a typed exception.

    No-op for successful responses (2xx).
    """
    if response.is_success:
        return

    status = response.status_code
    code: str | None = None
    message = f"HTTP {status}"
    request_id: str | None = None

    try:
        body = response.json()
    except Exception:
        body = None

    if isinstance(body, dict):
        meta = body.get("meta") if isinstance(body.get("meta"), dict) else None
        err = body.get("error") if isinstance(body.get("error"), dict) else None
        if err is not None:
            code = err.get("code") if isinstance(err.get("code"), str) else None
            msg = err.get("message")
            if isinstance(msg, str) and msg:
                message = msg
        if meta is not None:
            rid = meta.get("request_id")
            if isinstance(rid, str):
                request_id = rid

    cls = _exception_for_status(status)
    if cls is FabricRateLimitError:
        retry_after = _parse_retry_after(response.headers.get("retry-after"))
        raise FabricRateLimitError(
            message,
            status_code=status,
            code=code,
            request_id=request_id,
            response=response,
            retry_after=retry_after,
        )
    raise cls(
        message,
        status_code=status,
        code=code,
        request_id=request_id,
        response=response,
    )


def _parse_retry_after(value: str | None) -> float | None:
    """Best-effort parse of a ``Retry-After`` header into seconds.

    Only handles the delta-seconds form (e.g. ``"30"``). HTTP-date form
    is uncommon for our endpoints and isn't worth the date-parsing
    complexity here — callers can fall back to ``response.headers``
    on the exception if they need it.
    """
    if not value:
        return None
    try:
        return float(value.strip())
    except (TypeError, ValueError):
        return None
