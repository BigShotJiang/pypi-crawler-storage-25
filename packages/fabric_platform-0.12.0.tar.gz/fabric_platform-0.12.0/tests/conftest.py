"""Shared test fixtures for the Python SDK.

The whole suite uses ``httpx.MockTransport`` so we can pin every method
to its expected URL/body without standing up the API server. The
fixtures here build a ``FabricClient`` whose internal ``httpx.Client``
points at a mock that records each request and dispatches a per-test
canned response.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Callable

import httpx
import pytest

# Make the local package importable without `pip install -e` so the suite
# runs hermetically against the working tree.
_SDK_ROOT = Path(__file__).resolve().parents[1]
if str(_SDK_ROOT) not in sys.path:
    sys.path.insert(0, str(_SDK_ROOT))

from fabric_platform import FabricClient  # noqa: E402


# Type alias for handlers — a function that inspects a request and
# returns a response. Tests provide one of these per fixture.
Handler = Callable[[httpx.Request], httpx.Response]


def _envelope(data: Any = None, *, status: int = 200) -> dict[str, Any]:
    """Wrap a payload in the Fabric envelope shape."""
    return {
        "meta": {"status": status, "request_id": "test-req"},
        "data": data,
        "error": None,
    }


def _error_envelope(
    code: str, message: str, *, status: int
) -> dict[str, Any]:
    """Build a Fabric-shaped error envelope."""
    return {
        "meta": {"status": status, "request_id": "test-req"},
        "data": None,
        "error": {"code": code, "message": message},
    }


class RequestRecorder:
    """Records every request the client made for later assertion."""

    def __init__(self) -> None:
        self.requests: list[httpx.Request] = []

    def __call__(self, handler: Handler) -> Handler:
        def _wrapped(request: httpx.Request) -> httpx.Response:
            self.requests.append(request)
            return handler(request)

        return _wrapped

    def last(self) -> httpx.Request:
        assert self.requests, "no requests recorded"
        return self.requests[-1]


@pytest.fixture
def recorder() -> RequestRecorder:
    """A fresh recorder per test."""
    return RequestRecorder()


@pytest.fixture
def make_client(
    recorder: RequestRecorder,
) -> Callable[[Handler], FabricClient]:
    """Factory: pass a handler, get a wired FabricClient.

    The returned client uses an httpx MockTransport so no real network
    traffic ever leaves the test. The recorder captures every request
    so tests can assert on URLs, methods, headers, and bodies.
    """

    def _make(handler: Handler) -> FabricClient:
        client = FabricClient(
            base_url="http://test.fabric.local",
            api_key="test-api-key",
        )
        # Replace the inner httpx.Client with one that uses MockTransport.
        # We have to preserve headers + base_url so request inspection
        # still sees the realistic shape.
        original = client._http_client
        original.close()
        mock_client = httpx.Client(
            base_url=client.base_url,
            headers=dict(original.headers),
            transport=httpx.MockTransport(recorder(handler)),
        )
        client._http_client = mock_client
        client._transport._client = mock_client
        return client

    return _make


# Convenience handlers — used widely below.


def respond_with(payload: Any, *, status: int = 200) -> Handler:
    """Build a handler that always returns the same envelope payload."""

    def _handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(status, json=_envelope(payload, status=status))

    return _handler


def respond_with_error(
    code: str, message: str, *, status: int
) -> Handler:
    """Build a handler that always returns the same error envelope."""

    def _handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status, json=_error_envelope(code, message, status=status)
        )

    return _handler


def request_body_json(request: httpx.Request) -> Any:
    """Decode a request body as JSON; returns None for empty bodies."""
    if not request.content:
        return None
    return json.loads(request.content)


# Re-export envelope helpers for tests that build their own handlers.
__all__ = [
    "FabricClient",
    "Handler",
    "RequestRecorder",
    "_envelope",
    "_error_envelope",
    "make_client",
    "recorder",
    "request_body_json",
    "respond_with",
    "respond_with_error",
]
