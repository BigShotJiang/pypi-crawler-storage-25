"""Coverage for the resource-class pattern on FabricClient.

This pins the contracts that are easy to break and the ones that
diverge from "single GET/POST passthrough":

* Principal setters mutate state and flow to transport.
* Method → URL/method mapping for one representative method per
  resource group.
* ``submit_and_wait`` polls until terminal status.
* Typed errors propagate from the HTTP layer.
* ``upload`` accepts both bytes and a file path.
* ``download`` returns raw bytes.
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from tests.conftest import (
    Handler,
    RequestRecorder,
    _envelope,
    request_body_json,
    respond_with,
    respond_with_error,
)

from fabric_platform import FabricClient
from fabric_platform.errors import (
    FabricNotFoundError,
    FabricRateLimitError,
    FabricValidationError,
)


# ─── Principal setters ─────────────────────────────────────────────────


def test_principal_setters_mutate_client_state() -> None:
    client = FabricClient(api_key="x", base_url="http://test.local")

    client.set_organization_id("org-aaa")
    client.set_team_id("team-bbb")
    client.set_user_id("user-ccc")

    assert client.get_organization_id() == "org-aaa"
    assert client.get_team_id() == "team-bbb"
    assert client.get_user_id() == "user-ccc"

    # Clearing is supported.
    client.set_team_id(None)
    client.set_user_id(None)
    assert client.get_team_id() is None
    assert client.get_user_id() is None

    client.close()


def test_principal_setter_affects_list_runs_scoping(
    make_client, recorder: RequestRecorder
) -> None:
    """``set_team_id`` should flow into the next ``workflows.runs.list()``."""
    client = make_client(respond_with([]))

    client.set_team_id("team-xyz")
    client.workflows.runs.list()

    qs = recorder.last().url.params
    assert qs["team_id"] == "team-xyz"


# ─── Workflow registry parity ──────────────────────────────────────────


def test_compose_workflow_posts_to_compose_endpoint(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with({"id": "wf-1", "name": "chained"}))
    result = client.workflows.registry.compose(
        name="chained",
        steps=["research/trends", "hooks/generate"],
        description="research → hooks",
    )
    assert result == {"id": "wf-1", "name": "chained"}
    req = recorder.last()
    assert req.method == "POST"
    assert req.url.path == "/v1/workflows/compose"
    body = request_body_json(req)
    assert body == {
        "name": "chained",
        "steps": ["research/trends", "hooks/generate"],
        "description": "research → hooks",
    }


def test_list_workflow_registry_uses_query_params(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with([]))
    client.workflows.registry.list(organization_id="org-1", team_id="team-2")
    req = recorder.last()
    assert req.method == "GET"
    assert req.url.path == "/v1/workflow-registry"
    assert req.url.params["organization_id"] == "org-1"
    assert req.url.params["team_id"] == "team-2"


def test_delete_workflow_registry_entry_handles_slashed_names(
    make_client, recorder: RequestRecorder
) -> None:
    """Workflow names like ``research/trends`` must round-trip in the path."""
    client = make_client(respond_with(None))
    client.workflows.registry.delete(
        "research/trends", organization_id="org-1"
    )
    req = recorder.last()
    assert req.method == "DELETE"
    assert req.url.path == "/v1/workflow-registry/research/trends"
    assert req.url.params["organization_id"] == "org-1"


# ─── Workflow run state control ────────────────────────────────────────


@pytest.mark.parametrize(
    ("method_name", "url_suffix"),
    [
        ("pause", "/pause"),
        ("resume", "/resume"),
        ("recover", "/recover"),
    ],
)
def test_run_state_methods_post_to_correct_endpoint(
    make_client,
    recorder: RequestRecorder,
    method_name: str,
    url_suffix: str,
) -> None:
    client = make_client(respond_with({"ok": True}))
    method = getattr(client.workflows.runs, method_name)
    method("run-abc")
    req = recorder.last()
    assert req.method == "POST"
    assert req.url.path == f"/v1/workflows/runs/run-abc{url_suffix}"


def test_pause_run_includes_reason_when_provided(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with({"ok": True}))
    client.workflows.runs.pause("run-1", reason="manual pause for debugging")
    body = request_body_json(recorder.last())
    assert body == {"reason": "manual pause for debugging"}


# ─── submit_and_wait ───────────────────────────────────────────────────


def test_submit_and_wait_polls_until_terminal(
    recorder: RequestRecorder,
) -> None:
    """``submit_and_wait`` must poll until status is terminal."""
    poll_count = {"n": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path == "/v1/workflows/run":
            return httpx.Response(
                200, json=_envelope({"id": "run-final", "status": "pending"})
            )
        if path == "/v1/workflows/runs/run-final":
            poll_count["n"] += 1
            status = "completed" if poll_count["n"] >= 2 else "running"
            return httpx.Response(
                200,
                json=_envelope(
                    {
                        "id": "run-final",
                        "status": status,
                        "output": {"result": "done"} if status == "completed" else None,
                    }
                ),
            )
        return httpx.Response(404, json={})

    client = FabricClient(base_url="http://test.local", api_key="x")
    client._http_client.close()
    mock = httpx.Client(
        base_url=client.base_url,
        headers={"Authorization": "Bearer x", "Content-Type": "application/json"},
        transport=httpx.MockTransport(recorder(handler)),
    )
    client._http_client = mock
    client._transport._client = mock

    result = client.workflows.runs.submit_and_wait(
        "research/trends",
        input={"topic": "AI"},
        poll_interval=0.001,
        timeout=5.0,
    )

    assert result["status"] == "completed"
    assert result["output"] == {"result": "done"}
    assert poll_count["n"] >= 2

    client.close()


# ─── Error propagation ────────────────────────────────────────────────


def test_404_envelope_raises_typed_not_found(make_client) -> None:
    client = make_client(
        respond_with_error("not_found", "Run abc not found", status=404)
    )
    with pytest.raises(FabricNotFoundError) as exc_info:
        client.workflows.runs.get("abc")
    err = exc_info.value
    assert err.status_code == 404
    assert err.code == "not_found"
    assert "Run abc not found" in str(err)


def test_429_with_retry_after_raises_typed_rate_limit(make_client) -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(
            429,
            json={
                "meta": {"status": 429},
                "error": {"code": "too_many_requests", "message": "Slow"},
            },
            headers={"Retry-After": "60"},
        )

    client = make_client(handler)
    with pytest.raises(FabricRateLimitError) as exc_info:
        client.workflows.runs.list()
    assert exc_info.value.retry_after == 60.0


def test_400_envelope_raises_validation_error(make_client) -> None:
    client = make_client(
        respond_with_error("invalid_input", "Bad input", status=400)
    )
    with pytest.raises(FabricValidationError):
        client.workflows.registry.compose(name="x", steps=[])


# ─── New resources: service accounts ──────────────────────────────────


def test_create_service_account_posts_with_org_default(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(
        respond_with({"id": "sa-1", "name": "deployer"})
    )
    client.service_accounts.create(name="deployer", description="ci robot")
    req = recorder.last()
    assert req.url.path == "/v1/service-accounts"
    body = request_body_json(req)
    assert body["name"] == "deployer"
    assert body["description"] == "ci robot"
    assert body["organization_id"] == client.organization_id


def test_service_account_api_key_lifecycle(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with({"id": "key-1", "secret": "fab_xyz"}))

    # Create
    client.service_accounts.create_api_key("sa-1")
    assert recorder.last().url.path == "/v1/service-accounts/sa-1/api-keys"

    # Rotate
    client.service_accounts.rotate_api_key("sa-1", "key-1")
    assert (
        recorder.last().url.path
        == "/v1/service-accounts/sa-1/api-keys/key-1/rotate"
    )


# ─── New resources: OAuth ─────────────────────────────────────────────


def test_oauth_token_posts_client_credentials_grant(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(
        respond_with({"access_token": "tok", "expires_in": 7200})
    )
    result = client.oauth.token("client-1", "secret-1")
    assert result["access_token"] == "tok"
    body = request_body_json(recorder.last())
    assert body == {
        "grant_type": "client_credentials",
        "client_id": "client-1",
        "client_secret": "secret-1",
    }


def test_create_oauth_client_includes_redirect_uris(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with({"id": "oc-1", "secret": "shh"}))
    client.oauth.create_client(
        name="my-app",
        redirect_uris=["https://app.example.com/cb"],
        scopes=["openid", "profile"],
    )
    body = request_body_json(recorder.last())
    assert body["name"] == "my-app"
    assert body["redirect_uris"] == ["https://app.example.com/cb"]
    assert body["scopes"] == ["openid", "profile"]


# ─── New resources: assets ────────────────────────────────────────────


def test_upload_asset_from_path(
    make_client, recorder: RequestRecorder, tmp_path: Path
) -> None:
    file = tmp_path / "thumbnail.png"
    file.write_bytes(b"fake-png-bytes")

    client = make_client(respond_with({"id": "asset-1", "filename": "thumbnail.png"}))
    result = client.assets.upload(file)

    assert result["id"] == "asset-1"
    req = recorder.last()
    assert req.url.path == "/v1/assets"
    assert req.url.params["filename"] == "thumbnail.png"
    assert req.content == b"fake-png-bytes"


def test_upload_asset_from_bytes_requires_filename(make_client) -> None:
    client = make_client(respond_with({"id": "asset-1"}))
    with pytest.raises(ValueError, match="filename is required"):
        client.assets.upload(b"raw bytes")


def test_upload_asset_from_bytes_with_filename(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with({"id": "asset-1"}))
    client.assets.upload(b"raw bytes", filename="data.bin", content_type="application/octet-stream")
    req = recorder.last()
    assert req.url.params["filename"] == "data.bin"
    assert req.content == b"raw bytes"


def test_download_asset_returns_raw_bytes(
    make_client, recorder: RequestRecorder
) -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"\x89PNG\x00\x01\x02")

    client = make_client(handler)
    result = client.assets.download("asset-1")
    assert result == b"\x89PNG\x00\x01\x02"
    assert isinstance(result, bytes)


def test_asset_signed_url_returns_url_payload(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(
        respond_with(
            {
                "url": "http://test.local/v1/assets/asset-1?signature=xyz",
                "asset_id": "asset-1",
                "expires_at": "2026-04-06T22:00:00Z",
                "ttl_seconds": 3600,
            }
        )
    )
    result = client.assets.signed_url("asset-1", ttl_seconds=3600)
    assert result["url"].startswith("http://test.local/v1/assets/asset-1")
    assert result["ttl_seconds"] == 3600
    body = request_body_json(recorder.last())
    assert body == {"ttl_seconds": 3600}


# ─── New resources: packages ──────────────────────────────────────────


def test_list_packages_calls_packages_endpoint(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with([{"name": "research", "version": "1.0"}]))
    result = client.packages.list()
    assert result == [{"name": "research", "version": "1.0"}]
    assert recorder.last().url.path == "/v1/packages"


# ─── Galleries ────────────────────────────────────────────────────────


def test_create_gallery_includes_org_default(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with({"id": "gal-1"}))
    client.galleries.create(kind="persona", name="test")
    body = request_body_json(recorder.last())
    assert body["organization_id"] == client.organization_id
    assert body["kind"] == "persona"


def test_add_gallery_item_with_asset_id(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with({"id": "item-1"}))
    client.galleries.add_item("gal-1", asset_id="asset-1", tags=["face"])
    body = request_body_json(recorder.last())
    assert body == {"asset_id": "asset-1", "tags": ["face"]}
    assert recorder.last().url.path == "/v1/galleries/gal-1/items"


# ─── TOTP ─────────────────────────────────────────────────────────────


def test_totp_enroll_returns_enrollment_payload(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(
        respond_with(
            {"otpauth_uri": "otpauth://totp/Fabric:user@test.com?secret=ABC", "recovery_codes": ["aaa", "bbb"]}
        )
    )
    result = client.auth.totp_enroll()
    assert result["otpauth_uri"].startswith("otpauth://")
    assert recorder.last().url.path == "/v1/auth/totp/enroll"


def test_totp_verify_posts_code(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(
        respond_with({"enrolled": True, "message": "TOTP enrollment verified and activated"})
    )
    result = client.auth.totp_verify("123456")
    assert result["enrolled"] is True
    body = request_body_json(recorder.last())
    assert body == {"code": "123456"}
    assert recorder.last().url.path == "/v1/auth/totp/verify"


# ─── Permissions CRUD ────────────────────────────────────────────────


def test_grant_permission_posts_full_payload(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with({"id": "perm-1"}))
    client.permissions.grant(
        principal_id="user-1",
        action="workflow.run.execute",
        resource="workflow:research/trends",
        organization_id="org-1",
    )
    body = request_body_json(recorder.last())
    assert body == {
        "principal_id": "user-1",
        "action": "workflow.run.execute",
        "effect": "allow",
        "resource": "workflow:research/trends",
        "organization_id": "org-1",
    }


# ─── Org settings / budget ───────────────────────────────────────────


def test_set_org_budget_uses_put(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with({"monthly_limit_usd": 500.0}))
    client.organizations.set_budget("org-1", monthly_limit_usd=500.0)
    req = recorder.last()
    assert req.method == "PUT"
    assert req.url.path == "/v1/organizations/org-1/budget"
    body = request_body_json(req)
    assert body == {"monthly_limit_usd": 500.0}


# ─── Workflow schemas ─────────────────────────────────────────────────


def test_get_workflow_schemas_calls_dedicated_endpoint(
    make_client, recorder: RequestRecorder
) -> None:
    stub = {
        "name": "research/trends",
        "input_schema": {"type": "object", "title": "TrendsInput"},
        "output_schema": {"type": "object", "title": "TrendsOutput"},
        "task_schemas": [
            {
                "task_id": "gather_trends",
                "input_schema": {"type": "object"},
                "output_schema": {"type": "object"},
                "description": "Search the web.",
                "source": "pydantic",
            }
        ],
        "warnings": [],
    }
    client = make_client(respond_with(stub))
    result = client.workflows.registry.get_schemas("research/trends")

    req = recorder.last()
    assert req.method == "GET"
    assert req.url.path == "/v1/workflow-schemas/research/trends"
    assert req.url.params["organization_id"] == client.organization_id

    assert result["name"] == "research/trends"
    assert result["input_schema"]["title"] == "TrendsInput"
    assert result["task_schemas"][0]["source"] == "pydantic"


def test_get_workflow_schemas_handles_untyped_workflows(
    make_client, recorder: RequestRecorder
) -> None:
    stub = {
        "name": "untyped/example",
        "input_schema": None,
        "output_schema": None,
        "task_schemas": None,
        "warnings": ["Task `step_one` has no Pydantic types"],
    }
    client = make_client(respond_with(stub))
    result = client.workflows.registry.get_schemas("untyped/example")
    assert result["input_schema"] is None
    assert result["task_schemas"] is None
    assert len(result["warnings"]) == 1


def test_get_workflow_schemas_forwards_organization_id_override(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(respond_with({"name": "test", "input_schema": None,
                                       "output_schema": None, "task_schemas": None,
                                       "warnings": []}))
    client.workflows.registry.get_schemas("test", organization_id="org-override")
    req = recorder.last()
    assert req.url.params["organization_id"] == "org-override"


# ─── Submit with validate ─────────────────────────────────────────────


def test_submit_run_does_not_pass_validate_by_default(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(
        respond_with({"id": "run-1", "status": "pending"})
    )
    client.workflows.runs.submit("research/trends", input={"topic": "AI"})
    req = recorder.last()
    assert "validate" not in req.url.params


def test_submit_run_passes_validate_true_when_set(
    make_client, recorder: RequestRecorder
) -> None:
    client = make_client(
        respond_with({"id": "run-1", "status": "pending"})
    )
    client.workflows.runs.submit(
        "research/trends",
        input={"topic": "AI"},
        validate=True,
    )
    req = recorder.last()
    assert req.url.params["validate"] == "true"
    body = request_body_json(req)
    assert body["input"] == {"topic": "AI"}
