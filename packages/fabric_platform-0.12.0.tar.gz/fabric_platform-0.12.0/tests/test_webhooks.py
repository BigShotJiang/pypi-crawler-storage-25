"""Tests for the webhook signature verification helpers.

These tests mirror the TypeScript SDK's verify-webhook.test.ts to
guarantee cross-language parity — a payload signed on one side must
verify on the other.
"""

from __future__ import annotations

import hashlib
import hmac
import json

import pytest

from fabric_platform import webhooks
from fabric_platform.models import DomainEvent


SECRET = "whsec_test_1234567890"


def _sign(body: str, secret: str = SECRET) -> str:
    mac = hmac.new(secret.encode("utf-8"), body.encode("utf-8"), hashlib.sha256)
    return f"sha256={mac.hexdigest()}"


def test_verify_signature_accepts_valid_payload():
    body = '{"id":"evt_1","kind":"workflow.run.completed"}'
    assert webhooks.verify_signature(body, _sign(body), SECRET) is True


def test_verify_signature_accepts_bytes_body():
    body = '{"id":"evt_1","kind":"workflow.run.completed"}'
    assert webhooks.verify_signature(body.encode("utf-8"), _sign(body), SECRET) is True


def test_verify_signature_rejects_tampered_body():
    body = '{"id":"evt_1","kind":"workflow.run.completed"}'
    signature = _sign(body)
    tampered = '{"id":"evt_2","kind":"workflow.run.completed"}'
    assert webhooks.verify_signature(tampered, signature, SECRET) is False


def test_verify_signature_rejects_wrong_secret():
    body = '{"id":"evt_1","kind":"workflow.run.completed"}'
    assert webhooks.verify_signature(body, _sign(body), "different_secret") is False


def test_verify_signature_rejects_malformed_header():
    body = '{"id":"evt_1"}'
    assert webhooks.verify_signature(body, "not-a-signature", SECRET) is False


def test_construct_event_returns_parsed_domain_event():
    payload = {
        "id": "evt_42",
        "kind": "workflow.run.completed",
        "run_id": "run_abc",
        "payload": {"output": {"hello": "world"}},
    }
    body = json.dumps(payload)
    event = webhooks.construct_event(body, _sign(body), SECRET)
    assert isinstance(event, DomainEvent)
    assert event.id == "evt_42"
    assert event.kind == "workflow.run.completed"
    assert event.run_id == "run_abc"
    assert event.payload == {"output": {"hello": "world"}}


def test_construct_event_raises_on_bad_signature():
    body = '{"id":"evt_1","kind":"workflow.run.completed"}'
    with pytest.raises(ValueError, match="Invalid webhook signature"):
        webhooks.construct_event(body, "sha256=deadbeef", SECRET)
