"""Tests for the typed error hierarchy.

The error layer is the load-bearing piece — every other test relies on
these classes propagating instead of bare ``httpx.HTTPStatusError``s.
Cover:
1. Each status code maps to the right exception class.
2. The envelope's ``code``/``message``/``request_id`` are surfaced.
3. ``FabricRateLimitError`` exposes ``retry_after`` from the header.
4. Non-envelope error bodies (e.g. raw HTML / empty) still raise a
   typed exception with a synthetic message — no ``KeyError`` from
   trying to dig into a missing field.
5. Successful responses pass through ``raise_for_envelope`` untouched.
"""

from __future__ import annotations

import httpx
import pytest

from fabric_platform.errors import (
    FabricAuthError,
    FabricConflictError,
    FabricError,
    FabricForbiddenError,
    FabricNotFoundError,
    FabricRateLimitError,
    FabricServerError,
    FabricValidationError,
    raise_for_envelope,
)


def _make_response(
    status: int,
    *,
    body: dict | str | None = None,
    headers: dict[str, str] | None = None,
) -> httpx.Response:
    if isinstance(body, dict):
        return httpx.Response(status, json=body, headers=headers or {})
    if body is None:
        return httpx.Response(status, headers=headers or {})
    return httpx.Response(status, content=body, headers=headers or {})


@pytest.mark.parametrize(
    ("status", "expected_cls"),
    [
        (400, FabricValidationError),
        (401, FabricAuthError),
        (403, FabricForbiddenError),
        (404, FabricNotFoundError),
        (409, FabricConflictError),
        (422, FabricValidationError),
        (429, FabricRateLimitError),
        (500, FabricServerError),
        (502, FabricServerError),
        (503, FabricServerError),
    ],
)
def test_status_code_maps_to_typed_exception(
    status: int, expected_cls: type[FabricError]
) -> None:
    body = {
        "meta": {"status": status, "request_id": "req-123"},
        "data": None,
        "error": {"code": "test_error", "message": "something broke"},
    }
    resp = _make_response(status, body=body)
    with pytest.raises(expected_cls) as exc_info:
        raise_for_envelope(resp)
    err = exc_info.value
    assert err.status_code == status
    assert err.code == "test_error"
    assert err.request_id == "req-123"
    assert "something broke" in str(err)


def test_envelope_message_overrides_synthetic_default() -> None:
    body = {
        "meta": {"status": 404, "request_id": "rid"},
        "error": {"code": "not_found", "message": "Run abc not found"},
    }
    resp = _make_response(404, body=body)
    with pytest.raises(FabricNotFoundError) as exc_info:
        raise_for_envelope(resp)
    assert str(exc_info.value) == "Run abc not found"


def test_rate_limit_error_parses_retry_after() -> None:
    body = {
        "meta": {"status": 429},
        "error": {"code": "too_many_requests", "message": "Slow down"},
    }
    resp = _make_response(429, body=body, headers={"Retry-After": "30"})
    with pytest.raises(FabricRateLimitError) as exc_info:
        raise_for_envelope(resp)
    assert exc_info.value.retry_after == 30.0


def test_rate_limit_error_handles_missing_retry_after_header() -> None:
    body = {
        "meta": {"status": 429},
        "error": {"code": "too_many_requests", "message": "Slow down"},
    }
    resp = _make_response(429, body=body)  # no header
    with pytest.raises(FabricRateLimitError) as exc_info:
        raise_for_envelope(resp)
    assert exc_info.value.retry_after is None


def test_non_json_body_still_raises_typed_exception() -> None:
    # Some middleware errors return plain HTML or empty bodies.
    # The envelope parser must not crash on those — it should fall
    # back to a synthetic message and still raise the right class.
    resp = _make_response(503, body="<h1>Bad Gateway</h1>")
    with pytest.raises(FabricServerError) as exc_info:
        raise_for_envelope(resp)
    assert exc_info.value.status_code == 503
    assert exc_info.value.code is None
    assert "503" in str(exc_info.value)


def test_empty_body_still_raises_typed_exception() -> None:
    resp = _make_response(404)
    with pytest.raises(FabricNotFoundError) as exc_info:
        raise_for_envelope(resp)
    assert exc_info.value.status_code == 404


def test_successful_response_does_not_raise() -> None:
    resp = _make_response(200, body={"meta": {"status": 200}, "data": {"ok": True}})
    raise_for_envelope(resp)  # must not raise


def test_all_typed_errors_inherit_from_fabric_error() -> None:
    # Lets callers do `except FabricError:` as a catch-all.
    for cls in (
        FabricValidationError,
        FabricAuthError,
        FabricForbiddenError,
        FabricNotFoundError,
        FabricConflictError,
        FabricRateLimitError,
        FabricServerError,
    ):
        assert issubclass(cls, FabricError)
