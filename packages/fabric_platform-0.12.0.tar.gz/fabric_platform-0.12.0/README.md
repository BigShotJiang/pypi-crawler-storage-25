# fabric-platform

Python SDK for the [Fabric](https://github.com/tinylabscom/fabric) AI workflow platform.

## Installation

```bash
pip install fabric-platform
```

## Quick Start

```python
from fabric_platform import FabricClient

# API key auth
fabric = FabricClient(api_key="fab_your_key")

# Or: native email/password auth
fabric = FabricClient(base_url="https://fabric.example.com")
auth = fabric.login("alice@example.com", "SecurePass1!")

# Or: consumer-driven social login (your app handles OAuth)
auth = fabric.social_login(
    provider="google",
    provider_user_id=google_user["sub"],
    email=google_user["email"],
    display_name=google_user["name"],
)

# Use the authenticated client
me = fabric.get_me()
orgs = fabric.get_my_organizations()
```

## Features

- **Auth**: signup, login, social login, change password, logout-all
- **Organizations & Teams**: CRUD, memberships, invitations
- **Workflows**: submit, monitor, stream events
- **Assets**: upload, download, galleries
- **Webhooks & Schedules**: create, manage, delivery history
- **Admin**: user management (list, unlock, verify, delete)

## Typed workflows

Fabric derives JSON Schemas from each workflow's Pydantic task
types at server boot and stores them in the registry. Discover a
workflow's contract without reading the source:

```python
schemas = fabric.get_workflow_schemas("research/trends")
print(schemas["input_schema"])    # JSON Schema for workflow input
print(schemas["output_schema"])   # JSON Schema for workflow output
print(schemas["task_schemas"])    # Per-task breakdown
```

Opt in to server-side validation on submission:

```python
from fabric_platform.errors import FabricValidationError

try:
    run = fabric.submit_run(
        "research/trends",
        input={"topic": 42},  # wrong type
        validate=True,
    )
except FabricValidationError as e:
    print(e.response.json()["error"]["details"])
```

See the [Typed Workflows guide](https://github.com/tinylabscom/fabric/blob/main/website/src/content/docs/guides/typed-workflows.mdx)
for the full pattern, CI integration, and migration tips.

## Documentation

See the [Fabric documentation](https://github.com/tinylabscom/fabric) for the full API reference.
