# mypy: ignore-errors

from typing import Any, Callable, Coroutine, List, Optional, Type, Union, cast

from tortoise.models import Model

from . import NOT_FOUND, CRUDGenerator
from ._types import DEPENDENCIES, PAGINATION
from ._types import PYDANTIC_SCHEMA as SCHEMA


CALLABLE = Callable[..., Coroutine[Any, Any, Model]]
CALLABLE_LIST = Callable[..., Coroutine[Any, Any, List[Model]]]


class TortoiseCRUDRouter(CRUDGenerator[SCHEMA]):

    def __init__(
        self,
        schema: Type[SCHEMA],
        db_model: Type[Model],
        primary_key_field_name: str = 'id',
        path_param_name: str = 'item_id',
        create_schema: Optional[Type[SCHEMA]] = None,
        update_schema: Optional[Type[SCHEMA]] = None,
        prefix: Optional[str] = None,
        tags: Optional[List[str]] = None,
        paginate: Optional[int] = None,
        get_all_route: Union[bool, DEPENDENCIES] = True,
        get_one_route: Union[bool, DEPENDENCIES] = True,
        create_route: Union[bool, DEPENDENCIES] = True,
        update_route: Union[bool, DEPENDENCIES] = True,
        delete_one_route: Union[bool, DEPENDENCIES] = True,
        delete_all_route: Union[bool, DEPENDENCIES] = True,
        **kwargs: Any,
    ) -> None:

        self.db_model = db_model
        self.primary_key_field_name = primary_key_field_name
        self._pk: str = db_model.describe()["pk_field"]["db_column"]

        super().__init__(
            schema=schema,
            path_param_name=path_param_name,
            create_schema=create_schema,
            update_schema=update_schema,
            prefix=prefix or db_model.describe()["name"].replace("None.", ""),
            tags=tags,
            paginate=paginate,
            get_all_route=get_all_route,
            get_one_route=get_one_route,
            create_route=create_route,
            update_route=update_route,
            delete_one_route=delete_one_route,
            delete_all_route=delete_all_route,
            **kwargs
        )

    def _get_all(self, *args: Any, **kwargs: Any) -> CALLABLE_LIST:
        async def get_all(pagination: PAGINATION = self.pagination) -> List[Model]:
            skip, limit = pagination.get("skip"), pagination.get("limit")
            query = self.db_model.all().offset(cast(int, skip))
            if limit:
                query = query.limit(limit)
            return await query

        return get_all

    def _get_one(self, *args: Any, **kwargs: Any) -> CALLABLE:
        async def get_one(item_id: int) -> Model:
            model = await self.db_model.filter(**{self.primary_key_field_name: item_id}).first()

            if model:
                return model
            else:
                raise NOT_FOUND

        return get_one

    def _create(self, *args: Any, **kwargs: Any) -> CALLABLE:
        async def create(model: self.create_schema) -> Model:  # type: ignore
            db_model = self.db_model(**model.dict())
            await db_model.save()

            return db_model

        return create

    def _update(self, *args: Any, **kwargs: Any) -> CALLABLE:
        async def update(
            item_id: int, model: self.update_schema  # type: ignore
        ) -> Model:
            await self.db_model.filter(**{self.primary_key_field_name: item_id}).update(
                **model.dict(exclude_unset=True)
            )
            return await self._get_one()(item_id)

        return update

    def _delete_all(self, *args: Any, **kwargs: Any) -> CALLABLE_LIST:
        async def delete_all() -> List[Model]:
            await self.db_model.all().delete()
            return await self._get_all()(pagination={"skip": 0, "limit": None})

        return delete_all

    def _delete_one(self, *args: Any, **kwargs: Any) -> CALLABLE:
        async def delete_one(item_id: int) -> Model:
            model: Model = await self._get_one()(item_id)
            await self.db_model.filter(**{self.primary_key_field_name: item_id}).delete()

            return model

        return delete_one
