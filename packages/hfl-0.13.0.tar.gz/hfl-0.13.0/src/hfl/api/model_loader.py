# SPDX-License-Identifier: HRUL-1.0
# Copyright (c) 2026 Gabriel Galán Pelayo
"""
Centralized model loading logic for API routes.

Consolidates model loading from routes_openai.py and routes_native.py
to avoid code duplication and ensure consistent behavior.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from hfl.api.state import get_state
from hfl.converter.formats import ModelType, detect_model_type
from hfl.engine.selector import select_engine, select_tts_engine
from hfl.exceptions import (
    ModelNotFoundError,
    ModelNotReadyError,
    ModelTypeMismatchError,
)
from hfl.exceptions import (
    ValidationError as APIValidationError,
)
from hfl.models.registry import get_registry
from hfl.validators import ValidationError, validate_model_name

if TYPE_CHECKING:
    from hfl.engine.base import AudioEngine, InferenceEngine
    from hfl.models.manifest import ModelManifest

logger = logging.getLogger(__name__)


async def load_llm(model_name: str) -> tuple["InferenceEngine", "ModelManifest"]:
    """Load LLM model with proper async handling.

    This is the primary entry point for model loading in API routes.
    Handles validation, registry lookup, type checking, and loading.

    Args:
        model_name: Name, alias, or repo_id of the model

    Returns:
        Tuple of (InferenceEngine, ModelManifest)

    Raises:
        APIValidationError: For malformed model names (400).
        ModelNotFoundError: If the model is not in the registry (404).
        ModelTypeMismatchError: If a non-LLM model was requested (400).
        ModelNotReadyError: If the engine slot exists but is None (503).
    """
    # Validate input
    try:
        validate_model_name(model_name)
    except ValidationError as e:
        raise APIValidationError(str(e)) from e

    state = get_state()

    # Fast path - already loaded
    if state.current_model and state.current_model.name == model_name:
        if state.engine is None:
            raise ModelNotReadyError(model_name)
        return state.engine, state.current_model

    # Lookup in registry
    manifest = get_registry().get(model_name)
    if not manifest:
        raise ModelNotFoundError(model_name)

    # Verify model type
    model_path = Path(manifest.local_path)
    model_type = detect_model_type(model_path)
    if model_type != ModelType.LLM:
        raise ModelTypeMismatchError(model_name, expected="llm", got=model_type.value)

    # Load model in thread pool to avoid blocking event loop
    # context_size_override > 0 means explicit user override via --ctx flag
    # Otherwise pass 0 to let the engine auto-detect from model metadata
    n_ctx = state.context_size_override if state.context_size_override > 0 else 0
    engine = select_engine(model_path)
    try:
        await asyncio.to_thread(engine.load, manifest.local_path, n_ctx=n_ctx)
        await state.set_llm_engine(engine, manifest)
        return engine, manifest
    except Exception:
        # Cleanup engine if loading succeeded but state update failed
        if engine.is_loaded:
            try:
                await asyncio.to_thread(engine.unload)
            except Exception as cleanup_error:
                logger.error("Failed to cleanup engine after load error: %s", cleanup_error)
        raise


async def load_tts(model_name: str) -> tuple["AudioEngine", "ModelManifest"]:
    """Load TTS model with proper async handling.

    Args:
        model_name: Name, alias, or repo_id of the TTS model

    Returns:
        Tuple of (AudioEngine, ModelManifest)

    Raises:
        APIValidationError: For malformed model names (400).
        ModelNotFoundError: If the model is not in the registry (404).
        ModelTypeMismatchError: If a non-TTS model was requested (400).
        ModelNotReadyError: If the TTS engine slot exists but is None (503).
    """
    try:
        validate_model_name(model_name)
    except ValidationError as e:
        raise APIValidationError(str(e)) from e

    state = get_state()

    # Fast path
    if state.current_tts_model and state.current_tts_model.name == model_name:
        if state.tts_engine is None:
            raise ModelNotReadyError(model_name)
        return state.tts_engine, state.current_tts_model

    manifest = get_registry().get(model_name)
    if not manifest:
        raise ModelNotFoundError(model_name)

    model_path = Path(manifest.local_path)
    model_type = detect_model_type(model_path)
    if model_type != ModelType.TTS:
        raise ModelTypeMismatchError(model_name, expected="tts", got=model_type.value)

    # Load model in thread pool
    engine = select_tts_engine(model_path)
    try:
        await asyncio.to_thread(engine.load, manifest.local_path)
        await state.set_tts_engine(engine, manifest)
        return engine, manifest
    except Exception:
        # Cleanup engine if loading succeeded but state update failed
        if engine.is_loaded:
            try:
                await asyncio.to_thread(engine.unload)
            except Exception as cleanup_error:
                logger.error("Failed to cleanup TTS engine after load error: %s", cleanup_error)
        raise


def load_llm_sync(model_name: str) -> tuple["InferenceEngine", "ModelManifest"]:
    """Synchronous version of load_llm for CLI usage.

    Args:
        model_name: Name, alias, or repo_id of the model

    Returns:
        Tuple of (InferenceEngine, ModelManifest)

    Raises:
        ValueError: If model not found or type mismatch
    """
    validate_model_name(model_name)

    manifest = get_registry().get(model_name)
    if not manifest:
        raise ValueError(f"Model not found: {model_name}")

    model_path = Path(manifest.local_path)
    model_type = detect_model_type(model_path)
    if model_type != ModelType.LLM:
        raise ValueError(f"Expected LLM model, got {model_type.value}")

    engine = select_engine(model_path)
    # Phase 8 P3-2: pass LoRA adapter paths from the manifest
    # (populated by ``POST /api/create`` when a Modelfile declared
    # ``ADAPTER`` instructions). Engines that don't support LoRA
    # ignore the kwarg.
    load_kwargs: dict[str, Any] = {"n_ctx": manifest.context_length}
    if getattr(manifest, "adapter_paths", None):
        # ADAPTER paths come from a Modelfile via POST /api/create — untrusted.
        # Contain each to the HFL data dir so a manifest can't make the engine
        # read arbitrary files (e.g. ../../etc/passwd) as a "LoRA adapter".
        import hfl.config
        from hfl.security import PathTraversalError, sanitize_path

        base = hfl.config.config.home_dir
        safe_adapters: list[str] = []
        for adapter in manifest.adapter_paths:
            try:
                safe_adapters.append(str(sanitize_path(base, str(adapter))))
            except PathTraversalError as exc:
                raise ValueError(f"adapter path rejected: {exc}") from exc
        load_kwargs["lora_paths"] = safe_adapters
    engine.load(manifest.local_path, **load_kwargs)

    return engine, manifest
