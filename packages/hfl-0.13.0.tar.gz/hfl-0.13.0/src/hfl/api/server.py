# SPDX-License-Identifier: HRUL-1.0
# Copyright (c) 2026 Gabriel Galán Pelayo
"""
REST API server compatible with OpenAI, Ollama, and Anthropic.

Implemented endpoints:
  OpenAI:
    POST /v1/chat/completions
    POST /v1/completions
    GET  /v1/models

  Anthropic:
    POST /v1/messages

  Ollama-native:
    POST /api/generate
    POST /api/chat
    GET  /api/tags
    POST /api/pull
    DELETE /api/delete

Legal Compliance (R9 - Audit):
- Disclaimer header in all AI responses

Security:
- Optional API key authentication via --api-key flag
"""

import secrets
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any, Callable

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from starlette.middleware.base import BaseHTTPMiddleware

from hfl import __version__
from hfl.api.exception_handlers import register_exception_handlers
from hfl.api.middleware import RequestBodyLimitMiddleware, RequestLogger
from hfl.api.routes_anthropic import router as anthropic_router
from hfl.api.routes_batch import router as batch_router
from hfl.api.routes_benchmark import router as benchmark_router
from hfl.api.routes_blobs import router as blobs_router
from hfl.api.routes_compliance import router as compliance_router
from hfl.api.routes_copy import router as copy_router
from hfl.api.routes_create import router as create_router
from hfl.api.routes_discover import router as discover_router
from hfl.api.routes_draft import router as draft_router
from hfl.api.routes_embed import router as embed_router
from hfl.api.routes_health import router as health_router
from hfl.api.routes_images import router as images_router
from hfl.api.routes_lora import router as lora_router
from hfl.api.routes_metrics import router as metrics_router
from hfl.api.routes_native import router as native_router
from hfl.api.routes_openai import router as openai_router
from hfl.api.routes_openai_responses import router as openai_responses_router
from hfl.api.routes_ps import router as ps_router
from hfl.api.routes_pull import router as pull_router
from hfl.api.routes_push import router as push_router
from hfl.api.routes_recommend import router as recommend_router
from hfl.api.routes_show import router as show_router
from hfl.api.routes_smart_pull import router as smart_pull_router
from hfl.api.routes_snapshot import router as snapshot_router
from hfl.api.routes_stop import router as stop_router
from hfl.api.routes_transcribe import router as transcribe_router
from hfl.api.routes_tts import router as tts_router
from hfl.api.routes_verify import router as verify_router
from hfl.api.routes_web import router as web_router
from hfl.api.routes_ws import router as ws_router
from hfl.api.state import get_state
from hfl.config import config


# API Key Authentication Middleware
class APIKeyMiddleware(BaseHTTPMiddleware):
    """Middleware that validates API key if configured."""

    # Endpoints that don't require authentication (exact match).
    # /api/tags is intentionally kept out of the public set so auth policy
    # is deterministic (spec §5.1): when an API key is configured, /api/tags
    # always requires it, matching /api/chat.
    PUBLIC_ENDPOINTS = {"/", "/api/version", "/healthz"}

    # Path prefixes that don't require authentication
    PUBLIC_PREFIXES = ("/health", "/metrics")

    async def dispatch(self, request: Request, call_next: Callable[[Request], Any]) -> Response:
        state = get_state()

        # Skip auth if no API key is configured
        if not state.api_key:
            response: Response = await call_next(request)
            return response

        # Skip auth for public endpoints (exact match)
        if request.url.path in self.PUBLIC_ENDPOINTS:
            response = await call_next(request)
            return response

        # Skip auth for public prefixes (e.g., /health, /health/ready, /health/live)
        if request.url.path.startswith(self.PUBLIC_PREFIXES):
            response = await call_next(request)
            return response

        # Check for API key in Authorization header (Bearer token)
        # Use constant-time comparison to prevent timing attacks
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
            if secrets.compare_digest(token.encode(), state.api_key.encode()):
                response = await call_next(request)
                return response

        # Check for API key in X-API-Key header
        api_key_header = request.headers.get("X-API-Key", "")
        if api_key_header and secrets.compare_digest(
            api_key_header.encode(), state.api_key.encode()
        ):
            response = await call_next(request)
            return response

        # Authentication failed — return a structured envelope so clients
        # can decide retry policy without parsing prose (spec §5.4).
        return JSONResponse(
            status_code=401,
            content={
                "error": {
                    "error": "Invalid or missing API key",
                    "code": "UNAUTHORIZED",
                    "category": "auth",
                    "retryable": False,
                }
            },
            headers={"WWW-Authenticate": "Bearer"},
        )


# R9 - Disclaimer Middleware (Legal Audit)
# Adds disclaimer header to all AI responses
class DisclaimerMiddleware(BaseHTTPMiddleware):
    """Middleware that adds disclaimer to AI endpoint responses."""

    AI_ENDPOINTS = {
        # LLM endpoints
        "/v1/chat/completions",
        "/v1/completions",
        "/api/generate",
        "/api/chat",
        # Anthropic endpoints
        "/v1/messages",
        # TTS endpoints
        "/v1/audio/speech",
        "/api/tts",
    }

    async def dispatch(self, request: Request, call_next: Callable[[Request], Any]) -> Response:
        response: Response = await call_next(request)
        # Only add disclaimer to generation endpoints
        if request.url.path in self.AI_ENDPOINTS:
            response.headers["X-AI-Disclaimer"] = (
                "AI-generated content. May be inaccurate or inappropriate. "
                "User assumes all responsibility for use of outputs."
            )
        return response


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Server lifecycle."""
    yield
    # Cleanup on shutdown
    await get_state().cleanup()
    # Close HTTP clients
    from hfl.hub.client import close_async_hf_client, close_hf_client

    await close_async_hf_client()
    close_hf_client()


_openapi_tags = [
    {
        "name": "OpenAI",
        "description": ("OpenAI-compatible endpoints (chat completions, completions, models)"),
    },
    {
        "name": "Anthropic",
        "description": "Anthropic Messages API-compatible endpoints",
    },
    {"name": "Ollama", "description": "Ollama-compatible endpoints (generate, chat, tags)"},
    {"name": "TTS", "description": "Text-to-speech endpoints"},
    {"name": "Health", "description": "Health check and readiness probes"},
    {"name": "Metrics", "description": "Prometheus and JSON metrics"},
]

app = FastAPI(
    title="hfl API",
    description="OpenAI, Ollama, and Anthropic compatible API for HuggingFace models",
    version=__version__,
    lifespan=lifespan,
    openapi_tags=_openapi_tags,
)

# CORS - Configurable via config.py
# Use ["*"] if cors_allow_all is True, otherwise use explicit origins
_cors_origins = ["*"] if config.cors_allow_all else config.cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=config.cors_allow_credentials,
    allow_methods=config.cors_allow_methods,
    allow_headers=config.cors_allow_headers,
)

# R9 - Add disclaimer middleware
app.add_middleware(DisclaimerMiddleware)

# Middleware execution order (Starlette runs in reverse add order):
# RequestLogger → BodyLimit → APIKey → RateLimit → Disclaimer → CORS
# Body-limit runs before auth/rate-limit so oversized requests are
# rejected with 413 without consuming rate-limit tokens or touching
# auth; this matches the "reject early, reject cheap" principle.

# Optional rate limiting (after auth in execution order)
if config.rate_limit_enabled:
    from hfl.api.middleware import RateLimitMiddleware

    app.add_middleware(
        RateLimitMiddleware,
        requests_per_window=config.rate_limit_requests,
        window_seconds=config.rate_limit_window,
    )

# API key authentication (runs before rate limiting)
app.add_middleware(APIKeyMiddleware)

# Body-size limit (runs before auth so oversized bodies are rejected
# without consuming auth/rate-limit work). 0 disables the limit.
if config.max_request_bytes > 0:
    app.add_middleware(RequestBodyLimitMiddleware, max_bytes=config.max_request_bytes)

# Request logging and metrics recording (outermost - runs first)
app.add_middleware(RequestLogger)

# Register global exception handlers for HFLError hierarchy
register_exception_handlers(app)

app.include_router(anthropic_router)
app.include_router(openai_router)
app.include_router(openai_responses_router)
app.include_router(native_router)
app.include_router(batch_router)
app.include_router(blobs_router)
app.include_router(copy_router)
app.include_router(create_router)
app.include_router(embed_router)
app.include_router(ps_router)
app.include_router(pull_router)
app.include_router(push_router)
app.include_router(discover_router)
app.include_router(recommend_router)
app.include_router(smart_pull_router)
app.include_router(verify_router)
app.include_router(benchmark_router)
app.include_router(compliance_router)
app.include_router(ws_router)
app.include_router(snapshot_router)
app.include_router(lora_router)
app.include_router(draft_router)
app.include_router(show_router)
app.include_router(stop_router)
app.include_router(transcribe_router)
app.include_router(tts_router)
app.include_router(web_router)
app.include_router(health_router)
app.include_router(images_router)
app.include_router(metrics_router)


@app.get("/")
async def root() -> dict[str, str]:
    return {"status": "hfl is running"}


def start_server(
    host: str | None = None,
    port: int | None = None,
    api_key: str | None = None,
) -> None:
    """Start the API server.

    Args:
        host: Host address to bind (default: from config)
        port: Port number (default: from config)
        api_key: Optional API key for authentication. If set, all requests
                 must include either:
                 - Authorization: Bearer <api_key>
                 - X-API-Key: <api_key>
    """
    get_state().api_key = api_key
    uvicorn.run(
        app,
        host=host or config.host,
        port=port or config.port,
        log_level="info",
        timeout_graceful_shutdown=30,
    )
