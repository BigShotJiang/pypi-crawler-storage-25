# SPDX-License-Identifier: HRUL-1.0
# Copyright (c) 2026 Gabriel Galán Pelayo
"""
Centralized logging configuration for HFL.

Features:
- Structured JSON logging (optional)
- Request ID tracing
- Privacy-safe logging (no sensitive data)
- Configurable log levels
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone
from typing import Any

# Import unified tracing from core module
from hfl.core.tracing import get_request_id, set_request_id

# Re-export for backward compatibility
__all__ = [
    "get_request_id",
    "set_request_id",
    "configure_logging",
    "get_logger",
    "log_request",
    "log_model_load",
    "log_error",
]


class StructuredFormatter(logging.Formatter):
    """JSON structured log formatter for production use."""

    def format(self, record: logging.LogRecord) -> str:
        log_data: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Add request ID if available
        request_id = get_request_id()
        if request_id:
            log_data["request_id"] = request_id

        # Add extra fields from the record
        if hasattr(record, "method"):
            log_data["method"] = record.method
        if hasattr(record, "path"):
            log_data["path"] = record.path
        if hasattr(record, "status"):
            log_data["status"] = record.status
        if hasattr(record, "duration_ms"):
            log_data["duration_ms"] = record.duration_ms
        if hasattr(record, "model"):
            log_data["model"] = record.model

        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_data)


class PrettyFormatter(logging.Formatter):
    """Human-readable log formatter for development."""

    COLORS = {
        "DEBUG": "\033[36m",  # Cyan
        "INFO": "\033[32m",  # Green
        "WARNING": "\033[33m",  # Yellow
        "ERROR": "\033[31m",  # Red
        "CRITICAL": "\033[35m",  # Magenta
    }
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        # Get request ID
        request_id = get_request_id()
        rid_str = f"[{request_id}] " if request_id else ""

        # Color based on level
        color = self.COLORS.get(record.levelname, "")
        reset = self.RESET if color else ""

        # Format timestamp
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Build message
        msg = record.getMessage()

        # Add extra context
        extras = []
        if hasattr(record, "method"):
            extras.append(f"{record.method} {getattr(record, 'path', '')}")
        if hasattr(record, "status"):
            extras.append(f"status={record.status}")
        if hasattr(record, "duration_ms"):
            extras.append(f"duration={record.duration_ms:.1f}ms")
        if hasattr(record, "model"):
            extras.append(f"model={record.model}")

        extra_str = " ".join(extras)
        if extra_str:
            msg = f"{msg} | {extra_str}"

        formatted = f"{timestamp} {color}{record.levelname:8}{reset} {rid_str}{msg}"

        if record.exc_info:
            formatted += "\n" + self.formatException(record.exc_info)

        return formatted


def _resolve_debug_env() -> bool:
    """Read ``HFL_DEBUG`` / ``OLLAMA_DEBUG`` as a boolean.

    Either being truthy (``1``/``true``/``yes``/``on``,
    case-insensitive) flips the server logger to DEBUG. Empty / unset
    yields ``False`` so the explicit ``level=`` argument wins.
    """
    import os as _os

    raw = _os.environ.get("HFL_DEBUG") or _os.environ.get("OLLAMA_DEBUG") or ""
    return raw.strip().lower() in ("1", "true", "yes", "on")


def configure_logging(
    level: str = "INFO",
    json_format: bool = False,
    log_file: str | None = None,
) -> None:
    """Configure logging for the application.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
            Overridden to ``"DEBUG"`` when ``HFL_DEBUG`` (or its
            Ollama-equivalent ``OLLAMA_DEBUG``) is truthy.
        json_format: Use JSON structured logging (for production)
        log_file: Optional file path for file logging
    """
    # Env override: HFL_DEBUG / OLLAMA_DEBUG = 1 forces DEBUG, beating
    # any default ``level=`` the caller passed. An explicit
    # ``level="DEBUG"`` is a no-op (same outcome).
    if _resolve_debug_env():
        level = "DEBUG"

    # Get root logger for hfl
    logger = logging.getLogger("hfl")
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Clear existing handlers
    logger.handlers.clear()

    # Choose formatter
    formatter: logging.Formatter
    if json_format:
        formatter = StructuredFormatter()
    else:
        formatter = PrettyFormatter()

    # Console handler
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # File handler (optional)
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(StructuredFormatter())  # Always JSON for files
        logger.addHandler(file_handler)

    # Don't propagate to root logger
    logger.propagate = False


def get_logger(name: str = "hfl") -> logging.Logger:
    """Get a logger instance.

    Args:
        name: Logger name (defaults to 'hfl')

    Returns:
        Logger instance
    """
    return logging.getLogger(name)


# Convenience functions for common log operations
def log_request(
    method: str,
    path: str,
    status: int,
    duration_ms: float,
    model: str | None = None,
) -> None:
    """Log an API request with structured data.

    PRIVACY: This function only logs metadata, never request/response content.
    """
    logger = get_logger()
    extra: dict[str, Any] = {
        "method": method,
        "path": path,
        "status": status,
        "duration_ms": duration_ms,
    }
    if model:
        extra["model"] = model

    logger.info(
        "Request completed",
        extra=extra,
    )


def log_model_load(model_name: str, duration_ms: float) -> None:
    """Log model loading event."""
    logger = get_logger()
    logger.info(
        f"Model loaded: {model_name}",
        extra={"model": model_name, "duration_ms": duration_ms},
    )


def log_error(message: str, exc: Exception | None = None) -> None:
    """Log an error with optional exception."""
    logger = get_logger()
    logger.error(message, exc_info=exc is not None)
