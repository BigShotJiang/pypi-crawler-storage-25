import pytest

from engine_python_sdk.api.async_client import AsyncEngineClient


@pytest.mark.asyncio
async def test_async_client_relogin_once_and_retry_success() -> None:
    calls = {"n": 0}
    store = {"token": "expired-token"}

    async def get_token() -> str:
        return store["token"]

    async def login() -> None:
        store["token"] = "fresh-token"

    async def create_call(token: str) -> list[str]:
        calls["n"] += 1
        if calls["n"] == 1:
            return ["You don't have permission to access"]
        return []

    client = AsyncEngineClient(get_token=get_token, login=login)
    await client._execute_with_retry(create_call)

    assert calls["n"] == 2
    assert store["token"] == "fresh-token"
