from engine_python_sdk.api.sync_client import EngineClient


def test_sync_client_relogin_once_and_retry_success() -> None:
    calls = {"n": 0}
    store = {"token": "expired-token"}

    def get_token() -> str:
        return store["token"]

    def login() -> None:
        store["token"] = "fresh-token"

    def create_call(token: str) -> list[str]:
        calls["n"] += 1
        if calls["n"] == 1:
            return ["User isn't authenticated"]
        return []

    client = EngineClient(get_token=get_token, login=login)
    client._execute_with_retry(create_call)

    assert calls["n"] == 2
    assert store["token"] == "fresh-token"
