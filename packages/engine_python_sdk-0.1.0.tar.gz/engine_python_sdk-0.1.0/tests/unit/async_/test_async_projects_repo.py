import pytest

from engine_python_sdk.async_.projects_repo import AsyncProjectsRepository


@pytest.mark.asyncio
async def test_async_projects_list_uses_projects_endpoint() -> None:
    called = {}

    async def fake_execute(*, path: str, query: str, variables: dict, token: str | None = None) -> tuple[dict, list[str]]:
        called["path"] = path
        return ({"project": {"list": {"data": [], "limit": 20, "offset": 0}}}, [])

    repo = AsyncProjectsRepository(execute=fake_execute)
    await repo.list_projects(token="t", offset=0, limit=20, name="ACOMS")

    assert called["path"] == "/graphql/projects"


@pytest.mark.asyncio
async def test_async_update_account_project_uses_projects_endpoint() -> None:
    called = {}

    async def fake_execute(*, path: str, query: str, variables: dict, token: str | None = None) -> tuple[dict, list[str]]:
        called["path"] = path
        return ({"projectMutation": {"accountProject": {"success": True}}}, [])

    repo = AsyncProjectsRepository(execute=fake_execute)
    await repo.update_account_project(token="t", account_id=1001, project_uid="11111111-2222-3333-4444-555555555555")

    assert called["path"] == "/graphql/projects"
