from engine_python_sdk import __version__


def test_package_imports_version() -> None:
    assert isinstance(__version__, str)
    assert __version__
