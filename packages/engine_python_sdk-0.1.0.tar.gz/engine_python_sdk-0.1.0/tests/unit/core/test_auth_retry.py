import pytest

from engine_python_sdk.core.auth_retry import should_relogin, execute_with_auth_retry_sync, execute_with_auth_retry_async
from engine_python_sdk.core.errors import GraphQLRequestError, PermissionDeniedError


def test_should_relogin_matches_permission_message() -> None:
    assert should_relogin(["You don't have permission to access"])


def test_should_not_relogin_on_non_auth_message() -> None:
    assert not should_relogin(["validation failed"])


def test_sync_retries_once_on_auth_error() -> None:
    calls = {"n": 0}

    def get_token() -> str:
        return "token"

    def login() -> None:
        return None

    def call(token: str) -> list[str]:
        calls["n"] += 1
        if calls["n"] == 1:
            return ["User isn't authenticated"]
        return []

    execute_with_auth_retry_sync(get_token, login, call)
    assert calls["n"] == 2


def test_sync_non_auth_error_no_relogin() -> None:
    calls = {"n": 0}

    def get_token() -> str:
        return "token"

    def login() -> None:
        raise AssertionError("login should not be called")

    def call(token: str) -> list[str]:
        calls["n"] += 1
        return ["validation failed"]

    with pytest.raises(GraphQLRequestError):
        execute_with_auth_retry_sync(get_token, login, call)

    assert calls["n"] == 1


@pytest.mark.asyncio
async def test_async_retries_once_on_auth_error() -> None:
    calls = {"n": 0}

    async def get_token() -> str:
        return "token"

    async def login() -> None:
        return None

    async def call(token: str) -> list[str]:
        calls["n"] += 1
        if calls["n"] == 1:
            return ["You don't have permission to access"]
        return []

    await execute_with_auth_retry_async(get_token, login, call)
    assert calls["n"] == 2


@pytest.mark.asyncio
async def test_async_permission_denied_after_retry() -> None:
    async def get_token() -> str:
        return "token"

    async def login() -> None:
        return None

    async def call(token: str) -> list[str]:
        return ["User isn't authenticated"]

    with pytest.raises(PermissionDeniedError):
        await execute_with_auth_retry_async(get_token, login, call)
