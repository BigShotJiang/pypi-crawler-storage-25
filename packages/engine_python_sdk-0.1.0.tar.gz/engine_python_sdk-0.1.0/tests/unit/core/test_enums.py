from engine_python_sdk.core.enums import AccountPlatform


def test_account_platform_enum_value() -> None:
    assert AccountPlatform.FACEBOOK.value == "FACEBOOK"
