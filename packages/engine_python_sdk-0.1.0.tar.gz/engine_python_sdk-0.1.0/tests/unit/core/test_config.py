import pytest

from engine_python_sdk.config import load_env_config
from engine_python_sdk.core.errors import ConfigError


def test_load_env_rejects_base_url_with_path(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ENGINE_BASE_URL", "https://example.com/graphql")
    monkeypatch.setenv("ENGINE_USERNAME", "u")
    monkeypatch.setenv("ENGINE_PASSWORD", "p")

    with pytest.raises(ConfigError):
        load_env_config()


def test_load_env_accepts_base_url_without_path(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ENGINE_BASE_URL", "https://example.com:8443")
    monkeypatch.setenv("ENGINE_USERNAME", "u")
    monkeypatch.setenv("ENGINE_PASSWORD", "p")

    cfg = load_env_config()
    assert cfg.base_url == "https://example.com:8443"
