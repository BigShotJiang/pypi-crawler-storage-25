from engine_python_sdk.sync.projects_repo import ProjectsRepository


def test_projects_list_uses_projects_endpoint() -> None:
    called = {}

    def fake_execute(*, path: str, query: str, variables: dict, token: str | None = None) -> tuple[dict, list[str]]:
        called["path"] = path
        return ({"project": {"list": {"data": [], "limit": 20, "offset": 0}}}, [])

    repo = ProjectsRepository(execute=fake_execute)
    repo.list_projects(token="t", offset=0, limit=20, name="ACOMS")

    assert called["path"] == "/graphql/projects"


def test_update_account_project_uses_projects_endpoint() -> None:
    called = {}

    def fake_execute(*, path: str, query: str, variables: dict, token: str | None = None) -> tuple[dict, list[str]]:
        called["path"] = path
        return ({"projectMutation": {"accountProject": {"success": True}}}, [])

    repo = ProjectsRepository(execute=fake_execute)
    repo.update_account_project(token="t", account_id=1001, project_uid="11111111-2222-3333-4444-555555555555")

    assert called["path"] == "/graphql/projects"
