from collections.abc import Callable

from engine_python_sdk.core.auth_retry import execute_with_auth_retry_sync


class EngineClient:
    def __init__(
        self,
        *,
        get_token: Callable[[], str],
        login: Callable[[], None],
    ) -> None:
        self._get_token = get_token
        self._login = login

    def _execute_with_retry(self, call: Callable[[str], list[str]]) -> None:
        execute_with_auth_retry_sync(self._get_token, self._login, call)
