from collections.abc import Awaitable, Callable

from engine_python_sdk.core.auth_retry import execute_with_auth_retry_async


class AsyncEngineClient:
    def __init__(
        self,
        *,
        get_token: Callable[[], Awaitable[str]],
        login: Callable[[], Awaitable[None]],
    ) -> None:
        self._get_token = get_token
        self._login = login

    async def _execute_with_retry(self, call: Callable[[str], Awaitable[list[str]]]) -> None:
        await execute_with_auth_retry_async(self._get_token, self._login, call)
