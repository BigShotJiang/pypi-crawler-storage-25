from dataclasses import dataclass
from typing import Any

import httpx

from engine_python_sdk.core.errors import InvalidResponseError, TransportError


@dataclass(slots=True)
class AsyncTransportConfig:
    base_url: str
    timeout: float = 30.0
    proxy: str | None = None


class AsyncGraphQLTransport:
    def __init__(self, config: AsyncTransportConfig) -> None:
        self._config = config
        self._client = httpx.AsyncClient(
            base_url=config.base_url,
            timeout=config.timeout,
            proxy=config.proxy,
        )

    async def execute(
        self,
        *,
        path: str,
        query: str,
        variables: dict[str, Any],
        token: str | None = None,
    ) -> tuple[dict[str, Any], list[str]]:
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        payload = {"query": query, "variables": variables}

        try:
            response = await self._client.post(path, headers=headers, json=payload)
            response.raise_for_status()
        except Exception as exc:  # noqa: BLE001
            raise TransportError(str(exc)) from exc

        try:
            body = response.json()
        except Exception as exc:  # noqa: BLE001
            raise InvalidResponseError("invalid json response") from exc

        data = body.get("data") if isinstance(body, dict) else None
        errors = body.get("errors", []) if isinstance(body, dict) else []
        messages = [err.get("message", "") for err in errors if isinstance(err, dict)]

        if data is None:
            data = {}

        return data, messages

    async def close(self) -> None:
        await self._client.aclose()
