from dataclasses import dataclass
from urllib.parse import urlparse
import os

from engine_python_sdk.core.errors import ConfigError


@dataclass(slots=True)
class EnvConfig:
    base_url: str
    username: str
    password: str


def load_env_config() -> EnvConfig:
    base_url = os.getenv("ENGINE_BASE_URL", "").strip()
    username = os.getenv("ENGINE_USERNAME", "").strip()
    password = os.getenv("ENGINE_PASSWORD", "")

    if not base_url or not username or not password:
        raise ConfigError("missing required engine environment variables")

    parsed = urlparse(base_url)
    if not parsed.scheme or not parsed.netloc:
        raise ConfigError("ENGINE_BASE_URL must include scheme and host")

    if parsed.path not in ("", "/"):
        raise ConfigError("ENGINE_BASE_URL must not include path")

    return EnvConfig(base_url=base_url, username=username, password=password)
