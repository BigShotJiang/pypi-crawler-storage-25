from typing import Any, Callable


class ProjectsRepository:
    def __init__(
        self,
        *,
        execute: Callable[..., tuple[dict[str, Any], list[str]]],
    ) -> None:
        self._execute = execute

    def list_projects(
        self,
        *,
        token: str,
        offset: int,
        limit: int,
        name: str | None = None,
    ) -> tuple[dict[str, Any], list[str]]:
        query = (
            "query ListProjects($pagination: Pagination, $filters: ProjectFilters) { "
            "project { list(pagination: $pagination, filters: $filters) { "
            "data { uid name description createdAt updatedAt } limit offset } } }"
        )
        variables: dict[str, Any] = {
            "pagination": {"offset": offset, "limit": limit},
            "filters": {"name": name} if name is not None else {},
        }
        return self._execute(
            path="/graphql/projects",
            query=query,
            variables=variables,
            token=token,
        )

    def update_account_project(
        self,
        *,
        token: str,
        account_id: int,
        project_uid: str,
    ) -> tuple[dict[str, Any], list[str]]:
        query = (
            "mutation UpdateAccountProject($accountId: Int!, $projectUid: UUID!) { "
            "projectMutation { accountProject(accountId: $accountId, projectUid: $projectUid) { "
            "success message detail } } }"
        )
        variables = {"accountId": account_id, "projectUid": project_uid}
        return self._execute(
            path="/graphql/projects",
            query=query,
            variables=variables,
            token=token,
        )
