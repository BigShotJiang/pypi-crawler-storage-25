from enum import StrEnum


class AccountPlatform(StrEnum):
    FACEBOOK = "FACEBOOK"
    TIKTOK = "TIKTOK"
    TWITTER = "TWITTER"
    YOUTUBE = "YOUTUBE"
    HOTMAIL = "HOTMAIL"
    OTHER = "OTHER"


class DevicePlatform(StrEnum):
    IOS = "IOS"
    ANDROID = "ANDROID"
    CHROME = "CHROME"
    FIREFOX = "FIREFOX"


class AccountTarget(StrEnum):
    COACHING = "COACHING"
    ATTACKING = "ATTACKING"
    MONITOR = "MONITOR"
    COLLECT = "COLLECT"


class AccountStatus(StrEnum):
    IDLE = "idle"
    DIE = "die"
    BLOCKED = "blocked"
    RUNNING = "running"


class Gender(StrEnum):
    MALE = "male"
    FEMALE = "female"
    OTHER = "other"


class AgeType(StrEnum):
    YEAR = "year"
    MONTH = "month"
    NONE = "None"


class FilterOperator(StrEnum):
    EQ = "="
    GT = ">"
    LT = "<"
    GE = ">="
    LE = "<="
