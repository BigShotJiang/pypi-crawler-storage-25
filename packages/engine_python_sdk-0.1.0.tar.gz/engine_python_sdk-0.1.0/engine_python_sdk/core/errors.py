class SDKError(Exception):
    pass


class ConfigError(SDKError):
    pass


class AuthenticationRequiredError(SDKError):
    pass


class AuthenticationFailedError(SDKError):
    pass


class PermissionDeniedError(SDKError):
    pass


class GraphQLRequestError(SDKError):
    pass


class TransportError(SDKError):
    pass


class InvalidResponseError(SDKError):
    pass
