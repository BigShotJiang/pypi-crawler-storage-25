from collections.abc import Awaitable, Callable

from engine_python_sdk.core.errors import GraphQLRequestError, PermissionDeniedError

AUTH_MESSAGES = {
    "You don't have permission to access",
    "User isn't authenticated",
}


def should_relogin(messages: list[str]) -> bool:
    return any(message in AUTH_MESSAGES for message in messages)


def execute_with_auth_retry_sync(
    get_token: Callable[[], str],
    login: Callable[[], None],
    call: Callable[[str], list[str]],
) -> None:
    token = get_token()
    messages = call(token)

    if not messages:
        return

    if not should_relogin(messages):
        raise GraphQLRequestError("graphql request failed")

    login()
    token = get_token()
    messages = call(token)

    if not messages:
        return

    if should_relogin(messages):
        raise PermissionDeniedError("permission denied after retry")

    raise GraphQLRequestError("graphql request failed")


async def execute_with_auth_retry_async(
    get_token: Callable[[], Awaitable[str]],
    login: Callable[[], Awaitable[None]],
    call: Callable[[str], Awaitable[list[str]]],
) -> None:
    token = await get_token()
    messages = await call(token)

    if not messages:
        return

    if not should_relogin(messages):
        raise GraphQLRequestError("graphql request failed")

    await login()
    token = await get_token()
    messages = await call(token)

    if not messages:
        return

    if should_relogin(messages):
        raise PermissionDeniedError("permission denied after retry")

    raise GraphQLRequestError("graphql request failed")
