# engine-python-sdk

Python SDK for Engine GraphQL APIs with sync + async support.

## Highlights

- Dual-mode clients (sync + async)
- Strict one-time auth retry behavior
- Projects support on `/graphql/projects`
- Proxy/SOCKS capable transport using `httpx`
- PyPI-ready packaging (`hatchling`)

## Install

```bash
pip install engine-python-sdk
```

## Dev setup

```bash
python -m venv .venv
.venv/Scripts/python.exe -m pip install -r requirements-dev.txt
.venv/Scripts/python.exe -m pip install -e .
```

## Test

```bash
.venv/Scripts/pytest.exe -v
```

See docs:
- `docs/api-contract.md`
- `docs/integration-guide.md`
- `docs/publish-guide.md`
