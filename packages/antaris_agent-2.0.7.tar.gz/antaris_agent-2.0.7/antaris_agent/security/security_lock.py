"""Security lock — prevents unauthorized security level downgrading."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import platform
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class LockConfig:
    """Security lock configuration."""
    enabled: bool = False
    min_level: int = 0          # Floor level (0-4)
    auth: str = "none"          # "passphrase" | "pin" | "none"
    passphrase_hash: str = ""   # SHA-256 of passphrase (if auth=passphrase)
    pin_hash: str = ""          # SHA-256 of PIN (if auth=pin)
    
    def to_dict(self) -> dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, d: dict) -> "LockConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class SecurityLock:
    """Manages security level lock with integrity verification."""
    
    def __init__(self, config_path: Optional[Path] = None):
        self._config_path = config_path or (Path.home() / ".antarisbot")
        self._lock_config = LockConfig()
    
    @property
    def is_locked(self) -> bool:
        return self._lock_config.enabled
    
    @property
    def min_level(self) -> int:
        return self._lock_config.min_level if self._lock_config.enabled else 0
    
    @property
    def auth_method(self) -> str:
        return self._lock_config.auth
    
    def load(self, lock_dict: dict) -> None:
        """Load lock config from a dict (e.g., from config.json security.lock section)."""
        self._lock_config = LockConfig.from_dict(lock_dict)
    
    def set_lock(self, min_level: int, auth: str = "none", passphrase: str = "", pin: str = "") -> bool:
        """Set a security lock. Returns True on success."""
        if min_level < 0 or min_level > 4:
            logger.error("Invalid lock level: %d", min_level)
            return False
        if auth not in ("none", "passphrase", "pin"):
            logger.error("Invalid auth method: %s", auth)
            return False
        if auth == "passphrase" and not passphrase:
            logger.error("Passphrase required for passphrase auth")
            return False
        if auth == "pin" and not pin:
            logger.error("PIN required for pin auth")
            return False
        
        self._lock_config = LockConfig(
            enabled=True,
            min_level=min_level,
            auth=auth,
            passphrase_hash=hashlib.sha256(passphrase.encode()).hexdigest() if passphrase else "",
            pin_hash=hashlib.sha256(pin.encode()).hexdigest() if pin else "",
        )
        self._write_integrity()
        logger.info("Security lock set: min_level=%d, auth=%s", min_level, auth)
        return True
    
    def check_downgrade(self, current_level: int, target_level: int) -> tuple[bool, str]:
        """Check if a security level change is allowed.
        
        Returns (allowed, message).
        - If not locked or target >= min_level: (True, "")
        - If locked with auth=none: (False, "locked permanently") 
        - If locked with auth: (False, "authentication required")
        """
        if not self._lock_config.enabled:
            return True, ""
        
        # Escalation always allowed
        if target_level >= current_level:
            return True, ""
        
        # Target above or equal to floor: allowed
        if target_level >= self._lock_config.min_level:
            return True, ""
        
        # Below floor
        if self._lock_config.auth == "none":
            return False, f"Security lock active. Level cannot drop below {self._lock_config.min_level}. This deployment is permanently locked."
        else:
            return False, f"Security lock active. Authentication required to drop below level {self._lock_config.min_level}."
    
    def bypass_lock(self, passphrase: str = "", pin: str = "") -> bool:
        """Attempt to bypass the lock with credentials. Returns True on success."""
        if not self._lock_config.enabled:
            return True
        
        if self._lock_config.auth == "none":
            return False  # Hard lock, cannot bypass
        
        if self._lock_config.auth == "passphrase":
            return hmac.compare_digest(
                hashlib.sha256(passphrase.encode()).hexdigest(),
                self._lock_config.passphrase_hash
            )
        
        if self._lock_config.auth == "pin":
            return hmac.compare_digest(
                hashlib.sha256(pin.encode()).hexdigest(),
                self._lock_config.pin_hash
            )
        
        return False
    
    def disable_lock(self, passphrase: str = "", pin: str = "") -> bool:
        """Disable the lock. Requires correct credentials."""
        if not self._lock_config.enabled:
            return True
        
        if self._lock_config.auth == "none":
            logger.warning("Cannot disable hard lock (auth=none)")
            return False
        
        if not self.bypass_lock(passphrase=passphrase, pin=pin):
            logger.warning("Lock disable failed: wrong credentials")
            return False
        
        self._lock_config = LockConfig()  # Reset to defaults (disabled)
        self._remove_integrity()
        logger.info("Security lock disabled")
        return True
    
    def verify_integrity(self, lock_dict: dict) -> bool:
        """Verify config integrity against stored HMAC. 
        
        Returns True if:
        - No integrity file exists (fresh install, no lock)
        - Integrity file exists and HMAC matches
        
        Returns False if:
        - Integrity file exists but HMAC doesn't match (tampering)
        - Integrity file missing but lock is enabled in config (file deleted)
        """
        integrity_path = self._config_path / ".lock_integrity"
        
        if not integrity_path.exists():
            # No integrity file
            if lock_dict.get("enabled", False):
                # Lock in config but no integrity file = tampered
                logger.error("Lock config present but integrity file missing — possible tampering")
                return False
            return True  # No lock, no integrity file = fine
        
        # Integrity file exists — verify
        try:
            stored_hmac = integrity_path.read_text().strip()
            computed_hmac = self._compute_hmac(lock_dict)
            if not hmac.compare_digest(stored_hmac, computed_hmac):
                logger.error("Lock integrity check FAILED — config has been tampered")
                return False
            return True
        except Exception as e:
            logger.error("Integrity verification error: %s", e)
            return False
    
    def _write_integrity(self) -> None:
        """Write HMAC of current lock config to integrity file."""
        integrity_path = self._config_path / ".lock_integrity"
        integrity_path.parent.mkdir(parents=True, exist_ok=True)
        hmac_value = self._compute_hmac(self._lock_config.to_dict())
        integrity_path.write_text(hmac_value)
    
    def _remove_integrity(self) -> None:
        """Remove integrity file when lock is disabled."""
        integrity_path = self._config_path / ".lock_integrity"
        if integrity_path.exists():
            integrity_path.unlink()
    
    def _compute_hmac(self, lock_dict: dict) -> str:
        """Compute HMAC-SHA256 of lock config using machine ID as key."""
        machine_id = self._get_machine_id()
        config_json = json.dumps(lock_dict, sort_keys=True)
        return hmac.new(
            machine_id.encode(),
            config_json.encode(),
            hashlib.sha256
        ).hexdigest()
    
    def _get_machine_id(self) -> str:
        """Get a machine-specific identifier for HMAC key derivation.

        Uses hostname + OS + arch + MAC address. If all platform calls fail,
        falls back to a per-install UUID stored in the config dir so the key
        remains unique (but no longer tied to hardware).
        """
        try:
            parts = [
                platform.node(),      # hostname
                platform.system(),    # OS
                platform.machine(),   # arch
                str(uuid.getnode()),  # MAC address as int
            ]
            return hashlib.sha256(":".join(parts).encode()).hexdigest()
        except Exception:
            # Fallback: generate and persist a random per-install ID
            fallback_path = self._config_path / ".machine_id"
            try:
                if fallback_path.exists():
                    return fallback_path.read_text().strip()
                machine_id = str(uuid.uuid4())
                fallback_path.parent.mkdir(parents=True, exist_ok=True)
                fallback_path.write_text(machine_id)
                logger.warning("Platform ID unavailable; using per-install fallback machine ID")
                return machine_id
            except Exception:
                # Absolute last resort — static but logged
                logger.error("Cannot derive or persist machine ID; lock integrity is weakened")
                return "fallback-machine-id-INSECURE"
    
    def get_status(self) -> dict:
        """Return lock status as a dict."""
        return {
            "enabled": self._lock_config.enabled,
            "min_level": self._lock_config.min_level,
            "auth": self._lock_config.auth,
            "has_passphrase": bool(self._lock_config.passphrase_hash),
            "has_pin": bool(self._lock_config.pin_hash),
        }