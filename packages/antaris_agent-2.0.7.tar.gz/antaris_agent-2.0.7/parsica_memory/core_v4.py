"""
MemorySystem — Production-ready memory system with sharding, BM25 search, and concurrency safety.

Features:
- Sharded storage for scalability (10K+ memories)
- BM25-inspired search with IDF weighting and field boosting
- File locking and optimistic conflict detection
- Fast indexes (full-text, tags, dates)
- Schema migration with backward compatibility

Usage:
    from parsica_memory import MemorySystem

    mem = MemorySystem("./workspace")
    mem.load()
    mem.ingest("Key decision", source="meeting", category="strategic")
    results = mem.search("decision")
    mem.save()  # Saves to sharded format
"""

import json
import logging
import os
import re
import time
from collections import defaultdict

logger = logging.getLogger("parsica_memory")

# v4.6.6 — Pre-ingest metadata junk filter
# Rejects lines that look like raw JSON key-value pairs (from Discord metadata
# blocks that slipped through the plugin's stripContextPacket) or structural
# JSON tokens. These are never meaningful memories.
#   Matches:  "message_id": "1234"
#             "conversation_label": "Guild #..."
#             "sender_id": "276...",
#             { / } / [ / ]  standing alone
_METADATA_LINE_RE = re.compile(
    r'^\d*\.?\s*"(?:conversation_label|sender_id|sender|message_id|group_subject|group_channel|'
    r'group_space|was_mentioned|has_reply_context|has_forwarded_context|has_thread_starter|'
    r'history_count|chat_id|channel|provider|surface|chat_type|schema|flags)"'
    r'|^HEARTBEAT_OK$|^NO_REPLY$'
    r'|^[{\[\]},]$'                                     # bare JSON structural tokens
    r'|^\s*"[a-z_]{2,40}"\s*:\s*'                     # JSON key-value lines "key": ...
    r'|^<!--.*-->$'                                     # HTML comment markers
    r'|^\s*```[a-z]*\s*$'                              # fenced code block delimiters
    r'|^\s*\*\(from:\s*[\w:]+\)\*\s*$'                # context packet source tags
    r'|^Packet built \d{4}-\d{2}-\d{2}'               # context packet timestamp lines
    r'|^\[Queued messages while agent was busy\]\s*$'  # OpenClaw queued message banner
    r'|^Queued #\d+\s*$'                               # queued message index lines
    r'|^\s*-{3,}\s*$'                                  # horizontal rule separators
    r'|^\[System Message\]'                             # system message lines
    r'|^Reasoning:\s*$',                               # bare reasoning labels
    re.IGNORECASE
)

# v4.9.9 — Code line detection for ingest quality filtering
_CODE_LINE_RE = re.compile(
    r'^\s{4,}\S'                    # 4+ space indented code
    r'|^export\s+\w+='             # env var exports
    r'|^[A-Z_]{3,}=\S'            # ALL_CAPS=value assignments
    r'|^\$\s'                       # shell prompt lines
    r'|^>>>\s'                      # Python REPL lines
    r'|^\s*import\s+\w'            # import statements
    r'|^\s*from\s+\w+\s+import'   # from X import Y
    r'|^\s*def\s+\w+\('           # function definitions
    r'|^\s*class\s+\w+[:\(]'      # class definitions
)

# v4.9.9 — Credential detection for security filtering
_CREDENTIAL_RE = re.compile(
    r'sk-ant-api\d{2}-\w{20,}'      # Anthropic API keys
    r'|sk-proj-\w{20,}'             # OpenAI API keys  
    r'|hf_\w{20,}'                  # HuggingFace tokens
    r'|eyJ[A-Za-z0-9_-]{50,}'       # JWT tokens (base64-encoded JSON)
    r'|ghp_\w{20,}'                 # GitHub personal tokens
    r'|ghu_\w{20,}'                 # GitHub user tokens
    r'|MTQ\w{20,}\.\w{5,}\.\w{20,}' # Discord bot tokens
    r'|Bearer\s+\w{20,}'            # Bearer tokens
    r'|token[=:]\s*\w{30,}'         # Generic token assignments
    r'|password[=:]\s*\S{8,}'       # Password assignments
    r'|PRIVATE.KEY'                  # Private key markers
)

# v5.0.2 — Conversation noise filter for agent memory quality.
# Matches short acknowledgments, status messages, and flow-control phrases
# that are conversational but carry no knowledge worth remembering.
# Applied only to pipeline/agent_turn sources (not user-typed memories).
_CONVERSATION_NOISE_RE = re.compile(
    r'^(?:OUTPUT:\s*)?(?:'
    r'(?:Understood|Got it|On it|Sure|OK|Ready|Done|Noted|Will do|Perfect|'
    r'Sounds good|Absolutely|Alright|Acknowledged|Affirmative|Roger|Copy that|'
    r'No problem|Of course|Certainly|Definitely|Right away|'
    r'Let me (?:check|look|see|think|work)|'
    r'I\'ll (?:check|look|handle|work|take|get)|'
    r'Looking (?:into|at)|Checking (?:now|that)|Starting (?:now|on)|'
    r'Working on (?:it|that|this)|Running (?:now|that))\b'
    r'|^(?:Turn:\s*)?<@\d+>\s*.{0,15}$'     # bare mentions with <=15 chars after
    r'|^\[\[reply_to_current\]\]'            # reply markers
    r'|^HEARTBEAT_OK$'
    r'|^NO_REPLY$'
    r')',
    re.IGNORECASE
)

# v5.0.2 — Turn/INPUT/OUTPUT prefix stripping for content normalization.
# When checking for duplicates, the same message stored as "Turn: X",
# "INPUT: X", and "OUTPUT: X" should be treated as one memory, not three.
_TURN_PREFIX_RE = re.compile(r'^(?:Turn|INPUT|OUTPUT|System):\s*')

# v5.4.0 — stopwords for fact dedup inverted index
# Common words that appear in almost every fact — excluded to keep candidate sets lean
_FACT_DEDUP_STOPWORDS: frozenset = frozenset({
    "a", "an", "the", "is", "it", "in", "on", "at", "to", "of",
    "and", "or", "but", "for", "with", "was", "are", "be", "as",
    "by", "has", "had", "not", "from", "this", "that", "its"
})

import copy
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from .entry import MemoryEntry
from .decay import DecayEngine
from .sentiment import SentimentTagger
from .temporal import TemporalEngine
from .confidence import ConfidenceEngine
from .compression import CompressionEngine
from .forgetting import ForgettingEngine
from .consolidation import ConsolidationEngine
from .gating import InputGate
from .synthesis import KnowledgeSynthesizer
from .sharding import ShardManager
from .migration import MigrationManager
# v4.6.0: Incremental Index Loading + Time-Window Shard Splitting
from .wal import WALWriter, WALReader
from .shards import ShardManager as TimeShardManager
from .migrate import migrate_to_shards as _migrate_to_shards
from .indexing import IndexManager
from .search import SearchEngine, SearchResult
from .archive import ConversationArchive
from .context_packet import ContextPacket, ContextPacketBuilder
from .proactive import ProactiveMemory
from .export import export_memories, export_archive
from .namespace import NamespaceManager
from .memory_types import (
    MEMORY_TYPE_CONFIGS, DEFAULT_TYPE, get_type_config,
    format_mistake_content, SEVERITY_LEVELS,
)
from .utils import atomic_write_json
from .performance import ReadCache, WALManager, PerformanceMonitor, AccessTracker
from .shared import SharedMemoryPool
from .category_tagger import CategoryTagger

# Module-level CategoryTagger singleton — shared across all ingest paths
_ct = CategoryTagger()

# Default tags to auto-extract
_DEFAULT_TAG_TERMS = [
    "web3", "ethereum", "postgresql", "optimization", "cost",
    "revenue", "security", "deployment", "production", "testing",
]


class SemanticExpander:
    """Query expansion using a domain-specific word embedding lookup.

    Loads ``parsica_memory/data/word_expansion.json`` at init (zero runtime
    dependency).  The index is derived from pre-computed MiniLM document
    embeddings: for each word, its embedding is the centroid of all document
    embeddings containing that word.  Nearest neighbours are found via cosine
    similarity — so expansions are grounded in *this agent's actual memory
    corpus*, not a generic dictionary.

    "memory" → memories, memory_system, store, persisted  (not RAM/cache)
    "search" → retrieval, recall, queries, indexing
    "error"  → debugging, failure, fail, bug

    Only neighbours with cosine similarity >= MIN_SIM are used, sorted by
    score so the highest-quality expansions are added first.

    Falls back silently to no-op if the file is missing (e.g. first install
    before the build step has been run).

    Example::

        expander = SemanticExpander()
        expander.expand("memory recall degraded")
        # → "memory recall degraded memories retrieval search queries"
    """

    # Maximum extra tokens to append per query (prevents index bloat)
    _MAX_EXTRA_TOKENS = 5
    # Only use neighbours with cosine similarity >= this threshold
    _MIN_SIM = 0.87
    # Tokens shorter than this are skipped during lookup
    _MIN_TOKEN_LEN = 4

    def __init__(self, index_path: Optional[str] = None) -> None:
        if index_path is None:
            index_path = os.path.join(
                os.path.dirname(__file__), "data", "word_expansion.json"
            )
        # _index: {word: [(neighbour, score), ...]} sorted by score desc
        self._index: dict = {}
        try:
            if os.path.exists(index_path):
                with open(index_path, encoding="utf-8") as f:
                    raw = json.load(f)
                expansions = raw.get("expansions", raw)  # support both formats
                # Filter to only high-confidence neighbours
                for word, neighbours in expansions.items():
                    if not neighbours:
                        continue
                    # Detect format: list-of-pairs [[n, s], ...] vs plain strings [n, ...]
                    sample = neighbours[0]
                    if isinstance(sample, (list, tuple)) and len(sample) == 2:
                        # Scored format: [[neighbour, score], ...]
                        filtered = [
                            (n, s) for n, s in neighbours
                            if s >= self._MIN_SIM
                        ]
                    else:
                        # Plain string list (pre-filtered by build step)
                        filtered = [(n, 1.0) for n in neighbours]
                    if filtered:
                        self._index[word] = filtered  # already sorted by score desc
        except Exception as e:
            import sys as _sys
            print(f"[parsica-memory] WARNING: word_expansion.json load failed: {e}", file=_sys.stderr)
            # _index stays empty, expansion disabled silently but now observable

    def expand(self, query: str) -> str:
        """Return query augmented with semantically related terms.

        Original query terms are preserved and weighted naturally by BM25
        (they appear once).  Expanded terms are appended once — BM25 TF-IDF
        will score them lower than exact matches, which is the desired behaviour.
        Expansion uses corpus-derived word embeddings so domain semantics are
        respected (agent memory vocabulary, not general English).
        """
        if not self._index:
            return query
        tokens = re.findall(r"[a-zA-Z][a-zA-Z0-9_'-]{%d,}" % (self._MIN_TOKEN_LEN - 1),
                            query.lower())
        extras: list = []
        seen = set(query.lower().split())
        for tok in tokens:
            # neighbours are [(word, score), ...] sorted by score desc
            for neighbour, _score in self._index.get(tok, []):
                if neighbour not in seen and len(extras) < self._MAX_EXTRA_TOKENS:
                    extras.append(neighbour)
                    seen.add(neighbour)
        if extras:
            return query + " " + " ".join(extras)
        return query

    def __bool__(self) -> bool:
        return bool(self._index)

    def __len__(self) -> int:
        return len(self._index)


def _jaccard_similarity(text_a: str, text_b: str) -> float:
    """Word-level Jaccard similarity between two strings.
    
    v5.3.1: Helper for fuzzy dedup. Returns overlap ratio of word sets.
    """
    words_a = set(text_a.lower().split())
    words_b = set(text_b.lower().split())
    if not words_a or not words_b:
        return 0.0
    intersection = words_a & words_b
    union = words_a | words_b
    return len(intersection) / len(union)


class MemorySystemV4(NamespaceManager):
    """Production-ready memory system with sharding and indexing.

    Storage mode parameters
    -----------------------
    Three flags control the storage/sharding subsystem. They interact as
    follows (evaluated in priority order during load/save):

    ``use_sharding`` (bool, default True)
        Enables the **enterprise** shard system (``sharding.py`` /
        ``ShardManager``).  Hash-based partitioning into ``shards/`` dir.
        When True, this takes priority over ``sharding``.

    ``sharding`` (bool, default True)
        Enables the **v4.6 time-window** shard system (``shards.py`` /
        ``TimeShardManager``).  Weekly JSONL files
        (``memories_YYYY-WXX.jsonl``).  Only active when
        ``use_sharding=False``.

    ``tiered_storage`` (bool, default True)
        Hot/warm/cold tier classification.  Only active when
        ``use_sharding=False`` AND ``sharding=True``.  Hot tier loaded
        on startup; warm/cold loaded on-demand during search.

    Typical configurations:
        - **Enterprise** (default): ``use_sharding=True`` — ignores
          ``sharding`` and ``tiered_storage``.
        - **Time-window + tiers**: ``use_sharding=False, sharding=True,
          tiered_storage=True``.
        - **Legacy flat file**: ``use_sharding=False, sharding=False``.

    Other parameters
    ----------------
    workspace : str
        Root directory. Shards and indexes are stored here.
    half_life : float
        Decay half-life in days (default 7).
    tag_terms : list[str] | None
        Custom terms to auto-tag. Merged with built-in defaults.
    """

    def __init__(
        self,
        workspace: str = ".",
        half_life: float = 7.0,
        tag_terms: List[str] = None,
        use_sharding: bool = True,
        use_indexing: bool = True,
        enable_read_cache: bool = True,
        cache_max_entries: int = 1000,
        agent_name: Optional[str] = None,
        # v4.6.0: time-window shard splitting + incremental index loading
        sharding: bool = True,
        # v4.6.5: LLM-enriched indexing — any callable(str) -> dict
        enricher: Optional[Callable[[str], dict]] = None,
        # v4.7.0: tiered storage — load hot tier only on startup
        tiered_storage: bool = True,
        # v4.8.0: graph intelligence — entity extraction + relationship-aware search
        graph_intelligence: bool = True,
        # v4.9.2: quality routing — follow-up pattern detection + outcome tracking
        quality_routing: bool = True,
        # v4.9.4: semantic query expansion — pre-built domain index, zero runtime dep
        semantic_expansion: bool = True,
    ):
        self.workspace = os.path.abspath(workspace)
        self.agent_name = agent_name
        if agent_name is None:
            import warnings
            warnings.warn(
                "[parsica-memory] agent_name not set. Memories will not be agent-scoped. "
                "Pass agent_name='your-agent-name' to MemorySystem() to enable per-agent "
                "isolation and correct cross-instance context restore.",
                UserWarning,
                stacklevel=2,
            )
        self.use_sharding = use_sharding
        self.use_indexing = use_indexing

        # Backward compatibility paths
        self.legacy_metadata_path = os.path.join(self.workspace, "memory_metadata.json")
        self.audit_path = os.path.join(self.workspace, "memory_audit.json")

        # v0.4 managers
        self.migration_manager = MigrationManager(workspace)
        self.shard_manager = ShardManager(workspace) if use_sharding else None
        self.index_manager = IndexManager(workspace) if use_indexing else None

        # Engines (same as v0.3)
        self.decay = DecayEngine(half_life=half_life)
        self.sentiment = SentimentTagger()
        self.temporal = TemporalEngine()
        self.confidence = ConfidenceEngine()
        self.compression = CompressionEngine()
        self.forgetting = ForgettingEngine()
        self.consolidation = ConsolidationEngine(decay=self.decay)
        self.gating = InputGate()
        self.synthesis = KnowledgeSynthesizer()
        self.search_engine = SearchEngine()
        self.proactive = ProactiveMemory(self.workspace)

        # Tag terms
        self._tag_terms = list(set(_DEFAULT_TAG_TERMS + (tag_terms or [])))

        # Memory store (in-memory cache)
        self.memories: List[MemoryEntry] = []
        self._hashes: set = set()
        self._content_norms: set = set()  # v4.9.9 — Content-normalized dedup guard

        # v5.4.0 — Inverted word index for O(1) fact dedup candidate lookup
        self._fact_word_index: Dict[str, set] = {}       # word → set of fact hashes
        self._fact_hash_to_entry: Dict[str, object] = {} # hash → MemoryEntry (facts only)

        # Sprint 11 — performance subsystem
        self._read_cache: Optional[ReadCache] = (
            ReadCache(cache_max_entries) if enable_read_cache else None
        )
        self._enable_read_cache = enable_read_cache
        self._wal = WALManager(self.workspace)
        self._perf = PerformanceMonitor()
        self._access_tracker = AccessTracker(self.workspace)

        # Sprint 3 — pluggable embedding for hybrid semantic search
        self._embedding_fn: Optional[Callable[[str], List[float]]] = None
        self._embedding_cache: Dict[str, List[float]] = {}  # key -> vector, bounded to 1000

        # v4.6.5 — LLM enricher (any callable: str -> {tags, summary, keywords})
        self._enricher: Optional[Callable[[str], dict]] = enricher
        # v4.6.5 — Enrichment counter (lifetime, resets on get_enrichment_count(reset=True))
        self._enrichment_count: int = 0

        # v3.2 — Instrumentation + Co-occurrence (Tier 1 Semantic)
        from .instrumentation import SearchContext
        from .cooccurrence import CooccurrenceIndex
        self._cooccurrence = CooccurrenceIndex(self.workspace)
        self._cooccurrence.load()
        self._instrumentation_log_path = os.path.join(self.workspace, ".instrumentation_log.jsonl")
        self._usage_signals_path = os.path.join(self.workspace, ".usage_signals.jsonl")
        self.opt_in_to_aggregation: bool = False  # Must explicitly opt in
        self._shared_pool: Optional["SharedMemoryPool"] = None
        self._shared_agent_id: Optional[str] = None

        # ── v4.6.0: Time-Window Shard Splitting ─────────────────────────────
        # ``sharding`` controls the NEW weekly shard system (shards.py).
        # It is only active when ``use_sharding=False`` so the enterprise
        # sharding system (sharding.py) takes priority when enabled.
        self._v46_sharding: bool = sharding
        self._v46_shards: Optional[TimeShardManager] = (
            TimeShardManager(self.workspace) if sharding else None
        )

        # ── v4.7.0: Tiered Storage ───────────────────────────────────────────
        # When tiered_storage=True and the v4.6 shard system is active, only
        # the hot tier (0-3 days) is loaded into self.memories on startup.
        # Warm-tier shards (3-14 days) are loaded on-demand when a search
        # returns fewer than WARM_FALLBACK_THRESHOLD results.
        self._tiered_storage: bool = tiered_storage and sharding and not use_sharding
        if self._tiered_storage:
            from .tiers import TierManager
            self._tier_manager: Optional["TierManager"] = TierManager(self.workspace)
        else:
            self._tier_manager = None
        # Warm shard names populated during _load_v46_shards(); used by search()
        self._warm_shard_names: List[str] = []
        self._cold_shard_names: List[str] = []

        # ── v4.9.2: Graph Intelligence ───────────────────────────────────────
        # Entity extraction + relationship-aware search boost.
        # Disabled when graph_intelligence=False (zero overhead).
        self._graph_enabled: bool = graph_intelligence
        if self._graph_enabled:
            try:
                from .graph import MemoryGraph
                self._graph: Optional["MemoryGraph"] = MemoryGraph(self.workspace)
            except Exception:
                logger.warning("Graph intelligence init failed; disabling", exc_info=True)
                self._graph_enabled = False
                self._graph = None
        else:
            self._graph = None

        # ── v4.9.2: Quality Routing ──────────────────────────────────────────
        # Follow-up search pattern detection + outcome-based importance scoring.
        self._quality_routing_enabled: bool = quality_routing
        if self._quality_routing_enabled:
            try:
                from .quality_router import QualityRouter
                self._quality_router: Optional["QualityRouter"] = QualityRouter(self.workspace)
            except Exception:
                logger.warning("Quality router init failed; disabling", exc_info=True)
                self._quality_routing_enabled = False
                self._quality_router = None
        else:
            self._quality_router = None

        # ── v4.9.4: Semantic Query Expansion ────────────────────────────────
        self._expander: Optional[SemanticExpander] = (
            SemanticExpander() if semantic_expansion else None
        )

        # ── v3.1.6: Conversation archive ───────────────────────────────────
        self.archive = ConversationArchive(
            self.workspace,
            summarizer=self._archive_summarizer,
        )

        # ── v4.6.0: Incremental Index Loading ───────────────────────────────
        # Renamed from .antaris_index.json → .parsica_index.json (branding).
        # Falls back to legacy path if the new one doesn't exist yet.
        self._index_path: str = os.path.join(self.workspace, ".parsica_index.json")
        self._index_wal_path: str = os.path.join(self.workspace, ".parsica_wal.jsonl")
        # Backward compat: rename legacy files if they exist
        for old, new in [
            (".antaris_index.json", ".parsica_index.json"),
            (".antaris_wal.jsonl", ".parsica_wal.jsonl"),
        ]:
            old_path = os.path.join(self.workspace, old)
            new_path = os.path.join(self.workspace, new)
            if os.path.exists(old_path) and not os.path.exists(new_path):
                try:
                    os.rename(old_path, new_path)
                except OSError:
                    pass  # non-fatal: will regenerate
        self._index_wal_writer: WALWriter = WALWriter()
        self._index_wal_writer.open(self._index_wal_path)
        self._index_wal_entry_count: int = 0  # entries written since last flush

        # Initialize system
        self._initialize()

    def _initialize(self):
        """Initialize the memory system, handling migrations if needed."""
        import logging  # Bug fix: moved to top of method — was inside success branch only
        _log = logging.getLogger("parsica_memory")
        # Check if migration is needed
        if self.migration_manager.needs_migration():
            migration_result = self.migration_manager.migrate()
            if migration_result["status"] == "success":
                _log.info(
                    f"Migrated from {migration_result['from_version']} to {migration_result['to_version']}")
            elif migration_result["status"] == "error":
                _log.error(
                    f"Migration failed: {migration_result['message']}")
                # Fall back to legacy format
                self.use_sharding = False
                self.use_indexing = False

        # Sprint 8 — namespace manager
        self._init_namespace_manager()

        # Load existing data
        self.load()

        # v4.6.0: Set up incremental index (after memories are loaded)
        self._setup_v46_index()

    # ── internal helpers ────────────────────────────────────────────────

    def _rebuild_content_indexes(self) -> None:
        """Rebuild in-memory dedup indexes from self.memories.

        Consolidates the hash set, content-norm set, and fact dedup inverted
        index from the current memory list. Called after any bulk mutation
        (load, compact, forget, import) to keep indexes consistent.

        Previously this 5-line pattern was copy-pasted in 6+ places.
        """
        self._hashes = {m.hash for m in self.memories}
        self._content_norms = {
            _TURN_PREFIX_RE.sub('', m.content).strip().lower()
            for m in self.memories
        }
        self._fact_word_index = {}
        self._fact_hash_to_entry = {}
        for m in self.memories:
            if m.memory_type == "fact":
                self._index_fact(m)

    def _archive_summarizer(self, text: str) -> str:
        """Adapter for ConversationArchive summarization.

        Uses the configured enricher when available, falling back to extractive
        summarization inside ConversationArchive when no summary is produced.
        """
        if self._enricher is None:
            return ""
        enrichment = self._enricher(text)
        if isinstance(enrichment, dict):
            summary = str(enrichment.get("summary", "")).strip()
            if summary:
                return summary
        return ""

    def _decompose_facts(
        self,
        enrichment: dict,
        parent_entry: "MemoryEntry",
        source: str,
        category: str,
        session_id: str,
        agent_id: Optional[str],
    ) -> int:
        """Extract atomic facts from an enrichment result and store them.

        Applies hash, content-norm, and fuzzy dedup checks. Returns the
        count of new fact entries created. Used by ingest(), re_enrich(),
        and re_decompose() to eliminate the 3× duplication of this logic.
        """
        facts = enrichment.get("facts", [])
        if not facts or not isinstance(facts, list):
            return 0

        count = 0
        for fact_text in facts:
            if not isinstance(fact_text, str) or len(fact_text.strip()) < 10:
                continue

            fact_entry = MemoryEntry(
                fact_text.strip(),
                source=source,
                line=0,
                category=category,
                memory_type="fact",
                session_id=session_id,
                agent_id=agent_id or self.agent_name,
            )
            fact_entry.provenance = "decomposed"
            fact_entry.parent_hash = parent_entry.hash
            fact_entry.confidence = 0.8
            fact_entry.tags = list(getattr(parent_entry, "tags", []))

            # Dedup: exact hash
            if fact_entry.hash in self._hashes:
                continue
            # Dedup: normalized content
            fact_norm = fact_text.strip().lower()
            if fact_norm in self._content_norms:
                continue
            # Dedup: fuzzy similarity
            existing = self._find_similar_fact(fact_entry.content, threshold=0.85)
            if existing is not None:
                self._bump_sighting(existing)
                continue

            self.memories.append(fact_entry)
            self._hashes.add(fact_entry.hash)
            self._content_norms.add(fact_norm)
            self._index_fact(fact_entry)
            self.search_engine.mark_dirty()
            if self.use_indexing and self.index_manager:
                self.index_manager.add_memory(fact_entry)
            self._wal.append(fact_entry.to_dict())
            count += 1

        return count

    # ── persistence ─────────────────────────────────────────────────────

    def save(self) -> str:
        """Save memory state to disk using the appropriate format."""
        # v4.9.2: persist graph alongside memories
        if self._graph_enabled and self._graph is not None:
            try:
                self._graph.save()
            except Exception:
                logger.warning("Graph save failed", exc_info=True)
        if self.use_sharding and self.shard_manager:
            return self._save_sharded()
        if not self.use_sharding and self._v46_sharding and self._v46_shards:
            return self._save_v46_sharded()
        return self._save_legacy()
    
    def _save_sharded(self) -> str:
        """Save using v0.4 sharded format."""
        if not self.shard_manager:
            return self._save_legacy()

        # Group memories by shard
        shard_groups = self.shard_manager.shard_memories(self.memories)
        expected_shards = set(shard_groups.keys())

        # Save each expected shard and rebuild the in-memory shard index from truth
        self.shard_manager.index.shards = {}
        for shard_key, shard_memories in shard_groups.items():
            self.shard_manager.save_shard(shard_key, shard_memories)
            self.shard_manager.index.add_shard(shard_key, shard_memories)

        # Remove obsolete shard files so deleted memories cannot resurrect on reload
        self.shard_manager.delete_obsolete_shards(expected_shards)

        # Save shard index
        self.shard_manager.index.save_index()

        # Update search indexes
        if self.use_indexing and self.index_manager:
            self.index_manager.rebuild_indexes(self.memories)
            self.index_manager.save_all_indexes()

        shard_dir = os.path.join(self.workspace, "shards")
        return shard_dir
    
    def _save_v46_sharded(self) -> str:
        """Save using the v4.6+ weekly time-shard format.

        v2.6.1: When tiered storage is active, only hot-tier entries are in
        self.memories.  Warm/cold shard files must be protected from deletion
        by rewrite_entries() — otherwise a save() after ingest would wipe the
        warm/cold tiers that were never loaded into memory.
        """
        if not self._v46_shards:
            return self._save_legacy()

        # Collect warm/cold shard names to protect from deletion.
        # Also refresh them from disk first in case this instance mutated state
        # after startup (delete_source()/forget()/save()) while another process
        # created or migrated additional warm/cold shards in the same workspace.
        protected: set = set()
        if self._tiered_storage and self._tier_manager is not None:
            all_shards = self._v46_shards.list_shards()
            _hot, warm, cold = self._tier_manager.classify_shards(all_shards)
            self._warm_shard_names = warm
            self._cold_shard_names = cold
            protected.update(warm)
            protected.update(cold)

        shard_names = self._v46_shards.rewrite_entries(
            self.memories, protected_shards=protected if protected else None,
        )

        if self._tiered_storage and self._tier_manager is not None:
            hot, warm, cold = self._tier_manager.classify_shards(shard_names)
            self._warm_shard_names = warm
            self._cold_shard_names = cold
            self._tier_manager.invalidate_warm_cache()
            self._tier_manager.save_hashes(shard_names)

        return self.workspace

    def _save_legacy(self) -> str:
        """Save using v0.2/v0.3 legacy single-file format."""
        from . import __version__ as _pkg_version  # Bug fix: distinguish format vs pkg version
        data = {
            "version": "0.4.0",           # storage schema version (used by migration logic)
            "package_version": _pkg_version,  # parsica-memory package version
            "saved_at": datetime.now(timezone.utc).isoformat(),
            "count": len(self.memories),
            "format": "legacy",
            "memories": [m.to_dict() for m in self.memories],
        }
        atomic_write_json(self.legacy_metadata_path, data)
        return self.legacy_metadata_path

    # ── WAL flush / close ─────────────────────────────────────────────────

    def flush(self) -> Dict:
        """Compact the WAL into permanent shard/legacy storage.

        Called automatically after ``WALManager.flush_interval`` writes or
        when the WAL exceeds 1 MB.  Also called by ``close()``.

        Returns:
            ``{"flushed_entries": N, "wal_cleared": True}``
        """
        pending_entries = self._wal.load_pending()
        pending_before = len(pending_entries)
        pending_hashes = {entry.get("hash") for entry in pending_entries if entry.get("hash")}

        # Persist current in-memory state first. This makes the snapshot durable
        # before the WAL is rewritten/cleared, eliminating the data-loss window
        # from clear-before-save ordering.
        self.save()

        # Persist access counts alongside the flush
        self._access_tracker.save()

        # Persist co-occurrence index (deferred from ingest for bulk-write perf)
        self._cooccurrence.save()

        # Rewrite WAL to keep only entries that were appended during/after save.
        remaining_entries = []
        for entry in self._wal.load_pending():
            entry_hash = entry.get("hash")
            if entry_hash and entry_hash in pending_hashes:
                continue
            remaining_entries.append(entry)

        if remaining_entries:
            self._wal.replace_with_entries(remaining_entries)
        else:
            self._wal.clear()

        # Invalidate read-cache (data on disk changed)
        if self._read_cache is not None:
            self._read_cache.invalidate()

        # v4.9.6: Rebuild Layer 9 cluster index at flush time (not at search time).
        # Clusters are O(n×e) to build — acceptable at write-flush, not at search.
        self.search_engine.rebuild_clusters(self.memories)

        self._perf.record_compaction()

        return {"flushed_entries": pending_before, "wal_cleared": self._wal.pending_count() == 0}

    def close(self) -> None:
        """Flush WAL and release resources.  Call before process exit."""
        self.flush()

    def load(self) -> int:
        """Load memory state from disk, auto-detecting format.

        Sprint 11: after loading from shards/legacy, replays any pending WAL
        entries so that a crash between ingest and flush loses no data.

        v4.6.0: When ``use_sharding=False`` and ``sharding=True``, loads from
        the time-window shard files (``memories_YYYY-WXX.jsonl``).  Also
        auto-migrates ``memories.jsonl`` → weekly shards if the flat file
        exists but no shard files are present.
        """
        if self.use_sharding and self.shard_manager:
            count = self._load_sharded()
            if count > 0:
                self._replay_wal()
                # v5.0.2: Load pre-computed embeddings for Layer 10 reranking
                self.search_engine.load_embeddings(self.workspace)
                return len(self.memories)

        # v4.6.0: time-window shard load path (only when enterprise sharding off)
        if not self.use_sharding and self._v46_sharding and self._v46_shards:
            self._v46_auto_migrate()
            count = self._load_v46_shards()
            if count > 0:
                self._replay_wal()
                return len(self.memories)

        # Fall back to legacy flat format (memories.jsonl or memory_metadata.json)
        result = self._load_legacy()
        self._replay_wal()
        return len(self.memories)

    def _replay_wal(self) -> int:
        """Replay pending WAL entries that were not yet compacted to shards.

        This is called automatically on ``load()`` and is safe to call even
        when the WAL is empty or doesn't exist.

        Returns:
            Number of entries replayed.
        """
        pending = self._wal.load_pending()
        if not pending:
            return 0

        replayed = 0
        for entry_dict in pending:
            try:
                entry = MemoryEntry.from_dict(entry_dict)
            except Exception:
                continue   # corrupted entry — skip

            if entry.hash in self._hashes:
                continue   # already in memory (e.g. flushed before crash)

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            if entry.memory_type == "fact": self._index_fact(entry)  # v5.4.0
            replayed += 1

        if replayed:
            self.search_engine.mark_dirty()

        return replayed

    def _load_sharded(self) -> int:
        """Load from v0.4 sharded format."""
        if not self.shard_manager:
            return 0

        # Load all memories from shards (careful with memory usage)
        _LOAD_LIMIT = 75000
        self.memories = self.shard_manager.get_all_memories(limit=_LOAD_LIMIT)
        # Bug fix: warn when the safety limit is hit so users know data was truncated
        if len(self.memories) >= _LOAD_LIMIT:
            import warnings
            warnings.warn(
                f"parsica-memory: loaded {_LOAD_LIMIT} memories (safety limit). "
                "Some older memories may not be in the active set. "
                "Consider calling forget() or archiving old shards.",
                UserWarning,
                stacklevel=3,
            )
        self._rebuild_content_indexes()
        if self.memories:
            self.search_engine.build_index(self.memories)
        return len(self.memories)

    def _load_legacy(self) -> int:
        """Load from v0.2/v0.3 legacy single-file format."""
        if not os.path.exists(self.legacy_metadata_path):
            return 0

        with open(self.legacy_metadata_path) as f:
            data = json.load(f)

        self.memories = [MemoryEntry.from_dict(d) for d in data.get("memories", [])]
        self._rebuild_content_indexes()
        if self.memories:
            self.search_engine.build_index(self.memories)
        return len(self.memories)

    # ── v4.6.0: Time-Window Sharding helpers ────────────────────────────────

    def _v46_auto_migrate(self) -> None:
        """Auto-migrate memories.jsonl → weekly shards if flat file exists
        but no shard files are present yet (first-run migration).

        Emits a UserWarning so callers are aware the migration happened.
        """
        if self._v46_shards is None:
            return

        flat_path = os.path.join(self.workspace, "memories.jsonl")
        existing_shards = self._v46_shards.list_shards()

        if os.path.exists(flat_path) and not existing_shards:
            import warnings
            warnings.warn(
                "[parsica-memory] Auto-migrating memories.jsonl to "
                "time-window shard files (memories_YYYY-WXX.jsonl). "
                "Original backed up as memories.jsonl.bak.",
                UserWarning,
                stacklevel=5,
            )
            _migrate_to_shards(self.workspace)

    def _load_v46_shards(self) -> int:
        """Load memories from the active time-window shards (v4.6/v4.7 path).

        v4.6: Loads current week + previous 2 weeks (~3-week window).
        v4.7: When tiered_storage=True, classifies all shards into hot/warm/cold
        and loads only the hot tier into self.memories.  Warm shard names are
        stored in self._warm_shard_names for on-demand search fallback.
        """
        if not self._v46_shards:
            return 0

        if self._tiered_storage and self._tier_manager is not None:
            # v4.7: hot-only load
            all_shards = self._v46_shards.list_shards()
            hot, warm, cold = self._tier_manager.classify_shards(all_shards)
            self._warm_shard_names = warm
            self._cold_shard_names = cold

            # Load hot shards only
            hot_entries: List[MemoryEntry] = []
            seen: set = set()
            for shard_name in hot:
                for entry in self._tier_manager._load_shard(shard_name):
                    if entry.hash not in seen:
                        hot_entries.append(entry)
                        seen.add(entry.hash)

            self.memories = hot_entries
            self._rebuild_content_indexes()
            if self.memories:
                self.search_engine.build_index(self.memories)

            # Snapshot shard hashes for incremental sync
            self._tier_manager.save_hashes(all_shards)
            return len(self.memories)

        # v4.6 fallback: load current + 2 prior weeks
        self.memories = self._v46_shards.load_active_shards(weeks=2)
        self._rebuild_content_indexes()
        if self.memories:
            self.search_engine.build_index(self.memories)
        return len(self.memories)

    # ── v4.7.0: Tiered search helpers ─────────────────────────────────────

    def _warm_search_fallback(
        self,
        query: str,
        limit: int,
        category,
        min_confidence: float,
        decay_fn,
        session_id: str,
        effective_agent_id,
        memory_type,
        existing_hashes: set,
    ) -> list:
        """Load warm shards on-demand and search them.

        Called when the hot-tier search returns fewer than
        WARM_FALLBACK_THRESHOLD results. Results already present in the hot
        tier (by hash) are excluded to avoid duplicates.

        Returns a list of SearchResult objects (may be empty on any failure).
        """
        try:
            warm_entries = self._tier_manager.load_warm(self._warm_shard_names)
            if not warm_entries:
                return []
            # Build a temporary search engine scoped to warm entries
            from .search import SearchEngine
            warm_engine = SearchEngine()
            warm_engine.build_index(warm_entries)
            warm_results = warm_engine.search(
                query=query,
                memories=warm_entries,
                limit=limit * 5,
                category=category,
                min_score=min_confidence,
                decay_fn=decay_fn,
                session_id=session_id,
                agent_id=effective_agent_id,
            )
            # Filter memory_type and already-seen hashes
            if memory_type is not None:
                warm_results = [
                    r for r in warm_results
                    if getattr(r.entry, "memory_type", "episodic") == memory_type
                ]
            warm_results = [
                r for r in warm_results if r.entry.hash not in existing_hashes
            ]
            return warm_results[:limit]
        except Exception:
            logger.debug("Warm-tier search fallback failed", exc_info=True)
            return []

    def _cold_search(
        self,
        query: str,
        limit: int,
        decay_fn,
        effective_agent_id,
        existing_hashes: set,
    ) -> list:
        """Load cold shards on-demand and search them (explicit opt-in only).

        Returns a list of SearchResult objects (may be empty on any failure).
        """
        try:
            if not self._tier_manager or not self._cold_shard_names:
                return []
            cold_entries = self._tier_manager.load_warm(self._cold_shard_names)
            if not cold_entries:
                return []
            from .search import SearchEngine
            cold_engine = SearchEngine()
            cold_engine.build_index(cold_entries)
            cold_results = cold_engine.search(
                query=query,
                memories=cold_entries,
                limit=limit * 5,
                decay_fn=decay_fn,
                agent_id=effective_agent_id,
            )
            return [r for r in cold_results if r.entry.hash not in existing_hashes][:limit]
        except Exception:
            logger.debug("Cold-tier search failed", exc_info=True)
            return []

    # ── v4.6.0: Incremental Index Loading helpers ─────────────────────────

    def _setup_v46_index(self) -> None:
        """Set up the BM25 index for fast restarts (v4.6 feature).

        Strategy:
        1. Try to load a saved index from ``.parsica_index.json``.
        2. On failure (missing / corrupt), do a full ``build_index()`` (if
           memories exist) and save the result.  An empty-corpus save is
           written when there are no memories so the file always exists
           after init — enabling WAL delta application on the next restart.
        3. Apply any pending WAL entries from ``.parsica_wal.jsonl`` to
           fold in memories ingested since the last save.
        """
        loaded = self.search_engine.load_index(self._index_path)

        if not loaded:
            # Full rebuild from current memories (or empty corpus)
            if self.memories:
                self.search_engine.build_index(self.memories)
            self.search_engine.save_index(self._index_path)
        else:
            # Index loaded OK — apply WAL delta to catch up
            reader = WALReader()
            reader.open(self._index_wal_path)
            wal_dicts = reader.read_all()
            if wal_dicts:
                from .entry import MemoryEntry as _ME
                wal_entries = []
                for d in wal_dicts:
                    try:
                        wal_entries.append(_ME.from_dict(d))
                    except Exception:
                        pass
                if wal_entries:
                    self.search_engine.apply_wal_entries(wal_entries)

    def _flush_v46_index(self) -> None:
        """Rebuild the full index, save it, and clear the index WAL.

        Called automatically when the index WAL reaches 500 entries.
        """
        self.search_engine.build_index(self.memories)
        self.search_engine.save_index(self._index_path)
        # Clear the WAL file
        reader = WALReader()
        reader.open(self._index_wal_path)
        reader.clear()
        # Reopen the writer on the (now empty) file
        self._index_wal_writer.close()
        self._index_wal_writer = WALWriter()
        self._index_wal_writer.open(self._index_wal_path)
        self._index_wal_entry_count = 0

    # ── Sprint 3: embedding interface ────────────────────────────────────

    def set_embedding_fn(self, fn: Callable[[str], List[float]]) -> None:
        """Set a custom embedding function for semantic search.

        When set, search() uses hybrid BM25 + cosine similarity scoring.
        When not set, pure BM25 is used (default, zero-dependency behavior).

        Example::

            import openai
            client = openai.Client()
            def embed(text):
                return client.embeddings.create(
                    input=text, model="text-embedding-3-small"
                ).data[0].embedding
            mem.set_embedding_fn(embed)
        """
        self._embedding_fn = fn
        self._embedding_cache.clear()  # invalidate embedding cache on fn change
        if self._read_cache is not None:
            self._read_cache.invalidate()  # invalidate search result cache

    def _get_embedding(self, text: str) -> Optional[List[float]]:
        """Get embedding with caching. Returns None if no embedding fn set."""
        if self._embedding_fn is None:
            return None
        key = text[:200]  # cache key
        if key not in self._embedding_cache:
            if len(self._embedding_cache) >= 1000:
                # Evict oldest (first inserted key in Python 3.7+ dict)
                del self._embedding_cache[next(iter(self._embedding_cache))]
            try:
                self._embedding_cache[key] = self._embedding_fn(text)
            except Exception:
                return None
        return self._embedding_cache.get(key)

    # ── v5.3.1: fuzzy dedup helper ─────────────────────────────────────

    def _fact_index_words(self, content: str) -> set:
        """Extract indexable words from fact content.

        v5.4.0: Lowercased, stopwords removed, minimum length 3.
        Keeps the inverted index lean — common words ("the", "is", etc.)
        would create huge candidate sets and defeat the purpose of the index.
        """
        return {
            w for w in content.lower().split()
            if w not in _FACT_DEDUP_STOPWORDS and len(w) >= 3
        }

    def _index_fact(self, entry: "MemoryEntry") -> None:
        """Add a fact entry to the inverted word dedup index.

        v5.4.0: Called after a fact entry is successfully added to self.memories.
        Also called at load time to rebuild the index from disk.
        """
        for w in self._fact_index_words(entry.content):
            self._fact_word_index.setdefault(w, set()).add(entry.hash)
        self._fact_hash_to_entry[entry.hash] = entry

    def _find_similar_fact(self, content: str, threshold: float = 0.85) -> Optional["MemoryEntry"]:
        """Find existing fact entry with similar content using Jaccard similarity.

        v5.4.0: Replaced O(n) full scan with inverted word index for O(candidates) lookup.
        Candidates = facts sharing at least one non-stopword with the new content.
        Jaccard is run only on the candidate set, not all memories.

        Args:
            content: New fact content to search for
            threshold: Minimum Jaccard similarity (0.0-1.0) to consider a match

        Returns:
            Existing MemoryEntry if found, None otherwise
        """
        words = self._fact_index_words(content)
        if not words:
            return None  # no indexable words — skip dedup safely
        candidates: set = set()
        for w in words:
            candidates.update(self._fact_word_index.get(w, set()))
        for h in candidates:
            entry = self._fact_hash_to_entry.get(h)
            if entry and _jaccard_similarity(content, entry.content) >= threshold:
                return entry
        return None

    def _bump_sighting(self, existing: "MemoryEntry") -> None:
        """Bump sighting count and confidence for a canonical fact that was seen again.
        
        v5.3.1: Called when fuzzy dedup detects a near-duplicate fact.
        """
        existing.confidence = min(existing.confidence + 0.05, 1.0)
        existing.last_accessed = datetime.now(timezone.utc).isoformat()
        existing.access_count += 1
        existing.sighting_count = getattr(existing, 'sighting_count', 0) + 1
        existing.last_sighted = datetime.now(timezone.utc).isoformat()
        self.search_engine.mark_dirty()

    # ── search with indexing ───────────────────────────────────────────

    def search(
        self,
        query: str,
        limit: int = 20,
        tags: Optional[List[str]] = None,
        tag_mode: str = "any",
        date_range: Optional[Tuple[str, str]] = None,
        use_decay: bool = True,
        category: str = None,
        min_confidence: float = 0.0,
        sentiment_filter: str = None,
        memory_type: Optional[str] = None,    # Sprint 2
        explain: bool = False,
        session_id: str = "*",               # v4.1: session isolation; "*" = all sessions (cross-session search for recall). Session isolation is for writes, not reads.
        agent_id: Optional[str] = None,      # v4.5.4: agent-scoped search
        include_cold: bool = False,          # v4.7.0: include cold-tier shards
        cross_session_recall: str = "all",   # v5.2: "all" = no filter, "semantic" = other sessions only get semantic memories, "none" = strict session isolation
        confidence_floor: float = 0.0,      # v5.3.1: minimum confidence to include
        source_channel: Optional[str] = None,  # v5.6: filter by channel (e.g. "discord:1234", "telegram:chat_5678")
    ) -> list:
        """Search memories using BM25-inspired ranking with optional fast indexes.

        Sprint 11: results are served from the LRU read-cache when the query
        signature matches a previously seen search.  On a cache miss the full
        BM25 pipeline runs and the result-set is cached for future calls.
        Access counts are incremented for every returned entry so that hot
        memories receive a relevance boost in future searches.

        Bug fix: BM25 IDF is always computed over the full corpus (self.memories)
        so that type/sentiment filters do not corrupt IDF weights.  Filters are
        applied AFTER scoring.

        Feature: recall_priority from MEMORY_TYPE_CONFIGS is applied to each
        scored entry so that e.g. mistake memories (recall_priority=1.0) float
        to the top.

        Args:
            query: Search query string.
            limit: Maximum results.
            memory_type: Optional filter — only return entries of this type.
            explain: If True, return SearchResult objects with score explanations.
        """
        _t0 = time.monotonic()

        # ── cache key ───────────────────────────────────────────────────
        # v4.1: include session_id in cache key so sessions don't share results
        # v4.5.4: effective_agent_id — use explicitly passed agent_id, else fall
        # back to the MemorySystem's own identity (self.agent_name).  None means
        # no scoping (shared pool visible to all).
        effective_agent_id = agent_id if agent_id is not None else self.agent_name

        cache_key = json.dumps(
            [query, limit, tags, tag_mode, date_range, use_decay,
             category, min_confidence, sentiment_filter, memory_type, explain,
             session_id, effective_agent_id, cross_session_recall, source_channel],
            sort_keys=True, default=str,
        )

        if self._read_cache is not None:
            cached = self._read_cache.get(cache_key)
            if cached is not None:
                self._perf.record_search((time.monotonic() - _t0) * 1000)
                return cached

        # ── full search pipeline ─────────────────────────────────────────
        # Bug fix (Bug 2): always build the BM25 index from the FULL corpus
        # so that IDF weights are never corrupted by a filtered subset.
        if self.search_engine._doc_count != len(self.memories):
            self.search_engine.build_index(self.memories)

        decay_fn = self.decay.score if use_decay else None

        # v4.9.19: Query-side expansion REMOVED — enrichment on the document side
        # (search_keywords 2×, enriched_summary 2×, search_queries 3×) handles
        # vocabulary bridging. Query expansion inflated short queries to 150+
        # tokens, defeating inverted index pre-filter and diluting BM25 scores.
        # See benchmarks/DIAGNOSIS.md Issue 1.

        # v5.2: When cross_session_recall is active and not "all", we need to
        # search across ALL sessions first, then filter. Otherwise the search
        # engine's session_id pre-filter would exclude other sessions' memories
        # before our cross-session filter can selectively include semantic ones.
        search_session_id = session_id
        if cross_session_recall != "all" and session_id and session_id != "*":
            search_session_id = "*"  # search all, filter post-scoring

        # Fetch a generous pool from the full corpus, then filter & trim.
        # Using limit * 10 (min 200) ensures filters don't starve results.
        fetch_limit = max(limit * 10, 200)
        search_results = self.search_engine.search(
            query=query,
            memories=self.memories,
            limit=fetch_limit,
            category=category,
            min_score=min_confidence,
            decay_fn=decay_fn,
            session_id=search_session_id,
            agent_id=effective_agent_id,   # v4.5.4: pre-filter by agent
            index_manager=self.index_manager if self.use_indexing else None,
        )

        # ── post-scoring filters (Bug 2 fix: applied AFTER BM25 scoring) ──
        if sentiment_filter:
            search_results = [
                r for r in search_results
                if hasattr(r.entry, "sentiment")
                and r.entry.sentiment
                and sentiment_filter in r.entry.sentiment
            ]
        if memory_type is not None:
            search_results = [
                r for r in search_results
                if getattr(r.entry, "memory_type", "episodic") == memory_type
            ]

        # ── Sprint 3: hybrid BM25 + semantic scoring ──────────────────────
        if self._embedding_fn is not None:
            query_vec = self._get_embedding(query)
            if query_vec is not None:
                from .utils import cosine_similarity
                bm25_weight = 0.4
                semantic_weight = 0.6
                hybrid_results = []
                for result in search_results:
                    entry_vec = self._get_embedding(result.entry.content[:500])
                    if entry_vec is not None:
                        sem_score = cosine_similarity(query_vec, entry_vec)
                        hybrid_score = bm25_weight * result.relevance + semantic_weight * sem_score
                        hybrid_results.append(SearchResult(
                            entry=result.entry,
                            score=hybrid_score,
                            relevance=hybrid_score,
                            matched_terms=result.matched_terms,
                            explanation=result.explanation + f" [hybrid: bm25={result.relevance:.3f} sem={sem_score:.3f}]",
                        ))
                    else:
                        hybrid_results.append(result)
                search_results = sorted(hybrid_results, key=lambda r: r.score, reverse=True)

        # ── Feature 1: recall_priority boost ─────────────────────────────
        for r in search_results:
            priority = MEMORY_TYPE_CONFIGS.get(
                getattr(r.entry, "memory_type", "episodic"), {}
            ).get("recall_priority", 1.0)
            r.score *= priority

        # Re-sort after recall_priority adjustment
        search_results.sort(key=lambda r: r.score, reverse=True)
        search_results = search_results[:limit * 3 if source_channel else limit]

        # ── v4.7.0: Warm-tier fallback ────────────────────────────────────
        # If hot-tier search returned fewer than WARM_FALLBACK_THRESHOLD
        # results AND warm shards exist, load them on-demand and merge.
        if (
            self._tiered_storage
            and self._tier_manager is not None
            and self._warm_shard_names
            and len(search_results) < 3
        ):
            warm_extra = self._warm_search_fallback(
                query=query,
                limit=limit,
                category=category,
                min_confidence=min_confidence,
                decay_fn=decay_fn,
                session_id=session_id,
                effective_agent_id=effective_agent_id,
                memory_type=memory_type,
                existing_hashes={r.entry.hash for r in search_results},
            )
            if warm_extra:
                search_results = sorted(
                    search_results + warm_extra,
                    key=lambda r: r.score,
                    reverse=True,
                )[:limit]

        # ── v4.7.0: Cold-tier search (explicit opt-in only) ───────────────
        if include_cold and self._tiered_storage and self._cold_shard_names and self._tier_manager:
            cold_extra = self._cold_search(
                query=query,
                limit=limit,
                decay_fn=decay_fn,
                effective_agent_id=effective_agent_id,
                existing_hashes={r.entry.hash for r in search_results},
            )
            if cold_extra:
                search_results = sorted(
                    search_results + cold_extra,
                    key=lambda r: r.score,
                    reverse=True,
                )[:limit]

        # Reinforce accessed memories & record access counts
        for r in search_results:
            self.decay.reinforce(r.entry)
            self._record_access(r.entry.hash)   # Sprint 11 access tracking

        # Apply access-count boost and re-sort (Sprint 11)
        if search_results:
            boosted = []
            for r in search_results:
                boost = self._access_tracker.boost_score(r.entry.hash)
                boosted.append((r, r.score * boost))
            boosted.sort(key=lambda x: x[1], reverse=True)
            search_results = [r for r, _ in boosted]

        # ── v4.9.2: Graph-based relevance boost ───────────────────────────
        # Apply graph boost only when graph is enabled AND has been built.
        # This re-ranks results using entity relationship signals without
        # changing which entries are returned (no cold/warm tier loading).
        if (self._graph_enabled and self._graph is not None
                and search_results and not include_cold):
            try:
                search_results = self._graph.boost_results(query, search_results)
            except Exception:
                logger.debug("Graph boost failed for query %r", query[:50], exc_info=True)

        # ── v4.9.2: Quality Routing — observe search patterns ─────────────
        if self._quality_routing_enabled and self._quality_router is not None and search_results:
            try:
                self._quality_router.observe_search(
                    query=query,
                    results=search_results,
                    session_id=str(session_id) if session_id else "",
                    agent_id=str(self.agent_name or ""),
                )
            except Exception:
                logger.debug("Quality router observe failed", exc_info=True)

        # ── v5.3.1: Confidence threshold filtering ─────────────────────────
        # Filter results below confidence floor (enables "I don't know" capability)
        if confidence_floor > 0:
            filtered_results = []
            for r in search_results:
                entry_confidence = getattr(r.entry, 'confidence', 0.5)
                score = getattr(r, 'score', 0.0) if hasattr(r, 'score') else getattr(r, 'relevance', 0.0)
                if (entry_confidence * score) >= confidence_floor:
                    filtered_results.append(r)
            search_results = filtered_results

        # ── v5.6: source_channel filter ────────────────────────────────────
        if source_channel:
            search_results = [
                r for r in search_results
                if getattr(r.entry if hasattr(r, 'entry') else r, 'source_channel', '') == source_channel
            ][:limit]

        if explain:
            # v5.2: cross-session filter for explain mode (SearchResult objects)
            if cross_session_recall != "all" and session_id and session_id != "*":
                filtered_sr = []
                for r in search_results:
                    entry_session = getattr(r.entry, "session_id", "") or ""
                    is_own = (entry_session == session_id) or (not entry_session)
                    if is_own:
                        filtered_sr.append(r)
                    elif cross_session_recall == "none":
                        continue
                    elif cross_session_recall == "semantic":
                        if getattr(r.entry, "memory_type", "episodic") == "semantic":
                            filtered_sr.append(r)
                search_results = filtered_sr
            self._perf.record_search((time.monotonic() - _t0) * 1000)
            if self._read_cache is not None:
                self._read_cache.put(cache_key, search_results)
            return search_results

        # Backward compat: return MemoryEntry with search-time confidence.
        # Uses copy to avoid mutating the canonical entry in the index.
        # WindowEntry (Layer 5 sliding windows) are resolved back to their
        # constituent MemoryEntry objects for API compatibility.
        # Agent scoping is preserved: only entries matching the effective
        # agent_id (or shared entries) are included in the resolved set.
        entries = []
        seen_hashes: set = set()
        _mem_by_hash = {m.hash: m for m in self.memories}
        for r in search_results:
            entry = r.entry
            # Resolve WindowEntry → constituent MemoryEntries
            if hasattr(entry, "source_ids"):
                for h in entry.source_ids:
                    if h in seen_hashes:
                        continue
                    mem_entry = _mem_by_hash.get(h)
                    if mem_entry:
                        # Respect agent scoping: skip entries from other agents
                        entry_aid = getattr(mem_entry, "agent_id", None)
                        if (effective_agent_id and entry_aid
                                and entry_aid != effective_agent_id):
                            continue
                        entry_copy = copy.copy(mem_entry)
                        entry_copy.confidence = r.relevance
                        entries.append(entry_copy)
                        seen_hashes.add(h)
            else:
                if entry.hash not in seen_hashes:
                    entry_copy = copy.copy(entry)
                    entry_copy.confidence = r.relevance
                    entries.append(entry_copy)
                    seen_hashes.add(entry.hash)

        # ── v5.2: Cross-session recall filtering ─────────────────────────
        # Applied AFTER WindowEntry resolution so individual MemoryEntry objects
        # are correctly filtered (WindowEntries bundle multiple sessions).
        #   "semantic" — other sessions' memories only if memory_type == "semantic"
        #   "none"     — only memories from the current session (strict isolation)
        #   "all"      — no filtering (default, backward compatible)
        if cross_session_recall != "all" and session_id and session_id != "*":
            filtered_entries = []
            for entry in entries:
                entry_session = getattr(entry, "session_id", "") or ""
                is_own_session = (entry_session == session_id) or (not entry_session)
                if is_own_session:
                    filtered_entries.append(entry)
                elif cross_session_recall == "none":
                    continue
                elif cross_session_recall == "semantic":
                    entry_type = getattr(entry, "memory_type", "episodic") or "episodic"
                    if entry_type == "semantic":
                        filtered_entries.append(entry)
            entries = filtered_entries

        elapsed_ms = (time.monotonic() - _t0) * 1000
        self._perf.record_search(elapsed_ms)
        if self._read_cache is not None:
            self._read_cache.put(cache_key, entries)
        return entries
    
    def _search_indexed(self, 
                       query: str,
                       limit: int,
                       tags: Optional[List[str]],
                       tag_mode: str,
                       date_range: Optional[Tuple[str, str]],
                       use_decay: bool) -> List[MemoryEntry]:
        """Fast search using indexes."""
        
        # Get results from indexes
        indexed_results = self.index_manager.search(
            query=query,
            tags=tags,
            tag_mode=tag_mode,
            date_range=date_range,
            limit=limit * 2  # Get more for decay scoring
        )
        
        if not indexed_results:
            return []
        
        # Convert hash results to memory objects
        hash_to_memory = {m.hash: m for m in self.memories}
        results = []
        
        for memory_hash, base_score in indexed_results:
            if memory_hash in hash_to_memory:
                memory = hash_to_memory[memory_hash]
                
                # Apply decay scoring if requested
                if use_decay:
                    decay_score = self.decay.score(memory)
                    final_score = base_score * (0.5 + decay_score)
                    # Reinforce memory (simulate access)
                    self.decay.reinforce(memory)
                else:
                    final_score = base_score
                
                results.append((memory, final_score))
        
        # Sort by final score and return
        results.sort(key=lambda x: x[1], reverse=True)
        return [memory for memory, score in results[:limit]]
    
    def _search_legacy(self, query: str, limit: int, use_decay: bool) -> List[MemoryEntry]:
        """Fallback to legacy search method."""
        import re
        
        query_lower = query.lower()
        results = []
        
        for memory in self.memories:
            content_lower = memory.content.lower()
            
            # Simple text matching
            if query_lower in content_lower:
                if use_decay:
                    decay_score = self.decay.score(memory)
                    self.decay.reinforce(memory)
                    score = decay_score
                else:
                    score = 1.0
                
                results.append((memory, score))
        
        # Sort by score
        results.sort(key=lambda x: x[1], reverse=True)
        return [memory for memory, score in results[:limit]]

    def recent(
        self,
        limit: int = 10,
        agent_id: Optional[str] = None,
        include_shared: bool = True,
    ) -> list:
        """Return the N most recently accessed memories for this agent.

        Unlike search(), this method does NOT use BM25 — it is a pure
        timestamp sort.  Guaranteed to return results as long as any
        memories exist.  Use this for session restore where you want
        "what was I working on?" rather than keyword matching.

        v4.5.4: added for recency-first session restore.

        Args:
            limit: Maximum number of entries to return.
            agent_id: Filter to this agent.  Defaults to self.agent_name.
                      Entries with no agent_id are the shared pool and are
                      always included when include_shared=True.
            include_shared: Include memories with no agent_id (shared pool).

        Returns:
            List of MemoryEntry objects, newest first.
        """
        effective_agent_id = agent_id if agent_id is not None else self.agent_name

        if effective_agent_id:
            filtered = [
                m for m in self.memories
                if getattr(m, "agent_id", None) == effective_agent_id
                or (include_shared and not getattr(m, "agent_id", None))
            ]
        else:
            filtered = list(self.memories)

        # Sort by last_accessed desc, fall back to created_at
        def _sort_key(m):
            ts = getattr(m, "last_accessed", None) or getattr(m, "created_at", None) or ""
            return ts

        filtered.sort(key=_sort_key, reverse=True)
        return filtered[:limit]

    # ── cross-channel recency recall (v2.3.0) ──────────────────────────

    def recall_recent(
        self,
        hours: float = 6.0,
        limit: int = 5,
        exclude_channel: Optional[str] = None,
        session_id: Optional[str] = None,
        source_channel: Optional[str] = None,
    ) -> List:
        """Retrieve the most recent memories, optionally filtered by session/channel.

        This complements semantic search by surfacing *temporally recent*
        memories regardless of keyword or embedding relevance — perfect
        for cross-channel continuity where a user switches apps.

        Parameters
        ----------
        hours : float
            How far back to look from now (default 6).
        limit : int
            Max memories to return (default 5).
        exclude_channel : str, optional
            Channel identifier to skip (e.g. the current channel, which
            is already covered by semantic search).
        session_id : str, optional
            Filter to only memories from this session. None = all sessions.
        source_channel : str, optional
            Filter to only memories from this channel. None = all channels.

        Returns
        -------
        list[MemoryEntry]
            Newest-first list of memories, capped at *limit*.
        """
        from .search import search_by_recency
        results = search_by_recency(
            self.memories,
            hours=hours,
            limit=limit * 3 if (session_id or source_channel) else limit,  # over-fetch for post-filter
            exclude_channel=exclude_channel,
        )
        # v5.6: post-filter by session_id and source_channel
        if session_id:
            results = [m for m in results if getattr(m, 'session_id', '') == session_id]
        if source_channel:
            results = [m for m in results if getattr(m, 'source_channel', '') == source_channel]
        return results[:limit]

    # ── ingestion ───────────────────────────────────────────────────────

    def ingest(
        self,
        content: str,
        source: str = "inline",
        category: str = "general",
        memory_type: str = DEFAULT_TYPE,
        type_config: Optional[Dict] = None,
        tags: Optional[List[str]] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        channel_id: Optional[str] = None,
        source_url: Optional[str] = None,
        content_hash: Optional[str] = None,
        source_channel: Optional[str] = None,
    ) -> int:
        """Ingest raw text. Returns count of new memories added.

        Sprint 2: accepts optional *memory_type* and *type_config* to attach
        structured type information to each entry.  Backward-compatible —
        existing callers that don't pass these get episodic defaults.

        Args:
            content: Raw text to ingest (multi-line supported).
            source: Source label (file path, "inline", etc.).
            category: Category label (general, strategic, etc.).
            memory_type: One of the canonical types or a custom string.
                Defaults to "episodic".
            type_config: For custom types, a dict with optional keys
                decay_multiplier, importance_boost, recall_priority.
            tags: Optional explicit tags to merge with auto-extracted tags.
        """
        cfg = get_type_config(memory_type, type_config)
        count = 0
        for i, line in enumerate(content.split("\n")):
            stripped = line.strip()
            if len(stripped) < 15 or stripped.startswith("```") or stripped == "---":
                continue
            # v4.6.6: reject raw JSON metadata lines (conversation_label, sender_id etc.)
            if _METADATA_LINE_RE.match(stripped):
                continue
            
            # v4.9.9 — Pipeline ingest quality gate (conversation noise only)
            _is_pipeline = source.startswith('pipeline:') or source == 'agent_turn'
            if _is_pipeline:
                if len(stripped) < 80:
                    continue  # v5.0.2: raised from 40 — short fragments aren't memories
                # v5.0.2: reject conversation noise (acknowledgments, status messages)
                if _CONVERSATION_NOISE_RE.match(stripped):
                    continue
                # Skip pure code lines (indented code, variable assignments)
                if _CODE_LINE_RE.match(stripped):
                    continue
                # Skip table formatting
                if stripped.startswith('|') and '---' in stripped:
                    continue
                if stripped.count('|') > 3 and len(stripped.split()) < 5:
                    continue
            
            # v4.9.9 — Credential scrubbing: never store API keys or tokens
            if _CREDENTIAL_RE.search(stripped):
                continue

            # v5.0.2 — Normalize content for dedup: strip Turn/INPUT/OUTPUT prefixes
            # so the same message stored as "Turn: X" and "INPUT: X" deduplicates.
            _content_for_dedup = stripped
            if _is_pipeline:
                _content_for_dedup = _TURN_PREFIX_RE.sub('', stripped).strip()

            entry = MemoryEntry(stripped, source, i + 1, category,
                                memory_type=memory_type,
                                agent_id=agent_id or self.agent_name,
                                session_id=session_id or "")
            # v4.7.0: stamp ingestion provenance
            if source_url is not None:
                entry.source_url = source_url
            if content_hash is not None:
                entry.content_hash = content_hash
            # v2.3.0: cross-channel recency recall
            if source_channel:
                entry.source_channel = source_channel
            if entry.hash in self._hashes:
                continue

            # v4.9.9 — Content-normalized dedup guard
            # v5.0.2 — Uses prefix-stripped content for pipeline sources
            _content_norm = _content_for_dedup.lower().strip()
            if _content_norm in self._content_norms:
                continue

            # Process through gating system
            gate_priority = self.gating.classify(stripped)
            if gate_priority == "P3":  # Skip noise
                continue

            entry.tags = self._extract_tags(stripped)
            # Merge caller-supplied tags with auto-extracted tags (Bug fix #12)
            if tags:
                entry.tags = sorted(set(entry.tags) | set(tags))

            # Layer 2 — CategoryTagger auto-tag + auto-categorise on ingest
            cat_tags = _ct.tag(stripped)
            for ct_tag in cat_tags:
                if ct_tag not in entry.tags:
                    entry.tags.append(ct_tag)
            # Only overwrite category if caller left it at default "general"
            if entry.category == "general" and cat_tags:
                entry.category = _ct.primary_category(stripped)

            entry.sentiment = self.sentiment.analyze(stripped)

                # v4.6.5 — LLM enrichment (non-fatal, optional)
            # v3.1 toggle wiring: respect runtime flags when present.
            # These are set by the OpenClaw bridge on the owning pipeline object.
            # Default behaviour stays the same for direct library users:
            # enrichment ON, decomposition OFF.
            enrichment = None  # Initialize to ensure variable exists
            enrichment_enabled = getattr(self, "_enrichment_enabled", True)
            decomposition_enabled = getattr(self, "_decomposition_enabled", False)
            if enrichment_enabled and self._enricher is not None:
                try:
                    enrichment = self._enricher(stripped)
                    if enrichment and isinstance(enrichment, dict):
                        if enrichment.get("tags"):
                            entry.tags = sorted(
                                set(entry.tags) | {t.lower() for t in enrichment["tags"]}
                            )
                        if enrichment.get("summary"):
                            entry.enriched_summary = str(enrichment["summary"])
                        if enrichment.get("keywords"):
                            entry.search_keywords = [
                                str(k).lower() for k in enrichment["keywords"]
                            ]
                        if enrichment.get("search_queries"):
                            entry.search_queries = [
                                str(q) for q in enrichment["search_queries"]
                            ]
                        # Feed enrichment relationships into co-occurrence index
                        self._feed_cooccurrence_from_enrichment(stripped, enrichment)
                        self._enrichment_count += 1
                except Exception:
                    logger.debug("LLM enrichment failed for entry", exc_info=True)
                    enrichment = None

            # v5.3: Fact decomposition — store atomic facts as separate entries
            if decomposition_enabled and self._enricher is not None and enrichment and isinstance(enrichment, dict):
                count += self._decompose_facts(
                    enrichment, entry, source, category,
                    session_id or "", agent_id,
                )

            # v5.3.1: Fuzzy dedup — if a new fact is very similar to an existing one,
            # link as a sighting instead of creating a duplicate
            if entry.memory_type == "fact":
                existing = self._find_similar_fact(entry.content, threshold=0.85)
                if existing is not None:
                    # Bump the canonical entry instead of adding a duplicate
                    self._bump_sighting(existing)
                    continue  # Skip adding the duplicate

            # Apply type importance boost
            boost = cfg.get("importance_boost", 1.0)
            if boost != 1.0:
                entry.importance = min(entry.importance * boost, self.decay.max_score)

            # Store type_config for custom types
            if type_config:
                entry.type_metadata["_type_config"] = type_config

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            _cn = _TURN_PREFIX_RE.sub('', entry.content).strip().lower()
            self._content_norms.add(_cn)  # v5.0.1 fix C-1
            if entry.memory_type == "fact":
                self._index_fact(entry)  # v5.4.0 — update dedup index for fact entries
            self.search_engine.mark_dirty()

            if self.use_indexing and self.index_manager:
                self.index_manager.add_memory(entry)

            # Sprint 11 — WAL append
            self._wal.append(entry.to_dict())

            # v4.9.2 — Index into memory graph (non-fatal)
            if self._graph_enabled and self._graph is not None:
                try:
                    self._graph.index_entry(entry.hash, entry.content)
                except Exception:
                    logger.debug("Graph index_entry failed for %s", entry.hash[:12], exc_info=True)

            # v4.6.0 — Write to time-window shard (when enterprise sharding off)
            if not self.use_sharding and self._v46_sharding and self._v46_shards:
                self._v46_shards.write_entry(entry)

            # v4.6.0 — Append to index WAL for incremental index tracking
            try:
                self._index_wal_writer.append(entry.to_dict())
                self._index_wal_entry_count += 1
            except Exception:
                logger.debug("Index WAL append failed; will rebuild on restart", exc_info=True)

            # v3.2 — Update local co-occurrence index (Tier 1 semantic)
            self._update_cooccurrence(stripped)

            count += 1

        # Invalidate read-cache on write
        if count and self._read_cache is not None:
            self._read_cache.invalidate()

        # v3.1.6 — proactive note capture
        try:
            proactive_key = session_id or agent_id or self.agent_name or "default"
            self.proactive.scan(proactive_key, content)
        except Exception:
            logger.debug("Proactive scan failed", exc_info=True)

        # Auto-flush if WAL threshold is reached
        if self._wal.should_flush():
            self.flush()

        # v4.6.0 — Flush index WAL when it reaches 500 entries
        if self._index_wal_entry_count >= 500:
            self._flush_v46_index()

        return count

    def checkpoint_conversation(
        self,
        turns: Iterable,
        agent_name: Optional[str] = None,
        timestamp: Optional[str] = None,
    ) -> str:
        """Append a conversation checkpoint to the daily memory markdown file."""
        return self.archive.checkpoint(
            turns,
            agent_name or self.agent_name or "agent",
            timestamp=timestamp,
        )

    def rotate_archive(self) -> int:
        """Rotate daily conversation logs older than 7 days into archive.md."""
        return self.archive.rotate()

    def search_archive(self, query: str, limit: int = 10) -> List[Dict[str, object]]:
        """Search the conversation archive and active daily logs."""
        return self.archive.search_archive(query, limit=limit)

    def get_recent_archive(self, days: int = 3) -> str:
        """Return raw recent conversation logs from the last N daily files."""
        return self.archive.get_recent(days=days)

    def ingest_file(self, file_path: str, category: str = "tactical") -> int:
        """Ingest a single file."""
        if not os.path.exists(file_path):
            return 0
        
        try:
            with open(file_path, encoding="utf-8") as f:
                content = f.read()
            return self.ingest(content, source=file_path, category=category)
        except (OSError, UnicodeDecodeError):
            return 0

    def ingest_directory(self, dir_path: str, category: str = "tactical",
                        pattern: str = "*.md") -> int:
        """Ingest all matching files in a directory."""
        if not os.path.exists(dir_path):
            return 0
        
        total = 0
        for path in Path(dir_path).glob(pattern):
            if path.is_file():
                total += self.ingest_file(str(path), category)
        return total

    def ingest_bulk(
        self,
        items: List[str],
        source: str = "bulk",
        category: str = "general",
        memory_type: str = DEFAULT_TYPE,
        tags: Optional[List[str]] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> int:
        """Ingest a list of strings in a single deferred-flush pass.

        v5.5.0 — For large-scale ingest (1K+), this is significantly faster
        than calling ingest() in a loop because it raises the WAL flush
        threshold for the duration of the batch and does exactly one flush
        at the end. At 10K entries this is ~6× faster than loop ingest.

        The flush threshold is restored to its original value after the batch
        even if an exception is raised mid-batch (try/finally).

        Args:
            items: List of content strings to ingest (each treated as one entry).
            source: Source label applied to all entries.
            category: Category label applied to all entries.
            memory_type: Memory type applied to all entries.
            tags: Optional tags merged with auto-extracted tags on each entry.
            agent_id: Optional agent scope override.
            session_id: Optional session scope override.

        Returns:
            Total number of new memories added.
        """
        if not items:
            return 0

        # Defer WAL flush for the duration of the batch (only if WAL supports it).
        # Guard with hasattr so mocked/stubbed WALs in tests don't raise AttributeError
        # before the try block, which would skip the finally and leave flush_interval unrestored.
        _has_flush_control = hasattr(self._wal, 'flush_interval')
        original_flush_interval = self._wal.flush_interval if _has_flush_control else None
        if _has_flush_control:
            # Set flush interval high enough to cover the entire batch
            self._wal.flush_interval = len(items) + 1
        total = 0
        try:
            for item in items:
                total += self.ingest(
                    item,
                    source=source,
                    category=category,
                    memory_type=memory_type,
                    tags=tags,
                    agent_id=agent_id,
                    session_id=session_id,
                )
        finally:
            if _has_flush_control and original_flush_interval is not None:
                self._wal.flush_interval = original_flush_interval
            try:
                self.flush()
            except Exception:
                pass  # WAL entries are safe; flush will be retried on next auto-flush

        return total

    # ── Sprint 2: typed ingest methods ──────────────────────────────────

    def ingest_mistake(
        self,
        what_happened: str,
        correction: str,
        root_cause: Optional[str] = None,
        severity: str = "medium",
        tags: Optional[List[str]] = None,
        source: str = "mistake",
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Optional[MemoryEntry]:
        """Ingest a structured mistake memory.

        Mistakes receive 2× importance, 10× half-life, and are surfaced
        proactively in context packets via the "Known Pitfalls" section.

        Args:
            what_happened: Brief description of what went wrong.
            correction: What should be done instead.
            root_cause: Why it happened (optional but strongly recommended).
            severity: "high", "medium", or "low" (default "medium").
            tags: Extra tags to attach.
            source: Source label (default "mistake").

        Returns:
            The created MemoryEntry, or None if duplicate.
        """
        if severity not in SEVERITY_LEVELS:
            severity = "medium"

        content = format_mistake_content(what_happened, correction, root_cause, severity)
        cfg = MEMORY_TYPE_CONFIGS["mistake"]

        entry = MemoryEntry(content, source, 0, "mistake", memory_type="mistake",
                            agent_id=agent_id or self.agent_name,
                            session_id=session_id or "")
        if entry.hash in self._hashes:
            return None
        _cn = _TURN_PREFIX_RE.sub('', entry.content).strip().lower()  # v5.0.1 fix C-2
        if _cn in self._content_norms:  # v5.0.1 fix C-2 — catch content-norm dupes missed by hash check
            return None

        entry.importance = min(1.0 * cfg["importance_boost"], self.decay.max_score)
        entry.tags = list(set(["mistake", f"severity:{severity}"] + (tags or [])))
        entry.sentiment = self.sentiment.analyze(content)
        entry.type_metadata = {
            "what_happened": what_happened,
            "correction": correction,
            "root_cause": root_cause,
            "severity": severity,
        }

        self.memories.append(entry)
        self._hashes.add(entry.hash)
        self._content_norms.add(_cn)  # v5.0.1 fix C-1/C-2 — _cn computed above before dup checks
        self.search_engine.mark_dirty()

        if self.use_indexing and self.index_manager:
            self.index_manager.add_memory(entry)

        # Sprint 11 — WAL
        self._wal.append(entry.to_dict())
        if self._read_cache is not None:
            self._read_cache.invalidate()
        if self._wal.should_flush():
            self.flush()

        return entry

    def ingest_fact(
        self,
        content: str,
        source: str = "fact",
        tags: Optional[List[str]] = None,
        category: str = "general",
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> int:
        """Ingest a fact-type memory (normal decay, high recall priority)."""
        return self._ingest_typed(
            content, source, category, "fact", tags=tags,
            agent_id=agent_id, session_id=session_id,
        )

    def ingest_preference(
        self,
        content: str,
        source: str = "preference",
        tags: Optional[List[str]] = None,
        category: str = "general",
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> int:
        """Ingest a preference-type memory (3x slower decay, high context-matched recall)."""
        return self._ingest_typed(
            content, source, category, "preference", tags=tags,
            agent_id=agent_id, session_id=session_id,
        )

    def ingest_procedure(
        self,
        content: str,
        source: str = "procedure",
        tags: Optional[List[str]] = None,
        category: str = "general",
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> int:
        """Ingest a procedure-type memory (3x slower decay, high task-matched recall)."""
        return self._ingest_typed(
            content, source, category, "procedure", tags=tags,
            agent_id=agent_id, session_id=session_id,
        )

    def _ingest_typed(
        self,
        content: str,
        source: str,
        category: str,
        memory_type: str,
        tags: Optional[List[str]] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> int:
        """Helper: ingest one or more lines with a specific memory type.

        Feature 2 fix: applies the same P0-P3 input gating that ``ingest()``
        uses so that P3 (ephemeral) content is never silently stored via the
        typed-ingest helpers.
        """
        cfg = get_type_config(memory_type)
        count = 0
        for i, line in enumerate(content.split("\n")):
            stripped = line.strip()
            if len(stripped) < 15 or stripped.startswith("```") or stripped == "---":
                continue
            # v4.6.6: reject raw JSON metadata lines
            if _METADATA_LINE_RE.match(stripped):
                continue

            # Feature 2: apply gating — drop P3 noise
            if not self.gating.should_store(stripped):
                continue

            entry = MemoryEntry(stripped, source, i + 1, category,
                                memory_type=memory_type,
                                agent_id=agent_id or self.agent_name,
                                session_id=session_id or "")
            if entry.hash in self._hashes:
                continue
            _cn = _TURN_PREFIX_RE.sub('', entry.content).strip().lower()  # v5.0.1 fix C-2
            if _cn in self._content_norms:  # v5.0.1 fix C-2 — catch content-norm dupes missed by hash check
                continue

            entry.importance = min(1.0 * cfg.get("importance_boost", 1.0),
                                   self.decay.max_score)
            entry.tags = list(set([memory_type] + self._extract_tags(stripped) + (tags or [])))

            # Layer 2 — CategoryTagger auto-tag + auto-categorise on ingest
            cat_tags = _ct.tag(stripped)
            for ct_tag in cat_tags:
                if ct_tag not in entry.tags:
                    entry.tags.append(ct_tag)
            if entry.category == "general" and cat_tags:
                entry.category = _ct.primary_category(stripped)

            entry.sentiment = self.sentiment.analyze(stripped)

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            if entry.memory_type == "fact": self._index_fact(entry)  # v5.4.0
            self._content_norms.add(_cn)  # v5.0.1 fix C-1/C-2 — _cn computed above before dup checks
            self.search_engine.mark_dirty()

            if self.use_indexing and self.index_manager:
                self.index_manager.add_memory(entry)

            # Sprint 11 — WAL
            self._wal.append(entry.to_dict())
            count += 1

        if count:
            if self._read_cache is not None:
                self._read_cache.invalidate()
            if self._wal.should_flush():
                self.flush()

        return count

    # ── analysis & synthesis ────────────────────────────────────────────

    def analyze(self, query: str, limit: int = 10) -> Dict:
        """Analyze memories related to a query."""
        memories = self.search(query, limit=limit)
        if not memories:
            return {"status": "no_results", "query": query}
        
        # Basic analysis (can be enhanced)
        categories = defaultdict(int)
        sentiment_scores = []
        date_range = []
        
        for memory in memories:
            if memory.category:
                categories[memory.category] += 1
            if memory.sentiment and 'compound' in memory.sentiment:
                sentiment_scores.append(memory.sentiment['compound'])
            date_range.append(memory.created[:10])
        
        return {
            "status": "success",
            "query": query,
            "total_memories": len(memories),
            "categories": dict(categories),
            "avg_sentiment": sum(sentiment_scores) / len(sentiment_scores) if sentiment_scores else 0,
            "date_range": [min(date_range), max(date_range)] if date_range else [],
            "sample_memories": [m.content[:100] for m in memories[:3]]
        }

    def synthesize_knowledge(self, topic: str, limit: int = 20) -> Optional[str]:
        """Generate knowledge synthesis using the KnowledgeSynthesizer."""
        memories = self.search(topic, limit=limit)
        if not memories:
            return None
        
        memory_texts = [m.content for m in memories]
        return self.synthesis.synthesize(memory_texts, topic)

    # ── context packets ──────────────────────────────────────────────────

    def build_context_packet(
        self,
        task: str,
        tags: Optional[List[str]] = None,
        category: str = None,
        environment: Optional[Dict[str, str]] = None,
        instructions: Optional[List[str]] = None,
        max_memories: int = 15,
        max_tokens: int = 4000,
        min_relevance: float = 0.1,
        include_mistakes: bool = True,     # Sprint 2
        max_pitfalls: int = 5,             # Sprint 2
    ) -> "ContextPacket":
        """Build a context packet for sub-agent spawning.

        Searches the memory store for relevant context and packages it
        into a structured ContextPacket that can be injected into a
        sub-agent's prompt at spawn time.

        Solves the "cold spawn" problem: sub-agents start with zero
        context, leading to confident mistakes based on incomplete
        information. A context packet gives them relevant onboarding.

        Args:
            task: Description of the sub-agent's task (used as search query).
            tags: Optional tag filters to narrow search.
            category: Optional category filter.
            environment: Key-value pairs (e.g. {"venv": "venv-svi", "python": "3.11"}).
            instructions: Explicit constraints for the sub-agent.
            max_memories: Maximum memories to include (default 15).
            max_tokens: Token budget for rendered output (default 4000).
            min_relevance: Minimum relevance score (default 0.1).

        Returns:
            ContextPacket with .render(), .to_dict(), .trim() methods.

        Example::

            packet = mem.build_context_packet(
                task="Verify package installation in venv",
                environment={"venv": "venv-svi"},
                instructions=["Check the venv, not global pip"],
            )
            prompt = f"{packet.render()}\\n\\nYOUR TASK: verify installation"
        """
        builder = ContextPacketBuilder(self)
        return builder.build(
            task=task,
            tags=tags,
            category=category,
            environment=environment,
            instructions=instructions,
            max_memories=max_memories,
            max_tokens=max_tokens,
            min_relevance=min_relevance,
            include_mistakes=include_mistakes,
            max_pitfalls=max_pitfalls,
        )

    def build_context_packet_multi(
        self,
        task: str,
        queries: List[str],
        environment: Optional[Dict[str, str]] = None,
        instructions: Optional[List[str]] = None,
        max_memories: int = 15,
        max_tokens: int = 4000,
        min_relevance: float = 0.1,
    ) -> "ContextPacket":
        """Build a context packet from multiple search queries.

        Useful when a task spans multiple topics. Deduplicates results
        across queries and merges into a single packet.

        Args:
            task: Overall task description.
            queries: List of search queries to run.
            environment: Optional environment context.
            instructions: Optional constraints.
            max_memories: Max total memories.
            max_tokens: Token budget.
            min_relevance: Minimum relevance threshold.

        Returns:
            Merged ContextPacket with deduplicated results.
        """
        builder = ContextPacketBuilder(self)
        return builder.build_multi(
            task=task,
            queries=queries,
            environment=environment,
            instructions=instructions,
            max_memories=max_memories,
            max_tokens=max_tokens,
            min_relevance=min_relevance,
        )

    # ── utility methods ─────────────────────────────────────────────────

    # ── Sprint 11: access pattern learning ──────────────────────────────

    def _record_access(self, entry_id: str) -> None:
        """Increment the access count for a memory entry.

        Called automatically by ``search()`` for every returned result.
        Persisted to ``access_counts.json`` on the next ``flush()``.
        """
        self._access_tracker.record_access(entry_id)

    def get_hot_entries(self, top_n: int = 10) -> List[MemoryEntry]:
        """Return the *top_n* most frequently accessed memory entries.

        Useful for pre-loading important context into packets.

        Args:
            top_n: Number of hot entries to return.

        Returns:
            List of MemoryEntry objects, ordered by access count descending.
        """
        top_ids = self._access_tracker.get_top(top_n)
        hash_to_entry = {m.hash: m for m in self.memories}
        result = []
        for entry_id, _count in top_ids:
            if entry_id in hash_to_entry:
                result.append(hash_to_entry[entry_id])
        return result

    def _extract_tags(self, content: str) -> List[str]:
        """Extract tags from content."""
        tags = []
        content_lower = content.lower()
        
        # Extract explicit tags (@tag format)
        explicit_tags = re.findall(r'@([a-zA-Z][a-zA-Z0-9_-]*)', content)
        tags.extend(explicit_tags)
        
        # Auto-tag based on terms
        for term in self._tag_terms:
            if term.lower() in content_lower:
                tags.append(term)
        
        return list(set(tags))  # Remove duplicates

    def compact(self) -> Dict:
        """Compact memory storage: remove duplicates, expire stale entries, save.

        Sprint 11: returns a richer result dict with shard counts and timing.

        Returns::

            {
                "shards_before": int,
                "shards_after": int,
                "entries_before": int,
                "entries_after": int,
                "space_freed_mb": float,
                "duration_ms": float,
                # backward-compat keys still present:
                "original_count": int,
                "final_count": int,
                "removed_count": int,
            }
        """
        _t0 = time.monotonic()

        # Snapshot shard count and disk usage before compaction
        shards_before = 0
        disk_before = 0.0
        if self.use_sharding and self.shard_manager:
            shards_dir = os.path.join(self.workspace, "shards")
            if os.path.isdir(shards_dir):
                shards_before = len([
                    f for f in os.listdir(shards_dir) if f.endswith(".json")
                ])
                disk_before = sum(
                    os.path.getsize(os.path.join(shards_dir, f))
                    for f in os.listdir(shards_dir) if f.endswith(".json")
                ) / (1024 * 1024)

        entries_before = len(self.memories)

        # Remove exact duplicates (by hash)
        seen_hashes: set = set()
        unique_memories = []
        for memory in self.memories:
            if memory.hash not in seen_hashes:
                unique_memories.append(memory)
                seen_hashes.add(memory.hash)

        # Apply decay-based forgetting: drop entries whose decay score is 0
        # (effectively dead entries that will never be recalled)
        # H-4 fix: also retain entries with an enriched_summary (even if decay==0)
        # so that LLM-enriched entries are never silently dropped by compaction.
        retained_memories = [
            m for m in unique_memories
            if self.decay.score(m) > 0.0 or bool(getattr(m, 'enriched_summary', None))
        ]

        # Use consolidation to detect near-duplicate pairs; keep the
        # higher-confidence entry from each pair.
        dup_pairs = self.consolidation.find_duplicates(retained_memories)
        hashes_to_drop: set = set()
        for mem_a, mem_b in dup_pairs:
            # Drop whichever has lower confidence (or the second if tied)
            loser = mem_b if mem_a.confidence >= mem_b.confidence else mem_a
            hashes_to_drop.add(loser.hash)
        consolidated_memories = [
            m for m in retained_memories if m.hash not in hashes_to_drop
        ]

        self.memories = consolidated_memories
        self._rebuild_content_indexes()
        self.search_engine.mark_dirty()

        # Invalidate cache — data has changed
        if self._read_cache is not None:
            self._read_cache.invalidate()

        # Rebuild indexes after compaction
        if self.use_indexing and self.index_manager:
            self.index_manager.rebuild_indexes(self.memories)

        # Flush compacted state to disk first, then rewrite the WAL to keep only
        # entries that were appended after the compaction snapshot began.
        pending_entries = self._wal.load_pending()
        pending_hashes = {entry.get("hash") for entry in pending_entries if entry.get("hash")}
        self.save()
        remaining_entries = []
        for entry in self._wal.load_pending():
            entry_hash = entry.get("hash")
            if entry_hash and entry_hash in pending_hashes:
                continue
            remaining_entries.append(entry)
        if remaining_entries:
            self._wal.replace_with_entries(remaining_entries)
        else:
            self._wal.clear()
        self._perf.record_compaction()

        # Snapshot shard count and disk usage after compaction
        shards_after = 0
        disk_after = 0.0
        if self.use_sharding and self.shard_manager:
            shards_dir = os.path.join(self.workspace, "shards")
            if os.path.isdir(shards_dir):
                shards_after = len([
                    f for f in os.listdir(shards_dir) if f.endswith(".json")
                ])
                disk_after = sum(
                    os.path.getsize(os.path.join(shards_dir, f))
                    for f in os.listdir(shards_dir) if f.endswith(".json")
                ) / (1024 * 1024)

        entries_after = len(self.memories)
        duration_ms = round((time.monotonic() - _t0) * 1000, 1)

        return {
            # Sprint 11 spec keys
            "shards_before": shards_before,
            "shards_after": shards_after,
            "entries_before": entries_before,
            "entries_after": entries_after,
            "space_freed_mb": round(max(disk_before - disk_after, 0.0), 3),
            "duration_ms": duration_ms,
            # Backward-compatible keys
            "original_count": entries_before,
            "final_count": entries_after,
            "removed_count": entries_before - entries_after,
        }

    # ── system management ───────────────────────────────────────────────

    def get_stats(self) -> Dict:
        """Get comprehensive system statistics."""
        from . import __version__ as _pkg_version  # Bug fix: add package version to stats
        stats = {
            "schema_version": "0.4.0",    # storage format version (used by migration logic)
            "package_version": _pkg_version,  # parsica-memory package version
            "total_memories": len(self.memories),
            "workspace": self.workspace,
            "features": {
                "sharding": self.use_sharding,
                "indexing": self.use_indexing
            }
        }
        
        if self.use_sharding and self.shard_manager:
            stats["sharding"] = self.shard_manager.index.get_stats()
        
        if self.use_indexing and self.index_manager:
            stats["indexing"] = self.index_manager.get_combined_stats()

        # M-1 fix: expose whether SemanticExpander loaded its word_expansion.json
        stats["expander_loaded"] = bool(self._expander) if self._expander is not None else False

        # Memory distribution by category
        categories = defaultdict(int)
        for memory in self.memories:
            categories[memory.category or "uncategorized"] += 1
        stats["categories"] = dict(categories)
        
        return stats

    def migrate_to_v4(self) -> Dict:
        """Manually trigger migration to v0.4 format."""
        return self.migration_manager.migrate("0.4.0")
    
    def rollback_migration(self) -> Dict:
        """Rollback the most recent migration."""
        return self.migration_manager.rollback()
    
    def validate_data(self) -> Dict:
        """Validate the current data schema."""
        return self.migration_manager.validate_schema()
    
    def rebuild_indexes(self):
        """Rebuild all search indexes from current memories."""
        if self.use_indexing and self.index_manager:
            self.index_manager.rebuild_indexes(self.memories)
            self.index_manager.save_all_indexes()
    
    def get_migration_history(self) -> List[Dict]:
        """Get history of applied migrations."""
        return self.migration_manager.get_migration_history()

    # ── Backward-compatible methods from v0.3 ──────────────────────

    def stats(self) -> Dict:
        """System statistics including Sprint 11 performance metrics.

        Backward-compatible — all v0.3/v0.4 keys are preserved.  New Sprint 11
        keys are added under their own names.

        Returns::

            {
                # v0.3 compat keys
                "total": int,
                "avg_score": float,
                "archive_candidates": int,
                "sentiments": dict,
                "avg_confidence": float,
                "categories": dict,
                # Sprint 11 performance keys
                "total_entries": int,
                "total_shards": int,
                "search_count": int,
                "avg_search_time_ms": float,
                "cache_hit_rate": float,
                "wal_pending_entries": int,
                "last_compaction": str | None,
                "disk_usage_mb": float,
                "memory_usage_mb": float,
            }
        """
        s = self.get_stats()
        now = datetime.now(timezone.utc)
        scores = [self.decay.score(m, now) for m in self.memories]
        sentiments: Dict[str, int] = defaultdict(int)
        for m in self.memories:
            dom = self.sentiment.dominant(m.sentiment)
            if dom:
                sentiments[dom] += 1
        # v0.3 compat
        s["total"] = len(self.memories)
        s["avg_score"] = round(sum(scores) / max(len(scores), 1), 4)
        s["archive_candidates"] = sum(1 for sc in scores if sc < self.decay.archive_threshold)
        s["sentiments"] = dict(sentiments)
        s["avg_confidence"] = round(
            sum(m.confidence for m in self.memories) / max(len(self.memories), 1), 4
        )

        # Sprint 11 performance metrics
        shards_count = 0
        disk_mb = 0.0
        if self.use_sharding and self.shard_manager:
            shards_dir = os.path.join(self.workspace, "shards")
            if os.path.isdir(shards_dir):
                shard_files = [
                    os.path.join(shards_dir, f)
                    for f in os.listdir(shards_dir) if f.endswith(".json")
                ]
                shards_count = len(shard_files)
                disk_mb = sum(os.path.getsize(p) for p in shard_files) / (1024 * 1024)

        import sys
        mem_mb = sys.getsizeof(self.memories) / (1024 * 1024)

        s["total_entries"] = len(self.memories)
        s["total_shards"] = shards_count
        s["search_count"] = self._perf.search_count
        s["avg_search_time_ms"] = self._perf.avg_search_time_ms
        s["cache_hit_rate"] = (
            round(self._read_cache.hit_rate, 4) if self._read_cache is not None else 0.0
        )
        s["wal_pending_entries"] = self._wal.pending_count()
        s["last_compaction"] = self._perf.last_compaction
        s["disk_usage_mb"] = round(disk_mb, 3)
        s["memory_usage_mb"] = round(mem_mb, 3)
        s["enrichment_count"] = self._enrichment_count

        # v4.9.2 additions
        try:
            import parsica_memory as _am
            s["version"] = getattr(_am, "__version__", "unknown")
        except Exception:
            s["version"] = "unknown"
        s["hot_entries"] = len(self.memories)
        s["warm_entries"] = len(getattr(self, '_warm_shard_names', []))
        s["cold_entries"] = len(getattr(self, '_cold_shard_names', []))
        s["wal_size"] = s["wal_pending_entries"]
        s["workspace"] = self.workspace
        s["agent_name"] = self.agent_name
        try:
            s["cooccurrence_pairs"] = len(self._cooccurrence._index) if hasattr(
                self._cooccurrence, '_index') else 0
        except Exception:
            s["cooccurrence_pairs"] = 0
        try:
            s["cache_size"] = len(self._read_cache._cache) if (
                self._read_cache and hasattr(self._read_cache, '_cache')) else 0
        except Exception:
            s["cache_size"] = 0
        try:
            import json as _json
            cost_path = os.path.join(self.workspace, "memory", "enrichment_costs.json")
            if os.path.exists(cost_path):
                with open(cost_path) as _f:
                    _cost = _json.load(_f)
                s["enrichment_cost_usd"] = round(_cost.get("lifetime_usd", 0.0), 6)
            else:
                s["enrichment_cost_usd"] = round(self._enrichment_count * 0.00005, 6)
        except Exception:
            s["enrichment_cost_usd"] = 0.0
        try:
            _gstats = self.get_graph_stats()
            s["graph_enabled"] = _gstats.get("graph_enabled", False)
            s["graph_nodes"] = _gstats.get("node_count", 0)
            s["graph_edges"] = _gstats.get("edge_count", 0)
        except Exception:
            s["graph_enabled"] = False
            s["graph_nodes"] = 0
            s["graph_edges"] = 0

        return s

    def get_enrichment_count(self, reset: bool = False) -> int:
        """Return the number of enrichments performed since last reset.

        v4.6.5 — Used by the plugin to track cumulative enrichment costs.

        Args:
            reset: If True, resets the counter to 0 after reading.

        Returns:
            Count of enrichments since last reset (or since startup).
        """
        count = self._enrichment_count
        if reset:
            self._enrichment_count = 0
        return count

    def ingest_with_gating(self, content: str, source: str = "inline",
                           context: Dict = None) -> int:
        """Ingest with P0-P3 input classification. P3 content is dropped.
        
        Multi-line content is split and each line classified independently.
        """
        count = 0
        for i, line in enumerate(content.split("\n")):
            stripped = line.strip()
            # Bug fix: align minimum length with ingest() (was 5, now 15)
            if len(stripped) < 15:
                continue
            
            # v4.9.9 — Credential scrubbing: never store API keys or tokens
            if _CREDENTIAL_RE.search(stripped):
                continue
            gate_context = context or {}
            gate_context.update({"source": source, "line": i + 1})
            routing = self.gating.route(stripped, gate_context)
            if not routing["store"]:
                continue
            category = routing.get("category", "tactical")
            count += self.ingest(stripped, source=source, category=category)
        return count

    def on_date(self, date: str) -> List[MemoryEntry]:
        """Get memories from a specific date."""
        return self.temporal.on_date(self.memories, date)

    def between(self, start: str, end: str) -> List[MemoryEntry]:
        """Get memories between two dates."""
        return self.temporal.between(self.memories, start, end)

    def narrative(self, topic: str = None) -> str:
        """Build a narrative from memories, optionally filtered by topic."""
        return self.temporal.narrative(self.memories, topic=topic)

    def forget(self, topic: str = None, entity: str = None,
               before_date: str = None) -> Dict:
        """Selectively forget memories with audit trail.

        Bug fix (Bug 1): ForgettingEngine has no ``forget()`` method; instead
        it exposes ``forget_topic()``, ``forget_entity()``, and
        ``forget_before()``.  This method now delegates correctly and supports
        combining multiple criteria (applied in sequence).

        Args:
            topic: Remove all memories containing this topic string.
            entity: Remove all memories mentioning this entity.
            before_date: Remove all memories created before this date (YYYY-MM-DD).

        Returns:
            Dict with keys ``removed`` (list[MemoryEntry]) and ``audit`` (dict).
        """
        if topic is None and entity is None and before_date is None:
            return {"removed": [], "audit": self.forgetting.audit_log([])}

        current = list(self.memories)
        all_forgotten: List = []

        if topic is not None:
            current, forgotten = self.forgetting.forget_topic(current, topic)
            all_forgotten.extend(forgotten)

        if entity is not None:
            current, forgotten = self.forgetting.forget_entity(current, entity)
            all_forgotten.extend(forgotten)

        if before_date is not None:
            current, forgotten = self.forgetting.forget_before(current, before_date)
            all_forgotten.extend(forgotten)

        # Deduplicate (a memory might match multiple criteria)
        seen: set = set()
        unique_forgotten = []
        for m in all_forgotten:
            if m.hash not in seen:
                unique_forgotten.append(m)
                seen.add(m.hash)

        result = {
            "removed": unique_forgotten,
            "audit": self.forgetting.audit_log(unique_forgotten),
        }

        if unique_forgotten:
            removed_set = {m.hash for m in unique_forgotten}
            # Bug fix: `current` is already the post-forget filtered list from
            # forget_topic/forget_entity/forget_before — no need to re-filter.
            self.memories = current
            # M-5 fix: rebuild all dedup indexes so re-ingesting the same content
            # after a forget() is not blocked by stale entries.
            self._rebuild_content_indexes()
            self.search_engine.mark_dirty()
            if self._read_cache is not None:
                self._read_cache.invalidate()

            # P0 fix: purge forgotten entries from the WAL so they cannot
            # resurrect via _replay_wal() on next load.  Rewrite the WAL
            # keeping only entries whose hashes are NOT in the removed set.
            pending = self._wal.load_pending()
            surviving = [e for e in pending if e.get("hash") not in removed_set]
            if len(surviving) < len(pending):
                if surviving:
                    self._wal.replace_with_entries(surviving)
                else:
                    self._wal.clear()

            # Also purge from the v4.6 index WAL
            try:
                idx_reader = WALReader()
                idx_reader.open(self._index_wal_path)
                idx_entries = idx_reader.read_all()
                if idx_entries:
                    idx_surviving = [e for e in idx_entries if e.get("hash") not in removed_set]
                    if len(idx_surviving) < len(idx_entries):
                        idx_reader.clear()
                        self._index_wal_writer.close()
                        self._index_wal_writer = WALWriter()
                        self._index_wal_writer.open(self._index_wal_path)
                        for entry in idx_surviving:
                            self._index_wal_writer.append(entry)
                        self._index_wal_entry_count = len(idx_surviving)
            except Exception:
                logger.debug("Index WAL purge failed after forget; will rebuild on restart", exc_info=True)

            # Log to audit (before save so the trail is recorded even if
            # save hits an I/O error — audit is non-critical, durability is).
            for m in unique_forgotten:
                self._append_audit({"action": "forget", "hash": m.hash,
                                    "content_preview": m.content[:50],
                                    "timestamp": datetime.now(timezone.utc).isoformat()})

            # v2.6.1: Persist current truth to shard/legacy files.
            # Without this, time-shard mode would still have deleted entries
            # in the weekly JSONL files, causing resurrection on reload.
            self.save()

        return result

    def reindex(self) -> None:
        """Force a full search index rebuild."""
        self.search_engine.reindex(self.memories)

    def consolidate(self) -> Dict:
        """Run consolidation: dedup, clustering, contradiction detection."""
        return self.consolidation.run(self.memories)

    def compress_old(self, days: int = 7) -> list:
        """Compress memories older than N days."""
        mem_dir = os.path.join(self.workspace, "memory")
        return self.compression.compress_old_files(mem_dir, days)

    def synthesize(self, research_results: Dict = None) -> Dict:
        """Integrate research findings into memory."""
        report = self.synthesis.run_cycle(self.memories, research_results=research_results)
        # Add synthesized entries to memory store
        if report.get("synthesized_entries", 0) > 0 and "new_entries" in report:
            for entry_dict in report["new_entries"]:
                entry = MemoryEntry.from_dict(entry_dict)
                if "synthesis" not in entry.tags:
                    entry.tags.append("synthesis")
                self.memories.append(entry)
                if self.use_indexing and self.index_manager:
                    self.index_manager.add_memory(entry)
        return report

    def research_suggestions(self, limit: int = 5) -> List[Dict]:
        """Get suggestions for knowledge gaps."""
        return self.synthesis.suggest_research_topics(self.memories, limit=limit)

    # ── Feature 3: Export / Import API ─────────────────────────────────

    def export_active(self, range_name: str = "all", topic: Optional[str] = None,
                      format: str = "json") -> str:
        """Export active memories in json/markdown/jsonl formats."""
        return export_memories(self, range_name=range_name, topic=topic, format=format)

    def export_archive_view(self, range_name: str = "all", topic: Optional[str] = None,
                            format: str = "json") -> str:
        """Export archive view in json/markdown/jsonl formats."""
        return export_archive(self, range_name=range_name, topic=topic, format=format)

    def scan_proactive(self, user_id: str, text: str) -> List[Dict]:
        """Scan text for proactive notes. Delegates to ProactiveMemory.scan().

        Args:
            user_id: User identifier for note storage.
            text: Message text to scan for notable facts.

        Returns:
            List of noted fact dicts (category + surface_after).
        """
        return self.proactive.scan(user_id, text)

    def proactive_prune(self, key: Optional[str] = None, days: int = 7) -> int:
        """Prune old surfaced proactive notes."""
        return self.proactive.prune(key=key, days=days)

    def get_proactive(self, user_id: str, trigger: str = "") -> List[str]:
        """Get proactive surfaces for a user. Delegates to ProactiveMemory.surface().

        Args:
            user_id: User identifier.
            trigger: Optional trigger text (greeting triggers surfacing).

        Returns:
            List of note text strings that should be surfaced.
        """
        return self.proactive.surface(user_id, trigger)

    def export(self, output_path: str, include_metadata: bool = True) -> int:
        """Export all memories to a JSON file.

        Args:
            output_path: Destination file path.
            include_metadata: When True (default), includes full metadata
                (workspace path, export timestamp, version tag).  When False,
                only the ``entries`` list is included (useful for data portability).

        Returns:
            Count of exported entries.

        Format::

            {
                "version": "4.2",
                "exported_at": "<ISO 8601>",
                "workspace": "<path>",
                "entries": [
                    {
                        "content": str,
                        "source": str,
                        "category": str,
                        "memory_type": str,
                        "timestamp": str,
                        "score": float
                    },
                    ...
                ]
            }
        """
        now = datetime.now(timezone.utc)
        entries = []
        for m in self.memories:
            entry_dict = {
                "content": m.content,
                "source": getattr(m, "source", ""),
                "category": m.category or "general",
                "memory_type": getattr(m, "memory_type", "episodic"),
                "timestamp": m.created,
                "score": self.decay.score(m, now),
            }
            entries.append(entry_dict)

        # Always augment entries with hash so import_from() can deduplicate correctly
        for m, e in zip(self.memories, entries):
            e["_hash"] = m.hash

        if include_metadata:
            data: dict = {
                "version": "4.2",
                "exported_at": now.isoformat(),
                "workspace": self.workspace,
                "entries": entries,
            }
        else:
            data = {"entries": entries}

        atomic_write_json(output_path, data)
        return len(entries)

    def import_from(self, input_path: str, merge: bool = True) -> int:
        """Import memories from a JSON file exported by :meth:`export`.

        Args:
            input_path: Path to the JSON file produced by ``export()``.
            merge: When ``True`` (default) imported entries are *added* to the
                existing store — duplicates (same content hash) are skipped.
                When ``False`` the existing store is **replaced** with the
                imported entries.

        Returns:
            Count of imported entries (after deduplication when merge=True).
        """
        with open(input_path, encoding="utf-8") as fh:
            raw = json.load(fh)

        # Support both the versioned envelope {"entries": [...]} and a raw list
        if isinstance(raw, dict):
            entries_data = raw.get("entries", [])
        elif isinstance(raw, list):
            entries_data = raw
        else:
            return 0

        if not merge:
            # Replace mode: wipe existing store first
            self.memories = []
            self._rebuild_content_indexes()
            self.search_engine.mark_dirty()
            if self._read_cache is not None:
                self._read_cache.invalidate()

        count = 0
        for entry_dict in entries_data:
            if not isinstance(entry_dict, dict):
                continue
            try:
                # Build a MemoryEntry from the compact export format
                content = entry_dict.get("content", "")
                source = entry_dict.get("source", "import")
                category = entry_dict.get("category", "general")
                memory_type = entry_dict.get("memory_type", "episodic")

                entry = MemoryEntry(content, source, 0, category,
                                    memory_type=memory_type)

                # Restore original hash if present (exported by export()).
                # This ensures deduplication by content hash works correctly
                # even when the source/line combo differs on reimport.
                if "_hash" in entry_dict:
                    entry.hash = entry_dict["_hash"]

                # Restore timestamp if present
                if "timestamp" in entry_dict:
                    entry.created = entry_dict["timestamp"]
                    entry.last_accessed = entry_dict["timestamp"]
            except Exception:
                continue  # skip malformed entries

            if entry.hash in self._hashes:
                continue  # deduplicate

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            if entry.memory_type == "fact": self._index_fact(entry)  # v5.4.0
            _cn = _TURN_PREFIX_RE.sub('', entry.content).strip().lower()
            self._content_norms.add(_cn)  # v5.0.1 fix C-1
            count += 1

        if count:
            self.search_engine.mark_dirty()
            if self._read_cache is not None:
                self._read_cache.invalidate()

        return count

    def import_memories(self, path: str) -> int:
        """Backward-compat alias for :meth:`import_from` with merge=True.

        Args:
            path: Path to the JSON array file produced by ``export()``.

        Returns:
            Number of new entries added.
        """
        return self.import_from(path, merge=True)

    # ── shared pool integration ──────────────────────────────────────────

    def enable_shared_pool(
        self,
        pool_dir: str,
        pool_name: str = "default",
        agent_id: str = None,
        role: str = "write",
        load_existing: bool = True,
    ) -> "SharedMemoryPool":
        """Attach a SharedMemoryPool to this MemorySystem instance.

        Enables multi-agent memory sharing. The pool is created (or loaded)
        at pool_dir. This agent is registered with the given role.

        Args:
            pool_dir: Directory for the shared pool files.
            pool_name: Pool identifier (default "default").
            agent_id: This agent's ID in the pool. Defaults to the workspace basename.
            role: Access role — "read", "write", or "admin" (default "write").
            load_existing: If True, load an existing pool from disk (default True).

        Returns:
            The attached SharedMemoryPool instance.
        """
        if agent_id is None:
            agent_id = os.path.basename(self.workspace.rstrip("/"))

        pool = SharedMemoryPool(pool_dir, pool_name)
        if load_existing:
            pool.load()

        # Register if not already registered
        if agent_id not in pool.permissions:
            pool.register_agent(agent_id, role)

        self._shared_pool = pool
        self._shared_agent_id = agent_id
        return pool

    def get_shared_pool(self) -> Optional["SharedMemoryPool"]:
        """Return the attached SharedMemoryPool, or None if not enabled."""
        return self._shared_pool

    def shared_write(
        self,
        content: str,
        namespace: str = "shared",
        category: str = "general",
        metadata: dict = None,
    ) -> Optional[object]:
        """Write a memory to the attached shared pool.

        Raises RuntimeError if no shared pool is attached (call enable_shared_pool first).
        """
        if self._shared_pool is None:
            raise RuntimeError("No shared pool attached. Call enable_shared_pool() first.")
        return self._shared_pool.write(
            self._shared_agent_id, content, namespace, category, metadata
        )

    def shared_search(
        self,
        query: str,
        namespace: str = None,
        limit: int = 20,
        instrumentation_context=None,
    ) -> list:
        """Search the attached shared pool.

        If instrumentation_context is provided (a SearchContext), populates
        retrieved_memory_ids for later mark_used() calls.

        Raises RuntimeError if no shared pool is attached.
        """
        if self._shared_pool is None:
            raise RuntimeError("No shared pool attached. Call enable_shared_pool() first.")

        if hasattr(self._shared_pool, 'search_with_context') and instrumentation_context is not None:
            results, _ = self._shared_pool.search_with_context(
                self._shared_agent_id, query, instrumentation_context, limit, namespace
            )
        else:
            results = self._shared_pool.read(
                self._shared_agent_id, query, namespace, limit
            )
        return results

    def shared_mark_used(
        self,
        memory_ids: list,
        boost_factor: float = 1.3,
    ) -> int:
        """Signal that retrieved shared memories were used in a response.

        Triggers cross-agent relevance boosting for memories written by other agents.

        Returns:
            Number of memories boosted.
        """
        if self._shared_pool is None:
            raise RuntimeError("No shared pool attached.")
        return self._shared_pool.mark_used_batch(
            self._shared_agent_id, memory_ids, boost_factor
        )

    def _append_audit(self, entry: Dict) -> None:
        """Append an entry to the audit log."""
        audit = []
        if os.path.exists(self.audit_path):
            with open(self.audit_path) as f:
                audit = json.load(f)
        audit.append(entry)
        atomic_write_json(self.audit_path, audit)

    # ── v3.2 Instrumentation ──────────────────────────────────────────────────

    def mark_retrieved(self, memory_ids: List[str], context) -> None:
        """Record that a set of memories were retrieved for a query.

        Called automatically when instrumentation_context is passed to search().
        Logs the retrieval event to the instrumentation log for later analysis.

        Args:
            memory_ids: List of memory hashes that were retrieved.
            context: SearchContext object for this search request.
        """
        context.retrieved_memory_ids = list(memory_ids)
        event = {
            "event": "retrieved",
            "request_id": context.request_id,
            "query": context.query,
            "memory_ids": memory_ids,
            "count": len(memory_ids),
            "timestamp": context.timestamp,
            "context_id": context.context_id,
        }
        try:
            with open(self._instrumentation_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")
        except OSError:
            pass  # Instrumentation failures are non-fatal

    def mark_used(self, memory_ids: List[str], context=None) -> int:
        """Signal that specific memories were used in the agent's response.

        Boosts the relevance of used memories and resets their decay age.
        Optionally logs a usage signal if opt_in_to_aggregation is True.

        Args:
            memory_ids: List of memory hashes that appeared in the response.
            context: Optional SearchContext for linking to the retrieval event.

        Returns:
            Number of memories successfully boosted.
        """
        if context is not None:
            context.used_memory_ids = list(memory_ids)

        boosted = 0
        for memory_id in memory_ids:
            if self.boost_relevance(memory_id):
                boosted += 1

        # Log usage event
        event = {
            "event": "used",
            "memory_ids": memory_ids,
            "count": len(memory_ids),
            "timestamp": time.time(),
            "request_id": context.request_id if context else None,
        }
        try:
            with open(self._instrumentation_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")
        except OSError:
            pass

        # Log to audit logger if available
        if context is not None and hasattr(context, 'audit_logger') and context.audit_logger is not None:
            try:
                for memory_id in memory_ids:
                    context.audit_logger.log("recall", {
                        "memory_id": memory_id,
                        "context_id": context.context_id,
                        "request_id": context.request_id,
                        "session_id": context.session_id,
                    })
            except Exception:
                # Audit logging failures are non-fatal
                pass

        # Report anonymized signal if user opted in
        if self.opt_in_to_aggregation and context is not None:
            from .instrumentation import build_usage_signal
            self.report_usage_signal(build_usage_signal(context))

        # Invalidate cache so boosted memories rank higher on next search
        if boosted and self._read_cache is not None:
            self._read_cache.invalidate()

        return boosted

    def boost_relevance(self, memory_id: str, multiplier: float = 1.5) -> bool:
        """Boost the importance/relevance of a memory by ID.

        Increases the memory's importance score and resets its decay age,
        making it surface higher in future searches.

        Args:
            memory_id: The memory hash to boost.
            multiplier: Importance multiplier (default 1.5 = 50% boost).

        Returns:
            True if the memory was found and boosted, False otherwise.
        """
        for entry in self.memories:
            if entry.hash == memory_id:
                entry.importance = min(entry.importance * multiplier, 10.0)
                # Reset decay: freshen the memory as if it was just accessed
                entry.last_accessed = datetime.now(timezone.utc).isoformat()
                entry.access_count += 1
                self.search_engine.mark_dirty()
                return True
        return False

    def report_usage_signal(self, data: Dict) -> None:
        """Append an anonymized usage signal for crowdsourced PPMI training.

        Only writes when opt_in_to_aggregation is True. Data contains only
        statistical information — never actual memory content.

        Args:
            data: Anonymized signal dict from build_usage_signal().
        """
        if not self.opt_in_to_aggregation:
            return
        try:
            with open(self._usage_signals_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(data) + "\n")
        except OSError:
            pass

    # ── v3.2 Co-occurrence Semantic Boost ──────────────────────────────────────

    def search_with_context(
        self,
        query: str,
        limit: int = 20,
        instrumentation_context=None,
        cooccurrence_boost: bool = True,
        **kwargs,
    ) -> tuple:
        """Search memories with optional instrumentation and co-occurrence boost.

        Returns (results, SearchContext) for use with mark_used().

        Args:
            query: Search query string.
            limit: Maximum results to return.
            instrumentation_context: Optional pre-built SearchContext.
                If None, one is created automatically.
            cooccurrence_boost: Whether to apply local co-occurrence re-ranking.
            **kwargs: Additional args forwarded to search() (explain, category, etc.)

        Returns:
            Tuple of (results, SearchContext).
        """
        from .instrumentation import SearchContext

        ctx = instrumentation_context or SearchContext(query=query)

        # Run BM25 search (fetch extra for re-ranking)
        fetch_limit = limit * 2 if cooccurrence_boost else limit
        results = self.search(query, limit=fetch_limit, explain=True, **kwargs)

        # Co-occurrence re-ranking (Tier 1 semantic boost)
        if cooccurrence_boost and self._cooccurrence.vocab_size > 0:
            for r in results:
                boost = self._cooccurrence.boost_score(query, r.entry.content)
                r.score += boost

            results.sort(key=lambda r: r.score, reverse=True)

        results = results[:limit]

        # Record retrieval for instrumentation
        retrieved_ids = [r.entry.hash for r in results]
        self.mark_retrieved(retrieved_ids, ctx)

        # Return plain entries by default (backward compat), explain if needed
        if kwargs.get("explain"):
            return results, ctx

        entries = []
        for r in results:
            entry_copy = copy.copy(r.entry)
            entry_copy.confidence = r.relevance
            entries.append(entry_copy)
        return entries, ctx

    def _update_cooccurrence(self, content: str) -> None:
        """Update the local co-occurrence index when a memory is stored.

        Note: does NOT save to disk on every call — deferred to flush() to
        avoid O(n) disk writes during bulk ingestion (e.g. ingest_directory).
        """
        self._cooccurrence.update_from_memory(content)

    def _feed_cooccurrence_from_enrichment(self, original: str, enrichment: dict) -> None:
        """Feed enrichment-derived semantic relationships into the co-occurrence index.

        Constructs a virtual sentence from enrichment tags + keywords + original
        terms, then passes it through update_from_memory so all semantic pairs
        are captured. This bootstraps the co-occurrence matrix with high-quality
        LLM-derived relationships even before natural conversational data accumulates.

        v4.6.5 — runs on every enriched ingest, non-fatal.
        """
        try:
            parts = []
            # Add original content tokens
            parts.append(original.lower())
            # Add enrichment tags (normalised to words)
            for tag in enrichment.get("tags", []):
                parts.append(tag.lower().replace("_", " "))
            # Add enrichment keywords
            for kw in enrichment.get("keywords", []):
                parts.append(str(kw).lower().replace("_", " "))
            # Add enriched summary if present
            if enrichment.get("summary"):
                parts.append(enrichment["summary"].lower())
            virtual_sentence = " ".join(parts)
            self._cooccurrence.update_from_memory(virtual_sentence)
        except Exception:
            pass  # Non-fatal

    def re_enrich(
        self,
        batch_size: int = 50,
        progress_fn=None,
        overwrite: bool = False,
        decompose: bool = False,
    ) -> int:
        """Re-enrich all existing memories through the configured enricher.

        Processes entries in batch_size chunks. Skips already-enriched entries
        unless overwrite=True. Rebuilds the search index after completion and
        saves all shards.

        v4.6.5 — bootstraps the co-occurrence matrix with 90K+ word pairs
        when run against an existing ~9,000 entry memory store.

        v5.3 — decompose=True (default) also extracts atomic facts from the
        enrichment response and stores them as separate MemoryEntry objects
        (memory_type="fact", provenance="decomposed"). Applies the same hash,
        content-norm, and fuzzy dedup checks as ingest(). Entries that are
        already facts themselves are never decomposed further.

        Args:
            batch_size: Progress callback fired every N enriched entries.
            progress_fn: Optional callable(enriched_count, total_count).
            overwrite: If True, re-enrich even entries that already have
                       an enriched_summary. Default False (idempotent).
            decompose: If True (default), extract and store atomic facts from
                       the enrichment response, mirroring the behaviour of
                       ingest(). Set to False to skip fact extraction (faster,
                       matches the original re_enrich behaviour).

        Returns:
            Count of entries enriched (fact entries created are not counted
            towards this total; use re_decompose() stats for that).
        """
        if self._enricher is None:
            return 0

        count = 0
        total = len(self.memories)
        # Snapshot to avoid iterating over newly-added fact entries
        snapshot = list(self.memories)

        for entry in snapshot:
            if not overwrite and getattr(entry, "enriched_summary", ""):
                continue  # Already enriched — skip unless overwrite requested

            try:
                enrichment = self._enricher(entry.content)
                if enrichment and isinstance(enrichment, dict):
                    if enrichment.get("tags"):
                        entry.tags = sorted(
                            set(entry.tags) | {t.lower() for t in enrichment["tags"]}
                        )
                    if enrichment.get("summary"):
                        entry.enriched_summary = str(enrichment["summary"])
                    if enrichment.get("keywords"):
                        entry.search_keywords = [
                            str(k).lower() for k in enrichment["keywords"]
                        ]
                    if enrichment.get("search_queries"):
                        entry.search_queries = [
                            str(q) for q in enrichment["search_queries"]
                        ]
                    self._feed_cooccurrence_from_enrichment(entry.content, enrichment)
                    self._enrichment_count += 1
                    count += 1

                    # v5.3: Fact decomposition — mirror ingest() behaviour
                    if decompose and entry.memory_type != "fact":
                        self._decompose_facts(
                            enrichment, entry, entry.source, entry.category,
                            getattr(entry, "session_id", ""),
                            getattr(entry, "agent_id", self.agent_name),
                        )

            except Exception:
                pass  # Non-fatal — leave entry as-is

            if progress_fn and (count % batch_size == 0) and count > 0:
                progress_fn(count, total)

        if count:
            # Rebuild search index with enriched content
            self.search_engine.mark_dirty()
            # Save all shards with updated entries
            try:
                self.save()
            except Exception:
                pass
            # Save co-occurrence index
            try:
                self._cooccurrence.save()
            except Exception:
                pass

        return count


    def re_decompose(
        self,
        batch_size: int = 50,
        progress_fn=None,
        overwrite: bool = False,
    ) -> int:
        """Extract atomic facts from existing memories and store as separate entries.

        v2.0: Runs the enricher on each memory to extract facts, then creates
        new fact-type entries with provenance="decomposed" and parent_hash linking
        back to the source. Applies fuzzy dedup to avoid duplicate facts.

        Args:
            batch_size: Progress callback fired every N processed entries.
            progress_fn: Optional callable(processed_count, total_count).
            overwrite: If True, re-decompose even entries that already spawned facts.
                Default False (skips entries whose hash appears as a parent_hash).

        Returns:
            Count of new fact entries created.
        """
        if self._enricher is None:
            return 0

        # Build set of parent hashes to skip already-decomposed entries
        existing_parents = set()
        if not overwrite:
            for m in self.memories:
                ph = getattr(m, "parent_hash", "")
                if ph:
                    existing_parents.add(ph)

        new_facts = 0
        processed = 0
        total = len(self.memories)
        # Snapshot the current memory list to avoid iterating over new additions
        snapshot = list(self.memories)

        for entry in snapshot:
            # Skip fact entries themselves (don't decompose facts into more facts)
            if entry.memory_type == "fact":
                continue
            # Skip already-decomposed entries unless overwrite
            if not overwrite and entry.hash in existing_parents:
                continue

            try:
                enrichment = self._enricher(entry.content)
                if not enrichment or not isinstance(enrichment, dict):
                    continue

                new_facts += self._decompose_facts(
                    enrichment, entry, entry.source, entry.category,
                    getattr(entry, "session_id", ""),
                    getattr(entry, "agent_id", self.agent_name),
                )

            except Exception:
                pass  # Non-fatal

            processed += 1
            if progress_fn and (processed % batch_size == 0) and processed > 0:
                progress_fn(processed, total, new_facts)

        if new_facts:
            self.search_engine.mark_dirty()
            try:
                self.save()
            except Exception:
                pass

        return new_facts

    # ── v4.7.0: Knowledge Ingestion methods ────────────────────────────────

    def ingest_url(self, url: str, depth: int = 1, incremental: bool = True) -> dict:
        """Ingest content from a URL into the memory system.

        Args:
            url: Web URL to crawl.
            depth: Link depth to follow (1 = single page).
            incremental: Skip chunks already known from previous crawls.

        Returns:
            {"ingested": N, "skipped_duplicates": M, "source_url": url}
        """
        try:
            from .ingest_web import WebCrawler
            from .ingest_manifest import IngestManifest

            crawler = WebCrawler()
            manifest = IngestManifest(self.workspace)

            known_hashes = manifest.get_known_hashes(url) if incremental else set()
            chunks = crawler.crawl(url, depth=depth)

            ingested = 0
            skipped = 0
            entry_ids = []

            for chunk in chunks:
                if chunk["content_hash"] in known_hashes:
                    skipped += 1
                    continue
                count = self.ingest(
                    chunk["text"],
                    source=url,
                    source_url=chunk["source_url"],
                    content_hash=chunk["content_hash"],
                )
                if count > 0:
                    ingested += count
                    entry_ids.append(chunk["content_hash"])
                else:
                    skipped += 1

            if entry_ids:
                manifest.update(url, entry_ids[-1], entry_ids)
                manifest.save()

            return {"ingested": ingested, "skipped_duplicates": skipped, "source_url": url}
        except Exception as e:
            import logging
            logging.getLogger("parsica_memory").error("ingest_url failed: %s", e)
            return {"ingested": 0, "skipped_duplicates": 0, "source_url": url, "error": str(e)}

    def ingest_data_file(self, path: str, format: str = "auto", **kwargs) -> dict:
        """Ingest structured data from a file (CSV, JSON, SQLite).

        Args:
            path: Path to the data file.
            format: "csv", "json", "sqlite", or "auto" (detect by extension).
            **kwargs: Extra args (text_columns for CSV, query for SQLite).

        Returns:
            {"ingested": N, "skipped_duplicates": M, "source_url": path}
        """
        try:
            from .ingest_structured import StructuredIngester
            from .ingest_manifest import IngestManifest

            ingester = StructuredIngester()
            manifest = IngestManifest(self.workspace)

            if format == "auto":
                ext = os.path.splitext(path)[1].lower()
                format = {".csv": "csv", ".json": "json", ".sqlite": "sqlite",
                          ".db": "sqlite", ".sqlite3": "sqlite", ".pdf": "pdf"}.get(ext, "json")

            if format == "csv":
                chunks = ingester.from_csv(path, text_columns=kwargs.get("text_columns"))
            elif format == "json":
                chunks = ingester.from_json(path)
            elif format == "sqlite":
                query = kwargs.get("query", "SELECT * FROM sqlite_master")
                chunks = ingester.from_sqlite(path, query)
            elif format == "pdf":
                from .ingest_pdf import PDFIngester
                chunks = PDFIngester().from_pdf(path)
            else:
                return {"ingested": 0, "skipped_duplicates": 0, "source_url": path,
                        "error": f"Unknown format: {format}"}

            source_url = f"file://{os.path.abspath(path)}"
            known_hashes = manifest.get_known_hashes(source_url)

            ingested = 0
            skipped = 0
            entry_ids = []

            for chunk in chunks:
                if chunk["content_hash"] in known_hashes:
                    skipped += 1
                    continue
                count = self.ingest(
                    chunk["text"],
                    source=path,
                    source_url=chunk["source_url"],
                    content_hash=chunk["content_hash"],
                    tags=[
                        t for t in [
                            "pdf" if format == "pdf" else None,
                            f"page:{chunk['page_number']}" if chunk.get("page_number") is not None else None,
                            chunk.get("extraction_method"),
                            "ocr_needed" if chunk.get("needs_ocr") else None,
                        ] if t
                    ],
                )
                if count > 0:
                    ingested += count
                    entry_ids.append(chunk["content_hash"])
                else:
                    skipped += 1

            if entry_ids:
                manifest.update(source_url, entry_ids[-1], entry_ids)
                manifest.save()

            return {"ingested": ingested, "skipped_duplicates": skipped, "source_url": path}
        except Exception as e:
            import logging
            logging.getLogger("parsica_memory").error("ingest_data_file failed: %s", e)
            return {"ingested": 0, "skipped_duplicates": 0, "source_url": path, "error": str(e)}

    def ingest_sql(self, db_path: str, query: str) -> dict:
        """Ingest data from a SQLite query.

        Args:
            db_path: Path to the SQLite database.
            query: SQL SELECT query.

        Returns:
            {"ingested": N, "skipped_duplicates": M, "source_url": db_path}
        """
        return self.ingest_data_file(db_path, format="sqlite", query=query)

    def delete_source(self, source_url: str) -> dict:
        """Remove all memories originating from a specific source URL.

        Args:
            source_url: The source_url to match against.

        Returns:
            {"deleted": N, "source_url": source_url}
        """
        try:
            from .ingest_manifest import IngestManifest

            to_remove = [m for m in self.memories
                         if getattr(m, "source_url", None) == source_url]
            removed_hashes = {m.hash for m in to_remove}

            self.memories = [m for m in self.memories if m.hash not in removed_hashes]
            # _rebuild_content_indexes() reconstructs _hashes, _content_norms,
            # and the fact dedup index from self.memories — no need to manually
            # subtract removed_hashes first.
            self._rebuild_content_indexes()

            if to_remove:
                self.search_engine.mark_dirty()
                if self._read_cache is not None:
                    self._read_cache.invalidate()

                # P0 fix: purge deleted entries from WAL to prevent resurrection
                pending = self._wal.load_pending()
                surviving = [e for e in pending if e.get("hash") not in removed_hashes]
                if len(surviving) < len(pending):
                    if surviving:
                        self._wal.replace_with_entries(surviving)
                    else:
                        self._wal.clear()

                # Also purge deleted entries from the v4.6 index WAL.
                # v2.6.1 fix: previous code used string / operator (TypeError)
                # and WALWriter methods that don't exist. Now uses WALReader
                # (same pattern as forget()).
                try:
                    idx_reader = WALReader()
                    idx_reader.open(self._index_wal_path)
                    idx_entries = idx_reader.read_all()
                    if idx_entries:
                        idx_surviving = [e for e in idx_entries if e.get("hash") not in removed_hashes]
                        if len(idx_surviving) < len(idx_entries):
                            idx_reader.clear()
                            self._index_wal_writer.close()
                            self._index_wal_writer = WALWriter()
                            self._index_wal_writer.open(self._index_wal_path)
                            for entry in idx_surviving:
                                self._index_wal_writer.append(entry)
                            self._index_wal_entry_count = len(idx_surviving)
                except Exception:
                    logger.debug("Index WAL purge failed after delete_source; will rebuild on restart", exc_info=True)

                # v2.6.1: Persist current truth to shard/legacy files.
                # Without this, time-shard mode would still have deleted entries
                # in the weekly JSONL files, causing resurrection on reload.
                self.save()

            # Clean manifest
            try:
                manifest = IngestManifest(self.workspace)
                manifest.remove(source_url)
                manifest.save()
            except Exception:
                pass

            return {"deleted": len(to_remove), "source_url": source_url}
        except Exception as e:
            import logging
            logging.getLogger("parsica_memory").error("delete_source failed: %s", e)
            return {"deleted": 0, "source_url": source_url, "error": str(e)}


    # ── v4.9.2: Graph Intelligence public API ────────────────────────────────

    def graph_search(
        self,
        subject: str,
        relation: str = None,
        obj: str = None,
    ) -> list:
        """
        Relationship-aware graph search.

        Examples:
          mem.graph_search("alice")                   → all relationships involving alice
          mem.graph_search("alice", "created_by")     → what did alice create?
          mem.graph_search("alice", obj="parsica")    → how are alice and parsica related?

        Returns list of (source, relation, target, entry_ids) tuples.
        Returns empty list if graph is disabled or entity not found.
        """
        try:
            if not self._graph_enabled or self._graph is None:
                return []
            return self._graph.relationship_search(subject, relation, obj)
        except Exception:
            return []

    def entity_path(self, source: str, target: str, max_hops: int = 3) -> list:
        """
        Find the relationship path between two entities in the memory graph.

        Returns list of entity canonicals from source → target (inclusive),
        or empty list if no path exists or graph is disabled.

        Example:
          mem.entity_path("alice", "parsica-memory")
          → ["alice", "created_by", "parsica-memory"]  (if path exists)
        """
        try:
            if not self._graph_enabled or self._graph is None:
                return []
            result = self._graph.find_path(source, target, max_hops=max_hops)
            return result or []
        except Exception:
            return []

    def get_entity(self, canonical: str) -> dict:
        """
        Get information about a specific entity in the memory graph.

        Returns dict with entity info or empty dict if not found.
        """
        try:
            if not self._graph_enabled or self._graph is None:
                return {}
            node = self._graph.get_node(canonical)
            if node is None:
                return {}
            from dataclasses import asdict
            return asdict(node)
        except Exception:
            return {}

    def get_health(self) -> dict:
        """
        Simple readiness check for monitoring / health endpoints.

        Returns:
          {"status": "ok", "checks": {<name>: True/False, ...}}

        Status is "ok" only when all checks pass.
        Non-fatal: any check that throws is marked False.
        """
        checks = {}

        # Workspace is accessible
        try:
            checks["workspace_accessible"] = os.path.isdir(self.workspace)
        except Exception:
            checks["workspace_accessible"] = False

        # Memory store has entries loaded
        try:
            checks["memories_loaded"] = len(self.memories) >= 0  # always true, 0 is fine
        except Exception:
            checks["memories_loaded"] = False

        # WAL is functional
        try:
            checks["wal_ok"] = self._wal is not None
        except Exception:
            checks["wal_ok"] = False

        # Search engine is responsive
        try:
            self.search("__health_check__", limit=1)
            checks["search_ok"] = True
        except Exception:
            checks["search_ok"] = False

        # Graph (if enabled)
        try:
            if self._graph_enabled:
                checks["graph_ok"] = self._graph is not None
            else:
                checks["graph_ok"] = True  # disabled = not a failure
        except Exception:
            checks["graph_ok"] = False

        # Bootstrap file size check — OpenClaw injects workspace files into context
        # with a hard 35,000 char limit. Files over this limit are silently truncated,
        # causing agents to lose memory context without any visible error.
        try:
            bootstrap_warnings = self.check_bootstrap_files()
            checks["bootstrap_files_ok"] = len(bootstrap_warnings) == 0
            if bootstrap_warnings:
                import warnings
                for w in bootstrap_warnings:
                    warnings.warn(w, RuntimeWarning, stacklevel=2)
        except Exception:
            checks["bootstrap_files_ok"] = True  # non-fatal if check fails

        status = "ok" if all(checks.values()) else "degraded"
        result = {"status": status, "checks": checks}

        # Surface bootstrap warnings in health report for easy visibility
        try:
            bw = self.check_bootstrap_files()
            if bw:
                result["bootstrap_warnings"] = bw
        except Exception:
            pass

        return result

    def check_bootstrap_files(
        self,
        workspace_dir: Optional[str] = None,
        warn_threshold: int = 30_000,
        hard_limit: int = 35_000,
    ) -> list:
        """
        Scan common agent bootstrap files and warn if they exceed OpenClaw's
        35,000 char injection limit.

        OpenClaw (and similar runtimes) inject workspace files like MEMORY.md,
        AGENTS.md, SOUL.md into each session context. Files over ~35K chars are
        silently truncated — agents lose the tail end of their memory bootstrap
        on every message without any visible error.

        Args:
            workspace_dir: Directory to scan. Defaults to parent of self.workspace.
            warn_threshold: Warn early at this char count (default 30,000).
            hard_limit: Hard truncation limit (default 35,000).

        Returns:
            List of warning strings. Empty list = all files OK.
        """
        warnings_out = []
        bootstrap_files = [
            "MEMORY.md",
            "AGENTS.md",
            "SOUL.md",
            "USER.md",
            "IDENTITY.md",
            "CONTEXT.md",
            "SYSTEM.md",
            "HEARTBEAT.md",
        ]

        try:
            # Try workspace parent first (standard layout: workspace/memory_store → workspace/MEMORY.md)
            scan_dir = workspace_dir or os.path.dirname(self.workspace.rstrip("/"))
            if not os.path.isdir(scan_dir):
                scan_dir = self.workspace

            for fname in bootstrap_files:
                fpath = os.path.join(scan_dir, fname)
                if not os.path.isfile(fpath):
                    continue
                try:
                    size = os.path.getsize(fpath)
                    if size >= hard_limit:
                        warnings_out.append(
                            f"⚠️  {fname} is {size:,} chars — EXCEEDS OpenClaw's {hard_limit:,} char "
                            f"bootstrap limit. Content is being silently truncated every session. "
                            f"Prune this file immediately to restore full memory injection. ({fpath})"
                        )
                    elif size >= warn_threshold:
                        warnings_out.append(
                            f"⚠️  {fname} is {size:,} chars — approaching OpenClaw's {hard_limit:,} char "
                            f"bootstrap limit (warn at {warn_threshold:,}). "
                            f"Consider pruning before it causes silent truncation. ({fpath})"
                        )
                except OSError:
                    pass
        except Exception:
            pass  # Never raise — this is a non-fatal diagnostic

        return warnings_out

    def get_graph_stats(self) -> dict:
        """Return memory graph statistics (node count, edge count, top entities)."""
        try:
            if not self._graph_enabled or self._graph is None:
                return {"graph_enabled": False}
            return {**self._graph.get_stats(), "graph_enabled": True}
        except Exception:
            return {"graph_enabled": False}

    def rebuild_graph(self) -> int:
        """
        Rebuild the memory graph from scratch by re-indexing all loaded memories.

        Useful after bulk ingestion or when the graph file is stale/missing.
        Returns number of entries indexed. Non-fatal.
        """
        try:
            if not self._graph_enabled or self._graph is None:
                return 0
            # Reset the graph
            self._graph._nodes.clear()
            self._graph._edges.clear()
            self._graph._loaded = True
            count = 0
            for entry in self.memories:
                n = self._graph.index_entry(entry.hash, entry.content)
                if n > 0:
                    count += 1
            self._graph.save()
            # v4.9.6: also rebuild Layer 9 clusters when doing a full graph rebuild
            self.search_engine.rebuild_clusters(self.memories)
            return count
        except Exception:
            return 0

    def rebuild_clusters(self) -> int:
        """Rebuild the Layer 9 cluster index from all loaded memories.

        Call this after bulk ingestion when you want cluster-boosted search
        results immediately, without waiting for the next auto-flush.

        Returns the number of memories indexed into clusters.
        """
        try:
            self.search_engine.rebuild_clusters(self.memories)
            return len(self.memories)
        except Exception:
            return 0


    
# Backward compatibility alias
MemorySystem = MemorySystemV4