"""Conversation archive utilities for Parsica Memory.

Zero-dependency conversation checkpointing, summarization, rotation, and
archive search. Daily raw conversations are stored in ``memory/YYYY-MM-DD.md``
and older files are rolled into ``memory/archive.md``.
"""

from __future__ import annotations

import math
import os
import re
from collections import Counter, defaultdict
from datetime import datetime
from typing import Callable, Dict, Iterable, List, Optional, Tuple


_WORD_RE = re.compile(r"[a-zA-Z0-9_'-]+")
_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "but", "by", "for", "from",
    "had", "has", "have", "he", "her", "his", "i", "in", "is", "it", "its",
    "me", "my", "of", "on", "or", "our", "she", "that", "the", "their",
    "them", "they", "this", "to", "was", "we", "were", "with", "you", "your",
}


class ConversationArchive:
    """Manages raw conversation checkpoints and archival search."""

    def __init__(
        self,
        workspace: str,
        summarizer: Optional[Callable[[str], str]] = None,
        retention_days: int = 7,
    ):
        self.workspace = os.path.abspath(workspace)
        self.retention_days = retention_days
        self.memory_dir = os.path.join(self.workspace, "memory")
        self.archive_path = os.path.join(self.memory_dir, "archive.md")
        self._summarizer = summarizer
        os.makedirs(self.memory_dir, exist_ok=True)

    def set_enricher(self, enricher) -> None:
        self._summarizer = None if enricher is None else self._wrap_enricher(enricher)

    def checkpoint(
        self,
        turns: Iterable,
        agent_name: str,
        timestamp: Optional[str] = None,
    ) -> str:
        ts = self._coerce_iso_timestamp(timestamp)
        day = ts[:10]
        daily_path = self._daily_path(day)
        rendered = self._render_checkpoint(turns, agent_name, ts)
        with open(daily_path, "a", encoding="utf-8") as fh:
            if os.path.exists(daily_path) and os.path.getsize(daily_path) > 0:
                fh.write("\n")
            fh.write(rendered)
            fh.write("\n")
        return daily_path

    def summarize(self, turns: Iterable) -> str:
        rendered_turns = self._flatten_turns(turns)
        if not rendered_turns:
            return "- No conversation content to summarize."

        if self._summarizer is not None:
            try:
                result = self._summarizer("\n".join(rendered_turns)).strip()
                if result:
                    lines = [line.strip() for line in result.splitlines() if line.strip()]
                    return "\n".join(lines[:4])
            except Exception:
                pass

        scored = self._score_sentences(rendered_turns)
        if not scored:
            first = rendered_turns[:2]
            return "\n".join(f"- {line}" for line in first)

        top = [sentence for sentence, _ in scored[:4]]
        return "\n".join(f"- {line}" for line in top[: max(2, min(4, len(top)))])

    def rotate(self) -> int:
        daily_files = self._list_daily_files()
        now = datetime.now()
        grouped: Dict[Tuple[int, int], List[Tuple[str, str]]] = defaultdict(list)
        rotated = 0

        for day_str, path in daily_files:
            try:
                day_dt = datetime.strptime(day_str, "%Y-%m-%d")
            except ValueError:
                continue
            if (now.date() - day_dt.date()).days <= self.retention_days:
                continue
            content = self._read_text(path).strip()
            if not content:
                try:
                    os.remove(path)
                except OSError:
                    pass
                continue
            grouped[(day_dt.year, day_dt.month)].append((day_str, content))
            rotated += 1

        if not grouped:
            return 0

        existing = self._read_text(self.archive_path).strip()
        new_sections: List[str] = []
        for (year, month) in sorted(grouped.keys(), reverse=True):
            month_name = datetime(year, month, 1).strftime("%B")
            lines = [f"# {year}", f"## {month_name}"]
            for day_str, content in sorted(grouped[(year, month)], key=lambda item: item[0], reverse=True):
                summary = self.summarize(self._extract_turn_lines(content))
                lines.append(f"### {day_str}")
                lines.append("")
                lines.append("#### Summary")
                lines.append(summary)
                lines.append("")
                lines.append("#### Raw")
                lines.append(content)
                lines.append("")
            new_sections.append("\n".join(lines).strip())

        # P1 fix: check for already-archived days to prevent duplication
        archived_days = set()
        for line in existing.splitlines():
            if line.startswith("### ") and re.fullmatch(r"\d{4}-\d{2}-\d{2}", line[4:].strip()):
                archived_days.add(line[4:].strip())

        # Filter out already-archived days
        for key in list(grouped.keys()):
            grouped[key] = [(d, c) for d, c in grouped[key] if d not in archived_days]
        grouped = {k: v for k, v in grouped.items() if v}

        if not grouped:
            # All days already archived — just delete the stale daily files
            return rotated

        new_sections: List[str] = []
        for (year, month) in sorted(grouped.keys(), reverse=True):
            month_name = datetime(year, month, 1).strftime("%B")
            lines_sec = [f"# {year}", f"## {month_name}"]
            for day_str, content in sorted(grouped[(year, month)], key=lambda item: item[0], reverse=True):
                summary = self.summarize(self._extract_turn_lines(content))
                lines_sec.append(f"### {day_str}")
                lines_sec.append("")
                lines_sec.append("#### Summary")
                lines_sec.append(summary)
                lines_sec.append("")
                lines_sec.append("#### Raw")
                lines_sec.append(content)
                lines_sec.append("")
            new_sections.append("\n".join(lines_sec).strip())

        final_text = "\n\n".join(section for section in ["\n\n".join(new_sections).strip(), existing] if section).strip()
        # P1 fix: atomic write — write to temp file then os.replace
        import tempfile
        tmp_fd, tmp_path = tempfile.mkstemp(dir=self.memory_dir, suffix=".tmp")
        try:
            with os.fdopen(tmp_fd, "w", encoding="utf-8") as fh:
                fh.write(final_text + ("\n" if final_text else ""))
            os.replace(tmp_path, self.archive_path)
        except Exception:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

        for items in grouped.values():
            for day_str, _content in items:
                path = self._daily_path(day_str)
                try:
                    os.remove(path)
                except OSError:
                    pass
        return rotated

    def search_archive(self, query: str, limit: int = 10) -> List[Dict[str, object]]:
        docs = []
        archive_text = self._read_text(self.archive_path)
        if archive_text.strip():
            docs.extend(self._split_archive_sections(archive_text))
        for day_str, path in self._list_daily_files():
            text = self._read_text(path)
            if text.strip():
                docs.append({"source": path, "date": day_str, "content": text})

        scored = self._bm25_search(query, docs)
        return scored[:max(0, limit)]

    def get_recent(self, days: int = 3) -> str:
        if days <= 0:
            return ""
        parts: List[str] = []
        for day_str, path in self._list_daily_files()[:days]:
            text = self._read_text(path).strip()
            if not text:
                continue
            parts.append(f"# {day_str}\n\n{text}")
        return "\n\n".join(parts)

    def _wrap_enricher(self, enricher) -> Callable[[str], str]:
        def _inner(text: str) -> str:
            result = enricher(text)
            if isinstance(result, dict):
                return str(result.get("summary", "")).strip()
            return str(result or "").strip()
        return _inner

    def _daily_path(self, day_str: str) -> str:
        return os.path.join(self.memory_dir, f"{day_str}.md")

    def _list_daily_files(self) -> List[Tuple[str, str]]:
        out = []
        if not os.path.isdir(self.memory_dir):
            return out
        for name in os.listdir(self.memory_dir):
            if not name.endswith(".md") or name == "archive.md":
                continue
            day = name[:-3]
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
                out.append((day, os.path.join(self.memory_dir, name)))
        out.sort(key=lambda item: item[0], reverse=True)
        return out

    def _coerce_iso_timestamp(self, value: Optional[str]) -> str:
        if not value:
            return datetime.now().isoformat()
        try:
            return datetime.fromisoformat(value).isoformat()
        except ValueError:
            return datetime.now().isoformat()

    def _render_checkpoint(self, turns: Iterable, agent_name: str, timestamp: str) -> str:
        header = f"## {timestamp} — {agent_name}"
        lines = [header, ""]
        flat = self._flatten_turns(turns)
        if not flat:
            lines.append("- (no turns)")
        else:
            for line in flat:
                lines.append(f"- {line}")
        return "\n".join(lines).rstrip()

    def _flatten_turns(self, turns: Iterable) -> List[str]:
        flat: List[str] = []
        for turn in turns or []:
            if isinstance(turn, dict):
                speaker = turn.get("speaker") or turn.get("role") or turn.get("author") or "turn"
                content = turn.get("content") or turn.get("text") or turn.get("message") or ""
                content = str(content).strip()
                if content:
                    flat.append(f"{speaker}: {content}")
            else:
                text = str(turn).strip()
                if text:
                    flat.append(text)
        return flat

    def _extract_turn_lines(self, content: str) -> List[str]:
        lines = []
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("- "):
                lines.append(stripped[2:].strip())
        return lines

    def _score_sentences(self, rendered_turns: List[str]) -> List[Tuple[str, float]]:
        sentences = []
        for line in rendered_turns:
            parts = [part.strip() for part in re.split(r"(?<=[.!?])\s+", line) if part.strip()]
            sentences.extend(parts or [line])
        if not sentences:
            return []

        tf = Counter()
        for sentence in sentences:
            tf.update(self._tokenize(sentence))

        scored = []
        for idx, sentence in enumerate(sentences):
            tokens = self._tokenize(sentence)
            if not tokens:
                continue
            score = sum(tf[token] for token in tokens)
            score += min(len(tokens), 20) * 0.05
            if idx == 0:
                score += 0.25
            scored.append((sentence, score))
        scored.sort(key=lambda item: item[1], reverse=True)
        return scored

    def _split_archive_sections(self, text: str) -> List[Dict[str, str]]:
        sections = []
        current_year = ""
        current_month = ""
        current_day = None
        buf: List[str] = []

        def flush() -> None:
            nonlocal current_day, buf
            if current_day and buf:
                sections.append({
                    "source": self.archive_path,
                    "date": current_day,
                    "content": "\n".join(buf).strip(),
                    "year": current_year,
                    "month": current_month,
                })
            buf = []

        for line in text.splitlines():
            if line.startswith("# ") and not line.startswith("## "):
                flush()
                current_year = line[2:].strip()
                current_day = None
            elif line.startswith("## ") and not line.startswith("### "):
                flush()
                current_month = line[3:].strip()
                current_day = None
            elif line.startswith("### "):
                flush()
                current_day = line[4:].strip()
            else:
                if current_day:
                    buf.append(line)
        flush()
        return sections

    def _bm25_search(self, query: str, docs: List[Dict[str, str]]) -> List[Dict[str, object]]:
        terms = self._tokenize(query)
        if not terms or not docs:
            return []

        tokenized_docs = [self._tokenize(doc["content"]) for doc in docs]
        lengths = [len(tokens) for tokens in tokenized_docs]
        avgdl = sum(lengths) / len(lengths) if lengths else 0.0
        doc_freq = Counter()
        for tokens in tokenized_docs:
            for term in set(tokens):
                doc_freq[term] += 1

        results = []
        for doc, tokens, dl in zip(docs, tokenized_docs, lengths):
            tf = Counter(tokens)
            score = 0.0
            for term in terms:
                freq = tf.get(term, 0)
                if freq <= 0:
                    continue
                df = doc_freq.get(term, 0)
                idf = math.log(1 + ((len(docs) - df + 0.5) / (df + 0.5)))
                denom = freq + 1.5 * (1 - 0.75 + 0.75 * (dl / avgdl if avgdl else 0.0))
                score += idf * ((freq * (1.5 + 1)) / denom)
            if score <= 0:
                continue
            snippet = self._make_snippet(doc["content"], query)
            result = dict(doc)
            result["score"] = round(score, 6)
            result["snippet"] = snippet
            results.append(result)

        results.sort(key=lambda item: (item["score"], item.get("date", "")), reverse=True)
        return results

    def _make_snippet(self, text: str, query: str, max_len: int = 220) -> str:
        compact = re.sub(r"\s+", " ", text).strip()
        if len(compact) <= max_len:
            return compact
        terms = [re.escape(term) for term in query.split() if term.strip()]
        if terms:
            match = re.search("|".join(terms), compact, flags=re.IGNORECASE)
            if match:
                start = max(0, match.start() - 60)
                end = min(len(compact), start + max_len)
                return compact[start:end].strip()
        return compact[:max_len].strip()

    def _tokenize(self, text: str) -> List[str]:
        return [
            token.lower()
            for token in _WORD_RE.findall(text)
            if token and token.lower() not in _STOPWORDS
        ]

    def _read_text(self, path: str) -> str:
        if not os.path.exists(path):
            return ""
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read()
