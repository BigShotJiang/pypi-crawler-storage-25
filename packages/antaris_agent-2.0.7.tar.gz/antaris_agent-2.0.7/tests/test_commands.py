"""
Tests for CommandDispatcher and BotMemory ingest filter.
"""
import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from antaris_agent.channels.base import InboundMessage
from antaris_agent.core.commands import (
    CommandDispatcher, CommandResult,
    _parse_every_interval, _parse_time_token, _parse_cron_add_spec,
    _derive_job_name, _validate_cron_expr, MAX_CRON_JOBS,
)
from antaris_agent.core.memory import BotMemory


# ── Helpers ─────────────────────────────────────────────────────────────────

def make_inbound(text="Hello", user_id="user-42", channel_id="ch-1", platform="terminal"):
    return InboundMessage(
        id="msg-1",
        user_id=user_id,
        user_name="TestUser",
        channel_id=channel_id,
        platform=platform,
        text=text,
        timestamp_ms=0,
    )


def make_bot():
    """Build a minimal mock Bot for CommandDispatcher."""
    bot = MagicMock()
    bot.memory.stats.return_value = {"total": 42}
    bot.config.model = "claude-sonnet-4-6"
    bot.config.provider_name = "anthropic"
    bot.config.guard_mode = "strict"
    bot.config.security_mode = "sandboxed"
    bot.dispatcher.providers = {"anthropic": MagicMock(), "openai": MagicMock()}
    bot.router = None
    return bot


# ── CommandDispatcher tests ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_status_returns_status_string():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!status"))
    assert result.handled is True
    assert result.response is not None
    assert "Status" in result.response or "Memory" in result.response


@pytest.mark.asyncio
async def test_status_contains_memory_count():
    bot = make_bot()
    bot.memory.stats.return_value = {"total": 1337}
    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!status"))
    assert "1,337" in result.response


@pytest.mark.asyncio
async def test_model_opus_sets_override():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!model opus", user_id="user-1"))
    assert result.handled is True
    assert dispatcher.get_model_override("user-1") == "claude-opus-4-6"
    assert "claude-opus-4-6" in result.response


@pytest.mark.asyncio
async def test_model_alias_sonnet():
    dispatcher = CommandDispatcher(make_bot())
    await dispatcher.dispatch(make_inbound("!model sonnet", user_id="u2"))
    assert dispatcher.get_model_override("u2") == "claude-sonnet-4-6"


@pytest.mark.asyncio
async def test_model_auto_clears_override():
    dispatcher = CommandDispatcher(make_bot())
    await dispatcher.dispatch(make_inbound("!model opus", user_id="u3"))
    assert dispatcher.get_model_override("u3") == "claude-opus-4-6"
    result = await dispatcher.dispatch(make_inbound("!model auto", user_id="u3"))
    assert result.handled is True
    assert dispatcher.get_model_override("u3") is None
    assert "auto" in result.response.lower() or "reset" in result.response.lower()


@pytest.mark.asyncio
async def test_model_no_args_clears_override():
    dispatcher = CommandDispatcher(make_bot())
    await dispatcher.dispatch(make_inbound("!model opus", user_id="u4"))
    result = await dispatcher.dispatch(make_inbound("!model", user_id="u4"))
    assert result.handled is True
    assert dispatcher.get_model_override("u4") is None


@pytest.mark.asyncio
async def test_model_unknown_name_stored_as_is():
    dispatcher = CommandDispatcher(make_bot())
    await dispatcher.dispatch(make_inbound("!model my-custom-model-v2", user_id="u5"))
    assert dispatcher.get_model_override("u5") == "my-custom-model-v2"


@pytest.mark.asyncio
async def test_recap_returns_string():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!recap"))
    assert result.handled is True
    assert isinstance(result.response, str)
    assert len(result.response) > 0


@pytest.mark.asyncio
async def test_recap_with_number():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!recap 25"))
    assert result.handled is True
    assert "25" in result.response


@pytest.mark.asyncio
async def test_recap_clamps_to_50():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!recap 999"))
    assert result.handled is True
    assert "50" in result.response


@pytest.mark.asyncio
async def test_recap_clamps_minimum_to_1():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!recap 0"))
    assert result.handled is True
    assert "1" in result.response


@pytest.mark.asyncio
async def test_non_command_returns_not_handled():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("Hello, how are you?"))
    assert result.handled is False
    assert result.response is None


@pytest.mark.asyncio
async def test_unknown_command_returns_not_handled():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!unknown"))
    assert result.handled is False


@pytest.mark.asyncio
async def test_get_model_override_returns_none_for_unknown_user():
    dispatcher = CommandDispatcher(make_bot())
    assert dispatcher.get_model_override("no-such-user") is None


@pytest.mark.asyncio
async def test_overrides_are_per_user():
    dispatcher = CommandDispatcher(make_bot())
    await dispatcher.dispatch(make_inbound("!model opus", user_id="alice"))
    await dispatcher.dispatch(make_inbound("!model flash", user_id="bob"))
    assert dispatcher.get_model_override("alice") == "claude-opus-4-6"
    assert dispatcher.get_model_override("bob") == "gemini-2.0-flash"


# ── BotMemory ingest filter tests ───────────────────────────────────────────

def make_memory(tmp_path):
    import antaris_agent.core.memory as mem_module
    original_available = mem_module._MEMORY_AVAILABLE
    original_system = mem_module.MemorySystem

    mock_store = MagicMock()
    mock_store.search.return_value = []
    mock_store.stats.return_value = {"total": 0}

    mem_module._MEMORY_AVAILABLE = True
    mem_module.MemorySystem = MagicMock(return_value=mock_store)

    memory = BotMemory(store_path=str(tmp_path / "mem"), search_limit=10, min_relevance=0.3)

    mem_module._MEMORY_AVAILABLE = original_available
    mem_module.MemorySystem = original_system

    return memory, mock_store


def test_ingest_filter_skips_context_packet_header(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("## Context Packet\n\nSome content here") is True


def test_ingest_filter_skips_relevant_context_header(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("### Relevant Context\n1. some result") is True


def test_ingest_filter_skips_packet_built_line(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("Some text *Packet built 2026-03-11 at 11:00") is True


def test_ingest_filter_skips_queued_messages_marker(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("[Queued messages while agent was busy]") is True


def test_ingest_filter_skips_context_packet_xml(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("<ContextPacket>...</ContextPacket>") is True


def test_ingest_filter_skips_system_message(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("[System Message]") is True


def test_ingest_filter_skips_short_messages(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("hi") is True
    assert memory._should_skip_ingest("ok") is True
    assert memory._should_skip_ingest("") is True


def test_ingest_filter_skips_empty_and_whitespace(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("   ") is True
    assert memory._should_skip_ingest("\n\n\t") is True


def test_ingest_filter_skips_punctuation_only(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("...!!!???") is True


def test_ingest_filter_allows_normal_message(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("Hello, how are you today?") is False
    assert memory._should_skip_ingest("What is the weather like in San Francisco?") is False


def test_ingest_filter_allows_longer_message(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("This is twenty chars") is False


def test_ingest_filter_blocks_19_chars(tmp_path):
    memory, mock_store = make_memory(tmp_path)
    assert memory._should_skip_ingest("This is nineteen ch") is True


# ── !gather command tests ───────────────────────────────────────────────────

def make_bot_with_gather():
    from unittest.mock import MagicMock
    from antaris_agent.channels.discord import DiscordAdapter

    bot = MagicMock()
    bot.memory.stats.return_value = {"total": 0}
    bot.config.model = "claude-sonnet-4-6"
    bot.config.provider_name = "anthropic"
    bot.config.guard_mode = "monitor"
    bot.config.security_mode = "sandboxed"
    bot.config.discord_open_channels = ["111", "222"]
    bot.dispatcher.providers = {}
    bot.router = None

    adapter = MagicMock(spec=DiscordAdapter)
    adapter._client = MagicMock()
    bot._channels = [adapter]

    return bot, adapter


@pytest.mark.asyncio
async def test_gather_defaults_to_12h():
    bot, adapter = make_bot_with_gather()
    dispatcher = CommandDispatcher(bot)

    with patch("antaris_agent.core.gather.gather_and_ingest", new=AsyncMock(return_value={
        "channels_synced": 2,
        "total_messages": 60,
        "errors": [],
    })) as mock_gather:
        result = await dispatcher.dispatch(make_inbound("!gather"))
        assert result.handled is True
        assert result.response is not None
        mock_gather.assert_awaited_once()
        call_kwargs = mock_gather.call_args
        assert call_kwargs.kwargs.get("hours", call_kwargs.args[3] if len(call_kwargs.args) > 3 else 12) == 12 or "12" in str(mock_gather.call_args)


@pytest.mark.asyncio
async def test_gather_with_6_hours():
    bot, adapter = make_bot_with_gather()
    dispatcher = CommandDispatcher(bot)

    with patch("antaris_agent.core.gather.gather_and_ingest", new=AsyncMock(return_value={
        "channels_synced": 1,
        "total_messages": 18,
        "errors": [],
    })) as mock_gather:
        result = await dispatcher.dispatch(make_inbound("!gather 6"))
        assert result.handled is True
        mock_gather.assert_awaited_once()
        kwargs = mock_gather.call_args.kwargs
        assert kwargs.get("hours") == 6


@pytest.mark.asyncio
async def test_gather_invalid_hours_returns_error():
    bot, adapter = make_bot_with_gather()
    dispatcher = CommandDispatcher(bot)

    with patch("antaris_agent.core.gather.gather_and_ingest", new=AsyncMock()) as mock_gather:
        result = await dispatcher.dispatch(make_inbound("!gather 999"))
        assert result.handled is True
        assert result.response is not None
        mock_gather.assert_not_awaited()
        assert "999" in result.response or "valid" in result.response.lower() or "invalid" in result.response.lower()


@pytest.mark.asyncio
async def test_gather_no_discord_client_returns_error():
    bot = MagicMock()
    bot.config.discord_open_channels = ["111"]
    bot._channels = []
    bot.dispatcher.providers = {}
    bot.router = None

    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!gather"))
    assert result.handled is True
    assert "discord" in result.response.lower() or "client" in result.response.lower()


@pytest.mark.asyncio
async def test_gather_no_open_channels_returns_error():
    from antaris_agent.channels.discord import DiscordAdapter

    bot = MagicMock()
    bot.config.discord_open_channels = []
    adapter = MagicMock(spec=DiscordAdapter)
    adapter._client = MagicMock()
    bot._channels = [adapter]
    bot.dispatcher.providers = {}
    bot.router = None

    dispatcher = CommandDispatcher(bot)
    result = await dispatcher.dispatch(make_inbound("!gather"))
    assert result.handled is True
    assert "channel" in result.response.lower()


@pytest.mark.asyncio
async def test_help_includes_gather():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!help"))
    assert result.handled is True
    assert "!gather" in result.response


# ── !cron add command tests ────────────────────────────────────────────────

def make_bot_with_cron():
    bot = make_bot()
    bot.cron = MagicMock()
    bot.cron.list_jobs.return_value = []
    bot.cron.add_job.side_effect = lambda job: job
    return bot


@pytest.mark.asyncio
async def test_cron_add_every_30m_creates_agent_turn_job_with_channel():
    bot = make_bot_with_cron()
    dispatcher = CommandDispatcher(bot)
    inbound = make_inbound("!cron add every 30m remind me to stretch", channel_id="discord-123")

    result = await dispatcher.dispatch(inbound)

    assert result.handled is True
    assert "Added job" in result.response
    job = bot.cron.add_job.call_args.args[0]
    assert job.schedule_kind == "every"
    assert job.schedule_every_ms == 30 * 60 * 1000
    assert job.payload_kind == "agentTurn"
    assert job.channel_id == "discord-123"
    assert job.payload_text == "remind me to stretch"


@pytest.mark.asyncio
async def test_cron_add_daily_6am_creates_cron_job():
    bot = make_bot_with_cron()
    dispatcher = CommandDispatcher(bot)

    await dispatcher.dispatch(make_inbound("!cron add daily 6am post daily brief"))

    job = bot.cron.add_job.call_args.args[0]
    assert job.schedule_kind == "cron"
    assert job.schedule_cron == "0 6 * * *"
    assert job.payload_kind == "agentTurn"
    assert job.payload_text == "post daily brief"


@pytest.mark.asyncio
async def test_cron_add_weekdays_630am_creates_weekday_cron_job():
    bot = make_bot_with_cron()
    dispatcher = CommandDispatcher(bot)

    await dispatcher.dispatch(make_inbound("!cron add weekdays 6:30am post market brief"))

    job = bot.cron.add_job.call_args.args[0]
    assert job.schedule_kind == "cron"
    assert job.schedule_cron == "30 6 * * 1-5"
    assert job.payload_text == "post market brief"


@pytest.mark.asyncio
async def test_cron_add_tomorrow_9am_creates_at_job():
    bot = make_bot_with_cron()
    dispatcher = CommandDispatcher(bot)

    await dispatcher.dispatch(make_inbound("!cron add tomorrow 9am remind me to call mom"))

    job = bot.cron.add_job.call_args.args[0]
    assert job.schedule_kind == "at"
    assert job.schedule_at is not None
    assert job.payload_text == "remind me to call mom"


@pytest.mark.asyncio
async def test_cron_add_at_iso_creates_at_job():
    bot = make_bot_with_cron()
    dispatcher = CommandDispatcher(bot)

    await dispatcher.dispatch(make_inbound("!cron add at 2026-03-27T09:00:00Z send follow-up"))

    job = bot.cron.add_job.call_args.args[0]
    assert job.schedule_kind == "at"
    # P2-14: Z is now normalized to +00:00
    assert job.schedule_at == "2026-03-27T09:00:00+00:00"
    assert job.payload_text == "send follow-up"


@pytest.mark.asyncio
async def test_cron_add_raw_cron_creates_cron_job():
    bot = make_bot_with_cron()
    dispatcher = CommandDispatcher(bot)

    await dispatcher.dispatch(make_inbound('!cron add cron "0 6 * * 1-5" weekday brief'))

    job = bot.cron.add_job.call_args.args[0]
    assert job.schedule_kind == "cron"
    assert job.schedule_cron == "0 6 * * 1-5"
    assert job.payload_text == "weekday brief"


@pytest.mark.asyncio
async def test_cron_add_invalid_returns_usage_and_does_not_create_job():
    bot = make_bot_with_cron()
    dispatcher = CommandDispatcher(bot)

    result = await dispatcher.dispatch(make_inbound("!cron add bananas"))

    assert result.handled is True
    assert "Usage:" in result.response
    bot.cron.add_job.assert_not_called()


@pytest.mark.asyncio
async def test_help_includes_cron_add_examples():
    dispatcher = CommandDispatcher(make_bot())
    result = await dispatcher.dispatch(make_inbound("!help"))
    assert result.handled is True
    assert "!cron add every 30m remind me to stretch" in result.response
    assert '!cron add cron "0 6 * * 1-5" weekday brief' in result.response


# ── _parse_every_interval unit tests ──────────────────────────────────────

class TestParseEveryInterval:
    def test_30m(self):
        assert _parse_every_interval("30m") == 30 * 60_000

    def test_2h(self):
        assert _parse_every_interval("2h") == 2 * 3_600_000

    def test_1d(self):
        assert _parse_every_interval("1d") == 86_400_000

    def test_0m_rejected(self):
        assert _parse_every_interval("0m") is None

    def test_negative_1m_rejected(self):
        assert _parse_every_interval("-1m") is None

    def test_5x_rejected(self):
        assert _parse_every_interval("5x") is None

    def test_abc_rejected(self):
        assert _parse_every_interval("abc") is None

    def test_empty_rejected(self):
        assert _parse_every_interval("") is None

    def test_single_char_rejected(self):
        assert _parse_every_interval("m") is None


# ── _parse_time_token unit tests ──────────────────────────────────────────

class TestParseTimeToken:
    def test_6am(self):
        assert _parse_time_token("6am") == (6, 0)

    def test_6_30am(self):
        assert _parse_time_token("6:30am") == (6, 30)

    def test_12am_is_midnight(self):
        assert _parse_time_token("12am") == (0, 0)

    def test_12pm_is_noon(self):
        assert _parse_time_token("12pm") == (12, 0)

    def test_9pm(self):
        assert _parse_time_token("9pm") == (21, 0)

    def test_24h_format_18_00(self):
        assert _parse_time_token("18:00") == (18, 0)

    def test_24h_format_06_30(self):
        assert _parse_time_token("06:30") == (6, 30)

    def test_noon_keyword(self):
        assert _parse_time_token("noon") == (12, 0)

    def test_midnight_keyword(self):
        assert _parse_time_token("midnight") == (0, 0)

    def test_noon_case_insensitive(self):
        assert _parse_time_token("NOON") == (12, 0)

    def test_midnight_case_insensitive(self):
        assert _parse_time_token("MIDNIGHT") == (0, 0)

    def test_invalid_text_rejected(self):
        assert _parse_time_token("hello") is None

    def test_empty_rejected(self):
        assert _parse_time_token("") is None


# ── _parse_cron_add_spec edge case tests ──────────────────────────────────

class TestParseCronAddSpec:
    def test_empty_string_returns_none(self):
        assert _parse_cron_add_spec("") is None

    def test_every_with_no_text(self):
        result = _parse_cron_add_spec("every")
        assert result is not None and "_error" in result

    def test_every_with_interval_no_payload(self):
        result = _parse_cron_add_spec("every 30m")
        assert result is not None and "_error" in result

    def test_daily_6am_no_payload(self):
        result = _parse_cron_add_spec("daily 6am")
        assert result is not None and "_error" in result

    def test_cron_with_invalid_expr(self):
        result = _parse_cron_add_spec('cron "bad cron" do something')
        assert result is not None and "_error" in result

    def test_cron_with_garbage_fields(self):
        result = _parse_cron_add_spec('cron "abc def ghi jkl mno" do something')
        assert result is not None and "_error" in result

    def test_cron_with_3_fields(self):
        result = _parse_cron_add_spec('cron "0 6 *" do something')
        assert result is not None and "_error" in result

    def test_valid_every_30m(self):
        result = _parse_cron_add_spec("every 30m remind me to stretch")
        assert result is not None
        assert "_error" not in result
        assert result["schedule_kind"] == "every"
        assert result["schedule_every_ms"] == 30 * 60_000

    def test_valid_daily(self):
        result = _parse_cron_add_spec("daily 6am post brief")
        assert result is not None
        assert "_error" not in result
        assert result["schedule_kind"] == "cron"
        assert result["schedule_cron"] == "0 6 * * *"

    def test_valid_weekdays(self):
        result = _parse_cron_add_spec("weekdays 9am standup")
        assert result is not None
        assert "_error" not in result
        assert result["schedule_cron"] == "0 9 * * 1-5"


# ── P0-1: at with space-separated datetime ────────────────────────────────

class TestAtSpaceSeparatedDatetime:
    def test_at_with_space_separated_datetime(self):
        result = _parse_cron_add_spec("at 2026-03-27 09:00 send follow-up")
        assert result is not None
        assert "_error" not in result
        assert result["schedule_kind"] == "at"
        # The datetime should include 09:00, not just the date
        assert "09:00" in result["schedule_at"] or "09:00" in result.get("schedule_at", "")
        assert result["payload_text"] == "send follow-up"

    def test_at_with_iso_datetime_still_works(self):
        result = _parse_cron_add_spec("at 2026-03-27T09:00:00Z send follow-up")
        assert result is not None
        assert "_error" not in result
        assert result["schedule_kind"] == "at"
        assert result["payload_text"] == "send follow-up"

    def test_at_space_separated_with_timezone(self):
        result = _parse_cron_add_spec("at 2026-03-27 09:00+05:00 do task")
        assert result is not None
        assert "_error" not in result
        # Should have greedy-parsed 2026-03-27T09:00+05:00
        assert "09:00" in result["schedule_at"]


# ── P0-2: Past dates in at ────────────────────────────────────────────────

class TestAtPastDate:
    def test_past_date_has_warning(self):
        result = _parse_cron_add_spec("at 2020-01-01T00:00:00Z do something")
        assert result is not None
        assert "_error" not in result
        assert "_warning" in result
        assert "past" in result["_warning"].lower()

    def test_future_date_no_warning(self):
        result = _parse_cron_add_spec("at 2099-01-01T00:00:00Z do something")
        assert result is not None
        assert "_error" not in result
        assert "_warning" not in result

    @pytest.mark.asyncio
    async def test_past_date_warning_in_response(self):
        bot = make_bot_with_cron()
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron add at 2020-01-01T00:00:00Z do something"))
        assert result.handled is True
        assert "past" in result.response.lower()


# ── P0-3: delete_after_run for one-shot jobs ──────────────────────────────

class TestDeleteAfterRun:
    @pytest.mark.asyncio
    async def test_at_job_has_delete_after_run(self):
        bot = make_bot_with_cron()
        dispatcher = CommandDispatcher(bot)
        await dispatcher.dispatch(make_inbound("!cron add at 2099-03-27T09:00:00Z send msg"))
        job = bot.cron.add_job.call_args.args[0]
        assert job.delete_after_run is True

    @pytest.mark.asyncio
    async def test_tomorrow_job_has_delete_after_run(self):
        bot = make_bot_with_cron()
        dispatcher = CommandDispatcher(bot)
        await dispatcher.dispatch(make_inbound("!cron add tomorrow 9am call mom"))
        job = bot.cron.add_job.call_args.args[0]
        assert job.delete_after_run is True

    @pytest.mark.asyncio
    async def test_every_job_does_not_have_delete_after_run(self):
        bot = make_bot_with_cron()
        dispatcher = CommandDispatcher(bot)
        await dispatcher.dispatch(make_inbound("!cron add every 30m stretch"))
        job = bot.cron.add_job.call_args.args[0]
        assert job.delete_after_run is False

    def test_at_parse_spec_has_delete_after_run(self):
        result = _parse_cron_add_spec("at 2099-01-01T00:00:00Z do it")
        assert result.get("delete_after_run") is True

    def test_tomorrow_parse_spec_has_delete_after_run(self):
        result = _parse_cron_add_spec("tomorrow 9am call mom")
        assert result.get("delete_after_run") is True


# ── P0-4: Job count limit ────────────────────────────────────────────────

class TestJobCountLimit:
    @pytest.mark.asyncio
    async def test_job_count_limit_exceeded(self):
        bot = make_bot_with_cron()
        # Return MAX_CRON_JOBS existing jobs
        bot.cron.list_jobs.return_value = [MagicMock() for _ in range(MAX_CRON_JOBS)]
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron add every 30m stretch"))
        assert result.handled is True
        assert "limit" in result.response.lower() or str(MAX_CRON_JOBS) in result.response
        bot.cron.add_job.assert_not_called()

    @pytest.mark.asyncio
    async def test_job_count_under_limit_works(self):
        bot = make_bot_with_cron()
        bot.cron.list_jobs.return_value = [MagicMock() for _ in range(MAX_CRON_JOBS - 1)]
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron add every 30m stretch"))
        assert result.handled is True
        assert "Added job" in result.response
        bot.cron.add_job.assert_called_once()


# ── P0-5: Minimum interval for every ─────────────────────────────────────

class TestMinimumInterval:
    def test_every_1m_rejected(self):
        result = _parse_cron_add_spec("every 1m do something")
        assert result is not None and "_error" in result
        assert "5 minutes" in result["_error"] or "too frequent" in result["_error"].lower()

    def test_every_4m_rejected(self):
        result = _parse_cron_add_spec("every 4m do something")
        assert result is not None and "_error" in result

    def test_every_5m_accepted(self):
        result = _parse_cron_add_spec("every 5m do something")
        assert result is not None
        assert "_error" not in result
        assert result["schedule_every_ms"] == 5 * 60_000

    def test_every_30m_accepted(self):
        result = _parse_cron_add_spec("every 30m do something")
        assert result is not None
        assert "_error" not in result

    @pytest.mark.asyncio
    async def test_every_1m_via_dispatch_rejected(self):
        bot = make_bot_with_cron()
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron add every 1m spam"))
        assert result.handled is True
        bot.cron.add_job.assert_not_called()
        assert "5 minutes" in result.response or "too frequent" in result.response.lower()


# ── P1-6: Raw cron expression validation ──────────────────────────────────

class TestCronExprValidation:
    def test_valid_cron_expr(self):
        assert _validate_cron_expr("0 6 * * 1-5") is None

    def test_valid_cron_expr_with_steps(self):
        assert _validate_cron_expr("*/15 * * * *") is None

    def test_invalid_characters(self):
        result = _validate_cron_expr("abc def ghi jkl mno")
        assert result is not None
        assert "Invalid character" in result or "invalid" in result.lower()

    def test_wrong_field_count(self):
        result = _validate_cron_expr("0 6 *")
        assert result is not None

    def test_six_fields_rejected(self):
        result = _validate_cron_expr("0 6 * * 1-5 2026")
        assert result is not None

    @pytest.mark.asyncio
    async def test_invalid_cron_expr_via_dispatch(self):
        bot = make_bot_with_cron()
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound('!cron add cron "abc def ghi jkl mno" do task'))
        assert result.handled is True
        bot.cron.add_job.assert_not_called()
        assert "❌" in result.response


# ── P1-7: tomorrow TZ transparency ───────────────────────────────────────

class TestTomorrowTzTransparency:
    def test_tomorrow_summary_includes_tz(self):
        from datetime import datetime
        result = _parse_cron_add_spec("tomorrow 9am call mom")
        assert result is not None
        assert "_error" not in result
        tz_name = datetime.now().astimezone().tzname()
        assert tz_name in result["summary"]

    @pytest.mark.asyncio
    async def test_tomorrow_response_includes_tz(self):
        from datetime import datetime
        bot = make_bot_with_cron()
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron add tomorrow 9am call mom"))
        tz_name = datetime.now().astimezone().tzname()
        assert tz_name in result.response


# ── P1-13: daily/weekdays TZ transparency ────────────────────────────────

class TestDailyWeekdaysTzTransparency:
    def test_daily_summary_includes_tz(self):
        from datetime import datetime
        result = _parse_cron_add_spec("daily 6am post brief")
        assert result is not None
        tz_name = datetime.now().astimezone().tzname()
        assert tz_name in result["summary"]

    def test_weekdays_summary_includes_tz(self):
        from datetime import datetime
        result = _parse_cron_add_spec("weekdays 9am standup")
        assert result is not None
        tz_name = datetime.now().astimezone().tzname()
        assert tz_name in result["summary"]

    def test_daily_has_schedule_tz_if_resolvable(self):
        """schedule_tz is set to IANA name when system TZ resolves, omitted otherwise."""
        result = _parse_cron_add_spec("daily 6am post brief")
        assert result is not None
        if "schedule_tz" in result:
            # Must be IANA format (contains "/"), not abbreviation like "PDT"
            assert "/" in result["schedule_tz"], f"Expected IANA name, got {result['schedule_tz']}"

    def test_weekdays_has_schedule_tz_if_resolvable(self):
        result = _parse_cron_add_spec("weekdays 9am standup")
        assert result is not None
        if "schedule_tz" in result:
            assert "/" in result["schedule_tz"], f"Expected IANA name, got {result['schedule_tz']}"


# ── P1-9: 24-hour time and keywords ──────────────────────────────────────

class TestTimeFormatExtensions:
    def test_noon_in_daily(self):
        result = _parse_cron_add_spec("daily noon check status")
        assert result is not None
        assert "_error" not in result
        assert result["schedule_cron"] == "0 12 * * *"

    def test_midnight_in_daily(self):
        result = _parse_cron_add_spec("daily midnight run backup")
        assert result is not None
        assert "_error" not in result
        assert result["schedule_cron"] == "0 0 * * *"

    def test_24h_time_in_daily(self):
        result = _parse_cron_add_spec("daily 18:00 post summary")
        assert result is not None
        assert "_error" not in result
        assert result["schedule_cron"] == "0 18 * * *"

    def test_24h_time_in_weekdays(self):
        result = _parse_cron_add_spec("weekdays 08:30 standup")
        assert result is not None
        assert "_error" not in result
        assert result["schedule_cron"] == "30 8 * * 1-5"


# ── P2-12: _derive_job_name ellipsis ──────────────────────────────────────

class TestDeriveJobName:
    def test_short_name_unchanged(self):
        assert _derive_job_name("short") == "short"

    def test_exactly_40_chars_no_ellipsis(self):
        text = "a" * 40
        assert _derive_job_name(text) == text

    def test_over_40_chars_gets_ellipsis(self):
        text = "a" * 50
        result = _derive_job_name(text)
        assert result == "a" * 37 + "..."
        assert len(result) == 40

    def test_empty_returns_default(self):
        assert _derive_job_name("") == "Cron Job"

    def test_none_returns_default(self):
        assert _derive_job_name(None) == "Cron Job"


# ── P2-14: Normalize at ISO strings ──────────────────────────────────────

class TestNormalizeAtIso:
    def test_z_normalized_to_plus_00_00(self):
        result = _parse_cron_add_spec("at 2026-03-27T09:00:00Z send msg")
        assert result is not None
        assert result["schedule_at"] == "2026-03-27T09:00:00+00:00"

    def test_plus_offset_preserved(self):
        result = _parse_cron_add_spec("at 2026-03-27T09:00:00+05:00 send msg")
        assert result is not None
        assert "+05:00" in result["schedule_at"]


# ── P1-10: Specific error messages ───────────────────────────────────────

class TestSpecificErrors:
    def test_every_no_interval_specific_error(self):
        result = _parse_cron_add_spec("every")
        assert result is not None
        assert "_error" in result
        assert "❌" in result["_error"]

    def test_daily_bad_time_specific_error(self):
        result = _parse_cron_add_spec("daily badtime do something")
        assert result is not None
        assert "_error" in result
        assert "time format" in result["_error"].lower() or "invalid" in result["_error"].lower()

    def test_at_bad_datetime_specific_error(self):
        result = _parse_cron_add_spec("at not-a-date do something")
        assert result is not None
        assert "_error" in result
        assert "datetime" in result["_error"].lower() or "iso" in result["_error"].lower()

    def test_cron_no_expr_specific_error(self):
        result = _parse_cron_add_spec("cron")
        assert result is not None
        assert "_error" in result

    @pytest.mark.asyncio
    async def test_specific_error_not_generic_usage(self):
        """Recognized-but-invalid input should return specific error, not usage block."""
        bot = make_bot_with_cron()
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron add every 1m spam"))
        assert result.handled is True
        # Should be a specific error, not the generic usage
        assert "Usage:" not in result.response
        assert "❌" in result.response


# ── Regression: existing !cron list, remove, run ──────────────────────────

class TestCronListRemoveRun:
    @pytest.mark.asyncio
    async def test_cron_list_empty(self):
        bot = make_bot_with_cron()
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron list"))
        assert result.handled is True
        assert "No cron jobs" in result.response

    @pytest.mark.asyncio
    async def test_cron_list_with_jobs(self):
        bot = make_bot_with_cron()
        mock_job = MagicMock()
        mock_job.id = "abcd1234efgh"
        mock_job.name = "test job"
        mock_job.schedule_kind = "every"
        mock_job.enabled = True
        bot.cron.list_jobs.return_value = [mock_job]
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron list"))
        assert result.handled is True
        assert "abcd1234" in result.response

    @pytest.mark.asyncio
    async def test_cron_remove_calls_remove_job(self):
        bot = make_bot_with_cron()
        mock_job = MagicMock()
        mock_job.id = "abcd1234efgh5678"
        bot.cron.list_jobs.return_value = [mock_job]
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron remove abcd1234"))
        assert result.handled is True
        assert "Removed" in result.response
        bot.cron.remove_job.assert_called_once_with("abcd1234efgh5678")

    @pytest.mark.asyncio
    async def test_cron_remove_not_found(self):
        bot = make_bot_with_cron()
        bot.cron.list_jobs.return_value = []
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron remove nonexistent"))
        assert result.handled is True
        assert "No job found" in result.response

    @pytest.mark.asyncio
    async def test_cron_run_queues_job(self):
        bot = make_bot_with_cron()
        mock_job = MagicMock()
        mock_job.id = "abcd1234efgh5678"
        bot.cron.list_jobs.return_value = [mock_job]
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron run abcd1234"))
        assert result.handled is True
        assert "queued" in result.response.lower()
        bot.cron.run_now.assert_called_once_with("abcd1234efgh5678")

    @pytest.mark.asyncio
    async def test_cron_run_not_found(self):
        bot = make_bot_with_cron()
        bot.cron.list_jobs.return_value = []
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron run nonexistent"))
        assert result.handled is True
        assert "No job found" in result.response


# ── Round 2 Fix Tests ─────────────────────────────────────────────────────────

class TestR2AtHumanTime:
    """R2-GPT: at <date> <human-time> should parse correctly."""

    def test_at_date_9am(self):
        result = _parse_cron_add_spec("at 2026-03-27 9am send follow-up")
        assert result is not None
        assert "_error" not in result
        # Should NOT have "9am" in payload — time should be parsed
        assert "9am" not in result.get("payload_text", "")
        assert result["payload_text"] == "send follow-up"

    def test_at_date_6_30pm(self):
        result = _parse_cron_add_spec("at 2026-03-27 6:30pm call bob")
        assert result is not None
        assert "_error" not in result
        assert result["payload_text"] == "call bob"

    def test_at_date_noon(self):
        result = _parse_cron_add_spec("at 2026-03-27 noon lunch meeting")
        assert result is not None
        assert "_error" not in result
        assert result["payload_text"] == "lunch meeting"


class TestR2AtNoPayload:
    """R2-Opus: at <date> <time> with no payload should error, not misparse."""

    def test_at_date_time_no_payload_errors(self):
        result = _parse_cron_add_spec("at 2026-03-27 09:00")
        # Should either error (missing payload) or be None
        assert result is None or "_error" in result


class TestR2CronFieldValidation:
    """R2-GPT/Opus: Semantically impossible cron values should be rejected."""

    def test_minute_99_rejected(self):
        error = _validate_cron_expr("99 6 * * *")
        assert error is not None
        assert "out of range" in error.lower()

    def test_hour_24_rejected(self):
        error = _validate_cron_expr("0 24 * * *")
        assert error is not None

    def test_dom_32_rejected(self):
        error = _validate_cron_expr("0 6 32 * *")
        assert error is not None

    def test_month_13_rejected(self):
        error = _validate_cron_expr("0 6 * 13 *")
        assert error is not None

    def test_valid_still_passes(self):
        error = _validate_cron_expr("0 6 * * 1-5")
        assert error is None

    def test_valid_with_steps_passes(self):
        error = _validate_cron_expr("*/15 9-17 * * 1-5")
        assert error is None


class TestR2UnmatchedQuote:
    """R2-Opus: Unmatched quotes give specific error."""

    def test_unmatched_quote_error(self):
        result = _parse_cron_add_spec('cron "0 6 * * 1-5 do something')
        assert result is not None
        assert "_error" in result
        assert "quote" in result["_error"].lower()


class TestR2CronHelp:
    """R2-Opus: Explicit !cron help handler."""

    @pytest.mark.asyncio
    async def test_cron_help_returns_usage(self):
        bot = make_bot_with_cron()
        dispatcher = CommandDispatcher(bot)
        result = await dispatcher.dispatch(make_inbound("!cron help"))
        assert result.handled is True
        assert "!cron add" in result.response


# ── Round 3 Fix Tests ─────────────────────────────────────────────────────────

class TestR3StepValidation:
    """R3-Opus: Step values should NOT be validated against field range."""

    def test_step_60_in_minute_accepted(self):
        """*/60 is valid — step can exceed field range."""
        error = _validate_cron_expr("*/60 * * * *")
        assert error is None

    def test_step_100_in_hour_accepted(self):
        error = _validate_cron_expr("0 */100 * * *")
        assert error is None

    def test_step_0_rejected(self):
        """Step value 0 is always invalid."""
        error = _validate_cron_expr("*/0 * * * *")
        assert error is not None
        assert "0" in error

    def test_base_values_still_validated(self):
        """Base values (not steps) should still be range-checked."""
        error = _validate_cron_expr("99 6 * * *")
        assert error is not None
        assert "out of range" in error.lower()

    def test_range_with_large_step_accepted(self):
        """1-5/60 — step 60 is fine even though it exceeds range width."""
        error = _validate_cron_expr("1-5/60 * * * *")
        assert error is None


class TestR3NaiveIsoNormalization:
    """R3-Sonnet/GPT/Opus: at with ISO time should be tz-aware."""

    def test_at_iso_space_has_timezone(self):
        """at 2026-03-27 09:00 send msg should store tz-aware datetime."""
        result = _parse_cron_add_spec("at 2026-03-27 09:00 send msg")
        assert result is not None
        assert "_error" not in result
        # Should contain a timezone offset (+ or -)
        at_val = result["schedule_at"]
        assert "+" in at_val or "-" in at_val.split("T")[-1], f"Expected tz-aware, got {at_val}"


class TestR3MacOsIanaResolution:
    """R3-Sonnet/Opus: IANA tz regex should handle macOS zoneinfo.default path."""

    def test_zoneinfo_default_path_matches(self):
        """Regex should extract IANA name from macOS-style path."""
        import re as _re
        target = "/usr/share/zoneinfo.default/America/Los_Angeles"
        match = _re.search(r'zoneinfo[^/]*/(.+)$', target)
        assert match is not None
        assert match.group(1) == "America/Los_Angeles"

    def test_standard_zoneinfo_path_matches(self):
        import re as _re
        target = "/usr/share/zoneinfo/US/Pacific"
        match = _re.search(r'zoneinfo[^/]*/(.+)$', target)
        assert match is not None
        assert match.group(1) == "US/Pacific"


# ── Round 4 Fix Tests ─────────────────────────────────────────────────────────

class TestR4MalformedCronFragments:
    """R4-Opus: Reject malformed cron field fragments."""

    def test_star_slash_empty_rejected(self):
        """'*/' with empty step should be rejected."""
        error = _validate_cron_expr("*/ * * * *")
        assert error is not None
        assert "step" in error.lower() or "empty" in error.lower()

    def test_trailing_dash_rejected(self):
        error = _validate_cron_expr("5- * * * *")
        assert error is not None
        assert "malformed" in error.lower() or "range" in error.lower()

    def test_leading_dash_rejected(self):
        error = _validate_cron_expr("-1 * * * *")
        assert error is not None

    def test_valid_still_passes_after_fragment_checks(self):
        """Ensure tighter validation doesn't break valid expressions."""
        assert _validate_cron_expr("*/15 9-17 1,15 * 1-5") is None
        assert _validate_cron_expr("0 6 * * *") is None
        assert _validate_cron_expr("30 14 * * 0") is None
