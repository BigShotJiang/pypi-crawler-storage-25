from setuptools import setup, find_packages

setup(
    name="obuvstore",
    version="2.1.0",
    description="ИС ООО «Обувь» — готовый пакет для демо-экзамена",
    packages=find_packages(),
    package_data={
        "obuvstore": [
            "data/*.sql",
            "resources/*",
        ]
    },
    include_package_data=True,
    install_requires=[
        "PyQt5>=5.15",
        "mysql-connector-python>=8.0",
        "openpyxl>=3.0",
    ],
    python_requires=">=3.8",

    # Добавляет команду obuvstore-init в терминал
    entry_points={
        "console_scripts": [
            "obuvstore-init=obuvstore.cli:init_project",
        ],
    },
)
