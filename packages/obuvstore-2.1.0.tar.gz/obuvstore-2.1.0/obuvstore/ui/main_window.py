"""
ui/main_window.py — УНИВЕРСАЛЬНОЕ главное окно.
Строит вкладки, таблицы, фильтры и диалоги автоматически из domain.py.
Этот файл менять НЕ нужно.
"""
import os
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget,
    QTableWidgetItem, QLabel, QLineEdit, QPushButton, QComboBox,
    QHeaderView, QAction, QToolBar, QStatusBar, QMessageBox,
    QDialog, QFormLayout, QDoubleSpinBox, QSpinBox, QTabWidget,
    QSizePolicy, QDateEdit, QAbstractItemView
)
from PyQt5.QtCore import Qt, QSize, QDate
from PyQt5.QtGui import QIcon, QColor, QPixmap

from obuvstore import config, domain
from obuvstore.ui.styles import DISCOUNT_ROW_TEXT
from obuvstore.database import connection as db


# ═══════════════════════════════════════════════════════════════
#  УНИВЕРСАЛЬНЫЙ ДИАЛОГ добавления / редактирования строки
# ═══════════════════════════════════════════════════════════════
class EntityDialog(QDialog):
    def __init__(self, entity: dict, row: dict = None, parent=None):
        super().__init__(parent)
        self.entity = entity
        self.row = row
        self.widgets = {}   # field -> виджет
        title = entity_name(entity)
        self.setWindowTitle(
            f"Добавление: {title}" if row is None
            else f"Редактирование: {title}"
        )
        self.setMinimumWidth(440)
        self._build()

    def _build(self):
        layout = QFormLayout(self)
        layout.setSpacing(10)

        for col in self.entity["columns"]:
            if col.get("editable", True) is False:
                continue
            widget = self._make_widget(col)
            self.widgets[col["field"]] = (col, widget)
            layout.addRow(col["label"] + ":", widget)

        btn_row = QHBoxLayout()
        btn_ok = QPushButton("Сохранить")
        btn_ok.setObjectName("btnAccent")
        btn_ok.clicked.connect(self.accept)
        btn_cancel = QPushButton("Отмена")
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_ok)
        btn_row.addWidget(btn_cancel)
        layout.addRow(btn_row)

    def _make_widget(self, col):
        """Создаёт подходящий виджет под тип колонки."""
        ctype = col["type"]
        field = col["field"]
        current = self.row.get(field) if self.row else None

        if ctype == "int":
            w = QSpinBox()
            w.setRange(-2_000_000_000, 2_000_000_000)
            if current is not None:
                w.setValue(int(current))
            return w

        if ctype == "decimal":
            w = QDoubleSpinBox()
            w.setRange(0, 9_999_999)
            w.setDecimals(2)
            if current is not None:
                w.setValue(float(current))
            return w

        if ctype == "date":
            w = QDateEdit()
            w.setCalendarPopup(True)
            w.setDisplayFormat("yyyy-MM-dd")
            w.setDate(self._to_qdate(current))
            return w

        if ctype == "enum":
            w = QComboBox()
            w.addItems([str(o) for o in col.get("options", [])])
            if current is not None:
                idx = w.findText(str(current))
                if idx >= 0:
                    w.setCurrentIndex(idx)
            return w

        if ctype == "ref":
            w = QComboBox()
            w.addItem("— не выбрано —", None)
            try:
                for opt in db.fetch_ref_options(col):
                    w.addItem(str(opt["label"]), opt["id"])
            except Exception:
                pass
            if current is not None:
                idx = w.findData(current)
                if idx >= 0:
                    w.setCurrentIndex(idx)
            return w

        # text по умолчанию
        w = QLineEdit()
        if current is not None:
            w.setText(str(current))
        return w

    @staticmethod
    def _to_qdate(value):
        if value is None:
            return QDate.currentDate()
        try:
            qd = QDate.fromString(str(value)[:10], "yyyy-MM-dd")
            return qd if qd.isValid() else QDate.currentDate()
        except Exception:
            return QDate.currentDate()

    def get_data(self) -> dict:
        """Считывает значения всех виджетов."""
        result = {}
        for field, (col, w) in self.widgets.items():
            ctype = col["type"]
            if ctype == "int":
                result[field] = w.value()
            elif ctype == "decimal":
                result[field] = w.value()
            elif ctype == "date":
                result[field] = w.date().toString("yyyy-MM-dd")
            elif ctype == "enum":
                result[field] = w.currentText()
            elif ctype == "ref":
                result[field] = w.currentData()
            else:
                result[field] = w.text().strip()
        return result


# ═══════════════════════════════════════════════════════════════
#  УНИВЕРСАЛЬНАЯ ВКЛАДКА сущности
# ═══════════════════════════════════════════════════════════════
class EntityTab(QWidget):
    def __init__(self, entity: dict, role: str, parent=None):
        super().__init__(parent)
        self.entity = entity
        self.role = role
        self.rows = []
        self.search_edit = None
        self.sort_combo = None

        self.can_filter = role in entity.get("roles_filter", [])
        self.can_edit = role in entity.get("roles_edit", [])

        self._build()
        self.refresh()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        title = QLabel(entity_name(self.entity))
        title.setObjectName("sectionTitle")
        layout.addWidget(title)

        # Поиск + сортировка
        if self.can_filter:
            flt = QHBoxLayout()
            self.search_edit = QLineEdit()
            self.search_edit.setPlaceholderText("Поиск…")
            self.search_edit.textChanged.connect(self.refresh)

            self.sort_combo = QComboBox()
            self.sort_combo.addItem("Без сортировки", None)
            for c in self.entity["columns"]:
                self.sort_combo.addItem(f"{c['label']} ↑", (c["field"], "ASC"))
                self.sort_combo.addItem(f"{c['label']} ↓", (c["field"], "DESC"))
            self.sort_combo.currentIndexChanged.connect(self.refresh)

            flt.addWidget(QLabel("Поиск:"))
            flt.addWidget(self.search_edit, 3)
            flt.addWidget(QLabel("Сортировка:"))
            flt.addWidget(self.sort_combo, 2)
            layout.addLayout(flt)

        # Таблица
        cols = self.entity["columns"]
        self.table = QTableWidget(0, len(cols))
        self.table.setHorizontalHeaderLabels([c["label"] for c in cols])
        self.table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.Stretch
        )
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        layout.addWidget(self.table)

        # Кнопки CRUD
        if self.can_edit:
            btns = QHBoxLayout()
            b_add = QPushButton("Добавить")
            b_edit = QPushButton("Редактировать")
            b_del = QPushButton("Удалить")
            b_del.setObjectName("btnDanger")
            b_add.clicked.connect(self._add)
            b_edit.clicked.connect(self._edit)
            b_del.clicked.connect(self._delete)
            btns.addWidget(b_add)
            btns.addWidget(b_edit)
            btns.addWidget(b_del)
            btns.addStretch()
            layout.addLayout(btns)

    def refresh(self):
        search = ""
        sort_field, sort_dir = None, "ASC"
        if self.can_filter and self.search_edit is not None:
            search = self.search_edit.text()
            data = self.sort_combo.currentData()
            if data:
                sort_field, sort_dir = data

        try:
            self.rows = db.fetch_entity(
                self.entity, search=search,
                sort_field=sort_field, sort_dir=sort_dir
            )
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", f"Не удалось загрузить данные:\n{e}")
            self.rows = []

        cols = self.entity["columns"]
        highlight = self.entity.get("highlight")

        self.table.setRowCount(0)
        for r, row in enumerate(self.rows):
            self.table.insertRow(r)
            for c_idx, col in enumerate(cols):
                field = col["field"]
                # для ссылочных колонок показываем подпись, а не id
                if col["type"] == "ref":
                    value = row.get(f"{field}__label") or "—"
                else:
                    value = row.get(field)
                    value = "—" if value is None else value
                item = QTableWidgetItem(str(value))
                item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(r, c_idx, item)

            # Условная подсветка строки
            if highlight and self._check_highlight(row, highlight):
                for c_idx in range(len(cols)):
                    cell = self.table.item(r, c_idx)
                    cell.setBackground(QColor(highlight["color"]))
                    cell.setForeground(QColor(DISCOUNT_ROW_TEXT))

    @staticmethod
    def _check_highlight(row, rule):
        try:
            val = float(row.get(rule["field"]) or 0)
            target = float(rule["value"])
            op = rule.get("op", ">")
            if op == ">":  return val > target
            if op == ">=": return val >= target
            if op == "<":  return val < target
            if op == "<=": return val <= target
            if op == "==": return val == target
        except Exception:
            return False
        return False

    def _selected(self):
        r = self.table.currentRow()
        if r < 0 or r >= len(self.rows):
            QMessageBox.warning(self, "Выбор", "Выберите строку в таблице.")
            return None
        return self.rows[r]

    def _add(self):
        dlg = EntityDialog(self.entity, parent=self)
        if dlg.exec_() == QDialog.Accepted:
            try:
                db.insert_entity(self.entity, dlg.get_data())
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось добавить:\n{e}")
                return
            self.refresh()

    def _edit(self):
        row = self._selected()
        if not row:
            return
        dlg = EntityDialog(self.entity, row=row, parent=self)
        if dlg.exec_() == QDialog.Accepted:
            try:
                db.update_entity(
                    self.entity, row[self.entity["pk"]], dlg.get_data()
                )
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить:\n{e}")
                return
            self.refresh()

    def _delete(self):
        row = self._selected()
        if not row:
            return
        reply = QMessageBox.question(
            self, "Подтверждение", "Удалить выбранную строку?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            try:
                db.delete_entity(self.entity, row[self.entity["pk"]])
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось удалить:\n{e}")
                return
            self.refresh()


def entity_name(entity):
    """Находит название вкладки сущности по её описанию."""
    for name, e in domain.ENTITIES.items():
        if e is entity:
            return name
    return entity.get("table", "Запись")


# ═══════════════════════════════════════════════════════════════
#  ГЛАВНОЕ ОКНО
# ═══════════════════════════════════════════════════════════════
class MainWindow(QMainWindow):
    def __init__(self, user: dict = None):
        super().__init__()
        self.user = user
        guest_role = domain.APP.get("guest_role", "Гость")
        self.role = user["role_name"] if user else guest_role
        self.setWindowTitle(f"{domain.APP['title']} — {self.role}")
        self.setMinimumSize(config.WINDOW_MIN_W, config.WINDOW_MIN_H)
        if os.path.exists(config.ICON_APP):
            self.setWindowIcon(QIcon(config.ICON_APP))
        self._build_menu()
        self._build_toolbar()
        self._build_central()
        self._build_statusbar()

    def _build_menu(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("Файл")
        act_exit = QAction("Выход", self)
        act_exit.setShortcut("Ctrl+Q")
        act_exit.triggered.connect(self.close)
        file_menu.addAction(act_exit)

        data_menu = menubar.addMenu("Данные")
        act_refresh = QAction("Обновить", self)
        act_refresh.setShortcut("F5")
        act_refresh.triggered.connect(self._refresh_current)
        data_menu.addAction(act_refresh)

        help_menu = menubar.addMenu("Справка")
        act_about = QAction("О программе", self)
        act_about.triggered.connect(self._show_about)
        help_menu.addAction(act_about)

    def _build_toolbar(self):
        tb = QToolBar("Главная панель")
        tb.setIconSize(QSize(24, 24))
        tb.setMovable(False)
        self.addToolBar(tb)

        if os.path.exists(config.LOGO_FILE):
            logo = QLabel()
            logo.setPixmap(
                QPixmap(config.LOGO_FILE).scaledToHeight(32, Qt.SmoothTransformation)
            )
            logo.setStyleSheet("padding: 0 10px;")
            tb.addWidget(logo)
            tb.addSeparator()

        act_refresh = QAction("Обновить", self)
        act_refresh.triggered.connect(self._refresh_current)
        tb.addAction(act_refresh)
        tb.addSeparator()
        act_exit = QAction("Выход", self)
        act_exit.triggered.connect(self.close)
        tb.addAction(act_exit)

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tb.addWidget(spacer)
        name = self.user["full_name"] if self.user else "Гость"
        lbl = QLabel(f"{name}   |   {self.role}")
        lbl.setStyleSheet("padding-right: 12px; font-weight: bold;")
        tb.addWidget(lbl)

    def _build_central(self):
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        # Создаём вкладку для каждой сущности, доступной этой роли
        for name, entity in domain.ENTITIES.items():
            if self.role in entity.get("roles_view", []):
                tab = EntityTab(entity, role=self.role)
                self.tabs.addTab(tab, name)

        if self.tabs.count() == 0:
            empty = QLabel("Для вашей роли нет доступных разделов.")
            empty.setAlignment(Qt.AlignCenter)
            self.tabs.addTab(empty, "—")

    def _build_statusbar(self):
        sb = QStatusBar()
        self.setStatusBar(sb)
        sb.addPermanentWidget(QLabel(f"Роль: {self.role}"))
        sb.showMessage(f"Добро пожаловать — {domain.APP['title']}", 5000)

    def _refresh_current(self):
        w = self.tabs.currentWidget()
        if w is not None and hasattr(w, "refresh"):
            w.refresh()

    def _show_about(self):
        QMessageBox.information(
            self, "О программе",
            f"{domain.APP['title']}\n\n"
            f"Текущая роль: {self.role}\n"
            f"Сервер БД: {config.DB_HOST}:{config.DB_PORT}\n"
            f"База данных: {config.DB_NAME}"
        )
