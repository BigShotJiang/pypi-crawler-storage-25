# =============================================================
#  config.py — ЕДИНЫЙ ФАЙЛ НАСТРОЕК
#  Меняй только этот файл — всё остальное подхватится само
# =============================================================

# ── ПОДКЛЮЧЕНИЕ К MySQL ───────────────────────────────────────
DB_HOST     = "localhost"       # ← адрес сервера
DB_PORT     = 3306
DB_USER     = "root"            # ← логин MySQL
DB_PASSWORD = "root"   # ← пароль MySQL
DB_NAME     = "obuvstore"       # ← имя базы данных

# ── ЦВЕТА (по техзаданию Модуля 2) ───────────────────────────
COLOR_BG_PRIMARY   = "#FFFFFF"   # Основной фон
COLOR_BG_SECONDARY = "#7FFF00"   # Дополнительный фон
COLOR_ACCENT       = "#00FA9A"   # Акцент / целевое действие
COLOR_DISCOUNT     = "#2E8B57"   # Фон строки при скидке > 15%
COLOR_TEXT         = "#1A1A1A"   # Основной цвет текста
COLOR_TEXT_LIGHT   = "#555555"   # Вторичный текст
COLOR_BORDER       = "#CCCCCC"   # Рамки/разделители

# ── ШРИФТЫ ───────────────────────────────────────────────────
FONT_FAMILY      = "Times New Roman"
FONT_SIZE_SMALL  = 10
FONT_SIZE_NORMAL = 12
FONT_SIZE_LARGE  = 14
FONT_SIZE_TITLE  = 18

# ── ОКНО ─────────────────────────────────────────────────────
WINDOW_TITLE  = "ООО «Обувь»"
WINDOW_MIN_W  = 1000
WINDOW_MIN_H  = 650

# ── ПУТЬ К РЕСУРСАМ ──────────────────────────────────────────
import os
RESOURCES_DIR = os.path.join(os.path.dirname(__file__), "resources")
ICON_APP      = os.path.join(RESOURCES_DIR, "icon.ico")
LOGO_FILE     = os.path.join(RESOURCES_DIR, "logo.png")
