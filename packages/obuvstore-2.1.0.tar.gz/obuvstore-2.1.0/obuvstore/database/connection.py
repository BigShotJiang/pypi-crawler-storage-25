"""
database/connection.py
УНИВЕРСАЛЬНЫЙ слой работы с БД.
Все запросы строятся автоматически из описания в domain.py.
Этот файл менять НЕ нужно.
"""
import mysql.connector
from obuvstore import config, domain

_connection = None


def get_connection():
    global _connection
    if _connection is None or not _connection.is_connected():
        _connection = mysql.connector.connect(
            host=config.DB_HOST,
            port=config.DB_PORT,
            user=config.DB_USER,
            password=config.DB_PASSWORD,
            database=config.DB_NAME,
            charset="utf8mb4",
            autocommit=True,
        )
        print(f"[obuvstore] Подключено к MySQL: {config.DB_HOST}/{config.DB_NAME}")
    return _connection


def close_connection():
    global _connection
    if _connection and _connection.is_connected():
        _connection.close()
        _connection = None


def execute_query(sql: str, params: tuple = (), fetch: bool = False):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute(sql, params)
        if fetch:
            return cursor.fetchall()
        conn.commit()
        return cursor.lastrowid
    finally:
        cursor.close()


# ═══════════════ АВТОРИЗАЦИЯ (из domain.AUTH) ═══════════════

def get_user_by_login(login: str, password: str):
    a = domain.AUTH
    rj = a["role_join"]
    sql = (
        f"SELECT u.*, r.`{rj['role_name_field']}` AS role_name "
        f"FROM `{a['table']}` u "
        f"JOIN `{rj['role_table']}` r "
        f"  ON u.`{rj['role_fk']}` = r.`{rj['role_pk']}` "
        f"WHERE u.`{a['login_field']}`=%s AND u.`{a['password_field']}`=%s "
        f"LIMIT 1"
    )
    rows = execute_query(sql, (login, password), fetch=True)
    return rows[0] if rows else None


# ═══════════════ УНИВЕРСАЛЬНЫЙ CRUD (из domain.ENTITIES) ═══════════════

def fetch_entity(entity: dict, search: str = "",
                 sort_field: str = None, sort_dir: str = "ASC"):
    """Читает строки сущности. Сам делает JOIN для ссылочных колонок."""
    table = entity["table"]
    pk = entity["pk"]
    cols = entity["columns"]

    select_parts = [f"m.`{pk}` AS `{pk}`"]
    joins = []
    text_fields = []

    for i, c in enumerate(cols):
        field = c["field"]
        select_parts.append(f"m.`{field}` AS `{field}`")
        if c["type"] == "ref":
            alias = f"j{i}"
            select_parts.append(
                f"{alias}.`{c['ref_label']}` AS `{field}__label`"
            )
            joins.append(
                f"LEFT JOIN `{c['ref_table']}` {alias} "
                f"ON m.`{field}` = {alias}.`{c['ref_pk']}`"
            )
        elif c["type"] == "text":
            text_fields.append(f"m.`{field}`")

    sql = f"SELECT {', '.join(select_parts)} FROM `{table}` m " + " ".join(joins)
    params = []

    if search and text_fields:
        conds = " OR ".join(f"{tf} LIKE %s" for tf in text_fields)
        sql += f" WHERE ({conds})"
        params += [f"%{search}%"] * len(text_fields)

    if sort_field:
        direction = "DESC" if str(sort_dir).upper() == "DESC" else "ASC"
        sql += f" ORDER BY m.`{sort_field}` {direction}"
    else:
        sql += f" ORDER BY m.`{pk}` DESC"

    return execute_query(sql, tuple(params), fetch=True)


def insert_entity(entity: dict, data: dict):
    """Добавляет строку. data = {колонка: значение}."""
    table = entity["table"]
    fields = list(data.keys())
    collist = ", ".join(f"`{f}`" for f in fields)
    placeholders = ", ".join(["%s"] * len(fields))
    sql = f"INSERT INTO `{table}` ({collist}) VALUES ({placeholders})"
    return execute_query(sql, tuple(data.values()))


def update_entity(entity: dict, pk_value, data: dict):
    """Обновляет строку по первичному ключу."""
    table = entity["table"]
    pk = entity["pk"]
    setpart = ", ".join(f"`{f}`=%s" for f in data)
    sql = f"UPDATE `{table}` SET {setpart} WHERE `{pk}`=%s"
    execute_query(sql, tuple(list(data.values()) + [pk_value]))


def delete_entity(entity: dict, pk_value):
    """Удаляет строку по первичному ключу."""
    table = entity["table"]
    pk = entity["pk"]
    execute_query(f"DELETE FROM `{table}` WHERE `{pk}`=%s", (pk_value,))


def fetch_ref_options(column: dict):
    """Список значений для ссылочной колонки (для выпадающего списка)."""
    sql = (
        f"SELECT `{column['ref_pk']}` AS id, "
        f"`{column['ref_label']}` AS label "
        f"FROM `{column['ref_table']}` ORDER BY label"
    )
    return execute_query(sql, fetch=True)


def get_next_number(table: str, field: str):
    """Следующий свободный номер (для авто-нумерации заказов и т.п.)."""
    rows = execute_query(
        f"SELECT COALESCE(MAX(`{field}`), 0) + 1 AS n FROM `{table}`",
        fetch=True
    )
    return rows[0]["n"] if rows else 1
