"""
obuvstore/__init__.py — запускается при: import obuvstore
Схема БД применяется ТОЛЬКО при первом запуске (когда таблиц нет).
"""
import os
import sys


def _get_sql_path() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, "data", "obuvstore_full.sql")


def _ensure_resource_dirs():
    os.makedirs(os.path.join(os.getcwd(), "resources"), exist_ok=True)


def _export_sql():
    src = _get_sql_path()
    dst = os.path.join(os.getcwd(), "obuvstore_schema.sql")
    if not os.path.exists(dst) and os.path.exists(src):
        import shutil
        shutil.copy(src, dst)
        print(f"[obuvstore] SQL-схема скопирована → {dst}")


def _setup_db():
    try:
        from obuvstore.database.connection import get_connection
        from obuvstore import domain
        conn = get_connection()
        cursor = conn.cursor()
        # проверяем по первой сущности — есть ли уже таблицы
        first_table = next(iter(domain.ENTITIES.values()))["table"]
        cursor.execute(f"SHOW TABLES LIKE '{first_table}'")
        if cursor.fetchone() is not None:
            cursor.close()
            print("[obuvstore] ✅ База данных подключена. Данные сохранены.")
            return
        print("[obuvstore] Первый запуск — создаю схему БД...")
        with open(_get_sql_path(), encoding="utf-8") as f:
            raw = f.read()
        for stmt in raw.split(";"):
            s = stmt.strip()
            if s:
                try:
                    cursor.execute(s)
                except Exception:
                    pass
        conn.commit()
        cursor.close()
        print("[obuvstore] ✅ База данных создана и заполнена.")
    except Exception as e:
        print(
            f"\n[obuvstore] ⚠️  Не удалось подключиться к MySQL: {e}\n"
            "  1. Проверь что MySQL Server запущен\n"
            "  2. Открой obuvstore/config.py — проверь DB_HOST, DB_USER, DB_PASSWORD\n"
            "  3. Убедись что база создана (импортируй obuvstore_schema.sql)\n"
        )


_ensure_resource_dirs()
_export_sql()
_setup_db()

from obuvstore.ui.styles      import get_app_stylesheet   # noqa: E402
from obuvstore.ui.login       import LoginDialog           # noqa: E402
from obuvstore.ui.main_window import MainWindow            # noqa: E402


def run_app():
    from PyQt5.QtWidgets import QApplication, QDialog
    app = QApplication(sys.argv)
    app.setStyleSheet(get_app_stylesheet())

    current_user = {}
    chose_guest = {"value": False}

    login = LoginDialog()
    login.login_success.connect(lambda u: current_user.update(u))
    login.guest_mode.connect(lambda: chose_guest.update({"value": True}))

    result = login.exec_()

    # Крестик / Esc — пользователь НЕ вошёл и НЕ выбрал гостя → выход
    if result != QDialog.Accepted or (not current_user and not chose_guest["value"]):
        sys.exit(0)

    user = current_user if current_user.get("user_id") else None
    window = MainWindow(user=user)
    window.show()
    sys.exit(app.exec_())
