/**
 * Auto-installation of binary dependencies for the KISS Sorcar extension.
 * Ensures uv, git, Node.js, VS Code CLI, Python environment, and Playwright
 * Chromium are available.  Called during extension activation.
 */

import * as vscode from 'vscode';
import * as path from 'path';
import * as os from 'os';
import * as fs from 'fs';
import * as https from 'https';
import * as crypto from 'crypto';
import {exec, execSync, execFileSync, spawn} from 'child_process';
import {findKissProject, findUvPath} from './AgentProcess';

const HOME_DIR = process.env.HOME || process.env.USERPROFILE || '';
const LOG_DIR = path.join(HOME_DIR, '.kiss');
const LOG_FILE = path.join(LOG_DIR, 'install.log');
const MIN_PYTHON_MAJOR = 3;
const MIN_PYTHON_MINOR = 13;
const UV_VERSION = '0.11.2';
const NODE_VERSION = 'v22.16.0';

/**
 * Escape a string so it is safe to embed inside an XML ``<string>``
 * element (e.g. macOS LaunchAgent plist).  Without escaping a path
 * containing ``&`` or ``<`` produces malformed XML and ``launchctl``
 * silently rejects the unit.
 */
function xmlEscape(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Escape a string so it is safe to embed inside a systemd unit value.
 * Backslashes and newlines must not appear unescaped — they otherwise
 * silently corrupt the unit.
 */
function unitEscape(s: string): string {
  return s.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/%/g, '%%');
}

/**
 * Download a URL into ``destPath`` using the Node ``https`` module.
 * Follows up to 5 redirects.  Resolves only after the response has been
 * fully written to disk.  Never spawns a shell.
 */
function downloadFile(
  url: string,
  destPath: string,
  maxRedirects = 5,
): Promise<void> {
  return new Promise((resolve, reject) => {
    const get = (u: string, hops: number): void => {
      const req = https.get(u, {timeout: 60000}, res => {
        const status = res.statusCode || 0;
        if (status >= 300 && status < 400 && res.headers.location) {
          if (hops <= 0) {
            res.resume();
            reject(new Error(`Too many redirects from ${url}`));
            return;
          }
          res.resume();
          const next = new URL(res.headers.location, u).toString();
          get(next, hops - 1);
          return;
        }
        if (status !== 200) {
          res.resume();
          reject(new Error(`HTTP ${status} fetching ${u}`));
          return;
        }
        const out = fs.createWriteStream(destPath);
        res.pipe(out);
        out.on('finish', () =>
          out.close(err => (err ? reject(err) : resolve())),
        );
        out.on('error', reject);
      });
      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy(new Error(`Timeout downloading ${u}`));
      });
    };
    get(url, maxRedirects);
  });
}

/**
 * Compute the lowercase-hex SHA256 digest of a file on disk.
 */
function sha256OfFile(filePath: string): string {
  const buf = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buf).digest('hex');
}

/**
 * Best-effort integrity check for a downloaded asset against a vendor-
 * published SHA256 file (e.g. ``<url>.sha256`` for uv, ``SHASUMS256.txt``
 * for nodejs.org).  When ``expectedHashHex`` is given and does not match,
 * the file is unlinked and an error is thrown.  When omitted (vendor
 * does not publish a hash), the function logs a warning and returns —
 * we do not silently skip integrity for binaries we know how to verify.
 *
 * Pinning the digest in the extension source is preferable but requires
 * release-time bookkeeping; this helper at minimum compares against the
 * SHA256 file fetched from the same release URL, defending against
 * CDN/mirror corruption and accidental wrong-asset downloads.
 */
async function verifyDownloadHash(
  filePath: string,
  expectedHashHex: string | null,
): Promise<void> {
  const got = sha256OfFile(filePath);
  if (!expectedHashHex) {
    log(
      `No SHA256 expectation for ${path.basename(filePath)}; ` +
        `computed hash = ${got}`,
    );
    return;
  }
  if (got.toLowerCase() !== expectedHashHex.toLowerCase()) {
    try {
      fs.unlinkSync(filePath);
    } catch {
      /* ignore */
    }
    throw new Error(
      `SHA256 mismatch for ${path.basename(filePath)}: ` +
        `expected ${expectedHashHex}, got ${got}`,
    );
  }
  log(`SHA256 ok for ${path.basename(filePath)}`);
}

/**
 * Fetch ``<assetUrl>.sha256`` (uv-style sidecar) and return the hex digest,
 * or null when the sidecar isn't available.
 */
function fetchUvStyleSha256(assetUrl: string): Promise<string | null> {
  return new Promise(resolve => {
    const req = https.get(assetUrl + '.sha256', {timeout: 15000}, res => {
      if ((res.statusCode || 0) !== 200) {
        res.resume();
        resolve(null);
        return;
      }
      const chunks: Buffer[] = [];
      res.on('data', d => chunks.push(d));
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf-8').trim();
        // sidecar is "<hex>  filename"
        const m = /^([0-9a-fA-F]{64})/.exec(text);
        resolve(m ? m[1] : null);
      });
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => {
      req.destroy();
      resolve(null);
    });
  });
}

/**
 * Fetch ``https://nodejs.org/dist/<NODE_VERSION>/SHASUMS256.txt`` and find
 * the hash for ``assetName``.  Returns null on any error.
 */
function fetchNodeSha256(assetName: string): Promise<string | null> {
  const url = `https://nodejs.org/dist/${NODE_VERSION}/SHASUMS256.txt`;
  return new Promise(resolve => {
    const req = https.get(url, {timeout: 15000}, res => {
      if ((res.statusCode || 0) !== 200) {
        res.resume();
        resolve(null);
        return;
      }
      const chunks: Buffer[] = [];
      res.on('data', d => chunks.push(d));
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf-8');
        for (const line of text.split('\n')) {
          const m = /^([0-9a-fA-F]{64})\s+(.+?)\s*$/.exec(line);
          if (m && m[2] === assetName) {
            resolve(m[1]);
            return;
          }
        }
        resolve(null);
      });
    });
    req.on('error', () => resolve(null));
    req.on('timeout', () => {
      req.destroy();
      resolve(null);
    });
  });
}

/**
 * Run a child process without invoking a shell, capturing combined
 * stdout/stderr, and resolving with the trimmed stdout on exit code 0.
 * Used for ``tar``, ``mv``, etc. where a shell would be required only
 * to interpolate user-controlled paths.
 */
function spawnPromise(
  cmd: string,
  args: string[],
  cwd?: string,
  timeoutMs = 300_000,
): Promise<string> {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args, {cwd, stdio: ['ignore', 'pipe', 'pipe']});
    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => {
      proc.kill('SIGKILL');
      reject(
        new Error(`${cmd} ${args.join(' ')} timed out after ${timeoutMs}ms`),
      );
    }, timeoutMs);
    proc.stdout?.on('data', (d: Buffer) => {
      stdout += d.toString();
    });
    proc.stderr?.on('data', (d: Buffer) => {
      stderr += d.toString();
    });
    proc.on('close', code => {
      clearTimeout(timer);
      if (code === 0) resolve(stdout.trim());
      else
        reject(
          new Error(
            `${cmd} ${args.join(' ')} exited ${code}: ${stderr.trim()}`,
          ),
        );
    });
    proc.on('error', err => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

/** Guard against concurrent ensureDependencies calls. */
let pendingDeps: Promise<void> | null = null;

/**
 * Write a timestamped message to ~/.kiss/install.log and the developer console.
 */
function log(message: string): void {
  const line = `[${new Date().toISOString()}] ${message}`;
  console.log('[KISS Sorcar]', message);
  try {
    fs.mkdirSync(LOG_DIR, {recursive: true});
    fs.appendFileSync(LOG_FILE, line + '\n');
  } catch {
    /* ignore write errors */
  }
}

/**
 * Prepend ~/.local/bin to process.env.PATH so that binaries installed by
 * the extension (uv, node, sorcar) are found by all child processes.
 * Safe to call multiple times — skips if already present.
 */
export function ensureLocalBinInPath(): void {
  if (!HOME_DIR) return;
  const localBin = path.join(HOME_DIR, '.local', 'bin');
  const parts = (process.env.PATH || '').split(path.delimiter);
  if (!parts.includes(localBin)) {
    process.env.PATH = `${localBin}${path.delimiter}${process.env.PATH || ''}`;
  }
}

/**
 * Find the actual Node.js directory inside the base install dir on Windows.
 * Node.js extracts to a nested subdirectory like node-v22.16.0-win-x64/.
 * Returns the nested directory containing node.exe, or baseDir as fallback.
 */
function findNodeDirWindows(baseDir: string): string {
  try {
    for (const entry of fs.readdirSync(baseDir)) {
      const candidate = path.join(baseDir, entry);
      if (fs.existsSync(path.join(candidate, 'node.exe'))) return candidate;
    }
  } catch {
    /* ignore */
  }
  return baseDir;
}

/**
 * Return the best default model name by calling Python's canonical
 * ``get_default_model()`` from ``kiss.core.models.model_info``.
 *
 * Requires ``uv`` and the KISS project ``.venv`` to be available.
 * Returns an empty string when the Python call fails (e.g. during
 * first-time setup before dependencies are installed).  The backend
 * will send the real model via the ``showWelcome`` event in that case.
 */
export function getDefaultModel(): string {
  const uvPath = findUvPath();
  const kissProject = findKissProject();
  if (!uvPath || !kissProject) return '';
  try {
    // H1 — argv-form so quotes / shell metacharacters in either path
    // (both come from user-controlled HOME / settings) cannot inject.
    return execFileSync(
      uvPath,
      [
        'run',
        '--directory',
        kissProject,
        'python',
        '-c',
        'from kiss.core.models.model_info import get_default_model; ' +
          'print(get_default_model())',
      ],
      {encoding: 'utf-8', timeout: 15_000, stdio: ['ignore', 'pipe', 'ignore']},
    ).trim();
  } catch {
    return '';
  }
}

/**
 * Run the post-install finalization steps: install the ``sorcar`` CLI
 * wrapper, restart the kiss-web daemon, persist PATH entries to the
 * user's shell rc file, and prompt for any missing API keys.  Returns
 * whether at least one API key (or the Claude CLI) is available.
 *
 * When called with a non-null ``progress`` reporter this function
 * publishes brief sub-step messages so the surrounding "KISS Sorcar:
 * Setting up" notification stays visible continuously from the first
 * install step until the restart prompt is shown.  Passing ``null``
 * skips the progress reports (used on the fast path, which has no
 * progress notification to annotate).
 */
async function runFinalization(
  progress: vscode.Progress<{message?: string; increment?: number}> | null,
  kissProjectPath: string,
  uvPath: string | null,
): Promise<boolean> {
  if (uvPath) {
    if (progress) progress.report({message: 'Installing CLI wrapper...'});
    installCliScript(kissProjectPath, uvPath);
  }

  if (progress) progress.report({message: 'Restarting kiss-web daemon...'});
  restartKissWebDaemon(kissProjectPath);

  if (progress) progress.report({message: 'Updating shell PATH...'});
  try {
    const rcPath = getShellRcPath();
    const localBin = path.join(HOME_DIR, '.local', 'bin');
    ensurePathInShellRc(rcPath, localBin);
    if (process.platform === 'win32') {
      const gitCmdDir = path.join(HOME_DIR, '.local', 'git', 'cmd');
      if (fs.existsSync(gitCmdDir)) {
        ensurePathInShellRc(rcPath, gitCmdDir);
      }
      const nodeBaseDir = path.join(HOME_DIR, '.local', 'node');
      const nodeDir = findNodeDirWindows(nodeBaseDir);
      if (fs.existsSync(nodeDir)) {
        ensurePathInShellRc(rcPath, nodeDir);
      }
    }
  } catch (err) {
    log(
      `Failed to update shell rc PATH: ${err instanceof Error ? err.message : err}`,
    );
  }

  if (progress) progress.report({message: 'Checking API keys...'});
  const apiKeysReady = await ensureApiKeys();

  if (progress) progress.report({message: 'Checking remote password...'});
  await ensureRemotePassword();

  return apiKeysReady;
}

/**
 * Ensure all required dependencies are installed.
 * Shows a progress notification during first-time installation.
 * Safe to call multiple times — uses a concurrency guard so overlapping
 * calls reuse the in-flight check instead of racing.
 */
export function ensureDependencies(): Promise<void> {
  if (pendingDeps) return pendingDeps;
  pendingDeps = ensureDependenciesImpl().finally(() => {
    pendingDeps = null;
  });
  return pendingDeps;
}

async function ensureDependenciesImpl(): Promise<void> {
  ensureLocalBinInPath();
  log('=== Dependency check started ===');

  const kissProjectPath = findKissProject();
  if (!kissProjectPath) {
    log('KISS project not found — skipping dependency setup');
    vscode.window.showErrorMessage(
      'KISS Sorcar: Could not find the KISS project directory. ' +
        'Please set "kissSorcar.kissProjectPath" in VS Code settings. ' +
        'See ~/.kiss/install.log for details.',
    );
    return;
  }
  log(`KISS project: ${kissProjectPath}`);

  // Early exit: when all dependencies are fully installed, the daemon is
  // running, and no extension update is pending, skip all setup work.
  // This avoids the 162 MB Playwright re-download, daemon restart, and
  // CLI script rewrite that previously ran on every VS Code activation.
  const updateMarker = path.join(LOG_DIR, '.extension-updated');
  if (
    findUvPath() &&
    fs.existsSync(path.join(kissProjectPath, '.venv')) &&
    isChromiumInstalled() &&
    isDaemonRunning() &&
    !fs.existsSync(updateMarker)
  ) {
    log('All dependencies satisfied and daemon running — nothing to do');
    log('=== Dependency check finished ===');
    loadApiKeysFromShellRc();
    return;
  }

  let uvPath = findUvPath();
  let venvExists = fs.existsSync(path.join(kissProjectPath, '.venv'));

  // If .venv exists but Python is genuinely too old, remove it so uv sync
  // recreates it.  Transient errors (timeout, spawn failure) must NOT delete
  // .venv — that causes unnecessary slow-path rebuilds on every activation.
  if (uvPath && venvExists) {
    const pyStatus = checkPythonVersion(uvPath, kissProjectPath);
    if (pyStatus === 'too_old') {
      log('Python version too old — removing .venv for recreation');
      try {
        fs.rmSync(path.join(kissProjectPath, '.venv'), {
          recursive: true,
          force: true,
        });
      } catch {
        /* ignored */
      }
      venvExists = false;
    } else if (pyStatus === 'error') {
      log('Python version check failed (transient) — keeping .venv');
    }
  }

  // Check if build-extension.sh just ran (marker file written by the script).
  // When the marker exists, always show the restart notification — even on
  // the fast path where uv + .venv are already present.
  // (updateMarker is declared above for the early-exit guard.)
  let showRestartNotification = false;
  // ``apiKeysReady`` is set by ``runFinalization`` in either the fast
  // or slow path below.  Declared up here so the post-progress
  // restart-notification block below can read it regardless of which
  // path was taken.
  let apiKeysReady = false;
  if (fs.existsSync(updateMarker)) {
    showRestartNotification = true;
    try {
      fs.unlinkSync(updateMarker);
    } catch {
      /* ignore */
    }
    log('Extension-updated marker found — will show restart notification');
  }

  // Fast path: everything looks ready, ensure playwright in background
  if (uvPath && venvExists) {
    log('Fast path: uv and .venv present, ensuring Playwright in background');
    const uv = uvPath; // capture narrowed non-null type for closure
    runAsync(
      uv,
      ['run', 'python', '-m', 'playwright', 'install', 'chromium'],
      kissProjectPath,
    )
      .then(async () => {
        if (process.platform === 'linux') {
          await runAsync(
            uv,
            ['run', 'python', '-m', 'playwright', 'install-deps', 'chromium'],
            kissProjectPath,
          );
        }
      })
      .catch(err => {
        log(
          `Fast-path Playwright install failed: ${err instanceof Error ? err.message : err}`,
        );
        // Only warn the user if Chromium is genuinely missing.  Playwright
        // browsers are cached system-wide (outside .venv), so a transient
        // background update failure is benign when chromium is already cached.
        if (!isChromiumInstalled()) {
          vscode.window.showWarningMessage(
            'KISS Sorcar: Chromium browser update failed in background. See ~/.kiss/install.log for details.',
          );
        }
      });
    // Ensure git, Node.js, and VS Code CLI are available even on fast path
    if (!gitWorks()) {
      void installGit().then(installed => {
        if (!installed) {
          vscode.window.showWarningMessage(
            `KISS Sorcar: git is not available. ${gitInstallHint()}`,
          );
        }
      });
    }
    if (!commandExists('node')) {
      void installNode().then(installed => {
        if (!installed) {
          vscode.window.showWarningMessage(
            'KISS Sorcar: Node.js could not be installed automatically. Some agent tools may be unavailable.',
          );
        }
      });
    }
    if (!commandExists('code')) {
      void installCodeCli();
    }
    // Fast-path finalization: when we did not enter the slow-path
    // withProgress block we still need to run the finalization
    // steps.  The fast path does NOT show a progress notification
    // (because there was no "installing" notification to keep
    // visible to begin with), so the user-visible UX gap that
    // motivated wrapping finalization in withProgress does not
    // apply here.
    apiKeysReady = await runFinalization(null, kissProjectPath, uvPath);
  } else {
    // Slow path: show progress bar and install missing deps
    const result = await vscode.window.withProgress(
      {
        location: vscode.ProgressLocation.Notification,
        title: 'KISS Sorcar: Setting up',
        cancellable: false,
      },
      async progress => {
        // 1. Install uv if needed
        if (!uvPath) {
          // curl and tar are required to download and extract uv
          if (process.platform !== 'win32') {
            for (const bin of ['curl', 'tar']) {
              if (!commandExists(bin)) {
                vscode.window.showErrorMessage(
                  `KISS Sorcar: '${bin}' is required to install uv but was not found. Please install '${bin}' and restart VS Code.`,
                );
                return {success: false, apiKeysReady: false};
              }
            }
          }
          progress.report({
            message: 'Installing uv package manager...',
            increment: 0,
          });
          uvPath = await installUv();
          if (!uvPath) {
            vscode.window.showErrorMessage(
              'KISS Sorcar: Failed to install uv. Install manually: curl -LsSf https://astral.sh/uv/install.sh | sh',
            );
            return {success: false, apiKeysReady: false};
          }
          progress.report({increment: 20});
        }

        // 2. Install git if needed
        if (!gitWorks()) {
          progress.report({message: 'Installing git...'});
          const gitInstalled = await installGit();
          if (!gitInstalled) {
            vscode.window.showWarningMessage(
              `KISS Sorcar: git could not be installed automatically. ${gitInstallHint()}`,
            );
          }
        }

        // 3. Install Node.js if needed (provides node, npm, npx for agent tasks)
        if (!commandExists('node')) {
          progress.report({message: 'Installing Node.js...'});
          const nodeInstalled = await installNode();
          if (!nodeInstalled) {
            log('Node.js could not be installed automatically');
            vscode.window.showWarningMessage(
              'KISS Sorcar: Node.js could not be installed automatically. ' +
                'Some agent tools may be unavailable. Install from https://nodejs.org',
            );
          }
        }

        // 4. Ensure VS Code CLI is on PATH
        if (!commandExists('code')) {
          progress.report({message: 'Setting up VS Code CLI...'});
          const codeInstalled = await installCodeCli();
          if (!codeInstalled) {
            log('VS Code CLI could not be set up on PATH');
          }
        }

        // 5. Set up Python environment (installs Python 3.13+ and all pip dependencies)
        if (!venvExists) {
          progress.report({
            message:
              'Setting up Python environment (first time, may take a minute)...',
          });
          await runAsync(uvPath, ['sync'], kissProjectPath);
          progress.report({increment: 50});
        }

        // 6. Verify Python version meets minimum requirement
        if (checkPythonVersion(uvPath, kissProjectPath) !== 'ok') {
          vscode.window.showErrorMessage(
            `KISS Sorcar requires Python ${MIN_PYTHON_MAJOR}.${MIN_PYTHON_MINOR}+. ` +
              `Please install Python ${MIN_PYTHON_MAJOR}.${MIN_PYTHON_MINOR} or later and restart VS Code.`,
          );
          return {success: false, apiKeysReady: false};
        }

        // 7. Install Playwright Chromium
        progress.report({message: 'Installing dependencies...'});
        await runAsync(
          uvPath,
          ['run', 'python', '-m', 'playwright', 'install', 'chromium'],
          kissProjectPath,
        );
        if (process.platform === 'linux') {
          await runAsync(
            uvPath,
            ['run', 'python', '-m', 'playwright', 'install-deps', 'chromium'],
            kissProjectPath,
          ).catch(err =>
            log(
              `Playwright deps install failed (may need sudo): ${err instanceof Error ? err.message : err}`,
            ),
          );
        }
        progress.report({increment: 30});

        // Finalization runs INSIDE the withProgress callback so the
        // "KISS Sorcar: Setting up" notification stays visible
        // continuously from the first install step until the
        // "Restart VS Code" prompt is shown.  Previously these steps
        // ran after the callback returned, leaving a visible gap
        // between "Installing dependencies..." and "Restart VS Code"
        // (often several seconds — much longer when ensureApiKeys
        // had to prompt the user for an API key).
        progress.report({message: 'Finalizing setup...'});
        const finalizedKeys = await runFinalization(
          progress,
          kissProjectPath,
          uvPath,
        );
        return {success: true, apiKeysReady: finalizedKeys};
      },
    );

    showRestartNotification = showRestartNotification || !!result.success;
    apiKeysReady = result.apiKeysReady;
  }

  log('=== Dependency check finished ===');

  // Show restart notification only after API key prompting has completed.
  if (showRestartNotification) {
    if (apiKeysReady) {
      // Loop until the user explicitly clicks "Restart VS Code".  VS
      // Code may auto-hide information notifications (depending on
      // user settings or notification-center state) and the user may
      // dismiss the toast with the close button — in either case
      // ``showInformationMessage`` resolves to ``undefined`` and we
      // re-show, guaranteeing the prompt stays visible until the
      // restart button is clicked.
      void (async () => {
        for (;;) {
          const choice = await vscode.window.showInformationMessage(
            'KISS Sorcar: Installation complete! Please restart VS Code and any open terminal for changes to take effect.',
            'Restart VS Code',
          );
          if (choice === 'Restart VS Code') {
            vscode.commands.executeCommand('workbench.action.reloadWindow');
            return;
          }
        }
      })();
    } else {
      vscode.window.showWarningMessage(
        'KISS Sorcar: Installation complete, but at least one of Claude Code, ANTHROPIC_API_KEY, or OPENAI_API_KEY is required. ' +
          'Set an API key in your environment or restart VS Code to be prompted again.',
      );
    }
  }
}

/**
 * Restart the kiss-web remote access daemon.
 *
 * Always restarts the daemon so that code changes from an editable install
 * are picked up (the Python code is loaded at process start time).  Kills
 * any existing kiss-web and cloudflared processes, waits for port 8787 to
 * be free, then (re-)creates the service definition and starts it.
 *
 * On macOS uses ``~/Library/LaunchAgents/com.kiss.web-server.plist``
 * with ``KeepAlive`` and ``RunAtLoad``.
 * On Linux uses ``~/.config/systemd/user/kiss-web.service`` with
 * ``Restart=always`` and enables lingering.
 *
 * @param kissProjectPath - Absolute path to the KISS project directory.
 */
function restartKissWebDaemon(kissProjectPath: string): void {
  if (process.platform === 'win32') return; // Not supported on Windows

  const kissWebBin = path.join(kissProjectPath, '.venv', 'bin', 'kiss-web');
  if (!fs.existsSync(kissWebBin)) {
    log(`kiss-web binary not found at ${kissWebBin} — skipping daemon setup`);
    return;
  }

  const binDir = path.join(HOME_DIR, '.local', 'bin');

  // Skip the kill+restart when the kiss-web binary and the editable
  // kiss source tree are byte-for-byte identical to the last time the
  // daemon was started AND the daemon is currently healthy on port
  // 8787.  This preserves any running ``cloudflared`` quick-tunnel
  // across VS Code window reloads / re-activations, which would
  // otherwise mint a brand-new random ``*.trycloudflare.com`` URL
  // every time the extension activates.
  //
  // The fingerprint changes whenever the user rebuilds, reinstalls,
  // or edits any Python source under ``src/kiss/`` — so the
  // editable-install code-pickup behavior is preserved on real
  // changes.
  const fpFile = path.join(LOG_DIR, '.kiss-web.fingerprint');
  const currentFp = computeKissWebFingerprint(kissProjectPath, kissWebBin);
  let savedFp = '';
  try {
    savedFp = fs.readFileSync(fpFile, 'utf-8').trim();
  } catch {
    /* missing or unreadable — treat as mismatch */
  }
  const daemonAlive = (() => {
    try {
      execSync('lsof -i :8787 -t', {stdio: 'ignore', timeout: 2000});
      return true;
    } catch {
      return false;
    }
  })();
  if (currentFp && currentFp === savedFp && daemonAlive) {
    log(
      `kiss-web fingerprint unchanged (${currentFp.slice(0, 8)}) and ` +
        'daemon healthy on :8787 — skipping restart to preserve tunnel URL',
    );
    return;
  }
  log(
    `kiss-web restart: fingerprint ${savedFp.slice(0, 8) || '<none>'} → ` +
      `${currentFp.slice(0, 8) || '<none>'}, daemonAlive=${daemonAlive}`,
  );

  // Kill the existing kiss-web process before restarting.  Use
  // ``pkill -x`` (exact comm match) and pass the name as a separate
  // argv element via ``execFileSync`` so the shell never interpolates
  // the value.  We deliberately avoid the substring-match flag, which
  // would otherwise kill unrelated processes (e.g. a user editing
  // kiss-web.py in another VS Code window).
  //
  // ``cloudflared`` is intentionally NOT killed here: the Python
  // ``web_server`` adopts the existing cloudflared on startup
  // (matching pid in ``~/.kiss/cloudflared.pid`` and a healthy
  // metrics endpoint), keeping the same public URL across kiss-web
  // restarts.  When the kiss-web binary genuinely changed we still
  // restart kiss-web; the surviving cloudflared keeps forwarding to
  // ``https://localhost:8787``, which the new kiss-web re-binds.
  try {
    execFileSync('pkill', ['-x', 'kiss-web'], {
      stdio: 'ignore',
      timeout: 5000,
    });
  } catch {
    /* no matching process — ok */
  }

  // Wait for port 8787 to be free (up to 5 seconds)
  for (let i = 0; i < 10; i++) {
    try {
      execSync('lsof -i :8787 -t', {stdio: 'ignore', timeout: 2000});
      // Port still in use — wait
      execSync('sleep 0.5', {timeout: 2000});
    } catch {
      // Port is free
      break;
    }
  }

  if (process.platform === 'darwin') {
    const plistLabel = 'com.kiss.web-server';
    const plistDir = path.join(HOME_DIR, 'Library', 'LaunchAgents');
    const plistFile = path.join(plistDir, `${plistLabel}.plist`);

    log('Restarting kiss-web macOS LaunchAgent...');
    try {
      fs.mkdirSync(plistDir, {recursive: true});
      // XML-escape every interpolated path so that paths containing
      // ``&``, ``<``, ``>``, ``"`` or ``'`` cannot corrupt the plist
      // structure or inject alternate ProgramArguments via XML entities.
      const xLabel = xmlEscape(plistLabel);
      const xBin = xmlEscape(kissWebBin);
      const xProj = xmlEscape(kissProjectPath);
      const xLogDir = xmlEscape(LOG_DIR);
      const xPath = xmlEscape(
        `/opt/homebrew/bin:${binDir}:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin`,
      );
      const plistContent = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>${xLabel}</string>
    <key>ProgramArguments</key>
    <array>
        <string>${xBin}</string>
    </array>
    <key>WorkingDirectory</key>
    <string>${xProj}</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>${xLogDir}/kiss-web-stdout.log</string>
    <key>StandardErrorPath</key>
    <string>${xLogDir}/kiss-web-stderr.log</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>${xPath}</string>
    </dict>
</dict>
</plist>`;

      fs.writeFileSync(plistFile, plistContent);

      // Unload existing service if present, then bootstrap the new one.
      // H1 — pass paths as separate argv entries via execFileSync so a
      // plistFile path containing single/double quotes or shell
      // metacharacters (HOME_DIR is user-controlled) cannot inject
      // arbitrary shell commands.
      const uid = execFileSync('id', ['-u'], {encoding: 'utf-8'}).trim();
      try {
        execFileSync('launchctl', ['bootout', `gui/${uid}/${plistLabel}`], {
          stdio: 'ignore',
          timeout: 5000,
        });
      } catch {
        /* not loaded — ok */
      }
      try {
        execFileSync('launchctl', ['bootstrap', `gui/${uid}`, plistFile], {
          stdio: 'ignore',
          timeout: 5000,
        });
      } catch {
        // Fall back to older load command — same argv-form to avoid
        // shell interpolation of plistFile.
        execFileSync('launchctl', ['load', '-w', plistFile], {
          stdio: 'ignore',
          timeout: 5000,
        });
      }
      log(`kiss-web macOS LaunchAgent restarted: ${plistFile}`);
    } catch (err) {
      log(
        `Failed to restart kiss-web daemon (macOS): ${err instanceof Error ? err.message : err}`,
      );
    }
  } else if (process.platform === 'linux') {
    const systemdDir = path.join(HOME_DIR, '.config', 'systemd', 'user');
    const serviceFile = path.join(systemdDir, 'kiss-web.service');

    log('Restarting kiss-web systemd user service...');
    try {
      fs.mkdirSync(systemdDir, {recursive: true});
      // unit-escape every interpolated path so that backslashes / newlines
      // / percent signs in user paths cannot corrupt the unit.
      const uBin = unitEscape(kissWebBin);
      const uProj = unitEscape(kissProjectPath);
      const uPath = unitEscape(`${binDir}:/usr/local/bin:/usr/bin:/bin`);
      const uLogDir = unitEscape(LOG_DIR);
      const serviceContent = `[Unit]
Description=KISS Sorcar Remote Web Server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${uBin}
WorkingDirectory=${uProj}
Restart=always
RestartSec=5
Environment=PATH=${uPath}
StandardOutput=append:${uLogDir}/kiss-web-stdout.log
StandardError=append:${uLogDir}/kiss-web-stderr.log

[Install]
WantedBy=default.target
`;
      fs.writeFileSync(serviceFile, serviceContent);
      execSync('systemctl --user daemon-reload', {
        stdio: 'ignore',
        timeout: 10000,
      });
      execSync('systemctl --user restart kiss-web', {
        stdio: 'ignore',
        timeout: 10000,
      });
      // Enable lingering so service runs without active login session
      const username = os.userInfo().username;
      try {
        // H1 — argv-form so a username with shell metacharacters cannot
        // inject commands.
        execFileSync('loginctl', ['enable-linger', username], {
          stdio: 'ignore',
          timeout: 5000,
        });
      } catch {
        /* may require elevated privileges — non-fatal */
      }
      log(`kiss-web systemd user service restarted: ${serviceFile}`);
    } catch (err) {
      log(
        `Failed to restart kiss-web daemon (Linux): ${err instanceof Error ? err.message : err}`,
      );
    }
  }

  // Record the fingerprint so the next activation can skip the
  // restart when nothing has changed.  Best-effort: a write failure
  // simply forces an unconditional restart next time, which is safe.
  try {
    fs.writeFileSync(fpFile, currentFp + '\n');
  } catch (err) {
    log(
      `Failed to write kiss-web fingerprint: ${err instanceof Error ? err.message : err}`,
    );
  }
}

/**
 * Compute a fingerprint of the installed kiss-web binary and the
 * editable kiss source tree.
 *
 * The fingerprint is the SHA-256 of:
 *   - the bytes of the ``kiss-web`` entrypoint script, and
 *   - the latest mtime (in nanoseconds) across all ``*.py`` files
 *     under ``${kissProjectPath}/src/kiss/``, excluding ``__pycache__``
 *     and ``tests/`` directories.
 *
 * This changes whenever the user rebuilds kiss-web, reinstalls the
 * package, or edits any source file picked up by the editable install
 * — exactly the situations where the daemon needs to restart to pick
 * up new code.  Returns ``""`` if the fingerprint cannot be computed
 * (caller treats this as a mismatch and restarts unconditionally).
 */
function computeKissWebFingerprint(
  kissProjectPath: string,
  kissWebBin: string,
): string {
  try {
    const hash = crypto.createHash('sha256');
    hash.update(fs.readFileSync(kissWebBin));
    const srcDir = path.join(kissProjectPath, 'src', 'kiss');
    let latestMtimeNs = BigInt(0);
    const walk = (dir: string): void => {
      let entries: fs.Dirent[];
      try {
        entries = fs.readdirSync(dir, {withFileTypes: true});
      } catch {
        return;
      }
      for (const entry of entries) {
        if (entry.name === '__pycache__' || entry.name === 'tests') continue;
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          walk(full);
        } else if (entry.isFile() && entry.name.endsWith('.py')) {
          try {
            const st = fs.statSync(full, {bigint: true});
            if (st.mtimeNs > latestMtimeNs) latestMtimeNs = st.mtimeNs;
          } catch {
            /* skip unreadable file */
          }
        }
      }
    };
    walk(srcDir);
    hash.update(latestMtimeNs.toString());
    return hash.digest('hex');
  } catch (err) {
    log(
      `computeKissWebFingerprint failed: ${err instanceof Error ? err.message : err}`,
    );
    return '';
  }
}

/**
 * Install a `sorcar` CLI wrapper script in ~/.local/bin/ so users can
 * invoke the agent from any terminal after the extension is installed.
 * The wrapper calls `uv run sorcar` from the bundled kiss_project directory.
 */
function installCliScript(kissProjectPath: string, uvPath: string): void {
  if (!HOME_DIR) return;

  const binDir = path.join(HOME_DIR, '.local', 'bin');

  // Resolve uv to an absolute path for the wrapper script
  let absUvPath = uvPath;
  if (uvPath === 'uv' || !path.isAbsolute(uvPath)) {
    try {
      const whichCmd =
        process.platform === 'win32' ? `where ${uvPath}` : `which ${uvPath}`;
      absUvPath = execSync(whichCmd, {encoding: 'utf-8'}).trim().split('\n')[0];
    } catch {
      const suffix = process.platform === 'win32' ? '.exe' : '';
      absUvPath = path.join(HOME_DIR, '.local', 'bin', `uv${suffix}`);
    }
  }

  try {
    fs.mkdirSync(binDir, {recursive: true});

    if (process.platform === 'win32') {
      const cmdPath = path.join(binDir, 'sorcar.cmd');
      const script =
        '@echo off\r\n' +
        'REM Installed by KISS Sorcar VS Code extension\r\n' +
        `"${absUvPath}" run --directory "${kissProjectPath}" sorcar %*\r\n`;
      fs.writeFileSync(cmdPath, script);
    } else {
      const scriptPath = path.join(binDir, 'sorcar');
      const script =
        '#!/bin/bash\n' +
        '# Installed by KISS Sorcar VS Code extension\n' +
        `exec "${absUvPath}" run --directory "${kissProjectPath}" sorcar "$@"\n`;
      fs.writeFileSync(scriptPath, script, {mode: 0o755});
    }
  } catch (err) {
    log(
      `Failed to install CLI script: ${err instanceof Error ? err.message : err}`,
    );
  }
}

/**
 * Map Node.js platform/arch to the uv GitHub release asset triplet.
 * Returns [archName, platformSuffix, extension] or null if unsupported.
 */
function uvAssetInfo(): {
  archName: string;
  triplet: string;
  ext: string;
} | null {
  const archMap: Record<string, string> = {
    arm64: 'aarch64',
    x64: 'x86_64',
  };
  const arch = archMap[process.arch];
  if (!arch) return null;

  if (process.platform === 'darwin') {
    return {archName: arch, triplet: `${arch}-apple-darwin`, ext: 'tar.gz'};
  } else if (process.platform === 'linux') {
    return {
      archName: arch,
      triplet: `${arch}-unknown-linux-gnu`,
      ext: 'tar.gz',
    };
  } else if (process.platform === 'win32') {
    return {archName: arch, triplet: `${arch}-pc-windows-msvc`, ext: 'zip'};
  }
  return null;
}

/**
 * Install uv from a pinned GitHub binary release and return its path, or null on failure.
 * Downloads the platform-specific binary from releases.astral.sh and extracts to ~/.local/bin/.
 */
async function installUv(): Promise<string | null> {
  const asset = uvAssetInfo();
  if (!asset) {
    log(
      `Unsupported platform/arch for uv: ${process.platform}/${process.arch}`,
    );
    return null;
  }

  const installDir = path.join(HOME_DIR, '.local', 'bin');
  const assetName = `uv-${asset.triplet}`;
  const url = `https://releases.astral.sh/github/uv/releases/download/${UV_VERSION}/${assetName}.${asset.ext}`;
  log(`Downloading uv ${UV_VERSION} from ${url}`);

  try {
    // Ensure install directory exists
    fs.mkdirSync(installDir, {recursive: true});

    if (process.platform === 'win32') {
      // Windows: download zip and extract with PowerShell
      const zipPath = path.join(installDir, `${assetName}.zip`);
      await execPromise(
        `powershell -Command "Invoke-WebRequest -Uri '${url}' -OutFile '${zipPath}'; ` +
          `Expand-Archive -Force -Path '${zipPath}' -DestinationPath '${installDir}'; ` +
          `Move-Item -Force '${path.join(installDir, assetName, 'uv.exe')}' '${path.join(installDir, 'uv.exe')}'; ` +
          `Move-Item -Force '${path.join(installDir, assetName, 'uvx.exe')}' '${path.join(installDir, 'uvx.exe')}'; ` +
          `Remove-Item -Force '${zipPath}'; Remove-Item -Recurse -Force '${path.join(installDir, assetName)}'"`,
      );
    } else {
      // macOS/Linux: download tar.gz and extract with tar (no shell so
      // that ``HOME`` containing single-quotes can never inject shell
      // commands).  Verify SHA256 against the vendor sidecar before
      // extracting so a corrupted/MITM'd download is rejected.
      const tarPath = path.join(installDir, `${assetName}.${asset.ext}`);
      await downloadFile(url, tarPath);
      const expectedHash = await fetchUvStyleSha256(url);
      await verifyDownloadHash(tarPath, expectedHash);
      // Extract with argv-form spawn — no shell.
      await spawnPromise('tar', ['xzf', tarPath, '-C', installDir]);
      // Move uv / uvx into installDir, then remove the extracted folder.
      const extractedDir = path.join(installDir, assetName);
      for (const bin of ['uv', 'uvx']) {
        const src = path.join(extractedDir, bin);
        const dst = path.join(installDir, bin);
        try {
          fs.unlinkSync(dst);
        } catch {
          /* not present */
        }
        fs.renameSync(src, dst);
        fs.chmodSync(dst, 0o755);
      }
      try {
        fs.rmSync(extractedDir, {recursive: true, force: true});
      } catch {
        /* ignore */
      }
      try {
        fs.unlinkSync(tarPath);
      } catch {
        /* ignore */
      }
    }

    log('uv installed successfully');
    return findUvPath();
  } catch (err) {
    log(`Failed to install uv: ${err instanceof Error ? err.message : err}`);
    return null;
  }
}

/**
 * Check that the Python version in the project's .venv is >= MIN_PYTHON.
 * Runs `uv run python --version` and parses the output (e.g. "Python 3.13.2").
 *
 * Returns ``'ok'`` when the version meets the requirement, ``'too_old'``
 * when a valid version was parsed but is below the minimum, and ``'error'``
 * when the check itself failed (timeout, spawn error, etc.).  Callers
 * should only delete `.venv` on ``'too_old'`` — transient errors must not
 * destroy a potentially valid environment.
 */
function checkPythonVersion(
  uvPath: string,
  cwd: string,
): 'ok' | 'too_old' | 'error' {
  try {
    // H1 — argv-form so a uvPath containing quotes or shell
    // metacharacters cannot inject commands.
    const output = execFileSync(uvPath, ['run', 'python', '--version'], {
      cwd,
      encoding: 'utf-8',
      timeout: 30_000,
    }).trim();
    // Output format: "Python 3.13.2"
    const match = output.match(/Python\s+(\d+)\.(\d+)/);
    if (!match) return 'error';
    const major = parseInt(match[1], 10);
    const minor = parseInt(match[2], 10);
    if (
      major > MIN_PYTHON_MAJOR ||
      (major === MIN_PYTHON_MAJOR && minor >= MIN_PYTHON_MINOR)
    ) {
      return 'ok';
    }
    return 'too_old';
  } catch {
    return 'error';
  }
}

/**
 * Return the Playwright browsers cache directory for the current platform.
 */
function playwrightBrowsersPath(): string {
  const env = process.env.PLAYWRIGHT_BROWSERS_PATH;
  if (env) return env;
  if (process.platform === 'darwin') {
    return path.join(HOME_DIR, 'Library', 'Caches', 'ms-playwright');
  } else if (process.platform === 'win32') {
    return path.join(
      process.env.LOCALAPPDATA || path.join(HOME_DIR, 'AppData', 'Local'),
      'ms-playwright',
    );
  }
  return path.join(HOME_DIR, '.cache', 'ms-playwright');
}

/**
 * Check if the kiss-web daemon is running by probing port 8787.
 * Returns true if port 8787 has a listener (macOS/Linux only).
 * On Windows the daemon is not supported, so always returns false.
 *
 * The probe is retried up to 3 times with 300 ms gaps before
 * returning false.  A single ``lsof`` call races with the
 * LaunchAgent's ~1-3 s respawn window after a previous kiss-web
 * restart; without the retry the extension would nuke a healthy
 * daemon that was merely mid-startup, burning the current Cloudflare
 * tunnel URL on every VS Code activation that lost that race.
 */
function isDaemonRunning(): boolean {
  if (process.platform === 'win32') return false;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      execSync('lsof -i :8787 -t', {stdio: 'ignore', timeout: 3000});
      return true;
    } catch {
      // not listening yet; fall through to retry
    }
    if (attempt < 2) {
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 300);
    }
  }
  return false;
}

/**
 * Check if Playwright Chromium is already installed in the browser cache.
 * Returns true if any chromium-* directory exists in the cache.
 */
function isChromiumInstalled(): boolean {
  try {
    const cacheDir = playwrightBrowsersPath();
    if (!fs.existsSync(cacheDir)) return false;
    return fs.readdirSync(cacheDir).some(e => e.startsWith('chromium-'));
  } catch {
    return false;
  }
}

/**
 * Check if a command is available on the system.
 */
function commandExists(cmd: string): boolean {
  try {
    // H1 — argv-form so a caller-supplied ``cmd`` containing shell
    // metacharacters cannot inject extra commands.
    execFileSync(process.platform === 'win32' ? 'where' : 'which', [cmd], {
      stdio: 'ignore',
    });
    return true;
  } catch {
    return false;
  }
}

/**
 * Check if git is functional (not just a macOS shim that triggers a CLT dialog).
 * Returns true only if `git --version` actually succeeds and outputs a version string.
 */
function gitWorks(): boolean {
  try {
    const output = execSync('git --version', {
      encoding: 'utf-8',
      timeout: 10_000,
      stdio: ['ignore', 'pipe', 'ignore'],
    });
    return output.includes('git version');
  } catch {
    return false;
  }
}

/**
 * Return a user-facing hint for how to install git manually on the current platform.
 */
function gitInstallHint(): string {
  if (process.platform === 'darwin') {
    return 'Run "xcode-select --install" in Terminal, or install Homebrew (https://brew.sh) and run "brew install git".';
  } else if (process.platform === 'linux') {
    return 'Run "sudo apt-get install git" (Debian/Ubuntu), "sudo dnf install git" (Fedora), or the equivalent for your distribution.';
  } else if (process.platform === 'win32') {
    return 'Download Git from https://git-scm.com/download/win';
  }
  return 'Download Git from https://git-scm.com';
}

/**
 * Attempt to install git from prebuilt binaries.
 * Returns true if git is available after the attempt.
 *
 * macOS: tries Homebrew (binary bottles), then triggers Xcode Command Line Tools.
 * Linux: tries common package managers with non-interactive sudo.
 * Windows: downloads MinGit portable from Git for Windows releases.
 */
async function installGit(): Promise<boolean> {
  log('Git not found, attempting to install...');

  if (process.platform === 'darwin') {
    // Try Homebrew first — downloads a prebuilt bottle, no user interaction needed
    if (commandExists('brew')) {
      log('Installing git via Homebrew...');
      try {
        await execPromise('brew install git');
        if (gitWorks()) {
          log('Git installed via Homebrew');
          return true;
        }
      } catch (err) {
        log(
          `Homebrew git install failed: ${err instanceof Error ? err.message : err}`,
        );
      }
    }

    // Fall back to Xcode Command Line Tools (installs Apple's prebuilt git binary)
    try {
      execSync('xcode-select -p', {stdio: 'ignore'});
      // CLT already installed but git not working — unusual, nothing more we can do
      log('Xcode CLT present but git not working');
      return false;
    } catch {
      // CLT not installed — trigger the system installer dialog
    }

    log('Triggering Xcode Command Line Tools installation...');
    try {
      execSync('xcode-select --install', {stdio: 'ignore', timeout: 5_000});
    } catch {
      // Expected: opens a system dialog and may exit non-zero
    }

    // Poll for git to become available while the user completes the CLT dialog
    for (let i = 0; i < 120; i++) {
      // up to 10 minutes
      await new Promise(resolve => setTimeout(resolve, 5_000));
      if (gitWorks()) {
        log('Git installed via Xcode Command Line Tools');
        return true;
      }
    }
    return false;
  } else if (process.platform === 'linux') {
    // Try common package managers with non-interactive sudo (-n)
    const attempts: [string, string][] = [
      [
        'apt-get',
        'sudo -n sh -c "apt-get update -y && apt-get install -y git"',
      ],
      ['dnf', 'sudo -n dnf install -y git'],
      ['yum', 'sudo -n yum install -y git'],
      ['pacman', 'sudo -n pacman -S --noconfirm git'],
      ['apk', 'sudo -n apk add git'],
    ];
    for (const [bin, cmd] of attempts) {
      if (commandExists(bin)) {
        log(`Installing git via ${bin}...`);
        try {
          await execPromise(cmd);
          if (gitWorks()) {
            log(`Git installed via ${bin}`);
            return true;
          }
        } catch (err) {
          log(`Failed via ${bin}: ${err instanceof Error ? err.message : err}`);
        }
      }
    }
    return false;
  } else if (process.platform === 'win32') {
    return installMinGitWindows();
  }

  return false;
}

/**
 * Download MinGit (portable git for Windows) from Git for Windows releases
 * and extract it to ~/.local/git/. Adds the git cmd directory to PATH.
 */
async function installMinGitWindows(): Promise<boolean> {
  const GIT_VERSION = '2.49.0';
  const archSuffix = process.arch === 'arm64' ? 'arm64' : '64';
  const assetName = `MinGit-${GIT_VERSION}-${archSuffix}-bit`;
  const url = `https://github.com/git-for-windows/git/releases/download/v${GIT_VERSION}.windows.1/${assetName}.zip`;
  const gitDir = path.join(HOME_DIR, '.local', 'git');

  log(`Downloading MinGit from ${url}`);

  try {
    fs.mkdirSync(gitDir, {recursive: true});

    const zipPath = path.join(gitDir, `${assetName}.zip`);
    await execPromise(
      'powershell -Command "' +
        `Invoke-WebRequest -Uri '${url}' -OutFile '${zipPath}'; ` +
        `Expand-Archive -Force -Path '${zipPath}' -DestinationPath '${gitDir}'; ` +
        `Remove-Item -Force '${zipPath}'"`,
    );

    // Add MinGit's cmd directory to PATH so git.exe is found
    const gitCmdDir = path.join(gitDir, 'cmd');
    if (fs.existsSync(path.join(gitCmdDir, 'git.exe'))) {
      const parts = (process.env.PATH || '').split(path.delimiter);
      if (!parts.includes(gitCmdDir)) {
        process.env.PATH = `${gitCmdDir}${path.delimiter}${process.env.PATH || ''}`;
      }
      log('MinGit installed successfully');
      return true;
    }
    log('MinGit extracted but git.exe not found in cmd/');
  } catch (err) {
    log(
      `MinGit installation failed: ${err instanceof Error ? err.message : err}`,
    );
  }
  return false;
}

/**
 * Install Node.js from the official binary tarball and return true on success.
 * Downloads a platform-specific archive and extracts to ~/.local/ so that
 * node, npm, and npx are available on PATH via ~/.local/bin/.
 */
async function installNode(): Promise<boolean> {
  const archMap: Record<string, string> = {arm64: 'arm64', x64: 'x64'};
  const arch = archMap[process.arch];
  if (!arch) {
    log(`Unsupported architecture for Node.js: ${process.arch}`);
    return false;
  }

  if (process.platform === 'win32') {
    const assetName = `node-${NODE_VERSION}-win-${arch}`;
    const url = `https://nodejs.org/dist/${NODE_VERSION}/${assetName}.zip`;
    const installDir = path.join(HOME_DIR, '.local', 'node');
    log(`Downloading Node.js from ${url}`);
    try {
      fs.mkdirSync(installDir, {recursive: true});
      const zipPath = path.join(installDir, `${assetName}.zip`);
      await execPromise(
        'powershell -Command "' +
          `Invoke-WebRequest -Uri '${url}' -OutFile '${zipPath}'; ` +
          `Expand-Archive -Force -Path '${zipPath}' -DestinationPath '${installDir}'; ` +
          `Remove-Item -Force '${zipPath}'"`,
      );
      // Add node directory to PATH
      const nodeDir = path.join(installDir, assetName);
      if (fs.existsSync(path.join(nodeDir, 'node.exe'))) {
        const parts = (process.env.PATH || '').split(path.delimiter);
        if (!parts.includes(nodeDir)) {
          process.env.PATH = `${nodeDir}${path.delimiter}${process.env.PATH || ''}`;
        }
        log('Node.js installed successfully (Windows)');
        return true;
      }
    } catch (err) {
      log(
        `Node.js installation failed: ${err instanceof Error ? err.message : err}`,
      );
    }
    return false;
  }

  // macOS / Linux: download tar.gz and extract to ~/.local/
  const osName = process.platform === 'darwin' ? 'darwin' : 'linux';
  const assetName = `node-${NODE_VERSION}-${osName}-${arch}`;
  const url = `https://nodejs.org/dist/${NODE_VERSION}/${assetName}.tar.gz`;
  log(`Downloading Node.js from ${url}`);

  try {
    const installDir = path.join(HOME_DIR, '.local');
    fs.mkdirSync(installDir, {recursive: true});
    // Download with the Node ``https`` module (no shell), verify the
    // SHA256 against ``SHASUMS256.txt`` from nodejs.org, and extract
    // with argv-form ``tar`` (no shell).
    const tarPath = path.join(installDir, `${assetName}.tar.gz`);
    await downloadFile(url, tarPath);
    const expectedHash = await fetchNodeSha256(`${assetName}.tar.gz`);
    await verifyDownloadHash(tarPath, expectedHash);
    await spawnPromise('tar', [
      'xzf',
      tarPath,
      '-C',
      installDir,
      '--strip-components=1',
    ]);
    try {
      fs.unlinkSync(tarPath);
    } catch {
      /* ignore */
    }
    log('Node.js installed successfully');
    return commandExists('node');
  } catch (err) {
    log(
      `Node.js installation failed: ${err instanceof Error ? err.message : err}`,
    );
    return false;
  }
}

/**
 * Ensure the VS Code CLI (`code`) is available on PATH.
 * On macOS, symlinks from the app bundle to ~/.local/bin/code.
 * On Linux, attempts snap or apt installation.
 * On Windows, VS Code's installer normally adds `code` to PATH.
 * Returns true if `code` is available after the attempt.
 */
async function installCodeCli(): Promise<boolean> {
  if (commandExists('code')) return true;

  if (process.platform === 'darwin') {
    const vscodeApp =
      '/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code';
    if (fs.existsSync(vscodeApp)) {
      const binDir = path.join(HOME_DIR, '.local', 'bin');
      try {
        fs.mkdirSync(binDir, {recursive: true});
        const linkPath = path.join(binDir, 'code');
        try {
          fs.unlinkSync(linkPath);
        } catch {
          /* doesn't exist */
        }
        fs.symlinkSync(vscodeApp, linkPath);
        log('VS Code CLI symlinked to ~/.local/bin/code');
        return true;
      } catch (err) {
        log(
          `Failed to symlink VS Code CLI: ${err instanceof Error ? err.message : err}`,
        );
      }
    }
  } else if (process.platform === 'linux') {
    // Try snap first, then apt with Microsoft repo
    if (commandExists('snap')) {
      try {
        await execPromise('sudo -n snap install --classic code');
        if (commandExists('code')) {
          log('VS Code CLI installed via snap');
          return true;
        }
      } catch (err) {
        log(`snap install failed: ${err instanceof Error ? err.message : err}`);
      }
    }
    if (commandExists('apt-get')) {
      try {
        await execPromise(
          'curl -fsSL https://packages.microsoft.com/keys/microsoft.asc | sudo -n gpg --dearmor -o /usr/share/keyrings/microsoft.gpg && ' +
            'echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/microsoft.gpg] https://packages.microsoft.com/repos/code stable main" | ' +
            'sudo -n tee /etc/apt/sources.list.d/vscode.list >/dev/null && ' +
            'sudo -n apt-get update -y && sudo -n apt-get install -y code',
        );
        if (commandExists('code')) {
          log('VS Code CLI installed via apt');
          return true;
        }
      } catch (err) {
        log(`apt install failed: ${err instanceof Error ? err.message : err}`);
      }
    }
  }
  // Windows: VS Code installer normally adds `code` to PATH; nothing to do.
  return commandExists('code');
}

/**
 * Run a command with args and return a promise that resolves on exit code 0.
 */
function runAsync(cmd: string, args: string[], cwd: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const cmdLine = `${cmd} ${args.join(' ')}`;
    log(`Running: ${cmdLine}`);
    const proc = spawn(cmd, args, {
      cwd,
      stdio: 'pipe',
      env: {...process.env, PYTHONUNBUFFERED: '1'},
    });
    let output = '';
    proc.stdout?.on('data', (d: Buffer) => {
      output += d.toString();
    });
    proc.stderr?.on('data', (d: Buffer) => {
      output += d.toString();
    });
    proc.on('close', code => {
      if (output.trim()) log(`Output [${cmdLine}]:\n${output.trim()}`);
      if (code === 0) {
        log(`Completed: ${cmdLine}`);
        resolve();
      } else {
        reject(new Error(`${cmdLine} failed (exit code ${code}): ${output}`));
      }
    });
    proc.on('error', err => {
      log(`Spawn error [${cmdLine}]: ${err.message}`);
      reject(err);
    });
  });
}

/**
 * Execute a shell command and return stdout.
 */
function execPromise(cmd: string): Promise<string> {
  return new Promise((resolve, reject) => {
    exec(cmd, {timeout: 300_000}, (err, stdout) => {
      if (err) reject(err);
      else resolve(stdout);
    });
  });
}

// ---------------------------------------------------------------------------
// API Key Setup
// ---------------------------------------------------------------------------

/**
 * Get the path to the user's shell rc file based on the SHELL environment variable.
 */
function getShellRcPath(): string {
  const homeDir = process.env.HOME || process.env.USERPROFILE || '';

  if (process.platform === 'win32') {
    // PowerShell profile
    const docsDir = path.join(homeDir, 'Documents', 'PowerShell');
    return path.join(docsDir, 'Microsoft.PowerShell_profile.ps1');
  }

  const shell = process.env.SHELL || '';
  if (shell.endsWith('/zsh') || shell.endsWith('/zsh-5')) {
    return path.join(homeDir, '.zshrc');
  } else if (shell.endsWith('/fish')) {
    return path.join(homeDir, '.config', 'fish', 'config.fish');
  } else {
    return path.join(homeDir, '.bashrc');
  }
}

/**
 * Validate an Anthropic API key by calling the /v1/models endpoint.
 * Returns true if the key is valid (HTTP 200), false otherwise.
 */
function validateAnthropicKey(key: string): Promise<boolean> {
  return new Promise(resolve => {
    const req = https.request(
      {
        hostname: 'api.anthropic.com',
        path: '/v1/models',
        method: 'GET',
        headers: {
          'x-api-key': key,
          'anthropic-version': '2023-06-01',
        },
        timeout: 15000,
      },
      res => {
        resolve(res.statusCode === 200);
        res.resume(); // consume response body
      },
    );
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
    req.end();
  });
}

/**
 * Read the content of a shell rc file, creating its parent directory if needed.
 * Returns an empty string if the file doesn't exist yet.
 */
function readShellRc(rcPath: string): string {
  try {
    return fs.readFileSync(rcPath, 'utf-8');
  } catch {
    fs.mkdirSync(path.dirname(rcPath), {recursive: true});
    return '';
  }
}

/**
 * Write content to a shell rc file, ensuring a trailing newline.
 */
function writeShellRc(rcPath: string, content: string): void {
  if (content.length > 0 && !content.endsWith('\n')) {
    content += '\n';
  }
  fs.writeFileSync(rcPath, content);
}

/**
 * Add an environment variable export line to a shell rc file.
 * If the variable already exists in the file, replaces it. Otherwise appends.
 */
function addToShellRc(rcPath: string, envName: string, value: string): void {
  const isPs1 = rcPath.endsWith('.ps1');
  const isFish = rcPath.endsWith('config.fish');
  const exportLine = isPs1
    ? `$env:${envName} = "${value}"`
    : isFish
      ? `set -gx ${envName} "${value}"`
      : `export ${envName}="${value}"`;

  let content = readShellRc(rcPath);

  // Check if an export for this variable already exists
  const linePattern = isPs1
    ? new RegExp(`^\\s*\\$env:${envName}\\s*=.*$`, 'gm')
    : isFish
      ? new RegExp(`^\\s*set\\s+-gx\\s+${envName}\\s.*$`, 'gm')
      : new RegExp(`^\\s*export\\s+${envName}=.*$`, 'gm');

  if (linePattern.test(content)) {
    linePattern.lastIndex = 0; // reset after test() so replace() starts from beginning
    content = content.replace(linePattern, exportLine);
  } else {
    if (content.length > 0 && !content.endsWith('\n')) {
      content += '\n';
    }
    content += exportLine + '\n';
  }

  writeShellRc(rcPath, content);
}

/**
 * Ensure a directory is on PATH in the user's shell rc file.
 * Adds an idempotent PATH export/prepend line if not already present.
 * Uses $HOME instead of a hardcoded path for portability.
 */
function ensurePathInShellRc(rcPath: string, dirPath: string): void {
  const isPs1 = rcPath.endsWith('.ps1');
  const isFish = rcPath.endsWith('config.fish');
  // Use $HOME-relative form for portability
  const homeDir = process.env.HOME || process.env.USERPROFILE || '';
  let dirRef = dirPath;
  if (homeDir && dirPath.startsWith(homeDir)) {
    dirRef = dirPath.replace(homeDir, '$HOME');
  }

  let content = readShellRc(rcPath);

  // Check if the directory is already referenced in a PATH line
  const escaped = dirRef
    .replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    .replace('\\$HOME', '(\\$HOME|~)');
  const alreadyPresent = isPs1
    ? new RegExp(`\\$env:PATH.*${escaped}`, 'm').test(content)
    : isFish
      ? new RegExp(`fish_add_path.*${escaped}`, 'm').test(content)
      : new RegExp(`PATH.*${escaped}`, 'm').test(content);

  if (alreadyPresent) return;

  const pathSep = isPs1 ? ';' : ':';
  const exportLine = isPs1
    ? `$env:PATH = "${dirRef};$env:PATH"`
    : isFish
      ? `fish_add_path "${dirRef}"`
      : `export PATH="${dirRef}${pathSep}$PATH"`;

  if (content.length > 0 && !content.endsWith('\n')) {
    content += '\n';
  }
  content += exportLine + '\n';

  writeShellRc(rcPath, content);
  log(`Added ${dirRef} to PATH in ${rcPath}`);
}

/**
 * Prompt the user for an API key. If a validate function is provided,
 * the key is validated and the user is re-prompted if invalid.
 * When optional is true, the prompt indicates the key can be skipped with Esc.
 * Returns the key string, or undefined if the user cancelled.
 */
async function promptForApiKey(
  displayName: string,
  placeholder: string,
  validate?: (key: string) => Promise<boolean>,
  optional?: boolean,
): Promise<string | undefined> {
  while (true) {
    const prompt = optional
      ? `${displayName} (optional — press Esc to skip):`
      : `${displayName} is not set. Please enter your key:`;
    const key = await vscode.window.showInputBox({
      title: displayName,
      prompt,
      placeHolder: placeholder,
      ignoreFocusOut: true,
    });

    if (key === undefined) {
      if (!optional) {
        const choice = await vscode.window.showWarningMessage(
          `${displayName} is required for KISS Sorcar to function.`,
          'Enter Key',
          'Skip',
        );
        if (choice === 'Enter Key') {
          continue;
        }
      }
      return undefined;
    }

    const trimmed = key.trim();
    if (!trimmed) {
      continue; // Empty input — re-prompt
    }

    if (validate) {
      const valid = await vscode.window.withProgress(
        {
          location: vscode.ProgressLocation.Notification,
          title: `Validating ${displayName}...`,
        },
        () => validate(trimmed),
      );

      if (!valid) {
        const choice = await vscode.window.showWarningMessage(
          `The ${displayName} is not valid. Please try again.`,
          'Try Again',
          'Cancel',
        );
        if (choice !== 'Try Again') {
          return undefined;
        }
        continue;
      }
    }

    return trimmed;
  }
}

/**
 * Load API keys from the user's shell rc file into process.env.
 * VS Code launched from macOS Dock/Spotlight does not source ~/.zshrc,
 * so API keys set there are invisible to process.env.  This function
 * reads the rc file and populates any missing env vars.
 */
function loadApiKeysFromShellRc(): void {
  const rcPath = getShellRcPath();
  const content = readShellRc(rcPath);
  if (!content) return;

  const isPs1 = rcPath.endsWith('.ps1');
  const isFish = rcPath.endsWith('config.fish');
  // Match uncommented export lines per shell syntax
  const pattern = isPs1
    ? /^\s*\$env:(\w+)\s*=\s*(.+)$/gm
    : isFish
      ? /^\s*set\s+-gx\s+(\w+)\s+(.+)$/gm
      : /^\s*export\s+(\w+)=(.+)$/gm;

  let match;
  while ((match = pattern.exec(content)) !== null) {
    const name = match[1];
    let value = match[2].trim();
    // Strip surrounding quotes
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (name && value && !process.env[name]) {
      process.env[name] = value;
    }
  }
}

/**
 * Ensure at least one LLM API key is configured.
 * Loads existing keys from the shell rc file (needed on macOS Dock launch),
 * then skips prompting if any key is already set.  Otherwise prompts the
 * user for each provider until at least one key is provided.
 * Validates the Anthropic key if the user enters one.
 * Saves provided keys to the user's shell rc file and current process env.
 *
 * Uses a marker file (~/.kiss/.api-keys-prompted) to suppress re-prompting
 * for additional keys on subsequent VS Code restarts once at least one key
 * has been collected.
 *
 * Returns true when at least one API key is available.
 */
async function ensureApiKeys(): Promise<boolean> {
  // Load keys from shell rc into process.env so that keys saved in
  // ~/.zshrc are picked up even when VS Code wasn't launched from a shell.
  loadApiKeysFromShellRc();

  const keys = [
    {
      envName: 'ANTHROPIC_API_KEY',
      displayName: 'Anthropic API Key',
      placeholder: 'sk-ant-...',
      validate: validateAnthropicKey,
    },
    {
      envName: 'OPENAI_API_KEY',
      displayName: 'OpenAI API Key',
      placeholder: 'sk-...',
    },
  ];

  const hasClaudeCli = commandExists('claude');
  const hasAnyKey = () =>
    hasClaudeCli || keys.some(k => !!process.env[k.envName]);

  // If claude CLI or at least one key is already set, no prompting needed
  if (hasAnyKey()) return true;

  const markerPath = path.join(LOG_DIR, '.api-keys-prompted');
  const alreadyPrompted = fs.existsSync(markerPath);
  const rcPath = getShellRcPath();

  // Prompt for keys until at least one is provided
  while (true) {
    for (const {envName, displayName, placeholder, validate} of keys) {
      if (process.env[envName]) continue;
      // Once we have at least one key and were already prompted, skip remaining
      if (hasAnyKey() && alreadyPrompted) break;

      const key = await promptForApiKey(
        displayName,
        placeholder,
        validate,
        true,
      );
      if (key) {
        process.env[envName] = key;
        addToShellRc(rcPath, envName, key);
        log(`${displayName} saved to ~/${path.basename(rcPath)}`);
      }
    }

    if (hasAnyKey()) break;

    // No key provided — warn and offer retry
    const choice = await vscode.window.showWarningMessage(
      'KISS Sorcar requires Claude Code, ANTHROPIC_API_KEY, or OPENAI_API_KEY to work.',
      'Enter Key',
      'Skip',
    );
    if (choice !== 'Enter Key') break;
  }

  // Write marker so additional keys aren't re-prompted on next restart
  if (!alreadyPrompted) {
    try {
      fs.mkdirSync(LOG_DIR, {recursive: true});
      fs.writeFileSync(markerPath, new Date().toISOString() + '\n');
      log('API key prompt marker written');
    } catch {
      /* ignore */
    }
  }

  return hasAnyKey();
}

/**
 * Read ``~/.kiss/config.json`` and return the parsed object, or an empty
 * object when the file is missing / unreadable.
 *
 * Retries up to ``RETRIES`` times with a small backoff to defend against
 * a concurrent writer (the Python ``save_config`` or ``install.sh``)
 * briefly truncating the file mid-write.  Only ``ENOENT`` (file does
 * not exist) short-circuits without retrying — every other failure
 * mode (empty file, ``SyntaxError`` from a half-written JSON document,
 * EBUSY, etc.) is treated as transient.
 */
function readKissConfigOnce():
  | {
      ok: true;
      value: Record<string, unknown>;
    }
  | {
      ok: false;
      reason: 'missing' | 'empty' | 'parse' | 'shape' | 'io';
      err?: unknown;
    } {
  const configPath = path.join(LOG_DIR, 'config.json');
  let raw: string;
  try {
    raw = fs.readFileSync(configPath, 'utf-8');
  } catch (err) {
    const code = (err as NodeJS.ErrnoException | undefined)?.code;
    if (code === 'ENOENT') {
      return {ok: false, reason: 'missing', err};
    }
    return {ok: false, reason: 'io', err};
  }
  if (!raw.trim()) {
    return {ok: false, reason: 'empty'};
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    return {ok: false, reason: 'parse', err};
  }
  if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
    return {ok: true, value: parsed as Record<string, unknown>};
  }
  return {ok: false, reason: 'shape'};
}

function readKissConfig(): Record<string, unknown> {
  const configPath = path.join(LOG_DIR, 'config.json');
  const RETRIES = 5;
  const BACKOFF_MS = 100;
  let last: ReturnType<typeof readKissConfigOnce> = {ok: false, reason: 'io'};
  for (let attempt = 0; attempt < RETRIES; attempt++) {
    last = readKissConfigOnce();
    if (last.ok) {
      return last.value;
    }
    if (last.reason === 'missing') {
      // The file genuinely does not exist — no point retrying.
      log(`readKissConfig: ${configPath} does not exist`);
      return {};
    }
    if (attempt < RETRIES - 1) {
      // Busy-wait briefly to let any concurrent writer finish.
      const deadline = Date.now() + BACKOFF_MS;
      while (Date.now() < deadline) {
        /* spin */
      }
    }
  }
  if (last.reason === 'empty') {
    log(
      `readKissConfig: ${configPath} exists but is empty after ${RETRIES} retries`,
    );
  } else if (last.reason === 'parse') {
    log(
      `readKissConfig: failed to parse ${configPath} after ${RETRIES} retries: ${
        last.err instanceof Error ? last.err.message : String(last.err)
      }`,
    );
  } else if (last.reason === 'shape') {
    log(`readKissConfig: ${configPath} parsed but not a plain object`);
  } else {
    log(
      `readKissConfig: failed to read ${configPath} after ${RETRIES} retries: ${
        last.err instanceof Error ? last.err.message : String(last.err)
      }`,
    );
  }
  return {};
}

/**
 * Write ``cfg`` to ``~/.kiss/config.json`` atomically: stage in a
 * sibling temp file and then ``rename`` into place so that concurrent
 * readers never observe an empty or half-written ``config.json``.
 */
function writeKissConfig(cfg: Record<string, unknown>): void {
  fs.mkdirSync(LOG_DIR, {recursive: true});
  const target = path.join(LOG_DIR, 'config.json');
  const tmp = path.join(
    LOG_DIR,
    `.config.json.${process.pid}.${Date.now()}.tmp`,
  );
  fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2) + '\n');
  fs.renameSync(tmp, target);
}

/**
 * Return the ``remote_password`` value from ``~/.kiss/config.json``,
 * or an empty string when it is missing / not a non-empty string.
 */
function getStoredRemotePassword(): string {
  const cfg = readKissConfig();
  const existing = cfg['remote_password'];
  if (typeof existing === 'string' && existing.length > 0) {
    return existing;
  }
  return '';
}

/**
 * Ensure the remote-access password for the KISS Sorcar web / mobile app
 * is configured.  Reads ``remote_password`` from ``~/.kiss/config.json``;
 * if it is empty or missing, prompts the user to set one.
 *
 * To guard against transient file-read failures (e.g. a concurrent
 * writer holding the file or the daemon restart briefly truncating it),
 * the config is re-read after a short delay before prompting the user.
 *
 * When the user provides a password it is persisted to ``config.json``.
 * When the user cancels, an informational message tells them the password
 * can be set later from the KISS Sorcar settings panel.
 */
async function ensureRemotePassword(): Promise<void> {
  // First read — fast path when password is already set.
  if (getStoredRemotePassword()) {
    log('ensureRemotePassword: password already set — skipping prompt');
    return;
  }

  // The daemon was just restarted; config.json may be mid-write by a
  // concurrent process (install.sh or kiss-web).  Wait briefly and retry.
  log(
    'ensureRemotePassword: password not found on first read — retrying after 2 s',
  );
  await new Promise(resolve => setTimeout(resolve, 2000));

  if (getStoredRemotePassword()) {
    log('ensureRemotePassword: password found on retry — skipping prompt');
    return;
  }

  log('ensureRemotePassword: password still empty — prompting user');
  const password = await vscode.window.showInputBox({
    title: 'KISS Sorcar — Remote Access Password',
    prompt:
      'Set a password for the KISS Sorcar web / mobile app (press Esc to skip):',
    placeHolder: 'Enter a password',
    password: true,
    ignoreFocusOut: true,
  });

  if (password === undefined || password.trim() === '') {
    vscode.window.showInformationMessage(
      'KISS Sorcar: You can set the remote access password later in the ' +
        'KISS Sorcar settings panel (Remote password field).',
    );
    return;
  }

  // Re-read config before writing so we don't clobber keys added by
  // a concurrent process between our read and this write.
  const cfg = readKissConfig();
  cfg['remote_password'] = password.trim();
  writeKissConfig(cfg);
  log('Remote access password saved to ~/.kiss/config.json');
}
