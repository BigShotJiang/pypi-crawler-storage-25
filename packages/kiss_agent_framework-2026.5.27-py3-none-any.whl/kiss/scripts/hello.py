print("Hello, world!")
