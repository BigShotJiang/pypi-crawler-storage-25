"""Auth module."""
