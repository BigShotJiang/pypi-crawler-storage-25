"""CPA client module."""
