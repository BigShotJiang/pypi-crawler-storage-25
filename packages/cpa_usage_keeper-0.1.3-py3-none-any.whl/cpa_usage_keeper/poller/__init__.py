"""Poller module."""
