from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="tablesqlconverter",
    version="1.0.1",
    author="HuangJie",
    author_email="huangjie155@msn.cn",
    description="Convert table schema between MySQL, Hive, and string formats",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/huangjie155/tablesqlconverter",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=[],
    extras_require={
        "dev": ["pytest", "flake8"],
    },
)