import re
from io import StringIO
from collections import Counter
import copy

M2HMap={'TINYINT': 'TINYINT', 'SMALLINT': 'SMALLINT', 'MEDIUMINT': 'INT', 'INT': 'INT', 'INTEGER': 'INT', 'BIGINT': 'BIGINT', 'FLOAT': 'FLOAT', 'DOUBLE': 'DOUBLE', 'DECIMAL': 'DECIMAL', 'NUMERIC': 'DECIMAL', 'CHAR': 'CHAR', 'VARCHAR': 'VARCHAR', 'TEXT': 'STRING', 'TINYTEXT': 'STRING', 'MEDIUMTEXT': 'STRING', 'LONGTEXT': 'STRING', 'BLOB': 'BINARY', 'TINYBLOB': 'BINARY', 'MEDIUMBLOB': 'BINARY', 'LONGBLOB': 'BINARY', 'DATE': 'DATE', 'DATETIME': 'TIMESTAMP', 'TIMESTAMP': 'TIMESTAMP', 'TIME': 'STRING', 'YEAR': 'SMALLINT', 'ENUM': 'STRING', 'SET': 'STRING', 'BIT': 'INT', 'BOOLEAN': 'BOOLEAN', 'BOOL': 'BOOLEAN', 'JSON': 'STRING', 'BINARY': 'BINARY', 'VARBINARY': 'BINARY'}


class Converter:
    """
    effective:
    1 将复制的字符串表格、mysql字符串、hivesql字符串等转换成schema中间
    2 schema转换成mysql,dataxjson,字符串表格
    3 mysql类型转转hive，mysqlSchema2hiveSchema
    
    schema格式
    {"<tbname>":[{"colname":"","type":"","comment":""},]}
      不受顺序限制，增强扩展能力
    """

    def _tblstr2Lines(self,tblstr):
        """
        字符串分行
        """
        return StringIO(tblstr.strip()).readlines()

    def _colNums(self,arr,sep="\t"):
        """
        用_tblstr2Lines的结果分列，并检查列数相等
        """
        content=[[ie.strip() for ie in it.split(sep)] for it in arr]
        stat=Counter([len(it) for it in content])
        if len(stat)>1:
            """校验"""
            raise Exception(str(stat))
        return content

    def _m2s_getFisrtParentheses(self,tgtstr):
        """
        mysql2shema第一个括号内的内容
        sgtstr示例 abc,)()
        """
        depth = 0
        pos = 0
        for it in tgtstr:
            if it == "(":
                depth += 1
            elif it == ')':
                depth -= 1
                if depth < 0:
                    break
            pos += 1
        return tgtstr[0:pos]
    
    def row2col(self,tblstr):
        """
        行存储转列存储
        """
        arr=self._colNums(self._tblstr2Lines(tblstr))
        return zip(*arr)
    
    def tblstr2schema(self,tblstr,tblNameNo,fieldNameNo,typeNo,commentNo=None,dbNameNo=None,dataNo=0,sep="\t"):
        """
        字符串类型的表格式转json存储格式
        包含表名，可包含数据库名和comment
        """
        arr=self._colNums(self._tblstr2Lines(tblstr),sep=sep)[dataNo:]
        data={}
        for it in arr:
            tbname =it[tblNameNo] if dbNameNo is None else f"{it[dbNameNo]}.{it[tblNameNo]}"
            if tbname not in data:
                data[tbname]=[]
            data[tbname].append({"field":it[fieldNameNo],"type":it[typeNo],"comment":it[commentNo] if commentNo is not None else ""})
        return data

    def tblstr2schema_fillTblname(self,tblstr,tblName,fieldNameNo,typeNo,commentNo=None,dataNo=0,sep="\t"):
        """
        tblname手动添加
        其它同tblstr2schema
        """
        arr=self._colNums(self._tblstr2Lines(tblstr),sep=sep)[dataNo:]
        data={tblName:[]}
        for it in arr:
            data[tblName].append({"field":it[fieldNameNo],"type":it[typeNo],"comment":it[commentNo] if commentNo is not None else ""})
        

    def schema2mysql(self,schema,sep='\n'):
        """
        将json的schema中间形式转换为mysql
        """
        res=[]
        for tblname in schema:
            colInfo=",".join([f"`{it['field']}` {it['type']} comment '{it['comment']}'" for it in schema[tblname]])
            sql=f"CREATE TABLE IF NOT EXISTS {tblname}({colInfo})"
            res.append(sql)
        return sep.join(res)
    
    def schema2table(self,schema):
        """
        将json的schema格式转换为table字符串
        """
        res=[]
        for tblname in schema:
            res+=[[tblname,it["field"],it['type'],it['comment'] and it['comment'] or ""] for it in schema[tblname]]
        return "\n".join(["\t".join(ie) for ie in res])
    
    def schema2dataxjson(self,schema,*keys):
        """
        将json的schema格式转换为datax的list
        """
        data={}
        for it in schema:
            data[it]=[]
            for ia in schema[it]:
                ib={}
                for key in keys:
                    ib[f"{key}"]=f"{ia[key]}"
                data[it].append(ib)
        return data

    def schema2SingleList(self,schema,key):
        """
        将json的schema的一个字段抽出一个列表
        """
        data={}
        for it in schema:
            data[it]=[ia[f"{key}"] for ia in schema[it]]
        return data

    def _m2s_getFieldInfo(self,word):
        """
        mysql2schema的工具
        """
        typelststr = '(?<=\s)(?:TINYINT|SMALLINT|MEDIUMINT|INTEGER|INT|BIGINT|FLOAT|DOUBLE|DECIMAL|NUMERIC|VARCHAR|CHAR|TINYTEXT|MEDIUMTEXT|LONGTEXT|TEXT|TINYBLOB|MEDIUMBLOB|LONGBLOB|BLOB|DATETIME|DATE|TIMESTAMP|TIME|YEAR|ENUM|SET|BIT|BOOLEAN|BOOL|JSON|VARBINARY|BINARY)'
        typeposPattern = re.compile(typelststr, re.I)
        pos = 0
        itemlst = []
        for it in typeposPattern.finditer(word):
            s = it.start()
            itemlst.append(word[pos:s])
            pos = s
        itemlst.append(word[pos:])
        # print(itemlst)
        itemlsta = itemlst[:-1]
        itemlstb = itemlst[1:]
        data = []
        for i in range(len(itemlstb)):
            filedname = re.findall("\w+", itemlsta[i].rsplit(",")[-1])[0]
            typename = re.match("\w+(?:\([\d,]+?\))?", itemlstb[i]).group()
            commentname = re.search("comment\s+[\"\'](.*)[\"\']", itemlstb[i], re.I | re.S)
            data.append({"field":filedname, "type":typename, "comment":commentname.group(1) if commentname else ""})
        return data
    
    def sql2schema(self,sqlstrs):
        splitTable = re.compile("(?=CREATE\s+(?:\w+)?\s+TABLE)", re.IGNORECASE)
        tblNamePattern = re.compile("CREATE\s+(?:\w+\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS)?\s+([\w.]+)\(", re.S | re.I)
        resdata={}
        for tbl in splitTable.split(sqlstrs)[1:]:
            tblnamesearch=tblNamePattern.search(tbl)
            tblname=tblnamesearch.group(1)
            data=self._m2s_getFisrtParentheses(tbl[tblnamesearch.end():])
            da=self._m2s_getFieldInfo(data)
            resdata[tblname]=da
        return resdata
    
    def mysqlSchema2hiveSchema(self,schema):
        schemaCopy=copy.deepcopy(schema)
        pattern = re.compile(f"(\w+)(?:\(|\b)?", flags=re.I)
        try:
            for it in schema:
                for ty in schema[it]:
                    # print(ty)
                    ty['type']=M2HMap[pattern.match(ty["type"]).group(1).upper()] if pattern.match(ty["type"]) else ty["type"].upper()
        except Exception as e:
            raise Exception(e)
        return schemaCopy
    
    def hiveSchema2HiveSql(self, schema, sep='\n',external=True,infoword="",tblCommentMap:dict= {}):
        "简写hm2hq"
        res = []
        for tblname in schema:
            colInfo = ",".join(
                [f"`{it['field']}` {it['type']} comment '{it['comment']}'" for it in schema[tblname]])
            sql = f"CREATE EXTERNAL TABLE IF NOT EXISTS {tblname}({colInfo})" if external else f"CREATE TABLE IF NOT EXISTS {tblname}({colInfo})"
            sql=sql if not infoword else sql+" "+f"COMMENT '{tblCommentMap.get(tblname)}'" if not tblCommentMap else "" +" "+infoword
            res.append(sql)
        return sep.join(res)
    
    def hm2hq_tblCommentMap(self,tblnamelst,tblCommentlst):
        """
        hiveSchema2HiveSql的参数
        """
        return list(zip(tblnamelst,tblCommentlst))
    
    def hm2hq_hiveInfowordRowFormat(self,hasField=False,hasLine=False,field="\t",line="\n"):
        infow="ROW FORMAT DELIMITED "
        if hasField:
            infow+=f"FIELDS TERMINATED BY '{field}'"
        if hasLine:
            infow +=f"LINES TERMINATED BY '{line}'"
        return infow
    
    def hm2hq_hiveInfowordSave(self,savetgt="TEXTFILE"):
        return f"STORED AS {savetgt};"