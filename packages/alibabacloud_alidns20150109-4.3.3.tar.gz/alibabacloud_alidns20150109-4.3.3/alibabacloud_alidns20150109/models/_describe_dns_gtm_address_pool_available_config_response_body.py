# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_alidns20150109 import models as main_models
from darabonba.model import DaraModel

class DescribeDnsGtmAddressPoolAvailableConfigResponseBody(DaraModel):
    def __init__(
        self,
        attribute_infos: main_models.DescribeDnsGtmAddressPoolAvailableConfigResponseBodyAttributeInfos = None,
        request_id: str = None,
    ):
        self.attribute_infos = attribute_infos
        # The ID of the request.
        self.request_id = request_id

    def validate(self):
        if self.attribute_infos:
            self.attribute_infos.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.attribute_infos is not None:
            result['AttributeInfos'] = self.attribute_infos.to_map()

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AttributeInfos') is not None:
            temp_model = main_models.DescribeDnsGtmAddressPoolAvailableConfigResponseBodyAttributeInfos()
            self.attribute_infos = temp_model.from_map(m.get('AttributeInfos'))

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        return self

class DescribeDnsGtmAddressPoolAvailableConfigResponseBodyAttributeInfos(DaraModel):
    def __init__(
        self,
        attribute_info: List[main_models.DescribeDnsGtmAddressPoolAvailableConfigResponseBodyAttributeInfosAttributeInfo] = None,
    ):
        self.attribute_info = attribute_info

    def validate(self):
        if self.attribute_info:
            for v1 in self.attribute_info:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['AttributeInfo'] = []
        if self.attribute_info is not None:
            for k1 in self.attribute_info:
                result['AttributeInfo'].append(k1.to_map() if k1 else None)

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.attribute_info = []
        if m.get('AttributeInfo') is not None:
            for k1 in m.get('AttributeInfo'):
                temp_model = main_models.DescribeDnsGtmAddressPoolAvailableConfigResponseBodyAttributeInfosAttributeInfo()
                self.attribute_info.append(temp_model.from_map(k1))

        return self

class DescribeDnsGtmAddressPoolAvailableConfigResponseBodyAttributeInfosAttributeInfo(DaraModel):
    def __init__(
        self,
        father_code: str = None,
        group_code: str = None,
        group_name: str = None,
        line_code: str = None,
        line_name: str = None,
    ):
        self.father_code = father_code
        self.group_code = group_code
        self.group_name = group_name
        self.line_code = line_code
        self.line_name = line_name

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.father_code is not None:
            result['FatherCode'] = self.father_code

        if self.group_code is not None:
            result['GroupCode'] = self.group_code

        if self.group_name is not None:
            result['GroupName'] = self.group_name

        if self.line_code is not None:
            result['LineCode'] = self.line_code

        if self.line_name is not None:
            result['LineName'] = self.line_name

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('FatherCode') is not None:
            self.father_code = m.get('FatherCode')

        if m.get('GroupCode') is not None:
            self.group_code = m.get('GroupCode')

        if m.get('GroupName') is not None:
            self.group_name = m.get('GroupName')

        if m.get('LineCode') is not None:
            self.line_code = m.get('LineCode')

        if m.get('LineName') is not None:
            self.line_name = m.get('LineName')

        return self

