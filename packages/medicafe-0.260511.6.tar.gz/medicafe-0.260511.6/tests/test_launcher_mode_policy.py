#!/usr/bin/env python
from __future__ import print_function

import unittest

from MediCafe import launcher


class LauncherModePolicyTests(unittest.TestCase):

    def test_explicit_mode_env_override_wins(self):
        policy = launcher.resolve_next_step_assistant_mode(
            {'MEDICAFE_NEXT_STEP_ASSISTANT_MODE': 'off'},
            'auto_contextual',
            context={'non_interactive': False},
        )
        self.assertEqual(policy.get('mode'), 'off')
        self.assertEqual(policy.get('source'), 'env_override')
        self.assertEqual(policy.get('reason'), 'explicit_mode')

    def test_preference_used_when_no_env_override(self):
        policy = launcher.resolve_next_step_assistant_mode({}, 'advisory')
        self.assertEqual(policy.get('mode'), 'advisory')
        self.assertEqual(policy.get('source'), 'preference')
        self.assertEqual(policy.get('reason'), 'saved_preference')

    def test_invalid_explicit_mode_falls_back_to_advisory(self):
        policy = launcher.resolve_next_step_assistant_mode(
            {'MEDICAFE_NEXT_STEP_ASSISTANT_MODE': 'surprise'},
            'off',
        )
        self.assertEqual(policy.get('mode'), 'advisory')
        self.assertEqual(policy.get('source'), 'env_override')
        self.assertEqual(policy.get('reason'), 'invalid_explicit_mode_fallback')


if __name__ == '__main__':
    unittest.main()
