# -*- coding: utf-8 -*-
from __future__ import print_function

import ctypes
import os
import sys
import unittest

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from MediCafe import win_pid_probe

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch


class TestWinPidProbe(unittest.TestCase):
    def test_non_windows_returns_false(self):
        with patch.object(win_pid_probe.os, 'name', 'posix'):
            self.assertFalse(win_pid_probe.windows_process_is_alive_or_unknown(1234))

    def test_open_process_access_denied_assumes_alive(self):
        class FakeKernel32(object):
            def OpenProcess(self, access, inherit, pid):
                return 0

            def GetLastError(self):
                return 5

        fake_kernel = FakeKernel32()
        import types
        fake_windll = types.SimpleNamespace(kernel32=fake_kernel)
        with patch.object(win_pid_probe.os, 'name', 'nt'):
            with patch.object(ctypes, 'windll', fake_windll, create=True):
                self.assertTrue(win_pid_probe.windows_process_is_alive_or_unknown(99))

    def test_exit_code_not_still_active_returns_false(self):
        class FakeKernel32(object):
            def OpenProcess(self, access, inherit, pid):
                return 42

            def GetExitCodeProcess(self, handle, exit_code_ptr):
                try:
                    exit_code_ptr.contents.value = 0
                except AttributeError:
                    exit_code_ptr._obj.value = 0
                return 1

            def CloseHandle(self, handle):
                return True

        fake_kernel = FakeKernel32()
        import types
        fake_windll = types.SimpleNamespace(kernel32=fake_kernel)
        with patch.object(win_pid_probe.os, 'name', 'nt'):
            with patch.object(ctypes, 'windll', fake_windll, create=True):
                self.assertFalse(win_pid_probe.windows_process_is_alive_or_unknown(7))


if __name__ == '__main__':
    unittest.main()
