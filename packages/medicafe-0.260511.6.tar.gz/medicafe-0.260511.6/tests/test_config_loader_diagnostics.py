import json
import os

from MediCafe import MediLink_ConfigLoader as cfg_loader
from MediCafe import json_sidecar as sidecar


def setup_function(_function):
    cfg_loader.clear_config_cache()
    os.environ.pop('MEDICAFE_CONFIG_FILE', None)
    os.environ.pop('MEDICAFE_CROSSWALK_FILE', None)


def teardown_function(_function):
    cfg_loader.clear_config_cache()
    os.environ.pop('MEDICAFE_CONFIG_FILE', None)
    os.environ.pop('MEDICAFE_CROSSWALK_FILE', None)


def _write_json(path, payload):
    with open(str(path), 'w', encoding='utf-8') as handle:
        json.dump(payload, handle)


def test_load_configuration_reports_missing_files_and_uses_defaults(tmp_path):
    config_path = tmp_path / 'missing_config.json'
    crosswalk_path = tmp_path / 'missing_crosswalk.json'

    config, crosswalk = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert diagnostics['overall_status'] == 'degraded'
    assert diagnostics['config']['status'] == 'missing'
    assert diagnostics['crosswalk']['status'] == 'missing'
    assert diagnostics['defaults_in_use']['config'] is True
    assert diagnostics['defaults_in_use']['crosswalk'] is True
    assert 'MediLink_Config' in config
    assert 'payer_id' in crosswalk


def test_invalid_config_keeps_valid_crosswalk_and_records_syntax_issue(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'

    with open(str(config_path), 'w', encoding='utf-8') as handle:
        handle.write('{ invalid json')
    _write_json(crosswalk_path, {'payer_id': {'1': '87726'}})

    config, crosswalk = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert diagnostics['overall_status'] == 'degraded'
    assert diagnostics['config']['status'] == 'invalid_syntax'
    assert diagnostics['defaults_in_use']['config'] is True
    assert diagnostics['defaults_in_use']['crosswalk'] is False
    assert crosswalk['payer_id']['1'] == '87726'
    assert 'MediLink_Config' in config


def test_invalid_utf8_config_reports_decode_error(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'

    with open(str(config_path), 'wb') as handle:
        handle.write(b'{"MediLink_Config": {"local_storage_path": "\x80"}}')
    _write_json(crosswalk_path, {'payer_id': {}})

    cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert diagnostics['config']['status'] == 'decode_error'
    assert diagnostics['defaults_in_use']['config'] is True


def test_missing_medilink_config_section_preserves_root_keys_and_injects_defaults(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'

    _write_json(config_path, {'CSV_FILE_PATH': 'demo.csv'})
    _write_json(crosswalk_path, {'payer_id': {'2': '03432'}})

    config, crosswalk = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert diagnostics['config']['status'] == 'missing_required_key'
    assert diagnostics['config']['fallback_scope'] == 'MediLink_Config_section'
    assert config['CSV_FILE_PATH'] == 'demo.csv'
    assert 'MediLink_Config' in config
    assert crosswalk['payer_id']['2'] == '03432'


def test_load_configuration_composes_optional_sidecars(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    config_local_path = tmp_path / 'config.local.json'
    crosswalk_state_path = tmp_path / 'crosswalk.state.json'

    _write_json(config_path, {'CSV_FILE_PATH': 'base.csv', 'MediLink_Config': {'local_storage_path': 'base'}})
    _write_json(crosswalk_path, {'payer_id': {}, 'optum_payer_list': {'metadata': {'last_update': 'old'}, 'payers': {}}})
    _write_json(config_local_path, {
        '__sidecar__': {'schema_version': 1},
        'CSV_FILE_PATH': 'local.csv',
        'MediLink_Config': {'certificate_provider': {'mode': 'managed_ca'}},
    })
    _write_json(crosswalk_state_path, {
        '__sidecar__': {'schema_version': 1},
        'optum_payer_list': {'metadata': {'last_update': 'new'}, 'payers': {'87726': {'search_claim': True}}},
    })

    config, crosswalk = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert config['CSV_FILE_PATH'] == 'local.csv'
    assert config['MediLink_Config']['certificate_provider']['mode'] == 'managed_ca'
    assert crosswalk['optum_payer_list']['metadata']['last_update'] == 'new'
    assert crosswalk['optum_payer_list']['payers']['87726']['search_claim'] is True
    assert diagnostics['resolved_paths']['config_local'].endswith('config.local.json')
    assert diagnostics['resolved_paths']['crosswalk_state'].endswith('crosswalk.state.json')
    assert diagnostics['config_local']['status'] == 'loaded'
    assert diagnostics['crosswalk_state']['status'] == 'loaded'


def test_load_configuration_ignores_tombstones_from_sidecar(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    config_local_path = tmp_path / 'config.local.json'

    _write_json(config_path, {'CSV_FILE_PATH': 'base.csv', 'MediLink_Config': {'local_storage_path': 'base'}})
    _write_json(crosswalk_path, {'payer_id': {}})
    _write_json(config_local_path, {
        '__sidecar__': {'schema_version': 1},
        'CSV_FILE_PATH': {'__tombstone__': True},
    })

    config, _crosswalk = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))

    assert 'CSV_FILE_PATH' not in config


def test_load_configuration_reports_schema_mismatch_for_sidecar(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    crosswalk_state_path = tmp_path / 'crosswalk.state.json'

    _write_json(config_path, {'MediLink_Config': {'local_storage_path': 'base'}})
    _write_json(crosswalk_path, {'payer_id': {}, 'optum_payer_list': {'metadata': {'last_update': 'old'}, 'payers': {}}})
    _write_json(crosswalk_state_path, {
        '__sidecar__': {'schema_version': 999},
        'optum_payer_list': {'metadata': {'last_update': 'new'}, 'payers': {'87726': {'search_claim': True}}},
    })

    _config, crosswalk = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert diagnostics['overall_status'] == 'degraded'
    assert diagnostics['crosswalk_state']['status'] == 'schema_mismatch'
    assert diagnostics['crosswalk_state']['ignored_for_composition'] is True
    assert crosswalk['optum_payer_list']['metadata']['last_update'] == 'old'


def test_state_owned_summary_key_snippet_more_count_excludes_empty_pointers():
    """(+N more) must count only displayable keys, not raw list length with null/empty entries."""
    ptrs = ['', '', 'a', 'b', 'c', '', None]
    ptrs.sort(key=lambda p: (p is None, str(p or '')))
    snippet = cfg_loader._state_owned_summary_key_snippet(ptrs, max_keys=1, max_chars=240)
    assert '(+2 more)' in snippet
    assert '(+6 more)' not in snippet


def test_load_configuration_reports_state_owned_present_in_baseline(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    config_local_path = tmp_path / 'config.local.json'
    _write_json(config_path, {'CSV_FILE_PATH': 'legacy.csv', 'MediLink_Config': {'local_storage_path': 'base'}})
    _write_json(crosswalk_path, {'payer_id': {}, 'optum_payer_list': {'metadata': {}, 'payers': {}}})
    _write_json(config_local_path, {'__sidecar__': {'schema_version': 1}, 'CSV_FILE_PATH': 'sidecar.csv'})

    cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    stale = diagnostics.get('stale_state_owned_in_baseline', {})
    assert stale.get('config_count', 0) >= 1
    pointers = stale.get('config_state_owned_pointers') or []
    assert isinstance(pointers, list)
    assert len(pointers) == int(stale.get('config_count') or 0)
    assert any('CSV_FILE_PATH' in str(p) for p in pointers)
    lines = diagnostics.get('summary_lines') or []
    assert any('baseline_config_state_owned_keys' in ln for ln in lines)
    audit = diagnostics.get('config_loader_audit') or {}
    assert audit.get('schema_version') == 2
    assert audit.get('config_state_owned_pointers') == pointers
    assert diagnostics['overall_status'] == 'degraded'

    rendered = cfg_loader._format_config_load_diagnostics(diagnostics)
    assert 'Configuration loader diagnostics:' in rendered
    assert 'baseline_config_state_owned_keys' in rendered


def test_load_configuration_legacy_baseline_state_without_sidecar_is_not_degraded(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'
    _write_json(config_path, {'CSV_FILE_PATH': 'legacy.csv', 'MediLink_Config': {'local_storage_path': 'base'}})
    _write_json(crosswalk_path, {'payer_id': {}})

    cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    diagnostics = cfg_loader.get_last_load_diagnostics()

    stale = diagnostics.get('stale_state_owned_in_baseline', {})
    assert stale.get('config_count', 0) == 0
    assert diagnostics['overall_status'] == 'ok'


def test_sidecar_write_invalidates_loader_cache(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'

    _write_json(config_path, {'CSV_FILE_PATH': 'before.csv', 'MediLink_Config': {'local_storage_path': 'base'}})
    _write_json(crosswalk_path, {'payer_id': {}})

    config1, _ = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    assert config1['CSV_FILE_PATH'] == 'before.csv'

    ok, _written_path = sidecar.write_config_local_update(
        str(config_path),
        '$/CSV_FILE_PATH',
        'after.csv',
        writer='pytest_cache_invalidation',
    )
    assert ok is True

    config2, _ = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    assert config2['CSV_FILE_PATH'] == 'after.csv'


def test_loader_path_resolution_uses_environment_sidecar_colocation(tmp_path):
    config_path = tmp_path / 'nested' / 'config.json'
    crosswalk_path = tmp_path / 'nested' / 'crosswalk.json'
    config_path.parent.mkdir()

    _write_json(config_path, {'CSV_FILE_PATH': 'base.csv', 'MediLink_Config': {'local_storage_path': 'base'}})
    _write_json(crosswalk_path, {'payer_id': {}})
    _write_json(config_path.parent / 'config.local.json', {
        '__sidecar__': {'schema_version': 1},
        'CSV_FILE_PATH': 'env-local.csv',
    })

    os.environ['MEDICAFE_CONFIG_FILE'] = str(config_path)
    os.environ['MEDICAFE_CROSSWALK_FILE'] = str(crosswalk_path)

    config, _ = cfg_loader.load_configuration(
        config_path=cfg_loader._DEFAULT_CONFIG_PATH,
        crosswalk_path=cfg_loader._DEFAULT_CROSSWALK_PATH,
    )
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert config['CSV_FILE_PATH'] == 'env-local.csv'
    assert diagnostics['path_source'] == 'environment'
    assert diagnostics['resolved_paths']['config_local'] == str(config_path.parent / 'config.local.json')
    assert diagnostics['resolved_paths']['crosswalk_state'] == str(config_path.parent / 'crosswalk.state.json')


def test_loader_path_resolution_uses_windows_cwd_fallback(monkeypatch, tmp_path):
    json_dir = tmp_path / 'json'
    json_dir.mkdir()
    config_path = json_dir / 'config.json'
    crosswalk_path = json_dir / 'crosswalk.json'

    _write_json(config_path, {'CSV_FILE_PATH': 'cwd.csv', 'MediLink_Config': {'local_storage_path': 'base'}})
    _write_json(crosswalk_path, {'payer_id': {}})

    monkeypatch.setattr(cfg_loader.platform, 'system', lambda: 'Windows')
    monkeypatch.setattr(cfg_loader.platform, 'release', lambda: '11')
    monkeypatch.setattr(cfg_loader.os, 'getcwd', lambda: str(tmp_path))
    monkeypatch.setattr(cfg_loader, '_DEFAULT_CONFIG_PATH', str(tmp_path / 'missing-default-config.json'))
    monkeypatch.setattr(cfg_loader, '_DEFAULT_CROSSWALK_PATH', str(tmp_path / 'missing-default-crosswalk.json'))

    config, _ = cfg_loader.load_configuration(
        config_path=cfg_loader._DEFAULT_CONFIG_PATH,
        crosswalk_path=cfg_loader._DEFAULT_CROSSWALK_PATH,
    )
    diagnostics = cfg_loader.get_last_load_diagnostics()

    assert config['CSV_FILE_PATH'] == 'cwd.csv'
    assert diagnostics['path_source'] == 'windows_cwd_fallback'
    assert diagnostics['resolved_paths']['config'] == str(config_path)
    assert diagnostics['resolved_paths']['crosswalk'] == str(crosswalk_path)


def test_loader_path_resolution_uses_windows_xp_fallback(monkeypatch):
    xp_config = r'F:\Medibot\json\config.json'
    xp_crosswalk = r'F:\Medibot\json\crosswalk.json'

    monkeypatch.setattr(cfg_loader.platform, 'system', lambda: 'Windows')
    monkeypatch.setattr(cfg_loader.platform, 'release', lambda: 'XP')
    monkeypatch.setattr(cfg_loader, '_DEFAULT_CONFIG_PATH', r'Z:\missing-default-config.json')
    monkeypatch.setattr(cfg_loader, '_DEFAULT_CROSSWALK_PATH', r'Z:\missing-default-crosswalk.json')

    info = cfg_loader._resolve_requested_config_paths(None, None)

    assert info['path_source'] == 'windows_xp_fallback'
    assert info['config_path'] == xp_config
    assert info['crosswalk_path'] == xp_crosswalk


def test_resolve_effective_paths_and_sidecar_paths(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'

    _write_json(config_path, {'MediLink_Config': {'local_storage_path': 'base'}})
    _write_json(crosswalk_path, {'payer_id': {}})
    os.environ['MEDICAFE_CONFIG_FILE'] = str(config_path)
    os.environ['MEDICAFE_CROSSWALK_FILE'] = str(crosswalk_path)

    assert cfg_loader.resolve_effective_config_path(None) == str(config_path)
    assert cfg_loader.resolve_effective_crosswalk_path(None, None) == str(crosswalk_path)
    paths = cfg_loader.resolve_sidecar_paths(str(config_path), str(crosswalk_path))
    assert paths['config_local_path'].endswith('config.local.json')
    assert paths['crosswalk_state_path'].endswith('crosswalk.state.json')


def test_update_certificate_provider_config_writes_config_local_sidecar(tmp_path):
    config_path = tmp_path / 'config.json'
    crosswalk_path = tmp_path / 'crosswalk.json'

    _write_json(config_path, {'MediLink_Config': {'local_storage_path': 'base'}})
    _write_json(crosswalk_path, {'payer_id': {}})

    success, error = cfg_loader.update_certificate_provider_config(
        {'mode': 'managed_ca', 'status': 'ready'},
        config_path=str(config_path),
    )

    assert success is True
    assert error is None
    local_path = tmp_path / 'config.local.json'
    assert local_path.exists()
    with open(str(local_path), 'r', encoding='utf-8') as handle:
        sidecar = json.load(handle)
    assert sidecar['MediLink_Config']['certificate_provider']['mode'] == 'managed_ca'
    cfg_loader.clear_config_cache()
    config, _crosswalk = cfg_loader.load_configuration(str(config_path), str(crosswalk_path))
    assert config['MediLink_Config']['certificate_provider']['status'] == 'ready'
