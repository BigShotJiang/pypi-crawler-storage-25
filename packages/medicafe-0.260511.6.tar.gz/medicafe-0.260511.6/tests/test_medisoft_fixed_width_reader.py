# -*- coding: utf-8 -*-
"""Medisoft fixed-width reader: multi-line record boundaries (Python 3.4+)."""
from __future__ import unicode_literals

import os
import tempfile
import json

from MediLink import MediLink_DataMgmt


def _write_dat(lines):
    fd, path = tempfile.mkstemp(suffix=".dat", text=True)
    try:
        os.close(fd)
        with open(path, "wb") as handle:
            for line in lines:
                if isinstance(line, bytes):
                    handle.write(line + b"\n")
                else:
                    handle.write(line.encode("ascii") + b"\n")
        return path
    except Exception:
        try:
            os.unlink(path)
        except Exception:
            pass
        raise


def test_medisoft_three_line_records_without_blanks_yield_two_blocks():
    """Back-to-back 3-line patients must not merge line1 of patient2 into patient1."""
    lines = [
        "PERSONAL_AAAAAAAAAAAAAAAAA",
        "INSURANCE_BBBBBBBBBBBBBBBBBBB",
        "SERVICE_CCCCCCCCCCCCCCCCCCCCC",
        "PERSONAL_DDDDDDDDDDDDDDDDDDDD",
        "INSURANCE_EEEEEEEEEEEEEEEEEEE",
        "SERVICE_FFFFFFFFFFFFFFFFFFFFF",
    ]
    path = _write_dat(lines)
    try:
        gen = MediLink_DataMgmt.read_consolidated_fixed_width_data(
            path,
            config={
                "mode": "medisoft_records",
                "min_lines": 3,
                "max_lines": 5,
                "skip_header": False,
                "medisoft_peek_yield_after_lines": 3,
            },
        )
        rows = list(gen)
        assert len(rows) == 2
        assert rows[0][0] == lines[0]
        assert rows[0][1] == lines[1]
        assert rows[0][2] == lines[2]
        assert rows[1][0] == lines[3]
        assert rows[1][1] == lines[4]
        assert rows[1][2] == lines[5]
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass


def test_medisoft_blank_separated_records_still_parse():
    lines = [
        "PERSONAL_AAAAAAAAAAAAAAAAA",
        "INSURANCE_BBBBBBBBBBBBBBBBBBB",
        "SERVICE_CCCCCCCCCCCCCCCCCCCCC",
        "",
        "PERSONAL_DDDDDDDDDDDDDDDDDDDD",
        "INSURANCE_EEEEEEEEEEEEEEEEEEE",
        "SERVICE_FFFFFFFFFFFFFFFFFFFFF",
    ]
    path = _write_dat(lines)
    try:
        gen = MediLink_DataMgmt.read_consolidated_fixed_width_data(
            path,
            config={
                "mode": "medisoft_records",
                "min_lines": 3,
                "max_lines": 5,
                "skip_header": False,
                "medisoft_peek_yield_after_lines": 3,
            },
        )
        rows = list(gen)
        assert len(rows) == 2
        assert rows[0][0].startswith("PERSONAL_A")
        assert rows[1][0].startswith("PERSONAL_D")
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass


def test_legacy_peek_accumulates_when_yield_after_equals_max_lines():
    """Opt-in old behavior: do not force yield at 3 when peek_yield_after_lines is 5."""
    lines = [
        "L1", "L2", "L3", "L4", "L5",
        "M1", "M2", "M3",
    ]
    path = _write_dat(lines)
    try:
        gen = MediLink_DataMgmt.read_consolidated_fixed_width_data(
            path,
            config={
                "mode": "medisoft_records",
                "min_lines": 3,
                "max_lines": 5,
                "skip_header": False,
                "medisoft_peek_yield_after_lines": 5,
            },
        )
        rows = list(gen)
        assert len(rows) == 2
        assert rows[0][0] == "L1" and rows[0][4] == "L5"
        assert rows[1][0] == "M1"
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass


def test_classify_fourth_line_service_vs_personal():
    """Slice-based scores disambiguate extra service line vs next patient personal line."""
    ps = {"FIRST": [0, 10], "LAST": [10, 22]}
    ss = {"DATE": [24, 36], "CPT": [36, 42]}
    line_svc = ((" " * 24) + "04/15/2026" + "99213".ljust(6)).ljust(42)
    line_per = ("JOHN".ljust(10) + "DOE".ljust(12)).ljust(42)
    assert (
        MediLink_DataMgmt._classify_medisoft_continuation_line(line_svc, ps, ss)
        == "service_continuation"
    )
    assert (
        MediLink_DataMgmt._classify_medisoft_continuation_line(line_per, ps, ss)
        == "next_patient"
    )


def test_medisoft_fourth_line_service_keeps_one_four_line_record():
    """When line 4 scores as service, it stays in the same patient block (no blank separator)."""
    ps = {"FIRST": [0, 10], "LAST": [10, 22]}
    ss = {"DATE": [24, 36], "CPT": [36, 42]}
    p1a = ("ALICE     JONES       ").ljust(42)
    p1b = ("INSURANCE_BBBBBBBBBBBB").ljust(42)
    p1c = ("SERVICE_CCCCCCCCCCCCCC").ljust(42)
    line4_svc = ((" " * 24) + "04/15/2026" + "99213".ljust(6)).ljust(42)
    p2a = ("BOB       SMITH       ").ljust(42)
    p2b = ("INSURANCE_2___________").ljust(42)
    p2c = ("SERVICE_2_____________").ljust(42)
    lines = [p1a, p1b, p1c, line4_svc, p2a, p2b, p2c]
    path = _write_dat(lines)
    try:
        gen = MediLink_DataMgmt.read_consolidated_fixed_width_data(
            path,
            config={
                "mode": "medisoft_records",
                "min_lines": 3,
                "max_lines": 5,
                "skip_header": False,
                "medisoft_peek_yield_after_lines": 3,
                "personal_slices": ps,
                "service_slices": ss,
            },
        )
        rows = list(gen)
        assert len(rows) == 2
        assert rows[0][3] == line4_svc
        assert rows[1][0] == p2a
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass


def test_medisoft_fourth_line_personal_starts_new_patient():
    """When line 4 scores as personal, it begins the next 3-line patient (no blank separator)."""
    ps = {"FIRST": [0, 10], "LAST": [10, 22]}
    ss = {"DATE": [24, 36], "CPT": [36, 42]}
    p1a = ("ALICE     JONES       ").ljust(42)
    p1b = ("INSURANCE_BBBBBBBBBBBB").ljust(42)
    p1c = ("SERVICE_CCCCCCCCCCCCCC").ljust(42)
    line4_per = ("ZOE       BAKER       ").ljust(42)
    p2b = ("INSURANCE_ZZZZZZZZZZZZ").ljust(42)
    p2c = ("SERVICE_ZZZZZZZZZZZZZZ").ljust(42)
    lines = [p1a, p1b, p1c, line4_per, p2b, p2c]
    path = _write_dat(lines)
    try:
        gen = MediLink_DataMgmt.read_consolidated_fixed_width_data(
            path,
            config={
                "mode": "medisoft_records",
                "min_lines": 3,
                "max_lines": 5,
                "skip_header": False,
                "medisoft_peek_yield_after_lines": 3,
                "personal_slices": ps,
                "service_slices": ss,
            },
        )
        rows = list(gen)
        assert len(rows) == 2
        assert rows[0][2] == p1c
        assert rows[0][3] is None
        assert rows[1][0] == line4_per
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass


def test_dat_boundary_telemetry_writes_dev_artifacts_not_info_per_file(monkeypatch, tmp_path):
    lines = [
        "PERSONAL_AAAAAAAAAAAAAAAAA",
        "INSURANCE_BBBBBBBBBBBBBBBBBBB",
        "SERVICE_CCCCCCCCCCCCCCCCCCCCC",
        "",
    ]
    path = _write_dat(lines)
    reports = tmp_path / "reports"
    logs = []

    def fake_log(message, level="INFO", *args, **kwargs):
        logs.append((level, message))

    monkeypatch.setenv("MEDICAFE_DAT_BOUNDARY_TELEMETRY_DIR", str(reports))
    monkeypatch.setattr(MediLink_DataMgmt.MediLink_ConfigLoader, "log", fake_log)
    try:
        rows = list(MediLink_DataMgmt.read_consolidated_fixed_width_data(
            path,
            config={
                "mode": "medisoft_records",
                "min_lines": 3,
                "max_lines": 5,
                "skip_header": False,
                "medisoft_peek_yield_after_lines": 3,
            },
        ))
        assert len(rows) == 1
        assert not any(
            level == "INFO" and "MEDISOFT_DAT_BOUNDARY_SUMMARY" in message
            for level, message in logs
        )
        assert any(
            level == "DEBUG" and "MEDISOFT_DAT_BOUNDARY_DETAIL" in message
            for level, message in logs
        )
        summary_path = reports / "medisoft_dat_boundary_summary_latest.json"
        detail_path = reports / "medisoft_dat_boundary_detail_latest.jsonl"
        assert summary_path.exists()
        assert detail_path.exists()
        with open(str(summary_path), "r") as handle:
            summary = json.load(handle)
        assert summary["file_count"] >= 1
    finally:
        try:
            os.unlink(path)
        except Exception:
            pass
