# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import sys
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _write_json(path, data):
    with open(path, 'w') as handle:
        json.dump(data, handle)


def _write_text(path, text):
    with open(path, 'w') as handle:
        handle.write(text)


def _write_csv(path):
    _write_text(path, 'h1,h2\n1,2\n')


class CsvIntakeHeuristicBackfillTests(unittest.TestCase):
    def setUp(self):
        import tempfile

        self.tmp = tempfile.mkdtemp()
        self.target = os.path.join(self.tmp, 'tgt')
        self.storage = os.path.join(self.tmp, 'storage')
        os.makedirs(self.target)
        os.makedirs(self.storage)

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmp, ignore_errors=True)

    def _touch(self, path):
        with open(path, 'w') as handle:
            handle.write('x')

    def test_heuristic_picks_earliest_sx_strictly_after_tracker_time(self):
        from MediBot import process_csvs

        self._touch(os.path.join(self.target, 'SX_CSV_20260114_143000_000001.csv'))
        self._touch(os.path.join(self.target, 'SX_CSV_20260114_143500_000001.csv'))
        idx = process_csvs._default_intake_index()
        key = process_csvs._normalize_csv_intake_key(
            'personal_68_20260114_143204_156738.csv'
        )
        idx['entries'][key] = {
            'downloaded_name': 'personal_68_20260114_143204_156738.csv',
            'current': None,
            'history': [],
        }
        stats = process_csvs.apply_sx_heuristic_backfill(
            idx, '', self.target, self.storage, cold_start=True
        )
        self.assertEqual(stats.get('inferred'), 1)
        self.assertEqual(stats.get('skipped_unparsed'), 0)
        self.assertEqual(stats.get('backfill_mode'), 'full_seed')
        cur = idx['entries'][key]['current']
        self.assertEqual(cur['target_basename'], 'SX_CSV_20260114_143500_000001.csv')
        self.assertTrue(cur.get('inferred_mapping'))
        self.assertEqual(cur.get('inference_rule'), 'next_sx_after_tracker_timestamp')

    def test_heuristic_pairs_multiple_tracker_entries_and_consumes_sx_once(self):
        from MediBot import process_csvs

        for name in (
                'SX_CSV_20260114_143010_000001.csv',
                'SX_CSV_20260114_143020_000001.csv'):
            self._touch(os.path.join(self.target, name))
        idx = process_csvs._default_intake_index()
        tracker_names = [
            'personal_1_20260114_143000_000000.csv',
            'personal_2_20260114_143010_000000.csv',
            'personal_3_20260114_143015_000000.csv',
        ]
        for name in tracker_names:
            key = process_csvs._normalize_csv_intake_key(name)
            idx['entries'][key] = {
                'downloaded_name': name,
                'current': None,
                'history': [],
            }

        stats = process_csvs.apply_sx_heuristic_backfill(
            idx, '', self.target, self.storage, cold_start=True
        )

        self.assertEqual(stats.get('inferred'), 2)
        self.assertEqual(stats.get('skipped_no_sx'), 1)
        assigned = []
        for name in tracker_names:
            key = process_csvs._normalize_csv_intake_key(name)
            cur = idx['entries'][key].get('current')
            if cur:
                assigned.append(cur.get('target_basename'))
        self.assertEqual(
            assigned,
            ['SX_CSV_20260114_143010_000001.csv', 'SX_CSV_20260114_143020_000001.csv'],
        )
        self.assertEqual(len(set(assigned)), len(assigned))

    def test_heuristic_skips_unparseable_tracker_basename(self):
        from MediBot import process_csvs

        self._touch(os.path.join(self.target, 'SX_CSV_20260114_143500_000001.csv'))
        idx = process_csvs._default_intake_index()
        key = process_csvs._normalize_csv_intake_key('nodate.csv')
        idx['entries'][key] = {
            'downloaded_name': 'nodate.csv',
            'current': None,
            'history': [],
        }
        stats = process_csvs.apply_sx_heuristic_backfill(
            idx, '', self.target, self.storage, cold_start=False
        )
        self.assertEqual(stats.get('inferred'), 0)
        self.assertEqual(stats.get('skipped_unparsed'), 1)
        self.assertEqual(stats.get('backfill_mode'), 'incremental')
        self.assertIsNone(idx['entries'][key].get('current'))

    def test_heuristic_skips_when_no_sx_after_tracker_time(self):
        from MediBot import process_csvs

        self._touch(os.path.join(self.target, 'SX_CSV_20260114_143000_000001.csv'))
        idx = process_csvs._default_intake_index()
        key = process_csvs._normalize_csv_intake_key(
            'x_20260114_143500_000000.csv'
        )
        idx['entries'][key] = {
            'downloaded_name': 'x_20260114_143500_000000.csv',
            'current': None,
            'history': [],
        }
        stats = process_csvs.apply_sx_heuristic_backfill(
            idx, '', self.target, self.storage
        )
        self.assertEqual(stats.get('inferred'), 0)
        self.assertEqual(stats.get('skipped_no_sx'), 1)
        self.assertEqual(stats.get('backfill_mode'), 'incremental')


class CsvIntakeWizardReportTests(unittest.TestCase):
    def test_format_csv_intake_wizard_report_lines(self):
        from MediBot import process_csvs

        idx = process_csvs._default_intake_index()
        idx['entries']['a.csv'] = {
            'downloaded_name': 'A.csv',
            'current': {
                'target_basename': 'SX_CSV_1.csv',
                'status': 'mapped',
            },
            'history': [{}],
        }
        st = {
            'phase': 'started',
            'started_at': 1,
            'completed_at': 2,
            'stats': {
                'mapped_current': 1,
                'no_current_mapping': 0,
                'current_present_in_source': 0,
                'current_present_in_target': 1,
                'history_records_total': 1,
                'downloaded_tracker_count': 1,
            },
        }
        lines = process_csvs.format_csv_intake_wizard_report(idx, st, max_rows=10)
        self.assertTrue(any('A.csv' in ln for ln in lines))
        self.assertTrue(any('SX_CSV_1.csv' in ln for ln in lines))

    def test_format_report_marks_inferred_status(self):
        from MediBot import process_csvs

        idx = process_csvs._default_intake_index()
        idx['entries']['z.csv'] = {
            'downloaded_name': 'z.csv',
            'current': {
                'target_basename': 'SX_CSV_x.csv',
                'status': 'mapped',
                'inferred_mapping': True,
            },
            'history': [],
        }
        lines = process_csvs.format_csv_intake_wizard_report(idx, {}, max_rows=10)
        self.assertTrue(any('inferred' in ln for ln in lines))


class CsvIntakeIndexTests(unittest.TestCase):
    def setUp(self):
        import tempfile

        self.tmp = tempfile.mkdtemp()
        self.source = os.path.join(self.tmp, 'src')
        self.target = os.path.join(self.tmp, 'tgt')
        self.storage = os.path.join(self.tmp, 'storage')
        os.makedirs(self.source)
        os.makedirs(self.target)
        os.makedirs(self.storage)
        self.config_path = os.path.join(self.tmp, 'config.json')
        _write_json(
            self.config_path,
            {
                'CSV_FILE_PATH': '',
                'MediLink_Config': {'local_storage_path': self.storage},
            },
        )

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmp, ignore_errors=True)

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    def test_creates_index_and_maps_csv(self, _cache, _tracker):
        from MediBot import process_csvs

        csv_path = os.path.join(self.source, 'daily.csv')
        _write_csv(csv_path)
        rc = process_csvs.process_csv(
            self.source,
            self.target,
            self.config_path,
            local_storage_path=self.storage,
            silent=True,
        )
        self.assertEqual(rc, 0)
        idx_path = os.path.join(self.storage, process_csvs.CSV_INTAKE_INDEX_FILENAME)
        st_path = os.path.join(self.storage, process_csvs.CSV_INTAKE_STATUS_FILENAME)
        self.assertTrue(os.path.isfile(idx_path))
        self.assertTrue(os.path.isfile(st_path))
        with open(idx_path, 'r') as handle:
            data = json.load(handle)
        key = process_csvs._normalize_csv_intake_key('daily.csv')
        self.assertIn(key, data.get('entries', {}))
        cur = data['entries'][key].get('current') or {}
        self.assertTrue(cur.get('target_basename', '').startswith('SX_CSV_'))
        self.assertEqual(cur.get('source_basename'), 'daily.csv')
        self.assertFalse(os.path.exists(os.path.join(self.storage, process_csvs.CSV_WORKFLOW_LOCK_FILENAME)))

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    def test_busy_workflow_lock_blocks_second_processor(self, _cache, _tracker):
        from MediBot import process_csvs

        csv_path = os.path.join(self.source, 'daily.csv')
        _write_csv(csv_path)
        lock_path = os.path.join(self.storage, process_csvs.CSV_WORKFLOW_LOCK_FILENAME)
        _write_json(lock_path, {
            'pid': os.getpid(),
            'created_at': 1,
            'writer': 'process_csvs',
            'artifact': 'csv_processing_workflow',
        })
        old_wait = process_csvs._CSV_WORKFLOW_LOCK_WAIT_SEC
        try:
            process_csvs._CSV_WORKFLOW_LOCK_WAIT_SEC = 0
            rc = process_csvs.process_csv(
                self.source,
                self.target,
                self.config_path,
                local_storage_path=self.storage,
                silent=True,
            )
        finally:
            process_csvs._CSV_WORKFLOW_LOCK_WAIT_SEC = old_wait
            if os.path.exists(lock_path):
                os.remove(lock_path)
        self.assertEqual(rc, 1)
        self.assertTrue(os.path.exists(csv_path))

    def test_release_workflow_lock_keeps_file_without_matching_pid(self):
        from MediBot import process_csvs

        lock_path = os.path.join(self.storage, process_csvs.CSV_WORKFLOW_LOCK_FILENAME)
        foreign_pid = 999999001
        _write_json(lock_path, {
            'pid': foreign_pid,
            'created_at': 1,
            'writer': 'process_csvs',
            'artifact': 'csv_processing_workflow',
        })
        process_csvs._release_csv_workflow_lock(lock_path)
        self.assertTrue(os.path.exists(lock_path))

    def test_release_workflow_lock_no_pid_key_does_not_remove(self):
        from MediBot import process_csvs

        lock_path = os.path.join(self.storage, process_csvs.CSV_WORKFLOW_LOCK_FILENAME)
        _write_json(lock_path, {'writer': 'process_csvs', 'artifact': 'csv_processing_workflow'})
        process_csvs._release_csv_workflow_lock(lock_path)
        self.assertTrue(os.path.exists(lock_path))

    def test_release_workflow_lock_removes_when_pid_matches(self):
        from MediBot import process_csvs

        lock_path = os.path.join(self.storage, process_csvs.CSV_WORKFLOW_LOCK_FILENAME)
        _write_json(lock_path, {
            'pid': os.getpid(),
            'created_at': 1,
            'writer': 'process_csvs',
            'artifact': 'csv_processing_workflow',
        })
        process_csvs._release_csv_workflow_lock(lock_path)
        self.assertFalse(os.path.exists(lock_path))

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    def test_appends_history_on_second_intake_same_basename(self, _cache, _tracker):
        from MediBot import process_csvs

        _write_csv(os.path.join(self.source, 'daily.csv'))
        self.assertEqual(
            0,
            process_csvs.process_csv(
                self.source,
                self.target,
                self.config_path,
                local_storage_path=self.storage,
                silent=True,
            ),
        )
        _write_csv(os.path.join(self.source, 'daily.csv'))
        self.assertEqual(
            0,
            process_csvs.process_csv(
                self.source,
                self.target,
                self.config_path,
                local_storage_path=self.storage,
                silent=True,
            ),
        )
        idx_path = os.path.join(self.storage, process_csvs.CSV_INTAKE_INDEX_FILENAME)
        with open(idx_path, 'r') as handle:
            data = json.load(handle)
        key = process_csvs._normalize_csv_intake_key('daily.csv')
        ent = data['entries'][key]
        self.assertGreaterEqual(len(ent.get('history', [])), 1)

    def test_reconcile_marks_target_missing(self):
        from MediBot import process_csvs

        idx = process_csvs._default_intake_index()
        key = process_csvs._normalize_csv_intake_key('x.csv')
        idx['entries'][key] = {
            'downloaded_name': 'x.csv',
            'first_seen_at_utc': 1,
            'last_seen_at_utc': 1,
            'history': [],
            'current': {
                'source_path': os.path.join(self.source, 'x.csv'),
                'target_path': os.path.join(self.target, 'SX_CSV_1.csv'),
                'source_basename': 'x.csv',
                'target_basename': 'SX_CSV_1.csv',
                'present_in_source': True,
                'present_in_target': True,
                'last_process_iteration': 1,
                'status': 'mapped',
                'updated_at_utc': 1,
            },
        }
        _write_csv(os.path.join(self.target, 'SX_CSV_1.csv'))
        process_csvs._reconcile_intake_index_entries(idx, self.source, self.target)
        self.assertEqual(idx['entries'][key]['current']['status'], 'mapped')
        os.remove(os.path.join(self.target, 'SX_CSV_1.csv'))
        process_csvs._reconcile_intake_index_entries(idx, self.source, self.target)
        self.assertEqual(idx['entries'][key]['current']['status'], 'target_only')

    @patch('MediBot.process_csvs.add_downloaded_email', return_value=True)
    @patch('MediBot.process_csvs.build_deductible_cache', return_value=0)
    @patch('MediBot.process_csvs._save_csv_intake_index')
    def test_intake_continues_when_index_write_fails(self, mock_save, _cache, _tracker):
        from MediBot import process_csvs

        mock_save.return_value = False
        _write_csv(os.path.join(self.source, 'daily.csv'))
        rc = process_csvs.process_csv(
            self.source,
            self.target,
            self.config_path,
            local_storage_path=self.storage,
            silent=True,
        )
        self.assertEqual(rc, 0)
        self.assertGreaterEqual(mock_save.call_count, 1)


class ParseSxCsvDatetimeTests(unittest.TestCase):
    """_parse_sx_csv_datetime: variable-length fractional seconds -> microseconds."""

    def test_short_fraction_right_padded(self):
        from datetime import datetime

        from MediBot import process_csvs

        dt5 = process_csvs._parse_sx_csv_datetime('SX_CSV_20260114_143000_5.csv')
        self.assertEqual(dt5, datetime(2026, 1, 14, 14, 30, 0, 500000))
        dt50 = process_csvs._parse_sx_csv_datetime('SX_CSV_20260114_143000_50.csv')
        self.assertEqual(dt50, datetime(2026, 1, 14, 14, 30, 0, 500000))
        dt123 = process_csvs._parse_sx_csv_datetime('SX_CSV_20260114_143000_123.csv')
        self.assertEqual(dt123, datetime(2026, 1, 14, 14, 30, 0, 123000))

    def test_six_digit_fraction_unchanged(self):
        from datetime import datetime

        from MediBot import process_csvs

        dt = process_csvs._parse_sx_csv_datetime('SX_CSV_20260114_143000_000001.csv')
        self.assertEqual(dt, datetime(2026, 1, 14, 14, 30, 0, 1))

    def test_long_fraction_truncated_to_six_digits(self):
        from datetime import datetime

        from MediBot import process_csvs

        dt = process_csvs._parse_sx_csv_datetime('SX_CSV_20260114_143000_123456789.csv')
        self.assertEqual(dt, datetime(2026, 1, 14, 14, 30, 0, 123456))


if __name__ == '__main__':
    unittest.main()
