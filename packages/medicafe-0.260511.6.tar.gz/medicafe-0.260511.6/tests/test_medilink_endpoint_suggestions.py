#!/usr/bin/env python
"""
Focused tests for feature-aware suggested endpoint selection in MediLink_PatientProcessor.
"""

import os
import sys
import importlib
from importlib.machinery import SourceFileLoader
import unittest
from unittest.mock import patch


PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
MEDILINK_ROOT = os.path.join(PROJECT_ROOT, 'MediLink')
if MEDILINK_ROOT not in sys.path:
    sys.path.insert(0, MEDILINK_ROOT)


class TestMediLinkEndpointSuggestions(unittest.TestCase):
    def _load_source_module(self, module_name, module_path):
        try:
            return importlib.import_module(module_name)
        except ImportError:
            return SourceFileLoader(module_name, module_path).load_module()

    def _load_patient_processor_module(self):
        if MEDILINK_ROOT not in sys.path:
            sys.path.insert(0, MEDILINK_ROOT)
        if 'MediLink_DataMgmt' not in sys.modules:
            self._load_source_module('MediLink_DataMgmt', os.path.join(MEDILINK_ROOT, 'MediLink_DataMgmt.py'))
        if 'MediLink_Display_Utils' not in sys.modules:
            self._load_source_module('MediLink_Display_Utils', os.path.join(MEDILINK_ROOT, 'MediLink_Display_Utils.py'))

        module_name = 'MediLink_PatientProcessor'
        if module_name in sys.modules:
            return sys.modules[module_name]
        return self._load_source_module(module_name, os.path.join(MEDILINK_ROOT, 'MediLink_PatientProcessor.py'))

    def _build_config(self):
        return {
            'MediLink_Config': {
                'local_claims_path': '',
                'endpoints': {
                    'OPTUMAI': {},
                    'UHCAPI': {},
                    'AVAILITY': {},
                }
            }
        }

    def _build_parsed_data(self, insurance_name):
        return {
            'INAME': insurance_name,
            'CODEA': '00145',
            'DATE': '20260331',
            'CHART': 'MACRO000',
            'PATID': '12345',
            'FIRST': 'JOHN',
            'MIDDLE': '',
            'LAST': 'DOE',
            'AMOUNT': '100.00',
    }

    def test_optumai_legacy_suggestion_is_overridden_to_uhcapi_when_submit_not_supported(self):
        patient_processor_mod = self._load_patient_processor_module()
        extract_and_suggest_endpoint = patient_processor_mod.extract_and_suggest_endpoint

        insurance_name = 'UHC GLOBAL    IMG     30526'

        crosswalk = {
            'payer_id': {
                'USN01': {
                    'medisoft_id': ['487'],
                    'endpoint': 'OPTUMAI',
                }
            },
            'endpoint_payer_ids': {
                'UHCAPI': ['USN01']
            },
            'optum_payer_list': {
                'payers': {
                    'USN01': {
                        'eligibility': False,
                        'search_claim': False,
                        'submit_with_precheck': False,
                        'search_277ca': False,
                    }
                }
            }
        }

        with patch.object(patient_processor_mod, 'load_insurance_data_from_mains', return_value={insurance_name: 487}):
            with patch.object(patient_processor_mod.MediLink_DataMgmt, 'read_fixed_width_data', return_value=[('a', 'b', 'c', 'd', 'e')]):
                with patch.object(patient_processor_mod.MediLink_DataMgmt, 'parse_fixed_width_data', return_value=self._build_parsed_data(insurance_name)):
                    result = extract_and_suggest_endpoint('fake.dat', self._build_config(), crosswalk)

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].get('suggested_endpoint'), 'UHCAPI')

    def test_optumai_suggestion_stays_optumai_when_submit_supported(self):
        patient_processor_mod = self._load_patient_processor_module()
        extract_and_suggest_endpoint = patient_processor_mod.extract_and_suggest_endpoint

        insurance_name = 'UNITED HEALTHCARE'

        crosswalk = {
            'payer_id': {
                '87726': {
                    'medisoft_id': ['999'],
                    'endpoint': 'OPTUMAI',
                }
            },
            'endpoint_payer_ids': {
                'UHCAPI': ['87726']
            },
            'optum_payer_list': {
                'payers': {
                    '87726': {
                        'eligibility': True,
                        'search_claim': True,
                        'submit_with_precheck': True,
                        'search_277ca': True,
                    }
                }
            }
        }

        with patch.object(patient_processor_mod, 'load_insurance_data_from_mains', return_value={insurance_name: 999}):
            with patch.object(patient_processor_mod.MediLink_DataMgmt, 'read_fixed_width_data', return_value=[('a', 'b', 'c', 'd', 'e')]):
                with patch.object(patient_processor_mod.MediLink_DataMgmt, 'parse_fixed_width_data', return_value=self._build_parsed_data(insurance_name)):
                    result = extract_and_suggest_endpoint('fake.dat', self._build_config(), crosswalk)

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].get('suggested_endpoint'), 'OPTUMAI')

    def test_persisted_uhcapi_choice_is_not_repromoted_to_optumai(self):
        patient_processor_mod = self._load_patient_processor_module()
        extract_and_suggest_endpoint = patient_processor_mod.extract_and_suggest_endpoint

        insurance_name = 'UNITED HEALTHCARE OVERRIDE'

        crosswalk = {
            'payer_id': {
                '87726': {
                    'medisoft_id': ['1001'],
                    'endpoint': 'UHCAPI',
                }
            },
            'endpoint_payer_ids': {
                'UHCAPI': ['87726']
            },
            'optum_payer_list': {
                'payers': {
                    '87726': {
                        'eligibility': True,
                        'search_claim': True,
                        'submit_with_precheck': True,
                        'search_277ca': True,
                    }
                }
            }
        }

        with patch.object(patient_processor_mod, 'load_insurance_data_from_mains', return_value={insurance_name: 1001}):
            with patch.object(patient_processor_mod.MediLink_DataMgmt, 'read_fixed_width_data', return_value=[('a', 'b', 'c', 'd', 'e')]):
                with patch.object(patient_processor_mod.MediLink_DataMgmt, 'parse_fixed_width_data', return_value=self._build_parsed_data(insurance_name)):
                    result = extract_and_suggest_endpoint('fake.dat', self._build_config(), crosswalk)

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].get('suggested_endpoint'), 'UHCAPI')

    def test_sidecar_claim_submission_override_is_used_for_suggestion(self):
        patient_processor_mod = self._load_patient_processor_module()
        extract_and_suggest_endpoint = patient_processor_mod.extract_and_suggest_endpoint

        insurance_name = 'UNITED HEALTHCARE ROUTING OVERRIDE'

        crosswalk = {
            'payer_id': {
                '87726': {
                    'medisoft_id': ['1002'],
                    'endpoint': 'OPTUMAI',
                }
            },
            'routing_overrides': {
                'payers': {
                    '87726': {
                        'claim_submission': {
                            'preferred_endpoint': 'UHCAPI',
                            'source': 'user',
                        }
                    }
                }
            },
            'endpoint_payer_ids': {
                'UHCAPI': ['87726']
            },
            'optum_payer_list': {
                'payers': {
                    '87726': {
                        'eligibility': True,
                        'search_claim': True,
                        'submit_with_precheck': True,
                        'search_277ca': True,
                    }
                }
            }
        }

        with patch.object(patient_processor_mod, 'load_insurance_data_from_mains', return_value={insurance_name: 1002}):
            with patch.object(patient_processor_mod.MediLink_DataMgmt, 'read_fixed_width_data', return_value=[('a', 'b', 'c', 'd', 'e')]):
                with patch.object(patient_processor_mod.MediLink_DataMgmt, 'parse_fixed_width_data', return_value=self._build_parsed_data(insurance_name)):
                    result = extract_and_suggest_endpoint('fake.dat', self._build_config(), crosswalk)

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].get('suggested_endpoint'), 'UHCAPI')
        self.assertEqual(result[0].get('primary_payer_id'), '87726')

    def test_patient_name_omits_blank_padded_middle_without_double_spaces(self):
        patient_processor_mod = self._load_patient_processor_module()
        extract_and_suggest_endpoint = patient_processor_mod.extract_and_suggest_endpoint

        insurance_name = 'UNITED HEALTHCARE NAME'
        parsed_data = self._build_parsed_data(insurance_name)
        parsed_data['FIRST'] = '  JOHN  '
        parsed_data['MIDDLE'] = '   '
        parsed_data['LAST'] = '  DOE  '

        crosswalk = {
            'payer_id': {
                '87726': {
                    'medisoft_id': ['1003'],
                    'endpoint': 'UHCAPI',
                }
            },
            'endpoint_payer_ids': {
                'UHCAPI': ['87726']
            }
        }

        with patch.object(patient_processor_mod, 'load_insurance_data_from_mains', return_value={insurance_name: 1003}):
            with patch.object(patient_processor_mod.MediLink_DataMgmt, 'read_fixed_width_data', return_value=[('a', 'b', 'c', 'd', 'e')]):
                with patch.object(patient_processor_mod.MediLink_DataMgmt, 'parse_fixed_width_data', return_value=parsed_data):
                    result = extract_and_suggest_endpoint('fake.dat', self._build_config(), crosswalk)

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0].get('patient_name'), 'JOHN DOE')
        self.assertNotIn('  ', result[0].get('patient_name'))


if __name__ == '__main__':
    unittest.main()
