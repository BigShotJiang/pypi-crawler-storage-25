# -*- coding: utf-8 -*-
from __future__ import print_function

import hashlib
import os
import shutil
import tempfile
import unittest

from MediCafe.local_index_utils import (
    file_signature,
    list_report_files,
    pair_by_next_greater,
    path_key,
    stream_sha256,
)


class LocalIndexUtilsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_path_key_normalizes_to_absolute_key(self):
        child = os.path.join(self.tmp, "a", "..", "file.txt")
        key = path_key(child)
        self.assertEqual(key, os.path.normcase(os.path.abspath(os.path.normpath(child))))

    def test_missing_file_signature_is_none(self):
        self.assertIsNone(file_signature(os.path.join(self.tmp, "missing.txt")))

    def test_stream_sha256_matches_hashlib(self):
        path = os.path.join(self.tmp, "payload.bin")
        payload = (b"abc123" * 20000) + b"tail"
        with open(path, "wb") as handle:
            handle.write(payload)
        self.assertEqual(stream_sha256(path, chunk_size=17), hashlib.sha256(payload).hexdigest())

    def test_pair_by_next_greater_consumes_successors_once(self):
        left = [("a", 1), ("b", 3), ("c", 5)]
        right = [("r1", 2), ("r2", 4)]
        pairs = pair_by_next_greater(left, right)
        self.assertEqual(pairs[0][1][0], "r1")
        self.assertEqual(pairs[1][1][0], "r2")
        self.assertIsNone(pairs[2][1])

    def test_list_report_files_returns_files_with_metadata_only(self):
        path_a = os.path.join(self.tmp, "a.json")
        path_b = os.path.join(self.tmp, "b.txt")
        os.makedirs(os.path.join(self.tmp, "subdir"))
        with open(path_a, "w") as handle:
            handle.write("a")
        with open(path_b, "w") as handle:
            handle.write("b")
        rows = list_report_files(self.tmp)
        names = [row.get("name") for row in rows]
        self.assertEqual(names, ["a.json", "b.txt"])
        for row in rows:
            self.assertTrue(os.path.isfile(row.get("path")))
            self.assertTrue(row.get("mtime") >= 0)


if __name__ == "__main__":
    unittest.main()
