import io
import json
import os
import shutil
import sys
import tempfile
import unittest


current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
medilink_dir = os.path.join(parent_dir, 'MediLink')
if medilink_dir not in sys.path:
    sys.path.insert(0, medilink_dir)

import MediLink_Down as down  # noqa: E402
try:
    from MediLink_RemittanceYieldTelemetry import new_yield_report  # noqa: E402
except ImportError:
    from MediLink.MediLink_RemittanceYieldTelemetry import new_yield_report  # noqa: E402


class PatchMixin(object):
    def setUp(self):
        self._patches = []

    def tearDown(self):
        while self._patches:
            obj, name, old = self._patches.pop()
            setattr(obj, name, old)

    def patch_attr(self, obj, name, value):
        old = getattr(obj, name)
        setattr(obj, name, value)
        self._patches.append((obj, name, old))


class TestRemittanceParserYieldTelemetry(PatchMixin, unittest.TestCase):
    def _tmpdir(self):
        path = tempfile.mkdtemp()
        self.addCleanup(lambda: shutil.rmtree(path, ignore_errors=True))
        return path

    def _read_json(self, path):
        with io.open(path, 'r', encoding='utf-8') as handle:
            return json.load(handle)

    def _read_all_text(self, root):
        chunks = []
        for base, _dirs, names in os.walk(root):
            for name in names:
                path = os.path.join(base, name)
                with io.open(path, 'r', encoding='utf-8') as handle:
                    chunks.append(handle.read())
        return '\n'.join(chunks)

    def test_report_writes_latest_timestamped_and_phi_light_event(self):
        storage = self._tmpdir()
        source_path = os.path.join(storage, 'Jane_Doe_CLM12345.era')
        with open(source_path, 'wb') as handle:
            handle.write(b'CLP*CLM12345*1*100~NM1*QC*1*DOE*JANE~')

        report = new_yield_report(storage, run_id='yield_test_001', emit_events=True)
        report.record_download_seen(source_path, 'payer_endpoint_jane')
        report.record_move_supported(source_path, 'payer_endpoint_jane')
        report.record_move_success(source_path, source_path, 'payer_endpoint_jane')
        report.record_decode_selected(source_path, 'ERA', 'payer_endpoint_jane')
        report.record_decode_result(source_path, 2, 'ERA', 'payer_endpoint_jane')
        report.record_parser_metrics(
            source_path,
            {'malformed_segment_count': 1},
            {'duplicate_suppressed_count': 0, 'missing_key_suppressed_count': 0},
            'payer_endpoint_jane',
        )
        report.record_ingest_result(
            source_path,
            True,
            2,
            None,
            'payer_endpoint_jane',
            {
                'matched_rows': 1,
                'unmatched_rows': 1,
                'parser_named_rows': 1,
                'sourceBlankPatientNames': 1,
                'patientNamesBackfilled': 1,
                'patientNamesStillBlank': 0,
            },
            1,
            1,
        )
        report.record_endpoint_result('payer_endpoint_jane', {
            'transport': 'winscp',
            'status': 'processed',
            'reason': 'ok',
            'files_downloaded': 1,
            'records_found': 2,
            'files_translated': 1,
        })
        paths = report.write()

        self.assertTrue(os.path.exists(paths['json_path']))
        self.assertTrue(os.path.exists(paths['txt_path']))
        self.assertTrue(os.path.exists(paths['latest_json_path']))
        self.assertTrue(os.path.exists(paths['latest_txt_path']))
        self.assertTrue(os.path.exists(paths['events_path']))

        payload = self._read_json(paths['latest_json_path'])
        self.assertEqual(payload.get('schema_version'), 1)
        self.assertEqual(payload.get('totals', {}).get('downloaded_files'), 1)
        self.assertEqual(payload.get('totals', {}).get('decoded_records'), 2)
        self.assertEqual(payload.get('totals', {}).get('endpoint_total'), 1)
        self.assertEqual(payload.get('totals', {}).get('endpoint_processed'), 1)
        self.assertEqual(payload.get('totals', {}).get('endpoint_winscp'), 1)
        self.assertEqual(payload.get('totals', {}).get('parser_malformed_segments'), 1)
        self.assertEqual(payload.get('totals', {}).get('matched_rows'), 1)
        self.assertEqual(payload.get('totals', {}).get('unmatched_rows'), 1)
        self.assertEqual(payload.get('totals', {}).get('patient_names_backfilled'), 1)
        self.assertEqual(payload.get('totals', {}).get('patient_names_still_blank'), 0)
        self.assertEqual(payload.get('totals', {}).get('missing_claim_number_rows'), 1)
        self.assertEqual(payload.get('totals', {}).get('fallback_correlated_missing_claim_rows'), 1)
        self.assertEqual(payload.get('files', [])[0].get('extension'), '.era')
        self.assertEqual(payload.get('files', [])[0].get('matched_rows'), 1)
        self.assertEqual(payload.get('files', [])[0].get('patient_names_backfilled'), 1)
        self.assertEqual(payload.get('endpoints', [])[0].get('status'), 'processed')
        self.assertTrue(payload.get('files', [])[0].get('checksum_prefix'))
        self.assertEqual(payload.get('files', [])[0].get('size_bytes'), os.path.getsize(source_path))

        rendered = self._read_all_text(os.path.join(storage, 'reports'))
        rendered += self._read_all_text(os.path.join(storage, 'telemetry'))
        self.assertNotIn('Jane', rendered)
        self.assertNotIn('DOE', rendered)
        self.assertNotIn('CLM12345', rendered)
        self.assertNotIn(source_path, rendered)
        self.assertNotIn('Jane_Doe_CLM12345.era', rendered)
        self.assertNotIn('payer_endpoint_jane', rendered)

    def test_zero_record_decode_counts_file_without_claim_or_patient_payload(self):
        storage = self._tmpdir()
        responses = os.path.join(storage, 'responses')
        os.makedirs(responses)
        path = os.path.join(responses, 'zero_records.dpt')
        with open(path, 'wb') as handle:
            handle.write(b'NO CLAIMS HERE')

        self.patch_attr(down, 'get_decode_extensions', None)
        self.patch_attr(down, 'process_decoded_file', lambda src, out, return_records=True: [])
        self.patch_attr(down, 'determine_file_type', lambda src: 'DPT')
        self.patch_attr(down, 'get_last_parse_telemetry', lambda file_type=None: {'malformed_segment_count': 2})
        self.patch_attr(down, 'get_last_format_telemetry', lambda file_type=None: {'duplicate_suppressed_count': 0, 'missing_key_suppressed_count': 0})
        self.patch_attr(down, 'ingest_decoded_records_to_canonical', None)
        self.patch_attr(down, 'write_jsonl', None)
        self.patch_attr(down, 'load_configuration', lambda: ({'MediLink_Config': {}}, None))

        report = new_yield_report(storage, run_id='zero_decode')
        records, translated = down.translate_files(
            [path],
            responses,
            storage,
            endpoint_key='endpoint_secret',
            silent=True,
            yield_report=report,
        )
        report.write()

        self.assertEqual(records, [])
        self.assertEqual(len(translated), 1)
        payload = self._read_json(os.path.join(storage, 'reports', 'remittance_parse_yield_latest.json'))
        totals = payload.get('totals', {})
        self.assertEqual(totals.get('decode_selected_files'), 1)
        self.assertEqual(totals.get('decode_zero_record_files'), 1)
        self.assertEqual(totals.get('decoded_records'), 0)
        self.assertEqual(totals.get('parser_malformed_segments'), 2)
        self.assertEqual(payload.get('files', [])[0].get('source_type'), 'DPT')

    def test_ingest_exception_records_exception_class_without_payload(self):
        storage = self._tmpdir()
        responses = os.path.join(storage, 'responses')
        os.makedirs(responses)
        path = os.path.join(responses, 'private_remit.era')
        with open(path, 'wb') as handle:
            handle.write(b'CLP*SECRETCLAIM*1*100~NM1*QC*1*DOE*JANE~')

        def fake_ingest(records, source_meta, lookups, log_fn=None, log_basename=''):
            raise RuntimeError('SECRETCLAIM Jane Doe raw message')

        writes = []

        self.patch_attr(down, 'get_decode_extensions', lambda: ['.era'])
        self.patch_attr(down, 'process_decoded_file', lambda src, out, return_records=True: [{'Claim #': 'SECRETCLAIM', 'Patient': 'Jane Doe'}])
        self.patch_attr(down, 'determine_file_type', lambda src: 'ERA')
        self.patch_attr(down, 'get_last_parse_telemetry', lambda file_type=None: {'malformed_segment_count': 0})
        self.patch_attr(down, 'get_last_format_telemetry', lambda file_type=None: {'duplicate_suppressed_count': 0, 'missing_key_suppressed_count': 0})
        self.patch_attr(down, 'ingest_decoded_records_to_canonical', fake_ingest)
        self.patch_attr(down, 'build_source_meta', lambda **kwargs: kwargs)
        self.patch_attr(down, 'build_crosswalk_lookups', lambda receipts_root: {})
        self.patch_attr(down, 'write_jsonl', lambda rows, path: writes.append((len(rows), os.path.basename(path))))
        self.patch_attr(down, 'load_configuration', lambda: ({'MediLink_Config': {'local_claims_path': ''}}, None))

        report = new_yield_report(storage, run_id='ingest_exception')
        records, translated = down.translate_files(
            [path],
            responses,
            storage,
            endpoint_key='endpoint_secret',
            silent=True,
            yield_report=report,
        )
        report.write()

        self.assertEqual(len(records), 1)
        self.assertEqual(len(translated), 1)
        self.assertTrue(writes)
        payload = self._read_json(os.path.join(storage, 'reports', 'remittance_parse_yield_latest.json'))
        file_row = payload.get('files', [])[0]
        self.assertEqual(payload.get('totals', {}).get('ingest_exception_files'), 1)
        self.assertEqual(file_row.get('ingest_status'), 'exception')
        self.assertIn('RuntimeError', file_row.get('error_classes', []))

        rendered = self._read_all_text(os.path.join(storage, 'reports'))
        self.assertNotIn('SECRETCLAIM', rendered)
        self.assertNotIn('Jane', rendered)
        self.assertNotIn('Doe', rendered)
        self.assertNotIn('raw message', rendered)
        self.assertNotIn('private_remit.era', rendered)

    def test_missing_and_unsupported_move_counters(self):
        storage = self._tmpdir()
        report = new_yield_report(storage, run_id='move_counters')
        self.patch_attr(down, 'translate_files', lambda files, output_directory, local_storage_path, endpoint_key=None, silent=False, yield_report=None: ([], []))

        records, translated = down.handle_files(
            storage,
            ['missing_supported.era', 'unsupported_upload.pdf'],
            endpoint_key='endpoint_secret',
            silent=True,
            yield_report=report,
        )
        report.write()

        self.assertEqual(records, [])
        self.assertEqual(translated, [])
        payload = self._read_json(os.path.join(storage, 'reports', 'remittance_parse_yield_latest.json'))
        totals = payload.get('totals', {})
        self.assertEqual(totals.get('downloaded_files'), 2)
        self.assertEqual(totals.get('supported_move_files'), 1)
        self.assertEqual(totals.get('missing_source_files'), 1)
        self.assertEqual(totals.get('unsupported_move_files'), 1)
        self.assertEqual(totals.get('moved_files'), 0)

        rendered = self._read_all_text(os.path.join(storage, 'reports'))
        self.assertNotIn('missing_supported.era', rendered)
        self.assertNotIn('unsupported_upload.pdf', rendered)
        self.assertNotIn('endpoint_secret', rendered)


if __name__ == '__main__':
    unittest.main()
