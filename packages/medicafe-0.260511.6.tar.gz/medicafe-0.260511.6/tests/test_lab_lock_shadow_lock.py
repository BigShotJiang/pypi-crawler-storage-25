# -*- coding: utf-8 -*-
"""Tests for lab shadow.lock acquisition (orphan/corrupt recovery)."""
from __future__ import print_function

import ctypes
import inspect
import json
import os
import shutil
import sys
import tempfile
import unittest

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
UM = os.path.join(REPO_ROOT, 'scripts', 'unified_model')
if UM not in sys.path:
    sys.path.insert(0, UM)

import lab_lock

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch


class TestShadowLockRecoverCorrupt(unittest.TestCase):
    def setUp(self):
        self.lab = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.lab, ignore_errors=True)

    def test_acquire_after_empty_lock_file(self):
        lock_p = os.path.join(self.lab, 'shadow.lock')
        with open(lock_p, 'w') as f:
            f.write('')
        self.assertTrue(lab_lock.acquire_lock(self.lab))
        try:
            self.assertTrue(os.path.exists(lock_p))
        finally:
            lab_lock.release_lock(self.lab)

    def test_acquire_after_lock_missing_pid_line(self):
        lock_p = os.path.join(self.lab, 'shadow.lock')
        with open(lock_p, 'w') as f:
            f.write('heartbeat_at_utc=2020-01-01T00:00:00Z\n')
        self.assertTrue(lab_lock.acquire_lock(self.lab))
        try:
            self.assertTrue(os.path.exists(lock_p))
        finally:
            lab_lock.release_lock(self.lab)

    def test_pid_running_windows_does_not_call_os_kill(self):
        class FakeKernel32(object):
            STILL_ACTIVE = 259

            def __init__(self):
                self.open_calls = []
                self.close_calls = []

            def OpenProcess(self, access, inherit, pid):
                self.open_calls.append((access, inherit, pid))
                return 123

            def GetExitCodeProcess(self, handle, exit_code_ptr):
                try:
                    exit_code_ptr.contents.value = 259
                except AttributeError:
                    exit_code_ptr._obj.value = 259
                return 1

            def CloseHandle(self, handle):
                self.close_calls.append(handle)
                return True

            def GetLastError(self):
                return 0

        fake_kernel = FakeKernel32()
        import types
        fake_windll = types.SimpleNamespace(kernel32=fake_kernel)
        with patch.object(lab_lock.os, 'name', 'nt'):
            with patch.object(ctypes, 'windll', fake_windll, create=True):
                with patch.object(lab_lock.os, 'kill') as kill_mock:
                    self.assertTrue(lab_lock._pid_running(456))

        self.assertEqual(kill_mock.call_count, 0)
        self.assertEqual(fake_kernel.open_calls[0][0], 0x1000)
        self.assertEqual(fake_kernel.open_calls[0][2], 456)
        self.assertEqual(fake_kernel.close_calls, [123])

    def test_pid_running_windows_access_denied_assumes_live(self):
        """OpenProcess may fail with ERROR_ACCESS_DENIED while the PID is still running."""

        class FakeKernel32(object):
            def OpenProcess(self, access, inherit, pid):
                return 0

            def GetLastError(self):
                return 5

        class FakeCtypes(object):
            pass

        fake_kernel = FakeKernel32()
        fake_ctypes = FakeCtypes()
        fake_ctypes.windll = FakeCtypes()
        fake_ctypes.windll.kernel32 = fake_kernel

        with patch.object(lab_lock.os, 'name', 'nt'):
            with patch.dict('sys.modules', {'ctypes': fake_ctypes}):
                with patch.object(lab_lock.os, 'kill') as kill_mock:
                    self.assertTrue(lab_lock._pid_running(999))

        self.assertEqual(kill_mock.call_count, 0)

    def test_replace_safe_write_creates_parent_without_exist_ok(self):
        target = os.path.join(self.lab, 'nested', 'diagnostics_state.json')
        real_makedirs = lab_lock.os.makedirs
        calls = []

        def fake_makedirs(path):
            calls.append(path)
            return real_makedirs(path)

        with patch.object(lab_lock.os, 'makedirs', fake_makedirs):
            lab_lock.replace_safe_write(target, {'ok': True})

        self.assertEqual(calls, [os.path.dirname(target)])
        with open(target, 'r') as handle:
            self.assertEqual(json.load(handle), {'ok': True})

    def test_ensure_dir_treats_errno_183_as_race_when_directory_exists(self):
        """Windows-style 'already exists' after concurrent mkdir must not abort writes."""
        nested = os.path.join(self.lab, 'nested183')

        def fake_makedirs(path):
            os.mkdir(path)
            err = OSError(183, 'Cannot create a file when that file already exists')
            err.errno = 183
            raise err

        with patch.object(lab_lock.os, 'makedirs', fake_makedirs):
            lab_lock._ensure_dir(nested)

        self.assertTrue(os.path.isdir(nested))

    def test_replace_safe_write_falls_back_to_rename_when_replace_fails(self):
        target = os.path.join(self.lab, 'run_cursor.json')
        with open(target, 'w') as handle:
            handle.write('old')

        with patch.object(lab_lock.os, 'replace', side_effect=OSError(13, 'permission denied')) as replace_mock:
            lab_lock.replace_safe_write(target, {'cursor': 'new'})

        self.assertEqual(replace_mock.call_count, 1)
        self.assertFalse(os.path.exists(target + '.tmp'))
        with open(target, 'r') as handle:
            self.assertEqual(json.load(handle), {'cursor': 'new'})

    def test_replace_safe_write_bytes_falls_back_when_replace_unavailable(self):
        target = os.path.join(self.lab, 'snapshot.bin')
        with open(target, 'wb') as handle:
            handle.write(b'old')

        with patch.object(lab_lock.os, 'replace', None):
            lab_lock.replace_safe_write_bytes(target, b'new-bytes')

        self.assertFalse(os.path.exists(target + '.tmp'))
        with open(target, 'rb') as handle:
            self.assertEqual(handle.read(), b'new-bytes')

    def test_replace_safe_write_restores_existing_file_when_fallback_rename_fails(self):
        target = os.path.join(self.lab, 'run_cursor_restore.json')
        with open(target, 'w') as handle:
            handle.write('old-content')
        real_rename = lab_lock.os.rename

        def fake_rename(src, dst):
            if src == target + '.tmp':
                raise OSError(13, 'rename blocked')
            return real_rename(src, dst)

        with patch.object(lab_lock.os, 'replace', side_effect=OSError(13, 'permission denied')):
            with patch.object(lab_lock.os, 'rename', fake_rename):
                with self.assertRaises(OSError):
                    lab_lock.replace_safe_write(target, {'cursor': 'new'})

        self.assertFalse(os.path.exists(target + '.tmp'))
        self.assertFalse(os.path.exists(target + '.bak.{0}'.format(os.getpid())))
        with open(target, 'r') as handle:
            self.assertEqual(handle.read(), 'old-content')

    def test_replace_safe_write_succeeds_when_backup_remove_fails_after_promote(self):
        """Backup delete must not fail the write after tmp was already renamed to path."""
        target = os.path.join(self.lab, 'state_after_promote.json')
        with open(target, 'w') as handle:
            handle.write('prior')

        real_remove = lab_lock.os.remove
        backup_name = target + '.bak.{0}'.format(os.getpid())

        def fake_remove(p):
            if p == backup_name:
                raise OSError(13, 'access denied')
            return real_remove(p)

        with patch.object(lab_lock.os, 'replace', side_effect=OSError(13, 'permission denied')):
            with patch.object(lab_lock.os, 'remove', fake_remove):
                lab_lock.replace_safe_write(target, {'committed': True})

        self.assertFalse(os.path.exists(target + '.tmp'))
        with open(target, 'r') as handle:
            self.assertEqual(json.load(handle), {'committed': True})
        self.assertTrue(os.path.isfile(backup_name))

    def test_lab_lock_source_avoids_python35_exist_ok_keyword(self):
        source = inspect.getsource(lab_lock)
        self.assertNotIn('exist_ok=', source)


if __name__ == '__main__':
    unittest.main()
