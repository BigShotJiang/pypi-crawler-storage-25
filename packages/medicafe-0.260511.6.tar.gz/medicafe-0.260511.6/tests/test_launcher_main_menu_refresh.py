import io
from contextlib import redirect_stdout


def test_blank_main_menu_choice_refreshes_without_invalid_or_dispatch():
    from MediCafe.launcher import MediCafeOrchestrator

    orchestrator = MediCafeOrchestrator.__new__(MediCafeOrchestrator)
    orchestrator.update_available_version = None
    orchestrator._update_notification_shown = False
    orchestrator.medicafe_version = 'test'
    orchestrator.startup_notices = []

    choices = ['', 'exit']
    dispatches = []
    notices = []
    renders = []

    orchestrator._clear_console = lambda: None
    orchestrator._print_version_details = lambda: None
    orchestrator._print_welcome_block = lambda: None
    orchestrator._try_print_background_support_send_notice = lambda: None
    orchestrator._print_background_support_send_status_banner = lambda: None
    orchestrator._maybe_offer_startup_assistant = lambda: False
    orchestrator._print_main_menu_options = lambda: renders.append('menu')
    orchestrator._get_menu_choice = lambda: choices.pop(0)
    orchestrator._record_notice = lambda level, message, print_console=True: notices.append((level, message))
    orchestrator._confirm_exit_with_active_support_send_jobs = lambda: True
    orchestrator._mark_clean_exit = lambda: None
    orchestrator._join_payer_list_thread = lambda: None

    def dispatch(action_id):
        dispatches.append(action_id)
        if action_id == 'exit':
            return 'exit'
        return 'invalid'

    orchestrator._dispatch_launcher_action = dispatch

    out = io.StringIO()
    with redirect_stdout(out):
        orchestrator.main_menu_loop()

    assert dispatches == ['exit']
    assert renders == ['menu', 'menu']
    assert 'Invalid choice.' not in out.getvalue()
    assert ('INFO', 'LAUNCHER_ACTION refresh main menu') in notices
