# -*- coding: utf-8 -*-
from __future__ import print_function

import argparse
import os
import sys

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
TOOLS = os.path.join(REPO_ROOT, 'tools')
if TOOLS not in sys.path:
    sys.path.insert(0, TOOLS)

from repo_audit import history_sensitive_scan


def test_build_grep_report_scans_sensitive_filenames_without_global_args(monkeypatch):
    def fake_iter_rev_list_objects():
        return iter([
            ('a' * 40, 'config/client_secret.env'),
            ('b' * 40, 'docs/README.md'),
        ])

    def fake_grep_history_findings(args):
        return [], {
            'commits': 0,
            'scanned_chunks': 0,
            'timed_out_chunks': 0,
            'truncated': False,
        }

    monkeypatch.setattr(history_sensitive_scan, 'iter_rev_list_objects', fake_iter_rev_list_objects)
    monkeypatch.setattr(history_sensitive_scan, 'grep_history_findings', fake_grep_history_findings)
    monkeypatch.setattr(history_sensitive_scan, 'scan_commit_metadata', lambda max_findings: [])

    args = argparse.Namespace(
        max_paths_per_object=1,
        max_grep_findings=10,
        max_metadata_findings=10,
    )
    report = history_sensitive_scan.build_grep_report(args)

    assert report['summary']['rev_list_object_rows'] == 2
    assert report['summary']['finding_count_by_rule'] == {'sensitive_filename': 1}
    assert report['findings'][0]['paths'] == ['config/client_secret.env']
