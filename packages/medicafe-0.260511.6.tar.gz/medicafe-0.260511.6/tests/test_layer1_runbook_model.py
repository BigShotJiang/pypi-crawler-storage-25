# -*- coding: utf-8 -*-
from __future__ import print_function

import unittest


class TestLayer1RunbookModel(unittest.TestCase):
    def test_stale_dat_qa_full_block_maps_to_dat_verification_rerun(self):
        from MediCafe.layer1_runbook_model import (
            ACTION_PHASE_D_DAT_VERIFICATION_RERUN,
            RUNBOOK_KEY_PHASE_D_DAT_QA_FULL_BLOCK_STALE,
            RUNBOOK_STATUS_ACTION_READY,
            build_layer1_runbook_model,
        )

        model = build_layer1_runbook_model(
            {
                'layer1_readiness_status': 'evaluated_ok',
                'layer1_current_run_id': 'phase-d',
                'phase_d_selected_rows': 419,
                'layer1_data_status': 'strict_dat_blocked',
            },
            {
                'last_manifest_sha256': 'abc',
                'last_shadow_pipeline_run_id': 'shadow',
                'last_phase_d_run_id': 'phase-d',
                'last_phase_d_dat_telemetry': {
                    'dat_selected_count': 419,
                    'dat_qa_pass_count': 0,
                    'dat_qa_reject_count': 419,
                },
                'phase_d_remediation': {
                    'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'status': 'active',
                },
            },
            {},
            {
                'anchor_run_id': 'shadow',
                'phase_d_artifact_run_id': 'phase-d',
                'dat_payer_resolution_evidence_status': 'stale_pre_resolution_diagnostics',
            },
            app_version='0.test',
        )

        self.assertEqual(model.get('layer1_runbook_key'), RUNBOOK_KEY_PHASE_D_DAT_QA_FULL_BLOCK_STALE)
        self.assertEqual(model.get('layer1_runbook_status'), RUNBOOK_STATUS_ACTION_READY)
        self.assertEqual(model.get('layer1_runbook_action_kind'), ACTION_PHASE_D_DAT_VERIFICATION_RERUN)
        self.assertEqual(model.get('layer1_runbook_target_anchor_run_id'), 'shadow')
        self.assertEqual(model.get('layer1_runbook_target_phase_d_run_id'), 'phase-d')
        self.assertTrue(model.get('layer1_runbook_fingerprint'))

    def test_current_dat_qa_full_block_maps_to_review_bundle(self):
        from MediCafe.layer1_runbook_model import (
            ACTION_REVIEW_DAT_QA_FULL_BLOCK,
            RUNBOOK_KEY_PHASE_D_DAT_QA_FULL_BLOCK_CURRENT,
            build_layer1_runbook_model,
        )

        model = build_layer1_runbook_model(
            {'phase_d_selected_rows': 5, 'layer1_current_run_id': 'd'},
            {
                'last_shadow_pipeline_run_id': 's',
                'last_phase_d_run_id': 'd',
                'last_phase_d_dat_telemetry': {
                    'dat_selected_count': 5,
                    'dat_qa_pass_count': 0,
                    'dat_qa_reject_count': 5,
                },
            },
            {},
            {'dat_payer_resolution_evidence_status': 'current_resolution_diagnostics_present'},
        )

        self.assertEqual(model.get('layer1_runbook_key'), RUNBOOK_KEY_PHASE_D_DAT_QA_FULL_BLOCK_CURRENT)
        self.assertEqual(model.get('layer1_runbook_action_kind'), ACTION_REVIEW_DAT_QA_FULL_BLOCK)

    def test_invalid_external_pressure_is_observed_after_dat_full_block_absent(self):
        from MediCafe.layer1_runbook_model import (
            ACTION_SEND_BUNDLE,
            RUNBOOK_KEY_PHASE_D_INVALID_EXTERNAL_ID,
            RUNBOOK_STATUS_OBSERVE,
            build_layer1_runbook_model,
        )

        model = build_layer1_runbook_model(
            {'layer1_readiness_status': 'evaluated_ok', 'layer1_current_run_id': 'd'},
            {
                'last_phase_d_constraint_skip_counts': {
                    'patient_invalid_external_id': 17,
                },
            },
            {},
            {},
        )

        self.assertEqual(model.get('layer1_runbook_key'), RUNBOOK_KEY_PHASE_D_INVALID_EXTERNAL_ID)
        self.assertEqual(model.get('layer1_runbook_status'), RUNBOOK_STATUS_OBSERVE)
        self.assertEqual(model.get('layer1_runbook_action_kind'), ACTION_SEND_BUNDLE)

    def test_invalid_external_pressure_after_strict_dat_integration_is_action_ready(self):
        from MediCafe.layer1_runbook_model import (
            ACTION_RESOLVE_EXTERNAL_PATIENT_ID_CONTRACT,
            RUNBOOK_KEY_PHASE_D_INVALID_EXTERNAL_ID,
            RUNBOOK_STATUS_ACTION_READY,
            build_layer1_runbook_model,
        )

        model = build_layer1_runbook_model(
            {
                'layer1_readiness_status': 'evaluated_ok',
                'layer1_current_run_id': 'd',
                'layer1_data_status': 'strict_dat_integrated',
                'layer1_dat_strict_integrated_count': 1620,
                'phase_d_dat_canonical_record_count': 1610,
            },
            {
                'last_phase_d_constraint_skip_counts': {
                    'patient_invalid_external_id': 1394,
                    'patient_invalid_external_id_by_contract_disposition': {
                        'csv_patient_id_field_contains_display_text_or_wrong_column': 1381,
                    },
                },
                'phase_d_remediation': {
                    'issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SPIKE',
                    'status': 'active',
                },
            },
            {},
            {'anchor_run_id': 's', 'phase_d_artifact_run_id': 'd'},
        )

        self.assertEqual(model.get('layer1_runbook_key'), RUNBOOK_KEY_PHASE_D_INVALID_EXTERNAL_ID)
        self.assertEqual(model.get('layer1_runbook_status'), RUNBOOK_STATUS_ACTION_READY)
        self.assertEqual(model.get('layer1_runbook_action_kind'), ACTION_RESOLVE_EXTERNAL_PATIENT_ID_CONTRACT)
        self.assertEqual(model.get('layer1_runbook_blocker_class'), 'invalid_external_patient_id')
        self.assertIn('Do not broadly rewrite patient IDs', '\n'.join(model.get('layer1_runbook_reason_lines') or []))


if __name__ == '__main__':
    unittest.main()
