# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import sys
import unittest

TESTS_ROOT = os.path.abspath(os.path.dirname(__file__))
if TESTS_ROOT not in sys.path:
    sys.path.insert(0, TESTS_ROOT)

from xp_lab_scenarios import XPLabScenario

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
UM_ROOT = os.path.join(REPO_ROOT, "scripts", "unified_model")
if UM_ROOT not in sys.path:
    sys.path.insert(0, UM_ROOT)


def _archive_names(manifest):
    names = []
    for row in manifest.get("attachments", []):
        if isinstance(row, dict):
            names.append(row.get("archive_name"))
    return names


class XPLabScenarioEvidenceModeTests(unittest.TestCase):
    def test_active_run_uses_live_status_and_withholds_stale_latest_artifacts(self):
        from MediCafe import evidence_manifest
        from MediCafe.evidence_mode import MODE_LIVE_STATUS

        sc = XPLabScenario()
        try:
            meta = sc.add_live_status_with_stale_latest()
            req = evidence_manifest.build_evidence_request(
                "system_health_pack",
                "xp_lab_scenario",
                sc.lab_root,
                anchor_run_id=meta["completed_run_id"],
                active_run_id=meta["active_run_id"],
            )
            manifest = evidence_manifest.resolve_evidence_manifest(req)
            names = _archive_names(manifest)
            extra_meta = evidence_manifest.manifest_to_extra_meta(manifest)

            self.assertEqual(extra_meta.get("current_evidence_mode"), MODE_LIVE_STATUS)
            self.assertFalse(extra_meta.get("decisive_run_evidence_current"))
            self.assertIn("diagnostics_state.json", names)
            self.assertIn("run_cursor.json", names)
            self.assertIn("phase_c_current_attempt_latest.json", names)
            self.assertIn("evidence_mode_report.txt", names)
            self.assertNotIn("phase_c_execution_handoff_{0}.json".format(meta["completed_run_id"]), names)
            self.assertNotIn("ingest_from_manifest_diagnostics_latest.json", names)
            self.assertNotIn("ingest_from_manifest_bootstrap_latest.json", names)
        finally:
            sc.cleanup()

    def test_manifest_sha_mismatch_uses_incoherent_state_and_withholds_stale_layer1(self):
        from MediCafe import evidence_manifest
        from MediCafe.evidence_mode import MODE_INCOHERENT_STATE

        sc = XPLabScenario()
        try:
            meta = sc.add_manifest_sha_mismatch_with_stale_phase_artifacts()
            req = evidence_manifest.build_evidence_request(
                "cloud_health_escalation",
                "xp_lab_scenario",
                sc.lab_root,
                anchor_run_id=meta["shadow_run_id"],
                failed_phase="C",
                error_code="PHASE_C_HANDOFF_INCOHERENT",
            )
            manifest = evidence_manifest.resolve_evidence_manifest(req)
            names = _archive_names(manifest)
            extra_meta = evidence_manifest.manifest_to_extra_meta(manifest)

            self.assertEqual(extra_meta.get("current_evidence_mode"), MODE_INCOHERENT_STATE)
            self.assertEqual(extra_meta.get("evidence_mode_blocking_reason"), "phase_c_manifest_sha_mismatch")
            self.assertIn("evidence_incoherent_state.txt", names)
            self.assertNotIn(
                "ingest_write_summary_{0}.json".format(meta["phase_c_run_id"]),
                names,
            )
            self.assertNotIn(
                "qa_canonical_summary_{0}.json".format(meta["phase_d_run_id"]),
                names,
            )
        finally:
            sc.cleanup()


class XPLabScenarioPhaseCStallTests(unittest.TestCase):
    def test_xp_smoke_reports_phase_c_stall_bootstrap_without_finish(self):
        from xp_phase_smoke import build_smoke_result

        sc = XPLabScenario()
        try:
            sc.add_phase_c_stall_bootstrap_without_finish()
            result = build_smoke_result(sc.lab_root)
            phase_c = [row for row in result.get("phases", []) if row.get("phase") == "C"][0]
            interfaces = [row for row in result.get("phases", []) if row.get("phase") == "interfaces"][0]

            self.assertEqual(result.get("overall_status"), "blocked")
            self.assertEqual(phase_c.get("status"), "blocked")
            self.assertEqual(phase_c.get("blocker"), "phase_c_script_entered_but_no_finish_diag")
            self.assertTrue(phase_c.get("bootstrap_present"))
            self.assertFalse(phase_c.get("finish_diagnostics_present"))
            self.assertEqual(interfaces.get("status"), "ok")
        finally:
            sc.cleanup()

    def test_handoff_report_classifies_phase_c_stall_bootstrap_without_finish(self):
        from run_shadow_pipeline import _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        sc = XPLabScenario()
        try:
            meta = sc.add_phase_c_stall_bootstrap_without_finish()
            state_path = os.path.join(sc.lab_root, "diagnostics_state.json")
            cursor_path = os.path.join(sc.lab_root, "run_cursor.json")
            with open(state_path, "r", encoding="utf-8") as handle:
                state_before = json.load(handle)
            with open(cursor_path, "r", encoding="utf-8") as handle:
                cursor_before = json.load(handle)
            exec_info = {"return_code": 0, "ok": True}

            _emit_phase_c_execution_handoff_report(
                sc.lab_root,
                meta["shadow_run_id"],
                dict(state_before),
                {},
                exec_info,
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            )

            with open(state_path, "r", encoding="utf-8") as handle:
                state_after = json.load(handle)
            report_path = state_after.get("last_phase_c_execution_handoff_report_path")
            with open(report_path, "r", encoding="utf-8") as handle:
                report = json.load(handle)

            self.assertEqual(report.get("blocker_class"), "phase_c_script_entered_but_no_finish_diag")
            self.assertTrue(report.get("bootstrap_diagnostics_present"))
            self.assertTrue(report.get("bootstrap_timeline_present"))
            self.assertEqual(report.get("bootstrap_timeline_last_stage"), "ingest_write_transaction_begin")
            self.assertFalse(report.get("ingest_diagnostics_present"))
            self.assertEqual(report.get("publish_failure_class"), "finish_diagnostics_missing")
        finally:
            sc.cleanup()

    def test_phase_c_stall_status_bundle_attaches_current_attempt_telemetry(self):
        from MediCafe import evidence_manifest
        from run_shadow_pipeline import _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST
        from run_shadow_pipeline import _emit_phase_c_execution_handoff_report

        sc = XPLabScenario()
        try:
            meta = sc.add_phase_c_stall_bootstrap_without_finish()
            state_path = os.path.join(sc.lab_root, "diagnostics_state.json")
            current_attempt_path = os.path.join(sc.reports_dir, "phase_c_current_attempt_latest.json")
            with open(state_path, "r", encoding="utf-8") as handle:
                state_before = json.load(handle)
            exec_info = {"return_code": 0, "ok": True}

            _emit_phase_c_execution_handoff_report(
                sc.lab_root,
                meta["shadow_run_id"],
                dict(state_before),
                {},
                exec_info,
                True,
                True,
                "PHASE_C_HANDOFF_INCOHERENT",
                _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
            )

            with open(state_path, "r", encoding="utf-8") as handle:
                state_after = json.load(handle)
            report_path = state_after.get("last_phase_c_execution_handoff_report_path")
            state_after["pipeline_state"] = "running"
            state_after["active_run_id"] = meta["shadow_run_id"] + "-active"
            state_after["last_shadow_pipeline_run_id"] = meta["shadow_run_id"]
            with open(state_path, "w", encoding="utf-8") as handle:
                json.dump(state_after, handle, sort_keys=True)
                handle.write("\n")
            with open(current_attempt_path, "r", encoding="utf-8") as handle:
                current_attempt = json.load(handle)
            self.assertEqual(current_attempt.get("last_reached_stage"), "ingest_write_transaction_begin")
            current_attempt["handoff_report_seen"] = True
            current_attempt["handoff_report_path"] = report_path
            with open(current_attempt_path, "w", encoding="utf-8") as handle:
                json.dump(current_attempt, handle, sort_keys=True)
                handle.write("\n")

            req = evidence_manifest.build_evidence_request(
                "system_health_pack",
                "xp_lab_scenario",
                sc.lab_root,
                anchor_run_id=meta["shadow_run_id"],
                active_run_id=state_after["active_run_id"],
                failed_phase="C",
                error_code="PHASE_C_HANDOFF_INCOHERENT",
            )
            manifest = evidence_manifest.resolve_evidence_manifest(req)
            names = _archive_names(manifest)
            rows = {
                row.get("archive_name"): row
                for row in manifest.get("attachments", [])
                if isinstance(row, dict)
            }

            self.assertEqual(
                evidence_manifest.manifest_to_extra_meta(manifest).get("current_evidence_mode"),
                "live_status",
            )
            self.assertIn("phase_c_current_attempt_latest.json", names)
            self.assertIn("ingest_from_manifest_bootstrap_latest.json", names)
            self.assertIn("ingest_from_manifest_bootstrap_timeline_latest.jsonl", names)
            self.assertIn(os.path.basename(report_path), names)
            self.assertEqual(
                rows["ingest_from_manifest_bootstrap_latest.json"].get("scope"),
                "phase_c_current_attempt_bootstrap",
            )
            self.assertEqual(
                rows["ingest_from_manifest_bootstrap_timeline_latest.jsonl"].get("scope"),
                "phase_c_current_attempt_bootstrap_timeline",
            )
            self.assertEqual(
                rows[os.path.basename(report_path)].get("scope"),
                "phase_c_current_attempt_handoff",
            )
        finally:
            sc.cleanup()

    def test_xp_current_failure_reproduces_tier2_then_clean_exit_before_finish(self):
        from MediCafe.layer1_phase_c_runbook_helper import build_runbook_telemetry_document
        from xp_phase_smoke import build_smoke_result

        sc = XPLabScenario()
        try:
            sc.add_phase_c_stall_after_tier2_rebuild()
            smoke = build_smoke_result(sc.lab_root)
            phase_c = [row for row in smoke.get("phases", []) if row.get("phase") == "C"][0]
            telemetry = build_runbook_telemetry_document(
                sc.lab_root,
                REPO_ROOT,
                sys.executable,
                execute_pipeline=False,
                wait_lock_sec=0,
                no_blocking_waits=True,
            )
            stop_step = next(
                (row for row in telemetry.get("steps") or [] if row.get("step_id") in (
                    "2_phase_c_stop_point_action",
                    "3_phase_c_stop_point_action",
                )),
                {},
            )
            stop_point = (stop_step.get("result") or {}).get("data") or {}
            with open(sc.report_path("phase_c_current_attempt_latest.json"), "r", encoding="utf-8") as handle:
                current_attempt = json.load(handle)

            self.assertEqual(phase_c.get("blocker"), "phase_c_script_entered_but_no_finish_diag")
            self.assertEqual(current_attempt.get("last_reached_stage"), "ingest_write_transaction_begin")
            self.assertEqual(stop_point.get("last_stage"), "ingest_write_transaction_begin")
            self.assertEqual(
                stop_point.get("stop_point_class"),
                "transaction_entry_no_finer_marker",
            )
            self.assertEqual(
                stop_point.get("existing_repo_mechanisms"),
                "phase_c_current_attempt;phase_c_self_heal_ladder",
            )
            self.assertEqual(
                telemetry.get("layer1_model_before", {}).get("layer1_current_blocker"),
                "phase_c_manifest_not_ingested",
            )
            with open(os.path.join(sc.lab_root, "diagnostics_state.json"), "r", encoding="utf-8") as handle:
                state_after = json.load(handle)
            self.assertEqual(
                state_after.get("phase_c_last_self_heal_tier"),
                "tier2_force_db_rebuild",
            )
        finally:
            sc.cleanup()

    def test_live_status_refreshes_support_send_queue_context_before_attaching(self):
        from MediCafe import evidence_manifest

        sc = XPLabScenario()
        try:
            meta = sc.add_live_status_with_stale_latest()
            stale_ctx = sc.report_path("support_send_bundle_queue_context_latest.json")
            sc.write_json(
                stale_ctx,
                {
                    "schema_version": 1,
                    "generated_at_utc": "2000-01-01T00:00:00Z",
                    "stale_marker": True,
                },
            )
            req = evidence_manifest.build_evidence_request(
                "system_health_pack",
                "xp_lab_scenario",
                sc.lab_root,
                anchor_run_id=meta["completed_run_id"],
                active_run_id=meta["active_run_id"],
            )
            manifest = evidence_manifest.resolve_evidence_manifest(req)
            names = _archive_names(manifest)
            with open(stale_ctx, "r", encoding="utf-8") as handle:
                refreshed = json.load(handle)

            self.assertIn("support_send_bundle_queue_context_latest.json", names)
            self.assertFalse(refreshed.get("stale_marker", False))
            self.assertNotEqual(refreshed.get("generated_at_utc"), "2000-01-01T00:00:00Z")
            self.assertIn("recent_jobs", refreshed)
        finally:
            sc.cleanup()


if __name__ == "__main__":
    unittest.main()
