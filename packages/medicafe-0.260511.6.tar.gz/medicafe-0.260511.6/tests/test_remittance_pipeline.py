# tests/test_remittance_pipeline.py
"""Remittance merge/resolution helpers (Python 3.4+)."""
import os
import sys
import unittest

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
medilink_dir = os.path.join(parent_dir, 'MediLink')
if medilink_dir not in sys.path:
    sys.path.insert(0, medilink_dir)

from MediLink_Parser import (  # noqa: E402
    parse_277_content,
    parse_dpt_content,
    parse_ebt_content,
    parse_ibt_content,
    parse_era_content,
    get_last_parse_telemetry,
)
from MediLink_RemittancePipeline import (  # noqa: E402
    merge_remittance_group,
    group_records_for_merge,
    canonical_to_posting_row,
    resolve_remittance_dict,
    build_crosswalk_lookups,
    normalize_unified_record,
    build_source_meta,
    get_decode_extensions,
    extension_to_file_type,
)
from MediLink_Decoder import (  # noqa: E402
    GLOBAL_SEEN_CLAIM_NUMBERS,
    format_records,
    get_last_format_telemetry,
)


class TestMergeRemittanceGroup(unittest.TestCase):
    def test_single_row_has_merge_count(self):
        r = {'claim_number': '1', 'dos': '20250101', 'paid': '10', 'data_source': 'claims_inquiry'}
        m = merge_remittance_group([r])
        self.assertEqual(m.get('merge_source_count'), 1)
        self.assertTrue(m.get('merge_consistent'))

    def test_money_conflict_flag(self):
        rows = [
            {'paid': '10', 'allowed': '0', 'patient_resp': '0', 'status': 'A', 'data_source': 'parsed_file'},
            {'paid': '20', 'allowed': '0', 'patient_resp': '0', 'status': 'A', 'data_source': 'claims_inquiry'},
        ]
        m = merge_remittance_group(rows)
        self.assertTrue(m.get('money_conflict'))
        self.assertFalse(m.get('merge_consistent'))
        self.assertEqual(m.get('merge_source_count'), 2)

    def test_group_records_for_merge(self):
        recs = [
            {'internal_claim_key': 'k1', 'dos': '20250101', 'claim_number': 'x'},
            {'internal_claim_key': 'k1', 'dos': '20250101', 'claim_number': 'y'},
        ]
        g = group_records_for_merge(recs)
        self.assertEqual(len(g), 1)

    def test_merge_file_plus_api_preserves_api_breadcrumbs(self):
        file_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '100',
            'data_source': 'parsed_file',
            'processed_date': '',
            'claim_xwalk_data': None,
            'lookup_mode': '',
            'document_refs': None,
        }
        api_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '100',
            'data_source': 'claims_inquiry',
            'processed_date': '2025-01-10',
            'claim_xwalk_data': [{'stage': 'x'}],
            'lookup_mode': 'member',
            'document_refs': [{'id': 'd1'}],
        }
        m = merge_remittance_group([file_row, api_row])
        self.assertEqual(m.get('claim_xwalk_data'), [{'stage': 'x'}])
        self.assertEqual(m.get('lookup_mode'), 'member')
        self.assertEqual(m.get('processed_date'), '2025-01-10')
        self.assertEqual(m.get('document_refs'), [{'id': 'd1'}])

    def test_merge_inquiry_processed_date_when_file_has_different_date(self):
        file_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '1',
            'data_source': 'parsed_file',
            'processed_date': '20250101',
        }
        api_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '1',
            'data_source': 'claims_inquiry',
            'processed_date': '20250115',
        }
        m = merge_remittance_group([file_row, api_row])
        self.assertEqual(m.get('processed_date'), '20250101')
        self.assertEqual(m.get('inquiry_processed_date'), '20250115')
        self.assertTrue(m.get('source_conflict'))

    def test_merge_fills_blank_patient_name_from_api_row(self):
        file_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '100',
            'patient_name': '',
            'data_source': 'parsed_file',
        }
        api_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '100',
            'patient_name': 'Jane Q. Public',
            'data_source': 'claims_inquiry',
        }
        m = merge_remittance_group([file_row, api_row])
        self.assertEqual(m.get('patient_name'), 'Jane Q. Public')


class TestCanonicalToPostingRow(unittest.TestCase):
    def test_patid_from_internal(self):
        row = {
            'merge_source_count': 1,
            'merge_consistent': True,
            'internal_patid': '12345',
            'dos': '20250101',
            'payer_id': 'p',
            'paid': '1',
            'allowed': '2',
            'patient_resp': '3',
            'status': 'ok',
            'claim_number': 'CN',
        }
        out = canonical_to_posting_row(row)
        self.assertEqual(out['patid'], '12345')
        self.assertEqual(out['source_claim_number'], 'CN')

    def test_posting_row_ignores_legacy_patid_without_internal(self):
        row = {
            'merge_source_count': 1,
            'merge_consistent': True,
            'patid': 'LEGACY999',
            'internal_patid': '',
            'dos': '20250101',
            'payer_id': 'p',
            'paid': '0',
            'allowed': '0',
            'patient_resp': '0',
            'status': 'x',
            'claim_number': 'CN',
        }
        out = canonical_to_posting_row(row)
        self.assertEqual(out['patid'], '')


class TestResolveRemittanceDict(unittest.TestCase):
    def test_non_dict_unchanged(self):
        self.assertEqual(resolve_remittance_dict([], {}), [])

    def test_resolve_via_submitted_claim_number(self):
        lookups = {
            'by_submitted_claim_number': {
                'CLM01': {
                    'internal_patid': '99',
                    'internal_chart': 'C',
                    'claim_key': 'k',
                }
            },
            'by_claim_key': {},
        }
        rec = {'claim_number': 'CLM01', 'dos': '20250101'}
        resolve_remittance_dict(rec, lookups)
        self.assertEqual(rec.get('internal_patid'), '99')
        self.assertEqual(rec.get('match_status'), 'matched_exact')

    def test_resolve_backfills_patient_name_from_crosswalk(self):
        lookups = {
            'by_submitted_claim_number': {
                'CLM01': {
                    'internal_patid': '99',
                    'internal_chart': 'C',
                    'claim_key': 'k',
                    'member_id': 'MID1',
                    'member_first_name': 'Jane',
                    'member_last_name': 'Doe',
                }
            },
            'by_claim_key': {},
        }
        rec = {'claim_number': 'CLM01', 'dos': '20250101', 'patient_name': ''}
        resolve_remittance_dict(rec, lookups)
        self.assertEqual(rec.get('patient_name'), 'Jane Doe')
        self.assertEqual(rec.get('member_id'), 'MID1')

    def test_resolve_preserves_existing_patient_name(self):
        lookups = {
            'by_submitted_claim_number': {
                'CLM01': {
                    'internal_patid': '99',
                    'internal_chart': 'C',
                    'claim_key': 'k',
                    'member_first_name': 'Jane',
                    'member_last_name': 'Doe',
                }
            },
            'by_claim_key': {},
        }
        rec = {'claim_number': 'CLM01', 'dos': '20250101', 'patient_name': 'Source Name'}
        resolve_remittance_dict(rec, lookups)
        self.assertEqual(rec.get('patient_name'), 'Source Name')


class TestEraPatientNameParsing(unittest.TestCase):
    def test_parse_era_patient_name_from_nm1_qc(self):
        content = (
            'TRN*1*12345~'
            'N1*PR*PAYER~'
            'CLP*CLM123*1*100*80*20*12*PATID*PAYERCLM~'
            'NM1*QC*1*DOE*JANE~'
            'AMT*B6*85~'
            'CAS*PR*1*15~'
            'DTM*472*20210102~'
            'SE*8*0001~'
        )
        rows = parse_era_content(content)
        self.assertEqual(rows[0].get('Patient'), 'DOE JANE')

    def test_parse_era_clp_fields_and_patient_resp_fallback(self):
        content = (
            ' TRN*1*12345 ~\n'
            ' N1*PR*PAYER NAME ~'
            ' CLP*CLM123*2*100*80*20*12*PAYERCLM123 ~'
            ' NM1*QC*1*DOE*JANE ~'
            ' AMT*B6*85 ~'
            ' DTM*472*20210102 ~'
        )
        rows = parse_era_content(content)
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row.get('Chart Number'), 'CLM123')
        self.assertEqual(row.get('claimStatus'), '2')
        self.assertEqual(row.get('Claim Status Code'), '2')
        self.assertEqual(row.get('payer_claim_number'), 'PAYERCLM123')
        self.assertEqual(row.get('Payer Claim Number'), 'PAYERCLM123')
        self.assertEqual(row.get('Patient Responsibility'), 20.0)
        self.assertEqual(row.get('Patient'), 'DOE JANE')

    def test_parse_era_cas_pr_does_not_double_count_clp05(self):
        content = (
            'CLP*CLM123*1*100*80*20*12*PAYERCLM123~'
            'CAS*PR*1*15~'
        )
        rows = parse_era_content(content)
        self.assertEqual(rows[0].get('Patient Responsibility'), 15.0)
        self.assertEqual(rows[0].get('Adjustment Amount'), 15.0)

    def test_parse_era_cas_multiple_reason_amount_triplets(self):
        content = (
            'CLP*CLM123*1*100*80*20*12*PAYERCLM123~'
            'CAS*CO*45*10**97*5~'
            'CAS*PR*1*3**2*4~'
        )
        rows = parse_era_content(content)
        self.assertEqual(rows[0].get('Write Off'), 15.0)
        self.assertEqual(rows[0].get('Patient Responsibility'), 7.0)
        self.assertEqual(rows[0].get('Adjustment Amount'), 22.0)

    def test_parse_era_malformed_segment_telemetry_is_phi_light(self):
        content = 'CLP*ONLYONE~AMT*B6*BAD~CLP*CLM123*1*100*80*20*12*PAYERCLM123~'
        rows = parse_era_content(content)
        telemetry = get_last_parse_telemetry('ERA')
        self.assertEqual(len(rows), 1)
        self.assertEqual(telemetry.get('file_type'), 'ERA')
        self.assertEqual(telemetry.get('record_count'), 1)
        self.assertTrue(telemetry.get('malformed_segment_count') >= 1)


class Test277BoundaryParsing(unittest.TestCase):
    def test_ref_1k_without_trn2_starts_distinct_claim_records(self):
        content = (
            'ST*277*0001~'
            'NM1*PR*2*PAYER*****PI*PAYER1~'
            'REF*1K*PAYERCLAIM1~'
            'NM1*QC*1*DOE*JANE~'
            'STC*A1:19:PR*20260501*WQ*0~'
            'REF*1K*PAYERCLAIM2~'
            'NM1*QC*1*SMITH*JOHN~'
            'STC*A2:20:PR*20260502*WQ*0~'
            'SE*8*0001~'
        )
        rows = parse_277_content(content)
        telemetry = get_last_parse_telemetry('277')
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0].get('Claim #'), 'PAYERCLAIM1')
        self.assertEqual(rows[0].get('payer_claim_number'), 'PAYERCLAIM1')
        self.assertEqual(rows[0].get('Patient'), 'DOE JANE')
        self.assertEqual(rows[1].get('Claim #'), 'PAYERCLAIM2')
        self.assertEqual(rows[1].get('payer_claim_number'), 'PAYERCLAIM2')
        self.assertEqual(rows[1].get('Patient'), 'SMITH JOHN')
        self.assertEqual(telemetry.get('records_started_by_ref1k'), 2)
        self.assertEqual(telemetry.get('records_missing_claim_number_but_has_payer_claim_number'), 2)

    def test_hl_patient_boundary_flushes_prior_ref_claim(self):
        content = (
            'REF*1K*PAYERCLAIM1~'
            'NM1*QC*1*DOE*JANE~'
            'HL*2*1*PT~'
            'REF*1K*PAYERCLAIM2~'
            'NM1*QC*1*SMITH*JOHN~'
        )
        rows = parse_277_content(content)
        telemetry = get_last_parse_telemetry('277')
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0].get('Claim #'), 'PAYERCLAIM1')
        self.assertEqual(rows[1].get('Claim #'), 'PAYERCLAIM2')
        self.assertEqual(telemetry.get('records_started_by_hl'), 1)


class TestTextReportParsing(unittest.TestCase):
    def test_dpt_parses_adjacent_labeled_fields_without_double_spaces(self):
        content = (
            'Patient Account Number: DPT001 Patient Name: DOE JANE Claim Status: Accepted\n'
            'Paid: 12.34 Allowed: 20.00 Patient Responsibility: 7.66\n'
        )
        rows = parse_dpt_content(content)
        telemetry = get_last_parse_telemetry('DPT')
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].get('Patient Account Number'), 'DPT001')
        self.assertEqual(rows[0].get('Patient Name'), 'DOE JANE')
        self.assertEqual(rows[0].get('Claim Status'), 'Accepted')
        self.assertTrue(telemetry.get('raw_key_count') >= 5)

    def test_ebt_parses_adjacent_labeled_fields_without_double_spaces(self):
        content = (
            'Patient Name: DOE JANE Patient Account Number: EBT001 Message Initiator: PAYER Message Type: Eligibility\n'
        )
        rows = parse_ebt_content(content)
        telemetry = get_last_parse_telemetry('EBT')
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].get('Patient Name'), 'DOE JANE')
        self.assertEqual(rows[0].get('Patient Account Number'), 'EBT001')
        self.assertEqual(rows[0].get('Message Initiator'), 'PAYER')
        self.assertEqual(rows[0].get('Message Type'), 'Eligibility')
        self.assertTrue(telemetry.get('raw_key_count') >= 4)

    def test_ibt_parses_adjacent_labeled_fields_without_double_spaces(self):
        content = (
            'Submitter Batch ID: BATCH1 Patient Control Number: IBT001 Patient Name: DOE JANE\n'
            'Payer Claim Number: PCN123 Status: Accepted\n'
        )
        rows = parse_ibt_content(content)
        telemetry = get_last_parse_telemetry('IBT')
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].get('Submitter Batch ID'), 'BATCH1')
        self.assertEqual(rows[0].get('Patient Control Number'), 'IBT001')
        self.assertEqual(rows[0].get('Patient Name'), 'DOE JANE')
        self.assertEqual(rows[0].get('Payer Claim Number'), 'PCN123')
        self.assertEqual(rows[0].get('Status'), 'Accepted')
        self.assertTrue(telemetry.get('raw_key_count') >= 5)


class TestRemittanceDecoderFormatting(unittest.TestCase):
    def tearDown(self):
        GLOBAL_SEEN_CLAIM_NUMBERS.clear()

    def test_global_seen_claim_numbers_does_not_suppress_format_records(self):
        GLOBAL_SEEN_CLAIM_NUMBERS.add('CLM123')
        rows = format_records([
            {
                'Chart Number': 'CLM123',
                'Payer': 'PAYER',
                'Amount Paid': '80',
                'Charge': '100',
            }
        ], 'ERA')
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].claim_number, 'CLM123')
        self.assertIn('CLM123', GLOBAL_SEEN_CLAIM_NUMBERS)

    def test_duplicate_suppression_is_within_single_format_call(self):
        source_rows = [
            {'Chart Number': 'CLM123', 'Payer': 'PAYER', 'Amount Paid': '80', 'Charge': '100'},
            {'Chart Number': 'CLM123', 'Payer': 'PAYER', 'Amount Paid': '80', 'Charge': '100'},
        ]
        rows = format_records(source_rows, 'ERA')
        telemetry = get_last_format_telemetry('ERA')
        self.assertEqual(len(rows), 1)
        self.assertEqual(telemetry.get('duplicate_suppressed_count'), 1)


class TestRemittanceRegistry(unittest.TestCase):
    def test_dpt_decode_enabled(self):
        self.assertIn('.dpt', get_decode_extensions())
        self.assertEqual(extension_to_file_type('example.dpt'), 'DPT')


class TestNormalizeUnifiedRecord(unittest.TestCase):
    def test_source_checksum_from_meta(self):
        raw = {
            'Claim #': 'C1',
            'Chart': '',
            'Serv.': '20250101',
            'Payer ID': '',
            'Payer': '',
            'Patient': 'Ann Other',
            'Status': '',
            'Charged': '',
            'Allowed': '',
            'Paid': '',
            'Pt Resp': '',
        }
        meta = build_source_meta(source_checksum='sha1:abc', source_file='f.era')
        row = normalize_unified_record(raw, meta)
        self.assertEqual(row.get('source_checksum'), 'sha1:abc')


class TestBuildCrosswalkLookups(unittest.TestCase):
    def test_empty_root(self):
        m = build_crosswalk_lookups('')
        self.assertIn('by_claim_key', m)
        self.assertIn('by_submitted_claim_number', m)


if __name__ == '__main__':
    unittest.main()
