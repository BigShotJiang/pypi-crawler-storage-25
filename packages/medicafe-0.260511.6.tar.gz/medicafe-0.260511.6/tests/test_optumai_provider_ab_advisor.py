#!/usr/bin/env python
"""Tests for OPTUMAI provider-sequence A/B advisor helper."""

from __future__ import print_function

import os
import shutil
import sys
import tempfile
import unittest


PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


def _base_config(tmpdir):
    return {
        "MediLink_Config": {
            "local_claims_path": tmpdir,
            "endpoints": {
                "OPTUMAI": {
                    "submission_method": "api",
                    "provider_sequence_ab_billing_group_name": "CLINIC GROUP",
                    "provider_sequence_ab_billing_group_npi": "1992735088",
                    "provider_sequence_ab_billing_taxonomy": "363LA2200X",
                }
            },
        }
    }


def _patient(chart, amount="100", payer_id="87726"):
    return {
        "confirmed_endpoint": "OPTUMAI",
        "patient_id": chart,
        "CHART": chart,
        "payer_id": payer_id,
        "primary_insurance": "UHC",
        "surgery_date_iso": "2026-05-12",
        "primary_procedure_code": "99213",
        "amount": amount,
        "claim_key": "{}|{}|2026-05-12|99213".format(chart, payer_id),
    }


class TestOptumaiProviderAbAdvisor(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_no_advice_when_group_billing_config_missing(self):
        from MediCafe import optumai_provider_ab_advisor as advisor

        cfg = _base_config(self.tmpdir)
        del cfg["MediLink_Config"]["endpoints"]["OPTUMAI"]["provider_sequence_ab_billing_group_npi"]
        advice = advisor.build_provider_ab_advice([_patient("1")], cfg, now_func=lambda: 1)

        self.assertFalse(advice.get("offered"))
        self.assertEqual(advice.get("reason"), "missing_group_billing_config")

    def test_no_advice_for_non_optumai_route(self):
        from MediCafe import optumai_provider_ab_advisor as advisor

        row = _patient("1")
        row["confirmed_endpoint"] = "AVAILITY"
        advice = advisor.build_provider_ab_advice([row], _base_config(self.tmpdir), now_func=lambda: 1)

        self.assertFalse(advice.get("offered"))

    def test_selects_one_candidate_and_annotates_accepted(self):
        from MediCafe import optumai_provider_ab_advisor as advisor

        rows = [_patient("1", amount="500"), _patient("2", amount="100")]
        advice = advisor.build_provider_ab_advice(rows, _base_config(self.tmpdir), now_func=lambda: 42)
        advisor.annotate_provider_ab_choice(rows, advice, True)

        self.assertTrue(advice.get("offered"))
        self.assertEqual(advice.get("patient_index"), 1)
        self.assertFalse(advisor.is_provider_ab_patient(rows[0]))
        self.assertTrue(advisor.is_provider_ab_patient(rows[1]))
        self.assertEqual(rows[1].get("optumai_provider_ab_operator_choice"), "accepted")

    def test_declined_choice_does_not_mark_provider_ab_patient(self):
        from MediCafe import optumai_provider_ab_advisor as advisor

        rows = [_patient("1")]
        advice = advisor.build_provider_ab_advice(rows, _base_config(self.tmpdir), now_func=lambda: 42)
        advisor.annotate_provider_ab_choice(rows, advice, False)

        self.assertEqual(rows[0].get("optumai_provider_ab_operator_choice"), "declined")
        self.assertFalse(advisor.is_provider_ab_patient(rows[0]))

    def test_prompt_defaults_to_normal_unless_operator_enters_2(self):
        from MediCafe import optumai_provider_ab_advisor as advisor

        advice = {
            "offered": True,
            "same_payer_prior_provider_sequence_warning": True,
        }
        printed = []
        self.assertFalse(advisor.prompt_provider_ab_advice(advice, input_fn=lambda _p: "", print_fn=printed.append))
        self.assertTrue(advisor.prompt_provider_ab_advice(advice, input_fn=lambda _p: "2", print_fn=printed.append))
        self.assertTrue(any("not for resubmitting" in line for line in printed))

    def test_config_overlay_sets_group_billing_only_for_trial_patient(self):
        from MediCafe import optumai_provider_ab_advisor as advisor

        cfg = _base_config(self.tmpdir)
        row = _patient("1")
        row["optumai_provider_ab_operator_choice"] = "accepted"
        row["optumai_provider_ab_variant"] = advisor.VARIANT_BILLING_GROUP_RENDERING_INDIVIDUAL

        out = advisor.config_for_provider_ab_patient(cfg, row)
        optum = out["MediLink_Config"]["endpoints"]["OPTUMAI"]

        self.assertIsNot(out, cfg)
        self.assertEqual(optum.get("billing_provider_entity_type_qualifier"), "2")
        self.assertEqual(optum.get("billing_provider_lastname"), "CLINIC GROUP")
        self.assertEqual(optum.get("billing_provider_firstname"), "")
        self.assertEqual(optum.get("billing_provider_npi"), "1992735088")
        self.assertTrue(optum.get("emit_billing_provider_taxonomy"))

    def test_telemetry_fields_classify_provider_warning_outcome(self):
        from MediCafe import optumai_provider_ab_advisor as advisor

        row = _patient("1")
        row["optumai_provider_ab_offered"] = True
        row["optumai_provider_ab_operator_choice"] = "accepted"
        row["optumai_provider_ab_variant"] = advisor.VARIANT_BILLING_GROUP_RENDERING_INDIVIDUAL
        fields = advisor.telemetry_fields_for_patient(
            row,
            "Submitted to OPTUMAI (validation warning). status=000, transactionId=present "
            "reason=provider_sequence_missing",
            status=True,
        )

        self.assertEqual(fields.get("optumai_provider_ab_outcome"), "accepted_with_provider_warning")

    def test_bundle_summary_is_redacted_and_outcome_focused(self):
        from MediCafe import optumai_provider_ab_advisor as advisor

        row = _patient("1")
        row["patient_name"] = "Jane Doe"
        row["member_id"] = "SECRET-MEMBER"
        row["optumai_provider_ab_offered"] = True
        row["optumai_provider_ab_operator_choice"] = "accepted"
        row["optumai_provider_ab_variant"] = advisor.VARIANT_BILLING_GROUP_RENDERING_INDIVIDUAL
        row["optumai_provider_ab_advice_id"] = "advice-1"
        row["optumai_provider_ab_reason"] = "eligible_optumai_claim_with_custody_tracking"
        file_path = os.path.join(self.tmpdir, "claim.txt")
        submission_results = {
            "OPTUMAI": {
                file_path: (
                    True,
                    "Submitted to OPTUMAI. status=000, transactionId=present",
                ),
                "_transaction_ids": {
                    file_path: "TX-1",
                },
            }
        }
        summary = advisor.build_submission_bundle_summary(
            submission_results,
            {file_path: [row]},
            now_func=lambda: 1,
        )
        extra_meta, extra_files = advisor.bundle_parts_for_submission_summary(summary)

        self.assertEqual(summary.get("trial_count"), 1)
        self.assertEqual(summary.get("generated_at_utc"), "1970-01-01T00:00:01Z")
        self.assertEqual(summary.get("trials")[0].get("outcome"), "accepted_no_provider_warning")
        self.assertTrue(summary.get("trials")[0].get("transaction_id_present"))
        self.assertEqual(extra_meta.get("bundle_kind"), "claim_submission_report")
        self.assertEqual(extra_files[0][0], "optumai_provider_ab_submission_summary.json")
        text = str(summary)
        self.assertNotIn("Jane Doe", text)
        self.assertNotIn("SECRET-MEMBER", text)


if __name__ == "__main__":
    unittest.main()
