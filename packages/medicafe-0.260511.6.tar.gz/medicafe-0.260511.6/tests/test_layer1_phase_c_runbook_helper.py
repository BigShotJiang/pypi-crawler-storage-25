# -*- coding: utf-8 -*-
"""Tests for MediCafe.layer1_phase_c_runbook_helper automation + telemetry."""

from __future__ import print_function

import json
import os
import sys

import pytest


def _write_json(path, obj):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(obj, handle)


def _make_lab(tmp_path, diag, b_summary):
    lab = str(tmp_path / "lab")
    rep = os.path.join(lab, "reports")
    os.makedirs(rep, exist_ok=True)
    _write_json(os.path.join(lab, "diagnostics_state.json"), diag)
    _write_json(os.path.join(lab, "run_cursor.json"), {})
    _write_json(os.path.join(rep, "artifact_discovery_summary_b1.json"), b_summary)
    return lab


def test_build_runbook_telemetry_ingest_failure_executes_steps(tmp_path):
    from MediCafe.layer1_phase_c_runbook_helper import build_runbook_telemetry_document

    diag = {
        "last_discovery_ok": True,
        "last_phase_b_run_id": "b1",
        "last_manifest_sha256": "same",
        "last_ingest_manifest_sha256": "same",
        "last_phase_c_ok": False,
        "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
        "last_phase_c_run_id": "c-run-t",
    }
    lab = _make_lab(
        tmp_path,
        diag,
        {"run_id": "b1", "counts_by_class": {"dat": 1}, "dat_telemetry": {"dat_manifest_rows_count": 1}},
    )
    _write_json(
        os.path.join(lab, "reports", "ingest_write_summary_c-run-t.json"),
        {"ok": False, "rows_failed": 2, "operator_hint": "x", "db_error_detail": "locked"},
    )
    doc = build_runbook_telemetry_document(
        lab,
        str(tmp_path),
        sys.executable,
        execute_pipeline=False,
        wait_lock_sec=0,
        no_blocking_waits=True,
    )
    assert doc.get("runbook_key") == "phase_c_ingest_failure"
    assert isinstance(doc.get("layer1_operator_runbook_checklist"), list)
    assert doc.get("layer1_operator_runbook_checklist")
    lines = doc.get("automation_runbook_checklist_lines") or []
    assert lines
    assert any(str(x).startswith("[OK]") for x in lines)
    steps = doc.get("steps") or []
    assert len(steps) >= 5
    lock_step = next((s for s in steps if s.get("step_id") == "4_lock_wait_optional"), None)
    assert lock_step is not None
    assert (lock_step.get("result") or {}).get("status") == "skipped"
    assert "non-interactive" in str((lock_step.get("result") or {}).get("detail", "")).lower()
    ids = [s.get("step_id") for s in steps]
    assert "1_ingest_summary_snapshot" in ids
    assert "2_phase_c_stop_point_action" in ids
    assert "3_phase_c_db_health_probe" in ids
    assert doc.get("layer1_model_before", {}).get("layer1_current_blocker") == "phase_c_ingest_failed"


def test_build_runbook_telemetry_classifies_phase_c_transaction_stop_point(tmp_path):
    from MediCafe.layer1_phase_c_runbook_helper import build_runbook_telemetry_document

    diag = {
        "last_discovery_ok": True,
        "last_phase_b_run_id": "b1",
        "last_manifest_sha256": "same",
        "last_ingest_manifest_sha256": "same",
        "last_phase_c_ok": False,
        "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
        "last_phase_c_run_id": "c-stop",
    }
    lab = _make_lab(
        tmp_path,
        diag,
        {"run_id": "b1", "counts_by_class": {"dat": 1}, "dat_telemetry": {"dat_manifest_rows_count": 1}},
    )
    _write_json(
        os.path.join(lab, "reports", "ingest_write_summary_c-stop.json"),
        {"ok": False, "rows_failed": 0, "db_error_detail": ""},
    )
    timeline_path = os.path.join(lab, "reports", "ingest_from_manifest_bootstrap_timeline_latest.jsonl")
    with open(timeline_path, "w", encoding="utf-8") as handle:
        handle.write('{"schema_version":1,"stage":"sqlite_begin_execute_end","stage_seq":1}\n')
        handle.write('{"schema_version":1,"stage":"ingest_schema_verify_begin","stage_seq":2}\n')

    doc = build_runbook_telemetry_document(
        lab,
        str(tmp_path),
        sys.executable,
        execute_pipeline=False,
        wait_lock_sec=0,
        no_blocking_waits=True,
    )
    stop_step = next((s for s in doc.get("steps") or [] if s.get("step_id") == "2_phase_c_stop_point_action"), None)
    assert stop_step is not None
    data = (stop_step.get("result") or {}).get("data") or {}
    assert data.get("last_stage") == "ingest_schema_verify_begin"
    assert data.get("stop_point_class") == "schema_verification_stalled"
    assert "phase_c_db_health_probe" in str(data.get("existing_repo_mechanisms") or "")


def test_build_runbook_stop_point_uses_max_stage_seq_when_jsonl_out_of_order(tmp_path):
    from MediCafe.layer1_phase_c_runbook_helper import build_runbook_telemetry_document

    diag = {
        "last_discovery_ok": True,
        "last_phase_b_run_id": "b1",
        "last_manifest_sha256": "same",
        "last_ingest_manifest_sha256": "same",
        "last_phase_c_ok": False,
        "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
        "last_phase_c_run_id": "c-oo",
    }
    lab = _make_lab(
        tmp_path,
        diag,
        {"run_id": "b1", "counts_by_class": {"dat": 1}, "dat_telemetry": {"dat_manifest_rows_count": 1}},
    )
    _write_json(
        os.path.join(lab, "reports", "ingest_write_summary_c-oo.json"),
        {"ok": False, "rows_failed": 0, "db_error_detail": ""},
    )
    timeline_path = os.path.join(lab, "reports", "ingest_from_manifest_bootstrap_timeline_latest.jsonl")
    with open(timeline_path, "w", encoding="utf-8") as handle:
        handle.write('{"schema_version":1,"stage":"ingest_schema_verify_end","stage_seq":20}\n')
        handle.write('{"schema_version":1,"stage":"ingest_write_transaction_begin","stage_seq":1}\n')

    doc = build_runbook_telemetry_document(
        lab,
        str(tmp_path),
        sys.executable,
        execute_pipeline=False,
        wait_lock_sec=0,
        no_blocking_waits=True,
    )
    stop_step = next((s for s in doc.get("steps") or [] if s.get("step_id") == "2_phase_c_stop_point_action"), None)
    assert stop_step is not None
    data = (stop_step.get("result") or {}).get("data") or {}
    assert data.get("last_stage") == "ingest_schema_verify_end"
    assert data.get("last_stage_seq") == 20
    assert data.get("stop_point_class") == "row_write_next"


def test_build_runbook_telemetry_manifest_pending(tmp_path):
    from MediCafe.layer1_phase_c_runbook_helper import build_runbook_telemetry_document

    diag = {
        "last_discovery_ok": True,
        "last_phase_b_run_id": "b1",
        "last_manifest_sha256": "aaa",
        "last_ingest_manifest_sha256": "bbb",
        "last_phase_c_shadow_recovery_status": "",
    }
    lab = _make_lab(tmp_path, diag, {"run_id": "b1", "counts_by_class": {"dat": 1}})
    doc = build_runbook_telemetry_document(
        lab,
        str(tmp_path),
        sys.executable,
        execute_pipeline=False,
        wait_lock_sec=0,
        no_blocking_waits=True,
    )
    assert doc.get("runbook_key") == "phase_c_manifest_pending"
    ids = [s.get("step_id") for s in (doc.get("steps") or [])]
    assert "1_manifest_sha_snapshot" in ids


def test_build_runbook_bundle_extra_files_includes_layer1_when_qa_recommends(tmp_path):
    from MediCafe.layer1_phase_c_runbook_helper import build_runbook_bundle_extra_files

    lab = str(tmp_path / "lab2")
    rep = os.path.join(lab, "reports")
    os.makedirs(rep, exist_ok=True)
    rid = "20260101-120000-aaaaaaaa"
    l1_sum = os.path.join(rep, "layer1_join_debug_summary_{0}.json".format(rid))
    l1_pack = os.path.join(rep, "layer1_join_debug_pack_{0}.txt".format(rid))
    _write_json(l1_sum, {"run_id": rid})
    with open(l1_pack, "w", encoding="utf-8") as handle:
        handle.write("pack\n")
    qa_path = os.path.join(rep, "qa_canonical_summary_{0}.json".format(rid))
    _write_json(
        qa_path,
        {
            "run_id": rid,
            "layer1_join_debug_generated": True,
            "layer1_support_bundle_attachment_recommended": True,
            "layer1_join_debug_pack_path": l1_pack,
            "layer1_join_debug_summary_path": l1_sum,
            "layer1_join_debug_samples_path": "",
        },
    )
    tel = os.path.join(rep, "layer1_phase_c_runbook_telemetry_test.json")
    with open(tel, "w", encoding="utf-8") as handle:
        handle.write("{}\n")
    extra = build_runbook_bundle_extra_files(lab, tel)
    names = [x[0] for x in extra]
    assert os.path.basename(tel) in names
    assert "layer1_join_debug_summary_{0}.json".format(rid) in names
    assert "layer1_join_debug_pack_{0}.txt".format(rid) in names


def test_submit_telemetry_via_support_bundle_patches(monkeypatch, tmp_path):
    from MediCafe.layer1_phase_c_runbook_helper import submit_telemetry_via_support_bundle

    diag = {
        "last_discovery_ok": True,
        "last_phase_b_run_id": "b1",
        "last_manifest_sha256": "same",
        "last_ingest_manifest_sha256": "same",
        "last_phase_c_ok": False,
        "last_phase_c_error_code": "X",
        "last_phase_c_run_id": "c1",
        "last_shadow_pipeline_run_id": "shadow1",
    }
    lab = _make_lab(
        tmp_path,
        diag,
        {"run_id": "b1", "counts_by_class": {"dat": 1}, "dat_telemetry": {"dat_manifest_rows_count": 1}},
    )
    _write_json(os.path.join(lab, "reports", "ingest_write_summary_c1.json"), {"ok": False})
    tel_path = os.path.join(lab, "reports", "tel.json")
    with open(tel_path, "w", encoding="utf-8") as handle:
        handle.write("{}\n")
    doc = {"runbook_key": "phase_c_ingest_failure", "steps": []}

    def fake_collect(**kwargs):
        assert kwargs.get("extra_meta", {}).get("bundle_kind") == "layer1_phase_c_runbook"
        return os.path.join(lab, "out.zip")

    def fake_submit(**kwargs):
        assert kwargs.get("zip_path")
        return True

    import MediCafe.error_reporter as er

    monkeypatch.setattr(er, "collect_support_bundle", fake_collect)
    monkeypatch.setattr(er, "submit_support_bundle_email", fake_submit)

    ok, zp, err = submit_telemetry_via_support_bundle(
        lab,
        str(tmp_path),
        tel_path,
        doc,
        skip_interactive_reauth=True,
    )
    assert ok is True
    assert "out.zip" in zp


def test_maybe_auto_attach_adds_telemetry_to_meta(tmp_path, monkeypatch):
    from MediCafe.layer1_phase_c_runbook_helper import maybe_auto_attach_layer1_runbook_for_system_health_pack

    monkeypatch.setenv("MEDICAFE_LAYER1_RUNBOOK_AUTO_COOLDOWN_SEC", "7200")
    diag = {
        "last_discovery_ok": True,
        "last_phase_b_run_id": "b1",
        "last_manifest_sha256": "same",
        "last_ingest_manifest_sha256": "same",
        "last_phase_c_ok": False,
        "last_phase_c_error_code": "E",
        "last_phase_c_run_id": "c-auto-1",
        "last_shadow_pipeline_run_id": "sh1",
    }
    lab = _make_lab(
        tmp_path,
        diag,
        {"run_id": "b1", "counts_by_class": {"dat": 1}, "dat_telemetry": {"dat_manifest_rows_count": 1}},
    )
    _write_json(
        os.path.join(lab, "reports", "ingest_write_summary_c-auto-1.json"),
        {"ok": False, "rows_failed": 0},
    )
    extra_meta = {}
    attached = []

    def add_unique(path, alias=None):
        attached.append((alias or os.path.basename(path), path))

    ok, reason = maybe_auto_attach_layer1_runbook_for_system_health_pack(
        str(tmp_path),
        lab,
        diag,
        {},
        extra_meta,
        add_unique_file=add_unique,
        python_exe=sys.executable,
        progress_callback=None,
    )
    assert ok is True
    assert reason == "attached"
    assert isinstance(extra_meta.get("layer1_phase_c_runbook_auto"), dict)
    assert extra_meta.get("layer1_phase_c_runbook_auto", {}).get("runbook_key") == "phase_c_ingest_failure"
    assert len(attached) >= 1


def test_maybe_auto_attach_respects_cooldown(tmp_path, monkeypatch):
    from MediCafe.layer1_phase_c_runbook_helper import maybe_auto_attach_layer1_runbook_for_system_health_pack

    monkeypatch.setenv("MEDICAFE_LAYER1_RUNBOOK_AUTO_COOLDOWN_SEC", "999999")
    diag = {
        "last_discovery_ok": True,
        "last_phase_b_run_id": "b1",
        "last_manifest_sha256": "same",
        "last_ingest_manifest_sha256": "same",
        "last_phase_c_ok": False,
        "last_phase_c_error_code": "E",
        "last_phase_c_run_id": "c-auto-2",
        "last_shadow_pipeline_run_id": "sh1",
    }
    lab = _make_lab(
        tmp_path,
        diag,
        {"run_id": "b1", "counts_by_class": {"dat": 1}, "dat_telemetry": {"dat_manifest_rows_count": 1}},
    )
    _write_json(
        os.path.join(lab, "reports", "ingest_write_summary_c-auto-2.json"),
        {"ok": False},
    )

    def add_unique(path, alias=None):
        pass

    extra_meta1 = {}
    ok1, _ = maybe_auto_attach_layer1_runbook_for_system_health_pack(
        str(tmp_path), lab, diag, {}, extra_meta1, add_unique_file=add_unique, python_exe=sys.executable
    )
    assert ok1 is True
    extra_meta2 = {}
    ok2, r2 = maybe_auto_attach_layer1_runbook_for_system_health_pack(
        str(tmp_path), lab, diag, {}, extra_meta2, add_unique_file=add_unique, python_exe=sys.executable
    )
    assert ok2 is False
    assert "cooldown" in str(r2)


def test_maybe_auto_attach_disabled_by_env(tmp_path, monkeypatch):
    from MediCafe.layer1_phase_c_runbook_helper import maybe_auto_attach_layer1_runbook_for_system_health_pack

    monkeypatch.setenv("MEDICAFE_LAYER1_RUNBOOK_AUTO", "0")
    diag = {
        "last_discovery_ok": True,
        "last_phase_b_run_id": "b1",
        "last_manifest_sha256": "same",
        "last_ingest_manifest_sha256": "same",
        "last_phase_c_ok": False,
        "last_phase_c_run_id": "c-auto-3",
    }
    lab = _make_lab(
        tmp_path,
        diag,
        {"run_id": "b1", "counts_by_class": {"dat": 1}, "dat_telemetry": {"dat_manifest_rows_count": 1}},
    )
    _write_json(os.path.join(lab, "reports", "ingest_write_summary_c-auto-3.json"), {"ok": False})

    ok, r = maybe_auto_attach_layer1_runbook_for_system_health_pack(
        str(tmp_path), lab, diag, {}, {}, add_unique_file=lambda p, alias=None: None, python_exe=sys.executable
    )
    assert ok is False
    assert "disabled" in str(r)
