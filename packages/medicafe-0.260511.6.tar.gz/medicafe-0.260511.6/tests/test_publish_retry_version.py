# -*- coding: utf-8 -*-
"""Tests for tools/publish_retry_version.py (PyPI publish retry version resolution)."""

import pytest

from tools.publish_retry_version import (
    bump_and_write_sources,
    bump_date_based_version,
    distribution_versions_from_dist,
    resolve_base_version_for_retry,
)


def test_resolve_prefers_dist_wheel_over_setup(tmp_path):
    repo = tmp_path / "repo"
    dist = repo / "dist"
    repo.mkdir()
    dist.mkdir()
    (repo / "setup.py").write_text('version="0.260501.1"', encoding="utf-8")
    (dist / "medicafe-0.260501.7-py3-none-any.whl").write_text("", encoding="utf-8")

    assert resolve_base_version_for_retry(dist, repo) == "0.260501.7"


def test_resolve_picks_max_when_multiple_wheels(tmp_path):
    repo = tmp_path / "repo"
    dist = repo / "dist"
    repo.mkdir()
    dist.mkdir()
    (repo / "setup.py").write_text('version="0.260501.99"', encoding="utf-8")
    (dist / "medicafe-0.260501.3-py3-none-any.whl").write_text("", encoding="utf-8")
    (dist / "medicafe-0.260501.8-py2.py3-none-any.whl").write_text("", encoding="utf-8")

    assert resolve_base_version_for_retry(dist, repo) == "0.260501.8"


def test_resolve_falls_back_to_setup_when_dist_empty(tmp_path):
    repo = tmp_path / "repo"
    dist = repo / "dist"
    repo.mkdir()
    dist.mkdir()
    (repo / "setup.py").write_text(
        'setup(name="x", version="0.260502.4",)', encoding="utf-8"
    )

    assert resolve_base_version_for_retry(dist, repo) == "0.260502.4"


def test_distribution_versions_includes_sdist(tmp_path):
    dist = tmp_path / "dist"
    dist.mkdir()
    (dist / "medicafe-0.260503.2.tar.gz").write_text("", encoding="utf-8")

    assert distribution_versions_from_dist(dist) == ["0.260503.2"]


def test_bump_and_write_sources_prefers_dist(tmp_path):
    repo = tmp_path / "repo"
    dist = repo / "dist"
    repo.mkdir()
    dist.mkdir()
    (repo / "setup.py").write_text(
        "from setuptools import setup\nsetup(name='medicafe', version='0.260505.1')\n",
        encoding="utf-8",
    )
    for rel in ("MediCafe/__init__.py", "MediBot/__init__.py", "MediLink/__init__.py"):
        p = repo / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text('__version__ = "0.260505.1"\n', encoding="utf-8")
    (dist / "medicafe-0.260505.4-py3-none-any.whl").write_text("", encoding="utf-8")

    bump_and_write_sources(repo, dist)

    setup_text = (repo / "setup.py").read_text(encoding="utf-8")
    assert 'version="0.260505.5"' in setup_text
    assert (repo / "MediCafe/__init__.py").read_text(encoding="utf-8").strip() == '__version__ = "0.260505.5"'


def test_bump_date_based_version():
    assert bump_date_based_version("0.260504.9") == "0.260504.10"


def test_bump_rejects_non_date_based():
    with pytest.raises(SystemExit):
        bump_date_based_version("1.2.3")
