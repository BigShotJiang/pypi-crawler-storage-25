import json

from unittest.mock import patch


SAMPLE_X12 = (
    "ISA*00*          *00*          *ZZ*SENDER         *ZZ*RECEIVER       *260508*1425*^*00501*1*0*P*:~"
    "GS*HC*SENDER*RECEIVER*20260508*1425*1*X*005010X222A1~"
    "ST*837*0001*005010X222A1~"
    "NM1*85*1*OLIVER-VIDAUD*RAFAEL****XX*1942376918~"
    "REF*EI*123456789~"
    "NM1*IL*1*CHARTER*DEBRA****MI*ABC12345~"
    "DMG*D8*19500101*F~"
    "NM1*PR*2*UNITED HEALTH CARE*****PI*87726~"
    "CLM*CHADE000043026*450***11:B:1*Y*A*Y*Y~"
    "HI*ABK:H2510~"
    "NM1*82*1*BOLES*STEVEN****XX*1114031507~"
    "PRV*PE*PXC*363LA2200X~"
    "LX*1~"
    "SV1*HC:66984:24*450*MJ*15***1~"
    "DTP*472*D8*20260430~"
    "SE*15*0001~"
)


class FakeClient(object):
    config = {
        "MediLink_Config": {
            "billing_provider_tin": "123456789",
            "local_storage_path": "",
        }
    }


def test_build_probe_context_extracts_provider_and_claim_fields():
    from MediCafe.optumai_submission_probe import build_probe_context

    response = {
        "statuscode": "400",
        "responseType": "837999",
        "transactionId": "8842177824761333",
        "x12ResponseData": "ST*999~IK5*A~AK9*A*1*1*1~",
        "message": "Validation failed [reason=provider_sequence_missing]",
    }

    context = build_probe_context(SAMPLE_X12, response)

    assert context["payer_id"] == "87726"
    assert context["claim_number"] == "CHADE000043026"
    assert context["transactionId"] == "8842177824761333"
    assert context["member_id"] == "ABC12345"
    assert context["member_dob"] == "01/01/1950"
    assert context["service_start_date"] == "04/30/2026"
    assert context["billing_provider_npi"] == "1942376918"
    assert context["rendering_provider_npi"] == "1114031507"
    assert context["rendering_taxonomy"] == "363LA2200X"
    assert context["has_999"] is True


def test_probe_runs_277ca_for_provider_sequence_400_with_transaction_id():
    from MediCafe.optumai_submission_probe import probe_optumai_submission_context

    response = {
        "statuscode": "400",
        "responseType": "837999",
        "transactionId": "8842177824761333",
        "x12ResponseData": "ST*999~IK5*A~AK9*A*1*1*1~",
        "message": "Validation failed [reason=provider_sequence_missing]",
    }

    client = FakeClient()
    with patch(
        "MediCafe.claim_actions_adapter.search_277ca_via_optumai",
        return_value={
            "statuscode": "200",
            "message": "277CA found",
            "responseType": "837277",
            "x12ResponseData": "ST*277*0001~STC*A1:19~",
        },
    ) as mock_search:
        report = probe_optumai_submission_context(
            client,
            x12_request_data=SAMPLE_X12,
            submission_response=response,
            include_member_search=False,
            include_provider_search=False,
            include_local_remittance=False,
        )

    mock_search.assert_called_once_with(client, "8842177824761333", "87726")
    assert report["classification"] == "ack_277ca_retrieved"
    assert report["recommendation"]["operator_status"] == "processed_despite_provider_validation"
    assert report["recommendation"]["recommended_action"] == "do_not_resubmit_track_downstream"
    assert report["recommendation"]["downstream_processing_confirmed"] is True
    assert report["probes"]["search277CA"]["has_x12"] is True


def test_probe_classifies_member_search_claim_when_277ca_has_no_payload():
    from MediCafe.optumai_submission_probe import probe_optumai_submission_context

    response = {
        "statuscode": "400",
        "responseType": "837999",
        "transactionId": "8842177824761333",
        "x12ResponseData": "ST*999~IK5*A~AK9*A*1*1*1~",
        "message": "Validation failed [reason=provider_sequence_missing]",
    }

    with patch(
        "MediCafe.claim_actions_adapter.search_277ca_via_optumai",
        return_value={"statuscode": "404", "message": "No 277CA", "x12ResponseData": ""},
    ), patch(
        "MediCafe.api_core.get_claim_status_by_member_data",
        return_value={
            "statuscode": "200",
            "message": "Claims found",
            "claims": [{"claimNumber": "FM96902925"}],
        },
    ) as mock_member:
        report = probe_optumai_submission_context(
            FakeClient(),
            x12_request_data=SAMPLE_X12,
            submission_response=response,
            include_provider_search=False,
            include_local_remittance=False,
        )

    assert mock_member.call_args[0][1] == "87726"
    assert mock_member.call_args[0][2] == "ABC12345"
    assert mock_member.call_args[0][7] == "04/30/2026"
    assert mock_member.call_args[0][8] == "CHADE000043026"
    assert report["classification"] == "claim_found_by_member_search"
    assert report["recommendation"]["operator_status"] == "processed_despite_provider_validation"


def test_probe_matches_local_remittance_by_claim_number(tmp_path):
    from MediCafe.optumai_submission_probe import probe_optumai_submission_context

    remittance_path = tmp_path / "remittance_parsed.jsonl"
    remittance_path.write_text(
        json.dumps({
            "claim_number": "CHADE000043026",
            "payer_claim_number": "FM96902925",
            "payer_id": "87726",
            "dos": "04/30/2026",
            "status": "Processed",
        }) + "\n"
    )

    report = probe_optumai_submission_context(
        FakeClient(),
        x12_request_data=SAMPLE_X12,
        submission_response={"statuscode": "400", "responseType": "837999"},
        include_277ca=False,
        include_member_search=False,
        include_provider_search=False,
        remittance_path=str(remittance_path),
    )

    assert report["classification"] == "local_remittance_match"
    assert report["recommendation"]["operator_status"] == "processed_despite_provider_validation"
    assert report["local_remittance"]["match_count"] == 1
    assert report["local_remittance"]["matches"][0]["payer_claim_number"] == "FM96902925"


def test_write_probe_report_outputs_json_and_text(tmp_path):
    from MediCafe.optumai_submission_probe import (
        build_probe_context,
        write_probe_report,
    )

    report = {
        "schema_version": 1,
        "context": build_probe_context(
            SAMPLE_X12,
            {
                "statuscode": "400",
                "responseType": "837999",
                "transactionId": "8842177824761333",
                "x12ResponseData": "ST*999~IK5*A~AK9*A*1*1*1~",
            },
        ),
        "probes": {},
        "local_remittance": {"attempted": False, "match_count": 0, "matches": [], "path": ""},
        "classification": "accepted_999_with_transaction_only",
        "recommendation": {
            "downstream_processing_confirmed": False,
            "operator_status": "out_of_custody_unconfirmed",
            "recommended_action": "defer_resubmit_probe_later",
        },
    }

    paths = write_probe_report(report, str(tmp_path), basename="probe_test")

    assert (tmp_path / "probe_test.json").exists()
    assert (tmp_path / "probe_test.txt").exists()
    assert json.loads((tmp_path / "probe_test.json").read_text())["classification"] == (
        "accepted_999_with_transaction_only"
    )
    text = (tmp_path / "probe_test.txt").read_text()
    assert "OPTUMAI Submission Probe" in text
    assert "operator_status: out_of_custody_unconfirmed" in text


def test_recommendation_for_accepted_999_without_downstream_evidence_defers_resubmit():
    from MediCafe.optumai_submission_probe import (
        build_probe_recommendation,
        classify_probe_result,
    )

    report = {
        "context": {
            "has_999": True,
            "transactionId": "8842177824761333",
        },
        "probes": {},
        "local_remittance": {"match_count": 0},
    }
    report["classification"] = classify_probe_result(report)
    recommendation = build_probe_recommendation(report)

    assert report["classification"] == "accepted_999_with_transaction_only"
    assert recommendation["operator_status"] == "out_of_custody_unconfirmed"
    assert recommendation["recommended_action"] == "defer_resubmit_probe_later"
