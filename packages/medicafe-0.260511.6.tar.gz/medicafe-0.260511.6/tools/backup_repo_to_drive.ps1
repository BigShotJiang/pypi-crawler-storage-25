# Incremental copy of the MediCafe repo to a local or synced backup folder.
#
# Why not "post-commit" for "on push"?
# - Git has no client-side post-push hook. Common patterns:
#   (A) pre-push: run backup, then allow push to proceed.
#   (B) post-commit: runs after every local commit (often too noisy / slow for full tree copies).
#   (C) git alias: e.g. push then backup in one command.
#
# Robocopy: exit codes 0-7 are success-ish; treat 8+ as failure.
#
# Defaults are conservative:
# - .git is excluded unless -IncludeGit is supplied.
# - sensitive/runtime local assets are excluded unless -IncludeSensitiveLocalAssets is supplied.
# - -Mirror uses robocopy /MIR and can delete destination files not present in source.
#
# Examples:
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\backup_repo_to_drive.ps1 `
#     -Destination "<backup-root>\MediCafe_worktree_backup"
#
#   $env:MEDICAFE_BACKUP_DEST = "<backup-root>\MediCafe_worktree_backup"
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\backup_repo_to_drive.ps1
#
# Optional pre-push (Git for Windows, bash hook at .git/hooks/pre-push):
#   #!/bin/sh
#   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$(git rev-parse --show-toplevel)/tools/backup_repo_to_drive.ps1" || true
#
# Optional: point all clones at shared hooks (run once per machine):
#   git config core.hooksPath tools/git-hooks
#   (then add tools/git-hooks/pre-push as above; keep hooks executable.)

param(
    [string]$Source = "",
    [string]$Destination = "",
    [switch]$Mirror,
    [switch]$IncludeGit,
    [switch]$IncludeSensitiveLocalAssets,
    [switch]$WhatIf
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Fail([string]$Message) {
    Write-Host "ERROR: $Message" -ForegroundColor Red
    exit 2
}

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$defaultSource = Resolve-Path (Join-Path $here "..")
if (-not $Source) {
    $Source = $defaultSource.Path
}
if (-not $Destination) {
    $Destination = [string]$env:MEDICAFE_BACKUP_DEST
}
if (-not $Destination) {
    Fail "Set -Destination or environment variable MEDICAFE_BACKUP_DEST (e.g. under Google Drive)."
}

if (-not (Test-Path -LiteralPath $Source)) {
    Fail "Source not found: $Source"
}

$excludeDirs = @(
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".venv",
    "venv",
    "node_modules",
    ".tox",
    ".eggs",
    "*.egg-info"
)
$excludeFiles = @(
    "Log_*.log",
    "timing_history.jsonl",
    "reconciliation_report.csv",
    "reconciliation_report.json"
)

if (-not $IncludeGit) {
    $excludeDirs += ".git"
}

if (-not $IncludeSensitiveLocalAssets) {
    $excludeDirs += @(
        (Join-Path $Source "input\test\test"),
        (Join-Path $Source "lab"),
        (Join-Path $Source "reports"),
        (Join-Path $Source "reports_queue"),
        (Join-Path $Source "phase_d_dat_smoke_lab"),
        (Join-Path $Source "MediBot\DOWNLOADS"),
        (Join-Path $Source "Installers\WinSCP-Portable"),
        (Join-Path $Source "ERA_TEST_DUMP"),
        (Join-Path $Source "TEST_CLAIMS"),
        (Join-Path $Source ".cursor")
    )
    $excludeFiles += @(
        ".env",
        ".env.local",
        (Join-Path $Source "docs\INTERNAL_SECURITY_COMPLIANCE_FINDINGS.md")
    )
}

$xdArgs = @()
foreach ($d in $excludeDirs) {
    $xdArgs += @("/XD", $d)
}
$xfArgs = @()
foreach ($f in $excludeFiles) {
    $xfArgs += @("/XF", $f)
}

$flags = @(
    "/E",
    "/FFT",
    "/COPY:DAT",
    "/R:2",
    "/W:2",
    "/NFL",
    "/NDL",
    "/NP"
)
if ($Mirror) {
    $flags = @("/MIR") + $flags
}

if ($WhatIf) {
    Write-Host "WhatIf: robocopy from`n  $Source`nto`n  $Destination`nMirror=$Mirror IncludeGit=$IncludeGit IncludeSensitiveLocalAssets=$IncludeSensitiveLocalAssets"
    Write-Host "XD:" ($excludeDirs -join ", ")
    Write-Host "XF:" ($excludeFiles -join ", ")
    exit 0
}

if (-not (Test-Path -LiteralPath $Destination)) {
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null
}

$robocopyArgs = @($Source, $Destination) + $flags + $xdArgs + $xfArgs
Write-Host "Running robocopy (this may take a while on first run)..." -ForegroundColor Cyan
& robocopy.exe @robocopyArgs
$code = $LASTEXITCODE
if ($code -ge 8) {
    Fail "robocopy failed with exit code $code"
}
Write-Host "Backup finished (robocopy exit $code)." -ForegroundColor Green
exit 0
