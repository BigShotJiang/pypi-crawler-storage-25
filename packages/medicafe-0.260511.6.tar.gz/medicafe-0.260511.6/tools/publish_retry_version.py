#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Resolve and bump MediCafe PyPI distribution version for publish retries (CI).

The Windows build job may sync ``setup.py`` / ``__version__`` to match PyPI before
building, but only ``dist/*`` is uploaded. The publish job checks out unmodified
git; reading ``setup.py`` alone for retry bumps can desync from the built
artifacts and yield regressed or duplicate versions. Prefer versions parsed from
wheel/sdist filenames under ``dist/``, then fall back to ``setup.py``.
"""
import argparse
import re
import sys
from pathlib import Path

PACKAGE = "medicafe"
VERSION_RE = re.compile(r"^0\.(\d{6})\.(\d+)$")
# medicafe-0.260221.1-py3-none-any.whl / ...-cp311-...
_WHEEL_VER = re.compile(r"^" + re.escape(PACKAGE) + r"-(0\.\d{6}\.\d+)-")
_SDIST_VER = re.compile(r"^" + re.escape(PACKAGE) + r"-(0\.\d{6}\.\d+)\.tar\.gz$")
_INIT_FILES = ("MediCafe/__init__.py", "MediBot/__init__.py", "MediLink/__init__.py")


def _parse_key(version):
    match = VERSION_RE.match((version or "").strip())
    if not match:
        return None
    return (int(match.group(1)), int(match.group(2)))


def read_setup_version(repo_root):
    setup_path = Path(repo_root) / "setup.py"
    setup_text = setup_path.read_text(encoding="utf-8")
    match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', setup_text)
    if not match:
        raise SystemExit("Could not read setup.py version.")
    return match.group(1)


def distribution_versions_from_dist(dist_dir):
    """Return all date-based versions found in wheel/sdist filenames."""
    dist_path = Path(dist_dir)
    if not dist_path.is_dir():
        return []
    found = []
    for path in sorted(dist_path.iterdir()):
        if not path.is_file():
            continue
        name = path.name
        if name.endswith(".whl"):
            m = _WHEEL_VER.match(name)
            if m:
                found.append(m.group(1))
        elif name.endswith(".tar.gz"):
            m = _SDIST_VER.match(name)
            if m:
                found.append(m.group(1))
    return found


def resolve_base_version_for_retry(dist_dir, repo_root):
    """
    Version the retry bump should start from: built artifacts first, else setup.py.
    When multiple dist files disagree, use the highest date-based key.
    """
    from_dist = distribution_versions_from_dist(dist_dir)
    if from_dist:
        return max(from_dist, key=_parse_key)
    return read_setup_version(repo_root)


def bump_date_based_version(version):
    match = VERSION_RE.match(version.strip())
    if not match:
        raise SystemExit(
            "Retry bump requires date-based version format 0.YYMMDD.N; got: {0}".format(version)
        )
    return "0.{0}.{1}".format(match.group(1), int(match.group(2)) + 1)


def _write_version_file(path, pattern, replacement):
    text = path.read_text(encoding="utf-8")
    updated = re.sub(pattern, replacement, text)
    path.write_text(updated, encoding="utf-8")


def bump_and_write_sources(repo_root, dist_dir):
    repo_root = Path(repo_root)
    current = resolve_base_version_for_retry(dist_dir, repo_root)
    new_version = bump_date_based_version(current)
    print("Publish retry bump: {0} -> {1}".format(current, new_version))

    _write_version_file(
        repo_root / "setup.py",
        r'version\s*=\s*["\'][^"\']+["\']',
        'version="{0}"'.format(new_version),
    )
    for init_file in _INIT_FILES:
        path = repo_root / init_file
        _write_version_file(
            path,
            r'__version__\s*=\s*["\'][^"\']+["\']',
            '__version__ = "{0}"'.format(new_version),
        )


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.strip().split("\n")[0])
    parser.add_argument("--repo-root", default=".", help="Repository root (default: .)")
    parser.add_argument("--dist-dir", default="dist", help="Directory with wheels/sdists")
    parser.add_argument(
        "--bump-and-write",
        action="store_true",
        help="Bump date-based version from dist/setup resolution and rewrite sources",
    )
    args = parser.parse_args(argv)
    if not args.bump_and_write:
        parser.error("No action requested (use --bump-and-write)")
    bump_and_write_sources(args.repo_root, args.dist_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main() or 0)
