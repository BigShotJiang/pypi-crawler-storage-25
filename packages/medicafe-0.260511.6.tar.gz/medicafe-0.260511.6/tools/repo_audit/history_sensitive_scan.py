#!/usr/bin/env python3
"""Scan reachable Git history for likely secrets and sensitive data.

The report intentionally does not include raw matched values. It records rule
IDs, path/object evidence, redacted previews, and hashes of matched values so
findings can be de-duplicated without creating a second sensitive artifact.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import os
import re
import subprocess
import sys
from collections import Counter, defaultdict
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


DEFAULT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
ROOT = DEFAULT_ROOT


TEXT_EXTENSIONS = {
    ".bat",
    ".cfg",
    ".cmd",
    ".conf",
    ".csv",
    ".env",
    ".html",
    ".ini",
    ".js",
    ".json",
    ".log",
    ".md",
    ".ps1",
    ".py",
    ".sql",
    ".txt",
    ".xml",
    ".yaml",
    ".yml",
}

DEFAULT_EXCLUDED_CONTENT_PATHS = {
    "tools/repo_audit/history_sensitive_scan.py",
}

SENSITIVE_FILENAME_RE = re.compile(
    r"(?i)(^|[/\\])("
    r"\.env|.*\.pem|.*\.key|.*\.pfx|.*\.p12|.*id_rsa.*|.*id_dsa.*|"
    r".*credential.*|.*secret.*|.*token.*|.*password.*|.*passwd.*|"
    r".*patient.*|.*member.*|.*subscriber.*|.*tax.*|.*npi.*|.*ssn.*|"
    r".*\.sqlite|.*\.sqlite3|.*\.db|.*\.mdb|.*\.accdb|.*\.bak|.*\.dump"
    r")$"
)


RULES: Sequence[Tuple[str, re.Pattern[str]]] = (
    ("pem_private_key", re.compile(r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----")),
    ("openssh_private_key", re.compile(r"-----BEGIN OPENSSH PRIVATE KEY-----")),
    ("aws_access_key", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("google_api_key", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b")),
    ("github_token", re.compile(r"\bgh[opsru]_[0-9A-Za-z_]{30,}\b")),
    ("slack_token", re.compile(r"\bxox[baprs]-[0-9A-Za-z-]{20,}\b")),
    ("stripe_live_secret", re.compile(r"\bsk_live_[0-9A-Za-z]{20,}\b")),
    ("jwt_token", re.compile(r"\beyJ[0-9A-Za-z_\-]{10,}\.[0-9A-Za-z_\-]{10,}\.[0-9A-Za-z_\-]{10,}\b")),
    (
        "generic_secret_assignment",
        re.compile(
            r"(?i)\b(api[_-]?key|secret|token|password|passwd|client[_-]?secret|"
            r"private[_-]?key|authorization)\b\s*[:=]\s*['\"]?([^\s'\"<>]{12,})"
        ),
    ),
    (
        "email_address",
        re.compile(r"\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b", re.IGNORECASE),
    ),
    (
        "ssn_like",
        re.compile(r"\b(?!000|666|9\d\d)\d{3}[- ]?(?!00)\d{2}[- ]?(?!0000)\d{4}\b"),
    ),
    ("ein_like", re.compile(r"\b\d{2}-\d{7}\b")),
    (
        "dob_labeled",
        re.compile(r"(?i)\b(?:dob|date of birth|birthdate)\b.{0,30}\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b"),
    ),
    (
        "medical_identifier_label",
        re.compile(
            r"(?i)\b(?:mrn|medical record|member id|subscriber id|tax id|tin|ein|ssn|npi|dea)\b.{0,50}"
        ),
    ),
    (
        "us_street_address_like",
        re.compile(
            r"\b\d{1,6}\s+[A-Za-z0-9.'\-]+(?:\s+[A-Za-z0-9.'\-]+){0,5}\s+"
            r"(?:Street|St|Road|Rd|Avenue|Ave|Boulevard|Blvd|Drive|Dr|Lane|Ln|"
            r"Court|Ct|Circle|Cir|Way|Place|Pl|Terrace|Ter|Highway|Hwy)\.?\b",
            re.IGNORECASE,
        ),
    ),
)

GREP_RULE_IDS = {
    "pem_private_key",
    "openssh_private_key",
    "aws_access_key",
    "google_api_key",
    "github_token",
    "slack_token",
    "stripe_live_secret",
    "jwt_token",
    "generic_secret_assignment",
    "ssn_like",
    "ein_like",
    "dob_labeled",
    "medical_identifier_label",
    "us_street_address_like",
}

GIT_GREP_PATTERNS: Sequence[str] = (
    r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----",
    r"-----BEGIN OPENSSH PRIVATE KEY-----",
    r"\b(AKIA|ASIA)[0-9A-Z]{16}\b",
    r"\bAIza[0-9A-Za-z_\-]{35}\b",
    r"\bgh[opsru]_[0-9A-Za-z_]{30,}\b",
    r"\bxox[baprs]-[0-9A-Za-z-]{20,}\b",
    r"\bsk_live_[0-9A-Za-z]{20,}\b",
    r"\beyJ[0-9A-Za-z_\-]{10,}\.[0-9A-Za-z_\-]{10,}\.[0-9A-Za-z_\-]{10,}\b",
    r"\b(api[_-]?key|secret|token|password|passwd|client[_-]?secret|private[_-]?key|authorization)\b[[:space:]]*[:=][[:space:]]*['\"]?[^[:space:]'\"<>]{12,}",
    r"\b[0-9]{3}[- ]?[0-9]{2}[- ]?[0-9]{4}\b",
    r"\b[0-9]{2}-[0-9]{7}\b",
    r"\b(dob|date of birth|birthdate)\b.{0,30}\b[0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{2,4}\b",
    r"\b(mrn|medical record|member id|subscriber id|tax id|tin|ein|ssn|npi|dea)\b.{0,50}",
    r"\b[12][0-9]{9}\b",
    r"\b[0-9]{1,6}[[:space:]]+[A-Za-z0-9.'\-]+([[:space:]]+[A-Za-z0-9.'\-]+){0,5}[[:space:]]+(Street|St|Road|Rd|Avenue|Ave|Boulevard|Blvd|Drive|Dr|Lane|Ln|Court|Ct|Circle|Cir|Way|Place|Pl|Terrace|Ter|Highway|Hwy)\.?\b",
)


def run_git(args: Sequence[str], cwd: Optional[str] = None) -> subprocess.Popen:
    if cwd is None:
        cwd = ROOT
    return subprocess.Popen(
        ["git"] + list(args),
        cwd=cwd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def git_output(args: Sequence[str], cwd: Optional[str] = None) -> str:
    if cwd is None:
        cwd = ROOT
    proc = subprocess.Popen(
        ["git"] + list(args),
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    out, err = proc.communicate()
    if proc.returncode:
        raise RuntimeError("git {0} failed with exit {1}: {2}".format(
            " ".join(args),
            proc.returncode,
            err.decode("utf-8", "replace"),
        ))
    return out.decode("utf-8", "replace")


def utc_stamp() -> str:
    return _dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")


def sha12(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", "replace")).hexdigest()[:12]


def redact(value: str) -> str:
    if len(value) <= 8:
        return "<redacted>"
    return "{0}<redacted:{1}>".format(value[:2], len(value))


def path_evidence(paths: Sequence[str]) -> List[dict]:
    evidence = []
    for path in paths[:8]:
        normalized = path.replace("\\", "/")
        parts = [part for part in normalized.split("/") if part]
        if len(parts) > 1:
            location = parts[0]
        elif normalized == "<commit metadata>":
            location = normalized
        else:
            location = "<repo-root>"
        _, ext = os.path.splitext(normalized)
        evidence.append(
            {
                "location": location,
                "extension": ext.lower(),
                "path_sha256_12": sha12(normalized),
            }
        )
    return evidence


def decode_text(data: bytes) -> Optional[str]:
    if b"\x00" in data[:4096]:
        return None
    for encoding in ("utf-8", "utf-16", "cp1252", "latin-1"):
        try:
            text = data.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        return None
    if "\x00" in text[:2048]:
        return None
    return text


def is_probably_text_path(path: str) -> bool:
    _, ext = os.path.splitext(path.lower())
    return ext in TEXT_EXTENSIONS or not ext


def npi_checksum_valid(value: str) -> bool:
    digits = re.sub(r"\D", "", value)
    if len(digits) != 10 or digits[0] not in ("1", "2"):
        return False
    payload = "80840" + digits[:9]
    total = 0
    reverse_digits = list(map(int, reversed(payload)))
    for idx, digit in enumerate(reverse_digits):
        if idx % 2 == 0:
            doubled = digit * 2
            total += doubled - 9 if doubled > 9 else doubled
        else:
            total += digit
    check = (10 - (total % 10)) % 10
    return check == int(digits[-1])


def line_number_for_offset(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def redacted_line(text: str, match: re.Match[str]) -> str:
    start = text.rfind("\n", 0, match.start()) + 1
    end = text.find("\n", match.end())
    if end == -1:
        end = len(text)
    line = text[start:end]
    return "<redacted_match length={0} line_length={1}>".format(len(match.group(0)), len(line))


def iter_rev_list_objects() -> Iterable[Tuple[str, str]]:
    proc = subprocess.Popen(
        ["git", "rev-list", "--objects", "--all"],
        cwd=ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    assert proc.stdout is not None
    for raw in proc.stdout:
        line = raw.decode("utf-8", "replace").rstrip("\n")
        if not line:
            continue
        parts = line.split(" ", 1)
        object_id = parts[0]
        path = parts[1] if len(parts) > 1 else ""
        yield object_id, path
    err = proc.stderr.read() if proc.stderr is not None else b""
    if proc.wait() != 0:
        raise RuntimeError(err.decode("utf-8", "replace"))


def batch_check(objects: Sequence[str]) -> Dict[str, Tuple[str, int]]:
    proc = run_git(["cat-file", "--batch-check=%(objectname) %(objecttype) %(objectsize)"])
    assert proc.stdin is not None
    assert proc.stdout is not None
    payload = ("\n".join(objects) + "\n").encode("ascii")
    out, err = proc.communicate(payload)
    if proc.returncode:
        raise RuntimeError(err.decode("utf-8", "replace"))
    result = {}
    for raw_line in out.decode("ascii", "replace").splitlines():
        parts = raw_line.split()
        if len(parts) != 3:
            continue
        result[parts[0]] = (parts[1], int(parts[2]))
    return result


def batch_cat_blobs(objects: Sequence[str]) -> Iterable[Tuple[str, bytes]]:
    proc = run_git(["cat-file", "--batch"])
    assert proc.stdin is not None
    assert proc.stdout is not None
    proc.stdin.write(("\n".join(objects) + "\n").encode("ascii"))
    proc.stdin.close()
    for _ in objects:
        header = proc.stdout.readline()
        if not header:
            break
        object_id, object_type, size_text = header.decode("ascii", "replace").strip().split()[:3]
        size = int(size_text)
        data = proc.stdout.read(size)
        proc.stdout.read(1)
        if object_type == "blob":
            yield object_id, data
    err = proc.stderr.read() if proc.stderr is not None else b""
    if proc.wait() != 0:
        raise RuntimeError(err.decode("utf-8", "replace"))


def excluded_content_path(paths: Sequence[str]) -> bool:
    for path in paths:
        normalized = path.replace("\\", "/")
        if normalized in DEFAULT_EXCLUDED_CONTENT_PATHS:
            return True
    return False


def scan_text(text: str, object_id: str, paths: Sequence[str], max_findings_per_blob: int) -> List[dict]:
    if excluded_content_path(paths):
        return []
    findings = []
    seen = set()
    for rule_id, pattern in RULES:
        for match in pattern.finditer(text):
            raw = match.group(0)
            key = (rule_id, raw)
            if key in seen:
                continue
            seen.add(key)
            findings.append(
                {
                    "rule_id": rule_id,
                    "object_id": object_id,
                    "object_id_prefix": object_id[:12],
                    "path_evidence": path_evidence(paths),
                    "line": line_number_for_offset(text, match.start()),
                    "match_sha256_12": sha12(raw),
                    "redacted_preview": redacted_line(text, match),
                }
            )
            if len(findings) >= max_findings_per_blob:
                return findings
    for match in re.finditer(r"\b[12]\d{9}\b", text):
        raw = match.group(0)
        if not npi_checksum_valid(raw):
            continue
        findings.append(
            {
                "rule_id": "npi_valid_checksum",
                "object_id": object_id,
                "object_id_prefix": object_id[:12],
                "path_evidence": path_evidence(paths),
                "line": line_number_for_offset(text, match.start()),
                "match_sha256_12": sha12(raw),
                "redacted_preview": redacted_line(text, match),
            }
        )
        if len(findings) >= max_findings_per_blob:
            return findings
    return findings


def rules_for_grep_line(line: str) -> List[Tuple[str, re.Match[str]]]:
    matches = []
    for rule_id, pattern in RULES:
        if rule_id not in GREP_RULE_IDS:
            continue
        for match in pattern.finditer(line):
            matches.append((rule_id, match))
    for match in re.finditer(r"\b[12]\d{9}\b", line):
        if npi_checksum_valid(match.group(0)):
            matches.append(("npi_valid_checksum", match))
    return matches


def commit_list() -> List[str]:
    output = git_output(["rev-list", "--all"])
    return [line.strip() for line in output.splitlines() if line.strip()]


def grep_history_findings(args: argparse.Namespace) -> Tuple[List[dict], dict]:
    commits = commit_list()
    findings = []
    seen = set()
    timed_out_chunks = 0
    scanned_chunks = 0
    for idx in range(0, len(commits), args.grep_commit_batch_size):
        chunk = commits[idx : idx + args.grep_commit_batch_size]
        cmd = ["git", "grep", "-I", "-n", "-E"]
        for pattern in GIT_GREP_PATTERNS:
            cmd.extend(["-e", pattern])
        cmd.extend(chunk)
        cmd.append("--")
        proc = subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            out, err = proc.communicate(timeout=args.grep_timeout_sec)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()
            timed_out_chunks += 1
            continue
        if proc.returncode not in (0, 1):
            raise RuntimeError(err.decode("utf-8", "replace"))
        scanned_chunks += 1
        for raw_line in out.decode("utf-8", "replace").splitlines():
            parsed = re.match(r"^([0-9a-f]{40}):(.*?):(\d+):(.*)$", raw_line)
            if not parsed:
                continue
            commit, path, line_no, line = parsed.groups()
            if excluded_content_path([path]):
                continue
            for rule_id, match in rules_for_grep_line(line):
                raw = match.group(0)
                key = (rule_id, path, line_no, sha12(raw))
                if key in seen:
                    continue
                seen.add(key)
                findings.append(
                    {
                        "rule_id": rule_id,
                        "commit": commit,
                        "object_id": commit,
                        "object_id_prefix": commit[:12],
                        "path_evidence": path_evidence([path]),
                        "line": int(line_no),
                        "match_sha256_12": sha12(raw),
                        "redacted_preview": redacted_line(line, match),
                    }
                )
                if len(findings) >= args.max_grep_findings:
                    return findings, {
                        "commits": len(commits),
                        "scanned_chunks": scanned_chunks,
                        "timed_out_chunks": timed_out_chunks,
                        "truncated": True,
                    }
    return findings, {
        "commits": len(commits),
        "scanned_chunks": scanned_chunks,
        "timed_out_chunks": timed_out_chunks,
        "truncated": False,
    }


def scan_commit_metadata(max_findings: int) -> List[dict]:
    fmt = "%H%x00%an%x00%ae%x00%cn%x00%ce%x00%s%x00%b%x1e"
    output = git_output(["log", "--all", "--format={0}".format(fmt)])
    findings = []
    for record in output.split("\x1e"):
        if not record.strip():
            continue
        parts = record.split("\x00", 6)
        if len(parts) < 7:
            continue
        commit, author_name, author_email, committer_name, committer_email, subject, body = parts
        text = "\n".join([author_name, author_email, committer_name, committer_email, subject, body])
        for finding in scan_text(text, commit, ["<commit metadata>"], 8):
            finding["commit"] = commit
            finding["object_id"] = commit
            finding["object_id_prefix"] = commit[:12]
            findings.append(finding)
            if len(findings) >= max_findings:
                return findings
    return findings


def scan_sensitive_filenames(max_paths_per_object: int) -> Tuple[List[dict], int]:
    object_paths: Dict[str, List[str]] = defaultdict(list)
    filename_findings = []
    object_count = 0
    for object_id, path in iter_rev_list_objects():
        object_count += 1
        if path and len(object_paths[object_id]) < max_paths_per_object:
            object_paths[object_id].append(path)
        if path and SENSITIVE_FILENAME_RE.search(path):
            filename_findings.append(
                {
                    "rule_id": "sensitive_filename",
                    "object_id": object_id,
                    "object_id_prefix": object_id[:12],
                    "paths": [path],
                    "path_evidence": path_evidence([path]),
                    "match_sha256_12": sha12(path),
                    "redacted_preview": redact(os.path.basename(path)),
                }
            )
    return filename_findings, object_count


def build_grep_report(args: argparse.Namespace) -> dict:
    filename_findings, object_count = scan_sensitive_filenames(args.max_paths_per_object)
    content_findings, grep_stats = grep_history_findings(args)
    metadata_findings = scan_commit_metadata(args.max_metadata_findings)
    all_findings = filename_findings + content_findings + metadata_findings
    counts = Counter(finding["rule_id"] for finding in all_findings)
    return {
        "schema_version": 1,
        "generated_at_utc": _dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "repo_root": ROOT,
        "scan_policy": {
            "mode": "grep",
            "raw_values_included": False,
            "max_grep_findings": args.max_grep_findings,
            "note": "Fast pass scans commit trees with high-signal regexes plus sensitive filenames and commit metadata.",
        },
        "summary": {
            "rev_list_object_rows": object_count,
            "scanned_commits": grep_stats["commits"],
            "scanned_grep_chunks": grep_stats["scanned_chunks"],
            "timed_out_grep_chunks": grep_stats["timed_out_chunks"],
            "grep_findings_truncated": grep_stats["truncated"],
            "finding_count": len(all_findings),
            "finding_count_by_rule": dict(sorted(counts.items())),
            "sensitive_large_path_count": 0,
        },
        "findings": all_findings,
        "sensitive_large_paths": [],
    }


def build_blob_report(args: argparse.Namespace) -> dict:
    object_paths: Dict[str, List[str]] = defaultdict(list)
    filename_findings = []
    object_count = 0
    for object_id, path in iter_rev_list_objects():
        object_count += 1
        if path and len(object_paths[object_id]) < args.max_paths_per_object:
            object_paths[object_id].append(path)
        if path and SENSITIVE_FILENAME_RE.search(path):
            filename_findings.append(
                {
                    "rule_id": "sensitive_filename",
                    "object_id": object_id,
                    "object_id_prefix": object_id[:12],
                    "paths": [path],
                    "path_evidence": path_evidence([path]),
                    "match_sha256_12": sha12(path),
                    "redacted_preview": redact(os.path.basename(path)),
                }
            )

    object_ids = list(object_paths.keys())
    type_size = {}
    for idx in range(0, len(object_ids), args.batch_size):
        type_size.update(batch_check(object_ids[idx : idx + args.batch_size]))

    blob_ids = []
    skipped_large = 0
    skipped_non_blob = 0
    sensitive_large_paths = []
    for object_id in object_ids:
        object_type, size = type_size.get(object_id, ("unknown", 0))
        if object_type != "blob":
            skipped_non_blob += 1
            continue
        paths = object_paths.get(object_id, [])
        if size > args.max_blob_bytes:
            skipped_large += 1
            if any(SENSITIVE_FILENAME_RE.search(path or "") for path in paths):
                sensitive_large_paths.append(
                    {
                        "object_id": object_id,
                        "object_id_prefix": object_id[:12],
                        "size_bytes": size,
                        "path_evidence": path_evidence(paths[:8]),
                    }
                )
            continue
        if paths and not any(is_probably_text_path(path) for path in paths):
            if not any(SENSITIVE_FILENAME_RE.search(path or "") for path in paths):
                continue
        blob_ids.append(object_id)

    content_findings = []
    scanned_blobs = 0
    scanned_bytes = 0
    for idx in range(0, len(blob_ids), args.batch_size):
        for object_id, data in batch_cat_blobs(blob_ids[idx : idx + args.batch_size]):
            scanned_blobs += 1
            scanned_bytes += len(data)
            text = decode_text(data)
            if text is None:
                continue
            content_findings.extend(
                scan_text(text, object_id, object_paths.get(object_id, []), args.max_findings_per_blob)
            )

    metadata_findings = scan_commit_metadata(args.max_metadata_findings)
    all_findings = filename_findings + content_findings + metadata_findings
    counts = Counter(finding["rule_id"] for finding in all_findings)

    return {
        "schema_version": 1,
        "generated_at_utc": _dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "repo_root": ROOT,
        "scan_policy": {
            "raw_values_included": False,
            "max_blob_bytes": args.max_blob_bytes,
            "max_findings_per_blob": args.max_findings_per_blob,
            "note": "Redacted previews may still include surrounding labels or harmless context.",
        },
        "summary": {
            "rev_list_object_rows": object_count,
            "unique_objects_with_paths": len(object_ids),
            "scanned_blobs": scanned_blobs,
            "scanned_bytes": scanned_bytes,
            "skipped_non_blob_objects": skipped_non_blob,
            "skipped_large_blobs": skipped_large,
            "finding_count": len(all_findings),
            "finding_count_by_rule": dict(sorted(counts.items())),
            "sensitive_large_path_count": len(sensitive_large_paths),
        },
        "findings": all_findings,
        "sensitive_large_paths": sensitive_large_paths,
    }


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=DEFAULT_ROOT)
    parser.add_argument("--mode", choices=["grep", "blob"], default="grep")
    parser.add_argument("--max-blob-bytes", type=int, default=2 * 1024 * 1024)
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--max-paths-per-object", type=int, default=12)
    parser.add_argument("--max-findings-per-blob", type=int, default=40)
    parser.add_argument("--max-metadata-findings", type=int, default=500)
    parser.add_argument("--grep-commit-batch-size", type=int, default=16)
    parser.add_argument("--grep-timeout-sec", type=int, default=90)
    parser.add_argument("--max-grep-findings", type=int, default=5000)
    parser.add_argument("--output", default=None)
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    global ROOT
    args = parse_args(argv)
    ROOT = os.path.abspath(args.repo_root)
    if args.mode == "blob":
        report = build_blob_report(args)
    else:
        report = build_grep_report(args)
    output = args.output
    if not output:
        report_dir = os.path.join(ROOT, "reports")
        if not os.path.isdir(report_dir):
            os.makedirs(report_dir)
        output = os.path.join(report_dir, "repo_history_sensitive_scan_{0}.json".format(utc_stamp()))
    with open(output, "w", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2, sort_keys=True)
        handle.write("\n")

    summary = report["summary"]
    print("history sensitive scan report: {0}".format(output))
    print("findings: {0}".format(summary["finding_count"]))
    print("finding_count_by_rule: {0}".format(json.dumps(summary["finding_count_by_rule"], sort_keys=True)))
    print("sensitive_large_path_count: {0}".format(summary["sensitive_large_path_count"]))
    return 1 if summary["finding_count"] or summary["sensitive_large_path_count"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
