#!/usr/bin/env python
"""Replay a flat XP evidence bundle through Layer 1 decision models.

This is a developer/support tool, not XP-packaged runtime code. It copies a
bundle into a temporary lab layout, runs the same readiness/evidence/runbook
models used by operator packs, prints a compact JSON result, and deletes the
temporary lab unless --keep-lab is supplied.
"""

from __future__ import print_function

import argparse
import json
import os
import shutil
import sys
import tempfile


def _read_json(path):
    with open(path, "r") as handle:
        return json.load(handle)


def _copy_bundle_to_lab(bundle_dir, lab_dir):
    reports_dir = os.path.join(lab_dir, "reports")
    if not os.path.isdir(reports_dir):
        os.makedirs(reports_dir)
    for name in os.listdir(bundle_dir):
        src = os.path.join(bundle_dir, name)
        if not os.path.isfile(src):
            continue
        shutil.copy2(src, os.path.join(reports_dir, name))
        if name in ("diagnostics_state.json", "run_cursor.json"):
            shutil.copy2(src, os.path.join(lab_dir, name))
    return reports_dir


def _first_shadow_report(bundle_dir):
    for name in os.listdir(bundle_dir):
        if name.startswith("shadow_run_report_") and name.endswith(".json"):
            return os.path.join(bundle_dir, name)
    return ""


def _build_result(bundle_dir, lab_dir, reports_dir):
    repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

    from MediCafe.evidence_manifest import build_evidence_request
    from MediCafe.evidence_manifest import resolve_evidence_manifest
    from MediCafe.layer1_readiness_model import build_layer1_readiness_model
    from MediCafe.layer1_runbook_model import build_layer1_runbook_model

    meta = _read_json(os.path.join(bundle_dir, "meta.json"))
    evidence_scope_path = os.path.join(bundle_dir, "evidence_scope.json")
    evidence_scope = _read_json(evidence_scope_path) if os.path.isfile(evidence_scope_path) else {}
    diagnostics = _read_json(os.path.join(bundle_dir, "diagnostics_state.json"))
    cursor = _read_json(os.path.join(bundle_dir, "run_cursor.json"))
    shadow_path = _first_shadow_report(bundle_dir)
    shadow = _read_json(shadow_path) if shadow_path else {}

    anchor = (
        meta.get("anchor_run_id")
        or evidence_scope.get("anchor_run_id")
        or evidence_scope.get("context_pack_anchor_run_id")
        or evidence_scope.get("artifact_run_id")
        or shadow.get("run_id")
        or meta.get("run_id")
        or ""
    )
    pack_context = {
        "anchor_run_id": anchor,
        "app_version": meta.get("app_version"),
        "anchor_shadow_report_payload": shadow,
        "pack_scope": "completed_run",
    }
    layer1 = build_layer1_readiness_model(lab_dir, reports_dir, diagnostics, pack_context)
    request = build_evidence_request(
        meta.get("bundle_kind") or "run_evidence_bundle",
        meta.get("send_source") or "",
        lab_dir,
        anchor_run_id=anchor,
        active_run_id=anchor,
        recommendation_action_kind=meta.get("recommended_action_kind") or "review_dat_qa_full_block",
        follow_recommendation_now=meta.get("follow_recommendation_now") or "send_bundle",
    )
    manifest = resolve_evidence_manifest(request)
    scope = manifest.get("scope") if isinstance(manifest.get("scope"), dict) else {}
    validation = manifest.get("validation") if isinstance(manifest.get("validation"), dict) else {}
    runbook = build_layer1_runbook_model(
        layer1,
        diagnostics,
        cursor,
        scope,
        app_version=meta.get("app_version") or "",
    )

    return {
        "bundle_dir": os.path.abspath(bundle_dir),
        "tmp_lab": os.path.abspath(lab_dir),
        "app_version": meta.get("app_version"),
        "bundle_kind": meta.get("bundle_kind"),
        "send_source": meta.get("send_source"),
        "anchor_run_id": anchor,
        "phase_run_id_map": scope.get("phase_run_id_map"),
        "layer1_status": layer1.get("layer1_readiness_status"),
        "layer1_data_status": layer1.get("layer1_data_status"),
        "layer1_evaluated": layer1.get("layer1_evaluated"),
        "layer1_current_run_id": layer1.get("layer1_current_run_id"),
        "layer1_current_blocker": layer1.get("layer1_current_blocker"),
        "historical_layer1_debug_only": layer1.get("historical_layer1_debug_only"),
        "strict_dat_integrated_count": layer1.get("layer1_dat_strict_integrated_count"),
        "relaxed_dat_keyable_count": layer1.get("layer1_dat_relaxed_keyable_count"),
        "relaxed_dat_csv_overlap_count": layer1.get("layer1_dat_relaxed_csv_overlap_count"),
        "developer_note": layer1.get("developer_note"),
        "attachment_contract_status": validation.get("attachment_contract_status"),
        "missing_required_evidence_count": len(manifest.get("missing_required_evidence") or []),
        "missing_required_evidence": manifest.get("missing_required_evidence") or [],
        "dat_payer_resolution_evidence_status": scope.get("dat_payer_resolution_evidence_status"),
        "layer1_runbook_key": runbook.get("layer1_runbook_key"),
        "layer1_runbook_action_kind": runbook.get("layer1_runbook_action_kind"),
        "layer1_runbook_reason": runbook.get("layer1_runbook_reason"),
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bundle_dir", help="Flat support/evidence bundle directory to replay.")
    parser.add_argument("--lab-dir", help="Use this lab directory instead of creating a temporary one.")
    parser.add_argument("--keep-lab", action="store_true", help="Do not delete the replay lab.")
    args = parser.parse_args(argv)

    bundle_dir = os.path.abspath(args.bundle_dir)
    if not os.path.isdir(bundle_dir):
        raise SystemExit("bundle_dir does not exist: {0}".format(bundle_dir))

    made_tmp = False
    if args.lab_dir:
        lab_dir = os.path.abspath(args.lab_dir)
        if not os.path.isdir(lab_dir):
            os.makedirs(lab_dir)
    else:
        lab_dir = tempfile.mkdtemp(prefix="mc_layer1_replay_")
        made_tmp = True

    try:
        reports_dir = _copy_bundle_to_lab(bundle_dir, lab_dir)
        result = _build_result(bundle_dir, lab_dir, reports_dir)
        print(json.dumps(result, indent=2, sort_keys=True))
    finally:
        if made_tmp and not args.keep_lab:
            shutil.rmtree(lab_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
