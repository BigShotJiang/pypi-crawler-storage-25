#!/usr/bin/env python
"""Replay XP evidence bundles into local review reports.

This is a developer-side tool. It never mutates the original bundle, never
starts the shadow pipeline, never starts DAT smoke, and never sends support
bundles. It hydrates one or more XP bundles into scratch lab layouts, runs the
same evidence manifest and Layer 1 decision models used by operator packs, and
emits a Codex-ready handoff prompt with exact paths.
"""
from __future__ import print_function

import argparse
import datetime
import json
import os
import re
import shutil
import sys
import tempfile
import zipfile


BUNDLE_MARKERS = ("meta.json", "diagnostics_state.json", "run_cursor.json", "evidence_scope.json")
STATE_NAMES = ("diagnostics_state.json", "run_cursor.json", "phase_d_dat_smoke_state.json")
REPORT_EXTENSIONS = (".json", ".txt", ".jsonl", ".csv", ".md", ".log")


def _repo_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _safe_str(value):
    if value is None:
        return ""
    try:
        return str(value)
    except Exception:
        return ""


def _safe_int(value, default=0):
    try:
        if value is None or value == "":
            return default
        return int(value)
    except Exception:
        return default


def _utc_now():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _timestamp():
    return datetime.datetime.utcnow().strftime("%Y%m%d-%H%M%S")


def _mkdir(path):
    if path and not os.path.isdir(path):
        os.makedirs(path)


def _read_json(path, default=None):
    if default is None:
        default = {}
    if not path or not os.path.isfile(path):
        return default
    try:
        with open(path, "r") as handle:
            data = json.load(handle)
        return data
    except Exception:
        return default


def _write_json(path, payload):
    with open(path, "w") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def _write_text(path, text):
    with open(path, "w") as handle:
        handle.write(text)


def _copy2(src, dst):
    parent = os.path.dirname(dst)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    shutil.copy2(src, dst)


def _looks_like_bundle_dir(path):
    if not os.path.isdir(path):
        return False
    for marker in BUNDLE_MARKERS:
        if os.path.isfile(os.path.join(path, marker)):
            return True
    try:
        for name in os.listdir(path):
            if name.startswith("shadow_run_report_") or name.startswith("qa_canonical_summary_"):
                return True
    except Exception:
        return False
    return False


def _find_bundle_dirs(parent):
    rows = []
    if not os.path.isdir(parent):
        return rows
    if _looks_like_bundle_dir(parent):
        return [os.path.abspath(parent)]
    try:
        names = sorted(os.listdir(parent))
    except Exception:
        return rows
    preferred = []
    fallback = []
    for name in names:
        path = os.path.join(parent, name)
        if not os.path.isdir(path) or not _looks_like_bundle_dir(path):
            continue
        if name.startswith("medicafe_bundle_"):
            preferred.append(os.path.abspath(path))
        else:
            fallback.append(os.path.abspath(path))
    return preferred or fallback


def _single_child_dir(path):
    try:
        names = [n for n in os.listdir(path) if os.path.isdir(os.path.join(path, n))]
    except Exception:
        return ""
    if len(names) == 1:
        return os.path.join(path, names[0])
    return ""


def discover_bundle_sources(input_path, scratch_root):
    path = os.path.abspath(input_path)
    if os.path.isfile(path) and path.lower().endswith(".zip"):
        extract_root = os.path.join(scratch_root, "zip_extract")
        _mkdir(extract_root)
        with zipfile.ZipFile(path, "r") as zf:
            zf.extractall(extract_root)
        child = _single_child_dir(extract_root)
        candidates = _find_bundle_dirs(child or extract_root)
        if candidates:
            return candidates
        return [extract_root] if _looks_like_bundle_dir(extract_root) else []
    if os.path.isdir(path):
        return _find_bundle_dirs(path)
    return []


def _sanitize_name(name):
    text = _safe_str(name).strip() or "bundle"
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text)


def _iter_files(root):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in (".git", "__pycache__")]
        for name in filenames:
            yield os.path.join(dirpath, name)


def _bundle_relative_name(bundle_dir, path):
    try:
        rel = os.path.relpath(path, bundle_dir)
    except Exception:
        rel = os.path.basename(path)
    if rel.startswith(".."):
        rel = os.path.basename(path)
    return rel


def _target_for_bundle_file(bundle_dir, src, lab_dir, reports_dir):
    rel = _bundle_relative_name(bundle_dir, src)
    base = os.path.basename(src)
    if rel == base and base in STATE_NAMES:
        return os.path.join(lab_dir, base)
    if rel.startswith("reports" + os.sep) or rel.startswith("lab" + os.sep + "reports" + os.sep):
        parts = rel.split(os.sep)
        rel = os.path.join(*parts[1:]) if parts[0] == "reports" else os.path.join(*parts[2:])
    return os.path.join(reports_dir, rel)


def _build_basename_map(lab_dir, reports_dir):
    mapping = {}
    for root in (lab_dir, reports_dir):
        if not os.path.isdir(root):
            continue
        for path in _iter_files(root):
            base = os.path.basename(path)
            mapping[base] = os.path.abspath(path)
    return mapping


def _candidate_basename(value):
    text = _safe_str(value).strip()
    if not text:
        return ""
    normalized = text.replace("\\", "/")
    if "/" not in normalized and ":" not in normalized:
        return ""
    return normalized.rstrip("/").split("/")[-1]


def _rebase_json_value(value, basename_map):
    if isinstance(value, dict):
        return dict((k, _rebase_json_value(v, basename_map)) for k, v in value.items())
    if isinstance(value, list):
        return [_rebase_json_value(v, basename_map) for v in value]
    if isinstance(value, tuple):
        return tuple(_rebase_json_value(v, basename_map) for v in value)
    if isinstance(value, str):
        base = _candidate_basename(value)
        if base and base in basename_map:
            return basename_map[base]
    return value


def hydrate_bundle(bundle_dir, lab_dir):
    reports_dir = os.path.join(lab_dir, "reports")
    _mkdir(reports_dir)
    copied = []
    for src in _iter_files(bundle_dir):
        name = os.path.basename(src)
        ext = os.path.splitext(name)[1].lower()
        if name in STATE_NAMES or ext in REPORT_EXTENSIONS or name == "meta.json" or name == "evidence_scope.json":
            dst = _target_for_bundle_file(bundle_dir, src, lab_dir, reports_dir)
            _copy2(src, dst)
            copied.append(dst)
            if name in ("diagnostics_state.json", "run_cursor.json") and os.path.dirname(dst) != lab_dir:
                _copy2(src, os.path.join(lab_dir, name))
                copied.append(os.path.join(lab_dir, name))
            if name == "phase_d_dat_smoke_state.json" and os.path.dirname(dst) != reports_dir:
                _copy2(src, os.path.join(reports_dir, name))
                copied.append(os.path.join(reports_dir, name))
    basename_map = _build_basename_map(lab_dir, reports_dir)
    for path in list(copied):
        if not path.lower().endswith(".json") or not os.path.isfile(path):
            continue
        payload = _read_json(path, default=None)
        if payload is None:
            continue
        rebased = _rebase_json_value(payload, basename_map)
        if rebased != payload:
            _write_json(path, rebased)
    return reports_dir


def _find_first(prefix, suffix, directory):
    if not directory or not os.path.isdir(directory):
        return ""
    try:
        names = sorted(os.listdir(directory))
    except Exception:
        return ""
    for name in names:
        if name.startswith(prefix) and name.endswith(suffix):
            return os.path.join(directory, name)
    return ""


def _find_by_run(prefix, run_id, suffix, directory):
    if run_id:
        path = os.path.join(directory, "{0}{1}{2}".format(prefix, run_id, suffix))
        if os.path.isfile(path):
            return path
    return _find_first(prefix, suffix, directory)


def _phase_run_ids_from_files(reports_dir):
    out = {}
    if not os.path.isdir(reports_dir):
        return out
    try:
        names = os.listdir(reports_dir)
    except Exception:
        return out
    patterns = (
        ("B", "artifact_discovery_summary_", ".json"),
        ("C", "ingest_write_summary_", ".json"),
        ("D", "qa_canonical_summary_", ".json"),
        ("E", "projection_parity_summary_", ".json"),
    )
    for phase, prefix, suffix in patterns:
        for name in sorted(names):
            if name.startswith(prefix) and name.endswith(suffix):
                out[phase] = name[len(prefix):-len(suffix)]
                break
    return out


def _phase_map_from_any(*items):
    for item in items:
        if isinstance(item, dict):
            for key in ("phase_run_id_map", "phase_run_ids", "last_shadow_pipeline_phase_run_ids"):
                data = item.get(key)
                if isinstance(data, dict):
                    out = {}
                    for p, rid in data.items():
                        phase = _safe_str(p).strip().upper()
                        val = _safe_str(rid).strip()
                        if phase and val:
                            out[phase] = val
                    if out:
                        return out
    return {}


def _first_value(*values):
    for value in values:
        text = _safe_str(value).strip()
        if text:
            return text
    return ""


def _anchor_from_payloads(meta, evidence_scope, diagnostics, cursor, shadow):
    meta_scope = meta.get("evidence_scope") if isinstance(meta.get("evidence_scope"), dict) else {}
    return _first_value(
        evidence_scope.get("anchor_run_id"),
        evidence_scope.get("context_pack_anchor_run_id"),
        evidence_scope.get("recommendation_anchor_run_id"),
        evidence_scope.get("artifact_run_id"),
        meta_scope.get("anchor_run_id"),
        meta.get("anchor_run_id"),
        meta.get("recommendation_anchor_run_id"),
        diagnostics.get("last_shadow_pipeline_run_id"),
        cursor.get("last_shadow_pipeline_run_id"),
        shadow.get("run_id"),
        meta.get("run_id"),
    )


def _bundle_kind(meta, evidence_scope):
    return _first_value(meta.get("bundle_kind"), evidence_scope.get("bundle_kind"), "run_evidence_bundle")


def _recommendation_action(meta, evidence_scope, shadow, qa_summary):
    for data in (meta, evidence_scope, shadow, qa_summary):
        if not isinstance(data, dict):
            continue
        val = _first_value(
            data.get("recommended_action_kind"),
            data.get("recommendation_action_kind"),
            data.get("layer1_runbook_action_kind"),
        )
        if val:
            return val
    contract = qa_summary.get("phase_d_developer_unblock") if isinstance(qa_summary, dict) else {}
    if isinstance(contract, dict):
        return _safe_str(contract.get("recommended_action_kind")).strip()
    return "review_dat_qa_full_block"


def _dat_counts(qa_summary, shadow):
    summary = qa_summary if isinstance(qa_summary, dict) else {}
    tel = summary.get("dat_telemetry") if isinstance(summary.get("dat_telemetry"), dict) else {}
    sh = shadow if isinstance(shadow, dict) else {}
    return {
        "selected": _safe_int(tel.get("dat_selected_count", summary.get("phase_d_dat_selected_count", sh.get("phase_d_dat_selected_count", 0))), 0),
        "qa_pass": _safe_int(tel.get("dat_qa_pass_count", summary.get("phase_d_dat_qa_pass_count", sh.get("phase_d_dat_qa_pass_count", 0))), 0),
        "qa_reject": _safe_int(tel.get("dat_qa_reject_count", summary.get("phase_d_dat_qa_reject_count", sh.get("phase_d_dat_qa_reject_count", 0))), 0),
        "canonical": _safe_int(tel.get("dat_canonical_record_count", summary.get("phase_d_dat_canonical_record_count", sh.get("phase_d_dat_canonical_record_count", 0))), 0),
        "v2_inserted": _safe_int(summary.get("phase_d_dat_v2_inserted_total", sh.get("phase_d_dat_v2_inserted_total", 0)), 0),
    }


def _milestone_verdict(qa_summary, shadow):
    counts = _dat_counts(qa_summary, shadow)
    stage = _first_value(
        qa_summary.get("phase_d_data_plane_stage") if isinstance(qa_summary, dict) else "",
        shadow.get("phase_d_data_plane_stage") if isinstance(shadow, dict) else "",
    )
    if counts["selected"] > 0 and counts["qa_pass"] > 0 and counts["canonical"] > 0:
        if stage == "milestone_ready":
            return "Milestone-ready evidence", counts, stage
        return "Partially advanced", counts, stage
    if counts["selected"] > 0 or counts["qa_pass"] > 0 or counts["canonical"] > 0:
        return "Partially advanced", counts, stage
    return "Not advanced", counts, stage


def _developer_unblock_entries(qa_summary):
    try:
        from MediCafe.phase_d_developer_unblock import evidence_report_entries_from_summary
        return evidence_report_entries_from_summary(qa_summary)
    except Exception:
        pass
    data = qa_summary if isinstance(qa_summary, dict) else {}
    entries = []
    for key in (
            "phase_d_invalid_external_id_contract_report_json_path",
            "phase_d_invalid_external_id_contract_report_txt_path"):
        path = _safe_str(data.get(key)).strip()
        if path:
            entries.append({
                "path": path,
                "archive_name": os.path.basename(path),
                "required": True,
                "contains_pii": False,
                "safe_for_bundle": True,
            })
    return entries


def _developer_unblock_status(qa_summary):
    contract = qa_summary.get("phase_d_developer_unblock") if isinstance(qa_summary, dict) else {}
    reports = _developer_unblock_entries(qa_summary)
    if (not isinstance(contract, dict) or not contract) and not reports:
        return {
            "status": "absent",
            "missing_reports": [],
            "present_reports": [],
            "recommended_action_kind": "",
            "operator_manual_review_required": False,
        }
    missing = []
    present = []
    for row in reports:
        if not isinstance(row, dict):
            continue
        path = _safe_str(row.get("path")).strip()
        name = _safe_str(row.get("archive_name")).strip() or os.path.basename(path)
        if path and os.path.isfile(path):
            present.append(name)
        elif bool(row.get("required", True)):
            missing.append(name or path)
    status = "complete"
    if missing:
        status = "degraded"
    if not reports:
        status = "not_applicable"
    return {
        "status": status,
        "missing_reports": missing,
        "present_reports": present,
        "recommended_action_kind": _safe_str(contract.get("recommended_action_kind") if isinstance(contract, dict) else "").strip(),
        "operator_manual_review_required": bool(contract.get("operator_manual_review_required", False)) if isinstance(contract, dict) else False,
        "next_predicted_stall": _safe_str(contract.get("next_predicted_stall") if isinstance(contract, dict) else "").strip(),
    }


def _smoke_status(reports_dir, anchor):
    mismatch = _find_by_run("run_evidence_smoke_anchor_mismatch_", anchor, ".txt", reports_dir)
    if mismatch:
        return {
            "verdict": "ignored_mismatch",
            "accepted_for_anchor": False,
            "ignored_smoke_mismatch": True,
            "path": mismatch,
        }
    note = _find_by_run("run_evidence_dat_smoke_note_", anchor, ".txt", reports_dir)
    state_path = os.path.join(reports_dir, "phase_d_dat_smoke_state.json")
    if not os.path.isfile(state_path):
        state_path = ""
    state = _read_json(state_path) if state_path else {}
    last_anchor = _first_value(state.get("last_requested_anchor_run_id"), state.get("anchor_run_id"), state.get("last_anchor_run_id"))
    status = _safe_str(state.get("last_status")).strip()
    report_path = _safe_str(state.get("last_report_path")).strip()
    accepted = bool(anchor and last_anchor == anchor and status in ("completed", "success", "ok"))
    if accepted:
        return {
            "verdict": "accepted_for_anchor",
            "accepted_for_anchor": True,
            "ignored_smoke_mismatch": False,
            "path": report_path or state_path,
            "last_status": status,
        }
    if state_path:
        return {
            "verdict": "state_present_not_accepted",
            "accepted_for_anchor": False,
            "ignored_smoke_mismatch": False,
            "path": state_path,
            "last_status": status,
        }
    if note:
        return {
            "verdict": "note_present",
            "accepted_for_anchor": False,
            "ignored_smoke_mismatch": False,
            "path": note,
        }
    return {
        "verdict": "not_packaged",
        "accepted_for_anchor": False,
        "ignored_smoke_mismatch": False,
        "path": "",
    }


def _coherence(anchor, phase_map, qa_summary, shadow):
    warnings = []
    d_run = _safe_str(phase_map.get("D")).strip()
    qa_run = _safe_str(qa_summary.get("run_id") if isinstance(qa_summary, dict) else "").strip()
    shadow_run = _safe_str(shadow.get("run_id") if isinstance(shadow, dict) else "").strip()
    shadow_phase = _phase_map_from_any(shadow)
    if anchor and shadow_run and shadow_run != anchor:
        warnings.append("shadow_run_id_mismatch:{0}!={1}".format(shadow_run, anchor))
    if d_run and qa_run and qa_run != d_run:
        warnings.append("phase_d_summary_run_id_mismatch:{0}!={1}".format(qa_run, d_run))
    for phase, rid in phase_map.items():
        srid = _safe_str(shadow_phase.get(phase)).strip()
        if srid and srid != rid:
            warnings.append("phase_{0}_map_shadow_mismatch:{1}!={2}".format(phase, rid, srid))
    return "review_required" if warnings else "coherent", warnings


def _original_path_for_basename(bundle_dir, path):
    base = os.path.basename(_safe_str(path).strip())
    if not base:
        return ""
    for src in _iter_files(bundle_dir):
        if os.path.basename(src) == base:
            return os.path.abspath(src)
    return _safe_str(path).strip()


def _rewrite_deleted_lab_references(result, bundle_dir):
    for key in ("qa_canonical_summary_path", "shadow_run_report_path"):
        path = _safe_str(result.get(key)).strip()
        if path:
            result[key] = _original_path_for_basename(bundle_dir, path)
    smoke = result.get("smoke")
    if isinstance(smoke, dict) and _safe_str(smoke.get("path")).strip():
        smoke["path"] = _original_path_for_basename(bundle_dir, smoke.get("path"))
    result["scratch_lab_dir"] = ""
    return result


def replay_bundle(bundle_dir, out_dir, keep_labs=False):
    repo = _repo_root()
    if repo not in sys.path:
        sys.path.insert(0, repo)

    from MediCafe.evidence_manifest import build_evidence_request
    from MediCafe.evidence_manifest import resolve_evidence_manifest
    from MediCafe.layer1_readiness_model import build_layer1_readiness_model
    from MediCafe.layer1_runbook_model import build_layer1_runbook_model

    base_name = _sanitize_name(os.path.basename(os.path.abspath(bundle_dir)))
    labs_root = os.path.join(out_dir, "labs")
    lab_dir = os.path.join(labs_root, base_name)
    if os.path.isdir(lab_dir):
        shutil.rmtree(lab_dir)
    reports_dir = hydrate_bundle(bundle_dir, lab_dir)

    meta = _read_json(os.path.join(reports_dir, "meta.json"))
    evidence_scope = _read_json(os.path.join(reports_dir, "evidence_scope.json"))
    diagnostics = _read_json(os.path.join(lab_dir, "diagnostics_state.json"))
    cursor = _read_json(os.path.join(lab_dir, "run_cursor.json"))
    shadow_path = _find_first("shadow_run_report_", ".json", reports_dir)
    shadow = _read_json(shadow_path) if shadow_path else {}
    phase_map = _phase_map_from_any(evidence_scope, meta.get("evidence_scope") if isinstance(meta.get("evidence_scope"), dict) else {}, diagnostics, cursor, shadow)
    file_phase_map = _phase_run_ids_from_files(reports_dir)
    for key, value in file_phase_map.items():
        if key not in phase_map:
            phase_map[key] = value
    anchor = _anchor_from_payloads(meta, evidence_scope, diagnostics, cursor, shadow)
    phase_d_run = _first_value(phase_map.get("D"), diagnostics.get("last_phase_d_run_id"), cursor.get("last_phase_d_run_id"))
    qa_path = _find_by_run("qa_canonical_summary_", phase_d_run, ".json", reports_dir)
    qa_summary = _read_json(qa_path) if qa_path else {}
    rec_kind = _recommendation_action(meta, evidence_scope, shadow, qa_summary)
    bundle_kind = _bundle_kind(meta, evidence_scope)

    pack_context = {
        "anchor_run_id": anchor,
        "app_version": meta.get("app_version"),
        "anchor_shadow_report_payload": shadow,
        "pack_scope": "completed_run",
    }
    layer1 = build_layer1_readiness_model(lab_dir, reports_dir, diagnostics, pack_context)
    request = build_evidence_request(
        bundle_kind,
        meta.get("send_source") or "local_replay",
        lab_dir,
        anchor_run_id=anchor,
        active_run_id=anchor,
        recommendation_action_kind=rec_kind,
        follow_recommendation_now=meta.get("follow_recommendation_now") or "send_bundle",
        phase_run_id_map=phase_map,
        phase_d_artifact_run_id=phase_d_run,
    )
    manifest = resolve_evidence_manifest(request)
    scope = manifest.get("scope") if isinstance(manifest.get("scope"), dict) else {}
    validation = manifest.get("validation") if isinstance(manifest.get("validation"), dict) else {}
    runbook = build_layer1_runbook_model(
        layer1,
        diagnostics,
        cursor,
        scope,
        app_version=meta.get("app_version") or "",
    )
    milestone, counts, stage = _milestone_verdict(qa_summary, shadow)
    unblock = _developer_unblock_status(qa_summary)
    smoke = _smoke_status(reports_dir, anchor)
    coherence_status, coherence_warnings = _coherence(anchor, phase_map, qa_summary, shadow)
    missing = manifest.get("missing_required_evidence") or []

    result = {
        "schema_version": "xp_bundle_replay_v1",
        "generated_at_utc": _utc_now(),
        "bundle_dir": os.path.abspath(bundle_dir),
        "scratch_lab_dir": os.path.abspath(lab_dir),
        "bundle_name": base_name,
        "bundle_kind": bundle_kind,
        "anchor_run_id": anchor,
        "phase_run_id_map": phase_map,
        "phase_d_artifact_run_id": phase_d_run,
        "qa_canonical_summary_path": qa_path,
        "shadow_run_report_path": shadow_path,
        "recommendation_action_kind": rec_kind,
        "coherence_status": coherence_status,
        "coherence_warnings": coherence_warnings,
        "attachment_contract_status": validation.get("attachment_contract_status"),
        "missing_required_evidence_count": len(missing),
        "missing_required_evidence": missing,
        "layer1_readiness_status": layer1.get("layer1_readiness_status"),
        "layer1_data_status": layer1.get("layer1_data_status"),
        "layer1_data_quality_status": layer1.get("layer1_data_quality_status"),
        "layer1_current_blocker": layer1.get("layer1_current_blocker"),
        "layer1_current_run_id": layer1.get("layer1_current_run_id"),
        "layer1_runbook_key": runbook.get("layer1_runbook_key"),
        "layer1_runbook_action_kind": runbook.get("layer1_runbook_action_kind"),
        "layer1_runbook_reason": runbook.get("layer1_runbook_reason"),
        "developer_unblock_status": unblock.get("status"),
        "developer_unblock": unblock,
        "smoke": smoke,
        "phase_d_data_plane_stage": stage,
        "phase_d_dat_counts": counts,
        "milestone_verdict": milestone,
        "manifest_scope": scope,
    }
    if not keep_labs:
        _rewrite_deleted_lab_references(result, bundle_dir)
        shutil.rmtree(lab_dir, ignore_errors=True)
    json_path = os.path.join(out_dir, "replay_{0}.json".format(base_name))
    md_path = os.path.join(out_dir, "replay_{0}.md".format(base_name))
    result["replay_json_path"] = os.path.abspath(json_path)
    result["replay_markdown_path"] = os.path.abspath(md_path)
    _write_json(json_path, result)
    _write_text(md_path, render_bundle_markdown(result))
    return result


def render_bundle_markdown(result):
    counts = result.get("phase_d_dat_counts") or {}
    lines = [
        "# XP Bundle Replay: {0}".format(result.get("bundle_name") or ""),
        "",
        "- bundle_dir: `{0}`".format(result.get("bundle_dir") or ""),
        "- anchor_run_id: `{0}`".format(result.get("anchor_run_id") or ""),
        "- phase_run_id_map: `{0}`".format(json.dumps(result.get("phase_run_id_map") or {}, sort_keys=True)),
        "- coherence_status: `{0}`".format(result.get("coherence_status") or ""),
        "- attachment_contract_status: `{0}`".format(result.get("attachment_contract_status") or ""),
        "- smoke_verdict: `{0}` accepted_for_anchor=`{1}` ignored_smoke_mismatch=`{2}`".format(
            (result.get("smoke") or {}).get("verdict", ""),
            (result.get("smoke") or {}).get("accepted_for_anchor", False),
            (result.get("smoke") or {}).get("ignored_smoke_mismatch", False)),
        "- layer1: status=`{0}` data_status=`{1}` data_quality_status=`{2}` blocker=`{3}`".format(
            result.get("layer1_readiness_status") or "",
            result.get("layer1_data_status") or "",
            result.get("layer1_data_quality_status") or "",
            result.get("layer1_current_blocker") or ""),
        "- developer_unblock_status: `{0}`".format(result.get("developer_unblock_status") or ""),
        "- phase_d_data_plane_stage: `{0}`".format(result.get("phase_d_data_plane_stage") or ""),
        "- DAT counts: selected=`{0}` qa_pass=`{1}` qa_reject=`{2}` canonical=`{3}` v2_inserted=`{4}`".format(
            counts.get("selected", 0), counts.get("qa_pass", 0), counts.get("qa_reject", 0),
            counts.get("canonical", 0), counts.get("v2_inserted", 0)),
        "- milestone_verdict: `{0}`".format(result.get("milestone_verdict") or ""),
        "",
    ]
    warnings = result.get("coherence_warnings") or []
    missing = result.get("missing_required_evidence") or []
    if warnings:
        lines.append("## Coherence Warnings")
        lines.extend(["- `{0}`".format(w) for w in warnings])
        lines.append("")
    if missing:
        lines.append("## Missing Required Evidence")
        for row in missing:
            if isinstance(row, dict):
                lines.append("- `{0}` reason=`{1}`".format(row.get("archive_name") or row.get("expected_path") or "", row.get("reason_code") or ""))
            else:
                lines.append("- `{0}`".format(row))
        lines.append("")
    return "\n".join(lines)


def render_summary_markdown(summary):
    lines = [
        "# XP Bundle Replay Summary",
        "",
        "- generated_at_utc: `{0}`".format(summary.get("generated_at_utc") or ""),
        "- input_path: `{0}`".format(summary.get("input_path") or ""),
        "- output_dir: `{0}`".format(summary.get("output_dir") or ""),
        "- bundle_count: `{0}`".format(len(summary.get("bundles") or [])),
        "",
        "## Bundles",
    ]
    for row in summary.get("bundles") or []:
        counts = row.get("phase_d_dat_counts") or {}
        lines.append(
            "- `{0}` anchor=`{1}` coherence=`{2}` smoke=`{3}` milestone=`{4}` DAT selected/pass/canonical/v2=`{5}/{6}/{7}/{8}` report=`{9}`".format(
                row.get("bundle_name") or "",
                row.get("anchor_run_id") or "",
                row.get("coherence_status") or "",
                (row.get("smoke") or {}).get("verdict", ""),
                row.get("milestone_verdict") or "",
                counts.get("selected", 0),
                counts.get("qa_pass", 0),
                counts.get("canonical", 0),
                counts.get("v2_inserted", 0),
                row.get("replay_markdown_path") or "",
            )
        )
    lines.append("")
    return "\n".join(lines)


def render_codex_handoff(summary):
    lines = [
        "# Codex XP Bundle Review Handoff",
        "",
        "Use the replay reports and original bundle paths below to review the XP evidence bundle with a code-review mindset.",
        "",
        "Do not browse the internet. Do not treat docs alone, smoke auto-run, cumulative totals, or packaging quality as Phase D milestone closure. Accept one pipeline anchor run_id plus distinct B/C/D/E run_ids only when the mapping is internally coherent.",
        "",
        "Required sections for the review:",
        "1. Findings",
        "2. Open questions / assumptions",
        "3. Smoke verdict: `Did not run`, `Ran but inconclusive`, `Ran and produced truthful diagnosis`, or `Ran and showed DAT-bearing breakthrough`",
        "4. Recommendation / provenance verdict: `Not trustworthy yet`, `Improved but still leaky`, or `Trustworthy for anchored review`",
        "5. Milestone verdict: `Not advanced`, `Partially advanced`, or `Milestone-ready evidence`",
        "6. Recommended next step",
        "",
        "Aggregate replay summary:",
        "- JSON: `{0}`".format(summary.get("summary_json_path") or ""),
        "- Markdown: `{0}`".format(summary.get("summary_markdown_path") or ""),
        "",
        "Bundles to review:",
    ]
    for row in summary.get("bundles") or []:
        lines.extend([
            "",
            "## {0}".format(row.get("bundle_name") or ""),
            "- original_bundle_dir: `{0}`".format(row.get("bundle_dir") or ""),
            "- replay_json: `{0}`".format(row.get("replay_json_path") or ""),
            "- replay_markdown: `{0}`".format(row.get("replay_markdown_path") or ""),
            "- anchor_run_id: `{0}`".format(row.get("anchor_run_id") or ""),
            "- phase_run_id_map: `{0}`".format(json.dumps(row.get("phase_run_id_map") or {}, sort_keys=True)),
            "- qa_canonical_summary_path: `{0}`".format(row.get("qa_canonical_summary_path") or ""),
            "- shadow_run_report_path: `{0}`".format(row.get("shadow_run_report_path") or ""),
            "- smoke_verdict: `{0}`".format((row.get("smoke") or {}).get("verdict", "")),
            "- milestone_verdict: `{0}`".format(row.get("milestone_verdict") or ""),
        ])
    lines.append("")
    return "\n".join(lines)


def build_summary(input_path, out_dir, bundle_results):
    summary_json = os.path.abspath(os.path.join(out_dir, "replay_summary.json"))
    summary_md = os.path.abspath(os.path.join(out_dir, "replay_summary.md"))
    handoff = os.path.abspath(os.path.join(out_dir, "codex_handoff_prompt.md"))
    summary = {
        "schema_version": "xp_bundle_replay_summary_v1",
        "generated_at_utc": _utc_now(),
        "input_path": os.path.abspath(input_path),
        "output_dir": os.path.abspath(out_dir),
        "summary_json_path": summary_json,
        "summary_markdown_path": summary_md,
        "codex_handoff_prompt_path": handoff,
        "bundles": bundle_results,
    }
    _write_json(summary_json, summary)
    _write_text(summary_md, render_summary_markdown(summary))
    _write_text(handoff, render_codex_handoff(summary))
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_path_pos", nargs="?", help="Bundle ZIP, bundle directory, or parent bundle directory.")
    parser.add_argument("--input", dest="input_path", help="Bundle ZIP, bundle directory, or parent bundle directory.")
    parser.add_argument("--out-dir", help="Output directory for replay reports.")
    parser.add_argument("--keep-labs", action="store_true", help="Keep hydrated scratch lab directories under the output folder.")
    args = parser.parse_args(argv)

    repo = _repo_root()
    input_path = args.input_path or args.input_path_pos or os.path.join(repo, "input", "test", "test")
    out_dir = args.out_dir or os.path.join(repo, "input", "test", "replay_reports", _timestamp())
    out_dir = os.path.abspath(out_dir)
    _mkdir(out_dir)

    scratch_root = tempfile.mkdtemp(prefix="mc_xp_replay_")
    try:
        bundles = discover_bundle_sources(input_path, scratch_root)
        results = []
        for bundle in bundles:
            results.append(replay_bundle(bundle, out_dir, keep_labs=args.keep_labs))
        summary = build_summary(input_path, out_dir, results)
    finally:
        shutil.rmtree(scratch_root, ignore_errors=True)

    print("XP bundle replay complete.")
    print("bundles={0}".format(len(summary.get("bundles") or [])))
    print("summary_json={0}".format(summary.get("summary_json_path") or ""))
    print("summary_markdown={0}".format(summary.get("summary_markdown_path") or ""))
    print("codex_handoff_prompt={0}".format(summary.get("codex_handoff_prompt_path") or ""))
    if not summary.get("bundles"):
        print("No bundle directories were found under: {0}".format(os.path.abspath(input_path)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
