#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Strict post-build artifact validation for MediCafe wheels.

Workflow:
1) Build isolated venv in a temporary directory.
2) Install built wheel from dist/ (no source-tree imports).
3) Run console script smoke test: medicafe version.
4) Validate critical import contract inside isolated environment.
5) Validate XP data-file integrity manifest against installed plain files.

This script does not write to the repository and exits non-zero on failure.
"""

from __future__ import print_function

import argparse
import glob
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile

# Ensure project root is in path for tools.build_colors
_script_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_script_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)
from tools.build_colors import bold, dim, fail, green_bold, pass_, step


REQUIRED_DATAMGMT_ATTRS = [
    'read_general_fixed_width_data',
    'read_fixed_width_data',
    'parse_fixed_width_data',
]
XP_PACKAGED_FILE_MANIFEST_SCHEMA_VERSION = 1


def run_cmd(cmd, cwd=None, env=None, timeout=300, label=None):
    if label:
        print(label)
    proc = subprocess.Popen(
        cmd,
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True,
    )
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except Exception:
        proc.kill()
        raise

    if proc.returncode != 0:
        print("  STDOUT:\n{}".format(stdout.strip()))
        print("  STDERR:\n{}".format(stderr.strip()))
        raise RuntimeError("Command failed with code {}: {}".format(proc.returncode, " ".join(cmd)))

    return stdout, stderr


def resolve_default_project_root(script_file):
    tools_dir = os.path.dirname(os.path.abspath(script_file))
    return os.path.dirname(tools_dir)


def find_wheel(dist_dir, explicit_wheel=None):
    if explicit_wheel:
        wheel_path = os.path.abspath(explicit_wheel)
        if not os.path.isfile(wheel_path):
            raise RuntimeError("Specified wheel not found: {}".format(wheel_path))
        return wheel_path

    wheels = sorted(glob.glob(os.path.join(dist_dir, '*.whl')))
    if not wheels:
        raise RuntimeError("No wheel files found in {}".format(dist_dir))
    wheels = sorted(wheels, key=lambda p: os.path.getmtime(p), reverse=True)
    return os.path.abspath(wheels[0])


def find_dist_artifacts(dist_dir, explicit_wheel=None):
    wheel_path = find_wheel(dist_dir, explicit_wheel=explicit_wheel)
    artifacts = [wheel_path]
    for pattern in ('*.tar.gz', '*.zip'):
        for path in sorted(glob.glob(os.path.join(dist_dir, pattern))):
            path = os.path.abspath(path)
            if path not in artifacts:
                artifacts.append(path)
    return artifacts


def extract_requires_python(wheel_path):
    try:
        with zipfile.ZipFile(wheel_path, 'r') as zf:
            metadata_names = [n for n in zf.namelist() if n.endswith('.dist-info/METADATA')]
            if not metadata_names:
                return ''
            metadata = zf.read(metadata_names[0]).decode('utf-8', 'replace')
    except Exception:
        return ''

    for line in metadata.splitlines():
        if line.startswith('Requires-Python:'):
            return line.split(':', 1)[1].strip()
    return ''


def normalize_archive_path(path):
    return str(path or '').replace('\\', '/')


def read_archive_member_bytes_by_suffix(artifact_path, suffix):
    target = normalize_archive_path(suffix).lstrip('/')
    normalized = normalize_archive_path(artifact_path).lower()
    try:
        if normalized.endswith('.whl') or normalized.endswith('.zip'):
            with zipfile.ZipFile(artifact_path, 'r') as archive:
                names = [normalize_archive_path(name) for name in archive.namelist() if not name.endswith('/')]
                matches = [name for name in names if name.endswith(target)]
                if len(matches) != 1:
                    raise RuntimeError("expected 1 member ending with '{}', found {}".format(target, len(matches)))
                return archive.read(matches[0])

        if normalized.endswith('.tar.gz') or normalized.endswith('.tgz') or normalized.endswith('.tar'):
            with tarfile.open(artifact_path, 'r:*') as archive:
                members = []
                for member in archive.getmembers():
                    if member.isfile() and normalize_archive_path(member.name).endswith(target):
                        members.append(member)
                if len(members) != 1:
                    raise RuntimeError("expected 1 member ending with '{}', found {}".format(target, len(members)))
                extracted = archive.extractfile(members[0])
                if extracted is None:
                    raise RuntimeError("unable to read member ending with '{}'".format(target))
                return extracted.read()

        raise RuntimeError("Unsupported artifact format: {}".format(artifact_path))
    except Exception as exc:
        raise RuntimeError("Unable to read artifact member '{}': {}".format(suffix, exc))


def preview_file_list(items, limit=20):
    preview = list(items[:limit])
    if len(items) > limit:
        preview.append('... {} more'.format(len(items) - limit))
    return '\n'.join(preview)


def validate_xp_manifest_matches_artifact(artifact_path):
    manifest_bytes = read_archive_member_bytes_by_suffix(
        artifact_path,
        'MediCafe/xp_packaged_file_manifest.json',
    )
    try:
        manifest = json.loads(manifest_bytes.decode('utf-8'))
    except Exception as exc:
        raise RuntimeError(
            "Artifact '{}' has unreadable XP packaged-file manifest: {}".format(
                os.path.basename(artifact_path),
                exc,
            )
        )

    if not isinstance(manifest, dict):
        raise RuntimeError(
            "Artifact '{}' XP packaged-file manifest must be a JSON object".format(
                os.path.basename(artifact_path)
            )
        )
    manifest_schema_version = manifest.get('schema_version')
    if manifest_schema_version != XP_PACKAGED_FILE_MANIFEST_SCHEMA_VERSION:
        raise RuntimeError(
            "Artifact '{}' has unsupported XP packaged-file manifest schema_version={} (expected {})".format(
                os.path.basename(artifact_path),
                manifest_schema_version,
                XP_PACKAGED_FILE_MANIFEST_SCHEMA_VERSION,
            )
        )
    package_name = str(manifest.get('package_name') or '')
    if package_name != 'medicafe':
        raise RuntimeError(
            "Artifact '{}' has unexpected XP packaged-file manifest package_name='{}'".format(
                os.path.basename(artifact_path),
                package_name,
            )
        )
    if 'version' not in manifest:
        raise RuntimeError(
            "Artifact '{}' XP packaged-file manifest is missing top-level version".format(
                os.path.basename(artifact_path)
            )
        )

    files = manifest.get('files') if isinstance(manifest, dict) else None
    if not isinstance(files, list) or not files:
        raise RuntimeError(
            "Artifact '{}' has empty XP packaged-file manifest".format(os.path.basename(artifact_path))
        )

    problems = []
    for row in files:
        if not isinstance(row, dict):
            problems.append('invalid_manifest_row')
            continue
        rel_path = normalize_archive_path(row.get('path')).lstrip('/')
        if not rel_path:
            problems.append('blank_manifest_path')
            continue
        try:
            data = read_archive_member_bytes_by_suffix(artifact_path, rel_path)
        except RuntimeError as exc:
            problems.append('{} missing ({})'.format(rel_path, exc))
            continue

        expected_size = int(row.get('size_bytes') or 0)
        expected_sha = str(row.get('sha256') or '')
        actual_size = len(data)
        actual_sha = hashlib.sha256(data).hexdigest()
        if expected_size != actual_size or expected_sha != actual_sha:
            problems.append(
                '{} hash/size mismatch expected {} {} actual {} {}'.format(
                    rel_path,
                    expected_sha[:16],
                    expected_size,
                    actual_sha[:16],
                    actual_size,
                )
            )

    if problems:
        raise RuntimeError(
            "Artifact '{}' XP packaged-file manifest mismatch:\n{}".format(
                os.path.basename(artifact_path),
                preview_file_list(problems),
            )
        )


def validate_xp_manifest_matches_dist_artifacts(artifact_paths):
    print(step('[1/6]') + ' Validating XP packaged-file manifest inside dist artifacts...')
    for artifact_path in artifact_paths:
        validate_xp_manifest_matches_artifact(artifact_path)
        print('  ' + pass_('PASS') + ' {}'.format(os.path.basename(artifact_path)))


def venv_python_path(venv_dir):
    if os.name == 'nt':
        return os.path.join(venv_dir, 'Scripts', 'python.exe')
    return os.path.join(venv_dir, 'bin', 'python')


def venv_console_script_path(venv_dir, script_name):
    if os.name == 'nt':
        return os.path.join(venv_dir, 'Scripts', script_name + '.exe')
    return os.path.join(venv_dir, 'bin', script_name)


def sanitized_env():
    env = os.environ.copy()
    if 'PYTHONPATH' in env:
        del env['PYTHONPATH']
    env['PIP_DISABLE_PIP_VERSION_CHECK'] = '1'
    return env


def critical_import_check_snippet(project_root):
    project_root_escaped = project_root.replace('\\', '\\\\')
    attrs_repr = repr(REQUIRED_DATAMGMT_ATTRS)
    return (
        "import os\n"
        "import MediLink.MediLink_DataMgmt as m\n"
        "project_root = os.path.normcase(os.path.abspath(r'{project_root}'))\n"
        "module_file = os.path.normcase(os.path.abspath(getattr(m, '__file__', '')))\n"
        "if module_file.startswith(project_root):\n"
        "    raise SystemExit('Imported from source tree instead of wheel: ' + module_file)\n"
        "required = {attrs}\n"
        "missing = [n for n in required if not hasattr(m, n)]\n"
        "if missing:\n"
        "    raise SystemExit('Missing required attributes: ' + ', '.join(missing))\n"
        "print('OK critical import contract')\n"
    ).format(project_root=project_root_escaped, attrs=attrs_repr)


def xp_integrity_check_snippet(project_root):
    project_root_escaped = project_root.replace('\\', '\\\\')
    return (
        "import os\n"
        "from MediCafe.xp_package_integrity import verify_installed_files\n"
        "project_root = os.path.normcase(os.path.abspath(r'{project_root}'))\n"
        "result = verify_installed_files()\n"
        "if not result.get('ok'):\n"
        "    raise SystemExit('XP packaged file integrity failed: missing={{0}} mismatched={{1}} error={{2}}'.format(result.get('missing'), result.get('mismatched'), result.get('error')))\n"
        "for row in result.get('checked_files', []):\n"
        "    installed = os.path.normcase(os.path.abspath(row.get('installed_path', '')))\n"
        "    if installed.startswith(project_root):\n"
        "        raise SystemExit('XP integrity check used source-tree file: ' + installed)\n"
        "print('OK XP packaged file integrity')\n"
    ).format(project_root=project_root_escaped)


def main():
    parser = argparse.ArgumentParser(description="MediCafe strict post-build artifact validation")
    parser.add_argument('--project-root', default=None, help='Project root path (defaults to parent of tools/)')
    parser.add_argument('--wheel', default=None, help='Explicit wheel path; defaults to newest dist/*.whl')
    args = parser.parse_args()

    project_root = args.project_root or resolve_default_project_root(__file__)
    project_root = os.path.abspath(project_root)
    dist_dir = os.path.join(project_root, 'dist')

    if not os.path.isdir(dist_dir):
        print(fail("FAIL") + " dist directory not found: {}".format(dist_dir))
        return 1

    try:
        artifact_paths = find_dist_artifacts(dist_dir, explicit_wheel=args.wheel)
        wheel_path = artifact_paths[0]
    except RuntimeError as exc:
        print(fail("FAIL") + " {}".format(exc))
        return 1
    requires_python = extract_requires_python(wheel_path)

    print(bold("MediCafe Post-Build Validation"))
    print(dim("Project root: {}".format(project_root)))
    print(dim("Wheel: {}".format(wheel_path)))
    if requires_python:
        print(dim("Wheel Requires-Python: {}".format(requires_python)))
    print(dim("Validation interpreter: {}".format(sys.executable)))
    print(dim("NOTE: Installing wheel with --ignore-requires-python for dev-machine artifact smoke testing."))

    tmp_root = tempfile.mkdtemp(prefix='medicafe_postbuild_')
    venv_dir = os.path.join(tmp_root, 'venv')
    run_dir = os.path.join(tmp_root, 'run')
    os.makedirs(run_dir)

    env = sanitized_env()

    try:
        validate_xp_manifest_matches_dist_artifacts(artifact_paths)

        run_cmd([sys.executable, '-m', 'venv', venv_dir], cwd=run_dir, env=env, timeout=300, label=step('[2/6]') + ' Creating isolated virtual environment...')
        py = venv_python_path(venv_dir)
        if not os.path.isfile(py):
            raise RuntimeError("Venv python not found: {}".format(py))

        run_cmd([py, '-m', 'pip', 'install', '--no-deps', '--ignore-requires-python', wheel_path], cwd=run_dir, env=env, timeout=300, label=step('[3/6]') + ' Installing built wheel...')

        console_script = venv_console_script_path(venv_dir, 'medicafe')
        if not os.path.isfile(console_script):
            raise RuntimeError("Console script not found after install: {}".format(console_script))
        run_cmd([console_script, 'version'], cwd=run_dir, env=env, timeout=120, label=step('[4/6]') + ' Running console script smoke test...')

        snippet = critical_import_check_snippet(project_root)
        run_cmd([py, '-c', snippet], cwd=run_dir, env=env, timeout=120, label=step('[5/6]') + ' Running critical import contract check...')

        xp_snippet = xp_integrity_check_snippet(project_root)
        run_cmd([py, '-c', xp_snippet], cwd=run_dir, env=env, timeout=120, label=step('[6/6]') + ' Running XP packaged file integrity check...')

    except RuntimeError as exc:
        print(fail("FAIL") + " {}".format(exc))
        return 1
    except Exception as exc:
        print(fail("FAIL") + " Unexpected error: {}".format(exc))
        return 1
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)

    print(green_bold("PASS Post-build artifact validation passed."))
    return 0


if __name__ == '__main__':
    sys.exit(main())
