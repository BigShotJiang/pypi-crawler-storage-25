#!/usr/bin/env python3
"""Unified repo audit CLI (registry-driven checks)."""

import argparse
import os
import sys

_TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
if _TOOLS_DIR not in sys.path:
    sys.path.insert(0, _TOOLS_DIR)

_MIN_PY = (3, 7)


def main(argv=None):
    if sys.version_info < _MIN_PY:
        sys.stderr.write(
            "repo_audit requires Python {0}.{1}+ (CI uses 3.11). Try: py -3.11 tools/repo_audit.py\n".format(
                *_MIN_PY
            )
        )
        return 2

    from repo_audit._registry import load_registered_checks, checks_for_tier
    from repo_audit._render import render_json, render_markdown, render_text

    parser = argparse.ArgumentParser(description="MediCafe deterministic repo audit")
    parser.add_argument(
        "--tier",
        default="fast",
        choices=["fast", "weekly", "monthly", "all"],
        help="Which check tier to run (default: fast)",
    )
    parser.add_argument("--check", default=None, help="Run a single check id from the registry")
    parser.add_argument(
        "--format",
        default="text",
        choices=["text", "markdown", "json"],
        dest="out_format",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit non-zero on warnings as well as failures",
    )
    parser.add_argument(
        "--json-output",
        default=None,
        help="Write JSON results to this path in addition to the primary output format",
    )
    parser.add_argument(
        "--markdown-summary",
        action="store_true",
        help="Append Markdown results to GITHUB_STEP_SUMMARY in addition to the primary output format",
    )
    args = parser.parse_args(argv)
    if args.strict:
        os.environ.setdefault("REPO_AUDIT_STRICT", "1")

    load_registered_checks()
    specs = checks_for_tier(args.tier, args.check)
    results = [spec.run() for spec in specs]

    body = {
        "text": render_text,
        "markdown": render_markdown,
        "json": render_json,
    }[args.out_format](results)

    if args.json_output:
        with open(args.json_output, "w", encoding="utf-8") as handle:
            handle.write(render_json(results))
            handle.write("\n")

    summary_path = os.environ.get("GITHUB_STEP_SUMMARY")
    wrote_primary_to_summary = False
    wrote_primary_to_stdout = False
    if summary_path and args.out_format == "markdown":
        try:
            with open(summary_path, "a", encoding="utf-8") as handle:
                handle.write(body)
                if not body.endswith("\n"):
                    handle.write("\n")
            wrote_primary_to_summary = True
        except OSError:
            sys.stdout.write(body)
            wrote_primary_to_stdout = True
    elif summary_path and args.markdown_summary:
        markdown_body = render_markdown(results)
        with open(summary_path, "a", encoding="utf-8") as handle:
            handle.write(markdown_body)
            if not markdown_body.endswith("\n"):
                handle.write("\n")

    if wrote_primary_to_summary or wrote_primary_to_stdout:
        pass
    else:
        try:
            sys.stdout.write(body)
        except UnicodeEncodeError:
            buf = getattr(sys.stdout, "buffer", None)
            if buf is not None:
                buf.write(body.encode("utf-8", errors="replace"))
            else:
                sys.stdout.write(body.encode("ascii", errors="replace").decode("ascii"))
        if body and not body.endswith("\n"):
            sys.stdout.write("\n")

    has_fail = any(r.status == "fail" for r in results)
    has_warn = any(r.status == "warn" for r in results)
    if has_fail:
        return 1
    if args.strict and has_warn:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
