# MediLink_Parser.py
import re

# Pre-compile regex patterns for better performance
_EBT_KEY_VALUE_PATTERN = re.compile(r'([^:]+):\s*(.+?)(?=\s{2,}[^:]+:|$)')
_ERA_SEGMENT_PATTERN = re.compile(r'\*')
_277_SEGMENT_PATTERN = re.compile(r'\*')

_LAST_PARSE_TELEMETRY = {}

_TEXT_REPORT_LABELS = (
    'Patient Account Number',
    'Patient Control Number',
    'Patient Name',
    'Submitter Batch ID',
    'Claim Status',
    'Claim #',
    'Payer Claim Number',
    'Payer',
    'Payer ID',
    'Member ID',
    'Service Date',
    'Date of Service',
    'Charged',
    'Allowed',
    'Paid',
    'Pt Resp',
    'Patient Responsibility',
    'Message Initiator',
    'Message Type',
    'Trace',
    'Status',
)
_TEXT_REPORT_LABEL_PATTERN = re.compile(
    r'(' + '|'.join([re.escape(label) for label in sorted(_TEXT_REPORT_LABELS, key=len, reverse=True)]) + r')\s*:',
    re.I,
)


def _new_parse_telemetry(file_type):
    return {
        'file_type': file_type,
        'record_count': 0,
        'segment_count': 0,
        'line_count': 0,
        'empty_segment_count': 0,
        'malformed_segment_count': 0,
    }


def _store_parse_telemetry(file_type, telemetry):
    safe = {}
    for key, value in telemetry.items():
        if isinstance(value, (int, float, bool)):
            safe[key] = value
        elif value is None:
            safe[key] = None
        else:
            safe[key] = str(value)
    _LAST_PARSE_TELEMETRY[file_type] = safe


def get_last_parse_telemetry(file_type=None):
    """
    Return PHI-light parser metrics from the most recent parse.
    """
    if file_type is None:
        out = {}
        for key, value in _LAST_PARSE_TELEMETRY.items():
            out[key] = dict(value)
        return out
    value = _LAST_PARSE_TELEMETRY.get(file_type)
    if value is None:
        return {}
    return dict(value)


def _split_x12_segment(segment, pattern):
    return [part.strip() for part in pattern.split(segment.strip())]


def _to_float_or_none(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _text_report_label_for(candidate):
    normalized = re.sub(r'\s+', ' ', str(candidate or '').strip()).lower()
    for label in _TEXT_REPORT_LABELS:
        if normalized == label.lower():
            return label
    return ''


def _parse_text_report_fields(line):
    """
    Parse payer text-report key/value pairs without depending on two-space
    separation between fields. Returns a list of (canonical_label, value).
    """
    matches = list(_TEXT_REPORT_LABEL_PATTERN.finditer(line or ''))
    fields = []
    for index, match in enumerate(matches):
        key = _text_report_label_for(match.group(1))
        if not key:
            continue
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(line)
        value = line[start:end].strip()
        fields.append((key, value))
    return fields


def _record_text_fields(record, line, telemetry):
    fields = _parse_text_report_fields(line)
    if fields:
        telemetry['raw_key_count'] = telemetry.get('raw_key_count', 0) + len(fields)
        for key, value in fields:
            record[key] = value
        return fields
    if ':' in line:
        telemetry['malformed_segment_count'] += 1
    return []

def parse_era_content(content, debug=False):
    extracted_data = []
    normalized_content = content.replace('~\n', '~')  # Normalize line endings
    lines = normalized_content.split('~')
    telemetry = _new_parse_telemetry('ERA')

    record = {}
    check_eft, payer_address = None, None
    payer_name = None
    allowed_amount, write_off, patient_responsibility, adjustment_amount = 0, 0, 0, 0
    clp_patient_responsibility = 0
    cas_pr_seen = False
    is_payer_section = False

    def _finish_record():
        pr = patient_responsibility
        adj = adjustment_amount
        if not cas_pr_seen and pr == 0 and clp_patient_responsibility:
            pr = clp_patient_responsibility
        if adj == 0 and (write_off > 0 or pr > 0):
            adj = write_off + pr
        record.update({
            'Payer Address': payer_address,
            'Allowed Amount': allowed_amount,
            'Write Off': write_off,
            'Patient Responsibility': pr,
            'Adjustment Amount': adj,
        })
        extracted_data.append(record)

    for line in lines:
        if not line or not line.strip():
            telemetry['empty_segment_count'] += 1
            continue
        segments = _split_x12_segment(line, _ERA_SEGMENT_PATTERN)
        tag = segments[0] if segments else ''
        if not tag:
            telemetry['empty_segment_count'] += 1
            continue
        telemetry['segment_count'] += 1

        if tag == 'TRN':
            if len(segments) > 2:
                check_eft = segments[2]  # Extract check/EFT number
            else:
                telemetry['malformed_segment_count'] += 1

        if tag == 'N1':
            if len(segments) > 2 and segments[1] == 'PR':
                is_payer_section = True  # Enter payer section
                payer_name = segments[2]
            elif len(segments) > 1 and segments[1] == 'PE':
                is_payer_section = False  # Exit payer section
            elif len(segments) <= 1:
                telemetry['malformed_segment_count'] += 1

        if is_payer_section and tag == 'N3' and len(segments) > 1:
            payer_address = segments[1]  # Extract payer address

        if tag == 'NM1':
            if record and len(segments) > 3 and segments[1] in ('QC', 'IL'):
                patient_parts = [segments[3]]
                if len(segments) > 4 and segments[4]:
                    patient_parts.append(segments[4])
                if len(segments) > 5 and segments[5]:
                    patient_parts.append(segments[5])
                record['Patient'] = ' '.join([p for p in patient_parts if p]).strip()
            elif len(segments) <= 3:
                telemetry['malformed_segment_count'] += 1
        if tag == 'CLP':
            if len(segments) < 5:
                telemetry['malformed_segment_count'] += 1
                continue
            if record:
                _finish_record()

                # Reset counters for next record
                allowed_amount, write_off, patient_responsibility, adjustment_amount = 0, 0, 0, 0
                clp_patient_responsibility = 0
                cas_pr_seen = False

            clp_status = segments[2] if len(segments) > 2 else ''
            clp_patient_responsibility = _to_float_or_none(segments[5]) if len(segments) > 5 else 0
            if clp_patient_responsibility is None:
                clp_patient_responsibility = 0
                telemetry['malformed_segment_count'] += 1
            payer_claim_number = segments[7] if len(segments) > 7 else ''

            # Start new record
            record = {
                'Check EFT': check_eft,
                'Chart Number': segments[1],
                'Payer': payer_name or '',
                'Payer Address': payer_address,
                'Amount Paid': segments[4],
                'Charge': segments[3],
                'claimStatus': clp_status,
                'Claim Status Code': clp_status,
                'payer_claim_number': payer_claim_number,
                'Payer Claim Number': payer_claim_number,
            }

        elif tag == 'CAS':
            if len(segments) < 4:
                telemetry['malformed_segment_count'] += 1
                continue
            group_code = segments[1]
            idx = 2
            parsed_any_adjustment = False
            while idx + 1 < len(segments):
                amount = _to_float_or_none(segments[idx + 1])
                if amount is None:
                    telemetry['malformed_segment_count'] += 1
                    idx += 3
                    continue
                parsed_any_adjustment = True
                if group_code == 'CO':
                    write_off += amount  # Contractual obligation
                elif group_code == 'PR':
                    patient_responsibility += amount  # Patient responsibility
                    cas_pr_seen = True
                elif group_code == 'OA':
                    adjustment_amount += amount  # Other adjustments
                idx += 3
            if not parsed_any_adjustment:
                telemetry['malformed_segment_count'] += 1

        elif tag == 'AMT':
            if len(segments) <= 2:
                telemetry['malformed_segment_count'] += 1
                continue
            if segments[1] == 'B6':
                amount = _to_float_or_none(segments[2])
                if amount is None:
                    telemetry['malformed_segment_count'] += 1
                    continue
                allowed_amount += amount  # Allowed amount

        elif tag == 'DTM':
            if len(segments) <= 2:
                telemetry['malformed_segment_count'] += 1
                continue
            if segments[1] == '232' or segments[1] == '472':
                record['Date of Service'] = segments[2]  # Service date

    # Process final record
    if record:
        _finish_record()
    telemetry['record_count'] = len(extracted_data)
    _store_parse_telemetry('ERA', telemetry)

    if debug:
        print("Parsed ERA Content:")
        for data in extracted_data:
            print(data)

    return extracted_data

def parse_277_content(content, debug=False, file_type='277'):
    segments = content.split('~')
    records = []
    current_record = {}
    segment_buffer = []
    telemetry = _new_parse_telemetry(file_type)

    def _append_message(target, text):
        if not text:
            return
        target.setdefault('messages', [])
        target['messages'].append(text)

    def _record_start(source):
        key = 'records_started_by_' + source
        telemetry[key] = telemetry.get(key, 0) + 1

    def _has_record_identity(record):
        if not record:
            return False
        return bool(record.get('Claim #') or record.get('payer_claim_number') or record.get('Claim ID'))

    for segment in segments:
        segment = segment.strip()
        if not segment:
            telemetry['empty_segment_count'] += 1
            continue
        parts = _split_x12_segment(segment, _277_SEGMENT_PATTERN)
        tag = parts[0] if parts else ''
        if not tag:
            telemetry['empty_segment_count'] += 1
            continue
        telemetry['segment_count'] += 1

        segment_buffer.append(segment)
        
        # Use TRN*2 segments as claim record boundaries (TRN*2 contains claim control number)
        if tag == 'TRN' and len(parts) > 1 and parts[1] == '2':
            # This is a claim-level TRN segment - save previous record if it has a claim number
            if current_record and _has_record_identity(current_record):
                # Save the previous record (excluding current TRN segment from its buffer)
                prev_buffer = segment_buffer[:-1] if len(segment_buffer) > 1 else []
                current_record['raw_segments'] = prev_buffer
                records.append(current_record)
                current_record = {}
                segment_buffer = [segment]  # Start new buffer with current TRN segment
            # Extract claim number from TRN*2 for the new record
            if len(parts) > 2:
                current_record['Claim #'] = parts[2]
                _record_start('trn2')
            else:
                telemetry['malformed_segment_count'] += 1
        
        if tag == 'HL':
            # Also check for patient-level HL segments (HL*4*3*PT) as record completion marker
            is_patient_level = len(parts) > 3 and parts[3] == 'PT'
            if is_patient_level and current_record and _has_record_identity(current_record):
                prev_buffer = segment_buffer[:-1] if len(segment_buffer) > 1 else []
                current_record['raw_segments'] = prev_buffer
                records.append(current_record)
                current_record = {}
                segment_buffer = [segment]
                telemetry['records_started_by_hl'] = telemetry.get('records_started_by_hl', 0) + 1

        if tag == 'NM1':
            if len(parts) > 3:
                if parts[1] == 'QC':
                    current_record['Patient'] = ' '.join([parts[3], parts[4]]) if len(parts) > 4 else parts[3]
                elif parts[1] == '41':
                    current_record['Clearing House'] = parts[3]
                elif parts[1] == 'PR':
                    current_record['Payer'] = parts[3]
                    for idx in range(4, len(parts)):
                        if parts[idx] == 'PI' and idx + 1 < len(parts):
                            current_record['Payer ID'] = parts[idx + 1]
                            current_record['payer_id'] = parts[idx + 1]
                            break
            else:
                telemetry['malformed_segment_count'] += 1
        elif tag == 'TRN' and len(parts) > 2:
            # TRN*1 is transaction set level, TRN*2 is claim level (already handled above)
            if len(parts) > 1 and parts[1] == '1':
                # Transaction set level TRN
                if len(parts) > 2:
                    current_record['Transaction ID'] = parts[2]
            elif len(parts) > 1 and parts[1] != '2':
                # Other TRN types
                if len(parts) > 2:
                    current_record['Control ID'] = parts[2]
        elif tag == 'TRN' and len(parts) <= 2:
            telemetry['malformed_segment_count'] += 1
        elif tag == 'STC' and len(parts) > 1:
            current_record['Status'] = parts[1]
            _append_message(current_record, "STC status: {}".format(parts[1]))
            if len(parts) > 4:
                current_record['Paid'] = parts[4]
                _append_message(current_record, "Paid amount: {}".format(parts[4]))
        elif tag == 'STC':
            telemetry['malformed_segment_count'] += 1
        elif tag == 'DTP' and len(parts) > 3:
            if parts[1] == '472':
                current_record['Serv.'] = parts[3]
            elif parts[1] == '050':
                current_record['Proc.'] = parts[3]
        elif tag == 'DTP':
            telemetry['malformed_segment_count'] += 1
        elif tag == 'AMT' and len(parts) > 2:
            if parts[1] == 'YU':
                current_record['Charged'] = parts[2]
            elif parts[1] in ('A8', 'AU', 'B6'):
                try:
                    add = float(parts[2])
                    prev = float(current_record.get('Allowed', '0') or '0')
                    current_record['Allowed'] = str(prev + add)
                except (ValueError, TypeError, IndexError):
                    current_record['Allowed'] = parts[2]
                    telemetry['malformed_segment_count'] += 1
        elif tag == 'AMT':
            telemetry['malformed_segment_count'] += 1
        elif tag == 'CAS' and len(parts) >= 4:
            try:
                qual = parts[1]
                amt = float(parts[3])
                if qual == 'PR':
                    prev = float(current_record.get('Pt Resp', '0') or '0')
                    current_record['Pt Resp'] = str(prev + amt)
            except (ValueError, TypeError, IndexError):
                telemetry['malformed_segment_count'] += 1
        elif tag == 'CAS':
            telemetry['malformed_segment_count'] += 1
        elif tag == 'REF' and len(parts) > 2:
            qualifier = parts[1]
            value = parts[2]
            if qualifier == '1K':
                if current_record and current_record.get('payer_claim_number') and current_record.get('payer_claim_number') != value:
                    prev_buffer = segment_buffer[:-1] if len(segment_buffer) > 1 else []
                    current_record['raw_segments'] = prev_buffer
                    records.append(current_record)
                    current_record = {}
                    segment_buffer = [segment]
                current_record['payer_claim_number'] = value
                if not current_record.get('Claim #'):
                    current_record['Claim #'] = value
                    telemetry['records_missing_claim_number_but_has_payer_claim_number'] = telemetry.get('records_missing_claim_number_but_has_payer_claim_number', 0) + 1
                _record_start('ref1k')
                _append_message(current_record, "Payer claim #: {}".format(value))
            elif qualifier == 'TJ':
                current_record['Trace'] = value
            elif qualifier == 'D9':
                current_record['Claim ID'] = value
        elif tag == 'REF':
            telemetry['malformed_segment_count'] += 1
        elif tag == 'QTY' and len(parts) > 2:
            if parts[1] == '90':
                current_record['Quantity'] = parts[2]
            elif parts[1] == 'QA':
                current_record['Adjudicated Quantity'] = parts[2]
        elif tag == 'QTY':
            telemetry['malformed_segment_count'] += 1

    if current_record:
        current_record['raw_segments'] = segment_buffer[:]
        records.append(current_record)
    telemetry['record_count'] = len(records)
    _store_parse_telemetry(file_type, telemetry)

    if debug:
        print("Parsed 277 Content:")
        for record in records:
            print(record)

    return records

def parse_277IBR_content(content, debug=False):
    return parse_277_content(content, debug, file_type='277IBR')

def parse_277EBR_content(content, debug=False):
    return parse_277_content(content, debug, file_type='277EBR')

def parse_277DPR_content(content, debug=False):
    return parse_277_content(content, debug, file_type='277DPR')

def parse_dpt_content(content, debug=False):
    extracted_data = []
    lines = content.splitlines()
    record = {}
    telemetry = _new_parse_telemetry('DPT')
    
    for line in lines:
        telemetry['line_count'] += 1
        if not line.strip():
            telemetry['empty_segment_count'] += 1
            continue
        if 'Patient Account Number:' in line:
            if record and record.get('Patient Account Number'):
                # Only save if we have a claim record (has Patient Account Number)
                extracted_data.append(record)
            record = {}  # Start new record
        
        _record_text_fields(record, line, telemetry)
    
    if record and record.get('Patient Account Number'):
        extracted_data.append(record)  # Add final record only if it has claim data
    telemetry['record_count'] = len(extracted_data)
    _store_parse_telemetry('DPT', telemetry)

    if debug:
        print("Parsed DPT Content:")
        for data in extracted_data:
            print(data)

    return extracted_data

def parse_ebt_content(content, debug=False):
    extracted_data = []  # List to hold all extracted records
    lines = content.splitlines()  # Split the content into individual lines
    record = {}  # Dictionary to hold the current record being processed
    telemetry = _new_parse_telemetry('EBT')
    
    for line in lines:
        telemetry['line_count'] += 1
        if not line.strip():
            telemetry['empty_segment_count'] += 1
            continue
        # Check for the start of a new record based on the presence of 'Patient Name'
        if 'Patient Name:' in line and record:
            ebt_post_processor(record)  # Process the current record before adding it to the list
            extracted_data.append(record)  # Add the completed record to the list
            record = {}  # Reset the record for the next entry

        _record_text_fields(record, line, telemetry)

    # Process and add the last record if it exists
    if record:
        ebt_post_processor(record)  # Final processing of the last record
        extracted_data.append(record)  # Add the last record to the list
    telemetry['record_count'] = len(extracted_data)
    _store_parse_telemetry('EBT', telemetry)

    # Debug output to show parsed data if debugging is enabled
    if debug:
        print("Parsed EBT Content:")
        for data in extracted_data:
            print(data)

    return extracted_data  # Return the list of extracted records

def ebt_post_processor(record):
    # Process the 'Message Initiator' field to separate it from 'Message Type'
    if 'Message Initiator' in record and 'Message Type:' in record['Message Initiator']:
        parts = record['Message Initiator'].split('Message Type:')  # Split the string into parts
        record['Message Initiator'] = parts[0].strip()  # Clean up the 'Message Initiator'
        record['Message Type'] = parts[1].strip()  # Clean up the 'Message Type'

def parse_ibt_content(content, debug=False):
    extracted_data = []
    lines = content.splitlines()
    record = {}
    pending_value_continuation = None  # Track if we're waiting for a value continuation
    telemetry = _new_parse_telemetry('IBT')
    
    for i, line in enumerate(lines):
        telemetry['line_count'] += 1
        line = line.strip()
        if not line:
            telemetry['empty_segment_count'] += 1
            # Handle continuation: if we have a pending value and this is an empty/whitespace line,
            # check if next line continues the value
            if pending_value_continuation and i + 1 < len(lines):
                next_line = lines[i + 1].strip()
                if next_line and ':' not in next_line:
                    # Next line continues the value
                    continue
            pending_value_continuation = None
            continue
            
        # Check for the start of a new record based on 'Submitter Batch ID:'
        if 'Submitter Batch ID:' in line:
            if record and record.get('Patient Control Number'):
                # Only save if we have a claim record (has Patient Control Number)
                extracted_data.append(record)
            record = {}  # Start new record
            pending_value_continuation = None
        
        # Use label-aware parsing to find multiple key-value pairs per line.
        matches = _parse_text_report_fields(line)
        if matches:
            telemetry['raw_key_count'] = telemetry.get('raw_key_count', 0) + len(matches)
            for key, value in matches:
                # Check if this might be a continuation of previous value
                if pending_value_continuation:
                    record[pending_value_continuation] = record[pending_value_continuation] + value
                    pending_value_continuation = None
                else:
                    record[key] = value
                    # Check if value looks incomplete (short numeric value that might continue)
                    if value and value[-1].isdigit() and len(value) < 15 and i + 1 < len(lines):
                        next_line = lines[i + 1].strip() if i + 1 < len(lines) else ''
                        if next_line and ':' not in next_line and next_line.isdigit():
                            pending_value_continuation = key
        elif pending_value_continuation:
            # This line continues the previous value
            record[pending_value_continuation] = record[pending_value_continuation] + line
            pending_value_continuation = None
        elif ':' in line:
            telemetry['malformed_segment_count'] += 1
    
    if record and record.get('Patient Control Number'):
        extracted_data.append(record)  # Add final record only if it has claim data
    telemetry['record_count'] = len(extracted_data)
    _store_parse_telemetry('IBT', telemetry)

    if debug:
        print("Parsed IBT Content:")
        for data in extracted_data:
            print(data)

    return extracted_data

def parse_999_content(content, debug=False):
    """
    Minimal 999 Implementation Acknowledgment parser.
    Extracts overall transaction set acknowledgment (AK9) and per-set (AK5) statuses when available.
    Returns a list with a single summary dict plus optional per-set entries.
    """
    records = []
    segments = content.split('~')
    overall_status = None
    functional_id = None
    control_numbers = []  # AK2 ST02 values
    per_set_statuses = []  # List of {'set_control': str, 'status': str}

    for seg in segments:
        parts = seg.split('*')
        if not parts or not parts[0]:
            continue
        tag = parts[0]
        if tag == 'AK1' and len(parts) > 1:
            functional_id = parts[1]
        elif tag == 'AK2' and len(parts) > 2:
            # Transaction Set Acknowledgment - capture ST02 control number
            control_numbers.append(parts[2])
        elif tag == 'AK5' and len(parts) > 1:
            # Transaction Set Response Trailer - status code in AK5-01 (A, E, R)
            status_code = parts[1]
            per_set_statuses.append({'status': status_code})
        elif tag == 'AK9' and len(parts) > 1:
            # Functional Group Response Trailer - overall status in AK9-01
            overall_status = parts[1]

    # Map X12 codes to friendly text
    status_map = {'A': 'Accepted', 'E': 'Accepted with Errors', 'R': 'Rejected'}
    overall_text = status_map.get(overall_status, overall_status or '')

    summary = {
        'Ack Type': '999',
        'Functional ID': functional_id or '',
        'Status': overall_text,
        'Sets Acknowledged': len(control_numbers) if control_numbers else 0,
    }
    records.append(summary)

    # Optionally include per-set detail rows
    for idx, st in enumerate(per_set_statuses):
        detail = {
            'Ack Type': '999',
            'Functional ID': functional_id or '',
            'Set #': str(idx + 1),
            'Status': status_map.get(st.get('status', ''), st.get('status', '')),
        }
        # Claim # not available in 999; leave out
        records.append(detail)

    if debug:
        print('Parsed 999 Content:')
        for r in records:
            print(r)
    return records
