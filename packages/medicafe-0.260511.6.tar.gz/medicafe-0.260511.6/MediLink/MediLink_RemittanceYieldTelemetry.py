import hashlib
import io
import json
import os
import time


SCHEMA_VERSION = 1
REPORT_PREFIX = 'remittance_parse_yield_'
LATEST_JSON_NAME = 'remittance_parse_yield_latest.json'
LATEST_TXT_NAME = 'remittance_parse_yield_latest.txt'
EVENTS_JSONL_NAME = 'remittance_parse_yield_events.jsonl'


def _utc_now_epoch():
    return int(time.time())


def _utc_stamp(epoch=None):
    if epoch is None:
        epoch = _utc_now_epoch()
    return time.strftime('%Y%m%dT%H%M%SZ', time.gmtime(epoch))


def _safe_str(value):
    if value is None:
        return ''
    try:
        return str(value)
    except Exception:
        return ''


def _hash_prefix(value, length=12):
    text = _safe_str(value)
    if not text:
        return ''
    try:
        return hashlib.sha1(text.encode('utf-8')).hexdigest()[:length]
    except Exception:
        return ''


def _public_run_id(run_id):
    text = _safe_str(run_id).strip()
    if not text:
        return _utc_stamp()
    if text.startswith('rid_'):
        return text
    if len(text) == 16 and text[8] == 'T' and text.endswith('Z'):
        return text
    return 'rid_' + _hash_prefix(text, length=16)


def _file_key(path_or_name):
    text = _safe_str(path_or_name)
    if not text:
        return ''
    try:
        text = os.path.basename(text)
    except Exception:
        pass
    return text.lower()


def _extension(path_or_name):
    text = _safe_str(path_or_name)
    try:
        ext = os.path.splitext(text)[1].lower()
    except Exception:
        ext = ''
    return ext


def _source_type_from_extension(ext):
    clean = _safe_str(ext).strip().lower()
    if clean.startswith('.'):
        clean = clean[1:]
    if not clean:
        return 'UNKNOWN'
    return clean.upper()


def _checksum_prefix(path, length=16):
    if not path or not os.path.isfile(path):
        return ''
    try:
        hasher = hashlib.sha1()
        with open(path, 'rb') as handle:
            for chunk in iter(lambda: handle.read(8192), b''):
                hasher.update(chunk)
        return hasher.hexdigest()[:length]
    except Exception:
        return ''


def _size_bytes(path):
    if not path or not os.path.isfile(path):
        return None
    try:
        return os.path.getsize(path)
    except Exception:
        return None


def _safe_int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _ensure_dir(path):
    if path and not os.path.isdir(path):
        os.makedirs(path)


def _write_text_replace(path, text):
    directory = os.path.dirname(path)
    _ensure_dir(directory)
    tmp = path + '.tmp.{0}.{1}'.format(os.getpid(), int(time.time() * 1000))
    with io.open(tmp, 'w', encoding='utf-8') as handle:
        handle.write(text)
    try:
        if os.path.exists(path):
            os.remove(path)
        os.rename(tmp, path)
    except Exception:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        raise


def _append_jsonl(path, row):
    directory = os.path.dirname(path)
    _ensure_dir(directory)
    with io.open(path, 'a', encoding='utf-8') as handle:
        handle.write(json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n')


def _new_totals():
    return {
        'endpoint_total': 0,
        'endpoint_winscp': 0,
        'endpoint_api': 0,
        'endpoint_processed': 0,
        'endpoint_no_files': 0,
        'endpoint_downloaded_no_records': 0,
        'endpoint_validated': 0,
        'endpoint_skipped': 0,
        'endpoint_offline': 0,
        'endpoint_error': 0,
        'downloaded_files': 0,
        'supported_move_files': 0,
        'unsupported_move_files': 0,
        'moved_files': 0,
        'missing_source_files': 0,
        'move_error_files': 0,
        'decode_selected_files': 0,
        'decode_success_files': 0,
        'decode_zero_record_files': 0,
        'decode_error_files': 0,
        'decoded_records': 0,
        'parser_malformed_segments': 0,
        'format_duplicate_suppressed': 0,
        'format_missing_key_suppressed': 0,
        'translated_files': 0,
        'ingest_attempted_files': 0,
        'ingest_success_files': 0,
        'ingest_exception_files': 0,
        'normalized_records': 0,
        'normalized_zero_files': 0,
        'matched_rows': 0,
        'unmatched_rows': 0,
        'parser_named_rows': 0,
        'source_blank_patient_names': 0,
        'patient_names_backfilled': 0,
        'patient_names_still_blank': 0,
        'missing_claim_number_rows': 0,
        'fallback_correlated_missing_claim_rows': 0,
        'ledger_attempted_files': 0,
        'ledger_success_files': 0,
        'ledger_exception_files': 0,
    }


class RemittanceParseYieldReport(object):
    def __init__(self, local_storage_path, run_id=None, emit_events=False):
        self.local_storage_path = local_storage_path or '.'
        self.reports_dir = os.path.join(self.local_storage_path, 'reports')
        self.telemetry_dir = os.path.join(self.local_storage_path, 'telemetry')
        self.run_id = _public_run_id(run_id) if run_id else _utc_stamp()
        self.emit_events = bool(emit_events)
        self.started_at_epoch = _utc_now_epoch()
        self.files = {}
        self.sequence = 0
        self.totals = _new_totals()
        self.endpoint_hashes = {}
        self.endpoint_results = {}

    def _entry(self, path_or_name, endpoint_key=None):
        key = _file_key(path_or_name)
        if not key:
            self.sequence += 1
            key = 'unknown_{0}'.format(self.sequence)
        entry = self.files.get(key)
        if entry is None:
            ext = _extension(path_or_name)
            self.sequence += 1
            entry = {
                'file_index': self.sequence,
                'extension': ext,
                'source_type': _source_type_from_extension(ext),
                'endpoint_hash_prefix': '',
                'size_bytes': None,
                'checksum_prefix': '',
                'move_status': 'not_seen',
                'decode_status': 'not_selected',
                'decoded_records': 0,
                'parser_malformed_segments': 0,
                'format_duplicate_suppressed': 0,
                'format_missing_key_suppressed': 0,
                'ingest_status': 'not_attempted',
                'normalized_records': 0,
                'matched_rows': 0,
                'unmatched_rows': 0,
                'parser_named_rows': 0,
                'source_blank_patient_names': 0,
                'patient_names_backfilled': 0,
                'patient_names_still_blank': 0,
                'missing_claim_number_rows': 0,
                'fallback_correlated_missing_claim_rows': 0,
                'ledger_status': 'not_attempted',
                'error_classes': [],
            }
            self.files[key] = entry
        if endpoint_key:
            entry['endpoint_hash_prefix'] = _hash_prefix(endpoint_key)
            self.endpoint_hashes[entry['endpoint_hash_prefix']] = True
        return entry

    def _add_error_class(self, entry, exc):
        if exc is None:
            return
        if isinstance(exc, str):
            name = exc
        else:
            try:
                name = exc.__class__.__name__
            except Exception:
                name = 'Exception'
        if name and name not in entry['error_classes']:
            entry['error_classes'].append(name)

    def record_endpoint_result(self, endpoint_key, result):
        endpoint_hash = _hash_prefix(endpoint_key)
        if not endpoint_hash or endpoint_hash in self.endpoint_results:
            return
        data = result if isinstance(result, dict) else {}
        transport = _safe_str(data.get('transport')).strip().lower()
        status = _safe_str(data.get('status')).strip().lower()
        if not status:
            status = 'unknown'
        self.endpoint_results[endpoint_hash] = {
            'endpoint_hash_prefix': endpoint_hash,
            'transport': transport or 'unknown',
            'status': status,
            'reason_hash_prefix': _hash_prefix(data.get('reason')),
            'files_downloaded': _safe_int(data.get('files_downloaded')),
            'records_found': _safe_int(data.get('records_found')),
            'files_translated': _safe_int(data.get('files_translated')),
        }
        self.endpoint_hashes[endpoint_hash] = True
        self.totals['endpoint_total'] += 1
        if transport == 'winscp':
            self.totals['endpoint_winscp'] += 1
        elif transport == 'api':
            self.totals['endpoint_api'] += 1
        status_key = 'endpoint_' + status
        if status_key in self.totals:
            self.totals[status_key] += 1

    def record_download_seen(self, path_or_name, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        if entry.get('download_seen') is not True:
            entry['download_seen'] = True
            self.totals['downloaded_files'] += 1

    def record_move_supported(self, path_or_name, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        if entry.get('move_supported_counted') is not True:
            entry['move_supported_counted'] = True
            self.totals['supported_move_files'] += 1

    def record_move_unsupported(self, path_or_name, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        entry['move_status'] = 'unsupported_extension'
        if entry.get('move_unsupported_counted') is not True:
            entry['move_unsupported_counted'] = True
            self.totals['unsupported_move_files'] += 1

    def record_move_missing(self, path_or_name, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        entry['move_status'] = 'missing_source'
        if entry.get('move_missing_counted') is not True:
            entry['move_missing_counted'] = True
            self.totals['missing_source_files'] += 1

    def record_move_error(self, path_or_name, exc=None, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        entry['move_status'] = 'move_error'
        self._add_error_class(entry, exc)
        if entry.get('move_error_counted') is not True:
            entry['move_error_counted'] = True
            self.totals['move_error_files'] += 1

    def record_move_success(self, path_or_name, moved_path, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        moved_key = _file_key(moved_path)
        if moved_key and moved_key not in self.files:
            self.files[moved_key] = entry
        entry['move_status'] = 'moved'
        entry['size_bytes'] = _size_bytes(moved_path)
        entry['checksum_prefix'] = _checksum_prefix(moved_path)
        if entry.get('move_success_counted') is not True:
            entry['move_success_counted'] = True
            self.totals['moved_files'] += 1

    def record_decode_selected(self, path_or_name, source_type=None, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        if source_type:
            entry['source_type'] = _safe_str(source_type) or entry.get('source_type')
        entry['decode_status'] = 'selected'
        if entry.get('decode_selected_counted') is not True:
            entry['decode_selected_counted'] = True
            self.totals['decode_selected_files'] += 1

    def record_decode_result(self, path_or_name, records_count, source_type=None, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        if source_type:
            entry['source_type'] = _safe_str(source_type) or entry.get('source_type')
        count = int(records_count or 0)
        entry['decode_status'] = 'zero_records' if count == 0 else 'ok'
        entry['decoded_records'] = count
        if entry.get('decode_result_counted') is not True:
            entry['decode_result_counted'] = True
            self.totals['decoded_records'] += count
            if count == 0:
                self.totals['decode_zero_record_files'] += 1
            else:
                self.totals['decode_success_files'] += 1

    def record_decode_error(self, path_or_name, exc=None, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        entry['decode_status'] = 'decode_error'
        self._add_error_class(entry, exc)
        if entry.get('decode_error_counted') is not True:
            entry['decode_error_counted'] = True
            self.totals['decode_error_files'] += 1

    def record_parser_metrics(self, path_or_name, parse_metrics=None, format_metrics=None, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        parse_data = parse_metrics if isinstance(parse_metrics, dict) else {}
        format_data = format_metrics if isinstance(format_metrics, dict) else {}
        malformed = _safe_int(parse_data.get('malformed_segment_count'))
        duplicate_suppressed = _safe_int(format_data.get('duplicate_suppressed_count'))
        missing_key_suppressed = _safe_int(format_data.get('missing_key_suppressed_count'))
        entry['parser_malformed_segments'] = malformed
        entry['format_duplicate_suppressed'] = duplicate_suppressed
        entry['format_missing_key_suppressed'] = missing_key_suppressed
        if entry.get('parser_metrics_counted') is not True:
            entry['parser_metrics_counted'] = True
            self.totals['parser_malformed_segments'] += malformed
            self.totals['format_duplicate_suppressed'] += duplicate_suppressed
            self.totals['format_missing_key_suppressed'] += missing_key_suppressed

    def record_translated(self, path_or_name, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        entry['translated'] = True
        if entry.get('translated_counted') is not True:
            entry['translated_counted'] = True
            self.totals['translated_files'] += 1

    def record_ingest_result(
            self, path_or_name, attempted, normalized_count=0, exc=None, endpoint_key=None,
            ingest_stats=None, missing_claim_number_rows=0, fallback_correlated_missing_claim_rows=0):
        entry = self._entry(path_or_name, endpoint_key)
        if attempted and entry.get('ingest_attempt_counted') is not True:
            entry['ingest_attempt_counted'] = True
            self.totals['ingest_attempted_files'] += 1
        count = int(normalized_count or 0)
        entry['normalized_records'] = count
        if exc is not None:
            entry['ingest_status'] = 'exception'
            self._add_error_class(entry, exc)
            if entry.get('ingest_exception_counted') is not True:
                entry['ingest_exception_counted'] = True
                self.totals['ingest_exception_files'] += 1
            return
        if attempted:
            entry['ingest_status'] = 'ok'
            stats = ingest_stats if isinstance(ingest_stats, dict) else {}
            entry['matched_rows'] = _safe_int(stats.get('matched_rows'))
            entry['unmatched_rows'] = _safe_int(stats.get('unmatched_rows'))
            entry['parser_named_rows'] = _safe_int(stats.get('parser_named_rows'))
            entry['source_blank_patient_names'] = _safe_int(stats.get('sourceBlankPatientNames'))
            entry['patient_names_backfilled'] = _safe_int(stats.get('patientNamesBackfilled'))
            entry['patient_names_still_blank'] = _safe_int(stats.get('patientNamesStillBlank'))
            entry['missing_claim_number_rows'] = _safe_int(missing_claim_number_rows)
            entry['fallback_correlated_missing_claim_rows'] = _safe_int(fallback_correlated_missing_claim_rows)
            if entry.get('ingest_success_counted') is not True:
                entry['ingest_success_counted'] = True
                self.totals['ingest_success_files'] += 1
                self.totals['normalized_records'] += count
                self.totals['matched_rows'] += entry['matched_rows']
                self.totals['unmatched_rows'] += entry['unmatched_rows']
                self.totals['parser_named_rows'] += entry['parser_named_rows']
                self.totals['source_blank_patient_names'] += entry['source_blank_patient_names']
                self.totals['patient_names_backfilled'] += entry['patient_names_backfilled']
                self.totals['patient_names_still_blank'] += entry['patient_names_still_blank']
                self.totals['missing_claim_number_rows'] += entry['missing_claim_number_rows']
                self.totals['fallback_correlated_missing_claim_rows'] += entry['fallback_correlated_missing_claim_rows']
                if count == 0:
                    self.totals['normalized_zero_files'] += 1

    def record_ledger_result(self, path_or_name, attempted, exc=None, endpoint_key=None):
        entry = self._entry(path_or_name, endpoint_key)
        if attempted and entry.get('ledger_attempt_counted') is not True:
            entry['ledger_attempt_counted'] = True
            self.totals['ledger_attempted_files'] += 1
        if exc is not None:
            entry['ledger_status'] = 'exception'
            self._add_error_class(entry, exc)
            if entry.get('ledger_exception_counted') is not True:
                entry['ledger_exception_counted'] = True
                self.totals['ledger_exception_files'] += 1
        elif attempted:
            entry['ledger_status'] = 'ok'
            if entry.get('ledger_success_counted') is not True:
                entry['ledger_success_counted'] = True
                self.totals['ledger_success_files'] += 1

    def payload(self):
        generated_at = _utc_now_epoch()
        files = []
        for _key, entry in sorted(self.files.items(), key=lambda item: item[1].get('file_index', 0)):
            clean = {}
            for key in (
                    'file_index', 'extension', 'source_type', 'endpoint_hash_prefix',
                    'size_bytes', 'checksum_prefix', 'move_status', 'decode_status',
                    'decoded_records', 'parser_malformed_segments',
                    'format_duplicate_suppressed', 'format_missing_key_suppressed',
                    'ingest_status', 'normalized_records', 'matched_rows',
                    'unmatched_rows', 'parser_named_rows', 'source_blank_patient_names',
                    'patient_names_backfilled', 'patient_names_still_blank',
                    'missing_claim_number_rows', 'fallback_correlated_missing_claim_rows',
                    'ledger_status', 'error_classes'):
                clean[key] = entry.get(key)
            files.append(clean)
        return {
            'schema_version': SCHEMA_VERSION,
            'report_kind': 'remittance_parse_yield',
            'run_id': self.run_id,
            'started_at_utc': _utc_stamp(self.started_at_epoch),
            'generated_at_utc': _utc_stamp(generated_at),
            'duration_sec': max(0, generated_at - self.started_at_epoch),
            'source_scope': {
                'endpoint_hash_count': len(self.endpoint_hashes),
            },
            'totals': dict(self.totals),
            'endpoints': list(self.endpoint_results.values()),
            'files': files,
        }

    def write(self):
        payload = self.payload()
        return write_yield_report(self.local_storage_path, payload, self.emit_events)


def render_yield_report_text(payload):
    totals = payload.get('totals') if isinstance(payload, dict) else {}
    if not isinstance(totals, dict):
        totals = {}
    lines = [
        'Remittance Parse Yield',
        'run_id: {0}'.format(payload.get('run_id', '') if isinstance(payload, dict) else ''),
        'generated_at_utc: {0}'.format(payload.get('generated_at_utc', '') if isinstance(payload, dict) else ''),
        'endpoint_total: {0}'.format(totals.get('endpoint_total', 0)),
        'endpoint_winscp: {0}'.format(totals.get('endpoint_winscp', 0)),
        'endpoint_api: {0}'.format(totals.get('endpoint_api', 0)),
        'endpoint_processed: {0}'.format(totals.get('endpoint_processed', 0)),
        'endpoint_no_files: {0}'.format(totals.get('endpoint_no_files', 0)),
        'endpoint_downloaded_no_records: {0}'.format(totals.get('endpoint_downloaded_no_records', 0)),
        'endpoint_validated: {0}'.format(totals.get('endpoint_validated', 0)),
        'endpoint_skipped: {0}'.format(totals.get('endpoint_skipped', 0)),
        'endpoint_offline: {0}'.format(totals.get('endpoint_offline', 0)),
        'endpoint_error: {0}'.format(totals.get('endpoint_error', 0)),
        'downloaded_files: {0}'.format(totals.get('downloaded_files', 0)),
        'supported_move_files: {0}'.format(totals.get('supported_move_files', 0)),
        'unsupported_move_files: {0}'.format(totals.get('unsupported_move_files', 0)),
        'moved_files: {0}'.format(totals.get('moved_files', 0)),
        'missing_source_files: {0}'.format(totals.get('missing_source_files', 0)),
        'move_error_files: {0}'.format(totals.get('move_error_files', 0)),
        'decode_selected_files: {0}'.format(totals.get('decode_selected_files', 0)),
        'decode_success_files: {0}'.format(totals.get('decode_success_files', 0)),
        'decode_zero_record_files: {0}'.format(totals.get('decode_zero_record_files', 0)),
        'decode_error_files: {0}'.format(totals.get('decode_error_files', 0)),
        'decoded_records: {0}'.format(totals.get('decoded_records', 0)),
        'parser_malformed_segments: {0}'.format(totals.get('parser_malformed_segments', 0)),
        'format_duplicate_suppressed: {0}'.format(totals.get('format_duplicate_suppressed', 0)),
        'format_missing_key_suppressed: {0}'.format(totals.get('format_missing_key_suppressed', 0)),
        'translated_files: {0}'.format(totals.get('translated_files', 0)),
        'ingest_attempted_files: {0}'.format(totals.get('ingest_attempted_files', 0)),
        'ingest_success_files: {0}'.format(totals.get('ingest_success_files', 0)),
        'ingest_exception_files: {0}'.format(totals.get('ingest_exception_files', 0)),
        'normalized_records: {0}'.format(totals.get('normalized_records', 0)),
        'normalized_zero_files: {0}'.format(totals.get('normalized_zero_files', 0)),
        'matched_rows: {0}'.format(totals.get('matched_rows', 0)),
        'unmatched_rows: {0}'.format(totals.get('unmatched_rows', 0)),
        'parser_named_rows: {0}'.format(totals.get('parser_named_rows', 0)),
        'source_blank_patient_names: {0}'.format(totals.get('source_blank_patient_names', 0)),
        'patient_names_backfilled: {0}'.format(totals.get('patient_names_backfilled', 0)),
        'patient_names_still_blank: {0}'.format(totals.get('patient_names_still_blank', 0)),
        'missing_claim_number_rows: {0}'.format(totals.get('missing_claim_number_rows', 0)),
        'fallback_correlated_missing_claim_rows: {0}'.format(totals.get('fallback_correlated_missing_claim_rows', 0)),
    ]
    return '\n'.join(lines) + '\n'


def write_yield_report(local_storage_path, payload, emit_events=False):
    root = local_storage_path or '.'
    reports_dir = os.path.join(root, 'reports')
    _ensure_dir(reports_dir)
    if isinstance(payload, dict):
        payload = dict(payload)
    else:
        payload = {}
    run_id = _public_run_id(payload.get('run_id', ''))
    payload['run_id'] = run_id
    json_text = json.dumps(payload, indent=2, sort_keys=True)
    text = render_yield_report_text(payload)

    json_path = os.path.join(reports_dir, REPORT_PREFIX + run_id + '.json')
    txt_path = os.path.join(reports_dir, REPORT_PREFIX + run_id + '.txt')
    latest_json_path = os.path.join(reports_dir, LATEST_JSON_NAME)
    latest_txt_path = os.path.join(reports_dir, LATEST_TXT_NAME)

    _write_text_replace(json_path, json_text + '\n')
    _write_text_replace(txt_path, text)
    _write_text_replace(latest_json_path, json_text + '\n')
    _write_text_replace(latest_txt_path, text)

    events_path = None
    if emit_events:
        events_path = os.path.join(root, 'telemetry', EVENTS_JSONL_NAME)
        _append_jsonl(events_path, {
            'schema_version': SCHEMA_VERSION,
            'event_kind': 'remittance_parse_yield',
            'run_id': run_id,
            'generated_at_utc': payload.get('generated_at_utc', ''),
            'totals': payload.get('totals', {}),
        })

    return {
        'json_path': json_path,
        'txt_path': txt_path,
        'latest_json_path': latest_json_path,
        'latest_txt_path': latest_txt_path,
        'events_path': events_path,
    }


def new_yield_report(local_storage_path, run_id=None, emit_events=None):
    if emit_events is None:
        emit_events = os.environ.get('MEDICAFE_REMITTANCE_PARSE_YIELD_EVENTS', '').strip() in (
            '1', 'true', 'TRUE', 'yes', 'YES'
        )
    return RemittanceParseYieldReport(local_storage_path, run_id=run_id, emit_events=emit_events)
