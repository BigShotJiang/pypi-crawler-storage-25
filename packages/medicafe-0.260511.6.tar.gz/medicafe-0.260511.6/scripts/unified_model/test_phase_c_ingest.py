#!/usr/bin/env python
"""
Phase C ingest: unit tests.
Tests ingest key, artifact class mapping, manifest parsing, idempotency, lock fail.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import glob
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_c_common import (
    PHASE_C_DB_WRITE_ERROR,
    PHASE_C_FINISH_INCOHERENT,
    PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
    PHASE_C_LOCK_FAIL,
    PHASE_C_STATE_WRITE_ERROR,
    PHASE_C_UNKNOWN_ARTIFACT_CLASS,
    artifact_class_to_source_type,
    compute_ingest_key_v1,
)

from unittest.mock import MagicMock, patch

SQL_PATH = os.path.join(_ROOT, "sql", "unified_relational_model_v1.sql")


def _make_lab_with_db():
    """Create temp lab dir with unified_model_xp.db and schema."""
    lab_root = tempfile.mkdtemp()
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    reports_dir = os.path.join(lab_root, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    if os.path.exists(SQL_PATH):
        with open(SQL_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(db_path)
            conn.executescript(f.read())
            conn.close()
    return lab_root, db_path, reports_dir


class TestComputeIngestKeyV1(unittest.TestCase):
    """Determinism and field validation for compute_ingest_key_v1."""

    def test_determinism_same_row_same_key(self):
        row = {
            "source_id": "csv_target",
            "artifact_class": "csv",
            "normalized_path": "a/b.csv",
            "mtime_epoch": 1234567890,
            "size_bytes": 100,
            "sha256": "abc123",
            "hash_mode": "full",
        }
        k1 = compute_ingest_key_v1(row)
        k2 = compute_ingest_key_v1(row)
        self.assertEqual(k1, k2)
        self.assertEqual(len(k1), 64)

    def test_missing_required_raises(self):
        row = {"source_id": "x", "artifact_class": "csv"}
        with self.assertRaises(ValueError) as ctx:
            compute_ingest_key_v1(row)
        self.assertIn("Missing required", str(ctx.exception))

    def test_sha256_empty_with_full_raises(self):
        row = {
            "source_id": "x",
            "artifact_class": "csv",
            "normalized_path": "a.csv",
            "mtime_epoch": 0,
            "size_bytes": 0,
            "sha256": "",
            "hash_mode": "full",
        }
        with self.assertRaises(ValueError) as ctx:
            compute_ingest_key_v1(row)
        self.assertIn("sha256", str(ctx.exception))

    def test_sha256_empty_with_skipped_large_ok(self):
        row = {
            "source_id": "x",
            "artifact_class": "csv",
            "normalized_path": "a.csv",
            "mtime_epoch": 0,
            "size_bytes": 0,
            "sha256": "",
            "hash_mode": "skipped_large",
        }
        k = compute_ingest_key_v1(row)
        self.assertEqual(len(k), 64)


class TestArtifactClassMapping(unittest.TestCase):
    """artifact_class_to_source_type map and unknown-class."""

    def test_known_classes_map(self):
        self.assertEqual(artifact_class_to_source_type("csv"), "file_csv")
        self.assertEqual(artifact_class_to_source_type("docx"), "file_docx")
        self.assertEqual(artifact_class_to_source_type("dat"), "file_dat")
        self.assertEqual(artifact_class_to_source_type("jsonl"), "file_jsonl")
        self.assertEqual(artifact_class_to_source_type("837"), "file_837")
        self.assertEqual(artifact_class_to_source_type("receipt"), "file_receipt")
        self.assertEqual(artifact_class_to_source_type("xml"), "file_xml")

    def test_unknown_returns_none(self):
        self.assertIsNone(artifact_class_to_source_type("unknown"))
        self.assertIsNone(artifact_class_to_source_type(""))


class TestManifestRowToIngestRow(unittest.TestCase):
    """manifest_row_to_ingest_row correctness."""

    def test_valid_row_produces_ingest_row(self):
        from ingest_from_manifest import manifest_row_to_ingest_row

        row = {
            "source_id": "csv_target",
            "artifact_class": "csv",
            "normalized_path": "a/b.csv",
            "mtime_epoch": 1234567890,
            "size_bytes": 100,
            "sha256": "abc123",
            "hash_mode": "full",
            "scope": "operational",
        }
        lineage = {"manifest_run_id": "run1", "manifest_sha256": "h1", "config_hash": "", "crosswalk_hash": ""}
        out = manifest_row_to_ingest_row(row, lineage)
        assert out is not None  # narrows for type checker; manifest_row_to_ingest_row may return None
        self.assertEqual(out["source_system"], "xp_local")
        self.assertEqual(out["source_type"], "file_csv")
        self.assertIn("csv_target", out["source_ref"])
        self.assertIn("a/b.csv", out["source_ref"])
        self.assertEqual(out["attachment_name"], "b.csv")
        self.assertEqual(out["ingest_status"], "ingested")

    def test_unknown_class_returns_none(self):
        from ingest_from_manifest import manifest_row_to_ingest_row

        row = {
            "source_id": "x",
            "artifact_class": "unknown",
            "normalized_path": "a.csv",
            "mtime_epoch": 0,
            "size_bytes": 0,
            "sha256": "",
            "hash_mode": "skipped_large",
            "scope": "operational",
        }
        lineage = {}
        self.assertIsNone(manifest_row_to_ingest_row(row, lineage))


class TestManifestParsing(unittest.TestCase):
    """Malformed JSON and missing fields yield anomalies, continue."""

    def test_malformed_line_yields_anomaly(self):
        from ingest_from_manifest import read_manifest_rows, validate_manifest_row

        lab_root = tempfile.mkdtemp()
        manifest = os.path.join(lab_root, "manifest.jsonl")
        try:
            with open(manifest, "w", encoding="utf-8") as f:
                f.write('{"valid": true}\n')
                f.write('{invalid json\n')
                f.write('{"artifact_class":"csv"}\n')
            rows = list(read_manifest_rows(manifest))
            self.assertEqual(len(rows), 3)
            self.assertIsNotNone(rows[0][0])
            self.assertIsNone(rows[1][0])
            valid, anomaly = validate_manifest_row(rows[0][0], 1)
            self.assertFalse(valid)
            self.assertIsNotNone(anomaly)
        finally:
            try:
                os.remove(manifest)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_phase_b_policy_metadata_record_is_skipped(self):
        from ingest_from_manifest import read_manifest_rows

        lab_root = tempfile.mkdtemp()
        manifest = os.path.join(lab_root, "manifest.jsonl")
        try:
            with open(manifest, "w", encoding="utf-8") as f:
                f.write(json.dumps({
                    "record_type": "phase_b_discovery_scope_policy",
                    "discovery_scope_policy": {
                        "effective_policy": {"include_xml": True},
                        "policy_source_map": {"include_xml": "config"},
                    },
                }) + "\n")
                f.write(json.dumps({
                    "source_id": "x",
                    "artifact_class": "csv",
                    "normalized_path": "a.csv",
                    "mtime_epoch": 0,
                    "size_bytes": 0,
                    "sha256": "",
                    "hash_mode": "skipped_large",
                    "scope": "op",
                }) + "\n")
            rows = list(read_manifest_rows(manifest))
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0][1], 2)
            self.assertEqual(rows[0][0].get("artifact_class"), "csv")
        finally:
            try:
                os.remove(manifest)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestIdempotentDbBehavior(unittest.TestCase):
    """Insert same rows twice; second run yields rows_skipped_duplicate."""

    def test_idempotent_insert(self):
        from ingest_from_manifest import manifest_row_to_ingest_row, write_ingest_rows

        lab_root, db_path, _ = _make_lab_with_db()
        try:
            row = {
                "source_id": "csv_target",
                "artifact_class": "csv",
                "normalized_path": "idem.csv",
                "mtime_epoch": 1234567890,
                "size_bytes": 100,
                "sha256": "abc123",
                "hash_mode": "full",
                "scope": "operational",
            }
            lineage = {}
            ingest_row = manifest_row_to_ingest_row(row, lineage)
            self.assertIsNotNone(ingest_row)
            conn = sqlite3.connect(db_path)
            try:
                ins1, skip1, fail1, ib1, sb1 = write_ingest_rows(conn, [ingest_row])
                conn.commit()
                self.assertEqual(ins1, 1)
                self.assertEqual(skip1, 0)
                self.assertEqual(ib1.get("csv"), 1)
                ins2, skip2, fail2, ib2, sb2 = write_ingest_rows(conn, [ingest_row])
                conn.commit()
                self.assertEqual(ins2, 0)
                self.assertEqual(skip2, 1)
                self.assertEqual(sb2.get("csv"), 1)
            finally:
                conn.close()
        finally:
            try:
                for f in os.listdir(lab_root):
                    p = os.path.join(lab_root, f)
                    if os.path.isfile(p):
                        os.remove(p)
                    else:
                        for sf in os.listdir(p):
                            os.remove(os.path.join(p, sf))
                        os.rmdir(p)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_write_ingest_rows_marks_schema_and_first_row_progress(self):
        from ingest_from_manifest import manifest_row_to_ingest_row, write_ingest_rows

        lab_root, db_path, _ = _make_lab_with_db()
        marks = []

        def mark(stage, detail=None):
            marks.append((stage, detail))

        try:
            row = {
                "source_id": "csv_target",
                "artifact_class": "csv",
                "normalized_path": "progress.csv",
                "mtime_epoch": 1234567890,
                "size_bytes": 100,
                "sha256": "abc123",
                "hash_mode": "full",
                "scope": "operational",
            }
            ingest_row = manifest_row_to_ingest_row(row, {})
            self.assertIsNotNone(ingest_row)
            conn = sqlite3.connect(db_path)
            try:
                ins, skip, fail, ib, sb = write_ingest_rows(conn, [ingest_row], mark=mark)
                conn.commit()
                self.assertEqual(ins, 1)
                self.assertEqual(skip, 0)
                self.assertEqual(fail, 0)
            finally:
                conn.close()
            stages = [row[0] for row in marks]
            self.assertEqual(stages, [
                "ingest_schema_verify_begin",
                "ingest_schema_verify_end",
                "ingest_rows_write_begin",
                "ingest_first_row_execute_begin",
                "ingest_first_row_execute_end",
                "ingest_rows_write_end",
            ])
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


class TestWriteIngestRowsAtomicity(unittest.TestCase):
    """A row-level SQLite error must not leave earlier rows committed in the same batch."""

    def test_raises_after_first_row_so_no_partial_commit(self):
        from ingest_from_manifest import manifest_row_to_ingest_row, write_ingest_rows

        row_ok = {
            "source_id": "csv_target",
            "artifact_class": "csv",
            "normalized_path": "atomic_ok.csv",
            "mtime_epoch": 1,
            "size_bytes": 1,
            "sha256": "a",
            "hash_mode": "full",
            "scope": "operational",
        }
        ingest_ok = manifest_row_to_ingest_row(row_ok, {})
        self.assertIsNotNone(ingest_ok)
        ingest_second = manifest_row_to_ingest_row(
            {
                "source_id": "csv_target",
                "artifact_class": "csv",
                "normalized_path": "atomic_second.csv",
                "mtime_epoch": 2,
                "size_bytes": 1,
                "sha256": "b",
                "hash_mode": "full",
                "scope": "operational",
            },
            {},
        )
        self.assertIsNotNone(ingest_second)

        class _FakeConn(object):
            def __init__(self):
                self.insert_n = 0
                self.rollback_called = False

            def execute(self, stmt, params=()):
                if "INSERT OR IGNORE INTO ingest_artifact" in stmt:
                    self.insert_n += 1
                    if self.insert_n == 1:
                        m = MagicMock()
                        m.rowcount = 1
                        return m
                    raise sqlite3.OperationalError("simulated_row_failure")
                m = MagicMock()
                m.rowcount = 0
                return m

            def rollback(self):
                self.rollback_called = True

        fake = _FakeConn()
        with patch("ingest_from_manifest._verify_schema", return_value=True):
            with self.assertRaises(sqlite3.OperationalError):
                write_ingest_rows(fake, [ingest_ok, ingest_second])
        self.assertTrue(fake.rollback_called)


class TestPhaseCDuplicateFlags(unittest.TestCase):
    """Per-plan duplicate-dominant / duplicate-only predicates."""

    def test_phase_c_duplicate_flags(self):
        from ingest_from_manifest import _phase_c_duplicate_flags

        dom, only = _phase_c_duplicate_flags(1, 10, 1)
        self.assertTrue(dom)
        self.assertFalse(only)
        dom2, only2 = _phase_c_duplicate_flags(0, 3, 1)
        self.assertTrue(dom2)
        self.assertTrue(only2)
        dom3, only3 = _phase_c_duplicate_flags(0, 0, 0)
        self.assertFalse(dom3)
        self.assertFalse(only3)


class TestCanonicalIngestSummary(unittest.TestCase):
    """ingest_write_summary JSON includes versioned schema and DB fields on txn failure."""

    def test_txn_failure_writes_full_summary_fields(self):
        from ingest_from_manifest import run_ingest
        import sqlite3

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(
                '{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv",'
                '"mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n'
            )
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest._execute_phase_c_ingest_transaction") as mock_txn:
                        mock_txn.return_value = (
                            False,
                            sqlite3.OperationalError("database is locked"),
                            0,
                            0,
                            1,
                            {},
                            {},
                            2,
                            3.0,
                            {"lock_path": "/tmp/lab.lock", "lock_pid": "99"},
                        )
                        with patch("phase_c_auto_report.submit_phase_c_failure_report", return_value=False):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_DB_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("summary_schema_version"), PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION)
            self.assertEqual(summary.get("db_error_class"), "OperationalError")
            self.assertIn("locked", summary.get("db_error_detail", "").lower())
            self.assertEqual(summary.get("db_lock_retry_count"), 2)
            self.assertEqual(summary.get("db_lock_retry_elapsed_sec"), 3.0)
            self.assertEqual(summary.get("lock_path"), "/tmp/lab.lock")
            self.assertEqual(summary.get("operator_hint"), "sqlite_lock_contention")
            path = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(rid))
            self.assertTrue(os.path.isfile(path))
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.assertEqual(data.get("summary_schema_version"), PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION)
            self.assertEqual(data.get("db_error_class"), "OperationalError")
            self.assertEqual(data.get("db_lock_retry_count"), 2)
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestRunIngestTerminationTelemetry(unittest.TestCase):
    """run_ingest top-level termination: SystemExit(0) and unexpected exceptions."""

    def test_run_ingest_system_exit_zero_returns_finish_incoherent(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_sysexit0.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(
                '{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv",'
                '"mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n'
            )
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch(
                            "ingest_from_manifest.resolve_manifest_path",
                            side_effect=SystemExit(0)):
                        ok, rid, summary, err = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_C_FINISH_INCOHERENT)
            self.assertEqual(summary.get("error_code"), PHASE_C_FINISH_INCOHERENT)
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_run_ingest_unexpected_exception_returns_finish_incoherent(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_exc.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(
                '{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv",'
                '"mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n'
            )
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch(
                            "ingest_from_manifest.resolve_manifest_path",
                            side_effect=ValueError("boom_resolve")):
                        ok, rid, summary, err = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_C_FINISH_INCOHERENT)
            self.assertIn("ValueError", summary.get("error_detail", ""))
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestPhaseCTransactionalWriteFailures(unittest.TestCase):
    """Any per-row execute failure aborts Phase C ingest transaction."""

    def test_row_failure_rolls_back_and_returns_db_write_error(self):
        from ingest_from_manifest import run_ingest
        import sqlite3

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_txn_fail.jsonl")
        rows = [
            '{"source_id":"x","artifact_class":"csv","normalized_path":"ok.csv","mtime_epoch":1,"size_bytes":1,"sha256":"a","hash_mode":"full","scope":"op"}',
            '{"source_id":"x","artifact_class":"csv","normalized_path":"boom.csv","mtime_epoch":2,"size_bytes":2,"sha256":"b","hash_mode":"full","scope":"op"}',
        ]
        with open(manifest, "w", encoding="utf-8") as f:
            f.write("\n".join(rows) + "\n")

        def fail_after_first_insert(conn, ingest_rows):
            first = ingest_rows[0]
            conn.execute(
                "INSERT OR IGNORE INTO ingest_artifact "
                "(ingest_key, source_system, source_type, source_ref, message_id, attachment_name, "
                "attachment_sha256, payload_json, ingest_status) VALUES (?,?,?,?,?,?,?,?,?)",
                (
                    first["ingest_key"],
                    first["source_system"],
                    first["source_type"],
                    first["source_ref"],
                    first["message_id"],
                    first["attachment_name"],
                    first["attachment_sha256"],
                    first["payload_json"],
                    first["ingest_status"],
                ),
            )
            raise sqlite3.OperationalError("simulated execute failure on row 2")

        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.write_ingest_rows", side_effect=fail_after_first_insert):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report", return_value=False):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)

            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_DB_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_DB_WRITE_ERROR)
            self.assertEqual(summary.get("rows_inserted"), 0)
            self.assertEqual(summary.get("rows_failed"), 2)

            conn = sqlite3.connect(db_path)
            try:
                count = conn.execute("SELECT COUNT(*) FROM ingest_artifact").fetchone()[0]
                self.assertEqual(count, 0)
            finally:
                conn.close()
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestLockFail(unittest.TestCase):
    """acquire_lock raises SystemExit => PHASE_C_LOCK_FAIL, exit 1."""

    def test_lock_fail_returns_error_code(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        try:
            with patch("ingest_from_manifest.acquire_lock", side_effect=SystemExit(1)):
                ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_LOCK_FAIL)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_LOCK_FAIL)
            self.assertEqual(summary.get("summary_schema_version"), PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION)
            summaries = glob.glob(os.path.join(reports_dir, "ingest_write_summary_*.json"))
            self.assertTrue(summaries, "lock-fail path should write canonical ingest_write_summary JSON")
            with open(summaries[0], "r", encoding="utf-8") as jf:
                on_disk = json.load(jf)
            self.assertEqual(on_disk.get("error_code"), PHASE_C_LOCK_FAIL)
            self.assertEqual(on_disk.get("summary_schema_version"), PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestStatePersistence(unittest.TestCase):
    """Successful run => run_cursor and diagnostics_state contain Phase C keys."""

    def test_state_persisted(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        phase_b_summary = os.path.join(reports_dir, "artifact_discovery_summary_test.json")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        with open(phase_b_summary, "w", encoding="utf-8") as f:
            json.dump({"manifest_sha256": "faceface", "config_hash": "", "crosswalk_hash": "", "counts_by_class": {}}, f)
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    ok, rid, summary, _ = run_ingest(lab_root, manifest)
            self.assertTrue(ok)
            self.assertEqual(summary.get("summary_schema_version"), PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION)
            self.assertIn("db_error_detail", summary)
            self.assertEqual(summary.get("operator_hint"), "")
            self.assertTrue(os.path.exists(cursor_path))
            self.assertTrue(os.path.exists(state_path))
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
            self.assertIn("last_phase_c_run_id", cursor)
            self.assertIn("last_phase_c_ok", cursor)
            self.assertEqual(cursor.get("updated_at_utc"), cursor.get("last_phase_c_at_utc"))
            diag_latest = os.path.join(reports_dir, "ingest_from_manifest_diagnostics_latest.json")
            self.assertTrue(os.path.isfile(diag_latest))
            self.assertEqual(cursor.get("last_ingest_from_manifest_diag_run_id"), rid)
            self.assertTrue(str(cursor.get("last_ingest_from_manifest_diag_path") or "").endswith(
                "ingest_from_manifest_diagnostics_latest.json"
            ))
            self.assertTrue(cursor.get("last_ingest_from_manifest_diag_at_utc"))
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertIn("last_phase_c_run_id", state)
            self.assertEqual(state.get("last_ingest_from_manifest_diag_run_id"), rid)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                os.remove(db_path)
                if os.path.exists(cursor_path):
                    os.remove(cursor_path)
                if os.path.exists(state_path):
                    os.remove(state_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestStateWriteErrorPropagation(unittest.TestCase):
    """persist_phase_c_state failure => PHASE_C_STATE_WRITE_ERROR returned, summary/report consistent."""

    def test_state_write_fail_manifest_missing_returns_state_error(self):
        """When manifest missing and persist fails, return PHASE_C_STATE_WRITE_ERROR."""
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(lab_root, "nonexistent_manifest.jsonl")
        self.assertFalse(os.path.exists(manifest))
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.persist_phase_c_state", side_effect=IOError("state write failed")):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report", return_value=False):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_STATE_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_STATE_WRITE_ERROR)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_state_write_fail_db_missing_returns_state_error(self):
        """When db missing and persist fails, return PHASE_C_STATE_WRITE_ERROR."""
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        os.remove(db_path)
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.persist_phase_c_state", side_effect=IOError("state write failed")):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report", return_value=False):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_STATE_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_STATE_WRITE_ERROR)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_state_write_fail_success_path_returns_state_error(self):
        """When DB write succeeds but persist fails, return PHASE_C_STATE_WRITE_ERROR, report deferred."""
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_test.jsonl")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write('{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv","mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n')
        report_calls = []
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.persist_phase_c_state", side_effect=IOError("state write failed")):
                        with patch("phase_c_auto_report.submit_phase_c_failure_report") as mock_report:
                            def capture(lab_root, ctx):
                                report_calls.append(ctx)
                            mock_report.side_effect = capture
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_STATE_WRITE_ERROR)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_STATE_WRITE_ERROR)
            self.assertEqual(len(report_calls), 1)
            self.assertEqual(report_calls[0].get("error_code"), PHASE_C_STATE_WRITE_ERROR)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestMissingPhaseBSummary(unittest.TestCase):
    """Missing summary file => warning logged, lineage empty, ingest proceeds."""

    def test_missing_summary_continues(self):
        from ingest_from_manifest import load_phase_b_summary_lineage

        lab_root = tempfile.mkdtemp()
        try:
            lineage = load_phase_b_summary_lineage(lab_root, "nonexistent_run_id")
            self.assertEqual(lineage.get("manifest_sha256"), "")
            self.assertEqual(lineage.get("config_hash"), "")
            self.assertEqual(lineage.get("counts_by_class"), {})
        finally:
            try:
                os.rmdir(lab_root)
            except Exception:
                pass



class TestMainFinishCoherent(unittest.TestCase):
    """main() must not exit 0 unless lab state reflects persist (PHASE_C_FINISH_INCOHERENT)."""

    def test_verify_rejects_stale_run_id_in_cursor(self):
        from ingest_from_manifest import verify_phase_c_lab_reflects_persist

        lab_root = tempfile.mkdtemp()
        try:
            for name, rid in (("run_cursor.json", "old"), ("diagnostics_state.json", "new")):
                path = os.path.join(lab_root, name)
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(
                        {
                            "last_phase_c_run_id": rid,
                            "last_phase_c_ok": True,
                            "last_ingest_manifest_sha256": "aa",
                        },
                        f,
                    )
            ok, reason = verify_phase_c_lab_reflects_persist(
                lab_root, "new", {"manifest_sha256": "aa", "summary_schema_version": 1}
            )
            self.assertFalse(ok)
            self.assertIn("mismatch", reason)
        finally:
            try:
                for n in ("run_cursor.json", "diagnostics_state.json"):
                    p = os.path.join(lab_root, n)
                    if os.path.exists(p):
                        os.remove(p)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_main_rewrites_diagnostics_on_incoherent(self):
        from ingest_from_manifest import main

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir, exist_ok=True)
        rid = "coherent-rid-1"
        summary = {
            "ok": True,
            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            "rows_inserted": 1,
            "rows_skipped_duplicate": 0,
            "manifest_sha256": "faceface",
        }
        path_json = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(rid))
        with open(path_json, "w", encoding="utf-8") as f:
            json.dump(summary, f)
        for name, doc in (
            (
                "run_cursor.json",
                {"last_phase_c_run_id": "other", "last_phase_c_ok": True, "last_ingest_manifest_sha256": "faceface"},
            ),
            (
                "diagnostics_state.json",
                {"last_phase_c_run_id": "other", "last_phase_c_ok": True, "last_ingest_manifest_sha256": "faceface"},
            ),
        ):
            with open(os.path.join(lab_root, name), "w", encoding="utf-8") as f:
                json.dump(doc, f)
        argv_bak = sys.argv[:]
        diag_latest = os.path.join(reports_dir, "ingest_from_manifest_diagnostics_latest.json")
        try:
            sys.argv = ["ingest_from_manifest.py", "--lab-dir", lab_root]
            stderr_buf = __import__("io").StringIO()
            with patch("ingest_from_manifest.run_ingest", return_value=(True, rid, summary, None)):
                with patch("sys.stderr", stderr_buf):
                    with self.assertRaises(SystemExit) as ctx:
                        main()
            self.assertEqual(ctx.exception.code, 1)
            self.assertIn("finish_incoherent", stderr_buf.getvalue())
            self.assertTrue(os.path.isfile(diag_latest))
            with open(diag_latest, "r", encoding="utf-8") as f:
                diag = json.load(f)
            self.assertFalse(diag.get("exit_ok"))
            self.assertEqual(diag.get("error_code"), PHASE_C_FINISH_INCOHERENT)
        finally:
            sys.argv = argv_bak
            try:
                for root, _, files in os.walk(lab_root):
                    for fn in files:
                        os.remove(os.path.join(root, fn))
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_main_rejects_when_run_specific_diagnostics_missing(self):
        from ingest_from_manifest import main

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir, exist_ok=True)
        rid = "coherent-rid-2"
        summary = {
            "ok": True,
            "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
            "rows_inserted": 1,
            "rows_skipped_duplicate": 0,
            "manifest_sha256": "faceface",
            "run_id": rid,
        }
        with open(os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(rid)), "w", encoding="utf-8") as f:
            json.dump(summary, f)
        diag_latest = os.path.join(reports_dir, "ingest_from_manifest_diagnostics_latest.json")
        with open(diag_latest, "w", encoding="utf-8") as f:
            f.write("{}\n")
        for name in ("run_cursor.json", "diagnostics_state.json"):
            with open(os.path.join(lab_root, name), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_run_id": rid,
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "faceface",
                    },
                    f,
                )
        argv_bak = sys.argv[:]
        try:
            sys.argv = ["ingest_from_manifest.py", "--lab-dir", lab_root]
            stderr_buf = __import__("io").StringIO()
            with patch("ingest_from_manifest.run_ingest", return_value=(True, rid, summary, None)):
                with patch("sys.stderr", stderr_buf):
                    with self.assertRaises(SystemExit) as ctx:
                        main()
            self.assertEqual(ctx.exception.code, 1)
            self.assertIn("finish_incoherent", stderr_buf.getvalue())
            self.assertIn("ingest_from_manifest_diagnostics_{0}.json missing".format(rid), stderr_buf.getvalue())
        finally:
            sys.argv = argv_bak
            try:
                for root, _, files in os.walk(lab_root):
                    for fn in files:
                        os.remove(os.path.join(root, fn))
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestMainBootstrapDiagnostics(unittest.TestCase):
    """Bootstrap diagnostics are emitted across main/entrypoint stages."""

    def test_main_success_writes_bootstrap_and_ingest_diagnostics(self):
        from ingest_from_manifest import (
            INGEST_BOOTSTRAP_DIAG_SCHEMA_VERSION,
            _run_main_entrypoint,
        )

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = os.path.join(reports_dir, "artifact_manifest_bootstrap_main.jsonl")
        phase_b_summary = os.path.join(reports_dir, "artifact_discovery_summary_bootstrap_main.json")
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(
                '{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv",'
                '"mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n'
            )
        with open(phase_b_summary, "w", encoding="utf-8") as f:
            json.dump({"manifest_sha256": "feedface", "config_hash": "", "crosswalk_hash": "", "counts_by_class": {}}, f)

        argv_bak = sys.argv[:]
        env_bak = os.environ.get("MEDICAFE_LAB_DIR")
        try:
            os.environ["MEDICAFE_LAB_DIR"] = lab_root
            sys.argv = ["ingest_from_manifest.py", "--lab-dir", lab_root, "--manifest", manifest]
            _run_main_entrypoint()
            bootstrap_latest = os.path.join(reports_dir, "ingest_from_manifest_bootstrap_latest.json")
            self.assertTrue(os.path.isfile(bootstrap_latest))
            with open(bootstrap_latest, "r", encoding="utf-8") as f:
                diag = json.load(f)
            self.assertEqual(diag.get("schema_version"), INGEST_BOOTSTRAP_DIAG_SCHEMA_VERSION)
            self.assertEqual(diag.get("stage"), "after_run_ingest")
            self.assertTrue(os.path.isfile(os.path.join(reports_dir, "ingest_from_manifest_diagnostics_latest.json")))
            timeline_path = os.path.join(reports_dir, "ingest_from_manifest_bootstrap_timeline_latest.jsonl")
            self.assertTrue(os.path.isfile(timeline_path))
            stages = []
            with open(timeline_path, "r", encoding="utf-8") as tlf:
                for line in tlf:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        row = json.loads(line)
                    except Exception:
                        continue
                    if isinstance(row, dict) and row.get("stage"):
                        stages.append(row.get("stage"))
            self.assertIn("run_ingest_entry", stages)
        finally:
            sys.argv = argv_bak
            if env_bak is None:
                os.environ.pop("MEDICAFE_LAB_DIR", None)
            else:
                os.environ["MEDICAFE_LAB_DIR"] = env_bak
            try:
                for root, _, files in os.walk(lab_root):
                    for fn in files:
                        os.remove(os.path.join(root, fn))
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_argparse_exit_zero_writes_bootstrap_and_does_not_mark_success(self):
        from ingest_from_manifest import _run_main_entrypoint

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        argv_bak = sys.argv[:]
        env_bak = os.environ.get("MEDICAFE_LAB_DIR")
        try:
            os.environ["MEDICAFE_LAB_DIR"] = lab_root
            sys.argv = ["ingest_from_manifest.py", "--help"]
            with self.assertRaises(SystemExit) as ctx:
                _run_main_entrypoint()
            self.assertEqual(ctx.exception.code, 0)
            bootstrap_latest = os.path.join(reports_dir, "ingest_from_manifest_bootstrap_latest.json")
            self.assertTrue(os.path.isfile(bootstrap_latest))
            with open(bootstrap_latest, "r", encoding="utf-8") as f:
                diag = json.load(f)
            self.assertEqual(diag.get("stage"), "argparse_system_exit_0")
            self.assertFalse(os.path.isfile(os.path.join(reports_dir, "ingest_from_manifest_diagnostics_latest.json")))
        finally:
            sys.argv = argv_bak
            if env_bak is None:
                os.environ.pop("MEDICAFE_LAB_DIR", None)
            else:
                os.environ["MEDICAFE_LAB_DIR"] = env_bak
            try:
                if os.path.isdir(reports_dir):
                    for fn in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, fn))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_unhandled_exception_writes_bootstrap_and_exits_nonzero(self):
        from ingest_from_manifest import _run_main_entrypoint

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        env_bak = os.environ.get("MEDICAFE_LAB_DIR")
        try:
            os.environ["MEDICAFE_LAB_DIR"] = lab_root
            with patch("ingest_from_manifest.main", side_effect=RuntimeError("boom_unhandled")):
                with self.assertRaises(SystemExit) as ctx:
                    _run_main_entrypoint()
            self.assertEqual(ctx.exception.code, 1)
            bootstrap_latest = os.path.join(reports_dir, "ingest_from_manifest_bootstrap_latest.json")
            self.assertTrue(os.path.isfile(bootstrap_latest))
            with open(bootstrap_latest, "r", encoding="utf-8") as f:
                diag = json.load(f)
            self.assertEqual(diag.get("stage"), "top_level_exception")
            self.assertIn("RuntimeError", str(diag.get("detail") or ""))
        finally:
            if env_bak is None:
                os.environ.pop("MEDICAFE_LAB_DIR", None)
            else:
                os.environ["MEDICAFE_LAB_DIR"] = env_bak
            try:
                if os.path.isdir(reports_dir):
                    for fn in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, fn))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_run_ingest_system_exit_zero_forces_nonzero_and_writes_finish_diag(self):
        from ingest_from_manifest import _run_main_entrypoint

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        argv_bak = sys.argv[:]
        env_bak = os.environ.get("MEDICAFE_LAB_DIR")
        try:
            os.environ["MEDICAFE_LAB_DIR"] = lab_root
            sys.argv = ["ingest_from_manifest.py", "--lab-dir", lab_root]
            stderr_buf = __import__("io").StringIO()
            with patch("ingest_from_manifest.run_ingest", side_effect=SystemExit(0)):
                with patch("sys.stderr", stderr_buf):
                    with self.assertRaises(SystemExit) as ctx:
                        _run_main_entrypoint()
            self.assertEqual(ctx.exception.code, 1)
            self.assertIn("finish_incoherent", stderr_buf.getvalue())

            bootstrap_latest = os.path.join(reports_dir, "ingest_from_manifest_bootstrap_latest.json")
            self.assertTrue(os.path.isfile(bootstrap_latest))
            with open(bootstrap_latest, "r", encoding="utf-8") as f:
                bootstrap = json.load(f)
            self.assertEqual(bootstrap.get("stage"), "run_ingest_system_exit_0")

            diag_latest = os.path.join(reports_dir, "ingest_from_manifest_diagnostics_latest.json")
            self.assertTrue(os.path.isfile(diag_latest))
            with open(diag_latest, "r", encoding="utf-8") as f:
                diag = json.load(f)
            self.assertFalse(bool(diag.get("exit_ok")))
            self.assertEqual(diag.get("error_code"), PHASE_C_FINISH_INCOHERENT)
        finally:
            sys.argv = argv_bak
            if env_bak is None:
                os.environ.pop("MEDICAFE_LAB_DIR", None)
            else:
                os.environ["MEDICAFE_LAB_DIR"] = env_bak
            try:
                if os.path.isdir(reports_dir):
                    for fn in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, fn))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestRunIngestFinishCoherent(unittest.TestCase):
    """run_ingest() must downgrade apparent success when publish/state coherence is missing."""

    def _write_single_row_manifest(self, reports_dir, name):
        manifest = os.path.join(reports_dir, name)
        with open(manifest, "w", encoding="utf-8") as f:
            f.write(
                '{"source_id":"x","artifact_class":"csv","normalized_path":"a.csv",'
                '"mtime_epoch":0,"size_bytes":0,"sha256":"","hash_mode":"skipped_large","scope":"op"}\n'
            )
        return manifest

    def test_success_when_publish_skipped_returns_finish_incoherent(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = self._write_single_row_manifest(reports_dir, "artifact_manifest_publish_skip.jsonl")
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest._write_phase_c_canonical_reports", return_value=None):
                        with patch("ingest_from_manifest._write_ingest_from_manifest_diagnostics", return_value=None):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_FINISH_INCOHERENT)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_FINISH_INCOHERENT)
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                cursor_path = os.path.join(lab_root, "run_cursor.json")
                state_path = os.path.join(lab_root, "diagnostics_state.json")
                if os.path.exists(cursor_path):
                    os.remove(cursor_path)
                if os.path.exists(state_path):
                    os.remove(state_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_summary_exists_but_state_not_updated_returns_finish_incoherent(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = self._write_single_row_manifest(reports_dir, "artifact_manifest_state_skip.jsonl")
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest.persist_phase_c_state", return_value=None):
                        ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_FINISH_INCOHERENT)
            self.assertIsNotNone(summary)
            self.assertEqual(summary.get("error_code"), PHASE_C_FINISH_INCOHERENT)
            path_json = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(rid))
            self.assertTrue(os.path.isfile(path_json))
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                cursor_path = os.path.join(lab_root, "run_cursor.json")
                state_path = os.path.join(lab_root, "diagnostics_state.json")
                if os.path.exists(cursor_path):
                    os.remove(cursor_path)
                if os.path.exists(state_path):
                    os.remove(state_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_finish_incoherent_overwrites_success_state_flags(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = self._write_single_row_manifest(reports_dir, "artifact_manifest_finish_incoherent_state.jsonl")
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest._coherence_finish_parts", return_value=["forced_finish_incoherent"]):
                        ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_FINISH_INCOHERENT)
            self.assertEqual(summary.get("error_code"), PHASE_C_FINISH_INCOHERENT)
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            cursor_path = os.path.join(lab_root, "run_cursor.json")
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
            self.assertEqual(state.get("last_phase_c_run_id"), rid)
            self.assertEqual(cursor.get("last_phase_c_run_id"), rid)
            self.assertFalse(bool(state.get("last_phase_c_ok")))
            self.assertFalse(bool(cursor.get("last_phase_c_ok")))
            self.assertEqual(state.get("last_phase_c_error_code"), PHASE_C_FINISH_INCOHERENT)
            self.assertEqual(cursor.get("last_phase_c_error_code"), PHASE_C_FINISH_INCOHERENT)
            self.assertTrue(state.get("last_ingest_manifest_sha256") is not None)
            self.assertTrue(cursor.get("last_ingest_manifest_sha256") is not None)
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                cursor_path = os.path.join(lab_root, "run_cursor.json")
                state_path = os.path.join(lab_root, "diagnostics_state.json")
                if os.path.exists(cursor_path):
                    os.remove(cursor_path)
                if os.path.exists(state_path):
                    os.remove(state_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_exception_after_success_persist_downgrades_lab_state(self):
        """If finish diagnostics raise after persist_phase_c_state ok=True, lab must not show success."""
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = self._write_single_row_manifest(reports_dir, "artifact_manifest_exc_after_persist.jsonl")
        phase_b_summary = os.path.join(reports_dir, "artifact_discovery_summary_exc_after_persist.json")
        with open(phase_b_summary, "w", encoding="utf-8") as f:
            json.dump({"manifest_sha256": "deadbeef", "config_hash": "", "crosswalk_hash": "", "counts_by_class": {}}, f)

        def diag_side_effect(*_a, **_k):
            diag_side_effect.n += 1
            if diag_side_effect.n == 1:
                raise RuntimeError("simulated_finish_diag_failure")

        diag_side_effect.n = 0

        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch(
                            "ingest_from_manifest._write_ingest_from_manifest_diagnostics",
                            side_effect=diag_side_effect):
                        ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_FINISH_INCOHERENT)
            self.assertEqual(diag_side_effect.n, 2)
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            cursor_path = os.path.join(lab_root, "run_cursor.json")
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
            self.assertEqual(state.get("last_phase_c_run_id"), rid)
            self.assertEqual(cursor.get("last_phase_c_run_id"), rid)
            self.assertFalse(bool(state.get("last_phase_c_ok")))
            self.assertFalse(bool(cursor.get("last_phase_c_ok")))
            self.assertEqual(state.get("last_phase_c_error_code"), PHASE_C_FINISH_INCOHERENT)
            self.assertEqual(cursor.get("last_phase_c_error_code"), PHASE_C_FINISH_INCOHERENT)
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                for name in ("run_cursor.json", "diagnostics_state.json"):
                    path = os.path.join(lab_root, name)
                    if os.path.exists(path):
                        os.remove(path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_exception_after_commit_before_summary_has_target_state_telemetry(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = self._write_single_row_manifest(reports_dir, "artifact_manifest_post_commit_gap.jsonl")

        def post_commit_boom(_rows_inserted, _rows_skipped, _ingest_row_count):
            raise RuntimeError("simulated_post_commit_presummary_failure")

        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest._phase_c_duplicate_flags", side_effect=post_commit_boom):
                        ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_FINISH_INCOHERENT)
            self.assertEqual(summary.get("error_code"), PHASE_C_FINISH_INCOHERENT)
            self.assertEqual(summary.get("post_commit_exception_class"), "RuntimeError")
            self.assertIn("simulated_post_commit_presummary_failure", summary.get("post_commit_exception_message", ""))
            target_state = summary.get("post_commit_report_target_state")
            self.assertIsInstance(target_state, dict)
            self.assertTrue(target_state.get("reports_dir_exists"))
            self.assertTrue(target_state.get("reports_dir_is_dir"))
            self.assertTrue(str(target_state.get("summary_json_path") or "").endswith(
                "ingest_write_summary_{0}.json".format(rid)))
            self.assertFalse(bool(target_state.get("summary_json_exists")))

            diag_path = os.path.join(reports_dir, "ingest_from_manifest_diagnostics_{0}.json".format(rid))
            self.assertTrue(os.path.isfile(diag_path))
            with open(diag_path, "r", encoding="utf-8") as f:
                diag = json.load(f)
            self.assertEqual(diag.get("error_code"), PHASE_C_FINISH_INCOHERENT)
            self.assertEqual(diag.get("post_commit_exception_class"), "RuntimeError")
            self.assertIsInstance(diag.get("post_commit_report_target_state"), dict)
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                for name in ("run_cursor.json", "diagnostics_state.json"):
                    path = os.path.join(lab_root, name)
                    if os.path.exists(path):
                        os.remove(path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_missing_diagnostics_forces_finish_incoherent_and_persists_both_files(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = self._write_single_row_manifest(reports_dir, "artifact_manifest_missing_diag.jsonl")
        phase_b_summary = os.path.join(reports_dir, "artifact_discovery_summary_missing_diag.json")
        with open(phase_b_summary, "w", encoding="utf-8") as f:
            json.dump({"manifest_sha256": "f00dbabe", "config_hash": "", "crosswalk_hash": "", "counts_by_class": {}}, f)
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest._write_ingest_from_manifest_diagnostics", return_value=None):
                        ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_FINISH_INCOHERENT)
            self.assertEqual(summary.get("error_code"), PHASE_C_FINISH_INCOHERENT)
            with open(os.path.join(lab_root, "diagnostics_state.json"), "r", encoding="utf-8") as f:
                state = json.load(f)
            with open(os.path.join(lab_root, "run_cursor.json"), "r", encoding="utf-8") as f:
                cursor = json.load(f)
            self.assertEqual(state.get("last_phase_c_run_id"), rid)
            self.assertEqual(cursor.get("last_phase_c_run_id"), rid)
            self.assertFalse(bool(state.get("last_phase_c_ok")))
            self.assertFalse(bool(cursor.get("last_phase_c_ok")))
            self.assertEqual(state.get("last_phase_c_error_code"), PHASE_C_FINISH_INCOHERENT)
            self.assertEqual(cursor.get("last_phase_c_error_code"), PHASE_C_FINISH_INCOHERENT)
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                for name in ("run_cursor.json", "diagnostics_state.json"):
                    path = os.path.join(lab_root, name)
                    if os.path.exists(path):
                        os.remove(path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_finish_incoherent_state_write_failure_sets_state_write_error(self):
        from ingest_from_manifest import run_ingest

        lab_root, db_path, reports_dir = _make_lab_with_db()
        manifest = self._write_single_row_manifest(reports_dir, "artifact_manifest_finish_state_fail.jsonl")
        try:
            with patch("ingest_from_manifest.acquire_lock"):
                with patch("ingest_from_manifest.release_lock"):
                    with patch("ingest_from_manifest._coherence_finish_parts", return_value=["forced_finish_incoherent"]):
                        with patch("ingest_from_manifest.persist_phase_c_state", side_effect=IOError("forced_state_write_error")):
                            ok, rid, summary, error_code = run_ingest(lab_root, manifest)
            self.assertFalse(ok)
            self.assertEqual(error_code, PHASE_C_STATE_WRITE_ERROR)
            self.assertEqual(summary.get("error_code"), PHASE_C_STATE_WRITE_ERROR)
        finally:
            try:
                for fn in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, fn))
                if os.path.exists(db_path):
                    os.remove(db_path)
                for name in ("run_cursor.json", "diagnostics_state.json"):
                    path = os.path.join(lab_root, name)
                    if os.path.exists(path):
                        os.remove(path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestPhaseCSqliteLockRetry(unittest.TestCase):
    """SQLite lock/busy bounded retry wraps Phase C ingest transaction."""

    def test_is_sqlite_lock_class_error_matches_locked(self):
        from phase_c_common import phase_c_sqlite_lock_class_error
        import sqlite3

        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("database is locked")))
        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("database is busy")))

        # Common sqlite contention variants seen across wrappers/drivers.
        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("database table is locked")))
        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("database schema is locked: main")))
        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("SQLITE_BUSY: another transaction is active")))
        self.assertTrue(phase_c_sqlite_lock_class_error(sqlite3.OperationalError("SQLITE_LOCKED: table users")))

        self.assertFalse(phase_c_sqlite_lock_class_error(RuntimeError("other")))
        self.assertFalse(phase_c_sqlite_lock_class_error(sqlite3.IntegrityError("constraint failed")))

    def test_is_sqlite_lock_class_error_not_retry_on_ambiguous_locked_substring(self):
        """OperationalError strings may contain \"locked\" without busy/lock semantics."""
        from phase_c_common import phase_c_sqlite_lock_class_error
        import sqlite3

        self.assertFalse(phase_c_sqlite_lock_class_error(
            sqlite3.OperationalError("cannot open: journal header malformed (locked-flag bits set)")
        ))
        self.assertFalse(phase_c_sqlite_lock_class_error(
            sqlite3.OperationalError("readonly database: lock metadata unavailable")
        ))

    def test_retries_once_on_lock_then_success(self):
        import sqlite3
        from ingest_from_manifest import _execute_phase_c_ingest_transaction

        lab_root = tempfile.mkdtemp()
        db_path = os.path.join(lab_root, "u.db")
        calls = {"n": 0}

        def fake_write(_conn, _rows, mark=None):
            calls["n"] += 1
            if calls["n"] == 1:
                raise sqlite3.OperationalError("database is locked")
            return (1, 0, 0, {"csv": 1}, {})

        try:
            sqlite3.connect(db_path).close()
            with patch("ingest_from_manifest.write_ingest_rows", side_effect=fake_write):
                with patch("ingest_from_manifest.read_lab_lock_diagnostic_metadata", return_value={"lock_pid": "9"}):
                    with patch("ingest_from_manifest.time.sleep", return_value=None):
                        ok, exc, inserted, skipped, failed, ib, sb, lock_retry, elapsed, meta = _execute_phase_c_ingest_transaction(
                            db_path, [{"stub": True}], lab_root
                        )
            self.assertTrue(ok)
            self.assertIsNone(exc)
            self.assertEqual(lock_retry, 1)
            self.assertEqual(inserted, 1)
            self.assertIsInstance(meta, dict)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_non_lock_errors_do_not_retry(self):
        import sqlite3
        from ingest_from_manifest import _execute_phase_c_ingest_transaction

        lab_root = tempfile.mkdtemp()
        db_path = os.path.join(lab_root, "u2.db")

        def boom(_conn, _rows, mark=None):
            raise sqlite3.OperationalError("unsupported file format")

        try:
            sqlite3.connect(db_path).close()
            with patch("ingest_from_manifest.write_ingest_rows", side_effect=boom):
                with patch("ingest_from_manifest.read_lab_lock_diagnostic_metadata", return_value={}):
                    ok, exc, _, _, _, _, _, lock_retry, _, meta = _execute_phase_c_ingest_transaction(db_path, [{"x": 1}], lab_root)
            self.assertFalse(ok)
            self.assertIsNotNone(exc)
            self.assertEqual(lock_retry, 0)
            self.assertIsInstance(meta, dict)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_transaction_marks_begin_commit_progress(self):
        import sqlite3
        from ingest_from_manifest import _execute_phase_c_ingest_transaction

        lab_root = tempfile.mkdtemp()
        db_path = os.path.join(lab_root, "u3.db")
        marks = []

        def mark(stage, detail=None):
            marks.append((stage, detail))

        def fake_write(_conn, _rows, mark=None):
            if mark:
                mark("fake_write_seen")
            return (1, 0, 0, {"csv": 1}, {})

        try:
            sqlite3.connect(db_path).close()
            with patch("ingest_from_manifest.write_ingest_rows", side_effect=fake_write):
                with patch("ingest_from_manifest.read_lab_lock_diagnostic_metadata", return_value={}):
                    ok, exc, inserted, skipped, failed, ib, sb, lock_retry, elapsed, meta = _execute_phase_c_ingest_transaction(
                        db_path, [{"stub": True}], lab_root, mark=mark
                    )
            self.assertTrue(ok)
            self.assertIsNone(exc)
            self.assertEqual(inserted, 1)
            stages = [row[0] for row in marks]
            self.assertEqual(stages, [
                "sqlite_begin_execute_begin",
                "sqlite_begin_execute_end",
                "fake_write_seen",
                "sqlite_commit_begin",
                "sqlite_commit_end",
            ])
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_transaction_system_exit_zero_is_structured_failure(self):
        import sqlite3
        from ingest_from_manifest import _execute_phase_c_ingest_transaction

        lab_root = tempfile.mkdtemp()
        db_path = os.path.join(lab_root, "u4.db")
        marks = []

        def mark(stage, detail=None):
            marks.append((stage, detail))

        def exit_zero(_conn, _rows, mark=None):
            raise SystemExit(0)

        try:
            sqlite3.connect(db_path).close()
            with patch("ingest_from_manifest.write_ingest_rows", side_effect=exit_zero):
                with patch("ingest_from_manifest.read_lab_lock_diagnostic_metadata", return_value={}):
                    ok, exc, inserted, skipped, failed, ib, sb, lock_retry, elapsed, meta = _execute_phase_c_ingest_transaction(
                        db_path, [{"stub": True}], lab_root, mark=mark
                    )
            self.assertFalse(ok)
            self.assertIsInstance(exc, SystemExit)
            self.assertEqual(getattr(exc, "code", None), 0)
            self.assertEqual(inserted, 0)
            self.assertEqual(failed, 1)
            self.assertEqual(lock_retry, 0)
            stages = [row[0] for row in marks]
            self.assertIn("ingest_transaction_base_exception", stages)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
