#!/usr/bin/env python
"""
DAT payer-anchor enrichment helpers.

XP-compatible: Python 3.4.4, stdlib only. The resolver is intentionally
non-interactive: missing MAINS/crosswalk data returns an empty context instead
of invoking legacy UI/error pauses.
"""
from __future__ import print_function

import os


DAT_PAYER_RESOLUTION_STATUS_RESOLVED = "resolved"
DAT_PAYER_RESOLUTION_STATUS_MISSING = "missing"
DAT_PAYER_RESOLUTION_STATUS_AMBIGUOUS = "ambiguous"
DAT_PAYER_RESOLUTION_SOURCE_EXISTING = "existing_payer_anchor"
DAT_PAYER_RESOLUTION_SOURCE_MAINS_CROSSWALK = "iname_mains_crosswalk"
DAT_PAYER_RESOLUTION_SOURCE_CROSSWALK_NAME = "iname_crosswalk_name"
DAT_PAYER_RESOLUTION_DIAG_UNRESOLVED = "insurance_name_present_but_not_payer_anchor"
DAT_PAYER_RESOLUTION_DIAG_AMBIGUOUS = "insurance_name_payer_mapping_ambiguous"


def _to_text(value):
    if value is None:
        return ""
    return str(value).strip()


def normalize_insurance_name(value):
    """Canonical key for matching padded/case-varied Medisoft insurance names."""
    text = _to_text(value)
    if not text:
        return ""
    return " ".join(text.split()).upper()


def normalize_insurance_display_key(value):
    """
    Canonical display-name key for Medisoft INAME values with numeric suffixes.

    DAT INAME commonly carries a display name plus a Medisoft numeric id, e.g.
    "AARP MEDICARE COMPLETE  31362". The numeric id is useful separately, but
    should not make display-name fallback miss the crosswalk name.
    """
    key = normalize_insurance_name(value)
    if not key:
        return ""
    parts = []
    for token in key.split():
        if token.isdigit():
            continue
        parts.append(token)
    return " ".join(parts)


def extract_medisoft_id_candidates_from_iname(value):
    """
    Return trailing numeric Medisoft id candidates from an INAME display string.

    Candidates are returned right-to-left because the final numeric token is the
    strongest legacy display convention, while earlier numeric tokens may be part
    of an address/display phrase (for example "BOX 1798  65").
    """
    key = normalize_insurance_name(value)
    if not key:
        return []
    out = []
    tokens = key.split()
    idx = len(tokens) - 1
    while idx >= 0:
        token = tokens[idx]
        if not token.isdigit():
            break
        _append_unique(out, token)
        idx -= 1
    return out


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    return [value]


def _append_unique(out, value):
    text = _to_text(value)
    if text and text not in out:
        out.append(text)


def _iter_payer_name_values(payer_data):
    """Yield known crosswalk name/alias fields for deterministic display-name lookup."""
    if not isinstance(payer_data, dict):
        return
    for key in ("name", "payer_name", "primary_insurance", "insurance_name"):
        text = _to_text(payer_data.get(key))
        if text:
            yield text
    for key in ("aliases", "alias_names", "insurance_aliases", "mains_names"):
        value = payer_data.get(key)
        for item in _as_list(value):
            text = _to_text(item)
            if text:
                yield text


def _normalize_name_to_id_map(mapping):
    out = {}
    if not isinstance(mapping, dict):
        return out
    for name, medisoft_id in mapping.items():
        key = normalize_insurance_name(name)
        mid = _to_text(medisoft_id)
        if key and mid:
            out[key] = mid
        display_key = normalize_insurance_display_key(name)
        if display_key and mid and display_key not in out:
            out[display_key] = mid
    return out


def build_payer_ids_by_medisoft(crosswalk):
    """
    Build reverse lookup: medisoft_id(str) -> [payer_id, ...].
    Candidate lists are sorted for deterministic ambiguity handling.
    """
    out = {}
    payer_map = {}
    if isinstance(crosswalk, dict):
        payer_map = crosswalk.get("payer_id", {})
    if not isinstance(payer_map, dict):
        return out
    for payer_id in sorted(payer_map.keys()):
        payer_data = payer_map.get(payer_id)
        if not isinstance(payer_data, dict):
            continue
        for field_name in ("medisoft_id", "medisoft_medicare_id"):
            for medisoft_id in _as_list(payer_data.get(field_name)):
                mid = _to_text(medisoft_id)
                if mid:
                    out.setdefault(mid, []).append(_to_text(payer_id))
        for medisoft_id in _as_list(payer_data.get("medisoft_ids")):
            mid = _to_text(medisoft_id)
            if mid:
                out.setdefault(mid, []).append(_to_text(payer_id))
    return out


def build_payer_ids_by_crosswalk_name(crosswalk):
    """Build direct crosswalk-name lookup as a fallback when MAINS is unavailable."""
    out = {}
    payer_map = {}
    if isinstance(crosswalk, dict):
        payer_map = crosswalk.get("payer_id", {})
    if not isinstance(payer_map, dict):
        return out
    for payer_id in sorted(payer_map.keys()):
        payer_data = payer_map.get(payer_id)
        if not isinstance(payer_data, dict):
            continue
        for name in _iter_payer_name_values(payer_data):
            key = normalize_insurance_name(name)
            if key:
                out.setdefault(key, []).append(_to_text(payer_id))
            display_key = normalize_insurance_display_key(name)
            if display_key:
                out.setdefault(display_key, []).append(_to_text(payer_id))
    return out


def _extract_medilink_config(config):
    if not isinstance(config, dict):
        return {}
    medi = config.get("MediLink_Config")
    if isinstance(medi, dict):
        return medi
    return {}


def _config_value(config, key):
    if isinstance(config, dict):
        value = _to_text(config.get(key))
        if value:
            return value
    medi = _extract_medilink_config(config)
    return _to_text(medi.get(key))


def load_insurance_to_id_from_mains(config, crosswalk):
    """
    Read MAINS into insurance-name -> Medisoft insurance id without legacy UI.

    Returns an empty dict when the MAINS path, mapping slices, or reader are
    unavailable.
    """
    mains_path = _config_value(config, "MAINS_MED_PATH")
    if not mains_path or not os.path.exists(mains_path):
        return {}
    slices = {}
    if isinstance(crosswalk, dict):
        mains_mapping = crosswalk.get("mains_mapping", {})
        if isinstance(mains_mapping, dict):
            slices = mains_mapping.get("slices", {})
    if not isinstance(slices, dict) or not slices:
        return {}
    try:
        from MediLink import MediLink_DataMgmt
    except Exception:
        try:
            import MediLink_DataMgmt
        except Exception:
            return {}
    reader = getattr(MediLink_DataMgmt, "read_general_fixed_width_data", None)
    if reader is None:
        return {}
    out = {}
    try:
        for record, line_number in reader(mains_path, slices):
            if not isinstance(record, dict):
                continue
            name_key = normalize_insurance_name(record.get("MAINSNAME"))
            medisoft_id = _to_text(line_number)
            if name_key and medisoft_id:
                out[name_key] = medisoft_id
    except Exception:
        return {}
    return out


def build_dat_payer_resolution_context(config=None, crosswalk=None, insurance_to_id=None):
    """
    Build the deterministic resolver context used by DAT parsing/tests.

    `insurance_to_id` is accepted for tests or callers that already loaded MAINS.
    """
    if not isinstance(crosswalk, dict):
        crosswalk = {}
    name_to_id = {}
    if isinstance(insurance_to_id, dict):
        name_to_id.update(_normalize_name_to_id_map(insurance_to_id))
    if not name_to_id:
        name_to_id.update(load_insurance_to_id_from_mains(config or {}, crosswalk))
    return {
        "insurance_name_to_id": name_to_id,
        "payer_ids_by_medisoft": build_payer_ids_by_medisoft(crosswalk),
        "payer_ids_by_crosswalk_name": build_payer_ids_by_crosswalk_name(crosswalk),
    }


def _resolution_payload(status, payer_id, source, diagnostic, insurance_name_key, insurance_id, candidates):
    sorted_candidates = sorted([_to_text(item) for item in candidates if _to_text(item)])
    return {
        "payer_id": _to_text(payer_id),
        "status": status,
        "source": source,
        "diagnostic": diagnostic,
        "insurance_name_key": insurance_name_key or "",
        "insurance_id": _to_text(insurance_id),
        "candidate_payer_ids": sorted_candidates,
        "candidate_payer_ids_text": ",".join(sorted_candidates),
    }


def resolve_payer_id_from_iname(insurance_name, resolution_context=None):
    """
    Resolve INAME/insurance_name to payer_id only when one deterministic payer exists.
    """
    key = normalize_insurance_name(insurance_name)
    if not key:
        return _resolution_payload(
            DAT_PAYER_RESOLUTION_STATUS_MISSING, "", "", "", "", "", []
        )
    context = resolution_context if isinstance(resolution_context, dict) else {}
    name_to_id = context.get("insurance_name_to_id")
    payer_ids_by_medisoft = context.get("payer_ids_by_medisoft")
    payer_ids_by_name = context.get("payer_ids_by_crosswalk_name")
    if not isinstance(name_to_id, dict):
        name_to_id = {}
    if not isinstance(payer_ids_by_medisoft, dict):
        payer_ids_by_medisoft = {}
    if not isinstance(payer_ids_by_name, dict):
        payer_ids_by_name = {}

    insurance_id = _to_text(name_to_id.get(key))
    candidates = []
    source = ""
    if insurance_id:
        for payer_id in _as_list(payer_ids_by_medisoft.get(insurance_id)):
            _append_unique(candidates, payer_id)
        source = DAT_PAYER_RESOLUTION_SOURCE_MAINS_CROSSWALK
    if not candidates:
        for medisoft_id in extract_medisoft_id_candidates_from_iname(insurance_name):
            for payer_id in _as_list(payer_ids_by_medisoft.get(medisoft_id)):
                _append_unique(candidates, payer_id)
            if candidates and not insurance_id:
                insurance_id = medisoft_id
        if candidates:
            source = DAT_PAYER_RESOLUTION_SOURCE_MAINS_CROSSWALK
    if not candidates:
        for payer_id in _as_list(payer_ids_by_name.get(key)):
            _append_unique(candidates, payer_id)
        if candidates:
            source = DAT_PAYER_RESOLUTION_SOURCE_CROSSWALK_NAME
    if not candidates:
        display_key = normalize_insurance_display_key(insurance_name)
        if display_key and display_key != key:
            for payer_id in _as_list(payer_ids_by_name.get(display_key)):
                _append_unique(candidates, payer_id)
            if candidates:
                source = DAT_PAYER_RESOLUTION_SOURCE_CROSSWALK_NAME

    candidates = sorted(candidates)
    if len(candidates) == 1:
        return _resolution_payload(
            DAT_PAYER_RESOLUTION_STATUS_RESOLVED,
            candidates[0],
            source,
            "",
            key,
            insurance_id,
            candidates,
        )
    if len(candidates) > 1:
        return _resolution_payload(
            DAT_PAYER_RESOLUTION_STATUS_AMBIGUOUS,
            "",
            source,
            DAT_PAYER_RESOLUTION_DIAG_AMBIGUOUS,
            key,
            insurance_id,
            candidates,
        )
    return _resolution_payload(
        DAT_PAYER_RESOLUTION_STATUS_MISSING,
        "",
        "",
        DAT_PAYER_RESOLUTION_DIAG_UNRESOLVED,
        key,
        insurance_id,
        [],
    )
