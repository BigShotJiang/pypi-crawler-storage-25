#!/usr/bin/env python
"""
Resolve selected DAT artifact rows against the attached Phase B manifest (jsonl).
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

try:
    from phase_d_common import DAT_ARTIFACT_NOT_IN_ATTACHED_MANIFEST
except ImportError:
    DAT_ARTIFACT_NOT_IN_ATTACHED_MANIFEST = "DAT_ARTIFACT_NOT_IN_ATTACHED_MANIFEST"

try:
    from ingest_from_manifest import extract_manifest_run_id, read_manifest_rows, resolve_manifest_path
except ImportError:
    resolve_manifest_path = None
    read_manifest_rows = None
    extract_manifest_run_id = None


def _norm_path(path):
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(str(path or ""))))
    except Exception:
        return str(path or "").strip().lower()


def _default_out():
    return {
        "manifest_match_status": "manifest_unavailable",
        "manifest_row_index": None,
        "manifest_locator": "",
        "manifest_normalized_path": "",
        "source_discovery_run_id": "",
        "selection_source": "",
        "manifest_issue_code": "",
        "manifest_issue_severity": "",
    }


def build_dat_manifest_lineage_index(lab_root, manifest_path=None):
    """
    Build one DAT lookup index for the active Phase B manifest.
    Missing/corrupt manifests return an unavailable index instead of failing.
    """
    out = {
        "available": False,
        "manifest_path": "",
        "source_discovery_run_id": "",
        "by_sha256": {},
        "by_norm_path": {},
    }
    lab_root = str(lab_root or "").strip()
    if not lab_root or resolve_manifest_path is None or read_manifest_rows is None:
        return out
    path = manifest_path or resolve_manifest_path(lab_root, None)
    if not path or not os.path.isfile(path):
        return out
    out["manifest_path"] = path
    rid = extract_manifest_run_id(path) if extract_manifest_run_id else ""
    out["source_discovery_run_id"] = str(rid or "")
    try:
        for row, line_num in read_manifest_rows(path):
            if not isinstance(row, dict):
                continue
            if str(row.get("artifact_class") or "").strip().lower() != "dat":
                continue
            indexed = (row, line_num)
            row_sha = str(row.get("sha256") or "").strip().lower()
            if row_sha and row_sha not in out["by_sha256"]:
                out["by_sha256"][row_sha] = indexed
            row_norm = _norm_path(row.get("normalized_path") or row.get("path") or "")
            if row_norm and row_norm not in out["by_norm_path"]:
                out["by_norm_path"][row_norm] = indexed
    except Exception:
        out["by_sha256"] = {}
        out["by_norm_path"] = {}
        return out
    out["available"] = True
    return out


def _lineage_from_match(match_row, match_index, source_discovery_run_id):
    out = _default_out()
    out["source_discovery_run_id"] = str(source_discovery_run_id or "")
    out["manifest_match_status"] = "in_attached_manifest"
    out["manifest_row_index"] = match_index
    out["manifest_normalized_path"] = str(match_row.get("normalized_path") or "")
    out["manifest_locator"] = str(match_row.get("normalized_path") or match_row.get("path") or "")
    out["selection_source"] = "attached_manifest"
    aid = match_row.get("artifact_id")
    if aid is not None and str(aid).strip():
        out["manifest_artifact_id"] = aid
    return out


def _lineage_not_found(source_discovery_run_id):
    out = _default_out()
    out["source_discovery_run_id"] = str(source_discovery_run_id or "")
    out["manifest_match_status"] = "not_in_attached_manifest"
    out["selection_source"] = "historical_db"
    out["manifest_issue_code"] = DAT_ARTIFACT_NOT_IN_ATTACHED_MANIFEST
    out["manifest_issue_severity"] = "warning"
    return out


def resolve_dat_artifact_manifest_lineage(lab_root, artifact_id, attachment_sha256, locator_full, manifest_index=None):
    """
    Match ingest DAT selection to artifact_manifest_*.jsonl resolved from lab_root.
    Returns fields merged into qa_reject_samples / diagnostics.
    """
    out = _default_out()
    lab_root = str(lab_root or "").strip()
    index = manifest_index if isinstance(manifest_index, dict) else None
    if index is not None:
        if not index.get("available"):
            return out
        sha = str(attachment_sha256 or "").strip().lower()
        loc_norm = _norm_path(locator_full)
        match = None
        if sha:
            match = (index.get("by_sha256") or {}).get(sha)
        if match is None and loc_norm:
            match = (index.get("by_norm_path") or {}).get(loc_norm)
        if match is not None:
            return _lineage_from_match(match[0], match[1], index.get("source_discovery_run_id"))
        return _lineage_not_found(index.get("source_discovery_run_id"))

    if not lab_root or resolve_manifest_path is None or read_manifest_rows is None:
        return out
    manifest_path = resolve_manifest_path(lab_root, None)
    if not manifest_path or not os.path.isfile(manifest_path):
        out["manifest_match_status"] = "manifest_unavailable"
        return out
    rid = extract_manifest_run_id(manifest_path) if extract_manifest_run_id else ""
    out["source_discovery_run_id"] = str(rid or "")
    sha = str(attachment_sha256 or "").strip().lower()
    loc_norm = _norm_path(locator_full)
    match_row = None
    match_index = None
    for row, line_num in read_manifest_rows(manifest_path):
        if not isinstance(row, dict):
            continue
        if str(row.get("artifact_class") or "").strip().lower() != "dat":
            continue
        row_sha = str(row.get("sha256") or "").strip().lower()
        row_norm = _norm_path(row.get("normalized_path") or row.get("path") or "")
        if sha and row_sha and sha == row_sha:
            match_row = row
            match_index = line_num
            break
        if loc_norm and row_norm and loc_norm == row_norm:
            match_row = row
            match_index = line_num
            break
    if match_row is not None:
        return _lineage_from_match(match_row, match_index, rid)
    return _lineage_not_found(rid)
