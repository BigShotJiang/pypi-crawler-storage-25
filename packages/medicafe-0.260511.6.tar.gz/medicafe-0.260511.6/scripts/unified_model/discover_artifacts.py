#!/usr/bin/env python
"""
Phase B artifact discovery engine. Consumes adapter via iter_candidates; no os.walk in core.
Manifest staged outside lock; lock only for finalize + summary + state.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import hashlib
import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_a_common import refresh_run_cursor_updated_at
from phase_b_common import (
    DISCOVERER_VERSION,
    PHASE_B_LOCK_FAIL,
    PHASE_B_MANIFEST_ROW_CAP_EXCEEDED,
    PHASE_B_MANIFEST_WRITE_FAIL,
    PHASE_B_ROOT_RESOLUTION_FAIL,
    iso_utc_now,
    run_id,
)
try:
    from phase_b_root_adapter import get_last_discovery_scope_policy, flush_phase_b_fingerprint_cache
except Exception:
    get_last_discovery_scope_policy = None
    flush_phase_b_fingerprint_cache = None
from phase_b_root_adapter import iter_candidates, resolve_roots
from lab_lock import acquire_lock, release_lock, replace_safe_write
from lab_path_utils import resolve_lab_root

# Canonical fields for manifest_sha256. Excludes run_id, locator, warnings, scope
# so unchanged filesystems produce identical manifest checksums.
CANONICAL_HASH_FIELDS = (
    "artifact_class",
    "normalized_path",
    "size_bytes",
    "mtime_epoch",
    "sha256",
    "hash_mode",
    "source_id",
    "discoverer_version",
)

ROW_CAP = int(os.environ.get("MEDICAFE_PHASE_B_ROW_CAP", "100000"))


def _flush_phase_b_fingerprint_cache():
    if flush_phase_b_fingerprint_cache is None:
        return
    try:
        flush_phase_b_fingerprint_cache()
    except Exception:
        pass


def _workspace_root():
    """Workspace root from script location."""
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))


def _resolve_lab_root(args):
    """Lab root: --lab-dir > MEDICAFE_LAB_DIR > workspace/lab."""
    return resolve_lab_root(args.lab_dir, _workspace_root())


def _candidate_to_row(candidate):
    """Build manifest row dict from CandidateArtifact."""
    return {
        "artifact_class": candidate.artifact_class,
        "normalized_path": candidate.normalized_path,
        "size_bytes": candidate.size_bytes,
        "mtime_epoch": candidate.mtime_epoch,
        "mtime_utc": _epoch_to_utc(candidate.mtime_epoch),
        "sha256": candidate.sha256,
        "hash_mode": candidate.hash_mode,
        "source_id": candidate.source_id,
        "scope": candidate.scope,
        "discoverer_version": DISCOVERER_VERSION,
        "warnings": getattr(candidate, "warnings", []) or [],
        "locator": candidate.locator or "",
    }


def _epoch_to_utc(epoch):
    """Format epoch as ISO 8601 UTC."""
    import time
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(epoch))


def _collect_rows(lab_root):
    """
    Layer A: consume adapter, dedupe on canonical_key, emit rows.
    Returns (rows, roots_scanned, errors, config_hash, crosswalk_hash).
    """
    result = resolve_roots(lab_root)
    config_hash = ""
    crosswalk_hash = ""
    if isinstance(result, tuple):
        roots = result[0] if len(result) > 0 else []
        config_hash = result[1] if len(result) > 1 else ""
        crosswalk_hash = result[2] if len(result) > 2 else ""
    else:
        roots = result
    if roots is None:
        roots = []
    if not roots:
        _flush_phase_b_fingerprint_cache()
        return [], [], [{"code": PHASE_B_ROOT_RESOLUTION_FAIL, "message": "No roots resolvable"}], config_hash, crosswalk_hash
    seen = set()
    rows = []
    roots_scanned = []
    errors = []
    for root_spec in roots:
        exists = os.path.isdir(root_spec.root_path)
        root_entry = {
            "source_id": root_spec.source_id,
            "root_path": root_spec.root_path,
            "exists": exists,
            "dat_yield_count": 0,
            "csv_yield_count": 0,
            "yield_counts_by_class": {},
        }
        roots_scanned.append(root_entry)
        if not exists:
            continue
        for candidate in iter_candidates(root_spec):
            if candidate.canonical_key in seen:
                continue
            seen.add(candidate.canonical_key)
            row = _candidate_to_row(candidate)
            rows.append(row)
            artifact_class = str(getattr(candidate, "artifact_class", "") or "")
            yield_counts = root_entry.get("yield_counts_by_class") or {}
            yield_counts[artifact_class] = int(yield_counts.get(artifact_class, 0) or 0) + 1
            root_entry["yield_counts_by_class"] = yield_counts
            if artifact_class == "dat":
                root_entry["dat_yield_count"] = int(root_entry.get("dat_yield_count", 0) or 0) + 1
            if artifact_class == "csv":
                root_entry["csv_yield_count"] = int(root_entry.get("csv_yield_count", 0) or 0) + 1
    existing_count = sum(1 for r in roots_scanned if r.get("exists"))
    if existing_count == 0:
        _flush_phase_b_fingerprint_cache()
        return [], roots_scanned, [{"code": PHASE_B_ROOT_RESOLUTION_FAIL, "message": "No roots resolvable"}], config_hash, crosswalk_hash
    _flush_phase_b_fingerprint_cache()
    return rows, roots_scanned, errors, config_hash, crosswalk_hash


def _discovery_scope_policy_snapshot():
    if get_last_discovery_scope_policy is None:
        return {}
    try:
        policy = get_last_discovery_scope_policy()
        return policy if isinstance(policy, dict) else {}
    except Exception:
        return {}


def _row_sort_key(row):
    """Sort key for manifest rows."""
    return (row.get("artifact_class", ""), row.get("normalized_path", ""))


def _update_hash_from_row(h, row):
    """Update hash with canonical fields of row."""
    canon = {k: row.get(k) for k in CANONICAL_HASH_FIELDS if k in row}
    canon_str = json.dumps(canon, sort_keys=True, separators=(",", ":"))
    h.update(canon_str.encode("utf-8"))


def _manifest_policy_record(policy):
    """Build the JSONL metadata row used by support bundle policy rollups."""
    return {
        "record_type": "phase_b_discovery_scope_policy",
        "schema_version": 1,
        "discovery_scope_policy": policy if isinstance(policy, dict) else {},
    }


def _write_manifest_and_hash(rows, manifest_tmp_path, discovery_scope_policy=None):
    """Sort rows in memory, write JSONL to temp, return manifest_sha256."""
    sorted_rows = sorted(rows, key=_row_sort_key)
    dir_path = os.path.dirname(manifest_tmp_path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    h = hashlib.sha256()
    with open(manifest_tmp_path, "w", encoding="utf-8") as f:
        policy_record = _manifest_policy_record(discovery_scope_policy)
        f.write(json.dumps(policy_record, ensure_ascii=False, sort_keys=True) + "\n")
        for row in sorted_rows:
            line = json.dumps(row, ensure_ascii=False) + "\n"
            f.write(line)
            _update_hash_from_row(h, row)
    return h.hexdigest()


def _write_summary_json(summary, path):
    """Write summary JSON."""
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)


def _write_summary_txt(summary, path):
    """Write human-readable summary."""
    dat_telemetry = summary.get("dat_telemetry") or {}
    csv_telemetry = summary.get("csv_telemetry") or {}
    lines = [
        "Phase B Artifact Discovery Summary",
        "run_id: {0}".format(summary.get("run_id", "")),
        "generated_at_utc: {0}".format(summary.get("generated_at_utc", "")),
        "ok: {0}".format(summary.get("ok", False)),
        "total_rows: {0}".format(summary.get("total_rows", 0)),
        "manifest_sha256: {0}".format(summary.get("manifest_sha256", "")),
        "config_hash: {0}".format(summary.get("config_hash", "")),
        "crosswalk_hash: {0}".format(summary.get("crosswalk_hash", "")),
        "dat_root_scanned_count: {0}".format(dat_telemetry.get("dat_root_scanned_count", 0)),
        "dat_root_existing_count: {0}".format(dat_telemetry.get("dat_root_existing_count", 0)),
        "dat_candidates_seen_count: {0}".format(dat_telemetry.get("dat_candidates_seen_count", 0)),
        "dat_configured_root_count: {0}".format(dat_telemetry.get("dat_configured_root_count", 0)),
        "dat_configured_root_existing_count: {0}".format(dat_telemetry.get("dat_configured_root_existing_count", 0)),
        "dat_configured_root_missing_count: {0}".format(dat_telemetry.get("dat_configured_root_missing_count", 0)),
        "dat_fallback_root_count: {0}".format(dat_telemetry.get("dat_fallback_root_count", 0)),
        "dat_selected_root_count: {0}".format(dat_telemetry.get("dat_selected_root_count", 0)),
        "dat_selection_mode: {0}".format(dat_telemetry.get("dat_selection_mode", "")),
        "dat_selected_root_source_id: {0}".format(dat_telemetry.get("dat_selected_root_source_id", "")),
        "dat_existing_empty_root_count: {0}".format(dat_telemetry.get("dat_existing_empty_root_count", 0)),
        "dat_effective_root_source_id: {0}".format(dat_telemetry.get("dat_effective_root_source_id", "")),
        "dat_yielding_root_source_ids: {0}".format(json.dumps(dat_telemetry.get("dat_yielding_root_source_ids", []))),
        "dat_root_yield_counts_by_source: {0}".format(
            json.dumps(dat_telemetry.get("dat_root_yield_counts_by_source", {}), sort_keys=True, separators=(",", ":"))
        ),
        "dat_manifest_rows_count: {0}".format(dat_telemetry.get("dat_manifest_rows_count", 0)),
        "csv_root_scanned_count: {0}".format(csv_telemetry.get("csv_root_scanned_count", 0)),
        "csv_root_existing_count: {0}".format(csv_telemetry.get("csv_root_existing_count", 0)),
        "csv_configured_root_count: {0}".format(csv_telemetry.get("csv_configured_root_count", 0)),
        "csv_configured_root_existing_count: {0}".format(csv_telemetry.get("csv_configured_root_existing_count", 0)),
        "csv_configured_root_yield_count: {0}".format(csv_telemetry.get("csv_configured_root_yield_count", 0)),
        "csv_manifest_rows_count: {0}".format(csv_telemetry.get("csv_manifest_rows_count", 0)),
        "csv_root_yield_counts_by_source: {0}".format(
            json.dumps(csv_telemetry.get("csv_root_yield_counts_by_source", {}), sort_keys=True, separators=(",", ":"))
        ),
        "csv_blocked_stage: {0}".format(csv_telemetry.get("csv_blocked_stage", "")),
        "post_medisoft_exercised: {0}".format(dat_telemetry.get("post_medisoft_exercised", False)),
        "post_medisoft_blocked_stage: {0}".format(dat_telemetry.get("post_medisoft_blocked_stage", "")),
        "",
        "Roots scanned:",
    ]
    for r in summary.get("roots_scanned", []):
        lines.append("  - {0}: {1} (exists={2}, yields={3})".format(
            r.get("source_id", ""), r.get("root_path", ""), r.get("exists", False),
            json.dumps(r.get("yield_counts_by_class", {}) or {}, sort_keys=True, separators=(",", ":"))
        ))
    lines.append("")
    lines.append("Counts by class:")
    for k, v in sorted(summary.get("counts_by_class", {}).items()):
        lines.append("  {0}: {1}".format(k, v))
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def _build_dat_telemetry(roots_scanned, counts_by_class):
    """Build lightweight DAT discovery telemetry from existing Phase B artifacts."""
    roots_scanned = roots_scanned or []
    counts_by_class = counts_by_class or {}
    dat_roots = [
        root for root in roots_scanned
        if str(root.get("source_id", "")).startswith("dat_")
    ]
    configured_roots = [
        root for root in dat_roots
        if str(root.get("source_id", "")) != "dat_fallback"
    ]
    fallback_roots = [
        root for root in dat_roots
        if str(root.get("source_id", "")) == "dat_fallback"
    ]
    dat_candidates_seen_count = len(dat_roots)
    dat_configured_root_count = len(configured_roots)
    dat_configured_root_existing_count = sum(1 for root in configured_roots if root.get("exists"))
    dat_configured_root_missing_count = max(0, dat_configured_root_count - dat_configured_root_existing_count)
    dat_fallback_root_count = len(fallback_roots)
    dat_root_existing_count = sum(1 for root in dat_roots if root.get("exists"))
    dat_root_yield_counts_by_source = {}
    for root in dat_roots:
        source_id = str(root.get("source_id", "") or "").strip()
        if not source_id:
            continue
        dat_root_yield_counts_by_source[source_id] = int(root.get("dat_yield_count", 0) or 0)
    dat_yielding_root_source_ids = [
        str(root.get("source_id", "") or "").strip()
        for root in dat_roots
        if int(root.get("dat_yield_count", 0) or 0) > 0 and str(root.get("source_id", "") or "").strip()
    ]
    selected_root = None
    selection_mode = "none"
    for root in configured_roots:
        if root.get("exists"):
            selected_root = root
            selection_mode = "configured"
            break
    if selected_root is None:
        for root in fallback_roots:
            if root.get("exists"):
                selected_root = root
                selection_mode = "fallback"
                break
    dat_selected_root_count = 1 if selected_root else 0
    dat_selected_root_source_id = selected_root.get("source_id", "") if selected_root else ""
    dat_selected_root_yield_count = int(selected_root.get("dat_yield_count", 0) or 0) if selected_root else 0
    dat_existing_empty_root_count = sum(
        1 for root in dat_roots
        if root.get("exists") and int(root.get("dat_yield_count", 0) or 0) == 0
    )
    dat_effective_root_source_id = dat_yielding_root_source_ids[0] if dat_yielding_root_source_ids else ""
    dat_manifest_rows_count = int(counts_by_class.get("dat", 0) or 0)
    post_medisoft_exercised = bool(dat_manifest_rows_count > 0)
    if post_medisoft_exercised:
        blocked_stage = ""
    elif dat_selected_root_count > 0 and dat_selected_root_yield_count == 0:
        blocked_stage = "empty_root"
    elif dat_yielding_root_source_ids:
        blocked_stage = "discovery"
    elif dat_configured_root_count > 0:
        blocked_stage = "missing_root"
    else:
        blocked_stage = "not_configured"
    return {
        "dat_root_scanned_count": dat_candidates_seen_count,
        "dat_root_existing_count": dat_root_existing_count,
        "dat_candidates_seen_count": dat_candidates_seen_count,
        "dat_configured_root_count": dat_configured_root_count,
        "dat_configured_root_existing_count": dat_configured_root_existing_count,
        "dat_configured_root_missing_count": dat_configured_root_missing_count,
        "dat_fallback_root_count": dat_fallback_root_count,
        "dat_selected_root_count": dat_selected_root_count,
        "dat_selection_mode": selection_mode,
        "dat_selected_root_source_id": dat_selected_root_source_id,
        "dat_root_yield_counts_by_source": dat_root_yield_counts_by_source,
        "dat_yielding_root_source_ids": dat_yielding_root_source_ids,
        "dat_existing_empty_root_count": dat_existing_empty_root_count,
        "dat_effective_root_source_id": dat_effective_root_source_id,
        "dat_manifest_rows_count": dat_manifest_rows_count,
        "post_medisoft_exercised": post_medisoft_exercised,
        "post_medisoft_blocked_stage": blocked_stage,
    }


def _build_csv_telemetry(roots_scanned, counts_by_class):
    """Build CSV discovery telemetry so missing active CSV roots are visible."""
    roots_scanned = roots_scanned or []
    counts_by_class = counts_by_class or {}
    csv_roots = [
        root for root in roots_scanned
        if str(root.get("source_id", "")).startswith("csv_")
    ]
    configured_roots = [
        root for root in csv_roots
        if str(root.get("source_id", "")) == "csv_configured"
    ]
    csv_root_yield_counts_by_source = {}
    for root in csv_roots:
        source_id = str(root.get("source_id", "") or "").strip()
        if not source_id:
            continue
        csv_root_yield_counts_by_source[source_id] = int(root.get("csv_yield_count", 0) or 0)
    csv_yielding_root_source_ids = [
        str(root.get("source_id", "") or "").strip()
        for root in csv_roots
        if int(root.get("csv_yield_count", 0) or 0) > 0 and str(root.get("source_id", "") or "").strip()
    ]
    csv_manifest_rows_count = int(counts_by_class.get("csv", 0) or 0)
    configured_existing = sum(1 for root in configured_roots if root.get("exists"))
    configured_yield_count = sum(int(root.get("csv_yield_count", 0) or 0) for root in configured_roots)
    if csv_manifest_rows_count > 0:
        blocked_stage = ""
    elif configured_roots and configured_existing == 0:
        blocked_stage = "configured_root_missing"
    elif configured_roots and configured_yield_count == 0:
        blocked_stage = "configured_root_empty"
    elif csv_roots:
        blocked_stage = "no_csv_rows"
    else:
        blocked_stage = "not_configured"
    return {
        "csv_root_scanned_count": len(csv_roots),
        "csv_root_existing_count": sum(1 for root in csv_roots if root.get("exists")),
        "csv_configured_root_count": len(configured_roots),
        "csv_configured_root_existing_count": configured_existing,
        "csv_configured_root_yield_count": configured_yield_count,
        "csv_root_yield_counts_by_source": csv_root_yield_counts_by_source,
        "csv_yielding_root_source_ids": csv_yielding_root_source_ids,
        "csv_manifest_rows_count": csv_manifest_rows_count,
        "csv_blocked_stage": blocked_stage,
    }


def _persist_phase_b_state(lab_root, rid, ok, error_code, manifest_path, manifest_sha256,
                           counts_by_class, dat_telemetry=None, csv_telemetry=None):
    """Update run_cursor.json and diagnostics_state.json with Phase B outcome."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    now = iso_utc_now()
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            state = {}
    if not isinstance(state, dict):
        state = {}
    circuit_open = bool(state.get("phase_c_circuit_open"))
    cursor = {}
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    cursor["last_phase_b_run_id"] = rid
    if circuit_open and ok and manifest_path and manifest_sha256:
        cursor["last_discovery_skipped_due_to_phase_c_circuit"] = True
        cursor["last_discovery_pending_manifest_path"] = manifest_path
        cursor["last_discovery_pending_manifest_sha256"] = manifest_sha256
        cursor["last_discovery_pending_phase_b_run_id"] = rid
    else:
        cursor["last_manifest_path"] = manifest_path
        cursor["last_manifest_sha256"] = manifest_sha256
        cursor["last_discovery_skipped_due_to_phase_c_circuit"] = False
    cursor["last_discovery_ok"] = ok
    cursor["last_discovery_counts_by_class"] = counts_by_class or {}
    cursor["last_discovery_dat_telemetry"] = dat_telemetry or {}
    cursor["last_discovery_csv_telemetry"] = csv_telemetry or {}
    cursor["last_discovery_error_code"] = error_code
    cursor["last_discovery_at_utc"] = now
    refresh_run_cursor_updated_at(cursor)
    replace_safe_write(cursor_path, cursor)
    state["last_phase_b_run_id"] = rid
    if circuit_open and ok and manifest_path and manifest_sha256:
        state["last_discovery_skipped_due_to_phase_c_circuit"] = True
        state["last_discovery_pending_manifest_path"] = manifest_path
        state["last_discovery_pending_manifest_sha256"] = manifest_sha256
        state["last_discovery_pending_phase_b_run_id"] = rid
    else:
        state["last_manifest_path"] = manifest_path
        state["last_manifest_sha256"] = manifest_sha256
        state["last_discovery_skipped_due_to_phase_c_circuit"] = False
    state["last_discovery_ok"] = ok
    state["last_discovery_error_code"] = error_code
    state["last_discovery_counts_by_class"] = counts_by_class or {}
    state["last_discovery_dat_telemetry"] = dat_telemetry or {}
    state["last_discovery_csv_telemetry"] = csv_telemetry or {}
    state["last_discovery_at_utc"] = now
    replace_safe_write(state_path, state)

def run_discovery(lab_root):
    """
    Main discovery flow. Returns (ok, run_id, manifest_path, summary, error_code).
    """
    rid = run_id()
    reports_dir = os.path.join(lab_root, "reports")
    manifest_tmp = os.path.join(reports_dir, "artifact_manifest_{0}.jsonl.tmp".format(rid))
    manifest_final = os.path.join(reports_dir, "artifact_manifest_{0}.jsonl".format(rid))
    summary_json = os.path.join(reports_dir, "artifact_discovery_summary_{0}.json".format(rid))
    summary_txt = os.path.join(reports_dir, "artifact_discovery_summary_{0}.txt".format(rid))

    rows, roots_scanned, errors, config_hash, crosswalk_hash = _collect_rows(lab_root)
    if errors and any(e.get("code") == PHASE_B_ROOT_RESOLUTION_FAIL for e in errors):
        dat_telemetry = _build_dat_telemetry(roots_scanned, {})
        csv_telemetry = _build_csv_telemetry(roots_scanned, {})
        summary_fail = {
            "run_id": rid,
            "generated_at_utc": iso_utc_now(),
            "ok": False,
            "total_rows": 0,
            "manifest_sha256": None,
            "roots_scanned": roots_scanned,
            "counts_by_class": {},
            "errors": errors,
            "config_hash": config_hash,
            "crosswalk_hash": crosswalk_hash,
            "dat_telemetry": dat_telemetry,
            "csv_telemetry": csv_telemetry,
            "discovery_scope_policy": _discovery_scope_policy_snapshot(),
        }
        try:
            acquire_lock(lab_root)
            try:
                summary_json_path = os.path.join(
                    lab_root, "reports",
                    "artifact_discovery_summary_{0}.json".format(rid),
                )
                summary_txt_path = os.path.join(
                    lab_root, "reports",
                    "artifact_discovery_summary_{0}.txt".format(rid),
                )
                reports_dir = os.path.dirname(summary_json_path)
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_summary_json(summary_fail, summary_json_path)
                _write_summary_txt(summary_fail, summary_txt_path)
                
                _persist_phase_b_state(
                    lab_root, rid, False, PHASE_B_ROOT_RESOLUTION_FAIL,
                    None, None, {}, dat_telemetry, csv_telemetry,
                )
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_b_auto_report import submit_phase_b_failure_report
                submit_phase_b_failure_report(lab_root, {
                    "error_code": PHASE_B_ROOT_RESOLUTION_FAIL,
                    "run_id": rid,
                    "first_failed": "no_roots",
                    "lab_root": lab_root,
                    "report_json_path": summary_json_path,
                    "report_txt_path": summary_txt_path,
                    "summary": summary_fail,
                })
            except Exception:
                pass
        except SystemExit:
            pass
        return False, rid, None, summary_fail, PHASE_B_ROOT_RESOLUTION_FAIL

    counts_by_class = {}
    for r in rows:
        c = r.get("artifact_class", "unknown")
        counts_by_class[c] = counts_by_class.get(c, 0) + 1

    if len(rows) > ROW_CAP:
        msg = "Row count {0} exceeds cap {1}".format(len(rows), ROW_CAP)
        dat_telemetry = _build_dat_telemetry(roots_scanned, counts_by_class)
        csv_telemetry = _build_csv_telemetry(roots_scanned, counts_by_class)
        summary_fail = {
            "run_id": rid,
            "generated_at_utc": iso_utc_now(),
            "ok": False,
            "total_rows": len(rows),
            "manifest_sha256": None,
            "roots_scanned": roots_scanned,
            "counts_by_class": counts_by_class,
            "errors": [{"code": PHASE_B_MANIFEST_ROW_CAP_EXCEEDED, "message": msg}],
            "config_hash": config_hash,
            "crosswalk_hash": crosswalk_hash,
            "dat_telemetry": dat_telemetry,
            "csv_telemetry": csv_telemetry,
            "discovery_scope_policy": _discovery_scope_policy_snapshot(),
        }
        try:
            acquire_lock(lab_root)
            try:
                reports_dir = os.path.join(lab_root, "reports")
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_summary_json(summary_fail, summary_json)
                _write_summary_txt(summary_fail, summary_txt)
                _persist_phase_b_state(
                    lab_root, rid, False, PHASE_B_MANIFEST_ROW_CAP_EXCEEDED,
                    None, None, counts_by_class, dat_telemetry, csv_telemetry,
                )
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_b_auto_report import submit_phase_b_failure_report
                submit_phase_b_failure_report(lab_root, {
                    "error_code": PHASE_B_MANIFEST_ROW_CAP_EXCEEDED,
                    "run_id": rid,
                    "first_failed": "row_cap",
                    "lab_root": lab_root,
                    "report_json_path": summary_json,
                    "report_txt_path": summary_txt,
                    "summary": summary_fail,
                })
            except Exception:
                pass
        except SystemExit:
            pass
        return False, rid, None, summary_fail, PHASE_B_MANIFEST_ROW_CAP_EXCEEDED

    try:
        manifest_sha256 = _write_manifest_and_hash(rows, manifest_tmp, _discovery_scope_policy_snapshot())
    except (IOError, OSError) as e:
        dat_telemetry = _build_dat_telemetry(roots_scanned, counts_by_class)
        csv_telemetry = _build_csv_telemetry(roots_scanned, counts_by_class)
        summary_fail = {
            "run_id": rid,
            "generated_at_utc": iso_utc_now(),
            "ok": False,
            "total_rows": len(rows),
            "manifest_sha256": None,
            "roots_scanned": roots_scanned,
            "counts_by_class": counts_by_class,
            "errors": [{"code": PHASE_B_MANIFEST_WRITE_FAIL, "message": str(e)}],
            "config_hash": config_hash,
            "crosswalk_hash": crosswalk_hash,
            "dat_telemetry": dat_telemetry,
            "csv_telemetry": csv_telemetry,
        }
        try:
            acquire_lock(lab_root)
            try:
                reports_dir = os.path.join(lab_root, "reports")
                if not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_summary_json(summary_fail, summary_json)
                _write_summary_txt(summary_fail, summary_txt)
                _persist_phase_b_state(
                    lab_root, rid, False, PHASE_B_MANIFEST_WRITE_FAIL,
                    None, None, counts_by_class, dat_telemetry, csv_telemetry,
                )
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_b_auto_report import submit_phase_b_failure_report
                submit_phase_b_failure_report(lab_root, {
                    "error_code": PHASE_B_MANIFEST_WRITE_FAIL,
                    "run_id": rid,
                    "first_failed": "manifest_write",
                    "lab_root": lab_root,
                    "report_json_path": summary_json,
                    "report_txt_path": summary_txt,
                    "summary": summary_fail,
                })
            except Exception:
                pass
        except SystemExit:
            pass
        return False, rid, None, summary_fail, PHASE_B_MANIFEST_WRITE_FAIL
    dat_telemetry = _build_dat_telemetry(roots_scanned, counts_by_class)
    csv_telemetry = _build_csv_telemetry(roots_scanned, counts_by_class)
    summary = {
        "run_id": rid,
        "generated_at_utc": iso_utc_now(),
        "ok": True,
        "total_rows": len(rows),
        "manifest_sha256": manifest_sha256,
        "roots_scanned": roots_scanned,
        "counts_by_class": counts_by_class,
        "errors": errors,
        "config_hash": config_hash,
        "crosswalk_hash": crosswalk_hash,
        "dat_telemetry": dat_telemetry,
        "csv_telemetry": csv_telemetry,
        "discovery_scope_policy": _discovery_scope_policy_snapshot(),
    }

    try:
        acquire_lock(lab_root)
    except SystemExit:
        return False, rid, None, summary, PHASE_B_LOCK_FAIL

    try:
        if os.path.exists(manifest_tmp):
            if os.path.exists(manifest_final):
                try:
                    os.remove(manifest_final)
                except Exception:
                    pass
            os.rename(manifest_tmp, manifest_final)
        _write_summary_json(summary, summary_json)
        _write_summary_txt(summary, summary_txt)
        _persist_phase_b_state(
            lab_root, rid, True, None,
            manifest_final, manifest_sha256, counts_by_class, dat_telemetry, csv_telemetry,
        )
        return True, rid, manifest_final, summary, None
    finally:
        release_lock(lab_root, owner_pid=os.getpid())


def main():
    parser = argparse.ArgumentParser(description="Phase B artifact discovery")
    parser.add_argument("--lab-dir", help="Override lab root (default: MEDICAFE_LAB_DIR or workspace/lab)")
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    ok, rid, manifest_path, summary, error_code = run_discovery(lab_root)
    if not ok:
        print("Phase B discovery failed: {0}".format(error_code), file=sys.stderr)
        sys.exit(1)
    print("Phase B discovery ok: {0} rows, manifest={1}".format(
        summary.get("total_rows", 0), manifest_path or ""))


if __name__ == "__main__":
    main()
