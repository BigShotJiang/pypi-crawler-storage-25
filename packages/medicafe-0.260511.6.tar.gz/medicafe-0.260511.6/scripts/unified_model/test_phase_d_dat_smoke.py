# -*- coding: utf-8 -*-
"""Tests for Phase D DAT smoke harness. XP-compatible: Python 3.4+, stdlib only."""
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

from phase_d_milestone_gate import (
    VERDICT_NOT_ADVANCED,
    VERDICT_PARTIALLY_ADVANCED,
    strict_gate_for_missing_shadow_report,
)
from phase_d_dat_smoke_common import (
    build_smoke_report,
    build_reference_diff,
    format_smoke_stdout_ladder,
    format_smoke_txt,
    load_phase_b_summary,
    _parse_phase_b_txt,
)


def _make_lab():
    lab_root = tempfile.mkdtemp()
    reports = os.path.join(lab_root, "reports")
    os.makedirs(reports)
    return lab_root, reports


def _touch_evidence(reports_dir, anchor):
    """Minimal files so evaluate_phase_d_qa_milestone_exit evidence_coherence passes."""
    ix = os.path.join(reports_dir, "shadow_evidence_index_{0}.json".format(anchor))
    with open(ix, "w", encoding="utf-8") as f:
        json.dump({"run_id": anchor}, f)
    qs = os.path.join(reports_dir, "qa_reject_samples_{0}.jsonl".format(anchor))
    with open(qs, "w", encoding="utf-8") as f:
        f.write("")


def _write_b_json(reports_dir, rid, data):
    p = os.path.join(reports_dir, "artifact_discovery_summary_{0}.json".format(rid))
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f)
    return p


def _write_c_json(reports_dir, rid, data):
    p = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(rid))
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f)
    return p


def _write_d_json(reports_dir, rid, data):
    p = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(rid))
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f)
    return p


def _write_e_json(reports_dir, rid, data):
    p = os.path.join(reports_dir, "projection_parity_summary_{0}.json".format(rid))
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f)
    return p


def _shadow_payload(
    anchor,
    paths,
    phase_run_ids,
    pipeline_ok=True,
    failed_phase="",
    dat_sel=2,
    dat_pass=0,
    dat_rej=2,
    dat_can=0,
):
    return {
        "run_id": anchor,
        "pipeline_ok": pipeline_ok,
        "failed_phase": failed_phase,
        "error_code": "",
        "phase_run_ids": phase_run_ids,
        "source_summary_paths": [
            paths["B"],
            paths["C"],
            paths["D"],
            paths["E"],
        ],
        "phase_d_dat_selected_count": dat_sel,
        "phase_d_dat_qa_pass_count": dat_pass,
        "phase_d_dat_qa_reject_count": dat_rej,
        "phase_d_dat_canonical_record_count": dat_can,
        "post_medisoft_blocked_stage": "qa",
        "phase_d_entity_scope": "v1",
        "phase_d_dat_v2_inserted_total": 0,
        "phase_d_dat_v2_payload_attempted_total": 0,
        "phase_d_dat_field_presence_by_alias": {},
    }


class TestPhaseDDatSmoke(unittest.TestCase):
    def test_strict_gate_missing_shadow(self):
        sg = strict_gate_for_missing_shadow_report()
        self.assertFalse(sg.get("evaluated"))
        self.assertIn("shadow_report_missing", sg.get("reasons") or [])

    def test_duplicate_only_no_new_ingest_gap(self):
        lab_root, reports_dir = _make_lab()
        try:
            rb, rc, rd, re = "rb1", "rc1", "rd1", "re1"
            pb = _write_b_json(
                lab_root,
                rb,
                {
                    "dat_telemetry": {"dat_manifest_rows_count": 5},
                },
            )
            pc = _write_c_json(
                lab_root,
                rc,
                {
                    "counts_by_class": {"dat": 390},
                    "rows_inserted": 0,
                    "rows_inserted_by_class": {"dat": 0},
                    "phase_c_duplicate_only": True,
                },
            )
            pd = _write_d_json(
                lab_root,
                rd,
                {
                    "run_id": rd,
                    "selection_scope": "new_artifacts_current_qa_only",
                    "dat_telemetry": {
                        "dat_selected_count": 0,
                        "dat_qa_pass_count": 0,
                        "dat_qa_reject_count": 0,
                        "dat_canonical_record_count": 0,
                        "post_medisoft_blocked_stage": "not_exercised",
                    },
                },
            )
            pe = _write_e_json(lab_root, re, {"eligible_count": 0})
            anchor = "anchor-x"
            paths = {"B": pb, "C": pc, "D": pd, "E": pe}
            sp = _shadow_payload(
                anchor,
                paths,
                {"B": rb, "C": rc, "D": rd, "E": re},
                dat_sel=0,
                dat_pass=0,
                dat_rej=0,
                dat_can=0,
            )
            sp["post_medisoft_blocked_stage"] = "not_exercised"
            sp["phase_d_dat_selected_count"] = 0
            shadow_path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(anchor))
            _touch_evidence(reports_dir, anchor)
            with open(shadow_path, "w", encoding="utf-8") as f:
                json.dump(sp, f)
            r = build_smoke_report(lab_root, anchor_run_id=anchor)
            self.assertFalse(r.get("phase_b_to_c_new_ingest_gap"))
            self.assertEqual(r.get("assessment"), "dat_discovered_not_ingested")
            self.assertEqual(r.get("assessment_detail"), "phase_c_ingest_explained_by_duplicates")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_legacy_xp_duplicate_explained_without_phase_c_flags(self):
        """High dat rows skipped as duplicates with zero inserts; no phase_c_duplicate_only in summary."""
        lab_root, reports_dir = _make_lab()
        try:
            rb, rc, rd, re = "rbx", "rcx", "rdx", "rex"
            pb = _write_b_json(
                lab_root,
                rb,
                {
                    "dat_telemetry": {"dat_manifest_rows_count": 5},
                },
            )
            pc = _write_c_json(
                lab_root,
                rc,
                {
                    "counts_by_class": {"dat": 390},
                    "rows_inserted": 0,
                    "rows_inserted_by_class": {"dat": 0},
                    "rows_skipped_duplicate": 390,
                },
            )
            pd = _write_d_json(
                lab_root,
                rd,
                {
                    "run_id": rd,
                    "selection_scope": "new_artifacts_current_qa_only",
                    "dat_telemetry": {
                        "dat_selected_count": 0,
                        "dat_qa_pass_count": 0,
                        "dat_qa_reject_count": 0,
                        "dat_canonical_record_count": 0,
                        "post_medisoft_blocked_stage": "not_exercised",
                    },
                },
            )
            pe = _write_e_json(lab_root, re, {"eligible_count": 0})
            anchor = "anchor-legacy-dup"
            paths = {"B": pb, "C": pc, "D": pd, "E": pe}
            sp = _shadow_payload(
                anchor,
                paths,
                {"B": rb, "C": rc, "D": rd, "E": re},
                dat_sel=0,
                dat_pass=0,
                dat_rej=0,
                dat_can=0,
            )
            sp["post_medisoft_blocked_stage"] = "not_exercised"
            sp["phase_d_dat_selected_count"] = 0
            shadow_path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(anchor))
            _touch_evidence(reports_dir, anchor)
            with open(shadow_path, "w", encoding="utf-8") as f:
                json.dump(sp, f)
            r = build_smoke_report(lab_root, anchor_run_id=anchor)
            self.assertFalse(r.get("phase_b_to_c_new_ingest_gap"))
            df = r.get("dat_funnel") or {}
            self.assertTrue(df.get("phase_c_ingest_explained_by_duplicates"))
            self.assertEqual(r.get("assessment"), "dat_discovered_not_ingested")
            self.assertEqual(r.get("assessment_detail"), "phase_c_ingest_explained_by_duplicates")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_no_ingest_without_duplicates_keeps_not_ingested_assessment(self):
        lab_root, reports_dir = _make_lab()
        try:
            rb, rc, rd, re = "rba", "rca", "rda", "rea"
            pb = _write_b_json(lab_root, rb, {"dat_telemetry": {"dat_manifest_rows_count": 5}})
            pc = _write_c_json(
                lab_root,
                rc,
                {
                    "counts_by_class": {"dat": 5},
                    "rows_inserted": 0,
                    "rows_inserted_by_class": {"dat": 0},
                    "rows_skipped_duplicate": 0,
                },
            )
            pd = _write_d_json(
                lab_root,
                rd,
                {
                    "run_id": rd,
                    "selection_scope": "new_artifacts_current_qa_only",
                    "dat_telemetry": {
                        "dat_selected_count": 0,
                        "dat_qa_pass_count": 0,
                        "dat_qa_reject_count": 0,
                        "dat_canonical_record_count": 0,
                        "post_medisoft_blocked_stage": "not_exercised",
                    },
                },
            )
            pe = _write_e_json(lab_root, re, {"eligible_count": 0})
            anchor = "anchor-no-ingest"
            paths = {"B": pb, "C": pc, "D": pd, "E": pe}
            sp = _shadow_payload(
                anchor,
                paths,
                {"B": rb, "C": rc, "D": rd, "E": re},
                dat_sel=0,
                dat_pass=0,
                dat_rej=0,
                dat_can=0,
            )
            sp["post_medisoft_blocked_stage"] = "not_exercised"
            sp["phase_d_dat_selected_count"] = 0
            shadow_path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(anchor))
            _touch_evidence(reports_dir, anchor)
            with open(shadow_path, "w", encoding="utf-8") as f:
                json.dump(sp, f)
            r = build_smoke_report(lab_root, anchor_run_id=anchor)
            self.assertTrue(r.get("phase_b_to_c_new_ingest_gap"))
            self.assertEqual(r.get("assessment"), "dat_discovered_not_ingested")
            self.assertFalse(bool(r.get("assessment_detail")))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_dev_like_qa_blocked(self):
        lab_root, reports_dir = _make_lab()
        try:
            rb, rc, rd, re = "b2", "c2", "d2", "e2"
            pb = _write_b_json(
                lab_root,
                rb,
                {"dat_telemetry": {"dat_manifest_rows_count": 3}},
            )
            pc = _write_c_json(
                lab_root,
                rc,
                {
                    "counts_by_class": {"dat": 3},
                    "rows_inserted_by_class": {"dat": 3},
                    "phase_c_duplicate_only": False,
                },
            )
            pd = _write_d_json(
                lab_root,
                rd,
                {
                    "run_id": rd,
                    "selection_scope": "new_artifacts_current_qa_only",
                    "dat_telemetry": {
                        "dat_selected_count": 2,
                        "dat_qa_pass_count": 0,
                        "dat_qa_reject_count": 2,
                        "dat_canonical_record_count": 0,
                        "post_medisoft_blocked_stage": "qa",
                    },
                },
            )
            pe = _write_e_json(lab_root, re, {})
            anchor = "anchor-dev"
            paths = {"B": pb, "C": pc, "D": pd, "E": pe}
            sp = _shadow_payload(anchor, paths, {"B": rb, "C": rc, "D": rd, "E": re})
            shadow_path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(anchor))
            _touch_evidence(reports_dir, anchor)
            with open(shadow_path, "w", encoding="utf-8") as f:
                json.dump(sp, f)
            r = build_smoke_report(lab_root, anchor_run_id=anchor)
            self.assertEqual(r.get("assessment"), "dat_selected_qa_blocked")
            self.assertFalse(r.get("phase_b_to_d_handoff_gap"))
            self.assertEqual(r.get("strict_milestone_verdict"), VERDICT_PARTIALLY_ADVANCED)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_c_to_d_selection_gap(self):
        lab_root, reports_dir = _make_lab()
        try:
            rb, rc, rd, re = "b3", "c3", "d3", "e3"
            pb = _write_b_json(lab_root, rb, {"dat_telemetry": {"dat_manifest_rows_count": 2}})
            pc = _write_c_json(
                lab_root,
                rc,
                {
                    "rows_inserted_by_class": {"dat": 2},
                    "phase_c_duplicate_only": False,
                },
            )
            pd = _write_d_json(
                lab_root,
                rd,
                {
                    "run_id": rd,
                    "dat_telemetry": {
                        "dat_selected_count": 0,
                        "post_medisoft_blocked_stage": "",
                    },
                },
            )
            pe = _write_e_json(lab_root, re, {})
            anchor = "anchor-sel"
            paths = {"B": pb, "C": pc, "D": pd, "E": pe}
            sp = _shadow_payload(
                anchor,
                paths,
                {"B": rb, "C": rc, "D": rd, "E": re},
                dat_sel=0,
                dat_pass=0,
                dat_rej=0,
                dat_can=0,
            )
            sp["phase_d_dat_selected_count"] = 0
            shadow_path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(anchor))
            _touch_evidence(reports_dir, anchor)
            with open(shadow_path, "w", encoding="utf-8") as f:
                json.dump(sp, f)
            r = build_smoke_report(lab_root, anchor_run_id=anchor)
            self.assertTrue(r.get("phase_c_to_d_selection_gap"))
            self.assertFalse(r.get("phase_b_to_c_new_ingest_gap"))
            self.assertEqual(r.get("assessment"), "dat_ingested_not_selected")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_d_summary_run_id_mismatch(self):
        lab_root, reports_dir = _make_lab()
        try:
            rb, rc, rd, re = "b4", "c4", "d4", "e4"
            pb = _write_b_json(lab_root, rb, {"dat_telemetry": {"dat_manifest_rows_count": 1}})
            pc = _write_c_json(lab_root, rc, {"rows_inserted_by_class": {"dat": 0}, "phase_c_duplicate_only": True})
            pd = _write_d_json(
                lab_root,
                rd,
                {"run_id": "wrong-id", "dat_telemetry": {"dat_selected_count": 0}},
            )
            pe = _write_e_json(lab_root, re, {})
            anchor = "anchor-mis"
            paths = {"B": pb, "C": pc, "D": pd, "E": pe}
            sp = _shadow_payload(anchor, paths, {"B": rb, "C": rc, "D": rd, "E": re}, dat_sel=0)
            sp["phase_d_dat_selected_count"] = 0
            shadow_path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(anchor))
            _touch_evidence(reports_dir, anchor)
            with open(shadow_path, "w", encoding="utf-8") as f:
                json.dump(sp, f)
            r = build_smoke_report(lab_root, anchor_run_id=anchor)
            self.assertFalse(r.get("phase_d_summary_integrity_ok"))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_b_txt_parser(self):
        lab_root, reports_dir = _make_lab()
        try:
            txt_path = os.path.join(reports_dir, "artifact_discovery_summary_ridtxt.txt")
            lines = [
                "Phase B Artifact Discovery Summary",
                "run_id: ridtxt",
                "dat_manifest_rows_count: 4",
                "post_medisoft_exercised: True",
                "dat_selection_mode: configured",
                "dat_selected_root_source_id: src1",
                'dat_yielding_root_source_ids: ["a"]',
                'dat_root_yield_counts_by_source: {"a":1}',
            ]
            with open(txt_path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
            parsed = _parse_phase_b_txt(txt_path)
            self.assertIsNotNone(parsed)
            dt = parsed.get("dat_telemetry") or {}
            self.assertEqual(dt.get("dat_manifest_rows_count"), 4)
            self.assertTrue(dt.get("post_medisoft_exercised"))
            self.assertEqual(dt.get("dat_selection_mode"), "configured")
            loaded = load_phase_b_summary(txt_path)
            self.assertEqual(loaded.get("dat_telemetry", {}).get("dat_manifest_rows_count"), 4)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_reference_diff_shape(self):
        cur = {
            "run_id": "d-a",
            "rows_selected": 3,
            "qa_pass_count": 0,
            "dat_telemetry": {
                "dat_selected_count": 2,
                "dat_qa_reject_counts_by_reason": {"X": 1},
                "dat_parse_diagnostics": {"record_shape_counts": {"a": 1}, "tuple_parse_failure_count": 0},
            },
        }
        ref = {
            "run_id": "d-b",
            "rows_selected": 0,
            "qa_pass_count": 0,
            "dat_telemetry": {"dat_selected_count": 0},
        }
        rd = build_reference_diff(cur, ref, "labref")
        self.assertEqual(rd.get("reference_label"), "labref")
        self.assertEqual(rd.get("reference_phase_d_run_id"), "d-b")
        self.assertIn("dat_selected_count", rd.get("fields") or {})

    def test_diagnostics_context_source(self):
        lab_root, reports_dir = _make_lab()
        try:
            st_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(st_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "phase_d_remediation": {
                            "issue_code": "IC1",
                            "verification_scope": "dat_lane_only",
                            "verification_target": "t1",
                            "context_run_id": "cr1",
                        }
                    },
                    f,
                )
            rb, rc, rd, re = "bx", "cx", "dx", "ex"
            pb = _write_b_json(lab_root, rb, {"dat_telemetry": {"dat_manifest_rows_count": 0}})
            pc = _write_c_json(lab_root, rc, {})
            pd = _write_d_json(lab_root, rd, {"run_id": rd, "dat_telemetry": {}})
            pe = _write_e_json(lab_root, re, {})
            anchor = "anchor-diag"
            paths = {"B": pb, "C": pc, "D": pd, "E": pe}
            sp = _shadow_payload(anchor, paths, {"B": rb, "C": rc, "D": rd, "E": re}, dat_sel=0)
            sp["phase_d_dat_selected_count"] = 0
            shadow_path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(anchor))
            _touch_evidence(reports_dir, anchor)
            with open(shadow_path, "w", encoding="utf-8") as f:
                json.dump(sp, f)
            r = build_smoke_report(lab_root, anchor_run_id=anchor)
            dc = r.get("diagnostics_context") or {}
            self.assertEqual(dc.get("source"), "diagnostics_state.phase_d_remediation")
            self.assertEqual(dc.get("issue_code"), "IC1")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_already_running_no_report(self):
        lab_root, reports_dir = _make_lab()
        try:
            import run_phase_d_dat_smoke as rsd

            with patch("run_shadow_pipeline.run_shadow_pipeline") as m:
                m.return_value = (False, "rid", None, "already_running")
                argv = [
                    "run_phase_d_dat_smoke.py",
                    "--lab-dir",
                    lab_root,
                ]
                with patch.object(sys, "argv", argv):
                    rc = rsd.main()
            self.assertEqual(rc, 0)
            found = [f for f in os.listdir(reports_dir) if f.startswith("phase_d_dat_smoke_report_")]
            self.assertEqual(found, [])
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_runner_binds_report_to_pipeline_run_id(self):
        lab_root, reports_dir = _make_lab()
        try:
            import run_phase_d_dat_smoke as rsd

            rid = "rid-anchor"
            with open(
                os.path.join(reports_dir, "shadow_run_report_{0}.json".format(rid)),
                "w",
                encoding="utf-8",
            ) as f:
                json.dump({"run_id": rid}, f)
            with patch("run_shadow_pipeline.run_shadow_pipeline") as m:
                m.return_value = (True, rid, None, "")
                with patch.object(rsd, "build_smoke_report") as m_build:
                    m_build.return_value = {
                        "anchor_run_id": rid,
                        "assessment": "pipeline_incomplete",
                        "phase_run_ids": {},
                        "dat_funnel": {},
                    }
                    argv = [
                        "run_phase_d_dat_smoke.py",
                        "--lab-dir",
                        lab_root,
                    ]
                    with patch.object(sys, "argv", argv):
                        rc = rsd.main()
            self.assertEqual(rc, 0)
            self.assertEqual(m_build.call_args[1].get("anchor_run_id"), rid)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_runner_fails_closed_when_pipeline_run_id_missing(self):
        lab_root, reports_dir = _make_lab()
        try:
            import run_phase_d_dat_smoke as rsd

            with patch("run_shadow_pipeline.run_shadow_pipeline") as m:
                m.return_value = (True, "", None, "")
                argv = [
                    "run_phase_d_dat_smoke.py",
                    "--lab-dir",
                    lab_root,
                ]
                with patch.object(sys, "argv", argv):
                    rc = rsd.main()
            self.assertEqual(rc, 1)
            found = [f for f in os.listdir(reports_dir) if f.startswith("phase_d_dat_smoke_report_")]
            self.assertEqual(found, [])
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_runner_fails_closed_when_anchor_shadow_missing(self):
        lab_root, reports_dir = _make_lab()
        try:
            import run_phase_d_dat_smoke as rsd

            rid = "rid-missing-shadow"
            with patch("run_shadow_pipeline.run_shadow_pipeline") as m:
                m.return_value = (True, rid, None, "")
                with patch.object(rsd, "build_smoke_report") as m_build:
                    argv = [
                        "run_phase_d_dat_smoke.py",
                        "--lab-dir",
                        lab_root,
                    ]
                    with patch.object(sys, "argv", argv):
                        rc = rsd.main()
            self.assertEqual(rc, 1)
            m_build.assert_not_called()
            found = [f for f in os.listdir(reports_dir) if f.startswith("phase_d_dat_smoke_report_")]
            self.assertEqual(found, [])
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_completed_smoke_returns_code_2_when_state_attempt_id_superseded(self):
        """If another attempt overwrote last_attempt_id, do not exit 0 without persisting state."""
        lab_root, reports_dir = _make_lab()
        state_fd, state_path = tempfile.mkstemp(suffix=".json")
        os.close(state_fd)
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_attempt_id": "anchor:context:issue:9999999999",
                        "last_status": "started",
                    },
                    f,
                )
            rid = "rid-supersede"
            with open(
                os.path.join(reports_dir, "shadow_run_report_{0}.json".format(rid)),
                "w",
                encoding="utf-8",
            ) as f:
                json.dump({"run_id": rid}, f)
            import run_phase_d_dat_smoke as rsd

            with patch("run_shadow_pipeline.run_shadow_pipeline") as m:
                m.return_value = (True, rid, None, "")
                with patch.object(rsd, "_begin_state_attempt"):
                    with patch.object(rsd, "build_smoke_report") as m_build:
                        m_build.return_value = {
                            "anchor_run_id": rid,
                            "assessment": "pipeline_incomplete",
                            "phase_run_ids": {},
                            "dat_funnel": {},
                        }
                        argv = [
                            "run_phase_d_dat_smoke.py",
                            "--lab-dir",
                            lab_root,
                            "--state-path",
                            state_path,
                            "--attempt-id",
                            "anchor:context:issue:1111111111",
                        ]
                        with patch.object(sys, "argv", argv):
                            rc = rsd.main()
            self.assertEqual(rc, 2)
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertNotEqual(str(st.get("last_status", "") or "").strip(), "completed")
            found = [f for f in os.listdir(reports_dir) if f.startswith("phase_d_dat_smoke_report_")]
            self.assertTrue(found)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)
            try:
                os.remove(state_path)
            except Exception:
                pass

    def test_verdict_not_advanced_when_no_movement(self):
        sg = strict_gate_for_missing_shadow_report()
        from phase_d_milestone_gate import derive_strict_milestone_verdict

        v = derive_strict_milestone_verdict(sg, {})
        self.assertEqual(v, VERDICT_NOT_ADVANCED)

    def test_format_outputs_include_assessment_detail_when_present(self):
        report = {
            "anchor_run_id": "rid1",
            "phase_run_ids": {},
            "pipeline_ok": True,
            "assessment": "dat_discovered_not_ingested",
            "assessment_detail": "phase_c_ingest_explained_by_duplicates",
            "strict_milestone_verdict": VERDICT_NOT_ADVANCED,
            "dat_funnel": {},
            "strict_gate": {},
        }
        txt = format_smoke_txt(report)
        self.assertIn("assessment_detail: phase_c_ingest_explained_by_duplicates", txt)
        out = format_smoke_stdout_ladder(report, "report.json", "report.txt")
        self.assertIn("assessment_detail: phase_c_ingest_explained_by_duplicates", out)


if __name__ == "__main__":
    unittest.main()
