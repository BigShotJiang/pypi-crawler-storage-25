#!/usr/bin/env python
"""
Phase C ingest: manifest-to-ingest_artifact write pass.
Deterministic, idempotent INSERT OR IGNORE. XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import json
import os
import re
import sqlite3
import sys
import time
import traceback

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_a_common import refresh_run_cursor_updated_at
from phase_c_common import (
    INGEST_KEY_POLICY_VERSION,
    PHASE_C_DB_LOCK_RETRY_DELAYS_SEC,
    PHASE_C_DB_WRITE_ERROR,
    PHASE_C_FINISH_INCOHERENT,
    PHASE_C_INGEST_KEY_ERROR,
    PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
    PHASE_C_LOCK_FAIL,
    PHASE_C_MANIFEST_INVALID,
    PHASE_C_MANIFEST_MISSING,
    PHASE_C_STATE_WRITE_ERROR,
    PHASE_C_UNKNOWN_ARTIFACT_CLASS,
    XP_SOURCE_SYSTEM,
    artifact_class_to_source_type,
    compute_ingest_key_v1,
    iso_utc_now,
    phase_c_operator_hint_from_db_error_detail,
    phase_c_sqlite_lock_class_error,
    run_id,
)
from lab_lock import acquire_lock, read_lab_lock_diagnostic_metadata, release_lock, replace_safe_write
from lab_path_utils import resolve_lab_root
from lab_path_utils import get_medicafe_lab_dir_env


REQUIRED_FIELDS = (
    "artifact_class",
    "normalized_path",
    "size_bytes",
    "mtime_epoch",
    "sha256",
    "hash_mode",
    "source_id",
    "scope",
)

INGEST_FROM_MANIFEST_DIAG_SCHEMA_VERSION = 1
INGEST_BOOTSTRAP_DIAG_SCHEMA_VERSION = 1
INGEST_BOOTSTRAP_TIMELINE_SCHEMA_VERSION = 1
_INGEST_BOOTSTRAP_START_EPOCH = time.time()
_INGEST_BOOTSTRAP_STAGE_SEQ = 0


def _bounded_text(value, limit):
    return str(value or "")[:int(limit or 0)]


def _write_ingest_bootstrap_diagnostic(lab_root, stage, detail=None, rid=None, manifest_arg=None):
    """Write bootstrap diagnostics for pre/post-main stages."""
    global _INGEST_BOOTSTRAP_STAGE_SEQ
    if not lab_root:
        return
    reports_dir = os.path.join(lab_root, "reports")
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        return
    script_path = os.path.abspath(__file__)
    script_size = None
    try:
        script_size = os.path.getsize(script_path)
    except Exception:
        script_size = None
    _INGEST_BOOTSTRAP_STAGE_SEQ += 1
    elapsed_sec = 0.0
    try:
        elapsed_sec = round(time.time() - float(_INGEST_BOOTSTRAP_START_EPOCH), 4)
    except Exception:
        elapsed_sec = 0.0
    stage_s = _bounded_text(stage, 128)
    doc = {
        "schema_version": INGEST_BOOTSTRAP_DIAG_SCHEMA_VERSION,
        "generated_at_utc": iso_utc_now(),
        "stage": stage_s,
        "stage_seq": int(_INGEST_BOOTSTRAP_STAGE_SEQ),
        "elapsed_since_process_start_sec": elapsed_sec,
        "pid": int(os.getpid()),
        "rid": _bounded_text(rid, 128),
        "cwd": _bounded_text(os.getcwd(), 512),
        "sys_argv": [_bounded_text(v, 1024) for v in (list(sys.argv) if isinstance(sys.argv, list) else [])],
        "__name__": _bounded_text(__name__, 128),
        "sys_executable": _bounded_text(sys.executable, 512),
        "script_path": _bounded_text(script_path, 1024),
        "script_size_bytes": script_size,
        "medicafe_lab_dir_env": _bounded_text(get_medicafe_lab_dir_env(), 1024),
        "resolved_lab_root": _bounded_text(lab_root, 1024),
        "manifest_arg": _bounded_text(manifest_arg, 1024),
        "detail": _bounded_text(detail, 2048),
    }
    payload = json.dumps(doc, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    latest_path = os.path.join(reports_dir, "ingest_from_manifest_bootstrap_latest.json")
    pid_path = os.path.join(reports_dir, "ingest_from_manifest_bootstrap_{0}.json".format(os.getpid()))
    timeline_latest_path = os.path.join(reports_dir, "ingest_from_manifest_bootstrap_timeline_latest.jsonl")
    timeline_pid_path = os.path.join(reports_dir, "ingest_from_manifest_bootstrap_timeline_{0}.jsonl".format(os.getpid()))
    timeline_doc = {
        "schema_version": INGEST_BOOTSTRAP_TIMELINE_SCHEMA_VERSION,
        "generated_at_utc": doc["generated_at_utc"],
        "stage": stage_s,
        "stage_seq": int(_INGEST_BOOTSTRAP_STAGE_SEQ),
        "elapsed_since_process_start_sec": elapsed_sec,
        "pid": int(os.getpid()),
        "rid": doc.get("rid", ""),
        "manifest_arg": doc.get("manifest_arg", ""),
        "resolved_lab_root": doc.get("resolved_lab_root", ""),
        "detail": doc.get("detail", ""),
    }
    timeline_line = json.dumps(timeline_doc, ensure_ascii=True, sort_keys=True, separators=(",", ":")) + "\n"
    # Per-process bootstrap snapshot always; lab-scoped bootstrap_latest skips before_argparse so
    # MEDICAFE_LAB_DIR prelude cannot clobber the wrong lab when --lab-dir resolves elsewhere.
    bootstrap_snapshot_paths = [pid_path]
    if stage_s != "before_argparse":
        bootstrap_snapshot_paths.insert(0, latest_path)
    for path in bootstrap_snapshot_paths:
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as handle:
                handle.write(payload)
            try:
                if os.path.isfile(path):
                    os.remove(path)
            except Exception:
                pass
            os.rename(tmp, path)
        except Exception:
            try:
                if os.path.isfile(tmp):
                    os.remove(tmp)
            except Exception:
                pass
    # Per-process JSONL timeline (full trail, including before_argparse).
    try:
        if stage_s == "before_argparse" and os.path.isfile(timeline_pid_path):
            os.remove(timeline_pid_path)
    except Exception:
        pass
    try:
        with open(timeline_pid_path, "a", encoding="utf-8") as handle:
            handle.write(timeline_line)
    except Exception:
        pass
    # Lab-scoped timeline_latest: skip before_argparse so a MEDICAFE_LAB_DIR prelude
    # cannot truncate or append under the wrong lab when --lab-dir resolves elsewhere.
    if stage_s != "before_argparse":
        try:
            if stage_s == "after_argparse" and os.path.isfile(timeline_latest_path):
                os.remove(timeline_latest_path)
        except Exception:
            pass
        try:
            with open(timeline_latest_path, "a", encoding="utf-8") as handle:
                handle.write(timeline_line)
        except Exception:
            pass


def _write_ingest_from_manifest_diagnostics(lab_root, ok, rid, summary, error_code):
    """
    Always write reports/ingest_from_manifest_diagnostics_<rid>.json and
    reports/ingest_from_manifest_diagnostics_latest.json for bundle attachment
    and RCCA (db_error_detail, lock hints, row counts) even when stderr is empty.
    """
    reports_dir = os.path.join(lab_root, "reports")
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        return
    doc = {
        "schema_version": INGEST_FROM_MANIFEST_DIAG_SCHEMA_VERSION,
        "generated_at_utc": iso_utc_now(),
        "script": "ingest_from_manifest.py",
        "run_id": rid,
        "exit_ok": bool(ok),
        "error_code": error_code or "",
        "python_version": sys.version.split()[0] if sys.version else "",
        "manifest_path": "",
        "manifest_sha256": "",
        "manifest_rows_read": 0,
        "rows_inserted": 0,
        "rows_failed": 0,
        "rows_skipped_duplicate": 0,
        "summary_ok": None,
        "summary_schema_version": None,
        "db_error_class": "",
        "db_error_detail": "",
        "operator_hint": "",
        "db_lock_retry_count": 0,
        "db_lock_retry_elapsed_sec": 0.0,
        "lock_path": "",
        "lock_pid": "",
        "lock_heartbeat_at_utc": "",
        "summary_error_code": "",
        "summary_error_detail": "",
        "post_commit_exception_class": "",
        "post_commit_exception_message": "",
        "post_commit_report_target_state": {},
    }
    if isinstance(summary, dict):
        doc["manifest_path"] = str(summary.get("manifest_path") or "")
        doc["manifest_sha256"] = str(summary.get("manifest_sha256") or "")
        doc["manifest_rows_read"] = int(summary.get("manifest_rows_read") or 0)
        doc["rows_inserted"] = int(summary.get("rows_inserted") or 0)
        doc["rows_failed"] = int(summary.get("rows_failed") or 0)
        doc["rows_skipped_duplicate"] = int(summary.get("rows_skipped_duplicate") or 0)
        doc["summary_ok"] = summary.get("ok")
        doc["summary_schema_version"] = summary.get("summary_schema_version")
        doc["db_error_class"] = str(summary.get("db_error_class") or "")
        det = str(summary.get("db_error_detail") or "")
        doc["db_error_detail"] = det[:2048]
        doc["operator_hint"] = str(summary.get("operator_hint") or "")
        doc["db_lock_retry_count"] = int(summary.get("db_lock_retry_count") or 0)
        doc["db_lock_retry_elapsed_sec"] = float(summary.get("db_lock_retry_elapsed_sec") or 0.0)
        doc["lock_path"] = str(summary.get("lock_path") or "")
        doc["lock_pid"] = str(summary.get("lock_pid") or "")
        doc["lock_heartbeat_at_utc"] = str(summary.get("lock_heartbeat_at_utc") or "")
        doc["summary_error_code"] = str(summary.get("error_code") or "")
        ed = str(summary.get("error_detail") or "")
        doc["summary_error_detail"] = ed[:512]
        doc["post_commit_exception_class"] = str(summary.get("post_commit_exception_class") or "")
        doc["post_commit_exception_message"] = str(summary.get("post_commit_exception_message") or "")[:512]
        target_state = summary.get("post_commit_report_target_state")
        if isinstance(target_state, dict):
            doc["post_commit_report_target_state"] = dict(target_state)
    payload = json.dumps(doc, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(rid or "unknown"))
    path_rid = os.path.join(reports_dir, "ingest_from_manifest_diagnostics_{0}.json".format(safe_rid))
    path_latest = os.path.join(reports_dir, "ingest_from_manifest_diagnostics_latest.json")
    for path in (path_rid, path_latest):
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as handle:
                handle.write(payload)
            try:
                if os.path.isfile(path):
                    os.remove(path)
            except Exception:
                pass
            os.rename(tmp, path)
        except Exception:
            try:
                if os.path.isfile(tmp):
                    os.remove(tmp)
            except Exception:
                pass
    if os.path.isfile(path_latest):
        _stamp_ingest_from_manifest_diag_pointers(lab_root, path_latest, doc.get("generated_at_utc") or "", rid)


def _stamp_ingest_from_manifest_diag_pointers(lab_root, path_latest, generated_at_utc, rid):
    """Stamp diagnostics_state.json and run_cursor.json with last ingest diagnostics pointers."""
    path_latest = str(path_latest or "").strip()
    generated_at_utc = str(generated_at_utc or "").strip()
    rid_s = str(rid or "").strip()
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    for path in (state_path, cursor_path):
        doc = {}
        loaded_ok = not os.path.isfile(path)
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                if isinstance(raw, dict):
                    doc = raw
                    loaded_ok = True
            except Exception:
                loaded_ok = False
        if not loaded_ok:
            # Never replace an existing state/cursor file we could not parse as a dict;
            # doing so would wipe Phase B/C/D lineage (same guard as execution-handoff stamp).
            continue
        doc["last_ingest_from_manifest_diag_path"] = path_latest
        doc["last_ingest_from_manifest_diag_at_utc"] = generated_at_utc
        doc["last_ingest_from_manifest_diag_run_id"] = rid_s
        try:
            replace_safe_write(path, doc)
        except Exception:
            pass


def _finish_run_ingest(lab_root, ok, rid, summary, error_code):
    _write_ingest_from_manifest_diagnostics(lab_root, ok, rid, summary, error_code)
    return ok, rid, summary, error_code


def _ingest_finish_diagnostics_paths(lab_root, rid):
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(rid or "unknown"))
    reports_dir = os.path.join(lab_root, "reports")
    diag_latest = os.path.join(reports_dir, "ingest_from_manifest_diagnostics_latest.json")
    diag_run = os.path.join(reports_dir, "ingest_from_manifest_diagnostics_{0}.json".format(safe_rid))
    return diag_latest, diag_run


def _ingest_finish_diagnostics_present(lab_root, rid):
    dl, dr = _ingest_finish_diagnostics_paths(lab_root, rid)
    return os.path.isfile(dl) and os.path.isfile(dr)


def _revert_persisted_success_after_outer_failure(lab_root, rid, summary_snapshot):
    """
    run_ingest() may catch an exception after persist_phase_c_state recorded ok=True.
    Downgrade diagnostics_state/run_cursor so operators and shadow handoff do not see
    last_phase_c_ok=True while the ingest subprocess reports PHASE_C_FINISH_INCOHERENT.
    """
    if not isinstance(summary_snapshot, dict):
        return
    try:
        persist_phase_c_state(
            lab_root,
            rid,
            False,
            PHASE_C_FINISH_INCOHERENT,
            summary_snapshot.get("manifest_path"),
            summary_snapshot.get("manifest_sha256"),
            int(summary_snapshot.get("rows_inserted") or 0),
            int(summary_snapshot.get("rows_failed") or 0),
            bool(summary_snapshot.get("has_row_anomalies")),
            int(summary_snapshot.get("anomaly_count") or 0),
            rows_skipped_duplicate=int(summary_snapshot.get("rows_skipped_duplicate") or 0),
            rows_inserted_by_class=summary_snapshot.get("rows_inserted_by_class") or {},
            rows_skipped_duplicate_by_class=summary_snapshot.get("rows_skipped_duplicate_by_class") or {},
            phase_c_duplicate_dominant=bool(summary_snapshot.get("phase_c_duplicate_dominant")),
            phase_c_duplicate_only=bool(summary_snapshot.get("phase_c_duplicate_only")),
        )
    except Exception:
        pass


def _minimal_summary_finish_incoherent(rid, manifest_path, manifest_sha256, detail):
    out = {
        "phase": "phase_c",
        "ok": False,
        "run_id": rid,
        "generated_at_utc": iso_utc_now(),
        "manifest_path": manifest_path or "",
        "manifest_run_id": "",
        "manifest_sha256": manifest_sha256 or "",
        "config_hash": "",
        "crosswalk_hash": "",
        "ingest_key_policy_version": INGEST_KEY_POLICY_VERSION,
        "manifest_rows_read": 0,
        "rows_inserted": 0,
        "rows_updated": 0,
        "rows_skipped_duplicate": 0,
        "rows_failed": 0,
        "has_row_anomalies": False,
        "anomaly_count": 0,
        "counts_by_class": {},
        "rows_inserted_by_class": {},
        "rows_skipped_duplicate_by_class": {},
        "phase_c_duplicate_dominant": False,
        "phase_c_duplicate_only": False,
        "error_code": PHASE_C_FINISH_INCOHERENT,
        "error_detail": _bounded_text(detail, 500),
    }
    normalize_phase_c_ingest_summary(out)
    return out


def _build_phase_c_lock_fail_summary(rid, manifest_path, manifest_run_id, lineage, manifest_rows_read, counts_by_class, anomalies, detail_txt, lock_meta):
    summary_lock = {
        "phase": "phase_c",
        "ok": False,
        "run_id": rid,
        "generated_at_utc": iso_utc_now(),
        "manifest_path": manifest_path or "",
        "manifest_run_id": manifest_run_id or "",
        "manifest_sha256": (lineage or {}).get("manifest_sha256", ""),
        "config_hash": (lineage or {}).get("config_hash", ""),
        "crosswalk_hash": (lineage or {}).get("crosswalk_hash", ""),
        "ingest_key_policy_version": INGEST_KEY_POLICY_VERSION,
        "manifest_rows_read": int(manifest_rows_read or 0),
        "rows_inserted": 0,
        "rows_updated": 0,
        "rows_skipped_duplicate": 0,
        "rows_failed": 0,
        "has_row_anomalies": len(anomalies or []) > 0,
        "anomaly_count": len(anomalies or []),
        "counts_by_class": counts_by_class if isinstance(counts_by_class, dict) else {},
        "rows_inserted_by_class": {},
        "rows_skipped_duplicate_by_class": {},
        "phase_c_duplicate_dominant": False,
        "phase_c_duplicate_only": False,
        "error_code": PHASE_C_LOCK_FAIL,
        "db_error_class": "SystemExit",
        "db_error_detail": str(detail_txt or ""),
        "db_lock_retry_count": 0,
        "db_lock_retry_elapsed_sec": 0.0,
    }
    _merge_lock_meta_into_summary(summary_lock, lock_meta if isinstance(lock_meta, dict) else {})
    normalize_phase_c_ingest_summary(summary_lock)
    return summary_lock


def _coherence_finish_parts(lab_root, rid, summary):
    parts = []
    if not isinstance(summary, dict):
        return ["summary_missing_or_invalid"]
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(rid or "unknown"))
    expected_json = os.path.join(lab_root, "reports", "ingest_write_summary_{0}.json".format(rid))
    diag_latest_path = os.path.join(lab_root, "reports", "ingest_from_manifest_diagnostics_latest.json")
    diag_run_path = os.path.join(
        lab_root, "reports", "ingest_from_manifest_diagnostics_{0}.json".format(safe_rid)
    )
    if str(summary.get("run_id") or "").strip() != str(rid or "").strip():
        parts.append("summary.run_id != rid")
    if not os.path.isfile(expected_json):
        parts.append("ingest_write_summary_{0}.json missing".format(rid))
    if summary.get("summary_schema_version") != PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION:
        parts.append("summary_schema_version mismatch")
    if not str(summary.get("manifest_sha256") or "").strip():
        parts.append("manifest_sha256 empty")
    if summary.get("error_code"):
        parts.append("summary error_code set ({0})".format(summary.get("error_code")))
    if not os.path.isfile(diag_latest_path):
        parts.append("ingest_from_manifest_diagnostics_latest.json missing")
    if not os.path.isfile(diag_run_path):
        parts.append("ingest_from_manifest_diagnostics_{0}.json missing".format(safe_rid))
    coherent, reason = verify_phase_c_lab_reflects_persist(lab_root, rid, summary)
    if not coherent:
        parts.append(str(reason or "lab_state_verify_failed"))
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    for label, path in (("run_cursor", cursor_path), ("diagnostics_state", state_path)):
        try:
            with open(path, "r", encoding="utf-8") as f:
                doc = json.load(f)
        except Exception:
            parts.append("{0}_diag_pointer_unreadable".format(label))
            continue
        if str(doc.get("last_ingest_from_manifest_diag_run_id") or "").strip() != str(rid or "").strip():
            parts.append("{0}_diag_run_id_mismatch".format(label))
    return parts


def _coerce_success_to_finish_incoherent(lab_root, rid, summary, summary_json, summary_txt):
    parts = _coherence_finish_parts(lab_root, rid, summary)
    if not parts:
        return True, summary, None
    if isinstance(summary, dict):
        manifest_path = summary.get("manifest_path")
        manifest_sha256 = summary.get("manifest_sha256")
        summary["ok"] = False
        summary["error_code"] = PHASE_C_FINISH_INCOHERENT
        summary["error_detail"] = "; ".join(parts)[:500]
        _write_phase_c_canonical_reports(summary, summary_json, summary_txt)
        # Prevent split-brain state where successful persist remains visible after
        # finish-incoherent coercion. Preserve lineage fields while downgrading outcome.
        _persist_phase_c_state_or_mark_summary_state_error(
            summary,
            summary_json,
            summary_txt,
            lambda: persist_phase_c_state(
                lab_root,
                rid,
                False,
                PHASE_C_FINISH_INCOHERENT,
                manifest_path,
                manifest_sha256,
                int(summary.get("rows_inserted") or 0),
                int(summary.get("rows_failed") or 0),
                bool(summary.get("has_row_anomalies")),
                int(summary.get("anomaly_count") or 0),
                rows_skipped_duplicate=int(summary.get("rows_skipped_duplicate") or 0),
                rows_inserted_by_class=summary.get("rows_inserted_by_class") or {},
                rows_skipped_duplicate_by_class=summary.get("rows_skipped_duplicate_by_class") or {},
                phase_c_duplicate_dominant=bool(summary.get("phase_c_duplicate_dominant")),
                phase_c_duplicate_only=bool(summary.get("phase_c_duplicate_only")),
            ),
        )
        if summary.get("error_code") == PHASE_C_STATE_WRITE_ERROR:
            return False, summary, PHASE_C_STATE_WRITE_ERROR
        summary["ok"] = False
        summary["error_code"] = PHASE_C_FINISH_INCOHERENT
        if manifest_path is not None:
            summary["manifest_path"] = manifest_path
        if manifest_sha256 is not None:
            summary["manifest_sha256"] = manifest_sha256
        _write_phase_c_canonical_reports(summary, summary_json, summary_txt)
    return False, summary, PHASE_C_FINISH_INCOHERENT


def verify_phase_c_lab_reflects_persist(lab_root, rid, summary):
    """
    Confirm diagnostics_state.json and run_cursor.json reflect this ingest after persist_phase_c_state.
    Guards exit 0 when state was written to a different lab root or was overwritten externally.
    Returns (True, None) or (False, short_reason).
    """
    if not isinstance(summary, dict):
        return False, "missing_summary_dict"
    exp_rid = str(rid or "").strip()
    if not exp_rid:
        return False, "empty_run_id"
    exp_sha = str(summary.get("manifest_sha256") or "").strip()
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    if not os.path.isfile(cursor_path) or not os.path.isfile(state_path):
        return False, "cursor_or_state_missing"
    try:
        with open(cursor_path, "r", encoding="utf-8") as f:
            cursor = json.load(f)
        with open(state_path, "r", encoding="utf-8") as f:
            state = json.load(f)
    except Exception as exc:
        return False, "cursor_or_state_unreadable:{0}".format(exc.__class__.__name__)
    for label, doc in (("run_cursor", cursor), ("diagnostics_state", state)):
        got_rid = str(doc.get("last_phase_c_run_id", "") or "").strip()
        if got_rid != exp_rid:
            return False, "{0}_run_id_mismatch got={1} expected={2}".format(label, got_rid, exp_rid)
        if doc.get("last_phase_c_ok") is not True:
            return False, "{0}_last_phase_c_ok_not_true".format(label)
    if exp_sha:
        for label, doc in (("run_cursor", cursor), ("diagnostics_state", state)):
            got_sha = str(doc.get("last_ingest_manifest_sha256", "") or "").strip()
            if got_sha != exp_sha:
                return False, "{0}_manifest_sha_mismatch got={1} expected={2}".format(
                    label, got_sha[:16] if got_sha else "", exp_sha[:16]
                )
    return True, None


def _workspace_root():
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))


def _resolve_lab_root(args):
    return resolve_lab_root(args.lab_dir, _workspace_root())


def resolve_manifest_path(lab_root, manifest_arg):
    """Resolve manifest path: --manifest > pending manifest on cursor > last_manifest_path > latest by mtime."""
    if manifest_arg and os.path.exists(manifest_arg):
        return manifest_arg
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
            pend = cursor.get("last_discovery_pending_manifest_path")
            if pend and os.path.isfile(pend):
                return pend
            path = cursor.get("last_manifest_path")
            if path and os.path.exists(path):
                return path
        except Exception:
            pass
    reports_dir = os.path.join(lab_root, "reports")
    if not os.path.isdir(reports_dir):
        return None
    manifests = []
    for name in os.listdir(reports_dir):
        if name.startswith("artifact_manifest_") and name.endswith(".jsonl"):
            manifests.append(os.path.join(reports_dir, name))
    if not manifests:
        return None
    return max(manifests, key=os.path.getmtime)


def extract_manifest_run_id(manifest_path):
    """Parse artifact_manifest_<run_id>.jsonl; return run_id or None."""
    if not manifest_path:
        return None
    name = os.path.basename(manifest_path)
    match = re.match(r"artifact_manifest_([^.]+)\.jsonl", name)
    return match.group(1) if match else None


def read_manifest_rows(manifest_path):
    """Yield (row_dict, line_num). Malformed line yields (None, line_num)."""
    if not manifest_path or not os.path.exists(manifest_path):
        return
    with open(manifest_path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
                if isinstance(row, dict) and row.get("record_type") == "phase_b_discovery_scope_policy":
                    continue
                yield (row, line_num)
            except (ValueError, TypeError):
                yield (None, line_num)


def load_phase_b_summary_lineage(lab_root, manifest_run_id):
    """Load Phase B summary lineage. Returns dict with empty values if missing."""
    result = {
        "manifest_sha256": "",
        "config_hash": "",
        "crosswalk_hash": "",
        "counts_by_class": {},
    }
    if not manifest_run_id:
        return result
    path = os.path.join(lab_root, "reports", "artifact_discovery_summary_{0}.json".format(manifest_run_id))
    if not os.path.exists(path):
        try:
            import logging
            logging.getLogger(__name__).warning("Phase B summary missing: {0}".format(path))
        except Exception:
            pass
        return result
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        result["manifest_sha256"] = data.get("manifest_sha256", "") or ""
        result["config_hash"] = data.get("config_hash", "") or ""
        result["crosswalk_hash"] = data.get("crosswalk_hash", "") or ""
        result["counts_by_class"] = data.get("counts_by_class", {}) or {}
    except Exception:
        pass
    return result


def validate_manifest_row(row, line_num):
    """Return (True, None) if valid; (False, anomaly_dict) if invalid."""
    if row is None:
        return (False, {"line_num": line_num, "error_code": "malformed_json", "message": "Malformed JSON line", "row_snippet": None})
    for k in REQUIRED_FIELDS:
        if k not in row:
            return (False, {"line_num": line_num, "error_code": "missing_field", "message": "Missing required: {0}".format(k), "row_snippet": dict(row)})
    try:
        mtime = row.get("mtime_epoch")
        size = row.get("size_bytes")
        if mtime is None or (not isinstance(mtime, (int, float)) and not str(mtime).strip()):
            return (False, {"line_num": line_num, "error_code": "invalid_type", "message": "mtime_epoch invalid", "row_snippet": dict(row)})
        if size is None or (not isinstance(size, (int, float)) and not str(size).strip()):
            return (False, {"line_num": line_num, "error_code": "invalid_type", "message": "size_bytes invalid", "row_snippet": dict(row)})
    except Exception:
        return (False, {"line_num": line_num, "error_code": "invalid_type", "message": "mtime_epoch/size_bytes invalid", "row_snippet": dict(row)})
    return (True, None)


def manifest_row_to_ingest_row(row, lineage):
    """Build ingest row from manifest row. Returns None if invalid (unknown class or key error)."""
    source_type = artifact_class_to_source_type(row.get("artifact_class"))
    if source_type is None:
        return None
    try:
        ingest_key = compute_ingest_key_v1(row)
    except ValueError:
        return None
    source_id = str(row.get("source_id", ""))
    normalized_path = str(row.get("normalized_path", ""))
    source_ref = source_id + chr(124) + normalized_path
    attachment_name = os.path.basename(normalized_path) if normalized_path else ""
    payload = {
        "phase_b_manifest_run_id": lineage.get("manifest_run_id", ""),
        "phase_b_manifest_sha256": lineage.get("manifest_sha256", ""),
        "config_hash": lineage.get("config_hash", ""),
        "crosswalk_hash": lineage.get("crosswalk_hash", ""),
        "artifact_class": row.get("artifact_class"),
        "normalized_path": normalized_path,
        "mtime_epoch": row.get("mtime_epoch"),
        "size_bytes": row.get("size_bytes"),
        "hash_mode": row.get("hash_mode"),
        "scope": row.get("scope"),
        "locator": row.get("locator", ""),
        "warnings": row.get("warnings", []),
    }
    ac = str(row.get("artifact_class", "unknown") or "unknown")
    return {
        "ingest_key": ingest_key,
        "source_system": XP_SOURCE_SYSTEM,
        "source_type": source_type,
        "source_ref": source_ref,
        "message_id": None,
        "attachment_name": attachment_name,
        "attachment_sha256": str(row.get("sha256", "")),
        "payload_json": json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
        "ingest_status": "ingested",
        "artifact_class": ac,
    }


def _verify_schema(conn):
    """Verify ingest_artifact exists with required columns."""
    cur = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='ingest_artifact'"
    )
    if not cur.fetchone():
        return False
    cur = conn.execute("PRAGMA table_info(ingest_artifact)")
    cols = {row[1] for row in cur.fetchall()}
    required = {"ingest_key", "source_system", "source_type", "source_ref", "payload_json", "ingest_status"}
    return required.issubset(cols)


def write_ingest_rows(conn, ingest_rows, mark=None):
    """INSERT OR IGNORE each row. Return (rows_inserted, rows_skipped_duplicate, rows_failed, inserted_by_class, skipped_by_class)."""
    if mark:
        mark("ingest_schema_verify_begin")
    if not _verify_schema(conn):
        raise RuntimeError("ingest_artifact table missing or invalid schema")
    if mark:
        mark("ingest_schema_verify_end")
    inserted = 0
    skipped = 0
    failed = 0
    inserted_by_class = {}
    skipped_by_class = {}
    stmt = (
        "INSERT OR IGNORE INTO ingest_artifact "
        "(ingest_key, source_system, source_type, source_ref, message_id, attachment_name, "
        "attachment_sha256, payload_json, ingest_status) VALUES (?,?,?,?,?,?,?,?,?)"
    )
    if mark:
        mark("ingest_rows_write_begin", detail="count={0}".format(len(ingest_rows)))
    for idx, r in enumerate(ingest_rows):
        ac = str(r.get("artifact_class", "unknown") or "unknown")
        try:
            if mark and idx == 0:
                mark("ingest_first_row_execute_begin", detail="artifact_class={0}".format(ac[:64]))
            cur = conn.execute(stmt, (
                r["ingest_key"],
                r["source_system"],
                r["source_type"],
                r["source_ref"],
                r["message_id"],
                r["attachment_name"],
                r["attachment_sha256"],
                r["payload_json"],
                r["ingest_status"],
            ))
            if cur.rowcount > 0:
                inserted += 1
                inserted_by_class[ac] = inserted_by_class.get(ac, 0) + 1
                if mark and idx == 0:
                    mark("ingest_first_row_execute_end", detail="inserted=1")
            else:
                skipped += 1
                skipped_by_class[ac] = skipped_by_class.get(ac, 0) + 1
                if mark and idx == 0:
                    mark("ingest_first_row_execute_end", detail="inserted=0")
        except Exception:
            failed += 1
            # SQLite leaves the transaction usable after a caught statement error; continuing
            # would allow COMMIT to persist a partial batch. Abort the whole ingest pass.
            try:
                conn.rollback()
            except Exception:
                pass
            # Row-level DB write failures must abort the transaction; callers handle rollback/error mapping.
            raise
    if mark:
        mark("ingest_rows_write_end", detail="inserted={0};skipped={1};failed={2}".format(inserted, skipped, failed))
    return (inserted, skipped, failed, inserted_by_class, skipped_by_class)


def _execute_phase_c_ingest_transaction(db_path, ingest_rows, lab_root, mark=None):
    """
    Bounded retry around BEGIN..COMMIT ingest writes for lock/busy class errors only.
    Returns (ok, last_exception, rows_inserted, rows_skipped, rows_failed, ins_by_c, skip_by_c,
             lock_retry_count, lock_retry_elapsed_sec, lock_meta_dict).
    """
    lock_retries = 0
    started = time.time()
    last_exc = None
    delays = PHASE_C_DB_LOCK_RETRY_DELAYS_SEC
    for attempt in range(len(delays) + 1):
        conn = None
        try:
            conn = sqlite3.connect(db_path, timeout=30.0)
            try:
                conn.execute("PRAGMA busy_timeout=30000")
            except Exception:
                pass
            if mark:
                mark("sqlite_begin_execute_begin")
            conn.execute("BEGIN")
            if mark:
                mark("sqlite_begin_execute_end")
            rows_inserted, rows_skipped, rows_failed, ins_by_c, skip_by_c = write_ingest_rows(conn, ingest_rows, mark=mark)
            if mark:
                mark("sqlite_commit_begin")
            conn.commit()
            if mark:
                mark("sqlite_commit_end")
            elapsed = round(time.time() - started, 3)
            return (
                True,
                None,
                rows_inserted,
                rows_skipped,
                rows_failed,
                ins_by_c,
                skip_by_c,
                lock_retries,
                elapsed,
                read_lab_lock_diagnostic_metadata(lab_root),
            )
        except Exception as e:
            last_exc = e
            try:
                if conn:
                    conn.rollback()
            except Exception:
                pass
            retryable = attempt < len(delays) and phase_c_sqlite_lock_class_error(e)
            if retryable:
                lock_retries += 1
                time.sleep(float(delays[attempt]))
            else:
                break
        except BaseException as e:
            if isinstance(e, KeyboardInterrupt):
                raise
            last_exc = e
            try:
                if conn:
                    conn.rollback()
            except Exception:
                pass
            if mark:
                mark(
                    "ingest_transaction_base_exception",
                    detail="{0}:{1}".format(e.__class__.__name__, _bounded_text(str(e), 256)),
                )
            break
        finally:
            try:
                if conn:
                    conn.close()
            except Exception:
                pass
    elapsed = round(time.time() - started, 3)
    return (
        False,
        last_exc,
        0,
        0,
        len(ingest_rows),
        {},
        {},
        lock_retries,
        elapsed,
        read_lab_lock_diagnostic_metadata(lab_root),
    )


def _phase_c_duplicate_flags(rows_inserted, rows_skipped, ingest_row_count):
    """Duplicate-dominant: skipped >= max(1, inserted). Duplicate-only: no new inserts, skips > 0, had rows to write."""
    dup_dom = rows_skipped >= max(1, rows_inserted)
    dup_only = rows_inserted == 0 and rows_skipped > 0 and ingest_row_count > 0
    return dup_dom, dup_only


def _write_summary_json(summary, path):
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)


def _phase_c_report_target_state(reports_dir, summary_json, summary_txt, anomalies_path):
    """Small pre-summary snapshot for diagnosing post-commit publish gaps."""
    out = {
        "reports_dir": reports_dir or "",
        "reports_dir_exists": False,
        "reports_dir_is_dir": False,
        "summary_json_path": summary_json or "",
        "summary_json_exists": False,
        "summary_txt_path": summary_txt or "",
        "summary_txt_exists": False,
        "anomalies_path": anomalies_path or "",
        "anomalies_exists": False,
    }
    try:
        out["reports_dir_exists"] = bool(reports_dir and os.path.exists(reports_dir))
        out["reports_dir_is_dir"] = bool(reports_dir and os.path.isdir(reports_dir))
    except Exception as exc:
        out["reports_dir_probe_error_class"] = exc.__class__.__name__
        out["reports_dir_probe_error_detail"] = _bounded_text(str(exc), 200)
    for key, path in (
            ("summary_json", summary_json),
            ("summary_txt", summary_txt),
            ("anomalies", anomalies_path)):
        try:
            out["{0}_exists".format(key)] = bool(path and os.path.exists(path))
        except Exception as exc:
            out["{0}_probe_error_class".format(key)] = exc.__class__.__name__
            out["{0}_probe_error_detail".format(key)] = _bounded_text(str(exc), 200)
    return out


def _format_phase_c_report_target_state_for_detail(state):
    if not isinstance(state, dict):
        return ""
    bits = []
    for key in (
            "reports_dir",
            "reports_dir_exists",
            "reports_dir_is_dir",
            "summary_json_path",
            "summary_json_exists",
            "summary_txt_path",
            "summary_txt_exists",
            "anomalies_path",
            "anomalies_exists"):
        bits.append("{0}={1}".format(key, state.get(key, "")))
    return _bounded_text(";".join(bits), 1000)


def normalize_phase_c_ingest_summary(summary):
    """Ensure canonical ingest_write_summary fields (versioned schema for consumers)."""
    if not isinstance(summary, dict):
        return summary
    summary["summary_schema_version"] = PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION
    summary.setdefault("db_error_class", "")
    summary.setdefault("db_error_detail", "")
    summary.setdefault("db_lock_retry_count", 0)
    summary.setdefault("db_lock_retry_elapsed_sec", 0)
    for k in ("lock_path", "lock_pid", "lock_heartbeat_at_utc"):
        summary.setdefault(k, "")
    detail = summary.get("db_error_detail", "") or ""
    summary["operator_hint"] = phase_c_operator_hint_from_db_error_detail(detail)
    return summary


def _merge_lock_meta_into_summary(summary, lock_meta):
    """Attach lab lock diagnostic metadata to summary when present."""
    if not isinstance(summary, dict):
        return
    if not isinstance(lock_meta, dict):
        summary.setdefault("lock_path", "")
        summary.setdefault("lock_pid", "")
        summary.setdefault("lock_heartbeat_at_utc", "")
        return
    summary["lock_path"] = lock_meta.get("lock_path", "") or ""
    summary["lock_pid"] = lock_meta.get("lock_pid", "") or ""
    summary["lock_heartbeat_at_utc"] = lock_meta.get("lock_heartbeat_at_utc", "") or ""
    owner_run = lock_meta.get("lock_owner_running")
    if owner_run is not None:
        summary["lock_owner_running"] = bool(owner_run)


def _write_phase_c_canonical_reports(summary, summary_json, summary_txt, anomalies_path=None, anomalies=None):
    """Normalize, write JSON+TXT, optional anomalies JSONL."""
    normalize_phase_c_ingest_summary(summary)
    if summary_json:
        _write_summary_json(summary, summary_json)
    if summary_txt:
        _write_summary_txt(summary, summary_txt)
    if anomalies_path and anomalies:
        with open(anomalies_path, "w", encoding="utf-8") as f:
            for a in anomalies:
                f.write(json.dumps(a, ensure_ascii=False) + "\n")


def _persist_phase_c_state_or_mark_summary_state_error(summary, summary_json, summary_txt, persist_fn):
    """
    Run persist_fn (typically persist_phase_c_state). On failure, mark summary STATE_WRITE_ERROR and rewrite reports.
    Returns True if persist succeeded.
    """
    try:
        persist_fn()
        return True
    except Exception as persist_err:
        summary["ok"] = False
        summary["error_code"] = PHASE_C_STATE_WRITE_ERROR
        summary["error_detail"] = str(persist_err)[:200]
        _write_phase_c_canonical_reports(summary, summary_json, summary_txt)
        return False


def _write_summary_txt(summary, path):
    lines = [
        "Phase C Ingest Write Summary",
        "summary_schema_version: {0}".format(summary.get("summary_schema_version", "")),
        "run_id: {0}".format(summary.get("run_id", "")),
        "generated_at_utc: {0}".format(summary.get("generated_at_utc", "")),
        "ok: {0}".format(summary.get("ok", False)),
        "manifest_path: {0}".format(summary.get("manifest_path", "")),
        "manifest_run_id: {0}".format(summary.get("manifest_run_id", "")),
        "manifest_rows_read: {0}".format(summary.get("manifest_rows_read", 0)),
        "rows_inserted: {0}".format(summary.get("rows_inserted", 0)),
        "rows_skipped_duplicate: {0}".format(summary.get("rows_skipped_duplicate", 0)),
        "rows_failed: {0}".format(summary.get("rows_failed", 0)),
        "has_row_anomalies: {0}".format(summary.get("has_row_anomalies", False)),
        "anomaly_count: {0}".format(summary.get("anomaly_count", 0)),
        "error_code: {0}".format(summary.get("error_code", "")),
        "rows_inserted_by_class: {0}".format(json.dumps(summary.get("rows_inserted_by_class") or {}, sort_keys=True)),
        "rows_skipped_duplicate_by_class: {0}".format(json.dumps(summary.get("rows_skipped_duplicate_by_class") or {}, sort_keys=True)),
        "phase_c_duplicate_dominant: {0}".format(summary.get("phase_c_duplicate_dominant", False)),
        "phase_c_duplicate_only: {0}".format(summary.get("phase_c_duplicate_only", False)),
    ]
    if summary.get("operator_hint"):
        lines.append("operator_hint: {0}".format(summary.get("operator_hint", "")))
    if summary.get("db_error_class") or summary.get("db_error_detail"):
        lines.append("db_error_class: {0}".format(summary.get("db_error_class", "") or ""))
        lines.append("db_error_detail: {0}".format(summary.get("db_error_detail", "") or ""))
    if "db_lock_retry_count" in summary:
        lines.append("db_lock_retry_count: {0}".format(summary.get("db_lock_retry_count", 0)))
    if "db_lock_retry_elapsed_sec" in summary:
        lines.append("db_lock_retry_elapsed_sec: {0}".format(summary.get("db_lock_retry_elapsed_sec", 0)))
    if summary.get("lock_path"):
        lines.append("lock_path: {0}".format(summary.get("lock_path", "")))
    if summary.get("lock_pid"):
        lines.append("lock_pid: {0}".format(summary.get("lock_pid", "")))
    if summary.get("lock_heartbeat_at_utc"):
        lines.append("lock_heartbeat_at_utc: {0}".format(summary.get("lock_heartbeat_at_utc", "")))
    if "lock_owner_running" in summary:
        lines.append("lock_owner_running: {0}".format(summary.get("lock_owner_running")))
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def persist_phase_c_state(lab_root, rid, ok, error_code, manifest_path, manifest_sha256,
                          rows_inserted, rows_failed, has_row_anomalies, anomaly_count,
                          rows_skipped_duplicate=0, rows_inserted_by_class=None,
                          rows_skipped_duplicate_by_class=None, phase_c_duplicate_dominant=False,
                          phase_c_duplicate_only=False):
    """Update run_cursor.json and diagnostics_state.json with Phase C outcome."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    now = iso_utc_now()
    cursor = {}
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    cursor["last_phase_c_run_id"] = rid
    cursor["last_phase_c_ok"] = ok
    cursor["last_ingest_manifest_path"] = manifest_path
    cursor["last_ingest_manifest_sha256"] = manifest_sha256
    cursor["last_ingest_key_policy_version"] = INGEST_KEY_POLICY_VERSION
    cursor["last_ingest_rows_inserted"] = rows_inserted
    cursor["last_ingest_rows_skipped_duplicate"] = rows_skipped_duplicate
    cursor["last_ingest_rows_inserted_by_class"] = rows_inserted_by_class if isinstance(rows_inserted_by_class, dict) else {}
    cursor["last_ingest_rows_skipped_duplicate_by_class"] = rows_skipped_duplicate_by_class if isinstance(rows_skipped_duplicate_by_class, dict) else {}
    cursor["last_phase_c_duplicate_dominant"] = bool(phase_c_duplicate_dominant)
    cursor["last_phase_c_duplicate_only"] = bool(phase_c_duplicate_only)
    cursor["last_ingest_rows_failed"] = rows_failed
    cursor["last_phase_c_has_row_anomalies"] = has_row_anomalies
    cursor["last_phase_c_anomaly_count"] = anomaly_count
    cursor["last_phase_c_error_code"] = error_code
    cursor["last_phase_c_at_utc"] = now
    refresh_run_cursor_updated_at(cursor)
    replace_safe_write(cursor_path, cursor)
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_phase_c_run_id"] = rid
    state["last_phase_c_ok"] = ok
    state["last_ingest_manifest_path"] = manifest_path
    state["last_ingest_manifest_sha256"] = manifest_sha256
    state["last_ingest_key_policy_version"] = INGEST_KEY_POLICY_VERSION
    state["last_ingest_rows_inserted"] = rows_inserted
    state["last_ingest_rows_skipped_duplicate"] = rows_skipped_duplicate
    state["last_ingest_rows_inserted_by_class"] = rows_inserted_by_class if isinstance(rows_inserted_by_class, dict) else {}
    state["last_ingest_rows_skipped_duplicate_by_class"] = rows_skipped_duplicate_by_class if isinstance(rows_skipped_duplicate_by_class, dict) else {}
    state["last_phase_c_duplicate_dominant"] = bool(phase_c_duplicate_dominant)
    state["last_phase_c_duplicate_only"] = bool(phase_c_duplicate_only)
    state["last_ingest_rows_failed"] = rows_failed
    state["last_phase_c_has_row_anomalies"] = has_row_anomalies
    state["last_phase_c_anomaly_count"] = anomaly_count
    state["last_phase_c_error_code"] = error_code
    state["last_phase_c_at_utc"] = now
    replace_safe_write(state_path, state)


def _run_ingest_core(
        lab_root,
        manifest_arg,
        rid,
        reports_dir,
        summary_json,
        summary_txt,
        anomalies_path,
        db_path,
        mark,
        stage_state,
        manifest_path_holder,
):
    """Internal ingest flow (invoked from run_ingest)."""
    manifest_path = resolve_manifest_path(lab_root, manifest_arg)
    manifest_path_holder[0] = manifest_path or ""
    mark("manifest_resolved", detail=_bounded_text(manifest_path or "", 256))
    mark(
        "lab_report_paths_resolved",
        detail="reports_dir={0}".format(_bounded_text(reports_dir, 240)),
    )
    if not manifest_path or not os.path.exists(manifest_path):
        summary_fail = {
            "phase": "phase_c",
            "ok": False,
            "run_id": rid,
            "generated_at_utc": iso_utc_now(),
            "manifest_path": manifest_path or "",
            "manifest_run_id": "",
            "manifest_sha256": "",
            "config_hash": "",
            "crosswalk_hash": "",
            "ingest_key_policy_version": INGEST_KEY_POLICY_VERSION,
            "manifest_rows_read": 0,
            "rows_inserted": 0,
            "rows_updated": 0,
            "rows_skipped_duplicate": 0,
            "rows_failed": 0,
            "has_row_anomalies": False,
            "anomaly_count": 0,
            "counts_by_class": {},
            "rows_inserted_by_class": {},
            "rows_skipped_duplicate_by_class": {},
            "phase_c_duplicate_dominant": False,
            "phase_c_duplicate_only": False,
            "error_code": PHASE_C_MANIFEST_MISSING,
        }
        try:
            acquire_lock(lab_root)
            try:
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_phase_c_canonical_reports(summary_fail, summary_json, summary_txt)
                _persist_phase_c_state_or_mark_summary_state_error(
                    summary_fail,
                    summary_json,
                    summary_txt,
                    lambda: persist_phase_c_state(
                        lab_root, rid, False, PHASE_C_MANIFEST_MISSING,
                        None, None, 0, 0, False, 0,
                    ),
                )
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_c_auto_report import submit_phase_c_failure_report
                submit_phase_c_failure_report(lab_root, {
                    "error_code": summary_fail.get("error_code", PHASE_C_MANIFEST_MISSING),
                    "run_id": rid,
                    "first_failed": "manifest_missing",
                    "lab_root": lab_root,
                    "report_json_path": summary_json,
                    "report_txt_path": summary_txt,
                    "summary": summary_fail,
                })
            except Exception:
                pass
        except SystemExit:
            lock_meta = read_lab_lock_diagnostic_metadata(lab_root)
            detail_txt = "lab_lock_acquire_rejected_SystemExit"
            summary_lock = _build_phase_c_lock_fail_summary(
                rid, manifest_path, "", {}, 0, {}, [], detail_txt, lock_meta
            )
            try:
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_phase_c_canonical_reports(summary_lock, summary_json, summary_txt)
            except Exception:
                pass
            return _finish_run_ingest(lab_root, False, rid, summary_lock, PHASE_C_LOCK_FAIL)
        return _finish_run_ingest(
            lab_root,
            False,
            rid,
            summary_fail,
            summary_fail.get("error_code", PHASE_C_MANIFEST_MISSING),
        )

    manifest_run_id = extract_manifest_run_id(manifest_path)
    lineage = load_phase_b_summary_lineage(lab_root, manifest_run_id)
    lineage["manifest_run_id"] = manifest_run_id

    ingest_rows = []
    anomalies = []
    manifest_rows_read = 0
    counts_by_class = {}

    for row, line_num in read_manifest_rows(manifest_path):
        manifest_rows_read += 1
        valid, anomaly = validate_manifest_row(row, line_num)
        if not valid:
            if anomaly:
                anomaly["error_code"] = anomaly.get("error_code", "malformed_json")
                anomalies.append(anomaly)
            continue
        ingest_row = manifest_row_to_ingest_row(row, lineage)
        if ingest_row is None:
            source_type = artifact_class_to_source_type(row.get("artifact_class")) if row else None
            if source_type is None:
                anomalies.append({
                    "line_num": line_num,
                    "error_code": PHASE_C_UNKNOWN_ARTIFACT_CLASS,
                    "message": "Unknown artifact_class",
                    "row_snippet": dict(row) if row else None,
                })
            else:
                anomalies.append({
                    "line_num": line_num,
                    "error_code": PHASE_C_INGEST_KEY_ERROR,
                    "message": "Ingest key computation failed",
                    "row_snippet": dict(row) if row else None,
                })
            continue
        assert row is not None  # valid row passed validate_manifest_row; narrows for type checker
        ingest_rows.append(ingest_row)
        ac = row.get("artifact_class", "unknown")
        counts_by_class[ac] = counts_by_class.get(ac, 0) + 1

    mark(
        "manifest_rows_enumerated",
        detail="read={0};ingest_candidates={1}".format(manifest_rows_read, len(ingest_rows)),
    )

    if not os.path.exists(db_path):
        summary_fail = {
            "phase": "phase_c",
            "ok": False,
            "run_id": rid,
            "generated_at_utc": iso_utc_now(),
            "manifest_path": manifest_path,
            "manifest_run_id": manifest_run_id or "",
            "manifest_sha256": lineage.get("manifest_sha256", ""),
            "config_hash": lineage.get("config_hash", ""),
            "crosswalk_hash": lineage.get("crosswalk_hash", ""),
            "ingest_key_policy_version": INGEST_KEY_POLICY_VERSION,
            "manifest_rows_read": manifest_rows_read,
            "rows_inserted": 0,
            "rows_updated": 0,
            "rows_skipped_duplicate": 0,
            "rows_failed": len(ingest_rows),
            "has_row_anomalies": len(anomalies) > 0,
            "anomaly_count": len(anomalies),
            "counts_by_class": counts_by_class,
            "rows_inserted_by_class": {},
            "rows_skipped_duplicate_by_class": {},
            "phase_c_duplicate_dominant": False,
            "phase_c_duplicate_only": False,
            "error_code": PHASE_C_MANIFEST_INVALID,
        }
        try:
            acquire_lock(lab_root)
            try:
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_phase_c_canonical_reports(summary_fail, summary_json, summary_txt)
                _persist_phase_c_state_or_mark_summary_state_error(
                    summary_fail,
                    summary_json,
                    summary_txt,
                    lambda: persist_phase_c_state(
                        lab_root, rid, False, PHASE_C_MANIFEST_INVALID,
                        manifest_path, lineage.get("manifest_sha256", ""),
                        0, len(ingest_rows), len(anomalies) > 0, len(anomalies),
                        rows_skipped_duplicate=0, rows_inserted_by_class={},
                        rows_skipped_duplicate_by_class={},
                        phase_c_duplicate_dominant=False, phase_c_duplicate_only=False,
                    ),
                )
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_c_auto_report import submit_phase_c_failure_report
                submit_phase_c_failure_report(lab_root, {
                    "error_code": summary_fail.get("error_code", PHASE_C_MANIFEST_INVALID),
                    "run_id": rid,
                    "first_failed": "db_missing",
                    "lab_root": lab_root,
                    "report_json_path": summary_json,
                    "report_txt_path": summary_txt,
                    "summary": summary_fail,
                })
            except Exception:
                pass
        except SystemExit:
            lock_meta = read_lab_lock_diagnostic_metadata(lab_root)
            detail_txt = "lab_lock_acquire_rejected_SystemExit"
            summary_lock = _build_phase_c_lock_fail_summary(
                rid, manifest_path, manifest_run_id, lineage, manifest_rows_read, counts_by_class, anomalies, detail_txt, lock_meta
            )
            try:
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_phase_c_canonical_reports(summary_lock, summary_json, summary_txt)
            except Exception:
                pass
            return _finish_run_ingest(lab_root, False, rid, summary_lock, PHASE_C_LOCK_FAIL)
        return _finish_run_ingest(
            lab_root,
            False,
            rid,
            summary_fail,
            summary_fail.get("error_code", PHASE_C_MANIFEST_INVALID),
        )

    db_error_result = None
    db_error_report_ctx = None
    mark("lock_acquire_begin")
    try:
        acquire_lock(lab_root)
    except SystemExit:
        lock_meta = read_lab_lock_diagnostic_metadata(lab_root)
        detail_bits = ["lab_lock_acquire_rejected_SystemExit"]
        if isinstance(lock_meta, dict):
            if lock_meta.get("lock_path"):
                detail_bits.append("lock_path={0}".format(lock_meta.get("lock_path")))
            if lock_meta.get("lock_pid"):
                detail_bits.append("lock_pid={0}".format(lock_meta.get("lock_pid")))
            if lock_meta.get("lock_heartbeat_at_utc"):
                detail_bits.append("heartbeat={0}".format(lock_meta.get("lock_heartbeat_at_utc")))
        detail_txt = "; ".join(detail_bits)
        summary_lock = _build_phase_c_lock_fail_summary(
            rid, manifest_path, manifest_run_id, lineage, manifest_rows_read, counts_by_class, anomalies, detail_txt, lock_meta
        )
        try:
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _write_phase_c_canonical_reports(summary_lock, summary_json, summary_txt)
            _persist_phase_c_state_or_mark_summary_state_error(
                summary_lock,
                summary_json,
                summary_txt,
                lambda: persist_phase_c_state(
                    lab_root, rid, False, PHASE_C_LOCK_FAIL,
                    manifest_path, lineage.get("manifest_sha256", ""),
                    0, 0, len(anomalies) > 0, len(anomalies),
                    rows_skipped_duplicate=0, rows_inserted_by_class={},
                    rows_skipped_duplicate_by_class={},
                    phase_c_duplicate_dominant=False, phase_c_duplicate_only=False,
                ),
            )
        except Exception:
            pass
        return _finish_run_ingest(lab_root, False, rid, summary_lock, PHASE_C_LOCK_FAIL)

    mark("lock_acquired")
    mark("db_connect_open", detail=_bounded_text(db_path, 512))
    try:
        mark("ingest_write_transaction_begin")
        (
            txn_ok,
            txn_exc,
            rows_inserted,
            rows_skipped,
            rows_failed,
            ins_by_c,
            skip_by_c,
            lock_retry_count,
            lock_retry_elapsed_sec,
            lock_meta,
        ) = _execute_phase_c_ingest_transaction(db_path, ingest_rows, lab_root, mark=mark)
        mark("ingest_write_transaction_end", detail="txn_ok={0}".format(bool(txn_ok)))

        if not txn_ok:
            e = txn_exc
            detail_txt = ""
            cls_name = ""
            if e is not None:
                cls_name = e.__class__.__name__
                detail_txt = str(e)
            summary_fail = {
                "phase": "phase_c",
                "ok": False,
                "run_id": rid,
                "generated_at_utc": iso_utc_now(),
                "manifest_path": manifest_path,
                "manifest_run_id": manifest_run_id or "",
                "manifest_sha256": lineage.get("manifest_sha256", ""),
                "config_hash": lineage.get("config_hash", ""),
                "crosswalk_hash": lineage.get("crosswalk_hash", ""),
                "ingest_key_policy_version": INGEST_KEY_POLICY_VERSION,
                "manifest_rows_read": manifest_rows_read,
                "rows_inserted": 0,
                "rows_updated": 0,
                "rows_skipped_duplicate": 0,
                "rows_failed": len(ingest_rows),
                "has_row_anomalies": len(anomalies) > 0,
                "anomaly_count": len(anomalies),
                "counts_by_class": counts_by_class,
                "rows_inserted_by_class": {},
                "rows_skipped_duplicate_by_class": {},
                "phase_c_duplicate_dominant": False,
                "phase_c_duplicate_only": False,
                "error_code": PHASE_C_DB_WRITE_ERROR,
                "db_error_class": cls_name,
                "db_error_detail": detail_txt,
                "db_lock_retry_count": lock_retry_count,
                "db_lock_retry_elapsed_sec": lock_retry_elapsed_sec,
            }
            _merge_lock_meta_into_summary(summary_fail, lock_meta)
            mark("summary_write_begin", detail="error_path=db_write")
            _write_phase_c_canonical_reports(summary_fail, summary_json, summary_txt)
            mark("summary_write_end", detail="error_path=db_write")
            mark("state_cursor_publish_begin", detail="error_path=db_write")
            _persist_phase_c_state_or_mark_summary_state_error(
                summary_fail,
                summary_json,
                summary_txt,
                lambda: persist_phase_c_state(
                    lab_root, rid, False, PHASE_C_DB_WRITE_ERROR,
                    manifest_path, lineage.get("manifest_sha256", ""),
                    0, len(ingest_rows), len(anomalies) > 0, len(anomalies),
                    rows_skipped_duplicate=0, rows_inserted_by_class={},
                    rows_skipped_duplicate_by_class={},
                    phase_c_duplicate_dominant=False, phase_c_duplicate_only=False,
                ),
            )
            mark("state_cursor_publish_end", detail="error_path=db_write")
            first_failed_txt = detail_txt[:100] if detail_txt else cls_name or "phase_c_db_write"
            db_error_report_ctx = {
                "error_code": summary_fail.get("error_code", PHASE_C_DB_WRITE_ERROR),
                "run_id": rid,
                "first_failed": first_failed_txt,
                "lab_root": lab_root,
                "report_json_path": summary_json,
                "report_txt_path": summary_txt,
                "summary": summary_fail,
            }
            db_error_result = (False, rid, summary_fail, summary_fail.get("error_code", PHASE_C_DB_WRITE_ERROR))

        if db_error_result is not None:
            pass
        else:
            post_commit_report_state = _phase_c_report_target_state(
                reports_dir, summary_json, summary_txt, anomalies_path)
            stage_state["post_commit_report_target_state"] = post_commit_report_state
            mark(
                "post_commit_pre_summary_probe",
                detail=_format_phase_c_report_target_state_for_detail(post_commit_report_state),
            )
            dup_dom, dup_only = _phase_c_duplicate_flags(rows_inserted, rows_skipped, len(ingest_rows))
            summary = {
                "phase": "phase_c",
                "ok": True,
                "run_id": rid,
                "generated_at_utc": iso_utc_now(),
                "manifest_path": manifest_path,
                "manifest_run_id": manifest_run_id or "",
                "manifest_sha256": lineage.get("manifest_sha256", ""),
                "config_hash": lineage.get("config_hash", ""),
                "crosswalk_hash": lineage.get("crosswalk_hash", ""),
                "ingest_key_policy_version": INGEST_KEY_POLICY_VERSION,
                "manifest_rows_read": manifest_rows_read,
                "rows_inserted": rows_inserted,
                "rows_updated": 0,
                "rows_skipped_duplicate": rows_skipped,
                "rows_failed": rows_failed,
                "has_row_anomalies": len(anomalies) > 0,
                "anomaly_count": len(anomalies),
                "counts_by_class": counts_by_class,
                "rows_inserted_by_class": ins_by_c,
                "rows_skipped_duplicate_by_class": skip_by_c,
                "phase_c_duplicate_dominant": dup_dom,
                "phase_c_duplicate_only": dup_only,
                "error_code": None,
            }
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _merge_lock_meta_into_summary(summary, lock_meta)
            mark("summary_write_begin", detail="ok_path=ingest")
            _write_phase_c_canonical_reports(
                summary, summary_json, summary_txt,
                anomalies_path if anomalies else None,
                anomalies if anomalies else None,
            )
            mark("summary_write_end", detail="ok_path=ingest")
            mark("state_cursor_publish_begin", detail="ok_path=ingest")
            if not _persist_phase_c_state_or_mark_summary_state_error(
                summary,
                summary_json,
                summary_txt,
                lambda: persist_phase_c_state(
                    lab_root, rid, True, None,
                    manifest_path, lineage.get("manifest_sha256", ""),
                    rows_inserted, rows_failed, len(anomalies) > 0, len(anomalies),
                    rows_skipped_duplicate=rows_skipped,
                    rows_inserted_by_class=ins_by_c,
                    rows_skipped_duplicate_by_class=skip_by_c,
                    phase_c_duplicate_dominant=dup_dom,
                    phase_c_duplicate_only=dup_only,
                ),
            ):
                db_error_report_ctx = {
                    "error_code": PHASE_C_STATE_WRITE_ERROR,
                    "run_id": rid,
                    "first_failed": str(summary.get("error_detail", ""))[:100],
                    "lab_root": lab_root,
                    "report_json_path": summary_json,
                    "report_txt_path": summary_txt,
                    "summary": summary,
                }
                db_error_result = (False, rid, summary, PHASE_C_STATE_WRITE_ERROR)
            else:
                try:
                    stage_state["phase_c_persisted_ok_summary"] = dict(summary)
                except Exception:
                    stage_state["phase_c_persisted_ok_summary"] = None
                mark("state_cursor_publish_end", detail="ok_path=ingest")
                # Publish diagnostics before final coherency gate so run_ingest itself can
                # enforce diagnostics+summary+state lineage for this exact run id.
                mark("finish_diagnostics_publish_begin")
                stage_state["finish_attempted"] = True
                _write_ingest_from_manifest_diagnostics(lab_root, True, rid, summary, None)
                mark("finish_diagnostics_publish_end")
                mark("finish_coherence_check_begin")
                coherent_ok, coherent_summary, coherent_error = _coerce_success_to_finish_incoherent(
                    lab_root, rid, summary, summary_json, summary_txt
                )
                mark(
                    "finish_coherence_check_end",
                    detail="ok={0};err={1}".format(bool(coherent_ok), _bounded_text(coherent_error or "", 120)),
                )
                return _finish_run_ingest(lab_root, coherent_ok, rid, coherent_summary, coherent_error)
    finally:
        release_lock(lab_root, owner_pid=os.getpid())

    if db_error_report_ctx is not None:
        try:
            from phase_c_auto_report import submit_phase_c_failure_report
            submit_phase_c_failure_report(lab_root, db_error_report_ctx)
        except Exception:
            pass
        return _finish_run_ingest(
            lab_root,
            db_error_result[0],
            db_error_result[1],
            db_error_result[2],
            db_error_result[3],
        )


def run_ingest(lab_root, manifest_arg=None):
    """Main flow. Returns (ok, run_id, summary, error_code)."""
    rid = run_id()
    reports_dir = os.path.join(lab_root, "reports")
    summary_json = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(rid))
    summary_txt = os.path.join(reports_dir, "ingest_write_summary_{0}.txt".format(rid))
    anomalies_path = os.path.join(reports_dir, "ingest_write_anomalies_{0}.jsonl".format(rid))
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    stage_state = {"stage": "run_ingest_entry", "finish_attempted": False}
    manifest_path_holder = [""]

    def mark(stage, detail=None):
        stage_state["stage"] = stage
        _write_ingest_bootstrap_diagnostic(
            lab_root, stage, detail=detail, rid=rid, manifest_arg=manifest_arg)

    mark("run_ingest_entry")
    try:
        result = _run_ingest_core(
            lab_root,
            manifest_arg,
            rid,
            reports_dir,
            summary_json,
            summary_txt,
            anomalies_path,
            db_path,
            mark,
            stage_state,
            manifest_path_holder,
        )
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 1
        tb_txt = _bounded_text(traceback.format_exc(), 3500)
        report_state_detail = _format_phase_c_report_target_state_for_detail(
            stage_state.get("post_commit_report_target_state"))
        detail = "code={0};stage={1};finish_diag_attempted={2};post_commit_report_state={3};tb={4}".format(
            code,
            stage_state["stage"],
            stage_state["finish_attempted"],
            report_state_detail,
            tb_txt,
        )
        mark("run_ingest_system_exit", detail=detail[:2048])
        _revert_persisted_success_after_outer_failure(
            lab_root, rid, stage_state.get("phase_c_persisted_ok_summary"))
        if code == 0 and not stage_state["finish_attempted"]:
            summ = _minimal_summary_finish_incoherent(
                rid,
                manifest_path_holder[0],
                "",
                "SystemExit(0) before finish diagnostics; stage={0}; post_commit_report_state={1}".format(
                    stage_state["stage"],
                    report_state_detail,
                ),
            )
            if isinstance(stage_state.get("post_commit_report_target_state"), dict):
                summ["post_commit_report_target_state"] = dict(stage_state.get("post_commit_report_target_state"))
            try:
                from phase_c_current_attempt import refresh_phase_c_current_attempt_from_lab

                refresh_phase_c_current_attempt_from_lab(lab_root, None, "ingest_from_manifest")
            except Exception:
                pass
            return _finish_run_ingest(lab_root, False, rid, summ, PHASE_C_FINISH_INCOHERENT)
        raise
    except Exception as exc:
        tb_txt = _bounded_text(traceback.format_exc(), 3500)
        cls = exc.__class__.__name__
        msg = _bounded_text(str(exc), 400)
        report_state_detail = _format_phase_c_report_target_state_for_detail(
            stage_state.get("post_commit_report_target_state"))
        detail = "exc={0};msg={1};stage={2};finish_diag_attempted={3};post_commit_report_state={4};tb={5}".format(
            cls,
            msg,
            stage_state["stage"],
            stage_state["finish_attempted"],
            report_state_detail,
            tb_txt,
        )
        mark("run_ingest_exception", detail=detail[:2048])
        _revert_persisted_success_after_outer_failure(
            lab_root, rid, stage_state.get("phase_c_persisted_ok_summary"))
        summ = _minimal_summary_finish_incoherent(
            rid,
            manifest_path_holder[0],
            "",
            "{0}: {1}; stage={2}; post_commit_report_state={3}".format(
                cls,
                msg,
                stage_state["stage"],
                report_state_detail,
            ),
        )
        summ["post_commit_exception_class"] = cls
        summ["post_commit_exception_message"] = msg
        if isinstance(stage_state.get("post_commit_report_target_state"), dict):
            summ["post_commit_report_target_state"] = dict(stage_state.get("post_commit_report_target_state"))
        return _finish_run_ingest(lab_root, False, rid, summ, PHASE_C_FINISH_INCOHERENT)

    ok, rid_ret, summary, error_code = result
    if (
            ok
            and not error_code
            and not _ingest_finish_diagnostics_present(lab_root, rid_ret)):
        summ = dict(summary) if isinstance(summary, dict) else _minimal_summary_finish_incoherent(
            rid_ret, manifest_path_holder[0], "", "summary_not_dict_after_ok")
        summ["ok"] = False
        summ["error_code"] = PHASE_C_FINISH_INCOHERENT
        summ["error_detail"] = "finish_diagnostics_missing_after_ok_return"
        normalize_phase_c_ingest_summary(summ)
        try:
            _write_phase_c_canonical_reports(summ, summary_json, summary_txt)
        except Exception:
            pass
        return _finish_run_ingest(lab_root, False, rid_ret, summ, PHASE_C_FINISH_INCOHERENT)
    return result


def main():
    env_lab_root = get_medicafe_lab_dir_env().strip()
    if env_lab_root:
        _write_ingest_bootstrap_diagnostic(env_lab_root, "before_argparse")
    parser = argparse.ArgumentParser(description="Phase C manifest-to-ingest ingest")
    parser.add_argument("--lab-dir", help="Override lab root")
    parser.add_argument("--manifest", help="Override manifest path")
    try:
        args = parser.parse_args()
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 1
        stage = "argparse_system_exit_0" if code == 0 else "argparse_system_exit_nonzero"
        if env_lab_root:
            _write_ingest_bootstrap_diagnostic(env_lab_root, stage)
        raise
    lab_root = _resolve_lab_root(args)
    _write_ingest_bootstrap_diagnostic(lab_root, "after_argparse", manifest_arg=args.manifest)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    _write_ingest_bootstrap_diagnostic(lab_root, "after_lab_root_creation", manifest_arg=args.manifest)
    _write_ingest_bootstrap_diagnostic(lab_root, "before_run_ingest", manifest_arg=args.manifest)
    try:
        ok, rid, summary, error_code = run_ingest(lab_root, args.manifest)
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 1
        stage = "run_ingest_system_exit_0" if code == 0 else "run_ingest_system_exit_nonzero"
        _write_ingest_bootstrap_diagnostic(
            lab_root,
            stage,
            detail="code={0}".format(code),
            manifest_arg=args.manifest,
        )
        if code == 0:
            # Never allow a silent success when run_ingest aborted before finish diagnostics.
            print(
                "Phase C ingest finish_incoherent: run_ingest raised SystemExit(0) before finish diagnostics/state publish",
                file=sys.stderr,
            )
            _write_ingest_from_manifest_diagnostics(
                lab_root,
                False,
                "unknown",
                {"run_id": "unknown", "error_code": PHASE_C_FINISH_INCOHERENT},
                PHASE_C_FINISH_INCOHERENT,
            )
            sys.exit(1)
        raise
    _write_ingest_bootstrap_diagnostic(
        lab_root,
        "after_run_ingest",
        detail="ok={0}; error_code={1}".format(bool(ok), str(error_code or "")),
        rid=rid,
        manifest_arg=args.manifest,
    )
    if not ok:
        print("Phase C ingest failed: {0}".format(error_code), file=sys.stderr)
        sys.exit(1)
    if summary is None:
        print("Phase C ingest missing summary payload", file=sys.stderr)
        sys.exit(1)
    expected_json = os.path.join(lab_root, "reports", "ingest_write_summary_{0}.json".format(rid))
    if not os.path.isfile(expected_json):
        print("Phase C ingest missing canonical summary file: {0}".format(expected_json), file=sys.stderr)
        sys.exit(1)
    if summary.get("summary_schema_version") != PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION:
        print("Phase C ingest summary_schema_version mismatch", file=sys.stderr)
        sys.exit(1)
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(rid or "unknown"))
    diag_latest_path = os.path.join(lab_root, "reports", "ingest_from_manifest_diagnostics_latest.json")
    diag_run_path = os.path.join(
        lab_root, "reports", "ingest_from_manifest_diagnostics_{0}.json".format(safe_rid)
    )
    finish_parts = []
    if str(summary.get("run_id") or "").strip() != str(rid or "").strip():
        finish_parts.append("summary.run_id != rid")
    if not str(summary.get("manifest_sha256") or "").strip():
        finish_parts.append("manifest_sha256 empty")
    if summary.get("error_code"):
        finish_parts.append("summary error_code set ({0})".format(summary.get("error_code")))
    if not os.path.isfile(diag_latest_path):
        finish_parts.append("ingest_from_manifest_diagnostics_latest.json missing")
    if not os.path.isfile(diag_run_path):
        finish_parts.append("ingest_from_manifest_diagnostics_{0}.json missing".format(safe_rid))
    coherent, reason = verify_phase_c_lab_reflects_persist(lab_root, rid, summary)
    if not coherent:
        finish_parts.append(str(reason or "lab_state_verify_failed"))
    if finish_parts:
        print(
            "Phase C ingest finish_incoherent: {0}".format("; ".join(finish_parts)),
            file=sys.stderr,
        )
        _write_ingest_from_manifest_diagnostics(lab_root, False, rid, summary, PHASE_C_FINISH_INCOHERENT)
        sys.exit(1)
    print("Phase C ingest ok: {0} inserted, {1} skipped".format(
        summary.get("rows_inserted", 0), summary.get("rows_skipped_duplicate", 0)))


def _run_main_entrypoint():
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:
        fallback_lab_root = get_medicafe_lab_dir_env().strip()
        if not fallback_lab_root:
            try:
                fallback_lab_root = resolve_lab_root(None, _workspace_root())
            except Exception:
                fallback_lab_root = ""
        if fallback_lab_root:
            _write_ingest_bootstrap_diagnostic(
                fallback_lab_root,
                "top_level_exception",
                detail="{0}: {1}".format(exc.__class__.__name__, str(exc)[:1024]),
            )
        print("Phase C ingest unhandled exception: {0}".format(exc), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    _run_main_entrypoint()
