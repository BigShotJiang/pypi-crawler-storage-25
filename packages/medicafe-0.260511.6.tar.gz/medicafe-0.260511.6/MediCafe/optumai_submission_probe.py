"""
optumai_submission_probe.py - Manual OPTUMAI post-submit correlation helper.

This module is intentionally opt-in.  It does not alter normal claim submission
behavior and never resubmits a claim.  Given a submitted 837 and an OPTUMAI
Claim Actions response, it can query related OPTUMAI inquiry surfaces and local
remittance data to answer whether a provider-validation response still has
downstream claim evidence.

Compatible with: Windows XP SP3, Python 3.4.4, ASCII-only.
"""
from __future__ import print_function

import json
import os
import time


SCHEMA_VERSION = 1


def _safe_text(value):
    if value is None:
        return ''
    try:
        return str(value).strip()
    except Exception:
        return ''


def _as_bool(value):
    if value is True:
        return True
    if value is False or value is None:
        return False
    return _safe_text(value).lower() in ('1', 'true', 't', 'yes', 'y', 'on')


def _segments(x12_data):
    text = _safe_text(x12_data).replace('\r', '').replace('\n', '')
    if not text:
        return []
    out = []
    for seg in text.split('~'):
        seg = seg.strip()
        if seg:
            out.append(seg)
    return out


def _format_x12_date(value):
    text = _safe_text(value)
    if len(text) == 8 and text.isdigit():
        return "{}/{}/{}".format(text[4:6], text[6:8], text[0:4])
    return text


def _extract_clm_context(segments):
    out = {
        'claim_number': '',
        'charge_amount': '',
        'place_of_service': '',
        'claim_frequency': '',
    }
    for seg in segments:
        if not seg.startswith('CLM*'):
            continue
        parts = seg.split('*')
        if len(parts) > 1:
            out['claim_number'] = _safe_text(parts[1])
        if len(parts) > 2:
            out['charge_amount'] = _safe_text(parts[2])
        if len(parts) > 5:
            pos_parts = _safe_text(parts[5]).split(':')
            if len(pos_parts) > 0:
                out['place_of_service'] = _safe_text(pos_parts[0])
            if len(pos_parts) > 2:
                out['claim_frequency'] = _safe_text(pos_parts[2])
        break
    return out


def _extract_nm1_segment(segments, entity_code):
    prefix = 'NM1*{}*'.format(entity_code)
    for seg in segments:
        if seg.startswith(prefix):
            parts = seg.split('*')
            return {
                'present': True,
                'entity_type': _safe_text(parts[2]) if len(parts) > 2 else '',
                'last_or_org': _safe_text(parts[3]) if len(parts) > 3 else '',
                'first': _safe_text(parts[4]) if len(parts) > 4 else '',
                'id_qualifier': _safe_text(parts[8]) if len(parts) > 8 else '',
                'id': _safe_text(parts[9]) if len(parts) > 9 else '',
                'raw_segment': seg,
            }
    return {
        'present': False,
        'entity_type': '',
        'last_or_org': '',
        'first': '',
        'id_qualifier': '',
        'id': '',
        'raw_segment': '',
    }


def _extract_ref_value(segments, qualifier):
    prefix = 'REF*{}*'.format(qualifier)
    for seg in segments:
        if seg.startswith(prefix):
            parts = seg.split('*')
            if len(parts) > 2:
                return _safe_text(parts[2])
    return ''


def _extract_service_dates(segments):
    for seg in segments:
        if not seg.startswith('DTP*472*'):
            continue
        parts = seg.split('*')
        if len(parts) < 4:
            continue
        qualifier = _safe_text(parts[2])
        value = _safe_text(parts[3])
        if qualifier == 'D8':
            formatted = _format_x12_date(value)
            return formatted, formatted
        if qualifier == 'RD8' and '-' in value:
            vals = value.split('-')
            if len(vals) == 2:
                return _format_x12_date(vals[0]), _format_x12_date(vals[1])
    return '', ''


def _extract_member_dob(segments):
    for seg in segments:
        if not seg.startswith('DMG*'):
            continue
        parts = seg.split('*')
        if len(parts) > 2 and parts[1] == 'D8':
            return _format_x12_date(parts[2])
    return ''


def _extract_x12_probe_context(x12_data):
    segs = _segments(x12_data)
    clm = _extract_clm_context(segs)
    billing = _extract_nm1_segment(segs, '85')
    rendering = _extract_nm1_segment(segs, '82')
    subscriber = _extract_nm1_segment(segs, 'IL')
    payer = _extract_nm1_segment(segs, 'PR')
    start_date, end_date = _extract_service_dates(segs)
    rendering_taxonomy = ''
    for seg in segs:
        if seg.startswith('PRV*PE*PXC*'):
            parts = seg.split('*')
            if len(parts) > 3:
                rendering_taxonomy = _safe_text(parts[3])
            break
    return {
        'claim_number': clm.get('claim_number', ''),
        'charge_amount': clm.get('charge_amount', ''),
        'payer_id': payer.get('id', ''),
        'payer_name': payer.get('last_or_org', ''),
        'member_id': subscriber.get('id', ''),
        'member_first_name': subscriber.get('first', ''),
        'member_last_name': subscriber.get('last_or_org', ''),
        'member_dob': _extract_member_dob(segs),
        'service_start_date': start_date,
        'service_end_date': end_date,
        'billing_provider_npi': billing.get('id', ''),
        'billing_provider_name': "{} {}".format(
            billing.get('first', ''), billing.get('last_or_org', '')).strip(),
        'rendering_provider_npi': rendering.get('id', ''),
        'rendering_provider_name': "{} {}".format(
            rendering.get('first', ''), rendering.get('last_or_org', '')).strip(),
        'rendering_taxonomy': rendering_taxonomy,
        'has_nm1_85': bool(billing.get('present')),
        'has_nm1_82': bool(rendering.get('present')),
        'has_prv_pe': bool(rendering_taxonomy),
        'has_ref_ei': bool(_extract_ref_value(segs, 'EI')),
        'segment_count': len(segs),
    }


def _submission_response_context(submission_response):
    if not isinstance(submission_response, dict):
        return {
            'transactionId': '',
            'statuscode': '',
            'responseType': '',
            'message': '',
            'has_inline_277ca': False,
            'has_999': False,
        }
    x12_response = _safe_text(
        submission_response.get('x12ResponseData')
        or submission_response.get('x12Response277CA')
    )
    inline_277 = _safe_text(submission_response.get('x12Response277CA'))
    if not inline_277 and 'ST*277' in x12_response.upper():
        inline_277 = x12_response
    return {
        'transactionId': _safe_text(
            submission_response.get('transactionId')
            or submission_response.get('transaction_id')
        ),
        'statuscode': _safe_text(
            submission_response.get('statuscode')
            or submission_response.get('statusCode')
        ),
        'responseType': _safe_text(
            submission_response.get('responseType')
            or submission_response.get('response_type')
        ),
        'message': _safe_text(submission_response.get('message')),
        'has_inline_277ca': bool(inline_277),
        'has_999': ('IK5*A' in x12_response.upper() and 'AK9*A' in x12_response.upper()),
    }


def build_probe_context(x12_request_data, submission_response=None):
    """
    Return a compact context dict used by all probe calls.
    """
    ctx = _extract_x12_probe_context(x12_request_data)
    sub = _submission_response_context(submission_response)
    ctx.update(sub)
    ctx['schema_version'] = SCHEMA_VERSION
    return ctx


def _response_status(response):
    if not isinstance(response, dict):
        return ''
    return _safe_text(response.get('statuscode') or response.get('statusCode'))


def _response_claim_count(response):
    if not isinstance(response, dict):
        return 0
    claims = response.get('claims')
    if isinstance(claims, list):
        return len(claims)
    return 0


def _response_has_x12(response):
    if not isinstance(response, dict):
        return False
    return bool(response.get('x12ResponseData') or response.get('x12Response277CA'))


def _call_probe(name, fn, *args, **kwargs):
    try:
        response = fn(*args, **kwargs)
        return {
            'name': name,
            'attempted': True,
            'ok': True,
            'statuscode': _response_status(response),
            'claim_count': _response_claim_count(response),
            'has_x12': _response_has_x12(response),
            'message': _safe_text(response.get('message')) if isinstance(response, dict) else '',
            'response': response,
        }
    except Exception as exc:
        return {
            'name': name,
            'attempted': True,
            'ok': False,
            'statuscode': 'exception',
            'claim_count': 0,
            'has_x12': False,
            'message': _safe_text(exc),
            'response': None,
        }


def _extract_medilink_config(config):
    if isinstance(config, dict) and isinstance(config.get('MediLink_Config'), dict):
        return config.get('MediLink_Config')
    if isinstance(config, dict):
        return config
    return {}


def _client_config(client, config=None):
    if isinstance(config, dict):
        return config
    try:
        cfg = getattr(client, 'config', None)
    except Exception:
        cfg = None
    return cfg if isinstance(cfg, dict) else {}


def _provider_tin_from_config(client, config=None):
    medi = _extract_medilink_config(_client_config(client, config))
    return _safe_text(medi.get('billing_provider_tin'))


def _remittance_path_from_config(client, config=None):
    medi = _extract_medilink_config(_client_config(client, config))
    storage = _safe_text(medi.get('local_storage_path'))
    if storage:
        return os.path.join(storage, 'remittance_parsed.jsonl')
    return ''


def _load_matching_remittance_rows(path, context, max_rows=5000):
    matches = []
    if not path or not os.path.exists(path):
        return matches
    claim_number = _safe_text(context.get('claim_number')).lower()
    transaction_id = _safe_text(context.get('transactionId')).lower()
    payer_id = _safe_text(context.get('payer_id')).lower()
    dos = _safe_text(context.get('service_start_date')).lower()
    try:
        handle = open(path, 'r')
        try:
            scanned = 0
            for line in handle:
                if max_rows and scanned >= int(max_rows):
                    break
                scanned += 1
                try:
                    row = json.loads(line.strip())
                except Exception:
                    continue
                if not isinstance(row, dict):
                    continue
                row_text = json.dumps(row, sort_keys=True).lower()
                score = 0
                reasons = []
                row_claim = _safe_text(row.get('claim_number') or row.get('source_claim_number')).lower()
                if claim_number and (row_claim == claim_number or claim_number in row_text):
                    score += 4
                    reasons.append('claim_number')
                if transaction_id and transaction_id in row_text:
                    score += 3
                    reasons.append('transaction_id')
                row_payer = _safe_text(row.get('payer_id')).lower()
                if payer_id and row_payer == payer_id:
                    score += 1
                    reasons.append('payer_id')
                row_dos = _safe_text(row.get('dos') or row.get('service_date')).lower()
                if dos and row_dos == dos:
                    score += 1
                    reasons.append('dos')
                if score >= 4:
                    matches.append({
                        'score': score,
                        'match_reasons': reasons,
                        'claim_number': row.get('claim_number') or row.get('source_claim_number') or '',
                        'payer_claim_number': row.get('payer_claim_number') or '',
                        'status': row.get('status') or row.get('claim_status') or '',
                        'dos': row.get('dos') or row.get('service_date') or '',
                    })
        finally:
            handle.close()
    except Exception:
        return matches
    return matches


def _member_lookup_has_minimum_context(context):
    member_id = _safe_text(context.get('member_id'))
    first = _safe_text(context.get('member_first_name'))
    last = _safe_text(context.get('member_last_name'))
    dob = _safe_text(context.get('member_dob'))
    return bool(
        (member_id and dob) or
        (member_id and first and last) or
        (first and last and dob)
    )


def classify_probe_result(report):
    """
    Classify what the combined probes imply.
    """
    probes = report.get('probes') if isinstance(report, dict) else {}
    if not isinstance(probes, dict):
        probes = {}
    ack = probes.get('search277CA') or {}
    member = probes.get('searchClaim_member') or {}
    provider = probes.get('searchClaim_provider') or {}
    rem = report.get('local_remittance') if isinstance(report, dict) else {}
    rem_count = int((rem or {}).get('match_count') or 0)

    if _as_bool(ack.get('has_x12')):
        return 'ack_277ca_retrieved'
    if int(member.get('claim_count') or 0) > 0:
        return 'claim_found_by_member_search'
    if int(provider.get('claim_count') or 0) > 0:
        return 'claim_found_by_provider_search'
    if rem_count > 0:
        return 'local_remittance_match'
    context = report.get('context') or {}
    if context.get('has_inline_277ca'):
        return 'inline_277ca_only'
    if context.get('has_999') and context.get('transactionId'):
        return 'accepted_999_with_transaction_only'
    return 'no_downstream_evidence_found'


def build_probe_recommendation(report):
    """
    Return operator policy derived from probe evidence.

    The key distinction is between an OPTUMAI validator error that has no later
    custody evidence and a validator error that is contradicted by 277CA,
    claims inquiry, or remittance evidence.  The latter should be treated as a
    downstream-processing-confirmed warning, not as a local resend cue.
    """
    classification = _safe_text((report or {}).get('classification'))
    downstream_confirmed = classification in (
        'ack_277ca_retrieved',
        'claim_found_by_member_search',
        'claim_found_by_provider_search',
        'local_remittance_match',
    )
    if downstream_confirmed:
        return {
            'downstream_processing_confirmed': True,
            'operator_status': 'processed_despite_provider_validation',
            'recommended_action': 'do_not_resubmit_track_downstream',
            'message': (
                'Downstream OPTUMAI evidence exists despite the Claim Actions '
                'provider-validation response. Treat the validator result as a '
                'warning/noisy precheck signal for this claim and continue '
                'tracking remittance/status evidence.'
            ),
        }
    if classification == 'accepted_999_with_transaction_only':
        return {
            'downstream_processing_confirmed': False,
            'operator_status': 'out_of_custody_unconfirmed',
            'recommended_action': 'defer_resubmit_probe_later',
            'message': (
                'OPTUMAI returned transaction lineage and accepted 999 evidence, '
                'but no downstream status/remittance proof was found yet. Do not '
                'resubmit immediately; rerun the probe after OPTUMAI has had time '
                'to publish status or remittance evidence.'
            ),
        }
    if classification == 'inline_277ca_only':
        return {
            'downstream_processing_confirmed': False,
            'operator_status': 'inline_ack_needs_review',
            'recommended_action': 'review_inline_277ca',
            'message': (
                'Claim Actions included inline 277CA text, but no independent '
                'downstream probe confirmed processing. Review the inline 277CA '
                'and rerun status/remittance correlation before resubmission.'
            ),
        }
    return {
        'downstream_processing_confirmed': False,
        'operator_status': 'no_downstream_evidence',
        'recommended_action': 'investigate_provider_enrollment_or_payload',
        'message': (
            'No downstream OPTUMAI evidence was found. Investigate provider '
            'enrollment/payload identity before any resend decision.'
        ),
    }


def format_probe_summary_lines(report):
    """
    Render a short operator-readable summary.
    """
    context = report.get('context') if isinstance(report, dict) else {}
    probes = report.get('probes') if isinstance(report, dict) else {}
    rem = report.get('local_remittance') if isinstance(report, dict) else {}
    if not isinstance(context, dict):
        context = {}
    if not isinstance(probes, dict):
        probes = {}
    if not isinstance(rem, dict):
        rem = {}

    lines = []
    rec = report.get('recommendation') if isinstance(report, dict) else {}
    if not isinstance(rec, dict):
        rec = {}
    lines.append("OPTUMAI Submission Probe")
    lines.append("classification: {}".format(_safe_text(report.get('classification'))))
    lines.append("operator_status: {}".format(_safe_text(rec.get('operator_status')) or "missing"))
    lines.append("recommended_action: {}".format(_safe_text(rec.get('recommended_action')) or "missing"))
    lines.append("downstream_processing_confirmed: {}".format(
        "yes" if rec.get('downstream_processing_confirmed') else "no"))
    lines.append("payer_id: {}".format(_safe_text(context.get('payer_id')) or "missing"))
    lines.append("claim_number: {}".format(_safe_text(context.get('claim_number')) or "missing"))
    lines.append("transactionId: {}".format(_safe_text(context.get('transactionId')) or "missing"))
    lines.append("responseType: {}".format(_safe_text(context.get('responseType')) or "missing"))
    lines.append("has_999: {}".format("yes" if context.get('has_999') else "no"))
    lines.append("has_inline_277ca: {}".format("yes" if context.get('has_inline_277ca') else "no"))
    lines.append("provider_segments: NM1*85={} NM1*82={} PRV*PE={} REF*EI={}".format(
        "yes" if context.get('has_nm1_85') else "no",
        "yes" if context.get('has_nm1_82') else "no",
        "yes" if context.get('has_prv_pe') else "no",
        "yes" if context.get('has_ref_ei') else "no",
    ))

    for key in ('search277CA', 'searchClaim_member', 'searchClaim_provider'):
        probe = probes.get(key)
        if not isinstance(probe, dict):
            continue
        lines.append("{}: status={} claims={} has_x12={} ok={} message={}".format(
            key,
            _safe_text(probe.get('statuscode')) or "missing",
            int(probe.get('claim_count') or 0),
            "yes" if probe.get('has_x12') else "no",
            "yes" if probe.get('ok') else "no",
            _safe_text(probe.get('message'))[:180],
        ))

    lines.append("local_remittance: attempted={} matches={} path={}".format(
        "yes" if rem.get('attempted') else "no",
        int(rem.get('match_count') or 0),
        _safe_text(rem.get('path')) or "missing",
    ))
    return lines


def write_probe_report(report, output_dir, basename=None):
    """
    Write JSON and text probe reports. Returns dict with paths.
    """
    if not output_dir:
        output_dir = '.'
    if not os.path.isdir(output_dir):
        os.makedirs(output_dir)
    if not basename:
        try:
            basename = "optumai_submission_probe_{}".format(int(time.time()))
        except Exception:
            basename = "optumai_submission_probe"
    json_path = os.path.join(output_dir, basename + ".json")
    txt_path = os.path.join(output_dir, basename + ".txt")
    f = open(json_path, 'w')
    try:
        f.write(json.dumps(report, indent=2, sort_keys=True))
    finally:
        f.close()
    f = open(txt_path, 'w')
    try:
        f.write("\n".join(format_probe_summary_lines(report)))
        f.write("\n")
    finally:
        f.close()
    return {
        'json_path': json_path,
        'txt_path': txt_path,
    }


def probe_optumai_submission_context(
        client,
        x12_request_data=None,
        x12_file_path=None,
        submission_response=None,
        config=None,
        include_277ca=True,
        include_member_search=True,
        include_provider_search=True,
        include_local_remittance=True,
        remittance_path=None,
        max_remittance_rows=5000):
    """
    Run read-only follow-up probes for an OPTUMAI Claim Actions response.

    This function only queries/searches. It does not submit or resubmit claims.
    """
    if not x12_request_data and x12_file_path:
        handle = open(x12_file_path, 'r')
        try:
            x12_request_data = handle.read()
        finally:
            handle.close()

    context = build_probe_context(x12_request_data or '', submission_response)
    report = {
        'schema_version': SCHEMA_VERSION,
        'context': context,
        'probes': {},
        'local_remittance': {
            'attempted': False,
            'path': '',
            'match_count': 0,
            'matches': [],
        },
        'classification': '',
    }

    payer_id = _safe_text(context.get('payer_id'))
    transaction_id = _safe_text(context.get('transactionId'))

    if include_277ca and transaction_id and payer_id:
        from MediCafe.claim_actions_adapter import search_277ca_via_optumai
        report['probes']['search277CA'] = _call_probe(
            'search277CA', search_277ca_via_optumai, client, transaction_id, payer_id)

    if include_member_search and payer_id and _member_lookup_has_minimum_context(context):
        from MediCafe import api_core
        report['probes']['searchClaim_member'] = _call_probe(
            'searchClaim_member',
            api_core.get_claim_status_by_member_data,
            client,
            payer_id,
            context.get('member_id'),
            context.get('member_first_name'),
            context.get('member_last_name'),
            context.get('member_dob'),
            context.get('service_start_date'),
            context.get('service_end_date'),
            context.get('claim_number'))

    if include_provider_search and payer_id and context.get('service_start_date'):
        tin = _provider_tin_from_config(client, config)
        if tin:
            from MediCafe import api_core
            report['probes']['searchClaim_provider'] = _call_probe(
                'searchClaim_provider',
                api_core.get_claim_summary_by_provider,
                client,
                tin,
                context.get('service_start_date'),
                context.get('service_end_date') or context.get('service_start_date'),
                payer_id,
                'false',
                transaction_id or None,
                None)

    if include_local_remittance:
        path = remittance_path or _remittance_path_from_config(client, config)
        matches = _load_matching_remittance_rows(path, context, max_rows=max_remittance_rows)
        report['local_remittance'] = {
            'attempted': bool(path),
            'path': path or '',
            'match_count': len(matches),
            'matches': matches,
        }

    report['classification'] = classify_probe_result(report)
    report['recommendation'] = build_probe_recommendation(report)
    return report
