from __future__ import print_function

import os

TRUE_VALUES = ('1', 'true', 'yes', 'y', 'on')
FALSE_VALUES = ('0', 'false', 'no', 'n', 'off')


def _as_bool(value, default=False):
    if value is True:
        return True
    if value is False:
        return False
    if value is None:
        return bool(default)
    text = str(value).strip().lower()
    if text in TRUE_VALUES:
        return True
    if text in FALSE_VALUES:
        return False
    return bool(default)


def _config_value(config, name, default=False):
    cfg = config if isinstance(config, dict) else {}
    medi = cfg.get('MediLink_Config') if isinstance(cfg.get('MediLink_Config'), dict) else cfg
    if isinstance(medi, dict) and name in medi:
        return _as_bool(medi.get(name), default), 'config'
    return bool(default), 'default'


def _env_override(env, name):
    source = env if isinstance(env, dict) else os.environ
    try:
        raw = source.get(name)
    except Exception:
        raw = None
    if raw is None or str(raw).strip() == '':
        return None, ''
    return _as_bool(raw, False), 'env_override'


def _resolve_bool(config, env, config_name, env_name, default=False):
    value, source = _config_value(config, config_name, default)
    env_value, env_source = _env_override(env, env_name)
    if env_source:
        return env_value, env_source
    return value, source


def resolve_diagnostics_policy(config=None, env=None, runtime_context=None):
    del runtime_context
    debug, debug_source = _resolve_bool(config, env, 'DEBUG', 'MEDICAFE_DEBUG', False)
    console, console_source = _resolve_bool(config, env, 'CONSOLE_LOGGING', 'MEDICAFE_CONSOLE_LOGGING', False)
    perf, perf_source = _resolve_bool(config, env, 'PERFORMANCE_LOGGING', 'MEDICAFE_PERFORMANCE_LOGGING', False)
    verbose_env, verbose_source = _env_override(env, 'MEDICAFE_VERBOSE_LOGGING')
    verbose = bool(debug) if not verbose_source else bool(verbose_env)
    json_console_env, json_console_source = _env_override(env, 'MEDICAFE_JSON_IO_CONSOLE')
    config_diag_env, config_diag_source = _env_override(env, 'MEDICAFE_CONFIG_DIAGNOSTICS_CONSOLE')
    policy = {
        'debug': bool(debug),
        'verbose': bool(verbose),
        'console_logging': bool(console),
        'performance_logging': bool(perf),
        'json_io_console': bool(json_console_env) if json_console_source else False,
        'config_diagnostics_console': bool(config_diag_env) if config_diag_source else False,
    }
    return {
        'schema_version': 1,
        'debug': policy['debug'],
        'verbose': policy['verbose'],
        'console_logging': policy['console_logging'],
        'performance_logging': policy['performance_logging'],
        'json_io_console': policy['json_io_console'],
        'config_diagnostics_console': policy['config_diagnostics_console'],
        'effective_policy': dict(policy),
        'source_map': {
            'debug': debug_source,
            'verbose': verbose_source or debug_source,
            'console_logging': console_source,
            'performance_logging': perf_source,
            'json_io_console': json_console_source or 'default',
            'config_diagnostics_console': config_diag_source or 'default',
        },
        'policy_source_map': {
            'debug': debug_source,
            'verbose': verbose_source or debug_source,
            'console_logging': console_source,
            'performance_logging': perf_source,
            'json_io_console': json_console_source or 'default',
            'config_diagnostics_console': config_diag_source or 'default',
        },
        'policy_reason': 'diagnostics_policy_resolved',
    }

