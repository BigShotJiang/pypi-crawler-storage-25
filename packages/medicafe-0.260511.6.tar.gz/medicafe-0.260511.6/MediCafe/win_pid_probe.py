# -*- coding: utf-8 -*-
"""
Windows-safe process liveness probe (XP-compatible MediCafe code).

Avoids os.kill(pid, 0) on Windows. When OpenProcess fails with access denied,
returns True so callers do not treat an uninspectable live process as dead
(e.g. lock theft while heartbeat is still fresh).
"""
from __future__ import print_function

import os


def windows_process_is_alive_or_unknown(pid_int):
    """
    Return True if pid_int appears to be a live Windows process, or if we
    cannot disprove liveness (access denied). Return False when we can tell
    the process is gone or the probe fails without access denial.
    """
    if os.name != "nt":
        return False
    try:
        import ctypes
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        PROCESS_QUERY_INFORMATION = 0x0400
        STILL_ACTIVE = 259

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid_int)
        if not handle:
            handle = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION, 0, pid_int)
        if not handle:
            try:
                last_error = kernel32.GetLastError()
                if int(last_error) == 5:
                    return True
            except Exception:
                pass
            return False
        try:
            exit_code = ctypes.c_ulong(0)
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                return True
            return int(exit_code.value) == STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)
    except Exception:
        return True
