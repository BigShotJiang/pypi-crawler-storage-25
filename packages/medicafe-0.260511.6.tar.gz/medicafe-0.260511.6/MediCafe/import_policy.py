from __future__ import print_function

import os

TRUE_VALUES = ('1', 'true', 'yes', 'y', 'on')
FALSE_VALUES = ('0', 'false', 'no', 'n', 'off')


def _env_value(env, name):
    source = env if isinstance(env, dict) else os.environ
    try:
        return source.get(name)
    except Exception:
        return None


def _env_bool(env, name, default=False):
    raw = _env_value(env, name)
    if raw is None:
        return bool(default), 'default'
    value = str(raw).strip().lower()
    if value in TRUE_VALUES:
        return True, 'env_override'
    if value in FALSE_VALUES:
        return False, 'env_override'
    return bool(default), 'default'


def minimal_import_enabled(env=None):
    value, _source = _env_bool(env, 'MEDICAFE_MINIMAL_IMPORT', False)
    return value


def smart_import_enabled(env=None):
    minimal = minimal_import_enabled(env)
    skip, _source = _env_bool(env, 'MEDICAFE_SKIP_SMART_IMPORT', False)
    return not (minimal or skip)


def legacy_imports_enabled(env=None):
    minimal = minimal_import_enabled(env)
    skip, _source = _env_bool(env, 'MEDICAFE_SKIP_LEGACY_IMPORTS', False)
    return not (minimal or skip)


def smart_import_validation_enabled(env=None):
    minimal = minimal_import_enabled(env)
    skip, _source = _env_bool(env, 'MEDICAFE_SKIP_SMART_IMPORT_VALIDATE', False)
    return not (minimal or skip)


def import_policy_snapshot(env=None):
    minimal, minimal_source = _env_bool(env, 'MEDICAFE_MINIMAL_IMPORT', False)
    skip_smart, skip_smart_source = _env_bool(env, 'MEDICAFE_SKIP_SMART_IMPORT', False)
    skip_legacy, skip_legacy_source = _env_bool(env, 'MEDICAFE_SKIP_LEGACY_IMPORTS', False)
    skip_validate, skip_validate_source = _env_bool(env, 'MEDICAFE_SKIP_SMART_IMPORT_VALIDATE', False)
    effective = {
        'minimal_import': bool(minimal),
        'smart_import_enabled': not (minimal or skip_smart),
        'legacy_imports_enabled': not (minimal or skip_legacy),
        'smart_import_validation_enabled': not (minimal or skip_validate),
    }
    return {
        'schema_version': 1,
        'effective_policy': effective,
        'policy_source_map': {
            'minimal_import': minimal_source,
            'smart_import_enabled': skip_smart_source if skip_smart else minimal_source,
            'legacy_imports_enabled': skip_legacy_source if skip_legacy else minimal_source,
            'smart_import_validation_enabled': skip_validate_source if skip_validate else minimal_source,
        },
        'policy_reason': 'import_policy_resolved',
    }

