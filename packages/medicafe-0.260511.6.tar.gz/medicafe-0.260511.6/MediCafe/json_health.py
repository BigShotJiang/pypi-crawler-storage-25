from __future__ import print_function

import json
import os
import shutil
import time
import calendar
import uuid
from datetime import datetime

try:
    from MediCafe import json_io
except Exception:
    json_io = None

SCHEMA_VERSION = 1
JSON_HEALTH_RESCAN_RECOMMENDED = 'JSON_HEALTH_RESCAN_RECOMMENDED'
_DEFAULT_MAX_RECORDS = 5000
_MAX_SAMPLE_REFS = 5
_HISTORY_MAX_LINES = 500
_SNAPSHOT_MAX_AGE_SEC = 24 * 60 * 60
_DEFAULT_ARTIFACT_KEYS = [
    'submission_index',
    'remittance_parsed',
    'csv_intake_index',
    'csv_intake_status',
    'config_json',
    'crosswalk_json',
]
_FULL_SCOPE_ARTIFACT_KEYS = set(_DEFAULT_ARTIFACT_KEYS)
_PLACEHOLDER_NAMES = set([
    'unknown', 'n/a', 'na', 'test', 'none', 'null', 'patient', 'demo',
])
_LAST_JSON_HEALTH_SUMMARY = {}


def _now_utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def _safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return int(default)


def _safe_float(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return float(default)


def _new_scan_id():
    return '{}-{}-{}'.format(int(time.time() * 1000), os.getpid(), uuid.uuid4().hex[:8])


def _safe_log(message, level='INFO'):
    try:
        from MediCafe.MediLink_ConfigLoader import log as mc_log
        mc_log(str(message), level=str(level or 'INFO'))
    except Exception:
        pass


def _truthy_env(name):
    value = str(os.environ.get(name, '') or '').strip().lower()
    return value in ('1', 'true', 'yes', 'on')


def _falsey_env(name):
    value = str(os.environ.get(name, '') or '').strip().lower()
    return value in ('0', 'false', 'no', 'off')


def json_health_enabled():
    if _falsey_env('MEDICAFE_JSON_HEALTH'):
        return False
    return True


def json_health_notices_enabled():
    if _falsey_env('MEDICAFE_JSON_HEALTH_NOTICE'):
        return False
    return True


def json_health_auto_repair_enabled():
    """Invalid JSONL lines are removed and the file rewritten. Default is on; set MEDICAFE_JSON_HEALTH_AUTO_REPAIR=0 to disable."""
    if _falsey_env('MEDICAFE_JSON_HEALTH_AUTO_REPAIR'):
        return False
    return True


def _default_notice_threshold(summary):
    if not isinstance(summary, dict):
        return False
    status = str(summary.get('status') or '')
    if status == 'error':
        return True
    if status == 'degraded':
        req_warn = _safe_int(summary.get('required_warning_count') or 0)
        return req_warn > 0
    if status == 'missing':
        req_missing = _safe_int(summary.get('required_missing_count') or 0)
        return req_missing > 0
    return False


def json_health_should_notice(summary):
    if not json_health_notices_enabled():
        return False
    if _truthy_env('MEDICAFE_JSON_HEALTH'):
        status = str((summary or {}).get('status') or '')
        return status in ('degraded', 'error', 'missing')
    return _default_notice_threshold(summary or {})


def _resolve_paths(config):
    medi = {}
    try:
        from MediCafe.core_utils import extract_medilink_config
        medi = extract_medilink_config(config or {})
    except Exception:
        if isinstance(config, dict):
            medi = config.get('MediLink_Config', config)
    if not isinstance(medi, dict):
        medi = {}
    storage = str(medi.get('local_storage_path') or '').strip()
    claims = str(medi.get('local_claims_path') or '').strip()
    if not storage:
        storage = os.path.join(os.getcwd(), 'MediBot', 'DOWNLOADS')
    if not os.path.isabs(storage):
        storage = os.path.abspath(storage)
    if claims and not os.path.isabs(claims):
        claims = os.path.abspath(claims)
    telemetry = os.path.join(storage, 'telemetry')
    return {
        'local_storage_path': storage,
        'local_claims_path': claims,
        'telemetry_dir': telemetry,
        'snapshot_path': os.path.join(telemetry, 'json_health_snapshot.json'),
        'history_path': os.path.join(telemetry, 'json_health_history.jsonl'),
    }


def _submission_index_path(config):
    claims = _resolve_paths(config).get('local_claims_path')
    if not claims:
        return ''
    try:
        from MediCafe.submission_index import _index_path
        return _index_path(claims)
    except Exception:
        return os.path.join(claims, 'submission_index.jsonl')


def submission_index_newer_than_json_health_snapshot_file(config=None):
    """
    True when submission_index.jsonl is newer on disk than telemetry/json_health_snapshot.json,
    or snapshot is missing while the index exists. Used to refresh snapshots before bundle attach.
    """
    cfg = config if isinstance(config, dict) else {}
    paths = _resolve_paths(cfg)
    snap = str(paths.get('snapshot_path') or '').strip()
    sub = _submission_index_path(cfg)
    try:
        if not sub or not os.path.isfile(sub):
            return False
        if not snap or not os.path.isfile(snap):
            return True
        return float(os.path.getmtime(sub)) > float(os.path.getmtime(snap))
    except Exception:
        return False


def _remittance_parsed_path(config):
    return os.path.join(_resolve_paths(config).get('local_storage_path'), 'remittance_parsed.jsonl')


def _csv_intake_index_path(config):
    return os.path.join(_resolve_paths(config).get('local_storage_path'), 'csv_intake_index.json')


def _csv_intake_status_path(config):
    return os.path.join(_resolve_paths(config).get('local_storage_path'), 'csv_intake_index_status.json')


def _config_crosswalk_paths(config):
    try:
        from MediCafe import preflight as _preflight
        config_path, crosswalk_path, _project_dir = _preflight._resolve_paths(config or {})
        return config_path, crosswalk_path
    except Exception:
        base = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        return (
            os.path.join(base, 'json', 'config.json'),
            os.path.join(base, 'json', 'crosswalk.json'),
        )


def _config_json_path(config):
    return _config_crosswalk_paths(config)[0]


def _crosswalk_json_path(config):
    return _config_crosswalk_paths(config)[1]


def _submission_row_filter(row):
    try:
        from MediCafe.submission_index import _is_submission_index_entry
        return bool(_is_submission_index_entry(row))
    except Exception:
        if not isinstance(row, dict):
            return False
        rt = str(row.get('record_type') or '').strip()
        if rt and rt != 'submission':
            return False
        notes = str(row.get('notes') or '').strip().lower()
        return notes != 'ack event'


def _remittance_row_filter(row):
    if not isinstance(row, dict):
        return False
    rt = str(row.get('record_type') or '').strip().lower()
    if rt in ('meta', 'metadata', 'control'):
        return False
    data_source = str(row.get('data_source') or '').strip().lower()
    if data_source and data_source not in ('parsed_file', 'claims_inquiry'):
        return False
    return True


ARTIFACT_SPECS = {
    'submission_index': {
        'required': True,
        'format': 'jsonl',
        'resolver': _submission_index_path,
        'row_filter': _submission_row_filter,
        'validators': ('identity', 'placeholder', 'dates'),
        'max_records': _DEFAULT_MAX_RECORDS,
        'writer_hint': 'MediLink_Up/submission_index',
    },
    'remittance_parsed': {
        'required': False,
        'format': 'jsonl',
        'resolver': _remittance_parsed_path,
        'row_filter': _remittance_row_filter,
        'validators': ('identity', 'financial_identity', 'schema_presence'),
        'max_records': _DEFAULT_MAX_RECORDS,
        'writer_hint': 'MediLink_Down',
    },
    'csv_intake_index': {
        'required': False,
        'format': 'json',
        'resolver': _csv_intake_index_path,
        'expected_root_type': 'object',
        'writer_hint': 'MediBot/process_csvs',
    },
    'csv_intake_status': {
        'required': False,
        'format': 'json',
        'resolver': _csv_intake_status_path,
        'expected_root_type': 'object',
        'writer_hint': 'MediBot/process_csvs',
    },
    'config_json': {
        'required': True,
        'format': 'json',
        'resolver': _config_json_path,
        'expected_root_type': 'object',
        'sidecar_artifact': 'config',
        'writer_hint': 'json/config.json',
    },
    'crosswalk_json': {
        'required': True,
        'format': 'json',
        'resolver': _crosswalk_json_path,
        'expected_root_type': 'object',
        'sidecar_artifact': 'crosswalk',
        'writer_hint': 'json/crosswalk.json',
    },
}


def _norm_token(value):
    return str(value or '').strip().lower()


def _norm_record(row):
    out = {}
    out['patient_name'] = str(
        row.get('patient_name') or row.get('name') or ''
    ).strip()
    first_name = str(
        row.get('member_first_name')
        or row.get('memberFirstName')
        or row.get('first_name')
        or row.get('FIRST')
        or ''
    ).strip()
    last_name = str(
        row.get('member_last_name')
        or row.get('memberLastName')
        or row.get('last_name')
        or row.get('LAST')
        or ''
    ).strip()
    if not out['patient_name'] and (first_name or last_name):
        out['patient_name'] = '{} {}'.format(first_name, last_name).strip()
    out['patient_id'] = str(
        row.get('patient_id')
        or row.get('internal_chart')
        or row.get('internal_patid')
        or row.get('member_id')
        or row.get('memberId')
        or row.get('patid')
        or row.get('PATID')
        or ''
    ).strip()
    if not out['patient_id']:
        ck = str(row.get('claim_key') or '').strip()
        if ck:
            seg0 = str(ck.split('|', 1)[0] or '').strip()
            if seg0:
                out['patient_id'] = seg0
    out['member_id'] = str(row.get('member_id') or row.get('memberId') or '').strip()
    out['dob'] = str(row.get('dob') or row.get('member_dob') or '').strip()
    out['dos'] = str(
        row.get('dos')
        or row.get('service_start_date')
        or row.get('service_date')
        or row.get('surgery_date_iso')
        or row.get('DOS')
        or row.get('service_end_date')
        or ''
    ).strip()
    out['status'] = str(row.get('status') or '').strip()
    out['record_type'] = str(row.get('record_type') or '').strip()
    out['charged'] = row.get('charged')
    out['allowed'] = row.get('allowed')
    out['paid'] = row.get('paid')
    out['patient_resp'] = row.get('patient_resp')
    out['schema_version'] = row.get('schema_version')
    out['data_source'] = str(row.get('data_source') or '').strip().lower()
    return out


def _parse_date(value):
    text = str(value or '').strip()
    if not text:
        return None
    for fmt in (
        '%Y-%m-%d', '%Y/%m/%d', '%Y.%m.%d',
        '%m/%d/%Y', '%m-%d-%Y', '%m.%d.%Y',
        '%m/%d/%y', '%m-%d-%y', '%m.%d.%y',
    ):
        try:
            return datetime.strptime(text, fmt)
        except Exception:
            continue
    return None


def _has_financials(nr):
    for key in ('charged', 'allowed', 'paid', 'patient_resp'):
        value = nr.get(key)
        if value is None:
            continue
        try:
            if abs(float(value)) > 0.00001:
                return True
        except Exception:
            text = str(value).strip()
            if text and text not in ('0', '0.0', '0.00'):
                return True
    return False


def _safe_diag_value(value, max_len=64):
    try:
        text = str(value or '').strip()
    except Exception:
        text = ''
    if len(text) > max_len:
        return text[:max_len] + '...'
    return text


def _basename_hint(value):
    text = _safe_diag_value(value, 160)
    if not text:
        return ''
    try:
        return os.path.basename(text.replace('\\', os.sep))
    except Exception:
        return text[-80:]


def _row_source_hint(row):
    parts = []
    for key in (
        'record_type', 'status', 'data_source', 'source', 'source_system',
        'source_endpoint', 'endpoint', 'parser_name', 'file_type',
    ):
        value = _safe_diag_value(row.get(key))
        if value:
            parts.append('{}={}'.format(key, value))
    for key in ('source_file', 'source_path', 'file_path', 'artifact_name'):
        value = _basename_hint(row.get(key))
        if value:
            parts.append('{}={}'.format(key, value))
            break
    if not parts:
        return 'source_hint=unavailable'
    return ';'.join(parts)


def _field_any(row, keys):
    for key in keys:
        try:
            if str(row.get(key) or '').strip():
                return True
        except Exception:
            continue
    return False


def _row_presence_signature(row):
    checks = [
        ('patient_name', ('patient_name', 'name')),
        ('name_parts', (
            'member_first_name', 'memberFirstName', 'first_name', 'FIRST',
            'member_last_name', 'memberLastName', 'last_name', 'LAST',
        )),
        ('patient_id', ('patient_id', 'internal_chart', 'internal_patid', 'member_id', 'memberId', 'patid', 'PATID')),
        ('claim_key', ('claim_key', 'internal_claim_key')),
        ('claim_number', ('claim_number', 'claimNumber', 'submitted_claim_number')),
        ('payer', ('payer_id', 'primary_insurance', 'payer_name')),
        ('dos', ('dos', 'service_start_date', 'service_date', 'surgery_date_iso', 'DOS')),
        ('charged', ('charged',)),
        ('allowed', ('allowed',)),
        ('paid', ('paid',)),
        ('patient_resp', ('patient_resp',)),
        ('source_file', ('source_file', 'source_path', 'file_path', 'artifact_name')),
    ]
    present = []
    missing = []
    for label, keys in checks:
        if _field_any(row, keys):
            present.append(label)
        else:
            missing.append(label)
    return 'present:{} missing:{}'.format(
        ','.join(present) if present else 'none',
        ','.join(missing) if missing else 'none',
    )


def _add_jsonl_issue_pattern(diag, row, line_no, row_issues):
    if not row_issues:
        return
    codes = []
    for issue in row_issues:
        code = str(issue.get('issue_code') or '').strip()
        if code and code not in codes:
            codes.append(code)
    if not codes:
        return
    source_hint = _row_source_hint(row)
    signature = _row_presence_signature(row)
    key = '|'.join([','.join(sorted(codes)), source_hint, signature])
    groups = diag.setdefault('_issue_pattern_groups_raw', {})
    group = groups.get(key)
    if group is None:
        group = {
            'issue_codes': list(sorted(codes)),
            'source_hint': source_hint,
            'field_presence_signature': signature,
            'count': 0,
            'sample_refs': [],
            'first_line': line_no,
            'last_line': line_no,
        }
        groups[key] = group
    group['count'] += 1
    group['last_line'] = line_no
    if len(group.get('sample_refs') or []) < 5:
        group.setdefault('sample_refs', []).append('line:{}'.format(line_no))


def _finalize_jsonl_issue_patterns(diag, limit=8):
    raw = diag.pop('_issue_pattern_groups_raw', {}) if isinstance(diag, dict) else {}
    if not raw:
        diag['issue_pattern_group_count'] = 0
        diag['top_issue_pattern_groups'] = []
        return
    try:
        values = sorted(
            raw.values(),
            key=lambda item: (-int(item.get('count') or 0), int(item.get('first_line') or 0)),
        )
    except Exception:
        values = list(raw.values())
    diag['issue_pattern_group_count'] = len(values)
    diag['top_issue_pattern_groups'] = [dict(item) for item in values[:limit]]


def _new_issue(artifact_key, issue_code, severity, line_no, writer_hint=''):
    return {
        'schema_version': SCHEMA_VERSION,
        'artifact_key': artifact_key,
        'record_scope': 'row',
        'issue_code': issue_code,
        'severity': severity,
        'count': 1,
        'sample_refs': ['line:{}'.format(line_no)] if line_no else [],
        'lineage_hint': '',
        'writer_hint': writer_hint or '',
    }


def _new_artifact_issue(artifact_key, issue_code, severity, writer_hint=''):
    return {
        'schema_version': SCHEMA_VERSION,
        'artifact_key': artifact_key,
        'record_scope': 'artifact',
        'issue_code': issue_code,
        'severity': severity,
        'count': 1,
        'sample_refs': [],
        'lineage_hint': '',
        'writer_hint': writer_hint or '',
    }


def _safe_error_token(exc):
    try:
        from MediCafe.operator_notices import safe_exception_token
        return safe_exception_token(exc)
    except Exception:
        try:
            return str(type(exc).__name__ or 'Exception')
        except Exception:
            return 'Exception'


def _collect_row_issues(artifact_key, spec, row, line_no):
    issues = []
    nr = _norm_record(row)
    writer_hint = str(spec.get('writer_hint') or '')
    validators = tuple(spec.get('validators') or ())

    if 'identity' in validators:
        if not nr.get('patient_name'):
            issues.append(_new_issue(artifact_key, 'PATIENT_NAME_MISSING', 'warning', line_no, writer_hint))
        if not nr.get('patient_id'):
            issues.append(_new_issue(artifact_key, 'PATIENT_ID_MISSING', 'warning', line_no, writer_hint))
    if 'placeholder' in validators:
        name_token = _norm_token(nr.get('patient_name'))
        if name_token and name_token in _PLACEHOLDER_NAMES:
            issues.append(_new_issue(artifact_key, 'PATIENT_NAME_PLACEHOLDER', 'warning', line_no, writer_hint))
    if 'dates' in validators:
        dos_text = nr.get('dos')
        dob_text = nr.get('dob')
        dos = _parse_date(dos_text) if dos_text else None
        dob = _parse_date(dob_text) if dob_text else None
        if dos_text and dos is None:
            issues.append(_new_issue(artifact_key, 'DATE_PARSE_FAILED', 'warning', line_no, writer_hint))
        if dob_text and dob is None:
            issues.append(_new_issue(artifact_key, 'DATE_PARSE_FAILED', 'warning', line_no, writer_hint))
        if dos and dob and dos < dob:
            issues.append(_new_issue(artifact_key, 'DATE_CHRONOLOGY_INVALID', 'error', line_no, writer_hint))
    if 'financial_identity' in validators:
        if _has_financials(nr) and (not nr.get('patient_id') or not nr.get('patient_name')):
            issues.append(_new_issue(artifact_key, 'FINANCIAL_IDENTITY_MISMATCH', 'warning', line_no, writer_hint))
    if 'schema_presence' in validators:
        if nr.get('schema_version') in (None, ''):
            severity = 'info'
            # Remittance rows with modern parser or financial context should treat
            # missing schema version as actionable warning, not legacy-only info.
            if artifact_key == 'remittance_parsed':
                if nr.get('data_source') in ('parsed_file', 'claims_inquiry') or _has_financials(nr):
                    severity = 'warning'
            issues.append(_new_issue(artifact_key, 'SCHEMA_VERSION_MISSING', severity, line_no, writer_hint))

    return issues


def _group_issues(issues, artifact_basename_map):
    grouped = {}
    for issue in issues:
        key = (
            issue.get('artifact_key'),
            issue.get('issue_code'),
            issue.get('severity'),
            issue.get('record_scope'),
        )
        if key not in grouped:
            grouped[key] = dict(issue)
            grouped[key]['artifact_basename'] = artifact_basename_map.get(issue.get('artifact_key'), '')
        else:
            grouped[key]['count'] = _safe_int(grouped[key].get('count')) + 1
            refs = grouped[key].get('sample_refs') or []
            for ref in issue.get('sample_refs') or []:
                if ref not in refs and len(refs) < _MAX_SAMPLE_REFS:
                    refs.append(ref)
            grouped[key]['sample_refs'] = refs
    return list(grouped.values())


def _scan_jsonl_artifact(artifact_key, spec, config, max_records):
    path = spec.get('resolver')(config)
    basename = os.path.basename(path) if path else ''
    diag = {
        'artifact_key': artifact_key,
        'status': 'ok',
        'exists': False,
        'path_basename': basename,
        'records_scanned': 0,
        'records_skipped': 0,
        'lines_read': 0,
        'invalid_lines': 0,
        'scan_limit_hit': False,
        'error': '',
        'errno': None,
        'winerror': None,
        'required': bool(spec.get('required')),
    }
    issues = []
    if not path:
        diag['status'] = 'skipped'
        diag['error'] = 'path_unresolved'
        return issues, diag, path
    if not os.path.exists(path):
        diag['status'] = 'missing'
        return issues, diag, path
    diag['exists'] = True
    row_filter = spec.get('row_filter')
    max_lines = _safe_int(spec.get('max_lines') or (max_records * 5), max_records * 5)
    if max_lines < max_records:
        max_lines = max_records
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            for line_no, raw in enumerate(handle, start=1):
                if diag['lines_read'] >= max_lines:
                    diag['scan_limit_hit'] = True
                    break
                diag['lines_read'] += 1
                text = raw.strip()
                if not text:
                    continue
                if diag['records_scanned'] >= max_records:
                    diag['scan_limit_hit'] = True
                    break
                try:
                    row = json.loads(text)
                except Exception:
                    diag['invalid_lines'] += 1
                    continue
                if not isinstance(row, dict):
                    diag['invalid_lines'] += 1
                    continue
                if callable(row_filter) and not row_filter(row):
                    diag['records_skipped'] += 1
                    continue
                diag['records_scanned'] += 1
                row_issues = _collect_row_issues(artifact_key, spec, row, line_no)
                issues.extend(row_issues)
                _add_jsonl_issue_pattern(diag, row, line_no, row_issues)
    except Exception as exc:
        diag['status'] = 'error'
        diag['error'] = _safe_error_token(exc)
        diag['errno'] = getattr(exc, 'errno', None)
        diag['winerror'] = getattr(exc, 'winerror', None)
        _finalize_jsonl_issue_patterns(diag)
        return issues, diag, path

    if diag['invalid_lines'] > 0 and diag['status'] == 'ok':
        diag['status'] = 'degraded'
    _finalize_jsonl_issue_patterns(diag)
    return issues, diag, path


def _sidecar_status_for_json_artifact(artifact_key, spec, config_path, crosswalk_path):
    sidecar_artifact = str(spec.get('sidecar_artifact') or '')
    if not sidecar_artifact:
        return {}
    try:
        from MediCafe import json_sidecar
        paths = json_sidecar.sidecar_paths_from_baseline(config_path, crosswalk_path)
        sidecar_path = ''
        if sidecar_artifact == 'config':
            sidecar_path = paths.get('config_local_path') or ''
        elif sidecar_artifact == 'crosswalk':
            sidecar_path = paths.get('crosswalk_state_path') or ''
        _payload, diag = json_sidecar.read_sidecar_file(sidecar_path)
        return {
            'sidecar_basename': os.path.basename(sidecar_path) if sidecar_path else '',
            'sidecar_exists': bool((diag or {}).get('exists')),
            'sidecar_status': str((diag or {}).get('status') or ''),
            'sidecar_schema_version': (diag or {}).get('schema_version'),
        }
    except Exception:
        return {
            'sidecar_basename': '',
            'sidecar_exists': False,
            'sidecar_status': 'sidecar_check_unavailable',
            'sidecar_schema_version': None,
        }


def _scan_json_artifact(artifact_key, spec, config, max_records):
    del max_records
    path = spec.get('resolver')(config)
    basename = os.path.basename(path) if path else ''
    diag = {
        'artifact_key': artifact_key,
        'status': 'ok',
        'exists': False,
        'path_basename': basename,
        'records_scanned': 0,
        'records_skipped': 0,
        'lines_read': 0,
        'invalid_lines': 0,
        'scan_limit_hit': False,
        'error': '',
        'errno': None,
        'winerror': None,
        'required': bool(spec.get('required')),
        'root_type': '',
        'sidecar_basename': '',
        'sidecar_exists': False,
        'sidecar_status': '',
        'sidecar_schema_version': None,
    }
    issues = []
    writer_hint = str(spec.get('writer_hint') or '')
    if not path:
        diag['status'] = 'skipped'
        diag['error'] = 'path_unresolved'
        return issues, diag, path
    if not os.path.exists(path):
        diag['status'] = 'missing'
        return issues, diag, path
    diag['exists'] = True
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
    except ValueError as exc:
        diag['status'] = 'error'
        diag['error'] = _safe_error_token(exc)
        issues.append(_new_artifact_issue(artifact_key, 'JSON_PARSE_FAILED', 'error', writer_hint))
        return issues, diag, path
    except Exception as exc:
        diag['status'] = 'error'
        diag['error'] = _safe_error_token(exc)
        diag['errno'] = getattr(exc, 'errno', None)
        diag['winerror'] = getattr(exc, 'winerror', None)
        return issues, diag, path

    if isinstance(payload, dict):
        diag['root_type'] = 'object'
    elif isinstance(payload, list):
        diag['root_type'] = 'array'
    else:
        diag['root_type'] = type(payload).__name__
    if str(spec.get('expected_root_type') or '') == 'object' and not isinstance(payload, dict):
        diag['status'] = 'error'
        issues.append(_new_artifact_issue(artifact_key, 'JSON_ROOT_TYPE_INVALID', 'error', writer_hint))

    cfg_path, cw_path = _config_crosswalk_paths(config)
    diag.update(_sidecar_status_for_json_artifact(artifact_key, spec, cfg_path, cw_path))
    sidecar_status = str(diag.get('sidecar_status') or '')
    if sidecar_status in ('invalid_structure', 'invalid_syntax', 'unreadable', 'schema_mismatch'):
        if diag.get('status') == 'ok':
            diag['status'] = 'degraded'
        issues.append(_new_artifact_issue(artifact_key, 'JSON_SIDECAR_SCHEMA_STATUS', 'warning', writer_hint))
    return issues, diag, path


def _aggregate_status(diagnostics, grouped_issues):
    warn_count = 0
    err_count = 0
    required_warn = 0
    missing_required = False
    required_error = False
    optional_error = False
    optional_missing_count = 0
    required_missing_count = 0
    scanned = 0
    for diag in diagnostics:
        scanned += 1
        required = bool(diag.get('required'))
        status = str(diag.get('status') or '')
        if status in ('error',):
            if required:
                required_error = True
            else:
                optional_error = True
        if status == 'missing':
            if required:
                missing_required = True
                required_missing_count += 1
            else:
                optional_missing_count += 1
    for issue in grouped_issues:
        sev = str(issue.get('severity') or 'info')
        count = _safe_int(issue.get('count'))
        if sev == 'warning':
            warn_count += count
            spec = ARTIFACT_SPECS.get(issue.get('artifact_key')) or {}
            if spec.get('required'):
                required_warn += count
        elif sev == 'error':
            err_count += count

    if required_error or err_count > 0:
        status = 'error'
    elif missing_required:
        status = 'missing'
    elif warn_count > 0 or optional_error:
        status = 'degraded'
    elif scanned > 0 and optional_missing_count == scanned:
        status = 'missing'
    else:
        status = 'ok'
    return {
        'status': status,
        'warning_count': warn_count,
        'error_count': err_count,
        'required_warning_count': required_warn,
        'required_missing_count': required_missing_count,
        'optional_missing_count': optional_missing_count,
    }


def format_json_health_log_line(summary):
    if not isinstance(summary, dict):
        return 'JSON_HEALTH_SUMMARY status=unknown'
    top_codes = []
    for issue in summary.get('issues', [])[:3]:
        top_codes.append('{}:{}'.format(issue.get('issue_code', ''), _safe_int(issue.get('count', 0))))
    return (
        'JSON_HEALTH_SUMMARY scan_id={scan_id} artifacts={artifacts} status={status} '
        'warning_issues={warn} error_issues={err} top_issue_codes={codes}'
    ).format(
        scan_id=summary.get('scan_id', ''),
        artifacts=_safe_int(summary.get('artifact_count', 0)),
        status=summary.get('status', 'unknown'),
        warn=_safe_int(summary.get('warning_count', 0)),
        err=_safe_int(summary.get('error_count', 0)),
        codes=','.join(top_codes) if top_codes else 'none',
    )


def build_json_health_notice(summary=None):
    payload = summary if isinstance(summary, dict) else get_last_json_health_summary()
    if not isinstance(payload, dict) or not payload:
        return None
    if not json_health_should_notice(payload):
        return None
    status = str(payload.get('status') or 'unknown')
    warn = _safe_int(payload.get('warning_count') or 0)
    err = _safe_int(payload.get('error_count') or 0)
    issue_total = len(payload.get('issues') or [])
    top_issue = ''
    issues = payload.get('issues') or []
    if issues:
        top_issue = str(issues[0].get('issue_code') or '')
    return {
        'status': status,
        'operator_notice': (
            'Notice: JSON health is {} ({} warning count, {} error count, {} issue groups). '
            'Review telemetry json health snapshot for artifact-level diagnostics.'
        ).format(status, warn, err, issue_total),
        'log_message': format_json_health_log_line(payload),
        'top_issue_code': top_issue,
    }


def _persist_summary(config, summary):
    paths = _resolve_paths(config)
    if not json_io:
        return False
    ok_snapshot = json_io.write_json_atomic(
        paths.get('snapshot_path'),
        summary,
        'json_health_snapshot',
        'json_health',
        indent=2,
        sort_keys=False,
        lock=True,
        ensure_ascii=True,
    )
    ok_history = json_io.append_jsonl(
        paths.get('history_path'),
        summary,
        'json_health_history',
        'json_health',
        lock=True,
        record_failure=True,
    )
    json_io.rotate_jsonl_tail(
        paths.get('history_path'),
        _HISTORY_MAX_LINES,
        'json_health_history',
        'json_health',
        record_failure=True,
    )
    return bool(ok_snapshot and ok_history)


def _summary_has_invalid_jsonl(summary):
    if not isinstance(summary, dict):
        return False
    for d in summary.get('artifact_diagnostics') or []:
        if _safe_int((d or {}).get('invalid_lines')) > 0:
            return True
    return False


def _summary_has_repairable_csv_intake_json(summary):
    if not isinstance(summary, dict):
        return False
    for d in summary.get('artifact_diagnostics') or []:
        key = str((d or {}).get('artifact_key') or '')
        status = str((d or {}).get('status') or '')
        if key in ('csv_intake_index', 'csv_intake_status') and status == 'error':
            return True
    return False


def _csv_intake_repair_payload(artifact_key):
    now = int(time.time())
    if artifact_key == 'csv_intake_index':
        return {
            'version': 1,
            'updated_at_utc': now,
            'entries': {},
            'recovered_by': 'json_health',
            'recovered_at_utc': _now_utc(),
        }
    return {
        'source': 'json_health',
        'started_at': None,
        'completed_at': now,
        'phase': 'repaired_empty',
        'requested_downloaded_count': 0,
        'stats': {},
        'recovered_by': 'json_health',
        'recovered_at_utc': _now_utc(),
    }


def repair_csv_intake_json_artifacts_for_config(config, summary=None, backup=True):
    cfg = config if isinstance(config, dict) else {}
    diagnostics = []
    if isinstance(summary, dict):
        diagnostics = list(summary.get('artifact_diagnostics') or [])
    out = []
    for artifact_key in ('csv_intake_index', 'csv_intake_status'):
        should_repair = False
        for diag in diagnostics:
            if str((diag or {}).get('artifact_key') or '') == artifact_key:
                should_repair = str((diag or {}).get('status') or '') == 'error'
                break
        if not should_repair:
            continue
        spec = ARTIFACT_SPECS.get(artifact_key) or {}
        try:
            path = spec.get('resolver')(cfg)
        except Exception:
            path = ''
        result = {
            'artifact_key': artifact_key,
            'path': path or '',
            'ok': False,
            'changed': False,
            'backup_path': '',
            'error': '',
        }
        if not path or not os.path.isfile(path):
            result['ok'] = True
            result['error'] = 'missing'
            out.append(result)
            continue
        if backup:
            bak = '{0}.json_health_bak.{1}'.format(path, int(time.time()))
            try:
                shutil.copy2(path, bak)
                result['backup_path'] = bak
            except Exception as exc:
                result['error'] = 'backup_failed:{0}'.format(_safe_error_token(exc))
                out.append(result)
                continue
        if not json_io:
            result['error'] = 'json_io_unavailable'
            out.append(result)
            continue
        ok = json_io.write_json_atomic(
            path,
            _csv_intake_repair_payload(artifact_key),
            'json_health_csv_intake_repair',
            'json_health',
            indent=2,
            sort_keys=True,
            lock=True,
            ensure_ascii=True,
        )
        result['ok'] = bool(ok)
        result['changed'] = bool(ok)
        if not ok:
            result['error'] = 'rewrite_failed'
        out.append(result)
    return out


def sanitize_jsonl_file(path, backup=True):
    """
    Drop lines that are not valid JSON objects (dict). Rewrites the file when any
    line is removed. Creates a timestamped .sanitized_bak.* sibling when backup=True.
    Does not attempt to fix semantic issues (missing patient_id, etc.).
    """
    result = {
        'path': path or '',
        'ok': False,
        'lines_read': 0,
        'lines_kept': 0,
        'lines_dropped': 0,
        'changed': False,
        'backup_path': '',
        'error': '',
    }
    if not path or not os.path.isfile(path):
        result['error'] = 'missing'
        return result
    kept_chunks = []
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            for raw in handle:
                result['lines_read'] += 1
                text = str(raw or '').strip()
                if not text:
                    continue
                try:
                    row = json.loads(text)
                except Exception:
                    result['lines_dropped'] += 1
                    continue
                if not isinstance(row, dict):
                    result['lines_dropped'] += 1
                    continue
                kept_chunks.append(json.dumps(row, ensure_ascii=True) + '\n')
                result['lines_kept'] += 1
    except Exception as exc:
        result['error'] = _safe_error_token(exc)
        return result
    if result['lines_dropped'] == 0:
        result['ok'] = True
        return result
    body = ''.join(kept_chunks)
    if backup:
        bak = '{0}.sanitized_bak.{1}'.format(path, int(time.time()))
        try:
            shutil.copy2(path, bak)
            result['backup_path'] = bak
        except Exception as exc:
            result['error'] = 'backup_failed:{0}'.format(_safe_error_token(exc))
            return result
    if not json_io or not getattr(json_io, 'rewrite_jsonl_atomic', None):
        result['error'] = 'json_io_unavailable'
        return result
    ok = json_io.rewrite_jsonl_atomic(
        path,
        body,
        artifact='json_health_sanitize',
        writer='json_health',
    )
    if not ok:
        result['error'] = 'rewrite_failed'
        return result
    result['ok'] = True
    result['changed'] = True
    return result


def sanitize_jsonl_artifacts_for_config(config, artifact_keys=None, backup=True):
    """
    Run sanitize_jsonl_file on resolved JSON health ledger paths (submission_index,
    remittance_parsed by default). Returns a list of per-artifact result dicts.
    """
    cfg = config if isinstance(config, dict) else {}
    keys = list(artifact_keys or ['submission_index', 'remittance_parsed'])
    out = []
    for key in keys:
        key_s = str(key or '').strip()
        spec = ARTIFACT_SPECS.get(key_s)
        if not spec:
            out.append({
                'artifact_key': key_s,
                'ok': False,
                'changed': False,
                'error': 'unknown_artifact',
            })
            continue
        try:
            path = spec.get('resolver')(cfg)
        except Exception:
            path = ''
        if not path or not os.path.isfile(path):
            out.append({
                'artifact_key': key_s,
                'path': path or '',
                'ok': True,
                'changed': False,
                'lines_dropped': 0,
            })
            continue
        res = sanitize_jsonl_file(path, backup=backup)
        res['artifact_key'] = key_s
        out.append(res)
    return out


def run_json_health_scan(config=None, artifact_keys=None, max_records=None, persist=True, repair_recursion_depth=0):
    global _LAST_JSON_HEALTH_SUMMARY
    if not json_health_enabled():
        _LAST_JSON_HEALTH_SUMMARY = {'status': 'skipped', 'reason': 'disabled'}
        return dict(_LAST_JSON_HEALTH_SUMMARY)
    cfg = config if isinstance(config, dict) else {}
    raw_keys = list(artifact_keys or _DEFAULT_ARTIFACT_KEYS)
    keys = []
    seen_keys = set()
    for key in raw_keys:
        key_s = str(key or '').strip()
        if not key_s or key_s in seen_keys:
            continue
        seen_keys.add(key_s)
        keys.append(key_s)

    prev_snap, _prev_snap_mtime = _read_snapshot(config=cfg)
    rescan_due_to_submission_index = False
    try:
        sub_idx_path = _submission_index_path(cfg)
        if sub_idx_path and os.path.isfile(sub_idx_path) and isinstance(prev_snap, dict):
            prev_epoch = _parse_scanned_at_utc_epoch(prev_snap.get('scanned_at_utc'))
            idx_mtime = int(os.path.getmtime(sub_idx_path))
            if prev_epoch is not None and idx_mtime > prev_epoch:
                rescan_due_to_submission_index = True
    except Exception:
        pass

    issues = []
    diagnostics = []
    artifact_basenames = {}
    max_rows = _safe_int(max_records or _DEFAULT_MAX_RECORDS, _DEFAULT_MAX_RECORDS)
    for key in keys:
        spec = ARTIFACT_SPECS.get(key)
        if not spec:
            diagnostics.append({
                'artifact_key': key,
                'status': 'skipped',
                'exists': False,
                'path_basename': '',
                'records_scanned': 0,
                'records_skipped': 0,
                'invalid_lines': 0,
                'scan_limit_hit': False,
                'error': 'unknown_artifact',
                'required': False,
            })
            continue
        artifact_max = _safe_int(spec.get('max_records') or max_rows, max_rows)
        effective_max = min(max_rows, artifact_max)
        if str(spec.get('format') or '') == 'json':
            artifact_issues, diag, path = _scan_json_artifact(key, spec, cfg, effective_max)
        else:
            artifact_issues, diag, path = _scan_jsonl_artifact(key, spec, cfg, effective_max)
        artifact_basenames[key] = os.path.basename(path) if path else ''
        issues.extend(artifact_issues)
        diagnostics.append(diag)

    grouped = _group_issues(issues, artifact_basenames)
    status_meta = _aggregate_status(diagnostics, grouped)
    summary = {
        'schema_version': SCHEMA_VERSION,
        'scan_id': _new_scan_id(),
        'scanned_at_utc': _now_utc(),
        'status': status_meta.get('status'),
        'artifact_count': len(diagnostics),
        'artifact_keys': list(keys),
        'scan_scope': (
            'full' if _FULL_SCOPE_ARTIFACT_KEYS.issubset(set(keys)) else 'partial'
        ),
        'warning_count': status_meta.get('warning_count'),
        'error_count': status_meta.get('error_count'),
        'required_warning_count': status_meta.get('required_warning_count'),
        'required_missing_count': status_meta.get('required_missing_count'),
        'optional_missing_count': status_meta.get('optional_missing_count'),
        'issues': grouped,
        'artifact_diagnostics': diagnostics,
    }
    if 'submission_index' in keys:
        try:
            from MediCafe.submission_index import summarize_submission_index_identity
            summary['submission_index_identity_summary'] = summarize_submission_index_identity(
                _submission_index_path(cfg)
            )
        except Exception:
            summary['submission_index_identity_summary'] = {'error': 'unavailable'}
    if rescan_due_to_submission_index:
        # Fresh scan supersedes a stale snapshot; do not flag JSON_HEALTH_RESCAN_RECOMMENDED on the
        # new summary (operators should see that code on stale attachment selection only).
        summary['submission_index_superseded_prior_json_health_snapshot'] = True

    _LAST_JSON_HEALTH_SUMMARY = dict(summary)
    if persist:
        _persist_summary(cfg, summary)
    _safe_log(format_json_health_log_line(summary), level=_summary_log_level(summary))

    if (
        persist
        and repair_recursion_depth == 0
        and json_health_auto_repair_enabled()
        and summary.get('status') not in ('skipped',)
        and (
            _summary_has_invalid_jsonl(summary)
            or _summary_has_repairable_csv_intake_json(summary)
        )
    ):
        repair_results = []
        if _summary_has_invalid_jsonl(summary):
            repair_results.extend(sanitize_jsonl_artifacts_for_config(cfg, artifact_keys=keys, backup=True))
        if _summary_has_repairable_csv_intake_json(summary):
            repair_results.extend(repair_csv_intake_json_artifacts_for_config(cfg, summary=summary, backup=True))
        if any(r.get('changed') for r in repair_results):
            _safe_log(
                'JSON_HEALTH_AUTO_REPAIR changed unhealthy JSON artifacts; re-scanning',
                level='INFO',
            )
            repaired_line_count = 0
            repaired_artifacts = []
            backup_paths = []
            for r in repair_results:
                try:
                    repaired_line_count += int(
                        r.get('invalid_line_count')
                        or r.get('removed_line_count')
                        or r.get('lines_dropped')
                        or 0
                    )
                except Exception:
                    pass
                if r.get('changed') and r.get('artifact_key'):
                    repaired_artifacts.append(r.get('artifact_key'))
                if r.get('backup_path'):
                    backup_paths.append(r.get('backup_path'))
            repaired = run_json_health_scan(
                config=cfg,
                artifact_keys=keys,
                max_records=max_records,
                persist=True,
                repair_recursion_depth=1,
            )
            repaired['json_health_auto_repair'] = {
                'enabled': True,
                'status': 'changed',
                'repaired_line_count': repaired_line_count,
                'repaired_artifacts': repaired_artifacts,
                'backup_paths': backup_paths,
                'auto_repair_source': 'json_health_auto_repair_enabled',
                'repair_results': repair_results,
            }
            _LAST_JSON_HEALTH_SUMMARY = dict(repaired)
            if persist:
                _persist_summary(cfg, repaired)
            return repaired
    return dict(summary)


def get_last_json_health_summary():
    return dict(_LAST_JSON_HEALTH_SUMMARY or {})


def _read_snapshot(config=None):
    paths = _resolve_paths(config or {})
    snap_path = paths.get('snapshot_path')
    if not snap_path or not os.path.exists(snap_path):
        return None, None
    try:
        with open(snap_path, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        mtime = os.path.getmtime(snap_path)
        return payload, mtime
    except Exception:
        return None, None


def _read_latest_full_summary_from_history(config=None):
    paths = _resolve_paths(config or {})
    history_path = paths.get('history_path')
    if not history_path or not os.path.exists(history_path):
        return None
    latest_full = None
    try:
        with open(history_path, 'r', encoding='utf-8') as handle:
            for raw in handle:
                text = str(raw or '').strip()
                if not text:
                    continue
                try:
                    row = json.loads(text)
                except Exception:
                    continue
                if not isinstance(row, dict):
                    continue
                if str(row.get('scan_scope') or '') != 'full':
                    continue
                latest_full = row
    except Exception:
        return None
    return latest_full


def _summary_age_seconds(summary, mtime=None):
    if mtime is not None:
        try:
            return max(0, int(time.time() - float(mtime)))
        except Exception:
            pass
    scanned = str((summary or {}).get('scanned_at_utc') or '').strip()
    if not scanned:
        return None
    try:
        dt = datetime.strptime(scanned, '%Y-%m-%dT%H:%M:%SZ')
        return max(0, int(time.time() - calendar.timegm(dt.timetuple())))
    except Exception:
        return None


def _parse_scanned_at_utc_epoch(scanned_at):
    text = str(scanned_at or '').strip()
    if not text:
        return None
    if text.endswith('Z'):
        text = text[:-1]
    try:
        dt = datetime.strptime(text, '%Y-%m-%dT%H:%M:%S')
        return int(calendar.timegm(dt.timetuple()))
    except Exception:
        return None


def _summary_log_level(summary):
    status = str((summary or {}).get('status') or '')
    if status in ('degraded', 'error'):
        return 'WARNING'
    if status == 'missing' and _safe_int((summary or {}).get('required_missing_count') or 0) > 0:
        return 'WARNING'
    return 'INFO'


def _attachment_candidate(summary, mtime=None, source='snapshot'):
    payload = summary if isinstance(summary, dict) else {}
    age = _summary_age_seconds(payload, mtime=mtime)
    status = str(payload.get('status') or '')
    stale_ok = bool(age is not None and age > _SNAPSHOT_MAX_AGE_SEC and status == 'ok')
    return {
        'summary': payload,
        'mtime': mtime,
        'source': str(source or 'snapshot'),
        'age': age,
        'status': status,
        'scope': str(payload.get('scan_scope') or ''),
        'stale': bool(age is not None and age > _SNAPSHOT_MAX_AGE_SEC),
        'eligible': not stale_ok,
    }


def _select_attachment_candidate(snapshot_candidate, full_candidate):
    if isinstance(full_candidate, dict):
        # Prefer full summary when it is eligible and not stale.
        if full_candidate.get('eligible') and (not full_candidate.get('stale')):
            return full_candidate
        # Prefer fresh current snapshot when available.
        if isinstance(snapshot_candidate, dict) and snapshot_candidate.get('eligible'):
            return snapshot_candidate
        # Fall back to stale-but-eligible full summary only when snapshot is unavailable/ineligible.
        if full_candidate.get('eligible'):
            return full_candidate
    if isinstance(snapshot_candidate, dict) and snapshot_candidate.get('eligible'):
        return snapshot_candidate
    return None


def build_json_health_support_attachment(summary_or_snapshot=None):
    src = summary_or_snapshot if isinstance(summary_or_snapshot, dict) else {}
    if not src:
        return {}
    out = {
        'schema_version': SCHEMA_VERSION,
        'scan_id': src.get('scan_id', ''),
        'scanned_at_utc': src.get('scanned_at_utc', ''),
        'status': src.get('status', 'unknown'),
        'artifact_count': _safe_int(src.get('artifact_count', 0)),
        'artifact_keys': list(src.get('artifact_keys') or []),
        'scan_scope': str(src.get('scan_scope') or 'unknown'),
        'warning_count': _safe_int(src.get('warning_count', 0)),
        'error_count': _safe_int(src.get('error_count', 0)),
        'required_missing_count': _safe_int(src.get('required_missing_count', 0)),
        'optional_missing_count': _safe_int(src.get('optional_missing_count', 0)),
        'issues': [],
        'artifact_diagnostics': [],
    }
    sis = src.get('submission_index_identity_summary')
    if isinstance(sis, dict):
        out['submission_index_identity_summary'] = dict(sis)
    oac = src.get('operator_action_codes')
    if isinstance(oac, list):
        out['operator_action_codes'] = list(oac)
    for issue in src.get('issues') or []:
        out['issues'].append({
            'artifact_key': issue.get('artifact_key', ''),
            'artifact_basename': issue.get('artifact_basename', ''),
            'issue_code': issue.get('issue_code', ''),
            'severity': issue.get('severity', ''),
            'count': _safe_int(issue.get('count', 0)),
            'sample_refs': list(issue.get('sample_refs') or [])[:_MAX_SAMPLE_REFS],
        })
    for diag in src.get('artifact_diagnostics') or []:
        out['artifact_diagnostics'].append({
            'artifact_key': diag.get('artifact_key', ''),
            'status': diag.get('status', ''),
            'exists': bool(diag.get('exists')),
            'path_basename': diag.get('path_basename', ''),
            'root_type': str(diag.get('root_type') or ''),
            'sidecar_basename': str(diag.get('sidecar_basename') or ''),
            'sidecar_exists': bool(diag.get('sidecar_exists')),
            'sidecar_status': str(diag.get('sidecar_status') or ''),
            'sidecar_schema_version': diag.get('sidecar_schema_version'),
            'records_scanned': _safe_int(diag.get('records_scanned', 0)),
            'records_skipped': _safe_int(diag.get('records_skipped', 0)),
            'lines_read': _safe_int(diag.get('lines_read', 0)),
            'invalid_lines': _safe_int(diag.get('invalid_lines', 0)),
            'scan_limit_hit': bool(diag.get('scan_limit_hit')),
            'error': str(diag.get('error') or ''),
            'errno': diag.get('errno'),
            'winerror': diag.get('winerror'),
        })
    return out


def get_latest_json_health_attachment(config=None):
    summary, mtime = _read_snapshot(config=config)
    snapshot_candidate = (
        _attachment_candidate(summary, mtime=mtime, source='snapshot')
        if isinstance(summary, dict)
        else None
    )
    full_candidate = None
    if (not isinstance(snapshot_candidate, dict)) or snapshot_candidate.get('scope') != 'full':
        full_summary = _read_latest_full_summary_from_history(config=config)
        if isinstance(full_summary, dict):
            full_candidate = _attachment_candidate(
                full_summary,
                mtime=None,
                source='history_full_fallback',
            )
    selected = _select_attachment_candidate(snapshot_candidate, full_candidate)
    if not isinstance(selected, dict):
        return None
    payload = build_json_health_support_attachment(selected.get('summary'))
    payload['snapshot_age_seconds'] = selected.get('age')
    payload['snapshot_source'] = selected.get('source')
    src = str(selected.get('source') or '')
    if src == 'history_full_fallback':
        attach_class = 'history_fallback'
    elif bool(selected.get('stale')):
        attach_class = 'stale_historical'
    else:
        attach_class = 'fresh_current'
    payload['json_health_attachment_class'] = attach_class
    try:
        sub_path = _submission_index_path(config)
        snap_epoch = None
        summ = selected.get('summary') if isinstance(selected.get('summary'), dict) else {}
        snap_epoch = _parse_scanned_at_utc_epoch(summ.get('scanned_at_utc'))
        if sub_path and os.path.isfile(sub_path):
            idx_mt = int(os.path.getmtime(sub_path))
            cmp_epoch = snap_epoch
            if cmp_epoch is None and isinstance(mtime, (int, float)):
                cmp_epoch = int(mtime)
            if cmp_epoch is not None and idx_mt > cmp_epoch:
                payload['submission_index_newer_than_json_health_snapshot'] = True
                codes = list(payload.get('operator_action_codes') or [])
                if JSON_HEALTH_RESCAN_RECOMMENDED not in codes:
                    codes.append(JSON_HEALTH_RESCAN_RECOMMENDED)
                payload['operator_action_codes'] = codes
    except Exception:
        pass
    return ('json_health_snapshot.json', payload)
