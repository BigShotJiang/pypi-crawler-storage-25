# -*- coding: utf-8 -*-
"""
Unified evidence bundle manifest (XP-compatible: Python 3.4).

Step 1: EvidenceRequest normalization, lab state reads, Phase C failure contract,
manifest_to_extra_files / manifest_to_extra_meta, merge_extra_files for callers.

attachment_contract_status (explicit semantics):
- pass: every Phase-C-required attachment for this request resolved to a path or
  inline body (no missing_required_evidence entries for required items).
- degraded: at least one required attachment is missing (recorded in
  missing_required_evidence) but the bundle may still be useful to send
  (e.g. diagnostics_state + run_cursor without run-aligned ingest summary).
- fail: contract is not meaningfully actionable (reserved for future bundle_kind
  policy; first slice uses this only when lab_root is unusable and nothing resolved).
"""
from __future__ import print_function

import json
import os
import time

try:
    from MediCafe.evidence_mode import (
        MODE_INCOHERENT_STATE,
        MODE_LIVE_STATUS,
        MODE_RUN_EVIDENCE,
        evidence_mode_report_text,
        resolve_evidence_mode,
    )
except Exception:
    try:
        from evidence_mode import (
            MODE_INCOHERENT_STATE,
            MODE_LIVE_STATUS,
            MODE_RUN_EVIDENCE,
            evidence_mode_report_text,
            resolve_evidence_mode,
        )
    except Exception:
        MODE_RUN_EVIDENCE = "run_evidence"
        MODE_LIVE_STATUS = "live_status"
        MODE_INCOHERENT_STATE = "incoherent_state"

        def resolve_evidence_mode(lab_root, bundle_kind="", requested_run_id="", send_source="",
                                  diagnostics_state=None, run_cursor=None):
            return {
                "schema_version": 1,
                "mode": MODE_RUN_EVIDENCE,
                "selected_run_id": requested_run_id or "",
                "active_run_id": "",
                "last_completed_run_id": "",
                "coherence_status": "ready",
                "blocking_reason": "",
                "allowed_current_artifacts": "completed_run",
                "decisive_run_evidence_current": True,
                "current_decision": "send_coherent_completed_run_evidence",
            }

        def evidence_mode_report_text(mode_info):
            return "Evidence Mode Report\nmode={0}\n".format(
                _safe_str((mode_info or {}).get("mode")) if isinstance(mode_info, dict) else MODE_RUN_EVIDENCE
            )

try:
    from MediCafe.evidence_contracts import (
        EVIDENCE_MANIFEST_SCHEMA_VERSION,
        EVIDENCE_REQUEST_SCHEMA_VERSION,
        PHASE_C_CORRELATION_ARCHIVE_NAME,
    )
except Exception:
    try:
        from evidence_contracts import (
            EVIDENCE_MANIFEST_SCHEMA_VERSION,
            EVIDENCE_REQUEST_SCHEMA_VERSION,
            PHASE_C_CORRELATION_ARCHIVE_NAME,
        )
    except Exception:
        EVIDENCE_REQUEST_SCHEMA_VERSION = 1
        EVIDENCE_MANIFEST_SCHEMA_VERSION = 1
        PHASE_C_CORRELATION_ARCHIVE_NAME = "phase_c_bundle_correlation_note.txt"

try:
    from MediCafe.phase_d_developer_unblock import evidence_report_entries_from_summary
except Exception:
    try:
        from phase_d_developer_unblock import evidence_report_entries_from_summary
    except Exception:
        evidence_report_entries_from_summary = None


def _safe_str(value):
    if value is None:
        return ""
    return str(value)


def _read_json_dict(path):
    """Return dict from JSON file, or None if missing/invalid."""
    if not path or not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            return payload
        return None
    except Exception:
        return None


def _safe_int(value, default=0):
    try:
        if value is None or value == "":
            return default
        return int(value)
    except Exception:
        return default


def build_evidence_request(bundle_kind, send_source, lab_root, **kwargs):
    """Normalize caller context into an EvidenceRequest dict."""
    anchor_run_id = _safe_str(kwargs.get("anchor_run_id"))
    active_run_id = _safe_str(kwargs.get("active_run_id"))
    if not active_run_id:
        active_run_id = anchor_run_id
    request = {
        "schema_version": EVIDENCE_REQUEST_SCHEMA_VERSION,
        "bundle_kind": _safe_str(bundle_kind),
        "send_source": _safe_str(send_source),
        "lab_root": _safe_str(lab_root),
        "anchor_run_id": anchor_run_id,
        "active_run_id": active_run_id,
        "failed_phase": _safe_str(kwargs.get("failed_phase")),
        "error_code": _safe_str(kwargs.get("error_code")),
        "recommendation_action_kind": _safe_str(kwargs.get("recommendation_action_kind")),
        "operator_surface": _safe_str(kwargs.get("operator_surface")) or "developer_support",
        "include_traceback": bool(kwargs.get("include_traceback")),
        "reason": _safe_str(kwargs.get("reason")),
        "phase_f_report_json_path": _safe_str(kwargs.get("phase_f_report_json_path")),
        "phase_f_report_txt_path": _safe_str(kwargs.get("phase_f_report_txt_path")),
        "phase_f_evidence_index_path": _safe_str(kwargs.get("phase_f_evidence_index_path")),
        "follow_recommendation_now": _safe_str(kwargs.get("follow_recommendation_now")),
        "operator_manual_review_required": bool(kwargs.get("operator_manual_review_required")),
        "reply_required": bool(kwargs.get("reply_required")),
        "evidence_snapshot_mixed_note": _safe_str(kwargs.get("evidence_snapshot_mixed_note")),
    }
    phase_map = kwargs.get("phase_run_id_map")
    if phase_map is None:
        phase_map = kwargs.get("phase_run_ids")
    if isinstance(phase_map, dict):
        clean_map = {}
        for key, value in phase_map.items():
            phase = _safe_str(key).strip().upper()
            rid = _safe_str(value).strip()
            if phase and rid:
                clean_map[phase] = rid
        if clean_map:
            request["phase_run_id_map"] = clean_map
    phase_d_rid = _safe_str(kwargs.get("phase_d_artifact_run_id")).strip()
    if phase_d_rid:
        request["phase_d_artifact_run_id"] = phase_d_rid
    # Caller-only context (not part of stable schema; stripped from audits if needed)
    if "_cloud_health_diagnostics" in kwargs:
        request["_cloud_health_diagnostics"] = kwargs.get("_cloud_health_diagnostics")
    if kwargs.get("_prefetched_evidence_tuples") is not None:
        request["_prefetched_evidence_tuples"] = list(kwargs.get("_prefetched_evidence_tuples") or [])
    for _orch_key in (
        "_orchestrator_result",
        "_orchestrator_payload",
        "_orchestrator_diagnostic_path",
        "_orchestrator_report_path",
    ):
        if _orch_key in kwargs:
            request[_orch_key] = kwargs.get(_orch_key)
    return request


def read_lab_state(lab_root):
    """
    Read diagnostics_state.json and run_cursor.json once.

    Returns dict with keys diagnostics_state, run_cursor (dict or None), and paths
    mapping logical names to absolute paths.
    """
    root = _safe_str(lab_root)
    paths = {
        "diagnostics_state.json": os.path.join(root, "diagnostics_state.json"),
        "run_cursor.json": os.path.join(root, "run_cursor.json"),
    }
    diagnostics_state = _read_json_dict(paths["diagnostics_state.json"])
    run_cursor = _read_json_dict(paths["run_cursor.json"])
    return {
        "diagnostics_state": diagnostics_state,
        "run_cursor": run_cursor,
        "paths": paths,
    }


def resolve_phase_c_summary(lab_root, state, cursor):
    """
    Strict run-aligned Phase C ingest summary resolution.

    If last_phase_c_run_id (from state) is non-empty and
    reports/ingest_write_summary_<run_id>.json is missing, callers must record
    missing_required_evidence — no mtime or latest fallback.

    state/cursor may be None (treated as empty dict for run id lookup).
    """
    root = _safe_str(lab_root)
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    run_id = _safe_str(st.get("last_phase_c_run_id"))
    if not run_id:
        run_id = _safe_str(cr.get("last_phase_c_run_id"))
    expected_name = ""
    expected_path = ""
    if run_id:
        expected_name = "ingest_write_summary_{0}.json".format(run_id)
        expected_path = os.path.join(root, "reports", expected_name)
    summary_obj = None
    exists = False
    if run_id and expected_path and os.path.isfile(expected_path):
        exists = True
        summary_obj = _read_json_dict(expected_path)
    return {
        "run_id": run_id,
        "expected_archive_name": expected_name,
        "expected_path": expected_path,
        "exists": exists,
        "summary": summary_obj,
    }


def _manifest_sha_tokens(state, cursor, summary):
    """Extract comparable Phase C manifest sha tokens from state/cursor/summary."""
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    sm = summary if isinstance(summary, dict) else {}
    out = []
    for src in (st, cr):
        for key in ("last_ingest_manifest_sha256", "last_manifest_sha256", "manifest_sha256"):
            val = _safe_str(src.get(key)).strip()
            if val:
                out.append(val)
    m_sha = _safe_str(sm.get("manifest_sha256")).strip()
    if m_sha:
        out.append(m_sha)
    return out


def _compute_coherence_status(state, cursor, summary_info):
    """If all three manifest sha fields exist and any differ, review_required."""
    if not summary_info.get("exists"):
        return "ready"
    summary = summary_info.get("summary")
    if not isinstance(summary, dict):
        return "ready"
    tokens = _manifest_sha_tokens(state, cursor, summary)
    if len(tokens) < 2:
        return "ready"
    if len(set(tokens)) == 1:
        return "ready"
    return "review_required"


def _phase_c_correlation_body(request, state, cursor, summary_info):
    """Deterministic non-PHI correlation text for Phase C bundle."""
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    lines = [
        "phase_c_bundle_correlation",
        "bundle_kind={0}".format(_safe_str(request.get("bundle_kind"))),
        "send_source={0}".format(_safe_str(request.get("send_source"))),
        "anchor_run_id={0}".format(_safe_str(request.get("anchor_run_id"))),
        "active_run_id={0}".format(_safe_str(request.get("active_run_id"))),
        "failed_phase={0}".format(_safe_str(request.get("failed_phase"))),
        "error_code={0}".format(_safe_str(request.get("error_code"))),
        "last_phase_c_run_id={0}".format(_safe_str(st.get("last_phase_c_run_id"))),
        "last_phase_c_ok={0}".format(st.get("last_phase_c_ok")),
        "last_phase_c_error_code={0}".format(_safe_str(st.get("last_phase_c_error_code"))),
        "last_phase_c_shadow_recovery_status={0}".format(_safe_str(st.get("last_phase_c_shadow_recovery_status"))),
        "last_phase_c_shadow_recovery_report_path={0}".format(_safe_str(st.get("last_phase_c_shadow_recovery_report_path"))),
        "ingest_summary_attached={0}".format("yes" if summary_info.get("exists") else "no"),
        "last_manifest_sha256_state={0}".format(_safe_str(st.get("last_manifest_sha256"))),
        "last_manifest_sha256_cursor={0}".format(_safe_str(cr.get("last_manifest_sha256"))),
    ]
    if isinstance(summary_info.get("summary"), dict):
        sm = summary_info["summary"]
        lines.append("ingest_summary_manifest_sha256={0}".format(_safe_str(sm.get("manifest_sha256"))))
    return "\n".join(lines) + "\n"


ATTACHMENT_STALE_AFTER_SEC = 86400


def _attachment_freshness_for_path(source_path):
    """Classify manifest file attachments with the same 24h stale boundary as bundle meta."""
    path = _safe_str(source_path)
    if not path or not os.path.isfile(path):
        return "current_run"
    try:
        age_sec = int(max(0, int(time.time()) - int(os.path.getmtime(path))))
        if age_sec > ATTACHMENT_STALE_AFTER_SEC:
            return "historical_snapshot"
    except Exception:
        pass
    return "current_run"


def _attachment_dict(archive_name, source_path=None, inline_content=None, required=True, **extra):
    row = {
        "archive_name": archive_name,
        "source_path": source_path or "",
        "inline_content": inline_content,
        "required": required,
        "freshness": extra.get("freshness") or _attachment_freshness_for_path(source_path),
        "scope": extra.get("scope", ""),
        "run_id": extra.get("run_id", ""),
        "source_kind": extra.get("source_kind", ""),
        "missing_reason": extra.get("missing_reason", ""),
        "correlation_note_role": extra.get("correlation_note_role", ""),
    }
    return row


def _manifest_has_archive_name(manifest, archive_name):
    name = _safe_str(archive_name)
    if not name:
        return False
    for row in manifest.get("attachments") or []:
        if isinstance(row, dict) and _safe_str(row.get("archive_name")) == name:
            return True
    return False


def _find_attachment_by_archive_name(manifest, archive_name):
    name = _safe_str(archive_name)
    if not name or not isinstance(manifest, dict):
        return None
    for row in manifest.get("attachments") or []:
        if isinstance(row, dict) and _safe_str(row.get("archive_name")) == name:
            return row
    return None


def add_required_attachment(manifest, archive_name, source_path, scope, run_id):
    """
    Attach file if present; otherwise append missing_required_evidence.
    scope and run_id are plain strings for manifest rows.
    """
    if not isinstance(manifest, dict):
        return
    name = _safe_str(archive_name)
    attachments = manifest.setdefault("attachments", [])
    missing = manifest.setdefault("missing_required_evidence", [])
    path = _safe_str(source_path)
    existing = _find_attachment_by_archive_name(manifest, name)
    if existing is not None:
        existing["required"] = True
        if scope:
            existing["scope"] = scope
        if run_id:
            existing["run_id"] = run_id
        return
    if path and os.path.isfile(path):
        attachments.append(
            _attachment_dict(
                name,
                source_path=path,
                required=True,
                scope=scope,
                run_id=run_id,
                source_kind="file",
            )
        )
        return
    expected_path = path
    missing.append(
        {
            "archive_name": name,
            "expected_path": expected_path,
            "expected_pattern": "",
            "reason_code": "missing_required_file",
        }
    )


def add_optional_attachment(manifest, archive_name, source_path, scope, run_id):
    """Attach when present; never records missing_required_evidence."""
    if not isinstance(manifest, dict):
        return
    name = _safe_str(archive_name)
    if _manifest_has_archive_name(manifest, name):
        return
    path = _safe_str(source_path)
    if not path or not os.path.isfile(path):
        return
    manifest.setdefault("attachments", []).append(
        _attachment_dict(
            name,
            source_path=path,
            required=False,
            scope=scope,
            run_id=run_id,
            source_kind="file",
        )
    )


def add_optional_inline_attachment(manifest, archive_name, inline_content, scope, run_id):
    """Attach caller-provided inline evidence; never records missing evidence."""
    if not isinstance(manifest, dict):
        return
    name = _safe_str(archive_name)
    if not name or _manifest_has_archive_name(manifest, name):
        return
    manifest.setdefault("attachments", []).append(
        _attachment_dict(
            name,
            inline_content=inline_content,
            required=False,
            scope=scope,
            run_id=run_id,
            source_kind="prefetched_inline",
        )
    )


def _local_runtime_latest_path(lab_root, archive_name):
    """Resolve local-runtime latest artifacts; reports/ wins over lab root."""
    root = _safe_str(lab_root)
    name = _safe_str(archive_name)
    if not root or not name:
        return ""
    candidates = (
        os.path.join(root, "reports", name),
        os.path.join(root, name),
    )
    for path in candidates:
        if os.path.isfile(path):
            return path
    return ""


def _append_remittance_parse_yield_attachments(manifest, lab_root):
    """Attach optional remittance parser-yield latest artifacts for local runtime bundles."""
    if not isinstance(manifest, dict):
        return
    json_name = "remittance_parse_yield_latest.json"
    txt_name = "remittance_parse_yield_latest.txt"
    scope = "local_runtime_latest"
    json_path = _local_runtime_latest_path(lab_root, json_name)
    txt_path = _local_runtime_latest_path(lab_root, txt_name)
    if json_path:
        add_optional_attachment(manifest, json_name, json_path, scope, "")
    if txt_path:
        add_optional_attachment(manifest, txt_name, txt_path, scope, "")

    names = []
    for name in (json_name, txt_name):
        if _manifest_has_archive_name(manifest, name):
            names.append(name)
    extra = manifest.setdefault("extra_meta", {})
    extra["remittance_parse_yield_present"] = bool(json_path or txt_path or names)
    extra["remittance_parse_yield_json_attached"] = json_name in names
    extra["remittance_parse_yield_txt_attached"] = txt_name in names
    extra["remittance_parse_yield_attachment_names"] = names
    extra["remittance_parse_yield_scope"] = scope


def _merge_diag_cursor_evidence_path(state, cursor, key):
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    v = _safe_str(st.get(key))
    if not v:
        v = _safe_str(cr.get(key))
    return v


def collect_phase_c_bundle_extra_tuples(lab_root, diagnostics_state=None, run_cursor=None):
    """
    Optional Phase C attachments: stamped pointers preferred over basename-only discovery.
    Returns list of (archive_name, abs_path).
    """
    lab_root = _safe_str(lab_root)
    if not lab_root or not os.path.isdir(lab_root):
        return []
    st = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    cr = run_cursor if isinstance(run_cursor, dict) else {}
    if not st and not cr:
        st = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
        cr = _read_json_dict(os.path.join(lab_root, "run_cursor.json"))
    out = []
    seen = set()

    def add_pair(name, path):
        p = _safe_str(path)
        n = _safe_str(name)
        if not p or not n or n in seen:
            return
        if not os.path.isfile(p):
            return
        out.append((n, p))
        seen.add(n)

    hp = _merge_diag_cursor_evidence_path(st, cr, "last_phase_c_execution_handoff_report_path")
    if hp:
        base = os.path.basename(hp)
        add_pair(base, hp)
        if hp.lower().endswith(".json"):
            tx = hp[:-5] + ".txt"
            add_pair(os.path.basename(tx), tx)

    diag_stamp = _merge_diag_cursor_evidence_path(st, cr, "last_ingest_from_manifest_diag_path")
    if diag_stamp:
        add_pair(os.path.basename(diag_stamp), diag_stamp)
    else:
        add_pair(
            "ingest_from_manifest_diagnostics_latest.json",
            os.path.join(lab_root, "reports", "ingest_from_manifest_diagnostics_latest.json"),
        )

    for base in (
        "ingest_from_manifest_bootstrap_latest.json",
        "ingest_from_manifest_bootstrap_timeline_latest.jsonl",
        "phase_c_current_attempt_latest.json",
        "phase_c_self_heal_status_latest.txt",
    ):
        add_pair(base, os.path.join(lab_root, "reports", base))

    summary_info = resolve_phase_c_summary(lab_root, st, cr)
    if summary_info.get("exists") and summary_info.get("expected_path"):
        exp = _safe_str(summary_info.get("expected_path"))
        an = _safe_str(summary_info.get("expected_archive_name")) or os.path.basename(exp)
        add_pair(an, exp)

    snap_path = _write_support_send_queue_context_snapshot(lab_root)
    if snap_path:
        add_pair(os.path.basename(snap_path), snap_path)

    return out


def _phase_c_mixed_run_scope_note(st, cr):
    active = _merge_diag_cursor_evidence_path(st, cr, "active_run_id")
    completed = _merge_diag_cursor_evidence_path(st, cr, "last_shadow_pipeline_run_id")
    c_run = _merge_diag_cursor_evidence_path(st, cr, "last_phase_c_run_id")
    hp = _merge_diag_cursor_evidence_path(st, cr, "last_phase_c_execution_handoff_report_path")
    hp_rid = ""
    if hp and os.path.isfile(hp):
        doc = _read_json_dict(hp)
        if isinstance(doc, dict):
            hp_rid = _safe_str(doc.get("pipeline_run_id"))
    parts = []
    if active and completed and active != completed:
        parts.append(
            "scope_mixed: active_run_id={0} last_completed_shadow_run_id={1}".format(active, completed)
        )
    if c_run and hp_rid and c_run != hp_rid:
        parts.append("phase_c_ingest_run_id={0} execution_handoff_pipeline_run_id={1}".format(c_run, hp_rid))
    if not parts:
        return ""
    return "; ".join(parts)


def _snapshot_scalar(value, max_len=500):
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return value
    text = _safe_str(value)
    if len(text) > int(max_len):
        return text[:int(max_len)]
    return text


def _snapshot_shallow_dict(src, keys, max_len=500):
    row = {}
    if not isinstance(src, dict):
        return row
    for key in keys:
        if key not in src:
            continue
        val = src.get(key)
        if isinstance(val, dict):
            nested = {}
            for nk in val:
                nv = val.get(nk)
                if isinstance(nv, (dict, list, tuple)):
                    continue
                nested[_safe_str(nk)] = _snapshot_scalar(nv, max_len=max_len)
            row[key] = nested
        elif isinstance(val, list):
            out = []
            for item in val[-5:]:
                if isinstance(item, dict):
                    out.append(_snapshot_shallow_dict(
                        item,
                        ("stage", "at_utc", "elapsed_since_start_sec", "delta_since_prior_stage_sec"),
                        max_len=max_len,
                    ))
                else:
                    out.append(_snapshot_scalar(item, max_len=max_len))
            row[key] = out
        else:
            row[key] = _snapshot_scalar(val, max_len=max_len)
    return row


def _read_post_update_autofollow_lifecycle_context(reports_dir):
    path = os.path.join(_safe_str(reports_dir), "post_update_cloud_autofollow_state.json")
    if not path or not os.path.isfile(path):
        return {}
    doc = _read_json_dict(path)
    if not isinstance(doc, dict):
        return {}
    out = _snapshot_shallow_dict(doc, (
        "status",
        "stage",
        "job_id",
        "installed_version",
        "updated_at_utc",
        "started_at_utc",
        "finished_at_utc",
        "last_reason",
        "phase_c_probe_status",
        "phase_c_probe_reason",
        "phase_c_probe_started_for_version",
        "phase_c_probe_started_at_utc",
        "phase_c_probe_finished_at_utc",
        "post_update_evidence_freshness_status",
        "post_update_fresh_shadow_run_id",
        "post_update_fresh_machine_app_version",
        "post_update_freshness_blocking_reason",
        "post_update_fresh_pipeline_status",
        "post_update_fresh_pipeline_started_for_version",
        "post_update_fresh_pipeline_started_at_utc",
        "post_update_fresh_pipeline_finished_at_utc",
    ))
    if out:
        out["state_file"] = os.path.basename(path)
    return out


def _write_support_send_queue_context_snapshot(lab_root):
    """Write reports/support_send_bundle_queue_context_latest.json with trimmed job lifecycle fields."""
    lab_root = _safe_str(lab_root)
    if not lab_root:
        return ""
    reports_dir = os.path.join(lab_root, "reports")
    out_path = os.path.join(reports_dir, "support_send_bundle_queue_context_latest.json")
    try:
        from MediCafe.support_send_jobs import SupportSendJobManager
    except Exception:
        return ""
    repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    try:
        mgr = SupportSendJobManager(repo_root, lab_root)
        jobs = mgr.list_jobs(limit=15)
        qstate = mgr._read_queue_state()
    except Exception:
        return ""
    trim_keys = (
        "job_id",
        "status",
        "source",
        "send_type",
        "created_at_utc",
        "started_at_utc",
        "finished_at_utc",
        "heartbeat_at_utc",
        "queue_wait_sec",
        "queued_before",
        "queued_after",
        "worker_mode",
        "worker_mode_policy",
        "worker_mode_policy_reason",
        "queue_policy_snapshot",
        "worker_started_at_utc",
        "anchor_run_id",
        "layer1_current_blocker",
        "context_run_id",
        "issue_code",
        "dedup_key",
        "dedup_key_components",
        "progress_stage",
        "progress_events",
        "bundle_kind",
        "priority",
        "operator_execution_mode",
        "installed_version",
        "recommendation_action_kind",
        "policy_decision",
        "policy_reason",
        "single_flight_policy_decision",
        "delivery_state",
        "delivery_issue_code",
        "auth_taxonomy",
        "self_observation_status",
        "result_ok",
        "result_message",
        "pipeline_defer_count",
        "pipeline_defer_started_at_utc",
        "pipeline_defer_last_at_utc",
        "pipeline_defer_policy_decision",
        "shadow_pipeline_lock_pid",
        "shadow_pipeline_lock_heartbeat_at_utc",
        "shadow_pipeline_lock_path",
        "delivery_diagnostics_resolved_path",
    )
    rows = []
    for job in jobs:
        if not isinstance(job, dict):
            continue
        row = _snapshot_shallow_dict(job, trim_keys)
        post_update_state = _snapshot_shallow_dict(
            job.get("post_update_autofollow_lab_state"),
            (
                "lab_status",
                "lab_stage",
                "lab_job_id",
                "lab_last_reason",
                "installed_version",
                "lab_state_updated_at_utc",
                "post_update_evidence_freshness_status",
                "post_update_fresh_shadow_run_id",
                "post_update_fresh_machine_app_version",
                "post_update_freshness_blocking_reason",
                "post_update_fresh_pipeline_status",
            ),
        )
        if post_update_state:
            row["post_update_autofollow_lifecycle"] = post_update_state
        rows.append(row)
    payload = {
        "schema_version": 2,
        "generated_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "queue_state": qstate if isinstance(qstate, dict) else {},
        "post_update_autofollow_lifecycle": _read_post_update_autofollow_lifecycle_context(reports_dir),
        "recent_jobs": rows,
    }
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        return ""
    tmp = out_path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=True, indent=2, sort_keys=True)
            handle.write("\n")
        try:
            if os.path.isfile(out_path):
                os.remove(out_path)
        except Exception:
            pass
        os.rename(tmp, out_path)
    except Exception:
        try:
            if os.path.isfile(tmp):
                os.remove(tmp)
        except Exception:
            pass
        return ""
    return out_path if os.path.isfile(out_path) else ""


def _append_phase_c_bundle_extras(manifest, lab_root, st, cr):
    """Attach common Phase C telemetry + support-send queue snapshot when files exist."""
    if not isinstance(manifest, dict):
        return
    ev_mode = _safe_str(manifest.get("scope", {}).get("evidence_mode"))
    if ev_mode in (MODE_LIVE_STATUS, MODE_INCOHERENT_STATE):
        return
    note = _phase_c_mixed_run_scope_note(st, cr)
    if note:
        prev = _safe_str(manifest.get("scope", {}).get("phase_c_artifact_run_mix_note"))
        merged = note if not prev else "{0}; {1}".format(prev, note)
        manifest.setdefault("scope", {})["phase_c_artifact_run_mix_note"] = merged
        manifest.setdefault("validation", {}).setdefault("warnings", []).append(
            "phase_c_scope:{0}".format(merged[:500])
        )
    anchor = _safe_str(st.get("last_shadow_pipeline_run_id") or cr.get("last_shadow_pipeline_run_id"))
    for archive_name, pth in collect_phase_c_bundle_extra_tuples(lab_root, st, cr):
        if _manifest_has_archive_name(manifest, archive_name):
            continue
        add_optional_attachment(manifest, archive_name, pth, "phase_c_bundle_extra", anchor)


def _append_live_status_attachments(manifest, lab_root, lab, mode_info):
    """Attach only current status files; no stale completed-run phase artifacts."""
    if not isinstance(manifest, dict):
        return
    reports_dir = os.path.join(_safe_str(lab_root), "reports")
    st = lab.get("diagnostics_state") if isinstance(lab, dict) else {}
    cr = lab.get("run_cursor") if isinstance(lab, dict) else {}
    if not isinstance(st, dict):
        st = {}
    if not isinstance(cr, dict):
        cr = {}
    paths = lab.get("paths") if isinstance(lab, dict) else {}
    if not isinstance(paths, dict):
        paths = {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "live_status",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "live_status",
        "",
    )
    support_queue_snapshot = _write_support_send_queue_context_snapshot(lab_root)
    for base in (
            "report_delivery_status.txt",
            "phase_c_current_attempt_latest.json"):
        pth = os.path.join(reports_dir, base)
        if os.path.isfile(pth):
            add_optional_attachment(manifest, base, pth, "live_status", "")
    if support_queue_snapshot and os.path.isfile(support_queue_snapshot):
        add_optional_attachment(
            manifest,
            "support_send_bundle_queue_context_latest.json",
            support_queue_snapshot,
            "live_status",
            "",
        )
    _append_live_phase_c_current_attempt_telemetry(manifest, lab_root, st, cr)
    if not _manifest_has_archive_name(manifest, "evidence_mode_report.txt"):
        manifest.setdefault("attachments", []).append(
            _attachment_dict(
                "evidence_mode_report.txt",
                inline_content=evidence_mode_report_text(mode_info),
                required=True,
                scope="evidence_mode",
                source_kind="evidence_mode_report",
            )
        )


def _append_live_phase_c_current_attempt_telemetry(manifest, lab_root, state, cursor):
    """Attach non-decisive Phase C attempt telemetry referenced by live status."""
    if not isinstance(manifest, dict):
        return
    root = _safe_str(lab_root)
    reports_dir = os.path.join(root, "reports")
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}

    def add_live_attempt_file(archive_name, path, scope):
        if not archive_name or _manifest_has_archive_name(manifest, archive_name):
            return
        if path and os.path.isfile(path):
            add_optional_attachment(manifest, archive_name, path, scope, "")

    current_attempt_path = os.path.join(reports_dir, "phase_c_current_attempt_latest.json")
    current_attempt = _read_json_dict(current_attempt_path)
    if not isinstance(current_attempt, dict):
        current_attempt = {}

    for key, archive_name, scope in (
            (
                "bootstrap_path",
                "ingest_from_manifest_bootstrap_latest.json",
                "phase_c_current_attempt_bootstrap",
            ),
            (
                "bootstrap_timeline_path",
                "ingest_from_manifest_bootstrap_timeline_latest.jsonl",
                "phase_c_current_attempt_bootstrap_timeline",
            )):
        pth = _safe_str(current_attempt.get(key))
        # Accept only paths explicitly referenced by the current-attempt file and
        # only for known non-PHI telemetry basenames. Do not promote bare latest
        # aliases into live status evidence.
        if pth and os.path.basename(pth) != archive_name:
            pth = ""
        add_live_attempt_file(archive_name, pth, scope)

    handoff_path = _safe_str(
        current_attempt.get("handoff_report_path")
        or st.get("last_phase_c_execution_handoff_report_path")
        or cr.get("last_phase_c_execution_handoff_report_path")
    )
    handoff_seen = bool(current_attempt.get("handoff_report_seen") or current_attempt.get("handoff_report_path"))
    if handoff_seen and handoff_path and os.path.isfile(handoff_path):
        add_live_attempt_file(
            os.path.basename(handoff_path),
            handoff_path,
            "phase_c_current_attempt_handoff",
        )
        if handoff_path.lower().endswith(".json"):
            txt_path = handoff_path[:-5] + ".txt"
            add_live_attempt_file(
                os.path.basename(txt_path),
                txt_path,
                "phase_c_current_attempt_handoff",
            )


def _append_incoherent_state_attachment(manifest, mode_info):
    if not isinstance(manifest, dict):
        return
    if _manifest_has_archive_name(manifest, "evidence_incoherent_state.txt"):
        return
    manifest.setdefault("attachments", []).append(
        _attachment_dict(
            "evidence_incoherent_state.txt",
            inline_content=evidence_mode_report_text(mode_info),
            required=True,
            scope="evidence_mode",
            source_kind="incoherent_state_report",
        )
    )


def _phase_c_rules_apply(request, diagnostics_state):
    diag = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    failed = _safe_str(request.get("failed_phase")).strip().upper()
    err = _safe_str(request.get("error_code"))
    if failed == "C":
        return True
    if err.startswith("PHASE_C_"):
        return True
    if diag.get("last_phase_c_ok") is False:
        return True
    return False


def _try_shadow_lock_redacted(lab_root):
    try:
        from lab_lock import read_lab_lock_diagnostic_metadata
    except Exception:
        return None
    try:
        stub = read_lab_lock_diagnostic_metadata(lab_root)
        if isinstance(stub, dict) and stub:
            return stub
    except Exception:
        pass
    return None


PHASE_F_BC_CORRELATION_ARCHIVE_NAME = "phase_f_bc_correlation_note.txt"


def collect_shadow_evidence_index_referenced_paths(index_path):
    """
    Parse shadow_evidence_index JSON (artifact_files[] with path/exists).

    Algorithm: read JSON dict; prefer list ``artifact_files``; each item may be
    dict with ``path`` (absolute or relative). Skip missing paths, __MISSING__,
    exists=False, non-files. Returns [(archive_basename, abs_path), ...].
    """
    out = []
    path = _safe_str(index_path)
    if not path or not os.path.isfile(path):
        return out
    payload = _read_json_dict(path)
    if not isinstance(payload, dict):
        return out
    rows = payload.get("artifact_files")
    if not isinstance(rows, list):
        rows = payload.get("files")
    if not isinstance(rows, list):
        return out
    base_dir = os.path.dirname(os.path.abspath(path))
    for item in rows:
        if not isinstance(item, dict):
            continue
        if item.get("exists") is False:
            continue
        raw = _safe_str(item.get("path", "")).strip()
        if not raw or raw == "__MISSING__":
            continue
        if not os.path.isabs(raw):
            cand = os.path.normpath(os.path.join(base_dir, raw))
        else:
            cand = raw
        if not os.path.isfile(cand):
            continue
        out.append((os.path.basename(cand), cand))
    return out


def _normalize_prefetched_tuples(raw):
    """Normalize caller-supplied (archive_name, path_or_inline) pairs."""
    out = []
    if not raw:
        return out
    try:
        iterable = list(raw)
    except Exception:
        return out
    for item in iterable:
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            out.append((_safe_str(item[0]), item[1]))
        elif isinstance(item, dict):
            a = item.get("archive_name")
            p = item.get("source_path")
            if a and p:
                out.append((_safe_str(a), p))
            elif a and "inline_content" in item:
                out.append((_safe_str(a), item.get("inline_content")))
    return out


def _layer1_debug_effective_for_request(request):
    """Best-effort gate: attach Layer1 debug only when current/effective."""
    req = request if isinstance(request, dict) else {}
    lab_root = _safe_str(req.get("lab_root"))
    if not lab_root:
        return False
    reports_dir = os.path.join(lab_root, "reports")
    diag = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json")) or {}
    try:
        from MediCafe.layer1_readiness_model import build_layer1_readiness_model
        from MediCafe.layer1_readiness_model import STATUS_READY_TO_EVALUATE
        from MediCafe.layer1_readiness_model import STATUS_EVALUATED_BLOCKED
        from MediCafe.layer1_readiness_model import STATUS_EVALUATED_OK
    except Exception:
        return False
    anchor = _safe_str(req.get("anchor_run_id"))
    pack_context = {"anchor_run_id": anchor, "pack_scope": "completed_run"} if anchor else {}
    model = build_layer1_readiness_model(lab_root, reports_dir, diag, pack_context=pack_context)
    if not isinstance(model, dict):
        return False
    if bool(model.get("historical_layer1_debug_only")):
        return False
    return _safe_str(model.get("layer1_readiness_status")) in (
        STATUS_READY_TO_EVALUATE, STATUS_EVALUATED_BLOCKED, STATUS_EVALUATED_OK
    )


def _merge_prefetched_into_manifest(manifest, request, scope_tag, run_id_token):
    rid = _safe_str(run_id_token)
    layer1_effective = None
    for archive_name, pth in _normalize_prefetched_tuples(request.get("_prefetched_evidence_tuples")):
        if not _manifest_has_archive_name(manifest, archive_name):
            path = _safe_str(pth)
            if path and os.path.isfile(path):
                scoped = _safe_str(scope_tag)
                if archive_name.startswith("layer1_join_debug_"):
                    scoped = "historical_layer1_context"
                    if rid and (
                            archive_name.startswith("layer1_join_debug_pack_{0}".format(rid)) or
                            archive_name.startswith("layer1_join_debug_summary_{0}".format(rid)) or
                            archive_name.startswith("layer1_join_debug_samples_{0}".format(rid))):
                        scoped = "current_layer1_context"
                        if layer1_effective is None:
                            layer1_effective = _layer1_debug_effective_for_request(request)
                        if not layer1_effective:
                            continue
                    else:
                        continue
                add_optional_attachment(manifest, archive_name, path, scoped, rid)
            elif pth is not None:
                add_optional_inline_attachment(manifest, archive_name, pth, scope_tag, rid)


def _apply_prefetched_phase_letter_evidence(manifest, lab_root, lab, request):
    """phase_b_evidence / phase_c_evidence / phase_d_evidence / phase_e_evidence (manual menu sends)."""
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    _merge_prefetched_into_manifest(
        manifest, request, "manual_phase_letter_prefetch", request.get("anchor_run_id")
    )


def _apply_config_write_contention_bundle(manifest, lab_root, lab, request):
    """config_write_contention: optional lab state plus telemetry files from caller."""
    paths = lab.get("paths") or {}
    add_optional_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "config_write_context",
        "",
    )
    add_optional_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "config_write_context",
        "",
    )
    _merge_prefetched_into_manifest(manifest, request, "config_write_telemetry", "")


def _apply_error_report_lab_context(manifest, lab_root, lab, request):
    """Generic error_report: optional lab diagnostics when lab_root is valid."""
    paths = lab.get("paths") or {}
    add_optional_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "error_report_context",
        "",
    )
    add_optional_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "error_report_context",
        "",
    )


def _apply_orchestrator_failure_bundle(manifest, lab_root, lab, request):
    """Shadow orchestrator auto-report: lab context plus structured result/payload."""
    paths = lab.get("paths") or {}
    add_optional_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "orchestrator_failure",
        "",
    )
    add_optional_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "orchestrator_failure",
        "",
    )
    tracker = os.path.join(_safe_str(lab_root), "cloud_health_tracker.json")
    if os.path.isfile(tracker):
        add_optional_attachment(
            manifest,
            "cloud_health_tracker.json",
            tracker,
            "orchestrator_failure",
            "",
        )
    res = request.get("_orchestrator_result")
    if isinstance(res, dict) and res:
        if not _manifest_has_archive_name(manifest, "orchestrator_result.json"):
            manifest["attachments"].append(
                _attachment_dict(
                    "orchestrator_result.json",
                    inline_content=res,
                    required=True,
                    scope="orchestrator_failure",
                    source_kind="orchestrator_result",
                )
            )
    pay = request.get("_orchestrator_payload")
    if isinstance(pay, dict) and pay:
        if not _manifest_has_archive_name(manifest, "orchestrator_payload.json"):
            manifest["attachments"].append(
                _attachment_dict(
                    "orchestrator_payload.json",
                    inline_content=pay,
                    required=False,
                    scope="orchestrator_failure",
                    source_kind="orchestrator_payload",
                )
            )
    dp = _safe_str(request.get("_orchestrator_diagnostic_path"))
    if dp and os.path.isfile(dp):
        add_optional_attachment(
            manifest,
            os.path.basename(dp),
            dp,
            "orchestrator_failure",
            "",
        )
    rp = _safe_str(request.get("_orchestrator_report_path"))
    if rp and os.path.isfile(rp):
        add_optional_attachment(
            manifest,
            os.path.basename(rp),
            rp,
            "orchestrator_failure",
            "",
        )


def _reports_dir(lab_root):
    return os.path.join(_safe_str(lab_root), "reports")


def _phase_run_ids_from_state_cursor(state, cursor):
    """Phase run ids from state/cursor: explicit last_phase_*_run_id beats phase maps; state before cursor."""
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    out = {}
    for phase, field in (
            ("B", "last_phase_b_run_id"),
            ("C", "last_phase_c_run_id"),
            ("D", "last_phase_d_run_id"),
            ("E", "last_phase_e_run_id"),
            ("F", "last_phase_f_run_id")):
        for source in (st, cr):
            rid = _safe_str(source.get(field)).strip()
            if rid and not out.get(phase):
                out[phase] = rid
    for source in (st, cr):
        phase_map = source.get("last_shadow_pipeline_phase_run_ids")
        if isinstance(phase_map, dict):
            for key, value in phase_map.items():
                phase = _safe_str(key).strip().upper()
                rid = _safe_str(value).strip()
                if phase and rid and not out.get(phase):
                    out[phase] = rid
    return out


def _phase_run_ids_from_request_state_cursor(request, state, cursor):
    """
    Resolve phase ids for an evidence request.

    Caller-supplied phase maps come from the anchored run artifact snapshot and
    must beat mutable lab state. Lab state may already point at a later
    remediation/verification phase run, which is useful live context but not
    valid as anchored bundle evidence.
    """
    req = request if isinstance(request, dict) else {}
    out = {}
    raw_map = req.get("phase_run_id_map")
    if isinstance(raw_map, dict):
        for key, value in raw_map.items():
            phase = _safe_str(key).strip().upper()
            rid = _safe_str(value).strip()
            if phase and rid and not out.get(phase):
                out[phase] = rid
    phase_d_rid = _safe_str(req.get("phase_d_artifact_run_id")).strip()
    if phase_d_rid:
        out["D"] = phase_d_rid
    fallback = _phase_run_ids_from_state_cursor(state, cursor)
    for key, value in fallback.items():
        if key and value and not out.get(key):
            out[key] = value
    return out


def _phase_artifact_run_id(state, cursor, anchor_run_id, phase, request=None):
    """Resolve artifact id for a phase when bundle anchor is the shadow run id."""
    anchor = _safe_str(anchor_run_id).strip()
    phase_key = _safe_str(phase).strip().upper()
    phase_ids = _phase_run_ids_from_request_state_cursor(request, state, cursor)
    rid = _safe_str(phase_ids.get(phase_key)).strip()
    return rid or anchor


def _dict_has_key_prefix(value, prefix):
    """Recursively detect diagnostic keys while staying Python 3.4 compatible."""
    pfx = _safe_str(prefix)
    if isinstance(value, dict):
        for key, child in value.items():
            if _safe_str(key).startswith(pfx):
                return True
            if _dict_has_key_prefix(child, pfx):
                return True
    elif isinstance(value, list):
        for child in value:
            if _dict_has_key_prefix(child, pfx):
                return True
    return False


def _jsonl_has_key_prefix(path, prefix, max_rows):
    pfx = _safe_str(prefix)
    if not path or not os.path.isfile(path):
        return False
    count = 0
    try:
        with open(path, "r", encoding="utf-8") as handle:
            for line in handle:
                if count >= max_rows:
                    break
                text = line.strip()
                if not text:
                    continue
                count += 1
                try:
                    row = json.loads(text)
                except Exception:
                    continue
                if _dict_has_key_prefix(row, pfx):
                    return True
    except Exception:
        return False
    return False


def _classify_dat_payer_resolution_evidence(summary_path, reject_samples_path):
    """Classify whether DAT QA evidence includes the embedded payer-resolution runbook diagnostics."""
    summary_exists = bool(summary_path and os.path.isfile(summary_path))
    samples_exists = bool(reject_samples_path and os.path.isfile(reject_samples_path))
    if not summary_exists and not samples_exists:
        return "missing_phase_d_evidence"
    summary = _read_json_dict(summary_path) if summary_exists else None
    summary_has = _dict_has_key_prefix(summary, "dat_payer_resolution_") or _dict_has_key_prefix(
        summary, "payer_resolution_context_counts")
    samples_has = _jsonl_has_key_prefix(reject_samples_path, "dat_payer_resolution_", 40)
    if summary_has or samples_has:
        return "current_resolution_diagnostics_present"
    return "stale_pre_resolution_diagnostics"


def _phase_d_dat_counts_from_summary(summary):
    data = summary if isinstance(summary, dict) else {}
    tel = data.get("dat_telemetry") if isinstance(data.get("dat_telemetry"), dict) else {}
    return {
        "dat_selected_count": _safe_int(
            tel.get("dat_selected_count", data.get("dat_selected_count", data.get("phase_d_dat_selected_count", 0))), 0),
        "dat_qa_pass_count": _safe_int(
            tel.get("dat_qa_pass_count", data.get("dat_qa_pass_count", data.get("phase_d_dat_qa_pass_count", 0))), 0),
        "dat_qa_reject_count": _safe_int(
            tel.get("dat_qa_reject_count", data.get("dat_qa_reject_count", data.get("phase_d_dat_qa_reject_count", 0))), 0),
        "dat_canonical_record_count": _safe_int(
            tel.get("dat_canonical_record_count", data.get("dat_canonical_record_count", data.get("phase_d_dat_canonical_record_count", 0))), 0),
    }


def _classify_dat_qa_full_block_context(state, cursor, phase_d_rid, qa_summary_path, rec_kind):
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    summary = _read_json_dict(qa_summary_path) or {}
    counts = _phase_d_dat_counts_from_summary(summary)
    rem = st.get("phase_d_remediation") if isinstance(st.get("phase_d_remediation"), dict) else {}
    if not rem and isinstance(cr.get("phase_d_remediation"), dict):
        rem = cr.get("phase_d_remediation")
    status = "current_or_unresolved"
    reason = ""
    if counts.get("dat_qa_pass_count", 0) > 0 or counts.get("dat_canonical_record_count", 0) > 0:
        status = "superseded_by_fresh_phase_d_context"
        reason = "fresh_phase_d_pass_or_canonical_movement"
    elif _safe_str(rem.get("status")).strip().lower() == "resolved":
        rem_rid = _safe_str(rem.get("context_run_id") or rem.get("remediation_context_run_id"))
        if not rem_rid or rem_rid == _safe_str(phase_d_rid):
            status = "superseded_by_fresh_phase_d_context"
            reason = "phase_d_remediation_resolved"
    elif rec_kind == "phase_d_dat_verification_rerun":
        status = "historical_pre_resolution_context"
        reason = "stale_pre_resolution_diagnostics"
    return status, reason, counts


def _apply_dat_qa_full_block_contract(manifest, lab_root, request, state=None, cursor=None):
    """Phase D DAT QA full-block required artifacts, with phase-aware artifact ids."""
    anchor_rid = _safe_str(request.get("anchor_run_id"))
    if not anchor_rid:
        return
    phase_d_rid = _phase_artifact_run_id(state, cursor, anchor_rid, "D", request=request)
    rep = _reports_dir(lab_root)
    qa_summary_path = os.path.join(rep, "qa_canonical_summary_{0}.json".format(phase_d_rid))
    qa_reject_path = os.path.join(rep, "qa_reject_samples_{0}.jsonl".format(phase_d_rid))
    layer1_summary_path = os.path.join(rep, "layer1_join_debug_summary_{0}.json".format(phase_d_rid))
    layer1_pack_path = os.path.join(rep, "layer1_join_debug_pack_{0}.txt".format(phase_d_rid))
    specs = [
        ("artifact_triage_pack_{0}.txt".format(anchor_rid), os.path.join(rep, "artifact_triage_pack_{0}.txt".format(anchor_rid)), anchor_rid),
        ("qa_canonical_summary_{0}.json".format(phase_d_rid), qa_summary_path, phase_d_rid),
        ("qa_reject_samples_{0}.jsonl".format(phase_d_rid), qa_reject_path, phase_d_rid),
        ("layer1_join_debug_summary_{0}.json".format(phase_d_rid), layer1_summary_path, phase_d_rid),
        ("layer1_join_debug_pack_{0}.txt".format(phase_d_rid), layer1_pack_path, phase_d_rid),
        ("run_artifact_index_{0}.txt".format(anchor_rid), os.path.join(rep, "run_artifact_index_{0}.txt".format(anchor_rid)), anchor_rid),
    ]
    for archive_name, fullpath, row_rid in specs:
        add_required_attachment(manifest, archive_name, fullpath, "dat_qa_full_block", row_rid)
    scope = manifest.setdefault("scope", {})
    scope["phase_d_artifact_run_id"] = phase_d_rid
    scope["phase_run_id_map"] = _phase_run_ids_from_request_state_cursor(request, state, cursor)
    status = _classify_dat_payer_resolution_evidence(qa_summary_path, qa_reject_path)
    scope["dat_payer_resolution_evidence_status"] = status
    rec_kind = _safe_str(request.get("recommendation_action_kind"))
    context_status, context_reason, dat_counts = _classify_dat_qa_full_block_context(
        state, cursor, phase_d_rid, qa_summary_path, rec_kind)
    scope["dat_qa_full_block_context_status"] = context_status
    scope["dat_qa_full_block_context_reason"] = context_reason
    scope["phase_d_dat_selected_count"] = dat_counts.get("dat_selected_count", 0)
    scope["phase_d_dat_qa_pass_count"] = dat_counts.get("dat_qa_pass_count", 0)
    scope["phase_d_dat_qa_reject_count"] = dat_counts.get("dat_qa_reject_count", 0)
    scope["phase_d_dat_canonical_record_count"] = dat_counts.get("dat_canonical_record_count", 0)
    if status == "stale_pre_resolution_diagnostics":
        manifest.setdefault("validation", {}).setdefault("warnings", []).append(
            "dat_payer_resolution_diagnostics_stale_pre_resolution"
        )
    if context_status == "superseded_by_fresh_phase_d_context":
        manifest.setdefault("validation", {}).setdefault("warnings", []).append(
            "dat_qa_full_block_context_superseded_by_fresh_phase_d"
        )
    oc = manifest.setdefault("operator_contract", {})
    oc["operator_manual_review_required"] = False
    oc["reply_required"] = False
    if _safe_str(request.get("follow_recommendation_now")):
        oc["follow_recommendation_now"] = _safe_str(request.get("follow_recommendation_now"))
    rec_lines = [
        "recommended_action_kind={0}".format(rec_kind),
        "follow_recommendation_now={0}".format(_safe_str(request.get("follow_recommendation_now"))),
        "operator_manual_review_required={0}".format(request.get("operator_manual_review_required")),
        "reply_required={0}".format(request.get("reply_required")),
        "anchor_run_id={0}".format(anchor_rid),
        "phase_d_artifact_run_id={0}".format(phase_d_rid),
        "dat_payer_resolution_evidence_status={0}".format(status),
        "dat_qa_full_block_context_status={0}".format(context_status),
        "dat_qa_full_block_context_reason={0}".format(context_reason or "-"),
        "phase_d_dat_counts=selected:{0}, qa_pass:{1}, qa_reject:{2}, canonical:{3}".format(
            dat_counts.get("dat_selected_count", 0),
            dat_counts.get("dat_qa_pass_count", 0),
            dat_counts.get("dat_qa_reject_count", 0),
            dat_counts.get("dat_canonical_record_count", 0)),
    ]
    if context_status == "superseded_by_fresh_phase_d_context":
        rec_lines.append(
            "scope_note=Anchored shadow full-block counters are historical/superseded; use the fresh Phase D context as current."
        )
    manifest["attachments"].append(
        _attachment_dict(
            "dat_qa_full_block_recommendation_lines.txt",
            inline_content="\n".join(rec_lines) + "\n",
            required=True,
            scope="dat_qa_full_block",
            source_kind="recommendation_note",
        )
    )


def _phase_f_evidence_correlation_body(request, state, cursor, summary_info_phase_c):
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    fp = _safe_str(request.get("failed_phase")).strip().upper()
    shadow_run_id = _safe_str(request.get("anchor_run_id"))
    phase_b_run = ""
    phase_c_run = ""
    try:
        prids = st.get("last_shadow_pipeline_phase_run_ids")
        if isinstance(prids, dict):
            phase_b_run = _safe_str(prids.get("B", ""))
            phase_c_run = _safe_str(prids.get("C", ""))
    except Exception:
        phase_b_run = ""
        phase_c_run = ""
    if not phase_c_run:
        phase_c_run = _safe_str(st.get("last_phase_c_run_id"))
    phase_c_attach = "no"
    sm = summary_info_phase_c if isinstance(summary_info_phase_c, dict) else {}
    if sm.get("exists"):
        phase_c_attach = "yes"
    manifest_sha = ""
    if isinstance(sm.get("summary"), dict):
        manifest_sha = _safe_str(sm["summary"].get("manifest_sha256"))
    lines = [
        "phase_f_evidence_correlation",
        "shadow_run_id={0}".format(shadow_run_id or "-"),
        "failed_phase={0}".format(fp or "-"),
        "phase_b_manifest_run_id={0}".format(phase_b_run or "-"),
        "phase_c_run_id={0}".format(phase_c_run or "-"),
        "phase_c_failure_summary_attached={0}".format(phase_c_attach),
        "manifest_sha256={0}".format(manifest_sha or "-"),
    ]
    if shadow_run_id and phase_c_run and shadow_run_id != phase_c_run:
        lines.append(
            "note=Phase F run id differs from Phase C run id; ingest summary may belong to a parallel pipeline attempt."
        )
    return "\n".join(lines) + "\n"


def _apply_phase_f_evidence_bundle(manifest, lab_root, lab, request, state, cursor):
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    rep = _reports_dir(lab_root)
    anchor = _safe_str(request.get("anchor_run_id"))
    jpath = _safe_str(request.get("phase_f_report_json_path"))
    tpath = _safe_str(request.get("phase_f_report_txt_path"))
    ipath = _safe_str(request.get("phase_f_evidence_index_path"))
    if not jpath and anchor:
        cand = os.path.join(rep, "shadow_run_report_{0}.json".format(anchor))
        if os.path.isfile(cand):
            jpath = cand
    if not tpath and anchor:
        cand = os.path.join(rep, "shadow_run_report_{0}.txt".format(anchor))
        if os.path.isfile(cand):
            tpath = cand
    if not ipath and anchor:
        cand = os.path.join(rep, "shadow_evidence_index_{0}.json".format(anchor))
        if os.path.isfile(cand):
            ipath = cand
    add_required_attachment(manifest, "shadow_run_report.json", jpath, "phase_f_report", anchor)
    add_required_attachment(manifest, "shadow_run_report.txt", tpath, "phase_f_report", anchor)
    add_required_attachment(manifest, "shadow_evidence_index.json", ipath, "phase_f_index", anchor)
    for archive_name, src in collect_shadow_evidence_index_referenced_paths(ipath):
        add_optional_attachment(manifest, archive_name, src, "phase_f_index_ref", anchor)
    summary_info_pc = resolve_phase_c_summary(lab_root, state, cursor)
    corr = _phase_f_evidence_correlation_body(request, state, cursor, summary_info_pc)
    if not _manifest_has_archive_name(manifest, PHASE_F_BC_CORRELATION_ARCHIVE_NAME):
        manifest["attachments"].append(
            _attachment_dict(
                PHASE_F_BC_CORRELATION_ARCHIVE_NAME,
                inline_content=corr,
                required=True,
                scope="phase_f_bc",
                source_kind="correlation_note",
                correlation_note_role="phase_f_bc",
            )
        )
    _merge_prefetched_into_manifest(manifest, request, "phase_f_manual_prefetch", request.get("anchor_run_id"))


def _apply_cloud_health_escalation_bundle(manifest, lab_root, lab, request):
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    diag = request.get("_cloud_health_diagnostics")
    diag_arg = diag if isinstance(diag, dict) else None
    try:
        from MediCafe.cloud_readiness import collect_cloud_health_phase_evidence_tuples

        for archive_name, pth in collect_cloud_health_phase_evidence_tuples(lab_root, diag_arg):
            add_optional_attachment(
                manifest,
                archive_name,
                pth,
                "cloud_health_phase",
                "",
            )
    except Exception:
        pass
    manifest.setdefault("scope", {})["coherence_status"] = "review_required"


def _apply_system_health_pack_bundle(manifest, lab_root, lab, request):
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    note = _safe_str(request.get("evidence_snapshot_mixed_note"))
    if note:
        manifest["scope"]["coherence_status"] = "review_required"
        manifest["validation"]["warnings"].append("mixed_snapshot:{0}".format(note))


def _apply_run_evidence_bundle_base(manifest, lab_root, lab, request):
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )


def _append_phase_d_developer_unblock_attachments(manifest, lab_root, state, cursor, request):
    if evidence_report_entries_from_summary is None:
        return
    anchor = _safe_str(manifest.get("scope", {}).get("anchor_run_id") or request.get("anchor_run_id")).strip()
    phase_d_run_id = _phase_artifact_run_id(state, cursor, anchor, "D", request=request)
    if not phase_d_run_id:
        return
    summary_path = os.path.join(_reports_dir(lab_root), "qa_canonical_summary_{0}.json".format(phase_d_run_id))
    summary = _read_json_dict(summary_path)
    if not isinstance(summary, dict):
        return
    for entry in evidence_report_entries_from_summary(summary):
        if bool(entry.get("contains_pii", False)):
            continue
        if not bool(entry.get("safe_for_bundle", True)):
            continue
        archive_name = _safe_str(entry.get("archive_name")).strip() or os.path.basename(_safe_str(entry.get("path")))
        source_path = _safe_str(entry.get("path")).strip()
        if bool(entry.get("required", True)):
            add_required_attachment(
                manifest,
                archive_name,
                source_path,
                "phase_d_developer_unblock",
                phase_d_run_id,
            )
        else:
            add_optional_attachment(
                manifest,
                archive_name,
                source_path,
                "phase_d_developer_unblock",
                phase_d_run_id,
            )


def _apply_pipeline_failure_report_bundle(manifest, lab_root, lab, request):
    """Pipeline failure report: lab state plus caller-produced report attachments."""
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    _merge_prefetched_into_manifest(
        manifest,
        request,
        "pipeline_failure_prefetch",
        request.get("anchor_run_id"),
    )


def _apply_phase_c_failure_contract(manifest, lab_root, lab, request, state, cursor):
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    ev_mode = _safe_str(manifest.get("scope", {}).get("evidence_mode"))
    if ev_mode == MODE_LIVE_STATUS:
        return
    mode_info = manifest.get("evidence_mode")
    if not isinstance(mode_info, dict):
        mode_info = {}
    phase_artifacts_allowed = not (
        ev_mode == MODE_INCOHERENT_STATE
        and _safe_str(mode_info.get("blocking_reason")) == "phase_c_handoff_run_id_mismatch"
    )
    paths = lab.get("paths") or {}
    add_required_attachment(
        manifest,
        "diagnostics_state.json",
        paths.get("diagnostics_state.json", ""),
        "lab_diagnostics",
        "",
    )
    add_required_attachment(
        manifest,
        "run_cursor.json",
        paths.get("run_cursor.json", ""),
        "lab_cursor",
        "",
    )
    summary_info = resolve_phase_c_summary(lab_root, st, cr)
    rid = summary_info.get("run_id") or ""
    if rid:
        if summary_info.get("exists"):
            add_required_attachment(
                manifest,
                summary_info.get("expected_archive_name") or "",
                summary_info.get("expected_path") or "",
                "phase_c_run",
                rid,
            )
        else:
            manifest.setdefault("missing_required_evidence", []).append(
                {
                    "archive_name": summary_info.get("expected_archive_name") or "",
                    "expected_path": summary_info.get("expected_path") or "",
                    "expected_pattern": "",
                    "reason_code": "phase_c_summary_missing_strict",
                }
            )
    recovery_path = _safe_str(
        st.get("last_phase_c_shadow_recovery_report_path")
        or cr.get("last_phase_c_shadow_recovery_report_path")
    )
    if phase_artifacts_allowed and recovery_path and os.path.isfile(recovery_path):
        add_optional_attachment(
            manifest,
            os.path.basename(recovery_path),
            recovery_path,
            "phase_c_shadow_recovery",
            _safe_str(st.get("last_shadow_pipeline_run_id") or request.get("anchor_run_id")),
        )
        if recovery_path.lower().endswith(".json"):
            recovery_txt = recovery_path[:-5] + ".txt"
            if os.path.isfile(recovery_txt) and not _manifest_has_archive_name(
                manifest, os.path.basename(recovery_txt)
            ):
                add_optional_attachment(
                    manifest,
                    os.path.basename(recovery_txt),
                    recovery_txt,
                    "phase_c_shadow_recovery",
                    _safe_str(st.get("last_shadow_pipeline_run_id") or request.get("anchor_run_id")),
                )
    exec_handoff_path = _safe_str(
        st.get("last_phase_c_execution_handoff_report_path")
        or cr.get("last_phase_c_execution_handoff_report_path")
    )
    anchor_rid = _safe_str(st.get("last_shadow_pipeline_run_id") or request.get("anchor_run_id"))
    if phase_artifacts_allowed and exec_handoff_path and os.path.isfile(exec_handoff_path):
        add_optional_attachment(
            manifest,
            os.path.basename(exec_handoff_path),
            exec_handoff_path,
            "phase_c_execution_handoff",
            anchor_rid,
        )
        if exec_handoff_path.endswith(".json"):
            txt_handoff = exec_handoff_path[:-5] + ".txt"
            if os.path.isfile(txt_handoff):
                add_optional_attachment(
                    manifest,
                    os.path.basename(txt_handoff),
                    txt_handoff,
                    "phase_c_execution_handoff",
                    anchor_rid,
                )
    bootstrap_path = os.path.join(lab_root, "reports", "ingest_from_manifest_bootstrap_latest.json")
    if phase_artifacts_allowed and os.path.isfile(bootstrap_path) and not _manifest_has_archive_name(
        manifest, "ingest_from_manifest_bootstrap_latest.json"
    ):
        add_optional_attachment(
            manifest,
            "ingest_from_manifest_bootstrap_latest.json",
            bootstrap_path,
            "phase_c_ingest_bootstrap",
            anchor_rid,
        )
    bootstrap_timeline_path = os.path.join(lab_root, "reports", "ingest_from_manifest_bootstrap_timeline_latest.jsonl")
    if phase_artifacts_allowed and os.path.isfile(bootstrap_timeline_path) and not _manifest_has_archive_name(
        manifest, "ingest_from_manifest_bootstrap_timeline_latest.jsonl"
    ):
        add_optional_attachment(
            manifest,
            "ingest_from_manifest_bootstrap_timeline_latest.jsonl",
            bootstrap_timeline_path,
            "phase_c_ingest_bootstrap_timeline",
            anchor_rid,
        )
    current_attempt_path = os.path.join(lab_root, "reports", "phase_c_current_attempt_latest.json")
    if os.path.isfile(current_attempt_path) and not _manifest_has_archive_name(
        manifest, "phase_c_current_attempt_latest.json"
    ):
        add_optional_attachment(
            manifest,
            "phase_c_current_attempt_latest.json",
            current_attempt_path,
            "phase_c_current_attempt",
            anchor_rid,
        )
    for smoke_name, smoke_scope in (
        ("xp_phase_smoke_latest.json", "xp_phase_smoke"),
        ("xp_phase_smoke_latest.txt", "xp_phase_smoke"),
    ):
        smoke_path = os.path.join(lab_root, "reports", smoke_name)
        if phase_artifacts_allowed and os.path.isfile(smoke_path) and not _manifest_has_archive_name(manifest, smoke_name):
            add_optional_attachment(
                manifest,
                smoke_name,
                smoke_path,
                smoke_scope,
                anchor_rid,
            )
    lock_stub = _try_shadow_lock_redacted(lab_root)
    if lock_stub is not None and not _manifest_has_archive_name(manifest, "shadow_lock_redacted.json"):
        manifest.setdefault("attachments", []).append(
            _attachment_dict(
                "shadow_lock_redacted.json",
                inline_content=lock_stub,
                required=False,
                scope="lab_lock",
                source_kind="lab_lock_redacted",
            )
        )
    self_heal_path = os.path.join(lab_root, "reports", "phase_c_self_heal_status_latest.txt")
    if phase_artifacts_allowed and os.path.isfile(self_heal_path) and not _manifest_has_archive_name(manifest, "phase_c_self_heal_status_latest.txt"):
        add_optional_attachment(
            manifest,
            "phase_c_self_heal_status_latest.txt",
            self_heal_path,
            "phase_c_self_heal_status",
            _safe_str(st.get("last_shadow_pipeline_run_id") or request.get("anchor_run_id")),
        )
    stderr_tail_path = os.path.join(lab_root, "reports", "phase_c_ingest_stderr_tail_latest.txt")
    if phase_artifacts_allowed and os.path.isfile(stderr_tail_path) and not _manifest_has_archive_name(
        manifest, "phase_c_ingest_stderr_tail_latest.txt"
    ):
        add_optional_attachment(
            manifest,
            "phase_c_ingest_stderr_tail_latest.txt",
            stderr_tail_path,
            "phase_c_ingest_stderr",
            anchor_rid,
        )
    diag_stamp = _merge_diag_cursor_evidence_path(st, cr, "last_ingest_from_manifest_diag_path")
    ingest_diag_path = diag_stamp if diag_stamp and os.path.isfile(diag_stamp) else os.path.join(
        lab_root, "reports", "ingest_from_manifest_diagnostics_latest.json"
    )
    if phase_artifacts_allowed and os.path.isfile(ingest_diag_path) and not _manifest_has_archive_name(
        manifest, os.path.basename(ingest_diag_path)
    ):
        add_optional_attachment(
            manifest,
            os.path.basename(ingest_diag_path),
            ingest_diag_path,
            "phase_c_ingest_from_manifest_diag",
            anchor_rid,
        )
    try:
        from MediCafe.phase_c_db_health_probe import write_phase_c_db_health_probe_latest

        probe_path = write_phase_c_db_health_probe_latest(lab_root, st)
        if phase_artifacts_allowed and probe_path and os.path.isfile(probe_path) and not _manifest_has_archive_name(
            manifest, "phase_c_db_health_probe_latest.json"
        ):
            add_optional_attachment(
                manifest,
                "phase_c_db_health_probe_latest.json",
                probe_path,
                "phase_c_db_health_probe",
                anchor_rid,
            )
    except Exception:
        pass
    if not _manifest_has_archive_name(manifest, PHASE_C_CORRELATION_ARCHIVE_NAME):
        corr_text = _phase_c_correlation_body(request, st, cr, summary_info)
        manifest["attachments"].append(
            _attachment_dict(
                PHASE_C_CORRELATION_ARCHIVE_NAME,
                inline_content=corr_text,
                required=True,
                scope="phase_c_bundle",
                source_kind="correlation_note",
                correlation_note_role="phase_c_bundle",
            )
        )
    coh = _compute_coherence_status(st, cr, summary_info)
    prev = _safe_str(manifest.get("scope", {}).get("coherence_status"))
    if coh == "review_required" or prev == "review_required":
        manifest.setdefault("scope", {})["coherence_status"] = "review_required"
    else:
        manifest.setdefault("scope", {})["coherence_status"] = coh


def _merge_operator_contract_from_request(manifest, request):
    oc = manifest.setdefault("operator_contract", {})
    if request.get("operator_manual_review_required"):
        oc["operator_manual_review_required"] = True
    if request.get("reply_required"):
        oc["reply_required"] = True
    fn = _safe_str(request.get("follow_recommendation_now"))
    if fn:
        oc["follow_recommendation_now"] = fn


def _apply_layer1_runbook_scope(manifest, lab_root, state, cursor):
    """Stamp shared Layer 1 runbook decision metadata into evidence scope."""
    if not isinstance(manifest, dict):
        return
    scope = manifest.setdefault("scope", {})
    try:
        from MediCafe.layer1_readiness_model import build_layer1_readiness_model
        from MediCafe.layer1_runbook_model import build_layer1_runbook_model
        from MediCafe.layer1_runbook_model import shallow_layer1_runbook_meta
    except Exception:
        return
    try:
        reports_dir = _reports_dir(lab_root)
        pack_context = {
            "anchor_run_id": _safe_str(scope.get("anchor_run_id")),
            "pack_scope": "completed_run",
        }
        l1_model = build_layer1_readiness_model(
            lab_root,
            reports_dir,
            state if isinstance(state, dict) else {},
            pack_context=pack_context,
        )
        rb_model = build_layer1_runbook_model(
            l1_model,
            state if isinstance(state, dict) else {},
            cursor if isinstance(cursor, dict) else {},
            scope,
            app_version="",
        )
        rb_meta = shallow_layer1_runbook_meta(rb_model)
        for key, value in rb_meta.items():
            scope[key] = value
    except Exception:
        return


def _finalize_manifest_validation(manifest):
    missing = manifest.get("missing_required_evidence") or []
    invalid_lab = any(
        isinstance(m, dict) and m.get("reason_code") == "invalid_lab_root" for m in missing
    )
    named_missing = any(
        isinstance(m, dict) and _safe_str(m.get("archive_name")) for m in missing
    )
    if invalid_lab:
        manifest.setdefault("validation", {})["attachment_contract_status"] = "fail"
        manifest["validation"]["ok_to_send"] = False
    elif named_missing:
        manifest.setdefault("validation", {})["attachment_contract_status"] = "degraded"
    else:
        manifest.setdefault("validation", {})["attachment_contract_status"] = "pass"


def resolve_evidence_manifest(request):
    """
    Resolve attachments and validation for an EvidenceRequest.

    Dispatch (see architecture plan A.4): DAT QA full-block first, then
    bundle_kind rules, then Phase C failure union when applicable.
    """
    req = request if isinstance(request, dict) else {}
    lab_root = _safe_str(req.get("lab_root"))
    req_public = {}
    for k, v in req.items():
        if not k.startswith("_"):
            try:
                req_public[k] = v
            except Exception:
                pass
    lab = read_lab_state(lab_root)
    state = lab.get("diagnostics_state")
    cursor = lab.get("run_cursor")
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    mode_info = resolve_evidence_mode(
        lab_root,
        bundle_kind=_safe_str(req.get("bundle_kind")),
        requested_run_id=_safe_str(req.get("anchor_run_id")),
        send_source=_safe_str(req.get("send_source")),
        diagnostics_state=st,
        run_cursor=cr,
    )
    if not isinstance(mode_info, dict):
        mode_info = {}
    evidence_mode = _safe_str(mode_info.get("mode")) or MODE_RUN_EVIDENCE

    manifest = {
        "schema_version": EVIDENCE_MANIFEST_SCHEMA_VERSION,
        "request": dict(req_public),
        "evidence_mode": dict(mode_info),
        "extra_meta": {},
        "attachments": [],
        "missing_required_evidence": [],
        "scope": {
            "bundle_kind": _safe_str(req.get("bundle_kind")),
            "scope_kind": _safe_str(req.get("bundle_kind")),
            "anchor_run_id": _safe_str(req.get("anchor_run_id")),
            "artifact_run_id": _safe_str(req.get("active_run_id")),
            "phase_artifact_scope": "run_aligned",
            "coherence_status": _safe_str(mode_info.get("coherence_status")) or "ready",
            "evidence_mode": evidence_mode,
            "current_evidence_mode": evidence_mode,
            "selected_run_id": _safe_str(mode_info.get("selected_run_id")),
            "active_run_id": _safe_str(mode_info.get("active_run_id")),
            "last_completed_run_id": _safe_str(mode_info.get("last_completed_run_id")),
            "blocking_reason": _safe_str(mode_info.get("blocking_reason")),
            "decisive_run_evidence_current": bool(mode_info.get("decisive_run_evidence_current")),
            "current_decision": _safe_str(mode_info.get("current_decision")),
        },
        "operator_contract": {
            "operator_manual_review_required": False,
            "reply_required": False,
            "follow_recommendation_now": "",
        },
        "validation": {
            "ok_to_send": True,
            "warnings": [],
            "errors": [],
            "attachment_contract_status": "",
        },
    }
    req_phase_map = req.get("phase_run_id_map")
    if isinstance(req_phase_map, dict):
        clean_scope_map = {}
        for key, value in req_phase_map.items():
            phase = _safe_str(key).strip().upper()
            rid = _safe_str(value).strip()
            if phase and rid:
                clean_scope_map[phase] = rid
        if clean_scope_map:
            manifest["scope"]["phase_run_id_map"] = dict(clean_scope_map)
            manifest["scope"]["phase_run_ids"] = dict(clean_scope_map)
    req_phase_d = _safe_str(req.get("phase_d_artifact_run_id")).strip()
    if req_phase_d:
        manifest["scope"]["phase_d_artifact_run_id"] = req_phase_d

    if not lab_root or not os.path.isdir(lab_root):
        manifest["missing_required_evidence"].append(
            {
                "archive_name": "",
                "expected_path": lab_root,
                "expected_pattern": "",
                "reason_code": "invalid_lab_root",
            }
        )
        manifest["validation"]["attachment_contract_status"] = "fail"
        manifest["validation"]["ok_to_send"] = False
        return manifest

    rec_kind = _safe_str(req.get("recommendation_action_kind"))
    if rec_kind in ("review_dat_qa_full_block", "phase_d_dat_verification_rerun"):
        _apply_dat_qa_full_block_contract(manifest, lab_root, req, st, cr)

    bk = _safe_str(req.get("bundle_kind"))
    if evidence_mode == MODE_LIVE_STATUS and bk in (
            "system_health_pack",
            "cloud_health_escalation",
            "run_evidence_bundle",
            "phase_f_evidence"):
        _append_live_status_attachments(manifest, lab_root, lab, mode_info)
    elif evidence_mode == MODE_INCOHERENT_STATE and bk in (
            "system_health_pack",
            "cloud_health_escalation",
            "run_evidence_bundle",
            "phase_f_evidence"):
        _append_live_status_attachments(manifest, lab_root, lab, mode_info)
    elif bk in ("phase_b_evidence", "phase_c_evidence", "phase_d_evidence", "phase_e_evidence"):
        _apply_prefetched_phase_letter_evidence(manifest, lab_root, lab, req)
    elif bk == "config_write_contention":
        _apply_config_write_contention_bundle(manifest, lab_root, lab, req)
    elif bk == "error_report":
        _apply_error_report_lab_context(manifest, lab_root, lab, req)
    elif bk == "orchestrator_failure":
        _apply_orchestrator_failure_bundle(manifest, lab_root, lab, req)
    elif bk == "phase_f_evidence":
        _apply_phase_f_evidence_bundle(manifest, lab_root, lab, req, st, cr)
    elif bk == "cloud_health_escalation":
        _apply_cloud_health_escalation_bundle(manifest, lab_root, lab, req)
    elif bk == "system_health_pack":
        _apply_system_health_pack_bundle(manifest, lab_root, lab, req)
    elif bk == "run_evidence_bundle":
        _apply_run_evidence_bundle_base(manifest, lab_root, lab, req)
    elif bk == "pipeline_failure_report":
        _apply_pipeline_failure_report_bundle(manifest, lab_root, lab, req)
    elif bk == "phase_c_unresolvable":
        _apply_pipeline_failure_report_bundle(manifest, lab_root, lab, req)

    if bk in ("system_health_pack", "cloud_health_escalation", "run_evidence_bundle"):
        _append_phase_d_developer_unblock_attachments(manifest, lab_root, st, cr, req)

    if bk in ("system_health_pack", "run_evidence_bundle"):
        _append_remittance_parse_yield_attachments(manifest, lab_root)

    _mode_gated_bundles = (
        "system_health_pack",
        "cloud_health_escalation",
        "run_evidence_bundle",
        "phase_f_evidence",
    )
    if (
            (evidence_mode == MODE_RUN_EVIDENCE or bk not in _mode_gated_bundles)
            and _phase_c_rules_apply(req, st)):
        _apply_phase_c_failure_contract(manifest, lab_root, lab, req, st, cr)

    if evidence_mode == MODE_INCOHERENT_STATE:
        _append_incoherent_state_attachment(manifest, mode_info)

    bk_done = _safe_str(req.get("bundle_kind"))
    if evidence_mode == MODE_RUN_EVIDENCE and bk_done in (
            "system_health_pack",
            "cloud_health_escalation",
            "pipeline_failure_report",
            "phase_f_evidence",
            "phase_c_unresolvable",
    ):
        _append_phase_c_bundle_extras(manifest, lab_root, st, cr)

    _merge_operator_contract_from_request(manifest, req)
    _apply_layer1_runbook_scope(manifest, lab_root, st, cr)

    _finalize_manifest_validation(manifest)
    return manifest


def manifest_to_extra_files(manifest):
    """Convert manifest attachment dicts to (archive_name, path_or_unicode) tuples."""
    out = []
    if not isinstance(manifest, dict):
        return out
    for row in manifest.get("attachments") or []:
        if not isinstance(row, dict):
            continue
        name = _safe_str(row.get("archive_name"))
        if not name:
            continue
        path = _safe_str(row.get("source_path"))
        inline = row.get("inline_content")
        if path and os.path.isfile(path):
            out.append((name, path))
        elif isinstance(inline, dict):
            out.append((name, inline))
        elif inline is not None:
            if isinstance(inline, bytes):
                try:
                    inline = inline.decode("utf-8")
                except Exception:
                    inline = ""
            out.append((name, inline))
    return out


def manifest_to_extra_meta(manifest):
    """
    Flatten manifest fields for support bundle meta.json.

    Includes attachment_contract_status, coherence_status, missing_required_evidence,
    evidence_manifest_schema_version, and optional embedded evidence_request.
    """
    out = {}
    if not isinstance(manifest, dict):
        return out
    req = manifest.get("request")
    if isinstance(req, dict):
        out["evidence_request"] = dict(req)
        if req.get("bundle_kind"):
            out["bundle_kind"] = _safe_str(req.get("bundle_kind"))
    out["evidence_manifest_schema_version"] = manifest.get("schema_version")
    mode_info = manifest.get("evidence_mode")
    if isinstance(mode_info, dict):
        out["evidence_mode"] = _safe_str(mode_info.get("mode"))
        out["current_evidence_mode"] = _safe_str(mode_info.get("mode"))
        out["decisive_run_evidence_current"] = bool(mode_info.get("decisive_run_evidence_current"))
        out["current_decision"] = _safe_str(mode_info.get("current_decision"))
        out["evidence_mode_blocking_reason"] = _safe_str(mode_info.get("blocking_reason"))
    missing = manifest.get("missing_required_evidence")
    if isinstance(missing, list):
        out["missing_required_evidence"] = list(missing)
    else:
        out["missing_required_evidence"] = []
    scope = manifest.get("scope")
    coh = "ready"
    if isinstance(scope, dict):
        coh = _safe_str(scope.get("coherence_status")) or "ready"
    out["coherence_status"] = coh
    val = manifest.get("validation")
    acs = "pass"
    if isinstance(val, dict) and val.get("attachment_contract_status"):
        acs = _safe_str(val.get("attachment_contract_status"))
    elif out["missing_required_evidence"]:
        acs = "degraded"
    out["attachment_contract_status"] = acs
    oc = manifest.get("operator_contract")
    if isinstance(oc, dict):
        out["operator_contract"] = dict(oc)
    sc = manifest.get("scope")
    if isinstance(sc, dict):
        out["evidence_scope"] = dict(sc)
    extra = manifest.get("extra_meta")
    if isinstance(extra, dict):
        for key, value in extra.items():
            if isinstance(key, str):
                out[key] = value
    return out


def merge_extra_files(primary, secondary):
    """
    Concatenate primary then secondary, dedupe by archive_name keeping first.

    Manifest-derived tuples should be passed as primary so contract paths win.
    """
    seen = set()
    out = []
    for seq in (primary, secondary):
        for item in seq or []:
            try:
                name = _safe_str(item[0])
            except Exception:
                continue
            if not name or name in seen:
                continue
            seen.add(name)
            out.append((item[0], item[1]))
    return out


def try_resolve_error_report_manifest(send_source="generic_error_bundle"):
    """
    Resolve an error_report manifest when MEDICAFE_LAB_DIR points at a lab tree.

    Returns None when lab is unknown or resolution fails (callers send without manifest).
    """
    lab_root = _safe_str(os.environ.get("MEDICAFE_LAB_DIR", "")).strip()
    if not lab_root or not os.path.isdir(lab_root):
        return None
    try:
        req = build_evidence_request(
            "error_report",
            _safe_str(send_source) or "generic_error_bundle",
            lab_root,
        )
        return resolve_evidence_manifest(req)
    except Exception:
        return None


def manifest_enqueue_snapshot(manifest):
    """
    Trim resolved manifest for support_send_jobs JSON (no large inline bodies).

    Preserves request/scope/validation/missing entries; summarizes attachments.
    """
    if not isinstance(manifest, dict):
        return {}
    atts = []
    for row in manifest.get("attachments") or []:
        if not isinstance(row, dict):
            continue
        entry = {
            "archive_name": _safe_str(row.get("archive_name")),
            "required": bool(row.get("required")),
            "freshness": _safe_str(row.get("freshness")),
            "scope": _safe_str(row.get("scope")),
            "source_kind": _safe_str(row.get("source_kind")),
        }
        path = _safe_str(row.get("source_path"))
        if path:
            entry["source_path_tail"] = os.path.basename(path)
        inline = row.get("inline_content")
        if inline is not None:
            entry["has_inline_content"] = True
            if isinstance(inline, str):
                entry["inline_len"] = len(inline)
            elif isinstance(inline, dict):
                entry["inline_len"] = len(json.dumps(inline, ensure_ascii=True))
        atts.append(entry)
    req = manifest.get("request")
    scope = manifest.get("scope")
    val = manifest.get("validation")
    oc = manifest.get("operator_contract")
    miss = manifest.get("missing_required_evidence")
    return {
        "schema_version": manifest.get("schema_version"),
        "request": dict(req) if isinstance(req, dict) else {},
        "scope": dict(scope) if isinstance(scope, dict) else {},
        "validation": dict(val) if isinstance(val, dict) else {},
        "missing_required_evidence": list(miss) if isinstance(miss, list) else [],
        "operator_contract": dict(oc) if isinstance(oc, dict) else {},
        "attachments_summary": atts,
    }


def operator_evidence_contract_preview_lines(lab_root, recommendation):
    """
    Compact resolver preview lines for operator runbooks (system health / run evidence).
    """
    lines = []
    root = _safe_str(lab_root).strip()
    if not root or not os.path.isdir(root):
        return lines
    rec = recommendation if isinstance(recommendation, dict) else {}
    rrk = _safe_str(rec.get("recommended_report_kind"))
    if rrk == "system_health_pack":
        bk = "system_health_pack"
    else:
        bk = "run_evidence_bundle"
    anchor = _safe_str(rec.get("recommendation_anchor_run_id"))
    live = _safe_str(rec.get("recommendation_live_run_id")) or anchor
    try:
        req = build_evidence_request(
            bk,
            "operator_ui_preview",
            root,
            anchor_run_id=anchor,
            active_run_id=live,
            recommendation_action_kind=_safe_str(rec.get("recommended_action_kind")),
        )
        man = resolve_evidence_manifest(req)
    except Exception:
        return lines
    val = man.get("validation") if isinstance(man.get("validation"), dict) else {}
    acs = _safe_str(val.get("attachment_contract_status")) or "-"
    scope = man.get("scope") if isinstance(man.get("scope"), dict) else {}
    coh = _safe_str(scope.get("coherence_status")) or "-"
    miss = man.get("missing_required_evidence")
    miss_n = len(miss) if isinstance(miss, list) else 0
    lines.append("Evidence contract preview (resolver; bundle_kind={0}):".format(bk))
    lines.append(" - attachment_contract_status={0}".format(acs))
    lines.append(" - coherence_status={0}".format(coh))
    lines.append(" - missing_required_evidence_count={0}".format(miss_n))
    return lines
