"""
Small local indexing helpers shared by XP-compatible production paths.

The helpers in this module are intentionally stdlib-only and conservative:
callers may treat every return value as disposable optimization state.
"""
from __future__ import print_function

import hashlib
import os


def path_key(path):
    """Return a stable, case-normalized absolute path key."""
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(str(path or ""))))
    except Exception:
        return str(path or "").strip().lower()


def file_signature(path):
    """Return a small file identity tuple, or None when the file is unavailable."""
    try:
        st = os.stat(path)
        return (int(getattr(st, "st_size", 0) or 0), float(getattr(st, "st_mtime", 0) or 0))
    except Exception:
        return None


def stream_sha256(path, chunk_size=65536):
    """Compute SHA-256 without reading the whole file into memory."""
    try:
        chunk_n = int(chunk_size or 65536)
    except Exception:
        chunk_n = 65536
    if chunk_n <= 0:
        chunk_n = 65536
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(chunk_n)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _pair_sort_value(row):
    if isinstance(row, dict):
        for key in ("sort_key", "timestamp", "mtime", "value"):
            if key in row:
                return row.get(key)
        return None
    if isinstance(row, (list, tuple)) and row:
        return row[-1]
    return row


def pair_by_next_greater(left_rows, right_rows):
    """
    Pair each sorted left row with the first unused sorted right row whose
    comparison value is greater. Returns [(left_row, right_row_or_None), ...].
    """
    out = []
    right_index = 0
    rights = list(right_rows or [])
    for left in left_rows or []:
        left_value = _pair_sort_value(left)
        chosen = None
        while right_index < len(rights):
            right = rights[right_index]
            right_value = _pair_sort_value(right)
            right_index += 1
            try:
                if right_value > left_value:
                    chosen = right
                    break
            except Exception:
                continue
        out.append((left, chosen))
    return out


def list_report_files(reports_dir):
    """Return one reusable listing of files under a reports directory."""
    rows = []
    if not reports_dir or not os.path.isdir(reports_dir):
        return rows
    try:
        names = os.listdir(reports_dir)
    except (IOError, OSError):
        return rows
    for name in names:
        path = os.path.join(reports_dir, name)
        if not os.path.isfile(path):
            continue
        try:
            mtime = os.path.getmtime(path)
        except (IOError, OSError, ValueError):
            mtime = 0
        rows.append({"name": name, "path": path, "mtime": mtime})
    rows.sort(key=lambda row: row.get("name", ""))
    return rows
