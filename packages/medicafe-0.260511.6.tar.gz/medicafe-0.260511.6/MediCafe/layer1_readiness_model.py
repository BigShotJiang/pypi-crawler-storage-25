# -*- coding: utf-8 -*-
"""
Layer 1 join readiness: upstream gate detection for operator-facing packs.

Computes a single dict from diagnostics_state plus phase B/C/D/F artifacts
(pack anchor or run snapshot). No imports from cloud_readiness* to avoid cycles.

Operator contract (what every pack should make obvious)
--------------------------------------------------------
* **layer1_readiness_status** — ``not_reached`` | ``ready_to_evaluate`` |
  ``evaluated_blocked`` | ``evaluated_ok``.
  ``evaluated_ok`` means the evaluator ran for the active Phase D run; it does
  not by itself mean strict DAT is usable.
* **layer1_data_status** - ``unknown`` | ``no_dat_selected`` |
  ``strict_dat_blocked`` | ``relaxed_dat_overlap_only`` |
  ``strict_dat_integrated``. Review this and the strict/relaxed DAT counters
  before treating DAT as integrated.
* **layer1_current_blocker** — stable machine code when ``not_reached`` or
  blocked (see ``LAYER1_BLOCKER_*`` constants); empty when none.
* **layer1_blocked_at_phase** — ``B`` | ``C`` | ``D`` | ``layer1`` | empty.
* **historical_layer1_debug_only** — True when a Layer 1 debug summary exists
  but its ``run_id`` does not match the active Phase D context (do not treat as
  current evidence).
* **phase_c_handoff_freshness** — ``phase_c_handoff_current`` |
  ``phase_c_handoff_stale_for_active_run`` | ``phase_c_handoff_stale_after_deploy`` |
  ``phase_c_handoff_missing`` (execution-handoff JSON vs active run, B/C SHAs,
  ingest script fingerprint). Stale values block Layer 1 until a fresh shadow run.
* **phase_c_handoff_comparison_run_id** — run id used for handoff comparison:
  ``active_run_id`` when set, otherwise ``last_shadow_pipeline_run_id`` (completed
  runs often clear the active id).
* **ingest_bootstrap_latest_present** / **ingest_finish_diagnostics_latest_present** —
  bootstrap sentinel vs finish diagnostics (separate artifacts; see pack lines).
* **layer1_operator_runbook** — optional list of strings: embedded steps when
  blocked at Phase C (manifest pending vs ingest failure). Rendered after the
  checklist in ``format_layer1_readiness_lines``. Automated execution + bundle:
  ``python -m MediCafe.layer1_phase_c_runbook_helper`` (see
  ``MediCafe/layer1_phase_c_runbook_helper.py``).
* **layer1_operator_runbook_checklist** — optional list of ``{label, status,
  detail}`` with ``[OK]`` / ``[WARN]`` / ``[FAIL]`` / ``[OPEN]`` tokens derived
  from diagnostics and ingest summary when blocked at Phase C (snapshot at pack
  build time). Per-step automation outcomes live in telemetry
  ``automation_runbook_checklist_lines`` (see ``layer1_phase_c_runbook_helper``).

Surfaces (must stay aligned)
----------------------------
* System Health Pack text: ``Layer 1 Readiness:`` before **Unified DB Readiness**.
* Artifact triage pack and run artifact index: same block near the top.
* Support bundle ``meta.json``: shallow keys via ``shallow_layer1_readiness_meta``
  (merged in ``send_latest_system_health_pack`` / ``send_latest_run_evidence_bundle``;
  contract: send-path tests in ``TestSystemHealthPackWiring`` and ``TestRunCentricArtifactTools``).

Definition of done (regression)
-------------------------------
From repo root (see also ``docs/TESTING_GUIDE.md``, ``AGENTS.md``, and ``README.md``):

- ``python3 -m pytest tests/test_cloud_readiness_artifacts.py::TestLayer1ReadinessModel tests/test_cloud_readiness_artifacts.py::TestLayer1ReadinessSurfacesAndContract tests/test_cloud_readiness_artifacts.py::TestSystemHealthPackWiring::test_send_latest_system_health_pack_extra_meta_merges_layer1_readiness_shallow_keys tests/test_cloud_readiness_artifacts.py::TestRunCentricArtifactTools::test_send_latest_run_evidence_bundle_extra_meta_merges_layer1_readiness_shallow_keys tests/test_cloud_readiness_recommendations.py -q --timeout=120``
- ``python3 -m py_compile MediCafe/layer1_readiness_model.py MediCafe/cloud_readiness_recommendations.py MediCafe/cloud_readiness_artifact_tools.py``

Changes to blocker waterfall, pack section order, ``meta.json`` keys, or
recommendation override rules must update these tests and ``AGENTS.md``.
"""
from __future__ import print_function

import hashlib
import os

try:
    from MediCafe.local_index_utils import list_report_files
except Exception:
    def list_report_files(reports_dir):
        rows = []
        try:
            names = os.listdir(reports_dir)
        except (OSError, IOError, TypeError):
            return rows
        for name in names:
            path = os.path.join(reports_dir, name)
            if not os.path.isfile(path):
                continue
            try:
                mtime = os.path.getmtime(path)
            except (OSError, IOError, ValueError):
                mtime = 0.0
            rows.append({"name": name, "path": path, "mtime": mtime})
        rows.sort(key=lambda row: row.get("name", ""))
        return rows

# Blocker codes (stable string API)
LAYER1_BLOCKER_PHASE_B_DISCOVERY_FAILED = "phase_b_discovery_failed"
LAYER1_BLOCKER_PHASE_B_SUMMARY_MISSING = "phase_b_summary_missing"
LAYER1_BLOCKER_PHASE_C_SHADOW_RECOVERY_DB_LOCKED = "phase_c_shadow_recovery_db_locked"
LAYER1_BLOCKER_PHASE_C_SHADOW_RECOVERY_FAILED = "phase_c_shadow_recovery_failed"
LAYER1_BLOCKER_PHASE_C_INGEST_FAILED = "phase_c_ingest_failed"
LAYER1_BLOCKER_PHASE_C_MANIFEST_NOT_INGESTED = "phase_c_manifest_not_ingested"
LAYER1_BLOCKER_MISSING_CURRENT_PHASE_D_SUMMARY = "missing_current_phase_d_summary"
LAYER1_BLOCKER_PHASE_D_ZERO_SELECTION = "phase_d_zero_selection"
LAYER1_BLOCKER_DAT_ZERO_SELECTED = "dat_zero_selected"
LAYER1_BLOCKER_LAYER1_EVAL_BLOCKED = "layer1_eval_blocked"
LAYER1_BLOCKER_PHASE_C_HANDOFF_STALE = "phase_c_handoff_stale_evidence"
LAYER1_BLOCKER_DAT_INTEGRATION_BLOCKED = "dat_integration_blocked"
LAYER1_BLOCKER_INVALID_EXTERNAL_PATIENT_ID = "invalid_external_patient_id"

STATUS_NOT_REACHED = "not_reached"
STATUS_READY_TO_EVALUATE = "ready_to_evaluate"
STATUS_EVALUATED_BLOCKED = "evaluated_blocked"
STATUS_EVALUATED_OK = "evaluated_ok"

DATA_STATUS_UNKNOWN = "unknown"
DATA_STATUS_NO_DAT_SELECTED = "no_dat_selected"
DATA_STATUS_STRICT_DAT_BLOCKED = "strict_dat_blocked"
DATA_STATUS_RELAXED_DAT_OVERLAP_ONLY = "relaxed_dat_overlap_only"
DATA_STATUS_STRICT_DAT_INTEGRATED = "strict_dat_integrated"

DATA_QUALITY_STATUS_BLOCKED = "blocked"
DATA_QUALITY_STATUS_WARNING = "warning"
DATA_QUALITY_STATUS_READY = "ready"
DATA_QUALITY_STATUS_UNKNOWN = "unknown"

_PHASE_C_BOOTSTRAP_BLOCKER_ENTRYPOINT_MISSING = "phase_c_script_entrypoint_not_observed"
_PHASE_C_BOOTSTRAP_BLOCKER_NO_FINISH_DIAG = "phase_c_script_entered_but_no_finish_diag"
_PHASE_C_BOOTSTRAP_BLOCKER_FINISH_INCOHERENT = "phase_c_finish_incoherent"

# Phase C execution-handoff evidence freshness (stable API for packs + support meta)
PHASE_C_HANDOFF_FRESHNESS_CURRENT = "phase_c_handoff_current"
PHASE_C_HANDOFF_FRESHNESS_STALE_ACTIVE_RUN = "phase_c_handoff_stale_for_active_run"
PHASE_C_HANDOFF_FRESHNESS_STALE_AFTER_DEPLOY = "phase_c_handoff_stale_after_deploy"
PHASE_C_HANDOFF_FRESHNESS_MISSING = "phase_c_handoff_missing"

# Embedded operator runbooks (System Health Pack / Layer 1 block). Plain language; XP ships this file.
LAYER1_OPERATOR_RUNBOOK_PHASE_C_MANIFEST_PENDING = (
    "Confirm Phase B finished and `last_manifest_sha256` in diagnostics matches the latest discovery.",
    "Let the shadow pipeline run Phase C ingest for that manifest, or rerun the pipeline once if it stopped mid-run.",
    "If shadow recovery is in progress, wait for `last_phase_c_shadow_recovery_status` to complete before expecting ingest.",
    "After ingest, verify `last_ingest_manifest_sha256` equals `last_manifest_sha256` and `last_phase_c_ok` is true.",
    "Defer DAT/CSV join diagnosis until Phase C succeeds for the current manifest.",
)

# Checklist status tokens (ASCII for XP / log viewers)
RUNBOOK_CHK_OK = "[OK]"
RUNBOOK_CHK_WARN = "[WARN]"
RUNBOOK_CHK_FAIL = "[FAIL]"
RUNBOOK_CHK_OPEN = "[OPEN]"

LAYER1_OPERATOR_RUNBOOK_PHASE_C_INGEST_FAILURE = (
    "Open `reports/ingest_write_summary_<last_phase_c_run_id>.json` (run id from diagnostics). Note ok, rows_failed, operator_hint, and db_error_detail.",
    "If the summary or hint indicates SQLite busy/locked or WinError 32: close any other program viewing or copying lab databases; wait one minute; rerun the shadow pipeline once.",
    "If rows_failed is large while the DB write path works: treat as ingest/validation rejects—send a System Health Pack for triage; do not hand-edit the unified SQLite database.",
    "If the detail mentions disk I/O or no space: free space on the lab drive, reboot, then rerun the shadow pipeline.",
    "If the detail mentions read-only or permission denied: confirm the lab root and database paths are writable by the MediBot user; add antivirus exclusions for lab `reports` and DB folders.",
    "Re-check Layer 1 only after diagnostics show last_phase_c_ok true and manifest SHA equals ingest SHA (see Layer 1 lines above).",
    "Do not interpret DAT/CSV join quality until that Phase C gate is satisfied.",
)


def _safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _dict_get_int(payload, key, default=None):
    if isinstance(payload, dict) and key in payload:
        return _safe_int(payload.get(key), 0)
    return default


def _first_int(payloads, key, default=0):
    for payload in payloads:
        v = _dict_get_int(payload, key, None)
        if v is not None:
            return v
    return default


def _first_nested_int(payloads, nested_key, key, default=0):
    for payload in payloads:
        if not isinstance(payload, dict):
            continue
        nested = payload.get(nested_key)
        if isinstance(nested, dict) and key in nested:
            return _safe_int(nested.get(key), 0)
    return default


def _has_any_key(payloads, keys):
    for payload in payloads:
        if not isinstance(payload, dict):
            continue
        for key in keys:
            if key in payload:
                return True
    return False


def _copy_int_dict(value):
    out = {}
    if not isinstance(value, dict):
        return out
    for key, raw in value.items():
        norm_key = _str_norm(key)
        if not norm_key:
            continue
        out[norm_key] = _safe_int(raw, 0)
    return out


def _format_int_dict(value):
    data = _copy_int_dict(value)
    if not data:
        return "{}"
    parts = []
    for key in sorted(data.keys()):
        parts.append("{0}:{1}".format(key, _safe_int(data.get(key), 0)))
    return ",".join(parts)


def _str_norm(value):
    try:
        return str(value or "").strip()
    except Exception:
        return ""


def _lower_code(value):
    return _str_norm(value).lower().replace("-", "_")


def _phase_d_constraint_skip_counts(diagnostics_state, phase_d_summary):
    if isinstance(diagnostics_state, dict):
        counts = diagnostics_state.get("last_phase_d_constraint_skip_counts")
        if isinstance(counts, dict):
            return counts
    if isinstance(phase_d_summary, dict):
        counts = phase_d_summary.get("constraint_skip_counts")
        if isinstance(counts, dict):
            return counts
    return {}


def _invalid_external_patient_id_breakdowns(diagnostics_state, phase_d_summary):
    counts = _phase_d_constraint_skip_counts(diagnostics_state, phase_d_summary)
    return (
        _copy_int_dict(counts.get("patient_invalid_external_id_by_source_contract")),
        _copy_int_dict(counts.get("patient_invalid_external_id_by_contract_disposition")),
    )


def _phase_d_dat_canonical_count(diagnostics_state, phase_d_summary):
    payloads = []
    if isinstance(phase_d_summary, dict):
        payloads.append(phase_d_summary)
    if isinstance(diagnostics_state, dict):
        tel = diagnostics_state.get("last_phase_d_dat_telemetry")
        if isinstance(tel, dict):
            payloads.append(tel)
    for payload in payloads:
        for key in (
                "dat_canonical_record_count",
                "phase_d_dat_canonical_record_count",
                "canonical_dat_record_count"):
            if isinstance(payload, dict) and key in payload:
                return _safe_int(payload.get(key), 0)
    return 0


def _invalid_external_patient_id_pressure(diagnostics_state, phase_d_summary, layer1_summary):
    payloads = []
    if isinstance(layer1_summary, dict):
        payloads.append(layer1_summary)
    if isinstance(phase_d_summary, dict):
        payloads.append(phase_d_summary)
    top_blocker_seen = False
    for payload in payloads:
        code = _lower_code(payload.get("layer1_top_blocker")) if isinstance(payload, dict) else ""
        if code in ("invalid_external_patient_id", "invalid_external_patient_ids", "invalid_external_id"):
            top_blocker_seen = True
        blockers = payload.get("ranked_join_blockers") if isinstance(payload, dict) else None
        if isinstance(blockers, list):
            for row in blockers:
                if not isinstance(row, dict):
                    continue
                rcode = _lower_code(row.get("code"))
                if rcode in ("invalid_external_patient_id", "invalid_external_patient_ids", "invalid_external_id"):
                    top_blocker_seen = True
    if isinstance(diagnostics_state, dict):
        counts = diagnostics_state.get("last_phase_d_constraint_skip_counts")
        if isinstance(counts, dict):
            n = _safe_int(counts.get("patient_invalid_external_id"), 0)
            if n > 0:
                return n
        join = diagnostics_state.get("last_phase_d_dat_csv_join_telemetry")
        if isinstance(join, dict):
            for key in (
                    "invalid_external_id_csv_count",
                    "invalid_external_id_join_block_count",
                    "invalid_external_patient_id_count"):
                n2 = _safe_int(join.get(key), 0)
                if n2 > 0:
                    return n2
    if top_blocker_seen:
        return 1
    return 0


def _default_load_json(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        import json
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _file_sha256_prefix16(path):
    if not path or not os.path.isfile(path):
        return ""
    try:
        with open(path, "rb") as handle:
            h = hashlib.sha256()
            block = handle.read(65536)
            while block:
                h.update(block)
                block = handle.read(65536)
        return h.hexdigest()[:16]
    except Exception:
        return ""


def _merge_diag_cursor_scalar(diagnostics_state, run_cursor, key, default=""):
    if not isinstance(diagnostics_state, dict):
        diagnostics_state = {}
    if not isinstance(run_cursor, dict):
        run_cursor = {}
    v = diagnostics_state.get(key, "")
    if v is None or v == "":
        v = run_cursor.get(key, "")
    if v is None:
        return default
    s = str(v).strip()
    return s if s else default


def _handoff_pipeline_run_id_from_report(path, payload):
    if isinstance(payload, dict):
        rid = _str_norm(payload.get("pipeline_run_id"))
        if rid:
            return rid
    base = os.path.basename(_str_norm(path))
    pref = "phase_c_execution_handoff_"
    suf = ".json"
    if base.startswith(pref) and base.endswith(suf):
        return base[len(pref) : -len(suf)]
    return ""


def _ingest_bootstrap_finish_presence(lab_root, reports_dir):
    rd = _str_norm(reports_dir) or (os.path.join(_str_norm(lab_root), "reports") if lab_root else "")
    boot = os.path.join(rd, "ingest_from_manifest_bootstrap_latest.json")
    finish = os.path.join(rd, "ingest_from_manifest_diagnostics_latest.json")
    return os.path.isfile(boot), os.path.isfile(finish)


def classify_phase_c_handoff_freshness(lab_root, diagnostics_state=None, run_cursor=None):
    """
    Classify whether stamped Phase C execution-handoff evidence matches the active lab lineage.

    Returns a dict including ``phase_c_handoff_freshness`` (one of the ``PHASE_C_HANDOFF_FRESHNESS_*``
    constants) and auxiliary fields for pack/meta surfaces.
    """
    out = {
        "phase_c_handoff_freshness": PHASE_C_HANDOFF_FRESHNESS_MISSING,
        "phase_c_handoff_report_path": "",
        "phase_c_handoff_pipeline_run_id": "",
        "phase_c_handoff_generated_at_utc": "",
        "phase_c_handoff_active_run_id": "",
        "phase_c_handoff_comparison_run_id": "",
        "phase_c_subprocess_script_drift": "unknown",
    }
    lab_root = _str_norm(lab_root)
    if not lab_root:
        return out
    diag = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    if run_cursor is None:
        run_cursor = _default_load_json(os.path.join(lab_root, "run_cursor.json"))
    elif not isinstance(run_cursor, dict):
        run_cursor = {}
    report_path = _merge_diag_cursor_scalar(
        diag, run_cursor, "last_phase_c_execution_handoff_report_path"
    )
    out["phase_c_handoff_report_path"] = report_path
    out["phase_c_handoff_active_run_id"] = _merge_diag_cursor_scalar(diag, run_cursor, "active_run_id")
    spath = _merge_diag_cursor_scalar(diag, run_cursor, "last_phase_c_subprocess_script_path")
    rp = _merge_diag_cursor_scalar(diag, run_cursor, "last_phase_c_subprocess_script_sha256_prefix")
    ondisk = _file_sha256_prefix16(spath)
    drift = "unknown"
    if not spath:
        drift = "unknown"
    elif not ondisk:
        drift = "unknown"
    elif rp and ondisk != rp:
        drift = "yes"
    elif rp:
        drift = "no"
    else:
        drift = "unknown"
    out["phase_c_subprocess_script_drift"] = drift

    if not report_path or not os.path.isfile(report_path):
        out["phase_c_handoff_freshness"] = PHASE_C_HANDOFF_FRESHNESS_MISSING
        return out

    payload = _default_load_json(report_path)
    if not isinstance(payload, dict) or not payload:
        out["phase_c_handoff_freshness"] = PHASE_C_HANDOFF_FRESHNESS_MISSING
        return out

    hp_rid = _handoff_pipeline_run_id_from_report(report_path, payload)
    out["phase_c_handoff_pipeline_run_id"] = hp_rid
    out["phase_c_handoff_generated_at_utc"] = _str_norm(payload.get("generated_at_utc"))

    if drift == "yes":
        out["phase_c_handoff_freshness"] = PHASE_C_HANDOFF_FRESHNESS_STALE_AFTER_DEPLOY
        return out

    active = _str_norm(out["phase_c_handoff_active_run_id"])
    shadow_last = _merge_diag_cursor_scalar(diag, run_cursor, "last_shadow_pipeline_run_id")
    comparison = active if active else _str_norm(shadow_last)
    out["phase_c_handoff_comparison_run_id"] = comparison
    if comparison and hp_rid and comparison != hp_rid:
        out["phase_c_handoff_freshness"] = PHASE_C_HANDOFF_FRESHNESS_STALE_ACTIVE_RUN
        return out

    snap = payload.get("snapshot_after")
    if isinstance(snap, dict):
        ho_b = _str_norm(snap.get("last_manifest_sha256"))
        ho_c = _str_norm(snap.get("last_ingest_manifest_sha256"))
        cur_b = _merge_diag_cursor_scalar(diag, run_cursor, "last_manifest_sha256")
        cur_c = _merge_diag_cursor_scalar(diag, run_cursor, "last_ingest_manifest_sha256")
        if ho_b and cur_b and ho_b != cur_b:
            out["phase_c_handoff_freshness"] = PHASE_C_HANDOFF_FRESHNESS_STALE_ACTIVE_RUN
            return out
        if ho_c and cur_c and ho_c != cur_c:
            out["phase_c_handoff_freshness"] = PHASE_C_HANDOFF_FRESHNESS_STALE_ACTIVE_RUN
            return out

    out["phase_c_handoff_freshness"] = PHASE_C_HANDOFF_FRESHNESS_CURRENT
    return out


def _apply_handoff_freshness_to_bootstrap_view(view, freshness):
    """If execution-handoff telemetry is stale, do not present bootstrap/handoff as current evidence."""
    if freshness not in (
        PHASE_C_HANDOFF_FRESHNESS_STALE_ACTIVE_RUN,
        PHASE_C_HANDOFF_FRESHNESS_STALE_AFTER_DEPLOY,
    ):
        return view
    if not isinstance(view, dict):
        view = {}
    view = dict(view)
    view["phase_c_bootstrap_diagnostics_present"] = False
    stg = _str_norm(view.get("phase_c_bootstrap_stage")).lower()
    if stg == "handoff_ok":
        view["phase_c_bootstrap_stage"] = "handoff_stale_not_current_evidence"
        view["phase_c_finish_diagnostics_observed"] = False
        view["phase_c_next_developer_action"] = (
            "Phase C execution-handoff snapshot is stale vs active lineage or on-disk ingest script; "
            "rerun shadow pipeline after deploy."
        )
    return view


def _recovery_text_failed(recovery):
    if not isinstance(recovery, dict):
        return ""
    parts = []
    for key in ("error_detail", "quarantine_retry_last_error", "error_code"):
        parts.append(_str_norm(recovery.get(key)))
    return " ".join(parts).lower()


def _recovery_failed(diagnostics_state):
    st = _str_norm(diagnostics_state.get("last_phase_c_shadow_recovery_status")).lower()
    if st == "failed":
        return True
    rec = diagnostics_state.get("phase_c_shadow_recovery")
    if isinstance(rec, dict):
        if _str_norm(rec.get("status")).lower() == "failed":
            return True
    return False


def _glob_latest_layer1_summary_path(reports_dir, preferred_phase_d_run_id=None, report_files=None):
    if not reports_dir or not os.path.isdir(reports_dir):
        return ""
    pref_rid = _str_norm(preferred_phase_d_run_id)
    if pref_rid:
        pref_path = os.path.join(
            reports_dir,
            "layer1_join_debug_summary_{0}.json".format(pref_rid),
        )
        if os.path.isfile(pref_path):
            return pref_path
    best_mtime = -1.0
    best_path = ""
    prefix = "layer1_join_debug_summary_"
    suffix = ".json"
    if report_files is None:
        report_files = list_report_files(reports_dir)
    for row in report_files:
        if not isinstance(row, dict):
            continue
        name = _str_norm(row.get("name"))
        if not name.startswith(prefix) or not name.endswith(suffix):
            continue
        path = _str_norm(row.get("path")) or os.path.join(reports_dir, name)
        try:
            mtime = float(row.get("mtime", 0.0) or 0.0)
        except (TypeError, ValueError):
            mtime = 0.0
        if mtime >= best_mtime:
            best_mtime = mtime
            best_path = path
    return best_path


def _update_layer1_data_plane_fields(
        out,
        layer1_summary,
        phase_d_summary,
        diagnostics_state,
        phase_d_selected_rows,
        dat_manifest_rows):
    """
    Populate DAT data-plane interpretation without changing gate/readiness status.

    Strict counts come from layer1_join_debug / qa_canonical_summary fields.
    Relaxed counts are debug-only PATID+DATE candidates and are not payer-anchor
    integration.
    """
    payloads = []
    if isinstance(layer1_summary, dict):
        payloads.append(layer1_summary)
    if isinstance(phase_d_summary, dict):
        payloads.append(phase_d_summary)

    strict_keyable = _first_int(payloads, "layer1_dat_keyable_count", 0)
    strict_overlap = _first_int(payloads, "layer1_dat_csv_overlap_count", 0)
    strict_integrated = _first_nested_int(payloads, "dat_csv_join_telemetry_ref", "matched_count", 0)

    phase_d_join = phase_d_summary.get("dat_csv_join_telemetry") if isinstance(phase_d_summary, dict) else {}
    if strict_integrated == 0 and isinstance(phase_d_join, dict):
        strict_integrated = _safe_int(phase_d_join.get("matched_count"), 0)
    diag_join = diagnostics_state.get("last_phase_d_dat_csv_join_telemetry") if isinstance(diagnostics_state, dict) else {}
    if strict_integrated == 0 and isinstance(diag_join, dict):
        strict_integrated = _safe_int(diag_join.get("matched_count"), 0)

    relaxed_keyable = _first_int(payloads, "layer1_dat_relaxed_keyable_count", 0)
    relaxed_overlap = _first_int(payloads, "layer1_dat_csv_relaxed_overlap_count", 0)
    if relaxed_overlap == 0:
        relaxed_overlap = _first_int(payloads, "layer1_dat_relaxed_csv_overlap", 0)
    relaxed_payer_missing = _first_int(payloads, "layer1_dat_relaxed_payer_anchor_missing_count", 0)
    relaxed_parsed_rows = _first_int(payloads, "layer1_dat_relaxed_parsed_rows", 0)
    dat_canonical = _phase_d_dat_canonical_count(diagnostics_state, phase_d_summary)
    invalid_external_pressure = _invalid_external_patient_id_pressure(
        diagnostics_state, phase_d_summary, layer1_summary)
    invalid_by_contract, invalid_by_disposition = _invalid_external_patient_id_breakdowns(
        diagnostics_state, phase_d_summary)

    dat_rows = _safe_int(dat_manifest_rows, 0)
    selected_rows = _safe_int(phase_d_selected_rows, 0)
    data_keys_present = _has_any_key(payloads, (
        "layer1_dat_keyable_count",
        "layer1_dat_csv_overlap_count",
        "layer1_dat_relaxed_keyable_count",
        "layer1_dat_csv_relaxed_overlap_count",
        "layer1_dat_relaxed_csv_overlap",
        "layer1_dat_relaxed_payer_anchor_missing_count",
        "layer1_dat_relaxed_parsed_rows",
    ))
    if not data_keys_present:
        for payload in payloads:
            if isinstance(payload, dict) and isinstance(payload.get("dat_csv_join_telemetry_ref"), dict):
                data_keys_present = True
                break
    if not data_keys_present and isinstance(phase_d_join, dict) and phase_d_join:
        data_keys_present = True
    if not data_keys_present and isinstance(diag_join, dict) and diag_join:
        data_keys_present = True

    if dat_rows <= 0 and selected_rows <= 0 and not data_keys_present:
        data_status = DATA_STATUS_NO_DAT_SELECTED
    elif strict_integrated > 0 or strict_overlap > 0:
        data_status = DATA_STATUS_STRICT_DAT_INTEGRATED
    elif relaxed_overlap > 0:
        data_status = DATA_STATUS_RELAXED_DAT_OVERLAP_ONLY
    elif strict_keyable > 0 or relaxed_keyable > 0 or relaxed_parsed_rows > 0 or dat_rows > 0:
        data_status = DATA_STATUS_STRICT_DAT_BLOCKED
    elif data_keys_present:
        data_status = DATA_STATUS_STRICT_DAT_BLOCKED
    else:
        data_status = DATA_STATUS_UNKNOWN

    out["layer1_data_status"] = data_status
    out["layer1_dat_strict_keyable_count"] = strict_keyable
    out["layer1_dat_strict_csv_overlap_count"] = strict_overlap
    out["layer1_dat_strict_integrated_count"] = strict_integrated
    out["layer1_dat_relaxed_keyable_count"] = relaxed_keyable
    out["layer1_dat_relaxed_csv_overlap_count"] = relaxed_overlap
    out["layer1_dat_relaxed_payer_anchor_missing_count"] = relaxed_payer_missing
    out["layer1_dat_relaxed_parsed_rows"] = relaxed_parsed_rows
    out["phase_d_dat_canonical_record_count"] = dat_canonical
    out["layer1_invalid_external_patient_id_count"] = invalid_external_pressure
    out["layer1_invalid_external_patient_id_by_source_contract"] = invalid_by_contract
    out["layer1_invalid_external_patient_id_by_contract_disposition"] = invalid_by_disposition
    out["layer1_dat_integration_blocker"] = ""
    quality_blockers = []
    if invalid_external_pressure > 0:
        quality_blockers.append(LAYER1_BLOCKER_INVALID_EXTERNAL_PATIENT_ID)
    if relaxed_payer_missing > 0 and strict_integrated <= 0:
        quality_blockers.append("relaxed_dat_missing_payer_anchor_diagnostic_only")
    if (strict_integrated <= 0
            and data_status in (DATA_STATUS_STRICT_DAT_BLOCKED, DATA_STATUS_RELAXED_DAT_OVERLAP_ONLY)
            and (dat_canonical > 0 or selected_rows > 0 or dat_rows > 0)
            and LAYER1_BLOCKER_DAT_INTEGRATION_BLOCKED not in quality_blockers):
        quality_blockers.append(LAYER1_BLOCKER_DAT_INTEGRATION_BLOCKED)
    if invalid_external_pressure > 0:
        quality_status = DATA_QUALITY_STATUS_BLOCKED
    elif strict_integrated > 0 and not quality_blockers:
        quality_status = DATA_QUALITY_STATUS_READY
    elif quality_blockers:
        quality_status = DATA_QUALITY_STATUS_WARNING
    elif data_status == DATA_STATUS_NO_DAT_SELECTED:
        quality_status = DATA_QUALITY_STATUS_UNKNOWN
    else:
        quality_status = DATA_QUALITY_STATUS_READY if data_status == DATA_STATUS_STRICT_DAT_INTEGRATED else DATA_QUALITY_STATUS_WARNING
    out["layer1_data_quality_status"] = quality_status
    out["layer1_data_quality_blockers"] = quality_blockers
    if (strict_integrated <= 0
            and data_status in (DATA_STATUS_STRICT_DAT_BLOCKED, DATA_STATUS_RELAXED_DAT_OVERLAP_ONLY)
            and (dat_canonical > 0 or selected_rows > 0 or dat_rows > 0)):
        if invalid_external_pressure > 0:
            out["layer1_dat_integration_blocker"] = LAYER1_BLOCKER_INVALID_EXTERNAL_PATIENT_ID
        else:
            out["layer1_dat_integration_blocker"] = LAYER1_BLOCKER_DAT_INTEGRATION_BLOCKED


def _apply_layer1_data_blocker(out):
    blocker = _str_norm(out.get("layer1_dat_integration_blocker"))
    if not blocker or _str_norm(out.get("layer1_current_blocker")):
        return
    out["layer1_current_blocker"] = blocker
    out["layer1_blocked_at_phase"] = "layer1"
    strict_integrated = _safe_int(out.get("layer1_dat_strict_integrated_count"), 0)
    canonical = _safe_int(out.get("phase_d_dat_canonical_record_count"), 0)
    invalid_count = _safe_int(out.get("layer1_invalid_external_patient_id_count"), 0)
    if blocker == LAYER1_BLOCKER_INVALID_EXTERNAL_PATIENT_ID:
        out["next_operator_action"] = (
            "Developer/support: Resolve external patient ID contract pressure from attached telemetry; "
            "strict DAT integrated count is {0} while DAT canonical count is {1}. "
            "No XP operator raw-data inspection is required.".format(
                strict_integrated, canonical)
        )
        if invalid_count > 0:
            out["developer_note"] = (
                "invalid_external_patient_id_count={0}; layer1_data_status={1}; layer1_data_quality_status={2}".format(
                    invalid_count,
                    _str_norm(out.get("layer1_data_status")) or DATA_STATUS_UNKNOWN,
                    _str_norm(out.get("layer1_data_quality_status")) or DATA_QUALITY_STATUS_UNKNOWN)
            )
    else:
        out["next_operator_action"] = (
            "Resolve DAT integration blocker: strict DAT integrated count is {0} while DAT canonical count is {1}; "
            "treat relaxed DAT overlap as diagnostic-only until payer-anchor linkage succeeds.".format(
                strict_integrated, canonical)
        )


def _phase_d_json_path_from_snapshot(snapshot, load_json_dict_fn, phase_d_run_id):
    rows = snapshot.get("phase_rows", []) if isinstance(snapshot.get("phase_rows"), list) else []
    for row in rows:
        if _str_norm(row.get("code")).upper() != "D":
            continue
        files = row.get("files", []) if isinstance(row.get("files"), list) else []
        for path in files:
            base = os.path.basename(_str_norm(path))
            if base.startswith("qa_canonical_summary_") and base.lower().endswith(".json"):
                return _str_norm(path)
    reports_dir = _str_norm(snapshot.get("reports_dir"))
    if reports_dir and phase_d_run_id:
        cand = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(phase_d_run_id))
        if os.path.isfile(cand):
            return cand
    return ""


def _phase_b_json_path(reports_dir, phase_b_run_id):
    if not reports_dir or not phase_b_run_id:
        return ""
    path = os.path.join(reports_dir, "artifact_discovery_summary_{0}.json".format(phase_b_run_id))
    if os.path.isfile(path):
        return path
    return ""


def _phase_b_manifest_path(reports_dir, phase_b_run_id):
    if not reports_dir or not phase_b_run_id:
        return ""
    path = os.path.join(reports_dir, "artifact_manifest_{0}.jsonl".format(phase_b_run_id))
    if os.path.isfile(path):
        return path
    return ""


def _sqlite_lock_style_hint_text(text):
    low = str(text or "").lower()
    for tok in ("locked", "busy", "winerror 32", "errno 32", "readonly", "read-only", "cannot lock"):
        if tok in low:
            return True
    return False


def _runbook_checklist_append(checklist, label, status_token, detail=""):
    checklist.append({
        "label": str(label or "").strip(),
        "status": str(status_token or "").strip(),
        "detail": str(detail or "").strip()[:220],
    })


def _build_runbook_checklist_manifest_pending(diagnostics_state, phase_b_run, b_path, b_sha, c_sha):
    checklist = []
    b_ok = bool(b_path and os.path.isfile(b_path))
    _runbook_checklist_append(
        checklist,
        "Phase B discovery summary on disk",
        RUNBOOK_CHK_OK if b_ok else RUNBOOK_CHK_FAIL,
        os.path.basename(b_path) if b_ok else (phase_b_run or "unknown"),
    )
    _runbook_checklist_append(
        checklist,
        "Diagnostics publish manifest digest (B)",
        RUNBOOK_CHK_OK if b_sha else RUNBOOK_CHK_OPEN,
        b_sha[:24] + "..." if len(b_sha) > 24 else b_sha,
    )
    _runbook_checklist_append(
        checklist,
        "Diagnostics publish ingest digest (C)",
        RUNBOOK_CHK_OK if c_sha else RUNBOOK_CHK_OPEN,
        c_sha[:24] + "..." if len(c_sha) > 24 else c_sha,
    )
    aligned = bool(b_sha and c_sha and b_sha == c_sha)
    _runbook_checklist_append(
        checklist,
        "Manifest digest matches ingest digest",
        RUNBOOK_CHK_OK if aligned else RUNBOOK_CHK_FAIL,
        "" if aligned else "ingest must catch up to current manifest",
    )
    rs = _str_norm(diagnostics_state.get("last_phase_c_shadow_recovery_status")).lower()
    if rs in ("running", "in_progress", "started"):
        _runbook_checklist_append(checklist, "Phase C shadow recovery idle", RUNBOOK_CHK_WARN, rs)
    elif rs == "failed":
        _runbook_checklist_append(checklist, "Phase C shadow recovery last outcome", RUNBOOK_CHK_FAIL, "failed")
    else:
        _runbook_checklist_append(checklist, "Phase C shadow recovery not in-flight", RUNBOOK_CHK_OK, rs or "n/a")
    pc_ok = diagnostics_state.get("last_phase_c_ok")
    if pc_ok is True:
        _runbook_checklist_append(checklist, "Diagnostics last_phase_c_ok", RUNBOOK_CHK_OK, "")
    elif pc_ok is False:
        _runbook_checklist_append(checklist, "Diagnostics last_phase_c_ok", RUNBOOK_CHK_FAIL, "")
    else:
        _runbook_checklist_append(checklist, "Diagnostics last_phase_c_ok", RUNBOOK_CHK_OPEN, "unset")
    _runbook_checklist_append(
        checklist,
        "Operator: let Phase C finish or rerun shadow pipeline once, then refresh this pack",
        RUNBOOK_CHK_OPEN,
        "",
    )
    return checklist


def _build_runbook_checklist_ingest_failure(diagnostics_state, hints, c_run, b_sha, c_sha):
    checklist = []
    has_path = bool(hints.get("summary_basename"))
    _runbook_checklist_append(
        checklist,
        "Canonical ingest summary file present",
        RUNBOOK_CHK_OK if has_path else RUNBOOK_CHK_FAIL,
        hints.get("summary_basename") or (c_run or "missing last_phase_c_run_id"),
    )
    if has_path:
        iok = hints.get("ingest_summary_ok")
        if iok is True:
            _runbook_checklist_append(checklist, "Ingest summary ok flag", RUNBOOK_CHK_OK, "")
        elif iok is False:
            _runbook_checklist_append(checklist, "Ingest summary ok flag", RUNBOOK_CHK_FAIL, "")
        else:
            _runbook_checklist_append(checklist, "Ingest summary ok flag", RUNBOOK_CHK_OPEN, "not set in summary")
    rf = hints.get("rows_failed")
    if rf is not None:
        try:
            rfi = int(rf)
        except (TypeError, ValueError):
            rfi = -1
        if rfi == 0:
            _runbook_checklist_append(checklist, "Ingest rows_failed count", RUNBOOK_CHK_OK, "0")
        elif rfi > 0:
            _runbook_checklist_append(
                checklist,
                "Ingest rows_failed count",
                RUNBOOK_CHK_WARN if rfi < 50 else RUNBOOK_CHK_FAIL,
                str(rfi),
            )
    hint_blob = " ".join([_str_norm(hints.get("operator_hint")), _str_norm(hints.get("db_error_detail"))])
    if _sqlite_lock_style_hint_text(hint_blob):
        _runbook_checklist_append(
            checklist,
            "SQLite lock / busy / file contention signature in summary",
            RUNBOOK_CHK_WARN,
            "close other writers; wait; retry pipeline",
        )
    else:
        _runbook_checklist_append(
            checklist,
            "SQLite lock / busy signature in summary",
            RUNBOOK_CHK_OK,
            "none detected in hint/detail",
        )
    aligned = bool(b_sha and c_sha and b_sha == c_sha)
    _runbook_checklist_append(
        checklist,
        "Manifest vs ingest digest alignment",
        RUNBOOK_CHK_OK if aligned else RUNBOOK_CHK_WARN,
        "" if aligned else "sha mismatch may still be present",
    )
    code = _str_norm(diagnostics_state.get("last_phase_c_error_code"))
    _runbook_checklist_append(
        checklist,
        "Diagnostics last_phase_c_error_code captured",
        RUNBOOK_CHK_OK if code else RUNBOOK_CHK_OPEN,
        code,
    )
    pc_ok = diagnostics_state.get("last_phase_c_ok")
    _runbook_checklist_append(
        checklist,
        "Phase C ingest marked successful in diagnostics",
        RUNBOOK_CHK_OK if pc_ok is True else RUNBOOK_CHK_FAIL,
        "",
    )
    _runbook_checklist_append(
        checklist,
        "Operator: follow expanded guidance below if any row is WARN/FAIL/OPEN",
        RUNBOOK_CHK_OPEN,
        "",
    )
    return checklist


def _phase_c_ingest_write_summary_hints(reports_dir, phase_c_run_id, load_json):
    """Load canonical ingest summary hints when Phase C failed (operator-facing, no cloud imports)."""
    if not reports_dir or not phase_c_run_id:
        return {}
    path = os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(phase_c_run_id))
    if not os.path.isfile(path):
        return {}
    summ = load_json(path)
    if not isinstance(summ, dict):
        return {}
    out = {"summary_basename": os.path.basename(path)}
    if "ok" in summ:
        out["ingest_summary_ok"] = summ.get("ok")
    oh = _str_norm(summ.get("operator_hint"))
    if oh:
        out["operator_hint"] = oh[:500]
    dd = _str_norm(summ.get("db_error_detail"))
    if dd:
        out["db_error_detail"] = dd[:400]
    try:
        rf = summ.get("rows_failed")
        if rf is not None:
            out["rows_failed"] = int(rf)
    except (TypeError, ValueError):
        pass
    return out


def _phase_c_false_clean_publish_missing(diagnostics_state):
    """
    Detect Phase C subprocess rc=0 but publish artifacts missing/incoherent.

    This is developer/support context from execution handoff telemetry, not an
    operator instruction to perform manual XP diagnostics.
    """
    if not isinstance(diagnostics_state, dict):
        return False, ""
    handoff_status = _str_norm(diagnostics_state.get("last_phase_c_execution_handoff_status")).lower()
    blocker = _str_norm(diagnostics_state.get("last_phase_c_execution_handoff_blocker_class")).lower()
    if handoff_status != "failed":
        return False, blocker
    if blocker in (
            "phase_c_subproc_ok_but_no_persist",
            "phase_c_expected_summary_missing",
            "phase_c_ingest_diagnostics_missing",
            "phase_c_script_entered_but_no_finish_diag",
            "phase_c_persist_did_not_touch_state"):
        return True, blocker
    return False, blocker


def _resolve_phase_b_run_id(diagnostics_state, snapshot, pack_context):
    pr = diagnostics_state.get("last_shadow_pipeline_phase_run_ids")
    if isinstance(pr, dict):
        rid = _str_norm(pr.get("B"))
        if rid:
            return rid
    if isinstance(snapshot, dict):
        pr2 = snapshot.get("phase_run_ids", {})
        if isinstance(pr2, dict):
            rid = _str_norm(pr2.get("B"))
            if rid:
                return rid
        rid = _str_norm(snapshot.get("run_id"))
        if rid:
            return rid
    rid = _str_norm(diagnostics_state.get("last_phase_b_run_id"))
    if rid:
        return rid
    if isinstance(pack_context, dict):
        payload = pack_context.get("anchor_shadow_report_payload", {})
        if isinstance(payload, dict):
            pr3 = payload.get("phase_run_ids", {})
            if isinstance(pr3, dict):
                rid = _str_norm(pr3.get("B"))
                if rid:
                    return rid
    return ""


def _resolve_phase_d_context_run_id(diagnostics_state, snapshot, pack_context):
    pr0 = diagnostics_state.get("last_shadow_pipeline_phase_run_ids")
    if isinstance(pr0, dict):
        rid = _str_norm(pr0.get("D"))
        if rid:
            return rid
    if isinstance(snapshot, dict):
        pr = snapshot.get("phase_run_ids", {})
        if isinstance(pr, dict):
            rid = _str_norm(pr.get("D"))
            if rid:
                return rid
    if isinstance(pack_context, dict):
        payload = pack_context.get("anchor_shadow_report_payload", {})
        if isinstance(payload, dict):
            pr2 = payload.get("phase_run_ids", {})
            if isinstance(pr2, dict):
                rid = _str_norm(pr2.get("D"))
                if rid:
                    return rid
    rid = _str_norm(diagnostics_state.get("last_phase_d_run_id"))
    if rid:
        return rid
    if isinstance(snapshot, dict):
        rid = _str_norm(snapshot.get("run_id"))
        if rid:
            return rid
    if not isinstance(pack_context, dict):
        return _str_norm(diagnostics_state.get("last_shadow_pipeline_run_id"))
    anchor = _str_norm(pack_context.get("anchor_run_id"))
    scope = _str_norm(pack_context.get("pack_scope")).lower()
    if scope == "live_current_state":
        active = _str_norm(diagnostics_state.get("active_run_id"))
        if active:
            return active
        return _str_norm(diagnostics_state.get("last_shadow_pipeline_run_id"))
    return anchor or _str_norm(diagnostics_state.get("last_shadow_pipeline_run_id"))


def _phase_c_bootstrap_status_view(diagnostics_state):
    """
    Build a compact, operator-safe view of Phase C bootstrap/handoff state.

    Returns shallow keys consumed by Layer 1 lines and support bundle meta.
    """
    if not isinstance(diagnostics_state, dict):
        diagnostics_state = {}
    blocker = _str_norm(diagnostics_state.get("last_phase_c_execution_handoff_blocker_class")).lower()
    handoff_status = _str_norm(diagnostics_state.get("last_phase_c_execution_handoff_status")).lower()
    diag_path = _str_norm(diagnostics_state.get("last_ingest_from_manifest_diag_path"))
    diag_run = _str_norm(diagnostics_state.get("last_ingest_from_manifest_diag_run_id"))
    diag_present = bool(diag_path or diag_run)
    bootstrap_present = False

    entrypoint_observed = True
    finish_observed = diag_present
    stage = "unknown"
    next_action = "Continue using operator bundles; avoid manual diagnostics-state triage."

    if blocker == _PHASE_C_BOOTSTRAP_BLOCKER_ENTRYPOINT_MISSING:
        bootstrap_present = False
        entrypoint_observed = False
        finish_observed = False
        stage = "entrypoint_not_observed"
        next_action = "Validate packaged ingest entrypoint/deploy path for ingest_from_manifest.py."
    elif blocker == _PHASE_C_BOOTSTRAP_BLOCKER_NO_FINISH_DIAG:
        bootstrap_present = True
        entrypoint_observed = True
        finish_observed = False
        stage = "entered_no_finish_diagnostics"
        next_action = (
            "Developer/support: use bootstrap timeline (last stage), phase_c_execution_handoff JSON/TXT, "
            "and phase_c_current_attempt_latest.json (not operator-facing)."
        )
    elif blocker == _PHASE_C_BOOTSTRAP_BLOCKER_FINISH_INCOHERENT:
        bootstrap_present = True
        entrypoint_observed = True
        finish_observed = True if diag_present else False
        stage = "finish_incoherent"
        next_action = "Fix Phase C summary/state publication coherence after ingest completion."
    elif handoff_status == "ok":
        bootstrap_present = False
        stage = "handoff_ok"
        entrypoint_observed = True
        finish_observed = True if diag_present else bool(
            diagnostics_state.get("last_phase_c_ok") is True)
        next_action = "No bootstrap action required."
    elif handoff_status == "failed":
        bootstrap_present = False
        stage = "handoff_failed"
        entrypoint_observed = not (blocker == "phase_c_not_run_recovery_failed")
        finish_observed = finish_observed or bool(
            blocker == "phase_c_handoff_incomplete")
        next_action = "Use System Health Pack evidence to route the active Phase C blocker."
    else:
        bootstrap_present = False

    return {
        "phase_c_bootstrap_diagnostics_present": bool(bootstrap_present),
        "phase_c_bootstrap_stage": stage,
        "phase_c_entrypoint_observed": bool(entrypoint_observed),
        "phase_c_finish_diagnostics_observed": bool(finish_observed),
        "phase_c_next_developer_action": _str_norm(next_action),
    }


def build_layer1_readiness_model(
        lab_root,
        reports_dir,
        diagnostics_state,
        pack_context=None,
        snapshot=None,
        load_json_dict_fn=None,
        report_files=None):
    """
    Build canonical Layer 1 readiness dict.

    Waterfall (first match sets blocker/status):
      1) Phase B discovery failed or B summary missing
      2) Phase C shadow recovery failed (db lock subtype on WinError/Errno 32)
      3) Phase C manifest not ingested (sha mismatch without completed recovery)
      4) Phase C ingest not OK (non-recovery failure); when
         ``reports/ingest_write_summary_<last_phase_c_run_id>.json`` exists,
         ``operator_hint`` / ``db_error_detail`` / ``rows_failed`` are folded into
         ``next_operator_action`` and ``developer_note`` for operators.
      5) Phase D summary missing or zero selection / no DAT
      6) Layer 1 evaluated blocked on current summary
    """
    load_json = load_json_dict_fn if callable(load_json_dict_fn) else _default_load_json
    if not isinstance(diagnostics_state, dict):
        diagnostics_state = {}

    reports_dir = _str_norm(reports_dir) or (os.path.join(_str_norm(lab_root), "reports") if lab_root else "")

    run_cursor = {}
    if _str_norm(lab_root):
        run_cursor = _default_load_json(os.path.join(_str_norm(lab_root), "run_cursor.json"))
    handoff_fresh = classify_phase_c_handoff_freshness(lab_root, diagnostics_state, run_cursor)
    boot_pres, finish_pres = _ingest_bootstrap_finish_presence(lab_root, reports_dir)

    out = {
        "layer1_readiness_status": STATUS_NOT_REACHED,
        "layer1_current_blocker": "",
        "layer1_blocked_at_phase": "",
        "layer1_current_run_id": "",
        "phase_b_discovered_counts": {},
        "phase_c_current_manifest_ingested": False,
        "phase_d_selected_rows": 0,
        "layer1_evaluated": False,
        "layer1_data_status": DATA_STATUS_UNKNOWN,
        "layer1_data_quality_status": DATA_QUALITY_STATUS_UNKNOWN,
        "layer1_data_quality_blockers": [],
        "layer1_dat_strict_keyable_count": 0,
        "layer1_dat_strict_csv_overlap_count": 0,
        "layer1_dat_strict_integrated_count": 0,
        "layer1_dat_relaxed_keyable_count": 0,
        "layer1_dat_relaxed_csv_overlap_count": 0,
        "layer1_dat_relaxed_payer_anchor_missing_count": 0,
        "layer1_dat_relaxed_parsed_rows": 0,
        "phase_d_dat_canonical_record_count": 0,
        "layer1_invalid_external_patient_id_count": 0,
        "layer1_dat_integration_blocker": "",
        "historical_layer1_debug_only": False,
        "next_operator_action": "",
        "developer_note": "",
        "layer1_operator_runbook": [],
        "layer1_operator_runbook_checklist": [],
        "phase_c_bootstrap_diagnostics_present": False,
        "phase_c_bootstrap_stage": "",
        "phase_c_entrypoint_observed": False,
        "phase_c_finish_diagnostics_observed": False,
        "phase_c_next_developer_action": "",
        "phase_c_handoff_freshness": handoff_fresh.get("phase_c_handoff_freshness", PHASE_C_HANDOFF_FRESHNESS_MISSING),
        "phase_c_handoff_report_path": handoff_fresh.get("phase_c_handoff_report_path", ""),
        "phase_c_handoff_pipeline_run_id": handoff_fresh.get("phase_c_handoff_pipeline_run_id", ""),
        "phase_c_handoff_generated_at_utc": handoff_fresh.get("phase_c_handoff_generated_at_utc", ""),
        "phase_c_handoff_active_run_id": handoff_fresh.get("phase_c_handoff_active_run_id", ""),
        "phase_c_handoff_comparison_run_id": handoff_fresh.get("phase_c_handoff_comparison_run_id", ""),
        "phase_c_subprocess_script_drift": handoff_fresh.get("phase_c_subprocess_script_drift", "unknown"),
        "ingest_bootstrap_latest_present": bool(boot_pres),
        "ingest_finish_diagnostics_latest_present": bool(finish_pres),
        "layer1_phase_c_handoff_blocker_class": _str_norm(
            diagnostics_state.get("last_phase_c_execution_handoff_blocker_class")),
    }
    bv = _phase_c_bootstrap_status_view(diagnostics_state)
    bv = _apply_handoff_freshness_to_bootstrap_view(bv, out["phase_c_handoff_freshness"])
    out.update(bv)
    handoff_blocker = _str_norm(
        diagnostics_state.get("last_phase_c_execution_handoff_blocker_class")).lower()

    phase_d_run = _resolve_phase_d_context_run_id(diagnostics_state, snapshot, pack_context)
    out["layer1_current_run_id"] = phase_d_run

    phase_b_run = _resolve_phase_b_run_id(diagnostics_state, snapshot, pack_context)
    b_path = _phase_b_json_path(reports_dir, phase_b_run)
    b_manifest_path = _phase_b_manifest_path(reports_dir, phase_b_run)
    b_summary = load_json(b_path) if b_path else {}
    counts = {}
    if isinstance(b_summary.get("counts_by_class"), dict):
        counts = dict(b_summary.get("counts_by_class"))
    elif isinstance(diagnostics_state.get("last_discovery_counts_by_class"), dict):
        counts = dict(diagnostics_state.get("last_discovery_counts_by_class"))
    csv_n = _safe_int(counts.get("csv"), 0)
    docx_n = _safe_int(counts.get("docx"), 0)
    dat_n = _safe_int(counts.get("dat"), 0)
    out["phase_b_discovered_counts"] = {"csv": csv_n, "docx": docx_n, "dat": dat_n}

    # ``dict.get("dat_telemetry", {})`` returns None when the key exists with value None (JSON null).
    b_dat_tel = b_summary.get("dat_telemetry") if isinstance(b_summary.get("dat_telemetry"), dict) else {}
    dat_manifest_rows = _safe_int(b_dat_tel.get("dat_manifest_rows_count"), dat_n)

    disc_ok = diagnostics_state.get("last_discovery_ok")
    if disc_ok is False:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_B_DISCOVERY_FAILED
        out["layer1_blocked_at_phase"] = "B"
        out["next_operator_action"] = "Fix Phase B discovery errors, then rerun the shadow pipeline."
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out
    if phase_b_run and not b_path and not b_manifest_path:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_B_SUMMARY_MISSING
        out["layer1_blocked_at_phase"] = "B"
        out["next_operator_action"] = "Wait for or rerun Phase B so the discovery summary exists for this run."
        out["developer_note"] = "missing artifact_discovery_summary for run_id={0}".format(phase_b_run)
        return out
    if phase_b_run and not b_path and b_manifest_path:
        out["developer_note"] = (
            "artifact_discovery_summary missing for run_id={0}; using artifact_manifest JSONL and downstream "
            "phase summaries for Layer 1 readiness".format(phase_b_run)
        )

    b_sha = _str_norm(diagnostics_state.get("last_manifest_sha256"))
    c_sha = _str_norm(diagnostics_state.get("last_ingest_manifest_sha256"))
    phase_c_ok = diagnostics_state.get("last_phase_c_ok")
    recovery = diagnostics_state.get("phase_c_shadow_recovery")
    recovery_txt = _recovery_text_failed(recovery if isinstance(recovery, dict) else {})

    if _recovery_failed(diagnostics_state):
        out["layer1_blocked_at_phase"] = "C"
        low = recovery_txt
        if "winerror 32" in low or "errno 32" in low or "[errno 32]" in low:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_SHADOW_RECOVERY_DB_LOCKED
            out["next_operator_action"] = (
                "Retry after shadow DB recovery; another process may be locking the database file.")
        else:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_SHADOW_RECOVERY_FAILED
            out["next_operator_action"] = "Resolve Phase C shadow DB recovery failure, then rerun ingest."
        out["developer_note"] = (recovery_txt or "")[:400]
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    fv = _str_norm(out.get("phase_c_handoff_freshness"))
    if fv == PHASE_C_HANDOFF_FRESHNESS_STALE_AFTER_DEPLOY:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_HANDOFF_STALE
        out["layer1_blocked_at_phase"] = "C"
        out["historical_layer1_debug_only"] = True
        out["next_operator_action"] = (
            "Phase C handoff evidence is stale after deploy (ingest script fingerprint drift vs on-disk); "
            "rerun the shadow pipeline so telemetry matches the current MediCafe build.")
        out["developer_note"] = (
            "phase_c_handoff_freshness={0}; stored_script_prefix vs on-disk mismatch".format(fv))
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out
    if fv == PHASE_C_HANDOFF_FRESHNESS_STALE_ACTIVE_RUN:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_HANDOFF_STALE
        out["layer1_blocked_at_phase"] = "C"
        out["historical_layer1_debug_only"] = True
        out["next_operator_action"] = (
            "Phase C execution-handoff report does not match the active shadow pipeline run or current "
            "manifest lineage; wait for the in-flight run to finish or refresh packs after completion.")
        out["developer_note"] = (
            "phase_c_handoff_freshness={0}; active_run_id={1} handoff_pipeline_run_id={2}".format(
                fv,
                _str_norm(out.get("phase_c_handoff_active_run_id")) or "-",
                _str_norm(out.get("phase_c_handoff_pipeline_run_id")) or "-",
            )
        )[:400]
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    if b_sha and b_sha != c_sha:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_MANIFEST_NOT_INGESTED
        out["layer1_blocked_at_phase"] = "C"
        false_clean, blocker = _phase_c_false_clean_publish_missing(diagnostics_state)
        if false_clean:
            out["next_operator_action"] = (
                "Phase C subprocess launched (rc=0) but publish artifacts are missing for the current manifest; "
                "this is developer/support context, not a manual XP diagnostics requirement.")
            out["developer_note"] = (
                "phase_c_publish_failure_context blocker_class={0}; manifest_sha256 != ingest_manifest_sha256; "
                "defer DAT/CSV join diagnosis until Phase C publish succeeds".format(blocker or "-"))
        else:
            out["next_operator_action"] = (
                "Complete Phase C ingest for the current manifest before DAT/CSV join diagnosis.")
            out["developer_note"] = (
                "manifest_sha256 != ingest_manifest_sha256; defer DAT/CSV join diagnosis until Phase C success")
        out["layer1_operator_runbook"] = list(LAYER1_OPERATOR_RUNBOOK_PHASE_C_MANIFEST_PENDING)
        out["layer1_operator_runbook_checklist"] = _build_runbook_checklist_manifest_pending(
            diagnostics_state, phase_b_run, b_path, b_sha, c_sha)
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    if handoff_blocker == _PHASE_C_BOOTSTRAP_BLOCKER_NO_FINISH_DIAG:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_INGEST_FAILED
        out["layer1_blocked_at_phase"] = "C"
        out["next_operator_action"] = (
            "Layer 1 did not run: Phase C ingest did not publish finish diagnostics. "
            "Send a System Health Pack when Cloud Readiness recommends it; no reply or manual JSON review is required on-site."
        )
        out["developer_note"] = (
            "phase_c_handoff_blocker={0}; phase_c_bootstrap_stage={1}; "
            "telemetry=ingest_from_manifest_bootstrap_timeline_latest.jsonl,phase_c_execution_handoff_*.json/.txt".format(
                handoff_blocker,
                _str_norm(out.get("phase_c_bootstrap_stage")) or "-",
            )
        )[:400]
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    if handoff_blocker in (
            _PHASE_C_BOOTSTRAP_BLOCKER_ENTRYPOINT_MISSING,
            _PHASE_C_BOOTSTRAP_BLOCKER_FINISH_INCOHERENT):
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_INGEST_FAILED
        out["layer1_blocked_at_phase"] = "C"
        out["next_operator_action"] = (
            "Phase C handoff is incomplete for the active manifest; rely on System Health Pack evidence and rerun pipeline after developer fix.")
        out["developer_note"] = (
            "phase_c_bootstrap_blocker={0}; {1}".format(
                handoff_blocker,
                _str_norm(out.get("phase_c_next_developer_action"))))
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    if phase_c_ok is False:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_C_INGEST_FAILED
        out["layer1_blocked_at_phase"] = "C"
        code = _str_norm(diagnostics_state.get("last_phase_c_error_code"))
        c_run = _str_norm(diagnostics_state.get("last_phase_c_run_id"))
        hints = _phase_c_ingest_write_summary_hints(reports_dir, c_run, load_json)
        base_action = "Fix Phase C ingest before interpreting Phase D, DAT/CSV joins, or Layer 1."
        hint_for_action = _str_norm(hints.get("operator_hint"))
        if not hint_for_action:
            hint_for_action = _str_norm(hints.get("db_error_detail"))[:220]
        if hint_for_action:
            suffix = hint_for_action[:220]
            if len(hint_for_action) > 220:
                suffix += "..."
            out["next_operator_action"] = "{0} Hint: {1}".format(base_action, suffix)
        else:
            out["next_operator_action"] = base_action
        dev_parts = []
        if code:
            dev_parts.append("last_phase_c_error_code={0}".format(code))
        if c_run:
            dev_parts.append("last_phase_c_run_id={0}".format(c_run))
        if "rows_failed" in hints:
            dev_parts.append("rows_failed={0}".format(hints["rows_failed"]))
        dd = _str_norm(hints.get("db_error_detail"))
        if dd and not hint_for_action:
            dev_parts.append(dd[:240])
        elif dd and hint_for_action and hints.get("operator_hint"):
            dev_parts.append(dd[:240])
        out["developer_note"] = "; ".join(dev_parts)[:400]
        out["layer1_operator_runbook"] = list(LAYER1_OPERATOR_RUNBOOK_PHASE_C_INGEST_FAILURE)
        out["layer1_operator_runbook_checklist"] = _build_runbook_checklist_ingest_failure(
            diagnostics_state, hints, c_run, b_sha, c_sha)
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    out["phase_c_current_manifest_ingested"] = bool(
        b_sha and c_sha and b_sha == c_sha and phase_c_ok is True)

    d_path = ""
    if isinstance(snapshot, dict):
        d_path = _phase_d_json_path_from_snapshot(snapshot, load_json, phase_d_run)
    if not d_path and phase_d_run and reports_dir:
        d_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(phase_d_run))
    d_file_ok = bool(d_path and os.path.isfile(d_path))
    d_summary = load_json(d_path) if d_file_ok else {}
    if not isinstance(d_summary, dict):
        d_summary = {}

    if d_file_ok:
        rows_sel = _safe_int(d_summary.get("rows_selected"), 0)
    else:
        rows_sel = 0
        if isinstance(pack_context, dict):
            actual = pack_context.get("anchor_actual", {})
            if isinstance(actual, dict):
                ar = _str_norm(actual.get("run_id"))
                if (not phase_d_run) or (ar == phase_d_run) or (not ar):
                    rows_sel = _safe_int(actual.get("phase_d_dat_selected_count"), 0)

    out["phase_d_selected_rows"] = rows_sel

    if not d_file_ok and rows_sel == 0:
        out["layer1_current_blocker"] = LAYER1_BLOCKER_MISSING_CURRENT_PHASE_D_SUMMARY
        out["layer1_blocked_at_phase"] = "D"
        out["next_operator_action"] = "Wait for Phase D QA summary for the current run, then re-check Layer 1."
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        if not d_path:
            out["developer_note"] = "qa_canonical_summary path unresolved"
        else:
            out["developer_note"] = "missing file {0}".format(os.path.basename(d_path))
        return out

    _update_layer1_data_plane_fields(out, {}, d_summary, diagnostics_state, rows_sel, dat_manifest_rows)

    rows_sel = out["phase_d_selected_rows"]
    if rows_sel == 0:
        out["layer1_blocked_at_phase"] = "D"
        if dat_manifest_rows > 0:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_PHASE_D_ZERO_SELECTION
            out["next_operator_action"] = (
                "Phase D selected zero DAT rows though DAT was discovered; triage DAT/ingest alignment before Layer 1.")
        else:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_DAT_ZERO_SELECTED
            out["next_operator_action"] = (
                "No DAT rows in discovery for this run; Layer 1 PATID+DATE cannot run until DAT is discovered.")
        if _str_norm(out.get("phase_c_bootstrap_stage")).lower() not in ("", "handoff_ok"):
            out["developer_note"] = (
                "Layer 1 DAT/phase-D context only; unresolved phase_c_bootstrap_stage={0}".format(
                    _str_norm(out.get("phase_c_bootstrap_stage")) or "unknown"))
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        return out

    l1_path = _str_norm(d_summary.get("layer1_join_debug_summary_path"))
    l1_summary = {}
    if l1_path and os.path.isfile(l1_path):
        l1_summary = load_json(l1_path)
        if not isinstance(l1_summary, dict):
            l1_summary = {}
    phase_d_rid_pre = _str_norm(d_summary.get("run_id")) or phase_d_run
    if not l1_summary:
        glob_path = _glob_latest_layer1_summary_path(reports_dir, phase_d_rid_pre, report_files=report_files)
        if glob_path:
            cand = load_json(glob_path)
            if not isinstance(cand, dict):
                cand = {}
            cand_run = _str_norm(cand.get("run_id"))
            if cand_run and phase_d_rid_pre and cand_run == phase_d_rid_pre:
                l1_summary = cand
                l1_path = glob_path
            elif cand:
                out["historical_layer1_debug_only"] = True
                out["developer_note"] = (
                    "stale layer1_join_debug_summary on disk (run_id={0}) != phase_d={1}"
                    .format(cand_run or "?", phase_d_rid_pre or "?"))

    l1_run = _str_norm(l1_summary.get("run_id")) if l1_summary else ""
    phase_d_rid = _str_norm(d_summary.get("run_id")) or phase_d_run
    if l1_path and l1_summary and l1_run and phase_d_rid and l1_run != phase_d_rid:
        out["historical_layer1_debug_only"] = True
        out["developer_note"] = "layer1 summary run_id={0} != phase_d context={1}".format(l1_run, phase_d_rid)

    if l1_summary and not out["historical_layer1_debug_only"]:
        _update_layer1_data_plane_fields(out, l1_summary, d_summary, diagnostics_state, rows_sel, dat_manifest_rows)

    if l1_summary and not out["historical_layer1_debug_only"]:
        evaluated = bool(l1_summary.get("layer1_join_evaluated", False))
        out["layer1_evaluated"] = evaluated
        if d_summary.get("layer1_join_debug_generated") and not evaluated:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_LAYER1_EVAL_BLOCKED
            out["layer1_blocked_at_phase"] = "layer1"
            out["layer1_readiness_status"] = STATUS_EVALUATED_BLOCKED
            out["next_operator_action"] = "Review Layer 1 join debug summary for blockers; do not use raw files alone."
            return out
        if evaluated:
            out["layer1_readiness_status"] = STATUS_EVALUATED_OK
            _apply_layer1_data_blocker(out)
            if not _str_norm(out.get("next_operator_action")):
                out["next_operator_action"] = (
                    "Layer 1 evaluation completed for this run; review layer1_data_status={0} "
                    "before treating DAT as usable.".format(out.get("layer1_data_status") or DATA_STATUS_UNKNOWN))
            return out

    if not l1_summary and d_summary.get("layer1_join_debug_generated"):
        out["layer1_evaluated"] = bool(d_summary.get("layer1_join_evaluated"))
        if not out["layer1_evaluated"]:
            out["layer1_current_blocker"] = LAYER1_BLOCKER_LAYER1_EVAL_BLOCKED
            out["layer1_blocked_at_phase"] = "layer1"
            out["layer1_readiness_status"] = STATUS_EVALUATED_BLOCKED
            out["next_operator_action"] = "Layer 1 debug was generated but is not marked evaluated; see QA summary."
            return out
        out["layer1_readiness_status"] = STATUS_EVALUATED_OK
        _apply_layer1_data_blocker(out)
        if not _str_norm(out.get("next_operator_action")):
            out["next_operator_action"] = (
                "Layer 1 evaluation completed for this run; review layer1_data_status={0} "
                "before treating DAT as usable.".format(out.get("layer1_data_status") or DATA_STATUS_UNKNOWN))
        return out

    if out["historical_layer1_debug_only"]:
        out["layer1_readiness_status"] = STATUS_NOT_REACHED
        out["layer1_current_blocker"] = LAYER1_BLOCKER_LAYER1_EVAL_BLOCKED
        out["layer1_blocked_at_phase"] = "layer1"
        out["next_operator_action"] = (
            "Do not interpret historical Layer 1 debug as current; align artifacts to the active Phase D run.")
        out["layer1_evaluated"] = False
        return out

    out["layer1_readiness_status"] = STATUS_READY_TO_EVALUATE
    out["next_operator_action"] = "Phase D has selected rows; Layer 1 debug may still be writing."
    return out


def format_layer1_readiness_lines(model):
    """Render model as pack lines (indented bullets)."""
    if not isinstance(model, dict):
        return [" - status=not_reached", " - current_blocker=(invalid_model)"]
    m = model
    lines = [
        " - status={0}".format(_str_norm(m.get("layer1_readiness_status")) or STATUS_NOT_REACHED),
        " - current_blocker={0}".format(_str_norm(m.get("layer1_current_blocker")) or "-"),
        " - blocked_at_phase={0}".format(_str_norm(m.get("layer1_blocked_at_phase")) or "-"),
        " - current_run_id={0}".format(_str_norm(m.get("layer1_current_run_id")) or "-"),
    ]
    pbc = m.get("phase_b_discovered_counts", {})
    if isinstance(pbc, dict):
        lines.append(
            " - Phase_B_discovered csv={0} docx={1} dat={2}".format(
                _safe_int(pbc.get("csv"), 0),
                _safe_int(pbc.get("docx"), 0),
                _safe_int(pbc.get("dat"), 0),
            )
        )
    lines.append(" - Phase_C_current_manifest_ingested={0}".format(bool(m.get("phase_c_current_manifest_ingested"))))
    lines.append(" - Phase_D_selected_rows={0}".format(_safe_int(m.get("phase_d_selected_rows"), 0)))
    lines.append(" - Layer_1_evaluated={0}".format(bool(m.get("layer1_evaluated"))))
    lines.append(" - layer1_data_status={0}".format(
        _str_norm(m.get("layer1_data_status")) or DATA_STATUS_UNKNOWN))
    lines.append(" - layer1_data_quality_status={0}".format(
        _str_norm(m.get("layer1_data_quality_status")) or DATA_QUALITY_STATUS_UNKNOWN))
    blockers = m.get("layer1_data_quality_blockers")
    if isinstance(blockers, list) and blockers:
        lines.append(" - layer1_data_quality_blockers={0}".format(
            ",".join([_str_norm(item) for item in blockers if _str_norm(item)]) or "-"))
    lines.append(
        " - Layer_1_DAT_strict keyable={0} csv_overlap={1} integrated={2}".format(
            _safe_int(m.get("layer1_dat_strict_keyable_count"), 0),
            _safe_int(m.get("layer1_dat_strict_csv_overlap_count"), 0),
            _safe_int(m.get("layer1_dat_strict_integrated_count"), 0),
        )
    )
    lines.append(
        " - Layer_1_DAT_relaxed keyable={0} csv_overlap={1} payer_anchor_missing={2} parsed_rows={3}".format(
            _safe_int(m.get("layer1_dat_relaxed_keyable_count"), 0),
            _safe_int(m.get("layer1_dat_relaxed_csv_overlap_count"), 0),
            _safe_int(m.get("layer1_dat_relaxed_payer_anchor_missing_count"), 0),
            _safe_int(m.get("layer1_dat_relaxed_parsed_rows"), 0),
        )
    )
    lines.append(
        " - Layer_1_DAT_integration blocker={0} dat_canonical={1} invalid_external_patient_id_count={2}".format(
            _str_norm(m.get("layer1_dat_integration_blocker")) or "-",
            _safe_int(m.get("phase_d_dat_canonical_record_count"), 0),
            _safe_int(m.get("layer1_invalid_external_patient_id_count"), 0),
        )
    )
    if (m.get("layer1_invalid_external_patient_id_by_source_contract")
            or m.get("layer1_invalid_external_patient_id_by_contract_disposition")):
        lines.append(
            " - Layer_1_invalid_external_patient_id_source_contracts={0}".format(
                _format_int_dict(m.get("layer1_invalid_external_patient_id_by_source_contract")))
        )
        lines.append(
            " - Layer_1_invalid_external_patient_id_contract_dispositions={0}".format(
                _format_int_dict(m.get("layer1_invalid_external_patient_id_by_contract_disposition")))
        )
    lines.append(" - historical_layer1_debug_only={0}".format(bool(m.get("historical_layer1_debug_only"))))
    _fv = _str_norm(m.get("phase_c_handoff_freshness"))
    _handoff_disqualifies_l1 = _fv in (
        PHASE_C_HANDOFF_FRESHNESS_STALE_ACTIVE_RUN,
        PHASE_C_HANDOFF_FRESHNESS_STALE_AFTER_DEPLOY,
    )
    lines.append(" - current_layer1_debug_effective={0}".format(
        bool(
            not m.get("historical_layer1_debug_only")
            and not _handoff_disqualifies_l1
            and m.get("layer1_readiness_status") in (
                STATUS_EVALUATED_OK, STATUS_EVALUATED_BLOCKED, STATUS_READY_TO_EVALUATE,
            )
        )
    ))
    lines.append(" - phase_c_handoff_freshness={0}".format(
        _str_norm(m.get("phase_c_handoff_freshness")) or PHASE_C_HANDOFF_FRESHNESS_MISSING))
    lines.append(" - phase_c_handoff_comparison_run_id={0}".format(
        _str_norm(m.get("phase_c_handoff_comparison_run_id")) or "-"))
    lines.append(" - ingest_bootstrap_latest_present={0}".format(bool(m.get("ingest_bootstrap_latest_present"))))
    lines.append(" - ingest_finish_diagnostics_latest_present={0}".format(
        bool(m.get("ingest_finish_diagnostics_latest_present"))))
    if m.get("ingest_bootstrap_latest_present") and not m.get("ingest_finish_diagnostics_latest_present"):
        lines.append(
            " - Note: ingest_from_manifest_bootstrap_latest.json present without finish diagnostics "
            "(ingest_from_manifest_diagnostics_latest.json / stamped ingest diag path)."
        )
    lines.append(" - Phase_C_bootstrap_diagnostics_present={0}".format(
        bool(m.get("phase_c_bootstrap_diagnostics_present"))))
    lines.append(" - Phase_C_bootstrap_stage={0}".format(
        _str_norm(m.get("phase_c_bootstrap_stage")) or "-"))
    lines.append(" - Phase_C_entrypoint_observed={0}".format(
        bool(m.get("phase_c_entrypoint_observed"))))
    lines.append(" - Phase_C_finish_diagnostics_observed={0}".format(
        bool(m.get("phase_c_finish_diagnostics_observed"))))
    lines.append(
        " - developer_summary: b_counts csv={0} docx={1} dat={2}; phase_c_ingest_ok={3}; layer1_reached={4}; next_blocker={5}".format(
            _safe_int(pbc.get("csv"), 0) if isinstance(pbc, dict) else 0,
            _safe_int(pbc.get("docx"), 0) if isinstance(pbc, dict) else 0,
            _safe_int(pbc.get("dat"), 0) if isinstance(pbc, dict) else 0,
            bool(m.get("phase_c_current_manifest_ingested")),
            bool(_str_norm(m.get("layer1_readiness_status")) in (STATUS_EVALUATED_OK, STATUS_EVALUATED_BLOCKED)),
            _str_norm(m.get("layer1_current_blocker")) or "-",
        )
    )
    noa = _str_norm(m.get("next_operator_action"))
    if noa:
        lines.append(" - Next_action: {0}".format(noa))
    chk = m.get("layer1_operator_runbook_checklist")
    if isinstance(chk, list) and chk:
        lines.append(" - Operator_runbook checklist:")
        for row in chk:
            if not isinstance(row, dict):
                continue
            lab = _str_norm(row.get("label"))
            if not lab:
                continue
            tok = _str_norm(row.get("status")) or RUNBOOK_CHK_OPEN
            det = _str_norm(row.get("detail"))
            if det:
                lines.append("     {0} {1}  ({2})".format(tok, lab, det))
            else:
                lines.append("     {0} {1}".format(tok, lab))
    rb = m.get("layer1_operator_runbook")
    if isinstance(rb, list) and rb:
        lines.append(" - Operator_runbook guidance (expanded):")
        for idx, step in enumerate(rb, 1):
            st = _str_norm(step)
            if st:
                lines.append("     {0}. {1}".format(idx, st))
    dn = _str_norm(m.get("developer_note"))
    if dn:
        lines.append(" - developer_note={0}".format(dn[:300]))
    pc_dev = _str_norm(m.get("phase_c_next_developer_action"))
    if pc_dev:
        lines.append(" - phase_c_next_developer_action={0}".format(pc_dev[:300]))
    return lines


def shallow_layer1_readiness_meta(model):
    """JSON-safe subset for support bundle meta."""
    if not isinstance(model, dict):
        return {}
    return {
        "layer1_readiness_status": _str_norm(model.get("layer1_readiness_status")),
        "layer1_current_blocker": _str_norm(model.get("layer1_current_blocker")),
        "layer1_blocked_at_phase": _str_norm(model.get("layer1_blocked_at_phase")),
        "layer1_current_run_id": _str_norm(model.get("layer1_current_run_id")),
        "historical_layer1_debug_only": bool(model.get("historical_layer1_debug_only")),
        "layer1_evaluated": bool(model.get("layer1_evaluated")),
        "layer1_data_status": _str_norm(model.get("layer1_data_status")) or DATA_STATUS_UNKNOWN,
        "layer1_data_quality_status": (
            _str_norm(model.get("layer1_data_quality_status")) or DATA_QUALITY_STATUS_UNKNOWN),
        "layer1_data_quality_blockers": [
            _str_norm(item) for item in (model.get("layer1_data_quality_blockers") or [])
            if _str_norm(item)
        ] if isinstance(model.get("layer1_data_quality_blockers"), list) else [],
        "layer1_dat_strict_keyable_count": _safe_int(model.get("layer1_dat_strict_keyable_count"), 0),
        "layer1_dat_strict_csv_overlap_count": _safe_int(model.get("layer1_dat_strict_csv_overlap_count"), 0),
        "layer1_dat_strict_integrated_count": _safe_int(model.get("layer1_dat_strict_integrated_count"), 0),
        "layer1_dat_relaxed_keyable_count": _safe_int(model.get("layer1_dat_relaxed_keyable_count"), 0),
        "layer1_dat_relaxed_csv_overlap_count": _safe_int(model.get("layer1_dat_relaxed_csv_overlap_count"), 0),
        "layer1_dat_relaxed_payer_anchor_missing_count": _safe_int(
            model.get("layer1_dat_relaxed_payer_anchor_missing_count"), 0),
        "layer1_dat_relaxed_parsed_rows": _safe_int(model.get("layer1_dat_relaxed_parsed_rows"), 0),
        "phase_d_dat_canonical_record_count": _safe_int(model.get("phase_d_dat_canonical_record_count"), 0),
        "layer1_invalid_external_patient_id_count": _safe_int(
            model.get("layer1_invalid_external_patient_id_count"), 0),
        "layer1_invalid_external_patient_id_by_source_contract": _copy_int_dict(
            model.get("layer1_invalid_external_patient_id_by_source_contract")),
        "layer1_invalid_external_patient_id_by_contract_disposition": _copy_int_dict(
            model.get("layer1_invalid_external_patient_id_by_contract_disposition")),
        "layer1_dat_integration_blocker": _str_norm(model.get("layer1_dat_integration_blocker")),
        "phase_c_handoff_freshness": (
            _str_norm(model.get("phase_c_handoff_freshness")) or PHASE_C_HANDOFF_FRESHNESS_MISSING
        ),
        "phase_c_handoff_comparison_run_id": _str_norm(model.get("phase_c_handoff_comparison_run_id")),
        "phase_c_subprocess_script_drift": _str_norm(model.get("phase_c_subprocess_script_drift")),
        "ingest_bootstrap_latest_present": bool(model.get("ingest_bootstrap_latest_present")),
        "ingest_finish_diagnostics_latest_present": bool(model.get("ingest_finish_diagnostics_latest_present")),
        "phase_c_bootstrap_diagnostics_present": bool(model.get("phase_c_bootstrap_diagnostics_present")),
        "phase_c_bootstrap_stage": _str_norm(model.get("phase_c_bootstrap_stage")),
        "phase_c_entrypoint_observed": bool(model.get("phase_c_entrypoint_observed")),
        "phase_c_finish_diagnostics_observed": bool(model.get("phase_c_finish_diagnostics_observed")),
        "phase_c_next_developer_action": _str_norm(model.get("phase_c_next_developer_action")),
        "layer1_phase_c_handoff_blocker_class": _str_norm(model.get("layer1_phase_c_handoff_blocker_class")),
    }
