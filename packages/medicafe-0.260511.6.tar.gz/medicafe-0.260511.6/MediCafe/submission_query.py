"""
submission_query.py - Multi-source submission query system

Purpose:
- Unified query system that aggregates claim submission data from multiple sources
- Combines JSONL index, 837p receipt files, and DAT source files
- Provides deduplication and prioritization of results

Compatible with: Windows XP SP3, Python 3.4.4, ASCII-only
"""
import os
import json
import time
from datetime import datetime

try:
    from MediCafe.core_utils import get_config_loader_with_fallback, extract_medilink_config
    MediLink_ConfigLoader = get_config_loader_with_fallback()
except ImportError:
    MediLink_ConfigLoader = None

_LAST_SUBMISSION_INDEX_HEALTH = {
    "index_path": "",
    "exists": False,
    "checked_at": 0.0,
    "total_lines": 0,
    "valid_lines": 0,
    "invalid_lines": 0,
    "status": "unknown",
    "error": "",
}

_RECEIPT_X12_CACHE = {}
_RECEIPT_X12_CACHE_MAX = 512


def _receipt_cache_key(receipt_path):
    try:
        norm = os.path.normcase(os.path.abspath(str(receipt_path or '')))
    except Exception:
        norm = str(receipt_path or '')
    return norm


def _trim_receipt_x12_cache():
    if len(_RECEIPT_X12_CACHE) <= _RECEIPT_X12_CACHE_MAX:
        return
    # Keep only newest half to bound memory on long-lived UI sessions.
    rows = []
    for key, value in _RECEIPT_X12_CACHE.items():
        ts = 0.0
        if isinstance(value, dict):
            try:
                ts = float(value.get('cached_at') or 0.0)
            except Exception:
                ts = 0.0
        rows.append((ts, key))
    rows.sort(reverse=True)
    keep = set([key for _ts, key in rows[:int(_RECEIPT_X12_CACHE_MAX / 2)]])
    for key in list(_RECEIPT_X12_CACHE.keys()):
        if key not in keep:
            try:
                del _RECEIPT_X12_CACHE[key]
            except Exception:
                pass


def _extract_member_data_from_x12_cached(receipt_path):
    receipt_path = str(receipt_path or '').strip()
    if not receipt_path or not os.path.exists(receipt_path):
        return {}
    cache_key = _receipt_cache_key(receipt_path)
    try:
        mtime = float(os.path.getmtime(receipt_path))
    except Exception:
        mtime = 0.0

    cached = _RECEIPT_X12_CACHE.get(cache_key)
    if isinstance(cached, dict):
        if float(cached.get('mtime') or 0.0) == mtime:
            data = cached.get('data')
            return data if isinstance(data, dict) else {}

    try:
        from MediCafe.x12_utils import extract_member_data_from_x12_file
        x12_data = extract_member_data_from_x12_file(receipt_path) or {}
    except Exception:
        x12_data = {}
    if not isinstance(x12_data, dict):
        x12_data = {}
    _RECEIPT_X12_CACHE[cache_key] = {
        'mtime': mtime,
        'data': x12_data,
        'cached_at': float(time.time()),
    }
    _trim_receipt_x12_cache()
    return x12_data


def _set_submission_index_health(
    index_path,
    exists,
    total_lines,
    valid_lines,
    invalid_lines,
    status="ok",
    error_text="",
):
    global _LAST_SUBMISSION_INDEX_HEALTH
    _LAST_SUBMISSION_INDEX_HEALTH = {
        "index_path": str(index_path or ""),
        "exists": bool(exists),
        "checked_at": float(time.time()),
        "total_lines": int(total_lines or 0),
        "valid_lines": int(valid_lines or 0),
        "invalid_lines": int(invalid_lines or 0),
        "status": str(status or "unknown"),
        "error": str(error_text or ""),
    }


def get_last_submission_index_health():
    """
    Return the most recent submission_index.jsonl parse-health snapshot.
    Used by submit-claims UI to optionally surface operator warnings.
    """
    return dict(_LAST_SUBMISSION_INDEX_HEALTH or {})


def build_submission_index_health_notice(health=None):
    """
    Build a normalized degradation notice payload from index health data.
    Returns None when no degraded condition should be surfaced.
    """
    if not isinstance(health, dict):
        health = get_last_submission_index_health()
    if not isinstance(health, dict):
        return None

    try:
        invalid_lines = int(health.get("invalid_lines") or 0)
    except Exception:
        invalid_lines = 0
    try:
        total_lines = int(health.get("total_lines") or 0)
    except Exception:
        total_lines = 0

    if invalid_lines <= 0:
        return None

    return {
        "invalid_lines": invalid_lines,
        "total_lines": total_lines,
        "index_path": str(health.get("index_path") or ""),
        "operator_notice": (
            "Notice: submission index has {} invalid row(s) out of {} parsed rows. "
            "Consolidated results continue in best-effort mode using receipt/DAT enrichment."
        ).format(invalid_lines, total_lines),
        "log_message": (
            "submission_index.jsonl health degraded (invalid_lines={}, total_lines={})"
        ).format(invalid_lines, total_lines),
    }


def get_last_json_health_summary():
    """
    Compatibility helper for callers that need unified json health context.
    Returns {} when json_health module is unavailable.
    """
    try:
        from MediCafe.json_health import get_last_json_health_summary as _get_last_json_health_summary
        summary = _get_last_json_health_summary()
        return summary if isinstance(summary, dict) else {}
    except Exception:
        return {}


def build_json_health_notice(summary=None):
    """
    Compatibility wrapper for unified JSON health notice payloads.
    """
    try:
        from MediCafe.json_health import build_json_health_notice as _build_json_health_notice
        return _build_json_health_notice(summary)
    except Exception:
        return None


def _normalize_dos_value(value):
    """
    Best-effort DOS normalization to YYYY-MM-DD for grouping/filtering.
    Returns empty string when no usable date is present.
    """
    raw = str(value or "").strip()
    if not raw:
        return ""

    patterns = [
        "%Y-%m-%d",
        "%Y/%m/%d",
        "%Y.%m.%d",
        "%m-%d-%Y",
        "%m/%d/%Y",
        "%m.%d.%Y",
        "%m-%d-%y",
        "%m/%d/%y",
        "%m.%d.%y",
    ]
    for pattern in patterns:
        try:
            return datetime.strptime(raw, pattern).strftime("%Y-%m-%d")
        except Exception:
            continue
    return raw


def _to_timestamp(value):
    """
    Parse timestamp-like values into epoch seconds (float). Returns None on failure.
    """
    if isinstance(value, (int, float)):
        return float(value)
    if not value:
        return None
    text = str(value).strip()
    if not text:
        return None
    # Numeric string fast-path.
    try:
        return float(text)
    except Exception:
        pass
    # Common datetime string formats used in index/legacy paths.
    patterns = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d",
        "%m/%d/%Y %H:%M:%S",
        "%m/%d/%Y",
    ]
    for pattern in patterns:
        try:
            dt = datetime.strptime(text, pattern)
            return time.mktime(dt.timetuple())
        except Exception:
            continue
    return None


def _format_ts(ts_value):
    if ts_value is None:
        return ""
    try:
        return datetime.fromtimestamp(float(ts_value)).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return ""


def _is_missing_value(value):
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    return False


def _set_if_missing(record, key, value):
    if not isinstance(record, dict):
        return False
    if _is_missing_value(value):
        return False
    current = record.get(key)
    if not _is_missing_value(current):
        return False
    if isinstance(value, str):
        record[key] = value.strip()
    else:
        record[key] = value
    return True


def _resolve_receipt_path(receipts_root, receipt_file):
    receipt_file = str(receipt_file or '').strip()
    if not receipt_file:
        return ''
    if os.path.isabs(receipt_file):
        return receipt_file
    if not receipts_root:
        return receipt_file
    return os.path.join(receipts_root, receipt_file)


def _needs_receipt_enrichment(record):
    if not isinstance(record, dict):
        return False
    for key in (
        'patient_name',
        'member_first_name',
        'member_last_name',
        'member_id',
        'payer_id',
        'primary_insurance',
        'service_start_date',
        'service_end_date',
        'dos',
        'patient_id',
        'internal_chart',
    ):
        if not str(record.get(key) or '').strip():
            return True
    return False


def _enrich_record_from_receipt(record, receipts_root):
    """
    Backfill sparse submission-index rows from their saved 837p receipt.

    Older index rows may contain only source/date/receipt metadata, which makes
    Claim Status display many Unknown patients and payers. The receipt is the
    local source of truth for member name, member ID, payer, and service dates.
    """
    if not isinstance(record, dict):
        return record

    receipt_file = record.get('receipt_file') or record.get('file_name')
    receipt_path = _resolve_receipt_path(receipts_root, receipt_file)
    if not receipt_path or not os.path.exists(receipt_path):
        return record

    x12_data = _extract_member_data_from_x12_cached(receipt_path)
    if not isinstance(x12_data, dict) or not x12_data:
        return record

    first = str(x12_data.get('member_first_name') or '').strip()
    last = str(x12_data.get('member_last_name') or '').strip()
    member_id = str(x12_data.get('member_id') or '').strip()
    payer_id = str(x12_data.get('payer_id') or '').strip()
    payer_name = str(x12_data.get('payer_name') or '').strip()
    service_start = str(x12_data.get('service_start_date') or '').strip()
    service_end = str(x12_data.get('service_end_date') or '').strip()

    _set_if_missing(record, 'member_first_name', first)
    _set_if_missing(record, 'member_last_name', last)
    if first or last:
        _set_if_missing(record, 'patient_name', '{} {}'.format(first, last).strip())

    _set_if_missing(record, 'member_id', member_id)
    if member_id and not str(record.get('patient_id') or '').strip() and not str(record.get('internal_chart') or '').strip():
        record['patient_id'] = member_id

    _set_if_missing(record, 'payer_id', payer_id)
    _set_if_missing(record, 'primary_insurance', payer_name)
    _set_if_missing(record, 'service_start_date', service_start)
    _set_if_missing(record, 'service_end_date', service_end)
    if service_start:
        _set_if_missing(record, 'dos', _normalize_dos_value(service_start))

    return record

def _record_timestamp(record):
    """
    Resolve best timestamp for ordering/lineage:
    1) submitted_at
    2) DAT file mtime
    3) receipt file mtime
    """
    if not isinstance(record, dict):
        return None
    ts = _to_timestamp(record.get("submitted_at"))
    if ts is not None:
        return ts

    dat_path = record.get("dat_file")
    if dat_path and os.path.exists(dat_path):
        try:
            return float(os.path.getmtime(dat_path))
        except Exception:
            pass

    receipt_path = record.get("receipt_file")
    if receipt_path:
        # receipt_file may be basename; only mtime when absolute path exists.
        if os.path.isabs(receipt_path) and os.path.exists(receipt_path):
            try:
                return float(os.path.getmtime(receipt_path))
            except Exception:
                pass
    return None


def _normalize_identity_value(value):
    return str(value or "").strip()


def _resolve_record_payer(record):
    return _normalize_identity_value(record.get("payer_id") or record.get("primary_insurance"))


def _resolve_record_patient(record):
    return _normalize_identity_value(
        record.get("patient_id") or record.get("member_id") or record.get("patid")
    )


def _build_claim_family_key(record):
    """
    Claim-family grouping key for latest-variant consolidation.
    Family: patient + payer + DOS.
    """
    patient_id = _resolve_record_patient(record)
    payer = _resolve_record_payer(record)
    dos = _normalize_dos_value(record.get("dos") or record.get("service_start_date"))
    if not patient_id or not payer or not dos:
        return ""
    return "|".join([patient_id, payer, dos])


def _merge_missing_fields(primary, secondary):
    """
    Fill empty fields in primary record from secondary record.
    Keeps primary authoritative while enriching sparse rows.
    """
    if not isinstance(primary, dict) or not isinstance(secondary, dict):
        return primary

    for key in [
        "patient_name",
        "name",
        "member_first_name",
        "member_last_name",
        "memberFirstName",
        "memberLastName",
        "member_id",
        "patient_id",
        "patid",
        "payer_id",
        "primary_insurance",
        "dos",
        "service_start_date",
        "service_end_date",
        "transactionId",
        "transaction_id",
        "claim_key",
        "submitted_claim_number",
        "dat_file",
        "receipt_file",
    ]:
        primary_val = primary.get(key)
        if primary_val is None or (isinstance(primary_val, str) and not primary_val.strip()):
            secondary_val = secondary.get(key)
            if secondary_val is not None:
                if isinstance(secondary_val, str):
                    if secondary_val.strip():
                        primary[key] = secondary_val
                else:
                    primary[key] = secondary_val
    return primary


def _backfill_identity_fields(record):
    """
    Best-effort identity backfill for sparse rows.
    - patient_id from claim_key first segment when absent
    - patient_name from member first/last names when absent
    """
    if not isinstance(record, dict):
        return record

    patient_id = str(record.get('patient_id') or '').strip()
    claim_key = str(record.get('claim_key') or '').strip()
    if (not patient_id) and claim_key:
        # claim_key shape: internal_chart|payer|dos|service_hash
        if '|' in claim_key:
            first = claim_key.split('|', 1)[0].strip()
            if first:
                record['patient_id'] = first

    patient_name = str(record.get('patient_name') or '').strip()
    if not patient_name:
        first_name = str(record.get('member_first_name') or record.get('memberFirstName') or '').strip()
        last_name = str(record.get('member_last_name') or record.get('memberLastName') or '').strip()
        if first_name or last_name:
            record['patient_name'] = "{} {}".format(first_name, last_name).strip()
    return record


def _query_recent_submission_sources(config, days, limit):
    """
    Shared source query helper used by both legacy and consolidated views.
    """
    try:
        if extract_medilink_config:
            medi = extract_medilink_config(config)
            if not medi:
                medi = config.get("MediLink_Config", {})
        else:
            medi = config.get("MediLink_Config", {})
    except Exception:
        medi = config.get("MediLink_Config", {})

    receipts_root = medi.get("local_claims_path")
    dat_directory = medi.get("Z_DAT_PATH")
    if dat_directory:
        if os.path.isfile(dat_directory):
            dat_directory = os.path.dirname(dat_directory)
        elif not os.path.isdir(dat_directory):
            dat_directory = None

    index_results = []
    receipt_results = []
    dat_results = []

    if receipts_root:
        try:
            index_results = get_recent_submissions_from_index(receipts_root, days, limit)
        except Exception as e:
            if MediLink_ConfigLoader:
                MediLink_ConfigLoader.log(
                    "Error querying JSONL index: {}".format(e),
                    level="WARNING",
                )
    else:
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(
                "local_claims_path not configured, skipping JSONL index query",
                level="INFO",
            )

    if receipts_root:
        try:
            receipt_results = get_recent_submissions_from_receipts(receipts_root, days, limit)
        except Exception as e:
            if MediLink_ConfigLoader:
                MediLink_ConfigLoader.log(
                    "Error querying 837p receipts: {}".format(e),
                    level="WARNING",
                )

    if dat_directory and os.path.isdir(dat_directory):
        try:
            dat_results = get_recent_submissions_from_dat_files(dat_directory, config, days, limit)
        except Exception as e:
            if MediLink_ConfigLoader:
                MediLink_ConfigLoader.log(
                    "Error querying DAT files: {}".format(e),
                    level="WARNING",
                )
    else:
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(
                "Z_DAT_PATH not configured or directory does not exist, skipping DAT file query",
                level="INFO",
            )

    return index_results, receipt_results, dat_results


def get_recent_submissions_from_all_sources(config, days=30, limit=50):
    """
    Query recent submissions from all available data sources and combine results.
    
    Sources queried (in priority order):
    1. JSONL submission index (most complete, has transactionId)
    2. 837p receipt files (generated X12, may not be indexed yet)
    3. DAT source files (original fixed-width files, pre-submission)
    
    Args:
        config: Configuration dictionary
        days: Number of days to look back (default 30)
        limit: Maximum number of results to return (default 50)
    
    Returns:
        list: Unified list of submission records sorted by most recent first
    """
    if MediLink_ConfigLoader:
        MediLink_ConfigLoader.log(
            "Starting multi-source submission query: days={}, limit={}".format(days, limit),
            level="INFO"
        )
    
    # Query source buckets, then combine.
    index_results, receipt_results, dat_results = _query_recent_submission_sources(
        config, days, limit
    )
    if MediLink_ConfigLoader:
        MediLink_ConfigLoader.log(
            "Found {} submissions from JSONL index".format(len(index_results)),
            level="INFO"
        )
        MediLink_ConfigLoader.log(
            "Found {} submissions from 837p receipt files".format(len(receipt_results)),
            level="INFO"
        )
        MediLink_ConfigLoader.log(
            "Found {} submissions from DAT source files".format(len(dat_results)),
            level="INFO"
        )

    combined_results = combine_and_deduplicate_submissions(
        index_results, receipt_results, dat_results
    )
    
    # Limit results
    if len(combined_results) > limit:
        combined_results = combined_results[:limit]
    
    if MediLink_ConfigLoader:
        MediLink_ConfigLoader.log(
            "Multi-source query complete: {} total submissions after deduplication".format(
                len(combined_results)
            ),
            level="INFO"
        )
    
    return combined_results


def build_consolidated_latest_variants(index_results, receipt_results, dat_results):
    """
    Build latest-variant rows by claim family.

    Family key: patient_id + payer + DOS.
    Winner rule:
      - If any index rows exist in family, choose latest index row by timestamp
      - Otherwise choose latest row by timestamp across all sources

    Returns:
        list of normalized winner rows with lineage metadata:
          first_seen_at, latest_seen_at, first_seen_str, latest_seen_str,
          family_key, superseded_count, source_hint
    """
    groups = {}
    sparse_rows = []

    # Build source-stable candidate list.
    all_results = []
    for record in (index_results or []):
        if isinstance(record, dict):
            item = dict(record)
            item["source"] = item.get("source") or "index"
            item["source_priority"] = item.get("source_priority", 1)
            all_results.append(item)
    for record in (receipt_results or []):
        if isinstance(record, dict):
            item = dict(record)
            item["source"] = item.get("source") or "receipt"
            item["source_priority"] = item.get("source_priority", 2)
            all_results.append(item)
    for record in (dat_results or []):
        if isinstance(record, dict):
            item = dict(record)
            item["source"] = item.get("source") or "dat"
            item["source_priority"] = item.get("source_priority", 3)
            all_results.append(item)

    # Attach normalized helpers used for grouping/ranking.
    for idx, item in enumerate(all_results):
        _backfill_identity_fields(item)
        item["_row_order"] = idx
        item["_ts"] = _record_timestamp(item)
        item["_family_key"] = _build_claim_family_key(item)
        if item["_family_key"]:
            groups.setdefault(item["_family_key"], []).append(item)
        else:
            sparse_rows.append(item)

    winners = []

    # Resolve grouped family winners.
    for family_key, entries in groups.items():
        index_entries = [e for e in entries if e.get("source") == "index"]
        candidate_pool = index_entries if index_entries else entries
        candidate_pool_sorted = sorted(
            candidate_pool,
            key=lambda e: (
                e.get("_ts") is not None,           # rows with usable ts first
                e.get("_ts") or 0,                  # newest timestamp
                -int(e.get("source_priority", 999)),# stable tie-break
                -int(e.get("_row_order", 0)),       # latest appearance
            ),
            reverse=True
        )
        winner = dict(candidate_pool_sorted[0])

        # Index-first enrichment: fill missing fields from family lineage.
        lineage_for_merge = sorted(
            entries,
            key=lambda e: (
                int(e.get("source_priority", 999)),
                -(e.get("_ts") or 0),
            )
        )
        for entry in lineage_for_merge:
            _merge_missing_fields(winner, entry)
        _backfill_identity_fields(winner)

        ts_values = [e.get("_ts") for e in entries if e.get("_ts") is not None]
        first_seen = min(ts_values) if ts_values else None
        latest_seen = max(ts_values) if ts_values else None

        winner["family_key"] = family_key
        winner["first_seen_at"] = first_seen
        winner["latest_seen_at"] = latest_seen
        winner["first_seen_str"] = _format_ts(first_seen)
        winner["latest_seen_str"] = _format_ts(latest_seen)
        winner["source_hint"] = winner.get("source", "")
        winner["superseded_count"] = max(0, len(entries) - 1)
        winner["dos"] = _normalize_dos_value(winner.get("dos") or winner.get("service_start_date"))
        winner.pop("_family_key", None)
        winner.pop("_row_order", None)
        winner.pop("_ts", None)
        winners.append(winner)

    # Keep sparse rows as singleton winners so legacy/sparse data still appears.
    for row in sparse_rows:
        ts_value = row.get("_ts")
        winner = dict(row)
        sparse_key = "sparse|{}|{}".format(
            winner.get("source", "unknown"),
            winner.get("_row_order", 0),
        )
        winner["family_key"] = sparse_key
        winner["first_seen_at"] = ts_value
        winner["latest_seen_at"] = ts_value
        winner["first_seen_str"] = _format_ts(ts_value)
        winner["latest_seen_str"] = _format_ts(ts_value)
        winner["source_hint"] = winner.get("source", "")
        winner["superseded_count"] = 0
        winner["dos"] = _normalize_dos_value(winner.get("dos") or winner.get("service_start_date"))
        winner.pop("_family_key", None)
        winner.pop("_row_order", None)
        winner.pop("_ts", None)
        winners.append(winner)

    winners.sort(
        key=lambda row: (
            row.get("latest_seen_at") is not None,
            row.get("latest_seen_at") or 0,
            -int(row.get("source_priority", 999)),
        ),
        reverse=True
    )
    return winners


def get_consolidated_latest_variants_from_all_sources(config, days=120, limit=150):
    """
    Index-first consolidated latest-variant view used by Submit Claims and Claim Status.

    The function intentionally queries a larger source window than the final limit so
    family grouping can resolve winners and lineage dates accurately.
    """
    if MediLink_ConfigLoader:
        MediLink_ConfigLoader.log(
            "Starting consolidated latest-variant query: days={}, limit={}".format(days, limit),
            level="DEBUG"
        )

    source_limit = max(int(limit or 0) * 4, 200)
    index_results, receipt_results, dat_results = _query_recent_submission_sources(
        config, days, source_limit
    )
    variants = build_consolidated_latest_variants(index_results, receipt_results, dat_results)

    if limit and len(variants) > int(limit):
        variants = variants[:int(limit)]

    if MediLink_ConfigLoader:
        MediLink_ConfigLoader.log(
            "Consolidated latest-variant query complete: {} rows".format(len(variants)),
            level="DEBUG"
        )
    return variants


def get_recent_submissions_from_index(receipts_root, days=30, limit=50):
    """
    Query recent submissions from JSONL submission index.
    
    Args:
        receipts_root: Path to receipts directory containing submission_index.jsonl
        days: Number of days to look back
        limit: Maximum number of results
    
    Returns:
        list: List of submission records from index
    """
    from MediCafe.submission_index import _index_path, _is_submission_index_entry
    
    results = []
    cutoff_time = time.time() - (days * 86400)
    total_lines = 0
    valid_lines = 0
    invalid_lines = 0
    invalid_line_numbers = []
    
    index_path = _index_path(receipts_root)
    if not os.path.exists(index_path):
        _set_submission_index_health(
            index_path=index_path,
            exists=False,
            total_lines=0,
            valid_lines=0,
            invalid_lines=0,
            status="missing",
            error_text="index file missing",
        )
        return results
    
    try:
        with open(index_path, 'r') as f:
            for line_no, line in enumerate(f, start=1):
                raw_line = line.strip()
                if not raw_line:
                    continue
                total_lines += 1
                try:
                    entry = json.loads(raw_line)
                    if not isinstance(entry, dict):
                        invalid_lines += 1
                        if len(invalid_line_numbers) < 5:
                            invalid_line_numbers.append(line_no)
                        continue

                    # Skip ack/timeline events; the status table needs submission rows.
                    if not _is_submission_index_entry(entry):
                        continue

                    # Check timestamp after filtering non-submission rows.
                    submitted_at = entry.get('submitted_at', '')
                    timestamp = _to_timestamp(submitted_at)
                    if timestamp is not None and timestamp < cutoff_time:
                        continue

                    valid_lines += 1

                    # Add source metadata and repair sparse legacy rows from their receipt.
                    entry['source'] = 'index'
                    entry['source_priority'] = 1
                    if _needs_receipt_enrichment(entry):
                        _enrich_record_from_receipt(entry, receipts_root)
                    _backfill_identity_fields(entry)
                    results.append(entry)
                    
                except Exception:
                    invalid_lines += 1
                    if len(invalid_line_numbers) < 5:
                        invalid_line_numbers.append(line_no)
                    continue
        
        # Sort by most recent first (normalize timestamps for consistent comparison)
        def get_timestamp(record):
            submitted_at = record.get('submitted_at', '')
            if isinstance(submitted_at, (int, float)):
                return float(submitted_at)
            elif isinstance(submitted_at, str):
                try:
                    from datetime import datetime
                    dt = datetime.strptime(submitted_at, "%Y-%m-%d %H:%M:%S")
                    return time.mktime(dt.timetuple())
                except Exception:
                    return 0
            return 0
        
        results.sort(key=get_timestamp, reverse=True)
        
        if len(results) > limit:
            results = results[:limit]

        _set_submission_index_health(
            index_path=index_path,
            exists=True,
            total_lines=total_lines,
            valid_lines=valid_lines,
            invalid_lines=invalid_lines,
            status="ok" if invalid_lines == 0 else "degraded",
            error_text="",
        )

        if MediLink_ConfigLoader:
            if invalid_lines > 0:
                MediLink_ConfigLoader.log(
                    "Submission index health degraded: invalid_lines={} total_lines={} valid_lines={} path='{}' sample_line_numbers={}".format(
                        invalid_lines,
                        total_lines,
                        valid_lines,
                        index_path,
                        ",".join([str(n) for n in invalid_line_numbers]) or "none",
                    ),
                    level="WARNING"
                )
            else:
                MediLink_ConfigLoader.log(
                    "Submission index health: invalid_lines=0 total_lines={} path='{}'".format(
                        total_lines,
                        index_path,
                    ),
                    level="DEBUG"
                )
            
    except Exception as e:
        _set_submission_index_health(
            index_path=index_path,
            exists=True,
            total_lines=total_lines,
            valid_lines=valid_lines,
            invalid_lines=invalid_lines,
            status="error",
            error_text=str(e),
        )
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(
                "Submission index health check failed: {}".format(e),
                level="WARNING"
            )
    
    return results


def get_recent_submissions_from_receipts(receipts_root, days=30, limit=50):
    """
    Scan 837p receipt files directory for recent submissions.
    
    Args:
        receipts_root: Path to receipts directory containing .837p files
        days: Number of days to look back
        limit: Maximum number of results
    
    Returns:
        list: List of submission records from 837p files
    """
    results = []
    cutoff_time = time.time() - (days * 86400)
    
    if not os.path.isdir(receipts_root):
        return results
    
    try:
        # Scan for .837p files
        for filename in os.listdir(receipts_root):
            if not filename.endswith('.837p'):
                continue
            
            filepath = os.path.join(receipts_root, filename)
            try:
                mtime = os.path.getmtime(filepath)
                if mtime < cutoff_time:
                    continue
                
                # Create basic record from file
                record = {
                    'source': 'receipt',
                    'source_priority': 2,
                    'receipt_file': filepath,
                    'submitted_at': mtime,
                    'dos': '',  # Will be extracted by x12_utils if needed
                    'payer_id': '',
                    'primary_insurance': '',
                    'patient_id': '',
                }

                # Best-effort enrichment from X12 contents so UI can show patient info.
                # Keep failures non-fatal to preserve resilience on legacy environments.
                x12_data = _extract_member_data_from_x12_cached(filepath)
                if isinstance(x12_data, dict):
                    first = (x12_data.get('member_first_name') or '').strip()
                    last = (x12_data.get('member_last_name') or '').strip()
                    if first:
                        record['member_first_name'] = first
                    if last:
                        record['member_last_name'] = last
                    if first or last:
                        record['patient_name'] = "{} {}".format(first, last).strip()

                    member_id = (x12_data.get('member_id') or '').strip()
                    if member_id:
                        record['patient_id'] = member_id

                    payer_id = (x12_data.get('payer_id') or '').strip()
                    if payer_id:
                        record['payer_id'] = payer_id

                    # Populate dos so receipt records can deduplicate (dedup requires payer_id, dos, patient_id)
                    service_start = (x12_data.get('service_start_date') or '').strip()
                    if service_start:
                        record['dos'] = service_start
                
                results.append(record)
                
            except Exception:
                continue
        
        # Sort by most recent first
        results.sort(key=lambda x: x.get('submitted_at', 0), reverse=True)
        
        if len(results) > limit:
            results = results[:limit]
            
    except Exception:
        pass
    
    return results


def get_recent_submissions_from_dat_files(dat_directory, config, days=30, limit=50):
    """
    Scan DAT source files directory for recent patient-level records.
    
    Args:
        dat_directory: Path to directory containing .DAT files
        config: Configuration dictionary
        days: Number of days to look back
        limit: Maximum number of results
    
    Returns:
        list: List of submission records from DAT files
    """
    results = []
    cutoff_time = time.time() - (days * 86400)

    if not os.path.isdir(dat_directory):
        return results

    try:
        try:
            from MediCafe.dat_utils import extract_member_data_from_dat_file
        except Exception:
            extract_member_data_from_dat_file = None

        dat_files = []
        for filename in os.listdir(dat_directory):
            if not filename.lower().endswith('.dat'):
                continue
            filepath = os.path.join(dat_directory, filename)
            try:
                mtime = os.path.getmtime(filepath)
            except Exception:
                continue
            if mtime < cutoff_time:
                continue
            dat_files.append((mtime, filepath))

        dat_files.sort(key=lambda x: x[0], reverse=True)

        for mtime, filepath in dat_files:
            if limit and len(results) >= int(limit):
                break

            # Always include at least one file-level row as fallback.
            base_record = {
                'source': 'dat',
                'source_priority': 3,
                'dat_file': filepath,
                'submitted_at': mtime,
                'dos': '',
                'payer_id': '',
                'primary_insurance': '',
                'patient_id': '',
            }

            parsed_rows = []
            if extract_member_data_from_dat_file:
                try:
                    parsed_rows = extract_member_data_from_dat_file(filepath, config) or []
                except Exception:
                    parsed_rows = []

            if not parsed_rows:
                results.append(base_record)
                continue

            for parsed in parsed_rows:
                if limit and len(results) >= int(limit):
                    break
                if not isinstance(parsed, dict):
                    continue

                first = str(parsed.get('first_name', '') or '').strip()
                last = str(parsed.get('last_name', '') or '').strip()
                patient_name = "{} {}".format(first, last).strip()
                record = {
                    'source': 'dat',
                    'source_priority': 3,
                    'dat_file': filepath,
                    'submitted_at': mtime,
                    'dos': _normalize_dos_value(parsed.get('service_date') or parsed.get('dos')),
                    'payer_id': str(parsed.get('payer_id', '') or '').strip(),
                    'primary_insurance': str(parsed.get('insurance_name', '') or '').strip(),
                    'patient_id': str(parsed.get('patient_id') or parsed.get('member_id') or parsed.get('patid') or '').strip(),
                    'member_id': str(parsed.get('member_id', '') or '').strip(),
                    'member_first_name': first,
                    'member_last_name': last,
                    'patient_name': patient_name,
                    'patid': str(parsed.get('patid', '') or '').strip(),
                }
                results.append(record)

        results.sort(key=lambda x: x.get('submitted_at', 0), reverse=True)
        if limit and len(results) > int(limit):
            results = results[:int(limit)]

    except Exception:
        pass

    return results


def build_current_export_rows_from_dat_paths(dat_paths, config, include_file_fallback=True):
    """
    Parse explicit .dat file paths into submission-shaped records (source=dat).
    Used for Submit claims current-export-first scope (detected files only).

    Does not scan directories; only processes existing files in dat_paths.
    Compatible with build_consolidated_latest_variants([], [], rows) for family dedupe.

    Args:
        include_file_fallback: If False, do not append a sparse per-file row when parsing
            returns no patients (submit scope should treat that as parse failure / prompt).
    """
    results = []
    if not dat_paths:
        return results
    try:
        from MediCafe.dat_utils import extract_member_data_from_dat_file
    except Exception:
        extract_member_data_from_dat_file = None

    seen_paths = set()
    for raw_path in dat_paths:
        if not raw_path or not isinstance(raw_path, str):
            continue
        if not raw_path.lower().endswith('.dat'):
            continue
        try:
            filepath = os.path.normpath(os.path.abspath(raw_path))
        except Exception:
            continue
        if filepath in seen_paths:
            continue
        seen_paths.add(filepath)
        if not os.path.isfile(filepath):
            continue
        try:
            mtime = os.path.getmtime(filepath)
        except Exception:
            mtime = time.time()

        base_record = {
            'source': 'dat',
            'source_priority': 3,
            'dat_file': filepath,
            'submitted_at': mtime,
            'dos': '',
            'payer_id': '',
            'primary_insurance': '',
            'patient_id': '',
        }

        parsed_rows = []
        if extract_member_data_from_dat_file:
            try:
                parsed_rows = extract_member_data_from_dat_file(filepath, config) or []
            except Exception:
                parsed_rows = []

        if not parsed_rows:
            if include_file_fallback:
                results.append(base_record)
            continue

        for parsed in parsed_rows:
            if not isinstance(parsed, dict):
                continue
            first = str(parsed.get('first_name', '') or '').strip()
            last = str(parsed.get('last_name', '') or '').strip()
            patient_name = "{} {}".format(first, last).strip()
            payer_display = str(parsed.get('insurance_name', '') or '').strip()
            record = {
                'source': 'dat',
                'source_priority': 3,
                'dat_file': filepath,
                'submitted_at': mtime,
                'dos': _normalize_dos_value(parsed.get('service_date') or parsed.get('dos')),
                'payer_id': str(parsed.get('payer_id', '') or '').strip(),
                'payer_display': payer_display,
                'primary_insurance': payer_display,
                'patient_id': str(parsed.get('patient_id') or parsed.get('member_id') or parsed.get('patid') or '').strip(),
                'member_id': str(parsed.get('member_id', '') or '').strip(),
                'member_first_name': first,
                'member_last_name': last,
                'patient_name': patient_name,
                'patid': str(parsed.get('patid', '') or '').strip(),
            }
            results.append(record)

    try:
        results.sort(key=lambda x: x.get('submitted_at', 0), reverse=True)
    except Exception:
        pass
    return results


def combine_and_deduplicate_submissions(index_results, receipt_results, dat_results):
    """
    Combine and deduplicate submission records from multiple sources.
    
    Deduplication strategy:
    - Prefer index records (most complete, priority 1)
    - Then receipt records (have X12, priority 2)
    - Then DAT records (source files, priority 3)
    - Deduplicate by (payer_id, dos, patient_id) when available
    
    Args:
        index_results: List of records from JSONL index
        receipt_results: List of records from 837p files
        dat_results: List of records from DAT files
    
    Returns:
        list: Combined and deduplicated list sorted by most recent first
    """
    # Use dict to track unique submissions by key
    seen = {}
    combined = []
    
    # Process in priority order (index first, then receipts, then DAT)
    all_results = index_results + receipt_results + dat_results
    
    for record in all_results:
        # Try to create deduplication key
        payer_id = record.get('payer_id', '')
        dos = record.get('dos', '')
        patient_id = record.get('patient_id', '')
        
        # Deduplicate only when claim identity is sufficiently specific.
        # If patient_id is missing, payer+DOS can collide across multiple patients.
        if not payer_id or not dos or not patient_id:
            combined.append(record)
            continue
        
        # Create key for deduplication
        key = "{}_{}_{}".format(payer_id, dos, patient_id)
        
        # Check if we've seen this before
        if key in seen:
            existing = seen[key]
            # Always backfill missing data from duplicate record.
            _merge_missing_fields(existing, record)

            # Keep the one with higher priority (lower priority number)
            if record.get('source_priority', 999) < existing.get('source_priority', 999):
                # Replace with higher priority record
                _merge_missing_fields(record, existing)
                seen[key] = record
                # Remove old record from combined
                try:
                    combined.remove(existing)
                except ValueError:
                    pass
                combined.append(record)
        else:
            seen[key] = record
            combined.append(record)
    
    # Sort by most recent first with mixed timestamp-format safety.
    combined.sort(
        key=lambda x: (_record_timestamp(x) is not None, _record_timestamp(x) or 0),
        reverse=True
    )
    
    return combined
