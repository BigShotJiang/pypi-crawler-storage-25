# -*- coding: utf-8 -*-
"""
Evidence mode resolver (XP-compatible: Python 3.4).

This module intentionally keeps the bundle decision tree small:

* run_evidence: one completed run can be used as decisive evidence.
* live_status: a pipeline run is active or newer than completed evidence; attach
  current status only.
* incoherent_state: the lab state points at mismatched or missing decisive run
  evidence; attach a small mismatch report instead of stale "latest" artifacts.
"""
from __future__ import print_function

import json
import os


MODE_RUN_EVIDENCE = "run_evidence"
MODE_LIVE_STATUS = "live_status"
MODE_INCOHERENT_STATE = "incoherent_state"


def _safe_str(value):
    if value is None:
        return ""
    try:
        return str(value).strip()
    except Exception:
        return ""


def _read_json_dict(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            return payload
    except Exception:
        pass
    return {}


def _merge_scalar(state, cursor, key):
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    val = _safe_str(st.get(key))
    if not val:
        val = _safe_str(cr.get(key))
    return val


def _handoff_pipeline_run_id(path):
    payload = _read_json_dict(path)
    rid = _safe_str(payload.get("pipeline_run_id"))
    if rid:
        return rid
    base = os.path.basename(_safe_str(path))
    prefix = "phase_c_execution_handoff_"
    suffix = ".json"
    if base.startswith(prefix) and base.endswith(suffix):
        return base[len(prefix):-len(suffix)]
    return ""


def _summary_exists_for_phase_c(lab_root, state, cursor):
    c_run = _merge_scalar(state, cursor, "last_phase_c_run_id")
    if not c_run:
        return True, "", ""
    path = os.path.join(_safe_str(lab_root), "reports", "ingest_write_summary_{0}.json".format(c_run))
    return os.path.isfile(path), c_run, path


def resolve_evidence_mode(lab_root, bundle_kind="", requested_run_id="", send_source="",
                          diagnostics_state=None, run_cursor=None):
    """
    Return a dict describing whether bundle contents may be completed-run
    evidence, live status only, or incoherent state evidence.
    """
    root = _safe_str(lab_root)
    state = diagnostics_state if isinstance(diagnostics_state, dict) else _read_json_dict(
        os.path.join(root, "diagnostics_state.json"))
    cursor = run_cursor if isinstance(run_cursor, dict) else _read_json_dict(
        os.path.join(root, "run_cursor.json"))

    active = _merge_scalar(state, cursor, "active_run_id")
    completed = _merge_scalar(state, cursor, "last_shadow_pipeline_run_id")
    selected = _safe_str(requested_run_id) or completed
    pipeline_state = _merge_scalar(state, cursor, "pipeline_state").lower()
    bundle_kind = _safe_str(bundle_kind)

    out = {
        "schema_version": 1,
        "mode": MODE_RUN_EVIDENCE,
        "selected_run_id": selected,
        "active_run_id": active,
        "last_completed_run_id": completed,
        "coherence_status": "ready",
        "blocking_reason": "",
        "allowed_current_artifacts": "completed_run",
        "decisive_run_evidence_current": True,
        "current_decision": "send_coherent_completed_run_evidence",
        "bundle_kind": bundle_kind,
        "send_source": _safe_str(send_source),
    }

    if active and ((completed and active != completed) or pipeline_state in ("running", "bootstrapping")):
        out["mode"] = MODE_LIVE_STATUS
        out["selected_run_id"] = active
        out["coherence_status"] = "live_status"
        out["blocking_reason"] = "active_run_differs_from_completed_run"
        out["allowed_current_artifacts"] = "live_state_only"
        out["decisive_run_evidence_current"] = False
        out["current_decision"] = "send_live_status_wait_for_completed_run"
        return out

    if not selected and bundle_kind in ("run_evidence_bundle", "phase_f_evidence"):
        out["mode"] = MODE_INCOHERENT_STATE
        out["coherence_status"] = "review_required"
        out["blocking_reason"] = "completed_run_id_missing"
        out["allowed_current_artifacts"] = "state_and_incoherence_report"
        out["decisive_run_evidence_current"] = False
        out["current_decision"] = "send_incoherent_state_report"
        return out

    handoff_path = _merge_scalar(state, cursor, "last_phase_c_execution_handoff_report_path")
    if handoff_path and os.path.isfile(handoff_path) and selected:
        handoff_rid = _handoff_pipeline_run_id(handoff_path)
        if handoff_rid and handoff_rid != selected:
            out["mode"] = MODE_INCOHERENT_STATE
            out["coherence_status"] = "review_required"
            out["blocking_reason"] = "phase_c_handoff_run_id_mismatch"
            out["allowed_current_artifacts"] = "state_and_incoherence_report"
            out["decisive_run_evidence_current"] = False
            out["current_decision"] = "send_incoherent_state_report"
            out["handoff_run_id"] = handoff_rid
            out["handoff_path"] = handoff_path
            return out

    b_sha = _merge_scalar(state, cursor, "last_manifest_sha256")
    c_sha = _merge_scalar(state, cursor, "last_ingest_manifest_sha256")
    if b_sha and c_sha and b_sha != c_sha:
        out["mode"] = MODE_INCOHERENT_STATE
        out["coherence_status"] = "review_required"
        out["blocking_reason"] = "phase_c_manifest_sha_mismatch"
        out["allowed_current_artifacts"] = "state_and_incoherence_report"
        out["decisive_run_evidence_current"] = False
        out["current_decision"] = "send_incoherent_state_report"
        out["last_manifest_sha256"] = b_sha
        out["last_ingest_manifest_sha256"] = c_sha
        return out

    if state.get("last_phase_c_ok") is False:
        exists, c_run, c_path = _summary_exists_for_phase_c(root, state, cursor)
        if c_run and not exists:
            out["mode"] = MODE_INCOHERENT_STATE
            out["coherence_status"] = "review_required"
            out["blocking_reason"] = "phase_c_summary_missing_for_recorded_run"
            out["allowed_current_artifacts"] = "state_and_incoherence_report"
            out["decisive_run_evidence_current"] = False
            out["current_decision"] = "send_incoherent_state_report"
            out["missing_phase_c_summary_path"] = c_path
            out["phase_c_run_id"] = c_run
            return out

    return out


def evidence_mode_report_text(mode_info):
    info = mode_info if isinstance(mode_info, dict) else {}
    lines = [
        "Evidence Mode Report",
        "schema_version={0}".format(info.get("schema_version", 1)),
        "mode={0}".format(_safe_str(info.get("mode"))),
        "selected_run_id={0}".format(_safe_str(info.get("selected_run_id")) or "-"),
        "active_run_id={0}".format(_safe_str(info.get("active_run_id")) or "-"),
        "last_completed_run_id={0}".format(_safe_str(info.get("last_completed_run_id")) or "-"),
        "coherence_status={0}".format(_safe_str(info.get("coherence_status")) or "-"),
        "blocking_reason={0}".format(_safe_str(info.get("blocking_reason")) or "-"),
        "decisive_run_evidence_current={0}".format(bool(info.get("decisive_run_evidence_current"))),
        "current_decision={0}".format(_safe_str(info.get("current_decision")) or "-"),
        "allowed_current_artifacts={0}".format(_safe_str(info.get("allowed_current_artifacts")) or "-"),
    ]
    if info.get("handoff_run_id"):
        lines.append("handoff_run_id={0}".format(_safe_str(info.get("handoff_run_id"))))
    if info.get("handoff_path"):
        lines.append("handoff_path={0}".format(_safe_str(info.get("handoff_path"))))
    if info.get("missing_phase_c_summary_path"):
        lines.append("missing_phase_c_summary_path={0}".format(_safe_str(info.get("missing_phase_c_summary_path"))))
    if info.get("last_manifest_sha256"):
        lines.append("last_manifest_sha256={0}".format(_safe_str(info.get("last_manifest_sha256"))))
    if info.get("last_ingest_manifest_sha256"):
        lines.append("last_ingest_manifest_sha256={0}".format(_safe_str(info.get("last_ingest_manifest_sha256"))))
    return "\n".join(lines) + "\n"
