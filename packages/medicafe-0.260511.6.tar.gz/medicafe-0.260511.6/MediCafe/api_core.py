# MediCafe/api_core.py
"""
Core API functionality for MediCafe.
Moved from MediLink to centralize shared API operations.

COMPATIBILITY: Python 3.4.4 and Windows XP compatible

TOKEN CACHE:
- In-memory, per-process. APIClientFactory.get_shared_client() and core_utils.get_api_client()
  return a singleton per process; tokens are reused within that process.
- Launcher commands (Deductible, Claims Status, etc.) run in separate subprocesses; each has
  its own empty cache. Multiple token acquisitions in one log session are expected, not a bug.
- Future: optional file-based cache for cross-process reuse (see docs/OPERATIONS_REFERENCE.md).
"""

import time, json, os, traceback, sys

from MediCafe import api_core_operations as _api_ops

# Import centralized logging configuration
try:
    from MediCafe.logging_config import DEBUG, CONSOLE_LOGGING
except ImportError:
    # Fallback to local flags if centralized config is not available
    DEBUG = False
    CONSOLE_LOGGING = False

# Set up project paths first
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

try:
    import yaml
except ImportError:
    yaml = None
try:
    import requests
except ImportError:
    requests = None

# Use core utilities for standardized imports
try:
    from MediCafe.core_utils import get_shared_config_loader
    MediLink_ConfigLoader = get_shared_config_loader()
except ImportError:
    try:
        from .core_utils import get_shared_config_loader
        MediLink_ConfigLoader = get_shared_config_loader()
    except ImportError:
        # Fallback to direct import
        from MediCafe.MediLink_ConfigLoader import MediLink_ConfigLoader

# CRITICAL: Ensure MediLink_ConfigLoader is available - this module requires it
if MediLink_ConfigLoader is None:
    raise ImportError(
        "[api_core] CRITICAL: MediLink_ConfigLoader module import failed. "
        "This module requires MediLink_ConfigLoader to function. "
        "Check PYTHONPATH, module dependencies, and ensure MediCafe package is properly installed."
    )

try:
    from MediCafe.network_route_helpers import handle_route_mismatch_404
except ImportError:
    def handle_route_mismatch_404(*args, **kwargs):
        return


try:
    from MediCafe import graphql_utils as MediLink_GraphQL
except ImportError:
    try:
        from MediLink import MediLink_GraphQL
    except ImportError:
        try:
            import graphql_utils as MediLink_GraphQL
        except ImportError:
            # Create a dummy module if graphql_utils is not available
            # BUG (minimally fixed): When graphql_utils is unavailable, DummyGraphQL
            # lacked OPTUMAI claims inquiry helpers used by get_claim_summary_by_provider.
            # Minimal fix implemented elsewhere: a capability guard disables OPTUMAI when
            # these methods are missing so fallback to UHCAPI proceeds without AttributeError.
            # Recommended next steps:
            # - Provide explicit no-op stubs here that raise NotImplementedError for clarity.
            # - Add a small shim that always exposes required methods to decouple import shapes.
            # - Add a config feature flag to enable/disable OPTUMAI claims inquiry.
            # - Add environment-based guard (dev/test default off) and metrics counter for use.
            # - Add unit tests for both capability-present and capability-absent paths.
            # Open question: should eligibility-only flows still run with a lightweight fallback query builder
            # when claims inquiry helpers are unavailable, or should GraphQL be fully disabled across all paths?
            class DummyGraphQL:
                GRAPHQL_AVAILABLE = False

                @staticmethod
                def build_eligibility_variables(**kwargs):
                    return kwargs

                @staticmethod
                def build_eligibility_request(graphql_variables):
                    return {
                        'query': '',
                        'variables': {'input': graphql_variables or {}}
                    }

                @staticmethod
                def build_optumai_enriched_request(graphql_variables):
                    return DummyGraphQL.build_eligibility_request(graphql_variables)

                @staticmethod
                def get_sample_eligibility_request():
                    return {'query': '', 'variables': {'input': {}}}

                @staticmethod
                def build_optumai_claims_inquiry_request(search_claim_input):
                    raise NotImplementedError("graphql_utils unavailable: OPTUMAI claims inquiry helpers are disabled")

                @staticmethod
                def transform_claims_inquiry_response_to_legacy(response):
                    return {
                        'statuscode': '503',
                        'message': 'graphql_utils unavailable: claims inquiry transform helper is disabled',
                        'claims': [],
                        'rawGraphQLResponse': response if isinstance(response, dict) else {}
                    }

                @staticmethod
                def transform_eligibility_response(response):
                    return response
            MediLink_GraphQL = DummyGraphQL()

try:
    from MediCafe.routing_reason_codes import (
        classify_routing_reason, next_step_hint, is_suppressible,
        UNSUPPORTED_PAYER, MEMBER_REQUIRED, NO_DATA, AUTH_ISSUE, TRANSPORT_ERROR
    )
except ImportError:
    classify_routing_reason = None
    next_step_hint = lambda rc: "Check logs for details."
    is_suppressible = lambda rc: False
    (UNSUPPORTED_PAYER, MEMBER_REQUIRED, NO_DATA, AUTH_ISSUE, TRANSPORT_ERROR) = (
        'unsupported_payer', 'member_required', 'no_data', 'auth_issue', 'transport_error')

_FALLBACK_LOG_ONCE = {}
_REQUEST_FAILURE_BATCH_STACK = []
_REQUEST_FAILURE_SUMMARY_LIMIT = 40

# AVAILITY Payer List rate limiting: 5 calls per second (demo app limit)
# Maintain last call timestamp to enforce 200ms minimum spacing
_AVAILITY_PAYER_LIST_LAST_CALL = 0

# Single canonical suppression source for routing. Replaces _OPTUMAI_PROVIDER_TIN_REQUIRES_MEMBER_PAYERS.
_ROUTING_SUPPRESSION_CACHE = {}  # {(payer_id, context): (reason_code, timestamp)}
_SUPPRESSION_TTL_SECONDS = 300  # 5 min
QUERY_CONTEXT_PROVIDER_TIN = 'provider_tin_search'


def _check_suppression(payer_id, context):
    """
    Check if payer/context is suppressed. Purge expired entries before lookup.
    Returns (bool, reason_code, hint) or (False, None, None) if not suppressed.
    """
    try:
        now = time.time()
        to_remove = []
        for key, val in _ROUTING_SUPPRESSION_CACHE.items():
            if len(val) >= 2 and (now - val[1]) > _SUPPRESSION_TTL_SECONDS:
                to_remove.append(key)
        for k in to_remove:
            _ROUTING_SUPPRESSION_CACHE.pop(k, None)
        key = (str(payer_id) if payer_id else '', str(context) if context else '')
        entry = _ROUTING_SUPPRESSION_CACHE.get(key)
        if entry and len(entry) >= 2:
            reason_code = entry[0]
            hint = next_step_hint(reason_code) if next_step_hint else "Check logs for details."
            return (True, reason_code, hint)
    except Exception:
        pass
    return (False, None, None)


def _add_suppression(payer_id, context, reason_code):
    """Store suppression for payer/context with current timestamp."""
    try:
        key = (str(payer_id) if payer_id else '', str(context) if context else '')
        _ROUTING_SUPPRESSION_CACHE[key] = (str(reason_code) if reason_code else 'unknown', time.time())
    except Exception:
        pass


def _log_routing_decision_once(payer_id, context, attempted, reason_code, fallback, hint):
    """Log one structured routing decision per dedup key."""
    key = "routing_decision_{}_{}_{}_{}_{}".format(
        payer_id or '', context or '', attempted or '', fallback or '', reason_code or '')
    msg = "[ROUTING_DECISION] payerId={}, context={}, attemptedEndpoint={}, reasonCode={}, fallbackEndpoint={}, nextStep=\"{}\"".format(
        payer_id or '', context or '', attempted or '', reason_code or '', fallback or '', hint or '')
    _log_fallback_once(key, msg, level="INFO")

def _optumai_error_indicates_member_required(error_code, error_description):
    """
    Return True if the OPTUMAI error looks like it is asking for member-level fields.
    Heuristic only; the spec does not enumerate payer-specific requirements.
    """
    try:
        code_upper = str(error_code or '').upper()
        desc_lower = str(error_description or '').lower()
        if 'MISSING_REQUIRED_FIELD' in code_upper:
            return True
        if ('member details' in desc_lower and 'mandatory' in desc_lower) or ('member' in desc_lower and 'mandatory' in desc_lower):
            return True
    except Exception:
        pass
    return False

def _log_fallback_once(key, message, level="WARNING"):
    try:
        if _FALLBACK_LOG_ONCE.get(key):
            return
        _FALLBACK_LOG_ONCE[key] = True
        MediLink_ConfigLoader.log(message, level=level, console_output=CONSOLE_LOGGING)
    except Exception:
        pass



def begin_request_failure_batch(label, context=None):
    """
    Start a request-failure aggregation window.

    Batch callers use this to keep repeated operational failures from emitting a
    full request dump per payer. Standalone calls are unchanged.
    """
    batch = {
        'label': str(label or 'request_batch'),
        'context': context if isinstance(context, dict) else {},
        'started_at': time.time(),
        'total': 0,
        'groups': {},
        'order': [],
    }
    _REQUEST_FAILURE_BATCH_STACK.append(batch)
    return batch


def is_request_failure_batch_active():
    return bool(_REQUEST_FAILURE_BATCH_STACK)


def _active_request_failure_batch():
    if _REQUEST_FAILURE_BATCH_STACK:
        return _REQUEST_FAILURE_BATCH_STACK[-1]
    return None


def _safe_log_value(value, limit=300):
    try:
        text = str(value if value is not None else '')
    except Exception:
        text = ''
    text = text.replace(chr(13), ' ').replace(chr(10), ' ').strip()
    if limit and len(text) > limit:
        return text[:limit] + '...'
    return text


def _extract_request_field(headers, params, data, names):
    sources = []
    if isinstance(headers, dict):
        sources.append(headers)
    if isinstance(params, dict):
        sources.append(params)
    if isinstance(data, dict):
        sources.append(data)

    for source in sources:
        for name in names:
            if name in source and source.get(name) not in (None, ''):
                return source.get(name)
        lowered = {}
        try:
            for key, value in source.items():
                lowered[str(key).lower()] = value
        except Exception:
            lowered = {}
        for name in names:
            key = str(name).lower()
            if key in lowered and lowered.get(key) not in (None, ''):
                return lowered.get(key)
    return None


def _append_unique(values, value, max_items=None):
    text = _safe_log_value(value, limit=120)
    if not text:
        return
    if text in values:
        return
    if max_items is None or len(values) < max_items:
        values.append(text)


def _summarize_values(values, max_items=20):
    if not values:
        return 'none'
    shown = values[:max_items]
    text = ','.join(shown)
    remaining = len(values) - len(shown)
    if remaining > 0:
        text += ' (+{} more)'.format(remaining)
    return text


def _record_request_failure_batch(endpoint_name, call_type, url, status_code=None,
                                  reason_code=None, reason_label=None, error_code=None,
                                  error_text=None, headers=None, params=None, data=None,
                                  next_step=None, exception_type=None):
    batch = _active_request_failure_batch()
    if not batch:
        return False

    reason_code = _safe_log_value(reason_code or 'unknown', limit=80)
    reason_label = _safe_log_value(reason_label or '', limit=120)
    error_code = _safe_log_value(error_code or '', limit=120)
    status_text = _safe_log_value(status_code if status_code is not None else 'unknown', limit=30)
    exception_text = _safe_log_value(exception_type or '', limit=80)
    url_text = _safe_log_value(url, limit=500)
    method_text = _safe_log_value(call_type, limit=20)
    endpoint_text = _safe_log_value(endpoint_name, limit=80)

    key = (
        endpoint_text,
        method_text,
        url_text,
        status_text,
        reason_code,
        reason_label,
        error_code,
        exception_text,
    )
    group = batch['groups'].get(key)
    if group is None:
        group = {
            'endpoint': endpoint_text,
            'method': method_text,
            'url': url_text,
            'status': status_text,
            'reason_code': reason_code,
            'reason_label': reason_label,
            'error_code': error_code,
            'exception_type': exception_text,
            'count': 0,
            'payer_ids': [],
            'date_ranges': [],
            'transactions': [],
            'sample_error': '',
            'next_step': _safe_log_value(next_step or '', limit=240),
        }
        batch['groups'][key] = group
        batch['order'].append(key)

    group['count'] += 1
    batch['total'] += 1

    payer_id = _extract_request_field(headers, params, data, ('payerId', 'payer_id', 'payer'))
    first_date = _extract_request_field(headers, params, data, ('firstServiceDt', 'serviceStartDate', 'first_service_date'))
    last_date = _extract_request_field(headers, params, data, ('lastServiceDt', 'serviceEndDate', 'last_service_date'))
    transaction_id = _extract_request_field(headers, params, data, ('transactionId', 'transaction_id'))

    _append_unique(group['payer_ids'], payer_id, max_items=_REQUEST_FAILURE_SUMMARY_LIMIT)
    if first_date or last_date:
        _append_unique(
            group['date_ranges'],
            '{}..{}'.format(_safe_log_value(first_date or '?', limit=40), _safe_log_value(last_date or '?', limit=40)),
            max_items=12
        )
    _append_unique(group['transactions'], transaction_id, max_items=12)

    if not group['sample_error'] and error_text:
        group['sample_error'] = _safe_log_value(error_text, limit=240)
    if not group['next_step'] and next_step:
        group['next_step'] = _safe_log_value(next_step, limit=240)
    return True


def flush_request_failure_batch(batch=None, level='WARNING'):
    """
    Emit one grouped summary for a request-failure batch and remove it from the stack.
    """
    target = batch
    if target is None:
        target = _active_request_failure_batch()
    if target is None:
        return

    try:
        if _REQUEST_FAILURE_BATCH_STACK and _REQUEST_FAILURE_BATCH_STACK[-1] is target:
            _REQUEST_FAILURE_BATCH_STACK.pop()
        elif target in _REQUEST_FAILURE_BATCH_STACK:
            _REQUEST_FAILURE_BATCH_STACK.remove(target)
    except Exception:
        pass

    total = target.get('total', 0)
    order = target.get('order') or []
    groups = target.get('groups') or {}
    if not total:
        return

    label = _safe_log_value(target.get('label') or 'request_batch', limit=120)
    try:
        MediLink_ConfigLoader.log(
            '[REQUEST_FAILURE_BATCH] {}: {} request failure(s) consolidated into {} group(s).'.format(
                label, total, len(order)
            ),
            level=level,
            console_output=CONSOLE_LOGGING
        )
        index = 1
        for key in order:
            group = groups.get(key) or {}
            msg = (
                '[REQUEST_FAILURE_BATCH] group={} count={} endpoint={} method={} status={} '
                'reasonCode={} reason="{}" errorCode={} url={} payerIds={} '
                'dateRanges={} transactionIds={} next="{}" sample="{}"'
            ).format(
                index,
                group.get('count', 0),
                group.get('endpoint') or 'unknown',
                group.get('method') or 'unknown',
                group.get('status') or 'unknown',
                group.get('reason_code') or 'unknown',
                _safe_log_value(group.get('reason_label') or '', limit=120).replace('"', "'"),
                group.get('error_code') or 'none',
                group.get('url') or 'unknown',
                _summarize_values(group.get('payer_ids') or [], max_items=20),
                _summarize_values(group.get('date_ranges') or [], max_items=6),
                _summarize_values(group.get('transactions') or [], max_items=6),
                _safe_log_value(group.get('next_step') or '', limit=240).replace('"', "'"),
                _safe_log_value(group.get('sample_error') or '', limit=240).replace('"', "'"),
            )
            MediLink_ConfigLoader.log(msg, level=level, console_output=CONSOLE_LOGGING)
            index += 1
    except Exception:
        pass

def _optumai_supports_feature_for_client(client, payer_id, feature, context_label):
    """
    Load crosswalk and check OPTUMAI feature support for a payer.
    Conservative default: if feature status is unknown, return False.

    Returns:
        tuple: (supports: bool, crosswalk: dict or None, reason: str or None)
    """
    if not payer_id:
        return False, None, 'payer_id_missing'
    try:
        from MediCafe.payer_list_updater import optumai_supports_feature, OPTUMAI_FEATURE_KEYS
    except ImportError:
        _log_fallback_once(
            'optumai_feature_check_import',
            "OPTUMAI feature check unavailable (import failure); skipping OPTUMAI for {}.".format(context_label),
            level="WARNING"
        )
        return False, None, 'feature_check_import_failed'
    if feature not in OPTUMAI_FEATURE_KEYS:
        MediLink_ConfigLoader.log(
            "Unknown OPTUMAI feature key '{}' ({}); treating as unsupported.".format(feature, context_label),
            level="WARNING",
            console_output=CONSOLE_LOGGING
        )
        return False, None, 'feature_unknown'
    if ensure_full_config_loaded is None:
        msg = ("CRITICAL: ensure_full_config_loaded is unavailable; falling back to "
               "MediLink_ConfigLoader.load_configuration() for OPTUMAI feature check ({}).".format(context_label))
        try:
            print(msg)
        except Exception:
            pass
        try:
            MediLink_ConfigLoader.log(msg, level="CRITICAL", console_output=CONSOLE_LOGGING)
        except Exception:
            pass
        try:
            _, crosswalk = MediLink_ConfigLoader.load_configuration()
        except Exception as e:
            try:
                err_msg = ("CRITICAL: load_configuration failed while checking OPTUMAI feature ({}): {}"
                           .format(context_label, str(e)))
                print(err_msg)
                MediLink_ConfigLoader.log(err_msg, level="CRITICAL", console_output=CONSOLE_LOGGING)
            except Exception:
                pass
            return False, None, 'loader_unavailable'
        # Continue with crosswalk if available
        if not crosswalk:
            MediLink_ConfigLoader.log(
                "OPTUMAI feature check skipped because crosswalk is missing ({}); defaulting to unsupported.".format(
                    context_label),
                level="DEBUG",
                console_output=CONSOLE_LOGGING
            )
            return False, None, 'crosswalk_missing'
        supports = False
        try:
            supports = bool(optumai_supports_feature(crosswalk, payer_id, feature))
        except Exception:
            supports = False
        if not supports:
            opl = crosswalk.get('optum_payer_list') or {}
            meta = opl.get('metadata') or {}
            payers = opl.get('payers')
            if meta.get('last_error') or not payers or (isinstance(payers, dict) and len(payers) == 0):
                return False, crosswalk, 'data_unavailable'
            return False, crosswalk, 'feature_not_supported'
        return True, crosswalk, None
    try:
        _, crosswalk = ensure_full_config_loaded(
            getattr(client, 'config', None),
            getattr(client, 'crosswalk', None)
        )
    except Exception as e:
        msg = ("CRITICAL: OPTUMAI feature check failed due to config/crosswalk load error ({}): {}. "
               "Falling back to MediLink_ConfigLoader.load_configuration().".format(context_label, str(e)))
        try:
            print(msg)
        except Exception:
            pass
        try:
            MediLink_ConfigLoader.log(msg, level="CRITICAL", console_output=CONSOLE_LOGGING)
        except Exception:
            pass
        try:
            _, crosswalk = MediLink_ConfigLoader.load_configuration()
        except Exception as e2:
            try:
                err_msg = ("CRITICAL: load_configuration failed while checking OPTUMAI feature ({}): {}"
                           .format(context_label, str(e2)))
                print(err_msg)
                MediLink_ConfigLoader.log(err_msg, level="CRITICAL", console_output=CONSOLE_LOGGING)
            except Exception:
                pass
            return False, None, 'loader_error'
    if not crosswalk:
        MediLink_ConfigLoader.log(
            "OPTUMAI feature check skipped because crosswalk is missing ({}); defaulting to unsupported.".format(
                context_label),
            level="DEBUG",
            console_output=CONSOLE_LOGGING
        )
        return False, None, 'crosswalk_missing'
    supports = False
    try:
        supports = bool(optumai_supports_feature(crosswalk, payer_id, feature))
    except Exception:
        supports = False
    if not supports:
        opl = crosswalk.get('optum_payer_list') or {}
        meta = opl.get('metadata') or {}
        payers = opl.get('payers')
        if meta.get('last_error') or not payers or (isinstance(payers, dict) and len(payers) == 0):
            return False, crosswalk, 'data_unavailable'
        return False, crosswalk, 'feature_not_supported'
    return True, crosswalk, None

"""
TODO At some point it might make sense to test their acknoledgment endpoint. body is transactionId.
This API is used to extract the claim acknowledgement details for the given transactionid which was 
generated for 837 requests in claim submission process. Claims Acknowledgement (277CA) will provide 
a status of claim-level acknowledgement of all claims received in the front-end processing system and 
adjudication system.
"""

class ConfigLoader:
    @staticmethod
    def load_configuration(config_path=os.path.join(os.path.dirname(__file__), '..', 'json', 'config.json'), 
                           crosswalk_path=os.path.join(os.path.dirname(__file__), '..', 'json', 'crosswalk.json')):
        return MediLink_ConfigLoader.load_configuration(config_path, crosswalk_path)

    @staticmethod
    def load_swagger_file(swagger_path):
        try:
            print("Attempting to load Swagger file: {}".format(swagger_path))
            with open(swagger_path, 'r') as swagger_file:
                if swagger_path.endswith('.yaml') or swagger_path.endswith('.yml'):
                    if yaml is None:
                        print("YAML parsing not available (PyYAML not installed). Please install PyYAML or provide a JSON Swagger file.")
                        return None
                    print("Parsing YAML file: {}".format(swagger_path))
                    swagger_data = yaml.safe_load(swagger_file)
                elif swagger_path.endswith('.json'):
                    print("Parsing JSON file: {}".format(swagger_path))
                    swagger_data = json.load(swagger_file)
                else:
                    raise ValueError("Unsupported Swagger file format.")
            print("Successfully loaded Swagger file: {}".format(swagger_path))
            return swagger_data
        except ValueError as e:
            print("Error parsing Swagger file {}: {}".format(swagger_path, e))
            MediLink_ConfigLoader.log("Error parsing Swagger file {}: {}".format(swagger_path, e), level="ERROR")
        except FileNotFoundError:
            print("Swagger file not found: {}".format(swagger_path))
            MediLink_ConfigLoader.log("Swagger file not found: {}".format(swagger_path), level="ERROR")
        except Exception as e:
            print("Unexpected error loading Swagger file {}: {}".format(swagger_path, e))
            MediLink_ConfigLoader.log("Unexpected error loading Swagger file {}: {}".format(swagger_path, e), level="ERROR")
        return None

# Function to ensure numeric type
def ensure_numeric(value):
    if isinstance(value, str):
        try:
            value = float(value)
        except ValueError:
            raise ValueError("Cannot convert {} to a numeric type".format(value))
    return value

# Import utilities from api_utils
try:
    from MediCafe.api_utils import TokenCache
except ImportError:
    # Fallback if api_utils is not available
    class TokenCache:
        def __init__(self):
            self.tokens = {}

# -----------------------------------------------------------------------------
# Endpoint-specific payer ID management (crosswalk-backed with hardcoded default)
# -----------------------------------------------------------------------------
# Intent:
# - Validate payer IDs against the endpoint actually being called.
# - Persist endpoint-specific payer ID lists into the crosswalk so they can be
#   updated over time without changing code.
# - For OPTUMAI: use the augmented list (includes LIFE1, WELM2, etc.).
# - For UHCAPI (including its Super Connector fallback): strictly enforce the
#   known-good UHC payer IDs only.
# - Future: OPTUMAI will expose a dedicated endpoint that returns its current
#   valid payer list. When available, this function should fetch and refresh the
#   crosswalk entry automatically (likely weekly/monthly), replacing the
#   hardcoded default below. The UHCAPI Super Connector will eventually be
#   deprecated; when removed, cleanup the UHC-specific paths accordingly.

try:
    # Prefer using existing crosswalk persistence utilities
    from MediBot.MediBot_Crosswalk_Utils import ensure_full_config_loaded, save_crosswalk
except Exception:
    ensure_full_config_loaded = None
    save_crosswalk = None

# -----------------------------------------------------------------------------
# OPTUMAI Header Building and TIN Normalization Helpers
# -----------------------------------------------------------------------------

def normalize_provider_tin(tin):
    """
    Normalize provider TIN to 9-digit numeric string.
    Removes hyphens, spaces, and other non-digit characters.
    
    Args:
        tin: Provider TIN (string, int, or any format)
        
    Returns:
        str: 9-digit numeric string, or None if input is invalid/empty
    """
    if not tin:
        return None
    try:
        tin_str = ''.join([ch for ch in str(tin) if ch.isdigit()])
        if len(tin_str) == 9:
            return tin_str
        else:
            MediLink_ConfigLoader.log(
                "Warning: Provider TIN '{}' normalized to '{}' (not 9 digits)".format(tin, tin_str),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
            # Return normalized version even if not 9 digits (caller can validate)
            return tin_str if tin_str else None
    except Exception as e:
        MediLink_ConfigLoader.log(
            "Error normalizing provider TIN '{}': {}".format(tin, str(e)),
            level="WARNING",
            console_output=CONSOLE_LOGGING
        )
        # Fallback to string conversion
        try:
            return str(tin)
        except Exception:
            return None

def build_optumai_headers(config, api_url=None, next_page_token=None):
    """
    Build standardized OPTUMAI headers with normalized TIN.
    Replaces duplicated header building logic across multiple functions.
    
    Args:
        config: Configuration object (must have MediLink config accessible)
        api_url: Optional API URL to detect sandbox/stage environment
        next_page_token: Optional pagination token for subsequent pages
        
    Returns:
        dict: Headers dictionary with Content-Type, Accept, providerTaxId,
              x-optum-consumer-correlation-id, environment (if sandbox), and
              nextPageToken (if provided)
    """
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    
    # Extract MediLink config and normalize provider TIN
    try:
        from MediCafe.core_utils import extract_medilink_config
    except ImportError:
        # Fallback if core_utils not available
        def extract_medilink_config(cfg):
            if hasattr(cfg, 'get'):
                return cfg
            return getattr(cfg, 'config', {})
    
    medi = extract_medilink_config(config)
    provider_tin = medi.get('billing_provider_tin')
    input_tin = provider_tin
    if provider_tin:
        # DEBUG: Log TIN normalization details
        if DEBUG:
            MediLink_ConfigLoader.log(
                "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: TIN normalization input={}".format(
                    input_tin if input_tin else 'None'
                ),
                level="DEBUG"
            )
        
        # Normalize to 9 digits (fixes missing normalization in claims inquiry)
        provider_tin = normalize_provider_tin(provider_tin)
        if provider_tin:
            # Validate normalized TIN is exactly 9 digits before adding to headers
            # This ensures consistency with get_eligibility_super_connector validation
            if len(provider_tin) == 9:
                headers['providerTaxId'] = provider_tin
                # DEBUG: Log successful normalization
                if DEBUG:
                    # Mask TIN for security (show first 5 digits, mask last 4)
                    tin_masked = provider_tin[:5] + '****'
                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: TIN normalized successfully, length={}, maskedValue={}".format(
                            len(provider_tin), tin_masked
                        ),
                        level="DEBUG"
                    )
            else:
                # WARNING: Log TIN normalization issues
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: TIN normalization issue - input '{}' normalized to '{}' (not 9 digits) - omitting providerTaxId header".format(
                        input_tin, provider_tin),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
                # Also log the existing warning message
                MediLink_ConfigLoader.log(
                    "Warning: Provider TIN '{}' normalized to '{}' (not 9 digits) - omitting providerTaxId header".format(
                        input_tin, provider_tin),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
    else:
        # WARNING: Log missing TIN
        if DEBUG:
            MediLink_ConfigLoader.log(
                "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: TIN normalization - missing billing_provider_tin in config",
                level="WARNING"
            )
    
    # Correlation ID for tracing
    try:
        corr_id = 'mc-{}'.format(int(time.time() * 1000))
    except Exception:
        corr_id = 'mc-{}'.format(int(time.time()))
    headers['x-optum-consumer-correlation-id'] = corr_id
    
    # Environment header (sandbox/stage detection)
    environment = None
    if api_url:
        try:
            api_url_lower = str(api_url).lower()
            if any(tag in api_url_lower for tag in ['sandbox', 'stg', 'stage', 'test']):
                headers['environment'] = 'sandbox'
                environment = 'sandbox'
        except Exception:
            pass
    
    # Pagination token
    if next_page_token:
        headers['nextPageToken'] = str(next_page_token)
    
    # DEBUG: Log header construction
    if DEBUG:
        # Mask correlation ID (show first 8 chars)
        corr_id_masked = corr_id[:8] + '...' if len(corr_id) >= 8 else corr_id
        # Mask provider TIN if present
        provider_tin_masked = 'None'
        if 'providerTaxId' in headers:
            tin_val = headers['providerTaxId']
            if len(tin_val) >= 5:
                provider_tin_masked = tin_val[:5] + '****'
            else:
                provider_tin_masked = '****'
        
        MediLink_ConfigLoader.log(
            "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: Header construction - providerTaxId={}, correlationId={}, environment={}, nextPageToken={}".format(
                provider_tin_masked, corr_id_masked, environment or 'None', 'present' if next_page_token else 'None'
            ),
            level="DEBUG"
        )
    
    return headers

# Hardcoded OPTUMAI payer IDs (fallback when optum_payer_list / endpoint_payer_ids missing).
# Single source of truth; used by _get_default_endpoint_payer_ids and get_valid_payer_ids_for_endpoint.
_OPTUMAI_HARDCODED_PAYER_IDS = [
    "87726", "25463", "39026", "74227", "LIFE1", "WELM2", "06111",
    "96385", "37602", "03432", "95467", "86050", "86047", "95378"
]

def _get_default_endpoint_payer_ids(endpoint_name):
    """
    Return hardcoded default payer IDs for a given endpoint.

    NOTE: Defaults are used when crosswalk does not yet contain a list.
    For OPTUMAI, uses get_optumai_payer_ids (optum_payer_list -> endpoint_payer_ids -> hardcoded).
    """
    if endpoint_name == 'OPTUMAI':
        try:
            from MediCafe.payer_list_updater import get_optumai_payer_ids
            if ensure_full_config_loaded:
                try:
                    config, crosswalk = ensure_full_config_loaded(None, None)
                    if crosswalk:
                        payer_ids = get_optumai_payer_ids(crosswalk=crosswalk, config=config)
                        if payer_ids:
                            return payer_ids
                except Exception:
                    pass
        except ImportError:
            pass
        return list(_OPTUMAI_HARDCODED_PAYER_IDS)

    # UHC-only list ??keep STRICT. Do not augment with non-UHC payers.
    uhc_payer_ids = [
        "87726", "03432", "96385", "95467", "86050", "86047", "95378", "06111", "37602"
    ]
    # Default to UHCAPI for any other endpoint name
    return uhc_payer_ids

def get_valid_payer_ids_for_endpoint(client, endpoint_name):
    """
    Resolve the valid payer IDs for a specific endpoint using crosswalk storage
    with a safe fallback to hardcoded defaults.

    For OPTUMAI: uses get_optumai_payer_ids (optum_payer_list -> endpoint_payer_ids -> hardcoded).
    Does not persist OPTUMAI to crosswalk; payer-list updater writes only to optum_payer_list.
    For other endpoints: reads endpoint_payer_ids, else initializes from defaults and persists.
    """
    try:
        base_config = None
        crosswalk = None
        if ensure_full_config_loaded is not None:
            base_config, crosswalk = ensure_full_config_loaded(
                getattr(client, 'config', None),
                getattr(client, 'crosswalk', None)
            )
        else:
            print("Warning: IN api_core, ensure_full_config_loaded is not available; falling back to MediLink_ConfigLoader.load_configuration().")
            MediLink_ConfigLoader.log(
                "Fallback: ensure_full_config_loaded not available in get_valid_payer_ids_for_endpoint; using MediLink_ConfigLoader.load_configuration().",
                level="WARNING"
            )
            base_config, crosswalk = MediLink_ConfigLoader.load_configuration()

        if endpoint_name == 'OPTUMAI':
            try:
                from MediCafe.payer_list_updater import get_optumai_payer_ids
                payer_ids = get_optumai_payer_ids(crosswalk=crosswalk, config=base_config)
                if payer_ids:
                    return payer_ids
            except ImportError:
                pass
            return list(_OPTUMAI_HARDCODED_PAYER_IDS)

        cw_ep = crosswalk.get('endpoint_payer_ids', {}) if isinstance(crosswalk, dict) else {}
        existing = cw_ep.get(endpoint_name)
        if isinstance(existing, list) and len(existing) > 0:
            return existing

        defaults = _get_default_endpoint_payer_ids(endpoint_name)
        if isinstance(crosswalk, dict):
            if 'endpoint_payer_ids' not in crosswalk:
                crosswalk['endpoint_payer_ids'] = {}
            crosswalk['endpoint_payer_ids'][endpoint_name] = list(defaults)
            if save_crosswalk is not None:
                try:
                    save_crosswalk(client, base_config, crosswalk, skip_api_operations=True)
                except Exception:
                    pass
        return defaults
    except Exception:
        return _get_default_endpoint_payer_ids(endpoint_name)


# -----------------------------------------------------------------------------
# Single routing layer: crosswalk-primary, hardcoded fallback
# -----------------------------------------------------------------------------
# Operations: search_claim, search_277ca, eligibility, claim_submission (align with OPTUMAI_FEATURE_KEYS in payer_list_updater)


def _load_routing_context(client):
    try:
        if ensure_full_config_loaded is not None:
            return ensure_full_config_loaded(
                getattr(client, 'config', None),
                getattr(client, 'crosswalk', None)
            )
        return MediLink_ConfigLoader.load_configuration()
    except Exception:
        return None, None


def _extract_endpoint_configs(base_config):
    try:
        medi = extract_medilink_config(base_config)
    except Exception:
        medi = base_config if isinstance(base_config, dict) else {}
    endpoints = medi.get('endpoints', {}) if isinstance(medi, dict) else {}
    if (not isinstance(endpoints, dict) or not endpoints) and isinstance(base_config, dict):
        fallback = base_config.get('MediLink_Config', {})
        endpoints = fallback.get('endpoints', {}) if isinstance(fallback, dict) else {}
    return endpoints if isinstance(endpoints, dict) else {}


def _get_crosswalk_payer_entry(crosswalk, payer_id):
    try:
        payer_entries = crosswalk.get('payer_id', {})
        if isinstance(payer_entries, dict):
            entry = payer_entries.get(str(payer_id))
            if isinstance(entry, dict):
                return entry
    except Exception:
        pass
    return {}


def _get_route_override(crosswalk, payer_id, operation):
    try:
        routing_overrides = crosswalk.get('routing_overrides', {})
        payers = routing_overrides.get('payers', {}) if isinstance(routing_overrides, dict) else {}
        payer_entry = payers.get(str(payer_id), {}) if isinstance(payers, dict) else {}
        override = payer_entry.get(str(operation)) if isinstance(payer_entry, dict) else None
        if isinstance(override, dict):
            endpoint = override.get('preferred_endpoint')
            if endpoint:
                return str(endpoint).strip(), override
    except Exception:
        pass
    return None, None


def _get_route_default(crosswalk, payer_id, operation):
    payer_entry = _get_crosswalk_payer_entry(crosswalk, payer_id)
    route_defaults = payer_entry.get('route_defaults', {}) if isinstance(payer_entry, dict) else {}
    if isinstance(route_defaults, dict):
        endpoint = route_defaults.get(str(operation))
        if endpoint:
            return str(endpoint).strip()
    return None


def _get_legacy_endpoint(crosswalk, payer_id):
    payer_entry = _get_crosswalk_payer_entry(crosswalk, payer_id)
    endpoint = payer_entry.get('endpoint') if isinstance(payer_entry, dict) else None
    if endpoint:
        return str(endpoint).strip()
    return None


def _get_endpoint_membership(crosswalk, endpoint_name):
    cw_ep = crosswalk.get('endpoint_payer_ids', {}) if isinstance(crosswalk, dict) else {}
    existing = cw_ep.get(endpoint_name) if isinstance(cw_ep, dict) else None
    if isinstance(existing, list) and len(existing) > 0:
        return existing
    return _get_default_endpoint_payer_ids(endpoint_name)


def _optum_supports_operation(crosswalk, payer_id, operation):
    try:
        from MediCafe.payer_list_updater import optumai_supports_feature
    except ImportError:
        optumai_supports_feature = None
    if not optumai_supports_feature:
        return False
    feature_key = 'submit_with_precheck' if operation == 'claim_submission' else operation
    return bool(optumai_supports_feature(crosswalk, payer_id, feature_key))


def _endpoint_supports_claim_submission(base_config, endpoint_name):
    endpoints = _extract_endpoint_configs(base_config)
    endpoint_cfg = endpoints.get(endpoint_name)
    if not isinstance(endpoint_cfg, dict):
        return False, 'endpoint_not_configured'
    method = str(endpoint_cfg.get('submission_method') or 'winscp').strip().lower()
    if method in ('api', 'winscp'):
        return True, None
    return False, 'endpoint_not_submission_capable'


def _validate_claim_submission_candidate(base_config, crosswalk, payer_id, endpoint_name):
    if not endpoint_name:
        return False, 'missing_endpoint'
    supported, reason = _endpoint_supports_claim_submission(base_config, endpoint_name)
    if not supported:
        return False, reason
    if endpoint_name == 'OPTUMAI' and not _optum_supports_operation(crosswalk, payer_id, 'claim_submission'):
        return False, 'submit_with_precheck_not_supported'
    return True, None


def resolve_operation_route_decision(client, payer_id, operation, use_overrides=True):
    """
    Structured routing decision for operation-aware routing.

    Phase 1 migration scope:
    - claim_submission consults routing_overrides and route_defaults
    - other operations preserve the legacy capability-driven routing behavior
    """
    normalized_payer_id = str(payer_id or '').strip()
    normalized_operation = str(operation or '').strip()
    decision = {
        'operation': normalized_operation,
        'payer_id': normalized_payer_id,
        'selected_endpoint': None,
        'reason_code': None,
        'decision_source': None,
        'override_found': False,
        'override_applied': False,
        'override_conflict': False,
        'override_conflict_reason': None,
    }

    if not normalized_payer_id or not normalized_operation:
        decision['reason_code'] = 'missing_payer_or_operation'
        return decision

    base_config, crosswalk = _load_routing_context(client)

    # When crosswalk is missing or empty, use hardcoded lists only.
    uhc_defaults = _get_default_endpoint_payer_ids('UHCAPI')
    optumai_defaults = _get_default_endpoint_payer_ids('OPTUMAI')
    if not crosswalk or not isinstance(crosswalk, dict):
        if normalized_operation == 'search_277ca':
            if normalized_payer_id in optumai_defaults:
                decision['selected_endpoint'] = 'OPTUMAI'
                decision['decision_source'] = 'defaults'
                decision['reason_code'] = None
                return decision
            decision['reason_code'] = 'crosswalk_unavailable'
            return decision
        if normalized_operation in ('search_claim', 'eligibility', 'claim_submission'):
            if normalized_payer_id in optumai_defaults:
                decision['selected_endpoint'] = 'OPTUMAI'
                decision['decision_source'] = 'defaults'
                decision['reason_code'] = None
                return decision
            if normalized_payer_id in uhc_defaults:
                decision['selected_endpoint'] = 'UHCAPI'
                decision['decision_source'] = 'defaults'
                decision['reason_code'] = None
                return decision
        decision['reason_code'] = 'payer_not_in_defaults'
        return decision

    if normalized_operation == 'claim_submission':
        if use_overrides:
            override_endpoint, override_payload = _get_route_override(crosswalk, normalized_payer_id, normalized_operation)
        else:
            override_endpoint, override_payload = None, None
        if override_endpoint:
            decision['override_found'] = True
            valid_override, override_reason = _validate_claim_submission_candidate(
                base_config,
                crosswalk,
                normalized_payer_id,
                override_endpoint
            )
            if valid_override:
                decision['selected_endpoint'] = override_endpoint
                decision['decision_source'] = 'routing_override'
                decision['override_applied'] = True
                decision['reason_code'] = None
                return decision
            decision['override_conflict'] = True
            decision['override_conflict_reason'] = override_reason
            decision['reason_code'] = override_reason

        route_default = _get_route_default(crosswalk, normalized_payer_id, normalized_operation)
        if route_default:
            valid_default, default_reason = _validate_claim_submission_candidate(
                base_config,
                crosswalk,
                normalized_payer_id,
                route_default
            )
            if valid_default:
                decision['selected_endpoint'] = route_default
                decision['decision_source'] = 'route_default'
                decision['reason_code'] = None
                return decision
            decision['reason_code'] = default_reason

        legacy_endpoint = _get_legacy_endpoint(crosswalk, normalized_payer_id)
        if legacy_endpoint:
            valid_legacy, legacy_reason = _validate_claim_submission_candidate(
                base_config,
                crosswalk,
                normalized_payer_id,
                legacy_endpoint
            )
            if valid_legacy:
                decision['selected_endpoint'] = legacy_endpoint
                decision['decision_source'] = 'legacy_endpoint'
                decision['reason_code'] = None
                MediLink_ConfigLoader.log(
                    "[DIAG:LEGACY_ENDPOINT_COMPAT_ROUTE] payer_id='{}' endpoint='{}' operation='claim_submission'".format(
                        normalized_payer_id,
                        legacy_endpoint
                    ),
                    level="DEBUG"
                )
                return decision
            decision['reason_code'] = legacy_reason

    # OPTUMAI operations: check feature support first (map claim_submission -> submit_with_precheck).
    if normalized_operation in ('search_claim', 'search_277ca', 'eligibility', 'claim_submission'):
        if _optum_supports_operation(crosswalk, normalized_payer_id, normalized_operation):
            decision['selected_endpoint'] = 'OPTUMAI'
            decision['decision_source'] = 'capability'
            decision['reason_code'] = None
            return decision
        valid_uhc = _get_endpoint_membership(crosswalk, 'UHCAPI')
        if normalized_payer_id in valid_uhc:
            if normalized_operation == 'search_277ca':
                decision['reason_code'] = 'search_277ca_not_supported_for_payer'
                return decision
            decision['selected_endpoint'] = 'UHCAPI'
            decision['decision_source'] = 'capability_fallback'
            decision['reason_code'] = None
            return decision
        decision['reason_code'] = 'payer_not_supported'
        return decision

    decision['reason_code'] = 'unknown_operation'
    return decision


def resolve_operation_route(client, payer_id, operation):
    """
    Compatibility wrapper over resolve_operation_route_decision().
    """
    decision = resolve_operation_route_decision(client, payer_id, operation)
    endpoint = decision.get('selected_endpoint')
    if endpoint:
        return endpoint, None
    return None, decision.get('reason_code')


def get_api_eligible_payer_ids_for_claim_status(client):
    """
    List of payer IDs valid for claim-status flows (recent submissions, payer rotation).
    Crosswalk-primary; hardcoded list fallback when crosswalk is missing or empty.

    Returns:
        list: Deduplicated payer IDs (union of OPTUMAI and UHCAPI valid payers).
    """
    try:
        optumai_ids = get_valid_payer_ids_for_endpoint(client, 'OPTUMAI')
        uhc_ids = get_valid_payer_ids_for_endpoint(client, 'UHCAPI')
        seen = set()
        result = []
        for pid in (optumai_ids or []):
            if pid and pid not in seen:
                seen.add(pid)
                result.append(pid)
        for pid in (uhc_ids or []):
            if pid and pid not in seen:
                seen.add(pid)
                result.append(pid)
        if result:
            return result
    except Exception:
        pass
    return _get_default_endpoint_payer_ids('UHCAPI')


class BaseAPIClient:
    def __init__(self, config):
        self.config = config
        self.token_cache = TokenCache()
        # Log when a new APIClient instance is created (helps diagnose token cache issues)
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log("New APIClient instance created (token cache is instance-specific)", level="DEBUG")

    def get_access_token(self, endpoint_name):
        raise NotImplementedError("Subclasses should implement this!")

    def make_api_call(self, endpoint_name, call_type, url_extension="", params=None, data=None, headers=None):
        raise NotImplementedError("Subclasses should implement this!")


def resolve_api_resilience_policy(config, recent_metrics=None, env=None):
    del recent_metrics
    del env
    cfg = config if isinstance(config, dict) else {}
    medi = cfg.get("MediLink_Config") if isinstance(cfg.get("MediLink_Config"), dict) else cfg
    feature_flags = medi.get("feature_flags") if isinstance(medi.get("feature_flags"), dict) else {}

    def _flag(name, default=False):
        if name in feature_flags:
            return bool(feature_flags.get(name)), "config"
        return bool(default), "default"

    circuit_enabled, circuit_source = _flag("api_circuit_breaker", False)
    caching_enabled, caching_source = _flag("api_caching", False)
    rate_enabled, rate_source = _flag("api_rate_limiting", False)
    return {
        "schema_version": 1,
        "api_circuit_breaker": bool(circuit_enabled),
        "api_caching": bool(caching_enabled),
        "api_rate_limiting": bool(rate_enabled),
        "effective_policy": {
            "api_circuit_breaker": bool(circuit_enabled),
            "api_caching": bool(caching_enabled),
            "api_rate_limiting": bool(rate_enabled),
        },
        "policy_source_map": {
            "api_circuit_breaker": circuit_source,
            "api_caching": caching_source,
            "api_rate_limiting": rate_source,
        },
        "policy_reason": "api_resilience_policy_resolved",
    }


class APIClient(BaseAPIClient):
    def __init__(self, config=None):
        if config is None:
            config, _ = MediLink_ConfigLoader.load_configuration()
        super().__init__(config)
        
        # Add enhanced features if available
        # XP/Python34 Compatibility: Enhanced error handling with verbose output
        try:
            from MediCafe.api_utils import APICircuitBreaker, APICache, APIRateLimiter
            MediLink_ConfigLoader.log("Successfully imported MediCafe.api_utils", level="DEBUG")
        except ImportError as e:
            MediLink_ConfigLoader.log("Warning: MediCafe.api_utils not available: {}".format(str(e)), level="WARNING")
            print("Warning: MediCafe.api_utils import failed: {}".format(str(e)))
            APICircuitBreaker = None
            APICache = None
            APIRateLimiter = None
        except Exception as e:
            MediLink_ConfigLoader.log("Unexpected error importing MediCafe.api_utils: {}".format(str(e)), level="ERROR")
            print("Error: Unexpected MediCafe.api_utils import error: {}".format(str(e)))
            APICircuitBreaker = None
            APICache = None
            APIRateLimiter = None
        
        try:
            try:
                from MediLink import MediLink_insurance_utils
            except Exception:
                MediLink_insurance_utils = None
            if MediLink_insurance_utils is None:
                import importlib
                MediLink_insurance_utils = importlib.import_module('MediLink.MediLink_insurance_utils')
            get_feature_flag = MediLink_insurance_utils.get_feature_flag
            MediLink_ConfigLoader.log("Successfully imported MediLink.MediLink_insurance_utils", level="DEBUG")
        except ImportError as e:
            MediLink_ConfigLoader.log("Warning: MediLink.MediLink_insurance_utils not available: {}".format(str(e)), level="WARNING")
            print("Warning: MediLink.MediLink_insurance_utils import failed: {}".format(str(e)))
            # Provide fallback function
            def get_feature_flag(flag_name, default=False):
                MediLink_ConfigLoader.log("Using fallback get_feature_flag for '{}', returning default: {}".format(flag_name, default), level="DEBUG")
                return default
        except Exception as e:
            MediLink_ConfigLoader.log("Unexpected error importing MediLink.MediLink_insurance_utils: {}".format(str(e)), level="ERROR")
            print("Error: Unexpected MediLink.MediLink_insurance_utils import error: {}".format(str(e)))
            # Provide fallback function
            def get_feature_flag(flag_name, default=False):
                MediLink_ConfigLoader.log("Using fallback get_feature_flag for '{}', returning default: {}".format(flag_name, default), level="DEBUG")
                return default
        
        # Initialize enhancements with error handling
        try:
            api_policy = resolve_api_resilience_policy(config)
            enable_circuit_breaker = bool(api_policy.get('api_circuit_breaker'))
            enable_caching = bool(api_policy.get('api_caching'))
            enable_rate_limiting = bool(api_policy.get('api_rate_limiting'))
            self.api_resilience_policy = api_policy
            
            self.circuit_breaker = APICircuitBreaker() if (enable_circuit_breaker and APICircuitBreaker) else None
            self.api_cache = APICache() if (enable_caching and APICache) else None
            self.rate_limiter = APIRateLimiter() if (enable_rate_limiting and APIRateLimiter) else None
            
            if any([enable_circuit_breaker, enable_caching, enable_rate_limiting]):
                MediLink_ConfigLoader.log("Enhanced API client initialized with circuit_breaker={}, caching={}, rate_limiting={}".format(
                    enable_circuit_breaker, enable_caching, enable_rate_limiting), level="INFO")
            else:
                MediLink_ConfigLoader.log("API enhancements disabled or not available, using standard client", level="DEBUG")
        except Exception as e:
            MediLink_ConfigLoader.log("Error initializing API enhancements: {}. Using standard client.".format(str(e)), level="WARNING")
            print("Warning: API enhancement initialization failed: {}".format(str(e)))
            self.circuit_breaker = None
            self.api_cache = None
            self.rate_limiter = None

    def _get_endpoint_env_settings(self, endpoint_name):
        """Return endpoint-scoped env-header settings with backward-compatible defaults."""
        try:
            from MediCafe.core_utils import extract_medilink_config
            medi = extract_medilink_config(self.config)
            endpoint_cfg = medi.get('endpoints', {}).get(endpoint_name, {}) if isinstance(medi, dict) else {}
        except Exception:
            endpoint_cfg = {}

        # Defensive normalization: endpoint entry may exist but be null/non-dict in YAML.
        if not isinstance(endpoint_cfg, dict):
            endpoint_cfg = {}

        def _parse_bool(value, default_value):
            if isinstance(value, bool):
                return value
            if value is None:
                return default_value
            if isinstance(value, (int, float)):
                return bool(value)
            if isinstance(value, str):
                normalized = value.strip().lower()
                if normalized in ('true', '1', 'yes', 'y', 'on'):
                    return True
                if normalized in ('false', '0', 'no', 'n', 'off', ''):
                    return False
            return default_value

        use_env_header_default = (endpoint_name == 'UHCAPI')
        use_env_header = _parse_bool(endpoint_cfg.get('use_env_header'), use_env_header_default)

        header_name = endpoint_cfg.get('env_header_name') or 'env'
        indicators = endpoint_cfg.get('staging_indicators') or ['stg', 'stage', 'test']
        if not isinstance(indicators, list):
            indicators = ['stg', 'stage', 'test']

        return use_env_header, str(header_name), [str(x).lower() for x in indicators if x]

    def detect_environment(self, endpoint_name='UHCAPI'):
        """Detect if endpoint api_url appears to target non-production environment."""
        try:
            from MediCafe.core_utils import extract_medilink_config
            medi = extract_medilink_config(self.config)
            endpoint_cfg = medi.get('endpoints', {}).get(endpoint_name, {}) if isinstance(medi, dict) else {}
            if not isinstance(endpoint_cfg, dict):
                endpoint_cfg = {}
            api_url = str(endpoint_cfg.get('api_url', '') or '')
            _, _, staging_indicators = self._get_endpoint_env_settings(endpoint_name)
            api_url_l = api_url.lower()

            MediLink_ConfigLoader.log("DEBUG: Found API URL for {}: {}".format(endpoint_name, api_url), level="DEBUG")

            for token in staging_indicators:
                if token and token in api_url_l:
                    MediLink_ConfigLoader.log(
                        "DEBUG: Detected staging environment for {} from URL token '{}': {}".format(endpoint_name, token, api_url),
                        level="DEBUG"
                    )
                    return 'sandbox'

            MediLink_ConfigLoader.log("DEBUG: No staging indicators found in {} URL: {}".format(endpoint_name, api_url), level="DEBUG")
        except Exception as e:
            MediLink_ConfigLoader.log("DEBUG: Error in environment detection for {}: {}".format(endpoint_name, e), level="DEBUG")

        return None

    def add_environment_headers(self, headers, endpoint_name):
        """Add endpoint-configured environment header when enabled."""
        use_env_header, header_name, _ = self._get_endpoint_env_settings(endpoint_name)
        if not use_env_header:
            return headers

        environment = self.detect_environment(endpoint_name)
        if environment:
            headers[header_name] = environment
            MediLink_ConfigLoader.log(
                "Added {} parameter for staging environment: {}".format(header_name, environment),
                level="INFO",
                console_output=CONSOLE_LOGGING
            )
        else:
            MediLink_ConfigLoader.log(
                "No {} parameter - using production environment".format(header_name),
                level="DEBUG",
                console_output=CONSOLE_LOGGING
            )
        return headers

    def get_access_token(self, endpoint_name, quiet_mode=False):
        MediLink_ConfigLoader.log("[Get Access Token] Called for {}".format(endpoint_name), level="DEBUG")
        current_time = time.time()
        cached_token = self.token_cache.get(endpoint_name, current_time, quiet_mode=quiet_mode)
        
        if cached_token:
            expires_at = self.token_cache.tokens[endpoint_name]['expires_at']
            MediLink_ConfigLoader.log("Cached token expires at {}".format(expires_at), level="DEBUG")
            return cached_token
        
        # Check if token request has already failed for this endpoint this session
        if self.token_cache.is_token_request_failed(endpoint_name):
            failure_info = self.token_cache.get_token_failure_info(endpoint_name)
            error_code = failure_info.get('error_code', 'unknown') if failure_info else 'unknown'
            # Suppress or reduce logging when in quiet mode
            log_level = "DEBUG" if quiet_mode else "INFO"
            MediLink_ConfigLoader.log(
                "Skipping token request for {} - token request already failed this session (error: {})".format(
                    endpoint_name, error_code),
                level=log_level
            )
            return None
        
        # Validate that we actually need a token before fetching
        # Check if the endpoint configuration exists and is valid
        try:
            from MediCafe.core_utils import extract_medilink_config
            medi = extract_medilink_config(self.config)
            endpoint_config = medi.get('endpoints', {}).get(endpoint_name)
            if not endpoint_config:
                MediLink_ConfigLoader.log("No configuration found for endpoint: {}".format(endpoint_name), level="ERROR")
                return None
                
            # Validate required configuration fields
            required_fields = ['token_url', 'client_id', 'client_secret']
            missing_fields = [field for field in required_fields if field not in endpoint_config]
            if missing_fields:
                MediLink_ConfigLoader.log("Missing required configuration fields for {}: {}".format(endpoint_name, missing_fields), level="ERROR")
                return None
                
        except KeyError:
            MediLink_ConfigLoader.log("Endpoint {} not found in configuration".format(endpoint_name), level="ERROR")
            return None
        except Exception as e:
            MediLink_ConfigLoader.log("Error validating endpoint configuration for {}: {}".format(endpoint_name, str(e)), level="ERROR")
            return None
        
        # If no valid token, fetch a new one
        token_url = endpoint_config['token_url']

        def _emit_token_failure_diag(error_code=None, error_description=None, http_status=None, exception_text=None):
            """
            Always-on redacted diagnostics for token failures.
            Safe for logs/support bundles (no secrets or tokens).
            Console output is suppressed when quiet_mode is True.
            """
            try:
                from MediCafe.token_diagnostics import build_token_diagnostics_block
                block = build_token_diagnostics_block(
                    endpoint_name=endpoint_name,
                    token_url=token_url,
                    client_id=endpoint_config.get('client_id'),
                    client_secret=endpoint_config.get('client_secret'),
                    scope=endpoint_config.get('scope'),
                    grant_type='client_credentials',
                    config_path=os.environ.get('MEDICAFE_CONFIG_FILE', '').strip(),
                    http_status=http_status,
                    error_code=error_code,
                    error_description=error_description,
                    exception_text=exception_text,
                    note="Redacted: no secrets or tokens are shown. Compare sha256_8/len/last4 across machines."
                )
                MediLink_ConfigLoader.log(
                    block,
                    level="ERROR",
                    console_output=(CONSOLE_LOGGING and not quiet_mode)
                )
            except Exception:
                pass
        
        # Standard token request logic for all endpoints (including AVAILITY)
        # AVAILITY uses scope=healthcare-hipaa-transactions-demo per test telemetry
        data = {
            'grant_type': 'client_credentials',
            'client_id': endpoint_config['client_id'],
            'client_secret': endpoint_config['client_secret']
        }

        # NOTE: Scope parameter is OPTIONAL for OPTUM API token requests.
        # According to OPTUM API documentation and investigation (see docs/OPTUMAI_TOKEN_SCOPE_INVESTIGATION.md),
        # scopes are auto-granted based on client credentials and subscription configuration in the OPTUMAI portal.
        # The scope parameter in the token request is not required - OPTUM determines available scopes
        # (e.g., read_healthcheck for eligibility endpoint) based on the client's subscription.
        # We include scope in the request if present in config for informational/debugging purposes,
        # but it is not validated as it's not part of the standard OPTUM token request flow.
        # For other endpoints that may require explicit scope, the conditional logic below handles it.
        if 'scope' in endpoint_config:
            data['scope'] = endpoint_config['scope']
            # Log scope value for informational/debugging purposes (OPTUM doesn't require it)
            if endpoint_name == 'OPTUMAI':
                MediLink_ConfigLoader.log(
                    "Scope '{}' found in OPTUMAI config (informational only - OPTUM auto-grants scopes via subscription)".format(
                        endpoint_config['scope']),
                    level="DEBUG"
                )

        headers = {'Content-Type': 'application/x-www-form-urlencoded'}

        # DEBUG: Log token request (no credentials)
        MediLink_ConfigLoader.log("Requesting new token for {} from {}".format(endpoint_name, token_url), level="DEBUG")

        try:
            response = requests.post(token_url, headers=headers, data=data)

            # Try to parse JSON regardless of HTTP status so we can surface OAuth error_description.
            token_data = None
            try:
                token_data = response.json()
            except Exception:
                token_data = None

            # OAuth providers often return 400 with JSON: {"error": "...", "error_description": "..."}
            if isinstance(token_data, dict) and 'error' in token_data:
                error_code = token_data.get('error', 'unknown')
                error_desc = token_data.get('error_description', 'N/A')
                MediLink_ConfigLoader.log(
                    "Token request failed for {}: error={}, error_description={}".format(
                        endpoint_name, error_code, error_desc),
                    level="ERROR"
                )
                # Mark this endpoint as failed to prevent repeated token requests
                try:
                    self.token_cache.mark_token_request_failed(
                        endpoint_name,
                        error_code,
                        error_description=error_desc,
                        http_status=getattr(response, 'status_code', None),
                        token_url=token_url
                    )
                except Exception:
                    self.token_cache.mark_token_request_failed(endpoint_name, error_code)
                _emit_token_failure_diag(
                    error_code=error_code,
                    error_description=error_desc,
                    http_status=getattr(response, 'status_code', None),
                    exception_text=None
                )
                return None

            # If non-2xx and no OAuth JSON error, raise for status to hit RequestException handler.
            try:
                response.raise_for_status()
            except Exception:
                raise

            # If we couldn't parse JSON earlier, try again now (2xx).
            if token_data is None:
                token_data = response.json()

            # Validate that access_token is present in response
            if not isinstance(token_data, dict) or 'access_token' not in token_data:
                keys = list(token_data.keys()) if isinstance(token_data, dict) else []
                MediLink_ConfigLoader.log(
                    "Invalid token response for {}: response missing 'access_token'. Keys received: {}".format(
                        endpoint_name, keys),
                    level="ERROR"
                )
                # Mark this endpoint as failed to prevent repeated token requests
                try:
                    self.token_cache.mark_token_request_failed(
                        endpoint_name,
                        'missing_access_token',
                        error_description="missing access_token in token response",
                        http_status=getattr(response, 'status_code', None),
                        token_url=token_url
                    )
                except Exception:
                    self.token_cache.mark_token_request_failed(endpoint_name, 'missing_access_token')
                _emit_token_failure_diag(
                    error_code='missing_access_token',
                    error_description="missing access_token in token response",
                    http_status=getattr(response, 'status_code', None),
                    exception_text=None
                )
                return None
            
            access_token = token_data['access_token']
            # Authoritative TTL is always expires_in from the token response. Production often returns 7200s;
            # 3600 here is only a conservative default if the field is missing.
            expires_in = token_data.get('expires_in', 3600)
            
            # DEBUG: Log response structure (no token values)
            MediLink_ConfigLoader.log("Token response keys: {}".format(list(token_data.keys())), level="DEBUG")
            
            # Log token acquisition details (without exposing secrets)
            if 'scope' in endpoint_config:
                scope_info = "scope: {}".format(endpoint_config['scope'])
            else:
                scope_info = "scope: none (OPTUM auto-grants via subscription)"
            MediLink_ConfigLoader.log(
                "Obtained NEW token for endpoint: {} (expires_in: {}s, {})".format(
                    endpoint_name, expires_in, scope_info),
                level="INFO",
                console_output=CONSOLE_LOGGING
            )
            
            if expires_in != 3600:
                MediLink_ConfigLoader.log(
                    "Token expires_in from response: {}s (using this value for cache TTL).".format(expires_in),
                    level="DEBUG",
                )

            self.token_cache.set(endpoint_name, access_token, expires_in, current_time)
            # Clear any previous token request failure flag since we successfully obtained a token
            self.token_cache.clear_token_request_failure(endpoint_name)
            return access_token
        except requests.exceptions.RequestException as e:
            MediLink_ConfigLoader.log("Failed to obtain token for {}: {}".format(endpoint_name, str(e)), level="ERROR")
            # Mark as failed if it's an auth-related error (401, 403)
            error_str = str(e)
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                if status_code in (401, 403):
                    # Capture response text snippet when available (safe: should not include secrets).
                    resp_text = None
                    try:
                        resp_text = getattr(e.response, 'text', None)
                    except Exception:
                        resp_text = None
                    try:
                        self.token_cache.mark_token_request_failed(
                            endpoint_name,
                            'http_{}'.format(status_code),
                            error_description=resp_text,
                            http_status=status_code,
                            token_url=token_url
                        )
                    except Exception:
                        self.token_cache.mark_token_request_failed(endpoint_name, 'http_{}'.format(status_code))
                    _emit_token_failure_diag(
                        error_code='http_{}'.format(status_code),
                        error_description=resp_text,
                        http_status=status_code,
                        exception_text=str(e)
                    )
            # Emit concise connectivity hint for DNS/proxy issues (best-effort, console-gated)
            try:
                from MediCafe.api_hints import emit_network_hint
                emit_network_hint(endpoint_name, token_url, e, console=CONSOLE_LOGGING)
            except Exception:
                pass
            return None
        except (KeyError, ValueError) as e:
            MediLink_ConfigLoader.log("Invalid token response for {}: unexpected error ({})".format(endpoint_name, str(e)), level="ERROR")
            # Mark as failed for parse/validation errors
            try:
                self.token_cache.mark_token_request_failed(
                    endpoint_name,
                    'parse_error',
                    error_description=str(e),
                    http_status=None,
                    token_url=token_url
                )
            except Exception:
                self.token_cache.mark_token_request_failed(endpoint_name, 'parse_error')
            _emit_token_failure_diag(
                error_code='parse_error',
                error_description=str(e),
                http_status=None,
                exception_text=str(e)
            )
            return None

    def make_api_call(self, endpoint_name, call_type, url_extension="", params=None, data=None, headers=None, quiet_mode=False):
        # Try enhanced API call if available
        if hasattr(self, 'circuit_breaker') and self.circuit_breaker:
            try:
                return self._make_enhanced_api_call(endpoint_name, call_type, url_extension, params, data, headers, quiet_mode=quiet_mode)
            except Exception as e:
                MediLink_ConfigLoader.log("Enhanced API call failed, falling back to standard: {}".format(str(e)), level="WARNING")
        
        # Standard API call logic
        return self._make_standard_api_call(endpoint_name, call_type, url_extension, params, data, headers, quiet_mode=quiet_mode)
    
    def _make_enhanced_api_call(self, endpoint_name, call_type, url_extension="", params=None, data=None, headers=None, quiet_mode=False):
        """Enhanced API call with circuit breaker, caching, and rate limiting"""
        # Check cache first (for GET requests)
        if self.api_cache and call_type == 'GET':
            cached_result = self.api_cache.get(endpoint_name, call_type, url_extension, params)
            if cached_result is not None:
                MediLink_ConfigLoader.log("Cache hit for {} {} {}".format(call_type, endpoint_name, url_extension), level="DEBUG")
                return cached_result
        
        # Check rate limits
        if self.rate_limiter:
            self.rate_limiter.wait_if_needed()
        
        # Make call with circuit breaker protection
        result = self.circuit_breaker.call_with_breaker(
            self._make_standard_api_call, endpoint_name, call_type, url_extension, params, data, headers, quiet_mode)
        
        # Record rate limit call
        if self.rate_limiter:
            self.rate_limiter.record_call()
        
        # Cache result (for GET requests)
        if self.api_cache and call_type == 'GET':
            self.api_cache.set(result, endpoint_name, call_type, url_extension, params)
        
        return result
    
    def _make_standard_api_call(self, endpoint_name, call_type, url_extension="", params=None, data=None, headers=None, quiet_mode=False):
        """Standard API call logic preserved for compatibility"""
        token = self.get_access_token(endpoint_name, quiet_mode=quiet_mode)
        if token:
            MediLink_ConfigLoader.log("[Make API Call] Token found for {}".format(endpoint_name), level="DEBUG")
        else:
            # Suppress or reduce logging when in quiet mode
            log_level = "DEBUG" if quiet_mode else "ERROR"
            MediLink_ConfigLoader.log("[Make API Call] No token obtained for {}".format(endpoint_name), level=log_level)
            raise ValueError("No access token available for endpoint: {}".format(endpoint_name))

        if headers is None:
            headers = {}
        # Set Authorization (always required)
        headers['Authorization'] = 'Bearer {}'.format(token)
        # Set Accept only if caller didn't provide it (allows AVAILITY application.json override)
        if 'Accept' not in headers:
            headers['Accept'] = 'application/json'
        
        # Add environment-specific headers automatically
        headers = self.add_environment_headers(headers, endpoint_name)
        
        from MediCafe.core_utils import extract_medilink_config
        medi = extract_medilink_config(self.config)
        base_url = medi.get('endpoints', {}).get(endpoint_name, {}).get('api_url', '')
        if url_extension and isinstance(url_extension, str) and url_extension.startswith(('http://', 'https://')):
            url = url_extension
            MediLink_ConfigLoader.log(
                "Warning: Absolute URL provided for endpoint {}. Using url_extension as full URL.".format(endpoint_name),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
        else:
            if not base_url:
                raise ValueError("Missing api_url for endpoint {}".format(endpoint_name))
            # Normalize URL construction: remove trailing slash from base_url, ensure url_extension starts with /
            # CRITICAL: Trailing slash in url_extension causes OPTUMAI gateway misrouting
            base_url = base_url.rstrip('/')
            if url_extension:
                url_extension = url_extension.strip()
                if not url_extension.startswith('/'):
                    url_extension = '/' + url_extension
                # Remove trailing slash from url_extension - CRITICAL for OPTUMAI Claim Actions
                url_extension = url_extension.rstrip('/')
            url = base_url + url_extension

        # VERBOSE LOGGING: Log all request details before making the call
        if DEBUG:
            MediLink_ConfigLoader.log("=" * 80, level="INFO")
            MediLink_ConfigLoader.log("VERBOSE API CALL DETAILS", level="INFO")
            MediLink_ConfigLoader.log("=" * 80, level="INFO")
            MediLink_ConfigLoader.log("Endpoint Name: {}".format(endpoint_name), level="INFO")
            MediLink_ConfigLoader.log("Call Type: {}".format(call_type), level="INFO")
            MediLink_ConfigLoader.log("Base URL: {}".format(base_url), level="INFO")
            MediLink_ConfigLoader.log("URL Extension: {}".format(url_extension), level="INFO")
            MediLink_ConfigLoader.log("Full URL: {}".format(url), level="INFO")
            MediLink_ConfigLoader.log("Headers: {}".format(json.dumps(headers, indent=2)), level="INFO")
            if params:
                MediLink_ConfigLoader.log("Query Parameters: {}".format(json.dumps(params, indent=2)), level="INFO")
            else:
                MediLink_ConfigLoader.log("Query Parameters: None", level="INFO")
            if data:
                MediLink_ConfigLoader.log("Request Data: {}".format(json.dumps(data, indent=2)), level="INFO")
            else:
                MediLink_ConfigLoader.log("Request Data: None", level="INFO")
            MediLink_ConfigLoader.log("=" * 80, level="INFO")

        try:
            masked_headers = headers.copy()
            if 'Authorization' in masked_headers:
                masked_headers['Authorization'] = 'Bearer ***'

            def make_request():
                if call_type == 'GET':
                    if DEBUG:
                        MediLink_ConfigLoader.log("Making GET request to: {}".format(url), level="INFO")
                    return requests.get(url, headers=headers, params=params)
                elif call_type == 'POST':
                    # Check if there are custom headers (any headers beyond Authorization and Accept)
                    custom_headers = {k: v for k, v in headers.items() if k not in ['Authorization', 'Accept']}
                    
                    if custom_headers:
                        # Log that custom headers were detected
                        MediLink_ConfigLoader.log("Custom headers detected: {}".format(custom_headers), level="DEBUG")
                    else:
                        # Set default Content-Type if no custom headers
                        headers['Content-Type'] = 'application/json'
                    
                    # Phase 1 Fix: Handle pre-serialized JSON strings for OPTUMAI Claim Actions
                    # Some GraphQL APIs require exact JSON format - if data is already a string,
                    # use data= parameter instead of json= to preserve exact formatting
                    if isinstance(data, str):
                        # Data is already serialized (e.g., from claim_actions_adapter)
                        # Use data= parameter to send as-is, ensuring Content-Type is set
                        if 'Content-Type' not in headers:
                            headers['Content-Type'] = 'application/json'
                        if DEBUG:
                            MediLink_ConfigLoader.log("Making POST request with pre-serialized JSON string to: {}".format(url), level="INFO")
                        return requests.post(url, headers=headers, data=data)
                    else:
                        # Data is a dict - use json= parameter for auto-serialization (standard behavior)
                        if DEBUG:
                            MediLink_ConfigLoader.log("Making POST request to: {}".format(url), level="INFO")
                        return requests.post(url, headers=headers, json=data)
                elif call_type == 'DELETE':
                    if DEBUG:
                        MediLink_ConfigLoader.log("Making DELETE request to: {}".format(url), level="INFO")
                    return requests.delete(url, headers=headers)
                else:
                    raise ValueError("Unsupported call type: {}".format(call_type))

            route_retry_performed = False
            trailing_question_tried = False

            while True:
                try:
                    # Make initial request
                    response = make_request()

                    # VERBOSE LOGGING: Log response details
                    if DEBUG:
                        MediLink_ConfigLoader.log("=" * 80, level="INFO")
                        MediLink_ConfigLoader.log("VERBOSE RESPONSE DETAILS", level="INFO")
                        MediLink_ConfigLoader.log("=" * 80, level="INFO")
                        MediLink_ConfigLoader.log("Response Status Code: {}".format(response.status_code), level="INFO")
                        MediLink_ConfigLoader.log("Response Headers: {}".format(json.dumps(dict(response.headers), indent=2)), level="INFO")
                        
                        try:
                            response_json = response.json()
                            MediLink_ConfigLoader.log("Response JSON: {}".format(json.dumps(response_json, indent=2)), level="INFO")
                        except ValueError:
                            MediLink_ConfigLoader.log("Response Text (not JSON): {}".format(response.text), level="INFO")
                        
                        MediLink_ConfigLoader.log("=" * 80, level="INFO")

                    # Handle 401 Unauthorized errors with token refresh and retry
                    if response.status_code == 401:
                        # Parse error response for diagnostics
                        trace_id = None
                        error_type = None
                        try:
                            error_response = response.json()
                            trace_id = error_response.get('traceId') or error_response.get('trace_id')
                            error_type = error_response.get('error') or error_response.get('error_type')
                            error_desc = error_response.get('error_description', '')
                            
                            # Check for "invalid_access_token" specifically
                            is_invalid_token = (error_type == 'invalid_access_token' or 
                                               'invalid_access_token' in error_desc.lower())
                            if is_invalid_token:
                                MediLink_ConfigLoader.log(
                                    "401 Unauthorized: invalid_access_token detected for endpoint {}. "
                                    "Clearing token cache and attempting refresh...".format(endpoint_name),
                                    level="WARNING",
                                    console_output=CONSOLE_LOGGING
                                )
                                if trace_id:
                                    MediLink_ConfigLoader.log("Trace ID: {}".format(trace_id), level="INFO")
                                
                                # Clear token cache for this endpoint (401 invalid_access_token error)
                                self.token_cache.clear(endpoint_name, reason="401 invalid_access_token")
                                
                                # Attempt to get a fresh token
                                fresh_token = self.get_access_token(endpoint_name)
                                if fresh_token:
                                    # Update headers with fresh token
                                    headers['Authorization'] = 'Bearer {}'.format(fresh_token)
                                    MediLink_ConfigLoader.log(
                                        "Token refreshed successfully. Retrying request to {}...".format(url),
                                        level="INFO",
                                        console_output=CONSOLE_LOGGING
                                    )
                                    
                                    # Retry the request once with fresh token
                                    time.sleep(0.5)  # Brief delay before retry
                                    response = make_request()
                                    
                                    # Log retry result
                                    if response.status_code == 200:
                                        MediLink_ConfigLoader.log(
                                            "Retry successful after token refresh! Request to {} now returned 200 status code.".format(url),
                                            level="INFO",
                                            console_output=CONSOLE_LOGGING
                                        )
                                    else:
                                        MediLink_ConfigLoader.log(
                                            "Retry failed after token refresh. Request to {} still returned {} status code.".format(
                                                url, response.status_code),
                                            level="ERROR",
                                            console_output=CONSOLE_LOGGING
                                        )
                                        if trace_id:
                                            MediLink_ConfigLoader.log(
                                                "Trace ID: {}. This may indicate a subscription/configuration issue. "
                                                "Verify client credentials and subscription access in OPTUMAI portal.".format(trace_id),
                                                level="ERROR",
                                                console_output=CONSOLE_LOGGING
                                            )
                                else:
                                    MediLink_ConfigLoader.log(
                                        "Failed to obtain fresh token for endpoint {}. Cannot retry request.".format(endpoint_name),
                                        level="ERROR",
                                        console_output=CONSOLE_LOGGING
                                    )
                        except (ValueError, KeyError) as e:
                            # Error response not in expected format
                            MediLink_ConfigLoader.log(
                                "401 Unauthorized error for endpoint {}. Could not parse error response: {}".format(
                                    endpoint_name, str(e)),
                                level="ERROR",
                                console_output=CONSOLE_LOGGING
                            )
                            # Still attempt token refresh (fallback for unparseable 401 responses)
                            self.token_cache.clear(endpoint_name, reason="401 unparseable error response")
                            fresh_token = self.get_access_token(endpoint_name)
                            if fresh_token:
                                headers['Authorization'] = 'Bearer {}'.format(fresh_token)
                                MediLink_ConfigLoader.log(
                                    "Token refreshed (unparseable 401 response). Retrying request...",
                                    level="INFO",
                                    console_output=CONSOLE_LOGGING
                                )
                                time.sleep(0.5)
                                response = make_request()
                            else:
                                MediLink_ConfigLoader.log(
                                    "Failed to obtain fresh token for endpoint {}. Cannot retry request.".format(endpoint_name),
                                    level="ERROR",
                                    console_output=CONSOLE_LOGGING
                                )

                    # If we get a 5xx error, wait and retry once
                    if 500 <= response.status_code < 600:
                        error_msg = "Received {} error from server for {} request to {}. Waiting 1 second before retry...".format(
                            response.status_code, call_type, url
                        )
                        MediLink_ConfigLoader.log(error_msg, level="WARNING")
                        
                        # Add more verbose logging for 504 errors specifically
                        if response.status_code == 504:
                            MediLink_ConfigLoader.log(
                                "504 Gateway Timeout detected. This usually indicates the server is overloaded or taking too long to respond. " 
                                "Retrying after 1 second delay...", 
                                level="WARNING"
                            )
                        
                        time.sleep(1)
                        response = make_request()
                        
                        # Log the retry result
                        if response.status_code == 200:
                            MediLink_ConfigLoader.log(
                                "Retry successful! Request to {} now returned 200 status code.".format(url),
                                level="INFO"
                            )
                        else:
                            MediLink_ConfigLoader.log(
                                "Retry failed. Request to {} still returned {} status code.".format(url, response.status_code),
                                level="ERROR"
                            )

                    # Handle trailing '?' fallback for POST requests with 404/500 errors
                    # Some API gateways (e.g., UHC Claims API) require trailing '?' for POST requests without query params
                    # Skip this retry for OPTUMAI endpoints - we know the correct format (no trailing '?' needed)
                    if endpoint_name == 'OPTUMAI':
                        # OPTUMAI requires exact path format per OpenAPI spec - no trailing '?' needed
                        # Log that we're skipping the retry to avoid unnecessary attempts
                        if response.status_code in [404, 500] and call_type == 'POST' and not trailing_question_tried:
                            MediLink_ConfigLoader.log(
                                "Skipping trailing '?' retry for OPTUMAI endpoint (known correct format: exact path per OpenAPI spec). Status: {}".format(
                                    response.status_code),
                                level="DEBUG"
                            )
                            trailing_question_tried = True  # Mark as tried to prevent further retry attempts
                    elif (response.status_code in [404, 500] and 
                        call_type == 'POST' and 
                        not trailing_question_tried and
                        (params is None or len(params) == 0) and
                        not url.endswith('?')):
                        
                        original_status_code = response.status_code
                        original_url = url
                        url = url + '?'
                        trailing_question_tried = True
                        
                        MediLink_ConfigLoader.log(
                            "Received {} error on POST request to {}. Retrying with trailing '?' as API gateway may require it...".format(
                                original_status_code, original_url),
                            level="INFO",
                            console_output=CONSOLE_LOGGING
                        )
                        
                        # Brief delay before retry
                        time.sleep(0.5)
                        response = make_request()
                        
                        # Log the retry result
                        if response.status_code == 200 or (200 <= response.status_code < 300):
                            MediLink_ConfigLoader.log(
                                "Retry successful with trailing '?' appended. Original error was {}. New URL: {}".format(
                                    original_status_code, url),
                                level="INFO",
                                console_output=CONSOLE_LOGGING
                            )
                        else:
                            MediLink_ConfigLoader.log(
                                "Retry with trailing '?' failed. Still received {} status code.".format(response.status_code),
                                level="WARNING",
                                console_output=CONSOLE_LOGGING
                            )
                        
                        # Continue the loop to allow full error handling on the retry response
                        continue

                    # Raise an HTTPError if the response was unsuccessful
                    response.raise_for_status()

                    return response.json()

                except requests.exceptions.HTTPError as http_err:
                    response_obj = getattr(http_err, 'response', None)
                    status_code = getattr(response_obj, 'status_code', None)
                    response_content = None
                    response_content_for_log = None

                    if response_obj is not None:
                        try:
                            response_content = response_obj.json()
                            response_content_for_log = json.dumps(response_content, indent=2)
                        except ValueError:
                            response_content = response_obj.text
                            response_content_for_log = response_obj.text

                    should_retry_route = False
                    if response_obj is not None and not route_retry_performed:
                        try:
                            should_retry_route = handle_route_mismatch_404(
                                status_code,
                                response_content,
                                call_type,
                                url,
                                CONSOLE_LOGGING
                            )
                        except Exception as remediation_err:
                            MediLink_ConfigLoader.log(
                                "Route mismatch remediation failed to start: {}".format(str(remediation_err)),
                                level="WARNING",
                                console_output=CONSOLE_LOGGING
                            )

                    if should_retry_route and not route_retry_performed:
                        route_retry_performed = True
                        time.sleep(0.5)
                        continue

                    # Some 400s are expected in normal operation (no data, payer not allowed).
                    # In batch mode, collect these into one grouped summary instead of one block per payer.
                    expected_400_reason = None
                    expected_400_level = "DEBUG"
                    expected_400_reason_code = None
                    expected_400_error_code = None
                    expected_400_next_step = None
                    expected_400_message = None
                    payer_id_for_log = None
                    err_codes_msgs = ''
                    if status_code == 400 and response_content is not None:
                        # Prefer structured errors; fall back to text scanning when provider returns a non-JSON body.
                        try:
                            if isinstance(response_content, dict):
                                err_list = response_content.get("errors") or []
                                err_codes_msgs = " ".join(
                                    str(e.get("code", "")) + " " + str(e.get("message", ""))
                                    for e in err_list if isinstance(e, dict)
                                )
                            else:
                                err_codes_msgs = str(response_content)
                        except Exception:
                            err_codes_msgs = ''

                        # Also include raw text (when available) in case JSON parsing failed upstream.
                        try:
                            if not err_codes_msgs and response_obj is not None:
                                err_codes_msgs = str(getattr(response_obj, 'text', '') or '')
                        except Exception:
                            pass

                        if ("LCLM_PS_201" in err_codes_msgs
                                or "LCLM_PS_203" in err_codes_msgs
                                or "No Data found with the given request" in err_codes_msgs):
                            expected_400_reason = "no-data (LCLM_PS_201/203)"
                            expected_400_level = "DEBUG"
                            expected_400_reason_code = NO_DATA
                            expected_400_error_code = "LCLM_PS_201/203"
                            expected_400_next_step = next_step_hint(NO_DATA) if next_step_hint else "Verify payerId/TIN/date range."
                            expected_400_message = "No data found with given request parameters"
                        elif ("LCLM_PS_105" in err_codes_msgs or "LCLM_PS_202" in err_codes_msgs):
                            expected_400_reason = "payer not allowed (LCLM_PS_105/202)"
                            expected_400_level = "INFO"
                            expected_400_reason_code = UNSUPPORTED_PAYER
                            expected_400_error_code = "LCLM_PS_105/202"
                            expected_400_next_step = next_step_hint(UNSUPPORTED_PAYER) if next_step_hint else "Confirm allowed payers for this TIN with UHC or remove payer from list."
                            # Best-effort payerId extraction for operator logs
                            try:
                                if isinstance(masked_headers, dict):
                                    payer_id_for_log = masked_headers.get('payerId') or masked_headers.get('payer_id')
                                if payer_id_for_log is None and isinstance(params, dict):
                                    payer_id_for_log = params.get('payerId') or params.get('payer_id')
                            except Exception:
                                payer_id_for_log = None
                            expected_400_message = "Authorization error: Payer ID {} not allowed".format(
                                payer_id_for_log or 'unknown')

                    if expected_400_reason:
                        try:
                            setattr(http_err, '_medicafe_expected_400_logged', True)
                            setattr(http_err, '_medicafe_reason_code', expected_400_reason_code)
                            setattr(http_err, '_medicafe_next_step', expected_400_next_step)
                            setattr(http_err, '_medicafe_error_message', expected_400_message)
                            setattr(http_err, '_medicafe_error_code', expected_400_error_code)
                        except Exception:
                            pass

                        try:
                            consolidated = _record_request_failure_batch(
                                endpoint_name, call_type, url,
                                status_code=status_code,
                                reason_code=expected_400_reason_code,
                                reason_label=expected_400_reason,
                                error_code=expected_400_error_code,
                                error_text=err_codes_msgs or str(http_err),
                                headers=masked_headers,
                                params=params,
                                data=data,
                                next_step=expected_400_next_step,
                                exception_type=type(http_err).__name__
                            )
                        except Exception:
                            consolidated = False
                        if not consolidated:
                            if expected_400_reason.startswith("no-data"):
                                MediLink_ConfigLoader.log(
                                    "HTTP 400 {}: {} {} - skipping verbose error dump.".format(
                                        expected_400_reason, call_type, url
                                    ),
                                    level=expected_400_level,
                                    console_output=CONSOLE_LOGGING
                                )
                            else:
                                MediLink_ConfigLoader.log(
                                    "HTTP 400 {}: {} {} payerId={}. Next: {}".format(
                                        expected_400_reason, call_type, url,
                                        payer_id_for_log or 'unknown',
                                        expected_400_next_step or "Confirm allowed payers for this TIN with UHC or remove payer from list."
                                    ),
                                    level=expected_400_level,
                                    console_output=CONSOLE_LOGGING
                                )
                    else:
                        MediLink_ConfigLoader.log("=" * 80, level="ERROR")
                        MediLink_ConfigLoader.log("VERBOSE HTTP ERROR DETAILS", level="ERROR")
                        MediLink_ConfigLoader.log("=" * 80, level="ERROR")

                        if response_obj is None:
                            log_message = (
                                "HTTPError with no response. "
                                "URL: {url}, "
                                "Method: {method}, "
                                "Params: {params}, "
                                "Data: {data}, "
                                "Headers: {masked_headers}, "
                                "Error: {error}"
                            ).format(
                                url=url,
                                method=call_type,
                                params=params,
                                data=data,
                                masked_headers=masked_headers,
                                error=str(http_err)
                            )
                            MediLink_ConfigLoader.log(log_message, level="ERROR")
                        else:
                            MediLink_ConfigLoader.log("HTTP Error Status Code: {}".format(status_code), level="ERROR")
                            MediLink_ConfigLoader.log("HTTP Error URL: {}".format(url), level="ERROR")
                            MediLink_ConfigLoader.log("HTTP Error Method: {}".format(call_type), level="ERROR")
                            MediLink_ConfigLoader.log("HTTP Error Headers: {}".format(json.dumps(masked_headers, indent=2)), level="ERROR")
                            
                            if params:
                                MediLink_ConfigLoader.log("HTTP Error Query Params: {}".format(json.dumps(params, indent=2)), level="ERROR")
                            if data:
                                # Handle both dict and pre-serialized string data
                                if isinstance(data, str):
                                    try:
                                        # Try to parse and pretty-print if it's JSON
                                        parsed_data = json.loads(data)
                                        MediLink_ConfigLoader.log("HTTP Error Request Data: {}".format(json.dumps(parsed_data, indent=2)), level="ERROR")
                                    except (ValueError, TypeError):
                                        # If not valid JSON, log as string (truncate if too long)
                                        data_preview = data[:500] + "..." if len(data) > 500 else data
                                        MediLink_ConfigLoader.log("HTTP Error Request Data (string): {}".format(data_preview), level="ERROR")
                                else:
                                    MediLink_ConfigLoader.log("HTTP Error Request Data: {}".format(json.dumps(data, indent=2)), level="ERROR")
                            
                            if isinstance(response_content, (dict, list)):
                                MediLink_ConfigLoader.log("HTTP Error Response JSON: {}".format(response_content_for_log), level="ERROR")
                            else:
                                MediLink_ConfigLoader.log("HTTP Error Response Text: {}".format(response_content_for_log), level="ERROR")

                            # Format data for log message (handle both dict and string)
                            data_for_log = data
                            if isinstance(data, str):
                                try:
                                    # Try to parse and format if it's JSON
                                    parsed_data = json.loads(data)
                                    data_for_log = json.dumps(parsed_data, indent=2)
                                except (ValueError, TypeError):
                                    # If not valid JSON, use as-is (truncate if too long)
                                    data_for_log = data[:500] + "..." if len(data) > 500 else data
                            elif isinstance(data, (dict, list)):
                                data_for_log = json.dumps(data, indent=2)
                            
                            log_message = (
                                "HTTPError: Status Code: {status}, "
                                "URL: {url}, "
                                "Method: {method}, "
                                "Params: {params}, "
                                "Data: {data}, "
                                "Headers: {masked_headers}, "
                                "Response Content: {content}"
                            ).format(
                                status=status_code,
                                url=url,
                                method=call_type,
                                params=params,
                                data=data_for_log,
                                masked_headers=masked_headers,
                                content=response_content
                            )
                            MediLink_ConfigLoader.log(log_message, level="ERROR")
                            # Provide a brief 404 route-match hint when applicable (best-effort, console-gated)
                            try:
                                from MediCafe.api_hints import emit_404_route_hint
                                emit_404_route_hint(call_type, url, status_code, response_content, console=CONSOLE_LOGGING)
                            except Exception:
                                pass

                        MediLink_ConfigLoader.log("=" * 80, level="ERROR")
                    raise

        except requests.exceptions.RequestException as req_err:
            # HTTPError is a RequestException; inner handler may have already logged no-data and raised.
            # Skip verbose dump here to avoid duplicate ERROR blobs for expected 400s.
            skip_verbose = bool(getattr(req_err, '_medicafe_expected_400_logged', False))
            if not skip_verbose and isinstance(req_err, requests.exceptions.HTTPError):
                resp = getattr(req_err, 'response', None)
                status = getattr(resp, 'status_code', None) if resp else None
                if status == 400 and resp is not None:
                    try:
                        body = resp.json()
                    except Exception:
                        body = None
                    codes_msgs = ''
                    if isinstance(body, dict):
                        err_list = body.get("errors") or []
                        codes_msgs = " ".join(
                            str(e.get("code", "")) + " " + str(e.get("message", ""))
                            for e in err_list if isinstance(e, dict)
                        )
                    else:
                        # Some providers return plain text bodies for 400 responses.
                        try:
                            codes_msgs = str(getattr(resp, 'text', '') or '')
                        except Exception:
                            codes_msgs = ''
                    if ("LCLM_PS_201" in codes_msgs
                            or "LCLM_PS_203" in codes_msgs
                            or "No Data found with the given request" in codes_msgs
                            or "LCLM_PS_105" in codes_msgs
                            or "LCLM_PS_202" in codes_msgs):
                        skip_verbose = True
            if skip_verbose:
                raise
            # Log connection-related issues or other request exceptions with verbose details
            MediLink_ConfigLoader.log("=" * 80, level="ERROR")
            MediLink_ConfigLoader.log("VERBOSE REQUEST EXCEPTION DETAILS", level="ERROR")
            MediLink_ConfigLoader.log("=" * 80, level="ERROR")
            MediLink_ConfigLoader.log("RequestException Type: {}".format(type(req_err).__name__), level="ERROR")
            MediLink_ConfigLoader.log("RequestException URL: {}".format(url), level="ERROR")
            MediLink_ConfigLoader.log("RequestException Method: {}".format(call_type), level="ERROR")
            MediLink_ConfigLoader.log("RequestException Headers: {}".format(json.dumps(masked_headers, indent=2)), level="ERROR")
            if params:
                MediLink_ConfigLoader.log("RequestException Query Params: {}".format(json.dumps(params, indent=2)), level="ERROR")
            if data:
                # Handle both dict and pre-serialized string data
                if isinstance(data, str):
                    try:
                        parsed_data = json.loads(data)
                        MediLink_ConfigLoader.log("RequestException Request Data: {}".format(json.dumps(parsed_data, indent=2)), level="ERROR")
                    except (ValueError, TypeError):
                        data_preview = data[:500] + "..." if len(data) > 500 else data
                        MediLink_ConfigLoader.log("RequestException Request Data (string): {}".format(data_preview), level="ERROR")
                else:
                    MediLink_ConfigLoader.log("RequestException Request Data: {}".format(json.dumps(data, indent=2)), level="ERROR")
            MediLink_ConfigLoader.log("RequestException Error: {}".format(str(req_err)), level="ERROR")
            MediLink_ConfigLoader.log("=" * 80, level="ERROR")
            
            # Also log concise version
            log_message = (
                "RequestException: No response received. "
                "URL: {url}, "
                "Method: {method}, "
                "Params: {params}, "
                "Data: {data}, "
                "Headers: {masked_headers}, "
                "Error: {error}"
            ).format(
                url=url,
                method=call_type,
                params=params,
                data=data if not isinstance(data, str) or len(data) < 200 else data[:200] + "...",
                masked_headers=masked_headers,
                error=str(req_err)
            )
            MediLink_ConfigLoader.log(log_message, level="ERROR")
            # Emit concise connectivity hint for DNS/proxy issues (best-effort, console-gated)
            try:
                from MediCafe.api_hints import emit_network_hint
                emit_network_hint(endpoint_name, url, req_err, console=CONSOLE_LOGGING)
            except Exception:
                pass
            raise

        except Exception as e:
            # Capture traceback for unexpected exceptions
            tb = traceback.format_exc()
            log_message = (
                "Unexpected error: {error}. "
                "URL: {url}, "
                "Method: {method}, "
                "Params: {params}, "
                "Data: {data}, "
                "Headers: {masked_headers}. "
                "Traceback: {traceback}"
            ).format(
                error=str(e),
                url=url,
                method=call_type,
                params=params,
                data=data,
                masked_headers=masked_headers,
                traceback=tb
            )
            MediLink_ConfigLoader.log(log_message, level="ERROR")
            raise

def fetch_payer_name_from_api(*args, **kwargs):
    """
    Fetch payer name by Payer ID with backward-compatible calling styles.

    Supported call signatures:
    - fetch_payer_name_from_api(client, payer_id, config, primary_endpoint='AVAILITY')
    - fetch_payer_name_from_api(payer_id, config, primary_endpoint='AVAILITY')  # client inferred via factory
    - fetch_payer_name_from_api(payer_id=payer_id, config=config, client=client, primary_endpoint='AVAILITY')
    - fetch_payer_name_from_api(..., quiet_mode=False)  # Suppress verbose logging when True
    """
    # Normalize arguments
    client = None
    payer_id = None
    config = None
    primary_endpoint = kwargs.get('primary_endpoint', 'AVAILITY')
    quiet_mode = kwargs.get('quiet_mode', False)

    if 'client' in kwargs:
        client = kwargs.get('client')
    if 'payer_id' in kwargs:
        payer_id = kwargs.get('payer_id')
    if 'config' in kwargs:
        config = kwargs.get('config')

    if len(args) >= 3 and isinstance(args[0], APIClient):
        client = args[0]
        payer_id = args[1]
        config = args[2]
        if len(args) >= 4 and 'primary_endpoint' not in kwargs:
            primary_endpoint = args[3]
    elif len(args) >= 2 and isinstance(args[0], str) and client is None:
        # Called as (payer_id, config, [primary_endpoint])
        payer_id = args[0]
        config = args[1]
        if len(args) >= 3 and 'primary_endpoint' not in kwargs:
            primary_endpoint = args[2]
    elif len(args) == 1 and isinstance(args[0], APIClient) and (payer_id is None or config is None):
        # Partial positional with client first, other params via kwargs
        client = args[0]

    # Acquire client via factory if not provided
    if client is None:
        try:
            from MediCafe.core_utils import get_api_client
            client = get_api_client()
            if client is None:
                client = APIClient()
        except Exception:
            client = APIClient()

    # Basic validation
    if not isinstance(client, APIClient):
        error_message = "Invalid client provided. Expected an instance of APIClient."
        MediLink_ConfigLoader.log(error_message, level="ERROR")
        raise ValueError(error_message)
    if payer_id is None or config is None:
        raise ValueError("Missing required arguments: payer_id and config are required")
    
    # TODO: FUTURE IMPLEMENTATION - Remove AVAILITY default when other endpoints have payer-list APIs
    # Currently defaulting to AVAILITY as it's the only endpoint with confirmed payer-list functionality
    # In the future, this should be removed and the system should dynamically detect which endpoints
    # have payer-list capabilities and use them accordingly.
    # Suggested approach: add endpoint capability metadata (e.g., supports_payer_list=true) in config and
    # prefer primary_endpoint when capable, with AVAILITY only as final fallback for backward compatibility.
    if primary_endpoint != 'AVAILITY':
        MediLink_ConfigLoader.log("[Fetch payer name from API] Overriding {} with AVAILITY (default until multi-endpoint payer-list support is implemented).".format(primary_endpoint), level="DEBUG")
        primary_endpoint = 'AVAILITY'
    
    try:
        from MediCafe.core_utils import extract_medilink_config
        medi = extract_medilink_config(config)
        endpoints = medi.get('endpoints', {})
    except KeyError as e:
        error_message = "Configuration loading error in fetch_payer_name_from_api: Missing key {0}... Attempting to reload configuration.".format(e)
        # print(error_message)
        MediLink_ConfigLoader.log(error_message, level="ERROR")
        # Attempt to reload configuration if key is missing
        config, _ = MediLink_ConfigLoader.load_configuration()
        # SAFE FALLBACK: if endpoints still missing, fall back to AVAILITY only and proceed.
        from MediCafe.core_utils import extract_medilink_config
        medi = extract_medilink_config(config)
        endpoints = medi.get('endpoints', {})
        if not endpoints:
            MediLink_ConfigLoader.log("Endpoints configuration missing after reload. Falling back to AVAILITY-only logic.", level="WARNING")
        MediLink_ConfigLoader.log("Re-loaded configuration successfully.", level="INFO")
    
    # Sanitize and validate payer_id
    if not isinstance(payer_id, str):
        payer_id = str(payer_id)
    
    payer_id = ''.join(char for char in payer_id if char.isalnum())
    
    if not payer_id:
        error_message = "Invalid payer_id in API v3: {}. Must contain a string of alphanumeric characters.".format(payer_id)
        MediLink_ConfigLoader.log(error_message, level="ERROR")
        print(error_message)
    
    # Payer-list is AVAILITY-only. Dynamic multi-endpoint payer-list selection deferred until other backends offer a payer-list API.

    # If HTTP client is unavailable or endpoints missing, use offline fallback only when allowed (TestMode or env flag)
    try:
        http_unavailable = (requests is None)  # type: ignore[name-defined]
    except Exception:
        http_unavailable = True
    # Determine whether offline fallback is permitted
    # Align with main flow: default True when TestMode key is absent
    offline_allowed = True
    try:
        from MediCafe.core_utils import extract_medilink_config
        medi_local = extract_medilink_config(config)
        offline_allowed = bool(medi_local.get('TestMode', True))
    except Exception:
        offline_allowed = True
    try:
        if os.environ.get('MEDICAFE_OFFLINE_PERMISSIVE', '').strip().lower() in ('1', 'true', 'yes', 'y'):
            offline_allowed = True
            MediLink_ConfigLoader.log(
                "MEDICAFE_OFFLINE_PERMISSIVE active; payer lookup may use degraded fallback metadata.",
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
    except Exception:
        pass

    if offline_allowed and (http_unavailable or not isinstance(endpoints, dict) or not endpoints):
        try:
            # Prefer crosswalk mapping when available
            try:
                _, cw = MediLink_ConfigLoader.load_configuration()
            except Exception:
                cw = {}
            payer_mappings = {}
            try:
                if isinstance(cw, dict):
                    payer_mappings = cw.get('payer_mappings', {}) or {}
            except Exception:
                payer_mappings = {}

            if payer_id in payer_mappings:
                resolved = payer_mappings.get(payer_id)
                MediLink_ConfigLoader.log(
                    "Using crosswalk mapping for payer {} -> {} [OFFLINE_FALLBACK:crosswalk_mapping offline_permissive_active={} fallback_source=crosswalk fallback_count={}]".format(payer_id, resolved, offline_allowed, len(payer_mappings)),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
                return resolved
            # Safe minimal hardcoded map as last resort (test/offline only)
            fallback_map = {
                '87726': 'UnitedHealthcare',
                '06111': 'Aetna',
                '03432': 'Cigna',
                '95378': 'Anthem Blue Cross',
                '95467': 'Blue Shield',
            }
            if payer_id in fallback_map:
                MediLink_ConfigLoader.log(
                    "Using offline fallback for payer {} -> {} [OFFLINE_FALLBACK:hardcoded offline_permissive_active={} fallback_source=hardcoded fallback_count={}]".format(payer_id, fallback_map[payer_id], offline_allowed, len(fallback_map)),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
                return fallback_map[payer_id]
        except Exception:
            pass

    # Payer-list is AVAILITY-only; payer_list_endpoint on other endpoints (e.g. UHCAPI) is ignored.
    if endpoints.get('AVAILITY') is not None:
        endpoint_order = ['AVAILITY']
    else:
        MediLink_ConfigLoader.log("AVAILITY endpoint required for payer-list but not in config; will attempt AVAILITY and may fail.", level="INFO")
        endpoint_order = ['AVAILITY']
    MediLink_ConfigLoader.log("Endpoint order for payer lookup: {}".format(endpoint_order), level="DEBUG")

    for endpoint_name in endpoint_order:
        try:
            # Path from AVAILITY config only; default matches Availity Payer List 1.0.5 path.
            endpoint_url = endpoints.get('AVAILITY', {}).get('payer_list_endpoint', '/availity-payer-list')
            
            # AVAILITY Payer List rate limiting: enforce 200ms (1/5 sec) minimum spacing
            # Demo app limit: 5 calls per second
            global _AVAILITY_PAYER_LIST_LAST_CALL
            if endpoint_name == 'AVAILITY':
                elapsed = time.time() - _AVAILITY_PAYER_LIST_LAST_CALL
                if elapsed < 0.2:  # 200ms = 1/5 second
                    sleep_time = 0.2 - elapsed
                    MediLink_ConfigLoader.log(
                        "AVAILITY payer-list rate limit: sleeping {:.3f}s to maintain 5 calls/sec".format(sleep_time),
                        level="DEBUG"
                    )
                    time.sleep(sleep_time)
                _AVAILITY_PAYER_LIST_LAST_CALL = time.time()
            
            # Availity 1.0.5 requires Accept: application.json (not application/json)
            response = client.make_api_call(
                endpoint_name, 'GET', endpoint_url, {'payerId': payer_id}, 
                headers={'Accept': 'application.json'}, 
                quiet_mode=quiet_mode
            )
            
            # Check if response exists
            if not response:
                log_message = "No response from {0} for Payer ID {1}".format(endpoint_name, payer_id)
                print(log_message)
                MediLink_ConfigLoader.log(log_message, level="ERROR")
                continue
            
            # Normalize response shape: API 1.0.5 returns array of payers; legacy may return dict with 'payers' key
            if isinstance(response, list):
                # New API format (1.0.5): top-level array of payer objects
                payers = response
            elif isinstance(response, dict):
                # Legacy format: dict with 'payers' key, or possibly body status code
                # Check body status code only for legacy dict format (new array format has no statuscode)
                status_code = response.get('statuscode', 200)
                if status_code != 200:
                    log_message = "Invalid response status code {0} from {1} for Payer ID {2}. Message: {3}".format(
                        status_code, endpoint_name, payer_id, response.get('message', 'No message'))
                    print(log_message)
                    MediLink_ConfigLoader.log(log_message, level="ERROR")
                    continue
                payers = response.get('payers', [])
            else:
                # Unexpected format
                payers = []
            
            # Validate payers list
            if not payers:
                log_message = "No payer found at {0} for ID {1}. Response: {2}".format(endpoint_name, payer_id, response)
                print(log_message)
                MediLink_ConfigLoader.log(log_message, level="INFO")
                continue
            
            # Extract the payer name from the first payer in the list
            payer_name = payers[0].get('displayName') or payers[0].get('name')
            if not payer_name:
                log_message = "Payer name not found in the response from {0} for ID {1}. Response: {2}".format(
                    endpoint_name, payer_id, response)
                print(log_message)
                MediLink_ConfigLoader.log(log_message, level="ERROR")
                continue
            
            # Log successful payer retrieval with source indicator
            log_message = "Found payer at {0} for ID {1}: {2} [API_SUCCESS]".format(endpoint_name, payer_id, payer_name)
            MediLink_ConfigLoader.log(log_message, level="DEBUG")
            return payer_name
        
        except Exception as e:
            # Enhanced error logging for AVAILITY: log endpoint response body when available
            if not quiet_mode:
                error_message = "Error calling {0} for Payer ID {1}. Exception: {2}".format(endpoint_name, payer_id, e)
                
                # For AVAILITY, try to extract and log response body (exception or its cause may have .response)
                if endpoint_name == 'AVAILITY':
                    resp_obj = getattr(e, 'response', None) or (getattr(e, '__cause__', None) and getattr(e.__cause__, 'response', None))
                    if resp_obj is not None:
                        try:
                            response_body = resp_obj.json()
                            error_message += " | Response body: {}".format(response_body)
                        except Exception:
                            try:
                                error_message += " | Response text: {}".format(getattr(resp_obj, 'text', '')[:500])
                            except Exception:
                                pass
                
                MediLink_ConfigLoader.log(error_message, level="INFO")

    # Offline/local fallback mapping for common payer IDs when API endpoints are unavailable
    # Only when offline fallback is permitted
    if offline_allowed:
        try:
            # Prefer crosswalk mapping first
            try:
                _, cw = MediLink_ConfigLoader.load_configuration()
            except Exception:
                cw = {}
            payer_mappings = {}
            try:
                if isinstance(cw, dict):
                    payer_mappings = cw.get('payer_mappings', {}) or {}
            except Exception:
                payer_mappings = {}
            if payer_id in payer_mappings:
                resolved = payer_mappings.get(payer_id)
                MediLink_ConfigLoader.log(
                    "Using crosswalk mapping for payer {} -> {} [OFFLINE_FALLBACK:crosswalk_mapping]".format(payer_id, resolved),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
                return resolved
            # Minimal fallback map if crosswalk has no mapping (still offline-only)
            fallback_map = {
                '87726': 'UnitedHealthcare',
                '06111': 'Aetna',
                '03432': 'Cigna',
                '95378': 'Anthem Blue Cross',
                '95467': 'Blue Shield',
            }
            if payer_id in fallback_map:
                MediLink_ConfigLoader.log(
                    "Using offline fallback for payer {} -> {} [OFFLINE_FALLBACK:hardcoded]".format(payer_id, fallback_map[payer_id]),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
                return fallback_map[payer_id]
        except Exception:
            pass

    # If all endpoints fail
    final_error_message = "All endpoints exhausted for Payer ID {0}.".format(payer_id)
    print(final_error_message)
    MediLink_ConfigLoader.log(final_error_message, level="CRITICAL")
    raise ValueError(final_error_message)

def get_claim_summary_by_provider(client, tin, first_service_date, last_service_date, payer_id, get_standard_error='false', transaction_id=None, env=None):
    """Compatibility wrapper for MediCafe.api_core_operations.get_claim_summary_by_provider."""
    return _api_ops._IMPL_get_claim_summary_by_provider(client, tin, first_service_date, last_service_date, payer_id, get_standard_error, transaction_id, env)



def get_claim_status_by_member_data(client, payer_id, member_id=None, member_first_name=None, member_last_name=None, member_dob=None, service_start_date=None, service_end_date=None, patient_account_number=None):
    """Compatibility wrapper for MediCafe.api_core_operations.get_claim_status_by_member_data."""
    return _api_ops._IMPL_get_claim_status_by_member_data(client, payer_id, member_id, member_first_name, member_last_name, member_dob, service_start_date, service_end_date, patient_account_number)



def _build_uhcapi_member_search_request(member_id, member_first_name, member_last_name, member_dob, service_start_date, service_end_date, patient_account_number=None):
    """Compatibility wrapper for MediCafe.api_core_operations._build_uhcapi_member_search_request."""
    return _api_ops._IMPL__build_uhcapi_member_search_request(member_id, member_first_name, member_last_name, member_dob, service_start_date, service_end_date, patient_account_number)



def _transform_uhcapi_member_response_to_legacy(uhc_response):
    """Compatibility wrapper for MediCafe.api_core_operations._transform_uhcapi_member_response_to_legacy."""
    return _api_ops._IMPL__transform_uhcapi_member_response_to_legacy(uhc_response)



def get_claim_status_by_submission_context(client, transaction_id=None, payer_id=None, member_id=None, member_first_name=None, member_last_name=None, member_dob=None, service_start_date=None, service_end_date=None, patient_account_number=None, lookup_type='both'):
    """Compatibility wrapper for MediCafe.api_core_operations.get_claim_status_by_submission_context."""
    return _api_ops._IMPL_get_claim_status_by_submission_context(client, transaction_id, payer_id, member_id, member_first_name, member_last_name, member_dob, service_start_date, service_end_date, patient_account_number, lookup_type)



def get_eligibility(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi):
    """Compatibility wrapper for MediCafe.api_core_operations.get_eligibility."""
    return _api_ops._IMPL_get_eligibility(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi)


def get_eligibility_v3(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi, first_name=None, last_name=None, payer_label=None, payer_name=None, service_start=None, service_end=None, middle_name=None, gender=None, ssn=None, city=None, state=None, zip=None, group_number=None, service_type_code=None, provider_first_name=None, tax_id_number=None, provider_name_id=None, corporate_tax_owner_id=None, corporate_tax_owner_name=None, organization_name=None, organization_id=None, identify_service_level_deductible=True):
    """Compatibility wrapper for MediCafe.api_core_operations.get_eligibility_v3."""
    return _api_ops._IMPL_get_eligibility_v3(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi, first_name, last_name, payer_label, payer_name, service_start, service_end, middle_name, gender, ssn, city, state, zip, group_number, service_type_code, provider_first_name, tax_id_number, provider_name_id, corporate_tax_owner_id, corporate_tax_owner_name, organization_name, organization_id, identify_service_level_deductible)


def get_eligibility_super_connector(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi, first_name=None, last_name=None, payer_label=None, payer_name=None, service_start=None, service_end=None, middle_name=None, gender=None, ssn=None, city=None, state=None, zip=None, group_number=None, service_type_code=None, provider_first_name=None, tax_id_number=None, provider_name_id=None, corporate_tax_owner_id=None, corporate_tax_owner_name=None, organization_name=None, organization_id=None, identify_service_level_deductible=True):
    """Compatibility wrapper for MediCafe.api_core_operations.get_eligibility_super_connector."""
    return _api_ops._IMPL_get_eligibility_super_connector(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi, first_name, last_name, payer_label, payer_name, service_start, service_end, middle_name, gender, ssn, city, state, zip, group_number, service_type_code, provider_first_name, tax_id_number, provider_name_id, corporate_tax_owner_id, corporate_tax_owner_name, organization_name, organization_id, identify_service_level_deductible)


def is_test_mode(client, body, endpoint_type):
    """
    Checks if Test Mode is enabled in the client's configuration and simulates the response if it is.

    :param client: An instance of APIClient
    :param body: The intended request body
    :param endpoint_type: The type of endpoint being accessed ('claim_submission' or 'claim_details')
    :return: A dummy response simulating the real API call if Test Mode is enabled, otherwise None
    """
    if client.config.get("MediLink_Config", {}).get("TestMode", True):
        print("Test Mode is enabled! API Call not executed.")
        print("\nIntended request body:", body)
        MediLink_ConfigLoader.log("Test Mode is enabled! Simulating 1 second delay for API response for {}.".format(endpoint_type), level="INFO")
        time.sleep(1)
        MediLink_ConfigLoader.log("Intended request body: {}".format(body), level="INFO")

        if endpoint_type == 'claim_submission':
            dummy_response = {
                "transactionId": "CS07180420240328013411240",  # This is the tID for the sandbox Claim Acknowledgement endpoint.
                "x12ResponseData": "ISA*00* *00* *ZZ*TEST1234567890 *33*TEST *210101*0101*^*00501*000000001*0*P*:~GS*HC*TEST1234567890*TEST*20210101*0101*1*X*005010X222A1~ST*837*000000001*005010X222A1~BHT*0019*00*00001*20210101*0101*CH~NM1*41*2*TEST SUBMITTER*****46*TEST~PER*IC*TEST CONTACT*TE*1234567890~NM1*40*2*TEST RECEIVER*****46*TEST~HL*1**20*1~NM1*85*2*TEST PROVIDER*****XX*1234567890~N3*TEST ADDRESS~N4*TEST CITY*TEST STATE*12345~REF*EI*123456789~PER*IC*TEST PROVIDER*TE*1234567890~NM1*87*2~N3*TEST ADDRESS~N4*TEST CITY*TEST STATE*12345~HL*2*1*22*0~SBR*P*18*TEST GROUP******CI~NM1*IL*1*TEST PATIENT****MI*123456789~N3*TEST ADDRESS~N4*TEST CITY*TEST STATE*12345~DMG*D8*19800101*M~NM1*PR*2*TEST INSURANCE*****PI*12345~CLM*TESTCLAIM*100***12:B:1*Y*A*Y*Y*P~REF*D9*TESTREFERENCE~HI*ABK:TEST~NM1*DN*1*TEST DOCTOR****XX*1234567890~LX*1~SV1*HC:TEST*100*UN*1***1~DTP*472*RD8*20210101-20210101~REF*6R*TESTREFERENCE~SE*30*000000001~GE*1*1~IEA*1*000000001~",
                "responseType": "dummy_response_837999",
                "message": "Test Mode: Claim validated and sent for further processing"
            }
        elif endpoint_type == 'claim_details':
            dummy_response = {
                "responseType": "dummy_response_277CA-CH",
                "x12ResponseData": "ISA*00* *00*  *ZZ*841162764 *ZZ*UB920086 *240318*0921*^*00501*000165687*0*T*:~GS*HN*841162764*UB920086*20240318*0921*0165687*X*005010X214~ST*277*000000006*005010X214~... SE*116*000000006~GE*1*0165687~IEA*1*000165687~",
                "statuscode": "000",
                "message:": ""
            }
        return dummy_response
    return None

def _detect_inline_ack_type(response_type, x12_data):
    """Compatibility wrapper for MediCafe.api_core_operations._detect_inline_ack_type."""
    return _api_ops._IMPL__detect_inline_ack_type(response_type, x12_data)



def _optumai_search277ca_ack_success_but_payload_empty(ack, success_status_codes):
    """Compatibility wrapper for MediCafe.api_core_operations._optumai_search277ca_ack_success_but_payload_empty."""
    return _api_ops._IMPL__optumai_search277ca_ack_success_but_payload_empty(ack, success_status_codes)



def _search_optumai_277ca_with_delayed_retry(client, transaction_id, payer_id, sleep_fn=None):
    """Compatibility wrapper for MediCafe.api_core_operations._search_optumai_277ca_with_delayed_retry."""
    return _api_ops._IMPL__search_optumai_277ca_with_delayed_retry(client, transaction_id, payer_id, sleep_fn)



def submit_uhc_claim(client, x12_request_data):
    """Compatibility wrapper for MediCafe.api_core_operations.submit_uhc_claim."""
    return _api_ops._IMPL_submit_uhc_claim(client, x12_request_data)


# -----------------------------------------------------------------------------
# Helper: Optional acknowledgment (277CA) test endpoint
# -----------------------------------------------------------------------------

def test_acknowledgment(client, transaction_id, config, endpoint_name='UHCAPI'):
    """Compatibility wrapper for MediCafe.api_core_operations.test_acknowledgment."""
    return _api_ops._IMPL_test_acknowledgment(client, transaction_id, config, endpoint_name)


if __name__ == "__main__":
    # Use factory for consistency but fallback to direct instantiation for testing
    try:
        from MediCafe.core_utils import get_api_client
        client = get_api_client()
        if client is None:
            client = APIClient()
    except ImportError:
        client = APIClient()
    
    # Define a configuration to enable or disable tests
    test_config = {
        'test_fetch_payer_name': False,
        'test_claim_summary': False,
        'test_eligibility': False,
        'test_eligibility_v3': False,
        'test_eligibility_super_connector': False,
        'test_claim_submission': False,
    }
    
    try:
        api_test_cases = client.config['MediLink_Config']['API Test Case']
        
        # Test 1: Fetch Payer Name
        if test_config.get('test_fetch_payer_name', False):
            try:
                for case in api_test_cases:
                    payer_name = fetch_payer_name_from_api(client, case['payer_id'], client.config)
                    print("*** TEST API: Payer Name: {}".format(payer_name))
            except Exception as e:
                print("*** TEST API: Error in Fetch Payer Name Test: {}".format(e))
        
        # Test 2: Get Claim Summary
        if test_config.get('test_claim_summary', False):
            try:
                for case in api_test_cases:
                    claim_summary = get_claim_summary_by_provider(client, case['provider_tin'], '05/01/2024', '06/23/2024', case['payer_id'])
                    print("TEST API: Claim Summary: {}".format(claim_summary))
            except Exception as e:
                print("TEST API: Error in Claim Summary Test: {}".format(e))
        
        # Test 3: Get Eligibility
        if test_config.get('test_eligibility', False):
            try:
                for case in api_test_cases:
                    eligibility = get_eligibility(client, case['payer_id'], case['provider_last_name'], case['search_option'], 
                                                  case['date_of_birth'], case['member_id'], case['npi'])
                    print("TEST API: Eligibility: {}".format(eligibility))
            except Exception as e:
                print("TEST API: Error in Eligibility Test: {}".format(e))

        # Test 4: Get Eligibility v3
        if test_config.get('test_eligibility_v3', False):
            try:
                for case in api_test_cases:
                    eligibility_v3 = get_eligibility_v3(client, payer_id=case['payer_id'], provider_last_name=case['provider_last_name'], 
                                                        search_option=case['search_option'], date_of_birth=case['date_of_birth'], 
                                                        member_id=case['member_id'], npi=case['npi'])
                    print("TEST API: Eligibility v3: {}".format(eligibility_v3))
            except Exception as e:
                print("TEST API: Error in Eligibility v3 Test: {}".format(e))

        # Test 5: Get Eligibility Super Connector (GraphQL)
        if test_config.get('test_eligibility_super_connector', False):
            try:
                for case in api_test_cases:
                    eligibility_super_connector = get_eligibility_super_connector(client, payer_id=case['payer_id'], provider_last_name=case['provider_last_name'], 
                                                                                search_option=case['search_option'], date_of_birth=case['date_of_birth'], 
                                                                                member_id=case['member_id'], npi=case['npi'])
                    print("TEST API: Eligibility Super Connector: {}".format(eligibility_super_connector))
            except Exception as e:
                print("TEST API: Error in Eligibility Super Connector Test: {}".format(e))

        """
        # Example of iterating over multiple patients (if needed)
        patients = [
            {'payer_id': '87726', 'provider_last_name': 'VIDA', 'search_option': 'MemberIDDateOfBirth', 'date_of_birth': '1980-01-01', 'member_id': '123456789', 'npi': '9876543210'},
            {'payer_id': '87726', 'provider_last_name': 'SMITH', 'search_option': 'MemberIDDateOfBirth', 'date_of_birth': '1970-02-02', 'member_id': '987654321', 'npi': '1234567890'},
            # Add more patients as needed
        ]

        for patient in patients:
            try:
                eligibility = get_eligibility(client, patient['payer_id'], patient['provider_last_name'], patient['search_option'], patient['date_of_birth'], patient['member_id'], patient['npi'])
                print("Eligibility for {}: {}".format(patient['provider_last_name'], eligibility))
            except Exception as e:
                print("Error in getting eligibility for {}: {}".format(patient['provider_last_name'], e))
        """
        # Test 6: UHC Claim Submission
        if test_config.get('test_claim_submission', False):
            try:
                x12_request_data = (
                    "ISA*00* *00* *ZZ*BRT219991205 *33*87726 *170417*1344*^*00501*019160001*0*P*:~GS*HC*BRT219991205*B2BRTA*20170417*134455*19160001*X*005010X222A1~ST*837*000000001*005010X222A1~BHT*0019*00*00001*20170417*134455*CH~NM1*41*2*B00099999819*****46*BB2B~PER*IC*NO NAME*TE*1234567890~NM1*40*2*TIGER*****46*87726~HL*1**20*1~NM1*85*2*XYZ ADDRESS*****XX*1073511762~N3*123 CITY#680~N4*STATE*TG*98765~REF*EI*943319804~PER*IC*XYZ ADDRESS*TE*8008738385*TE*9142862043*FX*1234567890~NM1*87*2~N3*PO BOX 277500~N4*STATE*TS*303847000~HL*2*1*22*0~SBR*P*18*701648******CI~NM1*IL*1*FNAME*LNAME****MI*00123456789~N3*2020 CITY~N4*STATE*TG*80001~DMG*D8*19820220*M~NM1*PR*2*PROVIDER XYZ*****PI*87726~\nCLM*TOSRTA-SPL1*471***12:B:1*Y*A*Y*Y*P~REF*D9*H4HZMH0R4P0104~HI*ABK:Z12~NM1*DN*1*DN*SKO****XX*1255589300~LX*1~SV1*HC:73525*471*UN*1***1~DTP*472*RD8*0190701-20190701~REF*6R*2190476543Z1~SE*30*000000001~GE*1*19160001~IEA*1*019160001~"
                )
                response = submit_uhc_claim(client, x12_request_data)
                print("\nTEST API: Claim Submission Response:\n", response)
            except Exception as e:
                print("\nTEST API: Error in Claim Submission Test:\n", e)
    
    except Exception as e:
        print("TEST API: Unexpected Error: {}".format(e))
