#!/usr/bin/env python
"""
Cloud readiness runbook builders.

Separated from cloud_readiness.py so orchestration code stays small while
rendering/decision helpers remain testable and focused.
"""
from __future__ import print_function

import json
import os
import time

CLOUD_DEGRADED_VALIDATION_RUNBOOK = (
    os.path.join('docs', 'runbooks', 'Cloud_Readiness_Cloud_Degraded_Validation.md')
    .replace('\\', '/')
)


def _cloud_degradation_action_lines(reasons):
    """Return manual-check lines for known cloud degradation reasons."""
    reason_actions = {
        'project_id_missing': 'Set GOOGLE_CLOUD_PROJECT/project-id and rerun system health triage.',
        'firestore_unavailable': 'Verify Firestore auth/API access, then confirm queue/state reads manually.',
        'queues_query_failed': 'Validate queue collection permissions and manually inspect unacked backlog.',
        'preprocessor_gate_unavailable': 'Run preprocessor gate checks separately and capture shadow cohort evidence.',
        'ingest_errors_query_failed': 'Review ingest_errors access and manually sample reject/error records.',
    }
    ordered = []
    seen = set()
    for reason in reasons:
        key = str(reason or '').strip()
        if not key or key in seen:
            continue
        seen.add(key)
        ordered.append(key)
    if not ordered:
        ordered = ['unknown']

    lines = []
    for key in ordered:
        action = reason_actions.get(key, 'Validate impacted cloud signals manually and capture evidence.')
        lines.append(' - Check ({0}): {1}'.format(key, action))
    return lines


def _format_ratio(num, den):
    den_i = int(den or 0)
    if den_i <= 0:
        return "0.000"
    try:
        return "{0:.3f}".format(float(num or 0) / float(den_i))
    except Exception:
        return "0.000"


def _ratio_value(num, den):
    den_i = int(den or 0)
    if den_i <= 0:
        return 0.0
    try:
        return float(num or 0) / float(den_i)
    except Exception:
        return 0.0


def _format_simple_count_map(counts, limit=4):
    mapping = counts if isinstance(counts, dict) else {}
    items = []
    for key, value in mapping.items():
        try:
            items.append((str(key), int(value or 0)))
        except Exception:
            continue
    items = sorted(items, key=lambda item: (-item[1], item[0]))
    if limit is not None:
        items = items[:max(0, int(limit or 0))]
    if not items:
        return 'none'
    return ', '.join('{0}:{1}'.format(key, value) for key, value in items)


def _safe_json_dict(path):
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        return {}
    return {}


def _any_key_match(mapping, key_candidates):
    if not isinstance(mapping, dict):
        return False
    wanted = set([str(k or '').strip().upper() for k in key_candidates if str(k or '').strip()])
    if not wanted:
        return False
    for key in mapping.keys():
        if str(key or '').strip().upper() in wanted:
            return True
    return False


def _dat_parser_slice_snapshot(lab_root, repo_root_hint=''):
    """
    Best-effort parser slice snapshot from repo json/config.json and json/crosswalk.json.
    This keeps DOS vs DATE1 visibility explicit in health packs.
    """
    config_path = os.environ.get('MEDICAFE_CONFIG_FILE', '').strip()
    crosswalk_path = os.environ.get('MEDICAFE_CROSSWALK_FILE', '').strip()

    module_repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    candidate_roots = []
    repo_root_hint = str(repo_root_hint or '').strip()
    if repo_root_hint:
        candidate_roots.append(os.path.abspath(repo_root_hint))
    candidate_roots.append(module_repo_root)
    if lab_root:
        candidate_roots.append(os.path.dirname(os.path.abspath(lab_root)))

    if not config_path:
        for root in candidate_roots:
            candidate = os.path.join(root, 'json', 'config.json')
            if os.path.exists(candidate):
                config_path = candidate
                break
        if not config_path and candidate_roots:
            config_path = os.path.join(candidate_roots[0], 'json', 'config.json')
    if not crosswalk_path:
        for root in candidate_roots:
            candidate = os.path.join(root, 'json', 'crosswalk.json')
            if os.path.exists(candidate):
                crosswalk_path = candidate
                break
        if not crosswalk_path:
            crosswalk_path = os.path.join(os.path.dirname(config_path), 'crosswalk.json') if config_path else ''

    config = _safe_json_dict(config_path)
    crosswalk = _safe_json_dict(crosswalk_path)
    medi = config.get('MediLink_Config', config) if isinstance(config, dict) else {}
    fixed = medi.get('fixedWidthSlices', {}) if isinstance(medi.get('fixedWidthSlices', {}), dict) else {}
    service_slices = fixed.get('service_slices', {}) if isinstance(fixed.get('service_slices', {}), dict) else {}
    mains_map = crosswalk.get('mains_mapping', {}) if isinstance(crosswalk.get('mains_mapping', {}), dict) else {}
    mains_slices = mains_map.get('slices', {}) if isinstance(mains_map.get('slices', {}), dict) else {}
    return {
        'config_service_has_dos': _any_key_match(service_slices, ('DOS',)),
        'config_service_has_date1': _any_key_match(service_slices, ('DATE1',)),
        'config_service_has_date': _any_key_match(service_slices, ('DATE',)),
        'crosswalk_mains_has_dos': _any_key_match(mains_slices, ('DOS',)),
        'crosswalk_mains_has_date1': _any_key_match(mains_slices, ('DATE1',)),
        'crosswalk_mains_has_date': _any_key_match(mains_slices, ('DATE',)),
        'config_service_slice_count': len(service_slices.keys()) if isinstance(service_slices, dict) else 0,
        'crosswalk_mains_slice_count': len(mains_slices.keys()) if isinstance(mains_slices, dict) else 0,
    }


def _build_dat_qa_focus_lines(state, lab_root=None, repo_root_hint=''):
    """
    Build proactive DAT QA focus hints from diagnostics_state telemetry.
    These lines are designed to keep the next health pack actionable.
    """
    payload = state if isinstance(state, dict) else {}
    dat_disc = payload.get('last_discovery_dat_telemetry', {})
    if not isinstance(dat_disc, dict):
        dat_disc = {}
    dat_phase_d = payload.get('last_phase_d_dat_telemetry', {})
    if not isinstance(dat_phase_d, dict):
        dat_phase_d = {}

    selected = int(dat_phase_d.get('dat_selected_count', 0) or 0)
    qa_pass = int(dat_phase_d.get('dat_qa_pass_count', 0) or 0)
    qa_reject = int(dat_phase_d.get('dat_qa_reject_count', 0) or 0)
    canonical = int(dat_phase_d.get('dat_canonical_record_count', 0) or 0)
    manifest_rows = int(dat_disc.get('dat_manifest_rows_count', 0) or 0)
    missing_cfg = int(dat_disc.get('dat_configured_root_missing_count', 0) or 0)
    selected_root = str(dat_disc.get('dat_selected_root_source_id', '') or '').strip() or '-'
    effective_root = str(dat_disc.get('dat_effective_root_source_id', '') or '').strip() or '-'
    selection_mode = str(dat_disc.get('dat_selection_mode', '') or '').strip() or '-'

    lines = []
    if selected <= 0:
        return lines

    lines.append(
        ' - dat_focus_snapshot=selected:{0}, qa_pass:{1}, qa_reject:{2}, canonical:{3}, pass_rate:{4}'.format(
            selected, qa_pass, qa_reject, canonical, _format_ratio(qa_pass, selected))
    )
    lines.append(
        ' - dat_discovery_snapshot=manifest_rows:{0}, selected_root:{1}, effective_root:{2}, selection_mode:{3}, missing_configured_roots:{4}'.format(
            manifest_rows, selected_root, effective_root, selection_mode, missing_cfg)
    )
    if missing_cfg > 0 and manifest_rows > 0 and selected > 0 and selected_root != '-':
        lines.append(
            ' - dat_configured_root_missing_interpretation=non_gating_selected_root_yielded'
        )
    slice_snapshot = _dat_parser_slice_snapshot(lab_root, repo_root_hint=repo_root_hint)
    if slice_snapshot:
        lines.append(
            ' - dat_parser_slice_snapshot=config_service(DOS:{0},DATE1:{1},DATE:{2},count:{3}), crosswalk_mains(DOS:{4},DATE1:{5},DATE:{6},count:{7})'.format(
                bool(slice_snapshot.get('config_service_has_dos')),
                bool(slice_snapshot.get('config_service_has_date1')),
                bool(slice_snapshot.get('config_service_has_date')),
                int(slice_snapshot.get('config_service_slice_count', 0) or 0),
                bool(slice_snapshot.get('crosswalk_mains_has_dos')),
                bool(slice_snapshot.get('crosswalk_mains_has_date1')),
                bool(slice_snapshot.get('crosswalk_mains_has_date')),
                int(slice_snapshot.get('crosswalk_mains_slice_count', 0) or 0),
            )
        )
    field_presence = dat_phase_d.get('dat_field_presence_by_alias', {})
    if isinstance(field_presence, dict) and field_presence:
        records_seen = int(field_presence.get('records_seen', 0) or 0)
        if records_seen > 0:
            lines.append(
                ' - dat_alias_presence=records:{0}, PATID:{1}, patient_id:{2}, DOS:{3}, DATE1:{4}, DATE:{5}, date_of_service:{6}, PAYERID:{7}, INSID:{8}, payer_id:{9}'.format(
                    records_seen,
                    int(field_presence.get('PATID', 0) or 0),
                    int(field_presence.get('patient_id', 0) or 0),
                    int(field_presence.get('DOS', 0) or 0),
                    int(field_presence.get('DATE1', 0) or 0),
                    int(field_presence.get('DATE', 0) or 0),
                    int(field_presence.get('date_of_service', 0) or 0),
                    int(field_presence.get('PAYERID', 0) or 0),
                    int(field_presence.get('INSID', 0) or 0),
                    int(field_presence.get('payer_id', 0) or 0),
                )
            )

    parse_diag = dat_phase_d.get('dat_parse_diagnostics', {})
    if isinstance(parse_diag, dict) and parse_diag:
        failure_count = int(parse_diag.get('tuple_parse_failure_count', 0) or 0)
        if failure_count > 0:
            first_detail = str(parse_diag.get('first_failure_detail', '') or '').strip()
            first_class = str(parse_diag.get('first_failure_class', '') or '').strip()
            detail = first_detail or first_class or '-'
            lines.append(' - dat_parse_exceptions=count:{0}, first:{1}'.format(failure_count, detail))
        shape_counts = parse_diag.get('record_shape_counts', {}) if isinstance(parse_diag.get('record_shape_counts', {}), dict) else {}
        if shape_counts:
            lines.append(' - dat_record_shapes={0}'.format(_format_simple_count_map(shape_counts)))
        key_sets = parse_diag.get('raw_key_sets_sample', []) if isinstance(parse_diag.get('raw_key_sets_sample', []), list) else []
        if key_sets:
            sample = '; '.join(str(item) for item in key_sets[:3] if str(item or '').strip())
            if sample:
                lines.append(' - dat_raw_key_sets_sample={0}'.format(sample))

    file_prefix_counts = dat_phase_d.get('dat_file_prefix_counts', {})
    if isinstance(file_prefix_counts, dict) and file_prefix_counts:
        lines.append(' - dat_file_prefix_mix={0}'.format(_format_simple_count_map(file_prefix_counts)))
    reject_prefix_counts = dat_phase_d.get('dat_reject_file_prefix_counts', {})
    if isinstance(reject_prefix_counts, dict) and reject_prefix_counts:
        lines.append(' - dat_reject_file_prefix_mix={0}'.format(_format_simple_count_map(reject_prefix_counts)))

    reject_mix = dat_phase_d.get('dat_qa_reject_counts_by_reason', {})
    if isinstance(reject_mix, dict) and reject_mix:
        ranked = []
        for code, count in reject_mix.items():
            try:
                count_i = int(count or 0)
            except Exception:
                count_i = 0
            ranked.append((count_i, str(code)))
        ranked.sort(reverse=True)
        top = ranked[:3]
        parts = []
        for count_i, code in top:
            parts.append(
                '{0}:{1}({2})'.format(
                    code,
                    count_i,
                    _format_ratio(count_i, qa_reject),
                )
            )
        lines.append(' - dat_reject_mix_top={0}'.format(', '.join(parts)))

    if qa_pass == 0 and qa_reject > 0:
        lines.append(' - next_health_focus=dat_qa_full_block')
        lines.append(
            ' - next_health_target=drive dat_qa_pass_count>0 and dat_canonical_record_count>0 for the next run'
        )
        dos_missing = int((reject_mix or {}).get('QA_DAT_DATE_OF_SERVICE_MISSING', 0) or 0)
        req_missing = int((reject_mix or {}).get('QA_ARTIFACT_CLASS_REQUIRED_FIELDS', 0) or 0)
        parse_empty = int((reject_mix or {}).get('QA_DAT_EMPTY_FILE', 0) or 0)
        parse_none = int((reject_mix or {}).get('QA_DAT_PARSE_NO_RECORDS', 0) or 0)
        unsupported = int((reject_mix or {}).get('QA_DAT_UNSUPPORTED_LAYOUT', 0) or 0)
        patient_missing = int((reject_mix or {}).get('QA_DAT_PATIENT_ANCHOR_MISSING', 0) or 0)
        if dos_missing > 0 and _ratio_value(dos_missing, qa_reject) >= 0.60:
            lines.append(' - dat_failure_mode_hypothesis=date_alias_or_slice_mismatch_high')
        if patient_missing > 0 and _ratio_value(patient_missing, qa_reject) >= 0.20:
            lines.append(' - dat_failure_mode_hypothesis=patient_anchor_alias_mismatch_watch')
        if unsupported > 0 and _ratio_value(unsupported, qa_reject) >= 0.10:
            lines.append(' - dat_failure_mode_hypothesis=unsupported_dat_layout_or_anchor_contract')
        if (parse_empty + parse_none) > 0 and _ratio_value(parse_empty + parse_none, qa_reject) >= 0.10:
            lines.append(' - dat_failure_mode_hypothesis=empty_or_zero_record_dat_parse_contract')
        if req_missing > 0 and _ratio_value(req_missing, qa_reject) >= 0.10:
            lines.append(' - dat_failure_mode_hypothesis=parser_shape_or_record_contract_mismatch_watch')
        lines.append(' - next_health_target=confirm alias presence trends vs reject mix (DOS/DATE1/DATE, PATID/patient_id, PAYERID/INSID)')
    elif qa_pass > 0 and canonical == 0:
        lines.append(' - next_health_focus=dat_to_canonical_transition')
        lines.append(
            ' - next_health_target=verify canonicalization path and replay drain after DAT QA pass begins'
        )
    return lines


def collect_failed_or_warned_signals(audit_payload):
    """Return ordered list of fail/warn findings/metrics for top-blocker selection."""
    items = []
    if not isinstance(audit_payload, dict):
        return items
    surfaces = audit_payload.get('surfaces', {}) if isinstance(audit_payload.get('surfaces', {}), dict) else {}
    for surface_name in ('xp_local', 'cloud'):
        surface = surfaces.get(surface_name, {}) if isinstance(surfaces.get(surface_name, {}), dict) else {}
        for finding in surface.get('findings', []) if isinstance(surface.get('findings', []), list) else []:
            if not isinstance(finding, dict):
                continue
            sev = str(finding.get('severity', '') or '').lower()
            if sev not in ('fail', 'warn'):
                continue
            code = str(finding.get('code', '') or '').strip()
            msg = str(finding.get('message', '') or '').strip()
            label = '{0}:{1}'.format(surface_name, code or 'finding')
            items.append({'severity': sev, 'label': label, 'message': msg})
        for metric in surface.get('metrics', []) if isinstance(surface.get('metrics', []), list) else []:
            if not isinstance(metric, dict):
                continue
            st = str(metric.get('status', '') or '').lower()
            if st not in ('fail', 'warn'):
                continue
            key = str(metric.get('key', '') or '').strip()
            val = metric.get('value')
            msg = 'metric={0}, value={1}'.format(key or 'unknown', val)
            label = '{0}:{1}'.format(surface_name, key or 'metric')
            items.append({'severity': st, 'label': label, 'message': msg})
    return items


def build_system_health_triage_runbook(
        audit_ok,
        audit_data,
        pack_ok,
        pack_path,
        report_path,
        collect_failed_or_warned_signals_fn=None):
    """Build GO/NO-GO runbook payload for triage option."""
    if collect_failed_or_warned_signals_fn is None:
        collect_failed_or_warned_signals_fn = collect_failed_or_warned_signals

    payload = {}
    if isinstance(audit_data, dict):
        payload = audit_data.get('payload', {}) if isinstance(audit_data.get('payload', {}), dict) else {}
    overall = payload.get('overall', {}) if isinstance(payload.get('overall', {}), dict) else {}
    status = str(overall.get('status', '') or '').lower()

    decision = 'GO' if audit_ok and pack_ok and status == 'pass' else 'NO_GO'
    blocker = 'none'
    if not audit_ok:
        blocker = 'audit_execution_failed'
    elif not pack_ok:
        blocker = 'system_health_pack_unavailable'
    else:
        signals = collect_failed_or_warned_signals_fn(payload)
        for sev in ('fail', 'warn'):
            hit = next((s for s in signals if s.get('severity') == sev), None)
            if hit:
                blocker = '{0} ({1})'.format(hit.get('label', 'signal'), hit.get('message', ''))
                break

    next_action = 'Open latest System Health Pack and verify all surfaces are pass.'
    if decision != 'GO':
        if not audit_ok:
            next_action = 'Re-run System Health Triage and inspect audit stderr/output.'
        elif status == 'fail':
            next_action = 'Treat as NO-GO. Resolve failing metrics before cutover decisions.'
        elif status == 'warn':
            next_action = 'Review warn metrics and decide whether risk is acceptable for current milestone.'
        elif not pack_ok:
            next_action = 'Open latest migration audit summary and regenerate System Health Pack.'

    verify_artifact = pack_path or report_path or '(not generated)'
    lines = [
        'Release decision: {0}'.format(decision),
        'Top blocker: {0}'.format(blocker),
        'Next action: {0}'.format(next_action),
        'Verification artifact: {0}'.format(verify_artifact),
    ]
    return {
        'decision': decision,
        'top_blocker': blocker,
        'next_action': next_action,
        'verification_artifact': verify_artifact,
        'lines': lines,
    }


def _is_pipeline_running_live(lab_root):
    """Best-effort live pipeline activity check for runbook coherence."""
    if not lab_root:
        return False
    try:
        from MediCafe.cloud_readiness_health import is_pipeline_running as _health_is_pipeline_running
    except Exception:
        try:
            from cloud_readiness_health import is_pipeline_running as _health_is_pipeline_running
        except Exception:
            _health_is_pipeline_running = None
    if _health_is_pipeline_running is not None:
        try:
            return bool(_health_is_pipeline_running(lab_root))
        except Exception:
            return False
    return os.path.exists(os.path.join(lab_root, 'shadow_pipeline.lock'))


def _derive_system_health_pack_pipeline_state(lab_root, state):
    """Return effective pipeline_state/alignment using live lock activity when present."""
    payload = state if isinstance(state, dict) else {}
    active_run_id = str(payload.get('active_run_id', '') or '').strip()
    last_run_id = str(payload.get('last_shadow_pipeline_run_id', '') or '').strip()
    pipeline_state = str(payload.get('pipeline_state', '') or '').strip().lower()
    effective_pipeline_state = pipeline_state or 'unknown'
    if effective_pipeline_state in ('bootstrapping', 'running'):
        effective_pipeline_state = 'running'
    live_running = _is_pipeline_running_live(lab_root)
    if live_running or active_run_id:
        effective_pipeline_state = 'running'

    alignment = 'none'
    if active_run_id and last_run_id and active_run_id != last_run_id:
        alignment = 'active_differs_from_last'
    elif active_run_id and last_run_id and active_run_id == last_run_id:
        alignment = 'active_matches_last'
    elif active_run_id and not last_run_id:
        alignment = 'active_only'
    elif effective_pipeline_state == 'running':
        alignment = 'transition_in_progress'
    elif last_run_id:
        alignment = 'last_only'

    return {
        'active_run_id': active_run_id,
        'last_run_id': last_run_id,
        'pipeline_state': effective_pipeline_state,
        'alignment': alignment,
        'live_running': live_running,
    }


def build_system_health_pack_runbook(
        lab_root,
        audit_payload,
        artifacts,
        parse_iso_utc_epoch_fn,
        load_json_dict_fn,
        state_override=None,
        pack_scope='',
        anchor_run_id=''):
    """Build freshness/alignment/degraded-mode runbook lines for system health pack."""
    payload = audit_payload if isinstance(audit_payload, dict) else {}
    migration_stage = str(payload.get('migration_stage', '') or '').strip().lower() or 'xp_validation'
    overall = payload.get('overall', {}) if isinstance(payload.get('overall', {}), dict) else {}
    status = str(overall.get('status', '') or '').lower()
    generated_at = payload.get('generated_at_utc')
    generated_epoch = parse_iso_utc_epoch_fn(generated_at)
    age_hours = None
    if generated_epoch is not None:
        try:
            age_hours = round(max(0.0, (time.time() - float(generated_epoch)) / 3600.0), 2)
        except Exception:
            age_hours = None
    audit_freshness = 'unknown'
    if age_hours is not None:
        audit_freshness = 'stale' if age_hours > 6 else 'current'

    state = load_json_dict_fn(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    dat_state = state_override if isinstance(state_override, dict) else state
    pipeline_snapshot = _derive_system_health_pack_pipeline_state(lab_root, state)
    pipeline_state = pipeline_snapshot.get('pipeline_state', 'unknown')
    alignment = pipeline_snapshot.get('alignment', 'none')

    degraded = payload.get('degradations', []) if isinstance(payload.get('degradations', []), list) else []
    cloud_degraded = [d for d in degraded if isinstance(d, dict) and d.get('surface') == 'cloud']
    cloud_reasons = []
    for item in cloud_degraded:
        reason = str(item.get('reason', '') or '').strip()
        if reason:
            cloud_reasons.append(reason)

    repo_root_hint = ''
    if isinstance(artifacts, dict):
        repo_root_hint = str(artifacts.get('repo_root', '') or '').strip()

    lines = []
    lines.append('System Health Runbook:')
    lines.append(' - audit_status={0}'.format(status or 'unknown'))
    lines.append(' - audit_freshness={0}'.format(audit_freshness))
    lines.append(' - migration_stage={0}'.format(migration_stage))
    lines.append(' - audit_age_hours={0}'.format(age_hours if age_hours is not None else 'unknown'))
    lines.append(' - pipeline_state={0}'.format(pipeline_state or 'unknown'))
    lines.append(' - run_alignment={0}'.format(alignment))
    lines.append(' - pack_scope={0}'.format(str(pack_scope or 'unknown')))
    if anchor_run_id:
        lines.append(' - anchor_run_id={0}'.format(anchor_run_id))
    lines.append(' - cloud_degraded_mode={0}'.format(bool(cloud_degraded)))
    dat_focus_lines = _build_dat_qa_focus_lines(dat_state, lab_root=lab_root, repo_root_hint=repo_root_hint)
    for dat_line in dat_focus_lines:
        lines.append(dat_line)
    lines.append('Actions:')
    if age_hours is None or age_hours > 6:
        lines.append(' - Re-run System Health Triage to refresh stale audit signals.')
    if pipeline_state == 'running':
        if alignment == 'active_differs_from_last':
            lines.append(' - Active run differs from last completed run; wait for completion then refresh pack.')
        else:
            lines.append(' - Shadow pipeline activity is still in progress; wait for completion then refresh pack.')
    if str(pack_scope or '').strip() == 'mixed_scope':
        lines.append(' - Live current state differs from the anchored completed run; use anchored run sections for run-scoped evidence.')
    if cloud_degraded:
        if cloud_reasons:
            lines.append(' - cloud_degradation_reasons={0}'.format(','.join(cloud_reasons)))
        else:
            lines.append(' - cloud_degradation_reasons=unknown')
        lines.append(' - Open cloud degraded validation runbook: {0}'.format(CLOUD_DEGRADED_VALIDATION_RUNBOOK))
        if migration_stage == 'xp_validation':
            lines.append(' - Cloud collection is degraded but non-gating in xp_validation; complete manual checks before dual-run/cutover.')
        else:
            lines.append(' - Cloud collection is degraded; complete manual checks before GO decisions.')
        for line in _cloud_degradation_action_lines(cloud_reasons):
            lines.append(line)
    if status in ('fail', 'warn') and audit_freshness == 'current':
        lines.append(' - Review audit summary and failing/warn metrics before operational cutover.')
    elif status in ('fail', 'warn') and audit_freshness == 'stale':
        lines.append(' - audit_status_interpretation=stale_historical_signal; rerun audit before treating fail/warn metrics as current.')
    if dat_focus_lines:
        lines.append(' - Track dat_focus_snapshot and dat_reject_mix_top deltas across consecutive health packs.')
    if not any([age_hours is None or age_hours > 6, pipeline_state == 'running', cloud_degraded, status in ('fail', 'warn')]):
        lines.append(' - Pack is fresh and aligned; proceed with routine verification and evidence send if needed.')
    return lines


def build_delivery_runbook_lines(delivery_diag, orchestrator_error_code=None):
    """Create remediation runbook lines from sender diagnostics."""
    diag = delivery_diag if isinstance(delivery_diag, dict) else {}
    token_available = diag.get('token_available')
    recipient_count = diag.get('recipient_count')
    queued_count = diag.get('queued_bundle_count')
    lines = []
    lines.append('Delivery runbook:')
    lines.append(' - token_available={0}'.format(token_available))
    lines.append(' - recipient_count={0}'.format(recipient_count))
    lines.append(' - queued_bundle_count={0}'.format(queued_count))
    last_hist = diag.get('historical_last_support_email_delivery')
    if not isinstance(last_hist, dict):
        last_hist = diag.get('last_support_email_delivery')
    if isinstance(last_hist, dict):
        lines.append(
            ' - last_support_email_delivery=historical_prior_send_state (not current bundle telemetry)'
        )
    lines.append('Actions:')
    any_issue = False
    oec = str(orchestrator_error_code or '').strip()
    if oec == 'PIPELINE_SCRIPT_MISSING':
        lines.append(
            ' - Orchestrator cannot find shadow pipeline scripts: verify MediCafe repo install, PYTHONPATH, '
            'and that scripts/unified_model/run_shadow_pipeline.py exists next to the configured repo root.'
        )
        any_issue = True
    if token_available is False:
        lines.append(' - Gmail token unavailable: re-authenticate sender account before retry.')
        any_issue = True
    if isinstance(recipient_count, int) and recipient_count <= 0:
        lines.append(' - No recipients configured: add support recipients and retry send.')
        any_issue = True
    if isinstance(queued_count, int) and queued_count > 0:
        if oec == 'PIPELINE_SCRIPT_MISSING':
            lines.append(
                ' - Queued bundles may be unrelated to script resolution; drain queue after fixing install paths.'
            )
            any_issue = True
        elif token_available is False:
            lines.append(' - paused waiting for operator reauth.')
            any_issue = True
        elif token_available is True:
            lines.append(' - token restored; queued drain pending or failed.')
            any_issue = True
        else:
            lines.append(' - Pending queued bundles exist: monitor queue drain and retry after token/recipient fixes.')
            any_issue = True
    if diag.get('config_probe_error'):
        lines.append(' - Config probe failed: validate error-reporting config file readability and values.')
        any_issue = True
    if diag.get('token_probe_error'):
        lines.append(' - Token probe failed: inspect token store path/permissions and re-auth state.')
        any_issue = True
    if diag.get('queue_probe_error'):
        lines.append(' - Queue probe failed: check reports queue directory access and lock/permission issues.')
        any_issue = True
    if not any_issue:
        lines.append(' - No blocking sender issues detected; retry send if needed.')
    return lines
