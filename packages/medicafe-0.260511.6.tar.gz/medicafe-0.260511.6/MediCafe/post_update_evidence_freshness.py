# -*- coding: utf-8 -*-
"""
Post-update evidence freshness assessment.

XP-compatible: Python 3.4 syntax, stdlib only.
"""
from __future__ import print_function

import json
import os

from MediCafe.evidence_mode import MODE_RUN_EVIDENCE, resolve_evidence_mode


STATUS_FRESH = "fresh"
STATUS_STALE = "stale"
STATUS_LIVE_STATUS = "live_status"
STATUS_UNAVAILABLE = "unavailable"

_PHASES = ("B", "C", "D", "E")
_PHASE_ORDER = {"B": 1, "C": 2, "D": 3, "E": 4}
_PHASE_PATTERNS = {
    "B": ("artifact_discovery_summary_", ".json"),
    "C": ("ingest_write_summary_", ".json"),
    "D": ("qa_canonical_summary_", ".json"),
    "E": ("projection_parity_summary_", ".json"),
}


def _safe_str(value):
    if value is None:
        return ""
    try:
        return str(value).strip()
    except Exception:
        return ""


def _read_json_dict(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            return payload
    except Exception:
        pass
    return {}


def _phase_run_id_from_path(path, phase):
    text = _safe_str(path)
    if not text or text == "__MISSING__":
        return ""
    base = os.path.basename(text)
    pattern = _PHASE_PATTERNS.get(phase)
    if not pattern:
        return ""
    prefix, suffix = pattern
    if base.startswith(prefix) and base.endswith(suffix):
        return base[len(prefix):-len(suffix)]
    return ""


def _source_path_by_phase(source_paths):
    out = {}
    if not isinstance(source_paths, list):
        return out
    for index, phase in enumerate(_PHASES):
        if index < len(source_paths):
            out[phase] = _safe_str(source_paths[index])
    return out


def _report_phase_run_ids(report):
    out = {}
    raw = report.get("phase_run_ids") if isinstance(report, dict) else {}
    if isinstance(raw, dict):
        for phase in _PHASES:
            rid = _safe_str(raw.get(phase))
            if rid:
                out[phase] = rid
    paths = _source_path_by_phase(report.get("source_summary_paths", []))
    for phase in _PHASES:
        rid = _phase_run_id_from_path(paths.get(phase), phase)
        if rid and not out.get(phase):
            out[phase] = rid
    return out


def _first_missing_phase_reason(report):
    failed_phase = _safe_str(report.get("failed_phase")).upper()
    failed_order = _PHASE_ORDER.get(failed_phase, 0)
    pipeline_ok = bool(report.get("pipeline_ok"))
    paths = _source_path_by_phase(report.get("source_summary_paths", []))
    for phase in _PHASES:
        path = _safe_str(paths.get(phase))
        missing = (not path) or path == "__MISSING__"
        if not missing and not os.path.isfile(path):
            missing = True
        if not missing:
            continue
        phase_order = _PHASE_ORDER.get(phase, 0)
        if pipeline_ok:
            return "phase_{0}_summary_missing".format(phase.lower())
        if not failed_order or phase_order <= failed_order:
            return "phase_{0}_summary_missing_before_or_at_failed_phase".format(phase.lower())
    return ""


def _lineage_conflict_reason(report):
    paths = _source_path_by_phase(report.get("source_summary_paths", []))
    phase_ids = report.get("phase_run_ids") if isinstance(report.get("phase_run_ids"), dict) else {}
    for phase in _PHASES:
        from_path = _phase_run_id_from_path(paths.get(phase), phase)
        from_map = _safe_str(phase_ids.get(phase))
        if from_path and from_map and from_path != from_map:
            return "phase_{0}_source_path_phase_run_id_conflict".format(phase.lower())
    return ""


def _latest_shadow_report_path(reports_dir):
    best_path = ""
    best_mtime = -1.0
    try:
        names = os.listdir(reports_dir)
    except Exception:
        return ""
    for name in names:
        if not name.startswith("shadow_run_report_") or not name.endswith(".json"):
            continue
        path = os.path.join(reports_dir, name)
        try:
            mtime = os.path.getmtime(path)
        except Exception:
            mtime = 0.0
        if mtime >= best_mtime:
            best_mtime = mtime
            best_path = path
    return best_path


def _active_pipeline(state, cursor):
    active = _safe_str((state or {}).get("active_run_id")) or _safe_str((cursor or {}).get("active_run_id"))
    completed = _safe_str((state or {}).get("last_shadow_pipeline_run_id")) or _safe_str(
        (cursor or {}).get("last_shadow_pipeline_run_id"))
    pipeline_state = (
        _safe_str((state or {}).get("pipeline_state")) or _safe_str((cursor or {}).get("pipeline_state"))
    ).lower()
    if pipeline_state in ("running", "bootstrapping"):
        return True
    if active and completed and active != completed:
        return True
    return False


def assess_post_update_evidence_freshness(lab_root, installed_version,
                                           diagnostics_state=None, run_cursor=None):
    """
    Return a small policy dict for post-update auto-follow evidence freshness.
    """
    root = _safe_str(lab_root)
    version = _safe_str(installed_version)
    reports_dir = os.path.join(root, "reports")
    state = diagnostics_state if isinstance(diagnostics_state, dict) else _read_json_dict(
        os.path.join(root, "diagnostics_state.json"))
    cursor = run_cursor if isinstance(run_cursor, dict) else _read_json_dict(
        os.path.join(root, "run_cursor.json"))
    completed = _safe_str(state.get("last_shadow_pipeline_run_id")) or _safe_str(
        cursor.get("last_shadow_pipeline_run_id"))
    active = _safe_str(state.get("active_run_id")) or _safe_str(cursor.get("active_run_id"))

    out = {
        "schema_version": 1,
        "post_update_evidence_freshness_status": STATUS_STALE,
        "post_update_fresh_shadow_run_id": completed,
        "post_update_fresh_machine_app_version": "",
        "post_update_freshness_blocking_reason": "",
        "post_update_fresh_pipeline_status": "idle",
        "installed_version": version,
        "last_completed_run_id": completed,
        "active_run_id": active,
        "shadow_report_path": "",
    }

    if _active_pipeline(state, cursor):
        out["post_update_evidence_freshness_status"] = STATUS_LIVE_STATUS
        out["post_update_fresh_pipeline_status"] = "running"
        out["post_update_freshness_blocking_reason"] = "fresh_pipeline_running"
        return out

    if not completed:
        out["post_update_evidence_freshness_status"] = STATUS_UNAVAILABLE
        out["post_update_freshness_blocking_reason"] = "completed_run_id_missing"
        return out

    report_path = os.path.join(reports_dir, "shadow_run_report_{0}.json".format(completed))
    if not os.path.isfile(report_path):
        report_path = _latest_shadow_report_path(reports_dir)
        if report_path:
            out["shadow_report_path"] = report_path
            latest = _read_json_dict(report_path)
            latest_run = _safe_str(latest.get("run_id"))
            if latest_run and latest_run != completed:
                out["post_update_freshness_blocking_reason"] = "latest_shadow_report_not_completed_run"
                out["post_update_fresh_shadow_run_id"] = latest_run
                out["post_update_fresh_machine_app_version"] = _safe_str(latest.get("machine_app_version"))
                return out
        out["post_update_freshness_blocking_reason"] = "shadow_report_missing_for_completed_run"
        return out

    out["shadow_report_path"] = report_path
    report = _read_json_dict(report_path)
    if not report:
        out["post_update_freshness_blocking_reason"] = "shadow_report_unreadable"
        return out

    report_run_id = _safe_str(report.get("run_id"))
    if report_run_id and report_run_id != completed:
        out["post_update_freshness_blocking_reason"] = "shadow_report_run_id_mismatch"
        out["post_update_fresh_shadow_run_id"] = report_run_id
        return out

    app_version = _safe_str(report.get("machine_app_version"))
    out["post_update_fresh_machine_app_version"] = app_version
    if version and app_version != version:
        out["post_update_freshness_blocking_reason"] = "machine_app_version_mismatch"
        return out

    mode = resolve_evidence_mode(
        root,
        bundle_kind="system_health_pack",
        requested_run_id=completed,
        send_source="post_update_cloud_autofollow",
        diagnostics_state=state,
        run_cursor=cursor,
    )
    out["evidence_mode"] = mode.get("mode")
    out["evidence_mode_blocking_reason"] = mode.get("blocking_reason", "")
    if mode.get("mode") != MODE_RUN_EVIDENCE:
        out["post_update_evidence_freshness_status"] = (
            STATUS_LIVE_STATUS if mode.get("mode") == STATUS_LIVE_STATUS else STATUS_STALE
        )
        out["post_update_freshness_blocking_reason"] = (
            mode.get("blocking_reason") or "evidence_mode_not_run_evidence"
        )
        return out

    conflict = _lineage_conflict_reason(report)
    if conflict:
        out["post_update_freshness_blocking_reason"] = conflict
        return out

    missing = _first_missing_phase_reason(report)
    if missing:
        out["post_update_freshness_blocking_reason"] = missing
        return out

    out["post_update_evidence_freshness_status"] = STATUS_FRESH
    out["post_update_fresh_pipeline_status"] = "completed"
    out["post_update_freshness_blocking_reason"] = ""
    out["phase_run_ids"] = _report_phase_run_ids(report)
    return out
