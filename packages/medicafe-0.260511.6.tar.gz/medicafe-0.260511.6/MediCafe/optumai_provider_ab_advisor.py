#!/usr/bin/env python
"""
OPTUMAI provider-sequence A/B advisor.

This module is intentionally small and side-effect light. It chooses at most
one new OPTUMAI claim for an operator-approved provider-loop trial, annotates
the patient row, and builds a per-patient config overlay for 837 generation.

Compatible with Python 3.4 / Windows XP runtime paths.
"""

from __future__ import print_function

import copy
import json
import os
import time


VARIANT_BILLING_GROUP_RENDERING_INDIVIDUAL = 'billing_group_rendering_individual'
ADVISOR_FLAG = 'provider_sequence_ab_advisor_enabled'
GROUP_NAME_KEY = 'provider_sequence_ab_billing_group_name'
GROUP_NPI_KEY = 'provider_sequence_ab_billing_group_npi'
GROUP_TAXONOMY_KEY = 'provider_sequence_ab_billing_taxonomy'
GROUP_EMIT_TAXONOMY_KEY = 'provider_sequence_ab_emit_billing_taxonomy'


def _safe_text(value):
    if value is None:
        return ''
    try:
        return str(value).strip()
    except Exception:
        return ''


def _as_bool(value, default=False):
    if value is None:
        return bool(default)
    if isinstance(value, bool):
        return value
    text = _safe_text(value).lower()
    if not text:
        return bool(default)
    return text in ('1', 'true', 't', 'yes', 'y', 'on')


def _medi_config(config):
    if not isinstance(config, dict):
        return {}
    child = config.get('MediLink_Config')
    if isinstance(child, dict):
        return child
    return config


def _endpoint_config(config, endpoint):
    medi = _medi_config(config)
    endpoints = medi.get('endpoints', {}) if isinstance(medi, dict) else {}
    endpoint_cfg = endpoints.get(str(endpoint or '').upper(), {})
    if isinstance(endpoint_cfg, dict):
        return endpoint_cfg
    return {}


def _effective_endpoint(row):
    return _safe_text(
        row.get('confirmed_endpoint') or
        row.get('user_preferred_endpoint') or
        row.get('suggested_endpoint') or
        row.get('endpoint')
    ).upper()


def _row_payer_id(row):
    return _safe_text(
        row.get('payer_id') or
        row.get('PAYERID') or
        row.get('payerId') or
        row.get('insurance_id')
    )


def _row_amount(row):
    raw = _safe_text(row.get('amount') or row.get('AMOUNT') or row.get('amount_billed'))
    if not raw:
        return 999999999.0
    cleaned = raw.replace('$', '').replace(',', '')
    try:
        return float(cleaned)
    except Exception:
        return 999999999.0


def _endpoint_submission_method(config, endpoint):
    endpoint_cfg = _endpoint_config(config, endpoint)
    return _safe_text(endpoint_cfg.get('submission_method') or 'winscp').lower()


def _advisor_enabled(config):
    endpoint_cfg = _endpoint_config(config, 'OPTUMAI')
    if ADVISOR_FLAG in endpoint_cfg:
        return _as_bool(endpoint_cfg.get(ADVISOR_FLAG), True)
    medi = _medi_config(config)
    if isinstance(medi, dict) and ADVISOR_FLAG in medi:
        return _as_bool(medi.get(ADVISOR_FLAG), True)
    return True


def _group_config_available(config):
    endpoint_cfg = _endpoint_config(config, 'OPTUMAI')
    return bool(_safe_text(endpoint_cfg.get(GROUP_NAME_KEY)) and _safe_text(endpoint_cfg.get(GROUP_NPI_KEY)))


def _receipts_root(config):
    medi = _medi_config(config)
    return _safe_text(medi.get('local_claims_path')) if isinstance(medi, dict) else ''


def _tracking_available(row, config):
    if not _receipts_root(config):
        return False
    if _safe_text(row.get('claim_key')):
        return True
    patient_id = _safe_text(row.get('patient_id') or row.get('CHART') or row.get('PATID'))
    dos = _safe_text(row.get('surgery_date_iso') or row.get('surgery_date') or row.get('DOS') or row.get('DATE'))
    proc = _safe_text(row.get('primary_procedure_code') or row.get('CODEA'))
    payer = _row_payer_id(row) or _safe_text(row.get('primary_insurance') or row.get('INAME'))
    return bool(patient_id and dos and proc and payer)


def _prior_provider_sequence_payers(config):
    root = _receipts_root(config)
    if not root:
        return set()
    path = os.path.join(root, 'submission_index.jsonl')
    payers = set()
    try:
        if not os.path.exists(path):
            return payers
        with open(path, 'r') as fh:
            for line in fh:
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                if not isinstance(row, dict):
                    continue
                text = json.dumps(row).lower()
                if 'provider_sequence_missing' in text or 'provider with sequence no. 01 not found' in text:
                    payer = _safe_text(row.get('payer_id') or row.get('payerId'))
                    if payer:
                        payers.add(payer)
    except Exception:
        return payers
    return payers


def _is_candidate(row, config):
    if not isinstance(row, dict):
        return False
    if row.get('exclude_from_submission') or row.get('duplicate_candidate'):
        return False
    if _effective_endpoint(row) != 'OPTUMAI':
        return False
    if _endpoint_submission_method(config, 'OPTUMAI') != 'api':
        return False
    if not _tracking_available(row, config):
        return False
    return True


def build_provider_ab_advice(patient_rows, config, crosswalk=None, now_func=None):
    """
    Return advice dict for one candidate, or {'offered': False, ...}.
    """
    if not _advisor_enabled(config):
        return {'offered': False, 'reason': 'advisor_disabled'}
    if not _group_config_available(config):
        return {'offered': False, 'reason': 'missing_group_billing_config'}

    prior_payers = _prior_provider_sequence_payers(config)
    candidates = []
    for idx, row in enumerate(patient_rows or []):
        if not _is_candidate(row, config):
            continue
        payer = _row_payer_id(row)
        same_payer_history = bool(payer and payer in prior_payers)
        score = 100 if same_payer_history else 0
        candidates.append((0 - score, _row_amount(row), idx, row, same_payer_history))

    if not candidates:
        return {'offered': False, 'reason': 'no_eligible_claim'}

    candidates.sort()
    _neg_score, _amount, idx, row, same_payer_history = candidates[0]
    now = now_func() if now_func else time.time()
    try:
        advice_id = 'optumai-provider-ab-{0}'.format(int(now))
    except Exception:
        advice_id = 'optumai-provider-ab'
    reason = 'same_payer_prior_provider_sequence_warning' if same_payer_history else 'eligible_optumai_claim_with_custody_tracking'

    return {
        'offered': True,
        'patient_index': idx,
        'variant': VARIANT_BILLING_GROUP_RENDERING_INDIVIDUAL,
        'advice_id': advice_id,
        'reason': reason,
        'same_payer_prior_provider_sequence_warning': same_payer_history,
    }


def prompt_provider_ab_advice(advice, input_fn=None, print_fn=None):
    """
    Return True only when the operator explicitly chooses option 2.
    """
    if not advice or not advice.get('offered'):
        return False
    if input_fn is None:
        try:
            input_fn = raw_input
        except NameError:
            input_fn = input
    if print_fn is None:
        print_fn = print

    print_fn("")
    print_fn("OPTUMAI provider-warning reduction trial")
    print_fn("")
    print_fn("This new claim appears eligible for a one-time provider-format trial.")
    print_fn("MediCafe will still submit it through OPTUMAI, but will use the enrolled billing")
    print_fn("group format to see if OPTUMAI stops showing the provider sequence warning.")
    print_fn("")
    print_fn("This is not for resubmitting an already-submitted claim.")
    print_fn("")
    print_fn("Why this claim:")
    print_fn("- New, not previously submitted by MediCafe")
    print_fn("- OPTUMAI route already selected")
    if advice.get('same_payer_prior_provider_sequence_warning'):
        print_fn("- Similar prior OPTUMAI claims showed provider-sequence warning")
    else:
        print_fn("- OPTUMAI provider-warning telemetry can be tracked after submission")
    print_fn("- Custody tracking is available after submission")
    print_fn("")
    print_fn("1) Submit normally")
    print_fn("2) Submit with provider-format trial")
    try:
        choice = input_fn("Choice [1]: ")
    except Exception:
        choice = ''
    return _safe_text(choice) == '2'


def annotate_provider_ab_choice(patient_rows, advice, accepted):
    if not advice or not advice.get('offered'):
        return patient_rows
    try:
        idx = int(advice.get('patient_index'))
        row = patient_rows[idx]
    except Exception:
        return patient_rows
    if not isinstance(row, dict):
        return patient_rows
    row['optumai_provider_ab_offered'] = True
    row['optumai_provider_ab_operator_choice'] = 'accepted' if accepted else 'declined'
    row['optumai_provider_ab_variant'] = advice.get('variant') or VARIANT_BILLING_GROUP_RENDERING_INDIVIDUAL
    row['optumai_provider_ab_advice_id'] = advice.get('advice_id') or ''
    row['optumai_provider_ab_reason'] = advice.get('reason') or ''
    return patient_rows


def is_provider_ab_patient(patient_data):
    if not isinstance(patient_data, dict):
        return False
    return (
        _safe_text(patient_data.get('optumai_provider_ab_operator_choice')) == 'accepted' and
        _safe_text(patient_data.get('optumai_provider_ab_variant')) == VARIANT_BILLING_GROUP_RENDERING_INDIVIDUAL
    )


def config_for_provider_ab_patient(config, patient_data):
    """
    Return a copied config with OPTUMAI group-billing provider override.
    """
    if not is_provider_ab_patient(patient_data):
        return config
    out = copy.deepcopy(config)
    medi = _medi_config(out)
    if not isinstance(medi, dict):
        return out
    endpoints = medi.get('endpoints')
    if not isinstance(endpoints, dict):
        endpoints = {}
        medi['endpoints'] = endpoints
    optum = endpoints.get('OPTUMAI')
    if not isinstance(optum, dict):
        optum = {}
        endpoints['OPTUMAI'] = optum

    source = _endpoint_config(config, 'OPTUMAI')
    group_name = _safe_text(source.get(GROUP_NAME_KEY))
    group_npi = _safe_text(source.get(GROUP_NPI_KEY))
    taxonomy = _safe_text(source.get(GROUP_TAXONOMY_KEY) or source.get('billing_provider_taxonomy'))

    if group_name:
        optum['billing_provider_lastname'] = group_name
    optum['billing_provider_firstname'] = ''
    if group_npi:
        optum['billing_provider_npi'] = group_npi
    optum['billing_provider_entity_type_qualifier'] = '2'
    if taxonomy:
        optum['billing_provider_taxonomy'] = taxonomy
    if taxonomy and _as_bool(source.get(GROUP_EMIT_TAXONOMY_KEY), True):
        optum['emit_billing_provider_taxonomy'] = True
    return out


def provider_ab_display_label(patient_data):
    if is_provider_ab_patient(patient_data):
        return 'OPTUMAI billing group format'
    return ''


def classify_provider_ab_outcome(message, status=True):
    text = _safe_text(message).lower()
    if not status:
        return 'failed_or_no_custody'
    if 'provider_sequence_missing' in text or 'provider with sequence no. 01 not found' in text:
        if 'submitted to optumai' in text or 'status=000' in text or 'transactionid=present' in text or 'x12ack=present' in text:
            return 'accepted_with_provider_warning'
        return 'failed_or_no_custody'
    if 'submitted to optumai' in text or 'status=000' in text or 'transactionid=present' in text or 'x12ack=present' in text:
        return 'accepted_no_provider_warning'
    return 'unknown'


def telemetry_fields_for_patient(patient_data, message='', status=True):
    if not isinstance(patient_data, dict) or not patient_data.get('optumai_provider_ab_offered'):
        return {}
    out = {
        'optumai_provider_ab_variant': _safe_text(patient_data.get('optumai_provider_ab_variant')),
        'optumai_provider_ab_operator_choice': _safe_text(patient_data.get('optumai_provider_ab_operator_choice')),
        'optumai_provider_ab_advice_id': _safe_text(patient_data.get('optumai_provider_ab_advice_id')),
        'optumai_provider_ab_reason': _safe_text(patient_data.get('optumai_provider_ab_reason')),
    }
    if is_provider_ab_patient(patient_data):
        out['optumai_provider_ab_outcome'] = classify_provider_ab_outcome(message, status=status)
    return out


def _normalized_path_key(path):
    text = _safe_text(path)
    if not text:
        return ''
    try:
        return os.path.normcase(os.path.abspath(os.path.normpath(text)))
    except Exception:
        try:
            return os.path.normcase(os.path.normpath(text))
        except Exception:
            return text


def _patients_for_submission_file(patient_file_map, file_path):
    if not isinstance(patient_file_map, dict):
        return []
    keys = [
        file_path,
        _normalized_path_key(file_path),
        os.path.basename(_safe_text(file_path)),
    ]
    for key in keys:
        try:
            patients = patient_file_map.get(key)
        except Exception:
            patients = None
        if patients:
            return list(patients)
    target = _normalized_path_key(file_path)
    for key, patients in patient_file_map.items():
        try:
            if _normalized_path_key(key) == target:
                return list(patients or [])
        except Exception:
            continue
    return []


def _transaction_id_present(endpoint_results, file_path):
    if not isinstance(endpoint_results, dict):
        return False
    tx_map = endpoint_results.get('_transaction_ids')
    if not isinstance(tx_map, dict):
        return False
    for key in (file_path, os.path.basename(_safe_text(file_path)), _normalized_path_key(file_path)):
        try:
            if tx_map.get(key):
                return True
        except Exception:
            continue
    target = _normalized_path_key(file_path)
    for key, value in tx_map.items():
        try:
            if value and _normalized_path_key(key) == target:
                return True
        except Exception:
            continue
    return False


def build_submission_bundle_summary(submission_results, patient_file_map, now_func=None):
    """
    Build a non-PHI claim-submission bundle summary for provider A/B trials.

    This deliberately avoids patient names, member IDs, NPIs, tax IDs, claim
    payloads, and raw gateway messages. The goal is just to tell dev whether
    the one operator-approved trial reached custody and whether the provider
    sequence warning still appeared.
    """
    trials = []
    if not isinstance(submission_results, dict):
        return {}
    for endpoint, files in submission_results.items():
        if not isinstance(files, dict):
            continue
        endpoint_text = _safe_text(endpoint).upper()
        for file_path, result in files.items():
            if _safe_text(file_path).startswith('_'):
                continue
            try:
                status, message = result
            except Exception:
                status = False
                message = ''
            patients = _patients_for_submission_file(patient_file_map, file_path)
            for patient in patients:
                if not is_provider_ab_patient(patient):
                    continue
                outcome = classify_provider_ab_outcome(message, status=status)
                trials.append({
                    'endpoint': endpoint_text,
                    'variant': _safe_text(patient.get('optumai_provider_ab_variant')),
                    'operator_choice': _safe_text(patient.get('optumai_provider_ab_operator_choice')),
                    'advice_id': _safe_text(patient.get('optumai_provider_ab_advice_id')),
                    'reason': _safe_text(patient.get('optumai_provider_ab_reason')),
                    'submission_status_success': bool(status),
                    'outcome': outcome,
                    'custody_signal_present': outcome in (
                        'accepted_no_provider_warning',
                        'accepted_with_provider_warning',
                    ),
                    'provider_warning_detected': outcome == 'accepted_with_provider_warning',
                    'transaction_id_present': _transaction_id_present(files, file_path),
                })
    if not trials:
        return {}
    now = now_func() if now_func else time.time()
    return {
        'schema_version': 1,
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(now)),
        'source': 'medilink_up_claim_submission',
        'summary_kind': 'optumai_provider_ab_trial',
        'trial_count': len(trials),
        'outcomes': [row.get('outcome') for row in trials],
        'trials': trials,
    }


def bundle_parts_for_submission_summary(summary):
    if not isinstance(summary, dict) or not summary.get('trial_count'):
        return ({}, [])
    outcomes = summary.get('outcomes') if isinstance(summary.get('outcomes'), list) else []
    extra_meta = {
        'bundle_kind': 'claim_submission_report',
        'claim_submission_context': 'optumai_provider_ab_trial',
        'optumai_provider_ab_trial_count': summary.get('trial_count'),
        'optumai_provider_ab_outcomes': list(outcomes),
    }
    return (
        extra_meta,
        [('optumai_provider_ab_submission_summary.json', summary)],
    )
