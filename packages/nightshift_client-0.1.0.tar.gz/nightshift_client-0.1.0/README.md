# nightshift-client

`nightshift-client` is the client-side Python package for the Nightshift tracker.

## Installation

```bash
cd nightshift-client
pip install -e .
```

## Python usage

```python
from nightshift_client import NightshiftClient

client = NightshiftClient(repo_path=".", identity="user@example.com")
issue_id = client.create_issue("Example issue", "Describe the problem")
client.push()
```

## CLI usage

```bash
nightshift-client daemon status --repo .
nightshift-client daemon start --repo .
nightshift-client daemon stop --repo .
```
