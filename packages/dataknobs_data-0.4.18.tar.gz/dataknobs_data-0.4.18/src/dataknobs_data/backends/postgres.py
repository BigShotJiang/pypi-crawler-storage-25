"""PostgreSQL backend implementation with proper connection management and vector support."""

from __future__ import annotations

import logging
import time
import uuid
from typing import TYPE_CHECKING, Any, cast

import asyncpg
from dataknobs_config import ConfigurableBase

from dataknobs_utils.sql_utils import PostgresDB, quote_ident

from ..database import AsyncDatabase, SyncDatabase
from ..pooling import ConnectionPoolManager
from ..pooling.postgres import PostgresPoolConfig, create_asyncpg_pool, validate_asyncpg_pool
from ..query import Operator, Query
from ..query_logic import ComplexQuery
from ..streaming import (
    StreamConfig,
    StreamResult,
    async_process_batch_with_fallback,
    process_batch_with_fallback,
)
from ..vector.mixins import VectorOperationsMixin
from .postgres_mixins import (
    PostgresBaseConfig,
    PostgresConnectionValidator,
    PostgresErrorHandler,
    PostgresTableManager,
    PostgresVectorSupport,
)
from .sql_base import SQLQueryBuilder, SQLRecordSerializer, SQLTableManager, validate_field_name
from ..vector.types import DistanceMetric

if TYPE_CHECKING:
    import numpy as np

    from collections.abc import AsyncIterator, Iterator, Callable, Awaitable
    from ..fields import VectorField
    from ..records import Record
    from ..vector.types import VectorSearchResult

logger = logging.getLogger(__name__)


class SyncPostgresDatabase(
    SyncDatabase,
    ConfigurableBase,
    VectorOperationsMixin,
    SQLRecordSerializer,
    PostgresBaseConfig,
    PostgresTableManager,
    PostgresVectorSupport,
    PostgresConnectionValidator,
    PostgresErrorHandler,
):
    """Synchronous PostgreSQL database backend with proper connection management."""

    def __init__(self, config: dict[str, Any] | None = None):
        """Initialize PostgreSQL database configuration.

        Args:
            config: Configuration with the following optional keys:
                - host: PostgreSQL host (default: from env/localhost)
                - port: PostgreSQL port (default: 5432)
                - database: Database name (default: from env/postgres)
                - user: Username (default: from env/postgres)
                - password: Password (default: from env)
                - table: Table name (default: "records")
                - schema: Schema name (default: "public")
                - enable_vector: Enable vector support (default: False)
                - ensure_database: Auto-create database if missing (default: True)
                - auto_create_table: Create the records table on connect if
                    missing (default: True). Set to False when an external
                    migration tool (Alembic, Flyway, etc.) owns DDL —
                    connect() will then verify the table exists and raise
                    RuntimeError if it doesn't.
        """
        super().__init__(config)

        # Parse configuration using mixin
        table_name, schema_name, conn_config, ensure_database, auto_create_table = (
            self._parse_postgres_config(config or {})
        )
        self._init_postgres_attributes(table_name, schema_name, ensure_database, auto_create_table)

        # Table manager for parameterized existence checks (psycopg2 pyformat style)
        self.table_manager = SQLTableManager(
            table_name,
            schema_name=schema_name,
            dialect="postgres",
            param_style="pyformat",
        )

        # Store connection config for later use
        self._conn_config = conn_config
        self.db = None  # Will be initialized in connect()
        self.query_builder = None  # Will be initialized in connect()

    @classmethod
    def from_config(cls, config: dict) -> SyncPostgresDatabase:
        """Create from config dictionary."""
        return cls(config)

    def connect(self) -> None:
        """Connect to the PostgreSQL database."""
        if self._connected:
            return  # Already connected

        # Initialize query builder with pyformat style for psycopg2
        self.query_builder = SQLQueryBuilder(self.table_name, self.schema_name, dialect="postgres", param_style="pyformat")

        # Open connection and ensure table; if the database doesn't exist
        # and ensure_database is enabled, create it and retry.
        # Note: PostgresDB connects lazily — the actual psycopg2 connection
        # happens on first query (in _ensure_table), not in _open_connection.
        try:
            self._open_connection()
            self._ensure_table()
        except Exception as e:
            if self._ensure_database_enabled and self._is_invalid_catalog_error(e):
                self._create_database()
                self._open_connection()
                self._ensure_table()
            else:
                raise

        # Detect and enable vector support if requested
        if self.vector_enabled:
            self._detect_vector_support()

        self._connected = True
        self.log_operation("connect", f"Connected to table: {self.schema_name}.{self.table_name}")

    def _open_connection(self) -> None:
        """Open the PostgresDB connection using stored config.

        The config dict is normalized up-front by
        ``normalize_postgres_connection_config`` (via
        ``_parse_postgres_config``), so ``host``/``database``/``user``/
        ``port`` are already populated from ``connection_string``, explicit
        keys, or ``POSTGRES_*`` env-var fallbacks. No secondary dotenv
        lookup is needed here — the normalizer is the single env-var
        contract.
        """
        self.db = PostgresDB(
            host=self._conn_config.get("host", "localhost"),
            db=self._conn_config.get("database", "postgres"),
            user=self._conn_config.get("user", "postgres"),
            pwd=self._conn_config.get("password"),
            port=self._conn_config.get("port", 5432),
        )

    @staticmethod
    def _is_invalid_catalog_error(exc: Exception) -> bool:
        """Check if an exception indicates the database does not exist.

        psycopg2 raises ``OperationalError`` for connection-level failures
        but does not set ``pgcode`` on these (it's ``None``).  We fall back
        to checking the error message for the PostgreSQL FATAL text.
        """
        import psycopg2
        if not isinstance(exc, psycopg2.OperationalError):
            return False
        pgcode = getattr(exc, "pgcode", None)
        if pgcode == "3D000":
            return True
        # Connection-level errors have pgcode=None; match on message
        if pgcode is None and "does not exist" in str(exc):
            return True
        return False

    def _create_database(self) -> None:
        """Create the target database via the ``postgres`` maintenance database.

        Called only when the initial connection fails because the target
        database does not exist.
        """
        import psycopg2
        import psycopg2.sql
        from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

        from .postgres_mixins import validate_database_name

        target_db = self._conn_config.get("database", "postgres")
        validate_database_name(target_db)

        conn = psycopg2.connect(
            host=self._conn_config.get("host", "localhost"),
            port=self._conn_config.get("port", 5432),
            user=self._conn_config.get("user", "postgres"),
            password=self._conn_config.get("password"),
            database="postgres",
            connect_timeout=10,
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)

        cursor = conn.cursor()
        try:
            cursor.execute(
                psycopg2.sql.SQL("CREATE DATABASE {}").format(
                    psycopg2.sql.Identifier(target_db)
                )
            )
            logger.info("Created PostgreSQL database %r", target_db)
        except psycopg2.errors.DuplicateDatabase:
            pass  # Race condition: another process created it
        finally:
            cursor.close()
            conn.close()

    def close(self) -> None:
        """Close the database connection."""
        if self.db:
            # PostgresDB manages its own connections via context managers
            # but we can mark as disconnected
            self._connected = False  # type: ignore[unreachable]

    def _initialize(self) -> None:
        """Initialize method - connection setup moved to connect()."""
        # Configuration parsing stays here, actual connection in connect()
        pass

    def _detect_vector_support(self) -> None:
        """Detect and enable vector support if pgvector is available."""
        from .postgres_vector import check_pgvector_extension_sync, install_pgvector_extension_sync

        try:
            # Check if pgvector is installed
            if check_pgvector_extension_sync(self.db):
                self._vector_enabled = True
                logger.info("pgvector extension detected and enabled")
            else:
                # Try to install it
                if install_pgvector_extension_sync(self.db):
                    self._vector_enabled = True
                    logger.info("pgvector extension installed and enabled")
                else:
                    logger.debug("pgvector extension not available")
        except Exception as e:
            logger.debug(f"Could not enable vector support: {e}")
            self._vector_enabled = False

    def _ensure_table(self) -> None:
        """Ensure the records table exists.

        When ``auto_create_table=True`` (default), runs ``CREATE TABLE IF NOT
        EXISTS …``. When ``auto_create_table=False``, verifies the table is
        present and raises ``RuntimeError`` if it isn't — for consumers
        managing DDL via Alembic / Flyway / Sqitch.
        """
        if not self.db:
            raise RuntimeError("Database not connected. Call connect() first.")

        if not self.auto_create_table:
            exists_sql, params = self.table_manager.get_table_exists_sql()
            df = self.db.query(exists_sql, params)
            exists = bool(df.iloc[0, 0]) if not df.empty else False
            if not exists:
                raise RuntimeError(
                    f"Table {self.schema_name}.{self.table_name} does not exist "
                    "and auto_create_table is disabled. Run your migrations "
                    "before starting the application."
                )
            return

        create_table_sql = self.get_create_table_sql(self.schema_name, self.table_name)
        self.db.execute(create_table_sql)

    def _record_to_row(self, record: Record, id: str | None = None) -> dict[str, Any]:
        """Convert a Record to a database row (delegates to shared serializer)."""
        return SQLRecordSerializer.record_to_row(record, id)

    def _row_to_record(self, row: dict[str, Any]) -> Record:
        """Convert a database row to a Record (delegates to shared serializer)."""
        return self.row_to_record(row)

    def create(self, record: Record) -> str:
        """Create a new record."""
        self._check_connection()
        # Use record's ID if it has one, otherwise generate a new one
        id = record.id if record.id else str(uuid.uuid4())
        row = self._record_to_row(record, id)

        sql = f"""
        INSERT INTO {self._q_qualified} (id, data, metadata)
        VALUES (%(id)s, %(data)s, %(metadata)s)
        """
        self.db.execute(sql, row)
        return id

    def read(self, id: str) -> Record | None:
        """Read a record by ID."""
        self._check_connection()
        sql = f"""
        SELECT id, data, metadata
        FROM {self._q_qualified}
        WHERE id = %(id)s
        """
        df = self.db.query(sql, {"id": id})

        if df.empty:
            return None

        row = df.iloc[0].to_dict()
        return self._row_to_record(row)

    def update(self, id: str, record: Record) -> bool:
        """Update an existing record.

        Args:
            id: The record ID to update
            record: The record data to update with

        Returns:
            True if the record was updated, False if no record with the given ID exists
        """
        self._check_connection()
        row = self._record_to_row(record, id)

        sql = f"""
        UPDATE {self._q_qualified}
        SET data = %(data)s, metadata = %(metadata)s, updated_at = CURRENT_TIMESTAMP
        WHERE id = %(id)s
        """
        result = self.db.execute(sql, row)

        # PostgresDB.execute returns number of affected rows
        rows_affected = result if isinstance(result, int) else 0

        if rows_affected == 0:
            logger.warning(f"Update affected 0 rows for id={id}. Record may not exist.")

        return rows_affected > 0

    def delete(self, id: str) -> bool:
        """Delete a record by ID."""
        self._check_connection()
        sql = f"""
        DELETE FROM {self._q_qualified}
        WHERE id = %(id)s
        """
        result = self.db.execute(sql, {"id": id})
        return result > 0 if isinstance(result, int) else False

    def exists(self, id: str) -> bool:
        """Check if a record exists."""
        self._check_connection()
        sql = f"""
        SELECT 1 FROM {self._q_qualified}
        WHERE id = %(id)s
        LIMIT 1
        """
        df = self.db.query(sql, {"id": id})
        return not df.empty

    def upsert(self, id_or_record: str | Record, record: Record | None = None) -> str:
        """Update or insert a record.
        
        Can be called as:
        - upsert(id, record) - explicit ID and record
        - upsert(record) - extract ID from record using Record's built-in logic
        """
        self._check_connection()
        
        # Determine ID and record based on arguments
        if isinstance(id_or_record, str):
            id = id_or_record
            if record is None:
                raise ValueError("Record required when ID is provided")
        else:
            record = id_or_record
            id = record.id
            if id is None:
                import uuid  # type: ignore[unreachable]
                id = str(uuid.uuid4())
                record.storage_id = id
        
        if self.exists(id):
            self.update(id, record)
        else:
            # Insert with specific ID
            row = self._record_to_row(record, id)
            sql = f"""
            INSERT INTO {self._q_qualified} (id, data, metadata)
            VALUES (%(id)s, %(data)s, %(metadata)s)
            """
            self.db.execute(sql, row)
        return id

    def search(self, query: Query | ComplexQuery) -> list[Record]:
        """Search for records matching the query."""
        self._check_connection()

        # Handle ComplexQuery with native SQL support
        if isinstance(query, ComplexQuery):
            sql_query, params_list = self.query_builder.build_complex_search_query(query)
        else:
            sql_query, params_list = self.query_builder.build_search_query(query)

        # Build params dict for psycopg2
        # The query builder now generates %(p0)s style placeholders directly
        params_dict = {}
        if params_list:
            for i, param in enumerate(params_list):
                params_dict[f"p{i}"] = param

        # Execute query
        df = self.db.query(sql_query, params_dict)

        # Convert to records
        records = []
        for _, row in df.iterrows():
            row_dict = row.to_dict()
            record = self._row_to_record(row_dict)

            # Apply field projection if specified
            if query.fields:
                record = record.project(query.fields)

            records.append(record)

        return records

    def _count_all(self) -> int:
        """Count all records in the database."""
        self._check_connection()
        sql = f"SELECT COUNT(*) as count FROM {self._q_qualified}"
        df = self.db.query(sql)
        return int(df.iloc[0]["count"]) if not df.empty else 0

    def clear(self) -> int:
        """Clear all records from the database."""
        self._check_connection()
        # Get count first
        count = self._count_all()

        # Delete all records
        sql = f"TRUNCATE TABLE {self._q_qualified}"
        self.db.execute(sql)

        return count

    def create_batch(self, records: list[Record]) -> list[str]:
        """Create multiple records efficiently using a single query.
        
        Uses multi-value INSERT for better performance.
        
        Args:
            records: List of records to create
            
        Returns:
            List of created record IDs
        """
        if not records:
            return []

        self._check_connection()

        # Create a query builder for PostgreSQL with pyformat style
        from .sql_base import SQLQueryBuilder
        query_builder = SQLQueryBuilder(self.table_name, self.schema_name, dialect="postgres", param_style="pyformat")

        # Use the shared batch create query builder
        query, params_list, ids = query_builder.build_batch_create_query(records)

        # Build params dict for psycopg2
        params_dict = {}
        for i, param in enumerate(params_list):
            params_dict[f"p{i}"] = param

        # Execute the batch insert and get returned IDs
        result_df = self.db.query(query, params_dict)

        # PostgreSQL RETURNING clause gives us the actual inserted IDs
        if not result_df.empty:
            return result_df['id'].tolist()
        return ids

    def delete_batch(self, ids: list[str]) -> list[bool]:
        """Delete multiple records efficiently using a single query.
        
        Uses single DELETE with IN clause for better performance.
        
        Args:
            ids: List of record IDs to delete
            
        Returns:
            List of success flags for each deletion
        """
        if not ids:
            return []

        self._check_connection()

        # Create a query builder for PostgreSQL with pyformat style
        from .sql_base import SQLQueryBuilder
        query_builder = SQLQueryBuilder(self.table_name, self.schema_name, dialect="postgres", param_style="pyformat")

        # Use the shared batch delete query builder (includes RETURNING clause)
        query, params_list = query_builder.build_batch_delete_query(ids)

        # Build params dict for psycopg2
        params_dict = {}
        for i, param in enumerate(params_list):
            params_dict[f"p{i}"] = param

        # Execute the batch delete and get returned IDs
        result_df = self.db.query(query, params_dict)

        # Get list of deleted IDs from RETURNING clause
        deleted_ids = set(result_df['id'].tolist()) if not result_df.empty else set()

        # Return results based on which IDs were actually deleted
        results = []
        for id in ids:
            results.append(id in deleted_ids)

        return results

    def update_batch(self, updates: list[tuple[str, Record]]) -> list[bool]:
        """Update multiple records efficiently using a single query.
        
        Uses PostgreSQL's CASE expressions for batch updates via shared SQL builder.
        
        Args:
            updates: List of (id, record) tuples to update
            
        Returns:
            List of success flags for each update
        """
        if not updates:
            return []

        self._check_connection()

        # Create a query builder for PostgreSQL with pyformat style
        from .sql_base import SQLQueryBuilder
        query_builder = SQLQueryBuilder(self.table_name, self.schema_name, dialect="postgres", param_style="pyformat")

        # Use the shared batch update query builder
        query, params_list = query_builder.build_batch_update_query(updates)

        # Build params dict for psycopg2
        params_dict = {}
        for i, param in enumerate(params_list):
            params_dict[f"p{i}"] = param

        # Execute the batch update and get returned IDs (query now includes RETURNING clause)
        result_df = self.db.query(query, params_dict)

        # Get list of updated IDs from RETURNING clause
        updated_ids = set(result_df['id'].tolist()) if not result_df.empty else set()

        results = []
        for record_id, _ in updates:
            results.append(record_id in updated_ids)

        return results

    def stream_read(
        self,
        query: Query | None = None,
        config: StreamConfig | None = None
    ) -> Iterator[Record]:
        """Stream records from PostgreSQL."""
        if query and query.filters:
            for f in query.filters:
                validate_field_name(f.field)
        self._check_connection()
        config = config or StreamConfig()

        # Build SQL query
        sql = f"SELECT id, data, metadata FROM {self._q_qualified}"
        params = {}

        if query and query.filters:
            # Add WHERE clause (simplified for now)
            where_clauses = []
            for i, filter in enumerate(query.filters):
                field_path = f"data->>'{filter.field}'"
                param_name = f"param_{i}"

                if filter.operator == Operator.EQ:
                    where_clauses.append(f"{field_path} = %({param_name})s")
                    params[param_name] = str(filter.value)

            if where_clauses:
                sql += " WHERE " + " AND ".join(where_clauses)

        # Use cursor for streaming
        # Note: PostgresDB may need modification to support cursors
        # For now, we'll fetch in batches
        sql += f" LIMIT {config.batch_size} OFFSET %(offset)s"

        offset = 0
        while True:
            params["offset"] = offset
            df = self.db.query(sql, params)

            if df.empty:
                break

            for _, row in df.iterrows():
                record = self._row_to_record(row.to_dict())
                if query and query.fields:
                    record = record.project(query.fields)
                yield record

            offset += config.batch_size

            # If we got less than batch_size, we're done
            if len(df) < config.batch_size:
                break

    def stream_write(
        self,
        records: Iterator[Record],
        config: StreamConfig | None = None
    ) -> StreamResult:
        """Stream records into PostgreSQL."""
        self._check_connection()
        config = config or StreamConfig()
        result = StreamResult()
        start_time = time.time()
        quitting = False

        batch = []
        for record in records:
            batch.append(record)

            if len(batch) >= config.batch_size:
                # Write batch with graceful fallback
                continue_processing = process_batch_with_fallback(
                    batch,
                    self._write_batch,
                    self.create,
                    result,
                    config
                )

                if not continue_processing:
                    quitting = True
                    break

                batch = []

        # Write remaining batch
        if batch and not quitting:
            process_batch_with_fallback(
                batch,
                self._write_batch,
                self.create,
                result,
                config
            )

        result.duration = time.time() - start_time
        return result

    def _write_batch(self, records: list[Record]) -> list[str]:
        """Write a batch of records to the database.
        
        Returns:
            List of created record IDs
        """
        # Build batch insert SQL
        values = []
        params = {}
        ids = []

        for i, record in enumerate(records):
            id = str(uuid.uuid4())
            ids.append(id)
            row = self._record_to_row(record, id)
            values.append(f"(%(id_{i})s, %(data_{i})s, %(metadata_{i})s)")
            params[f"id_{i}"] = row["id"]
            params[f"data_{i}"] = row["data"]
            params[f"metadata_{i}"] = row["metadata"]

        sql = f"""
        INSERT INTO {self._q_qualified} (id, data, metadata)
        VALUES {', '.join(values)}
        """
        self.db.execute(sql, params)
        return ids

    def vector_search(
        self,
        query_vector: np.ndarray | list[float] | VectorField,
        field_name: str,
        k: int = 10,
        filter: Query | None = None,
        metric: DistanceMetric | str = "cosine"
    ) -> list[VectorSearchResult]:
        """Search for similar vectors using PostgreSQL pgvector.
        
        Args:
            query_vector: Query vector (numpy array, list, or VectorField)
            field_name: Name of vector field to search (must be in data JSON)
            limit: Maximum number of results
            filters: Optional filters to apply
            metric: Distance metric to use (cosine, euclidean, l2, inner_product)
            
        Returns:
            List of VectorSearchResult objects ordered by similarity
        """
        if not self._vector_enabled:
            raise RuntimeError("Vector search not available - pgvector not installed")

        self._check_connection()

        from ..fields import VectorField
        from ..vector.types import DistanceMetric, VectorSearchResult
        from .postgres_vector import format_vector_for_postgres, get_vector_operator

        # Convert query vector to proper format
        if isinstance(query_vector, VectorField):
            vector_str = format_vector_for_postgres(query_vector.value)
        else:
            vector_str = format_vector_for_postgres(query_vector)

        # Get the appropriate operator
        if isinstance(metric, DistanceMetric):
            metric_str = metric.value
        else:
            metric_str = str(metric).lower()

        operator = get_vector_operator(metric_str)

        # Build the query - vectors are stored in JSON data field
        # Use centralized vector extraction logic
        vector_expr = self.get_vector_extraction_sql(field_name, dialect="postgres")

        # Build the base SQL with pyformat placeholders
        sql = f"""
        SELECT 
            id, 
            data,
            metadata,
            {vector_expr} {operator} %(p0)s::vector AS distance
        FROM {self._q_qualified}
        WHERE data ? %(p1)s  -- Check field exists
        """

        params: list[Any] = [vector_str, field_name]

        # Add filters if provided using the query builder
        if filter:
            # Query builder will generate pyformat placeholders since we configured it that way
            where_clause, filter_params = self.query_builder.build_where_clause(filter, len(params) + 1)
            if where_clause:
                sql += where_clause
                params.extend(filter_params)

        # Order by distance and limit
        next_param = len(params)
        sql += f" ORDER BY distance LIMIT %(p{next_param})s"
        params.append(k)

        # Build param dict for psycopg2
        param_dict = {}
        for i, param in enumerate(params):
            param_dict[f"p{i}"] = param

        df = self.db.query(sql, param_dict)

        # Convert results
        results = []
        for _, row in df.iterrows():
            record = self._row_to_record(row)

            # Calculate similarity score from distance
            distance = row["distance"]
            if metric_str in ["cosine", "cosine_similarity"]:
                score = 1.0 - distance  # Cosine distance to similarity
            elif metric_str in ["euclidean", "l2"]:
                score = 1.0 / (1.0 + distance)  # Convert distance to similarity
            elif metric_str in ["inner_product", "dot_product"]:
                score = -distance  # Negative because pgvector uses negative for descending
            else:
                score = -distance  # Default: lower distance = better

            result = VectorSearchResult(
                record=record,
                score=float(score),
                vector_field=field_name
            )
            results.append(result)

        return results

    def has_vector_support(self) -> bool:
        """Check if this database has vector support enabled.
        
        Returns:
            True if vector operations are supported
        """
        return self._vector_enabled

    def enable_vector_support(self) -> bool:
        """Enable vector support for this database if possible.
        
        Returns:
            True if vector support is now enabled
        """
        if self._vector_enabled:
            return True

        self._detect_vector_support()
        return self._vector_enabled

    def bulk_embed_and_store(
        self,
        records: list[Record],
        text_field: str | list[str],
        vector_field: str = "embedding",
        embedding_fn: Any = None,
        batch_size: int = 100,
        model_name: str | None = None,
        model_version: str | None = None,
    ) -> list[str]:
        """Embed text fields and store vectors with records (stub for abstract requirement).
        
        This is a placeholder implementation to satisfy the abstract method requirement.
        Full implementation would require actual embedding function.
        """
        raise NotImplementedError("bulk_embed_and_store requires an embedding function")


# Global pool manager instance for async PostgreSQL connections
_pool_manager = ConnectionPoolManager[asyncpg.Pool]()


class AsyncPostgresDatabase(
    AsyncDatabase,
    VectorOperationsMixin,
    ConfigurableBase,
    PostgresBaseConfig,
    PostgresTableManager,
    PostgresVectorSupport,
    PostgresConnectionValidator,
    PostgresErrorHandler,
):
    """Native async PostgreSQL database backend with vector support and event loop-aware connection pooling."""

    def __init__(self, config: dict[str, Any] | None = None):
        """Initialize async PostgreSQL database.

        Args:
            config: Configuration with the following optional keys:
                - host: PostgreSQL host (default: localhost)
                - port: PostgreSQL port (default: 5432)
                - database: Database name (default: postgres)
                - user: Username (default: postgres)
                - password: Password (default: empty)
                - table: Table name (default: "records")
                - schema: Schema name (default: "public")
                - enable_vector: Enable vector support (default: False)
                - ensure_database: Auto-create database if missing (default: True)
                - auto_create_table: Create the records table on connect if
                    missing (default: True). Set to False when an external
                    migration tool (Alembic, Flyway, etc.) owns DDL —
                    connect() will then verify the table exists and raise
                    RuntimeError if it doesn't.
                - connection_string: PostgreSQL connection string (alternative to individual params)
                - min_pool_size: Minimum pool connections (default: 2)
                - max_pool_size: Maximum pool connections (default: 5)
                - command_timeout: Command timeout in seconds (default: None)
                - ssl: SSL configuration (default: None)
        """
        super().__init__(config)

        # Parse configuration using mixin
        table_name, schema_name, conn_config, ensure_database, auto_create_table = (
            self._parse_postgres_config(config or {})
        )
        self._init_postgres_attributes(table_name, schema_name, ensure_database, auto_create_table)

        # Table manager for parameterized existence checks (asyncpg numeric style)
        self.table_manager = SQLTableManager(
            table_name,
            schema_name=schema_name,
            dialect="postgres",
            param_style="numeric",
        )

        # Extract pool configuration
        self._pool_config = PostgresPoolConfig.from_dict(conn_config)
        self._pool: asyncpg.Pool | None = None

    @classmethod
    def from_config(cls, config: dict) -> AsyncPostgresDatabase:
        """Create from config dictionary."""
        return cls(config)

    async def connect(self) -> None:
        """Connect to the database."""
        if self._connected:
            return

        # Attempt pool creation; if the database doesn't exist and
        # ensure_database is enabled, create it and retry.
        from ..pooling import BasePoolConfig
        try:
            self._pool = await _pool_manager.get_pool(
                self._pool_config,
                cast("Callable[[BasePoolConfig], Awaitable[Any]]", create_asyncpg_pool),
                validate_asyncpg_pool
            )
        except asyncpg.InvalidCatalogNameError:
            if self._ensure_database_enabled:
                await self._create_database()
                self._pool = await _pool_manager.get_pool(
                    self._pool_config,
                    cast("Callable[[BasePoolConfig], Awaitable[Any]]", create_asyncpg_pool),
                    validate_asyncpg_pool
                )
            else:
                raise

        # Initialize query builder
        self.query_builder = SQLQueryBuilder(self.table_name, self.schema_name, dialect="postgres")

        # Ensure table exists
        await self._ensure_table()

        # Check and enable vector support if requested
        if self.vector_enabled:
            await self._detect_vector_support()

        self._connected = True
        self.log_operation("connect", f"Connected to table: {self.schema_name}.{self.table_name}")

    async def _create_database(self) -> None:
        """Create the target database via the ``postgres`` maintenance database.

        Called only when pool creation fails with ``InvalidCatalogNameError``,
        indicating the target database does not exist.
        """
        from .postgres_mixins import validate_database_name

        target_db = self._pool_config.database
        # validate_database_name restricts to [a-zA-Z_][a-zA-Z0-9_]* which
        # is safe for double-quoted identifiers in CREATE DATABASE.  asyncpg
        # has no public sql.Identifier equivalent, so validation is the
        # primary defence against injection here.
        validate_database_name(target_db)

        conn = await asyncpg.connect(
            host=self._pool_config.host,
            port=self._pool_config.port,
            user=self._pool_config.user,
            password=self._pool_config.password,
            database="postgres",
            ssl=self._pool_config.ssl,
            timeout=10,
        )
        try:
            await conn.execute(f'CREATE DATABASE "{target_db}"')
            logger.info("Created PostgreSQL database %r", target_db)
        except asyncpg.exceptions.DuplicateDatabaseError:
            pass  # Race condition: another process created it
        finally:
            await conn.close()

    async def close(self) -> None:
        """Close the database connection and properly close the pool."""
        if self._pool is not None:
            try:
                await self._pool.close()
            except Exception as e:
                logger.warning("Error closing connection pool: %s", e)
            self._pool = None
        self._connected = False

    def _initialize(self) -> None:
        """Initialize is handled in connect."""
        pass

    async def _ensure_table(self) -> None:
        """Ensure the records table exists.

        When ``auto_create_table=True`` (default), runs ``CREATE TABLE IF NOT
        EXISTS …``. When ``auto_create_table=False``, verifies the table is
        present and raises ``RuntimeError`` if it isn't — for consumers
        managing DDL via Alembic / Flyway / Sqitch.
        """
        if not self._pool:
            raise RuntimeError("Database not connected. Call connect() first.")

        if not self.auto_create_table:
            exists_sql, params = self.table_manager.get_table_exists_sql()
            async with self._pool.acquire() as conn:
                exists = await conn.fetchval(exists_sql, *params)
            if not exists:
                raise RuntimeError(
                    f"Table {self.schema_name}.{self.table_name} does not exist "
                    "and auto_create_table is disabled. Run your migrations "
                    "before starting the application."
                )
            return

        create_table_sql = self.get_create_table_sql(self.schema_name, self.table_name)
        async with self._pool.acquire() as conn:
            await conn.execute(create_table_sql)

    async def _detect_vector_support(self) -> None:
        """Detect and enable vector support if pgvector is available."""
        from .postgres_vector import check_pgvector_extension, install_pgvector_extension

        async with self._pool.acquire() as conn:
            # Check if pgvector is available
            if await check_pgvector_extension(conn):
                self._vector_enabled = True
                logger.info("pgvector extension detected and enabled")
            else:
                # Try to install it
                if await install_pgvector_extension(conn):
                    self._vector_enabled = True
                    logger.info("pgvector extension installed and enabled")
                else:
                    logger.debug("pgvector extension not available")

    async def _ensure_vector_column(self, field_name: str, dimensions: int) -> None:
        """Ensure a vector column exists for the given field.
        
        Args:
            field_name: Name of the vector field
            dimensions: Number of dimensions
        """
        if not self._vector_enabled:
            return

        column_name = f"vector_{field_name}"
        q_column_name = quote_ident(column_name)

        # Check if column already exists
        check_sql = """
        SELECT column_name FROM information_schema.columns
        WHERE table_schema = $1 AND table_name = $2 AND column_name = $3
        """

        async with self._pool.acquire() as conn:
            existing = await conn.fetchval(check_sql, self.schema_name, self.table_name, column_name)

            if not existing:
                # Add vector column
                alter_sql = f"""
                ALTER TABLE {self._q_qualified}
                ADD COLUMN IF NOT EXISTS {q_column_name} vector({dimensions})
                """
                try:
                    await conn.execute(alter_sql)
                    self._vector_dimensions[field_name] = dimensions
                    logger.info(f"Added vector column {column_name} with {dimensions} dimensions")

                    # Create index for the vector column
                    from .postgres_vector import build_vector_index_sql, get_optimal_index_type

                    # Get row count for optimal index selection
                    count_sql = f"SELECT COUNT(*) FROM {self._q_qualified}"
                    count = await conn.fetchval(count_sql)

                    index_type, index_params = get_optimal_index_type(count)
                    index_sql = build_vector_index_sql(
                        self._q_table,
                        self._q_schema,
                        q_column_name,
                        dimensions,
                        metric="cosine",
                        index_type=index_type,
                        index_params=index_params
                    )

                    # Note: IVFFlat requires table to have data before creating index
                    if count > 0 or index_type != "ivfflat":
                        await conn.execute(index_sql)
                        logger.info(f"Created {index_type} index for {column_name}")

                except Exception as e:
                    logger.warning(f"Could not create vector column {column_name}: {e}")
            else:
                self._vector_dimensions[field_name] = dimensions

    def _check_connection(self) -> None:
        """Check if async database is connected."""
        self._check_async_connection()

    def _record_to_row(self, record: Record, id: str | None = None) -> dict[str, Any]:
        """Convert a Record to a database row (delegates to shared serializer).

        Mirrors :meth:`SyncPostgresDatabase._record_to_row`: both sync
        and async route through ``SQLRecordSerializer.record_to_row``
        so the outbound ``id`` / ``data`` / ``metadata`` shape lives
        in one place and cannot drift between siblings (the same trap
        that produced the inbound ``_row_to_record`` divergence).
        """
        return SQLRecordSerializer.record_to_row(record, id)

    def _row_to_record(self, row: asyncpg.Record) -> Record:
        """Convert a database row to a Record (delegates to shared serializer).

        Mirrors :meth:`SyncPostgresDatabase._row_to_record`: delegates
        to ``SQLRecordSerializer.row_to_record`` so the
        ``ensure_record_id`` step is applied uniformly. Without the
        delegation, async ``read()`` returned records where
        ``record.id`` / ``record.storage_id`` were whatever was in the
        JSON payload (typically ``None``) — silently differing from
        ``db.read(id)`` on the sync backend for the same on-disk row.
        ``asyncpg.Record`` supports ``dict()`` conversion via the
        mapping protocol; the explicit cast keeps the static helper's
        ``dict[str, Any]`` contract clean.
        """
        return SQLRecordSerializer.row_to_record(dict(row))

    @staticmethod
    def _build_vector_params(
        vector_inserts: list[tuple[str, str]],
        start_param: int,
    ) -> tuple[list[str], list[str], list[str]]:
        """Return (columns, placeholders, values) lists for vector fields.

        vector_inserts: [(quoted_col_name, formatted_vec_str), ...]
        start_param: $N index for the first vector parameter.
        Placeholders include the ``::vector`` cast required by asyncpg.
        """
        columns: list[str] = []
        placeholders: list[str] = []
        values: list[str] = []
        for i, (q_col, vec_str) in enumerate(vector_inserts):
            columns.append(q_col)
            placeholders.append(f"${start_param + i}::vector")
            values.append(vec_str)
        return columns, placeholders, values

    async def _collect_vector_inserts(
        self, record: Record
    ) -> list[tuple[str, str]]:
        """Return [(quoted_col_name, formatted_vec_str)] for every VectorField.

        Also calls _ensure_vector_column so the pgvector column is guaranteed
        to exist before any INSERT/UPDATE that uses the returned data.
        """
        from ..fields import VectorField
        from .postgres_vector import format_vector_for_postgres

        result: list[tuple[str, str]] = []
        for field_name, field_obj in record.fields.items():
            if isinstance(field_obj, VectorField) and self._vector_enabled:
                await self._ensure_vector_column(field_name, field_obj.dimensions)
                q_col = quote_ident(f"vector_{field_name}")
                result.append((q_col, format_vector_for_postgres(field_obj.value)))
        return result

    async def create(self, record: Record) -> str:
        """Create a new record with vector support."""
        self._check_connection()

        vector_inserts = await self._collect_vector_inserts(record)

        id = record.id if record.id else str(uuid.uuid4())
        row = self._record_to_row(record, id)

        columns = ["id", "data", "metadata"]
        values: list[Any] = [row["id"], row["data"], row["metadata"]]
        placeholders = ["$1", "$2", "$3"]

        vec_cols, vec_placeholders, vec_values = self._build_vector_params(
            vector_inserts, start_param=4
        )
        columns.extend(vec_cols)
        placeholders.extend(vec_placeholders)
        values.extend(vec_values)

        sql = f"""
        INSERT INTO {self._q_qualified} ({', '.join(columns)})
        VALUES ({', '.join(placeholders)})
        """

        async with self._pool.acquire() as conn:
            await conn.execute(sql, *values)

        return id

    async def read(self, id: str) -> Record | None:
        """Read a record by ID."""
        self._check_connection()
        sql = f"""
        SELECT id, data, metadata
        FROM {self._q_qualified}
        WHERE id = $1
        """

        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, id)

        if not row:
            return None

        return self._row_to_record(row)

    async def update(self, id: str, record: Record) -> bool:
        """Update an existing record.

        Args:
            id: The record ID to update
            record: The record data to update with

        Returns:
            True if the record was updated, False if no record with the given ID exists
        """
        self._check_connection()

        vector_inserts = await self._collect_vector_inserts(record)
        row = self._record_to_row(record, id)

        set_clauses = ["data = $2", "metadata = $3", "updated_at = CURRENT_TIMESTAMP"]
        values: list[Any] = [id, row["data"], row["metadata"]]

        vec_cols, vec_placeholders, vec_values = self._build_vector_params(
            vector_inserts, start_param=4
        )
        for q_col, placeholder in zip(vec_cols, vec_placeholders):
            set_clauses.append(f"{q_col} = {placeholder}")
        values.extend(vec_values)

        sql = f"""
        UPDATE {self._q_qualified}
        SET {', '.join(set_clauses)}
        WHERE id = $1
        """

        async with self._pool.acquire() as conn:
            result = await conn.execute(sql, *values)

        # Returns UPDATE n where n is rows affected
        rows_affected = int(result.split()[-1])

        if rows_affected == 0:
            logger.warning("Update affected 0 rows for id=%s. Record may not exist.", id)

        return rows_affected > 0

    async def delete(self, id: str) -> bool:
        """Delete a record by ID."""
        self._check_connection()
        sql = f"""
        DELETE FROM {self._q_qualified}
        WHERE id = $1
        """

        async with self._pool.acquire() as conn:
            result = await conn.execute(sql, id)

        # Returns DELETE n where n is rows affected
        return result.split()[-1] != "0"

    async def exists(self, id: str) -> bool:
        """Check if a record exists."""
        self._check_connection()
        sql = f"""
        SELECT 1 FROM {self._q_qualified}
        WHERE id = $1
        LIMIT 1
        """

        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql, id)

        return row is not None

    async def upsert(self, id_or_record: str | Record, record: Record | None = None) -> str:
        """Update or insert a record.

        Can be called as:
        - upsert(id, record) - explicit ID and record
        - upsert(record) - extract ID from record using Record's built-in logic
        """
        self._check_connection()

        # Determine ID and record based on arguments
        if isinstance(id_or_record, str):
            id = id_or_record
            if record is None:
                raise ValueError("Record required when ID is provided")
        else:
            record = id_or_record
            id = record.id
            if id is None:
                import uuid  # type: ignore[unreachable]
                id = str(uuid.uuid4())
                record.storage_id = id

        vector_inserts = await self._collect_vector_inserts(record)
        row = self._record_to_row(record, id)

        columns = ["id", "data", "metadata"]
        values: list[Any] = [row["id"], row["data"], row["metadata"]]
        placeholders = ["$1", "$2", "$3"]
        update_clauses = [
            "data = EXCLUDED.data",
            "metadata = EXCLUDED.metadata",
            "updated_at = CURRENT_TIMESTAMP",
        ]

        vec_cols, vec_placeholders, vec_values = self._build_vector_params(
            vector_inserts, start_param=4
        )
        columns.extend(vec_cols)
        placeholders.extend(vec_placeholders)
        values.extend(vec_values)
        for q_col in vec_cols:
            update_clauses.append(f"{q_col} = EXCLUDED.{q_col}")

        sql = f"""
        INSERT INTO {self._q_qualified} ({', '.join(columns)})
        VALUES ({', '.join(placeholders)})
        ON CONFLICT (id) DO UPDATE
        SET {', '.join(update_clauses)}
        """

        async with self._pool.acquire() as conn:
            await conn.execute(sql, *values)

        return id

    async def search(self, query: Query | ComplexQuery) -> list[Record]:
        """Search for records matching the query."""
        self._check_connection()

        # Initialize query builder if not already done
        if not hasattr(self, 'query_builder'):
            self.query_builder = SQLQueryBuilder(
                self.table_name, self.schema_name, dialect="postgres"
            )

        # Handle ComplexQuery with native SQL support
        if isinstance(query, ComplexQuery):
            sql, params = self.query_builder.build_complex_search_query(query)
        else:
            sql, params = self.query_builder.build_search_query(query)

        # Execute query with asyncpg (already uses positional parameters)
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)

        # Convert to records
        records = []
        for row in rows:
            record = self._row_to_record(row)

            # Apply field projection if specified
            if query.fields:
                record = record.project(query.fields)

            records.append(record)

        return records

    async def _count_all(self) -> int:
        """Count all records in the database."""
        self._check_connection()
        sql = f"SELECT COUNT(*) as count FROM {self._q_qualified}"

        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(sql)

        return row["count"] if row else 0

    async def clear(self) -> int:
        """Clear all records from the database."""
        self._check_connection()
        # Get count first
        count = await self._count_all()

        # Delete all records
        sql = f"TRUNCATE TABLE {self._q_qualified}"

        async with self._pool.acquire() as conn:
            await conn.execute(sql)

        return count

    async def create_batch(self, records: list[Record]) -> list[str]:
        """Create multiple records efficiently using a single query.
        
        Uses multi-value INSERT with RETURNING for better performance.
        
        Args:
            records: List of records to create
            
        Returns:
            List of created record IDs
        """
        if not records:
            return []

        self._check_connection()

        # Create a query builder for PostgreSQL
        from .sql_base import SQLQueryBuilder
        query_builder = SQLQueryBuilder(self.table_name, self.schema_name, dialect="postgres")

        # Use the shared batch create query builder
        query, params, ids = query_builder.build_batch_create_query(records)

        # Execute the batch insert with RETURNING
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, *params)

        # Return the actual inserted IDs from RETURNING clause
        if rows:
            return [row["id"] for row in rows]
        return ids  # Fallback to generated IDs

    async def delete_batch(self, ids: list[str]) -> list[bool]:
        """Delete multiple records efficiently using a single query.
        
        Uses single DELETE with IN clause and RETURNING for verification.
        
        Args:
            ids: List of record IDs to delete
            
        Returns:
            List of success flags for each deletion
        """
        if not ids:
            return []

        self._check_connection()

        # Create a query builder for PostgreSQL
        from .sql_base import SQLQueryBuilder
        query_builder = SQLQueryBuilder(self.table_name, self.schema_name, dialect="postgres")

        # Use the shared batch delete query builder
        query, params = query_builder.build_batch_delete_query(ids)

        # Execute the batch delete with RETURNING
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, *params)

        # Convert returned rows to set of deleted IDs
        deleted_ids = {row["id"] for row in rows}

        # Return results for each deletion
        results = []
        for id in ids:
            results.append(id in deleted_ids)

        return results

    async def update_batch(self, updates: list[tuple[str, Record]]) -> list[bool]:
        """Update multiple records efficiently using a single query.
        
        Uses PostgreSQL's CASE expressions for batch updates with native asyncpg.
        
        Args:
            updates: List of (id, record) tuples to update
            
        Returns:
            List of success flags for each update
        """
        if not updates:
            return []

        self._check_connection()

        # Create a query builder for PostgreSQL
        from .sql_base import SQLQueryBuilder
        query_builder = SQLQueryBuilder(self.table_name, self.schema_name, dialect="postgres")

        # Use the shared batch update query builder. It already
        # produces positional parameters ($1, $2) AND appends
        # ``RETURNING id`` when ``dialect="postgres"``
        # (sql_base.py:559-561) — do NOT append a second ``RETURNING
        # id`` here, that produces invalid SQL.
        query, params = query_builder.build_batch_update_query(updates)

        # Execute the batch update
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, *params)

        # Convert returned rows to set of updated IDs
        updated_ids = {row["id"] for row in rows}

        # Return results for each update
        results = []
        for record_id, _ in updates:
            results.append(record_id in updated_ids)

        return results

    async def vector_search(
        self,
        query_vector: np.ndarray | list[float] | VectorField,
        field_name: str,
        k: int = 10,
        filter: Query | None = None,
        metric: DistanceMetric | str = "cosine"
    ) -> list[VectorSearchResult]:
        """Search for similar vectors using PostgreSQL pgvector.
        
        Args:
            query_vector: Query vector (numpy array, list, or VectorField)
            field_name: Name of vector field to search
            limit: Maximum number of results
            filters: Optional filters to apply
            metric: Distance metric to use
            
        Returns:
            List of VectorSearchResult objects
        """
        if not self._vector_enabled:
            raise RuntimeError("Vector search not available - pgvector not installed")

        self._check_connection()

        from ..fields import VectorField
        from ..vector.types import DistanceMetric, VectorSearchResult
        from .postgres_vector import format_vector_for_postgres, get_vector_operator

        # Convert query vector to proper format
        if isinstance(query_vector, VectorField):
            vector_str = format_vector_for_postgres(query_vector.value)
        else:
            vector_str = format_vector_for_postgres(query_vector)

        # Get the appropriate operator
        if isinstance(metric, DistanceMetric):
            metric_str = metric.value
        else:
            metric_str = str(metric).lower()
        operator = get_vector_operator(metric_str)

        vector_column = f"vector_{field_name}"
        q_vector_column = quote_ident(vector_column)

        # Build query
        sql = f"""
        SELECT id, data, metadata, {q_vector_column},
               {q_vector_column} {operator} $1::vector AS distance
        FROM {self._q_qualified}
        WHERE {q_vector_column} IS NOT NULL
        """

        params = [vector_str]
        param_num = 2

        # Add filters if provided using the query builder
        if filter:
            # First get the where clause from query builder
            where_clause, filter_params = self.query_builder.build_where_clause(filter, param_num)
            if where_clause:
                # Convert %s placeholders to $N for asyncpg
                for param in filter_params:
                    where_clause = where_clause.replace("%s", f"${param_num}", 1)
                    params.append(param)
                    param_num += 1
                sql += where_clause

        # Order by distance and limit
        sql += f"""
        ORDER BY distance
        LIMIT {k}
        """

        # Execute query
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)

        # Convert to VectorSearchResult objects
        results = []
        for row in rows:
            record = self._row_to_record(row)

            # Convert distance to similarity score (1 - normalized_distance for cosine)
            distance = float(row['distance'])
            if metric_str == "cosine":
                score = 1.0 - min(distance, 2.0) / 2.0  # Normalize cosine distance [0,2] to similarity [0,1]
            elif metric_str in ["euclidean", "l2"]:
                score = 1.0 / (1.0 + distance)  # Convert distance to similarity
            else:
                score = 1.0 - distance  # Generic conversion

            result = VectorSearchResult(
                record=record,
                score=score,
                vector_field=field_name,
                metadata={"distance": distance, "metric": metric_str}
            )
            results.append(result)

        return results

    async def enable_vector_support(self) -> bool:
        """Enable vector support for this database.
        
        Returns:
            True if vector support is enabled
        """
        if self._vector_enabled:
            return True

        await self._detect_vector_support()
        return self._vector_enabled

    async def has_vector_support(self) -> bool:
        """Check if this database has vector support enabled.
        
        Returns:
            True if vector support is available
        """
        return self._vector_enabled

    async def bulk_embed_and_store(
        self,
        records: list[Record],
        text_field: str | list[str],
        vector_field: str,
        embedding_fn: Any | None = None,
        batch_size: int = 100,
        model_name: str | None = None,
        model_version: str | None = None,
    ) -> list[str]:
        """Embed text fields and store vectors with records.
        
        This is a placeholder implementation. In a real scenario, you would:
        1. Extract text from the specified fields
        2. Call the embedding function to generate vectors
        3. Store the vectors alongside the records
        
        Args:
            records: Records to process
            text_field: Field name(s) containing text to embed
            vector_field: Field name to store vectors in
            embedding_fn: Function to generate embeddings
            batch_size: Number of records to process at once
            model_name: Name of the embedding model
            model_version: Version of the embedding model
            
        Returns:
            List of record IDs that were processed
        """
        if not embedding_fn:
            raise ValueError("embedding_fn is required for bulk_embed_and_store")

        from ..fields import VectorField

        processed_ids = []

        # Process in batches
        for i in range(0, len(records), batch_size):
            batch = records[i:i + batch_size]

            # Extract texts
            texts = []
            for record in batch:
                if isinstance(text_field, list):
                    text = " ".join(str(record.fields.get(f, {}).value) for f in text_field if f in record.fields)
                else:
                    text = str(record.fields.get(text_field, {}).value) if text_field in record.fields else ""
                texts.append(text)

            # Generate embeddings
            if texts:
                embeddings = await embedding_fn(texts)

                # Store vectors with records
                for j, record in enumerate(batch):
                    if j < len(embeddings):
                        vector = embeddings[j]

                        # Add vector field to record
                        record.fields[vector_field] = VectorField(
                            name=vector_field,
                            value=vector,
                            dimensions=len(vector) if hasattr(vector, '__len__') else None,
                            source_field=text_field if isinstance(text_field, str) else ",".join(text_field),
                            model_name=model_name,
                            model_version=model_version,
                        )

                        # Create or update record
                        if record.has_storage_id():
                            if record.storage_id is None:
                                raise ValueError("Record has_storage_id() returned True but storage_id is None")
                            await self.update(record.storage_id, record)
                        else:
                            record_id = await self.create(record)
                            record.storage_id = record_id

                        if record.storage_id is None:
                            raise ValueError("Record storage_id is None after create/update")
                        processed_ids.append(record.storage_id)

        return processed_ids

    async def create_vector_index(
        self,
        vector_field: str,
        dimensions: int,
        metric: DistanceMetric | str = "cosine",
        index_type: str = "ivfflat",
        lists: int | None = None,
    ) -> bool:
        """Create a vector index for efficient similarity search.
        
        Args:
            vector_field: Name of the vector field to index
            dimensions: Number of dimensions in the vectors
            metric: Distance metric for the index
            index_type: Type of index (ivfflat, hnsw)
            lists: Number of lists for IVFFlat index
            
        Returns:
            True if index was created successfully
        """
        from .postgres_vector import (
            build_vector_column_expression,
            build_vector_index_sql,
            get_optimal_index_type,
            get_vector_count_sql,
        )

        self._check_connection()

        if not self._vector_enabled:
            return False

        # Determine optimal parameters if not provided
        if not lists and index_type == "ivfflat":
            # Count vectors to determine optimal lists
            count_sql = get_vector_count_sql(self._q_schema, self._q_table, vector_field)
            async with self._pool.acquire() as conn:
                count = await conn.fetchval(count_sql) or 0
                _, params = get_optimal_index_type(count)
                lists = params.get("lists", 100)

        # Convert metric enum to string if needed
        if hasattr(metric, 'value'):
            metric_str = metric.value
        else:
            metric_str = str(metric).lower()

        # Build vector column expression for index
        column_expr = build_vector_column_expression(vector_field, dimensions, for_index=True)

        # Build index SQL - pass field_name for proper index naming
        index_sql = build_vector_index_sql(
            q_table_name=self._q_table,
            q_schema_name=self._q_schema,
            column_name=column_expr,
            dimensions=dimensions,
            metric=metric_str,
            index_type=index_type,
            index_params={"lists": lists} if lists else None,
            field_name=vector_field
        )

        # Create the index
        try:
            logger.debug(f"Creating vector index with SQL: {index_sql}")
            async with self._pool.acquire() as conn:
                await conn.execute(index_sql)
            return True
        except Exception as e:
            logger.warning(f"Failed to create vector index: {e}")
            logger.debug(f"Index SQL was: {index_sql}")
            return False

    async def drop_vector_index(self, vector_field: str, metric: str = "cosine") -> bool:
        """Drop a vector index.
        
        Args:
            vector_field: Name of the vector field
            metric: Distance metric used in the index
            
        Returns:
            True if index was dropped successfully
        """
        from .postgres_vector import get_vector_index_name

        self._check_connection()

        index_name = get_vector_index_name(self.table_name, vector_field, metric)

        try:
            async with self._pool.acquire() as conn:
                await conn.execute(
                    f"DROP INDEX IF EXISTS {self._q_schema}.{quote_ident(index_name)}"
                )
            return True
        except Exception as e:
            logger.warning(f"Failed to drop vector index: {e}")
            return False

    async def get_vector_index_stats(self, vector_field: str) -> dict[str, Any]:
        """Get statistics about a vector field and its index.
        
        Args:
            vector_field: Name of the vector field
            
        Returns:
            Dictionary with index statistics
        """
        from .postgres_vector import get_index_check_sql, get_vector_count_sql

        self._check_connection()

        stats = {
            "field": vector_field,
            "indexed": False,
            "vector_count": 0,
        }

        try:
            async with self._pool.acquire() as conn:
                # Count vectors
                count_sql = get_vector_count_sql(self._q_schema, self._q_table, vector_field)
                stats["vector_count"] = await conn.fetchval(count_sql) or 0

                # Check for index — raw (unquoted) names are correct here:
                # get_index_check_sql queries pg_indexes using $1/$2 parameterized
                # bindings against catalog text columns (schemaname, tablename), not
                # via identifier interpolation, so quoting would produce wrong matches.
                index_sql, params = get_index_check_sql(self.schema_name, self.table_name, vector_field)
                stats["indexed"] = await conn.fetchval(index_sql, *params) or False
        except Exception as e:
            logger.warning(f"Failed to get vector index stats: {e}")

        return stats

    async def stream_read(
        self,
        query: Query | None = None,
        config: StreamConfig | None = None
    ) -> AsyncIterator[Record]:
        """Stream records from PostgreSQL using cursor."""
        if query and query.filters:
            for f in query.filters:
                validate_field_name(f.field)
        self._check_connection()
        config = config or StreamConfig()

        # Build SQL query
        sql = f"SELECT id, data, metadata FROM {self._q_qualified}"
        params = []

        if query and query.filters:
            where_clauses = []
            param_count = 0

            for filter in query.filters:
                param_count += 1
                field_path = f"data->>'{filter.field}'"

                if filter.operator == Operator.EQ:
                    where_clauses.append(f"{field_path} = ${param_count}")
                    params.append(str(filter.value))

            if where_clauses:
                sql += " WHERE " + " AND ".join(where_clauses)

        # Use cursor for efficient streaming. asyncpg's
        # ``conn.cursor(sql, *args)`` returns a ``CursorFactory`` that
        # supports ``async for``; ``await``-ing it returns a ``Cursor``
        # object intended for the explicit-fetch API
        # (``await cur.fetch(n)``) and is NOT an async iterator.
        async with self._pool.acquire() as conn:
            async with conn.transaction():
                batch = []
                async for row in conn.cursor(sql, *params):
                    record = self._row_to_record(row)
                    if query and query.fields:
                        record = record.project(query.fields)

                    batch.append(record)

                    if len(batch) >= config.batch_size:
                        for rec in batch:
                            yield rec
                        batch = []

                # Yield remaining records
                for rec in batch:
                    yield rec

    async def stream_write(
        self,
        records: AsyncIterator[Record],
        config: StreamConfig | None = None
    ) -> StreamResult:
        """Stream records into PostgreSQL using batch inserts."""
        self._check_connection()
        config = config or StreamConfig()
        result = StreamResult()
        start_time = time.time()
        quitting = False

        batch = []
        async for record in records:
            batch.append(record)

            if len(batch) >= config.batch_size:
                # Write batch with graceful fallback
                # Use lambda wrapper for _write_batch
                async def batch_func(b):
                    await self._write_batch(b)
                    return [r.id for r in b]

                continue_processing = await async_process_batch_with_fallback(
                    batch,
                    batch_func,
                    self.create,
                    result,
                    config
                )

                if not continue_processing:
                    quitting = True
                    break

                batch = []

        # Write remaining batch
        if batch and not quitting:
            async def batch_func(b):
                await self._write_batch(b)
                return [r.id for r in b]

            await async_process_batch_with_fallback(
                batch,
                batch_func,
                self.create,
                result,
                config
            )

        result.duration = time.time() - start_time
        return result

    async def _write_batch(self, records: list[Record]) -> list[str]:
        """Write a batch of records using COPY for performance.
        
        Returns:
            List of created record IDs
        """
        if not records:
            return []

        # Prepare data for COPY
        rows = []
        ids = []
        for record in records:
            row_data = self._record_to_row(record)
            ids.append(row_data["id"])
            rows.append((
                row_data["id"],
                row_data["data"],
                row_data["metadata"]
            ))

        # Use COPY for efficient bulk insert
        async with self._pool.acquire() as conn:
            await conn.copy_records_to_table(
                self.table_name,
                schema_name=self.schema_name or None,
                records=rows,
                columns=["id", "data", "metadata"]
            )

        return ids

    async def _supports_native_hybrid(self) -> bool:
        """Check if this PostgreSQL backend supports native hybrid search.

        PostgreSQL with pgvector and full-text search (tsvector) supports
        native hybrid search.

        Returns:
            True if vector support is enabled (pgvector available)
        """
        return self._vector_enabled

    async def hybrid_search(
        self,
        query_text: str,
        query_vector: np.ndarray | list[float],
        text_fields: list[str] | None = None,
        vector_field: str = "embedding",
        k: int = 10,
        config: Any = None,  # HybridSearchConfig
        filter: Query | None = None,
        metric: DistanceMetric | str = DistanceMetric.COSINE,
    ) -> list[Any]:  # list[HybridSearchResult]
        """Perform hybrid search using PostgreSQL full-text search and pgvector.

        Combines PostgreSQL's tsvector full-text search with pgvector similarity
        search using configurable fusion strategies.

        Args:
            query_text: Text query for full-text matching
            query_vector: Vector for pgvector similarity search
            text_fields: Fields to search for text matching
            vector_field: Name of the vector field to search
            k: Number of results to return
            config: Hybrid search configuration (weights, fusion strategy)
            filter: Optional additional filters to apply
            metric: Distance metric for vector search

        Returns:
            List of HybridSearchResult ordered by combined score (descending)
        """
        from ..vector.hybrid import (
            FusionStrategy,
            HybridSearchConfig,
            HybridSearchResult,
            reciprocal_rank_fusion,
        )
        from .postgres_vector import format_vector_for_postgres, get_vector_operator

        self._check_connection()

        config = config or HybridSearchConfig()

        # For NATIVE strategy with pgvector, we can do a combined query
        # For other strategies, use the parent implementation
        if config.fusion_strategy not in (FusionStrategy.NATIVE, FusionStrategy.RRF):
            from ..vector.mixins import VectorOperationsMixin
            return await VectorOperationsMixin.hybrid_search(
                self,
                query_text=query_text,
                query_vector=query_vector,
                text_fields=text_fields,
                vector_field=vector_field,
                k=k,
                config=config,
                filter=filter,
                metric=metric,
            )

        # Use config.text_fields if provided, otherwise use parameter
        search_text_fields = config.text_fields or text_fields or ["content", "title", "text"]

        # Get more results for fusion
        fetch_k = min(k * 3, 100)

        # Prepare vector search
        if isinstance(query_vector, (list, tuple)):
            import numpy as np
            query_vector = np.array(query_vector, dtype=np.float32)

        vector_str = format_vector_for_postgres(query_vector)

        # Get metric operator
        if isinstance(metric, str):
            metric_str = metric.lower()
        else:
            metric_str = metric.value
        operator = get_vector_operator(metric_str)

        vector_column = f"vector_{vector_field}"
        q_vector_column = quote_ident(vector_column)

        # Build combined query using CTE for efficient hybrid search
        # This performs both searches in a single query
        sql = f"""
        WITH text_search AS (
            SELECT
                id,
                data,
                metadata,
                ts_rank_cd(
                    to_tsvector('english', {self._build_text_field_concat(search_text_fields)}),
                    plainto_tsquery('english', $1)
                ) as text_score,
                ROW_NUMBER() OVER (
                    ORDER BY ts_rank_cd(
                        to_tsvector('english', {self._build_text_field_concat(search_text_fields)}),
                        plainto_tsquery('english', $1)
                    ) DESC
                ) as text_rank
            FROM {self._q_qualified}
            WHERE to_tsvector('english', {self._build_text_field_concat(search_text_fields)}) @@ plainto_tsquery('english', $1)
            LIMIT {fetch_k}
        ),
        vector_search AS (
            SELECT
                id,
                data,
                metadata,
                {q_vector_column},
                1.0 - ({q_vector_column} {operator} $2::vector) as vector_score,
                ROW_NUMBER() OVER (
                    ORDER BY {q_vector_column} {operator} $2::vector
                ) as vector_rank
            FROM {self._q_qualified}
            WHERE {q_vector_column} IS NOT NULL
            LIMIT {fetch_k}
        ),
        combined AS (
            SELECT
                COALESCE(t.id, v.id) as id,
                COALESCE(t.data, v.data) as data,
                COALESCE(t.metadata, v.metadata) as metadata,
                t.text_score,
                t.text_rank,
                v.vector_score,
                v.vector_rank
            FROM text_search t
            FULL OUTER JOIN vector_search v ON t.id = v.id
        )
        SELECT * FROM combined
        """

        params = [query_text, vector_str]

        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(sql, *params)
        except Exception as e:
            # If full-text search fails, fall back to client-side fusion
            logger.warning(f"Native PostgreSQL hybrid search failed ({e}), falling back to client-side")
            from ..vector.mixins import VectorOperationsMixin
            return await VectorOperationsMixin.hybrid_search(
                self,
                query_text=query_text,
                query_vector=query_vector,
                text_fields=text_fields,
                vector_field=vector_field,
                k=k,
                config=HybridSearchConfig(
                    text_weight=config.text_weight,
                    vector_weight=config.vector_weight,
                    fusion_strategy=FusionStrategy.RRF,
                    rrf_k=config.rrf_k,
                    text_fields=config.text_fields,
                ),
                filter=filter,
                metric=metric,
            )

        # Build result lists for fusion
        records_by_id: dict[str, Record] = {}
        text_scores: list[tuple[str, float]] = []
        vector_scores: list[tuple[str, float]] = []

        for row in rows:
            record = self._row_to_record(row)
            record_id = row['id']
            records_by_id[record_id] = record

            if row['text_score'] is not None:
                text_scores.append((record_id, float(row['text_score'])))
            if row['vector_score'] is not None:
                vector_scores.append((record_id, float(row['vector_score'])))

        # Sort by score for rank-based fusion
        text_scores.sort(key=lambda x: x[1], reverse=True)
        vector_scores.sort(key=lambda x: x[1], reverse=True)

        # Apply RRF fusion
        fused = reciprocal_rank_fusion(
            text_results=text_scores,
            vector_results=vector_scores,
            k=config.rrf_k,
            text_weight=config.text_weight,
            vector_weight=config.vector_weight,
        )

        # Build HybridSearchResult objects
        text_score_map = dict(text_scores)
        vector_score_map = dict(vector_scores)
        text_rank_map = {rid: i + 1 for i, (rid, _) in enumerate(text_scores)}
        vector_rank_map = {rid: i + 1 for i, (rid, _) in enumerate(vector_scores)}

        results: list[HybridSearchResult] = []
        for record_id, combined_score in fused[:k]:
            if record_id not in records_by_id:
                continue

            results.append(HybridSearchResult(
                record=records_by_id[record_id],
                combined_score=combined_score,
                text_score=text_score_map.get(record_id),
                vector_score=vector_score_map.get(record_id),
                text_rank=text_rank_map.get(record_id),
                vector_rank=vector_rank_map.get(record_id),
                metadata={
                    "fusion_strategy": config.fusion_strategy.value,
                    "text_weight": config.text_weight,
                    "vector_weight": config.vector_weight,
                    "backend": "postgresql",
                },
            ))

        return results

    def _build_text_field_concat(self, text_fields: list[str]) -> str:
        """Build SQL expression to concatenate text fields for full-text search.

        Args:
            text_fields: List of field names to concatenate

        Returns:
            SQL expression for concatenated text fields
        """
        if not text_fields:
            return "COALESCE(data->>'content', '')"

        for field in text_fields:
            validate_field_name(field)

        parts = [f"COALESCE(data->>'{field}', '')" for field in text_fields]
        return " || ' ' || ".join(parts)

    async def _text_search_for_hybrid(
        self,
        query_text: str,
        text_fields: list[str] | None,
        k: int,
        filter: Query | None = None,
    ) -> list[tuple[Record, float]]:
        """Perform PostgreSQL full-text search for hybrid search fusion.

        Uses PostgreSQL's tsvector/tsquery full-text search with ts_rank_cd scoring.

        Args:
            query_text: Text to search for
            text_fields: Fields to search in
            k: Maximum results to return
            filter: Additional filters

        Returns:
            List of (record, score) tuples ordered by text relevance
        """
        self._check_connection()

        search_fields = text_fields or ["content", "title", "text"]
        text_concat = self._build_text_field_concat(search_fields)

        sql = f"""
        SELECT
            id,
            data,
            metadata,
            ts_rank_cd(
                to_tsvector('english', {text_concat}),
                plainto_tsquery('english', $1)
            ) as score
        FROM {self._q_qualified}
        WHERE to_tsvector('english', {text_concat}) @@ plainto_tsquery('english', $1)
        ORDER BY score DESC
        LIMIT {k}
        """

        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(sql, query_text)
        except Exception as e:
            # Fall back to LIKE-based search if full-text search fails
            logger.warning(f"PostgreSQL full-text search failed ({e}), falling back to LIKE")
            from ..vector.mixins import VectorOperationsMixin
            return await VectorOperationsMixin._text_search_for_hybrid(
                self,
                query_text=query_text,
                text_fields=text_fields,
                k=k,
                filter=filter,
            )

        # Normalize scores
        results: list[tuple[Record, float]] = []
        max_score = max((float(row['score']) for row in rows), default=1.0) or 1.0

        for row in rows:
            record = self._row_to_record(row)
            score = float(row['score']) / max_score if max_score > 0 else 0.0
            results.append((record, score))

        return results
