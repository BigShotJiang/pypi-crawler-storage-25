# pgvector Backend

## Overview

The pgvector backend provides production-ready vector similarity search using PostgreSQL with the [pgvector](https://github.com/pgvector/pgvector) extension. It combines PostgreSQL's reliability with efficient approximate nearest neighbor (ANN) search.

**Location**: `dataknobs_data.vector.stores.pgvector.PgVectorStore`

## Installation

```bash
pip install asyncpg
```

PostgreSQL setup:
```sql
CREATE EXTENSION IF NOT EXISTS vector;
```

## Quick Start

```python
from dataknobs_data.vector.stores import VectorStoreFactory
import numpy as np

factory = VectorStoreFactory()
store = factory.create(
    backend="pgvector",
    connection_string="postgresql://user:pass@localhost:5432/mydb",
    dimensions=768,
    metric="cosine"
)

await store.initialize()

# Add vectors
vectors = np.random.rand(100, 768).astype(np.float32)
ids = await store.add_vectors(vectors, metadata=[{"source": f"doc_{i}"} for i in range(100)])

# Search
results = await store.search(np.random.rand(768).astype(np.float32), k=5)

await store.close()
```

## Configuration

### Connection & Basic Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `connection_string` | str | env fallback | PostgreSQL connection URL |
| `host` / `port` / `database` / `user` / `password` | various | env fallback | Individual connection keys (any subset) |
| `dimensions` | int | Required | Vector dimensions |
| `metric` | str | `"cosine"` | Distance metric: `cosine`, `euclidean`, `inner_product` |
| `schema` | str | `"edubot"` | Database schema |
| `table_name` | str | `"knowledge_embeddings"` | Table name |
| `pool_min_size` | int | 2 | Min connection pool size |
| `pool_max_size` | int | 10 | Max connection pool size |

The connection is resolved by the shared
[Postgres connection config normalizer](../../common/docs/guides/postgres-config.md)
— any combination of `connection_string`, individual keys,
`DATABASE_URL`, or `POSTGRES_*` env vars is accepted, with explicit
config always winning over env.

### Table Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `auto_create_table` | bool | `True` | Auto-create table if missing |
| `id_type` | str | `"text"` | ID type: `uuid` or `text`. See note below. |
| `columns` | dict | Default mappings | Column name overrides |
| `domain_id` | str | None | Multi-tenant domain filter |

#### `id_type` default

`id_type` defaults to `"text"` so that RAG consumers passing chunk ids
such as `"01-fundamentals_0"` work out-of-the-box without any config
override. If you previously relied on server-generated UUID columns,
set `id_type: "uuid"` explicitly — pre-existing UUID-typed tables keep
working because `CREATE TABLE IF NOT EXISTS` is a no-op on existing
tables.

Mismatches between `id_type="uuid"` and non-UUID id values raise a
guided `ValueError` (not a raw `asyncpg.DataError`) pointing at the
config change required to accept text ids.

### Index Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `index_type` | str | `"none"` | Index: `none`, `hnsw`, `ivfflat` |
| `auto_create_index` | bool | `False` | Auto-create index |
| `min_rows_for_index` | int | 1000 | Min rows for IVFFlat auto-creation |
| `index_params` | dict | `{}` | Index parameters |

## Index Types

### HNSW

Best for most production use cases. Works with empty tables.

```python
store = factory.create(
    backend="pgvector",
    dimensions=768,
    index_type="hnsw",
    auto_create_index=True,
    index_params={
        "m": 16,               # Connections per layer
        "ef_construction": 64  # Build quality
    }
)
```

### IVFFlat

Best for very large datasets. Requires existing data for clustering.

```python
store = factory.create(
    backend="pgvector",
    dimensions=768,
    index_type="ivfflat",
    auto_create_index=True,
    min_rows_for_index=1000,
    index_params={"lists": 100}  # Number of clusters
)
```

### Explicit Index Creation

```python
await store.create_index("hnsw", {"m": 32, "ef_construction": 128})
# or
await store.create_index("ivfflat", {"lists": 200})
```

## Column Mappings

Default columns with customization:

```python
store = factory.create(
    backend="pgvector",
    dimensions=768,
    columns={
        "id": "product_id",
        "embedding": "vector_data",
        "content": "description",
        "metadata": "attributes"
    },
    id_type="text"
)
```

Default column names: `id`, `embedding`, `content`, `metadata`, `domain_id`, `document_id`, `chunk_index`, `created_at`, `updated_at`

## Multi-tenant Usage

```python
tenant_store = factory.create(
    backend="pgvector",
    dimensions=768,
    domain_id="tenant_123"  # All operations filtered to this domain
)
```

## API Reference

### Core Methods

```python
# Initialize connection
await store.initialize()

# Add vectors
ids = await store.add_vectors(
    vectors,                    # np.ndarray
    ids=None,                   # Optional list[str]
    metadata=None               # Optional list[dict]
)

# Search
results = await store.search(
    query_vector,               # np.ndarray
    k=10,                       # Number of results
    filter=None,                # Metadata filter dict
    include_metadata=True,
    include_timestamps=False    # See "Timestamp Exposure" below
)  # Returns list[tuple[id, score, metadata]]

# Get vectors
results = await store.get_vectors(
    ids,                        # list[str]
    include_metadata=True,
    include_timestamps=False    # See "Timestamp Exposure" below
)  # Returns list[tuple[vector, metadata]]

# Delete vectors
count = await store.delete_vectors(ids)

# Update metadata
count = await store.update_metadata(ids, metadata_list)

# Count
total = await store.count(filter=None)

# Clear
await store.clear()

# Create index
created = await store.create_index(
    index_type="hnsw",          # or "ivfflat"
    params={"m": 16},           # Index parameters
    if_not_exists=True
)

# Close
await store.close()
```

## Metadata Filters

`search()` and `count()` accept a `filter: dict[str, Any] | None` that
is translated to JSONB-native predicates using `jsonb_build_object`
and the `@>` containment operator. Booleans, numbers, and lists are
type-preserved — the prior text-cast translation
(`metadata->>'key' = '...'`) silently returned zero rows for these
types.

```python
# Stored: {"type": "tension", "tags": ["urgent"], "active": True, "count": 5}

await store.search(q, k=10, filter={"type": "tension"})  # scalar EQ
await store.search(q, k=10, filter={"tags": "urgent"})   # in list
await store.search(q, k=10, filter={"type": ["tension", "gap"]})  # IN
await store.search(q, k=10, filter={"tags": ["urgent", "later"]}) # intersection
await store.count(filter={"active": True})   # → 1   (boolean roundtrip)
await store.count(filter={"count": 5})       # → 1   (numeric roundtrip)
await store.count(filter={"count": "5"})     # → 0   (no implicit coercion)
```

See [Vector Store Metadata Filter Semantics](vector-filter-semantics.md)
for the canonical four-quadrant table, per-backend implementation
notes, and constraints (hashability, flat shape, follow-ups).

## Distance Metrics

| Metric | pgvector Op | Score Conversion |
|--------|-------------|------------------|
| `cosine` | `<=>` | `1 - distance` |
| `euclidean` | `<->` | `1 / (1 + distance)` |
| `inner_product` | `<#>` | Raw value |

## Distributed Environments

The backend queries PostgreSQL's `pg_indexes` catalog for index existence checks, making it safe for multi-instance deployments (AWS ECS, Kubernetes, etc.).

## Auto-Created Schema

```sql
CREATE TABLE IF NOT EXISTS {schema}.{table_name} (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    domain_id VARCHAR(100),
    document_id VARCHAR(255),
    chunk_index INTEGER,
    content TEXT,
    embedding vector({dimensions}),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

## Upsert Semantics

`add_vectors` performs an upsert on `ON CONFLICT (id)`. All content
columns (`embedding`, `metadata`, `content`, `domain_id`,
`document_id`, `chunk_index`) are refreshed from the new row,
`updated_at` is set to `NOW()`, and `created_at` is **preserved** to
retain the original insertion time. `update_metadata` also refreshes
`updated_at = NOW()` — any write is a re-ingestion signal.

## Schema Migration — `updated_at` Column

When `auto_create_table=True` (the default), `initialize()` applies an
idempotent migration that adds `updated_at TIMESTAMP` to pre-existing
tables via `ALTER TABLE ... ADD COLUMN IF NOT EXISTS`. The migration
runs unconditionally on every `initialize()`, both after
`CREATE TABLE IF NOT EXISTS` (no-op when the column is already
present) and when the table pre-existed without the column.

**Pre-existing rows retain `NULL` in `updated_at`** — an honest "not
re-ingested since the column was added" signal — until the next
upsert or `update_metadata` populates the column with `NOW()`. The
column is added without a default in the `ADD COLUMN` step and then
wired up with `ALTER COLUMN ... SET DEFAULT NOW()` in a second,
catalog-only step, so Postgres does not rewrite the table to backfill
legacy rows with a volatile default.

### When `auto_create_table=False`

Consumers who manage their own schema must apply the migration
manually once, before pointing the store at an existing table:

```sql
ALTER TABLE <schema>.<table>
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP;
ALTER TABLE <schema>.<table>
  ALTER COLUMN updated_at SET DEFAULT NOW();
```

Both statements are idempotent — safe to re-run.

## Timestamp Exposure

Pass `include_timestamps=True` to `get_vectors()` or `search()` to
return `created_at` / `updated_at` (formatted per the configured
`timestamps.format`) as `_created_at` / `_updated_at` keys in the
result metadata. Pre-migration rows surface as `None` on
`_updated_at`. See the [Vector Store Timestamp Exposure](vector-timestamps.md)
shared concept doc for configuration, formats, collision policy, and
cross-backend semantics.

## See Also

- [Vector Store Timestamp Exposure](vector-timestamps.md)
- [Vector Store Design](history/vector-implementation/VECTOR_STORE_DESIGN_V2.md)
- [API Reference](API_REFERENCE.md)
