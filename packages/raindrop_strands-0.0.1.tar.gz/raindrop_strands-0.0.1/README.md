# raindrop-strands

Raindrop integration for [Strands Agents](https://strandsagents.com) (Python). Automatically captures agent invocations, model calls, tool usage, and token metrics via the Strands hook system.

## Installation

```bash
pip install raindrop-strands strands-agents
```

`strands-agents` is a required dependency.

## Usage

```python
import os
from strands import Agent
from raindrop_strands import create_raindrop_strands

raindrop = create_raindrop_strands(
    api_key=os.environ.get("RAINDROP_API_KEY"),
    user_id="user_123",
    convo_id="session_456",
)

agent = Agent(
    model="us.amazon.nova-lite-v1:0",
    system_prompt="You are a helpful assistant.",
)

raindrop["handler"].register_hooks(agent)

result = agent("What is the capital of France?")
print(result)

raindrop["flush"]()
```

Omitting `api_key` disables telemetry shipping (a warning is emitted) but does not crash your application.

## API

### `create_raindrop_strands(api_key, user_id, convo_id)`

Returns a dict with:

- `"handler"` — `RaindropStrandsHandler` instance to register on agents
- `"flush"` — flush pending telemetry
- `"shutdown"` — flush and release resources

## Testing

```bash
cd packages/strands-python
poetry install --with dev
pytest
```

## License

MIT
