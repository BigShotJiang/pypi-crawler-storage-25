# -*- coding: utf-8 -*-
"""Request and response models for the AtendentePro service API."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class SetupRequest(BaseModel):
    """Payload for POST /setup — registers or updates a tenant's agent network."""

    tenant_id: str = Field(..., min_length=1)
    yamls: Dict[str, str] = Field(
        ...,
        description="Map of config name to YAML content, e.g. {'flow_config': '...', 'triage_config': '...'}",
    )
    include_agents: Optional[Dict[str, bool]] = Field(
        default=None,
        description=(
            "Agent inclusion overrides. Keys: flow, interview, answer, knowledge, "
            "confirmation, usage, onboarding, escalation, feedback."
        ),
    )
    network_config: Optional[Dict[str, List[str]]] = Field(
        default=None,
        description=(
            "Custom handoff graph. Maps agent name to list of handoff target names. "
            "When set, uses create_custom_network instead of create_standard_network."
        ),
    )
    availability_schedule: Optional[Dict[str, Any]] = Field(
        default=None,
        description=(
            "Optional business-hours gate (issue #136). Shape: "
            "{'timezone': 'America/Sao_Paulo', "
            "'hours': {'monday': {'start': '08:00', 'end': '18:00'}, ...}, "
            "'out_of_hours_message': '...'}. When configured, /chat "
            "short-circuits with the OOH message outside the windows."
        ),
    )


class UserContextPayload(BaseModel):
    """User identity for role-based access filtering."""

    user_id: Optional[str] = None
    role: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class ChatRequest(BaseModel):
    """Payload for POST /chat — sends a message to a tenant's agent network."""

    # Upper bounds on text inputs prevent log flooding and memory spikes
    # from a malicious or buggy caller. tenant_id/session_id are routing
    # keys so a hard cap of 128 is plenty; message is the LLM input so
    # we allow a generous 64 KB (~16k tokens).
    tenant_id: str = Field(..., min_length=1, max_length=128)
    session_id: str = Field(..., min_length=1, max_length=128)
    message: str = Field(..., min_length=1, max_length=65_536)
    metadata: Optional[Dict[str, Any]] = None
    user_context: Optional[UserContextPayload] = Field(
        default=None,
        description="User identity for RBAC filtering (user_id, role, metadata).",
    )

    # Note: per-request prompt_dialect / prompt_dialect_enabled fields
    # were removed. Agent instructions are baked at tenant setup time,
    # so a payload toggle had no real effect and surfaced as a false API
    # contract (the server would silently log + drop). For real A/B
    # switching, set PROMPT_DIALECT_ENABLED / PROMPT_DIALECT in the
    # service env and rebuild tenants.


class ToolCallPayload(BaseModel):
    """A single function-tool call emitted by an agent during a /chat run.

    Exposed so consumers running tools client-side (e.g. an edge function
    persisting to its own database) can replay the call with their own
    credentials. The server has already executed the registered Python tool
    and fed the output back to the model — ``tool_results`` carries that
    output, also for client transparency.
    """

    call_id: Optional[str] = Field(
        default=None,
        description="Provider-assigned identifier; pairs the call with its entry in tool_results.",
    )
    name: str = Field(..., description="Function-tool name (e.g. 'register_meal').")
    arguments: str = Field(
        ...,
        description="Arguments as a JSON-encoded string, exactly as the model produced them.",
    )


class ToolResultPayload(BaseModel):
    """The output the server's tool implementation returned for a tool call."""

    call_id: Optional[str] = None
    output: str = Field(..., description="String output of the tool (often JSON).")


class ChatResponse(BaseModel):
    """Response from POST /chat."""

    response: str
    agent_name: Optional[str] = None
    handoff_to: Optional[str] = None
    tool_calls: List[ToolCallPayload] = Field(
        default_factory=list,
        description=(
            "Function-tool calls produced during the run. Empty when the agent "
            "answered with text only."
        ),
    )
    tool_results: List[ToolResultPayload] = Field(
        default_factory=list,
        description=("Outputs of the tools executed by the server, paired with calls via call_id."),
    )
    no_reply: bool = Field(
        default=False,
        description=(
            "True when the server intentionally did not invoke the agent network "
            "(e.g. staff takeover via UserContext.metadata.human_active). When set, "
            "``response`` is empty and ``no_reply_reason`` carries the reason code."
        ),
    )
    no_reply_reason: Optional[str] = Field(
        default=None,
        description=("Reason code when ``no_reply`` is true. Known values: 'human_active'."),
    )


class HealthResponse(BaseModel):
    """Response from GET /health."""

    status: str = "ok"
    version: str
    tenants_loaded: List[str] = Field(default_factory=list)
