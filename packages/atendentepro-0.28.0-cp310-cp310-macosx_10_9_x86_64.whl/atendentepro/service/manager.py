# -*- coding: utf-8 -*-
"""
Tenant manager for the AtendentePro multi-tenant service.

Handles per-tenant AgentNetwork lifecycle and per-session conversation history.
"""

from __future__ import annotations

import asyncio
import importlib
import logging
import os
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


# ============================================================================
# TOOL I/O EXTRACTION
# ============================================================================


def _extract_tool_io(
    new_items: Optional[List[Any]],
) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Pull tool calls and tool outputs out of the SDK ``RunResult.new_items``.

    Returns ``(tool_calls, tool_results)`` shaped to match :class:`ToolCallPayload`
    and :class:`ToolResultPayload`. Designed for clients that re-execute tools
    locally (Path B) — the server has already run the registered Python tool,
    but the client may need the raw ``arguments`` to perform an effect against
    its own backend (e.g. write to its database with its own credentials).

    Duck-typed against the OpenAI Agents SDK because ``ToolCallItemTypes`` is a
    union of provider-specific shapes plus a fallback ``dict``. Items that
    don't expose a name + arguments are skipped silently — the response stays
    valid even when the SDK introduces a new tool item kind.
    """
    if not new_items:
        return [], []

    tool_calls: List[Dict[str, Any]] = []
    tool_results: List[Dict[str, Any]] = []

    for item in new_items:
        item_type = getattr(item, "type", None)
        raw_item = getattr(item, "raw_item", None)

        if item_type == "tool_call_item" and raw_item is not None:
            name = _get(raw_item, "name")
            arguments = _get(raw_item, "arguments")
            if name is None or arguments is None:
                continue
            tool_calls.append(
                {
                    "call_id": _get(raw_item, "call_id"),
                    "name": str(name),
                    # arguments is already a JSON-encoded string from the model
                    "arguments": str(arguments),
                }
            )
            continue

        if item_type == "tool_call_output_item":
            output = getattr(item, "output", None)
            call_id = _get(raw_item, "call_id") if raw_item is not None else None
            if output is None:
                continue
            tool_results.append(
                {
                    "call_id": call_id,
                    "output": output if isinstance(output, str) else str(output),
                }
            )

    return tool_calls, tool_results


def _get(obj: Any, key: str) -> Any:
    """Return ``obj.key`` for objects, ``obj[key]`` for dicts, ``None`` otherwise."""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(key)
    return getattr(obj, key, None)


# ============================================================================
# CUSTOM NETWORK MODULE RESOLVER (issue #87)
# ============================================================================

# Allowlist prefix for ``network_type="custom_module"``. Modules outside
# this prefix cannot be imported via the YAML / kwargs path — protects
# against arbitrary code execution if a malicious YAML lands in the
# template tree (e.g. a compromised PR review). Override at deploy time
# via ``ATENDENTEPRO_NETWORK_MODULE_PREFIX`` (comma-separated list of
# allowed prefixes — set to ``"*"`` to disable the check, NOT recommended).
_NETWORK_MODULE_PREFIX_ENV = "ATENDENTEPRO_NETWORK_MODULE_PREFIX"
_DEFAULT_NETWORK_MODULE_PREFIX = "client_resources."


class NetworkModuleNotAllowedError(RuntimeError):
    """Raised when ``network_module`` does not match the allowlist prefix."""


def _allowed_network_module_prefixes() -> List[str]:
    """Return the active prefix allowlist (env override > default)."""
    raw = os.environ.get(_NETWORK_MODULE_PREFIX_ENV, "").strip()
    if not raw:
        return [_DEFAULT_NETWORK_MODULE_PREFIX]
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    return parts or [_DEFAULT_NETWORK_MODULE_PREFIX]


def _is_module_allowed(module_path: str, prefixes: List[str]) -> bool:
    """``True`` when *module_path* matches any allowed prefix.

    The literal ``"*"`` disables the check entirely (escape hatch — caller
    explicitly accepts the risk).
    """
    if not module_path:
        return False
    if "*" in prefixes:
        return True
    return any(module_path == p.rstrip(".") or module_path.startswith(p) for p in prefixes)


def _resolve_custom_network_factory(
    module_path: str,
    factory_name: str,
) -> Callable[..., Any]:
    """Import *module_path* and return its *factory_name* callable.

    Enforces the allowlist prefix (issue #87). Raises a precise error
    message at the first failure so misconfiguration is obvious in logs.
    """
    if not module_path:
        raise NetworkModuleNotAllowedError(
            "network_module is required when network_type='custom_module'."
        )
    if not factory_name:
        raise NetworkModuleNotAllowedError(
            "network_factory is required when network_type='custom_module'."
        )

    prefixes = _allowed_network_module_prefixes()
    if not _is_module_allowed(module_path, prefixes):
        raise NetworkModuleNotAllowedError(
            f"network_module={module_path!r} is outside the allowlist prefixes "
            f"{prefixes!r}. Either move the module under an allowed prefix or "
            f"export {_NETWORK_MODULE_PREFIX_ENV} with a comma-separated list "
            f"of additional prefixes (use '*' to disable the check entirely — "
            f"NOT recommended)."
        )

    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Could not import network_module={module_path!r}: {exc}. "
            f"Verify the module is on PYTHONPATH and the spelling is correct."
        ) from exc

    factory = getattr(module, factory_name, None)
    if factory is None:
        raise AttributeError(
            f"network_factory={factory_name!r} is not defined in module "
            f"{module_path!r}. Verify the symbol name and that it is exported "
            f"at module top-level."
        )
    if not callable(factory):
        raise TypeError(
            f"network_factory={factory_name!r} in {module_path!r} is not callable "
            f"(got {type(factory).__name__})."
        )
    return factory


_INCLUDE_AGENT_KEYS = frozenset(
    {
        "flow",
        "interview",
        "answer",
        "knowledge",
        "confirmation",
        "usage",
        "onboarding",
        "escalation",
        "feedback",
    }
)

SESSION_TTL_SECONDS = int(os.environ.get("ATENDENTEPRO_SESSION_TTL", "3600"))
CLEANUP_INTERVAL_SECONDS = 300
AGENT_TIMEOUT_SECONDS = float(os.environ.get("ATENDENTEPRO_AGENT_TIMEOUT", "60"))


@dataclass
class _Session:
    messages: List[Dict[str, str]] = field(default_factory=list)
    last_active: float = field(default_factory=time.time)


@dataclass
class _TenantState:
    # Typed as ``Any`` at runtime (dataclass annotation) but conceptually
    # this is a ``BaseNetwork`` (issue #150 — Task 2.3): either the legacy
    # ``AgentNetwork`` (sequential triage pipeline) or a ``ParallelNetwork``
    # ensemble. The dispatcher in :meth:`TenantManager.chat` branches on
    # the runtime type so sequential tenants keep their full
    # ``RunResult`` extraction (last_agent / new_items / tool_calls).
    network: Any  # BaseNetwork
    sessions: Dict[str, _Session] = field(default_factory=dict)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    # Last time this tenant served traffic — drives TTL purge and LRU
    # eviction when ``max_active_tenants`` is set (issue #134). Defaults
    # to setup time so a freshly registered tenant doesn't race the
    # cleanup loop into immediate eviction.
    last_active: float = field(default_factory=time.time)
    # Optional availability schedule (issue #136). When set, ``chat()``
    # short-circuits with the configured out-of-hours message before
    # invoking the agent network.
    availability_schedule: Optional[Any] = None  # AvailabilitySchedule


class TenantManager:
    """Manages AgentNetwork instances per tenant and conversation histories per session.

    All ``default_*`` parameters set baseline values that apply to every tenant.
    Per-tenant overrides can be passed via :meth:`setup` and :meth:`chat`.
    """

    def __init__(
        self,
        templates_dir: Optional[Path] = None,
        default_custom_tools: Optional[Dict[str, List[Any]]] = None,
        default_include_agents: Optional[Dict[str, bool]] = None,
        default_network_config: Optional[Dict[str, List[str]]] = None,
        default_user_loader: Optional[Callable[[List], Any]] = None,
        tenant_ttl_minutes: Optional[int] = None,
        max_active_tenants: Optional[int] = None,
    ) -> None:
        """Initialize the manager.

        Args:
            tenant_ttl_minutes: When set, tenants whose last ``/chat`` is older
                than this threshold are evicted by the cleanup loop. ``None``
                (default) keeps every tenant in memory indefinitely — matches
                pre-#134 byte-for-byte behavior. Useful when ``tenant_id`` is a
                dynamic UUID (e.g. one tenant per clinic) and the working set
                is much smaller than the total registered set.
            max_active_tenants: Optional hard cap on simultaneously loaded
                tenants. When ``setup()`` would push the count past the cap,
                the LRU tenant (by ``last_active``) is evicted first. ``None``
                (default) disables the cap.

        After eviction, an evicted tenant's next ``/chat`` raises ``KeyError``
        (HTTP 404) — the client is expected to call ``/setup`` again to reload.
        """
        self._tenants: Dict[str, _TenantState] = {}
        self._templates_dir = templates_dir or Path(tempfile.mkdtemp(prefix="atendentepro_"))
        self._default_custom_tools: Dict[str, List[Any]] = default_custom_tools or {}
        self._default_include_agents: Dict[str, bool] = default_include_agents or {}
        self._default_network_config: Optional[Dict[str, List[str]]] = default_network_config
        self._default_user_loader: Optional[Callable[[List], Any]] = default_user_loader
        self._cleanup_task: Optional[asyncio.Task[None]] = None
        self._tenant_ttl_seconds: Optional[float] = (
            float(tenant_ttl_minutes) * 60.0 if tenant_ttl_minutes else None
        )
        self._max_active_tenants: Optional[int] = max_active_tenants

    # ------------------------------------------------------------------
    # Setup
    # ------------------------------------------------------------------

    async def setup(
        self,
        tenant_id: str,
        yamls: Dict[str, str],
        custom_tools: Optional[Dict[str, List[Any]]] = None,
        include_agents: Optional[Dict[str, bool]] = None,
        network_config: Optional[Dict[str, List[str]]] = None,
        network_type: str = "standard",
        network_module: Optional[str] = None,
        network_factory: Optional[str] = None,
        network_params: Optional[Dict[str, Any]] = None,
        availability_schedule: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Write YAML configs to disk and create an AgentNetwork for *tenant_id*.

        Knowledge items (title/category/content) received via YAML are mapped
        to the ``about`` field of ``knowledge_config.yaml`` so the Knowledge
        Agent has them as direct context.  Embeddings are NOT generated here --
        they belong to the separate document-upload flow (PDFs chunked into
        hundreds of embeddings).

        Args:
            tenant_id: Unique identifier for the tenant.
            yamls: Map of config name to YAML content.
            custom_tools: Optional dict of custom tools per agent name.
                Merged with ``default_custom_tools`` (per-tenant overrides win).
            include_agents: Optional dict of agent name to bool controlling
                which agents are included. Merged with ``default_include_agents``.
                Valid keys: flow, interview, answer, knowledge, confirmation,
                usage, onboarding, escalation, feedback.
            network_config: Optional dict mapping agent names to their handoff
                targets (list of agent name strings). When provided, uses
                ``create_custom_network`` instead of ``create_standard_network``.
                Overrides ``default_network_config`` for this tenant.
            network_type: Strategy for assembling the AgentNetwork (issue #87).
                ``"standard"`` (default) → existing standard/custom network path.
                ``"custom_module"`` → import a Python factory by name and call
                it with ``network_params``. The module path MUST match the
                allowlist prefix in ``ATENDENTEPRO_NETWORK_MODULE_PREFIX``
                (default ``client_resources.``) — protects against arbitrary
                code execution from a compromised YAML.
                ``"parallel"`` → call :func:`create_parallel_network` for
                this tenant. Requires the YAML payload to include a
                ``multiagent_config.yaml`` with ``network_type: parallel``
                and the usual ``fanout`` / ``coordinator`` fields. The
                resulting :class:`ParallelNetwork` is dispatched by
                :meth:`chat` via the ``BaseNetwork`` Protocol.
            network_module: Required when ``network_type="custom_module"`` —
                dotted module path (e.g. ``client_resources.acme.network``).
            network_factory: Required when ``network_type="custom_module"`` —
                name of a top-level callable that returns an AgentNetwork.
            network_params: kwargs forwarded to the custom factory. Must be a
                plain dict; ``None`` means no kwargs.
        """
        import yaml as _yaml

        from atendentepro.network import (
            AgentNetwork,
            create_custom_network,
            create_parallel_network,
            create_standard_network,
        )
        from atendentepro.templates.manager import get_template_manager

        tenant_dir = self._templates_dir / tenant_id
        tenant_dir.mkdir(parents=True, exist_ok=True)

        for config_name, content in yamls.items():
            filename = f"{config_name}.yaml" if not config_name.endswith(".yaml") else config_name
            (tenant_dir / filename).write_text(content, encoding="utf-8")

        self._rewrite_knowledge_config(yamls, tenant_dir)

        get_template_manager().clear_caches()

        merged_tools: Optional[Dict[str, List[Any]]] = None
        if self._default_custom_tools or custom_tools:
            merged_tools = {**self._default_custom_tools, **(custom_tools or {})}

        merged_includes = {**self._default_include_agents, **(include_agents or {})}

        effective_network_config = network_config or self._default_network_config

        if network_type == "custom_module":
            # Issue #87: import-by-name network factory with allowlist.
            factory = _resolve_custom_network_factory(
                module_path=network_module or "",
                factory_name=network_factory or "",
            )
            kwargs = dict(network_params or {})
            try:
                network = factory(**kwargs)
            except TypeError as exc:
                raise TypeError(
                    f"network_factory={network_factory!r} in {network_module!r} "
                    f"rejected the supplied network_params kwargs: {exc}"
                ) from exc
            if not isinstance(network, AgentNetwork):
                raise TypeError(
                    f"network_factory={network_factory!r} in {network_module!r} "
                    f"returned {type(network).__name__}, expected AgentNetwork."
                )
        elif network_type == "parallel":
            # Issue #155: first-class dispatch of ParallelNetwork.
            # Requires multiagent_config.yaml with network_type=parallel
            # in the YAML payload (validated inside create_parallel_network).
            network = create_parallel_network(
                templates_root=self._templates_dir,
                client=tenant_id,
            )
        elif effective_network_config:
            network = create_custom_network(
                templates_root=self._templates_dir,
                client=tenant_id,
                network_config=effective_network_config,
                custom_tools=merged_tools,
            )
        elif network_type == "standard":
            network = create_standard_network(
                templates_root=self._templates_dir,
                client=tenant_id,
                custom_tools=merged_tools,
                user_loader=self._default_user_loader,
                include_flow=merged_includes.get("flow", True),
                include_interview=merged_includes.get("interview", True),
                include_answer=merged_includes.get("answer", True),
                include_knowledge=merged_includes.get("knowledge", True),
                include_confirmation=merged_includes.get("confirmation", True),
                include_usage=merged_includes.get("usage", True),
                include_onboarding=merged_includes.get("onboarding", False),
                include_escalation=merged_includes.get("escalation", True),
                include_feedback=merged_includes.get("feedback", True),
            )
        else:
            raise ValueError(
                f"Unknown network_type={network_type!r}. "
                f"Expected one of: 'standard', 'custom_module', 'parallel'."
            )

        # Parse availability schedule once at setup; chat() consults the
        # cached object (issue #136). ``None`` keeps pre-#136 byte-for-byte.
        parsed_schedule: Optional[Any] = None
        if availability_schedule:
            from atendentepro.availability import AvailabilitySchedule

            parsed_schedule = AvailabilitySchedule.from_dict(availability_schedule)

        if tenant_id in self._tenants:
            self._tenants[tenant_id].network = network
            self._tenants[tenant_id].last_active = time.time()
            if parsed_schedule is not None:
                self._tenants[tenant_id].availability_schedule = parsed_schedule
        else:
            # Issue #134: enforce the cap BEFORE insertion so the new tenant
            # never gets evicted on the same call. Eviction never touches
            # ``tenant_id`` because it isn't in the map yet.
            if self._max_active_tenants is not None:
                while len(self._tenants) >= self._max_active_tenants:
                    evicted = self._evict_lru_tenant()
                    if evicted is None:
                        break
                    logger.info(
                        "Evicted LRU tenant %s to enforce max_active_tenants=%d",
                        evicted,
                        self._max_active_tenants,
                    )
            self._tenants[tenant_id] = _TenantState(
                network=network,
                availability_schedule=parsed_schedule,
            )

        logger.info("Tenant %s configured (%d yamls)", tenant_id, len(yamls))

    # ------------------------------------------------------------------
    # Knowledge helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _rewrite_knowledge_config(yamls: Dict[str, str], tenant_dir: Path) -> None:
        """Convert knowledge items into the format KnowledgeConfig.load() expects.

        Incoming YAML may contain ``items`` (title/category/content).  The
        ``KnowledgeConfig`` model reads ``about``, ``template`` and ``format``.
        This method builds an ``about`` string from the items so the Knowledge
        Agent receives all the content as direct context (no RAG needed).
        """
        import yaml as _yaml

        raw = yamls.get("knowledge_config")
        if not raw:
            return

        try:
            data = _yaml.safe_load(raw)
        except Exception:
            return

        if not isinstance(data, dict):
            return

        items = data.get("items")
        if not items or not isinstance(items, list):
            return

        sections: List[str] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            title = item.get("title", "")
            category = item.get("category", "")
            content = item.get("content", "")
            if not content:
                continue
            header = title or category or "Item"
            sections.append(f"### {header}\n{content}")

        if not sections:
            return

        about_text = "\n\n".join(sections)

        kc_path = tenant_dir / "knowledge_config.yaml"
        existing: Dict[str, Any] = {}
        if kc_path.exists():
            existing = _yaml.safe_load(kc_path.read_text(encoding="utf-8")) or {}

        existing["about"] = about_text
        existing.pop("items", None)

        kc_path.write_text(_yaml.dump(existing, allow_unicode=True), encoding="utf-8")
        logger.info("Knowledge config rewritten with %d items as context", len(sections))

    # ------------------------------------------------------------------
    # Chat
    # ------------------------------------------------------------------

    async def chat(
        self,
        tenant_id: str,
        session_id: str,
        message: str,
        metadata: Optional[Dict[str, Any]] = None,
        user_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Run a message through the tenant's triage agent and return the result.

        Args:
            tenant_id: Target tenant.
            session_id: Conversation session identifier.
            message: User message text.
            metadata: Optional free-form metadata (phone, channel, etc.).
            user_context: Optional dict with ``user_id``, ``role``, and
                ``metadata`` keys.  When provided, a ``UserContext`` object
                is created and the runner uses it for access filtering.
                If a ``user_loader`` is configured on the network, it runs
                automatically via ``run_with_user_context``.
        """
        from agents import Runner

        state = self._tenants.get(tenant_id)
        if state is None:
            raise KeyError(f"Tenant '{tenant_id}' not configured. Call POST /setup first.")

        # Refresh tenant LRU stamp BEFORE any short-circuit so a tenant under
        # active human takeover (issue #135) doesn't get reaped by the TTL
        # purge or LRU eviction (issue #134).
        state.last_active = time.time()

        # Staff takeover hook (issue #135). When the caller signals an
        # active human handler via ``UserContext.metadata.human_active``,
        # short-circuit the run: no agent invocation, no session-history
        # mutation. The human's replies live outside the agent's context,
        # so we leave session.messages untouched. Cooldown / re-engagement
        # logic stays on the client. This wins over availability checks —
        # an emergency line where a human picked up should not be muted by
        # the schedule.
        if user_context:
            metadata = user_context.get("metadata")
            if isinstance(metadata, dict) and metadata.get("human_active"):
                logger.info(
                    "Staff takeover active for tenant=%s session=%s — skipping agent run",
                    tenant_id,
                    session_id,
                )
                return {
                    "response": "",
                    "agent_name": None,
                    "handoff_to": None,
                    "tool_calls": [],
                    "tool_results": [],
                    "no_reply": True,
                    "no_reply_reason": "human_active",
                }

        # Availability gate (issue #136). Outside the configured business
        # window the lib auto-replies with the tenant-defined OOH template
        # without invoking the agent network. Caller decides whether to
        # forward the template (typical) or stay silent.
        if (
            state.availability_schedule is not None
            and not state.availability_schedule.is_available()
        ):
            logger.info(
                "Out-of-hours response for tenant=%s session=%s",
                tenant_id,
                session_id,
            )
            return {
                "response": state.availability_schedule.out_of_hours_message,
                "agent_name": None,
                "handoff_to": None,
                "tool_calls": [],
                "tool_results": [],
                "no_reply": True,
                "no_reply_reason": "out_of_hours",
            }

        async with state.lock:
            session = state.sessions.setdefault(session_id, _Session())
            session.last_active = time.time()

            session.messages.append({"role": "user", "content": message})

            network = state.network

            # Reset user_context to prevent leaking between sessions (issue #15).
            # Only sequential ``AgentNetwork`` instances carry this attribute;
            # ParallelNetwork stays purely functional.
            if hasattr(network, "loaded_user_context"):
                network.loaded_user_context = None

            if user_context and hasattr(network, "loaded_user_context"):
                from atendentepro.models.context import UserContext as _UC

                uc = _UC(
                    user_id=user_context.get("user_id"),
                    role=user_context.get("role"),
                    metadata=user_context.get("metadata", {}),
                )
                network.loaded_user_context = uc

            # Sequential ``AgentNetwork`` instances expose a ``triage`` agent;
            # service callers expect rich extraction (last_agent / new_items)
            # off the ``RunResult`` so we keep the existing path. Other
            # ``BaseNetwork`` flavours (e.g. ParallelNetwork) only commit to
            # returning a string from ``run()`` — branch accordingly.
            from atendentepro.network import AgentNetwork as _AgentNetwork

            is_sequential = isinstance(network, _AgentNetwork) or hasattr(network, "triage")

            # ``asyncio.wait_for`` rather than ``asyncio.timeout``: the latter
            # is Python 3.11+ and the project floor is 3.10 (issue #138).
            async def _run() -> Any:
                if is_sequential and getattr(network, "user_loader", None) is not None:
                    from atendentepro.utils.user_loader import run_with_user_context as _run_ctx

                    return await _run_ctx(network, network.triage, list(session.messages))
                if is_sequential:
                    return await Runner.run(network.triage, list(session.messages))
                # Non-sequential BaseNetwork: ``run()`` returns a plain string.
                return await network.run(list(session.messages))

            try:
                result = await asyncio.wait_for(_run(), timeout=AGENT_TIMEOUT_SECONDS)
            except (asyncio.TimeoutError, TimeoutError):
                logger.error(
                    "Agent execution timed out after %.0fs for tenant=%s session=%s",
                    AGENT_TIMEOUT_SECONDS,
                    tenant_id,
                    session_id,
                )
                session.messages.append({"role": "assistant", "content": ""})
                return {
                    "response": "",
                    "agent_name": None,
                    "error": "timeout",
                    "timeout_seconds": AGENT_TIMEOUT_SECONDS,
                }

            if is_sequential:
                assistant_text = str(result.final_output) if result.final_output else ""
                last_agent = getattr(result, "last_agent", None)
                agent_name = getattr(last_agent, "name", None) if last_agent else None

                # Extract handoff target if the agent handed off (issue #39)
                handoff_to = None
                if last_agent and agent_name:
                    triage_name = getattr(network.triage, "name", None)
                    if triage_name and agent_name != triage_name:
                        handoff_to = agent_name

                tool_calls, tool_results = _extract_tool_io(getattr(result, "new_items", None))
            else:
                # ParallelNetwork & friends: only the final string is exposed
                # via the BaseNetwork contract. agent_name / tool_calls /
                # tool_results are not applicable to ensemble runs.
                assistant_text = str(result) if result else ""
                agent_name = None
                handoff_to = None
                tool_calls = []
                tool_results = []

            session.messages.append({"role": "assistant", "content": assistant_text})

        return {
            "response": assistant_text,
            "agent_name": agent_name,
            "handoff_to": handoff_to,
            "tool_calls": tool_calls,
            "tool_results": tool_results,
        }

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_loaded_tenants(self) -> List[str]:
        return list(self._tenants.keys())

    def remove_tenant(self, tenant_id: str) -> bool:
        return self._tenants.pop(tenant_id, None) is not None

    # ------------------------------------------------------------------
    # Session cleanup
    # ------------------------------------------------------------------

    def start_cleanup_loop(self) -> None:
        if self._cleanup_task is None or self._cleanup_task.done():
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())

    def stop_cleanup_loop(self) -> None:
        if self._cleanup_task and not self._cleanup_task.done():
            self._cleanup_task.cancel()

    async def _cleanup_loop(self) -> None:
        while True:
            await asyncio.sleep(CLEANUP_INTERVAL_SECONDS)
            await self._purge_expired_sessions()
            if self._tenant_ttl_seconds is not None:
                self._purge_expired_tenants()

    def _evict_lru_tenant(self) -> Optional[str]:
        """Drop the least-recently-active tenant. Returns its id or ``None`` if empty.

        Eviction does not lock — a chat already in flight retains its local
        ``state`` reference, so the network keeps serving until the call
        completes. The next ``/chat`` for an evicted tenant raises ``KeyError``
        (HTTP 404) and the client is expected to call ``/setup`` again.
        """
        if not self._tenants:
            return None
        lru_id = min(self._tenants, key=lambda tid: self._tenants[tid].last_active)
        del self._tenants[lru_id]
        return lru_id

    def _purge_expired_tenants(self) -> None:
        """Drop tenants whose ``last_active`` exceeds ``tenant_ttl_seconds``.

        No-op when ``tenant_ttl_minutes`` was not set (the legacy/static
        TrackFuel-style configuration).
        """
        if self._tenant_ttl_seconds is None:
            return
        cutoff = time.time() - self._tenant_ttl_seconds
        expired = [tid for tid, state in self._tenants.items() if state.last_active < cutoff]
        for tid in expired:
            del self._tenants[tid]
            logger.info(
                "Purged tenant %s (idle > %.0fs, TTL=%.0fs)",
                tid,
                time.time() - cutoff,
                self._tenant_ttl_seconds,
            )

    async def _purge_expired_sessions(self) -> None:
        """Purge expired sessions with per-tenant locking to avoid race conditions (issue #14)."""
        now = time.time()
        purged = 0
        for state in list(self._tenants.values()):
            async with state.lock:
                expired = [
                    sid
                    for sid, sess in state.sessions.items()
                    if now - sess.last_active > SESSION_TTL_SECONDS
                ]
                for sid in expired:
                    del state.sessions[sid]
                    purged += 1
        if purged:
            logger.info("Purged %d expired sessions", purged)
