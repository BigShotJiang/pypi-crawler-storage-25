# -*- coding: utf-8 -*-
"""
FastAPI application for the AtendentePro multi-tenant agent service.

Run directly:  python -m atendentepro.service.app
Via script:    atendentepro-service
"""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from typing import AsyncIterator, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from atendentepro.service.manager import TenantManager
from atendentepro.service.schemas import ChatRequest, ChatResponse, HealthResponse, SetupRequest
from atendentepro.utils.rate_limiter import RateLimiter, RateLimitExceededError

logger = logging.getLogger(__name__)

_manager: Optional[TenantManager] = None


def _get_manager() -> TenantManager:
    global _manager
    if _manager is None:
        _manager = TenantManager()
    return _manager


def create_app(manager: Optional[TenantManager] = None) -> FastAPI:
    """Build and return the FastAPI application.

    Args:
        manager: Optional pre-configured ``TenantManager``. When ``None`` a
            default instance is created.  Pass a custom manager to inject
            ``default_custom_tools`` or a specific ``templates_dir``.
    """
    global _manager
    if manager is not None:
        _manager = manager

    mgr = _get_manager()

    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
        from atendentepro import __version__
        from atendentepro.config import configure
        from atendentepro.license import activate

        token = os.environ.get("ATENDENTEPRO_LICENSE_KEY")
        activate(token=token, silent=True)

        configure(
            provider=os.environ.get("ATENDENTEPRO_PROVIDER", "openai"),
            openai_api_key=os.environ.get("OPENAI_API_KEY"),
        )

        mgr.start_cleanup_loop()
        logger.info("AtendentePro service v%s started", __version__)

        yield

        mgr.stop_cleanup_loop()

    app = FastAPI(
        title="AtendentePro Service",
        description="Multi-tenant agent network server",
        lifespan=lifespan,
    )

    # CORS middleware (issue #36)
    cors_origins = os.environ.get(
        "ATENDENTEPRO_CORS_ORIGINS", "http://localhost:3000,http://localhost:8000"
    ).split(",")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[o.strip() for o in cors_origins if o.strip()],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Rate limiter (issue #35)
    _rate_limit_max = int(os.environ.get("ATENDENTEPRO_RATE_LIMIT_MAX", "100"))
    _rate_limit_window = int(os.environ.get("ATENDENTEPRO_RATE_LIMIT_WINDOW", "60"))
    rate_limiter = RateLimiter(max_requests=_rate_limit_max, window_seconds=_rate_limit_window)

    @app.get("/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        from atendentepro import __version__

        return HealthResponse(
            version=__version__,
            tenants_loaded=mgr.get_loaded_tenants(),
        )

    @app.post("/setup")
    async def setup_tenant(req: SetupRequest) -> dict:
        try:
            rate_limiter.check(req.tenant_id)
        except RateLimitExceededError:
            raise HTTPException(status_code=429, detail="Rate limit exceeded")
        try:
            import yaml

            for config_name, content in req.yamls.items():
                try:
                    yaml.safe_load(content)
                except yaml.YAMLError as e:
                    raise HTTPException(
                        status_code=400,
                        detail=f"YAML invalido em '{config_name}': {e}",
                    ) from e

            await mgr.setup(
                req.tenant_id,
                req.yamls,
                include_agents=req.include_agents,
                network_config=req.network_config,
                availability_schedule=req.availability_schedule,
            )
        except HTTPException:
            raise
        except Exception as exc:
            logger.exception("Failed to setup tenant %s", req.tenant_id)
            raise HTTPException(
                status_code=500,
                detail=f"Erro ao configurar tenant: {exc}",
            ) from exc
        return {"status": "ok", "tenant_id": req.tenant_id}

    @app.post("/chat", response_model=ChatResponse)
    async def chat(req: ChatRequest) -> ChatResponse:
        try:
            rate_limiter.check(req.tenant_id)
        except RateLimitExceededError:
            raise HTTPException(status_code=429, detail="Rate limit exceeded")
        try:
            uc_dict = None
            if req.user_context is not None:
                uc_dict = req.user_context.model_dump(exclude_none=True)

            result = await mgr.chat(
                tenant_id=req.tenant_id,
                session_id=req.session_id,
                message=req.message,
                metadata=req.metadata,
                user_context=uc_dict,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception("Chat error for tenant %s", req.tenant_id)
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        return ChatResponse(**result)

    return app


app = create_app()


def main() -> None:
    """Entry point for the ``atendentepro-service`` console script."""
    import uvicorn

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run(
        "atendentepro.service.app:app",
        host=host,
        port=port,
        log_level="info",
    )


if __name__ == "__main__":
    main()
