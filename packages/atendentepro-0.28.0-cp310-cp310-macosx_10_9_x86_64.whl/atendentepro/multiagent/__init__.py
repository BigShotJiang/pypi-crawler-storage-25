# -*- coding: utf-8 -*-
"""Multi-agent hierarchy support for AtendentePro.

Public package surface for the hierarchy machinery introduced by
issues #147 / #148 / #149. The submodules
(:mod:`atendentepro.multiagent.metadata`,
:mod:`atendentepro.multiagent.invoke`,
:mod:`atendentepro.multiagent.signal`,
:mod:`atendentepro.multiagent.state`,
:mod:`atendentepro.multiagent.tools`) are wired here so consumers can do::

    from atendentepro.multiagent import (
        AgentMetadata,
        AgentSignal,
        MultiAgentState,
        invoke_agent,
        build_call_agent_tool,
    )

The same names are re-exported from the package top level
(``atendentepro``) per the ``.importlinter`` contract — public callers
should always prefer ``from atendentepro import X``.
"""

from atendentepro.multiagent.invoke import AgentOutputSchemaError, invoke_agent
from atendentepro.multiagent.metadata import (
    AgentMetadata,
    OutputSchemaNotAllowedError,
    check_output_schema_allowed,
    resolve_output_schema,
)
from atendentepro.multiagent.parallel import (
    CoordinatorError,
    ParallelFanoutError,
    ParallelNetwork,
    ParallelNetworkConfigError,
)
from atendentepro.multiagent.protocol import BaseNetwork, HasAgentMetadata
from atendentepro.multiagent.signal import AgentSignal, signal_subclass
from atendentepro.multiagent.state import MultiAgentState, new_state
from atendentepro.multiagent.tools import (
    CallAgentForbidden,
    UnknownAgentError,
    build_call_agent_tool,
)

__all__ = [
    # Metadata
    "AgentMetadata",
    "OutputSchemaNotAllowedError",
    "check_output_schema_allowed",
    "resolve_output_schema",
    # Signal
    "AgentSignal",
    "signal_subclass",
    # State
    "MultiAgentState",
    "new_state",
    # Invoke
    "invoke_agent",
    "AgentOutputSchemaError",
    # Tools
    "build_call_agent_tool",
    "CallAgentForbidden",
    "UnknownAgentError",
    # Protocol / Parallel ensemble (PR2)
    "BaseNetwork",
    "HasAgentMetadata",
    "ParallelNetwork",
    "ParallelNetworkConfigError",
    "ParallelFanoutError",
    "CoordinatorError",
]
