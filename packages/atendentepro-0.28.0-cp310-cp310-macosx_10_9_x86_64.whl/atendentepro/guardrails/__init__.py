# -*- coding: utf-8 -*-
"""Guardrails module for AtendentePro library."""

from .manager import (
    GuardrailCallable,
    GuardrailManager,
    InputGuardrailDecision,
    clear_guardrail_cache,
    get_guardrails_for_agent,
    get_out_of_scope_message,
    load_guardrail_config,
    run_input_guardrails,
    set_guardrails_client,
)

__all__ = [
    "GuardrailManager",
    "GuardrailCallable",
    "InputGuardrailDecision",
    "get_guardrails_for_agent",
    "get_out_of_scope_message",
    "load_guardrail_config",
    "set_guardrails_client",
    "clear_guardrail_cache",
    "run_input_guardrails",
]
