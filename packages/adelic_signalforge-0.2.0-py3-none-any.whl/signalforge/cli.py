"""
signalforge.cli

Command-line interface for SignalForge.

Usage
-----
    python -m signalforge <command> [options]

Commands
--------
    demo            Run the built-in EEG seizure demo (no arguments needed)
    run             Run the pipeline on a CSV file
    plan            Show a SamplingPlan for a domain
    neighborhood    Show the p-adic arithmetic viewing box for an integer
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
DOCS = HERE.parent / "docs"
EXAMPLES = HERE.parent / "examples"


# ---------------------------------------------------------------------------
# demo
# ---------------------------------------------------------------------------

def cmd_demo(args: argparse.Namespace) -> int:
    """Run the built-in EEG seizure detection demo."""
    csv_path = DOCS / "eeg_chbmit" / "chb01_03_eeg_rms.csv"
    if not csv_path.exists():
        print(f"Demo data not found: {csv_path}")
        print("Run docs/eeg_chbmit/edf_to_helix_signal.py to generate it.")
        return 1

    import pandas as pd
    from .pipeline.canonical import CanonicalRecord, OrderType
    from .pipeline.binned import materialize
    from .pipeline.surface import measure
    from .pipeline.feature import engineer
    from .domains import eeg

    SFREQ = 256
    SEIZURE_START_S = 2996
    SEIZURE_END_S   = 3036

    print("=" * 60)
    print("SignalForge — EEG Seizure Detection Demo")
    print("=" * 60)
    print(f"Dataset  : CHB-MIT chb01_03  ({SFREQ} Hz, 1 hour, 23 channels)")
    print(f"Signal   : RMS across all channels → scalar time series")
    print(f"Seizure  : {SEIZURE_START_S}–{SEIZURE_END_S} s  (ground truth annotation)")
    print(f"Method   : unsupervised p-adic multiscale z-score")
    print(f"Training : none")
    print()

    df = pd.read_csv(csv_path)
    t_secs = df["t_sec"].to_numpy(dtype=np.float64)
    rms    = df["eeg_rms"].to_numpy(dtype=np.float64)
    sample_indices = np.round(t_secs * SFREQ).astype(np.int64)

    t0 = time.perf_counter()
    records = [
        CanonicalRecord(
            primary_order=int(si),
            order_type=OrderType.SEQUENCE,
            channel="eeg", metric="rms", value=float(v),
            seq_order=int(si),
        )
        for si, v in zip(sample_indices, rms)
    ]
    plan    = eeg.sampling_plan()
    binned  = materialize(records, plan, agg_funcs={"eeg": {"rms": "mean"}})
    surfaces = measure(binned, plan, profile="continuous")
    tensors  = [engineer(s, plan) for s in surfaces]
    elapsed = time.perf_counter() - t0

    ft = tensors[0]
    windows_s = tuple(w // SFREQ for w in plan.windows)
    time_axis = np.array(ft.time_axis)

    seiz_bin_start = (SEIZURE_START_S * SFREQ) // plan.cbin
    seiz_bin_end   = (SEIZURE_END_S   * SFREQ) // plan.cbin
    t_start = int(np.searchsorted(time_axis, seiz_bin_start))
    t_end   = int(np.searchsorted(time_axis, seiz_bin_end))

    zscore_mat = ft.values["mean_zscore"]

    print(f"{'Scale':>8}   {'z_max':>7}   {'z_mean':>7}   {'signal'}")
    print("-" * 50)
    for si, ws in enumerate(windows_s):
        row = zscore_mat[si, t_start:t_end]
        valid = row[np.isfinite(row)]
        if len(valid) == 0:
            continue
        zmax  = valid.max()
        zmean = valid.mean()
        bar   = "█" * min(int(abs(zmax)), 20) if zmax > 0 else "░" * min(int(abs(zmax)), 20)
        sign  = "+" if zmax > 0 else "-"
        print(f"{ws:>6}s   {zmax:>7.2f}   {zmean:>7.2f}   {sign}{bar}")

    peak_z  = zscore_mat[:, t_start:t_end]
    valid   = peak_z[np.isfinite(peak_z)]
    overall = valid.max() if len(valid) > 0 else float("nan")

    print()
    print(f"Peak z-score in seizure window : {overall:.2f} σ")
    print(f"Pipeline time                  : {elapsed:.1f} s")
    print(f"Surface shape                  : {surfaces[0].shape}  (scales × time bins)")
    print(f"Feature tensor shape           : {ft.shape}  (scales × time bins)")
    print(f"Features computed              : {len(ft.feature_names)}")
    return 0


# ---------------------------------------------------------------------------
# run
# ---------------------------------------------------------------------------

def cmd_run(args: argparse.Namespace) -> int:
    """Run the pipeline on a CSV file."""
    domain = args.domain.lower()
    csv_path = Path(args.csv)

    if not csv_path.exists():
        print(f"File not found: {csv_path}")
        return 1

    script = EXAMPLES / f"run_{domain}.py"
    if not script.exists():
        print(f"No run script for domain {domain!r}. Available: intermagnet, eeg, equities, timeseries")
        return 1

    import runpy
    import sys as _sys
    _sys.argv = [str(script), "--csv", str(csv_path)]
    if args.out:
        _sys.argv += ["--out", args.out]
    runpy.run_path(str(script), run_name="__main__")
    return 0


# ---------------------------------------------------------------------------
# plan
# ---------------------------------------------------------------------------

def cmd_plan(args: argparse.Namespace) -> int:
    """Show a SamplingPlan for a domain."""
    domain = args.domain.lower()

    try:
        if domain == "intermagnet":
            from .domains import intermagnet
            plan = intermagnet.sampling_plan()
        elif domain == "intermagnet-yearly":
            from .domains import intermagnet
            plan = intermagnet.sampling_plan_yearly()
        elif domain == "eeg":
            from .domains import eeg
            plan = eeg.sampling_plan()
        elif domain == "equities":
            from .domains import equities
            plan = equities.sampling_plan()
        elif domain == "equities-daily":
            from .domains import equities
            plan = equities.sampling_plan_daily()
        elif domain == "timeseries":
            from .domains import timeseries
            plan = timeseries.sampling_plan()
        else:
            print(f"Unknown domain {domain!r}.")
            print("Available: intermagnet, intermagnet-yearly, eeg, equities, equities-daily, timeseries")
            return 1
    except Exception as e:
        print(f"Error: {e}")
        return 1

    print(f"SamplingPlan  — {domain}")
    print(f"  horizon       : {plan.horizon:,} ({plan.horizon // plan.cbin} bins)")
    print(f"  grain         : {plan.grain}")
    print(f"  cbin          : {plan.cbin}")
    print(f"  prime_basis   : {plan.prime_basis}")
    print(f"  n_windows     : {len(plan.windows)}")
    print()
    print(f"  {'window':>12}   {'hop':>8}   {'n_values':>8}   coordinate")
    print(f"  {'-'*12}   {'-'*8}   {'-'*8}   ----------")
    for w, h, nv, coord in zip(plan.windows, plan.hops, plan.n_values, plan.coordinates):
        print(f"  {w:>12,}   {h:>8,}   {nv:>8,}   {coord}")
    return 0


# ---------------------------------------------------------------------------
# neighborhood
# ---------------------------------------------------------------------------

def cmd_neighborhood(args: argparse.Namespace) -> int:
    """Show the p-adic arithmetic viewing box."""
    from .lattice import neighborhood as nb_fn

    anchor = args.anchor
    radius = args.radius
    basis  = args.basis  # may be None

    try:
        nb = nb_fn(anchor, radius, basis=basis)
    except Exception as e:
        print(f"Error: {e}")
        return 1

    print(f"Neighborhood(anchor={anchor}, radius={radius})")
    print(f"  integers : {nb.integers[0]} .. {nb.integers[-1]}  ({len(nb.integers)} values)")
    print(f"  primes   : {nb.prime_basis}")
    print()
    nb.show()
    return 0


# ---------------------------------------------------------------------------
# load
# ---------------------------------------------------------------------------

def _auto_ingest(csv_path: Path) -> list:
    """Auto-detect CSV format and ingest into CanonicalRecords."""
    import pandas as pd
    from .pipeline.canonical import CanonicalRecord, OrderType

    df = pd.read_csv(csv_path)
    cols = list(df.columns)

    # Two-column CSV: treat as generic timeseries
    if len(cols) == 2:
        date_col, value_col = cols
        df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
        df = df.dropna(subset=[value_col])
        return [
            CanonicalRecord(
                primary_order=i,
                order_type=OrderType.SEQUENCE,
                channel="value",
                metric="value",
                value=float(row[value_col]),
                seq_order=i,
            )
            for i, row in df.iterrows()
        ]

    # Multi-column: look for known patterns
    lower = {c.lower(): c for c in cols}

    # timestamp + ticker + metric + value (equities format)
    if all(k in lower for k in ("timestamp", "ticker", "metric", "value")):
        from .domains import equities
        return equities.ingest(str(csv_path))

    # timestamp + station + component + value (intermagnet format)
    if all(k in lower for k in ("timestamp", "station", "component", "value")):
        from .domains import intermagnet
        return intermagnet.ingest(str(csv_path))

    # t_sec + eeg_rms (EEG format)
    if all(k in lower for k in ("t_sec", "eeg_rms")):
        from .domains import eeg
        return eeg.ingest(str(csv_path))

    # Fallback: use first column as index, second as value
    if len(cols) >= 2:
        value_col = cols[1]
        df[value_col] = pd.to_numeric(df[value_col], errors="coerce")
        df = df.dropna(subset=[value_col])
        return [
            CanonicalRecord(
                primary_order=i,
                order_type=OrderType.SEQUENCE,
                channel=value_col,
                metric="value",
                value=float(row[value_col]),
                seq_order=i,
            )
            for i, row in df.iterrows()
        ]

    print(f"Cannot auto-detect format for {csv_path.name}")
    return []


def cmd_load(args: argparse.Namespace) -> int:
    """Show a summary of a CSV file."""
    csv_path = Path(args.csv)
    if not csv_path.exists():
        print(f"File not found: {csv_path}")
        return 1

    import pandas as pd

    t0 = time.perf_counter()
    records = _auto_ingest(csv_path)
    elapsed = time.perf_counter() - t0

    if not records:
        return 1

    channels = sorted({r.channel for r in records})
    keys_all = set()
    for r in records:
        if hasattr(r, 'keys') and r.keys:
            keys_all.update(r.keys.keys())

    orders = [r.primary_order for r in records]
    min_o, max_o = min(orders), max(orders)

    # Estimate grain
    from .lattice.sampling import grain_from_orders
    grain = grain_from_orders(orders)

    print(f"  file      : {csv_path.name}")
    print(f"  records   : {len(records):,}")
    print(f"  channels  : {channels}")
    if keys_all:
        print(f"  keys      : {sorted(keys_all)}")
    print(f"  range     : {min_o:,} → {max_o:,}  (span: {max_o - min_o:,})")
    print(f"  est grain : {grain}")
    print(f"  ({elapsed:.2f}s)")
    return 0


# ---------------------------------------------------------------------------
# surface
# ---------------------------------------------------------------------------

def cmd_surface(args: argparse.Namespace) -> int:
    """Load CSV, build surface, show anomaly summary. Optional heatmap."""
    # Resolve CSV path: explicit arg > workspace config
    csv_arg = getattr(args, "csv", None)
    ws = _find_workspace()
    ws_config = _load_workspace(ws) if ws else {}

    if csv_arg:
        csv_path = Path(csv_arg)
    elif "csv" in ws_config:
        csv_path = Path(ws_config["csv"])
    else:
        print("  No CSV specified and no workspace found.")
        print("  Usage: sf surface <csv> or cd into a workspace.")
        return 1

    if not csv_path.exists():
        print(f"File not found: {csv_path}")
        return 1

    # Inherit workspace defaults if not overridden on CLI
    if args.max_window is None and "max_window" in ws_config:
        args.max_window = ws_config["max_window"]
    if args.grain is None and "grain" in ws_config:
        args.grain = ws_config["grain"]

    t_total = time.perf_counter()

    # Ingest
    t0 = time.perf_counter()
    records = _auto_ingest(csv_path)
    if not records:
        return 1
    t_ingest = time.perf_counter() - t0

    # Zoom — slice records by index or date
    zoom_label = ""
    if args.start_date or args.end_date:
        import pandas as pd
        df = pd.read_csv(csv_path)
        dates = pd.to_datetime(df[df.columns[0]], errors="coerce")
        value_col = df.columns[1] if len(df.columns) == 2 else None
        if value_col:
            mask = pd.to_numeric(df[value_col], errors="coerce").notna()
            dates = dates[mask].reset_index(drop=True)

        start_idx = 0
        end_idx = len(records)
        if args.start_date:
            sd = pd.Timestamp(args.start_date)
            start_idx = int((dates >= sd).idxmax()) if (dates >= sd).any() else 0
        if args.end_date:
            ed = pd.Timestamp(args.end_date)
            end_idx = int((dates <= ed)[::-1].idxmax()) + 1 if (dates <= ed).any() else len(records)

        records = records[start_idx:end_idx]
        # Re-index primary_order from 0
        for i, r in enumerate(records):
            r.primary_order = i
            if hasattr(r, 'seq_order') and r.seq_order is not None:
                r.seq_order = i
        zoom_label = f"  zoom      : {args.start_date or 'start'} → {args.end_date or 'end'} ({len(records):,} records)"
    elif args.start is not None or args.end is not None:
        s = args.start or 0
        e = args.end or len(records)
        records = records[s:e]
        for i, r in enumerate(records):
            r.primary_order = i
            if hasattr(r, 'seq_order') and r.seq_order is not None:
                r.seq_order = i
        zoom_label = f"  zoom      : bin {s} → {e} ({len(records):,} records)"

    channels = sorted({r.channel for r in records})
    print(f"  file      : {csv_path.name}")
    print(f"  records   : {len(records):,}  channels={channels}  ({t_ingest:.2f}s)")
    if zoom_label:
        print(zoom_label)

    # Build graph
    from .graph import Input, Bin, Measure, Baseline, Residual, Pipeline

    x = Input()
    agg = {ch: {"value": "mean"} for ch in channels}
    b = Bin(agg_funcs=agg)(x)
    m = Measure(profile="continuous")(b)

    # Default output is the measured surface
    output = m

    # Apply baseline and/or residual if requested
    if args.baseline:
        bl_kwargs = {"method": args.baseline}
        if args.baseline == "ewma":
            bl_kwargs["alpha"] = args.alpha
        else:
            bl_kwargs["window"] = args.window
        bl = Baseline(**bl_kwargs)(m)

        if args.residual:
            output = Residual(mode=args.residual)(m, bl)
        else:
            output = bl
    elif args.residual:
        print("  --residual requires --baseline")
        return 1

    pipe = Pipeline(x, output)

    # Resolve — derive horizon from max_window if given
    resolve_kwargs = {}
    if args.max_window:
        resolve_kwargs["windows"] = [args.max_window]
    if args.grain:
        resolve_kwargs["grain"] = args.grain

    pipe.resolve(records=records, **resolve_kwargs)
    plan = pipe.plan

    print(f"  horizon   : {plan.horizon:,}  grain={plan.grain}  cbin={plan.cbin}")
    print(f"  windows   : {plan.windows}")
    print(f"  basis     : {plan.prime_basis}")

    # Build
    t0 = time.perf_counter()
    result = pipe.build(records)
    surfaces = result.value
    t_build = time.perf_counter() - t0

    print(f"  surfaces  : {len(surfaces)}  ({t_build:.2f}s)")
    for s in surfaces:
        finite = np.isfinite(list(s.values.values())[0])
        print(f"    {s.channel:12s}  shape={s.shape}  coverage={finite.mean():.1%}")

    # Anomaly summary
    # Pick the first available value array from the surface
    print()
    label = "peak |z| per scale"
    if args.baseline and args.residual:
        label = f"{args.residual} residual vs {args.baseline} baseline"
    elif args.baseline:
        label = f"{args.baseline} baseline"
    print(f"  Anomaly summary ({label}):")
    for s in surfaces:
        # Use "mean" if available, else first value array
        arr = s.values.get("mean")
        if arr is None:
            arr = next(iter(s.values.values()), None)
        if arr is None:
            continue
        print(f"    {s.channel}")
        scale_peaks = []
        for i, w in enumerate(plan.windows):
            row = arr[i]
            finite = row[np.isfinite(row)]
            if len(finite) == 0:
                continue
            mu = np.mean(finite)
            sigma = np.std(finite)
            if sigma == 0:
                continue
            z = (finite - mu) / sigma
            peak_idx = int(np.argmax(np.abs(z)))
            peak = float(np.max(np.abs(z)))
            scale_peaks.append((peak, w, peak_idx))
        scale_peaks.sort(reverse=True)
        for peak, w, idx in scale_peaks[:8]:
            bar = "█" * min(int(peak), 30)
            print(f"      scale={w:>6}  peak |z| = {peak:>6.2f}σ  {bar}")

    total = time.perf_counter() - t_total
    print(f"\n  total: {total:.2f}s")

    # Heatmap
    if args.hm or args.save:
        # Try to read dates from the CSV for the time axis
        import pandas as pd
        df = pd.read_csv(csv_path)
        date_col = df.columns[0]
        dates = None
        try:
            dates = pd.to_datetime(df[date_col])
            value_col = df.columns[1] if len(df.columns) == 2 else None
            if value_col:
                mask = pd.to_numeric(df[value_col], errors="coerce").notna()
                dates = dates[mask].reset_index(drop=True)
            # Apply same zoom slice to dates
            if args.start_date or args.end_date:
                start_idx = 0
                end_idx = len(dates)
                if args.start_date:
                    sd = pd.Timestamp(args.start_date)
                    start_idx = int((dates >= sd).idxmax()) if (dates >= sd).any() else 0
                if args.end_date:
                    ed = pd.Timestamp(args.end_date)
                    end_idx = int((dates <= ed)[::-1].idxmax()) + 1 if (dates <= ed).any() else len(dates)
                dates = dates.iloc[start_idx:end_idx].reset_index(drop=True)
            elif args.start is not None or args.end is not None:
                s = args.start or 0
                e = args.end or len(dates)
                dates = dates.iloc[s:e].reset_index(drop=True)
        except Exception:
            pass

        subtitle = ""
        if args.baseline and args.residual:
            subtitle = f"{args.residual} residual vs {args.baseline}"
        elif args.baseline:
            subtitle = f"baseline: {args.baseline}"

        _render_heatmap(surfaces, plan, csv_path.name, dates,
                        subtitle=subtitle, save_path=args.save)

    return 0


def _render_heatmap(surfaces: list, plan, filename: str = "", dates=None,
                    subtitle: str = "", save_path: str = None) -> None:
    """Render a z-score heatmap of the mean surface for each channel."""
    import matplotlib
    if save_path:
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates

    for s in surfaces:
        # Use "mean" if available, else first value array
        arr = s.values.get("mean")
        if arr is None:
            arr = next(iter(s.values.values()), None)
        if arr is None:
            continue

        fig, ax = plt.subplots(figsize=(14, 6))
        finite_arr = np.where(np.isfinite(arr), arr, np.nan)

        # Compute z-scores per scale
        z = np.full_like(finite_arr, np.nan)
        for i in range(finite_arr.shape[0]):
            row = finite_arr[i]
            valid = row[np.isfinite(row)]
            if len(valid) > 0 and np.std(valid) > 0:
                z[i] = (row - np.nanmean(row)) / np.nanstd(row)

        n_scales, n_time = z.shape

        # Time axis: use dates if available (allow partial coverage)
        if dates is not None and len(dates) > 0:
            last_idx = min(len(dates) - 1, n_time - 1)
            extent = [
                mdates.date2num(dates.iloc[0]),
                mdates.date2num(dates.iloc[last_idx]),
                -0.5,
                n_scales - 0.5,
            ]
            im = ax.imshow(
                z,
                aspect="auto",
                interpolation="nearest",
                cmap="RdBu_r",
                vmin=-4, vmax=4,
                origin="lower",
                extent=extent,
            )
            ax.xaxis_date()
            ax.xaxis.set_major_locator(mdates.AutoDateLocator())
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
            fig.autofmt_xdate(rotation=45)
        else:
            im = ax.imshow(
                z,
                aspect="auto",
                interpolation="nearest",
                cmap="RdBu_r",
                vmin=-4, vmax=4,
                origin="lower",
            )
            ax.set_xlabel("Time (bins)")

        ax.set_ylabel("Window scale")
        ax.set_yticks(range(n_scales))
        ax.set_yticklabels([str(w) for w in plan.windows], fontsize=7)

        title = f"SignalForge — {s.channel}"
        if filename:
            title += f"  ({filename})"
        if subtitle:
            title += f"\n{subtitle}"
        ax.set_title(title, fontsize=13, fontweight="bold")

        cbar = fig.colorbar(im, ax=ax, shrink=0.8)
        cbar.set_label(
            "z-score (σ)\nDeviation of windowed mean from scale baseline",
            fontsize=9,
        )

        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150)
            print(f"  Saved: {save_path}")
        else:
            plt.show()


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# workspace (sf init)
# ---------------------------------------------------------------------------

_SF_CONFIG = "sf.json"


def _find_workspace() -> Path | None:
    """Walk up from cwd looking for sf.json."""
    p = Path.cwd()
    for _ in range(10):
        if (p / _SF_CONFIG).exists():
            return p
        if p.parent == p:
            break
        p = p.parent
    return None


def _load_workspace(ws: Path) -> dict:
    import json
    with open(ws / _SF_CONFIG) as f:
        return json.load(f)


def _save_workspace(ws: Path, config: dict) -> None:
    import json
    with open(ws / _SF_CONFIG, "w") as f:
        json.dump(config, f, indent=2)
    print(f"  config: {ws / _SF_CONFIG}")


def cmd_init(args: argparse.Namespace) -> int:
    """Initialize a workspace directory."""
    import json

    ws = Path(args.name)
    csv_path = Path(args.csv) if args.csv else None

    if ws.exists() and (ws / _SF_CONFIG).exists():
        print(f"  Workspace already exists: {ws}")
        return 1

    ws.mkdir(parents=True, exist_ok=True)
    (ws / "cache").mkdir(exist_ok=True)
    (ws / "output").mkdir(exist_ok=True)

    config = {
        "version": 1,
        "name": args.name,
    }

    if csv_path:
        if not csv_path.exists():
            print(f"  File not found: {csv_path}")
            return 1
        config["csv"] = str(csv_path.resolve())

        # Auto-detect and summarize
        records = _auto_ingest(csv_path)
        if records:
            channels = sorted({r.channel for r in records})
            from .lattice.sampling import grain_from_orders
            orders = [r.primary_order for r in records]
            grain = grain_from_orders(orders)
            config["summary"] = {
                "records": len(records),
                "channels": channels,
                "estimated_grain": grain,
            }

    if args.max_window:
        config["max_window"] = args.max_window
    if args.grain:
        config["grain"] = args.grain

    _save_workspace(ws, config)

    print(f"  workspace : {ws}/")
    print(f"  cache     : {ws}/cache/")
    print(f"  output    : {ws}/output/")
    if csv_path:
        print(f"  data      : {config['csv']}")
        if "summary" in config:
            s = config["summary"]
            print(f"  records   : {s['records']:,}  channels={s['channels']}")
            print(f"  est grain : {s['estimated_grain']}")
    print()
    print(f"  cd {ws} && sf surface -hm")
    return 0


# ---------------------------------------------------------------------------
# inspect
# ---------------------------------------------------------------------------

_INSPECT_ENTRIES = {
    "ewma": {
        "name": "Exponentially Weighted Moving Average",
        "formula": "s_t = α · x_t + (1 - α) · s_{t-1}",
        "params": "α (alpha): smoothing factor in (0, 1]. Higher = more responsive.",
        "description": (
            "Tracks a drifting baseline by weighting recent values more heavily.\n"
            "  The effective memory is ~1/α observations. At α=0.1, the baseline\n"
            "  reflects roughly the last 10 points; at α=0.01, the last 100."
        ),
        "use_when": (
            "The underlying process has a slowly changing mean — trending markets,\n"
            "  gradual load shifts, seasonal drift. Not ideal for periodic baselines\n"
            "  (use periodic or median for those)."
        ),
        "cli": "sf surface data.csv -hm --baseline ewma --alpha 0.1",
    },
    "median": {
        "name": "Rolling Median Filter",
        "formula": "s_t = median(x_{t-w/2}, ..., x_{t+w/2})",
        "params": "window: number of observations in the centered window.",
        "description": (
            "Robust to spikes and outliers — a single extreme value doesn't move\n"
            "  the baseline. Produces a smooth estimate of the 'typical' value."
        ),
        "use_when": (
            "You expect sharp transient spikes that shouldn't contaminate the\n"
            "  baseline. Good for bursty event data, noisy sensors, or any signal\n"
            "  where outliers are common and the underlying level is stable."
        ),
        "cli": "sf surface data.csv -hm --baseline median --window 20",
    },
    "rolling_mean": {
        "name": "Rolling Mean",
        "formula": "s_t = mean(x_{t-w+1}, ..., x_t)",
        "params": "window: number of observations in the trailing window.",
        "description": (
            "Simple trailing average. Every point in the window contributes equally.\n"
            "  Responds to level shifts after ~window observations."
        ),
        "use_when": (
            "A straightforward smoothing baseline when you don't need outlier\n"
            "  robustness (use median) or exponential decay (use EWMA)."
        ),
        "cli": "sf surface data.csv -hm --baseline rolling_mean --window 20",
    },
    "difference": {
        "name": "Difference Residual",
        "formula": "r_t = x_t - baseline_t",
        "params": "None (applied via --residual difference)",
        "description": (
            "Absolute deviation from baseline. Preserves units.\n"
            "  A residual of 10 means 10 units above baseline."
        ),
        "use_when": (
            "The absolute magnitude of deviation matters — e.g., event counts\n"
            "  where '50 extra logins' is meaningful regardless of the base rate."
        ),
        "cli": "sf surface data.csv -hm --baseline ewma --residual difference",
    },
    "ratio": {
        "name": "Ratio Residual",
        "formula": "r_t = x_t / baseline_t",
        "params": "None (applied via --residual ratio)",
        "description": (
            "Multiplicative deviation. A ratio of 2.0 means double the baseline.\n"
            "  Scale-invariant: a 2x spike means the same whether the base is 10 or 10,000."
        ),
        "use_when": (
            "The proportional deviation matters more than absolute — common for\n"
            "  count data, throughput, or any metric where the baseline varies\n"
            "  across entities or time periods."
        ),
        "cli": "sf surface data.csv -hm --baseline ewma --residual ratio",
    },
    "z": {
        "name": "Z-Score Residual",
        "formula": "r_t = (x_t - baseline_t) / σ_baseline",
        "params": "None (applied via --residual z)",
        "description": (
            "Deviation normalized by the baseline's standard deviation.\n"
            "  Measures 'how unusual' relative to the baseline's own variability."
        ),
        "use_when": (
            "You want a unitless anomaly score that accounts for how variable\n"
            "  the signal normally is. A z of 3 means the same thing whether\n"
            "  the signal is VIX or Kerberos TGT counts."
        ),
        "cli": "sf surface data.csv -hm --baseline ewma --residual z",
    },
}


def cmd_inspect(args: argparse.Namespace) -> int:
    """Show documentation for a baseline or residual method."""
    name = args.name.lower()
    entry = _INSPECT_ENTRIES.get(name)

    if entry is None:
        print(f"Unknown: {name!r}")
        print(f"Available: {', '.join(sorted(_INSPECT_ENTRIES))}")
        return 1

    print(f"\n  {entry['name']}")
    print(f"  {'=' * len(entry['name'])}")
    print(f"\n  Formula:  {entry['formula']}")
    print(f"  Params:   {entry['params']}")
    print(f"\n  {entry['description']}")
    print(f"\n  Use when:")
    print(f"  {entry['use_when']}")
    print(f"\n  Example:")
    print(f"  {entry['cli']}")
    print()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="signalforge",
        description="SignalForge — p-adic multiscale signal processing pipeline",
    )
    sub = parser.add_subparsers(dest="command", metavar="command")
    sub.required = True

    # demo
    p_demo = sub.add_parser("demo", help="Run the EEG seizure detection demo")

    # run
    p_run = sub.add_parser("run", help="Run the pipeline on a CSV file")
    p_run.add_argument("domain", choices=["intermagnet", "eeg", "equities", "timeseries"],
                       help="Domain (determines SamplingPlan and ingest)")
    p_run.add_argument("csv", help="Input CSV file path")
    p_run.add_argument("--out", default=None, help="Output directory for CSV export")

    # plan
    p_plan = sub.add_parser("plan", help="Show a SamplingPlan for a domain")
    p_plan.add_argument("domain",
                        choices=["intermagnet", "intermagnet-yearly", "eeg", "equities", "equities-daily", "timeseries"],
                        help="Domain name")

    # init
    p_init = sub.add_parser("init", help="Initialize a workspace directory")
    p_init.add_argument("name", help="Workspace directory name")
    p_init.add_argument("--csv", default=None, help="Path to CSV data file")
    p_init.add_argument("--max-window", type=int, default=None,
                        help="Default max analysis window")
    p_init.add_argument("--grain", type=int, default=None, help="Default grain")

    # inspect
    p_insp = sub.add_parser("inspect", help="Show docs for a method or operator")
    p_insp.add_argument("name", help="Method name (e.g. ewma, median, ratio, z)")

    # load
    p_load = sub.add_parser("load", help="Show a summary of a CSV file")
    p_load.add_argument("csv", help="Input CSV file path")

    # surface
    p_surf = sub.add_parser("surface", help="Build and display a surface from a CSV")
    p_surf.add_argument("csv", nargs="?", default=None,
                        help="Input CSV file path (optional if in a workspace)")
    p_surf.add_argument("-hm", action="store_true", help="Render heatmap")
    p_surf.add_argument("--max-window", type=int, default=None,
                        help="Largest analysis window (horizon derived automatically)")
    p_surf.add_argument("--grain", type=int, default=None, help="Finest resolution")
    p_surf.add_argument("--baseline", default=None,
                        choices=["ewma", "median", "rolling_mean"],
                        help="Baseline method")
    p_surf.add_argument("--alpha", type=float, default=0.1,
                        help="EWMA smoothing factor (default: 0.1)")
    p_surf.add_argument("--window", type=int, default=20,
                        help="Baseline window size for median/rolling_mean (default: 20)")
    p_surf.add_argument("--residual", default=None,
                        choices=["difference", "ratio", "z"],
                        help="Residual mode (requires --baseline)")
    p_surf.add_argument("--start", type=int, default=None,
                        help="Start index (bin number) for zoom")
    p_surf.add_argument("--end", type=int, default=None,
                        help="End index (bin number) for zoom")
    p_surf.add_argument("--start-date", default=None,
                        help="Start date for zoom (e.g. 2008-01-01)")
    p_surf.add_argument("--end-date", default=None,
                        help="End date for zoom (e.g. 2009-12-31)")
    p_surf.add_argument("--save", default=None,
                        help="Save heatmap to file instead of displaying")

    # neighborhood
    p_nb = sub.add_parser("neighborhood", help="Show the p-adic arithmetic viewing box")
    p_nb.add_argument("anchor", type=int, help="Center integer")
    p_nb.add_argument("radius", type=int, nargs="?", default=6,
                      help="Half-width (default: 6)")
    p_nb.add_argument("--basis", type=int, nargs="+", default=None,
                      help="Explicit prime basis (default: auto)")

    args = parser.parse_args(argv)

    dispatch = {
        "demo":         cmd_demo,
        "run":          cmd_run,
        "plan":         cmd_plan,
        "init":         cmd_init,
        "inspect":      cmd_inspect,
        "load":         cmd_load,
        "surface":      cmd_surface,
        "neighborhood": cmd_neighborhood,
    }
    return dispatch[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
