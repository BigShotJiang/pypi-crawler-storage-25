"""LLM client — talks to Ollama via PastaWater broker or directly to a brain."""

import json
import os
import requests
from typing import Iterator


DEFAULT_API_URL = "https://pastawater.io"


class LLMClient:
    """Client that talks to Ollama via PastaWater broker API or direct brain connection."""

    def __init__(
        self,
        token: str = "",
        device_id: str = "",
        slot: int = 0,
        model: str = "",
        api_url: str = DEFAULT_API_URL,
        brain_url: str = "",
        brain_key: str = "",
    ):
        self.token = token
        self.device_id = device_id
        self.slot = slot
        self.model = model
        self.api_url = api_url.rstrip("/")
        self.brain_url = brain_url.rstrip("/") if brain_url else ""
        self.brain_key = brain_key
        self.direct_mode = bool(brain_url)

        self.session = requests.Session()
        self.session.headers["Content-Type"] = "application/json"
        self._active_response = None  # Track active streaming response for abort
        # Auth: PW token works for both cloud API and local brain proxy
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"
        if brain_key:
            self.session.headers["X-Controller-API-Key"] = brain_key

    def abort(self):
        """Abort the active streaming request."""
        if self._active_response:
            try:
                self._active_response.close()
            except Exception:
                pass
            self._active_response = None

    def chat(self, messages: list[dict], temperature: float = 0.3, context_length: int = 8192, thinking: bool = False) -> str:
        """Send messages and return the full response text."""
        chunks = []
        for chunk in self.chat_stream(messages, temperature, context_length, thinking=thinking):
            chunks.append(chunk)
        return "".join(chunks)

    def chat_stream(self, messages: list[dict], temperature: float = 0.3, context_length: int = 8192, thinking: bool = False) -> Iterator[str]:
        """Stream chat tokens from Ollama."""
        if self.direct_mode:
            yield from self._stream_direct(messages, temperature, context_length, thinking=thinking)
        else:
            yield from self._stream_broker(messages, temperature, context_length, thinking=thinking)

    def _stream_direct(self, messages: list[dict], temperature: float, context_length: int, thinking: bool = False) -> Iterator[str]:
        """Stream directly from brain's Ollama endpoint."""
        model_lower = self.model.lower()
        is_gemma = "gemma" in model_lower

        # Thinking-capable models (gemma4, qwen3 thinking variants) put
        # their reasoning in a separate `thinking` field. If we send
        # think:false to them, on complex prompts the whole answer can
        # end up suppressed and content comes back empty. Always opt
        # IN to thinking for these — we'll strip the thinking field
        # before showing the user unless --think is on.
        is_thinking_model = is_gemma or model_lower.startswith("qwen3.5")
        ask_for_thinking = thinking or is_thinking_model

        if thinking or is_gemma:
            # Thinking mode or Gemma: use /api/chat (Gemma doesn't work with raw mode)
            payload = {
                "model": self.model,
                "messages": messages,
                "stream": True,
                "think": ask_for_thinking,
                "options": {
                    "temperature": temperature,
                    "num_ctx": context_length,
                    "num_predict": 4096,
                },
            }
            endpoint = "/api/chat"
        else:
            # Qwen/DeepSeek: use /api/generate with raw ChatML to avoid
            # Ollama's tool-call parsing, thinking EOF, and empty function name bugs
            raw_prompt = self._flatten_messages(messages)
            payload = {
                "model": self.model,
                "prompt": raw_prompt,
                "raw": True,
                "stream": True,
                "options": {
                    "temperature": temperature,
                    "num_ctx": context_length,
                    "num_predict": 4096,
                },
            }
            endpoint = "/api/generate"

        try:
            resp = self.session.post(
                f"{self.brain_url}{endpoint}",
                json=payload,
                stream=True,
                timeout=300,
            )
        except requests.exceptions.ConnectionError:
            yield f"[Error: Could not connect to brain at {self.brain_url}]"
            return
        except requests.exceptions.Timeout:
            yield "[Error: Request timed out]"
            return

        if resp.status_code != 200:
            yield f"[Error: Brain returned {resp.status_code}]"
            return

        self._active_response = resp
        for line in resp.iter_lines():
            if not line:
                continue
            try:
                data = json.loads(line)
                # Check for thinking field
                if thinking:
                    thinking_text = data.get("message", {}).get("thinking", "")
                    if thinking_text:
                        yield f"[think]{thinking_text}[/think]"
                # /api/chat uses message.content, /api/generate uses response
                if "message" in data:
                    msg = data["message"]
                    content = msg.get("content", "")
                    # Native Ollama tool_calls — serialize into the
                    # <tool_call>{...}</tool_call> text format that the
                    # agent's parser knows about. Without this, gemma /
                    # qwen3 tool-call responses come through as empty
                    # content and pw-agent prints "Empty response".
                    tool_calls = msg.get("tool_calls") or []
                    if tool_calls and not content:
                        for tc in tool_calls:
                            fn = (tc or {}).get("function") or {}
                            name = fn.get("name", "")
                            args = fn.get("arguments", {})
                            if isinstance(args, str):
                                try:
                                    args = json.loads(args)
                                except Exception:
                                    args = {"_raw": args}
                            payload_text = json.dumps({"name": name, "arguments": args})
                            content = f"<tool_call>{payload_text}</tool_call>"
                else:
                    content = data.get("response", "")
                if content:
                    yield content
                if data.get("done"):
                    return
            except json.JSONDecodeError:
                continue

    def _flatten_messages(self, messages: list[dict]) -> str:
        """Flatten chat messages into a prompt string using the model's native template.

        Different model families use different chat templates:
        - Qwen/DeepSeek: ChatML (<|im_start|>role\ncontent<|im_end|>)
        - Gemma: <start_of_turn>role\ncontent<end_of_turn>
        - Llama: [INST] content [/INST]
        """
        model_lower = self.model.lower()

        if "gemma" in model_lower:
            # Gemma format
            parts = []
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                # Gemma uses "user" and "model" (not "assistant")
                gemma_role = "model" if role == "assistant" else role
                if role == "system":
                    # Gemma has no system role — prepend to first user message
                    parts.append(f"<start_of_turn>user\n{content}<end_of_turn>")
                else:
                    parts.append(f"<start_of_turn>{gemma_role}\n{content}<end_of_turn>")
            parts.append("<start_of_turn>model\n")
            return "\n".join(parts)
        else:
            # ChatML format (Qwen, DeepSeek, most Ollama models)
            parts = []
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                parts.append(f"<|im_start|>{role}\n{content}<|im_end|>")
            parts.append("<|im_start|>assistant\n")
            return "\n".join(parts)

    def _stream_broker(self, messages: list[dict], temperature: float, context_length: int, thinking: bool = False) -> Iterator[str]:
        """Submit task asynchronously and poll for completion to avoid EOF/timeouts."""
        import time

        payload = {
            "model": "llm-chat",
            "slot": self.slot,
            "messages": messages,
            "llm_model": self.model,
            "temperature": temperature,
            "max_tokens": 4096,
            "context_length": context_length,
            "thinking": thinking,
        }

        # 1. Submit the task asynchronously (with retry on transient errors)
        task_id = None
        max_retries = 3
        for attempt in range(max_retries):
            try:
                resp = self.session.post(
                    f"{self.api_url}/api/v1/playground/generate/async",
                    json=payload,
                    timeout=30,
                )
                if resp.status_code in (200, 202):
                    data = resp.json()
                    if data.get("success"):
                        task_id = data.get("task_id")
                        break
                    err = data.get("error", "")
                    # Retryable: slot resolution failures, device offline
                    if attempt < max_retries - 1 and ("resolve device" in err or "offline" in err):
                        time.sleep(2 * (attempt + 1))
                        continue
                    yield f"[Error: {err}]"
                    return
                elif resp.status_code in (502, 503, 504):
                    # Gateway errors — retry
                    if attempt < max_retries - 1:
                        time.sleep(2 * (attempt + 1))
                        continue
                    yield f"[Error: API returned {resp.status_code} after {max_retries} retries]"
                    return
                else:
                    yield f"[Error: API returned {resp.status_code}: {resp.text[:200]}]"
                    return
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
                if attempt < max_retries - 1:
                    time.sleep(2 * (attempt + 1))
                    continue
                yield f"[Error: Connection failed after {max_retries} retries]"
                return
            except Exception as e:
                yield f"[Error: {str(e)}]"
                return

        if not task_id:
            yield "[Error: No task_id returned from broker]"
            return

        # 2. Poll for result
        # Most LLM tasks take 5-60s. We'll poll every 1-2s.
        max_wait = 300 # 5 minutes
        start_time = time.time()

        # Add a subtle indicator that we are polling
        import sys

        while time.time() - start_time < max_wait:
            try:
                # Use a fresh request for polling to avoid session stickiness issues
                poll_resp = self.session.get(
                    f"{self.api_url}/api/v1/playground/tasks/{task_id}",
                    timeout=10
                )
                if poll_resp.status_code == 200:
                    poll_data = poll_resp.json()
                    status = poll_data.get("status")

                    if status == "completed":
                        result = poll_data.get("result", {})
                        # Yield thinking content first (if present)
                        thinking_text = result.get("thinking", "")
                        if thinking_text:
                            yield f"[think]{thinking_text}[/think]"
                        text = result.get("text", "") or result.get("response", "") or ""
                        if not text and os.environ.get("PW_DEBUG"):
                            import sys
                            sys.stderr.write(f"DEBUG poll result: {str(result)[:300]}\n")
                        yield text
                        return

                    if status == "failed":
                        err = poll_data.get("error", "Generation failed")
                        if os.environ.get("PW_DEBUG"):
                            import sys
                            sys.stderr.write(f"DEBUG task failed: {err}\n")
                            sys.stderr.write(f"DEBUG full: {str(poll_data)[:500]}\n")
                        yield f"[Error: {err}]"
                        return

                elif poll_resp.status_code != 404: 
                    # If we get a 500 or other error during polling, report it
                    try:
                        err_data = poll_resp.json()
                        err_msg = err_data.get("error", f"Status {poll_resp.status_code}")
                    except:
                        err_msg = f"Status {poll_resp.status_code}"
                    yield f"[Error: Polling failed: {err_msg}]"
                    return

            except Exception:
                pass # Continue polling on transient network errors

            time.sleep(1.5)

        yield "[Error: Task timed out after 5 minutes]"

    def list_devices(self) -> list:
        """List online GPU devices with running LLM."""
        if self.direct_mode:
            return [{"slot": 0, "device_id": "local", "device_name": "local", "gpu": "direct", "llm_model": self.model}]

        try:
            resp = self.session.get(f"{self.api_url}/api/user/byog/slots", timeout=15)
            if resp.status_code != 200:
                return []
            data = resp.json()
            if not data.get("success"):
                return []

            devices = []
            for s in data.get("slots", []):
                if not s.get("online"):
                    continue
                running = s.get("running_services", [])
                if "llm" in running:
                    devices.append({
                        "slot": s.get("slot_number"),
                        "device_id": s.get("device_id", ""),
                        "device_name": s.get("device_name", "Unknown"),
                        "gpu": s.get("gpu_info", {}).get("name", "Unknown"),
                        "vram_gb": round(s.get("gpu_info", {}).get("memory_total_mb", 0) / 1024, 1),
                        "llm_model": s.get("llm_current_model") or "ollama",
                    })
            return devices
        except Exception:
            return []

    def test_connection(self) -> tuple[bool, str]:
        """Test connectivity and return (ok, message)."""
        if self.direct_mode:
            try:
                resp = self.session.get(f"{self.brain_url}/api/tags", timeout=10)
                if resp.status_code != 200:
                    return False, f"Brain returned {resp.status_code}"
                data = resp.json()
                models = [m["name"] for m in data.get("models", [])]
                if self.model and self.model not in models:
                    available = ", ".join(models[:5]) or "none"
                    return False, f"Model '{self.model}' not found. Available: {available}"
                return True, f"Connected to brain at {self.brain_url} ({self.model})"
            except requests.exceptions.ConnectionError:
                return False, f"Could not connect to {self.brain_url}"
            except Exception as e:
                return False, str(e)

        # Cloud mode — find our slot
        try:
            resp = self.session.get(f"{self.api_url}/api/user/byog/slots", timeout=15)
            if resp.status_code == 401:
                return False, "Invalid API token"
            if resp.status_code != 200:
                return False, f"API error: {resp.status_code}"

            data = resp.json()
            if not data.get("success"):
                return False, data.get("error", "API error")

            for s in data.get("slots", []):
                if s.get("slot_number") == self.slot:
                    if not s.get("online"):
                        return False, f"Slot {self.slot} is offline"
                    if "llm" not in s.get("running_services", []):
                        return False, f"Slot {self.slot} has no LLM running"
                    gpu = s.get("gpu_info", {}).get("name", "unknown")
                    model = s.get("llm_current_model") or self.model or "ollama"
                    return True, f"Connected to {model} on {gpu} (slot {self.slot})"

            return False, f"Slot {self.slot} not found"
        except requests.exceptions.ConnectionError:
            return False, f"Could not connect to {self.api_url}"
        except Exception as e:
            return False, str(e)
