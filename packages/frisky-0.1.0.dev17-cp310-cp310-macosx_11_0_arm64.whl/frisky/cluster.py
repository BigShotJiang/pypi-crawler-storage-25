"""Python Cluster class supporting both in-process and subprocess workers."""
import multiprocessing
import os
import sys


def _is_interactive():
    """Detect if running in IPython/Jupyter."""
    if "IPython" not in sys.modules:
        return False
    try:
        from IPython import get_ipython
        return get_ipython() is not None
    except Exception:
        return False


def _get_total_memory():
    """Get total system memory in bytes."""
    try:
        return os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')
    except (ValueError, AttributeError):
        # Fallback for systems without sysconf
        return None


def _worker_process(scheduler_addr, addr_queue, nthreads=1, memory_limit=None, env_vars=None):
    """Run a worker in a subprocess."""
    import signal
    from frisky import Worker, enable_tracing

    # TODO: Remove once dask fixes circular import issues in dask.array
    # Pre-import dask.array to avoid "partially initialized module" errors
    # when multiple threads unpickle tasks that trigger dask imports concurrently.
    # See: https://github.com/dask/dask/issues/XXXX
    try:
        import dask.array
    except ImportError:
        pass

    # Restore environment variables (needed for 'spawn' start method)
    if env_vars:
        for key, value in env_vars.items():
            os.environ[key] = value

    # Ignore SIGINT in worker processes - parent handles shutdown
    signal.signal(signal.SIGINT, signal.SIG_IGN)

    # Enable tracing for span collection via REST API
    # Capacity passed from main process via FRISKY_TRACING_CAPACITY env var
    tracing_capacity = int(os.environ.get('FRISKY_TRACING_CAPACITY', '1000000'))
    enable_tracing(tracing_capacity)

    worker = Worker(scheduler_addr, nthreads=nthreads, memory_limit=memory_limit)
    addr_queue.put(worker.address)
    worker.wait_closed()


class Cluster:
    """A cluster of workers connected to a scheduler.

    Args:
        n_workers: Number of workers to create.
        threads_per_worker: Threads per worker.
        processes: If True, spawn workers in separate processes (TCP transport).
                   If False, use in-process workers (channel transport by default).
        transport: 'auto', 'channel', or 'tcp'. Default 'auto' uses channel for
                   in-process workers and TCP for subprocess workers.
        memory_limit: Memory limit per worker in bytes. If None (default), uses
                      system total memory divided by n_workers.
        dashboard_address: Address for dashboard server (e.g. "127.0.0.1:8787").
                          Use "127.0.0.1:0" for random port. Only applies to TCP mode.
        silence_summary: If True, disable periodic summary output. If None (default),
                        auto-detect: silence in IPython/Jupyter, show in scripts.
        compress_chunk_kb: Chunk size in KB for parallel compression. Default 128KB.
                          Larger values (e.g. 4096) may help with many workers.

    Examples:
        # In-process workers (channel transport, shared GIL)
        cluster = Cluster(n_workers=4)

        # Subprocess workers (TCP transport, no GIL contention)
        cluster = Cluster(n_workers=4, processes=True)

        # In-process workers with TCP transport (for debugging/metrics)
        cluster = Cluster(n_workers=4, transport='tcp')

        # With explicit memory limit (1GB per worker)
        cluster = Cluster(n_workers=2, memory_limit=1024**3)
    """

    def __init__(self, n_workers=4, threads_per_worker=1, processes=False, transport='auto', memory_limit=None, dashboard_address=None, silence_summary=None, compress_chunk_kb=None):
        from frisky.frisky import Scheduler, Worker

        # Silence summary output if requested or in interactive mode
        if silence_summary is None:
            silence_summary = _is_interactive()
        if silence_summary and 'FRISKY_SUMMARY' not in os.environ:
            os.environ['FRISKY_SUMMARY'] = 'off'

        # Set compression chunk size if specified
        if compress_chunk_kb is not None:
            os.environ['FRISKY_COMPRESS_CHUNK_KB'] = str(compress_chunk_kb)

        self.n_workers = n_workers
        self.processes = processes
        self._workers = []
        self._subprocess_handles = []
        self._worker_addresses = []  # Track worker addresses for graceful shutdown

        # Determine transport: 'auto' chooses based on processes flag
        if transport == 'auto':
            use_tcp = processes
        elif transport == 'tcp':
            use_tcp = True
        elif transport == 'channel':
            use_tcp = False
            if processes:
                raise ValueError("Cannot use channel transport with subprocess workers")
        else:
            raise ValueError(f"Unknown transport: {transport}. Use 'auto', 'tcp', or 'channel'.")

        # Use explicit memory limit if provided, otherwise calculate from system memory
        if memory_limit is None:
            total_memory = _get_total_memory()
            memory_limit = total_memory // n_workers if total_memory else None

        if processes:
            # Subprocess workers (always TCP)
            self._scheduler = Scheduler("127.0.0.1:0", dashboard_address=dashboard_address)

            # Capture environment variables to pass to workers
            # (needed for 'spawn' start method on macOS)
            env_vars = {k: v for k, v in os.environ.items()
                        if k.startswith(('RUST_LOG', 'FRISKY_'))}

            # Start all worker processes in parallel
            queues = []
            for i in range(n_workers):
                addr_queue = multiprocessing.Queue()
                p = multiprocessing.Process(
                    target=_worker_process,
                    args=(self._scheduler.address, addr_queue, threads_per_worker, memory_limit, env_vars)
                )
                p.start()
                self._subprocess_handles.append(p)
                queues.append(addr_queue)

            # Collect addresses from all workers
            for addr_queue in queues:
                worker_addr = addr_queue.get(timeout=10)
                self._worker_addresses.append(worker_addr)
        elif use_tcp:
            # In-process workers with TCP transport
            self._scheduler = Scheduler("127.0.0.1:0", dashboard_address=dashboard_address)
            for _ in range(n_workers):
                worker = Worker(self._scheduler.address, nthreads=threads_per_worker, memory_limit=memory_limit)
                self._workers.append(worker)
                self._worker_addresses.append(worker.address)
        else:
            # In-process workers with channel transport
            # Enable dashboard for tracing/monitoring even without TCP
            self._scheduler = Scheduler(dashboard=True, dashboard_address=dashboard_address)
            for _ in range(n_workers):
                worker = Worker(self._scheduler, nthreads=threads_per_worker, memory_limit=memory_limit)
                self._workers.append(worker)

    @property
    def scheduler(self):
        """Return the scheduler object."""
        return self._scheduler

    @property
    def dashboard_address(self):
        """Return the dashboard URL (if dashboard is enabled)."""
        return self._scheduler.dashboard_address

    @property
    def workers(self):
        """Return the list of workers (only available for in-process mode)."""
        return self._workers

    def close(self):
        """Close the cluster and all workers."""
        for worker in self._workers:
            worker.close()
        self._workers.clear()

        # Gracefully close TCP workers for clean shutdown
        # First check which workers are still alive
        live_workers = []
        for i, p in enumerate(self._subprocess_handles):
            if p.is_alive() and i < len(self._worker_addresses):
                live_workers.append(self._worker_addresses[i])

        if live_workers and self.processes:
            from frisky import Client
            try:
                with Client(self._scheduler) as client:
                    for addr in live_workers:
                        try:
                            client.close_worker(addr, "cluster-shutdown")
                        except Exception:
                            pass  # Worker may already be closed
            except Exception:
                pass  # Scheduler may already be closed
        self._worker_addresses.clear()

        for p in self._subprocess_handles:
            if not p.is_alive():
                # Already dead, just reap it immediately
                p.join(timeout=0)
                continue
            try:
                p.join(timeout=1)  # Brief wait for graceful shutdown
            except KeyboardInterrupt:
                pass  # User is impatient, proceed to terminate
            if p.is_alive():
                p.terminate()  # Force kill if still running
                try:
                    p.join(timeout=1)
                except KeyboardInterrupt:
                    pass
        self._subprocess_handles.clear()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
