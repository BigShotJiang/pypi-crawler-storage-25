"""HTTP client helpers for the scheduler dashboard REST API."""

import json
import urllib.error
import urllib.parse
import urllib.request


def _get_json(url: str, params: dict | None = None, timeout: int = 10) -> dict:
    """Fetch JSON from a dashboard URL.

    Args:
        url: Base URL (without query string)
        params: Optional query params dict; None values are omitted, string
            values are URL-encoded.
        timeout: Request timeout in seconds.

    Raises:
        urllib.error.HTTPError: For HTTP errors (404, 500, etc.).
        ConnectionError: For network errors (connection refused, timeout, DNS).
    """
    if params:
        params = {k: v for k, v in params.items() if v is not None}
        if params:
            url = f"{url}?{urllib.parse.urlencode(params)}"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError:
        raise
    except urllib.error.URLError as e:
        raise ConnectionError(f"Could not connect to {url}: {e}") from None


def query_spans(
    name: str | None = None,
    min_duration_ms: int | None = None,
    task: str | None = None,
    start_ns: int | None = None,
    end_ns: int | None = None,
    limit: int = 100,
    dashboard_url: str = "http://localhost:8787",
) -> list[dict]:
    """Query spans from the scheduler via REST API.

    Automatically paginates when limit exceeds the server's page size (100k).

    Args:
        name: Filter by span name prefix (e.g., "worker.exec", "spill")
        min_duration_ms: Minimum span duration in milliseconds
        task: Filter by task key
        start_ns: Only spans after this time (nanoseconds since epoch)
        end_ns: Only spans before this time (nanoseconds since epoch)
        limit: Maximum number of spans to return (default 100)
        dashboard_url: URL of the scheduler dashboard

    Returns:
        List of span dicts with keys: trace_id, span_id, parent_span_id,
        name, start_ns, end_ns, duration_ns, keys, worker
    """
    PAGE_SIZE = 100_000
    spans_url = f"{dashboard_url.rstrip('/')}/api/spans"
    all_spans: list[dict] = []
    # Paginate by time - server returns most recent spans first, so we
    # work backwards by setting end_ns to just before the oldest span we've seen
    current_end_ns = end_ns

    while len(all_spans) < limit:
        page_limit = min(PAGE_SIZE, limit - len(all_spans))
        data = _get_json(
            spans_url,
            params={
                "name": name,
                "min_duration_ms": min_duration_ms,
                "task": task,
                "start_ns": start_ns,
                "end_ns": current_end_ns,
                "limit": page_limit,
            },
            timeout=30,
        )
        spans = data.get("spans", [])
        if not spans:
            break

        all_spans.extend(spans)

        # Server returns most recent spans, so get the oldest (min start_ns) for next page
        min_start = min(s["start_ns"] for s in spans)
        if current_end_ns is not None and min_start >= current_end_ns:
            break  # No progress, avoid infinite loop
        current_end_ns = min_start - 1

    # Sort by start_ns (oldest first) since we collected backwards
    all_spans.sort(key=lambda s: s["start_ns"])
    return all_spans


def story(key: str, dashboard_url: str = "http://localhost:8787") -> dict:
    """Get the event history (story) for a task.

    Returns all scheduler events involving the specified task key,
    in chronological order.

    Args:
        key: The task key to query
        dashboard_url: URL of the scheduler dashboard (default: http://localhost:8787)

    Returns:
        dict with keys:
            - key: The queried task key
            - events: List of event dicts with timestamp_us, event_type, details
            - total_events_in_log: Total events in the scheduler's ring buffer
            - timestamp_ms: When the query was executed

    Example:
        >>> story = frisky.story("add-0-1")
        >>> for event in story["events"]:
        ...     print(f"{event['event_type']}: {event['details']}")
    """
    encoded_key = urllib.parse.quote(key, safe="")
    url = f"{dashboard_url.rstrip('/')}/api/story/{encoded_key}"
    try:
        return _get_json(url, timeout=10)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise KeyError(f"Task '{key}' not found") from None
        raise
