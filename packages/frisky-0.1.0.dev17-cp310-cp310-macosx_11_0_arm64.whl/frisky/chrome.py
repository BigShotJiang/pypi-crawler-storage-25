"""Chrome trace format export for frisky spans."""

import json


def export_chrome_trace(spans, filename="trace.json", n_workers=0):
    """Export spans to Chrome trace format.

    Args:
        spans: List of span dicts from get_spans() or cluster.collect_traces()
        filename: Output filename (default: trace.json)
        n_workers: Number of workers (for labeling, auto-detected if spans have worker_idx)

    The output can be loaded in chrome://tracing for visualization.
    """
    # Auto-detect n_workers from spans if not provided
    if n_workers == 0:
        worker_indices = {s.get("worker_idx") for s in spans if s.get("worker_idx") is not None}
        n_workers = len(worker_indices)

    # Scheduler span types -> tid mapping
    scheduler_tids = {
        "scheduler.handle_update_graph": 0,
        "scheduler.task_finished": 1,
        "scheduler.tasks_finished": 1,  # batch version on same row
        "client.receive_result": 2,
    }

    # All worker spans on same row (tid=0) within each worker process
    worker_tids = {
        "worker.receive_task": 0,
        "worker.exec.gil": 0,
        "worker.exec.deserialize": 0,
        "worker.exec.call": 0,
        "worker.exec.serialize": 0,
        "worker.store_data": 0,
        "worker.lock": 0,
        "worker.handle_event": 0,
        "worker.task_complete": 0,
    }

    events = []
    for span in spans:
        name = span["name"]
        worker_idx = span.get("worker_idx")

        # Determine pid and tid based on whether this is a scheduler or worker span
        if worker_idx is not None:
            pid = worker_idx + 1  # Workers start at pid=1
            tid = worker_tids.get(name, 1)
        else:
            pid = 0  # Scheduler
            tid = scheduler_tids.get(name, 2)

        # Chrome trace uses microseconds
        start_us = span["start_ns"] / 1000
        dur_us = span["duration_ns"] / 1000

        events.append({
            "name": name,
            "cat": "frisky",
            "ph": "X",  # Complete event (duration)
            "ts": start_us,
            "dur": dur_us,
            "pid": pid,
            "tid": tid,
            "args": {
                "trace_id": span["trace_id"],
                "span_id": span["span_id"],
            }
        })

    # Add process name metadata for scheduler
    events.append({
        "name": "process_name",
        "ph": "M",
        "pid": 0,
        "args": {"name": "Scheduler"}
    })

    # Add thread names for scheduler
    scheduler_thread_names = {
        0: "scheduler.update_graph",
        1: "scheduler.task_finished",
        2: "client.receive_result",
    }
    for tid, name in scheduler_thread_names.items():
        events.append({
            "name": "thread_name",
            "ph": "M",
            "pid": 0,
            "tid": tid,
            "args": {"name": name}
        })

    # Add process and thread names for each worker
    for w in range(n_workers):
        pid = w + 1
        events.append({
            "name": "process_name",
            "ph": "M",
            "pid": pid,
            "args": {"name": f"Worker {w}"}
        })
        events.append({
            "name": "thread_name",
            "ph": "M",
            "pid": pid,
            "tid": 0,
            "args": {"name": "worker"}
        })

    trace = {"traceEvents": events}

    with open(filename, "w") as f:
        json.dump(trace, f)

    return len(events)
