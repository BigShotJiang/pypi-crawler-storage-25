"""Span statistics summary."""

from collections import defaultdict


def summarize_spans(spans):
    """Summarize spans by name with statistics.

    Args:
        spans: List of span dicts

    Returns:
        Dict mapping span name to stats: count, total_ms, mean_ms, max_ms
    """
    stats = defaultdict(lambda: {"count": 0, "total_ns": 0, "max_ns": 0})

    for span in spans:
        name = span["name"]
        # Use duration_ns if available, otherwise calculate from timestamps
        if "duration_ns" in span:
            duration_ns = span["duration_ns"]
        else:
            duration_ns = span["end_ns"] - span["start_ns"]
        stats[name]["count"] += 1
        stats[name]["total_ns"] += duration_ns
        stats[name]["max_ns"] = max(stats[name]["max_ns"], duration_ns)

    result = {}
    for name, s in stats.items():
        result[name] = {
            "count": s["count"],
            "total_ms": s["total_ns"] / 1_000_000,
            "mean_ms": (s["total_ns"] / s["count"]) / 1_000_000,
            "max_ms": s["max_ns"] / 1_000_000,
        }

    return result
