"""Text-based timeline rendering for frisky spans."""

import math
from typing import Optional


def _auto_scale_time(ns: int) -> tuple[float, str]:
    """Return (value, unit) for human-readable time.

    Picks a unit where the value will have at least 2 significant digits
    to avoid repeated labels in rulers (e.g., "0 0 0 1 1 1ms").
    """
    if ns >= 10_000_000_000:  # >= 10s
        return ns / 1_000_000_000, "s"
    elif ns >= 10_000_000:  # >= 10ms
        return ns / 1_000_000, "ms"
    elif ns >= 10_000:  # >= 10µs
        return ns / 1_000, "µs"
    else:
        return float(ns), "ns"


def _format_time(ns: int, unit: str) -> float:
    """Format time in given unit."""
    divisors = {"s": 1e9, "ms": 1e6, "µs": 1e3, "ns": 1}
    return ns / divisors[unit]


def _format_duration(ns: int) -> str:
    """Format a duration in a compact human-readable form."""
    if ns >= 1_000_000_000:
        return f"{ns / 1_000_000_000:.1f} s"
    elif ns >= 1_000_000:
        return f"{ns / 1_000_000:.1f} ms"
    elif ns >= 1_000:
        return f"{ns / 1_000:.1f} µs"
    else:
        return f"{ns} ns"


def _total_duration(spans: list, start_ns: Optional[int] = None, end_ns: Optional[int] = None) -> int:
    """Sum durations of spans within the given time window.

    If start_ns/end_ns are provided, only counts the portion of each span
    that falls within the window.
    """
    total = 0
    for s in spans:
        s_start = s["start_ns"]
        s_end = s["end_ns"]
        if start_ns is not None and end_ns is not None:
            # Clip span to window
            s_start = max(s_start, start_ns)
            s_end = min(s_end, end_ns)
            if s_start < s_end:
                total += s_end - s_start
        else:
            total += s_end - s_start
    return total


# ANSI codes for dim text
_DIM = "\033[2m"
_RESET = "\033[0m"


def _is_minor(ns: int, max_ns: int, threshold: float = 0.1) -> bool:
    """Check if a duration is minor relative to the max."""
    return max_ns > 0 and ns < max_ns * threshold


def _format_duration_relative(ns: int, max_ns: int, threshold: float = 0.1, width: int = 10) -> str:
    """Format duration, dimmed if it's small relative to max.

    Returns right-aligned string of specified width (accounting for ANSI codes).
    """
    text = _format_duration(ns)
    padded = f"{text:>{width}}"
    if _is_minor(ns, max_ns, threshold):
        return f"{_DIM}{padded}{_RESET}"
    return padded


def _format_label(label: str, ns: int, max_ns: int, width: int, align: str = ">") -> str:
    """Format a row label, dimmed if duration is minor."""
    if align == ">":
        padded = f"{label:>{width}}"
    else:
        padded = f"{label:<{width}}"
    if _is_minor(ns, max_ns):
        return f"{_DIM}{padded}{_RESET}"
    return padded


def _render_row(
    spans_list: list, width: int, start_ns: int, end_ns: int, sparse_threshold: float = 0.1
) -> str:
    """Render a single row of the timeline.

    Uses ▓ for columns with >sparse_threshold activity, │ for sparse activity.
    """
    duration = end_ns - start_ns
    if duration <= 0:
        return " " * width

    # Track active time per column
    col_active_ns = [0.0] * width
    col_duration = duration / width

    for s in spans_list:
        s_end = s["end_ns"]
        s_start = s["start_ns"]
        if s_end < start_ns or s_start > end_ns:
            continue
        s_start = max(s_start, start_ns)
        s_end = min(s_end, end_ns)

        # Calculate which columns this span overlaps
        start_col = int((s_start - start_ns) / duration * width)
        end_col = int((s_end - start_ns) / duration * width)
        start_col = max(0, min(start_col, width - 1))
        end_col = max(0, min(end_col, width - 1))

        for i in range(start_col, end_col + 1):
            # Calculate overlap between span and this column's time window
            col_start = start_ns + i * col_duration
            col_end = col_start + col_duration
            overlap_start = max(s_start, col_start)
            overlap_end = min(s_end, col_end)
            col_active_ns[i] += max(0, overlap_end - overlap_start)

    # Render based on density
    row = []
    for i in range(width):
        density = col_active_ns[i] / col_duration if col_duration > 0 else 0
        if density <= 0:
            row.append(" ")
        elif density <= sparse_threshold:
            row.append("│")
        else:
            row.append("▓")
    return "".join(row)


def _nice_tick_interval(duration: float, target_ticks: int = 5) -> float:
    """Calculate a nice round tick interval for the given duration."""
    rough_interval = duration / target_ticks
    # Find the magnitude (power of 10)
    if rough_interval <= 0:
        return 1
    magnitude = 10 ** int(math.floor(math.log10(rough_interval)))
    # Normalize to 1-10 range
    normalized = rough_interval / magnitude
    # Pick a nice number: 1, 2, 5, or 10
    if normalized <= 1.5:
        nice = 1
    elif normalized <= 3:
        nice = 2
    elif normalized <= 7:
        nice = 5
    else:
        nice = 10
    return nice * magnitude


# Sparkline characters for metrics visualization
SPARK_CHARS = "▁▂▃▄▅▆▇█"


def _extract_metrics_timeseries(spans: list[dict]) -> dict[str, list[tuple[int, int]]]:
    """Extract timeseries from scheduler.metrics spans.

    Returns dict mapping metric name -> list of (timestamp_ns, value) tuples,
    sorted by timestamp.
    """
    metrics_spans = [s for s in spans if s.get("name") == "scheduler.metrics"]
    if not metrics_spans:
        return {}

    # Parse key=value pairs from keys field
    result: dict[str, list[tuple[int, int]]] = {}
    for span in sorted(metrics_spans, key=lambda s: s["end_ns"]):
        ts = span["end_ns"]
        for kv in span.get("keys", []):
            if "=" in kv:
                key, val = kv.split("=", 1)
                try:
                    value = int(val)
                    if key not in result:
                        result[key] = []
                    result[key].append((ts, value))
                except ValueError:
                    pass
    return result


def _render_sparkline(
    values: list[int],
    width: int,
    min_val: Optional[int] = None,
    max_val: Optional[int] = None,
) -> str:
    """Render values as Unicode sparkline.

    Expects len(values) == width. If longer, samples evenly.
    """
    if not values:
        return " " * width

    if min_val is None:
        min_val = min(values)
    if max_val is None:
        max_val = max(values)

    # Sample if needed
    if len(values) > width:
        step = len(values) / width
        values = [values[int(i * step)] for i in range(width)]

    # Map to sparkline characters
    value_range = max_val - min_val
    n_chars = len(SPARK_CHARS)
    chars = []
    for v in values:
        if value_range == 0:
            idx = 0 if v == 0 else n_chars - 1
        else:
            normalized = (v - min_val) / value_range
            idx = int(normalized * (n_chars - 1) + 0.5)
            idx = max(0, min(idx, n_chars - 1))
        chars.append(SPARK_CHARS[idx])
    return "".join(chars)


def _format_bytes_rate(n: int) -> str:
    """Format byte rate in human-readable form."""
    if n >= 1_000_000_000:
        return f"{n / 1_000_000_000:.1f} GB/s"
    elif n >= 1_000_000:
        return f"{n / 1_000_000:.1f} MB/s"
    elif n >= 1_000:
        return f"{n / 1_000:.1f} KB/s"
    else:
        return f"{n} B/s"


def _bin_gauge_to_columns(
    series: list[tuple[int, int]],
    start_ns: int,
    end_ns: int,
    width: int,
) -> list[int]:
    """Bin gauge values into timeline columns, forward-filling from last known value.

    Looks back before start_ns to find initial value, then forward-fills across columns.
    """
    if not series:
        return [0] * width

    duration = end_ns - start_ns
    col_duration = duration / width

    # Find last value before window (for forward-fill)
    initial_value = 0
    for ts, v in series:
        if ts < start_ns:
            initial_value = v
        else:
            break

    # Build list of (column_index, value) for samples in window
    samples_in_window = []
    for ts, v in series:
        if start_ns <= ts <= end_ns:
            col = int((ts - start_ns) / col_duration)
            col = max(0, min(col, width - 1))
            samples_in_window.append((col, v))

    # Forward-fill: start with initial value, update when we hit a sample
    result = [0] * width
    current_value = initial_value
    sample_idx = 0
    for col in range(width):
        # Apply any samples at this column
        while sample_idx < len(samples_in_window) and samples_in_window[sample_idx][0] <= col:
            current_value = samples_in_window[sample_idx][1]
            sample_idx += 1
        result[col] = current_value

    return result


def _bin_rates_to_columns(
    series: list[tuple[int, int]],
    start_ns: int,
    end_ns: int,
    width: int,
) -> list[int]:
    """Compute rates from cumulative values and bin into timeline columns.

    Computes rate between consecutive samples and fills columns for the time
    range where that rate applies (from previous sample to current sample).
    """
    if len(series) < 2:
        return [0] * width

    duration = end_ns - start_ns
    col_duration = duration / width

    # Find samples before, during, and after window
    # We need the sample before to compute rate at window start
    before = [(ts, v) for ts, v in series if ts < start_ns]
    during = [(ts, v) for ts, v in series if start_ns <= ts <= end_ns]
    after = [(ts, v) for ts, v in series if ts > end_ns]

    if not during and not before:
        return [0] * width

    # Use last sample before window as baseline, or first sample in window
    if before:
        baseline_ts, baseline_v = before[-1]
    else:
        baseline_ts, baseline_v = during[0]

    # Compute rate segments: each segment has (start_ts, end_ts, rate)
    # The rate applies from prev_ts to ts
    segments = []
    prev_ts, prev_v = baseline_ts, baseline_v

    # Process samples in window
    for ts, v in during:
        if ts > prev_ts:
            dt_s = (ts - prev_ts) / 1e9
            rate = int((v - prev_v) / dt_s) if dt_s > 0 else 0
            segments.append((prev_ts, ts, max(0, rate)))
        prev_ts, prev_v = ts, v

    # Include first sample after window to fill to end
    if after:
        ts, v = after[0]
        if ts > prev_ts:
            dt_s = (ts - prev_ts) / 1e9
            rate = int((v - prev_v) / dt_s) if dt_s > 0 else 0
            segments.append((prev_ts, ts, max(0, rate)))

    if not segments:
        return [0] * width

    # Fill columns based on which segments cover them
    result = [0] * width
    for seg_start, seg_end, rate in segments:
        # Clip segment to window
        seg_start = max(seg_start, start_ns)
        seg_end = min(seg_end, end_ns)
        if seg_start >= seg_end:
            continue

        # Calculate which columns this segment covers
        start_col = int((seg_start - start_ns) / col_duration)
        end_col = int((seg_end - start_ns) / col_duration)
        start_col = max(0, min(start_col, width - 1))
        end_col = max(0, min(end_col, width - 1))

        for col in range(start_col, end_col + 1):
            # Use max rate if multiple segments cover same column
            result[col] = max(result[col], rate)

    return result


def _render_metrics_section(
    spans: list[dict],
    start_ns: int,
    end_ns: int,
    width: int,
    label_width: int,
) -> list[str]:
    """Render metrics sparklines aligned with timeline axis.

    Returns list of lines showing Memory, Disk, and Network sparklines.
    """
    timeseries = _extract_metrics_timeseries(spans)
    if not timeseries:
        return []

    # Ensure label width is at least as wide as longest metric label
    METRIC_LABELS = ["Memory", "Disk Write", "Disk Read", "Network"]
    label_width = max(label_width, max(len(l) for l in METRIC_LABELS))

    lines = []

    # Memory (gauge, show as % of limit)
    if "mem_used" in timeseries and "mem_limit" in timeseries:
        mem_series = timeseries["mem_used"]
        limit_series = timeseries["mem_limit"]
        # Get max limit from all samples
        mem_limit = max(v for _, v in limit_series) if limit_series else 1

        # Bin memory values into columns with forward-fill
        mem_vals = _bin_gauge_to_columns(mem_series, start_ns, end_ns, width)
        mem_pcts = [int(100 * v / mem_limit) if mem_limit > 0 else 0 for v in mem_vals]

        nonzero = [v for v in mem_pcts if v > 0]
        if nonzero:
            sparkline = _render_sparkline(mem_pcts, width, min_val=0, max_val=max(100, max(nonzero)))
            summary = f"{min(nonzero)}%→{max(nonzero)}%"
            label = f"{'Memory':<{label_width}}"
            lines.append(f"{label} │{sparkline}│ {summary:>12}")

    # Disk Write (rate from cumulative spill_bytes)
    if "spill_bytes" in timeseries:
        disk_w_rates = _bin_rates_to_columns(timeseries["spill_bytes"], start_ns, end_ns, width)
        if any(r > 0 for r in disk_w_rates):
            sparkline = _render_sparkline(disk_w_rates, width, min_val=0)
            summary = f"{_format_bytes_rate(max(disk_w_rates))}"
            label = f"{'Disk Write':<{label_width}}"
            lines.append(f"{label} │{sparkline}│ {summary:>12}")

    # Disk Read (rate from cumulative unspill_bytes)
    if "unspill_bytes" in timeseries:
        disk_r_rates = _bin_rates_to_columns(timeseries["unspill_bytes"], start_ns, end_ns, width)
        if any(r > 0 for r in disk_r_rates):
            sparkline = _render_sparkline(disk_r_rates, width, min_val=0)
            summary = f"{_format_bytes_rate(max(disk_r_rates))}"
            label = f"{'Disk Read':<{label_width}}"
            lines.append(f"{label} │{sparkline}│ {summary:>12}")

    # Network (combined send + recv rate)
    net_rates = [0] * width
    has_network = False
    if "bytes_sent" in timeseries:
        send_rates = _bin_rates_to_columns(timeseries["bytes_sent"], start_ns, end_ns, width)
        net_rates = [net_rates[i] + send_rates[i] for i in range(width)]
        has_network = True
    if "bytes_recv" in timeseries:
        recv_rates = _bin_rates_to_columns(timeseries["bytes_recv"], start_ns, end_ns, width)
        net_rates = [net_rates[i] + recv_rates[i] for i in range(width)]
        has_network = True

    if has_network and any(r > 0 for r in net_rates):
        sparkline = _render_sparkline(net_rates, width, min_val=0)
        summary = f"{_format_bytes_rate(max(net_rates))}"
        label = f"{'Network':<{label_width}}"
        lines.append(f"{label} │{sparkline}│ {summary:>12}")

    return lines


def _make_ruler(width: int, start_ns: int, end_ns: int, unit: str) -> str:
    """Create time ruler with tick marks (relative to start)."""
    duration = end_ns - start_ns
    duration_in_unit = _format_time(duration, unit)

    # Calculate nice round tick interval
    interval = _nice_tick_interval(duration_in_unit, target_ticks=5)

    # Generate tick values (in display units)
    ticks = []
    val = 0.0
    while val <= duration_in_unit:
        ticks.append(val)
        val += interval
    # Ensure we have the end point
    if not ticks or ticks[-1] < duration_in_unit * 0.95:
        ticks.append(duration_in_unit)

    ruler = [" "] * width
    for i, val in enumerate(ticks):
        # Position in the ruler
        if duration_in_unit > 0:
            pos = int(val / duration_in_unit * (width - 1))
        else:
            pos = 0
        pos = min(pos, width - 1)

        # Format label - first tick gets unit
        if i == 0:
            label = f"0{unit}"
        elif i == len(ticks) - 1:
            # Last label right-aligned with unit
            label = f"{val:.0f}{unit}"
            pos = width - len(label)
        else:
            label = f"{val:.0f}"

        # Place label (don't overwrite previous labels)
        for j, c in enumerate(label):
            if 0 <= pos + j < width:
                ruler[pos + j] = c

    return "".join(ruler)


def render_timeline(
    spans: list,
    start: Optional[int] = None,
    duration: Optional[int] = None,
    width: int = 70,
    view: str = "detailed",
    prefixes: Optional[list[str]] = None,
    worker: Optional[int] = None,
    trace_id: Optional[int] = None,
) -> str:
    """Render spans as a text-based Gantt chart.

    Args:
        spans: List of span dicts from get_spans() or query_spans()
        start: Start time in nanoseconds (None = auto-detect from spans)
        duration: Duration in nanoseconds (None = auto-detect from spans)
        width: Character width for the timeline (default 70)
        view: View type - 'component', 'worker', 'trace', or 'detailed'
        prefixes: Filter to spans matching these prefixes (e.g., ['worker.spill', 'worker.exec'])
        worker: Filter to specific worker index
        trace_id: Filter to specific trace (required for 'trace' view)

    Returns:
        Formatted string showing spans as a timeline.

    Example:
        >>> spans = frisky.get_spans()
        >>> print(frisky.render_timeline(spans, view='component'))
                     │0           12          24          36          48       60µs│
                     ├──────────────────────────────────────────────────────────────┤
             compute │▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓                 ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓  │
               spill │            ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓       ▓▓▓▓▓▓▓▓▓▓▓▓          │
             unspill │                                        ▓▓▓▓▓▓▓▓▓▓▓▓          │
           scheduler │         ▓         ▓▓                                      ▓▓ │
                     └──────────────────────────────────────────────────────────────┘
    """
    if not spans:
        return "No spans to display"

    # Keep original spans for metrics (before filtering)
    all_spans = spans

    # Calculate time base from ALL spans before filtering
    # This keeps the time axis consistent regardless of filters
    data_start_ns = min(s["start_ns"] for s in spans)

    # Apply prefix filter
    if prefixes:
        spans = [s for s in spans if any(s["name"].startswith(p) for p in prefixes)]
        if not spans:
            return f"No spans match prefixes: {prefixes}"

    # Apply worker filter
    if worker is not None:
        spans = [s for s in spans if s.get("worker_idx") == worker]
        if not spans:
            return f"No spans for worker {worker}"

    # Apply trace filter
    if trace_id is not None:
        spans = [s for s in spans if s.get("trace_id") == trace_id]
        if not spans:
            return f"No spans for trace_id {trace_id}"

    # Filter out scheduler.metrics spans from view (they're metric containers, not activity)
    spans = [s for s in spans if s.get("name") != "scheduler.metrics"]
    if not spans:
        return "No spans to display (only scheduler.metrics found)"

    # Calculate time window
    # Start is relative to the earliest span (before filtering)

    if start is None:
        start_ns = data_start_ns
    else:
        # User specifies start relative to data start
        start_ns = data_start_ns + start

    if duration is None:
        end_ns = max(s["end_ns"] for s in spans)
    else:
        end_ns = start_ns + duration

    # Pick unit based on the window duration being displayed
    _, unit = _auto_scale_time(end_ns - start_ns)

    lines = []
    label_width = 10  # Default, will be updated by views

    if view == "component":
        view_lines, label_width = _render_component_view(spans, start_ns, end_ns, width, unit)
        lines.extend(view_lines)
    elif view == "worker":
        view_lines, label_width = _render_worker_view(spans, start_ns, end_ns, width, unit)
        lines.extend(view_lines)
    elif view == "trace":
        if trace_id is None:
            # Sample a few traces spread throughout the time range
            lines.extend(_render_sampled_traces(spans, width, n_samples=3))
        else:
            lines.extend(_render_trace_view(spans, width, trace_id))
        # Skip metrics for trace view (has its own time window)
        return "\n".join(lines)
    elif view == "detailed":
        view_lines, label_width = _render_detailed_view(spans, start_ns, end_ns, width, unit)
        lines.extend(view_lines)
    else:
        return f"Unknown view: {view}. Use 'component', 'worker', 'trace', or 'detailed'."

    # Add metrics sparklines (use all_spans to include scheduler.metrics)
    metrics_lines = _render_metrics_section(all_spans, start_ns, end_ns, width, label_width)
    if metrics_lines:
        lines.extend(metrics_lines)

    return "\n".join(lines)


def _render_component_view(spans: list, start_ns: int, end_ns: int, width: int, unit: str) -> tuple[list[str], int]:
    """Render spans grouped by component type.

    Returns (lines, label_width) tuple.
    """
    components = {
        "compute": [s for s in spans if "exec.call" in s["name"] or s["name"] == "worker.execute"],
        "serialize": [
            s
            for s in spans
            if "serialize" in s["name"] and "spill" not in s["name"] and "unspill" not in s["name"]
        ],
        "spill": [s for s in spans if "spill." in s["name"] and "unspill" not in s["name"]],
        "unspill": [s for s in spans if "unspill." in s["name"]],
        "scheduler": [s for s in spans if "scheduler" in s["name"]],
    }

    # Remove empty components
    components = {k: v for k, v in components.items() if v}

    if not components:
        return ["No recognized components in spans"], 10

    # Ensure label width is at least 10 to align with metrics section
    max_name = max(10, max(len(n) for n in components.keys()))
    ruler = _make_ruler(width, start_ns, end_ns, unit)

    # Calculate max duration for relative formatting (within the visible window)
    durations = {k: _total_duration(v, start_ns, end_ns) for k, v in components.items()}
    max_dur = max(durations.values()) if durations else 0

    lines = []
    lines.append(f'{"":<{max_name}} │{ruler}│')
    lines.append(f'{"":<{max_name}} ├{"─" * width}┤')
    for comp in ["compute", "serialize", "spill", "unspill", "scheduler"]:
        if comp in components:
            label = _format_label(comp, durations[comp], max_dur, max_name)
            row = _render_row(components[comp], width, start_ns, end_ns)
            total = _format_duration_relative(durations[comp], max_dur)
            lines.append(f"{label} │{row}│{total}")
    lines.append(f'{"":<{max_name}} └{"─" * width}┘')

    return lines, max_name


def _render_worker_view(spans: list, start_ns: int, end_ns: int, width: int, unit: str) -> tuple[list[str], int]:
    """Render spans grouped by worker.

    Returns (lines, label_width) tuple.
    """
    # Group by worker_idx (None for scheduler)
    by_worker = {}
    for s in spans:
        w = s.get("worker_idx")
        if w not in by_worker:
            by_worker[w] = []
        by_worker[w].append(s)

    # Sort: numeric workers first, then scheduler (None)
    worker_order = sorted([w for w in by_worker.keys() if w is not None]) + (
        [None] if None in by_worker else []
    )

    # Ensure label width is at least 10 to align with metrics section
    max_name = max(
        10, max(len(f"worker-{w}" if w is not None else "scheduler") for w in worker_order)
    )
    ruler = _make_ruler(width, start_ns, end_ns, unit)

    # Calculate max duration for relative formatting (within the visible window)
    durations = {w: _total_duration(by_worker[w], start_ns, end_ns) for w in worker_order}
    max_dur = max(durations.values()) if durations else 0

    lines = []
    lines.append(f'{"":<{max_name}} │{ruler}│')
    lines.append(f'{"":<{max_name}} ├{"─" * width}┤')
    for w in worker_order:
        label_text = f"worker-{w}" if w is not None else "scheduler"
        label = _format_label(label_text, durations[w], max_dur, max_name)
        row = _render_row(by_worker[w], width, start_ns, end_ns)
        total = _format_duration_relative(durations[w], max_dur)
        lines.append(f"{label} │{row}│{total}")
    lines.append(f'{"":<{max_name}} └{"─" * width}┘')

    return lines, max_name


def _render_sampled_traces(spans: list, width: int, n_samples: int = 3) -> list[str]:
    """Sample a few traces spread throughout the time range and render each."""
    # Group spans by trace_id
    by_trace = {}
    for s in spans:
        tid = s.get("trace_id")
        if tid is not None:
            if tid not in by_trace:
                by_trace[tid] = []
            by_trace[tid].append(s)

    if not by_trace:
        return ["No traces found"]

    # Filter to traces that have task keys (skip meta traces like dask_compute)
    by_trace = {
        tid: trace_spans
        for tid, trace_spans in by_trace.items()
        if any(s.get("keys") for s in trace_spans)
    }

    if not by_trace:
        return ["No task traces found (only meta traces)"]

    # Sort traces by their start time
    trace_starts = []
    for tid, trace_spans in by_trace.items():
        start = min(s["start_ns"] for s in trace_spans)
        trace_starts.append((start, tid))
    trace_starts.sort()

    # Sample traces spread throughout (first, middle(s), last)
    n_traces = len(trace_starts)
    if n_traces <= n_samples:
        selected = [(start, tid) for start, tid in trace_starts]
    else:
        indices = [int(i * (n_traces - 1) / (n_samples - 1)) for i in range(n_samples)]
        selected = [trace_starts[i] for i in indices]

    # Sort selected traces chronologically
    selected.sort(key=lambda x: x[0])

    # Calculate the overall time base for relative start times
    all_starts = [s["start_ns"] for s in spans]
    global_start = min(all_starts)

    lines = []
    for i, (_, tid) in enumerate(selected):
        trace_spans = by_trace[tid]
        t_min = min(s["start_ns"] for s in trace_spans)

        # Calculate relative start time
        relative_start = t_min - global_start
        rel_str = _format_duration(relative_start)

        lines.extend(_render_trace_view(trace_spans, width, tid, rel_str))
        if i < len(selected) - 1:
            lines.append("")  # blank line between traces

    return lines


def _render_trace_view(
    spans: list, width: int, trace_id: int, offset_str: Optional[str] = None
) -> list[str]:
    """Render spans for a single trace, showing task flow."""
    trace_spans = [s for s in spans if s.get("trace_id") == trace_id]
    if not trace_spans:
        return [f"No spans for trace_id {trace_id}"]

    # Sort by start time
    trace_spans = sorted(trace_spans, key=lambda s: s["start_ns"])

    # Use trace-specific time range
    t_min = min(s["start_ns"] for s in trace_spans)
    t_max = max(s["end_ns"] for s in trace_spans)
    t_dur = t_max - t_min
    _, t_unit = _auto_scale_time(t_dur)

    # Get task keys if available
    keys = set()
    for s in trace_spans:
        keys.update(s.get("keys", []))
    key_str = ", ".join(sorted(keys)[:3])
    if len(keys) > 3:
        key_str += "..."

    max_name = max(len(s["name"]) for s in trace_spans)
    ruler = _make_ruler(width, t_min, t_max, t_unit)

    # Calculate max duration for relative formatting
    max_dur = max(s["end_ns"] - s["start_ns"] for s in trace_spans)

    lines = []
    if offset_str:
        lines.append(f"@ {offset_str} ({key_str}): {_format_time(t_dur, t_unit):.1f}{t_unit} total")
    else:
        lines.append(f"({key_str}): {_format_time(t_dur, t_unit):.1f}{t_unit} total")
    lines.append("")
    lines.append(f'{"":<{max_name}} │{ruler}│')
    lines.append(f'{"":<{max_name}} ├{"─" * width}┤')
    for s in trace_spans:
        dur_ns = s["end_ns"] - s["start_ns"]
        label = _format_label(s["name"], dur_ns, max_dur, max_name, align="<")
        row = _render_row([s], width, t_min, t_max)
        dur_str = _format_duration_relative(dur_ns, max_dur)
        lines.append(f'{label} │{row}│{dur_str}')
    lines.append(f'{"":<{max_name}} └{"─" * width}┘')

    return lines


def _render_detailed_view(spans: list, start_ns: int, end_ns: int, width: int, unit: str) -> tuple[list[str], int]:
    """Render all span types, each on its own row.

    Returns (lines, label_width) tuple.
    """
    # Group by unique span name
    by_name = {}
    for s in spans:
        name = s["name"]
        if name not in by_name:
            by_name[name] = []
        by_name[name].append(s)

    if not by_name:
        return ["No spans to display"], 10

    # Ensure label width is at least 10 to align with metrics section
    max_name = max(10, max(len(n) for n in by_name.keys()))
    ruler = _make_ruler(width, start_ns, end_ns, unit)

    # Calculate max duration for relative formatting (within the visible window)
    durations = {n: _total_duration(ns, start_ns, end_ns) for n, ns in by_name.items()}
    max_dur = max(durations.values()) if durations else 0

    lines = []
    lines.append(f'{"":<{max_name}} │{ruler}│')
    lines.append(f'{"":<{max_name}} ├{"─" * width}┤')
    for name in sorted(by_name.keys()):
        label = _format_label(name, durations[name], max_dur, max_name, align="<")
        row = _render_row(by_name[name], width, start_ns, end_ns)
        total = _format_duration_relative(durations[name], max_dur)
        lines.append(f"{label} │{row}│{total}")
    lines.append(f'{"":<{max_name}} └{"─" * width}┘')

    return lines, max_name

