"""Observe commands: workers, prefixes, progress, detail, tasks, task."""

import json
import urllib.parse
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich.text import Text

from frisky.dashboard_client import _get_json
from .render import (
    format_bytes,
    format_occupancy,
    render_workers_table,
    render_prefixes_table,
    shorten_key,
)

observe_app = typer.Typer(
    name="observe",
    help="Observe a running Frisky cluster.",
    no_args_is_help=True,
)


def _fetch_progress(url: str) -> dict:
    """Fetch progress data from scheduler API."""
    api_url = f"{url.rstrip('/')}/api/progress"
    try:
        return _get_json(api_url, timeout=5)
    except ConnectionError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)
    except json.JSONDecodeError as e:
        typer.echo(f"Error: Invalid JSON response: {e}", err=True)
        raise typer.Exit(1)


@observe_app.command()
def workers(
    url: str = typer.Option(
        "http://localhost:8787",
        "--url", "-u",
        help="Scheduler dashboard URL.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw JSON instead of table.",
    ),
) -> None:
    """Show worker status and resource usage."""
    data = _fetch_progress(url)

    if json_output:
        output = {
            "timestamp_ms": data.get("timestamp_ms"),
            "workers": data.get("workers", []),
            "totals": data.get("totals", {}),
        }
        typer.echo(json.dumps(output, indent=2))
        return

    render_workers_table(Console(), data)


@observe_app.command()
def prefixes(
    url: str = typer.Option(
        "http://localhost:8787",
        "--url", "-u",
        help="Scheduler dashboard URL.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw JSON instead of table.",
    ),
    show_all: bool = typer.Option(
        False,
        "--all", "-a",
        help="Show all prefixes (default: top 10 by activity).",
    ),
) -> None:
    """Show task prefix statistics."""
    data = _fetch_progress(url)

    if json_output:
        output = {
            "timestamp_ms": data.get("timestamp_ms"),
            "prefix_stats": data.get("prefix_stats", {}),
            "queued": data.get("queued", {}),
        }
        typer.echo(json.dumps(output, indent=2))
        return

    console = Console()
    if not data.get("prefix_stats"):
        console.print("[dim]No task prefixes[/dim]")
        return

    render_prefixes_table(console, data, show_all)


@observe_app.command()
def progress(
    url: str = typer.Option(
        "http://localhost:8787",
        "--url", "-u",
        help="Scheduler dashboard URL.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw JSON instead of table.",
    ),
    show_all: bool = typer.Option(
        False,
        "--all", "-a",
        help="Show all prefixes (default: top 10 by activity).",
    ),
) -> None:
    """Show combined worker and prefix overview."""
    data = _fetch_progress(url)

    if json_output:
        typer.echo(json.dumps(data, indent=2))
        return

    console = Console()
    render_workers_table(console, data)
    if data.get("prefix_stats"):
        console.print()
        render_prefixes_table(console, data, show_all)


@observe_app.command()
def detail(
    url: str = typer.Option(
        "http://localhost:8787",
        "--url", "-u",
        help="Scheduler dashboard URL.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw JSON instead of table.",
    ),
    workers_filter: Optional[str] = typer.Option(
        None,
        "--workers", "-w",
        help="Comma-separated worker addresses to include (default: all).",
    ),
    prefixes_filter: Optional[str] = typer.Option(
        None,
        "--prefixes", "-p",
        help="Comma-separated task prefixes to include (default: all).",
    ),
) -> None:
    """Show detailed worker x prefix breakdown."""
    data = _fetch_progress(url)

    if json_output:
        typer.echo(json.dumps(data, indent=2))
        return

    console = Console()

    # Parse filters
    worker_filter = set(w.strip() for w in workers_filter.split(",")) if workers_filter else None
    prefix_filter = set(p.strip() for p in prefixes_filter.split(",")) if prefixes_filter else None

    # Filter workers
    filtered_workers = data.get("workers", [])
    if worker_filter:
        filtered_workers = [w for w in filtered_workers if w.get("address") in worker_filter]

    # Collect all prefixes from filtered workers
    all_prefixes = set()
    for w in filtered_workers:
        all_prefixes.update(w.get("prefixes", {}).keys())
    all_prefixes.update(data.get("totals", {}).get("prefixes", {}).keys())
    all_prefixes.update(data.get("queued", {}).keys())

    # Apply prefix filter
    if prefix_filter:
        all_prefixes = all_prefixes & prefix_filter

    prefix_list = sorted(all_prefixes)

    if not prefix_list:
        console.print("[dim]No matching data[/dim]")
        return

    # Build table
    table = Table(title="Worker x Prefix Detail", expand=True)
    table.add_column("Worker", style="cyan", overflow="fold")
    for prefix in prefix_list:
        table.add_column(prefix, justify="right", overflow="fold")

    # Worker rows
    for w in filtered_workers:
        row = [w.get("address", "")]
        for prefix in prefix_list:
            counts = w.get("prefixes", {}).get(prefix, {})
            proc = counts.get("processing", 0)
            mem = counts.get("memory", 0)
            if proc or mem:
                row.append(f"{proc}/{mem}")
            else:
                row.append("")
        table.add_row(*row)

    # Totals row
    if not worker_filter or len(filtered_workers) > 1:
        totals = data.get("totals", {})
        totals_row = ["[bold]TOTAL[/bold]"]
        for prefix in prefix_list:
            counts = totals.get("prefixes", {}).get(prefix, {})
            proc = counts.get("processing", 0)
            mem = counts.get("memory", 0)
            if proc or mem:
                totals_row.append(f"[bold]{proc}/{mem}[/bold]")
            else:
                totals_row.append("")
        table.add_row(*totals_row)

    console.print(table)
    console.print()
    console.print("[dim]Values: processing/memory[/dim]")

    # Show queued if any match prefix filter
    queued = data.get("queued", {})
    if prefix_filter:
        queued = {k: v for k, v in queued.items() if k in prefix_filter}

    if queued:
        console.print()
        q_table = Table(title="Queued Tasks", expand=True)
        q_table.add_column("Prefix", style="cyan", overflow="fold")
        q_table.add_column("Count", justify="right")
        for prefix, count in sorted(queued.items()):
            q_table.add_row(prefix, str(count))
        console.print(q_table)


@observe_app.command()
def tasks(
    url: str = typer.Option(
        "http://localhost:8787",
        "--url", "-u",
        help="Scheduler dashboard URL.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw JSON instead of table.",
    ),
    state: Optional[str] = typer.Option(
        None,
        "--state", "-s",
        help="Filter by state(s), comma-separated.",
    ),
    prefix: Optional[str] = typer.Option(
        None,
        "--prefix", "-p",
        help="Filter by prefix(es), comma-separated.",
    ),
    worker: Optional[str] = typer.Option(
        None,
        "--worker", "-w",
        help="Filter by worker address.",
    ),
    limit: int = typer.Option(
        20,
        "--limit", "-n",
        help="Maximum number of tasks to show (max 100).",
    ),
) -> None:
    """List tasks with optional filtering."""
    try:
        data = _get_json(
            f"{url.rstrip('/')}/api/tasks",
            params={"state": state, "prefix": prefix, "worker": worker, "limit": min(limit, 100)},
            timeout=10,
        )
    except Exception as e:
        typer.echo(f"Error: Could not connect to scheduler at {url}: {e}", err=True)
        raise typer.Exit(1)

    if json_output:
        typer.echo(json.dumps(data, indent=2))
        return

    console = Console()
    tasks_list = data.get("tasks", [])
    total = data.get("total_matching", 0)

    if not tasks_list:
        console.print("[dim]No matching tasks[/dim]")
        return

    table = Table(title=f"Tasks ({len(tasks_list)} of {total})", expand=True)
    table.add_column("Key", style="cyan", overflow="fold")
    table.add_column("State", style="yellow")
    table.add_column("Worker")
    table.add_column("Size", justify="right")
    table.add_column("Deps", justify="right")
    table.add_column("Dependents", justify="right")
    table.add_column("Est. Duration", justify="right")

    for t in tasks_list:
        table.add_row(
            t.get("key", ""),
            t.get("state", ""),
            t.get("worker") or "",
            format_bytes(t.get("nbytes", 0)) if t.get("nbytes", 0) > 0 else "",
            str(t.get("n_dependencies", 0)),
            str(t.get("n_dependents", 0)),
            format_occupancy(t.get("duration_avg", -1)) if t.get("duration_avg", -1) > 0 else "",
        )

    console.print(table)

    if len(tasks_list) < total:
        console.print(f"[dim](showing {len(tasks_list)} of {total} matching tasks, use --limit to see more)[/dim]")


@observe_app.command("task")
def task_detail(
    key: str = typer.Argument(
        ...,
        help="Task key to inspect.",
    ),
    url: str = typer.Option(
        "http://localhost:8787",
        "--url", "-u",
        help="Scheduler dashboard URL.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw JSON instead of formatted output.",
    ),
) -> None:
    """Show detailed information and event history for a task."""
    # URL-encode the key for the path
    encoded_key = urllib.parse.quote(key, safe="")
    base_url = url.rstrip('/')

    # Fetch task detail (may 404 if task released)
    try:
        task_data = _get_json(f"{base_url}/api/task/{encoded_key}", timeout=10)
    except Exception:
        task_data = None

    # Fetch story
    try:
        story_data = _get_json(f"{base_url}/api/story/{encoded_key}", timeout=10)
    except Exception:
        story_data = None

    if task_data is None and (story_data is None or not story_data.get("events")):
        typer.echo(f"Error: Task '{key}' not found (no detail or history)", err=True)
        raise typer.Exit(1)

    if json_output:
        output = {"key": key}
        if task_data:
            output["task_detail"] = task_data
        if story_data:
            output["story"] = story_data
        typer.echo(json.dumps(output, indent=2))
        return

    console = Console()

    if task_data is None:
        console.print(f"\n[bold yellow]Task '{key}' released[/bold yellow] (showing history only)\n")
        task = {}
        dependents_tree = []
        dependency_tree = []
    else:
        task = task_data.get("task", {})
        dependents_tree = task_data.get("dependents_tree", [])
        dependency_tree = task_data.get("dependency_tree", [])

    # Waiting on (blocking dependencies)
    waiting_on = task_data.get("waiting_on", []) if task_data else []
    if waiting_on:
        console.print(f"\n[bold red]Blocking on {len(waiting_on)} tasks:[/bold red]")
        wait_table = Table(show_header=True, header_style="dim", box=None, padding=(0, 2), expand=True)
        wait_table.add_column("Key", overflow="fold")
        wait_table.add_column("State")
        wait_table.add_column("Size", justify="right")
        wait_table.add_column("Worker")

        for w in waiting_on[:10]:
            state = w.get("state", "")
            state_color = "green" if state == "Memory" else "yellow" if state != "Erred" else "red"
            wait_table.add_row(
                w.get("key", ""),
                f"[{state_color}]{state}[/{state_color}]",
                format_bytes(w.get("nbytes", 0)) if w.get("nbytes", 0) > 0 else "",
                w.get("worker") or "",
            )
        console.print(wait_table)
        if len(waiting_on) > 10:
            console.print(f"[dim]... and {len(waiting_on) - 10} more[/dim]")
        console.print()

    # Build unified tree table
    table = Table(
        show_header=True,
        header_style="dim",
        box=None,
        padding=(0, 2),
        collapse_padding=True,
        expand=True,
    )
    table.add_column("Task", overflow="fold")
    table.add_column("State", justify="right", no_wrap=True)
    table.add_column("Size", justify="right", no_wrap=True)
    table.add_column("Duration", justify="right", no_wrap=True)
    table.add_column("Worker", justify="right", no_wrap=True)

    def _state_styled(state: str) -> Text:
        color = "green" if state == "Memory" else "red" if state == "Erred" else "yellow"
        return Text(state, style=color)

    def _add_task_row(prefix: str, t: dict, bold: bool = False, has_more: bool = False):
        key_str = t.get("key", "")
        if has_more:
            key_str += " ..."

        task_text = Text()
        task_text.append(prefix, style="dim")
        task_text.append(key_str, style="bold cyan" if bold else None)

        state = t.get("state", "")
        nbytes = t.get("nbytes", 0)
        duration = t.get("duration_avg", -1)
        worker = t.get("worker") or ""

        duration_str = ""
        if duration > 0.001:
            duration_str = format_occupancy(duration)

        table.add_row(
            task_text,
            _state_styled(state),
            format_bytes(nbytes) if nbytes > 0 else "",
            duration_str,
            worker,
        )

    def _build_tree_prefixes(nodes: list) -> list:
        """Build (prefix, task, has_more) tuples for tree nodes."""
        if not nodes:
            return []

        from collections import defaultdict
        children_by_parent = defaultdict(list)
        for node in nodes:
            parent = node.get("parent_key")
            children_by_parent[parent].append(node)

        result = []
        prefix_stack = []

        def visit(parent_key, depth: int):
            children = children_by_parent.get(parent_key, [])
            for i, node in enumerate(children):
                t = node.get("task", {})
                node_key = t.get("key", "")
                is_last = i == len(children) - 1
                has_more = node.get("has_more_deps", False)

                if depth == 0:
                    prefix = "└ " if is_last else "├ "
                else:
                    prefix = "".join(prefix_stack) + ("└ " if is_last else "├ ")

                result.append((prefix, t, has_more))

                if node_key in children_by_parent:
                    prefix_stack.append("  " if is_last else "│ ")
                    visit(node_key, depth + 1)
                    prefix_stack.pop()

        visit(None, 0)
        return result

    # Dependents section (upward tree)
    if dependents_tree:
        dep_rows = _build_tree_prefixes(dependents_tree)
        for prefix, t, has_more in reversed(dep_rows):
            upward_prefix = prefix.replace("└", "┌")
            _add_task_row(upward_prefix, t, has_more=has_more)

    # Main task (highlighted)
    _add_task_row("► ", task, bold=True)

    # Dependencies section (downward tree)
    if dependency_tree:
        tree_rows = _build_tree_prefixes(dependency_tree)
        for prefix, t, has_more in tree_rows:
            _add_task_row(prefix, t, has_more=has_more)

    if task_data:
        console.print()
        console.print(table)

    # Story / Event Timeline
    events = story_data.get("events", []) if story_data else []
    if events:
        console.print()
        console.print("[bold]Event History[/bold]")
        console.print()

        story_table = Table(show_header=True, header_style="dim", box=None, padding=(0, 2), expand=True)
        story_table.add_column("Time", justify="right", no_wrap=True, style="dim")
        story_table.add_column("Event", no_wrap=True)
        story_table.add_column("Details", overflow="fold")

        for event in events:
            ts_us = event.get("timestamp_us", 0)
            event_type = event.get("event_type", "")
            details = event.get("details", {})

            if ts_us < 1_000:
                time_str = f"{ts_us}us"
            elif ts_us < 1_000_000:
                time_str = f"{ts_us/1000:.1f}ms"
            else:
                time_str = f"{ts_us/1_000_000:.3f}s"

            type_colors = {
                "transition": "yellow",
                "placed": "cyan",
                "transfer_start": "magenta",
                "transfer_complete": "green",
                "transfer_failed": "red",
                "task_completed": "green",
                "task_erred": "red",
                "data_freed": "dim",
            }
            color = type_colors.get(event_type, "white")
            event_styled = f"[{color}]{event_type}[/{color}]"

            if event_type == "transition":
                detail_str = f"{details.get('from_state', '')} -> {details.get('to_state', '')}"
            elif event_type == "placed":
                worker = details.get("worker", "")
                reason = details.get("reason", "")
                deps_local = details.get("deps_local")
                deps_total = details.get("deps_total")
                if deps_local is not None and deps_total is not None:
                    detail_str = f"{worker} ({reason}: {deps_local}/{deps_total} deps local)"
                else:
                    detail_str = f"{worker} ({reason})"
            elif event_type == "transfer_start":
                data_key = details.get("key", "")
                from_w = details.get("from_worker", "")
                to_w = details.get("to_worker", "")
                nbytes = details.get("nbytes", 0)
                short_key = shorten_key(data_key) if data_key else ""
                detail_str = f"{short_key}: {from_w} -> {to_w} ({format_bytes(nbytes)})"
            elif event_type == "transfer_complete":
                data_key = details.get("key", "")
                short_key = shorten_key(data_key) if data_key else ""
                detail_str = f"{short_key} -> {details.get('to_worker', '')}"
            elif event_type == "transfer_failed":
                data_key = details.get("key", "")
                from_w = details.get("from_worker", "")
                to_w = details.get("to_worker", "")
                reason = details.get("reason", "")
                short_key = shorten_key(data_key) if data_key else ""
                detail_str = f"{short_key}: {from_w} -> {to_w} FAILED: {reason}"
            elif event_type == "task_completed":
                worker = details.get("worker", "")
                duration_us = details.get("duration_us", 0)
                nbytes = details.get("nbytes", 0)
                duration_str = format_occupancy(duration_us / 1_000_000) if duration_us > 0 else ""
                detail_str = f"{worker} ({duration_str}, {format_bytes(nbytes)})"
            elif event_type == "task_erred":
                detail_str = details.get("worker", "")
            elif event_type == "data_freed":
                detail_str = f"freed on {details.get('worker', '')}"
            else:
                detail_str = str(details)

            story_table.add_row(time_str, event_styled, detail_str)

        console.print(story_table)
    elif task_data is None:
        console.print("[dim]No events found in history[/dim]")

    console.print()
