"""Frisky command-line interface.

Start a scheduler:
    frisky scheduler

Start a worker:
    frisky worker tcp://127.0.0.1:8786

Observe a running cluster:
    frisky observe progress
"""

import typer

from .server import scheduler, worker
from .observe import observe_app
from .logs import logs
from .spans import spans_app

app = typer.Typer(
    name="frisky",
    help="Frisky: A high-performance distributed scheduler for Python.",
    add_completion=False,
    no_args_is_help=True,
)

# Register commands
app.command("scheduler")(scheduler)
app.command("worker")(worker)
app.command("logs")(logs)

# Register subcommand groups
app.add_typer(observe_app, name="observe")
app.add_typer(spans_app, name="spans")
