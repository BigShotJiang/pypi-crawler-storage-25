"""Server commands: scheduler and worker."""

import signal
import sys
from typing import Optional

import typer

from .render import format_bytes, parse_memory


def scheduler(
    address: str = typer.Option(
        "127.0.0.1:8786",
        "--address", "-a",
        help="Address to bind the scheduler (host:port).",
    ),
    dashboard: bool = typer.Option(
        True,
        "--dashboard/--no-dashboard",
        help="Enable the web dashboard.",
    ),
    dashboard_address: str = typer.Option(
        "127.0.0.1:8787",
        "--dashboard-address",
        help="Address for the dashboard server.",
    ),
) -> None:
    """Start the Frisky scheduler.

    The scheduler coordinates task execution across workers. Start it first,
    then connect workers using the address printed below.

    Examples:

        frisky scheduler

        frisky scheduler --address 0.0.0.0:8786

        frisky scheduler --no-dashboard
    """
    from frisky import Scheduler

    sched = Scheduler(address, dashboard=dashboard, dashboard_address=dashboard_address)

    typer.echo(f"Scheduler started at: {sched.address}")
    if dashboard:
        typer.echo(f"Dashboard: http://{dashboard_address}")
    typer.echo("Press Ctrl+C to stop")

    # Block until Ctrl+C
    def handle_signal(sig, frame):
        typer.echo("\nShutting down scheduler...")
        sched.close()
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    # Keep the main thread alive
    try:
        signal.pause()
    except AttributeError:
        # Windows doesn't have signal.pause()
        import time
        while True:
            time.sleep(1)


def worker(
    scheduler_address: str = typer.Argument(
        ...,
        help="Scheduler address to connect to (e.g., 127.0.0.1:8786).",
    ),
    nthreads: int = typer.Option(
        1,
        "--nthreads", "-n",
        help="Number of threads for concurrent task execution.",
    ),
    memory_limit: Optional[str] = typer.Option(
        None,
        "--memory-limit", "-m",
        help="Memory limit per worker (e.g., '4GB', '500MB'). Defaults to system memory.",
    ),
) -> None:
    """Start a Frisky worker.

    Workers execute tasks assigned by the scheduler. Connect to a running
    scheduler by providing its address.

    Examples:

        frisky worker 127.0.0.1:8786

        frisky worker 127.0.0.1:8786 --nthreads 4

        frisky worker 127.0.0.1:8786 -n 4 --memory-limit 4GB
    """
    from frisky import Worker

    # Parse memory limit if provided
    memory_bytes = None
    if memory_limit:
        memory_bytes = parse_memory(memory_limit)

    w = Worker(scheduler_address, nthreads=nthreads, memory_limit=memory_bytes)

    typer.echo(f"Worker started: {w.address}")
    typer.echo(f"  Scheduler: {scheduler_address}")
    typer.echo(f"  Threads: {nthreads}")
    if memory_bytes:
        typer.echo(f"  Memory limit: {format_bytes(memory_bytes)}")
    typer.echo("Press Ctrl+C to stop")

    # Block until Ctrl+C or scheduler closes connection
    def handle_signal(sig, frame):
        typer.echo("\nShutting down worker...")
        w.close()
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    # Block until worker closes (scheduler disconnect or signal)
    w.wait_closed()
    typer.echo("Worker closed")
