"""Logs command: view and follow logs from scheduler and workers."""

import json
from datetime import datetime
from typing import Optional

import typer
from rich.console import Console

from frisky.dashboard_client import _get_json


def logs(
    url: str = typer.Option(
        "http://localhost:8787",
        "--url", "-u",
        help="Scheduler dashboard URL.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw JSON instead of formatted output.",
    ),
    level: str = typer.Option(
        "info",
        "--level", "-l",
        help="Minimum log level (trace, debug, info, warn, error).",
    ),
    worker_filter: Optional[str] = typer.Option(
        None,
        "--worker", "-w",
        help="Filter by worker address (use 'scheduler' for scheduler logs).",
    ),
    target: Optional[str] = typer.Option(
        None,
        "--target", "-t",
        help="Filter by target module containing this string.",
    ),
    limit: int = typer.Option(
        50,
        "--limit", "-n",
        help="Maximum number of log entries to show (max 1000).",
    ),
    follow: bool = typer.Option(
        False,
        "--follow", "-f",
        help="Continuously poll for new logs (every 1s).",
    ),
    grep: Optional[str] = typer.Option(
        None,
        "--grep", "-g",
        help="Filter logs containing this text (case-insensitive).",
    ),
) -> None:
    """Show logs from scheduler and workers.

    Query the log buffer for recent entries with optional filtering.

    Examples:

        frisky logs

        frisky logs --level warn

        frisky logs --worker 127.0.0.1:9001

        frisky logs --target scheduler --limit 100

        frisky logs -f  # Follow mode (poll every 1s)

        frisky logs --grep spill  # Filter by message content
    """
    import time

    last_seen_ns: Optional[int] = None

    console = Console()

    api_url = f"{url.rstrip('/')}/api/logs"
    base_params = {
        "level": level or None,
        "worker": worker_filter,
        "target": target,
        "limit": min(limit, 1000),
    }

    def _fetch_logs(since_ns: Optional[int] = None) -> dict:
        try:
            return _get_json(api_url, params={**base_params, "since_ns": since_ns}, timeout=10)
        except Exception as e:
            typer.echo(f"Error: Could not connect to scheduler at {url}: {e}", err=True)
            raise typer.Exit(1)

    def _render_logs(logs_list: list, is_follow: bool = False) -> Optional[int]:
        """Render logs and return the max timestamp seen."""
        if not logs_list:
            if not is_follow:
                console.print("[dim]No logs found[/dim]")
            return None

        max_ts = None
        for log in logs_list:
            ts_ns = log.get("timestamp_ns", 0)
            if max_ts is None or ts_ns > max_ts:
                max_ts = ts_ns

            level_val = log.get("level", "info")
            source = log.get("source", {})
            source_type = source.get("type", "Scheduler") if isinstance(source, dict) else "Scheduler"
            source_addr = source.get("address", "") if isinstance(source, dict) else ""

            # Format timestamp as wall clock time (HH:MM:SS.mmm)
            ts_dt = datetime.fromtimestamp(ts_ns / 1_000_000_000)
            ts_str = ts_dt.strftime("%H:%M:%S") + f".{(ts_ns // 1_000_000) % 1000:03d}"

            # Color by level
            level_colors = {
                "trace": "dim",
                "debug": "dim",
                "info": "white",
                "warn": "yellow",
                "error": "red",
            }
            color = level_colors.get(level_val, "white")
            level_display = level_val.upper()[:5]

            # Format source
            if source_type == "Scheduler":
                src_display = "scheduler"
            else:
                src_display = source_addr  # Full address for distributed workers

            message = log.get("message", "")

            console.print(
                f"[dim]{ts_str}[/dim] [{color}]{level_display:>5}[/{color}] {src_display:>21}  {message}"
            )

        return max_ts

    def _filter_grep(logs_list: list) -> list:
        """Filter logs by grep pattern (case-insensitive)."""
        if not grep:
            return logs_list
        pattern = grep.lower()
        return [log for log in logs_list if pattern in log.get("message", "").lower()]

    if json_output:
        data = _fetch_logs()
        if grep:
            data["logs"] = _filter_grep(data.get("logs", []))
        typer.echo(json.dumps(data, indent=2))
        return

    if follow:
        # Follow mode - poll every 1s
        console.print("[dim]Following logs... (Ctrl+C to stop)[/dim]\n")
        try:
            while True:
                data = _fetch_logs(last_seen_ns)
                logs_list = _filter_grep(data.get("logs", []))
                max_ts = _render_logs(logs_list, is_follow=True)
                if max_ts is not None:
                    last_seen_ns = max_ts
                time.sleep(1)
        except KeyboardInterrupt:
            console.print("\n[dim]Stopped.[/dim]")
    else:
        data = _fetch_logs()
        logs_list = _filter_grep(data.get("logs", []))
        total = data.get("total_in_buffer", 0)
        workers_queried = data.get("workers_queried", 0)
        workers_responded = data.get("workers_responded", 0)
        _render_logs(logs_list)
        if logs_list:
            # Build status message
            parts = [f"showing {len(logs_list)} entries"]
            if workers_queried > 0 and workers_responded < workers_queried:
                parts.append(f"from {workers_responded}/{workers_queried} workers")
            parts.append(f"{total} total in buffer")
            console.print(f"\n[dim]({', '.join(parts)})[/dim]")
