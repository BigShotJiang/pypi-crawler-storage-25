"""Entry point for `python -m frisky.cli`."""

from frisky.cli import app

app()
