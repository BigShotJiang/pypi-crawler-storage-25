"""Spans commands: query and analyze tracing spans."""

import json
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from frisky.dashboard_client import _get_json
from .render import parse_time

spans_app = typer.Typer(
    name="spans",
    help="Query and analyze tracing spans.",
    no_args_is_help=False,
)


def _is_url(source: str) -> bool:
    """Check if source looks like a URL."""
    return source.startswith(("http://", "https://"))


def _fetch_spans_from_url(
    url: str,
    name: Optional[str] = None,
    task: Optional[str] = None,
    limit: int = 100,
) -> list:
    """Fetch spans from scheduler REST API."""
    try:
        data = _get_json(
            f"{url.rstrip('/')}/api/spans",
            params={"name": name, "task": task, "limit": limit},
            timeout=10,
        )
        return data.get("spans", [])
    except Exception as e:
        typer.echo(f"Error: Could not connect to scheduler at {url}: {e}", err=True)
        raise typer.Exit(1)


def _load_spans_from_file(path: str) -> list:
    """Load spans from JSON file."""
    try:
        with open(path) as f:
            data = json.load(f)
        # Support both raw list and {"spans": [...]} format
        if isinstance(data, list):
            return data
        return data.get("spans", data.get("traceEvents", []))
    except Exception as e:
        typer.echo(f"Error reading {path}: {e}", err=True)
        raise typer.Exit(1)


def _load_spans(source: str, name: Optional[str] = None, task: Optional[str] = None, limit: int = 100) -> list:
    """Load spans from URL or file."""
    if _is_url(source):
        return _fetch_spans_from_url(source, name=name, task=task, limit=limit)
    return _load_spans_from_file(source)


@spans_app.callback(invoke_without_command=True)
def spans_default(
    ctx: typer.Context,
    url: Optional[str] = typer.Option(
        None,
        "--url", "-u",
        help="Scheduler dashboard URL (e.g., http://localhost:8787).",
    ),
    name: Optional[str] = typer.Option(
        None,
        "--name", "-n",
        help="Filter by span name prefix (e.g., 'worker.exec', 'spill').",
    ),
    task: Optional[str] = typer.Option(
        None,
        "--task", "-t",
        help="Filter by task key.",
    ),
    limit: int = typer.Option(
        100,
        "--limit", "-l",
        help="Maximum number of spans to return.",
    ),
    table_output: bool = typer.Option(
        False,
        "--table",
        help="Display as formatted table instead of JSON.",
    ),
) -> None:
    """Query tracing spans from a running scheduler.

    Returns JSON by default for programmatic analysis. Use --table for
    human-readable output.

    Examples:

        frisky spans --url http://localhost:8787

        frisky spans -u http://localhost:8787 --name spill --limit 1000

        frisky spans -u http://localhost:8787 --table
    """
    # If a subcommand was invoked, let it handle things
    if ctx.invoked_subcommand is not None:
        return

    # No URL provided - show help
    if url is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    spans_list = _fetch_spans_from_url(url, name=name, task=task, limit=limit)

    if table_output:
        console = Console()
        if not spans_list:
            console.print("[dim]No spans found[/dim]")
            return

        table = Table(title=f"Spans ({len(spans_list)})", expand=True)
        table.add_column("Name", style="cyan", overflow="fold")
        table.add_column("Duration", justify="right")
        table.add_column("Keys", overflow="fold")
        table.add_column("Worker", overflow="fold")

        for span in spans_list:
            duration_ns = span.get("duration_ns") or (span["end_ns"] - span["start_ns"])
            duration_ms = duration_ns / 1_000_000
            keys = span.get("keys", [])
            key_str = ", ".join(keys[:2]) + ("..." if len(keys) > 2 else "")
            worker = span.get("worker", "")

            table.add_row(
                span["name"],
                f"{duration_ms:.2f}ms",
                key_str,
                worker,
            )

        console.print(table)
        return

    # Default: JSON output
    typer.echo(json.dumps(spans_list, indent=2))


@spans_app.command("timeline")
def spans_timeline(
    ctx: typer.Context,
    source: Optional[str] = typer.Argument(
        None,
        help="Source: URL (http://...) or JSON file path.",
    ),
    view: str = typer.Option(
        "detailed",
        "--view", "-v",
        help="View type: 'component', 'worker', 'trace', or 'detailed'.",
    ),
    start: Optional[str] = typer.Option(
        None,
        "--start", "-s",
        help="Start time (e.g., '10ms', '5µs'). Default: auto-detect from spans.",
    ),
    duration: Optional[str] = typer.Option(
        None,
        "--duration", "-d",
        help="Duration (e.g., '100ms', '1s'). Default: auto-detect from spans.",
    ),
    width: int = typer.Option(
        70,
        "--width", "-w",
        help="Character width for the timeline.",
    ),
    prefix: Optional[list[str]] = typer.Option(
        None,
        "--prefix", "-p",
        help="Filter by span name prefix(es). Can be repeated.",
    ),
    worker_idx: Optional[int] = typer.Option(
        None,
        "--worker",
        help="Filter to specific worker index.",
    ),
    trace: Optional[int] = typer.Option(
        None,
        "--trace", "-t",
        help="Filter to specific trace ID (required for 'trace' view).",
    ),
    name: Optional[str] = typer.Option(
        None,
        "--name", "-n",
        help="Span name prefix filter (for live query).",
    ),
    limit: int = typer.Option(
        10000,
        "--limit", "-l",
        help="Max spans to fetch (for live query).",
    ),
) -> None:
    """Render spans as a text-based Gantt chart timeline.

    SOURCE can be a URL (live query) or a JSON file.

    View modes:
    - detailed: All span types on separate rows (default)
    - component: Group by operation type (compute, spill, scheduler)
    - worker: Activity per worker
    - trace: Follow single task through system (requires --trace)

    Examples:

        frisky spans timeline spans.json

        frisky spans timeline spans.json --view component

        frisky spans timeline http://localhost:8787 --limit 10000

        frisky spans timeline spans.json --prefix worker.spill --prefix worker.exec
    """
    from frisky.timeline import render_timeline

    if source is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    spans_list = _load_spans(source, name=name, limit=limit)

    if not spans_list:
        typer.echo("No spans found")
        raise typer.Exit(0)

    # Parse time parameters
    start_ns = None
    if start:
        try:
            start_ns = parse_time(start)
        except ValueError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1)

    duration_ns = None
    if duration:
        try:
            duration_ns = parse_time(duration)
        except ValueError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1)

    output = render_timeline(
        spans_list,
        start=start_ns,
        duration=duration_ns,
        width=width,
        view=view,
        prefixes=prefix,
        worker=worker_idx,
        trace_id=trace,
    )

    typer.echo(output)


@spans_app.command("summary")
def spans_summary(
    ctx: typer.Context,
    source: Optional[str] = typer.Argument(
        None,
        help="Source: URL (http://...) or JSON file path.",
    ),
    name: Optional[str] = typer.Option(
        None,
        "--name", "-n",
        help="Span name prefix filter (for live query).",
    ),
    limit: int = typer.Option(
        10000,
        "--limit", "-l",
        help="Max spans to fetch (for live query).",
    ),
) -> None:
    """Show statistics summary by span name.

    SOURCE can be a URL (live query) or a JSON file.

    Examples:

        frisky spans summary spans.json

        frisky spans summary http://localhost:8787
    """
    from frisky.tracing import summarize_spans

    if source is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    spans_list = _load_spans(source, name=name, limit=limit)

    if not spans_list:
        typer.echo("No spans found")
        raise typer.Exit(0)

    stats = summarize_spans(spans_list)

    console = Console()
    table = Table(title=f"Span Statistics ({len(spans_list)} spans)", expand=True)
    table.add_column("Name", style="cyan", overflow="fold")
    table.add_column("Count", justify="right")
    table.add_column("Total", justify="right")
    table.add_column("Mean", justify="right")
    table.add_column("Max", justify="right")

    for span_name, s in sorted(stats.items(), key=lambda x: -x[1]["total_ms"]):
        table.add_row(
            span_name,
            str(s["count"]),
            f"{s['total_ms']:.2f}ms",
            f"{s['mean_ms']:.2f}ms",
            f"{s['max_ms']:.2f}ms",
        )
    console.print(table)


@spans_app.command("export")
def spans_export(
    ctx: typer.Context,
    source: Optional[str] = typer.Argument(
        None,
        help="Source: URL (http://...) or JSON file path.",
    ),
    output_file: Optional[str] = typer.Argument(
        None,
        help="Output file for Chrome trace format.",
    ),
    name: Optional[str] = typer.Option(
        None,
        "--name", "-n",
        help="Span name prefix filter (for live query).",
    ),
    limit: int = typer.Option(
        50000,
        "--limit", "-l",
        help="Max spans to fetch (for live query).",
    ),
) -> None:
    """Export spans to Chrome trace format.

    SOURCE can be a URL (live query) or a JSON file.
    Open the output file in chrome://tracing.

    Examples:

        frisky spans export spans.json trace.json

        frisky spans export http://localhost:8787 trace.json --limit 50000
    """
    from frisky.chrome import export_chrome_trace

    if source is None or output_file is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)

    spans_list = _load_spans(source, name=name, limit=limit)

    if not spans_list:
        typer.echo("No spans found")
        raise typer.Exit(0)

    export_chrome_trace(spans_list, output_file)
    typer.echo(f"Exported {len(spans_list)} spans to {output_file}")
