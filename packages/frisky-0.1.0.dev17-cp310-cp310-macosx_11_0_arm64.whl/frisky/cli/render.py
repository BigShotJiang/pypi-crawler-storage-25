"""Shared rendering helpers for CLI output."""

import typer
from rich.console import Console
from rich.table import Table

DEFAULT_TOP_N = 10


def parse_time(value: str) -> int:
    """Parse time string like '10ms', '5µs', '1s' to nanoseconds."""
    value = value.strip().lower()
    units = {
        "ns": 1,
        "µs": 1_000,
        "us": 1_000,
        "ms": 1_000_000,
        "s": 1_000_000_000,
    }
    for suffix, multiplier in sorted(units.items(), key=lambda x: -len(x[0])):
        if value.endswith(suffix):
            try:
                return int(float(value[: -len(suffix)]) * multiplier)
            except ValueError:
                raise ValueError(f"Invalid time value: {value}")
    # No suffix, assume nanoseconds
    try:
        return int(float(value))
    except ValueError:
        raise ValueError(f"Invalid time value: {value}")


def parse_memory(s: str) -> int:
    """Parse a memory string like '4GB' or '500MB' to bytes."""
    s = s.strip().upper()
    units = {
        "B": 1,
        "KB": 1024,
        "MB": 1024**2,
        "GB": 1024**3,
        "TB": 1024**4,
        "K": 1024,
        "M": 1024**2,
        "G": 1024**3,
        "T": 1024**4,
    }
    for suffix, multiplier in sorted(units.items(), key=lambda x: -len(x[0])):
        if s.endswith(suffix):
            try:
                return int(float(s[:-len(suffix)]) * multiplier)
            except ValueError:
                raise typer.BadParameter(f"Invalid memory value: {s}")
    # No suffix, assume bytes
    try:
        return int(s)
    except ValueError:
        raise typer.BadParameter(f"Invalid memory value: {s}")


def shorten_key(key: str, max_len: int = 50) -> str:
    """Shorten a task key for display by truncating long hashes."""
    if len(key) <= max_len:
        return key
    # Truncate middle, keeping start and end visible
    half = (max_len - 3) // 2
    return key[:half] + "..." + key[-half:]


def format_bytes(n: int) -> str:
    """Format bytes as human-readable string."""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def format_occupancy(seconds: float) -> str:
    """Format occupancy as human-readable duration."""
    if seconds < 0.001:
        return "0s"
    if seconds < 1:
        return f"{seconds*1000:.0f}ms"
    if seconds < 60:
        return f"{seconds:.1f}s"
    return f"{seconds/60:.1f}m"


def has_io_activity(data: dict) -> bool:
    """Check if any worker has I/O activity (transfers or spills)."""
    for w in data.get("workers", []):
        if (w.get("bytes_produced", 0) > 0 or w.get("bytes_received", 0) > 0 or
            w.get("bytes_sent", 0) > 0 or w.get("spilled_count", 0) > 0):
            return True
    return False


def render_workers_status_table(console: Console, data: dict) -> None:
    """Render workers status table (core metrics)."""
    totals = data.get("totals", {})

    table = Table(title="Workers", expand=True)
    table.add_column("Address", style="cyan", overflow="fold")
    table.add_column("CPU %", justify="right")
    table.add_column("Memory", justify="right")
    table.add_column("Managed", justify="right")
    table.add_column("Occup", justify="right")
    table.add_column("Proc", justify="right")
    table.add_column("Ready", justify="right")
    table.add_column("In Mem", justify="right")

    for w in data.get("workers", []):
        limit = w.get("memory_limit")
        mem_str = format_bytes(w.get("memory_bytes", 0))
        if limit:
            mem_str = f"{mem_str} / {format_bytes(limit)}"
        # Show managed memory with data count for debugging memory accounting
        managed = w.get("managed_memory_bytes", 0)
        data_count = w.get("data_count", 0)
        managed_str = f"{format_bytes(managed)} ({data_count})"
        table.add_row(
            w.get("address", ""),
            f"{w.get('cpu_percent', 0):.0f}",
            mem_str,
            managed_str,
            format_occupancy(w.get("occupancy", 0)),
            str(w.get("processing", 0)),
            str(w.get("ready_count", 0)),
            str(w.get("in_memory", 0)),
        )

    totals_limit = totals.get("memory_limit")
    totals_mem_str = format_bytes(totals.get("memory_bytes", 0))
    if totals_limit:
        totals_mem_str = f"{totals_mem_str} / {format_bytes(totals_limit)}"
    totals_managed = totals.get("managed_memory_bytes", 0)
    totals_data_count = totals.get("data_count", 0)
    totals_managed_str = f"{format_bytes(totals_managed)} ({totals_data_count})"
    table.add_row(
        "[bold]TOTAL[/bold]",
        f"[bold]{totals.get('cpu_percent', 0):.0f}[/bold]",
        f"[bold]{totals_mem_str}[/bold]",
        f"[bold]{totals_managed_str}[/bold]",
        f"[bold]{format_occupancy(totals.get('occupancy', 0))}[/bold]",
        f"[bold]{totals.get('processing', 0)}[/bold]",
        f"[bold]{totals.get('ready_count', 0)}[/bold]",
        f"[bold]{totals.get('in_memory', 0)}[/bold]",
    )

    console.print(table)


def render_workers_io_table(console: Console, data: dict) -> None:
    """Render workers I/O table (transfers and spills). Only call if has_io_activity() is True."""
    totals = data.get("totals", {})

    table = Table(title="Worker I/O", expand=True)
    table.add_column("Address", style="cyan", overflow="fold")
    table.add_column("Produced", justify="right")
    table.add_column("Received", justify="right")
    table.add_column("Sent", justify="right")
    table.add_column("Spilled", justify="right")

    for w in data.get("workers", []):
        spill_str = ""
        if w.get("spilled_count", 0) > 0:
            spill_str = f"{w.get('spilled_count')} ({format_bytes(w.get('spilled_bytes', 0))})"
        table.add_row(
            w.get("address", ""),
            format_bytes(w.get("bytes_produced", 0)) if w.get("bytes_produced", 0) > 0 else "",
            format_bytes(w.get("bytes_received", 0)) if w.get("bytes_received", 0) > 0 else "",
            format_bytes(w.get("bytes_sent", 0)) if w.get("bytes_sent", 0) > 0 else "",
            spill_str,
        )

    totals_spill_str = ""
    if totals.get("spilled_count", 0) > 0:
        totals_spill_str = f"{totals.get('spilled_count')} ({format_bytes(totals.get('spilled_bytes', 0))})"
    table.add_row(
        "[bold]TOTAL[/bold]",
        f"[bold]{format_bytes(totals.get('bytes_produced', 0)) if totals.get('bytes_produced', 0) > 0 else ''}[/bold]",
        f"[bold]{format_bytes(totals.get('bytes_received', 0)) if totals.get('bytes_received', 0) > 0 else ''}[/bold]",
        f"[bold]{format_bytes(totals.get('bytes_sent', 0)) if totals.get('bytes_sent', 0) > 0 else ''}[/bold]",
        f"[bold]{totals_spill_str}[/bold]",
    )

    console.print(table)


def render_workers_table(console: Console, data: dict) -> None:
    """Render workers tables (status + I/O if active)."""
    render_workers_status_table(console, data)
    if has_io_activity(data):
        console.print()  # blank line between tables
        render_workers_io_table(console, data)


def render_prefixes_table(console: Console, data: dict, show_all: bool = False) -> None:
    """Render prefixes table to console."""
    prefix_stats = data.get("prefix_stats", {})

    if not prefix_stats:
        return

    def activity(item):
        s = item[1]
        return -(s.get("waiting", 0) + s.get("queued", 0) + s.get("processing", 0) + s.get("memory", 0)), item[0]

    sorted_prefixes = sorted(prefix_stats.items(), key=activity)

    total_prefixes = len(sorted_prefixes)
    if not show_all and total_prefixes > DEFAULT_TOP_N:
        sorted_prefixes = sorted_prefixes[:DEFAULT_TOP_N]
        truncated = True
    else:
        truncated = False

    table = Table(title="Task Prefixes", expand=True)
    table.add_column("Prefix", style="cyan", overflow="fold")
    table.add_column("Waiting", justify="right")
    table.add_column("Queued", justify="right")
    table.add_column("Processing", justify="right")
    table.add_column("Memory", justify="right")
    table.add_column("Data Size", justify="right")
    table.add_column("Est. Time", justify="right")

    for prefix, stats in sorted_prefixes:
        waiting = stats.get("waiting", 0)
        queued = stats.get("queued", 0)
        proc = stats.get("processing", 0)
        mem = stats.get("memory", 0)
        mem_bytes = stats.get("memory_bytes", 0)
        time_est = stats.get("time_estimate", 0)

        table.add_row(
            prefix,
            str(waiting) if waiting else "",
            str(queued) if queued else "",
            str(proc) if proc else "",
            str(mem) if mem else "",
            format_bytes(mem_bytes) if mem_bytes > 0 else "",
            format_occupancy(time_est) if time_est > 0 else "",
        )

    console.print(table)

    if truncated:
        console.print(f"[dim](showing top {DEFAULT_TOP_N} of {total_prefixes} prefixes, use --all for complete list)[/dim]")
