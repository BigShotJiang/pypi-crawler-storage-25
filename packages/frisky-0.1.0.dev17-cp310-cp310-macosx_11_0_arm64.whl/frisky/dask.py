"""Dask task graph support for Frisky.

Translates dask task graphs to Frisky TaskSpecs for distributed execution.
"""

import cloudpickle
import types
from typing import Any, Dict, List, Tuple
from contextlib import contextmanager

from dask._task_spec import (
    convert_legacy_graph,
    Task,
    DataNode,
    Alias,
    TaskRef,
)
import dask.order

from frisky import record_span, now_ns


@contextmanager
def _span(name: str):
    """Context manager for recording a span."""
    start = now_ns()
    try:
        yield
    finally:
        record_span(name, start, now_ns())


def _make_placeholder(key: Any) -> object:
    """Create placeholder object that worker will resolve from dependency data."""
    ns = types.SimpleNamespace()
    # Convert tuple keys to string representation
    ns.__frisky_future_key__ = str(key) if not isinstance(key, str) else key
    return ns


def _serialize_task(func: callable, args: tuple) -> bytes:
    """Serialize (func, args) to run_spec bytes in Frisky format.

    Format: [4-byte func_len][func_bytes][args_bytes]
    """
    func_bytes = cloudpickle.dumps(func)
    args_bytes = cloudpickle.dumps(args)

    return len(func_bytes).to_bytes(4, "little") + func_bytes + args_bytes


def _replace_futures_in_task(task: "Task") -> "Task":
    """Replace Frisky Futures in task args with TaskRefs.

    This allows tasks that reference persisted futures to be serialized.
    Handles nested structures including DataNodes containing futures.
    """
    from dask._task_spec import Task as DaskTask

    def replace_in_arg(arg):
        if _is_frisky_future(arg):
            return TaskRef(arg.key)
        elif isinstance(arg, DataNode):
            value = arg({})
            if _is_frisky_future(value):
                return TaskRef(value.key)
            return arg
        elif isinstance(arg, Task):
            return _replace_futures_in_task(arg)
        elif isinstance(arg, (list, tuple)):
            return type(arg)([replace_in_arg(a) for a in arg])
        elif isinstance(arg, dict):
            return {k: replace_in_arg(v) for k, v in arg.items()}
        return arg

    new_args = replace_in_arg(task.args)
    return DaskTask(task.key, task.func, new_args)


def _has_futures(obj: Any) -> bool:
    """Check if object contains any Frisky Futures."""
    if _is_frisky_future(obj):
        return True
    if isinstance(obj, DataNode):
        return _is_frisky_future(obj({}))
    if isinstance(obj, Task):
        return _has_futures(obj.args)
    if isinstance(obj, (list, tuple)):
        return any(_has_futures(x) for x in obj)
    if isinstance(obj, dict):
        return any(_has_futures(v) for v in obj.values())
    return False


def _serialize_dask_task(task: "Task", dep_keys_str: List[str], dep_keys_orig: List[Any]) -> bytes:
    """Serialize a dask Task object for execution.

    The Task object's __call__ method knows how to resolve nested
    Tasks/TaskRefs/Aliases when given a values dict.

    We create placeholders for each dependency key, and wrap in a function
    that builds the values dict and calls the task.

    Args:
        task: The dask Task object
        dep_keys_str: Stringified dependency keys (for frisky placeholders)
        dep_keys_orig: Original dependency keys (for Task.__call__ dict)
    """
    # Only replace futures if there are any (to avoid modifying normal tasks)
    if _has_futures(task.args):
        task = _replace_futures_in_task(task)

    # Create placeholders for each dependency - these will be resolved by worker
    dep_placeholders = [_make_placeholder(k) for k in dep_keys_str]

    def execute_task(task_obj, orig_keys, *dep_values):
        """Execute a dask Task with the given dependency values.

        Args:
            task_obj: The dask Task to execute
            orig_keys: List of ORIGINAL dependency keys (may be tuples)
            *dep_values: Values corresponding to each key
        """
        # Build values dict that Task.__call__ expects
        # Keys must be original format (tuples) not stringified
        values = dict(zip(orig_keys, dep_values))
        return task_obj(values)

    func_bytes = cloudpickle.dumps(execute_task)
    # Args: (task_obj, orig_keys, placeholder1, placeholder2, ...)
    args = (task, dep_keys_orig) + tuple(dep_placeholders)
    args_bytes = cloudpickle.dumps(args)

    return len(func_bytes).to_bytes(4, "little") + func_bytes + args_bytes


def _identity(x):
    """Identity function for DataNode and Alias tasks."""
    return x


def _to_dict(dsk: Any) -> Dict[Any, Any]:
    """Convert various graph representations to dict."""
    # Already a dict
    if isinstance(dsk, dict):
        return dict(dsk)
    # HighLevelGraph or similar with to_dict
    if hasattr(dsk, "to_dict"):
        return dsk.to_dict()
    # Expression-based graph (dask 2024+)
    if hasattr(dsk, "__dask_graph__"):
        g = dsk.__dask_graph__()
        if hasattr(g, "to_dict"):
            return g.to_dict()
        return dict(g)
    # Try dict conversion as fallback
    return dict(dsk)


def _is_frisky_future(obj: Any) -> bool:
    """Check if object is a Frisky Future."""
    return type(obj).__name__ == "Future" and hasattr(obj, "key")


def translate_graph(
    dsk: Dict[Any, Any], keys: List[Any]
) -> List[Tuple[str, bytes, List[str], int]]:
    """Convert dask graph to list of Frisky task specs.

    Args:
        dsk: Dask graph dict mapping keys to computations
        keys: Output keys to compute

    Returns:
        List of (key_str, run_spec, dependencies, priority) tuples
    """
    with _span("client.translate_graph"):
        # Convert to dict and normalize to modern format
        dsk = _to_dict(dsk)
        dsk = convert_legacy_graph(dsk)

        # Get priority ordering from dask
        priorities = dask.order.order(dsk)

        tasks = []
        for key, node in dsk.items():
            # Convert key to string for Frisky
            key_str = str(key) if not isinstance(key, str) else key
            priority = priorities.get(key, 0)

            if isinstance(node, DataNode):
                # Literal value - wrap in identity function
                value = node({})
                deps = []
                run_spec = _serialize_task(_identity, (value,))

            elif isinstance(node, Task):
                # Task with function and args - may have nested Tasks/TaskRefs
                # Keep original keys for Task.__call__, stringified for frisky
                deps_orig = list(node.dependencies)
                deps = [str(d) if not isinstance(d, str) else d for d in deps_orig]
                # Use dask Task serialization which handles nested structures
                run_spec = _serialize_dask_task(node, deps, deps_orig)

            elif isinstance(node, Alias):
                # Reference to another key
                target_str = str(node.target) if not isinstance(node.target, str) else node.target
                # If alias points to itself (from a Future), skip - task already exists
                if target_str == key_str:
                    continue
                # Otherwise pass through via identity
                deps = [target_str]
                run_spec = _serialize_task(_identity, (_make_placeholder(node.target),))

            else:
                raise TypeError(f"Unknown node type: {type(node)}")

            tasks.append((key_str, run_spec, deps, priority))

        return tasks


def get(client, dsk: Dict[Any, Any], keys: Any, sync: bool = True) -> Any:
    """Compute dask graph using Frisky scheduler.

    Args:
        client: Frisky Client instance
        dsk: Dask graph dict
        keys: Output key(s) to compute - can be a single key or list of keys
        sync: If True, gather and return results; if False, return futures

    Returns:
        Computed result(s) if sync=True, else Future(s)
    """
    with _span("client.dask_get"):
        # Normalize keys to list
        # Tricky: dask uses tuples as keys (e.g., ('task-name', 0, 1))
        # So we check if keys is a list, otherwise treat as single key
        if isinstance(keys, list):
            keys_list = keys
            singleton = False
        else:
            # Single key (could be string, tuple, or other hashable)
            keys_list = [keys]
            singleton = True

        # Translate graph to Frisky format
        task_specs = translate_graph(dsk, keys_list)

        # Get output key strings
        output_keys = [str(k) if not isinstance(k, str) else k for k in keys_list]

        # Submit all tasks via Rust client method
        with _span("client.submit_graph"):
            futures = client.submit_graph(task_specs, output_keys)

        if sync:
            with _span("client.dask_gather"):
                results = client.gather(futures)
            return results[0] if singleton else results

        return futures[0] if singleton else futures


def compute(client, *collections, sync: bool = True, optimize_graph: bool = True) -> Any:
    """Compute dask collections using Frisky scheduler.

    Args:
        client: Frisky Client instance
        *collections: Dask collections (delayed, array, dataframe, etc.)
        sync: If True, gather and return results; if False, return futures
        optimize_graph: If True, optimize the task graph before computing

    Returns:
        Computed result(s) if sync=True, else Future(s)
    """
    with _span("client.dask_compute"):
        import dask
        from dask.base import unpack_collections, optimize

        # Unpack input - handles nested structures
        if len(collections) == 1:
            collections = collections[0]
            singleton = not isinstance(collections, (list, tuple))
            if singleton:
                collections = [collections]
        else:
            singleton = False
            collections = list(collections)

        # Unpack collections (handles nested Delayed, etc.)
        unpacked, _ = unpack_collections(*collections)

        # Optimize if requested
        if optimize_graph:
            unpacked = list(optimize(*unpacked))

        # Merge all graphs and collect keys and postcompute info
        merged_dsk = {}
        keys = []
        postcomputes = []
        for c in unpacked:
            graph = c.__dask_graph__()
            if hasattr(graph, "to_dict"):
                merged_dsk.update(graph.to_dict())
            else:
                merged_dsk.update(graph)
            keys.append(c.__dask_keys__())
            postcomputes.append(c.__dask_postcompute__())

        flat_keys = list(dask.core.flatten(keys))

        # Submit via get()
        futures = get(client, merged_dsk, flat_keys, sync=False)

        if sync:
            values = client.gather(futures)
        else:
            values = futures

        # Reconstruct per-collection results using __dask_postcompute__
        values_dict = dict(zip(flat_keys, values))

        def repack_keys(keys_structure):
            """Recursively repack values matching the nested key structure."""
            if isinstance(keys_structure, list):
                return [repack_keys(k) for k in keys_structure]
            else:
                # It's a key (tuple), look up the value
                return values_dict[keys_structure]

        out = []
        for coll_keys, (finalize, extra_args) in zip(keys, postcomputes):
            # Repack values in the same nested structure as keys
            coll_values = repack_keys(coll_keys)
            # Use dask's finalize to reconstruct the result (e.g., concatenate array chunks)
            out.append(finalize(coll_values, *extra_args))

        return out[0] if singleton else out


def persist(client, *collections, optimize_graph: bool = True) -> Any:
    """Persist dask collections using Frisky scheduler.

    Submits tasks for the collections and returns new collections backed
    by Futures. Computation proceeds asynchronously in the background.

    Args:
        client: Frisky Client instance
        *collections: Dask collections (delayed, array, dataframe, etc.)
        optimize_graph: If True, optimize the task graph before submitting

    Returns:
        New dask collections backed by Futures (computation in background)
    """
    with _span("client.dask_persist"):
        import dask
        from dask.base import unpack_collections, optimize, flatten

        # Unpack input - collections comes as a list from dask.persist
        if len(collections) == 1:
            collections = collections[0]
            singleton = not isinstance(collections, (list, tuple))
            if singleton:
                collections = [collections]
        else:
            singleton = False
            collections = list(collections)

        # Unpack collections
        unpacked, _ = unpack_collections(*collections)

        # Optimize if requested
        if optimize_graph:
            unpacked = list(optimize(*unpacked))

        # Merge all graphs and collect keys
        merged_dsk = {}
        all_keys = []
        for c in unpacked:
            graph = c.__dask_graph__()
            if hasattr(graph, "to_dict"):
                merged_dsk.update(graph.to_dict())
            else:
                merged_dsk.update(graph)
            all_keys.extend(flatten(c.__dask_keys__()))

        # Submit tasks and get futures (don't wait for results)
        futures = get(client, merged_dsk, all_keys, sync=False)
        futures_dict = dict(zip(all_keys, futures))

        # Rebuild collections using __dask_postpersist__ with Futures
        # This creates collections backed by Futures instead of computed values
        out = []
        for c in unpacked:
            rebuild, state = c.__dask_postpersist__()
            c_keys = list(flatten(c.__dask_keys__()))
            c_futures = {k: futures_dict[k] for k in c_keys}
            new_c = rebuild(c_futures, *state)
            out.append(new_c)

        return out[0] if singleton else out
