"""Frisky - Dask scheduler in Rust."""

import copyreg

# Re-export from the Rust extension
from frisky.frisky import (
    Client,
    Future,
    Scheduler,
    Worker,
    enable_tracing,
    disable_tracing,
    get_spans,
    get_trace_report,
    record_span,
    now_ns,
    enable_validation,
    funcname,
    wait,
    generate_tls_material,
    DEBUG_MODE,
)

# Register pickle support for Future.
# When pickled, Frisky Futures become dask TaskRefs so they work correctly
# in serialized task graphs (e.g., when xarray embeds persisted arrays in
# postcompute methods). On unpickle, dask's graph processing recognizes
# TaskRefs and resolves them to actual data.
def _reduce_future(future):
    from dask._task_spec import TaskRef
    return (TaskRef, (future.key,))

copyreg.pickle(Future, _reduce_future)

# Pure Python
from frisky.cluster import Cluster
from frisky.metrics import get_metrics, print_metrics, reset_metrics
from frisky.timeline import render_timeline
from frisky.chrome import export_chrome_trace
from frisky.tracing import summarize_spans
from frisky.dashboard_client import query_spans, story

# `frisky.dask` and `frisky.hijack` require optional deps (`dask`, `distributed`).
# Re-export them lazily via PEP 562 __getattr__ so `import frisky` works without
# those deps installed. The submodule import (and its deps) only fires when the
# user first accesses `frisky.hijack`, `frisky.dask_get`, etc.
_LAZY_REEXPORTS = {
    "hijack": ("frisky.hijack", "hijack"),
    "dask_get": ("frisky.dask", "get"),
    "dask_compute": ("frisky.dask", "compute"),
    "dask_persist": ("frisky.dask", "persist"),
    "translate_graph": ("frisky.dask", "translate_graph"),
}


def __getattr__(name):
    if name in _LAZY_REEXPORTS:
        import importlib
        module_name, attr_name = _LAZY_REEXPORTS[name]
        value = getattr(importlib.import_module(module_name), attr_name)
        globals()[name] = value  # cache on first access
        return value
    raise AttributeError(f"module 'frisky' has no attribute {name!r}")


__all__ = [
    "Client",
    "Cluster",
    "Future",
    "Scheduler",
    "Worker",
    "get_metrics",
    "print_metrics",
    "reset_metrics",
    "enable_tracing",
    "disable_tracing",
    "get_spans",
    "query_spans",
    "get_trace_report",
    "export_chrome_trace",
    "render_timeline",
    "summarize_spans",
    "enable_validation",
    "funcname",
    "wait",
    "generate_tls_material",
    "dask_get",
    "dask_compute",
    "dask_persist",
    "translate_graph",
    "story",
    "hijack",
]
