"""Metrics display using rich tables."""
from rich.console import Console
from rich.table import Table

from frisky.frisky import get_metrics as _get_metrics, reset_metrics

# Re-export
get_metrics = _get_metrics
__all__ = ["get_metrics", "reset_metrics", "print_metrics"]


def print_metrics():
    """Print performance metrics in a formatted table."""
    console = Console()
    metrics = _get_metrics()

    # Scheduler table
    sched = metrics.get("scheduler", {})
    table = Table(title="Scheduler", show_header=True, header_style="bold")
    table.add_column("Operation", style="cyan")
    table.add_column("Count", justify="right")
    table.add_column("Avg (μs)", justify="right")
    table.add_column("Total (ms)", justify="right")

    # Transitions
    count = int(sched.get("transition_total_count", 0))
    if count > 0:
        total_ms = sched.get("transition_total_ms", 0)
        avg_us = total_ms * 1000 / count if count else 0
        table.add_row("transitions", f"{count:,}", f"{avg_us:.1f}", f"{total_ms:.1f}")

        for name, key in [("  released→waiting", "transition_released_waiting"),
                          ("  waiting→processing", "transition_waiting_processing"),
                          ("  processing→memory", "transition_processing_memory")]:
            c = int(sched.get(f"{key}_count", 0))
            if c > 0:
                avg = sched.get(f"{key}_us", 0)
                tot = avg * c / 1000
                table.add_row(name, f"{c:,}", f"{avg:.1f}", f"{tot:.1f}")

    # Message handlers
    for name, key in [("handle_update_graph", "handle_update_graph"),
                      ("handle_task_finished", "handle_task_finished")]:
        count = int(sched.get(f"{key}_count", 0))
        if count > 0:
            avg = sched.get(f"{key}_us", 0)
            total = sched.get(f"{key}_ms", 0)
            table.add_row(name, f"{count:,}", f"{avg:.1f}", f"{total:.1f}")

    table.add_section()
    table.add_row("tasks_submitted", f"{int(sched.get('tasks_submitted', 0)):,}", "", "")
    table.add_row("tasks_completed", f"{int(sched.get('tasks_completed', 0)):,}", "", "")
    table.add_row("batches_received", f"{int(sched.get('batches_received', 0)):,}", "", "")

    # Message counts (logical vs wire)
    logical_to_workers = int(sched.get('messages_sent_to_workers', 0))
    wire_to_workers = int(sched.get('wire_sends_to_workers', 0))
    logical_to_clients = int(sched.get('messages_sent_to_clients', 0))
    wire_to_clients = int(sched.get('wire_sends_to_clients', 0))

    if wire_to_workers > 0:
        table.add_row("msgs → workers", f"{logical_to_workers:,}", f"wire: {wire_to_workers:,}", "")
    else:
        table.add_row("msgs → workers", f"{logical_to_workers:,}", "", "")
    if wire_to_clients > 0:
        table.add_row("msgs → clients", f"{logical_to_clients:,}", f"wire: {wire_to_clients:,}", "")
    else:
        table.add_row("msgs → clients", f"{logical_to_clients:,}", "", "")

    console.print(table)
    console.print()

    # Worker table
    worker = metrics.get("worker", {})
    table = Table(title="Worker", show_header=True, header_style="bold")
    table.add_column("Operation", style="cyan")
    table.add_column("Count", justify="right")
    table.add_column("Avg (μs)", justify="right")
    table.add_column("Total (ms)", justify="right")

    for name, key in [("task_execute", "task_execute"),
                      ("  acquire_gil", "exec_acquire_gil"),
                      ("  deserialize", "exec_deserialize"),
                      ("  call", "exec_call"),
                      ("  serialize_result", "exec_serialize_result")]:
        count = int(worker.get(f"{key}_count", 0))
        if count > 0:
            avg = worker.get(f"{key}_us", 0)
            total = worker.get(f"{key}_ms", 0)
            table.add_row(name, f"{count:,}", f"{avg:.1f}", f"{total:.1f}")

    table.add_section()
    table.add_row("tasks_executed", f"{int(worker.get('tasks_executed', 0)):,}", "", "")
    table.add_row("tasks_failed", f"{int(worker.get('tasks_failed', 0)):,}", "", "")

    # Message counts (logical vs wire)
    logical_sent = int(worker.get('messages_sent', 0))
    wire_sent = int(worker.get('wire_sends_to_scheduler', 0))
    logical_recv = int(worker.get('messages_received', 0))
    wire_recv = int(worker.get('wire_recv_from_scheduler', 0))

    if wire_sent > 0:
        table.add_row("msgs sent", f"{logical_sent:,}", f"wire: {wire_sent:,}", "")
    else:
        table.add_row("msgs sent", f"{logical_sent:,}", "", "")
    if wire_recv > 0:
        table.add_row("msgs received", f"{logical_recv:,}", f"wire: {wire_recv:,}", "")
    else:
        table.add_row("msgs received", f"{logical_recv:,}", "", "")

    console.print(table)
    console.print()

    # Client table
    python = metrics.get("python", {})
    table = Table(title="Client", show_header=True, header_style="bold")
    table.add_column("Operation", style="cyan")
    table.add_column("Count", justify="right")
    table.add_column("Avg (μs)", justify="right")
    table.add_column("Total (ms)", justify="right")

    for name, key in [("submit_total", "submit_total"),
                      ("cloudpickle_dumps", "cloudpickle_dumps"),
                      ("cloudpickle_loads", "cloudpickle_loads"),
                      ("future_result_wait", "future_result_wait")]:
        count = int(python.get(f"{key}_count", 0))
        if count > 0:
            avg = python.get(f"{key}_us", 0)
            total = python.get(f"{key}_ms", 0)
            table.add_row(name, f"{count:,}", f"{avg:.1f}", f"{total:.1f}")

    table.add_section()
    table.add_row("submits", f"{int(python.get('submits', 0)):,}", "", "")

    console.print(table)
