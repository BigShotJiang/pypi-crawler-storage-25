"""Tests for related domain auto-enrichment in the resolver."""

from __future__ import annotations

import pytest

from recon_tool.models import EvidenceRecord, SourceResult, TenantInfo
from recon_tool.resolver import SourcePool, _enrich_from_related, resolve_tenant


class FakeSource:
    def __init__(self, name: str, result: SourceResult) -> None:
        self._name = name
        self._result = result

    @property
    def name(self) -> str:
        return self._name

    async def lookup(self, domain: str, **kwargs) -> SourceResult:
        return self._result


class TestEnrichFromRelated:
    """Tests for _enrich_from_related — the untested enrichment path."""

    @pytest.mark.asyncio
    async def test_no_related_domains_returns_unchanged(self):
        info = TenantInfo(
            tenant_id="aaa",
            display_name="Test",
            default_domain="test.com",
            queried_domain="test.com",
            related_domains=(),
        )
        enriched, _results = await _enrich_from_related(info, [])
        assert enriched is info  # same object, no change

    @pytest.mark.asyncio
    async def test_onmicrosoft_domains_skipped(self):
        info = TenantInfo(
            tenant_id="aaa",
            display_name="Test",
            default_domain="test.com",
            queried_domain="test.com",
            related_domains=("contoso.onmicrosoft.com",),
        )
        enriched, _results = await _enrich_from_related(info, [])
        assert enriched is info  # onmicrosoft filtered out, no enrichment

    @pytest.mark.asyncio
    async def test_cap_limits_enrichment_candidates(self):
        """More than MAX_RELATED_ENRICHMENTS candidates should be capped."""
        # MAX_RELATED_ENRICHMENTS is 15 (tightened from 25 in v1.0.1). Submit
        # 30 candidates and assert the cap holds.
        related = tuple(f"related{i}.com" for i in range(30))
        info = TenantInfo(
            tenant_id="aaa",
            display_name="Test",
            default_domain="test.com",
            queried_domain="test.com",
            related_domains=related,
        )
        # Real DNS lookups on the fake domains fail gracefully — the point
        # is we don't try all 30.
        _enriched, results = await _enrich_from_related(info, [])
        assert len(results) <= 15

    @pytest.mark.asyncio
    async def test_related_subdomain_evidence_is_merged(self, monkeypatch):
        """Subdomain enrichment should preserve evidence for added services."""

        async def fake_lightweight_lookup(_domain: str) -> SourceResult:
            return SourceResult(
                source_name="dns_records",
                detected_services=("Kartra",),
                detected_slugs=("kartra",),
                evidence=(
                    EvidenceRecord(
                        source_type="CNAME",
                        raw_value="example.kartra.com",
                        rule_name="Kartra",
                        slug="kartra",
                    ),
                ),
            )

        monkeypatch.setattr("recon_tool.sources.dns.lightweight_subdomain_lookup", fake_lightweight_lookup)
        info = TenantInfo(
            tenant_id="aaa",
            display_name="Test",
            default_domain="example.com",
            queried_domain="example.com",
            related_domains=("learn.example.com",),
        )
        enriched, _results = await _enrich_from_related(info, [])
        assert "Kartra" in enriched.services
        assert any(e.source_type == "CNAME" and e.slug == "kartra" for e in enriched.evidence)
        assert ("kartra", "low") in enriched.detection_scores


class TestEnrichmentIntegration:
    """Integration test: resolver discovers related domains and enriches."""

    @pytest.mark.asyncio
    async def test_related_domain_services_merged(self):
        """When a source returns related_domains, the resolver enriches them."""
        primary = SourceResult(
            source_name="s1",
            tenant_id="aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
            detected_services=("Microsoft 365",),
            detected_slugs=("microsoft365",),
            related_domains=(),  # no related domains = no enrichment
        )
        pool = SourcePool([FakeSource("s1", primary)])
        info, _results = await resolve_tenant("example.com", pool=pool)
        assert info.tenant_id == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
