"""
candy.imagegen — Génération d'images via l'API Candy v20
=========================================================

Nouveautés v20 :
  - ImageGen.edit()    — modifier une zone précise (inpainting)
  - ImageGen.upscale() — améliorer la résolution d'une image

Usage :
    from candy import ImageGen

    # Génère une image
    ImageGen.create("un chat astronaute sur la lune", save="chat.png")

    # Avec paramètres avancés
    ImageGen.create(
        "portrait d'un robot steampunk",
        style="photorealistic",
        size="1024x1024",
        save="robot.png"
    )

    # Variation
    ImageGen.variation("original.png", strength=0.6, save="variation.png")

    # Description
    desc = ImageGen.describe("photo.jpg", lang="FR")

    # Batch
    images = ImageGen.batch(["forêt", "ville", "portrait"], save_dir="./output/")

    # Styles disponibles
    print(ImageGen.styles())

    # Édition / inpainting (v20)
    ImageGen.edit("photo.jpg", mask="mask.png", prompt="remplace le fond par un coucher de soleil", save="edited.png")

    # Upscale (v20)
    ImageGen.upscale("small.png", scale=2, save="big.png")
"""

import base64
import json
import time
from pathlib import Path
from typing import Optional, Union
import httpx

CANDY_JSON_URL = "https://client.hubworld.net/candy.json"

_url_cache: Optional[str] = None
_url_cache_time: float = 0
URL_CACHE_TTL = 300


def _get_api_base() -> str:
    global _url_cache, _url_cache_time
    now = time.time()
    if _url_cache and (now - _url_cache_time) < URL_CACHE_TTL:
        return _url_cache
    try:
        r = httpx.get(CANDY_JSON_URL, timeout=10)
        r.raise_for_status()
        d = r.json()
        if d.get("is_closed", True):
            raise RuntimeError("API Candy hors ligne.")
        link = d.get("link", "").strip().rstrip("/")
        if not link:
            raise RuntimeError("Aucun lien API dans candy.json.")
        _url_cache      = link
        _url_cache_time = now
        return link
    except Exception as e:
        raise RuntimeError(f"Impossible de joindre l'API Candy : {e}")


class ImageGenError(Exception):
    pass


class _ImageGen:
    """
    Client de génération d'images via l'API Candy v20.
    Utilise le même tunnel Cloudflare que le reste de candy.
    """

    def create(
        self,
        prompt: str,
        *,
        style:    str   = "default",
        size:     str   = "512x512",
        steps:    int   = 20,
        guidance: float = 7.5,
        negative: str   = "",
        save:     Optional[str] = None,
        timeout:  int   = 120,
    ) -> Union[str, bytes]:
        """
        Génère une image à partir d'un prompt texte.

        Args:
            prompt:   Description de l'image
            style:    "default" "photorealistic" "anime" "painting"
                      "sketch" "3d" "pixel" "watercolor" "oil" "comic"
            size:     "512x512" "768x768" "1024x1024" "1024x768"
            steps:    Nombre de pas de débruitage (10-50)
            guidance: Échelle de guidage (1.0-20.0)
            negative: Prompt négatif (ce qu'on ne veut PAS)
            save:     Chemin de sauvegarde (.png / .jpg)
            timeout:  Timeout en secondes (défaut 120)
        Returns:
            bytes si save=None, sinon str (chemin du fichier sauvegardé)
        """
        base = _get_api_base()
        payload = {
            "prompt":   prompt,
            "style":    style,
            "size":     size,
            "steps":    steps,
            "guidance": guidance,
            "negative": negative,
        }
        try:
            resp = httpx.post(f"{base}/image/create", json=payload, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
        except httpx.TimeoutException:
            raise ImageGenError(f"Timeout après {timeout}s.")
        except Exception as e:
            raise ImageGenError(f"Erreur API : {e}")

        b64    = data.get("image_base64", "")
        fmt    = data.get("format", "png")
        img_bytes = base64.b64decode(b64) if b64 else b""

        if save:
            Path(save).write_bytes(img_bytes)
            print(f"\033[90m[candy] 🎨 Image sauvegardée → {save}\033[0m")
            return save
        return img_bytes

    def variation(
        self,
        image_path: str,
        *,
        strength: float = 0.7,
        prompt:   str   = "",
        save:     Optional[str] = None,
        timeout:  int   = 120,
    ) -> Union[str, bytes]:
        """
        Génère une variation d'une image existante.

        Args:
            image_path: Chemin vers l'image source
            strength:   Force de la variation (0.0 = identique, 1.0 = totalement différent)
            prompt:     Prompt optionnel pour guider la variation
            save:       Chemin de sauvegarde
        """
        base     = _get_api_base()
        img_data = Path(image_path).read_bytes()
        b64_in   = base64.b64encode(img_data).decode()
        payload  = {
            "image_base64": b64_in,
            "strength":     strength,
            "prompt":       prompt,
        }
        try:
            resp = httpx.post(f"{base}/image/variation", json=payload, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            raise ImageGenError(f"Erreur variation : {e}")

        img_bytes = base64.b64decode(data.get("image_base64", ""))
        if save:
            Path(save).write_bytes(img_bytes)
            print(f"\033[90m[candy] 🎨 Variation sauvegardée → {save}\033[0m")
            return save
        return img_bytes

    def describe(
        self,
        image_path: str,
        *,
        lang:    str = "FR",
        detail:  str = "medium",
        timeout: int = 60,
    ) -> str:
        """
        Décrit une image en langage naturel.

        Args:
            image_path: Chemin vers l'image
            lang:       Langue de la description ("FR", "EN", etc.)
            detail:     Niveau de détail — "low" "medium" "high"
        """
        base     = _get_api_base()
        img_data = Path(image_path).read_bytes()
        b64_in   = base64.b64encode(img_data).decode()
        suffix   = Path(image_path).suffix.lstrip(".").lower()
        mime     = "image/jpeg" if suffix in ("jpg", "jpeg") else f"image/{suffix}"
        payload  = {
            "image_base64": b64_in,
            "mime_type":    mime,
            "lang":         lang,
            "detail":       detail,
        }
        try:
            resp = httpx.post(f"{base}/image/describe", json=payload, timeout=timeout)
            resp.raise_for_status()
            return resp.json().get("description", "")
        except Exception as e:
            raise ImageGenError(f"Erreur description : {e}")

    def batch(
        self,
        prompts:     list,
        *,
        style:       str            = "default",
        size:        str            = "512x512",
        save_dir:    Optional[str]  = None,
        timeout:     int            = 120,
    ) -> list:
        """
        Génère plusieurs images d'un coup.

        Args:
            prompts:  Liste de prompts
            style:    Style visuel commun
            size:     Taille commune
            save_dir: Dossier de sauvegarde (sinon retourne liste de bytes)
        Returns:
            Liste de chemins si save_dir, sinon liste de bytes
        """
        results = []
        if save_dir:
            Path(save_dir).mkdir(parents=True, exist_ok=True)
        for i, prompt in enumerate(prompts):
            try:
                save_path = str(Path(save_dir) / f"image_{i+1:03d}.png") if save_dir else None
                result    = self.create(prompt, style=style, size=size,
                                        save=save_path, timeout=timeout)
                results.append(result)
            except Exception as e:
                results.append(f"[ERREUR] {e}")
        return results

    # ── Nouveautés v20 ────────────────────────────────────────────────────────

    def edit(
        self,
        image_path: str,
        *,
        mask:    Optional[str] = None,
        prompt:  str           = "",
        save:    Optional[str] = None,
        timeout: int           = 120,
    ) -> Union[str, bytes]:
        """
        Édite une image existante via inpainting (v20).

        Args:
            image_path: Chemin vers l'image à éditer
            mask:       Chemin vers le masque (zones blanches = à modifier)
                        Si None, le modèle détecte automatiquement les zones
            prompt:     Description de ce qu'on veut mettre à la place
            save:       Chemin de sauvegarde

        Example:
            ImageGen.edit(
                "photo.jpg",
                mask="mask.png",
                prompt="remplace le fond par un coucher de soleil",
                save="edited.png"
            )
        """
        base     = _get_api_base()
        img_data = Path(image_path).read_bytes()
        b64_in   = base64.b64encode(img_data).decode()
        payload: dict = {
            "image_base64": b64_in,
            "prompt":       prompt,
        }
        if mask:
            mask_data      = Path(mask).read_bytes()
            payload["mask_base64"] = base64.b64encode(mask_data).decode()
        try:
            resp = httpx.post(f"{base}/image/edit", json=payload, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            raise ImageGenError(f"Erreur edit : {e}")
        img_bytes = base64.b64decode(data.get("image_base64", ""))
        if save:
            Path(save).write_bytes(img_bytes)
            print(f"\033[90m[candy] ✏️ Image éditée sauvegardée → {save}\033[0m")
            return save
        return img_bytes

    def upscale(
        self,
        image_path: str,
        *,
        scale:   int           = 2,
        save:    Optional[str] = None,
        timeout: int           = 120,
    ) -> Union[str, bytes]:
        """
        Améliore la résolution d'une image (v20).

        Args:
            image_path: Chemin vers l'image basse résolution
            scale:      Facteur d'agrandissement — 2 ou 4
            save:       Chemin de sauvegarde

        Example:
            ImageGen.upscale("small.png", scale=4, save="big.png")
        """
        if scale not in (2, 4):
            raise ValueError("scale doit être 2 ou 4.")
        base     = _get_api_base()
        img_data = Path(image_path).read_bytes()
        b64_in   = base64.b64encode(img_data).decode()
        payload  = {"image_base64": b64_in, "scale": scale}
        try:
            resp = httpx.post(f"{base}/image/upscale", json=payload, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            raise ImageGenError(f"Erreur upscale : {e}")
        img_bytes = base64.b64decode(data.get("image_base64", ""))
        if save:
            Path(save).write_bytes(img_bytes)
            print(f"\033[90m[candy] 🔍 Image upscalée (x{scale}) → {save}\033[0m")
            return save
        return img_bytes

    def styles(self) -> list:
        """Retourne la liste des styles disponibles."""
        return [
            "default", "photorealistic", "anime", "painting",
            "sketch", "3d", "pixel", "watercolor", "oil", "comic",
        ]

    # ── Nouveautés v21 ────────────────────────────────────────────────────────

    def animate(
        self,
        prompt: str,
        *,
        frames:  int           = 8,
        style:   str           = "default",
        size:    str           = "512x512",
        save:    Optional[str] = None,
        timeout: int           = 180,
    ) -> bytes:
        """
        Génère une courte animation GIF / WebP animé depuis un prompt (v21).

        Args:
            prompt:  Description de l'animation
            frames:  Nombre de frames (4, 8 ou 16)
            style:   Style visuel
            size:    Taille de chaque frame
            save:    Chemin de sauvegarde (.gif ou .webp)

        Example:
            ImageGen.animate("un chat qui saute sur une lune", frames=8, save="anim.gif")
        """
        if frames not in (4, 8, 16):
            raise ValueError("frames doit être 4, 8 ou 16.")
        base    = _get_api_base()
        payload = {"prompt": prompt, "frames": frames, "style": style, "size": size}
        try:
            resp = httpx.post(f"{base}/image/animate", json=payload, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            raise ImageGenError(f"Erreur animate : {e}")

        raw = base64.b64decode(data.get("animation_base64", ""))
        if save:
            Path(save).write_bytes(raw)
            fmt = Path(save).suffix.lstrip(".")
            print(f"\033[90m[candy] 🎬 Animation {fmt} sauvegardée → {save}\033[0m")
        return raw

    def style_transfer(
        self,
        content_image: str,
        style_image:   str,
        *,
        strength:      float          = 0.75,
        save:          Optional[str]  = None,
        timeout:       int            = 120,
    ) -> bytes:
        """
        Applique le style d'une image source sur une image cible (v21).

        Args:
            content_image: Image dont on veut garder le contenu
            style_image:   Image dont on veut copier le style artistique
            strength:      Force du transfert (0.0 = contenu pur, 1.0 = style pur)
            save:          Chemin de sauvegarde

        Example:
            ImageGen.style_transfer(
                "mon_portrait.jpg",
                "van_gogh_starry_night.jpg",
                strength=0.8,
                save="portrait_van_gogh.png"
            )
        """
        base     = _get_api_base()
        content  = base64.b64encode(Path(content_image).read_bytes()).decode()
        style    = base64.b64encode(Path(style_image).read_bytes()).decode()
        payload  = {
            "content_base64": content,
            "style_base64":   style,
            "strength":       strength,
        }
        try:
            resp = httpx.post(f"{base}/image/style_transfer", json=payload, timeout=timeout)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            raise ImageGenError(f"Erreur style_transfer : {e}")

        raw = base64.b64decode(data.get("image_base64", ""))
        if save:
            Path(save).write_bytes(raw)
            print(f"\033[90m[candy] 🎨 Style transféré → {save}\033[0m")
        return raw

    def compare_styles(
        self,
        prompt:   str,
        *,
        size:     str           = "512x512",
        save_dir: Optional[str] = None,
        timeout:  int           = 180,
    ) -> dict:
        """
        Génère la même image dans tous les styles disponibles (v21).

        Args:
            prompt:   Description de l'image
            size:     Taille de chaque image
            save_dir: Dossier de sauvegarde (sinon retourne un dict style→bytes)

        Example:
            results = ImageGen.compare_styles("un château médiéval", save_dir="./styles/")
            # → ./styles/default.png, ./styles/anime.png, ./styles/painting.png ...
        """
        results = {}
        if save_dir:
            Path(save_dir).mkdir(parents=True, exist_ok=True)

        for style in self.styles():
            try:
                save_path = str(Path(save_dir) / f"{style}.png") if save_dir else None
                img       = self.create(prompt, style=style, size=size,
                                        save=save_path, timeout=timeout)
                results[style] = img
            except Exception as e:
                results[style] = f"[ERREUR] {e}"

        if save_dir:
            print(f"\033[90m[candy] 🎨 {len(self.styles())} styles générés → {save_dir}\033[0m")
        return results


ImageGen = _ImageGen()
