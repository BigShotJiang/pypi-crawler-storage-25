from .base import BaseModule


class Trading(BaseModule):
    """Trading algorithmique, analyse technique, indicateurs, backtesting, stratégies quantitatives."""
    _personality = "trading"
