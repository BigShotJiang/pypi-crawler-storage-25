from .base import BaseModule


class Full(BaseModule):
    """Polymathe complet : toutes les disciplines combinées."""
    _personality = "full"
