from .base import BaseModule


class Podcast(BaseModule):
    """Création de podcast, production audio, structuration d'épisodes, monétisation, croissance d'audience."""
    _personality = "podcast"
