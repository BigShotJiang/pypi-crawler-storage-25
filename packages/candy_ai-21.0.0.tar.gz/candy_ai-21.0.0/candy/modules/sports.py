from .base import BaseModule


class Sports(BaseModule):
    """Analyse sportive, tactiques, entraînement, statistiques."""
    _personality = "sports"
