from .base import BaseModule


class Venture(BaseModule):
    """Capital risque, due diligence, term sheets, valorisation startups, levées de fonds, exits."""
    _personality = "venture"
