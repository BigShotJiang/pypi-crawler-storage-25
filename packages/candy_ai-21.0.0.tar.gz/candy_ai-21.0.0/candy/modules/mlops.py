from .base import BaseModule


class MLOps(BaseModule):
    """Déploiement de modèles ML, monitoring, CI/CD pour l'IA, feature stores, MLflow, Kubeflow."""
    _personality = "mlops"
