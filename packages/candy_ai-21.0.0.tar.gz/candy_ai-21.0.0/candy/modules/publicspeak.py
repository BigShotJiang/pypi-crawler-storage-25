from .base import BaseModule


class PublicSpeak(BaseModule):
    """Art oratoire, discours persuasifs, gestion du trac, storytelling, préparation de présentations."""
    _personality = "publicspeak"
