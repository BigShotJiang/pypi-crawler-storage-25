from .base import BaseModule


class Bioinformatics(BaseModule):
    """Génomique, séquençage ADN, analyse de séquences, outils bioinformatiques, phylogénétique."""
    _personality = "bioinformatics"
