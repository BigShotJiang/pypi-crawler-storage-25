from .base import BaseModule


class VFX(BaseModule):
    """Effets visuels, compositing, motion capture, pipeline VFX, logiciels After Effects, Nuke."""
    _personality = "vfx"
