from .base import BaseModule


class SupplyChain(BaseModule):
    """Chaîne d'approvisionnement, lean manufacturing, just-in-time, gestion des risques fournisseurs."""
    _personality = "supplychain"
