from .base import BaseModule


class Animation(BaseModule):
    """Animation 2D/3D, storyboard, timing, rigging, rendu, studios et techniques d'animation."""
    _personality = "animation"
