from .base import BaseModule


class Ecommerce(BaseModule):
    """E-commerce, conversion, UX shop, logistique, dropshipping, marketplaces, Shopify."""
    _personality = "ecommerce"
