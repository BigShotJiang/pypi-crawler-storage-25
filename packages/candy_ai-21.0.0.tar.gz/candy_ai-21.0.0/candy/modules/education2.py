from .base import BaseModule


class Education2(BaseModule):
    """Pédagogie innovante, apprentissage adaptatif, neurosciences de l'éducation, edtech, MOOC."""
    _personality = "education2"
