from .base import BaseModule


class Research(BaseModule):
    """Recherche académique, analyse de sources, rédaction scientifique."""
    _personality = "research"
