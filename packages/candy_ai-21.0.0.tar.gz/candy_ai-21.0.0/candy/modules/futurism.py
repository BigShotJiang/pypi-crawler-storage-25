from .base import BaseModule


class Futurism(BaseModule):
    """Futurisme, tendances technologiques, singularité, transhumanisme, prédictions à long terme."""
    _personality = "futurism"
