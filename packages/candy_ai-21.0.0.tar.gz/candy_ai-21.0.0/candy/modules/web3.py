from .base import BaseModule


class Web3(BaseModule):
    """Web3, DAO, tokens, gouvernance décentralisée, interopérabilité blockchain, DApps."""
    _personality = "web3"
