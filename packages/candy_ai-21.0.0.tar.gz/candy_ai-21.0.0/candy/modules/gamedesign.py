from .base import BaseModule


class GameDesign(BaseModule):
    """Game design, mécaniques de jeu, level design, progression, monétisation, expérience joueur."""
    _personality = "gamedesign"
