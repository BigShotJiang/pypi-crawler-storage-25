from .base import BaseModule


class Parenting(BaseModule):
    """Éducation bienveillante, développement de l'enfant, gestion des conflits familiaux, pédagogie positive."""
    _personality = "parenting"
