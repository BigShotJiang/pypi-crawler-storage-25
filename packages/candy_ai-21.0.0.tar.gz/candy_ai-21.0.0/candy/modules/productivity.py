from .base import BaseModule


class Productivity(BaseModule):
    """Efficacité personnelle, gestion du temps, habitudes, systèmes."""
    _personality = "productivity"
