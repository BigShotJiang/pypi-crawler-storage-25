from .base import BaseModule


class IoT(BaseModule):
    """Internet des objets, protocoles MQTT, Arduino, Raspberry Pi, edge computing, sécurité IoT."""
    _personality = "iot"
