from .base import BaseModule


class PublicPolicy(BaseModule):
    """Politiques publiques, analyse d'impact, gouvernance, élaboration de lois, relations avec les institutions."""
    _personality = "publicpolicy"
