from .base import BaseModule


class GameDev(BaseModule):
    """Développement de jeux, Unity, Unreal, level design."""
    _personality = "gamedev"
