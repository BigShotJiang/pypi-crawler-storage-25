from .base import BaseModule


class Sleep(BaseModule):
    """Science du sommeil, chronobiologie, troubles du sommeil, hygiène de sommeil, rêves."""
    _personality = "sleep"
