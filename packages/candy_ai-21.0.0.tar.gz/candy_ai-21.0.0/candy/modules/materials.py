from .base import BaseModule


class Materials(BaseModule):
    """Science des matériaux, nanotechnologies, polymères, métallurgie, matériaux composites."""
    _personality = "materials"
