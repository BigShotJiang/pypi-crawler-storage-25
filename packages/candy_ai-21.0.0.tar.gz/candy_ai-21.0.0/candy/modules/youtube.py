from .base import BaseModule


class Youtube(BaseModule):
    """Création de contenu YouTube, référencement de vidéos, stratégie de chaîne, montage, miniatures, audience."""
    _personality = "youtube"
