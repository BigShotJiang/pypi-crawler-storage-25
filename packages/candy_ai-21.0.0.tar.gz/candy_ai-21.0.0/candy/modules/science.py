from .base import BaseModule


class Science(BaseModule):
    """Sciences : physique, chimie, biologie, astronomie, géologie."""
    _personality = "science"
