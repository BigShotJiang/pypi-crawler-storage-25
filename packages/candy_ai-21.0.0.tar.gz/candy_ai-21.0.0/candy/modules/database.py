from .base import BaseModule


class Database(BaseModule):
    """Architecture BDD, optimisation, SQL vs NoSQL."""
    _personality = "database"
