from .base import BaseModule


class Sports2(BaseModule):
    """Sciences du sport, biomécanique, psychologie sportive, données de performance, wearables."""
    _personality = "sports2"
