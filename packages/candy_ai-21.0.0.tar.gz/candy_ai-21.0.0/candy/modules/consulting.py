from .base import BaseModule


class Consulting(BaseModule):
    """Conseil en stratégie, diagnostic d'entreprise, transformation organisationnelle, présentation executive."""
    _personality = "consulting"
