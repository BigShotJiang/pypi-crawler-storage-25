from .base import BaseModule


class Quantum(BaseModule):
    """Informatique quantique, algorithmes quantiques, Qiskit, portes quantiques, cryptographie post-quantique."""
    _personality = "quantum"
