from .base import BaseModule


class DataScience(BaseModule):
    """Science des données, feature engineering, modélisation, évaluation de modèles, pipelines ML."""
    _personality = "datascience"
