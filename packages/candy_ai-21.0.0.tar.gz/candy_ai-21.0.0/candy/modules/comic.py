from .base import BaseModule


class Comic(BaseModule):
    """Humour, blagues, écriture comique, jeux de mots."""
    _personality = "comic"
