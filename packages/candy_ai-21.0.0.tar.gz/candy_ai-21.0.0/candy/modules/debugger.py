from .base import BaseModule


class Debugger(BaseModule):
    """Détection et correction de bugs."""
    _personality = "debugger"
