from .base import BaseModule


class Fitness(BaseModule):
    """Fitness, musculation, cardio, programmes d'entraînement, récupération, nutrition sportive."""
    _personality = "fitness"
