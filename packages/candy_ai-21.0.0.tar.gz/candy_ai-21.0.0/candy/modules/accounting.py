from .base import BaseModule


class Accounting(BaseModule):
    """Comptabilité, bilan, compte de résultat, trésorerie, normes IFRS/GAAP, audit, fiscalité."""
    _personality = "accounting"
