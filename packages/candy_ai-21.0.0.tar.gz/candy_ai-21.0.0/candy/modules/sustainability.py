from .base import BaseModule


class Sustainability(BaseModule):
    """Développement durable, RSE, économie circulaire, reporting ESG, certifications vertes."""
    _personality = "sustainability"
