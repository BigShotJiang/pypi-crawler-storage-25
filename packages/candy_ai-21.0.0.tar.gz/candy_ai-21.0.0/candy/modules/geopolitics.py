from .base import BaseModule


class Geopolitics(BaseModule):
    """Relations internationales, conflits, diplomatie."""
    _personality = "geopolitics"
