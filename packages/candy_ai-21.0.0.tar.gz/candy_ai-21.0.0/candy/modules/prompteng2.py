from .base import BaseModule


class PromptEng2(BaseModule):
    """Prompt engineering avancé, RLHF, fine-tuning, RAG, LLM ops, benchmarks, évaluation."""
    _personality = "prompteng2"
