from .base import BaseModule


class Neuroscience(BaseModule):
    """Neurosciences, cerveau, cognition, neuroplasticité, troubles neurologiques, imagerie cérébrale."""
    _personality = "neuroscience"
