from .base import BaseModule


class SpaceScience(BaseModule):
    """Science spatiale, missions, propulsion, orbites, colonisation, télescopes, SETI."""
    _personality = "spacescience"
