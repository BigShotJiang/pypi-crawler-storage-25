from .base import BaseModule


class SEO(BaseModule):
    """Référencement naturel, mots-clés, backlinks, SEO technique, content marketing, Core Web Vitals."""
    _personality = "seo"
