from .base import BaseModule


class Cybersecurity(BaseModule):
    """Sécurité offensive et défensive, pentesting, CTF, OWASP, zero-day, forensics, reverse engineering."""
    _personality = "cybersecurity"
