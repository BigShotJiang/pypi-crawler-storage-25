from .base import BaseModule


class Entrepreneur(BaseModule):
    """Startups, MVP, levée de fonds, pitch decks."""
    _personality = "entrepreneur"
