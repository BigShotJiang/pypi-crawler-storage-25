from .base import BaseModule


class Mindfulness(BaseModule):
    """Pleine conscience, gestion du stress, techniques de respiration, thérapie cognitive basée sur la pleine conscience."""
    _personality = "mindfulness"
