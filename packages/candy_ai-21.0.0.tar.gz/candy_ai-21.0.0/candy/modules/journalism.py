from .base import BaseModule


class Journalism(BaseModule):
    """Journalisme d'investigation, rédaction d'articles, vérification des faits, éthique journalistique."""
    _personality = "journalism"
