from .base import BaseModule


class Mythology(BaseModule):
    """Mythologies mondiales, symbolisme, archétypes, comparaison des traditions mythologiques, héros et récits fondateurs."""
    _personality = "mythology"
