from .base import BaseModule


class Finance(BaseModule):
    """Finance personnelle, investissement, comptabilité, économie."""
    _personality = "finance"
