from .base import BaseModule


class Analytic(BaseModule):
    """Analyse de données, statistiques, pandas, numpy, R, SQL, visualisation."""
    _personality = "analytic"
