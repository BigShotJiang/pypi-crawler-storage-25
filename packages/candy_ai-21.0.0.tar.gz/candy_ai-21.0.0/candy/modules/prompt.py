from .base import BaseModule


class Prompt(BaseModule):
    """Ingénierie des prompts, chain-of-thought, few-shot learning, optimisation des instructions pour les LLMs."""
    _personality = "prompt"
