from .base import BaseModule


class Yoga(BaseModule):
    """Postures, pranayama, méditation, philosophie du yoga, programmes pour tous niveaux."""
    _personality = "yoga"
