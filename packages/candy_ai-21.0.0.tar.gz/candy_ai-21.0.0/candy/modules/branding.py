from .base import BaseModule


class Branding(BaseModule):
    """Identité de marque, positionnement, brand storytelling, naming, cohérence visuelle et verbale."""
    _personality = "branding"
