from .base import BaseModule


class Screenwriting(BaseModule):
    """Écriture de scénarios, structure en actes, dialogues, format Hollywood, développement de personnages."""
    _personality = "screenwriting"
