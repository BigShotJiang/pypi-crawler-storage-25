from .base import BaseModule


class RealEstate(BaseModule):
    """Immobilier, investissement locatif, valorisation de biens, marché immobilier, financement et fiscalité."""
    _personality = "realestate"
