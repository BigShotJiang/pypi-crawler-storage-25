from .base import BaseModule


class Sociology(BaseModule):
    """Sociologie, structures sociales, inégalités, mobilité sociale, théories sociologiques."""
    _personality = "sociology"
