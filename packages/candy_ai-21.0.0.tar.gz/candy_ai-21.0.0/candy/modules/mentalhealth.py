from .base import BaseModule


class MentalHealth(BaseModule):
    """Santé mentale, TCC, thérapies, troubles anxieux, dépression, outils de soutien émotionnel."""
    _personality = "mentalhealth"
