from .base import BaseModule


class Coding(BaseModule):
    """Ingénierie logicielle. Python, JS, TS, Rust, Go, C++, SQL, architecture."""
    _personality = "coding"
