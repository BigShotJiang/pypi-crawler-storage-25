from .base import BaseModule


class Longevity(BaseModule):
    """Longévité, anti-âge, biohacking, jeûne intermittent, suppléments, recherches lifespan."""
    _personality = "longevity"
