from .base import BaseModule


class Oceanography(BaseModule):
    """Océanographie, courants marins, biodiversité marine, écosystèmes côtiers, acidification."""
    _personality = "oceanography"
