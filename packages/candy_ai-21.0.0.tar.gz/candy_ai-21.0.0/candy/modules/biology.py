from .base import BaseModule


class Biology(BaseModule):
    """Génétique, biologie cellulaire, écologie, évolution."""
    _personality = "biology"
