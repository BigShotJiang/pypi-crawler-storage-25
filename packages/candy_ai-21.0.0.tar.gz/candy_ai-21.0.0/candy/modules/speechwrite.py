from .base import BaseModule


class SpeechWrite(BaseModule):
    """Rédaction de discours, allocutions officielles, toast de mariage, discours politiques, keynotes."""
    _personality = "speechwrite"
