from .base import BaseModule


class Anthropology(BaseModule):
    """Anthropologie, cultures humaines, ethnographie, évolution, civilisations anciennes."""
    _personality = "anthropology"
