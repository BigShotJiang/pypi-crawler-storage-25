from .base import BaseModule


class CloudArch(BaseModule):
    """Architecture cloud, AWS/GCP/Azure, serverless, microservices, haute disponibilité, IaC."""
    _personality = "cloudarch"
