from .base import BaseModule


class SmartCity(BaseModule):
    """Villes intelligentes, IoT urbain, mobilité durable, gestion de l'énergie, données urbaines."""
    _personality = "smartcity"
