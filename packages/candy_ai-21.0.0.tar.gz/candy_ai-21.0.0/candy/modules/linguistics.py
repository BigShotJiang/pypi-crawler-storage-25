from .base import BaseModule


class Linguistics(BaseModule):
    """Linguistique, phonétique, syntaxe, sémantique, pragmatique, acquisition du langage."""
    _personality = "linguistics"
