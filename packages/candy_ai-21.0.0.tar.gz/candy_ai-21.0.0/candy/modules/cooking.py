from .base import BaseModule


class Cooking(BaseModule):
    """Chef professionnel et nutritionniste. Recettes, techniques, nutrition."""
    _personality = "cooking"
