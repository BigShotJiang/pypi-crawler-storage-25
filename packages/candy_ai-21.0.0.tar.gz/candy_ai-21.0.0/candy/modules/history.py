from .base import BaseModule


class History(BaseModule):
    """Histoire mondiale de l'Antiquité à nos jours."""
    _personality = "history"
