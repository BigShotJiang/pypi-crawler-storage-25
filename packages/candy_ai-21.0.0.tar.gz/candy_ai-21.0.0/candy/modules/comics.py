from .base import BaseModule


class Comics(BaseModule):
    """Création de bandes dessinées, scénarisation, découpage, bulles, narration visuelle."""
    _personality = "comics"
