from .base import BaseModule


class Math(BaseModule):
    """Mathématiques : algèbre, calcul, géométrie, statistiques, probabilités."""
    _personality = "math"
