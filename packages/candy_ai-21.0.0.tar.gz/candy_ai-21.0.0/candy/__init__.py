"""
🍬 candy v21 — Python framework for Cedric8-Thinking — Python framework for Cedric8-Thinking
One-liner · Multi-agents · Memory · Smart · Monitor · CLI v19 · 120 personalities
"""

from .banner import show_banner
show_banner()

from .config import config as cfg, get_profile, list_profiles
from .client import CandyClient, CandyUnavailableError, CandyQuotaError, CandyTimeoutError
from .conversation import Conversation
from .helper import Helper
from .core import (
    Candy, Agent, Memory, Logger,
    ask_validated, ask_json,
    _detect_personality as detect_personality,
)
from .monitor import Monitor
from .imagegen import ImageGen, ImageGenError
from .smart import Smart
from .mix import Mix, Chain
from .compare import Compare
from .auto_memory import AutoMemory
from .logger import CandyLogger
from . import utils
from .utils import (
    detect_lang, translate, summarize, spellcheck, keywords,
    sentiment, generate_title, ask_about, rephrase, generate_faq,
    compare, codegen, explain_code, mock_data, timed_ask,
    cached_ask, clear_cache, optimize_prompt, extract,
    pipeline, full_report
)

# ── 50 personnalités originales ──────────────────────────────────────────────
from .modules.math import Math
from .modules.reflexion import Reflexion
from .modules.coding import Coding
from .modules.analytic import Analytic
from .modules.full import Full
from .modules.science import Science
from .modules.writing import Writing
from .modules.history import History
from .modules.law import Law
from .modules.medicine import Medicine
from .modules.finance import Finance
from .modules.marketing import Marketing
from .modules.security import Security
from .modules.design import Design
from .modules.language import Language
from .modules.psychology import Psychology
from .modules.education import Education
from .modules.research import Research
from .modules.business import Business
from .modules.productivity import Productivity
from .modules.cooking import Cooking
from .modules.travel import Travel
from .modules.music import Music
from .modules.film import Film
from .modules.sports import Sports
from .modules.philosophy import Philosophy
from .modules.environment import Environment
from .modules.architecture import Architecture
from .modules.automotive import Automotive
from .modules.astronomy import Astronomy
from .modules.biology import Biology
from .modules.chemistry import Chemistry
from .modules.physics import Physics
from .modules.engineering import Engineering
from .modules.entrepreneur import Entrepreneur
from .modules.ethics import Ethics
from .modules.geopolitics import Geopolitics
from .modules.crypto import Crypto
from .modules.ai import AI
from .modules.devops import DevOps
from .modules.database import Database
from .modules.gamedev import GameDev
from .modules.comic import Comic
from .modules.storyteller import Storyteller
from .modules.translator import Translator
from .modules.summarizer import Summarizer
from .modules.debugger import Debugger
from .modules.reviewer import Reviewer
from .modules.planner import Planner
from .modules.tutor import Tutor

# ── 40 nouvelles personnalités v13 ───────────────────────────────────────────
from .modules.nutrition import Nutrition
from .modules.yoga import Yoga
from .modules.mindfulness import Mindfulness
from .modules.parenting import Parenting
from .modules.relationship import Relationship
from .modules.leadership import Leadership
from .modules.negotiation import Negotiation
from .modules.publicspeak import PublicSpeak
from .modules.branding import Branding
from .modules.uxresearch import UXResearch
from .modules.datavis import DataVis
from .modules.mlops import MLOps
from .modules.prompt import Prompt
from .modules.blockchain import Blockchain
from .modules.iot import IoT
from .modules.ar_vr import ArVr
from .modules.quantum import Quantum
from .modules.robotics import Robotics
from .modules.bioinformatics import Bioinformatics
from .modules.climatetech import ClimateTech
from .modules.agri import Agri
from .modules.interior import Interior
from .modules.fashion import Fashion
from .modules.photography import Photography
from .modules.podcast import Podcast
from .modules.youtube import Youtube
from .modules.socialmedia import SocialMedia
from .modules.seo import SEO
from .modules.copywriting import Copywriting
from .modules.taxlaw import TaxLaw
from .modules.realestate import RealEstate
from .modules.insurance import Insurance
from .modules.logistics import Logistics
from .modules.hrm import HRM
from .modules.projectmgmt import ProjectMgmt
from .modules.consulting import Consulting
from .modules.publicpolicy import PublicPolicy
from .modules.journalism import Journalism
from .modules.speechwrite import SpeechWrite
from .modules.mythology import Mythology

__version__ = "21.0.0"
__author__  = "Cedric8-Thinking Engine"

# ── 30 nouvelles personnalités v17/v19/v21 (120 total) ───────────────────────────────
from .modules.screenwriting import Screenwriting
from .modules.comics import Comics
from .modules.animation import Animation
from .modules.gamedesign import GameDesign
from .modules.vfx import VFX
from .modules.cybersecurity import Cybersecurity
from .modules.cloudarch import CloudArch
from .modules.datascience import DataScience
from .modules.neuroscience import Neuroscience
from .modules.spacescience import SpaceScience
from .modules.materials import Materials
from .modules.oceanography import Oceanography
from .modules.venture import Venture
from .modules.trading import Trading
from .modules.ecommerce import Ecommerce
from .modules.supplychain import SupplyChain
from .modules.accounting import Accounting
from .modules.mentalhealth import MentalHealth
from .modules.fitness import Fitness
from .modules.sleep import Sleep
from .modules.longevity import Longevity
from .modules.sociology import Sociology
from .modules.linguistics import Linguistics
from .modules.anthropology import Anthropology
from .modules.education2 import Education2
from .modules.sports2 import Sports2
from .modules.futurism import Futurism
from .modules.sustainability import Sustainability
from .modules.smartcity import SmartCity
from .modules.web3 import Web3
from .modules.prompteng2 import PromptEng2
