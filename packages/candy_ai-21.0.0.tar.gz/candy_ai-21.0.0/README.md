# 🍬 candy-ai v21

**Framework IA Python professionnel** — Cedric8-Thinking Engine

```bash
pip install candy-ai
```

---

## 🆕 Nouveautés v21

### 🧠 AutoMemory — Mémoire inter-sessions
```python
from candy import AutoMemory, Coding

AutoMemory.enable()

chat = Coding.chat()
chat.say("Je préfère toujours des réponses en français")
chat.say("Je travaille sur un projet FastAPI avec Python 3.12")

# La prochaine session, candy s'en souvient automatiquement
chat2 = Coding.chat()

print(AutoMemory.summary())
AutoMemory.remember("Mon stack : React + FastAPI + PostgreSQL")
AutoMemory.forget()    # tout effacer
AutoMemory.disable()
```

### 🔀 Compare — Même prompt, plusieurs personnalités
```python
from candy import Compare, Coding, Security, Reviewer

result = Compare(Coding, Security, Reviewer).ask("Comment sécuriser une API REST ?")
result.show()               # affichage formaté
print(result["coding"])
name, resp = result.best()  # la plus longue
md = result.to_markdown()

# Async — toutes en parallèle
import asyncio
result = asyncio.run(Compare(Coding, Security).ask_async("..."))
```

### 📝 stream_to_file — Génération longue sans saturer la RAM
```python
from candy import Writing, Coding

Writing.stream_to_file(
    "roman.txt",
    "Écris un roman de science-fiction de 5000 mots",
    show_progress=True
)
# → [candy] ✓ 24,831 chars → roman.txt  (18.3s)

Coding.stream_to_file("api.py", "Génère une API REST complète avec FastAPI")
Writing.stream_to_file("journal.txt", "Entrée du jour...", append=True)
```

### 📋 CandyLogger — Logs structurés JSON
```python
from candy import CandyLogger, Coding

CandyLogger.enable()               # ~/.candy/logs/candy.jsonl

Coding.ask("Write a sort")         # loggué automatiquement

CandyLogger.tail(n=10)
print(CandyLogger.stats())
# → {"total_calls": 42, "avg_latency_ms": 312, "top_personality": "coding"}
logs = CandyLogger.read(last_n=50, personality="coding")
CandyLogger.clear()
```

### 🎨 ImageGen — Animate, StyleTransfer, CompareStyles
```python
from candy import ImageGen

ImageGen.animate("un chat qui saute sur la lune", frames=8, save="anim.gif")

ImageGen.style_transfer(
    "mon_portrait.jpg",
    "van_gogh.jpg",
    strength=0.8,
    save="portrait_van_gogh.png"
)

ImageGen.compare_styles("un château médiéval", save_dir="./styles/")
# → styles/default.png, styles/anime.png, styles/painting.png ...
```

### 🖥️ CLI — candy logs
```bash
candy logs              # 10 derniers appels
candy logs --n 50       # 50 derniers
candy logs --stats      # statistiques
candy logs --clear      # vider
```

---

## Fonctionnalités v20 (toutes conservées)

Async, Mix, Chain, Retry, Cache offline, Conversation+ (titre, compression, export MD), ImageGen Edit/Upscale, CLI doctor/update.

---

## Quick Start

```python
from candy import Coding
print(Coding.ask("Write a binary search in Python"))
```

## Streaming

```python
for token in Writing.stream("Raconte une histoire"):
    print(token, end="", flush=True)
```

## 120 personnalités disponibles

Math, Coding, Writing, Medicine, Law, Finance, Security, Design, Psychology, Education, Research, Business, Cooking, Travel, Music, Film, Philosophy, Engineering, Crypto, AI, DevOps, Screenwriting, Comics, Animation, DataScience, Neuroscience, Trading, MentalHealth, Fitness, Sustainability... et 90 autres.

---

## Powered by Cedric8-Thinking · MIT License
