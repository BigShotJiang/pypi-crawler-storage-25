import os
import time
import gc
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from transformers import PreTrainedModel, PreTrainedTokenizer
from amazingvmsloth.optimizer import create_optimizer
from amazingvmsloth.gradient import GradientAccumulator, enable_gradient_checkpointing, set_gradient_requirements
from amazingvmsloth.packing import SmartCollator, prepack_dataset, BatchCollator


def _detect_cpu_features():
    """Detect CPU capabilities for optimal dtype selection."""
    info = {"avx512_bf16": False, "avx512": False, "avx2": False, "cores": os.cpu_count() or 4}
    try:
        import cpuinfo
        flags = cpuinfo.get_cpu_info().get("flags", [])
        info["avx512_bf16"] = "avx512_bf16" in flags or "avx512bf" in flags
        info["avx512"] = "avx512f" in flags
        info["avx2"] = "avx2" in flags
    except Exception:
        pass
    return info


def optimize_cpu():
    if torch.cuda.is_available():
        return False, {}

    # Optimal thread count: physical cores, not hyperthreads
    cpu_count = os.cpu_count() or 4
    optimal_threads = max(1, cpu_count // 2) if cpu_count > 4 else cpu_count
    
    # Set BEFORE any PyTorch operations
    torch.set_num_threads(optimal_threads)
    os.environ.setdefault("OMP_NUM_THREADS", str(optimal_threads))
    os.environ.setdefault("MKL_NUM_THREADS", str(optimal_threads))
    os.environ.setdefault("OPENBLAS_NUM_THREADS", str(optimal_threads))
    os.environ.setdefault("VECLIB_MAXIMUM_THREADS", str(optimal_threads))
    os.environ.setdefault("NUMEXPR_NUM_THREADS", str(optimal_threads))

    # MKL settings
    try:
        if hasattr(torch.backends, 'mkl') and torch.backends.mkl.is_available():
            torch.backends.mkl.set_num_threads(optimal_threads)
    except Exception:
        pass

    # IPEX detection and optimization
    ipex_available = False
    try:
        import intel_extension_for_pytorch as ipex
        ipex_available = True
    except ImportError:
        pass

    # CPU features
    features = _detect_cpu_features()
    
    print(f"[amazingvmsloth] CPU Optimization:")
    print(f"  Threads:       {torch.get_num_threads()} (of {cpu_count} logical)")
    print(f"  AVX-512 BF16:  {'Yes' if features['avx512_bf16'] else 'No'}")
    print(f"  IPEX:          {'Yes (2-4x speedup available)' if ipex_available else 'No (pip install intel-extension-for-pytorch)'}")
    print(f"  torch.compile: {'Available' if hasattr(torch, 'compile') else 'No'}")
    
    return ipex_available, features


@dataclass
class CpuTrainingConfig:
    output_dir: str = "./output"
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 1
    gradient_accumulation_steps: int = 16
    learning_rate: float = 2e-4
    weight_decay: float = 0.01
    warmup_ratio: float = 0.1
    max_grad_norm: float = 1.0
    logging_steps: int = 10
    save_steps: int = 500
    max_seq_length: int = 512
    seed: int = 42
    optim: str = "adamw"
    quant: str = "none"  # CPU: don't use bnb quantization, use fp32 or bf16
    compile_model: bool = True  # torch.compile gives big speedup on CPU
    use_ipex: bool = True
    use_prepacking: bool = True
    dtype: str = "auto"  # auto, fp32, bf16, fp16
    gradient_checkpointing: bool = False  # trades compute for memory
    low_ram: bool = False  # aggressive memory optimization


class CpuTrainer:
    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizer,
        train_dataset,
        config: Optional[CpuTrainingConfig] = None,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.train_dataset = train_dataset
        self.config = config or CpuTrainingConfig()
        self._global_step = 0
        self._start_time = None
        self._trainable_params = []

    def train(self) -> Dict[str, Any]:
        ipex_available, features = optimize_cpu()

        self._setup(ipex_available)

        self._start_time = time.time()
        accumulator = GradientAccumulator(self.config.gradient_accumulation_steps)
        model = self.model
        optimizer = self.optimizer
        scheduler = self.scheduler

        # torch.compile for CPU - significant speedup for repeated shapes
        if self.config.compile_model and hasattr(torch, "compile"):
            try:
                model = torch.compile(model, mode="reduce-overhead")
                print("[amazingvmsloth] Model compiled with torch.compile (CPU)")
            except Exception as e:
                print(f"[amazingvmsloth] torch.compile failed: {e}")

        # IPEX optimization if available
        if ipex_available and self.config.use_ipex:
            try:
                import intel_extension_for_pytorch as ipex
                model, optimizer = ipex.optimize(model, optimizer=optimizer, dtype=self._dtype)
                print("[amazingvmsloth] IPEX optimization applied")
            except Exception as e:
                print(f"[amazingvmsloth] IPEX optimization failed: {e}")

        total_steps = len(self.dataloader) * self.config.num_train_epochs // self.config.gradient_accumulation_steps
        total_steps = max(1, total_steps)

        print(f"\n{'='*60}")
        print(f"  amazingvmsloth CPU Training")
        print(f"{'='*60}")
        print(f"  Model:         {getattr(model, 'name_or_path', 'unknown')}")
        print(f"  Dtype:         {self._dtype}")
        print(f"  Quantization:  {self.config.quant}")
        print(f"  Optimizer:     {self.config.optim}")
        print(f"  Batch size:    {self.config.per_device_train_batch_size}")
        print(f"  Grad accum:    {self.config.gradient_accumulation_steps}")
        print(f"  Threads:       {torch.get_num_threads()}")
        print(f"  Total steps:   {total_steps}")
        print(f"{'='*60}\n")

        # Track if we need to fall back from torch.compile
        compile_failed = False
        uncompiled_model = None

        for epoch in range(self.config.num_train_epochs):
            model.train()
            epoch_loss = 0.0
            step_count = 0
            data_step = 0
            n_batches = len(self.dataloader)

            from tqdm import tqdm
            pbar = tqdm(self.dataloader, total=n_batches, desc=f"Epoch {epoch+1}/{self.config.num_train_epochs}", unit="batch")

            for batch in pbar:
                data_step += 1

                # CPU tensors are already on CPU
                batch_dict = {
                    k: v if isinstance(v, torch.Tensor) else v
                    for k, v in batch.items()
                }

                # Try forward pass; fall back from torch.compile if it fails
                try:
                    # Mixed precision autocast for bf16 on supported CPUs
                    if self._dtype == torch.bfloat16 and features.get("avx512_bf16"):
                        with torch.autocast(device_type="cpu", dtype=torch.bfloat16):
                            outputs = model(**batch_dict)
                            loss = outputs.loss if hasattr(outputs, "loss") else outputs["loss"]
                    else:
                        outputs = model(**batch_dict)
                        loss = outputs.loss if hasattr(outputs, "loss") else outputs["loss"]
                except Exception as e:
                    if self.config.compile_model and not compile_failed:
                        print(f"[amazingvmsloth] torch.compile failed at runtime: {e}")
                        print("[amazingvmsloth] Falling back to non-compiled model...")
                        compile_failed = True
                        # On first failure, save the uncompiled model reference and swap
                        if uncompiled_model is None:
                            uncompiled_model = self.model
                        model = uncompiled_model
                        # Retry with uncompiled model
                        if self._dtype == torch.bfloat16 and features.get("avx512_bf16"):
                            with torch.autocast(device_type="cpu", dtype=torch.bfloat16):
                                outputs = model(**batch_dict)
                                loss = outputs.loss if hasattr(outputs, "loss") else outputs["loss"]
                        else:
                            outputs = model(**batch_dict)
                            loss = outputs.loss if hasattr(outputs, "loss") else outputs["loss"]
                    else:
                        raise

                scaled_loss = accumulator.accumulate(loss)
                scaled_loss.backward()

                if accumulator.should_step() or data_step == n_batches:
                    if self.config.max_grad_norm > 0:
                        nn.utils.clip_grad_norm_(
                            self._trainable_params,
                            self.config.max_grad_norm,
                        )

                    optimizer.step()
                    scheduler.step()
                    optimizer.zero_grad(set_to_none=True)

                    self._global_step += 1
                    epoch_loss += accumulator.mean_loss
                    step_count += 1
                    accumulator.reset()

                    # Update progress bar with live loss
                    avg_loss = epoch_loss / max(step_count, 1)
                    pbar.set_postfix({"loss": f"{avg_loss:.4f}", "step": self._global_step})

                    if self._global_step % self.config.logging_steps == 0:
                        elapsed = time.time() - self._start_time
                        steps_per_sec = self._global_step / elapsed if elapsed > 0 else 0
                        lr = scheduler.get_last_lr()[0]
                        avg_loss = epoch_loss / max(step_count, 1)
                        remaining = total_steps - self._global_step
                        eta = remaining / steps_per_sec if steps_per_sec > 0 else 0
                        eta_str = f"{int(eta)//60}m{int(eta)%60}s"

                        ram_mb = 0
                        try:
                            import psutil
                            ram_mb = psutil.Process().memory_info().rss / 1024**2
                        except Exception:
                            pass

                        print(
                            f"Epoch [{epoch+1}/{self.config.num_train_epochs}] "
                            f"Step [{self._global_step}/{total_steps}] "
                            f"Loss: {avg_loss:.4f} | "
                            f"LR: {lr:.2e} | "
                            f"Speed: {steps_per_sec:.2f} steps/s | "
                            f"RAM: {ram_mb:.0f}MB | "
                            f"ETA: {eta_str}"
                        )

            avg_loss = epoch_loss / max(step_count, 1)
            elapsed = time.time() - self._start_time
            print(f"\nEpoch {epoch+1}/{self.config.num_train_epochs} | Loss: {avg_loss:.4f} | Time: {elapsed:.0f}s")

        self._save()
        total_time = time.time() - self._start_time
        print(f"\n{'='*60}")
        print(f"  CPU Training complete in {total_time:.1f}s ({self._global_step} steps)")
        print(f"{'='*60}")

        return {"global_step": self._global_step, "training_time": total_time}

    def _setup(self, ipex_available: bool = False):
        torch.manual_seed(self.config.seed)

        # Determine optimal dtype
        if self.config.dtype == "auto":
            if ipex_available:
                self._dtype = torch.bfloat16  # IPEX works great with bf16
            else:
                self._dtype = torch.float32  # Safe default
        elif self.config.dtype == "bf16":
            self._dtype = torch.bfloat16
        elif self.config.dtype == "fp16":
            self._dtype = torch.float16
        else:
            self._dtype = torch.float32

        # Convert model to optimal dtype if not already
        if self._dtype != torch.float32:
            print(f"[amazingvmsloth] Converting model to {self._dtype} for CPU training")
            self.model = self.model.to(self._dtype)

        if self.config.gradient_checkpointing:
            print("[amazingvmsloth] Gradient checkpointing enabled (saves RAM, slower)")
            enable_gradient_checkpointing(self.model)
        set_gradient_requirements(self.model)
        self._trainable_params = [p for p in self.model.parameters() if p.requires_grad]

        pad_id = 0
        if self.tokenizer:
            pad_id = self.tokenizer.pad_token_id or self.tokenizer.eos_token_id or 0

        # Use pre-packing for CPU too if enabled
        if self.config.use_prepacking:
            from amazingvmsloth.packing import prepack_dataset
            packed = prepack_dataset(self.train_dataset, self.tokenizer, max_seq_length=self.config.max_seq_length)
            print(f"[amazingvmsloth] Pre-packed into {len(packed)} chunks")
            collator = BatchCollator()
            dataset = packed
        else:
            collator = SmartCollator(
                max_seq_length=self.config.max_seq_length,
                pad_token_id=pad_id,
            )
            dataset = self.train_dataset

        self.dataloader = DataLoader(
            dataset,
            batch_size=self.config.per_device_train_batch_size,
            shuffle=True,
            collate_fn=collator,
            num_workers=0,
            pin_memory=False,
        )

        self.optimizer = create_optimizer(
            self.model,
            optimizer_type=self.config.optim,
            lr=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
        )

        from transformers import get_cosine_schedule_with_warmup
        total_steps = max(1, len(self.dataloader) * self.config.num_train_epochs // self.config.gradient_accumulation_steps)
        warmup = max(1, int(total_steps * self.config.warmup_ratio))
        self.scheduler = get_cosine_schedule_with_warmup(
            self.optimizer,
            num_warmup_steps=warmup,
            num_training_steps=total_steps,
        )

    def _save(self):
        os.makedirs(self.config.output_dir, exist_ok=True)
        model_to_save = self.model
        
        # Save with fallback for shared tensors
        try:
            if hasattr(model_to_save, "save_pretrained"):
                model_to_save.save_pretrained(self.config.output_dir, safe_serialization=True)
        except RuntimeError as e:
            if "shared tensors" in str(e):
                state_dict = model_to_save.state_dict()
                seen = set()
                clean_dict = {}
                for k, v in state_dict.items():
                    if k not in seen:
                        clean_dict[k] = v
                        seen.add(k)
                torch.save(clean_dict, os.path.join(self.config.output_dir, "model.pt"))
                print(f"  Model state dict saved")
            else:
                raise
        
        if self.tokenizer:
            self.tokenizer.save_pretrained(self.config.output_dir)

        from amazingvmsloth.lora import get_lora_state_dict
        lora_dict = get_lora_state_dict(model_to_save)
        if lora_dict:
            torch.save(lora_dict, os.path.join(self.config.output_dir, "lora_weights.pt"))

        print(f"  Model saved to {self.config.output_dir}")
