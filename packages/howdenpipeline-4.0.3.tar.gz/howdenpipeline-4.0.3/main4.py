import asyncio
from parameter2 import Parameter
from HowdenPipeline.flow.graph_pipeline import GraphPipeline
from HowdenPipeline.manager.tracker import Tracker
from HowdenParser.parser import Parser
from HowdenLLM import LLM
from pathlib import Path


async def main():
    parameter = Parameter()

    tracker = parameter.tracker.create(Tracker)

    parser = parameter.parser.create(Parser)
    payment_info = parameter.payment_info.create(LLM)
    payment_date = parameter.payment_date.create(LLM)

    pipeline = GraphPipeline(pdf=Path(parameter.root_folder),
                             delete_folder=True,
                             tracker=tracker,
                             parameter=parameter)

    pipeline.add_step(parser, output_filetype="md")
    pipeline.add_step(payment_date, dependencies=[parser], output_filetype="json", track=True, name="payment_date")
    pipeline.add_step(payment_info, dependencies=[parser], output_filetype="json", track=True)

    await pipeline.execute()


if __name__ == "__main__":
    asyncio.run(main())