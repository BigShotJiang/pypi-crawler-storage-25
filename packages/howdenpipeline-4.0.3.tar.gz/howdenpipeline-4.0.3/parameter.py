from HowdenConfig import Config
from string import Template


class PaymentInfo(Config):
    provider_and_model: str = "openai:gpt-5-mini"
    system: str = "You are an invoice extractor."
    template: Template = Template(
    """
    You are a text extraction assistant.
    
    Task:
    From the content below, identify every line that represents a payment the client must make.
    A payment line is any line that contains:
    - a descriptive label (for example: Premium, Tax, Fee, Commission, Total Amount)
    - a monetary amount (for example: 1.250,00 DKK, €530.50, 1200,-, 5 300,00)
    
    Extraction Rules:
    1. Every payment line must become a separate JSON key:value pair.
    2. The key is the descriptive part of the line (normalized to lowercase and spaces replaced with underscores).
    3. The value is the numeric amount only:
       - remove currency symbols (€, DKK, GBP, NOK, SEK etc.)
       - remove thousand separators ("," or ".")
       - convert decimal commas to decimal points
       - return the amount as a string
    4. If multiple amounts appear on a single line, take the most relevant monetary amount.
    5. Return ONLY valid JSON with no comments, no markdown, and no surrounding text.
    
    Example:
    Input line:
    "Total Premium: 5.300,00 DKK"
    Output:
    {
      "total_premium": "5300.00"
    }
    
    Content:
    \"\"\"$content\"\"\"
    """
)


class PaymentDate(Config):
    provider_and_model: str = "openai:gpt-5-mini"
    system: str = "You are an invoice extractor."
    template: Template = Template("""
    You are an information extraction system.

    Task:
    
    Extract the product name/handelsnavn from the content below.
    
    Example output:
    8955

    Content:
    \"\"\"$content\"\"\"
    """)

class Parser(Config):
    provider_and_model: str = "llamaparser:"
    result_type: str = "md"
    model: str = "anthropic-sonnet-4.5"
    parse_mode: str = "parse_page_with_agent"
    merge_tables_across_pages_in_markdown: bool = True
    preserve_layout_alignment_across_pages: bool = False
    hide_footers: bool=True
    hide_headers: bool=True

class Tracker(Config):
    logger_type: str = "mlflow"
    project_name: str = "howden_pipeline"

class Parameter(Config):

    tracker: Tracker = Tracker()
    parser: Parser = Parser()
    payment_info: PaymentInfo = PaymentInfo()
    payment_date: PaymentDate = PaymentDate()
    root_folder: str = r"C:\Users\JesperThoftIllemannJ\IdeaProjects\howden_pipeline\.data4"