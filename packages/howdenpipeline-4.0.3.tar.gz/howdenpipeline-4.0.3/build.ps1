param (
    [switch]$help
)

# --- Functions ---

function Show-Help {
    Write-Host @"
HowdenParser Build Script

Usage:
    .\build.ps1 [--patch|--minor|--major] [--help|-h]

Options:
    --patch     Bump patch version
    --minor     Bump minor version
    --major     Bump major version
    --help      Show this help message
    -h          Alias for --help
"@
    exit 0
}

function Load-Token {
    Write-Host "Loading PyPI token from .env..."
    $token = (Get-Content .env | ForEach-Object {
        if ($_ -match "^PYPI_TOKEN=(.*)$") { $matches[1] }
    })

    if (-not $token) {
        Write-Error "No PYPI_TOKEN found in .env"
        exit 1
    }

    $env:UV_PUBLISH_TOKEN = $token
    Write-Host "Token loaded."
}

function Get-Version {
    $tomlPath = "pyproject.toml"
    if (-not (Test-Path $tomlPath)) {
        Write-Error "pyproject.toml not found"
        exit 1
    }

    $content = Get-Content $tomlPath -Raw
    if ($content -match 'version\s*=\s*"([^"]+)"') {
        return $matches[1]
    } else {
        Write-Error "Version not found in pyproject.toml"
        exit 1
    }
}

function Validate-Git {
    # Check we're on main or master
    $currentBranch = git rev-parse --abbrev-ref HEAD
    if ($currentBranch -ne "main" -and $currentBranch -ne "master") {
        Write-Error "You must be on 'main' or 'master' to publish. Current branch: $currentBranch"
        exit 1
    }

    # Check for uncommitted changes
    $status = (git status --porcelain) | Out-String
    if ($status.Trim().Length -gt 0) {
        Write-Error "You have uncommitted changes. Please commit or stash them before publishing."
        exit 1
    }

    Write-Host "Git validation passed." -ForegroundColor Green
}

function Bump-Version {
    param (
        [string]$type
    )

    if (-not $type) {
        Write-Error "No bump type specified. Use --patch, --minor, or --major."
        exit 1
    }

    Write-Host "Bumping version ($type)..."
    uv run bump_version.py --$type
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Version bump failed."
        exit 1
    }
    $newVersion = Get-Version
    Write-Host "Version updated to $newVersion" -ForegroundColor Green
}

function Build {
    # Clean old build artifacts
    Write-Host "Cleaning old build artifacts..."
    if (Test-Path "dist") {
        Remove-Item -Recurse -Force "dist"
        Write-Host "Cleaned dist/ folder." -ForegroundColor Green
    }

    Write-Host "Building package with uv..."
    uv build
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Build failed. Aborting."
        exit 1
    }
    Write-Host "Build succeeded." -ForegroundColor Green
}

function Publish {
    Load-Token
    Write-Host "Publishing package with uv..."
    uv publish
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Publish failed. Aborting."
        exit 1
    }
    Write-Host "Publish succeeded." -ForegroundColor Green
}

function GitPushAndTag {
    $version = Get-Version
    $currentBranch = git rev-parse --abbrev-ref HEAD

    Write-Host "Committing version bump to $version..."
    git add pyproject.toml
    git commit -m "Release version $version"
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Git commit failed."
        exit 1
    }

    Write-Host "Pushing to $currentBranch..."
    git push origin $currentBranch
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Git push failed."
        exit 1
    }

    Write-Host "Tagging version v$version..."
    git tag -a "v$version" -m "Release version $version"
    git push origin "v$version"
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Git tag push failed."
        exit 1
    }

    Write-Host "Code pushed and tagged as v$version successfully!" -ForegroundColor Green
}

# --- Parse command line arguments ---
$bump = $null
$helpFlag = $false

foreach ($arg in $args) {
    switch ($arg) {
        "--patch" {
            if ($bump) { Write-Error "Only one of --patch, --minor, or --major is allowed."; exit 1 }
            $bump = "patch"
        }
        "--minor" {
            if ($bump) { Write-Error "Only one of --patch, --minor, or --major is allowed."; exit 1 }
            $bump = "minor"
        }
        "--major" {
            if ($bump) { Write-Error "Only one of --patch, --minor, or --major is allowed."; exit 1 }
            $bump = "major"
        }
        "-h"      { $helpFlag = $true }
        "--help"  { $helpFlag = $true }
        default {
            Write-Host "Unknown target: $arg"
            Write-Host "Available targets: --patch, --minor, --major, --help, -h"
            exit 1
        }
    }
}

if (-not $helpFlag -and -not $bump) {
    Write-Host "Error: You must provide one of the following options: --patch, --minor, --major, --help, or -h"
    exit 1
}

if ($helpFlag) {
    Show-Help
}

# --- Main execution ---
Write-Host "Starting build process..." -ForegroundColor Cyan
Validate-Git        # 1. Validate branch + clean working tree
Bump-Version $bump  # 2. Bump version first
Build               # 3. Clean dist/ and build with new version
Publish             # 4. Publish to PyPI
GitPushAndTag       # 5. Commit + push + tag the new version
Write-Host "All done!" -ForegroundColor Green