from HowdenConfig import Config


class Parser(Config):
    provider_and_model: str = "llamaparser:"
    result_type: str = "md"
    model: str = "anthropic-sonnet-4.5"
    parse_mode: str = "parse_page_with_agent"
    merge_tables_across_pages_in_markdown: bool = True
    preserve_layout_alignment_across_pages: bool = False
    hide_footers: bool=True
    hide_headers: bool=True

class TrackerConfig(Config):
    logger_type: str = "mlflow"
    project_name: str = "howden_pipeline"

class Parameter(Config):

    parser: Parser = Parser()
    tracker: TrackerConfig = TrackerConfig()