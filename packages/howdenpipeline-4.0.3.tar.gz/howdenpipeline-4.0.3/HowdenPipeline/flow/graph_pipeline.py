from pathlib import Path
from typing import Any, Iterable, List, Optional, Dict
import time
from HowdenConfig import Config
from HowdenPipeline.manager.jsonMatcher import JsonMatcher
from HowdenPipeline.manager.tracker import Tracker
from HowdenPipeline.flow.pipeline_graph_manager import PipelineGraphManager
from HowdenPipeline.flow.file_pipeline_runner import FilePipelineRunner


class GraphPipeline:

    def __init__(
            self,
            pdf: Path,
            parameter: Config,
            tracker: Optional[Tracker] = None,
            delete_folder: bool = False,

    ) -> None:

        self.delete_folder = delete_folder

        self.file_paths_pdf: Path = pdf

        self.graph_manager = PipelineGraphManager()

        self.tracker = tracker

        if self.tracker:
            print("run mlflow by writing <mlflow ui --backend-store-uri sqlite:///mlflow.db --port 5000>")
            self.tracker.log_lock_file()
            self._log_parameters_to_mlflow(parameter)

        self.matcher_factory = JsonMatcher

    def _log_parameters_to_mlflow(self, parameter: Any) -> None:
        """
        Recursively log all attributes from parameter object to MLflow.
        Prefixes each parameter with its class name.
        """
        params_dict = {}
        self._extract_params(parameter, params_dict, prefix=parameter.__class__.__name__)

        if params_dict:
            self.tracker.log_params(params_dict)

    def _extract_params(self, obj: Any, params_dict: dict, prefix: str = "") -> None:
        """
        Recursively extract all attributes from an object.
        """
        if hasattr(obj, '__dict__'):
            for key, value in obj.__dict__.items():
                param_name = f"{prefix}.{key}" if prefix else key

                # If the value is an object with __dict__, recurse into it
                if hasattr(value, '__dict__') and not isinstance(value, (str, int, float, bool, list, dict, tuple)):
                    self._extract_params(value, params_dict, prefix=param_name)
                else:
                    # Log primitive types and collections
                    params_dict[param_name] = str(value)
    @staticmethod
    def _aggregate_timing_data(pipeline_managers: List[Any]) -> Dict[str, Any]:
        """Aggregate timing data across all file pipeline runs as structured data."""
        from collections import defaultdict

        all_step_timings = defaultdict(list)

        # Collect all timings from all pipeline managers
        for manager in pipeline_managers:
            for step_name, durations in manager.step_timings.items():
                all_step_timings[step_name].extend(durations)

        # Build structured timing data
        timing_data = {
            "steps": {},
            "summary": {}
        }

        total_pipeline_time = 0

        for step_name, all_durations in all_step_timings.items():
            if all_durations:
                step_total = sum(all_durations)
                total_pipeline_time += step_total

                timing_data["steps"][step_name] = {
                    "avg_sec": round(sum(all_durations) / len(all_durations), 3),
                    "total_sec": round(step_total, 3),
                    "min_sec": round(min(all_durations), 3),
                    "max_sec": round(max(all_durations), 3),
                    "count": len(all_durations),
                    "all_executions": [round(d, 3) for d in all_durations]
                }

        timing_data["summary"] = {
            "total_pipeline_time_sec": round(total_pipeline_time, 3),
            "num_steps": len(all_step_timings),
            "num_files": len(pipeline_managers)
        }

        return timing_data

    def _log_prompts_with_accuracy(self, overall_accuracy: float) -> None:
        """
        Extract and log prompts from LLM steps with their accuracy.

        Args:
            overall_accuracy: The overall accuracy achieved by the pipeline
        """
        if not self.tracker:
            return

        # Iterate through all nodes to find LLM steps with prompts
        for node in self.graph_manager.graph.nodes():
            step = self.graph_manager.graph.nodes[node]["cls"]
            step_name = self.graph_manager.graph.nodes[node]["name"]

            # Check if this is an LLM step with a template/prompt
            if hasattr(step, 'template') and step.template:
                template = step.template
                template_str = template.template if hasattr(template, 'template') else str(template)

                system_msg = getattr(step, 'system', None)
                model = getattr(step, 'model', None) or getattr(step, 'provider_and_model', None)

                self.tracker.log_prompt(
                    prompt_name=step_name,
                    prompt_template=template_str,
                    system_message=system_msg,
                    model=model,
                    accuracy=overall_accuracy
                )

    def add_step(
            self,
            step: Any,
            dependencies: Optional[Iterable[Any]] = None,
            track: bool = False,
            output_filetype: Optional[str] = None,
            input_result: Optional[Any] = None,
            name: Optional[str] = None
    ) -> None:

        self.graph_manager.add_step(
            step=step,
            dependencies=dependencies,
            track=track,
            output_filetype=output_filetype,
            input_result=input_result,
            name=name
        )

    async def execute(self) -> List[Path]:
        if not self.file_paths_pdf:
            return []

        file_path = Path(self.file_paths_pdf).resolve()

        if file_path.is_dir():
            pdf_files = []
            for subfolder in file_path.iterdir():
                if subfolder.is_dir():
                    first_pdf = next(subfolder.glob("*.pdf"), None)
                    if first_pdf:
                        pdf_files.append(first_pdf)

            if not pdf_files:
                return []
        else:
            pdf_files = [file_path]

        # Process all PDFs concurrently
        async def process_single_file(pdf_file: Path, idx: int):
            """Process a single PDF file and return the match and manager."""
            graph_copy = self.graph_manager.graph.copy()
            file_pipeline_manager = FilePipelineRunner(
                graph_copy,
                self.delete_folder,
                self.tracker,
                file_index=idx
            )
            match = await file_pipeline_manager.run_for_file(pdf_file)
            return match, file_pipeline_manager

        # Create tasks for all PDF files
        import asyncio
        tasks = [process_single_file(pdf_file, idx) for idx, pdf_file in enumerate(pdf_files)]

        # Run all tasks concurrently
        results = await asyncio.gather(*tasks)

        # Separate matches and managers
        processed_matches = [match for match, _ in results]
        all_pipeline_managers = [manager for _, manager in results]

        # Aggregate timing data and log as artifact instead of metrics
        if self.tracker:
            timing_data = self._aggregate_timing_data(all_pipeline_managers)
            self.tracker.log_dict(timing_data, "timing_metrics.json", folder="performance")

        if self.tracker and len(processed_matches) > 0:
            matcher = self.matcher_factory(processed_matches)
            matcher.report(verbose=True)

            # Get overall accuracy for prompt logging
            overall_metrics = matcher.get_all_metrics()
            overall_accuracy = overall_metrics.get("overall_accuracy", 0.0)

            self.tracker.log_metrics(overall_metrics)

            # Log per-file accuracy as artifact instead of metrics
            per_file_accuracy = matcher.get_per_file_accuracy_artifact()
            self.tracker.log_dict(per_file_accuracy, "per_file_accuracy.json", folder="accuracy")

            # Log prompts with their accuracy
            self._log_prompts_with_accuracy(overall_accuracy)

        if self.tracker:
            self.tracker.end_logger()

        return processed_matches
