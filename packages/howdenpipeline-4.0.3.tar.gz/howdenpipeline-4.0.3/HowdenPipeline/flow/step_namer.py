from typing import Any, Optional

class StepNamer:
    @staticmethod
    def name_for(step: Any, custom_name: Optional[str] = None) -> str:
        # Get the base name from attribute or class name
        base_name = getattr(step, "name", None)
        if not base_name:
            base_name = step.__class__.__name__

        # If custom_name is provided, prepend it
        if custom_name:
            return f"{custom_name}_{base_name}"

        return base_name