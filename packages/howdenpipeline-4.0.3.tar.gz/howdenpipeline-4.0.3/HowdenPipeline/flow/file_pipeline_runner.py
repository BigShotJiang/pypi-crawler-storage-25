import json
from pathlib import Path
from typing import Any, List, Optional
import asyncio
import shutil
import networkx as nx
import time
import contextlib
import threading

from HowdenPipeline.flow.parameter_serializer import ParameterSerializer
from HowdenPipeline.flow.match import Match

# Global print lock for synchronized output across async tasks
_print_lock = threading.Lock()


class FilePipelineRunner:
    def __init__(
            self,
            graph: nx.DiGraph,
            delete_folder: bool = None,
            tracker: Optional[Any] = None,
            file_index: int = 0,
    ) -> None:
        self.graph = graph
        self.serializer = ParameterSerializer()
        self.match_holder: List[Match] = []
        self.delete_folder = delete_folder
        self.tracker = tracker
        self.file_index = file_index
        self.step_timings = {}
        self.parent_span = None

    def delete_folder_if_exists(self, path: Path) -> None:
        if self.delete_folder and path.exists() and path.is_dir():
            shutil.rmtree(path)
        path.mkdir(parents=True, exist_ok=True)


    async def run_for_file(self, file_path: Path) -> Match:
        with _print_lock:
            print(f"\n📄 Processing: {file_path.name}")

        combined_result_path: list[Path] = []

        # Create parent span for entire PDF processing
        parent_span_cm = self.tracker.start_span(
            name=f"process_pdf_{file_path.name}",
            span_type="CHAIN"
        ) if self.tracker else contextlib.nullcontext()

        with parent_span_cm as parent_span:
            # Store parent span for later access
            self.parent_span = parent_span

            if parent_span and self.tracker:
                self.tracker.set_span_input(parent_span, {"file_path": str(file_path)})

            for node in self._traversal_order():
                step = self.graph.nodes[node]["cls"]
                # Use the full path to create unique step identifier (e.g., "Parser", "payment_date", "payment_info")
                full_path_parts = self.graph.nodes[node]["full_path"]
                step_name = full_path_parts[-1] if full_path_parts else getattr(step, 'name', step.__class__.__name__)

                dep_path = "/".join(full_path_parts)
                folder_path = Path(file_path.parent / dep_path)

                self.delete_folder_if_exists(folder_path)

                filetype = self.graph.nodes[node]["filetype"]
                result_file_path = folder_path / Path("result").with_suffix(f".{filetype}")

                if not result_file_path.exists():
                    self._write_parameters(step, folder_path)
                    input_data = self._build_input_data(node, file_path)
                    input_result_parts = self.graph.nodes[node]["input_result"]

                    # Determine span type based on step class
                    step_class = step.__class__.__name__.lower()
                    if 'llm' in step_class or 'gpt' in step_class or 'claude' in step_class:
                        span_type = "LLM"
                    elif 'parser' in step_class:
                        span_type = "TOOL"
                    else:
                        span_type = "CHAIN"

                    # Start timing
                    start_time = time.time()
                    trace_data = {
                        "step_name": step_name,
                        "input_type": str(type(input_data)),
                    }

                    # Execute step with tracing
                    try:
                        # Use context manager for span
                        span_cm = self.tracker.start_span(name=step_name, span_type=span_type) if self.tracker else contextlib.nullcontext()

                        with span_cm as span:
                            # Set span inputs
                            if span and self.tracker:
                                self.tracker.set_span_input(span, {"input_path": str(input_data)})

                            if input_result_parts:
                                parts = folder_path.parts
                                idx = parts.index(input_result_parts[0])+1
                                new_path = Path(*parts[:idx])
                                print(f"  ├─ Running: {step_name}")
                                if asyncio.iscoroutinefunction(step):
                                    result = await step(input_data, new_path / "result.md")
                                else:
                                    result = step(input_data, new_path / "result.md")
                                print(f"  │  ✓ Completed")
                            else:
                                print(f"  ├─ Running: {step_name}")
                                if asyncio.iscoroutinefunction(step):
                                    result = await step(input_data)
                                else:
                                    result = step(input_data)
                                print(f"  │  ✓ Completed")

                            # Capture success
                            trace_data["status"] = "success"
                            trace_data["output_length"] = len(result) if result else 0

                            # Set span outputs
                            if span and self.tracker:
                                self.tracker.set_span_output(span, {"result": result[:500]})

                            # Set LLM-specific span attributes inside the context
                            if hasattr(step, 'get_trace_info'):
                                llm_trace = step.get_trace_info()
                                if span and self.tracker:
                                    llm_attributes = {
                                        "model": llm_trace.get("model"),
                                        "provider": llm_trace.get("provider"),
                                        "prompt_tokens": llm_trace.get("prompt_tokens"),
                                        "completion_tokens": llm_trace.get("completion_tokens"),
                                        "total_tokens": llm_trace.get("total_tokens"),
                                    }
                                    self.tracker.set_span_attributes(span, llm_attributes)

                    except Exception as e:
                        trace_data["status"] = "error"
                        trace_data["error"] = str(e)
                        raise
                    finally:
                        # End timing
                        duration = time.time() - start_time
                        trace_data["duration_sec"] = round(duration, 3)

                        # Extract LLM-specific trace info if available (for logging)
                        if hasattr(step, 'get_trace_info'):
                            llm_trace = step.get_trace_info()
                            trace_data.update(llm_trace)

                        # Log trace data as artifact for detailed inspection (suppressed output)
                        if self.tracker:
                            self.tracker.log_trace_data(f"{step_name}_{self.file_index}", trace_data, indent="  ")

                        # Store timing for aggregation using unique step name
                        if step_name not in self.step_timings:
                            self.step_timings[step_name] = []
                        self.step_timings[step_name].append(duration)

                    result_file_path.write_text(result, encoding="utf-8")

                if self.graph.nodes[node]["track"]:
                    self._log_step_result_to_mlflow(step, file_path, result_file_path)
                    combined_result_path.append(result_file_path)

                self._propagate_result_path(node, result_file_path)

            # Set parent span output with combined results and GT comparison
            if parent_span and self.tracker:
                # Quick GT comparison for span attributes
                gt_path = Path(f"{file_path.parent}/GT.json")
                gt_matches = self._quick_gt_check(combined_result_path, gt_path)

                self.tracker.set_span_output(parent_span, {
                    "combined_results": [str(p) for p in combined_result_path],
                    "num_steps": len(list(self._traversal_order()))
                })

                # Add GT match info as span attributes
                if gt_matches is not None:
                    self.tracker.set_span_attributes(parent_span, {
                        "gt_accuracy": gt_matches.get("accuracy", 0.0),
                        "gt_keys_matched": gt_matches.get("keys_matched", 0),
                        "gt_keys_total": gt_matches.get("keys_total", 0),
                    })
                    print(f"  └─ ✓ Completed (Accuracy: {gt_matches.get('accuracy', 0.0)}%)")
                else:
                    print(f"  └─ ✓ Completed")

        match = Match(
            result=combined_result_path if len(combined_result_path)> 0 else "" ,
            ground_truth=Path(f"{file_path.parent}/GT.json"),
            file_path=file_path
            )

        return match

    def get_timing_metrics(self) -> dict:
        """Get aggregated timing metrics for this file."""
        metrics = {}
        for step_name, durations in self.step_timings.items():
            if durations:
                metrics[f"step_{step_name}_avg_sec"] = round(sum(durations) / len(durations), 3)
                metrics[f"step_{step_name}_total_sec"] = round(sum(durations), 3)
                metrics[f"step_{step_name}_min_sec"] = round(min(durations), 3)
                metrics[f"step_{step_name}_max_sec"] = round(max(durations), 3)
        return metrics

    def _quick_gt_check(self, result_paths: List[Path], gt_path: Path) -> Optional[dict]:
        """
        Quick ground truth comparison for span attributes.

        Args:
            result_paths: List of result file paths
            gt_path: Path to ground truth JSON

        Returns:
            Dictionary with accuracy and match counts, or None if GT doesn't exist
        """
        if not gt_path.exists() or not result_paths:
            return None

        try:
            # Load GT
            with gt_path.open("r", encoding="utf-8") as f:
                gt_data = json.load(f)

            # Merge all result JSONs
            merged_result = {}
            for result_path in result_paths:
                if result_path.exists() and result_path.suffix == ".json":
                    with result_path.open("r", encoding="utf-8") as f:
                        result_data = json.load(f)
                        merged_result.update(result_data)

            # Compare keys
            gt_keys = set(gt_data.keys())
            matched = 0
            for key in gt_keys:
                if key in merged_result and merged_result[key] == gt_data[key]:
                    matched += 1

            accuracy = (matched / len(gt_keys) * 100) if gt_keys else 0.0

            return {
                "accuracy": round(accuracy, 2),
                "keys_matched": matched,
                "keys_total": len(gt_keys),
            }
        except Exception as e:
            print(f"[Warning] Could not perform GT check: {e}")
            return None

    def _traversal_order(self) -> List[str]:
        return list(nx.topological_sort(self.graph))

    def _write_parameters(self, step: Any, folder_path: Path) -> None:
        json_parameter = folder_path / "parameter.json"
        attrs = {
            k: v
            for k, v in step.__dict__.items()
            if not k.startswith("_") and k not in ("client", "provider")
        }

        # Remove duplicates: if input_params exists and contains duplicates of root fields, keep only input_params
        if "input_params" in attrs:
            input_params_keys = set(attrs["input_params"].keys()) if isinstance(attrs["input_params"], dict) else set()
            # Remove root-level keys that are duplicated in input_params
            attrs = {
                k: v for k, v in attrs.items()
                if k == "input_params" or k not in input_params_keys
            }

        serializable_attrs = self.serializer.make_serializable(attrs)
        json_parameter.write_text(
            json.dumps(
                serializable_attrs,
                indent=2,
                sort_keys=True,
                ensure_ascii=True,
            ),
            encoding="utf-8",
        )

    def _build_input_data(self, node: str, file_path: Path) -> Any:
        dep_paths = [
            data["result_path_from_dep"]
            for _pred, _succ, data in self.graph.in_edges(node, data=True)
            if "result_path_from_dep" in data
        ]

        if dep_paths:
            dep_paths = [Path(p) for p in dep_paths]
            if len(dep_paths) == 1:
                return dep_paths[0]
            return dep_paths

        if isinstance(file_path, Path):
            return file_path
        return Path(file_path)

    def _propagate_result_path(self, node: str, result_file_path: Path) -> None:
        for _u, _v, data in self.graph.out_edges(node, data=True):
            data["result_path_from_dep"] = str(result_file_path)

    def _log_step_result_to_mlflow(
            self,
            step: Any,
            file_path: Path,
            result_file_path: Path,
    ) -> None:
        """
        Log the result of a step execution to MLflow.

        Args:
            step (Any): The step that was executed.
            file_path (Path): Path to the input file.
            result_file_path (Path): Path to the result file.
        """
        if not self.tracker:
            return

        step_name = getattr(step, 'name', step.__class__.__name__)
        file_name = file_path.name
        hashed = step.hashed
        folder = self._determine_artifact_folder(step)
        artifact_name = f"{step_name}_{file_name}_{hashed}_result"

        self.tracker.log_artifact(result_file_path, artifact_name, folder)

    @staticmethod
    def _determine_artifact_folder(step: Any) -> str:
        """
        Determine which folder to store the artifact based on step type.

        Args:
            step (Any): The step being executed.

        Returns:
            str: Folder name for the artifact (e.g., 'parser', 'llm', 'other').
        """
        step_class_name = step.__class__.__name__.lower()

        if 'parser' in step_class_name:
            return 'parser'
        elif 'llm' in step_class_name or 'gpt' in step_class_name or 'claude' in step_class_name:
            return 'llm'
        else:
            return 'other'
