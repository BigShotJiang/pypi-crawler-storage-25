from dataclasses import dataclass
from pathlib import Path

@dataclass
class Match:
    result: list[Path]
    ground_truth: Path
    file_path: Path
