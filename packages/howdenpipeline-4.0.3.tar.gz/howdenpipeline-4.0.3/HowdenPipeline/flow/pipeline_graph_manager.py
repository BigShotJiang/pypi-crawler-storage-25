from typing import Any, Iterable, Optional
import networkx as nx
from HowdenPipeline.flow.step_namer import StepNamer
from HowdenPipeline.flow.step_hasher import StepHasher


class PipelineGraphManager:
    """
    Manages a directed acyclic graph (DAG) of pipeline steps and their dependencies.

    This class provides functionality to build and manage a computational pipeline where
    steps are represented as nodes in a directed graph, with edges representing dependencies
    between steps. Each step is uniquely identified, hashed for caching purposes, and tracked
    with metadata including file types and execution results.

    Attributes:
        graph (nx.DiGraph): The directed graph representing the pipeline structure.
    """

    def __init__(
            self,
    ) -> None:
        """
        Initialize the PipelineGraphManager.

        """
        self.graph: nx.DiGraph = nx.DiGraph()
        self._hasher = StepHasher()
        self._namer = StepNamer()

    def add_step(
            self,
            step: Any,
            dependencies: Optional[Iterable[Any]] = None,
            track: bool = False,
            output_filetype: Optional[str] = None,
            input_result: Optional[str] = None,
            name: Optional[str] = None,
    ) -> None:
        """
        Add a processing step to the pipeline graph.

        Creates a node in the graph representing the step, with metadata including
        name, hash, file type, and tracking information. If dependencies are specified,
        creates directed edges from dependency nodes to this step's node.

        Args:
            step (Any): The processing step object to add (e.g., Parser, Transformer).
            dependencies (Optional[Iterable[Any]]): Steps that must complete before this step.
                If None, the step is added as a root node. Defaults to None.
            track (bool): Whether to track this step's output for validation/metrics.
                Defaults to False.
            output_filetype (Optional[str]): File extension for the step's output (e.g., "md", "json").
                Defaults to None.
            input_result (Optional[str]): Reference to a previous step's output to use as
                data input (distinct from execution dependencies). Defaults to None.
            name (Optional[str]): Custom name for the step. If not provided, uses step.name or
                step.__class__.__name__. Defaults to None.

        Raises:
            KeyError: If a specified dependency step hasn't been added to the graph yet.
        """

        node_id = self._node_id_for(step)
        step_name = self._namer.name_for(step, custom_name=name)
        node_hash = self._hasher.compute_hash(step)
        node_label = self._create_node_label(step_name, node_hash)
        data_dependence = self._extract_data_dependence(input_result)
        full_path = self._build_full_path_and_create_edges(dependencies, node_id, node_label)
        self._set_node_attributes(node_id, step, step_name, track, output_filetype, node_hash, full_path, data_dependence)

    @staticmethod
    def _create_node_label(name: str, node_hash: str) -> str:
        """
        Create a label for the node combining name and hash.

        Args:
            name (str): The step name.
            node_hash (str): The hash of the step.

        Returns:
            str: Node label in format "name_hash" or just "name" if hash is empty.
        """
        return f"{name}_{node_hash}" if node_hash else name

    def _extract_data_dependence(self, input_result: Optional[str]) -> Optional[list]:
        """
        Extract data dependence path from input result steps.

        Args:
            input_result (Optional[str]): Reference to previous step's output.

        Returns:
            Optional[list]: Full path of the data dependency, or None.
        """
        if not input_result:
            return None

        for h in input_result:
            dep_id = self._node_id_for(h)
            return self.graph.nodes[dep_id].get("full_path", [])
        return None

    def _build_full_path_and_create_edges(
            self,
            dependencies: Optional[Iterable[Any]],
            node_id: str,
            node_label: str
    ) -> list:
        """
        Build the full path for the node and create dependency edges.

        Args:
            dependencies (Optional[Iterable[Any]]): Steps that must complete before this step.
            node_id (str): Unique identifier for the current node.
            node_label (str): Label for the current node.

        Returns:
            list: Full path from root to this node.
        """
        full_path = [node_label]

        if dependencies:
            for dep_step in dependencies:
                dep_id = self._node_id_for(dep_step)
                dep_path = self.graph.nodes[dep_id].get("full_path", [])
                full_path = dep_path + [node_label]
                self.graph.add_edge(dep_id, node_id)
        else:
            self.graph.add_node(node_id)

        return full_path

    def _set_node_attributes(
            self,
            node_id: str,
            step: Any,
            name: str,
            track: bool,
            output_filetype: Optional[str],
            node_hash: str,
            full_path: list,
            data_dependence: Optional[list]
    ) -> None:
        """
        Set all attributes for a node in the graph.

        Args:
            node_id (str): Unique identifier for the node.
            step (Any): The processing step object.
            name (str): The step name.
            track (bool): Whether to track this step's output.
            output_filetype (Optional[str]): File extension for the step's output.
            node_hash (str): Hash of the step.
            full_path (list): Full path from root to this node.
            data_dependence (Optional[list]): Data dependency path.
        """
        self.graph.nodes[node_id].update(
            cls=step,
            name=name,
            track=track,
            filetype=output_filetype,
            result=None,
            hash=node_hash,
            hash_path=[node_hash],
            full_path=full_path,
            input_result=data_dependence
        )

    @staticmethod
    def _node_id_for(step: Any) -> str:
        """
        Generate a unique identifier for a step based on its memory address.

        Args:
            step (Any): The step object to generate an ID for.

        Returns:
            str: Hexadecimal string representation of the object's memory address.
        """
        return hex(id(step))
