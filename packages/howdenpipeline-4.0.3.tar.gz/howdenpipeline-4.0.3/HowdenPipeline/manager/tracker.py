import os
import subprocess
from dotenv import load_dotenv
import mlflow

class Tracker:
    def __init__(self, logger_type: str, project_name: str = None):
        load_dotenv()
        self.logger_type = logger_type.lower()  # normalize once

        if self.logger_type == "langsmith":
            self._init_langsmith()
        elif self.logger_type == "mlflow":
            self._init_mlflow(project_name)
        elif self.logger_type == "none":
            print("[Logger] No logging enabled.")
        else:
            raise ValueError(f"Unsupported logger_type: {logger_type}")

    def _init_langsmith(self):
        from langsmith import Client
        from langsmith.utils import LangSmithError

        langsmith_key = os.getenv("LANGCHAIN_API_KEY")
        if not langsmith_key:
            raise ValueError("LANGCHAIN_API_KEY not set in .env or environment")

        os.environ["LANGCHAIN_TRACING_V2"] = "true"
        os.environ["LANGSMITH_ENDPOINT"] = "https://eu.api.smith.langchain.com"
        # Don't re-assign LANGCHAIN_API_KEY — it's already in the environment

        try:
            client = Client()
            projects = list(client.list_projects())
            print("✅ Token valid. Projects:", [p.name for p in projects])
        except LangSmithError as e:
            print("❌ Token invalid or unauthorized:", e)
        except Exception as e:
            print("❌ Could not connect to LangSmith:", e)

    def _init_mlflow(self, project_name: str):
        # Check for uncommitted changes
        self._check_git_clean()

        mlflow.set_tracking_uri(os.getenv("MLFLOW_TRACKING_URI", "sqlite:///mlflow.db"))
        experiment = mlflow.get_experiment_by_name(project_name)
        if experiment is not None and experiment.lifecycle_stage == "deleted":
            mlflow.tracking.MlflowClient().restore_experiment(experiment.experiment_id)
            print(f"[MLflow] Restored deleted experiment: {project_name}")
        mlflow.set_experiment(project_name)

        # Get git version before starting run
        git_version = self._get_git_short_hash()

        # Start run with git hash as run name
        run = mlflow.start_run(run_name=git_version if git_version else None)
        self.run_id = run.info.run_id

        # Log git version info as tags
        self._log_git_version()

        print(f"[MLflow] Project: {project_name} | Run ID: {self.run_id} | Version: {git_version}")

    def _get_git_short_hash(self) -> str:
        """Get the short git commit hash."""
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError:
            return None

    def _check_git_clean(self) -> None:
        """Check if git repository has uncommitted changes and block if it does."""
        try:
            # Check if we're in a git repository
            result = subprocess.run(
                ["git", "rev-parse", "--git-dir"],
                capture_output=True,
                text=True,
                check=False
            )
            if result.returncode != 0:
                print("[MLflow] Warning: Not a git repository, skipping git checks")
                return

            # Check for uncommitted changes
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                capture_output=True,
                text=True,
                check=True
            )

            if result.stdout.strip():
                raise RuntimeError(
                    "[MLflow] Blocking execution: Uncommitted changes detected!\n"
                    "Please commit or stash your changes before running.\n"
                    f"Uncommitted changes:\n{result.stdout}"
                )

            print("[MLflow] Git status: clean ✓")
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"[MLflow] Failed to check git status: {e}")

    def _log_git_version(self) -> None:
        """Log git commit hash and branch as MLflow tags."""
        try:
            # Get the current commit hash
            commit_hash = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                check=True
            ).stdout.strip()

            # Get current branch
            branch = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
                check=True
            ).stdout.strip()

            # Get short commit hash
            short_hash = subprocess.run(
                ["git", "rev-parse", "--short", "HEAD"],
                capture_output=True,
                text=True,
                check=True
            ).stdout.strip()

            # Get git repo URL
            try:
                repo_url = subprocess.run(
                    ["git", "config", "--get", "remote.origin.url"],
                    capture_output=True,
                    text=True,
                    check=True
                ).stdout.strip()
            except subprocess.CalledProcessError:
                repo_url = None

            # Set MLflow source tags (standard git tracking)
            mlflow.set_tag("mlflow.source.git.commit", commit_hash)
            mlflow.set_tag("mlflow.source.git.branch", branch)

            if repo_url:
                mlflow.set_tag("mlflow.source.git.repoURL", repo_url)

            # Set custom "Version" tag with git short hash (for custom column display)
            mlflow.set_tag("Version", short_hash)

            # Also set as regular tags for easy access
            mlflow.set_tag("git.commit", commit_hash)
            mlflow.set_tag("git.commit_short", short_hash)
            mlflow.set_tag("git.branch", branch)

            print(f"[MLflow] Version tag set to: {short_hash} | Branch: {branch}")
        except subprocess.CalledProcessError as e:
            print(f"[MLflow] Warning: Failed to log git version: {e}")

    def log_lock_file(self) -> None:
        """Log the lock file as an MLflow artifact (MLflow only)."""
        if self.logger_type != "mlflow":
            return
        if os.path.exists("uv.lock"):
            mlflow.set_tag("package_manager", "uv")
            mlflow.log_artifact("uv.lock", artifact_path="environment")
        elif os.path.exists("poetry.lock"):
            mlflow.set_tag("package_manager", "poetry")
            mlflow.log_artifact("poetry.lock", artifact_path="environment")
        else:
            print("  [warn] no uv.lock or poetry.lock found")

    def log_artifact(self, file, artifact_name: str = None, folder: str = None):
        """
        Log a single artifact file to MLflow.

        Args:
            file: Path to the file to log.
            artifact_name: Name for the artifact.
            folder: Subfolder to organize artifacts (e.g., 'parser', 'llm').
        """
        if self.logger_type == "mlflow":
            if folder:
                artifact_path = f"step_results/{folder}/{artifact_name}" if artifact_name else f"step_results/{folder}"
            else:
                artifact_path = f"step_results/{artifact_name}" if artifact_name else "step_results"
            mlflow.log_artifact(file, artifact_path=artifact_path)

    def log_artifacts(self, file):  # fixed: was @staticmethod with self bug
        if self.logger_type == "mlflow":
            mlflow.log_artifact(file, artifact_path="metadata")

    def log_metrics(self, metrics: dict):
        if self.logger_type == "mlflow":
            mlflow.log_metrics(metrics)

    def log_params(self, params: dict):
        if self.logger_type == "mlflow":
            print(f"[MLflow] Logging {len(params)} parameters...")
            mlflow.log_params(params)
            print(f"[MLflow] Parameters logged successfully")

    def log_dict(self, data: dict, filename: str, folder: str = "metadata", indent: str = ""):
        """
        Log a dictionary as JSON artifact to MLflow.

        Args:
            data: Dictionary to log.
            filename: Name of the JSON file (with or without .json extension).
            folder: Subfolder to organize artifacts.
            indent: Indentation prefix for log messages.
        """
        if self.logger_type == "mlflow":
            import json
            import tempfile
            from pathlib import Path

            # Ensure .json extension
            if not filename.endswith('.json'):
                filename = f"{filename}.json"

            # Create temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
                json.dump(data, f, indent=2)
                temp_path = f.name

            # Log to MLflow
            mlflow.log_artifact(temp_path, artifact_path=folder)

            # Clean up temp file
            Path(temp_path).unlink()
            # Only print if not indented (to suppress step-level logs)
            if not indent:
                print(f"[MLflow] Logged {filename} to {folder}/")

    def start_span(self, name: str, span_type: str = "UNKNOWN"):
        """
        Start an MLflow span for tracking operations.

        Args:
            name: Name of the span (e.g., step name).
            span_type: Type of span (LLM, CHAIN, TOOL, etc.).

        Returns:
            Span context manager or None.
        """
        if self.logger_type == "mlflow":
            try:
                return mlflow.start_span(name=name, span_type=span_type)
            except Exception as e:
                print(f"[MLflow] Warning: Could not start span: {e}")
                return None
        return None

    def set_span_attributes(self, span, attributes: dict):
        """
        Set attributes on an active MLflow span.

        Args:
            span: The active span object.
            attributes: Dictionary of attributes to set.
        """
        if self.logger_type == "mlflow" and span:
            try:
                for key, value in attributes.items():
                    if value is not None:
                        span.set_attribute(key, value)
            except Exception as e:
                print(f"[MLflow] Warning: Could not set span attributes: {e}")

    def set_span_input(self, span, inputs):
        """Set input data for a span."""
        if self.logger_type == "mlflow" and span:
            try:
                span.set_inputs(inputs)
            except Exception as e:
                print(f"[MLflow] Warning: Could not set span inputs: {e}")

    def set_span_output(self, span, outputs):
        """Set output data for a span."""
        if self.logger_type == "mlflow" and span:
            try:
                span.set_outputs(outputs)
            except Exception as e:
                print(f"[MLflow] Warning: Could not set span outputs: {e}")

    def log_trace_data(self, trace_name: str, trace_data: dict, indent: str = ""):
        """
        Log trace data (prompts, responses, tokens) as artifact.

        Args:
            trace_name: Name identifier for the trace.
            trace_data: Dictionary containing trace information.
            indent: Indentation prefix for log messages.
        """
        if self.logger_type == "mlflow":
            # Log as artifact for detailed inspection
            self.log_dict(trace_data, f"trace_{trace_name}.json", folder="traces", indent=indent)

    def log_prompt(self, prompt_name: str, prompt_template: str, system_message: str = None,
                   model: str = None, accuracy: float = None):
        """
        Register prompt to MLflow Prompt Registry with metadata and accuracy.

        Args:
            prompt_name: Name of the prompt
            prompt_template: The prompt template string
            system_message: System message if any
            model: Model used with this prompt
            accuracy: Accuracy achieved with this prompt
        """
        if self.logger_type == "mlflow":
            try:
                from mlflow.entities import Prompt
                from mlflow.client import MlflowClient

                client = MlflowClient()

                # Create prompt with template and parameters
                prompt_messages = []

                if system_message:
                    prompt_messages.append({
                        "role": "system",
                        "content": system_message
                    })

                prompt_messages.append({
                    "role": "user",
                    "content": prompt_template
                })

                # Build prompt parameters
                prompt_params = {
                    "model": model or "unknown",
                    "accuracy": accuracy if accuracy is not None else 0.0,
                    "run_id": self.run_id,
                }

                # Create and register the prompt
                try:
                    # Try to create/update prompt in registry
                    prompt_dict = {
                        "messages": prompt_messages,
                        "parameters": prompt_params
                    }

                    # Log prompt to current run
                    mlflow.log_dict(prompt_dict, f"prompts/{prompt_name}.json")

                    # Log as input to the run for better traceability
                    mlflow.log_input(
                        mlflow.data.from_dict(
                            prompt_dict,
                            source=f"prompt_{prompt_name}"
                        ),
                        context="prompt"
                    )

                except Exception as e:
                    # Fallback to simple artifact logging if registry not available
                    print(f"[MLflow] Prompt registry not available, using artifact logging: {e}")
                    mlflow.log_dict(prompt_dict, f"prompts/{prompt_name}.json")

                # Log accuracy as metric for easy comparison
                if accuracy is not None:
                    mlflow.log_metric(f"prompt_accuracy.{prompt_name}", accuracy)

                # Tag the run with prompt info
                mlflow.set_tag(f"prompt.{prompt_name}.model", model or "unknown")
                mlflow.set_tag(f"prompt.{prompt_name}.version", "v1")

                print(f"[MLflow] Registered prompt '{prompt_name}' (Model: {model}, Accuracy: {accuracy}%)")
            except Exception as e:
                print(f"[MLflow] Warning: Could not register prompt: {e}")

    def set_trace_tags(self, trace_id: str, tags: dict):
        """
        Set tags on a completed trace.

        Args:
            trace_id: The trace ID.
            tags: Dictionary of tags to set.
        """
        if self.logger_type == "mlflow":
            try:
                client = mlflow.tracking.MlflowClient()
                for key, value in tags.items():
                    if value is not None:
                        client.set_trace_tag(trace_id, key, str(value))
            except Exception as e:
                print(f"[MLflow] Warning: Could not set trace tags: {e}")

    def end_logger(self):
        if self.logger_type == "mlflow":
            print("[MLflow] Ending run...")
            mlflow.end_run()
            print("[MLflow] Run ended successfully")