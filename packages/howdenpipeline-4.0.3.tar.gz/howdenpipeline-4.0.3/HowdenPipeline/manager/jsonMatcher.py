from dataclasses import dataclass
from pathlib import Path
import json
from typing import List, Dict, Any, Union
from collections import defaultdict


@dataclass
class ComparisonResult:
    """Result of comparing a single result file against ground truth."""
    result_file: str
    ground_truth_file: str
    step_name: str
    accuracy: float
    total_keys: int
    matched_keys: int
    missing_keys: int
    mismatched_values: int
    key_matches: Dict[str, bool]
    mismatches_detail: Dict[str, Dict[str, Any]]


class JsonMatcher:
    """
    Compare JSON result files against ground truth (GT).
    GT is the holy grail - only keys in GT matter for accuracy calculation.
    """

    def __init__(self, matches: List[Any]):
        """
        Initialize matcher with list of Match objects.

        Args:
            matches: List of Match objects with structure:
                - result: list[Path] - paths to result JSON files
                - ground_truth: Path - path to GT.json
                - file_path: Path - original file path
        """
        self.matches = matches
        self.comparisons: List[ComparisonResult] = []
        self._run_comparisons()

    # ----------------------------------------------------------------------
    # Helpers
    # ----------------------------------------------------------------------
    @staticmethod
    def _load_json(path: Path) -> Dict[str, Any]:
        """Load JSON file, handling errors gracefully."""
        try:
            with path.open("r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError) as e:
            print(f"Warning: Could not load JSON from {path}: {e}")
            return {}

    @staticmethod
    def _flatten_json(data: Dict[str, Any], parent_key: str = "", sep: str = ".") -> Dict[str, Any]:
        """
        Flatten nested JSON into dot-notation keys.
        Example: {"a": {"b": 1}} -> {"a.b": 1}
        """
        items = []
        for k, v in data.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(JsonMatcher._flatten_json(v, new_key, sep=sep).items())
            elif isinstance(v, list):
                # Convert lists to strings for comparison
                items.append((new_key, str(v)))
            else:
                items.append((new_key, v))
        return dict(items)

    @staticmethod
    def _extract_step_name(result_path: Path) -> str:
        """Extract step name from result file path."""
        # Assumes structure like: .../step_name/result.json
        return result_path.parent.name

    @staticmethod
    def _normalize_value(value: Any) -> Any:
        """Normalize values for comparison (handle whitespace, case, etc.)."""
        if isinstance(value, str):
            return value.strip()
        return value

    # ----------------------------------------------------------------------
    # Comparison logic
    # ----------------------------------------------------------------------
    def _compare_single_result(self, result_file: Path, gt_file: Path) -> ComparisonResult:
        """
        Compare a single result file against ground truth.
        GT is the holy grail - only keys present in GT are evaluated.
        """
        result_json = self._flatten_json(self._load_json(result_file))
        gt_json = self._flatten_json(self._load_json(gt_file))

        # GT keys are the source of truth
        gt_keys = set(gt_json.keys())
        total_keys = len(gt_keys)

        matched_keys = 0
        missing_keys = 0
        mismatched_values = 0
        key_matches = {}
        mismatches_detail = {}

        for key in gt_keys:
            gt_value = self._normalize_value(gt_json[key])

            if key not in result_json:
                # Key missing from result
                missing_keys += 1
                key_matches[key] = False
                mismatches_detail[key] = {
                    "expected": gt_value,
                    "actual": None,
                    "reason": "missing"
                }
            else:
                result_value = self._normalize_value(result_json[key])

                if result_value == gt_value:
                    matched_keys += 1
                    key_matches[key] = True
                else:
                    mismatched_values += 1
                    key_matches[key] = False
                    mismatches_detail[key] = {
                        "expected": gt_value,
                        "actual": result_value,
                        "reason": "value_mismatch"
                    }

        accuracy = (matched_keys / total_keys) if total_keys > 0 else 1.0
        step_name = self._extract_step_name(result_file)

        return ComparisonResult(
            result_file=str(result_file),
            ground_truth_file=str(gt_file),
            step_name=step_name,
            accuracy=round(accuracy, 4),
            total_keys=total_keys,
            matched_keys=matched_keys,
            missing_keys=missing_keys,
            mismatched_values=mismatched_values,
            key_matches=key_matches,
            mismatches_detail=mismatches_detail
        )

    def _merge_json_files(self, result_files: List[Path]) -> Dict[str, Any]:
        """
        Merge multiple JSON result files into a single dictionary.
        Later files override earlier files if keys conflict.
        """
        merged = {}

        for result_file in result_files:
            if isinstance(result_file, Path) and result_file.exists():
                data = self._load_json(result_file)
                merged.update(data)
            else:
                print(f"Warning: Result file not found: {result_file}")

        return merged

    def _compare_merged_results(self, result_files: List[Path], gt_file: Path, file_path: Path) -> ComparisonResult:
        """
        Merge all result files and compare against ground truth.
        GT is the holy grail - only keys present in GT are evaluated.
        """
        # Merge all result JSONs into one
        merged_result = self._merge_json_files(result_files)
        result_json = self._flatten_json(merged_result)

        gt_json = self._flatten_json(self._load_json(gt_file))

        # GT keys are the source of truth
        gt_keys = set(gt_json.keys())
        total_keys = len(gt_keys)

        matched_keys = 0
        missing_keys = 0
        mismatched_values = 0
        key_matches = {}
        mismatches_detail = {}

        for key in gt_keys:
            gt_value = self._normalize_value(gt_json[key])

            if key not in result_json:
                # Key missing from result
                missing_keys += 1
                key_matches[key] = False
                mismatches_detail[key] = {
                    "expected": gt_value,
                    "actual": None,
                    "reason": "missing"
                }
            else:
                result_value = self._normalize_value(result_json[key])

                if result_value == gt_value:
                    matched_keys += 1
                    key_matches[key] = True
                else:
                    mismatched_values += 1
                    key_matches[key] = False
                    mismatches_detail[key] = {
                        "expected": gt_value,
                        "actual": result_value,
                        "reason": "value_mismatch"
                    }

        accuracy = (matched_keys / total_keys) if total_keys > 0 else 1.0

        # Use PDF file name as identifier for overall comparison
        step_name = file_path.stem if file_path else "merged"

        return ComparisonResult(
            result_file=f"merged_{len(result_files)}_files",
            ground_truth_file=str(gt_file),
            step_name=step_name,
            accuracy=round(accuracy, 4),
            total_keys=total_keys,
            matched_keys=matched_keys,
            missing_keys=missing_keys,
            mismatched_values=mismatched_values,
            key_matches=key_matches,
            mismatches_detail=mismatches_detail
        )

    def _run_comparisons(self) -> None:
        """Run comparisons for all matches by merging result files."""
        for match in self.matches:
            if not match.ground_truth.exists():
                print(f"Warning: Ground truth file not found: {match.ground_truth}")
                continue

            # Handle both single Path and list[Path] for result
            result_files = match.result if isinstance(match.result, list) else [match.result]

            # Filter out invalid paths
            valid_files = [f for f in result_files if isinstance(f, Path) and f.exists()]

            if not valid_files:
                print(f"Warning: No valid result files found for {match.file_path}")
                continue

            # Merge all results and compare once
            comparison = self._compare_merged_results(valid_files, match.ground_truth, match.file_path)
            self.comparisons.append(comparison)

    # ----------------------------------------------------------------------
    # Public API - Reporting
    # ----------------------------------------------------------------------
    def report(self, verbose: bool = False) -> None:
        """Print comparison results."""
        if not self.comparisons:
            print("No comparisons available.")
            return

        print("\n" + "="*80)
        print("JSON MATCHER RESULTS")
        print("="*80)

        for comp in self.comparisons:
            print(f"\n📄 {comp.step_name}")
            print(f"   Result: {comp.result_file}")
            print(f"   GT:     {comp.ground_truth_file}")
            print(f"   Accuracy: {comp.accuracy * 100:.2f}% ({comp.matched_keys}/{comp.total_keys})")
            print(f"   Missing keys: {comp.missing_keys}, Mismatched values: {comp.mismatched_values}")

            if verbose and comp.mismatches_detail:
                print(f"\n   Mismatches:")
                for key, detail in comp.mismatches_detail.items():
                    print(f"      • {key}:")
                    print(f"        Expected: {detail['expected']}")
                    print(f"        Actual:   {detail['actual']}")
                    print(f"        Reason:   {detail['reason']}")

        # Overall stats
        if self.comparisons:
            avg_accuracy = sum(c.accuracy for c in self.comparisons) / len(self.comparisons)
            print(f"\n{'='*80}")
            print(f"OVERALL AVERAGE ACCURACY: {avg_accuracy * 100:.2f}%")
            print(f"{'='*80}\n")

    # ----------------------------------------------------------------------
    # Public API - Metrics for MLflow
    # ----------------------------------------------------------------------
    def get_accuracy_per_key(self) -> Dict[str, float]:
        """
        Compute accuracy for each individual key across all comparisons.
        Useful for tracking which fields are consistently extracted correctly.
        """
        key_stats = defaultdict(lambda: {"correct": 0, "total": 0})

        for comp in self.comparisons:
            for key, matched in comp.key_matches.items():
                key_stats[key]["total"] += 1
                if matched:
                    key_stats[key]["correct"] += 1

        results = {}
        for key, stats in key_stats.items():
            accuracy = (stats["correct"] / stats["total"]) * 100 if stats["total"] > 0 else 0
            # Sanitize key name for MLflow (replace dots with underscores)
            safe_key = key.replace(".", "_")
            results[f"accuracy_{safe_key}"] = round(accuracy, 2)

        return results

    def get_accuracy_per_step(self) -> Dict[str, float]:
        """
        Compute accuracy for each PDF file.
        Useful for identifying which files were extracted correctly.
        """
        step_stats = defaultdict(lambda: {"correct": 0, "total": 0})

        for comp in self.comparisons:
            step_stats[comp.step_name]["correct"] += comp.matched_keys
            step_stats[comp.step_name]["total"] += comp.total_keys

        results = {}
        for step, stats in step_stats.items():
            accuracy = (stats["correct"] / stats["total"]) * 100 if stats["total"] > 0 else 0
            results[f"accuracy_file_{step}"] = round(accuracy, 2)

        return results

    def get_overall_accuracy(self) -> Dict[str, float]:
        """Get overall accuracy across all comparisons."""
        if not self.comparisons:
            return {"overall_accuracy": 0.0}

        total_matched = sum(c.matched_keys for c in self.comparisons)
        total_keys = sum(c.total_keys for c in self.comparisons)

        overall = (total_matched / total_keys * 100) if total_keys > 0 else 0.0

        return {
            "overall_accuracy": round(overall, 2),
            "total_comparisons": len(self.comparisons),
            "total_keys_evaluated": total_keys,
            "total_keys_matched": total_matched
        }

    def get_all_metrics(self) -> Dict[str, float]:
        """Get all metrics combined for logging to MLflow (excluding per-file accuracy)."""
        metrics = {}
        metrics.update(self.get_overall_accuracy())
        # Removed get_accuracy_per_step() - now logged as artifact instead
        metrics.update(self.get_accuracy_per_key())
        return metrics

    def get_per_file_accuracy_artifact(self) -> Dict[str, float]:
        """Get per-file accuracy data for artifact logging (not metrics)."""
        return self.get_accuracy_per_step()
