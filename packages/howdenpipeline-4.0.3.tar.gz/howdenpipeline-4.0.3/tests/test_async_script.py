import asyncio
import time
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from HowdenPipeline.flow.graph_pipeline import GraphPipeline
from HowdenPipeline.flow.match import Match


def _make_pdf_tree(root: Path, n_files: int) -> Path:
    for i in range(n_files):
        sub = root / f"file_{i}"
        sub.mkdir(parents=True, exist_ok=True)
        (sub / f"file_{i}.pdf").write_bytes(b"%PDF-1.4 fake")
    return root


def _build_pipeline(pdf_root: Path) -> GraphPipeline:
    return GraphPipeline(
        pdf=pdf_root,
        parameter=MagicMock(),
        tracker=None,
        delete_folder=False,
    )


@pytest.mark.asyncio
async def test_empty_path_returns_empty_list():
    pipeline = _build_pipeline(pdf_root=Path("."))
    pipeline.file_paths_pdf = None

    result = await pipeline.execute()

    assert result == []


@pytest.mark.asyncio
async def test_files_run_concurrently(tmp_path):
    N = 4
    SLEEP = 0.3
    TOLERANCE = 0.6

    _make_pdf_tree(tmp_path, N)
    pipeline = _build_pipeline(tmp_path)

    call_times: list[tuple[float, float]] = []

    async def fake_run_for_file(self, file_path: Path) -> Match:
        start = time.perf_counter()
        await asyncio.sleep(SLEEP)
        end = time.perf_counter()
        call_times.append((start, end))
        return Match(result="", ground_truth=Path("GT.json"), file_path=file_path)

    with patch(
        "HowdenPipeline.flow.file_pipeline_runner.FilePipelineRunner.run_for_file",
        new=fake_run_for_file,
    ):
        t0 = time.perf_counter()
        results = await pipeline.execute()
        elapsed = time.perf_counter() - t0

    assert len(results) == N

    sequential_time = N * SLEEP
    assert elapsed < sequential_time * TOLERANCE, (
        f"Not concurrent: elapsed={elapsed:.2f}s, sequential={sequential_time:.2f}s"
    )

    starts = [s for s, _ in call_times]
    ends = [e for _, e in call_times]
    assert max(starts) < min(ends), "Tasks did not overlap — they ran sequentially"


@pytest.mark.asyncio
async def test_single_file(tmp_path):
    pdf = tmp_path / "doc.pdf"
    pdf.write_bytes(b"%PDF-1.4 fake")

    pipeline = _build_pipeline(pdf)

    async def fake_run_for_file(self, file_path: Path) -> Match:
        return Match(result="", ground_truth=Path("GT.json"), file_path=file_path)

    with patch(
        "HowdenPipeline.flow.file_pipeline_runner.FilePipelineRunner.run_for_file",
        new=fake_run_for_file,
    ):
        results = await pipeline.execute()

    assert len(results) == 1
    assert results[0].file_path == pdf.resolve()


@pytest.mark.asyncio
async def test_async_step_is_awaited():
    awaited = []

    async def async_step(input_data):
        awaited.append(input_data)
        return "async_result"

    assert asyncio.iscoroutinefunction(async_step)

    result = await async_step("sample_input")

    assert result == "async_result"
    assert awaited == ["sample_input"]

