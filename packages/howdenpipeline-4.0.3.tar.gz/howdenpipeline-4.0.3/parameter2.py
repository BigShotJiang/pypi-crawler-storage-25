from HowdenConfig import Config
from string import Template


class TotalPrice(Config):
    provider_and_model: str = "openai:gpt-5-mini"
    system: str = "You are an invoice extractor."
    use_web_search_tool: bool = False
    response_format: dict = {
        "type": "json_schema",
        "name": "invoice_total",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "payment_amount": {"type": "number"}
            },
            "required": ["payment_amount"],
            "additionalProperties": False
        }
    }
    template: Template = Template(
        """
        What is the total price of the invoice?
        Remove any currency symbols. Return as a number, not a string.

        Example output:
        {
          "payment_amount": 8327.50
        }

        Content:
        \"\"\"$content\"\"\"
        """
    )


class PaymentDate(Config):
    provider_and_model: str = "openai:gpt-5-mini"
    use_web_search_tool: bool = False
    system: str = "You are an invoice extractor."
    response_format: dict = {
        "type": "json_schema",
        "name": "invoice_payment_date",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "payment_date": {"type": ["string", "null"]}
            },
            "required": ["payment_date"],
            "additionalProperties": False
        }
    }
    template: Template = Template(
        """
    You are an information extraction system.

    Task:
    Extract the invoice date from the content below.

    Requirements:
    1. The date must be in the format dd-mm-yyyy.
    2. If multiple dates appear, choose the one that clearly represents the invoice date.
    3. If no payment date can be found, return null.
    4. The response must be a JSON object with exactly one key: "payment_date".

    Example output:
    {
      "payment_date": "01-05-2005"
    }

    Content:
    \"\"\"$content\"\"\"
    """
    )


class Parser(Config):
    provider_and_model: str = "llamaparser:"
    result_type: str = "md"
    model: str = "anthropic-sonnet-4.5"
    parse_mode: str = "parse_page_with_agent"
    merge_tables_across_pages_in_markdown: bool = True
    preserve_layout_alignment_across_pages: bool = False
    hide_footers: bool = True
    hide_headers: bool = True
    tier: str = "agentic"
    version: str = "latest"
    merge_continued_tables: bool = True


class Tracker(Config):
    logger_type: str = "mlflow"
    project_name: str = "howden_pipeline"


class Parameter(Config):
    tracker: Tracker = Tracker()
    parser: Parser = Parser()
    payment_info: TotalPrice = TotalPrice()
    payment_date: PaymentDate = PaymentDate()
    root_folder: str = r"C:\jetbrains\howden_pipeline\.data"