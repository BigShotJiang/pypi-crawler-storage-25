import sys
import re

pyproject = "pyproject.toml"

def bump_version(version: str, bump_type: str) -> str:
    major, minor, patch = map(int, version.split("."))
    if bump_type == "patch":
        patch += 1
    elif bump_type == "minor":
        minor += 1
        patch = 0
    elif bump_type == "major":
        major += 1
        minor = 0
        patch = 0
    else:
        print(f"Unknown argument: --{bump_type}")
        return version
    return f"{major}.{minor}.{patch}"

# Read the bump type from command line argument
if len(sys.argv) > 1:
    arg = sys.argv[1].lstrip("-")
else:
    arg = "patch"

with open(pyproject, "r", encoding="utf-8") as f:
    content = f.read()

match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
if not match:
    print("Could not find version in pyproject.toml")
    sys.exit(1)

current_version = match.group(1)
new_version = bump_version(current_version, arg)

content = content.replace(f'version = "{current_version}"', f'version = "{new_version}"', 1)

with open(pyproject, "w", encoding="utf-8") as f:
    f.write(content)

print(f"Version bumped: {current_version} → {new_version}")
