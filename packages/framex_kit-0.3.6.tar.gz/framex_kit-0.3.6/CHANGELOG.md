# CHANGELOG

<!-- version list -->

## v0.3.6 (2026-04-17)

### Bug Fixes

- Add mysql to sensitive config keywords
  ([`5e3cd76`](https://github.com/touale/FrameX-kit/commit/5e3cd7609b59b2f69afb6ac183cb212a50173dc4))

- Fix configuration reading error in ray
  ([`989065c`](https://github.com/touale/FrameX-kit/commit/989065cfef3f4ad5e1316782a9eef44c86c79891))

- Improve plugin config fallback logic
  ([`ab5d1b9`](https://github.com/touale/FrameX-kit/commit/ab5d1b901f7dd8ec2830783073c3e32681d03d3d))

### Refactoring

- Make repository operations async
  ([`8a61f21`](https://github.com/touale/FrameX-kit/commit/8a61f217bd8db89d7591e4b0d05c222b116f07dc))


## v0.3.5 (2026-04-17)

### Bug Fixes

- Enforce repository access checks and restrict config paths
  ([`411c241`](https://github.com/touale/FrameX-kit/commit/411c2419eba2ece457b7024e6778c195a43c8064))

- Reduce OAuth scope to read_user and read_api
  ([`36d58fe`](https://github.com/touale/FrameX-kit/commit/36d58fec1141220cb10951b6202b439bf4b83ecc))

### Chores

- **deps-dev**: Bump pytest from 9.0.2 to 9.0.3
  ([`c8cf8b6`](https://github.com/touale/FrameX-kit/commit/c8cf8b62f87112058e6155c0fc7686211c5a1a49))

### Documentation

- Add online documentation link and badge
  ([`1b7081a`](https://github.com/touale/FrameX-kit/commit/1b7081aaf93b106018779a503ff14dc2269338d8))

### Features

- Add embedded config files support in plugin config
  ([`85fe10d`](https://github.com/touale/FrameX-kit/commit/85fe10d36b1a2e2d4a9c9882be40a850f5a5db25))

- Add OAuth provider and private repository access
  ([`e6ab19d`](https://github.com/touale/FrameX-kit/commit/e6ab19d0082db2dd6cd52b524ccc8d3cf060ede8))

- Add plugin release check and config view
  ([`2344e7f`](https://github.com/touale/FrameX-kit/commit/2344e7f26e2443f379572ffb46097332b6bb8288))

- Enforce OAuth for plugin config documentation
  ([`b9499ac`](https://github.com/touale/FrameX-kit/commit/b9499accd39c16c9f76c619f2066ed4b23649aec))


## v0.3.4 (2026-04-13)

### Chores

- **deps**: Bump python-multipart from 0.0.24 to 0.0.26
  ([`7a7f641`](https://github.com/touale/FrameX-kit/commit/7a7f6417224ccaa19c6ca501d88b9f7fe10db93a))

- **deps**: Bump uvicorn from 0.43.0 to 0.44.0
  ([`fc4fe67`](https://github.com/touale/FrameX-kit/commit/fc4fe671c4b7e6e169daeeaf062b7781f35a6631))

- **deps-dev**: Bump poethepoet from 0.41.0 to 0.44.0
  ([`48342e3`](https://github.com/touale/FrameX-kit/commit/48342e37659d0bcc788cab8fc1c8e54da77a5650))

- **deps-dev**: Bump pytest-cov from 7.0.0 to 7.1.0
  ([`5e19707`](https://github.com/touale/FrameX-kit/commit/5e19707130ebc2c06d23e8e25f8c2fbd447209a2))

### Continuous Integration

- Bump ruff to v0.15.10
  ([`a6883c7`](https://github.com/touale/FrameX-kit/commit/a6883c716f3819fc99289418972f0d8ce7e98fa2))

- Enable autofix for PRs in pre-commit config
  ([`324e968`](https://github.com/touale/FrameX-kit/commit/324e968b510d8aaafa5a97a594c86f96a368a069))

- Restrict permissions to read-only contents
  ([`9f73ced`](https://github.com/touale/FrameX-kit/commit/9f73cedac8c386ed5e356c599802ec1efb7d9a88))

### Documentation

- Add logo and improve README layout
  ([`94b5c72`](https://github.com/touale/FrameX-kit/commit/94b5c724153d8502846d4ec09050e7203ee18393))

- Refine documentation structure
  ([`7f15f5b`](https://github.com/touale/FrameX-kit/commit/7f15f5b759877ddb6174452cbc6a581584a951e2))

- Refine README for clarity and conciseness
  ([`5d6e381`](https://github.com/touale/FrameX-kit/commit/5d6e3813a7748905d49dd3908b5a9e7628fe49dd))

- Remove blank lines in README
  ([`20343f1`](https://github.com/touale/FrameX-kit/commit/20343f18e149775691f50e872eac491670d7a3a0))

- Remove Python version badge from README
  ([`9781d8e`](https://github.com/touale/FrameX-kit/commit/9781d8e4d1156b64d03032a142d9574ca37743d9))

- Update license to MIT
  ([`187fe56`](https://github.com/touale/FrameX-kit/commit/187fe567b6ed0ecfb19c2dd9d07a3e27fdeaaba1))

- Update README with architecture diagram and features
  ([`c79b14c`](https://github.com/touale/FrameX-kit/commit/c79b14cab036527eaa7e4ea889d3923cc4658429))

### Features

- Add expand/collapse all tags button in Swagger UI
  ([`e569bce`](https://github.com/touale/FrameX-kit/commit/e569bce0f5b2cb7cd6ee93b93d231faa1a21857f))

- Implement adaptive ingress config for ray serve
  ([`424fbf1`](https://github.com/touale/FrameX-kit/commit/424fbf1599846465a9a4a0f017c3457dd8b498ee))


## v0.3.3 (2026-04-09)

### Features

- Customize Swagger UI and move plugin description
  ([`84f2ae0`](https://github.com/touale/FrameX-kit/commit/84f2ae0e28f82838febe5409a163ec92abbec764))

### Testing

- Use AUTH_COOKIE_NAME constant in auth test
  ([`c74ac4a`](https://github.com/touale/FrameX-kit/commit/c74ac4a4cc88c19b6443d4e82e82a8434f656ca4))


## v0.3.2 (2026-04-09)

### Features

- Add AUTH_TOKEN_NAME constant for token handling
  ([`2b26319`](https://github.com/touale/FrameX-kit/commit/2b2631918d69fee85b24250ab797369a65b6e132))

- Add plugin description and tags metadata
  ([`d7f98dc`](https://github.com/touale/FrameX-kit/commit/d7f98dc2475af2a7b108fc06bea50fe052b94170))

- Update plugin tags and version config
  ([`d08d616`](https://github.com/touale/FrameX-kit/commit/d08d616015180a756b3c7d2a182c2029b2adbb7f))


## v0.3.1 (2026-04-08)

### Bug Fixes

- Remove unused annotation helpers
  ([`825a030`](https://github.com/touale/FrameX-kit/commit/825a0304dbd1ebebe5effeab5b1a8edbe0e81f6e))

- Simplify proxy content type handling
  ([`3a04343`](https://github.com/touale/FrameX-kit/commit/3a043436afa1a428ab0a1292c541259bce1ba513))

### Chores

- **deps**: Bump actions/deploy-pages from 4 to 5
  ([`b30ce0f`](https://github.com/touale/FrameX-kit/commit/b30ce0fe448b12ac6b944431a73728cc00253898))

- **deps**: Bump aiohttp from 3.13.3 to 3.13.4
  ([`6c64206`](https://github.com/touale/FrameX-kit/commit/6c64206386c074a74b199d5e50240eab4276a9f1))

- **deps**: Bump codecov/codecov-action from 5 to 6
  ([`436b4fa`](https://github.com/touale/FrameX-kit/commit/436b4fa46f9eba5da0baec71571fb98ad698edab))

- **deps**: Bump pygments from 2.19.2 to 2.20.0
  ([`5dea877`](https://github.com/touale/FrameX-kit/commit/5dea87722d739d89a7a55f6bb7aff0e4a1cfc15a))

- **deps**: Bump python-multipart from 0.0.22 to 0.0.24
  ([`6c1c605`](https://github.com/touale/FrameX-kit/commit/6c1c605618deb5f69e7f2f06ef0a80ffe6fbea5c))

- **deps**: Bump pytz from 2025.2 to 2026.1.post1
  ([`42d18ae`](https://github.com/touale/FrameX-kit/commit/42d18aed7aa232d79623ed8a52de646c701b44db))

- **deps**: Bump ray[serve] from 2.54.0 to 2.54.1
  ([`1fc2fda`](https://github.com/touale/FrameX-kit/commit/1fc2fda557453bd152b45b60a06d6ec65b471c54))

- **deps**: Bump requests from 2.32.5 to 2.33.0
  ([`3b596ff`](https://github.com/touale/FrameX-kit/commit/3b596ff029d3eecd1d7e54407d399ed702655a52))

- **deps**: Bump tomli from 2.3.0 to 2.4.1
  ([`e38c9d5`](https://github.com/touale/FrameX-kit/commit/e38c9d5b5a027b128f8d0cc152f5c39d5de2f7f5))

- **deps**: Bump uvicorn from 0.41.0 to 0.42.0
  ([`0c8f719`](https://github.com/touale/FrameX-kit/commit/0c8f719d7f59faa912b31aec3406ac7a151f7cfc))

- **deps**: Bump uvicorn from 0.42.0 to 0.43.0
  ([`770d3a7`](https://github.com/touale/FrameX-kit/commit/770d3a7a187e7271f17ce260309296e3c1e05930))

- **deps-dev**: Bump coverage from 7.13.3 to 7.13.5
  ([`94b0cfb`](https://github.com/touale/FrameX-kit/commit/94b0cfbb96d639950698c83677a43c1fb48acc56))

- **deps-dev**: Bump ruff from 0.15.4 to 0.15.8
  ([`b43f9cf`](https://github.com/touale/FrameX-kit/commit/b43f9cf37094e0e25091e483f0f2c9dc6a03fbe1))

### Features

- Add multipart/form-data support for proxy plugin
  ([`6a5c129`](https://github.com/touale/FrameX-kit/commit/6a5c129197b239a7357438a09e00ee0ee00fb92e))

- Enhance plugin tags with author and version info
  ([`8539a43`](https://github.com/touale/FrameX-kit/commit/8539a432f32d52f705a904c8d2ea6fd9dc0f1e07))

- Remove Enum from tags type hints
  ([`7bcf9c1`](https://github.com/touale/FrameX-kit/commit/7bcf9c1d5ca971b3ea0a6a5f0d591974334333f0))

### Refactoring

- Simplify API resolver and remove ApiResolver class
  ([`84f3f60`](https://github.com/touale/FrameX-kit/commit/84f3f60cfb3ea8fd9520b37ebc3aefc9376a26d9))

### Testing

- Improve auth tests and coroutine handling
  ([`b7c0cad`](https://github.com/touale/FrameX-kit/commit/b7c0cad005fe0a5c9abd5ab0e5bab5193b41ce62))


## v0.3.0 (2026-03-26)

### Bug Fixes

- Enforce default API resolver configuration
  ([`37212a3`](https://github.com/touale/FrameX-kit/commit/37212a3ee648e696b505b703724edcc4f7f8b559))

- Update response message based on status code
  ([`c8c2c50`](https://github.com/touale/FrameX-kit/commit/c8c2c50667a32e51053aa78e986d4274a1af90f6))

- Update use_ray setting and improve exception handling
  ([`6c184cb`](https://github.com/touale/FrameX-kit/commit/6c184cb4954f7e543ea6664aa41c6cdf0ff9a397))

- Use Field default_factory for mutable defaults
  ([`0205e9f`](https://github.com/touale/FrameX-kit/commit/0205e9f3b267a9901d72ecfcf0898747f0911840))

### Chores

- **deps**: Bump pyasn1 from 0.6.2 to 0.6.3
  ([`28a4f18`](https://github.com/touale/FrameX-kit/commit/28a4f1807760c037eb0da87e87101994ae1c22e4))

- **deps**: Bump pydantic from 2.12.3 to 2.12.5
  ([`b92a0b2`](https://github.com/touale/FrameX-kit/commit/b92a0b2cb57cc82e8ea86e049229bad4b1b7db41))

- **deps**: Bump pydantic-settings from 2.11.0 to 2.13.1
  ([`d3de700`](https://github.com/touale/FrameX-kit/commit/d3de700a633e56de4f3daa6563cfec2e5a6dcd6a))

- **deps**: Bump pyjwt from 2.10.1 to 2.12.0
  ([`d75ea36`](https://github.com/touale/FrameX-kit/commit/d75ea36b5b90f9fc0b658f5dc267fbf0e9ba3458))

- **deps**: Bump pyjwt from 2.12.0 to 2.12.1
  ([`08acce0`](https://github.com/touale/FrameX-kit/commit/08acce04ed5ccac27892bafd96fbdd64666c96e5))

- **deps-dev**: Bump pre-commit from 4.3.0 to 4.5.1
  ([`0e0a19d`](https://github.com/touale/FrameX-kit/commit/0e0a19d217b75fb7f16d55a17da81bd4fcd1b1b6))

- **deps-dev**: Bump pytest-env from 1.2.0 to 1.5.0
  ([`4821e84`](https://github.com/touale/FrameX-kit/commit/4821e845c6d3ac85ab3f1ac057e4fb7924f6e140))

- **deps-dev**: Bump pytest-env from 1.5.0 to 1.6.0
  ([`3816b7b`](https://github.com/touale/FrameX-kit/commit/3816b7ba41d3dc4c402b83a4499c0b7dcc3fcd69))

- **deps-dev**: Bump types-pytz
  ([`6c36498`](https://github.com/touale/FrameX-kit/commit/6c364985b049b480fb4f25d8f5220e0c198e673a))

### Features

- Add ApiResolver and context management for plugin APIs
  ([`1fc81d8`](https://github.com/touale/FrameX-kit/commit/1fc81d81e6c5fe13a087666f4a092fa7da5c6d80))

- Add extend_kwargs and tags support to on_request
  ([`da57497`](https://github.com/touale/FrameX-kit/commit/da5749744b0b323cf1a8c7699b18ecf1515f46a7))

### Refactoring

- Extract ApiResolver to separate module
  ([`d7e3262`](https://github.com/touale/FrameX-kit/commit/d7e3262a474045b0712122af834a3e977a168600))

- Simplify deployment name assignment in on_register
  ([`8c5f455`](https://github.com/touale/FrameX-kit/commit/8c5f45521d6b94f92ec22de3c4b60385af1d362b))

### Testing

- Add Ray integration tests and coverage support
  ([`940761f`](https://github.com/touale/FrameX-kit/commit/940761f735a253315056f00fac63e37e91c82330))

### Update

- Improve proxy params logging with format_proxy_params
  ([`0e29702`](https://github.com/touale/FrameX-kit/commit/0e297020fee5c8372f1e48268f37c0027dadae1a))


## v0.2.15 (2026-03-10)

### Features

- Add raw_response option to on_request
  ([`b2603f3`](https://github.com/touale/FrameX-kit/commit/b2603f37534c64a261739542e84737eabe98300a))


## v0.2.14 (2026-03-08)

### Chores

- Remove renovate.json
  ([`ac17367`](https://github.com/touale/FrameX-kit/commit/ac17367da4f1877024b2cd943cd60f4fe3a62118))

- **deps**: Bump actions/download-artifact from 7 to 8
  ([`c69563a`](https://github.com/touale/FrameX-kit/commit/c69563a6bad83131f71a4931c2616b1ec2ee11f8))

- **deps**: Bump actions/upload-artifact from 6 to 7
  ([`1249a03`](https://github.com/touale/FrameX-kit/commit/1249a03cba107dd260b54ae0a3929d8b410b5c12))

- **deps-dev**: Bump ruff from 0.15.2 to 0.15.4
  ([`0ff74e6`](https://github.com/touale/FrameX-kit/commit/0ff74e6dbfa211c341c0a29c09956e7b2367cad7))

### Features

- Add api_prefix option to on_request
  ([`0de764a`](https://github.com/touale/FrameX-kit/commit/0de764a8cf0c617667c8b6f2b62805293aba7ab5))

- Add call_plugin_api to exports
  ([`42e4d4d`](https://github.com/touale/FrameX-kit/commit/42e4d4d6236399a1ed538361096fa330c9e595e7))

- Add plugin description to tags
  ([`e921f42`](https://github.com/touale/FrameX-kit/commit/e921f42d84903ada63370fc4f46e33f6f23a3afe))


## v0.2.13 (2026-02-26)

### Bug Fixes

- Optimize imports and error handling
  ([`52a571c`](https://github.com/touale/FrameX-kit/commit/52a571c49ddc5cc4cec6d824d6c40c12e453ca91))

### Chores

- Remove config.js
  ([`ec60188`](https://github.com/touale/FrameX-kit/commit/ec601882e06c514b8ca22b959f76d90fb15abf7b))

- Remove open-pull-requests-limit from dependabot.yml
  ([`34cd30c`](https://github.com/touale/FrameX-kit/commit/34cd30c64994066313178a4f746fa55427c20e23))

- **deps**: Bump ray from 2.53.0 to 2.54.0
  ([`faa045b`](https://github.com/touale/FrameX-kit/commit/faa045bba61bf312cc0f733c4fadb48a142ffb08))

- **deps**: Bump uvicorn from 0.38.0 to 0.40.0
  ([`b74a974`](https://github.com/touale/FrameX-kit/commit/b74a9748347b9315675ab3da895d6272c1ad7517))

- **deps-dev**: Bump poethepoet from 0.40.0 to 0.41.0
  ([`69f1e62`](https://github.com/touale/FrameX-kit/commit/69f1e62b5349a8fbbd331508d02b0bea1813a4f5))

- **deps-dev**: Bump ruff from 0.15.0 to 0.15.2
  ([`f116fad`](https://github.com/touale/FrameX-kit/commit/f116fad4a2ad5a9ef08b7756824a532b1a6489c7))

- **deps-dev**: Bump types-pytz
  ([`a07323e`](https://github.com/touale/FrameX-kit/commit/a07323efa4de3b89bb3899e9234d15b3754b0e17))

### Features

- Add version endpoint and tests
  ([`b115a53`](https://github.com/touale/FrameX-kit/commit/b115a532341a37194af1c7df10116ff7cefd2677))

- Disable sensitive URLs from being displayed in OpenAPI.
  ([`ae0e099`](https://github.com/touale/FrameX-kit/commit/ae0e0991e533464524ce16c1c72b2ba51f0a1f64))

- Enhance proxy config
  ([`ef2348d`](https://github.com/touale/FrameX-kit/commit/ef2348d8e012f3b63a503c4dd71675e1cd2f41fd))

### Refactoring

- Remove sync call support in ray adapter
  ([`1950e27`](https://github.com/touale/FrameX-kit/commit/1950e2765f2e2cd7b9544d54128a59364da9409c))

### Testing

- Add proxy config tests
  ([`d06c454`](https://github.com/touale/FrameX-kit/commit/d06c4544d8bb8c830bbbf3c93cbf746fc4387457))


## v0.2.12 (2026-02-09)

### Bug Fixes

- Correct typos and test assertions
  ([`baa243a`](https://github.com/touale/FrameX-kit/commit/baa243abe1f2d367f469194ea1d961dad53017ad))

### Chores

- Add type ignore for ray imports
  ([`2903d02`](https://github.com/touale/FrameX-kit/commit/2903d02a7b167b19dd751da92dd11721140d3024))

- Make ray optional dependency
  ([`5c4e72c`](https://github.com/touale/FrameX-kit/commit/5c4e72cd109a1eba105dca83238c75e47bfcd2e5))

- Modify Dependabot config for daily updates and new ecosystem
  ([`632bf69`](https://github.com/touale/FrameX-kit/commit/632bf697cc2f6eb8cde2f7d58ca29120521823aa))

- Remove pre-commit workflow
  ([`69ba702`](https://github.com/touale/FrameX-kit/commit/69ba7029d909f28ab5d773a8c7973bd1db989ea7))

- Update Dependabot and pre-commit to weekly schedule
  ([`c43d948`](https://github.com/touale/FrameX-kit/commit/c43d9487c101fedd9531bf4097c8c91bae448c8e))

- Update Dependabot commit message prefix
  ([`472043d`](https://github.com/touale/FrameX-kit/commit/472043d4dd380d0290def4881369fc9a0479f267))

- Update uv sync to include ray extra
  ([`4226667`](https://github.com/touale/FrameX-kit/commit/42266673ce57d9836387646a38034ff7d3bacd1b))

- **deps**: Bump python-semantic-release from 10.4.1 to 10.5.3
  ([`471b1ea`](https://github.com/touale/FrameX-kit/commit/471b1eaf8c51730bbdfd57d877f807d783105a03))

- **deps)(deps-dev**: Bump mypy from 1.18.2 to 1.19.1
  ([`179052f`](https://github.com/touale/FrameX-kit/commit/179052f5cf717361c558cbc1d256993239b61779))

- **deps)(deps-dev**: Bump poethepoet from 0.37.0 to 0.40.0
  ([`f03cd28`](https://github.com/touale/FrameX-kit/commit/f03cd2864d6c144cbb01fffda4854a123b06440d))

- **deps)(deps-dev**: Bump ruff from 0.14.14 to 0.15.0
  ([`3ce55bf`](https://github.com/touale/FrameX-kit/commit/3ce55bf686f123cd60012f62cc294fdd225d872d))

- **deps-dev**: Bump coverage from 7.11.0 to 7.13.3
  ([`efdd99e`](https://github.com/touale/FrameX-kit/commit/efdd99e353b88c8eb47cecd1a5f4508821cec171))

- **deps-dev**: Bump pytest from 8.4.2 to 9.0.2
  ([`39478d3`](https://github.com/touale/FrameX-kit/commit/39478d3addd8f5cfb5ffd0ed97cc88bef26d5948))

### Performance Improvements

- Correct proxy function invocation logic
  ([`c261b26`](https://github.com/touale/FrameX-kit/commit/c261b26e69c1a913cfed778d45c9ff87d79ad57a))

### Refactoring

- Restructure adapter invocation logic
  ([`e547ef1`](https://github.com/touale/FrameX-kit/commit/e547ef1ecb85e71a6a56b34e902319edc7ef4b5f))

### Testing

- Add comprehensive adapter tests
  ([`7d1c888`](https://github.com/touale/FrameX-kit/commit/7d1c888ce64441c8ed1a81ac5a8ad814849de58f))

- Add type ignore for remote function
  ([`29bb840`](https://github.com/touale/FrameX-kit/commit/29bb840f59a34701205df472c650f7ebb97b033c))


## v0.2.11 (2026-02-08)

### Bug Fixes

- Enhance proxy error handling and async validation
  ([`c122808`](https://github.com/touale/FrameX-kit/commit/c12280838f2121ae19145a26f09860cda26fe6b9))

- Handle null and refs in anyOf union types
  ([`315ed88`](https://github.com/touale/FrameX-kit/commit/315ed88b7b53015377f4269780bcf766c033aecb))

- Optimize proxy function lookup and test assertions
  ([`1222780`](https://github.com/touale/FrameX-kit/commit/12227800ae1dc508ff240a40d99fee109103f96d))


## v0.2.10 (2026-02-03)

### Bug Fixes

- Sort imports in test_auth.py
  ([`981b68e`](https://github.com/touale/FrameX-kit/commit/981b68e2b1980e6635c376bb3f4478959be21292))

### Chores

- Remove gitlab ci and update releaserc
  ([`367a68e`](https://github.com/touale/FrameX-kit/commit/367a68e3b90118ff1c9c5e47d791c48819e12832))

### Features

- Add loguru logging config for uvicorn
  ([`3583b6e`](https://github.com/touale/FrameX-kit/commit/3583b6e0dd570cb121ac3bba477bc4f0b50e617a))

- Add url filtering for sentry health checks
  ([`71ec193`](https://github.com/touale/FrameX-kit/commit/71ec19360467c89365d08e122bf3c7bef5a7d793))


## v0.2.9 (2026-01-30)

### Bug Fixes

- Add proxy check in register function
  ([`1e21cc4`](https://github.com/touale/FrameX-kit/commit/1e21cc421a44b86e6c6c00b749703a272ec796eb))

- Improve error handling and test client configuration
  ([`564f33e`](https://github.com/touale/FrameX-kit/commit/564f33ebc32dd68813965a05a32e1125a775156d))

### Chores

- Remove secret detection workflow
  ([`31956bc`](https://github.com/touale/FrameX-kit/commit/31956bc0a39c8fc9b69f55c10effa05358b28bf7))

- Update dependencies and lock file
  ([`cb25cbe`](https://github.com/touale/FrameX-kit/commit/cb25cbe05530afeb9cdf45357aaf06864ac42a93))

- **deps**: Bump aiohttp from 3.13.2 to 3.13.3
  ([`9e6e74d`](https://github.com/touale/FrameX-kit/commit/9e6e74d9c97d37546db038d219e57e1bdefbc04a))

- **deps**: Bump urllib3 from 2.5.0 to 2.6.3
  ([`eebdd53`](https://github.com/touale/FrameX-kit/commit/eebdd5344447e56b088639fb3867a4a02e7527ec))

- **deps**: Update dependency ruff to v0.14.14
  ([`cf1db8a`](https://github.com/touale/FrameX-kit/commit/cf1db8a7a35624b53ca418e7b713520807819ca0))

- **deps**: Update pre-commit hook astral-sh/ruff-pre-commit to v0.14.14
  ([`8c70926`](https://github.com/touale/FrameX-kit/commit/8c7092659c78983fef3e47aa687ed4d5ea7512b1))


## v0.2.8 (2026-01-12)

### Bug Fixes

- Add proxy function registration and on_proxy hook
  ([`0ba17da`](https://github.com/touale/FrameX-kit/commit/0ba17da004fe56af8468116e055a9f4e5723d2c0))

- Correct plugin name display in warning log
  ([`1b54e64`](https://github.com/touale/FrameX-kit/commit/1b54e648e976fd5e8eb33b74b1b024a0eb0eb25f))

- Default methods to GET when methods is None
  ([`4875ab2`](https://github.com/touale/FrameX-kit/commit/4875ab2cf02b767a315943c340cf7aeb26fd9df5))

- Enhance plugin version formatting in API registration
  ([`e4d2887`](https://github.com/touale/FrameX-kit/commit/e4d28871e9bee3888de7af2e22f943ba378a0816))

- Optimize proxy response handling and cache encoding
  ([`fada3ed`](https://github.com/touale/FrameX-kit/commit/fada3ed1f188d2ca839b0a5f51352d4bf2667bfa))

- Prevent duplicate remote proxy function registration
  ([`1de00ae`](https://github.com/touale/FrameX-kit/commit/1de00ae74d23b48545ed519830b6c739262998bc))

- Remove verbose kwargs from proxy function logging
  ([`a32e0cf`](https://github.com/touale/FrameX-kit/commit/a32e0cfb8a29dbb296b5a05e3023506f2e83bc94))

- Update OAuth redirect status code from 301 to 302
  ([`1d975e9`](https://github.com/touale/FrameX-kit/commit/1d975e966cfe572ee2641292f19641abf51a6507))

- Update version handling and environment variable support
  ([`23d2142`](https://github.com/touale/FrameX-kit/commit/23d2142ded0905e3d85d7c4cdf765d3446ffe119))

### Features

- Add duplicate route detection in APIIngress
  ([`548e042`](https://github.com/touale/FrameX-kit/commit/548e042a05c5e1359abe1a5c6642e6fa0c249ccc))

- Add retry mechanism with tenacity for proxy requests
  ([`4bc05e8`](https://github.com/touale/FrameX-kit/commit/4bc05e8f2bb574bc31d9df09e068fa702cea4aab))

- Add reversion config and enhance logging with colored output
  ([`72268af`](https://github.com/touale/FrameX-kit/commit/72268af391b8f2e042b8fb3e59879a846793b338))

- Implement OAuth authentication with JWT support
  ([`98b648c`](https://github.com/touale/FrameX-kit/commit/98b648c38a7ba87035e83670258658670f52dc78))

- Tenacity dependency and retry mechanism
  ([`2921208`](https://github.com/touale/FrameX-kit/commit/292120840bb78c8fe624bd6553a462a1cf88fd53))

### Testing

- Add comprehensive APIIngress route validation tests
  ([`73ee04d`](https://github.com/touale/FrameX-kit/commit/73ee04de5ca71f77770944275b9a1f27dce0d059))

- Add pragma comments and enhance OAuth authentication tests
  ([`b4ed409`](https://github.com/touale/FrameX-kit/commit/b4ed40959fe04850ff6ca1d87afdb0e3bf4588ab))

- Refactor OAuth callback and add authentication tests
  ([`2544602`](https://github.com/touale/FrameX-kit/commit/254460280bf3d4c80b0b4fced45a9d851fcf5e11))

- Replace AuthConfig tests with OAuthConfig test cases
  ([`b43539c`](https://github.com/touale/FrameX-kit/commit/b43539c24258e7a42fe689787fe37ab6b02df78c))


## v0.2.7 (2025-12-26)

### Bug Fixes

- Improve proxy function registration and auth configuration
  ([`9d66e07`](https://github.com/touale/FrameX-kit/commit/9d66e07da0826476076bc58e4d43ca5fa93eb396))

### Features

- Enhance error handling and proxy response format
  ([`160d16a`](https://github.com/touale/FrameX-kit/commit/160d16a50d0913f16b8747dbaa4c4a57bb553c12))

### Testing

- Enhance error handling and add status code constants
  ([`ccfee69`](https://github.com/touale/FrameX-kit/commit/ccfee690c105d2455a1ea94dc824ae6baf0dde6e))


## v0.2.6 (2025-12-25)

### Chores

- Change default docs password to admin
  ([`24aca13`](https://github.com/touale/FrameX-kit/commit/24aca13f858f21c3a85268a8e59e6a3e40467b75))

### Documentation

- Improve authentication documentation formatting and structure
  ([`dda03a7`](https://github.com/touale/FrameX-kit/commit/dda03a7251bd303f70c0d22e9fa79090de837a77))

### Features

- Enhance API docs with runtime status and plugin versions
  ([`1435d3d`](https://github.com/touale/FrameX-kit/commit/1435d3dec90ae55d6f189f003bc799613c4bee89))

### Refactoring

- Improve CLI config and auth settings management
  ([`96b0cab`](https://github.com/touale/FrameX-kit/commit/96b0cabe6593dba233cc3d6971b87a3fe05b7f76))

### Testing

- Improve parameter handling and add comprehensive CLI tests
  ([`f37ff4c`](https://github.com/touale/FrameX-kit/commit/f37ff4cdb042b0a90dedfb7c4e076d7ba3ca2cdd))

- Restructure auth configuration into unified rules format
  ([`ebaa96f`](https://github.com/touale/FrameX-kit/commit/ebaa96f0f510a276ed1c3eed6f27a9ef27984149))


## v0.2.5 (2025-12-24)

### Bug Fixes

- Fix proxy function serialization and error handling
  ([`7288013`](https://github.com/touale/FrameX-kit/commit/7288013342ce81cc39dce4dbb07c668997f59723))

- Handle negative num_cpus value in ray initialization
  ([`db98eee`](https://github.com/touale/FrameX-kit/commit/db98eee7b0264019821cf993080de72eb2ff385c))

### Chores

- Upgrade ray from 2.47.1 to 2.53.0
  ([`b4e2bd0`](https://github.com/touale/FrameX-kit/commit/b4e2bd034d8b2b00bb7a0c505ebcf389e84828e6))

- **deps**: Update dependency ruff to v0.14.10
  ([`359d731`](https://github.com/touale/FrameX-kit/commit/359d7312f2c5593918a274b398270906dbcfaf39))

- **deps**: Update pre-commit hook astral-sh/ruff-pre-commit to v0.14.10
  ([`537c431`](https://github.com/touale/FrameX-kit/commit/537c4311df69e313bbf40c352608e25c11ca2fa4))

### Documentation

- Add authentication, concurrency and proxy function documentation
  ([`82ecef1`](https://github.com/touale/FrameX-kit/commit/82ecef173c02f529c48ca4e7fec98f7462648c8c))

### Features

- Add docs authentication with basic auth
  ([`00530f8`](https://github.com/touale/FrameX-kit/commit/00530f8da9a2e21db89dca1bfe3d9740b25185b9))

- Add proxy function registration placeholder
  ([`8a1b9db`](https://github.com/touale/FrameX-kit/commit/8a1b9db3f094b662ced812d6792487dd3bbaef41))

- Add proxy function support
  ([`8b9e474`](https://github.com/touale/FrameX-kit/commit/8b9e47450819ca4fb075afb6b11b0bc04069f67a))

- Enhance proxy function auth with random key generation
  ([`ffa9438`](https://github.com/touale/FrameX-kit/commit/ffa9438f3ebfb5ee2563a2b9f57e352f24603467))

- Enhance proxy function registration and auth
  ([`f169727`](https://github.com/touale/FrameX-kit/commit/f16972742989225a94b75eff570ba6d3363a2936))

### Refactoring

- Simplify proxy decorator and remove proxy_only param
  ([`081026b`](https://github.com/touale/FrameX-kit/commit/081026b89cb0e1cc0b537f6c3b03aa6acb55a4fc))

### Testing

- Add comprehensive application tests and improve auth logging
  ([`fb2b5d5`](https://github.com/touale/FrameX-kit/commit/fb2b5d5da1456939cc6921cf8d940f0e1cfa9d71))

- Add pytest-order and enhance proxy tests
  ([`425984c`](https://github.com/touale/FrameX-kit/commit/425984cdf9e53ccae19a962266ec7597752a3abe))

- Enhance cache encode/decode and proxy exception handling
  ([`9488998`](https://github.com/touale/FrameX-kit/commit/9488998f1b876317f25af62c6a3ee16d2df488db))


## v0.2.4 (2025-10-27)

### Features

- Add configurable excluded log paths support
  ([`73eb430`](https://github.com/touale/FrameX-kit/-/commit/73eb430385d0bf981d4a77cb45caa44bba25f19e))


## v0.2.3 (2025-10-24)

### Documentation

- Add teacher project prediction plugin status
  ([`b81ff66`](https://github.com/touale/FrameX-kit/-/commit/b81ff66374b9cbe725e7a0a992c26c111de409f6))

### Features

- Optimize plugin API logging with batch output
  ([`7cc3a2d`](https://github.com/touale/FrameX-kit/-/commit/7cc3a2d69bcd9d794a6b5066eae34c023c8f3907))

### Testing

- Add exception handling tests for test mode and plugin calls
  ([`75d1a3f`](https://github.com/touale/FrameX-kit/-/commit/75d1a3f0b87e41be2a7974cb1a7e96f8f243162d))


## v0.2.2 (2025-10-21)

### Documentation

- Remove plugin data directory config references
  ([`6466648`](https://github.com/touale/FrameX-kit/-/commit/64666480bba779f9a07b818cbc1b5b83ea7a9066))

### Features

- Remove plugin data directory support
  ([`bcd5dd1`](https://github.com/touale/FrameX-kit/-/commit/bcd5dd1941a0a38abb8e36b55c9f88599b4f01e8))


## v0.2.1 (2025-10-21)

### Chores

- **deps**: Lock file maintenance
  ([`95d70ad`](https://github.com/touale/FrameX-kit/-/commit/95d70ad2f483270d4b40d076459e001ebddd725c))

### Documentation

- Update development.md
  ([`e21019a`](https://github.com/touale/FrameX-kit/-/commit/e21019a12df4e108d934e3c1c1d51c2030db4c57))

- Update precision medicine and international matching status to complete
  ([`28704d1`](https://github.com/touale/FrameX-kit/-/commit/28704d1946441234adf36de4c358bd1d051281c9))

- Update remote_calls.md
  ([`b1a4805`](https://github.com/touale/FrameX-kit/-/commit/b1a48051ca8d6e02289a9dd4c126cd0131fd0172))

- Update technology prediction report status to complete
  ([`4507a66`](https://github.com/touale/FrameX-kit/-/commit/4507a66a75a1abf39e19005def8da32b1d0ccfe2))

- Updateadvanced_test.md
  ([`b267a9f`](https://github.com/touale/FrameX-kit/-/commit/b267a9fc9a9fa5db078698d45d225eee6d172c7f))

### Features

- Enhance CLI with configurable server options and plugin loading
  ([`2de69e0`](https://github.com/touale/FrameX-kit/-/commit/2de69e0dd86e7b043c59f9241c2e40b0d664c0ad))


## v0.2.0 (2025-10-20)

### Update

- Stable version release, improve error message in plugin import failure
  ([`8dc340e`](https://github.com/touale/FrameX-kit/-/commit/8dc340e3e796d648ccba3048df1aa65d629413d0))


## v0.1.21 (2025-10-20)

### Documentation

- Update project status and links
  ([`0049415`](https://github.com/touale/FrameX-kit/-/commit/004941590e3060e44959b399717db44925bdfc45))

### Features

- Add configurable server host, port and CPU count
  ([`bcaacfa`](https://github.com/touale/FrameX-kit/-/commit/bcaacfa784b288a94300e393bf0c1155a9e0370d))


## v0.1.20 (2025-10-16)

### Bug Fixes

- Update API registration and HTTP client timeout handling
  ([`4efe031`](https://github.com/touale/FrameX-kit/-/commit/4efe031a3a798481c815ae42a931e84094874612))

### Chores

- Add line length ignore to ruff config
  ([`619323f`](https://github.com/touale/FrameX-kit/-/commit/619323f2acf1ba568fb180b45860db052c15147b))

### Documentation

- Update plugin config and contribution status
  ([`a2c8efa`](https://github.com/touale/FrameX-kit/-/commit/a2c8efa422d10e12409bde6b3045a7c6ba6adacc))

### Features

- Remove YAML support from configuration handling
  ([`bf281d3`](https://github.com/touale/FrameX-kit/-/commit/bf281d3c503caf3b388d44f1f464ad65aa4846b6))


## v0.1.19 (2025-10-15)

### Features

- Adjust the remote func of LocalAdapter to execute in thread
  ([`1b6163e`](https://github.com/touale/FrameX-kit/-/commit/1b6163e14764f0b22e17f1578c7887f50d51b206))


## v0.1.18 (2025-10-15)

### Bug Fixes

- Update plugin model field definitions
  ([`15fb2d0`](https://github.com/touale/FrameX-kit/-/commit/15fb2d01f5817dbb17b4eafa40c69a307b6101fc))


## v0.1.17 (2025-10-14)

### Documentation

- Update personnel matching and peer search status
  ([`d21a4e0`](https://github.com/touale/FrameX-kit/-/commit/d21a4e023921849aedd6a2df24963846ddf26826))

### Features

- Enhance remote decorator with method support
  ([`43e2ce3`](https://github.com/touale/FrameX-kit/-/commit/43e2ce33fb7a6529eaabd6d98b1dff8a6e926251))


## v0.1.16 (2025-09-29)

### Chores

- **deps**: Lock file maintenance
  ([`fec070c`](https://github.com/touale/FrameX-kit/-/commit/fec070cad0856e2048a58e02adaf01f3081e23a6))

- **deps**: Lock file maintenance
  ([`5b39979`](https://github.com/touale/FrameX-kit/-/commit/5b399799b7f847696e00c87d56a56ada87dc6acb))

### Documentation

- Remove task decomposition from contribution table
  ([`92d05d5`](https://github.com/touale/FrameX-kit/-/commit/92d05d58a2223c08b48de107f5037d2fb8a932dd))

- Update find_policy status in contribution table
  ([`2a13de2`](https://github.com/touale/FrameX-kit/-/commit/2a13de2d661950a3d3b60acdfa1943d9cca47762))

- Update plugin addresses and status in contribution table
  ([`e4c1303`](https://github.com/touale/FrameX-kit/-/commit/e4c1303d8996f1a624c4269af80cd74277f366f8))

### Features

- Add callback support for API params
  ([`2955952`](https://github.com/touale/FrameX-kit/-/commit/29559527720cabb5410f0ce4e7bc20daef7d6fcc))

### Testing

- Enhance VCR recording with response filtering
  ([#3](https://github.com/touale/FrameX-kit/-/merge_requests/3),
  [`cbb47f9`](https://github.com/touale/FrameX-kit/-/commit/cbb47f9ecbf803c764dbe10d8c8fa72cde7a82cb))


## v0.1.15 (2025-09-16)

### Chores

- Add release extras to lock file
  ([`fbd5db7`](https://github.com/touale/FrameX-kit/-/commit/fbd5db78b780377102955f84f328e82ba6d85770))

### Features

- Add CLI interface with click
  ([`1cd4bab`](https://github.com/touale/FrameX-kit/-/commit/1cd4babf67239a2c71dbc78ba79329a6591bc300))

### Performance Improvements

- Simplify plugin configuration handling
  ([`4110dcb`](https://github.com/touale/FrameX-kit/-/commit/4110dcb5268e3db39b1416111c30281ff250e446))


## v0.1.14 (2025-09-15)

### Bug Fixes

- Simplify parameter processing in proxy plugin
  ([`65f9265`](https://github.com/touale/FrameX-kit/-/commit/65f9265ab7805e53d176b533b06fbb9130aeb701))

### Chores

- **deps**: Lock file maintenance
  ([`5f34c36`](https://github.com/touale/FrameX-kit/-/commit/5f34c36132e06599739f1c4d1914d83e7a3fa434))


## v0.1.13 (2025-09-15)

### Chores

- Update gitignore, config schedule and plugin config
  ([`67d735f`](https://github.com/touale/FrameX-kit/-/commit/67d735fbf89eb68e99f91db44e32023bd4e0e4cd))

### Refactoring

- Improve plugin config validation
  ([`30067b6`](https://github.com/touale/FrameX-kit/-/commit/30067b62988806a5fdea373d59e52507d0a02529))


## v0.1.12 (2025-09-12)

### Performance Improvements

- Simplify plugin config retrieval
  ([`63ef0a1`](https://github.com/touale/FrameX-kit/-/commit/63ef0a16a016b7eb482c3e38f298be30eb51ef6a))


## v0.1.11 (2025-09-12)

### Chores

- Add refactor to patch tags in semantic release config
  ([`7160105`](https://github.com/touale/FrameX-kit/-/commit/7160105a3fb23955e33a93394f3f11626e1cb1e2))

- **deps**: Update dependency ruff to v0.13.0
  ([`872deff`](https://github.com/touale/FrameX-kit/-/commit/872deffad1c62225ebb9988cf588ef5a7d14198a))

### Continuous Integration

- Add ray to ignored dependencies in config
  ([`3e0260e`](https://github.com/touale/FrameX-kit/-/commit/3e0260e86eda1c40437a3fbde57fac2a6a1c4871))

### Refactoring

- Optimize plugin config loading
  ([`1590bda`](https://github.com/touale/FrameX-kit/-/commit/1590bda81b69165d4b4714e52daf8d6091716f03))


## v0.1.10 (2025-09-12)

### Continuous Integration

- Extend renovate to run on master and main branches
  ([`31f430d`](https://github.com/touale/FrameX-kit/-/commit/31f430d23b3885fe510e1bc5f7eea6a8c670aed8))

### Documentation

- Add contribution md
  ([`ef58fbd`](https://github.com/touale/FrameX-kit/-/commit/ef58fbdf9e756ab65440bf6c05cf59b66aa49028))

- Add end-to-end examples and improve plugin documentation
  ([`163c164`](https://github.com/touale/FrameX-kit/-/commit/163c1648b78e7df6f6cafe5daadf91a723654193))

- Add last changed info to documentation book
  ([`c70b13d`](https://github.com/touale/FrameX-kit/-/commit/c70b13db962c1c5f4d64bddcca171c739dd943db))

- Fix code indentation and update contribution guide
  ([`115ba2a`](https://github.com/touale/FrameX-kit/-/commit/115ba2a706192de00a8cd7543f887753920f2154))

- Format img
  ([`7e81d60`](https://github.com/touale/FrameX-kit/-/commit/7e81d60f8c8a28286121baa8c7073fb02d0cab84))

- Update development guide and add FAQ section
  ([`4b9b2bf`](https://github.com/touale/FrameX-kit/-/commit/4b9b2bf6c5cb5d2f9a50c1c75928a31b5808adee))

- Update documentation structure and content
  ([`ffbe735`](https://github.com/touale/FrameX-kit/-/commit/ffbe735e20bb1b7b7658f660b63103211abef251))

- Update README and add overview documentation
  ([`5222e34`](https://github.com/touale/FrameX-kit/-/commit/5222e3442bf302f3a4fab66e1b7077239b8c3372))

### Features

- Add renovate config and update plugin documentation
  ([`f7cd12f`](https://github.com/touale/FrameX-kit/-/commit/f7cd12ff74d7796bbfe013b8fb02214a3bb324d1))


## v0.1.9 (2025-09-05)

### Features

- Update plugin loading and config handling, add documentation book for framex
  ([`b686a9b`](https://github.com/touale/FrameX-kit/-/commit/b686a9b53fd3d7d919f884b4595655b204c03fb6))


## v0.1.8 (2025-09-02)

### Features

- Optimize API handling and plugin management
  ([`de76f9f`](https://github.com/touale/FrameX-kit/-/commit/de76f9f3f776a856e864306e6592f21fb3aacc2a))


## v0.1.7 (2025-08-08)

### Features

- Add remote func support and update tests
  ([`fff01e3`](https://github.com/touale/FrameX-kit/-/commit/fff01e3cd72b20155f8b07c13fe6ecc85a0fb602))


## v0.1.6 (2025-07-31)

### Features

- Add path white/black lists to ProxyPlugin and modify APIIngress return type
  ([`a0f5ba8`](https://github.com/touale/FrameX-kit/-/commit/a0f5ba8a219cfdbbbc2b16a9cf071a6b6d364b98))


## v0.1.5 (2025-07-22)


## v0.1.5-beta.1 (2025-07-22)

### Bug Fixes

- Lock ray version to 2.47.1 and update uv.lock
  ([`1a7d274`](https://github.com/touale/FrameX-kit/-/commit/1a7d274bfa5c16e0591d6571fca74c9829038890))

- Remove str handle type in APIIngress and ProxyPlugin
  ([`071d88c`](https://github.com/touale/FrameX-kit/-/commit/071d88ce2a4ab213ff673f17684a0a21e3ecc417))


## v0.1.4 (2025-07-22)

### Continuous Integration

- Skip release job for merge requests
  ([`8db6b74`](https://github.com/touale/FrameX-kit/-/commit/8db6b74eaff125e9fb080c6a972d50235a14646e))


## v0.1.4-beta.2 (2025-07-22)

### Bug Fixes

- Optimize pre-commit install and add test silent mode
  ([`24dda1e`](https://github.com/touale/FrameX-kit/-/commit/24dda1e2a63c13b2611093b5667fdd2f17497fa5))

### Refactoring

- Enhance BaseAdapter and remove redundant code in Local/Ray Adapters
  ([`43dad3a`](https://github.com/touale/FrameX-kit/-/commit/43dad3a8b4410c016ca900bd5aadb78e9a1ba8c4))

### Testing

- Add pytest-asyncio, asyncio_mode, and plugin tests
  ([`1b2fcc9`](https://github.com/touale/FrameX-kit/-/commit/1b2fcc901f587a9c1e8157a979990e5de6edb14e))


## v0.1.4-beta.1 (2025-07-18)

### Bug Fixes

- Fixed the problem of abnormal parameters of proxy plugin parsing remote API
  ([`51a7083`](https://github.com/touale/FrameX-kit/-/commit/51a708343e04a935a9ca4cd35967e56f3be6f2d1))

### Continuous Integration

- Add pre-commit cache and env var to .gitlab-ci.yml
  ([`2614993`](https://github.com/touale/FrameX-kit/-/commit/2614993f16542e2fd868c851448288c4856111bf))


## v0.1.3 (2025-07-17)

### Bug Fixes

- Ensure reversion starts with 'v' in _setup_sentry
  ([`a0f12c7`](https://github.com/touale/FrameX-kit/-/commit/a0f12c72afb531708a26615fd7a4fecc255bad25))


## v0.1.2 (2025-07-17)

### Features

- Add reversion param to _setup_sentry and run
  ([`588a78e`](https://github.com/touale/FrameX-kit/-/commit/588a78eefcac498a171ba61e08666b9a105ed8db))


## v0.1.1 (2025-07-17)

### Documentation

- Update LICENSE
  ([`b1512b2`](https://github.com/touale/FrameX-kit/-/commit/b1512b28a2af22254532c31128430c9877eb6bf8))

### Features

- Rename to framex-kit, add reversion env, default use_ray false
  ([`ca0c993`](https://github.com/touale/FrameX-kit/-/commit/ca0c993cb74ed97c7ec023090038878b15fbccb9))


## v0.1.0 (2025-07-17)


## v0.1.0-beta.1 (2025-07-17)

### Chores

- Disable Sentry in pytest config
  ([`e9243a0`](https://github.com/touale/FrameX-kit/-/commit/e9243a0e0b56c71e2632e02d9a5e16ec291a2993))

### Features

- Integrate Sentry for error tracking and logging
  ([`5b9847e`](https://github.com/touale/FrameX-kit/-/commit/5b9847ef6665e692f2c74bfca6979489c5f7fc81))

### Refactoring

- Rename and restructure settings for server and proxy
  ([`a39738f`](https://github.com/touale/FrameX-kit/-/commit/a39738fa838574d685f594485830f524cc96572d))

### Update

- Optimize log filtering logic for sentry and ignore prefixes
  ([`5140174`](https://github.com/touale/FrameX-kit/-/commit/5140174b0e279725aed70e9d3c8c0c4836838b25))


## v0.0.2-beta.7 (2025-07-16)

### Features

- Introduce adapter to reduce dependence on `use_ray` config
  ([`487316c`](https://github.com/touale/FrameX-kit/-/commit/487316cbdc4d49cdd03c836c029fcaff1ef74618))


## v0.0.2-beta.6 (2025-07-15)

### Bug Fixes

- Fix ray cannot recognize other routes
  ([`9145a83`](https://github.com/touale/FrameX-kit/-/commit/9145a83715caded218d4a4c4a8bcaeace66f739f))

### Chores

- Disable proxy by default in config
  ([`59763bc`](https://github.com/touale/FrameX-kit/-/commit/59763bc36404733d3d1a72d98db693156a6f886d))

- Simplify proxy config and default values
  ([`8292de3`](https://github.com/touale/FrameX-kit/-/commit/8292de3e313cc52b61c6be8bce4498637f1e4ab1))

### Features

- Add health check, invoker plugin, and test cases
  ([`11fe877`](https://github.com/touale/FrameX-kit/-/commit/11fe877f4f5d79add245d12d01615fda095fc3e8))

### Refactoring

- Refactor call remote func
  ([`dec8fee`](https://github.com/touale/FrameX-kit/-/commit/dec8fee25901af167eb15c22b402061fd44425c8))


## v0.0.2-beta.5 (2025-07-15)

### Code Style

- Add return type annotations for better type checking
  ([`ff32a01`](https://github.com/touale/FrameX-kit/-/commit/ff32a018b2ad50dd7900d876c8b4d6af7c3d84fa))

### Features

- Add multi TOML and YAML support for plugin configs
  ([`7210af1`](https://github.com/touale/FrameX-kit/-/commit/7210af1faa7a8fd82012cc59ab654322dca28ae2))

- Add Ray and non-Ray mode support for server
  ([`ce02945`](https://github.com/touale/FrameX-kit/-/commit/ce029454eaa9393eb51b4b5aeb30c711d8010368))

### Refactoring

- Add logger catch and optimize proxy handling in plugin init
  ([`578b4ee`](https://github.com/touale/FrameX-kit/-/commit/578b4ee5d78000c979b6cd0864772595b6370b18))

### Testing

- Add test coverage and pytest config for better reliability
  ([`5119039`](https://github.com/touale/FrameX-kit/-/commit/5119039e0239d5690fdb7e933eb06b711ec04a1d))


## v0.0.2-beta.4 (2025-07-11)

### Performance Improvements

- Optimize plugin config and data dir setup
  ([`1a15f5b`](https://github.com/touale/FrameX-kit/-/commit/1a15f5b0e614b205e33a9c1761faa5e08b5340bf))


## v0.0.2-beta.3 (2025-07-10)

### Performance Improvements

- Enhance plugin loading and settings integration
  ([`bf64c50`](https://github.com/touale/FrameX-kit/-/commit/bf64c508178b3fe62a33497384695d182d25b80e))


## v0.0.2-beta.2 (2025-07-10)

### Features

- Support mixed plugin import
  ([`1178495`](https://github.com/touale/FrameX-kit/-/commit/1178495bbcd94dca648be4214e87300326269a45))

### Performance Improvements

- Enhance proxy handling
  ([`ce18798`](https://github.com/touale/FrameX-kit/-/commit/ce187988139c57ad57e23784ba093d7b49efe803))


## v0.0.2-beta.1 (2025-07-09)

### Build System

- Add verbose flag to tag step in release task
  ([`9a1d528`](https://github.com/touale/FrameX-kit/-/commit/9a1d5287723efbaa1630a1ffbf9b358ade45e646))

### Continuous Integration

- Add git fetch to release step for better branch sync
  ([`c4d0afd`](https://github.com/touale/FrameX-kit/-/commit/c4d0afd00f0b3fad9b1cc3ab1ef6e24313c262a9))

- Disable allow_failure in secret_detection job
  ([`eb305f0`](https://github.com/touale/FrameX-kit/-/commit/eb305f0929ddc4f218a1b19065fac58f2bccb111))

### Features

- Add 'perf' to patch tags and optimize plugin API handling
  ([`c27982c`](https://github.com/touale/FrameX-kit/-/commit/c27982c82dca7e5390c37e6addb344f49f3688e1))

### Performance Improvements

- Refine API model typing and adjust on_request call_type
  ([`e1dda26`](https://github.com/touale/FrameX-kit/-/commit/e1dda267ed28f38fc99c711c9e9cdc6dd6bef61a))


## v0.0.1 (2025-07-09)

### Build System

- Configure semantic release
  ([`d4125f6`](https://github.com/touale/FrameX-kit/-/commit/d4125f661477e9d48a6bb0fc161cecf4fc07aa39))

### Code Style

- Enhance ruff config, add type hints, and refine plugin APIs
  ([`23bdaed`](https://github.com/touale/FrameX-kit/-/commit/23bdaedf229f66f1c38d4cbd27d25cf621c2d041))

- Enhance ruff config, update ServerConfig, and optimize plugin data dir
  ([`67df965`](https://github.com/touale/FrameX-kit/-/commit/67df96501387ea9517aca9521d9225fd57ab0964))

### Continuous Integration

- Add git checkout and status to CI/CD pipeline
  ([`3f757b9`](https://github.com/touale/FrameX-kit/-/commit/3f757b9ed07c2c651eb99771a1f24d9f9d88b9fd))

- Add poethepoet to release deps and update uv.lock
  ([`a3e5e53`](https://github.com/touale/FrameX-kit/-/commit/a3e5e538eee0a2f6ffc1aaa7bbdea1b130d41c72))

- Add release stage, update config, and refine tasks
  ([`3238f5f`](https://github.com/touale/FrameX-kit/-/commit/3238f5f01065ef51f8ba3116047d2141e5fd975a))

- Enhance pre-commit failure handling with diff output
  ([`f7324fa`](https://github.com/touale/FrameX-kit/-/commit/f7324fa91f4bccf605dfc9b7854e8e8229c587c2))

- Opt release step
  ([`d05a0cc`](https://github.com/touale/FrameX-kit/-/commit/d05a0cc33b09ab8aaf6321175bcce74c68d60b07))

- Optimize CI/CD config, update pre-commit repos, and adjust test-ci task
  ([`7c0332a`](https://github.com/touale/FrameX-kit/-/commit/7c0332ad8f3f1dcc155ba43f1ceba33abf33a358))

- Refactor CI/CD, add poe_tasks, and update dependencies
  ([`f5547ce`](https://github.com/touale/FrameX-kit/-/commit/f5547ce8ba5fa9327b0f0b879c5e44001ab2ec5f))

- Update branch matching and reorder config sections
  ([`0af1739`](https://github.com/touale/FrameX-kit/-/commit/0af1739af7111a254bbd0a610b7dcb97b40a02f0))

- Update CI/CD image path for Python container
  ([`848ca93`](https://github.com/touale/FrameX-kit/-/commit/848ca93f966c50e8f3debb725caf79c1c11bed52))

- Update secret detection and pre-commit pip version
  ([`2bbaab7`](https://github.com/touale/FrameX-kit/-/commit/2bbaab7aefa04ea8a2891fb1bbac81acba7f6296))

### Documentation

- Enhance plugin example in README
  ([`5243675`](https://github.com/touale/FrameX-kit/-/commit/52436758fe67298d79ff238b51dcc5b420b92bc9))

### Features

- Add BaseModel validation in on_request decorator
  ([`cebf955`](https://github.com/touale/FrameX-kit/-/commit/cebf955e65ebdd05533d385c27f351a0f93a4a7c))

- Add config support and proxy plugin enhancements
  ([`a8ea1db`](https://github.com/touale/FrameX-kit/-/commit/a8ea1db933bda9e506eff2f9abf600f25d293dfc))

- Add proxy plugin and enhance API response handling
  ([`c028153`](https://github.com/touale/FrameX-kit/-/commit/c028153955d348fb25e23b4eabbbf4de300bbd1f))

- Add proxy plugin support and enhance API handling
  ([`a482823`](https://github.com/touale/FrameX-kit/-/commit/a482823449b3b4431e1c0cc43f91d773f213f4ba))

- Add streaming support and optimize API registration
  ([`35a7c8a`](https://github.com/touale/FrameX-kit/-/commit/35a7c8a1e4e94abb7ab13668078a7c6bb92ddffd))

- Enhance logging, update config, and optimize plugin setup
  ([`9a27f06`](https://github.com/touale/FrameX-kit/-/commit/9a27f06d8bd8b8a593ebc830f1a7a54627793780))

### Performance Improvements

- Optimize BaseModel transfer for remote calls
  ([`57a9c5c`](https://github.com/touale/FrameX-kit/-/commit/57a9c5c7271a23961e1564494881607604151808))

### Refactoring

- Refactor plugin loading and API setup in framex
  ([`483c6e5`](https://github.com/touale/FrameX-kit/-/commit/483c6e5601f4c6f2c5846e7e55112d0e7a40e348))

### Testing

- Simplify CI/CD, update pre-commit, and configure ruff
  ([`348b3f8`](https://github.com/touale/FrameX-kit/-/commit/348b3f80f6e74494234eb4c05780606332e326d2))
