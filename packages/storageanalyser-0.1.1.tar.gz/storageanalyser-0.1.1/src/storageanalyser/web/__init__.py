"""Web frontend for storageanalyser."""
