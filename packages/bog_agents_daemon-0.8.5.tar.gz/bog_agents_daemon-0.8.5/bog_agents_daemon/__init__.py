"""Bog Agents Daemon — ambient agent service."""

__version__ = "0.8.5"
