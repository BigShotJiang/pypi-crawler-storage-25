#include "cadunpack/unfold/sheetmetal_unfolder.hpp"

#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <BRepBndLib.hxx>
#include <BRepGProp.hxx>
#include <BRepTools.hxx>
#include <BRepTools_WireExplorer.hxx>
#include <BRep_Tool.hxx>
#include <Geom_Curve.hxx>
#include <GProp_GProps.hxx>
#include <Precision.hxx>
#include <TopAbs.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopTools_IndexedDataMapOfShapeListOfShape.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
#include <TopTools_ListIteratorOfListOfShape.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Compound.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_Shape.hxx>
#include <TopoDS_Solid.hxx>
#include <TopoDS_Wire.hxx>
#include <gp_Ax1.hxx>
#include <gp_Ax3.hxx>
#include <gp_Circ.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Dir.hxx>
#include <gp_Pln.hxx>
#include <gp_Trsf.hxx>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstddef>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <map>
#include <optional>
#include <queue>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include <boost/geometry.hpp>
#include <boost/geometry/geometries/multi_polygon.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <boost/geometry/geometries/polygon.hpp>

namespace cadunpack::unfold {

namespace {

namespace bg = boost::geometry;

[[maybe_unused]] constexpr double kGeometryTolerance = 1e-4;
[[maybe_unused]] constexpr double kAngleTolerance = 1e-3;
constexpr double kThicknessTolerance = 0.2;
constexpr double kPairAreaTolerance = 0.15;
constexpr double kMinThickness = 0.1;
constexpr double kMaxThickness = 30.0;
constexpr double kUnionAreaTolerance = 1e-2;
[[maybe_unused]] constexpr double kSampleTolerance = 0.25;

struct Point2 {
  double x = 0.0;
  double y = 0.0;
};

struct FaceInfo {
  TopoDS_Face face;
  int face_index = 0;
  GeomAbs_SurfaceType surface_type = GeomAbs_OtherSurface;
  double area = 0.0;
  gp_Pnt centroid;
  gp_Pln plane;
  gp_Cylinder cylinder;
};

enum class PatchType {
  kPlane,
  kCylinder,
};

struct SeamRecord {
  int neighbor_patch_id = -1;
  gp_Pnt start;
  gp_Pnt end;
  Point2 local_start{};
  Point2 local_end{};
  std::vector<int> edge_ids;
};

struct OrientationProbe {
  Point2 local_point{};
  double desired_along_sign = 0.0;
};

struct Segment2 {
  Point2 start;
  Point2 end;
};

struct QuantizedPoint2 {
  long long x = 0;
  long long y = 0;

  auto tie() const {
    return std::tie(x, y);
  }

  bool operator<(const QuantizedPoint2& other) const {
    return tie() < other.tie();
  }
};

struct QuantizedSegmentKey {
  QuantizedPoint2 start;
  QuantizedPoint2 end;

  auto tie() const {
    return std::tie(start, end);
  }

  bool operator<(const QuantizedSegmentKey& other) const {
    return tie() < other.tie();
  }
};

struct QuantizedLineKey {
  long long dir_x = 0;
  long long dir_y = 0;
  long long offset = 0;

  auto tie() const {
    return std::tie(dir_x, dir_y, offset);
  }

  bool operator<(const QuantizedLineKey& other) const {
    return tie() < other.tie();
  }
};

struct SegmentBounds {
  bool valid = false;
  double min_x = 0.0;
  double max_x = 0.0;
  double min_y = 0.0;
  double max_y = 0.0;
};

using BgPoint = bg::model::d2::point_xy<double>;
using BgPolygon = bg::model::polygon<BgPoint>;
using BgMultiPolygon = bg::model::multi_polygon<BgPolygon>;

struct PatchTransform {
  bool resolved = false;
  Point2 translation{};
  double a = 1.0;
  double b = 0.0;
  double c = 0.0;
  double d = 1.0;
};

struct SheetPatch {
  int patch_id = 0;
  PatchType type = PatchType::kPlane;
  int face_a_index = 0;
  int face_b_index = 0;
  TopoDS_Face face_a;
  TopoDS_Face face_b;
  TopoDS_Face representative_face;
  double area = 0.0;
  double thickness = 0.0;
  gp_Pln mid_plane;
  gp_Cylinder mid_cylinder;
  gp_Pnt local_origin;
  gp_Dir local_u;
  gp_Dir local_v;
  gp_Pnt cylinder_axis_origin;
  gp_Dir cylinder_axis_dir;
  gp_Dir cylinder_radial_zero;
  double cylinder_radius = 0.0;
  Point2 local_centroid{};
  PatchTransform transform{};
  std::vector<SeamRecord> seams;
  std::set<int> seam_edge_ids;
};

struct PairCandidate {
  int left_index = 0;
  int right_index = 0;
  double score = 0.0;
};

struct ThicknessSample {
  double value = 0.0;
  double weight = 0.0;
};

std::string SanitizeName(std::string value) {
  std::replace_if(value.begin(), value.end(), [](char ch) {
    return !std::isalnum(static_cast<unsigned char>(ch)) && ch != '_' && ch != '-' && ch != '.';
  }, '_');
  while (!value.empty() && value.back() == '_') {
    value.pop_back();
  }
  return value.empty() ? "component" : value;
}

double Dot(const gp_Dir& left, const gp_Dir& right) {
  return left.X() * right.X() + left.Y() * right.Y() + left.Z() * right.Z();
}

double Dot(const gp_Vec& left, const gp_Vec& right) {
  return left.X() * right.X() + left.Y() * right.Y() + left.Z() * right.Z();
}

double Dot(const Point2& left, const Point2& right) {
  return left.x * right.x + left.y * right.y;
}

[[maybe_unused]] double Length(const gp_Vec& value) {
  return value.Magnitude();
}

double Length(const Point2& value) {
  return std::sqrt((value.x * value.x) + (value.y * value.y));
}

QuantizedPoint2 QuantizePoint(const Point2& point) {
  return QuantizedPoint2{
      .x = static_cast<long long>(std::llround(point.x * 100000.0)),
      .y = static_cast<long long>(std::llround(point.y * 100000.0)),
  };
}

QuantizedSegmentKey QuantizeSegment(const Segment2& segment) {
  QuantizedPoint2 start = QuantizePoint(segment.start);
  QuantizedPoint2 end = QuantizePoint(segment.end);
  if (end < start) {
    std::swap(start, end);
  }
  return QuantizedSegmentKey{
      .start = start,
      .end = end,
  };
}

QuantizedLineKey QuantizeLineKey(const Point2& direction, double offset) {
  return QuantizedLineKey{
      .dir_x = static_cast<long long>(std::llround(direction.x * 1000000.0)),
      .dir_y = static_cast<long long>(std::llround(direction.y * 1000000.0)),
      .offset = static_cast<long long>(std::llround(offset * 1000000.0)),
  };
}

Point2 operator+(const Point2& left, const Point2& right) {
  return Point2{left.x + right.x, left.y + right.y};
}

Point2 operator-(const Point2& left, const Point2& right) {
  return Point2{left.x - right.x, left.y - right.y};
}

Point2 operator*(const Point2& point, double scalar) {
  return Point2{point.x * scalar, point.y * scalar};
}

Point2 Normalize(const Point2& point) {
  const double magnitude = Length(point);
  if (magnitude <= 1e-9) {
    return Point2{1.0, 0.0};
  }
  return Point2{point.x / magnitude, point.y / magnitude};
}

[[maybe_unused]] Point2 Perpendicular(const Point2& point) {
  return Point2{-point.y, point.x};
}

double Cross2(const Point2& left, const Point2& right) {
  return (left.x * right.y) - (left.y * right.x);
}

Point2 Midpoint(const Point2& left, const Point2& right) {
  return Point2{(left.x + right.x) / 2.0, (left.y + right.y) / 2.0};
}

gp_Pnt Midpoint(const gp_Pnt& left, const gp_Pnt& right) {
  return gp_Pnt((left.X() + right.X()) / 2.0, (left.Y() + right.Y()) / 2.0, (left.Z() + right.Z()) / 2.0);
}

[[maybe_unused]] double Distance(const gp_Pnt& left, const gp_Pnt& right) {
  return left.Distance(right);
}

Point2 Apply(const PatchTransform& transform, const Point2& value) {
  return Point2{
      transform.translation.x + (transform.a * value.x) + (transform.b * value.y),
      transform.translation.y + (transform.c * value.x) + (transform.d * value.y),
  };
}

double SignedLineSide(const Point2& line_start, const Point2& line_end, const Point2& point) {
  return Cross2(line_end - line_start, point - line_start);
}

[[maybe_unused]] Point2 ReflectAcrossLine(const Point2& point, const Point2& line_start, const Point2& line_end) {
  const Point2 direction = Normalize(line_end - line_start);
  const Point2 relative = point - line_start;
  const double along = Dot(relative, direction);
  const Point2 projection = line_start + (direction * along);
  return Point2{(projection.x * 2.0) - point.x, (projection.y * 2.0) - point.y};
}

PatchTransform ReflectionTransform(const Point2& line_start, const Point2& line_end) {
  const Point2 direction = Normalize(line_end - line_start);
  const double ux = direction.x;
  const double uy = direction.y;
  PatchTransform result;
  result.a = (2.0 * ux * ux) - 1.0;
  result.b = 2.0 * ux * uy;
  result.c = 2.0 * ux * uy;
  result.d = (2.0 * uy * uy) - 1.0;
  const Point2 mapped_start = Apply(result, line_start);
  result.translation = line_start - mapped_start;
  result.resolved = true;
  return result;
}

PatchTransform Compose(const PatchTransform& outer, const PatchTransform& inner) {
  PatchTransform result;
  result.a = (outer.a * inner.a) + (outer.b * inner.c);
  result.b = (outer.a * inner.b) + (outer.b * inner.d);
  result.c = (outer.c * inner.a) + (outer.d * inner.c);
  result.d = (outer.c * inner.b) + (outer.d * inner.d);
  result.translation = Apply(outer, inner.translation);
  result.resolved = true;
  return result;
}

std::pair<gp_Pnt, gp_Pnt> EdgeEndpoints(const TopoDS_Edge& edge) {
  Standard_Real first_parameter = 0.0;
  Standard_Real last_parameter = 0.0;
  Handle(Geom_Curve) curve = BRep_Tool::Curve(edge, first_parameter, last_parameter);
  if (curve.IsNull()) {
    return {gp_Pnt(), gp_Pnt()};
  }
  return {curve->Value(first_parameter), curve->Value(last_parameter)};
}

[[maybe_unused]] double EdgeLength(const TopoDS_Edge& edge) {
  const auto [first, last] = EdgeEndpoints(edge);
  return first.Distance(last);
}

[[maybe_unused]] gp_Vec PlaneNormalVector(const gp_Pln& plane) {
  const gp_Dir direction = plane.Axis().Direction();
  return gp_Vec(direction);
}

[[maybe_unused]] Point2 ToPoint2(const gp_Pnt& point) {
  return Point2{point.X(), point.Y()};
}

FaceInfo BuildFaceInfo(const TopoDS_Face& face, int face_index) {
  BRepAdaptor_Surface adaptor(face, Standard_True);
  GProp_GProps properties;
  BRepGProp::SurfaceProperties(face, properties);

  FaceInfo info;
  info.face = face;
  info.face_index = face_index;
  info.surface_type = adaptor.GetType();
  info.area = properties.Mass();
  info.centroid = properties.CentreOfMass();
  if (info.surface_type == GeomAbs_Plane) {
    info.plane = adaptor.Plane();
  } else if (info.surface_type == GeomAbs_Cylinder) {
    info.cylinder = adaptor.Cylinder();
  }
  return info;
}

double PlaneDistance(const FaceInfo& left, const FaceInfo& right) {
  const gp_Dir normal = left.plane.Axis().Direction();
  const gp_Vec delta(left.plane.Location(), right.plane.Location());
  return std::abs(Dot(delta, gp_Vec(normal)));
}

double AxisDistance(const gp_Ax1& left, const gp_Ax1& right) {
  const gp_Vec left_to_right(left.Location(), right.Location());
  const gp_Vec axis_cross = gp_Vec(left.Direction()).Crossed(gp_Vec(right.Direction()));
  if (axis_cross.Magnitude() <= 1e-6) {
    const gp_Vec perpendicular = left_to_right.Crossed(gp_Vec(left.Direction()));
    return perpendicular.Magnitude();
  }
  return std::abs(Dot(left_to_right, axis_cross)) / axis_cross.Magnitude();
}

std::vector<gp_Pnt> SampleEdgePoints(const TopoDS_Edge& edge);

std::pair<double, double> FaceAxisRange(const TopoDS_Face& face, const gp_Ax1& axis) {
  const gp_Vec axis_direction(axis.Direction());
  bool initialized = false;
  double min_value = 0.0;
  double max_value = 0.0;

  for (TopExp_Explorer explorer(face, TopAbs_EDGE); explorer.More(); explorer.Next()) {
    const TopoDS_Edge edge = TopoDS::Edge(explorer.Current());
    for (const auto& point : SampleEdgePoints(edge)) {
      const double projection = Dot(gp_Vec(axis.Location(), point), axis_direction);
      if (!initialized) {
        min_value = projection;
        max_value = projection;
        initialized = true;
      } else {
        min_value = std::min(min_value, projection);
        max_value = std::max(max_value, projection);
      }
    }
  }

  if (!initialized) {
    return {0.0, 0.0};
  }
  return {min_value, max_value};
}

Point2 MapToLocal(const SheetPatch& patch, const gp_Pnt& point);

SheetPatch MakePlanePatch(
    int patch_id,
    const FaceInfo& left,
    const FaceInfo& right,
    double thickness) {
  SheetPatch patch;
  patch.patch_id = patch_id;
  patch.type = PatchType::kPlane;
  patch.face_a_index = left.face_index;
  patch.face_b_index = right.face_index;
  patch.face_a = left.face;
  patch.face_b = right.face;
  patch.representative_face = left.face;
  patch.area = std::max(left.area, right.area);
  patch.thickness = thickness;

  const gp_Dir plane_normal = left.plane.Axis().Direction();
  const gp_Vec midpoint_delta(left.plane.Location(), right.plane.Location());
  const double signed_distance = Dot(midpoint_delta, gp_Vec(plane_normal));
  const gp_Pnt mid_location = left.plane.Location().Translated(gp_Vec(plane_normal) * (signed_distance / 2.0));
  patch.mid_plane = gp_Pln(mid_location, plane_normal);
  patch.local_origin = patch.mid_plane.Location();
  patch.local_u = patch.mid_plane.Position().XDirection();
  patch.local_v = patch.mid_plane.Position().YDirection();
  return patch;
}

std::optional<double> DetectThickness(const std::vector<FaceInfo>& faces) {
  auto dominant_cluster = [](std::vector<ThicknessSample> samples) -> std::optional<std::pair<double, double>> {
    if (samples.empty()) {
      return std::nullopt;
    }

    std::sort(samples.begin(), samples.end(), [](const ThicknessSample& left, const ThicknessSample& right) {
      return left.value < right.value;
    });
    std::size_t best_start = 0;
    std::size_t best_end = 0;
    double best_weight = 0.0;
    std::size_t current_start = 0;
    double current_weight = samples.front().weight;
    for (std::size_t index = 1; index <= samples.size(); ++index) {
      if (index == samples.size() || std::abs(samples[index].value - samples[index - 1].value) > kThicknessTolerance) {
        if (current_weight > best_weight) {
          best_start = current_start;
          best_end = index;
          best_weight = current_weight;
        }
        current_start = index;
        if (index < samples.size()) {
          current_weight = samples[index].weight;
        }
      } else {
        current_weight += samples[index].weight;
      }
    }

    double weighted_sum = 0.0;
    double weight_sum = 0.0;
    for (std::size_t index = best_start; index < best_end; ++index) {
      weighted_sum += samples[index].value * samples[index].weight;
      weight_sum += samples[index].weight;
    }
    if (weight_sum <= 1e-9) {
      return std::nullopt;
    }
    return std::pair<double, double>{weighted_sum / weight_sum, weight_sum};
  };

  std::vector<ThicknessSample> plane_candidates;
  std::vector<ThicknessSample> cylinder_candidates;
  plane_candidates.reserve(faces.size() * 2);
  cylinder_candidates.reserve(faces.size());

  for (std::size_t i = 0; i < faces.size(); ++i) {
    for (std::size_t j = i + 1; j < faces.size(); ++j) {
      if (faces[i].surface_type == GeomAbs_Plane && faces[j].surface_type == GeomAbs_Plane) {
        const double parallel = std::abs(Dot(faces[i].plane.Axis().Direction(), faces[j].plane.Axis().Direction()));
        if (parallel < 0.999) {
          continue;
        }
        const double area_ratio = std::abs(faces[i].area - faces[j].area) / std::max(faces[i].area, faces[j].area);
        if (area_ratio > 0.1) {
          continue;
        }
        const double distance = PlaneDistance(faces[i], faces[j]);
        if (distance >= kMinThickness && distance <= kMaxThickness) {
          plane_candidates.push_back(ThicknessSample{
              .value = distance,
              .weight = std::max(faces[i].area, faces[j].area),
          });
        }
      }
      if (faces[i].surface_type == GeomAbs_Cylinder && faces[j].surface_type == GeomAbs_Cylinder) {
        const gp_Ax1 axis_i = faces[i].cylinder.Axis();
        const gp_Ax1 axis_j = faces[j].cylinder.Axis();
        const double axis_parallel = std::abs(Dot(axis_i.Direction(), axis_j.Direction()));
        if (axis_parallel < 0.999) {
          continue;
        }
        const double axis_distance = AxisDistance(axis_i, axis_j);
        if (axis_distance > 0.25) {
          continue;
        }
        const double radius_delta = std::abs(faces[i].cylinder.Radius() - faces[j].cylinder.Radius());
        if (radius_delta >= kMinThickness && radius_delta <= kMaxThickness) {
          cylinder_candidates.push_back(ThicknessSample{
              .value = radius_delta,
              .weight = std::max(faces[i].area, faces[j].area),
          });
        }
      }
    }
  }

  const auto plane_cluster = dominant_cluster(plane_candidates);
  const auto cylinder_cluster = dominant_cluster(cylinder_candidates);

  if (cylinder_cluster.has_value()) {
    return cylinder_cluster->first;
  }
  if (plane_cluster.has_value()) {
    return plane_cluster->first;
  }
  return std::nullopt;
}

std::vector<PairCandidate> BuildPlaneCandidates(const std::vector<FaceInfo>& faces, double thickness) {
  std::vector<PairCandidate> candidates;
  for (std::size_t i = 0; i < faces.size(); ++i) {
    if (faces[i].surface_type != GeomAbs_Plane) {
      continue;
    }
    for (std::size_t j = i + 1; j < faces.size(); ++j) {
      if (faces[j].surface_type != GeomAbs_Plane) {
        continue;
      }
      const double parallel = std::abs(Dot(faces[i].plane.Axis().Direction(), faces[j].plane.Axis().Direction()));
      if (parallel < 0.999) {
        continue;
      }
      const double distance = PlaneDistance(faces[i], faces[j]);
      if (std::abs(distance - thickness) > kThicknessTolerance) {
        continue;
      }
      const double area_ratio = std::abs(faces[i].area - faces[j].area) / std::max(faces[i].area, faces[j].area);
      if (area_ratio > kPairAreaTolerance) {
        continue;
      }
      const gp_Vec centroid_delta(faces[i].centroid, faces[j].centroid);
      const gp_Dir normal = faces[i].plane.Axis().Direction();
      const gp_Vec in_plane = centroid_delta - (gp_Vec(normal) * Dot(centroid_delta, gp_Vec(normal)));
      candidates.push_back(PairCandidate{
          .left_index = static_cast<int>(i),
          .right_index = static_cast<int>(j),
          .score = std::abs(distance - thickness) + area_ratio + in_plane.Magnitude(),
      });
    }
  }
  std::sort(candidates.begin(), candidates.end(), [](const PairCandidate& left, const PairCandidate& right) {
    return left.score < right.score;
  });
  return candidates;
}

struct DominantPlanarPair {
  int left_index = 0;
  int right_index = 0;
  double thickness = 0.0;
};

std::optional<DominantPlanarPair> FindDominantPlanarSkinPair(const std::vector<FaceInfo>& faces) {
  std::optional<DominantPlanarPair> best;
  double best_area = -1.0;
  double best_score = std::numeric_limits<double>::max();

  for (std::size_t i = 0; i < faces.size(); ++i) {
    if (faces[i].surface_type != GeomAbs_Plane) {
      continue;
    }
    for (std::size_t j = i + 1; j < faces.size(); ++j) {
      if (faces[j].surface_type != GeomAbs_Plane) {
        continue;
      }
      const double parallel = std::abs(Dot(faces[i].plane.Axis().Direction(), faces[j].plane.Axis().Direction()));
      if (parallel < 0.999) {
        continue;
      }
      const double distance = PlaneDistance(faces[i], faces[j]);
      if (distance < kMinThickness || distance > kMaxThickness) {
        continue;
      }
      const double area_ratio = std::abs(faces[i].area - faces[j].area) / std::max(faces[i].area, faces[j].area);
      if (area_ratio > 0.15) {
        continue;
      }
      const gp_Vec centroid_delta(faces[i].centroid, faces[j].centroid);
      const gp_Dir normal = faces[i].plane.Axis().Direction();
      const gp_Vec in_plane = centroid_delta - (gp_Vec(normal) * Dot(centroid_delta, gp_Vec(normal)));
      const double area = std::max(faces[i].area, faces[j].area);
      const double score = in_plane.Magnitude() + std::abs(area_ratio);
      if (!best.has_value() || area > best_area || (std::abs(area - best_area) <= 1e-6 && score < best_score)) {
        best = DominantPlanarPair{
            .left_index = static_cast<int>(i),
            .right_index = static_cast<int>(j),
            .thickness = distance,
        };
        best_area = area;
        best_score = score;
      }
    }
  }

  return best;
}

[[maybe_unused]] std::optional<SheetPatch> BuildDominantFlatPatch(const std::vector<FaceInfo>& faces) {
  const auto dominant_pair = FindDominantPlanarSkinPair(faces);
  if (!dominant_pair.has_value()) {
    return std::nullopt;
  }
  return MakePlanePatch(
      1,
      faces[dominant_pair->left_index],
      faces[dominant_pair->right_index],
      dominant_pair->thickness);
}

std::vector<PairCandidate> BuildCylinderCandidates(const std::vector<FaceInfo>& faces, double thickness) {
  std::vector<PairCandidate> candidates;
  for (std::size_t i = 0; i < faces.size(); ++i) {
    if (faces[i].surface_type != GeomAbs_Cylinder) {
      continue;
    }
    for (std::size_t j = i + 1; j < faces.size(); ++j) {
      if (faces[j].surface_type != GeomAbs_Cylinder) {
        continue;
      }
      const gp_Ax1 axis_i = faces[i].cylinder.Axis();
      const gp_Ax1 axis_j = faces[j].cylinder.Axis();
      const double axis_parallel = std::abs(Dot(axis_i.Direction(), axis_j.Direction()));
      if (axis_parallel < 0.999) {
        continue;
      }
      const double axis_distance = AxisDistance(axis_i, axis_j);
      if (axis_distance > 0.25) {
        continue;
      }

      const auto [min_i, max_i] = FaceAxisRange(faces[i].face, axis_i);
      const auto [min_j, max_j] = FaceAxisRange(faces[j].face, axis_i);
      const double span_i = std::max(0.0, max_i - min_i);
      const double span_j = std::max(0.0, max_j - min_j);
      const double overlap = std::max(0.0, std::min(max_i, max_j) - std::max(min_i, min_j));
      const double min_span = std::max(1e-6, std::min(span_i, span_j));
      const double overlap_ratio = overlap / min_span;
      if (overlap_ratio < 0.6) {
        continue;
      }

      const double radius_delta = std::abs(faces[i].cylinder.Radius() - faces[j].cylinder.Radius());
      if (std::abs(radius_delta - thickness) > kThicknessTolerance) {
        continue;
      }
      const double developed_left = faces[i].area / std::max(faces[i].cylinder.Radius(), 1e-6);
      const double developed_right = faces[j].area / std::max(faces[j].cylinder.Radius(), 1e-6);
      const double developed_delta = std::abs(developed_left - developed_right);
      const double interval_center_delta =
          std::abs(((min_i + max_i) / 2.0) - ((min_j + max_j) / 2.0));
      candidates.push_back(PairCandidate{
          .left_index = static_cast<int>(i),
          .right_index = static_cast<int>(j),
          .score = axis_distance + std::abs(radius_delta - thickness) + developed_delta + interval_center_delta,
      });
    }
  }
  std::sort(candidates.begin(), candidates.end(), [](const PairCandidate& left, const PairCandidate& right) {
    return left.score < right.score;
  });
  return candidates;
}

std::vector<SheetPatch> BuildPatches(const std::vector<FaceInfo>& faces, double thickness) {
  std::vector<SheetPatch> patches;
  std::vector<bool> used(faces.size(), false);
  int next_patch_id = 1;

  for (const auto& candidate : BuildPlaneCandidates(faces, thickness)) {
    if (used[candidate.left_index] || used[candidate.right_index]) {
      continue;
    }

    const FaceInfo& left = faces[candidate.left_index];
    const FaceInfo& right = faces[candidate.right_index];

    SheetPatch patch;
    patch.patch_id = next_patch_id++;
    patch.type = PatchType::kPlane;
    patch.face_a_index = left.face_index;
    patch.face_b_index = right.face_index;
    patch.face_a = left.face;
    patch.face_b = right.face;
    patch.representative_face = left.face;
    patch.area = std::max(left.area, right.area);
    patch.thickness = thickness;

    const gp_Dir plane_normal = left.plane.Axis().Direction();
    const gp_Vec midpoint_delta(left.plane.Location(), right.plane.Location());
    const double signed_distance = Dot(midpoint_delta, gp_Vec(plane_normal));
    gp_Pnt mid_location = left.plane.Location().Translated(gp_Vec(plane_normal) * (signed_distance / 2.0));
    patch.mid_plane = gp_Pln(mid_location, plane_normal);
    patch.local_origin = patch.mid_plane.Location();
    patch.local_u = patch.mid_plane.Position().XDirection();
    patch.local_v = patch.mid_plane.Position().YDirection();
    used[candidate.left_index] = true;
    used[candidate.right_index] = true;
    patches.push_back(patch);
  }

  for (const auto& candidate : BuildCylinderCandidates(faces, thickness)) {
    if (used[candidate.left_index] || used[candidate.right_index]) {
      continue;
    }

    const FaceInfo& left = faces[candidate.left_index];
    const FaceInfo& right = faces[candidate.right_index];
    const FaceInfo& outer = left.cylinder.Radius() >= right.cylinder.Radius() ? left : right;
    const FaceInfo& inner = left.cylinder.Radius() >= right.cylinder.Radius() ? right : left;

    SheetPatch patch;
    patch.patch_id = next_patch_id++;
    patch.type = PatchType::kCylinder;
    patch.face_a_index = outer.face_index;
    patch.face_b_index = inner.face_index;
    patch.face_a = outer.face;
    patch.face_b = inner.face;
    patch.representative_face = outer.face;
    patch.area = std::max(left.area, right.area);
    patch.thickness = thickness;

    gp_Cylinder mid = outer.cylinder;
    mid.SetRadius((outer.cylinder.Radius() + inner.cylinder.Radius()) / 2.0);
    patch.mid_cylinder = mid;
    patch.cylinder_axis_origin = mid.Location();
    patch.cylinder_axis_dir = mid.Axis().Direction();
    patch.cylinder_radial_zero = mid.Position().XDirection();
    patch.cylinder_radius = mid.Radius();
    used[candidate.left_index] = true;
    used[candidate.right_index] = true;
    patches.push_back(patch);
  }

  return patches;
}

std::vector<gp_Pnt> SampleEdgePoints(const TopoDS_Edge& edge) {
  BRepAdaptor_Curve curve(edge);
  const Standard_Real first = curve.FirstParameter();
  const Standard_Real last = curve.LastParameter();
  if (std::abs(last - first) <= Precision::Confusion()) {
    const auto [start, finish] = EdgeEndpoints(edge);
    return {start, finish};
  }

  int sample_count = 0;
  switch (curve.GetType()) {
    case GeomAbs_Line:
      sample_count = 2;
      break;
    case GeomAbs_Circle: {
      const double radius = curve.Circle().Radius();
      const double angle = std::abs(last - first);
      sample_count = std::max(16, static_cast<int>(std::ceil((radius * angle) / 2.0)));
      break;
    }
    case GeomAbs_Ellipse:
      sample_count = 48;
      break;
    case GeomAbs_BSplineCurve:
    case GeomAbs_BezierCurve:
      sample_count = 64;
      break;
    default:
      sample_count = 24;
      break;
  }

  std::vector<gp_Pnt> points;
  points.reserve(sample_count);
  for (int index = 0; index < sample_count; ++index) {
    const double ratio = sample_count == 1 ? 0.0 : static_cast<double>(index) / static_cast<double>(sample_count - 1);
    const double parameter = first + ((last - first) * ratio);
    points.push_back(curve.Value(parameter));
  }
  return points;
}

std::optional<Point2> ExtremeLocalPointFromSeam(
    const SheetPatch& patch,
    const Point2& local_seam_start,
    const Point2& local_seam_end) {
  bool found = false;
  double best_distance = 0.0;
  Point2 best_point{};
  for (TopExp_Explorer explorer(patch.representative_face, TopAbs_EDGE); explorer.More(); explorer.Next()) {
    const TopoDS_Edge edge = TopoDS::Edge(explorer.Current());
    for (const auto& point : SampleEdgePoints(edge)) {
      const Point2 local_point = MapToLocal(patch, point);
      const double side = SignedLineSide(local_seam_start, local_seam_end, local_point);
      const double distance = std::abs(side);
      if (!found || distance > best_distance) {
        best_distance = distance;
        best_point = local_point;
        found = true;
      }
    }
  }
  if (!found) {
    return std::nullopt;
  }
  return best_point;
}

gp_Pnt MapPointToMedian(const SheetPatch& patch, const gp_Pnt& point) {
  if (patch.type == PatchType::kPlane) {
    const gp_Dir normal = patch.mid_plane.Axis().Direction();
    const gp_Vec offset(patch.mid_plane.Location(), point);
    const double distance = Dot(offset, gp_Vec(normal));
    return point.Translated(gp_Vec(normal) * (-distance));
  }

  const gp_Ax1 axis = patch.mid_cylinder.Axis();
  const gp_Vec axis_origin_to_point(axis.Location(), point);
  const double axial = Dot(axis_origin_to_point, gp_Vec(axis.Direction()));
  const gp_Pnt axial_point = axis.Location().Translated(gp_Vec(axis.Direction()) * axial);
  gp_Vec radial(axial_point, point);
  if (radial.Magnitude() <= Precision::Confusion()) {
    radial = gp_Vec(patch.cylinder_radial_zero);
  }
  radial.Normalize();
  return axial_point.Translated(radial * patch.cylinder_radius);
}

Point2 MapToLocal(const SheetPatch& patch, const gp_Pnt& point) {
  const gp_Pnt median_point = MapPointToMedian(patch, point);
  if (patch.type == PatchType::kPlane) {
    const gp_Vec delta(patch.local_origin, median_point);
    return Point2{
        Dot(delta, gp_Vec(patch.local_u)),
        Dot(delta, gp_Vec(patch.local_v)),
    };
  }

  const gp_Ax1 axis = patch.mid_cylinder.Axis();
  const gp_Vec axis_delta(axis.Location(), median_point);
  const double axial = Dot(axis_delta, gp_Vec(axis.Direction()));
  const gp_Pnt axis_point = axis.Location().Translated(gp_Vec(axis.Direction()) * axial);
  gp_Vec radial(axis_point, median_point);
  if (radial.Magnitude() <= Precision::Confusion()) {
    radial = gp_Vec(patch.cylinder_radial_zero);
  }
  radial.Normalize();
  const gp_Vec reference(patch.cylinder_radial_zero);
  double angle = std::atan2(Dot(gp_Vec(axis.Direction()), reference.Crossed(radial)), Dot(reference, radial));
  return Point2{axial, patch.cylinder_radius * angle};
}

Point2 SeamLocalStartForPatch(const SheetPatch& patch, const SeamRecord& seam) {
  return patch.type == PatchType::kCylinder ? seam.local_start : MapToLocal(patch, seam.start);
}

Point2 SeamLocalEndForPatch(const SheetPatch& patch, const SeamRecord& seam) {
  return patch.type == PatchType::kCylinder ? seam.local_end : MapToLocal(patch, seam.end);
}

[[maybe_unused]] Point2 CentroidOfLocalPoints(const std::vector<Point2>& points) {
  if (points.empty()) {
    return Point2{};
  }
  Point2 result{};
  for (const auto& point : points) {
    result.x += point.x;
    result.y += point.y;
  }
  result.x /= static_cast<double>(points.size());
  result.y /= static_cast<double>(points.size());
  return result;
}

struct SeamSelection {
  TopoDS_Edge primary;
  std::optional<TopoDS_Edge> secondary;
  int primary_edge_id = 0;
  std::optional<int> secondary_edge_id;
};

std::pair<gp_Pnt, gp_Pnt> AverageSeamEndpoints(const TopoDS_Edge& first, const TopoDS_Edge& second);
std::pair<Point2, Point2> LocalSeamEndpoints(const SheetPatch& patch, const SeamSelection& selection);
std::vector<BgPolygon> BuildPatchPolygons(const SheetPatch& patch);

std::optional<SeamSelection> SelectSeamPair(
    const std::vector<std::pair<TopoDS_Edge, int>>& edges,
    double expected_separation,
    std::optional<gp_Dir> expected_direction = std::nullopt) {
  if (edges.empty()) {
    return std::nullopt;
  }

  if (edges.size() == 1) {
    BRepAdaptor_Curve curve(edges.front().first);
    if (curve.GetType() != GeomAbs_Line) {
      return std::nullopt;
    }
    if (expected_direction.has_value()) {
      auto [start, end] = EdgeEndpoints(edges.front().first);
      gp_Vec seam_direction(start, end);
      if (seam_direction.Magnitude() > Precision::Confusion()) {
        seam_direction.Normalize();
        if (std::abs(Dot(seam_direction, gp_Vec(*expected_direction))) < 0.995) {
          return std::nullopt;
        }
      }
    }
    return SeamSelection{
        .primary = edges.front().first,
        .secondary = std::nullopt,
        .primary_edge_id = edges.front().second,
        .secondary_edge_id = std::nullopt,
    };
  }

  auto edge_length = [](const gp_Pnt& start, const gp_Pnt& end) {
    return start.Distance(end);
  };
  auto projected_overlap = [](const gp_Pnt& a_start,
                              const gp_Pnt& a_end,
                              const gp_Pnt& b_start,
                              const gp_Pnt& b_end,
                              const gp_Vec& direction) {
    const gp_XYZ origin = a_start.XYZ();
    const gp_XYZ dir = direction.XYZ();
    const double a0 = (a_start.XYZ() - origin) * dir;
    const double a1 = (a_end.XYZ() - origin) * dir;
    const double b0 = (b_start.XYZ() - origin) * dir;
    const double b1 = (b_end.XYZ() - origin) * dir;
    const double a_min = std::min(a0, a1);
    const double a_max = std::max(a0, a1);
    const double b_min = std::min(b0, b1);
    const double b_max = std::max(b0, b1);
    return std::max(0.0, std::min(a_max, b_max) - std::max(a_min, b_min));
  };

  double best_score = std::numeric_limits<double>::max();
  double best_overlap_ratio = -1.0;
  double best_min_length = -1.0;
  std::optional<SeamSelection> best;
  for (std::size_t i = 0; i < edges.size(); ++i) {
    for (std::size_t j = i + 1; j < edges.size(); ++j) {
      BRepAdaptor_Curve curve_i(edges[i].first);
      BRepAdaptor_Curve curve_j(edges[j].first);
      if (curve_i.GetType() != GeomAbs_Line || curve_j.GetType() != GeomAbs_Line) {
        continue;
      }
      const auto [i_start, i_end] = EdgeEndpoints(edges[i].first);
      const auto [j_start, j_end] = EdgeEndpoints(edges[j].first);
      gp_Vec direction_i(i_start, i_end);
      gp_Vec direction_j(j_start, j_end);
      if (direction_i.Magnitude() <= Precision::Confusion() || direction_j.Magnitude() <= Precision::Confusion()) {
        continue;
      }
      direction_i.Normalize();
      direction_j.Normalize();
      const double parallel = std::abs(Dot(direction_i, direction_j));
      if (parallel < 0.999) {
        continue;
      }
      const double length_i = edge_length(i_start, i_end);
      const double length_j = edge_length(j_start, j_end);
      const double min_length = std::max(1e-6, std::min(length_i, length_j));
      const double overlap = projected_overlap(i_start, i_end, j_start, j_end, direction_i);
      const double overlap_ratio = overlap / min_length;
      if (overlap_ratio < 0.6) {
        continue;
      }
      if (expected_direction.has_value()) {
        const auto [median_start, median_end] = AverageSeamEndpoints(edges[i].first, edges[j].first);
        gp_Vec seam_direction(median_start, median_end);
        if (seam_direction.Magnitude() > Precision::Confusion()) {
          seam_direction.Normalize();
          if (std::abs(Dot(seam_direction, gp_Vec(*expected_direction))) < 0.995) {
            continue;
          }
        }
      }
      const gp_Pnt midpoint_i = Midpoint(i_start, i_end);
      const gp_Pnt midpoint_j = Midpoint(j_start, j_end);
      const double separation = midpoint_i.Distance(midpoint_j);
      const double score = std::abs(separation - expected_separation);
      if (overlap_ratio > best_overlap_ratio + 1e-6 ||
          (std::abs(overlap_ratio - best_overlap_ratio) <= 1e-6 && min_length > best_min_length + 1e-6) ||
          (std::abs(overlap_ratio - best_overlap_ratio) <= 1e-6 && std::abs(min_length - best_min_length) <= 1e-6 &&
           score < best_score)) {
        best_overlap_ratio = overlap_ratio;
        best_min_length = min_length;
        best_score = score;
        best = SeamSelection{
            .primary = edges[i].first,
            .secondary = edges[j].first,
            .primary_edge_id = edges[i].second,
            .secondary_edge_id = edges[j].second,
        };
      }
    }
  }
  return best;
}

std::pair<gp_Pnt, gp_Pnt> AverageSeamEndpoints(const TopoDS_Edge& first, const TopoDS_Edge& second) {
  auto [first_start, first_end] = EdgeEndpoints(first);
  auto [second_start, second_end] = EdgeEndpoints(second);

  gp_Vec dominant_direction(first_start, first_end);
  if (dominant_direction.Magnitude() <= Precision::Confusion()) {
    dominant_direction = gp_Vec(second_start, second_end);
  }
  if (dominant_direction.Magnitude() <= Precision::Confusion()) {
    return {Midpoint(first_start, second_start), Midpoint(first_end, second_end)};
  }
  dominant_direction.Normalize();

  auto orient_along_dominant = [&](gp_Pnt& start, gp_Pnt& end) {
    gp_Vec edge_direction(start, end);
    if (edge_direction.Magnitude() <= Precision::Confusion()) {
      return;
    }
    edge_direction.Normalize();
    if (Dot(edge_direction, dominant_direction) < 0.0) {
      std::swap(start, end);
      edge_direction.Reverse();
    }

    const gp_Pnt origin = first_start;
    const double start_projection = Dot(gp_Vec(origin, start), dominant_direction);
    const double end_projection = Dot(gp_Vec(origin, end), dominant_direction);
    if (start_projection > end_projection) {
      std::swap(start, end);
    }
  };

  orient_along_dominant(first_start, first_end);
  orient_along_dominant(second_start, second_end);

  const double direct = first_start.Distance(second_start) + first_end.Distance(second_end);
  const double flipped = first_start.Distance(second_end) + first_end.Distance(second_start);
  if (flipped + 1e-6 < direct) {
    std::swap(second_start, second_end);
  }
  return {Midpoint(first_start, second_start), Midpoint(first_end, second_end)};
}

std::pair<gp_Pnt, gp_Pnt> BuildMedianSeamEndpoints(
    const SheetPatch& left,
    const SheetPatch& right,
    const SeamSelection& selection) {
  if (selection.secondary.has_value()) {
    return AverageSeamEndpoints(selection.primary, *selection.secondary);
  }

  auto [start, end] = EdgeEndpoints(selection.primary);
  const gp_Pnt left_start = MapPointToMedian(left, start);
  const gp_Pnt left_end = MapPointToMedian(left, end);
  const gp_Pnt right_start = MapPointToMedian(right, start);
  const gp_Pnt right_end = MapPointToMedian(right, end);
  return {Midpoint(left_start, right_start), Midpoint(left_end, right_end)};
}

std::pair<Point2, Point2> AverageLocalSeamEndpoints(
    const SheetPatch& patch,
    const TopoDS_Edge& first,
    const TopoDS_Edge& second) {
  auto [first_start_3d, first_end_3d] = EdgeEndpoints(first);
  auto [second_start_3d, second_end_3d] = EdgeEndpoints(second);

  Point2 first_start = MapToLocal(patch, first_start_3d);
  Point2 first_end = MapToLocal(patch, first_end_3d);
  Point2 second_start = MapToLocal(patch, second_start_3d);
  Point2 second_end = MapToLocal(patch, second_end_3d);

  Point2 dominant_direction = first_end - first_start;
  if (Length(dominant_direction) <= 1e-9) {
    dominant_direction = second_end - second_start;
  }
  if (Length(dominant_direction) <= 1e-9) {
    return {Midpoint(first_start, second_start), Midpoint(first_end, second_end)};
  }
  dominant_direction = Normalize(dominant_direction);

  auto orient_along_dominant = [&](Point2& start, Point2& end) {
    Point2 edge_direction = end - start;
    if (Length(edge_direction) <= 1e-9) {
      return;
    }
    edge_direction = Normalize(edge_direction);
    if (Dot(edge_direction, dominant_direction) < 0.0) {
      std::swap(start, end);
    }
    const double start_projection = Dot(start, dominant_direction);
    const double end_projection = Dot(end, dominant_direction);
    if (start_projection > end_projection) {
      std::swap(start, end);
    }
  };

  orient_along_dominant(first_start, first_end);
  orient_along_dominant(second_start, second_end);

  const double direct = Length(first_start - second_start) + Length(first_end - second_end);
  const double flipped = Length(first_start - second_end) + Length(first_end - second_start);
  if (flipped + 1e-6 < direct) {
    std::swap(second_start, second_end);
  }

  return {Midpoint(first_start, second_start), Midpoint(first_end, second_end)};
}

std::pair<Point2, Point2> LocalSeamEndpoints(const SheetPatch& patch, const SeamSelection& selection) {
  if (selection.secondary.has_value()) {
    return AverageLocalSeamEndpoints(patch, selection.primary, *selection.secondary);
  }
  auto [start, end] = EdgeEndpoints(selection.primary);
  return {MapToLocal(patch, start), MapToLocal(patch, end)};
}

std::map<int, int> BuildFacePatchMap(const std::vector<SheetPatch>& patches) {
  std::map<int, int> mapping;
  for (const auto& patch : patches) {
    mapping.emplace(patch.face_a_index, patch.patch_id);
    mapping.emplace(patch.face_b_index, patch.patch_id);
  }
  return mapping;
}

void PopulateSeams(
    const TopoDS_Shape& component,
    std::vector<SheetPatch>& patches,
    double thickness) {
  std::map<int, std::size_t> patch_index_by_id;
  for (std::size_t index = 0; index < patches.size(); ++index) {
    patch_index_by_id.emplace(patches[index].patch_id, index);
  }

  TopTools_IndexedMapOfShape face_map;
  TopExp::MapShapes(component, TopAbs_FACE, face_map);
  TopTools_IndexedMapOfShape edge_map;
  TopExp::MapShapes(component, TopAbs_EDGE, edge_map);
  TopTools_IndexedDataMapOfShapeListOfShape edge_faces;
  TopExp::MapShapesAndAncestors(component, TopAbs_EDGE, TopAbs_FACE, edge_faces);
  const std::map<int, int> face_to_patch = BuildFacePatchMap(patches);

  std::map<std::pair<int, int>, std::vector<std::pair<TopoDS_Edge, int>>> shared_edges;
  for (int edge_index = 1; edge_index <= edge_faces.Extent(); ++edge_index) {
    const TopoDS_Edge edge = TopoDS::Edge(edge_faces.FindKey(edge_index));
    const int mapped_edge_id = edge_map.FindIndex(edge);
    std::set<int> owners;
    for (TopTools_ListIteratorOfListOfShape iterator(edge_faces.FindFromIndex(edge_index)); iterator.More(); iterator.Next()) {
      const TopoDS_Face face = TopoDS::Face(iterator.Value());
      const int face_index = face_map.FindIndex(face);
      const auto patch_iterator = face_to_patch.find(face_index);
      if (patch_iterator != face_to_patch.end()) {
        owners.insert(patch_iterator->second);
      }
    }
    if (owners.size() == 2) {
      auto iterator = owners.begin();
      const int left = *iterator++;
      const int right = *iterator;
      shared_edges[{std::min(left, right), std::max(left, right)}].push_back({edge, mapped_edge_id});
    }
  }

  for (const auto& [key, edges] : shared_edges) {
    SheetPatch& left = patches[patch_index_by_id.at(key.first)];
    SheetPatch& right = patches[patch_index_by_id.at(key.second)];
    std::optional<gp_Dir> expected_direction;
    if (left.type == PatchType::kCylinder) {
      expected_direction = left.cylinder_axis_dir;
    } else if (right.type == PatchType::kCylinder) {
      expected_direction = right.cylinder_axis_dir;
    }
    const auto selection = SelectSeamPair(edges, thickness, expected_direction);
    if (!selection.has_value()) {
      continue;
    }
    const auto [start, end] = BuildMedianSeamEndpoints(left, right, *selection);
    const auto [left_local_start, left_local_end] = LocalSeamEndpoints(left, *selection);
    const auto [right_local_start, right_local_end] = LocalSeamEndpoints(right, *selection);
    left.seams.push_back(SeamRecord{
        .neighbor_patch_id = right.patch_id,
        .start = start,
        .end = end,
        .local_start = left_local_start,
        .local_end = left_local_end,
        .edge_ids = selection->secondary_edge_id.has_value()
                        ? std::vector<int>{selection->primary_edge_id, *selection->secondary_edge_id}
                        : std::vector<int>{selection->primary_edge_id},
    });
    right.seams.push_back(SeamRecord{
        .neighbor_patch_id = left.patch_id,
        .start = start,
        .end = end,
        .local_start = right_local_start,
        .local_end = right_local_end,
        .edge_ids = selection->secondary_edge_id.has_value()
                        ? std::vector<int>{selection->primary_edge_id, *selection->secondary_edge_id}
                        : std::vector<int>{selection->primary_edge_id},
    });
    left.seam_edge_ids.insert(selection->primary_edge_id);
    right.seam_edge_ids.insert(selection->primary_edge_id);
    if (selection->secondary_edge_id.has_value()) {
      left.seam_edge_ids.insert(*selection->secondary_edge_id);
      right.seam_edge_ids.insert(*selection->secondary_edge_id);
    }
  }
}

void ResolvePlaneFrames(std::vector<SheetPatch>& patches) {
  for (auto& patch : patches) {
    if (patch.type != PatchType::kPlane || patch.seams.size() != 1) {
      continue;
    }

    gp_Vec seam_direction(patch.seams.front().start, patch.seams.front().end);
    if (seam_direction.Magnitude() <= Precision::Confusion()) {
      continue;
    }
    seam_direction.Normalize();

    gp_Vec plane_normal(patch.mid_plane.Axis().Direction());
    gp_Vec in_plane_perpendicular = plane_normal.Crossed(seam_direction);
    if (in_plane_perpendicular.Magnitude() <= Precision::Confusion()) {
      continue;
    }
    in_plane_perpendicular.Normalize();

    const gp_Pnt seam_midpoint = Midpoint(patch.seams.front().start, patch.seams.front().end);
    patch.local_origin = seam_midpoint;
    patch.local_u = gp_Dir(seam_direction);
    patch.local_v = gp_Dir(in_plane_perpendicular);

    GProp_GProps properties;
    BRepGProp::SurfaceProperties(patch.representative_face, properties);
    const Point2 centroid = MapToLocal(patch, properties.CentreOfMass());
    if (centroid.y < 0.0) {
      in_plane_perpendicular.Reverse();
      patch.local_v = gp_Dir(in_plane_perpendicular);
    }
  }
}

PatchTransform AlignPatchTransform(
    const Point2& parent_global_start,
    const Point2& parent_global_end,
    const Point2& child_local_start,
    const Point2& child_local_end,
    const Point2& parent_global_centroid,
    const Point2& child_local_centroid,
    std::optional<double> desired_child_side = std::nullopt,
    std::optional<Point2> desired_side_probe_local = std::nullopt,
    std::optional<OrientationProbe> orientation_probe = std::nullopt) {
  const Point2 target_vector = parent_global_end - parent_global_start;
  const Point2 target_direction = Normalize(target_vector);

  auto build_transform = [&](bool reverse) {
    const Point2 start = reverse ? child_local_end : child_local_start;
    const Point2 end = reverse ? child_local_start : child_local_end;
    const Point2 source_vector = end - start;
    const Point2 source_direction = Normalize(source_vector);
    const double cross = Cross2(source_direction, target_direction);
    const double dot = Dot(target_direction, source_direction);

    PatchTransform transform;
    transform.resolved = true;
    transform.a = dot;
    transform.b = -cross;
    transform.c = cross;
    transform.d = dot;
    const Point2 source_midpoint = Midpoint(start, end);
    const Point2 target_midpoint = Midpoint(parent_global_start, parent_global_end);
    const Point2 mapped_midpoint = Apply(transform, source_midpoint);
    transform.translation = target_midpoint - mapped_midpoint;
    return transform;
  };

  auto apply_with_optional_reflection = [&](bool reverse) {
    PatchTransform transform = build_transform(reverse);
    const Point2 side_probe = desired_side_probe_local.value_or(child_local_centroid);
    const double child_side = SignedLineSide(parent_global_start, parent_global_end, Apply(transform, side_probe));
    if (desired_child_side.has_value()) {
      if (std::abs(child_side) > 1e-6) {
        const double child_sign = child_side >= 0.0 ? 1.0 : -1.0;
        if (child_sign != *desired_child_side) {
          transform = Compose(ReflectionTransform(parent_global_start, parent_global_end), transform);
        }
      }
    } else {
      const double parent_side = SignedLineSide(parent_global_start, parent_global_end, parent_global_centroid);
      if (std::abs(parent_side) > 1e-6 && std::abs(child_side) > 1e-6 && (parent_side * child_side) > 0.0) {
        transform = Compose(ReflectionTransform(parent_global_start, parent_global_end), transform);
      }
    }
    const Point2 start = reverse ? child_local_end : child_local_start;
    const Point2 end = reverse ? child_local_start : child_local_end;
    const Point2 mapped_start = Apply(transform, start);
    const Point2 mapped_end = Apply(transform, end);
    double seam_error = Length(mapped_start - parent_global_start) + Length(mapped_end - parent_global_end);
    if (orientation_probe.has_value()) {
      const Point2 target_midpoint = Midpoint(parent_global_start, parent_global_end);
      const Point2 mapped_probe = Apply(transform, orientation_probe->local_point);
      const double along = Dot(mapped_probe - target_midpoint, target_direction);
      if (std::abs(along) > 1e-6) {
        const double actual_sign = along >= 0.0 ? 1.0 : -1.0;
        if (actual_sign != orientation_probe->desired_along_sign) {
          seam_error += 1000000.0;
        }
      }
    }
    return std::pair<PatchTransform, double>{transform, seam_error};
  };

  const auto direct = apply_with_optional_reflection(false);
  const auto reversed = apply_with_optional_reflection(true);
  return direct.second <= reversed.second ? direct.first : reversed.first;
}

std::optional<double> DesiredSideForCylinderToPlaneTransition(
    const SheetPatch& cylinder_patch,
    const SheetPatch& child_plane,
    const SeamRecord& seam,
    const std::map<int, std::size_t>& patch_index_by_id,
    const std::vector<SheetPatch>& patches) {
  if (cylinder_patch.type != PatchType::kCylinder || child_plane.type != PatchType::kPlane) {
    return std::nullopt;
  }

  const auto far_plane_it = std::find_if(cylinder_patch.seams.begin(), cylinder_patch.seams.end(), [&](const SeamRecord& candidate) {
    return candidate.neighbor_patch_id != child_plane.patch_id;
  });
  if (far_plane_it == cylinder_patch.seams.end()) {
    return std::nullopt;
  }

  const SheetPatch& far_patch = patches[patch_index_by_id.at(far_plane_it->neighbor_patch_id)];
  if (far_patch.type != PatchType::kPlane || !far_patch.transform.resolved) {
    return std::nullopt;
  }

  const Point2 far_centroid = Apply(far_patch.transform, far_patch.local_centroid);
  const Point2 seam_start = Apply(cylinder_patch.transform, SeamLocalStartForPatch(cylinder_patch, seam));
  const Point2 seam_end = Apply(cylinder_patch.transform, SeamLocalEndForPatch(cylinder_patch, seam));
  const double far_side = SignedLineSide(seam_start, seam_end, far_centroid);
  if (std::abs(far_side) <= 1e-6) {
    return std::nullopt;
  }
  return far_side >= 0.0 ? -1.0 : 1.0;
}

bool IsClosedSectionCylinder(
    const SheetPatch& cylinder_patch,
    const std::map<int, std::size_t>& patch_index_by_id,
    const std::vector<SheetPatch>& patches) {
  if (cylinder_patch.type != PatchType::kCylinder || cylinder_patch.seams.size() != 2) {
    return false;
  }
  for (const auto& seam : cylinder_patch.seams) {
    const SheetPatch& neighbor = patches[patch_index_by_id.at(seam.neighbor_patch_id)];
    if (neighbor.type != PatchType::kPlane || neighbor.seams.size() < 2) {
      return false;
    }
  }
  return true;
}

std::optional<double> DesiredSideForPlaneToCylinderTransition(
    const SheetPatch& parent_plane,
    const SheetPatch& cylinder_patch,
    const SeamRecord& seam,
    const std::map<int, std::size_t>& patch_index_by_id,
    const std::vector<SheetPatch>& patches) {
  if (parent_plane.type != PatchType::kPlane || cylinder_patch.type != PatchType::kCylinder) {
    return std::nullopt;
  }
  if (!IsClosedSectionCylinder(cylinder_patch, patch_index_by_id, patches)) {
    return std::nullopt;
  }

  const auto far_plane_it = std::find_if(cylinder_patch.seams.begin(), cylinder_patch.seams.end(), [&](const SeamRecord& candidate) {
    return candidate.neighbor_patch_id != parent_plane.patch_id;
  });
  if (far_plane_it == cylinder_patch.seams.end()) {
    return std::nullopt;
  }

  const SheetPatch& far_patch = patches[patch_index_by_id.at(far_plane_it->neighbor_patch_id)];
  if (far_patch.type != PatchType::kPlane) {
    return std::nullopt;
  }

  gp_Vec seam_tangent(seam.start, seam.end);
  if (seam_tangent.Magnitude() <= Precision::Confusion()) {
    return std::nullopt;
  }
  seam_tangent.Normalize();

  gp_Vec parent_normal(parent_plane.mid_plane.Axis().Direction());
  gp_Vec far_normal(far_patch.mid_plane.Axis().Direction());
  gp_Vec side_direction = parent_normal.Crossed(seam_tangent);
  if (side_direction.Magnitude() <= Precision::Confusion()) {
    return std::nullopt;
  }
  side_direction.Normalize();

  const double alignment = Dot(far_normal, side_direction);
  if (std::abs(alignment) <= 1e-6) {
    return std::nullopt;
  }
  return alignment >= 0.0 ? 1.0 : -1.0;
}

std::optional<Point2> DesiredSideProbeForCylinderTransition(
    const SheetPatch& parent_plane,
    const SheetPatch& cylinder_patch,
    const std::map<int, std::size_t>& patch_index_by_id,
    const std::vector<SheetPatch>& patches) {
  if (parent_plane.type != PatchType::kPlane || cylinder_patch.type != PatchType::kCylinder) {
    return std::nullopt;
  }
  if (!IsClosedSectionCylinder(cylinder_patch, patch_index_by_id, patches)) {
    return std::nullopt;
  }
  const auto far_seam_it = std::find_if(cylinder_patch.seams.begin(), cylinder_patch.seams.end(), [&](const SeamRecord& candidate) {
    return candidate.neighbor_patch_id != parent_plane.patch_id;
  });
  if (far_seam_it == cylinder_patch.seams.end()) {
    return std::nullopt;
  }
  return Midpoint(far_seam_it->local_start, far_seam_it->local_end);
}

std::optional<OrientationProbe> SelectOrientationProbe(
    const SheetPatch& patch,
    const gp_Pnt& seam_start,
    const gp_Pnt& seam_end) {
  const Point2 local_seam_start = MapToLocal(patch, seam_start);
  const Point2 local_seam_end = MapToLocal(patch, seam_end);
  const Point2 local_seam_midpoint = Midpoint(local_seam_start, local_seam_end);
  const gp_Pnt seam_midpoint = Midpoint(seam_start, seam_end);
  gp_Vec seam_direction_3d(seam_start, seam_end);
  if (seam_direction_3d.Magnitude() <= Precision::Confusion()) {
    return std::nullopt;
  }
  seam_direction_3d.Normalize();

  bool found = false;
  double best_along = 0.0;
  double best_side_distance = 0.0;
  OrientationProbe best{};

  for (TopExp_Explorer explorer(patch.representative_face, TopAbs_EDGE); explorer.More(); explorer.Next()) {
    const TopoDS_Edge edge = TopoDS::Edge(explorer.Current());
    for (const auto& point : SampleEdgePoints(edge)) {
      const double along = Dot(gp_Vec(seam_midpoint, point), seam_direction_3d);
      if (std::abs(along) <= 1e-6) {
        continue;
      }
      const Point2 local_point = MapToLocal(patch, point);
      const double side_distance = std::abs(SignedLineSide(local_seam_start, local_seam_end, local_point));
      if (!found ||
          std::abs(along) > std::abs(best_along) + 1e-6 ||
          (std::abs(std::abs(along) - std::abs(best_along)) <= 1e-6 && side_distance > best_side_distance + 1e-6)) {
        found = true;
        best_along = along;
        best_side_distance = side_distance;
        best = OrientationProbe{
            .local_point = local_point,
            .desired_along_sign = along >= 0.0 ? 1.0 : -1.0,
        };
      }
    }
  }

  if (!found) {
    return std::nullopt;
  }
  return best;
}

std::vector<Point2> MapGlobalPoints(const SheetPatch& patch, const std::vector<gp_Pnt>& points) {
  std::vector<Point2> mapped;
  mapped.reserve(points.size());
  for (const auto& point : points) {
    mapped.push_back(Apply(patch.transform, MapToLocal(patch, point)));
  }
  return mapped;
}

bool NearlyEqual(const Point2& left, const Point2& right, double tolerance = 1e-5) {
  return Length(left - right) <= tolerance;
}

double SignedArea(const std::vector<Point2>& ring) {
  if (ring.size() < 3) {
    return 0.0;
  }
  double area = 0.0;
  for (std::size_t index = 0; index + 1 < ring.size(); ++index) {
    area += (ring[index].x * ring[index + 1].y) - (ring[index + 1].x * ring[index].y);
  }
  return area / 2.0;
}

void RemoveDuplicateAndCollinear(std::vector<Point2>& ring) {
  std::vector<Point2> cleaned;
  cleaned.reserve(ring.size());
  for (const auto& point : ring) {
    if (cleaned.empty() || !NearlyEqual(cleaned.back(), point)) {
      cleaned.push_back(point);
    }
  }
  if (cleaned.size() >= 2 && NearlyEqual(cleaned.front(), cleaned.back())) {
    cleaned.pop_back();
  }
  if (cleaned.size() < 3) {
    ring = std::move(cleaned);
    return;
  }

  bool changed = true;
  while (changed && cleaned.size() >= 3) {
    changed = false;
    std::vector<Point2> reduced;
    reduced.reserve(cleaned.size());
    for (std::size_t index = 0; index < cleaned.size(); ++index) {
      const Point2& previous = cleaned[(index + cleaned.size() - 1) % cleaned.size()];
      const Point2& current = cleaned[index];
      const Point2& next = cleaned[(index + 1) % cleaned.size()];
      if (Length(current - previous) <= 1e-6 || Length(next - current) <= 1e-6) {
        changed = true;
        continue;
      }
      const double area = std::abs(Cross2(current - previous, next - current));
      if (area <= 1e-4) {
        changed = true;
        continue;
      }
      reduced.push_back(current);
    }
    cleaned = std::move(reduced);
  }
  if (!cleaned.empty()) {
    cleaned.push_back(cleaned.front());
  }
  ring = std::move(cleaned);
}

std::vector<Point2> SampleWireRing(const SheetPatch& patch, const TopoDS_Wire& wire, const TopoDS_Face& face) {
  std::vector<Point2> ring;
  for (BRepTools_WireExplorer explorer(wire, face); explorer.More(); explorer.Next()) {
    TopoDS_Edge edge = explorer.Current();
    auto points3d = SampleEdgePoints(edge);
    if (points3d.size() < 2) {
      continue;
    }
    if (explorer.Orientation() == TopAbs_REVERSED) {
      std::reverse(points3d.begin(), points3d.end());
    }
    const auto points2d = MapGlobalPoints(patch, points3d);
    for (const auto& point : points2d) {
      if (ring.empty() || !NearlyEqual(ring.back(), point)) {
        ring.push_back(point);
      }
    }
  }
  if (!ring.empty() && !NearlyEqual(ring.front(), ring.back())) {
    ring.push_back(ring.front());
  }
  RemoveDuplicateAndCollinear(ring);
  return ring;
}

std::vector<BgPolygon> BuildPatchPolygons(const SheetPatch& patch) {
  std::vector<std::vector<Point2>> rings;
  for (TopExp_Explorer explorer(patch.representative_face, TopAbs_WIRE); explorer.More(); explorer.Next()) {
    auto ring = SampleWireRing(patch, TopoDS::Wire(explorer.Current()), patch.representative_face);
    if (ring.size() >= 4 && std::abs(SignedArea(ring)) > 1e-3) {
      rings.push_back(std::move(ring));
    }
  }
  if (rings.empty()) {
    return {};
  }

  std::size_t outer_index = 0;
  double max_area = 0.0;
  for (std::size_t index = 0; index < rings.size(); ++index) {
    const double area = std::abs(SignedArea(rings[index]));
    if (area > max_area) {
      max_area = area;
      outer_index = index;
    }
  }

  BgPolygon polygon;
  for (const auto& point : rings[outer_index]) {
    bg::append(polygon.outer(), BgPoint(point.x, point.y));
  }
  for (std::size_t index = 0; index < rings.size(); ++index) {
    if (index == outer_index) {
      continue;
    }
    polygon.inners().resize(polygon.inners().size() + 1);
    auto& inner = polygon.inners().back();
    for (const auto& point : rings[index]) {
      bg::append(inner, BgPoint(point.x, point.y));
    }
  }
  bg::correct(polygon);
  return {polygon};
}

std::vector<Segment2> SegmentsFromRing(const bg::model::ring<BgPoint>& ring) {
  std::vector<Segment2> segments;
  if (ring.size() < 2) {
    return segments;
  }
  for (std::size_t index = 1; index < ring.size(); ++index) {
    const Point2 start{bg::get<0>(ring[index - 1]), bg::get<1>(ring[index - 1])};
    const Point2 end{bg::get<0>(ring[index]), bg::get<1>(ring[index])};
    if (Length(end - start) <= 1e-6) {
      continue;
    }
    segments.push_back(Segment2{.start = start, .end = end});
  }
  return segments;
}

double PolygonAreaAbs(const BgPolygon& polygon) {
  return std::abs(bg::area(polygon));
}

double MultiPolygonAreaAbs(const BgMultiPolygon& polygons) {
  double area = 0.0;
  for (const auto& polygon : polygons) {
    area += PolygonAreaAbs(polygon);
  }
  return area;
}

std::vector<Segment2> BuildBoundarySegmentsFromPolygons(const std::vector<BgPolygon>& polygons) {
  std::map<QuantizedSegmentKey, std::vector<Segment2>> grouped_segments;
  for (const auto& polygon : polygons) {
    auto outer_segments = SegmentsFromRing(polygon.outer());
    for (const auto& segment : outer_segments) {
      grouped_segments[QuantizeSegment(segment)].push_back(segment);
    }
    for (const auto& inner : polygon.inners()) {
      auto inner_segments = SegmentsFromRing(inner);
      for (const auto& segment : inner_segments) {
        grouped_segments[QuantizeSegment(segment)].push_back(segment);
      }
    }
  }

  std::vector<Segment2> boundary_segments;
  for (const auto& [_, segments] : grouped_segments) {
    if (segments.size() % 2 == 1) {
      boundary_segments.push_back(segments.front());
    }
  }
  return boundary_segments;
}

std::vector<Segment2> MergeCollinearOverlaps(const std::vector<Segment2>& segments) {
  struct Interval {
    double start = 0.0;
    double end = 0.0;
  };
  struct GroupData {
    Point2 direction{};
    Point2 normal{};
    double offset = 0.0;
    std::vector<Interval> intervals;
  };

  std::map<QuantizedLineKey, GroupData> groups;
  for (const auto& segment : segments) {
    Point2 direction = segment.end - segment.start;
    const double length = Length(direction);
    if (length <= 1e-6) {
      continue;
    }
    direction = Normalize(direction);
    if (direction.x < -1e-9 || (std::abs(direction.x) <= 1e-9 && direction.y < -1e-9)) {
      direction = direction * -1.0;
    }
    const Point2 normal{-direction.y, direction.x};
    const double offset = Dot(segment.start, normal);
    const QuantizedLineKey key = QuantizeLineKey(direction, offset);
    GroupData& group = groups[key];
    if (group.intervals.empty()) {
      group.direction = direction;
      group.normal = normal;
      group.offset = offset;
    }
    const double a = Dot(segment.start, direction);
    const double b = Dot(segment.end, direction);
    group.intervals.push_back(Interval{
        .start = std::min(a, b),
        .end = std::max(a, b),
    });
  }

  std::vector<Segment2> merged_segments;
  for (auto& [_, group] : groups) {
    auto& intervals = group.intervals;
    if (intervals.empty()) {
      continue;
    }
    std::sort(intervals.begin(), intervals.end(), [](const Interval& left, const Interval& right) {
      if (left.start != right.start) {
        return left.start < right.start;
      }
      return left.end < right.end;
    });

    Interval current = intervals.front();
    for (std::size_t index = 1; index < intervals.size(); ++index) {
      if (intervals[index].start <= current.end + 1e-5) {
        current.end = std::max(current.end, intervals[index].end);
        continue;
      }
      if ((current.end - current.start) > 1e-6) {
        merged_segments.push_back(Segment2{
            .start = (group.direction * current.start) + (group.normal * group.offset),
            .end = (group.direction * current.end) + (group.normal * group.offset),
        });
      }
      current = intervals[index];
    }
    if ((current.end - current.start) > 1e-6) {
      merged_segments.push_back(Segment2{
          .start = (group.direction * current.start) + (group.normal * group.offset),
          .end = (group.direction * current.end) + (group.normal * group.offset),
      });
    }
  }
  return merged_segments;
}

std::vector<Segment2> DeduplicateSegments(const std::vector<Segment2>& segments) {
  std::map<QuantizedSegmentKey, Segment2> unique;
  for (const auto& segment : segments) {
    if (Length(segment.end - segment.start) <= 1e-6) {
      continue;
    }
    unique.emplace(QuantizeSegment(segment), segment);
  }
  std::vector<Segment2> deduplicated;
  deduplicated.reserve(unique.size());
  for (const auto& [_, segment] : unique) {
    deduplicated.push_back(segment);
  }
  return deduplicated;
}

std::vector<Segment2> SplitSegmentsAtIntersections(const std::vector<Segment2>& segments) {
  if (segments.empty()) {
    return {};
  }

  constexpr double kParallelTolerance = 1e-9;
  constexpr double kBoundaryTolerance = 1e-7;
  constexpr double kSplitTolerance = 1e-6;

  std::vector<std::vector<double>> split_parameters(segments.size(), std::vector<double>{0.0, 1.0});
  for (std::size_t left_index = 0; left_index < segments.size(); ++left_index) {
    const Point2 left_start = segments[left_index].start;
    const Point2 left_delta = segments[left_index].end - segments[left_index].start;
    if (Length(left_delta) <= 1e-9) {
      continue;
    }
    for (std::size_t right_index = left_index + 1; right_index < segments.size(); ++right_index) {
      const Point2 right_start = segments[right_index].start;
      const Point2 right_delta = segments[right_index].end - segments[right_index].start;
      if (Length(right_delta) <= 1e-9) {
        continue;
      }

      const double denominator = Cross2(left_delta, right_delta);
      if (std::abs(denominator) <= kParallelTolerance) {
        continue;
      }

      const Point2 delta_start = right_start - left_start;
      const double left_t = Cross2(delta_start, right_delta) / denominator;
      const double right_t = Cross2(delta_start, left_delta) / denominator;
      if (left_t < -kBoundaryTolerance || left_t > (1.0 + kBoundaryTolerance) ||
          right_t < -kBoundaryTolerance || right_t > (1.0 + kBoundaryTolerance)) {
        continue;
      }

      if (left_t > kBoundaryTolerance && left_t < (1.0 - kBoundaryTolerance)) {
        split_parameters[left_index].push_back(std::clamp(left_t, 0.0, 1.0));
      }
      if (right_t > kBoundaryTolerance && right_t < (1.0 - kBoundaryTolerance)) {
        split_parameters[right_index].push_back(std::clamp(right_t, 0.0, 1.0));
      }
    }
  }

  std::vector<Segment2> split_segments;
  for (std::size_t index = 0; index < segments.size(); ++index) {
    auto& parameters = split_parameters[index];
    std::sort(parameters.begin(), parameters.end());
    parameters.erase(
        std::unique(parameters.begin(), parameters.end(), [](double left, double right) {
          return std::abs(left - right) <= kSplitTolerance;
        }),
        parameters.end());

    for (std::size_t parameter_index = 1; parameter_index < parameters.size(); ++parameter_index) {
      const double start_t = parameters[parameter_index - 1];
      const double end_t = parameters[parameter_index];
      if ((end_t - start_t) <= 1e-8) {
        continue;
      }
      const Point2 start = segments[index].start + ((segments[index].end - segments[index].start) * start_t);
      const Point2 end = segments[index].start + ((segments[index].end - segments[index].start) * end_t);
      if (Length(end - start) <= 1e-6) {
        continue;
      }
      split_segments.push_back(Segment2{
          .start = start,
          .end = end,
      });
    }
  }
  return split_segments;
}

SegmentBounds ComputeSegmentBounds(const std::vector<Segment2>& segments) {
  SegmentBounds bounds;
  for (const auto& segment : segments) {
    const auto update = [&](const Point2& point) {
      if (!bounds.valid) {
        bounds.valid = true;
        bounds.min_x = point.x;
        bounds.max_x = point.x;
        bounds.min_y = point.y;
        bounds.max_y = point.y;
        return;
      }
      bounds.min_x = std::min(bounds.min_x, point.x);
      bounds.max_x = std::max(bounds.max_x, point.x);
      bounds.min_y = std::min(bounds.min_y, point.y);
      bounds.max_y = std::max(bounds.max_y, point.y);
    };
    update(segment.start);
    update(segment.end);
  }
  return bounds;
}

double BoundsSpanX(const SegmentBounds& bounds) {
  if (!bounds.valid) {
    return 0.0;
  }
  return bounds.max_x - bounds.min_x;
}

double BoundsSpanY(const SegmentBounds& bounds) {
  if (!bounds.valid) {
    return 0.0;
  }
  return bounds.max_y - bounds.min_y;
}

int CountBranchVertices(const std::vector<Segment2>& segments) {
  std::map<QuantizedPoint2, int> degree_by_point;
  for (const auto& segment : segments) {
    if (Length(segment.end - segment.start) <= 1e-6) {
      continue;
    }
    ++degree_by_point[QuantizePoint(segment.start)];
    ++degree_by_point[QuantizePoint(segment.end)];
  }
  int branch_count = 0;
  for (const auto& [_, degree] : degree_by_point) {
    if (degree > 2) {
      ++branch_count;
    }
  }
  return branch_count;
}

int CountDanglingVertices(const std::vector<Segment2>& segments) {
  std::map<QuantizedPoint2, int> degree_by_point;
  for (const auto& segment : segments) {
    if (Length(segment.end - segment.start) <= 1e-6) {
      continue;
    }
    ++degree_by_point[QuantizePoint(segment.start)];
    ++degree_by_point[QuantizePoint(segment.end)];
  }
  int dangling_count = 0;
  for (const auto& [_, degree] : degree_by_point) {
    if (degree == 1) {
      ++dangling_count;
    }
  }
  return dangling_count;
}

std::vector<Point2> CollectDanglingPoints(const std::vector<Segment2>& segments) {
  std::map<QuantizedPoint2, int> degree_by_point;
  std::map<QuantizedPoint2, Point2> point_by_key;
  for (const auto& segment : segments) {
    if (Length(segment.end - segment.start) <= 1e-6) {
      continue;
    }
    const QuantizedPoint2 start_key = QuantizePoint(segment.start);
    const QuantizedPoint2 end_key = QuantizePoint(segment.end);
    ++degree_by_point[start_key];
    ++degree_by_point[end_key];
    point_by_key.emplace(start_key, segment.start);
    point_by_key.emplace(end_key, segment.end);
  }

  std::vector<Point2> dangling;
  for (const auto& [key, degree] : degree_by_point) {
    if (degree == 1) {
      dangling.push_back(point_by_key.at(key));
    }
  }
  return dangling;
}

std::vector<Segment2> BuildSegmentsFromMergedPolygons(const BgMultiPolygon& merged) {
  std::vector<Segment2> segments;
  for (const auto& polygon : merged) {
    auto outer_segments = SegmentsFromRing(polygon.outer());
    segments.insert(segments.end(), outer_segments.begin(), outer_segments.end());
    for (const auto& inner : polygon.inners()) {
      auto inner_segments = SegmentsFromRing(inner);
      segments.insert(segments.end(), inner_segments.begin(), inner_segments.end());
    }
  }
  segments = MergeCollinearOverlaps(segments);
  return DeduplicateSegments(segments);
}

std::pair<Segment2, Segment2> Align2DSegments(Segment2 first, Segment2 second) {
  const double direct = Length(first.start - second.start) + Length(first.end - second.end);
  const double reversed = Length(first.start - second.end) + Length(first.end - second.start);
  if (reversed < direct) {
    std::swap(second.start, second.end);
  }
  return {first, second};
}

bool IsSingleClosedSeamLoop(const std::vector<SheetPatch>& patches);

std::vector<Segment2> BuildCutSegmentsFromUnion(const std::vector<SheetPatch>& patches) {
  BgMultiPolygon merged;
  bool initialized = false;
  std::vector<BgPolygon> all_polygons;
  double expected_area = 0.0;

  for (const auto& patch : patches) {
    const auto polygons = BuildPatchPolygons(patch);
    for (const auto& polygon : polygons) {
      expected_area += PolygonAreaAbs(polygon);
      all_polygons.push_back(polygon);
      if (!initialized) {
        merged.push_back(polygon);
        initialized = true;
      } else {
        BgMultiPolygon next;
        bg::union_(merged, polygon, next);
        merged = std::move(next);
      }
    }
  }

  if (!all_polygons.empty()) {
    const double merged_area = MultiPolygonAreaAbs(merged);
    if ((expected_area - merged_area) > std::max(kUnionAreaTolerance, expected_area * 1e-4)) {
      const std::vector<Segment2> merged_segments = BuildSegmentsFromMergedPolygons(merged);
      if (IsSingleClosedSeamLoop(patches) && !merged_segments.empty()) {
        return merged_segments;
      }
      std::vector<Segment2> fallback_raw = BuildBoundarySegmentsFromPolygons(all_polygons);
      std::vector<Segment2> fallback = DeduplicateSegments(fallback_raw);

      if (fallback.empty() && fallback_raw.empty()) {
        return merged_segments;
      }

      if (fallback.empty()) {
        fallback = fallback_raw;
      }

      const int fallback_dangling = CountDanglingVertices(fallback);
      const int raw_fallback_dangling = CountDanglingVertices(fallback_raw);
      if (fallback_dangling > raw_fallback_dangling) {
        fallback = fallback_raw;
      }

      if (merged_segments.empty()) {
        return fallback;
      }

      const SegmentBounds merged_bounds = ComputeSegmentBounds(merged_segments);
      const SegmentBounds fallback_bounds = ComputeSegmentBounds(fallback);
      const double merged_span_x = BoundsSpanX(merged_bounds);
      const double merged_span_y = BoundsSpanY(merged_bounds);
      const double fallback_span_x = BoundsSpanX(fallback_bounds);
      const double fallback_span_y = BoundsSpanY(fallback_bounds);

      const bool merged_shrank_horizontally =
          fallback_span_x > 1e-6 && merged_span_x < (fallback_span_x * 0.98);
      const bool merged_shrank_vertically =
          fallback_span_y > 1e-6 && merged_span_y < (fallback_span_y * 0.98);
      if (merged_shrank_horizontally || merged_shrank_vertically) {
        return fallback;
      }

      const int merged_branches = CountBranchVertices(merged_segments);
      const int fallback_branches = CountBranchVertices(fallback);
      if (fallback_branches < merged_branches) {
        return fallback;
      }
      return merged_segments;
    }
  }

  return BuildSegmentsFromMergedPolygons(merged);
}

std::vector<Segment2> BuildBendLines(const std::vector<SheetPatch>& patches) {
  std::vector<Segment2> bend_lines;
  for (const auto& patch : patches) {
    if (patch.type != PatchType::kCylinder || patch.seams.size() != 2 || !patch.transform.resolved) {
      continue;
    }
    auto [first, second] = Align2DSegments(
        Segment2{
            .start = Apply(patch.transform, SeamLocalStartForPatch(patch, patch.seams[0])),
            .end = Apply(patch.transform, SeamLocalEndForPatch(patch, patch.seams[0])),
        },
        Segment2{
            .start = Apply(patch.transform, SeamLocalStartForPatch(patch, patch.seams[1])),
            .end = Apply(patch.transform, SeamLocalEndForPatch(patch, patch.seams[1])),
        });
    const Point2 first_vector = first.end - first.start;
    const Point2 second_vector = second.end - second.start;
    const Point2 direction = Length(first_vector) >= Length(second_vector) ? Normalize(first_vector) : Normalize(second_vector);
    const auto projection = [&](const Point2& point) {
      return Dot(point - first.start, direction);
    };
    const double first_min = std::min(projection(first.start), projection(first.end));
    const double first_max = std::max(projection(first.start), projection(first.end));
    const double second_min = std::min(projection(second.start), projection(second.end));
    const double second_max = std::max(projection(second.start), projection(second.end));
    const double overlap_min = std::max(first_min, second_min);
    const double overlap_max = std::min(first_max, second_max);
    if ((overlap_max - overlap_min) > 1e-6) {
      auto point_on_segment = [&](const Segment2& segment, double projection_value) {
        const Point2 segment_direction = Normalize(segment.end - segment.start);
        const double segment_start_projection = Dot(segment.start - first.start, direction);
        return segment.start + (segment_direction * (projection_value - segment_start_projection));
      };
      const Point2 first_overlap_start = point_on_segment(first, overlap_min);
      const Point2 first_overlap_end = point_on_segment(first, overlap_max);
      const Point2 second_overlap_start = point_on_segment(second, overlap_min);
      const Point2 second_overlap_end = point_on_segment(second, overlap_max);
      bend_lines.push_back(Segment2{
          .start = Midpoint(first_overlap_start, second_overlap_start),
          .end = Midpoint(first_overlap_end, second_overlap_end),
      });
      continue;
    }
    bend_lines.push_back(Segment2{
        .start = Midpoint(first.start, second.start),
        .end = Midpoint(first.end, second.end),
    });
  }
  return bend_lines;
}

bool IsSingleClosedSeamLoop(const std::vector<SheetPatch>& patches) {
  if (patches.size() < 4) {
    return false;
  }

  std::map<int, std::size_t> patch_index_by_id;
  for (std::size_t index = 0; index < patches.size(); ++index) {
    patch_index_by_id.emplace(patches[index].patch_id, index);
  }

  std::set<std::pair<int, int>> undirected_edges;
  for (const auto& patch : patches) {
    if (patch.seams.size() != 2) {
      return false;
    }
    for (const auto& seam : patch.seams) {
      const int left = std::min(patch.patch_id, seam.neighbor_patch_id);
      const int right = std::max(patch.patch_id, seam.neighbor_patch_id);
      undirected_edges.insert({left, right});
    }
  }

  if (undirected_edges.size() != patches.size()) {
    return false;
  }

  std::set<int> visited;
  std::queue<int> pending;
  pending.push(patches.front().patch_id);
  visited.insert(patches.front().patch_id);
  while (!pending.empty()) {
    const int current_id = pending.front();
    pending.pop();
    const SheetPatch& current = patches[patch_index_by_id.at(current_id)];
    for (const auto& seam : current.seams) {
      if (visited.insert(seam.neighbor_patch_id).second) {
        pending.push(seam.neighbor_patch_id);
      }
    }
  }
  return visited.size() == patches.size();
}

struct LocalSegment {
  Point2 start{};
  Point2 end{};
};

Point2 BasisPerpendicular(const Point2& point) {
  return Point2{-point.y, point.x};
}

Point2 BasisNormalize(const Point2& point) {
  return Normalize(point);
}

bool TryBuildClosedSectionBasis(
    const std::vector<Segment2>& bend_segments,
    Point2& along_direction,
    Point2& across_direction) {
  if (bend_segments.size() < 3) {
    return false;
  }

  double best_length = 0.0;
  Point2 candidate{};
  for (const auto& bend : bend_segments) {
    const Point2 vector = bend.end - bend.start;
    const double length = Length(vector);
    if (length > best_length) {
      best_length = length;
      candidate = BasisNormalize(vector);
    }
  }
  if (best_length <= 1e-6) {
    return false;
  }

  for (const auto& bend : bend_segments) {
    const Point2 direction = BasisNormalize(bend.end - bend.start);
    if (Length(direction) <= 1e-6) {
      continue;
    }
    const double alignment = std::abs(Dot(direction, candidate));
    if (alignment < 0.995) {
      return false;
    }
  }

  along_direction = candidate;
  across_direction = BasisPerpendicular(candidate);
  return true;
}

Point2 ToLocalBasis(const Point2& point, const Point2& origin, const Point2& across, const Point2& along) {
  const Point2 delta = point - origin;
  return Point2{
      Dot(delta, across),
      Dot(delta, along),
  };
}

Point2 FromLocalBasis(const Point2& point, const Point2& origin, const Point2& across, const Point2& along) {
  return origin + (across * point.x) + (along * point.y);
}

std::optional<double> SelectClosedSectionCutCoordinate(
    const std::vector<LocalSegment>& cut_segments,
    const std::vector<LocalSegment>& bend_segments,
    double min_t,
    double max_t) {
  if ((max_t - min_t) <= 1e-6) {
    return std::nullopt;
  }

  std::vector<double> bend_coordinates;
  bend_coordinates.reserve(bend_segments.size());
  for (const auto& bend : bend_segments) {
    bend_coordinates.push_back((bend.start.x + bend.end.x) / 2.0);
  }
  std::sort(bend_coordinates.begin(), bend_coordinates.end());
  bend_coordinates.erase(
      std::unique(bend_coordinates.begin(), bend_coordinates.end(), [](double left, double right) {
        return std::abs(left - right) <= 1e-5;
      }),
      bend_coordinates.end());
  if (bend_coordinates.size() < 3) {
    return std::nullopt;
  }

  double min_bend_spacing = std::numeric_limits<double>::max();
  for (std::size_t index = 1; index < bend_coordinates.size(); ++index) {
    min_bend_spacing = std::min(min_bend_spacing, bend_coordinates[index] - bend_coordinates[index - 1]);
  }
  const double bend_clearance = std::max(2.0, min_bend_spacing * 0.15);

  std::vector<double> breakpoints;
  breakpoints.reserve((cut_segments.size() * 2) + bend_coordinates.size() + 2);
  breakpoints.push_back(min_t);
  breakpoints.push_back(max_t);
  for (const auto& segment : cut_segments) {
    breakpoints.push_back(segment.start.x);
    breakpoints.push_back(segment.end.x);
  }
  breakpoints.insert(breakpoints.end(), bend_coordinates.begin(), bend_coordinates.end());
  std::sort(breakpoints.begin(), breakpoints.end());
  breakpoints.erase(
      std::unique(breakpoints.begin(), breakpoints.end(), [](double left, double right) {
        return std::abs(left - right) <= 1e-5;
      }),
      breakpoints.end());

  std::vector<double> endpoint_coordinates;
  endpoint_coordinates.reserve(cut_segments.size() * 2);
  for (const auto& segment : cut_segments) {
    endpoint_coordinates.push_back(segment.start.x);
    endpoint_coordinates.push_back(segment.end.x);
  }

  std::optional<double> best_cut;
  double best_score = -std::numeric_limits<double>::max();
  for (std::size_t index = 1; index < breakpoints.size(); ++index) {
    const double left = breakpoints[index - 1];
    const double right = breakpoints[index];
    if ((right - left) <= 1e-4) {
      continue;
    }
    const double candidate = (left + right) / 2.0;

    bool too_close_to_bend = false;
    double nearest_bend = std::numeric_limits<double>::max();
    for (const double bend_coordinate : bend_coordinates) {
      const double distance = std::abs(candidate - bend_coordinate);
      nearest_bend = std::min(nearest_bend, distance);
      if (distance < bend_clearance) {
        too_close_to_bend = true;
        break;
      }
    }
    if (too_close_to_bend) {
      continue;
    }

    std::set<long long> intersections;
    bool blocked_by_collinear_cut = false;
    for (const auto& segment : cut_segments) {
      const double t0 = segment.start.x;
      const double t1 = segment.end.x;
      if (std::abs(t1 - t0) <= 1e-6) {
        if (std::abs(candidate - t0) <= 1e-4) {
          blocked_by_collinear_cut = true;
          break;
        }
        continue;
      }
      const double min_segment_t = std::min(t0, t1);
      const double max_segment_t = std::max(t0, t1);
      if (candidate <= min_segment_t + 1e-6 || candidate >= max_segment_t - 1e-6) {
        continue;
      }
      const double alpha = (candidate - t0) / (t1 - t0);
      const double s = segment.start.y + (alpha * (segment.end.y - segment.start.y));
      intersections.insert(static_cast<long long>(std::llround(s * 1000000.0)));
    }
    if (blocked_by_collinear_cut || intersections.size() != 2) {
      continue;
    }

    double nearest_endpoint = std::numeric_limits<double>::max();
    for (const double endpoint : endpoint_coordinates) {
      nearest_endpoint = std::min(nearest_endpoint, std::abs(candidate - endpoint));
    }
    const double score = (nearest_bend * 2.0) + nearest_endpoint;
    if (!best_cut.has_value() || score > best_score) {
      best_cut = candidate;
      best_score = score;
    }
  }

  return best_cut;
}

void RepositionClosedSectionSeam(
    std::vector<Segment2>& cut_segments,
    std::vector<Segment2>& bend_segments) {
  Point2 along{};
  Point2 across{};
  if (!TryBuildClosedSectionBasis(bend_segments, along, across)) {
    return;
  }
  if (cut_segments.empty()) {
    return;
  }

  const Point2 origin = cut_segments.front().start;

  std::vector<LocalSegment> local_cut_segments;
  local_cut_segments.reserve(cut_segments.size());
  std::vector<LocalSegment> local_bend_segments;
  local_bend_segments.reserve(bend_segments.size());
  double min_t = std::numeric_limits<double>::max();
  double max_t = -std::numeric_limits<double>::max();
  for (const auto& segment : cut_segments) {
    const Point2 start = ToLocalBasis(segment.start, origin, across, along);
    const Point2 end = ToLocalBasis(segment.end, origin, across, along);
    min_t = std::min(min_t, std::min(start.x, end.x));
    max_t = std::max(max_t, std::max(start.x, end.x));
    local_cut_segments.push_back(LocalSegment{
        .start = start,
        .end = end,
    });
  }
  for (const auto& segment : bend_segments) {
    local_bend_segments.push_back(LocalSegment{
        .start = ToLocalBasis(segment.start, origin, across, along),
        .end = ToLocalBasis(segment.end, origin, across, along),
    });
  }

  const std::optional<double> cut_coordinate =
      SelectClosedSectionCutCoordinate(local_cut_segments, local_bend_segments, min_t, max_t);
  if (!cut_coordinate.has_value()) {
    return;
  }
  const double span = max_t - min_t;
  if (span <= 1e-6) {
    return;
  }

  const auto wrap_t = [&](double value) {
    double wrapped = value - *cut_coordinate;
    while (wrapped < 0.0) {
      wrapped += span;
    }
    while (wrapped > span) {
      wrapped -= span;
    }
    return wrapped + min_t;
  };

  std::vector<Segment2> remapped_cut_segments;
  remapped_cut_segments.reserve(cut_segments.size() * 2);
  for (const auto& segment : local_cut_segments) {
    const double t0 = segment.start.x;
    const double t1 = segment.end.x;
    const double min_segment_t = std::min(t0, t1);
    const double max_segment_t = std::max(t0, t1);

    auto push_local_segment = [&](const Point2& start, const Point2& end) {
      const Point2 wrapped_start{wrap_t(start.x), start.y};
      const Point2 wrapped_end{wrap_t(end.x), end.y};
      remapped_cut_segments.push_back(Segment2{
          .start = FromLocalBasis(wrapped_start, origin, across, along),
          .end = FromLocalBasis(wrapped_end, origin, across, along),
      });
    };

    if (std::abs(t1 - t0) > 1e-6 && *cut_coordinate > min_segment_t + 1e-6 && *cut_coordinate < max_segment_t - 1e-6) {
      const double alpha = (*cut_coordinate - t0) / (t1 - t0);
      const double s = segment.start.y + (alpha * (segment.end.y - segment.start.y));
      const Point2 split_point{*cut_coordinate, s};
      push_local_segment(segment.start, split_point);
      push_local_segment(split_point, segment.end);
      continue;
    }
    push_local_segment(segment.start, segment.end);
  }

  std::vector<Segment2> remapped_bend_segments;
  remapped_bend_segments.reserve(bend_segments.size());
  for (const auto& segment : local_bend_segments) {
    const Point2 wrapped_start{wrap_t(segment.start.x), segment.start.y};
    const Point2 wrapped_end{wrap_t(segment.end.x), segment.end.y};
    remapped_bend_segments.push_back(Segment2{
        .start = FromLocalBasis(wrapped_start, origin, across, along),
        .end = FromLocalBasis(wrapped_end, origin, across, along),
    });
  }

  cut_segments = DeduplicateSegments(remapped_cut_segments);
  bend_segments = DeduplicateSegments(remapped_bend_segments);
}

std::string ToDxfString(double value) {
  std::ostringstream out;
  out.setf(std::ios::fixed);
  out.precision(6);
  out << value;
  return out.str();
}

const char* StepDebugComponentName() {
  return std::getenv("CADUNPACK_DEBUG_STEP_COMPONENT");
}

bool ShouldDebugComponent(const std::string& component_name) {
  const char* debug_component = StepDebugComponentName();
  return debug_component != nullptr && component_name == debug_component;
}

void DumpPatchDebug(const std::string& component_name, const std::vector<SheetPatch>& patches) {
  if (!ShouldDebugComponent(component_name)) {
    return;
  }
  std::cerr << "[cadunpack-step-debug] component=" << component_name << " patches=" << patches.size() << '\n';
  for (const auto& patch : patches) {
    std::cerr << "[cadunpack-step-debug] patch id=" << patch.patch_id
              << " type=" << (patch.type == PatchType::kPlane ? "plane" : "cylinder")
              << " area=" << patch.area
              << " seams=" << patch.seams.size()
              << " centroid=(" << patch.local_centroid.x << "," << patch.local_centroid.y << ")";
    if (patch.transform.resolved) {
      const Point2 global_centroid = Apply(patch.transform, patch.local_centroid);
      std::cerr << " global=(" << global_centroid.x << "," << global_centroid.y << ")";
    }
    std::cerr << '\n';
    const auto polygons = BuildPatchPolygons(patch);
    std::cerr << "[cadunpack-step-debug]  polygons=" << polygons.size() << '\n';
    for (const auto& polygon : polygons) {
      bg::model::box<BgPoint> box;
      bg::envelope(polygon, box);
      std::cerr << "[cadunpack-step-debug]   bbox=("
                << bg::get<bg::min_corner, 0>(box) << ","
                << bg::get<bg::min_corner, 1>(box) << ")-("
                << bg::get<bg::max_corner, 0>(box) << ","
                << bg::get<bg::max_corner, 1>(box) << ")"
                << " outer_points=" << polygon.outer().size()
                << '\n';
    }
    for (const auto& seam : patch.seams) {
      const Point2 seam_start = Apply(patch.transform, SeamLocalStartForPatch(patch, seam));
      const Point2 seam_end = Apply(patch.transform, SeamLocalEndForPatch(patch, seam));
      std::cerr << "[cadunpack-step-debug]  seam to=" << seam.neighbor_patch_id
                << " start=(" << seam_start.x << "," << seam_start.y << ")"
                << " end=(" << seam_end.x << "," << seam_end.y << ")"
                << " edge_ids=";
      for (std::size_t index = 0; index < seam.edge_ids.size(); ++index) {
        if (index > 0) {
          std::cerr << ',';
        }
        std::cerr << seam.edge_ids[index];
      }
      std::cerr << '\n';
    }
  }
}

std::string BuildDxf(const std::vector<Segment2>& cut_segments, const std::vector<Segment2>& bend_segments) {
  std::ostringstream out;
  out << "0\nSECTION\n2\nHEADER\n9\n$INSUNITS\n70\n4\n0\nENDSEC\n";
  out << "0\nSECTION\n2\nENTITIES\n";
  auto append_line = [&](const std::string& layer, const Segment2& segment) {
    out << "0\nLINE\n8\n" << layer << '\n';
    out << "10\n" << ToDxfString(segment.start.x) << "\n20\n" << ToDxfString(segment.start.y) << "\n30\n0.0\n";
    out << "11\n" << ToDxfString(segment.end.x) << "\n21\n" << ToDxfString(segment.end.y) << "\n31\n0.0\n";
  };
  for (const auto& segment : cut_segments) {
    append_line("CUT", segment);
  }
  for (const auto& segment : bend_segments) {
    append_line("BEND", segment);
  }
  out << "0\nENDSEC\n0\nEOF\n";
  return out.str();
}

void ResolveLocalCentroids(std::vector<SheetPatch>& patches, const std::vector<FaceInfo>& faces) {
  std::map<int, FaceInfo> face_lookup;
  for (const auto& face : faces) {
    face_lookup.emplace(face.face_index, face);
  }
  for (auto& patch : patches) {
    const FaceInfo& representative = face_lookup.at(patch.face_a_index);
    patch.local_centroid = MapToLocal(patch, representative.centroid);
  }
}

void ResolveTransforms(std::vector<SheetPatch>& patches) {
  if (patches.empty()) {
    return;
  }

  auto root_iterator = std::max_element(patches.begin(), patches.end(), [](const SheetPatch& left, const SheetPatch& right) {
    if (left.type != right.type) {
      return left.type != PatchType::kPlane;
    }
    return left.area < right.area;
  });

  root_iterator->transform.resolved = true;
  root_iterator->transform.translation = Point2{0.0, 0.0};

  std::map<int, std::size_t> patch_index_by_id;
  for (std::size_t index = 0; index < patches.size(); ++index) {
    patch_index_by_id.emplace(patches[index].patch_id, index);
  }

  std::queue<int> pending;
  pending.push(root_iterator->patch_id);
  while (!pending.empty()) {
    const int current_id = pending.front();
    pending.pop();
    SheetPatch& current = patches[patch_index_by_id.at(current_id)];
    const Point2 current_centroid = Apply(current.transform, current.local_centroid);

    for (const auto& seam : current.seams) {
      SheetPatch& neighbor = patches[patch_index_by_id.at(seam.neighbor_patch_id)];
      if (neighbor.transform.resolved) {
        continue;
      }
      const auto neighbor_seam_it = std::find_if(neighbor.seams.begin(), neighbor.seams.end(), [&](const SeamRecord& candidate) {
        return candidate.neighbor_patch_id == current.patch_id;
      });
      if (neighbor_seam_it == neighbor.seams.end()) {
        continue;
      }
      const Point2 parent_start = Apply(current.transform, SeamLocalStartForPatch(current, seam));
      const Point2 parent_end = Apply(current.transform, SeamLocalEndForPatch(current, seam));
      std::optional<double> desired_child_side;
      std::optional<Point2> desired_side_probe;
      const std::optional<OrientationProbe> orientation_probe =
          SelectOrientationProbe(neighbor, neighbor_seam_it->start, neighbor_seam_it->end);
      if (current.type == PatchType::kPlane && neighbor.type == PatchType::kCylinder) {
        desired_child_side =
            DesiredSideForPlaneToCylinderTransition(current, neighbor, seam, patch_index_by_id, patches);
        desired_side_probe = DesiredSideProbeForCylinderTransition(current, neighbor, patch_index_by_id, patches);
      } else if (current.type == PatchType::kCylinder && neighbor.type == PatchType::kPlane) {
        desired_child_side =
            DesiredSideForCylinderToPlaneTransition(current, neighbor, seam, patch_index_by_id, patches);
        desired_side_probe = ExtremeLocalPointFromSeam(
            neighbor,
            SeamLocalStartForPatch(neighbor, *neighbor_seam_it),
            SeamLocalEndForPatch(neighbor, *neighbor_seam_it));
      }
      neighbor.transform =
          AlignPatchTransform(parent_start,
                              parent_end,
                              SeamLocalStartForPatch(neighbor, *neighbor_seam_it),
                              SeamLocalEndForPatch(neighbor, *neighbor_seam_it),
                              current_centroid,
                              neighbor.local_centroid,
                              desired_child_side,
                              desired_side_probe,
                              orientation_probe);
      pending.push(neighbor.patch_id);
    }
  }

  const auto unresolved = std::find_if(patches.begin(), patches.end(), [](const SheetPatch& patch) {
    return !patch.transform.resolved;
  });
  if (unresolved != patches.end()) {
    throw std::runtime_error(
        "STEP exact flattening failed: the folded part contains unsupported or disconnected bend topology. The native unfold kernel could "
        "not resolve a continuous bend graph for this component.");
  }
}

UnfoldedComponent UnfoldComponent(const cadunpack::step::SourceComponent& component) {
  TopTools_IndexedMapOfShape face_map;
  TopExp::MapShapes(component.shape, TopAbs_FACE, face_map);
  std::vector<FaceInfo> faces;
  faces.reserve(face_map.Extent());
  for (int index = 1; index <= face_map.Extent(); ++index) {
    faces.push_back(BuildFaceInfo(TopoDS::Face(face_map(index)), index));
  }

  const std::string component_name = SanitizeName(
      component.summary.component_name.empty() ? component.summary.source_name : component.summary.component_name);

  const auto dominant_planar_pair = FindDominantPlanarSkinPair(faces);
  if (dominant_planar_pair.has_value() &&
      BuildCylinderCandidates(faces, dominant_planar_pair->thickness).empty()) {
    std::vector<SheetPatch> flat_patches{MakePlanePatch(
        1,
        faces[dominant_planar_pair->left_index],
        faces[dominant_planar_pair->right_index],
        dominant_planar_pair->thickness)};
    ResolvePlaneFrames(flat_patches);
    ResolveLocalCentroids(flat_patches, faces);
    flat_patches.front().transform.resolved = true;
    flat_patches.front().transform.translation = Point2{0.0, 0.0};

    const std::vector<Segment2> cut_segments = BuildCutSegmentsFromUnion(flat_patches);
    if (cut_segments.empty()) {
      throw std::runtime_error(
          "STEP exact flattening failed: no supported cut geometry was detected after extracting the flat component.");
    }

    return UnfoldedComponent{
        .component_id = component.summary.component_id,
        .source_name = component.summary.source_name,
        .component_name = component_name,
        .assembly_path = component.summary.assembly_path,
        .owning_node_id = component.summary.owning_node_id,
        .shape_kind = component.summary.shape_kind,
        .generated_dxf_file_name = component_name + ".dxf",
        .generated_dxf = BuildDxf(cut_segments, {}),
        .has_bends = false,
        .warnings = {},
    };
  }

  const auto thickness = DetectThickness(faces);
  if (!thickness.has_value()) {
    throw std::runtime_error(
        "STEP exact flattening failed: the component does not expose a consistent sheet thickness, so the native unfold kernel cannot "
        "derive a precise flat pattern.");
  }

  auto patches = BuildPatches(faces, *thickness);
  if (patches.empty()) {
    throw std::runtime_error(
        "STEP exact flattening failed: the component does not contain a supported planar/cylindrical sheet-metal surface graph.");
  }

  PopulateSeams(component.shape, patches, *thickness);
  ResolvePlaneFrames(patches);
  ResolveLocalCentroids(patches, faces);
  ResolveTransforms(patches);
  DumpPatchDebug(component_name, patches);

  std::vector<Segment2> cut_segments = BuildCutSegmentsFromUnion(patches);
  if (cut_segments.empty()) {
    throw std::runtime_error(
        "STEP exact flattening failed: no supported cut geometry was detected after unfolding the component.");
  }

  std::vector<Segment2> bend_segments = BuildBendLines(patches);
  if (IsSingleClosedSeamLoop(patches)) {
    std::vector<Segment2> original_cut = cut_segments;
    std::vector<Segment2> original_bend = bend_segments;

    RepositionClosedSectionSeam(cut_segments, bend_segments);

    const int original_dangling = CountDanglingVertices(original_cut);
    const int repositioned_dangling = CountDanglingVertices(cut_segments);
    const SegmentBounds original_bounds = ComputeSegmentBounds(original_cut);
    const SegmentBounds repositioned_bounds = ComputeSegmentBounds(cut_segments);
    const bool shrank_horizontally =
        BoundsSpanX(original_bounds) > 1e-6 &&
        BoundsSpanX(repositioned_bounds) < (BoundsSpanX(original_bounds) * 0.99);
    const bool shrank_vertically =
        BoundsSpanY(original_bounds) > 1e-6 &&
        BoundsSpanY(repositioned_bounds) < (BoundsSpanY(original_bounds) * 0.99);

    if (repositioned_dangling > original_dangling || shrank_horizontally || shrank_vertically) {
      cut_segments = std::move(original_cut);
      bend_segments = std::move(original_bend);
    }
  }
  cut_segments = DeduplicateSegments(SplitSegmentsAtIntersections(cut_segments));
  if (IsSingleClosedSeamLoop(patches)) {
    std::vector<Point2> dangling = CollectDanglingPoints(cut_segments);
    if (dangling.size() == 2 && Length(dangling[0] - dangling[1]) > 1e-6) {
      cut_segments.push_back(Segment2{
          .start = dangling[0],
          .end = dangling[1],
      });
      cut_segments = DeduplicateSegments(cut_segments);
    }
  }
  return UnfoldedComponent{
      .component_id = component.summary.component_id,
      .source_name = component.summary.source_name,
      .component_name = component_name,
      .assembly_path = component.summary.assembly_path,
      .owning_node_id = component.summary.owning_node_id,
      .shape_kind = component.summary.shape_kind,
      .generated_dxf_file_name = component_name + ".dxf",
      .generated_dxf = BuildDxf(cut_segments, bend_segments),
      .has_bends = !bend_segments.empty(),
      .warnings = {},
  };
}

}  // namespace

std::vector<UnfoldedComponent> SheetMetalUnfolder::unfold(
    const std::string& file_name,
    const std::vector<cadunpack::step::SourceComponent>& components) const {
  (void)file_name;
  if (components.empty()) {
    throw std::runtime_error("STEP exact flattening failed: the STEP file does not contain any unfoldable components.");
  }

  std::vector<UnfoldedComponent> results;
  results.reserve(components.size());
  for (const auto& component : components) {
    results.push_back(UnfoldComponent(component));
  }
  return results;
}

}  // namespace cadunpack::unfold
