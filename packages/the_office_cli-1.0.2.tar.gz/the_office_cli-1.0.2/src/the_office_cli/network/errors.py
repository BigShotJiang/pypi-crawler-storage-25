# *[opens the filing cabinet, pulls a blank form]*

"""
errors.py — The call dropped.

HTTP errors come in messy. This module gives them
structure — a code, a retry hint, and an exit code —
so agents know what to do next.
"""

import httpx

from the_office_cli.utils.output import EXIT_ERROR, EXIT_RATE_LIMITED

class ApiError(Exception):
    """A filed incident. Code says what happened, retry
    says whether to try again."""

    def __init__(
        self,
        code: str,
        message: str,
        retry: bool = False,
        retry_after: int | None = None,
        exit_code: int = EXIT_ERROR,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.retry = retry
        self.retry_after = retry_after
        self.exit_code = exit_code

_HTTP_TO_ERROR: dict[int, tuple[str, bool, int]] = {
    400: ("INVALID_INPUT", False, EXIT_ERROR),
    401: ("AUTH_EXPIRED", False, EXIT_ERROR),
    403: ("FORBIDDEN", False, EXIT_ERROR),
    404: ("NOT_FOUND", False, EXIT_ERROR),
    409: ("CONFLICT", False, EXIT_ERROR),
    422: ("VALIDATION_ERROR", False, EXIT_ERROR),
    429: ("RATE_LIMIT", True, EXIT_RATE_LIMITED),
}

ERROR_CODES = [
    "AUTH_EXPIRED",
    "CONFIRMATION_REQUIRED",
    "FORBIDDEN",
    "NOT_FOUND",
    "CONFLICT",
    "RATE_LIMIT",
    "INVALID_INPUT",
    "NOTE_TOO_LONG",
    "VALIDATION_ERROR",
    "SERVER_ERROR",
    "UNKNOWN_ERROR",
]

def raise_from_http(exc: httpx.HTTPStatusError) -> None:
    """Read the HTTP status, fill out the report, and
    file it for next time."""
    status = exc.response.status_code

    try:
        body = exc.response.json()
        message = body.get("message") or body.get("error") or str(exc)
    except Exception:
        message = str(exc)

    code, retry, exit_code = _HTTP_TO_ERROR.get(
        status, ("SERVER_ERROR", status >= 500, EXIT_ERROR)
    )

    retry_after: int | None = None
    if status == 429:
        ra = exc.response.headers.get("Retry-After")
        if ra and ra.isdigit():
            retry_after = int(ra)

    raise ApiError(
        code, message, retry=retry, retry_after=retry_after, exit_code=exit_code
    )

# Cabinet closed.
