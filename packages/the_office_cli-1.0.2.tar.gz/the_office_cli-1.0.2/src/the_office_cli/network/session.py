# *[picks up the handset, dials, waits for the tone]*

"""
session.py — The phone line.

Every API call dials out through here. Handles the auth
header, the idempotency key, and hangs up cleanly when
the other side sends an error.
"""

import json
import sys

import httpx

from the_office_cli.config import get_api_url, get_token
from the_office_cli.network.errors import raise_from_http


_idempotency_key: str | None = None

def set_idempotency_key(key: str | None) -> None:
    """Tag the next call with a retry key — same key,
    same result, no double-dials."""
    global _idempotency_key
    _idempotency_key = key

def _headers() -> dict[str, str]:
    """Prep the call — auth token, content type, retry key."""
    h = {"Content-Type": "application/json"}
    token = get_token()
    if token:
        h["Authorization"] = f"Bearer {token}"
    if _idempotency_key:
        h["Idempotency-Key"] = _idempotency_key
    return h

def _url(path: str) -> str:
    """Dial the full number from the base URL and path."""
    return f"{get_api_url()}{path}"

def _request(method: str, path: str, **kwargs) -> dict | list:
    """Place the call. If the other side hangs up angry,
    file the error."""
    try:
        r = httpx.request(method, _url(path), headers=_headers(), timeout=3600, **kwargs)
        r.raise_for_status()
        return r.json()
    except httpx.HTTPStatusError as e:
        raise_from_http(e)

def get(path: str, params: dict | None = None) -> dict | list:
    """Make the call and return what they said."""
    return _request("GET", path, params=params)

def post(path: str, body: dict | list | None = None, params: dict | None = None) -> dict:
    """Send the pitch and return the response."""
    return _request("POST", path, json=body, params=params)

def put(path: str, body: dict | None = None) -> dict:
    """Update the deal and return the new terms."""
    return _request("PUT", path, json=body)

def delete(path: str) -> dict:
    """Cancel the account and return the confirmation."""
    return _request("DELETE", path)

def input_stdin() -> dict | list | None:
    """Listen for JSON on stdin. Silence means nothing to read."""
    if sys.stdin.isatty():
        return None
    raw = sys.stdin.read().strip()
    if not raw:
        return None
    return json.loads(raw)

# Line disconnected.
