# *[taps badge on the desk, squints at the visitor list]*

"""
config.py — Hank's desk at the front door.

Two files live in ~/.the-office/ — the API address and
the JWT session. Nobody gets past here without them.
"""

import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".the-office"
CONFIG_FILE = CONFIG_DIR / "config.json"
SESSION_FILE = CONFIG_DIR / "session.json"

def get_api_url() -> str:
    """Check the building directory for where to send the call."""
    if CONFIG_FILE.exists():
        config = json.loads(CONFIG_FILE.read_text())
        return config.get("api_url", "http://localhost:5001")
    return "http://localhost:5001"

def get_token() -> str | None:
    """Look for a valid badge in the session file. No badge,
    no entry."""
    if SESSION_FILE.exists():
        session = json.loads(SESSION_FILE.read_text())
        return session.get("token")
    return None

def save_session(data: dict) -> None:
    """Print a new badge and file it in ~/.the-office/."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    SESSION_FILE.write_text(json.dumps(data, indent=2))

def clear_session() -> None:
    """Shred the badge. You're logged out."""
    if SESSION_FILE.exists():
        SESSION_FILE.unlink()

# Hank never leaves the desk.
