# *[walks through the front door, flips the lights on]*

"""
main.py — Dunder Mifflin, this is Pam.

Front door of the CLI. Routes to cli/main.py where the
real work happens.
"""

from the_office_cli.cli.main import cli


def main() -> None:
    """Answer the phone and transfer the call."""
    cli()


if __name__ == "__main__":
    main()

# Branch is open.
