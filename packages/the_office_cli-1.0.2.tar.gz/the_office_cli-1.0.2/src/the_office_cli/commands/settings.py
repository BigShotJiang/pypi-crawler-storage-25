# *[adjusts the monitor, moves the stapler]*

"""
settings.py — Your desk, your rules.

Name, email, company info, and outreach schedule —
read your settings or update them.
"""

from the_office_cli.cli.decorators import command
from the_office_cli.network.session import get, put

@command(
    name="get",
    full_name="settings",
    description="Use this command to get the user's settings.",
    schema={
        "endpoint": "/settings", "method": "GET",
        "input": {},
        "output": {
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "email": {"type": "string", "format": "email"},
            "role": {"type": "string"},
            "customer_id": {"type": "integer"},
            "company_name": {"type": "string"},
            "company_website": {"type": "string", "format": "uri"},
            "outreach_schedule": {
                "type": "object",
                "properties": {
                    "hour": {"type": "integer", "minimum": 0, "maximum": 23},
                    "days": {"type": "array", "items": {"type": "integer", "minimum": 0, "maximum": 6}},
                },
            },
        },
        "example": {
            "input": {},
            "output": {
                "first_name": "Michael",
                "last_name": "Scott",
                "email": "michael@dundermifflin.com",
                "role": "Regional Manager",
                "customer_id": 1,
                "company_name": "Dunder Mifflin",
                "company_website": "https://dundermifflin.com",
                "outreach_schedule": {"hour": 10, "days": [1, 2, 3, 4, 5]},
            },
        },
    },
)
def get_(**_):
    return {"object": "Settings", **get("/settings")}

@command(
    name="update",
    full_name="settings update",
    description="Use this command to edit the user's settings.",
    schema={
        "endpoint": "/settings", "method": "PUT",
        "input": {
            "body": {
                "first_name": {"type": "string"},
                "last_name": {"type": "string"},
                "email": {"type": "string", "format": "email"},
                "role": {"type": "string"},
                "company_name": {"type": "string"},
                "company_website": {"type": "string", "format": "uri"},
                "outreach_schedule": {
                "type": "object",
                "properties": {
                    "hour": {"type": "integer", "minimum": 0, "maximum": 23},
                    "days": {"type": "array", "items": {"type": "integer", "minimum": 0, "maximum": 6}},
                },
            },
            },
        },
        "output": {
            "message": {"type": "string"},
        },
        "example": {
            "input": {
                "body": {
                    "first_name": "Michael",
                    "last_name": "Scott",
                    "email": "michael@dundermifflin.com",
                    "role": "Regional Manager",
                    "company_name": "Dunder Mifflin",
                    "company_website": "https://dundermifflin.com",
                    "outreach_schedule": {"hour": 9, "days": [1, 2, 3, 4, 5]},
                },
            },
            "output": {"message": "Settings updated"},
        },
    },
    input_stdin=True,
    stdin_error="Pipe settings JSON to stdin",
)
def update(_body, **_):
    return {"object": "Settings", **put("/settings", _body)}

# Desk set.
