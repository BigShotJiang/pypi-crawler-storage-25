# *[slides the welcome packet across the desk]*

"""
info.py — The welcome packet.

Everything a new agent needs — `tour` for the full
command menu, `completion` for shell tab-completion.
"""

import json
import sys

import click

from the_office_cli.cli.decorators import command
from the_office_cli.utils.registry import get_registry
from the_office_cli.utils.schema import SCHEMA_VERSION, build_tour_schema

@command(
    name="tour",
    full_name="tour",
    description="Use this command to list every available command with its name, description, and endpoint. Prefer `<command> --schema` for the full JSON input/output and an example of any individual command.",
    schema={
        "endpoint": "local://registry",
        "method": "GET",
        "input": {},
        "output": {
            "version": {"type": "string"},
            "commands": {"type": "integer"},
            "schemas": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "group": {"type": "string"},
                        "command": {"type": "string"},
                        "description": {"type": "string"},
                        "endpoint": {
                            "type": "object",
                            "properties": {
                                "path": {"type": "string"},
                                "method": {"type": "string"},
                            },
                        },
                    },
                },
            },
        },
        "example": {
            "input": {},
            "output": {
                "version": SCHEMA_VERSION,
                "commands": 59,
                "schemas": [{"group": "campaign", "command": "campaign list", "description": "...", "endpoint": {"path": "/campaigns", "method": "GET"}}],
            },
        },
    },
)
def tour(**_):
    registry = get_registry()
    return {
        "object": "Tour",
        "version": SCHEMA_VERSION,
        "commands": len(registry),
        "schemas": [build_tour_schema(cfg) for cfg in registry],
    }

@click.command()
@click.argument("shell", type=click.Choice(["bash", "zsh", "fish"]))
def completion(shell: str) -> None:
    """Print shell completion script. Usage: eval \"$(the-office completion zsh)\""""
    from click.shell_completion import get_completion_class

    completion_class = get_completion_class(shell)
    if completion_class is None:
        click.echo(f"Unsupported shell: {shell}", err=True)
        sys.exit(1)
    # cli is imported late to avoid circular imports
    from the_office_cli.cli.main import cli

    comp = completion_class(cli, {}, "the-office", "_THE_OFFICE_COMPLETE")
    click.echo(comp.source())

# Packet delivered.
