# *[swipes the badge, pushes through the turnstile]*

"""
auth.py — Clocking in.

Log in, log out, check who you are, create a new
account, or run a fire drill to make sure everything's
connected.
"""

import click

from the_office_cli.cli.decorators import command
from the_office_cli.config import clear_session, get_api_url, get_token, save_session
from the_office_cli.network.session import get, post

@command(
    name="login",
    full_name="login",
    description="Use this command to log in with email and password.",
    schema={
        "endpoint": "/login",
        "method": "POST",
        "input": {
            "body": {
                "email": {"type": "string", "format": "email", "required": True},
                "password": {"type": "string", "required": True},
            },
        },
        "output": {
            "email": {"type": "string", "format": "email"},
            "message": {"type": "string"},
        },
        "example": {
            "input": {
                "body": {
                    "email": "michael@dundermifflin.com",
                    "password": "thatsWhatSheSaid2026",
                },
            },
            "output": {
                "email": "michael@dundermifflin.com",
                "message": "Logged in",
            },
        },
    },
)
@click.option("--email", required=True)
@click.option("--password", required=True, hide_input=True)
def login(email, password, **_):
    data = post("/login", {"email": email, "password": password})
    save_session({"token": data["token"], "email": email})
    return {"object": "Session", "email": email, "message": "Logged in"}

@command(
    name="logout",
    full_name="logout",
    description="Use this command to log out.",
    schema={
        "endpoint": "local://session",
        "method": "GET",
        "input": {},
        "output": {
            "message": {"type": "string"},
        },
        "example": {
            "input": {},
            "output": {"message": "Logged out"},
        },
    },
)
def logout(**_):
    clear_session()
    return {"object": "Session", "message": "Logged out"}

@command(
    name="whoami",
    full_name="whoami",
    description="Use this command to check the user's info and LinkedIn connection status.",
    schema={
        "endpoint": "/settings + /connect-with-linkedin/status",
        "method": "GET",
        "input": {},
        "output": {
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "email": {"type": "string", "format": "email"},
            "role": {"type": "string"},
            "customer_id": {"type": "integer"},
            "company_name": {"type": "string"},
            "api_url": {"type": "string", "format": "uri", "source": "local config"},
            "linkedin_connected": {"type": "boolean"},
        },
        "example": {
            "input": {},
            "output": {
                "first_name": "Michael",
                "last_name": "Scott",
                "email": "michael@dundermifflin.com",
                "role": "admin",
                "customer_id": 1,
                "company_name": "Dunder Mifflin",
                "api_url": "https://api.theoffice.com",
                "linkedin_connected": True,
            },
        },
    },
)
def whoami(**_):
    settings = get("/settings")

    linkedin_connected = False
    try:
        get("/connect-with-linkedin/status")
        linkedin_connected = True
    except Exception:
        pass

    return {
        "object": "Identity",
        "first_name": settings.get("first_name"),
        "last_name": settings.get("last_name"),
        "email": settings.get("email"),
        "role": settings.get("role"),
        "customer_id": settings.get("customer_id"),
        "company_name": settings.get("company_name"),
        "api_url": get_api_url(),
        "linkedin_connected": linkedin_connected,
    }

@command(
    name="create-account",
    full_name="create-account",
    description="Use this command to create a new account. First, the user provides email and password. Second, the user provides company name and website. If an organization with the same name and website exists, the user joins it instead. Prefer `login` when the user already has an account.",
    schema={
        "endpoint": "/customers",
        "method": "POST",
        "input": {
            "body": {
                "name": {"type": "string", "required": True},
                "website": {"type": "string", "format": "uri", "required": True},
                "email": {"type": "string", "format": "email", "required": True},
                "password": {"type": "string", "required": True},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "message": {"type": "string"},
        },
        "example": {
            "input": {
                "body": {
                    "name": "Dunder Mifflin",
                    "website": "dundermifflin.com",
                    "email": "michael@dundermifflin.com",
                    "password": "thatsWhatSheSaid2026",
                },
            },
            "output": {
                "id": 1,
                "message": "Account created",
            },
        },
    },
)
@click.option("--company-name", "name", required=True)
@click.option("--website", required=True)
@click.option("--email", required=True)
@click.option("--password", required=True, hide_input=True)
def create_account(name, website, email, password, **_):
    data = post("/customers", {
        "name": name,
        "website": website,
        "email": email,
        "password": password,
    })
    save_session({"token": data["token"], "email": email})
    return {"object": "Account", "id": data.get("id"), "message": "Account created"}

@command(
    name="fire-drill",
    full_name="fire-drill",
    description="Use this command to check if API, auth, and LinkedIn are connected.",
    schema={
        "endpoint": "/health_check",
        "method": "GET",
        "input": {},
        "output": {
            "checks": {
                "type": "object",
                "properties": {
                    "api": {"type": "boolean"},
                    "auth": {"type": "boolean"},
                    "linkedin": {"type": "boolean"},
                },
            },
            "hint": {"type": "string"},
        },
        "example": {
            "input": {},
            "output": {
                "checks": {
                    "api": True,
                    "auth": True,
                    "linkedin": True,
                },
                "hint": None,
            },
        },
    },
)
def fire_drill(**_):
    import httpx

    checks = {"api": False, "auth": False, "linkedin": False}
    api_url = get_api_url()

    try:
        r = httpx.get(f"{api_url}/health_check", timeout=5)
        checks["api"] = r.status_code == 200
    except Exception:
        pass

    token = get_token()
    if token and checks["api"]:
        try:
            r = httpx.get(
                f"{api_url}/settings",
                headers={"Authorization": f"Bearer {token}"},
                timeout=5,
            )
            checks["auth"] = r.status_code == 200
        except Exception:
            pass

    if checks["auth"]:
        try:
            r = httpx.get(
                f"{api_url}/connect-with-linkedin/status",
                headers={"Authorization": f"Bearer {token}"},
                timeout=5,
            )
            checks["linkedin"] = r.status_code == 200
        except Exception:
            pass

    all_ok = all(checks.values())
    return {
        "object": "FireDrill",
        "checks": checks,
        "hint": None
        if all_ok
        else (
            f"API unreachable at {api_url}"
            if not checks["api"]
            else "Run: the-office login"
            if not checks["auth"]
            else "Run: the-office linkedin connect account"
        ),
    }

# Shift's over.
