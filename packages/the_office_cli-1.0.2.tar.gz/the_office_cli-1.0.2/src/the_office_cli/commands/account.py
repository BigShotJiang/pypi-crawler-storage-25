# *[highlights a company name on the whiteboard]*

"""
account.py — The target accounts.

The companies your signals campaigns are watching.
List them, add one, edit, import a batch, or remove
them from the board.
"""

import json
import sys

import click

from the_office_cli.cli.decorators import command
from the_office_cli.network.session import delete, get, post, put
from the_office_cli.utils.output import error_stderr

@command(
    name="list",
    description="Use this command to list target accounts in a signals campaign with `--campaign`, or all target accounts in all campaigns with `--all`. One of `--campaign` or `--all` is required. Prefer `lead list` when the user wants leads instead of accounts.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/accounts OR /all_accounts", "method": "GET",
        "input": {
            "path": {
                "campaign_id": {"type": "integer"},
            },
            "query": {
                "page": {"type": "integer", "default": 1},
                "per_page": {"type": "integer", "default": 10},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "campaign_id": {"type": "integer"},
            "campaign": {"type": "string"},
            "website": {"type": "string", "format": "uri"},
            "company_name": {"type": "string"},
            "logo": {"type": "string", "format": "uri"},
            "description": {"type": "string"},
            "days_back": {"type": "integer"},
            "response": {"type": "string"},
            "citations": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "format": "uri"},
                        "title": {"type": "string"},
                    },
                },
            },
            "response_summary": {"type": "string"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 6,
                },
                "query": {
                    "page": 1,
                    "per_page": 10,
                },
            },
            "output": {
                "id": 1,
                "campaign_id": 6,
                "campaign": "Vance Refrigeration Takedown",
                "website": "https://vancerefrigeration.com",
                "company_name": "Vance Refrigeration",
                "logo": "https://logo.clearbit.com/vancerefrigeration.com",
                "description": "Bob Vance, Vance Refrigeration. They keep things cold.",
                "days_back": 365,
                "response": "Vance Refrigeration is a regional commercial HVAC supplier based in Scranton, PA...",
                "citations": [
                    {"url": "https://vancerefrigeration.com/about", "title": "About Vance Refrigeration"},
                ],
                "response_summary": "Regional supplier, 50 employees, expanding to Wilkes-Barre.",
                "created_at": "2026-03-15T09:00:00+00:00",
                "updated_at": "2026-04-08T11:30:00+00:00",
            },
        },
    },
)
@click.option("--campaign", "campaign_id", type=click.INT, help="Scope to one campaign")
@click.option("--all", "all_", is_flag=True, help="List every account across all campaigns")
@click.option("--page", type=click.INT, default=1, help="Page number (default: 1)")
@click.option("--per-page", "per_page", type=click.INT, default=10, help="Results per page (default: 10)")
def list_(campaign_id, all_, page, per_page, **_):
    if not campaign_id and not all_:
        error_stderr("INVALID_INPUT", "Pass --campaign <id> or --all")
    if campaign_id and all_:
        error_stderr("INVALID_INPUT", "Pass either --campaign or --all, not both")
    params = {"page": page, "per_page": per_page}
    if campaign_id:
        return {
            "object": "AccountList",
            "items": get(f"/campaigns/{campaign_id}/accounts", params=params),
        }
    return {
        "object": "AccountList",
        "items": get("/all_accounts", params=params),
    }

@command(
    name="get",
    description="Use this command to get a target account in a campaign and its buying signals with findings, citations, and confidence levels.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/accounts/<id>", "method": "GET",
        "input": {
            "path": {
                "campaign_id": {"type": "integer", "required": True},
                "id": {"type": "integer", "required": True},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "campaign_id": {"type": "integer"},
            "website": {"type": "string", "format": "uri"},
            "company_name": {"type": "string"},
            "logo": {"type": "string", "format": "uri"},
            "description": {"type": "string"},
            "days_back": {"type": "integer"},
            "response": {"type": "string"},
            "citations": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "format": "uri"},
                        "title": {"type": "string"},
                    },
                },
            },
            "response_gemini": {"type": "string"},
            "citations_gemini": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "format": "uri"},
                        "title": {"type": "string"},
                    },
                },
            },
            "response_summary": {"type": "string"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 6,
                    "id": 1,
                },
            },
            "output": {
                "id": 1,
                "campaign_id": 6,
                "website": "https://vancerefrigeration.com",
                "company_name": "Vance Refrigeration",
                "logo": "https://logo.clearbit.com/vancerefrigeration.com",
                "description": "Bob Vance, Vance Refrigeration. They keep things cold. We keep things personal.",
                "days_back": 365,
                "response": "Vance Refrigeration is a regional commercial HVAC supplier...",
                "citations": [
                    {"url": "https://vancerefrigeration.com/about", "title": "About"},
                ],
                "response_gemini": "Based on recent data, Vance Refrigeration has been expanding operations...",
                "citations_gemini": [
                    {"url": "https://scrantontimes.com/business/vance-expansion", "title": "Vance announces Wilkes-Barre warehouse"},
                ],
                "response_summary": "Bob Vance runs a tight ship. 50 employees, growing 12% YoY.",
                "created_at": "2026-03-15T09:00:00+00:00",
                "updated_at": "2026-04-08T11:30:00+00:00",
            },
        },
    },
)
@click.option("--campaign", "campaign_id", type=click.INT, required=True, help="Campaign ID the account belongs to")
@click.option("--id", type=click.INT, required=True)
def get_(campaign_id, id, **_):
    return {"object": "Account", **get(f"/campaigns/{campaign_id}/accounts/{id}")}

@command(
    name="create",
    description="Use this command to create a single target account in a signals campaign. Prefer `account import` when adding accounts in a batch to a campaign.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/accounts", "method": "POST",
        "input": {
            "path": {
                "campaign_id": {"type": "integer", "required": True},
            },
            "body": {
                "website": {"type": "string", "format": "uri", "required": True},
                "company_name": {"type": "string"},
                "description": {"type": "string"},
                "logo": {"type": "string", "format": "uri"},
                "days_back": {"type": "integer", "default": 365},
            },
        },
        "output": {
            "message": {"type": "string"},
            "id": {"type": "integer"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 6,
                },
                "body": {
                    "website": "https://vancerefrigeration.com",
                    "company_name": "Vance Refrigeration",
                    "description": "Bob Vance, Vance Refrigeration.",
                    "logo": "https://logo.clearbit.com/vancerefrigeration.com",
                    "days_back": 365,
                },
            },
            "output": {
                "message": "Account created successfully!",
                "id": 7,
            },
        },
    },
    input_stdin=True,
    stdin_error="Pipe account JSON to stdin",
)
@click.option(
    "--campaign", "campaign_id", type=click.INT,
    callback=lambda ctx, _p, v: v if ctx.resilient_parsing or v is not None else error_stderr(
        "INVALID_INPUT",
        "Accounts live inside a signals campaign. Pass an existing campaign id with --campaign, or create one with `the-office campaign create signals`.",
    ),
)
def create(campaign_id, _body, **_):
    return {"object": "Account", **post(f"/campaigns/{campaign_id}/accounts", _body)}

@command(
    name="update",
    description="Use this command to edit a target account in a campaign.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/accounts/<id>", "method": "PUT",
        "input": {
            "path": {
                "campaign_id": {"type": "integer", "required": True},
                "id": {"type": "integer", "required": True},
            },
            "body": {
                "website": {"type": "string", "format": "uri"},
                "company_name": {"type": "string"},
                "description": {"type": "string"},
                "logo": {"type": "string", "format": "uri"},
                "days_back": {"type": "integer"},
            },
        },
        "output": {
            "message": {"type": "string"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 6,
                    "id": 1,
                },
                "body": {
                    "website": "https://vancerefrigeration.com",
                    "company_name": "Vance Refrigeration",
                    "description": "Bob Vance — expanding to Wilkes-Barre.",
                    "logo": "https://logo.clearbit.com/vancerefrigeration.com",
                    "days_back": 180,
                },
            },
            "output": {"message": "Account updated successfully!"},
        },
    },
    input_stdin=True,
    stdin_error="Pipe JSON to stdin",
)
@click.option("--campaign", "campaign_id", type=click.INT, required=True, help="Campaign ID the account belongs to")
@click.option("--id", type=click.INT, required=True)
def update(campaign_id, id, _body, **_):
    return {"object": "Account", **put(f"/campaigns/{campaign_id}/accounts/{id}", _body)}

@command(
    name="delete",
    description="Use this command to permanently delete a target account from a campaign.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/accounts/<id>", "method": "DELETE",
        "input": {
            "path": {
                "campaign_id": {"type": "integer", "required": True},
                "id": {"type": "integer", "required": True},
            },
        },
        "output": {
            "message": {"type": "string"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 6,
                    "id": 2,
                },
            },
            "output": {"message": "Account deleted successfully!"},
        },
    },
)
@click.option("--campaign", "campaign_id", type=click.INT, required=True, help="Campaign ID the account belongs to")
@click.option("--id", type=click.INT, required=True)
def delete_(campaign_id, id, **_):
    return {"object": "Account", **delete(f"/campaigns/{campaign_id}/accounts/{id}")}

@command(
    name="import",
    full_name="account import",
    description="Use this command to upload target accounts in a batch to a signals campaign. Prefer `account create` when adding a single account to a campaign.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/accounts/bulk_insert", "method": "POST",
        "input": {
            "path": {
                "campaign_id": {"type": "integer", "required": True},
            },
            "body": {
                "website": {"type": "string", "format": "uri", "required": True},
                "company_name": {"type": "string"},
                "description": {"type": "string"},
                "logo": {"type": "string", "format": "uri"},
                "days_back": {"type": "integer", "default": 365},
            },
        },
        "output": {
            "message": {"type": "string"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 6,
                },
                "body": {
                    "website": "https://lackawannaprinting.com",
                    "company_name": "Lackawanna Printing",
                    "description": "Family-owned commercial printer, 30 years in Scranton.",
                    "logo": "https://logo.clearbit.com/lackawannaprinting.com",
                    "days_back": 365,
                },
            },
            "output": {"message": "Accounts created successfully!"},
        },
    },
)
@click.option(
    "--campaign", "campaign_id", type=click.INT,
    callback=lambda ctx, _p, v: v if ctx.resilient_parsing or v is not None else error_stderr(
        "INVALID_INPUT",
        "Accounts live inside a signals campaign. Pass an existing campaign id with --campaign, or create one with `the-office campaign create signals`.",
    ),
)
@click.option("--input", "input_file", help="JSONL file path (or pipe via stdin)")
def batch_create(campaign_id, input_file, **_):
    if input_file:
        with open(input_file) as f:
            lines = [ln.strip() for ln in f if ln.strip()]
    else:
        lines = [ln.strip() for ln in sys.stdin if ln.strip()]

    items = [json.loads(ln) for ln in lines]
    if not items:
        error_stderr("INVALID_INPUT", "No items provided")
    for item in items:
        if not item.get("website"):
            error_stderr("INVALID_INPUT", "Each item requires 'website' field")

    result = post(f"/campaigns/{campaign_id}/accounts/bulk_insert", items)
    return {"object": "BatchResult", **result, "total": len(items)}

# Accounts reviewed.
