# *[pins a new play to the board]*

"""
campaign.py — The sales plays.

Each campaign is a play — who to target, what to say,
and when to follow up. Create, update, pause, or close
them. Custom sequences, AI outreach, or signal triggers.
"""

import click

from the_office_cli.cli.decorators import command
from the_office_cli.network.session import delete, get, post, put

@command(
    name="list",
    description="Use this command to list all campaigns. Prefer `campaign get` when the user wants only one campaign.",
    schema={
        "endpoint": "/campaigns", "method": "GET",
        "input": {
            "query": {
                "full": {"type": "boolean"},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "name": {"type": "string"},
            "note": {"type": "string", "maxLength": 300},
            "status": {"type": "string", "enum": ["On", "Off"], "readOnly": True},
            "sourced": {"type": "integer"},
            "outreached": {"type": "integer"},
            "accepted": {"type": "integer"},
            "responded": {"type": "integer"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
            "filters": {
                "type": "object",
                "properties": {
                    "role": {
                        "type": "object",
                        "properties": {
                            "include": {"type": "array", "items": {"type": "string"}},
                            "exclude": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                    "location": {
                        "type": "object",
                        "properties": {
                            "include": {"type": "array", "items": {"type": "string"}},
                            "exclude": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                },
            },
            "is_active": {"type": "boolean"},
            "total_leads_to_source": {"type": "integer"},
            "daily_outreach_limit": {"type": "integer"},
            "search_url": {"type": "string", "format": "uri"},
            "cursor": {"type": "string"},
            "type_of_campaign": {"type": "string", "enum": ["custom", "ai", "signals"]},
            "signals": {"type": "array", "items": {"type": "string"}},
            "personalization_prompt": {"type": "string"},
            "context": {
                "type": "object",
                "properties": {
                    "company": {"type": "string"},
                    "edge": {"type": "string"},
                },
            },
            "follow_up_note": {"type": "string", "maxLength": 900},
            "follow_up_delay": {"type": "integer"},
            "follow_ups": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "note": {"type": "string"},
                        "delay": {"type": "integer"},
                    },
                },
            },
            "followed_up_at": {"type": "string", "format": "date-time"},
            "auto_renew": {"type": "boolean"},
            "user_id": {"type": "integer"},
        },
        "example": {
            "input": {
                "query": {
                    "full": True,
                },
            },
            "output": {
                "id": 1,
                "name": "Operation Overthrow",
                "note": "Dwight's master plan to steal all of Staples' clients",
                "status": "On",
                "sourced": 150,
                "outreached": 42,
                "accepted": 18,
                "responded": 7,
                "filters": {"role": {"include": ["8"]}, "location": {"include": ["103644278"]}},
                "is_active": True,
                "total_leads_to_source": 200,
                "daily_outreach_limit": 25,
                "search_url": "https://www.linkedin.com/sales/search/people?query=...",
                "cursor": None,
                "type_of_campaign": "ai",
                "signals": None,
                "personalization_prompt": "Reference their recent company achievement. Mention Dunder Mifflin's personal touch.",
                "context": {"company": "Dunder Mifflin Scranton", "edge": "dedicated reps, same-day delivery"},
                "follow_up_note": None,
                "follow_up_delay": 3,
                "follow_ups": [{"note": "Just checking in, Michael", "delay": 3}],
                "followed_up_at": "2026-04-09T14:00:00+00:00",
                "auto_renew": True,
                "user_id": 1,
                "created_at": "2026-01-15T08:30:00+00:00",
                "updated_at": "2026-04-10T10:00:00+00:00",
            },
        },
    },
)
@click.option("--full", is_flag=True, help="Include all campaign fields instead of summary view")
def list_(full, **_):
    return {
        "object": "CampaignList",
        "items": get("/campaigns", params={"full": "true"} if full else None),
    }

@command(
    name="get",
    description="Use this command to get a campaign's settings. Prefer `campaign list` when the user wants all campaigns.",
    schema={
        "endpoint": "/campaigns/<id>", "method": "GET",
        "input": {
            "path": {
                "id": {"type": "integer", "required": True},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "name": {"type": "string"},
            "filters": {
                "type": "object",
                "properties": {
                    "role": {
                        "type": "object",
                        "properties": {
                            "include": {"type": "array", "items": {"type": "string"}},
                            "exclude": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                    "location": {
                        "type": "object",
                        "properties": {
                            "include": {"type": "array", "items": {"type": "string"}},
                            "exclude": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                },
            },
            "is_active": {"type": "boolean"},
            "note": {"type": "string", "maxLength": 300},
            "total_leads_to_source": {"type": "integer"},
            "daily_outreach_limit": {"type": "integer"},
            "search_url": {"type": "string", "format": "uri"},
            "cursor": {"type": "string"},
            "type_of_campaign": {"type": "string", "enum": ["custom", "ai", "signals"]},
            "signals": {"type": "array", "items": {"type": "string"}},
            "personalization_prompt": {"type": "string"},
            "context": {
                "type": "object",
                "properties": {
                    "company": {"type": "string"},
                    "edge": {"type": "string"},
                },
            },
            "follow_up_note": {"type": "string", "maxLength": 900},
            "follow_up_delay": {"type": "integer"},
            "follow_ups": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "note": {"type": "string"},
                        "delay": {"type": "integer"},
                    },
                },
            },
            "followed_up_at": {"type": "string", "format": "date-time"},
            "auto_renew": {"type": "boolean"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
            "user_id": {"type": "integer"},
            "websites": {"type": "array", "items": {"type": "string"}},
        },
        "example": {
            "input": {
                "path": {
                    "id": 6,
                },
            },
            "output": {
                "id": 6,
                "name": "Vance Refrigeration Takedown",
                "filters": {},
                "is_active": True,
                "note": None,
                "total_leads_to_source": 0,
                "daily_outreach_limit": 25,
                "search_url": None,
                "cursor": None,
                "type_of_campaign": "signals",
                "signals": ["Did {company_website} recently hire a new VP of Sales or CRO?", "Did {company_website} raise funding or announce new investment?", "Is {company_website} expanding into new regions or markets?"],
                "personalization_prompt": "Reference the company's recent expansion. Mention Dunder Mifflin's same-day delivery edge.",
                "context": {"company": "Dunder Mifflin Scranton", "edge": "dedicated reps, same-day delivery"},
                "follow_up_note": None,
                "follow_up_delay": 3,
                "follow_ups": [{"note": "Just checking in, Bob", "delay": 3}],
                "followed_up_at": "2026-04-09T14:00:00+00:00",
                "auto_renew": True,
                "created_at": "2026-03-15T09:00:00+00:00",
                "updated_at": "2026-04-10T10:00:00+00:00",
                "user_id": 1,
                "websites": ["https://vancerefrigeration.com", "https://bluecross.com"],
            },
        },
    },
)
@click.option("--id", type=click.INT, required=True)
def get_(id, **_):
    return {"object": "Campaign", **get(f"/campaigns/{id}")}

@command(
    name="update",
    description="Use this command to edit a campaign's settings. Prefer `campaign status` when the user only wants to pause or resume the campaign.",
    schema={
        "endpoint": "/campaigns/<id>", "method": "PUT",
        "input": {
            "path": {
                "id": {"type": "integer", "required": True},
            },
            "body": {
                "name": {"type": "string"},
                "note": {"type": "string", "maxLength": 300},
                "total_leads_to_source": {"type": "integer"},
                "daily_outreach_limit": {"type": "integer"},
                "filters": {
                    "type": "object",
                    "properties": {
                        "role": {
                            "type": "object",
                            "properties": {
                                "include": {"type": "array", "items": {"type": "string"}},
                                "exclude": {"type": "array", "items": {"type": "string"}},
                            },
                        },
                        "location": {
                            "type": "object",
                            "properties": {
                                "include": {"type": "array", "items": {"type": "string"}},
                                "exclude": {"type": "array", "items": {"type": "string"}},
                            },
                        },
                    },
                },
                "search_url": {"type": "string", "format": "uri"},
                "follow_up_note": {"type": "string", "maxLength": 900},
                "follow_up_delay": {"type": "integer"},
                "follow_ups": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "note": {"type": "string"},
                            "delay": {"type": "integer"},
                        },
                    },
                },
                "signals": {"type": "array", "items": {"type": "string"}},
                "personalization_prompt": {"type": "string"},
                "context": {
                    "type": "object",
                    "properties": {
                        "company": {"type": "string"},
                        "edge": {"type": "string"},
                    },
                },
                "auto_renew": {"type": "boolean"},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "name": {"type": "string"},
            "filters": {
                "type": "object",
                "properties": {
                    "role": {
                        "type": "object",
                        "properties": {
                            "include": {"type": "array", "items": {"type": "string"}},
                            "exclude": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                    "location": {
                        "type": "object",
                        "properties": {
                            "include": {"type": "array", "items": {"type": "string"}},
                            "exclude": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                },
            },
            "is_active": {"type": "boolean"},
            "note": {"type": "string", "maxLength": 300},
            "total_leads_to_source": {"type": "integer"},
            "daily_outreach_limit": {"type": "integer"},
            "search_url": {"type": "string", "format": "uri"},
            "cursor": {"type": "string"},
            "type_of_campaign": {"type": "string", "enum": ["custom", "ai", "signals"]},
            "signals": {"type": "array", "items": {"type": "string"}},
            "personalization_prompt": {"type": "string"},
            "context": {
                "type": "object",
                "properties": {
                    "company": {"type": "string"},
                    "edge": {"type": "string"},
                },
            },
            "follow_up_note": {"type": "string", "maxLength": 900},
            "follow_up_delay": {"type": "integer"},
            "follow_ups": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "note": {"type": "string"},
                        "delay": {"type": "integer"},
                    },
                },
            },
            "followed_up_at": {"type": "string", "format": "date-time"},
            "auto_renew": {"type": "boolean"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
            "user_id": {"type": "integer"},
        },
        "example": {
            "input": {
                "path": {
                    "id": 1,
                },
                "body": {
                    "name": "Operation Overthrow",
                    "note": "Dwight says 25 is too conservative. Overruled.",
                    "total_leads_to_source": 200,
                    "daily_outreach_limit": 15,
                    "filters": {"role": {"include": ["8"]}},
                    "search_url": "https://www.linkedin.com/sales/search/people?query=...",
                    "follow_up_note": "Just checking in",
                    "follow_up_delay": 3,
                    "follow_ups": [{"note": "Just checking in", "delay": 3}],
                    "signals": None,
                    "personalization_prompt": "Reference their recent company achievement.",
                    "context": {"company": "Dunder Mifflin Scranton"},
                    "auto_renew": True,
                },
            },
            "output": {
                "id": 1,
                "name": "Operation Overthrow",
                "filters": {"role": {"include": ["8"]}},
                "is_active": True,
                "note": "Dwight says 25 is too conservative. Overruled.",
                "total_leads_to_source": 200,
                "daily_outreach_limit": 15,
                "search_url": "https://www.linkedin.com/sales/search/people?query=...",
                "cursor": None,
                "type_of_campaign": "ai",
                "signals": None,
                "personalization_prompt": "Reference their recent company achievement.",
                "context": {"company": "Dunder Mifflin Scranton"},
                "follow_up_note": None,
                "follow_up_delay": 3,
                "follow_ups": [{"note": "Just checking in", "delay": 3}],
                "followed_up_at": None,
                "auto_renew": True,
                "created_at": "2026-01-15T08:30:00+00:00",
                "updated_at": "2026-04-11T14:20:00+00:00",
                "user_id": 1,
            },
        },
    },
    input_stdin=True,
    stdin_error="Pipe JSON to stdin",
)
@click.option("--id", type=click.INT, required=True)
def update(id, _body, **_):
    return {"object": "Campaign", **put(f"/campaigns/{id}", _body)}

@command(
    name="delete",
    description="Use this command to permanently delete a campaign. Prefer `campaign status` when the user wants to pause outreach instead of deleting.",
    schema={
        "endpoint": "/campaigns/<id>", "method": "DELETE",
        "input": {
            "path": {
                "id": {"type": "integer", "required": True},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "name": {"type": "string"},
            "note": {"type": "string", "maxLength": 300},
            "status": {"type": "string", "enum": ["On", "Off"], "readOnly": True},
            "sourced": {"type": "integer"},
            "outreached": {"type": "integer"},
            "accepted": {"type": "integer"},
            "responded": {"type": "integer"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
        },
        "example": {
            "input": {
                "path": {
                    "id": 3,
                },
            },
            "output": {
                "id": 3,
                "name": "Pretzel Day Outreach",
                "note": "Ryan started the fire",
                "status": "Off",
                "sourced": 80,
                "outreached": 20,
                "accepted": 9,
                "responded": 3,
                "created_at": "2026-02-10T11:00:00+00:00",
                "updated_at": "2026-04-05T16:45:00+00:00",
            },
        },
    },
)
@click.option("--id", type=click.INT, required=True)
def delete_(id, **_):
    return {"object": "Campaign", **delete(f"/campaigns/{id}")}

@command(
    name="status",
    description="Use this command to pause or resume a campaign. Prefer `campaign delete` when the user wants to permanently delete the campaign.",
    schema={
        "endpoint": "/campaigns/<id>/status", "method": "PUT",
        "input": {
            "path": {
                "id": {"type": "integer", "required": True},
            },
            "body": {
                "is_active": {"type": "boolean", "required": True},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "name": {"type": "string"},
            "filters": {
                "type": "object",
                "properties": {
                    "role": {
                        "type": "object",
                        "properties": {
                            "include": {"type": "array", "items": {"type": "string"}},
                            "exclude": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                    "location": {
                        "type": "object",
                        "properties": {
                            "include": {"type": "array", "items": {"type": "string"}},
                            "exclude": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                },
            },
            "is_active": {"type": "boolean"},
            "note": {"type": "string", "maxLength": 300},
            "total_leads_to_source": {"type": "integer"},
            "daily_outreach_limit": {"type": "integer"},
            "search_url": {"type": "string", "format": "uri"},
            "cursor": {"type": "string"},
            "type_of_campaign": {"type": "string", "enum": ["custom", "ai", "signals"]},
            "signals": {"type": "array", "items": {"type": "string"}},
            "personalization_prompt": {"type": "string"},
            "context": {
                "type": "object",
                "properties": {
                    "company": {"type": "string"},
                    "edge": {"type": "string"},
                },
            },
            "follow_up_note": {"type": "string", "maxLength": 900},
            "follow_up_delay": {"type": "integer"},
            "follow_ups": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "note": {"type": "string"},
                        "delay": {"type": "integer"},
                    },
                },
            },
            "followed_up_at": {"type": "string", "format": "date-time"},
            "auto_renew": {"type": "boolean"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
            "user_id": {"type": "integer"},
        },
        "example": {
            "input": {
                "path": {
                    "id": 1,
                },
                "body": {
                    "is_active": False,
                },
            },
            "output": {
                "id": 1,
                "name": "Operation Overthrow",
                "filters": {"role": {"include": ["8"]}},
                "is_active": False,
                "note": "Dwight's master plan to steal all of Staples' clients",
                "total_leads_to_source": 200,
                "daily_outreach_limit": 25,
                "search_url": "https://www.linkedin.com/sales/search/people?query=...",
                "cursor": None,
                "type_of_campaign": "ai",
                "signals": None,
                "personalization_prompt": "Reference their recent company achievement.",
                "context": {"company": "Dunder Mifflin Scranton"},
                "follow_up_note": None,
                "follow_up_delay": 3,
                "follow_ups": [{"note": "Just checking in", "delay": 3}],
                "followed_up_at": "2026-04-09T14:00:00+00:00",
                "auto_renew": True,
                "created_at": "2026-01-15T08:30:00+00:00",
                "updated_at": "2026-04-11T14:20:00+00:00",
                "user_id": 1,
            },
        },
    },
    input_stdin=True,
    stdin_error='Pipe {"is_active": true/false} to stdin',
)
@click.option("--id", type=click.INT, required=True)
def status(id, _body, **_):
    return {"object": "Campaign", **put(f"/campaigns/{id}/status", _body)}

@command(
    name="custom",
    full_name="campaign create custom",
    description="Use this command to create a custom campaign that automates daily sending of LinkedIn connection requests and follow-ups to leads in the campaign. First, the user sets up a sequence — a connection request and follow-ups. Second, the user adds leads using search filters or a LinkedIn Sales Navigator link. Every lead receives the same connection request and follow-ups. Prefer `campaign create ai` when the user wants a personalized connection request for every lead.",
    schema={
        "endpoint": "/campaigns", "method": "POST",
        "input": {
            "body": {
                "name": {"type": "string", "required": True, "description": "Campaign name"},
                "note": {"type": "string", "maxLength": 300, "description": "A message sent as connection request on LinkedIn. Supports {first_name}, {last_name}, and {company} as placeholders"},
                "follow_up_note": {"type": "string", "maxLength": 600, "description": "A message sent as follow-up if the lead accepts your connection request but doesn't respond. Supports {first_name}, {last_name}, and {company} as placeholders"},
                "follow_up_delay": {"type": "integer", "description": "Days to wait after the lead accepts your connection request before sending the follow-up"},
                "follow_ups": {
                    "type": "array",
                    "description": "Additional follow-up messages after the first one, each with its own message and delay in days",
                    "items": {
                        "type": "object",
                        "properties": {
                            "note": {"type": "string"},
                            "delay": {"type": "integer"},
                        },
                    },
                },
                "daily_outreach_limit": {"type": "integer", "description": "Number of connection requests to send per day from this campaign"},
                "filters": {
                    "type": "object",
                    "description": "Basic lead search — 5 filters available: job position, location, industry, company, and company headcount. Look up filter IDs with `linkedin search parameters`. Use either filters or search_url, not both",
                    "properties": {
                        "role": {
                            "type": "object",
                            "properties": {
                                "include": {"type": "array", "items": {"type": "string"}},
                                "exclude": {"type": "array", "items": {"type": "string"}},
                            },
                        },
                        "location": {
                            "type": "object",
                            "properties": {
                                "include": {"type": "array", "items": {"type": "string"}},
                                "exclude": {"type": "array", "items": {"type": "string"}},
                            },
                        },
                    },
                },
                "search_url": {"type": "string", "format": "uri", "description": "Advanced lead search — 40+ filters available. Provide a LinkedIn Sales Navigator link with your selected filters. Use either search_url or filters, not both"},
                "total_leads_to_source": {"type": "integer", "required": True, "description": "Number of leads to add to this campaign"},
                "auto_renew": {"type": "boolean", "description": "Auto add leads from the same filters or search_url when all leads have been contacted"},
            },
        },
        "output": {
            "id": {"type": "integer", "description": "Created campaign id"},
            "message": {"type": "string", "description": "Confirmation message"},
        },
        "example": {
            "input": {
                "body": {
                    "name": "Lackawanna County Blitz",
                    "note": "Hi {first_name}, Michael Scott from Dunder Mifflin — same-day paper delivery with a dedicated rep. Open to exploring?",
                    "follow_up_note": "{first_name}, our clients save 15-20% vs big box suppliers. Happy to show you how.",
                    "follow_up_delay": 3,
                    "follow_ups": [
                        {"note": "One rep, one call, done — no more chasing vendors. Let me know if {company} could use that.", "delay": 7},
                        {"note": "{first_name}, Dwight handles your territory — he'll make sure {company} never runs out of paper.", "delay": 14},
                    ],
                    "daily_outreach_limit": 3,
                    "filters": {"role": {"include": ["8"]}, "location": {"include": ["103644278"]}},
                    "search_url": None,
                    "total_leads_to_source": 100,
                    "auto_renew": True,
                },
            },
            "output": {
                "id": 4,
                "message": "Campaign created successfully!",
            },
        },
    },
    input_stdin=True,
    stdin_error="Pipe campaign JSON to stdin",
)
def create_custom(_body, **_):
    return {"object": "Campaign", **post("/campaigns", {**_body, "type_of_campaign": "custom"})}

@command(
    name="ai",
    full_name="campaign create ai",
    description="Use this command to create an AI campaign that automates daily sending of personalized LinkedIn connection requests to leads in the campaign. First, the user provides a personalization prompt and selects the context. Second, the user adds leads using search filters or a LinkedIn Sales Navigator link. The sales agent generates a unique connection request for every lead. Prefer `campaign create custom` when the user wants the same connection request and follow-ups for every lead.",
    schema={
        "endpoint": "/campaigns", "method": "POST",
        "input": {
            "body": {
                "name": {"type": "string", "required": True, "description": "Campaign name"},
                "personalization_prompt": {"type": "string", "required": True, "description": "Instructions you give the AI on how to write and personalize the connection requests"},
                "context": {
                    "type": "object",
                    "description": "Context the AI can use to personalize your connection notes — your profile, lead profile, your website, your original messages",
                    "properties": {
                        "company": {"type": "string"},
                        "edge": {"type": "string"},
                    },
                },
                "filters": {
                    "type": "object",
                    "description": "Basic lead search — 5 filters available: job position, location, industry, company, and company headcount. Look up filter IDs with `linkedin search parameters`. Use either filters or search_url, not both",
                    "properties": {
                        "role": {
                            "type": "object",
                            "properties": {
                                "include": {"type": "array", "items": {"type": "string"}},
                                "exclude": {"type": "array", "items": {"type": "string"}},
                            },
                        },
                        "location": {
                            "type": "object",
                            "properties": {
                                "include": {"type": "array", "items": {"type": "string"}},
                                "exclude": {"type": "array", "items": {"type": "string"}},
                            },
                        },
                    },
                },
                "search_url": {"type": "string", "format": "uri", "description": "Advanced lead search — 40+ filters available. Provide a LinkedIn Sales Navigator link with your selected filters. Use either search_url or filters, not both"},
                "total_leads_to_source": {"type": "integer", "required": True, "description": "Number of leads to add to this campaign"},
                "daily_outreach_limit": {"type": "integer", "description": "Number of connection requests to send per day from this campaign"},
                "auto_renew": {"type": "boolean", "description": "Auto add leads from the same filters or search_url when all leads have been contacted"},
            },
        },
        "output": {
            "id": {"type": "integer", "description": "Created campaign id"},
            "message": {"type": "string", "description": "Confirmation message"},
        },
        "example": {
            "input": {
                "body": {
                    "name": "Michael Scott Paper Company Revival",
                    "personalization_prompt": "Mention their recent company news. Emphasize the personal service they won't get from Staples. Keep it under 200 characters.",
                    "context": ["your_profile", "lead_profile", "your_website"],
                    "filters": None,
                    "search_url": "https://www.linkedin.com/sales/search/people?query=...",
                    "total_leads_to_source": 200,
                    "daily_outreach_limit": 25,
                    "auto_renew": True,
                },
            },
            "output": {
                "id": 5,
                "message": "Campaign created successfully!",
            },
        },
    },
    input_stdin=True,
    stdin_error="Pipe campaign JSON to stdin",
)
def create_ai(_body, **_):
    return {"object": "Campaign", **post("/campaigns", {**_body, "type_of_campaign": "ai"})}

@command(
    name="signals",
    full_name="campaign create signals",
    description="Use this command to create a signals campaign that automates monthly monitoring of target accounts for buying signals. First, the user provides company websites. Second, the user defines the signals to track. Every month, each company is deep-researched and every signal is answered with findings, citations, and confidence levels. Prefer `campaign create custom` or `campaign create ai` when the user wants to automate sending connection requests and follow-ups to leads.",
    schema={
        "endpoint": "/campaigns", "method": "POST",
        "input": {
            "body": {
                "name": {"type": "string", "required": True, "description": "Campaign name"},
                "websites": {"type": "string", "required": True, "description": "Comma-separated target company websites to track"},
                "signals": {
                    "type": "array",
                    "description": "Custom signals to track on each company. Can be anything — e.g. \"Does {company_website} have open SDR roles?\", \"What is {company_website}'s sales department hierarchy?\"",
                    "items": {"type": "string"},
                },
            },
        },
        "output": {
            "id": {"type": "integer", "description": "Created campaign id"},
            "message": {"type": "string", "description": "Confirmation message"},
        },
        "example": {
            "input": {
                "body": {
                    "name": "Scranton Mid-Market Accounts",
                    "websites": "https://scrantoncounty.gov,https://lakewallenpaupack.com,https://poorrichards.com",
                    "signals": [
                        "Is {company_website} growing their team or hiring?",
                        "Has {company_website} moved to a new office or expanded locations?",
                        "Has {company_website} raised funding recently?",
                        "Does {company_website} still use a paper supplier or have they gone fully digital?",
                        "Is {company_website} unhappy with their current supplier?",
                        "Has {company_website} posted about sustainability or going green?",
                    ],
                },
            },
            "output": {
                "id": 6,
                "message": "Campaign created successfully!",
            },
        },
    },
    input_stdin=True,
    stdin_error="Pipe campaign JSON to stdin",
)
def create_signals(_body, **_):
    return {"object": "Campaign", **post("/campaigns", {**_body, "type_of_campaign": "signals"})}

# Play called.
