# *[logs into LinkedIn, puts on the headset]*

"""
linkedin.py — The LinkedIn desk.

Everything that touches LinkedIn — connect accounts,
search for prospects, send invitations and messages,
retrieve profiles, and read conversations.
"""

import click

from the_office_cli.cli.decorators import command
from the_office_cli.network.session import get, post, input_stdin
from the_office_cli.utils.output import error_stderr


@command(
    name="account",
    full_name="linkedin connect account",
    description="Use this command to get an auth URL for connecting a LinkedIn account. Opens the URL in the browser automatically. Prefer `linkedin reconnect account` when the account exists but is disconnected.",
    schema={
        "endpoint": "/provider/connect", "method": "GET",
        "input": {},
        "output": {
            "url": {"type": "string", "format": "uri"},
        },
        "example": {
            "input": {},
            "output": {"url": "https://account.unipile.com/auth/linkedin/abc123"},
        },
    },
)
def connect_account(**_):
    result = get("/provider/connect")
    url = result.get("url")
    if url:
        click.launch(url)
    return {"object": "AuthLink", **result}


@command(
    name="account",
    full_name="linkedin reconnect account",
    description="Use this command to get an auth URL for re-connecting a disconnected LinkedIn account. Prefer `linkedin connect account` when no LinkedIn account is connected.",
    schema={
        "endpoint": "/provider/reconnect/<account_id>", "method": "GET",
        "input": {
            "path": {
                "account_id": {"type": "string", "required": True},
            },
        },
        "output": {
            "url": {"type": "string", "format": "uri"},
        },
        "example": {
            "input": {
                "path": {
                    "account_id": "hzxstXVkQiixkJGNgbhSSw",
                },
            },
            "output": {"url": "https://account.unipile.com/auth/reconnect/hzxstXVkQiixkJGNgbhSSw"},
        },
    },
)
@click.option("--account-id", "account_id", required=True)
def reconnect_account(account_id, **_):
    return {"object": "AuthLink", **get(f"/provider/reconnect/{account_id}")}


@command(
    name="connection",
    full_name="linkedin check connection",
    description="Use this command to check whether the user's LinkedIn account is connected and ready.",
    schema={
        "endpoint": "/connect-with-linkedin/status", "method": "GET",
        "input": {},
        "output": {
            "connected": {"type": "boolean"},
        },
        "example": {"input": {}, "output": {"connected": True}},
    },
)
def check_account(**_):
    return {"object": "AccountStatus", "connected": get("/connect-with-linkedin/status")}


@command(
    name="me",
    full_name="linkedin me",
    description="Use this command to get the user's own LinkedIn profile. Prefer `linkedin retrieve profile` when the user wants a lead's profile.",
    schema={
        "endpoint": "/linkedin/me", "method": "GET",
        "input": {},
        "output": {
            "object": {"type": "string", "enum": ["AccountOwnerProfile"]},
            "provider": {"type": "string", "enum": ["LINKEDIN"]},
            "provider_id": {"type": "string"},
            "entity_urn": {"type": "string"},
            "object_urn": {"type": "string"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "profile_picture_url": {"type": "string", "format": "uri"},
            "public_profile_url": {"type": "string", "format": "uri"},
            "public_identifier": {"type": "string"},
            "headline": {"type": "string"},
            "occupation": {"type": "string"},
            "location": {"type": "string"},
            "email": {"type": "string", "format": "email"},
            "premium": {"type": "boolean"},
            "open_profile": {"type": "boolean"},
            "organizations": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {},
                },
            },
            "recruiter": {
                "type": "object",
                "properties": {
                    "contract_id": {"type": "string"},
                    "owner_seat_id": {"type": "string"},
                },
            },
            "sales_navigator": {
                "type": "object",
                "properties": {
                    "contract_id": {"type": "string"},
                    "owner_seat_id": {"type": "string"},
                },
            },
        },
        "example": {
            "input": {},
            "output": {
                "object": "AccountOwnerProfile",
                "provider": "LINKEDIN",
                "provider_id": "ACoAABcD1234567890abcdefghijklmnopqrstuv",
                "entity_urn": "urn:li:fsd_profile:ACoAABcD1234567890abcdefghijklmnopqrstuv",
                "object_urn": "urn:li:member:395537657",
                "first_name": "Michael",
                "last_name": "Scott",
                "profile_picture_url": "https://media.licdn.com/dms/image/v2/scranton/profile.jpg",
                "public_profile_url": "https://www.linkedin.com/in/michael-scott-scranton",
                "public_identifier": "michael-scott-scranton",
                "headline": "Regional Manager at Dunder Mifflin | World's Best Boss",
                "occupation": "Regional Manager at Dunder Mifflin Paper Company",
                "location": "Scranton, PA",
                "email": "michael@dundermifflin.com",
                "premium": True,
                "open_profile": True,
                "organizations": [],
                "recruiter": None,
                "sales_navigator": {"contract_id": "1420122305", "owner_seat_id": "573571805"},
            },
        },
    },
)
def retrieve_own_profile(**_):
    return {"object": "AccountOwnerProfile", **get("/linkedin/me")}


@command(
    name="profile",
    full_name="linkedin retrieve profile",
    description="Use this command to get a LinkedIn lead's profile. Prefer `linkedin me` when the user wants the user's own profile. Prefer `linkedin retrieve company` when the user wants a company profile.",
    schema={
        "endpoint": "/linkedin/profile/<id>", "method": "GET",
        "input": {
            "path": {
                "id": {
                    "type": "string",
                    "required": True,
                    "oneOf": [
                        {"format": "public_identifier"},
                        {"format": "provider_id"},
                        {"format": "classic_provider_id"},
                    ],
                    "examples": [
                        "dwight-k-schrute",
                        "ACwAABcD1234567890abcdefghijklmnopqrstuv",
                        "ACoAABcD1234567890abcdefghijklmnopqrstuv",
                    ],
                },
            },
            "query": {
                "linkedin_api": {"type": "string", "enum": ["sales_navigator", "recruiter"]},
                "notify": {"type": "boolean"},
                "linkedin_sections": {"type": "array", "items": {"type": "string"}},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["UserProfile"]},
            "provider": {"type": "string", "enum": ["LINKEDIN"]},
            "provider_id": {"type": "string"},
            "public_identifier": {"type": "string"},
            "member_urn": {"type": "string"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "headline": {"type": "string"},
            "location": {"type": "string"},
            "primary_locale": {
                "type": "object",
                "properties": {
                    "country": {"type": "string"},
                    "language": {"type": "string"},
                },
            },
            "summary": {"type": "string"},
            "follower_count": {"type": "integer"},
            "connections_count": {"type": "integer"},
            "shared_connections_count": {"type": "integer"},
            "is_premium": {"type": "boolean"},
            "is_open_profile": {"type": "boolean"},
            "is_open_to_work": {"type": "boolean"},
            "is_influencer": {"type": "boolean"},
            "is_creator": {"type": "boolean"},
            "is_hiring": {"type": "boolean"},
            "is_relationship": {"type": "boolean"},
            "is_self": {"type": "boolean"},
            "is_saved_lead": {"type": "boolean"},
            "is_crm_imported": {"type": "boolean"},
            "can_send_inmail": {"type": "boolean"},
            "network_distance": {"type": "string", "enum": ["FIRST_DEGREE", "SECOND_DEGREE", "THIRD_DEGREE", "OUT_OF_NETWORK"]},
            "public_profile_url": {"type": "string", "format": "uri"},
            "profile_picture_url": {"type": "string", "format": "uri"},
            "profile_picture_url_large": {"type": "string", "format": "uri"},
            "background_picture_url": {"type": "string", "format": "uri"},
            "websites": {"type": "array", "items": {"type": "string"}},
            "contact_info": {
                "type": "object",
                "properties": {
                    "adresses": {"type": "array", "items": {"type": "string"}},
                    "emails": {"type": "array", "items": {"type": "string"}},
                    "phones": {"type": "array", "items": {"type": "string"}},
                    "socials": {"type": "array", "items": {"type": "string"}},
                },
            },
            "birthdate": {
                "type": "object",
                "properties": {
                    "month": {"type": "integer"},
                    "day": {"type": "integer"},
                },
            },
            "invitation": {
                "type": "object",
                "properties": {
                    "status": {"type": "string"},
                    "sent_at": {"type": "string", "format": "date-time"},
                },
            },
            "work_experience": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "position": {"type": "string"},
                        "company": {"type": "string"},
                        "company_id": {"type": "string"},
                        "location": {"type": "string"},
                        "description": {"type": "string"},
                        "start": {"type": "string"},
                        "end": {"type": "string"},
                        "current": {"type": "boolean"},
                        "skills": {"type": "array", "items": {"type": "string"}},
                    },
                },
            },
            "work_experience_total_count": {"type": "integer"},
            "volunteering_experience": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "company": {"type": "string"},
                        "role": {"type": "string"},
                        "cause": {"type": "string"},
                        "start": {"type": "string"},
                        "end": {"type": "string"},
                    },
                },
            },
            "volunteering_experience_total_count": {"type": "integer"},
            "education": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "school": {"type": "string"},
                        "degree": {"type": "string"},
                        "field_of_study": {"type": "string"},
                        "start": {"type": "string"},
                        "end": {"type": "string"},
                        "skills": {"type": "array", "items": {"type": "string"}},
                    },
                },
            },
            "education_total_count": {"type": "integer"},
            "skills": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "endorsement_count": {"type": "integer"},
                        "endorsement_id": {"type": "string"},
                    },
                },
            },
            "skills_total_count": {"type": "integer"},
            "languages": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "proficiency": {"type": "string"},
                    },
                },
            },
            "languages_total_count": {"type": "integer"},
            "certifications": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "organization": {"type": "string"},
                        "issued_at": {"type": "string", "format": "date-time"},
                    },
                },
            },
            "certifications_total_count": {"type": "integer"},
            "projects": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "description": {"type": "string"},
                    },
                },
            },
            "projects_total_count": {"type": "integer"},
            "recommendations": {
                "type": "object",
                "properties": {
                    "received": {"type": "array", "items": {"type": "object", "properties": {}}},
                    "received_total_count": {"type": "integer"},
                    "given": {"type": "array", "items": {"type": "object", "properties": {}}},
                    "given_total_count": {"type": "integer"},
                },
            },
            "hashtags": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                    },
                },
            },
            "throttled_sections": {"type": "array", "items": {"type": "string"}},
        },
        "rate_limit": "50 profile views/account/day",
        "example": {
            "input": {
                "path": {
                    "id": "dwight-k-schrute",
                },
                "query": {
                    "linkedin_api": "sales_navigator",
                    "notify": False,
                    "linkedin_sections": ["experience", "education"],
                },
            },
            "output": {
                "object": "UserProfile",
                "provider": "LINKEDIN",
                "provider_id": "ACoAABDWs1cDfGh3iJk4lM5nO6pQ7rS8tU9vWxY",
                "public_identifier": "dwight-k-schrute",
                "member_urn": "395537657",
                "first_name": "Dwight",
                "last_name": "Schrute",
                "headline": "Assistant Regional Manager | Top Salesman | Beet Farmer | Volunteer Sheriff's Deputy",
                "location": "Scranton, PA",
                "primary_locale": {"country": "US", "language": "en"},
                "summary": "Bears. Beets. Battlestar Galactica.",
                "follower_count": 847,
                "connections_count": 847,
                "shared_connections_count": 42,
                "is_premium": True,
                "is_open_profile": True,
                "is_open_to_work": False,
                "is_influencer": False,
                "is_creator": False,
                "is_hiring": False,
                "is_relationship": True,
                "is_self": False,
                "is_saved_lead": False,
                "is_crm_imported": False,
                "can_send_inmail": True,
                "network_distance": "FIRST_DEGREE",
                "public_profile_url": "https://www.linkedin.com/in/dwight-k-schrute",
                "profile_picture_url": "https://media.licdn.com/dms/image/v2/schrute/profile_100.jpg",
                "profile_picture_url_large": "https://media.licdn.com/dms/image/v2/schrute/profile_800.jpg",
                "background_picture_url": "https://media.licdn.com/dms/image/v2/schrute/beet-farm.jpg",
                "websites": ["https://schrutefarms.com"],
                "contact_info": {
                    "adresses": ["1725 Slough Avenue, Scranton, PA, 18505"],
                    "emails": ["dwight@dundermifflin.com"],
                    "phones": ["+15705551234"],
                },
                "birthdate": {"month": 1, "day": 20},
                "invitation": None,
                "work_experience": [
                    {
                        "position": "Assistant Regional Manager",
                        "company": "Dunder Mifflin Paper Company",
                        "location": "Scranton, PA",
                        "current": True,
                        "start": "2005-03",
                        "end": None,
                        "skills": ["Sales", "Counterintelligence", "Beet Farming"],
                    },
                    {
                        "position": "Owner",
                        "company": "Schrute Farms",
                        "location": "Honesdale, PA",
                        "current": True,
                        "start": "1998-06",
                        "end": None,
                        "skills": ["Agritourism", "Beet Farming"],
                    },
                ],
                "work_experience_total_count": 2,
                "volunteering_experience": [
                    {
                        "company": "Lackawanna County Sheriff",
                        "role": "Volunteer Deputy",
                        "cause": "Public Safety",
                        "start": "2007-01",
                        "end": None,
                        "description": "Weekend shifts. Uniform pressed by me.",
                    },
                ],
                "volunteering_experience_total_count": 1,
                "education": [
                    {
                        "school": "Cornell University",
                        "degree": "Bachelor",
                        "field_of_study": "Agriculture",
                        "start": "2001",
                        "end": "2005",
                        "skills": ["Agriculture"],
                    },
                ],
                "education_total_count": 1,
                "skills": [
                    {"name": "Sales", "endorsement_count": 128, "endorsement_id": None, "insights": [], "endorsed": True},
                    {"name": "Beet Farming", "endorsement_count": 94, "endorsement_id": None, "insights": [], "endorsed": True},
                ],
                "skills_total_count": 2,
                "languages": [
                    {"name": "English", "proficiency": "NATIVE_OR_BILINGUAL"},
                    {"name": "German", "proficiency": "LIMITED_WORKING"},
                ],
                "languages_total_count": 2,
                "certifications": [
                    {"name": "Dundie Award Winner", "organization": "Dunder Mifflin"},
                ],
                "certifications_total_count": 1,
                "projects": [],
                "projects_total_count": 0,
                "recommendations": {"received": [], "received_total_count": 0, "given": [], "given_total_count": 0},
                "hashtags": ["#beets", "#battlestargalactica"],
                "throttled_sections": [],
            },
        },
    },
)
@click.option("--id", required=True)
@click.option("--api", "linkedin_api", help="LinkedIn API flavor: sales_navigator | recruiter. Omit for classic.")
def retrieve_profile(id, linkedin_api, **_):
    params = {k: v for k, v in {"linkedin_api": linkedin_api}.items() if v}
    return {
        "object": "UserProfile",
        **get(f"/linkedin/profile/{id}", params=params),
    }


@command(
    name="company",
    full_name="linkedin retrieve company",
    description="Use this command to get a LinkedIn company profile. Prefer `linkedin retrieve profile` when the user wants a lead's profile.",
    schema={
        "endpoint": "/linkedin/company/<id>", "method": "GET",
        "input": {
            "path": {
                "id": {
                    "type": "string",
                    "required": True,
                    "oneOf": [
                        {"format": "public_identifier"},
                        {"format": "company_id"},
                        {"format": "entity_urn"},
                    ],
                    "examples": [
                        "dunder-mifflin",
                        "1337",
                        "urn:li:fsd_company:1337",
                    ],
                },
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["CompanyProfile"]},
            "id": {"type": "string"},
            "entity_urn": {"type": "string"},
            "name": {"type": "string"},
            "description": {"type": "string"},
            "public_identifier": {"type": "string"},
            "profile_url": {"type": "string", "format": "uri"},
            "website": {"type": "string", "format": "uri"},
            "logo": {"type": "string", "format": "uri"},
            "logo_large": {"type": "string", "format": "uri"},
            "tagline": {"type": "string"},
            "followers_count": {"type": "integer"},
            "employee_count": {"type": "integer"},
            "employee_count_range": {
                "type": "object",
                "properties": {
                    "from": {"type": "integer"},
                    "to": {"type": "integer"},
                },
            },
            "is_following": {"type": "boolean"},
            "is_employee": {"type": "boolean"},
            "claimed": {"type": "boolean"},
            "organization_type": {"type": "string", "enum": ["PUBLIC_COMPANY", "EDUCATIONAL", "SELF_EMPLOYED", "GOVERNMENT_AGENCY", "NON_PROFIT", "SELF_OWNED", "PRIVATELY_HELD", "PARTNERSHIP"]},
            "industry": {"type": "array", "items": {"type": "string"}},
            "activities": {"type": "array", "items": {"type": "string"}},
            "hashtags": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                    },
                },
            },
            "locations": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "is_headquarter": {"type": "boolean"},
                        "city": {"type": "string"},
                        "country": {"type": "string"},
                        "state": {"type": "string"},
                        "address": {"type": "string"},
                        "postal_code": {"type": "string"},
                    },
                },
            },
            "messaging": {
                "type": "object",
                "properties": {
                    "is_enabled": {"type": "boolean"},
                    "entity_urn": {"type": "string"},
                    "id": {"type": "string"},
                },
            },
            "viewer_permissions": {
                "type": "object",
                "properties": {
                    "canRequestAdminAccess": {"type": "boolean"},
                    "canSendMessages": {"type": "boolean"},
                },
            },
            "foundation_date": {"type": "string"},
            "phone": {"type": "string"},
            "insights": {
                "type": "object",
                "properties": {
                    "employeesCount": {"type": "integer"},
                },
            },
            "acquired_by": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "id": {"type": "string"},
                },
            },
            "crunchbase_funding": {
                "type": "object",
                "properties": {
                    "total_funding": {"type": "string"},
                    "last_round": {"type": "string"},
                },
            },
            "localized_name": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "locale": {"type": "string"},
                        "value": {"type": "string"},
                    },
                },
            },
            "localized_description": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "locale": {"type": "string"},
                        "value": {"type": "string"},
                    },
                },
            },
            "localized_tagline": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "locale": {"type": "string"},
                        "value": {"type": "string"},
                    },
                },
            },
        },
        "rate_limit": "50 company views/account/day",
        "example": {
            "input": {"path": {"id": "dunder-mifflin"}},
            "output": {
                "object": "CompanyProfile",
                "id": "1337",
                "entity_urn": "urn:li:fsd_company:1337",
                "name": "Dunder Mifflin Paper Company",
                "description": "Limitless paper in a paperless world. Founded in 1949, Dunder Mifflin serves small and medium businesses across the Northeast with dedicated reps and same-day delivery.",
                "tagline": "Limitless paper in a paperless world",
                "public_identifier": "dunder-mifflin",
                "profile_url": "https://www.linkedin.com/company/dunder-mifflin/",
                "website": "https://careers.dundermifflin.com",
                "logo": "https://media.licdn.com/dms/image/v2/dundermifflin/logo_200.jpg",
                "logo_large": "https://media.licdn.com/dms/image/v2/dundermifflin/logo_400.jpg",
                "hashtags": [{"title": "#dundiesawards"}, {"title": "#beetsbattlestar"}],
                "followers_count": 1842,
                "employee_count": 172,
                "employee_count_range": {"from": 51, "to": 200},
                "is_following": True,
                "is_employee": False,
                "claimed": True,
                "organization_type": None,
                "industry": ["Paper & Forest Products"],
                "activities": ["Paper Distribution", "Office Supplies", "Professional Networks"],
                "locations": [
                    {"is_headquarter": True, "city": "Scranton", "country": "US", "area": "PA", "street": ["1725 Slough Avenue"], "postalCode": "18505"},
                    {"is_headquarter": False, "city": "Utica", "country": "US", "area": "NY", "street": [], "postalCode": "13502"},
                ],
                "messaging": {"is_enabled": True, "entity_urn": "urn:li:fsd_pageMailbox:2102163", "id": "2102163"},
                "viewer_permissions": {"canRequestAdminAccess": True, "canSendMessages": False},
                "foundation_date": "1949",
                "phone": "+15705551942",
                "insights": {
                    "employeesCount": {
                        "totalCount": 172,
                        "averageTenure": "6.8 years",
                        "growthGraph": [{"monthRange": 12, "growthPercentage": 3}],
                    },
                },
                "acquired_by": None,
                "crunchbase_funding": None,
                "localized_name": [
                    {"locale": {"country": "US", "language": "en"}, "value": "Dunder Mifflin Paper Company"},
                ],
                "localized_description": [
                    {"locale": {"country": "US", "language": "en"}, "value": "Limitless paper in a paperless world."},
                ],
                "localized_tagline": [
                    {"locale": {"country": "US", "language": "en"}, "value": "Limitless paper in a paperless world"},
                ],
            },
        },
    },
)
@click.option("--id", required=True)
def retrieve_company(id, **_):
    return {"object": "CompanyProfile", **get(f"/linkedin/company/{id}")}


@command(
    name="parameters",
    full_name="linkedin search parameters",
    description="Use this command to look up LinkedIn filter IDs by keyword. Required before building filtered searches in `linkedin search classic` or `linkedin search sales navigator`.",
    schema={
        "endpoint": "/linkedin/search-parameters", "method": "GET",
        "input": {
            "query": {
                "type": {"type": "string", "required": True, "enum": ["LOCATION", "PEOPLE", "CONNECTIONS", "COMPANY", "SCHOOL", "INDUSTRY", "SERVICE", "JOB_FUNCTION", "JOB_TITLE", "EMPLOYMENT_TYPE", "SKILL", "GROUPS", "SALES_INDUSTRY", "DEPARTMENT", "PERSONA", "ACCOUNT_LISTS", "LEAD_LISTS", "TECHNOLOGIES", "SAVED_ACCOUNTS", "SAVED_SEARCHES", "RECENT_SEARCHES", "REGION", "POSTAL_CODE", "HIRING_PROJECTS", "SAVED_FILTERS", "DEGREE"]},
                "keywords": {"type": "string"},
                "service": {"type": "string", "enum": ["CLASSIC", "RECRUITER", "SALES_NAVIGATOR"], "default": "CLASSIC"},
                "limit": {"type": "integer", "default": 10, "minimum": 1, "maximum": 100},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["LinkedinSearchParametersList"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "object": {"type": "string"},
                        "id": {"type": "string"},
                        "title": {"type": "string"},
                    },
                },
            },
            "paging": {
                "type": "object",
                "properties": {
                    "page_count": {"type": "integer"},
                },
            },
        },
        "example": {
            "input": {
                "query": {
                    "type": "INDUSTRY",
                    "keywords": "paper",
                    "service": "CLASSIC",
                    "limit": 3,
                },
            },
            "output": {
                "object": "LinkedinSearchParametersList",
                "items": [
                    {"object": "LinkedinSearchParameter", "id": "61", "title": "Paper and Forest Product Manufacturing"},
                    {"object": "LinkedinSearchParameter", "id": "1212", "title": "Wholesale Paper Products"},
                ],
                "paging": {"page_count": 2},
            },
        },
    },
)
@click.option("--type", "param_type", required=True, help="Parameter type: INDUSTRY, LOCATION, JOB_TITLE, etc.")
@click.option("--keywords", default="", help="Keywords to filter parameters")
@click.option("--service", default="CLASSIC", help="LinkedIn service: CLASSIC | RECRUITER | SALES_NAVIGATOR")
@click.option("--limit", type=click.INT, default=10, help="Max results to return (1-100, default: 10)")
def search_parameters(param_type, keywords, service, limit, **_):
    params = {
        k: v
        for k, v in {
            "type": param_type,
            "keywords": keywords,
            "service": service,
            "limit": limit,
        }.items()
        if v
    }
    return {"object": "SearchParameters", **get("/linkedin/search-parameters", params=params)}


@command(
    name="invite",
    full_name="linkedin send invite",
    description="Use this command to send a LinkedIn connection request with an optional message (max 300 characters). Counts against the 25 invites/day limit. Prefer `task send invites` when the user wants to automate sending connection requests daily to leads in a campaign.",
    schema={
        "endpoint": "/linkedin/invite", "method": "POST",
        "input": {
            "body": {
                "provider_id": {"type": "string", "required": True},
                "message": {"type": "string"},
                "user_email": {"type": "string", "format": "email"},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["UserInvitationSent"]},
            "invitation_id": {"type": "string"},
            "usage": {"type": "number"},
        },
        "rate_limit": "25 invitations/day",
        "example": {
            "input": {
                "body": {
                    "provider_id": "danny-cordray",
                    "message": "Danny, impressed by your track record at Osprey Paper. Let's connect.",
                    "user_email": "danny@ospreypaper.com",
                },
            },
            "output": {
                "object": "UserInvitationSent",
                "invitation_id": "inv_cordray_osprey_001",
                "usage": 24,
            },
        },
    },
)
@click.option("--provider-id", "provider_id", required=True)
@click.option("--message", help="Connection note (max 300 chars)")
def send_invite(provider_id, message, **_):
    if message and len(message) > 300:
        error_stderr("NOTE_TOO_LONG", f"Message too long ({len(message)}/300)")
    body = {"provider_id": provider_id}
    if message:
        body["message"] = message
    return {"object": "Invitation", **post("/linkedin/invite", body)}


@command(
    name="relations",
    full_name="linkedin list relations",
    description="Use this command to list the user's LinkedIn 1st-degree connections.",
    schema={
        "endpoint": "/linkedin/relations", "method": "GET",
        "input": {
            "query": {
                "limit": {"type": "integer", "default": 20, "minimum": 1, "maximum": 1000},
                "cursor": {"type": "string"},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["UserRelationsList"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "object": {"type": "string"},
                        "connection_urn": {"type": "string"},
                        "created_at": {"type": "integer"},
                        "first_name": {"type": "string"},
                        "last_name": {"type": "string"},
                        "member_id": {"type": "string"},
                        "member_urn": {"type": "string"},
                        "headline": {"type": "string"},
                        "public_identifier": {"type": "string"},
                        "public_profile_url": {"type": "string", "format": "uri"},
                        "profile_picture_url": {"type": "string", "format": "uri"},
                    },
                },
            },
            "cursor": {"type": "string"},
        },
        "rate_limit": "100 relation lookups/account/day",
        "example": {
            "input": {
                "query": {
                    "limit": 2,
                    "cursor": "eyJsaW1pdCI6Miwic3RhcnRJbmRleCI6MH0=",
                },
            },
            "output": {
                "object": "UserRelationsList",
                "items": [
                    {
                        "object": "UserRelation",
                        "connection_urn": "urn:li:fsd_connection:ACoAAA1234pam567890beesly",
                        "created_at": 1775767498000,
                        "first_name": "Pam",
                        "last_name": "Beesly",
                        "member_id": "ACoAAA1234pam567890beesly",
                        "member_urn": "urn:li:fsd_profile:ACoAAA1234pam567890beesly",
                        "headline": "Office Administrator at Dunder Mifflin",
                        "public_identifier": "pam-beesly-halpert",
                        "public_profile_url": "https://www.linkedin.com/in/pam-beesly-halpert/",
                        "profile_picture_url": "https://media.licdn.com/dms/image/v2/pam/profile_100.jpg",
                    },
                    {
                        "object": "UserRelation",
                        "connection_urn": "urn:li:fsd_connection:ACoAAA1234ryan567890howard",
                        "created_at": 1775500000000,
                        "first_name": "Ryan",
                        "last_name": "Howard",
                        "member_id": "ACoAAA1234ryan567890howard",
                        "member_urn": "urn:li:fsd_profile:ACoAAA1234ryan567890howard",
                        "headline": "Founder at WUPHF.com",
                        "public_identifier": "ryan-howard-wuphf",
                        "public_profile_url": "https://www.linkedin.com/in/ryan-howard-wuphf/",
                        "profile_picture_url": "https://media.licdn.com/dms/image/v2/ryan/profile_100.jpg",
                    },
                ],
                "cursor": "eyJsaW1pdCI6Miwic3RhcnRJbmRleCI6Mn0=",
            },
        },
    },
)
@click.option("--limit", type=click.INT, default=20, help="Max connections to return (1-1000, default: 20)")
@click.option("--cursor", help="Pagination cursor from previous response")
def list_relations(limit, cursor, **_):
    params = {
        k: v
        for k, v in {"limit": limit, "cursor": cursor}.items()
        if v
    }
    return {"object": "Relations", **get("/linkedin/relations", params=params)}


@command(
    name="chats",
    full_name="linkedin list chats",
    description="Use this command to list the user's LinkedIn chats.",
    schema={
        "endpoint": "/linkedin/chats", "method": "GET",
        "input": {
            "query": {
                "limit": {"type": "integer", "default": 20, "minimum": 1, "maximum": 250},
                "cursor": {"type": "string"},
                "before": {"type": "string", "format": "date-time"},
                "after": {"type": "string", "format": "date-time"},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["ChatList"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "object": {"type": "string"},
                        "id": {"type": "string"},
                        "account_id": {"type": "string"},
                        "account_type": {"type": "string"},
                        "provider_id": {"type": "string"},
                        "attendee_provider_id": {"type": "string"},
                        "name": {"type": "string"},
                        "type": {"type": "integer"},
                        "timestamp": {"type": "string", "format": "date-time"},
                        "unread_count": {"type": "integer"},
                        "unread": {"type": "integer"},
                        "archived": {"type": "integer"},
                        "muted_until": {"type": "string"},
                        "read_only": {"type": "integer"},
                        "pinned": {"type": "integer"},
                        "folder": {"type": "array", "items": {"type": "string"}},
                        "disabledFeatures": {"type": "array", "items": {"type": "string"}},
                    },
                },
            },
            "cursor": {"type": "string"},
        },
        "rate_limit": "50 chat lookups/account/day",
        "example": {
            "input": {
                "query": {
                    "limit": 1,
                    "cursor": "eyJsaW1pdCI6MX0=",
                    "before": "2026-04-11T00:00:00.000Z",
                    "after": "2026-04-10T00:00:00.000Z",
                },
            },
            "output": {
                "object": "ChatList",
                "items": [
                    {
                        "object": "Chat",
                        "id": "chat_wallace_001",
                        "account_id": "hzxstXVkQiixkJGNgbhSSw",
                        "account_type": "LINKEDIN",
                        "provider_id": "2-NDBlNDRhM2EtMDllOS00NDQy",
                        "attendee_provider_id": "ACoAAAw4YPUBikVX_ShIPV5s",
                        "name": None,
                        "type": 0,
                        "timestamp": "2026-04-10T16:53:27.000Z",
                        "unread_count": 0,
                        "unread": 0,
                        "archived": 0,
                        "muted_until": None,
                        "read_only": 0,
                        "pinned": 0,
                        "folder": ["INBOX", "INBOX_LINKEDIN_CLASSIC"],
                        "disabledFeatures": [],
                    },
                ],
                "cursor": "eyJhY2NvdW50X2lkIjpbImh6eHN0WFZrUWlpeGtKR05nYmhTU3ciXSwibGltaXQiOjF9",
            },
        },
    },
)
@click.option("--limit", type=click.INT, default=20, help="Max conversations to return (1-250, default: 20)")
@click.option("--cursor", help="Pagination cursor from previous response")
@click.option("--before", help="ISO 8601 UTC, chats before this datetime (YYYY-MM-DDTHH:MM:SS.sssZ)")
@click.option("--after", help="ISO 8601 UTC, chats after this datetime (YYYY-MM-DDTHH:MM:SS.sssZ)")
def list_chats(limit, cursor, before, after, **_):
    params = {
        k: v
        for k, v in {
            "limit": limit,
            "cursor": cursor,
            "before": before,
            "after": after,
        }.items()
        if v
    }
    return {"object": "ChatList", **get("/linkedin/chats", params=params)}


@command(
    name="messages",
    full_name="linkedin list messages",
    description="Use this command to list all messages in a LinkedIn chat by `chat_id`. Prefer `linkedin list user messages` when the user has the `provider_id` instead.",
    schema={
        "endpoint": "/linkedin/chats/<chat_id>/messages", "method": "GET",
        "input": {
            "path": {
                "chat_id": {"type": "string", "required": True},
            },
            "query": {
                "limit": {"type": "integer", "default": 100, "minimum": 1, "maximum": 250},
                "cursor": {"type": "string"},
                "before": {"type": "string", "format": "date-time"},
                "after": {"type": "string", "format": "date-time"},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["MessageList"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "object": {"type": "string"},
                        "id": {"type": "string"},
                        "message_id": {"type": "string"},
                        "provider_id": {"type": "string"},
                        "chat_id": {"type": "string"},
                        "chat_provider_id": {"type": "string"},
                        "account_id": {"type": "string"},
                        "sender_id": {"type": "string"},
                        "sender_attendee_id": {"type": "string"},
                        "timestamp": {"type": "string", "format": "date-time"},
                        "text": {"type": "string"},
                        "subject": {"type": "string"},
                        "is_sender": {"type": "integer"},
                        "delivered": {"type": "integer"},
                        "seen": {"type": "integer"},
                        "seen_by": {"type": "object", "additionalProperties": {"type": "string"}},
                        "edited": {"type": "integer"},
                        "hidden": {"type": "integer"},
                        "deleted": {"type": "integer"},
                        "is_event": {"type": "integer"},
                        "behavior": {"type": "string"},
                        "original": {"type": "string"},
                        "attachments": {"type": "array", "items": {"type": "object", "properties": {}}},
                        "reactions": {"type": "array", "items": {"type": "object", "properties": {}}},
                        "message_type": {"type": "string"},
                        "attendee_type": {"type": "string"},
                    },
                },
            },
            "cursor": {"type": "string"},
        },
        "example": {
            "input": {
                "path": {
                    "chat_id": "chat_wallace_001",
                },
                "query": {
                    "limit": 1,
                    "cursor": "eyJsaW1pdCI6MX0=",
                    "before": "2026-04-11T00:00:00.000Z",
                    "after": "2026-04-10T00:00:00.000Z",
                },
            },
            "output": {
                "object": "MessageList",
                "items": [
                    {
                        "object": "Message",
                        "id": "msg_wallace_meeting_001",
                        "message_id": "msg_wallace_meeting_001",
                        "provider_id": "2-MTc3NTg0MDAwNzQ3OWI5NTAyMS0xMDA=",
                        "chat_id": "chat_wallace_001",
                        "chat_provider_id": "2-NDBlNDRhM2EtMDllOS00NDQy",
                        "account_id": "hzxstXVkQiixkJGNgbhSSw",
                        "sender_id": "ACoAABcD1234567890abcdefghijklmnopqrstuv",
                        "sender_attendee_id": "FuN-nc6rWQqoGW0dbe6ykg",
                        "timestamp": "2026-04-10T16:53:27.479Z",
                        "text": "Hi David, were you able to find a time?",
                        "subject": None,
                        "is_sender": 1,
                        "delivered": 1,
                        "seen": 0,
                        "seen_by": {},
                        "edited": 0,
                        "hidden": 0,
                        "deleted": 0,
                        "is_event": 0,
                        "behavior": None,
                        "original": "",
                        "attachments": [],
                        "reactions": [],
                        "message_type": "MESSAGE",
                        "attendee_type": "MEMBER",
                        "attendee_distance": 1,
                    },
                ],
                "cursor": "eyJsaW1pdCI6MSwiY2hhdF9pZCI6ImNoYXRfd2FsbGFjZV8wMDEifQ==",
            },
        },
    },
)
@click.option("--chat", "chat_id", required=True, help="Chat ID")
@click.option("--limit", type=click.INT, default=100, help="Max messages to return (1-250, default: 100)")
@click.option("--cursor", help="Pagination cursor from previous response")
@click.option("--before", help="ISO 8601 UTC, messages before this datetime")
@click.option("--after", help="ISO 8601 UTC, messages after this datetime")
def list_messages(chat_id, limit, cursor, before, after, **_):
    params = {
        k: v
        for k, v in {
            "limit": limit,
            "cursor": cursor,
            "before": before,
            "after": after,
        }.items()
        if v
    }
    return {"object": "MessageList", **get(f"/linkedin/chats/{chat_id}/messages", params=params)}


@command(
    name="messages",
    full_name="linkedin list user messages",
    description="Use this command to list LinkedIn messages with a specific user across any chat. Prefer `linkedin list messages` when the user wants all messages in one chat.",
    schema={
        "endpoint": "/linkedin/users/<provider_id>/messages", "method": "GET",
        "input": {
            "path": {
                "provider_id": {"type": "string", "required": True},
            },
            "query": {
                "limit": {"type": "integer", "default": 100, "minimum": 1, "maximum": 250},
                "cursor": {"type": "string"},
                "before": {"type": "string", "format": "date-time"},
                "after": {"type": "string", "format": "date-time"},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["MessageList"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "object": {"type": "string"},
                        "id": {"type": "string"},
                        "message_id": {"type": "string"},
                        "provider_id": {"type": "string"},
                        "chat_id": {"type": "string"},
                        "chat_provider_id": {"type": "string"},
                        "account_id": {"type": "string"},
                        "sender_id": {"type": "string"},
                        "sender_attendee_id": {"type": "string"},
                        "timestamp": {"type": "string", "format": "date-time"},
                        "text": {"type": "string"},
                        "subject": {"type": "string"},
                        "is_sender": {"type": "integer"},
                        "delivered": {"type": "integer"},
                        "seen": {"type": "integer"},
                        "seen_by": {"type": "object", "additionalProperties": {"type": "string"}},
                        "edited": {"type": "integer"},
                        "hidden": {"type": "integer"},
                        "deleted": {"type": "integer"},
                        "is_event": {"type": "integer"},
                        "behavior": {"type": "string"},
                        "original": {"type": "string"},
                        "attachments": {"type": "array", "items": {"type": "object", "properties": {}}},
                        "reactions": {"type": "array", "items": {"type": "object", "properties": {}}},
                        "message_type": {"type": "string"},
                        "attendee_type": {"type": "string"},
                    },
                },
            },
            "cursor": {"type": "string"},
        },
        "example": {
            "input": {
                "path": {
                    "provider_id": "ACoAAAw4YPUBikVX_ShIPV5s",
                },
                "query": {
                    "limit": 1,
                    "cursor": "eyJsaW1pdCI6MX0=",
                    "before": "2026-04-11T00:00:00.000Z",
                    "after": "2026-04-10T00:00:00.000Z",
                },
            },
            "output": {
                "object": "MessageList",
                "items": [
                    {
                        "object": "Message",
                        "id": "msg_wallace_reply_001",
                        "message_id": "msg_wallace_reply_001",
                        "provider_id": "2-MTc3NTY1MjIwOTQyNmI4MTA1MC0xMDA=",
                        "chat_id": "chat_wallace_001",
                        "chat_provider_id": "2-NDBlNDRhM2EtMDllOS00NDQy",
                        "account_id": "hzxstXVkQiixkJGNgbhSSw",
                        "sender_id": "ACoAAAw4YPUBikVX_ShIPV5s",
                        "sender_attendee_id": "29Y9e7XKWtWij-0_orb2fA",
                        "timestamp": "2026-04-08T12:43:29.426Z",
                        "text": "Sounds good. Send me a link and I'll book a time.",
                        "subject": None,
                        "is_sender": 0,
                        "delivered": 1,
                        "seen": 0,
                        "seen_by": {},
                        "edited": 0,
                        "hidden": 0,
                        "deleted": 0,
                        "is_event": 0,
                        "behavior": None,
                        "original": "",
                        "attachments": [],
                        "reactions": [],
                        "message_type": "MESSAGE",
                        "attendee_type": "MEMBER",
                        "attendee_distance": 1,
                    },
                ],
                "cursor": "eyJsaW1pdCI6MSwic2VuZGVyX2lkIjoiQUNvQUFBdzRZUFVCaWtWWF9TaElQVjVzIn0=",
            },
        },
    },
)
@click.option("--provider-id", "provider_id", required=True)
@click.option("--limit", type=click.INT, default=100, help="Max messages to return (1-250, default: 100)")
@click.option("--cursor", help="Pagination cursor from previous response")
@click.option("--before", help="ISO 8601 UTC, messages before this datetime")
@click.option("--after", help="ISO 8601 UTC, messages after this datetime")
def list_user_messages(provider_id, limit, cursor, before, after, **_):
    params = {
        k: v
        for k, v in {
            "limit": limit,
            "cursor": cursor,
            "before": before,
            "after": after,
        }.items()
        if v
    }
    return {
        "object": "MessageList",
        **get(f"/linkedin/users/{provider_id}/messages", params=params),
    }


@command(
    name="message",
    full_name="linkedin send message",
    description="Use this command to send a message in an existing LinkedIn chat. Counts against the 50 messages/day limit. Prefer `task followup` when the user wants to automate sending follow-ups daily to leads in a campaign. Prefer `linkedin start chat` when the chat does not exist.",
    schema={
        "endpoint": "/linkedin/chats/<chat_id>/messages", "method": "POST",
        "input": {
            "path": {
                "chat_id": {"type": "string", "required": True},
            },
            "body": {
                "text": {"type": "string", "required": True},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["MessageSent"]},
            "message_id": {"type": "string"},
        },
        "rate_limit": "50 messages/day",
        "example": {
            "input": {
                "path": {
                    "chat_id": "chat_wallace_001",
                },
                "body": {
                    "text": "David, I have a plan. It involves paper. And trust.",
                },
            },
            "output": {
                "object": "MessageSent",
                "message_id": "msg_wallace_plan_001",
            },
        },
    },
)
@click.option("--chat", "chat_id", required=True, help="Chat ID")
@click.option("--text", required=True, help="Message text")
def send_message(chat_id, text, **_):
    return {"object": "Message", **post(f"/linkedin/chats/{chat_id}/messages", {"text": text})}


@command(
    name="chat",
    full_name="linkedin start chat",
    description="Use this command to start a new LinkedIn chat with a user. Counts against the 50 messages/day limit. Prefer `linkedin send message` when the chat already exists.",
    schema={
        "endpoint": "/linkedin/chats", "method": "POST",
        "input": {
            "body": {
                "provider_id": {"type": "string", "required": True},
                "text": {"type": "string", "required": True},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["ChatStarted"]},
            "chat_id": {"type": "string"},
            "message_id": {"type": "string"},
        },
        "rate_limit": "50 messages/day",
        "example": {
            "input": {
                "body": {
                    "provider_id": "holly-flax",
                    "text": "Holly, this is Michael Scott. From the conference. The one who did the Chris Rock impression.",
                },
            },
            "output": {
                "object": "ChatStarted",
                "chat_id": "chat_holly_new_001",
                "message_id": "msg_holly_intro_001",
            },
        },
    },
)
@click.option("--provider-id", "provider_id", required=True)
@click.option("--text", required=True, help="First message text")
def start_chat(provider_id, text, **_):
    body = {"provider_id": provider_id, "text": text}
    return {"object": "Chat", **post("/linkedin/chats", body)}


def _search_post(api: str, category: str) -> dict:
    """Shared body for `linkedin search`. Reads filter JSON from stdin."""
    body = {**(input_stdin() or {}), "api": api, "category": category}
    return {"object": "SearchResults", **post("/linkedin/search", body)}


@command(
    name="leads",
    full_name="linkedin search classic leads",
    description="Use this command to search LinkedIn people by keyword, industry, location, or company. Counts against the 500 searches/day limit. Prefer `linkedin search sales navigator leads` when Sales Navigator is available for more detailed filtering.",
    schema={
        "endpoint": "/linkedin/search", "method": "POST",
        "input": {
            "body": {
                "keywords": {"type": "string"},
                "url": {"type": "string", "format": "uri"},
                "cursor": {"type": "string"},
                "limit": {"type": "integer", "default": 100, "minimum": 1, "maximum": 100},
                "industry": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "location": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "profile_language": {"type": "array", "items": {"type": "string"}},
                "network_distance": {"type": "array", "items": {"type": "string"}},
                "company": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "past_company": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "school": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "service": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "connections_of": {"type": "string"},
                "followers_of": {"type": "string"},
                "open_to": {"type": "array", "items": {"type": "string"}},
                "advanced_keywords": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string"},
                        "first_name": {"type": "string"},
                        "last_name": {"type": "string"},
                        "company": {"type": "string"},
                        "school": {"type": "string"},
                    },
                },
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["LinkedinSearch"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string"},
                        "id": {"type": "string"},
                        "industry": {"type": "string"},
                        "name": {"type": "string"},
                        "member_urn": {"type": "string"},
                        "public_identifier": {"type": "string"},
                        "profile_url": {"type": "string", "format": "uri"},
                        "public_profile_url": {"type": "string", "format": "uri"},
                        "profile_picture_url": {"type": "string", "format": "uri"},
                        "profile_picture_url_large": {"type": "string", "format": "uri"},
                        "network_distance": {"type": "string"},
                        "location": {"type": "string"},
                        "headline": {"type": "string"},
                    },
                },
            },
            "config": {
                "type": "object",
                "properties": {
                    "params": {"type": "object", "additionalProperties": {"type": "string"}},
                },
            },
            "paging": {
                "type": "object",
                "properties": {
                    "start": {"type": "integer"},
                    "page_count": {"type": "integer"},
                    "total_count": {"type": "integer"},
                },
            },
            "cursor": {"type": "string"},
            "metadata": {
                "type": "object",
                "properties": {
                    "result_type": {"type": "string"},
                    "api": {"type": "string"},
                },
            },
        },
        "rate_limit": "500 searches/account/day",
        "example": {
            "input": {
                "body": {
                    "keywords": "paper sales scranton",
                    "url": None,
                    "cursor": None,
                    "limit": 1,
                    "industry": {"include": ["61"]},
                    "location": {"include": ["103644278"]},
                    "profile_language": ["en"],
                    "network_distance": ["DISTANCE_1", "DISTANCE_2"],
                    "company": {"include": ["1337"]},
                    "past_company": None,
                    "school": None,
                    "service": None,
                    "connections_of": None,
                    "followers_of": None,
                    "open_to": None,
                    "advanced_keywords": None,
                },
            },
            "output": {
                "object": "LinkedinSearch",
                "items": [
                    {
                        "type": "PEOPLE",
                        "id": "ACoAAA1234dwight567890schrutefarms",
                        "industry": None,
                        "name": "Dwight Schrute",
                        "member_urn": "urn:li:member:818863195",
                        "public_identifier": "dwight-k-schrute",
                        "profile_url": "https://www.linkedin.com/in/dwight-k-schrute?miniProfileUrn=urn%3Ali%3Afs_miniProfile%3AACoAAA1234",
                        "public_profile_url": "https://www.linkedin.com/in/dwight-k-schrute",
                        "profile_picture_url": "https://media.licdn.com/dms/image/v2/schrute/profile_100.jpg",
                        "profile_picture_url_large": "https://media.licdn.com/dms/image/v2/schrute/profile_100.jpg",
                        "network_distance": "DISTANCE_1",
                        "location": "Scranton, PA",
                        "headline": "Assistant Regional Manager | Top Salesman at Dunder Mifflin",
                    },
                ],
                "config": {"params": {"api": "classic", "category": "people", "keywords": "paper sales scranton"}},
                "paging": {"start": 0, "page_count": 1, "total_count": 232},
                "cursor": "eyJhY2NvdW50X2lkIjoiaHp4c3RYVmtRaWl4a0pHTmdiaFNTdyIsImxpbWl0IjoxLCJzdGFydCI6MSwicGFyYW1zIjp7ImFwaSI6ImNsYXNzaWMiLCJjYXRlZ29yeSI6InBlb3BsZSIsImtleXdvcmRzIjoicGFwZXIgc2FsZXMgc2NyYW50b24ifX0=",
                "metadata": {"result_type": "people", "api": "classic"},
            },
        },
    },
)
def search_classic_leads(**_):
    return _search_post("classic", "people")


@command(
    name="accounts",
    full_name="linkedin search classic accounts",
    description="Use this command to search LinkedIn companies by keyword, industry, location, or headcount. Counts against the 500 searches/day limit. Prefer `linkedin search sales navigator accounts` when Sales Navigator is available for more detailed filtering.",
    schema={
        "endpoint": "/linkedin/search", "method": "POST",
        "input": {
            "body": {
                "keywords": {"type": "string"},
                "url": {"type": "string", "format": "uri"},
                "cursor": {"type": "string"},
                "limit": {"type": "integer", "default": 100, "minimum": 1, "maximum": 100},
                "industry": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "location": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "has_job_offers": {"type": "boolean"},
                "headcount": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "min": {"type": "integer"},
                                            "max": {"type": "integer"},
                                        },
                                    },
                                },
                "network_distance": {"type": "array", "items": {"type": "string"}},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["LinkedinSearch"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string"},
                        "id": {"type": "string"},
                        "name": {"type": "string"},
                        "profile_url": {"type": "string", "format": "uri"},
                        "summary": {"type": "string"},
                        "industry": {"type": "string"},
                        "location": {"type": "string"},
                        "logo": {"type": "string", "format": "uri"},
                        "followers_count": {"type": "integer"},
                        "job_offers_count": {"type": "integer"},
                    },
                },
            },
            "config": {
                "type": "object",
                "properties": {
                    "params": {"type": "object", "additionalProperties": {"type": "string"}},
                },
            },
            "paging": {
                "type": "object",
                "properties": {
                    "start": {"type": "integer"},
                    "page_count": {"type": "integer"},
                    "total_count": {"type": "integer"},
                },
            },
            "cursor": {"type": "string"},
            "metadata": {
                "type": "object",
                "properties": {
                    "result_type": {"type": "string"},
                    "api": {"type": "string"},
                },
            },
        },
        "rate_limit": "500 searches/account/day",
        "example": {
            "input": {
                "body": {
                    "keywords": "paper",
                    "url": None,
                    "cursor": None,
                    "limit": 1,
                    "industry": {"include": ["61"]},
                    "location": {"include": ["103644278"]},
                    "has_job_offers": True,
                    "headcount": ["B"],
                    "network_distance": ["DISTANCE_2"],
                },
            },
            "output": {
                "object": "LinkedinSearch",
                "items": [
                    {
                        "type": "COMPANY",
                        "id": "1337",
                        "name": "Dunder Mifflin Paper Company",
                        "profile_url": "https://www.linkedin.com/company/dunder-mifflin/",
                        "summary": "Limitless paper in a paperless world. Founded 1949. Dedicated reps, same-day delivery.",
                        "industry": "Paper & Forest Products",
                        "location": "Scranton, PA",
                        "logo": "https://media.licdn.com/dms/image/v2/dundermifflin/logo_100.jpg",
                        "followers_count": 1842,
                        "job_offers_count": 2,
                    },
                ],
                "config": {"params": {"api": "classic", "category": "companies", "keywords": "paper"}},
                "paging": {"start": 0, "page_count": 1, "total_count": 1000},
                "cursor": "eyJhY2NvdW50X2lkIjoiaHp4c3RYVmtRaWl4a0pHTmdiaFNTdyIsImxpbWl0IjoxLCJzdGFydCI6MSwicGFyYW1zIjp7ImFwaSI6ImNsYXNzaWMiLCJjYXRlZ29yeSI6ImNvbXBhbmllcyIsImtleXdvcmRzIjoicGFwZXIifX0=",
                "metadata": {"result_type": "companies", "api": "classic"},
            },
        },
    },
)
def search_classic_accounts(**_):
    return _search_post("classic", "companies")


@command(
    name="posts",
    full_name="linkedin search classic posts",
    description="Use this command to search LinkedIn posts. Counts against the 500 searches/day limit.",
    schema={
        "endpoint": "/linkedin/search", "method": "POST",
        "input": {
            "body": {
                "keywords": {"type": "string"},
                "url": {"type": "string", "format": "uri"},
                "cursor": {"type": "string"},
                "limit": {"type": "integer", "default": 100, "minimum": 1, "maximum": 100},
                "sort_by": {"type": "string", "enum": ["relevance", "date_posted"]},
                "date_posted": {"type": "string", "enum": ["past_24h", "past_week", "past_month"]},
                "content_type": {"type": "array", "items": {"type": "string"}},
                "posted_by": {"type": "string", "enum": ["me", "first_connections", "following"]},
                "mentioning": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "author": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["LinkedinSearch"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string"},
                        "provider": {"type": "string"},
                        "id": {"type": "string"},
                        "social_id": {"type": "string"},
                        "share_url": {"type": "string", "format": "uri"},
                        "date": {"type": "string"},
                        "parsed_datetime": {"type": "string", "format": "date-time"},
                        "text": {"type": "string"},
                        "is_repost": {"type": "boolean"},
                        "comment_counter": {"type": "integer"},
                        "impressions_counter": {"type": "integer"},
                        "reaction_counter": {"type": "integer"},
                        "repost_counter": {"type": "integer"},
                        "permissions": {
                            "type": "object",
                            "properties": {
                                "can_post_comments": {"type": "boolean"},
                                "can_react": {"type": "boolean"},
                                "can_share": {"type": "boolean"},
                            },
                        },
                        "mentions": {"type": "array", "items": {"type": "object", "properties": {}}},
                        "attachments": {"type": "array", "items": {"type": "object", "properties": {}}},
                        "author": {
                            "type": "object",
                            "properties": {
                                "id": {"type": "string"},
                                "public_identifier": {"type": "string"},
                                "name": {"type": "string"},
                                "is_company": {"type": "boolean"},
                                "headline": {"type": "string"},
                                "profile_picture_url": {"type": "string", "format": "uri"},
                            },
                        },
                    },
                },
            },
            "config": {
                "type": "object",
                "properties": {
                    "params": {"type": "object", "additionalProperties": {"type": "string"}},
                },
            },
            "paging": {
                "type": "object",
                "properties": {
                    "start": {"type": "integer"},
                    "page_count": {"type": "integer"},
                    "total_count": {"type": "integer"},
                },
            },
            "cursor": {"type": "string"},
            "metadata": {
                "type": "object",
                "properties": {
                    "result_type": {"type": "string"},
                    "api": {"type": "string"},
                },
            },
        },
        "rate_limit": "500 searches/account/day",
        "example": {
            "input": {
                "body": {
                    "keywords": "paper sales",
                    "url": None,
                    "cursor": None,
                    "limit": 1,
                    "sort_by": "date_posted",
                    "date_posted": "past_week",
                    "content_type": ["text"],
                    "posted_by": "first_connections",
                    "mentioning": None,
                    "author": None,
                },
            },
            "output": {
                "object": "LinkedinSearch",
                "items": [
                    {
                        "type": "POST",
                        "provider": "LINKEDIN",
                        "id": "7448554026914336768",
                        "social_id": "urn:li:activity:7448554026914336768",
                        "share_url": "https://www.linkedin.com/posts/michael-scott-scranton_activity-7448554026914336768",
                        "date": "2h",
                        "parsed_datetime": "2026-04-11T08:14:27.458Z",
                        "text": "Just booked the Michael Scott Paper Company's biggest client yet. Dundies all around!",
                        "is_repost": False,
                        "comment_counter": 12,
                        "impressions_counter": 847,
                        "reaction_counter": 42,
                        "repost_counter": 5,
                        "permissions": {"can_post_comments": True, "can_react": True, "can_share": True},
                        "mentions": [],
                        "attachments": [],
                        "author": {
                            "id": "ACoAABMSc1cDfGh3iJk4lM5nO6pQ7rS8tU9vWxY",
                            "public_identifier": "michael-scott-scranton",
                            "name": "Michael Scott",
                            "is_company": False,
                            "headline": "Regional Manager at Dunder Mifflin | World's Best Boss",
                            "profile_picture_url": "https://media.licdn.com/dms/image/v2/scranton/profile_100.jpg",
                        },
                    },
                ],
                "config": {"params": {"api": "classic", "category": "posts", "keywords": "paper sales"}},
                "paging": {"start": 0, "page_count": 1, "total_count": 498},
                "cursor": "eyJhY2NvdW50X2lkIjoiaHp4c3RYVmtRaWl4a0pHTmdiaFNTdyIsImxpbWl0IjoxLCJzdGFydCI6MSwicGFyYW1zIjp7ImFwaSI6ImNsYXNzaWMiLCJjYXRlZ29yeSI6InBvc3RzIiwia2V5d29yZHMiOiJwYXBlciBzYWxlcyJ9fQ==",
                "metadata": {"result_type": "posts", "api": "classic"},
            },
        },
    },
)
def search_classic_posts(**_):
    return _search_post("classic", "posts")


@command(
    name="jobs",
    full_name="linkedin search classic jobs",
    description="Use this command to search LinkedIn job postings. Counts against the 500 searches/day limit.",
    schema={
        "endpoint": "/linkedin/search", "method": "POST",
        "input": {
            "body": {
                "keywords": {"type": "string"},
                "url": {"type": "string", "format": "uri"},
                "cursor": {"type": "string"},
                "limit": {"type": "integer", "default": 100, "minimum": 1, "maximum": 100},
                "sort_by": {"type": "string", "enum": ["relevance", "date"]},
                "date_posted": {"type": "integer", "minimum": 1},
                "region": {"type": "string"},
                "location": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "location_within_area": {"type": "string"},
                "industry": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "seniority": {"type": "array", "items": {"type": "string"}},
                "function": {"type": "array", "items": {"type": "string"}},
                "role": {"type": "array", "items": {"type": "string"}},
                "job_type": {"type": "array", "items": {"type": "string"}},
                "company": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "presence": {"type": "array", "items": {"type": "string"}},
                "easy_apply": {"type": "boolean"},
                "has_verifications": {"type": "boolean"},
                "under_10_applicants": {"type": "boolean"},
                "in_your_network": {"type": "boolean"},
                "fair_chance_employer": {"type": "boolean"},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["LinkedinSearch"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string"},
                        "id": {"type": "string"},
                        "reference_id": {"type": "string"},
                        "title": {"type": "string"},
                        "location": {"type": "string"},
                        "posted_at": {"type": "string", "format": "date-time"},
                        "benefits": {"type": "array", "items": {"type": "string"}},
                        "reposted": {"type": "boolean"},
                        "url": {"type": "string", "format": "uri"},
                        "promoted": {"type": "boolean"},
                        "easy_apply": {"type": "boolean"},
                        "company": {
                            "type": "object",
                            "properties": {
                                "id": {"type": "string"},
                                "name": {"type": "string"},
                                "public_identifier": {"type": "string"},
                                "profile_url": {"type": "string", "format": "uri"},
                                "profile_picture_url": {"type": "string", "format": "uri"},
                            },
                        },
                    },
                },
            },
            "config": {
                "type": "object",
                "properties": {
                    "params": {"type": "object", "additionalProperties": {"type": "string"}},
                },
            },
            "paging": {
                "type": "object",
                "properties": {
                    "start": {"type": "integer"},
                    "page_count": {"type": "integer"},
                    "total_count": {"type": "integer"},
                },
            },
            "cursor": {"type": "string"},
            "metadata": {
                "type": "object",
                "properties": {
                    "result_type": {"type": "string"},
                    "api": {"type": "string"},
                },
            },
        },
        "rate_limit": "500 searches/account/day",
        "example": {
            "input": {
                "body": {
                    "keywords": "paper sales",
                    "url": None,
                    "cursor": None,
                    "limit": 1,
                    "sort_by": "date",
                    "date_posted": 7,
                    "region": None,
                    "location": {"include": ["103644278"]},
                    "location_within_area": None,
                    "industry": {"include": ["61"]},
                    "seniority": ["entry"],
                    "function": ["sales"],
                    "role": None,
                    "job_type": ["full_time"],
                    "company": None,
                    "presence": ["on_site"],
                    "easy_apply": True,
                    "has_verifications": False,
                    "under_10_applicants": False,
                    "in_your_network": False,
                    "fair_chance_employer": False,
                },
            },
            "output": {
                "object": "LinkedinSearch",
                "items": [
                    {
                        "type": "JOB",
                        "id": "4377936327",
                        "reference_id": "XdPesBjE6XATwAPTp7g0IA==",
                        "title": "Regional Sales Representative",
                        "location": "Scranton, PA (On-site)",
                        "posted_at": "2026-04-08T09:15:00.000Z",
                        "benefits": ["401(k)", "Dental", "Medical", "Vision"],
                        "reposted": False,
                        "url": "https://www.linkedin.com/jobs/view/4377936327",
                        "promoted": True,
                        "easy_apply": True,
                        "company": {
                            "id": "1337",
                            "name": "Dunder Mifflin Paper Company",
                            "public_identifier": "dunder-mifflin",
                            "profile_url": "https://www.linkedin.com/company/dunder-mifflin",
                            "profile_picture_url": "https://media.licdn.com/dms/image/v2/dundermifflin/logo_200.jpg",
                        },
                    },
                ],
                "config": {"params": {"api": "classic", "category": "jobs", "keywords": "paper sales"}},
                "paging": {"start": 0, "page_count": 1, "total_count": 935},
                "cursor": "eyJhY2NvdW50X2lkIjoiaHp4c3RYVmtRaWl4a0pHTmdiaFNTdyIsImxpbWl0IjoxLCJzdGFydCI6MSwicGFyYW1zIjp7ImFwaSI6ImNsYXNzaWMiLCJjYXRlZ29yeSI6ImpvYnMiLCJrZXl3b3JkcyI6InBhcGVyIHNhbGVzIn19",
                "metadata": {"result_type": "jobs", "api": "classic"},
            },
        },
    },
)
def search_classic_jobs(**_):
    return _search_post("classic", "jobs")


@command(
    name="leads",
    full_name="linkedin search sales navigator leads",
    description="Use this command to search LinkedIn leads in Sales Navigator with 40+ filters such as job position, function, company headcount, industry, and geography. Requires Sales Navigator. Counts against the 2500 searches/day limit. Prefer `linkedin search classic leads` when Sales Navigator is not available.",
    schema={
        "endpoint": "/linkedin/search", "method": "POST",
        "input": {
            "body": {
                "keywords": {"type": "string"},
                "url": {"type": "string", "format": "uri"},
                "cursor": {"type": "string"},
                "limit": {"type": "integer", "default": 100, "minimum": 1, "maximum": 100},
                "last_viewed_at": {"type": "string", "format": "date-time"},
                "saved_search_id": {"type": "string"},
                "recent_search_id": {"type": "string"},
                "location": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "location_by_postal_code": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "industry": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "first_name": {"type": "string"},
                "last_name": {"type": "string"},
                "tenure": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "min": {"type": "integer"},
                                            "max": {"type": "integer"},
                                        },
                                    },
                                },
                "groups": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "school": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "profile_language": {"type": "array", "items": {"type": "string"}},
                "company": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "company_headcount": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "min": {"type": "integer"},
                            "max": {"type": "integer"},
                        },
                    },
                },
                "company_type": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "company_location": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "tenure_at_company": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "min": {"type": "integer"},
                                            "max": {"type": "integer"},
                                        },
                                    },
                                },
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["LinkedinSearch"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string"},
                        "id": {"type": "string"},
                        "industry": {"type": "string"},
                        "name": {"type": "string"},
                        "first_name": {"type": "string"},
                        "last_name": {"type": "string"},
                        "member_urn": {"type": "string"},
                        "public_identifier": {"type": "string"},
                        "public_profile_url": {"type": "string", "format": "uri"},
                        "profile_url": {"type": "string", "format": "uri"},
                        "profile_picture_url": {"type": "string", "format": "uri"},
                        "profile_picture_url_large": {"type": "string", "format": "uri"},
                        "network_distance": {"type": "string"},
                        "location": {"type": "string"},
                        "headline": {"type": "string"},
                        "summary": {"type": "string"},
                        "pending_invitation": {"type": "boolean"},
                        "current_positions": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "company": {"type": "string"},
                                    "company_id": {"type": "string"},
                                    "company_url": {"type": "string", "format": "uri"},
                                    "location": {"type": "string"},
                                    "industry": {"type": "array", "items": {"type": "string"}},
                                    "role": {"type": "string"},
                                    "tenure_at_company": {"type": "object", "properties": {"years": {"type": "integer"}, "months": {"type": "integer"}}},
                                    "tenure_at_role": {"type": "object", "properties": {"years": {"type": "integer"}, "months": {"type": "integer"}}},
                                    "skills": {"type": "array", "items": {"type": "string"}},
                                    "start": {"type": "object", "properties": {"month": {"type": "integer"}, "year": {"type": "integer"}}},
                                },
                            },
                        },
                        "open_profile": {"type": "boolean"},
                        "premium": {"type": "boolean"},
                    },
                },
            },
            "config": {
                "type": "object",
                "properties": {
                    "params": {"type": "object", "additionalProperties": {"type": "string"}},
                },
            },
            "paging": {
                "type": "object",
                "properties": {
                    "start": {"type": "integer"},
                    "page_count": {"type": "integer"},
                    "total_count": {"type": "integer"},
                },
            },
            "cursor": {"type": "string"},
            "metadata": {
                "type": "object",
                "properties": {
                    "result_type": {"type": "string"},
                    "api": {"type": "string"},
                },
            },
        },
        "rate_limit": "2500 searches/account/day",
        "example": {
            "input": {
                "body": {
                    "keywords": "paper sales scranton",
                    "url": None,
                    "cursor": None,
                    "limit": 1,
                    "last_viewed_at": None,
                    "saved_search_id": None,
                    "recent_search_id": None,
                    "location": {"include": ["103644278"]},
                    "location_by_postal_code": None,
                    "industry": {"include": ["61"]},
                    "first_name": None,
                    "last_name": None,
                    "tenure": None,
                    "groups": None,
                    "school": None,
                    "profile_language": ["en"],
                    "company": None,
                    "company_headcount": [{"min": 51, "max": 200}],
                    "company_type": None,
                    "company_location": None,
                    "tenure_at_company": None,
                },
            },
            "output": {
                "object": "LinkedinSearch",
                "items": [
                    {
                        "type": "PEOPLE",
                        "id": "ACwAAA1234dwight567890schrutefarms",
                        "industry": None,
                        "name": "Dwight Schrute",
                        "first_name": "Dwight",
                        "last_name": "Schrute",
                        "member_urn": "urn:li:member:233965540",
                        "public_identifier": "dwight-k-schrute",
                        "public_profile_url": "https://www.linkedin.com/in/dwight-k-schrute",
                        "profile_url": "https://www.linkedin.com/sales/lead/ACwAAA1234dwight,NAME_SEARCH,5mCP",
                        "profile_picture_url": "https://media.licdn.com/dms/image/v2/schrute/profile_200.jpg",
                        "profile_picture_url_large": "https://media.licdn.com/dms/image/v2/schrute/profile_100.jpg",
                        "network_distance": "DISTANCE_1",
                        "location": "Scranton, Pennsylvania, United States",
                        "headline": "Assistant Regional Manager at Dunder Mifflin | Beet Farmer",
                        "summary": "Experienced Assistant Regional Manager (formerly Assistant to the Regional Manager) with a track record in paper sales, beet farming, and counterintelligence. Graduated top of his class at Cornell.",
                        "pending_invitation": False,
                        "current_positions": [
                            {
                                "company": "Dunder Mifflin Paper Company",
                                "company_id": "1337",
                                "company_url": "https://www.linkedin.com/company/dunder-mifflin",
                                "location": "Scranton, PA",
                                "industry": ["Paper & Forest Products"],
                                "role": "Assistant Regional Manager",
                                "tenure_at_company": {"years": 14, "months": 3},
                                "tenure_at_role": {"years": 2, "months": 1},
                                "skills": ["Sales", "Counterintelligence", "Beet Farming"],
                                "start": {"month": 3, "year": 2005},
                            },
                        ],
                        "open_profile": True,
                        "premium": False,
                    },
                ],
                "config": {"params": {"api": "sales_navigator", "category": "people", "keywords": "paper sales scranton"}},
                "paging": {"start": 0, "page_count": 1, "total_count": 98},
                "cursor": "eyJhY2NvdW50X2lkIjoiaHp4c3RYVmtRaWl4a0pHTmdiaFNTdyIsImxpbWl0IjoxLCJzdGFydCI6MSwicGFyYW1zIjp7ImFwaSI6InNhbGVzX25hdmlnYXRvciIsImNhdGVnb3J5IjoicGVvcGxlIiwia2V5d29yZHMiOiJwYXBlciBzYWxlcyBzY3JhbnRvbiJ9fQ==",
                "metadata": {"result_type": "people", "api": "sales_navigator"},
            },
        },
    },
)
def search_sales_navigator_leads(**_):
    return _search_post("sales_navigator", "people")


@command(
    name="accounts",
    full_name="linkedin search sales navigator accounts",
    description="Use this command to search LinkedIn accounts in Sales Navigator with 15+ filters such as revenue, company headcount, headquarters location, industry, and department headcount growth. Requires Sales Navigator. Counts against the 2500 searches/day limit. Prefer `linkedin search classic accounts` when Sales Navigator is not available.",
    schema={
        "endpoint": "/linkedin/search", "method": "POST",
        "input": {
            "body": {
                "keywords": {"type": "string"},
                "url": {"type": "string", "format": "uri"},
                "cursor": {"type": "string"},
                "limit": {"type": "integer", "default": 100, "minimum": 1, "maximum": 100},
                "last_viewed_at": {"type": "string", "format": "date-time"},
                "saved_search_id": {"type": "string"},
                "recent_search_id": {"type": "string"},
                "industry": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "location": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "location_by_postal_code": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "has_job_offers": {"type": "boolean"},
                "headcount": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "min": {"type": "integer"},
                                            "max": {"type": "integer"},
                                        },
                                    },
                                },
                "headcount_growth": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "min": {"type": "integer"},
                                            "max": {"type": "integer"},
                                        },
                                    },
                                },
                "department_headcount": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "min": {"type": "integer"},
                                            "max": {"type": "integer"},
                                        },
                                    },
                                },
                "department_headcount_growth": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "min": {"type": "integer"},
                                            "max": {"type": "integer"},
                                        },
                                    },
                                },
                "network_distance": {"type": "array", "items": {"type": "string"}},
                "annual_revenue": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "min": {"type": "integer"},
                                            "max": {"type": "integer"},
                                        },
                                    },
                                },
                "followers_count": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "min": {"type": "integer"},
                                            "max": {"type": "integer"},
                                        },
                                    },
                                },
                "fortune": {
                                    "type": "array",
                                    "items": {
                                        "type": "object",
                                        "properties": {
                                            "min": {"type": "integer"},
                                            "max": {"type": "integer"},
                                        },
                                    },
                                },
                "technologies": {
                                    "type": "object",
                                    "properties": {
                                        "include": {"type": "array", "items": {"type": "string"}},
                                        "exclude": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                "recent_activities": {"type": "array", "items": {"type": "string"}},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["LinkedinSearch"]},
            "items": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string"},
                        "id": {"type": "string"},
                        "name": {"type": "string"},
                        "profile_url": {"type": "string", "format": "uri"},
                        "summary": {"type": "string"},
                        "industry": {"type": "string"},
                        "location": {"type": "string"},
                        "headcount": {"type": "string"},
                        "logo": {"type": "string", "format": "uri"},
                    },
                },
            },
            "config": {
                "type": "object",
                "properties": {
                    "params": {"type": "object", "additionalProperties": {"type": "string"}},
                },
            },
            "paging": {
                "type": "object",
                "properties": {
                    "start": {"type": "integer"},
                    "page_count": {"type": "integer"},
                    "total_count": {"type": "integer"},
                },
            },
            "cursor": {"type": "string"},
            "metadata": {
                "type": "object",
                "properties": {
                    "result_type": {"type": "string"},
                    "api": {"type": "string"},
                },
            },
        },
        "rate_limit": "2500 searches/account/day",
        "example": {
            "input": {
                "body": {
                    "keywords": "paper",
                    "url": None,
                    "cursor": None,
                    "limit": 1,
                    "last_viewed_at": None,
                    "saved_search_id": None,
                    "recent_search_id": None,
                    "industry": {"include": ["61"]},
                    "location": {"include": ["103644278"]},
                    "location_by_postal_code": None,
                    "has_job_offers": True,
                    "headcount": [{"min": 51, "max": 200}],
                    "headcount_growth": None,
                    "department_headcount": None,
                    "department_headcount_growth": None,
                    "network_distance": ["DISTANCE_2"],
                    "annual_revenue": None,
                    "followers_count": None,
                    "fortune": None,
                    "technologies": None,
                    "recent_activities": None,
                },
            },
            "output": {
                "object": "LinkedinSearch",
                "items": [
                    {
                        "type": "COMPANY",
                        "id": "1337",
                        "name": "Dunder Mifflin Paper Company",
                        "profile_url": "https://www.linkedin.com/sales/company/1337",
                        "summary": "Limitless paper in a paperless world. Founded 1949. Regional paper supplier serving Scranton, Utica, and the Northeast with dedicated reps and same-day delivery.",
                        "industry": "Paper & Forest Products",
                        "location": "Scranton, PA",
                        "headcount": "172",
                        "logo": "https://media.licdn.com/dms/image/v2/dundermifflin/logo_400.jpg",
                    },
                ],
                "config": {"params": {"api": "sales_navigator", "category": "companies", "keywords": "paper"}},
                "paging": {"start": 0, "page_count": 1, "total_count": 106321},
                "cursor": "eyJhY2NvdW50X2lkIjoiaHp4c3RYVmtRaWl4a0pHTmdiaFNTdyIsImxpbWl0IjoxLCJzdGFydCI6MSwicGFyYW1zIjp7ImFwaSI6InNhbGVzX25hdmlnYXRvciIsImNhdGVnb3J5IjoiY29tcGFuaWVzIiwia2V5d29yZHMiOiJwYXBlciJ9fQ==",
                "metadata": {"result_type": "companies", "api": "sales_navigator"},
            },
        },
    },
)
def search_sales_navigator_accounts(**_):
    return _search_post("sales_navigator", "companies")

# Logged out.
