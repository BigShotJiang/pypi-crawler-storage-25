# *[scrolls through the sent folder]*

"""
outreach.py — The sent folder.

Every lead that's been contacted across all campaigns —
who received a message, when, and their response status.
"""

import click

from the_office_cli.cli.decorators import command
from the_office_cli.network.session import get

@command(
    name="list",
    description="Use this command to list all outreached leads in all campaigns. Prefer `lead list` when the user wants all leads.",
    schema={
        "endpoint": "/outreach", "method": "GET",
        "input": {
            "query": {
                "page": {"type": "integer", "default": 1},
                "per_page": {"type": "integer", "default": 10000},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "created_at": {"type": "string", "format": "date-time"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "company": {"type": "string"},
            "position": {"type": "string"},
            "link": {"type": "string", "format": "uri"},
            "score": {
                "type": "object",
                "properties": {
                    "bant": {"type": "integer"},
                    "icp_fit": {"type": "integer"},
                },
            },
            "campaign": {"type": "string"},
            "campaign_id": {"type": "integer"},
            "outreach_status": {"type": "string", "enum": ["no_response", "accepted", "responded"]},
            "outreached_at": {"type": "string", "format": "date-time"},
        },
        "example": {
            "input": {
                "query": {
                    "page": 1,
                    "per_page": 10000,
                },
            },
            "output": {
                "id": 42,
                "created_at": "2026-03-28T09:15:00+00:00",
                "first_name": "Andy",
                "last_name": "Bernard",
                "company": "Cornell Paper Co.",
                "position": "Director of Sales",
                "link": "https://linkedin.com/in/andy-bernard-cornell",
                "score": {"bant": 82, "icp_fit": 91},
                "campaign": "Operation Overthrow",
                "campaign_id": 1,
                "outreach_status": "accepted",
                "outreached_at": "2026-04-01T10:30:00+00:00",
            },
        },
    },
)
@click.option("--page", type=click.INT, default=1, help="Page number for pagination (default: 1)")
@click.option("--per-page", "per_page", type=click.INT, default=10000, help="Results per page (default: 10000)")
def list_(page, per_page, **_):
    return {
        "object": "OutreachList",
        **get("/outreach", params={"page": page, "per_page": per_page}),
    }

# Folder closed.
