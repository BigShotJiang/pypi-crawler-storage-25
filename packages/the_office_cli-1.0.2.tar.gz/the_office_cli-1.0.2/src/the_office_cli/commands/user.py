# *[pulls up the team list on the shared drive]*

"""
user.py — The sales team.

Who's on the floor — list, add, update, or remove
team members within a customer organization.
"""

import click

from the_office_cli.cli.decorators import command
from the_office_cli.network.session import delete, get, post, put

@command(
    name="list",
    description="Use this command to list all users in an organization.",
    schema={
        "endpoint": "/customers/<customer_id>/users", "method": "GET",
        "input": {
            "path": {
                "customer_id": {"type": "integer", "required": True},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "email": {"type": "string", "format": "email"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "role": {"type": "string"},
            "is_admin": {"type": "boolean"},
            "is_super_admin": {"type": "boolean"},
            "status": {"type": "string", "enum": ["OK", "CREDENTIALS", "CREATION_SUCCESS", "ERROR", "STOPPED"]},
            "account_id": {"type": "string"},
            "account_type": {"type": "string", "enum": ["LINKEDIN"]},
            "provider": {"type": "string", "enum": ["unipile"]},
            "provider_id": {"type": "string"},
            "allow_starting_new_chats": {"type": "boolean"},
            "outreach_hour": {"type": "integer", "minimum": 0, "maximum": 23},
            "outreach_days": {"type": "array", "items": {"type": "integer", "minimum": 0, "maximum": 6}},
            "last_outreach_at": {"type": "string", "format": "date-time"},
            "last_outreach_count": {"type": "integer"},
            "requires_2fa": {"type": "boolean"},
            "disconnected_at": {"type": "string", "format": "date-time"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
            "customer_id": {"type": "integer"},
        },
        "example": {
            "input": {
                "path": {
                    "customer_id": 1,
                },
            },
            "output": {
                "id": 1,
                "email": "michael@dundermifflin.com",
                "first_name": "Michael",
                "last_name": "Scott",
                "role": "Regional Manager",
                "is_admin": True,
                "is_super_admin": False,
                "status": "OK",
                "account_id": "sM8kR7nX9qLpVwBzHcFjTy",
                "account_type": "LINKEDIN",
                "provider": "unipile",
                "provider_id": "ACoAABMSc1cDfGh3iJk4lM5nO6pQ7rS8tU9vWxY",
                "allow_starting_new_chats": True,
                "outreach_hour": 10,
                "outreach_days": [1, 2, 3, 4, 5],
                "last_outreach_at": "2026-04-10T10:00:00+00:00",
                "last_outreach_count": 25,
                "requires_2fa": False,
                "disconnected_at": None,
                "created_at": "2026-01-15T08:30:00+00:00",
                "updated_at": "2026-04-10T10:00:00+00:00",
                "customer_id": 1,
            },
        },
    },
)
@click.option("--customer", "customer_id", type=click.INT, required=True, help="Organization ID")
def list_(customer_id, **_):
    return {
        "object": "UserList",
        "items": get(f"/customers/{customer_id}/users"),
    }

@command(
    name="get",
    description="Use this command to get a user in an organization.",
    schema={
        "endpoint": "/customers/<customer_id>/users/<user_id>", "method": "GET",
        "input": {
            "path": {
                "customer_id": {"type": "integer", "required": True},
                "user_id": {"type": "integer", "required": True},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "email": {"type": "string", "format": "email"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "role": {"type": "string"},
            "is_admin": {"type": "boolean"},
            "is_super_admin": {"type": "boolean"},
            "status": {"type": "string", "enum": ["OK", "CREDENTIALS", "CREATION_SUCCESS", "ERROR", "STOPPED"]},
            "account_id": {"type": "string"},
            "account_type": {"type": "string", "enum": ["LINKEDIN"]},
            "provider": {"type": "string", "enum": ["unipile"]},
            "provider_id": {"type": "string"},
            "allow_starting_new_chats": {"type": "boolean"},
            "outreach_hour": {"type": "integer", "minimum": 0, "maximum": 23},
            "outreach_days": {"type": "array", "items": {"type": "integer", "minimum": 0, "maximum": 6}},
            "last_outreach_at": {"type": "string", "format": "date-time"},
            "last_outreach_count": {"type": "integer"},
            "requires_2fa": {"type": "boolean"},
            "disconnected_at": {"type": "string", "format": "date-time"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
            "customer_id": {"type": "integer"},
        },
        "example": {
            "input": {
                "path": {
                    "customer_id": 1,
                    "user_id": 2,
                },
            },
            "output": {
                "id": 2,
                "email": "dwight@dundermifflin.com",
                "first_name": "Dwight",
                "last_name": "Schrute",
                "role": "Assistant Regional Manager",
                "is_admin": False,
                "is_super_admin": False,
                "status": "OK",
                "account_id": "dS3mK4pN7qLrVwBzHcFjTy",
                "account_type": "LINKEDIN",
                "provider": "unipile",
                "provider_id": "ACoAABDWs1cDfGh3iJk4lM5nO6pQ7rS8tU9vWxY",
                "allow_starting_new_chats": True,
                "outreach_hour": 9,
                "outreach_days": [1, 2, 3, 4, 5],
                "last_outreach_at": "2026-04-10T09:00:00+00:00",
                "last_outreach_count": 25,
                "requires_2fa": False,
                "disconnected_at": None,
                "created_at": "2026-01-15T08:30:00+00:00",
                "updated_at": "2026-04-10T09:00:00+00:00",
                "customer_id": 1,
            },
        },
    },
)
@click.option("--customer", "customer_id", type=click.INT, required=True, help="Organization ID")
@click.option("--user-id", "user_id", type=click.INT, required=True)
def get_(customer_id, user_id, **_):
    return {"object": "User", **get(f"/customers/{customer_id}/users/{user_id}")}

@command(
    name="create",
    description="Use this command to create a new user in an organization.",
    schema={
        "endpoint": "/customers/<customer_id>/users", "method": "POST",
        "input": {
            "path": {
                "customer_id": {"type": "integer", "required": True},
            },
            "body": {
                "email": {"type": "string", "format": "email", "required": True},
                "password": {"type": "string", "required": True},
            },
        },
        "output": {
            "message": {"type": "string"},
            "user": {
                "type": "object",
                "properties": {
                    "email": {"type": "string", "format": "email"},
                },
            },
        },
        "example": {
            "input": {
                "path": {
                    "customer_id": 1,
                },
                "body": {
                    "email": "ryan@dundermifflin.com",
                    "password": "wuphf2026",
                },
            },
            "output": {
                "message": "User created successfully!",
                "user": {"email": "ryan@dundermifflin.com"},
            },
        },
    },
    input_stdin=True,
    stdin_error="Pipe user JSON to stdin",
)
@click.option("--customer", "customer_id", type=click.INT, required=True, help="Organization ID")
def create(customer_id, _body, **_):
    return {"object": "User", **post(f"/customers/{customer_id}/users", _body)}

@command(
    name="update",
    description="Use this command to edit a user in an organization.",
    schema={
        "endpoint": "/customers/<customer_id>/users/<user_id>", "method": "PUT",
        "input": {
            "path": {
                "customer_id": {"type": "integer", "required": True},
                "user_id": {"type": "integer", "required": True},
            },
            "body": {
                "email": {"type": "string", "format": "email"},
                "password": {"type": "string"},
                "is_admin": {"type": "boolean"},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "email": {"type": "string", "format": "email"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "role": {"type": "string"},
            "is_admin": {"type": "boolean"},
            "is_super_admin": {"type": "boolean"},
            "status": {"type": "string", "enum": ["OK", "CREDENTIALS", "CREATION_SUCCESS", "ERROR", "STOPPED"]},
            "account_id": {"type": "string"},
            "account_type": {"type": "string", "enum": ["LINKEDIN"]},
            "provider": {"type": "string", "enum": ["unipile"]},
            "provider_id": {"type": "string"},
            "allow_starting_new_chats": {"type": "boolean"},
            "outreach_hour": {"type": "integer", "minimum": 0, "maximum": 23},
            "outreach_days": {"type": "array", "items": {"type": "integer", "minimum": 0, "maximum": 6}},
            "last_outreach_at": {"type": "string", "format": "date-time"},
            "last_outreach_count": {"type": "integer"},
            "requires_2fa": {"type": "boolean"},
            "disconnected_at": {"type": "string", "format": "date-time"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
            "customer_id": {"type": "integer"},
        },
        "example": {
            "input": {
                "path": {
                    "customer_id": 1,
                    "user_id": 2,
                },
                "body": {
                    "email": "dwight@dundermifflin.com",
                    "password": "fact-bears-beets-battlestar-galactica",
                    "is_admin": True,
                },
            },
            "output": {
                "id": 2,
                "email": "dwight@dundermifflin.com",
                "first_name": "Dwight",
                "last_name": "Schrute",
                "role": "Assistant (to the) Regional Manager",
                "is_admin": True,
                "is_super_admin": False,
                "status": "OK",
                "account_id": "dS3mK4pN7qLrVwBzHcFjTy",
                "account_type": "LINKEDIN",
                "provider": "unipile",
                "provider_id": "ACoAABDWs1cDfGh3iJk4lM5nO6pQ7rS8tU9vWxY",
                "allow_starting_new_chats": True,
                "outreach_hour": 9,
                "outreach_days": [1, 2, 3, 4, 5],
                "last_outreach_at": "2026-04-10T09:00:00+00:00",
                "last_outreach_count": 25,
                "requires_2fa": False,
                "disconnected_at": None,
                "created_at": "2026-01-15T08:30:00+00:00",
                "updated_at": "2026-04-11T14:20:00+00:00",
                "customer_id": 1,
            },
        },
    },
    input_stdin=True,
    stdin_error="Pipe JSON to stdin",
)
@click.option("--customer", "customer_id", type=click.INT, required=True, help="Organization ID")
@click.option("--user-id", "user_id", type=click.INT, required=True)
def update(customer_id, user_id, _body, **_):
    return {"object": "User", **put(f"/customers/{customer_id}/users/{user_id}", _body)}

@command(
    name="delete",
    description="Use this command to permanently delete a user from an organization.",
    schema={
        "endpoint": "/customers/<customer_id>/users/<user_id>", "method": "DELETE",
        "input": {
            "path": {
                "customer_id": {"type": "integer", "required": True},
                "user_id": {"type": "integer", "required": True},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "email": {"type": "string", "format": "email"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "role": {"type": "string"},
            "is_admin": {"type": "boolean"},
            "is_super_admin": {"type": "boolean"},
            "status": {"type": "string", "enum": ["OK", "CREDENTIALS", "CREATION_SUCCESS", "ERROR", "STOPPED"]},
            "account_id": {"type": "string"},
            "account_type": {"type": "string", "enum": ["LINKEDIN"]},
            "provider": {"type": "string", "enum": ["unipile"]},
            "provider_id": {"type": "string"},
            "allow_starting_new_chats": {"type": "boolean"},
            "outreach_hour": {"type": "integer", "minimum": 0, "maximum": 23},
            "outreach_days": {"type": "array", "items": {"type": "integer", "minimum": 0, "maximum": 6}},
            "last_outreach_at": {"type": "string", "format": "date-time"},
            "last_outreach_count": {"type": "integer"},
            "requires_2fa": {"type": "boolean"},
            "disconnected_at": {"type": "string", "format": "date-time"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
            "customer_id": {"type": "integer"},
        },
        "example": {
            "input": {
                "path": {
                    "customer_id": 1,
                    "user_id": 99,
                },
            },
            "output": {
                "id": 99,
                "email": "toby@dundermifflin.com",
                "first_name": "Toby",
                "last_name": "Flenderson",
                "role": "HR",
                "is_admin": False,
                "is_super_admin": False,
                "status": None,
                "account_id": None,
                "account_type": None,
                "provider": None,
                "provider_id": None,
                "allow_starting_new_chats": True,
                "outreach_hour": 14,
                "outreach_days": [0, 1, 2, 3, 4, 5, 6],
                "last_outreach_at": None,
                "last_outreach_count": 0,
                "requires_2fa": False,
                "disconnected_at": None,
                "created_at": "2026-02-01T08:00:00+00:00",
                "updated_at": "2026-02-01T08:00:00+00:00",
                "customer_id": 1,
            },
        },
    },
)
@click.option("--customer", "customer_id", type=click.INT, required=True, help="Organization ID")
@click.option("--user-id", "user_id", type=click.INT, required=True)
def delete_(customer_id, user_id, **_):
    return {"object": "User", **delete(f"/customers/{customer_id}/users/{user_id}")}

# Team updated.
