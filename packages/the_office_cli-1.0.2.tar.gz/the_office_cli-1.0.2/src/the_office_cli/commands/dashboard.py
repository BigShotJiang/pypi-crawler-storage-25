# *[checks the leaderboard by the coffee machine]*

"""
dashboard.py — The leaderboard.

Funnel numbers and conversation breakdowns — per user,
per campaign. Bare call returns both views. Subcommands
for funnel-only or conversations-only.
"""

import click

from the_office_cli.cli.decorators import command
from the_office_cli.network.session import get
from the_office_cli.utils.output import output_stdout


@click.group(
    "dashboard",
    invoke_without_command=True,
    help="Funnel + conversations. Bare call returns both (2 subcommands for focused views).",
)
@click.pass_context
def group(ctx: click.Context) -> None:
    """Bare `the-office dashboard` — returns both funnel and conversations."""
    if ctx.invoked_subcommand is not None:
        return
    output_stdout({
        "object": "Dashboard",
        "funnel": get("/dashboard"),
        "conversations": get("/response_categories"),
    })


@command(
    name="funnel",
    full_name="dashboard funnel",
    description="Use this command to get the pipeline — total leads, outreached, accepted, and conversations. Prefer `dashboard conversations` when the user wants the conversations breakdown.",
    schema={
        "endpoint": "/dashboard", "method": "GET",
        "input": {},
        "output": {
            "users": {
                "type": "object",
                "additionalProperties": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "integer"},
                        "name": {"type": "string"},
                    },
                },
            },
            "campaigns": {
                "type": "object",
                "additionalProperties": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "integer"},
                        "name": {"type": "string"},
                    },
                },
            },
            "metrics": {
                "type": "object",
                "additionalProperties": {
                    "type": "object",
                    "additionalProperties": {
                        "type": "object",
                        "additionalProperties": {
                            "type": "object",
                            "properties": {
                                "value": {"type": "integer"},
                            },
                        },
                    },
                },
            },
        },
        "example": {
            "input": {},
            "output": {
                "users": {
                    "1": {"id": 1, "name": "Michael"},
                    "2": {"id": 2, "name": "Dwight"},
                },
                "campaigns": {
                    "1": {"id": 1, "name": "Operation Overthrow"},
                    "2": {"id": 2, "name": "Pretzel Day Outreach"},
                },
                "metrics": {
                    "1": {
                        "1": {
                            "step_1": {"value": 150},
                            "step_2": {"value": 42},
                            "step_3": {"value": 18},
                            "step_4": {"value": 7},
                        },
                        "2": {
                            "step_1": {"value": 80},
                            "step_2": {"value": 20},
                            "step_3": {"value": 9},
                            "step_4": {"value": 3},
                        },
                    },
                },
            },
        },
    },
)
def funnel(**_):
    return {"object": "Dashboard", **get("/dashboard")}

@command(
    name="conversations",
    full_name="dashboard conversations",
    description="Use this command to get the conversations broken down by sentiment (positive, neutral, negative), then by subcategory (e.g. booked meeting under positive, requested more info under neutral, not interested under negative), with a one-sentence summary per conversation (e.g. \"Sure send me your Calendly link\" for booked meeting). Prefer `dashboard funnel` when the user wants the pipeline breakdown.",
    schema={
        "endpoint": "/response_categories", "method": "GET",
        "input": {
            "query": {
                "user_id": {"type": "integer"},
                "campaign_id": {"type": "integer"},
            },
        },
        "output": {
            "users": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "integer"},
                        "name": {"type": "string"},
                    },
                },
            },
            "campaigns": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "integer"},
                        "name": {"type": "string"},
                    },
                },
            },
            "nodes": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string"},
                        "nodeColor": {"type": "string"},
                        "sentence": {"type": "string"},
                        "chat_id": {"type": "string"},
                    },
                },
            },
            "links": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "source": {"type": "string"},
                        "target": {"type": "string"},
                        "value": {"type": "integer"},
                    },
                },
            },
        },
        "example": {
            "input": {
                "query": {
                    "user_id": 1,
                    "campaign_id": 1,
                },
            },
            "output": {
                "users": [
                    {"id": 1, "name": "Michael"},
                    {"id": 2, "name": "Dwight"},
                ],
                "campaigns": [
                    {"id": 1, "name": "Operation Overthrow"},
                ],
                "nodes": [
                    {"id": "Leads", "nodeColor": "#73C2FB"},
                    {"id": "Outreached", "nodeColor": "#73C2FB"},
                    {"id": "Accepted", "nodeColor": "#35A854"},
                    {"id": "Conversations", "nodeColor": "#35A854"},
                    {"id": "Positive", "nodeColor": "#35A854"},
                    {"id": "Neutral", "nodeColor": "#CEB740"},
                    {"id": "Negative", "nodeColor": "#CE4040"},
                    {"id": "Booked Meeting", "nodeColor": "#35A854"},
                    {
                        "id": "4197",
                        "sentence": "Yes, send it over. Michael Scott Paper Company is interested.",
                        "nodeColor": "#35A854",
                        "chat_id": "chat_wallace_001",
                    },
                ],
                "links": [
                    {"source": "Leads", "target": "Outreached", "value": 42},
                    {"source": "Outreached", "target": "Accepted", "value": 18},
                    {"source": "Accepted", "target": "Conversations", "value": 7},
                    {"source": "Conversations", "target": "Positive", "value": 3},
                    {"source": "Conversations", "target": "Neutral", "value": 2},
                    {"source": "Conversations", "target": "Negative", "value": 2},
                    {"source": "Positive", "target": "Booked Meeting", "value": 1},
                    {"source": "Booked Meeting", "target": "4197", "value": 1},
                ],
            },
        },
    },
)
@click.option("--user", "user_id", type=click.INT, help="Filter Sankey to a single user's campaigns")
@click.option("--campaign", "campaign_id", type=click.INT, help="Filter Sankey to a single campaign")
def conversations(user_id, campaign_id, **_):
    params = {k: v for k, v in {"user_id": user_id, "campaign_id": campaign_id}.items() if v}
    return {
        "object": "ResponseCategories",
        **get("/response_categories", params=params),
    }

# Leaderboard updated.
