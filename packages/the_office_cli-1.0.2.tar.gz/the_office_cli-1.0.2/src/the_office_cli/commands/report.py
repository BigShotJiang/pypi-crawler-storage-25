# *[leans back, Friday afternoon, pulls up the report]*

"""
report.py — End of week.

A sales report with the pipeline (outreached, accepted,
responded) and a conversations breakdown by sentiment
(positive, neutral, negative) with a one-sentence summary
per conversation. Totals plus per-user, for any date range.
"""

import click

from the_office_cli.cli.decorators import command
from the_office_cli.network.session import get

@command(
    name="report",
    full_name="report",
    description=(
        "Use this command to get a sales report for a date range. First, the pipeline — "
        "outreached, accepted, and responded. Second, the conversations broken down by "
        "sentiment (positive, neutral, negative), then by subcategory (e.g. booked meeting "
        "under positive, requested info under neutral, not interested under negative), "
        "with a one-sentence summary per conversation."
    ),
    schema={
        "endpoint": "/reports", "method": "GET",
        "input": {
            "query": {
                "from": {"type": "string", "format": "date"},
                "to": {"type": "string", "format": "date"},
                "user_id": {"type": "integer"},
            },
        },
        "output": {
            "object": {"type": "string", "enum": ["Report"]},
            "from": {"type": "string", "format": "date"},
            "to": {"type": "string", "format": "date"},
            "totals": {
                "type": "object",
                "properties": {
                    "outreached": {"type": "integer"},
                    "accepted": {
                        "type": "object",
                        "properties": {
                            "count": {"type": "integer"},
                            "rate": {"type": "number"},
                        },
                    },
                    "responded": {
                        "type": "object",
                        "properties": {
                            "count": {"type": "integer"},
                            "rate": {"type": "number"},
                            "positive": {
                                "type": "object",
                                "properties": {
                                    "count": {"type": "integer"},
                                    "rate": {"type": "number"},
                                },
                                "additionalProperties": {
                                    "type": "object",
                                    "properties": {
                                        "count": {"type": "integer"},
                                        "rate": {"type": "number"},
                                        "sentence": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                            },
                            "neutral": {
                                "type": "object",
                                "properties": {
                                    "count": {"type": "integer"},
                                    "rate": {"type": "number"},
                                },
                                "additionalProperties": {
                                    "type": "object",
                                    "properties": {
                                        "count": {"type": "integer"},
                                        "rate": {"type": "number"},
                                        "sentence": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                            },
                            "negative": {
                                "type": "object",
                                "properties": {
                                    "count": {"type": "integer"},
                                    "rate": {"type": "number"},
                                },
                                "additionalProperties": {
                                    "type": "object",
                                    "properties": {
                                        "count": {"type": "integer"},
                                        "rate": {"type": "number"},
                                        "sentence": {"type": "array", "items": {"type": "string"}},
                                    },
                                },
                            },
                        },
                    },
                },
            },
            "users": {
                "type": "object",
                "additionalProperties": {
                    "type": "object",
                    "properties": {
                        "outreached": {"type": "integer"},
                        "accepted": {
                            "type": "object",
                            "properties": {
                                "count": {"type": "integer"},
                                "rate": {"type": "number"},
                            },
                        },
                        "responded": {
                            "type": "object",
                            "properties": {
                                "count": {"type": "integer"},
                                "rate": {"type": "number"},
                                "positive": {
                                    "type": "object",
                                    "properties": {
                                        "count": {"type": "integer"},
                                        "rate": {"type": "number"},
                                    },
                                    "additionalProperties": {
                                        "type": "object",
                                        "properties": {
                                            "count": {"type": "integer"},
                                            "rate": {"type": "number"},
                                            "sentence": {"type": "array", "items": {"type": "string"}},
                                        },
                                    },
                                },
                                "neutral": {
                                    "type": "object",
                                    "properties": {
                                        "count": {"type": "integer"},
                                        "rate": {"type": "number"},
                                    },
                                    "additionalProperties": {
                                        "type": "object",
                                        "properties": {
                                            "count": {"type": "integer"},
                                            "rate": {"type": "number"},
                                            "sentence": {"type": "array", "items": {"type": "string"}},
                                        },
                                    },
                                },
                                "negative": {
                                    "type": "object",
                                    "properties": {
                                        "count": {"type": "integer"},
                                        "rate": {"type": "number"},
                                    },
                                    "additionalProperties": {
                                        "type": "object",
                                        "properties": {
                                            "count": {"type": "integer"},
                                            "rate": {"type": "number"},
                                            "sentence": {"type": "array", "items": {"type": "string"}},
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            },
        },
        "example": {
            "input": {
                "query": {
                    "from": "2026-04-23",
                    "to": "2026-04-30",
                    "user_id": 1,
                },
            },
            "output": {
                "object": "Report",
                "from": "2026-04-23",
                "to": "2026-04-30",
                "totals": {
                    "outreached": 42,
                    "accepted": {"count": 18, "rate": 0.4286},
                    "responded": {
                        "count": 8,
                        "rate": 0.1905,
                        "positive": {
                            "count": 3,
                            "rate": 0.0714,
                            "booked_meeting": {
                                "count": 3,
                                "rate": 0.0714,
                                "sentence": [
                                    "Sure — Tuesday at 2pm works.",
                                    "Send the calendar invite.",
                                    "Calendar's open Wednesday — let's talk.",
                                ],
                            },
                        },
                        "neutral": {
                            "count": 3,
                            "rate": 0.0714,
                            "requested_info": {
                                "count": 2,
                                "rate": 0.0476,
                                "sentence": [
                                    "Send a one-pager I can forward to my CFO.",
                                    "Got pricing I can review first?",
                                ],
                            },
                            "using_competitor": {
                                "count": 1,
                                "rate": 0.0238,
                                "sentence": [
                                    "We're already with Staples.",
                                ],
                            },
                        },
                        "negative": {
                            "count": 2,
                            "rate": 0.0476,
                            "not_interested": {
                                "count": 2,
                                "rate": 0.0476,
                                "sentence": [
                                    "Not the right time for us.",
                                    "Pass for now.",
                                ],
                            },
                        },
                    },
                },
                "users": {
                    "michael@dundermifflin.com": {
                        "outreached": 42,
                        "accepted": {"count": 18, "rate": 0.4286},
                        "responded": {
                            "count": 8,
                            "rate": 0.1905,
                            "positive": {
                                "count": 3,
                                "rate": 0.0714,
                                "booked_meeting": {
                                    "count": 3,
                                    "rate": 0.0714,
                                    "sentence": [
                                        "Sure — Tuesday at 2pm works.",
                                        "Send the calendar invite.",
                                        "Calendar's open Wednesday — let's talk.",
                                    ],
                                },
                            },
                            "neutral": {
                                "count": 3,
                                "rate": 0.0714,
                                "requested_info": {
                                    "count": 2,
                                    "rate": 0.0476,
                                    "sentence": [
                                        "Send a one-pager I can forward to my CFO.",
                                        "Got pricing I can review first?",
                                    ],
                                },
                                "using_competitor": {
                                    "count": 1,
                                    "rate": 0.0238,
                                    "sentence": [
                                        "We're already with Staples.",
                                    ],
                                },
                            },
                            "negative": {
                                "count": 2,
                                "rate": 0.0476,
                                "not_interested": {
                                    "count": 2,
                                    "rate": 0.0476,
                                    "sentence": [
                                        "Not the right time for us.",
                                        "Pass for now.",
                                    ],
                                },
                            },
                        },
                    },
                },
            },
        },
    },
)
@click.option("--from", "from_date", help="Start date in YYYY-MM-DD format (default: yesterday)")
@click.option("--to", "to_date", help="End date in YYYY-MM-DD format (default: yesterday)")
@click.option("--user", "user_id", type=click.INT, help="Admin only: filter report to a specific teammate in the same customer org")
def generate(from_date, to_date, user_id, **_):
    params = {k: v for k, v in {"from": from_date, "to": to_date, "user_id": user_id}.items() if v}
    return {"object": "Report", **get("/reports", params=params)}

# Week closed.
