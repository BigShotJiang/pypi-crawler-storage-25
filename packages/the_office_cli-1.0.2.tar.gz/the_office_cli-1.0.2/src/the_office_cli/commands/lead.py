# *[Dwight pulls up the prospect spreadsheet]*

"""
lead.py — The prospect list.

Every lead lives here — add one, import a batch,
update their profile, or remove them from a campaign.
"""

import json
import sys

import click

from the_office_cli.cli.decorators import command
from the_office_cli.network.session import delete, get, post, put
from the_office_cli.utils.output import error_stderr

@command(
    name="list",
    description="Use this command to list leads in a campaign with `--campaign`, or all leads in all campaigns with `--all`. One of `--campaign` or `--all` is required. Prefer `outreach list` when the user only wants the outreached leads.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/leads OR /all_leads", "method": "GET",
        "input": {
            "path": {
                "campaign_id": {"type": "integer"},
            },
            "query": {
                "page": {"type": "integer", "default": 1},
                "per_page": {"type": "integer", "default": 10},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "link": {"type": "string", "format": "uri"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "company": {"type": "string"},
            "position": {"type": "string"},
            "score": {
                "type": "object",
                "properties": {
                    "bant": {"type": "integer"},
                    "icp_fit": {"type": "integer"},
                },
            },
            "campaign_id": {"type": "integer"},
            "campaign": {"type": "string"},
            "created_at": {"type": "string", "format": "date-time"},
            "status": {"type": "string", "enum": ["waiting", "outreached", "failed", "accepted", "responded"]},
            "location": {"type": "string"},
            "time_in_role": {"type": "string"},
            "time_in_company": {"type": "string"},
            "outreach_status": {"type": "string", "enum": ["no_response", "accepted", "responded"]},
            "outreached_at": {"type": "string", "format": "date-time"},
            "failed_at": {"type": "string", "format": "date-time"},
            "outreach_failed_reason": {"type": "string"},
            "accepted_at": {"type": "string", "format": "date-time"},
            "responded_at": {"type": "string", "format": "date-time"},
            "followed_up_at": {"type": "string", "format": "date-time"},
            "follow_up_timestamps": {
                "type": "array",
                "items": {"type": "string", "format": "date-time"},
            },
            "provider_id": {"type": "string"},
            "classic_provider_id": {"type": "string"},
            "public_identifier": {"type": "string"},
            "chat_id": {"type": "string"},
            "personalized_note": {"type": "string", "maxLength": 300},
            "personalized_at": {"type": "string", "format": "date-time"},
            "retrieve_profile_failed": {"type": "string", "format": "date-time"},
            "hubspot_contact_id": {"type": "string"},
            "hubspot_lifecycle_stage": {"type": "string"},
            "hubspot_lifecycle_stage_occurred_at": {"type": "string", "format": "date-time"},
            "hubspot_deal_stage": {"type": "string"},
            "hubspot_deal_stage_occurred_at": {"type": "string", "format": "date-time"},
            "hubspot_deal_id": {"type": "string"},
            "hubspot_deal_amount": {"type": "number"},
            "hubspot_sync_pending": {"type": "boolean"},
            "hubspot_synced_at": {"type": "string", "format": "date-time"},
            "hubspot_sync_error": {"type": "string"},
            "updated_at": {"type": "string", "format": "date-time"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 1,
                },
                "query": {
                    "page": 1,
                    "per_page": 10,
                },
            },
            "output": {
                "id": 42,
                "link": "https://linkedin.com/in/stanley-hudson-scranton",
                "first_name": "Stanley",
                "last_name": "Hudson",
                "company": "Staples",
                "position": "Regional Sales Rep",
                "campaign": "Operation Overthrow",
                "location": "Scranton, PA",
                "time_in_role": "8 years",
                "time_in_company": "12 years",
                "score": {"bant": 78, "icp_fit": 85},
                "status": "waiting",
                "outreach_status": "no_response",
                "outreached_at": None,
                "failed_at": None,
                "outreach_failed_reason": None,
                "accepted_at": None,
                "responded_at": None,
                "followed_up_at": None,
                "follow_up_timestamps": [],
                "provider_id": "ACwAAABxyz123",
                "classic_provider_id": None,
                "public_identifier": "stanley-hudson-scranton",
                "chat_id": None,
                "personalized_note": None,
                "personalized_at": None,
                "retrieve_profile_failed": None,
                "hubspot_contact_id": None,
                "hubspot_lifecycle_stage": None,
                "hubspot_lifecycle_stage_occurred_at": None,
                "hubspot_deal_stage": None,
                "hubspot_deal_stage_occurred_at": None,
                "hubspot_deal_id": None,
                "hubspot_deal_amount": None,
                "hubspot_sync_pending": False,
                "hubspot_synced_at": None,
                "hubspot_sync_error": None,
                "campaign_id": 1,
                "created_at": "2026-03-20T14:00:00+00:00",
                "updated_at": "2026-03-20T14:00:00+00:00",
            },
        },
    },
)
@click.option("--campaign", "campaign_id", type=click.INT, help="Scope to one campaign")
@click.option("--all", "all_", is_flag=True, help="List every lead across all campaigns")
@click.option("--page", type=click.INT, default=1, help="Page number (default: 1)")
@click.option("--per-page", "per_page", type=click.INT, default=10, help="Results per page (default: 10)")
def list_(campaign_id, all_, page, per_page, **_):
    if not campaign_id and not all_:
        error_stderr("INVALID_INPUT", "Pass --campaign <id> or --all")
    if campaign_id and all_:
        error_stderr("INVALID_INPUT", "Pass either --campaign or --all, not both")
    params = {"page": page, "per_page": per_page}
    if campaign_id:
        return {
            "object": "LeadList",
            "items": get(f"/campaigns/{campaign_id}/leads", params=params),
        }
    return {
        "object": "LeadList",
        **get("/all_leads", params=params),
    }

@command(
    name="get",
    description="Use this command to get a lead in a campaign.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/leads/<id>", "method": "GET",
        "input": {
            "path": {
                "campaign_id": {"type": "integer", "required": True},
                "lead_id": {"type": "integer", "required": True},
            },
        },
        "output": {
            "id": {"type": "integer"},
            "link": {"type": "string", "format": "uri"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "company": {"type": "string"},
            "position": {"type": "string"},
            "location": {"type": "string"},
            "time_in_role": {"type": "string"},
            "time_in_company": {"type": "string"},
            "score": {
                "type": "object",
                "properties": {
                    "bant": {"type": "integer"},
                    "icp_fit": {"type": "integer"},
                },
            },
            "status": {"type": "string", "enum": ["waiting", "outreached", "failed", "accepted", "responded"]},
            "outreach_status": {"type": "string", "enum": ["no_response", "accepted", "responded"]},
            "outreached_at": {"type": "string", "format": "date-time"},
            "failed_at": {"type": "string", "format": "date-time"},
            "outreach_failed_reason": {"type": "string"},
            "accepted_at": {"type": "string", "format": "date-time"},
            "responded_at": {"type": "string", "format": "date-time"},
            "followed_up_at": {"type": "string", "format": "date-time"},
            "follow_up_timestamps": {
                "type": "array",
                "items": {"type": "string", "format": "date-time"},
            },
            "provider_id": {"type": "string"},
            "classic_provider_id": {"type": "string"},
            "public_identifier": {"type": "string"},
            "chat_id": {"type": "string"},
            "personalized_note": {"type": "string", "maxLength": 300},
            "personalized_at": {"type": "string", "format": "date-time"},
            "retrieve_profile_failed": {"type": "string", "format": "date-time"},
            "hubspot_contact_id": {"type": "string"},
            "hubspot_lifecycle_stage": {"type": "string"},
            "hubspot_lifecycle_stage_occurred_at": {"type": "string", "format": "date-time"},
            "hubspot_deal_stage": {"type": "string"},
            "hubspot_deal_stage_occurred_at": {"type": "string", "format": "date-time"},
            "hubspot_deal_id": {"type": "string"},
            "hubspot_deal_amount": {"type": "number"},
            "hubspot_sync_pending": {"type": "boolean"},
            "hubspot_synced_at": {"type": "string", "format": "date-time"},
            "hubspot_sync_error": {"type": "string"},
            "campaign_id": {"type": "integer"},
            "created_at": {"type": "string", "format": "date-time"},
            "updated_at": {"type": "string", "format": "date-time"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 1,
                    "lead_id": 42,
                },
            },
            "output": {
                "id": 42,
                "link": "https://linkedin.com/in/jan-levinson-whitepages",
                "first_name": "Jan",
                "last_name": "Levinson",
                "company": "White Pages",
                "position": "VP Sales",
                "location": "New York, NY",
                "time_in_role": "2 years",
                "time_in_company": "2 years",
                "score": {"bant": 94, "icp_fit": 88},
                "status": "outreached",
                "outreach_status": "accepted",
                "outreached_at": "2026-04-01T10:30:00+00:00",
                "failed_at": None,
                "outreach_failed_reason": None,
                "accepted_at": "2026-04-02",
                "responded_at": None,
                "followed_up_at": None,
                "follow_up_timestamps": [],
                "provider_id": "ACwAAABjanLev456",
                "classic_provider_id": None,
                "public_identifier": "jan-levinson-whitepages",
                "chat_id": "chat_levinson_001",
                "personalized_note": "Jan, saw your keynote at the Northeast Paper Conference. Impressive pivot to digital.",
                "personalized_at": "2026-04-01T10:25:00+00:00",
                "retrieve_profile_failed": None,
                "hubspot_contact_id": None,
                "hubspot_lifecycle_stage": None,
                "hubspot_lifecycle_stage_occurred_at": None,
                "hubspot_deal_stage": None,
                "hubspot_deal_stage_occurred_at": None,
                "hubspot_deal_id": None,
                "hubspot_deal_amount": None,
                "hubspot_sync_pending": False,
                "hubspot_synced_at": None,
                "hubspot_sync_error": None,
                "campaign_id": 1,
                "created_at": "2026-03-25T11:00:00+00:00",
                "updated_at": "2026-04-02T09:15:00+00:00",
            },
        },
    },
)
@click.option("--campaign", "campaign_id", type=click.INT, required=True, help="Campaign ID the lead belongs to")
@click.option("--lead-id", "lead_id", type=click.INT, required=True)
def get_(campaign_id, lead_id, **_):
    return {"object": "Lead", **get(f"/campaigns/{campaign_id}/leads/{lead_id}")}

@command(
    name="create",
    description="Use this command to create a single lead in a campaign. Prefer `lead import` when adding leads in a batch to a campaign.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/leads", "method": "POST",
        "input": {
            "path": {
                "campaign_id": {"type": "integer", "required": True},
            },
            "body": {
                "link": {"type": "string", "format": "uri", "required": True},
                "first_name": {"type": "string"},
                "last_name": {"type": "string"},
                "company": {"type": "string"},
                "position": {"type": "string"},
                "location": {"type": "string"},
                "time_in_role": {"type": "string"},
                "time_in_company": {"type": "string"},
                "score": {
                    "type": "object",
                    "properties": {
                        "bant": {"type": "integer"},
                        "icp_fit": {"type": "integer"},
                    },
                },
            },
        },
        "output": {
            "message": {"type": "string"},
            "id": {"type": "integer"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 1,
                },
                "body": {
                    "link": "https://linkedin.com/in/karen-filippelli",
                    "first_name": "Karen",
                    "last_name": "Filippelli",
                    "company": "Utica Branch",
                    "position": "Sales Rep",
                    "location": "Utica, NY",
                    "time_in_role": "1 year",
                    "time_in_company": "1 year",
                    "score": {"bant": 90, "icp_fit": 85},
                },
            },
            "output": {
                "message": "Lead created successfully!",
                "id": 43,
            },
        },
    },
    input_stdin=True,
    stdin_error="Pipe lead JSON to stdin",
)
@click.option(
    "--campaign", "campaign_id", type=click.INT,
    callback=lambda ctx, _p, v: v if ctx.resilient_parsing or v is not None else error_stderr(
        "INVALID_INPUT",
        "Leads live inside a campaign. Pass an existing campaign id with --campaign, or create one with `the-office campaign create custom`.",
    ),
)
def create(campaign_id, _body, **_):
    return {"object": "Lead", **post(f"/campaigns/{campaign_id}/leads", _body)}

@command(
    name="update",
    description="Use this command to edit a lead in a campaign.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/leads/<id>", "method": "PUT",
        "input": {
            "path": {
                "campaign_id": {"type": "integer", "required": True},
                "lead_id": {"type": "integer", "required": True},
            },
            "body": {
                "link": {"type": "string", "format": "uri"},
                "first_name": {"type": "string"},
                "last_name": {"type": "string"},
                "company": {"type": "string"},
                "position": {"type": "string"},
                "location": {"type": "string"},
                "time_in_role": {"type": "string"},
                "time_in_company": {"type": "string"},
                "score": {
                    "type": "object",
                    "properties": {
                        "bant": {"type": "integer"},
                        "icp_fit": {"type": "integer"},
                    },
                },
            },
        },
        "output": {
            "message": {"type": "string"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 1,
                    "lead_id": 42,
                },
                "body": {
                    "link": "https://linkedin.com/in/jan-levinson-utica",
                    "first_name": "Jan",
                    "last_name": "Levinson",
                    "company": "Dunder Mifflin Utica",
                    "position": "VP Sales",
                    "location": "Utica, NY",
                    "time_in_role": "3 years",
                    "time_in_company": "3 years",
                    "score": {"bant": 95, "icp_fit": 92},
                },
            },
            "output": {"message": "Lead updated successfully!"},
        },
    },
    input_stdin=True,
    stdin_error="Pipe JSON to stdin",
)
@click.option("--campaign", "campaign_id", type=click.INT, required=True, help="Campaign ID the lead belongs to")
@click.option("--lead-id", "lead_id", type=click.INT, required=True)
def update(campaign_id, lead_id, _body, **_):
    return {"object": "Lead", **put(f"/campaigns/{campaign_id}/leads/{lead_id}", _body)}

@command(
    name="delete",
    description="Use this command to permanently delete a lead from a campaign.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/leads/<id>", "method": "DELETE",
        "input": {
            "path": {
                "campaign_id": {"type": "integer", "required": True},
                "lead_id": {"type": "integer", "required": True},
            },
        },
        "output": {
            "message": {"type": "string"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 1,
                    "lead_id": 99,
                },
            },
            "output": {"message": "Lead deleted successfully!"},
        },
    },
)
@click.option("--campaign", "campaign_id", type=click.INT, required=True, help="Campaign ID the lead belongs to")
@click.option("--lead-id", "lead_id", type=click.INT, required=True)
def delete_(campaign_id, lead_id, **_):
    return {"object": "Lead", **delete(f"/campaigns/{campaign_id}/leads/{lead_id}")}

@command(
    name="import",
    full_name="lead import",
    description="Use this command to upload leads in a batch to a campaign. Prefer `lead create` when adding a single lead to a campaign.",
    schema={
        "endpoint": "/campaigns/<campaign_id>/leads/bulk_insert", "method": "POST",
        "input": {
            "path": {
                "campaign_id": {"type": "integer", "required": True},
            },
            "body": {
                "link": {"type": "string", "format": "uri", "required": True},
                "first_name": {"type": "string"},
                "last_name": {"type": "string"},
                "company": {"type": "string"},
                "position": {"type": "string"},
                "location": {"type": "string"},
                "time_in_role": {"type": "string"},
                "time_in_company": {"type": "string"},
                "score": {
                    "type": "object",
                    "properties": {
                        "bant": {"type": "integer"},
                        "icp_fit": {"type": "integer"},
                    },
                },
            },
        },
        "output": {
            "message": {"type": "string"},
        },
        "example": {
            "input": {
                "path": {
                    "campaign_id": 1,
                },
                "body": {
                    "link": "https://linkedin.com/in/todd-packer",
                    "first_name": "Todd",
                    "last_name": "Packer",
                    "company": "Dunder Mifflin",
                    "position": "Traveling Salesman",
                    "location": "Scranton, PA",
                    "time_in_role": "5 years",
                    "time_in_company": "10 years",
                    "score": {"bant": 70, "icp_fit": 60},
                },
            },
            "output": {"message": "Leads created successfully!"},
        },
    },
)
@click.option(
    "--campaign", "campaign_id", type=click.INT,
    callback=lambda ctx, _p, v: v if ctx.resilient_parsing or v is not None else error_stderr(
        "INVALID_INPUT",
        "Leads live inside a campaign. Pass an existing campaign id with --campaign, or create one with `the-office campaign create custom`.",
    ),
)
@click.option("--input", "input_file", help="JSONL file path (or pipe via stdin)")
def batch_create(campaign_id, input_file, **_):
    # Read JSONL from --input if set, otherwise from stdin.
    if input_file:
        with open(input_file) as f:
            lines = [ln.strip() for ln in f if ln.strip()]
    else:
        lines = [ln.strip() for ln in sys.stdin if ln.strip()]

    items = [json.loads(ln) for ln in lines]
    if not items:
        error_stderr("INVALID_INPUT", "No items provided")
    for item in items:
        if not item.get("link"):
            error_stderr("INVALID_INPUT", "Each item requires 'link' field")

    result = post(f"/campaigns/{campaign_id}/leads/bulk_insert", items)
    return {"object": "BatchResult", **result, "total": len(items)}

# List updated.
