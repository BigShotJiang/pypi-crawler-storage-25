# *[looks up at the sales board, picks up the marker]*

"""
output.py — The scoreboard.

Every command ends here — success goes on the board,
errors get chalked in red. Two functions, two exits.
"""

import json
import sys

import click

EXIT_SUCCESS = 0
EXIT_ERROR = 1
EXIT_RATE_LIMITED = 2

def output_stdout(data: dict) -> None:
    """Deal closed. Write the win on the board and walk away."""
    click.echo(json.dumps({"result": "success", **data}))
    sys.exit(EXIT_SUCCESS)

def error_stderr(
    code: str,
    message: str,
    exit_code: int = EXIT_ERROR,
    retry: bool = False,
    retry_after: int | None = None,
) -> None:
    """Deal lost. Chalk the error in red and call it a day."""
    err: dict = {"result": "error", "code": code, "message": message, "retry": retry}
    if retry_after is not None:
        err["retry_after"] = retry_after
    click.echo(json.dumps(err), err=True)
    sys.exit(exit_code)

# Board updated.
