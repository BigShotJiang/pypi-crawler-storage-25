# *[Michael stands up, claps hands, "Let me show you around"]*

"""
registry.py — Michael's office tour.

Every command gets a stop on the tour when it's registered.
The tour command walks agents through the full list —
who does what, where to find them.
"""

import click

_REGISTRY: list[dict] = []

def register(
    group: click.Group,
    cmd: click.Command,
    group_name: str | None = None,
) -> None:
    """Add a stop to the tour — attach the command to its
    group and log it in the itinerary."""
    config = getattr(cmd, "_command_config", None)
    if config is None:
        raise RuntimeError(
            f"Command {cmd.name!r} was added to a group without @command(...) metadata"
        )
    config["_group"] = group_name or group.name
    _REGISTRY.append(config)
    group.add_command(cmd)

def get_registry() -> list[dict]:
    """Hand over the full tour itinerary."""
    return _REGISTRY

# And that's Dunder Mifflin.
