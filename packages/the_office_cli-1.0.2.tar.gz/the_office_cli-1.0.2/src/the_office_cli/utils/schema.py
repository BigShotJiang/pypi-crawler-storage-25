# *[fans out the brochures on the conference table]*

"""
schema.py — The product brochure.

Every command can hand you its brochure — the full spec
via --schema, or a one-liner for the tour menu.
"""

import json
import sys

import click

from the_office_cli.network.errors import ERROR_CODES
from the_office_cli.utils.output import EXIT_SUCCESS

SCHEMA_VERSION = "2.0"

def _build_schema(config: dict) -> dict:
    """Build the full brochure — endpoint, inputs, outputs,
    error codes, and examples."""
    s = config["schema"]
    schema = {
        "command": config.get("full_name") or config["name"],
        "description": config.get("description", ""),
        "endpoint": {"path": s["endpoint"], "method": s["method"]},
        "input": s.get("input", {}),
        "output": s.get("output", {}),
        "error": {
            "result": "error",
            "code": " | ".join(ERROR_CODES),
            "message": "string",
            "retry": "boolean — true = safe to retry, false = fix input first",
            "retry_after": "integer | null — seconds to wait (only on RATE_LIMIT)",
        },
        "confirm_required": s.get("method") == "DELETE",
        "dry_run": True,
        **({"rate_limit": s["rate_limit"]} if s.get("rate_limit") else {}),
        "exit_codes": {"0": "success", "1": "error", "2": "rate_limited"},
    }
    if s.get("example"):
        schema["example"] = s["example"]
    return schema

def build_tour_schema(config: dict) -> dict:
    """Build the business card version — group, command,
    description, endpoint."""
    s = config["schema"]
    group = config.get("_group", "")
    command = config.get("full_name") or (
        f"{group} {config['name']}" if group else config["name"]
    )
    return {
        "group": group,
        "command": command,
        "description": config.get("description", ""),
        "endpoint": {"path": s["endpoint"], "method": s["method"]},
    }

def print_schema(config: dict) -> None:
    """Hand over the brochure and exit before the meeting
    starts."""
    click.echo(json.dumps(_build_schema(config)))
    sys.exit(EXIT_SUCCESS)

# Brochures on the table.
