# *[sets up the projector in the conference room]*

"""
decorators.py — Sales training.

Before a command hits the floor, it goes through
training — learns the script (validation), does a
dry run (preview), and gets cleared for live calls.
"""

import json
import sys
from typing import Callable

import click

from the_office_cli.cli.flags import (
    confirm_option,
    dry_run_option,
    idempotency_key_option,
    schema_option,
)
from the_office_cli.network.errors import ApiError
from the_office_cli.network import session
from the_office_cli.network.session import set_idempotency_key
from the_office_cli.utils.output import EXIT_SUCCESS, error_stderr, output_stdout
from the_office_cli.utils.schema import print_schema

def _read_stdin(schema: dict, stdin_error: str) -> dict:
    """Read the training materials. If the basics are
    missing, you're not ready for the floor."""
    body = session.input_stdin()
    if not body:
        error_stderr("INVALID_INPUT", stdin_error)
    for field_name, field_def in schema.get("input", {}).items():
        if (
            isinstance(field_def, dict)
            and field_def.get("required")
            and field_name not in body
        ):
            error_stderr("INVALID_INPUT", f"Missing required field: {field_name}")
    return body

def _print_dry_run(command: str, schema: dict, kwargs: dict) -> None:
    """Roleplay the call without a real client on the
    line — practice round, then stop."""
    click.echo(
        json.dumps(
            {
                "result": "dry_run",
                "command": command,
                "would_call": {
                    "method": schema["method"],
                    "endpoint": schema["endpoint"],
                },
                "with_options": {
                    k: v for k, v in kwargs.items() if v is not None
                },
            }
        )
    )
    sys.exit(EXIT_SUCCESS)

def _require_confirm(command: str) -> None:
    """Firing a client is permanent. Say it out loud
    first. DELETEs need --confirm."""
    error_stderr("CONFIRMATION_REQUIRED", f"Pass --confirm to execute: {command}")

def _execute(fn: Callable, kwargs: dict) -> None:
    """Training's over. Make the real call. If it lands,
    print the win. If not, file the loss."""
    try:
        result = fn(**kwargs)
        result = _apply_pagination(result, kwargs)
        output_stdout(result)
    except ApiError as e:
        error_stderr(
            e.code,
            str(e),
            exit_code=e.exit_code,
            retry=e.retry,
            retry_after=e.retry_after,
        )
    except SystemExit:
        raise
    except Exception as e:
        error_stderr("UNKNOWN_ERROR", str(e))

def _apply_pagination(result: dict, kwargs: dict) -> dict:
    """When the call returns a long list, add page numbers
    so the caller knows where they are."""
    if "items" not in result:
        return result
    page = kwargs.get("page")
    per_page = kwargs.get("per_page")
    if page is None or per_page is None:
        return result
    items = result["items"]
    result["page"] = page
    result["per_page"] = per_page
    if isinstance(items, list):
        result["has_next"] = len(items) >= per_page
    return result

def command(
    *,
    name: str,
    description: str,
    schema: dict,
    full_name: str | None = None,
    input_stdin: bool = False,
    stdin_error: str = "Pipe JSON to stdin",
) -> Callable[[Callable], click.Command]:
    """Sales training — turn a plain function into a command
    that knows the script and can handle errors."""

    def decorator(fn: Callable) -> click.Command:
        user_params = list(reversed(getattr(fn, "__click_params__", [])))
        params: list[click.Parameter] = list(user_params)

        params.append(dry_run_option())

        method = schema.get("method", "GET")
        if method in ("POST", "PUT"):
            params.append(idempotency_key_option())
        if method == "DELETE":
            params.append(confirm_option())

        config: dict = {
            "name": name,
            "description": description,
            "schema": schema,
            "full_name": full_name,
        }

        params.append(schema_option(_schema_callback(config)))

        command_name = full_name or name

        def callback(**kwargs):
            dry_run = kwargs.pop("dry_run", False)
            confirm = kwargs.pop("confirm", False)
            idempotency_key = kwargs.pop("idempotency_key", None)
            set_idempotency_key(idempotency_key)

            if input_stdin:
                kwargs["_body"] = _read_stdin(schema, stdin_error)

            if dry_run:
                _print_dry_run(command_name, schema, kwargs)

            if method == "DELETE" and not confirm:
                _require_confirm(command_name)

            _execute(fn, kwargs)

        cmd = click.Command(
            name=name,
            callback=callback,
            params=params,
            help=description,
        )
        cmd._command_config = config
        return cmd

    return decorator

def _schema_callback(config: dict):
    """Hand out the product sheet before training starts
    — print the contract and exit."""

    def cb(ctx, _param, value):
        if not value or ctx.resilient_parsing:
            return
        print_schema(config)

    return cb

# Training complete. You're cleared for the floor.
