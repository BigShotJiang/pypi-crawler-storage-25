# *[opens the employee handbook to the rules page]*

"""
flags.py — The employee handbook.

Standard flags every command carries — schema, dry-run,
idempotency, confirm. Added at build time so nobody
has to remember them.
"""

import click

def schema_option(callback) -> click.Option:
    """--schema — show the command's full contract and exit
    before anything runs."""
    return click.Option(
        ["--schema"],
        is_flag=True,
        is_eager=True,
        expose_value=False,
        callback=callback,
        help="Print the command's full JSON contract (input, output, example) and exit",
    )

def dry_run_option() -> click.Option:
    """--dry-run — rehearse the call without dialing."""
    return click.Option(
        ["--dry-run", "dry_run"],
        is_flag=True,
        help="Validate inputs and show what would execute, no API call",
    )

def idempotency_key_option() -> click.Option:
    """--idempotency-key — a receipt number so retries don't
    send the same thing twice."""
    return click.Option(
        ["--idempotency-key", "idempotency_key"],
        hidden=True,
        help=(
            "UUID for safe retries — same key = same result, "
            "prevents double-sends"
        ),
    )

def confirm_option() -> click.Option:
    """--confirm — required for DELETEs. No accidental
    shredding."""
    return click.Option(
        ["--confirm"],
        is_flag=True,
        help="Confirm the destructive operation",
    )

# Handbook closed.
