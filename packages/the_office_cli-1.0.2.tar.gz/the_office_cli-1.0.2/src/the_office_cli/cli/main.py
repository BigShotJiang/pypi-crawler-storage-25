# *[taps the directory board by the elevator]*

"""
cli/main.py — The sales floor directory.

Every command is listed here under its department. Pure
wiring — no business logic, just which group owns what.
"""

from importlib.metadata import version

import click

from the_office_cli.commands import (
    account,
    auth,
    campaign,
    dashboard,
    lead,
    linkedin,
    info,
    outreach,
    report,
    settings,
    user,
)
from the_office_cli.utils.registry import register


@click.group()
@click.version_option(version("the-office-cli"))
def cli() -> None:
    """The Office — AI Sales Agent CLI. JSON in, JSON out."""


# Auth
register(cli, auth.login, group_name="auth")
register(cli, auth.logout, group_name="auth")
register(cli, auth.whoami, group_name="auth")
register(cli, auth.create_account, group_name="auth")
register(cli, auth.fire_drill, group_name="auth")

# Campaign
campaign_group = click.Group("campaign", help="Campaign management (8 commands)")
register(campaign_group, campaign.list_)
register(campaign_group, campaign.get_)
register(campaign_group, campaign.update)
register(campaign_group, campaign.delete_)
register(campaign_group, campaign.status)

create_group = click.Group("create", help="Create campaign (custom | ai | signals)")
register(create_group, campaign.create_custom, group_name="campaign")
register(create_group, campaign.create_ai, group_name="campaign")
register(create_group, campaign.create_signals, group_name="campaign")
campaign_group.add_command(create_group)

cli.add_command(campaign_group)

# Lead
lead_group = click.Group("lead", help="Lead management (6 commands)")
register(lead_group, lead.list_)
register(lead_group, lead.get_)
register(lead_group, lead.create)
register(lead_group, lead.update)
register(lead_group, lead.delete_)
register(lead_group, lead.batch_create)
cli.add_command(lead_group)

# LinkedIn
linkedin_group = click.Group("linkedin", help="LinkedIn via Unipile API (20 commands)")

register(linkedin_group, linkedin.retrieve_own_profile)

# LinkedIn connect account
linkedin_connect_group = click.Group("connect", help="Connect LinkedIn account")
register(linkedin_connect_group, linkedin.connect_account, group_name="linkedin")
linkedin_group.add_command(linkedin_connect_group)

# LinkedIn reconnect account
linkedin_reconnect_group = click.Group("reconnect", help="Reconnect LinkedIn account")
register(linkedin_reconnect_group, linkedin.reconnect_account, group_name="linkedin")
linkedin_group.add_command(linkedin_reconnect_group)

# LinkedIn check account
linkedin_check_group = click.Group("check", help="Check LinkedIn connection status")
register(linkedin_check_group, linkedin.check_account, group_name="linkedin")
linkedin_group.add_command(linkedin_check_group)

# LinkedIn retrieve profile and company
linkedin_retrieve_group = click.Group("retrieve", help="Retrieve profiles and companies")
register(linkedin_retrieve_group, linkedin.retrieve_profile, group_name="linkedin")
register(linkedin_retrieve_group, linkedin.retrieve_company, group_name="linkedin")
linkedin_group.add_command(linkedin_retrieve_group)

# LinkedIn send invitation and message
linkedin_send_group = click.Group("send", help="Send invitations and messages")
register(linkedin_send_group, linkedin.send_invite, group_name="linkedin")
register(linkedin_send_group, linkedin.send_message, group_name="linkedin")
linkedin_group.add_command(linkedin_send_group)

# LinkedIn list relations, chats, and messages
linkedin_list_group = click.Group("list", help="List connections, chats, and messages")
register(linkedin_list_group, linkedin.list_relations, group_name="linkedin")
register(linkedin_list_group, linkedin.list_chats, group_name="linkedin")
register(linkedin_list_group, linkedin.list_messages, group_name="linkedin")

# LinkedIn list user messages
linkedin_list_user_group = click.Group("user", help="Per-user message history")
register(linkedin_list_user_group, linkedin.list_user_messages, group_name="linkedin")
linkedin_list_group.add_command(linkedin_list_user_group)

linkedin_group.add_command(linkedin_list_group)

# LinkedIn start chat
linkedin_start_group = click.Group("start", help="Start new conversations")
register(linkedin_start_group, linkedin.start_chat, group_name="linkedin")
linkedin_group.add_command(linkedin_start_group)

# LinkedIn search parameters
search_group = click.Group("search", help="LinkedIn search (7 subcommands)")
register(search_group, linkedin.search_parameters, group_name="linkedin")

# LinkedIn search classic leads, accounts, posts, jobs
classic_group = click.Group("classic", help="Classic LinkedIn search -- leads, accounts, posts, jobs")
register(classic_group, linkedin.search_classic_leads, group_name="linkedin")
register(classic_group, linkedin.search_classic_accounts, group_name="linkedin")
register(classic_group, linkedin.search_classic_posts, group_name="linkedin")
register(classic_group, linkedin.search_classic_jobs, group_name="linkedin")
search_group.add_command(classic_group)

# LinkedIn search sales navigator leads, accounts
sales_navigator_group = click.Group("sales", help="Sales Navigator search")
navigator_group = click.Group("navigator", help="Sales Navigator search -- leads, accounts")
register(navigator_group, linkedin.search_sales_navigator_leads, group_name="linkedin")
register(navigator_group, linkedin.search_sales_navigator_accounts, group_name="linkedin")
sales_navigator_group.add_command(navigator_group)
search_group.add_command(sales_navigator_group)

linkedin_group.add_command(search_group)
cli.add_command(linkedin_group)

# Accounts
account_group = click.Group("account", help="Target company accounts (6 commands)")
register(account_group, account.list_)
register(account_group, account.get_)
register(account_group, account.create)
register(account_group, account.update)
register(account_group, account.delete_)
register(account_group, account.batch_create)
cli.add_command(account_group)

# Dashboard
register(dashboard.group, dashboard.funnel)
register(dashboard.group, dashboard.conversations)
cli.add_command(dashboard.group)

# Report
register(cli, report.generate, group_name="report")

# Outreach
outreach_group = click.Group("outreach", help="Outreach tracking (1 command)")
register(outreach_group, outreach.list_)
cli.add_command(outreach_group)

# User
user_group = click.Group("user", help="Team member management (5 commands)")
register(user_group, user.list_)
register(user_group, user.get_)
register(user_group, user.create)
register(user_group, user.update)
register(user_group, user.delete_)
cli.add_command(user_group)

# Settings
settings_group = click.Group("settings", help="View and update settings (2 commands)")
register(settings_group, settings.get_)
register(settings_group, settings.update)
cli.add_command(settings_group)

# Info
register(cli, info.tour, group_name="info")
cli.add_command(info.completion)

# Directory posted.
