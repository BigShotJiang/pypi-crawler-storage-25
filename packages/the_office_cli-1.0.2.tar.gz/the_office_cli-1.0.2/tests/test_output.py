# *[wipes the board, checks the markers work]*

"""
test_output.py — Check the scoreboard.

Wins go on stdout, losses go on stderr. Both exit with
the right code.
"""

import json

import pytest

from the_office_cli.utils.output import (
    EXIT_ERROR,
    EXIT_RATE_LIMITED,
    EXIT_SUCCESS,
    error_stderr,
    output_stdout,
)


def test_output_stdout_wraps_in_success(capsys):
    with pytest.raises(SystemExit) as exc_info:
        output_stdout({"object": "Campaign", "id": 1})
    assert exc_info.value.code == EXIT_SUCCESS
    out = json.loads(capsys.readouterr().out)
    assert out["result"] == "success"
    assert out["object"] == "Campaign"
    assert out["id"] == 1


def test_error_stderr_wraps_in_error(capsys):
    with pytest.raises(SystemExit) as exc_info:
        error_stderr("NOT_FOUND", "Campaign not found")
    assert exc_info.value.code == EXIT_ERROR
    err = json.loads(capsys.readouterr().err)
    assert err["result"] == "error"
    assert err["code"] == "NOT_FOUND"
    assert err["message"] == "Campaign not found"
    assert err["retry"] is False


def test_error_stderr_with_retry(capsys):
    with pytest.raises(SystemExit) as exc_info:
        error_stderr("RATE_LIMIT", "Too fast", exit_code=EXIT_RATE_LIMITED, retry=True, retry_after=60)
    assert exc_info.value.code == EXIT_RATE_LIMITED
    err = json.loads(capsys.readouterr().err)
    assert err["retry"] is True
    assert err["retry_after"] == 60


def test_error_stderr_excludes_retry_after_when_none(capsys):
    with pytest.raises(SystemExit):
        error_stderr("NOT_FOUND", "Gone")
    err = json.loads(capsys.readouterr().err)
    assert "retry_after" not in err


def test_exit_codes():
    assert EXIT_SUCCESS == 0
    assert EXIT_ERROR == 1
    assert EXIT_RATE_LIMITED == 2

# Board checks out.
