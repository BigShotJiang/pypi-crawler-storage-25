# *[holds up a brochure, checks the print quality]*

"""
test_schema.py — Check the brochures.

Full brochure and business card builders produce the right
shape, the right fields, and the right defaults.
"""

from the_office_cli.cli.main import cli  
from the_office_cli.utils.registry import get_registry
from the_office_cli.utils.schema import _build_schema, build_tour_schema


def _make_config(method="GET", **overrides):
    config = {
        "name": "list",
        "description": "Use this command to list things.",
        "full_name": "campaign list",
        "schema": {
            "endpoint": "/campaigns",
            "method": method,
            "input": {"full": {"type": "boolean"}},
            "output": {"id": {"type": "integer"}},
            "example": {
                "input": {"full": True},
                "output": {"id": 1},
            },
        },
    }
    config.update(overrides)
    return config


def test_build_schema_has_required_keys():
    schema = _build_schema(_make_config())
    required = {"command", "description", "endpoint", "input", "output", "error",
                "confirm_required", "dry_run", "exit_codes", "example"}
    assert required.issubset(schema.keys())


def test_build_schema_command_uses_full_name():
    schema = _build_schema(_make_config())
    assert schema["command"] == "campaign list"


def test_build_schema_command_falls_back_to_name():
    schema = _build_schema(_make_config(full_name=None))
    assert schema["command"] == "list"


def test_build_schema_confirm_required_true_for_delete():
    schema = _build_schema(_make_config(method="DELETE"))
    assert schema["confirm_required"] is True


def test_build_schema_confirm_required_false_for_get():
    schema = _build_schema(_make_config(method="GET"))
    assert schema["confirm_required"] is False


def test_build_schema_confirm_required_false_for_post():
    schema = _build_schema(_make_config(method="POST"))
    assert schema["confirm_required"] is False


def test_build_schema_includes_rate_limit_when_present():
    config = _make_config()
    config["schema"]["rate_limit"] = "25 invitations/day"
    schema = _build_schema(config)
    assert schema["rate_limit"] == "25 invitations/day"


def test_build_schema_excludes_rate_limit_when_absent():
    schema = _build_schema(_make_config())
    assert "rate_limit" not in schema


def test_build_schema_no_batch_mode():
    schema = _build_schema(_make_config())
    assert "batch_mode" not in schema


def test_build_schema_dry_run_always_true():
    schema = _build_schema(_make_config())
    assert schema["dry_run"] is True


def test_build_schema_exit_codes():
    schema = _build_schema(_make_config())
    assert schema["exit_codes"] == {"0": "success", "1": "error", "2": "rate_limited"}


def test_build_schema_includes_example():
    schema = _build_schema(_make_config())
    assert "example" in schema
    assert schema["example"]["input"]["full"] is True


def test_build_schema_excludes_example_when_absent():
    config = _make_config()
    del config["schema"]["example"]
    schema = _build_schema(config)
    assert "example" not in schema


def test_build_tour_schema_shape():
    config = _make_config()
    config["_group"] = "campaign"
    out = build_tour_schema(config)
    assert out["group"] == "campaign"
    assert out["command"] == "campaign list"
    assert out["endpoint"]["method"] == "GET"


def test_build_tour_schema_uses_full_name():
    config = _make_config()
    config["_group"] = "campaign"
    config["full_name"] = "campaign list"
    out = build_tour_schema(config)
    assert out["command"] == "campaign list"


def test_build_tour_schema_constructs_name_from_group():
    config = _make_config(full_name=None)
    config["_group"] = "campaign"
    out = build_tour_schema(config)
    assert out["command"] == "campaign list"


def test_every_command_input_uses_only_path_query_body():
    """Schema input only uses path/query/body buckets."""
    for config in get_registry():
        keys = set(config["schema"].get("input", {}).keys())
        bad = keys - {"path", "query", "body"}
        name = config.get("full_name") or config["name"]
        assert not bad, f"{name}: input has invalid keys {bad}"


def test_every_command_example_input_uses_only_path_query_body():
    """Example input only uses path/query/body buckets."""
    for config in get_registry():
        example_input = config["schema"].get("example", {}).get("input", {})
        bad = set(example_input.keys()) - {"path", "query", "body"}
        name = config.get("full_name") or config["name"]
        assert not bad, f"{name}: example.input has invalid keys {bad}"


def test_every_command_example_includes_all_input_fields():
    """Every input field appears in the example."""
    for config in get_registry():
        s = config["schema"]
        if "example" not in s:
            continue
        for bucket in ("path", "query", "body"):
            schema_fields = set(s.get("input", {}).get(bucket, {}).keys())
            example_fields = set(s.get("example", {}).get("input", {}).get(bucket, {}).keys())
            missing = schema_fields - example_fields
            name = config.get("full_name") or config["name"]
            assert not missing, f"{name}: {bucket} fields missing from example: {missing}"


def test_every_command_example_includes_all_output_fields():
    """Every output field appears in the example."""
    for config in get_registry():
        s = config["schema"]
        if "example" not in s:
            continue
        output_fields = set(s.get("output", {}).keys())
        example_output = set(s.get("example", {}).get("output", {}).keys())
        missing = output_fields - example_output
        name = config.get("full_name") or config["name"]
        assert not missing, f"{name}: output fields missing from example: {missing}"


def test_path_query_body_dicts_are_multiline():
    """path/query/body buckets in input/example must be multi-line. Excludes type specs."""
    import pathlib
    import re

    cmd_dir = pathlib.Path(__file__).parent.parent / "src/the_office_cli/commands"
    pattern = re.compile(r'^\s+"(path|query|body)": \{[^{}\n]+\}')
    type_spec = re.compile(r'^\s+"(path|query|body)": \{"type":')
    issues = []
    for f in sorted(cmd_dir.glob("*.py")):
        for line_num, line in enumerate(f.read_text().splitlines(), 1):
            if pattern.match(line) and not type_spec.match(line):
                issues.append(f"{f.name}:{line_num}: {line.strip()}")
    assert not issues, "Inline path/query/body dicts (must be multi-line):\n  " + "\n  ".join(issues)


def test_object_and_array_declarations_have_nested_shape():
    """Every {type: object} must declare 'properties' or 'additionalProperties';
    every {type: array} must declare 'items'."""
    issues = []

    def walk(d, prefix):
        if not isinstance(d, dict):
            return
        for key, val in d.items():
            if not isinstance(val, dict):
                continue
            t = val.get("type")
            if t == "object" and "properties" not in val and "additionalProperties" not in val:
                issues.append(f"{prefix}.{key}: opaque object (missing 'properties')")
            if t == "array" and "items" not in val:
                issues.append(f"{prefix}.{key}: opaque array (missing 'items')")
            if isinstance(val.get("properties"), dict):
                walk(val["properties"], f"{prefix}.{key}.properties")
            if isinstance(val.get("additionalProperties"), dict):
                walk({"_": val["additionalProperties"]}, f"{prefix}.{key}.additionalProperties")
            items = val.get("items")
            if isinstance(items, dict):
                if items.get("type") == "object" and "properties" not in items and "additionalProperties" not in items:
                    issues.append(f"{prefix}.{key}.items: opaque object (missing 'properties')")
                if isinstance(items.get("properties"), dict):
                    walk(items["properties"], f"{prefix}.{key}.items.properties")

    for config in get_registry():
        s = config["schema"]
        name = config.get("full_name") or config["name"]
        for bucket, bucket_data in s.get("input", {}).items():
            walk(bucket_data, f"{name}: input.{bucket}")
        walk(s.get("output", {}), f"{name}: output")

    assert not issues, f"Opaque types ({len(issues)} found):\n  " + "\n  ".join(issues[:30])

# Brochures approved.
