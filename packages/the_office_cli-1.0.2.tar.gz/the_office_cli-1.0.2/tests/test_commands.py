# *[Michael grabs the clipboard, starts walking the floor]*

"""
test_commands.py — Michael's tour audit.

Walk every stop on the tour and make sure the brochure
is there, the example is filled in, and the contract
is complete. No API calls, just inspection.
"""

import json

import pytest
from click.testing import CliRunner

from the_office_cli.cli.main import cli
from the_office_cli.utils.registry import get_registry


REQUIRED_SCHEMA_KEYS = {"command", "description", "endpoint", "input", "output", "error", "dry_run", "exit_codes"}


def _all_commands():
    """Walk the CLI tree and collect all leaf commands with their full invocation path."""
    commands = []

    def _walk(group, prefix=""):
        for name, cmd in group.commands.items():
            full = f"{prefix} {name}".strip()
            if hasattr(cmd, "commands"):
                _walk(cmd, full)
            else:
                commands.append((full, cmd))

    _walk(cli)
    return commands


@pytest.fixture(scope="module")
def all_commands():
    return _all_commands()


@pytest.fixture(scope="module")
def runner():
    return CliRunner()


def test_all_commands_have_schema(all_commands, runner):
    """Every command with @command(...) should respond to --schema with valid JSON."""
    for full_name, cmd in all_commands:
        if not hasattr(cmd, "_command_config"):
            continue
        result = runner.invoke(cli, full_name.split() + ["--schema"])
        assert result.exit_code == 0, f"{full_name} --schema failed: {result.output}"
        schema = json.loads(result.output)
        missing = REQUIRED_SCHEMA_KEYS - schema.keys()
        assert not missing, f"{full_name} schema missing keys: {missing}"


def test_all_commands_have_example(all_commands, runner):
    """Every command schema should include an example."""
    for full_name, cmd in all_commands:
        if not hasattr(cmd, "_command_config"):
            continue
        result = runner.invoke(cli, full_name.split() + ["--schema"])
        schema = json.loads(result.output)
        assert "example" in schema, f"{full_name} schema has no example"


def test_all_commands_have_endpoint(all_commands, runner):
    """Every command schema should have endpoint with path and method."""
    for full_name, cmd in all_commands:
        if not hasattr(cmd, "_command_config"):
            continue
        result = runner.invoke(cli, full_name.split() + ["--schema"])
        schema = json.loads(result.output)
        assert "path" in schema["endpoint"], f"{full_name} endpoint missing path"
        assert "method" in schema["endpoint"], f"{full_name} endpoint missing method"


def test_delete_commands_have_confirm_required(all_commands, runner):
    """Every DELETE command schema should have confirm_required: true."""
    for full_name, cmd in all_commands:
        if not hasattr(cmd, "_command_config"):
            continue
        result = runner.invoke(cli, full_name.split() + ["--schema"])
        schema = json.loads(result.output)
        if schema["endpoint"]["method"] == "DELETE":
            assert schema.get("confirm_required") is True, f"{full_name} DELETE but confirm_required is not true"


def test_registry_count_matches_tour():
    """The registry should contain all registered commands."""
    registry = get_registry()
    assert len(registry) >= 55, f"Expected at least 55 commands in registry, got {len(registry)}"


def test_tour_outputs_valid_json(runner):
    result = runner.invoke(cli, ["tour"])
    assert result.exit_code == 0
    tour = json.loads(result.output)
    assert "commands" in tour
    assert "schemas" in tour
    assert tour["commands"] == len(tour["schemas"])


def test_fire_drill_has_schema(runner):
    result = runner.invoke(cli, ["fire-drill", "--schema"])
    assert result.exit_code == 0
    schema = json.loads(result.output)
    assert schema["command"] == "fire-drill"


def test_whoami_has_schema(runner):
    result = runner.invoke(cli, ["whoami", "--schema"])
    assert result.exit_code == 0
    schema = json.loads(result.output)
    assert schema["command"] == "whoami"


def test_login_has_schema(runner):
    result = runner.invoke(cli, ["login", "--schema"])
    assert result.exit_code == 0
    schema = json.loads(result.output)
    assert schema["command"] == "login"


def test_create_account_has_schema(runner):
    result = runner.invoke(cli, ["create-account", "--schema"])
    assert result.exit_code == 0
    schema = json.loads(result.output)
    assert schema["command"] == "create-account"


def test_completion_generates_zsh_script(runner):
    result = runner.invoke(cli, ["completion", "zsh"])
    assert result.exit_code == 0
    assert "#compdef the-office" in result.output

# Tour audited.
