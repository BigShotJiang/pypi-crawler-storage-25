# *[hands out the exam papers, sets the timer]*

"""
test_decorators.py — Training exam.

Test the callback stages before anyone's cleared for the
floor — stdin, dry runs, confirm gates, pagination, and
the full execution pipeline.
"""

import json

import click
import pytest
from click.testing import CliRunner

from the_office_cli.cli.decorators import (
    _apply_pagination,
    _print_dry_run,
    _require_confirm,
    command,
)
from the_office_cli.network.session import get


def test_apply_pagination_adds_metadata():
    result = {"items": [1, 2, 3]}
    kwargs = {"page": 1, "per_page": 3}
    out = _apply_pagination(result, kwargs)
    assert out["page"] == 1
    assert out["per_page"] == 3
    assert out["has_next"] is True


def test_apply_pagination_has_next_false_when_partial_page():
    result = {"items": [1, 2]}
    kwargs = {"page": 1, "per_page": 10}
    out = _apply_pagination(result, kwargs)
    assert out["has_next"] is False


def test_apply_pagination_skips_without_items():
    result = {"object": "Campaign", "id": 1}
    kwargs = {"page": 1, "per_page": 10}
    out = _apply_pagination(result, kwargs)
    assert "page" not in out


def test_apply_pagination_skips_without_page_kwargs():
    result = {"items": [1, 2, 3]}
    kwargs = {"full": True}
    out = _apply_pagination(result, kwargs)
    assert "page" not in out


def test_print_dry_run_outputs_json_and_exits(capsys):
    schema = {"method": "GET", "endpoint": "/campaigns"}
    with pytest.raises(SystemExit) as exc_info:
        _print_dry_run("campaign list", schema, {"full": True})
    assert exc_info.value.code == 0
    out = json.loads(capsys.readouterr().out)
    assert out["result"] == "dry_run"
    assert out["command"] == "campaign list"
    assert out["would_call"]["method"] == "GET"
    assert out["with_options"]["full"] is True


def test_print_dry_run_excludes_none_options(capsys):
    schema = {"method": "POST", "endpoint": "/leads"}
    with pytest.raises(SystemExit):
        _print_dry_run("lead create", schema, {"campaign_id": 1, "status": None})
    out = json.loads(capsys.readouterr().out)
    assert "status" not in out["with_options"]
    assert out["with_options"]["campaign_id"] == 1


def test_require_confirm_exits_with_error(capsys):
    with pytest.raises(SystemExit) as exc_info:
        _require_confirm("campaign delete")
    assert exc_info.value.code == 1
    err = json.loads(capsys.readouterr().err)
    assert err["code"] == "CONFIRMATION_REQUIRED"
    assert "--confirm" in err["message"]


def test_command_adds_dry_run_flag():
    @command(name="test", description="test", schema={"endpoint": "/test", "method": "GET"})
    def test_cmd(**_):
        return {"object": "Test"}

    param_names = [p.name for p in test_cmd.params]
    assert "dry_run" in param_names


def test_command_adds_confirm_for_delete():
    @command(name="test", description="test", schema={"endpoint": "/test", "method": "DELETE"})
    def test_cmd(**_):
        return {"object": "Test"}

    param_names = [p.name for p in test_cmd.params]
    assert "confirm" in param_names


def test_command_adds_idempotency_key_for_post():
    @command(name="test", description="test", schema={"endpoint": "/test", "method": "POST"})
    def test_cmd(**_):
        return {"object": "Test"}

    param_names = [p.name for p in test_cmd.params]
    assert "idempotency_key" in param_names


def test_command_no_confirm_for_get():
    @command(name="test", description="test", schema={"endpoint": "/test", "method": "GET"})
    def test_cmd(**_):
        return {"object": "Test"}

    param_names = [p.name for p in test_cmd.params]
    assert "confirm" not in param_names


def test_command_no_idempotency_key_for_get():
    @command(name="test", description="test", schema={"endpoint": "/test", "method": "GET"})
    def test_cmd(**_):
        return {"object": "Test"}

    param_names = [p.name for p in test_cmd.params]
    assert "idempotency_key" not in param_names


def test_command_attaches_config():
    @command(name="test", description="a test", schema={"endpoint": "/t", "method": "GET"})
    def test_cmd(**_):
        return {"object": "Test"}

    assert test_cmd._command_config["name"] == "test"
    assert test_cmd._command_config["description"] == "a test"


def test_command_dry_run_via_cli_runner():
    @command(name="test", description="test", schema={"endpoint": "/test", "method": "GET"})
    def test_cmd(**_):
        return {"object": "Test"}

    runner = CliRunner()
    result = runner.invoke(test_cmd, ["--dry-run"])
    assert result.exit_code == 0
    out = json.loads(result.output)
    assert out["result"] == "dry_run"


def test_command_delete_without_confirm_via_cli_runner():
    @command(name="test", description="test", schema={"endpoint": "/test", "method": "DELETE"})
    def test_cmd(**_):
        return {"object": "Test"}

    runner = CliRunner()
    result = runner.invoke(test_cmd, [])
    assert result.exit_code == 1

# Exam graded.
