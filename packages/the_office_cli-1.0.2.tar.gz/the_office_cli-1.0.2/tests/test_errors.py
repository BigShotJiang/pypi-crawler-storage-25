# *[opens the cabinet, checks every folder is in the right slot]*

"""
test_errors.py — Check the filing cabinet.

Every HTTP status maps to the right error code, the right
retry hint, and the right exit code.
"""

import pytest
import httpx

from the_office_cli.network.errors import ApiError, raise_from_http, ERROR_CODES
from the_office_cli.utils.output import EXIT_ERROR, EXIT_RATE_LIMITED


def _make_http_error(status_code: int, body: dict | None = None) -> httpx.HTTPStatusError:
    response = httpx.Response(
        status_code=status_code,
        json=body or {},
        request=httpx.Request("GET", "http://test"),
    )
    return httpx.HTTPStatusError("error", request=response.request, response=response)


def test_400_maps_to_invalid_input():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(400))
    assert exc_info.value.code == "INVALID_INPUT"
    assert exc_info.value.retry is False


def test_401_maps_to_auth_expired():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(401))
    assert exc_info.value.code == "AUTH_EXPIRED"
    assert exc_info.value.retry is False


def test_403_maps_to_forbidden():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(403))
    assert exc_info.value.code == "FORBIDDEN"


def test_404_maps_to_not_found():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(404))
    assert exc_info.value.code == "NOT_FOUND"


def test_409_maps_to_conflict():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(409))
    assert exc_info.value.code == "CONFLICT"


def test_422_maps_to_validation_error():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(422))
    assert exc_info.value.code == "VALIDATION_ERROR"


def test_429_maps_to_rate_limit_with_retry():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(429))
    assert exc_info.value.code == "RATE_LIMIT"
    assert exc_info.value.retry is True
    assert exc_info.value.exit_code == EXIT_RATE_LIMITED


def test_429_parses_retry_after_header():
    response = httpx.Response(
        status_code=429,
        json={},
        headers={"Retry-After": "60"},
        request=httpx.Request("GET", "http://test"),
    )
    exc = httpx.HTTPStatusError("error", request=response.request, response=response)
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(exc)
    assert exc_info.value.retry_after == 60


def test_500_maps_to_server_error_with_retry():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(500))
    assert exc_info.value.code == "SERVER_ERROR"
    assert exc_info.value.retry is True


def test_unknown_status_maps_to_server_error():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(502))
    assert exc_info.value.code == "SERVER_ERROR"


def test_extracts_message_from_response_body():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(400, {"message": "Bad email format"}))
    assert "Bad email format" in str(exc_info.value)


def test_extracts_error_field_from_response_body():
    with pytest.raises(ApiError) as exc_info:
        raise_from_http(_make_http_error(404, {"error": "Campaign not found!"}))
    assert "Campaign not found!" in str(exc_info.value)


def test_error_codes_list_is_complete():
    expected = {
        "AUTH_EXPIRED", "CONFIRMATION_REQUIRED", "FORBIDDEN", "NOT_FOUND",
        "CONFLICT", "RATE_LIMIT", "INVALID_INPUT", "NOTE_TOO_LONG",
        "VALIDATION_ERROR", "SERVER_ERROR", "UNKNOWN_ERROR",
    }
    assert set(ERROR_CODES) == expected

# Cabinet checked.
