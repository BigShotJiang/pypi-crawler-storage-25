# *[picks up the handset, listens for a dial tone]*

"""
test_session.py — Check the phone line.

Headers, retry keys, and stdin all work before anyone
dials out.
"""

from unittest.mock import patch

from the_office_cli.network.session import _headers, set_idempotency_key, input_stdin


def test_headers_with_token():
    with patch("the_office_cli.network.session.get_token", return_value="jwt123"):
        h = _headers()
    assert h["Authorization"] == "Bearer jwt123"
    assert h["Content-Type"] == "application/json"


def test_headers_without_token():
    with patch("the_office_cli.network.session.get_token", return_value=None):
        h = _headers()
    assert "Authorization" not in h
    assert h["Content-Type"] == "application/json"


def test_headers_with_idempotency_key():
    set_idempotency_key("abc-123")
    with patch("the_office_cli.network.session.get_token", return_value=None):
        h = _headers()
    assert h["Idempotency-Key"] == "abc-123"
    set_idempotency_key(None)


def test_headers_without_idempotency_key():
    set_idempotency_key(None)
    with patch("the_office_cli.network.session.get_token", return_value=None):
        h = _headers()
    assert "Idempotency-Key" not in h


def test_input_stdin_returns_none_on_tty():
    with patch("sys.stdin") as mock_stdin:
        mock_stdin.isatty.return_value = True
        assert input_stdin() is None


def test_input_stdin_parses_json():
    with patch("sys.stdin") as mock_stdin:
        mock_stdin.isatty.return_value = False
        mock_stdin.read.return_value = '{"name": "Dwight"}\n'
        result = input_stdin()
    assert result == {"name": "Dwight"}


def test_input_stdin_returns_none_on_empty():
    with patch("sys.stdin") as mock_stdin:
        mock_stdin.isatty.return_value = False
        mock_stdin.read.return_value = "   \n"
        assert input_stdin() is None

# Dial tone confirmed.
