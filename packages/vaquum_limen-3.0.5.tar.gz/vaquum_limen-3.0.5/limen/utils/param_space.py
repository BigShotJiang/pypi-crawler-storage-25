import math
import random
import sys
from typing import Any

import polars as pl


SAMPLE_SELECTION_MIN_SIZE = 21
SAMPLE_SELECTION_TIPPING_POINT = 5
SAMPLE_SELECTION_LOG_BASE = 4
SAMPLE_SELECTION_MULTIPLIER = 3


def sample_range_exact(
    rng: Any,
    population_size: int,
    sample_size: int,
) -> list[int]:

    '''
    Sample ordered indices with exact `random.sample(range(N), k)` semantics.

    Args:
        rng (Any): Random provider with `sample()` and `getrandbits()`
        population_size (int): Size of the conceptual `range(N)` population
        sample_size (int): Number of unique ordered indices to draw

    Returns:
        list[int]: Ordered sampled indices matching stdlib range-sampling behavior
    '''

    # Mirror CPython Lib/random.py for range(N) sampling so huge-space ParamSpace
    # keeps legacy random.sample semantics even when the wrapper overflows.
    if not 0 <= sample_size <= population_size:
        raise ValueError('Sample larger than population or is negative')

    setsize = SAMPLE_SELECTION_MIN_SIZE
    if sample_size > SAMPLE_SELECTION_TIPPING_POINT:
        setsize += SAMPLE_SELECTION_LOG_BASE ** math.ceil(
            math.log(
                sample_size * SAMPLE_SELECTION_MULTIPLIER,
                SAMPLE_SELECTION_LOG_BASE,
            )
        )

    if population_size <= setsize and population_size <= sys.maxsize:
        return rng.sample(range(population_size), sample_size)

    bits = population_size.bit_length()
    get_bits = rng.getrandbits
    seen: set[int] = set()
    ordered_indices: list[int] = []

    for _ in range(sample_size):
        index = get_bits(bits)
        while index >= population_size or index in seen:
            index = get_bits(bits)
        seen.add(index)
        ordered_indices.append(index)

    return ordered_indices


class ParamSpace:

    '''
    Create a legacy parameter space manager for hyperparameter sampling.

    Args:
        params (dict): Dictionary of parameter names and their possible values.
        n_permutations (int): Number of parameter combinations to sample. When
            this is smaller than the total parameter space, sampling uses exact
            `random.sample(range(N), k)` semantics, including when `N` exceeds
            the stdlib wrapper's `Py_ssize_t` limit. When this is greater than
            or equal to the total parameter space, all combinations are
            enumerated instead of sampled.
    '''

    def __init__(self, params: dict, n_permutations: int) -> None:

        self.params = params
        self.keys = list(params.keys())
        self.param_sizes = [len(params[k]) for k in self.keys]
        self.total_space = 1
        for size in self.param_sizes:
            self.total_space *= size

        # Generate n_permutations unique random indices
        if n_permutations >= self.total_space:
            indices = list(range(self.total_space))
        elif self.total_space <= sys.maxsize:
            indices = random.sample(range(self.total_space), n_permutations)
        else:
            indices = sample_range_exact(random, self.total_space, n_permutations)

        # Convert indices to parameter combinations
        combos = [self._index_to_combo(idx) for idx in indices]
        self.df_params = pl.DataFrame(combos)
        self.n_permutations = self.df_params.height

    def _index_to_combo(self, index: int) -> dict:
        combo = {}
        remaining_index = index
        for i, key in enumerate(self.keys):
            size = self.param_sizes[i]
            combo[key] = self.params[key][remaining_index % size]
            remaining_index //= size
        return combo

    def generate(self, random_search: bool = True) -> dict:

        '''
        Compute next parameter combination from the parameter space.

        Args:
            random_search (bool): Whether to select parameters randomly or sequentially

        Returns:
            dict: Dictionary of parameter names and selected values, or None if space is exhausted
        '''

        if self.df_params.is_empty():
            return None

        row_no = random.randrange(self.df_params.height) if random_search else 0

        round_params = dict(zip(self.df_params.columns, self.df_params.row(row_no), strict=True))

        self.df_params = (
            self.df_params
              .with_row_index('__idx')
              .filter(pl.col('__idx') != row_no)
              .drop('__idx')
        )

        return round_params
