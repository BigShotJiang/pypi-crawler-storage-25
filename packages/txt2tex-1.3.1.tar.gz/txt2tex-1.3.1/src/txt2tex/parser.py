"""Parser for txt2tex - converts tokens into AST."""

from __future__ import annotations

import dataclasses
import re
from typing import ClassVar, Literal

from txt2tex.ast_nodes import (
    Abbreviation,
    Aggregator,
    AggregatorClause,
    ArgueChain,
    ArgueStep,
    AxDef,
    BagLiteral,
    BibliographyMetadata,
    BinaryOp,
    Binding,
    BMachine,
    CaseAnalysis,
    Conditional,
    Contents,
    Declaration,
    Divide,
    Document,
    DocumentItem,
    Expr,
    FreeBranch,
    FreeType,
    FunctionApp,
    FunctionType,
    GenDef,
    GenericInstantiation,
    GivenType,
    Group,
    GroupAggregate,
    GuardedBranch,
    GuardedCases,
    HorizDef,
    Identifier,
    InfruleBlock,
    Lambda,
    LatexBlock,
    LineBreak,
    NaturalJoin,
    Number,
    PageBreak,
    Paragraph,
    Part,
    PartsFormat,
    Project,
    ProofNode,
    ProofTree,
    PureParagraph,
    Quantifier,
    Range,
    RawLatexBlock,
    RelationalImage,
    RelationRename,
    Restrict,
    Schema,
    SchemaBinding,
    SchemaCompose,
    SchemaHide,
    SchemaInclusion,
    SchemaPipe,
    SchemaProject,
    SchemaRename,
    SchemaText,
    Section,
    SequenceLiteral,
    SetComprehension,
    SetLiteral,
    Solution,
    StringLit,
    Subscript,
    Superscript,
    SyntaxBlock,
    SyntaxDefinition,
    Theta,
    TitleMetadata,
    TruthTable,
    Tuple,
    TupleProjection,
    UnaryOp,
    Ungroup,
    Zed,
)
from txt2tex.constants import PROSE_WORDS
from txt2tex.tokens import Token, TokenType


class ParserError(Exception):
    """Raised when parser encounters invalid syntax."""

    # Instance variable type annotations
    message: str
    token: Token

    def __init__(self, message: str, token: Token) -> None:
        """Initialize parser error with token position."""
        super().__init__(f"Line {token.line}, column {token.column}: {message}")
        self.message = message
        self.token = token


class Parser:
    """Recursive descent parser for txt2tex whiteboard notation.

    Expression grammar (precedence from lowest to highest):
        expr       ::= quantifier | iff
        quantifier ::= ('forall' | 'exists' | 'exists1' | 'mu')
                       var_list (':' atom)? '|' expr
        var_list   ::= IDENTIFIER (',' IDENTIFIER)*
        iff        ::= implies ( '<=>' implies )*
        implies    ::= or ( '=>' or )*
        or         ::= and ( 'or' and )*
        and        ::= comparison ( 'and' comparison )*
        comparison ::= relation ( ('<' | '>' | '<=' | '>=' | '=' | '!=') relation )?
        relation   ::= set_op ( relation_op set_op )*
        set_op     ::= union ( ('in' | 'notin' | 'subset') union )?
        union      ::= intersect ( 'union' intersect )*
        intersect  ::= unary ( 'intersect' unary )*
        unary      ::= 'not' unary | postfix
        postfix    ::= atom ( '^' atom | '_' atom | '~' | '+' | '*' )*
        atom       ::= prefix_op atom | IDENTIFIER | NUMBER | '(' expr ')' |
                       '{' set_comprehension '}' | '⟨' sequence '⟩' | '[[' bag ']]'

    Document structure:
        document ::= document_item*
        document_item ::= section | solution | part | truth_table | equiv_chain |
                         z_definition | proof_tree | expr

    Relation operators:
        - Infix: <-> (relation), |-> (maplet), <| (domain restriction),
                 |> (range restriction), <<| (domain subtraction),
                 |>> (range subtraction), o9/comp (composition)
        - Prefix: dom, ran, inv, id
        - Postfix: ~ (inverse), + (transitive closure), * (reflexive-transitive)

    Function type operators:
        - -> (total), +-> (partial), >-> (injection), >+> (partial injection),
          -->> (surjection), +->> (partial surjection), >->> (bijection)
    """

    # Instance variable type annotations
    tokens: list[Token]
    pos: int
    last_token_end_column: int
    last_token_line: int
    _parsing_schema_text: bool
    _in_comprehension_body: bool
    _in_schema_expr_context: bool
    _in_comparison_rhs: bool
    _current_quantifier_vars: set[str]
    _in_relational_context: bool

    def __init__(self, tokens: list[Token]) -> None:
        """Initialize parser with token list.

        Args:
            tokens: List of tokens from Lexer to parse.
        """
        self.tokens = tokens
        self.pos = 0
        # Track the end position of the last consumed token for whitespace detection
        self.last_token_end_column = 0
        self.last_token_line = 1
        # Track whether we're parsing schema text (lambda/set comp declarations)
        # where periods are separators, not projection operators
        self._parsing_schema_text = False
        # Track whether we're in a comprehension/quantifier body where
        # periods can be expression separators
        # ({ x : X | pred . expr } or mu x : X | pred . expr)
        self._in_comprehension_body = False
        # Track whether we're parsing a schema-expression context (RHS of defs,
        # schema inclusion body) where ';' is schema composition, not a separator.
        self._in_schema_expr_context = False
        # Track whether we're parsing the RHS of a comparison operator inside
        # a comprehension body.  Used to allow field projections like 's.name'
        # in 'c.class = s.name }' even though the RBRACE follows immediately.
        self._in_comparison_rhs = False
        # All variable names declared in the current comprehension/quantifier
        # schema-text (across the entire semicolon chain).  Used by _parse_postfix
        # to distinguish bullet `.` from named-field projection: `.IDENT` where
        # IDENT is a declared variable cannot be a field selector (Z RM §3.16).
        self._current_quantifier_vars: set[str] = set()
        # True when parsing a relational-algebra argument position (inside sigma,
        # pi, join, div, group, ungroup operands).  Governs disambiguation of
        # Expr[new/old] postfix: RelationRename when True, SchemaRename when False.
        self._in_relational_context: bool = False

    def parse(self) -> Document | Expr:
        """Parse tokens and return AST.

        Parses the entire token stream into an Abstract Syntax Tree.
        Handles both document-level constructs (sections, solutions, Z blocks)
        and expression-level parsing.

        Returns:
            Document: For multi-line input or structural elements.
            Expr: For single expression input (backward compatible).

        Raises:
            ParserError: If the input contains syntax errors.
        """
        self._skip_newlines()

        # Empty input
        if self._at_end():
            return Document(
                items=[],
                title_metadata=None,
                parts_format="subsection",
                bibliography_metadata=None,
                line=1,
                column=1,
            )

        first_line = self._current().line

        # Parse title metadata, bibliography metadata, and parts format
        # at document start (if present)
        title_metadata = self._parse_title_metadata()
        bibliography_metadata = self._parse_bibliography_metadata()
        parts_format = self._parse_parts_format()

        # Check if we start with a structural element (section, solution, etc.)
        if self._is_structural_token():
            # Parse as document with structural elements
            items: list[DocumentItem] = []
            while not self._at_end():
                items.append(self._parse_document_item())
                self._skip_newlines()
            return Document(
                items=items,
                title_metadata=title_metadata,
                parts_format=parts_format,
                bibliography_metadata=bibliography_metadata,
                line=first_line,
                column=1,
            )

        # Check for abbreviation (identifier ==) or free type (identifier ::=)
        # or horizontal schema definition (identifier [generics]? defs ...)
        # Note: Partial support for compound identifiers like "R+ =="
        # (GitHub #3 still open)
        if self._match(TokenType.IDENTIFIER):
            next_token = self._peek_ahead(1)
            if next_token.type == TokenType.FREE_TYPE:
                # Parse free type and check for more items
                first_free_type = self._parse_free_type()
                self._skip_newlines()
                # Check if there are more items (multi-line document)
                if not self._at_end():
                    items_with_free: list[DocumentItem] = [first_free_type]
                    while not self._at_end():
                        items_with_free.append(self._parse_document_item())
                        self._skip_newlines()
                    return Document(
                        items=items_with_free,
                        title_metadata=None,
                        parts_format=parts_format,
                        bibliography_metadata=None,
                        line=first_line,
                        column=1,
                    )
                # Single free type
                return Document(
                    items=[first_free_type],
                    title_metadata=None,
                    parts_format=parts_format,
                    bibliography_metadata=None,
                    line=first_line,
                    column=1,
                )
            # Detect horizontal schema definition: Name defs ... or Name[X] defs ...
            is_horiz = next_token.type == TokenType.DEFS or (
                next_token.type == TokenType.LBRACKET
                and self._scan_for_defs_after_brackets(offset=1)
            )
            if is_horiz:
                first_hd = self._parse_horiz_def()
                self._skip_newlines()
                if not self._at_end():
                    items_with_hd: list[DocumentItem] = [first_hd]
                    while not self._at_end():
                        items_with_hd.append(self._parse_document_item())
                        self._skip_newlines()
                    return Document(
                        items=items_with_hd,
                        title_metadata=None,
                        parts_format=parts_format,
                        bibliography_metadata=None,
                        line=first_line,
                        column=1,
                    )
                return Document(
                    items=[first_hd],
                    title_metadata=None,
                    parts_format=parts_format,
                    bibliography_metadata=None,
                    line=first_line,
                    column=1,
                )
            # Check for abbreviation with or without postfix operator
            # Cases: "R ==", "R+ ==", "R* ==", "R~ ==" (partial support, GitHub #3 open)
            is_abbrev = next_token.type == TokenType.ABBREV
            if not is_abbrev and next_token.type in (
                TokenType.PLUS,
                TokenType.STAR,
                TokenType.TILDE,
            ):
                # Check if postfix operator is followed by ==
                token_after_postfix = self._peek_ahead(2)
                is_abbrev = token_after_postfix.type == TokenType.ABBREV
            if is_abbrev:
                # Parse abbreviation and check for more items
                first_abbrev = self._parse_abbreviation()
                self._skip_newlines()
                # Check if there are more items (multi-line document)
                if not self._at_end():
                    items_with_abbrev: list[DocumentItem] = [first_abbrev]
                    while not self._at_end():
                        items_with_abbrev.append(self._parse_document_item())
                        self._skip_newlines()
                    return Document(
                        items=items_with_abbrev,
                        title_metadata=None,
                        parts_format=parts_format,
                        bibliography_metadata=None,
                        line=first_line,
                        column=1,
                    )
                # Single abbreviation
                return Document(
                    items=[first_abbrev],
                    title_metadata=None,
                    parts_format=parts_format,
                    bibliography_metadata=None,
                    line=first_line,
                    column=1,
                )
        # Check for abbreviation with generic parameters [X, Y] Name == expression
        # Note: Bag literals [[x]] start with [[ which is distinct
        if self._match(TokenType.LBRACKET):
            # Check if this is a bag literal [[...]] or abbreviation [X, Y] Name ==
            next_token = self._peek_ahead(1)
            if next_token.type == TokenType.LBRACKET:
                # It's a bag literal - parse as expression
                first_item = self._parse_expr()
                # Single expression
                if not self._at_end():
                    self._reject_stray_slash()
                    raise ParserError(
                        f"Unexpected token after expression: {self._current().value!r}",
                        self._current(),
                    )
                return first_item
            # Parse abbreviation with generic parameters and check for more items
            first_generic_abbrev = self._parse_abbreviation()
            self._skip_newlines()
            # Check if there are more items (multi-line document)
            if not self._at_end():
                items_with_generic: list[DocumentItem] = [first_generic_abbrev]
                while not self._at_end():
                    items_with_generic.append(self._parse_document_item())
                    self._skip_newlines()
                return Document(
                    items=items_with_generic,
                    title_metadata=None,
                    parts_format=parts_format,
                    bibliography_metadata=None,
                    line=first_line,
                    column=1,
                )
            # Single abbreviation with generic parameters
            return Document(
                items=[first_generic_abbrev],
                title_metadata=None,
                parts_format=parts_format,
                bibliography_metadata=None,
                line=first_line,
                column=1,
            )

        # Try to parse as expression
        first_item = self._parse_expr()

        # Check if there are more items (multi-line document)
        if self._match(TokenType.NEWLINE):
            items_list: list[DocumentItem] = [first_item]
            self._skip_newlines()

            while not self._at_end():
                items_list.append(self._parse_document_item())
                self._skip_newlines()

            return Document(
                items=items_list,
                title_metadata=None,
                parts_format=parts_format,
                bibliography_metadata=None,
                line=first_line,
                column=1,
            )

        # Single expression (backward compatibility)
        if not self._at_end():
            self._reject_stray_slash()
            raise ParserError(
                f"Unexpected token after expression: {self._current().value!r}",
                self._current(),
            )
        return first_item

    def _parse_title_metadata(self) -> TitleMetadata | None:
        """Parse title metadata at document start (TITLE:, AUTHOR:, etc.).

        This method consumes tokens, so it should only be called once at the
        start of document parsing.
        """
        title: str | None = None
        subtitle: str | None = None
        author: str | None = None
        date: str | None = None
        institution: str | None = None

        # Parse title metadata lines (must be at start of document)
        while not self._at_end():
            if self._match(TokenType.TITLE):
                token = self._advance()  # Consume TITLE token (value contains text)
                title = token.value.strip()
                self._skip_newlines()
            elif self._match(TokenType.SUBTITLE):
                token = self._advance()  # Consume SUBTITLE token
                subtitle = token.value.strip()
                self._skip_newlines()
            elif self._match(TokenType.AUTHOR):
                token = self._advance()  # Consume AUTHOR token
                author = token.value.strip()
                self._skip_newlines()
            elif self._match(TokenType.DATE):
                token = self._advance()  # Consume DATE token
                date = token.value.strip()
                self._skip_newlines()
            elif self._match(TokenType.INSTITUTION):
                token = self._advance()  # Consume INSTITUTION token
                institution = token.value.strip()
                self._skip_newlines()
            elif self._match(TokenType.PARTS):
                # PARTS directive - stop here, will be parsed by _parse_parts_format()
                break
            else:
                # Not a title metadata line, stop parsing
                break

        # Return metadata if any field was set, otherwise None
        if title or subtitle or author or date or institution:
            return TitleMetadata(
                title=title,
                subtitle=subtitle,
                author=author,
                date=date,
                institution=institution,
                line=1,
                column=1,
            )
        return None

    def _is_structural_token(self) -> bool:
        """Check if current token is a structural element."""
        return self._match(
            TokenType.SECTION_MARKER,
            TokenType.SOLUTION_MARKER,
            TokenType.PART_LABEL,
            TokenType.TRUTH_TABLE,
            TokenType.TEXT,
            TokenType.PURETEXT,
            TokenType.LATEX,
            TokenType.B_BLOCK,
            TokenType.RAW_LATEX_BLOCK,
            TokenType.PAGEBREAK,
            TokenType.LINEBREAK,
            TokenType.CONTENTS,
            TokenType.PARTS,
            TokenType.ARGUE,  # Both EQUIV: and ARGUE: map to this token
            TokenType.EQUAL,  # EQUAL: expression equality chain
            TokenType.INFRULE,
            TokenType.GIVEN,
            TokenType.AXDEF,
            TokenType.GENDEF,
            TokenType.ZED,
            TokenType.SCHEMA,
            TokenType.SYNTAX,
            TokenType.PROOF,
        )

    def _parse_paragraph(self) -> Paragraph | Part:
        """Parse plain text paragraph from TEXT token.

        The TEXT token value contains the raw text content (no tokenization).
        If the text starts with a part label like "(a) content...",
        return a Part node containing a Paragraph instead.
        """
        text_token = self._advance()  # Consume TEXT token

        if text_token.type != TokenType.TEXT:
            raise ParserError("Expected TEXT token for paragraph", text_token)

        # The token value contains the raw text (already captured by lexer)
        text = text_token.value

        # Check if text starts with a structural part label at paragraph start.
        # Only short, recognised label forms are promoted to Part nodes:
        # single letter (a)-(z), single digit (1)-(9), or a short Roman numeral.
        # Longer words like (underlined) or (continued) stay as prose text.
        roman_numerals: frozenset[str] = frozenset(
            {"i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"}
        )
        part_match = re.match(r"^\(([a-z0-9]+)\)\s+(.+)", text, re.IGNORECASE)
        if part_match:
            label = part_match.group(1).lower()
            is_single_letter = len(label) == 1 and label.isalpha()
            is_single_digit = len(label) == 1 and label.isdigit()
            is_roman = label in roman_numerals
            if is_single_letter or is_single_digit or is_roman:
                content = part_match.group(2)
                paragraph = Paragraph(
                    text=content, line=text_token.line, column=text_token.column
                )
                return Part(
                    label=label,
                    items=[paragraph],
                    line=text_token.line,
                    column=text_token.column,
                )

        return Paragraph(text=text, line=text_token.line, column=text_token.column)

    def _parse_paragraph_coalesced(self) -> Paragraph | Part:
        """Parse one or more adjacent TEXT: directives as a single paragraph.

        Adjacent TEXT: lines (separated only by a single newline, no blank
        line between them) are joined into one paragraph separated by a
        single space.  A blank line (two successive NEWLINEs, or any
        non-TEXT structural token) breaks the paragraph.

        Delegates to _parse_paragraph for the first token so the
        part-label promotion rule still applies when the leading TEXT:
        line starts with a recognised structural label like ``(a)``.
        """
        # Parse the first TEXT token (may return a Part for labelled content).
        result = self._parse_paragraph()

        # If the first token produced a Part, do not attempt coalescing —
        # the content already belongs to the Part's item list.
        if isinstance(result, Part):
            return result

        # Coalesce following TEXT tokens that are adjacent (no blank line).
        # A blank line is signalled by two consecutive NEWLINEs or by any
        # token that is not NEWLINE + TEXT.
        accumulated: list[str] = [result.text]
        while True:
            # Peek: is the next token a NEWLINE followed directly by TEXT?
            if not self._match(TokenType.NEWLINE):
                break
            # Save position in case we need to back off.
            saved_pos = self.pos
            self._advance()  # consume the NEWLINE
            if not self._match(TokenType.TEXT):
                # Not followed by TEXT — restore to before the NEWLINE.
                self.pos = saved_pos
                break
            # Check it is not a blank line (another NEWLINE would appear before TEXT).
            # Since we consumed exactly one NEWLINE and the next token is TEXT,
            # this is a single-newline separation — coalesce it.
            text_token = self._advance()  # consume TEXT token
            text = text_token.value
            # Apply the same part-label guard: if this line starts with a
            # structural label, stop coalescing (it forms a new Part).
            roman_numerals: frozenset[str] = frozenset(
                {"i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"}
            )
            pm = re.match(r"^\(([a-z0-9]+)\)\s+(.+)", text, re.IGNORECASE)
            if pm:
                lbl = pm.group(1).lower()
                if (
                    (len(lbl) == 1 and lbl.isalpha())
                    or (len(lbl) == 1 and lbl.isdigit())
                    or lbl in roman_numerals
                ):
                    # Back off: put pos back before the TEXT token and stop.
                    self.pos = saved_pos
                    break
            accumulated.append(text)

        if len(accumulated) == 1:
            # No coalescing happened; return the already-parsed result.
            return result

        merged_text = " ".join(accumulated)
        return Paragraph(
            text=merged_text,
            line=result.line,
            column=result.column,
        )

    def _parse_pure_paragraph(self) -> PureParagraph:
        """Parse pure text paragraph from PURETEXT token.

        PURETEXT: blocks contain raw text with NO processing:
        - No formula detection
        - No operator conversion
        - Only basic LaTeX escaping applied during generation
        """
        text_token = self._advance()  # Consume PURETEXT token
        if text_token.type != TokenType.PURETEXT:
            raise ParserError("Expected PURETEXT token for pure paragraph", text_token)

        # The token value contains the raw text (already captured by lexer)
        text = text_token.value

        return PureParagraph(text=text, line=text_token.line, column=text_token.column)

    def _parse_latex_block(self) -> LatexBlock:
        """Parse raw LaTeX block from LATEX token.

        LATEX: blocks contain raw LaTeX with NO escaping.
        The LaTeX is passed directly through to the output.
        """
        latex_token = self._advance()  # Consume LATEX token
        if latex_token.type != TokenType.LATEX:
            raise ParserError("Expected LATEX token for LaTeX block", latex_token)

        # The token value contains the raw LaTeX (already captured by lexer)
        latex = latex_token.value

        return LatexBlock(latex=latex, line=latex_token.line, column=latex_token.column)

    def _parse_identifier_document_item(self) -> DocumentItem:
        """Parse document item starting with an IDENTIFIER token.

        Dispatches to free type, horizontal schema definition, or abbreviation
        based on the tokens that follow the identifier.
        Note: Partial support for compound identifiers like "R+ ==" (GitHub #3).
        """
        next_token = self._peek_ahead(1)
        if next_token.type == TokenType.FREE_TYPE:
            return self._parse_free_type()
        if next_token.type == TokenType.DEFS:
            return self._parse_horiz_def()
        has_generics = next_token.type == TokenType.LBRACKET
        if has_generics and self._scan_for_defs_after_brackets(offset=1):
            return self._parse_horiz_def()
        is_abbrev = next_token.type == TokenType.ABBREV
        if not is_abbrev and next_token.type in (
            TokenType.PLUS,
            TokenType.STAR,
            TokenType.TILDE,
        ):
            token_after_postfix = self._peek_ahead(2)
            is_abbrev = token_after_postfix.type == TokenType.ABBREV
        if is_abbrev:
            return self._parse_abbreviation()
        return self._parse_expr()

    def _parse_bracket_document_item(self) -> DocumentItem:
        """Parse document item starting with a left-bracket token.

        Distinguishes bag literals ([[...]]) from abbreviations with generic
        parameters ([X, Y] Name == expression).
        """
        next_token = self._peek_ahead(1)
        if next_token.type == TokenType.LBRACKET:
            return self._parse_expr()
        return self._parse_abbreviation()

    def _parse_parts_directive(self) -> PartsFormat:
        """Parse PARTS directive from PARTS token.

        PARTS directives parsed at document start are the authoritative source;
        one appearing later in content is parsed but has no effect.
        """
        parts_token = self._advance()
        return PartsFormat(
            style=parts_token.value.strip().lower(),
            line=parts_token.line,
            column=parts_token.column,
        )

    def _parse_b_block(self) -> BMachine:
        """Parse B-machine verbatim block from B_BLOCK token.

        The token value is the raw multi-line body (including the final END
        line) already captured by the lexer.  No Z-parser involvement.
        """
        b_token = self._advance()  # Consume B_BLOCK token
        if b_token.type != TokenType.B_BLOCK:
            raise ParserError("Expected B_BLOCK token for B-machine block", b_token)
        return BMachine(body=b_token.value, line=b_token.line, column=b_token.column)

    def _parse_raw_latex_block(self) -> RawLatexBlock:
        """Parse multi-line raw LaTeX block from RAW_LATEX_BLOCK token.

        The token value is the verbatim body already slurped by the lexer
        (body lines only — the END terminator is not included).  Emitted
        directly to .tex output with no escaping and no environment wrapper.
        """
        tok = self._advance()  # Consume RAW_LATEX_BLOCK token
        if tok.type != TokenType.RAW_LATEX_BLOCK:
            raise ParserError(
                "Expected RAW_LATEX_BLOCK token for multi-line LATEX block", tok
            )
        return RawLatexBlock(body=tok.value, line=tok.line, column=tok.column)

    def _parse_pagebreak(self) -> PageBreak:
        """Parse page break from PAGEBREAK token.

        PAGEBREAK: inserts a page break in the PDF output.
        """
        pagebreak_token = self._advance()  # Consume PAGEBREAK token
        if pagebreak_token.type != TokenType.PAGEBREAK:
            raise ParserError("Expected PAGEBREAK token", pagebreak_token)

        return PageBreak(line=pagebreak_token.line, column=pagebreak_token.column)

    def _parse_linebreak(self) -> LineBreak:
        r"""Parse line break (vertical \medskip) from LINEBREAK token.

        LINEBREAK: inserts a medium vertical space in the PDF output.
        """
        linebreak_token = self._advance()  # Consume LINEBREAK token
        if linebreak_token.type != TokenType.LINEBREAK:
            raise ParserError("Expected LINEBREAK token", linebreak_token)

        return LineBreak(line=linebreak_token.line, column=linebreak_token.column)

    def _parse_contents(self) -> Contents:
        """Parse table of contents directive from CONTENTS token.

        CONTENTS: generates table of contents (sections only)
        CONTENTS: full generates table of contents (sections + subsections)
        CONTENTS: 2 also generates table of contents (sections + subsections)
        """
        contents_token = self._advance()  # Consume CONTENTS token
        if contents_token.type != TokenType.CONTENTS:
            raise ParserError("Expected CONTENTS token", contents_token)

        depth = contents_token.value.strip()  # "full", "2", or empty
        return Contents(
            depth=depth, line=contents_token.line, column=contents_token.column
        )

    def _parse_bibliography_metadata(self) -> BibliographyMetadata:
        """Parse bibliography metadata directives.

        Parses BIBLIOGRAPHY: and BIBLIOGRAPHY_STYLE: directives.
        Returns BibliographyMetadata with file and style, or None values
        if not present.
        """
        file: str | None = None
        style: str | None = None

        # Parse BIBLIOGRAPHY: and BIBLIOGRAPHY_STYLE: tokens
        while not self._at_end():
            if self._match(TokenType.BIBLIOGRAPHY):
                token = self._advance()
                file = token.value.strip()
                self._skip_newlines()
            elif self._match(TokenType.BIBLIOGRAPHY_STYLE):
                token = self._advance()
                style = token.value.strip()
                self._skip_newlines()
            elif self._match(
                TokenType.TITLE,
                TokenType.SUBTITLE,
                TokenType.AUTHOR,
                TokenType.DATE,
                TokenType.INSTITUTION,
                TokenType.PARTS,
                TokenType.CONTENTS,
            ):
                # Other metadata directives - stop here, let them be parsed separately
                break
            else:
                # Not a metadata directive - stop parsing metadata
                break

        return BibliographyMetadata(
            file=file if file else None,
            style=style if style else None,
            line=self._current().line if not self._at_end() else 1,
            column=self._current().column if not self._at_end() else 1,
        )

    def _parse_parts_format(self) -> str:
        """Parse parts formatting style from PARTS token.

        PARTS: inline generates inline parts formatting
        PARTS: subsection generates subsection parts formatting (default)
        Returns the style string or "subsection" if not found.
        """
        if self._match(TokenType.PARTS):
            parts_token = self._advance()  # Consume PARTS token
            style = parts_token.value.strip().lower()
            # Validate style
            if style not in ("inline", "subsection"):
                raise ParserError(
                    f"Invalid parts format: {style}. Must be 'inline' or 'subsection'",
                    parts_token,
                )
            self._skip_newlines()  # Skip newlines after PARTS directive
            return style
        return "subsection"  # Default

    def _parse_document_item(self) -> DocumentItem:
        """Parse a document item (expression or structural element)."""
        if self._match(TokenType.SECTION_MARKER):
            return self._parse_section()
        if self._match(TokenType.SOLUTION_MARKER):
            return self._parse_solution()
        if self._match(TokenType.PART_LABEL):
            return self._parse_part()
        if self._match(TokenType.TRUTH_TABLE):
            return self._parse_truth_table()
        if self._match(TokenType.ARGUE):  # Handles both EQUIV: and ARGUE: keywords
            return self._parse_argue_chain(connector="iff")
        if self._match(TokenType.EQUAL):  # Expression equality chain
            return self._parse_argue_chain(connector="eq")
        if self._match(TokenType.INFRULE):
            return self._parse_infrule_block()
        if self._match(TokenType.GIVEN):
            return self._parse_given_type()
        if self._match(TokenType.AXDEF):
            return self._parse_axdef()
        if self._match(TokenType.GENDEF):
            return self._parse_gendef()
        if self._match(TokenType.ZED):
            return self._parse_zed()
        if self._match(TokenType.SCHEMA):
            return self._parse_schema()
        if self._match(TokenType.SYNTAX):
            return self._parse_syntax_block()
        if self._match(TokenType.PROOF):
            return self._parse_proof_tree()
        if self._match(TokenType.TEXT):
            return self._parse_paragraph_coalesced()
        if self._match(TokenType.PURETEXT):
            return self._parse_pure_paragraph()
        if self._match(TokenType.LATEX):
            return self._parse_latex_block()
        if self._match(TokenType.RAW_LATEX_BLOCK):
            return self._parse_raw_latex_block()
        if self._match(TokenType.B_BLOCK):
            return self._parse_b_block()
        if self._match(TokenType.PAGEBREAK):
            return self._parse_pagebreak()
        if self._match(TokenType.LINEBREAK):
            return self._parse_linebreak()
        if self._match(TokenType.CONTENTS):
            return self._parse_contents()
        if self._match(TokenType.PARTS):
            return self._parse_parts_directive()

        # Check for abbreviation (identifier == expr) or free type (identifier ::= ...)
        # or horizontal schema definition (identifier [generics]? defs ...)
        if self._match(TokenType.IDENTIFIER):
            return self._parse_identifier_document_item()

        # Check for abbreviation with generic parameters [X, Y] Name == expression
        # Note: Bag literals [[x]] start with [[ which is distinct
        if self._match(TokenType.LBRACKET):
            return self._parse_bracket_document_item()

        # Default: parse as expression
        return self._parse_expr()

    def _at_end(self) -> bool:
        """Check if we've consumed all tokens."""
        return self._current().type == TokenType.EOF

    def _current(self) -> Token:
        """Return current token without consuming it."""
        return self.tokens[self.pos]

    def _advance(self) -> Token:
        """Consume and return current token."""
        token = self.tokens[self.pos]
        if not self._at_end():
            self.pos += 1
        # Track the end position of this token for whitespace detection
        self.last_token_end_column = token.column + len(token.value)
        self.last_token_line = token.line
        return token

    def _match(self, *types: TokenType) -> bool:
        """Check if current token matches any of the given types."""
        return self._current().type in types

    def _peek_ahead(self, offset: int = 1) -> Token:
        """Look ahead at token without consuming it."""
        pos = self.pos + offset
        if pos < len(self.tokens):
            return self.tokens[pos]
        return self.tokens[-1]  # Return EOF if past end

    def _reject_stray_slash(self) -> None:
        """Raise ParserError if the current token is a stray SLASH.

        '/' is only valid inside schema rename brackets ``S[a/b]``.
        When it appears in any other position it produces a confusing
        generic "unexpected token" message.  This helper fires first and
        gives a targeted diagnostic.
        """
        if self._match(TokenType.SLASH):
            raise ParserError(
                "'/' is not a valid operator here; the slash is only valid"
                " inside schema rename brackets S[a/b]."
                " Did you mean '/=' (not equal) or '/in' (not in)?",
                self._current(),
            )

    def _skip_newlines(self) -> None:
        """Skip all consecutive newline tokens."""
        while self._match(TokenType.NEWLINE) and not self._at_end():
            self._advance()

    def _has_blank_line(self) -> bool:
        """Check if there are multiple consecutive newlines (blank line).

        Returns:
            True if there are 2+ consecutive NEWLINE tokens (indicating blank line)
        """
        if not self._match(TokenType.NEWLINE):
            return False

        # Count consecutive newlines
        newline_count = 0
        offset = 0
        while (
            self.pos + offset < len(self.tokens)
            and self.tokens[self.pos + offset].type == TokenType.NEWLINE
        ):
            newline_count += 1
            offset += 1

        return newline_count >= 2

    def _parse_predicate_groups(
        self, end_tokens: tuple[TokenType, ...]
    ) -> list[list[Expr]]:
        """Parse predicates grouped by blank lines for \\also generation.

        Args:
            end_tokens: Token types that end the predicate section (e.g., END, WHERE)

        Returns:
            List of predicate groups, where each group is separated by blank lines
        """
        groups: list[list[Expr]] = []
        current_group: list[Expr] = []

        while not self._at_end() and not self._match(*end_tokens):
            # Skip leading newlines before checking for predicates
            if self._match(TokenType.NEWLINE):
                # Check if this is a blank line (2+ consecutive newlines)
                if self._has_blank_line():
                    # Save current group if non-empty
                    if current_group:
                        groups.append(current_group)
                        current_group = []
                    # Skip all newlines (including the blank line)
                    self._skip_newlines()
                else:
                    # Single newline - just skip it
                    self._advance()
                continue

            # Parse predicate and add to current group
            current_group.append(self._parse_expr())

        # Add final group if non-empty
        if current_group:
            groups.append(current_group)

        return groups  # Return [] if no predicates

    def _is_keyword_usable_as_identifier(self) -> bool:
        """Check if current token is a keyword that can be used as an identifier.

        Z notation keywords (id, dom, ran, etc.) are context-sensitive.
        In declaration contexts (schema/axdef/gendef), they can be variable names.
        In expression contexts, they remain operators/functions.

        Returns:
            True if current token is a keyword usable as identifier in declarations
        """
        return self._current().type in (
            TokenType.ID,  # id (identity relation)
            TokenType.DOM,  # dom (domain)
            TokenType.RAN,  # ran (range)
            TokenType.INV,  # inv (inverse)
            TokenType.COMP,  # comp (composition)
            TokenType.MOD,  # mod (modulo)
            TokenType.BIGCUP,  # bigcup (distributed union)
            TokenType.BIGCAP,  # bigcap (distributed intersection)
            TokenType.FILTER,  # filter (sequence filter)
            TokenType.GROUP,  # group (relational operator; legal as attr name)
            TokenType.UNGROUP,  # ungroup (relational operator; legal as attr name)
        )

    # Operator keywords whose LaTeX expansion (e.g. \id, \dom) collides
    # with declaration-name use. Even though the parser can accept these
    # as attribute names, the LaTeX generator emits the operator symbol,
    # which fuzz then rejects in declaration position. Reject at the
    # parser level with a clear error.
    _RESERVED_DECL_NAMES: ClassVar[frozenset[str]] = frozenset(
        {"id", "dom", "ran", "inv", "comp", "mod", "bigcup", "bigcap", "filter"}
    )

    def _reject_reserved_decl_name(self, tok: Token) -> None:
        """Raise ParserError if `tok.value` is a reserved operator keyword.

        Operator names that have a dedicated LaTeX expansion (id → \\id,
        dom → \\dom, etc.) cannot be used as declaration variable names
        because the generator emits the operator symbol, producing
        invalid Z that fuzz rejects.
        """
        if tok.value in self._RESERVED_DECL_NAMES:
            msg = (
                f"{tok.value!r} is a reserved Z operator name and cannot be used "
                f"as a declaration variable (it would render as the operator "
                f"in LaTeX). Rename to a non-conflicting identifier "
                f"(e.g. {tok.value}1, {tok.value}Val, my{tok.value.capitalize()})."
            )
            raise ParserError(msg, tok)

    def _scan_for_colon_before_newline(self) -> bool:
        """Lookahead scan: return True if ':' appears before NEWLINE/WHERE/END/EOF.

        Used to disambiguate a bare identifier line from a typed declaration.
        ``count, count' : N`` returns True (typed declaration).
        ``Counter``           returns False (bare schema inclusion).
        Commas and identifiers between the current position and the colon are
        allowed — they are the multi-name variable list.

        Bracket depth is tracked so a COLON inside ``[...]`` (e.g., in a
        type expression within generic args) is not mistaken for the
        declaration colon.  Only a COLON at depth 0 signals a typed declaration.
        """
        offset = 0
        depth = 0
        while True:
            tok = self._peek_ahead(offset)
            if tok.type in (
                TokenType.NEWLINE,
                TokenType.WHERE,
                TokenType.END,
                TokenType.SEMICOLON,
                TokenType.EOF,
            ):
                return False
            if tok.type == TokenType.LBRACKET:
                depth += 1
            elif tok.type == TokenType.RBRACKET:
                depth -= 1
            elif tok.type == TokenType.COLON and depth == 0:
                return True
            offset += 1

    def _parse_inclusion_generic_args(self) -> list[Expr] | None:
        """Parse optional generic instantiation arguments: [expr, expr, ...].

        Returns None when no '[' is present.  Consumes the brackets and their
        contents when present (e.g., ``[Int]``, ``[N cross N]``).

        Raises ParserError for:
        - Empty brackets ``[]`` or comma-only ``[,]`` (Z RM §3.9 requires ≥1 expr)
        - Unclosed bracket — error points at the opening ``[``
        """
        if not self._match(TokenType.LBRACKET):
            return None
        open_tok = self._advance()  # consume '[', save for error reporting
        args: list[Expr] = []

        terminators = (
            TokenType.NEWLINE,
            TokenType.WHERE,
            TokenType.END,
            TokenType.EOF,
        )

        while not self._match(TokenType.RBRACKET):
            if self._at_end() or self._match(*terminators):
                raise ParserError("Unclosed '[' in generic argument list", open_tok)
            if self._match(TokenType.COMMA):
                if not args:
                    # Leading comma — no expression before it
                    raise ParserError(
                        "Expected type expression in generic argument list",
                        self._current(),
                    )
                self._advance()
                # Trailing comma before ']'
                if self._match(TokenType.RBRACKET):
                    raise ParserError(
                        "Expected type expression in generic argument list",
                        self._current(),
                    )
                continue
            args.append(self._parse_expr())

        if not args:
            raise ParserError(
                "Empty generic argument list — at least one type expression required",
                open_tok,
            )

        self._advance()  # consume ']'
        return args

    def _bracket_contains_slash(self) -> bool:
        """Return True if the next bracket group (starting at '[') contains '/'.

        Scans ahead from the current position (which must point at '[') for a
        SLASH token at bracket depth 0.  Does not consume any tokens.
        """
        depth = 0
        offset = 1  # start scanning past the '['
        while True:
            tok = self._peek_ahead(offset)
            if tok.type == TokenType.LBRACKET:
                depth += 1
            elif tok.type == TokenType.RBRACKET:
                if depth == 0:
                    return False
                depth -= 1
            elif tok.type == TokenType.SLASH and depth == 0:
                return True
            elif tok.type in (TokenType.EOF, TokenType.NEWLINE):
                return False
            offset += 1

    def _parse_schema_rename_or_generic(
        self, base: Expr
    ) -> GenericInstantiation | SchemaRename:
        """Consume '[' then dispatch to rename or generic instantiation.

        Disambiguation rule (Z RM §3.11): scan the bracket contents at
        bracket depth 0.  If any SLASH token appears before the matching
        ']', parse as schema rename pairs ``S[new/old, ...]``.  Otherwise,
        parse as a generic type instantiation ``S[T, ...]``.

        The '[' has NOT been consumed on entry; this method consumes it and
        the matching ']'.
        """
        if self._bracket_contains_slash():
            return self._parse_schema_rename(base)
        return self._parse_generic_instantiation(base)

    def _parse_generic_instantiation(self, base: Expr) -> GenericInstantiation:
        """Parse generic instantiation S[T, ...] — '[' not yet consumed."""
        lbracket_token = self._advance()  # Consume '['

        type_params: list[Expr] = []

        if self._match(TokenType.RBRACKET):
            raise ParserError(
                "Expected at least one type parameter in generic instantiation",
                self._current(),
            )

        type_params.append(self._parse_expr())

        while self._match(TokenType.COMMA):
            self._advance()  # Consume ','
            if self._match(TokenType.RBRACKET):
                # Trailing comma: Type[X,]
                break
            type_params.append(self._parse_expr())

        if not self._match(TokenType.RBRACKET):
            raise ParserError(
                "Expected ']' after generic type parameters", self._current()
            )
        self._advance()  # Consume ']'

        return GenericInstantiation(
            base=base,
            type_params=type_params,
            line=lbracket_token.line,
            column=lbracket_token.column,
        )

    def _parse_schema_rename(self, schema: Expr) -> SchemaRename:
        """Parse schema rename S[old/new, ...] — '[' not yet consumed.

        Grammar:
            rename ::= '[' pair (',' pair)* ']'
            pair   ::= IDENTIFIER '/' IDENTIFIER

        Raises ParserError for:
        - Empty bracket ``S[]``
        - Missing source name ``S[/b]``
        - Missing slash ``S[a b]``
        - Missing target name ``S[a/]``
        - Trailing slash ``S[a/b/]``
        - Trailing comma ``S[a/b,]``
        """
        open_tok = self._advance()  # Consume '['

        pairs: list[tuple[str, str]] = []

        while not self._match(TokenType.RBRACKET):
            if self._at_end() or self._match(TokenType.NEWLINE, TokenType.EOF):
                raise ParserError(
                    "unclosed '[' in schema rename",
                    open_tok,
                )

            # Expect source identifier
            if not self._match(TokenType.IDENTIFIER):
                cur = self._current()
                raise ParserError(
                    f"expected identifier before '/' in schema rename pair,"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )
            src_tok = self._advance()
            src = src_tok.value

            # Expect '/'
            if not self._match(TokenType.SLASH):
                cur = self._current()
                raise ParserError(
                    f"expected '/' in schema rename pair after {src!r},"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )
            self._advance()  # Consume '/'

            # Expect target identifier
            if not self._match(TokenType.IDENTIFIER):
                cur = self._current()
                raise ParserError(
                    f"expected identifier after '/' in schema rename pair,"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )
            tgt_tok = self._advance()
            tgt = tgt_tok.value

            pairs.append((src, tgt))

            # Optional comma separator
            if self._match(TokenType.COMMA):
                self._advance()  # Consume ','
                # Trailing comma check: next is ']'
                if self._match(TokenType.RBRACKET):
                    raise ParserError(
                        "expected rename pair after ',' in schema rename",
                        self._current(),
                    )
                continue

            # If not comma and not ']', something is wrong
            if not self._match(TokenType.RBRACKET):
                cur = self._current()
                raise ParserError(
                    f"expected ',' or ']' in schema rename,"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )

        if not pairs:
            raise ParserError(
                "schema rename requires at least one pair",
                open_tok,
            )

        if not self._match(TokenType.RBRACKET):
            raise ParserError(
                "expected ']' to close schema rename",
                self._current(),
            )
        self._advance()  # Consume ']'

        return SchemaRename(
            schema=schema,
            pairs=pairs,
            line=open_tok.line,
            column=open_tok.column,
        )

    def _parse_declaration_or_inclusion(
        self,
    ) -> Declaration | SchemaInclusion | list[Declaration]:
        """Parse one declaration line or schema-inclusion line.

        Five forms:
        1. ``pk name1, name2, ... : Type``  → list[Declaration] with is_primary_key=True
        2. ``Delta Name [generic-args]?``   → SchemaInclusion(decoration="delta")
        3. ``Xi Name [generic-args]?``      → SchemaInclusion(decoration="xi")
        4. ``name1, name2, ... : Type``     → list[Declaration]  (typed, ≥1 item)
        5. ``Name [generic-args]?``         → SchemaInclusion(decoration=None)
           (bare inclusion — only when no ':' follows on the same line)

        Returns a list of Declarations for the typed form so the caller can
        extend its declaration list directly; returns a single SchemaInclusion
        otherwise.
        """
        start_tok = self._current()

        # --- pk prefix: primary-key declaration ---
        if self._match(TokenType.PK):
            pk_tok = self._advance()  # consume 'pk'
            cur = self._current()
            # Reject pk before Delta/Xi or bare-schema inclusion (no attribute name)
            if self._match(TokenType.DELTA):
                raise ParserError(
                    "pk cannot precede Delta inclusion"
                    " (no attribute name to underline)",
                    cur,
                )
            if self._match(TokenType.XI):
                raise ParserError(
                    "pk cannot precede Xi inclusion (no attribute name to underline)",
                    cur,
                )
            # Must have an identifier (attribute name) followed eventually by ':'
            is_ident = self._match(TokenType.IDENTIFIER)
            is_kw_as_ident = self._is_keyword_usable_as_identifier()
            if not is_ident and not is_kw_as_ident:
                raise ParserError(
                    f"pk must be followed by an attribute name,"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )
            if not self._scan_for_colon_before_newline():
                raise ParserError(
                    "pk declaration requires a type annotation (name : Type)",
                    cur,
                )
            pk_var_tokens: list[Token] = []
            pk_var_tok = self._current()
            self._reject_reserved_decl_name(pk_var_tok)
            pk_var_tokens.append(pk_var_tok)
            self._advance()
            while self._match(TokenType.COMMA):
                self._advance()  # consume ','
                if not (
                    self._match(TokenType.IDENTIFIER)
                    or self._is_keyword_usable_as_identifier()
                ):
                    raise ParserError(
                        "Expected variable name after ','", self._current()
                    )
                self._reject_reserved_decl_name(self._current())
                pk_var_tokens.append(self._current())
                self._advance()
            if not self._match(TokenType.COLON):
                raise ParserError("Expected ':' in pk declaration", self._current())
            self._advance()  # consume ':'
            pk_type_expr = self._parse_expr()
            return [
                Declaration(
                    variable=vt.value,
                    type_expr=pk_type_expr,
                    is_primary_key=True,
                    line=pk_tok.line,
                    column=pk_tok.column,
                )
                for vt in pk_var_tokens
            ]

        # --- Delta / Xi decorated inclusion ---
        if self._match(TokenType.DELTA, TokenType.XI):
            decoration = "delta" if self._match(TokenType.DELTA) else "xi"
            kw = "Delta" if decoration == "delta" else "Xi"
            self._advance()  # consume Delta / Xi
            # Must be followed by an identifier (schema name)
            if not self._match(TokenType.IDENTIFIER):
                cur = self._current()
                raise ParserError(
                    f"Expected schema name after {kw},"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )
            name_tok = self._advance()
            generics = self._parse_inclusion_generic_args()
            return SchemaInclusion(
                name=name_tok.value,
                decoration=decoration,
                generics=generics,
                line=start_tok.line,
                column=start_tok.column,
            )

        # --- IDENTIFIER (or keyword-as-identifier) ---
        # Scan ahead to decide: typed declaration vs bare inclusion.
        if not self._scan_for_colon_before_newline():
            # No colon before newline → bare schema inclusion
            name_tok = self._advance()
            generics = self._parse_inclusion_generic_args()
            return SchemaInclusion(
                name=name_tok.value,
                decoration=None,
                generics=generics,
                line=start_tok.line,
                column=start_tok.column,
            )

        # Colon found → typed declaration (original path)
        var_tokens: list[Token] = []
        var_tok = self._current()
        self._reject_reserved_decl_name(var_tok)
        var_tokens.append(var_tok)
        self._advance()

        while self._match(TokenType.COMMA):
            self._advance()  # consume ','
            if not (
                self._match(TokenType.IDENTIFIER)
                or self._is_keyword_usable_as_identifier()
            ):
                raise ParserError("Expected variable name after ','", self._current())
            self._reject_reserved_decl_name(self._current())
            var_tokens.append(self._current())
            self._advance()

        if not self._match(TokenType.COLON):
            raise ParserError("Expected ':' in declaration", self._current())
        self._advance()  # consume ':'

        type_expr = self._parse_expr()

        return [
            Declaration(
                variable=vt.value,
                type_expr=type_expr,
                line=vt.line,
                column=vt.column,
            )
            for vt in var_tokens
        ]

    def _smart_join_justification(self, parts: list[str]) -> str:
        """Join justification tokens intelligently.

        Strategy: Join with spaces (preserving word separation), then remove
        spaces around parentheses, brackets, and equals signs to compact
        mathematical notation.

        Examples:
        - ["length", "(", "<", "ple", ">", "^", "pl", ")"] → "length(<ple>^pl)"
        - ["commutativity", "of", "or"] → "commutativity of or"
        - ["x", "is", "not", "free", "in", "y", "|->", "z"] → "x is not free in y|->z"
        - ["def", ".", "of", "=>"] → "def. of =>" (preserves space before =>)
        """
        if not parts:
            return ""

        # First join with spaces (preserves all word separation)
        result = " ".join(parts)

        # Remove spaces around specific punctuation to compact notation
        # ONLY touch safe characters that aren't part of operators
        result = re.sub(r"\s*\(\s*", "(", result)  # Remove space before/after (
        result = re.sub(r"\s*\)\s*", ")", result)  # Remove space before/after )
        # Remove space around standalone = but NOT part of operators (=>, <=>)
        # Negative lookahead/lookbehind avoids matching = in operators
        result = re.sub(r"\s*(?<![<>])=(?![>])\s*", "=", result)
        result = re.sub(r"\s*\.", ".", result)  # Remove space BEFORE period only
        return re.sub(r"\s*,", ",", result)  # Remove space BEFORE comma only

        # DO NOT touch < or > as they appear in many operators (=>, ->>, etc.)
        # Sequences like <ple> will have internal spacing, but that's acceptable
        # to avoid breaking operator conversion in _escape_justification

    def _parse_section(self) -> Section:
        """Parse section: === Title ==="""
        start_token = self._advance()  # Consume first '==='

        # The lexer emits a TEXT token carrying the raw title text between the
        # two === markers (verbatim, stripped of surrounding whitespace).  Fall
        # back to collecting individual tokens for malformed inputs.
        if self._match(TokenType.TEXT):
            title = self._advance().value
            # Consume the closing ===
            if self._match(TokenType.SECTION_MARKER):
                self._advance()
        else:
            # Fallback: collect individual tokens until closing ===.
            title_parts: list[str] = []
            while not self._match(TokenType.SECTION_MARKER) and not self._at_end():
                if self._match(TokenType.NEWLINE):
                    break  # Section title on one line
                title_parts.append(self._current().value)
                self._advance()

            if not self._match(TokenType.SECTION_MARKER):
                raise ParserError("Expected closing '===' for section", self._current())

            self._advance()  # Consume closing '==='
            # Reconstruct title, joining contraction/possessive suffixes directly
            # (no space before tokens that start with apostrophe, e.g. "'s", "'t").
            title_words: list[str] = []
            for part in title_parts:
                if part.startswith("'") and title_words:
                    title_words[-1] += part
                else:
                    title_words.append(part)
            title = " ".join(title_words)

        self._skip_newlines()

        # Parse section content until next section or end
        items: list[DocumentItem] = []
        while not self._at_end() and not self._match(TokenType.SECTION_MARKER):
            items.append(self._parse_document_item())
            self._skip_newlines()

        return Section(
            title=title, items=items, line=start_token.line, column=start_token.column
        )

    def _parse_solution(self) -> Solution:
        """Parse solution: ** Solution N **"""
        start_token = self._advance()  # Consume first '**'

        # Collect solution number/text (all tokens until closing **)
        solution_parts: list[str] = []
        while not self._match(TokenType.SOLUTION_MARKER) and not self._at_end():
            if self._match(TokenType.NEWLINE):
                break  # Solution marker on one line
            solution_parts.append(self._current().value)
            self._advance()

        if not self._match(TokenType.SOLUTION_MARKER):
            raise ParserError("Expected closing '**' for solution", self._current())

        self._advance()  # Consume closing '**'
        # Reconstruct number, joining contraction/possessive suffixes directly.
        number_words: list[str] = []
        for part in solution_parts:
            if part.startswith("'") and number_words:
                number_words[-1] += part
            else:
                number_words.append(part)
        number = " ".join(number_words)
        self._skip_newlines()

        # Parse solution content until next solution/section or end
        items: list[DocumentItem] = []
        while not self._at_end() and not self._match(
            TokenType.SOLUTION_MARKER, TokenType.SECTION_MARKER
        ):
            items.append(self._parse_document_item())
            self._skip_newlines()

        return Solution(
            number=number, items=items, line=start_token.line, column=start_token.column
        )

    def _parse_part(self) -> Part:
        """Parse part: (a) content"""
        part_token = self._advance()  # Consume '(a)', '(b)', etc.

        # Extract label from token value: "(a)" -> "a"
        label = part_token.value[1:-1]
        self._skip_newlines()

        # Parse part content until next part/solution/section or end
        items: list[DocumentItem] = []
        while not self._at_end() and not self._match(
            TokenType.PART_LABEL,
            TokenType.SOLUTION_MARKER,
            TokenType.SECTION_MARKER,
        ):
            items.append(self._parse_document_item())
            self._skip_newlines()

        return Part(
            label=label, items=items, line=part_token.line, column=part_token.column
        )

    def _parse_truth_table(self) -> TruthTable:
        """Parse truth table: TRUTH TABLE: followed by table rows."""
        start_token = self._advance()  # Consume 'TRUTH TABLE:'
        self._skip_newlines()

        # Parse header row (columns separated by |)
        headers: list[str] = []
        if not self._match(TokenType.IDENTIFIER):
            raise ParserError("Expected truth table header row", self._current())

        # Collect columns (tokens between pipes)
        column_tokens: list[str] = []
        while not self._match(TokenType.NEWLINE) and not self._at_end():
            if self._match(TokenType.PIPE):
                # Save current column
                if column_tokens:
                    headers.append(" ".join(column_tokens))
                    column_tokens = []
                self._advance()  # Skip pipe
            elif self._match(
                TokenType.IDENTIFIER,
                TokenType.AND,
                TokenType.OR,
                TokenType.NOT,
                TokenType.IMPLIES,
                TokenType.IFF,
                TokenType.LPAREN,
                TokenType.RPAREN,
            ):
                column_tokens.append(self._current().value)
                self._advance()
            else:
                break

        # Add last column
        if column_tokens:
            headers.append(" ".join(column_tokens))

        if not headers:
            raise ParserError("Expected truth table headers", self._current())

        self._skip_newlines()

        # Parse data rows
        rows: list[list[str]] = []
        while not self._at_end() and not self._is_structural_token():
            row: list[str] = []

            # Check if line starts with T/t or F/f (truth values)
            # Note: F may be lexed as FINSET, P as POWER
            if not self._match(TokenType.IDENTIFIER, TokenType.FINSET, TokenType.POWER):
                break

            first_val = self._current().value
            if first_val.upper() not in ("T", "F", "P"):
                break  # Not a truth table row

            # Collect row values separated by pipes, normalizing to uppercase
            while not self._match(TokenType.NEWLINE) and not self._at_end():
                if self._match(TokenType.PIPE):
                    self._advance()  # Skip pipe
                elif self._match(
                    TokenType.IDENTIFIER, TokenType.FINSET, TokenType.POWER
                ):
                    val = self._current().value
                    # Normalize t/f to T/F
                    row.append(val.upper() if val.upper() in ("T", "F") else val)
                    self._advance()
                else:
                    break

            if row:
                rows.append(row)
            self._skip_newlines()

        return TruthTable(
            headers=headers,
            rows=rows,
            line=start_token.line,
            column=start_token.column,
        )

    def _parse_argue_chain(self, connector: Literal["iff", "eq"] = "iff") -> ArgueChain:
        """Parse ARGUE:, EQUIV:, or EQUAL: block into an ArgueChain.

        Both EQUIV: and ARGUE: keywords produce connector='iff', rendered
        with \\Leftrightarrow between steps. EQUAL: produces connector='eq',
        rendered with = between steps (for expression equality chains).
        The generator uses a standard LaTeX array environment — not fuzz's
        argue environment — for reliable column spacing and adjustbox scaling.
        """
        start_token = self._advance()  # Consume 'ARGUE:', 'EQUIV:', or 'EQUAL:'
        self._skip_newlines()

        steps: list[ArgueStep] = []

        # Parse steps until we hit another structural element or end
        while not self._at_end() and not self._is_structural_token():
            # Consume leading connective if present on continuation lines.
            # Connector specificity: an EQUAL: block must never silently consume
            # a leading <=>, and an EQUIV/ARGUE block must never consume a leading =.
            # Note: = on a continuation line is consumed by _parse_comparison
            # (which crosses newlines), so the EQUALS branch rarely fires in
            # practice. The IFF branch fires because _parse_iff does NOT cross
            # newlines, so a bare <=> at line start reaches this check.
            if connector == "eq" and self._match(TokenType.EQUALS):
                self._advance()  # Consume leading '='
            elif connector == "iff" and self._match(TokenType.IFF):
                self._advance()  # Consume leading '<=>'
            elif connector == "eq" and self._match(TokenType.IFF):
                # <=> at the start of an EQUAL: continuation line means the
                # author used the wrong block type.  A clear message is more
                # helpful than the generic "unexpected token" from _parse_expr.
                tok = self._current()
                msg = (
                    "found '<=>' continuation in an EQUAL: chain; "
                    "use EQUIV: or ARGUE: for logical-equivalence chains"
                )
                raise ParserError(msg, tok)
            elif connector == "iff" and self._match(TokenType.EQUALS):
                # bare '=' at the start of an EQUIV:/ARGUE: continuation line
                # — the author may have intended EQUAL:.  Note: in practice
                # _parse_comparison absorbs 'a\n= b' as a single step, so
                # this branch fires only for a truly bare '=' with nothing
                # before it on the line, which is syntactically invalid.
                tok = self._current()
                msg = (
                    "found '=' continuation in an EQUIV:/ARGUE: chain; "
                    "use EQUAL: for expression-equality chains"
                )
                raise ParserError(msg, tok)

            # Parse expression
            expr = self._parse_expr()
            self._skip_newlines()

            # Check for optional justification [text]
            justification: str | None = None
            if self._match(TokenType.LBRACKET):
                self._advance()  # Consume '['

                # Collect justification text (all tokens until ']')
                just_parts: list[str] = []
                while not self._match(TokenType.RBRACKET) and not self._at_end():
                    if self._match(TokenType.NEWLINE):
                        break  # Justification on one line
                    just_parts.append(self._current().value)
                    self._advance()

                if not self._match(TokenType.RBRACKET):
                    raise ParserError(
                        "Expected closing ']' for justification", self._current()
                    )

                self._advance()  # Consume ']'
                # Join tokens smartly: add spaces only between consecutive identifiers
                justification = self._smart_join_justification(just_parts)

            # Create step
            steps.append(
                ArgueStep(
                    expression=expr,
                    justification=justification,
                    line=expr.line,
                    column=expr.column,
                )
            )

            self._skip_newlines()

        if not steps:
            raise ParserError(
                "Expected at least one step in ARGUE/EQUIV/EQUAL chain",
                self._current(),
            )

        return ArgueChain(
            steps=steps,
            connector=connector,
            line=start_token.line,
            column=start_token.column,
        )

    def _parse_infrule_block(self) -> InfruleBlock:
        """Parse INFRULE: block with premises, ---, and conclusion.

        Format:
          INFRULE:
          premise1 [label1]
          premise2 [label2]
          ---
          conclusion [label]
        """
        start_token = self._advance()  # Consume 'INFRULE:'
        self._skip_newlines()

        premises: list[tuple[Expr, str | None]] = []

        # Parse premises until we hit ---
        while not self._at_end() and not self._match(TokenType.DERIVE):
            # Check if we hit another structural token (error)
            if self._is_structural_token():
                raise ParserError(
                    "Expected '---' separator in INFRULE block", self._current()
                )

            # Parse premise expression
            expr = self._parse_expr()
            self._skip_newlines()

            # Check for optional label [text]
            label: str | None = None
            if self._match(TokenType.LBRACKET):
                self._advance()  # Consume '['

                # Collect label text (all tokens until ']')
                label_parts: list[str] = []
                while not self._match(TokenType.RBRACKET) and not self._at_end():
                    if self._match(TokenType.NEWLINE):
                        break  # Label on one line
                    label_parts.append(self._current().value)
                    self._advance()

                if not self._match(TokenType.RBRACKET):
                    raise ParserError("Expected closing ']' for label", self._current())

                self._advance()  # Consume ']'
                label = self._smart_join_justification(label_parts)

            premises.append((expr, label))
            self._skip_newlines()

        # Check for --- separator
        if not self._match(TokenType.DERIVE):
            raise ParserError(
                "Expected '---' separator in INFRULE block", self._current()
            )

        self._advance()  # Consume '---'
        self._skip_newlines()

        # Parse conclusion expression
        if self._at_end() or self._is_structural_token():
            raise ParserError(
                "Expected conclusion after '---' in INFRULE block", self._current()
            )

        conclusion_expr = self._parse_expr()
        self._skip_newlines()

        # Check for optional label [text]
        conclusion_label: str | None = None
        if self._match(TokenType.LBRACKET):
            self._advance()  # Consume '['

            # Collect label text
            conclusion_label_parts: list[str] = []
            while not self._match(TokenType.RBRACKET) and not self._at_end():
                if self._match(TokenType.NEWLINE):
                    break
                conclusion_label_parts.append(self._current().value)
                self._advance()

            if not self._match(TokenType.RBRACKET):
                raise ParserError(
                    "Expected closing ']' for conclusion label", self._current()
                )

            self._advance()  # Consume ']'
            conclusion_label = self._smart_join_justification(conclusion_label_parts)

        if not premises:
            raise ParserError(
                "Expected at least one premise in INFRULE block", self._current()
            )

        return InfruleBlock(
            premises=premises,
            conclusion=(conclusion_expr, conclusion_label),
            line=start_token.line,
            column=start_token.column,
        )

    def _parse_expr(self) -> Expr:
        """Parse expression (entry point)."""
        # Check for quantifier first (forall, exists, exists1, mu)
        if self._match(
            TokenType.FORALL, TokenType.EXISTS, TokenType.EXISTS1, TokenType.MU
        ):
            return self._parse_quantifier()
        # Check for lambda expression
        if self._match(TokenType.LAMBDA):
            return self._parse_lambda()
        # Check for conditional expression (if/then/else)
        if self._match(TokenType.IF):
            return self._parse_conditional()
        return self._parse_iff()

    def _parse_conditional(self) -> Expr:
        """Parse conditional expression: if condition then expr1 else expr2.

        Examples:
            if x > 0 then x else -x
            if s = <> then 0 else head s
            if x > 0 then 1 else if x < 0 then -1 else 0 (nested)

        Supports explicit line breaks with \\ continuation marker:
            if x > 0 \\
              then x \\
              else -x

        The condition is parsed with _parse_iff() (no quantifiers/lambdas/conditionals),
        but the then/else branches use _parse_expr() to allow nested conditionals.
        """
        if_token = self._advance()  # Consume 'if'

        # Parse condition (up to 'then') - no quantifiers/lambdas/conditionals
        condition = self._parse_iff()

        # Check for explicit line break after condition (before 'then')
        line_break_after_condition = False
        if self._match(TokenType.CONTINUATION):
            self._advance()  # consume \\
            line_break_after_condition = True

        # Skip newlines before 'then' (multi-line support)
        self._skip_newlines()

        # Expect 'then'
        if not self._match(TokenType.THEN):
            raise ParserError("Expected 'then' after if condition", self._current())
        self._advance()  # Consume 'then'

        # Skip newlines after 'then' (multi-line support)
        self._skip_newlines()

        # Parse then branch - allow nested conditionals
        then_expr = self._parse_expr()

        # Check for explicit line break after then expression (before 'else')
        line_break_after_then = False
        if self._match(TokenType.CONTINUATION):
            self._advance()  # consume \\
            line_break_after_then = True

        # Skip newlines before 'else' (multi-line support)
        self._skip_newlines()

        # Expect 'else'
        if not self._match(TokenType.ELSE):
            raise ParserError("Expected 'else' after then expression", self._current())
        self._advance()  # Consume 'else'

        # Skip newlines after 'else' (multi-line support)
        self._skip_newlines()

        # Parse else branch - allow nested conditionals
        else_expr = self._parse_expr()

        return Conditional(
            condition=condition,
            then_expr=then_expr,
            else_expr=else_expr,
            line_break_after_condition=line_break_after_condition,
            line_break_after_then=line_break_after_then,
            line=if_token.line,
            column=if_token.column,
        )

    def _parse_iff(self) -> Expr:
        """Parse iff operation (<=>), lowest precedence.

        Supports multi-line expressions with natural line breaks.
        """
        left = self._parse_implies()

        while self._match(TokenType.IFF):
            op_token = self._advance()
            # Detect line continuation (backslash or natural newline)
            has_continuation = False
            if self._match(TokenType.CONTINUATION):
                self._advance()  # consume \
                has_continuation = True
                # Skip newline and any leading whitespace on next line
                if self._match(TokenType.NEWLINE):
                    self._advance()
                self._skip_newlines()
            elif self._match(TokenType.NEWLINE):
                # Natural line break without \ marker (WYSIWYG)
                has_continuation = True
                self._skip_newlines()
            else:
                # No line break, but still skip newlines for flexibility
                self._skip_newlines()
            right = self._parse_implies()
            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line_break_after=has_continuation,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _parse_implies(self) -> Expr:
        """Parse implies operation (=>).

        Right side can be a quantifier to support patterns like:
        exists d : Dog | gentle(d) => forall t : Trainer | groomed(d, t)

        Implies is right-associative: a => b => c parses as a => (b => c)
        Implies binds tighter than iff: a => b <=> c parses as (a => b) <=> c

        Supports multi-line expressions with natural line breaks.
        """
        left = self._parse_or()

        while self._match(TokenType.IMPLIES):
            op_token = self._advance()
            # Detect line continuation (backslash or natural newline)
            has_continuation = False
            if self._match(TokenType.CONTINUATION):
                self._advance()  # consume \
                has_continuation = True
                # Skip newline and any leading whitespace on next line
                if self._match(TokenType.NEWLINE):
                    self._advance()
                self._skip_newlines()
            elif self._match(TokenType.NEWLINE):
                # Natural line break without \ marker (WYSIWYG)
                has_continuation = True
                self._skip_newlines()
            else:
                # No line break, but still skip newlines for flexibility
                self._skip_newlines()
            # Parse RHS: allow quantifiers/lambdas/conditionals but NOT iff (<=>)
            # This ensures => binds tighter than <=>
            right = self._parse_implies_rhs()
            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line_break_after=has_continuation,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _parse_implies_rhs(self) -> Expr:
        """Parse right-hand side of implies: allows quantifiers but not iff.

        This ensures proper precedence: a => b <=> c parses as (a => b) <=> c
        while still allowing: a => forall x : T | P
        """
        # Check for quantifier first (forall, exists, exists1, mu)
        if self._match(
            TokenType.FORALL, TokenType.EXISTS, TokenType.EXISTS1, TokenType.MU
        ):
            return self._parse_quantifier()
        # Check for lambda expression
        if self._match(TokenType.LAMBDA):
            return self._parse_lambda()
        # Check for conditional expression (if/then/else)
        if self._match(TokenType.IF):
            return self._parse_conditional()
        # Parse implies level (right-associative) - NOT iff level
        return self._parse_implies()

    def _parse_or(self) -> Expr:
        """Parse or operation.

        Supports multi-line expressions with natural line breaks.
        """
        left = self._parse_and()

        while self._match(TokenType.OR):
            op_token = self._advance()
            # Detect line continuation (backslash or natural newline)
            has_continuation = False
            if self._match(TokenType.CONTINUATION):
                self._advance()  # consume \
                has_continuation = True
                # Skip newline and any leading whitespace on next line
                if self._match(TokenType.NEWLINE):
                    self._advance()
                self._skip_newlines()
            elif self._match(TokenType.NEWLINE):
                # Natural line break without \ marker (WYSIWYG)
                has_continuation = True
                self._skip_newlines()
            else:
                # No line break, but still skip newlines for flexibility
                self._skip_newlines()
            right = self._parse_and()
            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line_break_after=has_continuation,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _parse_and(self) -> Expr:
        """Parse and operation.

        Allows quantifiers after 'and' (e.g., p and forall x : T | q).
        Supports multi-line expressions with natural line breaks.
        """
        left = self._parse_comparison()

        while self._match(TokenType.AND):
            op_token = self._advance()
            # Detect line continuation (backslash or natural newline)
            has_continuation = False
            if self._match(TokenType.CONTINUATION):
                self._advance()  # consume \
                has_continuation = True
                # Skip newline and any leading whitespace on next line
                if self._match(TokenType.NEWLINE):
                    self._advance()
                self._skip_newlines()
            elif self._match(TokenType.NEWLINE):
                # Natural line break without \ marker (WYSIWYG)
                has_continuation = True
                self._skip_newlines()
            else:
                # No line break, but still skip newlines for flexibility
                self._skip_newlines()
            # Quantifiers can appear after 'and' (e.g., p and forall x : T | q)
            # Check if next token is a quantifier keyword
            if self._match(
                TokenType.FORALL, TokenType.EXISTS, TokenType.EXISTS1, TokenType.MU
            ):
                right = self._parse_quantifier()
            else:
                right = self._parse_comparison()
            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line_break_after=has_continuation,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _parse_unary(self) -> Expr:
        """Parse unary operation (not, #, -).

        Handles logical not, cardinality (#), and arithmetic negation (-).
        """
        if self._match(TokenType.NOT):
            op_token = self._advance()
            operand = self._parse_unary()
            return UnaryOp(
                operator=op_token.value,
                operand=operand,
                line=op_token.line,
                column=op_token.column,
            )

        # Cardinality operator (#)
        if self._match(TokenType.HASH):
            op_token = self._advance()
            operand = self._parse_unary()
            return UnaryOp(
                operator=op_token.value,
                operand=operand,
                line=op_token.line,
                column=op_token.column,
            )

        # Unary negation (-)
        if self._match(TokenType.MINUS):
            op_token = self._advance()
            operand = self._parse_unary()
            return UnaryOp(
                operator=op_token.value,
                operand=operand,
                line=op_token.line,
                column=op_token.column,
            )

        return self._parse_range()

    def _parse_additive(self) -> Expr:
        """Parse additive operators (+ and - and ⌢).

        Arithmetic operators: + (addition), - (subtraction)
        Sequence operator: ⌢ (concatenation)
        Note: + can also be postfix (transitive closure R+), handled by lookahead
        """
        left = self._parse_multiplicative()

        while self._match(
            TokenType.PLUS,
            TokenType.MINUS,
            TokenType.CAT,
            TokenType.FILTER,
            TokenType.BAG_UNION,
            TokenType.BAG_DIFF,
        ):
            # Lookahead for +: only treat as infix if followed by operand
            # CAT, FILTER, BAG_UNION, BAG_DIFF, and MINUS are always infix
            if self._match(TokenType.PLUS) and not self._is_operand_start():
                break
            op_token = self._advance()
            right = self._parse_multiplicative()
            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _parse_range(self) -> Expr:
        """Parse range operator (m..n).

        Creates integer ranges: m..n represents {m, m+1, m+2, ..., n}
        Range has lower precedence than addition, so 1+2..3+4 means (1+2)..(3+4)
        Examples: 1..10, 1993..current, x.2..x.3
        """
        left = self._parse_additive()

        if self._match(TokenType.RANGE):
            op_token = self._advance()
            right = self._parse_additive()
            return Range(
                start=left,
                end=right,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _parse_multiplicative(self) -> Expr:
        """Parse multiplicative operators (*, /, mod).

        Arithmetic operators: * (multiplication), / (division), mod (modulo)
        Note: * can also be postfix (reflexive-transitive closure R*),
        handled by lookahead
        """
        left = self._parse_postfix()

        while self._match(TokenType.STAR, TokenType.MOD):
            # Lookahead for *: only treat as infix if followed by operand
            if self._match(TokenType.STAR) and not self._is_operand_start():
                break
            op_token = self._advance()
            right = self._parse_postfix()
            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _is_operand_start(self) -> bool:
        """Check if next token could start an operand expression.

        Used for lookahead to disambiguate postfix +/* from infix +/*.
        Checks the NEXT token, not the current one.

        """
        next_token = self._peek_ahead(1)
        return next_token.type in (
            TokenType.IDENTIFIER,
            TokenType.NUMBER,
            TokenType.LPAREN,
            TokenType.LBRACE,
            TokenType.LBRACKET,
            TokenType.NOT,
            TokenType.HASH,
            TokenType.MINUS,  # Unary negation
            TokenType.POWER,
            TokenType.POWER1,
            TokenType.FINSET,  # F (finite sets)
            TokenType.FINSET1,  # F1 (non-empty finite sets)
            TokenType.FORALL,
            TokenType.EXISTS,
            TokenType.EXISTS1,
            TokenType.MU,
            TokenType.LAMBDA,
            TokenType.IF,  # Conditional expressions (if/then/else)
            TokenType.SIGMA,  # sigma[...](...)
            TokenType.PI,  # pi[...](...)
        )

    def _should_parse_space_separated_arg(self) -> bool:
        """Check if we should parse next token as space-separated function argument.

        Space-separated application parses f x as function application.
        Returns True if next token could start an operand and we're not at
        a delimiter, separator, or infix operator.
        """
        # At end of input
        if self._at_end():
            return False

        current = self._current()

        # Reject common English prose words to avoid parsing text as math
        # This prevents "x >= 0 is true" from being parsed as function applications
        if (
            current.type == TokenType.IDENTIFIER
            and current.value.lower() in PROSE_WORDS
        ):
            return False

        # Stop at delimiters
        if current.type in (
            TokenType.RPAREN,
            TokenType.RBRACE,
            TokenType.RBRACKET,
            TokenType.RANGLE,
            TokenType.COMMA,
        ):
            return False

        # Stop at separators
        if current.type in (
            TokenType.NEWLINE,
            TokenType.SEMICOLON,
            TokenType.PIPE,
            TokenType.CONTINUATION,  # Line break marker
        ):
            return False

        # Stop at keywords that end expressions
        if current.type in (
            TokenType.WHERE,
            TokenType.END,
            TokenType.THEN,
            TokenType.ELSE,
            TokenType.AND,
            TokenType.OR,
        ):
            return False

        # Stop at infix operators
        if current.type in (
            TokenType.PLUS,
            TokenType.MINUS,
            TokenType.STAR,
            TokenType.MOD,
            TokenType.CAT,  # ⌢ concatenation
            TokenType.FILTER,  # ↾ sequence filter
            TokenType.BAG_UNION,  # ⊎ bag union
            TokenType.BAG_DIFF,  # bag_diff bag difference
            TokenType.RANGE,  # ..
            TokenType.EQUALS,
            TokenType.NOT_EQUAL,
            TokenType.LESS_THAN,
            TokenType.GREATER_THAN,
            TokenType.LESS_EQUAL,
            TokenType.GREATER_EQUAL,
            TokenType.IN,
            TokenType.NOTIN,
            TokenType.SUBSET,
            TokenType.PSUBSET,  # psubset (strict subset)
            TokenType.UNION,
            TokenType.INTERSECT,
            TokenType.SETMINUS,  # \ set difference
            TokenType.CROSS,  # x cross product
            TokenType.OVERRIDE,  # ++ override
            TokenType.RELATION,  # <->
            TokenType.MAPLET,  # |->
            TokenType.DRES,  # <|
            TokenType.RRES,  # |>
            TokenType.NDRES,  # <<|
            TokenType.NRRES,  # |>>
            TokenType.CIRC,  # o9
            TokenType.COMP,  # comp
            TokenType.TFUN,  # ->
            TokenType.PFUN,  # +->
            TokenType.TINJ,  # >->
            TokenType.PINJ,  # >+>
            TokenType.PINJ_ALT,  # -|>
            TokenType.TSURJ,  # -->>
            TokenType.PSURJ,  # +->>
            TokenType.BIJECTION,  # >->>
            TokenType.FINFUN,  # 77-> (finite partial function)
            TokenType.IMPLIES,  # =>
            TokenType.IFF,  # <=>
            TokenType.JOIN,  # join (natural join / theta-join)
            TokenType.DIV,  # div (relational division)
        ):
            return False

        # Check if current token could start an operand
        return current.type in (
            TokenType.IDENTIFIER,
            TokenType.NUMBER,
            TokenType.LPAREN,
            TokenType.LBRACE,
            TokenType.LANGLE,
            TokenType.NOT,
            TokenType.HASH,
            TokenType.DOM,
            TokenType.RAN,
            TokenType.INV,
            TokenType.ID,
            TokenType.POWER,
            TokenType.POWER1,
            TokenType.FINSET,
            TokenType.FINSET1,
            TokenType.BIGCUP,
            TokenType.BIGCAP,
            TokenType.LAMBDA,
            TokenType.IF,
            TokenType.SIGMA,
            TokenType.PI,
        )

    def _parse_quantifier(self) -> Expr:
        """Parse quantifier: (forall|exists|exists1|mu) var [, var]* : domain | body.

        Supports:
            - Multiple variables with shared domain: forall x, y : N | pred
            - Tuple patterns for destructuring: forall (x, y) : T | pred
            - Semicolon-separated bindings (nested): forall x : T; y : U | pred
            - Mu-operator with expression: mu x : N | pred . expr
            - Schema-text quantification (Z RM §3.10):
                exists Delta S | P
                exists Xi S | P
                exists S | P
                exists S' | P
                forall Delta S | P

        Disambiguation rule (Z RM §3.10):
            If `:` follows the identifier  → value-binding (existing path).
            If `Delta`/`Xi` precedes the identifier, or
            if the identifier is followed directly by `|` or NEWLINE→`|`
                → schema-binding (new path).

        Examples:
            forall x : N | pred
            forall x, y : N | pred
            forall (x, y) : T | pred
            exists1 x : N | pred
            mu x : N | pred . expr
            exists Delta S | P
            exists Xi S | P
            exists S | P
            exists S' | P
        """
        quant_token = self._advance()  # Consume 'forall', 'exists', 'exists1', or 'mu'

        # --- Schema-text quantification (Z RM §3.10) ---
        #
        # Check for Delta/Xi decoration before identifier.
        if self._match(TokenType.DELTA, TokenType.XI):
            decoration: Literal["Delta", "Xi", "None", "Prime"] = (
                "Delta" if self._match(TokenType.DELTA) else "Xi"
            )
            self._advance()  # Consume Delta or Xi
            if not self._match(TokenType.IDENTIFIER):
                raise ParserError(
                    f"Expected schema name after {decoration}",
                    self._current(),
                )
            schema_token = self._advance()
            schema_binding = SchemaBinding(
                decoration=decoration,
                schema_name=schema_token.value,
                line=schema_token.line,
                column=schema_token.column,
            )
            return self._parse_schema_quantifier_body(quant_token, schema_binding)

        # Check for bare IDENTIFIER followed by | (schema-as-declaration or primed).
        #
        # Disambiguation (Z naming convention, Z RM §3.2):
        #   - Schema names begin with an uppercase letter.
        #   - Variable names begin with a lowercase letter.
        #   - Presence of `:` after the identifier → value binding regardless.
        #   - Uppercase initial + no `:` or `,` follows → schema binding.
        #
        # Examples:
        #   exists S | P        → schema binding  (S is uppercase)
        #   exists S' | P       → schema binding  (S' is uppercase-initial)
        #   exists x | P        → value binding   (x is lowercase, no domain)
        #   exists x : T | P    → value binding   (: follows)
        if self._match(TokenType.IDENTIFIER):
            ident_token = self._peek_ahead(0)  # peek at current without consuming
            next_tok = self._peek_ahead(1)
            schema_name = ident_token.value
            # Strip trailing prime for the uppercase check
            base_name = schema_name.rstrip("'")
            is_schema_name = bool(base_name) and base_name[0].isupper()
            not_decl = next_tok.type not in (TokenType.COLON, TokenType.COMMA)
            if is_schema_name and not_decl:
                # Schema binding: bare S | P or S' | P
                self._advance()  # consume the identifier
                deco: Literal["Delta", "Xi", "None", "Prime"] = (
                    "Prime" if schema_name.endswith("'") else "None"
                )
                schema_binding = SchemaBinding(
                    decoration=deco,
                    schema_name=schema_name,
                    line=ident_token.line,
                    column=ident_token.column,
                )
                return self._parse_schema_quantifier_body(quant_token, schema_binding)
            # Fall through to value-binding path (: follows, or lowercase name)

        # Parse variable pattern: simple identifiers or tuple pattern like (x, y)
        tuple_pattern: Expr | None = None
        variables: list[str]

        if self._match(TokenType.LPAREN):
            # Tuple pattern: forall (x, y) : T | P
            tuple_pattern = self._parse_parenthesized_expr_or_tuple()

            # Extract variable names from tuple (validation: must be all identifiers)
            variables = []
            if isinstance(tuple_pattern, Tuple):
                for element in tuple_pattern.elements:
                    if isinstance(element, Identifier):
                        variables.append(element.name)
                    else:
                        raise ParserError(
                            "Tuple pattern in quantifier must contain only "
                            f"identifiers, not {type(element).__name__}",
                            self._current(),
                        )
            else:
                raise ParserError("Expected tuple pattern after '('", self._current())

            if not variables:
                raise ParserError(
                    "Tuple pattern in quantifier cannot be empty", self._current()
                )

        elif self._match(TokenType.IDENTIFIER):
            # Simple variable pattern: forall x : T | P
            variables = [self._advance().value]

            # Parse additional variables if comma-separated
            while self._match(TokenType.COMMA):
                self._advance()  # Consume ','
                if not self._match(TokenType.IDENTIFIER):
                    raise ParserError(
                        "Expected variable name after ','", self._current()
                    )
                variables.append(self._advance().value)
        else:
            raise ParserError(
                f"Expected variable name or tuple pattern after {quant_token.value}",
                self._current(),
            )

        # Parse optional domain (: domain)
        domain: Expr | None = None
        if self._match(TokenType.COLON):
            self._advance()  # Consume ':'
            # Parse type expression: union, cross, function & relation types
            # Allows: forall x : A union B | P
            # Allows: forall f : X -> Y | P (function type)
            # Allows: forall R : X <-> Y | P (relation type)
            # Set flag to prevent .identifier from being parsed as projection
            self._parsing_schema_text = True
            try:
                domain = self._parse_function_type()
            finally:
                self._parsing_schema_text = False

        # Check for semicolon-separated bindings (x : T; y : U | body)
        # Transform into nested quantifiers: Q x : T | Q y : U | body
        if self._match(TokenType.SEMICOLON):
            self._advance()  # Consume ';'

            # Recursively parse remaining quantifiers (same quantifier type)
            # We need to temporarily create a token for the nested quantifier
            # Save position for nested quantifier
            nested_line = self._current().line
            nested_column = self._current().column

            # Parse the rest as if it were a new quantifier of the same type
            # This will handle: y : U | body or y : U; z : V | body
            nested_quant = self._parse_quantifier_continuation(
                quant_token.value,
                nested_line,
                nested_column,
                inherited_vars=set(variables),
            )

            # Now wrap the nested quantifier as the body of this quantifier
            return Quantifier(
                quantifier=quant_token.value,
                variables=variables,
                domain=domain,
                body=nested_quant,
                expression=None,
                tuple_pattern=tuple_pattern,
                line=quant_token.line,
                column=quant_token.column,
            )

        # Parse separator |
        if not self._match(TokenType.PIPE):
            raise ParserError("Expected '|' after quantifier binding", self._current())
        self._advance()  # Consume '|'

        # Detect line continuation (backslash or natural newline)
        has_continuation = False
        if self._match(TokenType.CONTINUATION):
            self._advance()  # consume \
            has_continuation = True
            # Skip newline and any leading whitespace on next line
            if self._match(TokenType.NEWLINE):
                self._advance()
            self._skip_newlines()
        elif self._match(TokenType.NEWLINE):
            # Natural line break without \ marker (WYSIWYG)
            has_continuation = True
            self._skip_newlines()
        else:
            # Allow newlines after | for multi-line quantifiers
            self._skip_newlines()

        # Set flag: we're in quantifier body where . can be separator (for mu)
        # Also record all declared variables so _parse_postfix can distinguish
        # bullet `.` from field projection (Z RM §3.16: declared variables are
        # not field selectors of sibling bindings in the same schema-text).
        prev_quantifier_vars = self._current_quantifier_vars
        self._current_quantifier_vars = set(variables)
        self._in_comprehension_body = True
        try:
            # Parse body (may be followed by constraint pipe)
            body = self._parse_expr()

            # Check for second pipe (constrained quantifier)
            # forall x : T | constraint | body → constraint => body
            if self._match(TokenType.PIPE):
                self._advance()  # Consume second '|'

                # Check for continuation marker after second pipe
                constraint_continuation = False
                if self._match(TokenType.CONTINUATION):
                    self._advance()  # consume \
                    constraint_continuation = True
                    # Skip newline and any leading whitespace on next line
                    if self._match(TokenType.NEWLINE):
                        self._advance()
                    self._skip_newlines()

                constraint = body
                actual_body = self._parse_expr()
                # Combine constraint and body with IMPLIES (filter semantics)
                body = BinaryOp(
                    operator="implies",
                    left=constraint,
                    right=actual_body,
                    line_break_after=constraint_continuation,
                    line=constraint.line,
                    column=constraint.column,
                )

            # Check for bullet separator (Q x : T | pred . expr)
            expression: Expr | None = None
            bullet_continuation = False
            if self._match(TokenType.PERIOD):
                self._advance()  # Consume '.'

                # Handle continuation marker or newline after bullet separator
                if self._match(TokenType.CONTINUATION):
                    self._advance()  # consume \
                    bullet_continuation = True
                    # Skip newline and any leading whitespace on next line
                    if self._match(TokenType.NEWLINE):
                        self._advance()
                    self._skip_newlines()
                elif self._match(TokenType.NEWLINE):
                    # Allow bare newline after bullet (no backslash needed) - WYSIWYG
                    bullet_continuation = True
                    self._advance()
                    self._skip_newlines()

                # Expression after bullet is not part of comprehension body
                self._in_comprehension_body = False
                expression = self._parse_iff()  # Parse the expression part
        finally:
            self._in_comprehension_body = False
            self._current_quantifier_vars = prev_quantifier_vars

        return Quantifier(
            quantifier=quant_token.value,
            variables=variables,
            domain=domain,
            body=body,
            expression=expression,
            line_break_after_pipe=has_continuation,
            line_break_after_bullet=bullet_continuation,
            tuple_pattern=tuple_pattern,
            line=quant_token.line,
            column=quant_token.column,
        )

    def _parse_schema_quantifier_body(
        self,
        quant_token: Token,
        schema_binding: SchemaBinding,
    ) -> Quantifier:
        """Parse the ``| body`` tail of a schema-text quantifier (Z RM §3.10).

        Called after the schema binding (Delta S / Xi S / S / S') has been
        consumed.  Expects ``|`` followed by the predicate body.

        The body is the predicate after the spot character; fuzz expands the
        schema invariant, so the engine emits the binding literally.
        """
        # Expect | separator
        if not self._match(TokenType.PIPE):
            raise ParserError(
                "Expected '|' after schema binding in quantifier",
                self._current(),
            )
        self._advance()  # Consume |

        # Detect line continuation after |
        has_continuation = False
        if self._match(TokenType.CONTINUATION):
            self._advance()
            has_continuation = True
            if self._match(TokenType.NEWLINE):
                self._advance()
            self._skip_newlines()
        elif self._match(TokenType.NEWLINE):
            has_continuation = True
            self._skip_newlines()
        else:
            self._skip_newlines()

        self._in_comprehension_body = True
        try:
            body = self._parse_expr()
        finally:
            self._in_comprehension_body = False

        return Quantifier(
            quantifier=quant_token.value,
            variables=[],
            domain=None,
            body=body,
            expression=None,
            line_break_after_pipe=has_continuation,
            line_break_after_bullet=False,
            tuple_pattern=None,
            schema_binding=schema_binding,
            line=quant_token.line,
            column=quant_token.column,
        )

    def _parse_quantifier_continuation(
        self,
        quantifier: str,
        line: int,
        column: int,
        inherited_vars: set[str] | None = None,
    ) -> Expr:
        """Parse continuation of semicolon-separated quantifier bindings.

        Helper for parsing y : U | body or y : U; z : V | body
        after we've already parsed x : T;

        inherited_vars accumulates all variables declared in earlier bindings of
        the same schema-text chain so that _parse_postfix can see the full set
        when disambiguating bullet `.` from field projection (Z RM §3.16).
        """
        prior_vars: set[str] = inherited_vars if inherited_vars is not None else set()

        # After ';' the caller may have placed a natural newline or an explicit
        # `\` continuation before the next binding.  Mirror the post-`|` handling
        # (lines 2810-2820) so that `;`-chained quantifier prefixes may span
        # source lines (Z RM authoring convenience).
        if self._match(TokenType.CONTINUATION):
            self._advance()
            if self._match(TokenType.NEWLINE):
                self._advance()
            self._skip_newlines()
        elif self._match(TokenType.NEWLINE):
            self._skip_newlines()

        # Parse variable(s)
        if not self._match(TokenType.IDENTIFIER):
            raise ParserError(
                "Expected variable name after ';' in quantifier", self._current()
            )
        variables: list[str] = [self._advance().value]

        # Parse additional comma-separated variables
        while self._match(TokenType.COMMA):
            self._advance()  # Consume ','
            if not self._match(TokenType.IDENTIFIER):
                raise ParserError("Expected variable name after ','", self._current())
            variables.append(self._advance().value)

        # Parse domain
        domain: Expr | None = None
        if self._match(TokenType.COLON):
            self._advance()  # Consume ':'
            # Parse type expression to match main quantifier parser.
            # Mirror _parse_quantifier (parser.py:2305-2309): set the flag so
            # compound domain types like X -> Y stop at PIPE/PERIOD correctly.
            self._parsing_schema_text = True
            try:
                domain = self._parse_function_type()
            finally:
                self._parsing_schema_text = False

        # Check for another semicolon (more bindings)
        if self._match(TokenType.SEMICOLON):
            self._advance()  # Consume ';'
            nested_quant = self._parse_quantifier_continuation(
                quantifier,
                self._current().line,
                self._current().column,
                inherited_vars=prior_vars | set(variables),
            )
            return Quantifier(
                quantifier=quantifier,
                variables=variables,
                domain=domain,
                body=nested_quant,
                expression=None,
                tuple_pattern=None,  # No tuple pattern in continuation
                line=line,
                column=column,
            )

        # Otherwise expect pipe
        if not self._match(TokenType.PIPE):
            raise ParserError("Expected '|' after quantifier binding", self._current())
        self._advance()  # Consume '|'

        # Detect line continuation (backslash or natural newline).
        # Mirrors the logic in _parse_quantifier so that semicolon-chained
        # quantifier bindings (forall x : T; y : U; z : V | body) honour an
        # explicit `\` continuation and bare WYSIWYG newlines after `|`.
        has_continuation = False
        if self._match(TokenType.CONTINUATION):
            self._advance()  # consume \
            has_continuation = True
            if self._match(TokenType.NEWLINE):
                self._advance()
            self._skip_newlines()
        elif self._match(TokenType.NEWLINE):
            has_continuation = True
            self._skip_newlines()
        else:
            self._skip_newlines()

        # Set flag: we're in quantifier body where . can be separator (for mu)
        # Expose the full declared-variable set (this level + all inherited levels)
        # so _parse_postfix can apply the Z RM §3.16 bullet disambiguation rule.
        prev_quantifier_vars = self._current_quantifier_vars
        self._current_quantifier_vars = prior_vars | set(variables)
        self._in_comprehension_body = True
        try:
            # Parse body (constraint part if bullet separator follows)
            body = self._parse_iff()

            # Check for bullet separator (Q x : T | pred . expr)
            expression: Expr | None = None
            bullet_continuation = False
            if self._match(TokenType.PERIOD):
                self._advance()  # Consume '.'

                # Handle continuation marker or newline after bullet separator
                if self._match(TokenType.CONTINUATION):
                    self._advance()  # consume \
                    bullet_continuation = True
                    # Skip newline and any leading whitespace on next line
                    if self._match(TokenType.NEWLINE):
                        self._advance()
                    self._skip_newlines()
                elif self._match(TokenType.NEWLINE):
                    # Allow bare newline after bullet (no backslash needed) - WYSIWYG
                    bullet_continuation = True
                    self._advance()
                    self._skip_newlines()

                # Expression after bullet is not part of comprehension body
                self._in_comprehension_body = False
                expression = self._parse_iff()
        finally:
            self._in_comprehension_body = False
            self._current_quantifier_vars = prev_quantifier_vars

        return Quantifier(
            quantifier=quantifier,
            variables=variables,
            domain=domain,
            body=body,
            expression=expression,
            line_break_after_pipe=has_continuation,
            line_break_after_bullet=bullet_continuation,
            tuple_pattern=None,  # No tuple pattern in continuation
            line=line,
            column=column,
        )

    def _parse_lambda(self) -> Expr:
        """Parse lambda expression: lambda var [, var]* : domain . body.

        Examples:
        - lambda x : N . x^2
        - lambda x, y : N . x and y
        - lambda f : X -> Y . lambda x : X . f(x)
        """
        lambda_token = self._advance()  # Consume 'lambda'

        # Parse first variable
        if not self._match(TokenType.IDENTIFIER):
            raise ParserError("Expected variable name after lambda", self._current())
        variables: list[str] = [self._advance().value]

        # Parse additional variables if comma-separated
        while self._match(TokenType.COMMA):
            self._advance()  # Consume ','
            if not self._match(TokenType.IDENTIFIER):
                raise ParserError("Expected variable name after ','", self._current())
            variables.append(self._advance().value)

        # Parse domain (: domain) - required for lambda
        if not self._match(TokenType.COLON):
            raise ParserError("Expected ':' after lambda variables", self._current())
        self._advance()  # Consume ':'
        # Parse domain as full type expression (can be complex like X -> Y)
        # Use _parse_comparison() to get function types but stop at PERIOD
        # Set flag to prevent .identifier from being parsed as projection
        self._parsing_schema_text = True
        try:
            domain = self._parse_comparison()
        finally:
            self._parsing_schema_text = False

        # Multi-decl form: lambda s : Ship; c : Class | P . E
        # Delegate to _parse_quantifier_continuation (same path as forall/exists/mu),
        # which handles PIPE + optional bullet, producing nested Quantifier nodes.
        if self._match(TokenType.SEMICOLON):
            self._advance()  # Consume ';'
            nested_quant = self._parse_quantifier_continuation(
                "lambda",
                self._current().line,
                self._current().column,
                inherited_vars=set(variables),
            )
            return Quantifier(
                quantifier="lambda",
                variables=variables,
                domain=domain,
                body=nested_quant,
                expression=None,
                tuple_pattern=None,
                line=lambda_token.line,
                column=lambda_token.column,
            )

        # Single-decl form with predicate pipe: lambda s : Ship | P . E
        # Produces Quantifier(quantifier="lambda") consistent with multi-decl path.
        if self._match(TokenType.PIPE):
            self._advance()  # Consume '|'
            self._skip_newlines()
            prev_quantifier_vars = self._current_quantifier_vars
            self._current_quantifier_vars = set(variables)
            self._in_comprehension_body = True
            try:
                body = self._parse_iff()
                expression: Expr | None = None
                if self._match(TokenType.PERIOD):
                    self._advance()  # Consume '.'
                    self._in_comprehension_body = False
                    expression = self._parse_iff()
            finally:
                self._in_comprehension_body = False
                self._current_quantifier_vars = prev_quantifier_vars
            return Quantifier(
                quantifier="lambda",
                variables=variables,
                domain=domain,
                body=body,
                expression=expression,
                tuple_pattern=None,
                line=lambda_token.line,
                column=lambda_token.column,
            )

        # Original PERIOD-only path: lambda x : T . body  (no pipe, no semicolon)
        # Produces a Lambda node — single-decl abstraction.
        if not self._match(TokenType.PERIOD):
            raise ParserError("Expected '.' after lambda binding", self._current())
        self._advance()  # Consume '.'

        # Parse body (rest of expression) - use _parse_expr() to allow nested
        # quantifiers and lambdas in the body
        # Lambda binds tighter than quantifiers, so "lambda x : X . forall y : Y | P"
        # means the body is the entire quantifier expression
        body = self._parse_expr()

        return Lambda(
            variables=variables,
            domain=domain,
            body=body,
            line=lambda_token.line,
            column=lambda_token.column,
        )

    def _parse_binding(self) -> Binding:
        r"""Parse a Z binding literal: {| name == expr, ... |} (Z RM §3.7).

        Consumes LBIND, then a comma-separated list of ``IDENTIFIER == expr``
        pairs, then RBIND.  Empty bindings ``{| |}`` are accepted (Z RM §3.7
        permits them).

        The ``==`` inside binding context reuses the ABBREV token; the parser
        disambiguates by position — we are inside ``{| ... |}``, not at
        top-level abbreviation position.

        Raises:
            ParserError: Missing ``==``, missing label, missing value, missing
                closing ``|}``, or semicolon used between components.
        """
        start_token = self._current()
        self._advance()  # consume {|

        pairs: list[tuple[str, Expr]] = []

        # Empty binding: {| |}
        if self._match(TokenType.RBIND):
            self._advance()  # consume |}
            return Binding(pairs=[], line=start_token.line, column=start_token.column)

        # Parse first component
        pairs.append(self._parse_binding_component())

        # Parse remaining components
        while self._match(TokenType.COMMA):
            self._advance()  # consume ,
            # Skip any newlines between components
            self._skip_newlines()
            pairs.append(self._parse_binding_component())

        # Closing |}
        if not self._match(TokenType.RBIND):
            cur = self._current()
            if cur.type == TokenType.SEMICOLON:
                raise ParserError(
                    "binding components are comma-separated, not semicolons;"
                    " use ',' between components",
                    cur,
                )
            if cur.type == TokenType.EOF:
                raise ParserError(
                    "unclosed binding: expected '|}' to close '{|'",
                    cur,
                )
            raise ParserError(
                f"expected ',' or '|}}' in binding, got {cur.type.name}",
                cur,
            )
        self._advance()  # consume |}

        return Binding(pairs=pairs, line=start_token.line, column=start_token.column)

    def _parse_binding_component(self) -> tuple[str, Expr]:
        """Parse a single binding component: IDENTIFIER == expr.

        Raises:
            ParserError: If label is missing, ``==`` is missing, or value is
                missing.
        """
        # Expect an identifier as the label
        if not self._match(TokenType.IDENTIFIER):
            cur = self._current()
            if cur.type == TokenType.ABBREV:
                raise ParserError(
                    "binding component requires a label before '==';"
                    " got '==' with no label",
                    cur,
                )
            if cur.type in (TokenType.RBIND, TokenType.EOF):
                raise ParserError(
                    "expected binding label (identifier) before '=='",
                    cur,
                )
            raise ParserError(
                f"expected identifier as binding label, got {cur.type.name}",
                cur,
            )
        label_token = self._advance()  # consume identifier

        # Expect ==
        if not self._match(TokenType.ABBREV):
            cur = self._current()
            raise ParserError(
                f"expected '==' after binding label {label_token.value!r},"
                f" got {cur.type.name}",
                cur,
            )
        self._advance()  # consume ==

        # Parse value expression — stop before , or |}
        # Use _parse_expr to allow full expressions as values
        if self._match(TokenType.COMMA, TokenType.RBIND, TokenType.EOF):
            cur = self._current()
            raise ParserError(
                f"expected expression after '==' in binding component"
                f" {label_token.value!r}",
                cur,
            )
        value = self._parse_expr()

        return (label_token.value, value)

    def _parse_set(self) -> Expr:
        """Parse set literal or set comprehension.

        Distinguishes between:
            - Set literal: {1, 2, 3} or {a, b} - comma-separated elements
            - Set comprehension: {x : X | pred} - has : and |

        Strategy: Look ahead for : or | to determine type.
        Multi-variable comprehensions like {x, y : N | ...} need special handling.
        """
        start_token = self._current()  # Save position before '{'
        self._advance()  # Consume '{'

        # Empty set: {}
        if self._match(TokenType.RBRACE):
            self._advance()  # Consume '}'
            return SetLiteral(
                elements=[], line=start_token.line, column=start_token.column
            )

        # Look ahead to distinguish literal from comprehension
        # Strategy: Parse potential identifiers, check for : to determine type
        saved_pos = self.pos
        first_elem = self._parse_expr()

        # Case 1: Immediate colon -> single-variable comprehension
        if self._match(TokenType.COLON):
            self.pos = saved_pos
            return self._parse_set_comprehension_from_brace()

        # Case 2: Immediate pipe + identifier -> comprehension without domain
        if self._match(TokenType.PIPE):
            if isinstance(first_elem, Identifier):
                self.pos = saved_pos
                return self._parse_set_comprehension_from_brace()
            raise ParserError(
                "Unexpected '|' in set literal",
                self._current(),
            )

        # Case 3: Comma - need to look ahead further
        # Could be {x, y : N | ...} or {1, 2, 3}
        if self._match(TokenType.COMMA):
            # Collect all comma-separated items
            items: list[Expr] = [first_elem]
            while self._match(TokenType.COMMA):
                self._advance()  # Consume ','
                if self._match(TokenType.RBRACE):
                    # Trailing comma: {1, 2,}
                    break
                items.append(self._parse_expr())

            # Check what follows the comma-separated items
            if self._match(TokenType.COLON):
                # Multi-variable comprehension: {x, y : N | ...}
                # All items must be identifiers
                if not all(isinstance(item, Identifier) for item in items):
                    raise ParserError(
                        "Set comprehension variables must be identifiers",
                        self._current(),
                    )
                # Backtrack and parse as comprehension
                self.pos = saved_pos
                return self._parse_set_comprehension_from_brace()

            # It's a literal: {1, 2, 3} or {a, b, c}
            if not self._match(TokenType.RBRACE):
                raise ParserError("Expected '}' to close set literal", self._current())
            self._advance()  # Consume '}'
            return SetLiteral(
                elements=items, line=start_token.line, column=start_token.column
            )

        # Case 4: Single element followed by closing brace
        if self._match(TokenType.RBRACE):
            self._advance()  # Consume '}'
            return SetLiteral(
                elements=[first_elem],
                line=start_token.line,
                column=start_token.column,
            )

        # Unexpected token
        raise ParserError(
            "Expected ',', ':', '|', or '}' in set expression", self._current()
        )

    def _parse_set_comprehension_from_brace(self) -> Expr:
        """Parse set comprehension after '{' already consumed.

        Helper for _parse_set().
        """
        # Parse first variable
        if not self._match(TokenType.IDENTIFIER):
            raise ParserError(
                "Expected variable name in set comprehension", self._current()
            )
        variables: list[str] = [self._advance().value]

        # Parse additional variables if comma-separated
        while self._match(TokenType.COMMA):
            self._advance()  # Consume ','
            if not self._match(TokenType.IDENTIFIER):
                raise ParserError("Expected variable name after ','", self._current())
            variables.append(self._advance().value)

        # Parse optional domain (: domain)
        domain: Expr | None = None
        if self._match(TokenType.COLON):
            self._advance()  # Consume ':'
            # Parse type expression: union, cross, function & relation types
            # Allows: forall x : A union B | P
            # Allows: forall f : X -> Y | P (function type)
            # Allows: forall R : X <-> Y | P (relation type)
            # Set flag to prevent .identifier from being parsed as projection
            self._parsing_schema_text = True
            try:
                domain = self._parse_function_type()
            finally:
                self._parsing_schema_text = False

        # Parse optional extra declarations: ; var : Type ; var : Type ...
        # Handles multi-typed set comprehensions like { s : Ship; c : Class | ... }
        extra_declarations: list[tuple[str, Expr]] | None = None
        while self._match(TokenType.SEMICOLON):
            self._advance()  # Consume ';'
            # After ';' the caller may have placed a natural newline or an explicit
            # `\` continuation before the next binding.  Mirror the post-`|` handling
            # so that `;`-chained set-comprehension prefixes may span source lines.
            if self._match(TokenType.CONTINUATION):
                self._advance()
                if self._match(TokenType.NEWLINE):
                    self._advance()
                self._skip_newlines()
            elif self._match(TokenType.NEWLINE):
                self._skip_newlines()
            if not self._match(TokenType.IDENTIFIER):
                raise ParserError(
                    "Expected variable name after ';' in set comprehension",
                    self._current(),
                )
            extra_var = self._advance().value
            extra_domain: Expr | None = None
            if self._match(TokenType.COLON):
                self._advance()  # Consume ':'
                self._parsing_schema_text = True
                try:
                    extra_domain = self._parse_function_type()
                finally:
                    self._parsing_schema_text = False
            if extra_domain is None:
                raise ParserError(
                    f"Expected ':' and type after '{extra_var}' in set comprehension",
                    self._current(),
                )
            if extra_declarations is None:
                extra_declarations = []
            extra_declarations.append((extra_var, extra_domain))

        # Parse separator | or . for set comprehension
        # Syntax: {x : T | predicate . expr} or {x : T . expr} (no predicate)
        predicate: Expr | None
        expression: Expr | None

        if self._match(TokenType.PERIOD):
            # Period separator: no predicate, directly to expression
            self._advance()  # Consume '.'
            predicate = None
            expression = self._parse_set_expression()
        elif self._match(TokenType.PIPE):
            # Pipe separator: parse predicate, optionally followed by . expr
            self._advance()  # Consume '|'
            # After '|' the caller may have placed a natural newline or an explicit
            # `\` continuation before the predicate.  Mirror the quantifier post-`|`
            # handling so that long comprehensions may span source lines.
            if self._match(TokenType.CONTINUATION):
                self._advance()
                if self._match(TokenType.NEWLINE):
                    self._advance()
                self._skip_newlines()
            elif self._match(TokenType.NEWLINE):
                self._skip_newlines()
            # Set flag: we're in comprehension body where . can be separator.
            # Expose all declared variables (primary + extra) for bullet
            # disambiguation in _parse_postfix (Z RM §3.16).
            all_comp_vars: set[str] = set(variables)
            if extra_declarations is not None:
                for ev, _ in extra_declarations:
                    all_comp_vars.add(ev)
            prev_quantifier_vars = self._current_quantifier_vars
            self._current_quantifier_vars = all_comp_vars
            self._in_comprehension_body = True
            try:
                predicate = self._parse_set_predicate()

                # Parse optional expression part (. expression)
                expression = None
                if self._match(TokenType.PERIOD):
                    self._advance()  # Consume '.'
                    # Parse expression (up to })
                    expression = self._parse_set_expression()
            finally:
                self._in_comprehension_body = False
                self._current_quantifier_vars = prev_quantifier_vars
        elif self._match(TokenType.RBRACE):
            # No separator: both predicate and expression are omitted
            # {x : T} means "all x of type T", equivalent to just T
            predicate = None
            expression = None
        else:
            raise ParserError(
                "Expected '|', '.', or '}' after set comprehension binding",
                self._current(),
            )

        # Expect closing brace (skip newlines for multi-line comprehensions)
        self._skip_newlines()
        if not self._match(TokenType.RBRACE):
            raise ParserError(
                "Expected '}' to close set comprehension", self._current()
            )
        self._advance()  # Consume '}'

        # Use saved start position from _parse_set
        start_token = self.tokens[self.pos - len(variables) - 5]  # Approximate
        return SetComprehension(
            variables=variables,
            domain=domain,
            predicate=predicate,
            expression=expression,
            extra_declarations=extra_declarations,
            line=start_token.line,
            column=start_token.column,
        )

    def _parse_set_predicate(self) -> Expr:
        """Parse predicate in set comprehension (up to . or })."""
        # Parse expression, but stop at PERIOD or RBRACE
        # This is tricky because we need to parse a full expression
        # but stop before . or }
        # For now, use the standard expression parser but be aware of context
        return self._parse_iff()

    def _parse_set_expression(self) -> Expr:
        """Parse expression in set comprehension (after . and up to }).

        Newlines between the bullet separator and the expression are skipped
        to support multi-line comprehensions like:
            { s : Ship | pred .
              {| name == s.name |}
            }
        """
        # Skip newlines before expression (multi-line comprehension support)
        self._skip_newlines()
        return self._parse_iff()

    def _parse_comparison(self) -> Expr:
        """Parse comparison operators (<, >, <=, >=, =, !=).

        Allows newlines before and after comparison operators.
        Supports guarded cases after = operator (pattern matching).
        Supports line continuation with \\ after = operator.
        """
        left = self._parse_function_type()

        # Peek ahead to see if there's a comparison operator
        # We need to skip newlines to check, but restore position if no operator
        saved_pos = self.pos
        self._skip_newlines()

        if self._match(
            TokenType.LESS_THAN,
            TokenType.GREATER_THAN,
            TokenType.LESS_EQUAL,
            TokenType.GREATER_EQUAL,
            TokenType.EQUALS,
            TokenType.NOT_EQUAL,
            TokenType.SHOWS,
        ):
            # Found comparison operator, consume it
            op_token = self._advance()

            # Detect line continuation (backslash after operator)
            has_continuation = False
            if self._match(TokenType.CONTINUATION):
                self._advance()  # consume \
                has_continuation = True
                # Skip newline and any leading whitespace on next line
                if self._match(TokenType.NEWLINE):
                    self._advance()
                self._skip_newlines()
            else:
                # Allow newlines after comparison operator
                self._skip_newlines()

            prev_in_comparison_rhs = self._in_comparison_rhs
            self._in_comparison_rhs = True
            try:
                right = self._parse_function_type()
            finally:
                self._in_comparison_rhs = prev_in_comparison_rhs

            # Check for guarded cases after = operator (pattern matching)
            # Syntax: expr1 = expr2 \n if cond2 \n expr3 \n if cond3 ...
            if op_token.type == TokenType.EQUALS:
                right = self._try_parse_guarded_cases(right)

            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line_break_after=has_continuation,
                line=op_token.line,
                column=op_token.column,
            )
        else:
            # No comparison operator, restore position to not consume newlines
            self.pos = saved_pos

        return left

    def _try_parse_guarded_cases(self, first_expr: Expr) -> Expr:
        """Try to parse guarded cases for pattern matching.

        Checks if the current position is followed by:
          NEWLINE IF condition NEWLINE expr IF condition ...

        If so, parses all guarded branches and returns GuardedCases.
        Otherwise, returns the original expression unchanged.

        Args:
            first_expr: The first expression (already parsed)

        Returns:
            GuardedCases if guards found, otherwise first_expr unchanged
        """
        # Check if next is NEWLINE + IF (but not IF ... THEN)
        if not self._match(TokenType.NEWLINE):
            return first_expr

        # Save position in case we need to backtrack
        saved_pos = self.pos

        # Skip the newline
        self._advance()

        # Check if next token is IF
        if not self._match(TokenType.IF):
            # Not a guarded case, restore position and return
            self.pos = saved_pos
            return first_expr

        # It's a guarded case! Parse first branch
        self._advance()  # Consume IF
        first_guard = self._parse_expr()

        branches: list[GuardedBranch] = [
            GuardedBranch(
                expression=first_expr,
                guard=first_guard,
                line=first_expr.line,
                column=first_expr.column,
            )
        ]

        # Parse remaining branches: NEWLINE expr NEWLINE IF guard
        while True:
            # Expect NEWLINE + expr
            if not self._match(TokenType.NEWLINE):
                break
            self._advance()  # Consume NEWLINE

            # Check if we're at the end or a structural element
            if self._at_end() or self._match(TokenType.END, TokenType.WHERE):
                # Restore the newline for parent parser
                self.pos -= 1
                break

            # Parse branch expression
            branch_expr = self._parse_function_type()

            # Expect NEWLINE + IF
            if not self._match(TokenType.NEWLINE):
                # No more branches, this expression is something else
                # This shouldn't happen in well-formed input
                raise ParserError(
                    "Expected newline after guarded branch expression", self._current()
                )
            self._advance()  # Consume NEWLINE

            if not self._match(TokenType.IF):
                # No IF, so we're done with guarded cases
                # Restore position to before the expression
                raise ParserError(
                    "Expected 'if' guard after expression in guarded cases",
                    self._current(),
                )

            self._advance()  # Consume IF
            branch_guard = self._parse_expr()

            branches.append(
                GuardedBranch(
                    expression=branch_expr,
                    guard=branch_guard,
                    line=branch_expr.line,
                    column=branch_expr.column,
                )
            )

        return GuardedCases(
            branches=branches, line=first_expr.line, column=first_expr.column
        )

    def _parse_function_type(self) -> Expr:
        """Parse function and relation type operators.

        Function/relation types: ->, +->, >->, >+>, -|>, -->>, +->>, >->>, <->
        Right-associative: A -> B -> C parses as A -> (B -> C)
        Also used in quantifier domains: forall f : X -> Y | P
        """
        left = self._parse_relation()

        # Check for function/relation type operators (right-associative)
        if self._match(
            TokenType.TFUN,  # ->
            TokenType.PFUN,  # +->
            TokenType.TINJ,  # >->
            TokenType.PINJ,  # >+>
            TokenType.PINJ_ALT,  # -|>
            TokenType.TSURJ,  # -->>
            TokenType.PSURJ,  # +->>
            TokenType.BIJECTION,  # >->>
            TokenType.FINFUN,  # 77-> (finite partial function)
            TokenType.RELATION,  # <-> (relation type)
        ):
            arrow_token = self._advance()
            # Right-associative: recursively parse the right side as function type
            right = self._parse_function_type()
            return FunctionType(
                arrow=arrow_token.value,
                domain=left,
                range=right,
                line=arrow_token.line,
                column=arrow_token.column,
            )

        return left

    def _parse_relation(self) -> Expr:
        """Parse relation operators.

        Infix: <->, |->, <|, |>, <<|, |>>, o9/comp
        """
        left = self._parse_set_op()

        # Infix relation operators (left-associative)
        # Note: SEMICOLON is NOT included here - it's used for declaration separators
        # Use 'o9' for relational composition instead
        while self._match(
            TokenType.RELATION,  # <->
            TokenType.MAPLET,  # |->
            TokenType.DRES,  # <| (domain restriction)
            TokenType.RRES,  # |> (range restriction)
            TokenType.NDRES,  # <<| (domain subtraction)
            TokenType.NRRES,  # |>> (range subtraction)
            TokenType.CIRC,  # o9 (relational composition)
            TokenType.COMP,  # comp
        ):
            op_token = self._advance()
            right = self._parse_set_op()
            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _parse_set_op(self) -> Expr:
        """Parse set operators (in, notin, subset, psubset)."""
        left = self._parse_union()

        if self._match(
            TokenType.IN, TokenType.NOTIN, TokenType.SUBSET, TokenType.PSUBSET
        ):
            op_token = self._advance()
            right = self._parse_union()
            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _parse_union(self) -> Expr:
        """Parse union and override operators.

        Union: union operator (set union)
        Override: ++ (function/sequence override)
        Both have similar precedence in Z notation.

        Supports multi-line expressions with natural line breaks.
        """
        left = self._parse_cross()

        while self._match(TokenType.UNION, TokenType.OVERRIDE):
            op_token = self._advance()
            # Detect line continuation (backslash or natural newline)
            has_continuation = False
            if self._match(TokenType.CONTINUATION):
                self._advance()  # consume \
                has_continuation = True
                if self._match(TokenType.NEWLINE):
                    self._advance()
                self._skip_newlines()
            elif self._match(TokenType.NEWLINE):
                has_continuation = True
                self._skip_newlines()
            else:
                self._skip_newlines()
            right = self._parse_cross()
            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line_break_after=has_continuation,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _parse_cross(self) -> Expr:
        """Parse Cartesian product, natural join, theta-join, division, GROUP, UNGROUP.

        CROSS, JOIN, DIV, GROUP, and UNGROUP sit at the same precedence
        level between set operators and arithmetic (Phase 2.2 / 4.1).
        JOIN handles an optional subscript bracket: R join [p] S.
        GROUP and UNGROUP are Date's nested-relation operators.

        Supports multi-line expressions with natural line breaks.
        """
        left = self._parse_intersect()

        while self._match(
            TokenType.CROSS,
            TokenType.JOIN,
            TokenType.DIV,
            TokenType.GROUP,
            TokenType.UNGROUP,
        ):
            op_token = self._advance()

            if op_token.type == TokenType.JOIN:
                # Check for theta-join subscript: join [predicate]
                subscript: Expr | None = None
                if self._match(TokenType.LBRACKET):
                    bracket_tok = self._advance()  # consume '['
                    if self._match(TokenType.RBRACKET):
                        raise ParserError(
                            "Expected predicate in join subscript", self._current()
                        )
                    subscript = self._parse_expr()
                    if not self._match(TokenType.RBRACKET):
                        raise ParserError(
                            "Expected ']' after join predicate", bracket_tok
                        )
                    self._advance()  # consume ']'
                # Detect line continuation after optional subscript
                has_continuation = False
                if self._match(TokenType.CONTINUATION):
                    self._advance()  # consume \
                    has_continuation = True
                    if self._match(TokenType.NEWLINE):
                        self._advance()
                    self._skip_newlines()
                elif self._match(TokenType.NEWLINE):
                    has_continuation = True
                    self._skip_newlines()
                else:
                    self._skip_newlines()
                prev_relational = self._in_relational_context
                self._in_relational_context = True
                try:
                    right = self._parse_intersect()
                finally:
                    self._in_relational_context = prev_relational
                left = NaturalJoin(
                    left=left,
                    right=right,
                    subscript=subscript,
                    line_break_after=has_continuation,
                    line=op_token.line,
                    column=op_token.column,
                )
            elif op_token.type == TokenType.DIV:
                # Detect line continuation
                has_continuation = False
                if self._match(TokenType.CONTINUATION):
                    self._advance()  # consume \
                    has_continuation = True
                    if self._match(TokenType.NEWLINE):
                        self._advance()
                    self._skip_newlines()
                elif self._match(TokenType.NEWLINE):
                    has_continuation = True
                    self._skip_newlines()
                else:
                    self._skip_newlines()
                prev_relational = self._in_relational_context
                self._in_relational_context = True
                try:
                    right = self._parse_intersect()
                finally:
                    self._in_relational_context = prev_relational
                left = Divide(
                    left=left,
                    right=right,
                    line_break_after=has_continuation,
                    line=op_token.line,
                    column=op_token.column,
                )
            elif op_token.type == TokenType.GROUP:
                group_node = self._parse_group_rhs(left, op_token)
                # Detect line continuation after full GROUP expression
                has_continuation = False
                if self._match(TokenType.CONTINUATION):
                    self._advance()  # consume \
                    has_continuation = True
                    if self._match(TokenType.NEWLINE):
                        self._advance()
                    self._skip_newlines()
                elif self._match(TokenType.NEWLINE):
                    has_continuation = True
                    self._skip_newlines()
                else:
                    self._skip_newlines()
                if has_continuation:
                    # Replace the frozen node with line_break_after=True
                    if isinstance(group_node, GroupAggregate):
                        left = GroupAggregate(
                            relation=group_node.relation,
                            clauses=group_node.clauses,
                            line_break_after=True,
                            line=group_node.line,
                            column=group_node.column,
                        )
                    else:
                        left = Group(
                            relation=group_node.relation,
                            attrs=group_node.attrs,
                            alias=group_node.alias,
                            line_break_after=True,
                            line=group_node.line,
                            column=group_node.column,
                        )
                else:
                    left = group_node
            elif op_token.type == TokenType.UNGROUP:
                ungroup_node = self._parse_ungroup_rhs(left, op_token)
                # Detect line continuation after full UNGROUP expression
                has_continuation = False
                if self._match(TokenType.CONTINUATION):
                    self._advance()  # consume \
                    has_continuation = True
                    if self._match(TokenType.NEWLINE):
                        self._advance()
                    self._skip_newlines()
                elif self._match(TokenType.NEWLINE):
                    has_continuation = True
                    self._skip_newlines()
                else:
                    self._skip_newlines()
                if has_continuation:
                    # Replace the frozen Ungroup node with line_break_after=True
                    left = Ungroup(
                        relation=ungroup_node.relation,
                        alias=ungroup_node.alias,
                        line_break_after=True,
                        line=ungroup_node.line,
                        column=ungroup_node.column,
                    )
                else:
                    left = ungroup_node
            else:
                # CROSS
                has_continuation = False
                if self._match(TokenType.CONTINUATION):
                    self._advance()  # consume \
                    has_continuation = True
                    if self._match(TokenType.NEWLINE):
                        self._advance()
                    self._skip_newlines()
                elif self._match(TokenType.NEWLINE):
                    has_continuation = True
                    self._skip_newlines()
                else:
                    self._skip_newlines()
                right = self._parse_intersect()
                left = BinaryOp(
                    operator=op_token.value,
                    left=left,
                    right=right,
                    line_break_after=has_continuation,
                    line=op_token.line,
                    column=op_token.column,
                )

            # After constructing the node, check for trailing continuation
            # that marks a break before the next operator in the chain.
            # Example: R join S \    ← \ after RHS, before next join
            #            join T
            # The just-constructed node gets line_break_after=True so the
            # caller knows to emit \\ before the next operator.
            if self._match(TokenType.CONTINUATION):
                self._advance()  # consume \
                if self._match(TokenType.NEWLINE):
                    self._advance()
                self._skip_newlines()
                left = dataclasses.replace(left, line_break_after=True)
            elif (
                self._match(TokenType.NEWLINE) and self._next_non_newline_is_cross_op()
            ):
                # Natural line break before another cross-level operator
                self._skip_newlines()
                left = dataclasses.replace(left, line_break_after=True)

        return left

    def _next_non_newline_is_cross_op(self) -> bool:
        """Peek ahead past newlines to see if a cross-level operator follows.

        Returns True when the next non-newline token is one of CROSS, JOIN,
        DIV, GROUP, or UNGROUP, indicating a natural line break in a chain.
        """
        pos = self.pos
        while pos < len(self.tokens) and self.tokens[pos].type == TokenType.NEWLINE:
            pos += 1
        if pos >= len(self.tokens):
            return False
        return self.tokens[pos].type in (
            TokenType.CROSS,
            TokenType.JOIN,
            TokenType.DIV,
            TokenType.GROUP,
            TokenType.UNGROUP,
        )

    # Token types that start an aggregator clause.
    _AGGREGATOR_TOKEN_TYPES: ClassVar[frozenset[TokenType]] = frozenset(
        {
            TokenType.COUNT,
            TokenType.SUM,
            TokenType.AVG,
            TokenType.MIN,
            TokenType.MAX,
            TokenType.MEDIAN,
        }
    )

    # Mapping from aggregator token type to Aggregator enum value.
    _TOKEN_TO_AGGREGATOR: ClassVar[dict[TokenType, Aggregator]] = {
        TokenType.COUNT: Aggregator.COUNT,
        TokenType.SUM: Aggregator.SUM,
        TokenType.AVG: Aggregator.AVG,
        TokenType.MIN: Aggregator.MIN,
        TokenType.MAX: Aggregator.MAX,
        TokenType.MEDIAN: Aggregator.MEDIAN,
    }

    def _parse_group_rhs(
        self, relation: Expr, group_tok: Token
    ) -> Group | GroupAggregate:
        """Parse the RHS of a GROUP expression.

        Dispatches on the first token after '(':
        - LBRACE → regroup form: ({A, B, ...} as alias)
        - aggregator keyword → aggregate form: (Count(x) as t, Sum(y) as g)

        Mixing the two forms in one GROUP RHS is rejected with a clear message.
        """
        if not self._match(TokenType.LPAREN):
            raise ParserError("Expected '(' after 'group'", self._current())
        self._advance()  # consume '('

        if self._match(TokenType.LBRACE):
            return self._parse_group_regroup_rhs(relation, group_tok)
        if self._current().type in self._AGGREGATOR_TOKEN_TYPES:
            return self._parse_group_aggregate_rhs(relation, group_tok)
        cur = self._current()
        raise ParserError(
            f"Expected '{{' (regroup form) or an aggregator keyword "
            f"(Count, Sum, Avg, Min, Max, Median) after '(' in 'group', "
            f"got {cur.type.name} ({cur.value!r})",
            cur,
        )

    def _parse_group_regroup_rhs(self, relation: Expr, group_tok: Token) -> Group:
        """Parse the regroup form: {A, B, ...} as alias ).

        The opening '(' has already been consumed by _parse_group_rhs.
        """
        self._advance()  # consume '{'
        attrs: list[str] = []
        if not self._is_attr_name_token():
            raise ParserError(
                "Expected at least one attribute name in 'group' attribute list",
                self._current(),
            )
        attrs.append(self._advance().value)
        while self._match(TokenType.COMMA):
            self._advance()  # consume ','
            if not self._is_attr_name_token():
                raise ParserError(
                    "Expected attribute name after ',' in 'group' attribute list",
                    self._current(),
                )
            attrs.append(self._advance().value)
        if not self._match(TokenType.RBRACE):
            raise ParserError(
                "Expected '}' after attribute list in 'group'", self._current()
            )
        self._advance()  # consume '}'
        if not self._match(TokenType.AS):
            cur = self._current()
            raise ParserError(
                f"Expected 'as' after attribute list in 'group', "
                f"got {cur.type.name} ({cur.value!r})",
                cur,
            )
        self._advance()  # consume 'as'
        if not self._is_attr_name_token():
            raise ParserError(
                "Expected alias name after 'as' in 'group'", self._current()
            )
        alias = self._advance().value
        if not self._match(TokenType.RPAREN):
            raise ParserError(
                "Expected ')' to close 'group' expression", self._current()
            )
        self._advance()  # consume ')'
        return Group(
            relation=relation,
            attrs=attrs,
            alias=alias,
            line=group_tok.line,
            column=group_tok.column,
        )

    def _parse_group_aggregate_rhs(
        self, relation: Expr, group_tok: Token
    ) -> GroupAggregate:
        """Parse the aggregate form: Count(x) as t, Sum(y) as g ).

        The opening '(' has already been consumed by _parse_group_rhs.
        Parses one or more comma-separated AggregatorClause entries,
        then expects ')' to close the GROUP RHS.
        """
        clauses: list[AggregatorClause] = []
        clauses.append(self._parse_aggregator_clause())
        while self._match(TokenType.COMMA):
            self._advance()  # consume ','
            # Guard: if the next token is a '{', reject the mix
            if self._match(TokenType.LBRACE):
                raise ParserError(
                    "cannot mix regroup and aggregator forms in the same 'group' RHS",
                    self._current(),
                )
            clauses.append(self._parse_aggregator_clause())
        if not self._match(TokenType.RPAREN):
            raise ParserError(
                "Expected ')' to close 'group' expression", self._current()
            )
        self._advance()  # consume ')'
        return GroupAggregate(
            relation=relation,
            clauses=clauses,
            line=group_tok.line,
            column=group_tok.column,
        )

    def _parse_aggregator_clause(self) -> AggregatorClause:
        """Parse a single ``Count(attr) as alias`` clause."""
        agg_tok = self._current()
        if agg_tok.type not in self._AGGREGATOR_TOKEN_TYPES:
            raise ParserError(
                f"Expected aggregator keyword (Count, Sum, Avg, Min, Max, Median), "
                f"got {agg_tok.type.name} ({agg_tok.value!r})",
                agg_tok,
            )
        agg = self._TOKEN_TO_AGGREGATOR[agg_tok.type]
        self._advance()  # consume aggregator keyword
        if not self._match(TokenType.LPAREN):
            raise ParserError(
                f"Expected '(' after '{agg_tok.value}' in aggregator clause",
                self._current(),
            )
        self._advance()  # consume '('
        if not self._is_attr_name_token():
            raise ParserError(
                f"Expected attribute name inside '{agg_tok.value}(...)'",
                self._current(),
            )
        attr = self._advance().value
        if not self._match(TokenType.RPAREN):
            raise ParserError(
                f"Expected ')' after attribute in '{agg_tok.value}({attr})'",
                self._current(),
            )
        self._advance()  # consume ')'
        if not self._match(TokenType.AS):
            cur = self._current()
            raise ParserError(
                f"Expected 'as' after '{agg_tok.value}({attr})', "
                f"got {cur.type.name} ({cur.value!r})",
                cur,
            )
        self._advance()  # consume 'as'
        if not self._is_attr_name_token():
            raise ParserError(
                f"Expected alias name after 'as' in '{agg_tok.value}({attr}) as ...'",
                self._current(),
            )
        alias = self._advance().value
        return AggregatorClause(
            agg=agg,
            attr=attr,
            alias=alias,
            line=agg_tok.line,
            column=agg_tok.column,
        )

    def _parse_ungroup_rhs(self, relation: Expr, ungroup_tok: Token) -> Ungroup:
        """Parse the RHS of an UNGROUP expression: alias.

        Called after the 'ungroup' keyword has been consumed.  Expects a
        single identifier naming the nested-relation attribute to flatten.
        """
        if not self._is_attr_name_token():
            raise ParserError("Expected alias name after 'ungroup'", self._current())
        alias = self._advance().value
        return Ungroup(
            relation=relation,
            alias=alias,
            line=ungroup_tok.line,
            column=ungroup_tok.column,
        )

    def _parse_intersect(self) -> Expr:
        """Parse intersect and set difference operators.

        Supports multi-line expressions with natural line breaks.
        """
        left = self._parse_unary()

        while self._match(TokenType.INTERSECT, TokenType.SETMINUS):
            op_token = self._advance()
            # Detect line continuation (backslash or natural newline)
            has_continuation = False
            if self._match(TokenType.CONTINUATION):
                self._advance()  # consume \
                has_continuation = True
                if self._match(TokenType.NEWLINE):
                    self._advance()
                self._skip_newlines()
            elif self._match(TokenType.NEWLINE):
                has_continuation = True
                self._skip_newlines()
            else:
                self._skip_newlines()
            right = self._parse_unary()
            left = BinaryOp(
                operator=op_token.value,
                left=left,
                right=right,
                line_break_after=has_continuation,
                line=op_token.line,
                column=op_token.column,
            )

        return left

    def _parse_postfix(self, *, allow_space_separated: bool = True) -> Expr:
        """Parse postfix operators and space-separated application.

        Postfix operators:
            ^ (superscript), _ (subscript) - take operands
            ~ (inverse), + (transitive), * (reflexive-transitive) - no operands
            (| ... |) (relational image) - takes set argument
            [ ... ] (generic instantiation) - takes type parameters

        Disambiguation: + and * are postfix only if NOT followed by operand.
        If followed by operand, they're infix arithmetic operators.

        Space-separated application: f x y parses as (f x) y (left-associative).
        The allow_space_separated parameter prevents right-associativity when
        parsing arguments recursively.
        """
        base = self._parse_atom()

        # Check for generic instantiation S[X] or schema rename S[a/b].
        # Only treat [ as such if:
        # 1. Base is a type-like construct (Identifier or GenericInstantiation)
        # 2. The '[' immediately follows the last consumed token (no whitespace)
        # This prevents consuming '[' meant for justifications in equiv chains.
        while isinstance(base, (Identifier, GenericInstantiation)) and self._match(
            TokenType.LBRACKET
        ):
            # Check if '[' immediately follows the last token (no whitespace)
            # Use the tracked end position of the last consumed token
            lbracket_col = self._current().column

            # If on different lines or there's a gap,
            # don't treat as generic instantiation or schema rename
            if (
                self._current().line != self.last_token_line
                or lbracket_col > self.last_token_end_column
            ):
                # There's whitespace - likely a justification, not generic
                break

            if self._in_relational_context and self._bracket_contains_slash():
                # In a relational context, S[new/old] → RelationRename
                base = self._parse_relation_rename(base)
            else:
                base = self._parse_schema_rename_or_generic(base)

        # In a relational context, ANY expression base can take a [new/old]
        # postfix to form a RelationRename — handles compound operands such as
        # (pi[tournament](sigma[...](Match)))[tournamentId/tournament].
        # The '[' must immediately follow the closing token (no whitespace).
        if (
            self._in_relational_context
            and not isinstance(base, (Identifier, GenericInstantiation))
            and self._match(TokenType.LBRACKET)
            and self._current().line == self.last_token_line
            and self._current().column <= self.last_token_end_column
            and self._bracket_contains_slash()
        ):
            base = self._parse_relation_rename(base)

        # Check for tuple projection and function application
        # These need to be in the same loop so that f(x).1 works correctly
        # Tuple projection: .1, .2, .3 or .fieldname
        # Function application: expr(...)
        while self._match(TokenType.PERIOD, TokenType.LPAREN):
            # Check for tuple projection .1, .2, .3 or field projection .fieldname
            if self._match(TokenType.PERIOD):
                # Peek ahead to see if it's followed by a number or identifier
                next_token = self._peek_ahead(1)

                if next_token.type == TokenType.NUMBER:
                    # Numeric tuple projection: .1, .2, .3 (mostly original behavior)
                    # Add context-sensitive safety check:
                    # - If in schema text AND base is simple Identifier
                    #   AND followed by binary op
                    #   → likely separator (lambda x : X . 2 * x)
                    # - Otherwise → safe to parse as projection

                    # Only apply safety check in schema text
                    # (lambda/set comp declarations)
                    if self._parsing_schema_text and isinstance(base, Identifier):
                        token_after_num = self._peek_ahead(2)

                        # In lambda/set comp, simple type name followed by
                        # . NUMBER OP suggests separator
                        likely_separator = (
                            TokenType.STAR,  # X . 2 * x (separator in lambda)
                            TokenType.PLUS,  # X . 2 + x (separator)
                            TokenType.MINUS,  # X . 2 - x (separator)
                        )

                        if token_after_num.type in likely_separator:
                            # Ambiguous context - don't parse as projection
                            break

                    # In a comprehension/quantifier body, `.NUMBER` is not a valid
                    # tuple-projection: the base (last declared variable) has a
                    # basic type (N, Z, etc.), so §3.16 projection is ill-typed.
                    # The period must be the bullet separator.
                    if self._in_comprehension_body:
                        break

                    # Safe to parse as numeric projection
                    period_token = self._advance()  # Consume '.'
                    number_token = self._advance()  # Consume number

                    # Convert number to integer index
                    index = int(number_token.value)
                    if index < 1:
                        raise ParserError(
                            f"Tuple projection index must be >= 1, got {index}",
                            number_token,
                        )

                    base = TupleProjection(
                        base=base,
                        index=index,
                        line=period_token.line,
                        column=period_token.column,
                    )

                elif next_token.type == TokenType.IDENTIFIER:
                    # Named field projection: .fieldname (new feature)
                    # Don't parse as projection if we're in schema text
                    # (lambda/set comp) where periods are separators, not operators
                    # In set comprehensions like {c : children(p) . children(c)},
                    # the . after children(p) is the body separator, not field access
                    if self._parsing_schema_text:
                        # In schema text, period is always separator, not projection
                        break

                    # Don't allow field projections on number literals
                    # (only tuples/records have named fields)
                    # This prevents parsing "0 . x" as projection in
                    # "x > 0 . x + 1"
                    if isinstance(base, Number):
                        # Numbers don't have named fields
                        break

                    # Check if we're in a comprehension/quantifier body where
                    # period could be expression separator in comprehension/quantifier
                    # If so, check what follows the identifier
                    token_after_id = self._peek_ahead(2)

                    # In comprehension body, .identifier} likely means separator + expr
                    # Example: {z : Z | z = z_0 * z_0 * z_0 . z}
                    #          period is separator, not projection
                    # Exception: allow the projection when we are parsing the RHS
                    # of a comparison operator (e.g. 'c.class = s.name }'), where
                    # the field is genuinely part of the predicate, not a body expr.
                    if (
                        self._in_comprehension_body
                        and token_after_id.type == TokenType.RBRACE
                        and not self._in_comparison_rhs
                    ):
                        # Likely expression separator, not projection
                        break

                    # In a comprehension body, do not allow chaining a second
                    # projection onto an existing TupleProjection.  The pattern
                    # 'base.field . bullet' (where base is already a projection)
                    # is always a bullet separator followed by a simple expression,
                    # never a doubly-chained projection.  Doubly-chained projections
                    # in comprehension bodies require explicit parentheses.
                    if self._in_comprehension_body and isinstance(
                        base, TupleProjection
                    ):
                        break

                    # Z RM §3.16: field selection requires the LHS to have a
                    # schema (binding) type.  If the identifier after `.` is itself
                    # a declared variable in the current schema-text, the LHS
                    # cannot be a schema-typed expression of that variable, so the
                    # period must be the bullet separator.
                    # Example: `mu c : N; d : N | c = d . c + d` — `.c` has `c`
                    # in `_current_quantifier_vars`, so the period is the bullet.
                    if (
                        self._in_comprehension_body
                        and next_token.value in self._current_quantifier_vars
                    ):
                        break

                    # Only parse if followed by safe token
                    # (not ambiguous with separator)

                    # Safe followers that indicate this is field projection,
                    # not separator
                    safe_followers = (
                        TokenType.PERIOD,  # .field.other (chained)
                        TokenType.LPAREN,  # .field(x)
                        TokenType.RPAREN,  # .field)
                        TokenType.RBRACE,  # .field}
                        TokenType.RBRACKET,  # .field]
                        TokenType.RANGLE,  # .field>
                        TokenType.COMMA,  # .field,
                        TokenType.SEMICOLON,  # .field;
                        TokenType.EQUALS,  # .field =
                        TokenType.NOT_EQUAL,  # .field !=
                        TokenType.IN,  # .field in
                        TokenType.NOTIN,  # .field notin
                        TokenType.SUBSET,  # .field subset
                        TokenType.PSUBSET,  # .field psubset
                        TokenType.LESS_THAN,  # .field <
                        TokenType.GREATER_THAN,  # .field >
                        TokenType.LESS_EQUAL,  # .field <=
                        TokenType.GREATER_EQUAL,  # .field >=
                        TokenType.IMPLIES,  # .field =>
                        TokenType.IFF,  # .field <=>
                        TokenType.AND,  # .field and
                        TokenType.OR,  # .field or
                        TokenType.PLUS,  # .field +
                        TokenType.MINUS,  # .field -
                        TokenType.RBIND,  # .field |} (inside binding {| ... |})
                        TokenType.EOF,  # .field (standalone)
                        TokenType.NEWLINE,  # .field\n (end of line)
                    )

                    if token_after_id.type in safe_followers:
                        # Safe context - parse as field projection
                        period_token = self._advance()  # Consume '.'
                        field_token = self._advance()  # Consume identifier

                        base = TupleProjection(
                            base=base,
                            index=field_token.value,  # Field name as string
                            line=period_token.line,
                            column=period_token.column,
                        )
                    else:
                        # Not safe - likely a separator, leave PERIOD unparsed
                        break
                else:
                    # Not projection, leave PERIOD for other uses
                    break

            # Check for function application expr(...)
            elif self._match(TokenType.LPAREN):
                lparen_token = self._advance()  # Consume '('
                args = self._parse_argument_list()
                if not self._match(TokenType.RPAREN):
                    raise ParserError(
                        "Expected ')' after function arguments", self._current()
                    )
                self._advance()  # Consume ')'
                base = FunctionApp(
                    function=base,
                    args=args,
                    line=lparen_token.line,
                    column=lparen_token.column,
                )

        # Keep applying other postfix operators
        while self._match(
            TokenType.CARET,
            TokenType.UNDERSCORE,
            TokenType.TILDE,
            TokenType.PLUS,
            TokenType.STAR,
            TokenType.LIMG,  # (| for relational image
        ):
            # Check for postfix +/* disambiguation
            # If + or * followed by operand, treat as infix (don't consume as postfix)
            if self._match(TokenType.PLUS, TokenType.STAR) and self._is_operand_start():
                break

            # Relational image R(| S |)
            if self._match(TokenType.LIMG):
                limg_token = self._advance()  # Consume '(|'
                set_expr = self._parse_expr()  # Parse the set argument
                if not self._match(TokenType.RIMG):
                    raise ParserError(
                        "Expected '|)' after relational image argument", self._current()
                    )
                self._advance()  # Consume '|)'
                base = RelationalImage(
                    relation=base,
                    set=set_expr,
                    line=limg_token.line,
                    column=limg_token.column,
                )
                continue

            op_token = self._advance()

            if op_token.type == TokenType.CARET:
                # Superscript takes an operand
                operand = self._parse_atom()
                base = Superscript(
                    base=base,
                    exponent=operand,
                    line=op_token.line,
                    column=op_token.column,
                )
            elif op_token.type == TokenType.UNDERSCORE:
                # Subscript takes an operand
                operand = self._parse_atom()
                base = Subscript(
                    base=base,
                    index=operand,
                    line=op_token.line,
                    column=op_token.column,
                )
            else:
                # Postfix: ~ (inverse), + (transitive), * (reflexive-transitive)
                base = UnaryOp(
                    operator=op_token.value,
                    operand=base,
                    line=op_token.line,
                    column=op_token.column,
                )

        # Space-separated function application: f x y z → (((f x) y) z)
        # Only parse if allow_space_separated is True (prevents right-associativity)
        if allow_space_separated:
            while self._should_parse_space_separated_arg():
                # Save position for error reporting
                arg_start_token = self._current()

                # Parse argument with all its postfix operators
                # but WITHOUT space-separated application (prevents right-associativity)
                arg = self._parse_postfix(allow_space_separated=False)

                # Wrap in function application
                base = FunctionApp(
                    function=base,
                    args=[arg],
                    line=arg_start_token.line,
                    column=arg_start_token.column,
                )

        return base

    def _parse_parenthesized_expr_or_tuple(self) -> Expr:
        """Parse parenthesized expression or tuple.

        This parses (expr), (expr,), or (expr1, expr2, ...).
        Used by both _parse_atom and _parse_quantifier for tuple patterns.

        When _in_schema_expr_context is True, the inner expression is parsed
        with schema-calculus precedence so that ``(S ; T)`` works correctly.
        """
        lparen_token = self._advance()  # Consume '('

        # Parse first expression — use schema-calculus entry point when in
        # schema-expression context so that ';' is treated as composition.
        if self._in_schema_expr_context:
            first_expr = self._parse_schema_pipe()
        else:
            first_expr = self._parse_expr()

        # Allow newlines for multi-line expressions
        self._skip_newlines()

        # Check for comma (tuple) vs single parenthesized expression
        if self._match(TokenType.COMMA):
            # It's a tuple: (expr, expr, ...)
            elements: list[Expr] = [first_expr]

            while self._match(TokenType.COMMA):
                self._advance()  # Consume ','
                # Allow newlines after comma in tuples
                self._skip_newlines()
                # Check for trailing comma: (a, b,)
                if self._match(TokenType.RPAREN):
                    break
                if self._in_schema_expr_context:
                    elements.append(self._parse_schema_pipe())
                else:
                    elements.append(self._parse_expr())
                # Allow newlines for multi-line tuples
                self._skip_newlines()

            if not self._match(TokenType.RPAREN):
                raise ParserError("Expected ')' after tuple", self._current())
            self._advance()  # Consume ')'

            return Tuple(
                elements=elements,
                line=lparen_token.line,
                column=lparen_token.column,
            )

        # Single parenthesized expression
        if not self._match(TokenType.RPAREN):
            raise ParserError("Expected ')' after expression", self._current())
        self._advance()  # Consume ')'

        # Mark BinaryOp as explicitly parenthesized to preserve user intent
        if isinstance(first_expr, BinaryOp):
            return dataclasses.replace(first_expr, explicit_parens=True)

        return first_expr

    # ------------------------------------------------------------------
    # Relational algebra parsers (Phase 2.2)
    # ------------------------------------------------------------------

    def _parse_restrict(self) -> Restrict:
        """Parse sigma[predicate](relation)."""
        op_tok = self._advance()  # consume 'sigma'
        if not self._match(TokenType.LBRACKET):
            raise ParserError("Expected '[' after sigma", self._current())
        bracket_tok = self._advance()  # consume '['
        if self._match(TokenType.RBRACKET):
            raise ParserError(
                "Expected predicate expression in sigma[...]", self._current()
            )
        predicate = self._parse_expr()
        if not self._match(TokenType.RBRACKET):
            raise ParserError("Expected ']' after sigma predicate", bracket_tok)
        self._advance()  # consume ']'
        if not self._match(TokenType.LPAREN):
            raise ParserError("Expected '(' after sigma[...]", self._current())
        self._advance()  # consume '('
        prev_relational = self._in_relational_context
        self._in_relational_context = True
        try:
            relation = self._parse_expr()
        finally:
            self._in_relational_context = prev_relational
        if not self._match(TokenType.RPAREN):
            raise ParserError(
                "Expected ')' after sigma relation argument", self._current()
            )
        self._advance()  # consume ')'
        return Restrict(
            predicate=predicate,
            relation=relation,
            line=op_tok.line,
            column=op_tok.column,
        )

    def _parse_project(self) -> Project:
        """Parse pi[A, B, ...](relation)."""
        op_tok = self._advance()  # consume 'pi'
        if not self._match(TokenType.LBRACKET):
            raise ParserError("Expected '[' after pi", self._current())
        bracket_tok = self._advance()  # consume '['
        if self._match(TokenType.RBRACKET):
            raise ParserError("Expected attribute list in pi[...]", self._current())
        # Parse comma-separated attribute names (identifiers or keyword-identifiers)
        attrs: list[str] = []
        if not self._is_attr_name_token():
            raise ParserError("Expected attribute name in pi[...]", self._current())
        attrs.append(self._advance().value)
        while self._match(TokenType.COMMA):
            self._advance()  # consume ','
            if not self._is_attr_name_token():
                raise ParserError(
                    "Expected attribute name after ',' in pi[...]", self._current()
                )
            attrs.append(self._advance().value)
        if not self._match(TokenType.RBRACKET):
            raise ParserError("Expected ']' after pi attribute list", bracket_tok)
        self._advance()  # consume ']'
        if not self._match(TokenType.LPAREN):
            raise ParserError("Expected '(' after pi[...]", self._current())
        self._advance()  # consume '('
        prev_relational = self._in_relational_context
        self._in_relational_context = True
        try:
            relation = self._parse_expr()
        finally:
            self._in_relational_context = prev_relational
        if not self._match(TokenType.RPAREN):
            raise ParserError(
                "Expected ')' after pi relation argument", self._current()
            )
        self._advance()  # consume ')'
        return Project(
            attrs=attrs,
            relation=relation,
            line=op_tok.line,
            column=op_tok.column,
        )

    def _parse_relation_rename(self, base: Expr) -> RelationRename:
        """Parse R[new/old, ...] postfix in a relational context.

        Called from ``_parse_postfix`` when ``_in_relational_context`` is True
        and the bracket contents contain a ``/`` separator.  The ``[`` has NOT
        been consumed on entry; this method consumes it and the matching ``]``.

        Grammar:
            relation_rename ::= '[' pair (',' pair)* ']'
            pair            ::= name '/' name
            name            ::= IDENTIFIER | keyword-usable-as-identifier

        Per Z RM §3.11 the new name appears first (``new``), the old name
        second (``old``).  Pair direction: ``(new_name, old_name)``.

        Attribute names admit keywords as identifiers (``id``, ``dom``, ``ran``,
        etc.) because relation attribute names can coincide with operator keywords.
        """
        open_tok = self._advance()  # Consume '['

        pairs: list[tuple[str, str]] = []

        while not self._match(TokenType.RBRACKET):
            if self._at_end() or self._match(TokenType.NEWLINE, TokenType.EOF):
                raise ParserError(
                    "unclosed '[' in relation rename",
                    open_tok,
                )

            # Expect new (target) name (identifier or keyword-as-identifier)
            if not self._is_attr_name_token():
                cur = self._current()
                raise ParserError(
                    f"expected identifier before '/' in relation rename pair,"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )
            new_name = self._advance().value

            # Expect '/'
            if not self._match(TokenType.SLASH):
                cur = self._current()
                raise ParserError(
                    f"expected '/' in relation rename pair after {new_name!r},"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )
            self._advance()  # Consume '/'

            # Expect old (source) name (identifier or keyword-as-identifier)
            if not self._is_attr_name_token():
                cur = self._current()
                raise ParserError(
                    f"expected identifier after '/' in relation rename pair,"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )
            old_name = self._advance().value

            pairs.append((new_name, old_name))

            # Optional comma separator
            if self._match(TokenType.COMMA):
                self._advance()  # Consume ','
                if self._match(TokenType.RBRACKET):
                    raise ParserError(
                        "expected rename pair after ',' in relation rename",
                        self._current(),
                    )
                continue

            if not self._match(TokenType.RBRACKET):
                cur = self._current()
                raise ParserError(
                    f"expected ',' or ']' in relation rename,"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )

        if not pairs:
            raise ParserError(
                "relation rename requires at least one pair",
                open_tok,
            )

        self._advance()  # Consume ']'

        return RelationRename(
            relation=base,
            pairs=pairs,
            line=open_tok.line,
            column=open_tok.column,
        )

    def _is_attr_name_token(self) -> bool:
        """Return True if the current token is usable as an attribute name.

        Attribute names in pi[...] contexts are plain names.
        They admit keywords-as-identifiers (id, dom, ran, etc.) because Z
        field names can coincide with operator keywords.
        """
        return (
            self._match(TokenType.IDENTIFIER) or self._is_keyword_usable_as_identifier()
        )

    def _parse_atom(self) -> Expr:
        """Parse atom.

        Handles: identifier, number, parenthesized expression, set comprehension,
        prefix operators (dom, ran, inv, id, P, P1, F, F1, bigcup, bigcap),
        function application f(x), lambda expressions, and relational algebra
        prefix operators (sigma, pi).
        """
        # Relational algebra prefix-with-args operators (Phase 2.2): sigma and pi
        if self._match(TokenType.SIGMA):
            return self._parse_restrict()
        if self._match(TokenType.PI):
            return self._parse_project()

        # Prefix operators: relation functions, set functions, sequence operators
        # Check for generic instantiation P[X] before treating as prefix
        if self._match(
            TokenType.DOM,
            TokenType.RAN,
            TokenType.INV,
            TokenType.ID,
            TokenType.POWER,
            TokenType.POWER1,
            TokenType.FINSET,
            TokenType.FINSET1,
            TokenType.BIGCUP,  # Distributed union
            TokenType.BIGCAP,  # Distributed intersection
        ):
            op_token = self._advance()

            # Check if followed by '[' for generic instantiation like P[X]
            # If so, return as identifier and let postfix handle the [...]
            if self._match(TokenType.LBRACKET):
                # This is generic instantiation, not prefix operator
                # Return as Identifier and let _parse_postfix handle the [...]
                # Need to backtrack and reparse
                self.pos -= 1  # Back up before the operator token
                op_token = self._advance()  # Re-read it
                return Identifier(
                    name=op_token.value,
                    line=op_token.line,
                    column=op_token.column,
                )

            # Check if followed by a valid operand for prefix operator
            # If not, treat as standalone identifier (e.g., "R \ id" not "id R")
            if not self._match(
                TokenType.IDENTIFIER,
                TokenType.NUMBER,
                TokenType.LPAREN,
                TokenType.LBRACE,
                TokenType.LANGLE,
                TokenType.LAMBDA,
                TokenType.IF,
                TokenType.DOM,
                TokenType.RAN,
                TokenType.INV,
                TokenType.ID,
                TokenType.POWER,
                TokenType.POWER1,
                TokenType.FINSET,
                TokenType.FINSET1,
                TokenType.BIGCUP,
                TokenType.BIGCAP,
            ):
                # Not followed by valid operand, treat as identifier
                return Identifier(
                    name=op_token.value,
                    line=op_token.line,
                    column=op_token.column,
                )

            # Not followed by '[', so it's a prefix operator
            operand = self._parse_atom()
            return UnaryOp(
                operator=op_token.value,
                operand=operand,
                line=op_token.line,
                column=op_token.column,
            )

        # Lambda expressions (lambda x : X . body)
        if self._match(TokenType.LAMBDA):
            return self._parse_lambda()

        # Conditional expressions (if/then/else)
        if self._match(TokenType.IF):
            return self._parse_conditional()

        # Quantified expressions (forall, exists, exists1, mu) as atoms
        # These can appear in expressions like: BadMu = mu n : N | n > 0
        if self._match(
            TokenType.FORALL, TokenType.EXISTS, TokenType.EXISTS1, TokenType.MU
        ):
            return self._parse_quantifier()

        # θ-expression: theta SchemaRef  (Z RM §3.10)
        # Binds tightly at primary-expression level.
        if self._match(TokenType.THETA):
            theta_token = self._advance()
            # Require a schema reference (identifier-shaped atom) to follow.
            if not self._match(
                TokenType.IDENTIFIER,
                TokenType.DELTA,
                TokenType.XI,
            ):
                cur = self._current()
                if cur.type == TokenType.EOF:
                    raise ParserError(
                        "Unexpected end of input after 'theta';"
                        " expected schema name (e.g. theta S)",
                        cur,
                    )
                raise ParserError(
                    f"Expected schema name after theta,"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )
            schema_ref = self._parse_atom()
            return Theta(
                expr=schema_ref,
                line=theta_token.line,
                column=theta_token.column,
            )

        # Identifiers (including keywords allowed as function names)
        # Note: Function application expr(...) is handled in _parse_postfix()
        # Note: Generic instantiation Type[X] is handled in _parse_postfix()
        # Note: Relational image R(| S |) is handled in _parse_postfix()
        if self._match(
            TokenType.IDENTIFIER,
            TokenType.UNION,
            TokenType.INTERSECT,
            TokenType.FILTER,
            # Delta and Xi are keywords in declaration context but remain
            # valid identifiers in expression context (e.g. Gamma shows Delta).
            TokenType.DELTA,
            TokenType.XI,
        ):
            name_token = self._advance()
            return Identifier(
                name=name_token.value, line=name_token.line, column=name_token.column
            )

        if self._match(TokenType.NUMBER):
            token = self._advance()
            return Number(value=token.value, line=token.line, column=token.column)

        if self._match(TokenType.STRING):
            token = self._advance()
            return StringLit(value=token.value, line=token.line, column=token.column)

        if self._match(TokenType.LPAREN):
            return self._parse_parenthesized_expr_or_tuple()

        # Binding literal {| name == expr, ... |} (Z RM §3.7)
        if self._match(TokenType.LBIND):
            return self._parse_binding()

        # Set comprehension or set literal {x : X | pred} or {a, b, c}
        if self._match(TokenType.LBRACE):
            return self._parse_set()

        # Sequence literals ⟨a, b, c⟩
        if self._match(TokenType.LANGLE):
            return self._parse_sequence_literal()

        # Bag literals [[a, b, c]]
        # Check for two consecutive left brackets
        if self._match(TokenType.LBRACKET):
            # Peek ahead to see if next token is also LBRACKET
            if self._peek_ahead(1).type == TokenType.LBRACKET:
                return self._parse_bag_literal()
            # Single bracket - not a bag literal, error out
            raise ParserError(
                "Unexpected '[' - did you mean '[[' for bag literal?",
                self._current(),
            )

        # Handle unary prefix operators in restricted contexts
        # This allows # and not to work in set comprehension predicates
        # and other contexts where _parse_atom() is called directly
        if self._match(TokenType.HASH, TokenType.NOT, TokenType.MINUS):
            return self._parse_unary()

        raise ParserError(
            f"Expected identifier, number, '(', '{{', '{{|', '⟨', or lambda,"
            f" got {self._current().type.name}",
            self._current(),
        )

    def _parse_argument_list(self) -> list[Expr]:
        """Parse comma-separated argument list for function application.

        Handles empty list f(), single arg f(x), multiple args f(x, y, z).
        Returns: List of expressions (arguments).
        """
        args: list[Expr] = []

        # Empty argument list: f()
        if self._match(TokenType.RPAREN):
            return args

        # Parse first argument
        args.append(self._parse_expr())

        # Parse remaining arguments (comma-separated)
        while self._match(TokenType.COMMA):
            self._advance()  # Consume ','
            args.append(self._parse_expr())

        return args

    def _parse_sequence_literal(self) -> Expr:
        """Parse sequence literal: ⟨⟩, ⟨a⟩, ⟨a, b, c⟩."""
        langle_token = self._advance()  # Consume '⟨'

        elements: list[Expr] = []

        # Empty sequence: ⟨⟩
        if self._match(TokenType.RANGLE):
            self._advance()  # Consume '⟩'
            return SequenceLiteral(
                elements=elements,
                line=langle_token.line,
                column=langle_token.column,
            )

        # Parse comma-separated elements
        elements.append(self._parse_expr())

        while self._match(TokenType.COMMA):
            self._advance()  # Consume ','
            # Check for trailing comma: ⟨a, b,⟩
            if self._match(TokenType.RANGLE):
                break
            elements.append(self._parse_expr())

        # Expect closing angle bracket
        if not self._match(TokenType.RANGLE):
            raise ParserError("Expected '⟩' to close sequence literal", self._current())
        self._advance()  # Consume '⟩'

        return SequenceLiteral(
            elements=elements,
            line=langle_token.line,
            column=langle_token.column,
        )

    def _parse_bag_literal(self) -> Expr:
        """Parse bag literal: [[a]], [[a, b, c]].

        Bag literals use double brackets: [[...]]
        """
        # Consume first '['
        lbag_token = self._advance()
        # Consume second '['
        if not self._match(TokenType.LBRACKET):
            raise ParserError("Expected second '[' for bag literal", self._current())
        self._advance()

        elements: list[Expr] = []

        # Parse comma-separated elements
        elements.append(self._parse_expr())

        while self._match(TokenType.COMMA):
            self._advance()  # Consume ','
            # Check for closing brackets
            if self._match(TokenType.RBRACKET):
                break
            elements.append(self._parse_expr())

        # Expect first closing bracket
        if not self._match(TokenType.RBRACKET):
            raise ParserError("Expected ']' to close bag literal", self._current())
        self._advance()  # Consume first ']'

        # Expect second closing bracket
        if not self._match(TokenType.RBRACKET):
            raise ParserError(
                "Expected second ']' to close bag literal", self._current()
            )
        self._advance()  # Consume second ']'

        return BagLiteral(
            elements=elements,
            line=lbag_token.line,
            column=lbag_token.column,
        )

    def _parse_given_type(self) -> GivenType:
        """Parse given type: given A, B, C"""
        start_token = self._advance()  # Consume 'given'

        names: list[str] = []

        # Parse comma-separated list of type names
        # Stop at NEWLINE, END (for zed blocks), or EOF
        while not self._at_end() and not self._match(TokenType.NEWLINE, TokenType.END):
            if self._match(TokenType.COMMA):
                self._advance()  # Skip comma
                continue

            if not self._match(TokenType.IDENTIFIER):
                raise ParserError(
                    "Expected type name in given declaration", self._current()
                )

            names.append(self._current().value)
            self._advance()

        if not names:
            raise ParserError(
                "Expected at least one type name in given declaration", self._current()
            )

        return GivenType(names=names, line=start_token.line, column=start_token.column)

    def _parse_free_branch(self, branch_token: Token) -> FreeBranch:
        """Parse a single free type branch with optional parameters.

        Assumes the branch name token has already been consumed. Parses
        optional constructor parameters in angle brackets: <...> or ⟨...⟩

        Args:
            branch_token: The token containing the branch name

        Returns:
            FreeBranch with name and optional parameters
        """
        branch_name = branch_token.value

        # Check for constructor parameters: ⟨...⟩ or <...>
        parameters: Expr | None = None
        if self._match(TokenType.LANGLE):
            langle_token = self._current()
            self._advance()  # Consume '⟨' or '<'

            # Check for empty parameters: ⟨⟩
            if self._match(TokenType.RANGLE):
                # Empty parameters - create empty sequence literal
                parameters = SequenceLiteral(
                    elements=[],
                    line=langle_token.line,
                    column=langle_token.column,
                )
                self._advance()  # Consume '⟩' or '>'
            else:
                # Parse parameter type expression (can be cross product)
                # Examples: ⟨N⟩, ⟨Tree⟩, ⟨Tree x Tree⟩
                parameters = self._parse_cross()

                # Expect closing angle bracket
                if not self._match(TokenType.RANGLE):
                    raise ParserError(
                        "Expected '⟩' or '>' after constructor parameters",
                        self._current(),
                    )
                self._advance()  # Consume '⟩' or '>'

        return FreeBranch(
            name=branch_name,
            parameters=parameters,
            line=branch_token.line,
            column=branch_token.column,
        )

    def _parse_free_type(self) -> FreeType:
        """Parse free type: Type ::= branch1 | branch2⟨N⟩ | branch3⟨Tree x Tree⟩.

        Supports recursive constructors with parameters.

        Examples:
            Status ::= active | inactive (simple branches)
            Tree ::= stalk | leaf⟨N⟩ | branch⟨Tree x Tree⟩ (with parameters)
        """
        # Identifier already consumed in _parse_document_item, need to back up
        name_token = self._current()
        type_name = name_token.value
        self._advance()  # Move to ::=

        if not self._match(TokenType.FREE_TYPE):
            raise ParserError("Expected '::=' in free type definition", self._current())
        self._advance()  # Consume '::='

        branches: list[FreeBranch] = []

        # Parse pipe-separated list of branches
        # Stop at NEWLINE, END (for zed blocks), or EOF
        while not self._at_end() and not self._match(TokenType.NEWLINE, TokenType.END):
            # Accept IDENTIFIER or keywords that could be branch names (P, F, etc.)
            if (
                self._match(TokenType.IDENTIFIER)
                or self._match(TokenType.POWER)
                or self._match(TokenType.POWER1)
                or self._match(TokenType.FINSET)
                or self._match(TokenType.FINSET1)
            ):
                branch_token = self._current()
                self._advance()
                branches.append(self._parse_free_branch(branch_token))

            # Check for pipe separator
            if self._match(TokenType.PIPE):
                self._advance()
            elif (
                not self._match(TokenType.NEWLINE, TokenType.END) and not self._at_end()
            ):
                # Unexpected token - raise error to prevent infinite loop
                current = self._current()
                if current.type == TokenType.EQUALS:
                    raise ParserError(
                        "Unexpected '=' in free type definition. "
                        "Did you mean '::=' instead of '::=='?",
                        current,
                    )
                raise ParserError(
                    f"Expected branch name or '|' in free type definition, "
                    f"got {current.type.name}",
                    current,
                )

        if not branches:
            raise ParserError(
                "Expected at least one branch in free type definition", self._current()
            )

        return FreeType(
            name=type_name,
            branches=branches,
            line=name_token.line,
            column=name_token.column,
        )

    def _parse_syntax_block(self) -> SyntaxBlock:
        """Parse syntax environment for aligned free type definitions.

        Syntax:
          syntax
            TypeName ::= branch1 | branch2

            AnotherType ::= branch1<Param>
                         |  branch2<Param1 cross Param2>
          end

        Generates column-aligned LaTeX with \also between groups.
        """
        start_token = self._advance()  # Consume 'syntax'
        self._skip_newlines()

        # Parse groups of definitions separated by blank lines
        groups: list[list[SyntaxDefinition]] = []
        current_group: list[SyntaxDefinition] = []

        while not self._at_end() and not self._match(TokenType.END):
            # Check for blank line (group separator)
            if self._match(TokenType.NEWLINE):
                # Count consecutive newlines
                newline_count = 0
                while self._match(TokenType.NEWLINE):
                    newline_count += 1
                    self._advance()

                # Blank line (2+ newlines) separates groups
                if newline_count >= 2 and current_group:
                    groups.append(current_group)
                    current_group = []

                # Skip any remaining newlines
                self._skip_newlines()

                if self._match(TokenType.END):
                    break

            # Parse a single free type definition
            if not self._match(TokenType.IDENTIFIER):
                if not self._match(TokenType.END):
                    current_type = self._current().type.name
                    raise ParserError(
                        f"Expected type name in syntax block, got {current_type}",
                        self._current(),
                    )
                break

            # Parse: TypeName ::= branches
            type_name_token = self._current()
            type_name = type_name_token.value
            self._advance()

            if not self._match(TokenType.FREE_TYPE):
                raise ParserError(
                    "Expected '::=' after type name in syntax block",
                    self._current(),
                )
            self._advance()  # Consume '::='

            # Parse branches using shared helper
            branches: list[FreeBranch] = []

            # Parse initial set of branches on the same line
            while not self._at_end():
                if self._match(TokenType.NEWLINE, TokenType.END):
                    break
                # Parse branch name
                if not self._match(TokenType.IDENTIFIER):
                    if self._match(TokenType.PIPE):
                        # Skip leading pipe if present
                        self._advance()
                        continue
                    break

                branch_token = self._current()
                self._advance()
                branches.append(self._parse_free_branch(branch_token))

                # Check for pipe separator
                if self._match(TokenType.PIPE):
                    self._advance()

            # Check for continuation lines (starting with |)
            while not self._at_end() and not self._match(TokenType.END):
                # Skip single newline
                if self._match(TokenType.NEWLINE):
                    self._advance()

                # Check if next line starts with |
                if not self._match(TokenType.PIPE):
                    break

                self._advance()  # Consume continuation '|'

                # Parse branches on this continuation line
                while not self._at_end():
                    if self._match(TokenType.NEWLINE, TokenType.END):
                        break

                    if not self._match(TokenType.IDENTIFIER):
                        if self._match(TokenType.PIPE):
                            self._advance()
                            continue
                        break

                    branch_token = self._current()
                    self._advance()
                    branches.append(self._parse_free_branch(branch_token))

                    if self._match(TokenType.PIPE):
                        self._advance()

            if not branches:
                raise ParserError(
                    f"Expected at least one branch for type {type_name}",
                    type_name_token,
                )

            # Create SyntaxDefinition
            current_group.append(
                SyntaxDefinition(
                    name=type_name,
                    branches=branches,
                    line=type_name_token.line,
                    column=type_name_token.column,
                )
            )

            # Skip trailing newline after definition
            if self._match(TokenType.NEWLINE):
                self._advance()

        # Add final group if not empty
        if current_group:
            groups.append(current_group)

        # Expect 'end'
        if not self._match(TokenType.END):
            raise ParserError("Expected 'end' to close syntax block", self._current())
        self._advance()  # Consume 'end'

        if not groups:
            raise ParserError(
                "Expected at least one type definition in syntax block", start_token
            )

        return SyntaxBlock(
            groups=groups,
            line=start_token.line,
            column=start_token.column,
        )

    def _scan_for_defs_after_brackets(self, offset: int) -> bool:
        """Return True when a balanced bracket group starting at ``offset`` is
        followed immediately by a DEFS token.

        Used for lookahead disambiguation: ``Name[X, Y] defs ...`` is a
        horizontal definition, not an expression.  The bracket group at
        ``offset`` must start with LBRACKET; the scan terminates as soon as
        bracket depth returns to zero and checks the next token for DEFS.

        Returns False on any unexpected terminator (EOF, NEWLINE, etc.).
        Generic parameters must be on the same line as the name — a NEWLINE
        inside the bracket group ends the scan and returns False.
        """
        tok = self._peek_ahead(offset)
        if tok.type != TokenType.LBRACKET:
            return False
        depth = 1
        offset += 1
        while depth > 0:
            tok = self._peek_ahead(offset)
            if tok.type in (TokenType.EOF, TokenType.NEWLINE):
                return False
            if tok.type == TokenType.LBRACKET:
                depth += 1
            elif tok.type == TokenType.RBRACKET:
                depth -= 1
            offset += 1
        return self._peek_ahead(offset).type == TokenType.DEFS

    def _parse_horiz_def_generic_params(self) -> list[str] | None:
        """Parse optional generic LHS parameters for a horizontal definition.

        Identical to ``_parse_generic_params`` but records the opening bracket
        token for an improved error message when the bracket is not closed.

        Returns None when no ``[`` is present.
        """
        if not self._match(TokenType.LBRACKET):
            return None

        open_tok = self._advance()  # Consume '[', save for error reporting
        params: list[str] = []

        while not self._match(TokenType.RBRACKET) and not self._at_end():
            if self._match(TokenType.COMMA):
                self._advance()  # Skip comma
                continue

            if self._match(TokenType.NEWLINE, TokenType.EOF):
                raise ParserError(
                    "unclosed '[' in generic parameter list for horizontal definition",
                    open_tok,
                )

            if not self._match(TokenType.IDENTIFIER):
                raise ParserError(
                    "expected type parameter name in generic list",
                    self._current(),
                )

            params.append(self._current().value)
            self._advance()

        if not self._match(TokenType.RBRACKET):
            raise ParserError(
                "unclosed '[' in generic parameter list for horizontal definition",
                open_tok,
            )
        self._advance()  # Consume ']'

        return params if params else None

    # ------------------------------------------------------------------
    # Schema-calculus operators (Phase 3.2 — Z RM §3.11)
    # ------------------------------------------------------------------
    # Precedence (tightest to loosest):
    #   1. hide / project   (_parse_schema_project_hide)
    #   2. composition ;    (_parse_schema_compose)
    #   3. piping >>        (_parse_schema_pipe)
    #
    # These methods are only entered from _parse_horiz_def_rhs (and any
    # future schema-expression context) when _in_schema_expr_context is
    # True.  Inside axdef / schema / gendef bodies SEMICOLON remains a
    # plain declaration separator — those loops never call these methods.
    # ------------------------------------------------------------------

    def _parse_schema_pipe(self) -> Expr:
        """Parse schema piping ``S >> T`` (lowest schema-calculus precedence).

        Left-associative: ``A >> B >> C`` parses as ``(A >> B) >> C``.
        """
        left = self._parse_schema_compose()

        while self._match(TokenType.PIPE_PIPE):
            op_tok = self._advance()
            right = self._parse_schema_compose()
            left = SchemaPipe(
                left=left,
                right=right,
                line=op_tok.line,
                column=op_tok.column,
            )

        return left

    def _parse_schema_compose(self) -> Expr:
        """Parse schema composition ``S ; T`` (middle schema-calculus precedence).

        Left-associative: ``A ; B ; C`` parses as ``(A ; B) ; C``.
        SEMICOLON is consumed here only because _in_schema_expr_context is True;
        callers in declaration-loop contexts never invoke this method.
        """
        left = self._parse_schema_project_hide()

        while self._match(TokenType.SEMICOLON):
            op_tok = self._advance()
            right = self._parse_schema_project_hide()
            left = SchemaCompose(
                left=left,
                right=right,
                line=op_tok.line,
                column=op_tok.column,
            )

        return left

    def _parse_schema_project_hide(self) -> Expr:
        """Parse schema hiding and projection (tightest schema-calculus precedence).

        ``S hide (x, y)``  — existentially quantify named components.
        ``S project T``    — project S onto the signature of T.

        Both are left-associative and at the same precedence level, so they
        chain: ``S hide (x) project T`` is ``(S hide (x)) project T``.
        """
        # Start with a base schema expression (ordinary expression precedence).
        left = self._parse_expr()

        while self._match(TokenType.HIDE, TokenType.PROJECT):
            op_tok = self._advance()

            if op_tok.type == TokenType.HIDE:
                # Expect '(' name, name, ... ')'
                if not self._match(TokenType.LPAREN):
                    raise ParserError(
                        "expected '(' after 'hide' in schema hiding expression",
                        self._current(),
                    )
                self._advance()  # Consume '('

                names: list[str] = []
                while not self._match(TokenType.RPAREN):
                    if self._at_end():
                        raise ParserError(
                            "unclosed '(' in 'hide' expression — expected ')'",
                            op_tok,
                        )
                    if self._match(TokenType.COMMA):
                        self._advance()
                        continue
                    if not self._match(TokenType.IDENTIFIER):
                        cur = self._current()
                        raise ParserError(
                            f"expected identifier in 'hide' name list,"
                            f" got {cur.type.name} ({cur.value!r})",
                            cur,
                        )
                    names.append(self._advance().value)

                if not names:
                    raise ParserError(
                        "'hide' requires at least one component name", op_tok
                    )
                self._advance()  # Consume ')'

                left = SchemaHide(
                    schema=left,
                    names=names,
                    line=op_tok.line,
                    column=op_tok.column,
                )

            else:  # PROJECT
                right = self._parse_expr()
                left = SchemaProject(
                    left=left,
                    right=right,
                    line=op_tok.line,
                    column=op_tok.column,
                )

        return left

    def _parse_horiz_def(self) -> HorizDef:
        """Parse horizontal schema definition: Name [X, Y]? defs RHS.

        Per Z RM §3.8, the RHS is one of:
        - A schema reference — an identifier, possibly Phase-0 decorated
          (e.g. ``Counter'``, ``Delta Counter``).
        - An inline schema text ``[ decl-list | pred-list ]``.
        - A schema-calculus expression (Phase 3.2): S ; T, S >> T,
          S hide (x, y), S project T, and combinations.
        """
        start_tok = self._current()

        # Consume the LHS name
        if not self._match(TokenType.IDENTIFIER):
            raise ParserError(
                "expected schema name for horizontal definition", start_tok
            )
        name_tok = self._advance()
        name = name_tok.value

        # Optional generic parameters on the LHS: Name[X, Y]
        generics = self._parse_horiz_def_generic_params()

        # Consume 'defs'
        if not self._match(TokenType.DEFS):
            raise ParserError(
                "expected 'defs' in horizontal schema definition",
                self._current(),
            )
        self._advance()  # Consume 'defs'

        # --- Parse RHS ---
        if self._at_end() or self._match(TokenType.NEWLINE):
            raise ParserError(
                "expected RHS after 'defs' in horizontal schema definition",
                self._current(),
            )

        body: Expr | SchemaInclusion
        if self._match(TokenType.LBRACKET):
            body = self._parse_schema_text()
        else:
            # Enable schema-expression context so ';' becomes composition.
            prev = self._in_schema_expr_context
            self._in_schema_expr_context = True
            try:
                body = self._parse_horiz_def_rhs()
            finally:
                self._in_schema_expr_context = prev

        return HorizDef(
            name=name,
            generics=generics,
            body=body,
            line=start_tok.line,
            column=start_tok.column,
        )

    def _parse_horiz_def_rhs(self) -> Expr | SchemaInclusion:
        """Parse a schema expression on the RHS of a horizontal definition.

        Accepts:
        - A plain identifier (possibly Phase-0 decorated).
        - ``Delta Name [generics]?`` or ``Xi Name [generics]?`` — schema
          inclusions used as the RHS (legal in Z RM §3.8 examples).
        - A generic instantiation: ``Name[T]`` produced by ``_parse_atom``.
        - A schema-calculus expression (Phase 3.2): ``S ; T``, ``S >> T``,
          ``S hide (x, y)``, ``S project T``, and combinations.

        Returns an Expr node or SchemaInclusion for Delta/Xi decorated forms.
        Delta/Xi are handled first because they begin with reserved keywords
        that would otherwise stop expression parsing.
        """
        # Delta / Xi decorated reference → SchemaInclusion
        # These are handled before schema-calculus parsing because Delta/Xi
        # are keywords that mark the decorated form; schema-calculus operators
        # cannot apply to a bare Delta/Xi keyword start.
        if self._match(TokenType.DELTA, TokenType.XI):
            start_tok = self._current()
            decoration = "delta" if self._match(TokenType.DELTA) else "xi"
            self._advance()  # Consume Delta / Xi
            if not self._match(TokenType.IDENTIFIER):
                cur = self._current()
                kw = "Delta" if decoration == "delta" else "Xi"
                raise ParserError(
                    f"expected schema name after {kw},"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )
            name_tok = self._advance()
            generics = self._parse_inclusion_generic_args()
            return SchemaInclusion(
                name=name_tok.value,
                decoration=decoration,
                generics=generics,
                line=start_tok.line,
                column=start_tok.column,
            )

        # Schema-calculus expression (possibly just a plain identifier).
        # _parse_schema_pipe is the entry point of the schema-calculus
        # precedence cascade (pipe < compose < hide/project < base expr).
        return self._parse_schema_pipe()

    def _parse_schema_text(self) -> SchemaText:
        r"""Parse an inline schema text: ``[ decl-list | pred-list ]``.

        The bracket has already been detected but NOT consumed when this
        method is called.  Grammar:

            schema_text ::= '[' decl (';' decl)* '|' pred (';' pred)* ']'

        The declaration forms are the same three supported inside schema and
        axdef bodies.  Multiple predicates are separated by ``;``.
        """
        open_tok = self._advance()  # Consume '['

        # --- Declaration section ---
        declarations: list[Declaration | SchemaInclusion] = []

        while not self._at_end() and not self._match(
            TokenType.PIPE, TokenType.RBRACKET
        ):
            if self._match(TokenType.NEWLINE):
                self._advance()
                continue
            if self._match(TokenType.SEMICOLON):
                self._advance()  # Declaration separator
                continue

            # pk has no relation name in inline schema text — reject with clear message.
            if self._match(TokenType.PK):
                raise ParserError(
                    "Primary-key annotation requires a named schema;"
                    " inline schema text is anonymous",
                    self._current(),
                )

            if (
                self._match(TokenType.DELTA, TokenType.XI)
                or self._match(TokenType.IDENTIFIER)
                or self._is_keyword_usable_as_identifier()
            ):
                result = self._parse_declaration_or_inclusion()
                if isinstance(result, list):
                    declarations.extend(result)
                else:
                    declarations.append(result)
            else:
                cur = self._current()
                raise ParserError(
                    f"expected declaration or '|' in inline schema text,"
                    f" got {cur.type.name} ({cur.value!r})",
                    cur,
                )

        # FIX 2: empty declaration list is a syntax error
        if not declarations:
            raise ParserError(
                "inline schema text requires at least one declaration",
                open_tok,
            )

        # --- Predicate separator '|' ---
        if self._at_end():
            raise ParserError(
                "unclosed inline schema text '[' — expected '|' then ']'", open_tok
            )
        if self._match(TokenType.RBRACKET):
            # No predicate section — parse as [ decls ] (no pipe)
            self._advance()  # Consume ']'
            return SchemaText(
                declarations=declarations,
                predicates=[],
                line=open_tok.line,
                column=open_tok.column,
            )

        self._advance()  # Consume '|'

        # --- Predicate section (flat list; ';' and newlines are separators) ---
        predicates: list[Expr] = []

        while not self._at_end() and not self._match(TokenType.RBRACKET):
            if self._match(TokenType.NEWLINE):
                self._advance()
                continue
            if self._match(TokenType.SEMICOLON):
                self._advance()
                continue

            predicates.append(self._parse_expr())

        if not self._match(TokenType.RBRACKET):
            raise ParserError(
                "unclosed inline schema text '[' — expected closing ']'", open_tok
            )
        self._advance()  # Consume ']'

        return SchemaText(
            declarations=declarations,
            predicates=predicates,
            line=open_tok.line,
            column=open_tok.column,
        )

    def _parse_generic_params(self) -> list[str] | None:
        """Parse optional generic parameters: [X, Y, Z].

        Returns None if no generic parameters present.
        """
        if not self._match(TokenType.LBRACKET):
            return None

        self._advance()  # Consume '['
        params: list[str] = []

        # Parse comma-separated list of type parameters
        while not self._match(TokenType.RBRACKET) and not self._at_end():
            if self._match(TokenType.COMMA):
                self._advance()  # Skip comma
                continue

            if not self._match(TokenType.IDENTIFIER):
                raise ParserError(
                    "Expected type parameter name in generic list", self._current()
                )

            params.append(self._current().value)
            self._advance()

        if not self._match(TokenType.RBRACKET):
            raise ParserError(
                "Expected ']' to close generic parameter list", self._current()
            )
        self._advance()  # Consume ']'

        return params if params else None

    def _parse_compound_identifier_name(self) -> str:
        """Parse identifier name that may have postfix operator suffix.

        Handles compound identifiers like R+, R*, R~ used in abbreviations
        and schema names where the postfix operator is part of the name itself,
        not an operation on the identifier.

        Examples:
            R+ == {a, b : N | b > a}  # R+ is the abbreviation name
            R* == R+ o9 R+             # R* is the abbreviation name
            R~ == inv R                # R~ is the abbreviation name

        Returns:
            Compound identifier string (e.g., "R+", "R*", "R~")
        """
        if not self._match(TokenType.IDENTIFIER):
            raise ParserError("Expected identifier", self._current())

        name_token = self._advance()
        name = name_token.value

        # Check for postfix closure operators as part of the name
        # These are valid in definition contexts (not expression contexts)
        if self._match(TokenType.PLUS, TokenType.STAR, TokenType.TILDE):
            op_token = self._advance()
            name = name + op_token.value  # "R" + "+" → "R+"

        return name

    def _parse_abbreviation(self) -> Abbreviation:
        """Parse abbreviation: [X] name == expression or name == expression.

        Supports optional generic parameters.
        """
        start_token = self._current()

        # Check for generic parameters before name
        generic_params = self._parse_generic_params()

        # Parse name (may include postfix operator suffix like R+, R*, R~)
        name_token = self._current()  # Save for line/column info
        name = self._parse_compound_identifier_name()

        if not self._match(TokenType.ABBREV):
            raise ParserError("Expected '==' in abbreviation", self._current())
        self._advance()  # Consume '=='

        # Parse expression in relational context: a top-level abbreviation RHS
        # is an expression, not a Z paragraph body, so a postfix `R[a/b]` is a
        # relational rename (RelationRename → inline math) rather than a
        # schema rename (SchemaRename, which fuzz rejects when emitted with a
        # `/` inside a Z paragraph).
        prev_relational = self._in_relational_context
        self._in_relational_context = True
        try:
            expr = self._parse_expr()
        finally:
            self._in_relational_context = prev_relational

        return Abbreviation(
            name=name,
            expression=expr,
            generic_params=generic_params,
            line=start_token.line if generic_params else name_token.line,
            column=start_token.column if generic_params else name_token.column,
        )

    def _parse_axdef(self) -> AxDef:
        """Parse axiomatic definition block.

        Syntax: axdef [X, Y] ... end
        Supports optional generic parameters and semicolon-separated declarations.
        Comma-separated variable lists share a type: var1, var2 : Type.
        Schema inclusions (bare, Delta, Xi) are also permitted.
        """
        start_token = self._advance()  # Consume 'axdef'
        self._skip_newlines()

        # Check for generic parameters after 'axdef'
        generic_params = self._parse_generic_params()
        self._skip_newlines()

        declarations: list[Declaration | SchemaInclusion] = []

        # Parse declarations until 'where' or 'end'
        while not self._at_end() and not self._match(TokenType.WHERE, TokenType.END):
            if self._match(TokenType.NEWLINE):
                self._advance()
                continue

            # pk is only valid in schema bodies — reject it here with a clear message.
            if self._match(TokenType.PK):
                raise ParserError(
                    "Primary-key annotation is only valid in schema bodies,"
                    " not inside axdef",
                    self._current(),
                )

            # Three forms: Delta/Xi inclusion, bare inclusion, typed decl.
            if (
                self._match(TokenType.DELTA, TokenType.XI)
                or self._match(TokenType.IDENTIFIER)
                or self._is_keyword_usable_as_identifier()
            ):
                result = self._parse_declaration_or_inclusion()
                if isinstance(result, list):
                    declarations.extend(result)
                else:
                    declarations.append(result)

                # Semicolons are only valid after typed declarations.
                if self._match(TokenType.SEMICOLON):
                    self._advance()  # Consume ';'
                    self._skip_newlines()
                else:
                    self._skip_newlines()
            else:
                break

        # Parse 'where' clause (optional)
        predicate_groups: list[list[Expr]] = []  # Default: no groups
        if self._match(TokenType.WHERE):
            self._advance()  # Consume 'where'
            self._skip_newlines()

            # Parse predicates grouped by blank lines
            predicate_groups = self._parse_predicate_groups((TokenType.END,))

        # Expect 'end'
        if not self._match(TokenType.END):
            raise ParserError("Expected 'end' to close axdef block", self._current())
        self._advance()  # Consume 'end'

        return AxDef(
            declarations=declarations,
            predicates=predicate_groups,
            generic_params=generic_params,
            line=start_token.line,
            column=start_token.column,
        )

    def _parse_gendef(self) -> GenDef:
        """Parse generic definition block.

        Generic definitions require generic parameters.
        Syntax: gendef [X, Y] ... end
        Supports semicolon-separated declarations: f : X -> Y; g : X -> Y
        """
        start_token = self._advance()  # Consume 'gendef'
        self._skip_newlines()

        # Generic parameters are REQUIRED for gendef
        generic_params = self._parse_generic_params()
        if not generic_params:
            raise ParserError(
                "Generic parameters required for gendef (e.g., gendef [X, Y])",
                self._current(),
            )
        self._skip_newlines()

        declarations: list[Declaration | SchemaInclusion] = []

        # Parse declarations until 'where' or 'end'
        while not self._at_end() and not self._match(TokenType.WHERE, TokenType.END):
            if self._match(TokenType.NEWLINE):
                self._advance()
                continue

            # pk is only valid in schema bodies — reject it here with a clear message.
            if self._match(TokenType.PK):
                raise ParserError(
                    "Primary-key annotation is only valid in schema bodies,"
                    " not inside gendef",
                    self._current(),
                )

            # Three forms: Delta/Xi inclusion, bare inclusion, typed declaration.
            if (
                self._match(TokenType.DELTA, TokenType.XI)
                or self._match(TokenType.IDENTIFIER)
                or self._is_keyword_usable_as_identifier()
            ):
                result = self._parse_declaration_or_inclusion()
                if isinstance(result, list):
                    declarations.extend(result)
                else:
                    declarations.append(result)

                if self._match(TokenType.SEMICOLON):
                    self._advance()  # Consume ';'
                    self._skip_newlines()
                else:
                    self._skip_newlines()
            else:
                break

        # Parse 'where' clause (optional)
        predicate_groups: list[list[Expr]] = []  # Default: no groups
        if self._match(TokenType.WHERE):
            self._advance()  # Consume 'where'
            self._skip_newlines()

            # Parse predicates grouped by blank lines
            predicate_groups = self._parse_predicate_groups((TokenType.END,))

        # Expect 'end'
        if not self._match(TokenType.END):
            raise ParserError("Expected 'end' to close gendef block", self._current())
        self._advance()  # Consume 'end'

        return GenDef(
            generic_params=generic_params,
            declarations=declarations,
            predicates=predicate_groups,
            line=start_token.line,
            column=start_token.column,
        )

    def _parse_zed(self) -> Zed:
        """Parse zed block for Z notation constructs.

        Zed blocks contain unboxed Z notation paragraphs (\\begin{zed}...\\end{zed}).
        Syntax: zed <content> end

        The content can be:
        - Given types: given A, B, C
        - Free types: Type ::= branch1 | branch2
        - Abbreviations: Name == expression
        - Predicates: forall x : N | x >= 0

        Multiple constructs can appear in one zed block (mixed content).
        Single predicates are parsed as expressions (backward compatible).
        """
        start_token = self._advance()  # Consume 'zed'
        self._skip_newlines()

        items: list[DocumentItem] = []

        # Parse multiple statements until 'end'
        while not self._at_end() and not self._match(TokenType.END):
            if self._match(TokenType.NEWLINE):
                self._advance()
                continue

            # Check for given types
            if self._match(TokenType.GIVEN):
                items.append(self._parse_given_type())
                self._skip_newlines()
                continue

            # Check for abbreviations with generic parameters [X] Name == ...
            if self._match(TokenType.LBRACKET):
                items.append(self._parse_abbreviation())
                self._skip_newlines()
                continue

            # Check for free types or abbreviations (both start with IDENTIFIER)
            if self._match(TokenType.IDENTIFIER):
                # Save position to potentially backtrack
                saved_pos = self.pos

                # Try to parse as compound identifier (handles R, R+, R*, R~, etc.)
                try:
                    _ = self._parse_compound_identifier_name()

                    # Check what follows the identifier
                    if self._match(TokenType.FREE_TYPE):
                        # It's a free type, backtrack and parse properly
                        self.pos = saved_pos
                        items.append(self._parse_free_type())
                    elif self._match(TokenType.ABBREV):
                        # It's an abbreviation, backtrack and parse properly
                        self.pos = saved_pos
                        items.append(self._parse_abbreviation())
                    else:
                        # Not a recognized Z notation construct, backtrack and
                        # parse as expression
                        self.pos = saved_pos
                        items.append(self._parse_expr())
                except ParserError:
                    # Failed to parse compound identifier, backtrack and
                    # parse as expression
                    self.pos = saved_pos
                    items.append(self._parse_expr())

                self._skip_newlines()
                continue

            # Otherwise, parse as expression (predicate)
            items.append(self._parse_expr())
            self._skip_newlines()
            break  # Single expression mode (backward compatible)

        # Expect 'end'
        if not self._match(TokenType.END):
            raise ParserError("Expected 'end' to close zed block", self._current())
        self._advance()  # Consume 'end'

        # If single item and it's an expression, return Zed(content=expr)
        # for backward compatibility. Otherwise, wrap in Document
        if len(items) == 1 and isinstance(items[0], Expr):
            return Zed(
                content=items[0],
                line=start_token.line,
                column=start_token.column,
            )
        # Multiple items or non-expression items - wrap in Document
        doc = Document(
            items=items,
            line=start_token.line,
            column=start_token.column,
        )
        return Zed(
            content=doc,
            line=start_token.line,
            column=start_token.column,
        )

    def _parse_schema(self) -> Schema:
        """Parse schema definition block.

        Syntax:
            schema Name[X, Y] ... end (named with generics)
            schema Name ... end (named)
            schema ... end (anonymous)

        Supports optional generic parameters and semicolon-separated declarations.
        """
        start_token = self._advance()  # Consume 'schema'

        # Parse optional schema name
        # Note: May include postfix operator suffix like S+, S*, S~
        # (partial support, GitHub #3 open)
        name: str | None = None
        generic_params: list[str] | None = None

        if self._match(TokenType.IDENTIFIER):
            name = self._parse_compound_identifier_name()
            # Check for generic parameters after name
            generic_params = self._parse_generic_params()

        self._skip_newlines()

        declarations: list[Declaration | SchemaInclusion] = []

        # Parse declarations until 'where' or 'end'
        while not self._at_end() and not self._match(TokenType.WHERE, TokenType.END):
            if self._match(TokenType.NEWLINE):
                self._advance()
                continue

            # pk requires a named schema — reject it in anonymous schemas.
            if self._match(TokenType.PK) and name is None:
                raise ParserError(
                    "Primary-key annotation requires a named schema;"
                    " anonymous schemas have no relation name for PK notation",
                    self._current(),
                )

            # Four forms: pk prefix (named schemas only), Delta/Xi inclusion,
            # bare inclusion, typed declaration.
            if (
                self._match(TokenType.PK)
                or self._match(TokenType.DELTA, TokenType.XI)
                or self._match(TokenType.IDENTIFIER)
                or self._is_keyword_usable_as_identifier()
            ):
                result = self._parse_declaration_or_inclusion()
                if isinstance(result, list):
                    declarations.extend(result)
                else:
                    declarations.append(result)

                if self._match(TokenType.SEMICOLON):
                    self._advance()  # Consume ';'
                    self._skip_newlines()
                else:
                    self._skip_newlines()
            else:
                break

        # Parse 'where' clause (optional)
        predicate_groups: list[list[Expr]] = []  # Default: no groups
        if self._match(TokenType.WHERE):
            self._advance()  # Consume 'where'
            self._skip_newlines()

            # Parse predicates grouped by blank lines
            predicate_groups = self._parse_predicate_groups((TokenType.END,))

        # Expect 'end'
        if not self._match(TokenType.END):
            raise ParserError("Expected 'end' to close schema block", self._current())
        self._advance()  # Consume 'end'

        return Schema(
            name=name,
            declarations=declarations,
            predicates=predicate_groups,
            generic_params=generic_params,
            line=start_token.line,
            column=start_token.column,
        )

    def _parse_proof_tree(self) -> ProofTree:
        """Parse proof tree with Path C syntax (conclusion with supporting proof).

        Supports top-level CASE analysis where proof starts with cases.
        """
        start_token = self._advance()  # Consume 'PROOF:'
        self._skip_newlines()

        if self._at_end() or self._is_structural_token():
            raise ParserError("Expected proof node after PROOF:", self._current())

        # Check if first item is a case keyword (top-level case analysis)
        if self._match(TokenType.IDENTIFIER) and self._current().value == "case":
            # Parse all top-level cases
            cases: list[CaseAnalysis] = []

            while (
                not self._at_end()
                and not self._is_structural_token()
                and self._match(TokenType.IDENTIFIER)
                and self._current().value == "case"
            ):
                case_analysis = self._parse_case_analysis(
                    base_indent=0, parent_indent=None
                )
                cases.append(case_analysis)
                self._skip_newlines()

            # Check if there's a final conclusion after the cases
            final_conclusion_expr: Expr | None = None
            final_justification: str | None = None

            if not self._at_end() and not self._is_structural_token():
                # Parse potential final conclusion (e.g., "q [or elim]")
                final_conclusion_node = self._parse_proof_node(
                    base_indent=0, parent_indent=None
                )
                final_conclusion_expr = final_conclusion_node.expression
                final_justification = final_conclusion_node.justification

            # Create synthetic conclusion node to wrap the cases
            # Use the final conclusion if present, otherwise placeholder
            if final_conclusion_expr is None:
                final_conclusion_expr = Identifier(
                    name="[case_analysis]",
                    line=start_token.line,
                    column=start_token.column,
                )
                final_justification = "case analysis"

            # Type hint for children: explicitly cast to expected union type
            children_list: list[ProofNode | CaseAnalysis] = list(cases)

            conclusion = ProofNode(
                expression=final_conclusion_expr,
                justification=final_justification,
                label=None,
                is_assumption=False,
                is_sibling=False,
                children=children_list,
                indent_level=0,
                line=start_token.line,
                column=start_token.column,
            )
        else:
            # Standard proof: parse the conclusion node
            conclusion = self._parse_proof_node(base_indent=0, parent_indent=None)

        return ProofTree(
            conclusion=conclusion, line=start_token.line, column=start_token.column
        )

    def _parse_proof_node(
        self, base_indent: int, parent_indent: int | None
    ) -> ProofNode:
        """Parse a single proof node with Path C syntax."""
        if self._at_end() or self._is_structural_token():
            raise ParserError("Expected proof node", self._current())

        line_token = self._current()
        current_indent = line_token.column

        # If we've dedented past the parent level, stop
        if parent_indent is not None and current_indent <= parent_indent:
            raise ParserError("Unexpected dedent in proof tree", self._current())

        # Check for assumption label [1], [2], etc.
        label: int | None = None
        if self._match(TokenType.LBRACKET):
            self._advance()  # Consume '['
            if self._match(TokenType.NUMBER):
                label = int(self._current().value)
                self._advance()
                if not self._match(TokenType.RBRACKET):
                    raise ParserError(
                        "Expected ']' after assumption label", self._current()
                    )
                self._advance()  # Consume ']'
            else:
                # Not a label, must be justification - back up by recreating the bracket
                # Actually, we can't back up easily. Let's handle this differently.
                # For now, assume [number] is always a label at the start of a line.
                raise ParserError(
                    "Expected number in assumption label", self._current()
                )

        # Check for sibling marker ::
        is_sibling = False
        if self._match(TokenType.DOUBLE_COLON):
            is_sibling = True
            self._advance()  # Consume '::'

        # Check for ellipsis ... (steps omitted in proof)
        if self._match(TokenType.ELLIPSIS):
            ellipsis_token = self._advance()
            # Create a text node representing omitted steps
            expr: Expr = Identifier(
                name="...",
                line=ellipsis_token.line,
                column=ellipsis_token.column,
            )
        else:
            # Parse the expression
            expr = self._parse_expr()

        # Check for justification [rule name]
        justification: str | None = None
        is_assumption = False
        if self._match(TokenType.LBRACKET):
            self._advance()  # Consume '['

            # Collect justification text
            just_parts: list[str] = []
            while not self._match(TokenType.RBRACKET) and not self._at_end():
                if self._match(TokenType.NEWLINE):
                    break
                just_parts.append(self._current().value)
                self._advance()

            if self._match(TokenType.RBRACKET):
                self._advance()  # Consume ']'
                # Join tokens smartly: add spaces only between consecutive identifiers
                justification = self._smart_join_justification(just_parts)
                # Check if this is the [assumption] keyword
                if justification == "assumption":
                    is_assumption = True

        self._skip_newlines()

        # Parse children (nodes indented more than current)
        children: list[ProofNode | CaseAnalysis] = []
        while not self._at_end() and not self._is_structural_token():
            if self._match(TokenType.NEWLINE):
                self._skip_newlines()
                if self._at_end() or self._is_structural_token():
                    break

            next_token = self._current()
            next_indent = next_token.column

            # Check if still indented relative to current node
            if next_indent <= current_indent:
                break

            # Check for case analysis
            if self._match(TokenType.IDENTIFIER) and self._current().value == "case":
                case_analysis = self._parse_case_analysis(
                    base_indent=base_indent, parent_indent=current_indent
                )
                children.append(case_analysis)
            else:
                # Regular proof node
                child = self._parse_proof_node(
                    base_indent=base_indent, parent_indent=current_indent
                )
                children.append(child)

        return ProofNode(
            expression=expr,
            justification=justification,
            label=label,
            is_assumption=is_assumption,
            is_sibling=is_sibling,
            children=children,
            indent_level=current_indent - base_indent,
            line=line_token.line,
            column=line_token.column,
        )

    def _parse_case_analysis(
        self, base_indent: int, parent_indent: int | None
    ) -> CaseAnalysis:
        """Parse case analysis: case name: followed by proof steps.

        parent_indent can be None for top-level cases.
        """
        if not self._match(TokenType.IDENTIFIER) or self._current().value != "case":
            raise ParserError("Expected 'case' keyword", self._current())

        case_token = self._advance()  # Consume 'case'

        # Parse case name - collect all tokens until colon
        case_parts: list[str] = []
        while not self._match(TokenType.COLON) and not self._at_end():
            if self._match(TokenType.NEWLINE):
                raise ParserError("Expected ':' after case name", self._current())
            case_parts.append(self._current().value)
            self._advance()

        if not case_parts:
            raise ParserError("Expected case name after 'case'", self._current())

        case_name = " ".join(case_parts)

        # Expect colon
        if not self._match(TokenType.COLON):
            raise ParserError("Expected ':' after case name", self._current())
        self._advance()  # Consume ':'

        self._skip_newlines()

        # Parse proof steps indented under this case
        steps: list[ProofNode] = []
        case_indent = case_token.column

        while not self._at_end() and not self._is_structural_token():
            if self._match(TokenType.NEWLINE):
                self._skip_newlines()
                if self._at_end() or self._is_structural_token():
                    break

            next_token = self._current()
            next_indent = next_token.column

            # Check if still indented relative to case
            if next_indent <= case_indent:
                break

            # Check if this is another case (sibling case)
            if self._match(TokenType.IDENTIFIER) and self._current().value == "case":
                break  # Stop parsing this case

            # Parse proof node for this case
            step = self._parse_proof_node(
                base_indent=base_indent, parent_indent=case_indent
            )
            steps.append(step)

        return CaseAnalysis(
            case_name=case_name,
            steps=steps,
            line=case_token.line,
            column=case_token.column,
        )
