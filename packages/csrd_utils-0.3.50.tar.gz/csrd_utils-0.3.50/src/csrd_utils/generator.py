"""Service generation helpers backed by bundled cookiecutter templates."""

import os
import shutil
from pathlib import Path
from typing import Any

from cookiecutter.main import cookiecutter

from .resources import templates_path

_WORKSPACE_PYPROJECT_BASE = """\
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "workspace"
version = "0.1.0"
description = "Multi-service workspace"
readme = "README.md"
requires-python = ">=3.12"
license = {text = "MIT"}

dependencies = [
    "fastapi>=0.110",
    "uvicorn[standard]>=0.27",
    "pydantic[email]>=2.5",
    "csrd-versioning>=0.1.0",
    "csrd-lifespan>=0.1.0",
    "csrd-repository>=0.1.0",
    "csrd-context>=0.1.0",
    "httpx>=0.25",
    "celery[redis]>=5.3",
    "redis>=5.0",
    "csrd-logging>=0.1.0",
]

[dependency-groups]
dev = [
    "pytest>=7.4",
    "pytest-asyncio>=0.21",
    "httpx>=0.25",
    "mypy>=1.7",
    "ruff>=0.1",
]

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
pythonpath = ["src"]

[tool.mypy]
python_version = "3.12"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
strict = true

[tool.ruff]
target-version = "py312"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "W", "I", "N", "UP", "BLE", "FBT", "A", "C4", "PIE", "SIM", "RUF"]
ignore = ["E501"]

[tool.ruff.lint.isort]
known-first-party = [""]

[tool.hatch.build.targets.wheel]
packages = ["src"]
"""

_WORKSPACE_README = """\
# Workspace

Generated workspace with one or more microservices.

## Setup

```bash
uv sync
```

## Run tests

From the workspace root, run all tests:

```bash
uv run pytest
```

Run tests for a specific service:

```bash
uv run pytest tests/unit/{service_name}
uv run pytest tests/acceptance/{service_name}
```

> **Note:** Always use `uv run pytest` (not bare `pytest`) to ensure the
> workspace virtualenv and its dependencies (e.g. `pytest-asyncio`) are used.

## Run services

See individual service README files under `src/{service_name}/README.md` for instructions on running each service.

## Docker Compose

Run all services and infrastructure:

```bash
docker compose up --build
```

Check service health:

```bash
./smoke.sh
```
"""


def _build_context(
    *,
    name: str,
    description: str,
    port: int,
    model_name: str,
    model_name_plural: str,
    has_database: bool,
    database: str,
    has_delegates: bool,
    upstreams: str,
    has_workers: bool,
    broker: str,
    has_caching: bool,
    cache_backend: str,
    has_structured_logging: bool,
) -> dict[str, Any]:
    return {
        "service_name": name,
        "service_description": description,
        "port": str(port),
        "model_name": model_name,
        "model_name_plural": model_name_plural,
        "has_database": has_database,
        "database": database,
        "has_delegates": has_delegates,
        "upstreams": upstreams,
        "has_workers": has_workers,
        "broker": broker,
        "has_caching": has_caching,
        "cache_backend": cache_backend,
        "has_structured_logging": has_structured_logging,
    }


def generate_service(
    *,
    name: str,
    output_dir: Path,
    description: str,
    port: int,
    model_name: str,
    model_name_plural: str,
    has_database: bool,
    database: str,
    has_delegates: bool,
    upstreams: str,
    has_workers: bool,
    broker: str,
    has_caching: bool,
    cache_backend: str,
    has_structured_logging: bool,
    overwrite_if_exists: bool,
) -> Path:
    """Generate a service from the bundled cookiecutter-service template."""
    output_root = output_dir.resolve()
    src_dir = output_root / "src"
    src_dir.mkdir(parents=True, exist_ok=True)
    target = src_dir / name.replace("-", "_")

    if target.exists() and any(target.iterdir()) and not overwrite_if_exists:
        raise FileExistsError(
            f"Target directory already exists and is not empty: {target}. Use --force to overwrite."
        )

    if has_delegates and not upstreams.strip():
        raise ValueError("--upstreams is required when --delegates is enabled")

    context = _build_context(
        name=name,
        description=description,
        port=port,
        model_name=model_name,
        model_name_plural=model_name_plural,
        has_database=has_database,
        database=database,
        has_delegates=has_delegates,
        upstreams=upstreams,
        has_workers=has_workers,
        broker=broker,
        has_caching=has_caching,
        cache_backend=cache_backend,
        has_structured_logging=has_structured_logging,
    )

    # Suppress bytecode generation during template rendering.
    old_dontwritebytecode = os.environ.get("PYTHONDONTWRITEBYTECODE")
    try:
        os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
        with templates_path() as template_root:
            template = template_root / "cookiecutter-service"
            generated = cookiecutter(
                str(template),
                no_input=True,
                extra_context=context,
                output_dir=str(src_dir),
                overwrite_if_exists=overwrite_if_exists,
            )
    finally:
        if old_dontwritebytecode is None:
            os.environ.pop("PYTHONDONTWRITEBYTECODE", None)
        else:
            os.environ["PYTHONDONTWRITEBYTECODE"] = old_dontwritebytecode

    # Clean up any __pycache__ that may have been created despite PYTHONDONTWRITEBYTECODE.
    generated_path = Path(generated).resolve()
    for pycache_dir in generated_path.rglob("__pycache__"):
        shutil.rmtree(pycache_dir, ignore_errors=True)

    # Move docker files to workspace root and update Dockerfile
    _move_docker_files_to_workspace_root(generated_path, output_root, name)
    _move_tests_to_workspace_root(generated_path, output_root, name)

    # Ensure workspace root has a pyproject.toml with pytest config.
    _write_workspace_pyproject(output_root)

    # Ensure workspace root has a README with test running instructions.
    _write_workspace_readme(output_root)

    return generated_path


def _move_docker_files_to_workspace_root(
    service_path: Path, workspace_root: Path, service_name: str
) -> None:
    """Move docker-compose.yml and Dockerfile to workspace root, updating paths in Dockerfile."""
    service_name_snake = service_name.replace("-", "_")

    # Move docker-compose.yml to workspace root (create if doesn't exist)
    docker_compose_src = service_path / "docker-compose.yml"
    docker_compose_dst = workspace_root / "docker-compose.yml"
    if docker_compose_src.exists():
        if not docker_compose_dst.exists():
            shutil.copy2(docker_compose_src, docker_compose_dst)
        docker_compose_src.unlink()

    # Move Dockerfile to workspace root as Dockerfile.{service_name}
    dockerfile_src = service_path / "Dockerfile"
    dockerfile_dst = workspace_root / f"Dockerfile.{service_name}"
    if dockerfile_src.exists():
        # Read and update the Dockerfile to account for workspace root context
        dockerfile_content = dockerfile_src.read_text()
        # Keep the package importable as `service_name` at runtime.
        dockerfile_content = dockerfile_content.replace(
            "COPY . /app", f"COPY src/{service_name_snake} /app/{service_name_snake}"
        )
        dockerfile_content = dockerfile_content.replace(
            "-r /app/requirements.txt", f"-r /app/{service_name_snake}/requirements.txt"
        )
        dockerfile_dst.write_text(dockerfile_content)
        dockerfile_src.unlink()


def _move_tests_to_workspace_root(
    service_path: Path, workspace_root: Path, service_name: str
) -> None:
    """Move generated tests into workspace-level namespaced suites."""
    service_name_snake = service_name.replace("-", "_")
    tests_src = service_path / "tests"
    if not tests_src.is_dir():
        return

    tests_root = workspace_root / "tests"
    unit_dst = tests_root / "unit" / service_name_snake
    acceptance_dst = tests_root / "acceptance" / service_name_snake
    unit_dst.mkdir(parents=True, exist_ok=True)
    acceptance_dst.mkdir(parents=True, exist_ok=True)

    def _copy_tree(src_dir: Path, dst_dir: Path) -> None:
        if not src_dir.is_dir():
            return
        for src_file in src_dir.rglob("*"):
            if src_file.is_file():
                rel = src_file.relative_to(src_dir)
                dst_file = dst_dir / rel
                dst_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_file, dst_file)

    _copy_tree(tests_src / "unit", unit_dst)
    _copy_tree(tests_src / "acceptance", acceptance_dst)

    # Service-level API tests belong under acceptance for workspace execution.
    top_level_acceptance = ["test_items.py", "conftest.py"]
    for filename in top_level_acceptance:
        src_file = tests_src / filename
        if src_file.is_file():
            shutil.copy2(src_file, acceptance_dst / filename)

    shutil.rmtree(tests_src, ignore_errors=True)


def _write_workspace_pyproject(workspace_root: Path) -> None:
    """Write workspace-level pyproject.toml with full build/project/tool configuration.

    Creates complete pyproject.toml on first generation. On subsequent generations,
    only writes if the file doesn't exist or lacks [project] section (user customization).
    """
    dst = workspace_root / "pyproject.toml"
    if dst.exists():
        existing = dst.read_text(encoding="utf-8")
        # If user already has a [project] section, assume they customized it
        if "[project]" in existing:
            return
        # Otherwise write the full base config
        dst.write_text(_WORKSPACE_PYPROJECT_BASE, encoding="utf-8")
    else:
        dst.write_text(_WORKSPACE_PYPROJECT_BASE, encoding="utf-8")


def _write_workspace_readme(workspace_root: Path) -> None:
    """Write workspace-level README.md with test running and setup instructions.

    If the file does not exist it is created from scratch.  If it already exists
    it is left untouched (the user may have customised it).
    """
    dst = workspace_root / "README.md"
    if not dst.exists():
        dst.write_text(_WORKSPACE_README, encoding="utf-8")
