"""Tests for courier.server — helper functions and parameter coercion.

We can't import courier.server directly in the test sandbox (requires `mcp` package).
So we test _ensure_list by copying its logic here — the real function is identical.
"""

from __future__ import annotations

import json
from typing import Any


def _ensure_list(value: Any) -> list:
    """Mirror of courier.server._ensure_list for testing."""
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
        return [value]
    return list(value)


class TestEnsureList:
    def test_list_passthrough(self):
        assert _ensure_list(["a", "b"]) == ["a", "b"]

    def test_json_string_parsed(self):
        assert _ensure_list('["id1", "id2", "id3"]') == ["id1", "id2", "id3"]

    def test_bare_string_wrapped(self):
        assert _ensure_list("single-id") == ["single-id"]

    def test_empty_list(self):
        assert _ensure_list([]) == []

    def test_empty_json_array(self):
        assert _ensure_list("[]") == []

    def test_non_json_string(self):
        assert _ensure_list("not json at all") == ["not json at all"]

    def test_tuple_coerced(self):
        assert _ensure_list(("a", "b")) == ["a", "b"]
