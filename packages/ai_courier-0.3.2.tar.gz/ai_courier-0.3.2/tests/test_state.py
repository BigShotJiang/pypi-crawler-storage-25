"""Tests for courier.state — SQLite-backed persistent state."""

from __future__ import annotations

import pytest

from courier.state import StateStore


@pytest.fixture
def store(tmp_path) -> StateStore:
    s = StateStore(tmp_path / "test.db")
    yield s
    s.close()


# ── Watermarks ──────────────────────────────────────────────────────────────


class TestWatermarks:
    def test_get_nonexistent_returns_none(self, store):
        assert store.get_watermark("acct", "inbox") is None

    def test_set_and_get(self, store):
        store.set_watermark("acct", "inbox", "2026-04-13T12:00:00Z", "msg-001")
        wm = store.get_watermark("acct", "inbox")
        assert wm is not None
        assert wm.last_seen_date == "2026-04-13T12:00:00Z"
        assert wm.last_seen_email_id == "msg-001"
        assert wm.account_id == "acct"
        assert wm.mailbox_id == "inbox"

    def test_update_overwrites(self, store):
        store.set_watermark("acct", "inbox", "2026-04-13T12:00:00Z", "msg-001")
        store.set_watermark("acct", "inbox", "2026-04-13T18:00:00Z", "msg-002")
        wm = store.get_watermark("acct", "inbox")
        assert wm.last_seen_date == "2026-04-13T18:00:00Z"
        assert wm.last_seen_email_id == "msg-002"

    def test_separate_mailboxes(self, store):
        store.set_watermark("acct", "inbox", "2026-04-13T12:00:00Z")
        store.set_watermark("acct", "sent", "2026-04-13T14:00:00Z")
        assert store.get_watermark("acct", "inbox").last_seen_date == "2026-04-13T12:00:00Z"
        assert store.get_watermark("acct", "sent").last_seen_date == "2026-04-13T14:00:00Z"

    def test_separate_accounts(self, store):
        store.set_watermark("acct1", "inbox", "2026-04-13T12:00:00Z")
        store.set_watermark("acct2", "inbox", "2026-04-13T14:00:00Z")
        assert store.get_watermark("acct1", "inbox").last_seen_date == "2026-04-13T12:00:00Z"
        assert store.get_watermark("acct2", "inbox").last_seen_date == "2026-04-13T14:00:00Z"


# ── Triage classifications ──────────────────────────────────────────────────


class TestTriageStore:
    def test_classify_and_retrieve(self, store):
        store.classify_email("acct", "msg-001", "urgent", 0.8, "keyword: ASAP")
        result = store.get_classification("acct", "msg-001")
        assert result["classification"] == "urgent"
        assert result["confidence"] == 0.8
        assert result["reason"] == "keyword: ASAP"

    def test_get_nonexistent_returns_none(self, store):
        assert store.get_classification("acct", "nope") is None

    def test_reclassification_updates(self, store):
        store.classify_email("acct", "msg-001", "fyi", 0.5, "no signals")
        store.classify_email("acct", "msg-001", "urgent", 0.9, "updated")
        result = store.get_classification("acct", "msg-001")
        assert result["classification"] == "urgent"

    def test_get_classified_emails_all(self, store):
        store.classify_email("acct", "msg-001", "urgent", 0.8, "r1")
        store.classify_email("acct", "msg-002", "fyi", 0.5, "r2")
        store.classify_email("acct", "msg-003", "urgent", 0.7, "r3")
        all_emails = store.get_classified_emails("acct")
        assert len(all_emails) == 3

    def test_get_classified_emails_filtered(self, store):
        store.classify_email("acct", "msg-001", "urgent", 0.8, "r1")
        store.classify_email("acct", "msg-002", "fyi", 0.5, "r2")
        urgent = store.get_classified_emails("acct", "urgent")
        assert len(urgent) == 1
        assert urgent[0]["email_id"] == "msg-001"


# ── Contact signals ─────────────────────────────────────────────────────────


class TestContactSignals:
    def test_get_nonexistent_returns_none(self, store):
        assert store.get_contact_signal("acct", "nobody@example.com") is None

    def test_increment_received(self, store):
        store.update_contact_signal("acct", "alice@example.com", received=True)
        sig = store.get_contact_signal("acct", "alice@example.com")
        assert sig["total_received"] == 1
        assert sig["total_sent"] == 0

    def test_increment_sent(self, store):
        store.update_contact_signal("acct", "alice@example.com", sent=True)
        sig = store.get_contact_signal("acct", "alice@example.com")
        assert sig["total_sent"] == 1
        assert sig["total_received"] == 0

    def test_multiple_increments(self, store):
        store.update_contact_signal("acct", "alice@example.com", received=True)
        store.update_contact_signal("acct", "alice@example.com", received=True)
        store.update_contact_signal("acct", "alice@example.com", sent=True)
        sig = store.get_contact_signal("acct", "alice@example.com")
        assert sig["total_received"] == 2
        assert sig["total_sent"] == 1

    def test_top_contacts(self, store):
        for i in range(5):
            store.update_contact_signal("acct", f"user{i}@example.com", received=True)
        # Give user3 extra interactions
        for _ in range(10):
            store.update_contact_signal("acct", "user3@example.com", received=True)
        top = store.get_top_contacts("acct", limit=3)
        assert len(top) == 3
        assert top[0]["email_address"] == "user3@example.com"


# ── Session state ───────────────────────────────────────────────────────────


class TestSessionState:
    def test_get_nonexistent_returns_none(self, store):
        assert store.get_state("nope") is None

    def test_set_and_get_string(self, store):
        store.set_state("last_sweep", "2026-04-13T12:00:00Z")
        assert store.get_state("last_sweep") == "2026-04-13T12:00:00Z"

    def test_set_and_get_dict(self, store):
        store.set_state("prefs", {"theme": "dark", "limit": 50})
        assert store.get_state("prefs") == {"theme": "dark", "limit": 50}

    def test_set_and_get_list(self, store):
        store.set_state("tags", ["urgent", "work"])
        assert store.get_state("tags") == ["urgent", "work"]

    def test_overwrite(self, store):
        store.set_state("key", "old")
        store.set_state("key", "new")
        assert store.get_state("key") == "new"
