from __future__ import annotations

from courier.jmap import JMAPClient
from tests.conftest import make_email

# ── Email dataclass new fields (Task 8) ─────────────────────────────

def test_email_has_message_id_field():
    e = make_email(message_id=["<abc@example.com>"])
    assert e.message_id == ["<abc@example.com>"]


def test_email_has_reply_to_field():
    e = make_email(reply_to_addrs=["noreply@example.com"])
    assert e.reply_to_addrs == ["noreply@example.com"]


def test_email_defaults_empty_for_new_fields():
    e = make_email()
    assert e.message_id == []
    assert e.reply_to_addrs == []


# ── _normalize_utcdate regression tests ────────────────────────────

def test_normalize_utcdate_bare_date():
    from courier.jmap import JMAPClient
    assert JMAPClient._normalize_utcdate("2026-04-11") == "2026-04-11T00:00:00Z"


def test_normalize_utcdate_naive_datetime():
    from courier.jmap import JMAPClient
    assert JMAPClient._normalize_utcdate("2026-04-17T18:16:23") == "2026-04-17T18:16:23Z"


def test_normalize_utcdate_already_utcdate():
    from courier.jmap import JMAPClient
    assert JMAPClient._normalize_utcdate("2026-04-17T18:16:23Z") == "2026-04-17T18:16:23Z"


def test_normalize_utcdate_strips_microseconds():
    from courier.jmap import JMAPClient
    assert JMAPClient._normalize_utcdate(
        "2026-04-17T18:16:23.454444Z"
    ) == "2026-04-17T18:16:23Z"


def test_normalize_utcdate_converts_plus_zero_offset():
    from courier.jmap import JMAPClient
    assert JMAPClient._normalize_utcdate(
        "2026-04-17T18:16:23+00:00"
    ) == "2026-04-17T18:16:23Z"


def test_normalize_utcdate_converts_plus_zero_with_microseconds():
    """The exact format datetime.now(timezone.utc).isoformat() produces."""
    from courier.jmap import JMAPClient
    assert JMAPClient._normalize_utcdate(
        "2026-04-17T18:16:23.454444+00:00"
    ) == "2026-04-17T18:16:23Z"


def test_normalize_utcdate_rejects_non_utc_offset():
    from courier.jmap import JMAPClient
    import pytest
    with pytest.raises(ValueError, match="must be UTC"):
        JMAPClient._normalize_utcdate("2026-04-17T18:16:23-05:00")


def test_normalize_utcdate_strips_microseconds_with_z():
    """Z suffix + microseconds — common when a caller appends 'Z' manually."""
    from courier.jmap import JMAPClient
    assert JMAPClient._normalize_utcdate(
        "2026-04-17T18:16:23.454444Z"
    ) == "2026-04-17T18:16:23Z"


def test_normalize_utcdate_space_separator():
    """ISO-8601 allows space as T-separator; fromisoformat accepts it on 3.11+."""
    from courier.jmap import JMAPClient
    assert JMAPClient._normalize_utcdate(
        "2026-04-17 18:16:23"
    ) == "2026-04-17T18:16:23Z"


def test_normalize_utcdate_rejects_empty_string():
    import pytest

    from courier.jmap import JMAPClient
    with pytest.raises(ValueError, match="Invalid ISO-8601"):
        JMAPClient._normalize_utcdate("")


def test_normalize_utcdate_rejects_garbage():
    import pytest

    from courier.jmap import JMAPClient
    with pytest.raises(ValueError, match="Invalid ISO-8601"):
        JMAPClient._normalize_utcdate("not-a-date")


# ── Mailbox path computation (Task 9) ───────────────────────────────

def test_compute_path_for_root_mailbox():
    from courier.jmap import JMAPClient
    mailboxes = [
        {"id": "a", "name": "Inbox", "parentId": None},
    ]
    assert JMAPClient._compute_path("a", mailboxes) == "Inbox"


def test_compute_path_for_nested():
    from courier.jmap import JMAPClient
    mailboxes = [
        {"id": "root", "name": "Clients", "parentId": None},
        {"id": "child", "name": "Guardian", "parentId": "root"},
    ]
    assert JMAPClient._compute_path("child", mailboxes) == "Clients/Guardian"


def test_compute_path_handles_cycle_safely():
    """A mis-configured account with a parent cycle should not infinite-loop."""
    from courier.jmap import JMAPClient
    mailboxes = [
        {"id": "a", "name": "A", "parentId": "b"},
        {"id": "b", "name": "B", "parentId": "a"},
    ]
    # Should return *something* without hanging
    result = JMAPClient._compute_path("a", mailboxes)
    assert "A" in result


# ── Mailbox name/path resolver (Task 10) ────────────────────────────

def test_resolve_mailbox_by_id():
    from courier.jmap import JMAPClient
    mailboxes = [{"id": "abc", "name": "Inbox", "parentId": None}]
    assert JMAPClient._resolve_mailbox("abc", mailboxes) == "abc"


def test_resolve_mailbox_by_path():
    from courier.jmap import JMAPClient
    mailboxes = [
        {"id": "root", "name": "Clients", "parentId": None},
        {"id": "child", "name": "Guardian", "parentId": "root"},
    ]
    assert JMAPClient._resolve_mailbox("Clients/Guardian", mailboxes) == "child"


def test_resolve_mailbox_by_unique_leaf_name():
    from courier.jmap import JMAPClient
    mailboxes = [
        {"id": "a", "name": "Guardian", "parentId": "root"},
        {"id": "root", "name": "Clients", "parentId": None},
    ]
    assert JMAPClient._resolve_mailbox("Guardian", mailboxes) == "a"


def test_resolve_mailbox_ambiguous_name_raises():
    import pytest

    from courier.jmap import JMAPClient
    mailboxes = [
        {"id": "a", "name": "Archive", "parentId": None},
        {"id": "b", "name": "Archive", "parentId": "c"},
        {"id": "c", "name": "Clients", "parentId": None},
    ]
    with pytest.raises(ValueError, match="ambiguous"):
        JMAPClient._resolve_mailbox("Archive", mailboxes)


def test_resolve_mailbox_not_found_raises():
    import pytest

    from courier.jmap import JMAPClient
    mailboxes = [{"id": "a", "name": "Inbox", "parentId": None}]
    with pytest.raises(ValueError, match="not found"):
        JMAPClient._resolve_mailbox("Nonexistent", mailboxes)


# ── Reply-header composition (Task 14) ──────────────────────────────


def test_build_reply_subject_adds_re_prefix():
    original = make_email(subject="Weekly sync")
    headers = JMAPClient._build_reply_headers(original, body="hi", cc=None)
    assert headers["subject"] == "Re: Weekly sync"


def test_build_reply_subject_skips_duplicate_re():
    original = make_email(subject="Re: Weekly sync")
    headers = JMAPClient._build_reply_headers(original, body="hi", cc=None)
    assert headers["subject"] == "Re: Weekly sync"


def test_build_reply_subject_skips_case_insensitive_re():
    original = make_email(subject="re: WEEKLY")
    headers = JMAPClient._build_reply_headers(original, body="hi", cc=None)
    assert headers["subject"] == "re: WEEKLY"


def test_build_reply_in_reply_to_uses_original_message_id():
    original = make_email(message_id=["<orig@example.com>"])
    headers = JMAPClient._build_reply_headers(original, body="hi", cc=None)
    assert headers["in_reply_to"] == "<orig@example.com>"


def test_build_reply_references_chains():
    original = make_email(
        message_id=["<orig@example.com>"],
        references=["<a@example.com>", "<b@example.com>"],
    )
    headers = JMAPClient._build_reply_headers(original, body="hi", cc=None)
    assert headers["references"] == [
        "<a@example.com>", "<b@example.com>", "<orig@example.com>",
    ]


def test_build_reply_references_no_duplicate():
    original = make_email(
        message_id=["<orig@example.com>"],
        references=["<orig@example.com>"],
    )
    headers = JMAPClient._build_reply_headers(original, body="hi", cc=None)
    assert headers["references"] == ["<orig@example.com>"]


def test_build_reply_to_uses_reply_to_if_set():
    original = make_email(
        from_address="sender@example.com",
        reply_to_addrs=["desk@example.com"],
    )
    headers = JMAPClient._build_reply_headers(original, body="hi", cc=None)
    assert headers["to"] == [{"email": "desk@example.com"}]


def test_build_reply_to_falls_back_to_from():
    original = make_email(from_address="sender@example.com", from_name="Sender")
    headers = JMAPClient._build_reply_headers(original, body="hi", cc=None)
    assert headers["to"] == [{"name": "Sender", "email": "sender@example.com"}]


def test_build_reply_include_quote_prepends_attribution():
    original = make_email(
        from_address="sender@example.com",
        from_name="Sender",
        date="2026-04-17T12:00:00Z",
        body_text="Original message body.",
    )
    headers = JMAPClient._build_reply_headers(
        original, body="my reply", cc=None, include_quote=True,
    )
    assert "my reply" in headers["body"]
    assert (
        "On 2026-04-17T12:00:00Z, Sender <sender@example.com> wrote:"
        in headers["body"]
    )
    assert "> Original message body." in headers["body"]
