"""Tests for courier.triage_rules — configurable rule loading and evaluation."""

from __future__ import annotations

import pytest
import yaml

from courier.triage_rules import (
    TriageResult,
    TriageRule,
    TriageRuleset,
    SenderOverride,
    _parse_rules,
    classify_batch,
    classify_email,
    load_rules,
)
from tests.conftest import make_email


class FakeState:
    """Minimal StateStore stand-in for testing contact signals."""

    def __init__(self, known_contacts=None):
        self._known = known_contacts or {}

    def get_contact_signal(self, account_id, address):
        if address in self._known:
            return {"total_sent": self._known[address]}
        return None

    def classify_email(self, *args, **kwargs):
        pass


# ── Loading defaults ───────────────────────────────────────────────


class TestLoadDefaults:
    def test_loads_default_rules(self):
        ruleset = load_rules()
        assert len(ruleset.rules) > 0

    def test_default_has_no_sender_overrides(self):
        ruleset = load_rules()
        assert len(ruleset.sender_overrides) == 0

    def test_default_rules_have_valid_classifications(self):
        from courier.triage_rules import VALID_CLASSIFICATIONS
        ruleset = load_rules()
        for rule in ruleset.rules:
            assert rule.classification in VALID_CLASSIFICATIONS

    def test_all_default_rules_have_names(self):
        ruleset = load_rules()
        for rule in ruleset.rules:
            assert rule.name != "unnamed"


# ── User overrides ─────────────────────────────────────────────────


class TestUserOverrides:
    def test_user_sender_overrides_merge(self, tmp_path):
        defaults = tmp_path / "defaults.yaml"
        user = tmp_path / "user.yaml"

        defaults.write_text(yaml.dump({
            "sender_overrides": {
                "default@test.com": {"classification": "bulk", "reason": "default"},
            },
            "rules": [],
        }))
        user.write_text(yaml.dump({
            "sender_overrides": {
                "vip@company.com": {"classification": "urgent", "reason": "VIP"},
            },
        }))

        ruleset = load_rules(user_path=user, defaults_path=defaults)
        assert "default@test.com" in ruleset.sender_overrides
        assert "vip@company.com" in ruleset.sender_overrides

    def test_user_sender_override_wins_conflict(self, tmp_path):
        defaults = tmp_path / "defaults.yaml"
        user = tmp_path / "user.yaml"

        defaults.write_text(yaml.dump({
            "sender_overrides": {
                "bob@test.com": {"classification": "fyi", "reason": "default"},
            },
            "rules": [],
        }))
        user.write_text(yaml.dump({
            "sender_overrides": {
                "bob@test.com": {"classification": "urgent", "reason": "user override"},
            },
        }))

        ruleset = load_rules(user_path=user, defaults_path=defaults)
        assert ruleset.sender_overrides["bob@test.com"].classification == "urgent"

    def test_user_rules_replace_defaults(self, tmp_path):
        defaults = tmp_path / "defaults.yaml"
        user = tmp_path / "user.yaml"

        defaults.write_text(yaml.dump({
            "sender_overrides": {},
            "rules": [
                {"name": "default-rule", "classification": "fyi"},
            ],
        }))
        user.write_text(yaml.dump({
            "rules": [
                {"name": "custom-rule", "classification": "urgent",
                 "subject_pattern": "\\bfire\\b"},
            ],
        }))

        ruleset = load_rules(user_path=user, defaults_path=defaults)
        assert len(ruleset.rules) == 1
        assert ruleset.rules[0].name == "custom-rule"

    def test_user_no_rules_keeps_defaults(self, tmp_path):
        defaults = tmp_path / "defaults.yaml"
        user = tmp_path / "user.yaml"

        defaults.write_text(yaml.dump({
            "sender_overrides": {},
            "rules": [
                {"name": "default-rule", "classification": "fyi"},
            ],
        }))
        user.write_text(yaml.dump({
            "sender_overrides": {
                "vip@test.com": {"classification": "urgent"},
            },
        }))

        ruleset = load_rules(user_path=user, defaults_path=defaults)
        assert len(ruleset.rules) == 1
        assert ruleset.rules[0].name == "default-rule"

    def test_user_empty_rules_disables_all_rules(self, tmp_path):
        """Explicit `rules: []` in user YAML should disable all rules."""
        defaults = tmp_path / "defaults.yaml"
        user = tmp_path / "user.yaml"

        defaults.write_text(yaml.dump({
            "sender_overrides": {},
            "rules": [
                {"name": "default-rule", "classification": "fyi"},
            ],
        }))
        user.write_text(yaml.dump({
            "rules": [],
        }))

        ruleset = load_rules(user_path=user, defaults_path=defaults)
        assert len(ruleset.rules) == 0

    def test_missing_user_file_uses_defaults_only(self, tmp_path):
        defaults = tmp_path / "defaults.yaml"
        defaults.write_text(yaml.dump({
            "sender_overrides": {},
            "rules": [{"name": "r1", "classification": "bulk"}],
        }))

        ruleset = load_rules(
            user_path=tmp_path / "nonexistent.yaml",
            defaults_path=defaults,
        )
        assert len(ruleset.rules) == 1


# ── Validation ─────────────────────────────────────────────────────


class TestValidation:
    def test_invalid_classification_in_rule_raises(self):
        with pytest.raises(ValueError, match="Invalid classification"):
            _parse_rules({
                "rules": [{"name": "bad", "classification": "super_urgent"}],
                "sender_overrides": {},
            })

    def test_invalid_classification_in_override_raises(self):
        with pytest.raises(ValueError, match="Invalid classification"):
            _parse_rules({
                "rules": [],
                "sender_overrides": {
                    "x@y.com": {"classification": "vip"},
                },
            })

    def test_confidence_string_raises(self):
        with pytest.raises(ValueError, match="Invalid confidence"):
            _parse_rules({
                "rules": [{"name": "bad", "classification": "fyi", "confidence": "high"}],
                "sender_overrides": {},
            })

    def test_confidence_out_of_range_raises(self):
        with pytest.raises(ValueError, match="must be in"):
            _parse_rules({
                "rules": [{"name": "bad", "classification": "fyi", "confidence": 1.5}],
                "sender_overrides": {},
            })

    def test_confidence_negative_raises(self):
        with pytest.raises(ValueError, match="must be in"):
            _parse_rules({
                "rules": [{"name": "bad", "classification": "fyi", "confidence": -0.1}],
                "sender_overrides": {},
            })

    def test_confidence_bool_raises(self):
        with pytest.raises(ValueError, match="Invalid confidence"):
            _parse_rules({
                "rules": [{"name": "bad", "classification": "fyi", "confidence": True}],
                "sender_overrides": {},
            })

    def test_max_size_negative_raises(self):
        with pytest.raises(ValueError, match="Invalid max_size"):
            _parse_rules({
                "rules": [{"name": "bad", "classification": "fyi", "max_size": -100}],
                "sender_overrides": {},
            })

    def test_max_size_string_raises(self):
        with pytest.raises(ValueError, match="Invalid max_size"):
            _parse_rules({
                "rules": [{"name": "bad", "classification": "fyi", "max_size": "big"}],
                "sender_overrides": {},
            })

    def test_contradictory_contact_guards_raises(self):
        with pytest.raises(ValueError, match="both requires_known_contact"):
            _parse_rules({
                "rules": [{
                    "name": "bad", "classification": "fyi",
                    "requires_known_contact": True,
                    "requires_unknown_contact": True,
                }],
                "sender_overrides": {},
            })

    def test_invalid_regex_raises_with_context(self):
        with pytest.raises(ValueError, match="Invalid regex in rule 'bad'"):
            _parse_rules({
                "rules": [{"name": "bad", "classification": "fyi",
                           "from_pattern": "[invalid(regex"}],
                "sender_overrides": {},
            })


# ── Sender override evaluation ─────────────────────────────────────


class TestSenderOverrideEval:
    def test_override_takes_priority(self):
        ruleset = TriageRuleset(
            sender_overrides={
                "ceo@company.com": SenderOverride("ceo@company.com", "urgent", "VIP"),
            },
            rules=[
                TriageRule(name="catch-all", classification="fyi"),
            ],
        )
        e = make_email(from_address="ceo@company.com")
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "urgent"
        assert result.confidence == 1.0

    def test_override_case_insensitive(self):
        ruleset = TriageRuleset(
            sender_overrides={
                "ceo@company.com": SenderOverride("ceo@company.com", "urgent", "VIP"),
            },
            rules=[],
        )
        e = make_email(from_address="CEO@Company.com")
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "urgent"

    def test_always_bulk_override(self):
        ruleset = TriageRuleset(
            sender_overrides={
                "spam@annoying.com": SenderOverride("spam@annoying.com", "bulk", "always bulk"),
            },
            rules=[
                TriageRule(name="urgency", classification="urgent",
                           subject_pattern="\\burgent\\b"),
            ],
        )
        # Even with "urgent" in subject, override wins
        e = make_email(from_address="spam@annoying.com", subject="URGENT: buy now!")
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "bulk"


# ── Rule evaluation ────────────────────────────────────────────────


class TestRuleEvaluation:
    def test_first_match_wins(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="r1", classification="urgent", subject_pattern="\\bhelp\\b"),
            TriageRule(name="r2", classification="fyi", subject_pattern="\\bhelp\\b"),
        ])
        e = make_email(subject="help me please")
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "urgent"

    def test_from_pattern_match(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="noreply", classification="bulk",
                       from_pattern="noreply@"),
        ])
        e = make_email(from_address="noreply@service.com")
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "bulk"

    def test_body_pattern_match(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="question", classification="needs_reply",
                       body_pattern="\\?"),
        ])
        e = make_email(body_text="Are you free?")
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "needs_reply"

    def test_domain_pattern_match(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="linkedin", classification="bulk",
                       domain_pattern="@linkedin\\.com"),
        ])
        e = make_email(from_address="messages@linkedin.com")
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "bulk"

    def test_no_match_returns_fyi(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="noreply", classification="bulk",
                       from_pattern="noreply@"),
        ])
        e = make_email(from_address="friend@real.com", body_text="Hello!")
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "fyi"

    def test_body_only_checks_first_500_chars(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="question", classification="needs_reply",
                       body_pattern="secret_keyword"),
        ])
        body = "x" * 600 + "secret_keyword"
        e = make_email(body_text=body, size=700)
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "fyi"  # Not found in first 500


# ── Guard conditions ───────────────────────────────────────────────


class TestGuards:
    def test_requires_known_contact_blocks_unknown(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="q", classification="needs_reply",
                       body_pattern="\\?", requires_known_contact=True),
        ])
        e = make_email(body_text="Are you free?")
        # No state → unknown → guard blocks
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "fyi"

    def test_requires_known_contact_passes_known(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="q", classification="needs_reply",
                       body_pattern="\\?", requires_known_contact=True),
        ])
        state = FakeState(known_contacts={"alice@example.com": 3})
        e = make_email(body_text="Are you free?")
        result = classify_email(e, ruleset=ruleset, state=state, account_id="test")
        assert result.classification == "needs_reply"

    def test_requires_unknown_contact_blocks_known(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="cold", classification="bulk",
                       subject_pattern="raising capital",
                       requires_unknown_contact=True),
        ])
        state = FakeState(known_contacts={"alice@example.com": 5})
        e = make_email(subject="raising capital for project")
        result = classify_email(e, ruleset=ruleset, state=state, account_id="test")
        assert result.classification == "fyi"  # Falls through

    def test_max_size_blocks_large_email(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="q", classification="needs_reply",
                       body_pattern="\\?", max_size=50000),
        ])
        e = make_email(body_text="Question?", size=100000)
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "fyi"

    def test_requires_thread(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="thread", classification="actionable",
                       requires_thread=True),
        ])
        e_thread = make_email(in_reply_to="<prev@msg.com>")
        e_new = make_email(in_reply_to=None)
        assert classify_email(e_thread, ruleset=ruleset).classification == "actionable"
        assert classify_email(e_new, ruleset=ruleset).classification == "fyi"

    def test_requires_flagged(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="flagged", classification="actionable",
                       requires_flagged=True),
        ])
        e_flagged = make_email(is_flagged=True)
        e_normal = make_email(is_flagged=False)
        assert classify_email(e_flagged, ruleset=ruleset).classification == "actionable"
        assert classify_email(e_normal, ruleset=ruleset).classification == "fyi"

    def test_requires_calendar_invite(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="cal", classification="actionable",
                       requires_calendar_invite=True),
        ])
        e_cal = make_email(has_calendar_invite=True)
        e_normal = make_email(has_calendar_invite=False)
        assert classify_email(e_cal, ruleset=ruleset).classification == "actionable"
        assert classify_email(e_normal, ruleset=ruleset).classification == "fyi"


# ── Reason formatting ──────────────────────────────────────────────


class TestReasonFormatting:
    def test_from_placeholder(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="noreply", classification="bulk",
                       from_pattern="noreply@",
                       reason="sender: {from}"),
        ])
        e = make_email(from_address="noreply@test.com")
        result = classify_email(e, ruleset=ruleset)
        assert "noreply@test.com" in result.reason

    def test_match_placeholder(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="urgent", classification="urgent",
                       subject_pattern="\\b(urgent|asap)\\b",
                       reason="keyword: '{match}'"),
        ])
        e = make_email(subject="This is ASAP")
        result = classify_email(e, ruleset=ruleset)
        assert "ASAP" in result.reason

    def test_subject_short_placeholder(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="cold", classification="bulk",
                       subject_pattern="raising capital",
                       reason="cold: {subject_short}",
                       requires_unknown_contact=True),
        ])
        e = make_email(
            from_address="stranger@x.com",
            subject="Raising capital for my thing",
        )
        result = classify_email(e, ruleset=ruleset)
        assert "Raising capital" in result.reason


# ── Batch classification ───────────────────────────────────────────


class TestBatchClassification:
    def test_batch_groups_correctly(self):
        ruleset = TriageRuleset(rules=[
            TriageRule(name="noreply", classification="bulk",
                       from_pattern="noreply@"),
            TriageRule(name="urgent", classification="urgent",
                       subject_pattern="\\burgent\\b"),
        ])
        emails = [
            make_email(id="1", from_address="noreply@spam.com"),
            make_email(id="2", subject="URGENT help", body_text="No question."),
            make_email(id="3", body_text="Just FYI.", from_address="someone@co.com"),
        ]
        buckets = classify_batch(emails, ruleset=ruleset)
        assert len(buckets["bulk"]) == 1
        assert len(buckets["urgent"]) == 1
        assert len(buckets["fyi"]) == 1

    def test_batch_returns_all_bucket_keys(self):
        ruleset = TriageRuleset(rules=[])
        buckets = classify_batch([], ruleset=ruleset)
        assert set(buckets.keys()) == {"urgent", "needs_reply", "actionable", "fyi", "bulk"}


# ── Integration with default rules ─────────────────────────────────


class TestDefaultRulesIntegration:
    """Run key scenarios against the shipped default_rules.yaml."""

    def test_noreply_is_bulk(self):
        ruleset = load_rules()
        e = make_email(from_address="noreply@service.com")
        assert classify_email(e, ruleset=ruleset).classification == "bulk"

    def test_linkedin_is_bulk(self):
        ruleset = load_rules()
        e = make_email(from_address="messages@linkedin.com")
        assert classify_email(e, ruleset=ruleset).classification == "bulk"

    def test_cold_outreach_unknown_is_bulk(self):
        ruleset = load_rules()
        e = make_email(
            from_address="stranger@startup.io",
            subject="Raising capital for AI startup",
        )
        assert classify_email(e, ruleset=ruleset).classification == "bulk"

    def test_urgency_keyword(self):
        ruleset = load_rules()
        e = make_email(subject="URGENT: need response")
        assert classify_email(e, ruleset=ruleset).classification == "urgent"

    def test_question_known_contact(self):
        ruleset = load_rules()
        state = FakeState(known_contacts={"alice@example.com": 5})
        e = make_email(body_text="Are you available Thursday?")
        result = classify_email(e, ruleset=ruleset, state=state, account_id="test")
        assert result.classification == "needs_reply"

    def test_question_unknown_sender_is_fyi(self):
        ruleset = load_rules()
        e = make_email(
            from_address="stranger@random.com",
            body_text="Are you interested in our product?",
        )
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "fyi"

    def test_calendar_invite(self):
        ruleset = load_rules()
        e = make_email(subject="Invitation: Team Standup",
                       body_text="You have been invited to a meeting.",
                       preview="You have been invited to a meeting.")
        assert classify_email(e, ruleset=ruleset).classification == "actionable"

    def test_flagged_email(self):
        ruleset = load_rules()
        e = make_email(is_flagged=True, body_text="Nothing special.",
                       in_reply_to=None)
        # Need to make sure no other rule catches it first
        e2 = make_email(
            from_address="someone@company.com",
            subject="Misc update",
            body_text="Nothing special.",
            preview="Nothing special.",
            is_flagged=True,
            in_reply_to=None,
        )
        assert classify_email(e2, ruleset=ruleset).classification == "actionable"

    def test_rewardsnetwork_is_bulk(self):
        ruleset = load_rules()
        e = make_email(from_address="skymiles@email.rewardsnetwork.com",
                       subject="Dine Out Tonight",
                       body_text="Earn miles when you dine.",
                       preview="Earn miles when you dine.")
        assert classify_email(e, ruleset=ruleset).classification == "bulk"

    def test_zoom_invite_in_body_is_actionable(self):
        ruleset = load_rules()
        e = make_email(
            from_address="colleague@company.com",
            subject="Walkthrough slides and activities",
            body_text="Join Zoom Meeting\nhttps://zoom.us/j/12345\nMeeting agenda...",
            preview="Join Zoom Meeting",
        )
        assert classify_email(e, ruleset=ruleset).classification == "actionable"

    def test_teams_invite_in_body_is_actionable(self):
        ruleset = load_rules()
        e = make_email(
            from_address="colleague@company.com",
            subject="Presentation meeting",
            body_text="Join: https://teams.microsoft.com/meet/12345\nPasscode...",
            preview="Presentation meeting",
        )
        assert classify_email(e, ruleset=ruleset).classification == "actionable"

    def test_zoom_invite_beats_unknown_sender_question(self):
        """Zoom invite with ? in URL shouldn't be caught by question-unknown-sender."""
        ruleset = load_rules()
        e = make_email(
            from_address="stranger@external.com",
            subject="Meeting walkthrough",
            body_text="Join Zoom Meeting\nhttps://zoom.us/j/12345?pwd=abc\nAgenda...",
            preview="Join Zoom Meeting",
        )
        assert classify_email(e, ruleset=ruleset).classification == "actionable"

    def test_marketing_event_blast_is_bulk(self):
        ruleset = load_rules()
        e = make_email(
            from_address="andy@andystorch.com",
            subject="Reminder - Two Free Sessions This Week",
            body_text="Hey friends, this is a reminder that I'm hosting two free sessions.",
            preview="Hey friends, this is a reminder",
        )
        assert classify_email(e, ruleset=ruleset).classification == "bulk"

    def test_calendar_invite_mime_is_actionable(self):
        """Email with text/calendar MIME part should be actionable regardless of subject."""
        ruleset = load_rules()
        e = make_email(
            from_address="jeannie@example.com",
            subject="Catch up",
            body_text="Looking forward to chatting.",
            preview="Looking forward to chatting.",
            has_calendar_invite=True,
        )
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "actionable"
        assert result.confidence >= 0.9

    def test_calendar_invite_mime_beats_unknown_sender(self):
        """Calendar invite from unknown sender still gets actionable, not fyi."""
        ruleset = load_rules()
        e = make_email(
            from_address="stranger@external.com",
            subject="Quick sync",
            body_text="Join us for a quick sync.",
            preview="Join us for a quick sync.",
            has_calendar_invite=True,
        )
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "actionable"

    def test_calendar_invite_mime_beats_bulk_body(self):
        """Calendar invite should override what would otherwise be bulk."""
        ruleset = load_rules()
        e = make_email(
            from_address="someone@company.com",
            subject="Team meeting",
            body_text="Join us for a free session overview.",
            preview="Join us for a free session overview.",
            has_calendar_invite=True,
        )
        result = classify_email(e, ruleset=ruleset)
        assert result.classification == "actionable"

    def test_no_signals_is_fyi(self):
        ruleset = load_rules()
        e = make_email(
            from_address="someone@company.com",
            subject="FYI: update",
            body_text="Here's the latest.",
            preview="Here's the latest.",
            in_reply_to=None,
            is_flagged=False,
        )
        assert classify_email(e, ruleset=ruleset).classification == "fyi"
