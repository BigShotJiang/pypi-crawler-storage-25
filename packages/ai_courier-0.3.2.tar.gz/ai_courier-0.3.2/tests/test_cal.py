"""Tests for courier.cal — datetime normalization, Event properties, free_busy math."""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import pytest

from courier.cal import CalDAVClient, Event
from courier.config import AccountConfig


# ── Event dataclass ─────────────────────────────────────────────────────────


def make_event(**overrides) -> Event:
    defaults = dict(
        uid="evt-001",
        summary="Test Event",
        start=datetime(2026, 4, 14, 9, 0, tzinfo=timezone.utc),
        end=datetime(2026, 4, 14, 10, 0, tzinfo=timezone.utc),
    )
    defaults.update(overrides)
    return Event(**defaults)


class TestEventProperties:
    def test_duration_minutes(self):
        e = make_event()
        assert e.duration_minutes == 60

    def test_duration_90_min(self):
        e = make_event(end=datetime(2026, 4, 14, 10, 30, tzinfo=timezone.utc))
        assert e.duration_minutes == 90

    def test_is_all_day_true(self):
        e = make_event(
            start=datetime(2026, 4, 14, 0, 0, tzinfo=timezone.utc),
            end=datetime(2026, 4, 15, 0, 0, tzinfo=timezone.utc),
        )
        assert e.is_all_day is True

    def test_is_all_day_false(self):
        e = make_event()
        assert e.is_all_day is False

    def test_summary_dict_basic(self):
        e = make_event()
        d = e.summary_dict()
        assert d["uid"] == "evt-001"
        assert d["summary"] == "Test Event"
        assert d["duration_min"] == 60
        assert "location" not in d  # Empty — omitted

    def test_summary_dict_with_location(self):
        e = make_event(location="Room 42")
        d = e.summary_dict()
        assert d["location"] == "Room 42"

    def test_summary_dict_with_attendees(self):
        e = make_event(attendees=["alice@example.com"])
        d = e.summary_dict()
        assert d["attendees"] == ["alice@example.com"]

    def test_summary_dict_confirmed_status_omitted(self):
        e = make_event(status="CONFIRMED")
        assert "status" not in e.summary_dict()

    def test_summary_dict_tentative_shown(self):
        e = make_event(status="TENTATIVE")
        assert e.summary_dict()["status"] == "TENTATIVE"

    def test_summary_dict_all_day_flag(self):
        e = make_event(
            start=datetime(2026, 4, 14, 0, 0, tzinfo=timezone.utc),
            end=datetime(2026, 4, 15, 0, 0, tzinfo=timezone.utc),
        )
        assert e.summary_dict()["all_day"] is True

    def test_summary_dict_calendar_name(self):
        e = make_event(calendar_name="Hi-Team")
        assert e.summary_dict()["calendar"] == "Hi-Team"


# ── Timezone localization ──────────────────────────────────────────────────


class TestTimezoneLocalization:
    def test_summary_dict_localizes_to_ct(self):
        """UTC event should be localized to Central Time in output."""
        ct = ZoneInfo("America/Chicago")
        e = make_event(
            start=datetime(2026, 4, 14, 18, 0, tzinfo=timezone.utc),  # 1:00 PM CDT
            end=datetime(2026, 4, 14, 19, 0, tzinfo=timezone.utc),    # 2:00 PM CDT
        )
        d = e.summary_dict(local_tz=ct)
        assert "13:00:00-05:00" in d["start"]  # 1:00 PM CDT
        assert "14:00:00-05:00" in d["end"]

    def test_summary_dict_no_tz_stays_utc(self):
        """Without local_tz, output stays UTC."""
        e = make_event(
            start=datetime(2026, 4, 14, 18, 0, tzinfo=timezone.utc),
            end=datetime(2026, 4, 14, 19, 0, tzinfo=timezone.utc),
        )
        d = e.summary_dict()
        assert "+00:00" in d["start"]

    def test_all_day_not_localized(self):
        """All-day events should not be timezone-shifted."""
        ct = ZoneInfo("America/Chicago")
        e = make_event(
            start=datetime(2026, 4, 14, 0, 0, tzinfo=timezone.utc),
            end=datetime(2026, 4, 15, 0, 0, tzinfo=timezone.utc),
        )
        d = e.summary_dict(local_tz=ct)
        # Should still show midnight UTC, not shifted to previous day in CT
        assert "2026-04-14T00:00:00" in d["start"]

    def test_free_busy_localizes_output(self):
        """free_busy should return times in local timezone."""
        ct = ZoneInfo("America/Chicago")
        acct = AccountConfig(account_id="x", provider="fastmail", api_token="x", timezone="America/Chicago")
        c = CalDAVClient(acct)
        c.get_events = lambda start=None, end=None, **kw: []
        start = datetime(2026, 4, 14, 13, 0, tzinfo=timezone.utc)  # 8 AM CDT
        end = datetime(2026, 4, 14, 23, 0, tzinfo=timezone.utc)    # 6 PM CDT
        free = c.free_busy(start=start, end=end)
        assert len(free) == 1
        assert "-05:00" in free[0]["start"]  # CDT offset


# ── _normalize_dt ───────────────────────────────────────────────────────────


class TestNormalizeDt:
    """CalDAVClient._normalize_dt is the timezone workhorse."""

    @pytest.fixture
    def client(self):
        acct = AccountConfig(account_id="x", provider="fastmail", api_token="x")
        return CalDAVClient(acct)

    def test_date_to_midnight_utc(self, client):
        d = date(2026, 4, 14)
        result = client._normalize_dt(d)
        assert result == datetime(2026, 4, 14, 0, 0, tzinfo=timezone.utc)

    def test_naive_datetime_assumes_utc(self, client):
        dt = datetime(2026, 4, 14, 9, 30)
        result = client._normalize_dt(dt)
        assert result.tzinfo == timezone.utc
        assert result.hour == 9

    def test_aware_datetime_converted_to_utc(self, client):
        pst = timezone(timedelta(hours=-7))
        dt = datetime(2026, 4, 14, 9, 0, tzinfo=pst)
        result = client._normalize_dt(dt)
        assert result.tzinfo == timezone.utc
        assert result.hour == 16  # 9 AM PST = 4 PM UTC

    def test_utc_datetime_passthrough(self, client):
        dt = datetime(2026, 4, 14, 12, 0, tzinfo=timezone.utc)
        result = client._normalize_dt(dt)
        assert result == dt

    def test_string_fallback(self, client):
        result = client._normalize_dt("2026-04-14T12:00:00+00:00")
        assert result.hour == 12
        assert result.tzinfo == timezone.utc


# ── free_busy math ──────────────────────────────────────────────────────────


class TestFreeBusy:
    """Test free_busy gap calculation without CalDAV connection.

    We mock get_events to return controlled event lists, then verify
    the gap-finding math.
    """

    @pytest.fixture
    def client(self):
        acct = AccountConfig(account_id="x", provider="fastmail", api_token="x")
        c = CalDAVClient(acct)
        return c

    def _mock_events(self, client, events):
        """Monkey-patch get_events to return fixed list."""
        client.get_events = lambda start=None, end=None, **kw: events

    def test_fully_free_day(self, client):
        self._mock_events(client, [])
        start = datetime(2026, 4, 14, 8, 0, tzinfo=timezone.utc)
        end = datetime(2026, 4, 14, 18, 0, tzinfo=timezone.utc)
        free = client.free_busy(start=start, end=end)
        assert len(free) == 1
        assert free[0]["duration_min"] == 600  # 10 hours

    def test_single_meeting_creates_two_gaps(self, client):
        events = [
            make_event(
                start=datetime(2026, 4, 14, 10, 0, tzinfo=timezone.utc),
                end=datetime(2026, 4, 14, 11, 0, tzinfo=timezone.utc),
            ),
        ]
        self._mock_events(client, events)
        start = datetime(2026, 4, 14, 8, 0, tzinfo=timezone.utc)
        end = datetime(2026, 4, 14, 18, 0, tzinfo=timezone.utc)
        free = client.free_busy(start=start, end=end)
        assert len(free) == 2
        assert free[0]["duration_min"] == 120  # 8-10
        assert free[1]["duration_min"] == 420  # 11-18

    def test_overlapping_meetings_merged(self, client):
        events = [
            make_event(
                start=datetime(2026, 4, 14, 10, 0, tzinfo=timezone.utc),
                end=datetime(2026, 4, 14, 11, 0, tzinfo=timezone.utc),
            ),
            make_event(
                uid="evt-002",
                start=datetime(2026, 4, 14, 10, 30, tzinfo=timezone.utc),
                end=datetime(2026, 4, 14, 12, 0, tzinfo=timezone.utc),
            ),
        ]
        self._mock_events(client, events)
        start = datetime(2026, 4, 14, 8, 0, tzinfo=timezone.utc)
        end = datetime(2026, 4, 14, 18, 0, tzinfo=timezone.utc)
        free = client.free_busy(start=start, end=end)
        assert len(free) == 2
        assert free[0]["duration_min"] == 120  # 8-10
        assert free[1]["duration_min"] == 360  # 12-18

    def test_back_to_back_meetings_no_gap(self, client):
        events = [
            make_event(
                start=datetime(2026, 4, 14, 10, 0, tzinfo=timezone.utc),
                end=datetime(2026, 4, 14, 11, 0, tzinfo=timezone.utc),
            ),
            make_event(
                uid="evt-002",
                start=datetime(2026, 4, 14, 11, 0, tzinfo=timezone.utc),
                end=datetime(2026, 4, 14, 12, 0, tzinfo=timezone.utc),
            ),
        ]
        self._mock_events(client, events)
        start = datetime(2026, 4, 14, 10, 0, tzinfo=timezone.utc)
        end = datetime(2026, 4, 14, 12, 0, tzinfo=timezone.utc)
        free = client.free_busy(start=start, end=end)
        assert len(free) == 0

    def test_all_day_events_ignored(self, client):
        """All-day events don't block time slots."""
        events = [
            make_event(
                start=datetime(2026, 4, 14, 0, 0, tzinfo=timezone.utc),
                end=datetime(2026, 4, 15, 0, 0, tzinfo=timezone.utc),
            ),
        ]
        self._mock_events(client, events)
        start = datetime(2026, 4, 14, 8, 0, tzinfo=timezone.utc)
        end = datetime(2026, 4, 14, 18, 0, tzinfo=timezone.utc)
        free = client.free_busy(start=start, end=end)
        assert len(free) == 1
        assert free[0]["duration_min"] == 600

    def test_slot_minutes_filter(self, client):
        """Gaps smaller than slot_minutes are excluded."""
        events = [
            make_event(
                start=datetime(2026, 4, 14, 10, 0, tzinfo=timezone.utc),
                end=datetime(2026, 4, 14, 10, 15, tzinfo=timezone.utc),
            ),
        ]
        self._mock_events(client, events)
        start = datetime(2026, 4, 14, 10, 0, tzinfo=timezone.utc)
        end = datetime(2026, 4, 14, 10, 30, tzinfo=timezone.utc)
        # 15-min gap between 10:15 and 10:30, slot_minutes=30 — excluded
        free = client.free_busy(start=start, end=end, slot_minutes=30)
        assert len(free) == 0


# ── Event deduplication ──────────────────────────────────────────────────


class TestEventDedup:
    """Test _deduplicate_events logic."""

    def test_identical_uid_deduped(self):
        events = [
            make_event(uid="same-uid", summary="Meeting", calendar_name="Cal1"),
            make_event(uid="same-uid", summary="Meeting", calendar_name="Cal2"),
        ]
        result = CalDAVClient._deduplicate_events(events)
        assert len(result) == 1

    def test_different_uid_kept(self):
        events = [
            make_event(uid="uid-1", summary="Meeting A"),
            make_event(uid="uid-2", summary="Meeting B"),
        ]
        result = CalDAVClient._deduplicate_events(events)
        assert len(result) == 2

    def test_same_uid_different_recurrence_id_kept(self):
        """Recurring event instances with different recurrence_id are distinct."""
        events = [
            make_event(uid="recurring-uid", recurrence_id="20260414T090000Z"),
            make_event(uid="recurring-uid", recurrence_id="20260421T090000Z"),
        ]
        result = CalDAVClient._deduplicate_events(events)
        assert len(result) == 2

    def test_same_uid_same_recurrence_id_deduped(self):
        events = [
            make_event(uid="recurring-uid", recurrence_id="20260414T090000Z",
                       calendar_name="Cal1"),
            make_event(uid="recurring-uid", recurrence_id="20260414T090000Z",
                       calendar_name="Cal2"),
        ]
        result = CalDAVClient._deduplicate_events(events)
        assert len(result) == 1

    def test_no_uid_events_kept(self):
        """Events with empty UID can't be deduped — keep all."""
        events = [
            make_event(uid="", summary="Mystery 1"),
            make_event(uid="", summary="Mystery 2"),
        ]
        result = CalDAVClient._deduplicate_events(events)
        assert len(result) == 2

    def test_first_seen_wins(self):
        """When deduping, the first occurrence is kept."""
        events = [
            make_event(uid="dup-uid", calendar_name="Primary"),
            make_event(uid="dup-uid", calendar_name="Secondary"),
        ]
        result = CalDAVClient._deduplicate_events(events)
        assert result[0].calendar_name == "Primary"

    def test_empty_list(self):
        assert CalDAVClient._deduplicate_events([]) == []


# ── All-day event iCal generation ────────────────────────────────────────


class TestAllDayIcalGeneration:
    """Test that create_event generates proper VALUE=DATE for all-day events.

    We can't test create_event directly (needs CalDAV connection), but we can
    verify the iCal string generation logic by testing the branch conditions.
    """

    def test_date_objects_detected_as_all_day(self):
        """date (not datetime) inputs should trigger all-day path."""
        from datetime import date as dt_date
        start = dt_date(2026, 5, 5)
        end = dt_date(2026, 5, 5)
        # Verify: date, not datetime
        assert isinstance(start, dt_date) and not isinstance(start, datetime)

    def test_same_start_end_date_bumps_dtend(self):
        """When start == end for all-day, DTEND should be start + 1 day."""
        from datetime import date as dt_date
        start = dt_date(2026, 5, 5)
        end = dt_date(2026, 5, 5)
        # Simulate the logic from create_event
        if end <= start:
            end = start + timedelta(days=1)
        assert end == dt_date(2026, 5, 6)

    def test_multi_day_range_preserved(self):
        """Multi-day all-day event preserves the end date."""
        from datetime import date as dt_date
        start = dt_date(2026, 5, 5)
        end = dt_date(2026, 5, 8)
        # end > start, so no bump
        assert end == dt_date(2026, 5, 8)

    def test_value_date_format(self):
        """VALUE=DATE format is YYYYMMDD without time component."""
        from datetime import date as dt_date
        d = dt_date(2026, 5, 5)
        formatted = d.strftime('%Y%m%d')
        assert formatted == "20260505"
        assert "T" not in formatted
