"""Tests for courier.triage — rule-based email classification."""

from __future__ import annotations

import pytest

from courier.triage import (
    ACTIONABLE,
    BULK,
    FYI,
    NEEDS_REPLY,
    URGENT,
    TriageResult,
    classify_batch,
    classify_email,
)
from tests.conftest import make_email


class FakeState:
    """Minimal StateStore stand-in for testing contact signals."""

    def __init__(self, known_contacts=None):
        self._known = known_contacts or {}

    def get_contact_signal(self, account_id, address):
        if address in self._known:
            return {"total_sent": self._known[address]}
        return None

    def classify_email(self, *args, **kwargs):
        pass


# ── Bulk detection ──────────────────────────────────────────────────────────


class TestBulkDetection:
    def test_noreply_sender(self):
        e = make_email(from_address="noreply@service.com")
        assert classify_email(e).classification == BULK

    def test_no_reply_hyphen(self):
        e = make_email(from_address="no-reply@company.com")
        assert classify_email(e).classification == BULK

    def test_notifications_sender(self):
        e = make_email(from_address="notifications@github.com")
        assert classify_email(e).classification == BULK

    def test_newsletter_sender(self):
        e = make_email(from_address="newsletter@substack.com")
        assert classify_email(e).classification == BULK

    def test_marketing_sender(self):
        e = make_email(from_address="marketing@bigcorp.com")
        assert classify_email(e).classification == BULK

    def test_alerts_sender(self):
        e = make_email(from_address="alerts@monitoring.io")
        assert classify_email(e).classification == BULK

    def test_promo_sender(self):
        e = make_email(from_address="promotions@deals.com")
        assert classify_email(e).classification == BULK

    def test_digest_sender(self):
        e = make_email(from_address="digest@weekly.io")
        assert classify_email(e).classification == BULK

    def test_bulk_domain_skymiles(self):
        e = make_email(from_address="offers@skymiles.delta.com")
        assert classify_email(e).classification == BULK

    def test_bulk_domain_linkedin(self):
        e = make_email(from_address="messages@linkedin.com")
        assert classify_email(e).classification == BULK

    def test_cold_outreach_raising_capital(self):
        e = make_email(
            from_address="stranger@startup.io",
            subject="Raising capital for AI startup",
            body_text="Would love to connect.",
        )
        assert classify_email(e).classification == BULK

    def test_cold_outreach_known_contact_not_bulk(self):
        """If we've emailed someone before, their outreach-style subject isn't auto-bulk."""
        e = make_email(
            from_address="friend@known.com",
            subject="Raising capital for our joint project",
            body_text="Quick update.",
        )
        state = FakeState(known_contacts={"friend@known.com": 3})
        result = classify_email(e, state=state, account_id="test")
        assert result.classification != BULK

    def test_normal_sender_not_bulk(self):
        e = make_email(from_address="colleague@company.com", body_text="No signals here.")
        result = classify_email(e)
        assert result.classification != BULK


# ── Urgent detection ────────────────────────────────────────────────────────


class TestUrgentDetection:
    @pytest.mark.parametrize(
        "keyword",
        ["URGENT", "ASAP", "emergency", "critical", "deadline", "by EOD", "time-sensitive", "immediate"],
    )
    def test_urgency_keywords_in_subject(self, keyword):
        e = make_email(subject=f"Need this {keyword}", body_text="Plain body.")
        assert classify_email(e).classification == URGENT

    def test_urgency_in_preview(self):
        e = make_email(preview="This is urgent — need response ASAP", body_text="Details here.")
        assert classify_email(e).classification == URGENT

    def test_bulk_takes_priority_over_urgent(self):
        """Bulk sender check runs first, even if subject has urgency keywords."""
        e = make_email(
            from_address="noreply@spam.com",
            subject="URGENT: Your account",
        )
        assert classify_email(e).classification == BULK


# ── Needs reply detection ───────────────────────────────────────────────────


class TestNeedsReplyDetection:
    def test_question_from_known_contact(self):
        """Known contact asking a question → needs_reply."""
        e = make_email(body_text="Are you available Thursday?")
        state = FakeState(known_contacts={"alice@example.com": 5})
        assert classify_email(e, state=state, account_id="test").classification == NEEDS_REPLY

    def test_can_you_from_known_contact(self):
        e = make_email(body_text="Can you send me the latest deck?")
        state = FakeState(known_contacts={"alice@example.com": 2})
        assert classify_email(e, state=state, account_id="test").classification == NEEDS_REPLY

    def test_let_me_know_from_known_contact(self):
        e = make_email(body_text="Let me know if this works for you.")
        state = FakeState(known_contacts={"alice@example.com": 1})
        assert classify_email(e, state=state, account_id="test").classification == NEEDS_REPLY

    def test_thoughts_in_active_thread(self):
        """Question in an active thread (in_reply_to set) → needs_reply even without state."""
        e = make_email(body_text="Thoughts?", in_reply_to="<prev@example.com>")
        assert classify_email(e).classification == NEEDS_REPLY

    def test_question_from_unknown_sender_is_fyi(self):
        """Unknown sender asking a question → fyi, not needs_reply."""
        e = make_email(
            from_address="stranger@random.com",
            body_text="Are you interested in our product?",
        )
        result = classify_email(e)
        assert result.classification == FYI
        assert "unknown sender" in result.reason

    def test_large_email_not_needs_reply(self):
        """Big emails (newsletters) with questions shouldn't trigger needs_reply."""
        e = make_email(body_text="Can you believe it? " * 5000, size=100000)
        state = FakeState(known_contacts={"alice@example.com": 5})
        assert classify_email(e, state=state, account_id="test").classification != NEEDS_REPLY

    def test_question_only_in_first_500_chars(self):
        """Question pattern only checked in first 500 chars of body."""
        body = "x" * 600 + " Can you help?"
        e = make_email(body_text=body, size=700)
        result = classify_email(e)
        assert result.classification != NEEDS_REPLY


# ── Actionable detection ────────────────────────────────────────────────────


class TestActionableDetection:
    def test_calendar_in_subject(self):
        e = make_email(subject="Invitation: Team Standup", body_text="No questions.")
        assert classify_email(e).classification == ACTIONABLE

    def test_ics_in_subject(self):
        e = make_email(subject="event.ics attached", body_text="See attached.", preview="event.ics attached")
        assert classify_email(e).classification == ACTIONABLE

    def test_in_reply_to_thread(self):
        e = make_email(
            in_reply_to="<msg-prev@example.com>",
            body_text="Got it, thanks.",
            subject="Re: Project update",
        )
        assert classify_email(e).classification == ACTIONABLE

    def test_flagged_email(self):
        e = make_email(is_flagged=True, body_text="Nothing special.")
        assert classify_email(e).classification == ACTIONABLE


# ── FYI fallthrough ─────────────────────────────────────────────────────────


class TestFyiDefault:
    def test_no_signals(self):
        e = make_email(
            from_address="someone@company.com",
            subject="FYI: Team update",
            body_text="Here's the latest.",
            preview="Here's the latest.",
            in_reply_to=None,
            is_flagged=False,
        )
        assert classify_email(e).classification == FYI

    def test_fyi_low_confidence(self):
        e = make_email(body_text="No signals.", in_reply_to=None, is_flagged=False)
        result = classify_email(e)
        assert result.confidence == 0.5


# ── Priority order ──────────────────────────────────────────────────────────


class TestPriorityOrder:
    def test_urgent_beats_needs_reply(self):
        """Email with both urgency and a question → urgent wins."""
        e = make_email(
            subject="URGENT review needed",
            body_text="Can you look at this?",
        )
        assert classify_email(e).classification == URGENT


# ── Batch classification ────────────────────────────────────────────────────


class TestClassifyBatch:
    def test_batch_groups_correctly(self):
        state = FakeState(known_contacts={"alice@example.com": 3})
        emails = [
            make_email(id="1", from_address="noreply@spam.com"),
            make_email(id="2", subject="URGENT help", body_text="No question."),
            make_email(id="3", body_text="Can you help?"),  # alice@example.com is known → needs_reply
            make_email(id="4", body_text="Just FYI.", in_reply_to=None, is_flagged=False,
                       from_address="unknown@other.com"),
        ]
        buckets = classify_batch(emails, state=state, account_id="test")
        assert len(buckets[BULK]) == 1
        assert len(buckets[URGENT]) == 1
        assert len(buckets[NEEDS_REPLY]) == 1
        assert len(buckets[FYI]) == 1

    def test_batch_returns_all_bucket_keys(self):
        buckets = classify_batch([])
        assert set(buckets.keys()) == {URGENT, NEEDS_REPLY, ACTIONABLE, FYI, BULK}

    def test_batch_tuples_contain_email_and_result(self):
        emails = [make_email(id="1", from_address="noreply@x.com")]
        buckets = classify_batch(emails)
        email, result = buckets[BULK][0]
        assert isinstance(result, TriageResult)
        assert email.id == "1"


# ── TriageResult ────────────────────────────────────────────────────────────


class TestTriageResult:
    def test_to_dict(self):
        r = TriageResult(classification=URGENT, confidence=0.8, reason="keyword: 'urgent'")
        d = r.to_dict()
        assert d == {
            "classification": "urgent",
            "confidence": 0.8,
            "reason": "keyword: 'urgent'",
        }
