"""Tests for courier.jmap — date normalization, email parsing, summary."""

from __future__ import annotations

import pytest

from courier.jmap import Attachment, Email, JMAPClient
from tests.conftest import make_email


# ── _normalize_utcdate ──────────────────────────────────────────────────────


class TestNormalizeUtcdate:
    """The bug that broke sent-mail search: bare dates silently fail on Fastmail."""

    def test_bare_date_gets_time_suffix(self):
        assert JMAPClient._normalize_utcdate("2026-04-11") == "2026-04-11T00:00:00Z"

    def test_already_full_utc_unchanged(self):
        assert JMAPClient._normalize_utcdate("2026-04-11T00:00:00Z") == "2026-04-11T00:00:00Z"

    def test_datetime_without_z_gets_z(self):
        assert JMAPClient._normalize_utcdate("2026-04-11T14:30:00") == "2026-04-11T14:30:00Z"

    def test_datetime_with_positive_offset_rejected(self):
        """Non-UTC offsets are rejected — the caller must convert to UTC
        explicitly. Silently shifting the instant would be a fallback."""
        with pytest.raises(ValueError, match="must be UTC"):
            JMAPClient._normalize_utcdate("2026-04-11T14:30:00+05:00")

    def test_datetime_with_negative_offset_rejected(self):
        """Same rule for negative offsets."""
        with pytest.raises(ValueError, match="must be UTC"):
            JMAPClient._normalize_utcdate("2026-04-11T14:30:00-07:00")

    def test_datetime_with_z_unchanged(self):
        val = "2026-04-11T23:59:59Z"
        assert JMAPClient._normalize_utcdate(val) == val


# ── _parse_email ────────────────────────────────────────────────────────────


class TestParseEmail:
    """Verify JMAP raw dict → Email dataclass conversion."""

    SAMPLE_RAW = {
        "id": "msg-123",
        "threadId": "thread-456",
        "mailboxIds": {"inbox-id": True, "label-id": True},
        "from": [{"name": "Jim Perry", "email": "jim@hi-team.net"}],
        "to": [{"name": "Bob", "email": "bob@example.com"}],
        "cc": [{"email": "cc@example.com"}],
        "subject": "Test subject",
        "receivedAt": "2026-04-13T18:42:22Z",
        "preview": "Hey Bob...",
        "textBody": [{"partId": "1"}],
        "bodyValues": {"1": {"value": "Hey Bob, full body here."}},
        "keywords": {"$seen": True, "$flagged": True},
        "hasAttachment": True,
        "inReplyTo": "<prev-msg@example.com>",
        "references": ["<orig@example.com>", "<prev-msg@example.com>"],
        "size": 4500,
    }

    def _parse(self, raw=None):
        """Helper — instantiate a throwaway client just for _parse_email."""
        from courier.config import AccountConfig

        acct = AccountConfig(account_id="x", provider="fastmail", api_token="x")
        client = JMAPClient(acct)
        return client._parse_email(raw or self.SAMPLE_RAW)

    def test_basic_fields(self):
        e = self._parse()
        assert e.id == "msg-123"
        assert e.thread_id == "thread-456"
        assert e.from_address == "jim@hi-team.net"
        assert e.from_name == "Jim Perry"
        assert e.subject == "Test subject"

    def test_mailbox_ids_extracted(self):
        e = self._parse()
        assert set(e.mailbox_ids) == {"inbox-id", "label-id"}

    def test_to_and_cc(self):
        e = self._parse()
        assert e.to == ["bob@example.com"]
        assert e.cc == ["cc@example.com"]

    def test_body_text_assembled(self):
        e = self._parse()
        assert e.body_text == "Hey Bob, full body here."

    def test_keywords_parsed(self):
        e = self._parse()
        assert e.is_unread is False  # $seen = True → not unread
        assert e.is_flagged is True

    def test_unread_when_not_seen(self):
        raw = {**self.SAMPLE_RAW, "keywords": {}}
        e = self._parse(raw)
        assert e.is_unread is True

    def test_in_reply_to_and_references(self):
        e = self._parse()
        assert e.in_reply_to == "<prev-msg@example.com>"
        assert len(e.references) == 2

    def test_empty_from(self):
        raw = {**self.SAMPLE_RAW, "from": []}
        e = self._parse(raw)
        assert e.from_address == ""
        assert e.from_name == ""

    def test_none_to_and_cc(self):
        """JMAP can return null for to/cc fields."""
        raw = {**self.SAMPLE_RAW, "to": None, "cc": None}
        e = self._parse(raw)
        assert e.to == []
        assert e.cc == []


# ── Email.summary() ────────────────────────────────────────────────────────


class TestEmailSummary:
    def test_summary_truncates_body(self):
        e = make_email(body_text="x" * 1000)
        s = e.summary(max_body=100)
        assert len(s["body"]) == 103  # 100 chars + "..."
        assert s["body"].endswith("...")

    def test_summary_no_ellipsis_when_short(self):
        e = make_email(body_text="short")
        s = e.summary()
        assert s["body"] == "short"

    def test_summary_from_format(self):
        e = make_email(from_name="Alice", from_address="alice@example.com")
        s = e.summary()
        assert s["from"] == "Alice <alice@example.com>"

    def test_summary_from_no_name(self):
        e = make_email(from_name="", from_address="alice@example.com")
        s = e.summary()
        assert s["from"] == "alice@example.com"

    def test_summary_keys(self):
        s = make_email().summary()
        expected = {"id", "thread_id", "from", "to", "subject", "date", "body", "unread", "flagged", "has_attachment", "attachments"}
        assert set(s.keys()) == expected


# ── Calendar invite MIME detection ─────────────────────────────────────────


class TestCalendarInviteDetection:
    """Test _has_calendar_part and has_calendar_invite field on parsed emails."""

    def test_has_calendar_part_simple(self):
        structure = {"type": "text/calendar"}
        assert JMAPClient._has_calendar_part(structure) is True

    def test_has_calendar_part_nested(self):
        """Calendar part nested inside multipart/mixed."""
        structure = {
            "type": "multipart/mixed",
            "subParts": [
                {"type": "text/plain"},
                {"type": "text/calendar"},
            ],
        }
        assert JMAPClient._has_calendar_part(structure) is True

    def test_has_calendar_part_deeply_nested(self):
        """Calendar part inside multipart/alternative inside multipart/mixed."""
        structure = {
            "type": "multipart/mixed",
            "subParts": [
                {
                    "type": "multipart/alternative",
                    "subParts": [
                        {"type": "text/plain"},
                        {"type": "text/html"},
                        {"type": "text/calendar"},
                    ],
                },
            ],
        }
        assert JMAPClient._has_calendar_part(structure) is True

    def test_no_calendar_part(self):
        structure = {
            "type": "multipart/mixed",
            "subParts": [
                {"type": "text/plain"},
                {"type": "text/html"},
            ],
        }
        assert JMAPClient._has_calendar_part(structure) is False

    def test_none_structure(self):
        assert JMAPClient._has_calendar_part(None) is False

    def test_empty_structure(self):
        assert JMAPClient._has_calendar_part({}) is False

    def test_parse_email_sets_calendar_flag(self):
        """Full _parse_email pipeline sets has_calendar_invite from bodyStructure."""
        from courier.config import AccountConfig
        acct = AccountConfig(account_id="x", provider="fastmail", api_token="x")
        client = JMAPClient(acct)

        raw = {
            "id": "cal-msg",
            "threadId": "t1",
            "mailboxIds": {"inbox": True},
            "from": [{"name": "Jeannie", "email": "jeannie@example.com"}],
            "to": [{"email": "jim@hi-team.net"}],
            "cc": [],
            "subject": "Catch up",
            "receivedAt": "2026-04-14T12:00:00Z",
            "preview": "Looking forward to chatting.",
            "textBody": [{"partId": "1"}],
            "bodyStructure": {
                "type": "multipart/mixed",
                "subParts": [
                    {"type": "text/plain", "partId": "1"},
                    {"type": "text/calendar", "partId": "2"},
                ],
            },
            "bodyValues": {"1": {"value": "Looking forward to chatting."}},
            "keywords": {},
            "hasAttachment": True,
            "inReplyTo": None,
            "references": [],
            "size": 3000,
        }
        email = client._parse_email(raw)
        assert email.has_calendar_invite is True

    def test_parse_email_no_calendar(self):
        """Normal email without calendar part has False flag."""
        from courier.config import AccountConfig
        acct = AccountConfig(account_id="x", provider="fastmail", api_token="x")
        client = JMAPClient(acct)

        raw = {
            "id": "normal-msg",
            "threadId": "t1",
            "mailboxIds": {"inbox": True},
            "from": [{"name": "Alice", "email": "alice@example.com"}],
            "to": [{"email": "jim@hi-team.net"}],
            "cc": [],
            "subject": "Hello",
            "receivedAt": "2026-04-14T12:00:00Z",
            "preview": "Just checking in.",
            "textBody": [{"partId": "1"}],
            "bodyStructure": {"type": "text/plain", "partId": "1"},
            "bodyValues": {"1": {"value": "Just checking in."}},
            "keywords": {},
            "hasAttachment": False,
            "inReplyTo": None,
            "references": [],
            "size": 1500,
        }
        email = client._parse_email(raw)
        assert email.has_calendar_invite is False


# ── Attachment extraction ────────────────────────────────────────────────────


class TestExtractAttachments:
    """Walk bodyStructure and collect Attachment objects."""

    def test_empty_structure_returns_empty(self):
        assert JMAPClient._extract_attachments(None) == []
        assert JMAPClient._extract_attachments({}) == []

    def test_plain_text_no_attachments(self):
        structure = {"type": "text", "subtype": "plain", "partId": "1", "blobId": "B1"}
        result = JMAPClient._extract_attachments(structure, {"1"})
        assert result == []

    def test_pdf_attachment_detected(self):
        structure = {
            "type": "multipart",
            "subtype": "mixed",
            "subParts": [
                {"type": "text", "subtype": "plain", "partId": "1", "blobId": "B1"},
                {
                    "type": "application", "subtype": "pdf",
                    "partId": "2", "blobId": "B2",
                    "name": "doc.pdf", "size": 12345,
                    "disposition": "attachment",
                },
            ],
        }
        result = JMAPClient._extract_attachments(structure, {"1"})
        assert len(result) == 1
        assert result[0].name == "doc.pdf"
        assert result[0].type == "application/pdf"
        assert result[0].blob_id == "B2"
        assert result[0].size == 12345
        assert result[0].disposition == "attachment"

    def test_inline_image_with_name_is_attachment(self):
        structure = {
            "type": "multipart", "subtype": "related",
            "subParts": [
                {"type": "text", "subtype": "html", "partId": "1", "blobId": "BH"},
                {
                    "type": "image", "subtype": "png",
                    "partId": "2", "blobId": "BI",
                    "name": "logo.png", "size": 500,
                    "disposition": "inline", "cid": "logo@example.com",
                },
            ],
        }
        result = JMAPClient._extract_attachments(structure, {"1"})
        assert len(result) == 1
        assert result[0].cid == "logo@example.com"
        assert result[0].disposition == "inline"

    def test_body_parts_excluded(self):
        """textBody / htmlBody parts must NOT appear as attachments."""
        structure = {
            "type": "multipart", "subtype": "alternative",
            "subParts": [
                {"type": "text", "subtype": "plain", "partId": "1", "blobId": "B1"},
                {"type": "text", "subtype": "html", "partId": "2", "blobId": "B2"},
            ],
        }
        result = JMAPClient._extract_attachments(structure, {"1", "2"})
        assert result == []

    def test_multiple_attachments(self):
        structure = {
            "type": "multipart", "subtype": "mixed",
            "subParts": [
                {"type": "text", "subtype": "plain", "partId": "1", "blobId": "B1"},
                {"type": "application", "subtype": "pdf",
                 "partId": "2", "blobId": "B2", "name": "a.pdf",
                 "disposition": "attachment", "size": 100},
                {"type": "image", "subtype": "jpeg",
                 "partId": "3", "blobId": "B3", "name": "b.jpg",
                 "disposition": "attachment", "size": 200},
            ],
        }
        result = JMAPClient._extract_attachments(structure, {"1"})
        assert len(result) == 2
        assert {a.name for a in result} == {"a.pdf", "b.jpg"}

    def test_calendar_invite_without_name_detected(self):
        """text/calendar parts in meeting invites often lack filename/disposition."""
        structure = {
            "type": "multipart", "subtype": "alternative",
            "subParts": [
                {"type": "text", "subtype": "plain", "partId": "1", "blobId": "BT"},
                {"type": "text", "subtype": "html", "partId": "2", "blobId": "BH"},
                {"type": "text", "subtype": "calendar", "partId": "3",
                 "blobId": "BC", "size": 2048},
            ],
        }
        result = JMAPClient._extract_attachments(structure, {"1", "2"})
        assert len(result) == 1
        assert result[0].type == "text/calendar"

    def test_leaf_without_blobid_skipped(self):
        structure = {
            "type": "multipart", "subtype": "mixed",
            "subParts": [
                {"type": "application", "subtype": "pdf", "name": "ghost.pdf"},
            ],
        }
        result = JMAPClient._extract_attachments(structure, set())
        assert result == []


class TestAttachmentSummary:
    def test_summary_dict_fields(self):
        a = Attachment(
            blob_id="B1", name="report.pdf",
            type="application/pdf", size=2048,
            part_id="2", disposition="attachment",
        )
        d = a.summary_dict()
        assert d == {
            "blob_id": "B1", "name": "report.pdf",
            "type": "application/pdf", "size": 2048,
            "disposition": "attachment",
        }
