"""v0.2 regression — calendar read + create, including all-day VALUE=DATE.

Third of three tests that validate the v0.2 "stale vault note" claims.
Specifically disproves 'Courier breaks all-day events' by verifying
VALUE=DATE is present in the generated iCal per RFC 5545 §3.6.1.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone


def _sandbox_calendar_obj(live_caldav, sandbox_calendar):
    """Return the underlying caldav.Calendar for the sandbox dict.

    sandbox_calendar fixture returns a dict; for event creation and
    teardown we need the real Calendar object. This helper does the
    cross-reference by URL.
    """
    target_url = sandbox_calendar["url"]
    for cal in live_caldav._calendars:
        if str(cal.url).rstrip("/") == target_url.rstrip("/"):
            return cal
    raise RuntimeError(
        f"Sandbox calendar at {target_url!r} not found among "
        f"{[str(c.url) for c in live_caldav._calendars]}"
    )


def _tomorrow() -> datetime:
    return datetime.now(timezone.utc).replace(
        hour=0, minute=0, second=0, microsecond=0,
    ) + timedelta(days=1)


def test_today_and_week_return_list(live_caldav):
    today = live_caldav.get_today()
    week = live_caldav.get_week()
    assert isinstance(today, list)
    assert isinstance(week, list)


def test_create_timed_event_in_sandbox(live_caldav, sandbox_calendar):
    start = _tomorrow() + timedelta(hours=9)
    end = start + timedelta(hours=1)
    event = live_caldav.create_event(
        summary="[courier-e2e] timed",
        start=start,
        end=end,
        calendar_name="Courier Tests",
    )
    try:
        assert event.summary == "[courier-e2e] timed"
        assert event.duration_minutes == 60
    finally:
        cal_obj = _sandbox_calendar_obj(live_caldav, sandbox_calendar)
        try:
            cal_obj.event_by_url(event.raw_url).delete()
        except Exception:
            pass  # Cleanup-only — don't mask test failure


def test_create_all_day_event_uses_value_date(live_caldav, sandbox_calendar):
    """All-day events must emit VALUE=DATE per RFC 5545 §3.6.1."""
    start = date.today() + timedelta(days=1)
    end = start + timedelta(days=1)
    event = live_caldav.create_event(
        summary="[courier-e2e] all-day",
        start=start,
        end=end,
        calendar_name="Courier Tests",
        all_day=True,
    )
    cal_obj = _sandbox_calendar_obj(live_caldav, sandbox_calendar)
    try:
        assert event.is_all_day

        # Verify the raw iCal contains VALUE=DATE
        obj = cal_obj.event_by_url(event.raw_url)
        ical_text = obj.data
        assert "VALUE=DATE" in ical_text, (
            "All-day event did not emit VALUE=DATE — check cal.create_event "
            "all_day branch (RFC 5545 §3.6.1)."
        )
    finally:
        try:
            cal_obj.event_by_url(event.raw_url).delete()
        except Exception:
            pass  # Cleanup-only


def test_free_busy_respects_working_hours(live_caldav):
    """free_busy with working_hours=(9, 17) should not return 24/7 gaps."""
    start = _tomorrow()
    end = start + timedelta(days=3)
    slots = live_caldav.free_busy(
        start=start,
        end=end,
        slot_minutes=30,
        working_hours=(9, 17),
        working_days=(0, 1, 2, 3, 4),  # Mon-Fri
    )
    assert isinstance(slots, list)
    # No slot should be longer than 8 hours (9 to 17)
    for s in slots:
        dur = s["duration_min"]
        assert dur <= 8 * 60, f"Slot {s} exceeds an 8-hour working day"
