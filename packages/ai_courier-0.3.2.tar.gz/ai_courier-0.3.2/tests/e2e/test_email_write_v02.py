"""v0.2 regression — email write surface."""
from __future__ import annotations

import asyncio
import uuid

import pytest


@pytest.mark.asyncio
async def test_mark_read_clears_unread(live_jmap, self_sent_email):
    await live_jmap.mark_read([self_sent_email.id])
    refreshed = await live_jmap.get_email(self_sent_email.id)
    assert refreshed.is_unread is False


@pytest.mark.asyncio
async def test_archive_moves_out_of_inbox(live_jmap, self_sent_email):
    inbox_id = await live_jmap.get_mailbox_id("inbox")
    archive_id = await live_jmap.get_mailbox_id("archive")

    # Precondition: self_sent_email is in Inbox (fixture polls Inbox specifically)
    assert inbox_id in self_sent_email.mailbox_ids

    await live_jmap.archive([self_sent_email.id])
    refreshed = await live_jmap.get_email(self_sent_email.id)
    assert inbox_id not in refreshed.mailbox_ids
    assert archive_id in refreshed.mailbox_ids


@pytest.mark.asyncio
async def test_trash_moves_to_trash(live_jmap, live_config):
    """Does not use self_sent_email because fixture teardown trashes the email —
    we want explicit control to verify the trash operation."""
    marker = uuid.uuid4().hex
    subject = f"[courier-e2e-trash] {marker}"
    account = live_config.get_account()
    sent_id = await live_jmap.send_email(
        to=[{"name": "Self", "email": account.username}],
        subject=subject,
        body="trash test\n",
    )
    # Poll Inbox for arrival (match the 30-iteration pattern from self_sent_email)
    inbox_id = await live_jmap.get_mailbox_id("inbox")
    received = None
    for _ in range(30):
        hits = await live_jmap.search_emails(
            subject=subject, mailbox_id=inbox_id, limit=1,
        )
        if hits:
            received = hits[0]
            break
        await asyncio.sleep(1)
    assert received is not None, f"Test email {subject!r} did not arrive within 30s"

    await live_jmap.trash([received.id])
    trash_id = await live_jmap.get_mailbox_id("trash")
    refreshed = await live_jmap.get_email(received.id)
    assert trash_id in refreshed.mailbox_ids

    # Clean up the sent copy from Sent folder
    await live_jmap.trash([sent_id])
