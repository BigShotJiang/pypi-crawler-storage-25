"""v0.2 regression — attachments round-trip and draft lifecycle.

These tests disprove the stale vault notes claiming Courier "cannot
send attachments" and "cannot download attachments". v0.2 shipped
both; these tests confirm end-to-end they still work.
"""
from __future__ import annotations

import asyncio
import os
import tempfile
import uuid

import pytest


@pytest.mark.asyncio
async def test_attachment_roundtrip(live_jmap, live_config):
    """Send self an email with an attachment; list it; download it; bytes match."""
    marker = uuid.uuid4().hex
    subject = f"[courier-e2e-att] {marker}"
    account = live_config.get_account()

    # Write a small file to temp
    payload = f"attachment body {marker}\n".encode("utf-8")
    with tempfile.NamedTemporaryFile(
        suffix=".txt", delete=False, prefix="courier-e2e-"
    ) as tf:
        tf.write(payload)
        src_path = tf.name

    received = None
    sent_id = None
    try:
        sent_id = await live_jmap.send_email(
            to=[{"name": "Self", "email": account.username}],
            subject=subject,
            body="see attachment",
            attachment_paths=[src_path],
        )

        # Poll Inbox with 30-iteration / 1s pattern, filter by mailbox_id
        # (conventions from commits e7dfeb4 and 33ff1fa).
        inbox_id = await live_jmap.get_mailbox_id("inbox")
        for _ in range(30):
            hits = await live_jmap.search_emails(
                subject=subject, mailbox_id=inbox_id, limit=1,
            )
            if hits:
                full = await live_jmap.get_email(hits[0].id)
                if full.attachments:
                    received = full
                    break
            await asyncio.sleep(1)
        assert received is not None, (
            f"Self-sent attachment email {subject!r} did not arrive within 30s"
        )
        assert received.attachments, "Expected at least one attachment on received email"

        att = received.attachments[0]
        assert att.name.endswith(".txt")
        assert att.size == len(payload)

        # Download and verify
        data = await live_jmap.download_blob(
            att.blob_id, content_type=att.type, name=att.name,
        )
        assert data == payload
    finally:
        os.unlink(src_path)
        # Cleanup — trash both received and sent copies
        to_trash = []
        if received is not None:
            to_trash.append(received.id)
        if sent_id is not None:
            to_trash.append(sent_id)
        if to_trash:
            try:
                await live_jmap.trash(to_trash)
            except Exception:
                pass  # Cleanup-only — don't mask test failure


@pytest.mark.asyncio
async def test_draft_create_then_cleanup(live_jmap, live_config):
    """Create a draft, verify it exists in Drafts, then delete it."""
    account = live_config.get_account()
    marker = uuid.uuid4().hex
    draft_id = await live_jmap.create_draft(
        to=[{"name": "Self", "email": account.username}],
        subject=f"[courier-e2e-draft] {marker}",
        body="draft body\n",
    )
    assert draft_id

    # Verify in Drafts mailbox
    drafts_id = await live_jmap.get_mailbox_id("drafts")
    email = await live_jmap.get_email(draft_id)
    assert drafts_id in email.mailbox_ids

    # Cleanup
    await live_jmap.trash([draft_id])
