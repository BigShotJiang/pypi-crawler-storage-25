"""v0.2 regression — email read surface."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest


@pytest.mark.asyncio
async def test_inbox_returns_emails(live_jmap):
    emails = await live_jmap.list_emails(limit=5)
    assert isinstance(emails, list)
    # Inbox is rarely empty; if it is on your account, change limit to match reality.
    assert len(emails) > 0, "Inbox empty — ensure the account has mail"


@pytest.mark.asyncio
async def test_search_finds_self_sent(live_jmap, self_sent_email):
    results = await live_jmap.search_emails(subject=self_sent_email.subject, limit=3)
    ids = {e.id for e in results}
    assert self_sent_email.id in ids


@pytest.mark.asyncio
async def test_search_by_from_and_date(live_jmap, self_sent_email, live_config):
    after = (datetime.now(timezone.utc) - timedelta(minutes=5)).isoformat()
    results = await live_jmap.search_emails(
        from_addr=live_config.get_account().username,
        after=after,
        limit=10,
    )
    assert any(e.id == self_sent_email.id for e in results)


@pytest.mark.asyncio
async def test_get_email_returns_full_body(live_jmap, self_sent_email):
    full = await live_jmap.get_email(self_sent_email.id)
    assert full.id == self_sent_email.id
    assert "E2E marker" in full.body_text


@pytest.mark.asyncio
async def test_get_thread_returns_messages(live_jmap, self_sent_email):
    thread = await live_jmap.get_thread(self_sent_email.thread_id)
    assert len(thread) >= 1
    assert any(e.id == self_sent_email.id for e in thread)
