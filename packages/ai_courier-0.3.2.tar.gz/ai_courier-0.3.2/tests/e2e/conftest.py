"""E2E test configuration.

These tests run against a real Fastmail account and are opt-in. Set
COURIER_LIVE_TESTS=1 to run them. The configured account is loaded from
~/.config/courier/config.json — the same one the CLI and MCP server use.

Every write is contained in a sandbox:
  - mailbox: "Courier/Tests"    (created by `courier test-setup`)
  - calendar: "Courier Tests"   (created by `courier test-setup`)

Tests self-clean: fixtures create their own ephemera and tear them down.
"""
from __future__ import annotations

import asyncio
import os
import uuid
import warnings

import pytest
import pytest_asyncio

from courier.config import CourierConfig
from courier.jmap import JMAPClient

LIVE = os.environ.get("COURIER_LIVE_TESTS") == "1"
SANDBOX_MAILBOX_NAME = "Courier/Tests"
SANDBOX_CALENDAR_NAME = "Courier Tests"


def pytest_collection_modifyitems(config, items):
    if LIVE:
        return
    skip_live = pytest.mark.skip(reason="Set COURIER_LIVE_TESTS=1 to run")
    for item in items:
        item.add_marker(skip_live)


@pytest_asyncio.fixture(scope="session")
async def live_config() -> CourierConfig:
    cfg = CourierConfig.load()
    if not cfg.accounts:
        pytest.skip("No Courier account configured (run `courier setup`)")
    return cfg


@pytest_asyncio.fixture(scope="session")
async def live_jmap(live_config):
    account = live_config.get_account()
    client = JMAPClient(account)
    try:
        await client.connect()
        yield client
    finally:
        await client.close()


@pytest_asyncio.fixture(scope="session")
async def sandbox_mailbox_id(live_jmap) -> str:
    """Return the ID of the Courier/Tests mailbox. Fails loudly if missing."""
    mailboxes = await live_jmap.get_mailboxes()
    by_id = {mb["id"]: mb for mb in mailboxes}
    for mb in mailboxes:
        if mb.get("name") == "Tests":
            # Walk up to verify parent is named "Courier"
            parent = by_id.get(mb.get("parentId", ""))
            if parent and parent.get("name") == "Courier":
                return mb["id"]
    pytest.fail(
        f"Sandbox mailbox {SANDBOX_MAILBOX_NAME!r} not found. "
        "Run `courier test-setup` first."
    )


@pytest_asyncio.fixture
async def self_sent_email(live_jmap, live_config):
    """Send a timestamped test email to self; yield the Email; trash on teardown.

    The email lands in Inbox with an `[courier-e2e]` subject prefix and a
    uuid body marker, so it can be located unambiguously.
    """
    marker = uuid.uuid4().hex
    subject = f"[courier-e2e] {marker}"
    account = live_config.get_account()
    to = [{"name": "Self", "email": account.username}]

    sent_id = await live_jmap.send_email(
        to=to,
        subject=subject,
        body=f"E2E marker: {marker}\n",
    )

    # Poll INBOX specifically for the message by subject (up to ~30 s).
    # Filtering by mailbox_id avoids racing the Sent copy — search_emails
    # without a mailbox filter may surface either depending on which lands
    # in the JMAP index first.
    inbox_id = await live_jmap.get_mailbox_id("inbox")
    received = None
    for _ in range(30):
        emails = await live_jmap.search_emails(
            subject=subject, mailbox_id=inbox_id, limit=5,
        )
        if emails:
            received = emails[0]
            break
        await asyncio.sleep(1)
    if not received:
        # Clean up the sent copy before failing — otherwise it leaks into
        # Sent over flaky runs.
        try:
            await live_jmap.trash([sent_id])
        except Exception as exc:
            warnings.warn(
                f"Teardown failed to trash sent copy {sent_id}: {exc}",
                stacklevel=1,
            )
        raise RuntimeError(f"Self-sent email {subject!r} did not arrive within 30s")

    yield received

    # Teardown: trash both sent and received copies.
    # Warn (don't raise) on failure so cleanup issues don't mask test
    # failures, but stay visible under -W error or in warnings output.
    try:
        await live_jmap.trash([received.id, sent_id])
    except Exception as exc:
        warnings.warn(
            f"Teardown failed to trash {received.id}/{sent_id}: {exc}",
            stacklevel=1,
        )


@pytest.fixture(scope="session")
def live_caldav(live_config):
    from courier.cal import CalDAVClient
    account = live_config.get_account()
    client = CalDAVClient(account)
    client.connect()
    return client


@pytest.fixture(scope="session")
def sandbox_calendar(live_caldav):
    """Return the 'Courier Tests' calendar object or fail if not present.

    Note: CalDAVClient.list_calendars() returns list[dict[str, str]] with
    'name' and 'url' keys (not caldav.Calendar objects). Tests needing the
    raw Calendar object should use live_caldav directly.
    """
    for cal in live_caldav.list_calendars():
        if cal.get("name") == "Courier Tests":
            return cal
    pytest.fail("Sandbox calendar 'Courier Tests' not found. Run `courier test-setup`.")
