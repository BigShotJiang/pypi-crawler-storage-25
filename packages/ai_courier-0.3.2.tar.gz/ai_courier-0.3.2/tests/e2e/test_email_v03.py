"""v0.3 new tools E2E."""
from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_mailboxes_includes_inbox_and_sandbox(live_jmap):
    boxes = await live_jmap.list_mailboxes_enriched()
    by_role = {b["role"]: b for b in boxes if b["role"]}
    assert "inbox" in by_role, "Inbox role mailbox missing"
    assert "archive" in by_role
    assert "trash" in by_role

    # Sandbox parent + child present after `courier test-setup`
    paths = {b["path"] for b in boxes}
    assert "Courier" in paths, "Run `courier test-setup` first"
    assert "Courier/Tests" in paths


@pytest.mark.asyncio
async def test_move_to_sandbox_by_path(live_jmap, self_sent_email, sandbox_mailbox_id):
    result = await live_jmap.move_emails_by_name(
        [self_sent_email.id], "Courier/Tests"
    )
    assert result["mailbox_id"] == sandbox_mailbox_id
    refreshed = await live_jmap.get_email(self_sent_email.id)
    inbox_id = await live_jmap.get_mailbox_id("inbox")
    assert sandbox_mailbox_id in refreshed.mailbox_ids
    assert inbox_id not in refreshed.mailbox_ids


@pytest.mark.asyncio
async def test_label_add_preserves_inbox(live_jmap, self_sent_email, sandbox_mailbox_id):
    inbox_id = await live_jmap.get_mailbox_id("inbox")
    await live_jmap.set_mailbox_memberships(
        [self_sent_email.id], ["Courier/Tests"], add=True,
    )
    refreshed = await live_jmap.get_email(self_sent_email.id)
    assert sandbox_mailbox_id in refreshed.mailbox_ids
    assert inbox_id in refreshed.mailbox_ids, (
        "email_label should not remove existing membership"
    )


@pytest.mark.asyncio
async def test_label_remove(live_jmap, self_sent_email, sandbox_mailbox_id):
    # Add then remove
    await live_jmap.set_mailbox_memberships(
        [self_sent_email.id], ["Courier/Tests"], add=True,
    )
    await live_jmap.set_mailbox_memberships(
        [self_sent_email.id], ["Courier/Tests"], add=False,
    )
    refreshed = await live_jmap.get_email(self_sent_email.id)
    assert sandbox_mailbox_id not in refreshed.mailbox_ids


@pytest.mark.asyncio
async def test_reply_creates_draft_with_threading(live_jmap, self_sent_email):
    result = await live_jmap.reply_to(
        email_id=self_sent_email.id,
        body="automated test reply",
        send=False,
    )
    assert result["status"] == "draft"
    draft = await live_jmap.get_email(result["id"])
    # Thread should match the original
    assert draft.thread_id == self_sent_email.thread_id
    # Subject should be prefixed
    assert draft.subject.lower().startswith("re: ")
    # In-Reply-To should point to original
    if self_sent_email.message_id:
        assert draft.in_reply_to == self_sent_email.message_id[0]
    # Cleanup
    await live_jmap.trash([result["id"]])


@pytest.mark.asyncio
async def test_cleanup_sweeps_orphans_but_skips_trashed(live_jmap, live_config):
    """Simulate an orphan from a crashed E2E run; sweep; verify it's trashed.

    Uses a distinct prefix so the sweep doesn't touch the running suite's
    own self_sent_email fixtures in other tests.
    """
    import asyncio
    import uuid

    prefix = "[courier-e2e-cleanup-test]"
    marker = uuid.uuid4().hex
    subject = f"{prefix} {marker}"
    account = live_config.get_account()

    # Create an orphan (no teardown — simulating a crashed fixture)
    sent_id = await live_jmap.send_email(
        to=[{"name": "Self", "email": account.username}],
        subject=subject,
        body="orphan body\n",
    )

    # Wait for delivery to Inbox
    inbox_id = await live_jmap.get_mailbox_id("inbox")
    received = None
    for _ in range(30):
        hits = await live_jmap.search_emails(
            subject=subject, mailbox_id=inbox_id, limit=1,
        )
        if hits:
            received = hits[0]
            break
        await asyncio.sleep(1)
    assert received is not None, f"Orphan setup failed — {subject!r} didn't arrive"

    # Dry run first — should report counts without moving anything
    dry = await live_jmap.test_cleanup(prefix=prefix, dry_run=True)
    assert dry["to_trash"] >= 2  # at least the Inbox + Sent copies
    assert dry["trashed"] == 0
    # Still in Inbox after dry run
    still_there = await live_jmap.get_email(received.id)
    assert inbox_id in still_there.mailbox_ids

    # Real sweep
    result = await live_jmap.test_cleanup(prefix=prefix)
    assert result["trashed"] >= 2

    # Verify trashed
    trash_id = await live_jmap.get_mailbox_id("trash")
    refreshed = await live_jmap.get_email(received.id)
    assert trash_id in refreshed.mailbox_ids
    assert inbox_id not in refreshed.mailbox_ids

    # Second sweep should find already-trashed matches but skip them
    second = await live_jmap.test_cleanup(prefix=prefix)
    assert second["to_trash"] == 0, (
        "Second sweep should skip already-trashed messages"
    )

    # Sent copy cleanup (belt-and-braces; the sweep already handled it if in Sent)
    try:
        await live_jmap.trash([sent_id])
    except Exception:
        pass
