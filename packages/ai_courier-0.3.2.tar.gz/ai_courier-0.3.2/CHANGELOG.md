# Changelog

All notable changes to Courier are documented here. Format loosely based on
[Keep a Changelog](https://keepachangelog.com/); versioning follows SemVer.

## [0.3.2] — 2026-04-17

### Changed
- **PyPI package renamed from `courier-mcp` to `ai-courier`** ahead of first
  public PyPI release. Avoids collision with the unrelated `@trycourier/courier-mcp`
  (Courier Inc.'s notification-API MCP server on npm) and positions the name
  for cross-provider ambition — future Gmail / Exchange / Apple bindings
  stay inside the same package rather than being stuck with a Fastmail-
  flavored name.
- Install changes from `pip install courier-mcp` → `pip install ai-courier`.
- Everything else unchanged: repo stays `iamdadzilla/courier`, CLI verb
  stays `courier`, MCP server command stays `courier-mcp`, project and
  brand stay "Courier". Only the PyPI distribution name moves.

## [0.3.1] — 2026-04-17

### Added
- **`courier test-cleanup`** — sweep stray `[courier-e2e*]` test artifacts
  from all mailboxes to Trash. Idempotent; filters out already-trashed
  matches. Addresses the fixture-teardown orphan problem surfaced after
  the first live Fastmail-MCP-free sweep.

## [0.3.0] — 2026-04-17

### Added
- **Folder filing** — `email_mailboxes` lists folders/labels with paths;
  `email_move(ids, to)` moves to a mailbox by ID, name, or path
  (`"Clients/Guardian"`); `email_label(ids, labels, add)` adds/removes
  mailbox memberships without touching other memberships.
- **Threaded reply** — `email_reply(email_id, body, send, include_quote)`
  composes a proper reply (In-Reply-To, References, `Re:` prefix,
  Reply-To-or-From To: resolution); creates a draft by default.
- **E2E test suite** — `tests/e2e/`, opt-in via `COURIER_LIVE_TESTS=1`,
  self-cleaning via a `Courier/Tests` mailbox and `Courier Tests`
  calendar. New `courier test-setup` CLI command creates the sandbox.
- CLI verbs: `courier mailboxes`, `courier move`, `courier label`,
  `courier reply`, `courier test-setup`.
- `Email.message_id` and `Email.reply_to_addrs` — extracted from JMAP.

### Fixed
- `_normalize_utcdate` silently passed non-UTC offsets through, so
  `datetime.now(tz=UTC).isoformat()` output returned empty search
  results with no error. Now validates via `datetime.fromisoformat`
  and rejects non-UTC offsets with `ValueError`.
- `create_draft` sent `inReplyTo` as a string, but RFC 8621 §4.1.3.1
  types it as `String[]`. Fastmail rejected threaded draft creates.
  Now wrapped in a list; parsing normalizes list-or-string-or-None
  back to the existing `Email.in_reply_to: str | None` contract.
- `pyproject.toml` now sets `asyncio_default_test_loop_scope = "session"`
  so function-scoped tests share the session-scoped fixtures' event loop.

### Changed
- `__version__` corrected to `0.3.0` (was stale at `0.1.0` through v0.2).

### Migration
Agents using Courier can now retire Fastmail MCP entirely — all
previous filing and threaded-reply operations now have Courier
equivalents. See `docs/superpowers/specs/2026-04-17-courier-v0.3-design.md`
for the full mapping.

## [0.2.0] — 2026-04-16

### Added
- **Attachment support**
  - `Attachment` dataclass + `Email.attachments` list, populated from
    JMAP `bodyStructure` walk.
  - `JMAPClient.download_blob()` and `upload_blob()` using the session's
    `downloadUrl` / `uploadUrl` templates (RFC 8620 §6.2).
  - `create_draft()` / `send_email()` accept attachments — `send_email`
    takes `attachment_paths` and handles upload.
  - MCP tools `email_attachments` (list) and `email_attachment_save`
    (download to local path). `email_send` gains optional `attachment_paths`.
  - CLI `courier attachments <email_id>` and `courier download <email_id> <dest>`.
  - `courier read` now shows attachment list in the header.

- **Calendar invite MIME detection**
  - `Email.has_calendar_invite` populated by walking `bodyStructure` for
    `text/calendar` parts.
  - New triage guard `requires_calendar_invite`.
  - Default rule `calendar-invite-mime` (actionable, confidence 0.95).

- **Calendar event deduplication** across calendars via `(uid, recurrence_id)`.

- **All-day event support** in `create_event` + `calendar_create` MCP tool.
  All-day events emit `VALUE=DATE` per RFC 5545 §3.6.1.

### Changed
- `free_busy` gains `working_hours` and `working_days` parameters; gaps are
  split at day boundaries and trimmed to the working window when set.
- `courier free` defaults to Mon–Fri 09:00–17:00 local; flags `--all-hours`,
  `--start-hour`, `--end-hour` added.
- `courier free` CLI shows end date when a slot crosses midnight (previously
  displayed only the end time, which hid the date and looked wrong).

### Fixed
- `free_busy` previously reported multi-day 24/7 gaps (e.g. a 77-hour
  Friday-evening-through-Monday-morning slot) when there were no meetings
  over a weekend. These are now properly constrained and split by day.

## [0.1.0] — 2026-04-13

- Initial release. JMAP email client, CalDAV calendar client, rule-based
  triage, MCP server, CLI. Fastmail-only.
