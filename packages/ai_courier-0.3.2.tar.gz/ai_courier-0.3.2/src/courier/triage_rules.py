"""Configurable triage rule loading and evaluation.

Loads rules from YAML (defaults + user overrides) and evaluates them
against emails. Replaces the hardcoded regex chains in triage.py.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .jmap import Email
from .state import StateStore

# ── Constants ──────────────────────────────────────────────────────

VALID_CLASSIFICATIONS = {"urgent", "needs_reply", "actionable", "fyi", "bulk"}
FYI_DEFAULT = "fyi"

DEFAULT_RULES_PATH = Path(__file__).parent / "default_rules.yaml"
USER_RULES_PATH = Path.home() / ".config" / "courier" / "triage-rules.yaml"


# ── Data classes ───────────────────────────────────────────────────


@dataclass
class TriageRule:
    """A single triage rule with match conditions and guards."""

    name: str
    classification: str
    confidence: float = 0.7
    reason: str = ""

    # Match conditions (regex strings — compiled eagerly in __post_init__)
    from_pattern: str = ""
    subject_pattern: str = ""
    body_pattern: str = ""
    domain_pattern: str = ""

    # Guards
    requires_known_contact: bool = False
    requires_unknown_contact: bool = False
    requires_calendar_invite: bool = False
    max_size: int = 0  # 0 = no limit
    requires_thread: bool = False
    requires_flagged: bool = False

    # Compiled regexes (populated by _compile)
    _from_re: re.Pattern | None = field(default=None, repr=False)
    _subject_re: re.Pattern | None = field(default=None, repr=False)
    _body_re: re.Pattern | None = field(default=None, repr=False)
    _domain_re: re.Pattern | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self._compile()

    def _compile(self) -> None:
        """Compile regex patterns with contextual error messages."""

        def _safe_compile(pattern: str, field_name: str) -> re.Pattern:
            try:
                return re.compile(pattern, re.IGNORECASE)
            except re.error as exc:
                raise ValueError(
                    f"Invalid regex in rule {self.name!r} field "
                    f"{field_name!r}: {exc}"
                ) from exc

        if self.from_pattern:
            self._from_re = _safe_compile(self.from_pattern, "from_pattern")
        if self.subject_pattern:
            self._subject_re = _safe_compile(self.subject_pattern, "subject_pattern")
        if self.body_pattern:
            self._body_re = _safe_compile(self.body_pattern, "body_pattern")
        if self.domain_pattern:
            self._domain_re = _safe_compile(self.domain_pattern, "domain_pattern")


@dataclass
class SenderOverride:
    """Force a classification for a specific sender address."""

    address: str
    classification: str
    reason: str = ""


@dataclass
class TriageRuleset:
    """Complete set of triage rules + sender overrides."""

    rules: list[TriageRule] = field(default_factory=list)
    sender_overrides: dict[str, SenderOverride] = field(default_factory=dict)


# ── Loading ──────────────────────────────────────────────────────


def _parse_rules(data: dict[str, Any]) -> TriageRuleset:
    """Parse a YAML dict into a TriageRuleset."""
    rules = []
    for r in data.get("rules", []):
        rule_name = r.get("name", "unnamed")
        classification = r.get("classification", "fyi")
        if classification not in VALID_CLASSIFICATIONS:
            raise ValueError(f"Invalid classification '{classification}' in rule '{rule_name}'")

        # Validate confidence
        raw_confidence = r.get("confidence", 0.7)
        if isinstance(raw_confidence, bool) or not isinstance(raw_confidence, (int, float)):
            raise ValueError(
                f"Invalid confidence '{raw_confidence}' in rule '{rule_name}': "
                "must be a number in [0.0, 1.0]"
            )
        confidence = float(raw_confidence)
        if not 0.0 <= confidence <= 1.0:
            raise ValueError(
                f"Invalid confidence {confidence} in rule '{rule_name}': "
                "must be in [0.0, 1.0]"
            )

        # Validate max_size
        raw_max_size = r.get("max_size", 0)
        if not isinstance(raw_max_size, int) or isinstance(raw_max_size, bool) or raw_max_size < 0:
            raise ValueError(
                f"Invalid max_size '{raw_max_size}' in rule '{rule_name}': "
                "must be a non-negative integer"
            )

        # Validate guard combinations
        req_known = r.get("requires_known_contact", False)
        req_unknown = r.get("requires_unknown_contact", False)
        if req_known and req_unknown:
            raise ValueError(
                f"Rule '{rule_name}' has both requires_known_contact and "
                "requires_unknown_contact — this can never match"
            )

        rules.append(TriageRule(
            name=rule_name,
            classification=classification,
            confidence=confidence,
            reason=r.get("reason", ""),
            from_pattern=r.get("from_pattern", ""),
            subject_pattern=r.get("subject_pattern", ""),
            body_pattern=r.get("body_pattern", ""),
            domain_pattern=r.get("domain_pattern", ""),
            requires_known_contact=req_known,
            requires_unknown_contact=req_unknown,
            requires_calendar_invite=r.get("requires_calendar_invite", False),
            max_size=raw_max_size,
            requires_thread=r.get("requires_thread", False),
            requires_flagged=r.get("requires_flagged", False),
        ))

    overrides = {}
    for addr, cfg in data.get("sender_overrides", {}).items():
        addr_lower = addr.lower()
        classification = cfg.get("classification", "bulk")
        if classification not in VALID_CLASSIFICATIONS:
            raise ValueError(f"Invalid classification '{classification}' in sender override '{addr}'")
        overrides[addr_lower] = SenderOverride(
            address=addr_lower,
            classification=classification,
            reason=cfg.get("reason", f"sender override: {addr}"),
        )

    return TriageRuleset(rules=rules, sender_overrides=overrides)


def load_rules(
    user_path: Path | None = None,
    defaults_path: Path | None = None,
) -> TriageRuleset:
    """Load and merge default + user triage rules.

    Merge strategy:
    - sender_overrides: user overrides are additive (user wins on conflict)
    - rules: if user defines ANY rules, they REPLACE defaults entirely
    """
    defaults_path = defaults_path or DEFAULT_RULES_PATH
    user_path = user_path or USER_RULES_PATH

    # Load defaults
    default_data = yaml.safe_load(defaults_path.read_text()) or {}
    default_ruleset = _parse_rules(default_data)

    # Load user overrides (if they exist)
    if user_path.exists():
        user_data = yaml.safe_load(user_path.read_text()) or {}
        user_ruleset = _parse_rules(user_data)

        # Merge sender overrides (user wins)
        merged_overrides = {**default_ruleset.sender_overrides, **user_ruleset.sender_overrides}

        # Rules: if user defined the key at all, their rules replace defaults
        # (including an explicit empty list to disable all rules)
        merged_rules = user_ruleset.rules if "rules" in user_data else default_ruleset.rules

        return TriageRuleset(rules=merged_rules, sender_overrides=merged_overrides)

    return default_ruleset


# ── Evaluation ─────────────────────────────────────────────────────


@dataclass
class TriageResult:
    """Result of triage classification."""

    classification: str
    confidence: float
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "classification": self.classification,
            "confidence": self.confidence,
            "reason": self.reason,
        }


def _is_known_contact(
    state: StateStore | None, account_id: str, from_address: str
) -> bool:
    """Check if we've sent email to this address before."""
    if not state or not account_id:
        return False
    signal = state.get_contact_signal(account_id, from_address)
    return bool(signal and signal.get("total_sent", 0) > 0)


def _check_guards(
    rule: TriageRule,
    email: Email,
    is_known: bool,
) -> bool:
    """Check if all guard conditions on a rule are satisfied."""
    if rule.requires_known_contact and not is_known:
        return False
    if rule.requires_unknown_contact and is_known:
        return False
    if rule.requires_calendar_invite and not getattr(email, "has_calendar_invite", False):
        return False
    if rule.max_size and email.size >= rule.max_size:
        return False
    if rule.requires_thread and not email.in_reply_to:
        return False
    if rule.requires_flagged and not email.is_flagged:
        return False
    return True


def _format_reason(
    reason_template: str, email: Email, match: re.Match | None = None
) -> str:
    """Fill in reason template variables."""
    result = reason_template
    result = result.replace("{from}", email.from_address)
    result = result.replace("{subject_short}", email.subject[:50])
    if match:
        result = result.replace("{match}", match.group())
    else:
        result = result.replace("{match}", "")
    return result


def classify_email(
    email: Email,
    ruleset: TriageRuleset | None = None,
    state: StateStore | None = None,
    account_id: str = "",
) -> TriageResult:
    """Classify a single email using configurable rules.

    Evaluation order:
    1. Sender overrides (exact match)
    2. Rules (top-to-bottom, first match wins)
    3. Default: fyi
    """
    if ruleset is None:
        ruleset = load_rules()

    # ── Step 1: Sender overrides ──────────────────────────────
    from_lower = email.from_address.lower()
    if from_lower in ruleset.sender_overrides:
        override = ruleset.sender_overrides[from_lower]
        return TriageResult(
            classification=override.classification,
            confidence=1.0,
            reason=override.reason,
        )

    # ── Step 2: Evaluate rules ────────────────────────────────
    subject_and_preview = f"{email.subject} {email.preview}"
    body_head = email.body_text[:500]
    is_known = _is_known_contact(state, account_id, email.from_address)

    for rule in ruleset.rules:
        # Check guards first (cheap)
        if not _check_guards(rule, email, is_known):
            continue

        # Check match conditions — ALL specified patterns must match (AND logic)
        matched = False
        last_match: re.Match | None = None

        has_any_pattern = bool(
            rule.from_pattern or rule.subject_pattern
            or rule.body_pattern or rule.domain_pattern
        )

        if rule._from_re:
            m = rule._from_re.search(email.from_address)
            if m:
                matched = True
                last_match = m
            else:
                continue  # from_pattern required but didn't match

        if rule._domain_re:
            m = rule._domain_re.search(email.from_address)
            if m:
                matched = True
                last_match = m
            else:
                continue

        if rule._subject_re:
            m = rule._subject_re.search(subject_and_preview)
            if m:
                matched = True
                last_match = m
            else:
                continue

        if rule._body_re:
            m = rule._body_re.search(body_head)
            if m:
                matched = True
                last_match = m
            else:
                continue

        # Guard-only rules (no patterns) match if all guards passed
        if not has_any_pattern:
            matched = True

        if matched:
            reason = _format_reason(rule.reason, email, last_match)
            confidence = rule.confidence
            # Boost confidence for known contacts on needs_reply
            if rule.classification == "needs_reply" and is_known and confidence < 0.85:
                confidence = 0.85
            return TriageResult(
                classification=rule.classification,
                confidence=confidence,
                reason=reason,
            )

    # ── Step 3: Default fallthrough ───────────────────────────
    return TriageResult(FYI_DEFAULT, 0.5, "no strong signals detected")



def classify_batch(
    emails: list[Email],
    ruleset: TriageRuleset | None = None,
    state: StateStore | None = None,
    account_id: str = "",
) -> dict[str, list[tuple[Email, TriageResult]]]:
    """Classify a batch of emails and return them grouped by classification."""
    if ruleset is None:
        ruleset = load_rules()

    buckets: dict[str, list[tuple[Email, TriageResult]]] = {
        "urgent": [],
        "needs_reply": [],
        "actionable": [],
        "fyi": [],
        "bulk": [],
    }

    for email in emails:
        result = classify_email(email, ruleset, state, account_id)
        buckets[result.classification].append((email, result))

        if state and account_id:
            state.classify_email(
                account_id, email.id, result.classification,
                result.confidence, result.reason,
            )

    return buckets
