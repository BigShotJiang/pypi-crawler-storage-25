"""Rule-based email triage classification.

This module is the public API. It delegates to triage_rules.py which loads
configurable YAML rules. All existing imports continue to work.
"""

from __future__ import annotations

from .jmap import Email
from .state import StateStore
from .triage_rules import (
    TriageResult,
    TriageRuleset,
    classify_batch as _classify_batch,
    classify_email as _classify_email,
    load_rules,
)

# Re-export classification constants for backward compatibility
URGENT = "urgent"
NEEDS_REPLY = "needs_reply"
ACTIONABLE = "actionable"
FYI = "fyi"
BULK = "bulk"

# Re-export TriageResult (already imported above)
__all__ = [
    "URGENT", "NEEDS_REPLY", "ACTIONABLE", "FYI", "BULK",
    "TriageResult", "TriageRuleset",
    "classify_email", "classify_batch", "load_rules",
]

# Lazy-loaded default ruleset (loaded once, reused).
# Intentionally never invalidated — rule file changes require process restart.
_default_ruleset: TriageRuleset | None = None


def _get_default_ruleset() -> TriageRuleset:
    global _default_ruleset
    if _default_ruleset is None:
        _default_ruleset = load_rules()
    return _default_ruleset


def classify_email(
    email: Email,
    state: StateStore | None = None,
    account_id: str = "",
    ruleset: TriageRuleset | None = None,
) -> TriageResult:
    """Classify a single email. Backward-compatible signature.

    New callers can pass `ruleset` to use custom rules.
    Old callers get the default ruleset automatically.
    """
    return _classify_email(
        email,
        ruleset=ruleset or _get_default_ruleset(),
        state=state,
        account_id=account_id,
    )


def classify_batch(
    emails: list[Email],
    state: StateStore | None = None,
    account_id: str = "",
    ruleset: TriageRuleset | None = None,
) -> dict[str, list[tuple[Email, TriageResult]]]:
    """Classify a batch of emails. Backward-compatible signature."""
    return _classify_batch(
        emails,
        ruleset=ruleset or _get_default_ruleset(),
        state=state,
        account_id=account_id,
    )
