"""Courier MCP Server.

Exposes email and calendar operations as MCP tools.
Each tool returns context-window-optimized output.
"""

from __future__ import annotations

import asyncio
import json
from datetime import date, datetime, timezone
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .cal import CalDAVClient
from .config import CourierConfig
from .jmap import JMAPClient
from .state import StateStore
from .triage import classify_batch

# ── Server setup ─────────────────────────────────────────────────────

app = Server("courier")
_config: CourierConfig | None = None
_jmap: JMAPClient | None = None
_caldav: CalDAVClient | None = None
_state: StateStore | None = None


def _get_config() -> CourierConfig:
    global _config
    if not _config:
        _config = CourierConfig.load()
    return _config


def _get_state() -> StateStore:
    global _state
    if not _state:
        config = _get_config()
        _state = StateStore(config.db_path)
    return _state


async def _get_jmap() -> JMAPClient:
    global _jmap
    if not _jmap:
        config = _get_config()
        account = config.get_account()
        _jmap = JMAPClient(account)
        await _jmap.connect()
    return _jmap


def _get_caldav() -> CalDAVClient:
    global _caldav
    if not _caldav:
        config = _get_config()
        account = config.get_account()
        _caldav = CalDAVClient(account)
        _caldav.connect()
    return _caldav


def _text(data: Any) -> list[TextContent]:
    """Wrap data as MCP text content."""
    if isinstance(data, str):
        return [TextContent(type="text", text=data)]
    return [TextContent(type="text", text=json.dumps(data, indent=2, default=str))]


def _ensure_list(value: Any) -> list:
    """Coerce a value to a list. Handles Cowork runtime serializing arrays as strings."""
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
        # Single ID as bare string
        return [value]
    return list(value)


# ── Tool definitions ─────────────────────────────────────────────────

TOOLS = [
    # Email - Read
    Tool(
        name="email_inbox",
        description="Get inbox emails, triaged by priority. Returns emails grouped as: urgent, needs_reply, actionable, fyi, bulk.",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max emails to fetch", "default": 50},
                "unread_only": {"type": "boolean", "description": "Only unread emails", "default": False},
            },
        },
    ),
    Tool(
        name="email_new",
        description="Get emails received since last check (watermark-based). First call returns recent emails and sets watermark.",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "default": 50},
            },
        },
    ),
    Tool(
        name="email_search",
        description="Search emails with flexible filters.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Full-text search query"},
                "from": {"type": "string", "description": "Filter by sender address"},
                "subject": {"type": "string", "description": "Filter by subject"},
                "after": {"type": "string", "description": "After date (ISO 8601)"},
                "before": {"type": "string", "description": "Before date (ISO 8601)"},
                "limit": {"type": "integer", "default": 50},
            },
        },
    ),
    Tool(
        name="email_read",
        description="Read a specific email by ID. Returns full body text.",
        inputSchema={
            "type": "object",
            "properties": {
                "email_id": {"type": "string", "description": "Email ID"},
            },
            "required": ["email_id"],
        },
    ),
    Tool(
        name="email_thread",
        description="Get all emails in a thread, chronologically ordered.",
        inputSchema={
            "type": "object",
            "properties": {
                "thread_id": {"type": "string", "description": "Thread ID"},
            },
            "required": ["thread_id"],
        },
    ),
    # Email - Write
    Tool(
        name="email_archive",
        description="Archive emails (batch). Moves to Archive mailbox.",
        inputSchema={
            "type": "object",
            "properties": {
                "email_ids": {"type": "array", "items": {"type": "string"}, "description": "Email IDs to archive"},
            },
            "required": ["email_ids"],
        },
    ),
    Tool(
        name="email_trash",
        description="Trash emails (batch).",
        inputSchema={
            "type": "object",
            "properties": {
                "email_ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["email_ids"],
        },
    ),
    Tool(
        name="email_mark_read",
        description="Mark emails as read (batch).",
        inputSchema={
            "type": "object",
            "properties": {
                "email_ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["email_ids"],
        },
    ),
    Tool(
        name="email_draft",
        description="Create a draft email.",
        inputSchema={
            "type": "object",
            "properties": {
                "to": {"type": "array", "items": {"type": "object", "properties": {"name": {"type": "string"}, "email": {"type": "string"}}}},
                "subject": {"type": "string"},
                "body": {"type": "string"},
                "cc": {"type": "array", "items": {"type": "object", "properties": {"name": {"type": "string"}, "email": {"type": "string"}}}},
            },
            "required": ["to", "subject", "body"],
        },
    ),
    Tool(
        name="email_send",
        description="Send an email immediately. Optionally attach files by local path.",
        inputSchema={
            "type": "object",
            "properties": {
                "to": {"type": "array", "items": {"type": "object", "properties": {"name": {"type": "string"}, "email": {"type": "string"}}}},
                "subject": {"type": "string"},
                "body": {"type": "string"},
                "cc": {"type": "array", "items": {"type": "object", "properties": {"name": {"type": "string"}, "email": {"type": "string"}}}},
                "attachment_paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Local file paths to attach. Each is uploaded then attached.",
                },
            },
            "required": ["to", "subject", "body"],
        },
    ),
    Tool(
        name="email_attachments",
        description="List attachments on a specific email (names, types, sizes, blob IDs).",
        inputSchema={
            "type": "object",
            "properties": {
                "email_id": {"type": "string"},
            },
            "required": ["email_id"],
        },
    ),
    Tool(
        name="email_attachment_save",
        description="Download an attachment blob and save to a local path.",
        inputSchema={
            "type": "object",
            "properties": {
                "email_id": {"type": "string", "description": "Email containing the attachment"},
                "blob_id": {"type": "string", "description": "Attachment blob ID (from email_attachments)"},
                "dest_path": {"type": "string", "description": "Local path to write the file"},
            },
            "required": ["email_id", "blob_id", "dest_path"],
        },
    ),
    # Calendar
    Tool(
        name="calendar_today",
        description="Get today's calendar events, sorted chronologically.",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="calendar_week",
        description="Get this week's calendar events (next 7 days).",
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="calendar_events",
        description="Get calendar events in a date range.",
        inputSchema={
            "type": "object",
            "properties": {
                "start": {"type": "string", "description": "Start date (ISO 8601)"},
                "end": {"type": "string", "description": "End date (ISO 8601)"},
                "calendar": {"type": "string", "description": "Calendar name filter"},
            },
        },
    ),
    Tool(
        name="calendar_free",
        description="Find free time slots in a date range.",
        inputSchema={
            "type": "object",
            "properties": {
                "start": {"type": "string", "description": "Start date (ISO 8601)"},
                "end": {"type": "string", "description": "End date (ISO 8601)"},
                "slot_minutes": {"type": "integer", "description": "Minimum slot duration in minutes", "default": 30},
            },
        },
    ),
    Tool(
        name="calendar_create",
        description="Create a calendar event.",
        inputSchema={
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
                "start": {"type": "string", "description": "Start datetime (ISO 8601)"},
                "end": {"type": "string", "description": "End datetime (ISO 8601)"},
                "location": {"type": "string"},
                "description": {"type": "string"},
                "calendar": {"type": "string", "description": "Calendar name"},
                "attendees": {"type": "array", "items": {"type": "string"}, "description": "Attendee email addresses"},
            },
            "required": ["summary", "start", "end"],
        },
    ),
    Tool(
        name="email_mailboxes",
        description=(
            "List all mailboxes (folders/labels) with IDs, names, paths, roles, "
            "and counts. Use before email_move or email_label to discover "
            "available targets."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="email_move",
        description=(
            "Move emails to a target mailbox/folder. Replaces mailbox memberships "
            "(standard 'move' semantics). Target accepts mailbox ID, name ('Guardian'), "
            "or path ('Clients/Guardian')."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "email_ids": {"type": "array", "items": {"type": "string"}},
                "to": {"type": "string", "description": "Mailbox ID, name, or path"},
            },
            "required": ["email_ids", "to"],
        },
    ),
    Tool(
        name="email_label",
        description=(
            "Add or remove mailbox memberships without touching other memberships. "
            "Use for multi-label workflows. For filing (removing from inbox), "
            "prefer email_move."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "email_ids": {"type": "array", "items": {"type": "string"}},
                "labels": {"type": "array", "items": {"type": "string"}},
                "add": {"type": "boolean", "default": True},
            },
            "required": ["email_ids", "labels"],
        },
    ),
    Tool(
        name="email_reply",
        description=(
            "Reply to an email with proper threading (In-Reply-To, References, "
            "Re: prefix). Creates a draft by default; set send=True to send "
            "immediately."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "email_id": {"type": "string"},
                "body": {"type": "string"},
                "send": {"type": "boolean", "default": False},
                "include_quote": {"type": "boolean", "default": False},
                "cc": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "email": {"type": "string"},
                        },
                    },
                },
            },
            "required": ["email_id", "body"],
        },
    ),
    # Meta
    Tool(
        name="courier_status",
        description="Get Courier connection status, account info, and watermark state.",
        inputSchema={"type": "object", "properties": {}},
    ),
]


@app.list_tools()
async def list_tools() -> list[Tool]:
    return TOOLS


@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    try:
        # ── Email read tools ─────────────────────────────────────
        if name == "email_inbox":
            jmap = await _get_jmap()
            state = _get_state()
            limit = arguments.get("limit", 50)
            emails = await jmap.list_emails(limit=limit)

            if arguments.get("unread_only"):
                emails = [e for e in emails if e.is_unread]

            buckets = classify_batch(emails, state, jmap.session.account_id)
            result = {}
            for classification, items in buckets.items():
                if items:
                    result[classification] = [
                        {**e.summary(), "triage_reason": t.reason}
                        for e, t in items
                    ]
            return _text(result)

        elif name == "email_new":
            jmap = await _get_jmap()
            state = _get_state()
            account_id = jmap.session.account_id
            inbox_id = await jmap.get_mailbox_id("inbox")

            watermark = state.get_watermark(account_id, inbox_id)
            emails = await jmap.list_emails(
                mailbox_id=inbox_id,
                limit=arguments.get("limit", 50),
            )

            if watermark:
                # Filter to only emails after watermark
                emails = [e for e in emails if e.date > watermark.last_seen_date]

            # Update watermark
            if emails:
                newest = max(emails, key=lambda e: e.date)
                state.set_watermark(account_id, inbox_id, newest.date, newest.id)

            if not emails:
                return _text({"new_emails": 0, "message": "No new emails since last check"})

            buckets = classify_batch(emails, state, account_id)
            result = {"new_emails": len(emails)}
            for classification, items in buckets.items():
                if items:
                    result[classification] = [
                        {**e.summary(), "triage_reason": t.reason}
                        for e, t in items
                    ]
            return _text(result)

        elif name == "email_search":
            jmap = await _get_jmap()
            emails = await jmap.search_emails(
                query=arguments.get("query"),
                from_addr=arguments.get("from"),
                subject=arguments.get("subject"),
                after=arguments.get("after"),
                before=arguments.get("before"),
                limit=arguments.get("limit", 50),
            )
            return _text([e.summary() for e in emails])

        elif name == "email_read":
            jmap = await _get_jmap()
            email = await jmap.get_email(arguments["email_id"])
            return _text(email.summary(max_body=10000))

        elif name == "email_thread":
            jmap = await _get_jmap()
            emails = await jmap.get_thread(arguments["thread_id"])
            return _text([e.summary(max_body=2000) for e in emails])

        # ── Email write tools ────────────────────────────────────
        elif name == "email_archive":
            jmap = await _get_jmap()
            ids = _ensure_list(arguments["email_ids"])
            await jmap.archive(ids)
            return _text(f"Archived {len(ids)} emails")

        elif name == "email_trash":
            jmap = await _get_jmap()
            ids = _ensure_list(arguments["email_ids"])
            await jmap.trash(ids)
            return _text(f"Trashed {len(ids)} emails")

        elif name == "email_mark_read":
            jmap = await _get_jmap()
            ids = _ensure_list(arguments["email_ids"])
            await jmap.mark_read(ids)
            return _text(f"Marked {len(ids)} emails as read")

        elif name == "email_draft":
            jmap = await _get_jmap()
            draft_id = await jmap.create_draft(
                to=arguments["to"],
                subject=arguments["subject"],
                body=arguments["body"],
                cc=arguments.get("cc"),
            )
            return _text({"draft_id": draft_id, "status": "draft created"})

        elif name == "email_send":
            jmap = await _get_jmap()
            email_id = await jmap.send_email(
                to=arguments["to"],
                subject=arguments["subject"],
                body=arguments["body"],
                cc=arguments.get("cc"),
                attachment_paths=arguments.get("attachment_paths"),
            )
            return _text({"email_id": email_id, "status": "sent"})

        elif name == "email_attachments":
            jmap = await _get_jmap()
            email = await jmap.get_email(arguments["email_id"])
            return _text([a.summary_dict() for a in email.attachments])

        elif name == "email_attachment_save":
            import os
            jmap = await _get_jmap()
            email = await jmap.get_email(arguments["email_id"])
            # Find the attachment to get its metadata
            att = next((a for a in email.attachments if a.blob_id == arguments["blob_id"]), None)
            if not att:
                return _text({"error": f"blob_id {arguments['blob_id']} not found on email"})
            data = await jmap.download_blob(att.blob_id, content_type=att.type, name=att.name)
            dest = os.path.expanduser(arguments["dest_path"])
            os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
            with open(dest, "wb") as f:
                f.write(data)
            return _text({
                "saved": dest,
                "name": att.name,
                "type": att.type,
                "bytes": len(data),
            })

        # ── Calendar tools ───────────────────────────────────────
        elif name == "calendar_today":
            cal = _get_caldav()
            events = cal.get_today()
            return _text([e.summary_dict(local_tz=cal.local_tz) for e in events])

        elif name == "calendar_week":
            cal = _get_caldav()
            events = cal.get_week()
            return _text([e.summary_dict(local_tz=cal.local_tz) for e in events])

        elif name == "calendar_events":
            cal = _get_caldav()
            start = datetime.fromisoformat(arguments["start"]) if "start" in arguments else None
            end = datetime.fromisoformat(arguments["end"]) if "end" in arguments else None
            events = cal.get_events(
                start=start, end=end,
                calendar_name=arguments.get("calendar"),
            )
            return _text([e.summary_dict(local_tz=cal.local_tz) for e in events])

        elif name == "calendar_free":
            cal = _get_caldav()
            start = datetime.fromisoformat(arguments["start"]) if "start" in arguments else None
            end = datetime.fromisoformat(arguments["end"]) if "end" in arguments else None
            slots = cal.free_busy(
                start=start, end=end,
                slot_minutes=arguments.get("slot_minutes", 30),
            )
            return _text(slots)

        elif name == "calendar_create":
            cal = _get_caldav()
            # Detect all-day: bare date strings like "2026-05-05" (no T)
            raw_start = arguments["start"]
            raw_end = arguments["end"]
            is_all_day = "T" not in raw_start and "T" not in raw_end
            if is_all_day:
                start_val: date | datetime = date.fromisoformat(raw_start)
                end_val: date | datetime = date.fromisoformat(raw_end)
            else:
                start_val = datetime.fromisoformat(raw_start)
                end_val = datetime.fromisoformat(raw_end)
            event = cal.create_event(
                summary=arguments["summary"],
                start=start_val,
                end=end_val,
                location=arguments.get("location", ""),
                description=arguments.get("description", ""),
                calendar_name=arguments.get("calendar"),
                attendees=arguments.get("attendees"),
                all_day=is_all_day,
            )
            return _text(event.summary_dict(local_tz=cal.local_tz))

        elif name == "email_mailboxes":
            jmap = await _get_jmap()
            return _text(await jmap.list_mailboxes_enriched())

        elif name == "email_move":
            jmap = await _get_jmap()
            ids = _ensure_list(arguments["email_ids"])
            result = await jmap.move_emails_by_name(ids, arguments["to"])
            return _text({"moved": len(ids), **result})

        elif name == "email_label":
            jmap = await _get_jmap()
            ids = _ensure_list(arguments["email_ids"])
            labels = _ensure_list(arguments["labels"])
            add = arguments.get("add", True)
            return _text(await jmap.set_mailbox_memberships(ids, labels, add=add))

        elif name == "email_reply":
            jmap = await _get_jmap()
            return _text(await jmap.reply_to(
                email_id=arguments["email_id"],
                body=arguments["body"],
                send=arguments.get("send", False),
                include_quote=arguments.get("include_quote", False),
                cc=arguments.get("cc"),
            ))

        # ── Meta tools ───────────────────────────────────────────
        elif name == "courier_status":
            config = _get_config()
            state = _get_state()
            account = config.get_account()
            status = {
                "account": account.account_id,
                "provider": account.provider,
                "jmap_connected": _jmap is not None and _jmap.session is not None,
                "caldav_connected": _caldav is not None and bool(getattr(_caldav, '_calendars', None)),
            }

            # Include watermark info
            if _jmap and _jmap.session:
                try:
                    inbox_id = await _jmap.get_mailbox_id("inbox")
                    wm = state.get_watermark(_jmap.session.account_id, inbox_id)
                    if wm:
                        status["last_email_check"] = wm.last_seen_date
                except Exception:
                    pass

            return _text(status)

        else:
            return _text({"error": f"Unknown tool: {name}"})

    except Exception as e:
        return _text({"error": str(e), "tool": name})


# ── Entry point ──────────────────────────────────────────────────────

def main():
    """Run Courier as an MCP server over stdio."""
    async def _run():
        async with stdio_server() as (read, write):
            await app.run(read, write, app.create_initialization_options())

    asyncio.run(_run())


if __name__ == "__main__":
    main()
