"""Persistent state layer for Courier.

SQLite-backed storage for watermarks, triage classifications, and session state.
Designed for multi-account from the start (account_id on every table).
"""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass
class WatermarkInfo:
    """Tracks what's been seen per mailbox."""

    account_id: str
    mailbox_id: str
    last_seen_date: str  # ISO 8601
    last_seen_email_id: str
    updated_at: str


class StateStore:
    """SQLite-backed persistent state for Courier."""

    def __init__(self, db_path: Path | str):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path))
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        """Create tables if they don't exist."""
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS watermarks (
                account_id TEXT NOT NULL,
                mailbox_id TEXT NOT NULL,
                last_seen_date TEXT NOT NULL,
                last_seen_email_id TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL,
                PRIMARY KEY (account_id, mailbox_id)
            );

            CREATE TABLE IF NOT EXISTS triage (
                account_id TEXT NOT NULL,
                email_id TEXT NOT NULL,
                classification TEXT NOT NULL,
                confidence REAL NOT NULL DEFAULT 1.0,
                reason TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                PRIMARY KEY (account_id, email_id)
            );

            CREATE TABLE IF NOT EXISTS contact_signals (
                account_id TEXT NOT NULL,
                email_address TEXT NOT NULL,
                total_received INTEGER NOT NULL DEFAULT 0,
                total_sent INTEGER NOT NULL DEFAULT 0,
                last_received TEXT,
                last_sent TEXT,
                avg_reply_time_hours REAL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (account_id, email_address)
            );

            CREATE TABLE IF NOT EXISTS session_state (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
        """)

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    # ── Watermarks ───────────────────────────────────────────────────

    def get_watermark(self, account_id: str, mailbox_id: str) -> WatermarkInfo | None:
        """Get the watermark for a mailbox."""
        row = self._conn.execute(
            "SELECT * FROM watermarks WHERE account_id = ? AND mailbox_id = ?",
            (account_id, mailbox_id),
        ).fetchone()
        if not row:
            return None
        return WatermarkInfo(**dict(row))

    def set_watermark(
        self, account_id: str, mailbox_id: str, last_seen_date: str, last_seen_email_id: str = ""
    ) -> None:
        """Update the watermark for a mailbox."""
        self._conn.execute(
            """INSERT INTO watermarks (account_id, mailbox_id, last_seen_date, last_seen_email_id, updated_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT (account_id, mailbox_id) DO UPDATE SET
                last_seen_date = excluded.last_seen_date,
                last_seen_email_id = excluded.last_seen_email_id,
                updated_at = excluded.updated_at""",
            (account_id, mailbox_id, last_seen_date, last_seen_email_id, self._now()),
        )
        self._conn.commit()

    # ── Triage ───────────────────────────────────────────────────────

    def classify_email(
        self, account_id: str, email_id: str, classification: str,
        confidence: float = 1.0, reason: str = ""
    ) -> None:
        """Store triage classification for an email."""
        self._conn.execute(
            """INSERT INTO triage (account_id, email_id, classification, confidence, reason, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT (account_id, email_id) DO UPDATE SET
                classification = excluded.classification,
                confidence = excluded.confidence,
                reason = excluded.reason,
                created_at = excluded.created_at""",
            (account_id, email_id, classification, confidence, reason, self._now()),
        )
        self._conn.commit()

    def get_classification(self, account_id: str, email_id: str) -> dict[str, Any] | None:
        """Get triage classification for an email."""
        row = self._conn.execute(
            "SELECT * FROM triage WHERE account_id = ? AND email_id = ?",
            (account_id, email_id),
        ).fetchone()
        return dict(row) if row else None

    def get_classified_emails(
        self, account_id: str, classification: str | None = None
    ) -> list[dict[str, Any]]:
        """Get all classified emails, optionally filtered by classification."""
        if classification:
            rows = self._conn.execute(
                "SELECT * FROM triage WHERE account_id = ? AND classification = ? ORDER BY created_at DESC",
                (account_id, classification),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM triage WHERE account_id = ? ORDER BY created_at DESC",
                (account_id,),
            ).fetchall()
        return [dict(r) for r in rows]

    # ── Contact signals ──────────────────────────────────────────────

    def update_contact_signal(
        self, account_id: str, email_address: str,
        received: bool = False, sent: bool = False
    ) -> None:
        """Increment contact signal counters."""
        now = self._now()
        self._conn.execute(
            """INSERT INTO contact_signals
            (account_id, email_address, total_received, total_sent, last_received, last_sent, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (account_id, email_address) DO UPDATE SET
                total_received = contact_signals.total_received + ?,
                total_sent = contact_signals.total_sent + ?,
                last_received = CASE WHEN ? THEN ? ELSE contact_signals.last_received END,
                last_sent = CASE WHEN ? THEN ? ELSE contact_signals.last_sent END,
                updated_at = ?""",
            (
                account_id, email_address,
                1 if received else 0, 1 if sent else 0,
                now if received else None, now if sent else None, now,
                1 if received else 0, 1 if sent else 0,
                received, now, sent, now, now,
            ),
        )
        self._conn.commit()

    def get_contact_signal(self, account_id: str, email_address: str) -> dict[str, Any] | None:
        """Get contact signal data."""
        row = self._conn.execute(
            "SELECT * FROM contact_signals WHERE account_id = ? AND email_address = ?",
            (account_id, email_address),
        ).fetchone()
        return dict(row) if row else None

    def get_top_contacts(self, account_id: str, limit: int = 20) -> list[dict[str, Any]]:
        """Get most-interacted-with contacts."""
        rows = self._conn.execute(
            """SELECT *, (total_received + total_sent) as total_interactions
            FROM contact_signals WHERE account_id = ?
            ORDER BY total_interactions DESC LIMIT ?""",
            (account_id, limit),
        ).fetchall()
        return [dict(r) for r in rows]

    # ── Session state (generic key-value) ────────────────────────────

    def get_state(self, key: str) -> Any:
        """Get a session state value."""
        row = self._conn.execute(
            "SELECT value FROM session_state WHERE key = ?", (key,)
        ).fetchone()
        if not row:
            return None
        return json.loads(row["value"])

    def set_state(self, key: str, value: Any) -> None:
        """Set a session state value."""
        self._conn.execute(
            """INSERT INTO session_state (key, value, updated_at) VALUES (?, ?, ?)
            ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at""",
            (key, json.dumps(value), self._now()),
        )
        self._conn.commit()

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()
