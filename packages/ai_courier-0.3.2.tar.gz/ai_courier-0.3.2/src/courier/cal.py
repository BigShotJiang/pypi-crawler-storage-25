"""CalDAV calendar client with sane TZID handling.

Wraps python-caldav with timezone normalization, recurrence expansion,
and context-window-optimized output.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any
from zoneinfo import ZoneInfo

import caldav
from caldav.elements import dav

from .config import AccountConfig


@dataclass
class Event:
    """Context-window-optimized event representation."""

    uid: str
    summary: str
    start: datetime
    end: datetime
    location: str = ""
    description: str = ""
    attendees: list[str] = field(default_factory=list)
    organizer: str = ""
    status: str = ""  # CONFIRMED, TENTATIVE, CANCELLED
    is_recurring: bool = False
    recurrence_id: str | None = None
    calendar_name: str = ""
    raw_url: str = ""  # For mutations

    @property
    def duration_minutes(self) -> int:
        delta = self.end - self.start
        return int(delta.total_seconds() / 60)

    @property
    def is_all_day(self) -> bool:
        return (
            self.start.hour == 0 and self.start.minute == 0
            and self.end.hour == 0 and self.end.minute == 0
        )

    def summary_dict(self, local_tz: ZoneInfo | None = None) -> dict[str, Any]:
        """Token-efficient representation for context windows.

        If local_tz is provided, start/end are converted to that timezone
        for human-friendly output. Otherwise UTC is used.
        """
        start = self.start
        end = self.end
        if local_tz and not self.is_all_day:
            start = start.astimezone(local_tz)
            end = end.astimezone(local_tz)

        result: dict[str, Any] = {
            "uid": self.uid,
            "summary": self.summary,
            "start": start.isoformat(),
            "end": end.isoformat(),
            "duration_min": self.duration_minutes,
        }
        if self.location:
            result["location"] = self.location
        if self.calendar_name:
            result["calendar"] = self.calendar_name
        if self.attendees:
            result["attendees"] = self.attendees
        if self.status and self.status != "CONFIRMED":
            result["status"] = self.status
        if self.is_all_day:
            result["all_day"] = True
        return result


class CalDAVClient:
    """CalDAV client with timezone normalization."""

    def __init__(self, account: AccountConfig):
        self.account = account
        self._client: caldav.DAVClient | None = None
        self._calendar_home: Any | None = None
        # Local timezone for output — defaults to America/Chicago (CT)
        self.local_tz: ZoneInfo = ZoneInfo(getattr(account, "timezone", "America/Chicago"))

    def connect(self) -> None:
        """Connect to CalDAV server.

        Fastmail rejects principal discovery (405 on PROPFIND). We connect
        the DAVClient to the calendar-home-set URL directly and build
        Calendar objects from a raw PROPFIND response.
        """
        url = self.account.caldav_url
        if not url and self.account.provider == "fastmail":
            url = f"https://caldav.fastmail.com/dav/calendars/user/{self.account.username}/"
        if not url:
            raise ValueError("No caldav_url configured and can't auto-detect for this provider")
        self._client = caldav.DAVClient(
            url=url,
            username=self.account.username,
            password=self.account.app_password,
        )
        # Discover calendars via raw PROPFIND (bypasses broken principal discovery)
        self._calendars = self._discover_calendars(url)

    def create_calendar(self, name: str) -> None:
        """Create a calendar collection on the principal.

        `name` becomes the displayname; the URL slug is derived via
        ``name.lower().replace(" ", "-")``, so name must be a plain ASCII
        string without slashes or punctuation (e.g. "Courier Tests").

        Idempotent at caller's level — raises if the name already exists.
        """
        self._ensure_connected()
        # Build a new calendar URL under the home
        home_url = self.account.caldav_url or (
            f"https://caldav.fastmail.com/dav/calendars/user/{self.account.username}/"
        )
        # Use a slug derived from name (lowercase, no spaces)
        slug = name.lower().replace(" ", "-")
        cal_url = f"{home_url.rstrip('/')}/{slug}/"
        # MKCALENDAR request
        body = (
            '<?xml version="1.0" encoding="utf-8"?>'
            '<c:mkcalendar xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">'
            '<d:set><d:prop>'
            f'<d:displayname>{name}</d:displayname>'
            '</d:prop></d:set>'
            '</c:mkcalendar>'
        )
        response = self._client.request(
            cal_url, method="MKCALENDAR", body=body,
            headers={"Content-Type": "application/xml"},
        )
        if response.status >= 400 and response.status != 201:
            raise RuntimeError(
                f"MKCALENDAR failed (status {response.status}) — "
                f"does {name!r} already exist?"
            )
        # Refresh cache
        self._calendars = self._discover_calendars(home_url)

    def _discover_calendars(self, home_url: str) -> list:
        """PROPFIND the calendar-home-set and build Calendar objects.

        Uses the DAVClient's raw PROPFIND + lxml tree (response.tree)
        to bypass python-caldav's broken principal discovery on Fastmail.
        """
        body = (
            '<?xml version="1.0"?>'
            '<d:propfind xmlns:d="DAV:">'
            '<d:prop><d:resourcetype/><d:displayname/></d:prop>'
            '</d:propfind>'
        )
        response = self._client.request(home_url, method="PROPFIND", body=body, headers={"Depth": "1"})

        if response.status >= 400:
            raise ConnectionError(
                f"CalDAV PROPFIND failed with status {response.status}. "
                f"Check app_password and caldav_url."
            )

        from lxml import etree
        root = response.tree
        if root is None:
            # Fallback: parse raw bytes
            raw = response._raw if isinstance(response._raw, bytes) else response._raw.encode()
            root = etree.XML(raw, parser=etree.XMLParser(recover=True))

        DAV = "DAV:"
        CALDAV = "urn:ietf:params:xml:ns:caldav"
        calendars = []
        for resp in root.findall(f"{{{DAV}}}response"):
            href = resp.findtext(f"{{{DAV}}}href", "")
            # Skip the home-set collection itself
            home_path = home_url.replace("https://caldav.fastmail.com", "").rstrip("/")
            if href.rstrip("/") == home_path:
                continue
            # Only include resources with <calendar/> in resourcetype
            rt = resp.find(f".//{{{DAV}}}resourcetype")
            if rt is not None and rt.find(f"{{{CALDAV}}}calendar") is not None:
                name = resp.findtext(f".//{{{DAV}}}displayname", "")
                cal_url = f"https://caldav.fastmail.com{href}" if href.startswith("/") else href
                cal = caldav.Calendar(client=self._client, url=cal_url, name=name)
                calendars.append(cal)
        return calendars

    def _ensure_connected(self) -> None:
        if not hasattr(self, '_calendars') or not self._calendars:
            self.connect()

    def _normalize_dt(self, dt: Any) -> datetime:
        """Normalize any datetime-like to timezone-aware UTC datetime."""
        if isinstance(dt, date) and not isinstance(dt, datetime):
            # All-day event — treat as midnight UTC
            return datetime(dt.year, dt.month, dt.day, tzinfo=timezone.utc)
        if isinstance(dt, datetime):
            if dt.tzinfo is None:
                # Naive datetime — assume UTC
                return dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
        # String fallback
        return datetime.fromisoformat(str(dt)).astimezone(timezone.utc)

    def _parse_event(self, vevent: Any, calendar_name: str = "") -> Event:
        """Parse a vEvent into our optimized representation."""
        comp = vevent.vobject_instance.vevent

        start = self._normalize_dt(comp.dtstart.value)
        end = start  # Default
        if hasattr(comp, "dtend"):
            end = self._normalize_dt(comp.dtend.value)
        elif hasattr(comp, "duration"):
            end = start + comp.duration.value

        attendees = []
        if hasattr(comp, "attendee"):
            att_list = comp.attendee if isinstance(comp.attendee, list) else [comp.attendee]
            for att in att_list:
                addr = str(att.value).replace("mailto:", "").replace("MAILTO:", "")
                attendees.append(addr)

        organizer = ""
        if hasattr(comp, "organizer"):
            organizer = str(comp.organizer.value).replace("mailto:", "").replace("MAILTO:", "")

        return Event(
            uid=str(comp.uid.value) if hasattr(comp, "uid") else "",
            summary=str(comp.summary.value) if hasattr(comp, "summary") else "",
            start=start,
            end=end,
            location=str(comp.location.value) if hasattr(comp, "location") else "",
            description=str(comp.description.value) if hasattr(comp, "description") else "",
            attendees=attendees,
            organizer=organizer,
            status=str(comp.status.value) if hasattr(comp, "status") else "CONFIRMED",
            is_recurring=hasattr(comp, "rrule"),
            recurrence_id=str(comp.recurrence_id.value) if hasattr(comp, "recurrence_id") else None,
            calendar_name=calendar_name,
            raw_url=str(vevent.url) if hasattr(vevent, "url") else "",
        )

    # ── Query operations ─────────────────────────────────────────────

    def list_calendars(self) -> list[dict[str, str]]:
        """List available calendars."""
        self._ensure_connected()
        calendars = self._calendars
        return [{"name": c.name, "url": str(c.url)} for c in calendars]

    def get_events(
        self,
        start: datetime | date | None = None,
        end: datetime | date | None = None,
        calendar_name: str | None = None,
        expand_recurring: bool = True,
    ) -> list[Event]:
        """Get events in a date range. Recurrence expanded by default.

        If no range specified, defaults to today + 7 days.
        """
        self._ensure_connected()

        if start is None:
            start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        if end is None:
            end = self._normalize_dt(start) + timedelta(days=7)

        start = self._normalize_dt(start)
        end = self._normalize_dt(end)

        calendars = self._calendars
        if calendar_name:
            calendars = [c for c in calendars if c.name == calendar_name]

        events: list[Event] = []
        for cal in calendars:
            try:
                results = cal.date_search(
                    start=start, end=end, expand=expand_recurring
                )
                for vevent in results:
                    try:
                        events.append(self._parse_event(vevent, cal.name))
                    except Exception:
                        continue  # Skip malformed events
            except Exception:
                continue  # Skip inaccessible calendars

        # Deduplicate by (uid, recurrence_id) — same event appearing
        # in multiple calendars or via sync duplicates.
        events = self._deduplicate_events(events)

        # Sort chronologically
        events.sort(key=lambda e: e.start)
        return events

    @staticmethod
    def _deduplicate_events(events: list[Event]) -> list[Event]:
        """Remove duplicate events. Keeps first seen per (uid, recurrence_id)."""
        seen: dict[tuple[str, str], Event] = {}
        for e in events:
            if not e.uid:
                # No UID — can't deduplicate, keep it
                seen[(""  , id(e).__str__())] = e
                continue
            key = (e.uid, e.recurrence_id or "")
            if key not in seen:
                seen[key] = e
        return list(seen.values())

    def get_today(self) -> list[Event]:
        """Get today's events."""
        now = datetime.now(timezone.utc)
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        return self.get_events(start=start, end=end)

    def get_week(self) -> list[Event]:
        """Get this week's events (today through +7 days)."""
        return self.get_events()  # Default is 7 days

    def free_busy(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
        slot_minutes: int = 30,
        localize: bool = True,
        working_hours: tuple[int, int] | None = None,
        working_days: tuple[int, ...] = (0, 1, 2, 3, 4),  # Mon-Fri
    ) -> list[dict[str, Any]]:
        """Find free time slots in a date range.

        Returns list of free slots as {start, end, duration_min}.
        If localize=True, times are converted to self.local_tz.

        working_hours: (start_hour, end_hour) in local tz. Pass None to disable
          the constraint and return 24/7 gaps.
        working_days: weekday ints (Mon=0..Sun=6). Default Mon-Fri.
        """
        if start is None:
            start = datetime.now(timezone.utc)
        if end is None:
            end = start + timedelta(days=7)

        events = self.get_events(start=start, end=end)

        # Build list of busy periods
        busy = [(e.start, e.end) for e in events if not e.is_all_day]
        busy.sort(key=lambda x: x[0])

        # Merge overlapping
        merged: list[tuple[datetime, datetime]] = []
        for b_start, b_end in busy:
            if merged and b_start <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], b_end))
            else:
                merged.append((b_start, b_end))

        # Find raw gaps
        raw_gaps: list[tuple[datetime, datetime]] = []
        current = start
        for b_start, b_end in merged:
            if current < b_start:
                raw_gaps.append((current, b_start))
            current = max(current, b_end)
        if current < end:
            raw_gaps.append((current, end))

        # Split/trim gaps by working hours (local tz) and working days
        tz = self.local_tz if localize else timezone.utc
        constrained: list[tuple[datetime, datetime]] = []
        if working_hours is None:
            constrained = raw_gaps
        else:
            wh_start, wh_end = working_hours
            for g_start, g_end in raw_gaps:
                gs_local = g_start.astimezone(tz)
                ge_local = g_end.astimezone(tz)
                # Walk day-by-day
                day = gs_local.date()
                while day <= ge_local.date():
                    if day.weekday() in working_days:
                        day_open = datetime.combine(
                            day, datetime.min.time(), tzinfo=tz
                        ).replace(hour=wh_start)
                        day_close = datetime.combine(
                            day, datetime.min.time(), tzinfo=tz
                        ).replace(hour=wh_end)
                        slot_s = max(gs_local, day_open)
                        slot_e = min(ge_local, day_close)
                        if slot_s < slot_e:
                            constrained.append((slot_s, slot_e))
                    day += timedelta(days=1)

        # Emit slots meeting min duration
        out_tz = self.local_tz if localize else None
        free: list[dict[str, Any]] = []
        for s_dt, e_dt in constrained:
            gap_minutes = int((e_dt - s_dt).total_seconds() / 60)
            if gap_minutes >= slot_minutes:
                s = s_dt.astimezone(out_tz) if out_tz else s_dt
                e = e_dt.astimezone(out_tz) if out_tz else e_dt
                free.append({
                    "start": s.isoformat(),
                    "end": e.isoformat(),
                    "duration_min": gap_minutes,
                })
        return free

    # ── Mutation operations ──────────────────────────────────────────

    def create_event(
        self,
        summary: str,
        start: datetime | date,
        end: datetime | date,
        calendar_name: str | None = None,
        location: str = "",
        description: str = "",
        attendees: list[str] | None = None,
        all_day: bool = False,
    ) -> Event:
        """Create a new calendar event.

        For all-day events, pass date objects (not datetime) or set all_day=True.
        All-day events use VALUE=DATE per RFC 5545 §3.6.1, with DTEND set to
        the day *after* the last day of the event.
        """
        self._ensure_connected()

        calendars = self._calendars
        cal = calendars[0]  # Default
        if calendar_name:
            for c in calendars:
                if c.name == calendar_name:
                    cal = c
                    break

        # Build iCalendar string
        attendee_lines = ""
        if attendees:
            for addr in attendees:
                attendee_lines += f"\nATTENDEE;RSVP=TRUE:mailto:{addr}"

        # Detect all-day: explicit flag, or both start/end are date (not datetime)
        is_all_day = all_day or (
            isinstance(start, date) and not isinstance(start, datetime)
            and isinstance(end, date) and not isinstance(end, datetime)
        )

        if is_all_day:
            # Coerce to date if datetime was passed
            start_date = start if isinstance(start, date) and not isinstance(start, datetime) else start.date() if isinstance(start, datetime) else start
            end_date = end if isinstance(end, date) and not isinstance(end, datetime) else end.date() if isinstance(end, datetime) else end
            # RFC 5545: DTEND is exclusive — a 1-day event on May 5 needs
            # DTEND:20260506. If start == end, bump end by 1 day.
            if end_date <= start_date:
                end_date = start_date + timedelta(days=1)
            dt_start_line = f"DTSTART;VALUE=DATE:{start_date.strftime('%Y%m%d')}"
            dt_end_line = f"DTEND;VALUE=DATE:{end_date.strftime('%Y%m%d')}"
        else:
            # Timed event — ensure datetime, normalize to UTC
            if isinstance(start, date) and not isinstance(start, datetime):
                start = datetime(start.year, start.month, start.day, tzinfo=timezone.utc)
            if isinstance(end, date) and not isinstance(end, datetime):
                end = datetime(end.year, end.month, end.day, tzinfo=timezone.utc)
            dt_start_line = f"DTSTART:{start.strftime('%Y%m%dT%H%M%SZ')}"
            dt_end_line = f"DTEND:{end.strftime('%Y%m%dT%H%M%SZ')}"

        ical = f"""BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Courier//AI-Native Calendar//EN
BEGIN:VEVENT
SUMMARY:{summary}
{dt_start_line}
{dt_end_line}
LOCATION:{location}
DESCRIPTION:{description}{attendee_lines}
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR"""

        vevent = cal.save_event(ical)
        return self._parse_event(vevent, cal.name)

    def delete_event(self, uid: str) -> bool:
        """Delete an event by UID."""
        self._ensure_connected()
        for cal in self._calendars:
            try:
                event = cal.event_by_uid(uid)
                event.delete()
                return True
            except Exception:
                continue
        return False
