"""Courier CLI — for testing and debugging.

Usage:
    courier setup              Configure Fastmail account
    courier inbox              Show triaged inbox
    courier new                Show new emails since last check
    courier search <query>     Search emails
    courier read <email_id>    Read a specific email
    courier today              Today's calendar
    courier week               This week's calendar
    courier free               Find free time slots
    courier status             Connection & watermark status
"""

from __future__ import annotations

import argparse
import asyncio
import getpass
import json
import sys
from pathlib import Path

from .config import AccountConfig, CourierConfig, DEFAULT_CONFIG_DIR
from .jmap import JMAPClient
from .state import StateStore
from .triage import classify_batch


def _print_json(data):
    print(json.dumps(data, indent=2, default=str))


async def cmd_setup(args):
    """Interactive account setup."""
    print("Courier Setup — Fastmail Account")
    print("=" * 40)
    print()
    print("You'll need TWO credentials from Fastmail:")
    print()
    print("1. API token (for email/JMAP):")
    print("   Settings → Privacy & Security → API tokens")
    print("   Scope: Mail (+ Contacts if desired)")
    print()
    print("2. App password (for calendar/CalDAV):")
    print("   Settings → Privacy & Security → Third-party apps")
    print("   Create new → any name, allow CalDAV access")
    print()

    username = input("Fastmail username (email): ").strip()
    token = getpass.getpass("API token (for email): ").strip()
    app_pw = getpass.getpass("App password (for calendar): ").strip()

    account = AccountConfig(
        account_id="fastmail",
        provider="fastmail",
        api_token=token,
        app_password=app_pw,
        username=username,
    )

    # Test connection
    print("\nTesting JMAP connection...")
    client = JMAPClient(account)
    try:
        session = await client.connect()
        print(f"  Connected. Account ID: {session.account_id}")
        mailboxes = await client.get_mailboxes()
        print(f"  Found {len(mailboxes)} mailboxes")
        await client.close()
    except Exception as e:
        print(f"  Failed: {e}")
        return

    # Test CalDAV connection
    if app_pw:
        print("\nTesting CalDAV connection...")
        from .cal import CalDAVClient
        cal_client = CalDAVClient(account)
        try:
            cal_client.connect()
            calendars = cal_client.list_calendars()
            print(f"  Connected. Found {len(calendars)} calendars")
        except Exception as e:
            print(f"  Failed: {e}")
            print("  Calendar features won't work until this is fixed.")

    # Save config
    config = CourierConfig(
        accounts={"fastmail": account},
        default_account="fastmail",
    )
    config.save()
    print(f"\nConfig saved to {DEFAULT_CONFIG_DIR / 'config.json'}")
    print("Ready. Try: courier inbox")


async def cmd_test_setup(args):
    """Create the E2E test sandbox: Courier/Tests mailbox + Courier Tests calendar."""
    from .cal import CalDAVClient

    config = CourierConfig.load()
    account = config.get_account()

    # Mailbox sandbox
    async with JMAPClient(account) as jmap:
        mailboxes = await jmap.get_mailboxes()

        # Ensure parent "Courier"
        courier_parent = next(
            (mb for mb in mailboxes if mb.get("name") == "Courier" and not mb.get("parentId")),
            None,
        )
        if courier_parent:
            print(f"Parent mailbox 'Courier' exists (id={courier_parent['id']})")
            parent_id = courier_parent["id"]
        else:
            parent_id = await jmap.create_mailbox("Courier")
            print(f"Created parent mailbox 'Courier' (id={parent_id})")

        # Ensure child "Tests"
        tests_mb = next(
            (
                mb for mb in mailboxes
                if mb.get("name") == "Tests" and mb.get("parentId") == parent_id
            ),
            None,
        )
        if tests_mb:
            print(f"Test mailbox 'Courier/Tests' exists (id={tests_mb['id']})")
        else:
            tid = await jmap.create_mailbox("Tests", parent_id=parent_id)
            print(f"Created 'Courier/Tests' mailbox (id={tid})")

    # Calendar sandbox
    cal = CalDAVClient(account)
    cal.connect()
    cal_exit_code = 0
    if any(c.get("name") == "Courier Tests" for c in cal.list_calendars()):
        print("Calendar 'Courier Tests' exists.")
    else:
        try:
            cal.create_calendar("Courier Tests")
            print("Created calendar 'Courier Tests'.")
        except RuntimeError as e:
            print(f"Calendar create failed: {e}")
            cal_exit_code = 1

    if cal_exit_code:
        print("\nSandbox INCOMPLETE — calendar step failed. Fix before running tests.")
        import sys
        sys.exit(cal_exit_code)

    print("\nSandbox ready. Run tests with: COURIER_LIVE_TESTS=1 pytest tests/e2e/")


async def cmd_inbox(args):
    """Show triaged inbox."""
    config = CourierConfig.load()
    account = config.get_account()
    state = StateStore(config.db_path)

    async with JMAPClient(account) as jmap:
        emails = await jmap.list_emails(limit=args.limit)
        if args.unread:
            emails = [e for e in emails if e.is_unread]

        buckets = classify_batch(emails, state, jmap.session.account_id)

        for classification, items in buckets.items():
            if items:
                print(f"\n{'=' * 60}")
                print(f"  {classification.upper()} ({len(items)})")
                print(f"{'=' * 60}")
                for email, triage in items:
                    flag = "★" if email.is_flagged else " "
                    unread = "●" if email.is_unread else " "
                    print(f"  {unread}{flag} {email.from_name or email.from_address}")
                    print(f"     {email.subject}")
                    print(f"     {email.date[:16]}  [{triage.reason}]")
                    print(f"     id:{email.id}")
                    print()

    state.close()


async def cmd_new(args):
    """Show new emails since last check."""
    config = CourierConfig.load()
    account = config.get_account()
    state = StateStore(config.db_path)

    async with JMAPClient(account) as jmap:
        account_id = jmap.session.account_id
        inbox_id = await jmap.get_mailbox_id("inbox")
        watermark = state.get_watermark(account_id, inbox_id)

        emails = await jmap.list_emails(mailbox_id=inbox_id, limit=args.limit)

        if watermark:
            emails = [e for e in emails if e.date > watermark.last_seen_date]
            if not emails:
                print("No new emails since last check.")
                print(f"  Last check: {watermark.last_seen_date}")
                state.close()
                return

        if emails:
            newest = max(emails, key=lambda e: e.date)
            state.set_watermark(account_id, inbox_id, newest.date, newest.id)

        print(f"{len(emails)} new email(s)\n")
        for e in emails:
            unread = "●" if e.is_unread else " "
            print(f"  {unread} {e.from_name or e.from_address}: {e.subject}")
            print(f"     {e.date[:16]}  id:{e.id}")
            print()

    state.close()


async def cmd_search(args):
    """Search emails."""
    config = CourierConfig.load()
    account = config.get_account()

    async with JMAPClient(account) as jmap:
        emails = await jmap.search_emails(
            query=args.query,
            from_addr=args.from_addr,
            limit=args.limit,
        )
        print(f"{len(emails)} result(s)\n")
        for e in emails:
            print(f"  {e.from_name or e.from_address}: {e.subject}")
            print(f"     {e.date[:16]}  id:{e.id}")
            print()


async def cmd_read(args):
    """Read a specific email."""
    config = CourierConfig.load()
    account = config.get_account()

    async with JMAPClient(account) as jmap:
        email = await jmap.get_email(args.email_id)
        print(f"From: {email.from_name} <{email.from_address}>")
        print(f"To: {', '.join(email.to)}")
        if email.cc:
            print(f"CC: {', '.join(email.cc)}")
        print(f"Subject: {email.subject}")
        print(f"Date: {email.date}")
        if email.attachments:
            print(f"Attachments ({len(email.attachments)}):")
            for a in email.attachments:
                print(f"  • {a.name}  ({a.type}, {a.size} bytes)  blob:{a.blob_id}")
        print(f"{'─' * 60}")
        print(email.body_text)


async def cmd_attachments(args):
    """List attachments on an email."""
    config = CourierConfig.load()
    account = config.get_account()
    async with JMAPClient(account) as jmap:
        email = await jmap.get_email(args.email_id)
        if not email.attachments:
            print("No attachments.")
            return
        print(f"{len(email.attachments)} attachment(s) on {args.email_id}:")
        for a in email.attachments:
            print(f"  • {a.name}  ({a.type}, {a.size} bytes)")
            print(f"    blob_id: {a.blob_id}")


async def cmd_download(args):
    """Download an attachment to a local path."""
    import os
    config = CourierConfig.load()
    account = config.get_account()
    async with JMAPClient(account) as jmap:
        email = await jmap.get_email(args.email_id)
        if not email.attachments:
            print("No attachments on that email.")
            return
        # Resolve which attachment
        att = None
        if args.blob:
            att = next((a for a in email.attachments if a.blob_id == args.blob), None)
        elif args.name:
            att = next((a for a in email.attachments if a.name == args.name), None)
        elif len(email.attachments) == 1:
            att = email.attachments[0]
        if not att:
            print("Multiple attachments — specify --blob or --name:")
            for a in email.attachments:
                print(f"  • {a.name}  (blob:{a.blob_id})")
            return
        # Resolve destination
        dest = os.path.expanduser(args.dest)
        if os.path.isdir(dest):
            dest = os.path.join(dest, att.name)
        os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
        data = await jmap.download_blob(att.blob_id, content_type=att.type, name=att.name)
        with open(dest, "wb") as f:
            f.write(data)
        print(f"Saved {len(data)} bytes → {dest}")


async def cmd_today(args):
    """Show today's calendar."""
    from .cal import CalDAVClient

    config = CourierConfig.load()
    account = config.get_account()
    cal = CalDAVClient(account)
    cal.connect()

    events = cal.get_today()
    if not events:
        print("No events today.")
        return

    print(f"Today — {len(events)} event(s)\n")
    for e in events:
        if e.is_all_day:
            print(f"  ALL DAY  {e.summary}")
        else:
            start = e.start.strftime("%H:%M")
            end = e.end.strftime("%H:%M")
            print(f"  {start}–{end}  {e.summary} ({e.duration_minutes}min)")
        if e.location:
            print(f"           📍 {e.location}")
        print()


async def cmd_week(args):
    """Show this week's calendar."""
    from .cal import CalDAVClient

    config = CourierConfig.load()
    account = config.get_account()
    cal = CalDAVClient(account)
    cal.connect()

    events = cal.get_week()
    if not events:
        print("No events this week.")
        return

    current_day = None
    for e in events:
        day = e.start.strftime("%A %b %d")
        if day != current_day:
            current_day = day
            print(f"\n{'─' * 40}")
            print(f"  {day}")
            print(f"{'─' * 40}")

        if e.is_all_day:
            print(f"  ALL DAY  {e.summary}")
        else:
            start = e.start.strftime("%H:%M")
            end = e.end.strftime("%H:%M")
            print(f"  {start}–{end}  {e.summary}")


async def cmd_free(args):
    """Find free time slots."""
    from .cal import CalDAVClient
    from datetime import datetime, timezone

    config = CourierConfig.load()
    account = config.get_account()
    cal = CalDAVClient(account)
    cal.connect()

    wh = None if args.all_hours else (args.start_hour, args.end_hour)
    slots = cal.free_busy(slot_minutes=args.min_minutes, working_hours=wh)
    if not slots:
        print("No free slots found.")
        return

    print(f"Free slots (≥{args.min_minutes}min):\n")
    for s in slots:
        s_dt = datetime.fromisoformat(s["start"])
        e_dt = datetime.fromisoformat(s["end"])
        start = s_dt.strftime("%a %b %d %H:%M")
        # Show end date when slot crosses midnight
        if s_dt.date() == e_dt.date():
            end = e_dt.strftime("%H:%M")
        else:
            end = e_dt.strftime("%a %b %d %H:%M")
        print(f"  {start}–{end}  ({s['duration_min']}min)")


async def cmd_status(args):
    """Show connection status."""
    config = CourierConfig.load()
    state = StateStore(config.db_path)

    if not config.accounts:
        print("No accounts configured. Run: courier setup")
        return

    for aid, account in config.accounts.items():
        print(f"Account: {aid}")
        print(f"  Provider: {account.provider}")
        print(f"  Username: {account.username}")

        # Test JMAP
        try:
            client = JMAPClient(account)
            session = await client.connect()
            mailboxes = await client.get_mailboxes()
            inbox = [m for m in mailboxes if m.get("role") == "inbox"]
            inbox_count = inbox[0].get("totalEmails", "?") if inbox else "?"
            print(f"  JMAP: connected (account {session.account_id}, {inbox_count} emails)")
            await client.close()
        except Exception as e:
            print(f"  JMAP: error — {e}")

        # Watermark info
        wm = state.get_watermark(aid, "inbox")
        if wm:
            print(f"  Last email check: {wm.last_seen_date}")
        else:
            print(f"  Last email check: never")

    state.close()


async def cmd_mailboxes(args):
    """List mailboxes."""
    config = CourierConfig.load()
    account = config.get_account()
    async with JMAPClient(account) as jmap:
        for mb in await jmap.list_mailboxes_enriched():
            role = f" [{mb['role']}]" if mb["role"] else ""
            print(f"  {mb['path']:40}  {mb['id']}{role}")


async def cmd_move(args):
    """Move email(s) to a folder."""
    config = CourierConfig.load()
    account = config.get_account()
    async with JMAPClient(account) as jmap:
        result = await jmap.move_emails_by_name([args.email_id], args.folder)
        print(f"Moved {args.email_id} → {result['mailbox_name']} ({result['mailbox_id']})")


async def cmd_label(args):
    config = CourierConfig.load()
    account = config.get_account()
    async with JMAPClient(account) as jmap:
        await jmap.set_mailbox_memberships(
            [args.email_id], [args.label], add=not args.remove
        )
        verb = "Removed" if args.remove else "Added"
        print(f"{verb} label {args.label} on {args.email_id}")


async def cmd_reply(args):
    config = CourierConfig.load()
    account = config.get_account()

    body = args.body
    if not body and not args.stdin:
        print("Enter reply body, end with Ctrl-D:")
    if args.stdin or not body:
        import sys
        body = sys.stdin.read()

    async with JMAPClient(account) as jmap:
        result = await jmap.reply_to(
            email_id=args.email_id,
            body=body,
            send=args.send,
            include_quote=args.include_quote,
        )
        print(f"Reply {result['status']}: {result['id']}")


async def cmd_test_cleanup(args):
    """Sweep stray E2E test artifacts (default prefix: '[courier-e2e') to Trash."""
    config = CourierConfig.load()
    account = config.get_account()
    async with JMAPClient(account) as jmap:
        result = await jmap.test_cleanup(prefix=args.prefix, dry_run=args.dry_run)
    if args.dry_run:
        print(
            f"Would trash {result['to_trash']} of {result['found']} matching messages "
            f"(subject prefix {args.prefix!r}). Re-run without --dry-run to apply."
        )
    else:
        print(
            f"Trashed {result['trashed']} of {result['found']} matching messages "
            f"(subject prefix {args.prefix!r})."
        )


def main():
    parser = argparse.ArgumentParser(
        prog="courier",
        description="Courier — AI-native email & calendar client",
    )
    sub = parser.add_subparsers(dest="command")

    # setup
    sub.add_parser("setup", help="Configure Fastmail account")

    sub.add_parser("test-setup", help="Create E2E test sandbox (Courier/Tests + Courier Tests)")

    # inbox
    p = sub.add_parser("inbox", help="Show triaged inbox")
    p.add_argument("-n", "--limit", type=int, default=50)
    p.add_argument("-u", "--unread", action="store_true")

    # new
    p = sub.add_parser("new", help="New emails since last check")
    p.add_argument("-n", "--limit", type=int, default=50)

    # search
    p = sub.add_parser("search", help="Search emails")
    p.add_argument("query", nargs="?")
    p.add_argument("-f", "--from-addr")
    p.add_argument("-n", "--limit", type=int, default=50)

    # read
    p = sub.add_parser("read", help="Read an email")
    p.add_argument("email_id")

    # today
    sub.add_parser("today", help="Today's calendar")

    # week
    sub.add_parser("week", help="This week's calendar")

    # free
    p = sub.add_parser("free", help="Find free time slots")
    p.add_argument("-m", "--min-minutes", type=int, default=30)
    p.add_argument("--all-hours", action="store_true",
                   help="Include 24/7 gaps (default: Mon-Fri 9-17 local)")
    p.add_argument("--start-hour", type=int, default=9)
    p.add_argument("--end-hour", type=int, default=17)

    # attachments
    p = sub.add_parser("attachments", help="List attachments on an email")
    p.add_argument("email_id")

    # download
    p = sub.add_parser("download", help="Download an attachment to a local path")
    p.add_argument("email_id")
    p.add_argument("dest", help="Destination path (dir → use attachment name; file → use path)")
    p.add_argument("--blob", help="Specific blob ID (default: prompt if >1 attachment)")
    p.add_argument("--name", help="Match by filename instead of blob ID")

    # mailboxes
    sub.add_parser("mailboxes", help="List folders/labels")

    # move
    p = sub.add_parser("move", help="Move email to folder")
    p.add_argument("email_id")
    p.add_argument("folder", help="Mailbox ID, name, or path (e.g. 'Clients/Guardian')")

    # label
    p = sub.add_parser("label", help="Add/remove a label")
    p.add_argument("email_id")
    p.add_argument("label")
    p.add_argument("--remove", action="store_true")

    # reply
    p = sub.add_parser("reply", help="Reply to an email")
    p.add_argument("email_id")
    p.add_argument("body", nargs="?", help="Reply text; if omitted, reads stdin")
    p.add_argument("--send", action="store_true", help="Send immediately (default: draft)")
    p.add_argument("--include-quote", action="store_true", help="Prepend quoted original")
    p.add_argument("--stdin", action="store_true", help="Read body from stdin")

    # test-cleanup
    p = sub.add_parser(
        "test-cleanup",
        help="Sweep stray E2E test artifacts ([courier-e2e*]) to Trash",
    )
    p.add_argument(
        "--prefix",
        default="[courier-e2e",
        help="Subject prefix to match (default: '[courier-e2e')",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Report counts without trashing",
    )

    # status
    sub.add_parser("status", help="Connection status")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return

    cmd_map = {
        "setup": cmd_setup,
        "test-setup": cmd_test_setup,
        "inbox": cmd_inbox,
        "new": cmd_new,
        "search": cmd_search,
        "read": cmd_read,
        "today": cmd_today,
        "week": cmd_week,
        "free": cmd_free,
        "attachments": cmd_attachments,
        "download": cmd_download,
        "mailboxes": cmd_mailboxes,
        "move": cmd_move,
        "label": cmd_label,
        "reply": cmd_reply,
        "test-cleanup": cmd_test_cleanup,
        "status": cmd_status,
    }

    asyncio.run(cmd_map[args.command](args))


if __name__ == "__main__":
    main()
