"""Courier — AI-native email & calendar client over JMAP and CalDAV."""

__version__ = "0.3.2"
