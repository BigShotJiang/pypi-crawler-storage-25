from typing import NamedTuple
from .N1081B_sdk import N1081B  # noqa: F401


class _VersionInfo(NamedTuple):
    major: int
    minor: int
    micro: int
    releaselevel: str
    serial: int

    @property
    def version_str(self) -> str:
        release_level = f".{self.releaselevel}" if self.releaselevel else ""
        return f"{self.major}.{self.minor}.{self.micro}{release_level}"


# Leave version as a placeholder,
# it will be updated by the release process.
__version_info__ = _VersionInfo(
    major=1,
    minor=0,
    micro=2,
    releaselevel='cicd-job',
    serial=0,
)

__package_name__ = "n1081b-sdk"
__version__ = __version_info__.version_str
VERSION = __version__  # synonym for backwards compatibility
