import re
import uuid
from collections import Counter
from collections.abc import Iterable
from datetime import datetime
from typing import Any, TypeVar

import geojson
from dateutil.parser import ParserError, parse

from capella_console_client.enumerations import AssetType, ProductType, SquintMode
from capella_console_client.logconf import logger

STAC_ID_REGEX_STRICT = re.compile("^CAPELLA_C\\d{2}_\\w+_\\w+_\\w{2}_\\d{14}_\\d{14}$")


def _validate_uuid(uuid_str: str) -> None:
    try:
        uuid.UUID(uuid_str)
    except ValueError as e:
        raise ValueError(f"{uuid_str} is not a valid uuid: {e}")


def _validate_uuids(uuid_strs: list[str]) -> None:
    if len(uuid_strs) == 0:
        raise ValueError("No UUIDs provided")
    for uuid_str in uuid_strs:
        _validate_uuid(uuid_str)


def _validate_stac_id_or_stac_items(
    stac_ids: list[str] | None = None,
    items: Iterable[dict[str, Any]] | None = None,
) -> list[str]:
    if not stac_ids and not items:
        raise ValueError("Please provide stac_ids or items")

    if not stac_ids:
        if items is None:
            raise ValueError("items must be provided when stac_ids is not provided")
        stac_ids = [f["id"] for f in items]

    return stac_ids


def _validate_and_filter_product_types(
    product_types: list[str] | str | None,
) -> list[str] | None:
    if isinstance(product_types, str):
        product_types = [product_types]
    if not product_types:
        return None
    return [p.upper() for p in product_types if p.upper() in ProductType]


def _validate_and_filter_asset_types(
    asset_types: list[str] | str | None,
) -> list[str] | None:
    if not asset_types:
        return None
    if isinstance(asset_types, str):
        return [a for a in [asset_types] if a in AssetType]
    return [a for a in asset_types if a in AssetType]


def _validate_and_filter_stac_ids(stac_ids: list[str] | None) -> list[str]:
    if not stac_ids:
        return []

    valid_stac_ids = list(set(filter(STAC_ID_REGEX_STRICT.match, stac_ids)))

    diff = set(stac_ids) - set(valid_stac_ids)
    if diff:
        logger.warning(f"filtered {','.join(diff)} (no valid STAC id)")

    if not valid_stac_ids:
        logger.warning("No valid STAC id provided")
        return []

    duplicates = [k for k, v in Counter(stac_ids).items() if v > 1]
    if duplicates:
        logger.warning(f"filtered {','.join(duplicates)} (duplicate)")

    return valid_stac_ids


def _snake_to_camel(snake):
    REG = r"(.*?)_([a-zA-Z])"
    return re.sub(REG, lambda x: x.group(1) + x.group(2).upper(), snake)


def _datetime_to_iso8601_str(dt: datetime | str) -> str:
    dt_value: datetime
    if isinstance(dt, str):
        try:
            dt_value = parse(dt)
        except ParserError:
            raise ValueError(f"Could not parse {dt} string into a datetime")
    else:
        dt_value = dt
    return dt_value.replace(tzinfo=None).isoformat(timespec="milliseconds") + "Z"


def _set_squint_default(geometry: geojson.geometry.Geometry) -> SquintMode:
    is_point_request = geometry["type"] == "Point"

    if is_point_request:
        return SquintMode.ENABLED

    return SquintMode.DISABLED


T = TypeVar("T")


def _compact_unique(items: Iterable[T | None]) -> list[T]:
    """Return unique non-None values from iterable, preserving order."""
    seen = set()
    result = []
    for item in items:
        if item is not None and item not in seen:
            seen.add(item)
            result.append(item)
    return result
