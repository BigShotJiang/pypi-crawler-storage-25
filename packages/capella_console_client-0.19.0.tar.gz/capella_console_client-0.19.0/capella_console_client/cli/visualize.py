from collections import defaultdict
from typing import Any

import typer
from tabulate import tabulate

from capella_console_client.cli.config import (
    CURRENT_SETTINGS,
)
from capella_console_client.config import (
    STAC_PREFIXED_BY_QUERY_FIELDS,
)
from capella_console_client.search import StacSearchResult


def show_tabulated(
    stac_items: StacSearchResult,
    search_headers: list[str] | None = None,
    show_row_number: bool = False,
):
    if not search_headers:
        search_headers = CURRENT_SETTINGS["search_headers"]  # type: ignore

    table_data = defaultdict(list)

    if search_headers is None:
        raise ValueError("search_headers could not be resolved from settings")
    # force id left if specified
    if "id" in search_headers:
        del search_headers[search_headers.index("id")]
        search_headers.insert(0, "id")

    if show_row_number:
        table_data["#"] = list(range(1, len(stac_items) + 1))

    for field in search_headers:
        for it in stac_items:
            if field in STAC_PREFIXED_BY_QUERY_FIELDS:
                value = it["properties"].get(STAC_PREFIXED_BY_QUERY_FIELDS[field])
            else:
                value = it["properties"].get(field)
                if value is None:
                    value = it.get(field, "n/a")

            if value is not None:
                table_data[field].append(value)

    typer.echo(tabulate(table_data, tablefmt="fancy_grid", headers="keys"))
    typer.echo("\n")


def show_orders_tabulated(orders: list[dict[str, Any]]):
    fields = ["orderId", "orderDate", "expirationDate", "orderStatus"]
    table_data = []
    for i, order in enumerate(orders):
        cur = [i + 1]
        cur.extend(order[field] for field in fields)
        granules = [o["granuleId"] for o in order["items"]]
        cur.append("\n".join(granules))  # type: ignore
        table_data.append(cur)

    headers = ["#", *fields, "STAC ids"]
    typer.echo(tabulate(table_data, tablefmt="fancy_grid", headers=headers))


def show_order_review_tabulated(order_review: dict[str, Any]):
    order_summary = order_review["orderDetails"]["summary"]
    typer.secho("summary:\n", bold=True)
    table_data = [
        ("field", "value"),
        ("authorized", order_review["authorized"]),
        ("subtotal", order_summary["subtotal"]),
        ("total", order_summary["total"]),
    ]
    typer.echo(tabulate(table_data, tablefmt="fancy_grid", headers="firstrow"))

    typer.secho("\n\nby_line_item:\n", bold=True)
    line_items = order_review["orderDetails"]["lineItems"]

    line_item_table = []
    for li in line_items:
        cur = (li["granuleId"], li["order"]["finalListPrice"])
        line_item_table.append(cur)

    typer.echo(tabulate(line_item_table, tablefmt="fancy_grid", headers=["STAC id", "cost"]))


def show_cancel_result_tabulated(cancel_result: dict[str, Any]):
    table_data = []

    for tr_id, status in cancel_result.items():
        status_icon = "✅" if status.get("success") else "❌"
        table_data.append([tr_id, status_icon])

    typer.echo(tabulate(table_data, headers=["tasking request id", "cancel status"], tablefmt="fancy_grid"))


def show_update_result_tabulated(update_result: dict[str, Any]):
    table_data = []

    for tr_id, result in update_result.items():
        if result.get("success") is False:
            status_icon = "❌"
            detail = result.get("error", {}).get("code", "unknown error")
        else:
            status_icon = "✅"
            detail = result.get("properties", {}).get("taskingrequestName", "")
        table_data.append([tr_id, status_icon, detail])

    typer.echo(tabulate(table_data, headers=["tasking request id", "status", "name"], tablefmt="fancy_grid"))
