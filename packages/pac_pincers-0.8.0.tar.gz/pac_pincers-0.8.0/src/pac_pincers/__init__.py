"""pac-pincers: Local stdio MCP server for CSV/Excel manipulation via Polars virtual files."""
