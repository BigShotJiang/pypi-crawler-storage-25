from __future__ import annotations

from typing import Any

import polars as pl


_AGG_FN_MAP: dict[str, Any] = {
    "sum":      lambda c: c.sum(),
    "mean":     lambda c: c.mean(),
    "min":      lambda c: c.min(),
    "max":      lambda c: c.max(),
    "count":    lambda c: c.count(),
    "std":      lambda c: c.std(),
    "var":      lambda c: c.var(),
    "first":    lambda c: c.first(),
    "last":     lambda c: c.last(),
    "median":   lambda c: c.median(),
    "n_unique": lambda c: c.n_unique(),
}


def aggregate(
    df: pl.DataFrame,
    group_by: list[str] | None,
    aggregations: list[dict],
) -> pl.DataFrame:
    agg_exprs = []
    for agg in aggregations:
        col = pl.col(agg["column"])
        fn_name = agg["function"]
        if fn_name not in _AGG_FN_MAP:
            raise ValueError(
                f"Unknown aggregation function {fn_name!r}. "
                f"Valid: {sorted(_AGG_FN_MAP)}"
            )
        expr = _AGG_FN_MAP[fn_name](col)
        if alias := agg.get("alias"):
            expr = expr.alias(alias)
        agg_exprs.append(expr)

    if group_by:
        return df.group_by(group_by).agg(agg_exprs)
    return df.select(agg_exprs)


def filter_rows(
    df: pl.DataFrame,
    conditions: list[dict],
    logic: str = "and",
) -> pl.DataFrame:
    if not conditions:
        return df

    exprs: list[pl.Expr] = []
    for cond in conditions:
        col = pl.col(cond["column"])
        op = cond["operator"]
        val: Any = cond.get("value")

        match op:
            case "=":           expr = col == val
            case "!=":          expr = col != val
            case ">":           expr = col > val
            case ">=":          expr = col >= val
            case "<":           expr = col < val
            case "<=":          expr = col <= val
            case "contains":    expr = col.str.contains(val)
            case "starts_with": expr = col.str.starts_with(val)
            case "ends_with":   expr = col.str.ends_with(val)
            case "in":          expr = col.is_in(val)
            case "not_in":      expr = ~col.is_in(val)
            case "is_null":     expr = col.is_null()
            case "is_not_null": expr = col.is_not_null()
            case _:             raise ValueError(f"Unknown filter operator {op!r}")
        exprs.append(expr)

    combined = exprs[0]
    for e in exprs[1:]:
        combined = (combined & e) if logic == "and" else (combined | e)
    return df.filter(combined)


def sort_rows(df: pl.DataFrame, by: list[dict]) -> pl.DataFrame:
    columns = [b["column"] for b in by]
    descending = [b.get("descending", False) for b in by]
    return df.sort(columns, descending=descending)


def join_frames(
    left: pl.DataFrame,
    right: pl.DataFrame,
    left_on: list[str],
    right_on: list[str],
    how: str,
) -> pl.DataFrame:
    valid = {"inner", "left", "right", "full", "semi", "anti", "cross"}
    if how not in valid:
        raise ValueError(f"Unknown join type {how!r}. Valid: {sorted(valid)}")
    return left.join(right, left_on=left_on, right_on=right_on, how=how)  # type: ignore[arg-type]
