from __future__ import annotations

import io
import shutil
from datetime import date, datetime
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

import httpx
import polars as pl
from mcp.server.fastmcp import FastMCP

from .store import VirtualFileStore
from . import _transforms as T


mcp = FastMCP(
    "pac-pincers",
    instructions=(
        "Local stdio MCP for in-memory CSV/Excel manipulation. "
        "Files are loaded as 'virtual files' (Polars DataFrames) identified by unique IDs. "
        "Transform tools delete the source virtual file and replace it with the result "
        "unless keep_original=True."
    ),
)
_store = VirtualFileStore()


# ── helpers ──────────────────────────────────────────────────────────────────

# Human-friendly dtype aliases → Polars types
_DTYPE_MAP: dict[str, pl.DataType] = {
    "str": pl.String,    "string": pl.String, "utf8": pl.String,  "text": pl.String,
    "int": pl.Int64,     "int64": pl.Int64,   "integer": pl.Int64,
    "int32": pl.Int32,   "int16": pl.Int16,   "int8": pl.Int8,
    "uint64": pl.UInt64, "uint32": pl.UInt32, "uint16": pl.UInt16, "uint8": pl.UInt8,
    "float": pl.Float64, "float64": pl.Float64, "double": pl.Float64,
    "float32": pl.Float32,
    "bool": pl.Boolean,  "boolean": pl.Boolean,
    "date": pl.Date,
    "datetime": pl.Datetime, "timestamp": pl.Datetime,
    "time": pl.Time,
}


def _parse_schema(schema: dict[str, str]) -> dict[str, pl.DataType]:
    """Convert a human-friendly {col: dtype_string} map to Polars dtype objects."""
    result: dict[str, pl.DataType] = {}
    for col, dtype_str in schema.items():
        key = dtype_str.lower().strip()
        if key not in _DTYPE_MAP:
            raise ValueError(
                f"Unknown dtype {dtype_str!r} for column {col!r}. "
                f"Valid values: {sorted(_DTYPE_MAP)}"
            )
        result[col] = _DTYPE_MAP[key]
    return result


def _read_file(
    path: str,
    sheet_name: Optional[str] = None,
    schema_overrides: Optional[dict[str, pl.DataType]] = None,
    lazy_schema: bool = False,
) -> pl.DataFrame:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")
    ext = p.suffix.lower()
    if ext == ".csv":
        if sheet_name is not None:
            raise ValueError("sheet_name is only supported for Excel files (.xlsx/.xls/.xlsm)")
        # lazy_schema=False → infer_schema_length=None (scan whole file, accurate).
        # lazy_schema=True  → infer_schema_length=100 (Polars default, fast but risky).
        return pl.read_csv(
            p,
            schema_overrides=schema_overrides or {},
            infer_schema_length=100 if lazy_schema else None,
        )
    if ext in (".xlsx", ".xls", ".xlsm"):
        kwargs: dict = {}
        if sheet_name is not None:
            kwargs["sheet_name"] = sheet_name
        if schema_overrides:
            kwargs["schema_overrides"] = schema_overrides
        return pl.read_excel(p, **kwargs)
    raise ValueError(f"Unsupported format {ext!r} — use .csv or .xlsx/.xls/.xlsm")


def _write_file(df: pl.DataFrame, path: str, sheet_name: Optional[str] = None) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    ext = p.suffix.lower()
    if ext == ".csv":
        if sheet_name is not None:
            raise ValueError("sheet_name is only supported for Excel files (.xlsx/.xlsm)")
        df.write_csv(p)
    elif ext in (".xlsx", ".xls", ".xlsm"):
        target_sheet = sheet_name or "Sheet1"
        if p.exists() and sheet_name is not None:
            # Append a new sheet into the existing workbook via openpyxl.
            # Polars uses xlsxwriter (write-only) so we must use openpyxl for
            # in-place edits. Data is written as plain cells; no xlsxwriter styling.
            import openpyxl
            wb = openpyxl.load_workbook(str(p))
            if target_sheet in wb.sheetnames:
                raise ValueError(
                    f"Sheet {target_sheet!r} already exists in {path!r}. "
                    "Use a different sheet_name or delete the file first."
                )
            ws = wb.create_sheet(target_sheet)
            ws.append(list(df.columns))           # header row
            for row in df.iter_rows():            # data rows as tuples
                ws.append(list(row))
            wb.save(str(p))
        else:
            # New file — use Polars write_excel (xlsxwriter) for full formatting.
            df.write_excel(str(p), worksheet=target_sheet)
    else:
        raise ValueError(f"Unsupported format {ext!r} — use .csv or .xlsx")


def _safe(v: Any) -> Any:
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    return v


def _paginate(df: pl.DataFrame, offset: int, limit: int) -> dict:
    sliced = df.slice(offset, limit)
    return {
        "total_rows": df.height,
        "offset": offset,
        "limit": limit,
        "rows_returned": sliced.height,
        "columns": list(df.columns),
        "schema": {col: str(dtype) for col, dtype in df.schema.items()},
        "data": [{k: _safe(v) for k, v in row.items()} for row in sliced.to_dicts()],
    }


def _vf_meta(vf_id: str, df: pl.DataFrame) -> dict:
    return {
        "id": vf_id,
        "rows": df.height,
        "columns": list(df.columns),
    }


# ── virtual file operations ───────────────────────────────────────────────────

@mcp.tool()
def list_virtual_files() -> list[dict]:
    """List all virtual files currently held in memory.

    A virtual file is a named Polars DataFrame kept in server memory.
    Each has a unique ID with format `{name}__{uuid7hex}`.
    Returns metadata only (no row data). Use `get` to retrieve rows.

    Returns: list of { id, source, rows, columns, schema }
    """
    return _store.list_all()


@mcp.tool()
def load(
    path: str,
    id: Optional[str] = None,
    sheet_name: Optional[str] = None,
    schema: Optional[dict[str, str]] = None,
    lazy_schema: bool = False,
) -> dict:
    """Load a CSV or Excel file from disk into a new virtual file in memory.

    Reads the file at `path` into a Polars DataFrame and registers it as a virtual
    file. Supports .csv, .xlsx, .xls, .xlsm. The returned `id` is the handle for
    all subsequent operations on this data. The disk file is not modified.

    By default (`lazy_schema=False`) all column types are inferred by scanning the
    **entire** file, which avoids mismatches when early rows don't represent the full
    range of values (e.g. a column that looks like integers for the first 100 rows
    but contains floats later). Set `lazy_schema=True` to use Polars' default
    sample-based inference (first 100 rows only) — faster for very large files but
    risks type mismatches. Use `schema` to pin specific columns regardless.

    Args:
        path:        Absolute or relative path to the source file.
        id:          Optional custom ID (must be unique). Auto-generated if omitted.
        sheet_name:  Excel only — worksheet to load. Omit for the first sheet.
        schema:      Optional column type overrides: { "col_name": "dtype", ... }.
                     Supported dtypes: str, int, int32, int16, int8, uint64, uint32,
                     float, float32, bool, date, datetime, time.
                     Unspecified columns are still inferred automatically.
        lazy_schema: False (default) = scan entire file for accurate type inference.
                     True = sample first 100 rows only (faster but may mistype columns).

    Returns: { id, source, rows, columns, schema }
    """
    schema_overrides = _parse_schema(schema) if schema else None
    df = _read_file(
        path,
        sheet_name=sheet_name,
        schema_overrides=schema_overrides,
        lazy_schema=lazy_schema,
    )
    vf = _store.add(df, Path(path).stem, id=id, source=str(path))
    return {
        "id": vf.id,
        "source": vf.source,
        "rows": df.height,
        "columns": list(df.columns),
        "schema": {col: str(dtype) for col, dtype in df.schema.items()},
    }


@mcp.tool()
def load_remote(
    url: str,
    headers: Optional[dict[str, str]] = None,
    id: Optional[str] = None,
    schema: Optional[dict[str, str]] = None,
) -> dict:
    """Fetch a CSV file from a remote URL via HTTP GET and load it as a virtual file.

    Only GET requests are issued. The response body must be valid CSV text.
    Use `headers` to pass authentication tokens, API keys, or any other HTTP headers
    required by the remote endpoint.

    By default all column types are inferred. Use `schema` to override specific
    columns when inference is wrong.

    Args:
        url:     Full URL to fetch (must return CSV).
        headers: Optional HTTP headers, e.g. {"Authorization": "Bearer <token>"}.
        id:      Optional custom virtual file ID (auto-generated if omitted).
        schema:  Optional column type overrides: { "col_name": "dtype", ... }.
                 Supported dtypes: str, int, int32, int16, int8, uint64, uint32,
                 float, float32, bool, date, datetime, time.
                 Unspecified columns are still inferred automatically.

    Returns: { id, source, rows, columns, schema }
    """
    with httpx.Client(follow_redirects=True, timeout=60.0) as client:
        response = client.get(url, headers=headers or {})
    response.raise_for_status()

    content_type = response.headers.get("content-type", "")
    if content_type and "html" in content_type:
        raise ValueError(
            f"Response looks like HTML, not CSV (Content-Type: {content_type!r}). "
            "Check the URL or authentication headers."
        )

    schema_overrides = _parse_schema(schema) if schema else None
    # Data is already fully in memory — scanning all of it for inference is free.
    # infer_schema_length=None prevents mismatches when early rows don't reflect
    # the full value range (e.g. integers in rows 1-100, floats in row 101+).
    df = pl.read_csv(
        io.StringIO(response.text),
        schema_overrides=schema_overrides or {},
        infer_schema_length=None,
    )

    # Derive a friendly name from the URL path (last non-empty segment, no extension)
    path_parts = [p for p in urlparse(url).path.split("/") if p]
    name = Path(path_parts[-1]).stem if path_parts else "remote"

    vf = _store.add(df, name, id=id, source=url)
    return {
        "id": vf.id,
        "source": vf.source,
        "rows": df.height,
        "columns": list(df.columns),
        "schema": {col: str(dtype) for col, dtype in df.schema.items()},
    }


@mcp.tool()
def dump(id: str, path: str, sheet_name: Optional[str] = None) -> dict:
    """Write a virtual file from memory to a disk file.

    Serialises the virtual file identified by `id` to `path`. Format is inferred from
    the extension: .csv → CSV, .xlsx/.xls/.xlsm → Excel. Parent directories are
    created if missing. The virtual file remains in memory unchanged.

    For Excel output, `sheet_name` controls which worksheet the data lands in.
    If the file already exists and `sheet_name` is provided, the sheet is APPENDED
    to the existing workbook — existing sheets are untouched. This lets you dump
    multiple virtual files into one .xlsx file as separate sheets by calling `dump`
    sequentially with the same `path` and different `sheet_name` values.
    An error is raised if the sheet name already exists in the file.

    Args:
        id:         ID of the virtual file to write.
        path:       Destination path (extension determines format).
        sheet_name: Worksheet name for Excel output (default "Sheet1").
                    Required when appending to an existing file — omitting it
                    on an existing file overwrites the whole workbook.

    Returns: { id, path, sheet_name, rows }
    """
    vf = _store.get(id)
    _write_file(vf.df, path, sheet_name=sheet_name)
    return {"id": id, "path": str(path), "sheet_name": sheet_name, "rows": vf.df.height}


@mcp.tool()
def delete(id: str) -> dict:
    """Remove a virtual file from memory.

    Frees the in-memory DataFrame. Does NOT touch any disk file.
    The ID becomes invalid immediately. Use `copy` first if you need to keep the data.

    Args:
        id: ID of the virtual file to remove.

    Returns: { deleted_id }
    """
    _store.delete(id)
    return {"deleted_id": id}


@mcp.tool()
def rename(id: str, new_name: str, new_id: Optional[str] = None) -> dict:
    """Rename a virtual file — assigns it a new ID, old ID is invalidated.

    Re-registers the virtual file under a new ID derived from `new_name`
    (format: `new_name__{uuid7hex}`). Supply `new_id` to set the full ID explicitly.
    The DataFrame content is unchanged. The old ID must not be used after this call.

    Args:
        id:       Current ID of the virtual file.
        new_name: Base name for the new auto-generated ID (ignored if new_id is given).
        new_id:   Optional fully custom new ID (must be unique).

    Returns: { old_id, new_id }
    """
    old_id = id
    vf = _store.rename(id, new_name, new_id=new_id)
    return {"old_id": old_id, "new_id": vf.id}


@mcp.tool()
def copy(id: str, new_id: Optional[str] = None) -> dict:
    """Duplicate a virtual file, creating a new independent virtual file.

    Deep-copies the DataFrame and registers it under a new ID. The original virtual
    file is unchanged.

    Args:
        id:     ID of the virtual file to copy.
        new_id: Optional custom ID for the copy (must be unique).

    Returns: { source_id, new_id }
    """
    new_vf = _store.copy(id, new_id=new_id)
    return {"source_id": id, "new_id": new_vf.id}


@mcp.tool()
def get(id: str, offset: int = 0, limit: int = 100) -> dict:
    """Read paginated rows from a virtual file.

    Returns at most `limit` rows starting at `offset`. Always includes `total_rows`
    so you can determine whether more pages exist. Advance with offset += limit.

    Args:
        id:     ID of the virtual file.
        offset: First row index to return (0-based, default 0).
        limit:  Max rows to return (default 100).

    Returns: { id, total_rows, offset, limit, rows_returned, columns, schema, data }
    """
    vf = _store.get(id)
    result = _paginate(vf.df, offset, limit)
    result["id"] = id
    return result


# ── local (disk) file operations ─────────────────────────────────────────────

@mcp.tool()
def delete_local(path: str) -> dict:
    """Delete a file from disk. Does not affect any virtual file in memory.

    Args:
        path: Path to the file to delete.

    Returns: { deleted_path }
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")
    p.unlink()
    return {"deleted_path": str(path)}


@mcp.tool()
def rename_local(path: str, new_path: str) -> dict:
    """Rename (move) a file on disk. Does not affect any virtual file in memory.

    Args:
        path:     Current file path.
        new_path: New file path. Parent directory must already exist.

    Returns: { old_path, new_path }
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")
    p.rename(new_path)
    return {"old_path": str(path), "new_path": str(new_path)}


@mcp.tool()
def copy_local(path: str, dest: str) -> dict:
    """Copy a file on disk to a new location. Does not affect any virtual file in memory.

    Args:
        path: Source file path.
        dest: Destination file path.

    Returns: { source, dest }
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")
    shutil.copy2(str(p), str(dest))
    return {"source": str(path), "dest": str(dest)}


@mcp.tool()
def get_local(
    path: str,
    offset: int = 0,
    limit: int = 100,
    sheet_name: Optional[str] = None,
) -> dict:
    """Read paginated rows directly from a disk file without creating a virtual file.

    Reads a CSV or Excel file, returns a page of rows, then discards the data.
    Use this to inspect a file before deciding whether to load it into memory.

    Args:
        path:       Path to the CSV or Excel file.
        offset:     First row index to return (0-based, default 0).
        limit:      Max rows to return (default 100).
        sheet_name: Excel only — name of the worksheet to peek at. Omit for the first sheet.

    Returns: { path, sheet_name, total_rows, offset, limit, rows_returned, columns, schema, data }
    """
    df = _read_file(path, sheet_name=sheet_name)
    result = _paginate(df, offset, limit)
    result["path"] = str(path)
    result["sheet_name"] = sheet_name
    return result


# ── transform operations ──────────────────────────────────────────────────────
#
# All transforms produce a NEW virtual file and return its ID.
#
# keep_original=False (default):
#   The source virtual file is DELETED; the result takes a new auto-generated ID
#   (or the ID given via new_id). Use this when you want to replace the source.
#
# keep_original=True:
#   The source virtual file is KEPT unchanged; the result is a separate new entry.
#   Supply new_id to control the result's ID; otherwise it is auto-generated.
#
# new_id must be unique across all virtual files or the call returns an error.
# All transforms return { result_id, source_id, rows, columns }.


@mcp.tool()
def aggregate(
    id: str,
    aggregations: list[dict],
    group_by: Optional[list[str]] = None,
    new_id: Optional[str] = None,
    keep_original: bool = False,
) -> dict:
    """Group and aggregate a virtual file's rows.

    Each entry in `aggregations`:
      { "column": str, "function": str, "alias": str (optional) }

    Supported functions: sum, mean, min, max, count, std, var, first, last, median, n_unique.

    `group_by`: list of column names to group by. Omit for a global (single-row) aggregate.

    Args:
        id:           Source virtual file ID.
        aggregations: List of aggregation specs (see above).
        group_by:     Columns to group by (optional).
        new_id:       Custom ID for the result virtual file (auto-generated if omitted).
        keep_original: Keep source virtual file (default False — source is deleted).

    Returns: { result_id, source_id, rows, columns }
    """
    vf = _store.get(id)
    result_df = T.aggregate(vf.df, group_by, aggregations)
    new_vf = _store.apply_transform(id, result_df, new_id=new_id, keep_original=keep_original)
    return _vf_meta(new_vf.id, result_df) | {"source_id": id}


@mcp.tool()
def filter_rows(
    id: str,
    conditions: list[dict],
    logic: str = "and",
    new_id: Optional[str] = None,
    keep_original: bool = False,
) -> dict:
    """Filter rows of a virtual file by one or more conditions.

    Each condition:
      { "column": str, "operator": str, "value": any }
    Omit "value" for is_null / is_not_null operators.

    Operators: =, !=, >, >=, <, <=, contains, starts_with, ends_with,
               in, not_in, is_null, is_not_null.
    `in` / `not_in` require value to be a list.

    `logic`: "and" | "or" — how multiple conditions are combined (default "and").

    Args:
        id:           Source virtual file ID.
        conditions:   List of filter conditions (see above).
        logic:        Combine conditions with "and" or "or" (default "and").
        new_id:       Custom ID for the result virtual file (auto-generated if omitted).
        keep_original: Keep source virtual file (default False — source is deleted).

    Returns: { result_id, source_id, rows, columns }
    """
    vf = _store.get(id)
    result_df = T.filter_rows(vf.df, conditions, logic)
    new_vf = _store.apply_transform(id, result_df, new_id=new_id, keep_original=keep_original)
    return _vf_meta(new_vf.id, result_df) | {"source_id": id}


@mcp.tool()
def select_columns(
    id: str,
    columns: list[str],
    new_id: Optional[str] = None,
    keep_original: bool = False,
) -> dict:
    """Retain only the specified columns, dropping all others.

    Args:
        id:           Source virtual file ID.
        columns:      Ordered list of column names to keep.
        new_id:       Custom ID for the result virtual file (auto-generated if omitted).
        keep_original: Keep source virtual file (default False — source is deleted).

    Returns: { result_id, source_id, rows, columns }
    """
    vf = _store.get(id)
    result_df = vf.df.select(columns)
    new_vf = _store.apply_transform(id, result_df, new_id=new_id, keep_original=keep_original)
    return _vf_meta(new_vf.id, result_df) | {"source_id": id}


@mcp.tool()
def rename_columns(
    id: str,
    mapping: dict[str, str],
    new_id: Optional[str] = None,
    keep_original: bool = False,
) -> dict:
    """Rename one or more columns. Columns not listed in mapping are unchanged.

    Args:
        id:           Source virtual file ID.
        mapping:      { "old_name": "new_name", ... }
        new_id:       Custom ID for the result virtual file (auto-generated if omitted).
        keep_original: Keep source virtual file (default False — source is deleted).

    Returns: { result_id, source_id, rows, columns }
    """
    vf = _store.get(id)
    result_df = vf.df.rename(mapping)
    new_vf = _store.apply_transform(id, result_df, new_id=new_id, keep_original=keep_original)
    return _vf_meta(new_vf.id, result_df) | {"source_id": id}


@mcp.tool()
def sort(
    id: str,
    by: list[dict],
    new_id: Optional[str] = None,
    keep_original: bool = False,
) -> dict:
    """Sort rows by one or more columns.

    Each entry in `by`:
      { "column": str, "descending": bool (default false) }
    Rows are sorted by the first key, ties broken by subsequent keys.

    Args:
        id:           Source virtual file ID.
        by:           List of sort keys (see above).
        new_id:       Custom ID for the result virtual file (auto-generated if omitted).
        keep_original: Keep source virtual file (default False — source is deleted).

    Returns: { result_id, source_id, rows, columns }
    """
    vf = _store.get(id)
    result_df = T.sort_rows(vf.df, by)
    new_vf = _store.apply_transform(id, result_df, new_id=new_id, keep_original=keep_original)
    return _vf_meta(new_vf.id, result_df) | {"source_id": id}


@mcp.tool()
def join(
    id: str,
    right_id: str,
    left_on: list[str],
    right_on: list[str],
    how: str = "inner",
    new_id: Optional[str] = None,
    keep_original: bool = False,
) -> dict:
    """Join two virtual files into a new virtual file.

    `id` is the left table; `right_id` is the right table. Both must already be
    loaded as virtual files. The right virtual file is never modified or deleted.
    keep_original applies to the left table only.

    `left_on` / `right_on`: parallel lists of join-key column names.
    `how`: inner | left | right | full | semi | anti | cross (default inner).

    Args:
        id:           Left virtual file ID.
        right_id:     Right virtual file ID.
        left_on:      Key column(s) from the left table.
        right_on:     Key column(s) from the right table (same length as left_on).
        how:          Join type (default "inner").
        new_id:       Custom ID for the result virtual file (auto-generated if omitted).
        keep_original: Keep the left virtual file (default False — left source is deleted).

    Returns: { result_id, source_id, right_id, rows, columns }
    """
    left_vf = _store.get(id)
    right_vf = _store.get(right_id)
    result_df = T.join_frames(left_vf.df, right_vf.df, left_on, right_on, how)
    new_vf = _store.apply_transform(id, result_df, new_id=new_id, keep_original=keep_original)
    return _vf_meta(new_vf.id, result_df) | {"source_id": id, "right_id": right_id}


@mcp.tool()
def union(
    id: str,
    other_id: str,
    distinct: bool = False,
    diagonal: bool = False,
    new_id: Optional[str] = None,
    keep_original: bool = False,
) -> dict:
    """Stack two virtual files vertically (SQL UNION / UNION ALL).

    Appends all rows of `other_id` below the rows of `id`. The right virtual
    file (`other_id`) is never modified or deleted. `keep_original` applies to
    the left table only.

    Args:
        id:           Top (left) virtual file ID.
        other_id:     Bottom (right) virtual file ID.
        distinct:     If True, deduplicate the result — equivalent to SQL UNION DISTINCT.
                      If False (default), keep all rows — equivalent to SQL UNION ALL.
        diagonal:     If True, allow mismatched schemas: columns present in one table
                      but not the other are filled with null. If False (default), both
                      tables must have identical column names; a mismatch raises an error.
        new_id:       Custom ID for the result virtual file (auto-generated if omitted).
        keep_original: Keep the left virtual file (default False — left source is deleted).

    Returns: { result_id, source_id, other_id, rows, columns }
    """
    left_vf = _store.get(id)
    right_vf = _store.get(other_id)
    concat_how = "diagonal" if diagonal else "vertical"
    result_df = pl.concat([left_vf.df, right_vf.df], how=concat_how)
    if distinct:
        result_df = result_df.unique(maintain_order=True)
    new_vf = _store.apply_transform(id, result_df, new_id=new_id, keep_original=keep_original)
    return _vf_meta(new_vf.id, result_df) | {"source_id": id, "other_id": other_id}


@mcp.tool()
def head(
    id: str,
    n: int = 10,
    new_id: Optional[str] = None,
    keep_original: bool = False,
) -> dict:
    """Keep only the first N rows of a virtual file.

    Args:
        id:           Source virtual file ID.
        n:            Number of rows to keep (default 10).
        new_id:       Custom ID for the result virtual file (auto-generated if omitted).
        keep_original: Keep source virtual file (default False — source is deleted).

    Returns: { result_id, source_id, rows, columns }
    """
    vf = _store.get(id)
    result_df = vf.df.head(n)
    new_vf = _store.apply_transform(id, result_df, new_id=new_id, keep_original=keep_original)
    return _vf_meta(new_vf.id, result_df) | {"source_id": id}


@mcp.tool()
def with_columns(
    id: str,
    columns: list[dict],
    new_id: Optional[str] = None,
    keep_original: bool = False,
) -> dict:
    """Add or replace columns using SQL expressions.

    Each entry in `columns`:
      { "alias": str, "expr": str }

    `alias` is the name of the new (or replaced) column.
    `expr` is a SQL expression string evaluated against the existing columns.

    Supported expression syntax (SQL subset via Polars sql_expr):
      - Arithmetic:       "price * quantity"
      - Conditional:      "CASE WHEN status = 'active' THEN 1 ELSE 0 END"
      - Null handling:    "COALESCE(discount, 0)"
      - String ops:       "UPPER(name)", "first_name || ' ' || last_name"
      - Math functions:   "ROUND(price * 1.1, 2)", "ABS(balance)"
      - Date parts:       "EXTRACT(YEAR FROM created_at)"
      - Casting:          "CAST(quantity AS FLOAT)"
      - Literal value:    "42", "'unknown'"
      - Column reference: "price"  (copies / renames a column)

    Existing columns not listed in `columns` are preserved unchanged.
    If `alias` matches an existing column name, that column is replaced.

    Args:
        id:           Source virtual file ID.
        columns:      List of { "alias": str, "expr": str } specs.
        new_id:       Custom ID for the result virtual file (auto-generated if omitted).
        keep_original: Keep source virtual file (default False — source is deleted).

    Returns: { result_id, source_id, rows, columns }
    """
    vf = _store.get(id)
    exprs = []
    for spec in columns:
        alias = spec.get("alias")
        expr_str = spec.get("expr")
        if not alias:
            raise ValueError("Each column spec must have an 'alias' field.")
        if expr_str is None:
            raise ValueError(f"Column spec for {alias!r} must have an 'expr' field.")
        exprs.append(pl.sql_expr(expr_str).alias(alias))
    result_df = vf.df.with_columns(exprs)
    new_vf = _store.apply_transform(id, result_df, new_id=new_id, keep_original=keep_original)
    return _vf_meta(new_vf.id, result_df) | {"source_id": id}


@mcp.tool()
def distinct(
    id: str,
    columns: Optional[list[str]] = None,
    keep: str = "first",
    new_id: Optional[str] = None,
    keep_original: bool = False,
) -> dict:
    """Remove duplicate rows, keeping only unique value combinations.

    Equivalent to SQL DISTINCT. When `columns` is provided, uniqueness is judged
    only on those columns and the full row of the first (or last) match is kept.
    Omit `columns` to deduplicate across all columns.

    Args:
        id:           Source virtual file ID.
        columns:      Columns to consider for uniqueness. Omit for all columns.
        keep:         Which duplicate to keep: "first" (default), "last", or "any".
        new_id:       Custom ID for the result virtual file (auto-generated if omitted).
        keep_original: Keep source virtual file (default False — source is deleted).

    Returns: { result_id, source_id, rows, columns }
    """
    vf = _store.get(id)
    valid_keep = {"first", "last", "any"}
    if keep not in valid_keep:
        raise ValueError(f"Invalid keep={keep!r}. Valid: {sorted(valid_keep)}")
    result_df = vf.df.unique(subset=columns, keep=keep, maintain_order=True)
    new_vf = _store.apply_transform(id, result_df, new_id=new_id, keep_original=keep_original)
    return _vf_meta(new_vf.id, result_df) | {"source_id": id}


@mcp.tool()
def search(
    id: str,
    value: str,
    columns: Optional[list[str]] = None,
    limit: int = 5,
) -> dict:
    """Search for a value across all (or specified) columns and return matching rows.

    Casts every searched column to string and performs a case-insensitive substring
    match. Useful for discovering which column a given value belongs to — e.g. pass
    an unknown ID or name to find out where it lives in the dataset.

    Does NOT create a new virtual file; returns data directly like `get`.

    Args:
        id:      Virtual file ID to search.
        value:   String to search for (case-insensitive substring).
        columns: Columns to search. Omit to search all columns.
        limit:   Max matching rows to return (default 5).

    Returns: { total_matches, columns_with_matches, rows }
      - total_matches: total number of rows that contain the value in any searched column.
      - columns_with_matches: list of column names where the value was found.
      - rows: up to `limit` full matching rows.
    """
    vf = _store.get(id)
    df = vf.df
    search_cols = columns if columns is not None else df.columns
    needle = value.lower()

    # Build a per-column match expression (cast → lowercase → contains)
    col_exprs = [
        pl.col(c).cast(pl.String).str.to_lowercase().str.contains(needle)
        for c in search_cols
    ]

    # Combined mask: row matches if ANY searched column contains the value
    combined = col_exprs[0]
    for e in col_exprs[1:]:
        combined = combined | e

    matched_df = df.filter(combined)

    # Determine which columns actually had at least one hit
    cols_with_matches = [
        c
        for c, expr in zip(search_cols, col_exprs)
        if matched_df.filter(expr).height > 0
    ]

    return {
        "total_matches": matched_df.height,
        "columns_with_matches": cols_with_matches,
        "rows": [
            {k: _safe(v) for k, v in row.items()}
            for row in matched_df.head(limit).to_dicts()
        ],
    }
