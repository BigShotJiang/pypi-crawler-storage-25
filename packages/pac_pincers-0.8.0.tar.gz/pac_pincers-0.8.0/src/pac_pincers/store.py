from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import polars as pl
from uuid_extensions import uuid7 as _uuid7


def _new_uuid() -> str:
    return _uuid7().hex


@dataclass
class VirtualFile:
    id: str
    df: pl.DataFrame
    source: Optional[str] = None  # original file path, if any


class VirtualFileStore:
    def __init__(self) -> None:
        self._files: dict[str, VirtualFile] = {}

    def _gen_id(self, name: str) -> str:
        stem = Path(name).stem if name else "virtual"
        stem = "".join(c if c.isalnum() or c == "_" else "_" for c in stem)
        while True:
            candidate = f"{stem}__{_new_uuid()}"
            if candidate not in self._files:
                return candidate

    def add(
        self,
        df: pl.DataFrame,
        name: str,
        *,
        id: Optional[str] = None,
        source: Optional[str] = None,
    ) -> VirtualFile:
        if id is None:
            id = self._gen_id(name)
        elif id in self._files:
            raise ValueError(f"Virtual file id already exists: {id!r}")
        vf = VirtualFile(id=id, df=df, source=source)
        self._files[id] = vf
        return vf

    def get(self, id: str) -> VirtualFile:
        try:
            return self._files[id]
        except KeyError:
            raise KeyError(f"Virtual file not found: {id!r}")

    def delete(self, id: str) -> None:
        self.get(id)
        del self._files[id]

    def rename(self, id: str, new_name: str, *, new_id: Optional[str] = None) -> VirtualFile:
        """Re-register the virtual file under a new ID derived from new_name (or custom new_id). Old ID is removed."""
        vf = self.get(id)
        if new_id is None:
            new_id = self._gen_id(new_name)
        elif new_id in self._files:
            raise ValueError(f"Virtual file id already exists: {new_id!r}")
        new_vf = VirtualFile(id=new_id, df=vf.df, source=vf.source)
        self._files[new_id] = new_vf
        del self._files[id]
        return new_vf

    def copy(self, id: str, *, new_id: Optional[str] = None) -> VirtualFile:
        """Duplicate a virtual file; original is kept."""
        vf = self.get(id)
        stem = id.split("__")[0]
        if new_id is None:
            new_id = self._gen_id(stem)
        elif new_id in self._files:
            raise ValueError(f"Virtual file id already exists: {new_id!r}")
        new_vf = VirtualFile(id=new_id, df=vf.df.clone(), source=vf.source)
        self._files[new_id] = new_vf
        return new_vf

    def apply_transform(
        self,
        source_id: str,
        result_df: pl.DataFrame,
        *,
        new_id: Optional[str] = None,
        keep_original: bool = False,
    ) -> VirtualFile:
        """Store result_df as a new virtual file. Removes source_id unless keep_original is True."""
        source = self.get(source_id)
        stem = source_id.split("__")[0]
        new_vf = self.add(result_df, stem, id=new_id, source=source.source)
        if not keep_original:
            del self._files[source_id]
        return new_vf

    def list_all(self) -> list[dict]:
        return [
            {
                "id": vf.id,
                "source": vf.source,
                "rows": vf.df.height,
                "columns": list(vf.df.columns),
                "schema": {col: str(dtype) for col, dtype in vf.df.schema.items()},
            }
            for vf in self._files.values()
        ]
