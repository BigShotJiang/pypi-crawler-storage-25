import unittest

import nc


class ModuleTest(unittest.TestCase):
    def test_basics(self):
        assert nc("red") == nc.red
        assert nc["REd"] == nc.red
        assert "Taupe" in nc
        assert len(nc) == 1245

        assert str(nc[0]) == "Absolute zero"
