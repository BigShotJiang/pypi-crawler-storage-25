import copy
import inspect
import pickle
from concurrent.futures import ThreadPoolExecutor
from itertools import chain

import arro3.core
import numpy as np
import pyarrow as pa
import pytest
from numpy.testing import assert_allclose, assert_array_equal

import light_curve.light_curve_ext as lc


def _feature_classes(module, *, exclude_parametric=True):
    for name, member in inspect.getmembers(module):
        if name.startswith("_"):
            continue
        if inspect.ismodule(member):
            yield from _feature_classes(member)
        if not inspect.isclass(member):
            continue
        if not issubclass(member, lc._FeatureEvaluator):
            continue
        if member is lc.JSONDeserializedFeature:
            continue
        # Skip classes with non-trivial constructors
        if exclude_parametric:
            try:
                member()
            except TypeError:
                continue
        yield member


non_param_feature_classes = frozenset(_feature_classes(lc, exclude_parametric=True))
assert len(non_param_feature_classes) > 0

all_feature_classes = frozenset(_feature_classes(lc, exclude_parametric=False))
assert len(all_feature_classes) > 0

fit_feature_classes = frozenset(
    cls for cls in all_feature_classes if hasattr(cls, "model") and hasattr(cls, "supported_algorithms")
)
assert len(fit_feature_classes) > 0


def get_new_args_kwargs(cls):
    if hasattr(cls, "__getnewargs_ex__"):
        return cls.__getnewargs_ex__()
    if hasattr(cls, "__getnewargs__"):
        args = cls.__getnewargs__()
        return args, {}
    return (), {}


def new_default(cls, **kwargs):
    args, kwargs_ = get_new_args_kwargs(cls)
    kwargs = dict(kwargs_, **kwargs)
    return cls(*args, **kwargs)


def gen_periodogram_variants(*, rng=None):
    rng = np.random.default_rng(rng)

    peaks = rng.integers(1, 10)
    resolution = 10 ** rng.uniform(-0.5, 1.5)
    max_freq_factor = 10 ** rng.uniform(0.0, 2.0)
    features = [lc.Amplitude(), lc.Mean()]

    for nyquist in ["average", rng.uniform(0.0, 1.0)]:
        for freq_grid in [False, True]:
            for fast in [False, True]:
                if freq_grid:
                    if fast:
                        freqs = np.linspace(0.0, 100.0, 257)
                    else:
                        freqs = np.linspace(1.0, 100.0, 100)
                else:
                    freqs = None

                yield lc.Periodogram(
                    peaks=peaks,
                    resolution=resolution,
                    max_freq_factor=max_freq_factor,
                    nyquist=nyquist,
                    freqs=freqs,
                    fast=fast,
                    features=features,
                )

    # Test one non-default normalization; full normalization coverage
    # is in test_periodogram.py
    yield lc.Periodogram(
        peaks=peaks,
        resolution=resolution,
        max_freq_factor=max_freq_factor,
        features=features,
        normalization="standard",
    )


def gen_fit_variants(cls, *, rng=None):
    rng = np.random.default_rng(rng)
    for algo in cls.supported_algorithms:
        # Skip NUTS algorithms - they can panic on random data due to bad initial gradients
        if algo.startswith("nuts"):
            continue
        yield cls(
            algo,
            mcmc_niter=rng.integers(5, 20),
            lmsder_niter=rng.integers(1, 10),
            ceres_niter=rng.integers(1, 10),
            ceres_loss_reg=rng.uniform(0.5, 2.0),
            nuts_ntune=rng.integers(5, 20),
            nuts_niter=rng.integers(5, 20),
        )


def construct_example_objects(cls, *, parametric_variants=1, rng=None):
    # Extractor
    if cls is lc.Extractor:
        return [cls(lc.BeyondNStd(1.5), lc.LinearFit())]

    # Periodogram
    if cls is lc.Periodogram:
        return list(chain.from_iterable(gen_periodogram_variants(rng=rng) for _ in range(parametric_variants)))

    # Non-linear fit classes
    if cls in fit_feature_classes:
        return list(chain.from_iterable(gen_fit_variants(cls, rng=rng) for _ in range(parametric_variants)))

    # No mandatory arguments
    if not hasattr(cls, "__getnewargs__"):
        return [cls()]

    # default mandatory arguments
    args, kwargs = get_new_args_kwargs(cls)

    # Add Mean feature for metafeatures
    args = [[lc.Mean()] if arg == () else arg for arg in args]

    objects = [cls(*args, **kwargs)]
    # Nothing to mutate
    if not any(isinstance(arg, float) for arg in args + list(kwargs.values())):
        return objects

    # Mutate floats
    rng = np.random.default_rng(rng)

    def mutation(value):
        if not isinstance(value, float):
            return value
        return value * rng.uniform(0.9, 1.1) + rng.uniform(0.0, 1e-3)

    for _ in range(1, parametric_variants):
        mutated_args = list(map(mutation, args))
        mutated_kwargs = {name: mutation(value) for name, value in kwargs.items()}
        objects.append(cls(*mutated_args, **mutated_kwargs))
    return objects


def gen_feature_evaluators(*, parametric_variants=0, skip_fit=False, rng=None):
    if parametric_variants == 0:
        for cls in non_param_feature_classes:
            yield cls()
        return
    rng = np.random.default_rng(rng)
    classes = all_feature_classes
    if skip_fit:
        classes = classes - fit_feature_classes
    for cls in classes:
        yield from construct_example_objects(cls, parametric_variants=parametric_variants, rng=rng)


def gen_lc(n, rng=None):
    rng = np.random.default_rng(rng)

    t = np.sort(rng.normal(0, 1, n))
    m = t.copy()
    sigma = np.full_like(t, 0.1)

    return t, m, sigma


@pytest.mark.parametrize("cls", list(all_feature_classes))
def test_available_transforms(cls):
    # All available features should consume transform=None
    none = new_default(cls, transform=None)

    # If transform consumes False it
    # 1) should give the same feature as transform=None
    # 2) should be able to consume transform=True
    try:
        false = new_default(cls, transform=False)
    except NotImplementedError:
        return
    # It would be better to compare objects themselves, but __eq__ is not implemented yet
    # https://github.com/light-curve/light-curve-python/issues/148
    assert false.names == none.names
    true = new_default(cls, transform=True)
    # Check if transform=True is not the same as transform=False
    default_transform = getattr(cls, "default_transform", None)
    if default_transform != "identity":
        assert true.names != false.names

    # Both attributes should be present or absent
    assert hasattr(cls, "supported_transforms") == hasattr(cls, "default_transform")

    if not hasattr(cls, "supported_transforms"):
        return

    assert cls.default_transform in cls.supported_transforms

    for transform in cls.supported_transforms + ["default"]:
        new_default(cls, transform=transform)


@pytest.mark.parametrize("feature", gen_feature_evaluators(parametric_variants=2))
def test_negative_strides(feature):
    t = np.linspace(1, 0, 20)[::-2]
    m = np.exp(t)[:]
    err = np.random.uniform(0.1, 0.2, t.shape)
    feature(t, m, err)


# We don't want *Fit features here: not precise
@pytest.mark.parametrize("feature", gen_feature_evaluators(parametric_variants=0))
def test_float32_vs_float64(feature):
    rng = np.random.default_rng(0)
    n = 128

    t, m, sigma = gen_lc(n, rng=rng)

    results = [
        feature(t.astype(dtype), m.astype(dtype), sigma.astype(dtype), sorted=True)
        for dtype in [np.float32, np.float64]
    ]
    assert_allclose(*results, rtol=1e-5, atol=1e-5)


# We don't want *Fit features here: too slow
@pytest.mark.parametrize("feature", gen_feature_evaluators(parametric_variants=0))
def test_many_vs_call(feature):
    rng = np.random.default_rng(0)
    n_obs = 128
    n_lc = 128

    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    call = np.stack([feature(*lc, sorted=True) for lc in lcs])
    many = feature.many(lcs, sorted=True, n_jobs=2)
    assert_array_equal(call, many)

    # Test with Python threads to ensure we have no problems on the free-threading CPython
    with ThreadPoolExecutor(2) as pool:
        futures = [pool.submit(feature, *lc, sorted=True) for lc in lcs]
        call_threads = np.stack([f.result() for f in futures])
        del futures
    assert_array_equal(call, call_threads)

    n_lcs_per_job = 4
    with ThreadPoolExecutor(2) as pool:
        futures = [
            pool.submit(feature.many, lcs[i : i + n_lcs_per_job], sorted=True, n_jobs=2)
            for i in range(0, n_lc, n_lcs_per_job)
        ]
        many_threads = np.concatenate([f.result() for f in futures])
        del futures
    assert_array_equal(call, many_threads)


def test_fill_value_not_enough_observations():
    n = 1
    t = np.linspace(0.0, 1.0, n)
    m = t.copy()
    fill_value = -100.0
    sigma = np.ones_like(t)
    feature = lc.Kurtosis()
    with pytest.raises(ValueError):
        feature(t, m, sigma, fill_value=None)
    assert_array_equal(feature(t, m, sigma, fill_value=fill_value), fill_value)


@pytest.mark.parametrize("cls", all_feature_classes)
def test_nonempty_docstring(cls):
    assert len(cls.__doc__) > 10


@pytest.mark.parametrize("feature", gen_feature_evaluators(parametric_variants=2))
def test_check_t(feature):
    n_obs = 128
    t, m, sigma = gen_lc(n_obs)
    t[0] = np.nan
    with pytest.raises(ValueError):
        feature(t, m, sigma, check=True)
    t[0] = np.inf
    with pytest.raises(ValueError):
        feature(t, m, sigma, check=True)


@pytest.mark.parametrize("feature", gen_feature_evaluators(parametric_variants=2))
def test_check_m(feature):
    n_obs = 128
    t, m, sigma = gen_lc(n_obs)
    m[0] = np.nan
    with pytest.raises(ValueError):
        feature(t, m, sigma, check=True)
    m[0] = np.inf
    with pytest.raises(ValueError):
        feature(t, m, sigma, check=True)


# We need evaluators which use sigma
@pytest.mark.parametrize("cls", (lc.ExcessVariance, lc.LinearFit, lc.ReducedChi2, lc.StetsonK, lc.WeightedMean))
def test_check_sigma(cls):
    n_obs = 128
    t, m, sigma = gen_lc(n_obs)
    sigma[0] = np.nan
    feature = cls()
    with pytest.raises(ValueError):
        feature(t, m, sigma, check=True)
    # infinite values are allowed for sigma
    sigma[0] = np.inf
    feature(t, m, sigma, check=True)


@pytest.mark.parametrize("feature", gen_feature_evaluators(parametric_variants=5, rng=None))
@pytest.mark.parametrize("pickle_protocol", tuple(range(2, pickle.HIGHEST_PROTOCOL + 1)))
def test_pickling(feature, pickle_protocol):
    n_obs = 128
    data = gen_lc(n_obs)
    values = feature(*data)

    b = pickle.dumps(feature, protocol=pickle_protocol)
    new_feature = pickle.loads(b)

    new_values = new_feature(*data)
    assert_array_equal(values, new_values)


@pytest.mark.parametrize("feature", gen_periodogram_variants(rng=None))
@pytest.mark.parametrize("pickle_protocol", tuple(range(2, pickle.HIGHEST_PROTOCOL + 1)))
def test_periodogram_pickling(feature, pickle_protocol):
    n_obs = 128
    t, m, _sigma = gen_lc(n_obs)
    powers = feature.power(t, m)

    b = pickle.dumps(feature, protocol=pickle_protocol)
    new_feature = pickle.loads(b)

    new_powers = new_feature.power(t, m)
    assert_array_equal(powers, new_powers)


@pytest.mark.parametrize("feature", chain.from_iterable(gen_fit_variants(cls, rng=None) for cls in fit_feature_classes))
@pytest.mark.parametrize("pickle_protocol", tuple(range(2, pickle.HIGHEST_PROTOCOL + 1)))
def test_non_linear_fit_pickling(feature, pickle_protocol):
    n_obs = 128
    t, m, sigma = gen_lc(n_obs)

    params = feature(t, m, sigma)

    model = feature.model(t, params)

    b = pickle.dumps(feature, protocol=pickle_protocol)
    new_feature = pickle.loads(b)

    new_params = new_feature(t, m, sigma)
    assert_array_equal(params, new_params)

    new_model = new_feature.model(t, params)
    assert_array_equal(model, new_model)


@pytest.mark.parametrize("feature", gen_feature_evaluators(parametric_variants=5, rng=None))
def test_copy_deepcopy(feature):
    n_obs = 128
    data = gen_lc(n_obs)
    values = feature(*data)

    copied = copy.copy(feature)
    values_copied = copied(*data)
    assert_array_equal(values, values_copied)

    deepcopied = copy.deepcopy(feature)
    values_deepcopied = deepcopied(*data)
    assert_array_equal(values, values_deepcopied)


PICKLE_BENCHMARK_FEATURES = [
    lc.Amplitude(),  # no parameters
    lc.BeyondNStd(1.5),  # parametric
    lc.Extractor(  # large
        lc.Amplitude(),
        lc.BeyondNStd(2.0),
        lc.Bins(
            [lc.Kurtosis(), lc.LinearTrend(), lc.WeightedMean()],
            window=2.0,
            offset=59500.5,
        ),
        lc.Periodogram(features=[lc.InterPercentileRange(0.01)], peaks=5, max_freq_factor=12.0),
    ),
]


@pytest.mark.parametrize("feature", PICKLE_BENCHMARK_FEATURES)
def test_benchmark_pickle_loads(feature, benchmark):
    b = pickle.dumps(feature, protocol=pickle.HIGHEST_PROTOCOL)
    benchmark(pickle.loads, b)


@pytest.mark.parametrize("feature", PICKLE_BENCHMARK_FEATURES)
def test_benchmark_pickle_dumps(feature, benchmark):
    benchmark(pickle.dumps, feature, protocol=pickle.HIGHEST_PROTOCOL)


@pytest.mark.parametrize("feature", PICKLE_BENCHMARK_FEATURES)
def test_benchmark_copy(feature, benchmark):
    benchmark(copy.copy, feature)


@pytest.mark.parametrize("feature", PICKLE_BENCHMARK_FEATURES)
def test_benchmark_deepcopy(feature, benchmark):
    benchmark(copy.deepcopy, feature)


# We do not check pure MCMC because it requires a lot of iterations and would be too slow
@pytest.mark.parametrize("algo", ("ceres", "mcmc-ceres", "lmsder", "mcmc-lmsder"))
def test_bazin_fit_precise(algo):
    bazin = lc.BazinFit(algo)

    true_params = np.array([10.0, -2.0, 10.0, 10.0, 25.0])
    t = np.linspace(-50.0, 120.0, 1000)
    flux = bazin.model(t, true_params)
    fluxerr = np.ones_like(t)

    *params, reduced_chi2 = bazin(t, flux, fluxerr)
    assert_allclose(true_params, params, rtol=1e-4)  # tolerance set to underlying algorithms


# We do not check pure NUTS because it requires a lot of iterations and would be too slow
@pytest.mark.parametrize("algo", ("nuts-ceres", "nuts-lmsder"))
def test_bazin_fit_precise_nuts(algo):
    bazin = lc.BazinFit(algo)

    true_params = np.array([10.0, -2.0, 10.0, 10.0, 25.0])
    t = np.linspace(-50.0, 120.0, 1000)
    flux = bazin.model(t, true_params)
    fluxerr = np.ones_like(t)

    *params, reduced_chi2 = bazin(t, flux, fluxerr)
    assert_allclose(true_params, params, rtol=1e-3)


@pytest.mark.parametrize("cls", list(fit_feature_classes))
def test_nuts_in_supported_algorithms(cls):
    algos = cls.supported_algorithms
    assert "nuts" in algos
    assert "nuts-ceres" in algos
    assert "nuts-lmsder" in algos


@pytest.mark.parametrize("cls", list(fit_feature_classes))
def test_nuts_custom_params(cls):
    feat = cls("nuts-ceres", nuts_ntune=50, nuts_niter=50)
    assert feat is not None


@pytest.mark.parametrize("feature", gen_feature_evaluators(parametric_variants=5, rng=0))
def test_json_serialization(feature):
    n_obs = 128
    data = gen_lc(n_obs, rng=0)
    values = feature(*data)

    from_to_json = lc.feature_from_json(feature.to_json())
    values_from_to_json = from_to_json(*data)
    assert_allclose(values, values_from_to_json)


def test_json_deserialization():
    json = """
    {"FeatureExtractor":{"features":[{"Transformed":{"feature":{"AndersonDarlingNormal":{}},"transformer":{"Ln1p":{}}}},
    {"Transformed":{"feature":{"BazinFit":{"algorithm":{"Ceres":{"loss_factor":null,"niterations":20}},"inits_bounds":
    {"OptionArrays":{"init":[null,null,null,null,null],"lower":[0.0036307805477010066,null,null,0.0001,0.0001],"upper":
    [3630780547.7010174,null,null,30000.0,30000.0]}},"ln_prior":{"Fixed":{"None":{}}}}},"transformer":{"BazinFit":
    {"mag_zp":23.899999618530273}}}},{"ExcessVariance":{}}]}}
    """
    from_json = lc.feature_from_json(json)
    assert isinstance(from_json, lc._FeatureEvaluator)
    from_json(*gen_lc(128))


def test_raises_for_wrong_inputs():
    fe = lc.Amplitude()

    # First argument
    with pytest.raises(TypeError, match="'t' has type 'int'"):
        fe(5, [1.0, 2.0, 3.0])
    with pytest.raises(TypeError, match="'t' is a 2-d array"):
        fe(np.array([[1.0, 2.0, 3.0]]), np.array([1.0, 2.0, 3.0]))
    with pytest.raises(TypeError, match="'t' has dtype <U1"):
        fe(np.array(["a", "b", "c"]), np.array([1.0, 2.0, 3.0]))
    with pytest.raises(TypeError, match="'t' has type 'list'"):
        fe([1.0, 2.0, 3.0], [1.0, 2.0, 3.0], cast=False)
    # No failure of the last test with cast=True
    _ = fe([1.0, 2.0, 3.0], [1.0, 2.0, 3.0], cast=True)

    # Second and third arguments
    t = np.arange(10, dtype=np.float64)
    with pytest.raises(ValueError, match="Mismatched lengths:"):
        fe(t, np.arange(11, dtype=np.float64))
    with pytest.raises(TypeError, match="'m' must be a numpy array"):
        fe(t, set(t))
    with pytest.raises(TypeError, match="'sigma' is a 0-d array"):
        fe(t, t, np.array(1.0))
    with pytest.raises(TypeError, match="Mismatched dtypes:"):
        fe(t, t.astype(str) + "x")
    with pytest.raises(TypeError, match="Mismatched dtypes:"):
        fe(t, t.astype(np.float32), cast=False)
    # No failure of the last test with cast=True
    _ = fe(t, t.astype(np.float32), cast=True)


def _make_arrow_lcs(lcs, dtype=np.float64):
    """Build a pyarrow List<Struct<t, m, sigma>> array from list of (t, m, sigma) tuples."""
    pa_type = pa.float32() if dtype == np.float32 else pa.float64()
    struct_type = pa.struct([("t", pa_type), ("m", pa_type), ("sigma", pa_type)])
    # Build each light curve as a list of struct rows
    all_lcs = []
    for t, m, sigma in lcs:
        rows = [{"t": dtype(ti), "m": dtype(mi), "sigma": dtype(si)} for ti, mi, si in zip(t, m, sigma)]
        all_lcs.append(rows)
    return pa.array(all_lcs, type=pa.list_(struct_type))


def _make_arrow_lcs_no_sigma(lcs, dtype=np.float64):
    """Build a pyarrow List<Struct<t, m>> array from list of (t, m, sigma) tuples (sigma ignored)."""
    pa_type = pa.float32() if dtype == np.float32 else pa.float64()
    struct_type = pa.struct([("t", pa_type), ("m", pa_type)])
    all_lcs = []
    for t, m, _sigma in lcs:
        rows = [{"t": dtype(ti), "m": dtype(mi)} for ti, mi in zip(t, m)]
        all_lcs.append(rows)
    return pa.array(all_lcs, type=pa.list_(struct_type))


@pytest.mark.parametrize("feature", gen_feature_evaluators(parametric_variants=0))
def test_many_arrow_3fields(feature):
    """Arrow List<Struct<f64, f64, f64>> matches list-of-tuples result."""
    rng = np.random.default_rng(42)
    n_obs, n_lc = 64, 8
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    expected = feature.many(lcs, sorted=True, n_jobs=1)
    arrow_arr = _make_arrow_lcs(lcs)
    result = feature.many(arrow_arr, sorted=True, n_jobs=1, arrow_fields=[0, 1, 2])
    assert_array_equal(expected, result)


@pytest.mark.parametrize("feature", gen_feature_evaluators(parametric_variants=0))
def test_many_arrow_2fields(feature):
    """Arrow List<Struct<f64, f64>> (no sigma) matches list-of-tuples result."""
    rng = np.random.default_rng(42)
    n_obs, n_lc = 64, 8
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    lcs_no_sigma = [(t, m, None) for t, m, _s in lcs]
    expected = feature.many(lcs_no_sigma, sorted=True, n_jobs=1)
    arrow_arr = _make_arrow_lcs_no_sigma(lcs)
    result = feature.many(arrow_arr, sorted=True, n_jobs=1, arrow_fields=[0, 1])
    assert_array_equal(expected, result)


def test_many_arrow_f32():
    """Arrow Float32 variant works correctly."""
    rng = np.random.default_rng(42)
    n_obs, n_lc = 64, 8
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    lcs_f32 = [(t.astype(np.float32), m.astype(np.float32), s.astype(np.float32)) for t, m, s in lcs]
    expected = feature.many(lcs_f32, sorted=True, n_jobs=1)
    arrow_arr = _make_arrow_lcs(lcs, dtype=np.float32)
    result = feature.many(arrow_arr, sorted=True, n_jobs=1, arrow_fields=[0, 1, 2])
    assert_array_equal(expected, result)
    assert result.dtype == np.float32


def test_many_arrow_chunked():
    """Arrow ChunkedArray with multiple chunks works."""
    rng = np.random.default_rng(42)
    n_obs, n_lc = 64, 8
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    expected = feature.many(lcs, sorted=True, n_jobs=1)

    # Split into two chunks
    mid = n_lc // 2
    chunk1 = _make_arrow_lcs(lcs[:mid])
    chunk2 = _make_arrow_lcs(lcs[mid:])
    chunked = pa.chunked_array([chunk1, chunk2])
    result = feature.many(chunked, sorted=True, n_jobs=1, arrow_fields=[0, 1, 2])
    assert_array_equal(expected, result)


def test_many_arrow_wrong_fields():
    """Arrow input with wrong schema raises appropriate errors."""
    feature = lc.Amplitude()

    # Missing arrow_fields raises ValueError
    arr = pa.array(
        [[{"t": 1.0, "m": 2.0, "sigma": 0.1}]],
        type=pa.list_(pa.struct([("t", pa.float64()), ("m", pa.float64()), ("sigma", pa.float64())])),
    )
    with pytest.raises(ValueError, match="arrow_fields is required"):
        feature.many(arr, sorted=True)

    # Wrong field dtype (int32)
    arr = pa.array(
        [[{"t": 1, "m": 2}]],
        type=pa.list_(pa.struct([("t", pa.int32()), ("m", pa.int32())])),
    )
    with pytest.raises(TypeError, match="Float32 or Float64"):
        feature.many(arr, sorted=True, arrow_fields=[0, 1])

    # Non-list type
    arr = pa.array([1.0, 2.0, 3.0])
    with pytest.raises(TypeError, match="List array"):
        feature.many(arr, sorted=True, arrow_fields=[0, 1])

    # Mixed field dtypes
    arr = pa.array(
        [[{"t": np.float32(1.0), "m": np.float64(2.0)}]],
        type=pa.list_(pa.struct([("t", pa.float32()), ("m", pa.float64())])),
    )
    with pytest.raises(TypeError, match="same dtype"):
        feature.many(arr, sorted=True, arrow_fields=[0, 1])


def test_many_arrow_parallel():
    """Arrow input works with parallel execution."""
    rng = np.random.default_rng(42)
    n_obs, n_lc = 64, 16
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    expected = feature.many(lcs, sorted=True, n_jobs=1)
    arrow_arr = _make_arrow_lcs(lcs)
    result = feature.many(arrow_arr, sorted=True, n_jobs=2, arrow_fields=[0, 1, 2])
    assert_array_equal(expected, result)


def test_many_polars():
    """Polars Series (Arrow-backed) works with many()."""
    import polars as pl

    rng = np.random.default_rng(42)
    n_obs, n_lc = 64, 8
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    expected = feature.many(lcs, sorted=True, n_jobs=1)

    # Build a Polars Series of list-of-structs
    arrow_arr = _make_arrow_lcs(lcs)
    polars_series = pl.Series(arrow_arr)
    result = feature.many(polars_series, sorted=True, n_jobs=1, arrow_fields=[0, 1, 2])
    assert_array_equal(expected, result)


def test_many_nanoarrow():
    """nanoarrow array works with many()."""
    import nanoarrow

    rng = np.random.default_rng(42)
    n_obs, n_lc = 64, 8
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    expected = feature.many(lcs, sorted=True, n_jobs=1)

    arrow_arr = _make_arrow_lcs(lcs)
    nano_arr = nanoarrow.Array(arrow_arr)
    result = feature.many(nano_arr, sorted=True, n_jobs=1, arrow_fields=[0, 1, 2])
    assert_array_equal(expected, result)


def test_many_arro3():
    """arro3 array works with many()."""
    rng = np.random.default_rng(42)
    n_obs, n_lc = 64, 8
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    expected = feature.many(lcs, sorted=True, n_jobs=1)

    arrow_arr = _make_arrow_lcs(lcs)
    arro3_arr = arro3.core.Array.from_arrow(arrow_arr)
    result = feature.many(arro3_arr, sorted=True, n_jobs=1, arrow_fields=[0, 1, 2])
    assert_array_equal(expected, result)


@pytest.mark.parametrize(
    "arrow_arr, match_msg",
    [
        # Null list entry (whole light curve is null)
        (
            pa.array(
                [[{"t": 1.0, "m": 2.0, "sigma": 0.1}], None],
                type=pa.list_(pa.struct([("t", pa.float64()), ("m", pa.float64()), ("sigma", pa.float64())])),
            ),
            "list array",
        ),
        # Null struct entry (observation within a light curve is null)
        (
            pa.ListArray.from_arrays(
                pa.array([0, 2], type=pa.int32()),
                pa.StructArray.from_arrays(
                    [pa.array([1.0, 2.0]), pa.array([3.0, 4.0]), pa.array([0.1, 0.2])],
                    names=["t", "m", "sigma"],
                    mask=pa.array([False, True]),
                ),
            ),
            "struct array",
        ),
        # Null value in a data column
        (
            pa.array(
                [[{"t": 1.0, "m": None, "sigma": 0.1}, {"t": 2.0, "m": 5.0, "sigma": 0.2}]],
                type=pa.list_(pa.struct([("t", pa.float64()), ("m", pa.float64()), ("sigma", pa.float64())])),
            ),
            "data columns",
        ),
    ],
    ids=["null_list_entry", "null_struct_entry", "null_value"],
)
def test_many_arrow_nulls_rejected(arrow_arr, match_msg):
    """Null values at any level of the Arrow array raise NotImplementedError."""
    feature = lc.Amplitude()
    with pytest.raises(NotImplementedError, match=match_msg):
        feature.many(arrow_arr, sorted=True, n_jobs=1, arrow_fields=[0, 1, 2])


# ──────────────────────────────────────────────────────────────────────────────
# arrow_fields tests
# ──────────────────────────────────────────────────────────────────────────────


def _make_arrow_lcs_extra_fields(lcs, dtype=np.float64):
    """Build a pyarrow List<Struct<extra, t, m, sigma, extra2>> with extra fields."""
    pa_type = pa.float32() if dtype == np.float32 else pa.float64()
    struct_type = pa.struct(
        [
            ("extra", pa_type),
            ("t", pa_type),
            ("m", pa_type),
            ("sigma", pa_type),
            ("extra2", pa_type),
        ]
    )
    all_lcs = []
    for t, m, sigma in lcs:
        rows = [
            {"extra": dtype(0.0), "t": dtype(ti), "m": dtype(mi), "sigma": dtype(si), "extra2": dtype(0.0)}
            for ti, mi, si in zip(t, m, sigma)
        ]
        all_lcs.append(rows)
    return pa.array(all_lcs, type=pa.list_(struct_type))


def test_many_arrow_fields_by_name():
    """arrow_fields with field names selects correct columns from a wider struct."""
    rng = np.random.default_rng(0)
    n_obs, n_lc = 32, 4
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    expected = feature.many(lcs, sorted=True, n_jobs=1)

    arrow_arr = _make_arrow_lcs_extra_fields(lcs)
    result = feature.many(arrow_arr, sorted=True, n_jobs=1, arrow_fields=["t", "m", "sigma"])
    assert_array_equal(expected, result)


def test_many_arrow_fields_by_index():
    """arrow_fields with integer indices selects correct columns."""
    rng = np.random.default_rng(1)
    n_obs, n_lc = 32, 4
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    expected = feature.many(lcs, sorted=True, n_jobs=1)

    # struct is [extra, t, m, sigma, extra2] — t=1, m=2, sigma=3
    arrow_arr = _make_arrow_lcs_extra_fields(lcs)
    result = feature.many(arrow_arr, sorted=True, n_jobs=1, arrow_fields=[1, 2, 3])
    assert_array_equal(expected, result)


def test_many_arrow_fields_two_elements_no_sigma():
    """arrow_fields with 2 elements selects t and m without sigma."""
    rng = np.random.default_rng(2)
    n_obs, n_lc = 32, 4
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    lcs_no_sigma = [(t, m, None) for t, m, _s in lcs]
    expected = feature.many(lcs_no_sigma, sorted=True, n_jobs=1)

    arrow_arr = _make_arrow_lcs_extra_fields(lcs)
    result = feature.many(arrow_arr, sorted=True, n_jobs=1, arrow_fields=["t", "m"])
    assert_array_equal(expected, result)


def test_many_arrow_fields_mixed_name_and_index():
    """arrow_fields mixing str and int raises TypeError."""
    rng = np.random.default_rng(3)
    n_obs, n_lc = 32, 4
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    arrow_arr = _make_arrow_lcs_extra_fields(lcs)
    with pytest.raises(TypeError, match="PyArrowFields"):
        feature.many(arrow_arr, sorted=True, n_jobs=1, arrow_fields=["t", 2, 3])


def test_many_arrow_fields_nondefault_order():
    """arrow_fields lets user pick fields regardless of position order."""
    rng = np.random.default_rng(4)
    n_obs, n_lc = 32, 4
    lcs = [gen_lc(n_obs, rng=rng) for _ in range(n_lc)]

    feature = lc.Amplitude()
    expected = feature.many(lcs, sorted=True, n_jobs=1)

    # Build struct with fields in non-standard order: sigma, m, t
    pa_type = pa.float64()
    struct_type = pa.struct([("sigma", pa_type), ("m", pa_type), ("t", pa_type)])
    all_lcs = []
    for t, m, sigma in lcs:
        rows = [{"sigma": si, "m": mi, "t": ti} for ti, mi, si in zip(t, m, sigma)]
        all_lcs.append(rows)
    arrow_arr = pa.array(all_lcs, type=pa.list_(struct_type))

    result = feature.many(arrow_arr, sorted=True, n_jobs=1, arrow_fields=["t", "m", "sigma"])
    assert_array_equal(expected, result)


def test_many_arrow_fields_invalid_name():
    """arrow_fields with a nonexistent field name raises ValueError."""
    feature = lc.Amplitude()
    arr = _make_arrow_lcs([gen_lc(10, rng=np.random.default_rng(5)) for _ in range(2)])
    with pytest.raises(ValueError, match="not found"):
        feature.many(arr, sorted=True, arrow_fields=["t", "nonexistent"])


def test_many_arrow_fields_index_out_of_range():
    """arrow_fields with an out-of-range index raises ValueError."""
    feature = lc.Amplitude()
    arr = _make_arrow_lcs([gen_lc(10, rng=np.random.default_rng(6)) for _ in range(2)])
    with pytest.raises(ValueError, match="out of range"):
        feature.many(arr, sorted=True, arrow_fields=[0, 99])


def test_many_arrow_fields_wrong_count():
    """arrow_fields with 1 or 4 elements raises ValueError."""
    feature = lc.Amplitude()
    arr = _make_arrow_lcs([gen_lc(10, rng=np.random.default_rng(7)) for _ in range(2)])
    with pytest.raises(ValueError, match="2 .* or 3"):
        feature.many(arr, sorted=True, arrow_fields=["t"])
    with pytest.raises(ValueError, match="2 .* or 3"):
        feature.many(arr, sorted=True, arrow_fields=["t", "m", "sigma", "extra"])


def test_many_arrow_fields_duplicate_fields():
    """arrow_fields pointing to the same field twice raises ValueError."""
    feature = lc.Amplitude()
    arr = _make_arrow_lcs([gen_lc(10, rng=np.random.default_rng(8)) for _ in range(2)])
    with pytest.raises(ValueError, match="different fields"):
        feature.many(arr, sorted=True, arrow_fields=["t", "t"])


def test_many_arrow_fields_wrong_element_type():
    """Non-str, non-int element in arrow_fields raises TypeError."""
    feature = lc.Amplitude()
    arr = _make_arrow_lcs([gen_lc(10, rng=np.random.default_rng(9)) for _ in range(2)])
    with pytest.raises(TypeError, match="PyArrowFields"):
        feature.many(arr, sorted=True, arrow_fields=["t", 1.5])


def test_many_arrow_fields_duplicate_field_name():
    """arrow_fields with a duplicate field name raises ValueError."""
    feature = lc.Amplitude()
    # pyarrow allows structs with duplicate field names; build one without dict literals
    # (dict literals deduplicate keys, so use from_arrays instead)
    dup_struct_type = pa.struct([("t", pa.float64()), ("m", pa.float64()), ("m", pa.float64())])
    inner = pa.StructArray.from_arrays(
        [pa.array([1.0]), pa.array([2.0]), pa.array([3.0])],
        names=["t", "m", "m"],
    )
    offsets = pa.array([0, 1], type=pa.int32())
    arr = pa.ListArray.from_arrays(offsets, inner).cast(pa.list_(dup_struct_type))
    with pytest.raises(ValueError, match="ambiguous"):
        feature.many(arr, sorted=True, arrow_fields=["t", "m"])
