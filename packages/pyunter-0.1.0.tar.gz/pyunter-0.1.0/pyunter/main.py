import time
from .utils import reversedcount

class CannotStopCount(Exception):
	pass

stop = False
def startcount(start, stop, step=1, wait=0, stopOn=None):
	global i
	for i in range(start, stop + 1, step):
		if wait:
			time.sleep(wait)
		if stopOn:
			if i > stopOn:
				return
		print(i)
		if stop is True:
			break

def stopcount():
	try:
		global stop
		stop = True
	except Exception:
		raise CannotStopCount("Cannot stop, this exception is custom and returns when stopcount func breaks or doesn't have access to variable for handling stopcount.")
	
def help():
	print("available count commands:\nstartcount (usage: startcount(START STOP STEP WAIT (wait for new count frame) DONTPRINT (True or False) STOPON (count frame when count should stop)\n stopcount (usage: stopcount()\nreversedcount (use as normal startcount, it's just the same but system for counting is reversed")