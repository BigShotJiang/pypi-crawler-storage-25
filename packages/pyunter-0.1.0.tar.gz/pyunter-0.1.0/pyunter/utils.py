def reversedcount(start, stop, step=1, wait=0, dontPrint=False, stopOn=None):
	global i
	for i in reversed(range(start, stop + 1, step)):
		if wait:
			time.sleep(wait)
		if dontPrint is True:
			return
		if stopOn:
			if i > stopOn:
				return
		print(i)
		if stop is True:
			break
