# pyunter

Easy simple counting utility made for everyone and made for more better programming using counters

## Installation

```bash
pip install .
```

## Usage

```python
from pyunter import startcount, reversedcount

startcount(1, 10)
reversedcount(10, 1)
```

(this is just a test)