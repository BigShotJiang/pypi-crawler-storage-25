# serianshipkit

Official Python SDK for the [Serian ShipKit](https://serianshipkit.com) shipping API.  
Minimal, zero-dependency (stdlib only).

## Install

```bash
pip install serianshipkit
```

Requires **Python 3.9+**.

## Quick Start

```python
from serianshipkit import SerianLogistics

sl = SerianLogistics(api_key="sk_live_xxx")

# 1. Get rates
result = sl.rates.list(
    shipper={"name": "Acme", "street1": "1 Main", "city": "Accra",
             "state": "GA", "zip": "00233", "country": "GH"},
    recipient={"name": "Jane", "street1": "1 Oak", "city": "Lagos",
               "state": "LA", "zip": "100001", "country": "NG"},
    parcels=[{"length": 20, "width": 15, "height": 10, "weight": 1,
              "dimension_unit": "CM", "weight_unit": "KG"}],
)

# 2. Create a shipment
shipment = sl.shipments.create(
    {"rate_id": result["rates"][0]["rate_id"], "reference": "order-123"},
    idempotency_key="order-123",
)

print(shipment["tracking_number"], shipment["label_url"])
```

## Configuration

| Parameter  | Type  | Default                               | Description                        |
| ---------- | ----- | ------------------------------------- | ---------------------------------- |
| `api_key`  | `str` | —                                     | Your Serian API key (required)     |
| `base_url` | `str` | `https://api.serianshipkit.com`     | API base URL                       |
| `retries`  | `int` | `3`                                   | Auto-retry on 429/5xx with backoff |

## Error Handling

```python
from serianshipkit import SerianLogistics, SerianLogisticsError

try:
    sl.shipments.create(payload)
except SerianLogisticsError as e:
    print(e.status, e.code, e.request_id)
```

## License

MIT — Full API reference at <https://serianshipkit.com/docs>
