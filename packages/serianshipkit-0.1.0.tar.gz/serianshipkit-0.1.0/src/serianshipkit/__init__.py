"""Serian ShipKit Python SDK — minimal, dependency-free (uses stdlib).

    pip install requests   # optional; this SDK falls back to urllib if absent.
"""

from __future__ import annotations
import json
import time
import urllib.request
import urllib.error
from typing import Any, Dict, Optional


class SerianLogisticsError(Exception):
    def __init__(self, status: int, body: Dict[str, Any]):
        self.status = status
        self.body = body
        err = body.get("error", {}) if isinstance(body, dict) else {}
        self.code = err.get("code", "unknown")
        self.request_id = body.get("request_id") if isinstance(body, dict) else None
        super().__init__(err.get("message", f"HTTP {status}"))


class _Resource:
    def __init__(self, client: "SerianLogistics", path: str):
        self._client = client
        self._path = path


class _Rates(_Resource):
    def list(self, **body: Any) -> Dict[str, Any]:
        return self._client._request("POST", "/rates", body)


class _Shipments(_Resource):
    def create(self, body: Dict[str, Any], idempotency_key: Optional[str] = None) -> Dict[str, Any]:
        return self._client._request("POST", "/shipments", body, idempotency_key)

    def get(self, shipment_id: str) -> Dict[str, Any]:
        return self._client._request("GET", f"/shipments/{shipment_id}")

    def list(self, **params: Any) -> Dict[str, Any]:
        q = "&".join(f"{k}={v}" for k, v in params.items())
        return self._client._request("GET", f"/shipments?{q}")

    def cancel(self, shipment_id: str) -> Dict[str, Any]:
        return self._client._request("DELETE", f"/shipments/{shipment_id}")


class _Tracking(_Resource):
    def get(self, tracking_number: str, carrier: str = "fedex") -> Dict[str, Any]:
        return self._client._request(
            "GET", f"/tracking?tracking_number={tracking_number}&carrier={carrier}"
        )


class SerianLogistics:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.serianshipkit.com",
        retries: int = 3,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.retries = retries
        self.rates = _Rates(self, "/rates")
        self.shipments = _Shipments(self, "/shipments")
        self.tracking = _Tracking(self, "/tracking")

    def _request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        url = f"{self.base_url}/api/v1{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "serianshipkit-python/0.1.0",
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key

        data = json.dumps(body).encode() if body is not None else None

        for attempt in range(self.retries + 1):
            req = urllib.request.Request(url, data=data, method=method, headers=headers)
            try:
                with urllib.request.urlopen(req, timeout=20) as resp:
                    return json.loads(resp.read().decode() or "{}")
            except urllib.error.HTTPError as e:
                payload = {}
                try:
                    payload = json.loads(e.read().decode() or "{}")
                except Exception:
                    pass
                if e.code == 429 or (500 <= e.code < 600 and attempt < self.retries):
                    retry_after = int(e.headers.get("retry-after", "1"))
                    time.sleep(retry_after)
                    continue
                raise SerianLogisticsError(e.code, payload) from e

        raise SerianLogisticsError(0, {"error": {"message": "max retries exceeded"}})
