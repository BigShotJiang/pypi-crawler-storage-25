# BuildAI CLI

Typer-based CLI with two modes: standalone (PyPI, API-backed) and workspace (repo-local, DB-direct).

## Two Planes

| Mode | Install | Auth | DB Access |
|------|---------|------|-----------|
| Standalone (`buildai`) | `uv tool install buildai-cli` | API key / JWT | Through API |
| Workspace (`uv run buildai`) | Repo-local editable install | IAM / password | Direct via `admin` |

## Key Commands

```bash
buildai query "SELECT count(*) FROM core.clips"        # API-backed
buildai admin query "SELECT count(*) FROM core.clips"   # DB-direct
buildai admin schema tables                              # Schema introspection
buildai admin schema describe core.clips                 # Table details
uv run buildai dev use local                             # Set this worktree's deployment profile
uv run buildai dev current                               # Show resolved worktree target
buildai admin --write database migrate all               # Run migrations
buildai admin database diff --from preview --to production  # Migration delta
```

## Guards

- `admin` subcommands require workspace install + gcloud IAM.
- Writes require `--write` flag.
- Production migrations prompt for confirmation.
- Worktree app/runtime targeting comes from `uv run buildai dev use <profile>`.
- `buildai admin --env` selects the explicit DB lane: `production`, `preview`, `dev`.
- Do not confuse `--env preview` with the deployment profiles `local`, `preview`, or `staging`.

## Reference

CLI mode guide: `docs/how-to/choose-buildai-mode.md`
Database roles: `docs/database-roles.md`
