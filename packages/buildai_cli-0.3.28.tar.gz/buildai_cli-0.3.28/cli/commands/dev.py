"""Per-worktree development environment commands."""

from __future__ import annotations

import json
import os
import shlex
import subprocess
from pathlib import Path
from typing import Any

import typer

from cli.console import error, info, success
from cli.dev_context import (
    VALID_PROFILES,
    build_dev_context,
    clear_branch_preview_name,
    current_context_snapshot,
    export_env_lines,
    find_context_path,
    get_branch_preview_name,
    load_dev_context,
    save_dev_context,
    set_branch_preview_name,
)

app = typer.Typer(
    name="dev",
    help="Manage the gitignored per-worktree environment context.",
    no_args_is_help=True,
)


def _context_file_path() -> Path | None:
    explicit_path = os.getenv("BUILDAI_CONTEXT_PATH", "").strip()
    if explicit_path:
        return Path(explicit_path).expanduser()
    return find_context_path()


def _db_target(context: dict[str, Any]) -> dict[str, Any]:
    value = context.get("database_target")
    return value if isinstance(value, dict) else {}


def _runtime_target(context: dict[str, Any]) -> dict[str, Any]:
    value = context.get("runtime_target")
    return value if isinstance(value, dict) else {}


def _print_snapshot(snapshot: dict[str, Any]) -> None:
    db = _db_target(snapshot)
    runtime = _runtime_target(snapshot)
    path = _context_file_path()
    typer.echo(f"configured: {'yes' if snapshot.get('configured') else 'no'}")
    typer.echo(f"context_path: {path if path else 'unset'}")
    typer.echo(f"profile: {snapshot.get('profile') or 'unset'}")
    deployment_profile = snapshot.get("deployment_profile") or snapshot.get("profile") or "unset"
    typer.echo(f"deployment_profile: {deployment_profile}")
    typer.echo(f"branch: {snapshot.get('branch') or 'unknown'}")
    typer.echo(f"preview_env_id: {snapshot.get('preview_env_id') or 'unknown'}")
    typer.echo(f"preview_name: {snapshot.get('preview_name') or 'unset'}")
    typer.echo(f"api_url: {snapshot.get('api_url') or 'unset'}")
    typer.echo(f"mcp_url: {snapshot.get('mcp_url') or 'unset'}")
    typer.echo(f"app_env: {snapshot.get('app_env') or 'unset'}")
    typer.echo(f"runtime_region: {runtime.get('region') or 'unset'}")
    typer.echo(f"db_cluster: {db.get('cluster') or 'unset'}")
    typer.echo(f"db_instance: {db.get('instance') or 'unset'}")
    typer.echo(f"db_region: {db.get('region') or 'unset'}")
    typer.echo(f"db_name: {db.get('database') or 'unset'}")
    typer.echo(f"db_user: {db.get('user') or 'unset'}")
    if "use_iam_auth" in db:
        typer.echo(f"db_iam_auth: {db['use_iam_auth']}")
    typer.echo(f"cli_access_profile: {snapshot.get('cli_access_profile') or 'unset'}")


@app.command("current")
def current(
    json_output: bool = typer.Option(False, "--json", help="Emit the resolved context as JSON."),
) -> None:
    """Show the current worktree environment context."""
    snapshot = current_context_snapshot()
    if json_output:
        typer.echo(json.dumps(snapshot, indent=2, sort_keys=True))
        return
    _print_snapshot(snapshot)


@app.command("use")
def use(
    profile: str = typer.Argument(..., help="Preset profile to save for this worktree."),
    api_url: str | None = typer.Option(None, "--api-url", help="Override API base URL."),
    mcp_url: str | None = typer.Option(None, "--mcp-url", help="Override MCP base URL."),
    data_url: str | None = typer.Option(None, "--data-url", help="Override internal app URL."),
    partners_url: str | None = typer.Option(
        None, "--partners-url", help="Override partner app URL."
    ),
    app_env: str | None = typer.Option(
        None, "--app-env", help="Override APP_ENV (development, preview, production, test)."
    ),
    db_cluster: str | None = typer.Option(
        None, "--db-cluster", help="Override AlloyDB cluster id."
    ),
    db_instance: str | None = typer.Option(
        None, "--db-instance", help="Override AlloyDB instance id."
    ),
    db_region: str | None = typer.Option(None, "--db-region", help="Override AlloyDB region."),
    db_name: str | None = typer.Option(None, "--db-name", help="Override database name."),
    db_user: str | None = typer.Option(None, "--db-user", help="Override database user."),
    db_iam_auth: bool = typer.Option(False, "--db-iam-auth", help="Force IAM DB auth."),
    db_password_auth: bool = typer.Option(
        False, "--db-password-auth", help="Force password DB auth."
    ),
    preview_name: str | None = typer.Option(
        None,
        "--preview-name",
        help="Preferred public preview alias for this worktree. Stored locally, not committed.",
    ),
    cli_profile: str | None = typer.Option(
        None, "--cli-profile", help="Optional DAL/ops CLI access profile."
    ),
    yes: bool = typer.Option(False, "--yes", help="Skip the production confirmation prompt."),
) -> None:
    """Save the worktree environment context."""
    normalized_profile = profile.strip().lower()
    if normalized_profile not in VALID_PROFILES:
        error(f"Invalid profile '{profile}'. Valid: {', '.join(sorted(VALID_PROFILES))}.")
        raise typer.Exit(1)
    if db_iam_auth and db_password_auth:
        error("Choose only one of --db-iam-auth or --db-password-auth.")
        raise typer.Exit(1)
    if normalized_profile == "production" and not yes:
        confirmed = typer.confirm(
            "This will make this worktree default to production. Continue?", default=False
        )
        if not confirmed:
            raise typer.Exit(1)

    resolved_db_iam_auth: bool | None = None
    if db_iam_auth:
        resolved_db_iam_auth = True
    elif db_password_auth:
        resolved_db_iam_auth = False

    try:
        context = build_dev_context(
            profile=normalized_profile,
            api_url=api_url,
            mcp_url=mcp_url,
            data_url=data_url,
            partners_url=partners_url,
            app_env=app_env,
            db_cluster=db_cluster,
            db_instance=db_instance,
            db_region=db_region,
            db_name=db_name,
            db_user=db_user,
            db_iam_auth=resolved_db_iam_auth,
            preview_name=preview_name,
            cli_access_profile=cli_profile,
        )
        context_path = save_dev_context(context)
        branch_name = str(context.get("branch") or "").strip()
        if preview_name and branch_name:
            set_branch_preview_name(branch_name, preview_name)
    except Exception as exc:
        error(str(exc))
        raise typer.Exit(1) from exc

    success(f"Saved worktree context to {context_path}")
    if preview_name and context.get("branch"):
        info(f"Saved preview alias `{preview_name}` for branch `{context['branch']}` in local git config.")
    info('Run `eval "$(uv run buildai dev env)"` in your shell to export it immediately.')


@app.command("claim-preview")
def claim_preview(
    name: str | None = typer.Option(
        None,
        "--name",
        help="Public preview alias to bind. Defaults to the saved preview_name or branch slug.",
    ),
    force: bool = typer.Option(False, "--force", help="Reassign an existing alias or branch binding."),
) -> None:
    """Publish this worktree's preview alias binding into the external preview registry."""
    context = load_dev_context()
    if context is None:
        error("No worktree context found. Run `uv run buildai dev use <profile>` first.")
        raise typer.Exit(1)

    branch = str(context.get("branch") or "").strip()
    if not branch:
        error("Current worktree branch is unknown. Commit or check out the branch first.")
        raise typer.Exit(1)

    preview_name = (name or "").strip() or get_branch_preview_name(branch) or str(context.get("preview_env_id") or "").strip()
    if not preview_name:
        error("No preview alias available. Pass --name or save one with `uv run buildai dev use --preview-name ...`.")
        raise typer.Exit(1)

    repo_root = Path(__file__).resolve().parents[4]
    script = repo_root / "scripts" / "infra" / "preview_registry.py"
    cmd = [os.getenv("PYTHON", "python"), str(script), "bind", "--branch", branch, "--env-id", preview_name]
    if force:
        cmd.append("--force")

    result = subprocess.run(cmd, cwd=str(repo_root), text=True, capture_output=True, check=False)
    if result.returncode != 0:
        error(result.stderr.strip() or result.stdout.strip() or "Failed to bind preview alias.")
        raise typer.Exit(1)

    success(f"Bound branch `{branch}` to preview alias `{preview_name}`.")
    if result.stdout.strip():
        typer.echo(result.stdout.strip())


@app.command("preview-name")
def preview_name_command(
    name: str | None = typer.Argument(None, help="Alias to assign to the current branch."),
    clear: bool = typer.Option(False, "--clear", help="Remove the alias for the current branch."),
) -> None:
    """Show, set, or clear the current branch's local preview alias."""
    snapshot = current_context_snapshot()
    branch = str(snapshot.get("branch") or "").strip()
    if not branch:
        error("Current branch is unknown.")
        raise typer.Exit(1)

    if clear:
        clear_branch_preview_name(branch)
        success(f"Cleared preview alias for branch `{branch}`.")
        return

    if name:
        try:
            set_branch_preview_name(branch, name)
        except Exception as exc:
            error(str(exc))
            raise typer.Exit(1) from exc
        success(f"Saved preview alias `{name}` for branch `{branch}`.")
        return

    current = get_branch_preview_name(branch)
    typer.echo(current or "")


@app.command("env")
def env() -> None:
    """Print shell exports for the current worktree context."""
    context = load_dev_context()
    if context is None:
        error("No worktree context found. Run `uv run buildai dev use <profile>` first.")
        raise typer.Exit(1)

    lines: list[str] = []
    context_path = _context_file_path()
    if context_path is not None:
        lines.append(f"export BUILDAI_CONTEXT_PATH={shlex.quote(str(context_path))}")
    lines.extend(export_env_lines(context))
    typer.echo("\n".join(lines))
