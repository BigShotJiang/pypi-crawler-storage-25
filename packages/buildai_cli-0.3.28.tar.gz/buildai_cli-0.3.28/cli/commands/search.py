"""Semantic search commands — data plane (API-backed)."""

from __future__ import annotations

import html
import tempfile
import webbrowser
from difflib import get_close_matches
from typing import Optional

import typer

from cli.console import console
from cli.sdk_client import get_sdk_client

app = typer.Typer()

# Known collections: name → UUID
_COLLECTIONS: dict[str, str] = {
    "india 2026": "387e0754-76b5-536e-8498-896ec8153d0a",
    "india": "387e0754-76b5-536e-8498-896ec8153d0a",
    "india2026": "387e0754-76b5-536e-8498-896ec8153d0a",
    "egocentric 100k": "574438c1-95c4-50d2-a8ce-f7cbefacd56d",
    "ego100k": "574438c1-95c4-50d2-a8ce-f7cbefacd56d",
    "ego 100k": "574438c1-95c4-50d2-a8ce-f7cbefacd56d",
    "100k": "574438c1-95c4-50d2-a8ce-f7cbefacd56d",
    "egocentric 10k": "87b5a06b-a5c6-5c96-88ed-82a49513e2d9",
    "ego10k": "87b5a06b-a5c6-5c96-88ed-82a49513e2d9",
    "ego 10k": "87b5a06b-a5c6-5c96-88ed-82a49513e2d9",
    "10k": "87b5a06b-a5c6-5c96-88ed-82a49513e2d9",
}

_DEFAULT_COLLECTION = "387e0754-76b5-536e-8498-896ec8153d0a"  # India 2026


def _resolve_collection(name: str | None) -> str:
    """Resolve collection name or UUID to a collection UUID."""
    if name is None:
        return _DEFAULT_COLLECTION

    # Already a UUID?
    if len(name) == 36 and name.count("-") == 4:
        return name

    key = name.strip().lower()
    if key in _COLLECTIONS:
        return _COLLECTIONS[key]

    # Fuzzy match
    matches = get_close_matches(key, _COLLECTIONS.keys(), n=3, cutoff=0.4)
    if matches:
        hint = ", ".join(f"'{m}'" for m in matches)
        console.print(f"[yellow]Unknown collection '{name}'. Did you mean: {hint}?[/yellow]")
    else:
        known = ", ".join(sorted({v: k for k, v in reversed(list(_COLLECTIONS.items()))}.values()))
        console.print(f"[yellow]Unknown collection '{name}'. Known: {known}[/yellow]")
    raise typer.Exit(1)


@app.command()
def text(
    query: str = typer.Argument(..., help="Text query to search for"),
    collection: Optional[str] = typer.Option(
        None, "--collection", "-c", help="Collection name or UUID (default: India 2026)"
    ),
    page_size: int = typer.Option(20, "--limit", "-n", help="Number of results"),
    open_browser: bool = typer.Option(True, "--open/--no-open", help="Open results in browser"),
) -> None:
    """Search frames by text query and view results in browser."""
    collection_id = _resolve_collection(collection)
    client = get_sdk_client()

    # Over-fetch to compensate for per-worker dedup
    fetch_size = min(page_size * 3, 500)

    with console.status("Searching..."):
        page = client.search.query(
            query_text=query,
            collection_id=collection_id,
            page_size=fetch_size,
        )

    hits = page.data
    if not hits:
        console.print("[dim]No results found.[/dim]")
        raise typer.Exit(0)

    # Deduplicate: keep best-scoring hit per worker
    seen_workers: set[str] = set()
    deduped: list = []
    for hit in hits:
        key = hit.worker_id or hit.clip_id
        if key not in seen_workers:
            seen_workers.add(key)
            deduped.append(hit)
    hits = deduped[:page_size]

    console.print(f"[bold]{len(hits)}[/bold] results for [green]{query!r}[/green]")

    if open_browser:
        _open_results_html(query, hits)
    else:
        for i, hit in enumerate(hits, 1):
            console.print(
                f"  {i}. score={hit.score:.4f} clip={hit.clip_id} "
                f"factory={hit.factory_id or '—'}"
            )


def _open_results_html(query: str, hits: list) -> None:
    """Generate an HTML page with video results and open in browser."""
    cards = []
    for i, hit in enumerate(hits, 1):
        video_html = ""
        if hit.preview_video_url:
            video_html = (
                f'<video controls preload="metadata" '
                f'style="width:100%;border-radius:8px;">'
                f'<source src="{html.escape(hit.preview_video_url)}" type="video/mp4">'
                f"</video>"
            )
        elif hit.preview_image_url:
            video_html = (
                f'<img src="{html.escape(hit.preview_image_url)}" '
                f'style="width:100%;border-radius:8px;" />'
            )
        else:
            video_html = (
                '<div style="width:100%;height:200px;background:#1a1a2e;'
                "border-radius:8px;display:flex;align-items:center;"
                'justify-content:center;color:#666;">No preview</div>'
            )

        meta_parts = [f"<strong>Score:</strong> {hit.score:.4f}"]
        if hit.factory_id:
            meta_parts.append(f"<strong>Factory:</strong> {str(hit.factory_id)[:8]}…")
        if hit.worker_id:
            meta_parts.append(f"<strong>Worker:</strong> {str(hit.worker_id)[:8]}…")
        meta_parts.append(f"<strong>Clip:</strong> {str(hit.clip_id)[:8]}…")
        if hit.frame_id:
            meta_parts.append(f"<strong>Frame:</strong> {str(hit.frame_id)[:8]}…")

        cards.append(f"""
        <div class="card">
            <div class="rank">#{i}</div>
            {video_html}
            <div class="meta">{"<br>".join(meta_parts)}</div>
        </div>
        """)

    page_html = f"""<!DOCTYPE html>
<html><head>
<meta charset="utf-8">
<title>Search: {html.escape(query)}</title>
<style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{ background: #0d0d1a; color: #e0e0e0; font-family: -apple-system, system-ui, sans-serif; padding: 32px; }}
    h1 {{ font-size: 24px; font-weight: 600; margin-bottom: 8px; color: #fff; }}
    .subtitle {{ color: #888; margin-bottom: 32px; font-size: 14px; }}
    .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 24px; }}
    .card {{ background: #16162a; border-radius: 12px; padding: 16px; }}
    .card:hover {{ background: #1c1c38; }}
    .rank {{ font-size: 12px; color: #666; margin-bottom: 8px; font-weight: 600; }}
    .meta {{ margin-top: 12px; font-size: 13px; line-height: 1.8; color: #aaa; }}
    .meta strong {{ color: #ccc; }}
    video {{ background: #000; }}
</style>
</head><body>
<h1>Search: "{html.escape(query)}"</h1>
<p class="subtitle">{len(cards)} results</p>
<div class="grid">
    {"".join(cards)}
</div>
</body></html>"""

    with tempfile.NamedTemporaryFile("w", suffix=".html", delete=False) as f:
        f.write(page_html)
        path = f.name

    webbrowser.open(f"file://{path}")
    console.print(f"[dim]Opened {path}[/dim]")
