"""
Unified database management CLI.

All database operations under one command group:
    buildai admin database prepare         # Retired legacy preparation flow
    buildai admin database diff            # Compare environments (schema, indexes, data volumes)
    buildai admin database sync-schema     # Apply missing indexes, constraints, triggers
    buildai admin database sync-data       # Retired legacy data-copy flow
    buildai admin database migrate         # Run migrations, check status
    buildai admin database backfill        # Apply migrations from prod missing in non-prod
    buildai admin database verify          # Validate DB state (integrity, referential, parity)
    buildai admin database discover        # Retired legacy discovery flow
    buildai admin database status          # Overall database health summary
    buildai admin database roles           # Role management
    buildai admin database roles-setup     # Apply least-privilege roles/grants
    buildai admin database audit           # Permission auditing
    buildai admin database seed            # Run seed data scripts
"""

import asyncio
import json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

import asyncpg
import typer
from infra.auth_principal_targets import get_runtime_targets_with_database_access
from infra.migration_tracking import audit_migration_tracking, load_tracker_policy
from infra.settings import Settings, switch_environment
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from typing_extensions import Annotated

from cli.commands.sync.ddl import (
    generate_add_constraint_ddl,
    generate_index_ddl,
    generate_index_ddl_concurrent,
    generate_matview_ddl,
    generate_sequence_ddl,
    generate_trigger_ddl,
)

# Import existing sync utilities
from cli.commands.sync.models import (
    SyncDiff,
)
from cli.commands.sync.queries import (
    fetch_constraints,
    fetch_indexes,
    fetch_materialized_views,
    fetch_sequences,
    fetch_triggers,
)
from cli.console import console, dim, error, info, success, warning
from cli.context import get_connection, open_admin_database
from cli.guard import require_write

# =============================================================================
# Constants

MIGRATIONS_SA_EMAIL = "migrations-sa@data-470400.iam.gserviceaccount.com"
MIGRATIONS_SA_DB_USER = "migrations-sa@data-470400.iam"


def _migration_label(item: Any) -> str:
    filename = getattr(item, "filename", None)
    if isinstance(filename, str) and filename:
        return filename
    if isinstance(item, Path):
        return item.name
    return str(item)


async def _get_admin_connection(settings: Settings):
    """Connect as the platform admin service account for privileged DDL.

    Resolution order:
    1. ALLOYDB_ADMIN_IAM_USER_* env vars (explicit override)
    2. deployment_profiles.yaml database_admin section (canonical source of truth)
    3. ALLOYDB_PSW_PROD password fallback
    """
    return await open_admin_database(settings)


async def _get_migrations_connection(settings: Settings):
    """
    Get a dedicated migrations connection.

    Migrations should run under the migrations service account rather than the
    caller's local IAM principal so DDL authority is stable and auditable.
    """
    from infra.database import Database

    settings.validate_environment_access()

    if not settings.alloydb_instance_uri:
        raise RuntimeError("AlloyDB instance URI is not configured for this environment.")

    ip_type = "PRIVATE" if settings.use_private_ip else "PUBLIC"
    db = Database(
        instance_uri=settings.alloydb_instance_uri,
        database=settings.db_name,
        user=MIGRATIONS_SA_DB_USER,
        use_iam_auth=True,
        ip_type=ip_type,
        impersonate_sa=MIGRATIONS_SA_EMAIL,
    )
    await db.connect()
    return db


async def _set_owner_role(conn) -> bool:
    """
    Set role to buildai_owner for DDL operations.

    Returns True if successful, False if role doesn't exist or permission denied.
    """
    try:
        await conn.execute("SET ROLE buildai_owner")
        return True
    except Exception as e:
        if "does not exist" in str(e).lower() or "permission denied" in str(e).lower():
            return False
        raise


# =============================================================================

REPO_ROOT = Path(__file__).resolve().parents[4]
MIGRATIONS_DIR = REPO_ROOT / "migrations"
MIGRATIONS_TABLE = "public._migrations"
SEEDS_DIR = REPO_ROOT / "seeds"

# Table dependency ordering for safe data operations
TABLE_DEPENDENCY_ORDER = [
    # Level 0: Root tables
    "core.asset_types",
    "core.sources",
    "core.participants",
    "ops.organizations",
    "ops.sites",
    "ops.factories",
    "ops.programs",
    # Level 1: Recording and relationship roots
    "core.source_participants",
    "ops.site_sources",
    "ops.program_sources",
    # Level 2: Recording hierarchy
    "core.sessions",
    "core.streams",
    "core.clips",
    "core.frames",
    "core.assets",
]

# =============================================================================
# Data Models
# =============================================================================


@dataclass
class DatabaseStatus:
    """Overall database health status."""

    environment: str
    database_name: str
    connected: bool = False
    # Schema parity
    indexes_synced: int = 0
    indexes_total: int = 0
    constraints_synced: int = 0
    constraints_total: int = 0
    triggers_synced: int = 0
    triggers_total: int = 0
    # Migrations
    migrations_applied: int = 0
    repo_migrations_applied: int = 0
    migrations_total: int = 0
    migrations_raw_pending: int = 0
    migrations_safe_backfill_candidates: int = 0
    migrations_pending: int = 0
    migrations_db_only_allowed: int = 0
    migrations_db_only_unexpected: int = 0
    # Data
    sources_count: int = 0
    clips_count: int = 0
    frames_count: int = 0
    embeddings_count: int = 0

    @property
    def is_healthy(self) -> bool:
        """Check if database is healthy for testing."""
        return (
            self.connected
            and self.migrations_pending == 0
            and self.migrations_db_only_unexpected == 0
            and self.sources_count > 0
            and self.clips_count > 0
        )

    @property
    def health_status(self) -> str:
        """Return health status string."""
        if not self.connected:
            return "DISCONNECTED"
        if self.migrations_pending > 0:
            return "MIGRATIONS PENDING"
        if self.migrations_db_only_unexpected > 0:
            return "TRACKING DRIFT"
        if self.sources_count == 0 or self.clips_count == 0:
            return "NO DATA"
        return "READY FOR TESTING"


def _migration_requires_system_admin(path: Path) -> bool:
    for line in path.read_text(encoding="utf-8").splitlines()[:10]:
        if line.strip().lower() == "-- requires-system-admin: true":
            return True
    return False


def _validate_sync_direction(
    source: str, target: str, operation: str, allow_prod_write: bool = False
) -> None:
    """Validate that the sync direction is allowed."""
    target_is_prod = target.lower() in ("prod", "production")

    if target_is_prod:
        if operation == "data":
            raise typer.BadParameter(
                "Data writes to production are BLOCKED. Use `cli promote` for migrations instead."
            )
        if operation == "schema" and not allow_prod_write:
            raise typer.BadParameter("Schema writes to production require --allow-prod-write flag.")


async def _get_table_row_count(
    conn: asyncpg.Connection, table: str, where_clause: str | None = None
) -> int:
    """Get row count for a table with optional filter."""
    if where_clause:
        # Use parameterized query for safety
        query = f"SELECT COUNT(*) FROM {table} WHERE {where_clause}"
    else:
        query = f"SELECT COUNT(*) FROM {table}"
    result = await conn.fetchval(query)
    return result or 0


async def _compute_diff(
    source_env: str,
    target_env: str,
    schemas: Sequence[str] | None = None,
    include_indexes: bool = True,
    include_constraints: bool = True,
    include_triggers: bool = True,
    include_matviews: bool = True,
    include_sequences: bool = True,
) -> SyncDiff:
    """Compute schema diff between two environments."""
    diff = SyncDiff(source_env=source_env, target_env=target_env)
    schema_list = list(schemas) if schemas else None

    # Fetch from source
    source_settings = switch_environment(source_env)
    async with get_connection(source_settings) as source_conn:
        source_indexes = await fetch_indexes(source_conn, schema_list) if include_indexes else []
        source_constraints = (
            await fetch_constraints(source_conn, schema_list) if include_constraints else []
        )
        source_triggers = await fetch_triggers(source_conn, schema_list) if include_triggers else []
        source_matviews = (
            await fetch_materialized_views(source_conn, schema_list) if include_matviews else []
        )
        source_sequences = (
            await fetch_sequences(source_conn, schema_list) if include_sequences else []
        )

    # Fetch from target
    target_settings = switch_environment(target_env)
    async with get_connection(target_settings) as target_conn:
        target_indexes = await fetch_indexes(target_conn, schema_list) if include_indexes else []
        target_constraints = (
            await fetch_constraints(target_conn, schema_list) if include_constraints else []
        )
        target_triggers = await fetch_triggers(target_conn, schema_list) if include_triggers else []
        target_matviews = (
            await fetch_materialized_views(target_conn, schema_list) if include_matviews else []
        )
        target_sequences = (
            await fetch_sequences(target_conn, schema_list) if include_sequences else []
        )

    # Compare by full_name
    def _compare(source_items: list, target_items: list) -> tuple[list, list]:
        source_by_name = {getattr(i, "full_name"): i for i in source_items}
        target_by_name = {getattr(i, "full_name"): i for i in target_items}
        source_names = set(source_by_name.keys())
        target_names = set(target_by_name.keys())
        missing = [source_by_name[n] for n in sorted(source_names - target_names)]
        extra = [target_by_name[n] for n in sorted(target_names - source_names)]
        return missing, extra

    if include_indexes:
        diff.indexes_missing_in_target, diff.indexes_extra_in_target = _compare(
            source_indexes, target_indexes
        )
    if include_constraints:
        diff.constraints_missing, diff.constraints_extra = _compare(
            source_constraints, target_constraints
        )
    if include_triggers:
        diff.triggers_missing, diff.triggers_extra = _compare(source_triggers, target_triggers)
    if include_matviews:
        diff.matviews_missing, diff.matviews_extra = _compare(source_matviews, target_matviews)
    if include_sequences:
        diff.sequences_missing, diff.sequences_extra = _compare(source_sequences, target_sequences)

    return diff


async def _ensure_migrations_table(conn: asyncpg.Connection) -> None:
    """Ensure the migrations tracking table exists on a privileged connection."""
    await conn.execute(f"""
        CREATE TABLE IF NOT EXISTS {MIGRATIONS_TABLE} (
            id SERIAL PRIMARY KEY,
            filename TEXT UNIQUE NOT NULL,
            applied_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)


async def _get_migration_status(conn: asyncpg.Connection) -> tuple[set[str], list[Path]]:
    """Get applied migrations and all migration files without mutating database state."""
    migrations_table_exists = await conn.fetchval("SELECT to_regclass($1)", MIGRATIONS_TABLE)

    if migrations_table_exists is None:
        applied_set: set[str] = set()
    else:
        applied = await conn.fetch(f"SELECT filename FROM {MIGRATIONS_TABLE}")
        applied_set = {row["filename"] for row in applied}

    migration_files = sorted(MIGRATIONS_DIR.glob("*.sql")) if MIGRATIONS_DIR.exists() else []

    return applied_set, migration_files


async def _safe_copy_table_data(
    source_conn: asyncpg.Connection,
    target_conn: asyncpg.Connection,
    table: str,
    where_clause: str | None = None,
    params: list[Any] | None = None,
    limit: int | None = None,
) -> int:
    """
    Safely copy data from source to target table.

    Uses:
    - Parameterized queries (no SQL injection)
    - Targeted DELETE instead of TRUNCATE CASCADE
    - Transaction wrapping done at caller level

    Returns:
        Number of rows copied
    """
    schema_name, table_name = table.split(".")
    params = params or []
    if table == "observations.embedding_spaces":
        # Reference data - don't delete, just upsert
        pass

    # Step 2: Build and execute SELECT query
    query = f"SELECT * FROM {table}"
    if where_clause:
        query += f" WHERE {where_clause}"
    if limit:
        query += f" LIMIT {limit}"

    rows = await source_conn.fetch(query, *params)
    if not rows:
        return 0

    # Step 3: Insert into target using COPY protocol
    columns = list(rows[0].keys())
    records = [tuple(row[col] for col in columns) for row in rows]

    # For embedding_spaces, use ON CONFLICT to handle duplicates
    if table == "observations.embedding_spaces":
        for record in records:
            placeholders = ", ".join(f"${i + 1}" for i in range(len(columns)))
            cols_str = ", ".join(columns)
            # Insert or skip on conflict
            await target_conn.execute(
                f"INSERT INTO {table} ({cols_str}) VALUES ({placeholders}) ON CONFLICT DO NOTHING",
                *record,
            )
        return len(records)

    await target_conn.copy_records_to_table(
        table_name,
        schema_name=schema_name,
        records=records,
        columns=columns,
    )

    return len(rows)


# =============================================================================
# Typer App
# =============================================================================

app = typer.Typer(
    name="database",
    help="Unified database management commands",
    no_args_is_help=True,
)


# =============================================================================
# Commands
# =============================================================================


@app.command()
def status(ctx: typer.Context) -> None:
    """
    Show overall database health summary.

    Displays:
    - Schema parity (indexes, constraints, triggers)
    - Migration status
    - Data volumes (factories, clips, frames, embeddings)
    - Overall health assessment
    """
    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        status_obj = DatabaseStatus(
            environment=settings.app_env.value,
            database_name=settings.db_name,
        )

        try:
            async with get_connection(settings) as conn:
                status_obj.connected = True

                # Get migration status
                try:
                    migration_audit = await audit_migration_tracking(
                        conn,
                        policy=load_tracker_policy(),
                    )
                except Exception as exc:
                    warning(
                        "Migration tracker audit failed; continuing with raw migration "
                        f"status only: {exc}"
                    )
                    migration_audit = None
                status_obj.migrations_applied = migration_audit.applied_migrations_total
                status_obj.repo_migrations_applied = (
                    migration_audit.repo_migrations_total - migration_audit.raw_pending_count
                )
                status_obj.migrations_total = migration_audit.repo_migrations_total
                status_obj.migrations_raw_pending = migration_audit.raw_pending_count
                status_obj.migrations_safe_backfill_candidates = (
                    migration_audit.verified_safe_backfills_count
                )
                status_obj.migrations_pending = migration_audit.effective_pending_count
                status_obj.migrations_db_only_allowed = migration_audit.allowed_db_only_count
                status_obj.migrations_db_only_unexpected = migration_audit.unexpected_db_only_count

                # Get data volumes
                status_obj.sources_count = await _get_table_row_count(conn, "core.sources")
                status_obj.clips_count = await _get_table_row_count(
                    conn, "core.clips", "deleted_at IS NULL"
                )
                status_obj.frames_count = await _get_table_row_count(conn, "core.frames")
                status_obj.embeddings_count = await _get_table_row_count(
                    conn, "observations.emb_siglip2_ego100k_frame_default"
                )

        except Exception as e:
            error(f"Connection failed: {e}")

        # Display status
        console.print()
        console.print(
            Panel(
                f"[bold]Environment:[/bold] {status_obj.environment} ({status_obj.database_name})",
                title="Database Status",
            )
        )
        console.print()

        # Migrations table
        table = Table(title="Migrations")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right")
        table.add_row("Tracked rows", str(status_obj.migrations_applied))
        table.add_row("Repo applied", str(status_obj.repo_migrations_applied))
        table.add_row("Repo total", str(status_obj.migrations_total))
        table.add_row("Raw pending", str(status_obj.migrations_raw_pending))
        table.add_row("Safe backfills", str(status_obj.migrations_safe_backfill_candidates))
        table.add_row(
            "Effective pending",
            f"[red]{status_obj.migrations_pending}[/red]"
            if status_obj.migrations_pending > 0
            else "[green]0[/green]",
        )
        table.add_row("Allowed DB-only", str(status_obj.migrations_db_only_allowed))
        table.add_row(
            "Unexpected DB-only",
            f"[red]{status_obj.migrations_db_only_unexpected}[/red]"
            if status_obj.migrations_db_only_unexpected > 0
            else "[green]0[/green]",
        )
        console.print(table)
        console.print()

        # Data table
        table = Table(title="Data Volumes")
        table.add_column("Entity", style="cyan")
        table.add_column("Count", justify="right")
        table.add_row("Sources", f"{status_obj.sources_count:,}")
        table.add_row("Clips", f"{status_obj.clips_count:,}")
        table.add_row("Frames", f"{status_obj.frames_count:,}")
        table.add_row("Embeddings", f"{status_obj.embeddings_count:,}")
        console.print(table)
        console.print()

        # Health assessment
        health = status_obj.health_status
        if health == "READY FOR TESTING":
            success(f"Health: {health}")
        else:
            warning(f"Health: {health}")

    asyncio.run(run())


@app.command()
def diff(
    ctx: typer.Context,
    source: Annotated[str, typer.Option("--source", "-s", help="Source environment")] = "prod",
    target: Annotated[str, typer.Option("--target", "-t", help="Target environment")] = "dev",
    schema_only: Annotated[
        bool, typer.Option("--schema-only", help="Only show schema differences")
    ] = False,
    data_only: Annotated[
        bool, typer.Option("--data-only", help="Only show data volume differences")
    ] = False,
    output_format: Annotated[
        str, typer.Option("--format", "-f", help="Output format: table, json, markdown")
    ] = "table",
) -> None:
    """
    Compare environments (schema, indexes, data volumes).

    Shows differences between source and target databases including:
    - Missing indexes, constraints, triggers, matviews
    - Migration discrepancies
    - Data volume comparison
    """

    async def run() -> None:
        info(f"Comparing {source} -> {target}...")
        console.print()

        results: dict[str, Any] = {"source": source, "target": target}

        if not data_only:
            # Schema diff
            schema_diff = await _compute_diff(source, target)
            results["schema"] = schema_diff.to_dict()

            if output_format == "table":
                if schema_diff.is_empty():
                    success("Schema: No differences")
                else:
                    summary = schema_diff.summary()
                    table = Table(title="Schema Differences")
                    table.add_column("Object Type", style="cyan")
                    table.add_column(f"Missing in {target}", justify="right", style="red")
                    table.add_column(f"Extra in {target}", justify="right", style="yellow")

                    if summary["indexes_missing"] or summary["indexes_extra"]:
                        table.add_row(
                            "Indexes",
                            str(summary["indexes_missing"]),
                            str(summary["indexes_extra"]),
                        )
                    if summary["constraints_missing"] or summary["constraints_extra"]:
                        table.add_row(
                            "Constraints",
                            str(summary["constraints_missing"]),
                            str(summary["constraints_extra"]),
                        )
                    if summary["triggers_missing"] or summary["triggers_extra"]:
                        table.add_row(
                            "Triggers",
                            str(summary["triggers_missing"]),
                            str(summary["triggers_extra"]),
                        )
                    if summary["matviews_missing"] or summary["matviews_extra"]:
                        table.add_row(
                            "Materialized Views",
                            str(summary["matviews_missing"]),
                            str(summary["matviews_extra"]),
                        )

                    console.print(table)

            # Migration diff
            source_settings = switch_environment(source)
            target_settings = switch_environment(target)

            async with get_connection(source_settings) as source_conn:
                source_applied, _ = await _get_migration_status(source_conn)

            async with get_connection(target_settings) as target_conn:
                target_applied, migration_files = await _get_migration_status(target_conn)

            missing_in_target = source_applied - target_applied
            extra_in_target = target_applied - source_applied

            results["migrations"] = {
                "source_applied": len(source_applied),
                "target_applied": len(target_applied),
                "missing_in_target": list(sorted(missing_in_target)),
                "extra_in_target": list(sorted(extra_in_target)),
            }

            if output_format == "table":
                console.print()
                if missing_in_target:
                    warning(f"Migrations in {source} but not in {target}: {len(missing_in_target)}")
                    for m in sorted(missing_in_target)[:5]:
                        console.print(f"  - {m}")
                    if len(missing_in_target) > 5:
                        dim(f"  ... and {len(missing_in_target) - 5} more")
                else:
                    success("Migrations: In sync")

        if not schema_only:
            console.print()
            # Data volume comparison
            source_settings = switch_environment(source)
            target_settings = switch_environment(target)

            data_comparison = {}

            async with get_connection(source_settings) as source_conn:
                data_comparison["source"] = {
                    "clips": await _get_table_row_count(
                        source_conn, "core.clips", "deleted_at IS NULL"
                    ),
                    "frames": await _get_table_row_count(source_conn, "core.frames"),
                    "embeddings": await _get_table_row_count(
                        source_conn, "observations.emb_siglip2_ego100k_frame_default"
                    ),
                }

            async with get_connection(target_settings) as target_conn:
                data_comparison["target"] = {
                    "clips": await _get_table_row_count(
                        target_conn, "core.clips", "deleted_at IS NULL"
                    ),
                    "frames": await _get_table_row_count(target_conn, "core.frames"),
                    "embeddings": await _get_table_row_count(
                        target_conn, "observations.emb_siglip2_ego100k_frame_default"
                    ),
                }

            results["data"] = data_comparison

            if output_format == "table":
                table = Table(title="Data Volumes")
                table.add_column("Entity", style="cyan")
                table.add_column(source, justify="right")
                table.add_column(target, justify="right")
                table.add_column("Ratio", justify="right", style="dim")

                for entity in ["clips", "frames", "embeddings"]:
                    s_val = data_comparison["source"][entity]
                    t_val = data_comparison["target"][entity]
                    ratio = f"{t_val / s_val * 100:.2f}%" if s_val > 0 else "N/A"
                    table.add_row(
                        entity.capitalize(),
                        f"{s_val:,}",
                        f"{t_val:,}",
                        ratio,
                    )

                console.print(table)

        if output_format == "json":
            console.print(json.dumps(results, indent=2, default=str))

    asyncio.run(run())


@app.command("sync-schema")
def sync_schema(
    ctx: typer.Context,
    source: Annotated[str, typer.Option("--source", "-s", help="Source environment")] = "prod",
    target: Annotated[str, typer.Option("--target", "-t", help="Target environment")] = "dev",
    indexes: Annotated[bool, typer.Option("--indexes", help="Apply missing indexes")] = False,
    constraints: Annotated[
        bool, typer.Option("--constraints", help="Apply missing constraints")
    ] = False,
    triggers: Annotated[bool, typer.Option("--triggers", help="Apply missing triggers")] = False,
    all_objects: Annotated[bool, typer.Option("--all", help="Apply all missing objects")] = False,
    concurrent: Annotated[
        bool, typer.Option("--concurrent", help="Use CONCURRENTLY for indexes")
    ] = False,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", "-n", help="Show DDL without executing")
    ] = False,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation prompt")] = False,
) -> None:
    """
    Apply missing schema objects from source to target.

    Examples:
        buildai admin database sync-schema --all          # Apply everything
        buildai admin database sync-schema --indexes      # Just indexes
        buildai admin database sync-schema --dry-run      # Preview DDL
    """

    if not dry_run:
        require_write(ctx, "Database schema sync")

    async def run() -> None:
        _validate_sync_direction(source, target, "schema")

        if not any([indexes, constraints, triggers, all_objects]):
            error("Specify object type: --indexes, --constraints, --triggers, or --all")
            raise typer.Exit(1)

        info(f"Computing diff: {source} -> {target}...")
        schema_diff = await _compute_diff(
            source,
            target,
            include_indexes=indexes or all_objects,
            include_constraints=constraints or all_objects,
            include_triggers=triggers or all_objects,
            include_matviews=all_objects,
            include_sequences=all_objects,
        )

        objects_to_apply: list[Any] = []
        ddl_statements: list[str] = []

        if indexes or all_objects:
            for idx in schema_diff.indexes_missing_in_target:
                objects_to_apply.append(idx)
                if concurrent:
                    ddl_statements.append(generate_index_ddl_concurrent(idx))
                else:
                    ddl_statements.append(generate_index_ddl(idx))

        if constraints or all_objects:
            for c in schema_diff.constraints_missing:
                objects_to_apply.append(c)
                ddl_statements.append(generate_add_constraint_ddl(c))

        if triggers or all_objects:
            for t in schema_diff.triggers_missing:
                objects_to_apply.append(t)
                ddl_statements.append(generate_trigger_ddl(t))

        if all_objects:
            for mv in schema_diff.matviews_missing:
                objects_to_apply.append(mv)
                ddl_statements.append(generate_matview_ddl(mv))

            for seq in schema_diff.sequences_missing:
                objects_to_apply.append(seq)
                ddl_statements.append(generate_sequence_ddl(seq))

        if not objects_to_apply:
            success(f"No objects to apply. {target} is in sync with {source}.")
            return

        console.print()
        info(f"Found {len(objects_to_apply)} object(s) to apply")

        if dry_run:
            info("DDL statements (dry run):")
            for stmt in ddl_statements:
                console.print(Syntax(stmt, "sql", theme="monokai"))
                console.print()
            return

        if not yes:
            target_is_prod = target.lower() in ("prod", "production")
            if target_is_prod:
                warning("You are about to modify PRODUCTION!")
            if not typer.confirm(f"Apply {len(objects_to_apply)} object(s) to {target}?"):
                info("Cancelled.")
                return

        info(f"Applying {len(objects_to_apply)} object(s) to {target}...")
        target_settings = switch_environment(target)

        succeeded = 0
        failed = 0

        async with get_connection(target_settings) as conn:
            for obj, stmt in zip(objects_to_apply, ddl_statements):
                obj_name = getattr(obj, "full_name", str(obj))
                try:
                    await conn.execute(stmt)
                    success(f"  Applied: {obj_name}")
                    succeeded += 1
                except Exception as e:
                    error(f"  Failed {obj_name}: {e}")
                    failed += 1

        console.print()
        if failed == 0:
            success(f"All {succeeded} object(s) applied successfully.")
        else:
            warning(f"Completed: {succeeded} succeeded, {failed} failed.")

    asyncio.run(run())


@app.command("sync-data")
def sync_data(
    ctx: typer.Context,
    factory: Annotated[
        str | None, typer.Option("--factory", "-f", help="Retired pre-reset option")
    ] = None,
    discover: Annotated[bool, typer.Option("--discover", help="Retired pre-reset option")] = False,
    limit: Annotated[
        int | None, typer.Option("--limit", "-l", help="Retired pre-reset option")
    ] = None,
    include_embeddings: Annotated[
        bool, typer.Option("--include-embeddings", help="Retired pre-reset option")
    ] = False,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", "-n", help="Retired pre-reset option")
    ] = False,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Retired pre-reset option")] = False,
) -> None:
    """Retire the old sampled data-copy flow."""
    _ = (ctx, factory, discover, limit, include_embeddings, dry_run, yes)
    error(
        "database sync-data is retired. The old sampled copy flow was built for "
        "a pre-reset schema and has not been migrated to the current source/site model."
    )
    raise typer.Exit(1)


@app.command()
def migrate(
    ctx: typer.Context,
    target: Annotated[str | None, typer.Argument(help="Migration file or 'all'")] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Show without executing")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="Statement timeout in seconds")] = 3600,
    as_admin: Annotated[
        bool,
        typer.Option(
            "--as-admin",
            help="Run with the system-admin DB connection instead of migrations-sa.",
        ),
    ] = False,
) -> None:
    """
    Run database migrations.

    Examples:
        buildai admin database migrate                  # Show pending migrations
        buildai admin database migrate all              # Run all pending
        buildai admin database migrate 001_create.sql   # Run specific migration
    """
    if target is not None and not dry_run:
        require_write(ctx, "Database migrations")
    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        if not MIGRATIONS_DIR.exists():
            error(f"Migrations directory not found: {MIGRATIONS_DIR}")
            raise typer.Exit(1)

        async def _open_migration_db():
            return (
                await _get_admin_connection(settings)
                if as_admin
                else await _get_migrations_connection(settings)
            )

        if target is None or dry_run:
            status_db = await _open_migration_db()
            try:
                conn = status_db.conn
                await conn.execute(
                    "SELECT set_config('buildai.app_env', $1, false)",
                    settings.app_env.value,
                )
                applied_set, migration_files = await _get_migration_status(conn)
                pending = [f for f in migration_files if f.name not in applied_set]
                try:
                    migration_audit = await audit_migration_tracking(
                        conn,
                        policy=load_tracker_policy(),
                    )
                except Exception as exc:
                    warning(
                        "Migration tracker audit failed; continuing with raw migration "
                        f"status only: {exc}"
                    )
                    migration_audit = None

                if target is None:
                    env_name = "prod" if settings.is_production else "dev"
                    console.print(f"\n[bold]Migration Status[/bold] ({env_name})\n")
                    if migration_audit is not None:
                        applied = (
                            migration_audit.repo_migrations_total
                            - migration_audit.raw_pending_count
                        )
                        console.print(
                            f"Repo total: {len(migration_files)}, "
                            f"Tracked rows: {len(applied_set)}, "
                            f"Repo applied: {applied}, "
                            f"Raw pending: {migration_audit.raw_pending_count}, "
                            f"Effective pending: "
                            f"{migration_audit.effective_pending_count}\n"
                        )

                        if migration_audit.verified_safe_backfills:
                            console.print("[yellow]Verified safe backfill candidates:[/yellow]")
                            for item in migration_audit.verified_safe_backfills[:10]:
                                console.print(f"  - {_migration_label(item)}")
                            if len(migration_audit.verified_safe_backfills) > 10:
                                dim(
                                    "  ... and "
                                    f"{len(migration_audit.verified_safe_backfills) - 10} more"
                                )
                            console.print()

                        effective_pending = (
                            migration_audit.policy_candidates_not_verified
                            + migration_audit.unresolved_pending
                        )
                    else:
                        console.print(
                            f"Repo total: {len(migration_files)}, "
                            f"Tracked rows: {len(applied_set)}, "
                            f"Raw pending: {len(pending)}, "
                            "Effective pending: unavailable (audit failed)\n"
                        )
                        effective_pending = pending
                    if effective_pending:
                        console.print("[yellow]Effective pending migrations:[/yellow]")
                        for item in effective_pending[:10]:
                            console.print(f"  - {_migration_label(item)}")
                        if len(effective_pending) > 10:
                            dim(f"  ... and {len(effective_pending) - 10} more")
                    else:
                        success("All migrations applied")
                    if migration_audit is not None and migration_audit.unexpected_db_only:
                        console.print()
                        warning(
                            "Unexpected DB-only migration records: "
                            f"{len(migration_audit.unexpected_db_only)}"
                        )
                    return

                if target == "all":
                    to_run = pending
                else:
                    matches = [f for f in migration_files if target in f.name]
                    if not matches:
                        error(f"Migration not found: {target}")
                        raise typer.Exit(1)
                    to_run = matches

                if not to_run:
                    success("No migrations to run")
                    return

                if any(_migration_requires_system_admin(path) for path in to_run):
                    console.print(
                        "[yellow]Note:[/yellow] one or more selected migrations require --as-admin"
                    )
                console.print("[yellow]Dry run - would apply:[/yellow]")
                for f in to_run:
                    console.print(f"  - {f.name}")
            finally:
                await status_db.close()
            return

        migration_db = None
        using_owner_role = False
        conn = None
        try:
            migration_db = await _open_migration_db()
            conn = migration_db.conn
            await conn.execute(
                "SELECT set_config('buildai.app_env', $1, false)",
                settings.app_env.value,
            )
            applied_set, migration_files = await _get_migration_status(conn)
            pending = [f for f in migration_files if f.name not in applied_set]

            if target == "all":
                to_run = pending
            else:
                matches = [f for f in migration_files if target in f.name]
                if not matches:
                    error(f"Migration not found: {target}")
                    raise typer.Exit(1)
                to_run = matches
            if not to_run:
                success("No migrations to run")
                return

            requires_system_admin = any(_migration_requires_system_admin(path) for path in to_run)
            if requires_system_admin and not as_admin:
                error(
                    "Selected migration requires --as-admin. "
                    "Use the system-admin connection for ownership/pg_cron level changes."
                )
                raise typer.Exit(1)

            await _ensure_migrations_table(conn)
            # SET ROLE buildai_owner so migrations create objects under the
            # canonical owner — not the caller's service account.
            # Skip for requires-system-admin migrations: those need superuser
            # for ALTER OWNER / pg_cron and manage their own role context.
            if not requires_system_admin:
                using_owner_role = await _set_owner_role(conn)
                if not using_owner_role:
                    raise RuntimeError(
                        "Failed to SET ROLE buildai_owner. "
                        "Refusing to run migration as the caller identity."
                    )

            if settings.is_production:
                warning(f"About to run {len(to_run)} migration(s) in PRODUCTION")
                if not typer.confirm("Continue?"):
                    raise typer.Abort()

            for mig_file in to_run:
                info(f"Running {mig_file.name}...")

                try:
                    sql = mig_file.read_text()

                    if timeout == 0:
                        await conn.execute("SET statement_timeout = '0'")
                    else:
                        await conn.execute(f"SET statement_timeout = '{timeout}s'")

                    await conn.execute(sql, timeout=None)
                    await conn.execute(
                        f"INSERT INTO {MIGRATIONS_TABLE} (filename) "
                        "VALUES ($1) ON CONFLICT DO NOTHING",
                        mig_file.name,
                    )
                    success(f"  Applied {mig_file.name}")

                except Exception as e:
                    error(f"Migration failed: {mig_file.name}")
                    error(str(e))
                    raise typer.Exit(1)

            success(f"Applied {len(to_run)} migration(s)")
        finally:
            if using_owner_role and conn is not None:
                try:
                    await conn.execute("RESET ROLE")
                except Exception:
                    pass
            if migration_db is not None:
                await migration_db.close()

    asyncio.run(run())


@app.command()
def backfill(
    ctx: typer.Context,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", "-n", help="Show without executing")
    ] = False,
) -> None:
    """
    Apply migrations from prod that are missing in the non-prod target.

    This fixes the "migrations in prod but not dev" situation by
    downloading and applying migration SQL from production.
    """

    if not dry_run:
        require_write(ctx, "Database migration backfill")

    async def run() -> None:
        info("Checking migration parity...")

        prod_settings = switch_environment("prod")
        dev_settings = switch_environment("dev")

        async with get_connection(prod_settings) as prod_conn:
            prod_applied, _ = await _get_migration_status(prod_conn)

        async with get_connection(dev_settings) as dev_conn:
            dev_applied, migration_files = await _get_migration_status(dev_conn)

        missing_in_dev = prod_applied - dev_applied

        if not missing_in_dev:
            success("Non-prod has all migrations from prod")
            return

        # Find the actual migration files
        migrations_to_apply = []
        for f in migration_files:
            if f.name in missing_in_dev:
                migrations_to_apply.append(f)

        # Check for migrations that are in prod but not in our files
        in_prod_not_in_files = missing_in_dev - {f.name for f in migration_files}
        if in_prod_not_in_files:
            warning(f"Migrations in prod but not in repo: {in_prod_not_in_files}")
            warning("These may have been applied directly to prod. Manual intervention needed.")

        if not migrations_to_apply:
            warning("No migration files found to apply")
            return

        console.print()
        info(f"Found {len(migrations_to_apply)} migration(s) to backfill:")
        for f in migrations_to_apply:
            console.print(f"  - {f.name}")

        if dry_run:
            info("Dry run complete.")
            return

        if not typer.confirm("Apply these migrations to the non-prod target?"):
            info("Cancelled.")
            return

        migration_db = await _get_migrations_connection(dev_settings)
        conn = migration_db.conn
        using_owner_role = False
        try:
            using_owner_role = await _set_owner_role(conn)
            if not using_owner_role:
                raise RuntimeError(
                    "Failed to SET ROLE buildai_owner using migrations-sa for backfill."
                )
            for mig_file in sorted(migrations_to_apply, key=lambda f: f.name):
                info(f"Applying {mig_file.name}...")
                try:
                    sql = mig_file.read_text()
                    await conn.execute(sql)
                    await conn.execute(
                        f"INSERT INTO {MIGRATIONS_TABLE} (filename) "
                        "VALUES ($1) ON CONFLICT DO NOTHING",
                        mig_file.name,
                    )
                    success(f"  Applied {mig_file.name}")
                except Exception as e:
                    error(f"Failed: {e}")
                    raise typer.Exit(1)
        finally:
            if using_owner_role:
                try:
                    await conn.execute("RESET ROLE")
                except Exception:
                    pass
            await migration_db.close()

        success(f"Backfilled {len(migrations_to_apply)} migration(s)")

    asyncio.run(run())


@app.command()
def verify(
    ctx: typer.Context,
    fix: Annotated[bool, typer.Option("--fix", help="Attempt to fix issues")] = False,
) -> None:
    """
    Validate database state.

    Checks:
    - Migration parity (non-prod vs prod)
    - Schema object parity (indexes, constraints)
    - Referential integrity (no orphaned records)
    - Role assignments
    - Data completeness
    """
    settings: Settings = ctx.obj["settings"]
    issues: list[str] = []

    async def run() -> None:
        nonlocal issues

        info(f"Verifying database state ({settings.app_env.value})...")
        console.print()

        async with get_connection(settings) as conn:
            # Check 1: Migrations
            info("Checking migrations...")
            migration_audit = await audit_migration_tracking(
                conn,
                policy=load_tracker_policy(),
            )
            pending = migration_audit.effective_pending_count

            if pending == 0 and migration_audit.unexpected_db_only_count == 0:
                success(
                    "  Migrations:"
                    f" tracked={migration_audit.applied_migrations_total},"
                    f" effective_pending=0"
                )
            else:
                error(
                    "  Migrations:"
                    f" raw_pending={migration_audit.raw_pending_count}"
                    f" effective_pending={migration_audit.effective_pending_count}"
                    f" unexpected_db_only={migration_audit.unexpected_db_only_count}"
                )
                if pending > 0:
                    issues.append(f"{pending} effective pending migrations")
                if migration_audit.unexpected_db_only_count > 0:
                    issues.append(
                        f"{migration_audit.unexpected_db_only_count}"
                        " unexpected DB-only migration records"
                    )

            # Check 2: Required roles
            info("Checking roles...")
            required_roles = ["buildai_owner", "buildai_admin", "buildai_readonly"]
            existing = await conn.fetch(
                "SELECT rolname FROM pg_roles WHERE rolname = ANY($1)", required_roles
            )
            existing_names = {r["rolname"] for r in existing}

            for role in required_roles:
                if role in existing_names:
                    success(f"  Role exists: {role}")
                else:
                    error(f"  Missing role: {role}")
                    issues.append(f"Missing role: {role}")

            # Check 3: Data presence
            info("Checking data...")
            sources = await _get_table_row_count(conn, "core.sources")
            clips = await _get_table_row_count(conn, "core.clips", "deleted_at IS NULL")

            if sources > 0:
                success(f"  Sources: {sources}")
            else:
                warning("  Sources: 0 (no data)")
                issues.append("No sources in database")

            if clips > 0:
                success(f"  Clips: {clips:,}")
            else:
                warning("  Clips: 0 (no data)")
                issues.append("No clips in database")

            # Check 4: Orphaned records
            info("Checking referential integrity...")
            orphaned_frames = await conn.fetchval("""
                SELECT COUNT(*) FROM core.frames f
                LEFT JOIN core.clips c ON f.clip_id = c.id
                WHERE c.id IS NULL
            """)
            if orphaned_frames == 0:
                success("  No orphaned frames")
            else:
                error(f"  Orphaned frames: {orphaned_frames}")
                issues.append(f"{orphaned_frames} orphaned frames")

        console.print()

        # Summary
        if issues:
            error(f"Found {len(issues)} issue(s):")
            for issue in issues:
                console.print(f"  - {issue}")

            if fix:
                warning("Auto-fix not implemented for all issues.")
                console.print("Manual steps:")
                console.print("  - Migrations: buildai admin database migrate all")
                console.print("  - Roles: buildai admin database roles")
                console.print(
                    "  - Data: use explicit schema/query commands"
                    " against the current source/site model"
                )
        else:
            success("All checks passed!")

    asyncio.run(run())


@app.command()
def discover(
    ctx: typer.Context,
    count: Annotated[int, typer.Option("--count", "-c", help="Retired pre-reset option")] = 3,
    min_clips: Annotated[int, typer.Option("--min-clips", help="Minimum clip count")] = 100,
    max_clips: Annotated[int, typer.Option("--max-clips", help="Maximum clip count")] = 10000,
    require_embeddings: Annotated[
        bool, typer.Option("--require-embeddings", help="Retired pre-reset option")
    ] = False,
) -> None:
    """Retire the old sampled factory-copy discovery path."""
    _ = (ctx, count, min_clips, max_clips, require_embeddings)
    error(
        "database discover is retired. The old factory-copy path was built for a "
        "pre-reset schema and has not been migrated to the current source/site model."
    )
    raise typer.Exit(1)


@app.command()
def roles(ctx: typer.Context) -> None:
    """Show database roles and their members."""
    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        async with get_connection(settings) as conn:
            roles_query = """
                SELECT
                    r.rolname AS role,
                    r.rolsuper AS is_superuser,
                    r.rolcreaterole AS can_create_role,
                    r.rolcreatedb AS can_create_db,
                    ARRAY_AGG(DISTINCT m.rolname) FILTER (WHERE m.rolname IS NOT NULL) AS member_of
                FROM pg_roles r
                LEFT JOIN pg_auth_members am ON r.oid = am.member
                LEFT JOIN pg_roles m ON am.roleid = m.oid
                WHERE r.rolname NOT LIKE 'pg_%'
                  AND r.rolname NOT IN ('rds_iam', 'rds_superuser', 'rdsadmin', 'cloudsqlsuperuser')
                GROUP BY r.rolname, r.rolsuper, r.rolcreaterole, r.rolcreatedb
                ORDER BY r.rolname
            """
            roles_data = await conn.fetch(roles_query)

            table = Table(title="Database Roles")
            table.add_column("Role", style="cyan")
            table.add_column("Super", justify="center")
            table.add_column("Create Role", justify="center")
            table.add_column("Create DB", justify="center")
            table.add_column("Member Of", style="dim")

            for role in roles_data:
                member_of = ", ".join(role["member_of"]) if role["member_of"] else "-"
                table.add_row(
                    role["role"],
                    "[green]Yes[/green]" if role["is_superuser"] else "-",
                    "[green]Yes[/green]" if role["can_create_role"] else "-",
                    "[green]Yes[/green]" if role["can_create_db"] else "-",
                    member_of,
                )

            console.print(table)

    asyncio.run(run())


@app.command("roles-setup")
def roles_setup(
    ctx: typer.Context,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Show SQL without executing")] = False,
    as_admin: Annotated[
        bool,
        typer.Option(
            "--as-admin",
            help="Connect as postgres user via password auth (requires ALLOYDB_PSW_PROD)",
        ),
    ] = False,
    yes: Annotated[
        bool, typer.Option("--yes", "-y", help="Skip confirmation for production")
    ] = False,
) -> None:
    """
    Apply least-privilege role and grant setup.

    Uses scripts/ops/create-db-roles-leastpriv.sql.
    """
    settings: Settings = ctx.obj["settings"]

    if not dry_run:
        require_write(ctx, "Database role setup")

    sql_path = REPO_ROOT / "scripts" / "ops" / "create-db-roles-leastpriv.sql"

    if not sql_path.exists():
        error(f"SQL file not found: {sql_path}")
        raise typer.Exit(1)

    sql_content = sql_path.read_text()

    if dry_run:
        info("SQL to execute:")
        console.print(Syntax(sql_content, "sql", theme="monokai", line_numbers=False))
        return

    if settings.is_production and not yes:
        warning("This will modify PRODUCTION database roles!")
        if not typer.confirm("Are you sure you want to continue?"):
            raise typer.Abort()

    async def run() -> None:
        db = None
        connection_context = None
        using_owner_role = False

        try:
            if as_admin:
                info("Connecting as postgres (password auth)...")
                db = await _get_admin_connection(settings)
                conn = db.conn
            else:
                connection_context = get_connection(settings)
                conn = await connection_context.__aenter__()
                using_owner_role = await _set_owner_role(conn)
                if using_owner_role:
                    dim("Using role: buildai_owner")
                else:
                    dim("Role buildai_owner not available, using default permissions")

            await conn.execute(sql_content)
            success("Role setup completed.")

        except Exception as e:
            error(f"Role setup failed: {e}")
            raise typer.Exit(1)

        finally:
            if using_owner_role:
                try:
                    await conn.execute("RESET ROLE")
                except Exception:
                    pass

            if db is not None:
                await db.close()
            elif connection_context is not None:
                await connection_context.__aexit__(None, None, None)

    asyncio.run(run())


@app.command()
def audit(
    ctx: typer.Context,
    fix: Annotated[bool, typer.Option("--fix", help="Attempt to fix issues")] = False,
) -> None:
    """
    Audit AlloyDB permissions and configuration.

    Checks:
    - GCP IAM roles
    - AlloyDB users exist
    - PostgreSQL roles granted correctly
    """
    if fix:
        require_write(ctx, "AlloyDB permission fixes")
    settings: Settings = ctx.obj["settings"]
    project_id = settings.gcp_project_id
    region = settings.gcp_region

    info("Auditing AlloyDB permissions...")
    console.print()

    cluster = "buildai-india"

    # Check IAM roles
    info("Checking GCP IAM roles...")
    runtime_targets = get_runtime_targets_with_database_access()
    required_roles = ["roles/alloydb.client", "roles/alloydb.databaseUser"]

    iam_table = Table(title="IAM Role Audit")
    iam_table.add_column("Service Account", style="cyan")
    iam_table.add_column("DB Login", style="magenta")
    iam_table.add_column("alloydb.client", justify="center")
    iam_table.add_column("alloydb.databaseUser", justify="center")

    iam_issues = []

    for target in runtime_targets:
        sa_email = target.gcp_service_account_email
        db_login = target.alloydb_iam_user
        if sa_email is None or db_login is None:
            continue
        sa_name = sa_email.split("@", 1)[0]
        row = [sa_name, db_login]

        for role in required_roles:
            try:
                result = subprocess.run(
                    [
                        "gcloud",
                        "projects",
                        "get-iam-policy",
                        project_id,
                        "--flatten=bindings[].members",
                        f"--filter=bindings.role:{role}"
                        f" AND bindings.members:serviceAccount:{sa_email}",
                        "--format=value(bindings.role)",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.stdout.strip():
                    row.append("[green]Yes[/green]")
                else:
                    row.append("[red]No[/red]")
                    iam_issues.append((sa_email, role))
            except Exception:
                row.append("[yellow]?[/yellow]")

        iam_table.add_row(*row)

    console.print(iam_table)
    console.print()

    if iam_issues and fix:
        info("Fixing IAM roles...")
        for sa_email, role in iam_issues:
            try:
                subprocess.run(
                    [
                        "gcloud",
                        "projects",
                        "add-iam-policy-binding",
                        project_id,
                        f"--member=serviceAccount:{sa_email}",
                        f"--role={role}",
                        "--condition=None",
                        "--quiet",
                    ],
                    capture_output=True,
                    timeout=60,
                )
                success(f"  Added {role} to {sa_email}")
            except Exception as e:
                error(f"  Failed: {e}")

    # List AlloyDB users
    info(f"AlloyDB users in cluster: {cluster}")
    try:
        result = subprocess.run(
            [
                "gcloud",
                "alloydb",
                "users",
                "list",
                f"--cluster={cluster}",
                f"--region={region}",
                f"--project={project_id}",
                "--format=value(name.basename())",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            actual_users = {line.strip() for line in result.stdout.splitlines() if line.strip()}
            users_table = Table(title="AlloyDB IAM User Audit")
            users_table.add_column("Runtime", style="cyan")
            users_table.add_column("DB Login", style="magenta")
            users_table.add_column("Present", justify="center")

            missing_users: list[str] = []
            for target in runtime_targets:
                db_login = target.alloydb_iam_user
                if db_login is None:
                    continue
                present = db_login in actual_users
                users_table.add_row(
                    target.service_slug,
                    db_login,
                    "[green]Yes[/green]" if present else "[red]No[/red]",
                )
                if not present:
                    missing_users.append(db_login)

            console.print(users_table)
            console.print()
            if "backend-services" in actual_users:
                warning("Shared runtime DB login still exists: backend-services")
            if missing_users:
                warning("Missing AlloyDB IAM users: " + ", ".join(sorted(set(missing_users))))
        else:
            error(f"Failed: {result.stderr}")
    except Exception as e:
        error(f"Failed: {e}")


@app.command()
def seed(
    ctx: typer.Context,
    target: Annotated[str, typer.Argument(help="Seed category: shared, development, all")] = "all",
    dry_run: Annotated[
        bool, typer.Option("--dry-run", "-n", help="Show without executing")
    ] = False,
) -> None:
    """
    Run seed data scripts.

    SAFETY: Development seeds are BLOCKED in production.

    Examples:
        buildai admin database seed shared        # Shared seeds only
        buildai admin database seed development   # Local-mode seeds on the non-prod data plane
        buildai admin database seed all           # All applicable seeds
    """
    if not dry_run:
        require_write(ctx, "Database seeding")
    settings: Settings = ctx.obj["settings"]

    if target not in ["shared", "development", "all"]:
        error(f"Invalid target: {target}. Use: shared, development, or all")
        raise typer.Exit(1)

    # SAFETY: Block development seeds in production
    if settings.is_production and target in ["development", "all"]:
        error("Development seeds are BLOCKED in production!")
        dim("Use 'buildai admin database seed shared' for production reference data.")
        raise typer.Exit(1)

    # Collect seed files
    seed_files: list[tuple[str, Path]] = []

    def get_seed_files(category: str) -> list[Path]:
        seed_dir = SEEDS_DIR / category
        return sorted(seed_dir.glob("*.sql")) if seed_dir.exists() else []

    if target in ["shared", "all"]:
        for f in get_seed_files("shared"):
            seed_files.append(("shared", f))

    if target in ["development", "all"]:
        for f in get_seed_files("development"):
            seed_files.append(("development", f))

    if not seed_files:
        warning(f"No seed files found for target: {target}")
        return

    info(f"Seeds to run ({len(seed_files)} files):")
    for category, f in seed_files:
        console.print(f"  [cyan]{category}[/cyan]/{f.name}")

    if dry_run:
        dim("Dry run - no changes made")
        return

    async def run() -> None:
        async with get_connection(settings) as conn:
            for category, seed_file in seed_files:
                console.print(f"\n[cyan]Running[/cyan] {category}/{seed_file.name}...")

                sql = seed_file.read_text()

                try:
                    async with conn.transaction():
                        await conn.execute(sql)
                    success(f"  {seed_file.name}")
                except Exception as e:
                    error(f"  {seed_file.name}: {e}")
                    raise typer.Exit(1)

        console.print()
        success(f"All {len(seed_files)} seed files completed")

    asyncio.run(run())


@app.command()
def prepare(
    ctx: typer.Context,
    factory_count: Annotated[
        int, typer.Option("--factory-count", help="Retired pre-reset option")
    ] = 1,
    skip_schema: Annotated[bool, typer.Option("--skip-schema", help="Skip schema sync")] = False,
    skip_data: Annotated[bool, typer.Option("--skip-data", help="Skip data sync")] = False,
    skip_migrations: Annotated[
        bool, typer.Option("--skip-migrations", help="Skip migration backfill")
    ] = False,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", "-n", help="Show plan without executing")
    ] = False,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation prompts")] = False,
) -> None:
    """Retire the old non-prod preview-preparation flow."""
    _ = (ctx, factory_count, skip_schema, skip_data, skip_migrations, dry_run, yes)
    error(
        "database prepare is retired. It was built around the old non-production and "
        "factory-copy workflow and has not been migrated to the current source/site model."
    )
    raise typer.Exit(1)
