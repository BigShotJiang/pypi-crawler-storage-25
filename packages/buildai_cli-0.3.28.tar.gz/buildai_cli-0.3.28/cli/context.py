"""CLI context management for database connections and canonical DAL access.

This module provides a unified interface for CLI commands to access the database,
using infra.Database for AlloyDB (dev/prod) and direct asyncpg for test/CI.

Usage:
    # Simple connection (most commands)
    async with get_connection(settings) as conn:
        result = await conn.fetch("SELECT 1")

    # With canonical DAL context (for commands that use dal functions)
    async with get_cli_context(settings) as (db, ctx):
        datasets = await dal.external.datasets.list_datasets(ctx)

    # For raw SQL commands, use get_connection()
    # For commands that benefit from dal, use get_cli_context()
"""

import os
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import TYPE_CHECKING, AsyncGenerator

import asyncpg
from infra import Database, get_logger
from infra.settings import Settings, get_settings

if TYPE_CHECKING:
    from dal.context import Context

logger = get_logger(__name__)

# Environment variable to force local PostgreSQL (for test/CI)
USE_LOCAL_DB = os.getenv("USE_LOCAL_DB", "false").lower() == "true"
_ZERO_UUID = "00000000-0000-0000-0000-000000000000"
_UNRESTRICTED_CLI_PROFILES = frozenset(
    {
        "internal_admin",
        "internal_viewer",
        "analyst",
        "developer",
        "operator",
        "ml_engineer",
        "mcp",
        "agent",
    }
)


@dataclass(frozen=True)
class AdminConnectionConfig:
    """Describe the canonical admin connection the ops-plane CLI should prefer.

    This keeps DB-direct read paths deterministic when a deployment profile
    defines a dedicated admin principal instead of relying on the caller's
    personal IAM DB mapping.
    """

    user: str
    use_iam_auth: bool
    impersonate_sa: str | None = None
    password: str = ""


async def _stamp_cli_session_contract(
    conn: asyncpg.Connection,
    *,
    profile: str,
) -> None:
    """Stamp the canonical auth GUC contract for DB-direct CLI sessions."""
    unrestricted = "true" if profile in _UNRESTRICTED_CLI_PROFILES else "false"
    await conn.execute("SELECT set_config('app.principal_id', $1, false)", _ZERO_UUID)
    await conn.execute("SELECT set_config('app.unrestricted', $1, false)", unrestricted)
    await conn.execute("SELECT set_config('app.allowed_organization_ids', $1, false)", "{}")
    await conn.execute("SELECT set_config('app.allowed_site_ids', $1, false)", "{}")
    await conn.execute("SELECT set_config('app.allowed_dataset_ids', $1, false)", "{}")


def resolve_admin_connection_config(
    settings: Settings,
) -> AdminConnectionConfig | None:
    """Resolve the canonical admin DB login for this environment, if one exists.

    Resolution order is explicit env overrides first, then the checked-in
    deployment profile, then the production password fallback already used by
    privileged database commands.
    """
    from infra.deployment_profiles import deployment_profile_for_app_env, resolve_deployment_profile

    admin_iam_user = settings.effective_alloydb_admin_iam_user
    admin_impersonate_sa = settings.effective_alloydb_admin_impersonate_sa

    if not admin_iam_user or not admin_impersonate_sa:
        try:
            profile_name = deployment_profile_for_app_env(settings.app_env.value)
            profile = resolve_deployment_profile(profile_name)
            if profile.database_admin:
                admin_iam_user = admin_iam_user or profile.database_admin.iam_user
                admin_impersonate_sa = admin_impersonate_sa or profile.database_admin.impersonate_sa
        except (ValueError, KeyError):
            pass

    if admin_iam_user and admin_impersonate_sa:
        return AdminConnectionConfig(
            user=admin_iam_user,
            use_iam_auth=True,
            impersonate_sa=admin_impersonate_sa,
        )

    admin_password = os.getenv("ALLOYDB_PSW_PROD", "")
    if admin_password:
        return AdminConnectionConfig(
            user="postgres",
            use_iam_auth=False,
            password=admin_password,
        )

    return None


async def open_admin_database(settings: Settings) -> Database:
    """Open the canonical admin DB connection for privileged ops-plane access.

    Commands that need deterministic production introspection should use this
    instead of inheriting the caller's personal IAM DB login.
    """
    settings.validate_environment_access()

    if settings.is_test:
        raise RuntimeError("Admin AlloyDB connection is not available in test mode.")

    if not settings.alloydb_instance_uri:
        raise RuntimeError("AlloyDB instance URI is not configured for this environment.")

    config = resolve_admin_connection_config(settings)
    if config is None:
        raise RuntimeError(
            "Admin credentials not configured for this environment. "
            "Set ALLOYDB_ADMIN_IAM_USER_* / ALLOYDB_ADMIN_IMPERSONATE_SA_* or "
            "define database_admin in deployment_profiles.yaml."
        )

    ip_type = "PRIVATE" if settings.use_private_ip else "PUBLIC"
    db = Database(
        instance_uri=settings.alloydb_instance_uri,
        database=settings.db_name,
        user=config.user,
        password=config.password,
        use_iam_auth=config.use_iam_auth,
        ip_type=ip_type,
        impersonate_sa=config.impersonate_sa,
    )
    await db.connect()
    return db


@asynccontextmanager
async def get_connection(
    settings: Settings | None = None,
) -> AsyncGenerator[asyncpg.Connection, None]:
    """
    Get a database connection for CLI commands.

    Handles routing between:
    - AlloyDB (development/production) - via infra.Database
    - Local PostgreSQL (test/CI) - direct asyncpg

    Args:
        settings: Optional Settings instance. Uses cached settings if not provided.

    Yields:
        asyncpg.Connection for executing queries

    Usage:
        async with get_connection(settings) as conn:
            result = await conn.fetch("SELECT 1")
    """
    from cli.config import resolve_cli_profile

    if settings is None:
        settings = get_settings()
    resolved_profile = resolve_cli_profile()

    if USE_LOCAL_DB or settings.is_test:
        # Test/CI: use local PostgreSQL
        async with _local_connection(settings) as conn:
            await _stamp_cli_session_contract(conn, profile=resolved_profile)
            yield conn
    else:
        # Development/Production: use AlloyDB via infra.Database
        db = Database.from_settings(settings)
        try:
            await db.connect()
            await _stamp_cli_session_contract(db.conn, profile=resolved_profile)
            yield db.conn
        finally:
            await db.close()


@asynccontextmanager
async def get_admin_connection(
    settings: Settings | None = None,
    *,
    profile: str | None = None,
) -> AsyncGenerator[asyncpg.Connection, None]:
    """Get a connection using the canonical admin DB identity for this lane.

    This is intended for read-only ops-plane introspection where the checked-in
    deployment profile should decide the DB principal instead of the caller's
    personal IAM mapping.
    """
    from cli.config import resolve_cli_profile

    if settings is None:
        settings = get_settings()
    resolved_profile = resolve_cli_profile(profile)

    db = await open_admin_database(settings)
    try:
        await _stamp_cli_session_contract(db.conn, profile=resolved_profile)
        yield db.conn
    finally:
        await db.close()


@asynccontextmanager
async def _local_connection(
    settings: Settings,
) -> AsyncGenerator[asyncpg.Connection, None]:
    """
    Connect to local PostgreSQL (for test/CI environments).

    Uses environment variables for connection parameters:
    - DB_HOST (default: localhost)
    - DB_PORT (default: 5432)
    - DB_USER (falls back to settings.db_user)
    - DB_PASSWORD (falls back to "postgres")
    - DB_NAME (falls back to settings.db_name) - FIX: respect env var for CI
    """
    conn = await asyncpg.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "5432")),
        user=os.getenv("DB_USER") or settings.effective_db_user,
        password=os.getenv("DB_PASSWORD") or settings.effective_alloydb_password or "postgres",
        database=os.getenv("DB_NAME", settings.db_name),  # Respect DB_NAME env var for CI
        statement_cache_size=0,
    )
    try:
        yield conn
    finally:
        await conn.close()


@asynccontextmanager
async def get_cli_context(
    settings: Settings | None = None,
    *,
    profile: str | None = None,
) -> AsyncGenerator[tuple[Database | None, "Context"], None]:
    """
    Get a database connection and canonical DAL context for CLI commands.

    This is for commands that want to use canonical DAL functions instead of raw SQL.
    The context is scoped by CLI profile (default: internal_viewer).

    Args:
        settings: Optional Settings instance. Uses cached settings if not provided.

    Yields:
        Tuple of (Database instance or None, Context for DAL operations)
        - For test/CI: Database is None, Context wraps the raw connection
        - For dev/prod: Database is the infra.Database instance

    Usage:
        async with get_cli_context(settings) as (db, ctx):
            datasets = await dal.external.datasets.list_datasets(ctx)
    """
    from dal.context import Context

    from cli.config import resolve_cli_profile

    if settings is None:
        settings = get_settings()
    resolved_profile = resolve_cli_profile(profile)

    if USE_LOCAL_DB or settings.is_test:
        # Test/CI: wrap local connection in context
        async with _local_connection(settings) as conn:
            await _stamp_cli_session_contract(conn, profile=resolved_profile)
            ctx = await Context.for_cli_profile(conn, profile=resolved_profile)
            yield None, ctx
    else:
        # Development/Production: use infra.Database
        db = Database.from_settings(settings)
        try:
            await db.connect()
            await _stamp_cli_session_contract(db.conn, profile=resolved_profile)
            ctx = await Context.for_cli_profile(db, profile=resolved_profile)
            yield db, ctx
        finally:
            await db.close()
