"""CLI credential and API URL configuration."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from cli.dev_context import load_dev_context

CONFIG_DIR = Path.home() / ".buildai"
CREDENTIALS_PATH = CONFIG_DIR / "credentials.json"
DEFAULT_API_URL = "https://api.build.ai"


def _read_credentials_file() -> dict[str, Any]:
    if not CREDENTIALS_PATH.exists():
        return {}
    try:
        return json.loads(CREDENTIALS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def load_credentials() -> dict[str, Any]:
    return _read_credentials_file()


def save_credential(*, token: str, api_url: str = DEFAULT_API_URL) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_PATH.write_text(
        json.dumps({"token": token, "api_url": api_url}, indent=2) + "\n",
        encoding="utf-8",
    )
    os.chmod(CREDENTIALS_PATH, 0o600)


def clear_credential() -> None:
    if CREDENTIALS_PATH.exists():
        CREDENTIALS_PATH.unlink()


def _workspace_context() -> dict[str, Any] | None:
    try:
        return load_dev_context()
    except Exception:
        return None


def _clean_str(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    return cleaned or None


def resolve_credential() -> str:
    env_token = os.getenv("BUILDAI_TOKEN")
    if env_token:
        return env_token
    env_api_key = os.getenv("BUILDAI_API_KEY")
    if env_api_key:
        return env_api_key
    token = load_credentials().get("token")
    if token:
        return str(token)
    raise RuntimeError(
        "No credential found. Set BUILDAI_TOKEN or BUILDAI_API_KEY, or run `buildai login`."
    )


def resolve_api_url(*, include_workspace: bool = True) -> str:
    env_api_url = os.getenv("BUILDAI_API_URL")
    if env_api_url:
        return env_api_url.rstrip("/")
    if include_workspace:
        workspace_context = _workspace_context()
        workspace_api_url = _clean_str((workspace_context or {}).get("api_url"))
        if workspace_api_url:
            return workspace_api_url.rstrip("/")
    api_url = load_credentials().get("api_url")
    if isinstance(api_url, str) and api_url:
        return api_url.rstrip("/")
    return DEFAULT_API_URL


def load_cli_config() -> dict[str, Any]:
    return load_credentials()


def save_cli_config(*, profile: str | None = None, api_key: str | None = None) -> None:
    del profile
    if api_key is None:
        raise ValueError("api_key is required")
    save_credential(token=api_key, api_url=resolve_api_url(include_workspace=False))


def resolve_cli_api_key(explicit: str | None = None) -> str:
    if explicit:
        return explicit
    return resolve_credential()


def resolve_cli_profile(explicit: str | None = None) -> str:
    resolved_explicit = _clean_str(explicit)
    if resolved_explicit:
        return resolved_explicit
    env_profile = _clean_str(os.getenv("BUILDAI_CLI_PROFILE"))
    if env_profile:
        return env_profile
    workspace_context = _workspace_context()
    workspace_profile = _clean_str((workspace_context or {}).get("cli_access_profile"))
    if workspace_profile:
        return workspace_profile
    return "internal_viewer"
