"""Per-worktree developer environment context for repo-local workflows."""

from __future__ import annotations

import json
import os
import shlex
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from infra.deployment_profiles import (
    list_deployment_profiles,
    normalize_preview_env_id,
    resolve_deployment_profile,
)

DEV_CONTEXT_DIRNAME = ".buildai"
DEV_CONTEXT_FILENAME = "context.json"
DEV_CONTEXT_SUMMARY_FILENAME = "context.md"
VALID_PROFILES = {*list_deployment_profiles(), "custom"}


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _find_repo_root(start_path: Path | None = None) -> Path | None:
    current = (start_path or Path.cwd()).resolve()
    for candidate in (current, *current.parents):
        if (candidate / ".git").exists():
            return candidate
    return None


def find_context_path(start_path: Path | None = None) -> Path | None:
    """Return the repo-local worktree context path when one is available."""
    repo_root = _find_repo_root(start_path)
    if repo_root is None:
        return None
    return repo_root / DEV_CONTEXT_DIRNAME / DEV_CONTEXT_FILENAME


def require_context_path(start_path: Path | None = None) -> Path:
    """Resolve the worktree context path or fail outside this repo."""
    context_path = find_context_path(start_path)
    if context_path is None:
        raise RuntimeError("Not inside a git worktree for this repo.")
    return context_path


def load_dev_context(start_path: Path | None = None) -> dict[str, Any] | None:
    """Load the configured worktree context, honoring explicit path overrides."""
    explicit_path = os.getenv("BUILDAI_CONTEXT_PATH", "").strip()
    if explicit_path:
        path = Path(explicit_path).expanduser()
    else:
        path = find_context_path(start_path)
    if path is None or not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _git_output(args: list[str], cwd: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception:
        return None
    if result.returncode != 0:
        return None
    value = result.stdout.strip()
    return value or None


def get_branch_preview_name(branch: str | None, start_path: Path | None = None) -> str | None:
    """Return the branch-local preview alias stored in git config, if any."""
    if not branch:
        return None
    cwd = (start_path or Path.cwd()).resolve()
    value = _git_output(["config", "--local", "--get", f"branch.{branch}.buildaiPreviewName"], cwd)
    return normalize_preview_env_id(value) if value else None


def set_branch_preview_name(branch: str | None, preview_name: str, start_path: Path | None = None) -> None:
    """Persist one branch-local preview alias into local git config."""
    if not branch:
        raise RuntimeError("Cannot save preview alias without an active git branch.")
    cwd = (start_path or Path.cwd()).resolve()
    normalized = normalize_preview_env_id(preview_name)
    subprocess.run(
        ["git", "config", "--local", f"branch.{branch}.buildaiPreviewName", normalized],
        cwd=str(cwd),
        check=True,
        capture_output=True,
        text=True,
        timeout=5,
    )


def clear_branch_preview_name(branch: str | None, start_path: Path | None = None) -> None:
    """Remove the branch-local preview alias from local git config."""
    if not branch:
        return
    cwd = (start_path or Path.cwd()).resolve()
    subprocess.run(
        ["git", "config", "--local", "--unset", f"branch.{branch}.buildaiPreviewName"],
        cwd=str(cwd),
        check=False,
        capture_output=True,
        text=True,
        timeout=5,
    )


def _repo_metadata(start_path: Path | None = None) -> dict[str, Any]:
    repo_root = _find_repo_root(start_path)
    cwd = (start_path or Path.cwd()).resolve()
    branch = _git_output(["branch", "--show-current"], cwd) if repo_root else None
    commit_sha = _git_output(["rev-parse", "HEAD"], cwd) if repo_root else None
    preview_env_id = normalize_preview_env_id(branch) if branch else None
    return {
        "repo_root": str(repo_root) if repo_root else None,
        "worktree_path": str(cwd),
        "branch": branch,
        "commit_sha": commit_sha,
        "preview_env_id": preview_env_id,
    }


def _profile_defaults(profile: str, metadata: dict[str, Any]) -> dict[str, Any]:
    env_id = metadata.get("preview_env_id")
    if profile != "custom":
        resolved = resolve_deployment_profile(
            profile,
            env_id=env_id,
            override_key=metadata.get("branch"),
        )
        return {
            "deployment_profile": resolved.name,
            "runtime_target": {"region": resolved.runtime_region},
            "api_url": resolved.api_url,
            "mcp_url": resolved.mcp_url,
            "data_url": resolved.data_url,
            "partners_url": resolved.partners_url,
            "app_env": resolved.app_env,
            "database_target": resolved.database_target.as_context_dict(),
            "public_origins": dict(resolved.public_origins),
        }
    if profile == "custom":
        return {
            "deployment_profile": "custom",
            "runtime_target": {},
            "public_origins": {},
        }
    raise ValueError(f"Unknown profile: {profile}")


def build_dev_context(
    *,
    profile: str,
    api_url: str | None = None,
    mcp_url: str | None = None,
    data_url: str | None = None,
    partners_url: str | None = None,
    app_env: str | None = None,
    db_cluster: str | None = None,
    db_instance: str | None = None,
    db_region: str | None = None,
    db_name: str | None = None,
    db_user: str | None = None,
    db_iam_auth: bool | None = None,
    preview_name: str | None = None,
    cli_access_profile: str | None = None,
    start_path: Path | None = None,
) -> dict[str, Any]:
    """Build the persisted worktree context from one named deployment profile."""
    profile = profile.strip().lower()
    if profile not in VALID_PROFILES:
        raise ValueError(
            f"Unknown profile: {profile}. Valid profiles: {', '.join(sorted(VALID_PROFILES))}."
        )
    metadata = _repo_metadata(start_path)
    defaults = _profile_defaults(profile, metadata)
    resolved_app_env = app_env or defaults.get("app_env") or "development"
    database_target = dict(defaults.get("database_target") or {})
    runtime_target = dict(defaults.get("runtime_target") or {})
    public_origins = dict(defaults.get("public_origins") or {})
    if db_cluster:
        database_target["cluster"] = db_cluster
    if db_instance:
        database_target["instance"] = db_instance
    if db_region:
        database_target["region"] = db_region
    if db_name:
        database_target["database"] = db_name
    if db_user:
        database_target["user"] = db_user
    if db_iam_auth is not None:
        database_target["use_iam_auth"] = db_iam_auth

    context = {
        "version": 2,
        **metadata,
        "profile": profile,
        "deployment_profile": defaults.get("deployment_profile") or profile,
        "api_url": api_url or defaults.get("api_url"),
        "mcp_url": mcp_url or defaults.get("mcp_url"),
        "data_url": data_url or defaults.get("data_url"),
        "partners_url": partners_url or defaults.get("partners_url"),
        "app_env": resolved_app_env,
        "runtime_target": runtime_target,
        "database_target": database_target,
        "public_origins": public_origins,
        "generated_at": _now_iso(),
    }
    if cli_access_profile:
        context["cli_access_profile"] = cli_access_profile
    return context


def _resolved_deployment_profile_name(context: dict[str, Any]) -> str:
    """Return the visible deployment profile name for summaries and shell exports."""
    return str(context.get("deployment_profile") or context.get("profile") or "")


def _summary_markdown(context: dict[str, Any]) -> str:
    db = context.get("database_target") if isinstance(context.get("database_target"), dict) else {}
    runtime = (
        context.get("runtime_target") if isinstance(context.get("runtime_target"), dict) else {}
    )
    lines = [
        "# Build AI Worktree Context",
        "",
        f"- profile: `{context.get('profile') or 'unset'}`",
        f"- deployment profile: `{_resolved_deployment_profile_name(context) or 'unset'}`",
        f"- branch: `{context.get('branch') or 'unknown'}`",
        f"- worktree: `{context.get('worktree_path') or 'unknown'}`",
        f"- preview env id: `{context.get('preview_env_id') or 'none'}`",
        f"- preview name: `{context.get('preview_name') or 'none'}`",
        f"- api url: `{context.get('api_url') or 'unset'}`",
        f"- app env: `{context.get('app_env') or 'unset'}`",
        f"- runtime region: `{runtime.get('region') or 'unset'}`",
        f"- db cluster: `{db.get('cluster') or 'unset'}`",
        f"- db instance: `{db.get('instance') or 'unset'}`",
        f"- db region: `{db.get('region') or 'unset'}`",
        f"- db name: `{db.get('database') or 'unset'}`",
    ]
    if db.get("user"):
        lines.append(f"- db user: `{db['user']}`")
    if "use_iam_auth" in db:
        lines.append(f"- db iam auth: `{db['use_iam_auth']}`")
    if context.get("cli_access_profile"):
        lines.append(f"- cli access profile: `{context['cli_access_profile']}`")
    lines.append("")
    return "\n".join(lines)


def save_dev_context(context: dict[str, Any], start_path: Path | None = None) -> Path:
    """Persist the worktree context JSON plus the human-readable summary file."""
    context_path = require_context_path(start_path)
    context_path.parent.mkdir(parents=True, exist_ok=True)
    context_path.write_text(json.dumps(context, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    summary_path = context_path.parent / DEV_CONTEXT_SUMMARY_FILENAME
    summary_path.write_text(_summary_markdown(context), encoding="utf-8")
    return context_path


def export_env_lines(context: dict[str, Any]) -> list[str]:
    """Render shell exports that reproduce the saved worktree deployment context."""
    app_env = str(context.get("app_env") or "").strip()
    db = context.get("database_target") if isinstance(context.get("database_target"), dict) else {}
    runtime = (
        context.get("runtime_target") if isinstance(context.get("runtime_target"), dict) else {}
    )
    deployment_profile = shlex.quote(_resolved_deployment_profile_name(context))
    lines = [
        f"export BUILDAI_DEPLOYMENT_PROFILE={deployment_profile}",
        f"export BUILDAI_ENV_PROFILE={shlex.quote(str(context.get('profile') or ''))}",
        f"export BUILDAI_PREVIEW_ENV_ID={shlex.quote(str(context.get('preview_env_id') or ''))}",
    ]
    if context.get("preview_name"):
        lines.append(
            f"export BUILDAI_PREVIEW_NAME={shlex.quote(str(context.get('preview_name') or ''))}"
        )
    if db.get("cluster") or db.get("instance"):
        # Neutralize stale .env/legacy shell overrides so the context-selected target wins.
        lines.append("export ALLOYDB_INSTANCE_URI=''")
    if context.get("api_url"):
        lines.append(f"export BUILDAI_API_URL={shlex.quote(str(context['api_url']))}")
    if context.get("mcp_url"):
        lines.append(f"export BUILDAI_MCP_URL={shlex.quote(str(context['mcp_url']))}")
    if app_env:
        lines.append(f"export APP_ENV={shlex.quote(app_env)}")
    if db.get("cluster"):
        lines.append(f"export ALLOYDB_CLUSTER={shlex.quote(str(db['cluster']))}")
    if db.get("instance"):
        lines.append(f"export ALLOYDB_INSTANCE={shlex.quote(str(db['instance']))}")
    if runtime.get("region"):
        lines.append(f"export GCP_REGION={shlex.quote(str(runtime['region']))}")
    if db.get("region"):
        lines.append(f"export ALLOYDB_REGION={shlex.quote(str(db['region']))}")
    if db.get("database"):
        lines.append(f"export DB_NAME={shlex.quote(str(db['database']))}")
    if db.get("user"):
        if app_env == "production":
            lines.append(f"export ALLOYDB_USER_PROD={shlex.quote(str(db['user']))}")
        else:
            lines.append(f"export ALLOYDB_USER_PREVIEW={shlex.quote(str(db['user']))}")
    if "use_iam_auth" in db:
        iam_value = "true" if bool(db["use_iam_auth"]) else "false"
        if app_env == "production":
            lines.append(f"export ALLOYDB_IAM_AUTH_PROD={iam_value}")
        else:
            lines.append(f"export ALLOYDB_IAM_AUTH_PREVIEW={iam_value}")
    if context.get("cli_access_profile"):
        lines.append(
            f"export BUILDAI_CLI_PROFILE={shlex.quote(str(context['cli_access_profile']))}"
        )
    return lines


def current_context_snapshot(start_path: Path | None = None) -> dict[str, Any]:
    """Return the saved context merged with the live branch metadata snapshot."""
    metadata = _repo_metadata(start_path)
    configured = load_dev_context(start_path)
    snapshot: dict[str, Any] = {"configured": configured is not None}
    if configured is not None:
        snapshot.update(configured)
    snapshot.update(metadata)
    preview_name = get_branch_preview_name(str(metadata.get("branch") or ""), start_path)
    if preview_name:
        snapshot["preview_name"] = preview_name
    else:
        snapshot.pop("preview_name", None)
    return snapshot
