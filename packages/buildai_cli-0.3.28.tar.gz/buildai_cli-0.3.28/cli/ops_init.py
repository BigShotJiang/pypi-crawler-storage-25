"""Lazy DB/auth/observability setup for ops-plane commands.

Call ``init_ops_context(ctx)`` at the start of any ops-plane command
(or via the Typer group callback registered in ``main.py``).
"""

from __future__ import annotations

import logging
import os
from enum import Enum

import typer
from infra.deployment_profiles import deployment_profile_for_app_env, resolve_deployment_profile

from cli.console import error, info, warning


class AuthMethod(str, Enum):
    """Database authentication method."""

    IAM = "iam"
    PASSWORD = "password"


def _parse_env(value: str) -> str:
    normalized = value.strip().lower()
    if normalized in {"dev", "prod"}:
        error(
            f"Invalid environment '{value}'. "
            "Use full name: development, preview, production, or test."
        )
        raise typer.Exit(1)
    return normalized


def _resolve_context_app_env(context: dict[str, object] | None) -> str | None:
    if not context:
        return None
    value = context.get("app_env")
    if not isinstance(value, str):
        return None
    cleaned = value.strip().lower()
    return cleaned or None


def _apply_context_database_target(
    context: dict[str, object] | None,
    *,
    deployment_profile: str | None,
) -> None:
    database_target: dict[str, object] = {}
    runtime_target: dict[str, object] = {}
    if deployment_profile:
        resolved_profile = resolve_deployment_profile(
            deployment_profile,
            env_id=(
                str(context.get("preview_env_id")).strip()
                if isinstance(context, dict) and context.get("preview_env_id")
                else None
            ),
            override_key=(
                str(context.get("branch")).strip()
                if isinstance(context, dict) and context.get("branch")
                else None
            ),
        )
        database_target = resolved_profile.database_target.as_context_dict()
        runtime_target["region"] = resolved_profile.runtime_region
    if context and (
        (context.get("deployment_profile") or context.get("profile")) == deployment_profile
    ):
        raw_runtime_target = context.get("runtime_target")
        if isinstance(raw_runtime_target, dict):
            runtime_target.update(raw_runtime_target)
        raw_database_target = context.get("database_target")
        if isinstance(raw_database_target, dict):
            database_target.update(raw_database_target)

    if database_target.get("cluster") or database_target.get("instance"):
        # Neutralize stale .env overrides so the resolved context target wins.
        os.environ.setdefault("ALLOYDB_INSTANCE_URI", "")

    cluster = database_target.get("cluster")
    if isinstance(cluster, str) and cluster.strip():
        os.environ.setdefault("ALLOYDB_CLUSTER", cluster.strip())

    instance = database_target.get("instance")
    if isinstance(instance, str) and instance.strip():
        os.environ.setdefault("ALLOYDB_INSTANCE", instance.strip())

    runtime_region = runtime_target.get("region")
    if isinstance(runtime_region, str) and runtime_region.strip():
        os.environ.setdefault("GCP_REGION", runtime_region.strip())

    region = database_target.get("region")
    if isinstance(region, str) and region.strip():
        os.environ.setdefault("ALLOYDB_REGION", region.strip())

    database_name = database_target.get("database")
    if isinstance(database_name, str) and database_name.strip():
        os.environ.setdefault("DB_NAME", database_name.strip())

    normalized_profile = (deployment_profile or "").strip().lower()
    if normalized_profile == "production":
        user_key = "ALLOYDB_USER_PROD"
        iam_key = "ALLOYDB_IAM_AUTH_PROD"
    else:
        user_key = "ALLOYDB_USER_PREVIEW"
        iam_key = "ALLOYDB_IAM_AUTH_PREVIEW"

    user = database_target.get("user")
    if isinstance(user, str) and user.strip():
        os.environ.setdefault(user_key, user.strip())

    if "use_iam_auth" in database_target:
        os.environ.setdefault(iam_key, "true" if bool(database_target["use_iam_auth"]) else "false")


def _auth_env_prefix(settings_app_env: object) -> str:
    if str(settings_app_env) == "production":
        return "PROD"
    if str(settings_app_env) == "test":
        return "DEV"
    return "PREVIEW"


def init_ops_context(ctx: typer.Context):
    """Heavy DB/auth/observability init — called lazily by ops-plane commands.

    Reads raw flags stashed in ``ctx.obj`` by the lightweight main callback
    and performs the full Settings / IAM / observability setup.  Sets
    ``ctx.obj["settings"]`` and ``ctx.obj["_ops_ready"] = True``.

    Returns the ``Settings`` instance for convenience.
    """
    if ctx.obj.get("_ops_ready"):
        return ctx.obj["settings"]

    from cli._has_core import require_core
    from cli.dev_context import load_dev_context

    require_core("this command")

    from infra import init_observability
    from infra.auth import AuthError, get_effective_user_for_iam, validate_auth_config
    from infra.settings import Environment, ExecutionContext, Settings, get_settings

    verbose = ctx.obj.get("_verbose", False)
    log_level = logging.DEBUG if verbose else logging.WARNING
    init_observability("cli", log_level=log_level, enable_json_logs=False)

    workspace_context = load_dev_context()
    env_flag = ctx.obj.get("_env")
    auth_flag = ctx.obj.get("_auth")
    user_flag = ctx.obj.get("_user")

    # --- resolve environment ------------------------------------------------
    if env_flag is not None:
        try:
            app_env = Environment(_parse_env(env_flag))
        except ValueError:
            error(
                f"Invalid environment '{env_flag}'. "
                "Valid: development, preview, production, test."
            )
            raise typer.Exit(1)
    else:
        app_env_str = (
            os.getenv("APP_ENV")
            or _resolve_context_app_env(workspace_context)
            or Environment.PRODUCTION.value
        )
        try:
            app_env = Environment(_parse_env(app_env_str))
        except ValueError:
            app_env = Environment.PRODUCTION

    os.environ["APP_ENV"] = app_env.value
    deployment_profile = None
    if isinstance(workspace_context, dict):
        profile_name = workspace_context.get("deployment_profile") or workspace_context.get(
            "profile"
        )
        if isinstance(profile_name, str) and profile_name.strip():
            deployment_profile = profile_name.strip()
        preview_env_id = workspace_context.get("preview_env_id")
        if isinstance(preview_env_id, str) and preview_env_id.strip():
            os.environ["BUILDAI_PREVIEW_ENV_ID"] = preview_env_id.strip()
    if env_flag is not None:
        deployment_profile = (
            "" if app_env == Environment.TEST else deployment_profile_for_app_env(app_env.value)
        )
    elif deployment_profile is None and app_env != Environment.TEST:
        deployment_profile = deployment_profile_for_app_env(app_env.value)
    if deployment_profile:
        os.environ["BUILDAI_DEPLOYMENT_PROFILE"] = deployment_profile
    _apply_context_database_target(workspace_context, deployment_profile=deployment_profile)
    settings = Settings(app_env=app_env, execution_context=ExecutionContext.HUMAN)

    # --- resolve auth -------------------------------------------------------
    auth_info: list[str] = []
    env_prefix = _auth_env_prefix(settings.app_env)

    default_user = settings.effective_db_user
    default_use_iam = settings.effective_use_iam_auth
    default_password = settings.effective_alloydb_password

    if auth_flag is not None:
        use_iam_auth = auth_flag == AuthMethod.IAM
    else:
        use_iam_auth = default_use_iam

    if user_flag is not None:
        effective_user = user_flag
    elif use_iam_auth:
        try:
            effective_user = get_effective_user_for_iam(None, default_user)
        except AuthError as e:
            error(str(e))
            raise typer.Exit(1)
    else:
        effective_user = default_user

    try:
        validate_auth_config(
            username=effective_user,
            use_iam_auth=use_iam_auth,
            password=default_password if not use_iam_auth else "",
        )
    except AuthError as e:
        error(str(e))
        raise typer.Exit(1)

    if use_iam_auth:
        os.environ[f"ALLOYDB_IAM_AUTH_{env_prefix}"] = "true"
        auth_info.append("IAM auth")
    else:
        os.environ[f"ALLOYDB_IAM_AUTH_{env_prefix}"] = "false"
        auth_info.append("password auth")

    os.environ[f"ALLOYDB_USER_{env_prefix}"] = effective_user
    auth_info.append(f"user={effective_user}")

    # Reload settings with overrides
    get_settings.cache_clear()
    settings = Settings(app_env=settings.app_env, execution_context=ExecutionContext.HUMAN)

    try:
        settings.validate_environment_access()
    except PermissionError as e:
        error(str(e))
        raise typer.Exit(1)

    # --- store in context ---------------------------------------------------
    ctx.obj["settings"] = settings
    ctx.obj["_ops_ready"] = True

    context_profile = None
    if isinstance(workspace_context, dict):
        raw_profile = workspace_context.get("cli_access_profile")
        if isinstance(raw_profile, str) and raw_profile.strip():
            context_profile = raw_profile.strip()
    profile = (
        ctx.obj.get("cli_profile")
        or os.getenv("BUILDAI_CLI_PROFILE")
        or context_profile
        or "internal_admin"
    )
    ctx.obj["cli_profile"] = profile
    os.environ["BUILDAI_CLI_PROFILE"] = profile
    if ctx.obj.get("allow_write"):
        os.environ["BUILDAI_CLI_WRITE"] = "true"

    # --- banner -------------------------------------------------------------
    auth_str = f" [{', '.join(auth_info)}]"
    if settings.is_production:
        warning(f"Environment: PRODUCTION ({settings.db_name}){auth_str} | profile={profile}")
    else:
        message = (
            f"Environment: {settings.app_env.value} ({settings.db_name})"
            f"{auth_str} | profile={profile}"
        )
        info(message)

    return settings
