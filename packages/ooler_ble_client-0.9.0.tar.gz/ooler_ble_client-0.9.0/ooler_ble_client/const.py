"""Constants for the ooler_ble_client library."""
from __future__ import annotations

import logging

from .models import OolerMode

_LOGGER = logging.getLogger(__package__)

MODE_INT_TO_MODE_STATE: list[OolerMode] = ["Silent", "Regular", "Boost"]

POWER_CHAR = "7a2623ff-bd92-4c13-be9f-7023aa4ecb85"
MODE_CHAR = "cafe2421-d04c-458f-b1c0-253c6c97e8e8"
SETTEMP_CHAR = "6aa46711-a29d-4f8a-88e2-044ca1fd03ff"
ACTUALTEMP_CHAR = "e8ebded3-9dca-45c2-a2d8-ceffb901474d"

WARMWAKE_CHAR = "7aa73db1-1c2d-4c8c-9195-36c0a4b6acb2"
RELATIVE_HUMIDITY_CHAR = "654b8162-7090-4084-8d94-4eb33e917e9c"
AMBIENT_TEMPERATURE_F_CHAR = "7c0ea228-2616-4765-a726-beb5f4a0fa71"
WATER_LEVEL_CHAR = "8db5b9db-dbf6-47e6-a9dd-0612a1349a5b"
SERIAL_NUMBER_CHAR = "136e24c6-c486-4a74-bb0a-d18b985970a6"
CLEAN_CHAR = "e9bf509a-b1c5-4243-9514-352ad2d851f6"
DEVICE_LOGS_CHAR = "e6a505a4-9f0b-4755-b234-13243240da23"
PUMP_LEVEL_CHAR = "5a914d86-9b5e-4a35-ad3d-3e5936d485b2"
POWER_RAIL_CHAR = "acab07ec-fc95-451d-88e5-4565a364a806"
LIFETIME_CHAR = "5d30781f-1d06-4790-bbb8-5e1d7da96383"
RUNTIME_CHAR = "1a5c6dae-34de-4265-9fa6-0a59f7f683ee"
UV_RUNTIME_CHAR = "0ab6ff00-8d1b-475e-bcfa-ed3467f1f890"
DISPLAY_TEMPERATURE_UNIT_CHAR = "2c988613-fe15-4067-85bc-8e59d5e0b1e3"