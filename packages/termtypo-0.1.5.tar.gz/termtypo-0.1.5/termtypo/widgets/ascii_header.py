from textual.widget import Widget
from textual.app import RenderResult
from rich.text import Text
from rich.align import Align

LOGO = """\
 ████████╗███████╗██████╗ ███╗   ███╗
    ██╔══╝██╔════╝██╔══██╗████╗ ████║
    ██║   █████╗  ██████╔╝██╔████╔██║
    ██║   ██╔══╝  ██╔══██╗██║╚██╔╝██║
    ██║   ███████╗██║  ██║██║ ╚═╝ ██║
    ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝
 ████████╗██╗   ██╗██████╗  ██████╗
    ██╔══╝ ██╗ ██╔╝██╔══██╗██╔═══██╗
    ██║    ╚████╔╝ ██████╔╝██║   ██║
    ██║     ╚██╔╝  ██╔═══╝ ██║   ██║
    ██║      ██║   ██║     ╚██████╔╝
    ╚═╝      ╚═╝   ╚═╝      ╚═════╝ """


class AsciiHeader(Widget):
    DEFAULT_CSS = """
    AsciiHeader {
        height: 14;
        content-align: center middle;
        padding-top: 1;
    }
    """

    def render(self) -> RenderResult:
        text = Text(LOGO, style="bold #7aa2f7", justify="center")
        return Align(text, align="center")
