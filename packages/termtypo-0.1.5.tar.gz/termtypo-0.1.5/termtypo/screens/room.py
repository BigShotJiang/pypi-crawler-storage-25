"""Private room — create or join."""
from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.screen import Screen
from textual.widgets import Static, Input
from rich.text import Text

from termtypo.services.auth_service import current_user
from termtypo.services.matchmaking_service import create_room, get_room, create_private_match


class RoomScreen(Screen):
    """Combined create/join room screen."""

    BINDINGS = [
        Binding("escape", "go_back", "Back", show=False),
    ]

    DEFAULT_CSS = """
    RoomScreen {
        background: #1a1b26;
        align: center middle;
    }
    #room-box {
        width: 52;
        height: auto;
        border: round #7aa2f7;
        padding: 2 4;
        background: #24283b;
    }
    #room-code-display {
        height: 3;
        content-align: center middle;
        color: #9ece6a;
    }
    #join-input {
        margin: 1 0;
        background: #1a1b26;
        border: round #565f89;
        color: #c0caf5;
    }
    #join-input:focus {
        border: round #7aa2f7;
    }
    """

    def __init__(self, mode: str = "words_50", **kwargs) -> None:
        super().__init__(**kwargs)
        self._mode = mode
        self._view = "menu"   # "menu" | "create_waiting" | "join"
        self._room_code: str | None = None
        self._watcher = None

    def compose(self) -> ComposeResult:
        with Static(id="room-box"):
            yield Static(id="room-content")
            yield Input(placeholder="enter room code…", id="join-input")
        yield Static("[esc] back", classes="hint")

    def on_mount(self) -> None:
        self.query_one(Input).display = False
        self._render_menu()

    # ── rendering ─────────────────────────────────────────────────────────────

    def _render_menu(self) -> None:
        t = Text()
        t.append("  PRIVATE ROOM\n\n", style="bold #7aa2f7")
        t.append(f"  mode   {self._mode}\n\n", style="#565f89")
        t.append("  [c] Create room\n", style="#9ece6a")
        t.append("  [j] Join room\n", style="#7dcfff")
        self.query_one("#room-content", Static).update(t)
        self.query_one(Input).display = False

    def _render_waiting(self, code: str) -> None:
        t = Text()
        t.append("  PRIVATE ROOM\n\n", style="bold #7aa2f7")
        t.append("  Share this code with your friend:\n\n", style="#565f89")
        t.append(f"      {code}\n\n", style="bold #9ece6a")
        t.append("  Waiting for them to join…\n", style="#565f89")
        t.append("  [esc] cancel\n", style="#565f89")
        self.query_one("#room-content", Static).update(t)

    def _render_join(self) -> None:
        t = Text()
        t.append("  JOIN ROOM\n\n", style="bold #7aa2f7")
        t.append("  Enter the 6-character room code:\n", style="#565f89")
        self.query_one("#room-content", Static).update(t)
        inp = self.query_one(Input)
        inp.display = True
        inp.focus()

    # ── key shortcuts (when not in Input) ────────────────────────────────────

    def on_key(self, event) -> None:
        if self._view == "menu":
            if event.key == "c":
                self._do_create()
            elif event.key == "j":
                self._view = "join"
                self._render_join()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        code = event.value.strip().upper()
        if len(code) == 6:
            self._do_join(code)
        else:
            self.app.notify("Code must be 6 characters.", severity="warning")

    # ── create ────────────────────────────────────────────────────────────────

    def _do_create(self) -> None:
        user = current_user()
        if not user:
            self.app.notify("Login required.", severity="warning")
            return
        code = create_room(user["id"], self._mode)
        if not code:
            self.app.notify("Failed to create room.", severity="error")
            return
        self._room_code = code
        self._view = "create_waiting"
        self._render_waiting(code)
        self._watch_room_for_guest(code, user["id"])

    def _watch_room_for_guest(self, code: str, host_id: str) -> None:
        """Poll DB every 2s for a guest joining the room."""
        self.set_interval(2.0, lambda: self._check_room(code, host_id))

    def _check_room(self, code: str, host_id: str) -> None:
        from termtypo.services.auth_service import get_authed_client
        client = get_authed_client()
        if not client:
            return
        try:
            # Look for a guest: a match_participant in a match linked to this room
            room_res = client.table("rooms").select("match_id, status").eq("code", code).maybe_single().execute()
            if not room_res or not room_res.data:
                return
            room = room_res.data
            if room.get("status") == "active" and room.get("match_id"):
                # Someone joined and match was created — but we need to find who
                match_id = room["match_id"]
                parts_res = client.table("match_participants").select("user_id").eq("match_id", match_id).execute()
                guest_id = next((p["user_id"] for p in parts_res.data if p["user_id"] != host_id), None)
                if guest_id:
                    self._enter_private_race(match_id, guest_id, host_id)
        except Exception:
            pass

    # ── join ──────────────────────────────────────────────────────────────────

    def _do_join(self, code: str) -> None:
        user = current_user()
        if not user:
            self.app.notify("Login required.", severity="warning")
            return
        room = get_room(code)
        if not room:
            self.app.notify("Room not found or already started.", severity="error")
            return
        host_id = room["host_id"]
        mode = room.get("mode", "words_50")
        match_id = create_private_match(host_id, user["id"], mode)
        if not match_id:
            self.app.notify("Failed to start match.", severity="error")
            return
        self._enter_private_race(match_id, user["id"], host_id, as_guest=True, mode=mode)

    # ── enter race ────────────────────────────────────────────────────────────

    def _enter_private_race(
        self, match_id: str, my_id: str, opponent_id: str,
        as_guest: bool = False, mode: str | None = None,
    ) -> None:
        from termtypo.screens.race import RaceScreen
        from termtypo.services.auth_service import get_authed_client
        client = get_authed_client()
        passage = ""
        mode = mode or self._mode
        if client:
            try:
                res = client.table("matches").select("passage").eq("id", match_id).maybe_single().execute()
                passage = (res.data or {}).get("passage", "") if res else ""
            except Exception:
                pass
        self.app.push_screen(
            RaceScreen(match_id, passage, my_id, mode, ranked=False)
        )

    def action_go_back(self) -> None:
        self.app.pop_screen()
