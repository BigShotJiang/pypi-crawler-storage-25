# Helper modules for Flutterator
from .project import get_project_name, validate_flutter_project
from .utils import to_pascal_case, to_pascal_case_preserve, map_field_type, pascal_case_to_snake_case, pascal_case_to_kebab_case, pascal_case_to_camel_case
from .validation import (
    validate_field_name,
    validate_field_type,
    validate_entity_name,
    parse_fields_string,
    parse_field_type,
)
from .feature import (
    create_feature_layers,
    create_presentation_feature_layers,
    find_domain_models,
    find_domain_models_with_class_names,
    find_enums,
    find_enums_with_info,
    get_domain_model_class_name,
    generate_value_objects_and_validators,
    generate_consolidated_value_objects,
    generate_value_validators,
    generate_extensions,
)
from .domain import create_domain_entity_layers
from .component import (
    create_component_layers,
    create_component_form_layers,
    create_component_list_layers,
    ensure_base_form_bloc,
    get_model_fields_from_domain,
    get_repository_info,
    generate_component_widget_from_template,
    generate_form_event_from_template,
    generate_form_state_from_template,
    generate_form_bloc_from_template,
)
from .navigation import (
    create_drawer_page,
    update_home_page_with_drawer,
    create_drawer_widget,
    update_router_for_drawer_item,
    create_bottom_nav_page,
    update_home_page_with_bottom_nav,
    create_bottom_nav_widget,
)
from .page import generate_page_file, update_router
from .config import (
    FlutteratorConfig,
    load_config,
    apply_cli_overrides,
    create_default_config,
    show_config,
    PROJECT_CONFIG_FILE,
    GLOBAL_CONFIG_FILE,
)

