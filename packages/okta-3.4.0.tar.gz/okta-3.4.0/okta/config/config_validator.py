# The Okta software accompanied by this notice is provided pursuant to the following terms:
# Copyright © 2025-Present, Okta, Inc.
# Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the
# License.
# You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0.
# Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and limitations under the License.
# coding: utf-8

import logging

from okta.constants import (
    FINDING_OKTA_DOMAIN, LOGGER_NAME, REPO_URL,
    MIN_DPOP_KEY_ROTATION_SECONDS, MAX_DPOP_KEY_ROTATION_SECONDS,
)
from okta.error_messages import (
    ERROR_MESSAGE_ORG_URL_MISSING,
    ERROR_MESSAGE_API_TOKEN_DEFAULT,
    ERROR_MESSAGE_API_TOKEN_MISSING,
    ERROR_MESSAGE_AUTH_MODE_INVALID,
    ERROR_MESSAGE_CLIENT_ID_MISSING,
    ERROR_MESSAGE_CLIENT_ID_DEFAULT,
    ERROR_MESSAGE_SCOPES_PK_MISSING,
    ERROR_MESSAGE_ORG_URL_NOT_HTTPS,
    ERROR_MESSAGE_ORG_URL_YOUROKTADOMAIN,
    ERROR_MESSAGE_ORG_URL_TYPO,
    ERROR_MESSAGE_ORG_URL_ADMIN,
    ERROR_MESSAGE_PROXY_MISSING_HOST,
    ERROR_MESSAGE_PROXY_MISSING_AUTH,
    ERROR_MESSAGE_PROXY_INVALID_PORT,
)

logger = logging.getLogger(LOGGER_NAME)


class ConfigValidator:
    """
    This class performs validation checks on the Okta Client configuration.
    """

    def __init__(self, config):
        self._config = config
        self.validate_config()

    """
    Configuration Validators
    """

    def validate_config(self):
        """
        This method validates the client configuration and validates
        the values provided. Throws a ValueError if anything is invalid.

        Raises:
            ValueError: A configuration provided needs to be corrected.
        """
        errors = []
        # Defensive: default to empty dict if sections are missing
        client = self._config.get("client", {})

        # check org url
        errors += self._validate_org_url(client.get("orgUrl", ""))
        # check proxy settings if provided
        if "proxy" in client:
            errors += self._validate_proxy_settings(client["proxy"])
        # check API details based on authorization mode
        if client.get("authorizationMode") in ("SSWS", "Bearer"):
            errors += self._validate_token(client.get("token", ""))
            # Warn if DPoP is enabled with a non-OAuth auth mode (it has no effect)
            if client.get("dpopEnabled", False):
                logger.warning(
                    "dpopEnabled is True but authorizationMode is '%s'. "
                    "DPoP only applies to 'PrivateKey' (OAuth) mode and will "
                    "be ignored. Set authorizationMode to 'PrivateKey' to use DPoP.",
                    client.get("authorizationMode"),
                )
        elif client.get("authorizationMode") == "PrivateKey":
            client_fields = [
                "clientId",
                "scopes",
                "privateKey",
                "oauthTokenRenewalOffset",
            ]
            client_fields_values = [client.get(field, "") for field in client_fields]
            errors += self._validate_client_fields(*client_fields_values)
            # Validate DPoP configuration if enabled
            errors += self._validate_dpop_config(client)
        else:  # Not a valid authorization mode
            errors += [
                (
                    f"{ERROR_MESSAGE_AUTH_MODE_INVALID}"
                    f"{client.get('authorizationMode', None)}"
                )
            ]

        if errors:  # raise exception and stop program if errors
            newline = "\n"
            raise ValueError(
                f"{newline}Errors:"
                f"{newline + newline.join(errors) + 2 * newline}"
                f"See {REPO_URL} for usage"
            )

    def _validate_client_fields(
        self, client_id, client_scopes, client_private_key, oauth_token_renewal_offset
    ):
        client_fields_errors = []

        # check client id
        client_id = client_id.strip().lower()
        # null or empty string
        if not client_id:
            client_fields_errors.append(ERROR_MESSAGE_CLIENT_ID_MISSING)
        # contains {clientId}
        if "{clientId}".lower() in client_id:
            client_fields_errors.append(ERROR_MESSAGE_CLIENT_ID_DEFAULT)

        # check that at least 1 scope is provided and private key is provided
        if not (client_scopes and client_private_key):
            client_fields_errors.append(ERROR_MESSAGE_SCOPES_PK_MISSING)

        # Validate oauthTokenRenewalOffset
        if not oauth_token_renewal_offset:
            client_fields_errors.append("oauthTokenRenewalOffset must be provided")
        if not isinstance(oauth_token_renewal_offset, int):
            client_fields_errors.append(
                "oauthTokenRenewalOffset must be a valid integer"
            )
        if (
            isinstance(oauth_token_renewal_offset, int)
            and oauth_token_renewal_offset < 0
        ):
            client_fields_errors.append(
                "oauthTokenRenewalOffset must be a non-negative integer"
            )

        return client_fields_errors

    def _validate_token(self, token: str):
        # remove whitespaces and lowercase token for comparisons
        token = token.strip().lower()

        token_errors = []

        # token is null or empty
        if not token:
            token_errors.append(ERROR_MESSAGE_API_TOKEN_MISSING)
        # token contains {apiToken}
        if "{apiToken}".lower() in token:
            token_errors.append(ERROR_MESSAGE_API_TOKEN_DEFAULT)

        return token_errors

    def _validate_org_url(self, url: str):
        # remove whitespaces and lowercase URL for comparisons
        url = url.strip().lower()

        url_errors = []

        # if empty or null string
        if not url:
            url_errors.append(ERROR_MESSAGE_ORG_URL_MISSING)
        # if url is not https (in non-testing env)
        # Defensive: get testing section with default
        testing = self._config.get("testing", {})
        if url and not (
            testing.get("testingDisableHttpsCheck", False)
            or url.startswith("https")
        ):
            url_errors.append(
                (
                    f"{ERROR_MESSAGE_ORG_URL_NOT_HTTPS} Current value: "
                    f"{url or None}. "
                    "You can copy your domain from the Okta Developer Console. "
                    "Follow these instructions to find it: "
                    f"{FINDING_OKTA_DOMAIN}"
                )
            )
        # url still contains default {yourOktaDomain}
        if "{yourOktaDomain}".lower() in url or "{{yourOktaDomain}}".lower() in url:
            url_errors.append(ERROR_MESSAGE_ORG_URL_YOUROKTADOMAIN)
        # url contains -admin string
        admin_strings = [
            "-admin.okta.com",
            "-admin.oktapreview.com",
            "-admin.okta-emea.com",
            "-admin.okta-gov.com",
            "-admin.okta.mil",
            "-admin.okta-miltest.com",
            "-admin.trex-govcloud.com",
        ]
        if any(string in url for string in admin_strings) or "-admin" in url:
            url_errors.append(
                (
                    f"{ERROR_MESSAGE_ORG_URL_ADMIN} "
                    f"Current value: {url}. You can copy your domain "
                    "from the Okta Developer Console. Follow these instructions "
                    f"to find it: {FINDING_OKTA_DOMAIN}"
                )
            )
        # url ends with .com.com
        if url.endswith(".com.com"):
            url_errors.append(
                (
                    f"{ERROR_MESSAGE_ORG_URL_TYPO} Current "
                    f"value: {url}. You can copy your domain from "
                    "the Okta Developer Console. Follow these instructions to find"
                    f" it: {FINDING_OKTA_DOMAIN}"
                )
            )
        # url contains multiple '://' segments
        if url.count("://") > 1:
            url_errors.append(
                (
                    f"{ERROR_MESSAGE_ORG_URL_TYPO} Current "
                    f"value: {url}. You can copy your domain from "
                    "the Okta Developer Console. Follow these instructions to find"
                    f" it: {FINDING_OKTA_DOMAIN}"
                )
            )

        return url_errors

    def _validate_proxy_settings(self, proxy):
        proxy_errors = []
        if "host" not in proxy:
            proxy_errors.append(ERROR_MESSAGE_PROXY_MISSING_HOST)
        if (
            "username" in proxy
            and "password" not in proxy
            or "username" not in proxy
            and "password" in proxy
        ):
            proxy_errors.append(ERROR_MESSAGE_PROXY_MISSING_AUTH)
        if "port" in proxy:
            try:
                port_number = int(proxy["port"])
                if not 1 <= port_number <= 65535:
                    raise ValueError
            except (TypeError, ValueError):
                proxy_errors.append(ERROR_MESSAGE_PROXY_INVALID_PORT)

        return proxy_errors

    def _validate_dpop_config(self, client):
        """
        Validate DPoP-specific configuration.

        Coerces string values from environment variables to their expected
        types (bool for ``dpopEnabled``, int for ``dpopKeyRotationInterval``)
        before validation.  The coerced values are written back into *client*
        so that downstream code receives the correct Python types.

        Note: This method is only called when authorizationMode is 'PrivateKey',
        so no need to re-check the auth mode here.

        Args:
            client (dict): Client configuration dict (mutated in-place for
                type coercion of string values from environment variables).

        Returns:
            list: List of error messages (empty if valid)
        """

        errors = []

        dpop_enabled = client.get('dpopEnabled', False)

        # Coerce string from env vars to bool (e.g. "true" → True)
        if isinstance(dpop_enabled, str):
            dpop_enabled = dpop_enabled.strip().lower() == 'true'
            client['dpopEnabled'] = dpop_enabled

        # Validate dpopEnabled is a boolean
        if not isinstance(dpop_enabled, bool):
            errors.append(
                "dpopEnabled must be a boolean (True/False), "
                f"but got {type(dpop_enabled).__name__}: {dpop_enabled!r}"
            )
            return errors  # Cannot validate further if type is wrong

        if not dpop_enabled:
            return errors  # DPoP not enabled, nothing to validate

        # Validate key rotation interval
        rotation_interval = client.get('dpopKeyRotationInterval', 86400)

        # Coerce string from env vars to int (e.g. "86400" → 86400)
        if isinstance(rotation_interval, str):
            try:
                rotation_interval = int(rotation_interval)
                client['dpopKeyRotationInterval'] = rotation_interval
            except ValueError:
                errors.append(
                    "dpopKeyRotationInterval must be a valid integer "
                    f"(seconds), but got non-numeric string: "
                    f"{rotation_interval!r}"
                )
                return errors

        if not isinstance(rotation_interval, int):
            errors.append(
                "dpopKeyRotationInterval must be an integer (seconds), "
                f"but got {type(rotation_interval).__name__}"
            )
        elif rotation_interval < MIN_DPOP_KEY_ROTATION_SECONDS:
            errors.append(
                "dpopKeyRotationInterval must be at least "
                f"{MIN_DPOP_KEY_ROTATION_SECONDS} seconds (1 hour), "
                f"but got {rotation_interval} seconds. "
                "Shorter intervals may cause performance issues."
            )
        elif rotation_interval > MAX_DPOP_KEY_ROTATION_SECONDS:
            max_days = MAX_DPOP_KEY_ROTATION_SECONDS // 86400
            given_days = rotation_interval // 86400
            errors.append(
                "dpopKeyRotationInterval must be at most "
                f"{MAX_DPOP_KEY_ROTATION_SECONDS} seconds "
                f"({max_days} days), but got {rotation_interval} "
                f"seconds ({given_days} days). "
                "Excessive rotation intervals defeat the security "
                "purpose of DPoP. "
                "Recommended: 24-48 hours for production use."
            )
        elif rotation_interval > 7 * 24 * 3600:  # Warning for > 7 days
            # This is a warning, not an error
            logger.warning(
                "dpopKeyRotationInterval is very long (%d seconds, "
                "%d days). Consider shorter intervals (24-48 hours) "
                "for better security.",
                rotation_interval, rotation_interval // 86400,
            )

        return errors
