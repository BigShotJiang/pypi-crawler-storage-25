from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from typing import Optional

from loguru import logger
from redis.asyncio import Redis

from turbo_agent_core.schema.events import BaseEvent
from turbo_agent_store.interface.monitor import BaseRuntimeMonitor

from .constants import GLOBAL_LIFECYCLE_STREAM_KEY, trace_lifecycle_stream_key


@dataclass
class MonitorConfig:
    """RuntimeMonitor 配置。"""

    global_lifecycle_stream_key: str = GLOBAL_LIFECYCLE_STREAM_KEY
    trace_lifecycle_stream_key_fn = staticmethod(trace_lifecycle_stream_key)


@dataclass
class _PendingWrite:
    stream: str
    event_json: str


class RedisRuntimeMonitor(BaseRuntimeMonitor):
    """基于 Redis Stream 的 Runtime 事件监控器。"""

    def __init__(self, redis_client: Redis, queue_maxsize: int = 5000, config: Optional[MonitorConfig] = None):
        self._redis = redis_client
        self._queue: asyncio.Queue[_PendingWrite] = asyncio.Queue(maxsize=queue_maxsize)
        self._writer_task: Optional[asyncio.Task[None]] = None
        self._config = config or MonitorConfig()

    def start(self) -> None:
        if self._writer_task is None or self._writer_task.done():
            self._writer_task = asyncio.create_task(self._writer_loop())

    async def close(self) -> None:
        if self._writer_task is None:
            return

        try:
            await asyncio.wait_for(self._queue.join(), timeout=5.0)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            logger.warning("RedisRuntimeMonitor close timeout, some events might be lost")

        self._writer_task.cancel()
        try:
            await self._writer_task
        except asyncio.CancelledError:
            pass

    async def _writer_loop(self) -> None:
        while True:
            item = await self._queue.get()
            try:
                msg_id = await self._redis.xadd(item.stream, {"event": item.event_json})
                logger.info(
                    "[RedisRuntimeMonitor] 成功写入事件到 Redis: stream={} msg_id={} event_json={}",
                    item.stream,
                    msg_id,
                    item.event_json,
                )
            except Exception as e:
                logger.warning("RuntimeMonitor 写入 Redis Stream 失败：stream={}, 错误={}", item.stream, e)
            finally:
                self._queue.task_done()

    def _enqueue(self, stream: str, event: BaseEvent) -> None:
        try:
            payload = json.dumps(event.model_dump(mode="json"), ensure_ascii=False)
            self._queue.put_nowait(_PendingWrite(stream=stream, event_json=payload))
            logger.info("[RedisRuntimeMonitor] Enqueued event: type={} trace_id={} stream={}", event.type, event.trace_id, stream)
        except asyncio.QueueFull:
            logger.warning("RuntimeMonitor 写入队列已满，丢弃事件：type={}, trace_id={}", event.type, event.trace_id)

    def write(self, event: BaseEvent) -> None:
        self.start()
        self._enqueue(self._config.trace_lifecycle_stream_key_fn(event.trace_id), event)
        if str(event.type).startswith("run.lifecycle") and not event.trace_path:
            self._enqueue(self._config.global_lifecycle_stream_key, event)