# coding=utf-8

from __future__ import annotations

GLOBAL_LIFECYCLE_STREAM_KEY = "ta.result.lifecycle"


def trace_lifecycle_stream_key(trace_id: str) -> str:
    return f"ta.result.lifecycle.{trace_id}"