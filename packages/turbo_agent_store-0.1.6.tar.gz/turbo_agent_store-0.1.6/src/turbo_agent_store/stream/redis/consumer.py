# coding=utf-8
from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Set
from uuid import uuid4

from loguru import logger
from redis.asyncio import Redis
from redis.exceptions import ResponseError

from turbo_agent_core.schema.events import BaseEvent
from turbo_agent_store.interface import StateStore
from turbo_agent_store.stream.execution import ExecutionArchiver

from .constants import GLOBAL_LIFECYCLE_STREAM_KEY, trace_lifecycle_stream_key


def _trace_lock_key(trace_id: str) -> str:
    return f"ta.store.lock.trace.{trace_id}"


_LOCK_RENEW_LUA = """
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('PEXPIRE', KEYS[1], ARGV[2])
else
    return 0
end
"""


_LOCK_RELEASE_LUA = """
if redis.call('GET', KEYS[1]) == ARGV[1] then
    return redis.call('DEL', KEYS[1])
else
    return 0
end
"""


def _parse_event(fields: Dict[Any, Any]) -> Optional[BaseEvent]:
    raw = fields.get("event")
    if raw is None:
        raw = fields.get(b"event")
    if raw is None:
        return None

    if isinstance(raw, (bytes, bytearray)):
        raw = raw.decode("utf-8", errors="ignore")

    try:
        data = json.loads(raw)
    except Exception as e:
        logger.warning("事件 JSON 解析失败：{}", e)
        return None

    try:
        return BaseEvent.model_validate(data)
    except Exception as e:
        logger.warning("事件 schema 校验失败：{}", e)
        return None


def _normalize_stream_id(value: Any) -> str:
    if isinstance(value, (bytes, bytearray)):
        return value.decode("utf-8", errors="ignore")
    if value is None:
        return ""
    return str(value)


async def _ensure_consumer_group(redis: Redis, stream: str, group: str) -> None:
    await _ensure_consumer_group_from(redis=redis, stream=stream, group=group, start_id="0")


async def _ensure_consumer_group_from(*, redis: Redis, stream: str, group: str, start_id: str) -> None:
    try:
        await redis.xgroup_create(name=stream, groupname=group, id=start_id, mkstream=True)
        logger.info("已创建消费者组：stream={}, group={}", stream, group)
    except ResponseError as e:
        if "BUSYGROUP" in str(e):
            return
        raise


@dataclass
class ConsumerConfig:
    group: str = "ta.store.archive"
    consumer: str = ""
    consumer_prefix: str = "consumer"
    consumer_instance_id: str = ""
    lock_owner: str = ""
    block_ms: int = 1000
    count: int = 100
    flush_interval_s: float = 2.0
    pending_check_interval_s: float = 30.0
    trace_lock_ttl_ms: int = 5 * 60 * 1000
    trace_lock_renew_s: float = 10.0


def _resolve_consumer_name(config: ConsumerConfig) -> str:
    if config.consumer:
        return config.consumer

    instance_id = config.consumer_instance_id or uuid4().hex[:8]
    prefix = config.consumer_prefix or "consumer"
    return f"{prefix}-{instance_id}"


class EventStreamConsumer:
    """主消费者：监听全局发现流，发现 trace_id 后拉起 DataStreamConsumer 子消费者。"""

    def __init__(self, redis: Redis, state_store: StateStore, config: Optional[ConsumerConfig] = None):
        self.redis = redis
        self.state_store = state_store
        self.config = config or ConsumerConfig()
        if not self.config.consumer:
            self.config.consumer = _resolve_consumer_name(self.config)

        self._running = False
        self._trace_tasks: Dict[str, asyncio.Task[None]] = {}
        self._known_traces: Set[str] = set()
        self._trace_locks: Dict[str, str] = {}
        self._trace_created_message_ids: Dict[str, str] = {}
        self._last_pending_check_mono: float = 0.0

    async def run(self) -> None:
        self._running = True
        stream = GLOBAL_LIFECYCLE_STREAM_KEY
        await _ensure_consumer_group(self.redis, stream, self.config.group)

        if hasattr(self.state_store, "connect"):
            await self.state_store.connect()

        logger.info(
            "EventStreamConsumer 启动：stream={}, group={}, consumer={}",
            stream,
            self.config.group,
            self.config.consumer,
        )

        await self._log_group_state(stream, stage="startup")

        logger.info("[EventStreamConsumer] 开始处理历史 Pending/可认领消息：stream={}", stream)
        await self._drain_pending(stream)
        logger.info("[EventStreamConsumer] 历史 Pending/可认领消息处理完成：stream={}", stream)

        while self._running:
            try:
                logger.debug(
                    "[EventStreamConsumer] 等待全局流事件：stream={}, group={}, consumer={}",
                    stream,
                    self.config.group,
                    self.config.consumer,
                )
                items = await self.redis.xreadgroup(
                    groupname=self.config.group,
                    consumername=self.config.consumer,
                    streams={stream: ">"},
                    count=self.config.count,
                    block=self.config.block_ms,
                )
                if not items:
                    if self._should_run_pending_check():
                        logger.debug("[EventStreamConsumer] 本轮未收到新事件，转入 Pending 检查")
                        await self._drain_pending(stream)
                    continue

                logger.info("[EventStreamConsumer] xreadgroup 收到 {} 个流的数据", len(items))

                for _stream_name, messages in items:
                    for message_id, fields in messages:
                        should_ack = True
                        event = _parse_event(fields)
                        if event is None:
                            logger.warning("[EventStreamConsumer] 无法解析事件: msg_id={}", message_id)
                            await self.redis.xack(stream, self.config.group, message_id)
                            continue

                        logger.info("[EventStreamConsumer] 处理事件: type={} trace_id={}", event.type, event.trace_id)

                        if event.type == "run.lifecycle.created":
                            lifecycle = event
                            try:
                                if getattr(lifecycle, "trace_path", None):
                                    await self.redis.xack(stream, self.config.group, message_id)
                                    continue

                                start_id = None
                                try:
                                    if isinstance(message_id, (bytes, bytearray)):
                                        start_id = message_id.decode("utf-8", errors="ignore")
                                    elif isinstance(message_id, str):
                                        start_id = message_id
                                except Exception:
                                    start_id = None

                                lock_value = await self._try_acquire_trace_lock(trace_id=lifecycle.trace_id)
                                if not lock_value:
                                    logger.info("trace 正在被其他实例处理，稍后重试：trace_id={}", lifecycle.trace_id)
                                    should_ack = False
                                    continue

                                await self._start_trace_consumer(
                                    trace_id=lifecycle.trace_id,
                                    initial_created=lifecycle,
                                    start_stream_id=start_id,
                                    lock_value=lock_value,
                                    global_created_message_id=(
                                        message_id.decode("utf-8", errors="ignore")
                                        if isinstance(message_id, (bytes, bytearray))
                                        else str(message_id)
                                    ),
                                )
                                should_ack = False
                            except Exception as e:
                                logger.error("处理 created 事件失败，保留 Pending：trace_id={}, 错误={}", lifecycle.trace_id, e)
                                should_ack = False
                                continue

                        if should_ack:
                            await self.redis.xack(stream, self.config.group, message_id)
            except Exception as e:
                logger.error("EventStreamConsumer 循环异常: {}", e)
                await asyncio.sleep(1)

    def _should_run_pending_check(self) -> bool:
        interval = max(1.0, float(getattr(self.config, "pending_check_interval_s", 30.0)))
        now = time.monotonic()
        if (now - self._last_pending_check_mono) < interval:
            return False
        self._last_pending_check_mono = now
        return True

    async def _log_group_state(self, stream: str, *, stage: str) -> None:
        try:
            groups = await self.redis.xinfo_groups(stream)
            logger.info(
                "[EventStreamConsumer] 消费组状态 stage={} stream={} groups={}",
                stage,
                stream,
                groups,
            )
        except Exception as e:
            logger.warning(
                "[EventStreamConsumer] 读取消费组状态失败 stage={} stream={} error={}",
                stage,
                stream,
                e,
            )

    async def stop(self) -> None:
        self._running = False
        for task in list(self._trace_tasks.values()):
            task.cancel()
        await asyncio.gather(*self._trace_tasks.values(), return_exceptions=True)
        self._trace_tasks.clear()
        for trace_id, lock_value in list(self._trace_locks.items()):
            try:
                await self._release_trace_lock(trace_id=trace_id, lock_value=lock_value)
            except Exception:
                pass
        self._trace_locks.clear()
        if hasattr(self.state_store, "disconnect"):
            await self.state_store.disconnect()

    async def _start_trace_consumer(
        self,
        *,
        trace_id: str,
        initial_created: BaseEvent,
        start_stream_id: Optional[str],
        lock_value: str,
        global_created_message_id: str,
    ) -> None:
        if trace_id in self._known_traces:
            return
        self._known_traces.add(trace_id)

        self._trace_locks[trace_id] = lock_value
        self._trace_created_message_ids[trace_id] = global_created_message_id

        consumer = DataStreamConsumer(
            redis=self.redis,
            trace_id=trace_id,
            state_store=self.state_store,
            initial_created=initial_created,
            start_stream_id=start_stream_id,
            lock_value=lock_value,
            config=self.config,
            parent=self,
        )
        task = asyncio.create_task(consumer.run(), name=f"data-consumer-{trace_id}")

        def _cleanup(_t: asyncio.Task[None]) -> None:
            async def _finalize() -> None:
                final_status = "completed"
                try:
                    if _t.cancelled():
                        final_status = "suspended"
                        logger.warning("Trace {} consumer task cancelled (suspended).", trace_id)
                    elif _t.exception():
                        final_status = "failed"
                        logger.error("Trace {} consumer task failed: {}", trace_id, _t.exception())

                    if final_status == "completed":
                        created_mid = self._trace_created_message_ids.get(trace_id)
                        if created_mid:
                            await self.redis.xack(GLOBAL_LIFECYCLE_STREAM_KEY, self.config.group, created_mid)
                except Exception as e:
                    logger.error("Error during trace cleanup: {}", e)
                finally:
                    await self._update_trace_lock_status(trace_id=trace_id, status=final_status)

                    self._trace_created_message_ids.pop(trace_id, None)
                    self._trace_locks.pop(trace_id, None)
                    if self._trace_tasks.get(trace_id) == _t:
                        self._trace_tasks.pop(trace_id, None)

                    if final_status == "suspended":
                        self._known_traces.discard(trace_id)

            asyncio.create_task(_finalize())

        task.add_done_callback(_cleanup)
        self._trace_tasks[trace_id] = task
        logger.info("已拉起 DataStreamConsumer：trace_id={}", trace_id)

    async def _try_acquire_trace_lock(self, *, trace_id: str) -> str:
        lock_key = _trace_lock_key(trace_id)

        existing_lock = await self.redis.get(lock_key)
        if existing_lock:
            try:
                lock_data = json.loads(existing_lock)
                lock_status = lock_data.get("status", "processing")

                if lock_status == "suspended":
                    logger.info("[锁状态] Trace {} 状态为 suspended，允许重新获取锁", trace_id)
                    await self.redis.delete(lock_key)
                else:
                    logger.debug("[锁状态] Trace {} 状态为 {}，拒绝获取锁", trace_id, lock_status)
                    return ""
            except (json.JSONDecodeError, Exception) as e:
                logger.warning("[锁状态] 锁格式错误，删除重试: {}", e)
                await self.redis.delete(lock_key)

        lock_data = {
            "consumer": self.config.consumer,
            "owner": self.config.lock_owner or self.config.consumer,
            "timestamp": int(time.time() * 1000),
            "status": "processing",
        }
        lock_value = json.dumps(lock_data)
        ttl_ms = int(getattr(self.config, "trace_lock_ttl_ms", 5 * 60 * 1000))

        ok = await self.redis.set(lock_key, lock_value, nx=True, px=ttl_ms)
        return lock_value if ok else ""

    async def _update_trace_lock_status(self, *, trace_id: str, status: str) -> None:
        lock_key = _trace_lock_key(trace_id)
        existing_lock = await self.redis.get(lock_key)
        if existing_lock:
            try:
                lock_data = json.loads(existing_lock)
                lock_data["status"] = status
                lock_data["updated_at"] = int(time.time() * 1000)
                if status in ("completed", "suspended"):
                    ttl_ms = 24 * 60 * 60 * 1000
                else:
                    ttl_ms = await self.redis.pttl(lock_key)
                    if ttl_ms <= 0:
                        ttl_ms = 5 * 60 * 1000
                await self.redis.set(lock_key, json.dumps(lock_data), px=ttl_ms)
                logger.info("[锁状态] 更新 Trace {} 锁状态为: {}, TTL: {}ms", trace_id, status, ttl_ms)
            except Exception as e:
                logger.warning("[锁状态] 更新锁状态失败: {}", e)

    async def _release_trace_lock(self, *, trace_id: str, lock_value: str) -> None:
        lock_key = _trace_lock_key(trace_id)
        try:
            await self.redis.eval(_LOCK_RELEASE_LUA, 1, lock_key, lock_value)
        finally:
            if self._trace_locks.get(trace_id) == lock_value:
                self._trace_locks.pop(trace_id, None)

    async def _drain_pending(self, stream: str) -> None:
        try:
            logger.debug(
                "[EventStreamConsumer] 检查当前消费者 Pending：stream={}, group={}, consumer={}",
                stream,
                self.config.group,
                self.config.consumer,
            )
            items = await self.redis.xreadgroup(
                groupname=self.config.group,
                consumername=self.config.consumer,
                streams={stream: "0"},
                count=self.config.count,
                block=1,
            )
            pending_count = sum(len(messages) for _stream_name, messages in (items or []))
            if pending_count:
                logger.info(
                    "[EventStreamConsumer] 当前消费者 Pending 检查完成：stream={} pending_count={}",
                    stream,
                    pending_count,
                )
            for _stream_name, messages in items or []:
                for message_id, fields in messages:
                    await self._process_pending_msg(stream, message_id, fields)
        except Exception as e:
            logger.warning("Drain pending (self) failed: {}", e)

        start_id = "0-0"
        while True:
            try:
                normalized_start_id = _normalize_stream_id(start_id) or "0-0"
                res = await self.redis.xautoclaim(
                    name=stream,
                    groupname=self.config.group,
                    consumername=self.config.consumer,
                    min_idle_time=60000,
                    start_id=normalized_start_id,
                    count=self.config.count,
                )
                if not isinstance(res, (list, tuple)) or len(res) < 2:
                    break

                next_start_id = _normalize_stream_id(res[0]) or "0-0"
                raw_messages = res[1] or []

                if raw_messages:
                    logger.info(
                        "[EventStreamConsumer] XAUTOCLAIM 认领到 {} 条消息：stream={}, start_id={}",
                        len(raw_messages),
                        stream,
                        normalized_start_id,
                    )

                for mid, fields in raw_messages:
                    await self._process_pending_msg(stream, mid, fields)

                if not raw_messages and (next_start_id == "0-0" or next_start_id == normalized_start_id):
                    break
                start_id = next_start_id
            except Exception as e:
                logger.warning("Drain pending (autoclaim) failed: {}", e)
                break

    async def _process_pending_msg(self, stream: str, message_id: Any, fields: Dict[Any, Any]) -> None:
        event = _parse_event(fields)
        if event is None:
            await self.redis.xack(stream, self.config.group, message_id)
            return

        logger.info(
            "[EventStreamConsumer] 处理 Pending 消息：msg_id={} type={} trace_id={}",
            message_id,
            event.type,
            event.trace_id,
        )

        if event.type != "run.lifecycle.created":
            await self.redis.xack(stream, self.config.group, message_id)
            return

        lifecycle = event
        if getattr(lifecycle, "trace_path", None):
            await self.redis.xack(stream, self.config.group, message_id)
            return

        if lifecycle.trace_id in self._trace_tasks and not self._trace_tasks[lifecycle.trace_id].done():
            logger.info("[EventStreamConsumer] Trace {} 正在处理中 (local)，视为重复消息并 ACK: {}", lifecycle.trace_id, message_id)
            await self.redis.xack(stream, self.config.group, message_id)
            return

        lock_value = await self._try_acquire_trace_lock(trace_id=lifecycle.trace_id)
        if not lock_value:
            logger.debug("[EventStreamConsumer] 无法获取锁，ACK 消息: trace_id={}", lifecycle.trace_id)
            await self.redis.xack(stream, self.config.group, message_id)
            return

        start_id = None
        try:
            if isinstance(message_id, (bytes, bytearray)):
                start_id = message_id.decode("utf-8", errors="ignore")
            elif isinstance(message_id, str):
                start_id = message_id
        except Exception:
            start_id = None

        await self._start_trace_consumer(
            trace_id=lifecycle.trace_id,
            initial_created=lifecycle,
            start_stream_id=start_id,
            lock_value=lock_value,
            global_created_message_id=(
                message_id.decode("utf-8", errors="ignore")
                if isinstance(message_id, (bytes, bytearray))
                else str(message_id)
            ),
        )


class DataStreamConsumer:
    """子消费者：消费单 Trace 的 Redis 事件流，并与归档器协调 ACK。"""

    def __init__(
        self,
        redis: Redis,
        trace_id: str,
        state_store: StateStore,
        initial_created: BaseEvent,
        start_stream_id: Optional[str],
        lock_value: str = "",
        config: Optional[ConsumerConfig] = None,
        parent: Optional[EventStreamConsumer] = None,
    ):
        self.redis = redis
        self.trace_id = trace_id
        self.state_store = state_store
        self.config = config or ConsumerConfig()
        self.parent = parent
        if not self.config.consumer:
            self.config.consumer = _resolve_consumer_name(self.config)

        self._running = False
        self._start_stream_id = start_stream_id
        self._initial_created = initial_created
        self._lock_key = _trace_lock_key(trace_id)
        self._lock_value = lock_value
        self._lock_renew_task: Optional[asyncio.Task[None]] = None

        self.archiver = ExecutionArchiver(
            trace_id=trace_id,
            state_store=state_store,
            flush_interval_s=self.config.flush_interval_s,
        )
        self.aggregator = self.archiver.aggregator

        self._stream_name: Optional[str] = None

    async def run(self) -> None:
        self._running = True
        stream = trace_lifecycle_stream_key(self.trace_id)
        self._stream_name = stream

        if self.redis is not None and self._lock_value:
            self._lock_renew_task = asyncio.create_task(self._renew_lock_loop(), name=f"trace-lock-renew-{self.trace_id}")

        start_id = "0"
        if self._start_stream_id:
            try:
                ms = str(self._start_stream_id).split("-", 1)[0]
                start_id = f"{ms}-0"
            except Exception:
                start_id = "0"

        await _ensure_consumer_group_from(redis=self.redis, stream=stream, group=self.config.group, start_id=start_id)

        try:
            await self.handle_event(self._initial_created)
        except Exception as e:
            logger.error("initial_created 处理失败：trace_id={}, 错误={}", self.trace_id, e)

        await self._drain_pending(stream)

        try:
            while self._running:
                try:
                    items = await self.redis.xreadgroup(
                        groupname=self.config.group,
                        consumername=self.config.consumer,
                        streams={stream: ">"},
                        count=self.config.count,
                        block=self.config.block_ms,
                    )
                    if not items:
                        continue

                    for _stream_name, messages in items:
                        for message_id, fields in messages:
                            logger.info("DataStreamConsumer 收到事件: trace_id={}, message_id={}", self.trace_id, fields)
                            trace_completed = await self._process_message(stream, message_id, fields, check_completion=True)
                            if trace_completed:
                                self._running = False
                                break
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    logger.error("Trace loop error: {}", e)
                    if self.parent is not None:
                        try:
                            await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="failed")
                        except Exception:
                            pass
                    await asyncio.sleep(1)
        finally:
            logger.info("DataStreamConsumer flushing on exit: trace_id={}", self.trace_id)
            await self.archiver.force_flush()

            if self._lock_renew_task:
                self._lock_renew_task.cancel()
                await asyncio.gather(self._lock_renew_task, return_exceptions=True)

    async def _process_message(self, stream: str, message_id: Any, fields: Dict[str, Any], *, check_completion: bool = False) -> bool:
        event = _parse_event(fields)
        if event is None:
            await self.redis.xack(stream, self.config.group, message_id)
            return False

        try:
            logger.info("Processing event: trace_id={}, type={}, event={}", self.trace_id, event.type, event)
            await self.handle_event(event)
        except Exception as e:
            logger.error("事件 handle 失败：trace_id={}, type={}, 错误={}", self.trace_id, event.type, e)

        await self._ack_message(message_id)

        if check_completion:
            root_snapshot = self.archiver.aggregator.snapshot_root()
            if root_snapshot and root_snapshot.is_closed:
                logger.info("Trace Completed: trace_id={}", self.trace_id)

                final_status = getattr(root_snapshot, "status", "completed")
                if self.parent is not None:
                    if str(final_status) == "suspended":
                        await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="suspended")
                    elif str(final_status) in ["failed", "error"]:
                        await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="failed")
                    else:
                        await self.parent._update_trace_lock_status(trace_id=self.trace_id, status="completed")

                return True
        return False

    async def _drain_pending(self, stream: str) -> None:
        try:
            items = await self.redis.xreadgroup(
                groupname=self.config.group,
                consumername=self.config.consumer,
                streams={stream: "0"},
                count=self.config.count,
                block=1,
            )
        except Exception:
            return

        for _stream_name, messages in items or []:
            for message_id, fields in messages:
                await self._process_message(stream, message_id, fields, check_completion=False)

    async def handle_event(self, event: BaseEvent) -> None:
        await self.archiver.on_event(event)
        for node in self.aggregator.iter_nodes_post_order():
            logger.debug(
                "事件处理结束 handled: trace_id={}, type={} node_id={} snapshot={}",
                self.trace_id,
                event.type,
                node.trace_id,
                node.snapshot(),
            )

    async def _ack_message(self, message_id: Any) -> None:
        if self.redis is not None and self._stream_name:
            await self.redis.xack(self._stream_name, self.config.group, message_id)

    async def flush_now(self) -> None:
        await self.archiver.force_flush()

    async def _renew_lock_loop(self) -> None:
        interval = float(getattr(self.config, "trace_lock_renew_s", 10.0))
        ttl_ms = str(int(getattr(self.config, "trace_lock_ttl_ms", 5 * 60 * 1000)))
        while self._running:
            try:
                await self.redis.eval(_LOCK_RENEW_LUA, 1, self._lock_key, self._lock_value, ttl_ms)
            except Exception:
                pass
            await asyncio.sleep(interval)