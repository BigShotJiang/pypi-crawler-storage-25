# coding=utf-8
from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional

from loguru import logger

from turbo_agent_core.schema.events import BaseEvent
from turbo_agent_core.schema.enums import ConversationStatus, MessageStatus
from turbo_agent_core.schema.states import Action, Message, ReActRound, ToolCallRecord
from turbo_agent_core.utils.aggregators import ActionAggregate, EventTreeAggregator, ReActFlow, TraceAggregationResult, TraceEventAggregator
from turbo_agent_store.interface import StateStore


def _extract_root_input_data(aggregator: EventTreeAggregator) -> Dict[str, Any]:
	root_snapshot = aggregator.snapshot_root()
	if root_snapshot and isinstance(root_snapshot.input_data, dict):
		return root_snapshot.input_data
	return {}


def _resolve_conversation_id(root_input_data: Dict[str, Any]) -> Optional[str]:
	conversation_val = root_input_data.get("conversation")
	if isinstance(conversation_val, dict):
		return conversation_val.get("id")
	return root_input_data.get("conversation_id")


def _resolve_owner_id(message: Message, root_input_data: Dict[str, Any]) -> Optional[str]:
	return message.root_user_id or root_input_data.get("user_id") or (root_input_data.get("user") or {}).get("id")


def _resolve_tool_root_user_id(record: ToolCallRecord, root_input_data: Dict[str, Any]) -> Optional[str]:
	return record.root_user_id or root_input_data.get("user_id") or (root_input_data.get("user") or {}).get("id")


def _normalize_timestamp(ts: Optional[float]) -> Optional[float]:
	if ts is None:
		return None
	value = float(ts)
	if value > 1e11:
		return value / 1000.0
	return value


@dataclass(slots=True)
class MessageArchiveContext:
	conversation_id: Optional[str]
	owner_id: Optional[str]
	leaf_message_id: Optional[str]
	strip_nested: bool = True


@dataclass(slots=True)
class ToolCallArchiveContext:
	root_user_id: Optional[str]


@dataclass(slots=True)
class ActionArchiveContext:
	message_id: str
	react_round_id: Optional[str]
	root_user_id: Optional[str]
	strip_records: bool = True


@dataclass(slots=True)
class ReActRoundArchiveContext:
	message_id: str
	root_user_id: Optional[str]
	strip_actions: bool = True


class BaseExecutionWriter(ABC):
	"""单节点 writer 抽象，负责单类状态的写入节流与落库。"""

	def __init__(self, min_flush_interval_s: float = 2.0):
		self.min_flush_interval_s = max(0.0, float(min_flush_interval_s))

	def should_flush(self, node: TraceEventAggregator, now: float) -> bool:
		snapshot = node.snapshot()
		if not snapshot:
			return False
		stored_at = _normalize_timestamp(node.stored_at)
		finished_at = _normalize_timestamp(snapshot.finished_at)
		if not node.is_stored:
			if stored_at is None:
				return True
			if snapshot.is_closed:
				return True
			return (now - stored_at) >= self.min_flush_interval_s
		if snapshot.is_closed and finished_at and (stored_at or 0) < finished_at:
			return True
		return False

	@abstractmethod
	async def flush(self, node: TraceEventAggregator, state_obj: Any, context: Any) -> bool:
		"""写入单个节点。"""


class MessageStateWriter(BaseExecutionWriter):
	def __init__(self, state_store: StateStore, min_flush_interval_s: float = 2.0):
		super().__init__(min_flush_interval_s=min_flush_interval_s)
		self.state_store = state_store

	async def flush(self, node: TraceEventAggregator, state_obj: Message, context: MessageArchiveContext) -> bool:
		if not context.conversation_id:
			logger.debug("[ExecutionArchiver] 缺少 conversation_id，跳过消息写入: trace_id={}", node.trace_id)
			return False
		message_to_save = state_obj.model_copy(deep=True)
		if context.strip_nested:
			message_to_save.reactRounds = []
			message_to_save.actions = []
		await self.state_store.save_message(
			message_to_save,
			conversation_id=context.conversation_id,
			owner_id=context.owner_id,
		)
		return True


class ReActRoundStateWriter(BaseExecutionWriter):
	def __init__(self, state_store: StateStore, min_flush_interval_s: float = 2.0):
		super().__init__(min_flush_interval_s=min_flush_interval_s)
		self.state_store = state_store

	def should_flush(self, node, now: float) -> bool:
		stored_at = _normalize_timestamp(node.stored_at)
		updated_at = _normalize_timestamp(node.updated_at)
		if not node.is_stored:
			if stored_at is None:
				return True
			if node.is_closed:
				return True
			return (now - stored_at) >= self.min_flush_interval_s
		if node.is_closed and updated_at and (stored_at or 0) < updated_at:
			return True
		return False

	async def flush(self, node: ReActFlow, state_obj: ReActRound, context: ReActRoundArchiveContext) -> bool:
		react_round_to_save = state_obj.model_copy(deep=True)
		if context.strip_actions:
			react_round_to_save.actions = []
		await self.state_store.save_react_round(
			react_round_to_save,
			message_id=context.message_id,
			owner_id=context.root_user_id,
		)
		return True


class ActionStateWriter(BaseExecutionWriter):
	def __init__(self, state_store: StateStore, min_flush_interval_s: float = 2.0):
		super().__init__(min_flush_interval_s=min_flush_interval_s)
		self.state_store = state_store

	def should_flush(self, node, now: float) -> bool:
		stored_at = _normalize_timestamp(node.stored_at)
		finished_at = _normalize_timestamp(node.finished_at)
		if not node.is_stored:
			if stored_at is None:
				return True
			if node.is_closed:
				return True
			return (now - stored_at) >= self.min_flush_interval_s
		if node.is_closed and finished_at and (stored_at or 0) < finished_at:
			return True
		return False

	async def flush(self, node: ActionAggregate, state_obj: Action, context: ActionArchiveContext) -> bool:
		if not state_obj.root_user_id and context.root_user_id:
			state_obj.root_user_id = context.root_user_id
		action_to_save = state_obj.model_copy(deep=True)
		if context.strip_records:
			action_to_save.records = []
		await self.state_store.save_action(
			action_to_save,
			message_id=context.message_id,
			react_round_id=context.react_round_id,
			owner_id=context.root_user_id,
		)
		return True


class ToolCallRecordStateWriter(BaseExecutionWriter):
	def __init__(self, state_store: StateStore, min_flush_interval_s: float = 2.0):
		super().__init__(min_flush_interval_s=min_flush_interval_s)
		self.state_store = state_store

	async def flush(self, node: Any, state_obj: ToolCallRecord, context: ToolCallArchiveContext) -> bool:
		if not state_obj.root_user_id and context.root_user_id:
			state_obj.root_user_id = context.root_user_id
		await self.state_store.save_tool_call_record(state_obj, root_user_id=context.root_user_id)
		return True


class ExecutionArchiver:
	"""中立归档器：接收事件、聚合状态、决定何时落库。"""

	def __init__(
		self,
		trace_id: str,
		state_store: StateStore,
		*,
		flush_interval_s: float = 2.0,
		message_writer: Optional[MessageStateWriter] = None,
		react_round_writer: Optional[ReActRoundStateWriter] = None,
		action_writer: Optional[ActionStateWriter] = None,
		tool_call_writer: Optional[ToolCallRecordStateWriter] = None,
	):
		self.trace_id = trace_id
		self.state_store = state_store
		self.flush_interval_s = max(0.0, float(flush_interval_s))
		self.aggregator = EventTreeAggregator(root_trace_id=trace_id)
		self.message_writer = message_writer or MessageStateWriter(state_store, min_flush_interval_s=self.flush_interval_s)
		self.react_round_writer = react_round_writer or ReActRoundStateWriter(state_store, min_flush_interval_s=self.flush_interval_s)
		self.action_writer = action_writer or ActionStateWriter(state_store, min_flush_interval_s=self.flush_interval_s)
		self.tool_call_writer = tool_call_writer or ToolCallRecordStateWriter(state_store, min_flush_interval_s=self.flush_interval_s)
		self._last_flush_mono: float = time.monotonic()
		self._dirty = False

	async def on_event(self, event: BaseEvent) -> None:
		self.aggregator.on_event(event)
		self._mark_unstored(event)
		self._dirty = True
		await self.flush_if_needed()

	async def flush_if_needed(self) -> bool:
		if not self._dirty:
			return False

		now = time.monotonic()
		if (now - self._last_flush_mono) < self.flush_interval_s:
			return False

		await self.flush()
		return True

	async def force_flush(self) -> bool:
		had_dirty = self._dirty
		if self._dirty:
			await self.flush()
		await self._touch_conversation_updated_at()
		return had_dirty

	async def flush(self) -> bool:
		if not self._dirty:
			return False

		root_input_data = _extract_root_input_data(self.aggregator)
		now = time.time()

		for node in self.aggregator.iter_nodes_post_order():
			try:
				state_obj = node.to_state(include_nested=False)
			except Exception as exc:
				logger.warning("[ExecutionArchiver] to_state 失败，已跳过: trace_id={}, error={}", node.trace_id, exc)
				continue

			if not state_obj:
				continue

			if isinstance(state_obj, Message):
				if self.message_writer.should_flush(node, now):
					written = await self._archive_message_node(node=node, message=state_obj, root_input_data=root_input_data)
					if written:
						node.set_stored(True, now)
			elif isinstance(state_obj, ToolCallRecord):
				if self.tool_call_writer.should_flush(node, now):
					written = await self._archive_tool_node(node=node, record=state_obj, root_input_data=root_input_data)
					if written:
						node.set_stored(True, now)

		self._dirty = False
		self._last_flush_mono = time.monotonic()
		return True

	def snapshot_root(self) -> Optional[TraceAggregationResult]:
		return self.aggregator.snapshot_root()

	async def _touch_conversation_updated_at(self) -> None:
		if not hasattr(self.state_store, "touch_conversation"):
			return
		root_input_data = _extract_root_input_data(self.aggregator)
		conversation_id = _resolve_conversation_id(root_input_data)
		if not conversation_id:
			return
		await self.state_store.touch_conversation(conversation_id)

	async def _update_conversation_status(self, status: ConversationStatus) -> None:
		root_input_data = _extract_root_input_data(self.aggregator)
		conversation_id = _resolve_conversation_id(root_input_data)
		if not conversation_id:
			return
		await self.state_store.update_conversation_status(conversation_id, status)

	def _mark_unstored(self, event: BaseEvent) -> None:
		trace_path = getattr(event, "trace_path", None) or []
		for trace_id in [*trace_path, event.trace_id]:
			node = self.aggregator.nodes.get(trace_id)
			if node is not None:
				node.set_stored(False, float(event.timestamp))
				if event.react_id is not None:
					for run in node.runs.values():
						flow = run.react_flows.get(event.react_id)
						if flow is not None:
							flow.set_stored(False, float(event.timestamp))
				if event.action_id:
					self._mark_action_unstored(node=node, action_id=event.action_id, ts=float(event.timestamp))

	async def _archive_message_node(
		self,
		*,
		node: TraceEventAggregator,
		message: Message,
		root_input_data: Dict[str, Any],
	) -> bool:
		conversation_id = _resolve_conversation_id(root_input_data)
		owner_id = _resolve_owner_id(message, root_input_data)
		leaf_message_id = root_input_data.get("leaf_message_id")

		if conversation_id:
			await self._maintain_message_tree(
				conversation_id=conversation_id,
				message=message,
				leaf_message_id=leaf_message_id,
			)

		written = await self.message_writer.flush(
			node,
			message,
			MessageArchiveContext(
				conversation_id=conversation_id,
				owner_id=owner_id,
				leaf_message_id=leaf_message_id,
				strip_nested=True,
			),
		)
		if not written:
			return False
		await self._archive_components_from_trace(node=node, message=message, root_input_data=root_input_data)
		if message.status == MessageStatus.finished:
			await self._update_conversation_status(ConversationStatus.finished)
		return True

	async def _archive_tool_node(self, *, node: TraceEventAggregator, record: ToolCallRecord, root_input_data: Dict[str, Any]) -> bool:
		return await self.tool_call_writer.flush(
			node,
			record,
			ToolCallArchiveContext(
				root_user_id=_resolve_tool_root_user_id(record, root_input_data),
			),
		)

	async def _archive_components_from_trace(
		self,
		*,
		node: TraceEventAggregator,
		message: Message,
		root_input_data: Dict[str, Any],
	) -> None:
		now = time.time()
		for run_id in node.run_order:
			run = node.runs.get(run_id)
			if run is None:
				continue
			for react_id, flow in run.react_flows.items():
				await self._archive_react_flow(
					flow=flow,
					message_id=message.id,
					root_input_data=root_input_data,
					now=now,
				)
				for aggregate in flow.actions.values():
					await self._archive_action_aggregate(
						aggregate=aggregate,
						message_id=message.id,
						react_round_id=(flow.react_id or f"react_{message.id}_default") if react_id is not None else None,
						root_input_data=root_input_data,
						now=now,
					)

	async def _archive_react_flow(
		self,
		*,
		flow: ReActFlow,
		message_id: str,
		root_input_data: Dict[str, Any],
		now: float,
	) -> None:
		if flow.react_id is None:
			return
		if not self.react_round_writer.should_flush(flow, now):
			return
		react_round = flow.to_state(message_id, include_actions=False, include_action_records=False)
		root_user_id = react_round.root_user_id or root_input_data.get("user_id") or (root_input_data.get("user") or {}).get("id")
		written = await self.react_round_writer.flush(
			flow,
			react_round,
			ReActRoundArchiveContext(
				message_id=message_id,
				root_user_id=root_user_id,
				strip_actions=True,
			),
		)
		if written:
			flow.set_stored(True, now)

	async def _archive_action_aggregate(
		self,
		*,
		aggregate: ActionAggregate,
		message_id: str,
		react_round_id: Optional[str],
		root_input_data: Dict[str, Any],
		now: float,
	) -> None:
		if not self.action_writer.should_flush(aggregate, now):
			return

		action = aggregate.to_state(include_records=False)
		root_user_id = action.root_user_id or root_input_data.get("user_id") or (root_input_data.get("user") or {}).get("id")
		written = await self.action_writer.flush(
			aggregate,
			action,
			ActionArchiveContext(
				message_id=message_id,
				react_round_id=react_round_id,
				root_user_id=root_user_id,
				strip_records=True,
			),
		)
		if not written:
			return
		record = aggregate.to_tool_call_record_state()
		await self.tool_call_writer.flush(
			aggregate,
			record,
			ToolCallArchiveContext(root_user_id=_resolve_tool_root_user_id(record, root_input_data)),
		)
		aggregate.set_stored(True, now)

	def _find_action_aggregate(self, *, node: TraceEventAggregator, action_id: str):
		for run in node.runs.values():
			for flow in run.react_flows.values():
				aggregate = flow.actions.get(action_id)
				if aggregate is not None:
					return aggregate
		return None

	def _mark_action_unstored(self, *, node: TraceEventAggregator, action_id: str, ts: float) -> None:
		aggregate = self._find_action_aggregate(node=node, action_id=action_id)
		if aggregate is not None:
			aggregate.set_stored(False, ts)
			for run in node.runs.values():
				for flow in run.react_flows.values():
					if flow.actions.get(action_id) is aggregate:
						flow.set_stored(False, ts)
						return

	async def _maintain_message_tree(
		self,
		*,
		conversation_id: str,
		message: Message,
		leaf_message_id: Optional[str],
	) -> None:
		conversation = await self.state_store.get_conversation(conversation_id)
		if not conversation:
			return

		had_messages_before = bool(conversation.messages)
		existing_message = next((item for item in conversation.messages if item.id == message.id), None)
		if existing_message is not None:
			return

		parent_id = leaf_message_id
		if not parent_id and conversation.messages:
			parent_id = conversation.messages[-1].id

		try:
			conversation.add_child(message, parent_id=parent_id)
		except Exception as exc:
			logger.error(
				"[ExecutionArchiver] 会话树结构计算失败，消息将按当前状态落库: conversation_id={}, message_id={}, error={}",
				conversation_id,
				message.id,
				exc,
			)
			return

		if message.ancestors:
			parent_message_id = message.ancestors[-1]
			parent_msg = next((item for item in conversation.messages if item.id == parent_message_id), None)
			if parent_msg and conversation_id:
				await self.state_store.save_message(parent_msg, conversation_id=conversation_id)

		if not had_messages_before:
			await self.state_store.save_conversation(conversation)


__all__ = ["ExecutionArchiver"]