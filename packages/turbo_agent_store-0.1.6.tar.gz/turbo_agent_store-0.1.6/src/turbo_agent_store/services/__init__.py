"""服务相关一级模块导出。"""

from turbo_agent_store.services.package_loader import PackageLoader

# 资源内容解析服务当前未在 store 模块内实现，保留可选占位供 runtime 侧降级判断。
get_resource_content = None

__all__ = ["PackageLoader", "get_resource_content"]