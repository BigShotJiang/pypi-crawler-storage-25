"""turbo_agent_store 通用 DTO 与枚举定义。"""

from enum import Enum


class SubjectType(str, Enum):
	"""可用性判断主体类型。"""

	USER = "user"
	AGENT = "agent"
	JOB = "job"
	PROJECT = "project"
	CHARACTER = "character"
	TOOL = "tool"
	# 兼容旧实现保留，后续逐步淘汰。
	RESOURCE = "resource"


class SubjectResourceType(str, Enum):
	"""主体为资源时的资源类型。"""

	AGENT = "agent"
	TOOL = "tool"
	CHARACTER = "character"
	PLATFORM = "platform"
	MODEL = "model"
	MODEL_INSTANCE = "model_instance"


__all__ = [
	"SubjectType",
	"SubjectResourceType",
]

