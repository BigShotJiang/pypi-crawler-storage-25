"""
ResourceStore 抽象定义

包含两类存储抽象：
1. ResourceStore - 用于管理 KnowledgeResource 相关文件的存储
   文件存储路径: {user_id}/{context_id}/{resource_id}/original/{filename}
   
2. ResourceEntityStore - 资源类实体（Project, KnowledgeResource, Workset, BusinessSetting, Secret, ModelInstance）的 CRUD
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Optional, List, AsyncIterator
from datetime import datetime
from turbo_agent_store.dtos import SubjectType, SubjectResourceType
from turbo_agent_core.schema.resources import (
    Project, 
    KnowledgeResource, 
    Workset, 
    BusinessSetting
)
from turbo_agent_core.schema.external import Secret
from turbo_agent_core.schema.basic import ModelInstance, ModelSeries, Endpoint
from turbo_agent_core.schema.detail_agent import ModelInstanceDetail
from turbo_agent_core.schema.enums import FileType, KnowledgeType
from turbo_agent_core.schema.refs import ModelInstanceRef, EndpointRef
from turbo_agent_store.interface.entity import TurboEntityLocator


@dataclass
class ResourceInfo:
    """资源文件信息"""
    resource_id: str
    name: str
    path: str  # 完整存储路径
    size: int
    content_type: Optional[str]
    created_at: datetime
    updated_at: datetime


class KnowledgeResourceStorageKind(str, Enum):
    """知识资源存储归类。"""

    TEMP = "temp"
    PROJECT = "project"


@dataclass
class KnowledgeResourceUploadSpec:
    """知识资源上传编排参数。"""

    resource_id: str
    name: str
    knowledge_type: KnowledgeType
    file_type: Optional[FileType]
    filename: str
    mime_type: str
    creator_id: str
    local_file_uri: str
    storage_kind: KnowledgeResourceStorageKind
    space_id: str
    project_id: Optional[str] = None


class ResourceStore(ABC):
    """
    KnowledgeResource 文件存储抽象基类。
    
    管理用户上传的资源文件，包括：
    - 原始文件上传/下载
    - 解析后的中间文件（预留）
    - 分块后的数据（预留）
    
    存储结构：
        {user_id}/{context_id}/{resource_id}/
        ├── original/{filename}     # 原始文件
        ├── parsed/                  # 解析结果（预留）
        │   └── content.json
        └── chunks/                  # 分块数据（预留）
            └── chunks.json
    """
    
    @abstractmethod
    async def upload_original(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        filename: str,
        data: bytes,
        content_type: Optional[str] = None
    ) -> str:
        """
        上传原始文件。
        
        Args:
            user_id: 用户ID
            context_id: 上下文ID (session_{id} / project_{id} / temp_{id})
            resource_id: 资源ID
            filename: 原始文件名
            data: 文件数据
            content_type: MIME类型
            
        Returns:
            完整存储路径: {user_id}/{context_id}/{resource_id}/original/{filename}
        """
        pass
    
    @abstractmethod
    async def download(self, path: str) -> bytes:
        """
        下载文件。
        
        Args:
            path: 完整存储路径
            
        Returns:
            文件数据
        """
        pass
    
    @abstractmethod
    async def download_stream(self, path: str) -> AsyncIterator[bytes]:
        """
        流式下载文件。
        
        Args:
            path: 完整存储路径
            
        Yields:
            文件数据块
        """
        pass
    
    @abstractmethod
    async def delete_resource(
        self,
        user_id: str,
        context_id: str,
        resource_id: str
    ) -> bool:
        """
        删除整个资源目录（包括原始文件和解析结果）。
        
        Args:
            user_id: 用户ID
            context_id: 上下文ID
            resource_id: 资源ID
            
        Returns:
            是否删除成功
        """
        pass
    
    @abstractmethod
    async def delete_file(self, path: str) -> bool:
        """
        删除指定路径的文件。
        
        Args:
            path: 完整存储路径
            
        Returns:
            是否删除成功
        """
        pass
    
    @abstractmethod
    async def exists(self, path: str) -> bool:
        """
        检查文件是否存在。
        
        Args:
            path: 完整存储路径
            
        Returns:
            文件是否存在
        """
        pass
    
    @abstractmethod
    async def get_size(self, path: str) -> int:
        """
        获取文件大小。
        
        Args:
            path: 完整存储路径
            
        Returns:
            文件大小（字节）
        """
        pass
    
    # ===== 子资源操作（预留接口）=====
    @abstractmethod
    async def save_parsed(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        data: bytes,
        format: str = "json"
    ) -> str:
        """
        保存解析后的内容（预留）。
        
        Args:
            format: 解析结果格式，默认 json
            
        Returns:
            存储路径
        """
        raise NotImplementedError("Parsed content storage not implemented")
    
    @abstractmethod
    async def get_parsed(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        format: str = "json"
    ) -> Optional[bytes]:
        """
        获取解析后的内容（预留）。
        """
    @abstractmethod
    async def save_chunks(
        self,
        user_id: str,
        context_id: str,
        resource_id: str,
        data: bytes
    ) -> str:
        """
        保存分块后的数据（预留）。
        """
    
    @abstractmethod
    async def get_chunks(
        self,
        user_id: str,
        context_id: str,
        resource_id: str
    ) -> Optional[bytes]:
        """
        获取分块后的数据（预留）。
        """


class ResourceEntityStore(ABC):
    """
    资源类实体的配置存储抽象类。
    
    包含 Project, KnowledgeResource, Workset, BusinessSetting, Secret, ModelInstance 的 CRUD。
    所有方法均支持 **kwargs 参数，用于实现侧传入鉴权信息。
    """

    # ========== Project CRUD ==========
    @abstractmethod
    async def get_project(self, locator: Optional[TurboEntityLocator] = None, **kwargs) -> Optional[Project]:
        """
        根据 ID 获取 Project。

        Args:
            locator: 项目定位器
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def save_project(self, project: Project, **kwargs) -> str:
        """
        保存 Project，返回 Project ID。

        Args:
            project: Project 实例
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_projects(
        self, 
        space_name: Optional[str] = None,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List[Project]:
        """
        列出 Projects。

        Args:
            org_id: 可选的组织ID过滤
            skip: 跳过的记录数
            limit: 返回的最大记录数
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def delete_project(self, locator: Optional[TurboEntityLocator] = None,**kwargs) -> bool:
        """
        删除 Project。

        Args:
            project_id: Project 唯一标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    # ========== KnowledgeResource CRUD ==========
    @abstractmethod
    async def upload_knowledge_resource(
        self,
        spec: KnowledgeResourceUploadSpec,
        **kwargs,
    ) -> KnowledgeResource:
        """
        上传知识资源文件、创建数据库记录并回写 metadata。

        Args:
            spec: 上传编排参数，显式区分 temp 与 project 两种存储目标
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def get_knowledge_resource(
        self, 
        resource_id: str, 
        **kwargs
    ) -> Optional[KnowledgeResource]:
        """
        根据 ID 获取 KnowledgeResource。

        Args:
            resource_id: Resource 唯一标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def save_knowledge_resource(
        self, 
        resource: KnowledgeResource, 
        **kwargs
    ) -> str:
        """
        保存 KnowledgeResource，返回 Resource ID。

        Args:
            resource: KnowledgeResource 实例
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_knowledge_resources(
        self, 
        locator: Optional[TurboEntityLocator] = None,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List[KnowledgeResource]:
        """
        列出 KnowledgeResources。

        Args:
            project_id: 可选的项目ID过滤
            skip: 跳过的记录数
            limit: 返回的最大记录数
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def delete_knowledge_resource(
        self, 
        resource_id: str, 
        **kwargs
    ) -> bool:
        """
        删除 KnowledgeResource。

        Args:
            resource_id: Resource 唯一标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def bind_knowledge_resources_to_setting(
        self,
        setting_id: str,
        knowledge_ids: List[str],
        **kwargs,
    ) -> bool:
        """
        将多个 KnowledgeResource 绑定到指定 BusinessSetting。

        该接口用于显式维护 Setting 与知识资源的关系，避免调用方直接依赖底层关系表。

        Args:
            setting_id: BusinessSetting 唯一标识
            knowledge_ids: 要绑定的 KnowledgeResource ID 列表
            **kwargs: 实现侧可传入 assigned_by_id, user_id 等鉴权/审计信息

        Returns:
            是否绑定成功
        """
        pass

    # ========== Workset CRUD ==========
    @abstractmethod
    async def get_workset(self, workset_id: str, **kwargs) -> Optional[Workset]:
        """
        根据 ID 获取 Workset。

        Args:
            workset_id: Workset 唯一标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def save_workset(self, workset: Workset, **kwargs) -> str:
        """
        保存 Workset，返回 Workset ID。

        Args:
            workset: Workset 实例
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_worksets(
        self, 
        locator: Optional[TurboEntityLocator] = None,
        owner_id: Optional[str] = None,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List[Workset]:
        """
        列出 Worksets。

        Args:
            project_id: 可选的项目ID过滤
            owner_id: 可选的所有者ID过滤
            skip: 跳过的记录数
            limit: 返回的最大记录数
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def delete_workset(self, workset_id: str, **kwargs) -> bool:
        """
        删除 Workset。

        Args:
            workset_id: Workset 唯一标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    # ========== BusinessSetting CRUD ==========
    @abstractmethod
    async def get_business_settings(
        self, 
        setting_ids: List[str], 
        **kwargs
    ) -> List[BusinessSetting]:
        """
        根据 ID 获取 BusinessSetting。

        Args:
            setting_ids: Setting 唯一标识列表
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def save_business_setting(
        self, 
        setting: BusinessSetting, 
        **kwargs
    ) -> str:
        """
        保存 BusinessSetting，返回 Setting ID。

        Args:
            setting: BusinessSetting 实例
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_business_settings(
        self, 
        locator: Optional[TurboEntityLocator] = None,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List[BusinessSetting]:
        """
        列出 BusinessSettings。

        Args:
            project_id: 可选的项目ID过滤
            skip: 跳过的记录数
            limit: 返回的最大记录数
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_available_business_settings(
        self,
        locator: Optional[TurboEntityLocator] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[BusinessSetting]:
        """列出当前上下文下可用的 BusinessSettings。"""
        pass

    @abstractmethod
    async def delete_business_setting(
        self, 
        setting_id: str, 
        **kwargs
    ) -> bool:
        """
        删除 BusinessSetting。

        Args:
            setting_id: Setting 唯一标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    # ========== Secret CRUD（来自 external.py，但属于 Resource）==========
    @abstractmethod
    async def get_secret(self, secret_id: str, **kwargs) -> Optional[Secret]:
        """
        根据 ID 获取 Secret。

        Args:
            secret_id: Secret 唯一标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def save_secret(self, secret: Secret, **kwargs) -> str:
        """
        保存 Secret，返回 Secret ID。

        Args:
            secret: Secret 实例
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_secrets(
        self, 
        platform_id: Optional[str] = None,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List[Secret]:
        """
        列出 Secrets。

        Args:
            platform_id: 可选的平台ID过滤
            skip: 跳过的记录数
            limit: 返回的最大记录数
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_available_secrets(
        self,
        platform_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[Secret]:
        """列出当前上下文下可用的 Secrets。"""
        pass

    @abstractmethod
    async def delete_secret(self, secret_id: str, **kwargs) -> bool:
        """
        删除 Secret。

        Args:
            secret_id: Secret 唯一标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    # ========== Endpoint CRUD ==========
    @abstractmethod
    async def get_endpoint(
        self,
        endpoint_id: str,
        **kwargs
    ) -> Optional[Endpoint]:
        """根据 ID 获取 Endpoint（detail）。"""
        pass

    @abstractmethod
    async def save_endpoint(
        self,
        endpoint: Endpoint,
        **kwargs
    ) -> str:
        """保存 Endpoint，返回 Endpoint ID。"""
        pass

    @abstractmethod
    async def delete_endpoint(
        self,
        endpoint_id: str,
        **kwargs
    ) -> bool:
        """删除 Endpoint。"""
        pass

    @abstractmethod
    async def list_model_instance_endpoints(
        self,
        locator: Optional[TurboEntityLocator] = None,
        skip: int = 0,
        limit: int = 20,
        **kwargs
    ) -> List[EndpointRef]:
        """
        列出可被 ModelInstance 复用的 Endpoint（brief）。

        Args:
            locator: 可选定位过滤（space_name/series_name/model_name/project_name_id/version）。
                兼容说明：当前仍复用 TurboEntityLocator，其中 model_name 对应 locator.name_id，
                version 对应 locator.version_tag。
            skip: 跳过的记录数
            limit: 返回的最大记录数
        """
        pass

    # ========== ModelInstance CRUD（来自 basic.py）==========
    @abstractmethod
    async def get_model_instance_brief(
        self,
        locator: TurboEntityLocator,
        **kwargs
    ) -> Optional[ModelInstanceRef]:
        """
        根据定位读取 ModelInstance 简要态（brief）。

        Args:
            locator: 模型实例定位（space_name/series_name/model_name/version + 可选 project_name_id）。
                兼容说明：当前仍复用 TurboEntityLocator，其中 model_name 对应 locator.name_id，
                version 对应 locator.version_tag。
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def get_model_instance_detail(
        self,
        locator: TurboEntityLocator,
        **kwargs
    ) -> Optional[ModelInstanceDetail]:
        """
        根据定位读取 ModelInstance 详情态（detail）。

        Args:
            locator: 模型实例定位（space_name/series_name/model_name/version + 可选 project_name_id）。
                兼容说明：当前仍复用 TurboEntityLocator，其中 model_name 对应 locator.name_id，
                version 对应 locator.version_tag。
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def get_model_instance_runnable(
        self,
        locator: TurboEntityLocator,
        **kwargs
    ) -> Optional[ModelInstance]:
        """
        根据定位读取 ModelInstance 运行态（runnable）。

        Args:
            locator: 模型实例定位（space_name/series_name/model_name/version + 可选 project_name_id）。
                兼容说明：当前仍复用 TurboEntityLocator，其中 model_name 对应 locator.name_id，
                version 对应 locator.version_tag。
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def get_model_instance(
        self, 
        instance_id: str, 
        **kwargs
    ) -> Optional[ModelInstance]:
        """
        根据 ID 获取 ModelInstance（兼容入口，语义等价于 runnable）。

        Args:
            instance_id: ModelInstance 唯一标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def save_model_instance(
        self, 
        instance: ModelInstance, 
        locator: TurboEntityLocator,
        **kwargs
    ) -> str:
        """
        保存 ModelInstance，返回 Instance ID。

        Args:
            instance: ModelInstance 实例
            locator: 模型实例定位信息（space_name + series_name + model_name + 可选 version/project_name_id）。
                兼容说明：当前仍复用 TurboEntityLocator，其中 model_name 对应 locator.name_id，
                version 对应 locator.version_tag。
            **kwargs: 实现侧可传入 user_id、project_name_id、org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def delete_model_instance(
        self, 
        instance_id: str, 
        **kwargs
    ) -> bool:
        """
        删除 ModelInstance。

        Args:
            instance_id: ModelInstance 唯一标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_model_instances(
        self, 
        locator: Optional[TurboEntityLocator] = None,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List[ModelInstanceRef]:
        """
        列出 ModelInstances 简要态（brief）。

        Args:
            locator: 可选定位过滤（space_name/series_name/model_name/project_name_id/version）。
                兼容说明：当前仍复用 TurboEntityLocator，其中 model_name 对应 locator.name_id，
                version 对应 locator.version_tag。
            skip: 跳过的记录数
            limit: 返回的最大记录数
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def update_model_instance(
        self, 
        locator: TurboEntityLocator,
        instance: ModelInstance, 
        **kwargs
    ) -> bool:
        """
        更新 ModelInstance。

        Args:
            locator: 模型实例定位（space_name/series_name/model_name/version + 可选 project_name_id）。
                兼容说明：当前仍复用 TurboEntityLocator，其中 model_name 对应 locator.name_id，
                version 对应 locator.version_tag。
            instance: 更新的 ModelInstance 数据
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    # ========== ModelSeries 管理（模型系列）==========
    @abstractmethod
    async def create_model_series(
        self, 
        series: "ModelSeries", 
        creator_id: str,
        **kwargs
    ) -> str:
        """
        创建模型空间。

        Args:
            series: ModelSeries 实例
            creator_id: 创建者ID
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def get_model_series(
        self, 
        series_name: str,
        **kwargs
    ) -> Optional["ModelSeries"]:
        """
        获取模型空间详情。

        Args:
            series_name: 模型系列名称（唯一标识）
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def update_model_series(
        self, 
        series_name: str,
        series: "ModelSeries", 
        **kwargs
    ) -> bool:
        """
        更新模型空间。

        Args:
            series_name: 模型系列名称（唯一标识）
            series: 更新的 ModelSeries 数据
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def delete_model_series(
        self, 
        series_name: str,
        **kwargs
    ) -> bool:
        """
        删除模型空间。

        Args:
            series_name: 模型系列名称（唯一标识）
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_model_series(
        self, 
        user_id: Optional[str] = None,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List["ModelSeries"]:
        """
        列出模型空间。

        Args:
            user_id: 可选的用户ID过滤
            skip: 跳过的记录数
            limit: 返回的最大记录数
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_available_model_series(
        self,
        space_name: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List["ModelSeries"]:
        """列出当前上下文下可用的模型系列。"""
        pass
