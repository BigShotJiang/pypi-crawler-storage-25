"""统一持久化基础接口。"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Generic, List, Optional, TypeVar

from turbo_agent_core.schema.enums import RefType
from turbo_agent_core.schema.refs import BasicRef
from turbo_agent_store.dtos import SubjectType

T_Brief = TypeVar("T_Brief")
T_Detail = TypeVar("T_Detail")
T_Save = TypeVar("T_Save")
T_Locator = TypeVar("T_Locator")


@dataclass
class BindingRelation:
    """绑定查询结果。"""

    target: Any
    relation_info: dict[str, Any] = field(default_factory=dict)


class BasePersistence(
    ABC,
    Generic[
        T_Brief,
        T_Detail,
        T_Save,
        T_Locator,
    ],
):
    """
    通用资源持久化基础接口。

    规则：
    - `list` 仅返回 brief 对象。
    - `get` 拆分为 `get_brief` 与 `get_detail`。
    - `save` 仅接收 detail 或 runnable 级别数据，由具体实现决定。
    - 不提供 runnable 的读取或写入接口。
    - `list_available` 作为基础统一接口保留在该基类中。
    """

    @abstractmethod
    async def get_brief(self, locator: T_Locator, **kwargs) -> Optional[T_Brief]:
        """读取实体的简要信息（常用于列表与卡片）。"""

    @abstractmethod
    async def get_detail(self, locator: T_Locator, **kwargs) -> Optional[T_Detail]:
        """读取实体的详细信息（含更多业务关联字段）。"""

    @abstractmethod
    async def save(self, entity: T_Save, **kwargs) -> Any:
        """
        保存或更新实体数据记录。

        返回该实体的标识（如 ID 或 version_id），具体返回类型由实现决定。
        """

    @abstractmethod
    async def list(
        self,
        skip: int = 0,
        limit: int = 20,
        **kwargs,
    ) -> List[T_Brief]:
        """列出实体记录列表（brief 结构）。"""

    @abstractmethod
    async def list_available(
        self,
        skip: int = 0,
        limit: int = 20,
        subject_type: Optional[SubjectType] = None,
        subject_id: Optional[str] = None,
        **kwargs,
    ) -> List[T_Brief]:
        """列出当前上下文下可用的资源集合（brief 结构）。"""

    @abstractmethod
    async def delete(self, locator: T_Locator, **kwargs) -> bool:
        """删除实体记录。"""

    @abstractmethod
    async def bind(self, owner: T_Locator, target_ref: BasicRef, **kwargs) -> bool:
        """建立 owner 与目标 ref 的绑定关系。"""

    @abstractmethod
    async def unbind(
        self,
        owner: T_Locator,
        target_type: RefType,
        target_id: str,
        **kwargs,
    ) -> bool:
        """根据目标类型与目标 id 解除绑定关系。"""

    @abstractmethod
    async def list_bind(
        self,
        owner: T_Locator,
        target_type: RefType,
        **kwargs,
    ) -> List[BindingRelation]:
        """列出指定 owner 在某一目标类型下的绑定数据及关系信息。"""