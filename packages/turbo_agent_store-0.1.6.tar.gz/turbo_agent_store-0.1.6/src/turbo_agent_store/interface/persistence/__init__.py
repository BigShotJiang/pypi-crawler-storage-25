"""持久化抽象子包。"""

from .base import BasePersistence, BindingRelation
__all__ = [
    "BasePersistence",
    "BindingRelation",
]