"""
Gitea 资产管理抽象接口

用于统一管理项目文件与图片资源，覆盖以下能力：
1. 项目创建与后台同步
2. 根据路径模板创建项目文件管理路径
3. 指定资源（KnowledgeResource）自动提供
4. 默认公开策略（权限由业务层控制）
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class ProjectSyncSpec:
    """项目同步请求。"""

    org_name: str
    repo_name: str
    project_id: str
    local_repo_path: str
    description: str = ""
    default_branch: str = "main"


@dataclass
class ProjectSyncResult:
    """项目同步结果。"""

    org_name: str
    repo_name: str
    project_id: str
    repo_http_url: str
    repo_clone_url: str
    default_branch: str
    is_public: bool
    synced_at: datetime


@dataclass
class ManagedPathSpec:
    """路径模板请求。"""

    template: str
    project_id: str
    resource_type: str
    resource_id: str
    filename: Optional[str] = None
    workset_id: Optional[str] = None
    org_name: Optional[str] = None
    repo_name: Optional[str] = None


@dataclass
class ManagedPathResult:
    """路径模板结果。"""

    rendered_path: str
    created_at: datetime


@dataclass
class KnowledgeResourceProvisionSpec:
    """KnowledgeResource 自动提供请求。"""

    org_name: str
    repo_name: str
    project_id: str
    local_repo_path: str
    resource_id: str
    filename: str
    content: bytes
    content_type: str = "application/octet-stream"
    path_template: str = "assets/knowledge/{project_id}/{resource_id}/{filename}"
    commit_message: Optional[str] = None
    default_branch: str = "main"


@dataclass
class KnowledgeResourceProvisionResult:
    """KnowledgeResource 自动提供结果。"""

    repo_path: str
    raw_url: str
    commit_hash: str
    provided_at: datetime


class AssetRepositoryStore(ABC):
    """项目资产仓储抽象。"""

    @abstractmethod
    async def create_project_and_sync(self, spec: ProjectSyncSpec) -> ProjectSyncResult:
        """创建项目仓库并完成本地同步。"""

    @abstractmethod
    async def create_managed_path(self, spec: ManagedPathSpec) -> ManagedPathResult:
        """按路径模板创建项目内管理路径。"""

    @abstractmethod
    async def provide_knowledge_resource(
        self,
        spec: KnowledgeResourceProvisionSpec,
    ) -> KnowledgeResourceProvisionResult:
        """自动提供指定 KnowledgeResource 到 Gitea。"""

    @abstractmethod
    async def ensure_default_public(self, org_name: str, repo_name: str) -> bool:
        """确保仓库默认公开。"""
