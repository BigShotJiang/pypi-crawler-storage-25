from __future__ import annotations

from abc import ABC, abstractmethod
from typing import AsyncIterator, Callable

from turbo_agent_core.schema.events import BaseEvent


class BaseRuntimeMonitor(ABC):
    """Runtime 监控器基类。"""
    
    @abstractmethod
    def start(self) -> None: ...
    
    @abstractmethod
    async def close(self) -> None: ...
    
    @abstractmethod
    def write(self, event: BaseEvent) -> None: ...

    def monitor_stream(
        self,
        factory: Callable[..., AsyncIterator[BaseEvent]],
    ) -> Callable[..., AsyncIterator[BaseEvent]]:
        async def wrapped(*args, **kwargs) -> AsyncIterator[BaseEvent]:
            async for event in factory(*args, **kwargs):
                self.write(event)
                yield event

        return wrapped
