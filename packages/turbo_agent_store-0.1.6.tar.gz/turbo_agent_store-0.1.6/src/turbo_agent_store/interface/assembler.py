# coding=utf-8
import warnings
from abc import ABC, abstractmethod
from typing import Optional, Any, TypeVar, Generic

from turbo_agent_core.schema.basic import TurboEntity, BriefTurboEntity, DetailTurboEntity
from .entity import TurboEntityLocator

T = TypeVar("T", bound=TurboEntity)

class TurboEntityAssembler(ABC, Generic[T]):
    """
    数据组装器抽象基类。
    负责将底层存储模型（如 Prisma ORM 对象）转换为 Core Pydantic 实体。

    公共接口：
    - assemble_runnable(locator, user_id)：运行态组装的唯一入口。
      外部业务方（store / server / router）及 assembler 内部递归组装
      均统一通过此方法。locator 同时承载执行上下文（space / project）。
    - assemble_brief(locator) / assemble_detail(locator)：简要态 / 详细态组装。
    - assemble_inline(raw_data, user_id)：行内数据组装。

    显式参数约定：
    - user_id: 请求用户 ID，用于可用性过滤（如模型实例的可见范围）。
    - 执行上下文（executor_space_name / executor_project_name_id）：
      由 locator.space_name / locator.project_name_id 隐含提供。
    - **kwargs: 保留给实现侧特定参数（如 allow_litellm_side_effects、
      rewrite_for_managed_runtime 等），不在抽象层约定。
    """

    @abstractmethod
    def __init__(self, client: Any):
        """
        初始化组装器。
        
        Args:
            client: 数据库客户端实例 (如 Prisma Client)
        """
        self.client = client

    async def assemble_brief(self, locator: TurboEntityLocator) -> Optional[BriefTurboEntity]:
        """组装简要态实体（brief）。"""
        raise NotImplementedError("该 Assembler 未实现 locator 三态组装接口")

    async def assemble_detail(self, locator: TurboEntityLocator) -> Optional[DetailTurboEntity]:
        """组装详细态实体（detail）。"""
        raise NotImplementedError("该 Assembler 未实现 locator 三态组装接口")

    async def assemble_runnable(
        self,
        locator: TurboEntityLocator,
        user_id: Optional[str] = None,
        **kwargs,
    ) -> Optional[T]:
        """组装运行态实体（runnable）—— 唯一组装入口。

        外部业务方及 assembler 内部递归组装均通过此方法。
        执行上下文由 locator 隐含提供：
        - locator.space_name → executor_space_name
        - locator.project_name_id → executor_project_name_id

        Args:
            locator: 实体定位器，同时承载执行上下文（space / project）。
            user_id: 请求用户 ID，用于可用性过滤。
            **kwargs: 实现侧扩展参数。
        """
        raise NotImplementedError("该 Assembler 未实现 assemble_runnable 接口")

    async def assemble_inline(
        self,
        raw_data: Any,
        user_id: Optional[str] = None,
        **kwargs,
    ) -> Optional[T]:
        """行内数据组装，直接传入底层数据模型对象进行转换。

        Args:
            raw_data: 底层原始数据模型（如 Prisma 模型）。
            user_id: 请求用户 ID。
            **kwargs: 扩展参数。
        """
        raise NotImplementedError("该 Assembler 未实现 assemble_inline 接口")
