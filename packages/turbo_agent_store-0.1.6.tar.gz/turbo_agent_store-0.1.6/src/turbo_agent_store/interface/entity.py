"""
TurboEntityStore - 继承自 TurboEntity 的实体的配置存储抽象

所有继承 TurboEntity 的类（Agent, Character, Tool, LLMModel）的 CRUD 操作都通过此接口定义。
资源定位方式：space + project_name_id + name_id (+ version_tag)

此外包含：
- Agent 绑定管理（Character/Tool/Secret）
- Space 管理（通过 spaceName 定位）
"""

from abc import ABC, abstractmethod
from typing import Optional, List
from turbo_agent_core.schema.agents import Agent, Tool, Character, LLMModel
from turbo_agent_core.schema.basic import Space
from turbo_agent_core.schema.brief_agent import AgentBrief, ToolBrief, CharacterBrief, LLMModelBrief
from turbo_agent_core.schema.detail_agent import AgentDetail, ToolDetail, CharacterDetail, LLMModelDetail
from turbo_agent_store.dtos import SubjectType, SubjectResourceType
from enum import Enum


class LocatorType(str, Enum):
    AGENT = "agent"
    CHARACTER = "character"
    TOOL = "tool"
    LLM_MODEL = "llm_model"
    MODEL_INSTANCE = "model_instance"
    MODEL_SERIES = "model_series"
    PROJECT = "project"
    SPACE = "space"

class TurboEntityLocator:
    """统一实体读取定位参数。

    说明：
    - Agent 不支持版本维度，version_tag 对 Agent 会被忽略。
    - Character / Tool 可使用 version_tag 精确定位版本。
    """

    def __init__(
        self,
        space_name: str,
        project_name_id: Optional[str] = None,
        name_id: Optional[str] = None,
        version_tag: Optional[str] = None,
        series_name: Optional[str] = None,
        type: Optional[LocatorType] = None,
    ):
        self.space_name = space_name
        self.project_name_id = project_name_id
        self.name_id = name_id
        self.version_tag = version_tag
        self.series_name = series_name
        self.type = type

class TurboEntityStore(ABC):
    """
    继承自 TurboEntity 的实体的配置存储抽象类。

    资源定位方式：space + project_name_id + name_id (+ version_tag) 组合定位资源。

    Runnable 数据获取接口的显式参数约定：
    - user_id: 请求用户 ID，用于子依赖的可用性过滤（如模型实例可见范围）。
      在 get_*_runnable 方法中显式声明，不再通过 kwargs 隐式传递。
    - 执行上下文（executor_space_name / executor_project_name_id）：
      由 locator.space_name / locator.project_name_id 隐含提供，
      在内部委托给 Assembler 时自动提取并传递。
    - **kwargs: 保留给实现侧特定参数（如 allow_litellm_side_effects 等）。
    """

    # ========== 三态读取接口（brief/detail/runnable） ==========
    @abstractmethod
    async def get_agent_brief(self, locator: TurboEntityLocator, **kwargs) -> Optional[AgentBrief]:
        """读取 Agent 简要信息（卡片展示）。"""
        pass

    @abstractmethod
    async def get_agent_detail(self, locator: TurboEntityLocator, **kwargs) -> Optional[AgentDetail]:
        """读取 Agent 详细信息（编辑态）。"""
        pass

    @abstractmethod
    async def get_agent_runnable(
        self,
        locator: TurboEntityLocator,
        user_id: Optional[str] = None,
        **kwargs,
    ) -> Optional[Agent]:
        """读取 Agent 可执行信息（运行态）。

        Args:
            locator: 实体定位器，同时承载执行上下文（space / project）。
            user_id: 请求用户 ID，用于子依赖可用性过滤。
            **kwargs: 实现侧扩展参数。
        """
        pass

    @abstractmethod
    async def get_character_brief(self, locator: TurboEntityLocator, **kwargs) -> Optional[CharacterBrief]:
        """读取 Character 简要信息（卡片展示）。"""
        pass

    @abstractmethod
    async def get_character_detail(self, locator: TurboEntityLocator, **kwargs) -> Optional[CharacterDetail]:
        """读取 Character 详细信息（编辑态）。"""
        pass

    @abstractmethod
    async def get_character_runnable(
        self,
        locator: TurboEntityLocator,
        user_id: Optional[str] = None,
        **kwargs,
    ) -> Optional[Character]:
        """读取 Character 可执行信息（运行态）。

        Args:
            locator: 实体定位器，同时承载执行上下文（space / project）。
            user_id: 请求用户 ID，用于子依赖可用性过滤。
            **kwargs: 实现侧扩展参数。
        """
        pass

    @abstractmethod
    async def get_tool_brief(self, locator: TurboEntityLocator, **kwargs) -> Optional[ToolBrief]:
        """读取 Tool 简要信息（卡片展示）。"""
        pass

    @abstractmethod
    async def get_tool_detail(self, locator: TurboEntityLocator, **kwargs) -> Optional[ToolDetail]:
        """读取 Tool 详细信息（编辑态）。"""
        pass

    @abstractmethod
    async def get_tool_runnable(
        self,
        locator: TurboEntityLocator,
        user_id: Optional[str] = None,
        **kwargs,
    ) -> Optional[Tool]:
        """读取 Tool 可执行信息（运行态）。

        Args:
            locator: 实体定位器，同时承载执行上下文（space / project）。
            user_id: 请求用户 ID，用于子依赖可用性过滤。
            **kwargs: 实现侧扩展参数。
        """
        pass

    # ========== Agent CRUD ==========
    @abstractmethod
    async def get_agent(self, locator: TurboEntityLocator, **kwargs) -> Optional[Agent]:
        """根据 locator 获取 Agent。"""
        pass

    @abstractmethod
    async def save_agent(self, agent: Agent, **kwargs) -> str:
        """
        保存 Agent，返回版本 ID。

        Args:
            agent: Agent 实例
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_agents(
        self, 
        space_name: str,
        project_name_id: str,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List[AgentBrief]:
        """列出指定项目下的 Agents（brief 结构）。"""
        pass

    @abstractmethod
    async def list_available_agents(
        self,
        space_name: str,
        project_name_id: str,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[AgentDetail]:
        """列出当前上下文下可用的 Agents（detail 结构）。"""
        pass

    @abstractmethod
    async def delete_agent(
        self, 
        locator: TurboEntityLocator,
        **kwargs
    ) -> bool:
        """根据 locator 删除 Agent。"""
        pass

    # ========== Agent 绑定管理 ==========
    @abstractmethod
    async def bind_agent_character(
        self, 
        agent_locator: TurboEntityLocator,
        character_locator: TurboEntityLocator,
        **kwargs
    ) -> bool:
        """绑定 Character 到 Agent。character_locator 可携带 version_tag 用于版本校验。"""
        pass

    @abstractmethod
    async def unbind_agent_character(
        self, 
        agent_locator: TurboEntityLocator,
        character_locator: TurboEntityLocator,
        **kwargs
    ) -> bool:
        """解绑 Agent 的 Character。"""
        pass

    @abstractmethod
    async def bind_agent_tool(
        self, 
        agent_locator: TurboEntityLocator,
        tool_locator: TurboEntityLocator,
        **kwargs
    ) -> bool:
        """绑定 Tool 到 Agent。tool_locator 可携带 version_tag 用于版本校验。"""
        pass

    @abstractmethod
    async def unbind_agent_tool(
        self, 
        agent_locator: TurboEntityLocator,
        tool_locator: TurboEntityLocator,
        **kwargs
    ) -> bool:
        """解绑 Agent 的 Tool。"""
        pass

    @abstractmethod
    async def bind_agent_secret(
        self, 
        agent_locator: TurboEntityLocator,
        secret_id: str,
        **kwargs
    ) -> bool:
        """绑定 Secret 到 Agent。"""
        pass

    @abstractmethod
    async def unbind_agent_secret(
        self, 
        agent_locator: TurboEntityLocator,
        secret_id: str,
        **kwargs
    ) -> bool:
        """解绑 Agent 的 Secret。"""
        pass

    @abstractmethod
    async def list_agent_characters(
        self,
        agent_locator: TurboEntityLocator,
        **kwargs
    ) -> List[Character]:
        """列出 Agent 绑定的所有 Characters。"""
        pass

    @abstractmethod
    async def list_agent_tools(
        self,
        agent_locator: TurboEntityLocator,
        **kwargs
    ) -> List[Tool]:
        """列出 Agent 绑定的所有 Tools。"""
        pass

    # ========== Character CRUD ==========
    @abstractmethod
    async def get_character(
        self, 
        locator: TurboEntityLocator,
        **kwargs
    ) -> Optional[Character]:
        """根据 locator 获取 Character（可通过 version_tag 指定版本）。"""
        pass

    @abstractmethod
    async def save_character(self, character: Character, **kwargs) -> str:
        """
        保存 Character，返回版本 ID。

        Args:
            character: Character 实例
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_characters(
        self, 
        space_name: str,
        project_name_id: str,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List[CharacterBrief]:
        """列出指定项目下的 Characters（brief 结构）。"""
        pass

    @abstractmethod
    async def list_available_characters(
        self,
        space_name: str,
        project_name_id: str,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[CharacterDetail]:
        """列出当前上下文下可用的 Characters（detail 结构）。"""
        pass

    @abstractmethod
    async def delete_character(
        self, 
        locator: TurboEntityLocator,
        **kwargs
    ) -> bool:
        """根据 locator 删除 Character。"""
        pass

    # ========== Tool CRUD ==========
    @abstractmethod
    async def get_tool(
        self, 
        locator: TurboEntityLocator,
        **kwargs
    ) -> Optional[Tool]:
        """根据 locator 获取 Tool（可通过 version_tag 指定版本）。"""
        pass

    @abstractmethod
    async def save_tool(self, tool: Tool, **kwargs) -> str:
        """
        保存 Tool，返回版本 ID。

        Args:
            tool: Tool 实例
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_tools(
        self, 
        space_name: str,
        project_name_id: str,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List[ToolBrief]:
        """列出指定项目下的 Tools（brief 结构）。"""
        pass

    @abstractmethod
    async def list_available_tools(
        self,
        space_name: str,
        project_name_id: str,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs,
    ) -> List[ToolDetail]:
        """列出当前上下文下可用的 Tools（detail 结构）。"""
        pass

    @abstractmethod
    async def delete_tool(
        self, 
        locator: TurboEntityLocator,
        **kwargs
    ) -> bool:
        """根据 locator 删除 Tool。"""
        pass

    # ========== LLMModel CRUD ==========
    @abstractmethod
    async def get_model_brief(self, locator: Optional[TurboEntityLocator] = None, **kwargs) -> Optional[LLMModelBrief]:
        """读取 LLMModel 简要信息（卡片展示）。"""
        pass

    @abstractmethod
    async def get_model_detail(self, locator: Optional[TurboEntityLocator] = None, **kwargs) -> Optional[LLMModelDetail]:
        """读取 LLMModel 详细信息（编辑态）。"""
        pass

    @abstractmethod
    async def get_model_runnable(
        self,
        locator: Optional[TurboEntityLocator] = None,
        user_id: Optional[str] = None,
        **kwargs,
    ) -> Optional[LLMModel]:
        """读取 LLMModel 可执行信息（运行态）。

        Args:
            locator: 实体定位器，同时承载执行上下文（space / project）。
            user_id: 请求用户 ID，用于子依赖可用性过滤。
            **kwargs: 实现侧扩展参数。
        """
        pass

    @abstractmethod
    async def get_model(
        self, 
        locator: Optional[TurboEntityLocator] = None,
        **kwargs
    ) -> Optional[LLMModel]:
        """根据 locator 获取 LLMModel（可通过 version_tag 指定版本）。"""
        pass

    @abstractmethod
    async def save_model(self, model: LLMModel, **kwargs) -> str:
        """
        保存 LLMModel，返回版本 ID。

        Args:
            model: LLMModel 实例
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass



    @abstractmethod
    async def list_models(
        self, 
        space_name: str,
        skip: int = 0, 
        limit: int = 20, 
        project_name_id: Optional[str]=None,
        **kwargs
    ) -> List[LLMModelBrief]:
        """列出指定项目下的 LLMModels（brief 结构）。"""
        pass

    @abstractmethod
    async def list_available_models(
        self,
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 20,
        subject_type: SubjectType = SubjectType.USER,
        subject_resource_type: Optional[SubjectResourceType] = None,
        subject_resource_id: Optional[str] = None,
        **kwargs
    ) -> List[LLMModelDetail]:
        """列出当前上下文下可运行的 LLMModels（需存在可用实例）。"""
        pass

    @abstractmethod
    async def check_and_unbind_resource_dependencies(
        self,
        resource_type: str,
        locator: Optional[TurboEntityLocator] = None,
        resource_id: Optional[str] = None,
        execute_unbind: bool = False,
        **kwargs,
    ) -> dict:
        """检查资源依赖并按需解绑。

        用途：当资源 availability 发生变更时，先检查其被依赖关系；
        若 execute_unbind=True，则对可自动解绑的依赖关系执行解绑。

        Args:
            resource_type: 资源类型（如 model/tool/character/platform/secret）
            locator: 资源定位（可选）
            resource_id: 资源 ID（可选，优先）
            execute_unbind: 是否执行解绑动作（默认仅检查）
            **kwargs: 实现侧可传入 user_id、trace_id 等上下文
        """
        pass

    @abstractmethod
    async def delete_model(
        self, 
        locator: TurboEntityLocator,
        **kwargs
    ) -> bool:
        """根据 locator 删除 LLMModel。"""
        pass

    # ========== Space 管理 ==========
    @abstractmethod
    async def get_space(self, space_name: str, **kwargs) -> Optional[Space]:
        """
        通过 spaceName 获取 Space 信息。

        Args:
            space_name: Space 名称标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def create_space(self, space: Space, **kwargs) -> str:
        """
        创建 Space。

        Args:
            space: Space 实例
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def update_space(
        self, 
        space_name: str, 
        space: Space, 
        **kwargs
    ) -> bool:
        """
        更新 Space（spaceName 不可变，只能更新其他字段）。

        Args:
            space_name: 原 Space 名称标识
            space: 新的 Space 数据
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def delete_space(self, space_name: str, **kwargs) -> bool:
        """
        删除 Space。

        Args:
            space_name: Space 名称标识
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass

    @abstractmethod
    async def list_spaces(
        self, 
        space_type: Optional[str] = None,
        skip: int = 0, 
        limit: int = 20, 
        **kwargs
    ) -> List[Space]:
        """
        列出 Spaces。

        Args:
            space_type: 可选的 Space 类型过滤（USER/ORG）
            skip: 跳过的记录数
            limit: 返回的最大记录数
            **kwargs: 实现侧可传入 user_id, org_id 等鉴权信息
        """
        pass
