"""权限检查存储抽象。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional


class PermissionStore(ABC):
    """权限检查存储抽象类。"""

    @abstractmethod
    async def check_conversation_access(
        self,
        conversation_id: str,
        owner_user_id: Optional[str],
        user_id: str,
        require_write: bool = False,
    ) -> bool:
        """检查用户是否可访问指定对话。"""

    @abstractmethod
    async def check_resource_access(
        self,
        availability: str,
        project_id: str,
        creator_id: str,
        user_id: str,
        require_write: bool = False,
    ) -> bool:
        """检查资源访问权限。"""

    @abstractmethod
    async def check_project_access(
        self,
        project_id: str,
        user_id: str,
        require_write: bool = False,
    ) -> bool:
        """检查项目访问权限。"""

    @abstractmethod
    async def check_org_access(
        self,
        org_name_en: str,
        user_id: str,
        require_admin: bool = False,
    ) -> bool:
        """检查机构访问权限。"""