"""
Store 模块 CLI

提供 YAML 格式的配置导出/导入功能。
注意：数据库相关的命令已移动到 turbo-agent-cloud 模块。
"""

import asyncio
import io
import os
import typer
import yaml
import json
import shutil
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional
from rich.console import Console
from rich.table import Table
from loguru import logger

from turbo_agent_store.services.package_loader import PackageLoader

app = typer.Typer()
console = Console()


def _write_package_bytes(output: str, package_bytes: bytes):
    """将导出结果写入 zip 文件或解压到目录。"""
    if output.endswith(".zip"):
        Path(output).write_bytes(package_bytes)
        return

    output_dir = Path(output)
    output_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(package_bytes), "r") as zip_file:
        zip_file.extractall(output_dir)


def _infer_export_scope(store):
    """从已加载的 YAMLConfigStore 推断导出作用域。"""
    from turbo_agent_store.config_export import CoreDataExportScope

    entities = store.get_all_entities()
    scoped_entities = [entity for entity in entities if hasattr(entity, "space_name")]

    if len(scoped_entities) == 1:
        entity = scoped_entities[0]
        entity_type_map = {
            "Agent": "agent",
            "Character": "character",
            "Tool": "tool",
            "LLMModel": "model",
        }
        entity_type = entity_type_map.get(entity.__class__.__name__)
        if entity_type:
            return CoreDataExportScope(
                scope_type="entity",
                entity_type=entity_type,
                space_name=getattr(entity, "space_name", None),
                project_name_id=getattr(entity, "project_name_id", None),
                entity_id=getattr(entity, "id", None),
                name_id=getattr(entity, "name_id", None),
                version_tag=getattr(entity, "version_tag", None),
                series_name=getattr(entity, "series_name", None),
            )

    project_pairs = {
        (getattr(entity, "space_name", None), getattr(entity, "project_name_id", None))
        for entity in scoped_entities
        if getattr(entity, "space_name", None) and getattr(entity, "project_name_id", None)
    }
    if len(project_pairs) == 1:
        space_name, project_name_id = next(iter(project_pairs))
        return CoreDataExportScope(
            scope_type="project",
            space_name=space_name,
            project_name_id=project_name_id,
        )

    spaces = {getattr(entity, "space_name", None) for entity in scoped_entities if getattr(entity, "space_name", None)}
    if len(spaces) == 1:
        return CoreDataExportScope(scope_type="space", space_name=next(iter(spaces)))

    raise ValueError("无法从当前 package 自动推断唯一导出作用域，请在业务代码中显式调用 PackageExporter.export_core_data(...)。")


def _copy_package_payload_from_dir(source_dir: Path, output: str):
    """复制已有 package 中的二进制资源目录。"""
    payload_roots = ["assets", "resources"]

    if output.endswith(".zip"):
        with zipfile.ZipFile(output, "a", zipfile.ZIP_DEFLATED) as zf:
            for root in payload_roots:
                root_dir = source_dir / root
                if not root_dir.exists():
                    continue
                for file_path in root_dir.rglob("*"):
                    if file_path.is_file():
                        zf.write(file_path, arcname=str(file_path.relative_to(source_dir)))
    else:
        output_dir = Path(output)
        for root in payload_roots:
            root_dir = source_dir / root
            if not root_dir.exists():
                continue
            target_dir = output_dir / root
            if target_dir.exists():
                shutil.rmtree(target_dir)
            shutil.copytree(root_dir, target_dir)


def _copy_package_payload_from_zip(source_zip: Path, output: str):
    """复制已有 zip package 中的二进制资源目录。"""
    payload_roots = ("assets/", "resources/")
    with zipfile.ZipFile(source_zip, "r") as src:
        names = [name for name in src.namelist() if name.startswith(payload_roots) and not name.endswith("/")]
        if output.endswith(".zip"):
            with zipfile.ZipFile(output, "a", zipfile.ZIP_DEFLATED) as dst:
                for name in names:
                    dst.writestr(name, src.read(name))
        else:
            output_dir = Path(output)
            for name in names:
                target = output_dir / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(src.read(name))


# ===== Verify Command =====

@app.command()
def verify(
    package_path: str = typer.Argument(..., help="Zip 包路径"),
):
    """
    验证 Zip 包并尝试加载到内存。
    检查包内 YAML 文件的格式和依赖关系。
    """
    if not os.path.exists(package_path):
        console.print(f"[red]文件不存在: {package_path}[/red]")
        raise typer.Exit(code=1)

    try:
        loader = PackageLoader()
        entities = loader.load(package_path)
        
        table = Table(title=f"包内容: {os.path.basename(package_path)}")
        table.add_column("Type", style="cyan")
        table.add_column("ID", style="magenta")
        table.add_column("Name")
        table.add_column("Dependencies")
        
        for entity in entities:
            deps = []
            if hasattr(entity, 'model') and entity.model:
                deps.append(f"Model:{entity.model.name}")
            if hasattr(entity, 'tools') and entity.tools:
                deps.append(f"Tools:{len(entity.tools)}")
            
            table.add_row(
                entity.__class__.__name__,
                entity.id,
                entity.name,
                ", ".join(deps)
            )
            
        console.print(table)
        console.print(f"[green]成功加载 {len(entities)} 个实体[/green]")
        
    except Exception as e:
        console.print(f"[red]加载失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        raise typer.Exit(code=1)


# ===== Convert Command =====

@app.command()
def convert(
    input_path: str = typer.Argument(..., help="输入 YAML/JSON 文件路径"),
    output_path: str = typer.Argument(..., help="输出文件路径"),
    format: str = typer.Option("yaml", help="输出格式: yaml 或 json"),
):
    """
    在不同格式间转换配置文件。
    用于格式标准化和数据迁移。
    """
    input_file = Path(input_path)
    if not input_file.exists():
        console.print(f"[red]输入文件不存在: {input_path}[/red]")
        raise typer.Exit(code=1)
    
    try:
        # 读取输入
        with open(input_file, 'r', encoding='utf-8') as f:
            if input_path.endswith('.json'):
                data = json.load(f)
            else:
                data = yaml.safe_load(f)
        
        # 写入输出
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            if format.lower() == 'json':
                json.dump(data, f, indent=2, ensure_ascii=False)
            else:
                yaml.dump(data, f, allow_unicode=True, sort_keys=False)
        
        console.print(f"[green]已转换: {input_path} -> {output_path}[/green]")
        
    except Exception as e:
        console.print(f"[red]转换失败: {e}[/red]")
        raise typer.Exit(code=1)


# ===== Package Command =====

pack_app = typer.Typer()
app.add_typer(pack_app, name="pack", help="打包/解包配置")


@pack_app.command("create")
def pack_create(
    source_dir: str = typer.Argument(..., help="源目录路径（包含 YAML 文件）"),
    output: str = typer.Option("export.zip", help="输出 Zip 文件路径"),
):
    """
    将 YAML 配置目录打包为 Zip 包。
    """
    source_path = Path(source_dir)
    if not source_path.exists():
        console.print(f"[red]源目录不存在: {source_dir}[/red]")
        raise typer.Exit(code=1)
    
    try:
        output_file = Path(output)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with zipfile.ZipFile(output_file, 'w', zipfile.ZIP_DEFLATED) as zf:
            yaml_files = list(source_path.rglob("*.yaml")) + list(source_path.rglob("*.yml"))
            
            for file_path in yaml_files:
                rel_path = file_path.relative_to(source_path)
                zf.write(file_path, arcname=str(rel_path))
                console.print(f"  添加: {rel_path}")
        
        console.print(f"[green]已创建包: {output}[/green]")
        console.print(f"  共 {len(yaml_files)} 个 YAML 文件")
        
    except Exception as e:
        console.print(f"[red]打包失败: {e}[/red]")
        raise typer.Exit(code=1)


@pack_app.command("extract")
def pack_extract(
    package_path: str = typer.Argument(..., help="Zip 包路径"),
    output_dir: str = typer.Option("./extracted", help="输出目录"),
):
    """
    解压 Zip 包到目录。
    """
    package_file = Path(package_path)
    if not package_file.exists():
        console.print(f"[red]包文件不存在: {package_path}[/red]")
        raise typer.Exit(code=1)
    
    try:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        with zipfile.ZipFile(package_file, 'r') as zf:
            zf.extractall(output_path)
        
        console.print(f"[green]已解压到: {output_dir}[/green]")
        
    except Exception as e:
        console.print(f"[red]解压失败: {e}[/red]")
        raise typer.Exit(code=1)


# ===== Export Command =====

@app.command("export")
def export_package(
    source: str = typer.Argument(..., help="源数据路径（YAML 目录或 ZIP 包）"),
    output: str = typer.Option("export.zip", help="输出路径（.zip 文件或目录）"),
):
    """
    从已有 YAML 配置目录或 ZIP 包重建标准 Package。

    注意：
    1. 该命令不连接数据库，不负责从真实业务存储中导出数据。
    2. 若需要按 scope + user_id 从业务 store 导出，请在应用代码中调用
       PackageExporter.export_core_data(scope, export_user_id)。
    """
    source_path = Path(source)
    if not source_path.exists():
        console.print(f"[red]源路径不存在: {source}[/red]")
        raise typer.Exit(code=1)

    try:
        from turbo_agent_store.config_export import YAMLConfigStore, PackageExporter

        # 加载源数据
        if source_path.is_dir():
            store = YAMLConfigStore.from_dir(str(source_path))
        elif source_path.suffix in (".zip",):
            store = YAMLConfigStore.from_zip(str(source_path))
        else:
            console.print(f"[red]不支持的源格式，请使用目录或 .zip 文件[/red]")
            raise typer.Exit(code=1)

        summary = store.get_summary()
        scope = _infer_export_scope(store)

        exporter = PackageExporter(store=store)
        result = asyncio.run(exporter.export_core_data(scope=scope, export_user_id="package-repack"))
        _write_package_bytes(output, result.package_bytes)

        if source_path.is_dir():
            _copy_package_payload_from_dir(source_path, output)
        elif source_path.suffix in (".zip",):
            _copy_package_payload_from_zip(source_path, output)

        # 显示摘要
        table = Table(title="导出摘要")
        table.add_column("类型", style="cyan")
        table.add_column("数量", style="magenta", justify="right")

        for entity_type, count in summary.items():
            if count > 0:
                table.add_row(entity_type, str(count))

        console.print(table)
        console.print(f"[green]已导出到: {output}[/green]")

    except Exception as e:
        console.print(f"[red]导出失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        raise typer.Exit(code=1)


# ===== Info Command =====

@app.command("info")
def store_info(
    source: str = typer.Argument(..., help="YAML 配置目录或 ZIP 包路径"),
):
    """
    查看 Package 内容摘要（不执行加载，仅解析元数据）。
    """
    source_path = Path(source)
    if not source_path.exists():
        console.print(f"[red]路径不存在: {source}[/red]")
        raise typer.Exit(code=1)

    try:
        from turbo_agent_store.config_export import YAMLConfigStore

        if source_path.is_dir():
            store = YAMLConfigStore.from_dir(str(source_path))
        elif source_path.suffix in (".zip",):
            store = YAMLConfigStore.from_zip(str(source_path))
        else:
            console.print(f"[red]不支持的格式[/red]")
            raise typer.Exit(code=1)

        summary = store.get_summary()
        all_entities = store.get_all_entities()

        # 实体摘要表
        table = Table(title=f"Package 内容: {source}")
        table.add_column("类型", style="cyan")
        table.add_column("数量", style="magenta", justify="right")

        for entity_type, count in summary.items():
            if count > 0:
                table.add_row(entity_type, str(count))

        console.print(table)

        # 实体详情表
        if all_entities:
            detail_table = Table(title="实体列表")
            detail_table.add_column("类型", style="cyan")
            detail_table.add_column("ID", style="dim")
            detail_table.add_column("名称")
            detail_table.add_column("name_id", style="green")

            for entity in all_entities:
                detail_table.add_row(
                    entity.__class__.__name__,
                    getattr(entity, "id", "N/A"),
                    getattr(entity, "name", "N/A"),
                    getattr(entity, "name_id", getattr(entity, "name", "N/A")),
                )

            console.print(detail_table)

        console.print(f"[green]共 {len(all_entities)} 个实体[/green]")

    except Exception as e:
        console.print(f"[red]解析失败: {e}[/red]")
        import traceback
        traceback.print_exc()
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
