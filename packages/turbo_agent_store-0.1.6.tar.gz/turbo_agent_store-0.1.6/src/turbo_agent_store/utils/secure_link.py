"""secure_link 兼容导出。"""

from turbo_agent_store.files.file_manage.secure_link import generate_secure_link_signature

__all__ = ["generate_secure_link_signature"]
