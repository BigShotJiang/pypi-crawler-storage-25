import io
import json
import os
from boto3.session import Session
from botocore.config import Config
from turbo_agent_store.settings import settings
from prisma.enums import FileType,KnowledgeType
from loguru import logger
import mimetypes
import base64
import requests
import hashlib
import tempfile

def get_s3_client():
    endpoint = settings.TA_STORE_S3_ENDPOINT or None
    endpoint_url = endpoint
    if endpoint and not endpoint.startswith("http://") and not endpoint.startswith("https://"):
        scheme = "https" if settings.TA_STORE_S3_SECURE else "http"
        endpoint_url = f"{scheme}://{endpoint}"
    return Session().client(
        "s3",
        endpoint_url=endpoint_url,
        region_name=settings.TA_STORE_S3_REGION,
        aws_access_key_id=settings.TA_STORE_S3_ACCESS_KEY_ID or None,
        aws_secret_access_key=settings.TA_STORE_S3_SECRET_ACCESS_KEY or None,
        aws_session_token=settings.TA_STORE_S3_SESSION_TOKEN or None,
        use_ssl=settings.TA_STORE_S3_SECURE,
        config=Config(signature_version="s3v4", s3={"addressing_style": settings.TA_STORE_S3_ADDRESSING_STYLE}),
    )

PUBLIC_BUCKET = settings.TA_STORE_S3_PUBLIC_BUCKET
PRIVATE_BUCKET = settings.TA_STORE_S3_PRIVATE_BUCKET
COS_IMG_PREFIX = 'cos-img'
MODEL_SPACE_PREFIX = "model_space"
CHARACTER_PREFIX = "character"
TOOL_PREFIX = "tool"
PLATFORM_PREFIX = "platform"
ORGANIZATION_PREFIX = "organization"

class ImageTag:
    MODEL_SPACE = "model_space"
    CHARACTER = "character"
    TOOL = "tool"
    PLATFORM = "platform"
    ORGANIZATION = "organization"

def add_image_extension(file_name: str, image_bytes: bytes, origin_name: str):
    import imghdr
    ext = imghdr.what(None, h=image_bytes)
    segs = origin_name.split(".")
    filename_full = f"{file_name}.{segs[-1]}"
    if ext:
        filename_full = f"{file_name}.{ext}"
    logger.info(f"image info: {filename_full}, ext: {ext}")
    return filename_full, ext

def upload_image_to_cos(file_name: str, image_tag: str, file_path: str, user_id: str):
    if not user_id:
        raise Exception("unauthorized")
    s3_client = get_s3_client()
    with open(file_path, "rb") as f:
        image_bytes = f.read()
    filename_full, ext = add_image_extension(file_name, image_bytes, os.path.basename(file_path))
    if image_tag == ImageTag.CHARACTER:
        image_key = f"{COS_IMG_PREFIX}/{user_id}/{CHARACTER_PREFIX}/{filename_full}"
    elif image_tag == ImageTag.MODEL_SPACE:
        image_key = f"{COS_IMG_PREFIX}/{user_id}/{MODEL_SPACE_PREFIX}/{filename_full}"
    elif image_tag == ImageTag.PLATFORM:
        image_key = f"{COS_IMG_PREFIX}/{user_id}/{PLATFORM_PREFIX}/{filename_full}"
    elif image_tag == ImageTag.TOOL:
        image_key = f"{COS_IMG_PREFIX}/{user_id}/{TOOL_PREFIX}/{filename_full}"
    elif image_tag == ImageTag.ORGANIZATION:
        image_key = f"{COS_IMG_PREFIX}/{user_id}/{ORGANIZATION_PREFIX}/{filename_full}"
    else:
        raise Exception("imageTag not Matched")
    content_type = mimetypes.guess_type(filename_full)[0] or 'application/octet-stream'
    s3_client.upload_file(file_path, PUBLIC_BUCKET, image_key, ExtraArgs={"ContentType": content_type})
    url = f"/{PUBLIC_BUCKET}/{image_key}"
    logger.info(f"uploaded image url: {url}")
    return url

def upload_image_url_to_cos(file_name: str, image_url: str, image_tag: str, file_extension: str, user_id: str):
    if not user_id:
        raise Exception("unauthorized")
    s3_client = get_s3_client()
    if image_url.startswith('data:image/'):
        # 解析 base64
        header, base64_data = image_url.split(',', 1)
        mime_type = header.split(';')[0].split(':')[1]
        image_bytes = base64.b64decode(base64_data)
        ext = mime_type.split('/')[-1] or file_extension or 'png'
        filename_full = f"{file_name}.{ext}"
        if image_tag == ImageTag.CHARACTER:
            image_key = f"{COS_IMG_PREFIX}/{user_id}/{CHARACTER_PREFIX}/{filename_full}"
        elif image_tag == ImageTag.MODEL_SPACE:
            image_key = f"{COS_IMG_PREFIX}/{user_id}/{MODEL_SPACE_PREFIX}/{filename_full}"
        elif image_tag == ImageTag.PLATFORM:
            image_key = f"{COS_IMG_PREFIX}/{user_id}/{PLATFORM_PREFIX}/{filename_full}"
        elif image_tag == ImageTag.TOOL:
            image_key = f"{COS_IMG_PREFIX}/{user_id}/{TOOL_PREFIX}/{filename_full}"
        elif image_tag == ImageTag.ORGANIZATION:
            image_key = f"{COS_IMG_PREFIX}/{user_id}/{ORGANIZATION_PREFIX}/{filename_full}"
        else:
            raise Exception("imageTag not Matched")
        s3_client.put_object(
            Bucket=PUBLIC_BUCKET,
            Key=image_key,
            Body=image_bytes,
            ContentType=mime_type,
        )
        url = f"/{PUBLIC_BUCKET}/{image_key}"
        logger.info(f"uploaded base64 image url: {url}")
        return url
    # 普通 url
    # base file name
    
    filename_full = f"{file_name}.{file_extension}"
    response = requests.get(image_url)
    if response.status_code != 200:
        raise Exception(f"Failed to download image: {image_url}")
    image_bytes = response.content
    if image_tag == ImageTag.CHARACTER:
        image_key = f"{COS_IMG_PREFIX}/{user_id}/{CHARACTER_PREFIX}/{filename_full}"
    elif image_tag == ImageTag.MODEL_SPACE:
        image_key = f"{COS_IMG_PREFIX}/{user_id}/{MODEL_SPACE_PREFIX}/{filename_full}"
    elif image_tag == ImageTag.PLATFORM:
        image_key = f"{COS_IMG_PREFIX}/{user_id}/{PLATFORM_PREFIX}/{filename_full}"
    elif image_tag == ImageTag.TOOL:
        image_key = f"{COS_IMG_PREFIX}/{user_id}/{TOOL_PREFIX}/{filename_full}"
    elif image_tag == ImageTag.ORGANIZATION:
        image_key = f"{COS_IMG_PREFIX}/{user_id}/{ORGANIZATION_PREFIX}/{filename_full}"
    else:
        raise Exception("imageTag not Matched")
    content_type = mimetypes.guess_type(filename_full)[0] or 'application/octet-stream'
    s3_client.put_object(
        Bucket=PUBLIC_BUCKET,
        Key=image_key,
        Body=image_bytes,
        ContentType=content_type,
    )
    url = f"/{PUBLIC_BUCKET}/{image_key}"
    logger.info(f"uploaded image url: {url}")
    return url

# 从PRIVATE_BUCKET下载文件或者从PUBLIC_BUCKET下载文件 到临时路径
def download_file_from_cos(file_uri: str, private: bool = False):
    # if not user_id:
    #     raise Exception("unauthorized")
    s3_client = get_s3_client()
    bucket = PRIVATE_BUCKET if private else PUBLIC_BUCKET
    try:
        if file_uri.startswith('/'+bucket+'/'):
            # 如果是以 /bucket/ 开头，则去掉前缀
            file_key = file_uri[len('/'+bucket+'/'):]
        else:
            # 否则直接使用 file_uri 作为 file_key
            file_key = file_uri
        # 下载文件 到临时路径
        temp_file_path = tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(file_key)[-1]).name

        response = s3_client.get_object(Bucket=bucket, Key=file_key)
        file_content = response["Body"].read()
        # 将文件内容写入临时文件
        with open(temp_file_path, 'wb') as f:
            f.write(file_content)
        return temp_file_path
    except Exception as e:
        logger.error(f"Error downloading file from COS: {e}")
        raise Exception(f"Failed to download file: {file_key} from bucket: {bucket}  exception: {e}")

def upload_knowledge_file_to_cos(file_path: str, file_id: str, knowledge_type: KnowledgeType, user_id: str):
    if not user_id:
        raise Exception("unauthorized")
    # 取 file_path 的basename
    file_name = os.path.basename(file_path)
    #取file 内容 做hash 作为key
    file_hash = hashlib.md5(open(file_path, 'rb').read()).hexdigest().encode()
    file_key = f"{user_id}/knowledge/{knowledge_type.value}/{file_id}/{file_name}"
    s3_client = get_s3_client()
    content_type = mimetypes.guess_type(file_path)[0] or 'application/octet-stream'
    with open(file_path, 'rb') as f:
        file_bytes = f.read()
        s3_client.put_object(
            Bucket=PRIVATE_BUCKET,
            Key=file_key,
            Body=file_bytes,
            ContentType=content_type,
        )
    # 可根据 file_extension 处理不同类型文件上传
    return {
        "id": file_id,
        "file_key": file_key,
        "file_name": file_name,
        "file_hash": file_hash,
        "content_type": content_type
    }

def upload_docling_doc_json_to_cos(docling_json:dict, file_id: str, user_id: str):
    if not user_id:
        raise Exception("unauthorized")
    # 取 file_path 的basename
    file_key = f"{user_id}/docling/{file_id}.json"
    s3_client = get_s3_client()
    content_type = 'application/json'
    file_bytes = json.dumps(docling_json).encode('utf-8')
    s3_client.put_object(Bucket=PRIVATE_BUCKET, Key=file_key, Body=file_bytes, ContentType=content_type)
    # 可根据 file_extension 处理不同类型文件上传
    return {
        "id": file_id,
        "file_key": file_key
    }

def get_docling_doc_json_from_cos(file_id: str, user_id: str):
    if not user_id:
        raise Exception("unauthorized")
    file_key = f"{user_id}/docling/{file_id}.json"
    s3_client = get_s3_client()
    try:
        response = s3_client.get_object(Bucket=PRIVATE_BUCKET, Key=file_key)
        file_content = response["Body"].read()
        return file_content
    except Exception as e:
        logger.error(f"Error downloading file from COS: {e}")
        raise Exception(f"Failed to download file: {file_key} from bucket: {PRIVATE_BUCKET}  exception: {e}")

def upload_workset_file_to_cos(file_path: str, file_id: str, user_id: str):
    if not user_id:
        raise Exception("unauthorized")
    # 取 file_path 的basename
    file_name = os.path.basename(file_path)

    #取file 内容 做hash 作为key
    file_hash = hashlib.md5(open(file_path, 'rb').read()).hexdigest().encode()
    file_key = f"{user_id}/workset/{file_id}/{file_name}"
    s3_client = get_s3_client()
    content_type = mimetypes.guess_type(file_path)[0] or 'application/octet-stream'
    with open(file_path, 'rb') as f:
        file_bytes = f.read()
        #计算hash字符串
        # 计算文件的哈希值
        file_hash = hashlib.md5(file_bytes).hexdigest().encode()
        # 生成文件的唯一键
        file_key = f"{user_id}/workset/{file_hash}/{file_name}"
        s3_client.put_object(
            Bucket=PRIVATE_BUCKET,
            Key=file_key,
            Body=file_bytes,
            ContentType=content_type,
        )

    # 可根据 file_extension 处理不同类型文件上传
    return {
        "id": file_id,
        "file_key": file_key,
        "file_name": file_name,
        "file_hash": file_hash,
        "content_type": content_type
    }
