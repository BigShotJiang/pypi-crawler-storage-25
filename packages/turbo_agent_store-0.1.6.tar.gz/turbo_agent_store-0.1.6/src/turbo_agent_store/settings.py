import os
from pathlib import Path

from dotenv import load_dotenv
from pydantic_settings import BaseSettings, SettingsConfigDict
from pytz import timezone

# Load .env with a minimal, command-dir-first strategy.
# 优先顺序：仅当前工作目录 .env（运行命令所在目录）
_cwd_env_path = Path(os.getcwd()) / ".env"

if _cwd_env_path.exists():
    load_dotenv(dotenv_path=_cwd_env_path)
    

class Settings(BaseSettings):
    DATABASE_URL: str
    DOCLING_SERVER: str
    DOCLING_API_KEY: str
    # Manticore Search 配置
    MANTICORE_HOST: str = "http://127.0.0.1:9308"
    MANTICORE_API_KEY: str = ""

    # 索引名称 (支持 Meilisearch 和 Manticore)
    # 行为记录索引名称, 用于存储工具调用的行为记录
    MANTICORE_ACTION_INDEX: str = "turboagent_action_records"
    # RAG 知识库索引名称
    MANTICORE_KNOWLEDGE_INDEX: str = "turboagent_knowledge"
    # 工作集索引名称, 用于存储对话产生的上下文
    MANTICORE_WORKSET_INDEX: str = "turboagent_workset"
    # 测试阶段可选：强制每次初始化前删除并重建索引
    MANTICORE_FORCE_RECREATE: bool = False
    # 调试：创建或获取索引时是否输出 DESCRIBE 结果 (DEBUG 级别)
    MANTICORE_LOG_DESCRIBE: bool = True
    # JSON 检查模型配置，用于验证 并修正 JSON 格式
    CHUNCK_MODEL: str
    CHUNCK_MODEL_API_KEY: str
    CHUNCK_MODEL_API_URL: str
    EMBEDDING_DIM: int = 1024  # 向量维度，默认1024，可在 .env 中配置，如 1536, 2048 等

    # 文件管理后端选择：local | s3
    TA_STORE_FILE_BACKEND: str = "local"

    # S3 环境变量统一遵守 TA_STORE 前缀规范
    TA_STORE_S3_ENDPOINT: str = ""
    TA_STORE_S3_REGION: str = "us-east-1"
    TA_STORE_S3_ACCESS_KEY_ID: str = ""
    TA_STORE_S3_SECRET_ACCESS_KEY: str = ""
    TA_STORE_S3_SESSION_TOKEN: str = ""
    TA_STORE_S3_SECURE: bool = True
    TA_STORE_S3_ADDRESSING_STYLE: str = "path"
    TA_STORE_S3_PRIVATE_BUCKET: str = "turbo-agent-private"
    TA_STORE_S3_PUBLIC_BUCKET: str = "turbo-agent-public"

    # 外部访问地址（可走 Nginx 反向代理）
    # 例如：TA_STORE_EXTERNAL_BASE_URL=https://files.example.com
    #      TA_STORE_EXTERNAL_PATH_PREFIX=/files
    TA_STORE_EXTERNAL_BASE_URL: str = ""
    TA_STORE_EXTERNAL_PATH_PREFIX: str = ""
    TA_STORE_SECURE_LINK_SECRET: str = ""

    # 本地文件系统 file manager 配置
    TA_STORE_LOCAL_BASE_PATH: str = "/tmp/turbo_agent/file_manage"

    # 文件缓存 TTL 配置
    TA_STORE_CACHE_TTL_META_AVATAR_SECONDS: int = 604800
    TA_STORE_CACHE_TTL_OTHER_IMAGE_SECONDS: int = 86400
    TA_STORE_CACHE_TTL_DEFAULT_SECONDS: int = 3600

    TIMEZONE: str = "Asia/Shanghai"

    # 允许 .env 中存在未定义的额外变量（如 Redis 配置），避免 pydantic 报错
    # 禁用 pydantic 自带的 env_file 加载，完全依赖上方手工加载的 cwd/.env 或进程环境
    model_config = SettingsConfigDict(
        env_file=None,
        extra="ignore",
    )

settings = Settings()
tz = timezone(settings.TIMEZONE)
