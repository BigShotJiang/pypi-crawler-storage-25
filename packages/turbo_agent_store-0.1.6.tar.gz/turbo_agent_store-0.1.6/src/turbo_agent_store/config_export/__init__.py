"""
YAML 实现层

用于基于 core schema 的结构化导出/导入。
适用于：
- 配置备份与恢复
- 跨环境数据迁移
- 版本控制友好的配置管理
- 基于 Package 的 Store 接口实现（Worker 节点、桌面/具身客户端、测试）

主要组件：
- YAMLConfigStore: 基于 YAML Package 的 TurboEntityStore + ExternalStore 完整实现
- PackageExporter: 通过 export_core_data(scope, export_user_id) 导出标准 ZIP 包
- CoreDataExportScope / CoreDataExportResult: 导出作用域与结果模型
- PackageManifest / PackageMetadata: 包结构元数据模型
"""

from .config import YAMLConfigStore
from .exporter import PackageExporter
from .models import CoreDataExportResult, CoreDataExportScope, PackageAsset, PackageManifest, PackageMetadata

__all__ = [
    "YAMLConfigStore",
    "PackageExporter",
    "CoreDataExportScope",
    "CoreDataExportResult",
    "PackageAsset",
    "PackageManifest",
    "PackageMetadata",
]
