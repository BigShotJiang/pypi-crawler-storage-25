"""
PackageExporter - 实体整包导出器

支持导出：
- TurboEntity 及其依赖（Agent / Character / Tool / Model）
- 业务配置（BusinessSetting / KnowledgeResource / Project）
- 外部平台配置（Platform / AuthMethod / Secret / MCP）
- 关联资源文件（知识资源原文件、头像、平台图片）

最终输出为一个带有配置清单和资源目录的压缩包或目录。
"""

from __future__ import annotations

import json
import io
import mimetypes
import os
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import yaml
from loguru import logger

from turbo_agent_core.schema.agents import (
    Agent,
    APITool,
    AgentTool,
    BasicAgent,
    Character,
    LLMModel,
    LLMTool,
    MCPTool,
    Tool,
)
from turbo_agent_core.schema.external import (
    AuthMethod,
    McpResourceDescriptor,
    McpServerSpec,
    Platform,
    Secret,
)
from turbo_agent_core.schema.resources import BusinessSetting, KnowledgeResource, Project

from turbo_agent_store.interface.entity import TurboEntityLocator, TurboEntityStore
from turbo_agent_store.interface.external import ExternalStore
from turbo_agent_store.interface.resource import ResourceEntityStore, ResourceStore

from .models import CoreDataExportResult, CoreDataExportScope, PackageAsset, PackageManifest, PackageMetadata


def _entity_to_dict(entity: Any) -> Dict[str, Any]:
    if hasattr(entity, "model_dump"):
        return entity.model_dump(mode="json", exclude_none=True)
    if hasattr(entity, "dict"):
        return entity.dict(exclude_none=True)
    return {}


def _is_remote_uri(uri: Optional[str]) -> bool:
    if not uri:
        return False
    return uri.startswith("http://") or uri.startswith("https://")


class PackageExporter:
    """实体整包导出器。

    对外正式入口仅保留：
    - export_core_data(scope, export_user_id)

    其余 `_add_*` / `_collect_*` / `_build_*` 方法均为内部实现细节。
    """

    def __init__(
        self,
        store: Optional[Any] = None,
        entity_store: Optional[TurboEntityStore] = None,
        external_store: Optional[ExternalStore] = None,
        resource_entity_store: Optional[ResourceEntityStore] = None,
        resource_store: Optional[ResourceStore] = None,
    ):
        if store is not None:
            if entity_store is None and isinstance(store, TurboEntityStore):
                entity_store = store
            if external_store is None and isinstance(store, ExternalStore):
                external_store = store
            if resource_entity_store is None and isinstance(store, ResourceEntityStore):
                resource_entity_store = store
            if resource_store is None and isinstance(store, ResourceStore):
                resource_store = store

        self._entity_store = entity_store
        self._external_store = external_store
        self._resource_entity_store = resource_entity_store
        self._resource_store = resource_store

        self._agents: Dict[str, Dict[str, Any]] = {}
        self._characters: Dict[str, Dict[str, Any]] = {}
        self._tools: Dict[str, Dict[str, Any]] = {}
        self._models: Dict[str, Dict[str, Any]] = {}
        self._platforms: Dict[str, Dict[str, Any]] = {}
        self._auth_methods: Dict[str, Dict[str, Any]] = {}
        self._secrets: Dict[str, Dict[str, Any]] = {}
        self._knowledge_resources: Dict[str, Dict[str, Any]] = {}
        self._business_settings: Dict[str, Dict[str, Any]] = {}
        self._mcp_servers: Dict[str, Dict[str, Any]] = {}
        self._mcp_resources: Dict[str, Dict[str, Any]] = {}
        self._projects: Dict[str, Dict[str, Any]] = {}

        self._assets: Dict[str, bytes] = {}
        self._asset_entries: Dict[str, PackageAsset] = {}
        self._dep_graph: Dict[str, List[str]] = {}
        self._visited: Set[Tuple[str, str]] = set()

    async def export_core_data(
        self,
        scope: CoreDataExportScope,
        export_user_id: str,
    ) -> CoreDataExportResult:
        """唯一对外入口：按作用域导出核心数据为 zip 包。"""
        self._reset_state()
        await self._add_scope(
            scope_type=scope.scope_type,
            user_id=export_user_id,
            space_name=scope.space_name,
            project_name_id=scope.project_name_id,
            entity_type=scope.entity_type,
            entity_id=scope.entity_id,
            name_id=scope.name_id,
            version_tag=scope.version_tag,
            series_name=scope.series_name,
        )

        package_name = scope.build_package_name()
        manifest = self._build_manifest()
        metadata = self._build_metadata(
            name=package_name,
            created_by=export_user_id,
            description=f"core_data_export:{scope.scope_type}",
        )
        package_bytes = self._build_zip_bytes(manifest=manifest, metadata=metadata)
        return CoreDataExportResult(
            package_name=package_name,
            filename=f"{package_name}.zip",
            package_bytes=package_bytes,
            manifest=manifest.model_dump(mode="json"),
            metadata=metadata.model_dump(mode="json"),
            summary=self.get_summary(),
        )

    def _reset_state(self):
        self._agents.clear()
        self._characters.clear()
        self._tools.clear()
        self._models.clear()
        self._platforms.clear()
        self._auth_methods.clear()
        self._secrets.clear()
        self._knowledge_resources.clear()
        self._business_settings.clear()
        self._mcp_servers.clear()
        self._mcp_resources.clear()
        self._projects.clear()
        self._assets.clear()
        self._asset_entries.clear()
        self._dep_graph.clear()
        self._visited.clear()

    async def _add_agent(
        self,
        locator: Optional[TurboEntityLocator] = None,
        agent: Optional[Agent] = None,
        user_id: Optional[str] = None,
    ):
        if agent is None and locator is not None and self._entity_store:
            agent = await self._entity_store.get_agent_runnable(locator, user_id=user_id)
        if agent is None:
            logger.warning("未找到 Agent 或未提供有效数据")
            return
        await self._collect_agent(agent, user_id=user_id)

    async def _add_tool(
        self,
        locator: Optional[TurboEntityLocator] = None,
        tool: Optional[Tool] = None,
        user_id: Optional[str] = None,
    ):
        if tool is None and locator is not None and self._entity_store:
            tool = await self._entity_store.get_tool_runnable(locator, user_id=user_id)
        if tool is None:
            logger.warning("未找到 Tool 或未提供有效数据")
            return
        await self._collect_tool(tool, user_id=user_id)

    async def _add_character(
        self,
        locator: Optional[TurboEntityLocator] = None,
        character: Optional[Character] = None,
        user_id: Optional[str] = None,
    ):
        if character is None and locator is not None and self._entity_store:
            character = await self._entity_store.get_character_runnable(locator, user_id=user_id)
        if character is None:
            logger.warning("未找到 Character 或未提供有效数据")
            return
        await self._collect_character(character, user_id=user_id)

    async def _add_model(
        self,
        locator: Optional[TurboEntityLocator] = None,
        model: Optional[LLMModel] = None,
        user_id: Optional[str] = None,
    ):
        if model is None and locator is not None and self._entity_store:
            model = await self._entity_store.get_model_runnable(locator, user_id=user_id)
        if model is None:
            logger.warning("未找到 LLMModel 或未提供有效数据")
            return
        await self._collect_model(model)

    async def _add_platform(
        self,
        platform_id: Optional[str] = None,
        platform: Optional[Platform] = None,
        user_id: Optional[str] = None,
    ):
        if platform is None and platform_id and self._external_store:
            platform = await self._external_store.get_platform(platform_id, user_id=user_id)
        if platform is None:
            logger.warning("未找到 Platform 或未提供有效数据")
            return
        await self._collect_platform(platform, user_id=user_id)

    async def _add_scope(
        self,
        scope_type: str,
        user_id: Optional[str] = None,
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        entity_type: Optional[str] = None,
        entity_id: Optional[str] = None,
        name_id: Optional[str] = None,
        version_tag: Optional[str] = None,
        series_name: Optional[str] = None,
    ):
        """按导出范围收集实体。"""
        if scope_type == "space":
            if not space_name:
                raise ValueError("space 范围导出必须提供 space_name")
            await self._add_space_scope(space_name=space_name, user_id=user_id)
            return

        if scope_type == "project":
            if not space_name or not project_name_id:
                raise ValueError("project 范围导出必须提供 space_name 和 project_name_id")
            await self._add_project_scope(space_name=space_name, project_name_id=project_name_id, user_id=user_id)
            return

        if scope_type == "entity":
            if not entity_type:
                raise ValueError("entity 范围导出必须提供 entity_type")
            await self._add_single_entity(
                entity_type=entity_type,
                user_id=user_id,
                space_name=space_name,
                project_name_id=project_name_id,
                entity_id=entity_id,
                name_id=name_id,
                version_tag=version_tag,
                series_name=series_name,
            )
            return

        raise ValueError(f"不支持的 scope_type: {scope_type}")

    async def _add_space_scope(self, space_name: str, user_id: Optional[str] = None):
        """导出整个 space 范围。"""
        project_name_ids = await self._list_project_name_ids_in_space(space_name=space_name, user_id=user_id)
        for project_name_id in project_name_ids:
            await self._add_project_scope(space_name=space_name, project_name_id=project_name_id, user_id=user_id)

        if self._entity_store:
            models = await self._entity_store.list_models(
                space_name=space_name,
                project_name_id=None,
                skip=0,
                limit=1000,
                user_id=user_id,
            )
            for model in models:
                locator = TurboEntityLocator(
                    space_name=space_name,
                    project_name_id=None,
                    name_id=model.name_id,
                    series_name=getattr(model, "series_name", None),
                )
                await self._add_model(locator=locator, user_id=user_id)

    async def _add_project_scope(self, space_name: str, project_name_id: str, user_id: Optional[str] = None):
        """导出单个 project 范围。"""
        await self._collect_project_record(space_name=space_name, project_name_id=project_name_id, user_id=user_id)

        if not self._entity_store:
            return

        agents = await self._entity_store.list_agents(
            space_name=space_name,
            project_name_id=project_name_id,
            skip=0,
            limit=1000,
            user_id=user_id,
        )
        for agent in agents:
            await self._add_agent(
                locator=TurboEntityLocator(space_name=space_name, project_name_id=project_name_id, name_id=agent.name_id),
                user_id=user_id,
            )

        characters = await self._entity_store.list_characters(
            space_name=space_name,
            project_name_id=project_name_id,
            skip=0,
            limit=1000,
            user_id=user_id,
        )
        for character in characters:
            await self._add_character(
                locator=TurboEntityLocator(
                    space_name=space_name,
                    project_name_id=project_name_id,
                    name_id=character.name_id,
                    version_tag=getattr(character, "version_tag", None),
                ),
                user_id=user_id,
            )

        tools = await self._entity_store.list_tools(
            space_name=space_name,
            project_name_id=project_name_id,
            skip=0,
            limit=1000,
            user_id=user_id,
        )
        for tool in tools:
            await self._add_tool(
                locator=TurboEntityLocator(
                    space_name=space_name,
                    project_name_id=project_name_id,
                    name_id=tool.name_id,
                    version_tag=getattr(tool, "version_tag", None),
                ),
                user_id=user_id,
            )

        models = await self._entity_store.list_models(
            space_name=space_name,
            project_name_id=project_name_id,
            skip=0,
            limit=1000,
            user_id=user_id,
        )
        for model in models:
            await self._add_model(
                locator=TurboEntityLocator(
                    space_name=space_name,
                    project_name_id=project_name_id,
                    name_id=model.name_id,
                    series_name=getattr(model, "series_name", None),
                ),
                user_id=user_id,
            )

    async def _add_single_entity(
        self,
        entity_type: str,
        user_id: Optional[str] = None,
        space_name: Optional[str] = None,
        project_name_id: Optional[str] = None,
        entity_id: Optional[str] = None,
        name_id: Optional[str] = None,
        version_tag: Optional[str] = None,
        series_name: Optional[str] = None,
    ):
        """导出单个实体及其依赖。"""
        entity_type = entity_type.lower()

        if entity_type in {"agent", "character", "tool", "model"}:
            if not space_name:
                raise ValueError(f"导出 {entity_type} 时必须提供 space_name")
            locator = TurboEntityLocator(
                space_name=space_name,
                project_name_id=project_name_id,
                name_id=name_id,
                version_tag=version_tag,
                series_name=series_name,
            )
            if entity_type == "agent":
                await self._add_agent(locator=locator, user_id=user_id)
            elif entity_type == "character":
                await self._add_character(locator=locator, user_id=user_id)
            elif entity_type == "tool":
                await self._add_tool(locator=locator, user_id=user_id)
            elif entity_type == "model":
                await self._add_model(locator=locator, user_id=user_id)
            return

        if entity_type == "platform":
            if not entity_id:
                raise ValueError("导出 platform 时必须提供 entity_id")
            await self._add_platform(platform_id=entity_id, user_id=user_id)
            return

        if entity_type == "project":
            if entity_id:
                project = await self._get_project_by_id(entity_id=entity_id, user_id=user_id)
                if not project:
                    raise ValueError(f"未找到 project: {entity_id}")
                self._projects[project.id] = _entity_to_dict(project)
                avatar_path = await self._collect_project_avatar(project)
                if avatar_path:
                    self._projects[project.id]["avatarUrl"] = avatar_path
                return
            if not space_name or not project_name_id:
                raise ValueError("导出 project 时需提供 entity_id，或同时提供 space_name + project_name_id")
            await self._add_project_scope(space_name=space_name, project_name_id=project_name_id, user_id=user_id)
            return

        if entity_type == "knowledge_resource":
            if not entity_id:
                raise ValueError("导出 knowledge_resource 时必须提供 entity_id")
            knowledge = await self._get_knowledge_by_id(resource_id=entity_id, user_id=user_id)
            if not knowledge:
                raise ValueError(f"未找到 knowledge_resource: {entity_id}")
            await self._collect_knowledge_resource(knowledge, user_id=user_id)
            return

        if entity_type == "business_setting":
            if not entity_id:
                raise ValueError("导出 business_setting 时必须提供 entity_id")
            setting = await self._get_setting_by_id(setting_id=entity_id, user_id=user_id)
            if not setting:
                raise ValueError(f"未找到 business_setting: {entity_id}")
            await self._collect_business_setting(setting, user_id=user_id)
            return

        if entity_type == "secret":
            if not entity_id:
                raise ValueError("导出 secret 时必须提供 entity_id")
            secret = await self._get_secret_by_id(secret_id=entity_id, user_id=user_id)
            if not secret:
                raise ValueError(f"未找到 secret: {entity_id}")
            await self._collect_secret(secret)
            return

        if entity_type == "auth_method":
            if not entity_id or not self._external_store:
                raise ValueError("导出 auth_method 时必须提供 entity_id")
            auth_method = await self._external_store.get_auth_method(entity_id, user_id=user_id)
            if not auth_method:
                raise ValueError(f"未找到 auth_method: {entity_id}")
            await self._collect_auth_method(auth_method)
            return

        if entity_type == "mcp_server":
            if not entity_id or not self._external_store:
                raise ValueError("导出 mcp_server 时必须提供 entity_id")
            server = await self._external_store.get_mcp_server(entity_id, user_id=user_id)
            if not server:
                raise ValueError(f"未找到 mcp_server: {entity_id}")
            await self._collect_mcp_server(server)
            return

        if entity_type == "mcp_resource":
            if not entity_id or not self._external_store:
                raise ValueError("导出 mcp_resource 时必须提供 entity_id")
            resource = await self._external_store.get_mcp_resource(entity_id, user_id=user_id)
            if not resource:
                raise ValueError(f"未找到 mcp_resource: {entity_id}")
            await self._collect_mcp_resource(resource)
            return

        raise ValueError(f"不支持的 entity_type: {entity_type}")

    def _add_entity(self, entity: Any):
        """用于已有完整对象图的场景，直接记录显式对象。"""
        if isinstance(entity, Agent):
            self._agents[entity.id] = self._serialize_agent(entity)
        elif isinstance(entity, Character):
            self._characters[entity.id] = self._serialize_character(entity)
        elif isinstance(entity, Tool):
            self._tools[entity.id] = self._serialize_tool(entity)
        elif isinstance(entity, LLMModel):
            self._models[entity.id] = _entity_to_dict(entity)
        elif isinstance(entity, Platform):
            self._platforms[entity.id] = self._serialize_platform(entity)
        elif isinstance(entity, AuthMethod):
            self._auth_methods[entity.id] = _entity_to_dict(entity)
        elif isinstance(entity, Secret):
            self._secrets[entity.id] = self._serialize_secret(entity)
        elif isinstance(entity, KnowledgeResource):
            self._knowledge_resources[entity.id] = self._serialize_knowledge(entity)
        elif isinstance(entity, BusinessSetting):
            self._business_settings[entity.id] = self._serialize_setting(entity)
        elif isinstance(entity, McpServerSpec):
            self._mcp_servers[entity.id] = _entity_to_dict(entity)
        elif isinstance(entity, McpResourceDescriptor):
            self._mcp_resources[entity.id] = _entity_to_dict(entity)
        elif isinstance(entity, Project):
            self._projects[entity.id] = _entity_to_dict(entity)

    def _add_project(self, project: Project):
        self._projects[project.id] = _entity_to_dict(project)

    async def _collect_agent(self, agent: Agent, user_id: Optional[str] = None):
        visit_key = ("agent", agent.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)

        deps: List[str] = []
        await self._collect_project_by_belong(getattr(agent, "belongToProjectId", None), user_id=user_id)
        await self._collect_avatar_file(
            owner_type="agent",
            owner_id=agent.id,
            field_name="avatar_uri",
            source_uri=getattr(agent, "avatar_uri", None),
            target_name=getattr(agent, "name_id", agent.id),
        )

        if agent.model:
            await self._collect_model(agent.model)
            deps.append(agent.model.id)

        if agent.setting:
            await self._collect_business_setting(agent.setting, user_id=user_id)
            deps.append(agent.setting.id)

        for tool in agent.tools or []:
            await self._collect_tool(tool, user_id=user_id)
            deps.append(tool.id)

        for character in getattr(agent, "actAsCharacters", None) or []:
            await self._collect_character(character, user_id=user_id)
            deps.append(character.id)

        for assistant in getattr(agent, "assistantAgents", None) or []:
            await self._collect_agent(assistant, user_id=user_id)
            deps.append(assistant.id)

        for secret in getattr(agent, "accountSecrets", None) or []:
            await self._collect_secret(secret)
            deps.append(secret.id)

        self._agents[agent.id] = self._serialize_agent(agent)
        self._dep_graph[agent.id] = deps

    async def _collect_character(self, character: Character, user_id: Optional[str] = None):
        visit_key = ("character", character.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)

        deps: List[str] = []
        await self._collect_project_by_belong(getattr(character, "belongToProjectId", None), user_id=user_id)
        await self._collect_avatar_file(
            owner_type="character",
            owner_id=character.id,
            field_name="avatar_uri",
            source_uri=getattr(character, "avatar_uri", None),
            target_name=getattr(character, "name_id", character.id),
        )

        if character.model:
            await self._collect_model(character.model)
            deps.append(character.model.id)

        if character.setting:
            await self._collect_business_setting(character.setting, user_id=user_id)
            deps.append(character.setting.id)

        for tool in character.tools or []:
            await self._collect_tool(tool, user_id=user_id)
            deps.append(tool.id)

        self._characters[character.id] = self._serialize_character(character)
        self._dep_graph[character.id] = deps

    async def _collect_tool(self, tool: Tool, user_id: Optional[str] = None):
        visit_key = ("tool", tool.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)

        deps: List[str] = []
        await self._collect_project_by_belong(getattr(tool, "belongToProjectId", None), user_id=user_id)
        await self._collect_avatar_file(
            owner_type="tool",
            owner_id=tool.id,
            field_name="avatar_uri",
            source_uri=getattr(tool, "avatar_uri", None),
            target_name=getattr(tool, "name_id", tool.id),
        )

        if isinstance(tool, APITool) and tool.platform:
            await self._collect_platform(tool.platform, user_id=user_id)
            deps.append(tool.platform.id)

        if isinstance(tool, LLMTool) and tool.model:
            await self._collect_model(tool.model)
            deps.append(tool.model.id)
        if isinstance(tool, (LLMTool, AgentTool)) and getattr(tool, "setting", None):
            await self._collect_business_setting(tool.setting, user_id=user_id)
            deps.append(tool.setting.id)

        if isinstance(tool, AgentTool) and tool.backendAgent:
            await self._collect_agent(tool.backendAgent, user_id=user_id)
            deps.append(tool.backendAgent.id)

        if isinstance(tool, MCPTool):
            if tool.server:
                await self._collect_mcp_server(tool.server)
                deps.append(tool.server.id)
            if tool.resource:
                await self._collect_mcp_resource(tool.resource)
                deps.append(tool.resource.id)
            if tool.platform:
                await self._collect_platform(tool.platform, user_id=user_id)
                deps.append(tool.platform.id)

        self._tools[tool.id] = self._serialize_tool(tool)
        self._dep_graph[tool.id] = deps

    async def _collect_model(self, model: LLMModel):
        visit_key = ("model", model.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)

        await self._collect_project_by_belong(getattr(model, "belongToProjectId", None), user_id=None)
        await self._collect_avatar_file(
            owner_type="model",
            owner_id=model.id,
            field_name="avatar_uri",
            source_uri=getattr(model, "avatar_uri", None),
            target_name=getattr(model, "name_id", model.id),
        )

        model_data = _entity_to_dict(model)
        model_data["avatar_uri"] = self._packaged_field("model", model.id, "avatar_uri", model_data.get("avatar_uri"))
        self._models[model.id] = model_data
        self._dep_graph[model.id] = []

    async def _collect_platform(self, platform: Platform, user_id: Optional[str] = None):
        visit_key = ("platform", platform.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)

        deps: List[str] = []
        await self._collect_platform_image(platform)

        for auth_method in platform.authMethods or []:
            await self._collect_auth_method(auth_method)
            deps.append(auth_method.id)

        for secret in platform.secrets or []:
            await self._collect_secret(secret)
            deps.append(secret.id)
            if secret.authMethodId and self._external_store:
                auth_method = await self._external_store.get_auth_method(secret.authMethodId, user_id=user_id)
                if auth_method:
                    await self._collect_auth_method(auth_method)
                    deps.append(auth_method.id)

        self._platforms[platform.id] = self._serialize_platform(platform)
        self._dep_graph[platform.id] = deps

    async def _collect_secret(self, secret: Secret):
        visit_key = ("secret", secret.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)

        deps: List[str] = []
        if secret.authMethodId:
            deps.append(secret.authMethodId)
        if secret.platformId:
            deps.append(secret.platformId)

        self._secrets[secret.id] = self._serialize_secret(secret)
        self._dep_graph[secret.id] = deps

    async def _collect_auth_method(self, auth_method: AuthMethod):
        visit_key = ("auth_method", auth_method.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)
        self._auth_methods[auth_method.id] = _entity_to_dict(auth_method)
        self._dep_graph[auth_method.id] = []

    async def _collect_business_setting(self, setting: BusinessSetting, user_id: Optional[str] = None):
        visit_key = ("business_setting", setting.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)

        deps: List[str] = []
        await self._collect_project_by_belong(getattr(setting, "belongToProjectId", None), user_id=user_id)
        for knowledge in setting.knowledges or []:
            await self._collect_knowledge_resource(knowledge, user_id=user_id)
            deps.append(knowledge.id)

        self._business_settings[setting.id] = self._serialize_setting(setting)
        self._dep_graph[setting.id] = deps

    async def _collect_knowledge_resource(self, knowledge: KnowledgeResource, user_id: Optional[str] = None):
        visit_key = ("knowledge_resource", knowledge.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)

        await self._collect_project_by_belong(getattr(knowledge, "belongToProjectId", None), user_id=user_id)
        self._knowledge_resources[knowledge.id] = await self._serialize_knowledge_with_asset(knowledge, user_id=user_id)
        self._dep_graph[knowledge.id] = []

    async def _collect_mcp_server(self, server: McpServerSpec):
        visit_key = ("mcp_server", server.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)
        self._mcp_servers[server.id] = _entity_to_dict(server)
        self._dep_graph[server.id] = []

    async def _collect_mcp_resource(self, resource: McpResourceDescriptor):
        visit_key = ("mcp_resource", resource.id)
        if visit_key in self._visited:
            return
        self._visited.add(visit_key)
        deps = [resource.server_id] if resource.server_id else []
        self._mcp_resources[resource.id] = _entity_to_dict(resource)
        self._dep_graph[resource.id] = deps

    async def _collect_project_by_belong(self, belong_to_project_id: Optional[str], user_id: Optional[str] = None):
        if not belong_to_project_id:
            return
        if any(project.get("orgProjectId") == belong_to_project_id for project in self._projects.values()):
            return
        projects = await self._list_projects(user_id=user_id)
        for project in projects:
            if project.orgProjectId == belong_to_project_id:
                self._projects[project.id] = _entity_to_dict(project)
                avatar_path = await self._collect_project_avatar(project)
                if avatar_path:
                    self._projects[project.id]["avatarUrl"] = avatar_path
                self._dep_graph[project.id] = []
                return

    async def _collect_project_record(self, space_name: str, project_name_id: str, user_id: Optional[str] = None):
        target_org_project_id = f"{space_name}/{project_name_id}"
        projects = await self._list_projects(user_id=user_id)
        for project in projects:
            if project.orgProjectId == target_org_project_id:
                self._projects[project.id] = _entity_to_dict(project)
                avatar_path = await self._collect_project_avatar(project)
                if avatar_path:
                    self._projects[project.id]["avatarUrl"] = avatar_path
                self._dep_graph[project.id] = []
                return

    async def _list_project_name_ids_in_space(self, space_name: str, user_id: Optional[str] = None) -> List[str]:
        projects = await self._list_projects(user_id=user_id)
        result: List[str] = []
        prefix = f"{space_name}/"
        for project in projects:
            if project.orgProjectId.startswith(prefix):
                project_name = project.orgProjectId[len(prefix):]
                if project_name and project_name not in result:
                    result.append(project_name)
        return result

    async def _list_projects(self, user_id: Optional[str] = None) -> List[Project]:
        if self._resource_entity_store:
            return await self._resource_entity_store.list_projects(skip=0, limit=1000, user_id=user_id)
        if self._entity_store and hasattr(self._entity_store, "get_all_entities"):
            entities = getattr(self._entity_store, "get_all_entities")()
            return [entity for entity in entities if isinstance(entity, Project)]
        return []

    async def _get_project_by_id(self, entity_id: str, user_id: Optional[str] = None) -> Optional[Project]:
        if self._resource_entity_store:
            return await self._resource_entity_store.get_project(entity_id, user_id=user_id)
        for project in await self._list_projects(user_id=user_id):
            if project.id == entity_id:
                return project
        return None

    async def _get_knowledge_by_id(self, resource_id: str, user_id: Optional[str] = None) -> Optional[KnowledgeResource]:
        if self._resource_entity_store:
            return await self._resource_entity_store.get_knowledge_resource(resource_id, user_id=user_id)
        if self._entity_store and hasattr(self._entity_store, "get_all_entities"):
            for entity in getattr(self._entity_store, "get_all_entities")():
                if isinstance(entity, KnowledgeResource) and entity.id == resource_id:
                    return entity
        return None

    async def _get_setting_by_id(self, setting_id: str, user_id: Optional[str] = None) -> Optional[BusinessSetting]:
        if self._resource_entity_store:
            return await self._resource_entity_store.get_business_setting(setting_id, user_id=user_id)
        if self._entity_store and hasattr(self._entity_store, "get_all_entities"):
            for entity in getattr(self._entity_store, "get_all_entities")():
                if isinstance(entity, BusinessSetting) and entity.id == setting_id:
                    return entity
        return None

    async def _get_secret_by_id(self, secret_id: str, user_id: Optional[str] = None) -> Optional[Secret]:
        if self._resource_entity_store:
            return await self._resource_entity_store.get_secret(secret_id, user_id=user_id)
        if self._external_store and hasattr(self._external_store, "get_platform"):
            if self._entity_store and hasattr(self._entity_store, "get_all_entities"):
                for entity in getattr(self._entity_store, "get_all_entities")():
                    if isinstance(entity, Secret) and entity.id == secret_id:
                        return entity
        return None

    async def _collect_project_avatar(self, project: Project):
        return await self._collect_asset_file(
            owner_type="project",
            owner_id=project.id,
            field_name="avatarUrl",
            source_uri=getattr(project, "avatarUrl", None),
            package_path=f"assets/avatars/projects/{project.id}_{self._safe_name(getattr(project, 'name_en', None) or project.id)}{self._guess_suffix(getattr(project, 'avatarUrl', None))}",
        )

    async def _collect_platform_image(self, platform: Platform):
        return await self._collect_asset_file(
            owner_type="platform",
            owner_id=platform.id,
            field_name="image_url",
            source_uri=getattr(platform, "image_url", None),
            package_path=f"assets/platforms/{platform.id}_{self._safe_name(platform.name_en)}{self._guess_suffix(platform.image_url)}",
        )

    async def _collect_avatar_file(
        self,
        owner_type: str,
        owner_id: str,
        field_name: str,
        source_uri: Optional[str],
        target_name: str,
    ):
        if not source_uri:
            return
        package_path = f"assets/avatars/{owner_type}s/{owner_id}_{self._safe_name(target_name)}{self._guess_suffix(source_uri)}"
        return await self._collect_asset_file(owner_type, owner_id, field_name, source_uri, package_path)

    async def _collect_asset_file(
        self,
        owner_type: str,
        owner_id: str,
        field_name: str,
        source_uri: Optional[str],
        package_path: str,
    ) -> Optional[str]:
        if not source_uri or _is_remote_uri(source_uri):
            return None
        if package_path in self._assets:
            return package_path

        data = await self._read_binary_resource(source_uri)
        if data is None:
            return None

        self._assets[package_path] = data
        self._asset_entries[package_path] = PackageAsset(
            path=package_path,
            owner_type=owner_type,
            owner_id=owner_id,
            field_name=field_name,
            source_uri=source_uri,
            filename=Path(source_uri).name if source_uri else None,
            content_type=mimetypes.guess_type(source_uri)[0],
            optional=True,
        )
        return package_path

    async def _serialize_knowledge_with_asset(
        self,
        knowledge: KnowledgeResource,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        data = self._serialize_knowledge(knowledge)
        if knowledge.uri and not _is_remote_uri(knowledge.uri):
            filename = knowledge.filename or Path(knowledge.uri).name or f"{knowledge.id}.bin"
            package_path = f"resources/knowledge/{knowledge.id}/original/{filename}"
            stored_path = await self._collect_asset_file(
                owner_type="knowledge_resource",
                owner_id=knowledge.id,
                field_name="uri",
                source_uri=knowledge.uri,
                package_path=package_path,
            )
            if stored_path:
                data["uri"] = stored_path
                data["filename"] = filename
        return data

    async def _read_binary_resource(self, source_uri: str) -> Optional[bytes]:
        candidate = Path(source_uri)
        if candidate.exists() and candidate.is_file():
            return candidate.read_bytes()
        if self._resource_store:
            try:
                return await self._resource_store.download(source_uri)
            except Exception as exc:
                logger.debug(f"读取资源失败，已跳过: {source_uri}, {exc}")
        return None

    def _serialize_agent(self, agent: Agent) -> Dict[str, Any]:
        data = _entity_to_dict(agent)
        data["avatar_uri"] = self._packaged_field("agent", agent.id, "avatar_uri", data.get("avatar_uri"))
        if agent.model:
            data["model"] = agent.model.id
        if agent.setting:
            data["setting"] = agent.setting.id
        data["tools"] = [tool.id for tool in agent.tools or []]
        data["actAsCharacters"] = [character.id for character in getattr(agent, "actAsCharacters", None) or []]
        data["assistantAgents"] = [assistant.id for assistant in getattr(agent, "assistantAgents", None) or []]
        data["accountSecrets"] = [secret.id for secret in getattr(agent, "accountSecrets", None) or []]
        return data

    def _serialize_character(self, character: Character) -> Dict[str, Any]:
        data = _entity_to_dict(character)
        data["avatar_uri"] = self._packaged_field("character", character.id, "avatar_uri", data.get("avatar_uri"))
        if character.model:
            data["model"] = character.model.id
        if character.setting:
            data["setting"] = character.setting.id
        data["tools"] = [tool.id for tool in character.tools or []]
        return data

    def _serialize_tool(self, tool: Tool) -> Dict[str, Any]:
        data = _entity_to_dict(tool)
        data["avatar_uri"] = self._packaged_field("tool", tool.id, "avatar_uri", data.get("avatar_uri"))
        if isinstance(tool, APITool):
            data["platform"] = tool.platform.id
        if isinstance(tool, LLMTool) and tool.model:
            data["model"] = tool.model.id
            if tool.setting:
                data["setting"] = tool.setting.id
        if isinstance(tool, AgentTool):
            if tool.backendAgent:
                data["backendAgent"] = tool.backendAgent.id
            if tool.setting:
                data["setting"] = tool.setting.id
        if isinstance(tool, MCPTool):
            data["server"] = tool.server.id
            data["resource"] = tool.resource.id
            if tool.platform:
                data["platform"] = tool.platform.id
        return data

    def _serialize_platform(self, platform: Platform) -> Dict[str, Any]:
        data = _entity_to_dict(platform)
        data["image_url"] = self._packaged_field("platform", platform.id, "image_url", data.get("image_url"))
        data["secrets"] = [secret.id for secret in platform.secrets or []]
        data["authMethods"] = [auth.id for auth in platform.authMethods or []]
        return data

    def _serialize_secret(self, secret: Secret) -> Dict[str, Any]:
        data = _entity_to_dict(secret)
        data.pop("credential", None)
        return data

    def _serialize_setting(self, setting: BusinessSetting) -> Dict[str, Any]:
        data = _entity_to_dict(setting)
        data["knowledges"] = [knowledge.id for knowledge in setting.knowledges or []]
        return data

    def _serialize_knowledge(self, knowledge: KnowledgeResource) -> Dict[str, Any]:
        data = _entity_to_dict(knowledge)
        data["uri"] = self._packaged_field("knowledge_resource", knowledge.id, "uri", data.get("uri"))
        return data

    def _build_manifest(self) -> PackageManifest:
        return PackageManifest(
            projects=list(self._projects.values()),
            platforms=list(self._platforms.values()),
            auth_methods=list(self._auth_methods.values()),
            secrets=list(self._secrets.values()),
            knowledge_resources=list(self._knowledge_resources.values()),
            business_settings=list(self._business_settings.values()),
            mcp_servers=list(self._mcp_servers.values()),
            mcp_resources=list(self._mcp_resources.values()),
            models=list(self._models.values()),
            tools=list(self._tools.values()),
            characters=list(self._characters.values()),
            agents=list(self._agents.values()),
            assets=list(self._asset_entries.values()),
        )

    def _build_metadata(
        self,
        name: Optional[str] = None,
        description: Optional[str] = None,
        created_by: Optional[str] = None,
    ) -> PackageMetadata:
        return PackageMetadata(
            package_name=name or f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            created_at=datetime.now().isoformat(),
            created_by=created_by,
            description=description,
            entity_counts={
                "projects": len(self._projects),
                "platforms": len(self._platforms),
                "auth_methods": len(self._auth_methods),
                "secrets": len(self._secrets),
                "knowledge_resources": len(self._knowledge_resources),
                "business_settings": len(self._business_settings),
                "mcp_servers": len(self._mcp_servers),
                "mcp_resources": len(self._mcp_resources),
                "models": len(self._models),
                "tools": len(self._tools),
                "characters": len(self._characters),
                "agents": len(self._agents),
            },
            dependency_graph=self._dep_graph,
            asset_counts={
                "total": len(self._assets),
                "avatars": len([item for item in self._asset_entries.values() if item.field_name in {"avatar_uri", "avatarUrl", "image_url"}]),
                "knowledge_resources": len([item for item in self._asset_entries.values() if item.field_name == "uri"]),
            },
        )

    async def export_to_dir(
        self,
        output_dir: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        created_by: Optional[str] = None,
    ) -> str:
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)

        manifest = self._build_manifest()
        metadata = self._build_metadata(name, description, created_by)

        with open(out / "export.yaml", "w", encoding="utf-8") as f:
            yaml.dump(manifest.model_dump(mode="json"), f, allow_unicode=True, sort_keys=False, default_flow_style=False)

        with open(out / "metadata.json", "w", encoding="utf-8") as f:
            json.dump(metadata.model_dump(mode="json"), f, indent=2, ensure_ascii=False)

        type_map = {
            "agents": self._agents,
            "characters": self._characters,
            "tools": self._tools,
            "models": self._models,
            "platforms": self._platforms,
            "auth_methods": self._auth_methods,
            "secrets": self._secrets,
            "knowledge_resources": self._knowledge_resources,
            "business_settings": self._business_settings,
            "mcp_servers": self._mcp_servers,
            "mcp_resources": self._mcp_resources,
            "projects": self._projects,
        }

        for type_name, entities in type_map.items():
            if not entities:
                continue
            type_dir = out / type_name
            type_dir.mkdir(exist_ok=True)
            for entity_id, entity_data in entities.items():
                file_name = entity_data.get("name_id") or entity_data.get("name_en") or entity_id
                with open(type_dir / f"{file_name}.yaml", "w", encoding="utf-8") as f:
                    yaml.dump(entity_data, f, allow_unicode=True, sort_keys=False, default_flow_style=False)

        for asset_path, payload in self._assets.items():
            asset_file = out / asset_path
            asset_file.parent.mkdir(parents=True, exist_ok=True)
            asset_file.write_bytes(payload)

        logger.info(f"已导出 Package 到目录: {output_dir}")
        return str(out)

    async def export_to_zip(
        self,
        output_path: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        created_by: Optional[str] = None,
    ) -> str:
        manifest = self._build_manifest()
        metadata = self._build_metadata(name, description, created_by)

        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(
                "export.yaml",
                yaml.dump(manifest.model_dump(mode="json"), allow_unicode=True, sort_keys=False, default_flow_style=False),
            )
            zf.writestr(
                "metadata.json",
                json.dumps(metadata.model_dump(mode="json"), indent=2, ensure_ascii=False),
            )

            type_map = {
                "agents": self._agents,
                "characters": self._characters,
                "tools": self._tools,
                "models": self._models,
                "platforms": self._platforms,
                "auth_methods": self._auth_methods,
                "secrets": self._secrets,
                "knowledge_resources": self._knowledge_resources,
                "business_settings": self._business_settings,
                "mcp_servers": self._mcp_servers,
                "mcp_resources": self._mcp_resources,
                "projects": self._projects,
            }
            for type_name, entities in type_map.items():
                for entity_id, entity_data in entities.items():
                    file_name = entity_data.get("name_id") or entity_data.get("name_en") or entity_id
                    zf.writestr(
                        f"{type_name}/{file_name}.yaml",
                        yaml.dump(entity_data, allow_unicode=True, sort_keys=False, default_flow_style=False),
                    )

            for asset_path, payload in self._assets.items():
                zf.writestr(asset_path, payload)

        logger.info(f"已导出 Package 到 ZIP: {output_path}")
        return str(out)

    def _build_zip_bytes(self, manifest: PackageManifest, metadata: PackageMetadata) -> bytes:
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(
                "export.yaml",
                yaml.dump(manifest.model_dump(mode="json"), allow_unicode=True, sort_keys=False, default_flow_style=False),
            )
            zf.writestr(
                "metadata.json",
                json.dumps(metadata.model_dump(mode="json"), indent=2, ensure_ascii=False),
            )

            type_map = {
                "agents": self._agents,
                "characters": self._characters,
                "tools": self._tools,
                "models": self._models,
                "platforms": self._platforms,
                "auth_methods": self._auth_methods,
                "secrets": self._secrets,
                "knowledge_resources": self._knowledge_resources,
                "business_settings": self._business_settings,
                "mcp_servers": self._mcp_servers,
                "mcp_resources": self._mcp_resources,
                "projects": self._projects,
            }
            for type_name, entities in type_map.items():
                for entity_id, entity_data in entities.items():
                    file_name = entity_data.get("name_id") or entity_data.get("name_en") or entity_id
                    zf.writestr(
                        f"{type_name}/{file_name}.yaml",
                        yaml.dump(entity_data, allow_unicode=True, sort_keys=False, default_flow_style=False),
                    )

            for asset_path, payload in self._assets.items():
                zf.writestr(asset_path, payload)
        return buffer.getvalue()

    def get_summary(self) -> Dict[str, Any]:
        return {
            "agents": len(self._agents),
            "characters": len(self._characters),
            "tools": len(self._tools),
            "models": len(self._models),
            "platforms": len(self._platforms),
            "auth_methods": len(self._auth_methods),
            "secrets": len(self._secrets),
            "knowledge_resources": len(self._knowledge_resources),
            "business_settings": len(self._business_settings),
            "mcp_servers": len(self._mcp_servers),
            "mcp_resources": len(self._mcp_resources),
            "projects": len(self._projects),
            "assets": len(self._assets),
            "total": sum([
                len(self._agents),
                len(self._characters),
                len(self._tools),
                len(self._models),
                len(self._platforms),
                len(self._auth_methods),
                len(self._secrets),
                len(self._knowledge_resources),
                len(self._business_settings),
                len(self._mcp_servers),
                len(self._mcp_resources),
                len(self._projects),
            ]),
        }

    @staticmethod
    def _safe_name(value: str) -> str:
        return "".join(char if char.isalnum() or char in {"-", "_"} else "_" for char in value)

    @staticmethod
    def _guess_suffix(value: Optional[str]) -> str:
        if not value:
            return ".bin"
        suffix = Path(value).suffix
        if suffix:
            return suffix
        guessed = mimetypes.guess_extension(mimetypes.guess_type(value)[0] or "")
        return guessed or ".bin"

    def _packaged_field(self, owner_type: str, owner_id: str, field_name: str, fallback: Optional[str]) -> Optional[str]:
        for asset in self._asset_entries.values():
            if asset.owner_type == owner_type and asset.owner_id == owner_id and asset.field_name == field_name:
                return asset.path
        return fallback
