"""
Package 包清单与元数据模型

定义导出包的结构规范，用于 PackageExporter 导出和 YAMLConfigStore 导入。
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class CoreDataExportScope(BaseModel):
    """核心数据导出作用域。"""

    scope_type: str
    space_name: Optional[str] = None
    project_name_id: Optional[str] = None
    entity_type: Optional[str] = None
    entity_id: Optional[str] = None
    name_id: Optional[str] = None
    version_tag: Optional[str] = None
    series_name: Optional[str] = None

    def model_post_init(self, __context: Any) -> None:
        scope_type = self.scope_type.lower()
        self.scope_type = scope_type
        if scope_type not in {"space", "project", "entity"}:
            raise ValueError(f"不支持的导出范围: {self.scope_type}")
        if scope_type == "space" and not self.space_name:
            raise ValueError("space 范围导出必须提供 space_name")
        if scope_type == "project" and (not self.space_name or not self.project_name_id):
            raise ValueError("project 范围导出必须提供 space_name 和 project_name_id")
        if scope_type == "entity" and not self.entity_type:
            raise ValueError("entity 范围导出必须提供 entity_type")

    def build_package_name(self) -> str:
        if self.scope_type == "space":
            return f"space_{self.space_name}"
        if self.scope_type == "project":
            return f"project_{self.space_name}_{self.project_name_id}"
        suffix = self.name_id or self.entity_id or "entity"
        return f"entity_{self.entity_type}_{suffix}"


class CoreDataExportResult(BaseModel):
    """核心数据导出结果。"""

    package_name: str
    filename: str
    content_type: str = "application/zip"
    package_bytes: bytes
    manifest: Dict[str, Any]
    metadata: Dict[str, Any]
    summary: Dict[str, Any]


class PackageAsset(BaseModel):
    """包内二进制资源描述。"""

    path: str
    owner_type: str
    owner_id: str
    field_name: str
    source_uri: Optional[str] = None
    filename: Optional[str] = None
    content_type: Optional[str] = None
    optional: bool = False


class PackageManifest(BaseModel):
    """导出包清单，对应 export.yaml 顶层结构。"""

    version: str = "1.0"
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    description: Optional[str] = None

    # 各类实体列表，每项为 model_dump 后的字典
    projects: List[Dict[str, Any]] = Field(default_factory=list)
    platforms: List[Dict[str, Any]] = Field(default_factory=list)
    auth_methods: List[Dict[str, Any]] = Field(default_factory=list)
    secrets: List[Dict[str, Any]] = Field(default_factory=list)
    knowledge_resources: List[Dict[str, Any]] = Field(default_factory=list)
    business_settings: List[Dict[str, Any]] = Field(default_factory=list)
    mcp_servers: List[Dict[str, Any]] = Field(default_factory=list)
    mcp_resources: List[Dict[str, Any]] = Field(default_factory=list)
    models: List[Dict[str, Any]] = Field(default_factory=list)
    tools: List[Dict[str, Any]] = Field(default_factory=list)
    characters: List[Dict[str, Any]] = Field(default_factory=list)
    agents: List[Dict[str, Any]] = Field(default_factory=list)
    assets: List[PackageAsset] = Field(default_factory=list)


class PackageMetadata(BaseModel):
    """导出包元数据，对应 metadata.json。"""

    package_name: Optional[str] = None
    package_version: str = "1.0"
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    created_by: Optional[str] = None
    source_space: Optional[str] = None
    source_project: Optional[str] = None
    description: Optional[str] = None

    entity_counts: Dict[str, int] = Field(default_factory=dict)
    dependency_graph: Dict[str, List[str]] = Field(default_factory=dict)
    asset_counts: Dict[str, int] = Field(default_factory=dict)
