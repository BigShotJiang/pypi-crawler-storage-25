# coding=utf-8
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from turbo_agent_core.schema.enums import ConversationStatus, MessageStatus
from turbo_agent_core.schema.states import Action, Conversation, Message, ReActRound, ToolCallRecord, JobTask
from turbo_agent_store.interface import StateStore


@dataclass
class _MessageRecord:
    message: Message


class InMemoryStateStore(StateStore):
    """用于测试和调试的内存版 StateStore。"""

    def __init__(self):
        self.conversations: Dict[str, Conversation] = {}
        self.messages: Dict[str, Message] = {}
        self.actions: Dict[str, Action] = {}
        self.react_rounds: Dict[str, ReActRound] = {}
        self.tool_call_records: Dict[str, ToolCallRecord] = {}
        self.job_tasks: Dict[str, JobTask] = {}
        self.message_knowledge_ids: Dict[str, List[str]] = {}

    async def get_conversation(self, conversation_id: str, **kwargs) -> Optional[Conversation]:
        return self.conversations.get(conversation_id)

    async def save_conversation(self, conversation: Conversation, **kwargs) -> str:
        self.conversations[conversation.id] = conversation.model_copy(deep=True)
        return conversation.id

    async def update_conversation_status(self, conversation_id: str, status: ConversationStatus, **kwargs) -> bool:
        conversation = self.conversations.get(conversation_id)
        if conversation is None:
            return False
        conversation.status = status
        return True

    async def list_conversations(self, assistant_id: Optional[str] = None, workset_id: Optional[str] = None, status: Optional[ConversationStatus] = None, skip: int = 0, limit: int = 20, **kwargs) -> List[Conversation]:
        items = list(self.conversations.values())
        conversation_mode = kwargs.get("conversation_mode")
        if status is not None:
            items = [item for item in items if item.status == status]
        if conversation_mode is not None:
            items = [item for item in items if getattr(item, "conversation_mode", None) == conversation_mode]
        return items[skip:skip + limit]

    async def delete_conversation(self, conversation_id: str, **kwargs) -> bool:
        return self.conversations.pop(conversation_id, None) is not None

    async def get_message(self, message_id: str, **kwargs) -> Optional[Message]:
        return self.messages.get(message_id)

    async def save_message(self, message: Message, conversation_id: str, **kwargs) -> str:
        self.messages[message.id] = message.model_copy(deep=True)
        conv = self.conversations.get(conversation_id)
        if conv is not None:
            existing = next((item for item in conv.messages if item.id == message.id), None)
            if existing is None:
                conv.messages.append(message.model_copy(deep=True))
            else:
                idx = conv.messages.index(existing)
                conv.messages[idx] = message.model_copy(deep=True)
            if not conv.root_message_id and conv.messages:
                conv.root_message_id = conv.messages[0].id
        for round_data in message.reactRounds or []:
            self.react_rounds[round_data.id] = round_data.model_copy(deep=True)
            for action in round_data.actions or []:
                self.actions[action.id] = action.model_copy(deep=True)
                for record in action.records or []:
                    self.tool_call_records[record.id] = record.model_copy(deep=True)
        for action in message.actions or []:
            self.actions[action.id] = action.model_copy(deep=True)
            for record in action.records or []:
                self.tool_call_records[record.id] = record.model_copy(deep=True)
        return message.id

    async def bind_knowledge_resources_to_message(self, message_id: str, knowledge_ids: List[str], **kwargs) -> bool:
        self.message_knowledge_ids[message_id] = list(dict.fromkeys([knowledge_id for knowledge_id in knowledge_ids if knowledge_id]))
        return True

    async def list_messages(self, conversation_id: str, skip: int = 0, limit: int = 100, **kwargs) -> List[Message]:
        conv = self.conversations.get(conversation_id)
        if not conv:
            return []
        return conv.messages[skip:skip + limit]

    async def delete_message(self, message_id: str, **kwargs) -> bool:
        return self.messages.pop(message_id, None) is not None

    async def get_action(self, action_id: str, **kwargs) -> Optional[Action]:
        return self.actions.get(action_id)

    async def save_action(self, action: Action, message_id: str, **kwargs) -> str:
        self.actions[action.id] = action.model_copy(deep=True)
        for record in action.records or []:
            self.tool_call_records[record.id] = record.model_copy(deep=True)
        return action.id

    async def list_actions(self, message_id: str, skip: int = 0, limit: int = 100, **kwargs) -> List[Action]:
        return list(self.actions.values())[skip:skip + limit]

    async def update_action_status(self, action_id: str, status: ActionStatus, **kwargs) -> bool:
        action = self.actions.get(action_id)
        if not action:
            return False
        action.status = status
        return True

    async def get_react_round(self, round_id: str, **kwargs) -> Optional[ReActRound]:
        return self.react_rounds.get(round_id)

    async def save_react_round(self, react_round: ReActRound, message_id: str, **kwargs) -> str:
        self.react_rounds[react_round.id] = react_round.model_copy(deep=True)
        return react_round.id

    async def list_react_rounds(self, message_id: str, skip: int = 0, limit: int = 100, **kwargs) -> List[ReActRound]:
        return list(self.react_rounds.values())[skip:skip + limit]

    async def get_tool_call_record(self, record_id: str, **kwargs) -> Optional[ToolCallRecord]:
        return self.tool_call_records.get(record_id)

    async def save_tool_call_record(self, record: ToolCallRecord, **kwargs) -> str:
        self.tool_call_records[record.id] = record.model_copy(deep=True)
        return record.id

    async def list_tool_call_records(self, action_id: Optional[str] = None, tool_project_id: Optional[str] = None, tool_name_id: Optional[str] = None, skip: int = 0, limit: int = 100, **kwargs) -> List[ToolCallRecord]:
        return list(self.tool_call_records.values())[skip:skip + limit]

    async def get_job_task_state(self, task_id: str, **kwargs) -> Optional[JobTask]:
        return self.job_tasks.get(task_id)

    async def save_job_task_state(self, task: JobTask, **kwargs) -> str:
        self.job_tasks[task.id] = task.model_copy(deep=True)
        return task.id

    async def update_job_task_state(self, task_id: str, status: Optional[str] = None, execution_time=None, end_time=None, token_cost: Optional[int] = None, money_cost: Optional[float] = None, **kwargs) -> bool:
        return task_id in self.job_tasks

    async def create_conversation(self, conversation: Conversation, owner_id: Optional[str] = None) -> None:
        await self.save_conversation(conversation)
        for message in conversation.messages:
            await self.save_message(message, conversation.id)

    async def add_message_to_conversation(self, conversation_id: str, message: Message, parent_id: Optional[str] = None) -> Conversation:
        conversation = self.conversations.get(conversation_id)
        if conversation is None:
            raise ValueError(f"Conversation {conversation_id} not found")
        actual_parent_id = parent_id
        if not actual_parent_id and conversation.messages:
            actual_parent_id = conversation.messages[-1].id
        conversation.add_child(message, parent_id=actual_parent_id)
        await self.save_message(message, conversation_id)
        return conversation