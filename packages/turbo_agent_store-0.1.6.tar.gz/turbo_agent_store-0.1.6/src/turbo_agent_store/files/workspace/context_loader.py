"""对话工作区上下文加载器。"""

from __future__ import annotations

import base64
import mimetypes
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Optional
from urllib.parse import urlparse
from loguru import logger

from turbo_agent_core.schema.enums import KnowledgeType, ResourceStatus
from turbo_agent_core.schema.resources import KnowledgeResource
from turbo_agent_core.schema.states import Conversation, Message, MessageKnowledgeResourceContent
from turbo_agent_store.files.file_manage.base import FileManageStore
from turbo_agent_store.interface.permission import PermissionStore


@dataclass(slots=True)
class WorkspaceContextUserInfo:
    """工作区上下文加载所需的最小用户信息。"""

    user_id: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class WorkspaceContextResource:
    """已落地到本地上下文目录的资源。"""

    resource_id: str
    uri: str
    name: Optional[str]
    mime_type: Optional[str]
    local_path: Path
    storage_group: str


@dataclass(slots=True)
class WorkspaceContextSnapshot:
    """工作区上下文加载结果。"""

    conversation_id: str
    root_path: Path
    knowledge_files_path: Path
    temp_files_path: Path
    workset_path: Path
    output_files_path: Path
    resources: dict[str, WorkspaceContextResource] = field(default_factory=dict)


class WorkspaceContextLoader:
    """为 Conversation 准备本地上下文目录并提供消息内容转换能力。"""

    def __init__(
        self,
        file_manage_store: FileManageStore,
        permission_store: PermissionStore,
        conversation: Conversation,
        user_info: WorkspaceContextUserInfo | Mapping[str, Any] | str,
        base_path: Optional[str] = None,
    ):
        self.file_manage_store = file_manage_store
        self.permission_store = permission_store
        self.conversation = conversation
        self.user_info = self._normalize_user_info(user_info)
        self.base_path = Path(base_path or Path(tempfile.gettempdir()) / "turbo_agent" / "conversation_contexts")
        self.root_path = self.base_path / self._sanitize_segment(conversation.id)
        self.knowledge_files_path = self.root_path / "knowledge_files"
        self.temp_files_path = self.root_path / "temp_files"
        self.workset_path = self.root_path / "workset"
        self.output_files_path = self.root_path / "output_files"
        self._resource_index: dict[str, WorkspaceContextResource] = {}
        self._initialized = False

    async def initialize(self) -> WorkspaceContextSnapshot:
        """初始化本地上下文目录并预加载消息绑定资源。"""
        await self._authorize_conversation()
        self._ensure_directory_structure()
        for resource in self._collect_conversation_resources():
            await self._materialize_resource(resource)
        self._initialized = True
        return self.snapshot

    @property
    def snapshot(self) -> WorkspaceContextSnapshot:
        return WorkspaceContextSnapshot(
            conversation_id=self.conversation.id,
            root_path=self.root_path,
            knowledge_files_path=self.knowledge_files_path,
            temp_files_path=self.temp_files_path,
            workset_path=self.workset_path,
            output_files_path=self.output_files_path,
            resources=dict(self._resource_index),
        )

    def parse_message_content(self, message: Message) -> list[dict[str, Any]]:
        """将消息内容转换为兼容 OpenAI 多模态 content 的结构。"""
        if not self._initialized:
            raise RuntimeError("WorkspaceContextLoader 尚未初始化，请先调用 initialize()")

        if message.content is None:
            return []
        if isinstance(message.content, str):
            return [{"type": "text", "text": message.content}]

        result: list[dict[str, Any]] = []
        for item in message.content:
            if isinstance(item, str):
                result.append({"type": "text", "text": item})
            else:
                result.extend(self._parse_embedded_knowledge_item(item))
        return result

    def get_local_resource_path(self, resource_id: str) -> Optional[Path]:
        """返回已缓存资源的本地路径。"""
        resource = self._resource_index.get(resource_id)
        return resource.local_path if resource else None

    def _normalize_user_info(
        self, user_info: WorkspaceContextUserInfo | Mapping[str, Any] | str
    ) -> WorkspaceContextUserInfo:
        if isinstance(user_info, WorkspaceContextUserInfo):
            return user_info
        if isinstance(user_info, str):
            return WorkspaceContextUserInfo(user_id=user_info)
        user_id = user_info.get("user_id") or user_info.get("id") or user_info.get("userId")
        if not user_id:
            raise ValueError("user_info 缺少 user_id")
        metadata = {key: value for key, value in user_info.items() if key not in {"user_id", "id", "userId"}}
        return WorkspaceContextUserInfo(user_id=str(user_id), metadata=metadata)

    async def _authorize_conversation(self) -> None:
        logger.info(
            "WorkspaceContextLoader 开始校验会话访问: conversation_id={}, conversation_root_user_id={}, runtime_user_id={}",
            self.conversation.id,
            self.conversation.root_user_id,
            self.user_info.user_id,
        )
        allowed = await self.permission_store.check_conversation_access(
            conversation_id=self.conversation.id,
            owner_user_id=self.conversation.root_user_id,
            user_id=self.user_info.user_id,
            require_write=False,
        )
        if not allowed:
            raise PermissionError(f"用户 {self.user_info.user_id} 无权访问对话 {self.conversation.id}")

    def _ensure_directory_structure(self) -> None:
        for path in (
            self.knowledge_files_path,
            self.temp_files_path,
            self.workset_path,
            self.output_files_path,
        ):
            path.mkdir(parents=True, exist_ok=True)

    def _collect_conversation_resources(self) -> list[KnowledgeResource]:
        seen_keys: set[str] = set()
        resources: list[KnowledgeResource] = []
        for message in self.conversation.messages:
            for knowledge in message.knowledge_resources:
                cache_key = knowledge.id or knowledge.uri or knowledge.name
                if not cache_key or cache_key in seen_keys or not knowledge.uri:
                    continue
                seen_keys.add(cache_key)
                resources.append(knowledge)
            if isinstance(message.content, list):
                for item in message.content:
                    if not isinstance(item, MessageKnowledgeResourceContent):
                        continue
                    cache_key = item.id or item.uri or item.name
                    if not cache_key or cache_key in seen_keys or not item.uri:
                        continue
                    seen_keys.add(cache_key)
                    resources.append(
                        KnowledgeResource(
                            id=item.id,
                            name=item.name,
                            type=item.type,
                            status=ResourceStatus.ready,
                            fileType=item.fileType,
                            uri=item.uri,
                            mime_type=item.mimetype,
                            filename=item.name,
                        )
                    )
        return resources

    async def _materialize_resource(self, resource: KnowledgeResource) -> None:
        if resource.id in self._resource_index or not resource.uri:
            return

        payload = await self.file_manage_store.read_file_by_uri(resource.uri)
        storage_group, directory_id = self._resolve_storage_group(resource)
        target_dir = (self.knowledge_files_path if storage_group == "knowledge_files" else self.temp_files_path) / directory_id
        target_dir.mkdir(parents=True, exist_ok=True)

        extension = self._resolve_extension(resource)
        target_path = target_dir / f"origin{extension}"
        target_path.write_bytes(payload)

        self._resource_index[resource.id] = WorkspaceContextResource(
            resource_id=resource.id,
            uri=resource.uri,
            name=resource.filename or resource.name,
            mime_type=resource.mime_type,
            local_path=target_path,
            storage_group=storage_group,
        )

    def _resolve_storage_group(self, resource: KnowledgeResource) -> tuple[str, str]:
        uri = resource.uri or ""
        normalized_path = urlparse(uri).path or uri
        if "/temp/" in normalized_path or normalized_path.startswith("temp/"):
            temp_id = resource.id or self._infer_temp_resource_id(uri)
            return "temp_files", self._sanitize_segment(temp_id)
        return "knowledge_files", self._sanitize_segment(resource.id)

    def _infer_temp_resource_id(self, uri: str) -> str:
        normalized = urlparse(uri).path or uri
        parts = [part for part in normalized.strip("/").split("/") if part]
        if "temp" in parts:
            idx = parts.index("temp")
            if idx + 2 < len(parts):
                return parts[idx + 2]
        if len(parts) >= 2:
            return parts[-2]
        return "temp_resource"

    def _resolve_extension(self, resource: KnowledgeResource) -> str:
        if resource.fileType:
            ext = str(resource.fileType.value if hasattr(resource.fileType, "value") else resource.fileType).strip(".")
            return f".{ext}" if ext else ""
        if resource.filename:
            suffix = Path(resource.filename).suffix
            if suffix:
                return suffix
        if resource.mime_type:
            guessed = mimetypes.guess_extension(resource.mime_type, strict=False)
            if guessed:
                return guessed
        return ""

    def _parse_embedded_knowledge_item(self, item: MessageKnowledgeResourceContent) -> list[dict[str, Any]]:
        resource = self._resource_index.get(item.id)
        if self._is_image_item(item):
            if not resource:
                raise FileNotFoundError(f"未找到图片资源缓存: {item.id}")
            payload = resource.local_path.read_bytes()
            mime_type = item.mimetype or resource.mime_type or self._guess_mime_type(resource.local_path)
            return [{"type": "image_url", "image_url": {"url": self._build_data_url(payload, mime_type)}}]

        filename = item.name or (resource.name if resource else None) or "未知文件"
        return [{"type": "text", "text": f"用户上传了一个名为 {filename} 的文件"}]

    def _is_image_item(self, item: MessageKnowledgeResourceContent) -> bool:
        if item.type == KnowledgeType.Picture:
            return True
        return bool(item.mimetype and item.mimetype.startswith("image/"))

    def _guess_mime_type(self, local_path: Path) -> str:
        mime_type, _ = mimetypes.guess_type(str(local_path), strict=False)
        return mime_type or "application/octet-stream"

    def _build_data_url(self, payload: bytes, mime_type: str) -> str:
        encoded = base64.b64encode(payload).decode("ascii")
        return f"data:{mime_type};base64,{encoded}"

    def _sanitize_segment(self, value: Optional[str]) -> str:
        if not value:
            return "unknown"
        return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in value)