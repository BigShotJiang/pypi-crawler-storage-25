"""基于标准 S3 客户端的文件管理实现。"""

from __future__ import annotations

import asyncio
import mimetypes
import os
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import PurePosixPath
from typing import Any, Optional
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse, quote

from boto3.session import Session
from botocore.config import Config
from botocore.exceptions import ClientError

from turbo_agent_store.files.file_manage.base import (
    AccessMode,
    BucketVisibility,
    CacheGroup,
    FileDeleteResult,
    FileManageStore,
    FileMoveTarget,
    FileResourceDescriptor,
    FileWriteResult,
    ResourceFileSpec,
    SecureLinkResult,
    StorageLocator,
    TempBucketAllocation,
)
from turbo_agent_store.settings import settings


class S3FileManageStore(FileManageStore):
    """基于标准 S3 协议的文件管理实现。"""

    _IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".svg", ".avif"}
    _PUBLIC_ROLE_SET = {"avatar"}
    _PUBLIC_DOMAIN_SET = {"space", "project", "agent", "character", "tool", "platform", "model_series"}

    def __init__(
        self,
        endpoint: Optional[str] = None,
        region: Optional[str] = None,
        access_key_id: Optional[str] = None,
        secret_access_key: Optional[str] = None,
        session_token: Optional[str] = None,
        secure: Optional[bool] = None,
        addressing_style: Optional[str] = None,
        private_bucket: Optional[str] = None,
        public_bucket: Optional[str] = None,
        client: Any | None = None,
    ):
        self.endpoint = endpoint if endpoint is not None else settings.TA_STORE_S3_ENDPOINT
        self.region = region or settings.TA_STORE_S3_REGION
        self.private_bucket = private_bucket or settings.TA_STORE_S3_PRIVATE_BUCKET
        self.public_bucket = public_bucket or settings.TA_STORE_S3_PUBLIC_BUCKET
        self._secure = secure if secure is not None else settings.TA_STORE_S3_SECURE
        self._addressing_style = addressing_style or settings.TA_STORE_S3_ADDRESSING_STYLE

        _access_key_id = access_key_id if access_key_id is not None else settings.TA_STORE_S3_ACCESS_KEY_ID
        _secret_access_key = secret_access_key if secret_access_key is not None else settings.TA_STORE_S3_SECRET_ACCESS_KEY
        _session_token = session_token if session_token is not None else settings.TA_STORE_S3_SESSION_TOKEN

        self._endpoint_url = self._build_endpoint_url(self.endpoint)
        self.client = client or Session().client(
            "s3",
            endpoint_url=self._endpoint_url,
            region_name=self.region,
            aws_access_key_id=_access_key_id or None,
            aws_secret_access_key=_secret_access_key or None,
            aws_session_token=_session_token or None,
            use_ssl=self._secure,
            config=Config(signature_version="s3v4", s3={"addressing_style": self._addressing_style}),
        )

        self._ttl_meta_avatar = settings.TA_STORE_CACHE_TTL_META_AVATAR_SECONDS
        self._ttl_other_image = settings.TA_STORE_CACHE_TTL_OTHER_IMAGE_SECONDS
        self._ttl_default = settings.TA_STORE_CACHE_TTL_DEFAULT_SECONDS

        self._external_base_url = (settings.TA_STORE_EXTERNAL_BASE_URL or "").strip()
        self._external_path_prefix = self._normalize_path_prefix(settings.TA_STORE_EXTERNAL_PATH_PREFIX or "")

        self._ensure_required_buckets()

    def _build_endpoint_url(self, endpoint: str) -> str | None:
        normalized = (endpoint or "").strip()
        if not normalized:
            return None
        if normalized.startswith("http://") or normalized.startswith("https://"):
            return normalized.rstrip("/")
        scheme = "https" if self._secure else "http"
        return f"{scheme}://{normalized}".rstrip("/")

    def _normalize_path_prefix(self, path_prefix: str) -> str:
        if not path_prefix:
            return ""
        normalized = path_prefix.strip()
        if normalized == "/":
            return ""
        if not normalized.startswith("/"):
            normalized = f"/{normalized}"
        return normalized.rstrip("/")

    def _s3_origin(self) -> str:
        if self._endpoint_url:
            return self._endpoint_url.rstrip("/")
        return f"https://s3.{self.region}.amazonaws.com"

    def _get_external_origin(self) -> str:
        if self._external_base_url:
            return self._external_base_url.rstrip("/")
        return self._s3_origin()

    def _ensure_bucket(self, bucket_name: str) -> None:
        try:
            self.client.head_bucket(Bucket=bucket_name)
            return
        except ClientError as exc:
            error_code = str(exc.response.get("Error", {}).get("Code", ""))
            if error_code not in {"404", "NoSuchBucket", "NotFound"}:
                raise

        create_kwargs: dict[str, Any] = {"Bucket": bucket_name}
        if self.region and self.region != "us-east-1":
            create_kwargs["CreateBucketConfiguration"] = {"LocationConstraint": self.region}
        self.client.create_bucket(**create_kwargs)

    def _ensure_required_buckets(self) -> None:
        for bucket_name in (self.private_bucket, self.public_bucket):
            self._ensure_bucket(bucket_name)

    def _is_public_bucket(self, bucket: str) -> bool:
        return bucket == self.public_bucket

    def _is_image_key(self, object_key: str) -> bool:
        ext = PurePosixPath(object_key).suffix.lower()
        return ext in self._IMAGE_EXTS

    def resolve_bucket(
        self,
        resource_domain: str,
        role: Optional[str],
        visibility: Optional[BucketVisibility] = None,
    ) -> str:
        if visibility:
            if visibility == BucketVisibility.PUBLIC:
                return self.public_bucket
            if visibility == BucketVisibility.PRIVATE:
                return self.private_bucket

        normalized_domain = resource_domain.lower()
        normalized_role = (role or "").lower()
        if normalized_domain in self._PUBLIC_DOMAIN_SET and normalized_role in self._PUBLIC_ROLE_SET:
            return self.public_bucket
        return self.private_bucket

    def _get_cache_config(self, object_key: str) -> tuple[CacheGroup, int]:
        if "/meta/avatar/" in object_key or "/avatar/" in object_key:
            return CacheGroup.META_AVATAR, self._ttl_meta_avatar

        if self._is_image_key(object_key):
            return CacheGroup.OTHER_IMAGE, self._ttl_other_image

        return CacheGroup.DEFAULT, self._ttl_default

    def _build_external_url(self, bucket: str, object_key: str, revision: Optional[str]) -> str:
        object_path = quote(object_key.lstrip("/"), safe="/")
        path = f"{self._external_path_prefix}/{bucket}/{object_path}" if self._external_path_prefix else f"/{bucket}/{object_path}"
        url = f"{self._get_external_origin()}{path}"
        if not revision:
            return url

        parsed = urlparse(url)
        query_items = dict(parse_qsl(parsed.query, keep_blank_values=True))
        query_items["rev"] = revision
        return urlunparse(parsed._replace(query=urlencode(query_items, doseq=True)))

    def _rewrite_presigned_to_external(self, presigned_url: str) -> str:
        if not self._external_base_url:
            return presigned_url

        src = urlparse(presigned_url)
        dst = urlparse(self._get_external_origin())
        if src.path.startswith("/"):
            path = f"{self._external_path_prefix}{src.path}" if self._external_path_prefix else src.path
        else:
            path = f"{self._external_path_prefix}/{src.path}" if self._external_path_prefix else f"/{src.path}"

        return urlunparse((dst.scheme, dst.netloc, path, src.params, src.query, src.fragment))

    def _parse_storage_uri(self, uri: str) -> tuple[str, str]:
        if uri.startswith("s3://"):
            payload = uri[len("s3://") :]
        else:
            payload = uri.lstrip("/")
            return self.private_bucket, payload

        bucket, object_key = payload.split("/", 1)
        return bucket, object_key

    def _resolve_metadata_object_key(self, object_key: str) -> str:
        normalized_key = object_key.strip("/")
        if normalized_key.endswith("/metadata.json") or normalized_key == "metadata.json":
            return normalized_key

        for marker in ("/raw/", "/normalized/", "/artificial/"):
            if marker in normalized_key:
                return f"{normalized_key.split(marker, 1)[0]}/metadata.json"

        parent = PurePosixPath(normalized_key).parent.as_posix()
        if not parent or parent == ".":
            raise ValueError(f"无法从 URI 推导 metadata.json 路径: {object_key}")
        return f"{parent}/metadata.json"

    def _build_descriptor(self, bucket: str, object_key: str, cache_control: Optional[str] = None) -> FileResourceDescriptor:
        cache_group, ttl = self._get_cache_config(object_key)
        access_mode = AccessMode.PUBLIC if self._is_public_bucket(bucket) else AccessMode.PRESIGNED
        return FileResourceDescriptor(
            uri=f"s3://{bucket}/{object_key}",
            bucket=bucket,
            object_key=object_key,
            cache_group=cache_group,
            access_mode=access_mode,
            cache_ttl_seconds=ttl,
            cache_control=cache_control or f"public, max-age={ttl}",
            secure_link_expires_seconds=ttl,
        )

    def _resolve_variant_relative_path(self, spec: ResourceFileSpec) -> str:
        variant_name = spec.variant.value.strip("/")
        if not variant_name:
            raise ValueError("variant 不能为空")

        if "." in PurePosixPath(variant_name).name:
            return variant_name

        ext = spec.file_type.lstrip(".")
        filename = f"origin.{ext}" if variant_name == "raw" else f"data.{ext}"
        return f"{variant_name}/{filename}"

    def _temp_base_prefix(self, allocation: TempBucketAllocation, spec: ResourceFileSpec) -> str:
        return f"{allocation.bucket_prefix}{spec.resource_id}/"

    def _require_role(self, spec: ResourceFileSpec, scene: str) -> str:
        if spec.role is None:
            raise ValueError(f"{scene} 必须提供 role")
        return spec.role.value

    def _forbid_role(self, spec: ResourceFileSpec, scene: str) -> None:
        if spec.role is not None:
            raise ValueError(f"{scene} 不允许提供 role，当前传入: {spec.role.value}")

    def _resolve_move_target(self, target: FileMoveTarget) -> tuple[str, str]:
        has_uri = bool(target.uri)
        has_locator = target.locator is not None or target.relative_path is not None

        if has_uri == has_locator:
            raise ValueError("移动目标必须二选一：要么提供 uri，要么提供 locator + relative_path")

        if target.uri:
            return self._parse_storage_uri(target.uri)

        if target.locator is None or not target.relative_path:
            raise ValueError("使用 locator 作为移动目标时，必须同时提供 locator 与 relative_path")

        relative_path = target.relative_path.lstrip("/")
        return target.locator.bucket, f"{target.locator.prefix}{relative_path}"

    async def _run_in_executor(self, func, *args, **kwargs) -> Any:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, lambda: func(*args, **kwargs))

    async def _count_objects_with_prefix(self, bucket: str, prefix: str) -> int:
        def _count() -> int:
            count = 0
            continuation_token: str | None = None
            while True:
                kwargs: dict[str, Any] = {"Bucket": bucket, "Prefix": prefix, "MaxKeys": 1000}
                if continuation_token:
                    kwargs["ContinuationToken"] = continuation_token
                response = self.client.list_objects_v2(**kwargs)
                count += response.get("KeyCount", 0)
                if not response.get("IsTruncated"):
                    break
                continuation_token = response.get("NextContinuationToken")
            return count

        return await self._run_in_executor(_count)

    def _fmt_space(self, space_id: str) -> str:
        return space_id if space_id.startswith("space_") else f"space_{space_id}"

    def _fmt_proj(self, project_id: str) -> str:
        return project_id if project_id.startswith("project_") else f"project_{project_id}"

    async def ensure_project_storage(
        self, space_id: str, project_id: str, description: str = ""
    ) -> StorageLocator:
        del description
        s_id = self._fmt_space(space_id)
        p_id = self._fmt_proj(project_id)
        return StorageLocator(bucket=self.private_bucket, prefix=f"resources/{s_id}/{p_id}/")

    async def ensure_space_storage(
        self, space_id: str, description: str = ""
    ) -> StorageLocator:
        del description
        s_id = self._fmt_space(space_id)
        return StorageLocator(bucket=self.private_bucket, prefix=f"resources/{s_id}/")

    async def resolve_space_path(self, space_id: str, resource_type: str, resource_id: str) -> str:
        s_id = self._fmt_space(space_id)
        if resource_id:
            return f"resources/{s_id}/{resource_type}_{resource_id}/"
        return f"resources/{s_id}/{resource_type}/"

    async def resolve_project_path(self, space_id: str, project_id: str, resource_type: str, resource_id: str) -> str:
        s_id = self._fmt_space(space_id)
        p_id = self._fmt_proj(project_id)
        if resource_type.lower() == "meta" and resource_id == "":
            return f"resources/{s_id}/{p_id}/meta/"
        return f"resources/{s_id}/{p_id}/{resource_type}/{resource_id}/"

    async def put_resource_file(
        self,
        locator: StorageLocator,
        relative_path: str,
        local_file_path: str,
        content_type: Optional[str] = None,
    ) -> str:
        object_key = f"{locator.prefix}{relative_path}"

        guessed_content_type = content_type
        if not guessed_content_type:
            guessed_content_type, _ = mimetypes.guess_type(local_file_path)
            if not guessed_content_type:
                guessed_content_type, _ = mimetypes.guess_type(object_key)
            if not guessed_content_type:
                guessed_content_type = "application/octet-stream"

        def _put() -> str:
            self.client.upload_file(
                Filename=local_file_path,
                Bucket=locator.bucket,
                Key=object_key,
                ExtraArgs={"ContentType": guessed_content_type},
            )
            response = self.client.head_object(Bucket=locator.bucket, Key=object_key)
            return str(response.get("ETag", "")).strip('"')

        return await self._run_in_executor(_put)

    async def get_resource_file(self, locator: StorageLocator, relative_path: str) -> bytes:
        object_key = f"{locator.prefix}{relative_path}"

        def _get() -> bytes:
            response = self.client.get_object(Bucket=locator.bucket, Key=object_key)
            return response["Body"].read()

        return await self._run_in_executor(_get)

    async def allocate_temp_bucket(self, space_id: str, year: int) -> TempBucketAllocation:
        s_id = self._fmt_space(space_id)
        index = 0
        max_files_per_bucket = 1000

        while True:
            prefix = f"temp/{s_id}/{year}_bucket_{index}/"
            object_count = await self._count_objects_with_prefix(self.private_bucket, prefix)
            if object_count < max_files_per_bucket:
                break
            index += 1

        prefix = f"temp/{s_id}/{year}_bucket_{index}/"
        return TempBucketAllocation(
            space_id=space_id,
            year=year,
            bucket=self.private_bucket,
            bucket_index=index,
            bucket_prefix=prefix,
            max_files_per_bucket=max_files_per_bucket,
        )

    async def create_temp_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        self._forbid_role(spec, "临时文件")
        allocation = await self.allocate_temp_bucket(space_id, datetime.now(timezone.utc).year)
        base_prefix = self._temp_base_prefix(allocation, spec)
        return await self._create_standard_file(
            base_prefix=base_prefix,
            spec=spec,
            local_file_path=local_file_path,
            resource_domain="temp",
            visibility=BucketVisibility.PRIVATE,
        )

    async def read_temp_file(self, temp_uri: str) -> bytes:
        bucket, object_key = self._parse_storage_uri(temp_uri)
        locator = StorageLocator(
            bucket=bucket,
            prefix=f"{PurePosixPath(object_key).parent.as_posix()}/",
        )
        return await self.get_resource_file(locator, PurePosixPath(object_key).name)

    async def read_file_by_uri(self, uri: str) -> bytes:
        bucket, object_key = self._parse_storage_uri(uri)
        if object_key.startswith("temp/"):
            return await self.read_temp_file(uri)
        locator = StorageLocator(
            bucket=bucket,
            prefix=f"{PurePosixPath(object_key).parent.as_posix()}/",
        )
        return await self.get_resource_file(locator, PurePosixPath(object_key).name)

    async def delete_temp_file(self, temp_uri: str) -> FileDeleteResult:
        bucket, object_key = self._parse_storage_uri(temp_uri)

        def _del_obj() -> None:
            self.client.delete_object(Bucket=bucket, Key=object_key)

        await self._run_in_executor(_del_obj)
        return FileDeleteResult(descriptor=self._build_descriptor(bucket, object_key, cache_control=""), deleted=True)

    async def generate_secure_link(
        self,
        uri: str,
        variant: str = "raw",
        revision: Optional[str] = None,
    ) -> SecureLinkResult:
        del variant
        bucket, object_key = self._parse_storage_uri(uri)

        cache_group, ttl_seconds = self._get_cache_config(object_key)
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)

        if self._is_public_bucket(bucket):
            url = self._build_external_url(bucket=bucket, object_key=object_key, revision=revision)
            return SecureLinkResult(
                url=url,
                uri=uri,
                cache_group=cache_group,
                access_mode=AccessMode.PUBLIC,
                cache_ttl_seconds=ttl_seconds,
                cache_control=f"public, max-age={ttl_seconds}",
                expires_at_utc=expires_at,
            )

        def _presign() -> str:
            return self.client.generate_presigned_url(
                ClientMethod="get_object",
                Params={
                    "Bucket": bucket,
                    "Key": object_key,
                    "ResponseCacheControl": f"public, max-age={ttl_seconds}",
                },
                ExpiresIn=ttl_seconds,
            )

        presigned_url = await self._run_in_executor(_presign)
        url = self._rewrite_presigned_to_external(presigned_url)

        return SecureLinkResult(
            url=url,
            uri=uri,
            cache_group=cache_group,
            access_mode=AccessMode.PRESIGNED,
            cache_ttl_seconds=ttl_seconds,
            cache_control=f"public, max-age={ttl_seconds}",
            expires_at_utc=expires_at,
        )

    async def move_temp_resource(
        self,
        source_uri: str,
        target: FileMoveTarget,
    ) -> FileWriteResult:
        src_bucket, src_key = self._parse_storage_uri(source_uri)

        parts = src_key.split("/")
        if len(parts) < 2 or parts[0] != "temp":
            raise ValueError(f"无效的临时资源 URI，无法执行移动: {source_uri}")

        target_bucket, target_key = self._resolve_move_target(target)

        def _copy() -> dict[str, Any]:
            return self.client.copy_object(
                Bucket=target_bucket,
                Key=target_key,
                CopySource={"Bucket": src_bucket, "Key": src_key},
            )

        def _delete_source() -> None:
            self.client.delete_object(Bucket=src_bucket, Key=src_key)

        res = await self._run_in_executor(_copy)
        await self._run_in_executor(_delete_source)
        copy_result = res.get("CopyObjectResult", {}) if isinstance(res, dict) else {}
        return FileWriteResult(
            descriptor=self._build_descriptor(target_bucket, target_key),
            etag=str(copy_result.get("ETag", "")).strip('"') or None,
            version_id=res.get("VersionId") if isinstance(res, dict) else None,
        )

    async def update_resource_metadata(self, uri: str, metadata_content: bytes) -> FileWriteResult:
        bucket, object_key = self._parse_storage_uri(uri)
        metadata_key = self._resolve_metadata_object_key(object_key)
        metadata_content_type = "application/json; charset=utf-8"

        locator = StorageLocator(
            bucket=bucket,
            prefix=f"{PurePosixPath(metadata_key).parent.as_posix()}/",
        )
        with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as temp_file:
            temp_file.write(metadata_content)
            temp_path = temp_file.name

        try:
            etag = await self.put_resource_file(
                locator=locator,
                relative_path="metadata.json",
                local_file_path=temp_path,
                content_type=metadata_content_type,
            )
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

        descriptor = self._build_descriptor(bucket, metadata_key)
        return FileWriteResult(descriptor=descriptor, etag=etag)

    async def _create_standard_file(
        self,
        base_prefix: str,
        spec: ResourceFileSpec,
        local_file_path: str,
        resource_domain: str,
        visibility: Optional[BucketVisibility] = None,
    ) -> FileWriteResult:
        bucket = self.resolve_bucket(resource_domain=resource_domain, role=spec.role, visibility=visibility)
        locator = StorageLocator(bucket=bucket, prefix=base_prefix)

        rel_path = self._resolve_variant_relative_path(spec)

        etag = await self.put_resource_file(locator, rel_path, local_file_path)
        object_key = f"{base_prefix}{rel_path}"
        desc = self._build_descriptor(bucket, object_key)
        return FileWriteResult(descriptor=desc, etag=etag)

    async def _read_standard_file(
        self,
        base_prefix: str,
        spec: ResourceFileSpec,
        resource_domain: str,
        visibility: Optional[BucketVisibility] = None,
    ) -> bytes:
        bucket = self.resolve_bucket(resource_domain=resource_domain, role=spec.role, visibility=visibility)
        locator = StorageLocator(bucket=bucket, prefix=base_prefix)

        rel_path = self._resolve_variant_relative_path(spec)

        return await self.get_resource_file(locator, rel_path)

    async def _delete_standard_file(
        self,
        base_prefix: str,
        spec: ResourceFileSpec,
        resource_domain: str,
        visibility: Optional[BucketVisibility] = None,
    ) -> FileDeleteResult:
        bucket = self.resolve_bucket(resource_domain=resource_domain, role=spec.role, visibility=visibility)
        rel_path = self._resolve_variant_relative_path(spec)
        object_key = f"{base_prefix}{rel_path}"

        def _del_obj() -> None:
            self.client.delete_object(Bucket=bucket, Key=object_key)

        await self._run_in_executor(_del_obj)
        desc = self._build_descriptor(bucket, object_key, cache_control="")
        return FileDeleteResult(descriptor=desc, deleted=True)

    async def create_space_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_space_path(space_id, "meta", "")
        role = self._require_role(spec, "空间级文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="space")

    async def read_space_file(self, space_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_space_path(space_id, "meta", "")
        role = self._require_role(spec, "空间级文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="space")

    async def update_space_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_space_file(space_id, spec, local_file_path)

    async def delete_space_file(self, space_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_space_path(space_id, "meta", "")
        role = self._require_role(spec, "空间级文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="space")

    async def create_model_series_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_space_path(space_id, "model_series", spec.resource_id)
        role = self._require_role(spec, "模型系列文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="model_series")

    async def read_model_series_file(self, space_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_space_path(space_id, "model_series", spec.resource_id)
        role = self._require_role(spec, "模型系列文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="model_series")

    async def update_model_series_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_model_series_file(space_id, spec, local_file_path)

    async def delete_model_series_file(self, space_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_space_path(space_id, "model_series", spec.resource_id)
        role = self._require_role(spec, "模型系列文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="model_series")

    async def create_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "meta", "")
        role = self._require_role(spec, "项目级文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="project")

    async def read_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "meta", "")
        role = self._require_role(spec, "项目级文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="project")

    async def update_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_project_file(space_id, project_id, spec, local_file_path)

    async def delete_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "meta", "")
        role = self._require_role(spec, "项目级文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="project")

    async def create_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "agent", spec.resource_id)
        role = self._require_role(spec, "Agent 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="agent")

    async def read_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "agent", spec.resource_id)
        role = self._require_role(spec, "Agent 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="agent")

    async def update_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_agent_file(space_id, project_id, spec, local_file_path)

    async def delete_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "agent", spec.resource_id)
        role = self._require_role(spec, "Agent 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="agent")

    async def create_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "character", spec.resource_id)
        role = self._require_role(spec, "Character 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="character")

    async def read_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "character", spec.resource_id)
        role = self._require_role(spec, "Character 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="character")

    async def update_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_character_file(space_id, project_id, spec, local_file_path)

    async def delete_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "character", spec.resource_id)
        role = self._require_role(spec, "Character 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="character")

    async def create_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "tool", spec.resource_id)
        role = self._require_role(spec, "Tool 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="tool")

    async def read_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "tool", spec.resource_id)
        role = self._require_role(spec, "Tool 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="tool")

    async def update_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_tool_file(space_id, project_id, spec, local_file_path)

    async def delete_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "tool", spec.resource_id)
        role = self._require_role(spec, "Tool 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="tool")

    async def create_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "platform", spec.resource_id)
        role = self._require_role(spec, "Platform 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="platform")

    async def read_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "platform", spec.resource_id)
        role = self._require_role(spec, "Platform 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="platform")

    async def update_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_platform_file(space_id, project_id, spec, local_file_path)

    async def delete_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "platform", spec.resource_id)
        role = self._require_role(spec, "Platform 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="platform")

    async def create_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "mcp", spec.resource_id)
        role = self._require_role(spec, "MCP 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="mcp")

    async def read_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "mcp", spec.resource_id)
        role = self._require_role(spec, "MCP 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="mcp")

    async def update_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_mcp_file(space_id, project_id, spec, local_file_path)

    async def delete_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "mcp", spec.resource_id)
        role = self._require_role(spec, "MCP 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="mcp")

    async def create_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "skills", spec.resource_id)
        role = self._require_role(spec, "Skills 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="skills")

    async def read_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "skills", spec.resource_id)
        role = self._require_role(spec, "Skills 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="skills")

    async def update_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_skills_file(space_id, project_id, spec, local_file_path)

    async def delete_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "skills", spec.resource_id)
        role = self._require_role(spec, "Skills 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="skills")

    async def create_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        self._forbid_role(spec, "知识资源文件")
        prefix = await self.resolve_project_path(space_id, project_id, "knowledge_file", spec.resource_id)
        return await self._create_standard_file(prefix, spec, local_file_path, resource_domain="knowledge")

    async def read_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        self._forbid_role(spec, "知识资源文件")
        prefix = await self.resolve_project_path(space_id, project_id, "knowledge_file", spec.resource_id)
        return await self._read_standard_file(prefix, spec, resource_domain="knowledge")

    async def update_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_knowledge_file(space_id, project_id, spec, local_file_path)

    async def delete_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        self._forbid_role(spec, "知识资源文件")
        prefix = await self.resolve_project_path(space_id, project_id, "knowledge_file", spec.resource_id)
        return await self._delete_standard_file(prefix, spec, resource_domain="knowledge")

    async def create_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "secret", spec.resource_id)
        role = self._require_role(spec, "Secret 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="secret")

    async def read_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "secret", spec.resource_id)
        role = self._require_role(spec, "Secret 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="secret")

    async def update_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_secret_file(space_id, project_id, spec, local_file_path)

    async def delete_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "secret", spec.resource_id)
        role = self._require_role(spec, "Secret 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="secret")