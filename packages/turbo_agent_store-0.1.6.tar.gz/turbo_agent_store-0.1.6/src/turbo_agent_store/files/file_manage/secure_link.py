"""Nginx secure_link 签名工具。"""

from __future__ import annotations

import base64
import hashlib
import hmac


def generate_secure_link_signature(uri_path: str, expires: int, secret: str) -> str:
    """生成与 Nginx secure_link_md5 对齐的签名。

    对齐规则：
    `secure_link_md5 "$uri$arg_expires secret"`
    """

    if not secret:
        raise ValueError("生成 secure_link 签名时 secret 不能为空")

    message = f"{uri_path}{expires} {secret}".encode("utf-8")
    digest = hashlib.md5(message).digest()
    return base64.urlsafe_b64encode(digest).decode("utf-8").rstrip("=")