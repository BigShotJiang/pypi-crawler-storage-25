"""统一文件管理抽象接口。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional


class FileType(str, Enum):
    """受控文件类型。"""

    KNOWLEDGE_RESOURCE = "knowledge_resource"
    AVATAR = "avatar"


class ResourceFileRole(str, Enum):
    """资源文件作用角色。

    说明：
    1. 该枚举用于限制调用方可传入的 role，避免随意使用自定义字符串破坏路径与桶选择规则。
    2. role 仅表示文件在资源实例中的业务作用，不承载 temp、knowledge_file 等路径层级语义。
    """

    AVATAR = "avatar"
    CONFIG = "config"
    PACKAGE = "package"
    ENCRYPTED = "encrypted"

    def __str__(self) -> str:
        return self.value


class ResourceFileVariant(str, Enum):
    """资源文件内部变体。"""

    RAW = "raw"
    NORMALIZED = "normalized"
    ARTIFICIAL = "artificial"

    def __str__(self) -> str:
        return self.value


class AccessMode(str, Enum):
    """文件访问模式。"""

    PRESIGNED = "presigned"
    PUBLIC = "public"


class CacheGroup(str, Enum):
    """缓存分组。"""

    META_AVATAR = "meta_avatar"
    OTHER_IMAGE = "other_image"
    DEFAULT = "default"


class BucketVisibility(str, Enum):
    """桶可见性偏好。"""

    PUBLIC = "public"
    PRIVATE = "private"


class FileBackend(str, Enum):
    """文件管理后端类型。"""

    LOCAL = "local"
    S3 = "s3"


# --------------------- 工作集相关 (Gitea 生态) ---------------------

@dataclass
class RepoBinding:
    """仓库定位信息 (用于 Gitea/Git 等)。"""

    owner: str
    repo: str
    branch: str = "main"

@dataclass
class WorksetFileSpec:
    """工作集文件操作参数。"""

    resource_id: str
    file_type: str
    filename: Optional[str] = None
    branch: str = "main"


class WorksetManageStore(ABC):
    """Store 工作集管理抽象 (保留 Git 设计)。"""

    @abstractmethod
    async def ensure_workset_storage(
        self,
        space_id: str,
        workset_id: str,
        description: str = "",
        default_branch: str = "main",
    ) -> RepoBinding:
        """确保工作集级存储可用。"""

    @abstractmethod
    async def create_workset_file(
        self,
        space_id: str,
        workset_id: str,
        spec: WorksetFileSpec,
        content: bytes,
    ) -> "FileWriteResult":
        """创建 Workset 文件。"""

    @abstractmethod
    async def read_workset_file(self, space_id: str, workset_id: str, spec: WorksetFileSpec) -> bytes:
        """读取 Workset 文件。"""

    @abstractmethod
    async def update_workset_file(
        self,
        space_id: str,
        workset_id: str,
        spec: WorksetFileSpec,
        content: bytes,
    ) -> "FileWriteResult":
        """更新 Workset 文件。"""

    @abstractmethod
    async def delete_workset_file(self, space_id: str, workset_id: str, spec: WorksetFileSpec) -> "FileDeleteResult":
        """删除 Workset 文件。"""


# --------------------- 通用资源管理 (对象存储生态) ---------------------

@dataclass
class StorageLocator:
    """基于底层存储后端的直接定位信息。"""
    bucket: str
    prefix: str


@dataclass
class FileResourceDescriptor:
    """资源路径解析结果。"""

    uri: str
    bucket: str
    object_key: str
    cache_group: CacheGroup
    access_mode: AccessMode
    cache_ttl_seconds: int
    cache_control: str
    secure_link_expires_seconds: int


@dataclass
class TempBucketAllocation:
    """临时桶分配结果。"""

    space_id: str
    year: int
    bucket: str
    bucket_index: int
    bucket_prefix: str
    max_files_per_bucket: int


@dataclass
class FileMoveTarget:
    """文件移动目标描述。"""

    uri: Optional[str] = None
    locator: Optional[StorageLocator] = None
    relative_path: Optional[str] = None


@dataclass
class SecureLinkResult:
    """安全链接生成结果。"""

    url: str
    uri: str
    cache_group: CacheGroup
    access_mode: AccessMode
    cache_ttl_seconds: int
    cache_control: str
    expires_at_utc: datetime


@dataclass
class FileWriteResult:
    """文件写入结果。"""

    descriptor: FileResourceDescriptor
    etag: Optional[str] = None
    version_id: Optional[str] = None
    commit_sha: Optional[str] = None  # Compatible with Workset using git


@dataclass
class FileDeleteResult:
    """文件删除结果。"""

    descriptor: FileResourceDescriptor
    deleted: bool
    version_id: Optional[str] = None
    commit_sha: Optional[str] = None


@dataclass
class ResourceFileSpec:
    """资源文件操作参数。"""

    resource_id: str
    file_type: str
    role: Optional[ResourceFileRole] = None
    variant: ResourceFileVariant = ResourceFileVariant.RAW

    def __post_init__(self) -> None:
        self.resource_id = self.resource_id.strip()
        self.file_type = self.file_type.strip()
        if not self.file_type:
            raise ValueError("file_type 不能为空")
        if "/" in self.file_type or "\\" in self.file_type:
            raise ValueError("file_type 不能包含路径分隔符")
        if self.role is not None and not isinstance(self.role, ResourceFileRole):
            self.role = ResourceFileRole(self.role)
        if not isinstance(self.variant, ResourceFileVariant):
            self.variant = ResourceFileVariant(self.variant)


class FileManageStore(ABC):
    """Store 文件管理统一抽象 (S3/本地文件)。"""

    @abstractmethod
    async def ensure_space_storage(
        self,
        space_id: str,
        description: str = "",
    ) -> StorageLocator:
        """确保空间级存储可用。"""

    @abstractmethod
    async def ensure_project_storage(
        self,
        space_id: str,
        project_id: str,
        description: str = "",
    ) -> StorageLocator:
        """确保项目级存储可用。"""

    @abstractmethod
    async def resolve_space_path(self, space_id: str, resource_type: str, resource_id: str) -> str:
        """解析空间级路径前缀。"""

    @abstractmethod
    async def resolve_project_path(self, space_id: str, project_id: str, resource_type: str, resource_id: str) -> str:
        """解析项目路径前缀。"""

    @abstractmethod
    def resolve_bucket(
        self,
        resource_domain: str,
        role: Optional[str],
        visibility: Optional[BucketVisibility] = None,
    ) -> str:
        """根据资源域/角色/可见性解析目标桶。"""

    @abstractmethod
    async def put_resource_file(
        self,
        locator: StorageLocator,
        relative_path: str,
        local_file_path: str,
        content_type: Optional[str] = None,
    ) -> str:
        """写入资源文件并返回 object etag。"""

    @abstractmethod
    async def get_resource_file(self, locator: StorageLocator, relative_path: str) -> bytes:
        """读取资源文件。"""

    @abstractmethod
    async def allocate_temp_bucket(self, space_id: str, year: int) -> TempBucketAllocation:
        """按 `space_id + year` 和每桶上限分配临时桶。"""

    @abstractmethod
    async def create_temp_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        """创建临时文件。"""

    @abstractmethod
    async def read_temp_file(self, temp_uri: str) -> bytes:
        """读取临时文件。"""

    @abstractmethod
    async def read_file_by_uri(self, uri: str) -> bytes:
        """根据统一 URI 读取文件内容。"""

    @abstractmethod
    async def delete_temp_file(self, temp_uri: str) -> FileDeleteResult:
        """删除临时文件。"""

    @abstractmethod
    async def generate_secure_link(
        self,
        uri: str,
        variant: str = "raw",
        revision: Optional[str] = None,
    ) -> SecureLinkResult:
        """根据 URI 与 variant 生成预签名下载链接。"""

    @abstractmethod
    async def move_temp_resource(
        self,
        source_uri: str,
        target: FileMoveTarget,
    ) -> FileWriteResult:
        """将源 URI 指向的文件物理移动到目标位置，并返回新的资源定位。"""

    @abstractmethod
    async def update_resource_metadata(self, uri: str, metadata_content: bytes) -> FileWriteResult:
        """根据资源 URI 更新同实例目录下的 `metadata.json`。"""

    @abstractmethod
    async def create_space_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_space_file(self, space_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_space_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_space_file(self, space_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...

    @abstractmethod
    async def create_model_series_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_model_series_file(self, space_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_model_series_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_model_series_file(self, space_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...

    @abstractmethod
    async def create_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...

    @abstractmethod
    async def create_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...

    @abstractmethod
    async def create_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...

    @abstractmethod
    async def create_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...

    @abstractmethod
    async def create_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...

    @abstractmethod
    async def create_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...

    @abstractmethod
    async def create_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...

    @abstractmethod
    async def create_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...

    @abstractmethod
    async def create_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def read_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes: ...
    @abstractmethod
    async def update_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult: ...
    @abstractmethod
    async def delete_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult: ...
