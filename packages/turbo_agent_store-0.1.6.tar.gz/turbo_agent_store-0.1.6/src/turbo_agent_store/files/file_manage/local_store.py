"""基于本地文件系统的文件管理实现。"""

from __future__ import annotations

import os
import shutil
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath
from typing import Optional
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse, quote

from turbo_agent_store.files.file_manage.base import (
    AccessMode,
    BucketVisibility,
    CacheGroup,
    FileDeleteResult,
    FileManageStore,
    FileMoveTarget,
    FileResourceDescriptor,
    FileWriteResult,
    ResourceFileSpec,
    SecureLinkResult,
    StorageLocator,
    TempBucketAllocation,
)
from turbo_agent_store.files.file_manage.secure_link import generate_secure_link_signature
from turbo_agent_store.settings import settings


class LocalFileManageStore(FileManageStore):
    """基于普通文件系统的文件管理实现。

    设计说明：
    1. 使用本地目录模拟 `private/public` 双桶语义，分别映射到 `<base_path>/private` 与 `<base_path>/public`。
    2. 桌面端默认直接返回 `file://` 绝对路径，不额外施加权限控制。
    3. 若配置了 `TA_STORE_EXTERNAL_BASE_URL`，则统一生成外部 URL；private 资源的临时权限由 Nginx/网关侧负责。
    """

    _IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".svg", ".avif"}
    _PUBLIC_ROLE_SET = {"avatar"}
    _PUBLIC_DOMAIN_SET = {"space", "project", "agent", "character", "tool", "platform", "model_series"}

    def __init__(
        self,
        base_path: Optional[str] = None,
        external_base_url: Optional[str] = None,
        external_path_prefix: Optional[str] = None,
    ):
        self.base_path = Path(base_path or settings.TA_STORE_LOCAL_BASE_PATH).expanduser().resolve()
        self.private_root = self.base_path / "private"
        self.public_root = self.base_path / "public"
        self.private_root.mkdir(parents=True, exist_ok=True)
        self.public_root.mkdir(parents=True, exist_ok=True)

        self._ttl_meta_avatar = settings.TA_STORE_CACHE_TTL_META_AVATAR_SECONDS
        self._ttl_other_image = settings.TA_STORE_CACHE_TTL_OTHER_IMAGE_SECONDS
        self._ttl_default = settings.TA_STORE_CACHE_TTL_DEFAULT_SECONDS

        self._external_base_url = (external_base_url if external_base_url is not None else settings.TA_STORE_EXTERNAL_BASE_URL).strip()
        self._external_path_prefix = self._normalize_path_prefix(
            external_path_prefix if external_path_prefix is not None else settings.TA_STORE_EXTERNAL_PATH_PREFIX
        )
        self._secure_link_secret = (settings.TA_STORE_SECURE_LINK_SECRET or "").strip()

    def _normalize_path_prefix(self, path_prefix: str) -> str:
        if not path_prefix:
            return ""
        normalized = path_prefix.strip()
        if normalized == "/":
            return ""
        if not normalized.startswith("/"):
            normalized = f"/{normalized}"
        return normalized.rstrip("/")

    def _fmt_space(self, space_id: str) -> str:
        return space_id if space_id.startswith("space_") else f"space_{space_id}"

    def _fmt_proj(self, project_id: str) -> str:
        return project_id if project_id.startswith("project_") else f"project_{project_id}"

    def _is_public_bucket(self, bucket: str) -> bool:
        return bucket == "public"

    def _is_image_key(self, object_key: str) -> bool:
        return PurePosixPath(object_key).suffix.lower() in self._IMAGE_EXTS

    def _get_cache_config(self, object_key: str) -> tuple[CacheGroup, int]:
        if "/meta/avatar/" in object_key or "/avatar/" in object_key:
            return CacheGroup.META_AVATAR, self._ttl_meta_avatar
        if self._is_image_key(object_key):
            return CacheGroup.OTHER_IMAGE, self._ttl_other_image
        return CacheGroup.DEFAULT, self._ttl_default

    def _resolve_root(self, bucket: str) -> Path:
        if bucket == "public":
            return self.public_root
        if bucket == "private":
            return self.private_root
        raise ValueError(f"未知的本地 bucket: {bucket}")

    def _safe_file_path(self, bucket: str, object_key: str) -> Path:
        root = self._resolve_root(bucket)
        file_path = (root / object_key).resolve()
        if not str(file_path).startswith(str(root.resolve())):
            raise ValueError(f"非法路径: {object_key}")
        return file_path

    def _build_descriptor(self, bucket: str, object_key: str, cache_control: Optional[str] = None) -> FileResourceDescriptor:
        cache_group, ttl = self._get_cache_config(object_key)
        access_mode = AccessMode.PUBLIC if self._is_public_bucket(bucket) else AccessMode.PRESIGNED
        return FileResourceDescriptor(
            uri=self._build_storage_uri(bucket, object_key),
            bucket=bucket,
            object_key=object_key,
            cache_group=cache_group,
            access_mode=access_mode,
            cache_ttl_seconds=ttl,
            cache_control=cache_control or f"public, max-age={ttl}",
            secure_link_expires_seconds=ttl,
        )

    def _build_storage_uri(self, bucket: str, object_key: str) -> str:
        file_path = self._safe_file_path(bucket, object_key)
        return file_path.as_uri()

    def _parse_storage_uri(self, uri: str) -> tuple[str, str]:
        parsed = urlparse(uri)
        if parsed.scheme != "file":
            raise ValueError(f"LocalFileManageStore 仅支持 file:// URI: {uri}")

        file_path = Path(parsed.path).resolve()
        for bucket, root in (("private", self.private_root), ("public", self.public_root)):
            root_resolved = root.resolve()
            if str(file_path).startswith(str(root_resolved)):
                return bucket, file_path.relative_to(root_resolved).as_posix()
        raise ValueError(f"URI 不属于当前 LocalFileManageStore 根目录: {uri}")

    def _resolve_metadata_object_key(self, object_key: str) -> str:
        normalized_key = object_key.strip("/")
        if normalized_key.endswith("/metadata.json") or normalized_key == "metadata.json":
            return normalized_key
        for marker in ("/raw/", "/normalized/", "/artificial/"):
            if marker in normalized_key:
                return f"{normalized_key.split(marker, 1)[0]}/metadata.json"
        parent = PurePosixPath(normalized_key).parent.as_posix()
        if not parent or parent == ".":
            raise ValueError(f"无法从 URI 推导 metadata.json 路径: {object_key}")
        return f"{parent}/metadata.json"

    def _resolve_variant_relative_path(self, spec: ResourceFileSpec) -> str:
        variant_name = spec.variant.value.strip("/")
        if not variant_name:
            raise ValueError("variant 不能为空")
        if "." in PurePosixPath(variant_name).name:
            return variant_name
        ext = spec.file_type.lstrip(".")
        filename = f"origin.{ext}" if variant_name == "raw" else f"data.{ext}"
        return f"{variant_name}/{filename}"

    def _temp_base_prefix(self, allocation: TempBucketAllocation, spec: ResourceFileSpec) -> str:
        return f"{allocation.bucket_prefix}{spec.resource_id}/"

    def _require_role(self, spec: ResourceFileSpec, scene: str) -> str:
        if spec.role is None:
            raise ValueError(f"{scene} 必须提供 role")
        return spec.role.value

    def _forbid_role(self, spec: ResourceFileSpec, scene: str) -> None:
        if spec.role is not None:
            raise ValueError(f"{scene} 不允许提供 role，当前传入: {spec.role.value}")

    def _resolve_move_target(self, target: FileMoveTarget) -> tuple[str, str]:
        has_uri = bool(target.uri)
        has_locator = target.locator is not None or target.relative_path is not None
        if has_uri == has_locator:
            raise ValueError("移动目标必须二选一：要么提供 uri，要么提供 locator + relative_path")
        if target.uri:
            return self._parse_storage_uri(target.uri)
        if target.locator is None or not target.relative_path:
            raise ValueError("使用 locator 作为移动目标时，必须同时提供 locator 与 relative_path")
        return target.locator.bucket, f"{target.locator.prefix}{target.relative_path.lstrip('/')}"

    def resolve_bucket(
        self,
        resource_domain: str,
        role: Optional[str],
        visibility: Optional[BucketVisibility] = None,
    ) -> str:
        if visibility == BucketVisibility.PUBLIC:
            return "public"
        if visibility == BucketVisibility.PRIVATE:
            return "private"
        normalized_domain = resource_domain.lower()
        normalized_role = (role or "").lower()
        if normalized_domain in self._PUBLIC_DOMAIN_SET and normalized_role in self._PUBLIC_ROLE_SET:
            return "public"
        return "private"

    async def ensure_project_storage(self, space_id: str, project_id: str, description: str = "") -> StorageLocator:
        del description
        prefix = f"resources/{self._fmt_space(space_id)}/{self._fmt_proj(project_id)}/"
        self._safe_file_path("private", prefix).mkdir(parents=True, exist_ok=True)
        return StorageLocator(bucket="private", prefix=prefix)

    async def ensure_space_storage(self, space_id: str, description: str = "") -> StorageLocator:
        del description
        prefix = f"resources/{self._fmt_space(space_id)}/"
        self._safe_file_path("private", prefix).mkdir(parents=True, exist_ok=True)
        return StorageLocator(bucket="private", prefix=prefix)

    async def resolve_space_path(self, space_id: str, resource_type: str, resource_id: str) -> str:
        s_id = self._fmt_space(space_id)
        if resource_id:
            return f"resources/{s_id}/{resource_type}_{resource_id}/"
        return f"resources/{s_id}/{resource_type}/"

    async def resolve_project_path(self, space_id: str, project_id: str, resource_type: str, resource_id: str) -> str:
        s_id = self._fmt_space(space_id)
        p_id = self._fmt_proj(project_id)
        if resource_type.lower() == "meta" and resource_id == "":
            return f"resources/{s_id}/{p_id}/meta/"
        return f"resources/{s_id}/{p_id}/{resource_type}/{resource_id}/"

    async def put_resource_file(
        self,
        locator: StorageLocator,
        relative_path: str,
        local_file_path: str,
        content_type: Optional[str] = None,
    ) -> str:
        del content_type
        object_key = f"{locator.prefix}{relative_path}"
        file_path = self._safe_file_path(locator.bucket, object_key)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(local_file_path, file_path)
        stat = file_path.stat()
        return f"{int(stat.st_mtime_ns)}-{stat.st_size}"

    async def get_resource_file(self, locator: StorageLocator, relative_path: str) -> bytes:
        object_key = f"{locator.prefix}{relative_path}"
        return self._safe_file_path(locator.bucket, object_key).read_bytes()

    async def _count_objects_with_prefix(self, bucket: str, prefix: str) -> int:
        prefix_path = self._safe_file_path(bucket, prefix)
        if not prefix_path.exists():
            return 0
        return sum(1 for path in prefix_path.rglob("*") if path.is_file())

    async def allocate_temp_bucket(self, space_id: str, year: int) -> TempBucketAllocation:
        s_id = self._fmt_space(space_id)
        index = 0
        max_files_per_bucket = 1000
        while True:
            prefix = f"temp/{s_id}/{year}_bucket_{index}/"
            if await self._count_objects_with_prefix("private", prefix) < max_files_per_bucket:
                break
            index += 1
        return TempBucketAllocation(
            space_id=space_id,
            year=year,
            bucket="private",
            bucket_index=index,
            bucket_prefix=f"temp/{s_id}/{year}_bucket_{index}/",
            max_files_per_bucket=max_files_per_bucket,
        )

    async def create_temp_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        self._forbid_role(spec, "临时文件")
        allocation = await self.allocate_temp_bucket(space_id, datetime.now(timezone.utc).year)
        base_prefix = self._temp_base_prefix(allocation, spec)
        return await self._create_standard_file(base_prefix, spec, local_file_path, resource_domain="temp", visibility=BucketVisibility.PRIVATE)

    async def read_temp_file(self, temp_uri: str) -> bytes:
        bucket, object_key = self._parse_storage_uri(temp_uri)
        return self._safe_file_path(bucket, object_key).read_bytes()

    async def read_file_by_uri(self, uri: str) -> bytes:
        bucket, object_key = self._parse_storage_uri(uri)
        if object_key.startswith("temp/"):
            return await self.read_temp_file(uri)
        return self._safe_file_path(bucket, object_key).read_bytes()

    async def delete_temp_file(self, temp_uri: str) -> FileDeleteResult:
        bucket, object_key = self._parse_storage_uri(temp_uri)
        file_path = self._safe_file_path(bucket, object_key)
        if file_path.exists():
            file_path.unlink()
        return FileDeleteResult(descriptor=self._build_descriptor(bucket, object_key, cache_control=""), deleted=True)

    def _build_external_url(
        self,
        bucket: str,
        object_key: str,
        revision: Optional[str],
        expires_at: Optional[int] = None,
        signature: Optional[str] = None,
    ) -> str:
        object_path = quote(object_key.lstrip("/"), safe="/")
        path = f"{self._external_path_prefix}/{bucket}/{object_path}" if self._external_path_prefix else f"/{bucket}/{object_path}"
        url = f"{self._external_base_url.rstrip('/')}{path}"
        query_items = dict(parse_qsl(urlparse(url).query, keep_blank_values=True))
        if revision:
            query_items["rev"] = revision
        if expires_at is not None:
            query_items["expires"] = str(expires_at)
        if signature:
            query_items["sig"] = signature
        parsed = urlparse(url)
        return urlunparse(parsed._replace(query=urlencode(query_items, doseq=True)))

    async def generate_secure_link(self, uri: str, variant: str = "raw", revision: Optional[str] = None) -> SecureLinkResult:
        del variant
        bucket, object_key = self._parse_storage_uri(uri)
        cache_group, ttl_seconds = self._get_cache_config(object_key)
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)

        if not self._external_base_url:
            # 桌面端或本机模式：直接返回 file:// 路径，不额外处理权限。
            return SecureLinkResult(
                url=uri,
                uri=uri,
                cache_group=cache_group,
                access_mode=AccessMode.PUBLIC,
                cache_ttl_seconds=ttl_seconds,
                cache_control=f"public, max-age={ttl_seconds}",
                expires_at_utc=expires_at,
            )

        access_mode = AccessMode.PUBLIC if self._is_public_bucket(bucket) else AccessMode.PRESIGNED
        expires_epoch = int(expires_at.timestamp()) if access_mode == AccessMode.PRESIGNED else None
        signature = None
        if access_mode == AccessMode.PRESIGNED and expires_epoch is not None and self._secure_link_secret:
            external_path = f"{self._external_path_prefix}/{bucket}/{quote(object_key.lstrip('/'), safe='/')}" if self._external_path_prefix else f"/{bucket}/{quote(object_key.lstrip('/'), safe='/')}"
            signature = generate_secure_link_signature(external_path, expires_epoch, self._secure_link_secret)

        url = self._build_external_url(bucket, object_key, revision, expires_epoch, signature)
        return SecureLinkResult(
            url=url,
            uri=uri,
            cache_group=cache_group,
            access_mode=access_mode,
            cache_ttl_seconds=ttl_seconds,
            cache_control=f"public, max-age={ttl_seconds}",
            expires_at_utc=expires_at,
        )

    async def move_temp_resource(self, source_uri: str, target: FileMoveTarget) -> FileWriteResult:
        src_bucket, src_key = self._parse_storage_uri(source_uri)
        if not src_key.startswith("temp/"):
            raise ValueError(f"无效的临时资源 URI，无法执行移动: {source_uri}")
        target_bucket, target_key = self._resolve_move_target(target)
        src_path = self._safe_file_path(src_bucket, src_key)
        dst_path = self._safe_file_path(target_bucket, target_key)
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src_path), str(dst_path))
        stat = dst_path.stat()
        return FileWriteResult(
            descriptor=self._build_descriptor(target_bucket, target_key),
            etag=f"{int(stat.st_mtime_ns)}-{stat.st_size}",
        )

    async def update_resource_metadata(self, uri: str, metadata_content: bytes) -> FileWriteResult:
        bucket, object_key = self._parse_storage_uri(uri)
        metadata_key = self._resolve_metadata_object_key(object_key)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as temp_file:
            temp_file.write(metadata_content)
            temp_path = temp_file.name

        try:
            etag = await self.put_resource_file(
                locator=StorageLocator(bucket=bucket, prefix=f"{PurePosixPath(metadata_key).parent.as_posix()}/"),
                relative_path="metadata.json",
                local_file_path=temp_path,
                content_type="application/json; charset=utf-8",
            )
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

        return FileWriteResult(descriptor=self._build_descriptor(bucket, metadata_key), etag=etag)

    async def _create_standard_file(
        self,
        base_prefix: str,
        spec: ResourceFileSpec,
        local_file_path: str,
        resource_domain: str,
        visibility: Optional[BucketVisibility] = None,
    ) -> FileWriteResult:
        bucket = self.resolve_bucket(resource_domain=resource_domain, role=spec.role, visibility=visibility)
        rel_path = self._resolve_variant_relative_path(spec)
        etag = await self.put_resource_file(StorageLocator(bucket=bucket, prefix=base_prefix), rel_path, local_file_path)
        object_key = f"{base_prefix}{rel_path}"
        return FileWriteResult(descriptor=self._build_descriptor(bucket, object_key), etag=etag)

    async def _read_standard_file(
        self,
        base_prefix: str,
        spec: ResourceFileSpec,
        resource_domain: str,
        visibility: Optional[BucketVisibility] = None,
    ) -> bytes:
        bucket = self.resolve_bucket(resource_domain=resource_domain, role=spec.role, visibility=visibility)
        rel_path = self._resolve_variant_relative_path(spec)
        return await self.get_resource_file(StorageLocator(bucket=bucket, prefix=base_prefix), rel_path)

    async def _delete_standard_file(
        self,
        base_prefix: str,
        spec: ResourceFileSpec,
        resource_domain: str,
        visibility: Optional[BucketVisibility] = None,
    ) -> FileDeleteResult:
        bucket = self.resolve_bucket(resource_domain=resource_domain, role=spec.role, visibility=visibility)
        rel_path = self._resolve_variant_relative_path(spec)
        object_key = f"{base_prefix}{rel_path}"
        file_path = self._safe_file_path(bucket, object_key)
        if file_path.exists():
            file_path.unlink()
        return FileDeleteResult(descriptor=self._build_descriptor(bucket, object_key, cache_control=""), deleted=True)

    async def create_space_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_space_path(space_id, "meta", "")
        role = self._require_role(spec, "空间级文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="space")

    async def read_space_file(self, space_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_space_path(space_id, "meta", "")
        role = self._require_role(spec, "空间级文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="space")

    async def update_space_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_space_file(space_id, spec, local_file_path)

    async def delete_space_file(self, space_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_space_path(space_id, "meta", "")
        role = self._require_role(spec, "空间级文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="space")

    async def create_model_series_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_space_path(space_id, "model_series", spec.resource_id)
        role = self._require_role(spec, "模型系列文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="model_series")

    async def read_model_series_file(self, space_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_space_path(space_id, "model_series", spec.resource_id)
        role = self._require_role(spec, "模型系列文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="model_series")

    async def update_model_series_file(self, space_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_model_series_file(space_id, spec, local_file_path)

    async def delete_model_series_file(self, space_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_space_path(space_id, "model_series", spec.resource_id)
        role = self._require_role(spec, "模型系列文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="model_series")

    async def create_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "meta", "")
        role = self._require_role(spec, "项目级文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="project")

    async def read_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "meta", "")
        role = self._require_role(spec, "项目级文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="project")

    async def update_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_project_file(space_id, project_id, spec, local_file_path)

    async def delete_project_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "meta", "")
        role = self._require_role(spec, "项目级文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="project")

    async def create_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "agent", spec.resource_id)
        role = self._require_role(spec, "Agent 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="agent")

    async def read_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "agent", spec.resource_id)
        role = self._require_role(spec, "Agent 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="agent")

    async def update_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_agent_file(space_id, project_id, spec, local_file_path)

    async def delete_agent_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "agent", spec.resource_id)
        role = self._require_role(spec, "Agent 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="agent")

    async def create_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "character", spec.resource_id)
        role = self._require_role(spec, "Character 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="character")

    async def read_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "character", spec.resource_id)
        role = self._require_role(spec, "Character 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="character")

    async def update_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_character_file(space_id, project_id, spec, local_file_path)

    async def delete_character_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "character", spec.resource_id)
        role = self._require_role(spec, "Character 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="character")

    async def create_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "tool", spec.resource_id)
        role = self._require_role(spec, "Tool 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="tool")

    async def read_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "tool", spec.resource_id)
        role = self._require_role(spec, "Tool 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="tool")

    async def update_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_tool_file(space_id, project_id, spec, local_file_path)

    async def delete_tool_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "tool", spec.resource_id)
        role = self._require_role(spec, "Tool 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="tool")

    async def create_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "platform", spec.resource_id)
        role = self._require_role(spec, "Platform 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="platform")

    async def read_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "platform", spec.resource_id)
        role = self._require_role(spec, "Platform 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="platform")

    async def update_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_platform_file(space_id, project_id, spec, local_file_path)

    async def delete_platform_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "platform", spec.resource_id)
        role = self._require_role(spec, "Platform 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="platform")

    async def create_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "mcp", spec.resource_id)
        role = self._require_role(spec, "MCP 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="mcp")

    async def read_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "mcp", spec.resource_id)
        role = self._require_role(spec, "MCP 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="mcp")

    async def update_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_mcp_file(space_id, project_id, spec, local_file_path)

    async def delete_mcp_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "mcp", spec.resource_id)
        role = self._require_role(spec, "MCP 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="mcp")

    async def create_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "skills", spec.resource_id)
        role = self._require_role(spec, "Skills 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="skills")

    async def read_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "skills", spec.resource_id)
        role = self._require_role(spec, "Skills 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="skills")

    async def update_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_skills_file(space_id, project_id, spec, local_file_path)

    async def delete_skills_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "skills", spec.resource_id)
        role = self._require_role(spec, "Skills 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="skills")

    async def create_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        self._forbid_role(spec, "知识资源文件")
        prefix = await self.resolve_project_path(space_id, project_id, "knowledge_file", spec.resource_id)
        return await self._create_standard_file(prefix, spec, local_file_path, resource_domain="knowledge")

    async def read_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        self._forbid_role(spec, "知识资源文件")
        prefix = await self.resolve_project_path(space_id, project_id, "knowledge_file", spec.resource_id)
        return await self._read_standard_file(prefix, spec, resource_domain="knowledge")

    async def update_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_knowledge_file(space_id, project_id, spec, local_file_path)

    async def delete_knowledge_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        self._forbid_role(spec, "知识资源文件")
        prefix = await self.resolve_project_path(space_id, project_id, "knowledge_file", spec.resource_id)
        return await self._delete_standard_file(prefix, spec, resource_domain="knowledge")

    async def create_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "secret", spec.resource_id)
        role = self._require_role(spec, "Secret 文件")
        return await self._create_standard_file(f"{prefix}{role}/", spec, local_file_path, resource_domain="secret")

    async def read_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> bytes:
        prefix = await self.resolve_project_path(space_id, project_id, "secret", spec.resource_id)
        role = self._require_role(spec, "Secret 文件")
        return await self._read_standard_file(f"{prefix}{role}/", spec, resource_domain="secret")

    async def update_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec, local_file_path: str) -> FileWriteResult:
        return await self.create_secret_file(space_id, project_id, spec, local_file_path)

    async def delete_secret_file(self, space_id: str, project_id: str, spec: ResourceFileSpec) -> FileDeleteResult:
        prefix = await self.resolve_project_path(space_id, project_id, "secret", spec.resource_id)
        role = self._require_role(spec, "Secret 文件")
        return await self._delete_standard_file(f"{prefix}{role}/", spec, resource_domain="secret")