"""文件管理后端工厂。"""

from __future__ import annotations

from turbo_agent_store.files.file_manage.base import FileBackend, FileManageStore
from turbo_agent_store.files.file_manage.local_store import LocalFileManageStore
from turbo_agent_store.files.file_manage.s3_store import S3FileManageStore
from turbo_agent_store.settings import settings


def create_file_manage_store(file_backend: str | FileBackend | None = None) -> FileManageStore:
    """根据配置创建文件管理后端实例。"""

    backend_value = (file_backend.value if isinstance(file_backend, FileBackend) else file_backend) or settings.TA_STORE_FILE_BACKEND
    normalized_backend = backend_value.strip().lower()

    if normalized_backend == FileBackend.LOCAL.value:
        return LocalFileManageStore()
    if normalized_backend == FileBackend.S3.value:
        return S3FileManageStore()

    raise ValueError(f"不支持的文件管理后端: {backend_value}")