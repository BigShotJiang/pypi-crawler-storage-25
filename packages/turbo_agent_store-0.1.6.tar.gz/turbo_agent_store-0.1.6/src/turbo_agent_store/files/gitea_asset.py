"""
Gitea 资产管理实现

基于 Gitea API，提供统一的文件/图片资源管理能力。
"""

import base64
import json
from datetime import datetime
from typing import Any
from urllib import error, parse, request

from turbo_agent_store.interface.asset import (
    AssetRepositoryStore,
    KnowledgeResourceProvisionResult,
    KnowledgeResourceProvisionSpec,
    ManagedPathResult,
    ManagedPathSpec,
    ProjectSyncResult,
    ProjectSyncSpec,
)


class GiteaAssetRepositoryStore(AssetRepositoryStore):
    """Gitea 资产仓储实现。"""

    def __init__(
        self,
        base_url: str,
        token: str,
        timeout_seconds: int = 20,
    ):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout_seconds = timeout_seconds

    async def create_project_and_sync(self, spec: ProjectSyncSpec) -> ProjectSyncResult:
        """创建项目仓库并完成后台同步。"""
        repo_info = self._ensure_repo(spec.org_name, spec.repo_name, spec.description, spec.default_branch)
        await self.ensure_default_public(spec.org_name, spec.repo_name)
        self._sync_project_manifest(spec)

        return ProjectSyncResult(
            org_name=spec.org_name,
            repo_name=spec.repo_name,
            project_id=spec.project_id,
            repo_http_url=repo_info["html_url"],
            repo_clone_url=repo_info["clone_url"],
            default_branch=spec.default_branch,
            is_public=True,
            synced_at=datetime.now(),
        )

    async def create_managed_path(self, spec: ManagedPathSpec) -> ManagedPathResult:
        """按路径模板渲染路径。"""
        rendered = self._render_path(
            template=spec.template,
            project_id=spec.project_id,
            resource_type=spec.resource_type,
            resource_id=spec.resource_id,
            filename=spec.filename,
            workset_id=spec.workset_id,
            org_name=spec.org_name,
            repo_name=spec.repo_name,
        )
        return ManagedPathResult(rendered_path=rendered, created_at=datetime.now())

    async def provide_knowledge_resource(
        self,
        spec: KnowledgeResourceProvisionSpec,
    ) -> KnowledgeResourceProvisionResult:
        """自动提供指定 KnowledgeResource。"""
        self._ensure_repo(spec.org_name, spec.repo_name, "", spec.default_branch)
        await self.ensure_default_public(spec.org_name, spec.repo_name)

        target_repo_path = self._render_path(
            template=spec.path_template,
            project_id=spec.project_id,
            resource_type="knowledge",
            resource_id=spec.resource_id,
            filename=spec.filename,
        )

        commit_message = spec.commit_message or f"chore(resource): 提供知识资源 {spec.resource_id}"
        commit_hash = self._upsert_repo_file(
            org_name=spec.org_name,
            repo_name=spec.repo_name,
            repo_path=target_repo_path,
            content=spec.content,
            branch=spec.default_branch,
            message=commit_message,
        )

        raw_url = (
            f"{self.base_url}/{parse.quote(spec.org_name)}/{parse.quote(spec.repo_name)}"
            f"/raw/branch/{parse.quote(spec.default_branch)}/{parse.quote(target_repo_path, safe='/')}"
        )

        return KnowledgeResourceProvisionResult(
            repo_path=target_repo_path,
            raw_url=raw_url,
            commit_hash=commit_hash,
            provided_at=datetime.now(),
        )

    async def ensure_default_public(self, org_name: str, repo_name: str) -> bool:
        """确保仓库默认公开。"""
        payload = {"private": False}
        self._request_json(
            method="PATCH",
            path=f"/api/v1/repos/{parse.quote(org_name)}/{parse.quote(repo_name)}",
            payload=payload,
        )
        return True

    def _render_path(
        self,
        template: str,
        project_id: str,
        resource_type: str,
        resource_id: str,
        filename: str | None = None,
        workset_id: str | None = None,
        org_name: str | None = None,
        repo_name: str | None = None,
    ) -> str:
        now = datetime.now()
        values = {
            "project_id": project_id,
            "resource_type": resource_type,
            "resource_id": resource_id,
            "filename": filename or "",
            "workset_id": workset_id or "",
            "org": org_name or "",
            "repo": repo_name or "",
            "yyyy": now.strftime("%Y"),
            "mm": now.strftime("%m"),
            "dd": now.strftime("%d"),
        }
        rendered = template.format(**values).strip("/")
        if not rendered:
            raise ValueError("路径模板渲染结果为空")
        return rendered

    def _ensure_repo(
        self,
        org_name: str,
        repo_name: str,
        description: str,
        default_branch: str,
    ) -> dict[str, Any]:
        get_path = f"/api/v1/repos/{parse.quote(org_name)}/{parse.quote(repo_name)}"
        try:
            existing = self._request_json("GET", get_path)
            return {
                "html_url": existing.get("html_url", f"{self.base_url}/{org_name}/{repo_name}"),
                "clone_url": existing.get("clone_url", f"{self.base_url}/{org_name}/{repo_name}.git"),
            }
        except RuntimeError as exc:
            if "HTTP 404" not in str(exc):
                raise

        payload = {
            "name": repo_name,
            "description": description,
            "private": False,
            "auto_init": True,
            "default_branch": default_branch,
        }
        created = self._request_json(
            method="POST",
            path=f"/api/v1/orgs/{parse.quote(org_name)}/repos",
            payload=payload,
        )
        return {
            "html_url": created.get("html_url", f"{self.base_url}/{org_name}/{repo_name}"),
            "clone_url": created.get("clone_url", f"{self.base_url}/{org_name}/{repo_name}.git"),
        }

    def _sync_project_manifest(self, spec: ProjectSyncSpec) -> None:
        """通过 API 写入项目同步清单，标记后台已同步。"""
        manifest_path = f".turbo/project_sync/{spec.project_id}.json"
        manifest = {
            "project_id": spec.project_id,
            "org_name": spec.org_name,
            "repo_name": spec.repo_name,
            "default_branch": spec.default_branch,
            "description": spec.description,
            "local_repo_path": spec.local_repo_path,
            "synced_at": datetime.now().isoformat(),
        }
        self._upsert_repo_file(
            org_name=spec.org_name,
            repo_name=spec.repo_name,
            repo_path=manifest_path,
            content=json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"),
            message=f"chore(sync): 同步项目 {spec.project_id}",
            branch=spec.default_branch,
        )

    def _upsert_repo_file(
        self,
        org_name: str,
        repo_name: str,
        repo_path: str,
        content: bytes,
        message: str,
        branch: str,
    ) -> str:
        """通过 Gitea Contents API 创建或更新文件。"""
        clean_path = self._normalize_repo_path(repo_path)
        sha = self._get_file_sha(org_name=org_name, repo_name=repo_name, repo_path=clean_path, branch=branch)
        payload: dict[str, Any] = {
            "content": base64.b64encode(content).decode("ascii"),
            "message": message,
            "branch": branch,
        }
        if sha:
            payload["sha"] = sha

        response = self._request_json(
            method="PUT",
            path=(
                f"/api/v1/repos/{parse.quote(org_name)}/{parse.quote(repo_name)}"
                f"/contents/{parse.quote(clean_path, safe='/')}"
            ),
            payload=payload,
        )
        commit = response.get("commit") or {}
        commit_sha = commit.get("sha")
        if not commit_sha:
            raise RuntimeError(f"写入文件成功但未返回 commit sha: {clean_path}")
        return commit_sha

    def _get_file_sha(self, org_name: str, repo_name: str, repo_path: str, branch: str) -> str | None:
        """读取文件 sha；不存在返回 None。"""
        try:
            response = self._request_json(
                method="GET",
                path=(
                    f"/api/v1/repos/{parse.quote(org_name)}/{parse.quote(repo_name)}"
                    f"/contents/{parse.quote(repo_path, safe='/')}?ref={parse.quote(branch)}"
                ),
            )
            sha = response.get("sha")
            return sha if isinstance(sha, str) and sha else None
        except RuntimeError as exc:
            if "HTTP 404" in str(exc):
                return None
            raise

    def _normalize_repo_path(self, repo_path: str) -> str:
        """规范化并校验仓库内路径。"""
        cleaned = repo_path.strip().strip("/")
        if not cleaned:
            raise ValueError("仓库路径不能为空")
        parts = [part for part in cleaned.split("/") if part not in ("", ".")]
        if any(part == ".." for part in parts):
            raise ValueError(f"非法仓库路径: {repo_path}")
        return "/".join(parts)

    def _request_json(self, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        data = None
        headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/json",
        }
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"

        req = request.Request(url=url, data=data, headers=headers, method=method)
        try:
            with request.urlopen(req, timeout=self.timeout_seconds) as resp:
                body = resp.read().decode("utf-8")
                if not body:
                    return {}
                return json.loads(body)
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="ignore")
            raise RuntimeError(f"HTTP {exc.code} 调用失败: {method} {path} | {detail}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"网络请求失败: {method} {path} | {exc}") from exc
