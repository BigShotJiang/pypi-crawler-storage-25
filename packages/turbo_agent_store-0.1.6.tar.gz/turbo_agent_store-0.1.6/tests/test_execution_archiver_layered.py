import unittest
import importlib.util
import sys
from pathlib import Path

from turbo_agent_core.schema.events import (
	ContentActionEndEvent,
	ContentActionEndPayload,
	ContentActionResultEndEvent,
	ContentActionResultEndPayload,
	ContentActionStartEvent,
	ContentActionStartPayload,
	ContentTextEndEvent,
	ContentTextEndPayload,
	ContentTextStartEvent,
	ContentTextStartPayload,
	ExecutorMetadata,
	RunLifecycleCompletedEvent,
	RunLifecycleCompletedPayload,
	RunLifecycleCreatedEvent,
	RunLifecycleCreatedPayload,
	UserInfo,
)
from turbo_agent_core.schema.states import Conversation


class InMemoryStateStore:
	def __init__(self):
		self.conversations = {}
		self.messages = {}
		self.react_rounds = {}
		self.actions = {}
		self.tool_call_records = {}

	async def get_conversation(self, conversation_id: str, **kwargs):
		return self.conversations.get(conversation_id)

	async def save_conversation(self, conversation: Conversation, **kwargs):
		self.conversations[conversation.id] = conversation.model_copy(deep=True)
		return conversation.id

	async def save_message(self, message, conversation_id: str, **kwargs):
		self.messages[message.id] = message.model_copy(deep=True)
		return message.id

	async def save_react_round(self, react_round, message_id: str, **kwargs):
		self.react_rounds[react_round.id] = react_round.model_copy(deep=True)
		return react_round.id

	async def save_action(self, action, message_id: str, **kwargs):
		self.actions[action.id] = action.model_copy(deep=True)
		return action.id

	async def save_tool_call_record(self, record, **kwargs):
		self.tool_call_records[record.id] = record.model_copy(deep=True)
		return record.id


_EXECUTION_PATH = Path(__file__).resolve().parents[1] / "src" / "turbo_agent_store" / "stream" / "execution.py"
_EXECUTION_SPEC = importlib.util.spec_from_file_location("turbo_agent_store_stream_execution_test", _EXECUTION_PATH)
_EXECUTION_MODULE = importlib.util.module_from_spec(_EXECUTION_SPEC)
assert _EXECUTION_SPEC.loader is not None
sys.modules[_EXECUTION_SPEC.name] = _EXECUTION_MODULE
_EXECUTION_SPEC.loader.exec_module(_EXECUTION_MODULE)
ExecutionArchiver = _EXECUTION_MODULE.ExecutionArchiver


class TestExecutionArchiverLayered(unittest.IsolatedAsyncioTestCase):
	BASE_TS = 1700000000000

	async def test_archiver_saves_each_layer_without_nested_payload(self):
		store = InMemoryStateStore()
		conversation = Conversation(id="conv-1")
		await store.save_conversation(conversation)

		archiver = ExecutionArchiver(trace_id="trace-root", state_store=store, flush_interval_s=0.0)
		user = UserInfo(id="user-1")
		executor = ExecutorMetadata(id="agent-root", name="Root Agent")

		events = [
			RunLifecycleCreatedEvent(
				trace_id="trace-root",
				run_id="run-root-1",
				timestamp=self.BASE_TS + 10,
				executor_id="AGENT:writer@proj",
				executor_metadata=executor,
				user_metadata=user,
				payload=RunLifecycleCreatedPayload(input_data={"conversation_id": "conv-1", "user_id": "user-1"}),
			),
			ContentTextStartEvent(
				trace_id="trace-root",
				run_id="run-root-1",
				timestamp=self.BASE_TS + 20,
				executor_id="AGENT:writer@proj",
				react_id="react-1",
				payload=ContentTextStartPayload(format="plain"),
			),
			ContentTextEndEvent(
				trace_id="trace-root",
				run_id="run-root-1",
				timestamp=self.BASE_TS + 30,
				executor_id="AGENT:writer@proj",
				react_id="react-1",
				payload=ContentTextEndPayload(full_text="你好"),
			),
			ContentActionStartEvent(
				trace_id="trace-root",
				run_id="run-root-1",
				timestamp=self.BASE_TS + 40,
				executor_id="AGENT:writer@proj",
				react_id="react-1",
				action_id="action-1",
				payload=ContentActionStartPayload(name="TOOL:search@proj/tool@1.0.0", call_type="TOOL", intent="检索"),
			),
			ContentActionEndEvent(
				trace_id="trace-root",
				run_id="run-root-1",
				timestamp=self.BASE_TS + 50,
				executor_id="AGENT:writer@proj",
				react_id="react-1",
				action_id="action-1",
				payload=ContentActionEndPayload(arguments={"query": "hello"}, intent="检索 hello"),
			),
			ContentActionResultEndEvent(
				trace_id="trace-root",
				run_id="run-root-1",
				timestamp=self.BASE_TS + 60,
				executor_id="AGENT:writer@proj",
				react_id="react-1",
				action_id="action-1",
				payload=ContentActionResultEndPayload(record_id="record-1", full_result={"answer": "ok"}, status="success"),
			),
			RunLifecycleCompletedEvent(
				trace_id="trace-root",
				run_id="run-root-1",
				timestamp=self.BASE_TS + 70,
				executor_id="AGENT:writer@proj",
				payload=RunLifecycleCompletedPayload(output={"audit": "done"}, usage={"tokenCost": 1}),
			),
		]

		for event in events:
			await archiver.on_event(event)

		await archiver.force_flush()

		self.assertIn("trace-root", store.messages)
		self.assertEqual(store.messages["trace-root"].reactRounds, [])
		self.assertEqual(store.messages["trace-root"].actions, [])
		self.assertIn("react-1", store.react_rounds)
		self.assertEqual(store.react_rounds["react-1"].actions, [])
		self.assertIn("action-1", store.actions)
		self.assertEqual(store.actions["action-1"].records, [])
		self.assertIn("record-1", store.tool_call_records)


if __name__ == "__main__":
	unittest.main()