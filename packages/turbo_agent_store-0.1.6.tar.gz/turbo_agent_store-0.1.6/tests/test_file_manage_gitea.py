# coding=utf-8
from __future__ import annotations

import pytest

from turbo_agent_store.files.file_manage.base import FileType, ResourceFileSpec
from turbo_agent_store.files.file_manage.gitea import GiteaFileManageStore


@pytest.fixture
def gitea_store(monkeypatch: pytest.MonkeyPatch) -> GiteaFileManageStore:
    """构造一个不触发真实网络请求的 GiteaFileManageStore。"""
    store = GiteaFileManageStore(
        gitea_base_url="https://gitea.example.com",
        gitea_token="token",
        assets_base_url="https://assets.example.com",
    )
    monkeypatch.setattr(store, "_ensure_repo", lambda owner, repo, description, branch: None)
    return store


@pytest.mark.asyncio
async def test_create_agent_file_with_avatar_type(
    gitea_store: GiteaFileManageStore,
    monkeypatch: pytest.MonkeyPatch,
):
    captured: dict[str, str] = {}

    async def _fake_put_resource_file(locator, relative_path, content, content_type=None, commit_message=None):
        del content_type
        captured["owner"] = locator.owner
        captured["repo"] = locator.repo
        captured["relative_path"] = relative_path
        captured["commit_message"] = commit_message or ""
        captured["content"] = content.decode("utf-8")
        return "sha-create"

    monkeypatch.setattr(gitea_store, "put_resource_file", _fake_put_resource_file)

    spec = ResourceFileSpec(
        resource_id="agent_1",
        file_type=FileType.AVATAR,
        filename="a.png",
        timestamp="20260310T010203Z",
    )
    result = await gitea_store.create_agent_file(
        space_id="org_001",
        project_id="001",
        spec=spec,
        content=b"avatar-bytes",
    )

    assert captured["owner"] == "org_001"
    assert captured["repo"] == "project_001"
    assert captured["relative_path"] == "agent/avatar/agent_1/20260310T010203Z/a.png"
    assert "创建 agent 文件" in captured["commit_message"]
    assert captured["content"] == "avatar-bytes"
    assert result.commit_sha == "sha-create"
    assert result.descriptor.cache_group == "meta_avatar"


@pytest.mark.asyncio
async def test_update_agent_file_with_custom_type(
    gitea_store: GiteaFileManageStore,
    monkeypatch: pytest.MonkeyPatch,
):
    captured: dict[str, str] = {}

    async def _fake_put_resource_file(locator, relative_path, content, content_type=None, commit_message=None):
        del content_type
        captured["relative_path"] = relative_path
        captured["commit_message"] = commit_message or ""
        captured["content"] = content.decode("utf-8")
        return "sha-update"

    monkeypatch.setattr(gitea_store, "put_resource_file", _fake_put_resource_file)

    spec = ResourceFileSpec(
        resource_id="agent_1",
        file_type=FileType.KNOWLEDGE_RESOURCE,
        filename="data.json",
    )
    result = await gitea_store.update_agent_file(
        space_id="org_001",
        project_id="001",
        spec=spec,
        content=b"{}",
    )

    assert captured["relative_path"] == "agent/knowledge_resource/agent_1/data.json"
    assert "更新 agent 文件" in captured["commit_message"]
    assert captured["content"] == "{}"
    assert result.commit_sha == "sha-update"


@pytest.mark.asyncio
async def test_delete_agent_file(
    gitea_store: GiteaFileManageStore,
    monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setattr(gitea_store, "_get_file_sha", lambda owner, repo, repo_path, branch: "sha-old")

    def _fake_request_json(method: str, path: str, payload=None):
        assert method == "DELETE"
        assert "/contents/agent/avatar/agent_1/20260310T000000Z/a.png" in path
        assert payload["sha"] == "sha-old"
        return {"commit": {"sha": "sha-delete"}}

    monkeypatch.setattr(gitea_store, "_request_json", _fake_request_json)

    spec = ResourceFileSpec(
        resource_id="agent_1",
        file_type=FileType.AVATAR,
        filename="a.png",
        timestamp="20260310T000000Z",
    )
    result = await gitea_store.delete_agent_file(
        space_id="org_001",
        project_id="001",
        spec=spec,
    )

    assert result.deleted is True
    assert result.commit_sha == "sha-delete"
    assert result.descriptor.repo_path == "agent/avatar/agent_1/20260310T000000Z/a.png"


@pytest.mark.asyncio
async def test_generate_secure_link_with_cache_ttl(gitea_store: GiteaFileManageStore, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("TA_STORE_SECURE_LINK_SECRET", "ta_store_sign_secret")
    gitea_store.secure_link_secret = "ta_store_sign_secret"

    result = await gitea_store.generate_secure_link(
        uri="gitea://org_001/project_001/agent/avatar/agent_1/20260310T000000Z/a.png",
        variant="raw",
    )

    assert result.cache_group == "meta_avatar"
    assert result.cache_ttl_seconds == gitea_store.cache_ttl_meta_avatar_seconds
    assert "expires=" in result.url
    assert "sig=" in result.url


@pytest.mark.asyncio
async def test_avatar_requires_timestamp(gitea_store: GiteaFileManageStore):
    spec = ResourceFileSpec(
        resource_id="agent_1",
        file_type=FileType.AVATAR,
        filename="a.png",
    )
    with pytest.raises(ValueError, match="timestamp"):
        await gitea_store.create_agent_file(
            space_id="org_001",
            project_id="001",
            spec=spec,
            content=b"avatar",
        )


@pytest.mark.asyncio
async def test_knowledge_scope_uses_raw_path(
    gitea_store: GiteaFileManageStore,
    monkeypatch: pytest.MonkeyPatch,
):
    captured: dict[str, str] = {}

    async def _fake_put_resource_file(locator, relative_path, content, content_type=None, commit_message=None):
        del locator, content, content_type, commit_message
        captured["relative_path"] = relative_path
        return "sha-knowledge"

    monkeypatch.setattr(gitea_store, "put_resource_file", _fake_put_resource_file)

    spec = ResourceFileSpec(
        resource_id="res_1",
        file_type=FileType.KNOWLEDGE_RESOURCE,
        filename="doc.pdf",
    )
    await gitea_store.create_knowledge_file(
        space_id="org_001",
        project_id="001",
        spec=spec,
        content=b"pdf",
    )

    assert captured["relative_path"] == "knowledge/raw/res_1/doc.pdf"
