# coding=utf-8
from __future__ import annotations

import os
from pathlib import Path
from tempfile import NamedTemporaryFile

import pytest

os.environ.setdefault("DATABASE_URL", "sqlite:///test.db")
os.environ.setdefault("DOCLING_SERVER", "http://localhost:8000")
os.environ.setdefault("DOCLING_API_KEY", "test-key")
os.environ.setdefault("CHUNCK_MODEL", "test-model")
os.environ.setdefault("CHUNCK_MODEL_API_KEY", "test-key")
os.environ.setdefault("CHUNCK_MODEL_API_URL", "http://localhost:11434")

from turbo_agent_core.schema.enums import FileType, KnowledgeType, MessageRole, ResourceStatus
from turbo_agent_core.schema.resources import KnowledgeResource
from turbo_agent_core.schema.states import Conversation, Message, MessageKnowledgeResourceContent
from turbo_agent_store.files.file_manage import LocalFileManageStore, ResourceFileSpec
from turbo_agent_store.files.workspace import WorkspaceContextLoader
from turbo_agent_store.interface.permission import PermissionStore


def _write_temp_file(payload: bytes, suffix: str) -> str:
    with NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
        temp_file.write(payload)
        return temp_file.name


class FakePermissionStore(PermissionStore):
    def __init__(self, allowed_user_id: str):
        self.allowed_user_id = allowed_user_id

    async def check_conversation_access(self, conversation_id: str, owner_user_id: str | None, user_id: str, require_write: bool = False) -> bool:
        del conversation_id, owner_user_id, require_write
        return user_id == self.allowed_user_id

    async def check_resource_access(self, availability: str, project_id: str, creator_id: str, user_id: str, require_write: bool = False) -> bool:
        del availability, project_id, creator_id, user_id, require_write
        return True

    async def check_project_access(self, project_id: str, user_id: str, require_write: bool = False) -> bool:
        del project_id, user_id, require_write
        return True

    async def check_org_access(self, org_name_en: str, user_id: str, require_admin: bool = False) -> bool:
        del org_name_en, user_id, require_admin
        return True


@pytest.fixture
def local_store(tmp_path: Path) -> LocalFileManageStore:
    return LocalFileManageStore(base_path=str(tmp_path / "file-manage"))


@pytest.mark.asyncio
async def test_workspace_context_loader_initializes_and_parses_message(local_store: LocalFileManageStore, tmp_path: Path):
    image_path = _write_temp_file(b"fake-image-bytes", ".png")
    doc_path = _write_temp_file(b"doc-bytes", ".pdf")
    try:
        image_result = await local_store.create_temp_file(
            space_id="001",
            spec=ResourceFileSpec(resource_id="temp_img_001", file_type="png", variant="raw"),
            local_file_path=image_path,
        )
        doc_result = await local_store.create_knowledge_file(
            space_id="001",
            project_id="001",
            spec=ResourceFileSpec(resource_id="knowledge_doc_001", file_type="pdf", variant="raw"),
            local_file_path=doc_path,
        )
    finally:
        os.remove(image_path)
        os.remove(doc_path)

    image_knowledge = KnowledgeResource(
        id="temp_img_001",
        belong_to_project_path="001",
        name="diagram.png",
        type=KnowledgeType.Picture,
        status=ResourceStatus.ready,
        fileType=FileType.png,
        uri=image_result.descriptor.uri,
        filename="diagram.png",
        mime_type="image/png",
    )
    doc_knowledge = KnowledgeResource(
        id="knowledge_doc_001",
        belong_to_project_path="001",
        name="manual.pdf",
        type=KnowledgeType.Document,
        status=ResourceStatus.ready,
        fileType=FileType.pdf,
        uri=doc_result.descriptor.uri,
        filename="manual.pdf",
        mime_type="application/pdf",
    )
    message = Message(
        id="msg_001",
        role=MessageRole.user,
        content=[
            "请查看图片和文件",
            MessageKnowledgeResourceContent(
                id=image_knowledge.id,
                uri=image_knowledge.uri,
                type=image_knowledge.type,
                name=image_knowledge.name,
                mimetype="image/png",
                fileType=FileType.png,
            ),
            MessageKnowledgeResourceContent(
                id=doc_knowledge.id,
                uri=doc_knowledge.uri,
                type=doc_knowledge.type,
                name=doc_knowledge.name,
                mimetype="application/pdf",
                fileType=FileType.pdf,
            ),
        ],
        knowledge_resources=[image_knowledge, doc_knowledge],
        root_user_id="user_001",
    )
    conversation = Conversation(
        id="conv_001",
        messages=[message],
        root_user_id="user_001",
    )

    loader = WorkspaceContextLoader(
        file_manage_store=local_store,
        permission_store=FakePermissionStore(allowed_user_id="user_001"),
        conversation=conversation,
        user_info={"user_id": "user_001", "name": "测试用户"},
        base_path=str(tmp_path / "workspace-context"),
    )

    snapshot = await loader.initialize()

    assert snapshot.root_path == tmp_path / "workspace-context" / "conv_001"
    assert (snapshot.knowledge_files_path / "knowledge_doc_001" / "origin.pdf").exists()
    assert (snapshot.temp_files_path / "temp_img_001" / "origin.png").exists()
    assert snapshot.workset_path.exists()
    assert snapshot.output_files_path.exists()

    parsed = loader.parse_message_content(message)

    assert parsed[0] == {"type": "text", "text": "请查看图片和文件"}
    assert parsed[1]["type"] == "image_url"
    assert parsed[1]["image_url"]["url"].startswith("data:image/png;base64,")
    assert parsed[2] == {"type": "text", "text": "用户上传了一个名为 manual.pdf 的文件"}


@pytest.mark.asyncio
async def test_workspace_context_loader_rejects_unauthorized_user(local_store: LocalFileManageStore, tmp_path: Path):
    conversation = Conversation(id="conv_denied", messages=[], root_user_id="owner_001")
    loader = WorkspaceContextLoader(
        file_manage_store=local_store,
        permission_store=FakePermissionStore(allowed_user_id="other_user"),
        conversation=conversation,
        user_info="user_001",
        base_path=str(tmp_path / "workspace-context"),
    )

    with pytest.raises(PermissionError, match="无权访问对话"):
        await loader.initialize()