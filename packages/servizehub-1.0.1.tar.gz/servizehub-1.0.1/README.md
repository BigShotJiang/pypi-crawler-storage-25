# ServizeHub SDK

## Install
Install using pip:

```bash
pip install servizehub
```

## Usage

```python
import asyncio
from servizehub import VendorClient

client = VendorClient("vnd_test_12345")

async def main():
    response = await client.send_booking(
        "2026-04-15",
        "Photography",
        "available"
    )
    print(response)

asyncio.run(main())
```

## 📩 License

Created by Notasco Dev Team

Happy Coding! 🎯
