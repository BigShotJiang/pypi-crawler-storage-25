# servizehub/client.py
import httpx
import asyncio

class VendorClient:
    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("API key is required")

        self.api_key = api_key
        self.base_url = "https://servizehubuserdev.notasco.in"
        self.headers = {
            "Content-Type": "application/json",
            "servizhub-api-key": self.api_key,
        }

    async def send_booking(self, date: str, service_type: str, status: str):
        if not date or not service_type or not status:
            raise ValueError("All booking details are required")

        valid_statuses = ["available", "unavailable"]
        if status not in valid_statuses:
            raise ValueError("Invalid status value")

        url = f"{self.base_url}/external/capture-availability"

        async with httpx.AsyncClient() as client:
            response = await client.post(url, json={
                "date": date,
                "serviceType": service_type,
                "status": status,
            }, headers=self.headers)

        if response.status_code >= 400:
            raise Exception(f"Booking failed: {response.text}")

        return {"message": "Booking availability sent successfully"}