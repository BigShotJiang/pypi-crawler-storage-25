"""Alpha presets for chart layers."""


def alpha_presets() -> dict:
    """Return alpha values for common chart roles.

    Use when setting ``alpha=`` on matplotlib artists or plotly trace
    opacity. Alpha lowers the effective contrast a viewer sees, so
    verify composited contrast with ``check_palette()`` when the choice
    matters. Keys: ``raw_points``, ``overlay_point``, ``labels``,
    ``fill``, ``ci_ribbon``, ``ci_band``.
    """
    return dict(_presets)


_presets = {
    "raw_points":    0.4,
    "overlay_point": 0.6,
    "labels":        0.7,
    "fill":          0.9,
    "ci_ribbon":     0.10,
    "ci_band":       0.15,
}
