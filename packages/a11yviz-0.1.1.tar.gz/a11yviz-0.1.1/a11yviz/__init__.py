"""Accessibility tools for matplotlib and plotly: composable WCAG-aligned
transforms, alt-text scaffolding, document checks, and a drop-in CSS."""

from a11yviz._rules import load_rules
from a11yviz.alpha_presets import alpha_presets
from a11yviz.alt_template import alt_template
from a11yviz.alt_text import alt_text
from a11yviz.audit import audit
from a11yviz.check_headings import check_headings
from a11yviz.check_overlap import check_overlap
from a11yviz.check_palette import check_palette
from a11yviz.check_palette_size import check_palette_size
from a11yviz.check_readability import check_readability
from a11yviz.check_separability import check_separability
from a11yviz.css import css_path
css = css_path
from a11yviz.describe import describe
from a11yviz.layout import layout
from a11yviz.make_a11y import make_a11y
from a11yviz.palette import (
    palette,
    palette_div,
    palette_info,
    palette_list,
    palette_seq,
)
from a11yviz.plotly_sequences import plotly_sequences
from a11yviz.rubric import rubric
from a11yviz.show_palette import show_palette
from a11yviz.text_spacing_ratios import text_spacing_ratios
from a11yviz.theme import theme
from a11yviz.wcag_url import wcag_url

__version__ = "0.1.1"

__all__ = [
    "alpha_presets",
    "alt_template",
    "alt_text",
    "audit",
    "check_headings",
    "check_overlap",
    "check_palette",
    "check_palette_size",
    "check_readability",
    "check_separability",
    "css",
    "css_path",
    "describe",
    "layout",
    "make_a11y",
    "palette",
    "palette_div",
    "palette_info",
    "palette_list",
    "palette_seq",
    "plotly_sequences",
    "rubric",
    "show_palette",
    "text_spacing_ratios",
    "theme",
    "wcag_url",
    "__version__",
]
