"""Hardcoded RColorBrewer palette tables.

Python has no RColorBrewer; the R package resolves at runtime via
``RColorBrewer::brewer.pal()``. These tables mirror those exact hex codes
so the two packages return identical colors for the same palette name.
Brewer hex values are stable; do not edit without a corresponding update
to the R side.
"""


brewer = {
    "Dark2":  ["#1B9E77", "#D95F02", "#7570B3", "#E7298A",
               "#66A61E", "#E6AB02", "#A6761D", "#666666"],
    "Set2":   ["#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3",
               "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3"],
    "Paired": ["#A6CEE3", "#1F78B4", "#B2DF8A", "#33A02C",
               "#FB9A99", "#E31A1C", "#FDBF6F", "#FF7F00",
               "#CAB2D6", "#6A3D9A", "#FFFF99", "#B15928"],
    "RdBu":   ["#67001F", "#B2182B", "#D6604D", "#F4A582",
               "#FDDBC7", "#F7F7F7", "#D1E5F0", "#92C5DE",
               "#4393C3", "#2166AC", "#053061"],
    "PuOr":   ["#7F3B08", "#B35806", "#E08214", "#FDB863",
               "#FEE0B6", "#F7F7F7", "#D8DAEB", "#B2ABD2",
               "#8073AC", "#542788", "#2D004B"],
    "BrBG":   ["#543005", "#8C510A", "#BF812D", "#DFC27D",
               "#F6E8C3", "#F5F5F5", "#C7EAE5", "#80CDC1",
               "#35978F", "#01665E", "#003C30"],
}
