"""One-shot accessibility wrapper."""

from a11yviz.alt_text import alt_text
from a11yviz.layout import layout


def make_a11y(fig, level: str = "AA",
              palette: str | None = "dark2_8",
              alt: str | None = None):
    """Apply layout + (optional) alt text in one call.

    For plotly figures: applies ``layout(level=, palette=)`` and attaches
    ``alt`` if provided. For matplotlib figures: only attaches ``alt``;
    set the matplotlib palette and theme at plot time by wrapping plotting
    code in ``with theme(level=...)`` (matplotlib colors and rcParams are
    fixed at draw time and cannot be retro-applied).
    """
    if type(fig).__module__.startswith("plotly."):
        fig = layout(fig, level=level, palette=palette)
        if alt is not None:
            fig = alt_text(fig, alt)
        return fig
    if type(fig).__module__.startswith("matplotlib."):
        if alt is not None:
            fig = alt_text(fig, alt)
        return fig
    raise TypeError(
        f"make_a11y() supports plotly and matplotlib figures, got {type(fig).__name__}"
    )
