"""Attach screen-reader alt text to a plotly Figure or matplotlib Figure."""


def alt_text(fig, text: str):
    """Set an alt-text description for a Figure.

    Plotly: stored on the figure's layout for downstream HTML embedding.
    Matplotlib: stored on the Figure's metadata; rendered via `plt.savefig(metadata=...)`.
    """
    if _is_plotly(fig):
        fig.update_layout(meta=dict(alt=text))
        fig._a11y_alt = text
        return fig
    if _is_matplotlib(fig):
        fig._a11y_alt = text
        return fig
    raise TypeError(f"alt_text() supports plotly and matplotlib figures, got {type(fig).__name__}")


def _is_plotly(fig) -> bool:
    return type(fig).__module__.startswith("plotly.")


def _is_matplotlib(fig) -> bool:
    return type(fig).__module__.startswith("matplotlib.")
