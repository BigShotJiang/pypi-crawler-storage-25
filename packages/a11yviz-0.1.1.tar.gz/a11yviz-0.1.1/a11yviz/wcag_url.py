"""WCAG 2.1 specification URL for a success criterion."""


def wcag_url(criterion: str) -> str:
    """Return the deep link to the W3C WCAG 2.1 entry for one success criterion.

    Falls back to the spec root URL for unrecognised criteria.
    """
    slug = _slugs.get(criterion)
    return _base if slug is None else f"{_base}#{slug}"


_base = "https://www.w3.org/TR/WCAG21/"

_slugs = {
    "1.1.1":  "non-text-content",
    "1.3.1":  "info-and-relationships",
    "1.4.1":  "use-of-color",
    "1.4.3":  "contrast-minimum",
    "1.4.4":  "resize-text",
    "1.4.6":  "contrast-enhanced",
    "1.4.10": "reflow",
    "1.4.11": "non-text-contrast",
    "1.4.12": "text-spacing",
    "1.4.13": "content-on-hover-or-focus",
    "2.4.6":  "headings-and-labels",
    "2.4.7":  "focus-visible",
    "2.4.10": "section-headings",
    "3.1.5":  "reading-level",
    "4.1.3":  "status-messages",
}
