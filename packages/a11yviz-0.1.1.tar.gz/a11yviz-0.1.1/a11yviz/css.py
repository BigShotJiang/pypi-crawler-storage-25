"""Path to the bundled accessible CSS."""

from importlib import resources
from pathlib import Path


def css_path() -> Path:
    """Return the filesystem path to ``a11yviz.css``.

    Use it in plain HTML:
        <link rel="stylesheet" href="a11yviz.css">

    Or read its contents into a Quarto/Streamlit/Dash app:
        from a11yviz import css_path
        css = css_path().read_text()
    """
    return Path(str(resources.files("a11yviz").joinpath("css/a11yviz.css")))
