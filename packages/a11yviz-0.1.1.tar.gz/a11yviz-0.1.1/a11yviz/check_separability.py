"""Pairwise color contrast check against WCAG Success Criterion 1.4.11."""

from itertools import combinations

from a11yviz._rules import contrast_ratio


def check_separability(colors, min_ratio: float = 3.0) -> list[dict]:
    """Flag color pairs below the WCAG 2.1 Success Criterion 1.4.11 contrast threshold.

    For every pair of colors in the palette, computes the WCAG
    relative-luminance contrast ratio (same formula as
    ``check_palette``). Pairs below ``min_ratio`` (default ``3.0``, the
    success criterion 1.4.11 "Non-text Contrast / Graphical Objects" threshold) are
    flagged — two data marks of similar colors may fail this and
    viewers cannot tell them apart.

    Returns a list of dicts with keys ``from``, ``to``, ``ratio``,
    ``status``.
    """
    return [
        {"from":   c1,
         "to":     c2,
         "ratio":  (r := round(contrast_ratio(c1, c2), 2)),
         "status": "ok" if r >= min_ratio else "todo"}
        for c1, c2 in combinations(colors, 2)
    ]
