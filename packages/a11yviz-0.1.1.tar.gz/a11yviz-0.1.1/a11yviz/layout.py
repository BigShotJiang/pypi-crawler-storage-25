"""Plotly layout transformer for WCAG conformance."""

from a11yviz._rules import check_level, load_rules
from a11yviz.palette import palette as _palette


def layout(fig, level: str = "AA", palette: str | None = "dark2_8"):
    """Apply accessible layout to a plotly Figure.

    Sets fonts, axis styling, hover-label colors, legend position, and
    an accessible categorical ``colorway``. Targets WCAG 2.1 contrast
    (1.4.3, 1.4.6, 1.4.11) and resizability (1.4.4). Pass ``palette=None``
    to leave plotly's default colors unchanged. Returns the same Figure
    so it stays usable in a fluent chain.
    """
    try:
        import plotly.graph_objects as go  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "layout() requires plotly. Install with: pip install a11yviz[plotly]"
        ) from e

    level = check_level(level)
    rules = load_rules()
    fz = rules["font_size"][level]
    tt = rules["tooltip"]

    body = dict(family=tt["font"], size=fz["body"], color="#222")
    title = dict(family=tt["font"], size=fz["title"], color="#222")
    hover = dict(family=tt["font"], size=tt["size"], color=tt["text"])
    axis = dict(
        tickfont=body, title_font=title,
        gridcolor="#e5e5e5", zerolinecolor="#c0c0c0",
    )

    update = dict(
        autosize=True,
        font=body,
        margin=dict(t=30, b=60, l=90, r=30, autoexpand=True),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        hoverlabel=dict(
            bgcolor=tt["bg"], bordercolor=tt["border"],
            font=hover, align="left", namelength=-1,
        ),
        legend=dict(
            orientation="v", x=1.02, xanchor="left",
            y=0.5, yanchor="middle", font=body, title=dict(font=title),
        ),
        xaxis=axis, yaxis=axis,
    )
    if palette is not None:
        update["colorway"] = _palette(palette)

    fig.update_layout(**update)
    return fig
