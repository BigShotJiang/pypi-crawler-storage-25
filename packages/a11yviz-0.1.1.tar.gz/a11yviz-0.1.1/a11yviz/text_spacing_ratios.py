"""WCAG 1.4.12 text-spacing ratios (reference data)."""


def text_spacing_ratios() -> dict:
    """Return the spacing ratios specified in WCAG Success Criterion 1.4.12 (Text Spacing).

    All values are multiples of the font size. Keys: ``line_height``,
    ``paragraph``, ``letter``, ``word``.
    """
    return {
        "line_height": 1.5,
        "paragraph":   2.0,
        "letter":      0.12,
        "word":        0.16,
    }
