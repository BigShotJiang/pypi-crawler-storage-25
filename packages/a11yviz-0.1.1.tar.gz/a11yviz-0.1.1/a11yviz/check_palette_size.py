"""Flag categorical palettes above the recommended maximum."""


def check_palette_size(n: int, max: int = 7) -> dict:
    """Return a status dict noting whether ``n`` exceeds ``max``.

    Distinguishability drops fast above seven categories even in CVD-safe
    palettes; consider faceting, aggregation, or a sequential / ordinal
    encoding instead.
    """
    ok = n <= max
    return {
        "n":      n,
        "max":    max,
        "status": "ok" if ok else "todo",
        "note":   (f"{n} categories within recommended max {max}"
                   if ok
                   else f"{n} categories exceeds recommended max {max}; "
                        "consider faceting or aggregation"),
    }
