<img src="https://raw.githubusercontent.com/mshin77/a11yviz-py/main/logo.svg" alt="a11yviz Logo" align="right" width="220px"/>

[![PyPI version](https://img.shields.io/pypi/v/a11yviz)](https://pypi.org/project/a11yviz/)
[![Python versions](https://img.shields.io/pypi/pyversions/a11yviz)](https://pypi.org/project/a11yviz/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Tools to make `matplotlib` and `plotly` charts plus Markdown / Quarto
documents follow the [Web Content Accessibility Guidelines
(WCAG 2.1)](https://www.w3.org/TR/WCAG21/). Provides accessible themes,
layout helpers, WCAG-tagged palettes, alt-text scaffolds, per-criterion
audits, a chart-and-document rubric, heading-hierarchy and reading-level
checks, and a drop-in stylesheet for HTML tables and SVG diagrams. R
sibling: [a11yviz](https://github.com/mshin77/a11yviz).

## Installation

```bash
pip install a11yviz
```

## Quick start

```python
import matplotlib.pyplot as plt
import a11yviz
from sklearn.datasets import load_iris

_data = load_iris(as_frame=True)
iris = _data.frame
iris["species"] = _data.target_names[iris["target"]]
cols = a11yviz.palette("dark2_8")
markers = ["o", "s", "^"]

fig, ax = plt.subplots()
for i, (sp, sub) in enumerate(iris.groupby("species")):
    ax.scatter(sub["sepal length (cm)"], sub["sepal width (cm)"],
               color=cols[i], marker=markers[i], label=sp)
ax.set_xlabel("Sepal length (cm)")
ax.set_ylabel("Sepal width (cm)")
ax.legend()

a11yviz.alt_text(fig, "Scatter of iris sepal width vs length by species.")
```

## Citation

Shin, M. (2026). *a11yviz: Accessibility toolkit for ggplot2, plotly, and
Quarto* (R package version 0.1.1). <https://mshin77.github.io/a11yviz>

Shin, M. (2026). *a11yviz: Accessibility toolkit for matplotlib, plotly,
and Quarto* (Python package version 0.1.1). <https://pypi.org/project/a11yviz/>
