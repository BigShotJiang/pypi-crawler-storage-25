from a11yviz import rubric


def test_rubric_returns_15_rows_by_default():
    rows = rubric()
    assert len(rows) == 15
    assert {r["criterion"] for r in rows} == {
        "1.1.1", "1.3.1", "1.4.1", "1.4.3", "1.4.4",
        "1.4.6", "1.4.10", "1.4.11", "1.4.12", "1.4.13",
        "2.4.6", "2.4.7", "2.4.10", "3.1.5", "4.1.3",
    }


def test_rubric_aa_drops_aaa_only_rows():
    rows = rubric(level="AA")
    levels = {r["level"] for r in rows}
    assert "AAA" not in levels
    assert "A" in levels and "AA" in levels


def test_rubric_aaa_keeps_all():
    assert len(rubric(level="AAA")) == 15


def test_rubric_columns_present():
    row = rubric()[0]
    assert set(row.keys()) == {
        "criterion", "name", "level", "threshold_aa",
        "threshold_aaa", "a11yviz_function",
    }
