import pytest

from a11yviz import describe


def test_describe_calls_backend_with_context():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    captured = {}

    def fake_backend(ctx):
        captured.update(ctx)
        return "Mock alt text from backend."

    fig = go.Figure(go.Scatter(x=[1, 2, 3], y=[4, 5, 6], mode="markers"))
    out = describe(fig, backend=fake_backend)

    assert captured["chart_type"] == "Scatter plot"
    assert getattr(out, "_a11y_alt", None) == "Mock alt text from backend."


def test_attach_false_returns_string():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure(go.Scatter(x=[1], y=[2]))
    out = describe(fig, backend=lambda ctx: "raw text", attach=False)
    assert out == "raw text"


