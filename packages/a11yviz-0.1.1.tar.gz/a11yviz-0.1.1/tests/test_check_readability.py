from a11yviz import check_readability


def test_simple_text_low_grade():
    res = check_readability("The cat sat on the mat. The dog ran fast.")
    assert res["sentences"] == 2
    assert res["words"] == 10
    assert res["flesch_kincaid_grade"] < 3


def test_complex_text_higher_grade():
    txt = (
        "Multilevel cumulative-logit growth modelling decomposes longitudinal "
        "expectations into intercept variance, slope variance, and their "
        "covariance under non-proportional assumptions."
    )
    res = check_readability(txt)
    assert res["flesch_kincaid_grade"] > 12


def test_empty_input_yields_none():
    res = check_readability("")
    assert res["sentences"] == 0
    assert res["flesch_kincaid_grade"] is None


def test_file_path_is_read(tmp_path):
    f = tmp_path / "doc.md"
    f.write_text("# Title\n\nThe cat sat on the mat.\n", encoding="utf-8")
    res = check_readability(f)
    assert res["words"] > 0
