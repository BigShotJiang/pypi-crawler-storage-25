import pytest

from a11yviz import check_separability


def test_identical_colors_fail():
    out = check_separability(["#1B9E77", "#1B9E77"])
    assert out[0]["ratio"] == 1.0
    assert out[0]["status"] == "todo"


def test_widely_spaced_colors_pass():
    out = check_separability(["#000000", "#FFFFFF"])
    assert out[0]["ratio"] > 20
    assert out[0]["status"] == "ok"


def test_returns_n_choose_2_pairs():
    out = check_separability(["#000000", "#FF0000", "#00FF00"])
    assert len(out) == 3


def test_min_ratio_configurable():
    permissive = check_separability(["#666666", "#777777"], min_ratio=1.0)
    strict     = check_separability(["#666666", "#777777"], min_ratio=3.0)
    assert permissive[0]["status"] == "ok"
    assert strict[0]["status"]     == "todo"


def test_default_threshold_is_wcag_sc_1_4_11():
    out = check_separability(["#000000", "#888888"])
    assert out[0]["ratio"] >= 3.0
    assert out[0]["status"] == "ok"
