from a11yviz import css_path


def test_css_path_points_to_existing_file():
    p = css_path()
    assert p.exists()
    assert p.suffix == ".css"


def test_css_contains_key_wcag_rules():
    txt = css_path().read_text(encoding="utf-8")
    assert "focus-visible" in txt
    assert "line-height" in txt
    assert "hovertext" in txt
