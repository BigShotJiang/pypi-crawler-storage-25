from a11yviz import text_spacing_ratios


def test_wcag_1_4_12_values():
    expected = {
        "line_height": 1.5,
        "paragraph":   2.0,
        "letter":      0.12,
        "word":        0.16,
    }
    assert text_spacing_ratios() == expected
