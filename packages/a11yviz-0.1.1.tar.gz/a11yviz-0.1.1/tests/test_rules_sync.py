"""Sanity check: rules YAML parses and contains the keys this package depends on."""

from a11yviz import load_rules


def test_required_keys_present():
    r = load_rules()
    expected = ("contrast", "font_size", "palettes", "diverging",
                "sequential", "overlay_presets", "tooltip", "sc_mapping")
    for k in expected:
        assert k in r
    for level in ("AA", "AAA"):
        assert level in r["contrast"]
        assert level in r["font_size"]
    assert "dark2_8" in r["palettes"]
    assert "rdbu" in r["diverging"]
    assert "cividis" in r["sequential"]


def test_version_aligned_with_package():
    from a11yviz import __version__
    r = load_rules()
    assert r["version"] == __version__
