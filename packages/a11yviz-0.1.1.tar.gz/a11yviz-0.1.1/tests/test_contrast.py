from a11yviz._rules import contrast_ratio


def test_black_white_ratio_is_21():
    assert round(contrast_ratio("#000000", "#ffffff")) == 21


def test_blue_white_meets_aa():
    assert contrast_ratio("#0072B2", "#ffffff") > 4.5
