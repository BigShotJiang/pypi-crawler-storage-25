import matplotlib

matplotlib.use("Agg")

import pytest

from a11yviz import show_palette


def test_returns_figure():
    fig = show_palette("dark2_8")
    assert fig.axes


