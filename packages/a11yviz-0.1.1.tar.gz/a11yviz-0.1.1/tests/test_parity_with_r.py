"""Lock parity with the R a11yviz package.

The yaml schema and the RColorBrewer hex tables must stay byte-equal between
the two packages. These tests catch silent drift.
"""

from pathlib import Path

import pytest

from a11yviz._palette_data import brewer


_r_yaml = Path(__file__).resolve().parent.parent.parent / "a11yviz" / "inst" / "extdata" / "wcag_rules.yaml"
_py_yaml = Path(__file__).resolve().parent.parent / "a11yviz" / "_rules.yaml"


def test_yaml_byte_equal_to_r_package():
    if not _r_yaml.exists():
        pytest.skip("R package not at sibling path; parity check requires both repos")
    py_bytes = _py_yaml.read_bytes()
    r_bytes = _r_yaml.read_bytes()
    assert py_bytes == r_bytes, (
        "Python _rules.yaml drifted from R wcag_rules.yaml; "
        "run sync to keep palettes/diverging/sequential/overlay_presets aligned."
    )


def test_brewer_hex_locked():
    expected = {
        "Dark2":  ["#1B9E77", "#D95F02", "#7570B3", "#E7298A",
                   "#66A61E", "#E6AB02", "#A6761D", "#666666"],
        "Set2":   ["#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3",
                   "#A6D854", "#FFD92F", "#E5C494", "#B3B3B3"],
        "Paired": ["#A6CEE3", "#1F78B4", "#B2DF8A", "#33A02C",
                   "#FB9A99", "#E31A1C", "#FDBF6F", "#FF7F00",
                   "#CAB2D6", "#6A3D9A", "#FFFF99", "#B15928"],
        "RdBu":   ["#67001F", "#B2182B", "#D6604D", "#F4A582",
                   "#FDDBC7", "#F7F7F7", "#D1E5F0", "#92C5DE",
                   "#4393C3", "#2166AC", "#053061"],
        "PuOr":   ["#7F3B08", "#B35806", "#E08214", "#FDB863",
                   "#FEE0B6", "#F7F7F7", "#D8DAEB", "#B2ABD2",
                   "#8073AC", "#542788", "#2D004B"],
        "BrBG":   ["#543005", "#8C510A", "#BF812D", "#DFC27D",
                   "#F6E8C3", "#F5F5F5", "#C7EAE5", "#80CDC1",
                   "#35978F", "#01665E", "#003C30"],
    }
    assert brewer == expected
