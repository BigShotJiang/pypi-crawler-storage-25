import pytest

from a11yviz import palette, palette_div, palette_info, palette_list, palette_seq


def test_dark2_8_returns_eight_brewer_hex():
    cols = palette("dark2_8")
    assert len(cols) == 8
    assert cols[0] == "#1B9E77"
    assert all(c.startswith("#") and len(c) == 7 for c in cols)


def test_aaa_5_is_literal_set():
    assert palette("aaa_5") == [
        "#154E8A", "#7C2C5E", "#5C5108", "#8A3A1F", "#2D5C53",
    ]


def test_n_truncates_from_start():
    assert palette("dark2_8", n=3) == ["#1B9E77", "#D95F02", "#7570B3"]


def test_warns_on_mismatched_bg():
    with pytest.warns(UserWarning, match="aaa_5"):
        palette("aaa_5", bg="dark")


def test_div_rdbu_returns_three_anchors():
    p = palette_div("rdbu")
    assert set(p.keys()) == {"low", "mid", "high"}
    assert p["mid"] == "#F7F7F7"


def test_div_coolwarm_aaa_is_literal():
    assert palette_div("coolwarm_aaa") == {
        "low": "#3b4cc0", "mid": "#ffffff", "high": "#b40426",
    }


def test_seq_spec_only_without_n():
    spec = palette_seq("cividis")
    assert spec == {"option": "cividis", "begin": 0, "end": 1, "direction": 1}


def test_seq_with_n_returns_hex_via_matplotlib():
    pytest.importorskip("matplotlib")
    cols = palette_seq("cividis", n=5)
    assert len(cols) == 5
    assert all(c.startswith("#") for c in cols)


def test_info_for_discrete():
    info = palette_info("aaa_5")
    assert info["type"] == "discrete"
    assert len(info["colors"]) == 5
    assert info["safe_on"] == "white"


def test_list_returns_all_families():
    rows = palette_list()
    types = {r["type"] for r in rows}
    assert types == {"discrete", "diverging", "sequential"}


def test_list_filtered_by_type():
    rows = palette_list(type="diverging")
    assert {r["type"] for r in rows} == {"diverging"}


def test_list_n_is_none_for_continuous():
    rows = palette_list()
    for r in rows:
        if r["type"] == "discrete":
            assert isinstance(r["n"], int)
        else:
            assert r["n"] is None
