from a11yviz import alpha_presets


def test_returns_six_keys():
    presets = alpha_presets()
    assert set(presets.keys()) == {
        "raw_points", "overlay_point", "labels",
        "fill", "ci_ribbon", "ci_band",
    }


def test_values_in_unit_interval():
    for v in alpha_presets().values():
        assert 0 < v <= 1


def test_returns_independent_copy():
    a = alpha_presets()
    a["raw_points"] = 0.99
    assert alpha_presets()["raw_points"] != 0.99
