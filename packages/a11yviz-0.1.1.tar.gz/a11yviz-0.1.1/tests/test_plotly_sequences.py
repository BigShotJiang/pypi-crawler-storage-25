from a11yviz import plotly_sequences


def test_returns_one_row_per_sequence():
    rows = plotly_sequences()
    assert len(rows) == 7
    assert {r["name"] for r in rows} == {
        "Plotly", "D3", "G10", "T10", "Vivid", "Bold", "Pastel",
    }


def test_sorted_by_pct_pass_descending():
    rows = plotly_sequences()
    pcts = [r["pct_pass"] for r in rows]
    assert pcts == sorted(pcts, reverse=True)


def test_aaa_threshold_strictly_passes_fewer_than_aa():
    aa  = sum(r["n_pass"] for r in plotly_sequences(level="AA"))
    aaa = sum(r["n_pass"] for r in plotly_sequences(level="AAA"))
    assert aaa <= aa


def test_columns_present():
    row = plotly_sequences()[0]
    assert set(row.keys()) == {
        "name", "n", "min_ratio", "median_ratio", "n_pass", "pct_pass",
    }
