import pytest

from a11yviz import alt_template


def test_matplotlib_scatter_names_chart_type():
    pytest.importorskip("matplotlib")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots()
    ax.scatter([1, 2, 3], [4, 5, 6])
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    s = alt_template(fig)
    assert "Scatter plot" in s
    assert "REPLACE" in s
    plt.close(fig)


def test_matplotlib_line_names_chart_type():
    pytest.importorskip("matplotlib")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots()
    ax.plot([1, 2, 3], [4, 5, 6])
    s = alt_template(fig)
    assert "Line plot" in s
    plt.close(fig)


def test_plotly_scatter_names_chart_type():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure(go.Scatter(x=[1, 2, 3], y=[4, 5, 6], mode="markers"))
    fig.update_layout(xaxis_title="x", yaxis_title="y")
    s = alt_template(fig)
    assert "Scatter plot" in s
    assert "REPLACE" in s


def test_alt_template_rejects_unknown_objects():
    with pytest.raises(TypeError, match="supports matplotlib and plotly"):
        alt_template("not a figure")
