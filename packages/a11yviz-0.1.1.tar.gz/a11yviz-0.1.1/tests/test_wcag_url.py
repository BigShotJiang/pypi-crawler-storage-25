from a11yviz import wcag_url


def test_known_sc_returns_anchor():
    assert wcag_url("1.4.3") == "https://www.w3.org/TR/WCAG21/#contrast-minimum"


def test_unknown_sc_returns_spec_root():
    assert wcag_url("9.9.9") == "https://www.w3.org/TR/WCAG21/"


def test_all_rubric_scs_resolve():
    from a11yviz import rubric

    base = "https://www.w3.org/TR/WCAG21/"
    for row in rubric():
        url = wcag_url(row["criterion"])
        assert url.startswith(base + "#")
