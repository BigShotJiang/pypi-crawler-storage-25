import pytest

from a11yviz import make_a11y


def test_make_a11y_on_plotly_attaches_alt():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure(go.Scatter(x=[1, 2, 3], y=[4, 5, 6]))
    out = make_a11y(fig, level="AA", alt="Test scatter.")
    assert isinstance(out, go.Figure)
    assert getattr(out, "_a11y_alt", None) == "Test scatter."


def test_make_a11y_rejects_unknown_type():
    with pytest.raises(TypeError, match="supports plotly and matplotlib"):
        make_a11y(123, level="AA")


def test_make_a11y_forwards_palette_to_layout():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    from a11yviz import palette

    fig = go.Figure(go.Scatter(x=[1, 2, 3], y=[4, 5, 6]))
    out = make_a11y(fig, level="AA", palette="set2_8")
    assert list(out.layout.colorway) == palette("set2_8")
