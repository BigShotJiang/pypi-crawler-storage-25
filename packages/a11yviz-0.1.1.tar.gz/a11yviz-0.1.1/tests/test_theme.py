import pytest

from a11yviz import theme


def test_theme_context_manager_modifies_rcparams():
    pytest.importorskip("matplotlib")
    import matplotlib as mpl

    before = mpl.rcParams["font.size"]
    with theme(level="AA"):
        inside = mpl.rcParams["font.size"]
    after = mpl.rcParams["font.size"]

    assert inside >= 12
    assert after == before


def test_aaa_uses_larger_font_than_aa():
    pytest.importorskip("matplotlib")
    import matplotlib as mpl

    with theme(level="AA"):
        aa_font = mpl.rcParams["font.size"]
    with theme(level="AAA"):
        aaa_font = mpl.rcParams["font.size"]

    assert aaa_font > aa_font


