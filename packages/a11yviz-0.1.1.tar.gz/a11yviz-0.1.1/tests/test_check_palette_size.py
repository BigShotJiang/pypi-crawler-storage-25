from a11yviz import check_palette_size


def test_ok_when_within_max():
    assert check_palette_size(5)["status"] == "ok"


def test_todo_when_exceeds_max():
    assert check_palette_size(12)["status"] == "todo"


def test_custom_max():
    assert check_palette_size(8, max=10)["status"] == "ok"
