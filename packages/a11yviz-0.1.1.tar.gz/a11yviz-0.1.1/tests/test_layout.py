import pytest

from a11yviz import layout


def test_layout_returns_plotly_figure():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure(go.Scatter(x=[1, 2, 3], y=[4, 5, 6]))
    out = layout(fig, level="AA")
    assert isinstance(out, go.Figure)


def test_layout_sets_transparent_paper():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure(go.Scatter(x=[1, 2, 3], y=[4, 5, 6]))
    out = layout(fig)
    assert out.layout.paper_bgcolor == "rgba(0,0,0,0)"
    assert out.layout.plot_bgcolor == "rgba(0,0,0,0)"


def test_layout_applies_palette_colorway():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    from a11yviz import palette

    fig = go.Figure(go.Scatter(x=[1, 2, 3], y=[4, 5, 6]))
    out = layout(fig, palette="dark2_8")
    assert list(out.layout.colorway) == palette("dark2_8")


def test_layout_palette_none_leaves_colorway_unset():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure(go.Scatter(x=[1, 2, 3], y=[4, 5, 6]))
    out = layout(fig, palette=None)
    assert not out.layout.colorway
