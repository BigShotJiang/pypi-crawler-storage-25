import pytest

from a11yviz import alt_text


def test_alt_text_attaches_on_plotly():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure()
    out = alt_text(fig, "Test description.")
    assert getattr(out, "_a11y_alt", None) == "Test description."
    assert out.layout.meta["alt"] == "Test description."


def test_alt_text_attaches_on_matplotlib():
    pytest.importorskip("matplotlib")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, _ = plt.subplots()
    out = alt_text(fig, "MPL description.")
    assert getattr(out, "_a11y_alt", None) == "MPL description."
    plt.close(fig)


def test_alt_text_rejects_unknown_type():
    with pytest.raises(TypeError, match="supports plotly and matplotlib"):
        alt_text("not a figure", "...")
