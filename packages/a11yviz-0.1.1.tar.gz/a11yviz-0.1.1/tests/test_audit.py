import pytest

from a11yviz import alt_text, audit


def test_audit_fails_alt_by_default():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure()
    rows = audit(fig)
    alt_row = next(r for r in rows if r["check"] == "Alt text on figure")
    assert alt_row["status"] == "todo"


def test_audit_passes_alt_after_alt_text():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure()
    fig = alt_text(fig, "An empty figure used in tests.")
    rows = audit(fig)
    alt_row = next(r for r in rows if r["check"] == "Alt text on figure")
    assert alt_row["status"] == "ok"


def test_aa_returns_11_rows_aaa_adds_one():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure()
    assert len(audit(fig, level="AA"))  == 11
    assert len(audit(fig, level="AAA")) == 12


def test_audit_columns():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure()
    rows = audit(fig)
    assert set(rows[0].keys()) == {"criterion", "check", "status", "note"}


def test_criterion_numbers_match_r():
    pytest.importorskip("plotly")
    import plotly.graph_objects as go

    fig = go.Figure()
    expected_aa = {"1.1.1", "1.3.1", "1.4.1", "1.4.3", "1.4.4",
                   "1.4.10", "1.4.11", "1.4.12", "1.4.13", "2.4.7"}
    assert {r["criterion"] for r in audit(fig, level="AA")}  == expected_aa
    assert {r["criterion"] for r in audit(fig, level="AAA")} == expected_aa | {"1.4.6"}
