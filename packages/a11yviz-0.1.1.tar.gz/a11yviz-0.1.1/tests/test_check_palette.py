from a11yviz import check_palette


def test_black_on_white_passes_aa_and_aaa():
    rows = check_palette(["#000000"], bg="#ffffff", level="AA")
    assert rows[0]["status"] == "ok"
    assert rows[0]["ratio"] > 20


def test_light_gray_on_white_fails_aa():
    rows = check_palette(["#cccccc"], bg="#ffffff", level="AA")
    assert rows[0]["status"] == "todo"


def test_aaa_threshold_rejects_aa_only_colors():
    rows = check_palette(["#0072B2"], bg="#ffffff", level="AAA")
    assert rows[0]["status"] == "todo"


def test_returns_one_row_per_color():
    rows = check_palette(["#000000", "#ffffff", "#888888"])
    assert len(rows) == 3
    assert set(rows[0].keys()) == {"color", "bg", "alpha", "rendered", "ratio", "status"}


def test_alpha_one_leaves_color_unchanged():
    rows = check_palette(["#000000"], bg="#ffffff", alpha=1.0)
    assert rows[0]["rendered"].lower() == "#000000"
    assert rows[0]["alpha"] == 1.0


def test_alpha_below_one_composites_toward_bg():
    rows = check_palette(["#000000"], bg="#ffffff", alpha=0.5)
    assert rows[0]["rendered"].lower() == "#808080"
    assert rows[0]["ratio"] < 21


def test_alpha_lowers_contrast_against_white():
    full   = check_palette(["#0072B2"], bg="#ffffff", alpha=1.0)[0]["ratio"]
    faded  = check_palette(["#0072B2"], bg="#ffffff", alpha=0.4)[0]["ratio"]
    assert faded < full


def test_vector_bg_returns_cross_product():
    rows = check_palette(["#000000", "#ff0000"], bg=["#ffffff", "#1a1a1a"])
    assert len(rows) == 4
    bgs = {r["bg"] for r in rows}
    assert bgs == {"#ffffff", "#1a1a1a"}


def test_vector_bg_row_order_matches_r_expand_grid():
    rows = check_palette(["#000000", "#ff0000"], bg=["#ffffff", "#1a1a1a"])
    pairs = [(r["color"], r["bg"]) for r in rows]
    assert pairs == [
        ("#000000", "#ffffff"),
        ("#ff0000", "#ffffff"),
        ("#000000", "#1a1a1a"),
        ("#ff0000", "#1a1a1a"),
    ]


def test_vector_bg_dual_background_check():
    rows = check_palette(["#0072B2"], bg=["#ffffff", "#1a1a1a"], level="AA-large")
    assert len(rows) == 2
    assert all(r["status"] == "ok" for r in rows)


def test_aa_large_uses_3_to_1_threshold():
    rows_large = check_palette(["#888888"], bg="#ffffff", level="AA-large")
    assert rows_large[0]["status"] == "ok"
    rows_aa = check_palette(["#888888"], bg="#ffffff", level="AA")
    assert rows_aa[0]["status"] == "todo"


