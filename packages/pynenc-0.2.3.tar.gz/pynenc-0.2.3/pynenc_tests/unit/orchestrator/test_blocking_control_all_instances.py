from pynenc import Pynenc
from pynenc.call import Call
from pynenc.invocation import (
    DistributedInvocation,
    InvocationStatus,
    InvocationStatusRecord,
)
from pynenc_tests.conftest import MockPynenc

_mock_base_app = MockPynenc()


@_mock_base_app.task
def task0() -> None: ...


@_mock_base_app.task
def task1() -> None: ...


def test_get_blocking_invocations(app_instance: "Pynenc") -> None:
    invocation0: DistributedInvocation = DistributedInvocation.isolated(Call(task0))
    invocation1: DistributedInvocation = DistributedInvocation.isolated(Call(task1))

    graph = app_instance.orchestrator.blocking_control  # type: ignore

    # register new invocations in the orchestrator
    app_instance.orchestrator._register_new_invocations([invocation0, invocation1])

    # graph.add_invocation_call(invocation0, invocation1)
    # graph.add_invocation_call(invocation1, invocation2)
    graph.waiting_for_results(invocation0.invocation_id, [invocation1.invocation_id])

    invocation0.app.orchestrator.get_invocation_status_record.return_value = (  # type: ignore
        InvocationStatusRecord(status=InvocationStatus.REGISTERED)
    )

    blocking: list[str] = list(graph.get_blocking_invocations(2))
    assert len(blocking) == 1
    assert blocking[0] == invocation1.invocation_id
