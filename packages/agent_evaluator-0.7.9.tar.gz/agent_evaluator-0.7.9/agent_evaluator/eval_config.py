"""
eval_config.py — Phase 1: Config file-based zero-parameter decorators
======================================================================

Zero-param usage:
    @agent_eval                          # reads agent_eval.toml or pyproject.toml
    def agent(question, ground_truth=""): ...

Profile usage:
    @agent_eval(profile="rag_production")
    def rag_agent(question, context="", ground_truth=""): ...

Config file (agent_eval.toml or pyproject.toml [tool.agent-eval]):
    [default]
    task_type = "qa"
    output_dir = "results/"
    sample_rate = 1.0

    [profiles.rag_production]
    task_type = "information_retrieval"
    rag_mode = true
    enable_llm_judge = true
    judge_model = "claude-haiku-4-5-20251001"

Priority chain (highest to lowest):
    1. Code parameters (explicit non-_UNSET values)
    2. AGENT_EVAL_* environment variables
    3. [env.{AGENT_EVAL_ENV}] config section
    4. [profiles.{profile}] config section
    5. [default] config section
    6. SDK built-in defaults
"""

from __future__ import annotations

import os
import threading
import warnings
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    pass

# ---------------------------------------------------------------------------
# _UNSET sentinel — distinguishes "not passed" from "explicitly False / None"
# ---------------------------------------------------------------------------

class _UnsetType:
    """Singleton sentinel used as default for decorator parameters.

    Allows the config resolution layer to distinguish between:
    - ``param=False``  (user explicitly disabled)
    - ``param=_UNSET`` (user did not specify → apply config/env/preset)
    """
    _instance: Optional["_UnsetType"] = None

    def __new__(cls) -> "_UnsetType":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "<_UNSET>"

    def __bool__(self) -> bool:
        return False


_UNSET = _UnsetType()


# ---------------------------------------------------------------------------
# Sub-config dataclasses
# ---------------------------------------------------------------------------

@dataclass
class JudgeConfig:
    """LLM Judge configuration."""
    enabled: bool = False
    model: Optional[str] = None
    sample_rate: float = 0.1
    criteria: Optional[List[str]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "JudgeConfig":
        return cls(
            enabled=d.get("enabled", False),
            model=d.get("model") or d.get("judge_model"),
            sample_rate=float(d.get("sample_rate", d.get("judge_sample_rate", 0.1))),
            criteria=d.get("criteria") or d.get("judge_criteria"),
        )


@dataclass
class SecurityConfig:
    """Security metrics configuration."""
    enabled: bool = False
    allowed_tools: Optional[List[str]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "SecurityConfig":
        return cls(
            enabled=d.get("enabled", False),
            allowed_tools=d.get("allowed_tools"),
        )


@dataclass
class AnomalyConfig:
    """Anomaly detection configuration."""
    enabled: bool = False

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AnomalyConfig":
        return cls(enabled=d.get("enabled", False))


# ---------------------------------------------------------------------------
# EvalConfig — main configuration dataclass
# ---------------------------------------------------------------------------

@dataclass
class EvalConfig:
    """Resolved evaluation configuration.

    All values are concrete (no _UNSET).  This is the object produced
    after merging code params > env vars > env section > profile > default.
    """
    # Monitor settings
    output_dir: str = "results/"
    auto_save: bool = False
    auto_save_interval: int = 10

    # Task defaults
    task_type: str = "qa"
    framework: str = "native"
    model_name: str = ""

    # Sampling
    sample_rate: float = 1.0

    # Feature flags
    rag_mode: bool = False
    enable_hallucination: bool = False
    security_mode: bool = False
    enable_quality_evaluation: bool = False
    enable_anomaly_detection: bool = False

    # Judge sub-config
    judge: JudgeConfig = field(default_factory=JudgeConfig)

    # Security sub-config
    security: SecurityConfig = field(default_factory=SecurityConfig)

    # Anomaly sub-config
    anomaly: AnomalyConfig = field(default_factory=AnomalyConfig)

    # Flush
    flush_every: Optional[int] = None
    flush_filename: str = "auto_save"

    # Retry
    max_retries: int = 1

    # Misc
    preset: Optional[str] = None
    dry_run: bool = False
    enabled: bool = True

    @classmethod
    def _from_raw(cls, raw: Dict[str, Any]) -> "EvalConfig":
        """Build EvalConfig from a raw dict (from TOML or env merge)."""
        judge_raw = raw.get("judge", {})
        # Flat keys also supported: enable_llm_judge, judge_model, etc.
        if raw.get("enable_llm_judge") and not judge_raw.get("enabled"):
            judge_raw["enabled"] = raw["enable_llm_judge"]
        if raw.get("judge_model") and not judge_raw.get("model"):
            judge_raw["model"] = raw["judge_model"]
        if raw.get("judge_sample_rate") and not judge_raw.get("sample_rate"):
            judge_raw["sample_rate"] = raw["judge_sample_rate"]
        if raw.get("judge_criteria") and not judge_raw.get("criteria"):
            judge_raw["criteria"] = raw["judge_criteria"]

        security_raw = raw.get("security", {})
        if raw.get("enable_security_metrics") and not security_raw.get("enabled"):
            security_raw["enabled"] = raw["enable_security_metrics"]
        if raw.get("allowed_tools") and not security_raw.get("allowed_tools"):
            security_raw["allowed_tools"] = raw["allowed_tools"]

        anomaly_raw = raw.get("anomaly", {})
        if raw.get("enable_anomaly_detection") and not anomaly_raw.get("enabled"):
            anomaly_raw["enabled"] = raw["enable_anomaly_detection"]

        return cls(
            output_dir=raw.get("output_dir", "results/"),
            auto_save=bool(raw.get("auto_save", False)),
            auto_save_interval=int(raw.get("auto_save_interval", 10)),
            task_type=raw.get("task_type", "qa"),
            framework=raw.get("framework", "native"),
            model_name=raw.get("model_name", ""),
            sample_rate=float(raw.get("sample_rate", 1.0)),
            rag_mode=bool(raw.get("rag_mode", False)),
            enable_hallucination=bool(raw.get("enable_hallucination", False)),
            security_mode=bool(raw.get("security_mode", False)),
            enable_quality_evaluation=bool(raw.get("enable_quality_evaluation", False)),
            enable_anomaly_detection=bool(raw.get("enable_anomaly_detection", False)),
            judge=JudgeConfig.from_dict(judge_raw),
            security=SecurityConfig.from_dict(security_raw),
            anomaly=AnomalyConfig.from_dict(anomaly_raw),
            flush_every=raw.get("flush_every"),
            flush_filename=raw.get("flush_filename", "auto_save"),
            max_retries=int(raw.get("max_retries", 1)),
            preset=raw.get("preset"),
            dry_run=bool(raw.get("dry_run", False)),
            enabled=bool(raw.get("enabled", True)),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def __repr__(self) -> str:
        return (
            f"EvalConfig(task_type={self.task_type!r}, framework={self.framework!r}, "
            f"rag_mode={self.rag_mode}, judge.enabled={self.judge.enabled}, "
            f"output_dir={self.output_dir!r})"
        )


# ---------------------------------------------------------------------------
# EvalConfigLoader — reads agent_eval.toml / pyproject.toml
# ---------------------------------------------------------------------------

_SDK_DEFAULTS: Dict[str, Any] = {
    "output_dir": "results/",
    "task_type": "qa",
    "framework": "native",
    "model_name": "",
    "sample_rate": 1.0,
    "rag_mode": False,
    "enable_hallucination": False,
    "security_mode": False,
    "enable_quality_evaluation": False,
    "enable_anomaly_detection": False,
    "flush_filename": "auto_save",
    "max_retries": 1,
    "dry_run": False,
    "enabled": True,
    "auto_save": False,
    "auto_save_interval": 10,
}

_ENV_VAR_MAP: Dict[str, str] = {
    "AGENT_EVAL_OUTPUT_DIR": "output_dir",
    "AGENT_EVAL_TASK_TYPE": "task_type",
    "AGENT_EVAL_FRAMEWORK": "framework",
    "AGENT_EVAL_MODEL_NAME": "model_name",
    "AGENT_EVAL_SAMPLE_RATE": "sample_rate",
    "AGENT_EVAL_RAG_MODE": "rag_mode",
    "AGENT_EVAL_ENABLE_HALLUCINATION": "enable_hallucination",
    "AGENT_EVAL_SECURITY_MODE": "security_mode",
    "AGENT_EVAL_ENABLE_LLM_JUDGE": "enable_llm_judge",
    "AGENT_EVAL_JUDGE_MODEL": "judge_model",
    "AGENT_EVAL_JUDGE_SAMPLE_RATE": "judge_sample_rate",
    "AGENT_EVAL_ENABLE_ANOMALY": "enable_anomaly_detection",
    "AGENT_EVAL_DRY_RUN": "dry_run",
    "AGENT_EVAL_ENABLED": "enabled",
    "AGENT_EVAL_FLUSH_EVERY": "flush_every",
    "AGENT_EVAL_AUTO_SAVE": "auto_save",
    "AGENT_EVAL_AUTO_SAVE_INTERVAL": "auto_save_interval",
    "AGENT_EVAL_MAX_RETRIES": "max_retries",
}

_BOOL_KEYS = {
    "rag_mode", "enable_hallucination", "security_mode", "enable_llm_judge",
    "enable_anomaly_detection", "dry_run", "enabled", "auto_save",
}
_INT_KEYS = {"flush_every", "auto_save_interval", "max_retries"}
_FLOAT_KEYS = {"sample_rate", "judge_sample_rate"}


class EvalConfigLoader:
    """Loads and merges configuration from multiple sources.

    Search order for config file:
        1. ``$AGENT_EVAL_CONFIG`` env var path
        2. ``agent_eval.toml`` in current working directory
        3. ``pyproject.toml`` ``[tool.agent-eval]`` section in cwd
        4. Walk up to project root (git root or 3 levels max)
    """

    _toml_cache: Optional[Dict[str, Any]] = None
    _toml_mtime: float = 0.0
    _cache_lock = threading.Lock()

    @classmethod
    def _load_toml(cls, path: Path) -> Dict[str, Any]:
        """Parse TOML file; returns {} on any error."""
        try:
            try:
                import tomllib  # Python 3.11+
            except ImportError:
                try:
                    import tomli as tomllib  # type: ignore[no-redef]
                except ImportError:
                    return {}

            with open(path, "rb") as fh:
                return tomllib.load(fh)
        except Exception:
            return {}

    @classmethod
    def _find_config_file(cls) -> Optional[Path]:
        """Locate config file according to search order."""
        env_path = os.getenv("AGENT_EVAL_CONFIG")
        if env_path:
            p = Path(env_path)
            if p.is_file():
                return p
            warnings.warn(
                f"AGENT_EVAL_CONFIG={env_path!r} 파일이 존재하지 않습니다.",
                UserWarning,
                stacklevel=5,
            )

        # Search cwd + ancestors (up to 3 levels)
        cwd = Path.cwd()
        search_dirs = [cwd] + list(cwd.parents)[:3]

        for d in search_dirs:
            candidate = d / "agent_eval.toml"
            if candidate.is_file():
                return candidate

        for d in search_dirs:
            candidate = d / "pyproject.toml"
            if candidate.is_file():
                return candidate  # caller will extract [tool.agent-eval]

        return None

    @classmethod
    def _get_raw_toml(cls) -> Dict[str, Any]:
        """Return the raw TOML dict (from agent_eval.toml or pyproject.toml)."""
        with cls._cache_lock:
            config_path = cls._find_config_file()
            if config_path is None:
                return {}

            mtime = config_path.stat().st_mtime
            if cls._toml_cache is not None and mtime == cls._toml_mtime:
                return cls._toml_cache

            raw = cls._load_toml(config_path)

            # pyproject.toml: extract [tool.agent-eval]
            if config_path.name == "pyproject.toml":
                raw = raw.get("tool", {}).get("agent-eval", {})

            cls._toml_cache = raw
            cls._toml_mtime = mtime
            return raw

    @classmethod
    def _env_overrides(cls) -> Dict[str, Any]:
        """Read AGENT_EVAL_* env vars and return as dict."""
        result: Dict[str, Any] = {}
        for env_key, config_key in _ENV_VAR_MAP.items():
            val = os.getenv(env_key)
            if val is None:
                continue
            if config_key in _BOOL_KEYS:
                result[config_key] = val.lower() in ("1", "true", "yes")
            elif config_key in _INT_KEYS:
                try:
                    result[config_key] = int(val)
                except ValueError:
                    pass
            elif config_key in _FLOAT_KEYS:
                try:
                    result[config_key] = float(val)
                except ValueError:
                    pass
            else:
                result[config_key] = val
        return result

    @classmethod
    def load(cls, profile: Optional[str] = None) -> EvalConfig:
        """Load and resolve config with full priority chain.

        Priority: env vars > [env.{AGENT_EVAL_ENV}] > [profiles.{profile}] > [default] > SDK defaults
        """
        raw_toml = cls._get_raw_toml()

        # Start with SDK defaults
        merged: Dict[str, Any] = dict(_SDK_DEFAULTS)

        # Layer: [default] section
        defaults_section = raw_toml.get("default", {})
        merged.update(defaults_section)

        # Layer: [profiles.{profile}]
        if profile is not None:
            profiles = raw_toml.get("profiles", {})
            if profile in profiles:
                merged.update(profiles[profile])
            else:
                warnings.warn(
                    f"eval_config: 프로필 '{profile}'이 설정 파일에 없습니다. "
                    f"사용 가능: {list(profiles.keys()) or '[없음]'}",
                    UserWarning,
                    stacklevel=4,
                )

        # Layer: [env.{AGENT_EVAL_ENV}] — e.g. [env.production]
        eval_env = os.getenv("AGENT_EVAL_ENV")
        if eval_env:
            env_section = raw_toml.get("env", {}).get(eval_env, {})
            merged.update(env_section)

        # Layer: AGENT_EVAL_* environment variables (highest before code params)
        merged.update(cls._env_overrides())

        return EvalConfig._from_raw(merged)

    @classmethod
    def invalidate_cache(cls) -> None:
        """Force re-read of config file on next access (useful in tests)."""
        with cls._cache_lock:
            cls._toml_cache = None
            cls._toml_mtime = 0.0


# ---------------------------------------------------------------------------
# get_active_config() — convenience function
# ---------------------------------------------------------------------------

def get_active_config(profile: Optional[str] = None) -> EvalConfig:
    """Return the resolved EvalConfig for the given profile.

    Args:
        profile: Named profile from ``[profiles.*]`` in config file.
                 ``None`` uses the ``[default]`` section.

    Returns:
        :class:`EvalConfig` with all values resolved.
    """
    return EvalConfigLoader.load(profile=profile)


# ---------------------------------------------------------------------------
# Monitor registry — auto-create and cache PerformanceMonitor per config key
# ---------------------------------------------------------------------------

_monitor_registry: Dict[str, Any] = {}
_monitor_lock = threading.Lock()


def get_or_create_monitor(
    profile: Optional[str] = None,
    config: Optional[EvalConfig] = None,
) -> Any:  # returns PerformanceMonitor
    """Return a cached PerformanceMonitor for the given profile/config.

    If *config* is provided it takes precedence over *profile*.

    This function is used internally by the zero-param decorator path to avoid
    creating a new ``PerformanceMonitor`` on every decorated function definition.
    """
    from .core.trackers.monitor import PerformanceMonitor

    if config is None:
        config = get_active_config(profile=profile)

    cache_key = f"{profile or '_default'}::{config.output_dir}"

    with _monitor_lock:
        if cache_key in _monitor_registry:
            return _monitor_registry[cache_key]

        monitor = PerformanceMonitor(
            output_dir=config.output_dir,
            auto_save=config.auto_save,
            auto_save_interval=config.auto_save_interval,
            enable_hallucination_detection=config.enable_hallucination,
            enable_security_metrics=config.security_mode or config.security.enabled,
            enable_llm_judge=config.judge.enabled,
            judge_model=config.judge.model,
            judge_sample_rate=config.judge.sample_rate,
            judge_criteria=config.judge.criteria,
            enable_anomaly_detection=config.enable_anomaly_detection or config.anomaly.enabled,
        )

        _monitor_registry[cache_key] = monitor
        return monitor


def clear_monitor_registry() -> None:
    """Remove all cached monitors (useful in tests or multi-run scripts)."""
    with _monitor_lock:
        _monitor_registry.clear()
