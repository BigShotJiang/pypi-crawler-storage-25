"""
engine.py — PolicyEngine (YAML/TOML/JSON 기반 배포 게이팅 · 런타임 핫-리로드)
==============================================================================

정책 파일에서 임계값 규칙을 로드하고 EvaluationReport 또는 TaskResult에 대해
평가한다. 파일 변경 감지(mtime polling) 시 자동 재로드하므로 재배포 없이
게이팅 기준을 변경할 수 있다.

정책 파일 형식 (YAML 예시)::

    version: "1.0"
    policies:
      default:
        description: "기본 정책"
        gates:
          tcr:               {min: 0.80}
          accuracy:          {min: 0.70}
          hallucination_rate:{max: 0.15}
          p95_latency:       {max: 10.0}
        action:
          on_failure: warn   # warn | raise | exit | ignore
          exit_code: 1

      production:
        extends: default
        gates:
          tcr:      {min: 0.90, severity: error}
          accuracy: {min: 0.85}
        action:
          on_failure: exit

사용 예::

    from agent_evaluator.policy import PolicyEngine

    engine = PolicyEngine("agent_eval_policy.yaml", policy="production")
    engine.start_watching()      # 핫-리로드 시작

    report = monitor.generate_report()
    result = engine.evaluate(report)
    result.enforce()             # on_failure 액션 실행

    print(result.summary())
    engine.stop_watching()
"""

from __future__ import annotations

import logging
import sys
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Operator table
# ---------------------------------------------------------------------------

_OPS: Dict[str, Any] = {
    "gte": lambda v, t: v >= t,
    "lte": lambda v, t: v <= t,
    "gt":  lambda v, t: v > t,
    "lt":  lambda v, t: v < t,
    "eq":  lambda v, t: v == t,
    "ne":  lambda v, t: v != t,
}

_OP_SYMBOLS: Dict[str, str] = {
    "gte": ">=", "lte": "<=", "gt": ">", "lt": "<", "eq": "==", "ne": "!=",
}

# ---------------------------------------------------------------------------
# Metric name aliases: short user-facing name → report dict path(s)
# ---------------------------------------------------------------------------

# Each entry: canonical_name → list of (dict_path...,) tuples to try in order
_REPORT_METRIC_PATHS: Dict[str, List[tuple]] = {
    # EvaluationReport — values extracted here may be on 0-100 or 0-5 scale
    # → _NORMALIZE converts to 0-1 for consistent policy thresholds
    "tcr":               [("accuracy_metrics", "tcr", "tcr"),          # 0-100 %
                          ("accuracy_metrics", "tcr", "task_completion_rate")],
    "accuracy":          [("accuracy_metrics", "accuracy_scores", "overall_accuracy")],  # 0-100 %
    "hallucination_rate":[("accuracy_metrics", "hallucination", "hallucination_rate")],  # 0-1
    "quality_avg":       [("accuracy_metrics", "quality", "avg_total_score"),            # 0-5
                          ("quality_metrics", "avg_total_score")],
    "p95_latency":       [("efficiency_metrics", "latency", "p95")],    # seconds
    "p99_latency":       [("efficiency_metrics", "latency", "p99")],
    "mean_latency":      [("efficiency_metrics", "latency", "mean")],
    "total_tokens":      [("efficiency_metrics", "tokens", "total_tokens")],
    "avg_cost_usd":      [("efficiency_metrics", "tokens", "avg_cost_usd")],
    "total_tasks":       [("total_tasks",)],
    # TaskResult (already 0-1 scale)
    "completion_score":  [("completion_score",)],
    "accuracy_score":    [("accuracy_score",)],
    "execution_time":    [("execution_time",)],
    "tokens_used":       [("tokens_used",)],
    "success":           [("success",)],
    "attempts":          [("attempts",)],
}

# Normalization factors — applied AFTER extraction to produce 0-1 scale
# so policy thresholds are always in 0-1 range (0.85 = 85%)
_NORMALIZE: Dict[str, float] = {
    "tcr":       0.01,   # 0-100 % → 0-1
    "accuracy":  0.01,   # 0-100 % → 0-1
    "quality_avg": 0.2,  # 0-5 score → 0-1
}

# Aliases that map to canonical names
_METRIC_ALIASES: Dict[str, str] = {
    "task_completion_rate": "tcr",
    "overall_accuracy":     "accuracy",
    "overall_quality":      "quality_avg",
    "latency_p95":          "p95_latency",
    "latency_p99":          "p99_latency",
    "latency_mean":         "mean_latency",
    "cost_usd":             "avg_cost_usd",
}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class PolicyRule:
    """단일 메트릭 임계값 규칙."""
    metric: str
    op: str             # gte | lte | gt | lt | eq | ne
    threshold: float
    severity: str = "error"   # error | warning | info
    description: str = ""

    def evaluate(self, value: float) -> bool:
        """규칙을 value에 적용해 통과 여부를 반환한다."""
        fn = _OPS.get(self.op)
        if fn is None:
            raise ValueError(f"Unknown op: {self.op!r}. Valid: {list(_OPS)}")
        return bool(fn(value, self.threshold))

    def violation_message(self, actual: float) -> str:
        sym = _OP_SYMBOLS.get(self.op, self.op)
        desc = f" — {self.description}" if self.description else ""
        return (
            f"{self.metric} = {actual:.4f} violates rule "
            f"({self.metric} {sym} {self.threshold}){desc}"
        )


@dataclass
class PolicyAction:
    """정책 위반 시 실행할 액션."""
    on_failure: str = "warn"   # warn | raise | exit | ignore
    exit_code: int = 1
    message: str = ""


@dataclass
class Policy:
    """이름을 가진 규칙 집합 + 액션."""
    name: str
    rules: List[PolicyRule] = field(default_factory=list)
    action: PolicyAction = field(default_factory=PolicyAction)
    description: str = ""
    extends: Optional[str] = None


@dataclass
class RuleViolation:
    rule: PolicyRule
    actual_value: float
    message: str


@dataclass
class PolicyResult:
    """정책 평가 결과."""
    policy_name: str
    passed: bool
    violations: List[RuleViolation]       # severity=error
    warnings: List[RuleViolation]         # severity=warning
    metrics_evaluated: Dict[str, float]
    action: PolicyAction = field(default_factory=PolicyAction)

    # ── enforce ──────────────────────────────────────────────────────────────

    def enforce(self) -> None:
        """action.on_failure 에 따라 위반을 강제한다.

        - ``"warn"``   → logger.warning (기본값)
        - ``"raise"``  → :class:`PolicyViolationError` 발생
        - ``"exit"``   → ``sys.exit(action.exit_code)``
        - ``"ignore"`` → 아무것도 하지 않음
        """
        if self.passed and not self.warnings:
            return

        msg = self._format_message()
        mode = self.action.on_failure

        if mode == "ignore":
            return
        if mode == "warn":
            if not self.passed:
                logger.warning(msg)
            elif self.warnings:
                logger.warning(msg)
        elif mode == "raise":
            if not self.passed:
                raise PolicyViolationError(msg, result=self)
            elif self.warnings:
                logger.warning(msg)
        elif mode == "exit":
            if not self.passed:
                logger.error(msg)
                sys.exit(self.action.exit_code)
            elif self.warnings:
                logger.warning(msg)
        else:
            logger.warning("Unknown on_failure=%r, defaulting to warn.\n%s", mode, msg)

    def _format_message(self) -> str:
        lines = []
        if not self.passed:
            lines.append(f"[Policy '{self.policy_name}' FAILED]")
            for v in self.violations:
                lines.append(f"  ERROR: {v.message}")
        if self.warnings:
            if self.passed:
                lines.append(f"[Policy '{self.policy_name}' passed with warnings]")
            for w in self.warnings:
                lines.append(f"  WARNING: {w.message}")
        return "\n".join(lines)

    def summary(self) -> str:
        """한 줄 요약 문자열."""
        status = "PASSED" if self.passed else "FAILED"
        n_v = len(self.violations)
        n_w = len(self.warnings)
        return (
            f"Policy '{self.policy_name}': {status} "
            f"({n_v} violations, {n_w} warnings) "
            f"from {len(self.metrics_evaluated)} metrics"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "policy_name": self.policy_name,
            "passed": self.passed,
            "violations": [
                {
                    "metric": v.rule.metric,
                    "op": v.rule.op,
                    "threshold": v.rule.threshold,
                    "actual": v.actual_value,
                    "severity": v.rule.severity,
                    "message": v.message,
                }
                for v in self.violations
            ],
            "warnings": [
                {
                    "metric": w.rule.metric,
                    "op": w.rule.op,
                    "threshold": w.rule.threshold,
                    "actual": w.actual_value,
                    "severity": w.rule.severity,
                    "message": w.message,
                }
                for w in self.warnings
            ],
            "metrics_evaluated": self.metrics_evaluated,
        }


class PolicyViolationError(Exception):
    """``on_failure='raise'`` 시 발생하는 예외."""

    def __init__(self, message: str, *, result: PolicyResult) -> None:
        super().__init__(message)
        self.result = result


# ---------------------------------------------------------------------------
# PolicyEngine
# ---------------------------------------------------------------------------

class PolicyEngine:
    """YAML/TOML/JSON 기반 배포 게이팅 엔진 (런타임 핫-리로드 지원).

    정책 파일을 로드하고 ``EvaluationReport`` 또는 ``TaskResult`` 에 대해
    게이팅 규칙을 평가한다. ``start_watching()`` 호출 시 백그라운드 스레드가
    파일 mtime을 폴링하여 변경 감지 시 자동으로 리로드한다.

    Args:
        policy_file: 정책 파일 경로 (``.yaml`` / ``.toml`` / ``.json``).
            ``None`` 이면 빈 엔진으로 시작 (``register_policy()`` 로 직접 등록).
        policy: 기본 정책 이름. 기본값 ``"default"``.
        reload_interval: 핫-리로드 감지 주기(초). 기본 5.0초.
        on_reload: 리로드 완료 시 호출할 콜백. ``None`` 이면 사용 안 함.

    Example::

        engine = PolicyEngine("agent_eval_policy.yaml", policy="production")
        engine.start_watching()

        report = monitor.generate_report()
        result = engine.evaluate(report)
        result.enforce()

        engine.stop_watching()
    """

    def __init__(
        self,
        policy_file: Optional[str] = None,
        *,
        policy: str = "default",
        reload_interval: float = 5.0,
        on_reload: Optional[Callable[[], None]] = None,
    ) -> None:
        self._policy_file = policy_file
        self._default_policy = policy
        self._reload_interval = reload_interval
        self._on_reload = on_reload

        self._policies: Dict[str, Policy] = {}
        self._lock = threading.RLock()
        self._watcher: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._last_mtime: float = 0.0

        if policy_file:
            self._load_file(policy_file)

    # ── 정책 등록 · 조회 ──────────────────────────────────────────────────────

    def register_policy(self, policy: Policy) -> None:
        """정책을 직접 등록한다."""
        with self._lock:
            self._policies[policy.name] = policy

    def get_policy(self, name: Optional[str] = None) -> Policy:
        """정책 이름으로 조회한다. 없으면 ``KeyError``."""
        pname = name or self._default_policy
        with self._lock:
            if pname not in self._policies:
                available = list(self._policies)
                raise KeyError(
                    f"Policy {pname!r} not found. Available: {available}"
                )
            return self._policies[pname]

    def list_policies(self) -> List[str]:
        """등록된 정책 이름 목록."""
        with self._lock:
            return list(self._policies)

    def summary(self) -> Dict[str, Any]:
        """엔진 상태 요약 딕셔너리."""
        watching = self._watcher is not None and self._watcher.is_alive()
        with self._lock:
            policies_info = {
                name: {
                    "rules": len(p.rules),
                    "action": p.action.on_failure,
                    "description": p.description,
                }
                for name, p in self._policies.items()
            }
        return {
            "policy_file": self._policy_file,
            "default_policy": self._default_policy,
            "watching": watching,
            "reload_interval": self._reload_interval,
            "policies": policies_info,
        }

    # ── 평가 ──────────────────────────────────────────────────────────────────

    def evaluate(
        self,
        report_or_task: Any,
        *,
        policy: Optional[str] = None,
    ) -> PolicyResult:
        """``EvaluationReport`` 또는 ``TaskResult`` 에 대해 정책을 평가한다.

        Args:
            report_or_task: ``EvaluationReport`` 또는 ``TaskResult`` 인스턴스.
                ``to_dict()`` 메서드가 있거나 dict 형식이면 모두 허용.
            policy: 사용할 정책 이름. ``None`` 이면 기본 정책.

        Returns:
            :class:`PolicyResult` — 통과 여부, 위반 목록, 경고 목록 포함.
        """
        pol = self.get_policy(policy)
        metrics = _extract_metrics(report_or_task)
        return _apply_policy(pol, metrics)

    def evaluate_metrics(
        self,
        metrics: Dict[str, float],
        *,
        policy: Optional[str] = None,
    ) -> PolicyResult:
        """메트릭 딕셔너리에 대해 직접 정책을 평가한다.

        Args:
            metrics: ``{metric_name: value}`` 딕셔너리.
            policy: 사용할 정책 이름.

        Returns:
            :class:`PolicyResult`
        """
        pol = self.get_policy(policy)
        return _apply_policy(pol, metrics)

    # ── 핫-리로드 ─────────────────────────────────────────────────────────────

    def start_watching(self) -> None:
        """백그라운드 스레드로 파일 변경 감지를 시작한다.

        이미 실행 중이면 아무 작업도 하지 않는다.
        ``policy_file`` 이 없으면 경고 로그만 남긴다.
        """
        if self._policy_file is None:
            logger.warning("PolicyEngine: policy_file이 없어 watching을 시작할 수 없습니다.")
            return
        if self._watcher is not None and self._watcher.is_alive():
            return
        self._stop_event.clear()
        self._watcher = threading.Thread(
            target=self._watch_loop,
            daemon=True,
            name="PolicyEngineWatcher",
        )
        self._watcher.start()
        logger.debug("PolicyEngine watcher 시작: %s (interval=%.1fs)",
                     self._policy_file, self._reload_interval)

    def stop_watching(self) -> None:
        """백그라운드 감지 스레드를 중단한다."""
        self._stop_event.set()
        if self._watcher is not None:
            self._watcher.join(timeout=max(self._reload_interval + 1, 2))
            self._watcher = None
        logger.debug("PolicyEngine watcher 종료")

    def reload(self) -> None:
        """파일을 즉시 강제 리로드한다."""
        if self._policy_file is None:
            raise RuntimeError("policy_file이 지정되지 않았습니다.")
        self._load_file(self._policy_file)

    @property
    def is_watching(self) -> bool:
        """감지 스레드 실행 여부."""
        return self._watcher is not None and self._watcher.is_alive()

    def _watch_loop(self) -> None:
        import os
        while not self._stop_event.wait(self._reload_interval):
            try:
                mtime = os.path.getmtime(self._policy_file)  # type: ignore[arg-type]
                if self._last_mtime != 0.0 and mtime != self._last_mtime:
                    logger.info(
                        "PolicyEngine: 정책 파일 변경 감지 → 리로드 (%s)",
                        self._policy_file,
                    )
                    self._load_file(self._policy_file)  # type: ignore[arg-type]
                    if self._on_reload:
                        try:
                            self._on_reload()
                        except Exception as exc:
                            logger.debug("on_reload 콜백 실패 (무시): %s", exc)
                self._last_mtime = mtime
            except Exception as exc:
                logger.debug("PolicyEngine watch loop 오류 (무시): %s", exc)

    def _load_file(self, path: str) -> None:
        from .loader import load_policy_file
        import os
        policies = load_policy_file(path)
        with self._lock:
            self._policies.update(policies)
        try:
            self._last_mtime = os.path.getmtime(path)
        except OSError:
            pass
        logger.debug(
            "PolicyEngine: %d개 정책 로드됨 from %s (%s)",
            len(policies), path, list(policies),
        )

    def __repr__(self) -> str:
        n = len(self._policies)
        return (
            f"PolicyEngine(policies={n}, "
            f"default={self._default_policy!r}, "
            f"watching={self.is_watching})"
        )

    def __enter__(self) -> "PolicyEngine":
        self.start_watching()
        return self

    def __exit__(self, *_: Any) -> None:
        self.stop_watching()


# ---------------------------------------------------------------------------
# Internal: metric extraction
# ---------------------------------------------------------------------------

def _extract_metrics(obj: Any) -> Dict[str, float]:
    """``EvaluationReport`` 또는 ``TaskResult`` 에서 메트릭 딕셔너리를 추출한다.

    두 객체 타입을 모두 지원하고, ``to_dict()`` 로 직렬화한 dict도 허용한다.
    알 수 없는 키는 무시한다.
    """
    if hasattr(obj, "to_dict"):
        d: Dict[str, Any] = obj.to_dict()
    elif isinstance(obj, dict):
        d = obj
    else:
        d = {}

    metrics: Dict[str, float] = {}

    # 경로 기반 추출
    for canonical_name, paths in _REPORT_METRIC_PATHS.items():
        for path in paths:
            val = _get_nested(d, path)
            if val is not None:
                try:
                    raw = float(val)
                    # 스케일 정규화 (0-100 % → 0-1, 0-5 score → 0-1)
                    factor = _NORMALIZE.get(canonical_name, 1.0)
                    metrics[canonical_name] = raw * factor
                except (TypeError, ValueError):
                    pass
                break

    # extra 필드 평탄화 (TaskResult.extra)
    extra = d.get("extra") or {}
    if isinstance(extra, dict):
        for k, v in extra.items():
            if isinstance(v, (int, float)) and k not in metrics:
                try:
                    metrics[k] = float(v)
                except (TypeError, ValueError):
                    pass

    # 직접 metric 키가 있으면 추가 (사용자 정의 딕셔너리 지원)
    for k, v in d.items():
        canonical = _METRIC_ALIASES.get(k, k)
        if isinstance(v, (int, float)) and canonical not in metrics:
            try:
                metrics[canonical] = float(v)
            except (TypeError, ValueError):
                pass

    return metrics


def _get_nested(d: Dict[str, Any], path: tuple) -> Optional[float]:
    """중첩 dict에서 경로를 따라 값을 가져온다."""
    cur: Any = d
    for key in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
        if cur is None:
            return None
    return cur if isinstance(cur, (int, float, bool)) else None


# ---------------------------------------------------------------------------
# Internal: policy evaluation
# ---------------------------------------------------------------------------

def _apply_policy(policy: Policy, metrics: Dict[str, float]) -> PolicyResult:
    """Policy 를 metrics dict에 적용해 PolicyResult 를 반환한다."""
    violations: List[RuleViolation] = []
    warnings: List[RuleViolation] = []

    for rule in policy.rules:
        # 별칭 해소
        canonical = _METRIC_ALIASES.get(rule.metric, rule.metric)
        actual = metrics.get(canonical)
        if actual is None:
            actual = metrics.get(rule.metric)
        if actual is None:
            logger.debug(
                "PolicyEngine: 메트릭 %r를 찾을 수 없어 규칙 건너뜀 (available: %s)",
                rule.metric, list(metrics),
            )
            continue

        if not rule.evaluate(actual):
            viol = RuleViolation(
                rule=rule,
                actual_value=actual,
                message=rule.violation_message(actual),
            )
            if rule.severity == "warning":
                warnings.append(viol)
            else:
                violations.append(viol)

    passed = len(violations) == 0
    return PolicyResult(
        policy_name=policy.name,
        passed=passed,
        violations=violations,
        warnings=warnings,
        metrics_evaluated=metrics,
        action=policy.action,
    )
