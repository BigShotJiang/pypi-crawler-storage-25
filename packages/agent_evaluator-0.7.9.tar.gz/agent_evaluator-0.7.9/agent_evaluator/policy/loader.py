"""
loader.py — 정책 파일 로더 (YAML / TOML / JSON)
=================================================

지원 형식:
- ``.yaml`` / ``.yml`` → PyYAML (``pip install pyyaml``)
- ``.toml``            → tomllib (Python 3.11+) 또는 tomli
- ``.json``            → 표준 라이브러리

``extends`` 키워드로 정책 상속(부모 규칙 병합)을 지원한다.
순환 참조는 탐지 후 ``ValueError`` 를 발생시킨다.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Tuple

from .engine import Policy, PolicyAction, PolicyRule

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_policy_file(path: str) -> Dict[str, Policy]:
    """정책 파일을 로드해 ``{name: Policy}`` 딕셔너리를 반환한다.

    Args:
        path: 정책 파일 경로. 확장자로 형식 자동 감지.

    Returns:
        정책 이름 → ``Policy`` 매핑 딕셔너리.

    Raises:
        FileNotFoundError: 파일이 없을 때.
        ValueError: 파싱 오류 또는 순환 상속.
        ImportError: YAML/TOML 파서가 없을 때.
    """
    raw = _load_raw(path)
    return _parse_policies(raw)


def parse_policy_dict(raw: Dict[str, Any]) -> Dict[str, Policy]:
    """원시 딕셔너리에서 Policy 객체 딕셔너리를 반환한다.

    ``load_policy_file`` 없이 인메모리 딕셔너리를 직접 파싱할 때 사용한다.
    """
    return _parse_policies(raw)


# ---------------------------------------------------------------------------
# Format loaders
# ---------------------------------------------------------------------------

def _load_raw(path: str) -> Dict[str, Any]:
    path_lower = path.lower()
    if path_lower.endswith((".yaml", ".yml")):
        return _load_yaml(path)
    if path_lower.endswith(".toml"):
        return _load_toml(path)
    if path_lower.endswith(".json"):
        return _load_json(path)
    # 확장자 없음 → 순서대로 시도
    for loader in (_load_yaml, _load_toml, _load_json):
        try:
            return loader(path)
        except (ImportError, ValueError, json.JSONDecodeError):
            continue
        except Exception:
            continue
    raise ValueError(f"정책 파일 형식을 인식할 수 없습니다: {path}")


def _load_yaml(path: str) -> Dict[str, Any]:
    try:
        import yaml  # type: ignore[import]
    except ImportError as exc:
        raise ImportError(
            "YAML 정책 파일을 사용하려면 PyYAML이 필요합니다: "
            "pip install pyyaml"
        ) from exc
    with open(path, "r", encoding="utf-8") as f:
        result = yaml.safe_load(f)
    return result if isinstance(result, dict) else {}


def _load_toml(path: str) -> Dict[str, Any]:
    try:
        import tomllib  # Python 3.11+
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[import, no-redef]
        except ImportError as exc:
            raise ImportError(
                "TOML 정책 파일을 사용하려면 Python 3.11+ 또는 "
                "tomli가 필요합니다: pip install tomli"
            ) from exc
    with open(path, "rb") as f:
        return tomllib.load(f)


def _load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------

def _parse_policies(raw: Dict[str, Any]) -> Dict[str, Policy]:
    """원시 딕셔너리에서 Policy 객체 딕셔너리를 생성한다."""
    # 최상위에 "policies" 키가 있으면 사용, 없으면 최상위 자체를 정책 컨테이너로
    policies_raw: Dict[str, Any] = raw.get("policies", {})
    if not policies_raw:
        # version/description 등 메타 키 제외 후 정책 딕셔너리로 간주
        policies_raw = {
            k: v
            for k, v in raw.items()
            if k not in ("version", "description", "author")
            and isinstance(v, dict)
            and ("gates" in v or "action" in v or "extends" in v or "description" in v)
        }

    if not policies_raw:
        logger.warning("정책 파일에 policies 섹션이 없습니다.")
        return {}

    # 1단계: 개별 정책 파싱
    parsed: Dict[str, _RawPolicy] = {}
    for name, pdata in policies_raw.items():
        if not isinstance(pdata, dict):
            continue
        try:
            parsed[name] = _parse_single(name, pdata)
        except Exception as exc:
            logger.warning("정책 %r 파싱 실패 (건너뜀): %s", name, exc)

    # 2단계: extends 해소
    resolved: Dict[str, Policy] = {}
    for name in parsed:
        _resolve(name, parsed, resolved, visiting=set())

    return resolved


# ---------------------------------------------------------------------------
# Internal type for parsing stage
# ---------------------------------------------------------------------------

class _RawPolicy:
    """파싱된 정책 데이터 (extends 미해소 상태)."""
    __slots__ = ("policy", "has_explicit_action", "has_explicit_gates")

    def __init__(
        self,
        policy: Policy,
        has_explicit_action: bool,
        has_explicit_gates: bool,
    ) -> None:
        self.policy = policy
        self.has_explicit_action = has_explicit_action
        self.has_explicit_gates = has_explicit_gates


def _parse_single(name: str, data: Dict[str, Any]) -> _RawPolicy:
    """단일 정책 raw dict → _RawPolicy."""
    gates = data.get("gates", {})
    rules: List[PolicyRule] = []
    for metric, spec in (gates or {}).items():
        rules.extend(_parse_gate_spec(metric, spec))

    has_action = "action" in data or "actions" in data
    action_data = data.get("action") or data.get("actions") or {}
    action = PolicyAction(
        on_failure=action_data.get("on_failure", "warn"),
        exit_code=int(action_data.get("exit_code", 1)),
        message=action_data.get("message", ""),
    )

    policy = Policy(
        name=name,
        rules=rules,
        action=action,
        description=data.get("description", ""),
        extends=data.get("extends"),
    )
    return _RawPolicy(
        policy=policy,
        has_explicit_action=has_action,
        has_explicit_gates=bool(gates),
    )


def _parse_gate_spec(metric: str, spec: Any) -> List[PolicyRule]:
    """게이트 스펙 → PolicyRule 리스트.

    지원 형식::

        # 단순 숫자 (min 방향 >=)
        tcr: 0.85

        # min/max 딕셔너리
        tcr: {min: 0.85, severity: error}
        p95_latency: {max: 10.0, severity: warning}

        # 명시적 op/threshold 딕셔너리
        accuracy: {op: gte, threshold: 0.70}
    """
    rules: List[PolicyRule] = []

    if isinstance(spec, (int, float)):
        # 단순 숫자 → gte (min 방향)
        rules.append(PolicyRule(metric=metric, op="gte", threshold=float(spec)))
        return rules

    if not isinstance(spec, dict):
        logger.warning("게이트 %r 형식 미인식 (건너뜀): %r", metric, spec)
        return rules

    severity: str = spec.get("severity", "error")
    description: str = spec.get("description", "")

    if "min" in spec:
        rules.append(PolicyRule(
            metric=metric, op="gte", threshold=float(spec["min"]),
            severity=severity, description=description,
        ))
    if "max" in spec:
        rules.append(PolicyRule(
            metric=metric, op="lte", threshold=float(spec["max"]),
            severity=severity, description=description,
        ))
    if "eq" in spec:
        rules.append(PolicyRule(
            metric=metric, op="eq", threshold=float(spec["eq"]),
            severity=severity, description=description,
        ))

    # 명시적 op/threshold 형식 (min/max/eq 키가 없을 때만)
    if not rules:
        op = str(spec.get("op", "gte"))
        threshold = spec.get("threshold", spec.get("value"))
        if threshold is not None:
            rules.append(PolicyRule(
                metric=metric, op=op, threshold=float(threshold),
                severity=severity, description=description,
            ))
        else:
            logger.warning(
                "게이트 %r에 threshold가 없습니다 (건너뜀): %r", metric, spec
            )

    return rules


def _resolve(
    name: str,
    parsed: Dict[str, "_RawPolicy"],
    resolved: Dict[str, Policy],
    visiting: set,
) -> Policy:
    """extends 체인을 재귀적으로 해소한다."""
    if name in resolved:
        return resolved[name]

    if name in visiting:
        raise ValueError(f"순환 참조 감지: 정책 {name!r} extends 체인")

    raw = parsed[name]
    pol = raw.policy

    if pol.extends is None:
        resolved[name] = pol
        return pol

    parent_name = pol.extends
    if parent_name not in parsed:
        raise ValueError(
            f"정책 {name!r}의 extends={parent_name!r}를 찾을 수 없습니다. "
            f"사용 가능: {list(parsed)}"
        )

    visiting.add(name)
    parent = _resolve(parent_name, parsed, resolved, visiting)
    visiting.discard(name)

    # 규칙 병합: (metric, op) 키로 child가 parent를 덮어씀
    merged_rules: Dict[Tuple[str, str], PolicyRule] = {
        (r.metric, r.op): r for r in parent.rules
    }
    for r in pol.rules:
        merged_rules[(r.metric, r.op)] = r

    # 액션: child에 명시적 action이 있으면 child, 없으면 parent 상속
    merged_action = pol.action if raw.has_explicit_action else parent.action

    merged = Policy(
        name=name,
        rules=list(merged_rules.values()),
        action=merged_action,
        description=pol.description or parent.description,
        extends=pol.extends,
    )
    resolved[name] = merged
    return merged
