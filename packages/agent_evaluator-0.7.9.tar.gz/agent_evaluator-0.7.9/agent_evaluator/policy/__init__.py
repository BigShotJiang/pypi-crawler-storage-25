"""
agent_evaluator.policy — YAML 기반 배포 게이팅 · 런타임 핫-리로드
===================================================================

정책 파일(YAML/TOML/JSON)에 게이팅 임계값을 선언하고, 코드 변경 없이
배포 기준을 갱신할 수 있다.

Quick Start::

    from agent_evaluator.policy import PolicyEngine

    engine = PolicyEngine("agent_eval_policy.yaml", policy="production")

    # EvaluationReport 또는 TaskResult 평가
    result = engine.evaluate(monitor.generate_report())
    result.enforce()   # on_failure 액션 실행 (warn/raise/exit)

    print(result.summary())
    print(result.to_dict())

Hot-Reload::

    engine.start_watching()   # 백그라운드 스레드 시작
    # ... 운영 중 policy.yaml 수정 → 자동 리로드
    engine.stop_watching()

    # context manager 형태
    with PolicyEngine("policy.yaml") as engine:
        result = engine.evaluate(report)
        result.enforce()
"""

from .engine import (
    PolicyRule,
    PolicyAction,
    Policy,
    RuleViolation,
    PolicyResult,
    PolicyViolationError,
    PolicyEngine,
)
from .loader import load_policy_file, parse_policy_dict

__all__ = [
    "PolicyRule",
    "PolicyAction",
    "Policy",
    "RuleViolation",
    "PolicyResult",
    "PolicyViolationError",
    "PolicyEngine",
    "load_policy_file",
    "parse_policy_dict",
]
