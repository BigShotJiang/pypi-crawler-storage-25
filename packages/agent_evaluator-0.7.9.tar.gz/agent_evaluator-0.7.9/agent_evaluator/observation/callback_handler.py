"""
callback_handler.py — EvalCallbackHandler (LangChain 자동 추적)
================================================================

LangChain ``BaseCallbackHandler`` 를 상속하여 체인/도구/에이전트 이벤트를
EvalEventBus에 자동으로 발행하고, PerformanceMonitor의
``WorkflowExecutionTracker`` 를 직접 업데이트한다.

``langchain_core`` 가 설치되지 않은 환경에서는 ``EvalCallbackHandler`` 가
``FallbackCallbackHandler`` (빈 클래스)로 대체되어 ImportError 없이 동작한다.

사용 예::

    from langchain.agents import AgentExecutor
    from agent_evaluator import PerformanceMonitor
    from agent_evaluator.observation import EvalCallbackHandler

    monitor = PerformanceMonitor(output_dir="results/")
    handler = EvalCallbackHandler(monitor=monitor, task_id="task_001")

    agent_executor = AgentExecutor(agent=agent, tools=tools,
                                   callbacks=[handler])
    result = agent_executor.invoke({"input": "..."})
    # → WorkflowExecutionTracker에 체인/도구 단계 자동 기록
    # → EvalEventBus에 chain_start/chain_end/tool_start/tool_end 이벤트 발행
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional, Union

from .bus import EvalEvent, EvalEventBus

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# LangChain 임포트 — graceful fallback
# ---------------------------------------------------------------------------

try:
    from langchain_core.callbacks import BaseCallbackHandler  # type: ignore[import]
    from langchain_core.outputs import LLMResult  # type: ignore[import]
    _LANGCHAIN_AVAILABLE = True
except ImportError:
    try:
        from langchain.callbacks.base import BaseCallbackHandler  # type: ignore[import]
        from langchain.schema import LLMResult  # type: ignore[import]
        _LANGCHAIN_AVAILABLE = True
    except ImportError:
        _LANGCHAIN_AVAILABLE = False

        class BaseCallbackHandler:  # type: ignore[no-redef]
            """langchain_core 미설치 시 사용하는 빈 베이스 클래스."""
            pass

        class LLMResult:  # type: ignore[no-redef]
            pass


# ---------------------------------------------------------------------------
# EvalCallbackHandler
# ---------------------------------------------------------------------------

class EvalCallbackHandler(BaseCallbackHandler):
    """LangChain 체인/도구/에이전트 이벤트를 EvalEventBus와 monitor에 자동 기록.

    ``PerformanceMonitor`` 에 직접 연결하면 ``WorkflowExecutionTracker`` 가
    ``pip install langchain`` 만으로 자동 활성화된다.

    Args:
        monitor: ``PerformanceMonitor`` 인스턴스. ``None`` 이면 버스 발행만.
        task_id: ``WorkflowExecutionTracker`` 에 기록할 task_id.
            ``None`` 이면 내부 UUID 자동 생성.
        session_id: 버스 이벤트에 붙이는 세션 식별자.
        framework: ``WorkflowExecutionTracker`` 의 framework 필드 값.
        verbose: ``True`` 이면 이벤트를 logger.info 로 출력.

    Example::

        handler = EvalCallbackHandler(monitor=monitor, task_id="t001")
        chain = LLMChain(llm=llm, prompt=prompt, callbacks=[handler])
        chain.run("input")
    """

    def __init__(
        self,
        monitor: Optional[Any] = None,
        *,
        task_id: Optional[str] = None,
        session_id: Optional[str] = None,
        framework: str = "langchain",
        verbose: bool = False,
    ) -> None:
        if _LANGCHAIN_AVAILABLE:
            super().__init__()
        self.monitor = monitor
        self.task_id = task_id or f"lc_{id(self):x}"
        self.session_id = session_id
        self.framework = framework
        self.verbose = verbose

        # 체인 단위 타이밍 스택 (중첩 체인 지원)
        self._chain_stack: List[Dict[str, Any]] = []

        # 도구 단위 타이밍 (run_id → start_time)
        self._tool_timings: Dict[str, float] = {}

    # ── 내부 유틸 ───────────────────────────────────────────────────────────

    def _emit(self, event_type: str, source: str, payload: Dict[str, Any]) -> None:
        event = EvalEvent(
            event_type=event_type,
            source=source,
            payload=payload,
            session_id=self.session_id,
        )
        EvalEventBus.emit(event)
        if self.verbose:
            logger.info("[EvalCallbackHandler] %s source=%r", event_type, source)

    def _track_step(
        self,
        step_name: str,
        step_type: str,
        success: bool,
        duration: float,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        if self.monitor is None:
            return
        try:
            wf = getattr(self.monitor, "workflow_tracker", None)
            if wf is not None:
                wf.track_step(
                    task_id=self.task_id,
                    step_name=step_name,
                    step_type=step_type,
                    success=success,
                    execution_time=duration,
                    framework=self.framework,
                    metadata=metadata,
                )
        except Exception as exc:
            logger.debug("WorkflowExecutionTracker.track_step 실패: %s", exc)

    # ── Chain callbacks ──────────────────────────────────────────────────────

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        **kwargs: Any,
    ) -> None:
        chain_name = (
            serialized.get("name")
            or serialized.get("id", ["unknown"])[-1]
            if serialized else "chain"
        )
        self._chain_stack.append({"name": chain_name, "start": time.perf_counter()})
        self._emit("chain_start", chain_name, {"inputs_keys": list((inputs or {}).keys())})

    def on_chain_end(self, outputs: Dict[str, Any], **kwargs: Any) -> None:
        if not self._chain_stack:
            return
        frame = self._chain_stack.pop()
        duration = time.perf_counter() - frame["start"]
        chain_name = frame["name"]

        self._emit(
            "chain_end",
            chain_name,
            {
                "chain_name": chain_name,
                "duration": duration,
                "success": True,
                "outputs": {k: str(v)[:200] for k, v in (outputs or {}).items()},
            },
        )
        self._track_step(chain_name, "chain", True, duration,
                         {"outputs": list((outputs or {}).keys())})

    def on_chain_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        **kwargs: Any,
    ) -> None:
        if not self._chain_stack:
            return
        frame = self._chain_stack.pop()
        duration = time.perf_counter() - frame["start"]
        chain_name = frame["name"]

        self._emit(
            "chain_end",
            chain_name,
            {"chain_name": chain_name, "duration": duration, "success": False, "error": str(error)},
        )
        self._track_step(chain_name, "chain", False, duration, {"error": str(error)})

    # ── Tool callbacks ───────────────────────────────────────────────────────

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        tool_name = (
            serialized.get("name") or "tool"
            if serialized else "tool"
        )
        key = str(run_id) if run_id else tool_name
        self._tool_timings[key] = time.perf_counter()
        self._emit("tool_start", tool_name, {"input": str(input_str)[:300]})

    def on_tool_end(
        self,
        output: str,
        *,
        run_id: Optional[Any] = None,
        name: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        tool_name = name or "tool"
        key = str(run_id) if run_id else tool_name
        start_ts = self._tool_timings.pop(key, time.perf_counter())
        duration = time.perf_counter() - start_ts

        self._emit(
            "tool_end",
            tool_name,
            {"duration": duration, "success": True, "output": str(output)[:300]},
        )
        self._track_step(tool_name, "tool", True, duration)

    def on_tool_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: Optional[Any] = None,
        name: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        tool_name = name or "tool"
        key = str(run_id) if run_id else tool_name
        start_ts = self._tool_timings.pop(key, time.perf_counter())
        duration = time.perf_counter() - start_ts

        self._emit(
            "tool_end",
            tool_name,
            {"duration": duration, "success": False, "error": str(error)},
        )
        self._track_step(tool_name, "tool", False, duration, {"error": str(error)})

    # ── Agent callbacks ──────────────────────────────────────────────────────

    def on_agent_action(self, action: Any, **kwargs: Any) -> None:
        tool = getattr(action, "tool", "unknown")
        tool_input = getattr(action, "tool_input", "")
        self._emit(
            "agent_action",
            tool,
            {"tool": tool, "input": str(tool_input)[:300]},
        )

    def on_agent_finish(self, finish: Any, **kwargs: Any) -> None:
        output = getattr(finish, "return_values", {})
        self._emit(
            "agent_finish",
            "agent",
            {"output": str(output)[:300]},
        )

    # ── LLM callbacks (버스 발행만; 기록은 framework adapter가 담당) ─────────

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        **kwargs: Any,
    ) -> None:
        model = (
            serialized.get("name") or serialized.get("model_name", "llm")
            if serialized else "llm"
        )
        self._emit("llm_start", model, {"prompt_count": len(prompts)})

    def on_llm_end(self, response: Any, **kwargs: Any) -> None:
        self._emit("llm_end", "llm", {})

    # ── 편의 메서드 ──────────────────────────────────────────────────────────

    def reset(self) -> None:
        """내부 타이밍 스택을 초기화한다 (재사용 시)."""
        self._chain_stack.clear()
        self._tool_timings.clear()

    @property
    def is_langchain_available(self) -> bool:
        """langchain_core 가 설치되어 있는지 여부."""
        return _LANGCHAIN_AVAILABLE
