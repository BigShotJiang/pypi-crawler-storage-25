"""
observation/ — Phase 3: Observation Bus
========================================

이벤트 기반으로 5개 "불가능한" 지표를 자동 수집한다.

해결하는 지표
-------------
- AgentCoordination  — ``@observe_agent`` 로 에이전트 간 호출 그래프 자동 추적
- WorkflowExecution  — ``EvalCallbackHandler`` 로 LangChain 체인 이벤트 자동 수집
- ImplicitFeedback   — ``EvalFeedbackMiddleware`` 로 HTTP 요청/응답 신호 자동 수집

공개 API
---------
    from agent_evaluator.observation import (
        EvalEvent,
        EvalEventBus,
        observe_agent,
        connect_monitor_to_bus,
        EvalCallbackHandler,
        EvalFeedbackMiddleware,
    )
"""

from .bus import EvalEvent, EvalEventBus
from .observe import observe_agent, connect_monitor_to_bus
from .callback_handler import EvalCallbackHandler
from .middleware import EvalFeedbackMiddleware

__all__ = [
    "EvalEvent",
    "EvalEventBus",
    "observe_agent",
    "connect_monitor_to_bus",
    "EvalCallbackHandler",
    "EvalFeedbackMiddleware",
]
