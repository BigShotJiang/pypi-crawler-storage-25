"""
observe.py — @observe_agent + connect_monitor_to_bus
======================================================

``@observe_agent`` 는 에이전트 함수를 감싸 EvalEventBus에 이벤트를 발행하고,
``ContextVar`` 로 호출 스택을 추적하여 에이전트 간 호출 그래프를 자동 구성한다.

``connect_monitor_to_bus`` 는 EvalEventBus 구독을 설정해
``agent_end`` 이벤트를 ``AgentCoordinationTracker.track_interaction()`` 으로
자동 연결한다.

사용 예::

    from agent_evaluator import PerformanceMonitor
    from agent_evaluator.observation import observe_agent, connect_monitor_to_bus

    monitor = PerformanceMonitor(output_dir="results/")

    # Bus와 monitor 연결 (AgentCoordination 자동 기록)
    disconnect = connect_monitor_to_bus(monitor)

    @observe_agent("orchestrator", role="orchestrator")
    def orchestrator(task: str) -> str:
        result = worker(task)       # worker 호출이 자동으로 coordination 이벤트 발행
        return result

    @observe_agent("worker", role="worker")
    def worker(task: str) -> str:
        return f"done: {task}"

    orchestrator("analyse data")
    # → AgentCoordinationTracker에 orchestrator → worker 인터랙션 자동 기록

    disconnect()  # 구독 해제 (선택)
"""

from __future__ import annotations

import asyncio
import contextvars
import functools
import inspect
import logging
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

from .bus import EvalEvent, EvalEventBus

logger = logging.getLogger(__name__)

# ContextVar — 현재 실행 중인 에이전트 이름 추적 (asyncio 안전)
_current_agent: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "_observe_current_agent", default=None
)

# 세션 ContextVar — 멀티턴 식별자
_current_session: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "_observe_current_session", default=None
)


# ---------------------------------------------------------------------------
# @observe_agent
# ---------------------------------------------------------------------------

def observe_agent(
    name: Optional[str] = None,
    *,
    role: str = "worker",
    session_id: Optional[str] = None,
    session_id_fn: Optional[Callable] = None,
    emit_payload: bool = True,
) -> Callable:
    """에이전트 함수에 이벤트 관찰을 적용하는 데코레이터.

    함수 실행 전·후에 ``agent_start`` / ``agent_end`` 이벤트를 EvalEventBus에
    발행하고, ``ContextVar`` 로 호출 스택을 추적하여 에이전트 간 호출 관계를
    자동으로 기록한다.

    ``connect_monitor_to_bus(monitor)`` 와 함께 사용하면 ``AgentCoordinationTracker``
    가 자동으로 인터랙션을 기록한다.

    Args:
        name: 버스에서 사용할 에이전트 이름. ``None`` 이면 함수명 사용.
        role: 에이전트 역할 (``"orchestrator"``, ``"worker"``, ``"specialist"`` 등).
            대시보드 네트워크 뷰에서 사용된다.
        session_id: 고정 세션 ID. 동적 ID 가 필요하면 ``session_id_fn`` 사용.
        session_id_fn: ``(args, kwargs) -> str`` 동적 세션 ID 생성 함수.
        emit_payload: ``True`` 이면 첫 번째 인자(question/task)를 payload에 포함.
            민감한 데이터가 있으면 ``False`` 로 설정.

    Returns:
        함수를 감싸는 데코레이터. 반환값과 예외는 원본 함수 그대로 전달된다.

    Example::

        @observe_agent("planner", role="orchestrator")
        def plan(task: str) -> str:
            sub_result = execute(task)
            return f"plan({sub_result})"

        @observe_agent  # 이름 생략 시 함수명 사용
        def execute(task: str) -> str:
            return "done"
    """
    # bare @observe_agent (parens 없음) 지원
    if callable(name) and not isinstance(name, str):
        fn = name
        return observe_agent(fn.__name__, role=role)(fn)

    def decorator(func: Callable) -> Callable:
        agent_name: str = name or func.__name__

        def _build_event(
            event_type: str,
            caller: Optional[str],
            sid: Optional[str],
            extra: Optional[Dict[str, Any]] = None,
        ) -> EvalEvent:
            payload: Dict[str, Any] = {"role": role}
            if extra:
                payload.update(extra)
            return EvalEvent(
                event_type=event_type,
                source=agent_name,
                payload=payload,
                session_id=sid,
                parent_source=caller,
            )

        def _resolve_session(args: tuple, kwargs: dict) -> Optional[str]:
            if session_id_fn is not None:
                try:
                    return session_id_fn(args, kwargs)
                except Exception:
                    pass
            return session_id or _current_session.get(None)

        def _start(args: tuple, kwargs: dict):
            caller = _current_agent.get(None)
            sid = _resolve_session(args, kwargs)
            token_agent = _current_agent.set(agent_name)
            token_session = _current_session.set(sid) if sid else None

            start_payload: Dict[str, Any] = {}
            if emit_payload and args:
                try:
                    start_payload["input"] = str(args[0])[:200]
                except Exception:
                    pass

            EvalEventBus.emit(_build_event("agent_start", caller, sid, start_payload))
            return caller, sid, token_agent, token_session

        def _end(caller, sid, token_agent, token_session, elapsed, success, error_msg=None):
            _current_agent.reset(token_agent)
            if token_session is not None:
                _current_session.reset(token_session)
            EvalEventBus.emit(
                _build_event(
                    "agent_end",
                    caller,
                    sid,
                    {
                        "caller": caller,
                        "duration": elapsed,
                        "success": success,
                        **({"error": error_msg} if error_msg else {}),
                    },
                )
            )

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            caller, sid, token_agent, token_session = _start(args, kwargs)
            start_ts = time.perf_counter()
            try:
                result = func(*args, **kwargs)
                _end(caller, sid, token_agent, token_session,
                     time.perf_counter() - start_ts, True)
                return result
            except Exception as exc:
                _end(caller, sid, token_agent, token_session,
                     time.perf_counter() - start_ts, False, str(exc))
                raise

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            caller, sid, token_agent, token_session = _start(args, kwargs)
            start_ts = time.perf_counter()
            try:
                result = await func(*args, **kwargs)
                _end(caller, sid, token_agent, token_session,
                     time.perf_counter() - start_ts, True)
                return result
            except Exception as exc:
                _end(caller, sid, token_agent, token_session,
                     time.perf_counter() - start_ts, False, str(exc))
                raise

        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return wrapper

    return decorator


# ---------------------------------------------------------------------------
# connect_monitor_to_bus
# ---------------------------------------------------------------------------

def connect_monitor_to_bus(
    monitor: Any,
    *,
    session_id: Optional[str] = None,
    workflow_task_id: Optional[str] = None,
    workflow_framework: str = "observe_agent",
) -> Callable[[], None]:
    """EvalEventBus 구독을 설정하여 ``@observe_agent`` 이벤트를 monitor에 자동 기록한다.

    ``agent_end`` 이벤트 → ``AgentCoordinationTracker.track_interaction()``
    ``chain_end``  이벤트 → ``WorkflowExecutionTracker.track_step()``

    Args:
        monitor: ``PerformanceMonitor`` 인스턴스.
        session_id: 고정 세션 ID. ``None`` 이면 이벤트의 ``session_id`` 사용.
        workflow_task_id: ``WorkflowExecutionTracker`` 에 기록할 task_id.
            ``None`` 이면 이벤트의 ``session_id`` 또는 ``"workflow_default"`` 사용.
        workflow_framework: ``WorkflowExecutionTracker.track_step()`` 의 framework 파라미터.

    Returns:
        구독 해제 함수 ``disconnect()``. 더 이상 연동이 필요 없을 때 호출.

    Example::

        monitor = PerformanceMonitor(output_dir="results/")
        disconnect = connect_monitor_to_bus(monitor)

        # ... @observe_agent 호출 ...

        disconnect()  # 구독 해제
    """
    sub_ids: List[str] = []

    # ── agent_end → AgentCoordinationTracker ─────────────────────────────

    def _on_agent_end(event: EvalEvent) -> None:
        caller = event.payload.get("caller")
        if not caller:
            return  # 호출자가 없으면 coordination 없음

        duration = float(event.payload.get("duration", 0.0))
        success = bool(event.payload.get("success", True))
        task_id = session_id or event.session_id or f"session_{event.event_id}"

        try:
            coord_tracker = getattr(monitor, "agent_coordination_tracker", None)
            if coord_tracker is not None:
                coord_tracker.track_interaction(
                    task_id=task_id,
                    from_agent=caller,
                    to_agent=event.source,
                    interaction_type="call",
                    success=success,
                    context={"duration": duration, "role": event.payload.get("role", "worker")},
                )
                logger.debug(
                    "AgentCoordination: %s → %s (%.3fs, success=%s)",
                    caller, event.source, duration, success,
                )
        except Exception as exc:
            logger.debug("connect_monitor_to_bus agent_end 처리 실패: %s", exc)

    sub_ids.append(EvalEventBus.subscribe("agent_end", _on_agent_end))

    # ── chain_end → WorkflowExecutionTracker ─────────────────────────────

    def _on_chain_end(event: EvalEvent) -> None:
        tid = workflow_task_id or session_id or event.session_id or "workflow_default"
        step_name = event.payload.get("chain_name", event.source or "chain")
        duration = float(event.payload.get("duration", 0.0))
        success = bool(event.payload.get("success", True))

        try:
            wf_tracker = getattr(monitor, "workflow_tracker", None)
            if wf_tracker is not None:
                wf_tracker.track_step(
                    task_id=tid,
                    step_name=step_name,
                    step_type="chain",
                    success=success,
                    execution_time=duration,
                    framework=workflow_framework,
                    metadata={"outputs": event.payload.get("outputs")},
                )
                logger.debug("WorkflowExecution: step=%r task=%r", step_name, tid)
        except Exception as exc:
            logger.debug("connect_monitor_to_bus chain_end 처리 실패: %s", exc)

    sub_ids.append(EvalEventBus.subscribe("chain_end", _on_chain_end))

    # ── tool_end → chain_steps 보조 기록 (WorkflowExecutionTracker) ───────

    def _on_tool_end(event: EvalEvent) -> None:
        tid = workflow_task_id or session_id or event.session_id or "workflow_default"
        try:
            wf_tracker = getattr(monitor, "workflow_tracker", None)
            if wf_tracker is not None:
                wf_tracker.track_step(
                    task_id=tid,
                    step_name=event.source or "tool",
                    step_type="tool",
                    success=bool(event.payload.get("success", True)),
                    execution_time=float(event.payload.get("duration", 0.0)),
                    framework=workflow_framework,
                )
        except Exception as exc:
            logger.debug("connect_monitor_to_bus tool_end 처리 실패: %s", exc)

    sub_ids.append(EvalEventBus.subscribe("tool_end", _on_tool_end))

    def disconnect() -> None:
        """EvalEventBus 구독을 해제한다."""
        for sid in sub_ids:
            EvalEventBus.unsubscribe(sid)
        sub_ids.clear()
        logger.debug("connect_monitor_to_bus 구독 해제 완료")

    return disconnect
