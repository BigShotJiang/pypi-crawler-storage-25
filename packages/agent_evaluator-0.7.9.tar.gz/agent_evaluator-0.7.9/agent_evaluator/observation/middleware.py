"""
middleware.py — EvalFeedbackMiddleware (ASGI ImplicitFeedback 자동 수집)
========================================================================

FastAPI / Starlette ASGI 미들웨어. HTTP 요청/응답 패턴에서
``ImplicitFeedbackTracker`` 가 필요로 하는 신호를 자동으로 수집한다.

수집하는 신호
--------------
1. **응답 시간** — ``slow_threshold_s`` 초 초과 시 ``"slow_response"`` 피드백
2. **HTTP 상태 코드** — 4xx/5xx → ``"error_response"``, 2xx → ``"success_response"``
3. **명시적 피드백 헤더** — ``X-Eval-Feedback: positive / negative / neutral``
4. **Task ID 헤더** — ``X-Eval-Task-ID`` 로 어떤 task에 피드백을 달지 지정

사용 예::

    from fastapi import FastAPI
    from agent_evaluator import PerformanceMonitor
    from agent_evaluator.observation import EvalFeedbackMiddleware

    app = FastAPI()
    monitor = PerformanceMonitor(output_dir="results/")

    app.add_middleware(
        EvalFeedbackMiddleware,
        monitor=monitor,
        slow_threshold_s=2.0,
        feedback_endpoints=["/api/chat", "/api/query"],
    )

    @app.post("/api/chat")
    async def chat(request: Request):
        task_id = str(uuid.uuid4())
        response = await process(request)
        # 클라이언트가 X-Eval-Task-ID 헤더를 보내거나
        # 여기서 헤더를 직접 설정하면 ImplicitFeedback 자동 기록
        return JSONResponse(content=response, headers={"X-Eval-Task-ID": task_id})

설정 옵션
----------
``monitor``
    ``PerformanceMonitor`` 인스턴스.
``slow_threshold_s``
    이 시간(초) 이상 걸리면 ``"slow_response"`` 피드백 기록. 기본 2.0초.
``feedback_endpoints``
    모니터링할 경로 목록. ``None`` 이면 전체 경로.
    접두사 매칭: ``["/api/"]`` 이면 ``/api/chat``, ``/api/query`` 모두 매칭.
``task_id_header``
    task_id를 전달하는 요청 헤더명. 기본 ``"X-Eval-Task-ID"``.
    없으면 ``path_method_timestamp`` 형식 자동 생성.
``feedback_header``
    명시적 피드백 신호를 전달하는 요청 헤더명. 기본 ``"X-Eval-Feedback"``.
    값: ``"positive"`` / ``"negative"`` / ``"neutral"``.
``error_status_codes``
    피드백 ``"error_response"`` 로 기록할 HTTP 상태코드 집합.
    기본: ``{400, 422, 429, 500, 502, 503, 504}``.
``emit_bus_events``
    ``True`` 이면 ``http_request`` 이벤트를 EvalEventBus에도 발행.
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any, Callable, Dict, Optional, Set

from .bus import EvalEvent, EvalEventBus

logger = logging.getLogger(__name__)

_DEFAULT_ERROR_CODES: Set[int] = {400, 422, 429, 500, 502, 503, 504}
_DEFAULT_SLOW_THRESHOLD = 2.0
_TASK_ID_HEADER = "x-eval-task-id"
_FEEDBACK_HEADER = "x-eval-feedback"


class EvalFeedbackMiddleware:
    """ASGI 미들웨어 — HTTP 요청/응답 신호를 ImplicitFeedbackTracker에 자동 기록.

    ``fastapi`` 또는 ``starlette`` 없이도 ``__call__`` 시그니처만 맞으면 동작하지만,
    실제 사용은 ASGI 서버 위에서 해야 한다.
    """

    def __init__(
        self,
        app: Any,
        *,
        monitor: Optional[Any] = None,
        slow_threshold_s: float = _DEFAULT_SLOW_THRESHOLD,
        feedback_endpoints: Optional[list] = None,
        task_id_header: str = "X-Eval-Task-ID",
        feedback_header: str = "X-Eval-Feedback",
        error_status_codes: Optional[Set[int]] = None,
        emit_bus_events: bool = True,
    ) -> None:
        self.app = app
        self.monitor = monitor
        self.slow_threshold_s = slow_threshold_s
        self.feedback_endpoints = feedback_endpoints  # None = 전체 경로
        self.task_id_header = task_id_header.lower()
        self.feedback_header = feedback_header.lower()
        self.error_status_codes = error_status_codes or _DEFAULT_ERROR_CODES
        self.emit_bus_events = emit_bus_events

    # ── ASGI interface ───────────────────────────────────────────────────────

    async def __call__(self, scope: Dict, receive: Any, send: Any) -> None:
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        path: str = scope.get("path", "")
        if not self._should_monitor(path):
            await self.app(scope, receive, send)
            return

        # 요청 헤더에서 task_id + 명시적 피드백 추출
        headers: Dict[str, str] = {
            k.decode().lower(): v.decode()
            for k, v in scope.get("headers", [])
        }
        task_id = headers.get(self.task_id_header) or self._auto_task_id(path, scope)
        explicit_feedback = headers.get(self.feedback_header)  # positive / negative / neutral

        # 응답 상태코드를 가로채기 위한 래핑
        response_info: Dict[str, Any] = {}

        async def wrapped_send(message: Dict) -> None:
            if message.get("type") == "http.response.start":
                response_info["status"] = message.get("status", 200)
                # 응답 헤더에서도 task_id 읽기 (서버가 응답에 추가하는 경우)
                resp_headers = dict(message.get("headers", []))
                resp_task_id = resp_headers.get(self.task_id_header.encode())
                if resp_task_id:
                    response_info["task_id"] = resp_task_id.decode()
            await send(message)

        start_ts = time.perf_counter()
        try:
            await self.app(scope, receive, wrapped_send)
        finally:
            elapsed = time.perf_counter() - start_ts
            status = response_info.get("status", 200)
            effective_task_id = response_info.get("task_id", task_id)
            method = scope.get("method", "GET")

            self._record_feedback(
                task_id=effective_task_id,
                path=path,
                method=method,
                status=status,
                elapsed=elapsed,
                explicit_feedback=explicit_feedback,
            )

    # ── 내부 로직 ──────────────────────────────────────────────────────────

    def _should_monitor(self, path: str) -> bool:
        if self.feedback_endpoints is None:
            return True
        return any(path.startswith(ep) for ep in self.feedback_endpoints)

    def _auto_task_id(self, path: str, scope: Dict) -> str:
        method = scope.get("method", "GET")
        ts = int(time.time() * 1000)
        clean_path = path.replace("/", "_").strip("_") or "root"
        return f"{method}_{clean_path}_{ts}"

    def _record_feedback(
        self,
        task_id: str,
        path: str,
        method: str,
        status: int,
        elapsed: float,
        explicit_feedback: Optional[str],
    ) -> None:
        signals = []

        # 1. 명시적 피드백 헤더
        if explicit_feedback in ("positive", "negative", "neutral"):
            signals.append(explicit_feedback)

        # 2. 응답 시간
        if elapsed > self.slow_threshold_s:
            signals.append("slow_response")

        # 3. HTTP 상태코드
        if status in self.error_status_codes:
            signals.append("error_response")
        elif 200 <= status < 300 and not explicit_feedback:
            signals.append("success_response")

        metadata = {
            "path": path,
            "method": method,
            "status": status,
            "latency_s": round(elapsed, 4),
        }

        # monitor 기록
        if self.monitor is not None:
            for signal in signals:
                try:
                    self.monitor.record_implicit_feedback(
                        task_id=task_id,
                        feedback_type=signal,
                        metadata=metadata,
                    )
                except Exception as exc:
                    logger.debug("ImplicitFeedback 기록 실패 (무시): %s", exc)

        # EvalEventBus 발행
        if self.emit_bus_events:
            try:
                EvalEventBus.emit(EvalEvent(
                    event_type="http_request",
                    source=f"{method} {path}",
                    payload={
                        "task_id": task_id,
                        "status": status,
                        "latency_s": round(elapsed, 4),
                        "signals": signals,
                        **metadata,
                    },
                    session_id=task_id,
                ))
            except Exception as exc:
                logger.debug("EvalEventBus http_request 발행 실패: %s", exc)

        if signals:
            logger.debug(
                "EvalFeedbackMiddleware: task=%r path=%r status=%d signals=%s",
                task_id, path, status, signals,
            )
