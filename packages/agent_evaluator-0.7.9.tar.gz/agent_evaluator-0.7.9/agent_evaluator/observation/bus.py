"""
bus.py — EvalEvent + EvalEventBus
===================================

Thread-safe pub/sub 이벤트 버스. SDK 내부 컴포넌트와 사용자 코드 양쪽에서
평가 이벤트를 발행(emit)하고 구독(subscribe)할 수 있다.

이벤트 유형 (event_type)
-------------------------
``agent_start``   — ``@observe_agent`` 함수 실행 시작
``agent_end``     — ``@observe_agent`` 함수 실행 완료
``tool_start``    — LangChain 도구 실행 시작
``tool_end``      — LangChain 도구 실행 완료
``chain_start``   — LangChain 체인 실행 시작
``chain_end``     — LangChain 체인 실행 완료
``agent_action``  — LangChain 에이전트 액션 선택
``agent_finish``  — LangChain 에이전트 완료
``http_request``  — ASGI 미들웨어 HTTP 요청 완료 (ImplicitFeedback 연동)
``*``             — 모든 이벤트 유형을 구독하는 와일드카드

사용 예::

    from agent_evaluator.observation import EvalEvent, EvalEventBus

    # 구독
    def my_handler(event: EvalEvent):
        print(f"[{event.event_type}] {event.source}")

    sub_id = EvalEventBus.subscribe("agent_end", my_handler)

    # 발행 (SDK 내부 또는 사용자 코드)
    EvalEventBus.emit(EvalEvent(event_type="agent_end", source="my_agent", payload={}))

    # 구독 해제
    EvalEventBus.unsubscribe(sub_id)
"""

from __future__ import annotations

import collections
import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_WILDCARD = "*"
_DEFAULT_HISTORY_SIZE = 500


# ---------------------------------------------------------------------------
# EvalEvent
# ---------------------------------------------------------------------------

@dataclass
class EvalEvent:
    """단일 평가 이벤트.

    Attributes:
        event_type: 이벤트 종류 (``"agent_start"``, ``"chain_end"`` 등).
        source: 이벤트를 발행한 에이전트 / 도구 이름.
        payload: 이벤트별 추가 데이터.
        timestamp: 발행 시각 (``time.time()``).
        session_id: 멀티턴 대화 / 워크플로 세션 식별자.
        parent_source: 이 이벤트를 유발한 상위 에이전트 이름 (호출 그래프 추적용).
        event_id: 자동 생성 고유 ID (UUID 8자리).
    """

    event_type: str
    source: str
    payload: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    session_id: Optional[str] = None
    parent_source: Optional[str] = None
    event_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def __repr__(self) -> str:
        return (
            f"EvalEvent(type={self.event_type!r}, source={self.source!r}, "
            f"session={self.session_id!r}, id={self.event_id})"
        )


# ---------------------------------------------------------------------------
# EvalEventBus
# ---------------------------------------------------------------------------

class EvalEventBus:
    """Thread-safe pub/sub 이벤트 버스 (클래스메서드 기반 싱글톤).

    모든 SDK 컴포넌트와 사용자 코드가 공유하는 단일 버스.
    구독자(handler)가 없어도 ``emit()`` 은 항상 성공하며,
    핸들러 예외는 포착하여 로그로만 출력한다.
    """

    # {event_type: {sub_id: handler}}
    _subscribers: Dict[str, Dict[str, Callable[[EvalEvent], None]]] = {}
    _lock = threading.Lock()
    _history: Deque[EvalEvent] = collections.deque(maxlen=_DEFAULT_HISTORY_SIZE)

    # ── 구독 ────────────────────────────────────────────────────────────────

    @classmethod
    def subscribe(
        cls,
        event_type: str,
        handler: Callable[[EvalEvent], None],
    ) -> str:
        """이벤트 유형을 구독한다.

        Args:
            event_type: 구독할 이벤트 유형. ``"*"`` 이면 모든 이벤트 수신.
            handler: ``(EvalEvent) -> None`` 콜백. 예외는 버스가 포착한다.

        Returns:
            구독 취소 시 사용하는 ``sub_id`` 문자열.
        """
        sub_id = f"{event_type}:{uuid.uuid4().hex[:8]}"
        with cls._lock:
            cls._subscribers.setdefault(event_type, {})[sub_id] = handler
        logger.debug("EvalEventBus 구독: type=%r sub_id=%s", event_type, sub_id)
        return sub_id

    @classmethod
    def unsubscribe(cls, sub_id: str) -> bool:
        """구독을 해제한다.

        Args:
            sub_id: ``subscribe()`` 가 반환한 ID.

        Returns:
            실제로 제거됐으면 ``True``, 없으면 ``False``.
        """
        event_type = sub_id.split(":")[0]
        with cls._lock:
            removed = cls._subscribers.get(event_type, {}).pop(sub_id, None)
        if removed:
            logger.debug("EvalEventBus 구독 해제: sub_id=%s", sub_id)
        return removed is not None

    @classmethod
    def unsubscribe_all(cls, event_type: Optional[str] = None) -> int:
        """이벤트 유형의 모든 구독을 해제한다. ``None`` 이면 전체 해제."""
        with cls._lock:
            if event_type is None:
                count = sum(len(v) for v in cls._subscribers.values())
                cls._subscribers.clear()
            else:
                count = len(cls._subscribers.pop(event_type, {}))
        return count

    # ── 발행 ────────────────────────────────────────────────────────────────

    @classmethod
    def emit(cls, event: EvalEvent) -> None:
        """이벤트를 발행한다.

        해당 ``event_type`` 구독자와 와일드카드(``"*"``) 구독자 모두에게 전달한다.
        각 핸들러 예외는 독립적으로 포착되어 다른 핸들러에 영향을 주지 않는다.

        Args:
            event: 발행할 :class:`EvalEvent`.
        """
        with cls._lock:
            cls._history.append(event)
            handlers: List[Callable[[EvalEvent], None]] = list(
                {
                    **cls._subscribers.get(event.event_type, {}),
                    **cls._subscribers.get(_WILDCARD, {}),
                }.values()
            )

        for handler in handlers:
            try:
                handler(event)
            except Exception as exc:
                logger.debug(
                    "EvalEventBus 핸들러 예외 (무시): type=%r handler=%r exc=%s",
                    event.event_type, getattr(handler, "__name__", handler), exc,
                )

    # ── 히스토리 ─────────────────────────────────────────────────────────────

    @classmethod
    def history(cls, n: int = 50, event_type: Optional[str] = None) -> List[EvalEvent]:
        """최근 이벤트 목록을 반환한다.

        Args:
            n: 최대 반환 건수 (최신 순).
            event_type: 지정 시 해당 유형만 필터링.

        Returns:
            최신 이벤트가 뒤에 오는 리스트.
        """
        with cls._lock:
            events = list(cls._history)
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        return events[-n:]

    @classmethod
    def set_history_size(cls, size: int) -> None:
        """히스토리 최대 보관 크기를 변경한다."""
        with cls._lock:
            cls._history = collections.deque(cls._history, maxlen=size)

    # ── 관리 ─────────────────────────────────────────────────────────────────

    @classmethod
    def clear(cls) -> None:
        """모든 구독과 히스토리를 초기화한다 (테스트 / 재시작용)."""
        with cls._lock:
            cls._subscribers.clear()
            cls._history.clear()

    @classmethod
    def summary(cls) -> Dict[str, Any]:
        """버스 현황을 요약한다."""
        with cls._lock:
            return {
                "subscriptions": {k: len(v) for k, v in cls._subscribers.items()},
                "history_size": len(cls._history),
                "total_handlers": sum(len(v) for v in cls._subscribers.values()),
            }
