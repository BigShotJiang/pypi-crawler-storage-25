"""
plugin_registry.py — Phase 2: Open Plugin Extension Points
===========================================================

외부 패키지(또는 사용자 코드)가 Agent-Evaluator SDK에 새로운 **지표(Metric)**와
**프레임워크 어댑터(Framework Adapter)**를 등록할 수 있는 공개 확장 지점.

등록 방법 3가지
--------------
1. 데코레이터 (가장 간단)::

    from agent_evaluator import register_metric, register_framework_adapter

    @register_metric("bleu_score")
    def bleu(*, response: str, ground_truth: str, **_) -> dict:
        score = compute_bleu(response, ground_truth)
        return {"bleu": score}

    @register_framework_adapter("my_framework")
    class MyAdapter:
        def detect(self, response) -> bool:
            return hasattr(response, "my_framework_attr")
        def extract(self, response) -> Optional[EvalMetadata]:
            return EvalMetadata(tool_calls=response.my_framework_attr)

2. 클래스 직접 등록::

    from agent_evaluator import PluginRegistry

    class RougePlugin:
        name = "rouge"
        def compute(self, *, response, ground_truth, **_):
            return {"rouge1": rouge_1(response, ground_truth)}

    PluginRegistry.register_metric(RougePlugin())

3. 패키지 entry_points (pip install 후 자동 발견)::

    # setup.cfg / pyproject.toml
    [options.entry_points]
    agent_evaluator.plugins =
        my_plugin = my_package.plugin:MyPlugin

우선순위
--------
- 프레임워크 어댑터: 기존 `_FRAMEWORK_ADAPTERS` (built-in) > Plugin 어댑터
- 지표 플러그인: built-in 지표 이후 `extra["plugin_metrics"][plugin_name]` 에 저장
"""

from __future__ import annotations

import importlib
import inspect
import logging
import threading
from typing import Any, Callable, Dict, List, Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------

@runtime_checkable
class MetricPlugin(Protocol):
    """커스텀 지표 플러그인 프로토콜.

    ``compute()`` 가 호출될 때 ``question``, ``response``, ``ground_truth``,
    ``context``, ``task_type``, ``extra`` 키워드 인자가 전달됩니다.
    불필요한 인자는 ``**_`` 로 무시하세요.

    반환값: ``{metric_name: score_float}`` 딕셔너리.
    예외는 레지스트리가 포착하여 로그로만 출력하므로 SDK 평가는 중단되지 않습니다.

    Example::

        class RougeMetric:
            name = "rouge"

            def compute(self, *, response: str, ground_truth: str, **_) -> dict:
                from rouge_score import rouge_scorer
                scorer = rouge_scorer.RougeScorer(["rouge1"], use_stemmer=True)
                scores = scorer.score(ground_truth, response)
                return {"rouge1_f": scores["rouge1"].fmeasure}
    """

    @property
    def name(self) -> str:
        """플러그인 고유 이름 (대시보드 표시용)."""
        ...

    def compute(
        self,
        *,
        question: str = "",
        response: str = "",
        ground_truth: str = "",
        context: str = "",
        task_type: str = "qa",
        extra: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Dict[str, float]:
        """커스텀 지표를 계산합니다.

        Returns:
            ``{metric_name: score}`` 딕셔너리. 값은 ``float`` 이어야 합니다.
        """
        ...


@runtime_checkable
class FrameworkAdapterPlugin(Protocol):
    """커스텀 프레임워크 어댑터 플러그인 프로토콜.

    ``detect()`` 가 ``True`` 를 반환하면 ``extract()`` 가 호출됩니다.
    기존 ``_FRAMEWORK_ADAPTERS`` 에 없는 프레임워크 응답 형식을 지원할 때 사용합니다.

    Example::

        class HaystackV2Adapter:
            framework_name = "haystack_v2"

            def detect(self, response) -> bool:
                return type(response).__name__ == "GeneratorOutput"

            def extract(self, response) -> Optional[EvalMetadata]:
                from agent_evaluator.decorators import EvalMetadata
                return EvalMetadata(
                    tool_calls=[{"name": c.query, "args": {}} for c in response.documents]
                )
    """

    @property
    def framework_name(self) -> str:
        """프레임워크 이름 (e.g. ``"haystack_v2"``)."""
        ...

    def detect(self, response: Any) -> bool:
        """응답 객체가 이 어댑터로 처리 가능한지 판별합니다."""
        ...

    def extract(self, response: Any) -> Optional[Any]:
        """응답 객체에서 EvalMetadata를 추출합니다. 불가능하면 ``None`` 반환."""
        ...


# ---------------------------------------------------------------------------
# _FunctionMetricPlugin — callable을 MetricPlugin으로 래핑
# ---------------------------------------------------------------------------

class _NameOverriddenPlugin:
    """Wraps a MetricPlugin with an explicit name (used when @register_metric('name') overrides class.name)."""

    def __init__(self, inner: Any, name: str):
        self._inner = inner
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    def compute(self, **kwargs: Any) -> Dict[str, float]:
        return self._inner.compute(**kwargs)


class _FunctionMetricPlugin:
    """함수(callable)를 MetricPlugin으로 래핑하는 내부 클래스."""

    def __init__(self, fn: Callable, name: str):
        self._fn = fn
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    def compute(self, **kwargs: Any) -> Dict[str, float]:
        # 함수 시그니처에서 지원하는 파라미터만 전달
        sig = inspect.signature(self._fn)
        params = sig.parameters
        has_var_keyword = any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()
        )
        if has_var_keyword:
            return self._fn(**kwargs)
        filtered = {k: v for k, v in kwargs.items() if k in params}
        return self._fn(**filtered)


class _FunctionFrameworkPlugin:
    """함수 쌍(detect_fn, extract_fn)을 FrameworkAdapterPlugin으로 래핑하는 내부 클래스."""

    def __init__(self, framework_name: str, detect_fn: Optional[Callable], extract_fn: Callable):
        self._framework_name = framework_name
        self._detect_fn = detect_fn
        self._extract_fn = extract_fn

    @property
    def framework_name(self) -> str:
        return self._framework_name

    def detect(self, response: Any) -> bool:
        if self._detect_fn is None:
            return False
        try:
            return bool(self._detect_fn(response))
        except Exception:
            return False

    def extract(self, response: Any) -> Optional[Any]:
        try:
            return self._extract_fn(response)
        except Exception:
            return None


# ---------------------------------------------------------------------------
# PluginRegistry
# ---------------------------------------------------------------------------

class PluginRegistry:
    """Agent-Evaluator SDK 플러그인 중앙 레지스트리.

    Thread-safe singleton. 모든 메서드는 클래스메서드입니다.

    Metric 플러그인은 ``extra["plugin_metrics"][plugin_name]`` 에 결과를 저장합니다.
    Framework 어댑터 플러그인은 기존 built-in 어댑터가 실패한 경우에만 실행됩니다.
    """

    _metric_plugins: Dict[str, MetricPlugin] = {}
    _framework_plugins: Dict[str, FrameworkAdapterPlugin] = {}
    _lock = threading.Lock()
    _entry_points_loaded = False

    # ── Metric 플러그인 ────────────────────────────────────────────────────

    @classmethod
    def register_metric(cls, plugin: "MetricPlugin") -> None:
        """MetricPlugin 인스턴스를 등록합니다.

        Args:
            plugin: ``MetricPlugin`` 프로토콜을 구현한 객체.

        Raises:
            TypeError: ``name`` 속성 또는 ``compute()`` 메서드가 없는 경우.
        """
        if not hasattr(plugin, "name") or not callable(getattr(plugin, "compute", None)):
            raise TypeError(
                f"MetricPlugin은 'name' 속성과 'compute()' 메서드가 필요합니다: {type(plugin)}"
            )
        with cls._lock:
            cls._metric_plugins[plugin.name] = plugin
        logger.debug("MetricPlugin 등록: '%s'", plugin.name)

    @classmethod
    def unregister_metric(cls, name: str) -> bool:
        """이름으로 MetricPlugin을 제거합니다. 반환값: 제거 성공 여부."""
        with cls._lock:
            removed = cls._metric_plugins.pop(name, None)
        if removed:
            logger.debug("MetricPlugin 제거: '%s'", name)
        return removed is not None

    @classmethod
    def list_metric_plugins(cls) -> List[str]:
        """등록된 MetricPlugin 이름 목록을 반환합니다."""
        cls._ensure_entry_points()
        with cls._lock:
            return list(cls._metric_plugins.keys())

    @classmethod
    def compute_all(
        cls,
        *,
        question: str = "",
        response: str = "",
        ground_truth: str = "",
        context: str = "",
        task_type: str = "qa",
        extra: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Dict[str, float]]:
        """등록된 모든 MetricPlugin을 실행하고 결과를 반환합니다.

        Args:
            question: 평가 질문.
            response: 에이전트 응답.
            ground_truth: 정답 (없으면 빈 문자열).
            context: RAG 컨텍스트 (없으면 빈 문자열).
            task_type: 태스크 유형.
            extra: 기존 extra 딕셔너리 (참조용).

        Returns:
            ``{plugin_name: {metric_name: score}}`` 딕셔너리.
            각 플러그인 예외는 포착되어 로그로만 출력됩니다.
        """
        cls._ensure_entry_points()
        with cls._lock:
            plugins = list(cls._metric_plugins.values())

        results: Dict[str, Dict[str, float]] = {}
        kwargs = dict(
            question=question,
            response=response,
            ground_truth=ground_truth,
            context=context,
            task_type=task_type,
            extra=extra or {},
        )
        for plugin in plugins:
            try:
                scores = plugin.compute(**kwargs)
                if isinstance(scores, dict):
                    results[plugin.name] = {k: float(v) for k, v in scores.items()}
            except Exception as exc:
                logger.debug("MetricPlugin '%s' 실행 실패 (무시): %s", plugin.name, exc)
        return results

    # ── Framework 어댑터 플러그인 ──────────────────────────────────────────

    @classmethod
    def register_framework_adapter(cls, plugin: "FrameworkAdapterPlugin") -> None:
        """FrameworkAdapterPlugin 인스턴스를 등록합니다.

        Args:
            plugin: ``FrameworkAdapterPlugin`` 프로토콜을 구현한 객체.

        Raises:
            TypeError: ``framework_name``, ``detect()``, ``extract()`` 가 없는 경우.
        """
        if (
            not hasattr(plugin, "framework_name")
            or not callable(getattr(plugin, "detect", None))
            or not callable(getattr(plugin, "extract", None))
        ):
            raise TypeError(
                "FrameworkAdapterPlugin은 'framework_name' 속성과 "
                f"'detect()', 'extract()' 메서드가 필요합니다: {type(plugin)}"
            )
        with cls._lock:
            cls._framework_plugins[plugin.framework_name] = plugin
        logger.debug("FrameworkAdapterPlugin 등록: '%s'", plugin.framework_name)

    @classmethod
    def unregister_framework_adapter(cls, framework_name: str) -> bool:
        """이름으로 FrameworkAdapterPlugin을 제거합니다."""
        with cls._lock:
            removed = cls._framework_plugins.pop(framework_name, None)
        return removed is not None

    @classmethod
    def list_framework_plugins(cls) -> List[str]:
        """등록된 FrameworkAdapterPlugin 이름 목록을 반환합니다."""
        cls._ensure_entry_points()
        with cls._lock:
            return list(cls._framework_plugins.keys())

    @classmethod
    def auto_detect_framework(cls, response: Any) -> Optional[str]:
        """모든 registered FrameworkAdapterPlugin의 detect()를 순서대로 호출합니다.

        첫 번째로 ``True`` 를 반환한 플러그인의 ``framework_name`` 을 반환합니다.
        매칭 플러그인이 없으면 ``None`` 을 반환합니다.
        """
        cls._ensure_entry_points()
        with cls._lock:
            plugins = list(cls._framework_plugins.values())
        for plugin in plugins:
            try:
                if plugin.detect(response):
                    return plugin.framework_name
            except Exception as exc:
                logger.debug("FrameworkAdapterPlugin detect 실패 '%s': %s", plugin.framework_name, exc)
        return None

    @classmethod
    def extract_metadata(cls, framework_name: str, response: Any) -> Optional[Any]:
        """지정된 프레임워크 이름의 FrameworkAdapterPlugin으로 메타데이터를 추출합니다.

        Args:
            framework_name: 등록된 어댑터 이름.
            response: 에이전트 응답 객체.

        Returns:
            ``EvalMetadata`` 또는 ``None``.
        """
        cls._ensure_entry_points()
        with cls._lock:
            plugin = cls._framework_plugins.get(framework_name)
        if plugin is None:
            return None
        try:
            return plugin.extract(response)
        except Exception as exc:
            logger.debug("FrameworkAdapterPlugin extract 실패 '%s': %s", framework_name, exc)
            return None

    @classmethod
    def detect_and_extract(cls, response: Any) -> tuple:
        """auto_detect_framework + extract_metadata를 한 번에 실행합니다.

        Returns:
            ``(framework_name, EvalMetadata | None)`` 튜플.
            감지 실패 시 ``(None, None)``.
        """
        name = cls.auto_detect_framework(response)
        if name is None:
            return (None, None)
        meta = cls.extract_metadata(name, response)
        return (name, meta)

    # ── 레지스트리 초기화 ──────────────────────────────────────────────────

    @classmethod
    def clear(cls) -> None:
        """모든 등록 항목을 제거합니다 (테스트 / 재시작용)."""
        with cls._lock:
            cls._metric_plugins.clear()
            cls._framework_plugins.clear()
            cls._entry_points_loaded = False

    @classmethod
    def _ensure_entry_points(cls) -> None:
        """importlib.metadata entry_points를 한 번만 스캔합니다."""
        with cls._lock:
            if cls._entry_points_loaded:
                return
            cls._entry_points_loaded = True

        cls._load_entry_points()

    @classmethod
    def _load_entry_points(cls) -> None:
        """``agent_evaluator.plugins`` 그룹의 entry_points를 자동 로드합니다.

        패키지의 pyproject.toml / setup.cfg에 아래처럼 선언하세요::

            [options.entry_points]
            agent_evaluator.plugins =
                my_metric = my_package.plugins:MyMetricPlugin
                my_adapter = my_package.plugins:MyAdapterPlugin

        또는 pyproject.toml (flit/hatch)::

            [project.entry-points."agent_evaluator.plugins"]
            my_metric = "my_package.plugins:MyMetricPlugin"
        """
        try:
            from importlib.metadata import entry_points
            # Python 3.9+ accepts group= kwarg; earlier versions need the dict approach
            try:
                eps = entry_points(group="agent_evaluator.plugins")
            except TypeError:
                eps = entry_points().get("agent_evaluator.plugins", [])  # type: ignore[call-arg]

            for ep in eps:
                try:
                    obj = ep.load()
                    # If it's a class, instantiate it
                    if inspect.isclass(obj):
                        obj = obj()
                    # Determine if it's a MetricPlugin or FrameworkAdapterPlugin
                    if hasattr(obj, "compute") and hasattr(obj, "name"):
                        cls.register_metric(obj)
                        logger.info("Entry point MetricPlugin 로드: '%s' (%s)", obj.name, ep.name)
                    elif hasattr(obj, "detect") and hasattr(obj, "extract") and hasattr(obj, "framework_name"):
                        cls.register_framework_adapter(obj)
                        logger.info(
                            "Entry point FrameworkAdapterPlugin 로드: '%s' (%s)",
                            obj.framework_name, ep.name,
                        )
                    else:
                        logger.warning(
                            "Entry point '%s'은 MetricPlugin 또는 FrameworkAdapterPlugin이 "
                            "아닙니다 (건너뜀): %s", ep.name, type(obj)
                        )
                except Exception as exc:
                    logger.warning("Entry point '%s' 로드 실패 (건너뜀): %s", ep.name, exc)
        except Exception as exc:
            logger.debug("entry_points 스캔 실패 (무시): %s", exc)

    @classmethod
    def summary(cls) -> Dict[str, Any]:
        """등록된 플러그인 현황을 요약합니다."""
        cls._ensure_entry_points()
        with cls._lock:
            return {
                "metric_plugins": list(cls._metric_plugins.keys()),
                "framework_adapter_plugins": list(cls._framework_plugins.keys()),
                "total": len(cls._metric_plugins) + len(cls._framework_plugins),
            }


# ---------------------------------------------------------------------------
# Decorator API — @register_metric / @register_framework_adapter
# ---------------------------------------------------------------------------

def register_metric(
    name_or_cls: "Any" = None,
    *,
    name: Optional[str] = None,
    priority: int = 0,  # reserved for future ordering support
) -> "Any":
    """MetricPlugin 등록 데코레이터 / 함수.

    함수 또는 클래스를 MetricPlugin으로 등록합니다.

    사용법::

        # 1. 함수에 이름 명시
        @register_metric("bleu")
        def bleu_score(*, response, ground_truth, **_):
            return {"bleu": compute_bleu(response, ground_truth)}

        # 2. 함수에 파라미터 없이 (함수명 사용)
        @register_metric
        def my_metric(*, response, **_):
            return {"length": len(response)}

        # 3. 클래스 등록
        @register_metric
        class RougePlugin:
            name = "rouge"
            def compute(self, *, response, ground_truth, **_):
                return {"rouge1": ...}

        # 4. 런타임 등록 (데코레이터 없이)
        register_metric("bleu")(my_fn)

    Args:
        name_or_cls: 플러그인 이름 문자열, 또는 bare decorator로 사용 시 클래스/함수.
        name: 이름을 키워드로 지정 (name_or_cls와 동시 사용 불가).

    Returns:
        데코레이터 함수 또는 등록된 원본 객체.
    """
    def _do_register(fn_or_cls: Any, plugin_name: str) -> Any:
        if inspect.isclass(fn_or_cls):
            # Class: instantiate and register
            instance = fn_or_cls()
            # If the explicit name differs from the class's own name, wrap it
            if getattr(instance, "name", None) != plugin_name:
                instance = _NameOverriddenPlugin(instance, plugin_name)
            PluginRegistry.register_metric(instance)
            return fn_or_cls
        elif callable(fn_or_cls):
            # Callable: wrap as _FunctionMetricPlugin
            plugin = _FunctionMetricPlugin(fn_or_cls, plugin_name)
            PluginRegistry.register_metric(plugin)
            return fn_or_cls
        else:
            raise TypeError(f"register_metric: 함수 또는 클래스가 필요합니다: {type(fn_or_cls)}")

    # Bare @register_metric (no parens, no name)
    if callable(name_or_cls) and name is None:
        _plugin_name = getattr(name_or_cls, "name", None) or getattr(name_or_cls, "__name__", "unnamed")
        return _do_register(name_or_cls, _plugin_name)

    # @register_metric("name") — name_or_cls is the string name
    if isinstance(name_or_cls, str):
        _resolved_name = name_or_cls
    elif name is not None:
        _resolved_name = name
    else:
        _resolved_name = "unnamed"

    def decorator(fn_or_cls: Any) -> Any:
        _plugin_name = _resolved_name or getattr(fn_or_cls, "__name__", "unnamed")
        return _do_register(fn_or_cls, _plugin_name)

    return decorator


def register_framework_adapter(
    framework_name_or_cls: "Any" = None,
    *,
    framework_name: Optional[str] = None,
    detect: Optional[Callable] = None,
    priority: int = 0,  # reserved
) -> "Any":
    """FrameworkAdapterPlugin 등록 데코레이터 / 함수.

    클래스 또는 ``extract`` 함수를 FrameworkAdapterPlugin으로 등록합니다.

    사용법::

        # 1. 클래스 등록 (권장 — detect + extract 둘 다 정의)
        @register_framework_adapter("my_framework")
        class MyAdapter:
            def detect(self, response) -> bool:
                return hasattr(response, "my_attr")
            def extract(self, response):
                from agent_evaluator.decorators import EvalMetadata
                return EvalMetadata(tool_calls=response.my_attr)

        # 2. 함수 등록 (detect는 별도 함수 또는 None)
        @register_framework_adapter("my_framework", detect=lambda r: hasattr(r, "my_attr"))
        def extract_my(response):
            from agent_evaluator.decorators import EvalMetadata
            return EvalMetadata(tool_calls=response.my_attr)

        # 3. Bare decorator (클래스의 framework_name 속성 사용)
        @register_framework_adapter
        class MyAdapter:
            framework_name = "my_framework"
            def detect(self, response): ...
            def extract(self, response): ...

    Args:
        framework_name_or_cls: 프레임워크 이름 문자열, 또는 bare decorator로 사용 시 클래스.
        framework_name: 이름을 키워드로 지정.
        detect: extract 함수와 함께 사용할 detect 콜백 (클래스 방식에서는 불필요).

    Returns:
        데코레이터 함수 또는 등록된 원본 객체.
    """
    def _do_register_class(cls: Any, fw_name: str) -> Any:
        instance = cls()
        if not hasattr(instance, "framework_name"):
            instance._framework_name = fw_name
            type(instance).framework_name = property(lambda self: self._framework_name)  # type: ignore[attr-defined]
        PluginRegistry.register_framework_adapter(instance)
        return cls

    def _do_register_fn(fn: Callable, fw_name: str, detect_fn: Optional[Callable]) -> Callable:
        plugin = _FunctionFrameworkPlugin(fw_name, detect_fn, fn)
        PluginRegistry.register_framework_adapter(plugin)
        return fn

    # Bare @register_framework_adapter (no parens)
    if callable(framework_name_or_cls) and framework_name is None and detect is None:
        cls = framework_name_or_cls
        fw_name = getattr(cls, "framework_name", None) or getattr(cls, "__name__", "unknown")
        if isinstance(fw_name, str):
            return _do_register_class(cls, fw_name) if inspect.isclass(cls) else cls
        return cls

    # @register_framework_adapter("name") or @register_framework_adapter(framework_name="name")
    _resolved_name = (
        framework_name_or_cls if isinstance(framework_name_or_cls, str)
        else framework_name or "unknown"
    )

    def decorator(fn_or_cls: Any) -> Any:
        if inspect.isclass(fn_or_cls):
            return _do_register_class(fn_or_cls, _resolved_name)
        elif callable(fn_or_cls):
            return _do_register_fn(fn_or_cls, _resolved_name, detect)
        raise TypeError(f"register_framework_adapter: 함수 또는 클래스가 필요합니다: {type(fn_or_cls)}")

    return decorator
