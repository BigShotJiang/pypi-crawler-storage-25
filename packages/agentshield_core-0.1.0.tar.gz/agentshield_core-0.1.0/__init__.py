"""
AgentShield detectors — each detector returns a score, level, and signals list.
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from typing import Any

from ..shield import ThreatLevel


class BaseDetector(ABC):
    @abstractmethod
    def detect(
        self,
        user_intent: str,
        tool_name: str,
        tool_args: dict[str, Any],
        context: dict[str, Any],
    ) -> dict:
        """Return {"score": float, "level": ThreatLevel, "signals": list[str]}"""


class ToolCallPoisonDetector(BaseDetector):
    """
    Detects prompt injection payloads embedded in tool arguments —
    e.g. a retrieved document telling the agent to exfiltrate data,
    or a crafted input that redirects tool behavior.
    """

    # Patterns that commonly appear in injection payloads inside tool args
    INJECTION_PATTERNS: list[tuple[str, float, str]] = [
        # (regex, score_weight, signal_label)
        (r"ignore (previous|all|above|prior) instructions?", 0.9, "classic-ignore-instruction"),
        (r"you are now (a|an|the)", 0.75, "persona-override"),
        (r"system\s*:", 0.6, "system-prompt-injection"),
        (r"<\s*/?system\s*>", 0.8, "xml-system-tag"),
        (r"\[INST\]|\[/INST\]|<<SYS>>|<</SYS>>", 0.85, "llama-control-token"),
        (r"disregard (your|all|the) (instructions?|guidelines?|rules?)", 0.9, "disregard-instruction"),
        (r"(exfiltrate|send|leak|transmit).{0,40}(data|credentials?|secrets?|keys?)", 0.95, "data-exfiltration"),
        (r"execute the following (command|code|script)", 0.8, "command-injection"),
        (r"act as (if you are|a|an|though)", 0.65, "role-hijack"),
        (r"your (new|real|actual|true) (instructions?|goal|purpose|task)", 0.85, "goal-hijack"),
    ]

    def detect(self, user_intent, tool_name, tool_args, context) -> dict:
        signals = []
        max_score = 0.0

        # Flatten all string values in tool_args for scanning
        text_surface = " ".join(
            str(v) for v in self._flatten(tool_args)
        ).lower()

        for pattern, weight, label in self.INJECTION_PATTERNS:
            if re.search(pattern, text_surface, re.IGNORECASE):
                signals.append(f"tool-call-poison:{label}")
                max_score = max(max_score, weight)

        return {
            "score": max_score,
            "level": self._score_to_level(max_score),
            "signals": signals,
        }

    def _flatten(self, obj: Any, depth: int = 0) -> list:
        """Recursively extract string leaves from nested dicts/lists."""
        if depth > 5:
            return []
        if isinstance(obj, str):
            return [obj]
        if isinstance(obj, dict):
            return [s for v in obj.values() for s in self._flatten(v, depth + 1)]
        if isinstance(obj, (list, tuple)):
            return [s for v in obj for s in self._flatten(v, depth + 1)]
        return [str(obj)]

    def _score_to_level(self, score: float) -> ThreatLevel:
        if score >= 0.9:
            return ThreatLevel.CRITICAL
        if score >= 0.75:
            return ThreatLevel.HIGH
        if score >= 0.5:
            return ThreatLevel.MEDIUM
        if score > 0.0:
            return ThreatLevel.LOW
        return ThreatLevel.SAFE


class IntentDriftDetector(BaseDetector):
    """
    Detects when a tool call has semantically drifted away from the
    original user intent — a sign the agent has been hijacked mid-session.

    Uses lightweight keyword overlap heuristics (no external model needed).
    For production, swap in an embedding similarity check.
    """

    # High-risk tool names that should RARELY appear unless user explicitly asked
    HIGH_RISK_TOOLS = {
        "execute_code", "run_shell", "bash", "eval", "exec",
        "send_email", "send_message", "post_webhook",
        "delete_file", "drop_table", "write_file",
        "create_user", "modify_permissions", "update_config",
    }

    # Intent keywords that justify high-risk tool calls
    INTENT_WHITELIST_KEYWORDS = {
        "execute_code": ["code", "run", "script", "python", "compute", "calculate"],
        "send_email": ["email", "send", "message", "notify", "contact"],
        "write_file": ["save", "write", "create file", "store", "export"],
        "delete_file": ["delete", "remove", "clean up", "trash"],
    }

    def detect(self, user_intent, tool_name, tool_args, context) -> dict:
        signals = []
        score = 0.0
        intent_lower = user_intent.lower()
        tool_lower = tool_name.lower()

        # Flag high-risk tools not justified by intent
        if tool_lower in self.HIGH_RISK_TOOLS:
            allowed_keywords = self.INTENT_WHITELIST_KEYWORDS.get(tool_lower, [])
            if not any(kw in intent_lower for kw in allowed_keywords):
                signals.append(f"intent-drift:high-risk-tool-not-in-intent({tool_name})")
                score = max(score, 0.7)

        # Flag completely unrelated tool categories
        intent_words = set(re.findall(r"\w+", intent_lower))
        tool_words = set(re.findall(r"\w+", tool_lower))
        if intent_words and not intent_words.intersection(tool_words):
            # No word overlap at all is a weak signal on its own
            score = max(score, 0.1)

        return {
            "score": score,
            "level": self._score_to_level(score),
            "signals": signals,
        }

    def _score_to_level(self, score: float) -> ThreatLevel:
        if score >= 0.9:
            return ThreatLevel.CRITICAL
        if score >= 0.7:
            return ThreatLevel.HIGH
        if score >= 0.4:
            return ThreatLevel.MEDIUM
        if score > 0.0:
            return ThreatLevel.LOW
        return ThreatLevel.SAFE


class PrivilegeEscalationDetector(BaseDetector):
    """
    Detects tool calls that attempt to gain elevated permissions,
    access sensitive system resources, or modify security boundaries —
    actions that should never originate from LLM-generated tool calls.
    """

    ESCALATION_PATTERNS: list[tuple[str, float, str]] = [
        (r"(sudo|su\s+-|chmod\s+777|chown\s+root)", 0.95, "unix-privilege-escalation"),
        (r"(net\s+user|runas|psexec)", 0.95, "windows-privilege-escalation"),
        (r"(aws iam|gcloud iam|az role).*(create|attach|add|grant)", 0.9, "cloud-iam-escalation"),
        (r"(set|export)\s+(AWS_SECRET|OPENAI_API_KEY|DATABASE_URL|SECRET_KEY)", 0.95, "env-secret-overwrite"),
        (r"/etc/(passwd|shadow|sudoers)", 0.99, "sensitive-file-access"),
        (r"(drop\s+table|truncate\s+table|delete\s+from).{0,20}(users?|accounts?|admins?)", 0.9, "destructive-db-query"),
        (r"(disable|bypass|turn off).{0,20}(auth|authentication|firewall|mfa|2fa)", 0.95, "auth-bypass"),
    ]

    def detect(self, user_intent, tool_name, tool_args, context) -> dict:
        signals = []
        max_score = 0.0

        all_text = " ".join([
            str(v) for v in self._all_values(tool_args)
        ] + [tool_name])

        for pattern, weight, label in self.ESCALATION_PATTERNS:
            if re.search(pattern, all_text, re.IGNORECASE):
                signals.append(f"privilege-escalation:{label}")
                max_score = max(max_score, weight)

        return {
            "score": max_score,
            "level": self._score_to_level(max_score),
            "signals": signals,
        }

    def _all_values(self, obj: Any, depth: int = 0) -> list:
        if depth > 5:
            return []
        if isinstance(obj, str):
            return [obj]
        if isinstance(obj, dict):
            return [s for v in obj.values() for s in self._all_values(v, depth + 1)]
        if isinstance(obj, (list, tuple)):
            return [s for v in obj for s in self._all_values(v, depth + 1)]
        return [str(obj)]

    def _score_to_level(self, score: float) -> ThreatLevel:
        if score >= 0.9:
            return ThreatLevel.CRITICAL
        if score >= 0.75:
            return ThreatLevel.HIGH
        if score >= 0.5:
            return ThreatLevel.MEDIUM
        if score > 0.0:
            return ThreatLevel.LOW
        return ThreatLevel.SAFE
