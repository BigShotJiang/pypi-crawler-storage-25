"""Phase 5.3 Stage 1: validate the E8PagedKVCache layout.

The cache class lives in ``glq_vllm/e8_paged_cache.py`` and is the
Python prototype for the CUDA work in Stage 3. These tests pin the
correctness contract that the CUDA kernels will have to honour:

* Bit-exact equivalence with ``E8KVQuantizer.quantize`` /
  ``E8KVQuantizer.dequantize`` end-to-end.
* Storage budget per (token, head) matches the bpw recipe.
* Non-contiguous slot scattering (writes interleaved across blocks) is
  preserved by the gather path.
"""
from __future__ import annotations

import pytest
import torch

from glq.codebook_relaxed import E8RelaxedCodebook
from glq.kv_e8 import E8KVQuantizer
from glq_vllm.e8_paged_cache import (
    E8PagedKVCache,
    _BPW_RECIPE,
    gather_kv,
    gather_kv_to_paged_fp16,
    remap_block_table,
    write_kv,
)


@pytest.fixture(scope="module")
def relaxed():
    return E8RelaxedCodebook(device="cpu", verbose=False)


def _build_quantizer(cb, bpw: int):
    n_p, n_s = _BPW_RECIPE[bpw]
    small = cb.make_small() if n_s > 0 else None
    return E8KVQuantizer(cb, n_stages=n_p,
                        secondary_codebook=small, secondary_stages=n_s)


def _random_kv(seed: int, num_tokens: int, num_kv_heads: int, head_size: int,
               dtype=torch.float16):
    g = torch.Generator().manual_seed(seed)
    key = torch.randn(num_tokens, num_kv_heads, head_size,
                      generator=g, dtype=torch.float32).to(dtype)
    value = torch.randn(num_tokens, num_kv_heads, head_size,
                        generator=g, dtype=torch.float32).to(dtype)
    return key, value


@pytest.mark.parametrize("bpw", [2, 3, 4, 5, 6, 7])
def test_roundtrip_matches_quantizer(relaxed, bpw):
    """Storing K/V via the paged cache and gathering them back must
    reproduce ``quantizer.dequantize(quantizer.quantize(x))`` *exactly*
    — same math, just routed through the new storage layout."""
    block_size = 16
    num_kv_heads = 2
    head_size = 128
    num_blocks = 8

    cache = E8PagedKVCache.alloc(
        num_blocks=num_blocks, block_size=block_size,
        num_kv_heads=num_kv_heads, head_size=head_size, bpw=bpw,
        device="cpu", dtype=torch.float16)
    quant = _build_quantizer(relaxed, bpw)

    n_tokens = 40
    key, value = _random_kv(seed=bpw, num_tokens=n_tokens,
                            num_kv_heads=num_kv_heads, head_size=head_size)
    # Pack tokens into slots 0..39 (spans 3 blocks contiguously).
    slot_mapping = torch.arange(n_tokens, dtype=torch.long)
    write_kv(quant, key, value, cache, slot_mapping)
    k_out, v_out = gather_kv(quant, cache, slot_mapping)

    # Reference: straight quantize -> dequantize, no cache.
    k_ref = quant.dequantize(quant.quantize(key))
    v_ref = quant.dequantize(quant.quantize(value))

    assert torch.equal(k_out, k_ref), \
        f"K mismatch at bpw={bpw}: max delta={(k_out-k_ref).abs().max().item()}"
    assert torch.equal(v_out, v_ref), \
        f"V mismatch at bpw={bpw}: max delta={(v_out-v_ref).abs().max().item()}"


def test_non_contiguous_slot_scatter(relaxed):
    """Tokens written into scattered slots must come back individually
    correct — the cache must not assume a contiguous slot_mapping."""
    block_size = 16
    num_kv_heads = 2
    head_size = 64
    num_blocks = 4
    bpw = 3

    cache = E8PagedKVCache.alloc(
        num_blocks=num_blocks, block_size=block_size,
        num_kv_heads=num_kv_heads, head_size=head_size, bpw=bpw, device="cpu")
    quant = _build_quantizer(relaxed, bpw)

    n_tokens = 12
    key, value = _random_kv(seed=42, num_tokens=n_tokens,
                            num_kv_heads=num_kv_heads, head_size=head_size)
    # Interleave: pick slots that span multiple blocks in non-monotonic order.
    g = torch.Generator().manual_seed(0)
    slot_mapping = torch.randperm(
        num_blocks * block_size, generator=g)[:n_tokens].long()

    write_kv(quant, key, value, cache, slot_mapping)
    k_out, v_out = gather_kv(quant, cache, slot_mapping)
    k_ref = quant.dequantize(quant.quantize(key))
    v_ref = quant.dequantize(quant.quantize(value))
    assert torch.equal(k_out, k_ref)
    assert torch.equal(v_out, v_ref)


@pytest.mark.parametrize("bpw,expected_bytes_per_tok_per_head", [
    # head_size=128 → n_groups=16. Costs per group:
    #   idx1/idx2/idx3 = 2 bytes (int16);
    #   idx_s1 = 1 byte (uint8);
    #   scale  = 2 bytes (fp16).
    # Per (token, head) we store n_groups entries of each component.
    (2, (2 + 2) * 16),            # idx1 + scale         = 64 B
    (3, (2 + 1 + 2) * 16),        # idx1 + idx_s1 + scale = 80 B
    (4, (2 + 2 + 2) * 16),        # idx1 + idx2 + scale   = 96 B
    (5, (2 + 2 + 1 + 2) * 16),    # idx1 + idx2 + idx_s1 + scale = 112 B
    (6, (2 + 2 + 2 + 2) * 16),    # idx1 + idx2 + idx3 + scale   = 128 B
    (7, (2 + 2 + 2 + 1 + 2) * 16),# + idx_s1                      = 144 B
])
def test_bytes_per_token_per_head_matches_recipe(bpw,
                                                  expected_bytes_per_tok_per_head):
    """Storage cost per (token, head) must equal the theoretical sum of
    the recipe's components. Catches layout drift before kernel work."""
    cache = E8PagedKVCache.alloc(
        num_blocks=2, block_size=16, num_kv_heads=2, head_size=128,
        bpw=bpw, device="cpu", dtype=torch.float16)
    assert cache.bytes_per_token_per_head() == expected_bytes_per_tok_per_head


def test_total_bytes_strictly_smaller_than_fp16():
    """Allocated buffer must be smaller than the fp16 baseline at every
    bpw rung — otherwise the whole exercise is for nothing."""
    num_blocks, block_size, num_kv_heads, head_size = 16, 16, 4, 128
    fp16_total = (num_blocks * block_size * num_kv_heads * head_size
                  * 2          # bytes per fp16 element
                  * 2)         # K and V
    for bpw in sorted(_BPW_RECIPE):
        cache = E8PagedKVCache.alloc(
            num_blocks=num_blocks, block_size=block_size,
            num_kv_heads=num_kv_heads, head_size=head_size, bpw=bpw,
            device="cpu", dtype=torch.float16)
        ratio = cache.bytes_total() / fp16_total
        expected = {2: 0.25, 3: 0.3125, 4: 0.375,
                    5: 0.4375, 6: 0.5, 7: 0.5625}[bpw]
        assert abs(ratio - expected) < 1e-6, \
            f"bpw={bpw}: ratio {ratio:.4f} != expected {expected}"
        assert ratio < 1.0, f"bpw={bpw} not smaller than fp16"


@pytest.mark.parametrize("bpw", [2, 3, 4, 5, 6, 7])
def test_from_paged_storage_bit_exact_with_alloc(relaxed, bpw):
    """A cache built via from_paged_storage (views into a shared buffer)
    must roundtrip identically to one built via alloc (its own tensors).
    Locks the layout contract Stage 2c-2c relies on."""
    from glq_vllm.e8_paged_cache import (
        gather_kv_to_paged_fp16,
        write_kv,
    )
    from glq_vllm.e8_kv_spec import (
        E8_BYTES_PER_GROUP,
        compressed_kv_cache_shape,
    )

    quant = _build_quantizer(relaxed, bpw)
    num_blocks, block_size, num_kv_heads, head_size = 4, 16, 2, 128
    dtype = torch.bfloat16
    # vLLM's allocated buffer for one layer is [num_blocks, 2, block_size,
    # num_kv_heads, compressed_elems_per_tok_per_head].
    shape = compressed_kv_cache_shape(
        num_blocks, block_size, num_kv_heads, head_size,
        bpw=bpw, dtype_size=2)
    raw = torch.zeros(shape, dtype=dtype, device="cpu")
    k_buf = raw[:, 0]
    v_buf = raw[:, 1]
    # Built directly on the vLLM-style buffer (views into raw).
    shared = E8PagedKVCache.from_paged_storage(
        k_buf, v_buf, head_size=head_size, bpw=bpw, dtype=dtype)
    assert shared.shares_vllm_storage is True
    # Built independently for reference comparison.
    owned = E8PagedKVCache.alloc(
        num_blocks=num_blocks, block_size=block_size,
        num_kv_heads=num_kv_heads, head_size=head_size, bpw=bpw,
        device="cpu", dtype=dtype)

    # Random K, V to write into both caches; gather back via the same
    # quantizer and assert bit equality.
    n_tokens = num_blocks * block_size
    key, value = _random_kv(seed=bpw + 100, num_tokens=n_tokens,
                            num_kv_heads=num_kv_heads, head_size=head_size,
                            dtype=dtype)
    slot_mapping = torch.arange(n_tokens, dtype=torch.long)
    write_kv(quant, key, value, owned, slot_mapping)
    write_kv(quant, key, value, shared, slot_mapping)

    k_owned, v_owned = gather_kv_to_paged_fp16(quant, owned)
    k_shared, v_shared = gather_kv_to_paged_fp16(quant, shared)
    assert torch.equal(k_owned, k_shared), (
        f"K mismatch at bpw={bpw}: "
        f"max delta={(k_owned-k_shared).abs().max().item():.2e}")
    assert torch.equal(v_owned, v_shared), (
        f"V mismatch at bpw={bpw}: "
        f"max delta={(v_owned-v_shared).abs().max().item():.2e}")


def test_remap_block_table_roundtrip():
    """``remap_block_table`` must rewrite block_table entries so that
    indexing into ``unique_blocks`` reproduces the original block ids.
    Catches off-by-one or scatter errors in the remap helper."""
    num_blocks = 100
    # Two sequences referencing scattered blocks.
    block_table = torch.tensor([
        [5, 17, 42, 7],   # seq 0
        [42, 91, 3, 17],  # seq 1 (overlaps with seq 0 on blocks 42, 17)
    ], dtype=torch.int32)
    unique = block_table.flatten().unique().long()  # [3, 5, 7, 17, 42, 91]
    new_bt = remap_block_table(block_table, unique, num_blocks)
    # For every cell, unique[new_bt[i, j]] must equal the original.
    recovered = unique[new_bt.long()]
    assert torch.equal(recovered.to(block_table.dtype), block_table)


def test_scoped_gather_matches_full_gather():
    """Decompressing only ``block_indices`` then indexing must match the
    same blocks taken out of a full decompression. This is the contract
    Stage 2c-2a relies on for correctness."""
    from glq.codebook_relaxed import E8RelaxedCodebook
    cb = E8RelaxedCodebook(device="cpu", verbose=False)
    quant = _build_quantizer(cb, bpw=3)

    cache = E8PagedKVCache.alloc(
        num_blocks=12, block_size=16, num_kv_heads=2,
        head_size=128, bpw=3, device="cpu", dtype=torch.float16)
    n_tokens = cache.num_blocks * cache.block_size
    key, value = _random_kv(seed=99, num_tokens=n_tokens,
                            num_kv_heads=2, head_size=128)
    slot_mapping = torch.arange(n_tokens, dtype=torch.long)
    write_kv(quant, key, value, cache, slot_mapping)

    # Reference: decompress everything.
    k_full, v_full = gather_kv_to_paged_fp16(quant, cache)

    # Scoped: decompress only blocks [3, 7, 9] (any subset).
    selected = torch.tensor([3, 7, 9], dtype=torch.long)
    k_compact, v_compact = gather_kv_to_paged_fp16(
        quant, cache, block_indices=selected)

    assert k_compact.shape == (3, 16, 2, 128)
    assert torch.equal(k_compact, k_full[selected])
    assert torch.equal(v_compact, v_full[selected])


def test_recipe_dtype_correctness():
    """Each per-group buffer must use the smallest sufficient dtype.
    Catches accidental int16 storage of 8-bit indices."""
    cache = E8PagedKVCache.alloc(
        num_blocks=2, block_size=16, num_kv_heads=2, head_size=128,
        bpw=3, device="cpu")
    assert cache.k_idx1.dtype == torch.int16
    assert cache.k_idx_s1.dtype == torch.uint8        # 8-bit secondary
    assert cache.k_scale.dtype == torch.float16
    assert cache.k_idx2 is None
    assert cache.k_idx3 is None
