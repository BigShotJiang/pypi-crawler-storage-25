"""
csaq/inference.py — Self-Speculative Decoding Engine

Uses the CSAQ dual-precision weight structure:
  - Draft path:  quantized low-bit weights (fast, approximate)
  - Verify path: FP16 high-salience clique weights (accurate, slower)

The key insight: Draft and Verify share the SAME model and SAME KV-cache.
We swap weight rows in-place rather than duplicating the model.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import time
from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Dict, Any


@dataclass
class SpeculativeReport:
    """Tracks real performance metrics for Self-Speculative Decoding."""
    tokens_generated: int = 0
    tokens_accepted: int = 0
    tokens_rejected: int = 0
    draft_calls: int = 0
    verify_calls: int = 0
    total_wallclock_s: float = 0.0

    @property
    def acceptance_rate(self) -> float:
        total = self.tokens_accepted + self.tokens_rejected
        return self.tokens_accepted / max(total, 1)

    @property
    def speedup_factor(self) -> float:
        """Tokens produced per forward call (draft + verify)."""
        total_calls = self.draft_calls + self.verify_calls
        return self.tokens_generated / max(total_calls, 1)

    @property
    def inter_token_latency_ms(self) -> float:
        """Average milliseconds per generated token."""
        return (self.total_wallclock_s * 1000.0) / max(self.tokens_generated, 1)

    @property
    def block_efficiency(self) -> float:
        """Average tokens accepted per verify pass."""
        return self.tokens_accepted / max(self.verify_calls, 1)

    def summary(self) -> Dict[str, Any]:
        return {
            "tokens_generated": self.tokens_generated,
            "acceptance_rate": round(self.acceptance_rate, 4),
            "speedup_factor": round(self.speedup_factor, 2),
            "inter_token_latency_ms": round(self.inter_token_latency_ms, 2),
            "block_efficiency": round(self.block_efficiency, 2),
            "draft_calls": self.draft_calls,
            "verify_calls": self.verify_calls,
            "wallclock_s": round(self.total_wallclock_s, 3),
        }


# Type alias for a single hooked-layer entry
_HookEntry = Tuple[nn.Module, torch.Tensor, torch.Tensor, torch.Tensor]


class CSAQInferenceEngine:
    """
    Self-Speculative Decoding engine for CSAQ-quantized models.

    Uses the quantized model as a fast draft speculator and swaps in FP16
    high-salience clique weights for a single-batch verification pass.

    Usage:
        model, info = quantize(model, calib_data, config=config)
        engine = CSAQInferenceEngine(model, info["causal_map"], tokenizer)
        output, report = engine.generate_speculative(input_ids, lookahead=4)
    """

    def __init__(self, model, causal_map: Dict[str, List[int]], tokenizer=None):
        self.model = model
        self.tokenizer = tokenizer
        self.device = next(model.parameters()).device

        # --- Pre-calculate hooked layers as a tight list of tuples ---
        # This avoids string-based dict lookups during the hot swap loop.
        self._hooks: List[_HookEntry] = []

        for param_name, row_indices in causal_map.items():
            module = self._resolve_module(param_name)
            if module is None:
                continue
            if not hasattr(module, "_csaq_fp16_backup"):
                continue

            self._hooks.append((
                module,                            # the nn.Linear
                module._csaq_hi_rows,              # row indices (LongTensor)
                module._csaq_fp16_backup,          # FP16 originals
                module._csaq_quant_stash,          # quantized originals
            ))

    def _resolve_module(self, param_name: str) -> Optional[nn.Module]:
        parts = param_name.split(".")
        if parts[-1] == "weight":
            parts = parts[:-1]
        mod = self.model
        for p in parts:
            if hasattr(mod, p):
                mod = getattr(mod, p)
            else:
                return None
        return mod if isinstance(mod, nn.Module) else None

    # ── Weight Swapping ───────────────────────────────────────────────────

    def _swap_to_verify(self):
        """Swap high-salience rows to FP16 for verification. Tight loop."""
        for module, rows, fp16_backup, _ in self._hooks:
            module.weight.data[rows] = fp16_backup

    def _swap_to_draft(self):
        """Restore quantized weights after verification. Tight loop."""
        for module, rows, _, quant_stash in self._hooks:
            module.weight.data[rows] = quant_stash

    # ── KV-Cache Truncation ───────────────────────────────────────────────

    @staticmethod
    def _truncate_kv_cache(past_key_values, accepted_len: int):
        """
        Truncate KV-cache to `accepted_len` positions.

        When the verifier rejects draft token at position N, tokens N+1..K
        have "poisoned" KV entries that must be removed.
        """
        if past_key_values is None:
            return None

        truncated = []
        for layer_past in past_key_values:
            # Each layer_past is a tuple of (key, value), each shape:
            # (batch, n_heads, seq_len, head_dim)
            truncated.append(
                tuple(t[:, :, :accepted_len, :] for t in layer_past)
            )
        return tuple(truncated)

    # ── Speculative Generation ────────────────────────────────────────────

    @torch.no_grad()
    def generate_speculative(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 128,
        lookahead: int = 4,
        temperature: float = 1.0,
        top_p: float = 1.0,
    ) -> Tuple[torch.Tensor, SpeculativeReport]:
        """
        Generate tokens using Self-Speculative Decoding.

        Args:
            input_ids:      (1, seq_len) prompt token IDs
            max_new_tokens: maximum tokens to generate
            lookahead:      K — number of draft tokens per speculation round
            temperature:    sampling temperature (applied identically to draft & verify)
            top_p:          nucleus sampling threshold

        Returns:
            (output_ids, SpeculativeReport)
        """
        report = SpeculativeReport()
        t0 = time.time()

        self.model.eval()
        generated = input_ids.clone().to(self.device)
        past_key_values = None
        greedy = (temperature == 0.0)

        tokens_produced = 0

        while tokens_produced < max_new_tokens:
            # ── STEP 1: DRAFT — Generate K candidate tokens ──────────────
            draft_tokens = []
            draft_logits_list = []
            draft_input = generated[:, -1:]  # last token

            for k_step in range(lookahead):
                out = self.model(
                    input_ids=draft_input,
                    past_key_values=past_key_values,
                    use_cache=True,
                )
                past_key_values = out.past_key_values
                logits = out.logits[:, -1, :]  # (1, vocab)
                report.draft_calls += 1

                # Sample from draft distribution
                token, probs = self._sample(logits, temperature, top_p, greedy)
                draft_tokens.append(token)
                draft_logits_list.append(logits)
                draft_input = token.unsqueeze(0) if token.dim() == 1 else token

            # Stack draft tokens: (1, K)
            draft_token_ids = torch.cat(draft_tokens, dim=-1)  # (1, K)

            # ── STEP 2: VERIFY — Single batched forward pass ─────────────
            self._swap_to_verify()

            # Roll back KV-cache to before draft started (K positions back)
            kv_len_before_draft = past_key_values[0][0].shape[2] - lookahead
            verify_kv = self._truncate_kv_cache(past_key_values, kv_len_before_draft)

            # Build verify input: last real token + all K draft tokens
            verify_input = torch.cat([
                generated[:, -(lookahead + 1):-lookahead],  # the token before drafting
                draft_token_ids
            ], dim=-1)  # (1, K+1)

            verify_out = self.model(
                input_ids=verify_input,
                past_key_values=verify_kv,
                use_cache=True,
            )
            verify_logits = verify_out.logits  # (1, K+1, vocab)
            report.verify_calls += 1

            self._swap_to_draft()

            # ── STEP 3: REJECTION SAMPLING ───────────────────────────────
            n_accepted = 0

            for k in range(lookahead):
                draft_logit_k = draft_logits_list[k]       # (1, vocab)
                verify_logit_k = verify_logits[:, k + 1, :]  # (1, vocab) — offset by 1

                draft_token_k = draft_token_ids[:, k]  # (1,)

                if greedy:
                    # Greedy: accept if argmax matches
                    verify_token = verify_logit_k.argmax(dim=-1)
                    if verify_token.item() == draft_token_k.item():
                        n_accepted += 1
                    else:
                        # Reject: use verifier's token instead
                        draft_token_ids[:, k] = verify_token
                        n_accepted += 1  # count the corrected token
                        break
                else:
                    # Stochastic: standard rejection sampling
                    p_draft = F.softmax(draft_logit_k / temperature, dim=-1)
                    p_verify = F.softmax(verify_logit_k / temperature, dim=-1)

                    token_idx = draft_token_k.item()
                    ratio = p_verify[0, token_idx] / p_draft[0, token_idx].clamp(min=1e-10)
                    r = torch.rand(1, device=self.device)

                    if r.item() < min(1.0, ratio.item()):
                        n_accepted += 1
                    else:
                        # Reject: resample from max(0, p_verify - p_draft), normalized
                        residual = (p_verify - p_draft).clamp(min=0.0)
                        residual_sum = residual.sum()
                        if residual_sum > 1e-8:
                            corrected = torch.multinomial(residual / residual_sum, 1)
                        else:
                            corrected = verify_logit_k.argmax(dim=-1, keepdim=True)
                        draft_token_ids[:, k] = corrected.squeeze(-1)
                        n_accepted += 1  # count the corrected token
                        break

            # ── STEP 4: Commit accepted tokens & truncate KV-cache ───────
            accepted_tokens = draft_token_ids[:, :n_accepted]
            generated = torch.cat([generated, accepted_tokens], dim=-1)
            tokens_produced += n_accepted

            report.tokens_accepted += n_accepted
            report.tokens_rejected += (lookahead - n_accepted)
            report.tokens_generated += n_accepted

            # KV-cache truncation: keep only entries up to verified positions
            final_kv_len = kv_len_before_draft + n_accepted + 1  # +1 for the anchor token
            past_key_values = self._truncate_kv_cache(
                verify_out.past_key_values, final_kv_len
            )

            # EOS check
            if self.tokenizer is not None and self.tokenizer.eos_token_id is not None:
                if accepted_tokens[:, -1].item() == self.tokenizer.eos_token_id:
                    break

        report.total_wallclock_s = time.time() - t0
        return generated, report

    # ── Sampling Utility ──────────────────────────────────────────────────

    @staticmethod
    def _sample(
        logits: torch.Tensor,
        temperature: float,
        top_p: float,
        greedy: bool,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Sample a single token with consistent temperature/top-p."""
        if greedy:
            token = logits.argmax(dim=-1, keepdim=True)
            return token, F.softmax(logits, dim=-1)

        scaled = logits / max(temperature, 1e-8)

        if top_p < 1.0:
            sorted_logits, sorted_indices = torch.sort(scaled, descending=True)
            cumulative = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
            mask = cumulative - F.softmax(sorted_logits, dim=-1) > top_p
            sorted_logits[mask] = -float("inf")
            scaled = sorted_logits.scatter(1, sorted_indices.argsort(1), sorted_logits)

        probs = F.softmax(scaled, dim=-1)
        token = torch.multinomial(probs, 1)
        return token, probs
