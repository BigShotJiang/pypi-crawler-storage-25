"""Plugin-managed JWT/TOTP security policy descriptions and notices."""

from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from typing import TYPE_CHECKING, Literal, TypeGuard, cast

from litestar_auth._manager.totp_secrets import TotpSecretStoragePosture

if TYPE_CHECKING:
    from litestar_auth.authentication.strategy.jwt import JWTRevocationPosture

type _PluginSecurityPolicyKey = Literal["jwt_revocation", "totp_secret_storage"]


@dataclass(frozen=True, slots=True)
class _PluginSecurityPolicy:
    """Shared documentation and ownership wording for plugin-managed security policies."""

    key: _PluginSecurityPolicyKey
    plugin_surface: str
    contract_reference: str
    docs_summary: str
    production_requirement: str


@dataclass(frozen=True, slots=True)
class _PluginSecurityNotice:
    """One concrete runtime notice resolved from a strategy security contract."""

    policy: _PluginSecurityPolicy
    posture_key: str
    requires_explicit_production_opt_in: bool
    production_validation_error: str | None
    startup_warning: str | None


_JWT_REVOCATION_POLICY = _PluginSecurityPolicy(
    key="jwt_revocation",
    plugin_surface="JWTStrategy(allow_inmemory_denylist=True)",
    contract_reference="JWTStrategy.revocation_posture",
    docs_summary=(
        "`JWTStrategy` requires an explicit `denylist_store`, or `allow_inmemory_denylist=True` for "
        "single-process in-memory revocation."
    ),
    production_requirement=(
        "Plugin-managed production has no separate JWT revocation compatibility flag; startup warns when "
        "a strategy is explicitly wired to process-local in-memory revocation."
    ),
)
_TOTP_SECRET_STORAGE_POLICY = _PluginSecurityPolicy(
    key="totp_secret_storage",
    plugin_surface="user_manager_security.totp_secret_keyring",
    contract_reference="BaseUserManager.totp_secret_storage_posture",
    docs_summary=(
        "`BaseUserManager.totp_secret_storage_posture` is the Fernet-encrypted at-rest contract; "
        "omitting both `totp_secret_keyring` and `totp_secret_key` means non-null persisted TOTP secrets "
        "cannot be stored or read."
    ),
    production_requirement=(
        "With `totp_config` enabled, plugin-managed production requires `user_manager_security.totp_secret_keyring` "
        "or the one-key `totp_secret_key` shortcut unless `unsafe_testing=True` or a custom "
        "`user_manager_factory` explicitly owns that wiring."
    ),
)


def _current_jwt_revocation_posture_type() -> type[JWTRevocationPosture]:
    """Return the live JWT revocation posture class."""
    jwt_module = import_module("litestar_auth.authentication.strategy.jwt")
    return cast("type[JWTRevocationPosture]", jwt_module.JWTRevocationPosture)


def _is_current_jwt_revocation_posture(posture: object) -> TypeGuard[JWTRevocationPosture]:
    """Return whether ``posture`` is a concrete JWT revocation posture."""
    return isinstance(posture, _current_jwt_revocation_posture_type())


def _describe_jwt_revocation_policy(posture: object) -> _PluginSecurityNotice | None:
    """Resolve the shared plugin notice for a JWT revocation policy.

    Returns:
        The shared plugin notice when ``posture`` satisfies the JWT revocation
        contract, otherwise ``None``.
    """
    if not _is_current_jwt_revocation_posture(posture):
        return None
    return _PluginSecurityNotice(
        policy=_JWT_REVOCATION_POLICY,
        posture_key=posture.key,
        requires_explicit_production_opt_in=posture.requires_explicit_production_opt_in,
        production_validation_error=posture.production_validation_error,
        startup_warning=posture.startup_warning,
    )


def _describe_totp_secret_storage_policy(
    *,
    totp_secret_key: str | None,
    keyring_configured: bool = False,
) -> _PluginSecurityNotice:
    """Resolve the shared plugin notice for TOTP secret storage policy.

    Returns:
        The shared plugin notice for the resolved TOTP storage posture.
    """
    posture = TotpSecretStoragePosture.from_keyring_inputs(
        totp_secret_key=totp_secret_key,
        keyring_configured=keyring_configured,
    )
    return _PluginSecurityNotice(
        policy=_TOTP_SECRET_STORAGE_POLICY,
        posture_key=posture.key,
        requires_explicit_production_opt_in=posture.requires_explicit_production_opt_in,
        production_validation_error=posture.production_validation_error,
        startup_warning=None,
    )


def _iter_plugin_security_policies() -> tuple[_PluginSecurityPolicy, ...]:
    """Return the shared plugin-managed JWT/TOTP security policy descriptions."""
    return (
        _JWT_REVOCATION_POLICY,
        _TOTP_SECRET_STORAGE_POLICY,
    )
