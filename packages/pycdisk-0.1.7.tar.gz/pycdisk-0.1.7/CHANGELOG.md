# Changelog

## 0.1.0 (2026-05-14)

### Added

- Initial release of PyCDisk library.
- C++ core for Windows disk management (list, initialize, create partition, burn ISO).
- Python bindings using pybind11.
- Python API for easy interaction.
- CMake-based build system.
- `pyproject.toml` and `setup.py` for PyPI distribution.
- Basic `README.md` with usage examples.
