#pragma once

#include <string>
#include <vector>
#include <windows.h>
#include <winioctl.h>

namespace PyCDisk {

enum class PartitionScheme {
    MBR,
    GPT
};

enum class TargetSystem {
    BIOS,
    UEFI
};

struct DiskInfo {
    DWORD diskNumber;
    unsigned long long size;
    std::string model;
    PartitionScheme scheme;
};

class DiskManager {
public:
    DiskManager();
    ~DiskManager();

    std::vector<DiskInfo> listDisks();
    bool initializeDisk(DWORD diskNumber, PartitionScheme scheme);
    bool createPartition(DWORD diskNumber, unsigned long long sizeInBytes);
    bool formatPartition(DWORD diskNumber, DWORD partitionNumber, const std::string& fsType);
    bool writeIsoToDisk(DWORD diskNumber, const std::string& isoPath, TargetSystem target);

private:
    // Вспомогательные методы для работы с Windows API
    bool cleanDisk(HANDLE hDisk);
    bool updateDiskLayout(HANDLE hDisk, PartitionScheme scheme);
};

} // namespace PyCDisk
