#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "DiskManager.h"

namespace py = pybind11;
using namespace PyCDisk;

PYBIND11_MODULE(_core, m) {
    m.doc() = "PyCDisk core C++ implementation for Windows disk management";

    py::enum_<PartitionScheme>(m, "PartitionScheme")
        .value("MBR", PartitionScheme::MBR)
        .value("GPT", PartitionScheme::GPT)
        .export_values();

    py::enum_<TargetSystem>(m, "TargetSystem")
        .value("BIOS", TargetSystem::BIOS)
        .value("UEFI", TargetSystem::UEFI)
        .export_values();

    py::class_<DiskInfo>(m, "DiskInfo")
        .def_readonly("disk_number", &DiskInfo::diskNumber)
        .def_readonly("size", &DiskInfo::size)
        .def_readonly("model", &DiskInfo::model)
        .def_readonly("scheme", &DiskInfo::scheme);

    py::class_<DiskManager>(m, "DiskManager")
        .def(py::init<>())
        .def("list_disks", &DiskManager::listDisks)
        .def("initialize_disk", &DiskManager::initializeDisk)
        .def("create_partition", &DiskManager::createPartition)
        .def("format_partition", &DiskManager::formatPartition)
        .def("write_iso", &DiskManager::writeIsoToDisk);
}
