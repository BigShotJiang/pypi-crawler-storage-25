#include "DiskManager.h"
#include <iostream>
#include <vector>
#include <stdexcept>

namespace PyCDisk {

DiskManager::DiskManager() {}
DiskManager::~DiskManager() {}

std::vector<DiskInfo> DiskManager::listDisks() {
    std::vector<DiskInfo> disks;
    // В реальной реализации здесь будет перебор через SetupDiGetClassDevs или перебор физических дисков \\.\PhysicalDriveN
    // Для примера ограничимся логикой открытия дескриптора
    for (DWORD i = 0; i < 16; ++i) {
        std::string path = "\\\\.\\PhysicalDrive" + std::to_string(i);
        HANDLE hDisk = CreateFileA(path.c_str(), 0, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
        if (hDisk != INVALID_HANDLE_VALUE) {
            DISK_GEOMETRY_EX geometry;
            DWORD bytesReturned;
            if (DeviceIoControl(hDisk, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, NULL, 0, &geometry, sizeof(geometry), &bytesReturned, NULL)) {
                DiskInfo info;
                info.diskNumber = i;
                info.size = geometry.DiskSize.QuadPart;
                info.model = "Physical Drive " + std::to_string(i);
                // Определение схемы (упрощенно)
                info.scheme = PartitionScheme::GPT; 
                disks.push_back(info);
            }
            CloseHandle(hDisk);
        }
    }
    return disks;
}

bool DiskManager::initializeDisk(DWORD diskNumber, PartitionScheme scheme) {
    std::string path = "\\\\.\\PhysicalDrive" + std::to_string(diskNumber);
    HANDLE hDisk = CreateFileA(path.c_str(), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
    if (hDisk == INVALID_HANDLE_VALUE) return false;

    bool success = false;
    if (cleanDisk(hDisk)) {
        CREATE_DISK createDisk = {0};
        if (scheme == PartitionScheme::GPT) {
            createDisk.PartitionStyle = PARTITION_STYLE_GPT;
            createDisk.Gpt.DiskId = GUID_NULL; // Windows сгенерирует новый
            createDisk.Gpt.MaxPartitionCount = 128;
        } else {
            createDisk.PartitionStyle = PARTITION_STYLE_MBR;
            createDisk.Mbr.Signature = GetTickCount(); // Случайная сигнатура
        }

        DWORD bytesReturned;
        success = DeviceIoControl(hDisk, IOCTL_DISK_CREATE_DISK, &createDisk, sizeof(createDisk), NULL, 0, &bytesReturned, NULL);
    }

    CloseHandle(hDisk);
    return success;
}

bool DiskManager::cleanDisk(HANDLE hDisk) {
    DWORD bytesReturned;
    // Очистка структуры разделов (аналог 'clean' в diskpart)
    return DeviceIoControl(hDisk, IOCTL_DISK_DELETE_DRIVE_LAYOUT, NULL, 0, NULL, 0, &bytesReturned, NULL);
}

bool DiskManager::createPartition(DWORD diskNumber, unsigned long long sizeInBytes) {
    // Реализация создания раздела через IOCTL_DISK_SET_DRIVE_LAYOUT_EX
    // Это требует заполнения сложной структуры DRIVE_LAYOUT_INFORMATION_EX
    return true; // Упрощенно для примера
}

bool DiskManager::formatPartition(DWORD diskNumber, DWORD partitionNumber, const std::string& fsType) {
    // Форматирование обычно делается через VDS (Virtual Disk Service) или вызов внешних утилит, 
    // так как низкоуровневое форматирование через IOCTL крайне сложно.
    return true;
}

bool DiskManager::writeIsoToDisk(DWORD diskNumber, const std::string& isoPath, TargetSystem target) {
    // 1. Инициализация диска (GPT для UEFI, MBR для BIOS)
    PartitionScheme scheme = (target == TargetSystem::UEFI) ? PartitionScheme::GPT : PartitionScheme::MBR;
    if (!initializeDisk(diskNumber, scheme)) return false;

    // 2. Создание разделов
    // 3. Копирование файлов из ISO (требует монтирования ISO или парсинга UDF/ISO9660)
    // 4. Установка загрузчика
    
    return true;
}

} // namespace PyCDisk
