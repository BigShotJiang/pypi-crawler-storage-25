# PyCDisk

PyCDisk is a powerful Python library for comprehensive management of Windows disks, implemented with a high-performance C++ core. It provides full control over disk operations, including initialization, partition creation, and burning ISO images to disks with specified partition schemes (MBR/GPT) and target systems (BIOS/UEFI).

## Features

- **List Disks**: Enumerate all physical disks connected to the system.
- **Initialize Disk**: Initialize a disk with either MBR or GPT partition schemes.
- **Create Partition**: Create partitions of a specified size.
- **Burn ISO**: Write an ISO image to a disk, configuring it for BIOS or UEFI boot.

## Installation (Windows Only)

```bash
pip install PyCDisk
```

## Usage

```python
from pycdisk import PyCDisk, PartitionScheme, TargetSystem

disk_manager = PyCDisk()

# List all physical disks
disks = disk_manager.list_disks()
for disk in disks:
    print(f"Disk {disk.disk_number}: Model={disk.model}, Size={disk.size / (1024**3):.2f} GB, Scheme={disk.scheme.name}")

# Example: Initialize Disk 1 with GPT scheme
# if disk_manager.initialize(disk_number=1, scheme="GPT"):
#     print("Disk 1 initialized with GPT.")
# else:
#     print("Failed to initialize Disk 1.")

# Example: Create a 10GB partition on Disk 1
# if disk_manager.create_partition(disk_number=1, size_gb=10):
#     print("10GB partition created on Disk 1.")
# else:
#     print("Failed to create partition on Disk 1.")

# Example: Burn an ISO image to Disk 1 for UEFI boot
# iso_path = "C:\\path\\to\\your\\image.iso"
# if disk_manager.burn_iso(disk_number=1, iso_path=iso_path, target="UEFI"):
#     print(f"ISO {iso_path} burned to Disk 1 for UEFI.")
# else:
#     print(f"Failed to burn ISO {iso_path} to Disk 1.")
```

## Development

To build PyCDisk from source, you will need:

- Python 3.7+
- CMake 3.12+
- A C++17 compatible compiler (MSVC recommended on Windows)
- pybind11

```bash
git clone https://github.com/manus/PyCDisk.git
cd PyCDisk
pip install -r requirements.txt # (if any)
pip install .
```

## Contributing

Contributions are welcome! Please feel free to submit issues and pull requests.

## License

PyCDisk is licensed under the MIT License. See the `LICENSE` file for more details.

## Contact

For questions or support, please contact [support@manus.im](mailto:support@manus.im).
