import importlib.util
import os
import sys
import traceback

__version__ = "0.1.7"

_core = None
_load_error = ""

def _load_binary():
    global _core, _load_error
    pkg_dir = os.path.dirname(__file__)
    
    # Список возможных имен модуля
    possible_names = ["_core"]
    
    # 1. Попытка стандартного импорта
    try:
        from . import _core as m
        _core = m
        return
    except Exception as e:
        _load_error += f"Standard import failed: {str(e)}\n"

    # 2. Поиск .pyd файлов вручную
    try:
        for f in os.listdir(pkg_dir):
            if f.startswith("_core") and f.endswith(".pyd"):
                full_path = os.path.join(pkg_dir, f)
                spec = importlib.util.spec_from_file_location("_core", full_path)
                if spec and spec.loader:
                    m = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(m)
                    _core = m
                    return
    except Exception as e:
        _load_error += f"Manual pyd search failed: {str(e)}\n"
        _load_error += traceback.format_exc()

_load_binary()

class PyCDisk:
    def __init__(self):
        if _core is None:
            pkg_dir = os.path.dirname(__file__)
            files = os.listdir(pkg_dir) if os.path.exists(pkg_dir) else "Directory not found"
            error_msg = (
                f"PyCDisk binary extension (_core) not loaded.\n"
                f"Package directory: {pkg_dir}\n"
                f"Files in directory: {files}\n"
                f"Load errors:\n{_load_error}"
            )
            raise RuntimeError(error_msg)
        self._manager = _core.DiskManager()

    def list_disks(self):
        return self._manager.list_disks()

    def initialize(self, disk_number: int, scheme: str = "GPT"):
        s = _core.PartitionScheme.GPT if scheme.upper() == "GPT" else _core.PartitionScheme.MBR
        return self._manager.initialize_disk(disk_number, s)

    def create_partition(self, disk_number: int, size_gb: float):
        size_bytes = int(size_gb * 1024 * 1024 * 1024)
        return self._manager.create_partition(disk_number, size_bytes)

    def burn_iso(self, disk_number: int, iso_path: str, target: str = "UEFI"):
        t = _core.TargetSystem.UEFI if target.upper() == "UEFI" else _core.TargetSystem.BIOS
        return self._manager.write_iso(disk_number, iso_path, t)

if _core:
    PartitionScheme = _core.PartitionScheme
    TargetSystem = _core.TargetSystem
    __all__ = ["PyCDisk", "PartitionScheme", "TargetSystem"]
else:
    __all__ = ["PyCDisk"]
