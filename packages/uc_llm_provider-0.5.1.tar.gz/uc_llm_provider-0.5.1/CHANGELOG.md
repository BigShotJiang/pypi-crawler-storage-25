## Changelog

All notable changes documented here.

---

## [0.3.0] — 2026-05-19

### Added
- SQLite as default cost logger backend (queryable, aggregatable)
- `CostLogger.query()` and `CostLogger.summary()` for direct DB access
- `reset_cost_logger()` for test isolation
- `LogMode` type alias: `sqlite | jsonl | none`
- `_openai_tools.py` — Tool-Use transformation extracted from `OpenAIProvider`
- `_openai_tier2.py` — Embeddings and Batches mixin
- `_openai_tier3.py` — Moderation, Audio, Images mixin
- `openai.py` reduced to under 200 lines

### Changed
- `--log-mode` default: `sqlite` (server), `none` (CLI)
- `BaseProvider`: removed `_usage_window` and `_usage_log` (moved to CostLogger)
- `openai.py`: uses `OpenAITier2Mixin` and `OpenAITier3Mixin`

---

## [0.2.0] — 2026-05-19

### Added
- `server/` — FastAPI server with `/v1/chat`, `/v1/chat/stream`, `/v1/models`, `/v1/tokens/count`, `/v1/health`, `/v1/capabilities`
- `cli/` — Click CLI with `chat`, `stream`, `models`, `tokens`, `health`, `config` commands
- `logging/base.py` — `JsonlLogger` base class
- `core/` package structure (`base.py`, `models.py`, `retry.py`)
- Optional extras: `server`, `cli`, `anthropic`, `openai`, `google`, `all`
- Entry points: `uc-llm-server`, `uc-llm`
- 53 tests

### Changed
- `BaseProvider`: removed `_connected`, `connect()`, `disconnect()`, `reset()` — `_client is None` check only
- `BaseProvider.__init__`: `logger` and `cost_logger` now optional parameters
- `RequestContext.caller_id` (was `heinzel_id`)
- `logging/` refactored to use `JsonlLogger` base
- All providers cleaned of heinzel-internal imports

### Fixed
- `openai.py`: removed `file_processor` heinzel-internal import
- All providers: removed inline `import os`, `import sys`
- All docstrings: removed H.E.I.N.Z.E.L. references

---

## [0.1.1] — 2026-05-19

### Fixed
- `openai.py`: removed `file_processor` heinzel-internal import (syntax error in `_adapt_pdf_blocks`)
- All providers: removed inline `import os`
- `anthropic.py`, `openai.py`, `google.py`: removed `from config import instance_config`

---

## [0.1.0] — 2026-05-19

### Added
- Initial release
- `BaseProvider` — Tier 1/2/3 abstraction with retry, throttle, streaming, cost logging
- `AnthropicProvider`, `OpenAIProvider`, `GoogleProvider`
- `OpenAICompatibleProvider` — base for any OpenAI-compatible local endpoint
- `OllamaProvider` — local LLMs via Ollama, incl. `pull_model`, `list_local_models`, `delete_model`, `is_running`
- `get_provider(config)` factory
- `register_provider()` — custom provider registration
- JSONL cost logger
- JSONL request/response logger
- Exponential backoff retry
- Provider template
