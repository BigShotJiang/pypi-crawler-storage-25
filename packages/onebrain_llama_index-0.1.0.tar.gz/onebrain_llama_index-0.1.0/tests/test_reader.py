"""Tests for OneBrainReader."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from llama_index.core.schema import Document

from llama_index_onebrain.reader import OneBrainReader, _memory_to_document
from tests.conftest import (
    make_list_response,
    make_memory_item,
    make_search_response,
)


class TestMemoryToDocument:
    """Tests for the _memory_to_document helper."""

    def test_basic_conversion(self):
        memory = make_memory_item()
        doc = _memory_to_document(memory)
        assert isinstance(doc, Document)
        assert "Test Memory" in doc.text
        assert "This is test content." in doc.text
        assert doc.metadata["id"] == "mem_001"
        assert doc.metadata["type"] == "fact"
        assert doc.metadata["confidence"] == 0.95
        assert doc.metadata["source_type"] == "user_input"
        assert doc.metadata["created_at"] == "2026-01-15T09:30:00Z"

    def test_doc_id_matches_memory_id(self):
        memory = make_memory_item(memory_id="mem_xyz")
        doc = _memory_to_document(memory)
        assert doc.doc_id == "mem_xyz"

    def test_title_prepended_to_body(self):
        memory = make_memory_item(title="My Title", body="My Body")
        doc = _memory_to_document(memory)
        assert doc.text == "My Title\n\nMy Body"

    def test_empty_title(self):
        memory = make_memory_item(title="", body="Only body")
        doc = _memory_to_document(memory)
        assert doc.text == "Only body"

    def test_missing_fields(self):
        doc = _memory_to_document({})
        assert doc.text == ""
        assert doc.metadata["id"] == ""
        assert doc.metadata["type"] == ""
        assert doc.metadata["confidence"] == 0.0

    def test_none_body(self):
        memory = make_memory_item(body=None)
        memory["body"] = None
        doc = _memory_to_document(memory)
        assert "Test Memory" in doc.text


class TestOneBrainReaderInit:
    """Tests for OneBrainReader constructor."""

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_init_with_api_key(self, mock_class):
        reader = OneBrainReader(api_key="ob_test:secret")
        mock_class.assert_called_once_with(api_key="ob_test:secret")

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_init_with_base_url(self, mock_class):
        reader = OneBrainReader(
            api_key="ob_test:secret",
            base_url="https://custom.api.com",
        )
        mock_class.assert_called_once_with(
            api_key="ob_test:secret",
            base_url="https://custom.api.com",
        )

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_init_no_args_uses_env(self, mock_class):
        reader = OneBrainReader()
        mock_class.assert_called_once_with()


class TestOneBrainReaderLoadData:
    """Tests for OneBrainReader.load_data."""

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_load_data_with_query(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response()

        reader = OneBrainReader(api_key="ob_test:secret")
        docs = reader.load_data(query="deadlines")

        mock_instance.memory.search.assert_called_once_with(
            "deadlines",
            top_k=100,
        )
        assert len(docs) == 2
        assert all(isinstance(d, Document) for d in docs)

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_load_data_with_query_custom_limit(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response()

        reader = OneBrainReader(api_key="ob_test:secret")
        docs = reader.load_data(query="test", limit=5)

        mock_instance.memory.search.assert_called_once_with(
            "test",
            top_k=5,
        )

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_load_data_with_query_limit_capped(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response()

        reader = OneBrainReader(api_key="ob_test:secret")
        docs = reader.load_data(query="test", limit=200)

        mock_instance.memory.search.assert_called_once_with(
            "test",
            top_k=100,
        )

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_load_data_without_query(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.list.return_value = make_list_response()

        reader = OneBrainReader(api_key="ob_test:secret")
        docs = reader.load_data()

        mock_instance.memory.list.assert_called_once_with(limit=100)
        assert len(docs) == 2

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_load_data_with_memory_type(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.list.return_value = make_list_response()

        reader = OneBrainReader(api_key="ob_test:secret")
        docs = reader.load_data(memory_type="preference")

        mock_instance.memory.list.assert_called_once_with(
            limit=100,
            type="preference",
        )

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_load_data_empty_search_results(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = {"results": []}

        reader = OneBrainReader(api_key="ob_test:secret")
        docs = reader.load_data(query="nonexistent")

        assert docs == []

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_load_data_empty_list_results(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.list.return_value = {"items": []}

        reader = OneBrainReader(api_key="ob_test:secret")
        docs = reader.load_data()

        assert docs == []

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_load_data_query_takes_precedence(self, mock_class):
        """When query is set, memory_type is ignored."""
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response()

        reader = OneBrainReader(api_key="ob_test:secret")
        docs = reader.load_data(query="test", memory_type="fact")

        mock_instance.memory.search.assert_called_once()
        mock_instance.memory.list.assert_not_called()

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_load_data_preserves_metadata(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.list.return_value = make_list_response(
            items=[
                make_memory_item(
                    memory_id="mem_special",
                    memory_type="goal",
                    confidence=0.75,
                    source_type="ai_extraction",
                    created_at="2026-03-01T12:00:00Z",
                )
            ]
        )

        reader = OneBrainReader(api_key="ob_test:secret")
        docs = reader.load_data()

        assert len(docs) == 1
        meta = docs[0].metadata
        assert meta["id"] == "mem_special"
        assert meta["type"] == "goal"
        assert meta["confidence"] == 0.75
        assert meta["source_type"] == "ai_extraction"
        assert meta["created_at"] == "2026-03-01T12:00:00Z"

    @patch("llama_index_onebrain.reader.OneBrain")
    def test_load_data_with_limit_on_list(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.list.return_value = make_list_response()

        reader = OneBrainReader(api_key="ob_test:secret")
        docs = reader.load_data(limit=25)

        mock_instance.memory.list.assert_called_once_with(limit=25)
