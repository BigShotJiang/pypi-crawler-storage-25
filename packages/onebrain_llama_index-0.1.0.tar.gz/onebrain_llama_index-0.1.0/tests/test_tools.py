"""Tests for OneBrainToolSpec."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from llama_index_onebrain.tools import OneBrainToolSpec
from tests.conftest import (
    make_context_response,
    make_entity_item,
    make_entity_list_response,
    make_memory_item,
    make_search_response,
)


class TestOneBrainToolSpecInit:
    """Tests for OneBrainToolSpec constructor."""

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_init_with_api_key(self, mock_class):
        spec = OneBrainToolSpec(api_key="ob_test:secret")
        mock_class.assert_called_once_with(api_key="ob_test:secret")

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_init_with_base_url(self, mock_class):
        spec = OneBrainToolSpec(
            api_key="ob_test:secret",
            base_url="https://custom.api.com",
        )
        mock_class.assert_called_once_with(
            api_key="ob_test:secret",
            base_url="https://custom.api.com",
        )

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_init_no_args(self, mock_class):
        spec = OneBrainToolSpec()
        mock_class.assert_called_once_with()

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_spec_functions_declared(self, mock_class):
        spec = OneBrainToolSpec(api_key="ob_test:secret")
        assert "search_memory" in spec.spec_functions
        assert "write_memory" in spec.spec_functions
        assert "get_context" in spec.spec_functions
        assert "list_entities" in spec.spec_functions
        assert len(spec.spec_functions) == 4


class TestSearchMemory:
    """Tests for OneBrainToolSpec.search_memory."""

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_search_returns_formatted_results(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response()

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.search_memory("deadlines")

        assert "Test Memory" in result
        assert "0.92" in result
        assert "Second Memory" in result

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_search_passes_top_k(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = {"results": []}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        spec.search_memory("test", top_k=3)

        mock_instance.memory.search.assert_called_once_with(
            "test",
            top_k=3,
        )

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_search_empty_results(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = {"results": []}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.search_memory("nothing")

        assert result == "No memories found."

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_search_includes_type_in_output(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response(
            results=[
                make_memory_item(memory_type="preference"),
            ]
        )

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.search_memory("prefs")

        assert "[preference]" in result

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_search_includes_body(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response(
            results=[
                make_memory_item(body="Very specific content here"),
            ]
        )

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.search_memory("specific")

        assert "Very specific content here" in result

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_search_numbering(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response()

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.search_memory("test")

        assert result.startswith("1.")
        assert "2." in result

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_search_default_top_k(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = {"results": []}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        spec.search_memory("test")

        mock_instance.memory.search.assert_called_once_with(
            "test",
            top_k=10,
        )


class TestWriteMemory:
    """Tests for OneBrainToolSpec.write_memory."""

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_write_creates_memory(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.create.return_value = {"id": "mem_new"}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.write_memory("User prefers dark mode")

        mock_instance.memory.create.assert_called_once()
        call_kwargs = mock_instance.memory.create.call_args
        assert call_kwargs.kwargs["type"] == "fact"
        assert call_kwargs.kwargs["body"] == "User prefers dark mode"
        assert call_kwargs.kwargs["source_type"] == "ai_extraction"

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_write_custom_type(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.create.return_value = {"id": "mem_pref"}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.write_memory(
            "Prefers dark mode",
            memory_type="preference",
        )

        call_kwargs = mock_instance.memory.create.call_args
        assert call_kwargs.kwargs["type"] == "preference"

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_write_returns_confirmation(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.create.return_value = {"id": "mem_123"}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.write_memory("Some content")

        assert "Memory created successfully" in result
        assert "mem_123" in result
        assert "fact" in result

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_write_title_from_first_line(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.create.return_value = {"id": "mem_1"}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        spec.write_memory("First line\nSecond line\nThird line")

        call_kwargs = mock_instance.memory.create.call_args
        assert call_kwargs.kwargs["title"] == "First line"

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_write_title_truncated_at_80(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.create.return_value = {"id": "mem_1"}

        long_content = "A" * 200
        spec = OneBrainToolSpec(api_key="ob_test:secret")
        spec.write_memory(long_content)

        call_kwargs = mock_instance.memory.create.call_args
        assert len(call_kwargs.kwargs["title"]) == 80

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_write_missing_id_in_response(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.create.return_value = {}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.write_memory("Content")

        assert "unknown" in result


class TestGetContext:
    """Tests for OneBrainToolSpec.get_context."""

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_get_context_default_scope(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.context.get.return_value = make_context_response()

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.get_context()

        mock_instance.context.get.assert_called_once_with(
            scope="assistant",
        )
        assert "dark mode" in result

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_get_context_custom_scope(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.context.get.return_value = make_context_response(
            scope="deep",
        )

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        spec.get_context(scope="deep")

        mock_instance.context.get.assert_called_once_with(scope="deep")

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_get_context_returns_formatted(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.context.get.return_value = {
            "formatted": "Custom formatted text",
            "structured": {},
            "meta": {},
        }

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.get_context()

        assert result == "Custom formatted text"

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_get_context_falls_back_to_structured(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.context.get.return_value = {
            "formatted": "",
            "structured": {"profile": {"summary": "Developer"}},
            "meta": {},
        }

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.get_context()

        parsed = json.loads(result)
        assert parsed["profile"]["summary"] == "Developer"

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_get_context_no_data_available(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.context.get.return_value = {
            "formatted": "",
            "structured": {},
            "meta": {},
        }

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.get_context()

        assert result == "No context available."

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_get_context_missing_keys(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.context.get.return_value = {}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.get_context()

        assert result == "No context available."


class TestListEntities:
    """Tests for OneBrainToolSpec.list_entities."""

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_list_entities_returns_formatted(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.entity.list.return_value = (
            make_entity_list_response()
        )

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.list_entities()

        assert "Alice" in result
        assert "[person]" in result
        assert "Bob" in result
        assert "[organization]" in result

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_list_entities_with_type_filter(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.entity.list.return_value = (
            make_entity_list_response()
        )

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        spec.list_entities(entity_type="person")

        mock_instance.entity.list.assert_called_once_with(
            limit=50,
            type="person",
        )

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_list_entities_no_type_filter(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.entity.list.return_value = {"items": []}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        spec.list_entities()

        mock_instance.entity.list.assert_called_once_with(limit=50)

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_list_entities_empty(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.entity.list.return_value = {"items": []}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.list_entities()

        assert result == "No entities found."

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_list_entities_includes_description(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.entity.list.return_value = make_entity_list_response(
            items=[
                make_entity_item(
                    name="Charlie",
                    description="A designer",
                ),
            ]
        )

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.list_entities()

        assert "Charlie" in result
        assert "A designer" in result

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_list_entities_no_description(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.entity.list.return_value = make_entity_list_response(
            items=[
                make_entity_item(name="NoDesc", description=""),
            ]
        )

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.list_entities()

        assert "NoDesc" in result
        assert " -- " not in result

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_list_entities_numbering(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.entity.list.return_value = (
            make_entity_list_response()
        )

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.list_entities()

        lines = result.strip().split("\n")
        assert lines[0].startswith("1.")
        assert lines[1].startswith("2.")

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_list_entities_missing_items_key(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.entity.list.return_value = {}

        spec = OneBrainToolSpec(api_key="ob_test:secret")
        result = spec.list_entities()

        assert result == "No entities found."


class TestToolSpecToToolList:
    """Tests that to_tool_list works correctly."""

    @patch("llama_index_onebrain.tools.OneBrain")
    def test_to_tool_list_returns_tools(self, mock_class):
        spec = OneBrainToolSpec(api_key="ob_test:secret")
        tools = spec.to_tool_list()
        tool_names = [t.metadata.name for t in tools]

        assert "search_memory" in tool_names
        assert "write_memory" in tool_names
        assert "get_context" in tool_names
        assert "list_entities" in tool_names
        assert len(tools) == 4
