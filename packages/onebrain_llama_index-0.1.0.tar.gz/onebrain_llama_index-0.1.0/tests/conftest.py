"""Shared fixtures for llama-index-onebrain tests."""

from __future__ import annotations

from typing import Any, Dict, List
from unittest.mock import MagicMock, patch

import pytest


def make_memory_item(
    memory_id: str = "mem_001",
    title: str = "Test Memory",
    body: str = "This is test content.",
    memory_type: str = "fact",
    confidence: float = 0.95,
    source_type: str = "user_input",
    created_at: str = "2026-01-15T09:30:00Z",
    score: float = 0.88,
) -> Dict[str, Any]:
    """Build a mock memory item dict."""
    return {
        "id": memory_id,
        "title": title,
        "body": body,
        "type": memory_type,
        "confidence": confidence,
        "source_type": source_type,
        "created_at": created_at,
        "updated_at": created_at,
        "status": "active",
        "score": score,
        "metadata": None,
    }


def make_entity_item(
    entity_id: str = "ent_001",
    name: str = "Alice",
    entity_type: str = "person",
    description: str = "A developer",
) -> Dict[str, Any]:
    """Build a mock entity item dict."""
    return {
        "id": entity_id,
        "name": name,
        "type": entity_type,
        "description": description,
        "metadata": None,
        "created_at": "2026-01-15T09:30:00Z",
        "updated_at": "2026-01-15T09:30:00Z",
    }


def make_search_response(
    results: List[Dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    """Build a mock search response."""
    if results is None:
        results = [
            make_memory_item(memory_id="mem_001", score=0.92),
            make_memory_item(
                memory_id="mem_002",
                title="Second Memory",
                body="Another piece of content.",
                score=0.78,
            ),
        ]
    return {
        "results": results,
        "search_mode": "hybrid",
    }


def make_list_response(
    items: List[Dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    """Build a mock list response."""
    if items is None:
        items = [
            make_memory_item(memory_id="mem_001"),
            make_memory_item(
                memory_id="mem_002",
                title="Second Memory",
                body="Second content.",
            ),
        ]
    return {
        "items": items,
        "cursor": None,
        "hasMore": False,
        "total": len(items),
    }


def make_entity_list_response(
    items: List[Dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    """Build a mock entity list response."""
    if items is None:
        items = [
            make_entity_item(),
            make_entity_item(
                entity_id="ent_002",
                name="Bob",
                entity_type="organization",
                description="A company",
            ),
        ]
    return {
        "items": items,
        "cursor": None,
        "hasMore": False,
        "total": len(items),
    }


def make_context_response(
    scope: str = "assistant",
) -> Dict[str, Any]:
    """Build a mock context response."""
    return {
        "formatted": (
            "User Profile:\n"
            "- Prefers dark mode\n"
            "- Works on AI projects\n"
        ),
        "structured": {
            "profile": {"summary": "AI developer"},
            "memories": [],
            "entities": [],
        },
        "meta": {
            "scope": scope,
            "token_estimate": 150,
            "truncated": False,
        },
    }


@pytest.fixture()
def mock_onebrain_client() -> MagicMock:
    """Return a fully mocked OneBrain client instance."""
    client = MagicMock()
    client.memory = MagicMock()
    client.entity = MagicMock()
    client.context = MagicMock()
    client.brain = MagicMock()
    return client


@pytest.fixture()
def patch_onebrain():
    """Context manager that patches OneBrain constructor.

    Yields a tuple of (mock_class, mock_instance).
    """
    with patch(
        "onebrain.OneBrain",
    ) as mock_class:
        mock_instance = MagicMock()
        mock_instance.memory = MagicMock()
        mock_instance.entity = MagicMock()
        mock_instance.context = MagicMock()
        mock_instance.brain = MagicMock()
        mock_class.return_value = mock_instance
        yield mock_class, mock_instance
