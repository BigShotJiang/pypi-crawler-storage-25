"""Tests for OneBrainRetriever."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from llama_index.core.schema import NodeWithScore, QueryBundle, TextNode

from llama_index_onebrain.retriever import OneBrainRetriever
from tests.conftest import make_memory_item, make_search_response


class TestOneBrainRetrieverInit:
    """Tests for OneBrainRetriever constructor."""

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_init_defaults(self, mock_class):
        retriever = OneBrainRetriever(api_key="ob_test:secret")
        mock_class.assert_called_once_with(api_key="ob_test:secret")
        assert retriever._top_k == 10
        assert retriever._search_mode == "hybrid"

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_init_custom_params(self, mock_class):
        retriever = OneBrainRetriever(
            api_key="ob_test:secret",
            top_k=5,
            search_mode="vector",
            base_url="https://custom.api.com",
        )
        mock_class.assert_called_once_with(
            api_key="ob_test:secret",
            base_url="https://custom.api.com",
        )
        assert retriever._top_k == 5
        assert retriever._search_mode == "vector"

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_init_no_api_key_uses_env(self, mock_class):
        retriever = OneBrainRetriever()
        mock_class.assert_called_once_with()


class TestOneBrainRetrieverRetrieve:
    """Tests for OneBrainRetriever._retrieve."""

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_returns_nodes(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response()

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        bundle = QueryBundle(query_str="test query")
        nodes = retriever._retrieve(bundle)

        assert len(nodes) == 2
        assert all(isinstance(n, NodeWithScore) for n in nodes)

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_passes_search_params(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response()

        retriever = OneBrainRetriever(
            api_key="ob_test:secret",
            top_k=3,
            search_mode="keyword",
        )
        bundle = QueryBundle(query_str="hello")
        retriever._retrieve(bundle)

        mock_instance.memory.search.assert_called_once_with(
            "hello",
            mode="keyword",
            top_k=3,
        )

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_node_text_includes_title(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response(
            results=[
                make_memory_item(title="Important", body="Details here")
            ]
        )

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        bundle = QueryBundle(query_str="test")
        nodes = retriever._retrieve(bundle)

        assert len(nodes) == 1
        assert "Important" in nodes[0].node.text
        assert "Details here" in nodes[0].node.text

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_node_scores(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response(
            results=[
                make_memory_item(memory_id="a", score=0.95),
                make_memory_item(memory_id="b", score=0.60),
            ]
        )

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        bundle = QueryBundle(query_str="test")
        nodes = retriever._retrieve(bundle)

        assert nodes[0].score == pytest.approx(0.95)
        assert nodes[1].score == pytest.approx(0.60)

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_node_metadata(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response(
            results=[
                make_memory_item(
                    memory_id="mem_x",
                    memory_type="preference",
                    confidence=0.80,
                    source_type="system_inference",
                )
            ]
        )

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        bundle = QueryBundle(query_str="prefs")
        nodes = retriever._retrieve(bundle)

        meta = nodes[0].node.metadata
        assert meta["id"] == "mem_x"
        assert meta["type"] == "preference"
        assert meta["confidence"] == 0.80
        assert meta["source_type"] == "system_inference"

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_node_id_matches(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response(
            results=[make_memory_item(memory_id="mem_abc123")]
        )

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        bundle = QueryBundle(query_str="test")
        nodes = retriever._retrieve(bundle)

        assert nodes[0].node.id_ == "mem_abc123"

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_empty_results(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = {"results": []}

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        bundle = QueryBundle(query_str="nothing")
        nodes = retriever._retrieve(bundle)

        assert nodes == []

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_missing_results_key(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = {}

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        bundle = QueryBundle(query_str="test")
        nodes = retriever._retrieve(bundle)

        assert nodes == []

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_empty_title(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = make_search_response(
            results=[make_memory_item(title="", body="Just body")]
        )

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        bundle = QueryBundle(query_str="test")
        nodes = retriever._retrieve(bundle)

        assert nodes[0].node.text == "Just body"

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_missing_score_defaults_to_zero(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        result = make_memory_item()
        del result["score"]
        mock_instance.memory.search.return_value = {"results": [result]}

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        bundle = QueryBundle(query_str="test")
        nodes = retriever._retrieve(bundle)

        assert nodes[0].score == pytest.approx(0.0)

    @patch("llama_index_onebrain.retriever.OneBrain")
    def test_retrieve_uses_hybrid_by_default(self, mock_class):
        mock_instance = MagicMock()
        mock_class.return_value = mock_instance
        mock_instance.memory.search.return_value = {"results": []}

        retriever = OneBrainRetriever(api_key="ob_test:secret")
        bundle = QueryBundle(query_str="test")
        retriever._retrieve(bundle)

        mock_instance.memory.search.assert_called_once_with(
            "test",
            mode="hybrid",
            top_k=10,
        )
