"""LlamaIndex integration for OneBrain -- persistent AI memory layer.

This package provides LlamaIndex-compatible components that wrap the
``onebrain-sdk`` Python client.  If the OneBrain HTTP API changes, only
the SDK needs updating -- this integration stays stable.

Components:
    OneBrainReader      -- load OneBrain memories as LlamaIndex Documents
    OneBrainRetriever   -- semantic retriever backed by OneBrain search
    OneBrainToolSpec    -- agent tool spec for memory read/write
"""

from llama_index_onebrain._version import __version__
from llama_index_onebrain.reader import OneBrainReader
from llama_index_onebrain.retriever import OneBrainRetriever
from llama_index_onebrain.tools import OneBrainToolSpec

__all__ = [
    "__version__",
    "OneBrainReader",
    "OneBrainRetriever",
    "OneBrainToolSpec",
]
