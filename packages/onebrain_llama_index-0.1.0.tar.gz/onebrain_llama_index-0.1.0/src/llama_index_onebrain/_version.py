"""Version information for llama-index-onebrain."""

__version__ = "0.1.0"
