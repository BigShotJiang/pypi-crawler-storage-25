"""OneBrain document reader for LlamaIndex.

Loads OneBrain memories as ``llama_index.core.schema.Document`` objects,
either via search (when *query* is provided) or via listing.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from llama_index.core.readers.base import BaseReader
from llama_index.core.schema import Document
from onebrain import OneBrain

logger = logging.getLogger(__name__)


def _memory_to_document(memory: Dict[str, Any]) -> Document:
    """Convert a single OneBrain memory dict to a LlamaIndex Document."""
    text = memory.get("body", "") or ""
    title = memory.get("title", "")
    if title:
        text = f"{title}\n\n{text}"

    metadata: Dict[str, Any] = {
        "id": memory.get("id", ""),
        "type": memory.get("type", ""),
        "confidence": memory.get("confidence", 0.0),
        "source_type": memory.get("source_type", ""),
        "created_at": memory.get("created_at", ""),
    }

    return Document(
        text=text,
        metadata=metadata,
        doc_id=memory.get("id", ""),
    )


class OneBrainReader(BaseReader):
    """Load OneBrain memories as LlamaIndex Documents.

    If *query* is provided to :meth:`load_data`, memories are fetched
    via ``memory.search``.  Otherwise ``memory.list`` is used with an
    optional *memory_type* filter.

    Args:
        api_key: OneBrain API key.  Falls back to the
            ``ONEBRAIN_API_KEY`` environment variable.
        base_url: Optional custom API base URL for self-hosted
            deployments.

    Example::

        reader = OneBrainReader(api_key="ob_xxx:secret")
        docs = reader.load_data(query="project deadlines")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> None:
        super().__init__()
        kwargs: Dict[str, Any] = {}
        if api_key is not None:
            kwargs["api_key"] = api_key
        if base_url is not None:
            kwargs["base_url"] = base_url
        self._client = OneBrain(**kwargs)

    def load_data(
        self,
        query: Optional[str] = None,
        memory_type: Optional[str] = None,
        limit: int = 100,
    ) -> List[Document]:
        """Load memories as LlamaIndex Documents.

        Args:
            query: When provided, performs a semantic search and
                returns matching memories.
            memory_type: Filter by memory type when listing (ignored
                when *query* is set).  Valid values: fact, preference,
                decision, goal, experience, skill.
            limit: Maximum number of memories to return (default 100,
                max 100).

        Returns:
            List of LlamaIndex Document objects.
        """
        if query is not None:
            return self._load_from_search(query, limit)
        return self._load_from_list(memory_type, limit)

    def _load_from_search(
        self,
        query: str,
        limit: int,
    ) -> List[Document]:
        """Fetch memories via semantic search."""
        logger.debug("OneBrainReader: searching for %r", query)
        response = self._client.memory.search(
            query,
            top_k=min(limit, 100),
        )
        results: List[Dict[str, Any]] = response.get("results", [])
        return [_memory_to_document(r) for r in results]

    def _load_from_list(
        self,
        memory_type: Optional[str],
        limit: int,
    ) -> List[Document]:
        """Fetch memories via paginated listing."""
        logger.debug(
            "OneBrainReader: listing type=%s limit=%d",
            memory_type,
            limit,
        )
        kwargs: Dict[str, Any] = {"limit": min(limit, 100)}
        if memory_type is not None:
            kwargs["type"] = memory_type

        response = self._client.memory.list(**kwargs)
        items: List[Dict[str, Any]] = response.get("items", [])
        return [_memory_to_document(item) for item in items]
