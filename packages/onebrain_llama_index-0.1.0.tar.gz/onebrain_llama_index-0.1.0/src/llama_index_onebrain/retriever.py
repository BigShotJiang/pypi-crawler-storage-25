"""OneBrain retriever for LlamaIndex.

Implements ``BaseRetriever`` so it can be plugged directly into
any LlamaIndex query engine or chat engine pipeline.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from llama_index.core.callbacks import CallbackManager
from llama_index.core.retrievers import BaseRetriever
from llama_index.core.schema import NodeWithScore, QueryBundle, TextNode
from onebrain import OneBrain

logger = logging.getLogger(__name__)


class OneBrainRetriever(BaseRetriever):
    """Retrieve OneBrain memories as scored nodes.

    Uses ``memory.search`` under the hood with configurable search
    mode and result count.

    Args:
        api_key: OneBrain API key.  Falls back to the
            ``ONEBRAIN_API_KEY`` environment variable.
        top_k: Maximum number of results to return (default 10).
        search_mode: OneBrain search mode -- one of ``"hybrid"``,
            ``"keyword"``, or ``"vector"`` (default ``"hybrid"``).
        base_url: Optional custom API base URL for self-hosted
            deployments.
        callback_manager: Optional LlamaIndex callback manager.

    Example::

        retriever = OneBrainRetriever(
            api_key="ob_xxx:secret",
            top_k=5,
        )
        nodes = retriever.retrieve("project deadlines")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        top_k: int = 10,
        search_mode: str = "hybrid",
        base_url: Optional[str] = None,
        callback_manager: Optional[CallbackManager] = None,
    ) -> None:
        self._top_k = top_k
        self._search_mode = search_mode

        client_kwargs: Dict[str, Any] = {}
        if api_key is not None:
            client_kwargs["api_key"] = api_key
        if base_url is not None:
            client_kwargs["base_url"] = base_url
        self._client = OneBrain(**client_kwargs)

        super().__init__(callback_manager=callback_manager)

    def _retrieve(
        self,
        query_bundle: QueryBundle,
    ) -> List[NodeWithScore]:
        """Execute a search against OneBrain and return scored nodes.

        Args:
            query_bundle: The query to search for.

        Returns:
            List of ``NodeWithScore`` objects ordered by relevance.
        """
        query_str = query_bundle.query_str
        logger.debug(
            "OneBrainRetriever: query=%r top_k=%d mode=%s",
            query_str,
            self._top_k,
            self._search_mode,
        )

        response = self._client.memory.search(
            query_str,
            mode=self._search_mode,
            top_k=self._top_k,
        )

        results: List[Dict[str, Any]] = response.get("results", [])
        nodes: List[NodeWithScore] = []

        for result in results:
            text = result.get("body", "") or ""
            title = result.get("title", "")
            if title:
                text = f"{title}\n\n{text}"

            metadata: Dict[str, Any] = {
                "id": result.get("id", ""),
                "type": result.get("type", ""),
                "confidence": result.get("confidence", 0.0),
                "source_type": result.get("source_type", ""),
            }

            node = TextNode(
                text=text,
                metadata=metadata,
                id_=result.get("id", ""),
            )

            score = float(result.get("score", 0.0))
            nodes.append(NodeWithScore(node=node, score=score))

        return nodes
