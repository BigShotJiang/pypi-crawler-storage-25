"""OneBrain tool spec for LlamaIndex agents.

Exposes OneBrain memory operations as callable tools that can be
used by ReAct, OpenAI, or any other LlamaIndex agent.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional

from llama_index.core.tools.tool_spec.base import BaseToolSpec
from onebrain import OneBrain

logger = logging.getLogger(__name__)


class OneBrainToolSpec(BaseToolSpec):
    """LlamaIndex tool spec that exposes OneBrain memory operations.

    Provides four tools for agents: search, write, get context, and
    list entities.

    Args:
        api_key: OneBrain API key.  Falls back to the
            ``ONEBRAIN_API_KEY`` environment variable.
        base_url: Optional custom API base URL for self-hosted
            deployments.

    Example::

        from llama_index.core.agent import ReActAgent
        from llama_index.llms.openai import OpenAI

        spec = OneBrainToolSpec(api_key="ob_xxx:secret")
        agent = ReActAgent.from_tools(
            spec.to_tool_list(),
            llm=OpenAI(model="gpt-4"),
        )
        response = agent.chat("What do you know about me?")
    """

    spec_functions = [
        "search_memory",
        "write_memory",
        "get_context",
        "list_entities",
    ]

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> None:
        super().__init__()
        client_kwargs: Dict[str, Any] = {}
        if api_key is not None:
            client_kwargs["api_key"] = api_key
        if base_url is not None:
            client_kwargs["base_url"] = base_url
        self._client = OneBrain(**client_kwargs)

    def search_memory(
        self,
        query: str,
        top_k: int = 10,
    ) -> str:
        """Search OneBrain memories by semantic query.

        Args:
            query: The natural language search query.
            top_k: Maximum number of results (default 10).

        Returns:
            Formatted string of matching memories with scores.
        """
        logger.debug(
            "OneBrainToolSpec.search_memory: query=%r top_k=%d",
            query,
            top_k,
        )
        response = self._client.memory.search(query, top_k=top_k)
        results: List[Dict[str, Any]] = response.get("results", [])

        if not results:
            return "No memories found."

        lines: List[str] = []
        for idx, result in enumerate(results, start=1):
            title = result.get("title", "Untitled")
            body = result.get("body", "")
            score = result.get("score", 0.0)
            memory_type = result.get("type", "unknown")
            lines.append(
                f"{idx}. [{memory_type}] {title} "
                f"(score: {score:.2f})\n   {body}"
            )

        return "\n\n".join(lines)

    def write_memory(
        self,
        content: str,
        memory_type: str = "fact",
    ) -> str:
        """Write a new memory to OneBrain.

        Args:
            content: The memory content to store.
            memory_type: Type of memory -- one of fact, preference,
                decision, goal, experience, skill (default "fact").

        Returns:
            Confirmation string with the created memory ID.
        """
        logger.debug(
            "OneBrainToolSpec.write_memory: type=%s len=%d",
            memory_type,
            len(content),
        )
        title = content[:80].split("\n")[0]
        result = self._client.memory.create(
            type=memory_type,
            title=title,
            body=content,
            source_type="ai_extraction",
        )
        memory_id = result.get("id", "unknown")
        return (
            f"Memory created successfully. "
            f"ID: {memory_id}, type: {memory_type}"
        )

    def get_context(self, scope: str = "assistant") -> str:
        """Retrieve the OneBrain context for the current user.

        Args:
            scope: Context scope level -- one of brief, assistant,
                project, deep (default "assistant").

        Returns:
            Formatted context string.
        """
        logger.debug(
            "OneBrainToolSpec.get_context: scope=%s",
            scope,
        )
        response = self._client.context.get(scope=scope)

        formatted = response.get("formatted", "")
        if formatted:
            return formatted

        structured = response.get("structured", {})
        if structured:
            return json.dumps(structured, indent=2, default=str)

        return "No context available."

    def list_entities(
        self,
        entity_type: Optional[str] = None,
    ) -> str:
        """List entities stored in OneBrain.

        Args:
            entity_type: Optional filter by entity type (e.g.
                person, organization, tool).

        Returns:
            Formatted string of entities.
        """
        logger.debug(
            "OneBrainToolSpec.list_entities: type=%s",
            entity_type,
        )
        kwargs: Dict[str, Any] = {"limit": 50}
        if entity_type is not None:
            kwargs["type"] = entity_type

        response = self._client.entity.list(**kwargs)
        items: List[Dict[str, Any]] = response.get("items", [])

        if not items:
            return "No entities found."

        lines: List[str] = []
        for idx, entity in enumerate(items, start=1):
            name = entity.get("name", "Unknown")
            etype = entity.get("type", "unknown")
            description = entity.get("description", "")
            desc_part = f" -- {description}" if description else ""
            lines.append(f"{idx}. [{etype}] {name}{desc_part}")

        return "\n".join(lines)
