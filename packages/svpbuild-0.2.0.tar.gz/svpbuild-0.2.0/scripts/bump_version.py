import re
import sys
from pathlib import Path


def bump_version(version: str, bump_type: str) -> str:
    parts = version.split(".")
    if len(parts) != 3:
        raise ValueError(f"Version string '{version}' does not match expected format X.Y.Z")

    major, minor, patch = map(int, parts)

    if bump_type == "major":
        return f"{major + 1}.0.0"
    elif bump_type == "minor":
        return f"{major}.{minor + 1}.0"
    elif bump_type == "patch":
        return f"{major}.{minor}.{patch + 1}"
    else:
        raise ValueError(f"Invalid bump type: {bump_type}")


def main():
    if len(sys.argv) != 2:
        print("Usage: python scripts/bump_version.py [major|minor|patch]")
        sys.exit(1)

    bump_type = sys.argv[1].lower()
    if bump_type not in ["major", "minor", "patch"]:
        print(f"Error: Invalid bump type '{bump_type}'. Must be major, minor, or patch.")
        sys.exit(1)

    pyproject_path = Path("pyproject.toml")
    if not pyproject_path.exists():
        print("Error: pyproject.toml not found in current directory.")
        sys.exit(1)

    content = pyproject_path.read_text()

    # Match the version line exactly in the [project] section
    match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
    if not match:
        print("Error: Could not find version string in pyproject.toml")
        sys.exit(1)

    old_version = match.group(1)
    new_version = bump_version(old_version, bump_type)

    # Replace just the version string
    new_content = content[: match.start(1)] + new_version + content[match.end(1) :]
    pyproject_path.write_text(new_content)

    # Print the new version to stdout so the GitHub Action can capture it
    print(new_version)


if __name__ == "__main__":
    main()
