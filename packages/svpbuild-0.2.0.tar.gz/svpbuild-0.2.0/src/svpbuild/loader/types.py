from dataclasses import dataclass, field


@dataclass
class PortraitAsset:
    """
    Represents an individual portrait file.

    Attributes:
        variant: The variant name (e.g., 'Standard', 'Beach').
        conditions: A dictionary of Content Patcher condition keys and values (e.g., {'Season': 'Spring'}).
        path: The relative path to the image file.
    """

    path: str
    variant: str
    conditions: dict[str, str | int | bool] = field(default_factory=dict)


@dataclass
class CharacterAsset:
    """
    Represents a character's portrait assets discovered on disk.

    Attributes:
        name: The name of the character (e.g., 'Harvey').
        portraits: A list of PortraitAsset objects.
    """

    name: str
    portraits: list[PortraitAsset] = field(default_factory=list)

    @property
    def variants(self) -> set[str]:
        """Returns a set of unique variants associated with this character."""
        return set(portrait.variant for portrait in self.portraits)
