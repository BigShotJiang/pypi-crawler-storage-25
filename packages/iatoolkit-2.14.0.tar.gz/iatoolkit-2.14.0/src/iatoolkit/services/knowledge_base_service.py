# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit
#
# IAToolkit is open source software.


from iatoolkit.repositories.models import Document, VSDoc, Company, DocumentStatus
from iatoolkit.repositories.document_repo import DocumentRepo
from iatoolkit.repositories.vs_repo import VSRepo
from iatoolkit.repositories.models import CollectionType
from iatoolkit.services.profile_service import ProfileService
from iatoolkit.services.i18n_service import I18nService
from iatoolkit.services.storage_service import StorageService
from iatoolkit.services.parsers.parsing_service import ParsingService
from langchain_text_splitters import RecursiveCharacterTextSplitter
from iatoolkit.services.visual_kb_service import VisualKnowledgeBaseService
from sqlalchemy import desc, func
from typing import Any
import json
from iatoolkit.common.exceptions import IAToolkitException
import logging
import hashlib
import os
from typing import List, Optional, Union
from datetime import datetime
from injector import inject
import mimetypes


class KnowledgeBaseService:
    """
    Central service for managing the RAG (Retrieval-Augmented Generation) Knowledge Base.
    Orchestrates ingestion (OCR -> Split -> Embed -> Store), retrieval, and management.
    """

    @inject
    def __init__(self,
                 document_repo: DocumentRepo,
                 vs_repo: VSRepo,
                 visual_kb_service: VisualKnowledgeBaseService,
                 parsing_service: ParsingService,
                 storage_service: StorageService,
                 profile_service: ProfileService,
                 i18n_service: I18nService):
        self.document_repo = document_repo
        self.vs_repo = vs_repo
        self.visual_kb_service = visual_kb_service
        self.parsing_service = parsing_service
        self.storage_service = storage_service
        self.profile_service = profile_service
        self.i18n_service = i18n_service

        # Configure LangChain for intelligent text splitting
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=100,
            separators=["\n\n", "\n", ".", " ", ""]
        )
        self.min_chunk_chars = int(os.getenv("RAG_MIN_CHUNK_CHARS", "250"))
        self.merge_target_chars = int(os.getenv("RAG_MERGE_TARGET_CHARS", "800"))

    @staticmethod
    def _strip_nul_chars(value: Any) -> Any:
        """Recursively removes NUL bytes from text/metadata before persisting to Postgres."""
        if isinstance(value, str):
            return value.replace("\x00", "")
        if isinstance(value, dict):
            return {k: KnowledgeBaseService._strip_nul_chars(v) for k, v in value.items()}
        if isinstance(value, list):
            return [KnowledgeBaseService._strip_nul_chars(item) for item in value]
        if isinstance(value, tuple):
            return tuple(KnowledgeBaseService._strip_nul_chars(item) for item in value)
        return value

    def ingest_document_sync(self,
                             company: Company,
                             filename: str,
                             content: bytes,
                             user_identifier: str = None,
                             metadata: dict = None,
                             collection: str = None) -> Document:
        """
        Synchronously processes a document through the entire RAG pipeline:
        1. Saves initial metadata and raw content reference to the SQL Document table.
        2. Parses content via configured parsing provider (docling/basic/custom).
        3. Splits the text into semantic chunks using LangChain.
        4. Vectorizes and saves chunks to the Vector Store (VSRepo).
        5. Updates the document status to ACTIVE or FAILED.

        Args:
            company: The company owning the document.
            filename: Original filename.
            content: Raw bytes of the file.
            metadata: Optional dictionary with additional info (e.g., document_type).

        Returns:
            The created Document object.
        """
        if not metadata:
            metadata = {}

        metadata = self._strip_nul_chars(metadata)

        # --- Logic for Collection ---
        # priority: 1. method parameter 2. metadata
        collection_name = collection or metadata.get('collection')
        collection_id = self.document_repo.get_collection_id_by_name(company.short_name, collection_name)

        # ---  Router ---
        import mimetypes
        mime_type, _ = mimetypes.guess_type(filename)

        if mime_type and mime_type.startswith('image/'):
            return self.visual_kb_service.ingest_image_sync(
                company=company,
                filename=filename,
                content=content,
                user_identifier=user_identifier,
                metadata=metadata,
                collection_type_id=collection_id
            )
        # 1. Calculate SHA-256 hash of the content
        file_hash = hashlib.sha256(content).hexdigest()

        # 2. Check for duplicates by HASH (Content deduplication)
        # If the same content exists (even with a different filename), we skip processing.
        existing_doc = self.document_repo.get_by_hash(company.id, file_hash, collection_id)
        if existing_doc:
            if existing_doc.status == DocumentStatus.FAILED:
                # If the previous ingestion failed, we delete the failed document and try again.
                self.delete_document(existing_doc.id)
            else:
                msg = self.i18n_service.t('rag.ingestion.duplicate', filename=filename, company_short_name=company.short_name)
                logging.info(msg)
                return existing_doc


        # 3. Storage creation record with PENDING status
        try:
            # Upload to Storage immediately instead of saving b64 to DB
            # Determine basic mime type for upload
            import mimetypes
            mime_type, _ = mimetypes.guess_type(filename)
            if not mime_type:
                mime_type = "application/octet-stream"

            storage_key = self.storage_service.upload_document(
                company_short_name=company.short_name,
                file_content=content,
                filename=filename,
                mime_type=mime_type
            )

            new_doc = Document(
                company_id=company.id,
                collection_type_id=collection_id,
                filename=filename,
                hash=file_hash,
                user_identifier=user_identifier,
                storage_key=storage_key,        # Reference to cloud storage
                meta=metadata,
                status=DocumentStatus.PENDING
            )

            self.document_repo.insert(new_doc)

            # 3. Start processing (Extraction + Vectorization)
            self._process_document_content(company, new_doc, content, collection_name=collection_name)

            return new_doc

        except Exception as e:
            logging.exception(f"Error initializing document ingestion for {filename}: {e}")
            error_msg = self.i18n_service.t('rag.ingestion.failed', error=str(e))

            raise IAToolkitException(IAToolkitException.ErrorType.LOAD_DOCUMENT_ERROR, error_msg)


    def _process_document_content(self,
                                  company: Company,
                                  document: Document,
                                  raw_content: bytes,
                                  collection_name: str | None = None):
        """
        Internal method to handle the heavy lifting of extraction and vectorization.
        Updates the document status directly via the session.
        """
        session = self.document_repo.session

        try:
            # A. Update status to PROCESSING
            document.status = DocumentStatus.PROCESSING
            session.commit()

            # B. Provider-based parsing (docling/basic/custom)
            parse_result = self.parsing_service.parse_document(
                company_short_name=company.short_name,
                filename=document.filename,
                content=raw_content,
                metadata=document.meta or {},
                collection_name=collection_name,
                collection_id=document.collection_type_id,
                document_id=document.id,
            )

            # Persist parser traceability
            doc_meta = dict(document.meta or {})
            doc_meta["parser_provider"] = parse_result.provider
            if parse_result.provider_version:
                doc_meta["parser_version"] = parse_result.provider_version
            if parse_result.warnings:
                doc_meta["parser_warnings"] = parse_result.warnings
            document.meta = self._strip_nul_chars(doc_meta)

            # C. Splitting & chunking
            vs_docs = []
            block_index = 0
            n_images = 0
            n_tables = 0

            text_docs, block_index = self._create_text_chunks(document, parse_result.texts, block_index)
            vs_docs.extend(text_docs)

            table_docs, block_index, n_tables = self._create_table_chunks(document, parse_result.tables, block_index)
            vs_docs.extend(table_docs)

            # E. Add chunks to vector storage
            if vs_docs:
                self.vs_repo.add_document(company.short_name, vs_docs)

            # F. Image ingestion
            n_images = self._ingest_parsed_images(company, document, parse_result.images)

            # G. Finalize
            document.status = DocumentStatus.ACTIVE
            session.commit()
            logging.info(f"Successfully ingested {document.description} with {len(vs_docs)} chunks, {n_images} images, {n_tables} tables.")

        except Exception as e:
            session.rollback()
            logging.error(f"Failed to process document {document.id}: {e}")

            # Attempt to save the error state
            try:
                session.add(document)
                document.status = DocumentStatus.FAILED
                document.error_message = str(e)
                session.commit()
            except:
                pass  # If error commit fails, we can't do much more

            error_msg = self.i18n_service.t('rag.ingestion.processing_failed', error=str(e))
            raise IAToolkitException(IAToolkitException.ErrorType.LOAD_DOCUMENT_ERROR, error_msg)

    def _create_text_chunks(self, document: Document, parsed_texts, start_block_index: int) -> tuple[List[VSDoc], int]:
        """Helper 1: Creates text chunks from parser result."""
        vs_docs = []
        block_index = start_block_index

        compacted_units = self._compact_text_units(parsed_texts)

        for unit in compacted_units:
            if not unit["text"]:
                continue
            chunks = self.text_splitter.split_text(unit["text"])
            for chunk_index, chunk_text in enumerate(chunks):
                chunk_text = self._strip_nul_chars(chunk_text)
                meta = {
                    "source_type": "text",
                    "block_index": block_index,
                    "chunk_index": chunk_index
                }
                if document.meta:
                    meta.update(document.meta)

                if unit["meta"]:
                    meta.update(unit["meta"])

                meta = self._strip_nul_chars(meta)
                vs_docs.append(VSDoc(
                    company_id=document.company_id,
                    document_id=document.id,
                    text=chunk_text,
                    meta=meta
                ))
            block_index += 1
        return vs_docs, block_index

    def _compact_text_units(self, parsed_texts) -> list[dict]:
        """
        Merges short adjacent text units before splitting to avoid tiny chunks.
        Also avoids emitting standalone title chunks by prefixing them to the next block.
        """
        compacted: list[dict] = []
        pending_title: Optional[str] = None
        current_text = ""
        current_meta: dict = {}

        def flush_current():
            nonlocal current_text, current_meta
            if current_text.strip():
                compacted.append({
                    "text": self._strip_nul_chars(current_text.strip()),
                    "meta": self._strip_nul_chars(dict(current_meta))
                })
            current_text = ""
            current_meta = {}

        for item in parsed_texts or []:
            text = self._strip_nul_chars((item.text or "").strip())
            if not text:
                continue

            item_meta = self._strip_nul_chars(dict(item.meta or {}))
            source_label = (item_meta.get("source_label") or "").lower()

            # Titles should enrich the next text instead of creating tiny standalone chunks.
            if source_label == "title" and len(text) <= self.min_chunk_chars:
                pending_title = f"{pending_title}\n{text}".strip() if pending_title else text
                continue

            if pending_title:
                text = f"{pending_title}\n\n{text}"
                item_meta.setdefault("section_title", pending_title.splitlines()[-1])
                item_meta["title_prefixed"] = True
                pending_title = None

            if not current_text:
                current_text = text
                current_meta = item_meta
                continue

            if self._should_merge_text_units(current_text, current_meta, text, item_meta):
                current_text = f"{current_text}\n\n{text}"
                current_meta = self._merge_text_meta(current_meta, item_meta)
            else:
                flush_current()
                current_text = text
                current_meta = item_meta

        if pending_title:
            if current_text:
                current_text = f"{current_text}\n\n{pending_title}"
            else:
                current_text = pending_title

        flush_current()
        return compacted

    def _should_merge_text_units(self, current_text: str, current_meta: dict, next_text: str, next_meta: dict) -> bool:
        current_len = len(current_text)
        next_len = len(next_text)
        merged_len = current_len + 2 + next_len

        if current_len >= self.merge_target_chars:
            return False

        current_section = (current_meta.get("section_title") or "").strip().lower()
        next_section = (next_meta.get("section_title") or "").strip().lower()
        if current_section and next_section and current_section != next_section:
            return False

        current_page_end = current_meta.get("page_end") or current_meta.get("page") or current_meta.get("page_start")
        next_page_start = next_meta.get("page_start") or next_meta.get("page")
        if isinstance(current_page_end, int) and isinstance(next_page_start, int):
            if abs(next_page_start - current_page_end) > 1:
                return False

        if merged_len <= self.merge_target_chars:
            return True

        if current_len < self.min_chunk_chars and merged_len <= (self.merge_target_chars + self.min_chunk_chars):
            return True

        return False

    @staticmethod
    def _merge_text_meta(current_meta: dict, next_meta: dict) -> dict:
        merged = dict(current_meta)

        next_page_start = next_meta.get("page_start") or next_meta.get("page")
        next_page_end = next_meta.get("page_end") or next_meta.get("page")
        if next_page_start is not None and merged.get("page_start") is None:
            merged["page_start"] = next_page_start
        if next_page_end is not None:
            merged["page_end"] = next_page_end

        if not merged.get("section_title") and next_meta.get("section_title"):
            merged["section_title"] = next_meta.get("section_title")

        labels = []
        for src in (merged.get("source_label"), next_meta.get("source_label")):
            if src and src not in labels:
                labels.append(src)
        if labels:
            merged["source_labels"] = labels

        return merged

    def _create_table_chunks(self, document: Document, parsed_tables, start_block_index: int) -> tuple[List[VSDoc], int, int]:
        """Helper 2: Creates chunks for parsed tables."""
        vs_docs = []
        block_index = start_block_index
        n_tables = 0

        for table_index, table in enumerate(parsed_tables, start=1):
            n_tables += 1

            # 1. Sanitize the JSON to remove heavy visual metadata (bbox, coords)
            clean_json = self._sanitize_table_data(table.table_json)
            clean_json = self._strip_nul_chars(clean_json)

            # 2. Use provider text, fallback to clean JSON string
            table_text = self._strip_nul_chars(table.text or json.dumps(clean_json, ensure_ascii=False))
            if not table_text:
                continue

            # 3. Serialize clean JSON for metadata
            table_json_str = self._strip_nul_chars(json.dumps(clean_json, ensure_ascii=False)) if clean_json else None

            # Every table in its own chunk
            meta = {
                "source_type": "table",
                "table_index": table_index,
                "table_json": table_json_str,
                "block_index": block_index,
            }
            if document.meta:
                meta.update(document.meta)

            if table.meta:
                meta.update(table.meta)

            meta = self._strip_nul_chars(meta)
            vs_docs.append(VSDoc(
                company_id=document.company_id,
                document_id=document.id,
                text=table_text,
                meta=meta
            ))
            block_index += 1

        return vs_docs, block_index, n_tables

    def _sanitize_table_data(self, data: Any) -> Any:
        """
        Recursively removes heavy visual metadata (bbox, coords) from table JSON.
        Reduces metadata size by ~80-90%.
        """
        keys_to_remove = {
            'bbox', 'coord_origin', 'start_row_offset_idx', 'end_row_offset_idx',
            'start_col_offset_idx', 'end_col_offset_idx', 'fillable', 'row_section'
        }

        if isinstance(data, dict):
            return {
                k: self._sanitize_table_data(v)
                for k, v in data.items()
                if k not in keys_to_remove
            }
        elif isinstance(data, list):
            return [self._sanitize_table_data(item) for item in data]
        else:
            return data

    def _ingest_parsed_images(self, company: Company, document: Document, parsed_images) -> int:
        """Helper 3: Ingests normalized images returned by a parsing provider."""
        n_images = 0
        for image in parsed_images:
            try:
                self.visual_kb_service.ingest_document_image_sync(
                    company=company,
                    parent_document=document,
                    filename=image.filename,
                    content=image.content,
                    page=(image.meta or {}).get("page"),
                    image_index=(image.meta or {}).get("image_index"),
                    metadata=image.meta or {}
                )
                n_images += 1
            except Exception as e:
                logging.warning(f"Failed to ingest image {image.filename}: {e}")
        return n_images


    def search(self,
               company_short_name: str,
               query: str,
               n_results: int = 5,
               collection: str | list[str] | None = None,
               metadata_filter: dict = None
               ):
        """
        Performs a semantic search and returns the list of Document objects (chunks).
        Useful for UI displays where structured data is needed instead of a raw string context.

        Args:
            company_short_name: The target company.
            query: The user's question or search term.
            n_results: Max number of chunks to retrieve.
            metadata_filter: Optional filter for document metadata.
            collection: Optional collection name or list of collection names.

        Returns:
            List of Document objects found.
        """
        company = self.profile_service.get_company_by_short_name(company_short_name)
        if not company:
            # We return empty list instead of error string for consistency
            logging.warning(f"Company {company_short_name} not found during raw search.")
            return []

        normalized_collection = self._normalize_search_collection(collection)
        collection_ids = None
        if isinstance(normalized_collection, str):
            collection_id = self.document_repo.get_collection_id_by_name(company.short_name, normalized_collection)
            if collection_id is None:
                return []
            collection_ids = [collection_id]
        elif isinstance(normalized_collection, list):
            collection_ids = self.document_repo.get_collection_ids_by_name(
                company.short_name,
                normalized_collection,
            )
            if not collection_ids:
                return []

        # Queries VSRepo directly
        chunk_list = self.vs_repo.query(
            company_short_name=company_short_name,
            query_text=query,
            n_results=n_results,
            metadata_filter=metadata_filter,
            collection_ids=collection_ids,
        )

        return chunk_list

    @staticmethod
    def _normalize_search_collection(collection: str | list[str] | None) -> str | list[str] | None:
        if collection is None:
            return None

        if isinstance(collection, str):
            normalized = collection.strip()
            return normalized or None

        if isinstance(collection, list):
            normalized_items = []
            for item in collection:
                if not isinstance(item, str):
                    continue
                normalized = item.strip()
                if normalized:
                    normalized_items.append(normalized)
            return normalized_items or None

        return None

    def _build_documents_query(self,
                               company_short_name: str,
                               status: Optional[Union[str, List[str]]] = None,
                               user_identifier: Optional[str] = None,
                               collection: str = None,
                               filename_keyword: Optional[str] = None,
                               from_date: Optional[datetime] = None,
                               to_date: Optional[datetime] = None,
                               metadata_key: Optional[str] = None,
                               metadata_value: Optional[str] = None,
                               metadata_match_mode: Optional[str] = None):
        session = self.document_repo.session
        query = session.query(Document).join(Company).filter(Company.short_name == company_short_name)

        if status:
            if isinstance(status, list):
                query = query.filter(Document.status.in_(status))
            else:
                query = query.filter(Document.status == status)

        if collection:
            query = query.join(Document.collection_type).filter(CollectionType.name == collection.lower())

        if user_identifier:
            query = query.filter(Document.user_identifier.ilike(f"%{user_identifier}%"))

        if filename_keyword:
            query = query.filter(Document.filename.ilike(f"%{filename_keyword}%"))

        if from_date:
            query = query.filter(Document.created_at >= from_date)

        if to_date:
            query = query.filter(Document.created_at <= to_date)

        normalized_metadata_key = str(metadata_key or "").strip()
        normalized_metadata_value = str(metadata_value or "").strip().lower()
        normalized_match_mode = str(metadata_match_mode or "contains").strip().lower()
        if normalized_metadata_key and normalized_metadata_value:
            meta_value_expr = func.lower(func.coalesce(Document.meta[normalized_metadata_key].as_string(), ""))
            if normalized_match_mode == "exact":
                query = query.filter(meta_value_expr == normalized_metadata_value)
            else:
                query = query.filter(meta_value_expr.like(f"%{normalized_metadata_value}%"))

        return query

    def list_documents(self,
                       company_short_name: str,
                       status: Optional[Union[str, List[str]]] = None,
                       user_identifier: Optional[str] = None,
                       collection: str = None,
                       filename_keyword: Optional[str] = None,
                       from_date: Optional[datetime] = None,
                       to_date: Optional[datetime] = None,
                       metadata_key: Optional[str] = None,
                       metadata_value: Optional[str] = None,
                       metadata_match_mode: Optional[str] = None,
                       limit: int = 100,
                       offset: int = 0) -> List[Document]:
        """
        Retrieves a paginated list of documents based on various filters.
        Used by the frontend to display the Knowledge Base grid.
        """
        query = self._build_documents_query(
            company_short_name=company_short_name,
            status=status,
            user_identifier=user_identifier,
            collection=collection,
            filename_keyword=filename_keyword,
            from_date=from_date,
            to_date=to_date,
            metadata_key=metadata_key,
            metadata_value=metadata_value,
            metadata_match_mode=metadata_match_mode,
        )
        query = query.order_by(desc(Document.created_at))
        query = query.limit(limit).offset(offset)
        return query.all()

    def count_documents(self,
                        company_short_name: str,
                        status: Optional[Union[str, List[str]]] = None,
                        user_identifier: Optional[str] = None,
                        collection: str = None,
                        filename_keyword: Optional[str] = None,
                        from_date: Optional[datetime] = None,
                        to_date: Optional[datetime] = None,
                        metadata_key: Optional[str] = None,
                        metadata_value: Optional[str] = None,
                        metadata_match_mode: Optional[str] = None) -> int:
        query = self._build_documents_query(
            company_short_name=company_short_name,
            status=status,
            user_identifier=user_identifier,
            collection=collection,
            filename_keyword=filename_keyword,
            from_date=from_date,
            to_date=to_date,
            metadata_key=metadata_key,
            metadata_value=metadata_value,
            metadata_match_mode=metadata_match_mode,
        )
        return int(query.order_by(None).count() or 0)

    def get_document_descriptor(
        self,
        company_short_name: str,
        document_id: int,
        collection_name: str | None = None,
    ) -> dict:
        """
        Resolves a document descriptor suitable for MCP/API download workflows.

        Validates tenant ownership and, when provided, that the document belongs
        to the requested collection.
        """
        if not company_short_name or not document_id:
            raise IAToolkitException(
                IAToolkitException.ErrorType.INVALID_PARAMETER,
                "company_short_name and document_id are required.",
            )

        document = self.document_repo.get_by_id(document_id)
        if not document:
            raise IAToolkitException(
                IAToolkitException.ErrorType.DOCUMENT_NOT_FOUND,
                f"Document '{document_id}' not found.",
            )

        document_company_short_name = str(getattr(getattr(document, "company", None), "short_name", "") or "").strip()
        if document_company_short_name != company_short_name:
            raise IAToolkitException(
                IAToolkitException.ErrorType.INVALID_OPERATION,
                f"Document '{document_id}' does not belong to company '{company_short_name}'.",
            )

        normalized_collection_name = str(collection_name or "").strip().lower() or None
        document_collection_name = str(
            getattr(getattr(document, "collection_type", None), "name", "") or ""
        ).strip().lower() or None
        if normalized_collection_name and document_collection_name != normalized_collection_name:
            raise IAToolkitException(
                IAToolkitException.ErrorType.INVALID_OPERATION,
                f"Document '{document_id}' does not belong to collection '{collection_name}'.",
            )

        mime_type, _ = mimetypes.guess_type(str(document.filename or "").strip())
        download_url = None
        content_available = bool(document.storage_key)
        if content_available:
            download_url = self.storage_service.generate_presigned_url(
                company_short_name,
                document.storage_key,
            )

        return {
            "document_id": document.id,
            "company_short_name": company_short_name,
            "collection_name": document_collection_name,
            "filename": document.filename,
            "mime_type": mime_type or "application/octet-stream",
            "storage_key": document.storage_key,
            "download_url": download_url,
            "content_available": content_available,
            "status": document.status.value if hasattr(document.status, "value") else str(document.status),
            "metadata": document.meta or {},
            "created_at": document.created_at.isoformat() if document.created_at else None,
        }

    def get_document_content(self, document_id: int) -> tuple[bytes, str]:
        """
        Retrieves the raw content of a document and its filename.

        Args:
            document_id: ID of the document.

        Returns:
            A tuple containing (file_bytes, filename).
            Returns (None, None) if document not found.
        """
        doc = self.document_repo.get_by_id(document_id)
        if not doc:
            return None, None

        try:
            # Try to fetch from Cloud Storage
            if doc.storage_key:
                file_bytes = self.storage_service.get_document_content(doc.company.short_name, doc.storage_key)
                return file_bytes, doc.filename

        except Exception as e:
            logging.error(f"Error decoding content for document {document_id}: {e}")
            raise IAToolkitException(IAToolkitException.ErrorType.FILE_FORMAT_ERROR,
                        f"Error reading file content: {e}")

    def delete_document(self, document_id: int) -> bool:
        """
        Deletes a document and its associated vectors.
        Since vectors are linked via FK with ON DELETE CASCADE, deleting the Document record is sufficient.
        Also attempts to delete the physical file from Cloud Storage if it exists.

        Args:
            document_id: The ID of the document to delete.

        Returns:
            True if deleted, False if not found.
        """
        doc = self.document_repo.get_by_id(document_id)
        if not doc:
            return False

        session = self.document_repo.session
        try:
            # 1. Delete from Cloud Storage
            # We do this before DB commit. If it fails, we might still want to delete the DB record
            # or rollback. Here I choose to log and proceed, to avoid DB inconsistencies if S3 is down.
            if doc.storage_key:
                try:
                    self.storage_service.delete_file(doc.company.short_name, doc.storage_key)
                except Exception as e:
                    logging.error(f"Failed to delete file from storage for doc {doc.id}: {e}")
                    # We proceed to delete from DB to avoid "ghost" documents in UI

            # 2. delete from database
            session.delete(doc)
            session.commit()
            return True
        except Exception as e:
            session.rollback()
            logging.error(f"Error deleting document {document_id}: {e}")
            raise IAToolkitException(IAToolkitException.ErrorType.DATABASE_ERROR,
                                     f"Error deleting document: {e}")

    def sync_collection_types(self, company_short_name: str, categories_config: list):
        """
        This should be called during company initialization or configuration reload.
        Syncs DB collection types with the provided list.
        Also updates the configuration YAML.
        """
        company = self.profile_service.get_company_by_short_name(company_short_name)
        if not company:
            raise IAToolkitException(IAToolkitException.ErrorType.INVALID_NAME,
                                     f'Company {company_short_name} not found')

        session = self.document_repo.session

        # 1. Get existing types
        existing_types = session.query(CollectionType).filter_by(company_id=company.id).all()
        existing_names = {ct.name.lower(): ct for ct in existing_types}

        # 2. Add new types
        normalized_entries = self._normalize_collection_config_entries(categories_config)
        for entry in normalized_entries:
            cat_name = entry["name"]
            parser_provider = entry["parser_provider"]
            description = entry["description"]
            if cat_name not in existing_names:
                new_type = CollectionType(
                    company_id=company.id,
                    name=cat_name,
                    parser_provider=parser_provider,
                    description=description,
                )
                session.add(new_type)
            else:
                existing = existing_names[cat_name]
                if entry.get("parser_provider_provided"):
                    existing.parser_provider = parser_provider
                if entry.get("description_provided"):
                    existing.description = description

        session.commit()

    @staticmethod
    def _normalize_collection_config_entries(categories_config: list) -> list[dict]:
        """
        Accepts legacy list[str] and new list[dict{name, parser_provider, description,...}].
        Returns normalized entries:
            [{"name": "contracts", "parser_provider": "docling"|None, "description": "..."|None}, ...]
        """
        normalized: list[dict] = []
        seen_names = set()

        for item in categories_config or []:
            name = None
            parser_provider = None
            description = None
            parser_provider_provided = False
            description_provided = False

            if isinstance(item, str):
                name = item.strip().lower()
            elif isinstance(item, dict):
                raw_name = item.get("name")
                if isinstance(raw_name, str):
                    name = raw_name.strip().lower()
                if "parser_provider" in item:
                    parser_provider_provided = True
                    raw_provider = item.get("parser_provider")
                    if isinstance(raw_provider, str) and raw_provider.strip():
                        parser_provider = raw_provider.strip().lower()
                if "description" in item:
                    description_provided = True
                    raw_description = item.get("description")
                    if isinstance(raw_description, str):
                        description = raw_description.strip() or None
            else:
                continue

            if not name or name in seen_names:
                continue

            normalized.append({
                "name": name,
                "parser_provider": parser_provider,
                "description": description,
                "parser_provider_provided": parser_provider_provided,
                "description_provided": description_provided,
            })
            seen_names.add(name)

        return normalized


    def get_collection_descriptors(self, company_short_name: str) -> List[dict]:
        """
        Retrieves collection descriptors for a specific company.
        Returns entries with name, description and parser provider.
        """
        company = self.profile_service.get_company_by_short_name(company_short_name)
        if not company:
            logging.warning(f"Company {company_short_name} not found when listing collection descriptors.")
            return []

        session = self.document_repo.session
        collections = session.query(CollectionType).filter_by(company_id=company.id).all()
        return [
            {
                "name": c.name,
                "description": c.description,
                "parser_provider": c.parser_provider,
            }
            for c in collections
        ]


    def get_collection_names(self, company_short_name: str) -> List[str]:
        """
        Retrieves the names of all collections defined for a specific company.
        """
        return [entry["name"] for entry in self.get_collection_descriptors(company_short_name)]
