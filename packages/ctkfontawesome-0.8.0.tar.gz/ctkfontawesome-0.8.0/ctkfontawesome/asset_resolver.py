"""Helpers for reading packaged Font Awesome fonts and metadata."""

# Author: Clive Bostock
# Date: 2026-04-18
# Description: Resolve bundled Font Awesome assets from installed package resources.

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from importlib import resources
from typing import Any, Optional


FONT_PACKAGE = "ctkfontawesome.assets.fonts"
METADATA_PACKAGE = "ctkfontawesome.assets.metadata"
STYLE_ORDER = ("solid", "regular", "brands")
FONT_FILES = {
    "solid": "fa-solid-900.otf",
    "regular": "fa-regular-400.otf",
    "brands": "fa-brands-400.otf",
}


@dataclass(frozen=True)
class IconFontSpec:
    """Resolved font render specification for a single icon."""

    name: str
    style: str
    glyph: str
    width: int
    height: int


@lru_cache(maxsize=1)
def load_icon_families() -> dict[str, Any]:
    """Load bundled Font Awesome metadata.

    Returns:
        dict[str, Any]: Parsed icon metadata from the bundled JSON file.
    """
    payload = resources.read_text(METADATA_PACKAGE, "icon-families.json", encoding="utf-8")
    icon_families = json.loads(payload)
    if not isinstance(icon_families, dict):
        raise ValueError("Bundled icon metadata must be a JSON object.")
    return icon_families


@lru_cache(maxsize=None)
def load_font_bytes(style: str) -> bytes:
    """Return bundled font bytes for the requested style.

    Args:
        style: Font Awesome style name.

    Returns:
        bytes: Raw OpenType font bytes.
    """
    resolved_style = _normalise_style_name(style)
    return resources.read_binary(FONT_PACKAGE, FONT_FILES[resolved_style])


def resolve_icon_font_spec(name: str, style: Optional[str] = None) -> IconFontSpec:
    """Resolve the bundled font, glyph, and dimensions for an icon.

    Args:
        name: Canonical Font Awesome icon name.
        style: Optional style override.

    Returns:
        IconFontSpec: Resolved render specification.

    Raises:
        ValueError: If the icon or requested style is not available.
    """
    icon_data = load_icon_families().get(name)
    if not isinstance(icon_data, dict):
        raise ValueError(
            f"'{name}' is not a valid icon name. "
            "Check spelling or visit https://fontawesome.com/icons."
        )

    available_styles = _available_free_styles(icon_data)
    if not available_styles:
        raise ValueError(f"No bundled free font style is available for icon '{name}'.")

    resolved_style = _select_style(name, available_styles, style)
    svg_data = icon_data.get("svgs", {}).get("classic", {}).get(resolved_style)
    if not isinstance(svg_data, dict):
        raise ValueError(
            f"Bundled metadata for icon '{name}' is missing the '{resolved_style}' style."
        )

    unicode_value = icon_data.get("unicode")
    if not isinstance(unicode_value, str) or not unicode_value:
        raise ValueError(f"Bundled metadata for icon '{name}' is missing a unicode value.")

    width = int(svg_data.get("width", 512))
    height = int(svg_data.get("height", 512))
    return IconFontSpec(
        name=name,
        style=resolved_style,
        glyph=chr(int(unicode_value, 16)),
        width=width,
        height=height,
    )


def _available_free_styles(icon_data: dict[str, Any]) -> tuple[str, ...]:
    """Return free classic styles available for an icon."""
    free_styles = icon_data.get("familyStylesByLicense", {}).get("free", ())
    styles = []
    for style_data in free_styles:
        if not isinstance(style_data, dict):
            continue
        family_name = style_data.get("family")
        style_name = style_data.get("style")
        if family_name == "classic" and style_name in FONT_FILES and style_name not in styles:
            styles.append(style_name)
    return tuple(styles)


def _select_style(
    name: str,
    available_styles: tuple[str, ...],
    style: Optional[str],
) -> str:
    """Resolve a requested style against the available bundled styles."""
    if style is not None:
        requested_style = _normalise_style_name(style)
        if requested_style not in available_styles:
            available_text = ", ".join(available_styles)
            raise ValueError(
                f"Icon '{name}' does not provide the '{requested_style}' style. "
                f"Available bundled styles: {available_text}."
            )
        return requested_style

    for preferred_style in STYLE_ORDER:
        if preferred_style in available_styles:
            return preferred_style

    return available_styles[0]


def _normalise_style_name(style: str) -> str:
    """Normalise a user-supplied Font Awesome style name."""
    resolved_style = style.strip().lower()
    if resolved_style.startswith("fa-"):
        resolved_style = resolved_style[3:]
    if resolved_style not in FONT_FILES:
        allowed_styles = ", ".join(STYLE_ORDER)
        raise ValueError(
            f"Unsupported style {style!r}. Expected one of: {allowed_styles}."
        )
    return resolved_style
