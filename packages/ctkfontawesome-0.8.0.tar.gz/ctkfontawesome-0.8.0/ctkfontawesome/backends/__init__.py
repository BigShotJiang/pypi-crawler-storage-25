"""Rendering backends for CTkFontAwesome."""

# Author: Clive Bostock
# Date: 2026-04-18
# Description: Expose backend modules for icon rendering.
