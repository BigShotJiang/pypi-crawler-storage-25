"""Render bundled Font Awesome glyphs with Pillow and packaged fonts."""

# Author: Clive Bostock
# Date: 2026-04-18
# Description: Implement the default Pillow font rendering backend.

from __future__ import annotations

from io import BytesIO
from functools import lru_cache
from typing import Optional

from ctkfontawesome.asset_resolver import IconFontSpec, load_font_bytes


_BASE_FONT_SIZE = 1024


def render_icon(
    icon: IconFontSpec,
    fill: Optional[str] = None,
    scale_to_width: Optional[int] = None,
    scale_to_height: Optional[int] = None,
    scale: float = 1,
):
    """Render an icon spec to a transparent RGBA Pillow image.

    Args:
        icon: Resolved icon font specification.
        fill: Optional icon colour.
        scale_to_width: Target width in pixels.
        scale_to_height: Target height in pixels.
        scale: Scaling factor used when no explicit target size is supplied.

    Returns:
        PIL.Image.Image: Rendered RGBA image.

    Raises:
        RuntimeError: If Pillow is unavailable.
    """
    try:
        from PIL import Image, ImageDraw
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "The default Pillow backend requires Pillow. "
            "Install it with `pip install Pillow`."
        ) from exc

    output_width, output_height = _resolve_output_size(
        icon,
        scale_to_width=scale_to_width,
        scale_to_height=scale_to_height,
        scale=scale,
    )
    font = _best_fit_font(icon, output_width, output_height)

    image = Image.new("RGBA", (output_width, output_height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    left, top, right, bottom = draw.textbbox((0, 0), icon.glyph, font=font)
    glyph_width = max(right - left, 1)
    glyph_height = max(bottom - top, 1)
    x_pos = (output_width - glyph_width) / 2 - left
    y_pos = (output_height - glyph_height) / 2 - top
    draw.text((x_pos, y_pos), icon.glyph, font=font, fill=fill or "#000000")
    return image


def _resolve_output_size(
    icon: IconFontSpec,
    scale_to_width: Optional[int],
    scale_to_height: Optional[int],
    scale: float,
) -> tuple[int, int]:
    """Resolve the requested output size for an icon render."""
    if scale_to_width and scale_to_height:
        return int(scale_to_width), int(scale_to_height)

    if scale_to_width:
        output_height = int(round((icon.height / icon.width) * scale_to_width))
        return int(scale_to_width), output_height

    if scale_to_height:
        output_width = int(round((icon.width / icon.height) * scale_to_height))
        return output_width, int(scale_to_height)

    if scale != 1:
        return (
            max(int(round(icon.width * scale)), 1),
            max(int(round(icon.height * scale)), 1),
        )

    return max(icon.width, 1), max(icon.height, 1)


def _best_fit_font(icon: IconFontSpec, output_width: int, output_height: int):
    """Return a font sized to fit the requested output area."""
    try:
        from PIL import Image, ImageDraw
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "The default Pillow backend requires Pillow. "
            "Install it with `pip install Pillow`."
        ) from exc

    probe_image = Image.new("RGBA", (max(output_width, 1), max(output_height, 1)), (0, 0, 0, 0))
    probe_draw = ImageDraw.Draw(probe_image)
    base_font = _load_font(icon.style, _BASE_FONT_SIZE)
    left, top, right, bottom = probe_draw.textbbox((0, 0), icon.glyph, font=base_font)
    glyph_width = max(right - left, 1)
    glyph_height = max(bottom - top, 1)
    scale_factor = min(output_width / glyph_width, output_height / glyph_height)
    font_size = max(int(_BASE_FONT_SIZE * scale_factor), 1)
    return _load_font(icon.style, font_size)


@lru_cache(maxsize=None)
def _load_font(style: str, font_size: int):
    """Load a packaged font at a specific point size."""
    try:
        from PIL import ImageFont
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "The default Pillow backend requires Pillow. "
            "Install it with `pip install Pillow`."
        ) from exc

    font_bytes = load_font_bytes(style)
    return ImageFont.truetype(BytesIO(font_bytes), size=font_size)
