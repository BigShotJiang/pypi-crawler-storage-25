"""Tk-based browser for searching and previewing bundled Font Awesome icons."""

# Author: Clive Bostock
# Date: 2026-04-09
# Description: Provide a desktop browser for browsing, previewing, and copying icon snippets.

import tkinter as tk
from tkinter import colorchooser
from tkinter import ttk

import ctkfontawesome


OCEANIX_THEME = {
    "CTk": {"fg_color": ["#3b5068", "#3e5365"]},
    "CTkToplevel": {"fg_color": ["#4c6179", "#29404c"]},
    "CTkFrame": {
        "fg_color": ["#51667e", "#213844"],
        "top_fg_color": ["#3b5068", "#263d49"],
        "border_color": ["#5c7998", "#456582"],
    },
    "CTkButton": {
        "fg_color": ["#244461", "#0b2539"],
        "hover_color": ["#375774", "#142e42"],
        "border_color": ["#51667e", "#577584"],
        "text_color": ["#ffffff", "#ffffff"],
    },
    "CTkLabel": {"text_color": ["#ffffff", "#ffffff"]},
    "CTkEntry": {
        "fg_color": ["#375774", "#173145"],
        "border_color": ["#5c7998", "#3f5d6c"],
        "text_color": ["#ffffff", "#ffffff"],
        "placeholder_text_color": ["#718ead", "#7cb3d4"],
    },
    "CTkComboBox": {
        "fg_color": ["#375774", "#173145"],
        "border_color": ["#5c7998", "#3f5d6c"],
        "button_color": ["#263c5f", "#42606f"],
        "button_hover_color": ["#172d50", "#395766"],
        "text_color": ["#ffffff", "#ffffff"],
    },
    "CTkScrollbar": {
        "button_color": ["#173145", "#456582"],
        "button_hover_color": ["#2e4c68", "#22333f"],
    },
    "CTkTextbox": {
        "fg_color": ["#375774", "#173145"],
        "border_color": ["#5c7998", "#3f5d6c"],
        "text_color": ["#ffffff", "#ffffff"],
    },
}


class IconBrowser(tk.Tk):
    """Desktop browser for searching and previewing bundled icons."""

    def __init__(self):
        super().__init__()
        self.title("CTkFontAwesome Browser")
        self.geometry("980x640")
        self.minsize(840, 520)

        self.all_icons = ctkfontawesome.icon_names()
        self.all_categories = ctkfontawesome.category_names()
        self.filtered_icons = self.all_icons[:]
        self.current_image = None

        self.style = ttk.Style(self)
        self.dark_mode_var = tk.BooleanVar(value=True)
        self.search_var = tk.StringVar()
        self.category_var = tk.StringVar(value="All categories")
        self.fill_var = tk.StringVar()
        self.size_var = tk.IntVar(value=50)
        self.status_var = tk.StringVar()
        self.selected_name_var = tk.StringVar(value="Select an icon")
        self.default_fill = None

        self._build_ui()
        self._apply_theme()
        self._populate_list()
        if self.filtered_icons:
            self.listbox.selection_set(0)
            self._on_selection(None)

    def _build_ui(self):
        self.columnconfigure(0, weight=0)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        left = ttk.Frame(self, padding=12, style="Oceanix.Panel.TFrame")
        left.grid(row=0, column=0, sticky="nsew")
        left.rowconfigure(5, weight=1)

        ttk.Label(left, text="Category", style="Oceanix.Panel.TLabel").grid(row=0, column=0, sticky="w")
        category_values = ["All categories", *self.all_categories]
        category_combo = ttk.Combobox(
            left,
            textvariable=self.category_var,
            values=category_values,
            state="readonly",
            width=30,
            style="Oceanix.TCombobox",
        )
        category_combo.grid(row=1, column=0, sticky="ew", pady=(4, 10))
        category_combo.bind("<<ComboboxSelected>>", self._on_search)

        ttk.Label(left, text="Search", style="Oceanix.Panel.TLabel").grid(row=2, column=0, sticky="w")
        search_entry = ttk.Entry(left, textvariable=self.search_var, width=32, style="Oceanix.TEntry")
        search_entry.grid(row=3, column=0, sticky="ew", pady=(4, 12))
        search_entry.bind("<KeyRelease>", self._on_search)

        self.count_label = ttk.Label(left, text="", style="Oceanix.Panel.TLabel")
        self.count_label.grid(row=4, column=0, sticky="sw", pady=(0, 4))

        list_frame = ttk.Frame(left, style="Oceanix.TFrame")
        list_frame.grid(row=5, column=0, sticky="nsew")
        list_frame.rowconfigure(0, weight=1)
        list_frame.columnconfigure(0, weight=1)

        self.listbox = tk.Listbox(list_frame, exportselection=False, width=34)
        self.listbox.grid(row=0, column=0, sticky="nsew")
        self.listbox.bind("<<ListboxSelect>>", self._on_selection)

        scrollbar = ttk.Scrollbar(
            list_frame,
            orient="vertical",
            command=self.listbox.yview,
            style="Oceanix.Vertical.TScrollbar",
        )
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.listbox.configure(yscrollcommand=scrollbar.set)

        right = ttk.Frame(self, padding=12, style="Oceanix.Panel.TFrame")
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(3, weight=1)

        header = ttk.Frame(right, style="Oceanix.TFrame")
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)

        ttk.Label(header, textvariable=self.selected_name_var, style="Oceanix.Header.TLabel").grid(
            row=0, column=0, sticky="w"
        )

        mode_toggle = ttk.Checkbutton(
            header,
            text="Dark mode",
            variable=self.dark_mode_var,
            command=self._apply_theme,
            style="Oceanix.Switch.TCheckbutton",
        )
        mode_toggle.grid(row=0, column=1, sticky="e")

        controls = ttk.Frame(right, style="Oceanix.TFrame")
        controls.grid(row=1, column=0, sticky="ew", pady=(12, 12))
        controls.columnconfigure(6, weight=1)

        ttk.Label(controls, text="Fill", style="Oceanix.TLabel").grid(row=0, column=0, sticky="w")
        fill_entry = ttk.Entry(controls, textvariable=self.fill_var, width=12, style="Oceanix.TEntry")
        fill_entry.grid(row=0, column=1, sticky="w", padx=(6, 8))
        fill_entry.bind("<Return>", self._refresh_preview)

        ttk.Button(controls, text="Pick...", command=self._pick_fill_color, style="Oceanix.TButton").grid(
            row=0, column=2, sticky="w", padx=(0, 16)
        )

        ttk.Label(controls, text="Size", style="Oceanix.TLabel").grid(row=0, column=3, sticky="w")
        self.size_spin = tk.Spinbox(
            controls,
            from_=16,
            to=256,
            increment=8,
            textvariable=self.size_var,
            width=6,
            command=self._refresh_preview,
        )
        self.size_spin.grid(row=0, column=4, sticky="w", padx=(6, 16))
        self.size_spin.bind("<Return>", self._refresh_preview)

        ttk.Button(controls, text="Refresh", command=self._refresh_preview, style="Oceanix.TButton").grid(
            row=0, column=5, sticky="w", padx=(0, 16)
        )
        ttk.Button(controls, text="Copy Name", command=self._copy_name, style="Oceanix.TButton").grid(
            row=0, column=6, sticky="w"
        )
        ttk.Button(controls, text="Copy Code", command=self._copy_code, style="Oceanix.TButton").grid(
            row=0, column=7, sticky="w", padx=(8, 0)
        )

        self.preview_frame = ttk.LabelFrame(right, text="Preview", padding=16, style="Oceanix.TLabelframe")
        self.preview_frame.grid(row=2, column=0, sticky="nsew")
        self.preview_frame.columnconfigure(0, weight=1)
        self.preview_frame.rowconfigure(0, weight=1)

        self.preview_label = ttk.Label(self.preview_frame, anchor="center", justify="center", style="Oceanix.TLabel")
        self.preview_label.grid(row=0, column=0, sticky="nsew")

        details = ttk.LabelFrame(
            right,
            text="CustomTkinter Snippet",
            padding=12,
            style="Oceanix.TLabelframe",
        )
        details.grid(row=3, column=0, sticky="nsew", pady=(12, 0))
        details.columnconfigure(0, weight=1)
        details.rowconfigure(0, weight=1)

        self.code_text = tk.Text(details, wrap="none", height=14)
        self.code_text.grid(row=0, column=0, sticky="nsew")
        self.code_text.configure(state="disabled")

        details_scroll = ttk.Scrollbar(
            details,
            orient="vertical",
            command=self.code_text.yview,
            style="Oceanix.Vertical.TScrollbar",
        )
        details_scroll.grid(row=0, column=1, sticky="ns")
        self.code_text.configure(yscrollcommand=details_scroll.set)

        status = ttk.Label(
            self,
            textvariable=self.status_var,
            anchor="w",
            padding=(12, 0, 12, 10),
            style="Oceanix.Root.TLabel",
        )
        status.grid(row=1, column=0, columnspan=2, sticky="ew")

    def _mode_index(self):
        return 1 if self.dark_mode_var.get() else 0

    def _theme_color(self, widget_name, color_name):
        return OCEANIX_THEME[widget_name][color_name][self._mode_index()]

    def _resolve_fill_color(self):
        fill = self.fill_var.get().strip()
        return fill or self.default_fill

    def _pick_fill_color(self):
        initial_color = self._resolve_fill_color()
        _rgb, hex_color = colorchooser.askcolor(
            color=initial_color,
            title="Choose icon fill color",
            parent=self,
        )
        if not hex_color:
            return
        self.fill_var.set(hex_color)
        self._refresh_preview()

    def _apply_theme(self):
        root_background = self._theme_color("CTkToplevel", "fg_color")
        panel_background = self._theme_color("CTkFrame", "fg_color")
        top_panel_background = self._theme_color("CTkFrame", "top_fg_color")
        border_color = self._theme_color("CTkFrame", "border_color")
        button_background = self._theme_color("CTkButton", "fg_color")
        button_hover = self._theme_color("CTkButton", "hover_color")
        button_text = self._theme_color("CTkButton", "text_color")
        text_color = self._theme_color("CTkLabel", "text_color")
        entry_background = self._theme_color("CTkEntry", "fg_color")
        entry_border = self._theme_color("CTkEntry", "border_color")
        combo_background = self._theme_color("CTkComboBox", "fg_color")
        combo_button = self._theme_color("CTkComboBox", "button_color")
        combo_hover = self._theme_color("CTkComboBox", "button_hover_color")
        scrollbar_background = self._theme_color("CTkScrollbar", "button_color")
        scrollbar_hover = self._theme_color("CTkScrollbar", "button_hover_color")
        text_area_background = self._theme_color("CTkTextbox", "fg_color")
        previous_default_fill = self.default_fill
        self.default_fill = self._theme_color("CTkLabel", "text_color")
        current_fill = self.fill_var.get().strip()
        if not current_fill or current_fill == previous_default_fill:
            self.fill_var.set(self.default_fill)
        list_select = button_background

        self.configure(bg=root_background)
        self.style.theme_use("clam")
        self.style.configure("Oceanix.TFrame", background=panel_background)
        self.style.configure("Oceanix.Panel.TFrame", background=top_panel_background)
        self.style.configure("Oceanix.Root.TLabel", background=root_background, foreground=text_color)
        self.style.configure("Oceanix.TLabel", background=panel_background, foreground=text_color)
        self.style.configure("Oceanix.Panel.TLabel", background=top_panel_background, foreground=text_color)
        self.style.configure(
            "Oceanix.Header.TLabel",
            background=panel_background,
            foreground=text_color,
            font=("", 16, "bold"),
        )
        self.style.configure(
            "Oceanix.TButton",
            background=button_background,
            foreground=button_text,
            bordercolor=border_color,
            lightcolor=border_color,
            darkcolor=border_color,
            focuscolor=button_hover,
            relief="flat",
            padding=(10, 6),
        )
        self.style.map(
            "Oceanix.TButton",
            background=[("active", button_hover)],
            foreground=[("disabled", button_text), ("active", button_text)],
        )
        self.style.configure(
            "Oceanix.TEntry",
            fieldbackground=entry_background,
            foreground=text_color,
            bordercolor=entry_border,
            lightcolor=entry_border,
            darkcolor=entry_border,
            insertcolor=text_color,
            padding=6,
        )
        self.style.configure(
            "Oceanix.TCombobox",
            fieldbackground=combo_background,
            background=combo_button,
            foreground=text_color,
            bordercolor=entry_border,
            lightcolor=entry_border,
            darkcolor=entry_border,
            arrowcolor=text_color,
            padding=6,
        )
        self.style.map(
            "Oceanix.TCombobox",
            fieldbackground=[("readonly", combo_background)],
            background=[("readonly", combo_button), ("active", combo_hover)],
            foreground=[("readonly", text_color)],
            arrowcolor=[("readonly", text_color)],
        )
        self.style.configure(
            "Oceanix.TLabelframe",
            background=panel_background,
            bordercolor=border_color,
            lightcolor=border_color,
            darkcolor=border_color,
            relief="flat",
        )
        self.style.configure(
            "Oceanix.TLabelframe.Label",
            background=panel_background,
            foreground=text_color,
        )
        self.style.configure(
            "Oceanix.Switch.TCheckbutton",
            background=panel_background,
            foreground=text_color,
            indicatorcolor=button_background,
            indicatordiameter=14,
            indicatormargin=2,
            padding=(6, 4),
        )
        self.style.map(
            "Oceanix.Switch.TCheckbutton",
            background=[("active", panel_background)],
            foreground=[("selected", text_color), ("!selected", text_color)],
            indicatorcolor=[("selected", button_background), ("!selected", combo_button)],
        )
        self.style.configure(
            "Oceanix.Vertical.TScrollbar",
            background=scrollbar_background,
            troughcolor=panel_background,
            bordercolor=panel_background,
            arrowcolor=text_color,
            lightcolor=scrollbar_background,
            darkcolor=scrollbar_background,
        )
        self.style.map(
            "Oceanix.Vertical.TScrollbar",
            background=[("active", scrollbar_hover)],
            arrowcolor=[("active", text_color)],
        )

        self.option_add("*TCombobox*Listbox.background", combo_background)
        self.option_add("*TCombobox*Listbox.foreground", text_color)
        self.option_add("*TCombobox*Listbox.selectBackground", list_select)
        self.option_add("*TCombobox*Listbox.selectForeground", text_color)

        self.listbox.configure(
            bg=text_area_background,
            fg=text_color,
            selectbackground=list_select,
            selectforeground=text_color,
            highlightbackground=entry_border,
            highlightcolor=entry_border,
        )
        self.code_text.configure(
            bg=text_area_background,
            fg=text_color,
            insertbackground=text_color,
            highlightbackground=entry_border,
            highlightcolor=entry_border,
            relief="flat",
        )
        self.size_spin.configure(
            bg=entry_background,
            fg=text_color,
            buttonbackground=combo_button,
            highlightbackground=entry_border,
            highlightcolor=entry_border,
            insertbackground=text_color,
            relief="flat",
        )

    def _populate_list(self):
        self.listbox.delete(0, tk.END)
        for name in self.filtered_icons:
            self.listbox.insert(tk.END, name)
        self.count_label.configure(text=f"{len(self.filtered_icons)} icons")

    def _apply_filters(self):
        term = self.search_var.get().strip().lower()
        selected_category = self.category_var.get()

        if selected_category == "All categories":
            category_icons = self.all_icons
        else:
            category_icons = ctkfontawesome.icons_in_category(selected_category)

        if term:
            self.filtered_icons = [name for name in category_icons if term in name.lower()]
        else:
            self.filtered_icons = list(category_icons)

    def _on_search(self, _event=None):
        self._apply_filters()
        self._populate_list()
        if self.filtered_icons:
            self.listbox.selection_clear(0, tk.END)
            self.listbox.selection_set(0)
            self.listbox.activate(0)
            self.listbox.see(0)
            self._on_selection(None)
        else:
            self.selected_name_var.set("No matches")
            self._set_code_text("")
            self.preview_label.configure(image="", text="")
            self.status_var.set("No icons match the current search and category filters.")

    def _on_selection(self, _event):
        selection = self.listbox.curselection()
        if not selection:
            return
        name = self.filtered_icons[selection[0]]
        self.selected_name_var.set(name)
        self._render_preview(name)

    def _refresh_preview(self, _event=None):
        selection = self.listbox.curselection()
        if not selection:
            return
        self._render_preview(self.filtered_icons[selection[0]])

    def _render_preview(self, name):
        self._set_code_text(self._build_code_snippet(name))

        try:
            image = ctkfontawesome.icon_to_image(
                name,
                fill=self._resolve_fill_color(),
                scale_to_width=self.size_var.get(),
            )
        except Exception as exc:
            self.current_image = None
            self.preview_label.configure(
                image="",
                text="Image preview unavailable\n\n"
                "Install optional dependencies:\n"
                "pip install 'ctkfontawesome[images]'",
            )
            self.status_var.set(f"{type(exc).__name__}: {exc}")
            return

        self.current_image = image
        self.preview_label.configure(image=image, text="")
        self.status_var.set(f"Previewing '{name}' at {self.size_var.get()}px.")

    def _set_code_text(self, value):
        self.code_text.configure(state="normal")
        self.code_text.delete("1.0", tk.END)
        self.code_text.insert("1.0", value)
        self.code_text.configure(state="disabled")

    def _copy_name(self):
        selection = self.listbox.curselection()
        if not selection:
            return
        name = self.filtered_icons[selection[0]]
        self.clipboard_clear()
        self.clipboard_append(name)
        self.status_var.set(f"Copied icon name '{name}'.")

    def _copy_code(self):
        selection = self.listbox.curselection()
        if not selection:
            return
        name = self.filtered_icons[selection[0]]
        self.clipboard_clear()
        self.clipboard_append(self._build_code_snippet(name))
        self.status_var.set(f"Copied CustomTkinter snippet for '{name}'.")

    def _build_code_snippet(self, name):
        fill = self._resolve_fill_color()
        size = self.size_var.get()
        return (
            "import customtkinter as ctk\n"
            "from ctkfontawesome import icon_to_image\n\n"
            "app = ctk.CTk()\n\n"
            f"icon = icon_to_image(\"{name}\", fill=\"{fill}\", scale_to_width={size})\n"
            "button = ctk.CTkButton(\n"
            "    app,\n"
            "    text=\"\",\n"
            "    image=icon,\n"
            "    width=44,\n"
            "    height=44,\n"
            ")\n"
            "button.pack(padx=20, pady=20)\n\n"
            "app.mainloop()\n"
        )



def main():
    """Launch the icon browser application."""
    app = IconBrowser()
    app.mainloop()


if __name__ == "__main__":
    main()
