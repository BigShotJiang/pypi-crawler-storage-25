"""Bundled Font Awesome font resources."""

# Author: Clive Bostock
# Date: 2026-04-18
# Description: Mark bundled font files as importable package resources.
