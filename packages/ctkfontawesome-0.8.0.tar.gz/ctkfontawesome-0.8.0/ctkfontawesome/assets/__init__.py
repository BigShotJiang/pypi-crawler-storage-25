"""Packaged Font Awesome asset bundles."""

# Author: Clive Bostock
# Date: 2026-04-18
# Description: Mark packaged Font Awesome assets as importable resources.
