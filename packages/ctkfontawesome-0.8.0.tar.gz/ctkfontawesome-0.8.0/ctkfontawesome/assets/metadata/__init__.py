"""Bundled Font Awesome metadata resources."""

# Author: Clive Bostock
# Date: 2026-04-18
# Description: Mark bundled metadata files as importable package resources.
