"""Public API for bundled Font Awesome icon lookup and rendering."""

# Author: Clive Bostock
# Date: 2026-04-18
# Description: Expose bundled Font Awesome lookup helpers and rendering backends.

from __future__ import annotations

import io
from typing import Optional
from xml.etree import ElementTree as etree

from ctkfontawesome.asset_resolver import resolve_icon_font_spec
from ctkfontawesome.backends.pillow_font import render_icon
from ctkfontawesome.svgs import FA, FA_aliases, FA_categories

__version__ = "0.8.0"

_DEFAULT_BACKEND = "pillow"


def icon_names() -> list[str]:
    """Return the available Font Awesome icon names.

    Returns:
        list[str]: Sorted icon names available in the bundled SVG map.
    """
    return sorted(FA)


def icon_categories(name: str) -> tuple[str, ...]:
    """Return the upstream category names associated with an icon.

    Args:
        name: Name or alias of the Font Awesome icon.

    Returns:
        tuple[str, ...]: Category names for the icon, if available.
    """
    canonical_name = _canonical_icon_name(name)
    icon_to_svg(canonical_name)
    return tuple(FA_categories.get(canonical_name, ()))


def category_names() -> list[str]:
    """Return the available upstream category names.

    Returns:
        list[str]: Sorted category names available in the bundled metadata.
    """
    categories = set()
    for icon_category_names in FA_categories.values():
        categories.update(icon_category_names)
    return sorted(categories)


def icons_in_category(category: str) -> list[str]:
    """Return the icon names associated with a category.

    Args:
        category: Upstream Font Awesome category name.

    Returns:
        list[str]: Sorted icon names in the requested category.
    """
    return sorted(
        icon_name
        for icon_name, icon_category_names in FA_categories.items()
        if category in icon_category_names
    )


def icon_to_image(
    name: str,
    fill: Optional[str] = None,
    scale_to_width: Optional[int] = None,
    scale_to_height: Optional[int] = None,
    scale: float = 1,
    style: Optional[str] = None,
    backend: str = _DEFAULT_BACKEND,
):
    """Render an icon to a Tk-compatible `PhotoImage`.

    Args:
        name: Name of the Font Awesome icon.
        fill: Optional icon colour.
        scale_to_width: Target width in pixels, preserving aspect ratio.
        scale_to_height: Target height in pixels, preserving aspect ratio.
        scale: Scaling factor used when no explicit target size is supplied.
        style: Optional Font Awesome style override (`solid`, `regular`,
            or `brands`).
        backend: Rendering backend name. The default is the bundled Pillow
            font backend. Use `cairosvg` for the legacy explicit SVG path.

    Returns:
        PhotoImage: Rendered Tk image.

    Raises:
        RuntimeError: If Pillow or Tk image support is unavailable.
        ValueError: If the icon name or backend is invalid.
    """
    image = icon_to_pil(
        name,
        fill=fill,
        scale_to_width=scale_to_width,
        scale_to_height=scale_to_height,
        scale=scale,
        style=style,
        backend=backend,
    )
    try:
        from PIL import ImageTk
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "icon_to_image() requires Pillow image support. "
            "Install it with `pip install Pillow`."
        ) from exc

    photo = ImageTk.PhotoImage(image=image)
    photo._pil_image = image
    return photo


def icon_to_ctkimage(
    name: str,
    fill: Optional[str] = None,
    scale_to_width: Optional[int] = None,
    scale_to_height: Optional[int] = None,
    scale: float = 1,
    style: Optional[str] = None,
    backend: str = _DEFAULT_BACKEND,
    dark_fill: Optional[str] = None,
):
    """Render an icon to a `customtkinter.CTkImage`.

    Args:
        name: Name of the Font Awesome icon.
        fill: Optional light-mode icon colour.
        scale_to_width: Target width in pixels, preserving aspect ratio.
        scale_to_height: Target height in pixels, preserving aspect ratio.
        scale: Scaling factor used when no explicit target size is supplied.
        style: Optional Font Awesome style override (`solid`, `regular`,
            or `brands`).
        backend: Rendering backend name. The default is the bundled Pillow
            font backend. Use `cairosvg` for the legacy explicit SVG path.
        dark_fill: Optional dark-mode icon colour. When omitted, `fill` is
            reused for both light and dark variants.

    Returns:
        CTkImage: DPI-aware CustomTkinter image.

    Raises:
        RuntimeError: If CustomTkinter is unavailable.
    """
    light_image = icon_to_pil(
        name,
        fill=fill,
        scale_to_width=scale_to_width,
        scale_to_height=scale_to_height,
        scale=scale,
        style=style,
        backend=backend,
    )
    dark_image = icon_to_pil(
        name,
        fill=dark_fill if dark_fill is not None else fill,
        scale_to_width=scale_to_width,
        scale_to_height=scale_to_height,
        scale=scale,
        style=style,
        backend=backend,
    )
    try:
        import customtkinter as ctk
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "icon_to_ctkimage() requires CustomTkinter. "
            "Install it with `pip install customtkinter`."
        ) from exc

    return ctk.CTkImage(light_image=light_image, dark_image=dark_image, size=light_image.size)


def icon_to_pil(
    name: str,
    fill: Optional[str] = None,
    scale_to_width: Optional[int] = None,
    scale_to_height: Optional[int] = None,
    scale: float = 1,
    style: Optional[str] = None,
    backend: str = _DEFAULT_BACKEND,
):
    """Render an icon to a transparent RGBA `PIL.Image`.

    Args:
        name: Name of the Font Awesome icon.
        fill: Optional icon colour.
        scale_to_width: Target width in pixels, preserving aspect ratio.
        scale_to_height: Target height in pixels, preserving aspect ratio.
        scale: Scaling factor used when no explicit target size is supplied.
        style: Optional Font Awesome style override (`solid`, `regular`,
            or `brands`).
        backend: Rendering backend name. The default is `pillow`.

    Returns:
        PIL.Image.Image: Rendered image object.

    Raises:
        RuntimeError: If the explicit Cairo backend is requested but
            CairoSVG or its native Cairo runtime is unavailable.
        ValueError: If the backend or icon name is invalid.
    """
    canonical_name = _canonical_icon_name(name)

    if backend == "pillow":
        spec = resolve_icon_font_spec(canonical_name, style=style)
        return render_icon(
            spec,
            fill=fill,
            scale_to_width=scale_to_width,
            scale_to_height=scale_to_height,
            scale=scale,
        )

    if backend in {"cairosvg", "svg"}:
        xml_data = icon_to_svg(canonical_name)
        return svg_to_pil(
            xml_data,
            fill=fill,
            scale_to_width=scale_to_width,
            scale_to_height=scale_to_height,
            scale=scale,
        )

    raise ValueError(
        f"Unsupported backend {backend!r}. Expected 'pillow' or 'cairosvg'."
    )


def icon_to_svg(name: str) -> str:
    """Return the raw bundled SVG XML string for an icon.

    Args:
        name: Name or alias of the Font Awesome icon.

    Returns:
        str: Raw SVG XML for the requested icon.

    Raises:
        ValueError: If the icon name is unknown.
    """
    canonical_name = _canonical_icon_name(name)
    xml_data = FA.get(canonical_name)
    if xml_data is None:
        raise ValueError(
            f"'{canonical_name}' is not a valid icon name. "
            "Check spelling or visit https://fontawesome.com/icons."
        )
    return xml_data


def svg_to_pil(
    source: str,
    fill: Optional[str] = None,
    scale_to_width: Optional[int] = None,
    scale_to_height: Optional[int] = None,
    scale: float = 1,
):
    """Convert SVG markup into a `PIL.Image` via CairoSVG.

    Args:
        source: Raw SVG XML string.
        fill: Optional fill override.
        scale_to_width: Target width in pixels, preserving aspect ratio.
        scale_to_height: Target height in pixels, preserving aspect ratio.
        scale: Scaling factor used when no explicit target size is supplied.

    Returns:
        PIL.Image.Image: Rendered image object.

    Raises:
        RuntimeError: If CairoSVG or the native Cairo runtime is unavailable.
    """
    try:
        import cairosvg
        from PIL import Image
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "The explicit CairoSVG backend requires CairoSVG and a working "
            "Cairo runtime. Install it with "
            "`pip install 'ctkfontawesome[cairosvg]'`."
        ) from exc

    root = etree.fromstring(source)

    if fill:
        for elem in root.iter():
            tag = str(elem.tag)
            if "fill" in elem.attrib:
                elem.attrib["fill"] = fill
            elif tag.endswith("path"):
                elem.attrib["fill"] = fill

    width, height = _get_svg_dimensions(root)
    output_width, output_height = _compute_output_size(
        width,
        height,
        scale_to_width,
        scale_to_height,
        scale,
    )

    img_data = io.StringIO()
    etree.ElementTree(root).write(img_data, encoding="unicode")
    png_data = cairosvg.svg2png(
        bytestring=img_data.getvalue().encode("utf-8"),
        output_width=output_width,
        output_height=output_height,
    )
    image = Image.open(io.BytesIO(png_data))
    return image.convert("RGBA")


def svg_to_image(
    source: str,
    fill: Optional[str] = None,
    scale_to_width: Optional[int] = None,
    scale_to_height: Optional[int] = None,
    scale: float = 1,
):
    """Convert SVG markup into a Tk-compatible `PhotoImage`.

    Args:
        source: Raw SVG XML string.
        fill: Optional fill override.
        scale_to_width: Target width in pixels, preserving aspect ratio.
        scale_to_height: Target height in pixels, preserving aspect ratio.
        scale: Scaling factor used when no explicit target size is supplied.

    Returns:
        PhotoImage: Rendered Tk image.
    """
    image = svg_to_pil(
        source,
        fill=fill,
        scale_to_width=scale_to_width,
        scale_to_height=scale_to_height,
        scale=scale,
    )
    try:
        from PIL import ImageTk
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "svg_to_image() requires Pillow image support. "
            "Install it with `pip install Pillow`."
        ) from exc

    photo = ImageTk.PhotoImage(image=image)
    photo._pil_image = image
    return photo


def _canonical_icon_name(name: str) -> str:
    """Return the canonical icon name for a public name or alias."""
    resolved_name = FA_aliases.get(name, name)
    if resolved_name.startswith("fa-"):
        resolved_name = resolved_name[3:]
    return resolved_name


def _get_svg_dimensions(root: etree.Element) -> tuple[float, float]:
    """Return SVG dimensions from a `viewBox` or width and height values."""
    view_box = root.attrib.get("viewBox")
    if view_box:
        _, _, width, height = (float(value) for value in view_box.replace(",", " ").split())
        return width, height

    width = _parse_dimension(root.attrib.get("width"))
    height = _parse_dimension(root.attrib.get("height"))
    if width is None or height is None:
        raise ValueError("SVG is missing a usable viewBox or width/height values.")
    return width, height


def _parse_dimension(value: Optional[str]) -> Optional[float]:
    """Parse a numeric SVG dimension string."""
    if value is None:
        return None

    value = value.strip()
    digits = []
    for char in value:
        if char.isdigit() or char == ".":
            digits.append(char)
        else:
            break

    return float("".join(digits)) if digits else None


def _compute_output_size(
    width: float,
    height: float,
    scale_to_width: Optional[int],
    scale_to_height: Optional[int],
    scale: float,
) -> tuple[Optional[int], Optional[int]]:
    """Compute the output size for a render operation."""
    if scale_to_width and scale_to_height:
        return int(scale_to_width), int(scale_to_height)

    if scale_to_width:
        return int(scale_to_width), int(round((height / width) * scale_to_width))

    if scale_to_height:
        return int(round((width / height) * scale_to_height)), int(scale_to_height)

    if scale != 1:
        return int(round(width * scale)), int(round(height * scale))

    return None, None


__all__ = [
    "FA",
    "FA_aliases",
    "FA_categories",
    "__version__",
    "category_names",
    "icon_categories",
    "icon_names",
    "icon_to_ctkimage",
    "icon_to_image",
    "icon_to_pil",
    "icon_to_svg",
    "icons_in_category",
    "svg_to_image",
    "svg_to_pil",
]
