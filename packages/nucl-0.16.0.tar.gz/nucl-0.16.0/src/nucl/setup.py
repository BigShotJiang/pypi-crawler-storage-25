import json
import shutil
import subprocess
from typing import Any

import click

from nucl.config import get_org_id


def _has(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _run(args: list[str]) -> Any:
    r = subprocess.run(args, capture_output=True, text=True)
    if r.returncode != 0:
        raise click.ClickException(f"`{' '.join(args[:3])}...` failed:\n{r.stderr.strip()}")
    return json.loads(r.stdout)


def _pick(items: list[dict], key: str, label: str) -> dict:
    if not items:
        raise click.ClickException(f"No {label} found.")
    click.echo(f"\n  {label}:")
    for i, item in enumerate(items):
        click.echo(f"    [{i}] {item[key]}")
    idx = click.prompt("  Select", type=click.IntRange(0, len(items) - 1), default=0)
    return items[idx]


def setup_azure() -> dict:
    """Interactive Azure ML setup using az CLI."""
    if not _has("az"):
        raise click.ClickException("Azure CLI not found. Install: https://aka.ms/installazurecli")

    # 1. Pick subscription
    subs = _run(["az", "account", "list", "--output", "json"])
    sub = _pick(subs, "name", "Azure Subscriptions")
    sub_id = sub["id"]
    tenant_id = sub["tenantId"]
    click.echo(f"  Using subscription: {sub['name']} ({sub_id})")

    # 2. Ensure ml extension, then pick workspace
    click.echo("  Loading ML workspaces...")
    subprocess.run(["az", "extension", "add", "--name", "ml", "--yes"], capture_output=True)
    workspaces = _run(["az", "ml", "workspace", "list", "--subscription", sub_id, "--output", "json"])
    ws = _pick(workspaces, "name", "ML Workspaces")
    ws_name = ws["name"]
    rg = ws["resource_group"]
    click.echo(f"  Using workspace: {ws_name} (resource group: {rg})")

    # 3. Service principal
    use_existing = click.confirm("  Use an existing service principal?", default=False)

    if use_existing:
        client_id = click.prompt("  Client ID")
        client_secret = click.prompt("  Client Secret", hide_input=True)
    else:
        org_id = get_org_id() or "nucl"
        sp_name = f"nucl-{org_id[:16]}"
        click.echo(f"  Creating service principal '{sp_name}'...")
        sp = _run(["az", "ad", "sp", "create-for-rbac", "--name", sp_name, "--output", "json"])
        client_id = sp["appId"]
        client_secret = sp["password"]
        click.echo(f"  Created service principal: {client_id}")

        # Try role assignment (may fail without Owner/UAA permissions)
        scope = f"/subscriptions/{sub_id}/resourceGroups/{rg}/providers/Microsoft.MachineLearningServices/workspaces/{ws_name}"
        r = subprocess.run([
            "az", "role", "assignment", "create",
            "--assignee", client_id,
            "--role", "Contributor",
            "--scope", scope,
        ], capture_output=True, text=True)
        if r.returncode == 0:
            click.echo("  Granted Contributor role on workspace.")
        else:
            click.echo("  Warning: could not assign Contributor role (need Owner permissions).")
            click.echo(f"  Ask an admin to run: az role assignment create --assignee {client_id} --role Contributor --scope {scope}")

    return {
        "subscriptionId": sub_id,
        "resourceGroup": rg,
        "workspace": ws_name,
        "tenantId": tenant_id,
        "clientId": client_id,
        "clientSecret": client_secret,
    }


def setup_vertex() -> dict:
    """Interactive Vertex AI setup using gcloud CLI."""
    if not _has("gcloud"):
        raise click.ClickException("Google Cloud CLI not found. Install: https://cloud.google.com/sdk/docs/install")

    # 1. Pick project
    projects = _run(["gcloud", "projects", "list", "--format", "json"])
    proj = _pick(projects, "projectId", "GCP Projects")
    project_id = proj["projectId"]
    click.echo(f"  Using project: {project_id}")

    # 2. Pick location
    locations = ["us-central1", "us-east1", "us-west1", "europe-west1", "asia-east1"]
    click.echo("\n  Locations:")
    for i, loc in enumerate(locations):
        click.echo(f"    [{i}] {loc}")
    loc_idx = click.prompt("  Select", type=click.IntRange(0, len(locations) - 1), default=0)
    location = locations[loc_idx]

    # 3. Service account
    use_existing = click.confirm("  Use an existing service account key?", default=False)

    if use_existing:
        sa_path = click.prompt("  Service Account JSON path")
        sa_json = open(sa_path).read()
    else:
        org_id = get_org_id() or "nucl"
        sa_name = f"nucl-{org_id[:16]}".lower().replace("_", "-")
        sa_email = f"{sa_name}@{project_id}.iam.gserviceaccount.com"
        click.echo(f"  Creating service account '{sa_name}'...")

        # Create service account
        subprocess.run([
            "gcloud", "iam", "service-accounts", "create", sa_name,
            "--project", project_id,
            "--display-name", f"NUCL ({org_id})",
        ], capture_output=True, text=True, check=True)

        # Grant Vertex AI role
        subprocess.run([
            "gcloud", "projects", "add-iam-policy-binding", project_id,
            "--member", f"serviceAccount:{sa_email}",
            "--role", "roles/aiplatform.user",
            "--condition", "None",
        ], capture_output=True, text=True, check=True)

        # Create key (output to stdout)
        r = subprocess.run([
            "gcloud", "iam", "service-accounts", "keys", "create", "/dev/stdout",
            "--iam-account", sa_email,
        ], capture_output=True, text=True, check=True)
        sa_json = r.stdout
        click.echo(f"  Created service account: {sa_email}")

    return {
        "project": project_id,
        "location": location,
        "serviceAccountJson": sa_json,
    }
