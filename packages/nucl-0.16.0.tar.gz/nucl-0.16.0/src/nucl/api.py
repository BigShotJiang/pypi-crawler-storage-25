import httpx
import json
import sys

from nucl.config import get_api_key, get_api_url, get_org_id


def _raise(r: httpx.Response) -> None:
    if r.is_success:
        return
    try:
        body = r.json()
        msg = body.get("error", r.text)
    except Exception:
        msg = r.text
    raise httpx.HTTPStatusError(f"{r.status_code}: {msg}", request=r.request, response=r)


def _client() -> httpx.Client:
    key = get_api_key()
    if not key:
        print("Not logged in. Run: nucl auth login", file=sys.stderr)
        sys.exit(1)
    headers: dict[str, str] = {"Authorization": f"Bearer {key}"}
    org_id = get_org_id()
    if org_id:
        headers["x-nucl-org"] = org_id
    return httpx.Client(
        base_url=get_api_url(),
        headers=headers,
        timeout=300,
    )


def get(path: str, **params) -> dict:
    with _client() as c:
        r = c.get(path, params=params)
        _raise(r)
        return r.json()


def post(path: str, **kwargs) -> dict:
    with _client() as c:
        r = c.post(path, **kwargs)
        _raise(r)
        return r.json()


def post_multipart(path: str, metadata: dict, file_path: str) -> dict:
    with _client() as c:
        with open(file_path, "rb") as f:
            r = c.post(path, files={"code": f}, data={"metadata": json.dumps(metadata)})
        _raise(r)
        return r.json()


def patch(path: str, data: dict) -> dict:
    with _client() as c:
        r = c.patch(path, json=data)
        _raise(r)
        return r.json()


def delete(path: str) -> dict:
    with _client() as c:
        r = c.delete(path)
        _raise(r)
        return r.json()
