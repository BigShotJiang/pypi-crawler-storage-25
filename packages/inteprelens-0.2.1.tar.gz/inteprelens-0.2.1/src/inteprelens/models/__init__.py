# Original from: https://github.com/jonhanke/nam_causal-head-gating
# Adapted and extended for Causal Summer project by:
# - Bowen
# - 2026-01-27

from .adapters import (
    SUPPORTED_ARCHITECTURES,
    GemmaAdapter,
    GPT2Adapter,
    GPTNeoXAdapter,
    LlamaAdapter,
    MistralAdapter,
    ModelAdapter,
    PhiAdapter,
    get_adapter,
)

__all__ = [
    "ModelAdapter",
    "LlamaAdapter",
    "MistralAdapter",
    "GPT2Adapter",
    "GPTNeoXAdapter",
    "GemmaAdapter",
    "PhiAdapter",
    "get_adapter",
    "SUPPORTED_ARCHITECTURES",
]
