from inteprelens import (
    CHG,
    CHGResults,
    CHGTrainer,
    LensAPI,
    TokenScores,
    TraceResult,
    TransformerTracer,
)


def test_release_import_smoke() -> None:
    assert CHG is not None
    assert LensAPI is not None
    assert CHGTrainer is not None
    assert CHGResults is not None
    assert TransformerTracer is not None
    assert TraceResult is not None
    assert TokenScores is not None


def test_chgapi_is_not_exported() -> None:
    import inteprelens

    assert not hasattr(inteprelens, "CHGAPI")
