"""Tests for merge search-tools command."""

from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from merge_cli.commands.search_tools import search_tools

MCP_URL = "https://test.example.com/api/v1/tool-packs/tp_123/registered-users/user_456/mcp"
SEARCH_URL = "https://test.example.com/api/v1/tool-packs/tp_123/registered-users/user_456/search"


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def env_vars(monkeypatch):
    monkeypatch.setenv("MERGE_AH_API_KEY", "pk_test_key")
    monkeypatch.setenv("MERGE_AH_TOOL_PACK_ID", "tp_123")
    monkeypatch.setenv("MERGE_AH_REGISTERED_USER_ID", "user_456")
    monkeypatch.setenv("MERGE_AH_BASE_URL", "https://test.example.com")


SEARCH_RESPONSE = {
    "tools": [
        {
            "name": "post_message",
            "fully_qualified_name": "slack__post_message",
            "description": "Post a message to a Slack channel",
            "input_schema": {
                "type": "object",
                "properties": {"channel": {"type": "string"}},
            },
            "relevance_score": 0.95,
            "reasoning": "Direct match for sending Slack messages",
        }
    ],
    "total_results": 1,
    "intent": "send a slack message",
}

MCP_INIT_RESPONSE = {
    "jsonrpc": "2.0",
    "id": 1,
    "result": {
        "protocolVersion": "2024-11-05",
        "capabilities": {"tools": {"listChanged": True}},
        "serverInfo": {"name": "ToolPack MCP Server", "version": "0.1.0"},
    },
}

MCP_LIST_RESPONSE = {
    "jsonrpc": "2.0",
    "id": 1,
    "result": {
        "tools": [
            {"name": "slack__post_message", "description": "Post a Slack message"},
        ]
    },
}


def _mock_search_with_connectors(httpx_mock):
    """Mock the search endpoint."""
    httpx_mock.add_response(url=SEARCH_URL, method="POST", json=SEARCH_RESPONSE)


def test_search_tools_success(runner, env_vars, httpx_mock):
    _mock_search_with_connectors(httpx_mock)

    result = runner.invoke(search_tools, ["send a slack message"])
    assert result.exit_code == 0

    output = json.loads(result.output)
    assert output["total_results"] == 1
    assert output["tools"][0]["name"] == "post_message"
    assert "hint" in output


def test_search_tools_no_schema(runner, env_vars, httpx_mock):
    _mock_search_with_connectors(httpx_mock)

    result = runner.invoke(search_tools, ["send a slack message", "--schema", "none"])
    assert result.exit_code == 0

    output = json.loads(result.output)
    assert "input_schema" not in output["tools"][0]


def test_search_tools_with_connector_filter(runner, env_vars, httpx_mock):
    _mock_search_with_connectors(httpx_mock)

    result = runner.invoke(
        search_tools, ["send a message", "--connector", "slack", "--max-results", "5"]
    )
    assert result.exit_code == 0

    # Verify the search request body (first request)
    requests = httpx_mock.get_requests(url=SEARCH_URL)
    assert len(requests) == 1
    body = json.loads(requests[0].content)
    assert body["connector_slugs"] == ["slack"]
    assert body["max_results"] == 5


def test_search_tools_missing_config(runner, monkeypatch):
    monkeypatch.delenv("MERGE_AH_API_KEY", raising=False)
    monkeypatch.delenv("MERGE_AH_TOOL_PACK_ID", raising=False)
    monkeypatch.delenv("MERGE_AH_REGISTERED_USER_ID", raising=False)
    monkeypatch.setattr("merge_cli.config._load_config_file", lambda: {})

    result = runner.invoke(search_tools, ["test"])
    assert result.exit_code == 1
    output = json.loads(result.output)
    assert output["error_type"] == "config_error"


def test_search_tools_api_error(runner, env_vars, httpx_mock):
    httpx_mock.add_response(
        url=SEARCH_URL,
        method="POST",
        status_code=500,
        text="Internal Server Error",
    )

    result = runner.invoke(search_tools, ["test"])
    assert result.exit_code == 1
    output = json.loads(result.output)
    assert output["error_type"] == "api_error"
