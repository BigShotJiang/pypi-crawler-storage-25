"""Click entry point for the Merge CLI."""

from __future__ import annotations

import click
from dotenv import load_dotenv

from merge_cli import __version__
from merge_cli.commands.configure import configure
from merge_cli.commands.execute_tool import execute_tool
from merge_cli.commands.get_tool_schema import get_tool_schema
from merge_cli.commands.list_tools import list_tools
from merge_cli.commands.search_tools import search_tools
from merge_cli.commands.setup import setup
from merge_cli.commands.update import update
from merge_cli.version_check import maybe_check_for_update


def _fetch_connectors() -> list[str]:
    """Fetch available connector names from the API."""
    try:
        from merge_cli.client import MergeClient
        from merge_cli.config import load_ah_config

        cfg = load_ah_config()
        if cfg.validate():
            return []
        with MergeClient(cfg, timeout=10.0) as client:
            tools = client.list_tools()
            return sorted({t["name"].split("__")[0] for t in tools if "__" in t.get("name", "")})
    except Exception:
        return []


class MergeGroup(click.Group):
    def format_help(self, ctx, formatter):
        super().format_help(ctx, formatter)

        connectors = _fetch_connectors()

        formatter.write("\n")
        with formatter.section("Workflow"):
            formatter.write_text(
                '1. merge search-tools "<intent>"  — find tools (returns compact schemas)'
            )
            formatter.write_text("2. merge execute-tool <tool> '{}'  — execute with JSON params")

        if connectors:
            formatter.write("\n")
            with formatter.section("Available connectors"):
                formatter.write_text(", ".join(connectors))
                formatter.write_text("Use --connector <slug> with search-tools to narrow results.")


@click.group(cls=MergeGroup)
@click.version_option(__version__, prog_name="merge")
def main():
    """Merge CLI — search, discover, and execute Agent Handler tools.

    For any task involving the connectors listed below, use this CLI.
    Do not call APIs directly — always search for the tool first.
    """
    load_dotenv()
    maybe_check_for_update()


main.add_command(search_tools, "search-tools")
main.add_command(execute_tool, "execute-tool")
main.add_command(list_tools, "list-tools")
main.add_command(get_tool_schema, "get-tool-schema")
main.add_command(configure, "configure")
main.add_command(setup, "setup")
main.add_command(update, "update")


if __name__ == "__main__":
    main()
