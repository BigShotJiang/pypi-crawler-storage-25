"""HTTP client for Merge Agent Handler API."""

from __future__ import annotations

import json
import uuid
from typing import Any

import httpx

from merge_cli.config import AgentHandlerConfig

DEFAULT_TIMEOUT = 60.0


class MergeClientError(Exception):
    """Raised when the API returns an unexpected error."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class MergeClient:
    """Synchronous HTTP client for Agent Handler endpoints."""

    def __init__(self, config: AgentHandlerConfig, *, timeout: float = DEFAULT_TIMEOUT):
        self.config = config
        self._session_id: str | None = None
        self._http = httpx.Client(
            base_url=config.base_url.rstrip("/"),
            headers={
                "Authorization": f"Bearer {config.api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # ── URL helpers ──────────────────────────────────────────────

    @property
    def _base_path(self) -> str:
        tp = self.config.tool_pack_id
        ru = self.config.registered_user_id
        return f"/api/v1/tool-packs/{tp}/registered-users/{ru}"

    @property
    def _mcp_url(self) -> str:
        return f"{self._base_path}/mcp"

    @property
    def _search_url(self) -> str:
        return f"{self._base_path}/search"

    # ── MCP JSON-RPC helpers ─────────────────────────────────────

    def _mcp_request(self, method: str, params: dict | None = None) -> dict:
        """Send a JSON-RPC 2.0 request to the MCP endpoint."""
        body: dict[str, Any] = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
        }
        if params is not None:
            body["params"] = params

        headers = {}
        if self._session_id:
            headers["Mcp-Session-Id"] = self._session_id

        resp = self._http.post(self._mcp_url, json=body, headers=headers)

        # Capture session ID from response
        if "Mcp-Session-Id" in resp.headers:
            self._session_id = resp.headers["Mcp-Session-Id"]

        if resp.status_code != 200:
            raise MergeClientError(
                f"MCP request failed: {resp.status_code} {resp.text}",
                status_code=resp.status_code,
            )

        data = resp.json()

        # Check for JSON-RPC error
        if "error" in data:
            err = data["error"]
            raise MergeClientError(
                f"JSON-RPC error ({err.get('code')}): {err.get('message')}",
            )

        return data

    def _ensure_initialized(self) -> None:
        """Initialize MCP session if not already done."""
        if self._session_id is None:
            self._session_id = str(uuid.uuid4())
            self._mcp_request("initialize", {"protocolVersion": "2024-11-05"})

    # ── Public methods ───────────────────────────────────────────

    def search_tools(
        self,
        intent: str,
        *,
        connector_slugs: list[str] | None = None,
        max_results: int = 10,
    ) -> dict:
        """Search for tools by natural language intent (REST endpoint)."""
        payload: dict[str, Any] = {"intent": intent, "max_results": max_results}
        if connector_slugs is not None:
            payload["connector_slugs"] = connector_slugs

        resp = self._http.post(self._search_url, json=payload)

        if resp.status_code != 200:
            raise MergeClientError(
                f"Search failed: {resp.status_code} {resp.text}",
                status_code=resp.status_code,
            )

        return resp.json()

    def list_tools(self) -> list[dict]:
        """List all available tools via MCP tools/list."""
        self._ensure_initialized()
        data = self._mcp_request("tools/list")
        return data.get("result", {}).get("tools", [])

    def call_tool(self, tool_name: str, arguments: dict) -> dict:
        """Execute a tool via MCP tools/call. Returns the full JSON-RPC result."""
        self._ensure_initialized()
        data = self._mcp_request(
            "tools/call",
            {"name": tool_name, "arguments": arguments},
        )
        return data.get("result", {})

    def get_tool_schema(self, tool_name: str) -> dict | None:
        """Get the input schema for a single tool (filters from tools/list)."""
        tools = self.list_tools()
        for tool in tools:
            if tool.get("name") == tool_name:
                return tool
        return None

    def parse_tool_result(self, result: dict) -> dict:
        """Parse MCP tool/call result into a structured response.

        Handles success, reauth_required, billing_limit_reached, and generic errors.
        """
        is_error = result.get("isError", False)
        content_list = result.get("content", [])
        raw_text = ""
        for item in content_list:
            if item.get("type") == "text":
                raw_text = item.get("text", "")
                break

        # Try to parse as JSON
        try:
            parsed = json.loads(raw_text) if raw_text else {}
        except json.JSONDecodeError:
            parsed = {"raw": raw_text}

        if not is_error:
            return {
                "result": parsed if parsed else raw_text,
                "status": "success",
                "hint": "Tool executed successfully.",
            }

        # Handle known error types
        error_type = parsed.get("error", "execution_error")
        message = parsed.get("message", raw_text or "Tool execution failed.")

        if error_type == "reauth_required":
            return {
                "result": None,
                "status": "error",
                "error_type": "reauth_required",
                "message": message,
                "hint": "Authentication required. The user needs to re-connect their account.",
            }
        elif error_type == "billing_limit_reached":
            billing_url = parsed.get("billing_page_url", "")
            hint = "Billing limit reached. Upgrade the account to continue."
            if billing_url:
                hint += f" Billing page: {billing_url}"
            return {
                "result": None,
                "status": "error",
                "error_type": "billing_limit_reached",
                "message": message,
                "hint": hint,
            }
        else:
            return {
                "result": None,
                "status": "error",
                "error_type": error_type,
                "message": message,
                "hint": f"Tool execution failed: {message}",
            }
