"""Shared Click options for commands that require Agent Handler credentials."""

from __future__ import annotations

import click

COMMON_OPTIONS = [
    click.option("--api-key", envvar="MERGE_AH_API_KEY", default=None, help="API key override."),
    click.option(
        "--tool-pack-id", envvar="MERGE_AH_TOOL_PACK_ID", default=None, help="Tool pack ID."
    ),
    click.option(
        "--registered-user-id",
        envvar="MERGE_AH_REGISTERED_USER_ID",
        default=None,
        help="Registered user ID.",
    ),
    click.option("--base-url", envvar="MERGE_AH_BASE_URL", default=None, help="Base URL override."),
]


def add_common_options(cmd):
    """Apply shared auth/config options to a command."""
    for option in reversed(COMMON_OPTIONS):
        cmd = option(cmd)
    return cmd
