"""Configuration loading with priority: CLI flags > env vars > .env file > config file."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

CONFIG_DIR = Path.home() / ".merge"
CONFIG_FILE = CONFIG_DIR / "config.json"
VERSION_CACHE_FILE = CONFIG_DIR / "version_cache.json"

DEFAULT_BASE_URL = "https://ah-api.merge.dev"


@dataclass
class AgentHandlerConfig:
    api_key: str
    tool_pack_id: str
    registered_user_id: str
    base_url: str = DEFAULT_BASE_URL

    def validate(self) -> list[str]:
        errors = []
        if not self.api_key:
            errors.append("API key is required. Set MERGE_AH_API_KEY or run `merge configure`.")
        if not self.tool_pack_id:
            errors.append(
                "Tool pack ID is required. Set MERGE_AH_TOOL_PACK_ID or run `merge configure`."
            )
        if not self.registered_user_id:
            errors.append(
                "Registered user ID is required."
                " Set MERGE_AH_REGISTERED_USER_ID or run `merge configure`."
            )
        return errors


def _load_config_file() -> dict:
    """Load config from ~/.merge/config.json if it exists."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _save_config_file(config: dict) -> None:
    """Write config to ~/.merge/config.json."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    CONFIG_FILE.write_text(json.dumps(config, indent=2) + "\n")
    CONFIG_FILE.chmod(0o600)


def load_ah_config(
    *,
    api_key: str | None = None,
    tool_pack_id: str | None = None,
    registered_user_id: str | None = None,
    base_url: str | None = None,
) -> AgentHandlerConfig:
    """Load Agent Handler config with priority: CLI flags > env vars > config file."""
    file_cfg = _load_config_file().get("agent_handler", {})

    return AgentHandlerConfig(
        api_key=api_key or os.environ.get("MERGE_AH_API_KEY") or file_cfg.get("api_key", ""),
        tool_pack_id=(
            tool_pack_id
            or os.environ.get("MERGE_AH_TOOL_PACK_ID")
            or file_cfg.get("tool_pack_id", "")
        ),
        registered_user_id=(
            registered_user_id
            or os.environ.get("MERGE_AH_REGISTERED_USER_ID")
            or file_cfg.get("registered_user_id", "")
        ),
        base_url=(
            base_url
            or os.environ.get("MERGE_AH_BASE_URL")
            or file_cfg.get("base_url")
            or DEFAULT_BASE_URL
        ),
    )
