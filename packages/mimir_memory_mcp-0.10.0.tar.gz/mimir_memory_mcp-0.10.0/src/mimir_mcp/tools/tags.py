"""Tag tools: list, suggest consolidations, merge."""

from __future__ import annotations

import re
from typing import Annotated

from pydantic import Field

from fastmcp.exceptions import ToolError

from mimir_mcp import queries
from mimir_mcp.auth import get_current_scopes
from mimir_mcp.db import Database, get_db


LIST_TAGS_DEFAULT_LIMIT = 30


def _require_scope_access(scope: str, scopes: list[str]) -> None:
    if scope not in scopes:
        raise ToolError(f"Scope '{scope}' is not in your accessible scopes.")


def list_tags_impl(
    db: Database,
    scopes: list[str],
    *,
    scope: str,
    extended: bool = False,
) -> list[dict]:
    """Return tags in `scope` with usage counts.

    extended=False (default): top-N by count (N = LIST_TAGS_DEFAULT_LIMIT).
    extended=True: every tag in the scope.
    """
    _require_scope_access(scope, scopes)
    tags = queries.tags_with_counts(db, scope)
    if not extended:
        tags = tags[:LIST_TAGS_DEFAULT_LIMIT]
    return tags


_WORD_SPLIT_RE = re.compile(r"[-_ ]")
_STEM_SUFFIXES = ("s", "es", "ing", "ed")
LOW_USAGE_THRESHOLD = 2
EDIT_DISTANCE_THRESHOLD = 2


def _edit_distance(a: str, b: str) -> int:
    """Iterative Levenshtein distance. O(len(a) * len(b))."""
    if len(a) < len(b):
        a, b = b, a
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            ins = curr[j] + 1
            dele = prev[j + 1] + 1
            sub = prev[j] + (0 if ca == cb else 1)
            curr.append(min(ins, dele, sub))
        prev = curr
    return prev[-1]


def _is_stem_variant(a: str, b: str) -> bool:
    for suf in _STEM_SUFFIXES:
        if a == b + suf or b == a + suf:
            return True
    return False


def _is_word_subset(sub: str, full: str) -> bool:
    """True if `sub` appears as a whole token in `full` (dash/space/underscore separated)."""
    return sub in _WORD_SPLIT_RE.split(full)


def _match_reason(a: str, b: str) -> str | None:
    """Return the heuristic that matches a<->b, preferring the strongest signal, else None.

    Priority: stem (most specific) > edit_distance (typos) > substring (structural).
    Stem is checked first because it is a more specific signal than edit distance —
    plural/suffix variants are always stem matches regardless of Levenshtein proximity.
    Edit distance catches typos not covered by stem. Substring is checked last.
    """
    if _is_stem_variant(a, b):
        return "stem"
    if _edit_distance(a, b) <= EDIT_DISTANCE_THRESHOLD:
        return "edit_distance"
    # Substring only in the direction where sub is in full. a could be sub or full.
    if _is_word_subset(a, b) or _is_word_subset(b, a):
        return "substring"
    return None


def suggest_tag_consolidations_impl(
    db: Database,
    scopes: list[str],
    *,
    scope: str,
) -> list[dict]:
    """Candidate tag pairs for consolidation. See spec section 6 for heuristics."""
    _require_scope_access(scope, scopes)
    tags = queries.tags_with_counts(db, scope)
    if len(tags) < 2:
        return []
    candidates: list[dict] = []
    for low in tags:
        if low["count"] > LOW_USAGE_THRESHOLD:
            continue
        for high in tags:
            if high["name"] == low["name"]:
                continue
            if high["count"] < low["count"]:
                continue
            reason = _match_reason(low["name"], high["name"])
            if not reason:
                continue
            candidates.append(
                {
                    "from": low["name"],
                    "to": high["name"],
                    "from_count": low["count"],
                    "to_count": high["count"],
                    "reason": reason,
                }
            )
    candidates.sort(key=lambda c: (-c["to_count"], c["from_count"], c["from"]))
    return candidates


def merge_tags_impl(
    db: Database,
    scopes: list[str],
    *,
    from_tag: str,
    to_tag: str,
    scope: str,
) -> dict:
    """Replace from_tag with to_tag on every item in `scope`. Atomic.

    - If an item already has both tags, from_tag is simply removed.
    - Creates the to_tag row in `tags` if absent.
    - Deletes the from_tag row only when no items anywhere still reference it.
    """
    _require_scope_access(scope, scopes)

    rows = db.fetchall(
        "SELECT it.item_id FROM item_tags it JOIN items i ON it.item_id = i.id "
        "WHERE i.scope = ? AND it.tag_id = ?",
        (scope, from_tag),
    )
    item_ids = [r["item_id"] for r in rows]
    if not item_ids:
        return {"merged": 0, "from": from_tag, "to": to_tag, "scope": scope}

    # Ensure the target tag exists
    db.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", (to_tag,))

    placeholders = ",".join("?" for _ in item_ids)
    # Remove the from_tag rows for the affected items
    db.execute(
        f"DELETE FROM item_tags WHERE tag_id = ? AND item_id IN ({placeholders})",
        (from_tag, *item_ids),
    )
    # Add the to_tag rows (dedup via PK)
    db.executemany(
        "INSERT OR IGNORE INTO item_tags (item_id, tag_id) VALUES (?, ?)",
        [(i, to_tag) for i in item_ids],
    )

    # If no more references to from_tag anywhere, delete its tags row
    remaining = db.fetchone("SELECT COUNT(*) as c FROM item_tags WHERE tag_id = ?", (from_tag,))
    if remaining and remaining["c"] == 0:
        db.execute("DELETE FROM tags WHERE id = ?", (from_tag,))

    db.commit()
    return {"merged": len(item_ids), "from": from_tag, "to": to_tag, "scope": scope}


def register(mcp):
    """Register tag-related MCP tools."""

    @mcp.tool
    def list_tags(
        scope: Annotated[
            str,
            Field(description="Scope to list tags for. Must be a scope you can access."),
        ],
        extended: Annotated[
            bool,
            Field(
                default=False,
                description="If True, return every tag in the scope. Default returns only the 30 most-used.",
            ),
        ] = False,
    ) -> list[dict]:
        """List tags currently in use in a given scope, ordered by usage count (descending). Returns the 30 most-used by default; pass extended=True for the full list. Use this when you need to pick consistent tags mid-conversation without reloading the entire boot payload."""
        return list_tags_impl(get_db(), get_current_scopes(), scope=scope, extended=extended)

    @mcp.tool
    def suggest_tag_consolidations(
        scope: Annotated[
            str,
            Field(description="Scope to analyze for tag consolidation candidates."),
        ],
    ) -> list[dict]:
        """Return low-usage tags that look like variants of a more-used tag in the same scope. Heuristics: edit distance ≤ 2 (typo), plural/stem variants, substring/word-boundary match. Only surfaces pairs where at least one tag has count ≤ 2 — common tags are never candidates. Use the output to review with the user before merging via merge_tags."""
        return suggest_tag_consolidations_impl(get_db(), get_current_scopes(), scope=scope)

    @mcp.tool
    def merge_tags(
        from_tag: Annotated[
            str,
            Field(
                description="Tag to eliminate. Every item tagged with it in the given scope will be retagged with to_tag."
            ),
        ],
        to_tag: Annotated[
            str,
            Field(description="Tag to keep. Created automatically if it does not yet exist."),
        ],
        scope: Annotated[
            str,
            Field(
                description="Scope to operate in. Must be a scope you can access. Only items in this scope are affected."
            ),
        ],
    ) -> dict:
        """Rename every occurrence of from_tag to to_tag on items in the given scope. Atomic. Dedupes when an item already has both. Deletes the from_tag row from the tags table if no references remain anywhere. Returns {merged, from, to, scope}."""
        return merge_tags_impl(
            get_db(), get_current_scopes(), from_tag=from_tag, to_tag=to_tag, scope=scope
        )
