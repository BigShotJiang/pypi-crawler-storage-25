"""Session lifecycle tools: boot, end."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from mimir_mcp import queries
from mimir_mcp.auth import get_current_user, get_current_scopes
from mimir_mcp.db import Database, get_db
from mimir_mcp.tools.context import build_boot_summary
from mimir_mcp.tools.tags import suggest_tag_consolidations_impl


def boot_session_impl(db: Database, user_id: str, scopes: list[str]) -> dict:
    """Start a new session. Returns structured boot data plus tags_in_use per scope."""
    # 1. Get the last completed session (before creating a new one)
    last_session_row = queries.sessions_get_last_completed(db, user_id)
    last_session = None
    if last_session_row:
        last_session = {"summary": last_session_row["summary"]}

    # 2. Create new session
    queries.sessions_get_or_create(db, user_id)

    # 3. Fetch user profile
    user_row = queries.users_get(db, user_id)
    user = {"id": user_row["id"], "name": user_row["name"]}

    # 4. Fetch scopes with members (filtered to requested scopes)
    all_user_scopes = queries.scopes_for_user(db, user_id)
    scope_list = []
    for s in all_user_scopes:
        if s["id"] in scopes:
            scope_list.append(
                {
                    "id": s["id"],
                    "name": s["name"],
                    "description": s["description"],
                    "members": s["member_ids"],
                }
            )

    # 5-7. Fetch items, reminders, facts (delegated to shared helper)
    summary = build_boot_summary(db, user_id, scopes)

    # 8. Fetch shared activity (do NOT advance cursor -- crash safety)
    shared_activity_raw = queries.activity_get_shared(db, user_id, scopes)
    shared_activity = [dict(a) for a in shared_activity_raw]

    # Also fetch recently created/updated items by other users (covers items
    # that don't yet have explicit history entries)
    recent_items_by_others = queries.items_recent_by_others(db, user_id, scopes)
    # Merge into shared activity if not already represented
    existing_item_ids = {a.get("item_id") for a in shared_activity}
    for item in recent_items_by_others:
        if item["id"] not in existing_item_ids:
            shared_activity.append(
                {
                    "item_id": item["id"],
                    "actor": item["created_by"],
                    "event": "created",
                    "summary": item["summary"],
                    "scope": item["scope"],
                    "created_at": item["created_at"],
                }
            )

    # 9. Tags in use per scope
    tags_by_scope = queries.tags_in_use(db, scopes)

    # 10. Commit and return
    db.commit()

    return {
        "user": user,
        "scopes": scope_list,
        "last_session": last_session,
        **summary,
        "recent_shared_activity": shared_activity,
        "tags_in_use": tags_by_scope,
    }


def end_session_impl(db: Database, user_id: str, *, learnings: list[str] | None = None) -> dict:
    """End the active session. Optionally record learnings as facts.

    If no active session exists, still records learnings and advances the
    activity cursor — those are the valuable side-effects.

    When there are tag consolidation candidates in any accessible scope,
    includes them under 'tag_consolidation_candidates' keyed by scope id.
    """
    session = queries.sessions_get_active(db, user_id)
    session_id = session["id"] if session else None

    # Record learnings as facts (works with or without a session)
    if learnings:
        for learning in learnings:
            fact_id = queries.items_insert_full(
                db,
                user_id,
                "fact",
                "active",
                learning,
                user_id,
                source="learned",
            )
            queries.history_insert(
                db,
                fact_id,
                "created",
                f"Learned: {learning}",
                user_id,
                session_id=session_id,
            )

    # Generate summary
    if session:
        summary = "Session ended"
        if learnings:
            summary += f" with {len(learnings)} learning(s) recorded"
        queries.sessions_end(db, session_id, summary)
    else:
        summary = "No active session"
        if learnings:
            summary += f", {len(learnings)} learning(s) recorded"

    # Advance cursor
    queries.activity_advance_cursor(db, user_id)

    # Commit
    db.commit()

    # Collect tag consolidation candidates across every accessible scope.
    user_scope_rows = queries.scopes_for_user(db, user_id)
    user_scope_ids = [s["id"] for s in user_scope_rows]
    candidates: dict[str, list[dict]] = {}
    for sid in user_scope_ids:
        scope_candidates = suggest_tag_consolidations_impl(db, user_scope_ids, scope=sid)
        if scope_candidates:
            candidates[sid] = scope_candidates

    result = {"summary": summary}
    if candidates:
        result["tag_consolidation_candidates"] = candidates
    return result


def register(mcp):
    """Register session MCP tools."""

    @mcp.tool
    def start_session(
        scopes: Annotated[
            list[str] | None,
            Field(
                default=None,
                description="Scope IDs to activate for this session. Defaults to all your scopes if omitted.",
            ),
        ] = None,
    ) -> dict:
        """Start or resume a session and return your full current state: projects, tasks, ideas, top-level facts (parent_id IS NULL), upcoming reminders, recent shared activity, and the top 30 tags per scope. Idempotent — reuses the existing open session if one exists. Call once at the beginning of every conversation. If your context is compacted mid-conversation, call refresh_context instead."""
        resolved_scopes = scopes if scopes is not None else get_current_scopes()
        return boot_session_impl(get_db(), get_current_user(), resolved_scopes)

    @mcp.tool
    def end_session(
        learnings: Annotated[
            list[str] | None,
            Field(
                default=None,
                description="New facts discovered this session. Each string is saved as a persistent fact (type='fact', source='learned') in your personal scope. For facts in shared scopes or with custom fields, use add_items with type='fact' instead. Pass None or omit to end without saving facts.",
            ),
        ] = None,
    ) -> dict:
        """End the current session, or record learnings without one. Pass learnings to save new facts that should persist across sessions. If no active session exists, learnings are still recorded and the activity cursor is still advanced. If there are tag consolidation candidates in any accessible scope, they are included under 'tag_consolidation_candidates' — review with the user and invoke merge_tags to apply approved merges."""
        return end_session_impl(get_db(), get_current_user(), learnings=learnings)
