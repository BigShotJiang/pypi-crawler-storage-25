"""Context management tools: set_context, refresh_context."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from mimir_mcp import queries
from mimir_mcp.auth import get_current_scopes, get_current_user
from mimir_mcp.db import Database, get_db


def build_boot_summary(db: Database, user_id: str, scopes: list[str]) -> dict:
    """Build the boot-level summary (projects, tasks, reminders, ideas, facts)."""
    items = queries.items_top_level_active(db, scopes, exclude_types=("fact", "reminder"))
    projects = []
    tasks = []
    ideas = []
    for item in items:
        item_type = item["type"]
        slim = slim_item(item, personal_scope=user_id)
        if item_type == "project":
            projects.append(slim)
        elif item_type == "task":
            tasks.append(slim)
        elif item_type == "idea":
            ideas.append(slim)

    reminders_raw = queries.items_reminders_upcoming(db, scopes)
    reminders = [slim_item(r, personal_scope=user_id) for r in reminders_raw]

    facts_raw = queries.items_top_level_facts(db, scopes)
    facts = serialize_facts_flat(facts_raw)

    return {
        "projects": projects,
        "tasks": tasks,
        "ideas": ideas,
        "reminders": reminders,
        "facts": facts,
    }


def serialize_facts_flat(facts_raw) -> list[dict]:
    """Minimal fact shape: {id, summary}. tags & source accessible via get_details."""
    return [{"id": f["id"], "summary": f["summary"]} for f in facts_raw]


def slim_item(row, *, personal_scope: str | None = None) -> dict:
    """Serialize an item for top-level listings.

    Optional fields omitted when null/empty/zero. When `personal_scope` matches
    the item's scope, the `scope` key is omitted from the output.
    """
    out = {
        "id": row["id"],
        "summary": row["summary"],
        "status": row["status"],
    }
    if personal_scope is None or row["scope"] != personal_scope:
        out["scope"] = row["scope"]

    priority = row["priority"] if "priority" in row.keys() else None
    if priority and priority != "normal":
        out["priority"] = priority

    child_count = row["child_count"] if "child_count" in row.keys() else 0
    if child_count:
        out["child_count"] = child_count

    completed_count = row["completed_count"] if "completed_count" in row.keys() else 0
    if completed_count:
        out["completed_count"] = completed_count

    due_date = row["due_date"] if "due_date" in row.keys() else None
    if due_date:
        out["due_date"] = due_date

    return out


def child_slim_item(row) -> dict:
    """Minimal child shape: id, summary, optional due_date only."""
    out = {"id": row["id"], "summary": row["summary"]}
    due_date = row["due_date"] if "due_date" in row.keys() else None
    if due_date:
        out["due_date"] = due_date
    return out


def build_focused_view(db: Database, item_id: int, scopes: list[str]) -> dict:
    """Build the focused view for a specific item: detail + children + item_facts.

    Facts are excluded from `children` — they are returned separately via
    `item_facts` to avoid duplication.
    """
    item_row = queries.items_get_by_id(db, item_id)
    item_detail = dict(item_row)

    children_raw = queries.items_get_children(db, item_id, scopes)
    children: dict[str, list[dict]] = {}
    for child in children_raw:
        if child["type"] == "fact":
            continue
        children.setdefault(child["type"], []).append(child_slim_item(child))

    item_facts_raw = queries.items_facts_for_items(db, [item_id], scopes)
    item_facts = serialize_facts_flat(item_facts_raw)

    return {"item": item_detail, "children": children, "item_facts": item_facts}


def set_context_impl(
    db: Database, user_id: str, scopes: list[str], *, item_id: int | None = None
) -> dict:
    """Return a focused slice (item + children + item_facts) or the boot overview.

    Stateless — does not persist server-side focus.
    """
    if item_id is None:
        return build_boot_summary(db, user_id, scopes)

    item_row = queries.items_get_by_id(db, item_id)
    if not item_row:
        return {"error": f"Item {item_id} not found."}

    if item_row["scope"] not in scopes:
        return {"error": f"Item {item_id} is not in your accessible scopes."}

    return build_focused_view(db, item_id, scopes)


def refresh_context_impl(
    db: Database, user_id: str, scopes: list[str], *, item_id: int | None = None
) -> dict:
    """Refresh the current context view — stateless.

    With item_id=None: returns the top-level boot summary.
    With item_id: returns boot summary merged with focused view for that item.
      Result includes both 'facts' (top-level, from boot) and 'item_facts'
      (parent-scoped, from focused view).
    Always includes scopes, shared activity, and tags_in_use.
    Includes session_activity when an active session exists.
    """
    if item_id is not None:
        item_row = queries.items_get_by_id(db, item_id)
        if not item_row:
            return {"error": f"Item {item_id} not found."}
        if item_row["scope"] not in scopes:
            return {"error": f"Item {item_id} is not in your accessible scopes."}
        result = build_boot_summary(db, user_id, scopes)
        result.update(build_focused_view(db, item_id, scopes))
    else:
        result = build_boot_summary(db, user_id, scopes)

    all_user_scopes = queries.scopes_for_user(db, user_id)
    scope_list = []
    for s in all_user_scopes:
        if s["id"] in scopes:
            scope_list.append(
                {
                    "id": s["id"],
                    "name": s["name"],
                    "description": s["description"],
                    "members": s["member_ids"],
                }
            )
    result["scopes"] = scope_list

    session = queries.sessions_get_active(db, user_id)
    if session:
        activity_raw = queries.items_session_activity(db, session["id"])
        result["session_activity"] = [dict(a) for a in activity_raw]
    else:
        result["session_activity"] = []

    shared_activity_raw = queries.activity_get_shared(db, user_id, scopes)
    result["recent_shared_activity"] = [dict(a) for a in shared_activity_raw]

    result["tags_in_use"] = queries.tags_in_use(db, scopes)

    db.commit()
    return result


def register(mcp):
    """Register context MCP tools."""

    @mcp.tool(name="set_context")
    def set_context_tool(
        item_id: Annotated[
            int | None,
            Field(
                default=None,
                description="Item to focus on — returns its full detail, children, and relevant facts. Pass None to clear focus and return to the top-level overview.",
            ),
        ],
    ) -> dict:
        """Return a focused slice: {item, children, item_facts} where item_facts are only facts with parent_id = item_id. Stateless — does not persist focus on the server. Does not include scopes, tags_in_use, or shared_activity (those are already in your context from boot). Use this to drill into a specific item without a full context rebuild. For a rebuild that includes both boot + focus, use refresh_context(item_id) instead."""
        return set_context_impl(get_db(), get_current_user(), get_current_scopes(), item_id=item_id)

    @mcp.tool(name="refresh_context")
    def refresh_context_tool(
        item_id: Annotated[
            int | None,
            Field(
                default=None,
                description="Reload the focused view for this item. Pass None (default) for the top-level boot summary. Independent of any focus previously set via set_context.",
            ),
        ] = None,
    ) -> dict:
        """Reload your current state view. With no arguments, returns the top-level boot summary. With item_id, returns the boot payload PLUS {item, children, item_facts} for the focused item — a complete post-compaction rebuild. Includes scopes, recent_shared_activity, and top-30 tags_in_use. session_activity is included when an active session exists. Does not require an active session."""
        return refresh_context_impl(
            get_db(), get_current_user(), get_current_scopes(), item_id=item_id
        )
