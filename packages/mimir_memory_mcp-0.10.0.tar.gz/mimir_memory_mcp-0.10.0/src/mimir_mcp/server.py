"""FastMCP server entry point with authentication middleware."""

import os
import sys
from importlib.metadata import PackageNotFoundError, version as pkg_version
from pathlib import Path

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.server.dependencies import get_http_headers
from fastmcp.server.middleware import Middleware, MiddlewareContext

from starlette.requests import Request
from starlette.responses import JSONResponse

from mimir_mcp.auth import resolve_user, set_auth_context
from mimir_mcp.db import Database, get_db, init_db
from mimir_mcp.tools import register_all_tools

MIMIR_API_VERSION = "1"


def _get_package_version() -> str:
    """Return the installed package version, or 'unknown' if metadata is missing."""
    try:
        return pkg_version("mimir-memory-mcp")
    except PackageNotFoundError:
        return "unknown"


def _authenticate(db: Database, api_key: str | None):
    """Shared auth for MCP middleware and REST. Returns (user_id, scopes, is_admin) or None."""
    if not api_key:
        return None
    return resolve_user(db, api_key)


def _execute_seed_sql(db: Database, path: Path) -> None:
    """Execute a seed SQL file with foreign keys enabled."""
    sql = "PRAGMA foreign_keys = ON;\n" + path.read_text()
    db.conn.executescript(sql)
    db.commit()


class AuthMiddleware(Middleware):
    """Extract API key from HTTP headers and set auth context on every tool call."""

    async def on_call_tool(self, context: MiddlewareContext, call_next):
        headers = get_http_headers() or {}
        api_key = headers.get("x-api-key")

        result = _authenticate(get_db(), api_key)
        if result is None:
            raise ToolError("Missing x-api-key header" if not api_key else "Invalid API key")

        user_id, scopes, admin = result
        set_auth_context(user_id, scopes, is_admin=admin)
        return await call_next(context)


def auto_seed(db: Database, seed_file: str | None = None) -> None:
    """Apply seed file if the database has no users yet. Idempotent."""
    if seed_file is None:
        seed_file = os.environ.get("MIMIR_SEED_FILE")
    if not seed_file:
        return

    path = Path(seed_file)
    if not path.exists():
        return

    row = db.fetchone("SELECT COUNT(*) as n FROM users")
    if row and row["n"] > 0:
        return

    _execute_seed_sql(db, path)
    print(f"Seed data loaded from {seed_file}")


def create_server(db_path: str | None = None) -> FastMCP:
    """Create and configure the FastMCP server instance."""
    if db_path is None:
        db_path = os.environ.get("MIMIR_DB_PATH", "/data/mimir.db")

    db = init_db(db_path)
    auto_seed(db)

    mcp = FastMCP(
        name="Mimir",
        instructions=(
            "Mimir is a structured memory server for AI assistants. All data is "
            "scoped to the authenticated user.\n\n"
            "Items are the core unit of memory. Each item has a type (task, project, "
            "fact, reminder, note, idea), belongs to a scope, and has a summary "
            "(short headline) and optional detail (extended description). Items can "
            "form trees: projects, tasks, and ideas can have children; facts, notes, "
            "and reminders cannot (facts may have a parent — see below).\n\n"
            "Scopes are access groups. Each user has a personal scope plus any "
            "shared scopes (e.g., 'household'). You only see items in scopes you "
            "belong to.\n\n"
            "View states:\n"
            "- start_session() / refresh_context() — BOOT: projects/tasks/ideas "
            "(slim), upcoming reminders, TOP-LEVEL facts only (parent_id IS NULL), "
            "top-30 tags_in_use, shared activity. Call start_session once at the "
            "beginning of every conversation; after context compaction, call "
            "refresh_context — NOT start_session (that would create a new session).\n"
            "- set_context(item_id) — DRILL-IN: returns {item, children, item_facts} "
            "for the focused item. Stateless — additive to what you already have from "
            "boot. Does not include scopes, tags_in_use, or shared activity (those "
            "are still in your context from boot).\n"
            "- refresh_context(item_id) — REBUILD: boot payload + focused slice. Use "
            "when your context is compacted AND you need to resume with focus on a "
            "specific item.\n\n"
            "Fact parenting convention:\n"
            "- Facts that apply globally (user profile, cross-cutting principles) "
            "have NO parent (parent_id is omitted/null). They load at boot.\n"
            "- Facts specific to a project/task/idea MUST have that item as their "
            "parent. They load only when the parent is focused (in item_facts).\n"
            "This keeps the boot payload focused on always-relevant context.\n\n"
            "Item shape: boot/refresh responses return slim summaries (optional "
            "fields omitted when empty/zero). Top-level projects/tasks/ideas omit "
            "the `scope` field when it equals your personal scope. Children in "
            "focused views contain only {id, summary, due_date?}. Facts at every "
            "tier return {id, summary} — use get_details([id]) for tags, source, "
            "and full detail.\n\n"
            "Tags:\n"
            "- tags_in_use in the boot/refresh response is capped at 30 per scope "
            "(by usage count). For the full list, call list_tags(scope, extended=True).\n"
            "- When about to create a tagging burst, call list_tags(scope) once; "
            "reuse the result in-context across subsequent add_items calls.\n"
            "- suggest_tag_consolidations(scope) surfaces candidate tag pairs for "
            "merging (typos, plurals, substrings). end_session automatically includes "
            "any candidates in its response.\n"
            "- merge_tags(from_tag, to_tag, scope) atomically renames the tag across "
            "items. Use after reviewing suggestions with the user.\n\n"
            "Session lifecycle:\n"
            "- Call start_session once at conversation start. Idempotent — reuses "
            "the existing open session if one exists.\n"
            "- Call end_session at conversation end. Pass new facts learned as "
            "learnings. If no active session exists, learnings are still recorded "
            "and the activity cursor is still advanced. If the response contains "
            "tag_consolidation_candidates, review them with the user before "
            "finalizing.\n\n"
            "Finding items:\n"
            "- search_items: keyword search with stemming.\n"
            "- list_items: filtered browse by type, status, scope, parent.\n"
            "- get_facts: retrieve facts by tag or parent item.\n"
            "- list_tags: retrieve tags used in a scope (top 30 by default).\n"
        ),
    )
    mcp.add_middleware(AuthMiddleware())
    register_all_tools(mcp)

    # ── REST API (for Claude Code hooks) ────────────────────────────────────
    from mimir_mcp.tools.session import end_session_impl
    from mimir_mcp.tools.search import search_items_impl as search_items
    from mimir_mcp.tools.items import add_items_impl as add_items

    _version_headers = {"X-Mimir-API-Version": MIMIR_API_VERSION}

    def _api_response(data, status_code=200):
        """JSON response with API version header."""
        return JSONResponse(data, status_code=status_code, headers=_version_headers)

    def _rest_auth(request: Request):
        """Validate API key from request headers."""
        api_key = request.headers.get("x-api-key")
        result = _authenticate(db, api_key)
        if result is None:
            msg = "Missing x-api-key" if not api_key else "Invalid API key"
            return None, JSONResponse({"error": msg}, status_code=401)
        user_id, scopes, admin = result
        set_auth_context(user_id, scopes, is_admin=admin)
        return (user_id, scopes), None

    @mcp.custom_route("/health", methods=["GET"])
    async def health(request: Request) -> JSONResponse:
        try:
            db.fetchone("SELECT 1")
            return _api_response({"status": "ok"})
        except Exception as e:
            return _api_response({"status": "error", "detail": str(e)}, status_code=503)

    @mcp.custom_route("/version", methods=["GET"])
    async def version_route(request: Request) -> JSONResponse:
        return _api_response(
            {
                "version": _get_package_version(),
                "api_version": MIMIR_API_VERSION,
            }
        )

    @mcp.custom_route("/api/session/close", methods=["POST"])
    async def rest_close(request: Request) -> JSONResponse:
        auth, err = _rest_auth(request)
        if err:
            return err
        user_id, _ = auth
        result = end_session_impl(db, user_id, learnings=None)
        return _api_response(result)

    @mcp.custom_route("/api/items", methods=["POST"])
    async def rest_create_item(request: Request) -> JSONResponse:
        auth, err = _rest_auth(request)
        if err:
            return err
        user_id, scopes = auth
        body = await request.json()
        result = add_items(db, user_id, scopes, [body])
        return _api_response(result[0] if result else {"error": "No item created"})

    @mcp.custom_route("/api/search", methods=["GET"])
    async def rest_search(request: Request) -> JSONResponse:
        auth, err = _rest_auth(request)
        if err:
            return err
        user_id, scopes = auth
        query = request.query_params.get("q", "")
        result = search_items(db, user_id, scopes, query)
        return _api_response(result)

    return mcp


def run_seed(db_path: str, seed_file: str) -> None:
    """Load a SQL seed file into the database."""
    path = Path(seed_file)
    if not path.exists():
        raise FileNotFoundError(f"Seed file not found: {seed_file}")

    db = Database(db_path)
    db.run_migrations()
    _execute_seed_sql(db, path)
    db.close()
    print(f"Seed data loaded from {seed_file}")


def main():
    """Entry point: run server or seed database."""
    if len(sys.argv) >= 2 and sys.argv[1] == "seed":
        if len(sys.argv) < 4 or sys.argv[2] != "--file":
            print("Usage: mimir-mcp seed --file <path>")
            sys.exit(1)
        db_path = os.environ.get("MIMIR_DB_PATH", "/data/mimir.db")
        run_seed(db_path, sys.argv[3])
    else:
        port = int(os.environ.get("MIMIR_PORT", "8100"))
        server = create_server()
        print(
            f"Mimir v{_get_package_version()} "
            f"(api_version={MIMIR_API_VERSION}) listening on :{port}",
            flush=True,
        )
        server.run(transport="sse", host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()
