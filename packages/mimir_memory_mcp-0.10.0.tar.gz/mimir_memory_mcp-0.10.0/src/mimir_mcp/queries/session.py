"""Domain queries — session lifecycle, activity cursor, users, scopes."""

from __future__ import annotations

from mimir_mcp.db import Database


def sessions_get_or_create(db: Database, user_id: str) -> int:
    """Return the active session ID, creating one if none exists.

    If multiple open sessions exist (orphans), keeps the newest and
    auto-closes the rest with summary 'Auto-closed (superseded)'.
    """
    open_sessions = db.fetchall(
        "SELECT id FROM sessions WHERE user_id = ? AND ended_at IS NULL ORDER BY id DESC",
        (user_id,),
    )

    if not open_sessions:
        cursor = db.execute("INSERT INTO sessions (user_id) VALUES (?)", (user_id,))
        db.commit()
        return cursor.lastrowid

    newest_id = open_sessions[0]["id"]

    if len(open_sessions) > 1:
        orphan_ids = [s["id"] for s in open_sessions[1:]]
        placeholders = ",".join("?" for _ in orphan_ids)
        db.execute(
            f"UPDATE sessions SET ended_at = datetime('now'), summary = 'Auto-closed (superseded)' "
            f"WHERE id IN ({placeholders})",
            tuple(orphan_ids),
        )
        db.commit()

    return newest_id


def sessions_get_last_completed(db: Database, user_id: str):
    return db.fetchone(
        "SELECT * FROM sessions WHERE user_id = ? AND ended_at IS NOT NULL "
        "ORDER BY ended_at DESC LIMIT 1",
        (user_id,),
    )


def sessions_get_active(db: Database, user_id: str):
    return db.fetchone(
        "SELECT * FROM sessions WHERE user_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1",
        (user_id,),
    )


def sessions_end(db: Database, session_id: int, summary: str):
    db.execute(
        "UPDATE sessions SET ended_at = datetime('now'), summary = ? WHERE id = ?",
        (summary, session_id),
    )


def items_session_activity(db: Database, session_id: int):
    """Items created or updated during this session (via history entries)."""
    return db.fetchall(
        "SELECT DISTINCT h.item_id, h.event, h.created_at, i.summary, i.type, i.scope "
        "FROM item_history h "
        "JOIN items i ON h.item_id = i.id "
        "WHERE h.session_id = ? "
        "ORDER BY h.created_at DESC",
        (session_id,),
    )


def activity_get_shared(db: Database, user_id: str, scopes: list[str]):
    """Get shared activity since user's cursor."""
    cursor = db.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = ?",
        (user_id,),
    )
    cursor_id = cursor["last_seen_history_id"] if cursor else 0
    sp = ",".join("?" for _ in scopes)
    return db.fetchall(
        f"SELECT h.*, i.summary, i.scope FROM item_history h "
        f"JOIN items i ON h.item_id = i.id "
        f"WHERE h.id > ? AND h.actor != ? AND i.scope IN ({sp}) "
        f"ORDER BY h.created_at DESC LIMIT 50",
        (cursor_id, user_id, *scopes),
    )


def activity_advance_cursor(db: Database, user_id: str):
    """Advance cursor to the max of item_history IDs and item IDs."""
    max_history = db.fetchone("SELECT MAX(id) as m FROM item_history")
    max_item = db.fetchone("SELECT MAX(id) as m FROM items")
    h_id = max_history["m"] if max_history and max_history["m"] else 0
    i_id = max_item["m"] if max_item and max_item["m"] else 0
    new_cursor = max(h_id, i_id)
    db.execute(
        "UPDATE activity_cursor SET last_seen_history_id = ? WHERE user_id = ?",
        (new_cursor, user_id),
    )


def users_get(db: Database, user_id: str):
    return db.fetchone("SELECT * FROM users WHERE id = ?", (user_id,))


def scopes_for_user(db: Database, user_id: str) -> list:
    return db.fetchall(
        "SELECT s.*, GROUP_CONCAT(DISTINCT sm2.user_id) as member_ids "
        "FROM scopes s "
        "JOIN scope_members sm ON s.id = sm.scope_id "
        "JOIN scope_members sm2 ON s.id = sm2.scope_id "
        "WHERE sm.user_id = ? GROUP BY s.id",
        (user_id,),
    )
