"""Domain queries — item CRUD, children, soft delete, complete, facts."""

from __future__ import annotations

from mimir_mcp.db import Database


def items_insert_full(
    db: Database,
    scope: str,
    type: str,
    status: str,
    summary: str,
    created_by: str,
    *,
    detail: str | None = None,
    parent_id: int | None = None,
    priority: str | None = None,
    due_date: str | None = None,
    valid_until: str | None = None,
    source: str | None = None,
    metadata: str | None = None,
) -> int:
    """Full item insert with all fields including metadata."""
    cursor = db.execute(
        "INSERT INTO items (scope, type, status, summary, detail, parent_id, "
        "priority, due_date, valid_until, source, metadata, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            scope,
            type,
            status,
            summary,
            detail,
            parent_id,
            priority,
            due_date,
            valid_until,
            source,
            metadata,
            created_by,
            created_by,
        ),
    )
    return cursor.lastrowid


def items_update(db: Database, item_id: int, updates: dict, updated_by: str):
    """Update item fields dynamically. Only updates fields present in the dict."""
    if not updates:
        return
    set_parts = []
    params = []
    for field, value in updates.items():
        set_parts.append(f"{field} = ?")
        params.append(value)
    set_parts.append("updated_by = ?")
    params.append(updated_by)
    params.append(item_id)
    sql = f"UPDATE items SET {', '.join(set_parts)} WHERE id = ?"
    db.execute(sql, tuple(params))


def items_delete(db: Database, item_ids: list[int]):
    """Hard delete items by IDs. FK cascade handles children, tags, history."""
    if not item_ids:
        return
    placeholders = ",".join("?" for _ in item_ids)
    db.execute(f"DELETE FROM items WHERE id IN ({placeholders})", tuple(item_ids))


def items_top_level_active(
    db: Database,
    scopes: list[str],
    *,
    exclude_types=(),
    exclude_statuses=("completed", "archived", "deleted"),
):
    """Boot query: top-level active items across scopes."""
    sp = ",".join("?" for _ in scopes)
    tp = ",".join("?" for _ in exclude_types) if exclude_types else None
    stp = ",".join("?" for _ in exclude_statuses)
    sql = (
        f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags, "
        f"(SELECT COUNT(*) FROM items c WHERE c.parent_id = i.id AND c.status != 'deleted') as child_count, "
        f"(SELECT COUNT(*) FROM items c WHERE c.parent_id = i.id AND c.status = 'completed') as completed_count "
        f"FROM items i LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE i.scope IN ({sp}) AND i.parent_id IS NULL "
        f"AND i.status NOT IN ({stp}) "
    )
    params = list(scopes) + list(exclude_statuses)
    if exclude_types:
        sql += f"AND i.type NOT IN ({tp}) "
        params.extend(exclude_types)
    sql += "GROUP BY i.id ORDER BY i.priority, i.position"
    return db.fetchall(sql, tuple(params))


def items_get_by_id(db: Database, item_id: int):
    """Fetch a single item by ID with tags."""
    return db.fetchone(
        "SELECT i.*, GROUP_CONCAT(it.tag_id) as tags "
        "FROM items i LEFT JOIN item_tags it ON i.id = it.item_id "
        "WHERE i.id = ? GROUP BY i.id",
        (item_id,),
    )


def items_get_children(db: Database, parent_id: int, scopes: list[str], *, cascade: bool = False):
    sp = ",".join("?" for _ in scopes)
    if cascade:
        return db.fetchall(
            f"WITH RECURSIVE subtree(id, depth) AS ( "
            f"  SELECT id, 1 FROM items WHERE parent_id = ? "
            f"  UNION ALL "
            f"  SELECT i.id, s.depth + 1 FROM items i JOIN subtree s ON i.parent_id = s.id "
            f"  WHERE s.depth < 10 "
            f") "
            f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags, "
            f"(SELECT COUNT(*) FROM items c WHERE c.parent_id = i.id AND c.status != 'deleted') as child_count, "
            f"(SELECT COUNT(*) FROM items c WHERE c.parent_id = i.id AND c.status = 'completed') as completed_count "
            f"FROM items i "
            f"LEFT JOIN item_tags it ON i.id = it.item_id "
            f"WHERE i.id IN (SELECT id FROM subtree) AND i.scope IN ({sp}) "
            f"GROUP BY i.id ORDER BY i.type, i.position",
            (parent_id, *scopes),
        )
    return db.fetchall(
        f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags, "
        f"(SELECT COUNT(*) FROM items c WHERE c.parent_id = i.id AND c.status != 'deleted') as child_count, "
        f"(SELECT COUNT(*) FROM items c WHERE c.parent_id = i.id AND c.status = 'completed') as completed_count "
        f"FROM items i "
        f"LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE i.parent_id = ? AND i.scope IN ({sp}) "
        f"GROUP BY i.id ORDER BY i.type, i.position",
        (parent_id, *scopes),
    )


def items_get_children_ids(db: Database, parent_id: int, *, cascade: bool = False) -> list[int]:
    """Get child IDs. With cascade=True, returns all descendants recursively."""
    if cascade:
        rows = db.fetchall(
            "WITH RECURSIVE subtree(id, depth) AS ( "
            "  SELECT id, 1 FROM items WHERE parent_id = ? "
            "  UNION ALL "
            "  SELECT i.id, s.depth + 1 FROM items i JOIN subtree s ON i.parent_id = s.id "
            "  WHERE s.depth < 10 "
            ") "
            "SELECT id FROM subtree",
            (parent_id,),
        )
    else:
        rows = db.fetchall(
            "SELECT id FROM items WHERE parent_id = ?",
            (parent_id,),
        )
    return [r["id"] for r in rows]


def items_list(
    db: Database,
    scopes: list[str],
    *,
    type: str | None = None,
    status: str | None = None,
    parent_id: int | None = None,
    scope: str | None = None,
):
    """Flexible listing with filters, sorted by priority then position."""
    effective_scopes = [scope] if scope and scope in scopes else list(scopes)
    sp = ",".join("?" for _ in effective_scopes)

    sql = (
        f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags, "
        f"(SELECT COUNT(*) FROM items c WHERE c.parent_id = i.id AND c.status != 'deleted') as child_count, "
        f"(SELECT COUNT(*) FROM items c WHERE c.parent_id = i.id AND c.status = 'completed') as completed_count "
        f"FROM items i LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE i.scope IN ({sp}) "
    )
    params: list = list(effective_scopes)

    if parent_id is None:
        sql += "AND i.parent_id IS NULL "
    else:
        sql += "AND i.parent_id = ? "
        params.append(parent_id)

    if type:
        sql += "AND i.type = ? "
        params.append(type)

    if status:
        sql += "AND i.status = ? "
        params.append(status)
    else:
        sql += "AND i.status NOT IN ('completed', 'archived', 'deleted') "

    sql += "GROUP BY i.id ORDER BY i.priority, i.position"
    return db.fetchall(sql, tuple(params))


def items_top_level_facts(db: Database, scopes: list[str]):
    """Active (non-expired) facts with no parent (parent_id IS NULL) across the given scopes."""
    sp = ",".join("?" for _ in scopes)
    return db.fetchall(
        f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags "
        f"FROM items i LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE i.scope IN ({sp}) AND i.type = 'fact' "
        f"AND i.parent_id IS NULL "
        f"AND i.status = 'active' "
        f"AND (i.valid_until IS NULL OR i.valid_until > datetime('now')) "
        f"GROUP BY i.id",
        tuple(scopes),
    )


def items_facts_by_tags(db: Database, scopes: list[str], tags: list[str]):
    """Facts matching any of given tags (OR logic), filtered by scope."""
    sp = ",".join("?" for _ in scopes)
    tp = ",".join("?" for _ in tags)
    return db.fetchall(
        f"SELECT i.*, GROUP_CONCAT(it2.tag_id) as tags "
        f"FROM items i "
        f"JOIN item_tags it ON i.id = it.item_id "
        f"LEFT JOIN item_tags it2 ON i.id = it2.item_id "
        f"WHERE i.type = 'fact' AND i.scope IN ({sp}) "
        f"AND it.tag_id IN ({tp}) "
        f"AND i.status NOT IN ('completed', 'archived', 'deleted') "
        f"GROUP BY i.id",
        (*scopes, *tags),
    )


def items_facts_for_items(db: Database, item_ids: list[int], scopes: list[str]):
    """Facts that are children of given items, filtered by scope."""
    sp = ",".join("?" for _ in scopes)
    ip = ",".join("?" for _ in item_ids)
    return db.fetchall(
        f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags "
        f"FROM items i LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE i.type = 'fact' AND i.parent_id IN ({ip}) "
        f"AND i.scope IN ({sp}) "
        f"AND i.status NOT IN ('completed', 'archived', 'deleted') "
        f"GROUP BY i.id",
        (*item_ids, *scopes),
    )


def items_facts_for_descendants(db, item_ids: list[int], scopes: list[str]) -> list:
    """Retrieve facts that are descendants (any depth) of the given items."""
    id_placeholders = ",".join("?" * len(item_ids))
    sp = ",".join("?" * len(scopes))
    sql = f"""
        WITH RECURSIVE descendants(id) AS (
            SELECT id FROM items WHERE parent_id IN ({id_placeholders})
            UNION ALL
            SELECT i.id FROM items i JOIN descendants d ON i.parent_id = d.id
        )
        SELECT i.*, GROUP_CONCAT(it.tag_id) as tags
        FROM items i
        LEFT JOIN item_tags it ON i.id = it.item_id
        WHERE i.id IN (SELECT id FROM descendants)
          AND i.type = 'fact'
          AND i.scope IN ({sp})
          AND i.status NOT IN ('completed', 'archived', 'deleted')
        GROUP BY i.id
    """
    return db.fetchall(sql, (*item_ids, *scopes))


def items_soft_delete(db, item_ids: list[int], user_id: str) -> int:
    """Soft-delete items and all descendants by setting status to 'deleted'."""
    deleted_count = 0
    for item_id in item_ids:
        child_ids = items_get_children_ids(db, item_id, cascade=True)
        all_ids = [item_id] + child_ids
        placeholders = ",".join("?" * len(all_ids))
        db.execute(
            f"UPDATE items SET status = 'deleted', updated_by = ? WHERE id IN ({placeholders})",
            (user_id, *all_ids),
        )
        deleted_count += len(all_ids)
    return deleted_count


def items_complete_with_descendants(db, item_id: int, user_id: str) -> list[int]:
    """Complete an item and all its descendants. Returns list of completed IDs."""
    child_ids = items_get_children_ids(db, item_id, cascade=True)
    all_ids = [item_id] + child_ids
    placeholders = ",".join("?" * len(all_ids))
    db.execute(
        f"UPDATE items SET status = 'completed', updated_by = ? WHERE id IN ({placeholders}) AND status != 'completed'",
        (user_id, *all_ids),
    )
    return all_ids


def items_reminders_upcoming(db: Database, scopes: list[str]):
    """Reminders due within 7 days that have a due_date set."""
    sp = ",".join("?" for _ in scopes)
    return db.fetchall(
        f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags "
        f"FROM items i LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE i.scope IN ({sp}) AND i.type = 'reminder' "
        f"AND i.status NOT IN ('completed', 'archived', 'deleted') "
        f"AND i.due_date IS NOT NULL "
        f"AND i.due_date <= datetime('now', '+7 days') "
        f"GROUP BY i.id ORDER BY i.due_date",
        tuple(scopes),
    )


def items_recent_by_others(db: Database, user_id: str, scopes: list[str]):
    """Items recently created or updated by other users in shared scopes."""
    cursor = db.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = ?",
        (user_id,),
    )
    cursor_id = cursor["last_seen_history_id"] if cursor else 0
    sp = ",".join("?" for _ in scopes)
    return db.fetchall(
        f"SELECT * FROM items "
        f"WHERE scope IN ({sp}) AND created_by != ? AND id > ? "
        f"ORDER BY created_at DESC LIMIT 50",
        (*scopes, user_id, cursor_id),
    )


def item_tags_clear(db: Database, item_id: int):
    """Remove all tags from an item."""
    db.execute("DELETE FROM item_tags WHERE item_id = ?", (item_id,))


def item_tags_insert(db: Database, item_id: int, tag_ids: list[str]):
    """Insert tags for an item."""
    if not tag_ids:
        return
    db.executemany(
        "INSERT INTO item_tags (item_id, tag_id) VALUES (?, ?)",
        [(item_id, tag_id) for tag_id in tag_ids],
    )


def build_diff(old_row, updates: dict) -> list[dict]:
    """Build a structured diff between old row and new values."""
    diffs = []
    for field, new_val in updates.items():
        old_val = old_row[field] if field in old_row.keys() else None
        if str(old_val) != str(new_val):
            diffs.append({"field": field, "old": old_val, "new": new_val})
    return diffs
