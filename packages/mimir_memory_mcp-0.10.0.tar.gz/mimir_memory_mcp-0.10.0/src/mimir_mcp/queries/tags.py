"""Domain queries — tag operations."""

from __future__ import annotations

from mimir_mcp.db import Database

TAGS_IN_USE_LIMIT_PER_SCOPE = 30


def tags_in_use(db: Database, scopes: list[str]) -> dict[str, list[str]]:
    """Return the top-30 most-used tags per scope, keyed by scope id.

    Includes tags from items in all statuses — historical tags remain useful
    for consistent naming. Ordered by usage count (descending) then tag name.
    """
    if not scopes:
        return {}
    sp = ",".join("?" for _ in scopes)
    rows = db.fetchall(
        f"SELECT i.scope, it.tag_id, COUNT(*) as cnt "
        f"FROM item_tags it "
        f"JOIN items i ON it.item_id = i.id "
        f"WHERE i.scope IN ({sp}) "
        f"GROUP BY i.scope, it.tag_id "
        f"ORDER BY i.scope, cnt DESC, it.tag_id ASC",
        tuple(scopes),
    )
    result: dict[str, list[str]] = {}
    for row in rows:
        bucket = result.setdefault(row["scope"], [])
        if len(bucket) < TAGS_IN_USE_LIMIT_PER_SCOPE:
            bucket.append(row["tag_id"])
    return result


def tags_with_counts(db: Database, scope: str) -> list[dict]:
    """All tags in a scope with their usage counts, ordered by count desc."""
    rows = db.fetchall(
        "SELECT it.tag_id as name, COUNT(*) as count "
        "FROM item_tags it JOIN items i ON it.item_id = i.id "
        "WHERE i.scope = ? "
        "GROUP BY it.tag_id "
        "ORDER BY count DESC, name ASC",
        (scope,),
    )
    return [{"name": r["name"], "count": r["count"]} for r in rows]
