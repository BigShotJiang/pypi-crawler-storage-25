-- Migration 002: drop sessions.active_context_id
--
-- Server-side focus is obsoleted by the parent-based fact model.
-- SQLite pre-3.35 lacks ALTER TABLE DROP COLUMN, so use the recreate pattern
-- (portable and works on every deployment regardless of SQLite version).
--
-- FK toggling: item_history.session_id REFERENCES sessions(id). Dropping and
-- renaming the referenced table with FKs enforced fails when any history row
-- has session_id set, so FKs are disabled for the duration of the swap and
-- re-enabled at the end. This is the SQLite-recommended pattern for table
-- recreation under referential integrity.

PRAGMA foreign_keys = OFF;

CREATE TABLE sessions_new (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL REFERENCES users(id),
    started_at  TEXT NOT NULL DEFAULT (datetime('now')),
    ended_at    TEXT,
    summary     TEXT,
    log_path    TEXT
);

INSERT INTO sessions_new (id, user_id, started_at, ended_at, summary, log_path)
SELECT id, user_id, started_at, ended_at, summary, log_path FROM sessions;

DROP TABLE sessions;
ALTER TABLE sessions_new RENAME TO sessions;

CREATE INDEX idx_sessions_user ON sessions(user_id, ended_at);

PRAGMA foreign_keys = ON;
