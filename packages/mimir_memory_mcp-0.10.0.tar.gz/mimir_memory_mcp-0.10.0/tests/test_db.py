import pytest
import sqlite3
from pathlib import Path

from mimir_mcp.db import Database

MIGRATIONS_DIR = Path(__file__).parent.parent / "src" / "mimir_mcp" / "migrations"


def test_migration_creates_tables(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    db.run_migrations(MIGRATIONS_DIR)
    tables = [
        row[0]
        for row in db.fetchall("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
    ]
    expected = [
        "activity_cursor",
        "item_history",
        "item_tags",
        "items",
        "schema_version",
        "scope_members",
        "scopes",
        "sessions",
        "tags",
        "users",
    ]
    for t in expected:
        assert t in tables, f"Missing table: {t}"
    db.close()


def test_schema_version_is_2(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    db.run_migrations(MIGRATIONS_DIR)
    assert db.get_schema_version() == 2
    db.close()


def test_foreign_keys_enabled(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    db.run_migrations(MIGRATIONS_DIR)
    result = db.fetchone("PRAGMA foreign_keys")
    assert result[0] == 1
    db.close()


def test_migration_is_idempotent(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    db.run_migrations(MIGRATIONS_DIR)
    db.run_migrations(MIGRATIONS_DIR)
    assert db.get_schema_version() == 2
    db.close()


def test_fts5_index_exists(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    db.run_migrations(MIGRATIONS_DIR)
    tables = [
        row[0]
        for row in db.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%fts%'"
        )
    ]
    assert "items_fts" in tables
    db.close()


# --- SQL access enforcement trigger tests ---


def test_insert_trigger_rejects_wrong_scope(seed_data):
    """enforce_insert_access rejects items in scopes the user doesn't belong to."""
    with pytest.raises(sqlite3.IntegrityError, match="does not have access to this scope"):
        seed_data.execute(
            "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            ("alex", "task", "not_started", "Sneaky task", "jimmy", "jimmy"),
        )


def test_insert_trigger_rejects_cross_scope_parent(seed_data):
    """Child must belong to same scope as parent."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "project", "not_started", "Parent", "jimmy", "jimmy"),
    )
    parent_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.commit()
    with pytest.raises(sqlite3.IntegrityError, match="same scope as parent"):
        seed_data.execute(
            "INSERT INTO items (parent_id, scope, type, status, summary, created_by, updated_by) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (parent_id, "jimmy", "task", "not_started", "Wrong scope child", "jimmy", "jimmy"),
        )


def test_update_trigger_rejects_wrong_scope(seed_data):
    """enforce_update_access rejects updates by users outside the item's scope."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("jimmy", "task", "not_started", "Jimmy's task", "jimmy", "jimmy"),
    )
    seed_data.commit()
    item_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    with pytest.raises(sqlite3.IntegrityError, match="does not have access"):
        seed_data.execute(
            "UPDATE items SET summary = 'Hacked', updated_by = 'alex' WHERE id = ?",
            (item_id,),
        )


# --- FTS5 sync trigger tests ---


def test_fts5_insert_sync(seed_data):
    """Inserting an item makes it searchable via FTS5."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "fact", "active", "Alex is allergic to shellfish", "jimmy", "jimmy"),
    )
    seed_data.commit()
    results = seed_data.fetchall("SELECT rowid FROM items_fts WHERE items_fts MATCH 'shellfish'")
    assert len(results) == 1


def test_fts5_update_sync(seed_data):
    """Updating summary updates the FTS5 index."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "fact", "active", "Old summary text", "jimmy", "jimmy"),
    )
    seed_data.commit()
    item_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute(
        "UPDATE items SET summary = 'New summary about dolphins', updated_by = 'jimmy' "
        "WHERE id = ?",
        (item_id,),
    )
    seed_data.commit()
    old = seed_data.fetchall("SELECT rowid FROM items_fts WHERE items_fts MATCH 'Old'")
    new = seed_data.fetchall("SELECT rowid FROM items_fts WHERE items_fts MATCH 'dolphins'")
    assert len(old) == 0
    assert len(new) == 1


def test_fts5_delete_sync(seed_data):
    """Deleting an item removes it from FTS5 index."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "fact", "active", "Temporary fact about penguins", "jimmy", "jimmy"),
    )
    seed_data.commit()
    item_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("DELETE FROM items WHERE id = ?", (item_id,))
    seed_data.commit()
    results = seed_data.fetchall("SELECT rowid FROM items_fts WHERE items_fts MATCH 'penguins'")
    assert len(results) == 0
