from mimir_mcp.tools.session import boot_session_impl
from mimir_mcp.tools.context import (
    set_context_impl as set_context,
    refresh_context_impl as refresh_context,
)


# --- Helpers ---


def _create_project(db, scope, summary, *, created_by="jimmy", detail=None):
    """Insert a project item and return its id."""
    db.execute(
        "INSERT INTO items (scope, type, status, summary, detail, created_by, updated_by) "
        "VALUES (?, 'project', 'in_progress', ?, ?, ?, ?)",
        (scope, summary, detail, created_by, created_by),
    )
    db.commit()
    return db.fetchone("SELECT last_insert_rowid() as id")["id"]


def _create_child(db, parent_id, scope, item_type, summary, *, created_by="jimmy"):
    """Insert a child item under a parent and return its id."""
    db.execute(
        "INSERT INTO items (parent_id, scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, 'not_started', ?, ?, ?)",
        (parent_id, scope, item_type, summary, created_by, created_by),
    )
    db.commit()
    return db.fetchone("SELECT last_insert_rowid() as id")["id"]


def _create_fact(db, scope, summary, *, tag=None, detail=None, created_by="jimmy"):
    """Insert a fact item and optionally tag it. Returns item id."""
    db.execute(
        "INSERT INTO items (scope, type, status, summary, detail, created_by, updated_by) "
        "VALUES (?, 'fact', 'active', ?, ?, ?, ?)",
        (scope, summary, detail, created_by, created_by),
    )
    db.commit()
    fact_id = db.fetchone("SELECT last_insert_rowid() as id")["id"]
    if tag:
        db.execute("INSERT INTO item_tags VALUES (?, ?)", (fact_id, tag))
        db.commit()
    return fact_id


# --- Tests ---


def test_set_context_returns_item_and_children(seed_data):
    """set_context returns item detail + children. No longer persists focus server-side."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(
        seed_data, "jimmy", "Provider Ops", detail="Full project details here"
    )
    _create_child(seed_data, proj_id, "jimmy", "task", "Set up DNS")

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert result["item"]["id"] == proj_id
    assert result["item"]["detail"] == "Full project details here"

    all_children = []
    for children_of_type in result["children"].values():
        all_children.extend(children_of_type)
    assert len(all_children) >= 1


def test_set_context_does_not_persist_focus(seed_data):
    """Confirms set_context is stateless: no active_context_id written (column is gone)."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)
    proj_id = _create_project(seed_data, "jimmy", "X")

    set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    cols = [r["name"] for r in seed_data.fetchall("PRAGMA table_info(sessions)")]
    assert "active_context_id" not in cols


def test_set_context_returns_children_grouped_by_type(seed_data):
    """Children come back grouped by type (tasks, notes, etc.)."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Multi-child Project")
    _create_child(seed_data, proj_id, "jimmy", "task", "Task A")
    _create_child(seed_data, proj_id, "jimmy", "task", "Task B")
    _create_child(seed_data, proj_id, "jimmy", "note", "Note about project")

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert "task" in result["children"]
    assert "note" in result["children"]
    assert len(result["children"]["task"]) == 2
    assert len(result["children"]["note"]) == 1


def test_set_context_returns_facts_as_flat_list(seed_data):
    """Focused view returns item_facts — only facts whose parent_id == focused item."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Some project")
    # Global fact (no parent) — must NOT appear in item_facts
    _create_fact(seed_data, "household", "Alex is allergic to shellfish", tag="health")
    # Fact parented to the focused project — must appear in item_facts
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, parent_id, created_by, updated_by) "
        "VALUES ('jimmy', 'fact', 'active', 'Project-scoped fact', ?, 'jimmy', 'jimmy')",
        (proj_id,),
    )
    seed_data.commit()

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert "item_facts" in result
    assert isinstance(result["item_facts"], list)
    assert any(f["summary"] == "Project-scoped fact" for f in result["item_facts"])
    # Global fact must NOT appear
    assert not any(f["summary"] == "Alex is allergic to shellfish" for f in result["item_facts"])
    # Old key names must not appear
    assert "facts" not in result
    assert "global_facts" not in result


def test_focused_view_returns_item_facts_only(seed_data):
    """set_context(item_id) returns only facts whose parent_id == item_id."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "P")
    _create_fact(seed_data, "jimmy", "Global fact")  # no parent
    # Fact under project
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, parent_id, created_by, updated_by) "
        "VALUES ('jimmy', 'fact', 'active', 'Project fact', ?, 'jimmy', 'jimmy')",
        (proj_id,),
    )
    seed_data.commit()

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)
    assert "item_facts" in result
    assert "facts" not in result  # renamed — no collision with top-level key
    summaries = [f["summary"] for f in result["item_facts"]]
    assert summaries == ["Project fact"]


def test_focused_view_does_not_duplicate_facts_in_children(seed_data):
    """Facts parented to the focused item appear only in item_facts, not also in children."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Dedup project")
    _create_child(seed_data, proj_id, "jimmy", "task", "Child task")
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, parent_id, created_by, updated_by) "
        "VALUES ('jimmy', 'fact', 'active', 'Project fact', ?, 'jimmy', 'jimmy')",
        (proj_id,),
    )
    seed_data.commit()

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert any(f["summary"] == "Project fact" for f in result["item_facts"])
    assert "fact" not in result["children"]
    assert "task" in result["children"]


def test_clear_context(seed_data):
    """set_context(None) returns boot-level summary (stateless — no DB column written)."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    # First focus on a project
    proj_id = _create_project(seed_data, "jimmy", "Focused project")
    set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    # Now clear — result should look like boot summary (has projects/tasks/etc.)
    result = set_context(seed_data, "jimmy", scopes, item_id=None)

    assert "projects" in result
    assert "tasks" in result
    assert "reminders" in result
    assert "ideas" in result


def test_refresh_context_is_stateless_ignores_set_context(seed_data):
    """refresh_context() without item_id returns boot summary even after set_context."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Refresh target", detail="Detail text")
    _create_child(seed_data, proj_id, "jimmy", "task", "Child task")
    set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    # No item_id passed — should return boot summary, not the previously focused item
    result = refresh_context(seed_data, "jimmy", scopes)

    assert "projects" in result
    assert "item" not in result
    assert "children" not in result


def test_refresh_context_with_item_id_returns_focused_view(seed_data):
    """refresh_context(item_id=X) returns the focused view regardless of session state."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Target", detail="Full detail here")
    _create_child(seed_data, proj_id, "jimmy", "task", "Child")

    result = refresh_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert result["item"]["id"] == proj_id
    assert result["item"]["detail"] == "Full detail here"
    assert "children" in result


def test_refresh_context_with_unknown_item_returns_error(seed_data):
    """Unknown item_id produces an error response."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    result = refresh_context(seed_data, "jimmy", scopes, item_id=999999)

    assert "error" in result


def test_refresh_context_with_forbidden_scope_returns_error(seed_data):
    """Item in a scope the user can't access produces an error."""
    jimmy_scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", jimmy_scopes)

    alex_proj = _create_project(seed_data, "alex", "Alex project", created_by="alex")

    result = refresh_context(seed_data, "jimmy", jimmy_scopes, item_id=alex_proj)

    assert "error" in result


def test_refresh_context_with_no_focus(seed_data):
    """Without active focus, refresh returns boot summary."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    _create_project(seed_data, "jimmy", "Visible project")

    result = refresh_context(seed_data, "jimmy", scopes)

    assert "projects" in result
    assert "tasks" in result
    assert "reminders" in result
    assert "ideas" in result


def test_refresh_context_returns_session_activity(seed_data):
    """Items created/updated during this session are included."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    # Get the session_id
    session = seed_data.fetchone(
        "SELECT id FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    session_id = session["id"]

    # Create an item and record history tied to this session
    proj_id = _create_project(seed_data, "jimmy", "Session project")
    seed_data.execute(
        "INSERT INTO item_history (item_id, event, content, actor, session_id) "
        "VALUES (?, 'created', 'Created during session', 'jimmy', ?)",
        (proj_id, session_id),
    )
    seed_data.commit()

    result = refresh_context(seed_data, "jimmy", scopes)

    assert "session_activity" in result
    assert len(result["session_activity"]) >= 1
    assert any(a["item_id"] == proj_id for a in result["session_activity"])


def test_refresh_context_returns_scopes(seed_data):
    """Scopes are included in the refresh response."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    result = refresh_context(seed_data, "jimmy", scopes)

    assert "scopes" in result
    scope_ids = [s["id"] for s in result["scopes"]]
    assert "jimmy" in scope_ids
    assert "household" in scope_ids


def test_scope_enforcement(seed_data):
    """Can't set_context on an item outside user's scopes."""
    # Boot jimmy's session with only jimmy's scopes (not alex)
    jimmy_scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", jimmy_scopes)

    # Create an item in alex's personal scope (alex creates it)
    alex_item_id = _create_project(seed_data, "alex", "Alex private project", created_by="alex")

    # Jimmy tries to focus on alex's item — should fail
    result = set_context(seed_data, "jimmy", jimmy_scopes, item_id=alex_item_id)

    assert "error" in result


def test_facts_are_flat_slim_list_in_context_views(seed_data):
    """facts in boot summary, focused view, and refresh output are a flat slim list of {id, summary}."""
    from mimir_mcp.tools.context import build_boot_summary, build_focused_view, refresh_context_impl

    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    fact_id = _create_fact(
        seed_data,
        "jimmy",
        "Uses Malaysia Nomad Visa",
        tag="visa",
        detail="Verbose multi-line content that should not leak into boot responses.",
    )
    # Add a second tag on the same fact (tags are drill-down only, not in slim shape)
    seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (fact_id, "legal"))
    seed_data.commit()

    def _assert_slim_fact(fact):
        assert set(fact.keys()) == {"id", "summary"}, (
            f"unexpected keys in slim fact: {set(fact.keys())}"
        )
        assert fact["id"] == fact_id
        assert fact["summary"] == "Uses Malaysia Nomad Visa"

    # Path 1: build_boot_summary
    boot = build_boot_summary(seed_data, "jimmy", scopes)
    assert "facts" in boot and "global_facts" not in boot
    assert isinstance(boot["facts"], list)
    # Fact must appear exactly once (no tag-duplication)
    matching = [f for f in boot["facts"] if f["id"] == fact_id]
    assert len(matching) == 1
    _assert_slim_fact(matching[0])

    # Path 2: build_focused_view — returns item_facts (parent-scoped only)
    proj_id = _create_project(seed_data, "jimmy", "Focus target")
    # Attach the fact to the project so it appears in item_facts
    seed_data.execute("UPDATE items SET parent_id = ? WHERE id = ?", (proj_id, fact_id))
    seed_data.commit()
    focused = build_focused_view(seed_data, proj_id, scopes)
    assert "item_facts" in focused and "facts" not in focused and "global_facts" not in focused
    matching = [f for f in focused["item_facts"] if f["id"] == fact_id]
    assert len(matching) == 1
    _assert_slim_fact(matching[0])
    # Detach the fact so Path 3 (boot) picks it up as a top-level fact
    seed_data.execute("UPDATE items SET parent_id = NULL WHERE id = ?", (fact_id,))
    seed_data.commit()

    # Path 3: refresh_context_impl (no focus → boot summary path)
    refreshed = refresh_context_impl(seed_data, "jimmy", scopes)
    assert "facts" in refreshed and "global_facts" not in refreshed
    matching = [f for f in refreshed["facts"] if f["id"] == fact_id]
    assert len(matching) == 1
    _assert_slim_fact(matching[0])


def test_facts_untagged_has_minimal_shape(seed_data):
    """An untagged fact comes back with exactly {id, summary} — no tags key at all."""
    from mimir_mcp.tools.context import build_boot_summary

    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    fact_id = _create_fact(seed_data, "jimmy", "Untagged fact")

    boot = build_boot_summary(seed_data, "jimmy", scopes)
    matching = [f for f in boot["facts"] if f["id"] == fact_id]
    assert len(matching) == 1
    assert set(matching[0].keys()) == {"id", "summary"}


def test_get_details_still_returns_fact_detail(seed_data):
    """get_details_impl returns the full detail field even after boot paths strip it."""
    from mimir_mcp.tools.navigation import get_details_impl

    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    fact_id = _create_fact(
        seed_data,
        "jimmy",
        "Important fact",
        tag="visa",
        detail="Detail that must survive.",
    )

    results = get_details_impl(seed_data, "jimmy", scopes, [fact_id])
    assert len(results) == 1
    assert results[0]["detail"] == "Detail that must survive."


def test_boot_projects_use_slim_shape(seed_data):
    """Top-level projects in boot are slimmed: no detail, no created_at, includes child/completed counts when > 0."""
    from mimir_mcp.tools.context import build_boot_summary

    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(
        seed_data, "jimmy", "Slim test project", detail="Lots of detail that should be hidden"
    )
    # Tags are no longer included in slim items — tag insertion kept for DB integrity test only
    seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (proj_id, "work"))
    seed_data.commit()

    # 3 children, 2 completed
    c1 = _create_child(seed_data, proj_id, "jimmy", "task", "Task A")
    c2 = _create_child(seed_data, proj_id, "jimmy", "task", "Task B")
    _create_child(seed_data, proj_id, "jimmy", "task", "Task C")
    seed_data.execute("UPDATE items SET status = 'completed' WHERE id IN (?, ?)", (c1, c2))
    seed_data.commit()

    boot = build_boot_summary(seed_data, "jimmy", scopes)
    matching = [p for p in boot["projects"] if p["id"] == proj_id]
    assert len(matching) == 1
    proj = matching[0]

    # Required keys present
    assert proj["id"] == proj_id
    assert proj["summary"] == "Slim test project"
    assert proj["status"] == "in_progress"
    # scope omitted for personal-scope items (jimmy == personal_scope)
    assert "scope" not in proj
    # priority="normal" is now omitted (noise elimination)
    assert "priority" not in proj
    # tags dropped from slim items entirely
    assert "tags" not in proj
    # counts present when > 0
    assert proj["child_count"] == 3
    assert proj["completed_count"] == 2
    # Slim: detail, created_at, parent_id must NOT appear
    assert "detail" not in proj
    assert "created_at" not in proj
    assert "parent_id" not in proj
    assert "updated_at" not in proj


def test_boot_project_with_no_children_omits_counts(seed_data):
    """A project with zero children has child_count and completed_count absent."""
    from mimir_mcp.tools.context import build_boot_summary

    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Childless project")

    boot = build_boot_summary(seed_data, "jimmy", scopes)
    proj = next(p for p in boot["projects"] if p["id"] == proj_id)
    assert "child_count" not in proj
    assert "completed_count" not in proj


def test_boot_project_zero_completed_omits_completed_count(seed_data):
    """A project with children but none completed: child_count present, completed_count absent."""
    from mimir_mcp.tools.context import build_boot_summary

    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "No completions project")
    _create_child(seed_data, proj_id, "jimmy", "task", "A")
    _create_child(seed_data, proj_id, "jimmy", "task", "B")

    boot = build_boot_summary(seed_data, "jimmy", scopes)
    proj = next(p for p in boot["projects"] if p["id"] == proj_id)
    assert proj["child_count"] == 2
    assert "completed_count" not in proj


def test_focused_view_children_are_minimal(seed_data):
    """Children in focused views contain only id, summary, and optional due_date."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Proj")
    t1 = _create_child(seed_data, proj_id, "jimmy", "task", "Due soon")
    seed_data.execute("UPDATE items SET due_date = datetime('now','+1 day') WHERE id = ?", (t1,))
    _create_child(seed_data, proj_id, "jimmy", "task", "No deadline")
    seed_data.commit()

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)
    tasks = result["children"]["task"]

    by_summary = {t["summary"]: t for t in tasks}
    assert set(by_summary["Due soon"].keys()) == {"id", "summary", "due_date"}
    assert set(by_summary["No deadline"].keys()) == {"id", "summary"}


def test_focused_children_use_slim_shape_and_item_keeps_detail(seed_data):
    """build_focused_view: children are slim, but the focused item retains full detail."""
    from mimir_mcp.tools.context import build_focused_view

    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Parent with detail", detail="Important detail")
    child_id = _create_child(seed_data, proj_id, "jimmy", "task", "Child task")

    focused = build_focused_view(seed_data, proj_id, scopes)

    # Focused item keeps its full detail
    assert focused["item"]["id"] == proj_id
    assert focused["item"]["detail"] == "Important detail"
    assert "created_at" in focused["item"]  # full row preserved

    # Children use slim shape
    assert "task" in focused["children"]
    child = focused["children"]["task"][0]
    assert child["id"] == child_id
    assert child["summary"] == "Child task"
    assert "detail" not in child
    assert "created_at" not in child


def test_set_context_response_has_no_tags_in_use(seed_data):
    """set_context never attaches tags_in_use — regression lock for Task 3 removal."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)
    proj_id = _create_project(seed_data, "jimmy", "P")
    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)
    assert "tags_in_use" not in result


def test_set_context_works_without_session(seed_data):
    """set_context does not require an active session."""
    scopes = ["jimmy", "household"]
    proj_id = _create_project(seed_data, "jimmy", "No-session project", detail="Detail")
    _create_child(seed_data, proj_id, "jimmy", "task", "Child task")

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert result["item"]["id"] == proj_id
    assert "error" not in result


def test_set_context_none_works_without_session(seed_data):
    """set_context(None) returns boot summary without a session."""
    scopes = ["jimmy", "household"]
    result = set_context(seed_data, "jimmy", scopes, item_id=None)

    assert "projects" in result
    assert "error" not in result


def test_refresh_context_works_without_session(seed_data):
    """refresh_context does not require an active session."""
    scopes = ["jimmy", "household"]
    proj_id = _create_project(seed_data, "jimmy", "Refresh no-session")

    result = refresh_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert result["item"]["id"] == proj_id
    assert "error" not in result


def test_refresh_context_no_session_omits_session_activity(seed_data):
    """Without an active session, session_activity is an empty list."""
    scopes = ["jimmy", "household"]
    result = refresh_context(seed_data, "jimmy", scopes)

    assert result["session_activity"] == []
