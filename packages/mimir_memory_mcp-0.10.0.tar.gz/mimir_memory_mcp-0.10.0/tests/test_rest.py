"""Tests for REST API endpoints (non-MCP HTTP routes)."""

import pytest
from starlette.testclient import TestClient

from mimir_mcp.server import create_server, auto_seed
from mimir_mcp.db import get_db


@pytest.fixture
def client(tmp_path):
    """Create a test client for the Mimir REST API.

    Uses check_same_thread=False because TestClient runs requests
    in a different thread than where the DB was created.
    """
    db_path = str(tmp_path / "test.db")
    seed_file = tmp_path / "seed.sql"
    seed_file.write_text(
        "INSERT INTO users (id, name, is_admin, api_key) VALUES ('jimmy', 'Jimmy', TRUE, 'key-jimmy');\n"
        "INSERT INTO scopes (id, name, description) VALUES ('jimmy', 'Jimmy', 'Personal');\n"
        "INSERT INTO scope_members (scope_id, user_id) VALUES ('jimmy', 'jimmy');\n"
        "INSERT INTO activity_cursor (user_id, last_seen_history_id) VALUES ('jimmy', 0);\n"
    )
    server = create_server(db_path=db_path)
    # Allow cross-thread access for TestClient
    db = get_db()
    db.conn.close()
    import sqlite3

    db.conn = sqlite3.connect(db_path, check_same_thread=False)
    db.conn.row_factory = sqlite3.Row
    db.conn.execute("PRAGMA foreign_keys = ON")
    auto_seed(db, str(seed_file))
    app = server.http_app()
    return TestClient(app)


class TestHealthEndpoint:
    def test_health_ok(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"


class TestVersionEndpoint:
    def test_version_returns_200_and_shape(self, client):
        resp = client.get("/version")
        assert resp.status_code == 200
        body = resp.json()
        assert "version" in body
        assert isinstance(body["version"], str)
        assert body["version"]  # non-empty; "unknown" is accepted when metadata unavailable
        assert body["api_version"] == "1"

    def test_version_no_auth_required(self, client):
        # No x-api-key header — still returns 200
        resp = client.get("/version")
        assert resp.status_code == 200

    def test_version_includes_api_version_header(self, client):
        resp = client.get("/version")
        assert resp.headers.get("X-Mimir-API-Version") == "1"


class TestAuthFailures:
    def test_close_missing_api_key(self, client):
        resp = client.post("/api/session/close")
        assert resp.status_code == 401

    def test_search_missing_api_key(self, client):
        resp = client.get("/api/search?q=test")
        assert resp.status_code == 401

    def test_items_missing_api_key(self, client):
        resp = client.post("/api/items", json={"scope": "jimmy", "type": "task", "summary": "test"})
        assert resp.status_code == 401


class TestCloseEndpoint:
    def test_close_no_session(self, client):
        resp = client.post("/api/session/close", headers={"x-api-key": "key-jimmy"})
        assert resp.status_code == 200
        assert "No active session" in resp.json()["summary"]


class TestSearchEndpoint:
    def test_search_empty_results(self, client):
        resp = client.get("/api/search?q=nonexistent", headers={"x-api-key": "key-jimmy"})
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


class TestItemsEndpoint:
    def test_create_item(self, client):
        body = {"scope": "jimmy", "type": "task", "summary": "Test task from REST"}
        resp = client.post("/api/items", json=body, headers={"x-api-key": "key-jimmy"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["summary"] == "Test task from REST"
        assert data["type"] == "task"
        assert isinstance(data, dict)

    def test_create_item_wrong_scope(self, client):
        body = {"scope": "nonexistent", "type": "task", "summary": "Should fail"}
        resp = client.post("/api/items", json=body, headers={"x-api-key": "key-jimmy"})
        assert resp.status_code == 200
        data = resp.json()
        assert "error" in data
