"""Test migration 002 drops active_context_id while preserving session data."""

from pathlib import Path


from mimir_mcp.db import Database


MIGRATIONS_DIR = Path(__file__).parent.parent / "src" / "mimir_mcp" / "migrations"


def _apply_only(db: Database, *names: str) -> None:
    """Apply a fixed list of migration files in order."""
    for name in names:
        path = MIGRATIONS_DIR / name
        db.conn.executescript(path.read_text())
        db.conn.execute(
            "INSERT OR IGNORE INTO schema_version (version) VALUES (?)",
            (int(name.split("_")[0]),),
        )
        db.commit()


def test_migration_002_drops_active_context_id_and_preserves_data(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    # Apply only 001 to get the old schema with active_context_id
    _apply_only(db, "001_initial.sql")

    # Insert a user and a session with active_context_id populated
    db.execute(
        "INSERT INTO users (id, name, is_admin, api_key) VALUES (?, ?, ?, ?)",
        ("jimmy", "Jimmy", True, "key-jimmy"),
    )
    db.execute("INSERT INTO scopes VALUES (?, ?, ?)", ("jimmy", "Jimmy", "personal"))
    db.execute("INSERT INTO scope_members VALUES (?, ?)", ("jimmy", "jimmy"))
    db.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, 'project', 'active', 'Provider Ops', 'jimmy', 'jimmy')",
        ("jimmy",),
    )
    db.commit()
    proj_id = db.fetchone("SELECT last_insert_rowid() as id")["id"]
    db.execute(
        "INSERT INTO sessions (user_id, active_context_id, summary) VALUES (?, ?, ?)",
        ("jimmy", proj_id, "boot-test"),
    )
    db.commit()
    session_id_before = db.fetchone("SELECT last_insert_rowid() as id")["id"]

    # Seed an item_history row that references the session — the migration
    # recreates `sessions` via DROP + RENAME, and without FK-toggling this
    # row's session_id FK would block the DROP on any real production DB.
    db.execute(
        "INSERT INTO item_history (item_id, event, content, actor, session_id) "
        "VALUES (?, ?, ?, ?, ?)",
        (proj_id, "created", "", "jimmy", session_id_before),
    )
    db.commit()

    # Apply migration 002
    _apply_only(db, "002_drop_active_context_id.sql")

    # The column is gone
    cols = [r["name"] for r in db.fetchall("PRAGMA table_info(sessions)")]
    assert "active_context_id" not in cols
    assert set(cols) == {"id", "user_id", "started_at", "ended_at", "summary", "log_path"}

    # Session row survives with the same id and summary
    row = db.fetchone(
        "SELECT id, user_id, summary FROM sessions WHERE id = ?", (session_id_before,)
    )
    assert row is not None
    assert row["user_id"] == "jimmy"
    assert row["summary"] == "boot-test"

    # item_history.session_id reference is preserved across the swap
    hist = db.fetchone("SELECT session_id FROM item_history WHERE item_id = ?", (proj_id,))
    assert hist is not None
    assert hist["session_id"] == session_id_before

    # FK enforcement is restored after the migration
    fk_state = db.fetchone("PRAGMA foreign_keys")[0]
    assert fk_state == 1

    # Index is recreated
    idx = db.fetchall("PRAGMA index_list(sessions)")
    idx_names = [r["name"] for r in idx]
    assert "idx_sessions_user" in idx_names

    db.close()
