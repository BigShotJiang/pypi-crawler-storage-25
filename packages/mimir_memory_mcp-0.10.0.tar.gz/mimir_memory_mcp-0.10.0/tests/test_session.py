from mimir_mcp.tools.session import (
    boot_session_impl,
    end_session_impl as end_session,
)
from mimir_mcp.queries.session import sessions_get_or_create


def test_get_or_create_creates_when_none_exist(seed_data):
    session_id = sessions_get_or_create(seed_data, "jimmy")
    assert session_id is not None
    session = seed_data.fetchone("SELECT * FROM sessions WHERE id = ?", (session_id,))
    assert session["user_id"] == "jimmy"
    assert session["ended_at"] is None


def test_get_or_create_reuses_existing_open_session(seed_data):
    first_id = sessions_get_or_create(seed_data, "jimmy")
    second_id = sessions_get_or_create(seed_data, "jimmy")
    assert first_id == second_id


def test_get_or_create_closes_orphans_keeps_newest(seed_data):
    """When multiple open sessions exist, keep newest, auto-close the rest."""
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("jimmy",))
    seed_data.commit()
    old_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("jimmy",))
    seed_data.commit()
    newest_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]

    result_id = sessions_get_or_create(seed_data, "jimmy")
    assert result_id == newest_id

    old = seed_data.fetchone("SELECT * FROM sessions WHERE id = ?", (old_id,))
    assert old["ended_at"] is not None
    assert old["summary"] == "Auto-closed (superseded)"


def test_get_or_create_does_not_touch_other_users(seed_data):
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("alex",))
    seed_data.commit()
    sessions_get_or_create(seed_data, "jimmy")
    alex_session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'alex' AND ended_at IS NULL"
    )
    assert alex_session is not None


def test_boot_creates_session(seed_data):
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert result["user"]["name"] == "Jimmy"
    assert len(result["scopes"]) >= 2
    session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    assert session is not None


def test_boot_returns_scopes(seed_data):
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    scope_ids = [s["id"] for s in result["scopes"]]
    assert "jimmy" in scope_ids
    assert "household" in scope_ids
    assert "alex" not in scope_ids


def test_boot_reuses_existing_session(seed_data):
    """Boot with an existing open session reuses it instead of creating a new one."""
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    first_session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    open_sessions = seed_data.fetchall(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    assert len(open_sessions) == 1
    assert open_sessions[0]["id"] == first_session["id"]


def test_boot_auto_closes_orphan_sessions(seed_data):
    """Boot with multiple open sessions keeps newest, closes the rest."""
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("jimmy",))
    seed_data.commit()
    old_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("jimmy",))
    seed_data.commit()
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    old = seed_data.fetchone("SELECT * FROM sessions WHERE id = ?", (old_id,))
    assert old["ended_at"] is not None
    assert old["summary"] == "Auto-closed (superseded)"


def test_boot_response_has_no_stale_sessions_field(seed_data):
    """stale_sessions is no longer part of the boot response."""
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert "stale_sessions" not in result


def test_boot_does_not_close_other_users_sessions(seed_data):
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("alex",))
    seed_data.commit()
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    alex_open = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'alex' AND ended_at IS NULL"
    )
    assert alex_open is not None


def test_boot_returns_last_session_summary(seed_data):
    seed_data.execute(
        "INSERT INTO sessions (user_id, ended_at, summary) VALUES (?, datetime('now'), ?)",
        ("jimmy", "Worked on groceries"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert result["last_session"]["summary"] == "Worked on groceries"


def test_boot_returns_items_by_type(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Buy groceries", "jimmy", "jimmy"),
    )
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("jimmy", "project", "in_progress", "Provider Ops", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["tasks"]) == 1
    assert result["tasks"][0]["summary"] == "Buy groceries"
    assert len(result["projects"]) == 1


def test_boot_excludes_completed_items(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("jimmy", "task", "completed", "Done task", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["tasks"]) == 0


def test_boot_returns_facts_as_flat_list(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "fact", "active", "Alex is allergic to shellfish", "jimmy", "jimmy"),
    )
    fact_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (fact_id, "health"))
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert "facts" in result
    assert isinstance(result["facts"], list)
    # Facts are minimal {id, summary} — tags/source are drill-down via get_details
    assert any(f["summary"] == "Alex is allergic to shellfish" for f in result["facts"])


def test_end_session(seed_data):
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    result = end_session(seed_data, "jimmy", learnings=["Jaya Grocer has best fish"])
    assert "summary" in result
    session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NOT NULL"
    )
    assert session is not None
    fact = seed_data.fetchone("SELECT * FROM items WHERE type = 'fact' AND source = 'learned'")
    assert fact is not None
    assert "Jaya Grocer" in fact["summary"]


# --- C8: Activity cursor advancement tests ---


def test_boot_does_not_advance_cursor(seed_data):
    """Cursor stays at 0 after boot — events resurface if session crashes."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task", "alex", "alex"),
    )
    seed_data.commit()
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    cursor = seed_data.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = 'jimmy'"
    )
    assert cursor["last_seen_history_id"] == 0


def test_end_session_advances_cursor(seed_data):
    """Cursor advances at session end."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task", "alex", "alex"),
    )
    seed_data.commit()
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    end_session(seed_data, "jimmy")
    cursor = seed_data.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = 'jimmy'"
    )
    assert cursor["last_seen_history_id"] > 0


def test_crash_recovery_events_reappear_on_second_boot(seed_data):
    """If session ends without checkpoint/end, events reappear on next boot."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task by alex", "alex", "alex"),
    )
    seed_data.commit()
    # First boot — sees the event but cursor not advanced
    boot1 = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(boot1["recent_shared_activity"]) > 0
    # Simulate crash: no checkpoint or end_session
    # Second boot — should still see the event
    boot2 = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(boot2["recent_shared_activity"]) > 0


# --- C9: Reminder boot filtering tests ---


def test_boot_includes_reminders_due_within_7_days(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, due_date, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, datetime('now', '+3 days'), ?, ?)",
        ("household", "reminder", "active", "Dentist appointment", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["reminders"]) == 1


def test_boot_excludes_reminders_due_beyond_7_days(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, due_date, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, datetime('now', '+14 days'), ?, ?)",
        ("household", "reminder", "active", "Far future reminder", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["reminders"]) == 0


def test_boot_excludes_reminders_without_due_date(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "reminder", "active", "Undated reminder", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["reminders"]) == 0


def test_concurrent_boot_no_interference(seed_data):
    """Two users booting sessions simultaneously don't interfere."""
    result_jimmy = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    result_alex = boot_session_impl(seed_data, "alex", ["alex", "household"])
    assert result_jimmy["user"]["id"] == "jimmy"
    assert result_alex["user"]["id"] == "alex"
    jimmy_session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    alex_session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'alex' AND ended_at IS NULL"
    )
    assert jimmy_session is not None
    assert alex_session is not None
    assert jimmy_session["id"] != alex_session["id"]


def test_boot_projects_drop_tags(seed_data):
    """Top-level projects in the boot response carry no tags field."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'project', 'active', 'P1', 'jimmy', 'jimmy')"
    )
    seed_data.commit()
    pid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES ('venture')")
    seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (pid, "venture"))
    seed_data.commit()

    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    projects = result["projects"]
    assert len(projects) == 1
    assert "tags" not in projects[0]


def test_boot_omits_scope_when_personal(seed_data):
    """Scope is omitted on items in the caller's personal scope."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'project', 'active', 'Personal project', 'jimmy', 'jimmy')"
    )
    seed_data.commit()

    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    personal = [p for p in result["projects"] if p["summary"] == "Personal project"][0]
    assert "scope" not in personal


def test_boot_keeps_scope_when_shared(seed_data):
    """Scope is kept for items in a shared (non-caller-personal) scope."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('household', 'project', 'active', 'Family project', 'jimmy', 'jimmy')"
    )
    seed_data.commit()

    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    family = [p for p in result["projects"] if p["summary"] == "Family project"][0]
    assert family["scope"] == "household"


def test_boot_fact_shape_is_minimal(seed_data):
    """Boot facts contain only id and summary — no tags, no source."""
    seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES ('rule')")
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, source, created_by, updated_by) "
        "VALUES ('jimmy', 'fact', 'active', 'Top fact', 'user_stated', 'jimmy', 'jimmy')"
    )
    seed_data.commit()
    fid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (fid, "rule"))
    seed_data.commit()

    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert result["facts"]
    for f in result["facts"]:
        assert set(f.keys()) == {"id", "summary"}


def test_boot_facts_only_top_level(seed_data):
    """Boot 'facts' array contains only facts with parent_id IS NULL."""
    # Top-level fact
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'fact', 'active', 'Global principle', 'jimmy', 'jimmy')"
    )
    # Project
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'project', 'active', 'Project X', 'jimmy', 'jimmy')"
    )
    seed_data.commit()
    proj_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    # Project-scoped fact
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, parent_id, created_by, updated_by) "
        "VALUES ('jimmy', 'fact', 'active', 'Project-specific', ?, 'jimmy', 'jimmy')",
        (proj_id,),
    )
    seed_data.commit()

    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    fact_summaries = [f["summary"] for f in result["facts"]]
    assert "Global principle" in fact_summaries
    assert "Project-specific" not in fact_summaries


def test_end_session_surfaces_tag_consolidation_candidates(seed_data):
    """If there are tag consolidation candidates in any accessible scope,
    end_session surfaces them under 'tag_consolidation_candidates'."""
    # Create enough signal for a candidate in the 'jimmy' scope
    for i in range(6):
        seed_data.execute(
            "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
            "VALUES ('jimmy', 'note', 'active', ?, 'jimmy', 'jimmy')",
            (f"n{i}",),
        )
        seed_data.commit()
        iid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
        seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES ('prompt-engineering')")
        seed_data.execute("INSERT INTO item_tags VALUES (?, 'prompt-engineering')", (iid,))
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'note', 'active', 'lone', 'jimmy', 'jimmy')"
    )
    seed_data.commit()
    iid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES ('prompt')")
    seed_data.execute("INSERT INTO item_tags VALUES (?, 'prompt')", (iid,))
    seed_data.commit()

    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    result = end_session(seed_data, "jimmy")

    assert "tag_consolidation_candidates" in result
    jimmy_cands = result["tag_consolidation_candidates"].get("jimmy", [])
    pairs = [(c["from"], c["to"]) for c in jimmy_cands]
    assert ("prompt", "prompt-engineering") in pairs


def test_end_session_omits_candidates_field_when_none(seed_data):
    """No candidates -> field is absent (not present with empty dict)."""
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    result = end_session(seed_data, "jimmy")
    assert "tag_consolidation_candidates" not in result


def test_end_session_without_active_session_records_learnings(seed_data):
    """end_session with no active session still records learnings and advances cursor."""
    result = end_session(seed_data, "jimmy", learnings=["Offline learning"])
    assert "summary" in result

    fact = seed_data.fetchone("SELECT * FROM items WHERE type = 'fact' AND source = 'learned'")
    assert fact is not None
    assert "Offline learning" in fact["summary"]

    cursor = seed_data.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = 'jimmy'"
    )
    assert cursor["last_seen_history_id"] >= 0


def test_end_session_without_active_session_no_learnings(seed_data):
    """end_session with no active session and no learnings is a clean no-op."""
    result = end_session(seed_data, "jimmy")
    assert "summary" in result
