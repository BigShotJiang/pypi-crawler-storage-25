import pytest

from fastmcp.exceptions import ToolError

from mimir_mcp import queries
from mimir_mcp.tools.tags import list_tags_impl, merge_tags_impl, suggest_tag_consolidations_impl


def _seed_many_tags(db, scope: str, how_many: int):
    db.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, 'note', 'active', 'n', ?, ?)",
        (scope, "jimmy", "jimmy"),
    )
    db.commit()
    iid = db.fetchone("SELECT last_insert_rowid() as id")["id"]
    for i in range(how_many):
        db.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", (f"t{i:02d}",))
        db.execute("INSERT INTO item_tags VALUES (?, ?)", (iid, f"t{i:02d}"))
    db.commit()


def test_list_tags_default_top_30(seed_data):
    _seed_many_tags(seed_data, "jimmy", 40)
    tags = list_tags_impl(seed_data, ["jimmy", "household"], scope="jimmy")
    assert len(tags) == 30
    assert all({"name", "count"} <= set(t.keys()) for t in tags)


def test_list_tags_extended_returns_all(seed_data):
    _seed_many_tags(seed_data, "jimmy", 40)
    tags = list_tags_impl(seed_data, ["jimmy", "household"], scope="jimmy", extended=True)
    assert len(tags) == 40


def test_list_tags_rejects_inaccessible_scope(seed_data):
    with pytest.raises(ToolError):
        list_tags_impl(seed_data, ["jimmy"], scope="household")


def test_tags_in_use_limited_to_top_30(seed_data):
    """tags_in_use returns at most 30 tags per scope, ordered by usage count desc."""
    # Insert a base item and attach 40 single-use tags to it
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'note', 'active', 'N', 'jimmy', 'jimmy')"
    )
    seed_data.commit()
    iid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]

    # 40 distinct tag names each used once
    for i in range(40):
        seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", (f"t{i:02d}",))
        seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (iid, f"t{i:02d}"))

    # "heavy" used 5 times on 5 additional items, so it has count=5 (vs 1 for the rest)
    seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES ('heavy')")
    for _ in range(5):
        seed_data.execute(
            "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
            "VALUES ('jimmy', 'note', 'active', 'HN', 'jimmy', 'jimmy')"
        )
        hid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
        seed_data.execute("INSERT INTO item_tags VALUES (?, 'heavy')", (hid,))
    seed_data.commit()

    result = queries.tags_in_use(seed_data, ["jimmy"])
    assert "jimmy" in result
    # 41 distinct tags (40 single-use + "heavy") — capped at 30
    assert len(result["jimmy"]) == 30
    # "heavy" (count=5) must be first — ordering by count desc is the contract
    assert result["jimmy"][0] == "heavy"


def test_tags_in_use_empty_scopes(db):
    """Empty scopes list returns empty dict without SQL error."""
    result = queries.tags_in_use(db, [])
    assert result == {}


def _tag_item(db, scope, summary, tags):
    db.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, 'note', 'active', ?, 'jimmy', 'jimmy')",
        (scope, summary),
    )
    db.commit()
    iid = db.fetchone("SELECT last_insert_rowid() as id")["id"]
    for t in tags:
        db.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", (t,))
        db.execute("INSERT INTO item_tags VALUES (?, ?)", (iid, t))
    db.commit()


def test_suggest_flags_substring_match(seed_data):
    # 'prompt-engineering' used 6 times (high), 'prompt' used 1 time (low)
    for i in range(6):
        _tag_item(seed_data, "jimmy", f"n{i}", ["prompt-engineering"])
    _tag_item(seed_data, "jimmy", "lone", ["prompt"])

    candidates = suggest_tag_consolidations_impl(seed_data, ["jimmy"], scope="jimmy")
    pairs = [(c["from"], c["to"], c["reason"]) for c in candidates]
    assert ("prompt", "prompt-engineering", "substring") in pairs


def test_suggest_flags_edit_distance(seed_data):
    for i in range(5):
        _tag_item(seed_data, "jimmy", f"n{i}", ["automation"])
    _tag_item(seed_data, "jimmy", "typo", ["automaton"])

    candidates = suggest_tag_consolidations_impl(seed_data, ["jimmy"], scope="jimmy")
    pairs = [(c["from"], c["to"], c["reason"]) for c in candidates]
    assert ("automaton", "automation", "edit_distance") in pairs


def test_suggest_flags_stem_variant(seed_data):
    for i in range(4):
        _tag_item(seed_data, "jimmy", f"n{i}", ["venture"])
    _tag_item(seed_data, "jimmy", "solo", ["ventures"])

    candidates = suggest_tag_consolidations_impl(seed_data, ["jimmy"], scope="jimmy")
    pairs = [(c["from"], c["to"], c["reason"]) for c in candidates]
    assert ("ventures", "venture", "stem") in pairs


def test_suggest_ignores_high_usage_pairs(seed_data):
    # Both used 5 times -> neither is low-usage, no candidate
    for i in range(5):
        _tag_item(seed_data, "jimmy", f"a{i}", ["foo"])
    for i in range(5):
        _tag_item(seed_data, "jimmy", f"b{i}", ["foos"])

    candidates = suggest_tag_consolidations_impl(seed_data, ["jimmy"], scope="jimmy")
    assert candidates == []


def test_suggest_orders_by_to_count_desc(seed_data):
    for i in range(10):
        _tag_item(seed_data, "jimmy", f"x{i}", ["big-tag"])
    for i in range(3):
        _tag_item(seed_data, "jimmy", f"y{i}", ["small-tag"])
    _tag_item(seed_data, "jimmy", "low-b", ["big"])  # -> "big-tag" via substring
    _tag_item(seed_data, "jimmy", "low-s", ["small"])  # -> "small-tag" via substring

    candidates = suggest_tag_consolidations_impl(seed_data, ["jimmy"], scope="jimmy")
    assert candidates[0]["to"] == "big-tag"  # highest to_count first


def test_merge_tags_replaces_tag_across_items(seed_data):
    _tag_item(seed_data, "jimmy", "a", ["old"])
    _tag_item(seed_data, "jimmy", "b", ["old"])
    _tag_item(seed_data, "jimmy", "c", ["unrelated"])

    result = merge_tags_impl(seed_data, ["jimmy"], from_tag="old", to_tag="new", scope="jimmy")
    assert result == {"merged": 2, "from": "old", "to": "new", "scope": "jimmy"}

    # 'old' gone, 'new' in its place
    rows = seed_data.fetchall("SELECT tag_id FROM item_tags ORDER BY tag_id")
    ids = [r["tag_id"] for r in rows]
    assert "old" not in ids
    assert ids.count("new") == 2


def test_merge_tags_dedups_when_to_tag_already_present(seed_data):
    _tag_item(seed_data, "jimmy", "a", ["old", "new"])  # already has both

    result = merge_tags_impl(seed_data, ["jimmy"], from_tag="old", to_tag="new", scope="jimmy")
    assert result["merged"] == 1

    rows = seed_data.fetchall("SELECT tag_id FROM item_tags ORDER BY tag_id")
    ids = [r["tag_id"] for r in rows]
    assert ids == ["new"]


def test_merge_tags_removes_orphaned_tag_row(seed_data):
    _tag_item(seed_data, "jimmy", "a", ["old"])
    merge_tags_impl(seed_data, ["jimmy"], from_tag="old", to_tag="new", scope="jimmy")

    row = seed_data.fetchone("SELECT id FROM tags WHERE id = ?", ("old",))
    assert row is None


def test_merge_tags_keeps_tag_row_if_still_used_in_other_scope(seed_data):
    _tag_item(seed_data, "jimmy", "a", ["shared"])
    _tag_item(seed_data, "household", "b", ["shared"])

    merge_tags_impl(
        seed_data, ["jimmy", "household"], from_tag="shared", to_tag="alt", scope="jimmy"
    )

    row = seed_data.fetchone("SELECT id FROM tags WHERE id = ?", ("shared",))
    assert row is not None  # still used in household


def test_merge_tags_rejects_inaccessible_scope(seed_data):
    with pytest.raises(ToolError):
        merge_tags_impl(seed_data, ["jimmy"], from_tag="x", to_tag="y", scope="household")


def test_merge_tags_noop_when_from_tag_absent_in_scope(seed_data):
    """No-op contract: when from_tag has no items in the target scope, merge_tags
    returns merged=0 and must not create the to_tag row or mutate item_tags.

    Scenario A: from_tag does not exist in the tags table at all.
    Scenario B: from_tag exists globally but only carries items in a different scope.
    Both paths hit the same early return in merge_tags_impl.
    """
    # ── Scenario A: from_tag "ghost" never inserted ────────────────────
    item_tags_before = seed_data.fetchall("SELECT * FROM item_tags")

    result_a = merge_tags_impl(
        seed_data, ["jimmy"], from_tag="ghost", to_tag="ghost-merged", scope="jimmy"
    )

    assert result_a == {"merged": 0, "from": "ghost", "to": "ghost-merged", "scope": "jimmy"}
    # to_tag row must NOT have been created
    row = seed_data.fetchone("SELECT id FROM tags WHERE id = ?", ("ghost-merged",))
    assert row is None
    # item_tags must be unchanged
    item_tags_after = seed_data.fetchall("SELECT * FROM item_tags")
    assert item_tags_after == item_tags_before

    # ── Scenario B: from_tag "scope-only" exists and has items — but only in household ──
    _tag_item(seed_data, "household", "h-item", ["scope-only"])

    item_tags_before_b = seed_data.fetchall("SELECT * FROM item_tags ORDER BY item_id, tag_id")

    result_b = merge_tags_impl(
        seed_data,
        ["jimmy", "household"],
        from_tag="scope-only",
        to_tag="scope-only-merged",
        scope="jimmy",  # merge is requested in jimmy — no items here carry the tag
    )

    assert result_b == {
        "merged": 0,
        "from": "scope-only",
        "to": "scope-only-merged",
        "scope": "jimmy",
    }
    # to_tag row must NOT have been created
    row = seed_data.fetchone("SELECT id FROM tags WHERE id = ?", ("scope-only-merged",))
    assert row is None
    # item_tags must be unchanged (household item still has its original tag)
    item_tags_after_b = seed_data.fetchall("SELECT * FROM item_tags ORDER BY item_id, tag_id")
    assert item_tags_after_b == item_tags_before_b
