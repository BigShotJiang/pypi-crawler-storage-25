# Mimir MCP — State Model & Session Cleanup

**Date:** 2026-04-19
**Status:** Approved

## Summary

Trim what loads at each view state, introduce a parent-based model for facts (top-level vs. scoped), add explicit tag-management tools, and clean up the session lifecycle by deprecating server-side focus. Multi-terminal concurrent sessions are explicitly deferred to a later spec.

## Motivation

After the v0.7.0 context reduction, the boot/refresh payloads are still fat:

- Every project at top-level carries `tags` that mostly repeat `["private", "repo"]` — noise for repo-type projects, modest signal for ventures.
- Every fact at top-level carries `tags` and `source`. The summary alone answers "is this relevant?"; provenance is drill-down concern.
- `tags_in_use` returns the full tag list (~200 for the `jimmy` scope today), inflating every boot and refresh.
- All facts load at boot regardless of whether they're globally relevant (e.g., "Jimmy is in Malaysia") or project-specific (e.g., nine `ai-powered-legal-intelligence` MVP decisions). A conversation about `book-generator` still gets all of the legal-intelligence decisions injected.
- Children in focused views include fields (`scope`, `status`, `priority`, `tags`, `child_count`, `completed_count`) that are rarely useful for drilling a second level down.

Separately, the session-lifecycle tools overlap and have known multi-terminal defects:

- `sessions_close_stale` auto-closes every unended session at `start_session` time. If Terminal B starts a session, Terminal A's session is silently killed.
- `sessions_get_active` uses `ORDER BY id DESC LIMIT 1`, so whichever terminal last started "wins" for `set_context`, `save_session`, `end_session`.
- `active_context_id` is per-session state stored in a single active session per user — focus bleeds between terminals.
- `activity_cursor` is per-user — `save_session` from Terminal B advances cursor for Terminal A's view too.

The spec addresses context bloat and session-tool overlap. Concurrent multi-terminal sessions are **deferred**.

## Design

### 1. View states & response shapes

| State | Entry point | Response |
|---|---|---|
| **Boot** | `start_session`, `refresh_context()` | user, scopes, projects/tasks/ideas (top-slim), upcoming reminders, **top-level facts only** (`{id, summary}`), **top-30** tags_in_use, shared_activity, last_session |
| **Drill-in** | `set_context(item_id)` | `{item, children, item_facts}` only. No scopes, no tags_in_use, no shared_activity — Claude already has those from boot. |
| **Rebuild** | `refresh_context(item_id)` | Boot payload + `{item, children, item_facts}` — full post-compaction restore with focus preserved. |
| **Detail** | `get_details([ids])` | Full item rows (unchanged). |
| **Search / browse** | `search_items`, `list_items` | Slim matches (unchanged). |
| **Tag listing** | `list_tags(scope, extended=False)` | **New tool.** Top 30 tags + counts by default; full list when `extended=True`. |

**Key naming:** `facts` in any response = top-level facts (parent_id IS NULL). `item_facts` = facts attached to the focused item (parent_id = focused item's id). The two keys never collide.

### 2. Slim shapes

Two distinct shapes, used in different places:

**`top_slim_item`** — used for projects, tasks, ideas at the boot level:

```python
{
    "id": int,
    "summary": str,
    "status": str,
    "scope": str,           # OMITTED when scope == user's personal scope
    "priority": str,        # omitted when null/"normal"
    "child_count": int,     # omitted when 0
    "completed_count": int, # omitted when 0
    "due_date": str,        # omitted when null
}
```

Changes vs. current `slim_item`:
- **Remove `tags`** entirely from this shape.
- **Omit `scope`** when it equals the caller's personal scope. Keep when it belongs to a shared scope.

**`child_slim_item`** — used for children in drill-in and rebuild responses:

```python
{
    "id": int,
    "summary": str,
    "due_date": str,  # omitted when null
}
```

Drops: `scope`, `status`, `priority`, `tags`, `child_count`, `completed_count`. If scanning children for completion status becomes painful we can add `status` back; start strict.

### 3. Fact parenting convention

A fact's position in the response is determined entirely by `parent_id`:

- `parent_id IS NULL` → **top-level fact** → returned in boot's `facts` array. Reserved for cross-cutting principles, user profile, and general-purpose knowledge (e.g., "always develop containerized", "Jimmy is in Malaysia").
- `parent_id IS NOT NULL` → **scoped fact** → returned in the focused response's `item_facts` array **only when that parent is focused**.

The schema already allows `items.parent_id` on facts. No schema change — this is a **convention** enforced at fact-creation time via the server-instruction guidance and at read-time via the new boot/focused split.

**Top-level fact shape** (returned in `facts`):

```python
{
    "id": int,
    "summary": str,
}
```

Drops: `tags`, `source`.

**Scoped fact shape** (returned in `item_facts`):

Same: `{id, summary}`. Matches top-level for consistency. `tags` and `source` still accessible via `get_details([id])`.

### 4. `tags_in_use` trimming

- Returned in `start_session` and `refresh_context` responses.
- **Limited to top 30 tags per scope by usage count** (items-tagged count).
- Shape unchanged: `{scope_id: [tag_name, ...]}` but truncated.
- **Dropped from `set_context` response** — Claude has it from boot; use `list_tags` if fresh data is needed mid-conversation.

### 5. Session lifecycle (single-session model)

The single-active-session-per-user model is preserved. Multi-terminal concurrency is not fixed; see [Known issues](#known-issues).

| Tool | Status | Notes |
|---|---|---|
| `start_session(scopes?)` | Kept, behavior simplified | **Remove `sessions_close_stale` call.** Boot payload follows the new shapes above. **Remove `stale_sessions` field from response.** |
| `refresh_context(item_id?)` | Kept, stateless (v0.7 behavior) | Payload follows the new shapes. When `item_id` provided, adds `{item, children, item_facts}` on top of boot. |
| `set_context(item_id)` | Kept, **stateless** | **No longer writes `active_context_id`.** Returns only the focused slice: `{item, children, item_facts}`. No `tags_in_use`. |
| `save_session()` | Unchanged | Advances `activity_cursor`. |
| `end_session(learnings?)` | Kept, response extended | Closes session, records learnings as facts, advances cursor. **Adds `tag_consolidation_candidates` field when any exist.** |

**Removed function:** `sessions_close_stale` (and its caller in `boot_session_impl`). Orphan sessions now accumulate until a future multi-session redesign; see [Known issues](#known-issues).

### 6. New tools

#### `list_tags(scope: str, extended: bool = False) → list[dict]`

Returns tags in the given scope.

- `extended=False` (default): top 30 tags by usage count.
- `extended=True`: all tags.

Response shape:

```python
[
    {"name": "automation", "count": 14},
    {"name": "venture", "count": 7},
    ...
]
```

Auth: scope must be in the caller's accessible scopes. Raise `ToolError` otherwise.

#### `suggest_tag_consolidations(scope: str) → list[dict]`

Returns candidate tag pairs for consolidation. Matching heuristics (all gated by **low-usage on at least one tag**, defined as `count <= 2`):

1. **Edit distance ≤ 2** between tag names (typo detection: `automaton` ↔ `automation`).
2. **Plural/stem variants** — one tag is the other plus/minus a trailing `s`, `es`, `ing`, `ed` (e.g., `venture` ↔ `ventures`).
3. **Substring / word-boundary match** — one tag appears as a whole word (dash- or space-separated) within the other (e.g., `prompt` ⊂ `prompt-engineering`).

Response shape:

```python
[
    {
        "from": "prompt",           # low-usage candidate
        "to": "prompt-engineering", # high-usage partner
        "from_count": 1,
        "to_count": 6,
        "reason": "substring",      # one of: "edit_distance", "stem", "substring"
    },
    ...
]
```

Ordering: descending by `to_count` (strongest consolidation target first).

Auth: scope must be in the caller's accessible scopes.

#### `merge_tags(from_tag: str, to_tag: str, scope: str) → dict`

Atomically rename every occurrence of `from_tag` to `to_tag` on items in the given scope. Executes as a single transaction:

1. Find all items with `from_tag` in `scope`.
2. Remove `from_tag` from those items.
3. Add `to_tag` to those items (deduplicate — no duplicate rows in `item_tags`).
4. Delete `from_tag` row from `tags` if no remaining references.

Response shape:

```python
{"merged": 7, "from": "prompt", "to": "prompt-engineering", "scope": "jimmy"}
```

Auth: scope must be in the caller's accessible scopes.

### 7. `end_session` tag consolidation surfacing

After closing the session and advancing the cursor, call `suggest_tag_consolidations` for each of the user's scopes. If any candidates exist, include them in the response:

```python
{
    "summary": "Session ended with 2 learnings recorded",
    "tag_consolidation_candidates": {
        "jimmy": [ ... ],
        "family": [ ... ],
    },
}
```

Omit the field entirely when no candidates exist in any scope. Claude (via Hermes `/end`) can surface these to the user for review and invoke `merge_tags` on approval.

### 8. Database migration

**Migration `002_drop_active_context_id.sql`:**

```sql
-- SQLite doesn't support ALTER TABLE DROP COLUMN before 3.35.
-- Use the recreate pattern for portability.

CREATE TABLE sessions_new (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL REFERENCES users(id),
    started_at  TEXT NOT NULL DEFAULT (datetime('now')),
    ended_at    TEXT,
    summary     TEXT,
    log_path    TEXT
);

INSERT INTO sessions_new (id, user_id, started_at, ended_at, summary, log_path)
SELECT id, user_id, started_at, ended_at, summary, log_path FROM sessions;

DROP TABLE sessions;
ALTER TABLE sessions_new RENAME TO sessions;

CREATE INDEX idx_sessions_user ON sessions(user_id, ended_at);
```

No data migration for facts is required at the schema level — reparenting existing facts is a content task handled via `update_item` in conversation, not via SQL. A list of facts that should be reparented is provided as a follow-up task, not as part of this spec's migration.

### 9. Documentation & instruction updates

All of these are within the scope of this spec's implementation:

- **Server `instructions`** (`src/mimir_mcp/server.py`):
  - Update session-lifecycle bullets to reflect the new `set_context` semantics (stateless, no server-side focus).
  - Add fact-parenting convention: "Facts that apply globally (user profile, cross-cutting principles) have no parent. Facts specific to a project/task/idea MUST have that item as their parent."
  - Update `tags_in_use` description to reference the top-30 limit and point to `list_tags` for the full list.
  - Add description of `list_tags`, `suggest_tag_consolidations`, `merge_tags`.
- **Tool docstrings** for every touched tool (`start_session`, `refresh_context`, `set_context`, `end_session`, `add_items`, plus the three new tools).
- **Pydantic models** in `src/mimir_mcp/models.py`: update `SessionBootResponse`, `FocusedView`, add `TagConsolidationCandidate`, etc., to match the new shapes.
- **Hermes `CLAUDE.md`** (separate repo `~/hermes`): update the Mimir section to document the fact-parenting convention and the `tag_consolidation_candidates` field surfaced on `/end`.

### 10. Testing

Add / update in the following test files:

- **`tests/test_session.py`** — remove `sessions_close_stale` assertions; verify boot no longer returns `stale_sessions`; verify `end_session` includes `tag_consolidation_candidates` when applicable.
- **`tests/test_context.py`** — assert top-level facts only include `parent_id IS NULL`; assert focused view's `item_facts` only includes facts with matching `parent_id`; assert `set_context` no longer persists `active_context_id`; assert `set_context` response does not include `tags_in_use`.
- **`tests/test_items.py`** (or a new `test_tags.py`) — `list_tags` default (top 30) and extended (full); `suggest_tag_consolidations` for each heuristic (edit distance, stem, substring) with low-usage gating; `merge_tags` transactional correctness, scope-auth rejection.
- **Migration test** — apply migration 002 on a seeded database with populated `active_context_id` values; verify column is gone and all other session data survives.

## Excluded (YAGNI)

- **Multi-terminal concurrent sessions.** Client-owned `session_id`, per-session cursors, and per-session focus are deferred to a future spec. The known defects (see below) are accepted until that work happens.
- **Auto-parent inference for facts.** The server does not attempt to classify existing facts into projects based on content or tags. Reparenting happens via conversation + `update_item`.
- **Per-session `active_context_id` replacement.** No new server-side focus mechanism. Clients that want to remember focus across calls should track it in conversation context.
- **LLM-powered tag consolidation.** The server's heuristics are string-based. Semantic consolidation ("shop" ↔ "e-commerce") relies on Claude reviewing the candidates with the user.
- **Top-N tuning parameter on `tags_in_use`.** The 30 limit is hard-coded. Clients needing more use `list_tags(scope, extended=True)`.
- **Top-level fact promotion tool.** There is no `promote_fact_to_top_level` API; updating `parent_id` to NULL via `update_item` is sufficient.

## Known issues

Documented and carried into production as-is until a multi-terminal spec addresses them:

- **Orphan sessions accumulate.** With `sessions_close_stale` removed, sessions that aren't explicitly closed remain open. `sessions_get_active` still uses `ORDER BY id DESC LIMIT 1`, so the newest open session wins for all session-scoped operations.
- **Multi-terminal focus / cursor bleed.** When two terminals run concurrently for the same user:
  - Terminal B's `start_session` creates a new session but no longer closes Terminal A's session (bug mitigated compared to today — but both sessions are now "active" and `sessions_get_active` picks Terminal B's).
  - `save_session` and `end_session` target "the most recent" session, not the caller's session. Terminal A calling `save_session` advances the cursor as if it were Terminal B's session.
  - `activity_cursor` is per-user — a checkpoint by Terminal B marks shared activity as seen for Terminal A too.

These are **not** regressions introduced by this spec; they are pre-existing defects surfaced by removing the auto-close band-aid.

## Open questions

None. All decisions resolved during brainstorming.
