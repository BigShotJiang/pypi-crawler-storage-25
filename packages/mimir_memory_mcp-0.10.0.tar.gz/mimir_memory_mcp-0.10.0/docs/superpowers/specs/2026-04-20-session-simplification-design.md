# Session Simplification — Design Spec

**Date:** 2026-04-20
**Mimir task:** #217
**Wire-breaking:** Yes — `save_session` tool removed; bump minor version

## Problem

Mimir's session model assumes one active session per user at a time, but enforces this poorly:

- `start_session()` always creates a new session row, orphaning prior open sessions
- `sessions_get_active()` picks the newest open session (`ORDER BY id DESC LIMIT 1`), so `end_session()` from an older terminal closes the wrong session
- `set_context()` and `refresh_context()` gate behind an active session — pure reads that fail unnecessarily when no session exists
- `save_session()` advances the per-user activity cursor without showing the user what it marked as seen
- The `activity_cursor` is per-user (correct), but session lifecycle operations assume per-session semantics (incorrect)

These are not edge cases. Opening two terminals, forgetting `/end`, or connecting from a different client all trigger these bugs.

## Design Principles

1. **The user is the unit of identity, not the client.** Working from a terminal today and a web app tomorrow should be seamless.
2. **Sessions are optional bookkeeping.** All read and write operations work without an active session. Sessions exist for conversation bookends (`/start`, `/end`) — summaries, learnings, and cursor advancement.
3. **One active session per user.** Idempotent open, graceful close.

## Changes

### `start_session()` — get-or-create with orphan cleanup

**Current:** Always creates a new session row.

**New:**
1. Query for open sessions (`ended_at IS NULL`) for this user.
2. If exactly one exists — reuse it. Do not create a new row.
3. If multiple exist (legacy orphans) — keep the newest, auto-close the rest with summary `"Auto-closed (superseded)"`.
4. If none exist — create a new session row.

Boot payload construction is unchanged — it reads from items/facts/cursor, not the session row. The `last_session` field continues to show the most recent completed session's summary.

### `end_session(learnings)` — graceful without active session

**Current:** Fails if no active session exists.

**New:**
1. Try to find an active session.
2. **If found:** close it (set `ended_at`, write summary), record learnings as facts (`source="learned"`), advance activity cursor. Same as today.
3. **If not found:** still record learnings as facts, still advance activity cursor. Return a response indicating no session was closed but learnings were saved.

Rationale: learnings and cursor advancement are the valuable side-effects. The session row is bookkeeping.

### `save_session()` — removed

**Current:** Validates active session, advances per-user activity cursor.

**Removed.** Reasons:
- The cursor only controls the "what's new" notification feed in `recent_shared_activity`, not item visibility.
- `save_session` marked activity as "seen" without displaying it — counterproductive. A subsequent `refresh_context` after compaction would miss things that were silently marked seen.
- Cursor advancement at `end_session` is sufficient. Mid-session, you want shared activity to accumulate so `refresh_context` surfaces it.
- One fewer tool to document and maintain (relevant to tool consolidation effort, task #216).

Wire impact: clients calling `save_session` will get an unknown-tool error. The REST endpoint `/api/session/checkpoint` is also removed.

### `set_context(item_id)` — remove session gate

**Current:** Validates active session before returning focused view.

**New:** Remove validation. Any authenticated user can call this anytime. It is a stateless read operation.

### `refresh_context(item_id)` — remove session gate

**Current:** Validates active session before rebuilding boot + focused view.

**New:** Remove validation. Any authenticated user can call this anytime. It is a stateless read operation.

### Item operations — no change

`add_items`, `update_item`, `complete_items`, `archive_items`, `delete_items`, `convert_item` all pass `session_id` to `history_insert` as an optional parameter. The MCP tool wrappers do not pass it today — it defaults to `None`. No changes required.

## Files Touched

| File | Change |
|------|--------|
| `queries/session.py` | Replace `sessions_create` with get-or-create logic (query open sessions, auto-close orphans). `activity_advance_cursor` stays — still used by `end_session`. |
| `tools/session.py` | Update `boot_session_impl` to use get-or-create. Update `end_session_impl` for graceful no-session path (learnings + cursor still work, session_activity omitted). Remove `checkpoint_session_impl` and `save_session` tool registration. |
| `tools/context.py` | Remove active-session validation from `set_context_impl` and `refresh_context_impl`. |
| `server.py` | Remove `/api/session/checkpoint` REST endpoint. Keep `/api/session/close` (calls `end_session_impl`, which now handles no-session gracefully). |
| `models.py` | No changes expected (SessionBootResponse shape unchanged). |

## Schema

No migration required. The `sessions` table schema is unchanged. No columns added or removed.

## Tests

| Test | Action |
|------|--------|
| `test_boot_does_not_auto_close_other_sessions` | Invert: boot SHOULD auto-close orphans and reuse the surviving session |
| New: idempotent boot | `start_session` with existing open session returns same session ID |
| New: orphan cleanup | Multiple open sessions → newest kept, others auto-closed |
| New: graceful end without session | `end_session(learnings=[...])` with no active session records learnings and advances cursor |
| New: gateless `set_context` | Works without active session |
| New: gateless `refresh_context` | Works without active session |
| `save_session` tests | Remove entirely |
| `test_checkpoint_advances_cursor` | Remove (checkpoint no longer exists) |
| Existing `end_session` tests | Verify cursor still advances |

## Version

Bump minor version (e.g., v0.9.0 → v0.10.0). Wire-breaking: `save_session` tool removed, session validation behavior changed.
