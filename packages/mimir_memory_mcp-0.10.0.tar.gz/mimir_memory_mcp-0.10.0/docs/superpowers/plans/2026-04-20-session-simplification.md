# Session Simplification Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make sessions idempotent (one active per user), remove `save_session`, and remove session gates from read operations.

**Architecture:** Replace `sessions_create` with get-or-create logic in the query layer, update `boot_session_impl` and `end_session_impl` in the tools layer, remove `checkpoint_session_impl` and its MCP/REST registrations, and delete session validation from `set_context_impl`/`refresh_context_impl`.

**Tech Stack:** Python 3.11, SQLite, FastMCP, pytest

**Spec:** `docs/superpowers/specs/2026-04-20-session-simplification-design.md`

---

### Task 1: Query layer — get-or-create with orphan cleanup

**Files:**
- Modify: `src/mimir_mcp/queries/session.py`
- Test: `tests/test_session.py`

- [ ] **Step 1: Write failing tests for get-or-create behavior**

Add to `tests/test_session.py`:

```python
from mimir_mcp.queries.session import sessions_get_or_create, sessions_get_active


def test_get_or_create_creates_when_none_exist(seed_data):
    session_id = sessions_get_or_create(seed_data, "jimmy")
    assert session_id is not None
    session = seed_data.fetchone("SELECT * FROM sessions WHERE id = ?", (session_id,))
    assert session["user_id"] == "jimmy"
    assert session["ended_at"] is None


def test_get_or_create_reuses_existing_open_session(seed_data):
    first_id = sessions_get_or_create(seed_data, "jimmy")
    second_id = sessions_get_or_create(seed_data, "jimmy")
    assert first_id == second_id


def test_get_or_create_closes_orphans_keeps_newest(seed_data):
    """When multiple open sessions exist, keep newest, auto-close the rest."""
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("jimmy",))
    seed_data.commit()
    old_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("jimmy",))
    seed_data.commit()
    newest_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]

    result_id = sessions_get_or_create(seed_data, "jimmy")
    assert result_id == newest_id

    old = seed_data.fetchone("SELECT * FROM sessions WHERE id = ?", (old_id,))
    assert old["ended_at"] is not None
    assert old["summary"] == "Auto-closed (superseded)"


def test_get_or_create_does_not_touch_other_users(seed_data):
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("alex",))
    seed_data.commit()
    sessions_get_or_create(seed_data, "jimmy")
    alex_session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'alex' AND ended_at IS NULL"
    )
    assert alex_session is not None
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd ~/repositories/private/mimir && conda run -n mimir pytest tests/test_session.py::test_get_or_create_creates_when_none_exist tests/test_session.py::test_get_or_create_reuses_existing_open_session tests/test_session.py::test_get_or_create_closes_orphans_keeps_newest tests/test_session.py::test_get_or_create_does_not_touch_other_users -v`

Expected: FAIL — `cannot import name 'sessions_get_or_create'`

- [ ] **Step 3: Implement `sessions_get_or_create`**

In `src/mimir_mcp/queries/session.py`, add after `sessions_create`:

```python
def sessions_get_or_create(db: Database, user_id: str) -> int:
    """Return the active session ID, creating one if none exists.

    If multiple open sessions exist (orphans), keeps the newest and
    auto-closes the rest with summary 'Auto-closed (superseded)'.
    """
    open_sessions = db.fetchall(
        "SELECT id FROM sessions WHERE user_id = ? AND ended_at IS NULL ORDER BY id DESC",
        (user_id,),
    )

    if not open_sessions:
        cursor = db.execute("INSERT INTO sessions (user_id) VALUES (?)", (user_id,))
        db.commit()
        return cursor.lastrowid

    newest_id = open_sessions[0]["id"]

    if len(open_sessions) > 1:
        orphan_ids = [s["id"] for s in open_sessions[1:]]
        placeholders = ",".join("?" for _ in orphan_ids)
        db.execute(
            f"UPDATE sessions SET ended_at = datetime('now'), summary = 'Auto-closed (superseded)' "
            f"WHERE id IN ({placeholders})",
            tuple(orphan_ids),
        )
        db.commit()

    return newest_id
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `cd ~/repositories/private/mimir && conda run -n mimir pytest tests/test_session.py::test_get_or_create_creates_when_none_exist tests/test_session.py::test_get_or_create_reuses_existing_open_session tests/test_session.py::test_get_or_create_closes_orphans_keeps_newest tests/test_session.py::test_get_or_create_does_not_touch_other_users -v`

Expected: 4 PASSED

- [ ] **Step 5: Commit**

```bash
cd ~/repositories/private/mimir
git add src/mimir_mcp/queries/session.py tests/test_session.py
git commit -m "feat(queries): add sessions_get_or_create with orphan cleanup"
```

---

### Task 2: Boot — use get-or-create

**Files:**
- Modify: `src/mimir_mcp/tools/session.py`
- Modify: `tests/test_session.py`

- [ ] **Step 1: Update `test_boot_does_not_auto_close_other_sessions` to expect the opposite**

Replace the existing test in `tests/test_session.py`:

```python
def test_boot_reuses_existing_session(seed_data):
    """Boot with an existing open session reuses it instead of creating a new one."""
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    first_session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    open_sessions = seed_data.fetchall(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    assert len(open_sessions) == 1
    assert open_sessions[0]["id"] == first_session["id"]


def test_boot_auto_closes_orphan_sessions(seed_data):
    """Boot with multiple open sessions keeps newest, closes the rest."""
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("jimmy",))
    seed_data.commit()
    old_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    old = seed_data.fetchone("SELECT * FROM sessions WHERE id = ?", (old_id,))
    assert old["ended_at"] is not None
    assert old["summary"] == "Auto-closed (superseded)"
```

- [ ] **Step 2: Run the new tests to verify they fail (boot still creates new sessions)**

Run: `cd ~/repositories/private/mimir && conda run -n mimir pytest tests/test_session.py::test_boot_reuses_existing_session tests/test_session.py::test_boot_auto_closes_orphan_sessions -v`

Expected: FAIL — boot creates a second session

- [ ] **Step 3: Update `boot_session_impl` to use `sessions_get_or_create`**

In `src/mimir_mcp/tools/session.py`, change line 25 from:

```python
    queries.sessions_create(db, user_id)
```

to:

```python
    queries.sessions_get_or_create(db, user_id)
```

- [ ] **Step 4: Update the `start_session` docstring**

In `src/mimir_mcp/tools/session.py`, replace the `start_session` docstring:

```python
        """Start a new session and return your full current state: projects, tasks, ideas, top-level facts (parent_id IS NULL), upcoming reminders, recent shared activity, and the top 30 tags per scope. Call once at the beginning of every conversation. If your context is compacted mid-conversation, call refresh_context instead — calling start_session again creates a new session."""
```

with:

```python
        """Start or resume a session and return your full current state: projects, tasks, ideas, top-level facts (parent_id IS NULL), upcoming reminders, recent shared activity, and the top 30 tags per scope. Idempotent — reuses the existing open session if one exists. Call once at the beginning of every conversation. If your context is compacted mid-conversation, call refresh_context instead."""
```

- [ ] **Step 5: Remove dead `sessions_create` function**

In `src/mimir_mcp/queries/session.py`, delete `sessions_create` (lines 8–10) — it is no longer called anywhere.

- [ ] **Step 6: Run all session tests**

Run: `cd ~/repositories/private/mimir && conda run -n mimir pytest tests/test_session.py -v`

Expected: ALL PASS (existing tests should still work with get-or-create)

- [ ] **Step 7: Commit**

```bash
cd ~/repositories/private/mimir
git add src/mimir_mcp/tools/session.py src/mimir_mcp/queries/session.py tests/test_session.py
git commit -m "feat(session): boot uses get-or-create, reuses open sessions"
```

---

### Task 3: End session — graceful without active session

**Files:**
- Modify: `src/mimir_mcp/tools/session.py`
- Test: `tests/test_session.py`

- [ ] **Step 1: Write failing test for graceful end without session**

Add to `tests/test_session.py`:

```python
def test_end_session_without_active_session_records_learnings(seed_data):
    """end_session with no active session still records learnings and advances cursor."""
    result = end_session(seed_data, "jimmy", learnings=["Offline learning"])
    assert "summary" in result

    fact = seed_data.fetchone(
        "SELECT * FROM items WHERE type = 'fact' AND source = 'learned'"
    )
    assert fact is not None
    assert "Offline learning" in fact["summary"]

    cursor = seed_data.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = 'jimmy'"
    )
    assert cursor["last_seen_history_id"] >= 0


def test_end_session_without_active_session_no_learnings(seed_data):
    """end_session with no active session and no learnings is a clean no-op."""
    result = end_session(seed_data, "jimmy")
    assert "summary" in result
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd ~/repositories/private/mimir && conda run -n mimir pytest tests/test_session.py::test_end_session_without_active_session_records_learnings tests/test_session.py::test_end_session_without_active_session_no_learnings -v`

Expected: FAIL — current code returns early with `"No active session found."` and doesn't record learnings

- [ ] **Step 3: Update `end_session_impl` for graceful no-session path**

Replace `end_session_impl` in `src/mimir_mcp/tools/session.py`:

```python
def end_session_impl(db: Database, user_id: str, *, learnings: list[str] | None = None) -> dict:
    """End the active session. Optionally record learnings as facts.

    If no active session exists, still records learnings and advances the
    activity cursor — those are the valuable side-effects.

    When there are tag consolidation candidates in any accessible scope,
    includes them under 'tag_consolidation_candidates' keyed by scope id.
    """
    session = queries.sessions_get_active(db, user_id)
    session_id = session["id"] if session else None

    # Record learnings as facts (works with or without a session)
    if learnings:
        for learning in learnings:
            fact_id = queries.items_insert_full(
                db,
                user_id,
                "fact",
                "active",
                learning,
                user_id,
                source="learned",
            )
            queries.history_insert(
                db,
                fact_id,
                "created",
                f"Learned: {learning}",
                user_id,
                session_id=session_id,
            )

    # Generate summary
    if session:
        summary = "Session ended"
        if learnings:
            summary += f" with {len(learnings)} learning(s) recorded"
        queries.sessions_end(db, session_id, summary)
    else:
        summary = "No active session"
        if learnings:
            summary += f", {len(learnings)} learning(s) recorded"

    # Advance cursor
    queries.activity_advance_cursor(db, user_id)

    # Commit
    db.commit()

    # Collect tag consolidation candidates across every accessible scope.
    user_scope_rows = queries.scopes_for_user(db, user_id)
    user_scope_ids = [s["id"] for s in user_scope_rows]
    candidates: dict[str, list[dict]] = {}
    for sid in user_scope_ids:
        scope_candidates = suggest_tag_consolidations_impl(db, user_scope_ids, scope=sid)
        if scope_candidates:
            candidates[sid] = scope_candidates

    result = {"summary": summary}
    if candidates:
        result["tag_consolidation_candidates"] = candidates
    return result
```

- [ ] **Step 4: Update the `end_session` tool docstring**

In `src/mimir_mcp/tools/session.py`, in the `register` function, replace the `end_session` docstring:

```python
        """End the current session. Pass learnings to save new facts that should persist across sessions. Marks all shared activity as seen and closes the session. If there are tag consolidation candidates in any accessible scope, they are included under 'tag_consolidation_candidates' — review with the user and invoke merge_tags to apply approved merges."""
```

with:

```python
        """End the current session, or record learnings without one. Pass learnings to save new facts that should persist across sessions. If no active session exists, learnings are still recorded and the activity cursor is still advanced. If there are tag consolidation candidates in any accessible scope, they are included under 'tag_consolidation_candidates' — review with the user and invoke merge_tags to apply approved merges."""
```

- [ ] **Step 5: Run all session tests**

Run: `cd ~/repositories/private/mimir && conda run -n mimir pytest tests/test_session.py -v`

Expected: ALL PASS

- [ ] **Step 6: Commit**

```bash
cd ~/repositories/private/mimir
git add src/mimir_mcp/tools/session.py tests/test_session.py
git commit -m "feat(session): end_session graceful without active session"
```

---

### Task 4: Remove `save_session` / checkpoint

**Files:**
- Modify: `src/mimir_mcp/tools/session.py`
- Modify: `src/mimir_mcp/server.py`
- Modify: `tests/test_session.py`

- [ ] **Step 1: Remove `checkpoint_session_impl` and `save_session` tool from `tools/session.py`**

Delete the `checkpoint_session_impl` function (lines 149–162) entirely.

In the `register` function, delete the `save_session` tool (lines 195–198).

Update the module docstring from `"""Session lifecycle tools: boot, end, checkpoint."""` to `"""Session lifecycle tools: boot, end."""`

Remove the `checkpoint_session_impl` import alias from `tests/test_session.py` line 4:

```python
from mimir_mcp.tools.session import (
    boot_session_impl,
    end_session_impl as end_session,
)
```

- [ ] **Step 2: Remove checkpoint tests from `tests/test_session.py`**

Delete `test_checkpoint` (lines 122–125) and `test_checkpoint_advances_cursor` (lines 146–159).

- [ ] **Step 3: Remove `/api/session/checkpoint` REST endpoint from `server.py`**

In `src/mimir_mcp/server.py`, remove the import of `checkpoint_session_impl` from line 154:

```python
    from mimir_mcp.tools.session import end_session_impl
```

Delete the `rest_checkpoint` route (lines 192–199).

- [ ] **Step 4: Update MCP instructions in `server.py`**

In the `instructions` string in `create_server()`, replace the session lifecycle paragraph:

```python
            "Session lifecycle:\n"
            "- Call start_session once at conversation start.\n"
            "- Call save_session periodically to checkpoint your position in shared "
            "activity.\n"
            "- Call end_session at conversation end. Pass new facts learned as "
            "learnings. If the response contains tag_consolidation_candidates, "
            "review them with the user before finalizing.\n\n"
```

with:

```python
            "Session lifecycle:\n"
            "- Call start_session once at conversation start. Idempotent — reuses "
            "the existing open session if one exists.\n"
            "- Call end_session at conversation end. Pass new facts learned as "
            "learnings. If no active session exists, learnings are still recorded "
            "and the activity cursor is still advanced. If the response contains "
            "tag_consolidation_candidates, review them with the user before "
            "finalizing.\n\n"
```

- [ ] **Step 5: Run full test suite**

Run: `cd ~/repositories/private/mimir && conda run -n mimir pytest -v`

Expected: ALL PASS — no remaining references to checkpoint

- [ ] **Step 6: Commit**

```bash
cd ~/repositories/private/mimir
git add src/mimir_mcp/tools/session.py src/mimir_mcp/server.py tests/test_session.py
git commit -m "feat(session): remove save_session and checkpoint endpoint"
```

---

### Task 5: Remove session gates from context tools

**Files:**
- Modify: `src/mimir_mcp/tools/context.py`
- Modify: `tests/test_context.py`

- [ ] **Step 1: Write failing tests for gateless context operations**

Add to `tests/test_context.py`:

```python
def test_set_context_works_without_session(seed_data):
    """set_context does not require an active session."""
    scopes = ["jimmy", "household"]
    proj_id = _create_project(seed_data, "jimmy", "No-session project", detail="Detail")
    _create_child(seed_data, proj_id, "jimmy", "task", "Child task")

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert result["item"]["id"] == proj_id
    assert "error" not in result


def test_set_context_none_works_without_session(seed_data):
    """set_context(None) returns boot summary without a session."""
    scopes = ["jimmy", "household"]
    result = set_context(seed_data, "jimmy", scopes, item_id=None)

    assert "projects" in result
    assert "error" not in result


def test_refresh_context_works_without_session(seed_data):
    """refresh_context does not require an active session."""
    scopes = ["jimmy", "household"]
    proj_id = _create_project(seed_data, "jimmy", "Refresh no-session")

    result = refresh_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert result["item"]["id"] == proj_id
    assert "error" not in result


def test_refresh_context_no_session_omits_session_activity(seed_data):
    """Without an active session, session_activity is an empty list."""
    scopes = ["jimmy", "household"]
    result = refresh_context(seed_data, "jimmy", scopes)

    assert result["session_activity"] == []
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `cd ~/repositories/private/mimir && conda run -n mimir pytest tests/test_context.py::test_set_context_works_without_session tests/test_context.py::test_set_context_none_works_without_session tests/test_context.py::test_refresh_context_works_without_session tests/test_context.py::test_refresh_context_no_session_omits_session_activity -v`

Expected: FAIL — `"No active session found."` error returned

- [ ] **Step 3: Remove session gate from `set_context_impl`**

In `src/mimir_mcp/tools/context.py`, replace `set_context_impl` (lines 114–137):

```python
def set_context_impl(
    db: Database, user_id: str, scopes: list[str], *, item_id: int | None = None
) -> dict:
    """Return a focused slice (item + children + item_facts) or the boot overview.

    Stateless — does not persist server-side focus.
    """
    if item_id is None:
        return build_boot_summary(db, user_id, scopes)

    item_row = queries.items_get_by_id(db, item_id)
    if not item_row:
        return {"error": f"Item {item_id} not found."}

    if item_row["scope"] not in scopes:
        return {"error": f"Item {item_id} is not in your accessible scopes."}

    return build_focused_view(db, item_id, scopes)
```

- [ ] **Step 4: Remove session gate from `refresh_context_impl`**

In `src/mimir_mcp/tools/context.py`, replace `refresh_context_impl` (lines 140–192):

```python
def refresh_context_impl(
    db: Database, user_id: str, scopes: list[str], *, item_id: int | None = None
) -> dict:
    """Refresh the current context view — stateless.

    With item_id=None: returns the top-level boot summary.
    With item_id: returns boot summary merged with focused view for that item.
      Result includes both 'facts' (top-level, from boot) and 'item_facts'
      (parent-scoped, from focused view).
    Always includes scopes, shared activity, and tags_in_use.
    Includes session_activity when an active session exists.
    """
    if item_id is not None:
        item_row = queries.items_get_by_id(db, item_id)
        if not item_row:
            return {"error": f"Item {item_id} not found."}
        if item_row["scope"] not in scopes:
            return {"error": f"Item {item_id} is not in your accessible scopes."}
        result = build_boot_summary(db, user_id, scopes)
        result.update(build_focused_view(db, item_id, scopes))
    else:
        result = build_boot_summary(db, user_id, scopes)

    all_user_scopes = queries.scopes_for_user(db, user_id)
    scope_list = []
    for s in all_user_scopes:
        if s["id"] in scopes:
            scope_list.append(
                {
                    "id": s["id"],
                    "name": s["name"],
                    "description": s["description"],
                    "members": s["member_ids"],
                }
            )
    result["scopes"] = scope_list

    session = queries.sessions_get_active(db, user_id)
    if session:
        activity_raw = queries.items_session_activity(db, session["id"])
        result["session_activity"] = [dict(a) for a in activity_raw]
    else:
        result["session_activity"] = []

    shared_activity_raw = queries.activity_get_shared(db, user_id, scopes)
    result["recent_shared_activity"] = [dict(a) for a in shared_activity_raw]

    result["tags_in_use"] = queries.tags_in_use(db, scopes)

    db.commit()
    return result
```

- [ ] **Step 5: Remove `boot_session_impl` calls from context tests that only need them for the session gate**

In `tests/test_context.py`, the existing tests call `boot_session_impl` at the start to create a session. These should keep working — `boot_session_impl` creates items and a session, which some tests depend on for `session_activity`. No changes needed to existing tests; they still pass because `boot_session_impl` still works.

- [ ] **Step 6: Update `refresh_context` tool docstring**

In `src/mimir_mcp/tools/context.py`, in the `register` function, replace the `refresh_context_tool` docstring:

```python
        """Reload your current state view. With no arguments, returns the top-level boot summary. With item_id, returns the boot payload PLUS {item, children, item_facts} for the focused item — a complete post-compaction rebuild. On success, includes scopes, session_activity, recent_shared_activity, and top-30 tags_in_use. Unlike start_session, does not create a new session."""
```

with:

```python
        """Reload your current state view. With no arguments, returns the top-level boot summary. With item_id, returns the boot payload PLUS {item, children, item_facts} for the focused item — a complete post-compaction rebuild. Includes scopes, recent_shared_activity, and top-30 tags_in_use. session_activity is included when an active session exists. Does not require an active session."""
```

- [ ] **Step 7: Run full test suite**

Run: `cd ~/repositories/private/mimir && conda run -n mimir pytest -v`

Expected: ALL PASS

- [ ] **Step 8: Commit**

```bash
cd ~/repositories/private/mimir
git add src/mimir_mcp/tools/context.py tests/test_context.py
git commit -m "feat(context): remove session gates from set_context and refresh_context"
```

---

### Task 6: Version bump

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Bump version**

In `pyproject.toml`, change:

```toml
version = "0.9.0"
```

to:

```toml
version = "0.10.0"
```

- [ ] **Step 2: Run full test suite one final time**

Run: `cd ~/repositories/private/mimir && conda run -n mimir pytest -v`

Expected: ALL PASS

- [ ] **Step 3: Commit**

```bash
cd ~/repositories/private/mimir
git add pyproject.toml
git commit -m "chore: bump version to 0.10.0 (wire-breaking: save_session removed)"
```
