# State Model & Session Cleanup Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Trim what loads at each view state, split facts into top-level (parent_id=NULL) vs. scoped (parent_id=item), add tag-management tools (`list_tags`, `suggest_tag_consolidations`, `merge_tags`), surface consolidation candidates on `end_session`, and clean up the session lifecycle by removing `active_context_id` persistence and the auto-close-stale behavior.

**Architecture:** Changes land across `queries/` (new helpers), `tools/` (new `tags.py` module, edits to `context.py` and `session.py`), `models.py` (response-shape updates), `server.py` (instructions + tool registration), `migrations/` (new `002_drop_active_context_id.sql`). Each shape change is covered by targeted tests; the migration is tested by round-tripping session rows.

**Tech Stack:** Python 3.11 (conda env `mimir`), SQLite via the in-repo `Database` class, FastMCP for tool registration, Pydantic for input/output models, pytest for tests, ruff for formatting (pre-commit hook).

**Prerequisites:**
- Activate the `mimir` conda env. Install dev deps if fresh: `pip install -e ".[dev]"` and `pre-commit install`.
- Feature branch is already checked out: `feat/state-model-and-session-cleanup` (commit `a3cf914` landed the spec).
- Run `pytest` from the repo root to verify a clean baseline before starting.

**Reference:** Spec at `docs/specs/2026-04-19-state-model-and-session-cleanup-design.md`.

**Commit discipline:** One commit per task. Never skip pre-commit (ruff). Conventional commit messages match the existing history (`feat(scope): ...`, `refactor(scope): ...`, `test(scope): ...`, `docs: ...`).

---

### Task 1: Remove auto-close-stale behavior and `stale_sessions` field

**Files:**
- Modify: `src/mimir_mcp/queries/session.py` (remove `sessions_close_stale` function)
- Modify: `src/mimir_mcp/tools/session.py:15-86` (`boot_session_impl`: remove close-stale call, remove `stale_sessions` from return dict)
- Modify: `src/mimir_mcp/models.py:164-174` (`SessionBootResponse`: remove `stale_sessions` field)
- Modify: `tests/test_session.py` (remove / update the two stale-session tests)

- [ ] **Step 1: Update the stale-session tests (failing)**

Replace the two affected tests in `tests/test_session.py`:

```python
def test_boot_does_not_auto_close_other_sessions(seed_data):
    """With auto-close-stale removed, prior open sessions for this user remain open."""
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("jimmy",))
    seed_data.commit()
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    # Both the previous session and the new one should be open.
    open_sessions = seed_data.fetchall(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    assert len(open_sessions) == 2


def test_boot_response_has_no_stale_sessions_field(seed_data):
    """stale_sessions is no longer part of the boot response."""
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert "stale_sessions" not in result
```

Delete the old `test_boot_auto_closes_stale_sessions` test. Keep `test_boot_does_not_close_other_users_sessions` and `test_boot_creates_session` — but remove the `assert result["stale_sessions"] == 0` line from the latter.

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_session.py -v`
Expected: `test_boot_does_not_auto_close_other_sessions` FAILs (finds only 1 open session — the old one was auto-closed). `test_boot_response_has_no_stale_sessions_field` FAILs (`stale_sessions` still present).

- [ ] **Step 3: Remove `sessions_close_stale` from `queries/session.py`**

Delete the entire `sessions_close_stale` function (lines 8-22 of `src/mimir_mcp/queries/session.py`).

- [ ] **Step 4: Update `boot_session_impl` in `tools/session.py`**

Remove the call and the field. The function becomes (preserving everything else):

```python
def boot_session_impl(db: Database, user_id: str, scopes: list[str]) -> dict:
    """Start a new session. Returns structured boot data plus tags_in_use per scope."""
    # 1. Get the last completed session (before creating a new one)
    last_session_row = queries.sessions_get_last_completed(db, user_id)
    last_session = None
    if last_session_row:
        last_session = {"summary": last_session_row["summary"]}

    # 2. Create new session
    queries.sessions_create(db, user_id)

    # 3. Fetch user profile
    user_row = queries.users_get(db, user_id)
    user = {"id": user_row["id"], "name": user_row["name"]}

    # 4. Fetch scopes with members (filtered to requested scopes)
    all_user_scopes = queries.scopes_for_user(db, user_id)
    scope_list = []
    for s in all_user_scopes:
        if s["id"] in scopes:
            scope_list.append(
                {
                    "id": s["id"],
                    "name": s["name"],
                    "description": s["description"],
                    "members": s["member_ids"],
                }
            )

    # 5-7. Fetch items, reminders, facts (delegated to shared helper)
    summary = build_boot_summary(db, user_id, scopes)

    # 8. Fetch shared activity (do NOT advance cursor -- crash safety)
    shared_activity_raw = queries.activity_get_shared(db, user_id, scopes)
    shared_activity = [dict(a) for a in shared_activity_raw]

    # Also fetch recently created/updated items by other users
    recent_items_by_others = queries.items_recent_by_others(db, user_id, scopes)
    existing_item_ids = {a.get("item_id") for a in shared_activity}
    for item in recent_items_by_others:
        if item["id"] not in existing_item_ids:
            shared_activity.append(
                {
                    "item_id": item["id"],
                    "actor": item["created_by"],
                    "event": "created",
                    "summary": item["summary"],
                    "scope": item["scope"],
                    "created_at": item["created_at"],
                }
            )

    # 9. Tags in use per scope
    tags_by_scope = queries.tags_in_use(db, scopes)

    # 10. Commit and return
    db.commit()

    return {
        "user": user,
        "scopes": scope_list,
        "last_session": last_session,
        **summary,
        "recent_shared_activity": shared_activity,
        "tags_in_use": tags_by_scope,
    }
```

- [ ] **Step 5: Remove `stale_sessions` from `SessionBootResponse`**

In `src/mimir_mcp/models.py`, delete the `stale_sessions: int = 0` line (line 168).

- [ ] **Step 6: Run tests to verify pass**

Run: `pytest tests/test_session.py -v`
Expected: all tests PASS (including the two new tests).

- [ ] **Step 7: Run the full suite**

Run: `pytest`
Expected: all tests PASS.

- [ ] **Step 8: Commit**

```bash
git add src/mimir_mcp/queries/session.py src/mimir_mcp/tools/session.py src/mimir_mcp/models.py tests/test_session.py
git commit -m "refactor(session): remove auto-close-stale and stale_sessions field

Orphan sessions now persist until explicitly closed. Multi-terminal
defects are documented in the spec as known issues to be addressed
in a future multi-session redesign."
```

---

### Task 2: Migration 002 — drop `active_context_id` column

**Files:**
- Create: `src/mimir_mcp/migrations/002_drop_active_context_id.sql`
- Create: `tests/test_migration_002.py`

- [ ] **Step 1: Write the migration test (failing)**

Create `tests/test_migration_002.py`:

```python
"""Test migration 002 drops active_context_id while preserving session data."""

from pathlib import Path
import sqlite3

import pytest

from mimir_mcp.db import Database


MIGRATIONS_DIR = Path(__file__).parent.parent / "src" / "mimir_mcp" / "migrations"


def _apply_only(db: Database, *names: str) -> None:
    """Apply a fixed list of migration files in order."""
    for name in names:
        path = MIGRATIONS_DIR / name
        db.conn.executescript(path.read_text())
        db.conn.execute(
            "INSERT OR IGNORE INTO schema_version (version) VALUES (?)",
            (int(name.split("_")[0]),),
        )
        db.commit()


def test_migration_002_drops_active_context_id_and_preserves_data(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    # Apply only 001 to get the old schema with active_context_id
    _apply_only(db, "001_initial.sql")

    # Insert a user and a session with active_context_id populated
    db.execute(
        "INSERT INTO users (id, name, is_admin, api_key) VALUES (?, ?, ?, ?)",
        ("jimmy", "Jimmy", True, "key-jimmy"),
    )
    db.execute("INSERT INTO scopes VALUES (?, ?, ?)", ("jimmy", "Jimmy", "personal"))
    db.execute("INSERT INTO scope_members VALUES (?, ?)", ("jimmy", "jimmy"))
    db.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, 'project', 'active', 'Provider Ops', 'jimmy', 'jimmy')"
    )
    db.commit()
    proj_id = db.fetchone("SELECT last_insert_rowid() as id")["id"]
    db.execute(
        "INSERT INTO sessions (user_id, active_context_id, summary) VALUES (?, ?, ?)",
        ("jimmy", proj_id, "boot-test"),
    )
    db.commit()
    session_id_before = db.fetchone("SELECT last_insert_rowid() as id")["id"]

    # Apply migration 002
    _apply_only(db, "002_drop_active_context_id.sql")

    # The column is gone
    cols = [r["name"] for r in db.fetchall("PRAGMA table_info(sessions)")]
    assert "active_context_id" not in cols
    assert set(cols) == {"id", "user_id", "started_at", "ended_at", "summary", "log_path"}

    # Session row survives with the same id and summary
    row = db.fetchone("SELECT id, user_id, summary FROM sessions WHERE id = ?", (session_id_before,))
    assert row is not None
    assert row["user_id"] == "jimmy"
    assert row["summary"] == "boot-test"

    # Index is recreated
    idx = db.fetchall("PRAGMA index_list(sessions)")
    idx_names = [r["name"] for r in idx]
    assert "idx_sessions_user" in idx_names

    db.close()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_migration_002.py -v`
Expected: FAIL with `FileNotFoundError` or similar — migration file does not exist yet.

- [ ] **Step 3: Create the migration file**

Create `src/mimir_mcp/migrations/002_drop_active_context_id.sql`:

```sql
-- Migration 002: drop sessions.active_context_id
--
-- Server-side focus is obsoleted by the parent-based fact model.
-- SQLite pre-3.35 lacks ALTER TABLE DROP COLUMN, so use the recreate pattern
-- (portable and works on every deployment regardless of SQLite version).

CREATE TABLE sessions_new (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL REFERENCES users(id),
    started_at  TEXT NOT NULL DEFAULT (datetime('now')),
    ended_at    TEXT,
    summary     TEXT,
    log_path    TEXT
);

INSERT INTO sessions_new (id, user_id, started_at, ended_at, summary, log_path)
SELECT id, user_id, started_at, ended_at, summary, log_path FROM sessions;

DROP TABLE sessions;
ALTER TABLE sessions_new RENAME TO sessions;

CREATE INDEX idx_sessions_user ON sessions(user_id, ended_at);
```

- [ ] **Step 4: Run test to verify pass**

Run: `pytest tests/test_migration_002.py -v`
Expected: PASS.

- [ ] **Step 5: Run full suite**

Run: `pytest`
Expected: all tests PASS. (Note: `item_history.session_id` still references `sessions(id)` — verify no FK breakage under the recreate pattern. If any test fails with FK errors, investigate the recreate ordering; it shouldn't, because the ids are preserved.)

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/migrations/002_drop_active_context_id.sql tests/test_migration_002.py
git commit -m "feat(migrations): drop sessions.active_context_id column

Server-side focus is obsolete with the parent-based fact model. Uses
the recreate pattern for SQLite <3.35 compatibility; session ids and
foreign key references are preserved."
```

---

### Task 3: Stop writing `active_context_id` from `set_context`

**Files:**
- Modify: `src/mimir_mcp/queries/session.py` (remove `sessions_update_context`)
- Modify: `src/mimir_mcp/tools/context.py:126-165` (`set_context_impl`: drop the update_context call, simplify)
- Modify: `tests/test_context.py` (remove assertion on `session["active_context_id"]`)

- [ ] **Step 1: Update `test_set_context_focuses_item` test (failing intent)**

In `tests/test_context.py`, modify `test_set_context_focuses_item`:

```python
def test_set_context_returns_item_and_children(seed_data):
    """set_context returns item detail + children. No longer persists focus server-side."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(
        seed_data, "jimmy", "Provider Ops", detail="Full project details here"
    )
    _create_child(seed_data, proj_id, "jimmy", "task", "Set up DNS")

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    # Result should contain item detail with detail
    assert result["item"]["id"] == proj_id
    assert result["item"]["detail"] == "Full project details here"

    # Children should be present
    all_children = []
    for children_of_type in result["children"].values():
        all_children.extend(children_of_type)
    assert len(all_children) >= 1


def test_set_context_does_not_persist_focus(seed_data):
    """Confirms set_context is stateless: no active_context_id written (column is gone)."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)
    proj_id = _create_project(seed_data, "jimmy", "X")

    set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    cols = [r["name"] for r in seed_data.fetchall("PRAGMA table_info(sessions)")]
    assert "active_context_id" not in cols
```

Delete the old `test_set_context_focuses_item` (it asserts `active_context_id`).

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_context.py::test_set_context_returns_item_and_children tests/test_context.py::test_set_context_does_not_persist_focus -v`
Expected: The persist test may pass because migration 002 is landed (column gone). The `returns_item_and_children` test will pass too. If both pass without code change, add a temporary assertion `assert False` to confirm we're running the new file, then remove. (If `set_context_impl` still calls `sessions_update_context`, that will now raise a SQL error because the column no longer exists — which is the real signal.)

Realistic expectation: running the existing `set_context_impl` against the post-migration DB **will raise** `sqlite3.OperationalError` because `sessions_update_context` does `UPDATE sessions SET active_context_id = ?` and the column no longer exists. Tests fail with that error.

- [ ] **Step 3: Remove `sessions_update_context` from `queries/session.py`**

Delete lines 52-57 of `src/mimir_mcp/queries/session.py` (the `sessions_update_context` function).

- [ ] **Step 4: Simplify `set_context_impl`**

Replace `set_context_impl` in `src/mimir_mcp/tools/context.py`:

```python
def set_context_impl(
    db: Database, user_id: str, scopes: list[str], *, item_id: int | None = None
) -> dict:
    """Return a focused slice (item + children + item_facts) or the boot overview.

    Stateless — does not persist server-side focus.
    """
    session = queries.sessions_get_active(db, user_id)
    if not session:
        return {"error": "No active session found."}

    if item_id is None:
        return build_boot_summary(db, user_id, scopes)

    # Validate item exists
    item_row = queries.items_get_by_id(db, item_id)
    if not item_row:
        return {"error": f"Item {item_id} not found."}

    # Validate item is in one of user's scopes
    if item_row["scope"] not in scopes:
        return {"error": f"Item {item_id} is not in your accessible scopes."}

    return build_focused_view(db, item_id, scopes)
```

(Note: `build_focused_view` is updated in later tasks; for now, it still returns `facts` — that renaming happens in Task 7.)

- [ ] **Step 5: Run tests to verify pass**

Run: `pytest tests/test_context.py -v`
Expected: all tests PASS.

- [ ] **Step 6: Run full suite**

Run: `pytest`
Expected: all tests PASS.

- [ ] **Step 7: Commit**

```bash
git add src/mimir_mcp/queries/session.py src/mimir_mcp/tools/context.py tests/test_context.py
git commit -m "refactor(context): drop server-side focus persistence from set_context

set_context is now stateless. Removes sessions_update_context helper.
Clients drill in by calling set_context(item_id); focus is not
remembered across calls — that is intentional."
```

---

### Task 4: Top-level slim items — drop `tags`, omit `scope` when personal

**Files:**
- Modify: `src/mimir_mcp/tools/context.py:67-101` (`slim_item` function)
- Modify: `src/mimir_mcp/models.py` (`ItemSummary`: remove `tags` default or make it optional)
- Modify: `tests/test_context.py` or `tests/test_session.py` (add new tests)

**Implementation note:** `slim_item` is used for top-level projects/tasks/ideas (boot) AND for children in focused views. This task only changes the top-level usage. Task 5 introduces a separate `child_slim_item`. To avoid breaking focused views in this task, we rename the existing function to `top_slim_item` here and have `build_focused_view` temporarily keep using it — Task 5 then swaps in `child_slim_item` for children.

- [ ] **Step 1: Write failing tests**

Add to `tests/test_session.py`:

```python
def test_boot_projects_drop_tags(seed_data):
    """Top-level projects in the boot response carry no tags field."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'project', 'active', 'P1', 'jimmy', 'jimmy')"
    )
    seed_data.commit()
    pid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES ('venture')")
    seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (pid, "venture"))
    seed_data.commit()

    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    projects = result["projects"]
    assert len(projects) == 1
    assert "tags" not in projects[0]


def test_boot_omits_scope_when_personal(seed_data):
    """Scope is omitted on items in the caller's personal scope."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'project', 'active', 'Personal project', 'jimmy', 'jimmy')"
    )
    seed_data.commit()

    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    personal = [p for p in result["projects"] if p["summary"] == "Personal project"][0]
    assert "scope" not in personal


def test_boot_keeps_scope_when_shared(seed_data):
    """Scope is kept for items in a shared (non-caller-personal) scope."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('household', 'project', 'active', 'Family project', 'jimmy', 'jimmy')"
    )
    seed_data.commit()

    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    family = [p for p in result["projects"] if p["summary"] == "Family project"][0]
    assert family["scope"] == "household"
```

- [ ] **Step 2: Run tests to verify fail**

Run: `pytest tests/test_session.py::test_boot_projects_drop_tags tests/test_session.py::test_boot_omits_scope_when_personal tests/test_session.py::test_boot_keeps_scope_when_shared -v`
Expected: FAIL — `tags` is still present; `scope` is always present.

- [ ] **Step 3: Replace `slim_item` with a personal-scope-aware shape**

`slim_item` currently takes a `row`. To know "is scope equal to the caller's personal scope?" the function needs the caller's user_id. The personal scope id equals the user_id (per `scopes_for_user` semantics and the seed: user `jimmy` has scope `jimmy`).

Update `src/mimir_mcp/tools/context.py`:

```python
def slim_item(row, *, personal_scope: str | None = None) -> dict:
    """Serialize an item for top-level listings.

    Optional fields omitted when null/empty/zero. When `personal_scope` matches
    the item's scope, the `scope` key is omitted from the output.
    """
    out = {
        "id": row["id"],
        "summary": row["summary"],
        "status": row["status"],
    }
    if personal_scope is None or row["scope"] != personal_scope:
        out["scope"] = row["scope"]

    priority = row["priority"] if "priority" in row.keys() else None
    if priority and priority != "normal":
        out["priority"] = priority

    child_count = row["child_count"] if "child_count" in row.keys() else 0
    if child_count:
        out["child_count"] = child_count

    completed_count = row["completed_count"] if "completed_count" in row.keys() else 0
    if completed_count:
        out["completed_count"] = completed_count

    due_date = row["due_date"] if "due_date" in row.keys() else None
    if due_date:
        out["due_date"] = due_date

    return out
```

Changes vs. the existing implementation:
- **Removed** the `tags` block entirely.
- **Added** `personal_scope` kwarg; when set and matches, `scope` is omitted.
- **Changed** `priority`: omit when `"normal"` as well as null.

- [ ] **Step 4: Pass `personal_scope` from boot**

Update `build_boot_summary` in `src/mimir_mcp/tools/context.py` to pass `personal_scope=user_id`. The signature currently takes `user_id` as second param — good. Rewrite:

```python
def build_boot_summary(db: Database, user_id: str, scopes: list[str]) -> dict:
    """Build the boot-level summary (projects, tasks, reminders, ideas, facts)."""
    items = queries.items_top_level_active(db, scopes, exclude_types=("fact", "reminder"))
    projects = []
    tasks = []
    ideas = []
    for item in items:
        item_type = item["type"]
        slim = slim_item(item, personal_scope=user_id)
        if item_type == "project":
            projects.append(slim)
        elif item_type == "task":
            tasks.append(slim)
        elif item_type == "idea":
            ideas.append(slim)

    reminders_raw = queries.items_reminders_upcoming(db, scopes)
    reminders = [slim_item(r, personal_scope=user_id) for r in reminders_raw]

    facts_raw = queries.items_facts_by_scope(db, scopes)
    facts = serialize_facts_flat(facts_raw)

    return {
        "projects": projects,
        "tasks": tasks,
        "ideas": ideas,
        "reminders": reminders,
        "facts": facts,
    }
```

Also update the focused view caller (`build_focused_view`) — pass `personal_scope=` too, even for children, until Task 5 replaces it:

```python
def build_focused_view(db: Database, item_id: int, scopes: list[str], personal_scope: str) -> dict:
    item_row = queries.items_get_by_id(db, item_id)
    item_detail = dict(item_row)

    children_raw = queries.items_get_children(db, item_id, scopes)
    children: dict[str, list[dict]] = {}
    for child in children_raw:
        children.setdefault(child["type"], []).append(slim_item(child, personal_scope=personal_scope))

    facts_raw = queries.items_facts_by_scope(db, scopes)
    facts = serialize_facts_flat(facts_raw)

    return {
        "item": item_detail,
        "children": children,
        "facts": facts,
    }
```

Update callers of `build_focused_view` in `set_context_impl` and `refresh_context_impl` to pass `personal_scope=user_id`.

- [ ] **Step 5: Update `ItemSummary` in `models.py`**

Remove the `tags: list[str] = []` default. New shape:

```python
class ItemSummary(BaseModel):
    id: int
    type: str | None = None  # omitted in slim payload; present on detail
    scope: str | None = None
    status: str
    priority: str | None = None
    summary: str
    due_date: str | None = None
    child_count: int | None = None
    completed_count: int | None = None
    position: float | None = None
```

(`type` becomes optional because the slim boot payload no longer includes it — projects/tasks/ideas are grouped by the response key itself.)

- [ ] **Step 6: Run tests to verify pass**

Run: `pytest tests/test_session.py tests/test_context.py -v`
Expected: all PASS, including the three new ones.

- [ ] **Step 7: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 8: Commit**

```bash
git add src/mimir_mcp/tools/context.py src/mimir_mcp/models.py tests/test_session.py
git commit -m "feat(context): drop tags and personal-scope from slim items

slim_item no longer includes tags at top-level. Scope is omitted when
the item lives in the caller's personal scope (noise elimination);
kept when in a shared scope. priority='normal' is also omitted."
```

---

### Task 5: Child slim shape — `{id, summary, due_date?}` only

**Files:**
- Modify: `src/mimir_mcp/tools/context.py` (add `child_slim_item`, use it in `build_focused_view`)
- Modify: `tests/test_context.py` (add test)

- [ ] **Step 1: Write the failing test**

Add to `tests/test_context.py`:

```python
def test_focused_view_children_are_minimal(seed_data):
    """Children in focused views contain only id, summary, and optional due_date."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Proj")
    t1 = _create_child(seed_data, proj_id, "jimmy", "task", "Due soon")
    seed_data.execute(
        "UPDATE items SET due_date = datetime('now','+1 day') WHERE id = ?", (t1,)
    )
    t2 = _create_child(seed_data, proj_id, "jimmy", "task", "No deadline")
    seed_data.commit()

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)
    tasks = result["children"]["task"]

    by_summary = {t["summary"]: t for t in tasks}
    assert set(by_summary["Due soon"].keys()) == {"id", "summary", "due_date"}
    assert set(by_summary["No deadline"].keys()) == {"id", "summary"}
```

- [ ] **Step 2: Run test to verify fail**

Run: `pytest tests/test_context.py::test_focused_view_children_are_minimal -v`
Expected: FAIL — child dicts still contain `scope`, `status`, possibly `child_count`.

- [ ] **Step 3: Add `child_slim_item` to `tools/context.py`**

Add above `build_focused_view`:

```python
def child_slim_item(row) -> dict:
    """Minimal child shape: id, summary, optional due_date only."""
    out = {"id": row["id"], "summary": row["summary"]}
    due_date = row["due_date"] if "due_date" in row.keys() else None
    if due_date:
        out["due_date"] = due_date
    return out
```

- [ ] **Step 4: Use `child_slim_item` in `build_focused_view`**

Update `build_focused_view` to use `child_slim_item` for children (drop `personal_scope=` — no longer needed for children):

```python
def build_focused_view(db: Database, item_id: int, scopes: list[str]) -> dict:
    item_row = queries.items_get_by_id(db, item_id)
    item_detail = dict(item_row)

    children_raw = queries.items_get_children(db, item_id, scopes)
    children: dict[str, list[dict]] = {}
    for child in children_raw:
        children.setdefault(child["type"], []).append(child_slim_item(child))

    # Facts renamed in Task 7 — still uses top-level facts here temporarily
    facts_raw = queries.items_facts_by_scope(db, scopes)
    facts = serialize_facts_flat(facts_raw)

    return {"item": item_detail, "children": children, "facts": facts}
```

Update callers (`set_context_impl`, `refresh_context_impl`) to drop the now-unused `personal_scope` kwarg in their `build_focused_view(...)` calls.

- [ ] **Step 5: Run test to verify pass**

Run: `pytest tests/test_context.py::test_focused_view_children_are_minimal -v`
Expected: PASS.

- [ ] **Step 6: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 7: Commit**

```bash
git add src/mimir_mcp/tools/context.py tests/test_context.py
git commit -m "feat(context): minimal child shape in focused views

Children now expose only id, summary, and optional due_date. Dropped
scope, status, priority, tags, child_count, completed_count — Claude
drills with get_details when any of those matter."
```

---

### Task 6: Boot returns only top-level facts (`parent_id IS NULL`)

**Files:**
- Modify: `src/mimir_mcp/queries/items.py` (add `items_top_level_facts`)
- Modify: `src/mimir_mcp/tools/context.py:14-42` (`build_boot_summary` uses the new query)
- Modify: `tests/test_session.py` or `test_context.py` (add test)

- [ ] **Step 1: Write the failing test**

Add to `tests/test_session.py`:

```python
def test_boot_facts_only_top_level(seed_data):
    """Boot 'facts' array contains only facts with parent_id IS NULL."""
    # Top-level fact
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'fact', 'active', 'Global principle', 'jimmy', 'jimmy')"
    )
    # Project
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'project', 'active', 'Project X', 'jimmy', 'jimmy')"
    )
    seed_data.commit()
    proj_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    # Project-scoped fact
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, parent_id, created_by, updated_by) "
        "VALUES ('jimmy', 'fact', 'active', 'Project-specific', ?, 'jimmy', 'jimmy')",
        (proj_id,),
    )
    seed_data.commit()

    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    fact_summaries = [f["summary"] for f in result["facts"]]
    assert "Global principle" in fact_summaries
    assert "Project-specific" not in fact_summaries
```

- [ ] **Step 2: Run test to verify fail**

Run: `pytest tests/test_session.py::test_boot_facts_only_top_level -v`
Expected: FAIL — both facts appear because `items_facts_by_scope` returns all.

- [ ] **Step 3: Add `items_top_level_facts` query**

Add to `src/mimir_mcp/queries/items.py`:

```python
def items_top_level_facts(db: Database, scopes: list[str]):
    """Active (non-expired) facts with no parent (parent_id IS NULL) across the given scopes."""
    sp = ",".join("?" for _ in scopes)
    return db.fetchall(
        f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags "
        f"FROM items i LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE i.scope IN ({sp}) AND i.type = 'fact' "
        f"AND i.parent_id IS NULL "
        f"AND i.status = 'active' "
        f"AND (i.valid_until IS NULL OR i.valid_until > datetime('now')) "
        f"GROUP BY i.id",
        tuple(scopes),
    )
```

- [ ] **Step 4: Use it in `build_boot_summary`**

Replace `facts_raw = queries.items_facts_by_scope(db, scopes)` with:

```python
    facts_raw = queries.items_top_level_facts(db, scopes)
```

- [ ] **Step 5: Run test to verify pass**

Run: `pytest tests/test_session.py::test_boot_facts_only_top_level -v`
Expected: PASS.

- [ ] **Step 6: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 7: Commit**

```bash
git add src/mimir_mcp/queries/items.py src/mimir_mcp/tools/context.py tests/test_session.py
git commit -m "feat(context): boot returns only top-level facts

Facts with parent_id IS NULL are the 'global principles / user profile'
tier and load at boot. Project-scoped facts (parent_id set) are
excluded — they load only when their parent is focused (Task 7)."
```

---

### Task 7: Focused view returns `item_facts` (parent-scoped)

**Files:**
- Modify: `src/mimir_mcp/tools/context.py` (`build_focused_view`: rename `facts` → `item_facts`, switch query)
- Modify: `tests/test_context.py` (update tests to expect `item_facts`)

- [ ] **Step 1: Write the failing test**

Add to `tests/test_context.py`:

```python
def test_focused_view_returns_item_facts_only(seed_data):
    """set_context(item_id) returns only facts whose parent_id == item_id."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "P")
    _create_fact(seed_data, "jimmy", "Global fact")  # no parent
    # Fact under project
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, parent_id, created_by, updated_by) "
        "VALUES ('jimmy', 'fact', 'active', 'Project fact', ?, 'jimmy', 'jimmy')",
        (proj_id,),
    )
    seed_data.commit()

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)
    assert "item_facts" in result
    assert "facts" not in result  # renamed — no collision with top-level key
    summaries = [f["summary"] for f in result["item_facts"]]
    assert summaries == ["Project fact"]
```

Also update `test_set_context_returns_facts_as_flat_list` (lines 98+ of existing `test_context.py`) to use the new key `item_facts` and only expect parent-scoped facts.

- [ ] **Step 2: Run tests to verify fail**

Run: `pytest tests/test_context.py -v`
Expected: the new test FAILs (no `item_facts` key). The renamed test also FAILs.

- [ ] **Step 3: Update `build_focused_view`**

Replace the facts block in `build_focused_view`:

```python
def build_focused_view(db: Database, item_id: int, scopes: list[str]) -> dict:
    item_row = queries.items_get_by_id(db, item_id)
    item_detail = dict(item_row)

    children_raw = queries.items_get_children(db, item_id, scopes)
    children: dict[str, list[dict]] = {}
    for child in children_raw:
        children.setdefault(child["type"], []).append(child_slim_item(child))

    item_facts_raw = queries.items_facts_for_items(db, [item_id], scopes)
    item_facts = serialize_facts_flat(item_facts_raw)

    return {"item": item_detail, "children": children, "item_facts": item_facts}
```

Uses the already-existing `items_facts_for_items(db, [item_id], scopes)` which filters by `parent_id IN (…)`.

- [ ] **Step 4: Handle the rebuild response (`refresh_context(item_id)`)**

`refresh_context_impl` currently merges boot + focused fields. Since focused now uses `item_facts` (no collision), the merge is clean:

```python
def refresh_context_impl(
    db: Database, user_id: str, scopes: list[str], *, item_id: int | None = None
) -> dict:
    session = queries.sessions_get_active(db, user_id)
    if not session:
        return {"error": "No active session found."}

    session_id = session["id"]

    if item_id is not None:
        item_row = queries.items_get_by_id(db, item_id)
        if not item_row:
            return {"error": f"Item {item_id} not found."}
        if item_row["scope"] not in scopes:
            return {"error": f"Item {item_id} is not in your accessible scopes."}
        result = build_boot_summary(db, user_id, scopes)  # top-level facts as `facts`
        result.update(build_focused_view(db, item_id, scopes))  # adds item, children, item_facts
    else:
        result = build_boot_summary(db, user_id, scopes)

    # Scopes, activity, tags_in_use — unchanged
    all_user_scopes = queries.scopes_for_user(db, user_id)
    scope_list = []
    for s in all_user_scopes:
        if s["id"] in scopes:
            scope_list.append(
                {"id": s["id"], "name": s["name"],
                 "description": s["description"], "members": s["member_ids"]}
            )
    result["scopes"] = scope_list
    activity_raw = queries.items_session_activity(db, session_id)
    result["session_activity"] = [dict(a) for a in activity_raw]
    shared_activity_raw = queries.activity_get_shared(db, user_id, scopes)
    result["recent_shared_activity"] = [dict(a) for a in shared_activity_raw]
    result["tags_in_use"] = queries.tags_in_use(db, scopes)

    db.commit()
    return result
```

(Note: the `build_boot_summary` call in the rebuild path includes `projects/tasks/ideas/reminders/facts`, which matches the spec — a post-compaction rebuild restores everything.)

- [ ] **Step 5: Run tests to verify pass**

Run: `pytest tests/test_context.py -v`
Expected: all PASS.

- [ ] **Step 6: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 7: Commit**

```bash
git add src/mimir_mcp/tools/context.py tests/test_context.py
git commit -m "feat(context): focused views return parent-scoped item_facts

build_focused_view now fetches facts via items_facts_for_items,
filtering to parent_id = focused item. Response key is 'item_facts'
to avoid collision with top-level 'facts' during rebuild."
```

---

### Task 8: Trim fact shape to `{id, summary}`

**Files:**
- Modify: `src/mimir_mcp/tools/context.py:45-64` (`serialize_facts_flat`)
- Modify: `tests/test_session.py` and/or `tests/test_context.py` (add test)

- [ ] **Step 1: Write failing tests**

Add to `tests/test_session.py`:

```python
def test_boot_fact_shape_is_minimal(seed_data):
    """Boot facts contain only id and summary — no tags, no source."""
    seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES ('rule')")
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, source, created_by, updated_by) "
        "VALUES ('jimmy', 'fact', 'active', 'Top fact', 'user_stated', 'jimmy', 'jimmy')"
    )
    seed_data.commit()
    fid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (fid, "rule"))
    seed_data.commit()

    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert result["facts"]
    for f in result["facts"]:
        assert set(f.keys()) == {"id", "summary"}
```

- [ ] **Step 2: Run test to verify fail**

Run: `pytest tests/test_session.py::test_boot_fact_shape_is_minimal -v`
Expected: FAIL — extra keys `tags` and `source` present.

- [ ] **Step 3: Simplify `serialize_facts_flat`**

Replace in `src/mimir_mcp/tools/context.py`:

```python
def serialize_facts_flat(facts_raw) -> list[dict]:
    """Minimal fact shape: {id, summary}. tags & source accessible via get_details."""
    return [{"id": f["id"], "summary": f["summary"]} for f in facts_raw]
```

- [ ] **Step 4: Run test to verify pass**

Run: `pytest tests/test_session.py::test_boot_fact_shape_is_minimal -v`
Expected: PASS.

- [ ] **Step 5: Run full suite**

Run: `pytest`
Expected: all PASS. (If `tests/test_context.py::test_set_context_returns_facts_as_flat_list` or similar has an assertion on `tags` or `source` fields, update it to assert `{id, summary}`.)

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/tools/context.py tests/test_session.py tests/test_context.py
git commit -m "refactor(facts): slim boot/focused facts to {id, summary}

Drops tags and source from top-level and item-scoped fact payloads.
Provenance/tagging are drill-down concerns; callers needing them use
get_details([fact_id])."
```

---

### Task 9: `tags_in_use` — top 30 per scope

**Files:**
- Modify: `src/mimir_mcp/queries/tags.py` (order + limit)
- Add: `tests/test_tags.py` (new test file)

- [ ] **Step 1: Write failing test**

Create `tests/test_tags.py`:

```python
from mimir_mcp import queries


def test_tags_in_use_limited_to_top_30(seed_data):
    """tags_in_use returns at most 30 tags per scope, ordered by usage count desc."""
    # Insert an item
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'note', 'active', 'N', 'jimmy', 'jimmy')"
    )
    seed_data.commit()
    iid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]

    # 40 distinct tag names, each used once EXCEPT 'heavy' which is used 5 times via extra items
    for i in range(40):
        seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", (f"t{i:02d}",))
        seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (iid, f"t{i:02d}"))
    seed_data.commit()

    result = queries.tags_in_use(seed_data, ["jimmy"])
    assert "jimmy" in result
    # 40 distinct tags on one item -> 40 associations, limit 30
    assert len(result["jimmy"]) == 30
```

- [ ] **Step 2: Run test to verify fail**

Run: `pytest tests/test_tags.py -v`
Expected: FAIL — returns 40 tags (no limit applied).

- [ ] **Step 3: Rewrite `tags_in_use` with count + limit**

Replace in `src/mimir_mcp/queries/tags.py`:

```python
"""Domain queries — tag operations."""

from __future__ import annotations

from mimir_mcp.db import Database


TAGS_IN_USE_LIMIT_PER_SCOPE = 30


def tags_in_use(db: Database, scopes: list[str]) -> dict[str, list[str]]:
    """Return the top-30 most-used tags per scope, keyed by scope id.

    Includes tags from items in all statuses — historical tags remain useful
    for consistent naming. Ordered by usage count (descending) then tag name.
    """
    if not scopes:
        return {}
    sp = ",".join("?" for _ in scopes)
    rows = db.fetchall(
        f"SELECT i.scope, it.tag_id, COUNT(*) as cnt "
        f"FROM item_tags it "
        f"JOIN items i ON it.item_id = i.id "
        f"WHERE i.scope IN ({sp}) "
        f"GROUP BY i.scope, it.tag_id "
        f"ORDER BY i.scope, cnt DESC, it.tag_id ASC",
        tuple(scopes),
    )
    result: dict[str, list[str]] = {}
    for row in rows:
        bucket = result.setdefault(row["scope"], [])
        if len(bucket) < TAGS_IN_USE_LIMIT_PER_SCOPE:
            bucket.append(row["tag_id"])
    return result


def tags_with_counts(db: Database, scope: str) -> list[dict]:
    """All tags in a scope with their usage counts, ordered by count desc."""
    rows = db.fetchall(
        "SELECT it.tag_id as name, COUNT(*) as count "
        "FROM item_tags it JOIN items i ON it.item_id = i.id "
        "WHERE i.scope = ? "
        "GROUP BY it.tag_id "
        "ORDER BY count DESC, name ASC",
        (scope,),
    )
    return [{"name": r["name"], "count": r["count"]} for r in rows]
```

- [ ] **Step 4: Run test to verify pass**

Run: `pytest tests/test_tags.py -v`
Expected: PASS.

- [ ] **Step 5: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/queries/tags.py tests/test_tags.py
git commit -m "feat(tags): limit tags_in_use to top 30 per scope

Tags are now ordered by usage count (descending) and capped. Full
list is retrievable via the upcoming list_tags tool. Adds the
tags_with_counts helper used by list_tags and the consolidation
suggestions engine."
```

---

### Task 10: Drop `tags_in_use` from `set_context` response

**Files:**
- Modify: `src/mimir_mcp/tools/context.py` (`set_context_impl`)
- Modify: `tests/test_context.py` (add test)

- [ ] **Step 1: Write failing test**

Add to `tests/test_context.py`:

```python
def test_set_context_response_has_no_tags_in_use(seed_data):
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)
    proj_id = _create_project(seed_data, "jimmy", "P")
    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)
    assert "tags_in_use" not in result
```

- [ ] **Step 2: Run test to verify fail**

Run: `pytest tests/test_context.py::test_set_context_response_has_no_tags_in_use -v`
Expected: FAIL — `tags_in_use` still attached.

- [ ] **Step 3: Remove `tags_in_use` from `set_context_impl`**

(Already removed in Task 3's simplified implementation — verify. If any code still attaches `tags_in_use` to the `set_context_impl` return, delete it.)

Expected final form of `set_context_impl` (from Task 3, unchanged):

```python
def set_context_impl(db, user_id, scopes, *, item_id=None):
    session = queries.sessions_get_active(db, user_id)
    if not session:
        return {"error": "No active session found."}
    if item_id is None:
        return build_boot_summary(db, user_id, scopes)
    item_row = queries.items_get_by_id(db, item_id)
    if not item_row:
        return {"error": f"Item {item_id} not found."}
    if item_row["scope"] not in scopes:
        return {"error": f"Item {item_id} is not in your accessible scopes."}
    return build_focused_view(db, item_id, scopes)
```

- [ ] **Step 4: Run test to verify pass**

Run: `pytest tests/test_context.py::test_set_context_response_has_no_tags_in_use -v`
Expected: PASS.

- [ ] **Step 5: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/tools/context.py tests/test_context.py
git commit -m "refactor(context): drop tags_in_use from set_context response

Callers already have tags_in_use from the boot response; fresh data
mid-conversation is available via the upcoming list_tags tool."
```

---

### Task 11: `list_tags` tool

**Files:**
- Create: `src/mimir_mcp/tools/tags.py`
- Modify: `src/mimir_mcp/tools/__init__.py` (register new module)
- Add: tests in `tests/test_tags.py`

- [ ] **Step 1: Write failing tests**

Add to `tests/test_tags.py`:

```python
import pytest

from fastmcp.exceptions import ToolError

from mimir_mcp.tools.tags import list_tags_impl


def _seed_many_tags(db, scope: str, how_many: int):
    db.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, 'note', 'active', 'n', ?, ?)",
        (scope, "jimmy", "jimmy"),
    )
    db.commit()
    iid = db.fetchone("SELECT last_insert_rowid() as id")["id"]
    for i in range(how_many):
        db.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", (f"t{i:02d}",))
        db.execute("INSERT INTO item_tags VALUES (?, ?)", (iid, f"t{i:02d}"))
    db.commit()


def test_list_tags_default_top_30(seed_data):
    _seed_many_tags(seed_data, "jimmy", 40)
    tags = list_tags_impl(seed_data, ["jimmy", "household"], scope="jimmy")
    assert len(tags) == 30
    assert all({"name", "count"} <= set(t.keys()) for t in tags)


def test_list_tags_extended_returns_all(seed_data):
    _seed_many_tags(seed_data, "jimmy", 40)
    tags = list_tags_impl(seed_data, ["jimmy", "household"], scope="jimmy", extended=True)
    assert len(tags) == 40


def test_list_tags_rejects_inaccessible_scope(seed_data):
    with pytest.raises(ToolError):
        list_tags_impl(seed_data, ["jimmy"], scope="household")
```

- [ ] **Step 2: Run to verify fail**

Run: `pytest tests/test_tags.py -v`
Expected: ImportError — `mimir_mcp.tools.tags` does not exist yet.

- [ ] **Step 3: Create the tags tool module**

Create `src/mimir_mcp/tools/tags.py`:

```python
"""Tag tools: list, suggest consolidations, merge."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from fastmcp.exceptions import ToolError

from mimir_mcp import queries
from mimir_mcp.auth import get_current_scopes
from mimir_mcp.db import Database, get_db


LIST_TAGS_DEFAULT_LIMIT = 30


def _require_scope_access(scope: str, scopes: list[str]) -> None:
    if scope not in scopes:
        raise ToolError(f"Scope '{scope}' is not in your accessible scopes.")


def list_tags_impl(
    db: Database,
    scopes: list[str],
    *,
    scope: str,
    extended: bool = False,
) -> list[dict]:
    """Return tags in `scope` with usage counts.

    extended=False (default): top-N by count (N = LIST_TAGS_DEFAULT_LIMIT).
    extended=True: every tag in the scope.
    """
    _require_scope_access(scope, scopes)
    tags = queries.tags_with_counts(db, scope)
    if not extended:
        tags = tags[:LIST_TAGS_DEFAULT_LIMIT]
    return tags


def register(mcp):
    """Register tag-related MCP tools."""

    @mcp.tool
    def list_tags(
        scope: Annotated[
            str,
            Field(description="Scope to list tags for. Must be a scope you can access."),
        ],
        extended: Annotated[
            bool,
            Field(
                default=False,
                description="If True, return every tag in the scope. Default returns only the 30 most-used.",
            ),
        ] = False,
    ) -> list[dict]:
        """List tags currently in use in a given scope, ordered by usage count (descending). Returns the 30 most-used by default; pass extended=True for the full list. Use this when you need to pick consistent tags mid-conversation without reloading the entire boot payload."""
        return list_tags_impl(get_db(), get_current_scopes(), scope=scope, extended=extended)
```

- [ ] **Step 4: Register the module**

Update `src/mimir_mcp/tools/__init__.py`:

```python
from mimir_mcp.tools import (
    context,
    items,
    navigation,
    ordering,
    scopes,
    search,
    session,
    tags,  # new
)

__all__ = [
    "context",
    "items",
    "navigation",
    "ordering",
    "scopes",
    "search",
    "session",
    "tags",
]


def register_all_tools(mcp):
    session.register(mcp)
    context.register(mcp)
    items.register(mcp)
    navigation.register(mcp)
    search.register(mcp)
    ordering.register(mcp)
    scopes.register(mcp)
    tags.register(mcp)
```

- [ ] **Step 5: Run tests to verify pass**

Run: `pytest tests/test_tags.py -v`
Expected: the three `list_tags` tests PASS (plus the limit test from Task 9).

- [ ] **Step 6: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 7: Commit**

```bash
git add src/mimir_mcp/tools/tags.py src/mimir_mcp/tools/__init__.py tests/test_tags.py
git commit -m "feat(tags): add list_tags tool

Returns top-30 tags with counts by default; extended=True yields the
full list. Scope-auth gated. Intended for on-demand tag lookup
during tag creation / consolidation workflows."
```

---

### Task 12: `suggest_tag_consolidations` tool

**Files:**
- Modify: `src/mimir_mcp/tools/tags.py` (add impl + tool)
- Add: tests in `tests/test_tags.py`

- [ ] **Step 1: Write failing tests**

Add to `tests/test_tags.py`:

```python
from mimir_mcp.tools.tags import suggest_tag_consolidations_impl


def _tag_item(db, scope, summary, tags):
    db.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, 'note', 'active', ?, 'jimmy', 'jimmy')",
        (scope, summary),
    )
    db.commit()
    iid = db.fetchone("SELECT last_insert_rowid() as id")["id"]
    for t in tags:
        db.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", (t,))
        db.execute("INSERT INTO item_tags VALUES (?, ?)", (iid, t))
    db.commit()


def test_suggest_flags_substring_match(seed_data):
    # 'prompt-engineering' used 6 times (high), 'prompt' used 1 time (low)
    for i in range(6):
        _tag_item(seed_data, "jimmy", f"n{i}", ["prompt-engineering"])
    _tag_item(seed_data, "jimmy", "lone", ["prompt"])

    candidates = suggest_tag_consolidations_impl(seed_data, ["jimmy"], scope="jimmy")
    pairs = [(c["from"], c["to"], c["reason"]) for c in candidates]
    assert ("prompt", "prompt-engineering", "substring") in pairs


def test_suggest_flags_edit_distance(seed_data):
    for i in range(5):
        _tag_item(seed_data, "jimmy", f"n{i}", ["automation"])
    _tag_item(seed_data, "jimmy", "typo", ["automaton"])

    candidates = suggest_tag_consolidations_impl(seed_data, ["jimmy"], scope="jimmy")
    pairs = [(c["from"], c["to"], c["reason"]) for c in candidates]
    assert ("automaton", "automation", "edit_distance") in pairs


def test_suggest_flags_stem_variant(seed_data):
    for i in range(4):
        _tag_item(seed_data, "jimmy", f"n{i}", ["venture"])
    _tag_item(seed_data, "jimmy", "solo", ["ventures"])

    candidates = suggest_tag_consolidations_impl(seed_data, ["jimmy"], scope="jimmy")
    pairs = [(c["from"], c["to"], c["reason"]) for c in candidates]
    assert ("ventures", "venture", "stem") in pairs


def test_suggest_ignores_high_usage_pairs(seed_data):
    # Both used 5 times -> neither is low-usage, no candidate
    for i in range(5):
        _tag_item(seed_data, "jimmy", f"a{i}", ["foo"])
    for i in range(5):
        _tag_item(seed_data, "jimmy", f"b{i}", ["foos"])

    candidates = suggest_tag_consolidations_impl(seed_data, ["jimmy"], scope="jimmy")
    assert candidates == []


def test_suggest_orders_by_to_count_desc(seed_data):
    for i in range(10):
        _tag_item(seed_data, "jimmy", f"x{i}", ["big-tag"])
    for i in range(3):
        _tag_item(seed_data, "jimmy", f"y{i}", ["small-tag"])
    _tag_item(seed_data, "jimmy", "low-b", ["big"])     # -> "big-tag" via substring
    _tag_item(seed_data, "jimmy", "low-s", ["small"])   # -> "small-tag" via substring

    candidates = suggest_tag_consolidations_impl(seed_data, ["jimmy"], scope="jimmy")
    assert candidates[0]["to"] == "big-tag"  # highest to_count first
```

- [ ] **Step 2: Run tests to verify fail**

Run: `pytest tests/test_tags.py -k suggest -v`
Expected: ImportError — `suggest_tag_consolidations_impl` does not exist.

- [ ] **Step 3: Implement matching helpers + `suggest_tag_consolidations_impl`**

Append to `src/mimir_mcp/tools/tags.py`:

```python
import re

_WORD_SPLIT_RE = re.compile(r"[-_ ]")
_STEM_SUFFIXES = ("s", "es", "ing", "ed")
LOW_USAGE_THRESHOLD = 2
EDIT_DISTANCE_THRESHOLD = 2


def _edit_distance(a: str, b: str) -> int:
    """Iterative Levenshtein distance. O(len(a) * len(b))."""
    if len(a) < len(b):
        a, b = b, a
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            ins = curr[j] + 1
            dele = prev[j + 1] + 1
            sub = prev[j] + (0 if ca == cb else 1)
            curr.append(min(ins, dele, sub))
        prev = curr
    return prev[-1]


def _is_stem_variant(a: str, b: str) -> bool:
    for suf in _STEM_SUFFIXES:
        if a == b + suf or b == a + suf:
            return True
    return False


def _is_word_subset(sub: str, full: str) -> bool:
    """True if `sub` appears as a whole token in `full` (dash/space/underscore separated)."""
    return sub in _WORD_SPLIT_RE.split(full)


def _match_reason(a: str, b: str) -> str | None:
    """Return the heuristic that matches a<->b, preferring the strongest signal, else None."""
    if _edit_distance(a, b) <= EDIT_DISTANCE_THRESHOLD:
        return "edit_distance"
    if _is_stem_variant(a, b):
        return "stem"
    # Substring only in the direction where sub is in full. a could be sub or full.
    if _is_word_subset(a, b) or _is_word_subset(b, a):
        return "substring"
    return None


def suggest_tag_consolidations_impl(
    db: Database,
    scopes: list[str],
    *,
    scope: str,
) -> list[dict]:
    """Candidate tag pairs for consolidation. See spec section 6 for heuristics."""
    _require_scope_access(scope, scopes)
    tags = queries.tags_with_counts(db, scope)
    if len(tags) < 2:
        return []
    # Index for quick lookup; order stable on (count desc, name asc).
    candidates: list[dict] = []
    for low in tags:
        if low["count"] > LOW_USAGE_THRESHOLD:
            continue
        for high in tags:
            if high["name"] == low["name"]:
                continue
            if high["count"] < low["count"]:
                # Prefer more-used target. If both are low-usage, keep ordering by name.
                continue
            reason = _match_reason(low["name"], high["name"])
            if not reason:
                continue
            candidates.append(
                {
                    "from": low["name"],
                    "to": high["name"],
                    "from_count": low["count"],
                    "to_count": high["count"],
                    "reason": reason,
                }
            )
    candidates.sort(key=lambda c: (-c["to_count"], c["from_count"], c["from"]))
    return candidates
```

Then add the tool registration. Inside the existing `register(mcp)` function (add after `list_tags`):

```python
    @mcp.tool
    def suggest_tag_consolidations(
        scope: Annotated[
            str,
            Field(description="Scope to analyze for tag consolidation candidates."),
        ],
    ) -> list[dict]:
        """Return low-usage tags that look like variants of a more-used tag in the same scope. Heuristics: edit distance ≤ 2 (typo), plural/stem variants, substring/word-boundary match. Only surfaces pairs where at least one tag has count ≤ 2 — common tags are never candidates. Use the output to review with the user before merging via merge_tags."""
        return suggest_tag_consolidations_impl(get_db(), get_current_scopes(), scope=scope)
```

- [ ] **Step 4: Run tests to verify pass**

Run: `pytest tests/test_tags.py -k suggest -v`
Expected: all PASS.

- [ ] **Step 5: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/tools/tags.py tests/test_tags.py
git commit -m "feat(tags): add suggest_tag_consolidations tool

Surfaces candidate pairs via three heuristics — Levenshtein ≤ 2,
plural/stem variants, substring/word-boundary — all gated by
low-usage (count ≤ 2). Ordered by to_count desc."
```

---

### Task 13: `merge_tags` tool

**Files:**
- Modify: `src/mimir_mcp/tools/tags.py` (add impl + tool)
- Add: tests in `tests/test_tags.py`

- [ ] **Step 1: Write failing tests**

Add to `tests/test_tags.py`:

```python
from mimir_mcp.tools.tags import merge_tags_impl


def test_merge_tags_replaces_tag_across_items(seed_data):
    _tag_item(seed_data, "jimmy", "a", ["old"])
    _tag_item(seed_data, "jimmy", "b", ["old"])
    _tag_item(seed_data, "jimmy", "c", ["unrelated"])

    result = merge_tags_impl(seed_data, ["jimmy"], from_tag="old", to_tag="new", scope="jimmy")
    assert result == {"merged": 2, "from": "old", "to": "new", "scope": "jimmy"}

    # 'old' gone, 'new' in its place
    rows = seed_data.fetchall(
        "SELECT tag_id FROM item_tags ORDER BY tag_id"
    )
    ids = [r["tag_id"] for r in rows]
    assert "old" not in ids
    assert ids.count("new") == 2


def test_merge_tags_dedups_when_to_tag_already_present(seed_data):
    _tag_item(seed_data, "jimmy", "a", ["old", "new"])  # already has both

    result = merge_tags_impl(seed_data, ["jimmy"], from_tag="old", to_tag="new", scope="jimmy")
    assert result["merged"] == 1

    rows = seed_data.fetchall(
        "SELECT tag_id FROM item_tags ORDER BY tag_id"
    )
    ids = [r["tag_id"] for r in rows]
    assert ids == ["new"]


def test_merge_tags_removes_orphaned_tag_row(seed_data):
    _tag_item(seed_data, "jimmy", "a", ["old"])
    merge_tags_impl(seed_data, ["jimmy"], from_tag="old", to_tag="new", scope="jimmy")

    row = seed_data.fetchone("SELECT id FROM tags WHERE id = ?", ("old",))
    assert row is None


def test_merge_tags_keeps_tag_row_if_still_used_in_other_scope(seed_data):
    _tag_item(seed_data, "jimmy", "a", ["shared"])
    _tag_item(seed_data, "household", "b", ["shared"])

    merge_tags_impl(seed_data, ["jimmy", "household"], from_tag="shared", to_tag="alt", scope="jimmy")

    row = seed_data.fetchone("SELECT id FROM tags WHERE id = ?", ("shared",))
    assert row is not None  # still used in household


def test_merge_tags_rejects_inaccessible_scope(seed_data):
    with pytest.raises(ToolError):
        merge_tags_impl(seed_data, ["jimmy"], from_tag="x", to_tag="y", scope="household")
```

- [ ] **Step 2: Run tests to verify fail**

Run: `pytest tests/test_tags.py -k merge -v`
Expected: ImportError — `merge_tags_impl` does not exist.

- [ ] **Step 3: Implement `merge_tags_impl`**

Append to `src/mimir_mcp/tools/tags.py`:

```python
def merge_tags_impl(
    db: Database,
    scopes: list[str],
    *,
    from_tag: str,
    to_tag: str,
    scope: str,
) -> dict:
    """Replace from_tag with to_tag on every item in `scope`. Atomic.

    - If an item already has both tags, from_tag is simply removed.
    - Creates the to_tag row in `tags` if absent.
    - Deletes the from_tag row only when no items anywhere still reference it.
    """
    _require_scope_access(scope, scopes)

    rows = db.fetchall(
        "SELECT it.item_id FROM item_tags it JOIN items i ON it.item_id = i.id "
        "WHERE i.scope = ? AND it.tag_id = ?",
        (scope, from_tag),
    )
    item_ids = [r["item_id"] for r in rows]
    if not item_ids:
        return {"merged": 0, "from": from_tag, "to": to_tag, "scope": scope}

    # Ensure the target tag exists
    db.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", (to_tag,))

    placeholders = ",".join("?" for _ in item_ids)
    # Remove the from_tag rows for the affected items
    db.execute(
        f"DELETE FROM item_tags WHERE tag_id = ? AND item_id IN ({placeholders})",
        (from_tag, *item_ids),
    )
    # Add the to_tag rows (dedup via PK)
    db.executemany(
        "INSERT OR IGNORE INTO item_tags (item_id, tag_id) VALUES (?, ?)",
        [(i, to_tag) for i in item_ids],
    )

    # If no more references to from_tag anywhere, delete its tags row
    remaining = db.fetchone(
        "SELECT COUNT(*) as c FROM item_tags WHERE tag_id = ?", (from_tag,)
    )
    if remaining and remaining["c"] == 0:
        db.execute("DELETE FROM tags WHERE id = ?", (from_tag,))

    db.commit()
    return {"merged": len(item_ids), "from": from_tag, "to": to_tag, "scope": scope}
```

And register the tool inside `register(mcp)`:

```python
    @mcp.tool
    def merge_tags(
        from_tag: Annotated[
            str,
            Field(description="Tag to eliminate. Every item tagged with it in the given scope will be retagged with to_tag."),
        ],
        to_tag: Annotated[
            str,
            Field(description="Tag to keep. Created automatically if it does not yet exist."),
        ],
        scope: Annotated[
            str,
            Field(description="Scope to operate in. Must be a scope you can access. Only items in this scope are affected."),
        ],
    ) -> dict:
        """Rename every occurrence of from_tag to to_tag on items in the given scope. Atomic. Dedupes when an item already has both. Deletes the from_tag row from the tags table if no references remain anywhere. Returns {merged, from, to, scope}."""
        return merge_tags_impl(
            get_db(), get_current_scopes(), from_tag=from_tag, to_tag=to_tag, scope=scope
        )
```

- [ ] **Step 4: Run tests to verify pass**

Run: `pytest tests/test_tags.py -k merge -v`
Expected: all PASS.

- [ ] **Step 5: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/tools/tags.py tests/test_tags.py
git commit -m "feat(tags): add merge_tags tool

Atomically retags every item carrying from_tag with to_tag, in the
given scope. Dedupes, creates missing target tag, garbage-collects
orphan rows in the tags table."
```

---

### Task 14: `end_session` surfaces `tag_consolidation_candidates`

**Files:**
- Modify: `src/mimir_mcp/tools/session.py:89-133` (`end_session_impl`)
- Modify: `tests/test_session.py` (add test)

- [ ] **Step 1: Write failing test**

Add to `tests/test_session.py`:

```python
def test_end_session_surfaces_tag_consolidation_candidates(seed_data):
    """If there are tag consolidation candidates in any accessible scope,
    end_session surfaces them under 'tag_consolidation_candidates'."""
    # Create enough signal for a candidate in the 'jimmy' scope
    for i in range(6):
        seed_data.execute(
            "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
            "VALUES ('jimmy', 'note', 'active', ?, 'jimmy', 'jimmy')",
            (f"n{i}",),
        )
        seed_data.commit()
        iid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
        seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES ('prompt-engineering')")
        seed_data.execute("INSERT INTO item_tags VALUES (?, 'prompt-engineering')", (iid,))
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES ('jimmy', 'note', 'active', 'lone', 'jimmy', 'jimmy')"
    )
    seed_data.commit()
    iid = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES ('prompt')")
    seed_data.execute("INSERT INTO item_tags VALUES (?, 'prompt')", (iid,))
    seed_data.commit()

    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    result = end_session(seed_data, "jimmy")

    assert "tag_consolidation_candidates" in result
    jimmy_cands = result["tag_consolidation_candidates"].get("jimmy", [])
    pairs = [(c["from"], c["to"]) for c in jimmy_cands]
    assert ("prompt", "prompt-engineering") in pairs


def test_end_session_omits_candidates_field_when_none(seed_data):
    """No candidates -> field is absent (not present with empty dict)."""
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    result = end_session(seed_data, "jimmy")
    assert "tag_consolidation_candidates" not in result
```

- [ ] **Step 2: Run tests to verify fail**

Run: `pytest tests/test_session.py::test_end_session_surfaces_tag_consolidation_candidates tests/test_session.py::test_end_session_omits_candidates_field_when_none -v`
Expected: FAIL — field absent in both cases.

- [ ] **Step 3: Update `end_session_impl`**

In `src/mimir_mcp/tools/session.py`, modify `end_session_impl`:

```python
def end_session_impl(db: Database, user_id: str, *, learnings: list[str] | None = None) -> dict:
    """End the active session. Optionally record learnings as facts.

    When there are tag consolidation candidates in any accessible scope,
    includes them under 'tag_consolidation_candidates' keyed by scope id.
    """
    from mimir_mcp.tools.tags import suggest_tag_consolidations_impl  # late import: avoid circular dep

    session = queries.sessions_get_active(db, user_id)
    if not session:
        return {"summary": "No active session found."}

    session_id = session["id"]

    if learnings:
        for learning in learnings:
            fact_id = queries.items_insert_full(
                db, user_id, "fact", "active", learning, user_id, source="learned",
            )
            queries.history_insert(
                db, fact_id, "created",
                f"Learned: {learning}", user_id, session_id=session_id,
            )

    summary = "Session ended"
    if learnings:
        summary += f" with {len(learnings)} learning(s) recorded"

    queries.sessions_end(db, session_id, summary)
    queries.activity_advance_cursor(db, user_id)
    db.commit()

    # Collect tag consolidation candidates across every scope the user has access to.
    user_scope_rows = queries.scopes_for_user(db, user_id)
    user_scope_ids = [s["id"] for s in user_scope_rows]
    candidates: dict[str, list[dict]] = {}
    for sid in user_scope_ids:
        scope_candidates = suggest_tag_consolidations_impl(db, user_scope_ids, scope=sid)
        if scope_candidates:
            candidates[sid] = scope_candidates

    result: dict = {"summary": summary}
    if candidates:
        result["tag_consolidation_candidates"] = candidates
    return result
```

- [ ] **Step 4: Run tests to verify pass**

Run: `pytest tests/test_session.py -v`
Expected: all PASS.

- [ ] **Step 5: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/tools/session.py tests/test_session.py
git commit -m "feat(session): surface tag consolidation candidates on end_session

end_session now evaluates every accessible scope for consolidation
candidates and attaches them under tag_consolidation_candidates when
any exist. The field is omitted entirely when the result would be
empty."
```

---

### Task 15: Update Pydantic output models

**Files:**
- Modify: `src/mimir_mcp/models.py` (update `SessionBootResponse`, `ItemSummary`; add tag-related models)

This is cleanup: the shape changes above return plain dicts, but the Pydantic models should still reflect the current contract for anyone generating schemas or typing call sites.

- [ ] **Step 1: Apply the model edits**

In `src/mimir_mcp/models.py`:

1. Remove `tags: list[str] = []` from `ItemSummary` (kept for `ItemDetail`, which still has tags).
2. Make `scope` optional on `ItemSummary` (already changed in Task 4 — verify).
3. Ensure `SessionBootResponse.stale_sessions` is removed (verify — changed in Task 1).
4. Change `SessionBootResponse.facts: list[dict]` docstring/type note to indicate the slim `{id, summary}` shape.
5. Add new models:

```python
class TagWithCount(BaseModel):
    name: str
    count: int


class TagConsolidationCandidate(BaseModel):
    from_tag: str = Field(alias="from")
    to_tag: str = Field(alias="to")
    from_count: int
    to_count: int
    reason: str  # "edit_distance" | "stem" | "substring"

    model_config = {"populate_by_name": True}


class MergeTagsResult(BaseModel):
    merged: int
    from_tag: str = Field(alias="from")
    to_tag: str = Field(alias="to")
    scope: str

    model_config = {"populate_by_name": True}
```

- [ ] **Step 2: Run full suite**

Run: `pytest`
Expected: all PASS. (Models aren't validated at the tool return site today, so this is non-functional housekeeping — but the imports must stay valid.)

- [ ] **Step 3: Commit**

```bash
git add src/mimir_mcp/models.py
git commit -m "refactor(models): align output models with new response shapes

Drops 'tags' from ItemSummary slim shape. Adds TagWithCount,
TagConsolidationCandidate, MergeTagsResult. Aliasing 'from'/'to' for
Pydantic-reserved-keyword compatibility."
```

---

### Task 16: Update server instructions and tool docstrings

**Files:**
- Modify: `src/mimir_mcp/server.py:88-127` (the `instructions=` string)
- Modify: tool docstrings in `src/mimir_mcp/tools/context.py`, `src/mimir_mcp/tools/session.py`, `src/mimir_mcp/tools/tags.py`

- [ ] **Step 1: Rewrite the server instructions block**

Replace the `instructions=` argument in `create_server()` of `src/mimir_mcp/server.py` with:

```python
        instructions=(
            "Mimir is a structured memory server for AI assistants. All data is "
            "scoped to the authenticated user.\n\n"
            "Items are the core unit of memory. Each item has a type (task, project, "
            "fact, reminder, note, idea), belongs to a scope, and has a summary "
            "(short headline) and optional detail (extended description). Items can "
            "form trees: projects, tasks, and ideas can have children; facts, notes, "
            "and reminders cannot (facts may have a parent — see below).\n\n"
            "Scopes are access groups. Each user has a personal scope plus any "
            "shared scopes (e.g., 'household'). You only see items in scopes you "
            "belong to.\n\n"
            "View states:\n"
            "- start_session() / refresh_context() — BOOT: projects/tasks/ideas "
            "(slim), upcoming reminders, TOP-LEVEL facts only (parent_id IS NULL), "
            "top-30 tags_in_use, shared activity. Call start_session once at the "
            "beginning of every conversation; after context compaction, call "
            "refresh_context — NOT start_session (that would create a new session).\n"
            "- set_context(item_id) — DRILL-IN: returns {item, children, item_facts} "
            "for the focused item. Stateless — additive to what you already have from "
            "boot. Does not include scopes, tags_in_use, or shared activity (those "
            "are still in your context from boot).\n"
            "- refresh_context(item_id) — REBUILD: boot payload + focused slice. Use "
            "when your context is compacted AND you need to resume with focus on a "
            "specific item.\n\n"
            "Fact parenting convention:\n"
            "- Facts that apply globally (user profile, cross-cutting principles) "
            "have NO parent (parent_id is omitted/null). They load at boot.\n"
            "- Facts specific to a project/task/idea MUST have that item as their "
            "parent. They load only when the parent is focused (in item_facts).\n"
            "This keeps the boot payload focused on always-relevant context.\n\n"
            "Item shape: boot/refresh responses return slim summaries (optional "
            "fields omitted when empty/zero). Top-level projects/tasks/ideas omit "
            "the `scope` field when it equals your personal scope. Children in "
            "focused views contain only {id, summary, due_date?}. Facts at every "
            "tier return {id, summary} — use get_details([id]) for tags, source, "
            "and full detail.\n\n"
            "Tags:\n"
            "- tags_in_use in the boot/refresh response is capped at 30 per scope "
            "(by usage count). For the full list, call list_tags(scope, extended=True).\n"
            "- When about to create a tagging burst, call list_tags(scope) once; "
            "reuse the result in-context across subsequent add_items calls.\n"
            "- suggest_tag_consolidations(scope) surfaces candidate tag pairs for "
            "merging (typos, plurals, substrings). end_session automatically includes "
            "any candidates in its response.\n"
            "- merge_tags(from_tag, to_tag, scope) atomically renames the tag across "
            "items. Use after reviewing suggestions with the user.\n\n"
            "Session lifecycle:\n"
            "- Call start_session once at conversation start.\n"
            "- Call save_session periodically to checkpoint your position in shared "
            "activity.\n"
            "- Call end_session at conversation end. Pass new facts learned as "
            "learnings. If the response contains tag_consolidation_candidates, "
            "review them with the user before finalizing.\n\n"
            "Finding items:\n"
            "- search_items: keyword search with stemming.\n"
            "- list_items: filtered browse by type, status, scope, parent.\n"
            "- get_facts: retrieve facts by tag or parent item.\n"
            "- list_tags: retrieve tags used in a scope (top 30 by default).\n"
        ),
```

- [ ] **Step 2: Update tool docstrings**

- `start_session` docstring in `src/mimir_mcp/tools/session.py` — remove mention of stale-session auto-close and `stale_sessions` field.
- `set_context` docstring in `src/mimir_mcp/tools/context.py` — rewrite to match the new stateless semantics (no server-side focus; focused slice only; no tags_in_use; returns `{item, children, item_facts}`).
- `refresh_context` docstring — add the rebuild-with-focus note (boot payload + focused slice).
- `end_session` docstring — mention `tag_consolidation_candidates` surfacing.

Proposed new docstrings:

```python
# start_session
"""Start a new session and return your full current state: projects, tasks, ideas,
top-level facts (parent_id IS NULL), upcoming reminders, recent shared activity,
and the top 30 tags per scope. Call once at the beginning of every conversation.
If your context is compacted mid-conversation, call refresh_context instead —
calling start_session again creates a new session."""

# set_context
"""Return a focused slice: {item, children, item_facts} where item_facts are only
facts with parent_id = item_id. Stateless — does not persist focus on the server.
Does not include scopes, tags_in_use, or shared_activity (those are already in
your context from boot). Use this to drill into a specific item without a full
context rebuild. For a rebuild that includes both boot + focus, use
refresh_context(item_id) instead."""

# refresh_context
"""Reload your current state view. With no arguments, returns the top-level boot
summary. With item_id, returns the boot payload PLUS {item, children, item_facts}
for the focused item — a complete post-compaction rebuild. On success, includes
scopes, session_activity, recent_shared_activity, and top-30 tags_in_use. Unlike
start_session, does not create a new session."""

# end_session
"""End the current session. Pass learnings to save new facts that should persist
across sessions. Marks all shared activity as seen and closes the session. If
there are tag consolidation candidates in any accessible scope, they are included
under 'tag_consolidation_candidates' — review with the user and invoke merge_tags
to apply approved merges."""
```

- [ ] **Step 3: Run full suite**

Run: `pytest`
Expected: all PASS.

- [ ] **Step 4: Commit**

```bash
git add src/mimir_mcp/server.py src/mimir_mcp/tools/session.py src/mimir_mcp/tools/context.py src/mimir_mcp/tools/tags.py
git commit -m "docs(mcp): update instructions and tool docstrings for v0.8.0

Documents the new view states, fact-parenting convention, top-30 tag
limit, on-demand list_tags, tag consolidation flow, and the new
stateless set_context semantics."
```

---

### Task 17: Bump version & final sanity

**Files:**
- Modify: `pyproject.toml` (version bump)
- Optional: `MIMIR_API_VERSION` in `src/mimir_mcp/server.py` (bump only if you deem the response-shape changes break v1 clients — otherwise keep `"1"`)

- [ ] **Step 1: Bump the package version**

In `pyproject.toml`, change `version = "0.7.0"` to `version = "0.8.0"`.

- [ ] **Step 2: Evaluate API version**

Response shape changes are non-additive (fields removed). If downstream clients pin behavior, bump `MIMIR_API_VERSION` from `"1"` to `"2"`. If not, keep `"1"`. Recommendation: **keep `"1"`** for now — the only consumer is Hermes, which is being updated alongside. Note the decision in the commit message.

- [ ] **Step 3: Run the full suite one more time**

Run: `pytest -v`
Expected: all PASS.

- [ ] **Step 4: Manual sanity check (optional but recommended)**

Run the server locally and hit:
```
curl -s http://localhost:8100/version
```
Expected: `{"version":"0.8.0","api_version":"1"}`.

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml
git commit -m "chore(release): bump version to 0.8.0

Context trimming (no top-level tags on items; scope-when-shared only;
top-level facts only at boot; children minimal; top-30 tags_in_use),
parent-based fact model (global vs item-scoped), new tag tools
(list_tags, suggest_tag_consolidations, merge_tags), end_session
surfaces consolidation candidates, set_context is stateless."
```

---

## Post-implementation follow-ups (not part of this plan)

These belong in separate tickets after the branch lands:

1. **Data reparenting** — existing project-specific facts (e.g., the nine `ai-powered-legal-intelligence` MVP-decision facts) need their `parent_id` set. Handled via conversation + `update_item`, not in this PR.
2. **Hermes `CLAUDE.md` update** — in the `~/hermes` repo, document the fact-parenting convention and the `tag_consolidation_candidates` surfacing in the `/end` flow.
3. **Multi-terminal sessions spec** — address the orphan-session accumulation and cursor/focus cross-contamination documented in the spec's "Known issues" section.
