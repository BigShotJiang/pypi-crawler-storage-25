# Changelog

## 0.46.0 (2026-04-09)

Full Changelog: [v0.45.1...v0.46.0](https://github.com/bountylaboratories/python-sdk/compare/v0.45.1...v0.46.0)

### Features

* **api:** api update ([7bbce89](https://github.com/bountylaboratories/python-sdk/commit/7bbce89494e8e3c6735fd489739b7e3d615eef80))

## 0.45.1 (2026-04-08)

Full Changelog: [v0.45.0...v0.45.1](https://github.com/bountylaboratories/python-sdk/compare/v0.45.0...v0.45.1)

### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([e82ad5f](https://github.com/bountylaboratories/python-sdk/commit/e82ad5ffbac4fdeb667db43318ca0214eb654bf9))

## 0.45.0 (2026-03-30)

Full Changelog: [v0.44.0...v0.45.0](https://github.com/bountylaboratories/python-sdk/compare/v0.44.0...v0.45.0)

### Features

* **api:** api update ([e766d86](https://github.com/bountylaboratories/python-sdk/commit/e766d86d9cf9062a72efc4f883009aada3deff19))

## 0.44.0 (2026-03-27)

Full Changelog: [v0.43.3...v0.44.0](https://github.com/bountylaboratories/python-sdk/compare/v0.43.3...v0.44.0)

### Features

* **internal:** implement indices array format for query and form serialization ([5efb9f9](https://github.com/bountylaboratories/python-sdk/commit/5efb9f9069b9d198ee91b176945e8a49be5b1b1f))


### Chores

* **ci:** skip lint on metadata-only changes ([76506d2](https://github.com/bountylaboratories/python-sdk/commit/76506d2cab55dfa4ffbadfc327cc51fa876d9c30))
* **internal:** update gitignore ([b904eba](https://github.com/bountylaboratories/python-sdk/commit/b904eba95998c636183ab971b81ca5c4caa2f066))

## 0.43.3 (2026-03-20)

Full Changelog: [v0.43.2...v0.43.3](https://github.com/bountylaboratories/python-sdk/compare/v0.43.2...v0.43.3)

### Bug Fixes

* sanitize endpoint path params ([e16bf7c](https://github.com/bountylaboratories/python-sdk/commit/e16bf7c0b277ec550c8a6539cfa8e40e556b3f64))


### Chores

* **internal:** tweak CI branches ([789ca7c](https://github.com/bountylaboratories/python-sdk/commit/789ca7c1bf35024c9938bf49107b2ab25e8526cf))

## 0.43.2 (2026-03-17)

Full Changelog: [v0.43.1...v0.43.2](https://github.com/bountylaboratories/python-sdk/compare/v0.43.1...v0.43.2)

### Bug Fixes

* **deps:** bump minimum typing-extensions version ([11998a0](https://github.com/bountylaboratories/python-sdk/commit/11998a013d07f636daba7d740ae8ee5c16ae954e))

## 0.43.1 (2026-03-17)

Full Changelog: [v0.43.0...v0.43.1](https://github.com/bountylaboratories/python-sdk/compare/v0.43.0...v0.43.1)

### Bug Fixes

* **pydantic:** do not pass `by_alias` unless set ([5d9a0cf](https://github.com/bountylaboratories/python-sdk/commit/5d9a0cfa77f870b9f92410313602a8d18da4b798))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([6e1edd2](https://github.com/bountylaboratories/python-sdk/commit/6e1edd266be68b52d4afc35dd52122ed924b0e1c))

## 0.43.0 (2026-03-05)

Full Changelog: [v0.42.0...v0.43.0](https://github.com/bountylaboratories/python-sdk/compare/v0.42.0...v0.43.0)

### Features

* **api:** api update ([3fb5a72](https://github.com/bountylaboratories/python-sdk/commit/3fb5a724b4395205da5d3f42d66099abd64ecee9))

## 0.42.0 (2026-02-26)

Full Changelog: [v0.41.0...v0.42.0](https://github.com/bountylaboratories/python-sdk/compare/v0.41.0...v0.42.0)

### Features

* **api:** api update ([17d06c9](https://github.com/bountylaboratories/python-sdk/commit/17d06c906e2456ed9b7fc6e5134f1e4e50b40f94))


### Chores

* **internal:** make `test_proxy_environment_variables` more resilient to env ([5d60ed0](https://github.com/bountylaboratories/python-sdk/commit/5d60ed01060ab67647fd9315a07fc0eda0fd7640))

## 0.41.0 (2026-02-25)

Full Changelog: [v0.40.0...v0.41.0](https://github.com/bountylaboratories/python-sdk/compare/v0.40.0...v0.41.0)

### Features

* **api:** api update ([b24d4d6](https://github.com/bountylaboratories/python-sdk/commit/b24d4d622a29225a330be9089d095edcff41ed72))

## 0.40.0 (2026-02-24)

Full Changelog: [v0.39.0...v0.40.0](https://github.com/bountylaboratories/python-sdk/compare/v0.39.0...v0.40.0)

### Features

* **api:** api update ([a445d61](https://github.com/bountylaboratories/python-sdk/commit/a445d616756dfb47e421005dad0b31f3b15e2f61))

## 0.39.0 (2026-02-24)

Full Changelog: [v0.38.0...v0.39.0](https://github.com/bountylaboratories/python-sdk/compare/v0.38.0...v0.39.0)

### Features

* **api:** api update ([67d13a1](https://github.com/bountylaboratories/python-sdk/commit/67d13a1883b339c619b5f82aa2b1eff200cdb94a))


### Chores

* format all `api.md` files ([e8f0b63](https://github.com/bountylaboratories/python-sdk/commit/e8f0b63661d90fc9dbe36fb1e5eb21937283cd1e))
* **internal:** add request options to SSE classes ([86045f7](https://github.com/bountylaboratories/python-sdk/commit/86045f7cfe01db0ef6af5783c28599a11cc39d33))
* **internal:** bump dependencies ([8d866e9](https://github.com/bountylaboratories/python-sdk/commit/8d866e924bcfc8d15472dafb8878d6ba1d33306e))
* **internal:** fix lint error on Python 3.14 ([9cfe445](https://github.com/bountylaboratories/python-sdk/commit/9cfe445476acdf9d80bbcb561780ac479155d5e9))
* **internal:** make `test_proxy_environment_variables` more resilient ([046e68d](https://github.com/bountylaboratories/python-sdk/commit/046e68d5d8a7a5bea245710d1cca9f34065a25b6))
* **internal:** remove mock server code ([cff7202](https://github.com/bountylaboratories/python-sdk/commit/cff7202a8c0795ec77ccf62ce1ad8f267cf4d9e0))
* update mock server docs ([e7817e8](https://github.com/bountylaboratories/python-sdk/commit/e7817e888a4020c8c5d9e569ee9729bce74ee150))

## 0.38.0 (2026-02-10)

Full Changelog: [v0.37.0...v0.38.0](https://github.com/bountylaboratories/python-sdk/compare/v0.37.0...v0.38.0)

### Features

* **api:** api update ([7cccff5](https://github.com/bountylaboratories/python-sdk/commit/7cccff58eddce49486c17940bdbedaef16f7b155))
* **api:** api update ([68d821c](https://github.com/bountylaboratories/python-sdk/commit/68d821c5defe74314ab75dda1607332145389154))

## 0.37.0 (2026-02-08)

Full Changelog: [v0.36.0...v0.37.0](https://github.com/bountylaboratories/python-sdk/compare/v0.36.0...v0.37.0)

### Features

* **api:** api update ([79b4a16](https://github.com/bountylaboratories/python-sdk/commit/79b4a16cfaf985598782d699787840a58beab64d))

## 0.36.0 (2026-02-04)

Full Changelog: [v0.35.0...v0.36.0](https://github.com/bountylaboratories/python-sdk/compare/v0.35.0...v0.36.0)

### Features

* **api:** api update ([a77d1c6](https://github.com/bountylaboratories/python-sdk/commit/a77d1c60c0387455985331dc2bdf6d20076aff88))

## 0.35.0 (2026-01-30)

Full Changelog: [v0.34.0...v0.35.0](https://github.com/bountylaboratories/python-sdk/compare/v0.34.0...v0.35.0)

### Features

* **client:** add custom JSON encoder for extended type support ([187e8a7](https://github.com/bountylaboratories/python-sdk/commit/187e8a7b82377f04f2923cd847025cd1696a4b74))

## 0.34.0 (2026-01-27)

Full Changelog: [v0.33.0...v0.34.0](https://github.com/bountylaboratories/python-sdk/compare/v0.33.0...v0.34.0)

### Features

* **api:** api update ([cb0a736](https://github.com/bountylaboratories/python-sdk/commit/cb0a7368be82d0ffdf7dda4dc2fd01613d21dbc7))


### Chores

* **ci:** upgrade `actions/github-script` ([7be00fe](https://github.com/bountylaboratories/python-sdk/commit/7be00feecca4de09c7197983a2726f7b6d0da089))

## 0.33.0 (2026-01-23)

Full Changelog: [v0.32.0...v0.33.0](https://github.com/bountylaboratories/python-sdk/compare/v0.32.0...v0.33.0)

### Features

* **api:** api update ([fdd01af](https://github.com/bountylaboratories/python-sdk/commit/fdd01afafc1730198d5b08dd62a8604af5ac0d01))

## 0.32.0 (2026-01-23)

Full Changelog: [v0.31.0...v0.32.0](https://github.com/bountylaboratories/python-sdk/compare/v0.31.0...v0.32.0)

### Features

* **api:** api update ([5197788](https://github.com/bountylaboratories/python-sdk/commit/5197788593c186de50aa67f2bba4e6c56d290f81))

## 0.31.0 (2026-01-23)

Full Changelog: [v0.30.0...v0.31.0](https://github.com/bountylaboratories/python-sdk/compare/v0.30.0...v0.31.0)

### Features

* **api:** api update ([a7bfcf2](https://github.com/bountylaboratories/python-sdk/commit/a7bfcf2504b8a52ee764c5c9918863755f247b08))
* **api:** api update ([7379652](https://github.com/bountylaboratories/python-sdk/commit/7379652a7f712d5c6f83399269261543b7fbdcb2))
* **api:** api update ([7e8fff8](https://github.com/bountylaboratories/python-sdk/commit/7e8fff8b720e1d4192968ab8293ae146927e2c45))
* **api:** api update ([a509315](https://github.com/bountylaboratories/python-sdk/commit/a509315fa89211e93d8cb524638de9948ce47acd))
* **api:** api update ([a69b882](https://github.com/bountylaboratories/python-sdk/commit/a69b8826f953d1a64c9659295ae5d09ba1621d9f))
* **api:** manual updates ([97601d1](https://github.com/bountylaboratories/python-sdk/commit/97601d1da162c29c78222cf56c6b7d3eda56110b))

## 0.30.0 (2026-01-22)

Full Changelog: [v0.29.0...v0.30.0](https://github.com/bountylaboratories/python-sdk/compare/v0.29.0...v0.30.0)

### Features

* **api:** api update ([7484c04](https://github.com/bountylaboratories/python-sdk/commit/7484c04c2392eb3944d609ab7c5dfcc639d3d916))


### Chores

* **internal:** update `actions/checkout` version ([9e28fea](https://github.com/bountylaboratories/python-sdk/commit/9e28fea2120968c0e34236b81496b9f2c0bc3f5f))

## 0.29.0 (2026-01-14)

Full Changelog: [v0.28.3...v0.29.0](https://github.com/bountylaboratories/python-sdk/compare/v0.28.3...v0.29.0)

### Features

* **client:** add support for binary request streaming ([ead3700](https://github.com/bountylaboratories/python-sdk/commit/ead37001cf1f3bd2b0c8e0e1913f8d01e45b1f7a))


### Chores

* **internal:** add `--fix` argument to lint script ([c8a578e](https://github.com/bountylaboratories/python-sdk/commit/c8a578e79f967e928bb7b78c71d6c08f900f10f6))
* **internal:** codegen related update ([8880551](https://github.com/bountylaboratories/python-sdk/commit/88805518155476346cddd82d098c3834836d4cd7))

## 0.28.3 (2025-12-18)

Full Changelog: [v0.28.2...v0.28.3](https://github.com/bountylaboratories/python-sdk/compare/v0.28.2...v0.28.3)

### Bug Fixes

* use async_to_httpx_files in patch method ([5e9911f](https://github.com/bountylaboratories/python-sdk/commit/5e9911f01a0d71aea5382863b7cd029670772632))


### Chores

* **internal:** add missing files argument to base client ([fa3c563](https://github.com/bountylaboratories/python-sdk/commit/fa3c56309612f1ccd656998e15cc42e642175f7d))
* speedup initial import ([ba64b61](https://github.com/bountylaboratories/python-sdk/commit/ba64b610a617530709341fc57db7a2bde3782c93))

## 0.28.2 (2025-12-09)

Full Changelog: [v0.28.1...v0.28.2](https://github.com/bountylaboratories/python-sdk/compare/v0.28.1...v0.28.2)

### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([943b87d](https://github.com/bountylaboratories/python-sdk/commit/943b87d8a61698c79d2f8cdd1595b38762828d5e))


### Chores

* add missing docstrings ([0bc8b68](https://github.com/bountylaboratories/python-sdk/commit/0bc8b6837e9d2819975bd19c1228a1cfef947620))
* **docs:** use environment variables for authentication in code snippets ([d3756e2](https://github.com/bountylaboratories/python-sdk/commit/d3756e2169b955aa35e308ea13d3ede5e1f5c107))
* update lockfile ([f974296](https://github.com/bountylaboratories/python-sdk/commit/f97429613559893eccbe4c2308d476ec598d95f2))

## 0.28.1 (2025-11-28)

Full Changelog: [v0.28.0...v0.28.1](https://github.com/bountylaboratories/python-sdk/compare/v0.28.0...v0.28.1)

### Bug Fixes

* ensure streams are always closed ([69acb0f](https://github.com/bountylaboratories/python-sdk/commit/69acb0f98828be3e0f92ef5dfc3bfd8386ba7d09))


### Chores

* add Python 3.14 classifier and testing ([447c5e9](https://github.com/bountylaboratories/python-sdk/commit/447c5e998da0d61cde856874190d02a4a22b467e))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([04221aa](https://github.com/bountylaboratories/python-sdk/commit/04221aab9aee5e83a42a18a99297b220d93e8c13))

## 0.28.0 (2025-11-20)

Full Changelog: [v0.27.0...v0.28.0](https://github.com/bountylaboratories/python-sdk/compare/v0.27.0...v0.28.0)

### Features

* **api:** api update ([5033eef](https://github.com/bountylaboratories/python-sdk/commit/5033eefdb0a671a045185308324a1f8a89d6af76))

## 0.27.0 (2025-11-18)

Full Changelog: [v0.26.0...v0.27.0](https://github.com/bountylaboratories/python-sdk/compare/v0.26.0...v0.27.0)

### Features

* **api:** api update ([fdbd488](https://github.com/bountylaboratories/python-sdk/commit/fdbd488b988e9e2c620146f37e50ae66ae2df3a8))

## 0.26.0 (2025-11-18)

Full Changelog: [v0.25.0...v0.26.0](https://github.com/bountylaboratories/python-sdk/compare/v0.25.0...v0.26.0)

### Features

* **api:** api update ([110969e](https://github.com/bountylaboratories/python-sdk/commit/110969ebdc07c27313790bf139b71946d11fbcbe))

## 0.25.0 (2025-11-17)

Full Changelog: [v0.24.0...v0.25.0](https://github.com/bountylaboratories/python-sdk/compare/v0.24.0...v0.25.0)

### Features

* **api:** api update ([3f82696](https://github.com/bountylaboratories/python-sdk/commit/3f8269656b0b0d9c41670e557bee7b664fa30b7f))

## 0.24.0 (2025-11-17)

Full Changelog: [v0.23.0...v0.24.0](https://github.com/bountylaboratories/python-sdk/compare/v0.23.0...v0.24.0)

### Features

* **api:** api update ([b403572](https://github.com/bountylaboratories/python-sdk/commit/b403572680c4b965c485aab6a7d4e8b6894768d7))

## 0.23.0 (2025-11-13)

Full Changelog: [v0.22.0...v0.23.0](https://github.com/bountylaboratories/python-sdk/compare/v0.22.0...v0.23.0)

### Features

* **api:** api update ([60049f9](https://github.com/bountylaboratories/python-sdk/commit/60049f985060cd66779bc9f16245f706a58481f6))
* **api:** manual updates ([568c1d5](https://github.com/bountylaboratories/python-sdk/commit/568c1d57f5ababe5ed1dd3e17c40266269aa73da))

## 0.22.0 (2025-11-13)

Full Changelog: [v0.21.0...v0.22.0](https://github.com/bountylaboratories/python-sdk/compare/v0.21.0...v0.22.0)

### Features

* **api:** api update ([bc69e78](https://github.com/bountylaboratories/python-sdk/commit/bc69e78dc18bbc3b45f99dc576abfb44ce85ce1a))

## 0.21.0 (2025-11-13)

Full Changelog: [v0.20.0...v0.21.0](https://github.com/bountylaboratories/python-sdk/compare/v0.20.0...v0.21.0)

### Features

* **api:** api update ([e50eadb](https://github.com/bountylaboratories/python-sdk/commit/e50eadb5c5e29b0809d6a2ad64889c4125a029b8))

## 0.20.0 (2025-11-13)

Full Changelog: [v0.19.3...v0.20.0](https://github.com/bountylaboratories/python-sdk/compare/v0.19.3...v0.20.0)

### Features

* **api:** api update ([cbffe22](https://github.com/bountylaboratories/python-sdk/commit/cbffe227de37b7687a9c3583d0a8810bfd04918e))

## 0.19.3 (2025-11-12)

Full Changelog: [v0.19.2...v0.19.3](https://github.com/bountylaboratories/python-sdk/compare/v0.19.2...v0.19.3)

### Bug Fixes

* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([ad6efe9](https://github.com/bountylaboratories/python-sdk/commit/ad6efe9d734865cc85a9bbc7111de882c2c2a53f))

## 0.19.2 (2025-11-11)

Full Changelog: [v0.19.1...v0.19.2](https://github.com/bountylaboratories/python-sdk/compare/v0.19.1...v0.19.2)

### Bug Fixes

* compat with Python 3.14 ([2f58841](https://github.com/bountylaboratories/python-sdk/commit/2f58841684e1a0d285f75be79654d386bd31b932))


### Chores

* **internal/tests:** avoid race condition with implicit client cleanup ([25fd2c5](https://github.com/bountylaboratories/python-sdk/commit/25fd2c5cc223161f3d997d7f8a7945173764e89d))
* **internal:** grammar fix (it's -&gt; its) ([609c7b5](https://github.com/bountylaboratories/python-sdk/commit/609c7b5d17cb65576a6a4cc8cfe8cfd643c6b0a7))
* **package:** drop Python 3.8 support ([41b673b](https://github.com/bountylaboratories/python-sdk/commit/41b673b92f26c70d46f92b7051cc21208091063c))

## 0.19.1 (2025-10-30)

Full Changelog: [v0.19.0...v0.19.1](https://github.com/bountylaboratories/python-sdk/compare/v0.19.0...v0.19.1)

### Bug Fixes

* **client:** close streams without requiring full consumption ([8374710](https://github.com/bountylaboratories/python-sdk/commit/8374710ecb87b4fdddc5de1b14ac4f6a490b66ae))

## 0.19.0 (2025-10-19)

Full Changelog: [v0.18.0...v0.19.0](https://github.com/bountylaboratories/python-sdk/compare/v0.18.0...v0.19.0)

### Features

* **api:** api update ([03e95c5](https://github.com/bountylaboratories/python-sdk/commit/03e95c5b7040ab99b9a054466a06ec4afdfb8ca9))

## 0.18.0 (2025-10-19)

Full Changelog: [v0.17.0...v0.18.0](https://github.com/bountylaboratories/python-sdk/compare/v0.17.0...v0.18.0)

### Features

* **api:** api update ([65c64cd](https://github.com/bountylaboratories/python-sdk/commit/65c64cd370967e4ab25dfdf1f70dd36e79b51c78))

## 0.17.0 (2025-10-19)

Full Changelog: [v0.16.0...v0.17.0](https://github.com/bountylaboratories/python-sdk/compare/v0.16.0...v0.17.0)

### Features

* **api:** api update ([081c6f7](https://github.com/bountylaboratories/python-sdk/commit/081c6f7cf07220b998469d13788aa2846ec43f49))

## 0.16.0 (2025-10-18)

Full Changelog: [v0.15.0...v0.16.0](https://github.com/bountylaboratories/python-sdk/compare/v0.15.0...v0.16.0)

### Features

* **api:** api update ([1355985](https://github.com/bountylaboratories/python-sdk/commit/1355985eac8eba966107db45bec7094cec419821))
* **api:** manual updates ([05a3930](https://github.com/bountylaboratories/python-sdk/commit/05a3930dd168a123f4024d28d85d30bfc14896e3))

## 0.15.0 (2025-10-18)

Full Changelog: [v0.14.0...v0.15.0](https://github.com/bountylaboratories/python-sdk/compare/v0.14.0...v0.15.0)

### Features

* **api:** api update ([7b361a1](https://github.com/bountylaboratories/python-sdk/commit/7b361a1628661174a50364f49dff39a94fa363ab))
* **api:** manual updates ([7c8617d](https://github.com/bountylaboratories/python-sdk/commit/7c8617d2a1a91a0aa25937f0142f1ce217bc4cde))

## 0.14.0 (2025-10-18)

Full Changelog: [v0.13.0...v0.14.0](https://github.com/bountylaboratories/python-sdk/compare/v0.13.0...v0.14.0)

### Features

* **api:** api update ([cd1ec48](https://github.com/bountylaboratories/python-sdk/commit/cd1ec4862cfe4df78a02d0b7f52f65e1d5442b9c))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([27fa027](https://github.com/bountylaboratories/python-sdk/commit/27fa0279d88e2d889817bf48d22242d9c1b71cc3))

## 0.13.0 (2025-10-18)

Full Changelog: [v0.12.0...v0.13.0](https://github.com/bountylaboratories/python-sdk/compare/v0.12.0...v0.13.0)

### Features

* **api:** api update ([afda67c](https://github.com/bountylaboratories/python-sdk/commit/afda67cded83c3e3b58765369a0a475a6cb971d5))

## 0.12.0 (2025-10-16)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/bountylaboratories/python-sdk/compare/v0.11.0...v0.12.0)

### Features

* **api:** manual updates ([3019800](https://github.com/bountylaboratories/python-sdk/commit/3019800386280afbed246288f392ab2d9c1294fa))

## 0.11.0 (2025-10-16)

Full Changelog: [v0.10.0...v0.11.0](https://github.com/bountylaboratories/python-sdk/compare/v0.10.0...v0.11.0)

### Features

* **api:** api update ([5cd04c5](https://github.com/bountylaboratories/python-sdk/commit/5cd04c55b8221274f5d885c1159b4198df0d3500))
* **api:** manual updates ([3718c10](https://github.com/bountylaboratories/python-sdk/commit/3718c10cf65a6de521ee5f7484bd512c9b235c19))

## 0.10.0 (2025-10-14)

Full Changelog: [v0.9.0...v0.10.0](https://github.com/bountylaboratories/python-sdk/compare/v0.9.0...v0.10.0)

### Features

* **api:** api update ([a775f12](https://github.com/bountylaboratories/python-sdk/commit/a775f1298b6d9bf2bbd1fdf34cdcebc2c9d3ec9c))

## 0.9.0 (2025-10-13)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/bountylaboratories/python-sdk/compare/v0.8.0...v0.9.0)

### Features

* **api:** api update ([fbb1b21](https://github.com/bountylaboratories/python-sdk/commit/fbb1b21b4ad12a15bb637ac7faa9af1dbed05206))

## 0.8.0 (2025-10-13)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/bountylaboratories/python-sdk/compare/v0.7.0...v0.8.0)

### Features

* **api:** api update ([3bb9e81](https://github.com/bountylaboratories/python-sdk/commit/3bb9e8141a4ed72fbb257969c25330a1afb4999a))

## 0.7.0 (2025-10-13)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/bountylaboratories/python-sdk/compare/v0.6.0...v0.7.0)

### Features

* **api:** api update ([a6b3fc5](https://github.com/bountylaboratories/python-sdk/commit/a6b3fc5e26176da800c1a2083c1229da1da9465d))

## 0.6.0 (2025-10-13)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/bountylaboratories/python-sdk/compare/v0.5.0...v0.6.0)

### Features

* **api:** api update ([f6869ec](https://github.com/bountylaboratories/python-sdk/commit/f6869ec87246466482d395e4155734b9ea5fae89))


### Chores

* **internal:** detect missing future annotations with ruff ([319408e](https://github.com/bountylaboratories/python-sdk/commit/319408ed5a2ec94d5e2565bc56db5880360596be))

## 0.5.0 (2025-10-10)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/bountylaboratories/python-sdk/compare/v0.4.0...v0.5.0)

### Features

* **api:** api update ([9e71658](https://github.com/bountylaboratories/python-sdk/commit/9e71658b0133c59a8c2f53e9b4906f45d05de260))

## 0.4.0 (2025-10-08)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/bountylaboratories/python-sdk/compare/v0.3.0...v0.4.0)

### Features

* **api:** api update ([cffef9a](https://github.com/bountylaboratories/python-sdk/commit/cffef9ac2ae64cd8b52f43cf5f1d90cb825d0cd9))

## 0.3.0 (2025-10-06)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/bountylaboratories/python-sdk/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([9a05d55](https://github.com/bountylaboratories/python-sdk/commit/9a05d557e23acc60050b1037a8d7f5039b04b81e))

## 0.2.0 (2025-10-06)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/bountylaboratories/python-sdk/compare/v0.1.0...v0.2.0)

### Features

* **api:** manual updates ([54e1936](https://github.com/bountylaboratories/python-sdk/commit/54e1936ca1c135442b88e90134c35e8ccb4f061f))

## 0.1.0 (2025-10-06)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/bountylaboratories/python-sdk/compare/v0.0.2...v0.1.0)

### Features

* **api:** api update ([aed9894](https://github.com/bountylaboratories/python-sdk/commit/aed9894ce044d7d362494ab5271a2361a1d5d3a9))

## 0.0.2 (2025-10-04)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/bountylaboratories/python-sdk/compare/v0.0.1...v0.0.2)

### Chores

* configure new SDK language ([d4e6d6d](https://github.com/bountylaboratories/python-sdk/commit/d4e6d6d7a89f1706c81db5cf7013c01c14cd4e3e))
* update SDK settings ([b1baa49](https://github.com/bountylaboratories/python-sdk/commit/b1baa49ab531f863abd53d4ea0be0a9883f36894))
* update SDK settings ([9fc9b5b](https://github.com/bountylaboratories/python-sdk/commit/9fc9b5b30db13a0b3eedafd4e321f42c632758ec))
