# ============================================================================
# DEEPREAD - BIBLIOTECA DE EXTRAÇÃO INTELIGENTE DE DOCUMENTOS
# ============================================================================
"""
DeepRead - Biblioteca para extração e classificação inteligente de documentos PDF.

Uso básico:
    from deepread import DeepRead

    # Inicializar com token de autenticação
    dr = DeepRead(api_token="seu_token_aqui")

    # Processar documento
    resultado = dr.process("documento.pdf")
"""

__version__ = "2.6.1"
__author__ = "Monkai"

from .reader import DeepRead
from .auth import AuthToken, AuthenticationError, InvalidTokenError
from .cache import DocumentCache
from .resilience import CircuitBreaker
from .models import (
    # Core models
    Question,
    QuestionConfig,
    PageRange,
    Result,
    ProcessingResult,
    DocumentMetadata,
    ProcessingMetrics,
    Classification,
    # Example schemas
    DadosContrato,
    DadosEdital,
    ClassificacaoTripartite,
)
from .exceptions import (
    DeepReadError,
    DocumentError,
    ProcessingError,
    ConfigurationError,
    MissingDependencyError,
    ProviderAuthError,
    RateLimitError,
    ModelError,
)

__all__ = [
    # Main class
    "DeepRead",
    # Auth
    "AuthToken",
    "AuthenticationError",
    "InvalidTokenError",
    # Resilience
    "DocumentCache",
    "CircuitBreaker",
    # Core Models
    "Question",
    "QuestionConfig",
    "PageRange",
    "Result",
    "ProcessingResult",
    "DocumentMetadata",
    "ProcessingMetrics",
    "Classification",
    # Example Schemas
    "DadosContrato",
    "DadosEdital",
    "ClassificacaoTripartite",
    # Exceptions
    "DeepReadError",
    "DocumentError",
    "ProcessingError",
    "ConfigurationError",
    "MissingDependencyError",
    "ProviderAuthError",
    "RateLimitError",
    "ModelError",
]
