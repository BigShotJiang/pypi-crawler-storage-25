from typing import Any
from jinja2 import Template, TemplateError, UndefinedError, Environment
import ast

from ..utils.logger import logger


def get_nested_value(data: Any, path: str) -> Any:
    if not path:
        return data

    template_str = f"{{{{ {path} }}}}"

    try:
        template = Template(template_str)
        if isinstance(data, dict):
            result = template.render(**data)
        else:
            result = template.render(data)
        
        if not result or result == '':
            return None
            
        try:
            return ast.literal_eval(result)
        except (ValueError, SyntaxError):
            return result
    except (TemplateError, UndefinedError):
        return None


def render_template_string(template_str: str, state: dict, template_loader: Any = None) -> str:
    """
    Render a Jinja2 template string with the provided state.
    
    If template_loader (Environment) is provided, it is used for rendering.
    Falls back to a fresh Environment if loader is missing or invalid.
    """
    if not template_str:
        return ""
    
    if not template_loader or not hasattr(template_loader, 'from_string'):
        template_loader = Environment()
        
    try:
        return template_loader.from_string(template_str).render(**state)
    except (TemplateError, UndefinedError) as e:
        logger.error(f"Template rendering failed for '{template_str}': {e}")
        return template_str