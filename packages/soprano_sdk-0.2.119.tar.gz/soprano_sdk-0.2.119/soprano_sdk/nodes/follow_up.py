"""
Follow-up node strategy.

Activated automatically after any workflow outcome (instead of terminating the graph).
Handles follow-up Q&A, intent changes, restarts, and out-of-scope detection using
structured LLM output.
"""
import json
from datetime import date, datetime, timedelta, timezone
import textwrap
from typing import Dict, Any, List, Optional

from langgraph.types import interrupt

from soprano_sdk.agents.adaptor import AgentAdapter
from soprano_sdk.core.localization import LocalizationRule
from soprano_sdk.guardrails import GuardrailViolationError, GuardrailFailureResponse

from .base import ActionStrategy
from ..agents.factory import AgentFactory
from ..agents.structured_output import FollowUpOutput
from ..core.constants import WorkflowKeys, FOLLOW_UP_NODE
from ..core.state import initialize_state
from ..utils.logger import logger
from ..utils.tracing import trace_node_execution, trace_agent_invocation
from ..utils.template import render_template_string


class FollowUpStrategy(ActionStrategy):
    """
    Workflow-level follow-up node that activates after any outcome.

    Instead of terminating, the graph routes here. This node:
    - Delivers the outcome message to the user on first entry
    - Self-loops to handle follow-up Q&A via structured LLM output
    - Routes back to collector nodes on intent_change (with rollback)
    - Resets the entire graph on restart
    - Raises interrupt on out_of_scope (graph paused, not ended)
    - Ends the graph when max_attempts is exhausted
    """

    # Fallback message when agent.invoke() itself raises (network error, timeout, etc.).
    # Uses the global failure_message if configured, otherwise falls back to this default.
    _DEFAULT_LLM_INVOCATION_ERROR_FALLBACK = "I'm sorry, I'm having trouble right now. Please try again."

    def __init__(self, follow_up_config: Dict[str, Any], engine_context: Any, first_step_id: str, node_id: str = FOLLOW_UP_NODE):

        fake_step_config = {'id': node_id, 'action': 'follow_up'}
        super().__init__(fake_step_config, engine_context)

        self.config = follow_up_config
        self.name = follow_up_config.get('name', 'follow_up')
        self.first_step_id = first_step_id
        self.max_attempts = follow_up_config.get('max_attempts')  # None = infinite
        self.max_history_turns = follow_up_config.get('max_history_turns')  # None = unlimited
        self.on_max_attempts_reached = follow_up_config.get(
            'on_max_attempts_reached', "Our conversation has ended. Thank you."
        )
        self.on_unknown = follow_up_config.get(
            'on_unknown',
            "I don't have enough information to answer that question based on the available context."
        )
        self._LLM_INVOCATION_ERROR_FALLBACK = (
            getattr(engine_context, 'failure_message', None)
            or self._DEFAULT_LLM_INVOCATION_ERROR_FALLBACK
        )

        # Resolve guardrails by name from the engine's registry (ordered list)
        guardrail_names = self.config.get("guardrails", [])
        guardrail_registry = getattr(engine_context, 'guardrail_registry', {})
        self.output_guardrails = [
            guardrail_registry[name] for name in guardrail_names
            if name in guardrail_registry
        ]
        if self.output_guardrails:
            logger.info(f"Step '{self.step_id}': loaded {len(self.output_guardrails)} guardrail(s)")

        from .collect_input import _create_rollback_strategy
        rollback_strategy_name = engine_context.get_config_value("rollback_strategy", "history_based")
        self.rollback_strategy = _create_rollback_strategy(rollback_strategy_name)

        # Out-of-scope detection configuration (enabled by default)
        self.enable_out_of_scope = self.config.get("detect_out_of_scope", True)

        if explicit_scope := self.config.get("scope_description"):
            self.scope_description = explicit_scope
        else:
            self.scope_description = getattr(engine_context, "workflow_description", "the current workflow")

    @property
    def _conversation_key(self) -> str:
        return f'{self.step_id}_conversation'

    def pre_execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass


    def execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        with trace_node_execution(
            node_id=self.name,
            node_type="follow_up",
        ) as span:
            state = initialize_state(state)

            if self._conversation_key not in state.get(WorkflowKeys.CONVERSATIONS, {}):
                self._get_or_create_conversation(state)
                logger.info(f"Follow-up: initialized '{self._conversation_key}', returning for checkpoint.")
                return state

            conversation = self._get_or_create_conversation(state)

            if pending_prompt := state.get(WorkflowKeys.FOLLOW_UP_PENDING_PROMPT):
                state[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] = None
                # Fire interrupt to deliver the pending message (outcome or OOS) to the user.
                # On resumption, interrupt() returns the user's response instead of raising.
                # The node then completes normally so all state mutations are checkpointed.
                user_input = interrupt(pending_prompt)
                if pending_prompt.get("type") == "follow_up":
                    # Add outcome message to conversation history on resumption.
                    conversation.append(self._build_conversation_entry(
                        role="assistant",
                        content=pending_prompt["text"],
                        options=pending_prompt.get("options"),
                        is_selectable=pending_prompt.get("is_selectable"),
                    ))
                    self._update_conversation(state, conversation)

            else:
                prompt = self._get_last_interrupt_payload(conversation)
                user_input = interrupt(prompt)
            span.add_event("user.input_received", {"input_length": len(str(user_input))})

            attempts = (state.get(WorkflowKeys.FOLLOW_UP_ATTEMPTS) or 0) + 1
            state[WorkflowKeys.FOLLOW_UP_ATTEMPTS] = attempts

            if self.max_attempts is not None and attempts > self.max_attempts:
                logger.info(f"Follow-up max_attempts ({self.max_attempts}) exhausted")
                span.add_event("follow_up.max_attempts_exhausted", {"attempts": attempts})
                return self._terminate_conversation(state)

            conversation.append({"role": "user", "content": str(user_input)})
            self._update_conversation(state, conversation)
            agent_response = self._get_agent_response(state, conversation)

            # Mark utilized after follow-up agent invocation to prevent secondary extraction
            # by subsequent nodes in the same turn.
            state[WorkflowKeys.USER_MESSAGE_UTILIZED] = True

            # Early exit: guardrail fired — error message already in conversation,
            # stay in answering state so the user is re-prompted.
            if isinstance(agent_response, GuardrailFailureResponse):
                logger.info(f"Step '{self.step_id}': guardrail failure, staying in answering state")
                self._update_conversation(state, conversation)
                return state

            output = agent_response

            has_dispatch_signal = bool(output.intent_change or output.out_of_scope or output.restart)
            if not has_dispatch_signal and not (output.bot_response or "").strip():
                logger.warning("Follow-up: empty bot_response in structured output — substituting error fallback.")
                output = output.model_copy(update={"bot_response": self._LLM_INVOCATION_ERROR_FALLBACK})

            # Record the assistant response in history before dispatching special actions
            content_data = output.model_dump()
            conversation.append(self._build_conversation_entry(
                role="assistant",
                content=json.dumps(content_data)
            ))
            self._update_conversation(state, conversation)

            if output.intent_change:
                if output.restart:
                    logger.warning("Follow-up: LLM set both restart and intent_change — preferring intent_change")
                if output.out_of_scope:
                    logger.warning("Follow-up: LLM set both intent_change and out_of_scope — preferring intent_change")
                logger.info(
                    f"[FOLLOW_UP] {self.step_id} | intent change detected -> {output.intent_change} | "
                    f"llm_response={{bot_response={output.bot_response}, intent_change={output.intent_change}, "
                    f"out_of_scope={output.out_of_scope}, restart={output.restart}}}"
                )
                span.add_event("intent_change.detected", {"target": str(output.intent_change)})
                return self._handle_intent_change(output.intent_change, state)

            if output.out_of_scope:
                if output.restart:
                    logger.warning("Follow-up: LLM set both restart and out_of_scope — preferring out_of_scope")
                logger.info(
                    f"[FOLLOW_UP] {self.step_id} | out-of-scope detected | "
                    f"llm_response={{bot_response={output.bot_response}, out_of_scope={output.out_of_scope}, "
                    f"restart={output.restart}}}"
                )
                span.add_event("out_of_scope.detected", {"reason": str(output.out_of_scope)})
                return self._handle_out_of_scope(output, state, conversation, attempts, user_input)

            if output.restart:
                span.add_event("follow_up.restart")
                return self._handle_restart(state)

            self._set_status(state, 'answering')
            return state


    def _invoke_llm(self, state: Dict[str, Any], conversation: List[Dict]) -> FollowUpOutput:
        """Call the follow-up agent and return a parsed FollowUpOutput.

        Falls back to a safe error response on invocation failure, or wraps the raw
        string as bot_response if parsing fails.
        """
        agent = self._create_agent(state)
        raw_response = None
        try:
            with trace_agent_invocation(
                agent_name=self.name,
                model=self.config.get('model', 'default'),
            ):
                raw_response = agent.invoke(self._to_llm_messages(conversation))
            if isinstance(raw_response, GuardrailFailureResponse):
                return raw_response
            if isinstance(raw_response, dict):
                return FollowUpOutput(**raw_response)
            return FollowUpOutput(**json.loads(str(raw_response)))
        except Exception as e:
            if raw_response is None:
                logger.warning(f"Follow-up LLM invocation failed: {e}. Using error fallback.")
                return FollowUpOutput(bot_response=self._LLM_INVOCATION_ERROR_FALLBACK)
            logger.warning(f"Follow-up structured output parse failed: {e}. Using raw response.")
            return FollowUpOutput(bot_response=str(raw_response))

    def _get_agent_response(self, state: Dict[str, Any], conversation: List[Dict]) -> Any:
        """Get agent response and handle guardrails."""
        agent = self._create_agent(state)

        # Set grounding context so the adapter can forward it to grounding guardrails
        if self.output_guardrails:
            agent.guardrail_context = {
                "grounding_source": self._build_grounding_source(state, agent),
                "query": next(
                    (msg['content'] for msg in reversed(conversation) if msg['role'] == 'user'), ""
                ),
                "function_outputs": self._build_function_outputs(state),
            }

        try:
            return self._invoke_llm(state, conversation)
        except GuardrailViolationError as gve:
            logger.warning(f"Step '{self.step_id}': guardrail retries exhausted — {gve.error_message}")
            conversation.append(self._build_conversation_entry(
                role="assistant",
                content=gve.error_message,
                options=None,
                is_selectable=None,
            ))
            return GuardrailFailureResponse(gve.error_message)

    def _build_grounding_source(self, state: Dict[str, Any], agent: AgentAdapter) -> str:
        """Assemble grounding source from agent instructions, workflow state, and tool outputs."""
        parts = []

        # Get system prompt for context
        base_localization = self.engine_context.get_base_localization_instructions(state)
        localization_rule = self.engine_context.get_localization_rule(state)
        wait_phrases = self.engine_context.get_localization_wait_phrases(state)

        instructions = self._build_instructions(
            state,
            base_localization=base_localization,
            localization_rule=localization_rule,
            wait_phrases=wait_phrases
        )
        parts.append(f"AGENT INSTRUCTIONS:\n{instructions}")

        workflow_context = self._build_context_summary(state)
        if workflow_context:
            parts.append(f"WORKFLOW DATA:\n{workflow_context}")

        if hasattr(agent, 'last_tool_outputs') and agent.last_tool_outputs:
            tool_text = "\n".join(agent.last_tool_outputs)
            parts.append(f"TOOL OUTPUTS:\n{tool_text}")

        return "\n\n".join(parts)

    def _build_function_outputs(self, state: Dict[str, Any]) -> List[str]:
        """Collect call_function / call_async_function outputs as individual strings."""
        outputs = []
        for field_name in state.get(WorkflowKeys.COMPUTED_FIELDS, []):
            value = state.get(field_name)
            if value is not None:
                outputs.append(f"{field_name}: {value}")
        return outputs


    def _handle_out_of_scope(
        self,
        output: FollowUpOutput,
        state: Dict[str, Any],
        conversation: List[Dict],
        attempts: int,
        user_input: Any,
    ) -> Dict[str, Any]:
        """Handle an out-of-scope LLM response.

        Stores the OOS bot_response in conversation context, tracks consecutive OOS
        count (with a hard cap), and queues the OOS interrupt payload via
        PENDING_PROMPT so LangGraph fires one interrupt per execution cycle.
        """
        if (output.bot_response or "").strip():
            conversation.append(self._build_conversation_entry(
                role="assistant",
                content=output.bot_response,
                options=output.options,
                is_selectable=output.is_selectable,
            ))
            self._update_conversation(state, conversation)

        logger.info(f"Follow-up out_of_scope: {output.out_of_scope}")
        if self.max_attempts is not None and attempts > self.max_attempts:
            logger.info(f"Follow-up max_attempts ({self.max_attempts}) exhausted on OOS turn")
            return self._terminate_conversation(state)

        state[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] = self._build_oos_payload(output, user_input)
        self._set_status(state, 'answering')
        return state

    def _handle_restart(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Signal a restart to the workflow router."""
        logger.info("Follow-up: restart triggered — routing to END")
        self._set_status(state, 'restart')
        return state

    def _handle_intent_change(self, target_node: str, state: Dict[str, Any]) -> Dict[str, Any]:
        """Rollback state to the target collector node and resume the graph there."""
        logger.info(f"Follow-up: intent change -> '{target_node}'")
    
        excluded_nodes = self.config.get('excluded_nodes', [])
        if target_node in excluded_nodes:
            logger.warning(f"Follow-up: intent change to excluded node '{target_node}' rejected — falling back to self-loop")
            self._set_status(state, 'answering')
            return state

        rollback_state = self._rollback_state_to_node(state, target_node, preserve_conversations=True)

        if not rollback_state:
            logger.warning(f"Rollback failed for unknown node '{target_node}' — falling back to self-loop")
            self._set_status(state, 'answering')
            return state

        rollback_state[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] = None
        rollback_state[WorkflowKeys.FOLLOW_UP_ACTIVE] = None
        rollback_state[WorkflowKeys.FOLLOW_UP_ATTEMPTS] = None
        return rollback_state


    def _terminate_conversation(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """End the follow-up conversation after max_attempts is exhausted.

        Sets the terminal message to on_max_attempts_reached and clears all
        follow-up tracking fields so the graph reaches END cleanly.  The
        message is surfaced to the caller by tools.py / streamer.py after
        the graph completes, not via interrupt.
        """
        state[WorkflowKeys.MESSAGES] = [self.on_max_attempts_reached]
        state[WorkflowKeys.OUTCOME_ID] = None
        state[WorkflowKeys.FOLLOW_UP_ACTIVE] = None
        state[WorkflowKeys.FOLLOW_UP_ATTEMPTS] = None
        state[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] = None
        self._set_status(state, 'done')
        return state


    def _create_agent(self, state: Dict[str, Any]):
        model_config = self.engine_context.get_model_config(self.config)

        # Get localization context
        base_localization = self.engine_context.get_base_localization_instructions(state)
        localization_rule = self.engine_context.get_localization_rule(state)
        wait_phrases = self.engine_context.get_localization_wait_phrases(state)

        # Build agent instructions with localization context
        instructions = self._build_instructions(
            state,
            base_localization=base_localization,
            localization_rule=localization_rule,
            wait_phrases=wait_phrases
        )

        tools = self._load_tools(state)
        framework = self.engine_context.get_config_value('agent_framework', 'langgraph')

        tool_config = self.engine_context.config.get('tool_config') or {}
        max_retry_limit = tool_config.get('max_retry_limit')
        failure_message = getattr(self.engine_context, 'failure_message', None)

        return AgentFactory.create_agent(
            framework=framework,
            name='FollowUp',
            model_config=model_config,
            tools=tools,
            system_prompt=instructions,
            structured_output_model=FollowUpOutput,
            guardrails=self.output_guardrails,
            max_retry_limit=max_retry_limit,
            failure_message=failure_message,
        )

    def _build_instructions(
        self,
        state: Dict[str, Any],
        base_localization: Optional[str] = None,
        localization_rule: Optional[LocalizationRule] = None,
        wait_phrases: Optional[List[str]] = None
    ) -> str:
        """Compose the full system prompt for the follow-up LLM."""
        
        localization_block = ""
        if base_localization:
            localization_block = f"<localization>\n{base_localization}\n</localization>\n\n"

        agent_parts = [
            self._build_core_instructions(),
        ]

        custom_instructions = self.config.get('instructions', '').strip()
        agent_parts.append(f"ROLE & PERSONA:\n{custom_instructions if custom_instructions else 'You are a helpful follow-up assistant.'}")

        wait_phrases_str = ", ".join([f'"{p}"' for p in (wait_phrases or [])])
        bot_response_rules = textwrap.dedent(f"""
        BOT RESPONSE RULES:
        - If the user input is unclear, ask for clarification.
        - If the user asks to wait or pause (e.g. {wait_phrases_str}), acknowledge politely and wait.
        """)
        agent_parts.append(bot_response_rules)

        if localization_rule:
            if localization_rule.instructions:
                agent_parts.append(f"LOCALIZATION GUIDELINES:\n{localization_rule.instructions}")
            if localization_rule.examples:
                agent_parts.append(f"LOCALIZATION EXAMPLES:\n{localization_rule.examples}")

        agent_instructions_content = "\n\n".join(agent_parts)
        agent_instructions_block = f"<agent_instructions>\n{agent_instructions_content}\n</agent_instructions>"

        dynamic_parts = [
            self._build_context_summary(state),
            self._build_tool_responses(state),
            self._build_conversation_history(state),
        ]

        intent_guidance = self._build_intent_change_guidance(state)
        if intent_guidance:
            dynamic_parts.append(intent_guidance)

        dynamic_parts.append(self._build_response_format())
        
        dynamic_content = "\n\n".join(dynamic_parts)

        # Wrap with out-of-scope detection if enabled
        if self.enable_out_of_scope:
            dynamic_content = self._wrap_instructions_with_out_of_scope_detection(
                dynamic_content, self.scope_description
            )

        return (
            f"{localization_block}"
            f"{agent_instructions_block}\n\n"
            f"{dynamic_content}\n\n"
            f"IMPORTANT: The latest user message is the highest priority for decision making.\n"
            f"Current date: {date.today().isoformat()}"
        )

    def _wrap_instructions_with_out_of_scope_detection(
        self,
        instructions: str,
        scope_description: str,
    ) -> str:
        """Append out-of-scope detection instructions. Same as collect_input implementation."""
        return f"""{instructions}

<out_of_scope_detection>
OUT-OF-SCOPE DETECTION:
You are working within this context: 
{scope_description}

IMPORTANT: If the user's query is COMPLETELY UNRELATED to the workflow context above:
- Set out_of_scope to a brief description of what the user is trying to do
- Do NOT attempt to answer the query or provide information about unrelated topics
- Do NOT confuse this with related questions or intent changes within the workflow

A query is OUT OF SCOPE only if it's about:
- Completely different products, services, or business domains not mentioned in the workflow context
- Actions or requests that have no connection to the workflow purpose
- Topics that are entirely unrelated to what this workflow is designed to handle

A query is IN SCOPE if it:
- Relates to any part of the workflow context described above
- Asks clarifying questions about the current or previous steps
- Requests to change or correct previously collected information (this is an intent change, not out-of-scope)
</out_of_scope_detection>
"""

    def _build_core_instructions(self) -> str:
        """Unified core logic for the follow-up agent."""
        return textwrap.dedent(f"""
            PURPOSE:
            Decide how to handle the user's message based on the following priorities:
            1. intent_change: If message maps to a collector node (meaningful value, update, or clarification).
            2. restart: If the user explicitly wants to start over.
            3. out_of_scope: If the request is unrelated to the workflow.
            4. bot_response: Answer the user's question using ONLY provided context and tool outputs.

            DECISION RULES:
            - PRIORITY: intent_change > restart > out_of_scope > bot_response.
            - If any higher priority field (intent_change, restart, out_of_scope) applies: bot_response MUST be null.
            - Answer ONLY from provided context and tool outputs. If the information is missing AND you cannot determine an intent_change, out_of_scope, or restart, respond with a polite message acknowledging the question and explaining it's not available (e.g., "{self.on_unknown}").
            - TOOL USAGE: Use available tools to retrieve information if not present in context. Use the `compute` tool ONLY for mathematical calculations or date arithmetic. Do NOT use tools if you have determined an intent_change, out_of_scope, or restart.
            - Do NOT guess or fabricate information.

            STRICT CONSTRAINTS:
            - You CANNOT perform any actions (e.g., processing a payment, booking a ticket, or updating workflow state) directly.
            - You CANNOT simulate collecting data or updating fields. 
            - If the user provides information to update or complete the workflow, you MUST use `intent_change` to route to the appropriate node.
            - You are an information and routing bridge ONLY. You do not HAVE permission to execute or commit any business logic.
        """).strip()

    def _build_context_summary(self, state: Dict[str, Any]) -> str:
        """Return a WORKFLOW CONTEXT block listing the user's original query and all collected field values."""
        lines = ["WORKFLOW CONTEXT:"]

        if user_query := state.get(WorkflowKeys.USER_MESSAGE, ""):
            lines.append(f"  User query: {user_query}")

        accessible_fields = self.config.get('accessible_fields', [])

        for field in self.engine_context.data_fields:
            name = field['name']
            if name not in accessible_fields:
                continue

            val = state.get(name)
            if val is not None:
                # If val is a structured-output artifact (a dict containing 'bot_response'),
                # the collector stored the full response dict instead of just the field value.
                # Extract the actual field value by key to avoid leaking schema internals.
                if isinstance(val, dict) and 'bot_response' in val:
                    val = val.get(name)
                if val is not None:
                    lines.append(f"  - {name}: {val}")
        if len(lines) == 1:
            lines.append("  (No data collected yet)")
        return "\n".join(lines)

    def _build_conversation_history(self, state: Dict[str, Any]) -> str:
        """Return a CONVERSATION HISTORY block from all prior collector node conversations.

        Collector nodes in structured output mode store raw JSON as message content.
        This method extracts only the user-facing text so the follow-up LLM receives
        clean natural-language history rather than JSON artefacts.
        """
        aggregated = self.engine_context._aggregate_conversation_history(state)
        if not aggregated:
            return "CONVERSATION HISTORY: (none)"

        lines = ["CONVERSATION HISTORY:"]
        for msg in aggregated:
            role = msg['role'].upper()
            content = msg['content']
            try:
                parsed = json.loads(content)
                if isinstance(parsed, dict):
                    clean = str(parsed.get('text') or parsed.get('bot_response') or '').strip()

                    options = parsed.get('options')
                    if options:
                        opt_texts = [opt.get('text') for opt in options if isinstance(opt, dict) and opt.get('text')]
                        if opt_texts:
                            clean += f"\nOptions: {', '.join(opt_texts)}"
                    
                    if clean:
                        lines.append(f"  {role}: {clean}")
                    continue
            except (json.JSONDecodeError, ValueError):
                pass
            # Plain text from pattern-matching mode collectors — use as-is
            if content.strip():
                lines.append(f"  {role}: {content.strip()}")
        return "\n".join(lines)

    def _render_template_string(self, template_str: str, state: Dict[str, Any]) -> str:
        template_loader = self.engine_context.get_config_value('template_loader')
        return render_template_string(template_str, state, template_loader)

    def _build_intent_change_guidance(self, state: Dict[str, Any]) -> str:
        """Return an INTENT CHANGE block listing available collector nodes, or '' if none."""
        collector_nodes = state.get(WorkflowKeys.COLLECTOR_NODES, {})
        excluded_nodes = self.config.get('excluded_nodes', [])
        
        node_lines = []
        for node_id, raw_description in collector_nodes.items():
            if node_id not in excluded_nodes:
                description = self._render_template_string(raw_description, state)
                node_lines.append(f"  - {node_id}:\n      {description}")
        
        nodes_str = "\n".join(node_lines)
        if not nodes_str:
            return ""
        return textwrap.dedent(f"""
            INTENT CHANGE / ROUTING:
            Use intent_change when input maps to data handled by a collector node.
            - Match by meaning, not exact wording.
            - If multiple match, choose the MOST specific.
            - Do NOT avoid routing due to uncertainty.
            - Choose ONLY from these available nodes:
            {nodes_str}
        """).strip()

    def _build_tool_responses(self, state: Dict[str, Any]) -> str:
        """Capture and format tool inputs and outputs for available tools."""
        if not self.config.get("show_tool_responses", True):
            return ""

        from ..core.constants import WorkflowKeys
        from ..utils.builtin_tools import MONTY_TOOL_NAME

        available_tools = set(self.config.get('tools', []))
        if self.config.get('default_tools', True):
            available_tools.add(MONTY_TOOL_NAME)

        # Filter out tools that are marked as hidden from prompt
        if available_tools:
            available_tools = self._filter_hidden_tools(available_tools)

        tool_responses = state.get(WorkflowKeys.TOOL_RESPONSES) or {}
        if not tool_responses:
            return ""
        
        MONTY_TOOL_AVAILABLE = MONTY_TOOL_NAME in available_tools
        tool_entries = []
        for tool_name in sorted(available_tools):
            if tool_name in tool_responses:
                tool_data = tool_responses[tool_name]
                if isinstance(tool_data, dict) and "output" in tool_data:
                    output = tool_data["output"]
                    inputs = tool_data.get("input", {})
                    entry = f"- Tool '{tool_name}':\n    INPUT: {json.dumps(inputs)}\n    OUTPUT: {json.dumps(output)}"

                    if MONTY_TOOL_AVAILABLE:
                        entry += f"\n\n - The output of '{tool_name}' can be accessed in the {MONTY_TOOL_NAME} tool using the variable '{tool_name}_response'."
                        
                    tool_entries.append(entry)

        if not tool_entries:
            return ""
        
        header = "\nThe following tools have already been called and returned these results in this turn:\n"
        
        return header + "\n".join(tool_entries) + "\n"

    def _build_response_format(self) -> str:
        """Return the RESPONSE FORMAT instruction block."""
        return textwrap.dedent(f"""
            RESPONSE FORMAT:
            Your Final Answer must be a valid JSON object with exactly these fields:
            {FollowUpOutput.get_schema_reminder()}

            STRICT RULES:
            - Set AT MOST ONE of: intent_change, out_of_scope, restart=true.
            - reasoning: Brief internal reasoning (1-2 sentences).
        """).strip()

    def _load_tools(self, state: Dict[str, Any]) -> List:
        from ..utils.builtin_tools import make_compute_tool, MONTY_TOOL_NAME, MONTY_TOOL_DESCRIPTION
        from ..utils.tool import wrap_state_recording

        raw_tools = []
        if self.engine_context.tool_repository:
            for tool_name in self.config.get('tools', []):
                raw_tools.append(self.engine_context.tool_repository.load(tool_name, state))

        # Wrap each tool to record its output in state["_tool_responses"]
        tools = []
        for name, desc, func in raw_tools:
            tools.append((name, desc, wrap_state_recording(name, state)(func)))

        if self.config.get('default_tools', True):
            compute_func = make_compute_tool(state)
            tools.append((MONTY_TOOL_NAME, MONTY_TOOL_DESCRIPTION, wrap_state_recording(MONTY_TOOL_NAME, state)(compute_func)))

        return tools


    def _to_llm_messages(self, conversation: List[Dict[str, Any]]) -> List[Dict[str, str]]:
        """Convert stored conversation entries to plain ``{role, content}`` dicts.

        Entries written by ``_build_conversation_entry`` may have their content
        JSON-serialised (``{"bot_response": ..., "options": ..., "is_selectable": ...}``)
        to preserve UI metadata.  The LLM only needs plain text, so we unwrap
        the ``bot_response`` field here.

        Applies two guards against JSON format drift in long conversations:
        - Truncation: keeps the first message (outcome) + the last
          ``max_history_turns * 2`` messages when ``max_history_turns`` is set.
        - Format reminder: appends a brief JSON schema reminder to the last user
          message so the model stays anchored to the required output format.
        """
        result = []
        for m in conversation:
            content = m["content"]
            try:
                parsed = json.loads(content)
                if isinstance(parsed, dict) and ("bot_response" in parsed or "text" in parsed):
                    content = parsed.get("bot_response") or parsed.get("text", "")

                    options = parsed.get('options')
                    if options:
                        opt_texts = [opt.get('text') for opt in options if isinstance(opt, dict) and opt.get('text')]
                        if opt_texts:
                            content += f"\nOptions: {', '.join(opt_texts)}"

            except (json.JSONDecodeError, TypeError):
                pass
            result.append({"role": m["role"], "content": str(content).strip()})

        # Truncate: keep first message (outcome context) + last N turns
        if self.max_history_turns is not None and len(result) > self.max_history_turns * 2 + 1:
            result = result[:1] + result[-(self.max_history_turns * 2):]

        # Append JSON schema reminder to last user message to counteract format drift
        # in long conversations (model tends to forget structured output requirements).
        _schema_reminder = (
            f"\n\nIMPORTANT: Your Final Answer MUST be a valid JSON object with exactly these fields:\n"
            f"{FollowUpOutput.get_schema_reminder()}\n"
            "Set at most ONE of: intent_change, out_of_scope, restart=true."
        )
        for i in range(len(result) - 1, -1, -1):
            if result[i]["role"] == "user":
                result[i] = {
                    "role": "user",
                    "content": result[i]["content"] + _schema_reminder,
                }
                break

        return result

    def _get_or_create_conversation(self, state: Dict[str, Any]) -> List[Dict[str, str]]:
        conversations = state.get(WorkflowKeys.CONVERSATIONS, {})
        if self._conversation_key not in conversations:
            new_conv = []
            initial_user_msg = state.get(WorkflowKeys.USER_MESSAGE)

            if initial_user_msg and str(initial_user_msg).strip() and not conversations:
                current_time = datetime.now(timezone.utc).isoformat(timespec='microseconds').replace("+00:00", "Z")
                new_conv.append({
                    "role": "user", 
                    "content": str(initial_user_msg),
                    "timestamp": current_time
                })
            
            conversations[self._conversation_key] = new_conv
            state[WorkflowKeys.CONVERSATIONS] = conversations
        return conversations[self._conversation_key]

    def _update_conversation(self, state: Dict[str, Any], conversation: List[Dict[str, str]]) -> None:
        current_time = datetime.now(timezone.utc)
        for i, msg in enumerate(conversation):
            if "timestamp" not in msg:
                # Use microseconds and add a small offset for messages in the same list to ensure absolute order
                # even when they are part of the same bulk update.
                msg_time = current_time + timedelta(microseconds=i)
                msg["timestamp"] = msg_time.isoformat(timespec='microseconds').replace("+00:00", "Z")
        state[WorkflowKeys.CONVERSATIONS][self._conversation_key] = conversation

    def _get_last_interrupt_payload(self, conversation: List[Dict[str, str]]) -> Any:
        """Return the last assistant response as an interrupt payload dict.

        Content may be a plain string or a JSON blob (``{"bot_response", "options",
        "is_selectable"}``) written by ``_build_conversation_entry``.
        """
        last_msg = next(
            (msg for msg in reversed(conversation) if msg['role'] == 'assistant'),
            None,
        )
        if last_msg is None:
            return self._make_interrupt_payload("")
        content = last_msg['content']
        try:
            parsed = json.loads(content)
            if isinstance(parsed, dict) and ("bot_response" in parsed or "text" in parsed):
                return self._make_interrupt_payload(
                    parsed.get("bot_response") or parsed.get("text", ""),
                    options=parsed.get("options"),
                    is_selectable=parsed.get("is_selectable"),
                )
        except (json.JSONDecodeError, TypeError):
            pass
        return self._make_interrupt_payload(content)

    def _make_interrupt_payload(self,
        message: str,
        options: Optional[List] = None,
        is_selectable: Optional[bool] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"type": "follow_up", "text": message}
        if options is not None:
            payload["options"] = options
        if is_selectable is not None:
            payload["is_selectable"] = is_selectable
        return payload

    def _build_conversation_entry(self,
        role: str,
        content: str,
        options: Optional[List] = None,
        is_selectable: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Build a conversation message dict.

        When options/is_selectable are present, they are serialised into the
        content field as a JSON blob (``{"bot_response": ..., "options": ...,
        "is_selectable": ...}``) so the entry stays ``{role, content}``-only —
        compatible with all agent frameworks (e.g. crewai validates messages
        as ``list[dict[str, str]]``).  ``_get_last_interrupt_payload`` parses
        this blob back out when rebuilding the interrupt payload.
        """
        if options is not None or is_selectable is not None:
            serialised = json.dumps({
                "bot_response": content,
                "options": options,
                "is_selectable": is_selectable,
            })
            return {"role": role, "content": serialised}
        return {"role": role, "content": content}

    def _build_oos_payload(self, output: FollowUpOutput, user_input: Any) -> Dict[str, Any]:
        """Build the OOS pending prompt dict from the LLM's out-of-scope output."""
        payload: Dict[str, Any] = {
            "type": "follow_up_out_of_scope",
            "step_id": self.step_id,
            "reason": output.out_of_scope,
            "bot_response": output.bot_response or "",
            "user_message": str(user_input),
        }
        if output.options is not None:
            payload["options"] = output.options
        if output.is_selectable is not None:
            payload["is_selectable"] = output.is_selectable
        return payload
