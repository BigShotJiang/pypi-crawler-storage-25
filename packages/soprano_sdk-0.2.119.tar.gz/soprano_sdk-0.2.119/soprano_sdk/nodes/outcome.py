"""Defines the OutcomeNode, which renders the outcome message and queues it for delivery."""
from typing import Any, Dict

from .base import ActionStrategy
from ..core.constants import WorkflowKeys
from ..utils.logger import logger


class OutcomeNode(ActionStrategy):
    """Node that renders the outcome message and queues it for delivery.

    When follow-up is enabled, renders the outcome message, sets
    ``FOLLOW_UP_ACTIVE``, and stores the payload in ``FOLLOW_UP_PENDING_PROMPT``,
    then returns normally.  Because this node completes without interrupting,
    LangGraph checkpoints these mutations before the follow-up node runs.

    The follow-up node then fires ``interrupt(pending_prompt)`` to deliver the
    outcome message to the user and collect their first Q&A response in a single
    pass — avoiding the LangGraph limitation where state mutations made before
    ``interrupt()`` are discarded.

    When follow-up is disabled, this node is a no-op; the outcome message is
    retrieved by ``tools.py`` via ``get_outcome_message()`` after the graph
    reaches ``END``.
    """

    def __init__(self, outcome_id: str, engine_context: Any, follow_up_enabled: bool = True) -> None:
        fake_step_config = {'id': outcome_id, 'action': 'outcome'}
        super().__init__(fake_step_config, engine_context)
        self.follow_up_enabled = follow_up_enabled

    def pre_execute(self, state: Dict[str, Any]) -> None:
        pass

    def execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        logger.info(f"Outcome node '{self.step_id}': delivering outcome message (follow_up={self.follow_up_enabled})")

        state[WorkflowKeys.OUTCOME_ID] = self.step_id

        if not self.follow_up_enabled:
            # Message delivered by tools.py via get_outcome_message() after END.
            return state

        # Render outcome message and queue it for the follow-up node to deliver via interrupt.
        outcome_payload = self.engine_context.get_outcome_message(state)
        pending: Dict[str, Any] = {"type": "follow_up", "text": outcome_payload.message}
        if outcome_payload.options is not None:
            pending["options"] = outcome_payload.options
        if outcome_payload.is_selectable is not None:
            pending["is_selectable"] = outcome_payload.is_selectable

        state[WorkflowKeys.FOLLOW_UP_ACTIVE] = True
        state[WorkflowKeys.FOLLOW_UP_PENDING_PROMPT] = pending
        return state
