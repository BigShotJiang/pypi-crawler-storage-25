from typing import Any, Dict

from pydantic import BaseModel

from ..aws.session import SessionRegistry


class InstructorStructuredLLM:
    """Wrapper using instructor for structured output on Bedrock.

    Provides the same ``.invoke(messages)`` interface as LangChain's
    ``with_structured_output()`` result, returning a Pydantic model instance.
    """

    def __init__(self, model_name: str, output_schema: type[BaseModel], bedrock_kwargs: Dict[str, Any]):
        self._bedrock_kwargs = bedrock_kwargs
        self._model_name = model_name
        self._output_schema = output_schema

    def _get_instructor_client(self):
        import instructor

        session = SessionRegistry.get_or_create(
            aws_access_key_id=self._bedrock_kwargs.get("aws_access_key_id"),
            aws_secret_access_key=self._bedrock_kwargs.get("aws_secret_access_key"),
            region_name=self._bedrock_kwargs.get("region_name"),
            aws_session_token=self._bedrock_kwargs.get("aws_session_token"),
        )
        verify = self._bedrock_kwargs.get("verify_ssl", False)
        return instructor.from_bedrock(session.client("bedrock-runtime", verify=verify))

    def invoke(self, messages):
        """Invoke the instructor client and return a Pydantic instance."""
        normalized = []
        for msg in messages:
            if isinstance(msg, dict):
                normalized.append(msg)
            else:
                # LangChain BaseMessage objects
                normalized.append({"role": msg.type, "content": msg.content})

        return self._get_instructor_client().create(
            modelId=self._model_name,
            messages=normalized,
            response_model=self._output_schema,
        )
