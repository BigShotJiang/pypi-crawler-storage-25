"""
Functional guardrails for LLM output validation.

ThoughtActionGuardrail uses crewai.agents.parser.parse() to detect
leaked ReAct reasoning chain tokens (Thought:/Action:) in the final response.
"""
from __future__ import annotations

from ..utils.logger import logger
from ..utils.tracing import trace_guardrail_invocation
from ..utils.parser import convert_to_dict
from .base_guardrail import BaseGuardrail, GuardrailFactory, GuardrailResult
from pydantic import ValidationError


@GuardrailFactory.register("thought_action_check")
class ThoughtActionGuardrail(BaseGuardrail):
    """
    Validates CrewAI response format using crewai.agents.parser.parse().

    Only an AgentFinish result (a proper "Final Answer:" conclusion) is valid.
    Everything else indicates a malformed response:

    - parse() → AgentFinish      : PASS  (agent properly concluded)
    - parse() → AgentAction      : FAIL  (Thought:/Action: leaked)
    - parse() → OutputParserError: FAIL  (missing expected Final Answer: format)
    - Any other exception         : FAIL  (unexpected state)

    Supports retry with regeneration:
    - max_retries: Number of regeneration attempts (default: 1)
    """

    def __init__(self, error_message: str, max_retries: int = 1, is_enabled: bool = True, **kwargs):
        """Initialize with optional retry configuration."""
        super().__init__(error_message, is_enabled=is_enabled)
        self.max_retries = max_retries
        self._output_schema = None
        self._required_fields: list[str] = []
        logger.info(f"ThoughtActionGuardrail initialized with max_retries={max_retries}")

    @property
    def regeneration_feedback(self) -> str:
        if self._output_schema is not None:
            try:
                properties = self._output_schema.model_json_schema().get("properties", {})
                lines = []
                for field_name, field_meta in properties.items():
                    json_type = field_meta.get("type", "string")
                    if field_name in self._required_fields:
                        lines.append(f'  "{field_name}": {json_type}  // required')
                    else:
                        lines.append(f'  "{field_name}": {json_type} | null')
                schema_str = "{\n" + ",\n".join(lines) + "\n}"
            except Exception:
                schema_str = str(self._output_schema)
            return (
                "[System: Your previous response contained internal reasoning patterns "
                "(Thought:/Action:) that should not be visible. "
                "Respond with a valid JSON object matching this structure:\n"
                f"{schema_str}\n"
                "Do not include any reasoning chains — only the JSON output.]"
            )
        return (
            "[System: Your previous response contained internal reasoning patterns "
            "(Thought:/Action:) that should not be visible to the user. "
            "Please provide a clean, direct response starting with 'Final Answer:' "
            "containing only the user-facing message.]"
        )

    def check(self, response: str, **kwargs) -> GuardrailResult:
        self._output_schema = kwargs.get("output_schema")
        self._required_fields = kwargs.get("required_fields") or []
        with trace_guardrail_invocation(guardrail_name="ThoughtActionGuardrail", model="rule-based") as span:
            if span and span.is_recording():
                span.set_attribute("guardrail.input", response)

            react_keywords = ["Thought:", "Action:", "Observation:"]
            passed = True
            failed_keyword = None
            for keyword in react_keywords:
                if keyword in response:
                    passed = False
                    failed_keyword = keyword
                    break

            if span and span.is_recording():
                span.set_attribute("guardrail.passed", passed)
                if failed_keyword:
                    span.set_attribute("guardrail.failed_keyword", failed_keyword)

            if not passed:
                return GuardrailResult(passed=False, error_message=self.error_message)
            return GuardrailResult(passed=True)

@GuardrailFactory.register("structured_output_check")
class StructuredOutputGuardrail(BaseGuardrail):
    """
    Ensures that a structured output response is not empty.

    A response is considered empty if both:
    1. 'bot_response' (or 'message') is null or empty.
    2. No data fields (outside of framework metadata) are populated.

    This prevents 'silent failures' where the agent returns a schema-valid
    but semantically empty response.
    """

    def __init__(self, error_message: str, max_retries: int = 1, is_enabled: bool = True, **kwargs):
        """Initialize with optional retry configuration."""
        super().__init__(error_message, is_enabled=is_enabled)
        self.max_retries = max_retries
        # Stores the most recent ValidationError from schema validation, used in regeneration_feedback.
        self._validation_error: ValidationError | None = None
        # Stores the conversational fields used in the most recent check, used in regeneration_feedback.
        self._conversational_fields: list[str] = ["bot_response", "message"]
        logger.info(f"StructuredOutputGuardrail initialized with max_retries={max_retries}")

    @property
    def regeneration_feedback(self) -> str:
        if self._validation_error:
            return (
                f"[System: Your previous response failed schema validation.\n"
                f"Validation error: {self._validation_error}\n"
                f"Ensure all fields have the correct types and format. Please try again.]"
            )
        fields_str = " or ".join([f"'{f}'" for f in self._conversational_fields])
        return (
            "[System: Your previous response was empty or incomplete. "
            f"You must provide a conversational response in {fields_str}. "
            f"If providing 'options', you MUST also provide a conversational response in {fields_str} "
            "to provide context. Alternatively, populate the required data fields. "
            "Please try again.]"
        )

    def check(self, response: str, **kwargs) -> GuardrailResult:
        self._validation_error = None  # reset per check

        with trace_guardrail_invocation(guardrail_name="StructuredOutputGuardrail", model="rule-based") as span:
            if span and span.is_recording():
                span.set_attribute("guardrail.input", response)

            try:
                data = convert_to_dict(response)
                if span and span.is_recording():
                    span.set_attribute("guardrail.parsed_data", str(data))

                if not isinstance(data, dict):
                    # Plain-text response — validation fail
                    logger.warning(f"StructuredOutputGuardrail: Response is not a valid dictionary. Got: {data}.\nType:{type(data)}")
                    if span and span.is_recording():
                        span.set_attribute("guardrail.passed", False)
                        span.set_attribute("guardrail.response_type", "plain_text")
                    return GuardrailResult(passed=False, error_message=self.error_message)

                # --- Determine conversational field name from schema ---
                output_schema = kwargs.get("output_schema")
                conversational_fields = []
                if output_schema and hasattr(output_schema, "model_fields"):
                    if "message" in output_schema.model_fields:
                        conversational_fields.append("message")
                    if "bot_response" in output_schema.model_fields:
                        conversational_fields.append("bot_response")
                
                # Fallback if no schema or no typical field found in schema
                if not conversational_fields:
                    conversational_fields = ["bot_response", "message"]
                
                self._conversational_fields = conversational_fields
                has_conversational_response = any(data.get(f) for f in conversational_fields)

                # --- Rule 1: Schema conformance check ---
                # Ensure the structured data matches the expected Pydantic model.
                if output_schema:
                    try:
                        output_schema.model_validate(data)
                    except ValidationError as e:
                        self._validation_error = e
                        logger.warning(f"StructuredOutputGuardrail: Schema validation failed. Error: {e}")
                        if span and span.is_recording():
                            span.set_attribute("guardrail.schema_validation_failed", True)
                            span.set_attribute("guardrail.validation_error", str(e))
                            span.set_attribute("guardrail.passed", False)
                        return GuardrailResult(passed=False, error_message=self.error_message)

                # --- Rule 2: Conversational response or Routing fields present → PASS ---
                # These fields indicate a conversational turn or state steering rather than data submission.
                _ROUTING_FIELDS = ("out_of_scope", "intent_change", "restart")
                has_routing_field = any(data.get(f) for f in _ROUTING_FIELDS)
                
                if has_conversational_response or has_routing_field:
                    if span and span.is_recording():
                        span.set_attribute("guardrail.passed", True)
                        if has_conversational_response:
                            span.set_attribute("guardrail.has_conversational_response", True)
                            span.set_attribute("guardrail.conversational_fields", str(conversational_fields))
                        if has_routing_field:
                            span.set_attribute("guardrail.has_routing_field", True)
                    return GuardrailResult(passed=True)

                # --- Rule 3: Required fields check ---
                # No conversational/routing response: agent must be submitting data.
                # Every declared required field must be present (not None).
                required_fields: list[str] = kwargs.get("required_fields") or []
                missing = [f for f in required_fields if data.get(f) is None]

                if span and span.is_recording():
                    span.set_attribute("guardrail.has_bot_response", False)
                    span.set_attribute("guardrail.missing_required_fields", str(missing))

                if required_fields:
                    if not missing:
                        if span and span.is_recording():
                            span.set_attribute("guardrail.passed", True)
                        return GuardrailResult(passed=True)
                    else:
                        logger.warning(f"StructuredOutputGuardrail: Missing required fields: {missing}")
                        if span and span.is_recording():
                            span.set_attribute("guardrail.passed", False)
                            span.set_attribute("guardrail.reason", "missing_required_fields")
                        return GuardrailResult(passed=False, error_message=self.error_message)

                # Final fallback: If no conversational response, no routing fields,
                # and no required fields specified, the guardrail passes
                # (empty or partial but not explicitly invalid data).
                if span and span.is_recording():
                    span.set_attribute("guardrail.passed", True)
                    span.set_attribute("guardrail.reason", "fail_open_no_constraints")
                
                return GuardrailResult(passed=True)

            except (ValueError, SyntaxError, TypeError) as e:
                # Malformed JSON or structure — fail the guardrail
                logger.debug(f"StructuredOutputGuardrail: unexpected parse error: {e}")
                if span and span.is_recording():
                    span.set_attribute("guardrail.passed", False)
                    span.set_attribute("guardrail.reason", "parse_exception")
                    span.set_attribute("guardrail.error", str(e))
                return GuardrailResult(passed=False, error_message=self.error_message)
