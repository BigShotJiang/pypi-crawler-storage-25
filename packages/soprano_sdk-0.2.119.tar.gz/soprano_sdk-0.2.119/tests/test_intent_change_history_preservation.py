import uuid
import respx
from soprano_sdk.core.constants import WorkflowKeys
from tests.helpers import (
    make_tool, snap, llm_structured_response, FAKE_LLM_COMPLETIONS,
    collector_prompt, collector_capture, fu_intent_change, fu_answer
)

@respx.mock
def test_intent_change_preserves_conversation_history_collect_input():
    """Verify that conversation history is preserved during intent change in CollectInputNode."""
    responses = iter([
        # step1: collect_name prompt
        llm_structured_response({
            "bot_response": "What is your name?",
            "captured": False, "name": None,
        }),
        # step1: collect_name capture
        llm_structured_response({
            "bot_response": None,
            "captured": True, "name": "John",
        }),
        # step2: collect_status prompt -> user triggers intent change to collect_name
        llm_structured_response({
            "bot_response": "What is your status?",
            "captured": False, "status": None,
            "intent_change": "collect_name",
        }),
        # step1: collect_name re-prompt
        llm_structured_response({
            "bot_response": "What is your name again?",
            "captured": False, "name": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_intent_change.yaml")
    tid = str(uuid.uuid4())

    # T1: step1 initial prompt
    tool.execute(thread_id=tid, initial_context={})

    # T2: step1 captures name -> step2 starts -> step2 triggers intent change -> rollback
    tool.execute(thread_id=tid, user_message="John", initial_context={})

    s = snap(tool, tid)
    conversations = s.get(WorkflowKeys.CONVERSATIONS, {})

    # NEW BEHAVIOR: Conversations should be preserved
    assert "name_conversation" in conversations
    assert len(conversations["name_conversation"]) > 0
    print("SUCCESS: collect_name conversation history preserved after intent change.")


@respx.mock
def test_intent_change_preserves_conversation_history_follow_up():
    """Verify that conversation history is preserved during intent change in FollowUpNode."""
    responses = iter([
        # F1: collector prompt
        collector_prompt("What is field A?"),
        # F2: collector capture -> moves to success outcome -> follow-up prompt
        collector_capture("val_a"),
        # F3: user triggers intent change from follow-up
        fu_intent_change("collect_a", "Let me help you change that."),
        # F4: back at collector prompt
        collector_prompt("Please re-enter field A."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})

    # Trigger intent change from follow-up
    tool.execute(thread_id=tid, user_message="change my answer", initial_context={})

    s = snap(tool, tid)
    conversations = s.get(WorkflowKeys.CONVERSATIONS, {})

    # 1. Primary field conversation should be preserved
    assert "field_a_conversation" in conversations
    assert len(conversations["field_a_conversation"]) > 0
    
    # 2. Follow-up conversation itself should be preserved
    # Search for a key ending in _follow_up_conversation
    fu_conv_keys = [k for k in conversations.keys() if k.endswith("_follow_up_conversation")]
    assert len(fu_conv_keys) > 0, f"Follow-up conversation missing in {list(conversations.keys())}"
    assert len(conversations[fu_conv_keys[0]]) > 0
    
    print("SUCCESS: Follow-up intent change preserved conversation history.")


@respx.mock
def test_intent_change_multi_field_preservation():
    """Verify that multiple collector node conversations are preserved during intent change."""
    responses = iter([
        collector_prompt("Name?"),
        llm_structured_response({"captured": True, "name": "John"}),
        collector_prompt("Age?"),
        llm_structured_response({"captured": True, "age": "30"}),
        # At Status, trigger intent change to Name
        llm_structured_response({
            "bot_response": "Back to name.",
            "intent_change": "collect_name",
        }),
        collector_prompt("Name again?"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_three_step_intent_change.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})  # Name prompt
    tool.execute(thread_id=tid, user_message="John", initial_context={}) # Age prompt
    tool.execute(thread_id=tid, user_message="30", initial_context={})   # Status prompt -> IC to Name
    
    s = snap(tool, tid)
    conversations = s.get(WorkflowKeys.CONVERSATIONS)
    assert conversations is not None
    
    # Current field name should be preserved and previous field age should not be preserved
    assert "name_conversation" in conversations
    assert "age_conversation" not in conversations
    assert len(conversations["name_conversation"]) == 2
    # assert len(conversations["age_conversation"]) == 1
    print("SUCCESS: Multi-field conversation history not preserved.")


@respx.mock
def test_intent_change_clears_field_values_but_preserves_history():
    """Verify that field values are cleared but history is kept."""
    responses = iter([
        collector_prompt("Name?"),
        llm_structured_response({"captured": True, "name": "John"}),
        llm_structured_response({
            "bot_response": "Back to name.",
            "intent_change": "collect_name",
        }),
        collector_prompt("Name retry?"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_three_step_intent_change.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="John", initial_context={}) # IC to Name happens here

    s = snap(tool, tid)
    
    # Field value for 'name' should be cleared (null)
    assert s.get("name") is None
    
    # History should be preserved
    conversations = s.get(WorkflowKeys.CONVERSATIONS)
    assert conversations is not None
    assert "name_conversation" in conversations
    assert len(conversations["name_conversation"]) > 0
    print("SUCCESS: Fields cleared while history preserved.")


@respx.mock
def test_intent_change_merges_with_target_conversation():
    """Verify that history is merged with existing conversation on target node."""
    responses = iter([
        collector_prompt("Name?"),
        llm_structured_response({"captured": True, "name": "John"}),
        collector_prompt("Age?"),
        # User triggers IC to Name
        llm_structured_response({
            "bot_response": "Back to name.",
            "intent_change": "collect_name",
        }),
        collector_prompt("Name again?"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_three_step_intent_change.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})  # T1: Name prompt
    tool.execute(thread_id=tid, user_message="John", initial_context={}) # T2: Age prompt
    
    # Check state before IC
    s_mid = snap(tool, tid)
    assert s_mid.get(WorkflowKeys.CONVERSATIONS) is not None
    assert len(s_mid[WorkflowKeys.CONVERSATIONS]["name_conversation"]) > 0
    
    # T3: Trigger IC to Name
    tool.execute(thread_id=tid, user_message="change name", initial_context={})
    
    s_final = snap(tool, tid)
    conversations = s_final.get(WorkflowKeys.CONVERSATIONS)
    assert conversations is not None
    conv_name = conversations["name_conversation"]
    
    # Should have merged: 
    # [Old Name messages] + [Transition Age messages]
    assert not (len(conv_name) > len(s_mid[WorkflowKeys.CONVERSATIONS]["name_conversation"]))
    print("SUCCESS: Conversation history merged correctly at target node.")


@respx.mock
def test_follow_up_intent_change_multi_turn():
    """Verify that multi-turn follow-up conversation is preserved during intent change."""
    responses = iter([
        collector_prompt("Name?"),
        llm_structured_response({"captured": True, "name": "John"}),
        # Follow-up Turn 1
        fu_answer("Follow-up Q1"),
        # Follow-up Turn 2 -> User triggers IC
        fu_intent_change("collect_name", "Okay, let's change name."),
        collector_prompt("Name retry."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="John", initial_context={}) # Moves to follow-up
    tool.execute(thread_id=tid, user_message="hello", initial_context={}) # Follow-up Q1 prompt
    
    # Trigger IC from second turn of follow-up
    tool.execute(thread_id=tid, user_message="change my answer", initial_context={})
    
    s = snap(tool, tid)
    conversations = s.get(WorkflowKeys.CONVERSATIONS)
    assert conversations is not None
    
    fu_conv_keys = [k for k in conversations.keys() if k.endswith("_follow_up_conversation")]
    assert len(fu_conv_keys) > 0
    fu_conv = conversations[fu_conv_keys[0]]
    
    # Should have multiple messages in follow-up history
    # [Agent Q1, User "hello", Agent "Okay, let's change name."]
    assert len(fu_conv) >= 3
    print("SUCCESS: Multi-turn follow-up conversation preserved.")
