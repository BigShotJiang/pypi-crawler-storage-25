"""Tests for max_attempts enforcement in the follow-up node. Covers graph termination
when attempts are exhausted, farewell message rendering, unlimited mode, schema validation,
and cleanup of tracking counters on exhaustion.
"""

import uuid

import pytest
import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    make_tool,
    snap,
)


@respx.mock
def test_exceeding_max_attempts_ends_graph_with_farewell_message():
    """When the number of follow-up turns exceeds max_attempts, the graph should terminate
    and deliver the configured farewell message rather than calling the LLM again. The
    outcome_id should be cleared from the terminal checkpoint since the follow-up ended
    abnormally via the attempts limit.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer("Answer 1."),   # attempt 1
        fu_answer("Answer 2."),   # attempt 2
        fu_answer("Answer 3."),   # attempt 3
        # No LLM call on attempt 4 — max exceeded before LLM call
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="question 1", initial_context={})
    tool.execute(thread_id=tid, user_message="question 2", initial_context={})
    tool.execute(thread_id=tid, user_message="question 3", initial_context={})

    # 4th follow-up attempt exceeds max_attempts — no LLM call
    result_max = tool.execute(thread_id=tid, user_message="one more question", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP not in str(result_max)
    assert "Max attempts reached. Goodbye." in str(result_max)
    assert s.get("_messages") == ["Max attempts reached. Goodbye."]
    assert s.get("_outcome_id") is None
    assert respx.calls.call_count == 5  # no LLM call on 4th attempt


@respx.mock
def test_within_max_attempts_keeps_follow_up_active():
    """When the number of follow-up turns is still within max_attempts, the graph should
    remain in the follow-up state and the attempt counter should reflect the number of
    completed turns. The follow-up session should not be terminated prematurely.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer("Answer 1."),
        fu_answer("Answer 2."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="question 1", initial_context={})
    result4 = tool.execute(thread_id=tid, user_message="question 2", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result4)
    assert s["_follow_up_attempts"] == 2


@respx.mock
def test_no_max_attempts_config_allows_unlimited_qa_turns():
    """When max_attempts is not configured in the workflow YAML, the follow-up session
    should allow any number of Q&A turns without ever terminating. After five consecutive
    turns the graph should still be in FOLLOW_UP with the attempt counter at 5.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("val"),
        fu_answer("Answer 1."),
        fu_answer("Answer 2."),
        fu_answer("Answer 3."),
        fu_answer("Answer 4."),
        fu_answer("Answer 5."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_unlimited_attempts.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val", initial_context={})
    for i in range(1, 6):
        result = tool.execute(thread_id=tid, user_message=f"question {i}", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result)
    assert s["_follow_up_attempts"] == 5
    assert respx.calls.call_count == 7


@respx.mock
def test_default_farewell_message_used_when_not_configured():
    """When max_attempts is exceeded but no on_max_attempts_reached message is configured,
    the SDK's default farewell message should be displayed. The graph should terminate and
    not call the LLM for the exceeded attempt.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("val"),
        fu_answer("Answer 1."),   # attempt 1 (1 not > 1, OK)
        # No LLM#4: attempt 2 > max_attempts=1 → terminated before LLM call
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_max_one_attempt.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val", initial_context={})
    tool.execute(thread_id=tid, user_message="question 1", initial_context={})

    result_max = tool.execute(thread_id=tid, user_message="question 2", initial_context={})

    assert InterruptType.FOLLOW_UP not in str(result_max)
    assert "Our conversation has ended. Thank you." in str(result_max)
    assert respx.calls.call_count == 3


def test_max_attempts_zero_rejected_by_schema_validator():
    """A workflow configured with max_attempts=0 should be rejected at startup by the
    schema validator since it would immediately terminate on the very first follow-up
    message. The validator enforces max_attempts >= 1 to ensure at least one Q&A turn.
    """
    with pytest.raises(RuntimeError, match="less than the minimum of 1"):
        make_tool("follow_up_invalid_zero_attempts.yaml")


@respx.mock
def test_max_attempts_farewell_message_rendered_as_plain_string():
    """The on_max_attempts_reached message should be rendered as a plain string in the
    result, not as a Python list representation. Storing the message in a list and then
    formatting with f-string would produce brackets and quotes visible to the user.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer("Answer 1."),  # LLM#3: Q&A turn 1
        fu_answer("Answer 2."),  # LLM#4: Q&A turn 2
        fu_answer("Answer 3."),  # LLM#5: Q&A turn 3
        # LLM#6 never called: 4th message exceeds max_attempts(3) before LLM call
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="q1", initial_context={})
    tool.execute(thread_id=tid, user_message="q2", initial_context={})
    tool.execute(thread_id=tid, user_message="q3", initial_context={})
    result6 = tool.execute(thread_id=tid, user_message="q4", initial_context={})

    # The message MUST be present (functionality check)
    assert "Max attempts reached. Goodbye." in str(result6), (
        "Expected the on_max_attempts_reached message to appear in result"
    )

    # Expected: no Python list-repr brackets/quotes around the message.
    result_str = str(result6)
    assert "['Max attempts reached" not in result_str, (
        f"on_max_attempts_reached rendered with Python list repr brackets: "
        f"'{result_str}' — the user sees [' and '] in the output"
    )
    assert result_str.count("'") == 0 or "Max attempts reached. Goodbye.'" not in result_str, (
        f"Trailing quote from list repr found in: '{result_str}'"
    )


@respx.mock
def test_max_attempts_exhaustion_clears_follow_up_active_flag():
    """When max_attempts is exhausted, the _follow_up_active flag should be cleared in
    the terminal checkpoint. A stale True value for _follow_up_active would incorrectly
    signal to downstream systems that the workflow is still in an active follow-up session.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer("Answer 1."),  # LLM#3 — T3 (attempts=1)
        fu_answer("Answer 2."),  # LLM#4 — T4 (attempts=2)
        fu_answer("Answer 3."),  # LLM#5 — T5 (attempts=3)
        # T6 never calls LLM — exhaustion path returns before invocation
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="q1", initial_context={})
    tool.execute(thread_id=tid, user_message="q2", initial_context={})
    tool.execute(thread_id=tid, user_message="q3", initial_context={})
    result6 = tool.execute(thread_id=tid, user_message="q4", initial_context={})

    assert "Max attempts reached. Goodbye." in str(result6), (
        f"Expected exhaustion message, got: '{str(result6)}'"
    )
    assert InterruptType.FOLLOW_UP not in str(result6), (
        f"FOLLOW_UP interrupt should NOT fire after exhaustion, got: '{str(result6)}'"
    )

    s = snap(tool, tid)

    assert s.get("_follow_up_active") is not True, (
        f"_follow_up_active = {s.get('_follow_up_active')!r} after "
        f"max_attempts exhaustion. The early-return path does not clear "
        f"FOLLOW_UP_ACTIVE, leaving a stale True in the terminal checkpoint. "
        f"Expected _follow_up_active to be None or False."
    )


@respx.mock
def test_qa_exhaustion_clears_follow_up_attempts_counter():
    """When Q&A max_attempts is exhausted, the _follow_up_attempts counter should be
    cleared to None in the terminal checkpoint. Leaving a stale counter value creates an
    inconsistent terminal state where _follow_up_active is None but _follow_up_attempts
    still holds the over-limit value.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid"),
        fu_answer("Answer 1."), # LLM#3 — follow-up attempt 1 (allowed)
        fu_answer("Answer 2."), # LLM#4 — follow-up attempt 2 (allowed)
        fu_answer("Answer 3."), # LLM#5 — follow-up attempt 3 (allowed; max_attempts=3 not exceeded yet)
        # No LLM#6 — T6 terminates before invoking the LLM
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid", initial_context={})
    tool.execute(thread_id=tid, user_message="q1", initial_context={})
    tool.execute(thread_id=tid, user_message="q2", initial_context={})
    tool.execute(thread_id=tid, user_message="q3", initial_context={})
    result6 = tool.execute(thread_id=tid, user_message="q4", initial_context={})

    # T6 must terminate the graph (not produce a FOLLOW_UP interrupt)
    assert InterruptType.FOLLOW_UP not in str(result6), (
        f"Expected graph to terminate after max_attempts exceeded, "
        f"got FOLLOW_UP interrupt: '{str(result6)[:200]}'"
    )

    assert "Max attempts reached. Goodbye." in str(result6), (
        f"Expected on_max_attempts_reached message in result, got: '{str(result6)[:200]}'"
    )

    s = snap(tool, tid)

    # Baseline: FOLLOW_UP_ACTIVE is correctly cleared
    assert s.get("_follow_up_active") is None, (
        f"_follow_up_active should be None after exhaustion, got: {s.get('_follow_up_active')}"
    )

    assert s.get("_follow_up_attempts") is None, (
        f"_follow_up_attempts is {s.get('_follow_up_attempts')!r} "
        f"after Q&A max_attempts exhaustion; expected None. "
        f"The termination block clears FOLLOW_UP_ACTIVE but not "
        f"FOLLOW_UP_ATTEMPTS, creating an inconsistent terminal checkpoint."
    )
