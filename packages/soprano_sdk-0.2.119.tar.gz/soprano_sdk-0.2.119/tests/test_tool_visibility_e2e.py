"""
Tests for tool-level `include_response_in_prompt` visibility control.

Covers:
  - Unit tests: ActionStrategy._filter_hidden_tools helper
  - Unit tests: CollectInputStrategy and FollowUpStrategy filtering behavior
  - Respx E2E tests: Verify hidden tool output does NOT appear in LLM request,
    while visible tool output DOES appear, and compute can still access hidden output.
"""

import os
import uuid
import json

import respx

from unittest.mock import MagicMock
from soprano_sdk.nodes.base import ActionStrategy
from soprano_sdk.nodes.collect_input import CollectInputStrategy
from soprano_sdk.nodes.follow_up import FollowUpStrategy
from soprano_sdk.core.constants import WorkflowKeys
from soprano_sdk.utils.builtin_tools import MONTY_TOOL_NAME
from tests.helpers import (
    FAKE_LLM_URL,
    FAKE_LLM_COMPLETIONS,
    make_tool,
    snap,
    llm_text_response,
    llm_structured_response,
    fu_answer,
)

os.environ["OPENAI_API_KEY"] = "test-key"
os.environ["OPENAI_API_BASE"] = FAKE_LLM_URL


# ─── Shared mock tool implementations (referenced by fixture YAMLs) ────────────

def visible_fetcher(**kwargs):
    """Returns public info — safe go show in the prompt."""
    return {"account_type": "savings", "branch": "downtown"}


def hidden_fetcher(**kwargs):
    """Returns sensitive info — should be hidden from the LLM prompt."""
    return {"pin": "1234", "ssn_last4": "6789"}


# ─── Unit: ActionStrategy._filter_hidden_tools ─────────────────────────────────

class TestFilterHiddenTools:
    """Unit tests for the base-class _filter_hidden_tools helper."""

    def _make_strategy(self, tool_defs):
        """Create a minimal concrete strategy with a mocked engine config."""
        engine = MagicMock()
        engine.config = {"tool_config": {"tools": tool_defs}}

        # Concrete subclass to instantiate the abstract base
        class ConcreteStrategy(ActionStrategy):
            def execute(self, state): pass
            def pre_execute(self, state): pass

        return ConcreteStrategy({"id": "test", "action": "collect_input_with_agent"}, engine)

    def test_visible_tools_are_kept(self):
        strategy = self._make_strategy([
            {"name": "tool_a", "description": "x", "callable": "m.f", "include_response_in_prompt": True},
            {"name": "tool_b", "description": "x", "callable": "m.f", "include_response_in_prompt": True},
        ])
        result = strategy._filter_hidden_tools({"tool_a", "tool_b"})
        assert result == {"tool_a", "tool_b"}

    def test_hidden_tool_is_removed(self):
        strategy = self._make_strategy([
            {"name": "visible", "description": "x", "callable": "m.f", "include_response_in_prompt": True},
            {"name": "hidden", "description": "x", "callable": "m.f", "include_response_in_prompt": False},
        ])
        result = strategy._filter_hidden_tools({"visible", "hidden"})
        assert "visible" in result
        assert "hidden" not in result

    def test_defaults_to_visible_when_flag_absent(self):
        """Tools with no include_response_in_prompt should be treated as visible."""
        strategy = self._make_strategy([
            {"name": "no_flag_tool", "description": "x", "callable": "m.f"},
        ])
        result = strategy._filter_hidden_tools({"no_flag_tool"})
        assert "no_flag_tool" in result

    def test_empty_tool_set_returns_empty(self):
        strategy = self._make_strategy([
            {"name": "hidden", "description": "x", "callable": "m.f", "include_response_in_prompt": False},
        ])
        result = strategy._filter_hidden_tools(set())
        assert result == set()

    def test_no_engine_config_returns_all(self):
        """If engine has no config attr, all tools pass through unchanged."""
        engine = MagicMock(spec=[])  # spec=[] means no attributes at all

        class ConcreteStrategy(ActionStrategy):
            def execute(self, state): pass
            def pre_execute(self, state): pass

        strategy = ConcreteStrategy({"id": "t", "action": "collect_input_with_agent"}, engine)
        result = strategy._filter_hidden_tools({"tool_x", "tool_y"})
        assert result == {"tool_x", "tool_y"}

    def test_tools_not_in_available_set_are_ignored(self):
        """Tools defined in config but not in available_tools should not affect result."""
        strategy = self._make_strategy([
            {"name": "in_config_only", "description": "x", "callable": "m.f", "include_response_in_prompt": False},
        ])
        result = strategy._filter_hidden_tools({"not_in_config"})
        # tool from config not present in available_tools → shouldn't remove anything
        assert "not_in_config" in result



# ─── Unit: CollectInputStrategy prompt filtering ────────────────────────────────

class TestCollectInputPromptFiltering:
    """Unit tests for include_response_in_prompt in CollectInputStrategy._get_instructions."""

    def _make_strategy(self, tool_names, tool_defs):
        engine = MagicMock()
        engine.config = {"tool_config": {"tools": tool_defs}}
        config = {
            "field": "some_field",
            "agent": {
                "name": "TestAgent",
                "instructions": "Do stuff",
                "tools": tool_names,
            },
        }
        return CollectInputStrategy(config, engine)

    def test_visible_tool_response_appears_in_instructions(self):
        strategy = self._make_strategy(
            tool_names=["visible_tool"],
            tool_defs=[{"name": "visible_tool", "description": "v", "callable": "m.f", "include_response_in_prompt": True}],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "visible_tool": {"input": {"x": 1}, "output": "visible data"}
            }
        }
        instructions = strategy._get_instructions(state, {})
        assert "visible_tool" in instructions
        assert "visible data" in instructions

    def test_hidden_tool_response_absent_from_instructions(self):
        strategy = self._make_strategy(
            tool_names=["hidden_tool"],
            tool_defs=[{"name": "hidden_tool", "description": "h", "callable": "m.f", "include_response_in_prompt": False}],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "hidden_tool": {"input": {}, "output": "secret data"}
            }
        }
        instructions = strategy._get_instructions(state, {})
        assert "hidden_tool" not in instructions
        assert "secret data" not in instructions

    def test_mixed_tools_show_only_visible(self):
        strategy = self._make_strategy(
            tool_names=["visible_tool", "hidden_tool"],
            tool_defs=[
                {"name": "visible_tool", "description": "v", "callable": "m.f", "include_response_in_prompt": True},
                {"name": "hidden_tool", "description": "h", "callable": "m.f", "include_response_in_prompt": False},
            ],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "visible_tool": {"input": {}, "output": "public info"},
                "hidden_tool": {"input": {}, "output": "private info"},
            }
        }
        instructions = strategy._get_instructions(state, {})
        assert "visible_tool" in instructions
        assert "public info" in instructions
        assert "hidden_tool" not in instructions
        assert "private info" not in instructions

    def test_show_tool_responses_false_overrides_all(self):
        """When show_tool_responses is False, no tool history is injected regardless of per-tool flags."""
        engine = MagicMock()
        engine.config = {
            "tool_config": {"tools": [
                {"name": "visible_tool", "description": "v", "callable": "m.f", "include_response_in_prompt": True},
            ]}
        }
        config = {
            "field": "f",
            "agent": {
                "name": "A",
                "instructions": "Do stuff",
                "tools": ["visible_tool"],
                "show_tool_responses": False,
            },
        }
        strategy = CollectInputStrategy(config, engine)
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "visible_tool": {"input": {}, "output": "even visible is suppressed"}
            }
        }
        instructions = strategy._get_instructions(state, {})
        assert "visible_tool" not in instructions
        assert "even visible is suppressed" not in instructions


# ─── Unit: FollowUpStrategy prompt filtering ───────────────────────────────────

class TestFollowUpPromptFiltering:
    """Unit tests for include_response_in_prompt in FollowUpStrategy._build_tool_responses."""

    def _make_strategy(self, tool_names, tool_defs, show_responses=True):
        engine = MagicMock()
        engine.config = {"tool_config": {"tools": tool_defs}}
        config = {
            "tools": tool_names,
            "show_tool_responses": show_responses,
        }
        return FollowUpStrategy(config, engine_context=engine, first_step_id="start")

    def test_visible_tool_in_responses_block(self):
        strategy = self._make_strategy(
            tool_names=["visible_tool"],
            tool_defs=[{"name": "visible_tool", "description": "v", "callable": "m.f", "include_response_in_prompt": True}],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "visible_tool": {"input": {"q": 1}, "output": "public"}
            }
        }
        block = strategy._build_tool_responses(state)
        assert "visible_tool" in block
        assert "public" in block

    def test_hidden_tool_absent_from_responses_block(self):
        strategy = self._make_strategy(
            tool_names=["hidden_tool"],
            tool_defs=[{"name": "hidden_tool", "description": "h", "callable": "m.f", "include_response_in_prompt": False}],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "hidden_tool": {"input": {}, "output": "classified"}
            }
        }
        block = strategy._build_tool_responses(state)
        assert "hidden_tool" not in block
        assert "classified" not in block

    def test_show_tool_responses_false_returns_empty_string(self):
        strategy = self._make_strategy(
            tool_names=["visible_tool"],
            tool_defs=[{"name": "visible_tool", "description": "v", "callable": "m.f", "include_response_in_prompt": True}],
            show_responses=False,
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "visible_tool": {"input": {}, "output": "suppressed"}
            }
        }
        block = strategy._build_tool_responses(state)
        assert block == ""

    def test_no_tool_history_returns_empty_string(self):
        strategy = self._make_strategy(tool_names=["visible_tool"], tool_defs=[
            {"name": "visible_tool", "description": "v", "callable": "m.f", "include_response_in_prompt": True},
        ])
        block = strategy._build_tool_responses({})
        assert block == ""


# ─── Respx E2E: collect_input tool visibility ──────────────────────────────────

@respx.mock
def test_respx_collect_input_tool_state_recording_and_visibility():
    """
    E2E: Both visible and hidden tools run and are recorded in state.
    - visible_fetcher is listed in tool_responses state with correct output.
    - hidden_fetcher is also in tool_responses state (always recorded), but
      `include_response_in_prompt: false` means it won't appear in LangGraph
      prompt injections (unit tests cover that path).
    - compute tool can access hidden_fetcher output via hidden_fetcher_response.
    """
    responses = iter([
        # Turn 1: agent calls visible_fetcher
        llm_text_response(
            "Thought: Let me get visible data.\n"
            "Action: visible_fetcher\n"
            "Action Input: {}"
        ),
        # Turn 2: agent calls hidden_fetcher
        llm_text_response(
            "Thought: Now let me get hidden data.\n"
            "Action: hidden_fetcher\n"
            "Action Input: {}"
        ),
        # Turn 3: agent uses compute to access hidden data indirectly
        llm_text_response(
            "Thought: Accessing hidden data via compute.\n"
            "Action: compute\n"
            'Action Input: {"code": "str(hidden_fetcher_response)"}'
        ),
        # Turn 4: final answer
        llm_text_response("Final Answer: RESULT: all done"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tid = str(uuid.uuid4())
    tool = make_tool("tool_visibility_collect_input.yaml")
    result = tool.execute(thread_id=tid, user_message="Start", initial_context={})

    assert "Done" in str(result)

    # State should record BOTH tool responses under _tool_responses
    state = snap(tool, tid)
    tool_responses = state.get(WorkflowKeys.TOOL_RESPONSES, {})

    # visible_fetcher: recorded in state with correct output
    assert "visible_fetcher" in tool_responses
    assert tool_responses["visible_fetcher"]["output"]["account_type"] == "savings"
    assert tool_responses["visible_fetcher"]["output"]["branch"] == "downtown"

    # hidden_fetcher: also recorded in state (always captured regardless of prompt visibility)
    assert "hidden_fetcher" in tool_responses
    assert tool_responses["hidden_fetcher"]["output"]["pin"] == "1234"
    assert tool_responses["hidden_fetcher"]["output"]["ssn_last4"] == "6789"

    # compute was also captured (confirms it ran successfully using hidden_fetcher_response)
    assert "compute" in tool_responses


@respx.mock
def test_respx_collect_input_hidden_tool_accessible_via_compute():
    """
    E2E: Even when hidden_fetcher is not in the prompt, compute can still access
    its output via 'hidden_fetcher_response'.
    """
    responses = iter([
        llm_text_response(
            "Thought: Let me fetch hidden data.\n"
            "Action: hidden_fetcher\n"
            "Action Input: {}"
        ),
        llm_text_response(
            "Thought: Access it via compute.\n"
            "Action: compute\n"
            'Action Input: {"code": "hidden_fetcher_response[\'pin\']"}'
        ),
        llm_text_response("Final Answer: RESULT: pin is 1234"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tid = str(uuid.uuid4())
    tool = make_tool("tool_visibility_collect_input.yaml")
    tool.execute(thread_id=tid, user_message="Get hidden data", initial_context={})

    # The hidden_fetcher response must be in state even though not visible in prompt
    state = snap(tool, tid)
    tool_responses = state.get(WorkflowKeys.TOOL_RESPONSES, {})
    assert "hidden_fetcher" in tool_responses
    assert tool_responses["hidden_fetcher"]["output"]["pin"] == "1234"
    # Compute tool response should also be captured in state
    assert "compute" in tool_responses


# ─── Respx E2E: follow_up tool visibility ──────────────────────────────────────

@respx.mock
def test_respx_follow_up_visible_tool_in_request_hidden_absent():
    """
    E2E follow_up: After collection, trigger follow-up Q&A.
    The follow-up node's LLM request should contain visible_fetcher output
    but NOT hidden_fetcher output.
    """
    # Simulate: pre-populated tool responses in state
    state_tool_responses = {
        "visible_fetcher": {"input": {}, "output": {"account_type": "savings", "branch": "downtown"}},
        "hidden_fetcher": {"input": {}, "output": {"pin": "1234", "ssn_last4": "6789"}},
    }

    # Step 1: collector captures field_a
    collector_resp = llm_structured_response({"bot_response": None, "field_a": "myvalue"})
    # Step 2: follow-up answers a question
    fu_resp = fu_answer("Your account type is savings.")

    responses = iter([collector_resp, fu_resp])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tid = str(uuid.uuid4())
    tool = make_tool("tool_visibility_follow_up.yaml")

    # Pre-populate tool responses in the initial context to simulate tools having run
    tool.execute(
        thread_id=tid,
        user_message="myvalue",
        initial_context={WorkflowKeys.TOOL_RESPONSES: state_tool_responses},
    )

    # Now send a follow-up message
    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=fu_answer("Your branch is downtown."))
    tool.execute(thread_id=tid, user_message="What is my branch?")

    # Find the follow-up LLM call — the last one
    last_call_body = json.loads(respx.calls[-1].request.content)
    system_prompt = next(
        (m["content"] for m in last_call_body.get("messages", []) if m["role"] == "system"),
        ""
    )
    # visible_fetcher output should be in the follow-up prompt
    assert "savings" in system_prompt or "downtown" in system_prompt
    # hidden_fetcher should NOT be in the follow-up prompt
    assert "1234" not in system_prompt
    assert "6789" not in system_prompt


# ─── Extended unit tests: _filter_hidden_tools edge cases ──────────────────────

class TestFilterHiddenToolsExtended:
    """Additional edge-case tests for _filter_hidden_tools."""

    def _make_strategy(self, tool_defs):
        engine = MagicMock()
        engine.config = {"tool_config": {"tools": tool_defs}}

        class ConcreteStrategy(ActionStrategy):
            def execute(self, state): pass
            def pre_execute(self, state): pass

        return ConcreteStrategy({"id": "test", "action": "collect_input_with_agent"}, engine)

    def test_all_tools_hidden_returns_empty_set(self):
        """When every tool is marked hidden, result is an empty set."""
        strategy = self._make_strategy([
            {"name": "a", "description": "x", "callable": "m.f", "include_response_in_prompt": False},
            {"name": "b", "description": "x", "callable": "m.f", "include_response_in_prompt": False},
            {"name": "c", "description": "x", "callable": "m.f", "include_response_in_prompt": False},
        ])
        result = strategy._filter_hidden_tools({"a", "b", "c"})
        assert result == set()

    def test_empty_tool_config_list_returns_all_unchanged(self):
        """If tool_config.tools is an empty list, all tools pass through."""
        engine = MagicMock()
        engine.config = {"tool_config": {"tools": []}}

        class ConcreteStrategy(ActionStrategy):
            def execute(self, state): pass
            def pre_execute(self, state): pass

        strategy = ConcreteStrategy({"id": "t", "action": "collect_input_with_agent"}, engine)
        result = strategy._filter_hidden_tools({"tool_a", "tool_b"})
        assert result == {"tool_a", "tool_b"}

    def test_tool_not_in_tool_config_defaults_to_visible(self):
        """A tool in available_tools but absent from tool_config.tools is treated as visible."""
        strategy = self._make_strategy([
            {"name": "known_hidden", "description": "x", "callable": "m.f", "include_response_in_prompt": False},
        ])
        result = strategy._filter_hidden_tools({"unknown_tool", "known_hidden"})
        assert "unknown_tool" in result   # not in config → treated as visible
        assert "known_hidden" not in result


# ─── Extended unit tests: CollectInputStrategy ─────────────────────────────────

class TestCollectInputPromptFilteringExtended:
    """Additional tests for CollectInputStrategy's tool injection logic."""

    def _make_strategy(self, tool_names, tool_defs, extra_agent_cfg=None):
        engine = MagicMock()
        engine.config = {"tool_config": {"tools": tool_defs}}
        agent_cfg = {
            "name": "TestAgent",
            "instructions": "Do stuff",
            "tools": tool_names,
        }
        if extra_agent_cfg:
            agent_cfg.update(extra_agent_cfg)
        config = {"field": "some_field", "agent": agent_cfg}
        return CollectInputStrategy(config, engine)

    def test_all_tools_hidden_no_tool_block(self):
        """When every tool is hidden, the <tool_responses> block is absent."""
        strategy = self._make_strategy(
            tool_names=["hidden_a", "hidden_b"],
            tool_defs=[
                {"name": "hidden_a", "description": "h", "callable": "m.f", "include_response_in_prompt": False},
                {"name": "hidden_b", "description": "h", "callable": "m.f", "include_response_in_prompt": False},
            ],
            extra_agent_cfg={"default_tools": False},
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "hidden_a": {"input": {}, "output": "secret_a"},
                "hidden_b": {"input": {}, "output": "secret_b"},
            }
        }
        instructions = strategy._get_instructions(state, {})
        assert "<tool_responses>" not in instructions
        assert "secret_a" not in instructions
        assert "secret_b" not in instructions

    def test_tool_in_config_but_not_called_is_skipped(self):
        """A tool that's available but has no entry in _tool_responses is silently skipped."""
        strategy = self._make_strategy(
            tool_names=["tool_a", "tool_b"],
            tool_defs=[
                {"name": "tool_a", "description": "x", "callable": "m.f", "include_response_in_prompt": True},
                {"name": "tool_b", "description": "x", "callable": "m.f", "include_response_in_prompt": True},
            ],
        )
        # Only tool_a was actually called
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "tool_a": {"input": {}, "output": "result_a"},
            }
        }
        instructions = strategy._get_instructions(state, {})
        assert "tool_a" in instructions
        assert "result_a" in instructions
        assert "tool_b" not in instructions  # not called → not shown

    def test_compute_hint_uses_single_quotes_around_tool_name(self):
        """The compute access hint uses the 'tool_name' (with single quotes) format."""
        strategy = self._make_strategy(
            tool_names=["my_tool"],
            tool_defs=[
                {"name": "my_tool", "description": "x", "callable": "m.f", "include_response_in_prompt": True},
            ],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "my_tool": {"input": {}, "output": "result"}
            }
        }
        instructions = strategy._get_instructions(state, {})
        # The hint must quote the tool name
        assert f"The output of 'my_tool' can be accessed in the {MONTY_TOOL_NAME} tool" in instructions
        assert "my_tool_response" in instructions

    def test_hidden_tool_compute_hint_also_absent(self):
        """Hidden tools must not have their compute hint injected either."""
        strategy = self._make_strategy(
            tool_names=["hidden_tool", "visible_tool"],
            tool_defs=[
                {"name": "hidden_tool", "description": "h", "callable": "m.f", "include_response_in_prompt": False},
                {"name": "visible_tool", "description": "v", "callable": "m.f", "include_response_in_prompt": True},
            ],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "hidden_tool": {"input": {}, "output": "secret"},
                "visible_tool": {"input": {}, "output": "public"},
            }
        }
        instructions = strategy._get_instructions(state, {})
        # visible tool compute hint is present
        assert "visible_tool_response" in instructions
        # hidden tool compute hint must be completely absent
        assert "hidden_tool_response" not in instructions

    def test_malformed_tool_data_without_output_key_is_skipped(self):
        """Tool entries missing 'output' key are silently skipped (no crash)."""
        strategy = self._make_strategy(
            tool_names=["broken_tool"],
            tool_defs=[
                {"name": "broken_tool", "description": "x", "callable": "m.f", "include_response_in_prompt": True},
            ],
        )
        # Missing 'output' key — should not raise
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "broken_tool": {"input": {}}  # no 'output' key
            }
        }
        instructions = strategy._get_instructions(state, {})
        # Should not crash and should not emit a malformed entry
        assert "broken_tool" not in instructions

    def test_empty_tool_responses_state_produces_no_block(self):
        """If _tool_responses is present but empty, no block is injected."""
        strategy = self._make_strategy(
            tool_names=["visible_tool"],
            tool_defs=[
                {"name": "visible_tool", "description": "v", "callable": "m.f", "include_response_in_prompt": True},
            ],
        )
        state = {WorkflowKeys.TOOL_RESPONSES: {}}
        instructions = strategy._get_instructions(state, {})
        assert "<tool_responses>" not in instructions


# ─── Extended unit tests: FollowUpStrategy ─────────────────────────────────────

class TestFollowUpPromptFilteringExtended:
    """Additional tests for FollowUpStrategy._build_tool_responses logic."""

    def _make_strategy(self, tool_names, tool_defs, show_responses=True):
        engine = MagicMock()
        engine.config = {"tool_config": {"tools": tool_defs}}
        config = {"tools": tool_names, "show_tool_responses": show_responses}
        return FollowUpStrategy(config, engine_context=engine, first_step_id="start")

    def test_all_tools_hidden_returns_empty_string(self):
        """When all tools are hidden, _build_tool_responses returns empty string."""
        strategy = self._make_strategy(
            tool_names=["hidden_a", "hidden_b"],
            tool_defs=[
                {"name": "hidden_a", "description": "h", "callable": "m.f", "include_response_in_prompt": False},
                {"name": "hidden_b", "description": "h", "callable": "m.f", "include_response_in_prompt": False},
            ],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "hidden_a": {"input": {}, "output": "classified_a"},
                "hidden_b": {"input": {}, "output": "classified_b"},
            }
        }
        block = strategy._build_tool_responses(state)
        assert block == ""

    def test_tool_in_state_but_not_in_available_tools_is_skipped(self):
        """Tools in _tool_responses but NOT in node's tools list are not rendered."""
        strategy = self._make_strategy(
            tool_names=["allowed_tool"],
            tool_defs=[
                {"name": "allowed_tool", "description": "a", "callable": "m.f", "include_response_in_prompt": True},
            ],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "allowed_tool": {"input": {}, "output": "allowed_result"},
                "other_tool": {"input": {}, "output": "should_not_appear"},  # not in tools list
            }
        }
        block = strategy._build_tool_responses(state)
        assert "allowed_tool" in block
        assert "allowed_result" in block
        assert "other_tool" not in block
        assert "should_not_appear" not in block

    def test_compute_hint_uses_single_quotes_around_tool_name(self):
        """The compute hint format must quote the tool name with single quotes."""
        strategy = self._make_strategy(
            tool_names=["my_tool", MONTY_TOOL_NAME],
            tool_defs=[
                {"name": "my_tool", "description": "x", "callable": "m.f", "include_response_in_prompt": True},
            ],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "my_tool": {"input": {}, "output": "result"}
            }
        }
        block = strategy._build_tool_responses(state)
        assert f"The output of 'my_tool' can be accessed in the {MONTY_TOOL_NAME} tool" in block
        assert "my_tool_response" in block

    def test_hidden_tool_compute_hint_also_absent(self):
        """Hidden tools must not have compute hints either."""
        strategy = self._make_strategy(
            tool_names=["visible_tool", "hidden_tool", MONTY_TOOL_NAME],
            tool_defs=[
                {"name": "visible_tool", "description": "v", "callable": "m.f", "include_response_in_prompt": True},
                {"name": "hidden_tool", "description": "h", "callable": "m.f", "include_response_in_prompt": False},
            ],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "visible_tool": {"input": {}, "output": "public"},
                "hidden_tool": {"input": {}, "output": "classified"},
            }
        }
        block = strategy._build_tool_responses(state)
        assert "visible_tool_response" in block
        assert "hidden_tool_response" not in block

    def test_malformed_tool_data_without_output_key_is_skipped(self):
        """Tool entries with no 'output' key are silently skipped."""
        strategy = self._make_strategy(
            tool_names=["broken_tool"],
            tool_defs=[
                {"name": "broken_tool", "description": "x", "callable": "m.f", "include_response_in_prompt": True},
            ],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "broken_tool": {"input": {}}  # missing 'output'
            }
        }
        block = strategy._build_tool_responses(state)
        assert block == ""

    def test_tool_responses_none_in_state_returns_empty(self):
        """If _tool_responses key is None (not just absent), returns empty string."""
        strategy = self._make_strategy(
            tool_names=["my_tool"],
            tool_defs=[
                {"name": "my_tool", "description": "x", "callable": "m.f", "include_response_in_prompt": True},
            ],
        )
        block = strategy._build_tool_responses({WorkflowKeys.TOOL_RESPONSES: None})
        assert block == ""

    def test_header_only_present_when_entries_exist(self):
        """The 'The following tools have already been called' header only appears when there's content."""
        strategy = self._make_strategy(
            tool_names=["hidden_tool"],
            tool_defs=[
                {"name": "hidden_tool", "description": "h", "callable": "m.f", "include_response_in_prompt": False},
            ],
        )
        state = {
            WorkflowKeys.TOOL_RESPONSES: {
                "hidden_tool": {"input": {}, "output": "classified"}
            }
        }
        block = strategy._build_tool_responses(state)
        # No entries means no header either
        assert "The following tools have already been called" not in block
        assert block == ""
