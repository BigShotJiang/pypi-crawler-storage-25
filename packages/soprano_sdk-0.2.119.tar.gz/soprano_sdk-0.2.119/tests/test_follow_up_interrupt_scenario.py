import uuid
import respx
from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    make_tool,
    snap,
)

def _get_val(state, key):
    """Helper to extract value from potentially nested structured output dict."""
    val = state.get(key)
    if isinstance(val, dict) and key in val:
        return val[key]
    return val

@respx.mock
def test_follow_up_interrupt_after_three_functions_failure():
    """ Verify follow-up node interrupt after 1 collector -> 3 functions -> failure outcome. """
    responses = iter([
        collector_prompt("Please provide A."),          # LLM#1: collect_a prompt
        collector_capture("val_a"),                    # LLM#2: collect_a capture
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_three_func_failure.yaml")
    tid = str(uuid.uuid4())

    # 1. Entry -> collect_a prompt
    res1 = tool.execute(thread_id=tid, initial_context={})
    assert "Please provide A." in str(res1)
    assert InterruptType.USER_INPUT in str(res1)

    # 2. Provide A -> Transitions through func_1, func_2, func_3 -> end_failed -> FOLLOW_UP interrupt
    # OutcomeNode sets FOLLOW_UP_ACTIVE and returns normally.
    # The FollowUpNode then fires the interrupt.
    res2 = tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    
    assert "Workflow failed at the end of functions." in str(res2)
    assert InterruptType.FOLLOW_UP in str(res2)
    
    s = snap(tool, tid)
    assert _get_val(s, "field_a") == "val_a"
    assert s.get("computed_1") == "computed_set"
    assert s.get("computed_2") == "computed_set"
    assert s.get("computed_3") == "error_set"
    assert s.get("error") == "Something went wrong"
    assert s.get("_follow_up_active") is True
    assert s.get("_follow_up_pending_prompt") is not None


@respx.mock
def test_follow_up_interrupt_after_middle_function_error():
    """ Verify behavior when middle function (func_2) sets an error. """
    responses = iter([
        collector_prompt("Please provide A."),
        collector_capture("val_a"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_middle_func_error.yaml")
    tid = str(uuid.uuid4())

    # 1. Entry -> collect_a prompt
    tool.execute(thread_id=tid, initial_context={})

    # Provide A -> Transitions through func_1 -> func_2 (errors)
    res2 = tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    
    # User expects both tests to behave the same, I'll update the assertions to expect a follow-up
    # even though currently it might be hitting END.
    assert "Workflow failed at the end of functions." in str(res2)
    assert InterruptType.FOLLOW_UP in str(res2)
    
    s = snap(tool, tid)
    assert _get_val(s, "field_a") == "val_a"
    assert s.get("computed_1") == "computed_set"
    assert s.get("computed_2") == "error_set"
    assert s.get("error") == "Something went wrong"
    assert s.get("_follow_up_active") is True


@respx.mock
def test_follow_up_interrupt_no_next_no_match():
    """ Verify behavior when no transitions match and no 'next' is provided. """
    responses = iter([
        collector_prompt("Please provide A."),
        collector_capture("val_a"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_routing_err_no_match.yaml")
    tid = str(uuid.uuid4())

    # 1. Entry -> collect_a prompt
    tool.execute(thread_id=tid, initial_context={})

    # 2. Provide A -> Transitions to func_no_next (returns None, no match)
    res2 = tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    
    # User expects both tests to behave the same, so I'll assert a follow-up interrupt
    assert "Unable to complete the request" in str(res2)
    assert InterruptType.FOLLOW_UP in str(res2)
    
    s = snap(tool, tid)
    assert _get_val(s, "field_a") == "val_a"
    assert s.get("computed_1") is None
    assert s.get("_follow_up_active") is True
