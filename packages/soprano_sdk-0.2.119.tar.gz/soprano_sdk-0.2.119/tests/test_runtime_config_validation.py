"""Tests for runtime config schema validation (engine.py fix).

After the fix in engine.py, runtime overrides to YAML-schema keys are
re-validated via validate_workflow() after _deep_merge_config() is applied.
This ensures invalid runtime values raise RuntimeError at WorkflowTool()
construction time, with the same error quality as YAML validation.

Negative tests: invalid runtime values MUST raise RuntimeError.
Positive tests: valid runtime overrides still work exactly as before.
"""

import pytest

from tests.helpers import CapturingCheckpointer, FIXTURES, MODEL_CONFIG
from soprano_sdk.tools import WorkflowTool


def _make(yaml_name: str, extra: dict = None) -> WorkflowTool:
    config = {"model_config": MODEL_CONFIG, **(extra or {})}
    return WorkflowTool(
        yaml_path=str(FIXTURES / yaml_name),
        name="test",
        description="test",
        checkpointer=CapturingCheckpointer(),
        config=config,
    )


# ===========================================================================
# NEGATIVE TESTS: Invalid runtime overrides now raise RuntimeError
# ===========================================================================

class TestRuntimeValidationEnforced:
    """Invalid runtime overrides must be rejected at WorkflowTool() construction time."""

    def test_max_attempts_above_schema_maximum_raises(self):
        """steps[].max_attempts > 20 violates schema maximum: 20.

        Previously bypassed silently; now raises RuntimeError at construction.
        """
        with pytest.raises(RuntimeError, match="Validation failed|Schema validation error|maximum"):
            _make("follow_up_single_step.yaml", {
                "steps": [{"id": "collect_a", "max_attempts": 999}]
            })

    def test_max_attempts_below_schema_minimum_raises(self):
        """steps[].max_attempts < 1 violates schema minimum: 1."""
        with pytest.raises(RuntimeError, match="Validation failed|Schema validation error|minimum"):
            _make("follow_up_single_step.yaml", {
                "steps": [{"id": "collect_a", "max_attempts": 0}]
            })

    def test_timeout_above_schema_maximum_raises(self):
        """steps[].timeout > 600 violates schema maximum: 600."""
        with pytest.raises(RuntimeError, match="Validation failed|Schema validation error|maximum"):
            _make("follow_up_single_step.yaml", {
                "steps": [{"id": "collect_a", "timeout": 9999}]
            })

    def test_timeout_below_schema_minimum_raises(self):
        """steps[].timeout < 1 violates schema minimum: 1."""
        with pytest.raises(RuntimeError, match="Validation failed|Schema validation error|minimum"):
            _make("follow_up_single_step.yaml", {
                "steps": [{"id": "collect_a", "timeout": 0}]
            })

    def test_follow_up_max_attempts_below_minimum_raises(self):
        """follow_up.max_attempts < 1 violates schema minimum: 1."""
        with pytest.raises(RuntimeError, match="Validation failed|Schema validation error|minimum"):
            _make("follow_up_single_step.yaml", {
                "follow_up": {"max_attempts": -5}
            })

    def test_steps_next_unknown_target_raises(self):
        """steps[].next referencing a non-existent step/outcome ID must raise.

        The validator cross-checks transitions against the known step_ids ∪ outcome_ids.
        """
        with pytest.raises(RuntimeError, match="Validation failed|unknown target|nonexistent_target"):
            _make("follow_up_single_step.yaml", {
                "steps": [{"id": "collect_a", "next": "nonexistent_target"}]
            })

    def test_steps_transition_unknown_next_raises(self):
        """steps[].transitions[].next referencing an unknown target must raise."""
        with pytest.raises(RuntimeError, match="Validation failed|unknown target"):
            _make("follow_up_single_step.yaml", {
                "steps": [{
                    "id": "collect_a",
                    "transitions": [{"match": "fail_val", "ref": "field_a", "next": "ghost_outcome"}],
                }]
            })

    def test_outcomes_type_invalid_enum_raises(self):
        """outcomes[].type must be in ['success', 'failure', 'redirect'].

        Runtime passing an invalid type must now be rejected.
        """
        with pytest.raises(RuntimeError, match="Validation failed|Schema validation error|not valid"):
            _make("follow_up_single_step.yaml", {
                "outcomes": [{"id": "outcome_success", "type": "invalid_type"}]
            })

    def test_data_field_type_invalid_enum_raises(self):
        """data[].type must be in ['text', 'number', 'boolean', 'list', 'dict', 'double']."""
        with pytest.raises(RuntimeError, match="Validation failed|Schema validation error|not valid"):
            _make("follow_up_single_step.yaml", {
                "data": [{"name": "field_a", "type": "bad_type", "description": "Test"}]
            })

    def test_steps_field_references_unknown_data_field_raises(self):
        """steps[].field referencing a field not in data[] must raise.

        The cross-validator (_validate_data_fields) checks field references.
        """
        with pytest.raises(RuntimeError, match="Validation failed|unknown field|ghost_field"):
            _make("follow_up_single_step.yaml", {
                "steps": [{"id": "collect_a", "field": "ghost_field"}]
            })

    def test_steps_action_invalid_enum_raises(self):
        """steps[].action must be one of the valid enum values."""
        with pytest.raises(RuntimeError, match="Validation failed|Schema validation error|not valid|is not valid"):
            _make("follow_up_single_step.yaml", {
                "steps": [{"id": "collect_a", "action": "invalid_action_type"}]
            })

    def test_inputs_references_unknown_field_raises(self):
        """inputs[] containing a field name not defined in data[] must raise.

        The _validate_input_fields() cross-checker now runs on the merged config.
        """
        with pytest.raises(RuntimeError, match="Validation failed|not defined in data"):
            _make("follow_up_single_step.yaml", {
                "inputs": ["field_a", "nonexistent_field_xyz"]
            })

    def test_mfa_max_attempts_above_maximum_raises(self):
        """steps[].mfa.max_attempts > 20 violates schema maximum: 20."""
        with pytest.raises(RuntimeError, match="Validation failed|Schema validation error|maximum"):
            _make("so_bool_transition.yaml", {
                "steps": [{
                    "id": "collect_form",
                    "mfa": {
                        "type": "REST",
                        "payload": {"action": "send_otp"},
                        "max_attempts": 999,
                    }
                }]
            })


# ===========================================================================
# POSITIVE TESTS: Valid runtime overrides still succeed
# ===========================================================================

class TestRuntimeValidationAllowsValid:
    """Valid runtime overrides at schema boundary values must still succeed."""

    def test_max_attempts_at_schema_maximum_allowed(self):
        """steps[].max_attempts = 20 (schema maximum) is valid."""
        tool = _make("follow_up_single_step.yaml", {
            "steps": [{"id": "collect_a", "max_attempts": 20}]
        })
        steps = {s["id"]: s for s in tool.engine.steps}
        assert steps["collect_a"]["max_attempts"] == 20

    def test_max_attempts_at_schema_minimum_allowed(self):
        """steps[].max_attempts = 1 (schema minimum) is valid."""
        tool = _make("follow_up_single_step.yaml", {
            "steps": [{"id": "collect_a", "max_attempts": 1}]
        })
        steps = {s["id"]: s for s in tool.engine.steps}
        assert steps["collect_a"]["max_attempts"] == 1

    def test_timeout_at_schema_maximum_allowed(self):
        """steps[].timeout = 600 (schema maximum) is valid."""
        tool = _make("follow_up_single_step.yaml", {
            "steps": [{"id": "collect_a", "timeout": 600}]
        })
        steps = {s["id"]: s for s in tool.engine.steps}
        assert steps["collect_a"]["timeout"] == 600

    def test_valid_next_target_still_works(self):
        """steps[].next pointing to an existing outcome ID is valid."""
        tool = _make("follow_up_single_step.yaml", {
            "steps": [{"id": "collect_a", "next": "outcome_failure"}]
        })
        steps = {s["id"]: s for s in tool.engine.steps}
        assert steps["collect_a"]["next"] == "outcome_failure"

    def test_data_field_type_all_valid_enums_work(self):
        """data[].type accepts all valid enum values at runtime."""
        for valid_type in ["text", "number", "boolean", "list", "dict", "double"]:
            tool = _make("follow_up_single_step.yaml", {
                "data": [{"name": "field_a", "type": valid_type, "description": "Test"}]
            })
            data = {f["name"]: f for f in tool.engine.data_fields}
            assert data["field_a"]["type"] == valid_type, f"Type '{valid_type}' should be accepted"

    def test_outcomes_type_all_valid_enums_work(self):
        """outcomes[].type accepts all valid enum values at runtime."""
        for valid_type, redirect_to in [("success", None), ("failure", None), ("redirect", "target")]:
            override = {"id": "outcome_success", "type": valid_type}
            if redirect_to:
                override["redirect_to"] = redirect_to
            tool = _make("follow_up_single_step.yaml", {"outcomes": [override]})
            outcomes = {o["id"]: o for o in tool.engine.outcomes}
            assert outcomes["outcome_success"]["type"] == valid_type

    def test_follow_up_max_attempts_at_minimum_allowed(self):
        """follow_up.max_attempts = 1 is valid."""
        tool = _make("follow_up_single_step.yaml", {"follow_up": {"max_attempts": 1}})
        assert tool.engine.follow_up_config["max_attempts"] == 1

    def test_no_runtime_overrides_still_validates_cleanly(self):
        """WorkflowTool with no runtime YAML-schema overrides validates cleanly."""
        tool = _make("follow_up_single_step.yaml")  # only model_config, no schema overrides
        assert tool.engine.workflow_name == "Test - Follow Up Single Step"


# ===========================================================================
# DOCUMENTATION TEST: Schema-bypass comment is gone
# ===========================================================================

def test_engine_init_now_validates_merged_config():
    """REGRESSION: validate_workflow() is called twice — once on raw YAML and once
    on the merged config. The old comment 'bypasses schema validation' must no longer
    apply.

    This test verifies the enforcement by showing a previously-silently-accepted
    invalid value now raises at construction time.
    """
    # Previously passed silently (bypass); now raises
    with pytest.raises(RuntimeError, match="Validation failed|maximum"):
        _make("follow_up_single_step.yaml", {
            "steps": [{"id": "collect_a", "max_attempts": 999}]
        })

    # Previously-valid values still work
    good_tool = _make("follow_up_single_step.yaml", {
        "steps": [{"id": "collect_a", "max_attempts": 5}]
    })
    assert {s["id"]: s for s in good_tool.engine.steps}["collect_a"]["max_attempts"] == 5
