import uuid
import respx
import json

from langgraph.checkpoint.memory import InMemorySaver
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_prompt,
    collector_capture,
    fu_answer,
    make_tool
)


@respx.mock
def test_agent_description_renders_with_state_in_follow_up():
    """
    Verify that agent descriptions in the follow-up prompt's INTENT CHANGE section
    are correctly rendered using the absolute latest workflow state.
    """
    # 5 calls expected: 
    # 1. C1 prompt
    # 2. C1 capture (Alice)
    # 3. C2 prompt (Setting up for Alice)
    # 4. C2 capture (Savings)
    # 5. Follow-up agent (renders both Alice and Savings)
    responses = iter([
        collector_prompt("What is your name?"),                        # LLM#1: collect_user_name prompt
        collector_capture("Alice", field="user_name"),                 # LLM#2: collect_user_name capture
        collector_prompt("What account type for Alice?"),              # LLM#3: collect_account_type prompt
        collector_capture("Savings", field="account_type"),            # LLM#4: collect_account_type capture
        fu_answer("Your account is ready."),                           # LLM#5: follow-up turn context
    ])
    
    # Track requests to check the system prompt at the end
    captured_requests = []
    def _capture(req):
        captured_requests.append(req)
        return next(responses)

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_capture)

    tool = make_tool("agent_description_jinja.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())

    # T1: Start (prompts name)
    tool.execute(thread_id=tid, initial_context={})
    
    # T2: Provide name (captures name, then prompts account type)
    tool.execute(thread_id=tid, user_message="Alice", initial_context={})
    
    # T3: Provide account type (captures account type, then lands in outcome/follow_up)
    tool.execute(thread_id=tid, user_message="Savings", initial_context={})
    
    # T4: Trigger follow-up LLM invocation
    tool.execute(thread_id=tid, user_message="Can I change my name?", initial_context={})

    # Assert exactly 5 calls
    assert len(captured_requests) == 5, f"Expected 5 LLM calls, got {len(captured_requests)}"
    
    # Last request is the follow-up agent invocation (index 4)
    last_body = json.loads(captured_requests[4].content)
    system_msgs = [m for m in last_body.get("messages", []) if m.get("role") == "system"]
    system_prompt = system_msgs[0]["content"]
    # Updated assertions to match multiline formatting:
    # Nodes are registered AFTER collection, so they have the captured values.
    #   - node_id:
    #       description
    assert "collect_user_name:" in system_prompt
    assert "Collector for Alice" in system_prompt
    assert "collect_account_type:" in system_prompt
    assert "Setting up Savings for Alice" in system_prompt
    assert "Collector for Alice" in system_prompt
    assert "Setting up Savings for Alice" in system_prompt

