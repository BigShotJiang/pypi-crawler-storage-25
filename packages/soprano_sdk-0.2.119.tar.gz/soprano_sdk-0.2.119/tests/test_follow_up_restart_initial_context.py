"""Follow-up restart + initial_context re-injection test.

Scenario:
  1. Execute with initial_context={"customer_id": "cust_123"}.
     - customer_id is NOT a collector field; it flows into state directly.
  2. User provides field_a → call_function runs:
     - Sets side_effect_value directly on state.
     - Returns "computed_set" which is stored as computed_value via output:.
  3. Workflow reaches success outcome → follow-up first entry (FOLLOW_UP interrupt).
  4. User triggers restart in follow-up → LLM responds with restart=True.
  5. Follow-up node clears all state and routes back to collect_a.
  6. collect_a prompts again → USER_INPUT interrupt.

After restart (T3 result):
  - USER_INPUT in result (back at collect_a)
  - customer_id == "cust_123"  ← initial_context re-applied, not filtered
  - field_a is None            ← cleared by restart
  - computed_value is None     ← cleared by restart
  - side_effect_value is None  ← cleared by restart

LLM call order:
  LLM#1  collect_a prompt
  LLM#2  collect_a capture → call_function (no LLM) → outcome → FOLLOW_UP (no LLM)
  LLM#3  follow-up LLM → restart → collect_a re-prompts
  LLM#4  collect_a re-prompt after restart
"""

import uuid

import respx

from langgraph.checkpoint.memory import InMemorySaver
from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    fu_restart,
    llm_structured_response,
    make_tool,
    snap,
)


def _prompt_a(text="Please provide field A.") -> object:
    return llm_structured_response({"bot_response": text, "field_a": None})


def _capture_a(val) -> object:
    return llm_structured_response({"bot_response": None, "field_a": val})


@respx.mock
def test_restart_re_applies_initial_context_and_clears_collected_state():
    """After a follow-up restart, initial_context is in state; collected/computed fields are cleared."""
    responses = iter([
        _prompt_a("Please provide field A."),                        # LLM#1 collect_a prompt
        _capture_a("val_a"),                                         # LLM#2 collect_a capture
        # call_function: no LLM call
        # follow-up first entry: no LLM call (fires FOLLOW_UP interrupt immediately)
        fu_restart("Let's start over from the beginning."),          # LLM#3 follow-up restart
        _prompt_a("Please provide field A again."),                  # LLM#4 collect_a re-prompt after restart
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_restart_initial_context.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())
    initial_context = {"customer_id": "cust_123"}

    # T1: collect_a prompts
    tool.execute(thread_id=tid, initial_context=initial_context)

    # T2: collect_a captures → call_function → success → follow-up first entry
    result_entry = tool.execute(thread_id=tid, user_message="val_a", initial_context=initial_context)
    assert InterruptType.FOLLOW_UP in str(result_entry), (
        f"Expected FOLLOW_UP at first entry, got: '{str(result_entry)[:300]}'"
    )

    # Verify call_function ran: both state paths should be set
    s_before = snap(tool, tid)
    assert s_before.get("computed_value") == "computed_set", (
        f"Expected computed_value='computed_set' after call_function, got: {s_before.get('computed_value')}"
    )
    assert s_before.get("side_effect_value") == "side_effect_set", (
        f"Expected side_effect_value='side_effect_set' after call_function, got: {s_before.get('side_effect_value')}"
    )
    assert s_before.get("customer_id") == "cust_123", (
        f"Expected customer_id='cust_123' before restart, got: {s_before.get('customer_id')}"
    )

    # T3: follow-up restart → state cleared → collect_a re-prompts
    result_restart = tool.execute(thread_id=tid, user_message="start over please", initial_context=initial_context)
    assert InterruptType.USER_INPUT in str(result_restart), (
        f"Expected USER_INPUT after restart (back at collect_a), got: '{str(result_restart)[:300]}'"
    )

    # After restart: initial_context re-applied, collected/computed state cleared
    s_after = snap(tool, tid)
    assert s_after.get("customer_id") == "cust_123", (
        f"Expected customer_id re-applied from initial_context after restart, got: {s_after.get('customer_id')}"
    )
    assert s_after.get("field_a") is None, (
        f"Expected field_a=None after restart, got: {s_after.get('field_a')}"
    )
    assert s_after.get("computed_value") is None, (
        f"Expected computed_value=None after restart, got: {s_after.get('computed_value')}"
    )
    assert s_after.get("side_effect_value") is None, (
        f"Expected side_effect_value=None after restart, got: {s_after.get('side_effect_value')}"
    )

    assert respx.calls.call_count == 4
