import uuid
import respx
import pytest
import httpx
from tests.helpers import make_tool, snap, FAKE_LLM_COMPLETIONS
from soprano_sdk.core.constants import WorkflowKeys

@respx.mock
def test_explicit_null_condition_matches_none_result():
    """Verify that condition: null correctly matches a None function result using WorkflowTool."""
    # No LLM calls expected for call_function node, but respx ensures we use the tool infrastructure.
    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=httpx.Response(200, json={})) 

    tool = make_tool("call_function_null_transition.yaml")
    tid = str(uuid.uuid4())
    
    # Run the workflow
    tool.execute(thread_id=tid, initial_context={})
    
    s = snap(tool, tid)
    # outcome_id should be 'null_outcome'
    assert s.get(WorkflowKeys.OUTCOME_ID) == 'null_outcome'
    assert s.get(WorkflowKeys.STATUS) == 'check_null_null_outcome'

@respx.mock
def test_simple_next_routing_works_on_none_result():
    """Verify that top-level next: ... works when transitions are absent using WorkflowTool."""
    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=httpx.Response(200, json={}))

    tool = make_tool("call_function_simple_routing.yaml")
    tid = str(uuid.uuid4())
    
    tool.execute(thread_id=tid, initial_context={})
    
    s = snap(tool, tid)
    assert s.get(WorkflowKeys.OUTCOME_ID) == 'success_outcome'
    assert s.get(WorkflowKeys.STATUS) == 'check_simple_next_success_outcome'

@respx.mock
def test_non_matching_transitions_with_none_result_graceful_error():
    """Verify that if transitions exist but don't match None return, 
    and NO 'failed' outcome exists in YAML, it returns an error outcome gracefully.
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=httpx.Response(200, json={}))

    tool = make_tool("call_function_non_matching.yaml")
    tid = str(uuid.uuid4())
    
    # In mixed_routing_non_matching.yaml, there is no 'failed' outcome.
    # So it should set status to 'error' and return an error message.
    result = tool.execute(thread_id=tid, initial_context={})
    
    assert "Unable to complete the request" in str(result)
    
    s = snap(tool, tid)
    assert s.get(WorkflowKeys.OUTCOME_ID) == 'error'
    assert s.get(WorkflowKeys.STATUS) == 'check_non_matching_error'

@respx.mock
def test_non_matching_transitions_with_none_result_raises_keyerror():
    """Verify that if transitions exist but don't match None return,
    and a 'failed' outcome exists in YAML but is UNLINKED, it raises KeyError.
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=httpx.Response(200, json={}))

    tool = make_tool("call_function_keyerror.yaml")
    tid = str(uuid.uuid4())
    
    # Current behavior: hardcodes 'failed' status which is an outcome but not in routing map
    with pytest.raises(KeyError) as excinfo:
        tool.execute(thread_id=tid, initial_context={})
    
    assert 'failed' in str(excinfo.value)

@respx.mock
def test_node_sets_error_and_raises():
    """Verify behavior when a node sets state['error'] and then raises an exception."""
    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=httpx.Response(200, json={}))

    tool = make_tool("call_function_error_exception.yaml")
    tid = str(uuid.uuid4())
    
    # Run the workflow
    result = tool.execute(thread_id=tid, initial_context={})
    
    # the RuntimeError from CallFunctionStrategy is wrapped by ActionStrategy's "Unable to complete the request"
    expected_error = "Custom error from node"
    assert expected_error in str(result)
    
    s = snap(tool, tid)
    assert s.get(WorkflowKeys.OUTCOME_ID) == 'error'
    assert s.get(WorkflowKeys.STATUS) == 'check_error_raise_error'
    # Based on ActionStrategy.node_fn, it currently overwrites state['error']
    assert s.get(WorkflowKeys.ERROR) == expected_error
