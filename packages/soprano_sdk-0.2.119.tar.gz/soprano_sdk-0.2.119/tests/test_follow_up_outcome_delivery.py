"""Tests for outcome message delivery on first entry into the follow-up node.
Covers success, failure, and redirect outcome types, humanization, and that the outcome
message is stored in the follow-up LLM conversation context.
"""

import json
import uuid

import respx

from soprano_sdk.core.constants import InterruptType, OutcomePrefix

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    llm_structured_response,
    make_tool,
    snap,
)


def _humanizer(text):
    """LLM response: humanizer returns a humanized message."""
    return llm_structured_response({"message": text, "options": None, "is_selectable": None})


@respx.mock
def test_success_outcome_message_delivered_on_first_entry():
    """When a success outcome is reached, the first entry into the follow-up node should
    deliver the configured success message in the FOLLOW_UP interrupt payload. The outcome_id
    should be stored in the checkpoint to confirm the correct outcome was triggered.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result2)
    assert "Success! field_a=" in str(result2)
    assert s["_outcome_id"] == "outcome_success"


@respx.mock
def test_failure_outcome_message_delivered_on_first_entry():
    """When a failure outcome is reached, the first entry into the follow-up node should
    deliver the configured failure message. The outcome_id confirms which outcome branch
    was triggered by the collected field value.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("fail_val"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="fail_val", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result2)
    assert "Failure occurred." in str(result2)
    assert s["_outcome_id"] == "outcome_failure"


@respx.mock
def test_redirect_outcome_delivered_with_redirect_prefix():
    """When a redirect outcome is reached, the follow-up interrupt payload should include
    the redirect prefix marker so that the caller can detect and handle the redirect.
    The outcome_id confirms the redirect branch was triggered correctly.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("redirect_val"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="redirect_val", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result2)
    assert OutcomePrefix.REDIRECT in str(result2)
    assert s["_outcome_id"] == "outcome_redirect"


@respx.mock
def test_humanizer_called_before_follow_up_when_enabled():
    """When a humanization agent is configured, the humanizer LLM should be called
    before the follow-up interrupt is delivered so the outcome message is transformed
    into natural language. The humanized text should appear in the FOLLOW_UP payload.
    """
    responses = iter([
        collector_prompt(),                                            # LLM#1: collector prompt
        collector_capture("hello"),                                    # LLM#2: collector captures
        _humanizer("Humanized: Raw success message."),                 # LLM#3: humanizer
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_humanized.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="hello", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result2)
    assert "Humanized:" in str(result2)
    assert s["_outcome_id"] == "outcome_success"
    assert respx.calls.call_count == 3


@respx.mock
def test_humanizer_skipped_when_disabled():
    """When no humanization agent is configured, the raw template-rendered outcome message
    should be delivered directly without any additional LLM call. This verifies that the
    humanization step is optional and does not run unnecessarily.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("hello"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="hello", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result2)
    assert "Success! field_a=" in str(result2)
    assert respx.calls.call_count == 2


@respx.mock
def test_outcome_message_stored_in_follow_up_conversation_context():
    """On first entry into the follow-up node, the outcome message delivered to the user
    should also be stored as an assistant entry in the follow-up conversation so that the
    follow-up LLM has full context of what was shown. Without this entry the LLM would
    receive the user's first question with no prior assistant context.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        llm_structured_response({"bot_response": "Please tell me field A.", "field_a": None}),  # LLM#1
        llm_structured_response({"bot_response": None, "field_a": "valid_val"}),                # LLM#2
        fu_answer("Here is your answer."),     # LLM#3 — first follow-up Q&A
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                                 # T1 → LLM#1
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})       # T2 → LLM#2 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="q1", initial_context={})              # T3 → LLM#3

    # Verify LLM#3 was called
    assert len(captured_requests) >= 3, (
        f"Expected at least 3 LLM requests but captured {len(captured_requests)}"
    )

    # Parse the follow-up LLM request (LLM#3, index 2)
    follow_up_req_body = json.loads(captured_requests[2].content)
    messages = follow_up_req_body.get("messages", [])

    # Filter out the system message — only check the conversation turns
    non_system_messages = [m for m in messages if m.get("role") != "system"]

    # The outcome message for outcome_success is "Success! field_a={{ field_a }}"
    # rendered with field_a="valid_val" → "Success! field_a=valid_val"
    expected_outcome_text = "valid_val"  # at minimum, field value appears in outcome message

    # There should be an assistant message in the conversation that contains the outcome text
    assistant_messages = [m for m in non_system_messages if m.get("role") == "assistant"]

    assert assistant_messages, (
        f"No assistant message found in follow-up LLM#3 conversation. "
        f"On first entry, interrupt(outcome_payload) delivers the outcome message to the "
        f"user but no assistant entry is stored in the follow-up conversation. "
        f"When T3 runs, conversation=[] so the LLM has no context of what outcome was shown. "
        f"Expected an assistant entry like 'Success! field_a=valid_val' before the user's "
        f"first question. Non-system messages received: {non_system_messages}"
    )

    # Verify the assistant entry contains the outcome text
    outcome_in_assistant = any(
        expected_outcome_text in str(m.get("content", ""))
        for m in assistant_messages
    )
    assert outcome_in_assistant, (
        f"Assistant messages found but none contain the outcome text "
        f"('{expected_outcome_text}'): {assistant_messages}. "
        f"The outcome message 'Success! field_a=valid_val' should appear as an assistant "
        f"entry in the conversation so the follow-up LLM has full context."
    )
