"""Tests for the intent change flow — rolling back workflow state to a prior collector node
when the user wants to change previously entered data. Covers successful rollback, multi-step
rollback, invalid targets, dispatch signal priority (intent_change vs restart vs OOS), and
attempt counter management.
"""

import uuid

import httpx
import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    fu_intent_change,
    llm_structured_response,
    make_tool,
    snap,
)


def _prompt_b(text="Please tell me field B."):
    """LLM response: collect_b asks user for field_b."""
    return llm_structured_response({"bot_response": text, "field_b": None})


def _capture_b(field_b_val):
    """LLM response: collect_b captures field_b."""
    return llm_structured_response({"bot_response": None, "field_b": field_b_val})


def fu_restart_and_intent_change(target_node: str, text: str) -> httpx.Response:
    """LLM returns BOTH restart=True and intent_change simultaneously."""
    return llm_structured_response({
        "bot_response": text,
        "options": None,
        "is_selectable": None,
        "intent_change": target_node,
        "out_of_scope": None,
        "restart": True,
    })


def fu_restart_and_oos(reason: str, text: str) -> httpx.Response:
    """LLM returns BOTH restart=True and out_of_scope simultaneously."""
    return llm_structured_response({
        "bot_response": text,
        "options": None,
        "is_selectable": None,
        "intent_change": None,
        "out_of_scope": reason,
        "restart": True,
    })


@respx.mock
def test_intent_change_rolls_back_state_to_target_collector():
    """When the follow-up LLM signals an intent_change to a known collector node, the
    workflow state should be rolled back to before that collector ran and the graph should
    route to that collector for a fresh re-prompt. All previously collected data for that
    field and follow-up tracking state should be cleared.
    """
    responses = iter([
        collector_prompt("What is field A?"),                          # LLM#1: initial prompt
        collector_capture("valid_val"),                                # LLM#2: collector captures
        fu_intent_change("collect_a", "Let me help you change that."),  # LLM#3: intent_change
        collector_prompt("Please re-enter field A."),                  # LLM#4: fresh re-prompt after rollback
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="change my answer", initial_context={})
    s = snap(tool, tid)

    # Back at collector, not in follow-up
    assert InterruptType.USER_INPUT in str(result3)
    assert InterruptType.FOLLOW_UP not in str(result3)
    assert s["field_a"] is None
    assert s.get("_follow_up_active") is None
    assert respx.calls.call_count == 4


@respx.mock
def test_intent_change_from_second_qa_turn_still_rolls_back_correctly():
    """An intent_change triggered after at least one normal Q&A turn should still roll
    back correctly. After a Q&A turn the follow-up tracking state is checkpointed, and
    the rollback must explicitly clear those keys even though the snapshot predates them.
    """
    responses = iter([
        collector_prompt("What is field A?"),                              # LLM#1: initial prompt
        collector_capture("valid_val"),                                    # LLM#2: capture
        fu_answer("Answer 1."),                                            # LLM#3: first Q&A turn
        fu_intent_change("collect_a", "Let me help you redo that."),       # LLM#4: intent change
        collector_prompt("Please re-enter field A."),                      # LLM#5: collect_a re-prompt
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="question 1", initial_context={})  # T3: Q&A
    result4 = tool.execute(thread_id=tid, user_message="change my answer", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result4)
    assert InterruptType.FOLLOW_UP not in str(result4)
    assert s["field_a"] is None
    # These are explicitly cleared by _handle_intent_change on the rollback state
    assert s.get("_follow_up_active") is None
    assert s.get("_follow_up_attempts") is None
    assert respx.calls.call_count == 5


@respx.mock
def test_follow_up_reactivates_with_clean_slate_after_re_collection():
    """After an intent_change rollback and successful re-collection, the follow-up node
    should reactivate with a fresh session. The attempt counter and active flag should
    both be absent from the checkpoint since the follow-up first entry fires an interrupt
    before returning state.
    """
    responses = iter([
        collector_prompt("What is field A?"),                              # LLM#1: initial prompt
        collector_capture("valid_val"),                                    # LLM#2: capture
        fu_intent_change("collect_a", "Let me help you redo that."),       # LLM#3: intent change
        collector_prompt("Please re-enter field A."),                      # LLM#4: collect_a re-prompt
        collector_capture("new_val"),                                      # LLM#5: fresh capture
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    tool.execute(thread_id=tid, user_message="change my answer", initial_context={})  # T3
    result4 = tool.execute(thread_id=tid, user_message="new_val", initial_context={})
    s = snap(tool, tid)

    # Back at follow-up with fresh capture
    assert InterruptType.FOLLOW_UP in str(result4)
    assert s["_outcome_id"] == "outcome_success"
    # No Q&A turns yet in the new follow-up session
    assert s.get("_follow_up_attempts") is None
    assert s.get("_follow_up_active") is True  # checkpointed by Pass 1 of two-pass pattern
    assert respx.calls.call_count == 5


@respx.mock
def test_intent_change_to_first_step_clears_all_collected_fields():
    """In a two-step workflow, an intent_change targeting the first collector should
    roll back to before that collector ran, clearing both field_a and field_b since
    both were collected after that point.
    """
    responses = iter([
        collector_prompt("What is field A?"),                    # LLM#1: collect_a initial prompt
        collector_capture("val_a"),                              # LLM#2: collect_a capture
        _prompt_b("What is field B?"),                           # LLM#3: collect_b initial prompt
        _capture_b("val_b"),                                     # LLM#4: collect_b capture
        fu_intent_change("collect_a", "Let me redo A."),         # LLM#5: intent change to collect_a
        collector_prompt("Please re-enter field A."),            # LLM#6: collect_a re-prompt after rollback
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})           # T1: collect_a prompt
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})  # T2: capture a + collect_b prompt
    tool.execute(thread_id=tid, user_message="val_b", initial_context={})  # T3: capture b + FOLLOW_UP
    result4 = tool.execute(thread_id=tid, user_message="change field a", initial_context={})
    s = snap(tool, tid)

    # Rolled back to before collect_a — both fields cleared
    assert InterruptType.USER_INPUT in str(result4)
    assert s["field_a"] is None
    assert s["field_b"] is None
    assert s.get("_follow_up_active") is None
    assert respx.calls.call_count == 6


@respx.mock
def test_intent_change_to_second_step_preserves_earlier_fields():
    """In a two-step workflow, an intent_change targeting the second collector should
    roll back to before that collector ran, preserving field_a (collected earlier) while
    clearing field_b (collected at the rollback target).
    """
    responses = iter([
        collector_prompt("What is field A?"),                    # LLM#1: collect_a initial prompt
        collector_capture("val_a"),                              # LLM#2: collect_a capture
        _prompt_b("What is field B?"),                           # LLM#3: collect_b initial prompt
        _capture_b("val_b"),                                     # LLM#4: collect_b capture
        fu_intent_change("collect_b", "Let me redo B."),         # LLM#5: intent change to collect_b
        _prompt_b("Please re-enter field B."),                   # LLM#6: collect_b re-prompt after rollback
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})           # T1: collect_a prompt
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})  # T2: capture a + collect_b prompt
    tool.execute(thread_id=tid, user_message="val_b", initial_context={})  # T3: capture b + FOLLOW_UP
    result4 = tool.execute(thread_id=tid, user_message="change field b", initial_context={})
    s = snap(tool, tid)

    # Rolled back to before collect_b — field_a preserved, field_b cleared
    assert InterruptType.USER_INPUT in str(result4)
    assert s["field_a"] is not None   # preserved from collect_a
    assert s["field_b"] is None       # cleared by rollback
    assert s.get("_follow_up_active") is None
    assert respx.calls.call_count == 6


@respx.mock
def test_intent_change_after_qa_turn_clears_follow_up_tracking_state():
    """After at least one Q&A self-loop turn that checkpoints follow-up tracking state,
    a subsequent intent_change rollback must clear _follow_up_active and _follow_up_attempts.
    On re-entry after re-collection the outcome message should be rendered fresh, not the
    stale self-loop path with an empty conversation.
    """
    responses = iter([
        collector_prompt("What is field A?"),                               # LLM#1
        collector_capture("first_val"),                                     # LLM#2
        fu_answer("Here is your answer."),                                  # LLM#3 Q&A
        fu_intent_change("collect_a", "Let me help you redo that."),        # LLM#4
        collector_prompt("Please re-enter field A."),                       # LLM#5 re-prompt after rollback
        collector_capture("new_val"),                                       # LLM#6 re-capture
        # No LLM#7: follow-up re-entry fires interrupt before LLM call
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                           # T1
    tool.execute(thread_id=tid, user_message="first_val", initial_context={}) # T2 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="old question", initial_context={})  # T3 Q&A
    tool.execute(thread_id=tid, user_message="change my answer", initial_context={})  # T4 intent_change
    result5 = tool.execute(thread_id=tid, user_message="new_val", initial_context={})  # T5 re-collect + FOLLOW_UP re-entry
    s = snap(tool, tid)

    assert "Success! field_a=" in str(result5), (
        f"Expected outcome message in re-entry, got: '{str(result5)}'"
    )

    assert s.get("_follow_up_attempts") is None, (
        f"Expected _follow_up_attempts=None after re-entry, "
        f"got: {s.get('_follow_up_attempts')}"
    )


@respx.mock
def test_intent_change_to_unknown_node_falls_back_to_self_loop_not_graph_end():
    """When the follow-up LLM returns an intent_change to a node that does not exist in
    the workflow, the graph should stay alive as a FOLLOW_UP self-loop rather than routing
    to END. The user should remain in the follow-up session so they can try again.
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_intent_change("totally_nonexistent_node_xyz", "Let me update that."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="change something", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result3) or InterruptType.USER_INPUT in str(result3), (
        f"Graph should stay alive after invalid intent_change target, "
        f"but result has no interrupt marker: '{str(result3)}'"
    )


@respx.mock
def test_intent_change_wins_over_restart_when_both_signals_are_set():
    """When the follow-up LLM returns both restart=True and intent_change simultaneously,
    the intent_change should take precedence because it is more specific and less destructive.
    A full restart would wipe all workflow state including the outcome_id, while a rollback
    preserves state from earlier in the workflow.
    """
    responses = iter([
        collector_prompt("What is field A?"),
        collector_capture("my_value"),
        # LLM returns BOTH restart=True and intent_change='collect_a'
        fu_restart_and_intent_change("collect_a", "Let me help you update that."),
        # If intent_change wins: collector re-prompts
        collector_prompt("Please re-enter field A."),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="my_value", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="actually change it", initial_context={})
    s = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result3)

    # After a rollback (correct behaviour): _outcome_id should survive in the snapshot
    # since the rollback snapshot predates follow-up but postdates outcome routing.
    # After a restart (buggy behaviour): _outcome_id is None because _handle_restart clears everything.
    assert s.get("_outcome_id") is not None, (
        f"With intent_change the outcome_id should survive rollback "
        f"(rollback snapshot predates follow-up but postdates outcome routing). "
        f"A full restart wipes _outcome_id=None. Got: {s.get('_outcome_id')}"
    )


@respx.mock
def test_out_of_scope_wins_over_restart_when_both_signals_are_set():
    """When the follow-up LLM returns both restart=True and out_of_scope simultaneously,
    out_of_scope should take precedence because it is more specific. A full restart would
    wipe the entire session when the user only asked an out-of-scope question, which is
    a far more destructive action than delivering an OOS notification.
    """
    responses = iter([
        collector_prompt(),                                                     # LLM#1: collector prompt
        collector_capture("valid_val"),                                         # LLM#2: collector capture
        fu_restart_and_oos("unrelated_topic", "I can't help with that."),        # LLM#3: both flags
        collector_prompt("Starting over. What is field A?"),                    # LLM#4: re-prompt after restart
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="unrelated question", initial_context={})
    s = snap(tool, tid)

    # Expected: OOS notification delivered (FOLLOW_UP_OUT_OF_SCOPE).
    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3), (
        f"Expected FOLLOW_UP_OUT_OF_SCOPE when restart+OOS both set, "
        f"got: '{str(result3)}'"
    )
    # field_a should still be present (no restart happened)
    assert s.get("field_a") is not None, (
        "field_a should survive (no restart), got None — restart fired!"
    )


@respx.mock
def test_intent_change_to_invalid_node_falls_back_to_qa_self_loop():
    """When the follow-up LLM returns intent_change to an unrecognised target node,
    the node should fall back to a self-loop rather than routing to the collector or
    ending the graph. Collected data should be preserved since no rollback occurred.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_intent_change("nonexistent_collector_node", "Acknowledged."), # LLM#3 — bad target
        fu_answer("Continuing as normal."),                              # LLM#4 — next turn
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})

    # T3: follow-up LLM returns intent_change to unknown node
    result3 = tool.execute(thread_id=tid, user_message="I want to change something.", initial_context={})

    # Fallback: should self-loop back to FOLLOW_UP (not route to collector)
    assert InterruptType.FOLLOW_UP in str(result3), (
        f"Expected FOLLOW_UP at T3 (fallback self-loop on failed rollback), "
        f"got: '{str(result3)[:200]}'"
    )
    assert InterruptType.USER_INPUT not in str(result3), (
        f"T3 must NOT produce USER_INPUT: rollback failed so we did not reach the collector. "
        f"Got: '{str(result3)[:200]}'"
    )

    # field_a must be preserved — the rollback never happened
    s3 = snap(tool, tid)
    fa3 = s3.get("field_a")
    assert fa3 is not None and "valid_val" in str(fa3), (
        f"field_a must not be cleared on a failed rollback. "
        f"Expected value containing 'valid_val', got: {fa3!r}"
    )
    assert s3.get("_follow_up_active") is True, (
        f"_follow_up_active must remain True after fallback self-loop. "
        f"Got: {s3.get('_follow_up_active')!r}"
    )

    # T4: conversation continues normally after the failed intent_change
    result4 = tool.execute(thread_id=tid, user_message="ok, a normal question", initial_context={})

    assert InterruptType.FOLLOW_UP in str(result4), (
        f"Expected FOLLOW_UP at T4 after failed intent_change + self-loop. "
        f"Got: '{str(result4)[:200]}'"
    )

    assert len(captured_requests) >= 4, (
        f"Expected at least 4 LLM calls (including T4), got {len(captured_requests)}"
    )


@respx.mock
def test_normal_qa_resumes_after_failed_intent_change_rollback():
    """After a failed intent_change rollback (unknown target node), the follow-up loop
    should not be bricked. The next user message should still invoke the LLM and return
    a normal FOLLOW_UP interrupt, confirming the follow-up session continues normally.
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_answer("First answer."),                                    # LLM#3 — T3 normal
        fu_intent_change("no_such_node", "I'll try to help with that."),  # LLM#4 — T4 bad IC
        fu_answer("Second answer."),                                   # LLM#5 — T5 normal
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})

    result3 = tool.execute(thread_id=tid, user_message="q1", initial_context={})
    assert InterruptType.FOLLOW_UP in str(result3), (
        f"Expected FOLLOW_UP at T3. Got: '{str(result3)[:200]}'"
    )

    # T4: bad intent_change → fallback self-loop → FOLLOW_UP (not USER_INPUT)
    result4 = tool.execute(thread_id=tid, user_message="change bad", initial_context={})
    assert InterruptType.FOLLOW_UP in str(result4), (
        f"Expected FOLLOW_UP at T4 (self-loop after failed rollback). "
        f"Got: '{str(result4)[:200]}'"
    )
    assert InterruptType.USER_INPUT not in str(result4), (
        f"T4 must NOT produce USER_INPUT (no rollback occurred). "
        f"Got: '{str(result4)[:200]}'"
    )

    s4 = snap(tool, tid)
    fa4 = s4.get("field_a")
    assert fa4 is not None and "valid_val" in str(fa4), (
        f"field_a must be preserved after failed rollback. Got: {fa4!r}"
    )

    # T5: normal question continues after the failed intent_change turn
    result5 = tool.execute(thread_id=tid, user_message="q2", initial_context={})
    assert InterruptType.FOLLOW_UP in str(result5), (
        f"Expected FOLLOW_UP at T5. Got: '{str(result5)[:200]}'"
    )
    assert "Second answer." in str(result5), (
        f"T5 LLM response must appear. Got: '{str(result5)[:200]}'"
    )

    assert len(captured_requests) >= 5, (
        f"Expected 5 LLM calls total, got {len(captured_requests)}"
    )


    state = snap(tool, tid)
    assert state.get("_follow_up_active") is True, (
        f"_follow_up_active must be True after T5. Got: {state.get('_follow_up_active')!r}"
    )


@respx.mock
def test_intent_change_injects_follow_up_conversation_into_collector_prompt():
    """After a follow_up intent change rollback, the target collector's LLM call must
    include the follow-up conversation in its system prompt so the LLM can see the
    full context that led the user to request the change.

    Flow:
    T1  execute({})            → LLM#1 collector prompts             → USER_INPUT
    T2  execute("val_a")       → LLM#2 collector captures; FOLLOW_UP → FOLLOW_UP
    T3  execute("change it")   → LLM#3 follow-up intent_change       → USER_INPUT
                                   LLM#4 collector re-prompts after rollback

    Assert: the system prompt sent in LLM#4 contains the [Step: Follow Up] section
    with the user's intent-change message, giving the collector full context.

    Note: the follow_up's `bot_response` from an intent_change turn is NOT stored in
    the conversation — `_handle_intent_change` returns immediately without appending it.
    What IS stored is: the outcome assistant turn + the user's intent-change message.
    """
    import json as _json

    INTENT_CHANGE_USER_MSG = "change it"
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("What is field A?"),                                    # LLM#1
        collector_capture("val_a"),                                              # LLM#2
        fu_intent_change("collect_a", "Sure, let me help you update that."),    # LLM#3
        collector_prompt("Please re-enter field A."),                            # LLM#4: after rollback
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                              # T1
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})        # T2 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message=INTENT_CHANGE_USER_MSG, initial_context={})  # T3 → intent_change

    assert len(captured_requests) == 4, (
        f"Expected 4 LLM calls, got {len(captured_requests)}"
    )

    # LLM#4 is the collector re-prompt after rollback (index 3)
    collector_reprompt_req = captured_requests[3]
    body = _json.loads(collector_reprompt_req.content)
    messages = body.get("messages", [])

    # The system message is the first entry in messages
    system_msgs = [m for m in messages if m.get("role") == "system"]
    assert system_msgs, "Expected a system message in the collector re-prompt LLM call"
    system_prompt = system_msgs[0]["content"]

    # The [Step: Follow Up] section header must be present
    assert "Follow Up" in system_prompt, (
        f"Expected '[Step: Follow Up]' section header in the collector system prompt "
        f"after intent_change rollback, but it was not found.\n"
        f"System prompt excerpt: {system_prompt[:600]}"
    )

    # The user's intent-change message must appear in the Follow Up section
    assert INTENT_CHANGE_USER_MSG in system_prompt, (
        f"User's intent-change message '{INTENT_CHANGE_USER_MSG}' should appear in the "
        f"collector system prompt (as part of the [Step: Follow Up] conversation history), "
        f"but it was not found.\n"
        f"System prompt excerpt: {system_prompt[:600]}"
    )

@respx.mock
def test_intent_change_rollback_to_first_collector_then_recollect_routes_to_second_collector():
    """After intent_change rolls back to collect_a and the user re-provides field_a,
    the workflow should route to collect_b (the next collector in sequence) — NOT jump
    back to follow-up or end the graph. This verifies the downstream collect_b field is
    correctly cleared by rollback and that normal step sequencing is restored.

    Flow:
    T1  execute({})         → LLM#1 collect_a prompts                  → USER_INPUT
    T2  execute("val_a")    → LLM#2 collect_a captures; LLM#3 collect_b prompts → USER_INPUT
    T3  execute("val_b")    → LLM#4 collect_b captures; FOLLOW_UP entry         → FOLLOW_UP
    T4  execute("change a") → LLM#5 follow-up intent_change("collect_a"); LLM#6 re-prompt → USER_INPUT
    T5  execute("new_a")    → LLM#7 collect_a captures; LLM#8 collect_b prompts → USER_INPUT at collect_b
    """
    responses = iter([
        collector_prompt("What is field A?"),         # LLM#1: collect_a initial prompt
        collector_capture("val_a"),                   # LLM#2: collect_a captures
        _prompt_b("What is field B?"),                # LLM#3: collect_b initial prompt
        _capture_b("val_b"),                          # LLM#4: collect_b captures
        fu_intent_change("collect_a", "Sure, let me help you change field A."),  # LLM#5: intent_change
        collector_prompt("Please re-enter field A."), # LLM#6: collect_a re-prompt after rollback
        collector_capture("new_val_a"),               # LLM#7: collect_a re-captures new value
        _prompt_b("What is field B?"),                # LLM#8: collect_b re-prompts (cleared by rollback)
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                                   # T1
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})             # T2
    tool.execute(thread_id=tid, user_message="val_b", initial_context={})             # T3 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="change field a", initial_context={})   # T4 → back at collect_a

    result5 = tool.execute(thread_id=tid, user_message="new_val_a", initial_context={})  # T5
    s5 = snap(tool, tid)

    # T5 must land at collect_b waiting for field_b — not back at follow-up
    assert InterruptType.USER_INPUT in str(result5), (
        f"Expected USER_INPUT at collect_b after re-collecting field_a, "
        f"got: '{str(result5)[:300]}'"
    )
    assert InterruptType.FOLLOW_UP not in str(result5), (
        f"Workflow jumped straight back to follow-up without collecting field_b. "
        f"Got: '{str(result5)[:300]}'"
    )

    # field_a has the new value, field_b is still empty (waiting to be re-collected)
    assert s5.get("field_b") is None, (
        f"field_b should be cleared by rollback and not yet re-collected, "
        f"got: {s5.get('field_b')!r}"
    )
    field_a_val = s5.get("field_a")
    assert field_a_val is not None and "new_val_a" in str(field_a_val), (
        f"field_a should have the new value after re-collection, got: {field_a_val!r}"
    )
    assert respx.calls.call_count == 8


@respx.mock
def test_failed_intent_change_rollback_consumes_attempt_slot():
    """When an intent_change fails because the target node does not exist, the graph
    falls back to a self-loop. The attempt is counted like any other turn.
    """
    def fu_intent_change_unknown(target_node: str):
        return llm_structured_response({
            "bot_response": "Let me help you change that.",
            "options": None,
            "is_selectable": None,
            "intent_change": target_node,
            "out_of_scope": None,
            "restart": False,
        })

    def fu_answer_local(text: str):
        return llm_structured_response({
            "bot_response": text,
            "options": None,
            "is_selectable": None,
            "intent_change": None,
            "out_of_scope": None,
            "restart": False,
        })

    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_intent_change_unknown("nonexistent_node"),  # LLM#3 — intent_change fails
        fu_answer_local("Here is the info you requested."),  # LLM#4 — self-loop follow-up
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="change my answer", initial_context={})

    # The failed rollback should self-loop back into follow-up
    assert InterruptType.FOLLOW_UP in str(result3), (
        f"Expected FOLLOW_UP self-loop after failed rollback, got: '{str(result3)[:200]}'"
    )

    state = snap(tool, tid)
    attempts_after_t3 = state.get("_follow_up_attempts")

    assert attempts_after_t3 == 1, (
        f"_follow_up_attempts is {attempts_after_t3} after a failed intent_change rollback. "
        f"Expected 1 — failed rollback counts as a normal turn."
    )


@respx.mock
def test_rollback_to_first_node_injects_all_downstream_conversations_into_prompt():
    """Regression: C1→C2→C3→follow_up; follow_up rolls back to C1.

    The re-entered C1 prompt must contain preserved conversation history from
    C2, C3, and the follow_up — in that order — so the LLM has full context.

    Flow:
      T1 execute({})         → LLM#1  collect_a prompts               → USER_INPUT
      T2 execute("val_a")    → LLM#2  collect_a captures              → (routes to collect_b)
                               LLM#3  collect_b prompts               → USER_INPUT
      T3 execute("val_b")    → LLM#4  collect_b captures              → (routes to collect_c)
                               LLM#5  collect_c prompts               → USER_INPUT
      T4 execute("val_c")    → LLM#6  collect_c captures              → outcome → FOLLOW_UP
      T5 execute("change a") → LLM#7  follow_up intent_change→C1     → USER_INPUT
                               LLM#8  collect_a re-prompts

    Assert: system prompt of LLM#8 contains [Step: Collect B], [Step: Collect C],
    and [Step: Follow Up] sections — proving all downstream conversations are injected.
    """
    import json as _json

    COLLECT_B_PROMPT_TEXT = "Please tell me field B."
    COLLECT_C_PROMPT_TEXT = "Please tell me field C."
    captured_requests: list = []

    def _capture(req):
        captured_requests.append(req)
        return next(responses)

    def _prompt_c(text=COLLECT_C_PROMPT_TEXT):
        return llm_structured_response({"bot_response": text, "field_c": None})

    def _capture_c(value):
        return llm_structured_response({"bot_response": None, "field_c": value})

    responses = iter([
        collector_prompt("Please tell me field A."),       # LLM#1 collect_a prompts
        collector_capture("val_a"),                        # LLM#2 collect_a captures → collect_b
        _prompt_b(COLLECT_B_PROMPT_TEXT),                  # LLM#3 collect_b prompts
        llm_structured_response({"bot_response": None, "field_b": "val_b"}),  # LLM#4 collect_b captures → collect_c
        _prompt_c(COLLECT_C_PROMPT_TEXT),                  # LLM#5 collect_c prompts
        _capture_c("val_c"),                               # LLM#6 collect_c captures → outcome → FOLLOW_UP
        fu_intent_change("collect_a", "Sure, rolling back."),  # LLM#7 follow_up intent_change
        collector_prompt("Please re-enter field A."),      # LLM#8 collect_a re-prompts
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_capture)

    tool = make_tool("follow_up_three_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                              # T1
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})        # T2
    tool.execute(thread_id=tid, user_message="val_b", initial_context={})        # T3
    tool.execute(thread_id=tid, user_message="val_c", initial_context={})        # T4 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="change a", initial_context={})     # T5 → intent_change

    assert len(captured_requests) == 8, (
        f"Expected 8 LLM calls, got {len(captured_requests)}"
    )

    # LLM#8 is the collect_a re-prompt (index 7)
    reprompt_body = _json.loads(captured_requests[7].content)
    system_msgs = [m for m in reprompt_body.get("messages", []) if m.get("role") == "system"]
    assert system_msgs, "Expected a system message in the collect_a re-prompt"
    system_prompt = system_msgs[0]["content"]

    # All three downstream sections must appear (in order)
    assert "Collect B" in system_prompt, (
        f"[Step: Collect B] section missing from collect_a system prompt.\n"
        f"Excerpt: {system_prompt[:600]}"
    )
    assert "Collect C" in system_prompt, (
        f"[Step: Collect C] section missing from collect_a system prompt.\n"
        f"Excerpt: {system_prompt[:600]}"
    )
    assert "Follow Up" in system_prompt, (
        f"[Step: Follow Up] section missing from collect_a system prompt.\n"
        f"Excerpt: {system_prompt[:600]}"
    )

    # Confirm ordering: B before C before Follow Up
    b_pos = system_prompt.index("Collect B")
    c_pos = system_prompt.index("Collect C")
    fu_pos = system_prompt.index("Follow Up")
    assert b_pos < c_pos < fu_pos, (
        f"Expected sections to appear in order B→C→Follow Up, "
        f"got positions B={b_pos}, C={c_pos}, Follow Up={fu_pos}"
    )

    # Collect_b's prompt text must appear inside its section
    assert COLLECT_B_PROMPT_TEXT in system_prompt, (
        f"collect_b's prompt text not found in collect_a system prompt.\n"
        f"Excerpt: {system_prompt[:600]}"
    )
    assert COLLECT_C_PROMPT_TEXT in system_prompt, (
        f"collect_c's prompt text not found in collect_a system prompt.\n"
        f"Excerpt: {system_prompt[:600]}"
    )


@respx.mock
def test_multi_step_capture_history_with_transition_exclusion():
    """Scenario: C1→C2→C3→follow_up; user provides A and B at once.
    
    1. C1 prompt -> User "A is 1, B is 2"
    2. C1 capture(A) -> C2 (skipped prompt) -> C2 capture(B) -> C3 prompt
    3. User "C is 3" -> C3 capture(C) -> outcome -> FOLLOW_UP
    4. FollowUp user "change B" -> intent_change(C2)
    5. C2 re-prompt:
       - History must include "C?" and "C is 3"
       - History must NOT include transition messages (assistant messages with null bot_response)
    """
    import json as _json

    captured_requests: list = []
    def _capture(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("Field A?"),                               # LLM#1: C1 prompt
        llm_structured_response({"field_a": "1"}),                  # LLM#2: C1 capture (no bot_response)
        llm_structured_response({"field_b": "2"}),                  # LLM#3: C2 capture (skipped prompt, no bot_response)
        collector_prompt("Field C?"),                               # LLM#4: C3 prompt
        llm_structured_response({"field_c": "3"}),                  # LLM#5: C3 capture (no bot_response)
        fu_intent_change("collect_b", "OK, rolling back to B."),    # LLM#6: follow_up intent_change
        collector_prompt("Please re-enter Field B."),               # LLM#7: C2 re-prompt
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_capture)

    tool = make_tool("follow_up_three_step.yaml")
    tid = str(uuid.uuid4())

    # T1: Initial execute (prompts A)
    tool.execute(thread_id=tid, initial_context={})
    
    # T2: User provides A and B (captures both, then prompts C)
    tool.execute(thread_id=tid, user_message="A is 1, B is 2", initial_context={})
    
    # T3: User provides C (captures C, then lands in FOLLOW_UP)
    tool.execute(thread_id=tid, user_message="C is 3", initial_context={})
    
    # T4: User wants to change B (rolls back to C2, prompts B)
    tool.execute(thread_id=tid, user_message="change B", initial_context={})

    assert len(captured_requests) == 7, f"Expected 7 LLM calls, got {len(captured_requests)}"

    # LLM#7 is the C2 re-prompt (index 6)
    reprompt_body = _json.loads(captured_requests[6].content)
    system_msgs = [m for m in reprompt_body.get("messages", []) if m.get("role") == "system"]
    system_prompt = system_msgs[0]["content"]

    # History from C3 must be present
    assert "Collect C" in system_prompt
    assert "Field C?" in system_prompt
    assert "C is 3" in system_prompt

    # History from Follow Up must be present
    assert "Follow Up" in system_prompt
    assert "change B" in system_prompt

    # Transition exclusion check: 
    # C3 capture (LLM#5) returns {"field_c": "3"} with no bot_response.
    # This should be excluded from history.
    # If it was NOT excluded, we'd see "Agent: (blank)" or some JSON artifact.
    # The _build_conversation_history logic skips assistant messages with null/empty content.
    
    # Specifically, check that transitions ARE included as per user preference
    c_section = system_prompt.split("[Step: Collect C]")[1].split("[Step:")[0]
    assert "Agent:" in c_section
    
    # Transitions (with bot_response: null) are now excluded from history as per user's revert.
    # We expect 1 message for Collect C in history: Prompt (Assistant).
    agent_occurrences = c_section.count("Agent:")
    assert agent_occurrences >= 1, (
        f"Expected at least 1 'Agent:' entry in Collect C history (prompt), "
        f"found {agent_occurrences}.\n"
        f"C Section: {c_section}"
    )

    # Check Follow Up history section: It should contain the outcome message
    # (delivered on first entry) and the user's request.
    assert "User: change B" in system_prompt
    # The outcome message now contains raw JSON artifacts as per user's "internal artifacts are fine" logic
    assert "Success!" in system_prompt
    assert "'field_a': '1'" in system_prompt
    assert "OK, rolling back to B." in system_prompt


@respx.mock
def test_multi_step_capture_history_with_four_collectors():
    """Scenario: C1→C2→C3→C4→follow_up; user provides A, B, and C at once.

    1. C1 prompt -> User "A is 1, B is 2, C is 3"
    2. C1 capture(A) -> C2 (skipped) -> C3 (skipped) -> C4 prompt
    3. User "D is 4" -> C4 capture(D) -> outcome -> FOLLOW_UP
    4. FollowUp prompt "Success!"
    5. User "change B" -> intent_change(C2)
    6. C2 re-prompt:
       - History must include C3, C4, and Follow Up
    """
    import json as _json
    captured_requests: list = []
    def _capture(req):
        resp = next(responses)
        captured_requests.append((req, resp))
        return resp

    responses = iter([
        collector_prompt("Field A?"),                               # LLM#1: C1 prompt (T1)
        llm_structured_response({"field_a": "1"}),                  # LLM#2: C1 capture (T2 start)
        llm_structured_response({"field_b": "2"}),                  # LLM#3: C2 capture (T2 cont)
        llm_structured_response({"field_c": "3"}),                  # LLM#4: C3 capture (T2 cont)
        collector_prompt("Field D?"),                               # LLM#5: C4 prompt (T2 end)
        llm_structured_response({"field_d": "4"}),                  # LLM#6: C4 capture (T3 start)
        # T3 ends here with Outcome message ("Success!") delivered via interrupt
        fu_intent_change("collect_b", "OK, rolling back to B."),    # LLM#7: FollowUp intent_change (T4 start)
        collector_prompt("Please re-enter Field B."),               # LLM#8: C2 re-prompt (T4 end - after rollback)
        llm_structured_response({"field_b": "22"}),                 # LLM#9: C2 re-capture (T5 start)
        collector_prompt("Please re-enter Field C."),               # LLM#10: C3 prompt (T5 end)
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_capture)

    tool = make_tool("follow_up_four_step.yaml")
    tid = str(uuid.uuid4())

    # T1: Initial execute (prompts A)
    tool.execute(thread_id=tid, initial_context={})

    # T2: User provides A, B, and C (captures A, B, C then prompts D)
    tool.execute(thread_id=tid, user_message="A is 1, B is 2, C is 3", initial_context={})

    # T3: User provides D (captures D, then Outcome delivers Success! via interrupt)
    tool.execute(thread_id=tid, user_message="D is 4", initial_context={})

    # T4: User wants to change B (FollowUp processes "change B", rolls back to B, B re-prompts)
    tool.execute(thread_id=tid, user_message="change B", initial_context={})

    # Verify LLM#8: C2 re-prompt (index 7)
    # This happens in T4 after rollback
    assert len(captured_requests) == 8, f"Expected at least 8 LLM calls, got {len(captured_requests)}"

    # T5: User provides new B (captures B, then prompts C since C was cleared)
    tool.execute(thread_id=tid, user_message="B is 22", initial_context={})

    # Verify LLM#10: C3 re-prompt (index 9)
    c3_reprompt_req, _ = captured_requests[9]
    c3_reprompt_body = _json.loads(c3_reprompt_req.content)
    c3_system_prompt = next(m["content"] for m in c3_reprompt_body["messages"] if m["role"] == "system")

    # History should INCLUDE the new B provide turn
    assert "[Step: Collect B]" in c3_system_prompt
    assert "User: B is 22" in c3_system_prompt
    
    # And it should STILL include C4 and Follow Up from previous session (as extra keys)
    assert "[Step: Collect D]" in c3_system_prompt
    assert "[Step: Follow Up]" in c3_system_prompt
