"""Tests for composite follow-up flows that cross multiple behaviour tracks.

These tests combine OOS, intent_change, restart, and Q&A in sequences that are not
exercised by any individual track's test file. The goal is to catch state corruption
that only surfaces when one track's state interacts with another's.

Covered tracks:
  - OOS then intent_change in the next turn (OOS → rollback)
  - OOS then restart in the next turn (OOS → full state clear)
  - Chained intent_changes: rollback, re-collect, rollback again in new session
  - Attempt counter reset after intent_change, verified by running Q&A to the limit
  - Attempt counter reset after restart, verified by running Q&A to the limit
  - FOLLOW_UP_PENDING_PROMPT is None after intent_change rollback checkpoint
"""
import uuid

import respx

from langgraph.checkpoint.memory import InMemorySaver
from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    fu_intent_change,
    fu_out_of_scope,
    fu_restart,
    make_tool,
    snap,
)


# ──────────────────────────────────────────────────────────────────────────────
# OOS → intent_change in next turn
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_intent_change_after_oos_turn_rolls_back_correctly():
    """When the user's response to a FOLLOW_UP_OUT_OF_SCOPE interrupt is an intent_change
    signal, the follow-up node must process the OOS pending prompt path (firing interrupt,
    getting user input from the resume), call the LLM, detect intent_change, and rollback.

    The OOS attempt is consumed (attempts=1), the intent_change turn is also consumed
    (attempts=2), and then the collector re-prompts. All follow-up tracking state must be
    cleared by the rollback.

    LLM sequence:
      #1  collector prompt                (T1)
      #2  collector captures 'valid_val'  (T2) → FOLLOW_UP (outcome)
      #3  follow-up: OOS signal           (T3, pending_prompt path) → FOLLOW_UP_OUT_OF_SCOPE
      #4  follow-up: intent_change signal (T4, OOS pending_prompt path) → rollback
      #5  collector re-prompt             (T4, after rollback routing)
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_out_of_scope("off_topic", "I can't help with that."),   # LLM#3 — OOS
        fu_intent_change("collect_a", "Let me change my answer."), # LLM#4 — intent_change after OOS
        collector_prompt("Please re-enter field A."),               # LLM#5 — after rollback
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})         # T2 → FOLLOW_UP
    result3 = tool.execute(thread_id=tid, user_message="buy crypto", initial_context={})   # T3 → OOS
    result4 = tool.execute(thread_id=tid, user_message="change my answer", initial_context={})  # T4 → USER_INPUT

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3), (
        f"T3 must return OOS interrupt. Got: {result3}"
    )
    assert InterruptType.USER_INPUT in str(result4), (
        f"T4 must route back to collector after intent_change. Got: {result4}"
    )

    s = snap(tool, tid)
    assert s.get("field_a") is None, (
        f"field_a must be cleared after intent_change rollback. Got: {s.get('field_a')!r}"
    )
    assert s.get("_follow_up_active") is None, (
        f"_follow_up_active must be cleared after rollback. Got: {s.get('_follow_up_active')!r}"
    )
    assert s.get("_follow_up_attempts") is None, (
        f"_follow_up_attempts must be cleared after rollback. Got: {s.get('_follow_up_attempts')!r}"
    )
    assert s.get("_follow_up_pending_prompt") is None, (
        f"_follow_up_pending_prompt must be None after rollback. Got: {s.get('_follow_up_pending_prompt')!r}"
    )
    assert respx.calls.call_count == 5


# ──────────────────────────────────────────────────────────────────────────────
# OOS → restart in next turn
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_restart_after_oos_turn_clears_all_state():
    """When the user's response to a FOLLOW_UP_OUT_OF_SCOPE interrupt is a restart signal,
    the follow-up node must process the OOS pending prompt path, detect restart, clear all
    state, and route back to the first collector. The restart clears all collected fields,
    tracking state, and pending prompt.

    LLM sequence:
      #1  collector prompt                (T1)
      #2  collector captures 'valid_val'  (T2) → FOLLOW_UP
      #3  follow-up: OOS signal           (T3) → FOLLOW_UP_OUT_OF_SCOPE
      #4  follow-up: restart signal       (T4, OOS pending_prompt path) → restart
      #5  collector fresh prompt          (T4, after restart routing)
    """
    responses = iter([
        collector_prompt(),
        collector_capture("valid_val"),
        fu_out_of_scope("off_topic", "Can't help."),    # LLM#3 — OOS
        fu_restart("Let's start over."),                # LLM#4 — restart after OOS
        collector_prompt("Fresh start. Enter field A."),# LLM#5 — after restart
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="valid_val", initial_context={})          # T2 → FOLLOW_UP
    result3 = tool.execute(thread_id=tid, user_message="unrelated", initial_context={})    # T3 → OOS
    result4 = tool.execute(thread_id=tid, user_message="start over", initial_context={})   # T4 → USER_INPUT

    assert InterruptType.FOLLOW_UP_OUT_OF_SCOPE in str(result3)
    assert InterruptType.USER_INPUT in str(result4), (
        f"T4 must route to first collector after restart. Got: {result4}"
    )

    s = snap(tool, tid)
    assert s.get("field_a") is None, "field_a must be None after restart"
    assert s.get("_outcome_id") is None, "_outcome_id must be None after restart"
    assert s.get("_follow_up_active") is None, "_follow_up_active must be None after restart"
    assert s.get("_follow_up_pending_prompt") is None, (
        "_follow_up_pending_prompt must be None after restart"
    )
    assert respx.calls.call_count == 5


# ──────────────────────────────────────────────────────────────────────────────
# Chained intent_changes (two rollbacks in one thread)
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_chained_intent_changes_both_rollbacks_succeed():
    """When the user performs two consecutive intent_change rollbacks within the same
    workflow thread, both must succeed without state corruption. The second rollback
    must use STATE_HISTORY snapshots from the second collection run, not the first.

    Flow:
      1st collection → outcome_success ("old_val")
      → intent_change → re-collect ("new_val_1")
      → 2nd outcome ("new_val_1")
      → intent_change again → re-collect ("new_val_2")
      → 3rd outcome ("new_val_2")

    The final FOLLOW_UP must reflect 'new_val_2', not either of the prior values.
    """
    responses = iter([
        collector_prompt(),                                    # LLM#1
        collector_capture("old_val"),                          # LLM#2
        fu_intent_change("collect_a", "Let me redo once."),   # LLM#3 — 1st intent_change
        collector_prompt("Re-enter field A (1st)."),           # LLM#4
        collector_capture("new_val_1"),                        # LLM#5
        fu_intent_change("collect_a", "Let me redo again."),  # LLM#6 — 2nd intent_change
        collector_prompt("Re-enter field A (2nd)."),           # LLM#7
        collector_capture("new_val_2"),                        # LLM#8
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                                        # T1 → LLM#1
    result2 = tool.execute(thread_id=tid, user_message="old_val", initial_context={})      # T2 → LLM#2 → FOLLOW_UP
    result3 = tool.execute(thread_id=tid, user_message="redo1", initial_context={})        # T3 → LLM#3 + LLM#4 → USER_INPUT
    result4 = tool.execute(thread_id=tid, user_message="new_val_1", initial_context={})    # T4 → LLM#5 → FOLLOW_UP
    result5 = tool.execute(thread_id=tid, user_message="redo2", initial_context={})        # T5 → LLM#6 + LLM#7 → USER_INPUT
    result6 = tool.execute(thread_id=tid, user_message="new_val_2", initial_context={})    # T6 → LLM#8 → FOLLOW_UP

    assert InterruptType.FOLLOW_UP in str(result2)
    assert "old_val" in str(result2)

    assert InterruptType.USER_INPUT in str(result3), "1st rollback must route to collector"
    assert InterruptType.FOLLOW_UP in str(result4)
    assert "new_val_1" in str(result4), (
        f"2nd FOLLOW_UP must contain new_val_1. Got: {result4}"
    )

    assert InterruptType.USER_INPUT in str(result5), "2nd rollback must route to collector"
    assert InterruptType.FOLLOW_UP in str(result6)
    assert "new_val_2" in str(result6), (
        f"3rd FOLLOW_UP must contain new_val_2. Got: {result6}"
    )
    assert "old_val" not in str(result6) and "new_val_1" not in str(result6), (
        f"3rd FOLLOW_UP must not contain prior values. Got: {result6}"
    )

    s = snap(tool, tid)
    assert s.get("_outcome_id") == "outcome_success"
    assert s.get("_follow_up_active") is True
    assert respx.calls.call_count == 8


# ──────────────────────────────────────────────────────────────────────────────
# Attempt counter reset verified by Q&A in the new session
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_attempt_counter_reset_after_intent_change_new_session_runs_to_limit():
    """After intent_change rollback + re-collection, the attempt counter must be None in
    the new session. This test verifies the reset by running Q&A turns in the new session
    up to max_attempts (3), confirming all turns succeed without premature termination.

    If the counter was NOT reset, session-2 attempts would accumulate on top of the prior
    session's count and hit max_attempts earlier than expected.

    Session 1: 2 Q&A turns (attempts 1, 2), then intent_change (attempt 3, allowed).
    Session 2: 3 Q&A turns must all succeed (counter reset to None → fresh 1, 2, 3).
    4th session-2 turn must terminate (4 > max_attempts=3).
    """
    responses = iter([
        collector_prompt(),                                  # LLM#1
        collector_capture("val1"),                           # LLM#2 → FOLLOW_UP
        fu_answer("S1 answer 1."),                          # LLM#3 — session 1, attempt 1
        fu_answer("S1 answer 2."),                          # LLM#4 — session 1, attempt 2
        fu_intent_change("collect_a", "Let me redo."),      # LLM#5 — session 1, attempt 3 (3 not > 3)
        collector_prompt("Re-enter field A."),              # LLM#6 — after rollback
        collector_capture("val2"),                           # LLM#7 → new FOLLOW_UP
        fu_answer("S2 answer 1."),                          # LLM#8 — session 2, attempt 1 (not 4!)
        fu_answer("S2 answer 2."),                          # LLM#9 — session 2, attempt 2
        fu_answer("S2 answer 3."),                          # LLM#10 — session 2, attempt 3 (3 not > 3)
        # No LLM#11: session 2, attempt 4 > max_attempts=3 → terminated before LLM call
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml")
    tid = str(uuid.uuid4())

    # Session 1: 2 Q&A + intent_change
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val1", initial_context={})           # T2 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="q1", initial_context={})             # T3 — attempt 1
    tool.execute(thread_id=tid, user_message="q2", initial_context={})             # T4 — attempt 2
    result_ic = tool.execute(thread_id=tid, user_message="redo", initial_context={})  # T5 — attempt 3 → USER_INPUT
    assert InterruptType.USER_INPUT in str(result_ic)

    # Re-collection
    result_fu2 = tool.execute(thread_id=tid, user_message="val2", initial_context={})  # T6 → new FOLLOW_UP
    assert InterruptType.FOLLOW_UP in str(result_fu2)

    # Session 2: 3 Q&A turns must all succeed (counter reset)
    s2_q1 = tool.execute(thread_id=tid, user_message="s2q1", initial_context={})   # T7 — s2 attempt 1
    s2_q2 = tool.execute(thread_id=tid, user_message="s2q2", initial_context={})   # T8 — s2 attempt 2
    s2_q3 = tool.execute(thread_id=tid, user_message="s2q3", initial_context={})   # T9 — s2 attempt 3

    for idx, result in enumerate([s2_q1, s2_q2, s2_q3], start=1):
        assert InterruptType.FOLLOW_UP in str(result), (
            f"Session 2 Q&A turn {idx} returned '{result}' instead of FOLLOW_UP. "
            f"If the attempt counter was not reset after intent_change, attempt counter "
            f"would be {2+idx} at this point which would exceed max_attempts=3."
        )

    # Session 2, turn 4: must terminate (4 > max_attempts=3)
    s2_q4 = tool.execute(thread_id=tid, user_message="s2q4", initial_context={})   # T10 — s2 attempt 4
    assert InterruptType.FOLLOW_UP not in str(s2_q4), (
        f"Session 2, turn 4 should terminate — attempt 4 > max_attempts=3. Got: {s2_q4}"
    )
    assert "Max attempts reached. Goodbye." in str(s2_q4)
    assert respx.calls.call_count == 10


# ──────────────────────────────────────────────────────────────────────────────
# Attempt counter reset after restart verified by Q&A
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_attempt_counter_reset_after_restart_new_session_runs_to_limit():
    """After restart + re-collection, the attempt counter must be None in the new session.
    This test verifies the reset by running Q&A turns up to max_attempts (3) in the new
    session, confirming all turns succeed without premature termination.

    Session 1: 2 Q&A turns, then restart signal.
    Session 2 (after re-collection): 3 Q&A turns must all succeed (counter reset → 1, 2, 3).
    4th session-2 turn must terminate (4 > max_attempts=3).
    """
    responses = iter([
        collector_prompt(),                              # LLM#1
        collector_capture("val1"),                       # LLM#2 → FOLLOW_UP
        fu_answer("S1 answer 1."),                      # LLM#3 — session 1, attempt 1
        fu_answer("S1 answer 2."),                      # LLM#4 — session 1, attempt 2
        fu_restart("Let's start over."),                # LLM#5 — restart (attempt 3, 3 not > 3)
        collector_prompt("Fresh start. Enter field A."),# LLM#6 — after restart
        collector_capture("val2"),                       # LLM#7 → new FOLLOW_UP
        fu_answer("S2 answer 1."),                      # LLM#8 — session 2, attempt 1
        fu_answer("S2 answer 2."),                      # LLM#9 — session 2, attempt 2
        fu_answer("S2 answer 3."),                      # LLM#10 — session 2, attempt 3
        # No LLM#11: attempt 4 > max_attempts=3 → terminated before LLM call
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_single_step.yaml", checkpointer=InMemorySaver())
    tid = str(uuid.uuid4())

    # Session 1: 2 Q&A + restart
    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val1", initial_context={})            # T2 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="q1", initial_context={})              # T3 — attempt 1
    tool.execute(thread_id=tid, user_message="q2", initial_context={})              # T4 — attempt 2
    result_restart = tool.execute(thread_id=tid, user_message="restart", initial_context={})  # T5 → USER_INPUT

    assert InterruptType.USER_INPUT in str(result_restart)
    s_restart = snap(tool, tid)
    assert s_restart.get("field_a") is None
    assert s_restart.get("_follow_up_active") is None
    assert s_restart.get("_follow_up_attempts") is None

    # Re-collection
    result_fu2 = tool.execute(thread_id=tid, user_message="val2", initial_context={})  # T6 → new FOLLOW_UP
    assert InterruptType.FOLLOW_UP in str(result_fu2)
    assert "val2" in str(result_fu2)

    # Session 2: 3 Q&A turns must all succeed (counter reset by restart)
    s2_q1 = tool.execute(thread_id=tid, user_message="s2q1", initial_context={})
    s2_q2 = tool.execute(thread_id=tid, user_message="s2q2", initial_context={})
    s2_q3 = tool.execute(thread_id=tid, user_message="s2q3", initial_context={})

    for idx, result in enumerate([s2_q1, s2_q2, s2_q3], start=1):
        assert InterruptType.FOLLOW_UP in str(result), (
            f"Session 2 Q&A turn {idx} must return FOLLOW_UP. "
            f"Attempt counter must be reset by restart, not carry over session 1's count. "
            f"Got: {result}"
        )

    # Turn 4 in session 2 must terminate
    s2_q4 = tool.execute(thread_id=tid, user_message="s2q4", initial_context={})
    assert "Max attempts reached. Goodbye." in str(s2_q4)
    assert InterruptType.FOLLOW_UP not in str(s2_q4)
    assert respx.calls.call_count == 10
