from unittest.mock import MagicMock
from soprano_sdk.utils.tool import wrap_state_recording
from soprano_sdk.utils.builtin_tools import make_compute_tool, MONTY_TOOL_NAME
from soprano_sdk.nodes.collect_input import CollectInputStrategy
from soprano_sdk.nodes.follow_up import FollowUpStrategy
from soprano_sdk.core.constants import WorkflowKeys

def test_grouped_recording_complex_nesting():
    """Verify that wrap_state_recording handles complex nested structures in the clubbed format."""
    state = {}
    
    @wrap_state_recording("get_complex_data", state)
    def get_complex_data(id: str, tags: list):
        return {
            "id": id,
            "metadata": {"tags": tags, "active": True},
            "scores": [10, 20, 30]
        }
    
    result = get_complex_data(id="user_1", tags=["gold", "vip"])
    
    # Check clubbed structure
    responses = state.get(WorkflowKeys.TOOL_RESPONSES, {})
    assert "get_complex_data" in responses
    data = responses["get_complex_data"]
    
    assert data["input"] == {"id": "user_1", "tags": ["gold", "vip"]}
    assert data["output"] == result
    assert data["output"]["metadata"]["active"] is True
    
    # Verify NO flat keys are present
    assert "get_complex_data_response" not in state
    assert "get_complex_data_input" not in state

def test_dynamic_resolution_all_types():
    """Verify compute tool resolves outputs of various types correctly."""
    state = {
        WorkflowKeys.TOOL_RESPONSES: {
            "fetch_list": {"input": {}, "output": [1, 2, 3]},
            "check_status": {"input": {}, "output": True},
            "get_count": {"input": {}, "output": 42},
            "get_nested": {"input": {}, "output": {"val": 100}}
        }
    }
    
    compute = make_compute_tool(state)
    
    # List access
    assert compute(code="len(fetch_list_response)") == "3"
    assert compute(code="fetch_list_response[0]") == "1"
    
    # Boolean and Int
    assert compute(code="check_status_response is True") == "True"
    assert compute(code="get_count_response + 8") == "50"
    
    # Nested dict
    assert compute(code="get_nested_response['val']") == "100"

def test_collect_input_prompt_injection_enhanced():
    """Verify collect_input prompt contains per-tool compute instructions only when enabled."""
    engine = MagicMock()
    state = {
        WorkflowKeys.TOOL_RESPONSES: {
            "calculator": {"input": {"x": 5, "y": 10}, "output": 15}
        }
    }
    
    # Case 1: Compute enabled
    config_with_compute = {
        "id": "node_1",
        "field": "test",
        "agent": {"tools": ["calculator"], "default_tools": True}
    }
    strategy_with = CollectInputStrategy(config_with_compute, engine_context=engine)
    prompt_with = strategy_with._get_instructions(state, collector_nodes={})
    
    assert "<tool_responses>" in prompt_with
    assert f"The output of 'calculator' can be accessed in the {MONTY_TOOL_NAME} tool" in prompt_with
    assert "calculator_response" in prompt_with
    
    # Case 2: Compute disabled
    config_no_compute = {
        "id": "node_2",
        "field": "test",
        "agent": {"tools": ["calculator"], "default_tools": False}
    }
    strategy_no = CollectInputStrategy(config_no_compute, engine_context=engine)
    prompt_no = strategy_no._get_instructions(state, collector_nodes={})
    
    assert "<tool_responses>" in prompt_no
    assert f"The output of calculator can be accessed in the {MONTY_TOOL_NAME} tool" not in prompt_no

def test_follow_up_prompt_injection_enhanced():
    """Verify follow_up prompt contains per-tool compute instructions correctly."""
    engine = MagicMock()
    state = {
        WorkflowKeys.TOOL_RESPONSES: {
            "get_history": {"input": {"limit": 1}, "output": [{"id": 1}]}
        }
    }
    
    # Case 1: Compute enabled
    config_with = {"tools": ["get_history", MONTY_TOOL_NAME]}
    strategy_with = FollowUpStrategy(config_with, engine_context=engine, first_step_id="start", node_id="fu")
    responses_block_with = strategy_with._build_tool_responses(state)
    
    assert "The following tools have already been called" in responses_block_with
    assert "<tool_responses>" not in responses_block_with
    assert f"The output of 'get_history' can be accessed in the {MONTY_TOOL_NAME} tool" in responses_block_with
    
    # Case 2: Compute disabled
    config_no = {"tools": ["get_history"], "default_tools": False}
    strategy_no = FollowUpStrategy(config_no, engine_context=engine, first_step_id="start", node_id="fu")
    responses_block_no = strategy_no._build_tool_responses(state)
    
    assert f"The output of get_history can be accessed in the {MONTY_TOOL_NAME} tool" not in responses_block_no

def test_compute_resolution_override_priority():
    """Verify that tool_vars override state if names collide (unlikely but safe)."""
    state = {
        "my_tool_response": "state_value",
        WorkflowKeys.TOOL_RESPONSES: {
            "my_tool": {"input": {}, "output": "tool_value"}
        }
    }
    compute = make_compute_tool(state)
    # The dynamically resolved tool_vars should win because it's merged later in make_compute_tool
    assert compute(code="my_tool_response") == "tool_value"

def test_collect_input_show_responses_toggle():
    """Verify that CollectInputStrategy respects the show_tool_responses toggle."""
    engine = MagicMock()
    state = {
        WorkflowKeys.TOOL_RESPONSES: {
            "get_history": {"input": {"id": 1}, "output": "some history"}
        }
    }
    
    # Case 1: show_tool_responses=True (default)
    config_on = {
        "field": "test_field",
        "agent": {"tools": ["get_history"], "name": "test", "instructions": "test"}
    }
    strategy_on = CollectInputStrategy(config_on, engine)
    instructions_on = strategy_on._get_instructions(state, {"node1": "desc1"})
    assert "The following tools have already been called" in instructions_on
    
    # Case 2: show_tool_responses=False
    config_off = {
        "field": "test_field",
        "agent": {"tools": ["get_history"], "show_tool_responses": False, "name": "test", "instructions": "test"}
    }
    strategy_off = CollectInputStrategy(config_off, engine)
    instructions_off = strategy_off._get_instructions(state, {"node1": "desc1"})
    assert "The following tools have already been called" not in instructions_off

def test_collect_input_per_tool_visibility():
    """Verify that CollectInputStrategy respects the per-tool include_in_prompt flag."""
    engine = MagicMock()
    # Mock the engine config to specify tool-level visibility
    engine.config = {
        "tool_config": {
            "tools": [
                {"name": "visible_tool", "include_response_in_prompt": True},
                {"name": "hidden_tool", "include_response_in_prompt": False}
            ]
        }
    }
    
    state = {
        WorkflowKeys.TOOL_RESPONSES: {
            "visible_tool": {"input": {}, "output": "visible output"},
            "hidden_tool": {"input": {}, "output": "hidden output"}
        }
    }
    
    config = {
        "field": "test_field",
        "agent": {"tools": ["visible_tool", "hidden_tool"], "name": "test", "instructions": "test"}
    }
    strategy = CollectInputStrategy(config, engine)
    instructions = strategy._get_instructions(state, {"node1": "desc1"})
    
    assert "visible_tool" in instructions
    assert "visible output" in instructions
    assert "hidden_tool" not in instructions
    assert "hidden output" not in instructions

def test_follow_up_per_tool_visibility():
    """Verify that FollowUpStrategy respects the per-tool include_in_prompt flag."""
    engine = MagicMock()
    engine.config = {
        "tool_config": {
            "tools": [
                {"name": "visible_tool", "include_response_in_prompt": True},
                {"name": "hidden_tool", "include_response_in_prompt": False}
            ]
        }
    }
    
    state = {
        WorkflowKeys.TOOL_RESPONSES: {
            "visible_tool": {"input": {}, "output": "visible output"},
            "hidden_tool": {"input": {}, "output": "hidden output"}
        }
    }
    
    config = {"tools": ["visible_tool", "hidden_tool"]}
    strategy = FollowUpStrategy(config, engine_context=engine, first_step_id="start")
    responses = strategy._build_tool_responses(state)
    
    assert "visible_tool" in responses
    assert "visible output" in responses
    assert "hidden_tool" not in responses
    assert "hidden output" not in responses

def test_follow_up_show_responses_toggle():
    """Verify that FollowUpStrategy respects the show_tool_responses toggle."""
    engine = MagicMock()
    state = {
        WorkflowKeys.TOOL_RESPONSES: {
            "get_history": {"input": {"id": 1}, "output": "some history"}
        }
    }
    
    # Case 1: show_tool_responses=True (default)
    config_on = {"tools": ["get_history"]}
    strategy_on = FollowUpStrategy(config_on, engine_context=engine, first_step_id="start")
    responses_on = strategy_on._build_tool_responses(state)
    assert "The following tools have already been called" in responses_on
    
    # Case 2: show_tool_responses=False
    config_off = {"tools": ["get_history"], "show_tool_responses": False}
    strategy_off = FollowUpStrategy(config_off, engine_context=engine, first_step_id="start")
    responses_off = strategy_off._build_tool_responses(state)
    assert responses_off == ""
