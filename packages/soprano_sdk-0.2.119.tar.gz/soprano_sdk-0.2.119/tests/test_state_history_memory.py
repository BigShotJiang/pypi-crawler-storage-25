"""
Regression test for geometric memory growth in _state_history.

Previously, save_snapshot() deep-copied the entire state including _state_history
(all prior snapshots), causing each new snapshot to recursively nest all previous
ones — O(2^n) memory growth. With 15 snapshots: 15KB -> 150MB. With 20: ~4.8GB OOM.

The fix excludes _state_history from the deep copy. This test ensures growth stays linear.
"""
import sys
import json

from soprano_sdk.core.constants import WorkflowKeys
from soprano_sdk.core.rollback_strategies import HistoryBasedRollback


def _build_realistic_state(num_fields=5):
    """Build a state dict that resembles a real SOP mid-execution."""
    state = {
        WorkflowKeys.STATE_HISTORY: [],
        WorkflowKeys.CONVERSATIONS: {},
        WorkflowKeys.NODE_EXECUTION_ORDER: [],
        WorkflowKeys.NODE_FIELD_MAP: {},
        WorkflowKeys.ATTEMPT_COUNTS: {},
        WorkflowKeys.PARTIAL_DATA: {},
        WorkflowKeys.MESSAGES: [],
        WorkflowKeys.COLLECTOR_NODES: {},
    }
    for i in range(num_fields):
        field = f"field_{i}"
        state[field] = f"value_{i}_" + ("x" * 500)
        conv_key = f"{field}_conversation"
        state[WorkflowKeys.CONVERSATIONS][conv_key] = [
            {"role": "assistant", "content": f"Please provide {field}. " + ("context " * 50)},
            {"role": "user", "content": f"Here is my {field}: some user input " + ("detail " * 30)},
            {"role": "assistant", "content": json.dumps({"field": field, "value": f"value_{i}", "message": "Got it. " + ("confirm " * 40)})},
        ]
        state[WorkflowKeys.NODE_EXECUTION_ORDER].append(f"collect_{field}")
        state[WorkflowKeys.NODE_FIELD_MAP][f"collect_{field}"] = field
    return state


def _get_deep_size(obj, seen=None):
    """Recursively calculate the approximate memory size of a Python object."""
    if seen is None:
        seen = set()
    obj_id = id(obj)
    if obj_id in seen:
        return 0
    seen.add(obj_id)
    size = sys.getsizeof(obj)
    if isinstance(obj, dict):
        for k, v in obj.items():
            size += _get_deep_size(k, seen) + _get_deep_size(v, seen)
    elif isinstance(obj, (list, tuple, set, frozenset)):
        for item in obj:
            size += _get_deep_size(item, seen)
    return size


def test_state_history_growth_is_linear():
    """Ensure save_snapshot does not cause geometric memory growth.

    Regression test: with the bug, 15 snapshots produced 7600x growth.
    With the fix, growth should be well under 15x (linear).
    """
    state = _build_realistic_state(num_fields=5)
    strategy = HistoryBasedRollback()

    num_snapshots = 15
    sizes = []

    for i in range(num_snapshots):
        strategy.save_snapshot(state, f"collect_step_{i}", i)
        sizes.append(_get_deep_size(state))

    growth_ratio = sizes[-1] / sizes[0]
    assert growth_ratio < num_snapshots * 2, (
        f"State history growth is not linear: {growth_ratio:.1f}x over {num_snapshots} snapshots. "
        f"This likely means _state_history is being recursively nested inside snapshots."
    )


def test_snapshot_does_not_contain_state_history():
    """Verify that individual snapshots don't include _state_history."""
    state = _build_realistic_state(num_fields=3)
    strategy = HistoryBasedRollback()

    strategy.save_snapshot(state, "step_a", 0)
    strategy.save_snapshot(state, "step_b", 1)

    history = state[WorkflowKeys.STATE_HISTORY]
    for snapshot in history:
        assert WorkflowKeys.STATE_HISTORY not in snapshot['state'], (
            f"Snapshot '{snapshot['node_about_to_execute']}' contains _state_history — "
            f"this causes recursive nesting and geometric memory growth."
        )


def test_rollback_still_works_without_nested_history():
    """Verify rollback functions correctly when snapshots exclude _state_history."""
    state = _build_realistic_state(num_fields=3)
    strategy = HistoryBasedRollback()

    workflow_steps = [
        {'id': 'step_a', 'action': 'collect_input_with_agent', 'field': 'field_0'},
        {'id': 'step_b', 'action': 'collect_input_with_agent', 'field': 'field_1'},
        {'id': 'step_c', 'action': 'collect_input_with_agent', 'field': 'field_2'},
    ]

    # Save snapshots at each step
    for i, step in enumerate(workflow_steps):
        strategy.save_snapshot(state, step['id'], i)
        state[f"field_{i}"] = f"collected_value_{i}"

    # Roll back to step_b — should restore state before step_b executed
    restored = strategy.rollback_to_node(
        state, 'step_b',
        node_execution_order=['step_a', 'step_b', 'step_c'],
        node_field_map={'step_a': 'field_0', 'step_b': 'field_1', 'step_c': 'field_2'},
        workflow_steps=workflow_steps,
    )

    assert restored, "Rollback returned empty dict — snapshot lookup failed"
    # field_0 should have been collected before step_b's snapshot
    assert restored.get('field_0') == 'collected_value_0'
    # field_1 should NOT have the post-snapshot value (it was set after step_b's snapshot)
    assert restored.get('field_1') != 'collected_value_1'
