"""Tests for the agent factory module."""

import sys
import os

import pytest
from unittest.mock import MagicMock, patch
from soprano_sdk.agents.factory import (
    AgentFactory,
    AgentAdapter,
    LangGraphAgentCreator,
    LangGraphAgentAdapter,
    CrewAIAgentCreator,
    CrewAIAgentAdapter,
    AgnoAgentCreator,
    AgnoAgentAdapter,
    PydanticAIAgentCreator,
    InstructorStructuredLLM,
    get_model,
)


class TestAgentFactory:
    """Test suite for AgentFactory."""
    
    def test_get_creator_langgraph(self):
        """Test that factory returns LangGraph creator for 'langgraph'."""
        creator = AgentFactory.get_creator("langgraph")
        assert isinstance(creator, LangGraphAgentCreator)
    
    def test_get_creator_langgraph_case_insensitive(self):
        """Test that framework names are case-insensitive."""
        creator = AgentFactory.get_creator("LangGraph")
        assert isinstance(creator, LangGraphAgentCreator)
    
    def test_get_creator_crewai(self):
        """Test that factory returns CrewAI creator for 'crewai'."""
        creator = AgentFactory.get_creator("crewai")
        assert isinstance(creator, CrewAIAgentCreator)
    
    def test_get_creator_agno(self):
        """Test that factory returns Agno creator for 'agno'."""
        creator = AgentFactory.get_creator("agno")
        assert isinstance(creator, AgnoAgentCreator)
    
    def test_get_creator_pydantic_ai(self):
        """Test that factory returns Pydantic-AI creator for 'pydantic-ai'."""
        creator = AgentFactory.get_creator("pydantic-ai")
        assert isinstance(creator, PydanticAIAgentCreator)
    
    def test_get_creator_invalid_framework(self):
        """Test that factory raises ValueError for invalid framework."""
        with pytest.raises(ValueError) as exc_info:
            AgentFactory.get_creator("invalid_framework")
        
        assert "Unsupported agent framework" in str(exc_info.value)
        assert "invalid_framework" in str(exc_info.value)
        assert "langgraph" in str(exc_info.value)  # Should list supported frameworks
    
    def test_create_agent_langgraph_returns_adapter(self):
        """Test that factory returns an adapter when creating LangGraph agent."""
        adapter = AgentFactory.create_agent(
            framework="langgraph",
            name="TestAgent",
            model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
            tools=[],
            system_prompt="Test prompt",
            structured_output_model=None
        )
        
        # Should return an adapter, not raw agent
        assert isinstance(adapter, AgentAdapter)
        assert isinstance(adapter, LangGraphAgentAdapter)
        assert hasattr(adapter, 'invoke')


class TestLangGraphAgentAdapter:
    """Test suite for LangGraphAgentAdapter."""
    
    def test_adapter_has_invoke_method(self):
        """Test that adapter has invoke method."""
        creator = LangGraphAgentCreator()        
        adapter = creator.create_agent(
            name="TestAgent",
            model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
            tools=[],
            system_prompt="Test prompt"
        )
        
        assert isinstance(adapter, LangGraphAgentAdapter)
        assert hasattr(adapter, 'invoke')
        assert callable(adapter.invoke)
    
    def test_adapter_invoke_returns_standardized_format(self):
        """Test that adapter invoke returns standardized response format."""
        # Create a mock agent
        mock_agent = MagicMock()
        mock_message = MagicMock()
        mock_message.content = "Test response"
        mock_agent.invoke.return_value = {"messages": [mock_message]}
        
        adapter = LangGraphAgentAdapter(mock_agent)
        
        result = adapter.invoke([{"role": "user", "content": "Hello"}])
        
        # Check standardized format
        # Check standardized format
        assert isinstance(result, str)
        assert result == "Test response"
    
    def test_adapter_invoke_raises_on_missing_messages(self):
        """Test that adapter raises ValueError when response missing messages."""
        mock_agent = MagicMock()
        mock_agent.invoke.return_value = {}
        
        adapter = LangGraphAgentAdapter(mock_agent)
        
        with pytest.raises(ValueError, match="Agent response missing 'messages'"):
            adapter.invoke([{"role": "user", "content": "Hello"}])


class TestPlaceholderAgentAdapters:
    """Test suite for placeholder agent adapters (CrewAI, Agno, Pydantic-AI)."""
    
    def test_crewai_adapter_raises_import_error(self):
        """Test that CrewAI creator raises ImportError if crewai not installed."""
        creator = CrewAIAgentCreator()        
        # Should raise ImportError if crewai package is not installed
        try:
            adapter = creator.create_agent(
                name="TestAgent",
                model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
                tools=[],
                system_prompt="Test"
            )
            # If we get here, crewai is installed - test the adapter
            assert isinstance(adapter, CrewAIAgentAdapter)
        except ImportError as e:
            assert "crewai" in str(e).lower()
    
    def test_crewai_adapter_has_thought_action_guardrail_by_default(self):
        """ThoughtActionGuardrail is always the first guardrail for CrewAI agents."""
        from soprano_sdk.guardrails.functional_guardrail import ThoughtActionGuardrail

        creator = CrewAIAgentCreator()
        try:
            adapter = creator.create_agent(
                name="TestAgent",
                model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
                tools=[],
                system_prompt="Test",
            )
            assert len(adapter.guardrails) >= 1
            thought_action_guardrails = [
                g for g in adapter.guardrails if isinstance(g, ThoughtActionGuardrail)
            ]
            assert len(thought_action_guardrails) == 1, (
                "CrewAI adapter must have exactly one ThoughtActionGuardrail"
            )
        except ImportError:
            pass  # crewai not installed in this environment

    def test_crewai_adapter_does_not_duplicate_thought_action_guardrail(self):
        """If ThoughtActionGuardrail already passed explicitly, it is not added again."""
        from soprano_sdk.guardrails.functional_guardrail import ThoughtActionGuardrail

        creator = CrewAIAgentCreator()
        existing = ThoughtActionGuardrail(error_message="custom")
        try:
            adapter = creator.create_agent(
                name="TestAgent",
                model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
                tools=[],
                system_prompt="Test",
                guardrails=[existing],
            )
            thought_action_count = sum(
                1 for g in adapter.guardrails if isinstance(g, ThoughtActionGuardrail)
            )
            assert thought_action_count == 1
            # The configured instance (not the default) should be in the list
            assert any(g is existing for g in adapter.guardrails)
        except ImportError:
            pass

    def test_agno_adapter_raises_import_error(self):
        """Test that Agno creator raises ImportError if agno not installed."""
        creator = AgnoAgentCreator()
        # Should raise ImportError if agno package is not installed
        try:
            adapter = creator.create_agent(
                name="TestAgent",
                model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
                tools=[],
                system_prompt="Test",
            )
            # If we get here, agno is installed - test the adapter
            assert isinstance(adapter, AgnoAgentAdapter)
        except ImportError as e:
            assert "agno" in str(e).lower()
    def test_dynamic_guardrail_injection_without_structured_output(self):
        """Test that StructuredOutputGuardrail is NOT injected when schema and fields are absent."""
        from soprano_sdk.guardrails.functional_guardrail import StructuredOutputGuardrail
        creator = LangGraphAgentCreator()
        adapter = creator.create_agent(
            name="TestAgent",
            model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
            tools=[],
            system_prompt="Test",
        )
        assert not any(isinstance(g, StructuredOutputGuardrail) for g in adapter.guardrails)

    def test_dynamic_guardrail_injection_with_output_schema(self):
        """Test that StructuredOutputGuardrail IS injected when output_schema is provided."""
        from pydantic import BaseModel
        from soprano_sdk.guardrails.functional_guardrail import StructuredOutputGuardrail
        
        class DummySchema(BaseModel):
            field: str
            
        creator = LangGraphAgentCreator()
        adapter = creator.create_agent(
            name="TestAgent",
            model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
            tools=[],
            system_prompt="Test",
            structured_output_model=DummySchema,
        )
        assert any(isinstance(g, StructuredOutputGuardrail) for g in adapter.guardrails)

    def test_dynamic_guardrail_injection_with_required_fields(self):
        """Test that StructuredOutputGuardrail IS injected when required_fields are provided."""
        from soprano_sdk.guardrails.functional_guardrail import StructuredOutputGuardrail
        
        creator = LangGraphAgentCreator()
        adapter = creator.create_agent(
            name="TestAgent",
            model_config={"model_name": "gpt-4", "api_key": "key", "base_url": "url"},
            tools=[],
            system_prompt="Test",
            required_fields=["captured"],
        )
        assert any(isinstance(g, StructuredOutputGuardrail) for g in adapter.guardrails)



def _mock_langchain_aws():
    """Context manager that mocks langchain_aws if not installed."""
    mock_module = MagicMock()
    mock_cbc = MagicMock()
    mock_module.ChatBedrockConverse = mock_cbc
    return patch.dict(sys.modules, {"langchain_aws": mock_module}), mock_cbc


class TestGetModelBedrock:
    """Test suite for Bedrock provider support via ChatBedrockConverse and instructor."""

    def test_bedrock_no_api_key_required(self):
        """Test that bedrock provider does not require an API key."""
        env_overrides = {"AWS_ACCESS_KEY_ID": "", "AWS_SECRET_ACCESS_KEY": "", "AWS_REGION_NAME": ""}
        mock_aws, mock_cbc = _mock_langchain_aws()
        mock_cbc.return_value = MagicMock()
        with mock_aws, \
             patch.dict(os.environ, env_overrides), \
             patch("soprano_sdk.agents.factory.SessionRegistry") as mock_reg:
            mock_reg.get_or_create.return_value = MagicMock()
            config = {"model_name": "anthropic.claude-3-sonnet-20240229-v1:0", "provider": "bedrock"}
            get_model(config)
            call_kwargs = mock_cbc.call_args[1]
            assert call_kwargs["model_id"] == "anthropic.claude-3-sonnet-20240229-v1:0"

    def test_bedrock_model_id_passed_directly(self):
        """Test that bare model ID is passed to ChatBedrockConverse (no litellm prefix)."""
        mock_aws, mock_cbc = _mock_langchain_aws()
        mock_cbc.return_value = MagicMock()
        with mock_aws, patch("soprano_sdk.agents.factory.SessionRegistry") as mock_reg:
            mock_reg.get_or_create.return_value = MagicMock()
            config = {"model_name": "anthropic.claude-3-haiku-20240307-v1:0", "provider": "bedrock"}
            get_model(config)
            call_kwargs = mock_cbc.call_args[1]
            assert call_kwargs["model_id"] == "anthropic.claude-3-haiku-20240307-v1:0"

    def test_openai_still_uses_chatopenai(self):
        """Test that openai provider continues to use ChatOpenAI."""
        from langchain_openai import ChatOpenAI
        config = {"model_name": "gpt-4o-mini", "provider": "openai", "api_key": "sk-test"}
        model = get_model(config)
        assert isinstance(model, ChatOpenAI)

    def test_ollama_still_uses_chatopenai(self):
        """Test that ollama provider continues to use ChatOpenAI."""
        from langchain_openai import ChatOpenAI
        config = {"model_name": "llama3.2", "provider": "ollama"}
        model = get_model(config)
        assert isinstance(model, ChatOpenAI)

    def test_agno_with_bedrock_raises_error(self):
        """Test that agno framework with bedrock raises a clear error."""
        config = {"model_name": "anthropic.claude-3-sonnet-20240229-v1:0", "provider": "bedrock"}
        with pytest.raises(ValueError, match="not supported with the 'agno' framework"):
            get_model(config, framework="agno")

    def test_bedrock_structured_output_returns_instructor_wrapper(self):
        """Test that structured output on bedrock returns an InstructorStructuredLLM."""
        from pydantic import BaseModel, Field

        class TestOutput(BaseModel):
            answer: str = Field(description="test")

        mock_aws, _ = _mock_langchain_aws()
        with mock_aws:
            config = {"model_name": "anthropic.claude-3-sonnet-20240229-v1:0", "provider": "bedrock"}
            result = get_model(config, output_schema=TestOutput)
            assert isinstance(result, InstructorStructuredLLM)

    def test_bedrock_with_tools(self):
        """Test that tool binding works with ChatBedrockConverse."""
        mock_aws, mock_cbc = _mock_langchain_aws()
        mock_llm = MagicMock()
        mock_cbc.return_value = mock_llm
        tools = [MagicMock()]
        with mock_aws, patch("soprano_sdk.agents.factory.SessionRegistry") as mock_reg:
            mock_reg.get_or_create.return_value = MagicMock()
            config = {"model_name": "anthropic.claude-3-sonnet-20240229-v1:0", "provider": "bedrock"}
            get_model(config, tools=tools)
            mock_llm.bind_tools.assert_called_once_with(tools)

    def test_bedrock_with_base_url(self):
        """Test that base_url is passed as endpoint_url to the boto3 client."""
        mock_aws, mock_cbc = _mock_langchain_aws()
        mock_cbc.return_value = MagicMock()
        with mock_aws, \
             patch("soprano_sdk.agents.factory.SessionRegistry") as mock_registry:
            mock_session = MagicMock()
            mock_registry.get_or_create.return_value = mock_session
            config = {
                "model_name": "anthropic.claude-3-sonnet-20240229-v1:0",
                "provider": "bedrock",
                "base_url": "https://custom-endpoint.example.com",
            }
            get_model(config)
            call_kwargs = mock_session.client.call_args[1]
            assert call_kwargs["endpoint_url"] == "https://custom-endpoint.example.com"

    def test_bedrock_credentials_passed_to_session(self):
        """Test that AWS credentials from config are passed to the boto3 session."""
        mock_aws, mock_cbc = _mock_langchain_aws()
        mock_cbc.return_value = MagicMock()
        with mock_aws, \
             patch("soprano_sdk.agents.factory.SessionRegistry") as mock_registry:
            mock_session = MagicMock()
            mock_registry.get_or_create.return_value = mock_session
            config = {
                "model_name": "anthropic.claude-3-sonnet-20240229-v1:0",
                "provider": "bedrock",
                "aws_access_key_id": "test-key",
                "aws_secret_access_key": "test-secret",
                "aws_region_name": "us-east-1",
            }
            get_model(config)
            call_kwargs = mock_registry.get_or_create.call_args[1]
            assert call_kwargs["aws_access_key_id"] == "test-key"
            assert call_kwargs["region_name"] == "us-east-1"

    def test_bedrock_crewai_credentials_passed_to_llm(self):
        """Test that AWS credentials are passed to crewai LLM for crewai path."""
        with patch("soprano_sdk.agents.factory.LLM") as mock_llm_cls:
            config = {
                "model_name": "anthropic.claude-3-sonnet-20240229-v1:0",
                "provider": "bedrock",
                "aws_access_key_id": "crewai-key",
                "aws_secret_access_key": "crewai-secret",
                "aws_region_name": "eu-west-1",
            }
            get_model(config, framework="crewai")
            call_kwargs = mock_llm_cls.call_args[1]
            assert call_kwargs.get("aws_access_key_id") == "crewai-key"
            assert call_kwargs.get("aws_region_name") == "eu-west-1"

    def test_bedrock_langgraph_does_not_set_litellm_globals(self):
        """Test that langgraph framework does not set litellm module globals."""
        mock_aws, mock_cbc = _mock_langchain_aws()
        mock_cbc.return_value = MagicMock()
        with mock_aws, \
             patch("soprano_sdk.agents.factory.SessionRegistry"):
            # Should not raise — litellm globals are not touched for langgraph
            config = {
                "model_name": "anthropic.claude-3-sonnet-20240229-v1:0",
                "provider": "bedrock",
                "aws_access_key_id": "test-key",
            }
            get_model(config)  # no assertion needed, just verify no AttributeError
