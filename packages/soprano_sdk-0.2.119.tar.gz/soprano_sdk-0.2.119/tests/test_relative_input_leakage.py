import pytest
from uuid import uuid4
from soprano_sdk.tools import WorkflowTool

import tempfile
import os

import respx
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    llm_structured_response,
)

WORKFLOW_YAML = """
version: "1.0"
name: test_relative_leakage
description: Test workflow for relative input leakage
data:
  - name: category
    type: text
    description: "category"
  - name: brand
    type: text
    description: "brand"
  - name: dummy
    type: text
    description: "dummy"
steps:
  - id: step_category
    action: collect_input_with_agent
    field: category
    options:
      - Mobile
      - Laptop
      - Tablet
    agent:
      name: categoryAgent
      description: Collecting category
      instructions: "Please select a category."
      structured_output:
        enabled: true
        fields:
          - name: category
            type: text
            description: "The product category."
    next: step_brand

  - id: step_brand
    action: collect_input_with_agent
    field: brand
    options:
      - Apple
      - Samsung
      - Sony
    agent:
      name: brandAgent
      description: Collecting brand
      instructions: "Please select a brand."
      structured_output:
        enabled: true
        fields:
          - name: brand
            type: text
            description: "The product brand."

  - id: step_end
    action: collect_input_with_agent
    field: dummy
    agent:
      name: dummyAgent
      description: End
      instructions: "done."

outcomes:
  - id: success_outcome
    type: success
    target: __end__
    message: "Done."
"""

@pytest.fixture
def workflow_yaml():
    fd, path = tempfile.mkstemp(suffix=".yaml")
    with os.fdopen(fd, 'w') as f:
        f.write(WORKFLOW_YAML)
    yield path
    os.remove(path)

@respx.mock
def test_relative_input_leakage(workflow_yaml):
    responses = iter([
        # category agent: prompt
        llm_structured_response({
            "bot_response": "Please select a category.",
            "category": None
        }),
        # category agent: capture (user says "the 3rd option")
        llm_structured_response({
            "bot_response": None,
            "category": "Tablet"
        }),
        # brand agent: prompt (should NOT consume "the 3rd option" from USER_MESSAGE)
        llm_structured_response({
            "bot_response": "Please select a brand.",
            "brand": None
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    config = {
        "model_config": {
            "model_name": "gpt-4o-mini",
            "provider": "openai",
            "api_key": "fake",
            "base_url": "http://fake-llm/v1"
        }
    }
    tool = WorkflowTool(yaml_path=workflow_yaml, name="test", description="test", config=config)
    thread_id = str(uuid4())

    # Step 1: Start workflow (should interrupt at category)
    result1 = tool.execute(thread_id=thread_id, initial_context={})
    assert "__WORKFLOW_INTERRUPT__" in str(result1)
    
    # User provides a relative answer to Step 1
    # We say "Tablet", which should map to "Tablet" in step_category
    result2 = tool.execute(thread_id=thread_id, user_message="the 3rd option", initial_context={})    

    # After step_category completes, it transitions to step_brand.
    # step_brand SHOULD NOT consume "the 3rd option" as its own brand ("Sony").
    # It should interrupt and ask for the brand.
    assert "brand" in str(result2)
    assert "__WORKFLOW_INTERRUPT__" in str(result2), f"Expected interrupt at brand, but got {result2}"
