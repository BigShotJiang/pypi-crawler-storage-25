import uuid
import respx
from soprano_sdk.core.constants import InterruptType, WorkflowKeys

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    make_tool,
    snap,
)

def _get_val(state, key):
    val = state.get(key)
    if isinstance(val, dict) and key in val:
        return val[key]
    return val

@respx.mock
def test_routing_to_end_when_global_follow_up_disabled():
    """Verify that an error routes to the 'error' node, which then terminates with END when global follow-up is OFF."""
    responses = iter([
        collector_prompt("Please provide A."),
        collector_capture("val_a"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_routing_err_disabled_global.yaml")
    tid = str(uuid.uuid4())

    # 1. Entry -> collect_a prompt
    tool.execute(thread_id=tid, initial_context={})

    # 2. Provide A -> Transitions to func_1 (success) -> routes to 'end_success' outcome -> END
    res2 = tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    
    # Verify it reached END (no follow-up interrupt)
    assert InterruptType.FOLLOW_UP not in str(res2)
    assert InterruptType.USER_INPUT not in str(res2)
    
    s = snap(tool, tid)
    assert s.get(WorkflowKeys.OUTCOME_ID) == "end_success"
    # Ensure it's not active
    assert s.get(WorkflowKeys.FOLLOW_UP_ACTIVE) is not True

@respx.mock
def test_routing_to_end_when_outcome_follow_up_disabled():
    """Verify that routing to an outcome with follow_up: false terminates with END."""
    responses = iter([
        collector_prompt("Please provide A."),
        collector_capture("val_a"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_routing_err_disabled_outcome.yaml")
    tid = str(uuid.uuid4())

    # 1. Entry -> collect_a prompt
    tool.execute(thread_id=tid, initial_context={})

    # 2. Provide A -> Transitions to func_error (raises) -> routes to 'end_failed' outcome -> END
    res2 = tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    
    # Verify it reached END
    assert InterruptType.FOLLOW_UP not in str(res2)
    
    s = snap(tool, tid)
    assert s.get(WorkflowKeys.OUTCOME_ID) == "end_failed"
    assert s.get(WorkflowKeys.FOLLOW_UP_ACTIVE) is not True

@respx.mock
def test_fallback_to_default_error_outcome_with_follow_up():
    """Verify that unknown routing fallback still results in a follow-up if enabled."""
    responses = iter([
        collector_prompt("Please provide A."),
        collector_capture("val_a"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_routing_err_no_match.yaml")
    tid = str(uuid.uuid4())

    # 1. Entry -> collect_a prompt
    tool.execute(thread_id=tid, initial_context={})

    # 2. Provide A -> func_no_match returns unknown status -> routes to virtual 'error' node -> FOLLOW_UP
    res2 = tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    
    assert InterruptType.FOLLOW_UP in str(res2)
    
    s = snap(tool, tid)
    assert s.get(WorkflowKeys.OUTCOME_ID) == WorkflowKeys.ERROR
    assert s.get(WorkflowKeys.FOLLOW_UP_ACTIVE) is True

@respx.mock
def test_multiple_soft_errors_then_success_routing():
    """Verify that multiple nodes setting 'error' in state don't trigger error outcome if flow continues."""
    responses = iter([
        collector_prompt("Please provide A."),
        collector_capture("val_a"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_routing_err_soft_consecutive.yaml")
    tid = str(uuid.uuid4())

    # 1. Entry -> collect_a prompt
    tool.execute(thread_id=tid, initial_context={})

    # 2. Provide A -> Transitions to func_err_1 (soft error) -> func_err_2 (soft error) -> end_success
    res2 = tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    
    # It should reach success because each node set a valid next status
    assert "Workflow finished successfully." in str(res2)
    assert InterruptType.FOLLOW_UP in str(res2)
    
    s = snap(tool, tid)
    assert s.get("error") == "Something went wrong"
    assert s.get(WorkflowKeys.OUTCOME_ID) == "end_success"
    assert s.get(WorkflowKeys.FOLLOW_UP_ACTIVE) is True

@respx.mock
def test_explicit_error_outcome_override_routing():
    """Verify that a YAML-defined 'error' outcome overrides the virtual one."""
    responses = iter([
        collector_prompt("Please provide A."),
        collector_capture("val_a"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_routing_err_explicit_outcome.yaml")
    tid = str(uuid.uuid4())

    # 1. Entry -> collect_a prompt
    tool.execute(thread_id=tid, initial_context={})

    # 2. Provide A -> Transitions to func_error (raises exception) -> routes to 'error' outcome
    res2 = tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    
    # It should use the message from the YAML outcome, which has follow_up: false
    assert "This is an explicit YAML error message." in str(res2)
    assert InterruptType.FOLLOW_UP not in str(res2)
    
    s = snap(tool, tid)
    assert s.get(WorkflowKeys.OUTCOME_ID) == "error"
    assert s.get(WorkflowKeys.FOLLOW_UP_ACTIVE) is not True

@respx.mock
def test_hard_error_after_soft_error_routing():
    """Verify terminal routing when hard exception follows soft error."""
    responses = iter([
        collector_prompt("Please provide A."),
        collector_capture("val_a"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_routing_err_soft_then_hard.yaml")
    tid = str(uuid.uuid4())

    # 1. Entry -> collect_a prompt
    tool.execute(thread_id=tid, initial_context={})

    # 2. Provide A -> func_soft (set error) -> func_hard (raise) -> error outcome
    res2 = tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    
    assert InterruptType.FOLLOW_UP in str(res2)
    assert "Something went wrong" in str(res2)
    
    s = snap(tool, tid)
    assert s.get(WorkflowKeys.OUTCOME_ID) == WorkflowKeys.ERROR
