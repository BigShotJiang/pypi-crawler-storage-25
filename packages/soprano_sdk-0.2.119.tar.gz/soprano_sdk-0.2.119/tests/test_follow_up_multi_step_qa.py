"""Tests for follow-up Q&A in multi-step workflows.

All existing follow-up Q&A tests use single-step fixtures. These tests verify that the
follow-up node correctly integrates data and conversation history from two sequential
collector steps.

Covered tracks:
  - Outcome message renders both collected fields in a multi-step template
  - Q&A works correctly after a two-step workflow completes
  - WORKFLOW CONTEXT in the follow-up LLM system prompt lists all collected fields
  - CONVERSATION HISTORY in the system prompt aggregates messages from both collectors
  - Intent change in multi-step resets attempt counter for the new session
"""
import json
import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    collector_capture,
    collector_prompt,
    fu_answer,
    fu_intent_change,
    llm_structured_response,
    make_tool,
    snap,
)


def _prompt_b(text="Please tell me field B.") -> object:
    return llm_structured_response({"bot_response": text, "field_b": None})


def _capture_b(value) -> object:
    return llm_structured_response({"bot_response": None, "field_b": value})


# ──────────────────────────────────────────────────────────────────────────────
# Outcome message template with both fields
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_outcome_message_renders_both_collected_fields():
    """After a two-step workflow completes, the FOLLOW_UP interrupt payload must contain
    the outcome message template rendered with BOTH collected field values. The message
    template 'Success! a={{ field_a }}, b={{ field_b }}' must resolve to include the
    actual values of both fields, confirming that the Jinja rendering context includes
    all collected data from the entire workflow, not just the last step.

    LLM sequence:
      #1  collect_a prompt                    (T1)
      #2  collect_a captures 'val_a'          (T2, first half)
      #3  collect_b prompt                    (T2, second half — collect_b starts)
      #4  collect_b captures 'val_b'          (T3, first half)
                                              → OutcomeNode → FOLLOW_UP
    """
    responses = iter([
        collector_prompt("Please tell me field A."),  # LLM#1
        collector_capture("val_a"),                    # LLM#2
        _prompt_b("Now please tell me field B."),      # LLM#3
        _capture_b("val_b"),                           # LLM#4
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})                           # T1 → LLM#1 → USER_INPUT (collect_a)
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})     # T2 → LLM#2, #3 → USER_INPUT (collect_b)
    result3 = tool.execute(thread_id=tid, user_message="val_b", initial_context={})  # T3 → LLM#4 → FOLLOW_UP

    assert InterruptType.FOLLOW_UP in str(result3)
    assert "val_a" in str(result3), (
        f"Outcome message must contain field_a value. Got: {result3}"
    )
    assert "val_b" in str(result3), (
        f"Outcome message must contain field_b value. Got: {result3}"
    )
    assert respx.calls.call_count == 4


# ──────────────────────────────────────────────────────────────────────────────
# Q&A after multi-step completion
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_qa_works_after_multi_step_workflow_completion():
    """After a two-step workflow completes and delivers the outcome message, a Q&A turn
    must call the follow-up LLM and return the answer in FOLLOW_UP. The attempt counter
    must increment correctly for the first turn.

    LLM sequence:
      #1  collect_a prompt                    (T1)
      #2  collect_a captures 'val_a'          (T2)
      #3  collect_b prompt                    (T2)
      #4  collect_b captures 'val_b'          (T3) → FOLLOW_UP (outcome)
      #5  follow-up Q&A answer                (T4)
    """
    responses = iter([
        collector_prompt(),        # LLM#1
        collector_capture("val_a"), # LLM#2
        _prompt_b(),               # LLM#3
        _capture_b("val_b"),       # LLM#4
        fu_answer("Here is the answer to your question about the multi-step workflow."),  # LLM#5
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})
    tool.execute(thread_id=tid, user_message="val_b", initial_context={})   # T3 → FOLLOW_UP
    result4 = tool.execute(thread_id=tid, user_message="question", initial_context={})  # T4 → Q&A
    s = snap(tool, tid)

    assert InterruptType.FOLLOW_UP in str(result4)
    assert "Here is the answer" in str(result4)
    assert s["_follow_up_attempts"] == 1
    assert s["_outcome_id"] == "outcome_success"


# ──────────────────────────────────────────────────────────────────────────────
# WORKFLOW CONTEXT contains all collected fields
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_workflow_context_in_system_prompt_includes_all_collected_fields():
    """The follow-up LLM system prompt's WORKFLOW CONTEXT block must list all collected
    fields from the entire multi-step workflow. If _build_context_summary() only reads
    partial state (e.g. fields from the last step), the LLM would answer without knowing
    what field_a contained — unable to accurately explain the workflow outcome.

    Asserts that both 'field_a' and 'field_b' appear in the system message of the
    follow-up LLM request (LLM#5).
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt(),        # LLM#1
        collector_capture("alpha"), # LLM#2
        _prompt_b(),               # LLM#3
        _capture_b("beta"),        # LLM#4
        fu_answer("Answer."),      # LLM#5
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="alpha", initial_context={})
    tool.execute(thread_id=tid, user_message="beta", initial_context={})
    tool.execute(thread_id=tid, user_message="what are my values?", initial_context={})

    assert len(captured_requests) == 5
    fu_req = json.loads(captured_requests[4].content)
    system_messages = [m for m in fu_req["messages"] if m["role"] == "system"]
    assert system_messages, "Follow-up LLM must receive a system message"
    system_content = system_messages[0]["content"]

    assert "field_a" in system_content and "alpha" in system_content, (
        f"WORKFLOW CONTEXT must include field_a='alpha'. "
        f"System prompt (truncated): {system_content[:500]!r}"
    )
    assert "field_b" in system_content and "beta" in system_content, (
        f"WORKFLOW CONTEXT must include field_b='beta'. "
        f"System prompt (truncated): {system_content[:500]!r}"
    )


# ──────────────────────────────────────────────────────────────────────────────
# CONVERSATION HISTORY aggregates both collector steps
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_conversation_history_in_system_prompt_includes_both_collectors():
    """The CONVERSATION HISTORY block in the follow-up LLM system prompt must include
    messages from BOTH collector steps, not just the last one. This allows the follow-up
    LLM to understand the full dialogue that led to the outcome.

    _aggregate_conversation_history() walks all step conversations in execution order.
    If it only aggregates the last step, the LLM would be missing context from collect_a.

    Asserts that both the collect_a prompt ('Tell me A') and the collect_b prompt
    ('Tell me B') appear in the system message of the follow-up LLM request (LLM#5).
    """
    captured_requests: list = []

    def _side_effect(req):
        captured_requests.append(req)
        return next(responses)

    responses = iter([
        collector_prompt("Tell me A."),    # LLM#1 — collect_a prompt
        collector_capture("alpha"),        # LLM#2
        _prompt_b("Tell me B."),           # LLM#3 — collect_b prompt
        _capture_b("beta"),               # LLM#4
        fu_answer("Answer."),             # LLM#5
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=_side_effect)

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="alpha", initial_context={})
    tool.execute(thread_id=tid, user_message="beta", initial_context={})
    tool.execute(thread_id=tid, user_message="explain this", initial_context={})

    fu_req = json.loads(captured_requests[4].content)
    system_content = next(
        m["content"] for m in fu_req["messages"] if m["role"] == "system"
    )

    assert "Tell me A." in system_content, (
        f"collect_a's prompt ('Tell me A.') must appear in CONVERSATION HISTORY. "
        f"System prompt (truncated): {system_content[:600]!r}"
    )
    assert "Tell me B." in system_content, (
        f"collect_b's prompt ('Tell me B.') must appear in CONVERSATION HISTORY. "
        f"System prompt (truncated): {system_content[:600]!r}"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Intent change in multi-step resets attempt counter
# ──────────────────────────────────────────────────────────────────────────────

@respx.mock
def test_attempt_counter_resets_after_intent_change_allowing_fresh_qa_turns():
    """After an intent_change rollback and re-collection, the follow-up attempt counter
    must reset to None so the new session starts a fresh count. If the counter is NOT
    reset, the first Q&A turn in the new session would use the accumulated count from
    the previous session, potentially triggering premature max_attempts termination.

    Scenario (max_attempts=5 in follow_up_multi_step.yaml):
      Session 1: 2 Q&A turns (attempts 1, 2), then intent_change on turn 3 (attempt 3)
      Session 2 (after re-collection): attempt counter resets to None.
                 3 more Q&A turns each succeed (attempts 1, 2, 3 — NOT 4, 5, 6).

    If the counter was not reset, turns 4-6 of session 2 would hit max_attempts=5
    and one of them would terminate prematurely (6 > 5).
    """
    responses = iter([
        collector_prompt(),          # LLM#1 — collect_a initial prompt
        collector_capture("val_a"),  # LLM#2 — captures field_a
        _prompt_b(),                 # LLM#3 — collect_b initial prompt
        _capture_b("val_b"),         # LLM#4 — captures field_b → FOLLOW_UP
        fu_answer("Answer 1."),      # LLM#5 — session 1, turn 1
        fu_answer("Answer 2."),      # LLM#6 — session 1, turn 2
        fu_intent_change("collect_a", "Let me redo."),   # LLM#7 — session 1, turn 3 (attempts=3)
        collector_prompt("Re-enter field A."),            # LLM#8 — after rollback
        collector_capture("new_val_a"),                   # LLM#9 — re-capture field_a
        _prompt_b("Re-enter field B."),                   # LLM#10 — collect_b re-prompt
        _capture_b("new_val_b"),                          # LLM#11 — re-capture field_b → FOLLOW_UP
        fu_answer("Session 2 answer 1."),                 # LLM#12 — session 2, turn 1
        fu_answer("Session 2 answer 2."),                 # LLM#13 — session 2, turn 2
        fu_answer("Session 2 answer 3."),                 # LLM#14 — session 2, turn 3
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("follow_up_multi_step.yaml")
    tid = str(uuid.uuid4())

    # Session 1: both steps → outcome → 2 Q&A turns → intent_change on turn 3
    tool.execute(thread_id=tid, initial_context={})                             # T1
    tool.execute(thread_id=tid, user_message="val_a", initial_context={})       # T2
    tool.execute(thread_id=tid, user_message="val_b", initial_context={})       # T3 → FOLLOW_UP
    tool.execute(thread_id=tid, user_message="q1", initial_context={})          # T4 (attempt 1)
    tool.execute(thread_id=tid, user_message="q2", initial_context={})          # T5 (attempt 2)
    result_ic = tool.execute(thread_id=tid, user_message="change A", initial_context={})  # T6 → USER_INPUT

    assert InterruptType.USER_INPUT in str(result_ic), "T6: intent_change must route back to collector"

    # Re-collection: both steps again
    tool.execute(thread_id=tid, user_message="new_val_a", initial_context={})   # T7 → USER_INPUT (collect_b)
    result_fu2 = tool.execute(thread_id=tid, user_message="new_val_b", initial_context={})  # T8 → FOLLOW_UP (new)

    assert InterruptType.FOLLOW_UP in str(result_fu2)
    assert "new_val_a" in str(result_fu2) and "new_val_b" in str(result_fu2), (
        f"Second FOLLOW_UP must contain new field values. Got: {result_fu2}"
    )

    # Session 2: 3 Q&A turns — all must succeed (counter reset to None after intent_change)
    result_s2t1 = tool.execute(thread_id=tid, user_message="s2q1", initial_context={})   # T9 (attempt 1)
    result_s2t2 = tool.execute(thread_id=tid, user_message="s2q2", initial_context={})   # T10 (attempt 2)
    result_s2t3 = tool.execute(thread_id=tid, user_message="s2q3", initial_context={})   # T11 (attempt 3)

    for i, result in enumerate([result_s2t1, result_s2t2, result_s2t3], start=1):
        assert InterruptType.FOLLOW_UP in str(result), (
            f"Session 2, turn {i} must return FOLLOW_UP. "
            f"If attempt counter was not reset (stale value 3 from session 1), "
            f"turn {i} would use attempt {3+i} which may exceed max_attempts=5. "
            f"Got: {result}"
        )

    s = snap(tool, tid)
    assert s.get("_follow_up_attempts") == 3, (
        f"After 3 session-2 Q&A turns, attempt counter must be 3. "
        f"Got: {s.get('_follow_up_attempts')!r}"
    )
    assert respx.calls.call_count == 14
