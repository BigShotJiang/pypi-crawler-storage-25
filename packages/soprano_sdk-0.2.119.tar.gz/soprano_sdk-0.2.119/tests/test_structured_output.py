"""
Test script to verify structured output functionality.
"""
import pytest
from soprano_sdk.agents.structured_output import (
    create_structured_output_model,
    validate_field_definitions
)


def test_field_validation():
    """Test field definition validation."""
    # Valid fields
    valid_fields = [
        {"name": "username", "type": "text", "description": "User's name", "required": True},
        {"name": "age", "type": "number", "description": "User's age", "required": False}
    ]
    
    # Should not raise any exception
    validate_field_definitions(valid_fields)
    
    # Invalid fields - missing required key
    invalid_fields = [
        {"name": "username", "description": "User's name"}  # missing type
    ]
    
    with pytest.raises(ValueError, match="missing required key 'type'"):
        validate_field_definitions(invalid_fields)


def test_model_creation():
    """Test dynamic model creation."""
    fields = [
        {"name": "name", "type": "text", "description": "User's full name", "required": True},
        {"name": "age", "type": "number", "description": "User's age", "required": True},
        {"name": "email", "type": "text", "description": "User's email", "required": True}
    ]
    
    UserModel = create_structured_output_model(fields, "UserProfile")
    assert UserModel.__name__ == "UserProfile"
    
    # Test model instantiation
    user = UserModel(name="John Doe", age=30, email="john@example.com")
    
    # Verify fields
    assert user.name == "John Doe"
    assert user.age == 30
    assert user.email == "john@example.com"
    
    # Verify default fields added by create_structured_output_model
    assert hasattr(user, "bot_response")
    assert hasattr(user, "options")
    assert hasattr(user, "is_selectable")
    
    # Test model_dump
    user_dict = user.model_dump()
    assert user_dict["name"] == "John Doe"
    assert user_dict["age"] == 30
    assert user_dict["email"] == "john@example.com"
    assert "bot_response" in user_dict


def test_optional_fields():
    """Test optional field handling."""
    fields = [
        {"name": "username", "type": "text", "description": "Username", "required": True},
        {"name": "bio", "type": "text", "description": "User bio", "required": False}
    ]
    
    UserModel = create_structured_output_model(fields, "UserWithOptional")
    
    # Create with required field only
    user1 = UserModel(username="john_doe")
    assert user1.bio is None
    
    # Create with both fields
    user2 = UserModel(username="jane_doe", bio="Software engineer")
    assert user2.bio == "Software engineer"


def test_type_mapping():
    """Test all type mappings."""
    fields = [
        {"name": "text_field", "type": "text", "description": "Text field", "required": True},
        {"name": "number_field", "type": "number", "description": "Number field", "required": True},
        {"name": "boolean_field", "type": "boolean", "description": "Boolean field", "required": True},
        {"name": "list_field", "type": "list", "description": "List field", "required": True},
        {"name": "dict_field", "type": "dict", "description": "Dict field", "required": True}
    ]

    TestModel = create_structured_output_model(fields, "TypeTestModel")

    instance = TestModel(
        text_field="hello",
        number_field=42,
        boolean_field=True,
        list_field=[1, 2, 3],
        dict_field={"key": "value"}
    )

    assert instance.text_field == "hello"
    assert instance.number_field == 42
    assert instance.boolean_field is True
    assert instance.list_field == [1, 2, 3]
    assert instance.dict_field == {"key": "value"}


def test_literal_type():
    """Test Literal type with args."""
    fields = [
        {"name": "status", "type": "literal", "args": ["yes", "no", "maybe"], "description": "Status field"}
    ]

    validate_field_definitions(fields)

    Model = create_structured_output_model(fields, "LiteralModel")

    instance = Model(status="yes")
    assert instance.status == "yes"

    with pytest.raises(Exception):
        Model(status="invalid_value")


def test_literal_validation_requires_args():
    """Test that literal type without args fails validation."""
    fields = [
        {"name": "status", "type": "literal", "description": "Status field"}
    ]

    with pytest.raises(ValueError, match="requires a non-empty 'args' list"):
        validate_field_definitions(fields)


def test_list_with_args():
    """Test list type with args (parametrized)."""
    fields = [
        {"name": "tags", "type": "list", "args": [str], "description": "String tags"}
    ]

    Model = create_structured_output_model(fields, "ListArgsModel")

    instance = Model(tags=["a", "b", "c"])
    assert instance.tags == ["a", "b", "c"]


def test_dict_with_args():
    """Test dict type with args (parametrized)."""
    fields = [
        {"name": "metadata", "type": "dict", "args": [str, int], "description": "String-to-int map"}
    ]

    Model = create_structured_output_model(fields, "DictArgsModel")

    instance = Model(metadata={"count": 5})
    assert instance.metadata == {"count": 5}
