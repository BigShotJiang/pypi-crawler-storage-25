import uuid
import os
import respx
from tests.helpers import (
    FAKE_LLM_URL,
    FAKE_LLM_COMPLETIONS,
    make_tool,
    snap,
    llm_text_response
)

# Set environment variable for LiteLLM/CrewAI
os.environ["OPENAI_API_KEY"] = "test-key"
os.environ["OPENAI_API_BASE"] = FAKE_LLM_URL

# MOCK_DATA for dynamic tool responses
MOCK_DATA = {
    "user_type": "premium",
    "balance": 1000
}

# Define tools used in the YAML
def get_user_info(name, **kwargs):
    """Mock tool to get user info."""
    return {"user_id": "123", "user_type": MOCK_DATA["user_type"]}

def get_account_balance(user_id, **kwargs):
    """Mock tool to get account balance."""
    return MOCK_DATA["balance"]

@respx.mock
def test_crewai_compute_premium_user():
    """Test premium user calculation (1.05 boost) with _response suffix."""
    MOCK_DATA["user_type"] = "premium"
    MOCK_DATA["balance"] = 1000
    
    responses = iter([
        llm_text_response("Thought: I need user info.\nAction: get_user_info\nAction Input: {\"name\": \"John\"}"),
        llm_text_response("Thought: Getting balance.\nAction: get_account_balance\nAction Input: {\"user_id\": \"123\"}"),
        llm_text_response("Thought: Calculating balance.\nAction: compute\nAction Input: {\"code\": \"get_account_balance_response * 1.05\"}"),
        llm_text_response("Final Answer: DATA_CAPTURED: 1050.0")
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))
    
    tid = str(uuid.uuid4())
    tool = make_tool("crewai_compute_test.yaml")
    result = tool.execute(thread_id=tid, user_message="Process my finance data", initial_context={})
    
    # Assert Final Answer
    assert "Data processed successfully" in str(result)
    assert "CAPTURED_DATA: 1050.0" in str(result)

    # Assert State using snap()
    state = snap(tool, tid)
    tool_responses = state.get("_tool_responses", {})
    assert tool_responses.get("get_user_info")["output"] == {"user_id": "123", "user_type": "premium"}
    assert tool_responses.get("get_account_balance")["output"] == 1000
    assert tool_responses.get("compute")["output"] == "1050.0"

    # Assert LLM Requests (verify tool results were sent back to LLM)
    # The 3rd call (index 2) should contain the balance result
    assert b"1000" in respx.calls[2].request.content
    # The 4th call (index 3) should contain the computation result
    assert b"1050.0" in respx.calls[3].request.content

@respx.mock
def test_crewai_compute_standard_user():
    """Test standard user calculation (1.02 boost) with _response suffix."""
    MOCK_DATA["user_type"] = "standard"
    MOCK_DATA["balance"] = 1000
    
    responses = iter([
        llm_text_response("Thought: I need info.\nAction: get_user_info\nAction Input: {\"name\": \"Jane\"}"),
        llm_text_response("Thought: Getting balance.\nAction: get_account_balance\nAction Input: {\"user_id\": \"123\"}"),
        llm_text_response("Thought: Computing standard rate.\nAction: compute\nAction Input: {\"code\": \"get_account_balance_response * 1.02\"}"),
        llm_text_response("Final Answer: DATA_CAPTURED: 1020.0")
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))
    
    tid = str(uuid.uuid4())
    tool = make_tool("crewai_compute_test.yaml")
    result = tool.execute(thread_id=tid, user_message="Process my data", initial_context={})
    
    assert "Data processed successfully" in str(result)
    assert "CAPTURED_DATA: 1020.0" in str(result)

    # Assert State
    state = snap(tool, tid)
    assert state.get("_tool_responses", {}).get("compute")["output"] == "1020.0"

    # Assert LLM Requests
    assert b"1020.0" in respx.calls[3].request.content

@respx.mock
def test_crewai_compute_error_handling():
    """Test that agent handles compute tool errors."""
    responses = iter([
        llm_text_response("Thought: Let's try something invalid.\nAction: compute\nAction Input: {\"code\": \"1/0\"}"),
        llm_text_response("Thought: The tool failed. I should inform the user.\nFinal Answer: Error: calculation failed"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))
    
    tool = make_tool("crewai_compute_test.yaml")
    result = tool.execute(thread_id=str(uuid.uuid4()), user_message="Divide by zero", initial_context={})
    
    assert "Error: calculation failed" in str(result)



@respx.mock
def test_crewai_compute_access_state():
    """Test that compute tool can access workflow state with _response suffix for other tools."""

    responses = iter([
        llm_text_response("Thought: I need to format a summary.\nAction: get_account_balance\nAction Input: {\"user_id\": \"ignore\"}"),
        llm_text_response("Thought: Now formatting summary.\nAction: compute\nAction Input: {\"code\": \"f'Summary: {get_account_balance_response}'\"}"),
        llm_text_response("Final Answer: DATA_CAPTURED: Summary for: 1000")
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))
    
    tid = str(uuid.uuid4())
    tool = make_tool("crewai_compute_test.yaml")
    result = tool.execute(
        thread_id=tid, 
        user_message="Summarize my account", 
        initial_context={}
    )
    
    assert "Summary for: 1000" in str(result)

    # Assert State - compute should have access to both initial_context and tool outputs
    state = snap(tool, tid)
    assert state.get("_tool_responses", {}).get("get_account_balance")["output"] == 1000
    assert state.get("_tool_responses", {}).get("compute")["output"] == "Summary: 1000"


@respx.mock
def test_crewai_compute_self_reference():
    """Test that compute tool can access its own previous results in the same turn."""
    responses = iter([
        llm_text_response("Thought: First compute.\nAction: compute\nAction Input: {\"code\": \"10 + 20\"}"),
        llm_text_response("Thought: Second compute using first result.\nAction: compute\nAction Input: {\"code\": \"int(compute_response) * 2\"}"),
        llm_text_response("Final Answer: DATA_CAPTURED: 60")
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))
    
    tid = str(uuid.uuid4())
    tool = make_tool("crewai_compute_test.yaml")
    result = tool.execute(thread_id=tid, user_message="Chain computations", initial_context={})
    
    assert "CAPTURED_DATA: 60" in str(result)

    # Assert State - compute_response should hold the LATEST compute result 
    # (since tool wrappers overwrite by default)
    state = snap(tool, tid)
    assert state.get("_tool_responses", {}).get("compute")["output"] == "60"

    # Assert LLM Requests - verify first compute result was sent to second compute call
    # 2nd call (index 1) should have result of 10+20 = 30
    assert b"30" in respx.calls[2].request.content