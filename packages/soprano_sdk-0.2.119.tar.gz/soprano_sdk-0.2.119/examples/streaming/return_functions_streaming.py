"""Business logic functions for return processing -- with streaming events.

These functions use ``soprano_sdk.streaming.emit()`` to push mid-node
events to streaming consumers.  When running under
``WorkflowStreamer.stream()``, each ``emit()`` call surfaces as a
``CustomEvent``.  When running under ``WorkflowTool.execute()``
(non-streaming), ``emit()`` is a silent no-op -- no code changes needed.
"""

import random
import time

from soprano_sdk.streaming import emit


def check_eligibility(state: dict) -> bool:
    """Check if an order is eligible for return."""
    order_id = state.get("order_id", "unknown")

    # Step 1: Look up the order
    emit("step", {"label": f"Looking up order {order_id}..."})
    time.sleep(0.8)

    # Step 2: Check return window
    emit("step", {"label": "Checking return window policy..."})
    time.sleep(0.6)

    # Step 3: Verify item condition rules
    emit("step", {"label": "Verifying item condition rules..."})
    time.sleep(0.4)

    # Simulate eligibility result
    eligible = random.randint(1, 100) % 2 == 0

    emit("result", {
        "label": "Eligible for return" if eligible else "Not eligible for return",
        "eligible": eligible,
    })

    return eligible


def validate_reason(state: dict) -> bool:
    """Validate if a return reason is acceptable."""
    reason = state.get("return_reason", "")

    emit("step", {"label": f'Validating reason: "{reason}"...'})
    time.sleep(0.5)

    invalid_reasons = ["no reason", "just because", "don't want it"]
    reason_lower = reason.lower()
    is_valid = not any(invalid in reason_lower for invalid in invalid_reasons)

    emit("result", {
        "label": "Reason accepted" if is_valid else "Reason rejected",
        "valid": is_valid,
    })

    return is_valid


def process_return(state: dict) -> bool:
    """Process the return request."""
    order_id = state.get("order_id")
    reason = state.get("return_reason")

    emit("step", {"label": "Creating return record..."})
    time.sleep(0.6)

    emit("step", {"label": "Generating return shipping label..."})
    time.sleep(0.8)

    emit("step", {"label": "Sending confirmation email..."})
    time.sleep(0.4)

    emit("result", {
        "label": f"Return processed for order {order_id}",
        "order_id": order_id,
        "reason": reason,
    })

    return True
