import time
from typing import Any, Dict, Optional

import requests

from .errors import (
    AchekError,
    AuthenticationError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from .webhooks import Webhooks

DEFAULT_BASE_URL = "https://api.achek.com.ng/v1"
DEFAULT_TIMEOUT = 30
DEFAULT_RETRIES = 3
SDK_VERSION = "achekconnect-python/1.0.0"


class AchekConnect:
    """
    Official AchekConnect Python client.

    Usage::

        from achekconnect import AchekConnect

        client = AchekConnect("your-api-key")
        result = client.send_otp("+2348012345678")
        print(result["sessionId"])
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
        webhook_secret: str = "",
    ):
        if not api_key:
            raise AuthenticationError("api_key is required")
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._retries = retries
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "X-SDK": SDK_VERSION,
            }
        )
        self.webhooks = Webhooks(webhook_secret)

    # ──────────────────────────────── Transport ────────────────────────────────

    def _request(self, method: str, path: str, **kwargs) -> Dict[str, Any]:
        url = f"{self._base_url}{path}"
        attempt = 0
        while True:
            try:
                res = self._session.request(method, url, timeout=self._timeout, **kwargs)
            except requests.exceptions.Timeout:
                if attempt < self._retries:
                    attempt += 1
                    time.sleep(min(0.5 * 2 ** attempt, 10))
                    continue
                raise NetworkError("Request timed out")
            except requests.exceptions.RequestException as exc:
                if attempt < self._retries:
                    attempt += 1
                    time.sleep(min(0.5 * 2 ** attempt, 10))
                    continue
                raise NetworkError(str(exc)) from exc

            if res.status_code == 401:
                raise AuthenticationError()

            if res.status_code == 429:
                retry_after = int(res.headers.get("Retry-After", 60))
                if attempt < self._retries:
                    time.sleep(retry_after)
                    attempt += 1
                    continue
                raise RateLimitError(retry_after)

            data = res.json()

            if not data.get("success"):
                err = data.get("error", {})
                msg = err.get("message", "Request failed")
                code = err.get("code", "UNKNOWN")
                if res.status_code == 422:
                    raise ValidationError(msg)
                if res.status_code == 404:
                    raise NotFoundError(msg)
                raise AchekError(msg, code, res.status_code)

            return data

    # ──────────────────────────────── OTP ─────────────────────────────────────

    def send_otp(
        self,
        phone: str,
        *,
        length: int = 6,
        expires_in: int = 600,
        template: Optional[str] = None,
        sender_number: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Send a WhatsApp OTP to a phone number.

        Args:
            phone:         E.164 number e.g. ``"+2348012345678"``.
            length:        OTP digit length — 4 or 6 (default 6).
            expires_in:    Seconds until expiry (default 600).
            template:      Custom message with ``{{otp}}`` placeholder.
            sender_number: Override the default sender number.

        Returns:
            dict with ``sessionId``, ``phone``, ``expiresAt``, ``remaining``.
        """
        body: Dict[str, Any] = {"phone": phone, "length": length, "expiresIn": expires_in}
        if template is not None:
            body["template"] = template
        if sender_number is not None:
            body["senderNumber"] = sender_number
        return self._request("POST", "/otp/send", json=body)["data"]

    def verify_otp(self, phone: str, otp: str) -> Dict[str, Any]:
        """
        Verify a code entered by the user.

        Returns:
            dict with ``valid`` (bool), ``phone``, ``sessionId``.
        """
        return self._request("POST", "/otp/verify", json={"phone": phone, "otp": otp})["data"]

    # ──────────────────────────────── Messaging ────────────────────────────────

    def send_message(
        self,
        phone: str,
        message: str,
        *,
        sender_number: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Send a plain WhatsApp message."""
        body: Dict[str, Any] = {"phone": phone, "message": message}
        if sender_number is not None:
            body["senderNumber"] = sender_number
        return self._request("POST", "/messages/send", json=body)["data"]

    # ──────────────────────────────── AI Agents ────────────────────────────────

    def create_agent(
        self,
        name: str,
        system_prompt: str,
        *,
        provider: str = "openai",
        model: Optional[str] = None,
        welcome_message: Optional[str] = None,
        webhook_url: Optional[str] = None,
        phone_number: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new AI WhatsApp agent."""
        body: Dict[str, Any] = {
            "name": name,
            "systemPrompt": system_prompt,
            "provider": provider,
        }
        if model is not None:
            body["model"] = model
        if welcome_message is not None:
            body["welcomeMessage"] = welcome_message
        if webhook_url is not None:
            body["webhookUrl"] = webhook_url
        if phone_number is not None:
            body["phoneNumber"] = phone_number
        return self._request("POST", "/agents", json=body)["data"]

    def get_agent(self, agent_id: str) -> Dict[str, Any]:
        """Retrieve an agent by ID."""
        return self._request("GET", f"/agents/{agent_id}")["data"]

    def delete_agent(self, agent_id: str) -> Dict[str, Any]:
        """Delete an agent permanently."""
        return self._request("DELETE", f"/agents/{agent_id}")["data"]
