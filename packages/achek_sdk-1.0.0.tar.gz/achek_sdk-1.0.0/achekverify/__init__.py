"""
AchekConnect Python SDK
======================
Official client for the AchekConnect API — WhatsApp OTP, messaging, and AI bots.

Quick start::

    from achekconnect import AchekConnect

    client = AchekConnect("your-api-key")

    # Send OTP
    result = client.send_otp("+2348012345678")
    print(result["sessionId"])

    # Verify OTP
    check = client.verify_otp("+2348012345678", otp="482910")
    print(check["valid"])  # True / False
"""

from .client import AchekConnect
from .errors import (
    AchekError,
    AuthenticationError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from .webhooks import Webhooks

__all__ = [
    "AchekConnect",
    "AchekError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "NetworkError",
    "Webhooks",
]

__version__ = "1.0.0"
