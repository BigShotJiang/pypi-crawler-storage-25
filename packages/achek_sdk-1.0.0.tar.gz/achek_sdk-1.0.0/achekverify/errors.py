class AchekError(Exception):
    """Base exception for all AchekConnect SDK errors."""

    def __init__(
        self,
        message: str,
        code: str = "UNKNOWN",
        status_code: int = None,
        request_id: str = None,
    ):
        super().__init__(message)
        self.message = message
        self.code = code
        self.status_code = status_code
        self.request_id = request_id

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(code={self.code!r}, message={self.message!r})"


class AuthenticationError(AchekError):
    """Raised when the API key is missing or invalid (HTTP 401)."""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, "AUTHENTICATION_ERROR", 401)


class RateLimitError(AchekError):
    """Raised when the rate limit is exceeded (HTTP 429)."""

    def __init__(self, retry_after: int = 60, message: str = "Rate limit exceeded"):
        super().__init__(message, "RATE_LIMIT_ERROR", 429)
        self.retry_after = retry_after


class ValidationError(AchekError):
    """Raised when request validation fails (HTTP 422)."""

    def __init__(self, message: str, field: str = None):
        super().__init__(message, "VALIDATION_ERROR", 422)
        self.field = field


class NotFoundError(AchekError):
    """Raised when a resource is not found (HTTP 404)."""

    def __init__(self, resource: str = "Resource"):
        super().__init__(f"{resource} not found", "NOT_FOUND", 404)


class NetworkError(AchekError):
    """Raised for connection failures, timeouts, and other transport errors."""

    def __init__(self, message: str):
        super().__init__(message, "NETWORK_ERROR")
