import hmac
import hashlib
import json
from typing import Any, Dict


class Webhooks:
    """Helpers for verifying and parsing incoming AchekConnect webhook events."""

    def __init__(self, secret: str):
        self._secret = secret

    def verify(self, payload: bytes, signature: str) -> bool:
        """
        Return True if the HMAC-SHA256 signature matches the payload.

        Args:
            payload:   Raw request body bytes.
            signature: Value of the X-AchekConnect-Signature header.
        """
        if not self._secret:
            return False
        expected = hmac.new(
            self._secret.encode("utf-8"), payload, hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(expected, signature)

    def parse(self, payload: str) -> Dict[str, Any]:
        """Parse a raw JSON payload string into a dict."""
        return json.loads(payload)

    def construct_event(self, payload: bytes, signature: str) -> Dict[str, Any]:
        """
        Verify the signature then parse the payload.

        Use this in your webhook route handler::

            @app.route("/webhook", methods=["POST"])
            def webhook():
                event = client.webhooks.construct_event(
                    request.get_data(),
                    request.headers.get("X-AchekConnect-Signature", "")
                )
                if event["type"] == "otp.verified":
                    ...
                return "", 200

        Raises:
            ValueError: If the signature does not match.
        """
        if not self.verify(payload, signature):
            raise ValueError(
                "Webhook signature verification failed. "
                "Ensure you are passing the raw request body and the correct secret."
            )
        return self.parse(payload.decode("utf-8"))
