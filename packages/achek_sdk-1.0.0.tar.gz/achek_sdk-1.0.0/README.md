# achek-sdk

Official Python SDK for [Achek](https://achek.com.ng) — WhatsApp OTP, AI chatbots & business messaging for Nigerian developers.

## Installation

```bash
pip install achek-sdk
```

## Quick Start

```python
from achekverify import AchekConnect

client = AchekConnect("your_api_key")

# Send a WhatsApp OTP
result = client.send_otp("+2348XXXXXXXXX")
print(result["sessionId"])

# Verify the OTP the user enters
check = client.verify_otp("+2348XXXXXXXXX", otp="482910")
print(check["valid"])  # True / False

# Send a plain WhatsApp message
client.send_message("+2348XXXXXXXXX", "Hello from Achek!")
```

## Authentication

Get your API key from the [Achek dashboard](https://console.achek.com.ng).

```python
client = AchekConnect("ak_live_your_key_here")
```

## Features

- **WhatsApp OTP** — Send and verify one-time passwords via WhatsApp
- **Messaging** — Send plain and templated WhatsApp messages
- **AI Bot** — Create and manage AI chatbot agents
- **Webhooks** — Verify and parse incoming webhook events
- **Broadcasts** — Send bulk messages to multiple numbers

## Webhook Verification

```python
from achekverify import Webhooks

wh = Webhooks("your_webhook_secret")
payload = wh.verify(raw_body, signature_header)
print(payload["event"])  # e.g. "otp.verified"
```

## Links

- [Documentation](https://docs.achek.com.ng)
- [Dashboard](https://console.achek.com.ng)
- [GitHub](https://github.com/CalebDevX/AchekVerify)
- [Support](https://achek.com.ng/support)

## License

MIT
