from __future__ import annotations

import pytest

from wxflywheel.commands.common import require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.exceptions import MissingKeyError


def test_require_client_returns_client_when_key_exists() -> None:
    runtime = RuntimeContext.from_values(key="test-key", host="http://localhost:8011")
    client = require_client(runtime)
    assert client.key == "test-key"
    assert client.host == "http://localhost:8011"


def test_require_client_raises_when_key_is_missing() -> None:
    runtime = RuntimeContext.from_values(key=None, host="http://localhost:8011")
    with pytest.raises(MissingKeyError) as exc_info:
        require_client(runtime)
    assert exc_info.value.code == -1
