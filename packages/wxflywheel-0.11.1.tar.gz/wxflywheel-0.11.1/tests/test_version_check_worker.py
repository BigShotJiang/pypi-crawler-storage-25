"""Tests for wxflywheel._version_check_worker background worker entry point."""

from __future__ import annotations

import runpy
import sys
import warnings

import pytest

from wxflywheel import _version_check_worker, version_check


def test_worker_main_success_returns_0(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(version_check, "refresh_cache_from_pypi", lambda timeout=5.0: True)
    assert _version_check_worker.main() == 0


def test_worker_main_failure_returns_1(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(version_check, "refresh_cache_from_pypi", lambda timeout=5.0: False)
    assert _version_check_worker.main() == 1


def test_worker_main_swallows_exceptions(monkeypatch: pytest.MonkeyPatch) -> None:
    def _raise(timeout: float = 5.0) -> bool:
        raise RuntimeError("unexpected")

    monkeypatch.setattr(version_check, "refresh_cache_from_pypi", _raise)
    assert _version_check_worker.main() == 1


def test_worker_main_sets_worker_env_var(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)
    monkeypatch.setattr(version_check, "refresh_cache_from_pypi", lambda timeout=5.0: True)
    _version_check_worker.main()
    import os

    assert os.environ.get("WXFLYWHEEL_WORKER") == "1"


def test_worker_module_runs_as_script(monkeypatch: pytest.MonkeyPatch) -> None:
    """Cover the `if __name__ == '__main__': sys.exit(main())` block by
    running the module as __main__ via runpy. This is the standard way to
    exercise module entry-point code in unit tests without actually spawning
    a subprocess."""
    monkeypatch.setattr(version_check, "refresh_cache_from_pypi", lambda timeout=5.0: True)
    original_module = sys.modules.pop("wxflywheel._version_check_worker", None)
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            with pytest.raises(SystemExit) as exc_info:
                runpy.run_module("wxflywheel._version_check_worker", run_name="__main__")
    finally:
        if original_module is not None:
            sys.modules["wxflywheel._version_check_worker"] = original_module
    assert exc_info.value.code == 0
    runtime_warnings = [item for item in caught if issubclass(item.category, RuntimeWarning)]
    assert runtime_warnings == []
