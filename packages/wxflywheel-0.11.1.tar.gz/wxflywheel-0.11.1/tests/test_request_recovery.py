from wxflywheel.exceptions import WxflywheelError
from wxflywheel.request_recovery import (
    clamp_request_timeout,
    current_recovery_deadline,
    needs_login_probe,
    recovery_scope,
    should_attempt_recovery,
    wait_for_recovery,
)


def test_clamp_request_timeout_returns_remaining_budget_when_budget_is_smaller() -> None:
    assert clamp_request_timeout(0.5, default_timeout=30.0) == 0.5


def test_should_attempt_recovery_returns_false_for_non_transient_error() -> None:
    assert should_attempt_recovery(WxflywheelError(1402, "unauthorized")) is False


def test_auth_failed_needs_login_probe_before_recovery() -> None:
    assert needs_login_probe(WxflywheelError(300, "auth failed")) is True


def test_auth_failed_stays_non_recoverable_while_login_is_online() -> None:
    assert should_attempt_recovery(WxflywheelError(300, "auth failed"), login_online=True) is False


def test_auth_failed_becomes_recoverable_after_login_drops_offline() -> None:
    assert should_attempt_recovery(WxflywheelError(300, "auth failed"), login_online=False) is True


def test_auth_failed_on_wxindex_path_stays_recoverable_while_login_is_online() -> None:
    assert (
        should_attempt_recovery(
            WxflywheelError(300, "auth failed"),
            login_online=True,
            request_path="/api/wxindex/test",
        )
        is True
    )


def test_wait_for_recovery_returns_false_when_budget_expires_after_probe() -> None:
    moments = iter([0.0, 6.0])

    def _fake_monotonic() -> float:
        return next(moments)

    assert (
        wait_for_recovery(
            5.0,
            probe_online=lambda timeout: False,
            monotonic=_fake_monotonic,
            sleep=lambda _: None,
        )
        is False
    )


def test_wait_for_recovery_returns_false_when_deadline_is_already_spent() -> None:
    assert (
        wait_for_recovery(
            5.0,
            probe_online=lambda timeout: True,
            monotonic=lambda: 6.0,
            sleep=lambda _: None,
        )
        is False
    )


def test_recovery_scope_reuses_the_same_deadline_inside_one_command() -> None:
    with recovery_scope(monotonic=lambda: 10.0) as deadline:
        assert current_recovery_deadline(monotonic=lambda: 999.0) == deadline


def test_nested_recovery_scope_reuses_existing_deadline() -> None:
    with (
        recovery_scope(monotonic=lambda: 10.0) as outer_deadline,
        recovery_scope(monotonic=lambda: 999.0) as inner_deadline,
    ):
        assert inner_deadline == outer_deadline
