import base64
import json
import re
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Any, cast
from unittest.mock import patch

import click
import pytest
from click.testing import CliRunner

from tests.conftest import MockRespFactory
from wxflywheel import __version__
from wxflywheel.cli import cli, main
from wxflywheel.commands.search import (
    _build_article_detail_output,
    _build_article_output,
    _build_sticker_detail_output,
    _build_sticker_output,
    _build_video_detail_author_section,
    _build_video_detail_comments_section,
    _build_video_detail_media_section,
    _build_video_detail_output,
    _build_video_download_instructions,
    _build_video_ext_req_params,
    _build_video_output,
    _coerce_intlike,
    _collect_video_items,
    _decode_cursor,
    _decode_sticker_cursor,
    _decode_video_cursor,
    _encode_cursor,
    _encode_sticker_cursor,
    _encode_video_cursor,
    _extract_read_count,
    _extract_read_count_text,
    _extract_sticker_items_from_groups,
    _extract_video_interaction_metrics,
    _find_article_group,
    _normalize_article_items,
    _normalize_sticker_comments,
    _normalize_sticker_item,
    _normalize_video_items,
    _require_dict,
    _require_string,
    _try_coerce_intlike,
)
from wxflywheel.exceptions import WxflywheelError

ENV = {"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://localhost:8011"}


def _load_video_detail_v2_fixture() -> dict[str, Any]:
    path = Path(__file__).with_name("fixtures").joinpath("video_detail_v2_live.json")
    with path.open(encoding="utf-8") as f:
        return cast(dict[str, Any], json.load(f))


def _load_video_detail_payload() -> dict[str, Any]:
    return deepcopy(_load_video_detail_v2_fixture())


def _make_article_item(
    *,
    title: str = '<em class="highlight">微信</em>又上新功能',
    desc: str = '3月31日，<em class="highlight">微信</em>派公众号发文宣布微信推出一项新功能……',
    doc_id: str = "4132226094060041310",
    timestamp: int = 1775029376,
    doc_url: str = "http://mp.weixin.qq.com/article-1",
    thumb_url: str = "https://mmbiz.qpic.cn/article-1.jpg",
    source_name: str = "新华社",
    tag_title: str | None = "阅读 10万+",
    report_extinfo_str: str = (
        "src_channel%3D1930611252_4_0_4075929821_13%26show_tag%3DR_2_1_100000"
    ),
) -> dict[str, object]:
    source: dict[str, object] = {"title": source_name}
    if tag_title is not None:
        source["tag"] = [{"title": tag_title, "type": 2, "noBg": True}]
    return {
        "title": title,
        "desc": desc,
        "docID": doc_id,
        "timestamp": timestamp,
        "doc_url": doc_url,
        "thumbUrl": thumb_url,
        "source": source,
        "report_extinfo_str": report_extinfo_str,
    }


def _make_websearch_response(
    inner_payload: dict[str, object], *, message: str = ""
) -> dict[str, object]:
    return {
        "code": 200,
        "data": {
            "baseResponse": {"ret": 0, "errMsg": {"str": ""}},
            "updateCode": 0,
            "offset": inner_payload.get("offset", 0),
            "json": json.dumps(inner_payload, ensure_ascii=False),
        },
        "message": message,
    }


def _make_article_inner_payload(
    *,
    items: list[dict[str, object]] | None = None,
    continue_flag: int = 1,
    offset: int = 23,
    search_id: str = "search-id-1",
    cookies: str = '{"doc_offset":0,"scene":101}',
) -> dict[str, object]:
    return {
        "continueFlag": continue_flag,
        "offset": offset,
        "searchID": search_id,
        "cookies": cookies,
        "data": (
            [
                {
                    "type": 2,
                    "real_type": 2,
                    "items": items if items is not None else [_make_article_item()],
                }
            ]
            if items is not None
            else [{"type": 2, "real_type": 2, "items": [_make_article_item()]}]
        ),
    }


def _make_article_detail_v2_response(*, comments_error: str | None = None) -> dict[str, Any]:
    data: dict[str, object] = {
        "article": {
            "title": "未来十年，微信是普通人创业赚钱最大的机会",
            "source_name": "生财有术",
            "author": "亦仁",
            "summary": "这是一篇关于普通人如何借微信做生意的文章。",
            "published_at_text": "2026-04-09 10:30",
            "published_at_ts": 1775701800,
            "url": "http://mp.weixin.qq.com/s?__biz=abc&mid=1&idx=1&sn=xyz",
            "content_html": "<p>正文</p>",
        },
        "metrics": {
            "read_count": 5092,
            "like_count": 41,
            "watching_count": 173,
            "share_count": 691,
            "collect_count": 290,
            "comment_count": 4,
            "comment_enabled": True,
        },
        "comments": {
            "scope": "selected",
            "returned_count": 2,
            "items": [
                {
                    "userCommentId": 1,
                    "nickName": "小王",
                    "content": "这条思路很清楚",
                    "createTime": 1775701811,
                    "likeNum": 7,
                    "isTop": 1,
                    "reply": {
                        "replyList": [
                            {
                                "content": "同意",
                                "createTime": 1775701822,
                                "replyId": 101,
                                "replyLikeNum": 2,
                            }
                        ]
                    },
                },
                {
                    "userCommentId": 2,
                    "nickName": "小李",
                    "content": "收藏了",
                    "createTime": 1775701911,
                    "likeNum": 0,
                    "isTop": 0,
                },
            ],
        },
    }
    if comments_error is not None:
        data["comments_error"] = comments_error
    return {"code": 200, "data": data, "message": ""}


def _make_sticker_item(
    *,
    title: str = '吃<em class="highlight">小龙虾</em>的季节',
    doc_id: str = "2263028580860557921",
    source_name: str = "相约岁月",
    source_icon_url: str = "http://mmbiz.qpic.cn/icon.png",
    pub_time: int = 1775449350,
    update_time: str = "3天前",
    image: str = "http://mmbiz.qpic.cn/cover.jpg",
    jump_url: str = "http://mp.weixin.qq.com/s?__biz=MzY5NDAyMzUxOA==&mid=2247485540&idx=1&sn=abc",
    item_show_type: int = 8,
    mp_doc_id: str = "8268922412949997757",
    inner_offset: int = 1,
    report_id: str = "2263028580860557921:mp:2130789760",
    show_type: int = 4,
    src_type: int = 49,
    social_tags: object = None,
    hide_control: bool = True,
) -> dict[str, object]:
    return {
        "docID": doc_id,
        "title": title,
        "source": {"title": source_name, "iconUrl": source_icon_url},
        "pubTime": pub_time,
        "updateTime": update_time,
        "image": image,
        "jumpInfo": {
            "jumpUrl": jump_url,
            "itemShowType": item_show_type,
            "jumpType": 3,
            "mpScene": 7,
        },
        "mpDocID": mp_doc_id,
        "mpScene": 7,
        "inner_offset": inner_offset,
        "reportId": report_id,
        "showType": show_type,
        "src_type": src_type,
        "socialTags": social_tags,
        "hideControl": hide_control,
    }


def _make_sticker_inner_payload(
    *,
    items: list[dict[str, object]] | None = None,
    continue_flag: int = 1,
    offset: int = 30,
    search_id: str = "sticker-search-id-1",
    cookies: str = '{"doc_offset":0,"scene":101}',
) -> dict[str, object]:
    raw_items = items if items is not None else [_make_sticker_item()]
    groups: list[dict[str, object]] = []
    for i in range(0, len(raw_items), 2):
        pair = raw_items[i : i + 2]
        sub_boxes = [{"type": 84, "items": [item]} for item in pair]
        groups.append({"type": 107, "subBoxes": sub_boxes})
    return {
        "continueFlag": continue_flag,
        "offset": offset,
        "searchID": search_id,
        "cookies": cookies,
        "data": groups,
    }


def _make_video_item(
    *,
    title: str = "小龙虾销量⚜️ 第1⃣️ ⚜️",
    doc_id: str = "finderobjv0cDZu92mZj8B6ZR/Ej56SnGEfgjqopXagtc3co4MzAxw=",
    export_id: str = "export/UzFfBgAAxMmCEFtyXjHbjczT4DCKdoMAzvlObHSgLbTokaK-fQ",
    hash_doc_id: str = "15159504240972239737",
    image_url: str = "https://findermp.video.qq.com/251/20304/stodownload?encfilekey=live-sample",
    duration: str = "02:56",
    published_at_text: str = "31分钟前",
    published_at_ts: int = 1776239346,
    source_name: str | None = "小蜗聊AI",
    source_icon_url: str | None = (
        "https://wx.qlogo.cn/finderhead/ver_1/hXJxkczSPqU0RXLusGGwyfKgHnrgLQVicby882rbuETMnn6yTTMD5RA0CGK3lfB3xm0aZ6PX3562whXASrp8xEWYO8jFahRUtyo44VClmhqyiajDkMP5kia90ygTbqfPicKrxX2FW6qAenk45Qsf7TWMyQ/132"
    ),
    show_type: str | int = 1,
    report_extinfo_str: object | None = (
        '{"like_cnt": 12, "comment_cnt": 2, "forward_cnt": 1, "thumb_cnt": 0}'
    ),
) -> dict[str, object]:
    source: dict[str, object] = {}
    if source_name is not None:
        source["title"] = source_name
    if source_icon_url is not None:
        source["iconUrl"] = source_icon_url
    return {
        "docID": doc_id,
        "exportId": export_id,
        "hashDocID": hash_doc_id,
        "title": title,
        "image": image_url,
        "duration": duration,
        "dateTime": published_at_text,
        "pubTime": published_at_ts,
        "source": source,
        "showType": show_type,
        "report_extinfo_str": report_extinfo_str,
    }


def _make_video_inner_payload(
    *,
    items: list[dict[str, object]] | None = None,
    continue_flag: int = 1,
    offset: int = 20,
    search_id: str = "video-search-id-1",
    cookies: str = '{"doc_offset":0,"scene":101}',
    no_more_outer: bool = False,
    no_more_inner: bool = False,
    with_outer_video_group: bool = True,
    extra_groups: list[dict[str, object]] | None = None,
) -> dict[str, object]:
    raw_items = items if items is not None else [_make_video_item()]
    groups: list[dict[str, object]] = []
    if with_outer_video_group:
        groups.append(
            {
                "type": 107,
                "subBoxes": [
                    {"type": 84, "items": [raw_item], "real_type": 18874368}
                    for raw_item in raw_items
                ],
            }
        )
    if extra_groups:
        groups.extend(extra_groups)
    payload: dict[str, object] = {
        "continueFlag": continue_flag,
        "offset": offset,
        "searchID": search_id,
        "cookies": cookies,
        "data": groups,
    }
    if no_more_inner:
        payload["noMoreData"] = True
    return payload


def test_search_related_outputs_seed_and_words_on_success(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {
        "code": 200,
        "data": {"words": ["社群营销怎么做", "社群活跃技巧", "社群变现"]},
        "message": "",
    }
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "related", "--seed", "社群运营"], env=ENV)
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["code"] == 200
    assert data["data"]["seed"] == "社群运营"
    assert data["data"]["related"] == ["社群营销怎么做", "社群活跃技巧", "社群变现"]


def test_search_related_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": {"words": []}, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        runner.invoke(cli, ["search", "related", "--seed", "社群运营"], env=ENV)
    called_url = mock_post.call_args.args[1]
    called_params = mock_post.call_args.kwargs["params"]
    called_json = mock_post.call_args.kwargs["json"]
    assert called_url == "http://localhost:8011/v1/Finder/RelatedKeywords"
    assert called_params["key"] == "test-key"
    assert called_json == {"KeyWord": "社群运营"}


def test_search_related_api_error_exits_1(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 300, "data": None, "message": "关键词不能为空"}),
    ):
        result = runner.invoke(cli, ["search", "related", "--seed", ""], env=ENV)
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == 300
    assert "关键词不能为空" in err_data["message"]


def test_search_article_default_outputs_normalized_article_list(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(_make_article_inner_payload())
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    data = payload["data"]
    assert data["keyword"] == "微信"
    assert data["sort"] == "default"
    assert data["has_more"] is True
    assert "next_cursor" in data
    item = data["items"][0]
    assert item == {
        "article_id": "4132226094060041310",
        "title": "微信又上新功能",
        "summary": "3月31日，微信派公众号发文宣布微信推出一项新功能……",
        "source_name": "新华社",
        "published_at_ts": 1775029376,
        "url": "http://mp.weixin.qq.com/article-1",
        "cover_url": "https://mmbiz.qpic.cn/article-1.jpg",
        "read_count_text": "阅读 10万+",
        "read_count": 100000,
    }
    assert "rank" not in item
    assert "total_count" not in data
    assert payload["meta"]["cli"]["current_version"] == __version__


def test_search_article_default_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(_make_article_inner_payload())
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    called_url = mock_post.call_args.args[1]
    called_params = mock_post.call_args.kwargs["params"]
    called_json = mock_post.call_args.kwargs["json"]
    assert called_url == "http://localhost:8011/v1/Finder/WebSearch"
    assert called_params["key"] == "test-key"
    assert called_json == {
        "KeyWord": "微信",
        "Offset": 0,
        "BusinessType": 2,
        "Scene": 101,
        "SearchId": "",
    }


def test_search_article_newest_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(_make_article_inner_payload())
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        runner.invoke(cli, ["search", "article", "--keyword", "微信", "--sort", "newest"], env=ENV)
    called_json = mock_post.call_args.kwargs["json"]
    assert called_json == {
        "KeyWord": "微信",
        "Offset": 0,
        "BusinessType": 2,
        "Scene": 101,
        "SearchId": "",
        "ExtReqParams": [{"Key": "docSortType", "TextValue": '["2"]'}],
    }


def test_search_article_hot_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(_make_article_inner_payload())
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        runner.invoke(cli, ["search", "article", "--keyword", "微信", "--sort", "hot"], env=ENV)
    called_json = mock_post.call_args.kwargs["json"]
    assert called_json == {
        "KeyWord": "微信",
        "Offset": 0,
        "BusinessType": 2,
        "Scene": 101,
        "SearchId": "",
        "ExtReqParams": [{"Key": "docSortType", "TextValue": '["4"]'}],
    }


def test_search_article_detail_outputs_normalized_payload(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_response = _make_article_detail_v2_response(comments_error="comment cgi timeout")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp(api_response),
    ):
        result = runner.invoke(
            cli,
            ["search", "article-detail", "--url", "http://mp.weixin.qq.com/s?__biz=abc&mid=1"],
            env=ENV,
        )
    assert result.exit_code == 0
    payload = json.loads(result.output)
    data = payload["data"]
    assert data["article"]["title"] == "未来十年，微信是普通人创业赚钱最大的机会"
    assert data["metrics"]["comment_count"] == 4
    assert data["comments"]["scope"] == "selected"
    assert data["comments"]["returned_count"] == 2
    assert data["comments"]["items"][0] == {
        "user_comment_id": 1,
        "nick_name": "小王",
        "content": "这条思路很清楚",
        "create_time": 1775701811,
        "like_count": 7,
        "is_top": 1,
        "reply": {
            "reply_list": [
                {
                    "content": "同意",
                    "create_time": 1775701822,
                    "reply_id": 101,
                    "like_count": 2,
                }
            ]
        },
    }
    assert data["comments_error"] == "comment cgi timeout"
    assert payload["meta"]["cli"]["current_version"] == __version__


def test_search_article_detail_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp(_make_article_detail_v2_response()),
    ) as mock_get:
        runner.invoke(
            cli,
            ["search", "article-detail", "--url", "http://mp.weixin.qq.com/s?__biz=abc&mid=1"],
            env=ENV,
        )
    called_url = mock_get.call_args.args[1]
    called_params = mock_get.call_args.kwargs["params"]
    assert called_url == "http://localhost:8011/v1/Gh/ArticleDetailV2"
    assert called_params == {
        "key": "test-key",
        "url": "http://mp.weixin.qq.com/s?__biz=abc&mid=1",
    }


def test_build_article_detail_output_rejects_non_selected_scope() -> None:
    raw = _make_article_detail_v2_response()
    raw["data"]["comments"]["scope"] = "all"
    with pytest.raises(WxflywheelError) as exc_info:
        _build_article_detail_output(raw["data"])
    assert "comments.scope" in exc_info.value.message


def test_build_article_detail_output_rejects_non_list_comments_items() -> None:
    raw = _make_article_detail_v2_response()
    raw["data"]["comments"]["items"] = "bad"
    with pytest.raises(WxflywheelError) as exc_info:
        _build_article_detail_output(raw["data"])
    assert "comments.items is not a list" in exc_info.value.message


def test_build_article_detail_output_rejects_non_list_reply_list() -> None:
    raw = _make_article_detail_v2_response()
    raw["data"]["comments"]["items"][0]["reply"]["replyList"] = "bad"
    with pytest.raises(WxflywheelError) as exc_info:
        _build_article_detail_output(raw["data"])
    assert "replyList is not a list" in exc_info.value.message


def test_build_article_detail_output_rejects_non_bool_comment_enabled() -> None:
    raw = _make_article_detail_v2_response()
    raw["data"]["metrics"]["comment_enabled"] = 1
    with pytest.raises(WxflywheelError) as exc_info:
        _build_article_detail_output(raw["data"])
    assert "comment_enabled" in exc_info.value.message


def test_search_article_cursor_uses_server_offset_without_local_increment(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    cursor = _encode_cursor(
        {
            "v": 1,
            "keyword": "微信",
            "sort": "default",
            "offset": 23,
            "search_id": "search-id-2",
            "cookies": '{"doc_offset":23,"scene":101}',
        }
    )
    api_resp = _make_websearch_response(
        _make_article_inner_payload(continue_flag=0, offset=42, search_id="search-id-2")
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        result = runner.invoke(cli, ["search", "article", "--cursor", cursor], env=ENV)
    assert result.exit_code == 0
    called_json = mock_post.call_args.kwargs["json"]
    assert called_json == {
        "KeyWord": "微信",
        "Offset": 23,
        "BusinessType": 2,
        "Scene": 101,
        "SearchId": "search-id-2",
        "ExtReqParams": [{"Key": "cookies", "TextValue": '{"doc_offset":23,"scene":101}'}],
    }


def test_search_article_cursor_keeps_newest_sort_and_cookies(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    cursor = _encode_cursor(
        {
            "v": 1,
            "keyword": "微信",
            "sort": "newest",
            "offset": 20,
            "search_id": "search-id-3",
            "cookies": '{"doc_offset":20,"scene":101}',
        }
    )
    api_resp = _make_websearch_response(
        _make_article_inner_payload(continue_flag=0, offset=40, search_id="search-id-3")
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_post:
        result = runner.invoke(cli, ["search", "article", "--cursor", cursor], env=ENV)
    assert result.exit_code == 0
    called_json = mock_post.call_args.kwargs["json"]
    assert called_json == {
        "KeyWord": "微信",
        "Offset": 20,
        "BusinessType": 2,
        "Scene": 101,
        "SearchId": "search-id-3",
        "ExtReqParams": [
            {"Key": "docSortType", "TextValue": '["2"]'},
            {"Key": "cookies", "TextValue": '{"doc_offset":20,"scene":101}'},
        ],
    }


def test_search_article_omits_read_fields_when_response_has_no_reading_hotness(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    item = _make_article_item(
        tag_title=None,
        report_extinfo_str="src_channel%3D1930611252_4_0_4075929821_13",
    )
    api_resp = _make_websearch_response(
        _make_article_inner_payload(items=[item], continue_flag=0, offset=20)
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    item_payload = payload["data"]["items"][0]
    assert "read_count" not in item_payload
    assert "read_count_text" not in item_payload


def test_search_article_ignores_non_reading_source_tags(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    item = _make_article_item(
        tag_title=None,
        report_extinfo_str="src_channel%3D1930611252_4_0_4075929821_13",
    )
    item["source"] = {
        "title": "新华社",
        "tag": [{"title": "已关注", "type": 1, "noBg": True}],
    }
    api_resp = _make_websearch_response(
        _make_article_inner_payload(items=[item], continue_flag=0, offset=20)
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    item_payload = payload["data"]["items"][0]
    assert "read_count_text" not in item_payload


def test_search_article_prefers_reading_tag_when_other_tags_appear_first(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    item = _make_article_item(tag_title=None)
    item["source"] = {
        "title": "新华社",
        "tag": [
            {"title": "已关注", "type": 1, "noBg": True},
            {"title": "阅读 10万+", "type": 2, "noBg": True},
        ],
    }
    api_resp = _make_websearch_response(
        _make_article_inner_payload(items=[item], continue_flag=0, offset=20)
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"]["items"][0]["read_count_text"] == "阅读 10万+"


def test_search_article_allows_empty_summary_string(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    item = _make_article_item(desc="")
    api_resp = _make_websearch_response(
        _make_article_inner_payload(items=[item], continue_flag=0, offset=20)
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"]["items"][0]["summary"] == ""


def test_search_article_allows_empty_source_title(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    item = _make_article_item(source_name="")
    api_resp = _make_websearch_response(
        _make_article_inner_payload(items=[item], continue_flag=0, offset=20)
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"]["items"][0]["source_name"] == ""


def test_search_article_treats_missing_source_title_as_empty(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    item = _make_article_item()
    # 模拟真实场景：source 字段存在但完全没有 title 键，比如某些公众号的服务号文章
    item["source"] = {"tag": [{"title": "阅读 1万+", "type": 2, "noBg": True}]}
    api_resp = _make_websearch_response(
        _make_article_inner_payload(items=[item], continue_flag=0, offset=20)
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"]["items"][0]["source_name"] == ""


def test_search_article_returns_success_empty_list_when_no_article_group_exists(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(
        {"continueFlag": 0, "offset": 0, "searchID": "search-id-empty", "cookies": "{}", "data": []}
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"] == {
        "keyword": "微信",
        "sort": "default",
        "has_more": False,
        "items": [],
    }


def test_search_article_returns_success_empty_list_when_article_group_items_are_empty(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(
        _make_article_inner_payload(
            items=[],
            continue_flag=1,
            offset=23,
            search_id="search-id-empty-items",
        )
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"] == {
        "keyword": "微信",
        "sort": "default",
        "has_more": False,
        "items": [],
    }


def test_search_article_empty_group_forces_has_more_false(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = _make_websearch_response(
        {
            "continueFlag": 1,
            "offset": 23,
            "searchID": "search-id-empty-next",
            "cookies": '{"doc_offset":23,"scene":101}',
            "data": [{"type": 7, "items": []}],
        }
    )
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"] == {
        "keyword": "微信",
        "sort": "default",
        "has_more": False,
        "items": [],
    }


def test_search_article_requires_exactly_one_of_keyword_or_cursor(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main(["search", "article"]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert err_data["code"] == 2
    assert "exactly one of --keyword or --cursor" in err_data["message"]


def test_search_article_rejects_keyword_and_cursor_together(
    capsys: pytest.CaptureFixture[str],
) -> None:
    cursor = _encode_cursor(
        {
            "v": 1,
            "keyword": "微信",
            "sort": "default",
            "offset": 23,
            "search_id": "search-id-2",
            "cookies": '{"doc_offset":23,"scene":101}',
        }
    )
    assert main(["search", "article", "--keyword", "微信", "--cursor", cursor]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert "exactly one of --keyword or --cursor" in err_data["message"]


def test_search_article_rejects_sort_with_cursor(capsys: pytest.CaptureFixture[str]) -> None:
    cursor = _encode_cursor(
        {
            "v": 1,
            "keyword": "微信",
            "sort": "hot",
            "offset": 20,
            "search_id": "search-id-sort",
            "cookies": '{"doc_offset":20,"scene":101}',
        }
    )
    assert main(["search", "article", "--cursor", cursor, "--sort", "hot"]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert "Do not pass --sort together with --cursor" in err_data["message"]


def test_search_article_rejects_invalid_cursor(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["search", "article", "--cursor", "not-a-cursor"]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert err_data["code"] == 2
    assert "not a valid article-search cursor" in err_data["message"]


def test_search_article_rejects_cursor_with_wrong_version(
    capsys: pytest.CaptureFixture[str],
) -> None:
    cursor = _encode_cursor(
        {
            "v": 999,
            "keyword": "微信",
            "sort": "default",
            "offset": 23,
            "search_id": "search-id-2",
            "cookies": '{"doc_offset":23,"scene":101}',
        }
    )
    assert main(["search", "article", "--cursor", cursor]) == 2
    captured = capsys.readouterr()
    err_data = json.loads(captured.err)
    assert "Cursor version is unsupported" in err_data["message"]


def test_search_article_reports_runtime_error_when_inner_json_missing(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {
        "code": 200,
        "data": {"baseResponse": {"ret": 0, "errMsg": {"str": ""}}, "updateCode": 0, "offset": 20},
        "message": "",
    }
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == -999
    assert "data.json is missing or empty" in err_data["message"]


def test_search_article_reports_runtime_error_when_inner_json_is_invalid(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {
        "code": 200,
        "data": {
            "baseResponse": {"ret": 0, "errMsg": {"str": ""}},
            "updateCode": 0,
            "offset": 20,
            "json": "{bad json",
        },
        "message": "",
    }
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(cli, ["search", "article", "--keyword", "微信"], env=ENV)
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == -999
    assert "data.json is not valid JSON" in err_data["message"]


def test_search_article_help_describes_article_list_cursor_and_three_sorts() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["search", "article", "--help"])
    assert result.exit_code == 0
    assert "article list" in result.output
    assert "--cursor" in result.output
    assert "default" in result.output
    assert "newest" in result.output
    assert "hot" in result.output


def test_search_article_internal_helpers_cover_validation_edges() -> None:
    with pytest.raises(WxflywheelError, match="inner data\\[\\] groups"):
        _build_article_output(
            {"json": json.dumps({"continueFlag": 0})},
            keyword="微信",
            sort_name="default",
        )

    assert _find_article_group([1, {"type": 7}, {"type": "2", "items": []}]) == {
        "type": "2",
        "items": [],
    }

    with pytest.raises(WxflywheelError, match="items field is not a list"):
        _normalize_article_items({"items": []})

    assert _extract_read_count_text([123, {"title": ""}]) is None
    assert _extract_read_count(None) is None

    with pytest.raises(click.BadParameter, match="Cursor is empty"):
        _decode_cursor("   ")

    raw_list_cursor = (
        base64.urlsafe_b64encode(json.dumps(["bad"]).encode("utf-8")).decode("ascii").rstrip("=")
    )
    with pytest.raises(click.BadParameter, match="not a JSON object"):
        _decode_cursor(raw_list_cursor)

    for payload, expected_message in (
        (
            {"v": 1, "keyword": "", "sort": "default", "offset": 1, "search_id": "sid"},
            "missing a valid keyword field",
        ),
        (
            {"v": 1, "keyword": "微信", "sort": "bad", "offset": 1, "search_id": "sid"},
            "missing a valid sort field",
        ),
        (
            {"v": 1, "keyword": "微信", "sort": "default", "offset": 1, "search_id": ""},
            "missing a valid search_id field",
        ),
        (
            {
                "v": 1,
                "keyword": "微信",
                "sort": "default",
                "offset": 1,
                "search_id": "sid",
                "cookies": 1,
            },
            "cookies field must be a string",
        ),
        (
            {
                "v": 1,
                "keyword": "微信",
                "sort": "default",
                "offset": "not-a-number",
                "search_id": "sid",
            },
            "cursor.offset is missing or not numeric",
        ),
    ):
        with pytest.raises(click.BadParameter, match=expected_message):
            _decode_cursor(_encode_cursor(payload))

    with pytest.raises(WxflywheelError, match="not a JSON object"):
        _require_dict([], field_name="bad_dict")
    with pytest.raises(WxflywheelError, match="not a non-empty string"):
        _require_string("", field_name="bad_string")
    with pytest.raises(WxflywheelError, match="not numeric"):
        _coerce_intlike("bad", field_name="bad_int")

    assert _try_coerce_intlike(True) is None
    assert _try_coerce_intlike(7) == 7
    assert _try_coerce_intlike(7.0) == 7
    assert _try_coerce_intlike("8") == 8
    assert _try_coerce_intlike(" ") is None
    assert _try_coerce_intlike("bad") is None
    assert _try_coerce_intlike(None) is None


class TestSearchVideoCommand:
    def test_video_command_first_page_default_tab(self, mock_resp: MockRespFactory) -> None:
        inner = _make_video_inner_payload(continue_flag=1)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        assert result.exit_code == 0, result.output
        payload = json.loads(result.output)
        data = payload["data"]
        assert data["keyword"] == "小龙虾"
        assert data["tab"] == "default"
        assert data["has_more"] is True
        assert "next_cursor" in data
        call_body = mock_client.return_value.post.call_args[1]["body"]
        assert call_body == {
            "KeyWord": "小龙虾",
            "Offset": 0,
            "BusinessType": 7,
            "Scene": 101,
            "SearchId": "",
        }
        item = data["items"][0]
        assert item["video_id"] == "finderobjv0cDZu92mZj8B6ZR/Ej56SnGEfgjqopXagtc3co4MzAxw="
        assert item["export_id"] == "export/UzFfBgAAxMmCEFtyXjHbjczT4DCKdoMAzvlObHSgLbTokaK-fQ"
        assert item["hash_doc_id"] == "15159504240972239737"
        assert item["title"] == "小龙虾销量⚜️ 第1⃣️ ⚜️"
        assert (
            item["cover_url"]
            == "https://findermp.video.qq.com/251/20304/stodownload?encfilekey=live-sample"
        )
        assert item["account_name"] == "小蜗聊AI"
        assert item["account_icon_url"] == (
            "https://wx.qlogo.cn/finderhead/ver_1/hXJxkczSPqU0RXLusGGwyfKgHnrgLQVicby882rbuETMnn6yTTMD5RA0CGK3lfB3xm0aZ6PX3562whXASrp8xEWYO8jFahRUtyo44VClmhqyiajDkMP5kia90ygTbqfPicKrxX2FW6qAenk45Qsf7TWMyQ/132"
        )
        assert item["duration_text"] == "02:56"
        assert item["published_at_text"] == "31分钟前"
        assert item["published_at_ts"] == 1776239346
        assert item["show_type"] == 1
        assert item["interaction_metrics"] == {
            "like_count": 12,
            "comment_count": 2,
            "forward_count": 1,
            "thumb_count": 0,
        }
        assert set(item.keys()) == {
            "video_id",
            "export_id",
            "hash_doc_id",
            "title",
            "cover_url",
            "account_name",
            "account_icon_url",
            "duration_text",
            "published_at_text",
            "published_at_ts",
            "show_type",
            "interaction_metrics",
        }

    def test_video_command_first_page_newest_tab(self, mock_resp: MockRespFactory) -> None:
        inner = _make_video_inner_payload(continue_flag=1)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(
                cli,
                ["search", "video", "--keyword", "小龙虾", "--tab", "newest"],
                env=ENV,
            )
        assert result.exit_code == 0, result.output
        payload = json.loads(result.output)
        assert payload["data"]["tab"] == "newest"
        call_body = mock_client.return_value.post.call_args[1]["body"]
        assert {"Key": "FinderTabAdvanceSearch", "TextValue": '["2"]'} in call_body["ExtReqParams"]

    def test_video_command_follow_up_cursor(self, mock_resp: MockRespFactory) -> None:
        cursor = _encode_video_cursor(
            {
                "v": 1,
                "keyword": "小龙虾",
                "tab": "default",
                "offset": 23,
                "search_id": "video-search-id-2",
                "cookies": '{"doc_offset":23,"scene":101}',
            }
        )
        inner = _make_video_inner_payload(continue_flag=0, offset=42, search_id="video-search-id-2")
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--cursor", cursor], env=ENV)
        assert result.exit_code == 0, result.output
        call_body = mock_client.return_value.post.call_args[1]["body"]
        assert call_body["KeyWord"] == "小龙虾"
        assert call_body["Offset"] == 23
        assert call_body["SearchId"] == "video-search-id-2"
        assert {"Key": "cookies", "TextValue": '{"doc_offset":23,"scene":101}'} in call_body[
            "ExtReqParams"
        ]

    def test_video_command_rejects_both_keyword_and_cursor(self) -> None:
        cursor = _encode_video_cursor(
            {
                "v": 1,
                "keyword": "小龙虾",
                "tab": "default",
                "offset": 0,
                "search_id": "video-search-id-3",
                "cookies": None,
            }
        )
        result = main(["search", "video", "--keyword", "小龙虾", "--cursor", cursor])
        assert result == 2

    def test_video_command_rejects_neither_keyword_nor_cursor(self) -> None:
        result = main(["search", "video"])
        assert result == 2

    def test_video_command_rejects_tab_with_cursor(self, mock_resp: MockRespFactory) -> None:
        cursor = _encode_video_cursor(
            {
                "v": 1,
                "keyword": "小龙虾",
                "tab": "default",
                "offset": 0,
                "search_id": "video-search-id-4",
                "cookies": None,
            }
        )
        result = main(["search", "video", "--cursor", cursor, "--tab", "newest"])
        assert result == 2

    def test_video_command_no_more_data_inner_short_circuit(self) -> None:
        inner = _make_video_inner_payload(continue_flag=1, no_more_inner=True)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        assert payload["has_more"] is False
        assert payload["items"] == []
        assert "next_cursor" not in payload

    def test_video_command_no_more_data_outer_short_circuit(self) -> None:
        inner = _make_video_inner_payload(continue_flag=1)
        resp = _make_websearch_response(inner)
        data_payload = resp["data"]
        assert isinstance(data_payload, dict)
        data_payload["noMoreData"] = True
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        assert payload["has_more"] is False
        assert payload["items"] == []
        assert "next_cursor" not in payload

    def test_video_command_no_video_group_only_account(self) -> None:
        inner = _make_video_inner_payload(
            with_outer_video_group=False,
            extra_groups=[
                {"type": 62, "real_type": 33554434, "items": [_make_video_item()]},
            ],
        )
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        assert payload["has_more"] is False
        assert payload["items"] == []

    def test_video_command_empty_video_group(self) -> None:
        inner = _make_video_inner_payload(items=[])
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        assert payload["has_more"] is False
        assert payload["items"] == []

    def test_video_command_normalize_item_source_title_none(self) -> None:
        item = _make_video_item(source_name=None)
        inner = _make_video_inner_payload(items=[item], continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        assert payload["items"][0]["account_name"] == ""

    def test_video_command_normalize_item_source_object_missing(self) -> None:
        item = _make_video_item()
        del item["source"]
        inner = _make_video_inner_payload(items=[item], continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        assert payload["items"][0]["account_name"] == ""
        assert payload["items"][0]["account_icon_url"] == ""

    def test_video_command_normalize_item_clean_highlight_title(self) -> None:
        item = _make_video_item(title='<em class="highlight">小龙虾</em>销量')
        inner = _make_video_inner_payload(items=[item], continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        assert payload["items"][0]["title"] == "小龙虾销量"

    def test_video_command_continue_flag_zero_has_more_false(self) -> None:
        inner = _make_video_inner_payload(continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        assert payload["has_more"] is False
        assert "next_cursor" not in payload

    def test_video_command_continue_flag_one_has_next_cursor(self) -> None:
        inner = _make_video_inner_payload(continue_flag=1, offset=20, search_id="video-search-id-5")
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        decoded = _decode_video_cursor(payload["next_cursor"])
        assert decoded["keyword"] == "小龙虾"
        assert decoded["tab"] == "default"
        assert decoded["offset"] == 20
        assert decoded["search_id"] == "video-search-id-5"

    def test_video_command_normalize_item_missing_report_extinfo(self) -> None:
        item = _make_video_item(report_extinfo_str=None)
        inner = _make_video_inner_payload(items=[item], continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        assert payload["items"][0]["interaction_metrics"] == {
            "like_count": None,
            "comment_count": None,
            "forward_count": None,
            "thumb_count": None,
        }

    @pytest.mark.parametrize(
        ("report_extinfo_str", "expected"),
        [
            (
                '{"like_cnt":3,"comment_cnt":2,"forward_cnt":4,"thumb_cnt":1}',
                {
                    "like_count": 3,
                    "comment_count": 2,
                    "forward_count": 4,
                    "thumb_count": 1,
                },
            ),
            (
                '{"like_cnt":3.9,"comment_cnt":2.0,"forward_cnt":0.0,"thumb_cnt":4.0}',
                {
                    "like_count": 3,
                    "comment_count": 2,
                    "forward_count": 0,
                    "thumb_count": 4,
                },
            ),
            (
                '{"like_cnt":"8","comment_cnt":"9","forward_cnt":"0","thumb_cnt":"2"}',
                {
                    "like_count": 8,
                    "comment_count": 9,
                    "forward_count": 0,
                    "thumb_count": 2,
                },
            ),
            (
                '{"like_cnt":true,"comment_cnt":false,"forward_cnt":"bad","thumb_cnt":"",}',
                {
                    "like_count": None,
                    "comment_count": None,
                    "forward_count": None,
                    "thumb_count": None,
                },
            ),
            (
                "",
                {
                    "like_count": None,
                    "comment_count": None,
                    "forward_count": None,
                    "thumb_count": None,
                },
            ),
        ],
    )
    def test_video_command_normalize_report_extinfo_variants(
        self, report_extinfo_str: str | None, expected: dict[str, int | None]
    ) -> None:
        item = _make_video_item(report_extinfo_str=report_extinfo_str)
        inner = _make_video_inner_payload(items=[item], continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        payload = json.loads(result.output)["data"]
        assert payload["items"][0]["interaction_metrics"] == expected

    def test_video_command_normalize_item_missing_docid(self) -> None:
        item = _make_video_item()
        del item["docID"]
        inner = _make_video_inner_payload(items=[item], continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        assert result.exit_code == 1
        err_data = json.loads(result.stderr)
        assert "video item #1.docID is missing or not a string" in err_data["message"]

    def test_video_command_error_missing_data_json(self) -> None:
        with pytest.raises(WxflywheelError) as exc_info:
            _build_video_output(
                {"json": ""},
                keyword="小龙虾",
                tab_name="default",
            )
        assert "data.json is missing or empty" in exc_info.value.message

    def test_video_command_error_invalid_inner_json(self) -> None:
        payload = {"json": "{bad json"}
        with pytest.raises(WxflywheelError) as exc_info:
            _build_video_output(payload, keyword="小龙虾", tab_name="default")
        assert "data.json is not valid JSON" in exc_info.value.message

    def test_video_command_error_inner_payload_not_dict(self) -> None:
        payload = {"json": json.dumps([])}
        with pytest.raises(WxflywheelError) as exc_info:
            _build_video_output(payload, keyword="小龙虾", tab_name="default")
        assert "not a JSON object" in exc_info.value.message

    def test_video_command_error_outer_payload_not_dict(self) -> None:
        with pytest.raises(WxflywheelError, match="is not a JSON object"):
            _build_video_output("bad", keyword="小龙虾", tab_name="default")

    def test_video_command_error_inner_data_not_list(self) -> None:
        payload = {"json": json.dumps({"continueFlag": 1, "offset": 1, "searchID": "sid"})}
        with pytest.raises(WxflywheelError):
            _build_video_output(payload, keyword="小龙虾", tab_name="default")

    def test_video_group_nested_subbox_flattens(self) -> None:
        item_a = _make_video_item(doc_id="finderobjv0A")
        item_b = _make_video_item(doc_id="finderobjv0B", title="第二条")
        groups = [
            {
                "type": 107,
                "subBoxes": [
                    {"type": 84, "items": [item_a]},
                    {"type": 84, "items": [item_b]},
                ],
            }
        ]
        items = _collect_video_items(groups)
        assert len(items) == 2
        assert items[0]["docID"] == "finderobjv0A"
        assert items[1]["docID"] == "finderobjv0B"

    def test_video_group_non_dict_outer_group_is_skipped(self) -> None:
        item = _make_video_item(doc_id="finderobjv0A")
        groups = [None, {"type": 107, "subBoxes": [{"type": 84, "items": [item]}]}]
        items = _collect_video_items(groups)
        assert len(items) == 1
        assert items[0]["docID"] == "finderobjv0A"

    def test_video_group_skips_non_video_subbox(self) -> None:
        item_keep = _make_video_item(doc_id="finderobjKeep")
        item_skip = _make_video_item(doc_id="finderobjSkip")
        groups = [
            {
                "type": 107,
                "subBoxes": [
                    {"type": 24, "items": [item_skip]},
                    {"type": 84, "items": [item_keep]},
                ],
            }
        ]
        items = _collect_video_items(groups)
        assert len(items) == 1
        assert items[0]["docID"] == "finderobjKeep"

    def test_video_group_skips_non_dict_subbox(self) -> None:
        item_keep = _make_video_item(doc_id="finderobjKeep")
        groups = [
            {
                "type": 107,
                "subBoxes": [
                    "skip-me",
                    {"type": 84, "items": [item_keep]},
                ],
            }
        ]
        items = _collect_video_items(groups)
        assert len(items) == 1
        assert items[0]["docID"] == "finderobjKeep"

    def test_video_group_skips_subbox_items_when_not_list(self) -> None:
        item = _make_video_item(doc_id="finderobjKeep")
        groups = [
            {
                "type": 107,
                "subBoxes": [
                    {"type": 84, "items": "not-list"},
                    {"type": 84, "items": [item]},
                ],
            }
        ]
        items = _collect_video_items(groups)
        assert len(items) == 1
        assert items[0]["docID"] == "finderobjKeep"

    def test_video_normalize_new_fields(self) -> None:
        item = _make_video_item(
            title='<em class="highlight">AI</em> 智能体训练',
            doc_id="finderobjv04e0C+njNUGKHJ5gqcpQbjySaSA7q6CgkDBDBNOyfPeI=",
            export_id="export/UzFfBgAAxKKicBEPNFmBjczT4DCKgKU4FVE4fMbBDEQFgAmZXA",
            hash_doc_id="15159504240972239737",
            image_url="https://findermp.video.qq.com/251/20304/stodownload?encfilekey=changed",
            duration="03:21",
            published_at_text="31分钟前",
            published_at_ts=1776239346,
            source_name="小蜗聊AI",
            source_icon_url="https://wx.qlogo.cn/finderhead/abc/132",
            show_type=1,
            report_extinfo_str=(
                '{"like_cnt": 1, "comment_cnt": 2, "forward_cnt": 3, "thumb_cnt": 4}'
            ),
        )
        inner = _make_video_inner_payload(items=[item], continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "AI"], env=ENV)
        assert result.exit_code == 0, result.output
        normalized = json.loads(result.output)["data"]["items"][0]
        assert normalized == {
            "video_id": "finderobjv04e0C+njNUGKHJ5gqcpQbjySaSA7q6CgkDBDBNOyfPeI=",
            "export_id": "export/UzFfBgAAxKKicBEPNFmBjczT4DCKgKU4FVE4fMbBDEQFgAmZXA",
            "hash_doc_id": "15159504240972239737",
            "title": "AI 智能体训练",
            "cover_url": "https://findermp.video.qq.com/251/20304/stodownload?encfilekey=changed",
            "account_name": "小蜗聊AI",
            "account_icon_url": "https://wx.qlogo.cn/finderhead/abc/132",
            "duration_text": "03:21",
            "published_at_text": "31分钟前",
            "published_at_ts": 1776239346,
            "show_type": 1,
            "interaction_metrics": {
                "like_count": 1,
                "comment_count": 2,
                "forward_count": 3,
                "thumb_count": 4,
            },
        }

    def test_video_build_result_empty_when_normalize_returns_empty(self) -> None:
        inner = _make_video_inner_payload(continue_flag=1)
        with patch("wxflywheel.commands.search._normalize_video_items") as mock_normalize:
            mock_normalize.return_value = []
            result = _build_video_output(
                {"json": json.dumps(inner)}, keyword="小龙虾", tab_name="default"
            )
        assert result == {
            "keyword": "小龙虾",
            "tab": "default",
            "has_more": False,
            "items": [],
        }

    def test_video_normalize_missing_pub_time_falls_back_to_zero(self) -> None:
        # Regression: `pubTime` / `showType` are best-effort — WeChat Search
        # BT=7 returns null or omits these fields for livestream items and
        # schema variants. Align with frontend `?? 0` fallback to avoid
        # breaking the whole list. This replaces the old 0.10.x behavior
        # where pubTime non-int raised a hard error (regression guard).
        item = _make_video_item()
        item["pubTime"] = "not-int"  # invalid; expect fallback 0
        inner = _make_video_inner_payload(items=[item], continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "小龙虾"], env=ENV)
        assert result.exit_code == 0
        body = json.loads(result.output)
        assert body["data"]["items"][0]["published_at_ts"] == 0

    def test_video_normalize_item_with_null_optional_strings(self) -> None:
        # Regression: real-world bug discovered 2026-04-15 during keyword
        # "美食" E2E test. Some video items return duration / dateTime /
        # image / title / exportId / hashDocID as JSON null (livestream
        # items or certain rare schema variants). Before 0.11.1 the CLI
        # raised "field is missing or not a string" and the entire search
        # returned items=[] — breaking all users who searched keywords that
        # hit these items. Fix: coerce None to "" before _require_string.
        item = _make_video_item()
        item["duration"] = None
        item["dateTime"] = None
        item["image"] = None
        item["title"] = None
        item["exportId"] = None
        item["hashDocID"] = None
        # pubTime missing entirely
        item.pop("pubTime", None)
        # showType null
        item["showType"] = None
        inner = _make_video_inner_payload(items=[item], continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "video", "--keyword", "美食"], env=ENV)
        assert result.exit_code == 0, result.output
        normalized = json.loads(result.output)["data"]["items"][0]
        assert normalized["duration_text"] == ""
        assert normalized["published_at_text"] == ""
        assert normalized["cover_url"] == ""
        assert normalized["title"] == ""
        assert normalized["export_id"] == ""
        assert normalized["hash_doc_id"] == ""
        assert normalized["published_at_ts"] == 0
        assert normalized["show_type"] == 0

    def test_video_normalize_video_items_rejects_non_list(self) -> None:
        with pytest.raises(WxflywheelError, match="items field is not a list"):
            _normalize_video_items("bad")

    def test_video_extract_video_interaction_metrics_shape_variants(self) -> None:
        assert _extract_video_interaction_metrics(7) == {
            "like_count": None,
            "comment_count": None,
            "forward_count": None,
            "thumb_count": None,
        }
        assert _extract_video_interaction_metrics("[]") == {
            "like_count": None,
            "comment_count": None,
            "forward_count": None,
            "thumb_count": None,
        }
        assert _extract_video_interaction_metrics(
            '{"like_cnt": true, "comment_cnt": null, "forward_cnt": "bad", "thumb_cnt": "2"}'
        ) == {
            "like_count": None,
            "comment_count": None,
            "forward_count": None,
            "thumb_count": 2,
        }
        assert _extract_video_interaction_metrics(
            '{"like_cnt": {}, "comment_cnt": [], "forward_cnt": {"n": 1}, "thumb_cnt": "2"}'
        ) == {
            "like_count": None,
            "comment_count": None,
            "forward_count": None,
            "thumb_count": 2,
        }

    def test_video_command_help_describes_video_list_and_tabs(self) -> None:
        result = CliRunner().invoke(cli, ["search", "video", "--help"])
        assert result.exit_code == 0
        assert "--keyword" in result.output
        assert "--cursor" in result.output
        assert "default" in result.output
        assert "newest" in result.output

    def test_video_cursor_encode_decode_roundtrip_with_and_without_cookies(self) -> None:
        for cookies in ('{"doc_offset":0,"scene":101}', None):
            cursor = _encode_video_cursor(
                {
                    "v": 1,
                    "keyword": "小龙虾",
                    "tab": "newest",
                    "offset": 23,
                    "search_id": "video-search-id-6",
                    "cookies": cookies,
                }
            )
            decoded = _decode_video_cursor(cursor)
            assert decoded["keyword"] == "小龙虾"
            assert decoded["tab"] == "newest"
            assert decoded["offset"] == 23
            assert decoded["search_id"] == "video-search-id-6"
            assert decoded["cookies"] == cookies

    def test_video_cursor_decode_rejects_wrong_version(self) -> None:
        with pytest.raises(click.BadParameter, match="unsupported"):
            _decode_video_cursor(
                _encode_video_cursor(
                    {
                        "v": 999,
                        "keyword": "小龙虾",
                        "tab": "default",
                        "offset": 1,
                        "search_id": "sid",
                    }
                )
            )

    def test_video_cursor_decode_rejects_wrong_tab(self) -> None:
        with pytest.raises(click.BadParameter, match="missing a valid tab"):
            _decode_video_cursor(
                _encode_video_cursor(
                    {
                        "v": 1,
                        "keyword": "小龙虾",
                        "tab": "bad-tab",
                        "offset": 1,
                        "search_id": "sid",
                    }
                )
            )

    @pytest.mark.parametrize(
        ("payload", "message"),
        [
            (
                {"v": 1, "tab": "default", "offset": 1, "search_id": "sid"},
                "missing a valid keyword",
            ),
            (
                {
                    "v": 1,
                    "keyword": "小龙虾",
                    "tab": "default",
                    "offset": 1,
                    "search_id": "",
                },
                "missing a valid search_id",
            ),
        ],
    )
    def test_video_cursor_decode_rejects_missing_fields(
        self, payload: dict[str, object], message: str
    ) -> None:
        with pytest.raises(click.BadParameter, match=message):
            _decode_video_cursor(_encode_video_cursor(payload))

    def test_video_cursor_decode_rejects_non_numeric_offset(self) -> None:
        with pytest.raises(click.BadParameter, match="cursor.offset is missing or not numeric"):
            _decode_video_cursor(
                _encode_video_cursor(
                    {
                        "v": 1,
                        "keyword": "小龙虾",
                        "tab": "default",
                        "offset": "abc",
                        "search_id": "sid",
                    }
                )
            )

    def test_video_cursor_decode_rejects_empty(self) -> None:
        with pytest.raises(click.BadParameter, match="Cursor is empty"):
            _decode_video_cursor("")

    def test_video_cursor_decode_rejects_invalid_payload(self) -> None:
        with pytest.raises(click.BadParameter, match="is not a valid video-search cursor"):
            _decode_video_cursor("%%%")

    def test_video_cursor_decode_rejects_non_dict_payload(self) -> None:
        with pytest.raises(
            click.BadParameter,
            match="Cursor is not a JSON object",
        ):
            _decode_video_cursor(base64.urlsafe_b64encode(b"[]").decode("ascii").rstrip("="))

    def test_video_cursor_decode_rejects_non_str_cookies(self) -> None:
        with pytest.raises(
            click.BadParameter,
            match="Cursor cookies field must be a string when present.",
        ):
            _decode_video_cursor(
                _encode_video_cursor(
                    {
                        "v": 1,
                        "keyword": "小龙虾",
                        "tab": "default",
                        "offset": 1,
                        "search_id": "sid",
                        "cookies": 123,
                    }
                )
            )

    def test_build_video_ext_req_params_newest(self) -> None:
        params = _build_video_ext_req_params(
            tab_name="newest",
            cookies=None,
        )
        assert params == [{"Key": "FinderTabAdvanceSearch", "TextValue": '["2"]'}]

    def test_build_video_ext_req_params_with_cookies(self) -> None:
        params = _build_video_ext_req_params(
            tab_name="default",
            cookies='{"doc_offset":10}',
        )
        assert params == [{"Key": "cookies", "TextValue": '{"doc_offset":10}'}]


class TestStickerCommand:
    def test_sticker_basic_keyword_search(self, mock_resp: MockRespFactory) -> None:
        inner = _make_sticker_inner_payload()
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "sticker", "--keyword", "龙虾"], env=ENV)
        assert result.exit_code == 0, result.output
        payload = json.loads(result.output)
        assert payload["code"] == 200
        data = payload["data"]
        assert data["keyword"] == "龙虾"
        assert data["tab"] == "all"
        assert data["has_more"] is True
        assert len(data["items"]) == 1
        item = data["items"][0]
        assert item["sticker_id"] == "2263028580860557921"
        assert item["title"] == "吃小龙虾的季节"
        assert item["source_name"] == "相约岁月"

    def test_sticker_keyword_xor_cursor_both_missing(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["search", "sticker"], env=ENV)
        assert result.exit_code != 0
        assert "Provide exactly one of --keyword or --cursor" in result.output

    def test_sticker_keyword_xor_cursor_both_provided(self) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["search", "sticker", "--keyword", "test", "--cursor", "abc"],
            env=ENV,
        )
        assert result.exit_code != 0
        assert "Provide exactly one of --keyword or --cursor" in result.output

    def test_sticker_tab_not_allowed_with_cursor(self) -> None:
        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["search", "sticker", "--cursor", "abc", "--tab", "newest"],
            env=ENV,
        )
        assert result.exit_code != 0
        assert "Do not pass --tab together with --cursor" in result.output

    def test_sticker_empty_result(self, mock_resp: MockRespFactory) -> None:
        inner = _make_sticker_inner_payload(items=[], continue_flag=0)
        # Manually make data[] an empty list to simulate no sticker groups
        inner["data"] = []
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "sticker", "--keyword", "不存在"], env=ENV)
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert payload["data"]["items"] == []
        assert payload["data"]["has_more"] is False

    def test_sticker_cursor_round_trip(self, mock_resp: MockRespFactory) -> None:
        """First search returns a cursor; second search uses it and gets results."""
        cursor = _encode_sticker_cursor(
            {
                "v": 1,
                "keyword": "龙虾",
                "tab": "hottest",
                "offset": 30,
                "search_id": "sid-1",
                "cookies": '{"x":1}',
            }
        )
        inner = _make_sticker_inner_payload(continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "sticker", "--cursor", cursor], env=ENV)
        assert result.exit_code == 0, result.output
        payload = json.loads(result.output)
        assert payload["data"]["keyword"] == "龙虾"
        assert payload["data"]["tab"] == "hottest"

    def test_sticker_all_16_fields_present(self, mock_resp: MockRespFactory) -> None:
        inner = _make_sticker_inner_payload()
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "sticker", "--keyword", "test"], env=ENV)
        payload = json.loads(result.output)
        item = payload["data"]["items"][0]
        expected_keys = {
            "sticker_id",
            "title",
            "source_name",
            "source_icon_url",
            "published_at_ts",
            "published_relative",
            "cover_url",
            "sticker_url",
            "content_type_code",
            "mp_doc_id",
            "rank",
            "report_id",
            "display_style",
            "source_type",
            "social_tags",
            "hide_control",
        }
        assert set(item.keys()) == expected_keys

    def test_sticker_multiple_items_across_groups(self, mock_resp: MockRespFactory) -> None:
        items = [
            _make_sticker_item(doc_id="1", inner_offset=1, title="first"),
            _make_sticker_item(doc_id="2", inner_offset=2, title="second"),
            _make_sticker_item(doc_id="3", inner_offset=3, title="third"),
        ]
        inner = _make_sticker_inner_payload(items=items)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "sticker", "--keyword", "test"], env=ENV)
        payload = json.loads(result.output)
        assert len(payload["data"]["items"]) == 3
        assert payload["data"]["items"][0]["sticker_id"] == "1"
        assert payload["data"]["items"][2]["sticker_id"] == "3"

    def test_sticker_tab_newest(self, mock_resp: MockRespFactory) -> None:
        inner = _make_sticker_inner_payload()
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(
                cli,
                ["search", "sticker", "--keyword", "test", "--tab", "newest"],
                env=ENV,
            )
        payload = json.loads(result.output)
        assert payload["data"]["tab"] == "newest"
        # Verify the API was called with correct ExtReqParams
        call_body = mock_client.return_value.post.call_args[1]["body"]
        ext = call_body.get("ExtReqParams", [])
        assert any(p["Key"] == "docSortType" for p in ext)


class TestStickerNormalization:
    def test_extract_sticker_items_from_groups_empty(self) -> None:
        assert _extract_sticker_items_from_groups([]) == []

    def test_extract_sticker_items_skips_non_107_groups(self) -> None:
        groups: list[object] = [{"type": 2, "items": [_make_sticker_item()]}]
        assert _extract_sticker_items_from_groups(groups) == []

    def test_normalize_sticker_item_strips_highlight_tags(self) -> None:
        raw = _make_sticker_item(title='吃<em class="highlight">龙虾</em>的季节')
        result = _normalize_sticker_item(raw, fallback_rank=1)
        assert result["title"] == "吃龙虾的季节"

    def test_normalize_sticker_item_fallback_rank(self) -> None:
        raw = _make_sticker_item()
        del raw["inner_offset"]
        result = _normalize_sticker_item(raw, fallback_rank=99)
        assert result["rank"] == 99

    def test_normalize_sticker_item_source_not_dict(self) -> None:
        raw = _make_sticker_item()
        raw["source"] = "not-a-dict"
        with pytest.raises(WxflywheelError, match="sticker source.title"):
            _normalize_sticker_item(raw, fallback_rank=1)

    def test_normalize_sticker_item_jumpinfo_not_dict(self) -> None:
        raw = _make_sticker_item()
        raw["jumpInfo"] = "not-a-dict"
        with pytest.raises(WxflywheelError, match="sticker jumpInfo.jumpUrl"):
            _normalize_sticker_item(raw, fallback_rank=1)

    def test_extract_skips_non_dict_groups(self) -> None:
        groups: list[object] = ["not-a-dict", 123, None]
        assert _extract_sticker_items_from_groups(groups) == []

    def test_extract_skips_group_without_subboxes_list(self) -> None:
        groups: list[object] = [{"type": 107, "subBoxes": "not-a-list"}]
        assert _extract_sticker_items_from_groups(groups) == []

    def test_extract_skips_non_dict_subbox(self) -> None:
        groups: list[object] = [{"type": 107, "subBoxes": ["not-a-dict"]}]
        assert _extract_sticker_items_from_groups(groups) == []

    def test_extract_skips_subbox_without_items_list(self) -> None:
        groups: list[object] = [{"type": 107, "subBoxes": [{"type": 84, "items": "bad"}]}]
        assert _extract_sticker_items_from_groups(groups) == []

    def test_extract_skips_non_dict_item(self) -> None:
        groups: list[object] = [{"type": 107, "subBoxes": [{"type": 84, "items": ["not-a-dict"]}]}]
        assert _extract_sticker_items_from_groups(groups) == []


class TestStickerCursor:
    def test_encode_decode_round_trip(self) -> None:
        original = {
            "v": 1,
            "keyword": "龙虾",
            "tab": "hottest",
            "offset": 30,
            "search_id": "sid",
            "cookies": '{"x":1}',
        }
        encoded = _encode_sticker_cursor(original)
        decoded = _decode_sticker_cursor(encoded)
        assert decoded["keyword"] == "龙虾"
        assert decoded["tab"] == "hottest"
        assert decoded["offset"] == 30

    def test_decode_invalid_cursor(self) -> None:
        with pytest.raises(click.BadParameter):
            _decode_sticker_cursor("not-valid-base64!!!")

    def test_decode_wrong_version(self) -> None:
        encoded = _encode_sticker_cursor(
            {
                "v": 999,
                "keyword": "x",
                "tab": "all",
                "offset": 0,
                "search_id": "s",
            }
        )
        with pytest.raises(click.BadParameter, match="unsupported"):
            _decode_sticker_cursor(encoded)

    def test_decode_empty_cursor(self) -> None:
        with pytest.raises(click.BadParameter, match="empty"):
            _decode_sticker_cursor("")

    def test_decode_whitespace_only_cursor(self) -> None:
        with pytest.raises(click.BadParameter, match="empty"):
            _decode_sticker_cursor("   ")

    def test_decode_not_json_object(self) -> None:
        encoded = base64.urlsafe_b64encode(json.dumps(["bad"]).encode("utf-8"))
        raw = encoded.decode("ascii").rstrip("=")
        with pytest.raises(click.BadParameter, match="not a JSON object"):
            _decode_sticker_cursor(raw)

    def test_decode_missing_keyword(self) -> None:
        encoded = _encode_sticker_cursor(
            {
                "v": 1,
                "keyword": "",
                "tab": "all",
                "offset": 0,
                "search_id": "s",
            }
        )
        with pytest.raises(click.BadParameter, match="missing a valid keyword"):
            _decode_sticker_cursor(encoded)

    def test_decode_invalid_tab(self) -> None:
        encoded = _encode_sticker_cursor(
            {
                "v": 1,
                "keyword": "x",
                "tab": "bad-tab",
                "offset": 0,
                "search_id": "s",
            }
        )
        with pytest.raises(click.BadParameter, match="missing a valid tab"):
            _decode_sticker_cursor(encoded)

    def test_decode_missing_search_id(self) -> None:
        encoded = _encode_sticker_cursor(
            {
                "v": 1,
                "keyword": "x",
                "tab": "all",
                "offset": 0,
                "search_id": "",
            }
        )
        with pytest.raises(click.BadParameter, match="missing a valid search_id"):
            _decode_sticker_cursor(encoded)

    def test_decode_cookies_not_string(self) -> None:
        encoded = _encode_sticker_cursor(
            {
                "v": 1,
                "keyword": "x",
                "tab": "all",
                "offset": 0,
                "search_id": "s",
                "cookies": 123,
            }
        )
        with pytest.raises(click.BadParameter, match="cookies field must be a string"):
            _decode_sticker_cursor(encoded)

    def test_decode_offset_not_numeric(self) -> None:
        encoded = _encode_sticker_cursor(
            {
                "v": 1,
                "keyword": "x",
                "tab": "all",
                "offset": "not-a-number",
                "search_id": "s",
            }
        )
        with pytest.raises(click.BadParameter, match="cursor.offset is missing or not numeric"):
            _decode_sticker_cursor(encoded)

    def test_decode_cookies_none_is_valid(self) -> None:
        encoded = _encode_sticker_cursor(
            {
                "v": 1,
                "keyword": "x",
                "tab": "all",
                "offset": 0,
                "search_id": "s",
            }
        )
        decoded = _decode_sticker_cursor(encoded)
        assert decoded["cookies"] is None


class TestStickerOutputBuilder:
    def test_build_sticker_output_missing_json(self) -> None:
        with pytest.raises(WxflywheelError, match="data.json is missing or empty"):
            _build_sticker_output(
                {"baseResponse": {"ret": 0}},
                keyword="test",
                tab_name="all",
            )

    def test_build_sticker_output_empty_json_string(self) -> None:
        with pytest.raises(WxflywheelError, match="data.json is missing or empty"):
            _build_sticker_output(
                {"json": "   "},
                keyword="test",
                tab_name="all",
            )

    def test_build_sticker_output_invalid_json(self) -> None:
        with pytest.raises(WxflywheelError, match="data.json is not valid JSON"):
            _build_sticker_output(
                {"json": "{bad json"},
                keyword="test",
                tab_name="all",
            )

    def test_build_sticker_output_null_data_returns_empty(self) -> None:
        """When data is null (e.g. interaction-tab with no results), return empty."""
        result = _build_sticker_output(
            {"json": json.dumps({"continueFlag": 0})},
            keyword="test",
            tab_name="all",
        )
        assert result["items"] == []
        assert result["has_more"] is False
        assert "total_count" not in result

    def test_build_sticker_output_inner_not_dict(self) -> None:
        with pytest.raises(WxflywheelError, match="not a JSON object"):
            _build_sticker_output(
                {"json": json.dumps("just-a-string")},
                keyword="test",
                tab_name="all",
            )

    def test_build_sticker_output_has_more_false_no_cursor(
        self, mock_resp: MockRespFactory
    ) -> None:
        inner = _make_sticker_inner_payload(continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            result = runner.invoke(cli, ["search", "sticker", "--keyword", "test"], env=ENV)
        payload = json.loads(result.output)
        assert payload["data"]["has_more"] is False
        assert "next_cursor" not in payload["data"]


class TestStickerExtReqParams:
    def test_tab_all_produces_no_ext_params(self, mock_resp: MockRespFactory) -> None:
        inner = _make_sticker_inner_payload()
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            runner.invoke(cli, ["search", "sticker", "--keyword", "test", "--tab", "all"], env=ENV)
        call_body = mock_client.return_value.post.call_args[1]["body"]
        assert "ExtReqParams" not in call_body

    def test_cursor_with_cookies_includes_cookies_param(self, mock_resp: MockRespFactory) -> None:
        cursor = _encode_sticker_cursor(
            {
                "v": 1,
                "keyword": "test",
                "tab": "hottest",
                "offset": 30,
                "search_id": "sid",
                "cookies": '{"doc_offset":30}',
            }
        )
        inner = _make_sticker_inner_payload(continue_flag=0)
        resp = _make_websearch_response(inner)
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.post.return_value = {
                "code": 200,
                "data": resp["data"],
                "message": "",
            }
            runner = CliRunner()
            runner.invoke(cli, ["search", "sticker", "--cursor", cursor], env=ENV)
        call_body = mock_client.return_value.post.call_args[1]["body"]
        ext = call_body.get("ExtReqParams", [])
        assert any(p["Key"] == "cookies" for p in ext)


# ---------------------------------------------------------------------------
# search sticker-detail
# ---------------------------------------------------------------------------


def _make_sticker_detail_response(*, comments_error: str | None = None) -> dict[str, Any]:
    data: dict[str, object] = {
        "sticker_info": {
            "title": "杭州3日游超全攻略",
            "author_name": "旅行达人",
            "account_name": "旅行笔记",
            "account_id": "gh_abc123",
            "account_avatar_url": "https://wx.qlogo.cn/mmhead/abc",
            "account_description": "分享旅行攻略",
            "account_verified": False,
            "published_at": "2026-04-09 15:30",
            "published_at_timestamp": 1775719800,
            "ip_location": "浙江",
            "article_url": "http://mp.weixin.qq.com/s?__biz=xyz&mid=2",
            "content_type": "贴图",
            "content_type_code": 8,
        },
        "text_content": "<a>杭州</a>三天怎么玩？",
        "pictures": [
            {
                "image_url": "https://mmbiz.qpic.cn/pic1.jpg",
                "width_px": 1080,
                "height_px": 1440,
                "theme_color_rgb": "#336699",
                "is_qr_code": False,
                "attached_product": None,
            },
            {
                "image_url": "https://mmbiz.qpic.cn/pic2.jpg",
                "width_px": 1080,
                "height_px": 810,
                "theme_color_rgb": "#99cc00",
                "is_qr_code": True,
                "attached_product": None,
            },
        ],
        "cover_images": {
            "default_url": "https://mmbiz.qpic.cn/cover.jpg",
            "square_1x1_url": "",
            "portrait_3x4_url": "",
            "image_format": "jpeg",
            "show_cover_in_feed": True,
            "watermark_enabled": False,
        },
        "engagement_metrics": {
            "read_count": 12300,
            "like_count": 88,
            "watching_count": 210,
            "share_count": 45,
            "collect_count": 320,
            "comment_count": 7,
            "comment_enabled": True,
        },
        "hashtags": ["杭州旅游", "三日游攻略"],
        "topics": [
            {
                "topic_name": "杭州旅游",
                "topic_read_count": 5800000,
                "topic_article_count": 1200,
                "topic_url": "https://mp.weixin.qq.com/topic/杭州旅游",
            },
        ],
        "monetization": {
            "has_advertisement": True,
            "ad_mark_visible": True,
            "footer_product_card": None,
            "footer_shops": [],
            "product_window_items": [{"product_id": "p1"}],
            "gift_activity": None,
            "product_activity": None,
            "tipping_enabled": False,
            "tipping_total_amount": 0,
            "tipping_prompt_text": "",
            "paid_subscription": {
                "is_paid": False,
                "preview_percent": 0,
                "price_description": "",
                "fee": 0,
            },
        },
        "copyright": {
            "is_original": True,
            "is_cartoon_copyright": False,
        },
        "comments": {
            "scope": "selected",
            "returned_count": 1,
            "total_selected_count": 3,
            "items": [
                {
                    "nick_name": "小红",
                    "avatar_url": "https://wx.qlogo.cn/mmhead/red",
                    "content": "收藏了！下周去",
                    "like_count": 5,
                    "posted_at_timestamp": 1775719900,
                    "ip_location": "上海",
                    "is_top": True,
                    "is_author_reply": False,
                    "replies": [
                        {
                            "nick_name": "旅行达人",
                            "content": "玩得开心~",
                            "like_count": 2,
                            "posted_at_timestamp": 1775720000,
                            "is_author": True,
                        }
                    ],
                },
            ],
        },
    }
    if comments_error is not None:
        data["comments_error"] = comments_error
    return {"code": 200, "data": data, "message": ""}


def test_search_sticker_detail_outputs_normalized_payload(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_response = _make_sticker_detail_response(comments_error="comment cgi timeout")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp(api_response),
    ):
        result = runner.invoke(
            cli,
            ["search", "sticker-detail", "--url", "http://mp.weixin.qq.com/s?__biz=xyz&mid=2"],
            env=ENV,
        )
    assert result.exit_code == 0
    payload = json.loads(result.output)
    data = payload["data"]

    # sticker_info (drawer section 1)
    assert data["sticker_info"] == {
        "title": "杭州3日游超全攻略",
        "account_name": "旅行笔记",
        "ip_location": "浙江",
        "published_at": "2026-04-09 15:30",
        "published_at_timestamp": 1775719800,
        "article_url": "http://mp.weixin.qq.com/s?__biz=xyz&mid=2",
        "is_original": True,
    }

    # pictures (drawer section 2)
    assert len(data["pictures"]) == 2
    assert data["pictures"][0] == {
        "image_url": "https://mmbiz.qpic.cn/pic1.jpg",
        "width_px": 1080,
        "height_px": 1440,
        "is_qr_code": False,
    }
    assert data["pictures"][1]["is_qr_code"] is True

    # engagement_metrics (drawer section 3)
    assert data["engagement_metrics"] == {
        "read_count": 12300,
        "like_count": 88,
        "watching_count": 210,
        "share_count": 45,
        "collect_count": 320,
        "comment_count": 7,
        "comment_enabled": True,
    }

    # text_content + hashtags (drawer section 4)
    assert data["text_content"] == "<a>杭州</a>三天怎么玩？"
    assert data["hashtags"] == ["杭州旅游", "三日游攻略"]

    # topics (drawer section 5)
    assert data["topics"] == [
        {"topic_name": "杭州旅游", "topic_read_count": 5800000, "topic_article_count": 1200},
    ]

    # monetization (drawer section 6)
    assert data["monetization"] == {
        "tipping_enabled": False,
        "has_advertisement": True,
        "product_window_item_count": 1,
        "paid_subscription": {"is_paid": False, "fee": 0},
    }

    # comments (drawer section 7)
    assert data["comments"]["scope"] == "selected"
    assert data["comments"]["returned_count"] == 1
    assert data["comments"]["total_selected_count"] == 3
    assert data["comments"]["items"][0] == {
        "nick_name": "小红",
        "content": "收藏了！下周去",
        "like_count": 5,
        "posted_at_timestamp": 1775719900,
        "ip_location": "上海",
        "is_top": True,
        "is_author_reply": False,
        "replies": [
            {
                "nick_name": "旅行达人",
                "content": "玩得开心~",
                "like_count": 2,
                "posted_at_timestamp": 1775720000,
                "is_author": True,
            }
        ],
    }

    assert data["comments_error"] == "comment cgi timeout"
    assert payload["meta"]["cli"]["current_version"] == __version__


def test_search_sticker_detail_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp(_make_sticker_detail_response()),
    ) as mock_get:
        runner.invoke(
            cli,
            ["search", "sticker-detail", "--url", "http://mp.weixin.qq.com/s?__biz=xyz&mid=2"],
            env=ENV,
        )
    called_url = mock_get.call_args.args[1]
    called_params = mock_get.call_args.kwargs["params"]
    assert called_url == "http://localhost:8011/v1/Gh/StickerDetail"
    assert called_params == {
        "key": "test-key",
        "url": "http://mp.weixin.qq.com/s?__biz=xyz&mid=2",
    }


def test_build_sticker_detail_output_strips_non_drawer_fields() -> None:
    """The CLI normalizer must NOT leak fields the webui drawer does not show."""
    raw = _make_sticker_detail_response()
    result = _build_sticker_detail_output(raw["data"])

    # sticker_info keeps only drawer-visible fields (not account_id, avatar, etc.)
    assert "account_id" not in result["sticker_info"]
    assert "account_avatar_url" not in result["sticker_info"]
    assert "author_name" not in result["sticker_info"]

    # pictures keep only drawer-visible fields (not theme_color_rgb, attached_product)
    assert "theme_color_rgb" not in result["pictures"][0]
    assert "attached_product" not in result["pictures"][0]

    # cover_images section not present at all (drawer doesn't show it)
    assert "cover_images" not in result

    # topics strip topic_url (drawer doesn't show it)
    assert "topic_url" not in result["topics"][0]

    # monetization simplified (no ad_mark_visible, footer_shops, etc.)
    assert "ad_mark_visible" not in result["monetization"]
    assert "footer_shops" not in result["monetization"]

    # comments strip avatar_url (drawer doesn't render avatars with URLs)
    assert "avatar_url" not in result["comments"]["items"][0]


def test_build_sticker_detail_output_omits_comments_error_when_absent() -> None:
    raw = _make_sticker_detail_response()
    result = _build_sticker_detail_output(raw["data"])
    assert "comments_error" not in result


def test_build_sticker_detail_output_omits_replies_when_empty() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["comments"]["items"][0]["replies"] = []
    result = _build_sticker_detail_output(raw["data"])
    assert "replies" not in result["comments"]["items"][0]


def test_build_sticker_detail_output_rejects_non_selected_scope() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["comments"]["scope"] = "all"
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "comments.scope" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_list_pictures() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["pictures"] = "bad"
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "pictures is not a list" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_bool_comment_enabled() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["engagement_metrics"]["comment_enabled"] = 1
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "comment_enabled" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_list_comment_items() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["comments"]["items"] = "bad"
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "comments.items is not a list" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_list_hashtags() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["hashtags"] = "bad"
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "hashtags is not a list" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_list_topics() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["topics"] = "bad"
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "topics is not a list" in exc_info.value.message


def test_build_sticker_detail_output_rejects_non_list_product_window_items() -> None:
    raw = _make_sticker_detail_response()
    raw["data"]["monetization"]["product_window_items"] = "bad"
    with pytest.raises(WxflywheelError) as exc_info:
        _build_sticker_detail_output(raw["data"])
    assert "product_window_items is not a list" in exc_info.value.message


def test_normalize_sticker_comments_rejects_non_list_replies() -> None:
    """When a comment's replies field is a non-list truthy value, the normalizer
    should raise because only list or empty-list are valid."""
    raw_comments: dict[str, object] = {
        "scope": "selected",
        "returned_count": 1,
        "total_selected_count": 1,
        "items": [
            {
                "nick_name": "test",
                "content": "hi",
                "like_count": 0,
                "posted_at_timestamp": 1,
                "ip_location": "",
                "is_top": False,
                "is_author_reply": False,
                "replies": "bad",
            }
        ],
    }
    # replies="bad" is truthy but not a list — the isinstance check passes
    # because "bad" is truthy, but the for-loop on a string would produce chars.
    # However our code checks `isinstance(raw_replies, list)` first.
    result = _normalize_sticker_comments(raw_comments)
    # string "bad" fails isinstance(list) so replies key is omitted
    assert "replies" not in result["items"][0]


VIDEO_DETAIL_DOWNLOAD_INSTRUCTIONS_EXPECTED = (
    "请下载并解密这个视频：\n\npip install wxipad-video\n\n"
    "from wxipad_video import decrypt_video\n"
    'open("保存路径/文件名.mp4", "wb").write(decrypt_video("'
    "http://wxapp.tc.qq.com/251/20302/stodownload?encfilekey=Cvvj5Ix3eew"
    "K0tHtibORqcsqchXNh0Gf3sJcaYqC2rQCNNfd9GTaia8Ria41MsrKvuiaGrZ2c14"
    "49BXzOIkwNibiaxUpzGkZ0lUFVNovYDEsplbwqUJ6TaExImqdcjSARntJt8&bizid=10"
    "23&dotrans=0&hy=SH&idx=1&m=&uzid=7a1ac&token=2lt8WBSnjTkuS1aicl08Qhts"
    "tKs6M9qvl8mJJPNzqIp8gP0JJ35XY3zMsd1xPQSs8MQib1KtL9c2Z5fgliakXwkvS2MC"
    "Un3ybR6lD8bWDU9svgRa1CYEcEqqA6Zewia5vjTZN323ViaiaBgNB19LHhUhhMsS2HOe"
    "icV8puyWXkOmK207ibHEXqlvuU82wOTInR9IHbKhyRpdiaql0VxXSud2KKZibOicsrHn1"
    "LGPVgLhRQ3Qia8xrwk&basedata=CAMSBnhXVDExMiJmCgoKBnhXVDExMhABCgoKBnhXV"
    "DEyMxAACgoKBnhXVDEyOBAACgoKBnhXVDExMxAACgoKBnhXVDEyNxAACgoKBnhXVDEyNh"
    "AACgoKBnhXVDExMRAACgcKA3hBMBAACgcKA3hBMhAA&sign=Zp5mRVlAUL18hzYu0s_v92"
    "AJHSB-Tis_zC9Ehvh3K5Ufj7fqlR3bugqKuHONpxf2vWLseEQ1dIWsae60OHqa3w&extg="
    "10f4500&svrbypass=AAuL%2FQsFAAABAAAAAABeglAVTiFF3iaoJFPfaRAAAADnaHZTnGbF"
    "fAj9RgZXfw6Vx1vWqXjhhsgJ8DTzrFHNAzXcMGhxxbVZpU8cX0W3wYboWzYU0tdzS4c%"
    "3D&svrnonce=1776243492\", 1027315950))"
)


class TestSearchVideoDetailCommand:
    def test_video_detail_happy_path_full(self, mock_resp: MockRespFactory) -> None:
        payload = _load_video_detail_payload()
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 0
        payload_output = json.loads(result.output)
        assert payload_output["code"] == 200
        data = payload_output["data"]
        video = data["video"]
        author = data["author"]
        metrics = data["metrics"]
        media = data["media"]
        comments = data["comments"]

        assert video["video_id"] == "14900142492464842777"
        assert video["export_id"] == "export/UzFfBgAAxM2jOE5geCaGjczT4DCKTrwkSjrNGQuzWBKAZY9NIQ"
        assert video["hash_doc_id"] == "160748305415154983"
        assert (
            video["title"]
            == "今天，阿里发布旗下首款AI开发工具Meoo（秒悟），该工具内置阿里云数据库、"
            "存储等核心产品服务，用户无需任何编程基础，只需用自然语言描述想法，"
            "Meoo最快1分钟就能自动生成前端后端完整的网站、H5页面，并在阿里云上"
            "一键部署上线。"
        )
        assert video["cover_url"].startswith("https://wxapp.tc.qq.com/251/20304/stodownload?")
        assert video["width"] == 1080
        assert video["height"] == 1920
        assert video["duration_seconds"] == 45
        assert video["published_at_ts"] == 1776235400

        assert author["nickname"] == "阿里云"
        assert (
            author["head_url"]
            == "https://wx.qlogo.cn/finderhead/ver_1/b2ZESsr6mXyoHwpiamRodxicZH3Z0FMZhG6mMHO7d3Y1ESHCiaNKicIia7Yqm5TBeI7wcdKjhUd1zzWK6Mznv6zny5yWyzyLFVJ0PPIiaiaHAywfB02IVDS64Qfs5KgDdDHZUsZ/0"
        )
        assert (
            author["username"]
            == "v2_060000231003b20faec8c5e08e1bc5d3cd03ed37b0771dc2c3"
            "c94831e8e4a5f84c486cafc23d@finder"
        )
        assert author["signature"] == "计算，为了无法计算的价值"

        assert metrics["like_count"] == 288
        assert metrics["comment_count"] == 7
        assert metrics["forward_count"] == 360
        assert metrics["friend_like_count"] == 0
        assert metrics["thumb_count"] is None

        assert media["full_video_url"].startswith("http://wxapp.tc.qq.com/251/20302/stodownload?")
        assert media["decode_key"] == "1027315950"

        assert data["agent_download_instructions"] == VIDEO_DETAIL_DOWNLOAD_INSTRUCTIONS_EXPECTED

        assert comments["total_count"] == 7
        assert comments["returned_count"] == 8
        assert len(comments["items"]) == 8
        first = comments["items"][0]
        assert first["nickname"] == "Zero～1"
        assert "加油啊" in first["content"]
        assert first["reply_nickname"] is None
        assert first["replies"] == []

    def test_video_detail_missing_video_info_returns_empty_sections(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"].pop("videoInfo")
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 0
        data = json.loads(result.output)["data"]
        assert data["video"] == {
            "video_id": "",
            "export_id": "export/UzFfBgAAxM2jOE5geCaGjczT4DCKTrwkSjrNGQuzWBKAZY9NIQ",
            "hash_doc_id": "160748305415154983",
            "title": "",
            "cover_url": "",
            "width": 0,
            "height": 0,
            "duration_seconds": 0,
            "published_at_ts": 0,
        }
        assert data["author"] == {
            "nickname": "",
            "head_url": "",
            "username": "",
            "signature": "",
        }
        assert data["metrics"] == {
            "like_count": 0,
            "comment_count": 0,
            "forward_count": 0,
            "friend_like_count": 0,
            "thumb_count": None,
        }
        assert data["media"] == {
            "full_video_url": "",
            "decode_key": "0",
        }
        assert "agent_download_instructions" not in data
        assert data["comments"]["total_count"] == 7
        assert len(data["comments"]["items"]) == 8

    def test_video_detail_missing_full_video_url_omits_instructions(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["videoInfo"]["media"][0]["fullVideoUrl"] = ""
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 0
        data = json.loads(result.output)["data"]
        assert data["media"]["full_video_url"] == ""
        assert "agent_download_instructions" not in data

    def test_video_detail_full_video_url_present_emits_instructions(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["videoInfo"]["media"][0]["fullVideoUrl"] = "https://example.com/full.mp4"
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        data = json.loads(result.output)["data"]
        assert data["media"]["full_video_url"] == "https://example.com/full.mp4"
        assert "agent_download_instructions" in data
        assert data["agent_download_instructions"] == (
            "请下载并解密这个视频：\n\npip install wxipad-video\n\n"
            "from wxipad_video import decrypt_video\n"
            'open("保存路径/文件名.mp4", "wb").write('
            'decrypt_video("https://example.com/full.mp4", 1027315950))'
        )

    def test_video_detail_download_instructions_byte_exact(self) -> None:
        assert (
            _build_video_download_instructions(
                full_video_url="http://wxapp.tc.qq.com/251/20302/stodownload?encfilekey=Cvvj5Ix3eewK0tHtibORqcsqchXNh0Gf3sJcaYqC2rQCNNfd9GTaia8Ria41MsrKvuiaGrZ2c1449BXzOIkwNibiaxUpzGkZ0lUFVNovYDEsplbwqUJ6TaExImqdcjSARntJt8&bizid=1023&dotrans=0&hy=SH&idx=1&m=&uzid=7a1ac&token=2lt8WBSnjTkuS1aicl08QhtstKs6M9qvl8mJJPNzqIp8gP0JJ35XY3zMsd1xPQSs8MQib1KtL9c2Z5fgliakXwkvS2MCUn3ybR6lD8bWDU9svgRa1CYEcEqqA6Zewia5vjTZN323ViaiaBgNB19LHhUhhMsS2HOeicV8puyWXkOmK207ibHEXqlvuU82wOTInR9IHbKhyRpdiaql0VxXSud2KKZibOicsrHn1LGPVgLhRQ3Qia8xrwk&basedata=CAMSBnhXVDExMiJmCgoKBnhXVDExMhABCgoKBnhXVDEyMxAACgoKBnhXVDEyOBAACgoKBnhXVDExMxAACgoKBnhXVDEyNxAACgoKBnhXVDEyNhAACgoKBnhXVDExMRAACgcKA3hBMBAACgcKA3hBMhAA&sign=Zp5mRVlAUL18hzYu0s_v92AJHSB-Tis_zC9Ehvh3K5Ufj7fqlR3bugqKuHONpxf2vWLseEQ1dIWsae60OHqa3w&extg=10f4500&svrbypass=AAuL%2FQsFAAABAAAAAABeglAVTiFF3iaoJFPfaRAAAADnaHZTnGbFfAj9RgZXfw6Vx1vWqXjhhsgJ8DTzrFHNAzXcMGhxxbVZpU8cX0W3wYboWzYU0tdzS4c%3D&svrnonce=1776243492",
                decode_key="1027315950",
            )
            == VIDEO_DETAIL_DOWNLOAD_INSTRUCTIONS_EXPECTED
        )

    def test_video_detail_title_uses_description_not_nickname(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["videoInfo"]["description"] = "真实标题"
        payload["data"]["videoInfo"]["nickname"] = "错误来源标题"
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 0
        assert json.loads(result.output)["data"]["video"]["title"] == "真实标题"

    def test_video_detail_title_strips_highlight_em_tags(self, mock_resp: MockRespFactory) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["videoInfo"]["description"] = '<em class="highlight">高亮</em>标题'
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert json.loads(result.output)["data"]["video"]["title"] == "高亮标题"

    def test_video_detail_thumb_count_is_always_null(self, mock_resp: MockRespFactory) -> None:
        payload = _load_video_detail_payload()
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 0
        assert json.loads(result.output)["data"]["metrics"]["thumb_count"] is None

    def test_video_detail_published_at_ts_is_int_not_string(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["videoInfo"]["createtime"] = 1776235400
        payload["data"]["videoInfo"]["likeCount"] = 12
        payload["data"]["videoInfo"]["commentCount"] = 34
        payload["data"]["videoInfo"]["forwardCount"] = 56
        payload["data"]["videoInfo"]["friendLikeCount"] = 78
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        data = json.loads(result.output)["data"]
        assert isinstance(data["video"]["published_at_ts"], int)
        assert isinstance(data["metrics"]["like_count"], int)
        assert isinstance(data["metrics"]["comment_count"], int)
        assert isinstance(data["metrics"]["forward_count"], int)
        assert isinstance(data["metrics"]["friend_like_count"], int)

    def test_video_detail_no_published_at_text_field(self, mock_resp: MockRespFactory) -> None:
        with patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp(_load_video_detail_payload()),
        ):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        video = json.loads(result.output)["data"]["video"]
        assert "published_at_text" not in video

    def test_video_detail_comments_happy_flat(self, mock_resp: MockRespFactory) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["comments"] = [
            {"nickname": "a", "content": "1", "headUrl": "u", "createtime": 1, "likeCount": 1},
            {"nickname": "b", "content": "2", "headUrl": "u", "createtime": 2, "likeCount": 2},
        ]
        payload["data"]["commentCount"] = 2
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 0
        comments = json.loads(result.output)["data"]["comments"]
        assert comments["total_count"] == 2
        assert comments["returned_count"] == 2
        assert len(comments["items"]) == 2
        for item in comments["items"]:
            assert item["replies"] == []
            assert set(item.keys()) == {
                "nickname",
                "content",
                "head_url",
                "like_count",
                "published_at_ts",
                "published_at_text",
                "reply_nickname",
                "replies",
            }

    def test_video_detail_comments_nested_replies_recursive(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["comments"] = [
            {
                "nickname": "root",
                "content": "root",
                "headUrl": "https://wx.qlogo.cn/root",
                "createtime": 1,
                "likeCount": 1,
                "replies": [
                    {
                        "nickname": "child",
                        "content": "child",
                        "headUrl": "https://wx.qlogo.cn/child",
                        "createtime": 2,
                        "likeCount": 2,
                        "replyNickname": "root",
                        "replies": [
                            {
                                "nickname": "grand",
                                "content": "grand",
                                "headUrl": "https://wx.qlogo.cn/grand",
                                "createtime": 3,
                                "likeCount": 3,
                                "replyNickname": "child",
                            }
                        ],
                    }
                ],
            }
        ]
        payload["data"]["commentCount"] = 1
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 0
        item = json.loads(result.output)["data"]["comments"]["items"][0]
        assert item["nickname"] == "root"
        assert item["reply_nickname"] is None
        assert item["replies"][0]["nickname"] == "child"
        assert item["replies"][0]["reply_nickname"] == "root"
        assert item["replies"][0]["replies"][0]["reply_nickname"] == "child"

    def test_video_detail_comments_count_mismatch_exposed(self, mock_resp: MockRespFactory) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["commentCount"] = 2
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        comments = json.loads(result.output)["data"]["comments"]
        assert comments["total_count"] == 2
        assert comments["returned_count"] == 8

    def test_video_detail_comment_published_at_text_format(
        self, mock_resp: MockRespFactory
    ) -> None:
        # Format-level assertion: both the CLI implementation and this test
        # call datetime.fromtimestamp(ts).strftime("%Y/%m/%d %H:%M"), so they
        # follow whatever local timezone the test runner uses (macOS UTC+8
        # → "2026/04/15 15:21", GitHub Actions Ubuntu UTC → "2026/04/15 07:21"
        # — both correct). The regex guards the strftime format string itself
        # ("%Y/%m/%d %H:%M") so a typo like "%H:%M:%S" or "%Y-%m-%d" would fail.
        payload = _load_video_detail_payload()
        payload["data"]["comments"] = [
            {
                "nickname": "a",
                "content": "1",
                "headUrl": "u",
                "createtime": 1776237708,
                "likeCount": 1,
            }
        ]
        payload["data"]["commentCount"] = 1
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        comment = json.loads(result.output)["data"]["comments"]["items"][0]
        expected = datetime.fromtimestamp(1776237708).strftime("%Y/%m/%d %H:%M")
        assert comment["published_at_text"] == expected
        assert re.match(r"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$", comment["published_at_text"])

    def test_video_detail_comment_reply_nickname_null_on_root(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["comments"] = [
            {
                "nickname": "root",
                "content": "1",
                "headUrl": "u",
                "createtime": 1,
                "likeCount": 1,
            }
        ]
        payload["data"]["commentCount"] = 1
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        comment = json.loads(result.output)["data"]["comments"]["items"][0]
        assert comment["reply_nickname"] is None

    def test_video_detail_comment_reply_nickname_populated_on_child(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["comments"] = [
            {
                "nickname": "root",
                "content": "1",
                "headUrl": "u",
                "createtime": 1,
                "likeCount": 1,
                "replies": [
                    {
                        "nickname": "child",
                        "content": "2",
                        "headUrl": "u2",
                        "createtime": 2,
                        "likeCount": 2,
                        "replyNickname": "root",
                    }
                ],
            }
        ]
        payload["data"]["commentCount"] = 1
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        comment = json.loads(result.output)["data"]["comments"]["items"][0]
        assert comment["replies"][0]["reply_nickname"] == "root"

    def test_video_detail_comment_missing_content_allows_empty(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["comments"] = [
            {
                "nickname": "a",
                "content": "",
                "headUrl": "u",
                "createtime": 1,
                "likeCount": 1,
            }
        ]
        payload["data"]["commentCount"] = 1
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        comment = json.loads(result.output)["data"]["comments"]["items"][0]
        assert comment["content"] == ""

    def test_video_detail_comment_invalid_likecount_raises(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["comments"] = [
            {
                "nickname": "a",
                "content": "bad",
                "headUrl": "u",
                "createtime": 1,
                "likeCount": "bad",
            }
        ]
        payload["data"]["commentCount"] = 1
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 1
        err = json.loads(result.stderr)
        assert "likeCount" in err["message"]

    def test_video_detail_media_decode_key_is_string(self, mock_resp: MockRespFactory) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["videoInfo"]["media"][0]["decodeKey"] = 1027315950
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 0
        assert isinstance(json.loads(result.output)["data"]["media"]["decode_key"], str)

    def test_video_detail_cover_url_from_full_thumb_url(self, mock_resp: MockRespFactory) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["videoInfo"]["media"][0]["fullThumbUrl"] = "https://example.com/cover.jpg"
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert (
            json.loads(result.output)["data"]["video"]["cover_url"]
            == "https://example.com/cover.jpg"
        )

    def test_video_detail_click_invocation_both_flags_required(self) -> None:
        result = CliRunner().invoke(
            cli, ["search", "video-detail", "--export-id", "export-1"], env=ENV
        )
        assert result.exit_code == 2
        assert "hash-doc-id" in result.output

    def test_video_detail_click_invocation_hash_doc_id_required(self) -> None:
        result = CliRunner().invoke(
            cli, ["search", "video-detail", "--hash-doc-id", "hash-1"], env=ENV
        )
        assert result.exit_code == 2
        assert "export-id" in result.output

    def test_video_detail_click_invocation_success(self, mock_resp: MockRespFactory) -> None:
        payload = _load_video_detail_payload()
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.get.return_value = payload
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 0
        assert json.loads(result.output)["code"] == 200
        assert mock_client.return_value.get.call_count == 1

    def test_video_detail_client_get_uses_correct_query_params(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        with patch("wxflywheel.commands.search.require_client") as mock_client:
            mock_client.return_value.get.return_value = payload
            CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        called_params = mock_client.return_value.get.call_args.kwargs
        assert called_params["exportId"] == "export-1"
        assert called_params["hashDocId"] == "hash-1"

    def test_video_detail_width_height_missing_defaults_to_zero(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        media = payload["data"]["videoInfo"]["media"][0]
        media.pop("width")
        media.pop("height")
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        video = json.loads(result.output)["data"]["video"]
        assert video["width"] == 0
        assert video["height"] == 0

    def test_build_video_detail_author_section_missing_contact_returns_empty_fields(
        self,
    ) -> None:
        with pytest.raises(WxflywheelError):
            _build_video_detail_author_section({"contact": "bad"})

    def test_build_video_detail_media_section_non_list_media_returns_empty_tuple(
        self,
    ) -> None:
        media_section, full_video_url, decode_key = _build_video_detail_media_section(
            {"media": "bad"}
        )
        assert media_section == {"full_video_url": "", "decode_key": "0"}
        assert full_video_url == ""
        assert decode_key == "0"

    def test_video_detail_data_not_dict_raises(self) -> None:
        with pytest.raises(WxflywheelError):
            _build_video_detail_output(None)
        with pytest.raises(WxflywheelError):
            _build_video_detail_output([])

    def test_video_detail_comments_not_list_raises(self, mock_resp: MockRespFactory) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["comments"] = {"bad": 1}
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 1
        err = json.loads(result.stderr)
        assert "comments field is not a list" in err["message"]

    def test_video_detail_comments_section_rejects_non_list_replies(
        self,
    ) -> None:
        with pytest.raises(WxflywheelError) as exc_info:
            _build_video_detail_comments_section(
                [
                    {
                        "nickname": "a",
                        "content": "1",
                        "headUrl": "u",
                        "createtime": 1,
                        "replies": "bad",
                    }
                ],
                1,
            )
        assert "replies is not a list" in exc_info.value.message

    def test_video_detail_comments_none_graceful(
        self, mock_resp: MockRespFactory
    ) -> None:
        # Real-world: backend returns `data.comments = null` (JSON null) when the
        # video has zero comments or comments are disabled. This must be handled
        # gracefully as empty items, not as a protocol error. Regression guard
        # for a live-probe finding on 2026-04-15 after 0.11.0 was cut.
        payload = _load_video_detail_payload()
        payload["data"]["comments"] = None
        payload["data"]["commentCount"] = 0
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 0
        body = json.loads(result.output)
        assert body["code"] == 200
        comments = body["data"]["comments"]
        assert comments["total_count"] == 0
        assert comments["returned_count"] == 0
        assert comments["items"] == []

    def test_video_detail_metrics_likecount_missing_raises(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["videoInfo"].pop("likeCount")
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert result.exit_code == 1
        err = json.loads(result.stderr)
        assert "VideoDetailV2 videoInfo.likeCount" in err["message"]

    def test_video_detail_comment_published_at_text_ts_zero_returns_empty(
        self, mock_resp: MockRespFactory
    ) -> None:
        payload = _load_video_detail_payload()
        payload["data"]["comments"] = [
            {
                "nickname": "zero",
                "content": "0",
                "headUrl": "u",
                "createtime": 0,
                "likeCount": 0,
            }
        ]
        payload["data"]["commentCount"] = 1
        with patch("wxflywheel.client.requests.request", return_value=mock_resp(payload)):
            result = CliRunner().invoke(
                cli,
                ["search", "video-detail", "--export-id", "export-1", "--hash-doc-id", "hash-1"],
                env=ENV,
            )
        assert json.loads(result.output)["data"]["comments"]["items"][0]["published_at_text"] == ""
