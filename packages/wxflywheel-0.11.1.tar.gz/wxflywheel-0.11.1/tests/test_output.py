import json
import time
from io import StringIO
from typing import Any
from unittest.mock import call, patch

import pytest
import requests
from click.testing import CliRunner

from tests.conftest import MockRespFactory
from wxflywheel.cli import cli

ENV = {"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://localhost:8011"}


class RecordingStream(StringIO):
    def close(self) -> None:
        self.flush()


def test_error_output_stays_clean_json_when_not_running_in_a_terminal(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = CliRunner()
    fake_now = {"value": 0.0}

    def _fake_monotonic() -> float:
        return fake_now["value"]

    def _fake_sleep(seconds: float) -> None:
        fake_now["value"] += seconds

    def _fake_request(method: str, url: str, **kwargs: object) -> Any:
        if "/api/wxindex/" in url:
            return mock_resp({"code": 300, "data": None, "message": "获取凭证失败"})
        if url.endswith("/v1/login/GetLoginStatus"):
            return mock_resp({"code": 200, "data": {"loginState": 3}, "message": ""})
        raise AssertionError(f"unexpected url: {url}")

    monkeypatch.setattr(time, "monotonic", _fake_monotonic)
    monkeypatch.setattr(time, "sleep", _fake_sleep)
    with patch("wxflywheel.client.requests.request", side_effect=_fake_request):
        result = runner.invoke(cli, ["wxindex", "query", "--keyword", "社群运营"], env=ENV)

    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == 300
    assert "线路在恢复" not in result.stderr


def test_progress_notice_is_visible_in_terminal_sessions(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = CliRunner()
    progress_stream = RecordingStream()

    monkeypatch.setattr(time, "sleep", lambda _: None)
    with (
        patch("wxflywheel.output.should_emit_progress_message", return_value=True),
        patch("wxflywheel.output._open_progress_stream", return_value=progress_stream),
        patch(
            "wxflywheel.client.requests.request",
            side_effect=[
                requests.exceptions.Timeout("timed out"),
                mock_resp({"code": 200, "data": {"loginState": 1}, "message": ""}),
                mock_resp(
                    {
                        "code": 200,
                        "data": {"loginState": 1, "wxId": "wxid_test"},
                        "message": "",
                    }
                ),
            ],
        ),
    ):
        result = runner.invoke(cli, ["login", "status"], env=ENV)

    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["code"] == 200
    assert "线路在恢复" in progress_stream.getvalue()
    assert result.stderr == ""


def test_terminal_progress_notice_does_not_pollute_error_json(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = CliRunner()
    progress_stream = RecordingStream()
    fake_now = {"value": 0.0}

    def _fake_monotonic() -> float:
        return fake_now["value"]

    def _fake_sleep(seconds: float) -> None:
        fake_now["value"] += seconds

    def _fake_request(method: str, url: str, **kwargs: object) -> Any:
        if "/api/wxindex/" in url:
            return mock_resp({"code": 300, "data": None, "message": "获取凭证失败"})
        if url.endswith("/v1/login/GetLoginStatus"):
            return mock_resp({"code": 200, "data": {"loginState": 3}, "message": ""})
        raise AssertionError(f"unexpected url: {url}")

    with (
        patch("wxflywheel.output.should_emit_progress_message", return_value=True),
        patch("wxflywheel.output._open_progress_stream", return_value=progress_stream),
        patch("wxflywheel.client.requests.request", side_effect=_fake_request),
        patch("wxflywheel.client.time.monotonic", side_effect=_fake_monotonic),
        patch("wxflywheel.client.time.sleep", side_effect=_fake_sleep),
        patch("wxflywheel.request_recovery.time.monotonic", side_effect=_fake_monotonic),
    ):
        result = runner.invoke(cli, ["wxindex", "query", "--keyword", "社群运营"], env=ENV)

    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == 300
    assert "线路在恢复" in progress_stream.getvalue()
    assert "线路在恢复" not in result.stderr


def test_emit_progress_message_silently_skips_when_tty_stream_is_unavailable() -> None:
    with (
        patch("wxflywheel.output.should_emit_progress_message", return_value=True),
        patch(
            "wxflywheel.output.open",
            side_effect=[OSError("no tty"), OSError("no console")],
        ) as mock_open,
    ):
        from wxflywheel.output import emit_progress_message

        emit_progress_message("线路在恢复")

    assert mock_open.call_args_list == [
        call("/dev/tty", "w", encoding="utf-8", buffering=1),
        call("CONOUT$", "w", encoding="utf-8", buffering=1),
    ]
