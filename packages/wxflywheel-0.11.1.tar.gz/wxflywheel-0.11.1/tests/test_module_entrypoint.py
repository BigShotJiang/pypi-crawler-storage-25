from __future__ import annotations

import importlib
import runpy
import sys
from unittest.mock import patch

import pytest


def test_python_module_import_does_not_exit() -> None:
    module = importlib.import_module("wxflywheel.__main__")
    assert callable(module.main)


def test_python_module_entrypoint_exits_with_main_return_code() -> None:
    sys.modules.pop("wxflywheel.__main__", None)
    with (
        patch("sys.argv", ["python -m wxflywheel"]),
        patch("wxflywheel.cli.main", return_value=0) as mock_main,
        pytest.raises(SystemExit) as exc_info,
    ):
        runpy.run_module("wxflywheel.__main__", run_name="__main__")
    assert exc_info.value.code == 0
    mock_main.assert_called_once_with()


def test_python_module_entrypoint_exits_with_nonzero_main_return_code() -> None:
    sys.modules.pop("wxflywheel.__main__", None)
    with (
        patch("sys.argv", ["python -m wxflywheel"]),
        patch("wxflywheel.cli.main", return_value=2) as mock_main,
        pytest.raises(SystemExit) as exc_info,
    ):
        runpy.run_module("wxflywheel.__main__", run_name="__main__")
    assert exc_info.value.code == 2
    mock_main.assert_called_once_with()
