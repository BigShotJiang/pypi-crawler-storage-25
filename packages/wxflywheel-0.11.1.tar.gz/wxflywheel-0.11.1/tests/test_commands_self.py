"""Tests for the ``wxflywheel self`` command group."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from wxflywheel.cli import cli
from wxflywheel.commands import self_cmd


@pytest.fixture
def _self_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Point the cache dir at tmp_path so update.lock goes to a writable place."""
    cache_root = tmp_path / "cache"
    monkeypatch.setenv("WXFLYWHEEL_CACHE_DIR", str(cache_root))
    return cache_root


def _mock_pip_result(
    returncode: int = 0, stdout: str = "", stderr: str = ""
) -> MagicMock:
    m = MagicMock()
    m.returncode = returncode
    m.stdout = stdout
    m.stderr = stderr
    return m


def test_self_update_success(_self_env: Path) -> None:
    with patch("subprocess.run") as mock_run:
        mock_run.side_effect = [
            _mock_pip_result(0, "Successfully installed wxflywheel-99.0.0", ""),
            _mock_pip_result(0, "Name: wxflywheel\nVersion: 99.0.0\n", ""),
        ]
        runner = CliRunner()
        result = runner.invoke(cli, ["self", "update"])
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["code"] == 200
    data = payload["data"]
    assert data["success"] is True
    assert data["after_version"] == "99.0.0"
    assert "hint" in data
    assert "NEXT invocation" in data["hint"] or "next" in data["hint"].lower()


def test_self_update_pip_failure_returns_error(_self_env: Path) -> None:
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = _mock_pip_result(
            1, "", "ERROR: Could not find wxflywheel"
        )
        runner = CliRunner()
        result = runner.invoke(cli, ["self", "update"])
    assert result.exit_code == 1
    err = json.loads(result.stderr)
    assert err["code"] == -7
    assert "returncode 1" in err["message"]
    assert err["data"]["stderr_tail"] == "ERROR: Could not find wxflywheel"


def test_self_update_pip_timeout_returns_error(_self_env: Path) -> None:
    with patch("subprocess.run") as mock_run:
        mock_run.side_effect = subprocess.TimeoutExpired(
            cmd=["pip", "install"], timeout=180, output="partial", stderr="stderr part"
        )
        runner = CliRunner()
        result = runner.invoke(cli, ["self", "update"])
    assert result.exit_code == 1
    err = json.loads(result.stderr)
    assert err["code"] == -5
    assert "timed out" in err["message"]
    assert err["data"]["stderr_tail"] == "stderr part"


def test_self_update_pip_oserror_returns_error(_self_env: Path) -> None:
    with patch("subprocess.run") as mock_run:
        mock_run.side_effect = OSError("pip not found")
        runner = CliRunner()
        result = runner.invoke(cli, ["self", "update"])
    assert result.exit_code == 1
    err = json.loads(result.stderr)
    assert err["code"] == -6
    assert "pip subprocess" in err["message"]


def test_self_update_lock_timeout(_self_env: Path) -> None:
    from filelock import Timeout as FileLockTimeout

    class _FakeLockThatTimesOut:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        def __enter__(self) -> Any:
            raise FileLockTimeout("fake.lock")

        def __exit__(self, *args: Any) -> None:
            pass

    with patch("wxflywheel.commands.self_cmd.FileLock", _FakeLockThatTimesOut):
        runner = CliRunner()
        result = runner.invoke(cli, ["self", "update"])
    assert result.exit_code == 1
    err = json.loads(result.stderr)
    assert err["code"] == -4
    assert "in progress" in err["message"]


def test_self_update_cache_dir_creation_failure(
    _self_env: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _raise(*a: Any, **kw: Any) -> None:
        raise OSError("read only filesystem")

    monkeypatch.setattr(Path, "mkdir", _raise)
    runner = CliRunner()
    result = runner.invoke(cli, ["self", "update"])
    assert result.exit_code == 1
    err = json.loads(result.stderr)
    assert err["code"] == -3
    assert "cache directory" in err["message"]


def test_self_update_query_installed_version_on_pip_show_failure(
    _self_env: Path,
) -> None:
    with patch("subprocess.run") as mock_run:
        mock_run.side_effect = [
            _mock_pip_result(0, "Successfully installed", ""),
            _mock_pip_result(1, "", "pip show failed"),
        ]
        runner = CliRunner()
        result = runner.invoke(cli, ["self", "update"])
    assert result.exit_code == 0
    data = json.loads(result.output)["data"]
    assert data["after_version"] == "unknown"


def test_self_update_query_installed_version_pip_show_oserror(
    _self_env: Path,
) -> None:
    call_count = {"n": 0}

    def _fake_run(*args: Any, **kwargs: Any) -> MagicMock:
        call_count["n"] += 1
        if call_count["n"] == 1:
            return _mock_pip_result(0, "ok", "")
        raise OSError("no pip")

    with patch("subprocess.run", side_effect=_fake_run):
        runner = CliRunner()
        result = runner.invoke(cli, ["self", "update"])
    assert result.exit_code == 0
    data = json.loads(result.output)["data"]
    assert data["after_version"] == "unknown"


def test_self_update_tail_truncates_long_output(_self_env: Path) -> None:
    long_output = "x" * (self_cmd.MAX_OUTPUT_TAIL_CHARS + 500)
    with patch("subprocess.run") as mock_run:
        mock_run.side_effect = [
            _mock_pip_result(0, long_output, ""),
            _mock_pip_result(0, "Name: wxflywheel\nVersion: 99.0.0\n", ""),
        ]
        runner = CliRunner()
        result = runner.invoke(cli, ["self", "update"])
    data = json.loads(result.output)["data"]
    assert len(data["stdout_tail"]) == self_cmd.MAX_OUTPUT_TAIL_CHARS


def test_self_update_tail_handles_none_output(_self_env: Path) -> None:
    """Defensive: if pip somehow returns None for stdout/stderr, _tail returns ''"""
    assert self_cmd._tail(None) == ""
    assert self_cmd._tail("") == ""
    assert self_cmd._tail("short") == "short"


def test_query_installed_version_parses_pip_show_output() -> None:
    """Unit-test the private helper directly to cover pip show parsing."""
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = _mock_pip_result(
            0, "Name: wxflywheel\nVersion: 1.2.3\nLocation: /opt", ""
        )
        result = self_cmd._query_installed_version()
    assert result == "1.2.3"


def test_query_installed_version_returns_unknown_when_no_version_line() -> None:
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = _mock_pip_result(0, "Name: wxflywheel\n", "")
        result = self_cmd._query_installed_version()
    assert result == "unknown"


def test_query_installed_version_timeout_returns_unknown() -> None:
    with patch("subprocess.run") as mock_run:
        mock_run.side_effect = subprocess.TimeoutExpired(cmd=["pip"], timeout=10)
        result = self_cmd._query_installed_version()
    assert result == "unknown"


def test_self_help_mentions_next_invocation() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["self", "update", "--help"])
    assert result.exit_code == 0
    # Help text should warn Agent that new version needs next invocation
    assert "NEXT invocation" in result.output or "next" in result.output.lower()
