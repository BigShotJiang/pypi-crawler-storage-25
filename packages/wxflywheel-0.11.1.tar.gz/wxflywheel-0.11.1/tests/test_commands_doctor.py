"""Tests for the ``wxflywheel doctor`` diagnostic command."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
import requests
from click.testing import CliRunner

from wxflywheel.cli import cli
from wxflywheel.commands import doctor as doctor_mod


@pytest.fixture
def _doctor_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Isolate cache dir for doctor tests."""
    monkeypatch.setenv("WXFLYWHEEL_CACHE_DIR", str(tmp_path / "doctor_cache"))


def _mock_http(status: int = 200) -> MagicMock:
    m = MagicMock()
    m.status_code = status
    return m


def test_doctor_all_ok(_doctor_env: None, monkeypatch: pytest.MonkeyPatch) -> None:
    """Happy path: everything works, verdict is 'all systems operational'."""
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_http(200))
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["code"] == 200
    data = payload["data"]
    assert data["verdict"] == doctor_mod.VERDICT_ALL_OK
    assert len(data["checks"]) == 6
    check_names = [c["name"] for c in data["checks"]]
    assert check_names == [
        "python_version",
        "platform",
        "dependencies",
        "cache_directory",
        "network",
        "subprocess",
    ]
    # All checks should be ok in this happy-path fixture
    for check in data["checks"]:
        assert check["status"] in (doctor_mod.STATUS_OK,)
    assert "environment" in data
    assert "env_vars" in data
    assert "wxflywheel_version" in data


def test_doctor_reports_warn_on_network_failure(
    _doctor_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _raise(*a: Any, **kw: Any) -> None:
        raise requests.ConnectionError("no network")

    monkeypatch.setattr(requests, "get", _raise)
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    assert result.exit_code == 0  # doctor itself succeeds even if checks warn
    data = json.loads(result.output)["data"]
    network_check = next(c for c in data["checks"] if c["name"] == "network")
    assert network_check["status"] == doctor_mod.STATUS_WARN
    assert data["verdict"] == doctor_mod.VERDICT_WARN


def test_doctor_reports_warn_on_readonly_cache(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("WXFLYWHEEL_CACHE_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_http(200))

    original_mkdir = Path.mkdir

    def _selective_mkdir(self: Path, *args: Any, **kwargs: Any) -> None:
        if "cache" in str(self):
            raise OSError("read-only")
        original_mkdir(self, *args, **kwargs)

    monkeypatch.setattr(Path, "mkdir", _selective_mkdir)
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    assert result.exit_code == 0
    data = json.loads(result.output)["data"]
    cache_check = next(c for c in data["checks"] if c["name"] == "cache_directory")
    assert cache_check["status"] == doctor_mod.STATUS_WARN
    assert data["verdict"] == doctor_mod.VERDICT_WARN


def test_doctor_reports_fail_on_missing_dependency(
    _doctor_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    import importlib.metadata

    real_version = importlib.metadata.version

    def _fake_version(name: str) -> str:
        if name == "click":
            raise importlib.metadata.PackageNotFoundError(name)
        return real_version(name)

    monkeypatch.setattr(importlib.metadata, "version", _fake_version)
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_http(200))
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    assert result.exit_code == 0
    data = json.loads(result.output)["data"]
    deps_check = next(c for c in data["checks"] if c["name"] == "dependencies")
    assert deps_check["status"] == doctor_mod.STATUS_FAIL
    assert deps_check["details"]["click"]["installed"] is False
    assert data["verdict"] == doctor_mod.VERDICT_FAIL


def test_doctor_reports_fail_on_old_python(
    _doctor_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Simulate running on Python 3.9 (below 3.10 minimum).

    sys.version_info is not directly instantiable (its type is a special
    C-defined struct_sequence), so we patch with a plain tuple — the doctor
    code uses ``sys.version_info[:3]`` which works identically on tuples."""
    monkeypatch.setattr("sys.version_info", (3, 9, 0, "final", 0))
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_http(200))
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    assert result.exit_code == 0
    data = json.loads(result.output)["data"]
    py_check = next(c for c in data["checks"] if c["name"] == "python_version")
    assert py_check["status"] == doctor_mod.STATUS_FAIL
    assert py_check["details"]["satisfies_minimum"] is False
    assert data["verdict"] == doctor_mod.VERDICT_FAIL


def test_doctor_reports_fail_on_subprocess_unavailable(
    _doctor_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _raise(*a: Any, **kw: Any) -> None:
        raise OSError("fork denied (sandboxed)")

    monkeypatch.setattr(subprocess, "run", _raise)
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_http(200))
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    assert result.exit_code == 0
    data = json.loads(result.output)["data"]
    sub_check = next(c for c in data["checks"] if c["name"] == "subprocess")
    assert sub_check["status"] == doctor_mod.STATUS_FAIL
    assert sub_check["details"]["can_spawn"] is False
    assert data["verdict"] == doctor_mod.VERDICT_FAIL


def test_doctor_reports_fail_on_subprocess_nonzero_exit(
    _doctor_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _fake_run(*a: Any, **kw: Any) -> MagicMock:
        m = MagicMock()
        m.returncode = 1
        return m

    monkeypatch.setattr(subprocess, "run", _fake_run)
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_http(200))
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    data = json.loads(result.output)["data"]
    sub_check = next(c for c in data["checks"] if c["name"] == "subprocess")
    assert sub_check["status"] == doctor_mod.STATUS_FAIL


def test_doctor_reports_warn_on_subprocess_timeout(
    _doctor_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    def _timeout(*a: Any, **kw: Any) -> None:
        raise subprocess.TimeoutExpired(cmd=["python"], timeout=10)

    monkeypatch.setattr(subprocess, "run", _timeout)
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_http(200))
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    data = json.loads(result.output)["data"]
    sub_check = next(c for c in data["checks"] if c["name"] == "subprocess")
    # TimeoutExpired is caught in the same except block as OSError → FAIL
    assert sub_check["status"] == doctor_mod.STATUS_FAIL


def test_doctor_network_http_error_status_code(
    _doctor_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    """PyPI returns 503 (Service Unavailable) — should be treated as unreachable."""
    monkeypatch.setattr(requests, "get", lambda *a, **kw: _mock_http(503))
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor"])
    data = json.loads(result.output)["data"]
    network_check = next(c for c in data["checks"] if c["name"] == "network")
    assert network_check["status"] == doctor_mod.STATUS_WARN
    assert network_check["details"]["pypi"]["reachable"] is False
    assert network_check["details"]["pypi"]["status_code"] == 503


def test_doctor_platform_check_identifies_os(_doctor_env: None) -> None:
    with patch("requests.get", return_value=_mock_http(200)):
        runner = CliRunner()
        result = runner.invoke(cli, ["doctor"])
    data = json.loads(result.output)["data"]
    platform_check = next(c for c in data["checks"] if c["name"] == "platform")
    assert platform_check["status"] == doctor_mod.STATUS_OK
    # Exactly one of is_windows / is_macos / is_linux should be True on a real system
    flags = [
        platform_check["details"]["is_windows"],
        platform_check["details"]["is_macos"],
        platform_check["details"]["is_linux"],
    ]
    assert sum(flags) <= 1  # <=1 because the test could run on other OS too


def test_doctor_help_mentions_agent_first_invocation() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["doctor", "--help"])
    assert result.exit_code == 0
    assert "Agent" in result.output
    assert "first command" in result.output.lower() or "FIRST" in result.output


def test_aggregate_verdict_all_ok() -> None:
    checks = [{"status": "ok"}, {"status": "ok"}]
    assert doctor_mod._aggregate_verdict(checks) == doctor_mod.VERDICT_ALL_OK


def test_aggregate_verdict_warn_only() -> None:
    checks = [{"status": "ok"}, {"status": "warn"}]
    assert doctor_mod._aggregate_verdict(checks) == doctor_mod.VERDICT_WARN


def test_aggregate_verdict_fail_overrides_warn() -> None:
    checks = [{"status": "fail"}, {"status": "warn"}]
    assert doctor_mod._aggregate_verdict(checks) == doctor_mod.VERDICT_FAIL
