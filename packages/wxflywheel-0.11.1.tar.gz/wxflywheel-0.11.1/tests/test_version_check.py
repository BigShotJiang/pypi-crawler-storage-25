"""Tests for wxflywheel.version_check (pure unit tests, no network)."""

from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest
import requests

from wxflywheel import __version__, version_check


@pytest.fixture
def _isolated_cache(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Point the cache dir at a tmp_path and ensure no meta stub is active."""
    monkeypatch.setenv("WXFLYWHEEL_CACHE_DIR", str(tmp_path / "cache"))
    monkeypatch.delenv("WXFLYWHEEL_NO_META", raising=False)
    return tmp_path / "cache"


# ---------------------------------------------------------------------------
# cache_dir / cache_file
# ---------------------------------------------------------------------------


def test_cache_dir_respects_env_override(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("WXFLYWHEEL_CACHE_DIR", str(tmp_path))
    assert version_check.cache_dir() == tmp_path
    assert version_check.cache_file() == tmp_path / "version_check.json"


def test_cache_dir_defaults_to_home_cache(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("WXFLYWHEEL_CACHE_DIR", raising=False)
    result = version_check.cache_dir()
    assert result == Path.home() / ".cache" / "wxflywheel"


# ---------------------------------------------------------------------------
# load_cache / save_cache
# ---------------------------------------------------------------------------


def test_load_cache_returns_none_when_missing(_isolated_cache: Path) -> None:
    assert version_check.load_cache() is None


def test_load_cache_returns_dict_when_present(_isolated_cache: Path) -> None:
    _isolated_cache.mkdir(parents=True)
    cache_data = {"latest_version": "0.9.9", "checked_at_epoch": time.time()}
    (_isolated_cache / "version_check.json").write_text(json.dumps(cache_data))
    loaded = version_check.load_cache()
    assert loaded == cache_data


def test_load_cache_returns_none_on_corrupted_json(_isolated_cache: Path) -> None:
    _isolated_cache.mkdir(parents=True)
    (_isolated_cache / "version_check.json").write_text("{not json")
    assert version_check.load_cache() is None


def test_load_cache_returns_none_when_top_level_not_dict(_isolated_cache: Path) -> None:
    _isolated_cache.mkdir(parents=True)
    (_isolated_cache / "version_check.json").write_text("[1, 2, 3]")
    assert version_check.load_cache() is None


def test_load_cache_returns_none_on_os_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def _raise(*args: Any, **kwargs: Any) -> None:
        raise OSError("permission denied")

    monkeypatch.setattr(Path, "open", _raise)
    monkeypatch.setattr(Path, "exists", lambda self: True)
    assert version_check.load_cache() is None


def test_save_cache_creates_directory_and_writes_file(_isolated_cache: Path) -> None:
    assert version_check.save_cache({"foo": "bar"}) is True
    assert _isolated_cache.exists()
    data = json.loads((_isolated_cache / "version_check.json").read_text())
    assert data == {"foo": "bar"}


def test_save_cache_returns_false_on_os_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def _raise(*args: Any, **kwargs: Any) -> None:
        raise OSError("disk full")

    monkeypatch.setattr(Path, "mkdir", _raise)
    assert version_check.save_cache({"foo": "bar"}) is False


# ---------------------------------------------------------------------------
# is_cache_expired / compute_cache_age_seconds
# ---------------------------------------------------------------------------


def test_is_cache_expired_true_when_old() -> None:
    old_cache = {"checked_at_epoch": time.time() - 25 * 3600}
    assert version_check.is_cache_expired(old_cache) is True


def test_is_cache_expired_false_when_recent() -> None:
    fresh = {"checked_at_epoch": time.time() - 60}
    assert version_check.is_cache_expired(fresh) is False


def test_is_cache_expired_true_when_timestamp_missing() -> None:
    assert version_check.is_cache_expired({}) is True
    assert version_check.is_cache_expired({"checked_at_epoch": "not a number"}) is True


def test_compute_cache_age_seconds_returns_int() -> None:
    cache = {"checked_at_epoch": time.time() - 120}
    age = version_check.compute_cache_age_seconds(cache)
    assert age is not None
    assert 118 <= age <= 122


def test_compute_cache_age_seconds_returns_none_when_missing() -> None:
    assert version_check.compute_cache_age_seconds({}) is None
    assert version_check.compute_cache_age_seconds({"checked_at_epoch": "bad"}) is None


def test_compute_cache_age_seconds_clamps_to_zero_for_future_time() -> None:
    cache = {"checked_at_epoch": time.time() + 300}
    assert version_check.compute_cache_age_seconds(cache) == 0


# ---------------------------------------------------------------------------
# fetch_pypi_meta
# ---------------------------------------------------------------------------


def _mock_pypi_response(
    version: str,
    upload_time: str | None = None,
    description: str | None = "",
) -> MagicMock:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    release_files: list[dict[str, Any]] = []
    if upload_time is not None:
        release_files.append({"upload_time_iso_8601": upload_time})
    info: dict[str, Any] = {"version": version}
    if description is not None:
        info["description"] = description
    m.json.return_value = {
        "info": info,
        "releases": {version: release_files},
    }
    return m


def test_fetch_pypi_meta_success(monkeypatch: pytest.MonkeyPatch) -> None:
    resp = _mock_pypi_response("0.9.9", "2026-04-06T12:34:56Z", "# README\n\nbody")
    monkeypatch.setattr(requests, "get", lambda *a, **kw: resp)
    result = version_check.fetch_pypi_meta(timeout=1.0)
    assert result == ("0.9.9", "2026-04-06T12:34:56Z", "# README\n\nbody")


def test_fetch_pypi_meta_success_without_upload_time(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    resp = _mock_pypi_response("0.9.9", description="desc")
    monkeypatch.setattr(requests, "get", lambda *a, **kw: resp)
    result = version_check.fetch_pypi_meta(timeout=1.0)
    assert result == ("0.9.9", "", "desc")


def test_fetch_pypi_meta_description_missing_becomes_empty_string(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Covers the branch where PyPI response has no ``info.description`` key."""
    resp = _mock_pypi_response("0.9.9", "2026-04-06T00:00:00Z", description=None)
    monkeypatch.setattr(requests, "get", lambda *a, **kw: resp)
    result = version_check.fetch_pypi_meta(timeout=1.0)
    assert result == ("0.9.9", "2026-04-06T00:00:00Z", "")


def test_fetch_pypi_meta_description_non_string_becomes_empty_string(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Covers the ``isinstance(raw_description, str)`` False branch."""
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {
        "info": {"version": "1.0.0", "description": 12345},
        "releases": {"1.0.0": []},
    }
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    result = version_check.fetch_pypi_meta(timeout=1.0)
    assert result == ("1.0.0", "", "")


def test_fetch_pypi_meta_returns_none_on_request_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _raise(*a: Any, **kw: Any) -> None:
        raise requests.ConnectionError("no network")

    monkeypatch.setattr(requests, "get", _raise)
    assert version_check.fetch_pypi_meta(timeout=1.0) is None


def test_fetch_pypi_meta_returns_none_on_bad_json(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.side_effect = ValueError("bad json")
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    assert version_check.fetch_pypi_meta(timeout=1.0) is None


def test_fetch_pypi_meta_returns_none_when_top_level_not_dict(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = []
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    assert version_check.fetch_pypi_meta(timeout=1.0) is None


def test_fetch_pypi_meta_returns_none_when_info_missing_version(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {"info": {}, "releases": {}}
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    assert version_check.fetch_pypi_meta(timeout=1.0) is None


def test_fetch_pypi_meta_handles_non_dict_info(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {"info": "not a dict"}
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    assert version_check.fetch_pypi_meta(timeout=1.0) is None


def test_fetch_pypi_meta_handles_non_dict_releases(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Covers the `if isinstance(releases, dict)` False branch."""
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {"info": {"version": "1.0.0"}, "releases": "not a dict"}
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    result = version_check.fetch_pypi_meta(timeout=1.0)
    assert result == ("1.0.0", "", "")


def test_fetch_pypi_meta_handles_non_dict_first_file(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Covers the `if isinstance(first_file, dict)` False branch."""
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {
        "info": {"version": "1.0.0"},
        "releases": {"1.0.0": ["not a dict"]},
    }
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    result = version_check.fetch_pypi_meta(timeout=1.0)
    assert result == ("1.0.0", "", "")


def test_fetch_pypi_meta_handles_non_str_upload_time(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Covers the `if isinstance(raw_time, str)` False branch."""
    m = MagicMock()
    m.raise_for_status = MagicMock()
    m.json.return_value = {
        "info": {"version": "1.0.0"},
        "releases": {"1.0.0": [{"upload_time_iso_8601": None, "upload_time": 12345}]},
    }
    monkeypatch.setattr(requests, "get", lambda *a, **kw: m)
    result = version_check.fetch_pypi_meta(timeout=1.0)
    assert result == ("1.0.0", "", "")


# ---------------------------------------------------------------------------
# parse_breaking_from_description
#
# Pure local parser — no network required. Exercises every BREAKING marker
# form and boundary case against a synthetic Keep a Changelog block.
# ---------------------------------------------------------------------------


def test_parse_breaking_from_description_true_on_section_header() -> None:
    description = (
        "# Changelog\n\n"
        "## [0.9.0] - 2026-04-06\n\n"
        "### Breaking\n- something broke\n\n"
        "## [0.8.0] - 2026-04-05\n"
    )
    assert version_check.parse_breaking_from_description(description, "0.9.0") is True


def test_parse_breaking_from_description_true_on_phrase() -> None:
    description = (
        "## [0.9.0] - 2026-04-06\n\n"
        "### Changed\nThis introduces a BREAKING CHANGE in X.\n"
    )
    assert version_check.parse_breaking_from_description(description, "0.9.0") is True


def test_parse_breaking_from_description_true_on_prefix() -> None:
    description = "## [0.9.0] - 2026-04-06\n\n- BREAKING: removed old field\n"
    assert version_check.parse_breaking_from_description(description, "0.9.0") is True


def test_parse_breaking_from_description_false_when_no_marker() -> None:
    description = "## [0.9.0] - 2026-04-06\n\n### Added\n- new command\n"
    assert version_check.parse_breaking_from_description(description, "0.9.0") is False


def test_parse_breaking_from_description_ignores_other_version_sections() -> None:
    description = (
        "## [0.9.0] - 2026-04-06\n\n### Added\n- new command\n\n"
        "## [0.8.0] - 2026-04-05\n\n### Breaking\n- old breaking in previous version\n"
    )
    assert version_check.parse_breaking_from_description(description, "0.9.0") is False


def test_parse_breaking_from_description_false_when_version_missing() -> None:
    description = "## [0.8.0] - 2026-04-05\n\n### Added\n- something\n"
    assert version_check.parse_breaking_from_description(description, "0.9.0") is False


def test_parse_breaking_from_description_false_on_empty_description() -> None:
    assert version_check.parse_breaking_from_description("", "0.9.0") is False


def test_parse_breaking_from_description_false_on_empty_version() -> None:
    description = "## [0.9.0]\n\n### Breaking\n- x\n"
    assert version_check.parse_breaking_from_description(description, "") is False


def test_parse_breaking_from_description_scans_to_eof_when_last_section() -> None:
    """Covers the `next_section_match is None` branch: the target version is
    the last section in the description, so the body runs to EOF."""
    description = "## [0.9.0] - 2026-04-06\n\n### Breaking\n- final section\n"
    assert version_check.parse_breaking_from_description(description, "0.9.0") is True


def test_parse_breaking_ignores_unreleased_section_when_querying_older_version() -> None:
    """Real-world CHANGELOG layout: ``## [Unreleased]`` sits above the latest
    released version. When querying a released version, BREAKING markers
    inside the Unreleased section must NOT contaminate the result. Validates
    that the regex-based section finder correctly targets ``## [X.Y.Z]`` and
    not ``## [Unreleased]`` (which contains no numeric version pattern)."""
    description = (
        "## [Unreleased]\n\n### Breaking\n- a future breaking change\n\n"
        "## [0.4.2] - 2026-04-06\n\n### Fixed\n- silent fallback\n\n"
        "## [0.4.1] - 2026-04-06\n\n### Fixed\n- coverage gap\n"
    )
    # Query the middle version — must return False despite Unreleased having
    # a BREAKING marker above, because the section finder anchors on the
    # exact ``## [0.4.2]`` header.
    assert version_check.parse_breaking_from_description(description, "0.4.2") is False


# ---------------------------------------------------------------------------
# parse_breaking_from_description: markdown code-span awareness (v0.4.3)
#
# CHANGELOG sections describing breaking-detection logic name marker tokens
# inside backticks for readability. Without stripping markdown code spans
# before keyword scanning, these literal references trigger false positives.
# The GitHub-raw fetch path in v0.3.0~v0.4.1 always returned False on 404
# and masked this trap for 3 releases; v0.4.2 end-to-end verification on
# real PyPI description caught it.
# ---------------------------------------------------------------------------


def test_parse_breaking_ignores_backtick_wrapped_markers() -> None:
    """Self-referential documentation: a CHANGELOG section names all three
    marker tokens inside inline code to explain the detection mechanism.
    None of them must count as declarations."""
    description = (
        "## [0.9.0] - 2026-04-06\n\n"
        "### Added\n"
        "- Breaking detection scans for `### Breaking` headers, "
        "`BREAKING CHANGE` phrases, or `BREAKING:` prefixes in the target "
        "section.\n"
    )
    assert version_check.parse_breaking_from_description(description, "0.9.0") is False


def test_parse_breaking_detects_real_heading_alongside_backtick_references() -> None:
    """Mixed scenario: backtick-wrapped references to marker tokens coexist
    with a real ``### Breaking`` heading in the same section. The real
    heading must still be detected after code-span stripping.

    Complementary test: this verifies ``_strip_markdown_code_spans`` does
    NOT accidentally wipe out real ``### Breaking`` headings that have no
    surrounding backticks. It would still pass even without the strip
    preprocessor (the real heading is detectable either way); its purpose
    is to catch *overly-aggressive* stripping in future edits, not to
    validate the false-positive guard (which the siblings above do)."""
    description = (
        "## [0.9.0] - 2026-04-06\n\n"
        "- Prior art: we look for `### Breaking` headers in CHANGELOG "
        "sections (the literal token above is an inline code reference, not "
        "a declaration).\n\n"
        "### Breaking\n"
        "- Removed deprecated API\n"
    )
    assert version_check.parse_breaking_from_description(description, "0.9.0") is True


def test_parse_breaking_ignores_double_backtick_inline_code() -> None:
    """CommonMark allows ``...`` inline code to wrap content containing a
    single backtick. ``_strip_markdown_code_spans`` must handle this form in
    addition to single-backtick spans so that future CHANGELOG authors who
    need to embed a backtick inside a code reference do not accidentally
    leak BREAKING tokens past the stripper."""
    description = (
        "## [0.9.0] - 2026-04-06\n\n"
        "### Added\n"
        "- Double-backtick form for referencing the ``### Breaking`` marker, "
        "the ``BREAKING CHANGE`` phrase, and the ``BREAKING:`` prefix when "
        "inner backticks are needed.\n"
    )
    assert version_check.parse_breaking_from_description(description, "0.9.0") is False


def test_parse_breaking_ignores_fenced_code_block_markers() -> None:
    """Fenced code blocks can contain example CHANGELOG snippets that show
    what a real breaking entry looks like — these are examples, not
    declarations, and must be stripped before scanning."""
    description = (
        "## [0.9.0] - 2026-04-06\n\n"
        "Example of what a breaking CHANGELOG entry looks like:\n\n"
        "```markdown\n"
        "## [2.0.0]\n"
        "### Breaking\n"
        "- Something broke\n"
        "```\n"
        "\n"
        "This release contains no breaking changes.\n"
    )
    assert version_check.parse_breaking_from_description(description, "0.9.0") is False


def test_parse_breaking_fixes_v030_self_description_trap_regression() -> None:
    """Regression test pinning the 2026-04-06 discovery: v0.3.0's real
    CHANGELOG entry describes the new breaking-detection feature by listing
    all three markers inline. v0.4.2 end-to-end verification against real
    PyPI description exposed this as a false positive (has_breaking=True on
    v0.3.0 query). v0.4.3's markdown code-span preprocessor fixes it. This
    test reproduces the exact original prose verbatim to guard against
    future regressions."""
    description = (
        "## [0.3.0] - 2026-04-06\n\n"
        "### Added\n"
        "- **Breaking-change detection from CHANGELOG**. When a new version "
        "is detected, the worker fetches the GitHub-hosted CHANGELOG and "
        "searches the new version's section for `### Breaking` headers, "
        "`BREAKING CHANGE` phrases, or `BREAKING:` prefixes. If found, "
        "`update_severity` is set to `\"breaking\"` instead of the "
        "SemVer-derived `patch/minor/major`.\n"
    )
    assert version_check.parse_breaking_from_description(description, "0.3.0") is False


# ---------------------------------------------------------------------------
# refresh_cache_from_pypi
# ---------------------------------------------------------------------------


def test_refresh_cache_from_pypi_success(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        version_check,
        "fetch_pypi_meta",
        lambda timeout: ("99.0.0", "2026-04-06T00:00:00Z", "## [99.0.0]\n\n### Added\n- x\n"),
    )
    assert version_check.refresh_cache_from_pypi() is True
    loaded = version_check.load_cache()
    assert loaded is not None
    assert loaded["latest_version"] == "99.0.0"
    assert loaded["has_breaking"] is False
    assert loaded["changelog_url"] == "https://pypi.org/project/wxflywheel/99.0.0/"
    assert "checked_at_epoch" in loaded


def test_refresh_cache_from_pypi_detects_breaking_from_description(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    description = "## [99.0.0] - 2026-04-06\n\n### Breaking\n- incompatible change\n"
    monkeypatch.setattr(
        version_check,
        "fetch_pypi_meta",
        lambda timeout: ("99.0.0", "2026-04-06T00:00:00Z", description),
    )
    assert version_check.refresh_cache_from_pypi() is True
    loaded = version_check.load_cache()
    assert loaded is not None
    assert loaded["has_breaking"] is True


def test_refresh_cache_from_pypi_returns_false_on_pypi_failure(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(version_check, "fetch_pypi_meta", lambda timeout: None)
    assert version_check.refresh_cache_from_pypi() is False


def test_refresh_cache_from_pypi_skips_changelog_parse_when_no_upgrade(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When latest == current, ``parse_breaking_from_description`` must NOT
    be invoked (observable via a counter injected as the patched parser).
    This covers the ``latest_v > current_v`` False branch."""
    description = "## [" + __version__ + "]\n\n### Breaking\n- should not be read\n"
    monkeypatch.setattr(
        version_check,
        "fetch_pypi_meta",
        lambda timeout: (__version__, "2026-04-06T00:00:00Z", description),
    )
    call_count = {"n": 0}

    def _fake_parser(desc: str, ver: str) -> bool:
        call_count["n"] += 1
        return True

    monkeypatch.setattr(version_check, "parse_breaking_from_description", _fake_parser)
    assert version_check.refresh_cache_from_pypi() is True
    assert call_count["n"] == 0  # no upgrade → no parse
    loaded = version_check.load_cache()
    assert loaded is not None
    assert loaded["has_breaking"] is False


def test_refresh_cache_from_pypi_handles_invalid_version(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        version_check,
        "fetch_pypi_meta",
        lambda timeout: ("not-a-version", "2026-04-06T00:00:00Z", ""),
    )
    assert version_check.refresh_cache_from_pypi() is True
    loaded = version_check.load_cache()
    assert loaded is not None
    assert loaded["has_breaking"] is False


# ---------------------------------------------------------------------------
# compare_versions / compute_severity / compute_days_behind
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "current,latest,expected",
    [
        ("0.2.0", "0.3.0", -1),
        ("0.3.0", "0.3.0", 0),
        ("0.3.0", "0.2.0", 1),
        ("1.0.0", "2.0.0", -1),
        ("not-a-version", "0.3.0", 0),
        ("0.3.0", "bad", 0),
    ],
)
def test_compare_versions(current: str, latest: str, expected: int) -> None:
    assert version_check.compare_versions(current, latest) == expected


@pytest.mark.parametrize(
    "current,latest,has_breaking,expected",
    [
        ("0.2.1", "0.2.2", False, "patch"),
        ("0.2.1", "0.3.0", False, "minor"),
        ("0.2.1", "1.0.0", False, "major"),
        ("0.2.1", "0.3.0", True, "breaking"),
        ("0.3.0", "0.3.0", False, None),
        ("0.3.0", "0.2.0", False, None),
        ("bad", "0.3.0", False, None),
    ],
)
def test_compute_severity(
    current: str, latest: str, has_breaking: bool, expected: str | None
) -> None:
    assert version_check.compute_severity(current, latest, has_breaking) == expected


def test_compute_days_behind_with_iso_timezone() -> None:
    past = "2020-01-01T00:00:00+00:00"
    days = version_check.compute_days_behind(past)
    assert days is not None
    assert days > 2000  # at least 5 years


def test_compute_days_behind_with_z_suffix() -> None:
    past = "2020-01-01T00:00:00Z"
    days = version_check.compute_days_behind(past)
    assert days is not None
    assert days > 2000


def test_compute_days_behind_without_tz() -> None:
    past = "2020-01-01T00:00:00"
    days = version_check.compute_days_behind(past)
    assert days is not None
    assert days > 2000


def test_compute_days_behind_returns_none_for_empty() -> None:
    assert version_check.compute_days_behind(None) is None
    assert version_check.compute_days_behind("") is None


def test_compute_days_behind_returns_none_for_bad_format() -> None:
    assert version_check.compute_days_behind("not a date") is None


def test_compute_days_behind_clamps_to_zero_for_future() -> None:
    future = "2099-01-01T00:00:00Z"
    assert version_check.compute_days_behind(future) == 0


# ---------------------------------------------------------------------------
# try_trigger_background_refresh
# ---------------------------------------------------------------------------


def test_try_trigger_background_refresh_in_worker_mode_is_noop(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("WXFLYWHEEL_WORKER", "1")
    called = {"spawned": False}

    def _fake_popen(*a: Any, **kw: Any) -> MagicMock:
        called["spawned"] = True
        return MagicMock()

    monkeypatch.setattr(subprocess, "Popen", _fake_popen)
    version_check.try_trigger_background_refresh()
    assert called["spawned"] is False


def test_try_trigger_background_refresh_spawns_popen(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)
    calls: list[Any] = []

    def _fake_popen(args: list[str], **kwargs: Any) -> MagicMock:
        calls.append((args, kwargs))
        return MagicMock()

    monkeypatch.setattr(subprocess, "Popen", _fake_popen)
    version_check.try_trigger_background_refresh()
    assert len(calls) == 1
    spawned_args, _ = calls[0]
    assert "_version_check_worker" in spawned_args[-1]


def test_try_trigger_background_refresh_fallback_on_oserror(
    monkeypatch: pytest.MonkeyPatch, _isolated_cache: Path
) -> None:
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)

    def _raise(*a: Any, **kw: Any) -> None:
        raise OSError("fork denied")

    monkeypatch.setattr(subprocess, "Popen", _raise)
    refresh_called = {"n": 0}

    def _fake_refresh(timeout: float = 0.5) -> bool:
        refresh_called["n"] += 1
        return True

    monkeypatch.setattr(version_check, "refresh_cache_from_pypi", _fake_refresh)
    version_check.try_trigger_background_refresh()
    assert refresh_called["n"] == 1


def test_try_trigger_background_refresh_fallback_swallows_refresh_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)

    def _popen_raise(*a: Any, **kw: Any) -> None:
        raise OSError("fork denied")

    def _refresh_raise(timeout: float = 0.5) -> bool:
        raise RuntimeError("boom")

    monkeypatch.setattr(subprocess, "Popen", _popen_raise)
    monkeypatch.setattr(version_check, "refresh_cache_from_pypi", _refresh_raise)
    # Must NOT raise
    version_check.try_trigger_background_refresh()


def test_try_trigger_background_refresh_windows_creationflags(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Force the Windows branch regardless of host OS. Needed so that POSIX
    CI runners (ubuntu, macos) reach the creationflags code path and branch
    coverage stays at 100% on every matrix cell."""
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)
    monkeypatch.setattr("sys.platform", "win32")
    captured: dict[str, Any] = {}

    def _fake_popen(args: list[str], **kwargs: Any) -> MagicMock:
        captured.update(kwargs)
        return MagicMock()

    monkeypatch.setattr(subprocess, "Popen", _fake_popen)
    version_check.try_trigger_background_refresh()
    assert "creationflags" in captured
    assert "start_new_session" not in captured


def test_try_trigger_background_refresh_posix_start_new_session(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Force the POSIX branch regardless of host OS. Needed so that Windows
    CI runners reach the start_new_session code path and branch coverage
    stays at 100% on every matrix cell. Symmetric counterpart to
    ``test_try_trigger_background_refresh_windows_creationflags``."""
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)
    monkeypatch.setattr("sys.platform", "linux")
    captured: dict[str, Any] = {}

    def _fake_popen(args: list[str], **kwargs: Any) -> MagicMock:
        captured.update(kwargs)
        return MagicMock()

    monkeypatch.setattr(subprocess, "Popen", _fake_popen)
    version_check.try_trigger_background_refresh()
    assert captured.get("start_new_session") is True
    assert "creationflags" not in captured


# ---------------------------------------------------------------------------
# build_meta
# ---------------------------------------------------------------------------


def test_build_meta_test_mode_returns_minimal_stub(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("WXFLYWHEEL_NO_META", "1")
    meta = version_check.build_meta()
    assert meta == {"cli": {"current_version": __version__}}


def test_build_meta_empty_cache_returns_12_keys(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Prevent spawning during the test
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)
    meta = version_check.build_meta()
    cli = meta["cli"]
    assert cli["current_version"] == __version__
    assert cli["latest_version"] is None
    assert cli["update_available"] is None
    assert cli["update_severity"] is None
    assert cli["days_behind"] is None
    assert cli["changelog_url"] is None
    assert cli["latest_release_date"] is None
    assert cli["has_breaking"] is None
    assert cli["cache_age_seconds"] is None
    assert cli["update_command"] == version_check.UPDATE_COMMAND
    assert cli["self_update_command"] == version_check.SELF_UPDATE_COMMAND
    assert "python_version" in cli


def test_build_meta_with_fresh_cache_populates_fields(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)
    _isolated_cache.mkdir(parents=True)
    cache = {
        "latest_version": "99.0.0",
        "latest_release_date": "2026-04-06T00:00:00Z",
        "changelog_url": "https://example.com/release",
        "has_breaking": False,
        "checked_at_epoch": time.time() - 60,
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(cache))
    meta = version_check.build_meta()
    cli = meta["cli"]
    assert cli["latest_version"] == "99.0.0"
    assert cli["update_available"] is True
    assert cli["update_severity"] == "major"
    assert cli["changelog_url"] == "https://example.com/release"
    assert cli["has_breaking"] is False
    assert cli["cache_age_seconds"] is not None


def test_build_meta_triggers_refresh_when_cache_expired(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _isolated_cache.mkdir(parents=True)
    stale_cache = {
        "latest_version": "99.0.0",
        "checked_at_epoch": time.time() - 2 * version_check.CACHE_TTL_SECONDS,
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(stale_cache))

    triggered = {"n": 0}

    def _fake_trigger() -> None:
        triggered["n"] += 1

    monkeypatch.setattr(version_check, "try_trigger_background_refresh", _fake_trigger)
    version_check.build_meta()
    assert triggered["n"] == 1


def test_build_meta_does_not_trigger_refresh_when_cache_fresh(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _isolated_cache.mkdir(parents=True)
    fresh_cache = {
        "latest_version": __version__,
        "checked_at_epoch": time.time() - 60,
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(fresh_cache))

    triggered = {"n": 0}
    monkeypatch.setattr(
        version_check,
        "try_trigger_background_refresh",
        lambda: triggered.__setitem__("n", triggered["n"] + 1),
    )
    version_check.build_meta()
    assert triggered["n"] == 0


def test_build_meta_handles_partial_cache_fields(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cache with only some fields populated should still yield a stable
    12-key schema with missing fields as None."""
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)
    _isolated_cache.mkdir(parents=True)
    partial = {
        "latest_version": "99.0.0",
        "checked_at_epoch": time.time() - 60,
        # No latest_release_date, no changelog_url
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(partial))
    meta = version_check.build_meta()
    cli = meta["cli"]
    assert cli["latest_version"] == "99.0.0"
    assert cli["latest_release_date"] is None
    assert cli["changelog_url"] is None
    assert cli["days_behind"] is None


def test_build_meta_handles_cache_without_latest_version_key(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Covers the `if isinstance(latest, str) and latest:` False branch — when
    the cache file exists but the latest_version key is missing or empty."""
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)
    _isolated_cache.mkdir(parents=True)
    cache_without_latest = {
        "checked_at_epoch": time.time() - 60,
        # No latest_version at all
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(cache_without_latest))
    meta = version_check.build_meta()
    cli = meta["cli"]
    assert cli["latest_version"] is None
    assert cli["update_available"] is None
    assert cli["update_severity"] is None


def test_build_meta_handles_cache_with_empty_latest_version_string(
    _isolated_cache: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Covers the `if isinstance(latest, str) and latest:` False branch when
    the value is an empty string (distinct from missing key)."""
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)
    _isolated_cache.mkdir(parents=True)
    cache = {
        "latest_version": "",
        "checked_at_epoch": time.time() - 60,
    }
    (_isolated_cache / "version_check.json").write_text(json.dumps(cache))
    meta = version_check.build_meta()
    assert meta["cli"]["latest_version"] is None
