"""Tests for meta field injection in wxflywheel.output.emit_payload."""

from __future__ import annotations

import json
from typing import Any

import pytest
from click.testing import CliRunner

from wxflywheel import __version__, output, version_check
from wxflywheel.cli import cli


def test_emit_payload_includes_meta_by_default(
    capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """When include_meta is default, a cli meta object must be attached."""
    monkeypatch.setenv("WXFLYWHEEL_NO_META", "1")  # deterministic stub meta
    output.emit_payload({"code": 200, "data": {"foo": "bar"}, "message": ""})
    captured = capsys.readouterr()
    payload = json.loads(captured.out)
    assert "meta" in payload
    assert payload["meta"]["cli"]["current_version"] == __version__
    assert payload["data"]["foo"] == "bar"


def test_emit_payload_skips_meta_when_flag_false(
    capsys: pytest.CaptureFixture[str],
) -> None:
    output.emit_payload(
        {"code": 200, "data": {"foo": "bar"}, "message": ""}, include_meta=False
    )
    captured = capsys.readouterr()
    payload = json.loads(captured.out)
    assert "meta" not in payload


def test_emit_payload_meta_injection_failure_is_silent(
    capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """If build_meta raises, the main payload must still be emitted."""

    def _boom() -> dict[str, Any]:
        raise RuntimeError("broken")

    monkeypatch.setattr(version_check, "build_meta", _boom)
    monkeypatch.delenv("WXFLYWHEEL_NO_META", raising=False)
    output.emit_payload({"code": 200, "data": "ok", "message": ""})
    captured = capsys.readouterr()
    payload = json.loads(captured.out)
    assert payload["data"] == "ok"
    assert "meta" not in payload  # injection failed, but main payload survived


def test_error_payload_attaches_environment_fingerprint() -> None:
    """v0.4.0: error_payload auto-injects a 10-key environment fingerprint
    under data._environment so any error JSON carries enough platform info
    for the Agent to diagnose cross-platform failures without round-tripping."""
    from wxflywheel.output import error_payload

    payload = error_payload(-42, "simulated error", data=None)
    assert payload["code"] == -42
    assert payload["message"] == "simulated error"
    assert isinstance(payload["data"], dict)
    assert "_environment" in payload["data"]
    env = payload["data"]["_environment"]
    assert "platform_system" in env
    assert "python_version" in env
    assert "locale_preferred_encoding" in env


def test_error_payload_preserves_existing_dict_data_and_merges_environment() -> None:
    from wxflywheel.output import error_payload

    payload = error_payload(-7, "pip failed", data={"before_version": "0.3.0"})
    assert payload["data"]["before_version"] == "0.3.0"
    assert "_environment" in payload["data"]


def test_error_payload_wraps_non_dict_data_in_details() -> None:
    from wxflywheel.output import error_payload

    payload = error_payload(-1, "list data", data=["item1", "item2"])
    assert payload["data"]["details"] == ["item1", "item2"]
    assert "_environment" in payload["data"]


def test_error_payload_survives_environment_collection_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If environment collection fails, error payload must still be emitted
    with the original data intact."""

    def _raise(*args: Any, **kwargs: Any) -> None:
        raise RuntimeError("env collection broken")

    monkeypatch.setattr("wxflywheel.environment.collect_environment", _raise)
    from wxflywheel.output import error_payload

    payload = error_payload(-1, "test", data={"key": "value"})
    # Original data preserved, _environment may or may not be present
    assert payload["code"] == -1
    assert payload["message"] == "test"
    # data should at least contain the original key
    assert payload["data"] is not None


def test_all_existing_commands_still_return_three_field_envelope(
    mock_resp: Any,
) -> None:
    """Regression: code/data/message contract is preserved even with meta
    injected. This test deliberately KEEPS the autouse conftest fixture's
    WXFLYWHEEL_NO_META=1 setting so meta returns a deterministic stub —
    otherwise build_meta would hit load_cache()/try_trigger_background_refresh()
    and spawn a real worker subprocess in CI, violating test isolation."""
    from unittest.mock import patch

    runner = CliRunner()
    api_resp = {"code": 200, "data": {"loginState": 1}, "message": ""}
    env = {"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://localhost:8011"}
    with patch(
        "wxflywheel.client.requests.request", return_value=mock_resp(api_resp)
    ):
        result = runner.invoke(cli, ["login", "status"], env=env)
    payload = json.loads(result.output)
    # Original three fields
    assert "code" in payload
    assert "data" in payload
    assert "message" in payload
    # Plus the new meta field (stubbed by autouse conftest fixture)
    assert "meta" in payload
    assert payload["meta"]["cli"]["current_version"] == __version__
