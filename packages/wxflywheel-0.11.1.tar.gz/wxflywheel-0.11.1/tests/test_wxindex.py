import json
import time
from typing import Any
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from tests.conftest import MockRespFactory
from wxflywheel.cli import cli

ENV = {"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://localhost:8011"}


def test_wxindex_query_passes_through_full_backend_payload(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_data = {
        "keyword": "社群运营",
        "current_value": 612,
        "trend": [{"date": "2026-04-08", "value": 590}, {"date": "2026-04-09", "value": 612}],
        "multichannel": {
            "record_id": 7,
            "ymd": 20260409,
            "today_score": 612,
            "yesterday_score": 575,
            "today": {"total_score": 612, "finder_score": 188, "mpdoc_score": 210},
            "yesterday": {"total_score": 575, "finder_score": 160, "mpdoc_score": 205},
            "total_count": 14,
        },
        "channel_trend": [
            {
                "ymd": "20260408",
                "channel_score": {"total_score": 590, "finder_score": 170, "mpdoc_score": 208},
            },
            {
                "ymd": "20260409",
                "channel_score": {"total_score": 612, "finder_score": 188, "mpdoc_score": 210},
            },
        ],
        "updated_at": "2026-04-09 18:20:00",
    }
    api_resp = {"code": 200, "data": api_data, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(
            cli,
            ["wxindex", "query", "--keyword", "社群运营"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["code"] == 200
    assert data["data"] == api_data


def test_wxindex_query_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": {}, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_get:
        runner.invoke(
            cli,
            ["wxindex", "query", "--keyword", "社群 运营"],
            env=ENV,
        )
    called_url = mock_get.call_args.args[1]
    called_params = mock_get.call_args.kwargs["params"]
    assert called_url == "http://localhost:8011/api/wxindex/%E7%A4%BE%E7%BE%A4%20%E8%BF%90%E8%90%A5"
    assert called_params["key"] == "test-key"


def test_wxindex_query_api_error_exits_1(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = CliRunner()
    fake_now = {"value": 0.0}

    def _fake_monotonic() -> float:
        return fake_now["value"]

    def _fake_sleep(seconds: float) -> None:
        fake_now["value"] += seconds

    def _fake_request(method: str, url: str, **kwargs: object) -> Any:
        if "/api/wxindex/" in url:
            return mock_resp({"code": 300, "data": None, "message": "获取凭证失败"})
        if url.endswith("/v1/login/GetLoginStatus"):
            return mock_resp({"code": 200, "data": {"loginState": 3}, "message": ""})
        raise AssertionError(f"unexpected url: {url}")

    monkeypatch.setattr(time, "monotonic", _fake_monotonic)
    monkeypatch.setattr(time, "sleep", _fake_sleep)
    with patch("wxflywheel.client.requests.request", side_effect=_fake_request):
        result = runner.invoke(
            cli,
            ["wxindex", "query", "--keyword", "社群运营"],
            env=ENV,
        )
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == 300
    assert "获取凭证失败" in err_data["message"]


def test_wxindex_query_keeps_null_data_as_null(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": None, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(
            cli,
            ["wxindex", "query", "--keyword", "社群运营"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["data"] is None


def test_wxindex_related_outputs_keyword_and_words_on_success(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {
        "code": 200,
        "data": ["社群运营", "私域运营", "社群营销"],
        "message": "",
    }
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(
            cli,
            ["wxindex", "related", "--keyword", "社群"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["code"] == 200
    assert data["data"]["keyword"] == "社群"
    assert data["data"]["related"] == ["社群运营", "私域运营", "社群营销"]


def test_wxindex_related_calls_correct_api(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": [], "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)) as mock_get:
        runner.invoke(
            cli,
            ["wxindex", "related", "--keyword", "社群 运营"],
            env=ENV,
        )
    called_url = mock_get.call_args.args[1]
    called_params = mock_get.call_args.kwargs["params"]
    assert called_url == "http://localhost:8011/api/wxindexsug/%E7%A4%BE%E7%BE%A4%20%E8%BF%90%E8%90%A5"
    assert called_params["key"] == "test-key"


def test_wxindex_related_api_error_exits_1(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    runner = CliRunner()
    fake_now = {"value": 0.0}

    def _fake_monotonic() -> float:
        return fake_now["value"]

    def _fake_sleep(seconds: float) -> None:
        fake_now["value"] += seconds

    def _fake_request(method: str, url: str, **kwargs: object) -> Any:
        if "/api/wxindexsug/" in url:
            return mock_resp({"code": 300, "data": None, "message": "获取凭证失败"})
        if url.endswith("/v1/login/GetLoginStatus"):
            return mock_resp({"code": 200, "data": {"loginState": 3}, "message": ""})
        raise AssertionError(f"unexpected url: {url}")

    monkeypatch.setattr(time, "monotonic", _fake_monotonic)
    monkeypatch.setattr(time, "sleep", _fake_sleep)
    with patch("wxflywheel.client.requests.request", side_effect=_fake_request):
        result = runner.invoke(
            cli,
            ["wxindex", "related", "--keyword", "社群"],
            env=ENV,
        )
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == 300
    assert "获取凭证失败" in err_data["message"]


def test_wxindex_related_normalizes_null_data_to_empty_list(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": None, "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(
            cli,
            ["wxindex", "related", "--keyword", "社群"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["data"]["keyword"] == "社群"
    assert data["data"]["related"] == []


def test_wxindex_related_filters_non_string_items(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    api_resp = {"code": 200, "data": ["社群运营", 1, None], "message": ""}
    with patch("wxflywheel.client.requests.request", return_value=mock_resp(api_resp)):
        result = runner.invoke(
            cli,
            ["wxindex", "related", "--keyword", "社群"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["data"]["related"] == ["社群运营"]
