"""Tests for wxflywheel.environment runtime fingerprint module."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from wxflywheel import environment

# ---------------------------------------------------------------------------
# _safe
# ---------------------------------------------------------------------------


def test_safe_returns_str_on_success() -> None:
    assert environment._safe(lambda: "hello") == "hello"


def test_safe_returns_str_representation_of_non_string() -> None:
    assert environment._safe(lambda: 42) == "42"


def test_safe_returns_unknown_on_exception() -> None:
    def _raise() -> str:
        raise RuntimeError("boom")

    assert environment._safe(_raise) == "unknown"


def test_safe_returns_unknown_on_none() -> None:
    assert environment._safe(lambda: None) == "unknown"


def test_safe_returns_unknown_on_empty_string() -> None:
    assert environment._safe(lambda: "") == "unknown"


# ---------------------------------------------------------------------------
# collect_environment
# ---------------------------------------------------------------------------


def test_collect_environment_has_10_required_keys() -> None:
    env = environment.collect_environment()
    required_keys = {
        "platform_system",
        "platform_release",
        "platform_machine",
        "platform_version",
        "python_version",
        "python_implementation",
        "python_executable",
        "locale_preferred_encoding",
        "stdout_encoding",
        "filesystem_encoding",
    }
    assert set(env.keys()) == required_keys


def test_collect_environment_all_values_are_strings() -> None:
    env = environment.collect_environment()
    for key, value in env.items():
        assert isinstance(value, str), f"{key} is not a string"
        assert value != ""  # empty strings become "unknown"


def test_collect_environment_python_version_looks_like_version() -> None:
    env = environment.collect_environment()
    # Should be something like "3.11.4" or "3.12.0", never "unknown" in normal CI
    assert "." in env["python_version"] or env["python_version"] == "unknown"


# ---------------------------------------------------------------------------
# describe_short
# ---------------------------------------------------------------------------


def test_describe_short_returns_single_line() -> None:
    description = environment.describe_short()
    assert "\n" not in description
    assert "Python" in description
    assert "encoding" in description


# ---------------------------------------------------------------------------
# cache_dir_info
# ---------------------------------------------------------------------------


def test_cache_dir_info_returns_writable_for_tmp(tmp_path: Path) -> None:
    info = environment.cache_dir_info(tmp_path / "wxflywheel_cache_test")
    assert info["writable"] is True
    assert info["error"] is None
    assert info["path"] == str(tmp_path / "wxflywheel_cache_test")


def test_cache_dir_info_reports_error_on_readonly(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    target = tmp_path / "readonly"

    def _raise_oserror(*args: Any, **kwargs: Any) -> None:
        raise OSError("read-only filesystem")

    monkeypatch.setattr(Path, "mkdir", _raise_oserror)
    info = environment.cache_dir_info(target)
    assert info["writable"] is False
    assert info["error"] is not None
    assert "OSError" in info["error"]


def test_cache_dir_info_handles_non_oserror(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    target = tmp_path / "weird"

    def _raise_runtime(*args: Any, **kwargs: Any) -> None:
        raise RuntimeError("unexpected")

    monkeypatch.setattr(Path, "mkdir", _raise_runtime)
    info = environment.cache_dir_info(target)
    assert info["writable"] is False
    assert info["error"] is not None
    assert "RuntimeError" in info["error"]


def test_cache_dir_info_handles_existing_directory(tmp_path: Path) -> None:
    target = tmp_path / "exists"
    target.mkdir()
    info = environment.cache_dir_info(target)
    assert info["exists"] is True
    assert info["writable"] is True


# ---------------------------------------------------------------------------
# env_var_summary
# ---------------------------------------------------------------------------


def test_env_var_summary_has_4_keys() -> None:
    summary = environment.env_var_summary()
    assert set(summary.keys()) == {
        "WXFLYWHEEL_NO_META",
        "WXFLYWHEEL_WORKER",
        "WXFLYWHEEL_CACHE_DIR",
        "LANG",
    }


def test_env_var_summary_returns_unset_marker_for_missing_vars(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("WXFLYWHEEL_CACHE_DIR", raising=False)
    monkeypatch.delenv("WXFLYWHEEL_WORKER", raising=False)
    summary = environment.env_var_summary()
    assert summary["WXFLYWHEEL_CACHE_DIR"] == "<unset>"
    assert summary["WXFLYWHEEL_WORKER"] == "<unset>"


def test_env_var_summary_returns_actual_value_when_set(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("WXFLYWHEEL_CACHE_DIR", "/custom/path")
    summary = environment.env_var_summary()
    assert summary["WXFLYWHEEL_CACHE_DIR"] == "/custom/path"


def test_env_var_summary_preserves_no_meta_when_set_by_autouse(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The autouse conftest fixture sets WXFLYWHEEL_NO_META=1; verify env_var_summary sees it."""
    summary = environment.env_var_summary()
    assert summary["WXFLYWHEEL_NO_META"] == "1"
