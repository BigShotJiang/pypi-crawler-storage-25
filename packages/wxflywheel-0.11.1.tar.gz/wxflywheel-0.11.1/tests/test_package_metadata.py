from __future__ import annotations

import pkgutil


def test_package_ships_py_typed_marker() -> None:
    assert pkgutil.get_data("wxflywheel", "py.typed") is not None
