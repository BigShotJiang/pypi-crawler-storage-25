import time
from unittest.mock import MagicMock, patch

import pytest
import requests

from tests.conftest import MockRespFactory
from wxflywheel.client import WxflywheelClient
from wxflywheel.exceptions import WxflywheelError

# ── 成功路径 ──────────────────────────────────────────────────────────────


def test_get_normalizes_uppercase_success_payload(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"Code": 200, "Data": {"items": []}, "Text": ""}),
    ) as mock_get:
        result = client.get("/api/test", keyword="hello")
    mock_get.assert_called_once_with(
        "GET",
        "http://localhost:8011/api/test",
        params={"key": "test-key", "keyword": "hello"},
        json=None,
        timeout=60.0,
        stream=False,
    )
    assert result == {"code": 200, "data": {"items": []}, "message": ""}


def test_get_normalizes_lowercase_success_payload(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 200, "data": {"items": []}, "message": ""}),
    ):
        result = client.get("/api/test")
    assert result == {"code": 200, "data": {"items": []}, "message": ""}


def test_post_returns_standard_payload_on_200(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 200, "data": {}, "message": ""}),
    ) as mock_post:
        result = client.post("/v1/test/Action", {"Field": "value"})
    mock_post.assert_called_once_with(
        "POST",
        "http://localhost:8011/v1/test/Action",
        params={"key": "test-key"},
        json={"Field": "value"},
        timeout=60.0,
        stream=False,
    )
    assert result["code"] == 200


def test_host_trailing_slash_stripped(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011/")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 200, "data": {}, "message": ""}),
    ) as mock_get:
        client.get("/api/test")
    called_url = mock_get.call_args.args[1]
    assert called_url == "http://localhost:8011/api/test"


# ── 错误路径 ──────────────────────────────────────────────────────────────


def test_get_raises_wxflywheel_error_on_network_error() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            side_effect=requests.exceptions.ConnectionError("refused"),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == -999
    assert "refused" in exc_info.value.message
    assert exc_info.value.data is None


def test_get_raises_on_non_200(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"Code": 300, "Data": None, "Text": "账号掉线"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == 300
    assert exc_info.value.message == "账号掉线"
    assert exc_info.value.data is None


def test_handle_raises_on_lowercase_error_payload(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"code": 1402, "message": "unauthorized"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == 1402
    assert "unauthorized" in exc_info.value.message


def test_handle_raises_on_missing_code_field(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"error": "unexpected"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == -999
    assert "missing code/Code" in exc_info.value.message


def test_handle_accepts_numeric_string_code(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"Code": "300", "Text": "error msg"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == 300


def test_handle_raises_on_invalid_string_code(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"Code": "N/A", "Text": "error"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == -999
    assert "not numeric" in exc_info.value.message


def test_handle_raises_on_non_json_response() -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    bad_resp = MagicMock()
    bad_resp.status_code = 502
    bad_resp.text = "<html>Bad Gateway</html>"
    bad_resp.json.side_effect = ValueError("not json")
    with (
        patch("wxflywheel.client.requests.request", return_value=bad_resp),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == -999
    assert "502" in exc_info.value.message or "Bad Gateway" in exc_info.value.message


def test_raw_get_returns_response() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    fake_resp = MagicMock()
    fake_resp.status_code = 200
    with patch("wxflywheel.client.requests.request", return_value=fake_resp) as mock_get:
        result = client.raw_get("/api/stream", extra_param="val")
    mock_get.assert_called_once_with(
        "GET",
        "http://localhost:8011/api/stream",
        params={"key": "test-key", "extra_param": "val"},
        json=None,
        timeout=(10, 300),
        stream=True,
    )
    assert result is fake_resp


def test_raw_get_raises_on_network_error() -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            side_effect=requests.exceptions.Timeout("timed out"),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.raw_get("/api/stream")
    assert exc_info.value.code == -999
    assert "timed out" in exc_info.value.message


def test_post_raises_on_network_error() -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            side_effect=requests.exceptions.ConnectionError("refused"),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.post("/v1/test/Action", {"Field": "val"})
    assert exc_info.value.code == -999
    assert "refused" in exc_info.value.message


def test_handle_raises_on_non_dict_json_response() -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    list_resp = MagicMock()
    list_resp.status_code = 200
    list_resp.text = "[1, 2, 3]"
    list_resp.json.return_value = [1, 2, 3]
    with (
        patch("wxflywheel.client.requests.request", return_value=list_resp),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")
    assert exc_info.value.code == -999
    assert "not a JSON object" in exc_info.value.message


def test_post_raises_on_non_200(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"Code": 403, "Data": None, "Text": "forbidden"}),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.post("/v1/test/Action", {"Field": "val"})
    assert exc_info.value.code == 403
    assert "forbidden" in exc_info.value.message
    assert exc_info.value.data is None


def test_handle_ignores_http_status_code_when_body_code_200(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    resp = mock_resp({"Code": 200, "Data": {"loginState": 1}, "Text": ""}, status=500)
    with patch("wxflywheel.client.requests.request", return_value=resp):
        result = client.get("/api/test")
    assert result["code"] == 200
    assert result["data"]["loginState"] == 1


def test_handle_prefers_lowercase_fields_when_both_are_present(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp(
            {
                "Code": 200,
                "code": 200,
                "Data": {"old": True},
                "data": {"new": True},
                "message": "ok",
            }
        ),
    ):
        result = client.get("/api/test")
    assert result["data"] == {"new": True}
    assert result["message"] == "ok"


def test_handle_normalizes_missing_message_to_empty_string(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 200, "data": {"ok": True}}),
    ):
        result = client.get("/api/test")
    assert result["message"] == ""


def test_handle_stringifies_non_string_message(mock_resp: MockRespFactory) -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    with patch(
        "wxflywheel.client.requests.request",
        return_value=mock_resp({"code": 200, "data": {"ok": True}, "message": False}),
    ):
        result = client.get("/api/test")
    assert result["message"] == "False"


def test_raw_get_custom_timeout_is_passed_through() -> None:
    client = WxflywheelClient(key="k", host="http://localhost:8011")
    fake_resp = MagicMock()
    with patch("wxflywheel.client.requests.request", return_value=fake_resp) as mock_get:
        client.raw_get("/api/stream", timeout=(5, 600))
    _, kwargs = mock_get.call_args
    assert kwargs["timeout"] == (5, 600)
    assert kwargs["stream"] is True


def test_get_recovers_after_transient_timeout(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    monkeypatch.setattr(time, "sleep", lambda _: None)
    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            requests.exceptions.Timeout("timed out"),
            mock_resp({"code": 200, "data": {"loginState": 1}, "message": ""}),
            mock_resp({"code": 200, "data": {"ok": True}, "message": ""}),
        ],
    ) as mock_request:
        result = client.get("/api/test")

    assert result["data"] == {"ok": True}
    assert [call.args[1] for call in mock_request.call_args_list] == [
        "http://localhost:8011/api/test",
        "http://localhost:8011/v1/login/GetLoginStatus",
        "http://localhost:8011/api/test",
    ]


@pytest.mark.parametrize(
    "api_error_message",
    [
        "DecodePackHeader err timeout, ret=-13 (error session timeout)",
    ],
)
def test_get_recovers_after_transient_api_errors(
    api_error_message: str,
    mock_resp: MockRespFactory,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    monkeypatch.setattr(time, "sleep", lambda _: None)
    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            mock_resp({"code": 300, "data": None, "message": api_error_message}),
            mock_resp({"code": 200, "data": {"loginState": 1}, "message": ""}),
            mock_resp({"code": 200, "data": {"items": ["ok"]}, "message": ""}),
        ],
    ) as mock_request:
        result = client.get("/api/test")

    assert result["data"] == {"items": ["ok"]}
    assert [call.args[1] for call in mock_request.call_args_list] == [
        "http://localhost:8011/api/test",
        "http://localhost:8011/v1/login/GetLoginStatus",
        "http://localhost:8011/api/test",
    ]


def test_get_does_not_retry_auth_failed_when_login_is_still_online(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    monkeypatch.setattr(time, "sleep", lambda _: None)
    with (
        patch(
            "wxflywheel.client.requests.request",
            side_effect=[
                mock_resp({"code": 300, "data": None, "message": "auth failed"}),
                mock_resp({"code": 200, "data": {"loginState": 1}, "message": ""}),
            ],
        ) as mock_request,
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")

    assert exc_info.value.code == 300
    assert exc_info.value.message == "auth failed"
    assert [call.args[1] for call in mock_request.call_args_list] == [
        "http://localhost:8011/api/test",
        "http://localhost:8011/v1/login/GetLoginStatus",
    ]


def test_get_recovers_auth_failed_after_login_temporarily_drops_offline(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    fake_now = {"value": 0.0}
    sleep_calls: list[float] = []

    def _fake_monotonic() -> float:
        return fake_now["value"]

    def _fake_sleep(seconds: float) -> None:
        sleep_calls.append(seconds)
        fake_now["value"] += seconds

    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            mock_resp({"code": 300, "data": None, "message": "auth failed"}),
            mock_resp({"code": 200, "data": {"loginState": 3}, "message": ""}),
            mock_resp({"code": 200, "data": {"loginState": 1}, "message": ""}),
            mock_resp({"code": 200, "data": {"items": ["ok"]}, "message": ""}),
        ],
    ) as mock_request:
        monkeypatch.setattr(time, "monotonic", _fake_monotonic)
        monkeypatch.setattr(time, "sleep", _fake_sleep)
        result = client.get("/api/test")

    assert result["data"] == {"items": ["ok"]}
    assert sleep_calls == [5.0]
    assert [call.args[1] for call in mock_request.call_args_list] == [
        "http://localhost:8011/api/test",
        "http://localhost:8011/v1/login/GetLoginStatus",
        "http://localhost:8011/v1/login/GetLoginStatus",
        "http://localhost:8011/api/test",
    ]


def test_get_recovers_wxindex_auth_failed_even_when_login_stays_online(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    fake_now = {"value": 0.0}
    sleep_calls: list[float] = []

    def _fake_monotonic() -> float:
        return fake_now["value"]

    def _fake_sleep(seconds: float) -> None:
        sleep_calls.append(seconds)
        fake_now["value"] += seconds

    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            mock_resp({"code": 300, "data": None, "message": "auth failed"}),
            mock_resp({"code": 200, "data": {"loginState": 1}, "message": ""}),
            mock_resp({"code": 200, "data": {"loginState": 1}, "message": ""}),
            mock_resp({"code": 200, "data": {"items": ["ok"]}, "message": ""}),
        ],
    ) as mock_request:
        monkeypatch.setattr(time, "monotonic", _fake_monotonic)
        monkeypatch.setattr(time, "sleep", _fake_sleep)
        result = client.get("/api/wxindex/test")

    assert result["data"] == {"items": ["ok"]}
    assert sleep_calls == [5.0]
    assert [call.args[1] for call in mock_request.call_args_list] == [
        "http://localhost:8011/api/wxindex/test",
        "http://localhost:8011/v1/login/GetLoginStatus",
        "http://localhost:8011/v1/login/GetLoginStatus",
        "http://localhost:8011/api/wxindex/test",
    ]


def test_get_does_not_recover_for_non_recoverable_error(
    mock_resp: MockRespFactory,
) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            return_value=mock_resp({"code": 1402, "data": None, "message": "unauthorized"}),
        ) as mock_request,
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")

    assert exc_info.value.code == 1402
    assert mock_request.call_count == 1


def test_get_returns_last_error_when_recovery_window_expires(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    fake_now = {"value": 0.0}

    def _fake_monotonic() -> float:
        return fake_now["value"]

    def _fake_sleep(seconds: float) -> None:
        fake_now["value"] += seconds

    def _fake_request(method: str, url: str, **kwargs: object) -> MagicMock:
        if url.endswith("/api/test"):
            raise requests.exceptions.Timeout("timed out")
        return mock_resp({"code": 200, "data": {"loginState": 3}, "message": ""})

    monkeypatch.setattr(time, "monotonic", _fake_monotonic)
    monkeypatch.setattr(time, "sleep", _fake_sleep)

    with (
        patch("wxflywheel.client.requests.request", side_effect=_fake_request) as mock_request,
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")

    assert exc_info.value.code == -999
    assert "timed out" in exc_info.value.message
    assert mock_request.call_count > 1


def test_get_can_opt_out_of_recovery() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with (
        patch(
            "wxflywheel.client.requests.request",
            side_effect=requests.exceptions.Timeout("timed out"),
        ) as mock_request,
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test", allow_recovery=False)

    assert exc_info.value.code == -999
    assert mock_request.call_count == 1


def test_get_emits_recovery_notice_only_once_across_multiple_retries() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    original_attempts = {"count": 0}

    def _fake_request_json_once(
        method: str,
        path: str,
        *,
        params: dict[str, object] | None = None,
        body: dict[str, object] | None = None,
        timeout: float | tuple[float, float] | tuple[float, None] | None,
    ) -> dict[str, object]:
        if path == "/v1/login/GetLoginStatus":
            return {"code": 200, "data": {"loginState": 1}, "message": ""}
        original_attempts["count"] += 1
        if original_attempts["count"] < 3:
            raise WxflywheelError(-999, "timed out")
        return {"code": 200, "data": {"ok": True}, "message": ""}

    with (
        patch.object(client, "_request_json_once", side_effect=_fake_request_json_once),
        patch("wxflywheel.client.emit_progress_message") as mock_notice,
    ):
        result = client.get("/api/test")

    assert result["data"] == {"ok": True}
    assert original_attempts["count"] == 3
    mock_notice.assert_called_once()


def test_get_waits_probe_interval_before_retry_when_login_is_already_online(
    mock_resp: MockRespFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    fake_now = {"value": 0.0}
    sleep_calls: list[float] = []

    def _fake_monotonic() -> float:
        return fake_now["value"]

    def _fake_sleep(seconds: float) -> None:
        sleep_calls.append(seconds)
        fake_now["value"] += seconds

    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            requests.exceptions.Timeout("timed out"),
            mock_resp({"code": 200, "data": {"loginState": 1}, "message": ""}),
            mock_resp({"code": 200, "data": {"ok": True}, "message": ""}),
        ],
    ):
        monkeypatch.setattr(time, "monotonic", _fake_monotonic)
        monkeypatch.setattr(time, "sleep", _fake_sleep)
        result = client.get("/api/test")

    assert result["data"] == {"ok": True}
    assert sleep_calls == [5.0]


def test_get_raises_last_error_when_deadline_is_already_spent_after_recovery() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    monotonic_values = iter([0.0, 0.0, 66.0])

    def _fake_monotonic() -> float:
        return next(monotonic_values)

    with (
        patch("wxflywheel.client.time.monotonic", side_effect=_fake_monotonic),
        patch("wxflywheel.client.wait_for_recovery", return_value=True),
        patch("wxflywheel.client.emit_progress_message"),
        patch.object(
            client,
            "_request_json_once",
            side_effect=WxflywheelError(300, "DecodePackHeader err timeout, ret=-13"),
        ),
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")

    assert exc_info.value.code == 300
    assert exc_info.value.message == "DecodePackHeader err timeout, ret=-13"


def test_get_raises_auth_error_when_recovery_budget_is_gone_before_login_probe() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    monotonic_values = iter([0.0, 0.0, 66.0])

    def _fake_monotonic() -> float:
        return next(monotonic_values)

    with (
        patch("wxflywheel.client.time.monotonic", side_effect=_fake_monotonic),
        patch.object(
            client,
            "_request_json_once",
            side_effect=WxflywheelError(300, "auth failed"),
        ) as mock_request_once,
        patch.object(client, "_probe_login_online") as mock_probe,
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")

    assert exc_info.value.code == 300
    assert exc_info.value.message == "auth failed"
    mock_request_once.assert_called_once()
    mock_probe.assert_not_called()


def test_get_raises_generic_window_expired_error_when_budget_is_gone_before_first_try() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    monotonic_values = iter([0.0, 66.0])

    def _fake_monotonic() -> float:
        return next(monotonic_values)

    with (
        patch("wxflywheel.client.time.monotonic", side_effect=_fake_monotonic),
        patch.object(client, "_request_json_once") as mock_request_json_once,
        pytest.raises(WxflywheelError) as exc_info,
    ):
        client.get("/api/test")

    assert exc_info.value.code == -999
    assert "Recovery window expired" in exc_info.value.message
    mock_request_json_once.assert_not_called()


def test_probe_login_online_returns_false_when_probe_request_fails() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with patch.object(
        client, "_request_json_once", side_effect=WxflywheelError(-999, "timed out")
    ):
        assert client._probe_login_online(5.0) is False


def test_probe_login_online_returns_false_when_probe_data_is_not_dict() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with patch.object(
        client,
        "_request_json_once",
        return_value={"code": 200, "data": [], "message": ""},
    ):
        assert client._probe_login_online(5.0) is False


def test_probe_login_online_returns_false_when_login_state_is_not_numeric() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with patch.object(
        client,
        "_request_json_once",
        return_value={"code": 200, "data": {"loginState": "unknown"}, "message": ""},
    ):
        assert client._probe_login_online(5.0) is False


def test_probe_login_online_returns_false_when_login_state_is_unexpected_type() -> None:
    client = WxflywheelClient(key="test-key", host="http://localhost:8011")
    with patch.object(
        client,
        "_request_json_once",
        return_value={"code": 200, "data": {"loginState": []}, "message": ""},
    ):
        assert client._probe_login_online(5.0) is False
