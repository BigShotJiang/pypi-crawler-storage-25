from __future__ import annotations

from dataclasses import dataclass

DEFAULT_HOST = "http://localhost:8011"


@dataclass(frozen=True, slots=True)
class RuntimeContext:
    host: str
    key: str | None

    @classmethod
    def from_values(cls, *, key: str | None, host: str) -> "RuntimeContext":
        normalized_host = host.strip().rstrip("/") if host.strip() else DEFAULT_HOST
        normalized_key = key.strip() if key and key.strip() else None
        return cls(host=normalized_host, key=normalized_key)
