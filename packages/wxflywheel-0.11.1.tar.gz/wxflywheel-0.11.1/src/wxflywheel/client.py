from __future__ import annotations

import time
from typing import Any

import requests
import requests.exceptions

from wxflywheel.exceptions import NETWORK_ERROR_CODE, SUCCESS_CODE, WxflywheelError
from wxflywheel.output import emit_progress_message, success_payload
from wxflywheel.request_recovery import (
    DEFAULT_REQUEST_TIMEOUT_SECONDS,
    RECOVERY_NOTICE,
    clamp_probe_timeout,
    clamp_request_timeout,
    current_recovery_deadline,
    needs_login_probe,
    should_attempt_recovery,
    wait_for_recovery,
)

RequestTimeout = float | tuple[float, float] | tuple[float, None] | None


class WxflywheelClient:
    def __init__(self, key: str, host: str):
        self.key = key.strip()
        self.host = host.strip().rstrip("/")

    def get(self, path: str, *, allow_recovery: bool = True, **params: Any) -> dict[str, Any]:
        return self._request_json(
            "GET",
            path,
            params=params,
            timeout=DEFAULT_REQUEST_TIMEOUT_SECONDS,
            allow_recovery=allow_recovery,
        )

    def post(
        self, path: str, body: dict[str, Any], *, allow_recovery: bool = True
    ) -> dict[str, Any]:
        return self._request_json(
            "POST",
            path,
            body=body,
            timeout=DEFAULT_REQUEST_TIMEOUT_SECONDS,
            allow_recovery=allow_recovery,
        )

    def raw_get(
        self,
        path: str,
        timeout: tuple[float, float] | tuple[float, None] = (10, 300),
        **params: Any,
    ) -> requests.Response:
        return self._request("GET", path, params=params, timeout=timeout, stream=True)

    def _request_json(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        timeout: float = DEFAULT_REQUEST_TIMEOUT_SECONDS,
        allow_recovery: bool = True,
    ) -> dict[str, Any]:
        if not allow_recovery:
            return self._request_json_once(
                method,
                path,
                params=params,
                body=body,
                timeout=clamp_request_timeout(timeout, timeout),
            )

        deadline = current_recovery_deadline(time.monotonic)
        notice_emitted = False
        last_error: WxflywheelError | None = None

        while True:
            remaining = max(0.0, deadline - time.monotonic())
            if remaining <= 0:
                if last_error is not None:
                    raise last_error
                raise WxflywheelError(
                    NETWORK_ERROR_CODE,
                    "Recovery window expired before the request could be retried.",
                )
            try:
                return self._request_json_once(
                    method,
                    path,
                    params=params,
                    body=body,
                    timeout=clamp_request_timeout(remaining, timeout),
                )
            except WxflywheelError as error:
                login_online: bool | None = None
                if needs_login_probe(error):
                    probe_remaining = max(0.0, deadline - time.monotonic())
                    if probe_remaining <= 0:
                        raise error
                    login_online = self._probe_login_online(clamp_probe_timeout(probe_remaining))
                if not should_attempt_recovery(
                    error,
                    login_online=login_online,
                    request_path=path,
                ):
                    raise
                last_error = error
                if not notice_emitted:
                    emit_progress_message(RECOVERY_NOTICE)
                    notice_emitted = True
                if not wait_for_recovery(
                    deadline,
                    probe_online=self._probe_login_online,
                    monotonic=time.monotonic,
                    sleep=time.sleep,
                ):
                    raise

    def _request_json_once(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        timeout: RequestTimeout,
    ) -> dict[str, Any]:
        resp = self._request(method, path, params=params, body=body, timeout=timeout)
        return self._handle_json_response(resp)

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        timeout: RequestTimeout,
        stream: bool = False,
    ) -> requests.Response:
        try:
            return requests.request(
                method,
                f"{self.host}{path}",
                params={"key": self.key, **(params or {})},
                json=body,
                timeout=timeout,
                stream=stream,
            )
        except requests.exceptions.RequestException as exc:
            raise WxflywheelError(NETWORK_ERROR_CODE, str(exc)) from exc

    def _probe_login_online(self, timeout: float) -> bool:
        try:
            payload = self._request_json_once(
                "GET",
                "/v1/login/GetLoginStatus",
                params={"autoLogin": "false"},
                timeout=timeout,
            )
        except WxflywheelError:
            return False

        data = payload.get("data")
        if not isinstance(data, dict):
            return False

        raw_state = data.get("loginState")
        if isinstance(raw_state, (int, float, str)):
            try:
                return int(raw_state) == 1
            except ValueError:
                return False
        return False

    def _handle_json_response(self, resp: requests.Response) -> dict[str, Any]:
        try:
            data = resp.json()
        except ValueError as exc:
            raise WxflywheelError(
                NETWORK_ERROR_CODE,
                f"Response is not JSON (HTTP {resp.status_code}): {resp.text[:200]}",
            ) from exc

        if not isinstance(data, dict):
            raise WxflywheelError(
                NETWORK_ERROR_CODE,
                f"Response is not a JSON object (HTTP {resp.status_code}): {resp.text[:200]}",
            )

        code = self._extract_code(data)
        payload_data = data["data"] if "data" in data else data.get("Data")
        message = self._extract_message(data)

        if code != SUCCESS_CODE:
            raise WxflywheelError(code, message, payload_data)

        return success_payload(payload_data, message)

    @staticmethod
    def _extract_code(data: dict[str, Any]) -> int:
        raw_code = data["code"] if "code" in data else data.get("Code")
        if raw_code is None:
            raise WxflywheelError(
                NETWORK_ERROR_CODE,
                f"Response is missing code/Code field: {data}",
            )
        try:
            return int(float(raw_code))
        except (TypeError, ValueError) as exc:
            raise WxflywheelError(
                NETWORK_ERROR_CODE,
                f"Response code is not numeric: {raw_code!r}",
            ) from exc

    @staticmethod
    def _extract_message(data: dict[str, Any]) -> str:
        raw_message = data["message"] if "message" in data else data.get("Text")
        if isinstance(raw_message, str):
            return raw_message
        if raw_message is None:
            return ""
        return str(raw_message)
