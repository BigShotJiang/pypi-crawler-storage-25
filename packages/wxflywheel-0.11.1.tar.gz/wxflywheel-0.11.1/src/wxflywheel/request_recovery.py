from __future__ import annotations

import time
from collections.abc import Callable
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Iterator

from wxflywheel.exceptions import WxflywheelError

DEFAULT_REQUEST_TIMEOUT_SECONDS = 60.0
# Recovery window 比单次 timeout 大 5s 作为缓冲：recovery_scope 记录 deadline
# 时调了一次 time.monotonic()，首次请求读 remaining 时又调一次，中间 ε 时钟推进
# 会让 remaining = WINDOW - ε。若 WINDOW == DEFAULT_TIMEOUT，clamp 会返回
# DEFAULT_TIMEOUT-ε 削减首次请求超时；留 5s 缓冲保证首次请求始终拿到完整 60s timeout。
RECOVERY_WINDOW_SECONDS = 65.0
PROBE_INTERVAL_SECONDS = 5.0
PROBE_TIMEOUT_SECONDS = 5.0
RECOVERY_NOTICE = "线路在恢复，正在等待账号重新在线后重试（最长65秒）。"

_RECOVERABLE_TEXT_SNIPPETS = (
    "timeout",
    "timed out",
    "ret=-13",
)

_LOGIN_PROBE_TEXT_SNIPPETS = (
    "auth failed",
    "weapplogin",
    "jslogin",
    "获取凭证失败",
)

_ONLINE_AUTH_RECOVERY_PATH_PREFIXES = ("/api/wxindex",)
_ACTIVE_RECOVERY_DEADLINE: ContextVar[float | None] = ContextVar(
    "wxflywheel_active_recovery_deadline",
    default=None,
)


def build_recovery_deadline(monotonic: Callable[[], float] = time.monotonic) -> float:
    return monotonic() + RECOVERY_WINDOW_SECONDS


def remaining_seconds(
    deadline: float, monotonic: Callable[[], float] = time.monotonic
) -> float:
    return max(0.0, deadline - monotonic())


def clamp_request_timeout(
    remaining: float, default_timeout: float = DEFAULT_REQUEST_TIMEOUT_SECONDS
) -> float:
    if remaining >= default_timeout:
        return default_timeout
    return max(0.1, remaining)


def clamp_probe_timeout(remaining: float) -> float:
    return max(0.1, min(PROBE_TIMEOUT_SECONDS, remaining))


def needs_login_probe(error: WxflywheelError) -> bool:
    message = error.message.lower()
    return any(snippet in message for snippet in _LOGIN_PROBE_TEXT_SNIPPETS)


def should_attempt_recovery(
    error: WxflywheelError,
    *,
    login_online: bool | None = None,
    request_path: str = "",
) -> bool:
    message = error.message.lower()
    if any(snippet in message for snippet in _RECOVERABLE_TEXT_SNIPPETS):
        return True
    if any(snippet in message for snippet in _LOGIN_PROBE_TEXT_SNIPPETS):
        if any(request_path.startswith(prefix) for prefix in _ONLINE_AUTH_RECOVERY_PATH_PREFIXES):
            return True
        return login_online is False
    return False


def wait_for_recovery(
    deadline: float,
    *,
    probe_online: Callable[[float], bool],
    monotonic: Callable[[], float] = time.monotonic,
    sleep: Callable[[float], None] = time.sleep,
) -> bool:
    while True:
        remaining = remaining_seconds(deadline, monotonic)
        if remaining <= 0:
            return False
        sleep(min(PROBE_INTERVAL_SECONDS, remaining))
        remaining = remaining_seconds(deadline, monotonic)
        if remaining <= 0:
            return False
        if probe_online(clamp_probe_timeout(remaining)):
            return True


@contextmanager
def recovery_scope(monotonic: Callable[[], float] | None = None) -> Iterator[float]:
    """Share one recovery deadline across all backend calls in one command."""
    current_deadline = _ACTIVE_RECOVERY_DEADLINE.get()
    if current_deadline is not None:
        yield current_deadline
        return

    active_monotonic = monotonic or time.monotonic
    deadline = build_recovery_deadline(active_monotonic)
    token = _ACTIVE_RECOVERY_DEADLINE.set(deadline)
    try:
        yield deadline
    finally:
        _ACTIVE_RECOVERY_DEADLINE.reset(token)


def current_recovery_deadline(monotonic: Callable[[], float] | None = None) -> float:
    current_deadline = _ACTIVE_RECOVERY_DEADLINE.get()
    if current_deadline is not None:
        return current_deadline
    active_monotonic = monotonic or time.monotonic
    return build_recovery_deadline(active_monotonic)
