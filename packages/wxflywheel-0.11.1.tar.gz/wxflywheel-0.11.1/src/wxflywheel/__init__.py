"""wxflywheel CLI package."""

__version__ = "0.11.1"
