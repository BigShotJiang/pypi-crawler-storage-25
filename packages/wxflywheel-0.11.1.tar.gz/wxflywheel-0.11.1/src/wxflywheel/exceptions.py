from __future__ import annotations

from dataclasses import dataclass
from typing import Any

SUCCESS_CODE = 200
MISSING_KEY_CODE = -1
NETWORK_ERROR_CODE = -999
MISSING_KEY_MESSAGE = "Missing API key: set WXFLYWHEEL_KEY or pass --key."


@dataclass(slots=True)
class WxflywheelError(Exception):
    code: int
    message: str
    data: Any = None

    def __post_init__(self) -> None:
        Exception.__init__(self, self.message)


class MissingKeyError(WxflywheelError):
    def __init__(self) -> None:
        super().__init__(MISSING_KEY_CODE, MISSING_KEY_MESSAGE)
