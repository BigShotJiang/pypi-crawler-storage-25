"""Background worker that refreshes the version check cache.

Invoked by ``wxflywheel.version_check.try_trigger_background_refresh`` as::

    python -m wxflywheel._version_check_worker

The worker makes a single PyPI JSON API call to fetch the latest version,
upload time, and long_description (README + CHANGELOG spliced together at
release time by the ``wxflywheel-release.yml`` workflow). It then parses the
embedded CHANGELOG locally to detect BREAKING markers for the target version,
writes the result to ``~/.cache/wxflywheel/version_check.json`` and exits.
Zero GitHub requests — all information comes from the single PyPI response.
The worker runs in a detached subprocess so the main CLI command is never
blocked on network I/O.

The worker sets the ``WXFLYWHEEL_WORKER=1`` environment variable before
importing the version_check module so that any code path inside it can detect
worker mode and skip re-spawning another worker (preventing infinite fork
loops).
"""

from __future__ import annotations

import os
import sys


def main() -> int:
    """Refresh cache from PyPI and return exit code (0=success, 1=failure).

    Any exception is caught and downgraded to exit code 1 so the worker never
    leaves a traceback on the parent's stderr (which is DEVNULL anyway, but
    still defensive)."""
    os.environ["WXFLYWHEEL_WORKER"] = "1"

    try:
        # Import after setting env var so module init sees worker mode
        from wxflywheel.version_check import refresh_cache_from_pypi

        ok = refresh_cache_from_pypi(timeout=5.0)
        return 0 if ok else 1
    except Exception:
        return 1


if __name__ == "__main__":
    sys.exit(main())
