from __future__ import annotations

import base64
import json
import re
from datetime import datetime
from html import unescape
from typing import Any, Sequence
from urllib.parse import unquote

import click
from click.core import ParameterSource

from wxflywheel.commands.common import require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.exceptions import NETWORK_ERROR_CODE, WxflywheelError
from wxflywheel.output import JsonObject, json_command, success_payload

ARTICLE_SEARCH_PATH = "/v1/Finder/WebSearch"
ARTICLE_DETAIL_V2_PATH = "/v1/Gh/ArticleDetailV2"
STICKER_DETAIL_PATH = "/v1/Gh/StickerDetail"
VIDEO_DETAIL_PATH = "/v1/Finder/VideoDetailV2"
ARTICLE_BUSINESS_TYPE = 2
ARTICLE_SCENE = 101
CURSOR_VERSION = 1
DEFAULT_SORT = "default"
NEWEST_SORT = "newest"
HOT_SORT = "hot"
SORT_CHOICES = (DEFAULT_SORT, NEWEST_SORT, HOT_SORT)

STICKER_BUSINESS_TYPE = 33562628
STICKER_SCENE = 101
STICKER_CURSOR_VERSION = 1
DEFAULT_TAB = "all"
STICKER_TAB_CHOICES = ("all", "newest", "hottest")
VIDEO_BUSINESS_TYPE = 7
VIDEO_SCENE = 101
VIDEO_OUTER_GROUP_TYPE = 107
VIDEO_SUBBOX_TYPE = 84
VIDEO_CURSOR_VERSION = 1
VIDEO_DEFAULT_TAB = "default"
VIDEO_NEWEST_TAB = "newest"
VIDEO_TAB_CHOICES = (VIDEO_DEFAULT_TAB, VIDEO_NEWEST_TAB)

# Maps --tab names to the ExtReqParams {Key, TextValue} sent to WebSearch.
# "all" uses docSuperType=0 (default relevance), "newest"/"hottest" use
# docSortType for sort order (Frida-verified 2026-04-09).
STICKER_TAB_PARAMS: dict[str, tuple[str, str]] = {
    "all":     ("docSuperType", "0"),
    "newest":  ("docSortType", "2"),
    "hottest": ("docSortType", "4"),
}

HIGHLIGHT_TAG_RE = re.compile(r"</?em\b[^>]*>")
READ_COUNT_RE = re.compile(r"(?:^|&)show_tag=R_2_1_(\d+)(?:&|$)")


@click.group()
def search() -> None:
    """WeChat Search (微信搜一搜) — the in-app WeChat search engine that indexes official-account articles, videos, mini-programs and more. These commands cover seven search intents: search-suggestion related keywords (`search related`), normalized official-account article result lists (`search article`), normalized video result lists (`search video`), normalized sticker (贴图) result lists (`search sticker`), single official-account article detail retrieval (`search article-detail`), single sticker detail retrieval (`search sticker-detail`), and single Finder video detail retrieval (`search video-detail`)."""


@search.command()
@click.option("--seed", required=True, help="Seed keyword.")
@click.pass_obj
@json_command
def related(runtime: RuntimeContext, seed: str) -> JsonObject:
    """Get long-tail user-query related keywords for a seed term from WeChat Search (e.g. seed='咖啡' → ['附近咖啡店', '星巴克咖啡', '中国咖啡十大品牌']). These are phrase-level actual user queries from WeChat Search's suggestion aggregator, NOT short word associations — for short word-level terms use 'wxflywheel wxindex related' instead. Requires the WeChat account (identified by --key) to be online. Returns {seed, related[]}."""
    client = require_client(runtime)
    payload = client.post("/v1/Finder/RelatedKeywords", body={"KeyWord": seed})
    words = payload["data"]["words"]
    return success_payload({"seed": seed, "related": words}, payload["message"])


@search.command()
@click.option(
    "--url",
    "article_url",
    required=True,
    help="Full WeChat official-account article URL. Prefer the exact url returned by 'wxflywheel search article' so query parameters like chksm stay intact.",
)
@click.pass_obj
@json_command
def article_detail(runtime: RuntimeContext, article_url: str) -> JsonObject:
    """Fetch one WeChat official-account article detail page as a single Agent-facing payload: article info, full body HTML, six engagement metrics, and selected comments. This command wraps the backend's new ArticleDetailV2 aggregation endpoint, so the CLI caller does NOT manually chain 'BatchGetAppMsg + AppMsgCommentList'. Returns {article, metrics, comments, comments_error?}. The comments block is explicitly selected comments, not all raw comments."""
    client = require_client(runtime)
    payload = client.get(ARTICLE_DETAIL_V2_PATH, url=article_url)
    detail = _build_article_detail_output(payload["data"])
    return success_payload(detail, payload["message"])


@search.command()
@click.option(
    "--url",
    "sticker_url",
    required=True,
    help=(
        "Full WeChat sticker article URL (贴图 URL). Use the exact url returned by "
        "'wxflywheel search article' or the docUrl field from StickerSearchWithDetails "
        "results. Stickers are photo-essay posts (item_show_type=8) on official accounts, "
        "similar to Xiaohongshu image-text notes — they carry an image gallery instead of "
        "a long-form HTML body."
    ),
)
@click.pass_obj
@json_command
def sticker_detail(runtime: RuntimeContext, sticker_url: str) -> JsonObject:
    """Fetch one WeChat official-account sticker (贴图) detail page — a photo-essay post (类似小红书图文) whose primary content is an image gallery plus short body text, NOT a long-form HTML article. Use `search article-detail` for long-form articles; use this command for sticker/photo-essay posts (item_show_type=8, page_type=2). This command wraps the backend's StickerDetail aggregation endpoint which internally calls BatchGetAppMsg(CGI 2594) + AppMsgCommentList(CGI 25246). The returned fields are 100% aligned with the web management console's sticker detail drawer: sticker_info (title, account, location, date, originality), pictures (image gallery with dimensions and QR detection), engagement_metrics (read/like/watching/share/collect/comment counts), text_content, hashtags, topics (with read counts and article counts), monetization (tipping/ads/product window/paid subscription), and selected comments with threaded replies. Returns {sticker_info, pictures, engagement_metrics, text_content, hashtags, topics, monetization, comments, comments_error?}."""
    client = require_client(runtime)
    payload = client.get(STICKER_DETAIL_PATH, url=sticker_url)
    detail = _build_sticker_detail_output(payload["data"])
    return success_payload(detail, payload["message"])


@search.command()
@click.option(
    "--keyword",
    default=None,
    help="Keyword for a new article-list search.",
)
@click.option(
    "--cursor",
    default=None,
    help="Opaque next-page cursor returned by a previous 'wxflywheel search article' response.",
)
@click.option(
    "--sort",
    "sort_name",
    type=click.Choice(SORT_CHOICES, case_sensitive=False),
    default=DEFAULT_SORT,
    show_default=True,
    help="Article list order. Use only with --keyword.",
)
@click.pass_obj
@json_command
def article(
    runtime: RuntimeContext,
    keyword: str | None,
    cursor: str | None,
    sort_name: str,
) -> JsonObject:
    """Search WeChat Search official-account article results and return a normalized article list, NOT article bodies, comments or engagement-detail pages. Use --keyword to start a new search and choose one of the three live-verified list orders (`default`, `newest`, `hot`); use --cursor to fetch the next page of a previous result set without manually handling offset, search_id or cookies. Returns {keyword, sort, has_more, next_cursor?, items[]} where each item keeps only article_id/title/summary/source_name/published_at_ts/url/cover_url plus read_count/read_count_text when the live response actually includes reading-hotness metadata."""
    ctx = click.get_current_context()
    sort_source = ctx.get_parameter_source("sort_name")
    if (keyword is None) == (cursor is None):
        raise click.UsageError(
            "Provide exactly one of --keyword or --cursor. Use --keyword to start a new article search and --cursor to fetch the next page of a previous article result set."
        )
    if cursor is not None and sort_source != ParameterSource.DEFAULT:
        raise click.UsageError(
            "Do not pass --sort together with --cursor. The cursor already contains the original article-search order."
        )

    if cursor is not None:
        cursor_payload = _decode_cursor(cursor)
        request_keyword = cursor_payload["keyword"]
        request_sort = cursor_payload["sort"]
        body = _build_article_search_body(
            keyword=request_keyword,
            sort_name=request_sort,
            offset=cursor_payload["offset"],
            search_id=cursor_payload["search_id"],
            cookies=cursor_payload.get("cookies"),
        )
    else:
        request_keyword = keyword if keyword is not None else ""
        request_sort = sort_name
        body = _build_article_search_body(
            keyword=request_keyword,
            sort_name=request_sort,
            offset=0,
            search_id="",
            cookies=None,
        )

    client = require_client(runtime)
    payload = client.post(ARTICLE_SEARCH_PATH, body=body)
    article_data = _build_article_output(payload["data"], keyword=request_keyword, sort_name=request_sort)
    return success_payload(article_data, payload["message"])


@search.command()
@click.option(
    "--keyword",
    default=None,
    help="Keyword for a new sticker-list search.",
)
@click.option(
    "--cursor",
    default=None,
    help="Opaque next-page cursor returned by a previous 'wxflywheel search sticker' response.",
)
@click.option(
    "--tab",
    "tab_name",
    type=click.Choice(STICKER_TAB_CHOICES, case_sensitive=False),
    default=DEFAULT_TAB,
    show_default=True,
    help="Sticker sub-tab filter. 'all' = default relevance, 'newest' = most recent, 'hottest' = most engagement. Use only with --keyword, not --cursor.",
)
@click.pass_obj
@json_command
def sticker(
    runtime: RuntimeContext,
    keyword: str | None,
    cursor: str | None,
    tab_name: str,
) -> JsonObject:
    """Search WeChat Search sticker results (搜一搜贴图, similar to Xiaohongshu-style image posts) and return a normalized sticker list. Stickers are image-centric content (item_show_type=8) from official accounts — NOT emoji/GIF stickers. Use --keyword to start a new search and --tab to select sorting (all/newest/hottest); use --cursor to fetch the next page. Returns {keyword, tab, has_more, next_cursor?, items[]} where each item has 16 fields: sticker_id, title, source_name, source_icon_url, published_at_ts, published_relative, cover_url, sticker_url, content_type_code, mp_doc_id, rank, report_id, display_style, source_type, social_tags, hide_control."""
    ctx = click.get_current_context()
    tab_source = ctx.get_parameter_source("tab_name")
    if (keyword is None) == (cursor is None):
        raise click.UsageError(
            "Provide exactly one of --keyword or --cursor. Use --keyword to start a new sticker search and --cursor to fetch the next page of a previous sticker result set."
        )
    if cursor is not None and tab_source != ParameterSource.DEFAULT:
        raise click.UsageError(
            "Do not pass --tab together with --cursor. The cursor already contains the original sticker-search tab."
        )

    if cursor is not None:
        cursor_payload = _decode_sticker_cursor(cursor)
        request_keyword = cursor_payload["keyword"]
        request_tab = cursor_payload["tab"]
        body = _build_sticker_search_body(
            keyword=request_keyword,
            tab_name=request_tab,
            offset=cursor_payload["offset"],
            search_id=cursor_payload["search_id"],
            cookies=cursor_payload.get("cookies"),
        )
    else:
        request_keyword = keyword if keyword is not None else ""
        request_tab = tab_name
        body = _build_sticker_search_body(
            keyword=request_keyword,
            tab_name=request_tab,
            offset=0,
            search_id="",
            cookies=None,
        )

    client = require_client(runtime)
    payload = client.post(ARTICLE_SEARCH_PATH, body=body)
    sticker_data = _build_sticker_output(payload["data"], keyword=request_keyword, tab_name=request_tab)
    return success_payload(sticker_data, payload["message"])


@search.command("video")
@click.option(
    "--keyword",
    default=None,
    help="Keyword for a new video-list search. Use this to start a fresh search; combine with --tab to pick the sub-tab.",
)
@click.option(
    "--cursor",
    default=None,
    help="Opaque next-page cursor returned by a previous 'wxflywheel search video' response. Pass it verbatim; do not decode or modify. Cursors from other commands ('search article', 'search sticker') or older CLI versions will be rejected.",
)
@click.option(
    "--tab",
    "tab_name",
    type=click.Choice(VIDEO_TAB_CHOICES, case_sensitive=False),
    default=VIDEO_DEFAULT_TAB,
    show_default=True,
    help="Video list sub-tab filter. 'default' = 不限 (WeChat's default relevance ranking, no server-side filter), 'newest' = 最新 (FinderTabAdvanceSearch=[\"2\"], chronological newest first). Use only with --keyword — the cursor already encodes the original tab.",
)
@click.pass_obj
@json_command
def video(
    runtime: RuntimeContext,
    keyword: str | None,
    cursor: str | None,
    tab_name: str,
) -> JsonObject:
    """Search WeChat Search (搜一搜) video results and return a normalized video
list, NOT video playback streams, creator profiles, comments, or engagement
detail pages. Videos here are WeChat's in-app video posts (including
livestreams) surfaced by the WeChat Search video tab — item_show_type varies,
underlying source is a mix of 视频号 (Finder) content and livestream feeds.
This command wraps the backend's POST /v1/Finder/WebSearch endpoint with
BusinessType=7 and Scene=101, exactly matching the web admin console's video
search behavior (see web/ui/src/config/searchConfig.ts and VideoCard.tsx).

Use --keyword to start a new search and --tab to select the sub-tab:
  - 'default' (不限): WeChat's default relevance ranking (no ExtReqParams).
  - 'newest' (最新): chronological by publish time, newest first
    (FinderTabAdvanceSearch=[\"2\"]).

Use --cursor to fetch the next page of a previous result set without
manually handling offset, search_id, or cookies — the cursor is opaque and
carries everything needed. The cursor is stable across invocations within
the same CLI version; a cursor from an older version will be rejected.

Returns {keyword, tab, has_more, next_cursor?, items[]}. Each item keeps 12
Agent-facing fields: video_id (stable docID string), export_id (needed for
future detail lookup, may be empty for livestream-only items), hash_doc_id
(hashDocID string, stringized), title (highlight tags stripped),
cover_url (image), account_name / account_icon_url (from source.title /
source.iconUrl), duration_text (duration, e.g. "02:56"), published_at_text
(e.g. "31分钟前"), published_at_ts (unix timestamp, int), show_type (int
coerced from showType), and interaction_metrics (a fixed-shape object
{like_count, comment_count, forward_count, thumb_count} parsed from
item.report_extinfo_str, where each value is int or null — null distinguishes
"metric not reported" from literal 0).

If `published_at_ts` is missing or non-numeric in a video item, parsing fails
with `WxflywheelError` and the command returns an error. This keeps video
output aligned with the live BT=7 contract in this release.

has_more follows the same authority signal as the web admin console
(SearchPage.tsx line 228) and `search article`/`search sticker`: True only
when the backend returns `continueFlag == 1` AND the current page has at
least one video item. When the backend sets `noMoreData` (either at the
outer envelope or inner payload level), the command short-circuits to
`{has_more: False, items: []}` without raising — this matches the front-end
`search.ts` handling. Pagination note: WeChat's offset increments are
non-uniform (~9-10 per page, server-dictated); trust next_cursor instead of
computing offsets.

Requires the WeChat account (identified by --key) to be online.
"""
    ctx = click.get_current_context()
    tab_source = ctx.get_parameter_source("tab_name")
    if (keyword is None) == (cursor is None):
        raise click.UsageError(
            "Provide exactly one of --keyword or --cursor. Use --keyword to start a new video search and --cursor to fetch the next page of a previous video result set."
        )
    if cursor is not None and tab_source != ParameterSource.DEFAULT:
        raise click.UsageError(
            "Do not pass --tab together with --cursor. The cursor already contains the original video-search tab."
        )

    if cursor is not None:
        cursor_payload = _decode_video_cursor(cursor)
        request_keyword = cursor_payload["keyword"]
        request_tab = cursor_payload["tab"]
        body = _build_video_search_body(
            keyword=request_keyword,
            tab_name=request_tab,
            offset=cursor_payload["offset"],
            search_id=cursor_payload["search_id"],
            cookies=cursor_payload.get("cookies"),
        )
    else:
        request_keyword = keyword if keyword is not None else ""
        request_tab = tab_name
        body = _build_video_search_body(
            keyword=request_keyword,
            tab_name=request_tab,
            offset=0,
            search_id="",
            cookies=None,
        )

    client = require_client(runtime)
    payload = client.post(ARTICLE_SEARCH_PATH, body=body)
    video_data = _build_video_output(payload["data"], keyword=request_keyword, tab_name=request_tab)
    return success_payload(video_data, payload["message"])


def _build_article_search_body(
    *, keyword: str, sort_name: str, offset: int, search_id: str, cookies: str | None
) -> JsonObject:
    body: JsonObject = {
        "KeyWord": keyword,
        "Offset": offset,
        "BusinessType": ARTICLE_BUSINESS_TYPE,
        "Scene": ARTICLE_SCENE,
        "SearchId": search_id,
    }
    ext_req_params = _build_article_ext_req_params(sort_name=sort_name, cookies=cookies)
    if ext_req_params:
        body["ExtReqParams"] = ext_req_params
    return body


def _build_video_search_body(
    *, keyword: str, tab_name: str, offset: int, search_id: str, cookies: str | None
) -> JsonObject:
    body: JsonObject = {
        "KeyWord": keyword,
        "Offset": offset,
        "BusinessType": VIDEO_BUSINESS_TYPE,
        "Scene": VIDEO_SCENE,
        "SearchId": search_id,
    }
    ext_req_params = _build_video_ext_req_params(tab_name=tab_name, cookies=cookies)
    if ext_req_params:
        body["ExtReqParams"] = ext_req_params
    return body


def _build_video_ext_req_params(*, tab_name: str, cookies: str | None) -> list[JsonObject]:
    params: list[JsonObject] = []
    if tab_name == VIDEO_NEWEST_TAB:
        params.append({"Key": "FinderTabAdvanceSearch", "TextValue": '["2"]'})

    if isinstance(cookies, str) and cookies:
        params.append({"Key": "cookies", "TextValue": cookies})
    return params


def _build_video_output(payload_data: Any, *, keyword: str, tab_name: str) -> JsonObject:
    outer_data = _require_dict(payload_data, field_name="WebSearch outer data")

    if outer_data.get("noMoreData"):
        return {
            "keyword": keyword,
            "tab": tab_name,
            "has_more": False,
            "items": [],
        }

    raw_inner_json = outer_data.get("json")
    if not isinstance(raw_inner_json, str) or not raw_inner_json.strip():
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch video returned success but data.json is missing or empty, so the video result list cannot be parsed. The backend contract may have changed — verify /v1/Finder/WebSearch is still returning the expected envelope.",
        )

    try:
        inner_payload = json.loads(raw_inner_json)
    except ValueError as exc:
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch returned success but data.json is not valid JSON, so the video result list cannot be parsed.",
        ) from exc

    inner_data = _require_dict(inner_payload, field_name="WebSearch inner data")

    if inner_data.get("noMoreData"):
        return {
            "keyword": keyword,
            "tab": tab_name,
            "has_more": False,
            "items": [],
        }

    raw_groups = inner_data.get("data")
    if not isinstance(raw_groups, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch video payload is missing the inner data[] groups, so the video result list cannot be parsed.",
        )

    video_items = _collect_video_items(raw_groups)
    if not video_items:
        return {
            "keyword": keyword,
            "tab": tab_name,
            "has_more": False,
            "items": [],
        }

    items = _normalize_video_items(video_items)
    if not items:
        return {
            "keyword": keyword,
            "tab": tab_name,
            "has_more": False,
            "items": [],
        }

    has_more = _coerce_intlike(inner_data.get("continueFlag"), field_name="continueFlag") == 1

    result: JsonObject = {
        "keyword": keyword,
        "tab": tab_name,
        "has_more": has_more,
        "items": items,
    }
    if has_more:
        result["next_cursor"] = _encode_video_cursor(
            {
                "v": VIDEO_CURSOR_VERSION,
                "keyword": keyword,
                "tab": tab_name,
                "offset": _coerce_intlike(inner_data.get("offset"), field_name="offset"),
                "search_id": _require_string(inner_data.get("searchID"), field_name="searchID"),
                "cookies": inner_data.get("cookies"),
            }
        )
    return result


@search.command("video-detail")
@click.option(
    "--export-id",
    "export_id",
    required=True,
    help=(
        "Video's exportId from 'wxflywheel search video' result (item's `export_id` field). "
        "Must be non-empty and match an existing Finder video accessible by this --key. "
        "Required."
    ),
)
@click.option(
    "--hash-doc-id",
    "hash_doc_id",
    required=True,
    help=(
        "Video's hashDocId from 'wxflywheel search video' result (item's `hash_doc_id` field, "
        "where the CLI uses snake_case). Note: the underlying WeChat protocol parameter "
        "is hashDocId with a LOWERCASE 'd' at the end — this CLI flag maps to it directly. "
        "Required."
    ),
)
@click.pass_obj
@json_command
def video_detail(runtime: RuntimeContext, export_id: str, hash_doc_id: str) -> JsonObject:
    """Fetch one WeChat 视频号 (Finder) video detail page as a single Agent-facing
payload: video metadata, creator info, six engagement metrics, flattened comment tree
(with nested replies expanded), AND a ready-to-execute `agent_download_instructions`
string that teaches an AI Agent how to download and decrypt the video using the
`wxipad-video` Python package. This command wraps the backend's
GET /v1/Finder/VideoDetailV2 aggregation endpoint, which internally chains
GetCommentDetail pagination (up to 10 pages) + nested-reply expansion — the CLI
caller does NOT manually handle pagination.

Use --export-id and --hash-doc-id from a prior `wxflywheel search video` response
(each item carries `export_id` and `hash_doc_id` fields). Note that WeChat's protocol
parameter is `hashDocId` with a LOWERCASE 'd' at the end, and the CLI flag
`--hash-doc-id` maps to it exactly.

Returns {video, author, metrics, media, comments, agent_download_instructions?}
with the following guarantees:

- `video.title` comes from the backend `videoInfo.description` (the creator-authored
  description text), NOT from the WebSearch result item's title preview. This is more
  authoritative for Agent context.
- `video.published_at_ts` is a unix int timestamp. No relative-time string
  ("3 minutes ago") is generated — Agents should compute their own locale-appropriate
  display.
- `metrics.thumb_count` is ALWAYS null: the VideoDetailV2 backend does not return
  collect/favorite counts. If the Agent needs thumb_count, read it from the same
  video's `search video` result `interaction_metrics.thumb_count` field (collected
  at list-page time via report_extinfo_str).
- `media.full_video_url` + `media.decode_key` are the raw ISAAC64-encrypted CDN URL
  and the decryption key (first 128KB encrypted). They cannot be played directly —
  the video must be downloaded and decrypted with the `wxipad-video` Python package
  (see `agent_download_instructions`).
- `agent_download_instructions` is a string that is BYTE-FOR-BYTE identical to the
  string generated by the admin web console's `VideoDetailDrawer` component when
  the user clicks "复制下载指令" (Copy Download Command). This field is ONLY present
  when `media.full_video_url` is non-empty; when the video has been removed / taken
  down, this field is absent from the JSON response entirely (not set to null).
  Agents should read this string literally and execute it — do not reformat it.
- `comments.items[]` contains the full flattened comment tree with nested replies.
  Each comment has `published_at_text` in the format "YYYY/MM/DD HH:MM" (aligned
  with the web console's JS `formatTime` helper, which uses zh-CN locale
  `toLocaleString`). Comments with `createtime=0` have `published_at_text=""`.
- `comments.total_count` is the server-declared total; `comments.returned_count`
  is the actual number of items in the response (may exceed total_count because
  nested replies are flattened into the top-level items count).

Requires the WeChat account (identified by --key) to be online. The WeChat account
must have the video in its recommendation pool or recent browse history for the
video to be accessible via its exportId.
"""
    client = require_client(runtime)
    payload = client.get(VIDEO_DETAIL_PATH, exportId=export_id, hashDocId=hash_doc_id)
    detail = _build_video_detail_output(payload["data"])
    return success_payload(detail, payload["message"])


def _build_video_detail_output(payload_data: Any) -> JsonObject:
    data = _require_dict(payload_data, field_name="VideoDetailV2 data")

    export_id = data.get("exportId")
    hash_doc_id = data.get("hashDocId")
    video_info = data.get("videoInfo")

    video = _build_video_detail_video_section(video_info, export_id, hash_doc_id)
    author = _build_video_detail_author_section(video_info)
    metrics = _build_video_detail_metrics_section(video_info)
    media, full_video_url, decode_key = _build_video_detail_media_section(video_info)

    comments = _build_video_detail_comments_section(
        data.get("comments"),
        _coerce_intlike(data.get("commentCount"), field_name="VideoDetailV2 commentCount"),
    )

    output: JsonObject = {
        "video": video,
        "author": author,
        "metrics": metrics,
        "media": media,
        "comments": comments,
    }

    if full_video_url:
        output["agent_download_instructions"] = _build_video_download_instructions(
            full_video_url=full_video_url,
            decode_key=decode_key,
        )
    return output


def _build_video_detail_video_section(
    video_info: Any, export_id: str | None, hash_doc_id: str | None
) -> JsonObject:
    if not isinstance(video_info, dict) or not video_info:
        return {
            "video_id": "",
            "export_id": _require_string(export_id, field_name="video.export_id", allow_empty=True),
            "hash_doc_id": _require_string(hash_doc_id, field_name="video.hash_doc_id", allow_empty=True),
            "title": "",
            "cover_url": "",
            "width": 0,
            "height": 0,
            "duration_seconds": 0,
            "published_at_ts": 0,
        }

    media = video_info.get("media")
    media_item = media[0] if isinstance(media, list) and media else {}

    return {
        "video_id": _require_string(video_info.get("id"), field_name="VideoDetailV2 videoInfo.id", allow_empty=True),
        "export_id": _require_string(export_id, field_name="VideoDetailV2 exportId", allow_empty=False),
        "hash_doc_id": _require_string(hash_doc_id, field_name="VideoDetailV2 hashDocId", allow_empty=False),
        "title": _clean_highlight_text(
            _require_string(
                video_info.get("description"),
                field_name="VideoDetailV2 videoInfo.description",
                allow_empty=True,
            )
        ),
        "cover_url": _require_string(
            media_item.get("fullThumbUrl"),
            field_name="VideoDetailV2 videoInfo.media[0].fullThumbUrl",
            allow_empty=True,
        ),
        "width": _try_coerce_intlike(media_item.get("width")) or 0,
        "height": _try_coerce_intlike(media_item.get("height")) or 0,
        "duration_seconds": _try_coerce_intlike(media_item.get("videoPlayLen")) or 0,
        "published_at_ts": _coerce_intlike(
            video_info.get("createtime"), field_name="VideoDetailV2 videoInfo.createtime"
        ),
    }


def _build_video_detail_author_section(video_info: Any) -> JsonObject:
    if not isinstance(video_info, dict) or not video_info:
        return {
            "nickname": "",
            "head_url": "",
            "username": "",
            "signature": "",
        }

    contact = video_info.get("contact")
    if not isinstance(contact, dict):
        contact = {}

    return {
        "nickname": _require_string(contact.get("nickname"), field_name="VideoDetailV2 videoInfo.contact.nickname", allow_empty=True),
        "head_url": _require_string(contact.get("headUrl"), field_name="VideoDetailV2 videoInfo.contact.headUrl", allow_empty=True),
        "username": _require_string(contact.get("username"), field_name="VideoDetailV2 videoInfo.contact.username", allow_empty=True),
        "signature": _require_string(contact.get("signature"), field_name="VideoDetailV2 videoInfo.contact.signature", allow_empty=True),
    }


def _build_video_detail_metrics_section(video_info: Any) -> JsonObject:
    if not isinstance(video_info, dict) or not video_info:
        return {
            "like_count": 0,
            "comment_count": 0,
            "forward_count": 0,
            "friend_like_count": 0,
            "thumb_count": None,
        }

    return {
        "like_count": _coerce_intlike(video_info.get("likeCount"), field_name="VideoDetailV2 videoInfo.likeCount"),
        "comment_count": _coerce_intlike(video_info.get("commentCount"), field_name="VideoDetailV2 videoInfo.commentCount"),
        "forward_count": _coerce_intlike(video_info.get("forwardCount"), field_name="VideoDetailV2 videoInfo.forwardCount"),
        "friend_like_count": _coerce_intlike(
            video_info.get("friendLikeCount"),
            field_name="VideoDetailV2 videoInfo.friendLikeCount",
        ),
        "thumb_count": None,
    }


def _build_video_detail_media_section(video_info: Any) -> tuple[JsonObject, str, str]:
    if not isinstance(video_info, dict) or not video_info:
        return {"full_video_url": "", "decode_key": "0"}, "", "0"

    media = video_info.get("media")
    if not isinstance(media, list) or not media:
        return {"full_video_url": "", "decode_key": "0"}, "", "0"

    first_media = media[0] if isinstance(media[0], dict) else {}
    decode_key = first_media.get("decodeKey", "0")
    if not isinstance(decode_key, str):
        decode_key = str(decode_key)
    full_video_url = _require_string(
        first_media.get("fullVideoUrl"),
        field_name="VideoDetailV2 videoInfo.media[0].fullVideoUrl",
        allow_empty=True,
    )

    media_section = {
        "full_video_url": full_video_url,
        "decode_key": decode_key,
    }
    return media_section, full_video_url, decode_key


def _build_video_detail_comments_section(
    raw_comments: Any, total_count: int
) -> JsonObject:
    # WeChat backend returns `data.comments = null` (not an empty list) when the
    # video has zero comments or comments are disabled. Handle gracefully as
    # empty items, not as a protocol error. Any non-None, non-list value is a
    # genuine shape drift and still raises.
    if raw_comments is None:
        return {
            "total_count": total_count,
            "returned_count": 0,
            "items": [],
        }
    if not isinstance(raw_comments, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "VideoDetailV2 payload's comments field is not a list, so the comment tree cannot be normalized safely.",
        )

    normalized_items = [
        _normalize_video_detail_comment(raw_comment, index=index)
        for index, raw_comment in enumerate(raw_comments, start=1)
    ]

    return {
        "total_count": total_count,
        "returned_count": len(normalized_items),
        "items": normalized_items,
    }


def _normalize_video_detail_comment(raw_comment: Any, *, index: int) -> JsonObject:
    comment = _require_dict(raw_comment, field_name=f"VideoDetailV2 comments[{index}]")
    published_at_ts = _coerce_intlike(
        comment.get("createtime"),
        field_name=f"VideoDetailV2 comments[{index}].createtime",
    )
    reply_nickname = comment.get("replyNickname")

    raw_replies = comment.get("replies")
    if raw_replies is None:
        normalized_replies: list[JsonObject] = []
    elif not isinstance(raw_replies, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"VideoDetailV2 comments[{index}].replies is not a list, so the comment tree cannot be normalized safely.",
        )
    else:
        normalized_replies = [
            _normalize_video_detail_comment(raw_reply, index=reply_index)
            for reply_index, raw_reply in enumerate(raw_replies, start=1)
        ]

    return {
        "nickname": _require_string(
            comment.get("nickname"),
            field_name=f"VideoDetailV2 comments[{index}].nickname",
            allow_empty=True,
        ),
        "content": _require_string(
            comment.get("content"),
            field_name=f"VideoDetailV2 comments[{index}].content",
            allow_empty=True,
        ),
        "head_url": _require_string(
            comment.get("headUrl"),
            field_name=f"VideoDetailV2 comments[{index}].headUrl",
            allow_empty=True,
        ),
        "like_count": _coerce_intlike(
            comment.get("likeCount"),
            field_name=f"VideoDetailV2 comments[{index}].likeCount",
        ),
        "published_at_ts": published_at_ts,
        "published_at_text": _format_comment_published_at_text(published_at_ts),
        "reply_nickname": reply_nickname if isinstance(reply_nickname, str) and reply_nickname else None,
        "replies": normalized_replies,
    }


def _build_video_download_instructions(*, full_video_url: str, decode_key: str) -> str:
    return (
        "请下载并解密这个视频：\n"
        "\n"
        "pip install wxipad-video\n"
        "\n"
        "from wxipad_video import decrypt_video\n"
        f"open(\"保存路径/文件名.mp4\", \"wb\").write(decrypt_video(\"{full_video_url}\", {decode_key}))"
    )


def _format_comment_published_at_text(ts: int) -> str:
    if ts == 0:
        return ""
    return datetime.fromtimestamp(ts).strftime("%Y/%m/%d %H:%M")


def _collect_video_items(raw_groups: Sequence[object]) -> list[dict[str, object]]:
    """
    Flatten video items from WeChat Search WebSearch (BT=7) response.

    Since 2026-04-15 the live response wraps video items in a two-level
    structure: outer group type=107 → subBoxes[type=84] → items. Each
    type=84 subBox carries exactly one video item. Other outer group types
    (62 account, etc.) and other subBox types (24 related-search-word
    suggestions) are skipped.
    """
    collected: list[dict[str, object]] = []
    for group in raw_groups:
        if not isinstance(group, dict):
            continue
        if _try_coerce_intlike(group.get("type")) != VIDEO_OUTER_GROUP_TYPE:
            continue
        for subbox in group.get("subBoxes") or []:
            if not isinstance(subbox, dict):
                continue
            if _try_coerce_intlike(subbox.get("type")) != VIDEO_SUBBOX_TYPE:
                continue
            subbox_items = subbox.get("items")
            if isinstance(subbox_items, list):
                collected.extend(
                    item for item in subbox_items if isinstance(item, dict)
                )
    return collected


def _normalize_video_items(raw_items: Any) -> list[JsonObject]:
    if not isinstance(raw_items, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch video group exists but its items field is not a list, so the video result list cannot be normalized.",
        )
    normalized: list[JsonObject] = []
    for index, raw_item in enumerate(raw_items, start=1):
        item = _require_dict(raw_item, field_name=f"video item #{index}")
        raw_video_id = item.get("docID")
        if not isinstance(raw_video_id, str) or not raw_video_id:
            raise WxflywheelError(
                NETWORK_ERROR_CODE,
                f"WebSearch video item #{index}.docID is missing or not a string, so the result cannot be normalized. This usually means the backend response shape drifted.",
            )
        source = item.get("source")
        if not isinstance(source, dict):
            source = {}

        normalized.append(
            # Defensive None-to-empty-string coercion on optional string fields.
            # WeChat Search WebSearch BT=7 item schema varies by content type:
            # livestream items (noPlayIcon=true) and certain keyword-dependent
            # items have fields like duration / dateTime / image / exportId /
            # hashDocID / title set to null (JSON null, Python None) rather
            # than omitted. Frontend handles this via `item.duration || ''` /
            # `item.image || ...` fallbacks. The CLI mirrors that behavior by
            # coercing None to "" before `_require_string(..., allow_empty=True)`.
            # Integer fields pubTime / showType fall back to 0 via
            # `_try_coerce_intlike(...) or 0`, aligned with width/height/
            # duration_seconds already doing so in the detail command.
            {
                "video_id": raw_video_id,
                "export_id": _require_string(
                    item.get("exportId") or "", field_name=f"video item #{index}.exportId", allow_empty=True
                ),
                "hash_doc_id": _require_string(
                    item.get("hashDocID") or "", field_name=f"video item #{index}.hashDocID", allow_empty=True
                ),
                "title": _clean_highlight_text(
                    _require_string(
                        item.get("title") or "", field_name=f"video item #{index}.title", allow_empty=True
                    )
                ),
                "cover_url": _require_string(
                    item.get("image") or "", field_name=f"video item #{index}.image", allow_empty=True
                ),
                "account_name": source.get("title") if isinstance(source.get("title"), str) else "",
                "account_icon_url": source.get("iconUrl")
                if isinstance(source.get("iconUrl"), str)
                else "",
                "duration_text": _require_string(
                    item.get("duration") or "",
                    field_name=f"video item #{index}.duration",
                    allow_empty=True,
                ),
                "published_at_text": _require_string(
                    item.get("dateTime") or "",
                    field_name=f"video item #{index}.dateTime",
                    allow_empty=True,
                ),
                "published_at_ts": _try_coerce_intlike(item.get("pubTime")) or 0,
                "show_type": _try_coerce_intlike(item.get("showType")) or 0,
                "interaction_metrics": _extract_video_interaction_metrics(
                    item.get("report_extinfo_str")
                ),
            }
        )
    return normalized


def _extract_video_interaction_metrics(raw_report_extinfo: Any) -> dict[str, int | None]:
    metrics: dict[str, int | None] = {
        "like_count": None,
        "comment_count": None,
        "forward_count": None,
        "thumb_count": None,
    }
    if not isinstance(raw_report_extinfo, str) or not raw_report_extinfo:
        return metrics

    try:
        decoded = unquote(raw_report_extinfo)
        raw_metrics = json.loads(decoded)
    except (ValueError, TypeError):
        return metrics

    if not isinstance(raw_metrics, dict):
        return metrics

    mapping = {
        "like_count": "like_cnt",
        "comment_count": "comment_cnt",
        "forward_count": "forward_cnt",
        "thumb_count": "thumb_cnt",
    }
    for out_key, in_key in mapping.items():
        raw_metric = raw_metrics.get(in_key)
        if isinstance(raw_metric, bool) or raw_metric is None:
            continue
        if isinstance(raw_metric, int):
            metrics[out_key] = raw_metric
            continue
        if isinstance(raw_metric, float):
            metrics[out_key] = int(raw_metric)
            continue
        if isinstance(raw_metric, str):
            try:
                metrics[out_key] = int(raw_metric)
            except ValueError:
                continue
    return metrics


def _encode_video_cursor(cursor_payload: JsonObject) -> str:
    raw = json.dumps(cursor_payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return base64.urlsafe_b64encode(raw.encode("utf-8")).decode("ascii").rstrip("=")


def _decode_video_cursor(raw_cursor: str) -> dict[str, Any]:
    cursor_value = raw_cursor.strip()
    if not cursor_value:
        raise click.BadParameter(
            "Cursor is empty. Pass the exact next_cursor string returned by a previous 'wxflywheel search video' response.",
            param_hint="--cursor",
        )

    padding = "=" * (-len(cursor_value) % 4)
    try:
        decoded_bytes = base64.urlsafe_b64decode(f"{cursor_value}{padding}")
        payload = json.loads(decoded_bytes.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise click.BadParameter(
            "Cursor is not a valid video-search cursor. It may have been truncated, copied incorrectly, or generated by a different command/version.",
            param_hint="--cursor",
        ) from exc

    if not isinstance(payload, dict):
        raise click.BadParameter(
            "Cursor is not a JSON object. Pass the exact next_cursor string returned by 'wxflywheel search video'.",
            param_hint="--cursor",
        )

    version = payload.get("v")
    if version != VIDEO_CURSOR_VERSION:
        raise click.BadParameter(
            f"Cursor version is unsupported (expected v={VIDEO_CURSOR_VERSION}). Generate a fresh cursor with the current 'wxflywheel search video' command.",
            param_hint="--cursor",
        )

    keyword = payload.get("keyword")
    tab = payload.get("tab")
    search_id = payload.get("search_id")
    cookies = payload.get("cookies")

    if not isinstance(keyword, str) or not keyword:
        raise click.BadParameter(
            "Cursor is missing a valid keyword field.", param_hint="--cursor"
        )
    if tab not in VIDEO_TAB_CHOICES:
        raise click.BadParameter(
            "Cursor is missing a valid tab field.", param_hint="--cursor"
        )
    if not isinstance(search_id, str) or not search_id:
        raise click.BadParameter(
            "Cursor is missing a valid search_id field.", param_hint="--cursor"
        )
    if cookies is not None and not isinstance(cookies, str):
        raise click.BadParameter(
            "Cursor cookies field must be a string when present.", param_hint="--cursor"
        )

    try:
        offset = _coerce_intlike(payload.get("offset"), field_name="cursor.offset")
    except WxflywheelError as exc:
        raise click.BadParameter(exc.message, param_hint="--cursor") from exc

    return {
        "keyword": keyword,
        "tab": tab,
        "offset": offset,
        "search_id": search_id,
        "cookies": cookies,
    }


def _build_article_ext_req_params(*, sort_name: str, cookies: str | None) -> list[JsonObject]:
    params: list[JsonObject] = []
    if sort_name == NEWEST_SORT:
        params.append({"Key": "docSortType", "TextValue": "[\"2\"]"})
    elif sort_name == HOT_SORT:
        params.append({"Key": "docSortType", "TextValue": "[\"4\"]"})

    if isinstance(cookies, str) and cookies:
        params.append({"Key": "cookies", "TextValue": cookies})
    return params


def _build_article_output(payload_data: Any, *, keyword: str, sort_name: str) -> JsonObject:
    outer_data = _require_dict(payload_data, field_name="WebSearch outer data")
    raw_inner_json = outer_data.get("json")
    if not isinstance(raw_inner_json, str) or not raw_inner_json.strip():
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch returned success but data.json is missing or empty, so the article result list cannot be parsed.",
        )

    try:
        inner_payload = json.loads(raw_inner_json)
    except ValueError as exc:
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch returned success but data.json is not valid JSON, so the article result list cannot be parsed.",
        ) from exc

    inner_data = _require_dict(inner_payload, field_name="WebSearch inner data.json")
    raw_groups = inner_data.get("data")
    if not isinstance(raw_groups, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch article search payload is missing the inner data[] groups, so the article result list cannot be parsed.",
        )

    article_group = _find_article_group(raw_groups)
    if article_group is None:
        return {
            "keyword": keyword,
            "sort": sort_name,
            "has_more": False,
            "items": [],
        }

    items = _normalize_article_items(article_group.get("items"))
    if not items:
        return {
            "keyword": keyword,
            "sort": sort_name,
            "has_more": False,
            "items": [],
        }

    has_more = _coerce_intlike(inner_data.get("continueFlag"), field_name="continueFlag") == 1

    result: JsonObject = {
        "keyword": keyword,
        "sort": sort_name,
        "has_more": has_more,
        "items": items,
    }
    if has_more:
        result["next_cursor"] = _encode_cursor(
            {
                "v": CURSOR_VERSION,
                "keyword": keyword,
                "sort": sort_name,
                "offset": _coerce_intlike(inner_data.get("offset"), field_name="offset"),
                "search_id": _require_string(inner_data.get("searchID"), field_name="searchID"),
                "cookies": _require_string(inner_data.get("cookies"), field_name="cookies"),
            }
        )
    return result


def _find_article_group(raw_groups: list[object]) -> dict[str, Any] | None:
    for group in raw_groups:
        if not isinstance(group, dict):
            continue
        raw_type = group.get("type")
        if _try_coerce_intlike(raw_type) == ARTICLE_BUSINESS_TYPE:
            return group
    return None


def _normalize_article_items(raw_items: Any) -> list[JsonObject]:
    if not isinstance(raw_items, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch article group exists but its items field is not a list, so the article result list cannot be normalized.",
        )
    normalized: list[JsonObject] = []
    for index, raw_item in enumerate(raw_items, start=1):
        item = _require_dict(raw_item, field_name=f"article item #{index}")
        source = _require_dict(item.get("source"), field_name=f"article item #{index}.source")
        article: JsonObject = {
            "article_id": _require_string(item.get("docID"), field_name=f"article item #{index}.docID"),
            "title": _clean_highlight_text(
                _require_string(item.get("title"), field_name=f"article item #{index}.title")
            ),
            "summary": _clean_highlight_text(
                _require_string(
                    item.get("desc"),
                    field_name=f"article item #{index}.desc",
                    allow_empty=True,
                )
            ),
            "source_name": _require_string(
                # 真实 WebSearch 返回里 source.title 偶尔会是 None / 缺失（部分公众号
                # 服务号文章无显式 source 名），用 `or ""` 归一化为空字符串。非 str
                # 类型（如意外的 int）仍由 _require_string 拒绝以暴露上游字段格式异常。
                source.get("title") or "",
                field_name=f"article item #{index}.source.title",
                allow_empty=True,
            ),
            "published_at_ts": _coerce_intlike(
                item.get("timestamp"), field_name=f"article item #{index}.timestamp"
            ),
            "url": _require_string(item.get("doc_url"), field_name=f"article item #{index}.doc_url"),
            "cover_url": _require_string(
                item.get("thumbUrl"), field_name=f"article item #{index}.thumbUrl"
            ),
        }

        read_count_text = _extract_read_count_text(source.get("tag"))
        if read_count_text is not None:
            article["read_count_text"] = read_count_text

        read_count = _extract_read_count(item.get("report_extinfo_str"))
        if read_count is not None:
            article["read_count"] = read_count

        normalized.append(article)
    return normalized


def _build_article_detail_output(payload_data: Any) -> JsonObject:
    data = _require_dict(payload_data, field_name="ArticleDetailV2 data")
    article = _require_dict(data.get("article"), field_name="ArticleDetailV2 article")
    metrics = _require_dict(data.get("metrics"), field_name="ArticleDetailV2 metrics")
    comments = _require_dict(data.get("comments"), field_name="ArticleDetailV2 comments")

    normalized: JsonObject = {
        "article": {
            "title": _require_string(article.get("title"), field_name="ArticleDetailV2 article.title", allow_empty=True),
            "source_name": _require_string(
                article.get("source_name"),
                field_name="ArticleDetailV2 article.source_name",
                allow_empty=True,
            ),
            "author": _require_string(article.get("author"), field_name="ArticleDetailV2 article.author", allow_empty=True),
            "summary": _require_string(article.get("summary"), field_name="ArticleDetailV2 article.summary", allow_empty=True),
            "published_at_text": _require_string(
                article.get("published_at_text"),
                field_name="ArticleDetailV2 article.published_at_text",
                allow_empty=True,
            ),
            "published_at_ts": _coerce_intlike(
                article.get("published_at_ts"), field_name="ArticleDetailV2 article.published_at_ts"
            ),
            "url": _require_string(article.get("url"), field_name="ArticleDetailV2 article.url"),
            "content_html": _require_string(
                article.get("content_html"),
                field_name="ArticleDetailV2 article.content_html",
                allow_empty=True,
            ),
        },
        "metrics": {
            "read_count": _coerce_intlike(metrics.get("read_count"), field_name="ArticleDetailV2 metrics.read_count"),
            "like_count": _coerce_intlike(metrics.get("like_count"), field_name="ArticleDetailV2 metrics.like_count"),
            "watching_count": _coerce_intlike(
                metrics.get("watching_count"), field_name="ArticleDetailV2 metrics.watching_count"
            ),
            "share_count": _coerce_intlike(metrics.get("share_count"), field_name="ArticleDetailV2 metrics.share_count"),
            "collect_count": _coerce_intlike(
                metrics.get("collect_count"), field_name="ArticleDetailV2 metrics.collect_count"
            ),
            "comment_count": _coerce_intlike(
                metrics.get("comment_count"), field_name="ArticleDetailV2 metrics.comment_count"
            ),
            "comment_enabled": _require_bool(
                metrics.get("comment_enabled"), field_name="ArticleDetailV2 metrics.comment_enabled"
            ),
        },
        "comments": {
            "scope": _require_selected_comment_scope(comments.get("scope")),
            "returned_count": _coerce_intlike(
                comments.get("returned_count"), field_name="ArticleDetailV2 comments.returned_count"
            ),
            "items": _normalize_comment_items(comments.get("items")),
        },
    }

    comments_error = data.get("comments_error")
    if isinstance(comments_error, str) and comments_error:
        normalized["comments_error"] = comments_error

    return normalized


def _normalize_comment_items(raw_items: Any) -> list[JsonObject]:
    if not isinstance(raw_items, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "ArticleDetailV2 comments.items is not a list, so selected comments cannot be normalized safely.",
        )
    normalized: list[JsonObject] = []
    for index, raw_item in enumerate(raw_items, start=1):
        item = _require_dict(raw_item, field_name=f"ArticleDetailV2 comments.items[{index}]")
        normalized_item: JsonObject = {
            "user_comment_id": _coerce_intlike(
                item.get("userCommentId"),
                field_name=f"ArticleDetailV2 comments.items[{index}].userCommentId",
            ),
            "nick_name": _require_string(
                item.get("nickName"),
                field_name=f"ArticleDetailV2 comments.items[{index}].nickName",
                allow_empty=True,
            ),
            "content": _require_string(
                item.get("content"),
                field_name=f"ArticleDetailV2 comments.items[{index}].content",
                allow_empty=True,
            ),
            "create_time": _coerce_intlike(
                item.get("createTime"),
                field_name=f"ArticleDetailV2 comments.items[{index}].createTime",
            ),
            "like_count": _coerce_intlike(
                item.get("likeNum"),
                field_name=f"ArticleDetailV2 comments.items[{index}].likeNum",
            ),
            "is_top": _coerce_intlike(
                item.get("isTop"),
                field_name=f"ArticleDetailV2 comments.items[{index}].isTop",
            ),
        }
        reply = item.get("reply")
        if reply is not None:
            normalized_item["reply"] = _normalize_comment_reply(
                reply, field_name=f"ArticleDetailV2 comments.items[{index}].reply"
            )
        normalized.append(normalized_item)
    return normalized


def _normalize_comment_reply(raw_reply: Any, *, field_name: str) -> JsonObject:
    reply = _require_dict(raw_reply, field_name=field_name)
    raw_list = reply.get("replyList")
    if not isinstance(raw_list, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name}.replyList is not a list, so selected comment replies cannot be normalized safely.",
        )
    normalized_replies: list[JsonObject] = []
    for index, raw_item in enumerate(raw_list, start=1):
        item = _require_dict(raw_item, field_name=f"{field_name}.replyList[{index}]")
        normalized_replies.append(
            {
                "content": _require_string(
                    item.get("content"),
                    field_name=f"{field_name}.replyList[{index}].content",
                    allow_empty=True,
                ),
                "create_time": _coerce_intlike(
                    item.get("createTime"),
                    field_name=f"{field_name}.replyList[{index}].createTime",
                ),
                "reply_id": _coerce_intlike(
                    item.get("replyId"),
                    field_name=f"{field_name}.replyList[{index}].replyId",
                ),
                "like_count": _coerce_intlike(
                    item.get("replyLikeNum"),
                    field_name=f"{field_name}.replyList[{index}].replyLikeNum",
                ),
            }
        )
    return {"reply_list": normalized_replies}


def _build_sticker_search_body(
    *, keyword: str, tab_name: str, offset: int, search_id: str, cookies: str | None
) -> JsonObject:
    body: JsonObject = {
        "KeyWord": keyword,
        "Offset": offset,
        "BusinessType": STICKER_BUSINESS_TYPE,
        "Scene": STICKER_SCENE,
        "SearchId": search_id,
    }
    ext_req_params = _build_sticker_ext_req_params(tab_name=tab_name, cookies=cookies)
    if ext_req_params:
        body["ExtReqParams"] = ext_req_params
    return body


def _build_sticker_ext_req_params(*, tab_name: str, cookies: str | None) -> list[JsonObject]:
    params: list[JsonObject] = []
    tab_param = STICKER_TAB_PARAMS.get(tab_name)
    if tab_param is not None and tab_name != "all":
        key, value = tab_param
        params.append({"Key": key, "TextValue": f'["{value}"]'})

    if isinstance(cookies, str) and cookies:
        params.append({"Key": "cookies", "TextValue": cookies})
    return params


def _build_sticker_output(payload_data: Any, *, keyword: str, tab_name: str) -> JsonObject:
    outer_data = _require_dict(payload_data, field_name="WebSearch outer data")
    raw_inner_json = outer_data.get("json")
    if not isinstance(raw_inner_json, str) or not raw_inner_json.strip():
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch returned success but data.json is missing or empty, so the sticker result list cannot be parsed.",
        )

    try:
        inner_payload = json.loads(raw_inner_json)
    except ValueError as exc:
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "WebSearch returned success but data.json is not valid JSON, so the sticker result list cannot be parsed.",
        ) from exc

    inner_data = _require_dict(inner_payload, field_name="WebSearch inner data.json")
    raw_groups = inner_data.get("data")
    if not isinstance(raw_groups, list):
        # data can be null when the interaction-tab has no matching items
        # (e.g. "favorite" with no favorited stickers) — treat as empty.
        return {
            "keyword": keyword,
            "tab": tab_name,
            "has_more": False,
            "items": [],
        }

    items = _extract_sticker_items_from_groups(raw_groups)
    if not items:
        return {
            "keyword": keyword,
            "tab": tab_name,
            "has_more": False,
            "items": [],
        }

    has_more = _coerce_intlike(inner_data.get("continueFlag"), field_name="continueFlag") == 1
    next_offset = _coerce_intlike(inner_data.get("offset"), field_name="offset")

    result: JsonObject = {
        "keyword": keyword,
        "tab": tab_name,
        "has_more": has_more,
        "items": items,
    }
    if has_more:
        result["next_cursor"] = _encode_sticker_cursor(
            {
                "v": STICKER_CURSOR_VERSION,
                "keyword": keyword,
                "tab": tab_name,
                "offset": next_offset,
                "search_id": _require_string(inner_data.get("searchID"), field_name="searchID"),
                "cookies": _require_string(inner_data.get("cookies"), field_name="cookies"),
            }
        )
    return result


def _extract_sticker_items_from_groups(raw_groups: list[object]) -> list[JsonObject]:
    """Extract sticker items from the nested groups -> subBoxes -> items structure.

    WebSearch sticker results are wrapped in type=107 container groups,
    each containing 1-2 subBoxes of type=84 with 1 item each (two-column
    layout). This function flattens all items into a single ordered list.
    """
    normalized: list[JsonObject] = []
    rank = 0
    for raw_group in raw_groups:
        if not isinstance(raw_group, dict):
            continue
        group_type = _try_coerce_intlike(raw_group.get("type"))
        if group_type != 107:
            continue
        sub_boxes = raw_group.get("subBoxes")
        if not isinstance(sub_boxes, list):
            continue
        for raw_sub_box in sub_boxes:
            if not isinstance(raw_sub_box, dict):
                continue
            raw_items = raw_sub_box.get("items")
            if not isinstance(raw_items, list):
                continue
            for raw_item in raw_items:
                if not isinstance(raw_item, dict):
                    continue
                rank += 1
                normalized.append(_normalize_sticker_item(raw_item, fallback_rank=rank))
    return normalized


def _normalize_sticker_item(raw_item: dict[str, Any], *, fallback_rank: int) -> JsonObject:
    """Normalize a single raw sticker item into 16 Agent-readable fields."""
    source = raw_item.get("source")
    if not isinstance(source, dict):
        source = {}
    jump_info = raw_item.get("jumpInfo")
    if not isinstance(jump_info, dict):
        jump_info = {}

    return {
        "sticker_id": _require_string(raw_item.get("docID"), field_name="sticker docID"),
        "title": _clean_highlight_text(
            _require_string(raw_item.get("title"), field_name="sticker title")
        ),
        "source_name": _require_string(source.get("title"), field_name="sticker source.title"),
        "source_icon_url": _require_string(
            source.get("iconUrl"), field_name="sticker source.iconUrl", allow_empty=True
        ),
        "published_at_ts": _coerce_intlike(raw_item.get("pubTime"), field_name="sticker pubTime"),
        "published_relative": _require_string(
            raw_item.get("updateTime"), field_name="sticker updateTime", allow_empty=True
        ),
        "cover_url": _require_string(raw_item.get("image"), field_name="sticker image"),
        "sticker_url": _require_string(jump_info.get("jumpUrl"), field_name="sticker jumpInfo.jumpUrl"),
        "content_type_code": _coerce_intlike(
            jump_info.get("itemShowType"), field_name="sticker jumpInfo.itemShowType"
        ),
        "mp_doc_id": _require_string(
            raw_item.get("mpDocID"), field_name="sticker mpDocID", allow_empty=True
        ),
        "rank": _try_coerce_intlike(raw_item.get("inner_offset")) or fallback_rank,
        "report_id": _require_string(
            raw_item.get("reportId"), field_name="sticker reportId", allow_empty=True
        ),
        "display_style": _try_coerce_intlike(raw_item.get("showType")) or 0,
        "source_type": _try_coerce_intlike(raw_item.get("src_type")) or 0,
        "social_tags": raw_item.get("socialTags"),
        "hide_control": bool(raw_item.get("hideControl")),
    }


def _encode_sticker_cursor(cursor_payload: JsonObject) -> str:
    raw = json.dumps(cursor_payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return base64.urlsafe_b64encode(raw.encode("utf-8")).decode("ascii").rstrip("=")


def _decode_sticker_cursor(raw_cursor: str) -> dict[str, Any]:
    cursor_value = raw_cursor.strip()
    if not cursor_value:
        raise click.BadParameter(
            "Cursor is empty. Pass the exact next_cursor string returned by a previous 'wxflywheel search sticker' response.",
            param_hint="--cursor",
        )

    padding = "=" * (-len(cursor_value) % 4)
    try:
        decoded_bytes = base64.urlsafe_b64decode(f"{cursor_value}{padding}")
        payload = json.loads(decoded_bytes.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise click.BadParameter(
            "Cursor is not a valid sticker-search cursor. It may have been truncated, copied incorrectly, or generated by a different command/version.",
            param_hint="--cursor",
        ) from exc

    if not isinstance(payload, dict):
        raise click.BadParameter(
            "Cursor is not a JSON object. Pass the exact next_cursor string returned by 'wxflywheel search sticker'.",
            param_hint="--cursor",
        )

    version = payload.get("v")
    if version != STICKER_CURSOR_VERSION:
        raise click.BadParameter(
            f"Cursor version is unsupported (expected v={STICKER_CURSOR_VERSION}). Generate a fresh cursor with the current 'wxflywheel search sticker' command.",
            param_hint="--cursor",
        )

    keyword = payload.get("keyword")
    tab = payload.get("tab")
    search_id = payload.get("search_id")
    cookies = payload.get("cookies")

    if not isinstance(keyword, str) or not keyword:
        raise click.BadParameter(
            "Cursor is missing a valid keyword field.", param_hint="--cursor"
        )
    if tab not in STICKER_TAB_CHOICES:
        raise click.BadParameter(
            "Cursor is missing a valid tab field.", param_hint="--cursor"
        )
    if not isinstance(search_id, str) or not search_id:
        raise click.BadParameter(
            "Cursor is missing a valid search_id field.", param_hint="--cursor"
        )
    if cookies is not None and not isinstance(cookies, str):
        raise click.BadParameter(
            "Cursor cookies field must be a string when present.", param_hint="--cursor"
        )

    try:
        offset = _coerce_intlike(payload.get("offset"), field_name="cursor.offset")
    except WxflywheelError as exc:
        raise click.BadParameter(exc.message, param_hint="--cursor") from exc

    return {
        "keyword": keyword,
        "tab": tab,
        "offset": offset,
        "search_id": search_id,
        "cookies": cookies,
    }


def _clean_highlight_text(text: str) -> str:
    return unescape(HIGHLIGHT_TAG_RE.sub("", text))


def _extract_read_count_text(raw_tags: Any) -> str | None:
    if not isinstance(raw_tags, list):
        return None
    for raw_tag in raw_tags:
        if not isinstance(raw_tag, dict):
            continue
        title = raw_tag.get("title")
        if isinstance(title, str) and title.startswith("阅读"):
            return title
    return None


def _extract_read_count(raw_report_extinfo: Any) -> int | None:
    if not isinstance(raw_report_extinfo, str) or not raw_report_extinfo:
        return None
    decoded = unquote(raw_report_extinfo)
    match = READ_COUNT_RE.search(decoded)
    if match is None:
        return None
    return int(match.group(1))


def _encode_cursor(cursor_payload: JsonObject) -> str:
    raw = json.dumps(cursor_payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return base64.urlsafe_b64encode(raw.encode("utf-8")).decode("ascii").rstrip("=")


def _decode_cursor(raw_cursor: str) -> dict[str, Any]:
    cursor_value = raw_cursor.strip()
    if not cursor_value:
        raise click.BadParameter(
            "Cursor is empty. Pass the exact next_cursor string returned by a previous 'wxflywheel search article' response.",
            param_hint="--cursor",
        )

    padding = "=" * (-len(cursor_value) % 4)
    try:
        decoded_bytes = base64.urlsafe_b64decode(f"{cursor_value}{padding}")
        payload = json.loads(decoded_bytes.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise click.BadParameter(
            "Cursor is not a valid article-search cursor. It may have been truncated, copied incorrectly, or generated by a different command/version.",
            param_hint="--cursor",
        ) from exc

    if not isinstance(payload, dict):
        raise click.BadParameter(
            "Cursor is not a JSON object. Pass the exact next_cursor string returned by 'wxflywheel search article'.",
            param_hint="--cursor",
        )

    version = payload.get("v")
    if version != CURSOR_VERSION:
        raise click.BadParameter(
            f"Cursor version is unsupported (expected v={CURSOR_VERSION}). Generate a fresh cursor with the current 'wxflywheel search article' command.",
            param_hint="--cursor",
        )

    keyword = payload.get("keyword")
    sort_name = payload.get("sort")
    search_id = payload.get("search_id")
    cookies = payload.get("cookies")

    if not isinstance(keyword, str) or not keyword:
        raise click.BadParameter(
            "Cursor is missing a valid keyword field.", param_hint="--cursor"
        )
    if sort_name not in SORT_CHOICES:
        raise click.BadParameter(
            "Cursor is missing a valid sort field.", param_hint="--cursor"
        )
    if not isinstance(search_id, str) or not search_id:
        raise click.BadParameter(
            "Cursor is missing a valid search_id field.", param_hint="--cursor"
        )
    if cookies is not None and not isinstance(cookies, str):
        raise click.BadParameter(
            "Cursor cookies field must be a string when present.", param_hint="--cursor"
        )

    try:
        offset = _coerce_intlike(payload.get("offset"), field_name="cursor.offset")
    except WxflywheelError as exc:
        raise click.BadParameter(exc.message, param_hint="--cursor") from exc

    return {
        "keyword": keyword,
        "sort": sort_name,
        "offset": offset,
        "search_id": search_id,
        "cookies": cookies,
    }


def _require_dict(value: Any, *, field_name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is not a JSON object, so the payload cannot be normalized safely.",
        )
    return value


def _require_string(value: Any, *, field_name: str, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value):
        requirement = "string" if allow_empty else "non-empty string"
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is missing or not a {requirement}, so the payload cannot be normalized safely.",
        )
    return value


def _require_bool(value: Any, *, field_name: str) -> bool:
    if not isinstance(value, bool):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is missing or not a bool, so the payload cannot be normalized safely.",
        )
    return value


def _require_selected_comment_scope(value: Any) -> str:
    if value != "selected":
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "ArticleDetailV2 comments.scope is not 'selected', so the article detail payload does not match the curated CLI contract.",
        )
    return "selected"


def _coerce_intlike(value: Any, *, field_name: str) -> int:
    coerced = _try_coerce_intlike(value)
    if coerced is None:
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            f"{field_name} is missing or not numeric, so the payload cannot be normalized safely.",
        )
    return coerced


def _try_coerce_intlike(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        try:
            return int(stripped)
        except ValueError:
            return None
    return None


# ---------------------------------------------------------------------------
# Sticker detail normalizers — 100% aligned with StickerDetailDrawer.tsx
# ---------------------------------------------------------------------------


def _build_sticker_detail_output(payload_data: Any) -> JsonObject:
    data = _require_dict(payload_data, field_name="StickerDetail data")

    raw_info = _require_dict(data.get("sticker_info"), field_name="StickerDetail sticker_info")
    raw_metrics = _require_dict(
        data.get("engagement_metrics"), field_name="StickerDetail engagement_metrics"
    )
    raw_copyright = _require_dict(data.get("copyright"), field_name="StickerDetail copyright")
    raw_monetization = _require_dict(
        data.get("monetization"), field_name="StickerDetail monetization"
    )
    raw_comments = _require_dict(data.get("comments"), field_name="StickerDetail comments")

    normalized: JsonObject = {
        "sticker_info": {
            "title": _require_string(
                raw_info.get("title"),
                field_name="StickerDetail sticker_info.title",
                allow_empty=True,
            ),
            "account_name": _require_string(
                raw_info.get("account_name"),
                field_name="StickerDetail sticker_info.account_name",
                allow_empty=True,
            ),
            "ip_location": _require_string(
                raw_info.get("ip_location"),
                field_name="StickerDetail sticker_info.ip_location",
                allow_empty=True,
            ),
            "published_at": _require_string(
                raw_info.get("published_at"),
                field_name="StickerDetail sticker_info.published_at",
                allow_empty=True,
            ),
            "published_at_timestamp": _coerce_intlike(
                raw_info.get("published_at_timestamp"),
                field_name="StickerDetail sticker_info.published_at_timestamp",
            ),
            "article_url": _require_string(
                raw_info.get("article_url"),
                field_name="StickerDetail sticker_info.article_url",
            ),
            "is_original": _require_bool(
                raw_copyright.get("is_original"),
                field_name="StickerDetail copyright.is_original",
            ),
        },
        "pictures": _normalize_sticker_pictures(data.get("pictures")),
        "engagement_metrics": {
            "read_count": _coerce_intlike(
                raw_metrics.get("read_count"),
                field_name="StickerDetail engagement_metrics.read_count",
            ),
            "like_count": _coerce_intlike(
                raw_metrics.get("like_count"),
                field_name="StickerDetail engagement_metrics.like_count",
            ),
            "watching_count": _coerce_intlike(
                raw_metrics.get("watching_count"),
                field_name="StickerDetail engagement_metrics.watching_count",
            ),
            "share_count": _coerce_intlike(
                raw_metrics.get("share_count"),
                field_name="StickerDetail engagement_metrics.share_count",
            ),
            "collect_count": _coerce_intlike(
                raw_metrics.get("collect_count"),
                field_name="StickerDetail engagement_metrics.collect_count",
            ),
            "comment_count": _coerce_intlike(
                raw_metrics.get("comment_count"),
                field_name="StickerDetail engagement_metrics.comment_count",
            ),
            "comment_enabled": _require_bool(
                raw_metrics.get("comment_enabled"),
                field_name="StickerDetail engagement_metrics.comment_enabled",
            ),
        },
        "text_content": _require_string(
            data.get("text_content"),
            field_name="StickerDetail text_content",
            allow_empty=True,
        ),
        "hashtags": _normalize_sticker_hashtags(data.get("hashtags")),
        "topics": _normalize_sticker_topics(data.get("topics")),
        "monetization": _normalize_sticker_monetization(raw_monetization),
        "comments": _normalize_sticker_comments(raw_comments),
    }

    comments_error = data.get("comments_error")
    if isinstance(comments_error, str) and comments_error:
        normalized["comments_error"] = comments_error

    return normalized


def _normalize_sticker_pictures(raw_pictures: Any) -> list[JsonObject]:
    if not isinstance(raw_pictures, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail pictures is not a list, so the sticker detail payload cannot be normalized safely.",
        )
    normalized: list[JsonObject] = []
    for index, raw_pic in enumerate(raw_pictures, start=1):
        pic = _require_dict(raw_pic, field_name=f"StickerDetail pictures[{index}]")
        normalized.append(
            {
                "image_url": _require_string(
                    pic.get("image_url"),
                    field_name=f"StickerDetail pictures[{index}].image_url",
                ),
                "width_px": _coerce_intlike(
                    pic.get("width_px"),
                    field_name=f"StickerDetail pictures[{index}].width_px",
                ),
                "height_px": _coerce_intlike(
                    pic.get("height_px"),
                    field_name=f"StickerDetail pictures[{index}].height_px",
                ),
                "is_qr_code": _require_bool(
                    pic.get("is_qr_code"),
                    field_name=f"StickerDetail pictures[{index}].is_qr_code",
                ),
            }
        )
    return normalized


def _normalize_sticker_hashtags(raw_hashtags: Any) -> list[str]:
    if not isinstance(raw_hashtags, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail hashtags is not a list, so the sticker detail payload cannot be normalized safely.",
        )
    result: list[str] = []
    for index, raw_tag in enumerate(raw_hashtags, start=1):
        result.append(
            _require_string(
                raw_tag,
                field_name=f"StickerDetail hashtags[{index}]",
                allow_empty=True,
            )
        )
    return result


def _normalize_sticker_topics(raw_topics: Any) -> list[JsonObject]:
    if not isinstance(raw_topics, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail topics is not a list, so the sticker detail payload cannot be normalized safely.",
        )
    normalized: list[JsonObject] = []
    for index, raw_topic in enumerate(raw_topics, start=1):
        topic = _require_dict(raw_topic, field_name=f"StickerDetail topics[{index}]")
        normalized.append(
            {
                "topic_name": _require_string(
                    topic.get("topic_name"),
                    field_name=f"StickerDetail topics[{index}].topic_name",
                ),
                "topic_read_count": _coerce_intlike(
                    topic.get("topic_read_count"),
                    field_name=f"StickerDetail topics[{index}].topic_read_count",
                ),
                "topic_article_count": _coerce_intlike(
                    topic.get("topic_article_count"),
                    field_name=f"StickerDetail topics[{index}].topic_article_count",
                ),
            }
        )
    return normalized


def _normalize_sticker_monetization(raw_monetization: dict[str, Any]) -> JsonObject:
    raw_paid = _require_dict(
        raw_monetization.get("paid_subscription"),
        field_name="StickerDetail monetization.paid_subscription",
    )
    raw_product_items = raw_monetization.get("product_window_items")
    if not isinstance(raw_product_items, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail monetization.product_window_items is not a list, so the sticker detail payload cannot be normalized safely.",
        )
    return {
        "tipping_enabled": _require_bool(
            raw_monetization.get("tipping_enabled"),
            field_name="StickerDetail monetization.tipping_enabled",
        ),
        "has_advertisement": _require_bool(
            raw_monetization.get("has_advertisement"),
            field_name="StickerDetail monetization.has_advertisement",
        ),
        "product_window_item_count": len(raw_product_items),
        "paid_subscription": {
            "is_paid": _require_bool(
                raw_paid.get("is_paid"),
                field_name="StickerDetail monetization.paid_subscription.is_paid",
            ),
            "fee": _coerce_intlike(
                raw_paid.get("fee"),
                field_name="StickerDetail monetization.paid_subscription.fee",
            ),
        },
    }


def _normalize_sticker_comments(raw_comments: dict[str, Any]) -> JsonObject:
    scope = raw_comments.get("scope")
    if scope != "selected":
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail comments.scope is not 'selected', so the sticker detail payload does not match the curated CLI contract.",
        )

    raw_items = raw_comments.get("items")
    if not isinstance(raw_items, list):
        raise WxflywheelError(
            NETWORK_ERROR_CODE,
            "StickerDetail comments.items is not a list, so selected comments cannot be normalized safely.",
        )
    normalized_items: list[JsonObject] = []
    for index, raw_item in enumerate(raw_items, start=1):
        item = _require_dict(raw_item, field_name=f"StickerDetail comments.items[{index}]")
        normalized_item: JsonObject = {
            "nick_name": _require_string(
                item.get("nick_name"),
                field_name=f"StickerDetail comments.items[{index}].nick_name",
                allow_empty=True,
            ),
            "content": _require_string(
                item.get("content"),
                field_name=f"StickerDetail comments.items[{index}].content",
                allow_empty=True,
            ),
            "like_count": _coerce_intlike(
                item.get("like_count"),
                field_name=f"StickerDetail comments.items[{index}].like_count",
            ),
            "posted_at_timestamp": _coerce_intlike(
                item.get("posted_at_timestamp"),
                field_name=f"StickerDetail comments.items[{index}].posted_at_timestamp",
            ),
            "ip_location": _require_string(
                item.get("ip_location"),
                field_name=f"StickerDetail comments.items[{index}].ip_location",
                allow_empty=True,
            ),
            "is_top": _require_bool(
                item.get("is_top"),
                field_name=f"StickerDetail comments.items[{index}].is_top",
            ),
            "is_author_reply": _require_bool(
                item.get("is_author_reply"),
                field_name=f"StickerDetail comments.items[{index}].is_author_reply",
            ),
        }
        raw_replies = item.get("replies")
        if isinstance(raw_replies, list) and raw_replies:
            normalized_item["replies"] = _normalize_sticker_comment_replies(
                raw_replies,
                field_name=f"StickerDetail comments.items[{index}].replies",
            )
        normalized_items.append(normalized_item)

    return {
        "scope": "selected",
        "returned_count": _coerce_intlike(
            raw_comments.get("returned_count"),
            field_name="StickerDetail comments.returned_count",
        ),
        "total_selected_count": _coerce_intlike(
            raw_comments.get("total_selected_count"),
            field_name="StickerDetail comments.total_selected_count",
        ),
        "items": normalized_items,
    }


def _normalize_sticker_comment_replies(
    raw_replies: list[Any], *, field_name: str
) -> list[JsonObject]:
    normalized: list[JsonObject] = []
    for index, raw_reply in enumerate(raw_replies, start=1):
        reply = _require_dict(raw_reply, field_name=f"{field_name}[{index}]")
        normalized.append(
            {
                "nick_name": _require_string(
                    reply.get("nick_name"),
                    field_name=f"{field_name}[{index}].nick_name",
                    allow_empty=True,
                ),
                "content": _require_string(
                    reply.get("content"),
                    field_name=f"{field_name}[{index}].content",
                    allow_empty=True,
                ),
                "like_count": _coerce_intlike(
                    reply.get("like_count"),
                    field_name=f"{field_name}[{index}].like_count",
                ),
                "posted_at_timestamp": _coerce_intlike(
                    reply.get("posted_at_timestamp"),
                    field_name=f"{field_name}[{index}].posted_at_timestamp",
                ),
                "is_author": _require_bool(
                    reply.get("is_author"),
                    field_name=f"{field_name}[{index}].is_author",
                ),
            }
        )
    return normalized
