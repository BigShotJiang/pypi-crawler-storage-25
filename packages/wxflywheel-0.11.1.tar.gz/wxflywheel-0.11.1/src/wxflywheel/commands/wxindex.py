from __future__ import annotations

from urllib.parse import quote

import click

from wxflywheel.commands.common import normalize_string_list, require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.output import JsonObject, json_command, success_payload

WXINDEX_QUERY_PATH_PREFIX = "/api/wxindex/"


@click.group()
def wxindex() -> None:
    """WeChat Index (微信指数 / wxindex) — WeChat's official keyword trend dataset inside WeChat Search. Covers two distinct intents: `wxindex related` returns short high-frequency co-search terms for expansion, while `wxindex query` returns the full per-keyword trend payload for Agent judgment, including current value, year-long trend, channel breakdown, and recent fluctuation snapshot when available."""


@wxindex.command()
@click.option(
    "--keyword",
    required=True,
    help="WxIndex keyword to inspect in full, for example `社群运营` or `咖啡`.",
)
@click.pass_obj
@json_command
def query(runtime: RuntimeContext, keyword: str) -> JsonObject:
    """Fetch the full WeChat Index dataset for one keyword from WeChat Index, NOT just short related terms. This command is for Agent evaluation work such as judging a topic's value, momentum, channel mix, and recent fluctuation, so the CLI deliberately does not trim or reinterpret the backend payload. Returns the full keyword payload under the standard envelope, typically including `keyword`, `current_value`, `trend`, `multichannel`, `channel_trend`, and `updated_at`."""
    client = require_client(runtime)
    payload = client.get(f"{WXINDEX_QUERY_PATH_PREFIX}{quote(keyword, safe='')}")
    return success_payload(payload["data"], payload["message"])


@wxindex.command()
@click.option("--keyword", required=True, help="WxIndex keyword.")
@click.pass_obj
@json_command
def related(runtime: RuntimeContext, keyword: str) -> JsonObject:
    """Get short high-frequency related terms for a keyword from WeChat Index (e.g. keyword='咖啡' → ['咖啡机', '咖啡色', '咖啡店']). These are short word-level associations reflecting WeChat's search trend dataset, NOT long-tail user queries — for long-tail use 'wxflywheel search related' instead. Does not require a logged-in WeChat account. Returns {keyword, related[]}."""
    client = require_client(runtime)
    payload = client.get(f"/api/wxindexsug/{quote(keyword, safe='')}")
    words = normalize_string_list(payload["data"])
    return success_payload({"keyword": keyword, "related": words}, payload["message"])
