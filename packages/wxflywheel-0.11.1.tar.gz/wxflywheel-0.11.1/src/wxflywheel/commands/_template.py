"""
New command module template.

Adjust:
1. group name + docstring
2. command name + options + docstring
3. API path and parameters

Register in the root CLI:
    from wxflywheel.commands.module_name import module_name
    cli.add_command(module_name)
"""

from __future__ import annotations

import click

from wxflywheel.commands.common import require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.output import JsonObject, json_command


@click.group()
def module_name() -> None:
    """Module description."""


@module_name.command()
@click.option("--keyword", required=True, help="Search keyword.")
@click.pass_obj
@json_command
def action_name(runtime: RuntimeContext, keyword: str) -> JsonObject:
    client = require_client(runtime)
    return client.get("/api/research/search", keyword=keyword)
