from __future__ import annotations

import click

from wxflywheel.commands.common import require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.output import JsonObject, json_command


@click.group()
def login() -> None:
    """WeChat account login state inspection — read-only commands to check the current login state of a WeChat account managed by wx-ipad."""


@login.command()
@click.pass_obj
@json_command
def status(runtime: RuntimeContext) -> JsonObject:
    """Read the current WeChat account login state (online / reconnecting / offline / not_login / logout / unknown) and any recent login error journal. Read-only; does not trigger authentication. The --key parameter identifies which WeChat account slot to query. Returns {loginState, loginErrMsg, loginJournal, targetIp}."""
    client = require_client(runtime)
    return client.get("/v1/login/GetLoginStatus", autoLogin="false")
