from __future__ import annotations

from wxflywheel.client import WxflywheelClient
from wxflywheel.config import RuntimeContext
from wxflywheel.exceptions import MissingKeyError


def require_client(runtime: RuntimeContext) -> WxflywheelClient:
    if runtime.key is None:
        raise MissingKeyError()
    return WxflywheelClient(runtime.key, runtime.host)


def normalize_string_list(raw_words: object) -> list[str]:
    if not isinstance(raw_words, list):
        return []
    return [word for word in raw_words if isinstance(word, str)]
