"""``wxflywheel self`` command group — CLI package self-management.

The module file is named ``self_cmd.py`` instead of ``self.py`` to avoid
confusing Python tooling (``self`` is a convention, not a keyword, but the
filename is still ugly). The exposed Click command name is ``self`` via
``@click.group(name="self")``, matching the convention used by ``rustup`` and
``poetry``.
"""

from __future__ import annotations

import subprocess
import sys
from typing import Any

import click
from filelock import FileLock, Timeout

from wxflywheel import __version__
from wxflywheel.exceptions import WxflywheelError
from wxflywheel.output import JsonObject, json_command, success_payload

UPDATE_LOCK_TIMEOUT_SECONDS = 60
PIP_INSTALL_TIMEOUT_SECONDS = 180
PIP_SHOW_TIMEOUT_SECONDS = 10
MAX_OUTPUT_TAIL_CHARS = 2000


@click.group(name="self")
def self_cmd() -> None:
    """wxflywheel self-management — upgrade the CLI package itself by invoking pip in a subprocess of the current Python interpreter. Use 'wxflywheel self update' to trigger an upgrade to the latest PyPI release. AI Agents should read the meta.cli.self_update_command field from any command's JSON response and invoke it autonomously when meta.cli.update_available is true and the Agent is not in the middle of a critical workflow. The upgrade happens in a subprocess so it does not require the CLI to restart itself; however, the currently running wxflywheel process keeps the OLD code in memory, so the new version only takes effect on the NEXT wxflywheel invocation."""


@self_cmd.command(name="update")
@json_command
def update() -> JsonObject:
    """Upgrade wxflywheel to the latest PyPI release by invoking 'python -m pip install --upgrade wxflywheel' in a subprocess of the currently running Python interpreter. On success, returns (on stdout, exit code 0) a JSON envelope where data contains {before_version, after_version, success: true, returncode: 0, stdout_tail, stderr_tail, python_executable, hint}. IMPORTANT FOR AGENTS: the upgrade takes effect only on the NEXT invocation of wxflywheel — the currently running process keeps the OLD code in memory and will continue to behave like the old version until it exits. After a successful update, the Agent must either restart itself or call wxflywheel again from a fresh process to use the new version. This command uses a filesystem lock (~/.cache/wxflywheel/update.lock) with a 60-second acquisition timeout to prevent concurrent upgrades from corrupting the package state. Error cases (all emitted as JSON on STDERR with exit code 1, not stdout): code -3 = cache directory cannot be created (OSError, read-only filesystem or permission denied); code -4 = lock acquisition timed out (another upgrade in progress or stale lock file — the error message tells the Agent to wait or manually remove the lock); code -5 = pip install hung beyond 180 seconds (network extremely slow or PyPI unreachable); code -6 = pip itself cannot be invoked via 'python -m pip' (wrong Python environment, pip missing, or OS-level execution failure); code -7 = pip exited with non-zero returncode (network failure, PyPI credentials required, version conflict, or site-packages permission denied — stderr_tail is attached to the error's data field for Agent-side diagnosis). All error messages include enough context for the Agent to decide whether to retry, wait, or escalate to the user. There is no success=false path on stdout — any failure uses stderr + exit 1 + code/data/message envelope; Agents parsing output must check exit code first and read stderr on non-zero."""
    from wxflywheel.version_check import cache_dir

    cache_path = cache_dir()
    try:
        cache_path.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise WxflywheelError(
            -3,
            f"Cannot create cache directory {cache_path} for update lock: {exc}. "
            "Check filesystem permissions; wxflywheel needs write access to this "
            "directory for update coordination.",
        ) from exc

    lock_path = cache_path / "update.lock"
    lock = FileLock(str(lock_path), timeout=UPDATE_LOCK_TIMEOUT_SECONDS)
    try:
        with lock:
            return _run_pip_upgrade()
    except Timeout as exc:
        raise WxflywheelError(
            -4,
            f"Another wxflywheel self update is in progress (lock file {lock_path} "
            f"held for more than {UPDATE_LOCK_TIMEOUT_SECONDS}s). Wait for it to "
            f"finish, or if the lock file is stale (previous update crashed), "
            f"remove it manually: rm {lock_path}",
        ) from exc


def _run_pip_upgrade() -> JsonObject:
    """Actually run ``pip install --upgrade wxflywheel`` and build a response."""
    before_version = __version__
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "wxflywheel"],
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=PIP_INSTALL_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired as exc:
        stdout_tail = _tail(exc.stdout)
        stderr_tail = _tail(exc.stderr)
        raise WxflywheelError(
            -5,
            f"pip install --upgrade wxflywheel timed out after "
            f"{PIP_INSTALL_TIMEOUT_SECONDS} seconds. This usually means the "
            f"network is extremely slow or PyPI is unreachable. Check network "
            f"connectivity and retry.",
            {
                "before_version": before_version,
                "python_executable": sys.executable,
                "stdout_tail": stdout_tail,
                "stderr_tail": stderr_tail,
            },
        ) from exc
    except OSError as exc:
        raise WxflywheelError(
            -6,
            f"Failed to invoke pip subprocess: {exc}. Is pip installed in the "
            f"current Python environment ({sys.executable})? Some minimal "
            f"Python distributions do not include pip; in that case the Agent "
            f"must install wxflywheel using the environment's native package "
            f"manager instead.",
        ) from exc

    stdout_tail = _tail(result.stdout)
    stderr_tail = _tail(result.stderr)

    if result.returncode != 0:
        raise WxflywheelError(
            -7,
            f"pip install --upgrade wxflywheel failed with returncode "
            f"{result.returncode}. Check stderr_tail for details. Common "
            f"causes: network failure, PyPI credentials required for private "
            f"index, version conflict with other installed packages, or "
            f"insufficient filesystem permissions on the site-packages "
            f"directory.",
            {
                "before_version": before_version,
                "returncode": result.returncode,
                "stdout_tail": stdout_tail,
                "stderr_tail": stderr_tail,
                "python_executable": sys.executable,
            },
        )

    after_version = _query_installed_version()

    hint = (
        f"wxflywheel upgraded from {before_version} to {after_version}. The "
        f"currently running process still has the OLD code in memory and will "
        f"continue to behave like version {before_version} until it exits. "
        f"Restart your Agent or run the next wxflywheel command from a fresh "
        f"process to actually use the new version."
    )

    return success_payload(
        {
            "before_version": before_version,
            "after_version": after_version,
            "success": True,
            "returncode": 0,
            "stdout_tail": stdout_tail,
            "stderr_tail": stderr_tail,
            "python_executable": sys.executable,
            "hint": hint,
        },
        message=f"Upgraded wxflywheel from {before_version} to {after_version}",
    )


def _query_installed_version() -> str:
    """Query pip to get the currently-installed wxflywheel version. Returns
    'unknown' on any failure (defensive: never raise from this helper)."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", "wxflywheel"],
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=PIP_SHOW_TIMEOUT_SECONDS,
        )
    except (OSError, subprocess.TimeoutExpired):
        return "unknown"

    if result.returncode != 0:
        return "unknown"

    for line in result.stdout.splitlines():
        if line.startswith("Version:"):
            return line.split(":", 1)[1].strip()
    return "unknown"


def _tail(text: Any) -> str:
    """Return the last MAX_OUTPUT_TAIL_CHARS of a possibly-None string."""
    if not isinstance(text, str):
        return ""
    return text[-MAX_OUTPUT_TAIL_CHARS:]
