"""``wxflywheel doctor`` — environment self-check diagnostic command.

Runs a battery of checks across 6 subsystems (Python runtime / platform / CLI
dependencies / cache directory / network connectivity / subprocess capability)
and returns a single JSON verdict that an AI Agent can use to decide whether
wxflywheel is ready to use on the current machine. Designed to be the FIRST
command an Agent runs after ``pip install wxflywheel`` — it surfaces any
environmental problem (missing deps, broken network, read-only home, wrong
Python version) in one shot rather than letting the Agent hit them one by one
while running real business commands.

Output contract: a single JSON object on stdout with ``checks`` (a list of 6
check results, each with name/status/details) plus ``verdict`` (top-level
"all systems operational" / "warnings present" / "critical failures") and
``environment`` (the full 10-key platform fingerprint).

This command does NOT require a WXFLYWHEEL_KEY and does NOT call any wx-ipad
backend — it is purely a local environment probe. It is safe to run in
sandboxes, air-gapped networks (the network check will fail gracefully), and
minimal Python distributions.
"""

from __future__ import annotations

import importlib.metadata
import subprocess
import sys
from typing import Any

import click
import requests

from wxflywheel import __version__
from wxflywheel.environment import cache_dir_info, collect_environment, env_var_summary
from wxflywheel.output import JsonObject, json_command, success_payload

MINIMUM_PYTHON = (3, 10)
REQUIRED_DEPS = ("click", "requests", "packaging", "filelock")

PYPI_PING_URL = "https://pypi.org/pypi/wxflywheel/json"
# Use GitHub's public API root (no auth required, always returns 200) instead
# of a wxflywheel-specific raw URL: the wxflywheel repo is private, so any
# raw.githubusercontent.com URL returns 404 for unauthenticated requests and
# would cause doctor to falsely warn every user. This endpoint only tests
# GitHub's network reachability, which is what the doctor actually cares
# about (the breaking-change detector in version_check.py gracefully degrades
# to SemVer-derived severity when the private-repo CHANGELOG is unreachable).
GITHUB_PING_URL = "https://api.github.com/"
NETWORK_PING_TIMEOUT_SECONDS = 5.0

STATUS_OK = "ok"
STATUS_WARN = "warn"
STATUS_FAIL = "fail"

VERDICT_ALL_OK = "all systems operational"
VERDICT_WARN = "warnings present (wxflywheel will work but may have degraded features)"
VERDICT_FAIL = "critical failures (wxflywheel cannot run reliably on this machine)"


@click.command(name="doctor")
@json_command
def doctor() -> JsonObject:
    """Run an environment self-check across 6 subsystems (Python runtime / platform identity / required dependencies / cache directory writability / PyPI + GitHub network reachability / subprocess spawn capability) and return a single JSON verdict. Designed as the FIRST command an AI Agent should run after 'pip install wxflywheel' on a new machine: it surfaces missing dependencies, broken networks, read-only home directories, wrong Python versions, and sandbox restrictions in one shot, rather than letting the Agent hit them one by one during real business commands. Returns {checks[] (6 entries with name/status/details), verdict (top-level summary string), environment (full 10-key platform fingerprint), env_vars (wxflywheel-relevant env var values)}. Each check's status is one of 'ok'/'warn'/'fail'; the top-level verdict aggregates them. Requires no WXFLYWHEEL_KEY and does NOT call any wx-ipad backend — purely a local probe, safe in air-gapped environments (network checks will return 'warn' not 'fail' on isolation). Agents should run doctor on first invocation, and also whenever a business command returns an unexpected error, to rule out environment issues before escalating to the user."""
    checks: list[dict[str, Any]] = []

    checks.append(_check_python_version())
    checks.append(_check_platform())
    checks.append(_check_dependencies())
    checks.append(_check_cache_directory())
    checks.append(_check_network())
    checks.append(_check_subprocess())

    verdict = _aggregate_verdict(checks)

    return success_payload(
        {
            "wxflywheel_version": __version__,
            "verdict": verdict,
            "checks": checks,
            "environment": collect_environment(),
            "env_vars": env_var_summary(),
        },
        message=verdict,
    )


# ---------------------------------------------------------------------------
# Individual check functions
# ---------------------------------------------------------------------------


def _check_python_version() -> dict[str, Any]:
    """Check that the running Python is >= the declared minimum."""
    current = sys.version_info[:3]
    ok = current >= MINIMUM_PYTHON
    return {
        "name": "python_version",
        "status": STATUS_OK if ok else STATUS_FAIL,
        "details": {
            "current": ".".join(str(x) for x in current),
            "minimum_required": ".".join(str(x) for x in MINIMUM_PYTHON),
            "satisfies_minimum": ok,
        },
    }


def _check_platform() -> dict[str, Any]:
    """Check platform identity. Always OK — this is informational."""
    env = collect_environment()
    return {
        "name": "platform",
        "status": STATUS_OK,
        "details": {
            "system": env["platform_system"],
            "release": env["platform_release"],
            "machine": env["platform_machine"],
            "is_windows": env["platform_system"].lower() == "windows",
            "is_macos": env["platform_system"].lower() == "darwin",
            "is_linux": env["platform_system"].lower() == "linux",
        },
    }


def _check_dependencies() -> dict[str, Any]:
    """Check that all required runtime dependencies are importable with the
    versions recorded by the installed distribution metadata."""
    results: dict[str, Any] = {}
    any_missing = False
    for dep in REQUIRED_DEPS:
        try:
            version = importlib.metadata.version(dep)
            results[dep] = {"installed": True, "version": version}
        except importlib.metadata.PackageNotFoundError:
            results[dep] = {"installed": False, "version": None}
            any_missing = True
    return {
        "name": "dependencies",
        "status": STATUS_FAIL if any_missing else STATUS_OK,
        "details": results,
    }


def _check_cache_directory() -> dict[str, Any]:
    """Check that the version-check cache directory is writable."""
    # Delayed import to avoid circular: version_check -> output -> environment
    from wxflywheel.version_check import cache_dir

    info = cache_dir_info(cache_dir())
    writable = info["writable"]
    return {
        "name": "cache_directory",
        "status": STATUS_OK if writable else STATUS_WARN,
        "details": info,
    }


def _check_network() -> dict[str, Any]:
    """Check reachability of PyPI (for version checks) and GitHub raw
    (for CHANGELOG breaking-change detection). Network failure is WARN not
    FAIL because wxflywheel's core business commands work offline against
    the wx-ipad backend — only version checks need these two hosts."""
    pypi = _ping(PYPI_PING_URL)
    github = _ping(GITHUB_PING_URL)
    all_ok = pypi["reachable"] and github["reachable"]
    return {
        "name": "network",
        "status": STATUS_OK if all_ok else STATUS_WARN,
        "details": {
            "pypi": pypi,
            "github": github,
            "note": "network failures are WARN not FAIL because wxflywheel's business commands work offline — only update-notification checks need PyPI/GitHub.",
        },
    }


def _ping(url: str) -> dict[str, Any]:
    """Attempt a GET request with a short timeout; return a dict summary."""
    try:
        resp = requests.get(url, timeout=NETWORK_PING_TIMEOUT_SECONDS)
        return {
            "url": url,
            "reachable": resp.status_code < 400,
            "status_code": resp.status_code,
            "error": None,
        }
    except requests.RequestException as exc:
        return {
            "url": url,
            "reachable": False,
            "status_code": None,
            "error": f"{type(exc).__name__}: {exc}",
        }


def _check_subprocess() -> dict[str, Any]:
    """Check that we can spawn a subprocess using the current Python. This
    validates that 'wxflywheel self update' and the background version-check
    worker will be able to run. Uses a minimal, fast command (``python -c
    pass``) with a short timeout."""
    try:
        result = subprocess.run(
            [sys.executable, "-c", "pass"],
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=10,
        )
        ok = result.returncode == 0
        return {
            "name": "subprocess",
            "status": STATUS_OK if ok else STATUS_FAIL,
            "details": {
                "python_executable": sys.executable,
                "can_spawn": ok,
                "returncode": result.returncode,
                "note": "this validates 'wxflywheel self update' and the background version-check worker will be able to run.",
            },
        }
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {
            "name": "subprocess",
            "status": STATUS_FAIL,
            "details": {
                "python_executable": sys.executable,
                "can_spawn": False,
                "error": f"{type(exc).__name__}: {exc}",
                "note": "cannot spawn subprocess — 'wxflywheel self update' will not work; Agent must use 'pip install --upgrade wxflywheel' from the shell instead.",
            },
        }


def _aggregate_verdict(checks: list[dict[str, Any]]) -> str:
    """Roll up individual check statuses into a single top-level verdict."""
    has_fail = any(check["status"] == STATUS_FAIL for check in checks)
    has_warn = any(check["status"] == STATUS_WARN for check in checks)
    if has_fail:
        return VERDICT_FAIL
    if has_warn:
        return VERDICT_WARN
    return VERDICT_ALL_OK
