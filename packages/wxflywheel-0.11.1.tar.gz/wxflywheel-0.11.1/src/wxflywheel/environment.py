"""Runtime environment fingerprint for cross-platform diagnostics.

Captures a compact, JSON-serializable snapshot of the platform, Python
interpreter, and locale settings that wxflywheel is running in. Used by:

1. ``wxflywheel doctor`` — top-level diagnostic command (explicit, user-run)
2. ``WxflywheelError.data._environment`` — automatic attachment to error
   responses so that any failure JSON carries enough context for an Agent
   (or the upstream wx-ipad maintainer) to diagnose platform-specific issues
   without having to ask "what OS are you on?"

Design rules:

- **Never fails**. Every attribute lookup is wrapped in a broad except; if
  anything cannot be determined, the field becomes the string "unknown" (not
  None, not missing) so the schema stays stable for Agent parsers.
- **No PII**. We collect OS family / kernel / arch / Python / locale only —
  no username, hostname, MAC, IP, user home path, or working directory.
- **Compact**. The whole fingerprint is <300 bytes; attaching it to every
  error response has negligible bandwidth cost.
- **Cross-platform**. All values come from the stdlib (sys, platform, locale,
  os) so there are no extra dependencies and no platform-specific code paths.
"""

from __future__ import annotations

import locale
import os
import platform
import sys
from typing import Any


def _safe(fn: Any) -> str:
    """Call a zero-arg function, return str(result) or 'unknown' on any error."""
    try:
        value = fn()
    except Exception:
        return "unknown"
    if value is None or value == "":
        return "unknown"
    return str(value)


def collect_environment() -> dict[str, str]:
    """Return a stable 10-key environment fingerprint.

    All values are strings; unknown values become ``"unknown"`` (never None).
    The schema is guaranteed stable across Python versions and platforms.
    """
    return {
        "platform_system": _safe(platform.system),
        "platform_release": _safe(platform.release),
        "platform_machine": _safe(platform.machine),
        "platform_version": _safe(platform.version),
        "python_version": _safe(platform.python_version),
        "python_implementation": _safe(platform.python_implementation),
        "python_executable": _safe(lambda: sys.executable),
        "locale_preferred_encoding": _safe(
            lambda: locale.getpreferredencoding(False)
        ),
        "stdout_encoding": _safe(lambda: sys.stdout.encoding),
        "filesystem_encoding": _safe(sys.getfilesystemencoding),
    }


def describe_short() -> str:
    """Return a one-line human-readable summary, e.g.
    ``Darwin 23.6.0 arm64 / Python 3.11.5 (CPython) / encoding utf-8``.
    Used in error messages where a one-liner is better than a dict."""
    env = collect_environment()
    return (
        f"{env['platform_system']} {env['platform_release']} "
        f"{env['platform_machine']} / "
        f"Python {env['python_version']} ({env['python_implementation']}) / "
        f"encoding {env['locale_preferred_encoding']}"
    )


def cache_dir_info(cache_dir_path: Any) -> dict[str, Any]:
    """Return diagnostic info about a cache directory path.

    Used by ``wxflywheel doctor`` and potentially by error reports. Returns
    a dict with {path, exists, writable, error} — error is null on success,
    or a string describing why the directory cannot be written.
    """
    result: dict[str, Any] = {
        "path": str(cache_dir_path),
        "exists": False,
        "writable": False,
        "error": None,
    }
    try:
        path = cache_dir_path
        result["exists"] = path.exists()
        # Try to create it and write a probe file
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".wxflywheel_write_probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        result["writable"] = True
    except OSError as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def env_var_summary() -> dict[str, str]:
    """Return wxflywheel-relevant environment variable values.

    Does NOT include WXFLYWHEEL_KEY (secret) or WXFLYWHEEL_HOST (may contain
    IP addresses). Only includes flags that affect behavior. Values that are
    unset become ``"<unset>"`` for a stable 4-key schema.
    """

    def _get(name: str) -> str:
        raw = os.environ.get(name)
        return raw if raw is not None else "<unset>"

    return {
        "WXFLYWHEEL_NO_META": _get("WXFLYWHEEL_NO_META"),
        "WXFLYWHEEL_WORKER": _get("WXFLYWHEEL_WORKER"),
        "WXFLYWHEEL_CACHE_DIR": _get("WXFLYWHEEL_CACHE_DIR"),
        "LANG": _get("LANG"),
    }
