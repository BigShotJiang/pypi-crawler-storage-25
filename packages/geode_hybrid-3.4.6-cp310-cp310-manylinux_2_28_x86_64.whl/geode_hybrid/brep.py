#
# Copyright (c) 2019 - 2026 Geode-solutions. All rights reserved.
#

import opengeode
import geode_common
import geode_simplex

from .lib64.geode_hybrid_py_brep import *

HybridBRepLibrary.initialize()
