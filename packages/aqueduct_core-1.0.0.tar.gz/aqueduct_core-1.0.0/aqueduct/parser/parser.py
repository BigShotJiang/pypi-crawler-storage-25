"""Main Parser entrypoint.

Orchestrates: YAML load → Pydantic validation → context resolution →
graph validation → AST construction.

Output is a frozen Blueprint dataclass — the single input to the Compiler.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from aqueduct.parser.graph import detect_cycles, validate_spillway_targets
from aqueduct.parser.models import (
    AgentConfig,
    Blueprint,
    ContextRegistry,
    Edge,
    GuardrailsConfig,
    Module,
    RetryPolicy,
)
from aqueduct.parser.resolver import build_context_map, resolve_value
from aqueduct.parser.schema import BlueprintSchema


class ParseError(Exception):
    """Raised for any Blueprint parse, validation, or resolution failure."""


def _format_validation_error(exc: ValidationError, raw: dict | None = None) -> str:
    """Format Pydantic ValidationError into a readable message."""
    errors = exc.errors(include_url=False)
    n = len(errors)
    header = f"{n} validation error{'s' if n != 1 else ''} in Blueprint:"
    lines = [header]
    modules_raw = raw.get("modules", []) if raw else []
    for e in errors:
        loc = e["loc"]
        loc_parts: list[str] = []
        for i, part in enumerate(loc):
            if part == "modules" and i == 0:
                loc_parts.append("module")
            elif isinstance(part, int) and i == 1 and loc[0] == "modules":
                mod = modules_raw[part] if part < len(modules_raw) else {}
                name = mod.get("id") or mod.get("label") or f"#{part}"
                loc_parts.append(f' "{name}"')
            elif isinstance(part, int):
                loc_parts.append(f"[{part}]")
            elif loc_parts:
                loc_parts.append(f" → {part}")
            else:
                loc_parts.append(str(part))
        lines.append(f"  • {''.join(loc_parts)} — {e['msg']}")
    return "\n".join(lines)


def parse(
    path: str | Path,
    profile: str | None = None,
    cli_overrides: dict[str, str] | None = None,
) -> Blueprint:
    """Parse a Blueprint YAML file and return a validated, resolved AST.

    Args:
        path:          Path to the Blueprint YAML file.
        profile:       Active context profile name (--profile flag).
        cli_overrides: Key=value overrides from --ctx CLI flags.

    Returns:
        A frozen Blueprint dataclass with all Tier 0 context resolved.

    Raises:
        ParseError: On any YAML, schema, context, or graph validation failure.
    """
    path = Path(path)

    # ── 1. Load YAML ──────────────────────────────────────────────────────────
    try:
        raw: Any = yaml.safe_load(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise ParseError(f"Blueprint file not found: {path}")
    except yaml.YAMLError as exc:
        raise ParseError(f"Invalid YAML in {path.name}: {exc}") from exc

    if not isinstance(raw, dict):
        raise ParseError(f"Blueprint must be a YAML mapping, got {type(raw).__name__}")

    # ── 2. Pydantic schema validation ─────────────────────────────────────────
    try:
        validated = BlueprintSchema.model_validate(raw)
    except ValidationError as exc:
        raise ParseError(_format_validation_error(exc, raw)) from exc

    # ── 3. Tier 0 context resolution ──────────────────────────────────────────
    try:
        ctx_map = build_context_map(
            context_dict=validated.context,
            profile=profile,
            profiles=validated.context_profiles,
            cli_overrides=cli_overrides,
        )
    except ValueError as exc:
        raise ParseError(f"Context resolution failed: {exc}") from exc

    # ── 4. Build Module dataclasses (with config substitution) ────────────────
    try:
        modules = tuple(
            Module(
                id=m.id,
                type=m.type,
                label=m.label,
                description=m.description,
                tags=tuple(m.tags),
                config=resolve_value(m.config, ctx_map),
                on_failure=m.on_failure,
                on_failure_webhook=m.on_failure_webhook,
                checkpoint=m.checkpoint,
                spillway=m.spillway,
                depends_on=tuple(m.depends_on),
                attach_to=m.attach_to,
                ref=m.ref,
                context_override=resolve_value(m.context_override, ctx_map),
            )
            for m in validated.modules
        )
    except ValueError as exc:
        raise ParseError(f"Module config resolution failed: {exc}") from exc

    # ── 5. Build Edge dataclasses ─────────────────────────────────────────────
    edges = tuple(
        Edge(
            from_id=e.from_id,
            to_id=e.to,
            port=e.port,
            error_types=tuple(e.error_types),
        )
        for e in validated.edges
    )

    # ── 6. Graph validation ───────────────────────────────────────────────────
    try:
        cycle_nodes = detect_cycles(list(modules), list(edges))
        if cycle_nodes:
            raise ParseError(
                f"Cycle detected in module graph. Involved modules: {cycle_nodes}"
            )
        validate_spillway_targets(list(modules))
    except ValueError as exc:
        raise ParseError(str(exc)) from exc

    # ── 7. Assemble final Blueprint AST ───────────────────────────────────────
    rp = validated.retry_policy
    retry_policy = RetryPolicy(
        max_attempts=rp.max_attempts,
        backoff_strategy=rp.backoff.strategy,
        backoff_base_seconds=rp.backoff.base_seconds,
        backoff_max_seconds=rp.backoff.max_seconds,
        jitter=rp.backoff.jitter,
        on_exhaustion=rp.on_exhaustion,
        transient_errors=tuple(rp.transient_errors),
        non_transient_errors=tuple(rp.non_transient_errors),
        deadline_seconds=rp.deadline_seconds,
    )

    agent = AgentConfig(
        approval_mode=validated.agent.approval_mode,
        on_pending_patches=validated.agent.on_pending_patches,
        model=validated.agent.model,
        aggressive_max_patches=validated.agent.aggressive_max_patches,
        provider=validated.agent.provider,
        base_url=validated.agent.base_url,
        provider_options=validated.agent.provider_options,
        guardrails=GuardrailsConfig(
            forbidden_ops=tuple(validated.agent.guardrails.forbidden_ops),
            allowed_paths=tuple(validated.agent.guardrails.allowed_paths),
            heal_on_errors=tuple(validated.agent.guardrails.heal_on_errors),
            never_heal_errors=tuple(validated.agent.guardrails.never_heal_errors),
        ),
        prompt_context=validated.agent.prompt_context,
        timeout=validated.agent.timeout,
        max_reprompts=validated.agent.max_reprompts,
        confidence_threshold=validated.agent.confidence_threshold,
        on_heal_failure=validated.agent.on_heal_failure,
        max_heal_attempts_per_hour=validated.agent.max_heal_attempts_per_hour,
        patch_validation=validated.agent.patch_validation,
        block_on_explain_regression=validated.agent.block_on_explain_regression,
    )

    # Tier-0 resolution applies here too (parity with module config /
    # context_override) — ${ENV:-default} / ${ctx.*} in spark_config and
    # macros must be substituted, Spark/macros do no var expansion (ISSUE-027).
    # Wrapped so a bad ${ctx.*} surfaces as ParseError, not raw ValueError.
    try:
        resolved_spark_config = resolve_value(dict(validated.spark_config), ctx_map)
        resolved_macros = resolve_value(dict(validated.macros), ctx_map)
    except ValueError as exc:
        raise ParseError(f"spark_config / macros resolution failed: {exc}") from exc

    return Blueprint(
        aqueduct_version=validated.aqueduct,
        id=validated.id,
        name=validated.name,
        description=validated.description,
        context=ContextRegistry(values=ctx_map),
        modules=modules,
        edges=edges,
        spark_config=resolved_spark_config,
        retry_policy=retry_policy,
        agent=agent,
        udf_registry=tuple(validated.udf_registry),
        macros=resolved_macros,
        required_context=tuple(validated.required_context),
        checkpoint=validated.checkpoint,
    )
