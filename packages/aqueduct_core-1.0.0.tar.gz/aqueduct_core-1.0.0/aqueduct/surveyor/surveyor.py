"""Surveyor — monitors blueprint execution and persists observability signals.

Lifecycle (called from CLI):

    surveyor = Surveyor(manifest, store_dir=Path(".aqueduct"), webhook_url=...)
    surveyor.start(run_id)          # create DB tables, record run start
    result = execute(manifest, spark, run_id=run_id)
    failure_ctx = surveyor.record(result)   # persist result, fire webhook if failed
    surveyor.stop()                 # close DB connection

DuckDB schema
─────────────
  run_records        — one row per run (start + final status)
  failure_contexts   — one row per failed run (FailureContext document)

Phase 5 scope: logging + webhook only.  LLM patch loop wired in Phase 7.
"""

from __future__ import annotations

import json
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

import logging

from aqueduct.compiler.models import Manifest
from aqueduct.executor.models import ExecutionResult
from aqueduct.surveyor.models import FailureContext, RunRecord
from aqueduct.surveyor.webhook import fire_webhook

if TYPE_CHECKING:
    from aqueduct.stores import ObservabilityStore, StoreBundle

logger = logging.getLogger(__name__)

# ── DDL ───────────────────────────────────────────────────────────────────────

_DDL = """
CREATE TABLE IF NOT EXISTS run_records (
    run_id        VARCHAR PRIMARY KEY,
    blueprint_id  VARCHAR NOT NULL,
    status        VARCHAR NOT NULL,
    started_at    TIMESTAMPTZ NOT NULL,
    finished_at   TIMESTAMPTZ,
    module_results JSON
);

CREATE TABLE IF NOT EXISTS failure_contexts (
    run_id         VARCHAR PRIMARY KEY,
    blueprint_id   VARCHAR NOT NULL,
    failed_module  VARCHAR NOT NULL,
    error_message  VARCHAR NOT NULL,
    stack_trace    VARCHAR,
    manifest_json  JSON,
    provenance_json JSON,
    started_at     TIMESTAMPTZ NOT NULL,
    finished_at    TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS healing_outcomes (
    id           VARCHAR PRIMARY KEY,
    run_id       VARCHAR NOT NULL,
    failed_module VARCHAR,
    failure_category VARCHAR,
    model        VARCHAR,
    patch_id     VARCHAR,
    confidence   DOUBLE PRECISION,
    patch_applied BOOLEAN,
    run_success_after_patch BOOLEAN,
    applied_at   VARCHAR
);

CREATE TABLE IF NOT EXISTS patch_simulation (
    id           VARCHAR PRIMARY KEY,
    run_id       VARCHAR,
    blueprint_id VARCHAR,
    patch_id     VARCHAR NOT NULL,
    gate         VARCHAR NOT NULL,
    status       VARCHAR NOT NULL,
    detail       VARCHAR,
    sample_rows  BIGINT,
    duration_ms  BIGINT,
    recorded_at  VARCHAR NOT NULL
);
"""

_SIGNAL_OVERRIDES_DDL = """
CREATE TABLE IF NOT EXISTS signal_overrides (
    signal_id     VARCHAR PRIMARY KEY,
    passed        BOOLEAN NOT NULL,
    error_message VARCHAR,
    set_at        TIMESTAMPTZ NOT NULL
);
"""

_EXPLAIN_SNAPSHOT_DDL = """
CREATE TABLE IF NOT EXISTS explain_snapshot (
    blueprint_id     VARCHAR NOT NULL,
    run_id           VARCHAR NOT NULL,
    module_id        VARCHAR NOT NULL,
    captured_at      VARCHAR NOT NULL,
    exchange_count   INTEGER NOT NULL,
    python_udf_count INTEGER NOT NULL,
    broadcast_count  INTEGER NOT NULL,
    plan_text        VARCHAR NOT NULL,
    PRIMARY KEY (blueprint_id, run_id, module_id)
);
"""

# ── Helpers ───────────────────────────────────────────────────────────────────

def _utcnow() -> datetime:
    return datetime.now(tz=timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.isoformat()


def _first_failed_module(result: ExecutionResult) -> str:
    """Return the module_id of the first failing module, or '_executor'."""
    for mr in result.module_results:
        if mr.status == "error":
            return mr.module_id
    return "_executor"


def _first_error_message(result: ExecutionResult, exc: Exception | None) -> str:
    for mr in result.module_results:
        if mr.status == "error" and mr.error:
            return mr.error
    if exc is not None:
        return str(exc)
    return "unknown error"


def _first_error_type(result: ExecutionResult) -> str | None:
    """Return the error_type of the first failing module, or None for infra errors."""
    for mr in result.module_results:
        if mr.status == "error":
            return getattr(mr, "error_type", None)
    return None


# ── Public API ────────────────────────────────────────────────────────────────

class Surveyor:
    """Observability recorder for a single blueprint instance.

    One Surveyor per ``aqueduct run`` invocation.  Not thread-safe itself —
    the webhook is fire-and-forget in a daemon thread; everything else is
    single-threaded.
    """

    def __init__(
        self,
        manifest: Manifest,
        store_dir: Path,
        webhook_url: str | None = None,
        webhook_config: "WebhookEndpointConfig | None" = None,  # type: ignore[name-defined]  # noqa: F821
        blueprint_path: Path | None = None,
        patches_dir: Path | None = None,
        stores: "StoreBundle | None" = None,
    ) -> None:
        """Initialise the Surveyor.

        Args:
            stores: Optional pre-built `StoreBundle`. When None (the typical
                CLI path), the bundle is constructed lazily on `start()` from
                a default DuckDB layout under `store_dir`. The `stores=`
                parameter exists for the Phase 28 case where the CLI hands
                in a Postgres-backed bundle.
        """
        from aqueduct.config import WebhookEndpointConfig
        self._manifest = manifest
        self._store_dir = store_dir
        if webhook_config is not None:
            self._webhook_config: WebhookEndpointConfig | None = webhook_config
        elif webhook_url is not None:
            self._webhook_config = WebhookEndpointConfig(url=webhook_url)
        else:
            self._webhook_config = None
        self._blueprint_path = blueprint_path
        self._patches_dir = patches_dir or Path("patches")
        self._run_id: str | None = None
        self._started_at: datetime | None = None
        self._stores: "StoreBundle | None" = stores
        self._observability: "ObservabilityStore | None" = stores.observability if stores is not None else None
        self._started: bool = False  # DDL/migrations applied once per Surveyor.start()

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def start(self, run_id: str) -> None:
        """Open the configured observability store and record run start.

        Creates parent directories for DuckDB-backed stores; for Postgres
        the `observability` schema is auto-created on the first `connect()`.

        Args:
            run_id: The UUID generated by the CLI / Executor for this run.
        """
        self._run_id = run_id
        self._started_at = _utcnow()
        self._store_dir.mkdir(parents=True, exist_ok=True)

        # Construct a default DuckDB bundle when the caller did not hand one in.
        # The CLI path always builds and passes one via Phase 28's get_stores();
        # this fallback keeps direct programmatic callers (tests, scripts) working.
        if self._observability is None:
            from aqueduct.stores.duckdb_ import DuckDBObservabilityStore
            self._observability = DuckDBObservabilityStore(self._store_dir / "observability.db")

        with self._observability.connect() as cur:
            cur.execute(_DDL)
            # Additive migrations — safe to run on existing DBs (idempotent).
            try:
                cur.execute(
                    "ALTER TABLE failure_contexts ADD COLUMN IF NOT EXISTS provenance_json JSON"
                )
            except Exception:
                # Older DuckDB versions may not support IF NOT EXISTS on ALTER.
                pass
            try:
                # healing_outcomes.id was INTEGER pre-migration; UUID inserts need VARCHAR.
                col_type = cur.execute(
                    "SELECT data_type FROM information_schema.columns "
                    "WHERE table_name='healing_outcomes' AND column_name='id'"
                ).fetchone()
                if col_type and col_type[0].upper() == "INTEGER":
                    cur.execute("ALTER TABLE healing_outcomes DROP COLUMN id")
                    cur.execute("ALTER TABLE healing_outcomes ADD COLUMN id VARCHAR")
            except Exception:
                pass

            cur.execute(_SIGNAL_OVERRIDES_DDL)
            cur.execute(_EXPLAIN_SNAPSHOT_DDL)

            cur.execute(
                """
                INSERT INTO run_records
                    (run_id, blueprint_id, status, started_at, finished_at, module_results)
                VALUES (?, ?, 'running', ?, NULL, '[]')
                ON CONFLICT (run_id) DO UPDATE SET
                    blueprint_id   = EXCLUDED.blueprint_id,
                    status         = EXCLUDED.status,
                    started_at     = EXCLUDED.started_at,
                    finished_at    = EXCLUDED.finished_at,
                    module_results = EXCLUDED.module_results
                """,
                [run_id, self._manifest.blueprint_id, _iso(self._started_at)],
            )

        self._started = True

    def record(
        self,
        result: ExecutionResult,
        exc: Exception | None = None,
        patched: bool = False,
    ) -> FailureContext | None:
        """Persist the final run outcome.

        Updates the ``run_records`` row to its terminal status.  On failure,
        also inserts a ``failure_contexts`` row and (if configured) fires a
        webhook in a daemon thread.

        Args:
            result: ``ExecutionResult`` from the Executor.
            exc:    Optional unhandled ``ExecuteError`` that escaped execute().
                    Used to populate ``stack_trace`` when the exception was not
                    caught inside the Executor loop.

        Returns:
            ``FailureContext`` if the run failed, else ``None``.
        """
        if not self._started or self._observability is None or self._run_id is None:
            raise RuntimeError("Surveyor.start() must be called before record()")

        finished_at = _utcnow()
        module_results_json = json.dumps(
            [{"module_id": r.module_id, "status": r.status, "error": r.error}
             for r in result.module_results]
        )

        effective_status = "patched" if (patched and result.status == "success") else result.status
        with self._observability.connect() as cur:
            cur.execute(
                """
                UPDATE run_records
                SET status = ?, finished_at = ?, module_results = ?
                WHERE run_id = ?
                """,
                [effective_status, _iso(finished_at), module_results_json, result.run_id],
            )

        if result.status == "success":
            return None

        # ── Build FailureContext ───────────────────────────────────────────────
        stack_trace: str | None = None
        if exc is not None:
            stack_trace = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))

        # Build provenance slice: failed module + full context block
        provenance_json: str | None = None
        pmap = getattr(self._manifest, "provenance_map", None)
        if pmap is not None:
            failed_mid = _first_failed_module(result)
            failed_mod_prov = pmap.for_module(failed_mid)
            prov_slice = {
                "blueprint_id": pmap.blueprint_id,
                "blueprint_path": pmap.blueprint_path,
                "failed_module": failed_mod_prov.to_dict() if failed_mod_prov else None,
                "context": {k: v.to_dict() for k, v in pmap.context.items()},
            }
            provenance_json = json.dumps(prov_slice, indent=2)

        blueprint_source_yaml: str | None = None
        if self._blueprint_path is not None:
            try:
                blueprint_source_yaml = self._blueprint_path.read_text(encoding="utf-8")
            except OSError:
                pass

        ctx = FailureContext(
            run_id=result.run_id,
            blueprint_id=self._manifest.blueprint_id,
            failed_module=_first_failed_module(result),
            error_message=_first_error_message(result, exc),
            stack_trace=stack_trace,
            manifest_json=json.dumps(self._manifest.to_dict()),
            started_at=_iso(self._started_at),  # type: ignore[arg-type]
            finished_at=_iso(finished_at),
            provenance_json=provenance_json,
            blueprint_source_yaml=blueprint_source_yaml,
            error_type=_first_error_type(result),
        )

        with self._observability.connect() as cur:
            cur.execute(
                """
                INSERT INTO failure_contexts
                    (run_id, blueprint_id, failed_module, error_message,
                     stack_trace, manifest_json, provenance_json, started_at, finished_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (run_id) DO UPDATE SET
                    blueprint_id    = EXCLUDED.blueprint_id,
                    failed_module   = EXCLUDED.failed_module,
                    error_message   = EXCLUDED.error_message,
                    stack_trace     = EXCLUDED.stack_trace,
                    manifest_json   = EXCLUDED.manifest_json,
                    provenance_json = EXCLUDED.provenance_json,
                    started_at      = EXCLUDED.started_at,
                    finished_at     = EXCLUDED.finished_at
                """,
                [
                    ctx.run_id,
                    ctx.blueprint_id,
                    ctx.failed_module,
                    ctx.error_message,
                    ctx.stack_trace,
                    ctx.manifest_json,
                    ctx.provenance_json,
                    ctx.started_at,
                    ctx.finished_at,
                ],
            )

        if self._webhook_config:
            attempt = sum(1 for mr in result.module_results if mr.status == "error")
            template_vars = {
                "run_id": ctx.run_id,
                "blueprint_id": ctx.blueprint_id,
                "blueprint_name": self._manifest.name,
                "failed_module": ctx.failed_module,
                "error_message": ctx.error_message,
                "error_type": (ctx.stack_trace or "").splitlines()[0] if ctx.stack_trace else "ExecuteError",
                "started_at": ctx.started_at,
                "attempt": str(attempt),
            }
            fire_webhook(self._webhook_config, ctx.to_dict(), template_vars)

        return ctx

    def record_healing_outcome(
        self,
        *,
        run_id: str,
        failed_module: str | None,
        failure_category: str | None,
        model: str | None,
        patch_id: str | None,
        confidence: float | None,
        patch_applied: bool,
        run_success_after_patch: bool,
    ) -> None:
        """Persist one LLM healing attempt to healing_outcomes table."""
        if self._observability is None:
            return
        import datetime as _dt
        import uuid as _uuid
        with self._observability.connect() as cur:
            cur.execute(
                """
                INSERT INTO healing_outcomes
                (id, run_id, failed_module, failure_category, model, patch_id, confidence,
                 patch_applied, run_success_after_patch, applied_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    str(_uuid.uuid4()),
                    run_id, failed_module, failure_category, model, patch_id, confidence,
                    patch_applied, run_success_after_patch,
                    _dt.datetime.now(_dt.timezone.utc).isoformat(),
                ],
            )

    def record_patch_simulation(
        self,
        *,
        patch_id: str,
        gate: str,
        status: str,
        detail: str | None = None,
        sample_rows: int | None = None,
        duration_ms: int | None = None,
        run_id: str | None = None,
        blueprint_id: str | None = None,
    ) -> None:
        """Append one row to `observability.patch_simulation`.

        Called by Phase 29a `aqueduct patch preview` and by the auto/aggressive
        self-healing loop after each Gate 2 (lineage diff) and Gate 3 (sandbox
        replay) evaluation. The table is the audit trail for "why we accepted
        or rejected this patch without running the full pipeline."

        Args:
            patch_id:     PatchSpec identifier — matches `patches/applied/{id}.json`.
            gate:         `"lineage"` (lineage) or `"sandbox"` (sandbox replay).
            status:       `"pass"` | `"fail"` | `"warn"` | `"skip"`.
            detail:       Free-text reason — failing rule, missing column, etc.
            sample_rows:  Rows processed in the sandbox replay (NULL for gate2).
            duration_ms:  Wall-clock for the gate evaluation.
            run_id:       Originating failed run if invoked from the healing loop.
            blueprint_id: Blueprint identifier; defaults to the Surveyor's manifest id.
        """
        if self._observability is None:
            return
        import datetime as _dt
        import uuid as _uuid
        with self._observability.connect() as cur:
            cur.execute(
                """
                INSERT INTO patch_simulation
                  (id, run_id, blueprint_id, patch_id, gate, status, detail,
                   sample_rows, duration_ms, recorded_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    str(_uuid.uuid4()),
                    run_id,
                    blueprint_id or getattr(self._manifest, "blueprint_id", None),
                    patch_id,
                    gate,
                    status,
                    detail,
                    sample_rows,
                    duration_ms,
                    _dt.datetime.now(_dt.timezone.utc).isoformat(),
                ],
            )

    def record_explain_snapshot(
        self,
        *,
        run_id: str,
        module_id: str,
        exchange_count: int,
        python_udf_count: int,
        broadcast_count: int,
        plan_text: str,
        blueprint_id: str | None = None,
        keep_last_n: int = 5,
    ) -> None:
        """Append one row to `observability.explain_snapshot` for Gate 4 baseline.

        Phase 29b — physical-plan regression check. Captured per-module after
        each successful module execution. Rolling baseline: keeps the most
        recent `keep_last_n` runs per (blueprint_id, module_id), older rows
        are pruned to bound storage.

        Args:
            run_id:          Originating run.
            module_id:       Module the plan belongs to.
            exchange_count:  Count of `Exchange` nodes (shuffle proxy).
            python_udf_count:Count of `BatchEvalPython` nodes.
            broadcast_count: Count of `BroadcastExchange` nodes.
            plan_text:       Full `explain(mode="formatted")` text for debugging.
            blueprint_id:    Override Surveyor's manifest id.
            keep_last_n:     Pruning bound per (blueprint_id, module_id).
        """
        if self._observability is None:
            return
        import datetime as _dt
        bp_id = blueprint_id or getattr(self._manifest, "blueprint_id", None)
        if not bp_id:
            return
        with self._observability.connect() as cur:
            cur.execute(
                """
                INSERT INTO explain_snapshot
                  (blueprint_id, run_id, module_id, captured_at,
                   exchange_count, python_udf_count, broadcast_count, plan_text)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (blueprint_id, run_id, module_id) DO UPDATE SET
                    captured_at      = EXCLUDED.captured_at,
                    exchange_count   = EXCLUDED.exchange_count,
                    python_udf_count = EXCLUDED.python_udf_count,
                    broadcast_count  = EXCLUDED.broadcast_count,
                    plan_text        = EXCLUDED.plan_text
                """,
                [
                    bp_id, run_id, module_id,
                    _dt.datetime.now(_dt.timezone.utc).isoformat(),
                    exchange_count, python_udf_count, broadcast_count, plan_text,
                ],
            )
            # Rolling prune — keep last N run_ids per (blueprint_id, module_id)
            try:
                rows = cur.execute(
                    """
                    SELECT run_id FROM explain_snapshot
                    WHERE blueprint_id = ? AND module_id = ?
                    ORDER BY captured_at DESC
                    """,
                    [bp_id, module_id],
                ).fetchall()
                if len(rows) > keep_last_n:
                    stale = [r[0] for r in rows[keep_last_n:]]
                    for rid in stale:
                        cur.execute(
                            "DELETE FROM explain_snapshot WHERE blueprint_id=? AND module_id=? AND run_id=?",
                            [bp_id, module_id, rid],
                        )
            except Exception:
                pass

    def latest_explain_snapshots(
        self,
        *,
        blueprint_id: str | None = None,
    ) -> dict[str, dict]:
        """Return most-recent per-module snapshot for the blueprint.

        Returns mapping `module_id` → `{exchange_count, python_udf_count,
        broadcast_count, plan_text, run_id, captured_at}`. Used by the explain gate
        as the pre-patch baseline.
        """
        if self._observability is None:
            return {}
        bp_id = blueprint_id or getattr(self._manifest, "blueprint_id", None)
        if not bp_id:
            return {}
        out: dict[str, dict] = {}
        with self._observability.connect() as cur:
            rows = cur.execute(
                """
                SELECT module_id, run_id, captured_at, exchange_count,
                       python_udf_count, broadcast_count, plan_text
                FROM explain_snapshot
                WHERE blueprint_id = ?
                ORDER BY module_id, captured_at DESC
                """,
                [bp_id],
            ).fetchall()
        seen: set[str] = set()
        for r in rows:
            mid = r[0]
            if mid in seen:
                continue
            seen.add(mid)
            out[mid] = {
                "run_id": r[1],
                "captured_at": r[2],
                "exchange_count": r[3],
                "python_udf_count": r[4],
                "broadcast_count": r[5],
                "plan_text": r[6],
            }
        return out

    def count_recent_heal_attempts(self, within_minutes: int = 60) -> int:
        """Return the number of LLM healing attempts recorded in this blueprint's
        `healing_outcomes` table within the last ``within_minutes`` minutes.

        Used by the CLI self-healing loop to enforce a configurable spend-cap
        (``agent.max_heal_attempts_per_hour``). Each blueprint has its own
        `observability.db`, so the count is implicitly scoped to this blueprint without
        a JOIN against `run_records`.

        Returns 0 when the connection is not open (e.g. before `start()`).
        applied_at is ISO-8601 UTC which sorts lexicographically — direct
        string comparison is safe.
        """
        if self._observability is None:
            return 0
        import datetime as _dt
        threshold = (_dt.datetime.now(_dt.timezone.utc) - _dt.timedelta(minutes=within_minutes)).isoformat()
        try:
            with self._observability.connect() as cur:
                row = cur.execute(
                    "SELECT COUNT(*) FROM healing_outcomes WHERE applied_at >= ?",
                    [threshold],
                ).fetchone()
            return int(row[0]) if row else 0
        except Exception:
            return 0

    def evaluate_regulator(self, regulator_id: str) -> bool:
        """Evaluate whether a Regulator's gate is open (True) or closed (False).

        Finds the Probe wired to the Regulator via a signal-port edge, queries
        the latest ``passed`` field from its signals in the current run, and
        applies boolean coercion per spec:

          - ``passed=True`` or key absent or no signals → open (True)
          - ``passed=False``                            → closed (False)
          - any exception                               → open (True)

        Args:
            regulator_id: Module ID of the active Regulator to evaluate.

        Returns:
            True if the gate is open (downstream should execute).
            False if the gate is closed (on_block applies).
        """
        if self._run_id is None or self._observability is None:
            return True  # start() not called

        # Find the probe wired to this regulator's signal port
        probe_ids = [
            e.from_id
            for e in self._manifest.edges
            if e.to_id == regulator_id and e.port == "signal"
        ]
        if not probe_ids:
            return True  # no signal source → open

        probe_id = probe_ids[0]

        try:
            with self._observability.connect() as cur:
                cur.execute(_SIGNAL_OVERRIDES_DDL)
                # Persistent override takes priority over run-scoped probe data
                override_row = cur.execute(
                    "SELECT passed FROM signal_overrides WHERE signal_id = ?",
                    [probe_id],
                ).fetchone()
                if override_row is not None:
                    return bool(override_row[0])

                # Fall back to run-scoped probe signals
                try:
                    rows = cur.execute(
                        """
                        SELECT payload
                        FROM probe_signals
                        WHERE probe_id = ? AND run_id = ?
                        ORDER BY captured_at DESC
                        """,
                        [probe_id, self._run_id],
                    ).fetchall()
                except Exception:
                    return True  # probe_signals table not yet created → open

            # Walk rows newest-first, look for first payload containing 'passed'
            for (payload_raw,) in rows:
                payload = json.loads(payload_raw) if isinstance(payload_raw, str) else payload_raw
                if isinstance(payload, dict) and "passed" in payload:
                    passed = payload["passed"]
                    if passed is None:
                        return True
                    return bool(passed)

            return True  # no signal with 'passed' key → open

        except Exception:
            return True  # error → open per spec

    def get_probe_signal(
        self,
        probe_id: str,
        signal_type: str | None = None,
    ) -> list[dict]:
        """Return probe signal payloads for a given probe.

        Opens a fresh read connection to ``store_dir/observability.db``.  Returns
        an empty list if the observability DB does not exist yet.

        Args:
            probe_id:    The Probe module ID to query.
            signal_type: Optional filter — if given, only rows of that type
                         are returned.

        Returns:
            List of dicts: ``{"run_id", "probe_id", "signal_type", "payload",
            "captured_at"}``.  ``payload`` is already deserialised (dict).
        """
        import json as _json

        if self._observability is None:
            from aqueduct.stores.duckdb_ import DuckDBObservabilityStore
            observability_path = self._store_dir / "observability.db"
            if not observability_path.exists():
                return []
            self._observability = DuckDBObservabilityStore(observability_path)

        try:
            with self._observability.connect() as cur:
                if signal_type is not None:
                    rows = cur.execute(
                        """
                        SELECT run_id, probe_id, signal_type, payload,
                               CAST(captured_at AS VARCHAR) AS captured_at
                        FROM probe_signals
                        WHERE probe_id = ? AND signal_type = ?
                        ORDER BY captured_at DESC
                        """,
                        [probe_id, signal_type],
                    ).fetchall()
                else:
                    rows = cur.execute(
                        """
                        SELECT run_id, probe_id, signal_type, payload,
                               CAST(captured_at AS VARCHAR) AS captured_at
                        FROM probe_signals
                        WHERE probe_id = ?
                        ORDER BY captured_at DESC
                        """,
                        [probe_id],
                    ).fetchall()
        except Exception:
            return []

        return [
            {
                "run_id": r[0],
                "probe_id": r[1],
                "signal_type": r[2],
                "payload": _json.loads(r[3]) if isinstance(r[3], str) else r[3],
                "captured_at": str(r[4]),
            }
            for r in rows
        ]

    def stop(self) -> None:
        """No-op for the store-abstraction era.

        Pre-Phase 28 the Surveyor held an open DuckDB connection for the
        run lifetime; the new abstraction acquires connections per
        operation (pooled for Postgres, opened/closed for DuckDB) so there
        is nothing to close at the Surveyor level. Method retained for
        backwards-compatible call sites.
        """
        self._started = False
