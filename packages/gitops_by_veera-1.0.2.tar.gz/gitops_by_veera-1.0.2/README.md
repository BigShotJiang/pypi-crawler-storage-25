# gitops-by-veera

**Natural language → Git & GitHub operations, with a beautiful web UI**

Convert plain English (or your voice) into Git commands and GitHub API calls.

## Install

```bash
pip install gitops-by-veera
```

## Quick start

```bash
gitops
```

Opens the web UI in your browser at `http://localhost:7860`.

## Usage in Python / Colab

```python
import gitops_by_veera
gitops_by_veera.launch()          # opens browser / inline Colab iframe
```

## CLI commands

```bash
gitops serve              # launch web UI (default)
gitops run "Create a private repo named Veera"
gitops run "Stage all files and commit with message 'first commit'"
gitops setup              # store credentials on disk
```

## What you can say

### GitHub Cloud
- `Create a private repo named MyProject in my account`
- `Open a PR from feature-branch to main with title "Add new feature"`
- `Create an issue titled "Bug: login fails" in repo owner/myrepo`

### Local Git
- `Stage all files and commit with message "feat: initial setup"`
- `Create a branch called feature-xyz and push it`
- `Show the last 10 commits`
- `git status`

### Pipelines (chained)
- `Stage all, commit "first commit", create private repo demo, push to it`
- `Create branch hotfix, commit all changes as "fix: critical bug", push`

## Credentials

You need:
1. **Groq API key** — free at [console.groq.com](https://console.groq.com)
2. **GitHub Classic token** — [github.com/settings/tokens](https://github.com/settings/tokens), check `repo` scope

Enter both in the **Settings (⚙)** panel inside the web UI.

## How it works

1. Your command is sent to a Groq LLM which builds a structured execution plan
2. The plan is validated for safety (risk levels: 🟢 safe / 🟡 warning / 🔴 blocked)
3. **Dry Run** mode (default) shows the plan without executing — uncheck to run for real
4. Results stream back into the chat UI

## Voice input

Click 🎤 in the web UI. Uses your browser's built-in speech recognition (Chrome/Edge).
Speak your command — it auto-sends when you stop talking.

## Requirements

- Python 3.10+
- `fastapi`, `uvicorn`, `pydantic`, `requests`, `click`

## License

MIT
