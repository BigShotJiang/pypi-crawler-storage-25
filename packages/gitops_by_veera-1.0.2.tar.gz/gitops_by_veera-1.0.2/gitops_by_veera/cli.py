"""CLI entry point for gitops-by-veera.

Commands:
  gitops serve   — launch the web UI (default)
  gitops run     — run a command from the terminal
  gitops setup   — store API credentials on disk
"""

from __future__ import annotations

import getpass
import sys
from pathlib import Path
from typing import Optional

import click

from gitops_by_veera.config import (
    acquire_lock,
    find_repo_root,
    load_credentials,
    release_lock,
    require_repo_root,
    save_credentials,
)
from gitops_by_veera.constants import WARNING_MESSAGE
from gitops_by_veera.exceptions import (
    ConfigurationError,
    CredentialError,
    GitOpsError,
    LockAcquisitionError,
    RemediationLimitError,
    RepositoryNotFoundError,
    SecurityViolationError,
)
from gitops_by_veera.logger import enable_debug, get_logger
from gitops_by_veera.models import ExecutionPlan, OperationResult


def _prompt(message: str) -> str:
    try:
        return input(message).strip()
    except EOFError:
        return ""


def _confirm(message: str, default: bool = False) -> bool:
    answer = _prompt(message).lower()
    if answer in ("y", "yes"):
        return True
    if answer in ("n", "no"):
        return False
    return default


def _display_plan(plan: ExecutionPlan) -> None:
    click.echo("\n─── Execution Plan ──────────────────────────────────")
    for idx, op in enumerate(plan.operations):
        risk_color = {"safe": "green", "warning": "yellow", "blocked": "red"}.get(
            op.risk_level, "white"
        )
        click.echo(f"\n  [{idx + 1}] Type       : {op.type.upper()}")
        click.echo(
            f"      Risk       : " + click.style(op.risk_level.upper(), fg=risk_color, bold=True)
        )
        if op.type == "local":
            click.echo(f"      Command    : {op.binary} {' '.join(op.args)}")
        else:
            click.echo(f"      Endpoint   : {op.method} {op.endpoint}")
            if op.payload:
                click.echo(f"      Payload    : {op.payload}")
        click.echo(f"      Reason     : {op.reason}")
    click.echo("\n─────────────────────────────────────────────────────\n")


def _display_results(results: list[OperationResult]) -> None:
    click.echo("\n─── Execution Results ───────────────────────────────")
    for r in results:
        status = click.style("✓ SUCCESS", fg="green") if r.success else click.style("✗ FAILED", fg="red")
        click.echo(f"\n  [{r.operation_index + 1}] {r.operation_type.upper()} — {status}")
        if r.stdout:
            click.echo(f"      Output:\n{_indent(r.stdout)}")
        if r.stderr and not r.success:
            click.echo(click.style(f"      Error:\n{_indent(r.stderr)}", fg="red"))
    click.echo("\n─────────────────────────────────────────────────────\n")


def _indent(text: str, spaces: int = 8) -> str:
    pad = " " * spaces
    return "\n".join(pad + line for line in text.splitlines())


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx: click.Context) -> None:
    """GitOps by Veera — conversational Git and GitHub operations coordinator.

    Run `gitops serve` (or just `gitops`) to open the web UI.
    """
    if ctx.invoked_subcommand is None:
        ctx.invoke(serve_cmd)


# ── serve ────────────────────────────────────────────────────────────────────

@cli.command("serve")
@click.option("--port", default=7860, show_default=True, help="Port to serve on.")
@click.option("--host", default="0.0.0.0", show_default=True, help="Host to bind to.")
@click.option("--no-browser", is_flag=True, help="Don't open the browser automatically.")
def serve_cmd(port: int, host: str, no_browser: bool) -> None:
    """Launch the GitOps web UI in your browser."""
    import threading
    import time
    import webbrowser

    import uvicorn
    from gitops_by_veera.server import app

    url = f"http://localhost:{port}"
    click.echo(f"\n  🚀 GitOps by Veera  →  {click.style(url, fg='cyan', bold=True)}")
    click.echo("  Press Ctrl+C to stop\n")

    if not no_browser:
        def _open():
            time.sleep(1.2)
            webbrowser.open(url)
        threading.Thread(target=_open, daemon=True).start()

    uvicorn.run(app, host=host, port=port, log_level="info")


# ── setup ────────────────────────────────────────────────────────────────────

@cli.command("setup")
def setup_cmd() -> None:
    """Interactively configure Groq API key and GitHub token."""
    click.echo(click.style("\n  GitOps Setup\n", bold=True))
    click.echo(
        "  Credentials are stored in ~/.gitops_by_veera_config.json (chmod 600).\n\n"
        "  Tip: use a Classic GitHub token with the 'repo' scope for easiest setup.\n"
    )
    try:
        groq_api_key = getpass.getpass("  Groq API Key (gsk_...): ").strip()
        github_token = getpass.getpass("  GitHub Token (ghp_... or github_pat_...): ").strip()
    except (KeyboardInterrupt, EOFError):
        click.echo("\nSetup cancelled.")
        sys.exit(0)

    if not groq_api_key or not github_token:
        click.echo(click.style("\n  Error: both credentials are required.\n", fg="red"))
        sys.exit(1)

    try:
        save_credentials(github_token=github_token, groq_api_key=groq_api_key)
        click.echo(click.style("\n  Credentials saved.\n", fg="green"))
    except CredentialError as exc:
        click.echo(click.style(f"\n  Error: {exc}\n", fg="red"))
        sys.exit(1)


# ── run (terminal mode) ──────────────────────────────────────────────────────

@cli.command("run")
@click.argument("prompt")
@click.option("--debug", is_flag=True, default=False)
@click.option("--dry-run", is_flag=True, default=False)
def run_cmd(prompt: str, debug: bool, dry_run: bool) -> None:
    """Execute a natural language Git/GitHub operation from the terminal."""
    from gitops_by_veera.agent import GitOpsAgent, MAX_REMEDIATION_CYCLES

    logger = get_logger("gitops.cli", debug=debug)
    if debug:
        enable_debug(logger)

    lock: Optional[Path] = None

    try:
        creds = load_credentials()
    except (CredentialError, ConfigurationError) as exc:
        click.echo(click.style(f"\n  {exc}\n", fg="red"))
        sys.exit(1)

    try:
        lock = acquire_lock()
    except LockAcquisitionError as exc:
        click.echo(click.style(f"\n  {exc}\n", fg="red"))
        sys.exit(1)

    try:
        repo_root = find_repo_root() or Path.cwd()

        if dry_run:
            click.echo(click.style("\n  [DRY-RUN MODE] No operations will be executed.\n", fg="yellow"))

        agent = GitOpsAgent(
            groq_api_key=creds.groq_api_key,
            github_token=creds.github_token,
            repo_root=repo_root,
            debug=debug,
        )

        click.echo(f"\n  Planning: {click.style(prompt, bold=True)}\n")

        try:
            plan = agent.build_plan(prompt)
        except GitOpsError as exc:
            click.echo(click.style(f"\n  Planning failed: {exc}\n", fg="red"))
            sys.exit(1)

        _display_plan(plan)

        try:
            warnings = agent.validate(plan)
        except SecurityViolationError as exc:
            click.echo(click.style(f"\n  Security violation: {exc}\n", fg="red"))
            sys.exit(1)

        for warning in warnings:
            click.echo(click.style(f"  ⚠  {warning}", fg="yellow"))

        if warnings:
            if not _confirm(WARNING_MESSAGE):
                click.echo("  Aborted.")
                sys.exit(0)

        if not dry_run:
            if not _confirm("  Proceed with execution? (y/n): "):
                click.echo("  Aborted.")
                sys.exit(0)

        remediation_cycles = 0
        all_results: list[OperationResult] = []

        while True:
            results = agent.execute(plan, dry_run=dry_run)
            all_results.extend(results)
            failed = [r for r in results if not r.success]
            if not failed or dry_run:
                break
            if remediation_cycles >= MAX_REMEDIATION_CYCLES:
                click.echo(click.style(f"\n  Remediation limit reached.\n", fg="red"))
                break
            remediation_cycles += 1
            try:
                plan = agent.remediate(failed[0])
                _display_plan(plan)
                agent.validate(plan)
            except GitOpsError as exc:
                click.echo(click.style(f"\n  Remediation failed: {exc}\n", fg="red"))
                break
            if not _confirm("  Apply remediation? (y/n): "):
                break

        if not dry_run:
            _display_results(all_results)

        agent.metrics.finalize()
        if debug:
            click.echo("\n")
            for line in agent.metrics.summary_lines():
                click.echo("  " + line)

        failed_count = sum(1 for r in all_results if not r.success)
        if failed_count:
            click.echo(click.style(f"\n  {failed_count} operation(s) failed.\n", fg="red"))
            sys.exit(1)
        elif not dry_run:
            click.echo(click.style("\n  All operations completed successfully.\n", fg="green"))
        else:
            click.echo(click.style("\n  Dry-run complete. No changes were made.\n", fg="cyan"))

    except KeyboardInterrupt:
        click.echo("\n\n  Interrupted.")
        sys.exit(130)
    except GitOpsError as exc:
        click.echo(click.style(f"\n  Error: {exc}\n", fg="red"))
        sys.exit(1)
    finally:
        if lock is not None:
            release_lock(lock)


def main() -> None:
    """Package entry point."""
    cli()
