"""Structured logging with mandatory secret redaction — bug-fixed version."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

from gitops_by_veera.constants import REDACTED_PLACEHOLDER, SECRET_PATTERNS

LOG_FILE = Path.home() / ".gitops_by_veera.log"


class SecretRedactionFilter(logging.Filter):
    """Logging filter that scrubs known secret patterns from all log records."""

    def __init__(self, extra_secrets: Optional[list[str]] = None) -> None:
        super().__init__()
        self._extra_secrets: list[str] = extra_secrets or []

    def add_secret(self, secret: str) -> None:
        if secret and secret not in self._extra_secrets:
            self._extra_secrets.append(secret)

    def _redact(self, text: str) -> str:
        for pattern in SECRET_PATTERNS:
            text = pattern.sub(REDACTED_PLACEHOLDER, text)
        for secret in self._extra_secrets:
            if secret:
                text = text.replace(secret, REDACTED_PLACEHOLDER)
        return text

    def _redact_value(self, v: object) -> object:
        """Redact a value while preserving its original type if no redaction needed.
        
        BUG FIX: The original code converted all args to str, which caused
        TypeError when %d format was used with integer log arguments. This
        version preserves the original type when no redaction is needed.
        """
        s = str(v)
        redacted = self._redact(s)
        if redacted == s:
            return v  # preserve original type (int, float, etc.)
        return redacted

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = self._redact(str(record.msg))
        if record.args:
            if isinstance(record.args, dict):
                record.args = {k: self._redact_value(v) for k, v in record.args.items()}
            elif isinstance(record.args, tuple):
                record.args = tuple(self._redact_value(a) for a in record.args)
        return True


_redaction_filter = SecretRedactionFilter()


def get_logger(name: str = "gitops", debug: bool = False) -> logging.Logger:
    """Return a configured logger with secret redaction applied."""
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG if debug else logging.INFO)

    fmt = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )

    file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG if debug else logging.INFO)
    file_handler.setFormatter(fmt)
    file_handler.addFilter(_redaction_filter)

    logger.addHandler(file_handler)
    logger.addFilter(_redaction_filter)
    logger.propagate = False

    return logger


def register_secret(secret: str) -> None:
    """Register a runtime secret value for active redaction in all log records."""
    _redaction_filter.add_secret(secret)


def enable_debug(logger: logging.Logger) -> None:
    """Switch an existing logger to DEBUG level at runtime."""
    logger.setLevel(logging.DEBUG)
    for handler in logger.handlers:
        handler.setLevel(logging.DEBUG)
