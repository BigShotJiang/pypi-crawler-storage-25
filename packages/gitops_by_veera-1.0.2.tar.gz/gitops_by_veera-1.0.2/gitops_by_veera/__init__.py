"""gitops-by-veera — conversational autonomous Git and GitHub operations coordinator."""

from __future__ import annotations

__version__ = "1.0.0"
__author__ = "Veera"
__license__ = "MIT"

from gitops_by_veera.agent import GitOpsAgent
from gitops_by_veera.exceptions import GitOpsError

__all__ = ["GitOpsAgent", "GitOpsError", "launch", "__version__"]


def launch(
    port: int = 7860,
    host: str = "0.0.0.0",
    open_browser: bool = True,
    log_level: str = "warning",
) -> str:
    """Start the GitOps web UI and return the local URL.

    Works in any Python environment:
    - Local machine  : opens browser automatically
    - Google Colab   : displays inline iframe
    - Replit         : served through the workspace proxy
    - Jupyter        : prints URL
    """
    import threading
    import time

    import uvicorn

    from gitops_by_veera.server import app

    # Detect Google Colab
    try:
        from google.colab.output import serve_kernel_port_as_iframe  # type: ignore
        _in_colab = True
    except ImportError:
        _in_colab = False

    url = f"http://localhost:{port}"

    def _run():
        uvicorn.run(app, host=host, port=port, log_level=log_level)

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
    time.sleep(1.2)  # let uvicorn bind

    if _in_colab:
        serve_kernel_port_as_iframe(port, height=760)
    elif open_browser:
        import webbrowser
        webbrowser.open(url)
    else:
        print(f"GitOps by Veera → {url}")

    return url
