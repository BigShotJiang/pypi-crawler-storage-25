"""FastAPI server — serves the single-page UI and provides the /api/run endpoint."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# Allow running directly from the source tree (development)
_pkg = Path(__file__).parent
_src = _pkg.parent
if str(_src) not in sys.path:
    sys.path.insert(0, str(_src))

from gitops_by_veera.agent import GitOpsAgent
from gitops_by_veera.exceptions import GitOpsError

STATIC = _pkg / "static"

app = FastAPI(title="GitOps by Veera", docs_url=None, redoc_url=None)


# ── Request / Response models ────────────────────────────────────────────────

class RunRequest(BaseModel):
    prompt: str
    groq_api_key: str = ""
    github_token: str = ""
    repo_path: str = ""
    dry_run: bool = True


# ── Routes ───────────────────────────────────────────────────────────────────

@app.get("/api/health")
def health():
    return {"status": "ok", "version": "1.0.0"}


@app.post("/api/run")
def run_command(req: RunRequest):
    if not req.prompt.strip():
        raise HTTPException(400, "prompt is required")
    if not req.groq_api_key.strip():
        raise HTTPException(400, "groq_api_key is required — add it in Settings")
    if not req.github_token.strip():
        raise HTTPException(400, "github_token is required — add it in Settings")

    repo_dir: Optional[Path] = None
    if req.repo_path.strip():
        repo_dir = Path(req.repo_path.strip())
        if not repo_dir.exists():
            raise HTTPException(400, f"Working directory not found: {repo_dir}")

    try:
        agent = GitOpsAgent(
            groq_api_key=req.groq_api_key.strip(),
            github_token=req.github_token.strip(),
            repo_root=repo_dir,
            debug=False,
        )

        plan = agent.build_plan(req.prompt)

        plan_data = []
        for i, op in enumerate(plan.operations):
            entry: dict = {
                "index": i,
                "type": op.type,
                "risk_level": op.risk_level,
                "reason": op.reason,
            }
            if op.type == "local":
                entry["command"] = f"{op.binary} {' '.join(op.args)}"
            else:
                entry["method"]   = op.method
                entry["endpoint"] = op.endpoint
                entry["payload"]  = op.payload or {}
            plan_data.append(entry)

        warnings = agent.validate(plan)
        results  = agent.execute(plan, dry_run=req.dry_run)

        results_data = [
            {
                "operation_index": r.operation_index,
                "operation_type":  r.operation_type,
                "success":         r.success,
                "stdout":          (r.stdout or "").strip(),
                "stderr":          (r.stderr or "").strip(),
                "error_message":   r.error_message or "",
            }
            for r in results
        ]

        metrics = agent.metrics

        return {
            "plan":     plan_data,
            "warnings": warnings,
            "results":  results_data,
            "mode":     "DRY-RUN" if req.dry_run else "LIVE",
            "metrics": {
                "active_model":    metrics.active_model,
                "total_llm_calls": metrics.total_llm_calls,
                "duration":        round(metrics.total_execution_duration_seconds, 2),
            },
        }

    except GitOpsError as exc:
        msg = str(exc)
        if "403" in msg and "personal access token" in msg:
            raise HTTPException(
                403,
                "TOKEN_PERMISSIONS: Your GitHub token is missing required permissions. "
                "Use a Classic token with the 'repo' scope, or a Fine-grained PAT with "
                "Account permissions → Administration → Read & Write.",
            )
        if "401" in msg:
            raise HTTPException(401, "TOKEN_INVALID: GitHub token is invalid or expired.")
        raise HTTPException(500, f"GitOps error: {exc}")

    except Exception as exc:
        raise HTTPException(500, f"Unexpected error: {exc}")


# ── Static files (must come last so API routes take priority) ────────────────

@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")


# Mount anything else under /static (CSS, images if ever needed)
if STATIC.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")
