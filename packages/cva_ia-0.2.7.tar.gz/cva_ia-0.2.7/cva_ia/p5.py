import textwrap
def display_code():
    code = """
import nltk

nltk.download('treebank')

from nltk.corpus import treebank
from nltk.tag import hmm

data = treebank.tagged_sents()

train_data = data[:3000]
test_data = data[3000:]

trainer = hmm.HiddenMarkovModelTrainer()

hmm_tagger = trainer.train_supervised(train_data)

sentence = ["This", "is", "a", "good", "book"]

sentence_lower = [w.lower() for w in sentence]

output = hmm_tagger.tag(sentence_lower)

print("Tagged output:", output)
    """

    return code