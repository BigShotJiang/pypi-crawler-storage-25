def display_code():
    code = """
import nltk
from nltk.tokenize import word_tokenize
from nltk import pos_tag

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

text = "Students are learning Natural Language Processing in the NLP lab today."

words = word_tokenize(text)

print("Automatic POS Tagging Output:")
auto_tags = pos_tag(words)
print(auto_tags)

custom_dict = {
    "students": "NOUN",
    "learning": "VERB",
    "natural": "ADJECTIVE",
    "language": "NOUN",
    "processing": "NOUN",
    "lab": "NOUN",
    "today": "NOUN",
    "nlp": "NOUN"
}


def dictionary_tagger(tokens):
    tagged_output = []

    for word in tokens:
        lw = word.lower()

        if lw in custom_dict:
            tagged_output.append((word, custom_dict[lw]))
        else:
            tagged_output.append((word, "UNK"))

    return tagged_output

print("Dictionary-Based POS Tagging Output:")
dict_tags = dictionary_tagger(words)
print(dict_tags)
    """

    return code