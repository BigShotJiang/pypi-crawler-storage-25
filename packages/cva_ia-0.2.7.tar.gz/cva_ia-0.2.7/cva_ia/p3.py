
def display_code():
    code = """
import nltk
from nltk.tokenize import word_tokenize
from nltk import FreqDist, bigrams
from wordcloud import WordCloud
import matplotlib.pyplot as plt

text = "NLP enables computers to understand human language. NLP is useful in many applications."

words = word_tokenize(text.lower())

print("Word Frequency:")
fd = FreqDist(words)
print(fd.most_common())

print("Displaying Word Cloud...")
wc = WordCloud().generate(text)

plt.imshow(wc)
plt.axis("off")
plt.show()

total = len(words)

unigram_prob = {w: words.count(w) / total for w in set(words)}

print("Unigram Probabilities:")
print(unigram_prob)

bigrams_list = list(bigrams(words))

print("Bigrams:")
print(bigrams_list)

bigram_prob = {
    b: bigrams_list.count(b) / len(bigrams_list)
    for b in set(bigrams_list)
}

print("Bigram Probabilities:")
print(bigram_prob)
    """

    return code