import textwrap
def display_code():
    code = """
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from gensim import corpora, models

nltk.download('punkt')
nltk.download('stopwords')

documents = [
    "NLP is a field of AI that helps computers understand language.",
    "Machine learning and deep learning improve NLP tasks.",
    "Topic modeling such as LDA helps find hidden themes in text documents.",
    "Gensim library is widely used for topic modeling, text mining, and NLP.",
    "Artificial Intelligence and NLP are transforming many modern applications."
]

stop_words = set(stopwords.words('english'))

processed_docs = []

for doc in documents:
    tokens = word_tokenize(doc.lower())
    filtered = [w for w in tokens if w.isalpha() and w not in stop_words]
    processed_docs.append(filtered)

print("Processed Documents:")
print(processed_docs)

dictionary = corpora.Dictionary(processed_docs)

corpus = [dictionary.doc2bow(doc) for doc in processed_docs]

lda_model = models.LdaModel(
    corpus,
    num_topics=3,
    id2word=dictionary,
    passes=10
)

print("LDA Topics:")

topics = lda_model.print_topics(num_words=5)

for topic in topics:
    print(topic)
    """

    return code