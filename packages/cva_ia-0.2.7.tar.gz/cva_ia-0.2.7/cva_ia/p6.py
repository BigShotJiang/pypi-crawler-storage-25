import textwrap
def display_code():
    code = """
import nltk
import re

from nltk import pos_tag

nltk.download('punkt')
nltk.download('averaged_perceptron_tagger_eng')

text = "Ravi visited Delhi last week with Priya"

words = nltk.word_tokenize(text)

pos_tags = pos_tag(words)

person_pattern = re.compile(r'^[A-Z][a-z]+$')

location_keywords = ["Delhi", "India", "London", "Paris"]

persons = []
locations = []

for word, tag in pos_tags:

    if word in location_keywords:
        locations.append(word)

    elif tag == 'NNP' and person_pattern.match(word):
        persons.append(word)

print("Persons Identified:", persons)
print("Locations Identified:", locations)
    """

    return code