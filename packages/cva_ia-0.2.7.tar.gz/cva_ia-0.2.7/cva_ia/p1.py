def display_code():
    code = """
import nltk
import re
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.stem import PorterStemmer, WordNetLemmatizer

nltk.download('punkt')
nltk.download('wordnet')

text = "NLP is exciting. It helps computers process language in 2024 with AI!"

print("Sentence Tokenization:")
print(sent_tokenize(text))

print("Word Tokenization:")
words = word_tokenize(text)
print(words)

ps = PorterStemmer()
print("Stemming:")
print([ps.stem(w) for w in words])

lm = WordNetLemmatizer()
print("Lemmatization:")
print([lm.lemmatize(w) for w in words])

print("REGEX PATTERN DETECTION:")

numbers = [w for w in words if re.fullmatch(r'\d+', w)]
print("Numbers Found:", numbers)

capital_words = [w for w in words if re.fullmatch(r'[A-Z][a-zA-Z]*', w)]
print("Capitalized Words:", capital_words)

lowercase_words = [w for w in words if re.fullmatch(r'[a-z]+', w)]
print("Lowercase Words:", lowercase_words)

alphanumeric = [w for w in words if re.fullmatch(r'[A-Za-z0-9]+', w)]
print("Alphanumeric Words:", alphanumeric)

ing_words = [w for w in words if re.fullmatch(r'.*ing', w)]
print("Words Ending with 'ing':", ing_words)
"""
    return code