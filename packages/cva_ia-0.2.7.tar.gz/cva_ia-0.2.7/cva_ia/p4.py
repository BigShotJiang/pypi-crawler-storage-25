
def display_code():
    code = """
import nltk
from nltk.wsd import lesk
from nltk.tokenize import sent_tokenize, word_tokenize

nltk.download('punkt')
nltk.download('wordnet')

text = "I went to the bank to deposit money. The bank was full of customers today. Later, I walked near the river bank."

word = "bank"

sentences = sent_tokenize(text)

for sentence in sentences:
    tokens = [w.lower() for w in word_tokenize(sentence)]
    sense = lesk(tokens, word, pos="n")

    print("Sentence:", sentence)

    if sense:
        print("Predicted Sense:", sense.name())
        print("Definition:", sense.definition())
    else:
        print("No sense found")
    """

    return code