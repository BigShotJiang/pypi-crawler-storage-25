
def display_code():
    code = """
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.text_rank import TextRankSummarizer

text =

parser = PlaintextParser.from_string(text, Tokenizer("english"))

summarizer = TextRankSummarizer()

summary = summarizer(parser.document, 3)

print("Extractive TextRank Summary:")

for sentence in summary:
    print(sentence)
    """

    return code