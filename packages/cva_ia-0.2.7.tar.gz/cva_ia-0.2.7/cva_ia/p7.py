import textwrap
def display_code():
    code = """
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


documents = [
    "NLP is exciting and fun to learn.",
    "Machine learning and NLP go hand in hand.",
    "Python is a great programming language for NLP applications.",
    "Deep learning improves many NLP tasks significantly."
]

vectorizer = TfidfVectorizer()


tfidf_matrix = vectorizer.fit_transform(documents)

print("TF-IDF Matrix:")
print(tfidf_matrix.toarray())

print("Feature Names (Vocabulary):")
print(vectorizer.get_feature_names_out())

similarity_matrix = cosine_similarity(tfidf_matrix)

print("Cosine Similarity Matrix:")
print(similarity_matrix)
    """

    return code