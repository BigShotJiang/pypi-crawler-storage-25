import textwrap
def display_code():
    code = """
from nltk.corpus import movie_reviews
import random

from nltk.classify import NaiveBayesClassifier
from nltk.classify.util import accuracy


docs = [
    (list(movie_reviews.words(fileid)), category)
    for category in movie_reviews.categories()
    for fileid in movie_reviews.fileids(category)
]

random.shuffle(docs)


def word_features(words):
    return {w: True for w in words}


train = docs[:1500]
test = docs[1500:]

train_set = [
    (word_features(doc), category)
    for doc, category in train
]

test_set = [
    (word_features(doc), category)
    for doc, category in test
]

classifier = NaiveBayesClassifier.train(train_set)

print("Accuracy:", accuracy(classifier, test_set))

classifier.show_most_informative_features(5)
    """

    return code