# Envelope

The metric envelope packages a value with the parameter set, observed depth, and op counts so a regulator can verify the encrypted execution against the declared spec.

::: fairlearn_fhe.envelope.ENVELOPE_SCHEMA

::: fairlearn_fhe.envelope.MetricEnvelope

::: fairlearn_fhe.envelope.ParameterSet

::: fairlearn_fhe.envelope.canonical_envelope_payload

::: fairlearn_fhe.envelope.validate_envelope

::: fairlearn_fhe.envelope.sign_envelope

::: fairlearn_fhe.envelope.verify_envelope_signature

::: fairlearn_fhe.envelope.parameter_set_from_context

::: fairlearn_fhe.audit.audit_metric

::: fairlearn_fhe.encrypted.OP_COUNTERS

::: fairlearn_fhe.encrypted.reset_op_counters

::: fairlearn_fhe.encrypted.snapshot_op_counters
