# ACL Python SDK (acl-layer-py)

Official Python client for the Adaptive Context Layer (ACL). Optimize context delivery, detect loops, and ensure LLM reliability with a single interface.

```bash
pip install acl-layer-py
```

## Quick Start

```python
from acl import ACLClient

# Initialize the client
client = ACLClient(api_key="sk-acl-...")
```

### 1. Smart Completion (Recommended)
The `complete()` method is a high-level interface that automatically optimizes your prompt and handles provider interactions with built-in retries.

```python
with ACLClient(api_key="sk-acl-...") as client:
    result = client.complete(
        prompt="Analyze this technical document...",
        # Provide keys for different providers; ACL chooses the best one
        keys={
            "openai": "sk-...",
            "anthropic": "sk-ant-...",
            "google": "AIza..."
        },
        model="gpt-4o", # Optional: can be automatically optimized
        session_id="session_001",
        max_retries=3
    )
    
    if result["success"]:
        print(f"Response: {result['response']}")
        print(f"Executed via: {result['provider']} ({result['model']})")
    else:
        print(f"Error: {result['error']}")
```

### 2. Manual Optimization
If you prefer to call your LLM directly, use `adaptive_window()` to get optimization parameters first.

```python
with ACLClient(api_key="sk-acl-...") as client:
    sync = client.adaptive_window(
        text="Analyze this document...",
        model="gpt-4o",
        session_id="session_001"
    )
    # Use the optimized token budget for your direct LLM call
    optimized_budget = sync["window"]["final_token_budget"]
```

## Core Methods

| Method | Description |
|--------|-------------|
| `complete()` | Execute prompts with automatic optimization, routing, and retries. |
| `adaptive_window()` | Get optimized context window and model recommendations. |
| `get_telemetry()` | Extract detailed performance and savings metrics. |
| `health_check()` | Verify ACL service availability. |

## `complete()` Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `prompt` | str | ✅ | The input text/prompt to process. |
| `keys` | dict | ❌ | Map of `{provider: key}` for automated routing. |
| `llm_api_key` | str | ❌ | LLM API key (used if `keys` is not provided). |
| `model` | str | ❌ | Target model (e.g., 'gpt-4o', 'claude-3-sonnet'). |
| `provider` | str | ❌ | Specific provider to use. |
| `session_id` | str | ❌ | Unique ID for session tracking and context health. |
| `max_retries` | int | ❌ | Number of retry attempts on failure (default: 3). |

## Reliability Features

The SDK includes several built-in features to ensure your LLM calls are robust:
- **Automatic Retries**: Handles HTTP 429 (Rate Limit), 5xx (Server Errors), and timeouts.
- **Backoff Logic**: Implements exponential backoff (1s → 2s → 4s) to respect provider limits.
- **Silent Failure Detection**: Detects empty or incomplete responses and retries automatically.

## Response Structure

| Field | Type | Description |
|-------|------|-------------|
| `response` | object | The processed LLM response. |
| `success` | boolean | Whether the request was successful. |
| `model` | string | The specific model used for execution. |
| `provider` | string | The provider used (openai, anthropic, etc.). |
| `context_health`| object | Status of the session context (drift/health). |
| `attempts_made` | int | Total number of execution attempts. |
| `error` | string | Error details if the request failed. |

## Security & Privacy
- **Client-Side Execution**: All LLM calls are made directly from your environment.
- **Key Safety**: Your LLM API keys are used locally and are **never** stored or transmitted to ACL servers.