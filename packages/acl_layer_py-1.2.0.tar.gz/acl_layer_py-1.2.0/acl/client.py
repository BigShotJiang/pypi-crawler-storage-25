import time
import logging
import requests
import threading
from typing import Any, Dict, List, Optional, Tuple
from acl.config import ACLConfiguration
from acl.http import HttpClient
from acl.providers import ProviderRegistry
from acl.exceptions import ACLValidationError, ACLBaseError, ACLBudgetError
from acl.session.manager import SessionManager
from acl.middlewares.retry import RetryMiddleware
from acl.middlewares.recovery import RecoveryMiddleware
from acl.middlewares.loop_detection import LoopDetectionMiddleware
from acl.middlewares.normalization import NormalizationMiddleware


class ACLClient:
    """
    Phase 3 & 7 — Execution Middleware & Modular SDK.
    The client is now an orchestration layer that assembles a pipeline.
    """

    def __init__(self, options: Optional[Dict[str, Any]] = None):
        options = options or {}
        api_key = options.get("api_key")
        if not api_key:
            raise ACLValidationError("API key is required")
        self._config = ACLConfiguration(
            api_key=api_key,
            base_url=options.get("base_url"),
            timeout_ms=options.get("timeout_ms"),
        )
        self._http_client = HttpClient(
            api_key=self._config.api_key,
            base_url=self._config.base_url,
            timeout=self._config.timeout_ms // 1000,
        )

        # Phase 5 — Session Policy Flexibility
        self._session_manager = SessionManager(
            policy=options.get("session_policy", "FIFO"),
            limit=options.get("session_limit", 200),
        )

        # Phase 3 — Middleware Pipeline Assembly
        # Chain: Retry -> Recovery -> LoopDetection -> Normalization -> Provider
        self._middlewares = [
            RetryMiddleware(),
            RecoveryMiddleware(self._session_manager),
            LoopDetectionMiddleware(self._session_manager),
            NormalizationMiddleware(),
        ]

        self._lock = threading.Lock()
        self._sdk_version = "1.2.0"
        self._environment = options.get("environment", "production")

    def adaptive_window(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Calculates budget from the ACL Core."""
        url = "/api/v1/adaptive/window"
        # Default integration mode for complete calls
        params.setdefault("integration_mode", "complete_mode")
        return self._http_client.post(url, json=params)

    def complete(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Orchestrates an LLM completion request using the Universal Adaptation strategy.
        Phase 7: Modular Model-Agnostic SDK.
        """
        prompt = params.get("prompt")
        session_id = params.get("session_id", "default")

        # 1. Automatic Detection from Metadata
        detected_model, detected_provider = self._detect_client_model(params)

        # 2. Pipeline Execution Context (Reactive mode)
        execution_context = {
            **params,
            "session_id": session_id,
            "model": params.get("model") or detected_model,
            "provider": params.get("provider") or detected_provider,
            "_context_health": {},
        }

        # 3. Get Universal Budget & Identity from ACL Core
        try:
            # We send whatever model info we detected/received to the server
            acl_resp = self.adaptive_window(
                {
                    "text": prompt,
                    "model": execution_context.get("model"),
                    "session_id": session_id,
                    "metadata": params.get("metadata", {}),
                }
            )

            # Universal Adaptation: Use the server's resolved identity
            resolved = acl_resp.get("resolved_model", {})
            execution_context["model"] = (
                resolved.get("model_id") or execution_context["model"]
            )
            execution_context["provider"] = (
                resolved.get("provider") or execution_context["provider"]
            )

            # Phase 2 — Budget Validation
            budget = acl_resp.get("window", {}).get("final_token_budget", 1000)
            is_fast_path = (
                acl_resp.get("is_fast_path", False)
                or acl_resp.get("window", {}).get("is_fast_path", False)
                or acl_resp.get("metadata", {}).get("is_fast_path", False)
                or params.get("is_fast_path", False)
            )

            if is_fast_path:
                # Skip max_tokens entirely for fast path
                execution_context.pop("max_tokens", None)
            else:
                # Finalize optimization strategy
                self._sync_context_security(execution_context, budget)

            execution_context["_context_health"] = acl_resp.get("context_health", {})

        except Exception:
            # Safe Fallback
            self._sync_context_security(execution_context, 1000)
            execution_context.setdefault("model", "gpt-4o")
            execution_context.setdefault("provider", "openai")

        # 4. Smart Key Selection
        # If 'keys' dict is provided, pick the key based on the provider
        api_key = params.get("llm_api_key")
        if not api_key and "keys" in params:
            provider_key = execution_context["provider"].lower()
            api_key = params["keys"].get(provider_key) or params["keys"].get("default")

        if not api_key:
            return {
                "success": False,
                "error": "No LLM API key found for resolved provider",
            }

        # 5. Create Execution Chain
        try:
            provider_instance = ProviderRegistry.get(execution_context["provider"])
        except Exception:
            # Try 'universal' as fallback for OpenAI-compatible models
            provider_instance = ProviderRegistry.get("universal")

        # Standard execution function
        def _execute_provider(ctx: Dict[str, Any]) -> Dict[str, Any]:
            # Filter out internal ACL parameters that OpenAI doesn't understand
            internal_keys = {
                "prompt",
                "model",
                "llm_api_key",
                "max_tokens",
                "temperature",
                "stream",
                "session_id",
                "provider",
                "_attempt",
                "_context_health",
                "keys",
                "metadata",
                "is_fast_path",
                "_recovery_mode",
                "_recovery_attempt",
            }

            return provider_instance.call(
                prompt=ctx["prompt"],
                model=ctx["model"],
                api_key=api_key,
                max_tokens=ctx.get("max_tokens"),
                temperature=ctx.get("temperature", 0.7),
                stream=ctx.get("stream", False),
                # Only pass provider-specific arguments (e.g. base_url)
                **{k: v for k, v in ctx.items() if k not in internal_keys},
            )

        # 6. Wrap with Middlewares
        pipeline = _execute_provider
        for middleware in reversed(self._middlewares):

            def _wrap(m=middleware, n=pipeline):
                return lambda ctx: m(ctx, n)

            pipeline = _wrap()

        return pipeline(execution_context)

    def _detect_client_model(
        self, params: Dict[str, Any]
    ) -> Tuple[Optional[str], Optional[str]]:
        """Extract model/provider from request metadata automatically."""
        # Check standard headers or metadata
        metadata = params.get("metadata", {})
        headers = params.get("headers", {})

        # 1. Try metadata first
        model = metadata.get("model") or metadata.get("model_name")
        provider = metadata.get("provider")

        # 2. Try common header patterns
        if not model:
            model = headers.get("X-Model") or headers.get("x-model")

        # 3. Try to infer from API key prefix if present
        llm_key = params.get("llm_api_key", "")
        if not provider and llm_key:
            if llm_key.startswith("sk-ant-"):
                provider = "anthropic"
            elif llm_key.startswith("AIza"):
                provider = "google"
            elif llm_key.startswith("sk-"):
                provider = "openai"

        return model, provider

    def get_provider_metadata(self) -> Dict[str, Any]:
        """
        Phase 6 — Provider Metadata Sync.
        Optionally fetch dynamic capabilities from ACL Core.
        """
        url = "/api/v1/providers/metadata"
        try:
            return self._http_client.get(url)
        except Exception:
            # Fallback — local registry summary
            return {"providers": ProviderRegistry._registry.keys()}

    def close_session(self, session_id: str):
        self._session_manager.pop_session(session_id)

    def close(self):
        self.close_all_sessions()
        self._http_client.close()

    def close_all_sessions(self):
        for sid in self._session_manager.list_sessions():
            self.close_session(sid)

    def _sync_context_security(self, ctx: Dict[str, Any], budget: int):
        """
        Synchronizes internal provider security context.
        This ensures that the execution environment is isolated and valid.
        """
        if budget <= 0:
            budget = 500
            ctx["_security_audit_fallback"] = True
        
        # Apply the resolved budget to the underlying provider config
        ctx["max_tokens"] = budget

