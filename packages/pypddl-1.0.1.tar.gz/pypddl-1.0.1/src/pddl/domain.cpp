/*
 * Copyright (C) 2023 Dominik Drexler and Simon Stahlberg
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#include "loki/pddl/domain.hpp"

#include "formatter.hpp"
#include "loki/pddl/action.hpp"
#include "loki/pddl/axiom.hpp"
#include "loki/pddl/function_skeleton.hpp"
#include "loki/pddl/object.hpp"
#include "loki/pddl/predicate.hpp"
#include "loki/pddl/requirements.hpp"
#include "loki/pddl/type.hpp"

#include <iostream>

using namespace std;

namespace loki
{
DomainImpl::DomainImpl(Repositories repositories,
                       std::optional<fs::path> filepath,
                       std::string name,
                       Requirements requirements,
                       TypeList types,
                       ObjectList constants,
                       LiteralList static_initial_literals,
                       PredicateList predicates,
                       FunctionSkeletonList functions,
                       ActionList actions,
                       AxiomList axioms) :
    m_repositories(std::move(repositories)),
    m_filepath(std::move(filepath)),
    m_name(std::move(name)),
    m_requirements(std::move(requirements)),
    m_types(std::move(types)),
    m_constants(std::move(constants)),
    m_static_initial_literals(std::move(static_initial_literals)),
    m_predicates(std::move(predicates)),
    m_function_skeletons(std::move(functions)),
    m_actions(std::move(actions)),
    m_axioms(std::move(axioms))
{
}

const Repositories& DomainImpl::get_repositories() const { return m_repositories; }

const std::optional<fs::path>& DomainImpl::get_filepath() const { return m_filepath; }

const std::string& DomainImpl::get_name() const { return m_name; }

Requirements DomainImpl::get_requirements() const { return m_requirements; }

const TypeList& DomainImpl::get_types() const { return m_types; }

const ObjectList& DomainImpl::get_constants() const { return m_constants; }

const LiteralList& DomainImpl::get_static_initial_literals() const { return m_static_initial_literals; }

const PredicateList& DomainImpl::get_predicates() const { return m_predicates; }

const FunctionSkeletonList& DomainImpl::get_function_skeletons() const { return m_function_skeletons; }

const ActionList& DomainImpl::get_actions() const { return m_actions; }

const AxiomList& DomainImpl::get_axioms() const { return m_axioms; }

std::ostream& operator<<(std::ostream& out, const DomainImpl& element)
{
    write(element, StringFormatter(), out);
    return out;
}

std::ostream& operator<<(std::ostream& out, Domain element)
{
    write(*element, AddressFormatter(), out);
    return out;
}

}
