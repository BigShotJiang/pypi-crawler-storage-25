/*
 * Copyright (C) 2023 Dominik Drexler
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef LOKI_SRC_PDDL_PARSER_METRIC_HPP_
#define LOKI_SRC_PDDL_PARSER_METRIC_HPP_

#include "loki/ast/ast.hpp"
#include "loki/pddl/declarations.hpp"

namespace loki
{

/* OptimizationMetric */

struct MetricSpecificationDeclarationVisitor : boost::static_visitor<OptimizationMetric>
{
    ProblemParsingContext& context;

    MetricSpecificationDeclarationVisitor(ProblemParsingContext& context);

    OptimizationMetric operator()(const ast::MetricSpecificationTotalCost& node);
    OptimizationMetric operator()(const ast::MetricSpecificationGeneral& node);
};

extern OptimizationMetric parse(const ast::MetricSpecification& node, ProblemParsingContext& context);

}

#endif
