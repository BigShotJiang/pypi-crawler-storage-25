/*
 * Copyright (C) 2023 Dominik Drexler and Simon Stahlberg
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#include "loki/pddl/requirements_enum.hpp"

#include <cassert>
#include <ostream>
#include <string>

namespace loki
{

const std::unordered_map<RequirementEnum, std::string> requirement_enum_to_string = {
    { RequirementEnum::STRIPS, ":strips" },
    { RequirementEnum::TYPING, ":typing" },
    { RequirementEnum::NEGATIVE_PRECONDITIONS, ":negative-preconditions" },
    { RequirementEnum::DISJUNCTIVE_PRECONDITIONS, ":disjunctive-preconditions" },
    { RequirementEnum::EQUALITY, ":equality" },
    { RequirementEnum::EXISTENTIAL_PRECONDITIONS, ":existential-preconditions" },
    { RequirementEnum::UNIVERSAL_PRECONDITIONS, ":universal-preconditions" },
    { RequirementEnum::QUANTIFIED_PRECONDITIONS, ":quantified-preconditions" },
    { RequirementEnum::CONDITIONAL_EFFECTS, ":conditional-effects" },
    { RequirementEnum::FLUENTS, ":fluents" },
    { RequirementEnum::OBJECT_FLUENTS, ":object-fluents" },
    { RequirementEnum::NUMERIC_FLUENTS, ":numeric-fluents" },
    { RequirementEnum::ADL, ":adl" },
    { RequirementEnum::DURATIVE_ACTIONS, ":durative-actions" },
    { RequirementEnum::DERIVED_PREDICATES, ":derived-predicates" },
    { RequirementEnum::TIMED_INITIAL_LITERALS, ":timed-initial-literals" },
    { RequirementEnum::PREFERENCES, ":preferences" },
    { RequirementEnum::CONSTRAINTS, ":constraints" },
    { RequirementEnum::ACTION_COSTS, ":action-costs" },
    { RequirementEnum::NON_DETERMINISTIC, ":non-deterministic" },
    { RequirementEnum::PROBABILISTIC, ":probabilistic-effects" }
};

std::ostream& operator<<(std::ostream& out, RequirementEnum element)
{
    assert(requirement_enum_to_string.count(element));
    out << requirement_enum_to_string.at(element);
    return out;
}

}
