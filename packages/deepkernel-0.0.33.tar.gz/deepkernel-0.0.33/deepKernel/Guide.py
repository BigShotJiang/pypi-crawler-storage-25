import json
import os
from tkinter import *
from tkinter.font import *

from deepKernel import base, deepline


def refreshJoblist(job: str, step: str):
    try:
        base.refreshJoblist(job, step)
    except Exception as e:
        print(e)


def closeAllLayer(job: str, step: str):
    try:
        base.closeAllLayer(job, step)
    except Exception as e:
        print(e)


def displayLayers(job: str, step: str, clayer: str = '', snaplayer: str = '', displaylayers: list = [],
                  affectedlayers: list = []):
    try:
        base.displayLayers(job, step, clayer, snaplayer, displaylayers, affectedlayers)
    except Exception as e:
        print(e)


def changeToGuideTool(job: str, step: str, type: int = 0):
    try:
        base.changeToGuideTool(job, step, type)
    except Exception as e:
        print(e)


def changeToLastTool(job: str, step: str):
    try:
        base.changeToLastTool(job, step)
    except Exception as e:
        print(e)


def getClickedPoint(job: str, step: str) -> dict:
    try:
        point = base.getClickedPoint(job, step)
        point = json.loads(point)['paras']
        return point
    except Exception as e:
        print(e)
        return {}


def getClickedBox(job: str, step: str) -> dict:
    try:
        box = base.getClickedBox(job, step)
        box = json.loads(box)['paras']
        return box
    except Exception as e:
        print(e)
        return {}


def changeToPointTool(job: str, step: str, tips: str = '') -> dict:
    try:
        def onToolClicked():
            changeToGuideTool(job, step, 1)

        def onCtnClicked():
            changeToGuideTool(job, step, 1)
            ret = getClickedPoint(job, step)
            return_str.append(ret)
            changeToLastTool(job, step)
            root_window.destroy()

        # -*- coding:utf-8 -*-
        # 调用Tk()创建主窗口
        return_str = []
        if tips == '':
            tips = '请单击选择合适的坐标'
        changeToGuideTool(job, step, 1)
        root_window = Tk(baseName='提示')
        root_window.transient()
        root_window.attributes('-topmost', 'true')
        root_window.resizable(0, 0)
        # 给主窗口起一个名字，也就是窗口的名字
        root_window.title('Guide提示')
        main_frame = Frame(root_window, bg='yellow')
        main_frame.place(relwidth=1, relheight=1)
        cfg_path = deepline.getConfigPath()
        if cfg_path is not None:
            logo_path = os.path.join(os.path.join(cfg_path, 'Resources'), 'logo.ico')
            if os.path.exists(logo_path):
                root_window.iconbitmap(logo_path)
        root_window.geometry('330x100+234+45')
        fontStyle = Font(size=18)
        tips_lb = Label(main_frame, text=tips, borderwidth=2, font=fontStyle, fg='red', bg='yellow')
        # lb_width = tips_lb.
        tool_btn = Button(main_frame, text='工具', bg='cyan', command=onToolClicked)
        ctn_btn = Button(main_frame, text='继续', command=onCtnClicked, bg='lime')
        tips_lb.place(x=10, y=26)
        tool_btn.place(x=275, y=26, width=50, height=30)
        ctn_btn.place(x=115, y=65, width=100, height=30)
        # 开启主循环，让窗口处于显示状态
        root_window.mainloop()
        return return_str
    except Exception as e:
        print(e)
        return {}


def changeToBoxTool(job: str, step: str, tips: str = '') -> dict:
    try:
        def onToolClicked():
            changeToGuideTool(job, step, 0)

        def onCtnClicked():
            changeToGuideTool(job, step, 0)
            ret = getClickedBox(job, step)
            return_str.append(ret)
            changeToLastTool(job, step)
            root_window.destroy()

        # -*- coding:utf-8 -*-
        # 调用Tk()创建主窗口
        return_str = []
        if tips == '':
            tips = '请框选合适的位置'
        changeToGuideTool(job, step, 0)
        root_window = Tk(baseName='提示')
        root_window.attributes('-topmost', 'true')
        root_window.resizable(False, False)
        # 给主窗口起一个名字，也就是窗口的名字
        root_window.title('Guide提示')
        main_frame = Frame(root_window, bg='yellow')
        main_frame.place(relwidth=1, relheight=1)
        cfg_path = deepline.getConfigPath()
        if cfg_path is not None:
            logo_path = os.path.join(os.path.join(cfg_path, 'Resources'), 'logo.ico')
            if os.path.exists(logo_path):
                root_window.iconbitmap(logo_path)
        root_window.geometry('330x100+234+45')
        fontStyle = Font(size=18)
        tips_lb = Label(main_frame, text=tips, borderwidth=2, font=fontStyle, fg='red', bg='yellow', anchor=CENTER)
        # lb_width = tips_lb.
        tool_btn = Button(main_frame, text='工具', bg='cyan', command=onToolClicked)
        ctn_btn = Button(main_frame, text='继续', command=onCtnClicked, bg='lime')
        tips_lb.place(x=10, y=26)
        tool_btn.place(x=275, y=26, width=50, height=30)
        ctn_btn.place(x=115, y=65, width=100, height=30)
        # 开启主循环，让窗口处于显示状态
        root_window.mainloop()
        return return_str
    except Exception as e:
        print(e)
        return {}


def getActiveStep(job: str) -> str:
    try:
        ret = base.getActivedStepInfo(job)
        ret = json.loads(ret)['paras']['step']
        return ret
    except Exception as e:
        print(e)
        return ''


def getWorkLayer(job: str) -> str:
    try:
        ret = base.getActivedStepInfo(job)
        ret = json.loads(ret)['paras']['c_layer']
        return ret
    except Exception as e:
        print(e)
        return ''


def getAfectedLayers(job: str) -> list:
    try:
        ret = base.getActivedStepInfo(job)
        ret = json.loads(ret)['paras']['affect_layers']
        return ret
    except Exception as e:
        print(e)
        return []
