import json
from deepKernel import base


def exportDxf(jobName: str, stepName: str, layers: list, path: str) -> bool:
    try:
        if not layers:
            print("警告: 导出 DXF 时图层列表不能为空")
            return False
        retStr = base.exportDxf(jobName, stepName, layers, path)
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true' or ret.get('status') is True
    except Exception as e:
        print(f"exportDXF 异常: {e}")
        return False


def importDxf(path: str, jobName: str, stepName: str, layerName: str, scale: float = 1.0,
              polylineEnds: int = 1, units: str = "mm", proportionText: bool = False,
              convertCircleToApertures: bool = False, convertDonutsToApertures: bool = False,
              fillClosedZeroWidthPolylines: bool = False, layerApart: bool = False) -> bool:
    try:
        validUnits = ["Inch", "Mils", "mm", "HpPlotter", "cum", "um", "nm", "cm"]
        if units not in validUnits:
            print(f"错误: importDXF 不支持的单位类型 '{units}'")
            return False

        retStr = base.importDxf(path, jobName, stepName, layerName, scale, polylineEnds, units, proportionText,
                                convertCircleToApertures, convertDonutsToApertures, fillClosedZeroWidthPolylines,
                                layerApart)
        ret = json.loads(retStr)
        # 底层 READ_DXF 成功时返回的是 paras.result
        return ret.get('paras', {}).get('result', False)
    except Exception as e:
        print(f"importDXF 异常: {e}")
        return False


# def exportGds2(jobName: str, stepName: str, layers: list, path: str, dbu: float = 0.001) -> bool:
#     try:
#         if not layers:
#             return False
#         retStr = base.exportGds2(jobName, stepName, layers, path, dbu)
#         ret = json.loads(retStr)
#         return str(ret.get('status', '')).lower() == 'true'
#     except Exception as e:
#         print(f"exportGDS2 异常: {e}")
#         return False


def deleteLayerWithName(jobName: str, layerName: str) -> bool:
    try:
        retStr = base.deleteLayerWithName(jobName, layerName)
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true'
    except Exception as e:
        print(f"deleteLayerWithName 异常: {e}")
        return False


def arcToLine(jobName: str, stepName: str, layers: list, selectType: int, scopeParam: list) -> bool:
    try:
        if not scopeParam:
            print("警告: arcToLine scopeParam 不能为空")
            return False
        # scopeParam 内部的字典 key 必须是 min_value, max_value, degree, max_length
        retStr = base.arcToLine(jobName, stepName, layers, selectType, scopeParam)
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true'
    except Exception as e:
        print(f"arcToLine 异常: {e}")
        return False


def outlineToSurface(jobName: str, stepName: str, layers: list, canToPad: bool = False,
                     size: float = 0.0, unit: int = 0, method: int = 0) -> bool:
    try:
        retStr = base.outlineToSurface(jobName, stepName, layers, canToPad, size, unit, method)
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true'
    except Exception as e:
        print(f"outlineToSurface 异常: {e}")
        return False


def updateSymbolFromLayer(jobName: str, stepName: str, symbolName: str, layerName: str) -> bool:
    try:
        retStr = base.updateSymbolFromLayer(jobName, stepName, symbolName, layerName)
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true'
    except Exception as e:
        print(f"updateSymbolFromLayer 异常: {e}")
        return False


def newLayerFromSymbol(jobName: str, stepName: str, symbolName: str) -> bool:
    try:
        retStr = base.newLayerFromSymbol(jobName, stepName, symbolName)
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true'
    except Exception as e:
        print(f"newLayerFromSymbol异常: {e}")
        return False


def featureStepAndRepeat(jobName: str, stepName: str, layerName: str, nx: int = 1, ny: int = 1,
                         dx: float = 0.0, dy: float = 0.0,
                         xDir: int = 0, yDir: int = 0, mode: int = 0) -> bool:
    try:
        if nx < 1 or ny < 1:
            print("警告: 阵列数量 nx, ny 必须大于或等于 1")
            return False
        retStr = base.featureStepAndRepeat(jobName, stepName, layerName, nx, ny, dx, dy, xDir, yDir, mode)
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true'
    except Exception as e:
        print(f"featureStepAndRepeat 异常: {e}")
        return False


def breakSurfaceArc(jobName: str, stepName: str, layers: list, scopeParams: list) -> bool:
    try:
        retStr = base.breakSurfaceArc(jobName, stepName, layers, scopeParams)
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true'
    except Exception as e:
        print(f"breakSurfaceArc 异常: {e}")
        return False


def dividePolygon(jobName: str, stepName: str, layers: list, vertex: int) -> bool:
    try:
        if not layers:
            print("错误: 图层列表不能为空")
            return False
        retStr = base.dividePolygon(jobName, stepName, layers, vertex)
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true'
    except Exception as e:
        print(f"dividePolygon 异常: {e}")
        return False


def autoZeroPoint(jobName: str, stepName: str, layers: list, points: list) -> bool:
    try:
        pointCount = len(points)
        if pointCount not in [1, 2, 4]:
            print("错误: autoZeroPoint 仅支持 1, 2 或 4 个点")
            return False

        targetX, targetY = 0, 0
        if pointCount == 1:
            targetX, targetY = points[0]['x'], points[0]['y']
        elif pointCount == 2:
            targetX = int((points[0]['x'] + points[1]['x']) / 2)
            targetY = int((points[0]['y'] + points[1]['y']) / 2)
        elif pointCount == 4:
            targetX = int(sum(p['x'] for p in points) / 4)
            targetY = int(sum(p['y'] for p in points) / 4)

        retStr = base.autoZeroPoint(jobName, stepName, layers, targetX, targetY)
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true'
    except Exception as e:
        print(f"autoZeroPoint 计算或通信异常: {e}")
        return False


def maskAnalysis(jobName: str, stepName: str, layerName: str, userSymbol: bool = False) -> dict:
    try:
        retStr = base.maskAnalysis(jobName, stepName, layerName, userSymbol)
        ret = json.loads(retStr)
        return ret
    except Exception as e:
        print(f"maskAnalysis 异常: {e}")
        return {}


def createProfileBySelected(jobName: str, stepName: str, layers: list) -> bool:
    try:
        if not layers:
            print("提示: Operation can be done on selected features only")
            return False

        successCount = 0
        for layer in layers:
            retStr = base.createProfileBySelected(jobName, stepName, layer)
            ret = json.loads(retStr)
            if str(ret.get('status', '')).lower() == 'true':
                successCount += 1
            else:
                print(f"警告: Invalid polyline on layer {layer}")
        return successCount == len(layers)
    except Exception as e:
        print(f"createProfileBySelected 异常: {e}")
        return False


def reshapeBreak(jobName: str, stepName: str, layers: list) -> bool:
    try:
        if not layers:
            print("提示: No active layers defined")
            return False

        successCount = 0
        for layer in layers:
            retStr = base.reshapeBreak(jobName, stepName, layer)
            ret = json.loads(retStr)
            if str(ret.get('status', '')).lower() == 'true':
                successCount += 1
        return successCount == len(layers)
    except Exception as e:
        print(f"reshapeBreak 异常: {e}")
        return False


def contourize(job: str, step: str, layers: list, accuracy: int, separate_to_islands: bool, size: int, mode: int):
    try:
        mode = mode + 1
        base.contourize(job, step, layers, accuracy, separate_to_islands, size, mode)
    except Exception as e:
        print(e)
    return ''


def getUserSymbolHistogram(jobName: str, stepName: str, layerName: str) -> list:
    try:
        if not jobName or not stepName or not layerName:
            print("警告: getUserSymbolHistogram 参数 jobName, stepName 或 layerName 不能为空")
            return []

        retStr = base.getUserSymbolHistogram(jobName, stepName, layerName)

        if not retStr:
            return []

        ret = json.loads(retStr)

        if isinstance(ret, list):
            return ret

        if isinstance(ret, dict) and str(ret.get('status', '')).lower() == 'false':
            print(f"getUserSymbolHistogram 获取失败，底层返回: {ret}")
            return []

        return ret

    except Exception as e:
        print(f"getUserSymbolHistogram 异常: {e}")
        return []


def copyToOtherLayer(src_job: str, src_step: str, src_layer: str, dst_layer: str, invert: bool, offset_x: int,
                     offset_y: int, mirror: int, resize: float, rotation: float, x_anchor: float, y_anchor: float):
    try:
        base.selCopyOther(src_job, src_step, [src_layer], [dst_layer], invert, offset_x, offset_y, mirror, resize,
                          rotation, x_anchor, y_anchor)
    except Exception as e:
        print(e)
    return None


def moveToOtherLayer(src_job: str, src_step: str, src_layers: list, dst_job: str, dst_step: str, dst_layer: str,
                     invert: bool, offset_x: int, offset_y: int, mirror: int, resize: float, rotation: float,
                     x_anchor: float, y_anchor: float) -> None:
    try:
        base.selMoveOther(src_job, src_step, src_layers, dst_job, dst_step, dst_layer, invert, offset_x, offset_y,
                          mirror, resize, rotation, x_anchor, y_anchor)
    except Exception as e:
        print(e)


def resizeGlobal(jobName: str, stepName: str, layers: list, selectType: int, size: int) -> bool:
    try:
        if not layers:
            print("警告: resizeGlobal 失败，图层列表 layers 不能为空")
            return False

        retStr = base.resizeGlobal(jobName, stepName, layers, selectType, size)

        if not retStr:
            return False

        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true' or ret.get('status') is True

    except Exception as e:
        print(f"resizeGlobal 异常: {e}")
        return False


def clipArea(jobName: str, stepName: str, layers: list, mode: int,
             points: list = None, referenceLayer: str = None,
             clipInside: bool = False, clipContour: bool = False,
             margin: float = 0.0, smoothTolerance: float = 1000.0,
             featureType: int = 0) -> bool:
    try:
        if not layers:
            print("警告: clipArea 失败，目标图层列表 layers 不能为空")
            return False

        # 模式校验与参数保护
        if mode == 0 and not points:
            print("警告: clipArea 失败，在模式 0 (manual) 下，points 参数不能为空")
            return False

        if mode == 1 and not referenceLayer:
            print("警告: clipArea 失败，在模式 1 (reference) 下，referenceLayer 参数不能为空")
            return False

        if mode not in [0, 1, 2]:
            print(f"警告: clipArea 失败，不支持的模式 '{mode}'，仅支持 0, 1, 2")
            return False

        # 调用 base 层接口
        retStr = base.clipArea(jobName, stepName, layers, mode, points, referenceLayer,
                               clipInside, clipContour, margin, smoothTolerance, featureType)

        if not retStr:
            return False

        # 解析底层返回的 JSON 结果
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true' or ret.get('status') is True

    except Exception as e:
        print(f"clipArea 异常: {e}")
        return False


def exportGds(job, step, layer, filename, rotate, scale, gdsdbu, smooth, dividepolygon, mirror, cellname,
              breakarcinfo: list) -> bool:
    try:
        # 类型检查
        if not isinstance(breakarcinfo, list):
            raise TypeError(f"参数 'breakarcinfo' 必须是 list 类型，当前传入的是: {type(breakarcinfo).__name__}")

        # 定义导出类型为Gds
        _type = 1

        retStr = base.layerExport(
            job, step, layer, _type, filename, gdsdbu,
            resize=0.0, angle=0.0, scalingX=1.0, scalingY=1.0,
            isReverse=False, mirror=mirror, rotate=rotate, scale=scale,
            profiletop=False, cw=False, cutprofile=True,
            mirrorpointX=0, mirrorpointY=0, rotatepointX=0, rotatepointY=0,
            scalepointX=0, scalepointY=0, mirrordirection="X",
            cut_polygon=[], numberFormatL=2, numberFormatR=6, zeros=2,
            unit=0, profile_level=1, cellname=cellname,
            smooth=smooth, dividepolygon=dividepolygon, breakarcinfo=breakarcinfo
        )

        # 解析返回结果
        ret = json.loads(retStr)
        return str(ret.get('status', '')).lower() == 'true' or ret.get('status') is True

    except Exception as e:
        print(f"exportDXF 异常: {e}")
    return False
