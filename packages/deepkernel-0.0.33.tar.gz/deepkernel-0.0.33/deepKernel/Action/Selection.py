import json

from deepKernel import base
from deepKernel.Action import Information


def setAttributeFilter(logic: int, attribute_list: list):
    """
    #设置属性筛选
    :param     logic:0 ：全部满足  1:有其一
    :param     attribute_list:要设置的属性列表
    :returns   :
    :raise    error:
    """
    try:
        base.filterSetAttribute(logic, attribute_list)
    except Exception as e:
        print(e)
    return 0


def selectFeaturesByFilter(job: str, step: str, layers: list):
    """
    #根据筛选条件选择
    :param     job:
    :param     step:
    :param     layers:layer列表
    :returns   :
    :raises    error:
    """
    try:
        base.selectFeaturesByFilter(job, step, layers)
    except Exception as e:
        print(e)
    return 0


def clearSelect(job: str, step: str, layer: str = ''):
    try:
        layers = Information.getLayers(job)
        if layer == '':
            for layer in layers:
                base.clearSelectedFeatures(job, step, layer)
        else:
            base.clearSelectedFeatures(job, step, layer)
    except Exception as e:
        print(e)
    return 0


def reverseSelect(job: str, step: str, layer: str):
    """
    #反选
    :param     job:
    :param     step:
    :param     layer:
    :returns   :
    :raises    error:
    """
    try:
        base.counterElection(job, step, layer)
    except Exception as e:
        print(e)
    return 0


def setSelection(is_standard: bool, is_clear: bool, all_layers: bool, is_select: bool, inside: bool, exclude: bool):
    try:
        base.setSelection(is_standard, is_clear, all_layers, is_select, inside, exclude)
    except Exception as e:
        print(e)
    return 0


def resetSelection():
    try:
        base.setSelection(True, True, True, True, True, True)
    except Exception as e:
        print(e)
    return 0


def unselectFeatures(job: str, step: str, layer: str):
    try:
        base.unselectFeatures(job, step, layer)
    except Exception as e:
        print(e)
    return 0


def selectFeatureByPolygon(job: str, step: str, layer: str, selectpolygon: list):
    try:
        base.selectFeature(job, step, layer, selectpolygon, 1, True)
    except Exception as e:
        print(e)
    return 0


def selectFeatureByPoint(job: str, step: str, layer: str, location_x: int, location_y: int):
    try:
        selectpolygon = []
        min = 1
        selectpolygon.append([location_x - min, location_y - min])
        selectpolygon.append([location_x + min, location_y - min])
        selectpolygon.append([location_x + min, location_y + min])
        selectpolygon.append([location_x - min, location_y + min])
        selectpolygon.append([location_x - min, location_y - min])
        base.selectFeature(job, step, layer, selectpolygon, {}, 0)
    except Exception as e:
        print(e)
    return 0


def selectFeatureById(job: str, step: str, layer: str, ids: list):
    try:
        base.selectFeatureById(job, step, layer, ids)
    except Exception as e:
        print(e)
    return


def unselectFeaturesByFilter(job: str, step: str, layers: list):
    try:
        base.unselectFeaturesByFilter(job, step, layers)
    except Exception as e:
        print(e)
    return


def setSymbolRangeFilter(type: str, range: list):
    try:
        ret = base.getSelectParam()
        data = json.loads(ret)
        select_param = data['paras']['param']
        featuretypes = select_param['featuretypes']
        attributes_flag = select_param['attributes_flag']
        attributes_value = select_param['attributes_value']
        profile_value = select_param['profile_value']
        use_selection = select_param['use_selection']
        dcode = select_param['dcode']
        has_symbols = select_param['has_symbols']
        symbols = select_param['symbols']
        use_attr_range = select_param['use_attr_range']
        attr_range = select_param['attr_range']
        exclude_attributes_value = select_param['exclude_attributes_value']
        exclude_attr_range = select_param['exclude_attr_range']
        dict_new = dict(range)
        keys = list(dict_new.keys())
        key_list = [str(i) for i in keys]
        value_list = list(dict_new.values())
        ranges = dict(zip(key_list, value_list))
        new_list = []
        for k, v in ranges.items():
            dict_new = {}
            dict_new[k] = v
            new_list.append(dict_new)
        symbol_range_dict = {}
        symbol_range_dict['range'] = new_list
        symbol_range_dict['symbol_type'] = type
        symbol_range_list = [symbol_range_dict]
        base.setSelectParam(
            featuretypes, has_symbols, symbols, dcode, attributes_flag, attributes_value, profile_value, use_selection,
            use_symbol_range=True,
            symbol_range=symbol_range_list,
            use_attr_range=use_attr_range,
            attr_range=attr_range,
            exclude_attributes_value=exclude_attributes_value,
            exclude_attr_ranges=exclude_attr_range
        )
    except Exception as e:
        print(e)
    return None


def setAttrRangeFilter(logic: int, attr_range: list):
    try:
        ret = base.getSelectParam()
        data = json.loads(ret)
        select_param = data['paras']['param']
        featuretypes = select_param['featuretypes']
        attributes_value = select_param['attributes_value']
        profile_value = select_param['profile_value']
        use_selection = select_param['use_selection']
        dcode = select_param['dcode']
        has_symbols = select_param['has_symbols']
        symbols = select_param['symbols']
        use_symbol_range = select_param['use_symbol_range']
        symbol_range = select_param['symbol_range']
        exclude_attributes_value = select_param['exclude_attributes_value']
        exclude_attr_range = select_param['exclude_attr_range']
        base.setSelectParam(
            featuretypes, has_symbols, symbols, dcode, logic, attributes_value, profile_value, use_selection,
            use_symbol_range=use_symbol_range,
            symbol_range=symbol_range,
            use_attr_range=True,
            attr_range=attr_range,
            exclude_attributes_value=exclude_attributes_value,
            exclude_attr_ranges=exclude_attr_range
        )
    except Exception as e:
        print(e)
    return None


def setExcludeAttrFilter(attr: list):
    try:
        ret = base.getSelectParam()
        data = json.loads(ret)
        select_param = data['paras']['param']
        featuretypes = select_param['featuretypes']
        attributes_value = select_param['attributes_value']
        profile_value = select_param['profile_value']
        use_selection = select_param['use_selection']
        dcode = select_param['dcode']
        has_symbols = select_param['has_symbols']
        symbols = select_param['symbols']
        symbol_range = select_param['symbol_range']
        attr_range = select_param['attr_range']
        exclude_attr_range = select_param['exclude_attr_range']
        use_symbol_range = select_param['use_symbol_range']
        exclude_attr_dict = {}
        if attr:
            first_element = attr[0]
            if isinstance(first_element, str):
                # 纯字符串列表 (如 ['.smd', '.comp'])
                exclude_attr_dict = {str(k): "" for k in attr}
            elif isinstance(first_element, (list, tuple)) and len(first_element) >= 2:
                # 键值对列表 (如 [('.smd', ''), ('.comp', 'yes')])
                exclude_attr_dict = dict(attr)
            else:
                exclude_attr_dict = {str(k): "" for k in attr}

        base.setSelectParam(
            featuretypes, has_symbols, symbols, dcode, 0, attributes_value, profile_value, use_selection,
            use_symbol_range=use_symbol_range,
            symbol_range=symbol_range,
            use_attr_range=True,
            attr_range=attr_range,
            exclude_attributes_value=exclude_attr_dict,
            exclude_attr_ranges=exclude_attr_range
        )
    except Exception as e:
        print(e)


def setExcludeAttrRangeFilter(attr_range: list):
    try:
        ret = base.getSelectParam()
        data = json.loads(ret)
        select_param = data['paras']['param']
        featuretypes = select_param['featuretypes']
        attributes_value = select_param['attributes_value']
        profile_value = select_param['profile_value']
        use_selection = select_param['use_selection']
        dcode = select_param['dcode']
        has_symbols = select_param['has_symbols']
        symbols = select_param['symbols']
        symbol_range = select_param['symbol_range']
        include_attr_range = select_param['attr_range']
        exclude_attributes_value = select_param['exclude_attributes_value']
        use_symbol_range = select_param['use_symbol_range']
        base.setSelectParam(
            featuretypes, has_symbols, symbols, dcode, 0, attributes_value, profile_value, use_selection,
            use_symbol_range=use_symbol_range,
            symbol_range=symbol_range,
            use_attr_range=True,
            attr_range=include_attr_range,
            exclude_attributes_value=exclude_attributes_value,
            exclude_attr_ranges=attr_range
        )
    except Exception as e:
        print(e)


def selectFeaturesByNet(job: str, step: str, layer: str, use_select_info: bool, location_x: int, location_y: int,
                        tolerance: int):
    try:
        selectpolygon = []
        selectpolygon.append({'ix': location_x - tolerance, 'iy': location_y - tolerance})
        selectpolygon.append({'ix': location_x + tolerance, 'iy': location_y - tolerance})
        selectpolygon.append({'ix': location_x + tolerance, 'iy': location_y + tolerance})
        selectpolygon.append({'ix': location_x - tolerance, 'iy': location_y + tolerance})
        selectpolygon.append({'ix': location_x - tolerance, 'iy': location_y - tolerance})
        base.selectFeaturesByNet(job, step, layer, [], use_select_info, selectpolygon)
    except Exception as e:
        print(e)


def resetSelectFilter():
    try:
        ret = base.getSelectParam()
        data = json.loads(ret)
        select_param = data['paras']['param']

        base.setSelectParam(
            127,
            [],
            select_param['dcode'],
            0,
            {},
            select_param['profile_value'],
            select_param['use_selection'],
            use_symbol_range=False,
            symbol_range=[],
            use_attr_range=False,
            attr_range=[],
            exclude_attributes_value={},
            exclude_attr_ranges=[],
            exclude_symbols = []
        )
    except Exception as e:
        print(f"resetSelectFilter 异常: {e}")
    return 0


def setIncludeSymbolFilter(symbol_list: list):
    try:
        ret = base.getSelectParam()
        data = json.loads(ret)
        select_param = data['paras']['param']

        # 清洗所有必须是 list 的字段
        list_fields = [
            'symbols', 'exclude_symbols', 'symbol_range',
            'exclude_symbol_range', 'attr_range', 'exclude_attr_ranges'
        ]
        for key in list_fields:
            val = select_param.get(key, [])
            if not isinstance(val, list):
                if isinstance(val, str) and val.strip() != "":
                    # 底层传了单一的有效字符串(如 "r100")，包裹成 list 抢救一下
                    select_param[key] = [val.strip()]
                else:
                    # 对于空字符串 ""、False、None 等，一律重置为空列表
                    select_param[key] = []

        # 清洗所有必须是 dict 的字段
        dict_fields = ['attributes_value', 'exclude_attributes_value']
        for key in dict_fields:
            val = select_param.get(key, {})
            if not isinstance(val, dict):
                # 遇到非 dict 类型（如 "" 或 False），一律重置为空字典
                select_param[key] = {}

        base.setSelectParam(
            select_param['featuretypes'],
            symbol_list,
            select_param['dcode'],
            select_param['attributes_flag'],
            select_param['attributes_value'],
            select_param['profile_value'],
            select_param['use_selection'],
            use_symbol_range=select_param.get('use_symbol_range', False),
            symbol_range=select_param.get('symbol_range', []),
            use_attr_range=select_param.get('use_attr_range', False),
            attr_range=select_param.get('attr_range', []),
            exclude_attributes_value=select_param.get('exclude_attributes_value', {}),
            exclude_attr_ranges=select_param.get('exclude_attr_range', [])
        )
    except Exception as e:
        print(f"setIncludeSymbolFilter 异常: {e}")
    return 0


def setFeaturetypeFilter(line: bool = True, pad: bool = True, surface: bool = True, arc: bool = True, text: bool = True,
                         positive: bool = True, negative: bool = True):
    try:
        ret = base.getSelectParam()
        data = json.loads(ret)
        select_param = data['paras']['param']

        # 清洗所有必须是 list 的字段
        list_fields = [
            'symbols', 'exclude_symbols', 'symbol_range',
            'exclude_symbol_range', 'attr_range', 'exclude_attr_ranges'
        ]
        for key in list_fields:
            val = select_param.get(key, [])
            if not isinstance(val, list):
                if isinstance(val, str) and val.strip() != "":
                    # 底层传了单一的有效字符串(如 "r100")，包裹成 list 抢救一下
                    select_param[key] = [val.strip()]
                else:
                    # 对于空字符串 ""、False、None 等，一律重置为空列表
                    select_param[key] = []

        # 清洗所有必须是 dict 的字段
        dict_fields = ['attributes_value', 'exclude_attributes_value']
        for key in dict_fields:
            val = select_param.get(key, {})
            if not isinstance(val, dict):
                # 遇到非 dict 类型（如 "" 或 False），一律重置为空字典
                select_param[key] = {}

        featuretypes_int = 0
        if pad:
            featuretypes_int |= 0x1
        if line:
            featuretypes_int |= 0x2
        if arc:
            featuretypes_int |= 0x4
        if surface:
            featuretypes_int |= 0x8
        if text:
            featuretypes_int |= 0x10
        if negative:
            featuretypes_int |= 0x20
        if positive:
            featuretypes_int |= 0x40

        base.setSelectParam(
            featuretypes_int,
            select_param.get('symbols', []),
            select_param.get('dcode', 0),
            select_param.get('attributes_flag', -1),
            select_param.get('attributes_value', {}),
            select_param.get('profile_value', 0),
            select_param.get('use_selection', False),
            use_symbol_range=select_param.get('use_symbol_range', False),
            symbol_range=select_param.get('symbol_range', []),
            use_attr_range=select_param.get('use_attr_range', False),
            attr_range=select_param.get('attr_range', []),
            exclude_attributes_value=select_param.get('exclude_attributes_value', {}),
            exclude_attr_ranges=select_param.get('exclude_attr_ranges', [])
        )
    except Exception as e:
        print(f"setFeaturetypeFilter 异常: {e}")
    return 0