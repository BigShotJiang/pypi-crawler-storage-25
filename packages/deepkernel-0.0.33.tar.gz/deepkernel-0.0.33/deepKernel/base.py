import json
import math
import operator
from typing import TypedDict, Dict, List

from deepKernel import deepline


def checkProcessStatus(res: str) -> bool:
    """
    通用解析函数：解析底层接口返回的 JSON 字符串。
    - 如果包含 'status'，返回解析后的布尔值 (True/False)。
    - 如果包含 'result'，返回 result 的实际值。
    - status 和 result 不会同时出现。
    """
    try:
        if not res:
            return False

        data = json.loads(res)

        # 1. 优先判断是否存在 status 字段
        if 'status' in data:
            return str(data['status']).lower() == 'true'

        # 2. 判断是否存在 result 字段（有时在最外层，有时被包裹在 paras 中）
        if 'result' in data:
            return data['result']
        elif 'paras' in data and isinstance(data['paras'], dict) and 'result' in data['paras']:
            return data['paras']['result']

        # 3. 如果两个关键字段都没有，作为异常兜底返回 False
        return False

    except Exception as e:
        print(f"解析底层返回值异常: {e}")
        return False


# 获取step, layer信息
def getGraphic(job):
    data = {
        'func': 'GET_GRAPHICS',
        'paras': {'job': job}
    }
    return deepline.process(json.dumps(data))


# 设置属性筛选
def filterSetAttribute(logic, attribute_list):
    data = {
        'func': 'FILTER_SET_ATR',
        'paras': [{'logic': logic},
                  {'attributes_value': attribute_list}]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 根据筛选选择feature
def selectFeaturesByFilter(job, step, layers):
    data = {
        'func': 'SELECT_FEATURES_BY_FILTER',
        'paras': [{'job': job},
                  {'step': step},
                  {'layer': layers}]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# feature涨缩
# sel_type : 0 selected 1 all
def resizeGlobal(job, step, layers, sel_type, size):
    data = {
        'func': 'GLOBAL_RESIZE',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'sel_type': sel_type},
                  {'size': size},
                  {'corner': False}]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 打开料号
def openJob(path, job):
    data = {
        'func': 'OPEN_JOB',
        'paras': [{'path': path},
                  {'job': job}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 关闭料号
def closeJob(job):
    data = {
        'func': 'CLOSE_JOB',
        'paras':
            {'jobname': job}
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 保存料号
def saveJob(job):
    data = {
        'func': 'JOB_SAVE',
        'paras': [{'job': job}]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 获取当前层所有的feature的symbol信息
def getAllFeaturesReport(job, step, layer):
    data = {
        'func': 'GET_ALL_FEATURES_REPORT',
        'paras': {'job': job,
                  'step': step,
                  'layer': layer}
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 获取当前的筛选条件
def getSelectParam():
    data = {
        'func': 'GET_SELECT_PARAM',
        'paras': {}
    }
    return deepline.process(json.dumps(data))


# 设置新的筛选条件    profile_value//0: all 1: in  2: out
def setSelectParam(featuretypes, symbols: list, dcode:int, attributes_flag, attributes_value: dict,
                   profile_value, use_selection,
                   exclude_symbols: list = [], lines=False, ovals=False,
                   use_length=False, use_angle=False, minlength=0, maxlength=0,
                   minangle=0.0, maxangle=0.0,
                   use_symbol_range=False, symbol_range: list = [],
                   exclude_symbol_range: list = [],
                   use_attr_range=False, attr_range: list = [],
                   exclude_attributes_value: dict = {}, exclude_attr_ranges: list = []):
    list_params = {
        'symbols': symbols,
        'exclude_symbols': exclude_symbols,
        'symbol_range': symbol_range,
        'exclude_symbol_range': exclude_symbol_range,
        'attr_range': attr_range,
        'exclude_attr_ranges': exclude_attr_ranges
    }
    for name, val in list_params.items():
        if not isinstance(val, list):
            raise TypeError(f"参数 '{name}' 必须是 list 类型，当前传入的是: {type(val).__name__}")

    dict_params = {
        'attributes_value': attributes_value,
        'exclude_attributes_value': exclude_attributes_value
    }
    for name, val in dict_params.items():
        if not isinstance(val, dict):
            raise TypeError(f"参数 '{name}' 必须是 dict 类型，当前传入的是: {type(val).__name__}")

    data = {
        'func': 'SET_SELECT_PARAM',
        'paras': {
            'param': {
                'featuretypes': featuretypes,
                'symbols': symbols,
                'exclude_symbols': exclude_symbols,
                'lines': lines,
                'ovals': ovals,
                'use_length': use_length,
                'use_angle': use_angle,
                'minlength': minlength,
                'maxlength': maxlength,
                'minangle': minangle,
                'maxangle': maxangle,
                'dcode': dcode,
                'attributes_flag': attributes_flag,
                'attributes_value': attributes_value,
                'exclude_attributes_value': exclude_attributes_value,
                'profile_value': profile_value,
                'use_selection': use_selection,
                'use_symbol_range': use_symbol_range,
                'symbol_range': symbol_range,
                'exclude_symbol_range': exclude_symbol_range,
                'use_attr_range': use_attr_range,
                'attr_range': attr_range,
                'exclude_attr_ranges': exclude_attr_ranges
            }
        }
    }

    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 创建新层
def createNewLayer(job, step, layer, index):
    data = {
        'func': 'CREATE_NEW_LAYER',
        'paras': {'job': job,
                  'step': step,
                  'layer': layer,
                  'index': index}
    }
    return deepline.process(json.dumps(data))


# 创建新step
def createStep(jobname, stepname, index):
    data = {
        'func': 'CREATE_STEP',
        'paras': {'jobname': jobname,
                  'stepname': stepname,
                  'index': index}
    }
    return deepline.process(json.dumps(data))


# 修改job名
def jobRename(src_jobname, dst_jobname):
    data = {
        'func': 'JOB_RENAME',
        'paras': {'src_jobname': src_jobname,
                  'dst_jobname': dst_jobname}
    }
    return deepline.process(json.dumps(data))


class NewLayerInfo(TypedDict):
    context: str
    end_name: str
    name: str
    old_name: str
    orientation: str
    polarity: str
    row: int
    start_name: str
    step: str
    type: str


# 修改matrix信息
def changeMatrix(jobname: str, old_step_index: int, old_layer_index: int, new_step_name: str,
                 new_layer_info: NewLayerInfo):
    data = {
        'func': 'CHANGE_MATRIX',
        'paras': {'jobname': jobname,
                  'old_step_index': old_step_index,
                  'old_layer_index': old_layer_index,
                  'new_step_name': new_step_name,
                  'new_layer_info': new_layer_info}
    }
    return deepline.process(json.dumps(data))


# 获取matrix信息
def getMatrix(job):
    data = {
        'func': 'GET_MATRIX',
        'paras': {'job': job}
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 加载layer
def openLayer(job, step, layer):
    data = {
        'func': 'OPEN_LAYER',
        'paras': {'jobname': job,
                  'step': step,
                  'layer': layer}
    }
    deepline.process(json.dumps(data))
    return deepline.process(json.dumps(data))


# copy layer
def copyLayer(jobname, org_layer_index, dst_layer, poi_layer_index):
    data = {
        'func': 'COPY_LAYER',
        'paras': {'jobname': jobname,
                  'org_layer_index': org_layer_index,
                  'dst_layer': dst_layer,
                  'poi_layer_index': poi_layer_index}
    }
    return deepline.process(json.dumps(data))


# 删除料号
def jobDelete(jobname):
    data = {
        'func': 'JOB_DELETE',
        'paras': {'src_jobname': jobname}
    }
    return deepline.process(json.dumps(data))


# 删除feature
def selDelete(job, step, layers):
    data = {
        'func': 'SEL_DELETE',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers}]
    }
    return deepline.process(json.dumps(data))


# 清空选择
def clearSelectedFeatures(job, step, layer):
    data = {
        'func': 'CLEAR_SELECTED_FEATURES',
        'paras': {'job': job,
                  'step': step,
                  'layer': layer}
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 获取当前层所有选中的feature的symbol信息
def getSelectedFeaturesReport(job, step, layer):
    data = {
        'func': 'GET_SELECTED_FEATURES_REPORT',
        'paras': {'job': job,
                  'step': step,
                  'layer': layer}
    }
    ret = deepline.process(json.dumps(data))
    return ret


def filterByMode(jobname, step, layer, reference_layers: list, mode, feature_type_ref,
                 symbolnames: list, exclude_symbolnames: list, attrflag=-1, attrlogic=0,
                 attributes: dict = {}, exclude_attributes: dict = {}, use_symbol_range=False,
                 symbol_range: list = [], use_attr_range=False, attr_range: list = [],
                 exclude_symbol_range: list = [], exclude_attr_ranges: list = []):
    list_params = {
        'reference_layers': reference_layers,
        'symbolnames': symbolnames,
        'exclude_symbolnames': exclude_symbolnames,
        'symbol_range': symbol_range,
        'attr_range': attr_range,
        'exclude_symbol_range': exclude_symbol_range,
        'exclude_attr_ranges': exclude_attr_ranges
    }
    for name, val in list_params.items():
        if not isinstance(val, list):
            raise TypeError(f"参数 '{name}' 必须是 list 类型，当前传入的是: {type(val).__name__}")
    dict_params = {
        'attributes': attributes,
        'exclude_attributes': exclude_attributes
    }
    for name, val in dict_params.items():
        if not isinstance(val, dict):
            raise TypeError(f"参数 '{name}' 必须是 dict 类型，当前传入的是: {type(val).__name__}")

    data = {
        'func': 'FILTER_BY_MODE',
        'paras': {
            'jobname': jobname,
            'step': step,
            'layer': layer,
            'reference_layers': reference_layers,
            'mode': mode,
            'feature_type_ref': feature_type_ref,
            'symbolnames': symbolnames,
            'exclude_symbolnames': exclude_symbolnames,
            'attrflag': attrflag,
            'attrlogic': attrlogic,
            'attributes': attributes,
            'exclude_attributes': exclude_attributes,
            'use_symbol_range': use_symbol_range,
            'symbol_range': symbol_range,
            'use_attr_range': use_attr_range,
            'attr_range': attr_range,
            'exclude_symbol_range': exclude_symbol_range,
            'exclude_attr_ranges': exclude_attr_ranges
        }
    }
    # js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 孔分析
def drillCheck(job, step, layers, erf, rout_distance, hole_size, extra_holes,
               hole_seperation, power_ground_short, missing_hole, npth_to_rout,
               use_pth, use_npth, use_via, compensated_rout,
               calculate_board_net_status, ranges):
    """
    执行钻孔检查 (Drill Check)
    """
    data = {
        'func': 'DRILL_CHECK',
        'paras': [
            {'job': job},
            {'step': step},
            {'layers': layers},
            {'erf': erf},
            {'rout_distance': rout_distance},
            {'hole_size': hole_size},
            {'extra_holes': extra_holes},
            {'hole_seperation': hole_seperation},
            {'power_ground_short': power_ground_short},
            {'missing_hole': missing_hole},
            {'npth_to_rout': npth_to_rout},
            {'use_pth': use_pth},
            {'use_npth': use_npth},
            {'use_via': use_via},
            {'compensated_rout': compensated_rout},
            {'calculate_board_net_status': calculate_board_net_status},
            {'ranges': ranges}
        ]
    }

    # js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 插入layer
def insertLayer(job, poi_layer_index):
    data = {
        'func': 'LAYER_INSERT',
        'paras': [{'job': job},
                  {'poi_layer_index': poi_layer_index}]
    }
    # js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 添加symbol筛选
def filterSetIncludeSyms(has_symbols, symbols):
    data = {
        'func': 'FILTER_SET_INCLUDE_SYMS',
        'paras': [{'has_symbols': True},
                  {'symbols': symbols}]
    }
    # js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 反选
def counterElection(job, step, layer):
    data = {
        'func': 'COUNTER_ELECTION',
        'paras': [{'job': job},
                  {'step': step},
                  {'layer': layer}]
    }
    # js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 选中feature
"""selectpolygon :eg.[[0,0],[1,1]]"""


def selectFeature(job, step, layer, selectpolygon, type:int, clear:bool):
    data = {
        'func': 'SELECT_FEATURE',
        'paras': [{'job': job},
                  {'step': step},
                  {'layer': layer},
                  {'selectpolygon': selectpolygon},
                  {'type': type},  # 0:单选          1：框选
                  {'clear': clear}  # True,False
                  ]
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 修改文字
def changeText(job, step, layers, text, font, x_size, y_size, width, polarity, mirror, angle=0):
    data = {
        'func': 'TEXT_CHANGE',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'text': text},
                  {'font': font},
                  {'x_size': x_size},
                  {'y_size': y_size},
                  {'width': width},
                  {'polarity': polarity},
                  {'mirror': mirror},
                  {'angle': angle}
                  ]
    }
    ret = deepline.process(json.dumps(data))
    return ret


# 内外层分析
def signalLayerCheck(job, step, layers, erf, pp_spacing, drill2cu, rout2cu, sliver_min, min_pad_overlap, spacing, stubs,
                     drill, center, rout, smd, size, bottleneck, sliver, pad_connection_check,
                     apply_to, check_missing, use_compensated_rout, sort_spacing, ranges, mode):
    data = {
        'func': 'SIGNAL_LAYER_CHECK',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'erf': erf},
                  {'pp_spacing': pp_spacing},
                  {'drill2cu': drill2cu},
                  {'rout2cu': rout2cu},
                  {'sliver_min': sliver_min},
                  {'min_pad_overlap': min_pad_overlap},
                  {'spacing': spacing},
                  {'stubs': stubs},
                  {'drill': drill},
                  {'center': center},
                  {'rout': rout},
                  {'smd': smd},
                  {'size': size},
                  {'bottleneck': bottleneck},
                  {'sliver': sliver},
                  {'pad_connection_check': pad_connection_check},
                  {'apply_to': apply_to},
                  {'check_missing': check_missing},
                  {'use_compensated_rout': use_compensated_rout},
                  {'sort_spacing': sort_spacing},
                  {'ranges': ranges},
                  {'mode': mode}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 内外层优化
def signalLayerDFM(job, step, layers, erf, pth_ar_min, pth_ar_opt, via_ar_min, via_ar_opt, mvia_ar_min, mvia_ar_opt,
                   spacing_min, spacing_opt,
                   pad_to_pad_spacing_min, pad_to_pad_spacing_opt, lre_range_fr, lre_range_to, reduction, abs_min,
                   drill_to_cu,
                   apply_to, pads, smds, drills, padup, shave, paddn, rerout, linedn, reshape, padup_can_touch_pad,
                   cut_pad_touch_pad, laser_ar_min,
                   laser_ar_opt, buried_min, buried_opt, ranges):
    data = {
        'func': 'SIGNAL_LAYER_DFM',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'erf': erf},
                  {'pth_ar_min': pth_ar_min},
                  {'pth_ar_opt': pth_ar_opt},
                  {'via_ar_min': via_ar_min},
                  {'via_ar_opt': via_ar_opt},
                  {'mvia_ar_min': mvia_ar_min},
                  {'mvia_ar_opt': mvia_ar_opt},
                  {'spacing_min': spacing_min},
                  {'spacing_opt': spacing_opt},
                  {'pad_to_pad_spacing_min': pad_to_pad_spacing_min},
                  {'pad_to_pad_spacing_opt': pad_to_pad_spacing_opt},
                  {'lre_range_fr': lre_range_fr},
                  {'lre_range_to': lre_range_to},
                  {'reduction': reduction},
                  {'abs_min': abs_min},
                  {'drill_to_cu': drill_to_cu},
                  {'apply_to': apply_to},
                  {'pads': pads},
                  {'smds': smds},
                  {'drills': drills},
                  {'padup': padup},
                  {'shave': shave},
                  {'paddn': paddn},
                  {'rerout': rerout},
                  {'linedn': linedn},
                  {'reshape': reshape},
                  {'padup_can_touch_pad': padup_can_touch_pad},
                  {'cut_pad_touch_pad': cut_pad_touch_pad},
                  {'laser_ar_min': laser_ar_min},
                  {'laser_ar_opt': laser_ar_opt},
                  {'buried_ar_min': buried_min},
                  {'buried_ar_opt': buried_opt},
                  {'ranges': ranges}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 打散feature
def selBreak(job, step, layers, sel_type):
    data = {
        'func': 'SEL_BREAK',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'sel_type': sel_type}
                  ]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 复制Step
def copyStep(job, org_step_index, dst_step, poi_step_index):
    data = {
        'func': 'COPY_STEP',
        'paras': {'jobname': job,
                  'org_step_index': org_step_index,
                  'dst_step': dst_step,
                  'poi_step_index': poi_step_index}
    }
    ret = deepline.process(json.dumps(data))
    return ret


# 插入step
def insertStep(job, poi_step_index):
    data = {
        'func': 'INSERT_STEP',
        'paras': {'jobname': job,
                  'poi_step_index': poi_step_index}
    }
    ret = deepline.process(json.dumps(data))
    return ret


# layerCompareBmp
def layerCompareBmp(jobname1, stepname1, layername1, jobname2, stepname2, layername2, tolerance, grid_size, savepath,
                    suffix, bmp_width, bmp_height):
    data = {
        'func': 'LAYER_COMPARE_BMP',
        'paras': {'jobname1': jobname1,
                  'stepname1': stepname1,
                  'layername1': layername1,
                  'jobname2': jobname2,
                  'stepname2': stepname2,
                  'layername2': layername2,
                  'tolerance': tolerance,
                  'grid_size': grid_size,
                  'savepath': savepath,
                  'suffix': suffix,
                  'bmp_width': bmp_width,
                  'bmp_height': bmp_height}
    }
    ret = deepline.process(json.dumps(data))
    return ret


# 泪滴优化
def teardropCreateDFM(job, step, layers, erf, sel_type, drilled_pads, undrilled_pads, ann_ring_min, drill_size_min,
                      drill_size_max,
                      cu_spacing, drill_spacing, delete_old_teardrops, apply_to, work_mode, use_arc_tear, arc_angle,
                      bga_pads,
                      tear_line_width_ratio, ranges):
    data = {
        'func': 'TEARDROP_CREATE_DFM',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'erf': erf},
                  {'type': sel_type},
                  {'drilled_pads': drilled_pads},
                  {'undrilled_pads': undrilled_pads},
                  {'ann_ring_min': ann_ring_min},
                  {'drill_size_min': drill_size_min},
                  {'drill_size_max': drill_size_max},
                  {'cu_spacing': cu_spacing},
                  {'drill_spacing': drill_spacing},
                  {'delete_old_teardrops': delete_old_teardrops},
                  {'apply_to': apply_to},
                  {'work_mode': work_mode},
                  {'use_arc_tear': use_arc_tear},
                  {'arc_angle': arc_angle},
                  {'bga_pads': bga_pads},
                  {'tear_line_width_ratio': tear_line_width_ratio},
                  {'ranges': ranges}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 拼板
def stepRepeat(job, parentstep, childsteps):
    data = {
        'func': 'STEP_REPEAT',
        'paras': {'jobname': job,
                  'parentstep': parentstep,
                  'childsteps': childsteps}
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 设置基准点
def setDatumPoint(job, stepname, point_x, point_y):
    data = {
        'func': 'SET_DATUM_POINT',
        'paras': {'jobname': job,
                  'stepname': stepname,
                  'point': {'ix': point_x, 'iy': point_y}}
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 获取profile box
def getProfileBox(jobname, stepname):
    data = {
        'func': 'PROFILE_BOX',
        'paras': {'job': jobname,
                  'step': stepname}
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 修改feature的叠放顺序
def selIndex(job, step, layers, mode):
    data = {
        'func': 'SEL_INDEX',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'mode': mode}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 新建profile线
def createProfile(jobname, stepname, layername):
    data = {
        'func': 'CREATE_PROFILE',
        'paras': {'jobname': jobname,
                  'stepname': stepname,
                  'layername': layername}
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 添加线
# polarity:1 P 0 N
def addLine(job, step, layers, layer, symbol, start_x, start_y, end_x, end_y, polarity, dcode, attributes):
    data = {
        'func': 'ADD_LINE',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'layer': layer},
                  {'symbol': symbol},
                  {'start_x': start_x},
                  {'start_y': start_y},
                  {'end_x': end_x},
                  {'end_y': end_y},
                  {'polarity': polarity},
                  {'dcode': dcode},
                  {'attributes': attributes}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 跨层复制feature
def selCopyOther(src_job, src_step, src_layers, dst_layers, invert, offset_x, offset_y,
                 mirror, resize, rotation, x_anchor, y_anchor):
    data = {
        'func': 'SEL_COPY_OTHER',
        'paras': [{'src_job': src_job},
                  {'src_step': src_step},
                  {'src_layers': src_layers},
                  {'dst_layers': dst_layers},
                  {'invert': invert},
                  {'offset_x': offset_x},
                  {'offset_y': offset_y},
                  {'mirror': mirror},
                  {'resize': resize},
                  {'rotation': rotation},
                  {'x_anchor': x_anchor},
                  {'y_anchor': y_anchor}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


"""
#删除layer
:param     job:
:param     layer_index:
:returns   :
:raises    error:
"""


def deleteLayer(job, layer_index):
    data = {
        'func': 'DELETE_LAYER',
        'paras': {'jobname': job,
                  'layer_index': layer_index}
    }
    ret = deepline.process(json.dumps(data))
    return ret


# profile线间新建layer
def createLayerBetweenProfile(jobname, stepname, new_layername, child_profile_margin):
    data = {
        'func': 'CREATE_LAYER_BETWEEN_PROFILE',
        'paras': {'jobname': jobname,
                  'stepname': stepname,
                  'new_layername': new_layername,
                  'child_profile_margin': child_profile_margin}
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 添加surface
def addSurface(job, step, layers, layer, polarity, dcode, isround, attributes, points_location):
    data = {
        'func': 'ADD_SURFACE',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'layer': layer},
                  {'polarity': polarity},
                  {'dcode': dcode},
                  {'isround': isround},
                  {'attributes': attributes},
                  {'points_location': points_location}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 区域切割(profile)
def clipAreaUseProfile(job, step, layers: List[str], clipinside, clipcontour, margin, featuretype, smooth_tolerance):
    if isinstance(layers, str):
        layers = [layers]
    elif not isinstance(layers, list):
        raise TypeError(f"layers 参数必须是字符串或列表，当前收到: {type(layers)}")

    data = {
        'func': 'CLIP_AREA_USE_PROFILE',
        'paras': {
            'job': job,
            'step': step,
            'layer': layers,
            'clipinside': clipinside,
            'clipcontour': clipcontour,
            'margin': margin,
            'featuretype': featuretype,
            'smooth_tolerance': smooth_tolerance
        }
    }
    # js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 避铜
def avoidConductorDFMOp(jobname, stepname, layernames, erf, coverage_min, coverage_opt, radius_opt, mending_copper_wire,
                        is_fast, use_global, viadrill2cu, pthdrill2cu):
    data = {
        'func': 'AVOID_CONDUCTOR_DFM_OP',
        'paras': [{'jobname': jobname},
                  {'stepname': stepname},
                  {'layernames': layernames},
                  {'erf': erf},
                  {'coverage_min': coverage_min},
                  {'coverage_opt': coverage_opt},
                  {'radius_opt': radius_opt},
                  {'mending_copper_wire': mending_copper_wire},
                  {'is_fast': is_fast},
                  {'use_global': use_global},
                  {'pthdrill2cu': pthdrill2cu},
                  {'viadrill2cu': viadrill2cu}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 去尖角
def removeSharpAngle(job, step, layers: list, scope, radius, type, is_round):
    if not isinstance(layers, list):
        raise TypeError(f"参数 'layers' 必须是 list 类型，当前传入的是: {type(layers).__name__}")

    data = {
        'func': 'REMOVE_SHARP_ANGLE',
        'paras': {
            'para': {
                'job': job,
                'step': step,
                'scope': scope,
                'radius': radius,
                'type': type,
                'is_round': is_round
            },
            'layers': layers
        }
    }

    # js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 获取当前层所有选中的feature的symbol信息
"""
featureinfo:
type:   1        pad
            2       line
            4       surface
            8       arc
            16      text
            32      barcode
            64      text_plus
            0       unknow
"""


def getSelectedFeatureInfos(jobname, stepname, layername, featureInfos):
    data = {
        'func': 'GET_SELECTED_FEATURE_INFOS',
        'paras': {'jobname': jobname,
                  'stepname': stepname,
                  'layername': layername,
                  'featureInfos': featureInfos}
    }
    ret = deepline.process(json.dumps(data))
    return ret


# 获取当前层所有feature的symbol信息
def getAllFeatureInfos(job, step, layer):
    data = {
        'func': 'GET_ALL_FEATURE_INFOS',
        'paras': {'jobname': job,
                  'stepname': step,
                  'layername': layer}
    }
    ret = deepline.process(json.dumps(data))
    return ret


# 防焊层优化
def solderMaskDFM(job, step, layers, erf, clearance_min, clearance_opt, coverage_min, coverage_opt, bridge_opt,
                  bridge_min, apply_to, use_existing_mask, use_shaves, do_resize, max_oversized_clearance,
                  intersect_width, cut_surplus_width, cut_surplus_height, is_round, fan_shaved,
                  prevent_vertical_flow_add_sm, prevent_vertical_flow_del_sm,
                  drill_clearance_min, drill_clearance_opt, smd_clearance_min,
                  smd_clearance_opt, bga_clearance_min, bga_clearance_opt, add_outline, outline_width,
                  he_hong_resize_sm_in_surface, resize_gas_sm_no_drill, resize_gas_sm_has_drill,
                  add_v_cut_sm_size, resize_sm_surface_size, pth_fan_shaved, pad_covered_clearance, ranges):
    data = {
        'func': 'SOLDER_MASK_DFM',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'erf': erf},
                  {'clearance_min': clearance_min},
                  {'clearance_opt': clearance_opt},
                  {'coverage_min': coverage_min},
                  {'coverage_opt': coverage_opt},
                  {'bridge_opt': bridge_opt},
                  {'bridge_min': bridge_min},
                  {'apply_to': apply_to},
                  {'use_existing_mask': use_existing_mask},
                  {'use_shaves': use_shaves},
                  {'do_resize': do_resize},
                  {'max_oversized_clearance': max_oversized_clearance},
                  {'intersect_width': intersect_width},
                  {'cut_surplus_width': cut_surplus_width},
                  {'cut_surplus_height': cut_surplus_height},
                  {'is_round': is_round},
                  {'fan_shaved': fan_shaved},
                  {'prevent_vertical_flow_add_sm': prevent_vertical_flow_add_sm},
                  {'prevent_vertical_flow_del_sm': prevent_vertical_flow_del_sm},
                  {'drill_clearance_min': drill_clearance_min},
                  {'drill_clearance_opt': drill_clearance_opt},
                  {'smd_clearance_min': smd_clearance_min},
                  {'smd_clearance_opt': smd_clearance_opt},
                  {'bga_clearance_min': bga_clearance_min},
                  {'bga_clearance_opt': bga_clearance_opt},
                  {'add_outline': add_outline},
                  {'outline_width': outline_width},
                  {'he_hong_resize_sm_in_surface': he_hong_resize_sm_in_surface},
                  {'resize_gas_sm_no_drill': resize_gas_sm_no_drill},
                  {'resize_gas_sm_has_drill': resize_gas_sm_has_drill},
                  {'add_v_cut_sm_size': add_v_cut_sm_size},
                  {'resize_sm_surface_size': resize_sm_surface_size},
                  {'pth_fan_shaved': pth_fan_shaved},
                  {'pad_covered_clearance': pad_covered_clearance},
                  {'ranges': ranges}
                  ]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 求一个范围内最小距离
def getSelectedFeatureMinSpacing(jobname, stepname, layername, search_radium, min_spacing):
    data = {
        'func': 'GET_SELECTED_FEATURE_MIN_SPACING',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'layername': layername,
            'search_radium': search_radium,
            'min_spacing': min_spacing
        }
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 移动layer
def moveLayer(jobname, org_layer_index, dst_layer_index):
    data = {
        'func': 'MOVE_LAYER_POI',
        'paras': {
            'jobname': jobname,
            'org_layer_index': org_layer_index,
            'dst_layer_index': dst_layer_index,
        }
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# contour to pad
def contour2pad(job, step, layers, tol, minsize, maxsize, suffix):
    data = {
        'func': 'CONTOUR2PAD',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'tol': tol},
                  {'minsize': minsize},
                  {'maxsize': maxsize},
                  {'suffix': suffix}
                  ]
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# resizePolyline
def resizePolyline(job, step, layers, size, sel_type):
    data = {
        'func': 'POLYLINE_RESIZE',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'size': size},
                  {'sel_type': sel_type},
                  ]
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 求最小公差
def getMinTolerance(jobname, stepname, layername1, layername2, selectbox):
    data = {
        'func': 'GET_MIN_TOLERANCE',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'layername1': layername1,
            'layername2': layername2,
            'selectbox': selectbox
        }
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


"""
#删除step
:param     job:
:param     step_index:
:returns   :
:raises    error:
"""


def deleteStep(job, step_index):
    data = {
        'func': 'DELETE_STEP',
        'paras': {'jobname': job,
                  'step_index': step_index}
    }
    ret = deepline.process(json.dumps(data))
    return ret


# 跨层移动feature
def selMoveOther(src_job, src_step, src_layers, dst_job, dst_step, dst_layer, invert, offset_x, offset_y,
                 mirror, resize, rotation, x_anchor, y_anchor):
    data = {
        'func': 'SEL_MOVE_OTHER',
        'paras': [{'src_job': src_job},
                  {'src_step': src_step},
                  {'src_layers': src_layers},
                  {'dst_job': dst_job},
                  {'dst_step': dst_step},
                  {'dst_layer': dst_layer},
                  {'invert': invert},
                  {'offset_x': offset_x},
                  {'offset_y': offset_y},
                  {'mirror': mirror},
                  {'resize': resize},
                  {'rotation': rotation},
                  {'x_anchor': x_anchor},
                  {'y_anchor': y_anchor}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# smd_bga pad 优化
def smdBgaDFMOp(jobname, stepname, layernames, erf, smd_bga_spacing_opt, max_padup_value):
    data = {
        'func': 'SMD_BGA_DFM_OP',
        'paras': [{'jobname': jobname},
                  {'stepname': stepname},
                  {'layernames': layernames},
                  {'erf': erf},
                  {'smd_bga_spacing_opt': smd_bga_spacing_opt},
                  {'max_padup_value': max_padup_value}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# load layer
def loadLayer(jobname, stepname, layername):
    data = {
        'func': 'LOAD_LAYER',
        'paras': {'jobname': jobname,
                  'stepname': stepname,
                  'layername': layername}
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 设置显示模式
def setDisplayWidths(width):
    data = {
        'func': 'SET_DISPLAY_WIDTHS',
        'paras': [{'width': width}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 设置文字显示模式
def setDisplayText(disp):
    data = {
        'func': 'SET_DISPLAY_TEXT',
        'paras': [{'disp': disp}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 设置单位
def setUnits(units):
    data = {
        'func': 'SET_UNITS',
        'paras': [{'units': units}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 设置是否显示profile线
def setDisplayProfile(mode):
    data = {
        'func': 'SET_DISPLAY_PROFILE',
        'paras': [{'mode': mode}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 避npth孔和profile线 优化
def avoidFeaturesDFMOp(jobname, stepname, layernames, erf, avoid_profile, avoid_profile_size, avoid_npth,
                       avoid_npth_size, avoid_alone_drill, avoid_alone_drill_size, avoid_v_cut_size):
    data = {
        'func': 'AVOID_FEATURES_DFM_OP',
        'paras': [{'jobname': jobname},
                  {'stepname': stepname},
                  {'layernames': layernames},
                  {'erf': erf},
                  {'avoid_profile': avoid_profile},
                  {'avoid_profile_size': avoid_profile_size},
                  {'avoid_npth': avoid_npth},
                  {'avoid_npth_size': avoid_npth_size},
                  {'avoid_alone_drill': avoid_alone_drill},
                  {'avoid_alone_drill_size': avoid_alone_drill_size},
                  {'avoid_v_cut_size': avoid_v_cut_size}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# sliver 优化
def sliverDFMOp(jobname, stepname, layernames, erf, max_width, max_height):
    data = {
        'func': 'SLIVER_DFM_OP',
        'paras': [{'jobname': jobname},
                  {'stepname': stepname},
                  {'layernames': layernames},
                  {'erf': erf},
                  {'max_width': max_width},
                  {'max_height': max_height}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# contourize
def contourize(job, step, layers, accuracy, separate_to_islands, size, mode):
    data = {
        'func': 'CONTOURIZE',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'accuracy': accuracy},
                  {'separate_to_islands': separate_to_islands},
                  {'size': size},
                  {'mode': mode}, ]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# identify
def fileIdentify(path):
    data = {
        'func': 'FILE_IDENTIFY',
        'paras': {'pathname': path}
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


def setSelection(is_standard, is_clear, all_layers, is_select, inside, exclude):
    data = {
        'func': 'SET_SELECTION',
        'paras': {'sels': {
            'is_standard': is_standard,
            'is_clear': is_clear,
            'all_layers': all_layers,
            'is_select': is_select,
            'inside': inside,
            'exclude': exclude}
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 去除独立pad优化
def NFPRemovalDFM(job, step, layers, erf, isolated, drill_over, duplicate, covered, work_on, pth, pth_pressfit, npth,
                  via_laser, via, via_photo, remove_undrilled_pads, apply_to, remove_mark_NFP, ranges):
    data = {
        'func': 'NFP_REMOVAL_DFM',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'erf': erf},
                  {'isolated': isolated},
                  {'drill_over': drill_over},
                  {'duplicate': duplicate},
                  {'covered': covered},
                  {'work_on': work_on},
                  {'pth': pth},
                  {'pth_pressfit': pth_pressfit},
                  {'npth': npth},
                  {'via_laser': via_laser},
                  {'via': via},
                  {'via_photo': via_photo},
                  {'remove_undrilled_pads': remove_undrilled_pads},
                  {'apply_to': apply_to},
                  {'remove_mark_NFP': remove_mark_NFP},
                  {'ranges': ranges}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# neo削PAD
def NewSignalLayerDFM(job, step, layers, erf, cut_pad_touch_pad, drill_to_cu):
    data = {
        'func': 'NEW_SIGNAL_LAYER_DFM',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'erf': erf},
                  {'cut_pad_touch_pad': cut_pad_touch_pad},
                  {'drill_to_cu': drill_to_cu}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 设置梯形图relationship
def setRelationship(colname, rowname, relation_value, relation_ratio):
    data = {
        'func': 'SETRELATIONSHIP',
        'paras': [{'colname': colname},
                  {'rowname': rowname},
                  {'relation_value': relation_value},
                  {'relation_ratio': relation_ratio}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 获取梯形图relationship
def getRelationship(isoutter):
    data = {
        'func': 'GETRELATIONSHIP',
        'paras': [{'isoutter': isoutter}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 设置梯形图Introduction
def setIntroduction(attributename, min_resize, min_ring, opt_resize, opt_ring, is_shave):
    data = {
        'func': 'SETINTRODUCTION',
        'paras': [{'attributename': attributename},
                  {'min_resize': min_resize},
                  {'min_ring': min_ring},
                  {'opt_resize': opt_resize},
                  {'opt_ring': opt_ring},
                  {'is_shave': is_shave}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 获取梯形图Introduction
def getIntroduction(isoutter):
    data = {
        'func': 'GETINTRODUCTION',
        'paras': [{'isoutter': isoutter}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 料号另存为
def saveJobAs(job, path):
    data = {
        'func': 'SAVE_JOB_AS',
        'paras': {
            'job': job,
            'path': path
        }
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 添加pad
def addPad(job, step, layers, layer, symbol, location_x, location_y, polarity, dcode, orient, attributes,
           special_angle=0):
    if symbol == "":
        return
    aa = identifySymbol(symbol)
    ret = json.loads(identifySymbol(symbol))['result']
    if not ret:
        aa = json.loads(isJobOpen('eplib'))['paras']['status']
        if aa:
            copyUsersymbolToOtherJob('eplib', job, symbol, symbol)
    data = {
        'func': 'ADD_PAD',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'layer': layer},
                  {'symbol': symbol},
                  {'location_x': location_x},
                  {'location_y': location_y},
                  {'polarity': polarity},
                  {'dcode': dcode},
                  {'orient': orient},
                  {'attributes': attributes},
                  {'special_angle': special_angle}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 取消选中
def unselectFeatures(job, step, layer):
    data = {
        'func': 'UNSELECT_FEATURES',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer
        }
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 根据筛选器取消选中
def unselectFeaturesByFilter(job, step, layers):
    data = {
        'func': 'UNSELECT_FEATURES_BY_FILTER',
        'paras': [
            {'job': job},
            {'step': step},
            {'layer': layers}
        ]
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# dms create job
def DMSCreateJob(job):
    data = {
        'func': 'DMS_CREATE_JOB',
        'paras': {'job': job}

    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


def loadJobFromDb(job_id, odb_jobname, db_jobname):
    data = {
        'func': 'LOADJOBFROMDB',
        'paras': {'job_id': job_id,
                  'odb_jobname': odb_jobname,
                  'db_jobname': db_jobname}

    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


def login(username, password):
    data = {
        'func': 'LOGIN',
        'paras': {'name': username,
                  'pwd': password}
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# #设置机器人参数
# def setParameter(layer, pa, value):
#     data = {
#         'func': 'SETPARAMETER',
#         'paras': [{'layer': layer},
#                   {'pa': pa},
#                   {'value': value}]
#     }
#     #print(json.dumps(data))
#     ret = deepline.process(json.dumps(data))

# 设置机器人参数
def setParameter(rules):
    data = {
        'func': 'SETPARAMETER',
        'paras': [{'rules': rules}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# 设置参数(整个料)
def setJobParameter(jobName, rules):
    data = {
        'func': 'SETJOBPARAMETER',
        'paras': {
            'rules': rules,
            'jobName': jobName
        }
    }
    ret = deepline.process(json.dumps(data))
    return ret


# 设置参数(整个料)
def getJobParameter(jobName):
    data = {
        'func': 'GETJOBPARAMETER',
        'paras': {
            'job': jobName
        }
    }
    ret = deepline.process(json.dumps(data))
    return ret


# 获取机器人参数
def getParameter():
    data = {
        'func': 'GETPARAMETER',
        'paras': []
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 设置分析结果
def setLayerChecklist(jobName, stepName, layerName, checkList):
    data = {
        'func': 'SET_LAYER_CHECKLIST',
        'paras': {
            'jobName': jobName,
            'stepName': stepName,
            'layerName': layerName,
            'checkList': checkList
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# translate
def fileTranslate(path, job, step, layer, parameters: dict, start_time: dict, end_time: dict, assigned_dcodes: list):
    dict_params = {
        'parameters': parameters,
        'start_time': start_time,
        'end_time': end_time
    }
    for name, val in dict_params.items():
        if not isinstance(val, dict):
            raise TypeError(f"参数 '{name}' 必须是 dict 类型，当前传入的是: {type(val).__name__}")

    if not isinstance(assigned_dcodes, list):
        raise TypeError(f"参数 'assigned_dcodes' 必须是 list 类型，当前传入的是: {type(assigned_dcodes).__name__}")

    data = {
        'func': 'FILE_TRANSLATE',
        'paras': {
            'path': path,
            'job': job,
            'step': step,
            'layer': layer,
            'parameters': parameters,
            'start_time': start_time,
            'end_time': end_time,
            'assigned_dcodes': assigned_dcodes
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 创建料号（无路径）
def jobCreate(job):
    data = {
        'func': 'JOB_CREATE',
        'paras': {
            'job': job
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# translate init
def fileTranslateInit(jobname):
    data = {
        'func': 'FILE_TRANSLATE_INIT',
        'paras': {
            'jobname': jobname
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 创建料号（有路径）
def createJob(path, job):
    data = {
        'func': 'CREATE_JOB',
        'paras': {
            'path': path,
            'job': job
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 删除料号
def deleteJob(job):
    data = {
        'func': 'JOB_DELETE',
        'paras': {
            'src_jobname': job
        }
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


def addOutlineDrill(job, step, outerline_layer, drill_layer, add_drill_symbolname, move_offset_in_corner,
                    angle_tolerance):
    data = {
        'func': 'ADD_OUTLINE_DRILL',
        'paras': [{'job': job},
                  {'step': step},
                  {'outerline_layer': outerline_layer},
                  {'drill_layer': drill_layer},
                  {'add_drill_symbolname': add_drill_symbolname},
                  {'move_offset_in_corner': move_offset_in_corner},
                  {'angle_tolerance': angle_tolerance}]
    }
    # print(json.dumps(data))
    ret = deepline.process(json.dumps(data))
    return ret


# getCouponSingleEndDrillPositions
def getCouponSingleEndDrillPositions(xmin, ymin, xmax, ymax, x_margin, y_margin, npth_size, pth_size, pth_ring,
                                     avoid_cu_global, clearance,
                                     pth_to_gnd_drill, min_cu_width, single_lines, differential_lines):
    data = {
        'func': 'GET_COUPON_SINGLE_END_DRILL_POSITIONS',
        'paras': {
            'xmin': xmin,
            'ymin': ymin,
            'xmax': xmax,
            'ymax': ymax,
            'x_margin': x_margin,
            'y_margin': y_margin,
            'npth_size': npth_size,
            'pth_size': pth_size,
            'pth_ring': pth_ring,
            'avoid_cu_global': avoid_cu_global,
            'clearance': clearance,
            'pth_to_gnd_drill': pth_to_gnd_drill,
            'min_cu_width': min_cu_width,
            'single_lines': single_lines,
            'differential_lines': differential_lines
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# index筛选
def selectFeatureById(job, step, layer, ids):
    data = {
        'func': 'SELECT_FEATURE_BY_ID',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'ids': ids
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 设置profile
def setStepProfile(job, step, points):
    data = {
        'func': 'SET_STEP_PROFILE',
        'paras': {
            'job': job,
            'step': step,
            'points': points
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# change symbol
def changeFeatureSymbols(job, step, layers, symbol, pad_angle):
    data = {
        'func': 'CHANGE_FEATURE_SYMBOLS',
        'paras': {
            'job': job,
            'step': step,
            'layers': layers,
            'symbol': symbol,
            'pad_angle': pad_angle
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# clipAreaUseReference
def clipAreaUseReference(jobname, stepname, work_layer: list, reference_layer, margin, smooth_tolerance,
                         clipcontour, featuretype):
    if isinstance(work_layer, str):
        layer = [work_layer]
    elif not isinstance(work_layer, list):
        raise TypeError(f"work_layer 参数必须是字符串或列表，当前收到: {type(work_layer)}")

    data = {
        'func': 'CLIP_AREA_USE_REFERENCE',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'work_layer': work_layer,
            'reference_layer': reference_layer,
            'margin': margin,
            'smooth_tolerance': smooth_tolerance,
            'clipcontour': clipcontour,
            'featuretype': featuretype
        }
    }
    # js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# clipAreaUseManual
def clipAreaUseManual(job, step, layer: List[str], points: List[Dict], margin, clipcontour, clipinside, featuretype,
                      smooth_tolerance):
    if isinstance(layer, str):
        layer = [layer]
    elif not isinstance(layer, list):
        raise TypeError(f"layer 参数必须是字符串或列表，当前收到: {type(layer)}")

    if not isinstance(points, list):
        raise TypeError("points 参数必须是一个包含坐标字典的列表，例如 [{'ix': 10, 'iy': 20}]")

    data = {
        'func': 'CLIP_AREA_USE_MANUAL',
        'paras': {
            'job': job,
            'step': step,
            'layers': layer,
            'points': points,
            'margin': margin,
            'clipcontour': clipcontour,
            'clipinside': clipinside,
            'featuretype': featuretype,
            'smooth_tolerance': smooth_tolerance
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# line2padNew
def line2padNew(job, step, layers):
    data = {
        'func': 'RESHAPE_LINE_TO_PAD_NEW',
        'paras': {
            'job': job,
            'step': step,
            'layers': layers
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# pth npth开窗
def npthAndPthPrepareOp(job, step, sm_clearance, sm_np_clearance, add_sm_pads, add_signal_pads):
    data = {
        'func': 'NPTH_AND_PTH_PREPARE_OP',
        'paras': {
            'job': job,
            'step': step,
            'sm_clearance': sm_clearance,
            'sm_np_clearance': sm_np_clearance,
            'add_sm_pads': add_sm_pads,
            'add_signal_pads': add_signal_pads
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 修改属性
def modifyAttributes(job, step, layers, mode, attributes):
    data = {
        'func': 'MODIFY_ATTRIBUTES',
        'paras': {
            'jobname': job,
            'stepname': step,
            'layernames': layers,
            'mode': mode,
            'attributes': attributes
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# coupon获取线的坐标
def getCouponDrillLineRelations(xmin, ymin, xmax, ymax, x_margin, y_margin, npth_size, pth_size, pth_ring,
                                avoid_cu_global, clearance,
                                pth_to_gnd_drill, min_cu_width, single_lines, differential_lines, single_group_count,
                                diff_group_count, drill_positions):
    data = {
        'func': 'GET_COUPON_DRILL_LINE_RELATIONS',
        'paras': {
            'xmin': xmin,
            'ymin': ymin,
            'xmax': xmax,
            'ymax': ymax,
            'x_margin': x_margin,
            'y_margin': y_margin,
            'npth_size': npth_size,
            'pth_size': pth_size,
            'pth_ring': pth_ring,
            'avoid_cu_global': avoid_cu_global,
            'clearance': clearance,
            'pth_to_gnd_drill': pth_to_gnd_drill,
            'min_cu_width': min_cu_width,
            'single_lines': single_lines,
            'differential_lines': differential_lines,
            'single_group_count': single_group_count,
            'diff_group_count': diff_group_count,
            'drill_positions': drill_positions
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 添加文字
def addText(job, step, layer, symbol, fontname, text, xsize, ysize, linewidth, location_x, location_y, polarity,
            orient, version, layers, attributes, special_angle=0):
    data = {
        'func': 'ADD_TEXT',
        'paras': [{'job': job},
                  {'step': step},
                  {'layer': layer},
                  {'symbol': symbol},
                  {'fontname': fontname},
                  {'text': text},
                  {'xsize': xsize},
                  {'ysize': ysize},
                  {'linewidth': linewidth},
                  {'location_x': location_x},
                  {'location_y': location_y},
                  {'polarity': polarity},
                  {'orient': orient},
                  {'version': version},
                  {'layers': layers},
                  {'attributes': attributes},
                  {'special_angle': special_angle}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# surface2outline
def surface2outline(job, step, layers, width):
    data = {
        'func': 'SURFACE2OUTLINE',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'width': width}
                  ]
    }
    js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 层别比对
def layerComparePoint(jobname1, stepname1, layername1, jobname2, stepname2, layername2,
                      tolerance=22860, mode=True, consider_SR=True, map_layer_resolution=5080000):
    data = {
        'func': 'LAYER_COMPARE_POINT',
        'paras': {
            'jobname1': jobname1,
            'stepname1': stepname1,
            'layername1': layername1,
            'jobname2': jobname2,
            'stepname2': stepname2,
            'layername2': layername2,
            'tolerance': tolerance,
            'global': mode,
            'consider_SR': consider_SR,
            'map_layer_resolution': map_layer_resolution,
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 获取选中features的box
def getSelectedFeaturesBox(job, step, layers):
    data = {
        'func': 'GET_SELECTED_FEATURES_BOX',
        'paras': {
            'job': job,
            'step': step,
            'layers': layers
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 导出
def layerExport(job, step, layer, _type, filename, gdsdbu=0.001, resize=0.0, angle=0.0, scalingX=1.0, scalingY=1.0,
                isReverse=False, mirror=False, rotate=False, scale=False, profiletop=False, cw=False, cutprofile=True,
                mirrorpointX=0, mirrorpointY=0, rotatepointX=0, rotatepointY=0, scalepointX=0, scalepointY=0,
                mirrordirection="X", cut_polygon: list = [], numberFormatL=2, numberFormatR=6, zeros=2, unit=0,
                profile_level=1, cellname='', smooth=10, dividepolygon=512, breakarcinfo=[]):
    # 参数预处理与检查
    list_params = {
        'cut_polygon': cut_polygon,
        'breakarcinfo': breakarcinfo
    }
    if cut_polygon is None:
        cut_polygon = []
    for name, val in list_params.items():
        if not isinstance(val, list):
            raise TypeError(f"参数 '{name}' 必须是 list 类型，当前传入的是: {type(val).__name__}")

    data = {
        'func': 'LAYER_EXPORT',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'export_type': _type,
            'filename': filename,
            'gdsdbu': gdsdbu,
            'resize': resize,
            'angle': angle,
            'scalingX': scalingX,
            'scalingY': scalingY,
            'isReverse': isReverse,
            'mirror': mirror,
            'rotate': rotate,
            'scale': scale,
            'profiletop': profiletop,
            'cw': cw,
            'cutprofile': cutprofile,
            'mirrorpointX': mirrorpointX,
            'mirrorpointY': mirrorpointY,
            'rotatepointX': rotatepointX,
            'rotatepointY': rotatepointY,
            'scalepointX': scalepointX,
            'scalepointY': scalepointY,
            'mirrordirection': mirrordirection,
            'cut_polygon': cut_polygon,
            'number_format_l': numberFormatL,
            'number_format_r': numberFormatR,
            'zeros': zeros,
            'unit': unit,
            'profile_level': profile_level,
            'cellname': cellname,
            'smooth': smooth,
            'dividepolygon': dividepolygon,
            'breakarcinfo': breakarcinfo,
        }
    }

    # # js = json.dumps(data)
    # # print(js)
    return deepline.process(json.dumps(data))


# def layerExport(job, step, layer, _type, filename):
#     data = {
#             'func': 'LAYER_EXPORT',
#             'paras': {
#                         'job': job,
#                         'step': step,
#                         'layer': layer,
#                         'type': _type,
#                         'filename': filename
#                       }
#             }
#     js = json.dumps(data)
#     print(js)
#     return deepline.process(json.dumps(data))

# 获取profile polygon
def getProfile(job, step, points: list = None):
    if points is not None and not isinstance(points, list):
        raise TypeError(f"参数 'points' 必须是 list 类型，如 [[x,y], [x,y]]，当前传入的是: {type(points).__name__}")

    paras = {
        'jobname': job,
        'stepname': step
    }

    # 当传入了 points 时，把它组装进字典发给后端
    if points is not None:
        paras['points'] = points

    data = {
        'func': 'GET_PROFILE',
        'paras': paras
    }
    return deepline.process(json.dumps(data))


# 将一个料号中某一layer的信息拷贝至另一料号中
def copyLayerFeatures(src_job, src_step, src_layer, dst_job, dst_step, dst_layer, mode, invert, undo, mirror,
                      rotateAngle, anchorPoint, offsetPoint):
    data = {
        'func': 'COPY_LAYER_FEATURES',
        'paras': {
            'src_job': src_job,
            'src_step': src_step,
            'src_layer': src_layer,
            'dst_job': dst_job,
            'dst_step': dst_step,
            'dst_layer': dst_layer,
            'mode': mode,
            'invert': invert,
            'undo': undo,
            'mirror': mirror,
            'rotateAngle': rotateAngle,
            'anchorPoint': anchorPoint,
            'offsetPoint': offsetPoint
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 层别比对
def layerCompare(jobname1, stepname1, layername1, jobname2, stepname2, layername2, tolerance, mode, consider_SR,
                 comparison_map_layername, map_layer_resolution):
    data = {
        'func': 'LAYER_COMPARE',
        'paras': {
            'jobname1': jobname1,
            'stepname1': stepname1,
            'layername1': layername1,
            'jobname2': jobname2,
            'stepname2': stepname2,
            'layername2': layername2,
            'tolerance': tolerance,
            'global': mode,
            'consider_SR': consider_SR,
            'comparison_map_layername': comparison_map_layername,
            'map_layer_resolution': map_layer_resolution,
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 图形变换
def transform(jobname, stepname, layername, mode, rotate, scale, mirror_X, mirror_Y, duplicate, datumPoint, angle,
              xscale, yscale, xoffset, yoffset):
    data = {
        'func': 'TRANSFORM',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'layernames': layername,
            'mode': mode,
            'rotate': rotate,
            'scale': scale,
            'mirror_X': mirror_X,
            'mirror_Y': mirror_Y,
            'duplicate': duplicate,
            'datumPoint': datumPoint,
            'angle': angle,
            'xscale': xscale,
            'yscale': yscale,
            'xoffset': xoffset,
            'yoffset': yoffset
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 自动定属性
def autoClassifyAttribute(job, step, layers):
    data = {
        'func': 'AUTO_CLASSIFY_ATTRIBUTE',
        'paras': {
            'job': job,
            'step': step,
            'layers': layers
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 自动定属性
def outline2surface(jobname, stepname, layernames: list, can_to_pad, size, unit):
    if not isinstance(layernames, list):
        raise TypeError(f"参数 'layernames' 必须是 list 类型，当前传入的是: {type(layernames).__name__}")

    data = {
        'func': 'RESHAPE_OUTLINE_TO_SURFACE',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'layernames': layernames,
            'can_to_pad': can_to_pad,
            'size': size,
            'unit': unit
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


def reshapeOutlineToSurface(jobname, stepname, layernames: list, can_to_pad, size, unit):
    if not isinstance(layernames, list):
        raise TypeError(f"参数 'layernames' 必须是 list 类型，当前传入的是: {type(layernames).__name__}")

    data = {
        'func': 'RESHAPE_OUTLINE_TO_SURFACE',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'layernames': layernames,
            'can_to_pad': can_to_pad,
            'size': size,
            'unit': unit
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# okStepCheck
def okStepCheck(result):
    data = {
        'func': 'OK_STEP_CHECK',
        'paras': [{
            'result': result
        }]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# getStepRepeat
def getStepRepeat(job, step):
    data = {
        'func': 'GET_STEP_REPEAT',
        'paras': {
            'job': job,
            'step': step
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# getRestCu//残铜无孔开窗                      单位nm²
def getRestCu(job, step, layer, resolution_define, thickness):
    data = {
        'func': 'GET_REST_CU',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'or_and': 'or',
            'resolution_define': resolution_define,
            'thickness': thickness,
            'holes_slots': True,
            'include_soldermask': False,
            'include_drill': True
        }
    }
    js = json.dumps(data)
    print(js)
    return deepline.process(json.dumps(data))

    # getRestCuWithDrill//残铜有孔                     单位nm²


def getRestCuWithDrill(job, step, layer, resolution_define, thickness):
    data = {
        'func': 'GET_REST_CU_WITH_DRILL',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'or_and': 'or',
            'resolution_define': resolution_define,
            'thickness': thickness,
            'holes_slots': True,
            'include_soldermask': True,
            'include_drill': True
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))

    # getCuSolderDrill//残铜有孔开窗                     单位nm²


def getCuSolderDrill(job, step, layer, resolution_define, thickness):
    data = {
        'func': 'GET_CU_SOLDER_DRILL',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'or_and': 'or',
            'resolution_define': resolution_define,
            'thickness': thickness,
            'holes_slots': True,
            'include_soldermask': True,
            'include_drill': True
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))

    # getRestCuSolder//残铜无孔开窗                     单位nm²


def getRestCuSolder(job, step, layer, resolution_define, thickness):
    data = {
        'func': 'GET_REST_CU_SOLDER',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'or_and': 'or',
            'resolution_define': resolution_define,
            'thickness': thickness,
            'holes_slots': True,
            'include_soldermask': True,
            'include_drill': True
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))

    # getOutlayerCu//外层残铜有孔开窗                     单位nm²


def getOutlayerCu(job, step, resolution_define, thickness):
    data = {
        'func': 'GET_OUTLAYER_CU',
        'paras': {
            'job': job,
            'step': step,
            'layer': '',
            'or_and': 'or',
            'resolution_define': resolution_define,
            'thickness': thickness,
            'holes_slots': True,
            'include_soldermask': True,
            'include_drill': True
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))

    # getTotalSquare//计算总面积                    单位nm²


def getTotalSquare(job, step, layer='', or_and='or', resolution_define=0,
                   thickness=0, holes_slots=True, include_soldermask=True):
    data = {
        'func': 'GET_TOTAL_SQUARE',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'or_and': or_and,
            'resolution_define': resolution_define,
            'thickness': thickness,
            'holes_slots': holes_slots,
            'include_soldermask': include_soldermask
        }
    }

    # js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))

    # 计算选中的feature的面积                     单位nm²


def getSelectedFeatureAreas(job, step, layer):
    data = {
        'func': 'GET_SELECTED_FEATURE_AREAS',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))

    #


def resizePolygon(input_poly, resize_value):
    data = {
        'func': 'RESIZE_POLYGON',
        'paras': {
            'input_polygon': input_poly,
            'resize_value': resize_value
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


def getSrCouponPlan(Panel_Height, Panel_Width, x_margin, y_margin, pannel_left, pannel_bottom, pannel_top, pannel_right,
                    job, pcs_step,
                    panel_step, coupon_x_margin, coupon_y_margin, coupon_to_set_margin, npth_size, pth_size, pth_ring,
                    avoid_cu_global, clearance, pth_to_gnd_drill, min_cu_width, single_lines, differential_lines):
    data = {
        'func': 'GET_SR_COUPON_PLAN',
        'paras': {
            'Panel_Height': Panel_Height,
            'Panel_Width': Panel_Width,
            'x_margin': x_margin,
            'y_margin': y_margin,
            'pannel_left': pannel_left,
            'pannel_bottom': pannel_bottom,
            'pannel_top': pannel_top,
            'pannel_right': pannel_right,
            'job': job,
            'pcs_step': pcs_step,
            'panel_step': panel_step,
            'coupon_x_margin': coupon_x_margin,
            'coupon_y_margin': coupon_y_margin,
            'coupon_to_set_margin': coupon_to_set_margin,
            'npth_size': npth_size,
            'pth_size': pth_size,
            'pth_ring': pth_ring,
            'avoid_cu_global': avoid_cu_global,
            'clearance': clearance,
            'pth_to_gnd_drill': pth_to_gnd_drill,
            'min_cu_width': min_cu_width,
            'single_lines': single_lines,
            'differential_lines': differential_lines
        }
    }
    js = json.dumps(data)
    print(js)
    return deepline.process(json.dumps(data))


def drawPanelPicture(job, step, layer, path):
    data = {
        'func': 'DRAW_PANEL_PICTURE',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'path': path
        }
    }
    js = json.dumps(data)
    print(js)
    return deepline.process(json.dumps(data))


def getAllStepRepeatSteps(job, step):
    data = {
        'func': 'GET_ALL_STEP_REPEAT_STEPS',
        'paras': {
            'job': job,
            'step': step
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# def fillProfile(job,step,layer,profile_resize,child_profile_resize,avoid_drill_size,
# fill_by_pattern,symbolname,dx,dy,avoid_drill=True):
#     data = {
#             'func': 'FILL_PROFILE',
#             'paras': {
#                         'job': job,
#                         'step': step,
#                         'layer':layer,
#                         'profile_resize':profile_resize,
#                         'child_profile_resize':child_profile_resize,
#                         'avoid_drill_size':avoid_drill_size,
#                         'fill_by_pattern':fill_by_pattern,  #是否选择自己的symbol填充profile true or false
#                         'symbolname':symbolname,            #fill_by_pattern为false，symbolname填空
#                         'dx':dx,
#                         'dy':dy,
#                         'avoid_drill':avoid_drill
#                         }
#             }
#     js = json.dumps(data)
#     #print(js)
#     return deepline.process(json.dumps(data))

def fillProfile(job, step, layers, step_repeat_nesting, nesting_child_steps, step_margin_x, step_margin_y,
                max_distance_x, max_distance_y, SR_step_margin_x, SR_step_margin_y, SR_max_distance_x, SR_max_distance_y,
                avoid_drill, avoid_rout, avoid_feature, polarity):
    data = {
        'func': 'FILL_PROFILE',
        'paras': {
            'job': job,
            'step': step,
            'layers': layers,
            'step_repeat_nesting': step_repeat_nesting,
            'nesting_child_steps': nesting_child_steps,
            'step_margin_x': step_margin_x,
            'step_margin_y': step_margin_y,
            'max_distance_x': max_distance_x,
            'max_distance_y': max_distance_y,
            'SR_step_margin_x': SR_step_margin_x,
            'SR_step_margin_y': SR_step_margin_y,
            'SR_max_distance_x': SR_max_distance_x,
            'SR_max_distance_y': SR_max_distance_y,
            'avoid_drill': avoid_drill,
            'avoid_rout': avoid_rout,
            'avoid_feature': avoid_feature,
            'polarity': polarity
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


def usePatternFillContours(jobname, stepname, layername, symbolname, dx, dy, break_partial, cut_primitive, origin_point,
                           outline, outlinewidth, outline_invert, odd_offset=0, even_offset=0):
    data = {
        'func': 'USE_PATTERN_FILL_CONTOURS',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'layername': layername,
            'symbolname': symbolname,
            'dx': dx,
            'dy': dy,
            'break_partial': break_partial,
            'cut_primitive': cut_primitive,
            'origin_point': origin_point,
            'outline': outline,
            'outlinewidth': outlinewidth,
            'outline_invert': outline_invert,
            'odd_offset': odd_offset,
            'even_offset': even_offset
        }
    }
    js = json.dumps(data)
    print(js)
    return deepline.process(json.dumps(data))


def slPanelBanding(job, area, isclose_to_src):
    data = {
        'func': 'SL_PANEL_BANDING',
        'paras': {
            'job': job,
            'area': area,
            'isclose_to_src': isclose_to_src
        }
    }

    # js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


def negativeLayerToPositive(jobname, stepname, layernames):
    data = {
        'func': 'NEGATIVE_LAYER_TO_POSITIVE',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'layernames': layernames
        }
    }
    js = json.dumps(data)
    print(js)
    return deepline.process(json.dumps(data))


def translateLines(job, step, layer, op_type, type, ):
    data = {
        'func': 'TRANSLATE_LINES',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'op_type': op_type,
            'type': type
        }
    }
    js = json.dumps(data)
    print(js)
    return deepline.process(json.dumps(data))


def isSelected(job, step, layer):
    data = {
        'func': 'IS_SELECTED',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# contourize
def reshapeContourize(jobname, stepname, layernames, accuracy, separate_to_islands, max_size, clear_mode):
    data = {
        'func': 'RESHAPE_CONTOURIZE',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            '_layernames': layernames,
            'accuracy': accuracy,  # mil 0-2.5
            'separate_to_islands': separate_to_islands,
            'max_size': max_size,
            'clear_mode': clear_mode  # int 0
        }
    }
    return deepline.process(json.dumps(data))


# Guide map
# sub_kind:sub map 需添加的类型
# panel_kind:panel map 需添加的类型
def runMap(jobname, layername, run_sub, run_panel, sub_kind, panel_kind):
    data = {
        'func': 'RUN_MAP',
        'paras': {
            'jobname': jobname,
            'layername': layername,
            'run_sub': run_sub,
            'run_panel': run_panel,
            'sub_kind': sub_kind,
            'panel_kind': panel_kind
        }
    }
    return deepline.process(json.dumps(data))


def addSubJobnameArrow(jobname, step, layername):
    data = {
        'func': 'ADD_SUB_JOBNAME_ARROW',
        'paras': {
            'jobname': jobname,
            'layername': layername,
            'step': step
        }
    }
    return deepline.process(json.dumps(data))


def moveSelectFeatureToOtherStep(jobname, stepname, layername, dest_stepname, delete_org):
    data = {
        'func': 'MOVE_SELECT_FEATURE_TO_OTHER_STEP',
        'paras': {
            'jobname': jobname,
            'layername': layername,
            'stepname': stepname,
            'dest_stepname': dest_stepname,
            'delete_org': delete_org
        }
    }
    return deepline.process(json.dumps(data))


def runEdge(job, step, maplayer, is_ol1_top, is_ol2_top, is_smt_top, is_srd_top, is_psa_top, is_laser_top, is_et_top,
            is_fi_top):
    data = {
        'func': 'RUN_EDGE',
        'paras': {
            'job': job,
            'step': step,
            'maplayer': maplayer,
            'is_ol1_top': is_ol1_top,
            'is_ol2_top': is_ol2_top,
            'is_smt_top': is_smt_top,
            'is_srd_top': is_srd_top,
            'is_psa_top': is_psa_top,
            'is_laser_top': is_laser_top,
            'is_et_top': is_et_top,
            'is_fi_top': is_fi_top
        }
    }
    return deepline.process(json.dumps(data))


# 拷贝usersymbol至另一个料号
def copyUsersymbolToOtherJob(job1, job2, symbol1, symbol2):
    data = {
        'func': 'COPY_USERSYMBOL_TO_OTHER_JOB',
        'paras': {
            'job1': job1,
            'job2': job2,
            'symbol1': symbol1,
            'symbol2': symbol2
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 网格铜
# int dx = 0;//横向骨架线距离
# int dy = 0;//纵向
# int linewidth = 0;
# int x_offset = 0;//第一条线的横向偏移
# int y_offset = 0;//纵向
# int angle = 0;//(0-45)
def fillSelectFeatureByGrid(job, step, layer, dx, dy, linewidth, x_offset, y_offset, angle):
    data = {
        'func': 'FILL_SELECT_FEATURE_BY_GRID',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'dx': dx,
            'dy': dy,
            'linewidth': linewidth,
            'x_offset': x_offset,
            'y_offset': y_offset,
            'angle': angle
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


def moveSelectedFeaturesIndex(job, step, layers, put_last):
    data = {
        'func': 'MOVE_SELECTED_FEATURES_INDEX',
        'paras': {
            'jobname': job,
            'step': step,
            'layers': layers,
            'put_last': put_last
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 添加弧
def addArc(job, step, layers, layer, symbol, start_x, start_y, end_x, end_y, center_x, center_y, cw, polarity, dcode,
           attributes):
    data = {
        'func': 'ADD_ARC',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'layer': layer},
                  {'symbol': symbol},
                  {'start_x': start_x},
                  {'start_y': start_y},
                  {'end_x': end_x},
                  {'end_y': end_y},
                  {'center_x': center_x},
                  {'center_y': center_y},
                  {'cw': cw},
                  {'polarity': polarity},
                  {'dcode': dcode},
                  {'attributes': attributes}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 整体移动目标层的features jobname, stepname, layername, offset_x, offset_y
def moveSameLayer(jobname, stepname, layernames, offset_x, offset_y):
    data = {
        'func': 'MOVE_SAME_LAYER',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'layername': layernames,
            'offset_x': offset_x,
            'offset_y': offset_y
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 获取step拼板信息
def getStepHeaderInfos(job, step):
    data = {
        'func': 'GET_STEP_HEADER_INFOS',
        'paras': {
            'job': job,
            'step': step
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 分类层中的polygon
def classifyPolyline(job, step, layer):
    data = {
        'func': 'CLASSIFY_POLYLINE',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


def selPolarity(job, step, layers, polarity, sel_type):
    data = {
        'func': 'SEL_POLARITY',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'polarity': polarity},
                  {'sel_type': sel_type}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# Prepare分析
def PrepareCheck(job, ranges, solder_paste_top="", silk_screen_top="", solder_mask_top="",
                 signal_layer="", solder_mask_bottom="", silk_screen_bottom="",
                 solder_paste_bottom="", drill_layer="", rout="", outline="",
                 top="", bottom=""):
    paras_list = [
        {'job': job},
        {'ranges': ranges}
    ]

    # 动态追加存在的层名参数
    if solder_paste_top:
        paras_list.append({'solder_paste_top': solder_paste_top})
    if silk_screen_top:
        paras_list.append({'silk_screen_top': silk_screen_top})
    if solder_mask_top:
        paras_list.append({'solder_mask_top': solder_mask_top})
    if signal_layer:
        paras_list.append({'signal_layer': signal_layer})
    if solder_mask_bottom:
        paras_list.append({'solder_mask_bottom': solder_mask_bottom})
    if silk_screen_bottom:
        paras_list.append({'silk_screen_bottom': silk_screen_bottom})
    if solder_paste_bottom:
        paras_list.append({'solder_paste_bottom': solder_paste_bottom})
    if drill_layer:
        paras_list.append({'drill_layer': drill_layer})
    if rout:
        paras_list.append({'rout': rout})
    if outline:
        paras_list.append({'outline': outline})
    if top:
        paras_list.append({'top': top})
    if bottom:
        paras_list.append({'bottom': bottom})

    data = {
        'func': 'PREPARE_CHECK',
        'paras': paras_list
    }

    # js = json.dumps(data)
    # print(js)
    ret = deepline.process(json.dumps(data))
    return ret


# 根据profile创建outline
"""
layers:[]
linewidth: 线宽nm
"""


def profileToOuterline(job, step, layers, linewidth):
    data = {
        'func': 'PROFILE_TO_OUTERLINE',
        'paras': {'job': job,
                  'step': step,
                  'layernames': layers,
                  'linewidth': linewidth}

    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 防焊分析
def solderMaskCheck(job, step, layers, erf, sm_ar, sm_coverage, sm_to_rout, sliver_min, spacing_min, bridge_min,
                    overlap, drill, silver, pads, missing, coverage, spacing, rout, clearance_connection, bridge,
                    apply_to, use_compensated_rout, min_sliver_len, dist2sliver_ratio, apply_range, classify_pad_ar,
                    ranges, max_botteneck_width):
    data = {
        'func': 'SOLDER_MASK_CHECK',
        'paras': [{'job': job},
                  {'step': step},
                  {'layers': layers},
                  {'erf': erf},
                  {'sm_ar': sm_ar},
                  {'sm_coverage': sm_coverage},
                  {'sm_to_rout': sm_to_rout},
                  {'sliver_min': sliver_min},
                  {'spacing_min': spacing_min},
                  {'bridge_min': bridge_min},
                  {'overlap': overlap},
                  {'drill': drill},
                  {'silver': silver},
                  {'pads': pads},
                  {'missing': missing},
                  {'coverage': coverage},
                  {'spacing': spacing},
                  {'rout': rout},
                  {'clearance_connection': clearance_connection},
                  {'bridge': bridge},
                  {'apply_to': apply_to},
                  {'use_compensated_rout': use_compensated_rout},
                  {'min_sliver_len': min_sliver_len},
                  {'dist2sliver_ratio': dist2sliver_ratio},
                  {'apply_range': apply_range},
                  {'classify_pad_ar': classify_pad_ar},
                  {'ranges': ranges},
                  {'max_botteneck_width': max_botteneck_width}]
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(js)

    # selectPolyline
    """
    selectpolygon:[{'ix':0,'iy':0}]
    """


def selectPolyline(job, step, layer, selectpolygon):
    data = {
        'func': 'SELECT_POLYLINE',
        'paras': {'job': job,
                  'step': step,
                  'layer': layer,
                  'selectpolygon': selectpolygon}
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# flattenStep
def flattenStep(job, step, flatten_layer, dst_layer):
    data = {
        'func': 'FLATTEN_STEP',
        'paras': {'job': job,
                  'step': step,
                  'flatten_layer': flatten_layer,
                  'dst_layer': dst_layer}

    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 钻孔信息
def getDrillInfo(jobname, stepname, layername):
    data = {
        'func': 'GET_DRILL_INFO',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'layername': layername
        }
    }

    # js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 清空撤销堆栈
def clearAllOptions(job, step):
    data = {
        'func': 'CLEAR_ALL_OPTIONS',
        'paras': {'job': job,
                  'step': step
                  }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(js)


# identify symbol

def identifySymbol(symbolname):
    data = {
        'func': 'IDENTIFY_SYMBOL',
        'paras': {'content': symbolname
                  }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(js)


def isJobOpen(job):
    data = {
        'func': 'IS_JOB_OPENED',
        'paras': {'jobname': job}
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(js)


def useSolidFillContours(jobname, stepname, layernames, solid_type, min_brush, use_arcs):
    data = {
        "func": "USE_SOLID_FILL_CONTOURS",
        "paras": {
            "jobname": jobname,
            "stepname": stepname,
            "_layernames": layernames,
            "solid_type": solid_type,
            "min_brush": min_brush,
            "use_arcs": use_arcs
        }
    }
    js = json.dumps(data)
    print(js)
    return deepline.process(json.dumps(data))


# 导角
def roundingLineCorner(job, step, layers, radius):
    data = {
        'func': 'ROUNDING_LINE_CORNER',
        'paras': {
            'job': job,
            'step': step,
            'layers': layers,
            'radius': radius
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def getRestCuRate(job, step, layer, resolution_define, thickness,
                  or_and='or', holes_slots=True, include_soldermask=False,
                  mask_layers: list = [], affect_drill_layers: list = [],
                  input_num=0, cu_thickness=0.0, include_edges=False,
                  consider_rout=False, pth_without_pad=False):
    list_params = {
        'mask_layers': mask_layers,
        'affect_drill_layers': affect_drill_layers
    }
    for name, val in list_params.items():
        if not isinstance(val, list):
            raise TypeError(f"参数 '{name}' 必须是 list 类型，当前传入的是: {type(val).__name__}")

    data = {
        'func': 'GET_REST_CU_RATE',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'or_and': or_and,
            'holes_slots': holes_slots,
            'include_soldermask': include_soldermask,
            'mask_layers': mask_layers,
            'affect_drill_layers': affect_drill_layers,
            'resolution_define': resolution_define,
            'thickness': thickness,
            'input_num': input_num,
            'cu_thickness': cu_thickness,
            'include_edges': include_edges,
            'consider_rout': consider_rout,
            'pth_without_pad': pth_without_pad
        }
    }

    # js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 配置config path
def setConfigPath(path):
    data = {
        'func': 'SET_CONFIG_PATH',
        'paras': {
            'path': path
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 获取layer最小线宽线距的信息
def getQuotePriceInfo(job, step, layer):
    data = {
        'func': 'GET_QUOTE_PRICE_INFO',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 制作分孔图
def drillmapOutput(job, step, drilllayer, outlinelayer, outputlayer, unit):
    data = {
        'func': 'DRILLMAP_OUTPUT',
        'paras': {
            'job': job,
            'step': step,
            'drilllayer': drilllayer,
            'outlinelayer': outlinelayer,
            'outputlayer': outputlayer,
            'unit': unit
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 获取job内的usersymbol names
def getSpecialSymbolNames(jobname):
    data = {
        'func': 'GET_SPECIAL_SYMBOL_NAMES',
        'paras': {
            'jobname': jobname
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def layerExport2(job, step, layer, _type, filename):
    data = {
        'func': 'LAYER_EXPORT',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'type': _type,
            'filename': filename
        }
    }
    js = json.dumps(data)
    print(js)
    return deepline.process(json.dumps(data))


# 合并铜与轮廓线
def mergeCuEdgeLines(jobname, stepname, layernames):
    data = {
        'func': 'MERGE_CU_EDGE_LINES',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'layernames': layernames
        }
    }
    return deepline.process(json.dumps(data))


# 输出drill
def drill2File(job, step, layer, path, isMetric, number_format_l=2, number_format_r=4,
               zeroes=2, unit=0, tool_unit=1, x_scale=1.0, y_scale=1.0, x_anchor=0.0, y_anchor=0.0,
               x_origin=0.0, y_origin=0.0, x_offset=0.0, y_offset=0.0, regi_mirror=False,
               regi_rotation_angle=0, break_sr=False, canned_text_mode=0,
               manufacator='', tools_order: list = []):
    if not isinstance(tools_order, list):
        raise TypeError(f"参数 'tools_order' 必须是 list 类型，当前传入的是: {type(tools_order).__name__}")

    data = {
        'func': 'DRILL2FILE',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'path': path,
            'isMetric': isMetric,
            'number_format_l': number_format_l,
            'number_format_r': number_format_r,
            'zeroes': zeroes,
            'unit': unit,
            'tool_unit': tool_unit,
            'x_scale': x_scale,
            'y_scale': y_scale,
            'x_anchor': x_anchor,
            'y_anchor': y_anchor,
            'x_origin': x_origin,
            'y_origin': y_origin,
            'x_offset': x_offset,
            'y_offset': y_offset,
            'regi_mirror': regi_mirror,
            'regi_rotation_angle': regi_rotation_angle,
            'break_sr': break_sr,
            'canned_text_mode': canned_text_mode,
            'manufacator': manufacator,
            'tools_order': tools_order
        }
    }
    return deepline.process(json.dumps(data))


# 分类层中的net
def classifyLayerNet(job, step, layer):
    data = {
        'func': 'CLASSIFY_LAYER_NET',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
        }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 设置钻孔信息
def setDrillInfo(job, step, drllayer, vecDrillTools):
    data = {
        'func': 'SET_DRILL_INFO',
        'paras': {'jobname': job,
                  'stepname': step,
                  'layername': drllayer,
                  'vecDrillTools': vecDrillTools
                  }

    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(js)


def addTextByDrill(jobname, stepname, layername, drill_name, textsize, clear_org_features, toolID_to_text):
    data = {
        'func': 'ADD_TEXT_BY_DRILL',
        'paras': {'jobname': jobname,
                  'stepname': stepname,
                  'layername': layername,
                  'drill_name': drill_name,
                  'textsize': textsize,
                  'clear_org_features': clear_org_features,
                  'toolID_to_text': toolID_to_text
                  }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(js)


#
def createTable(jobname, stepname, layername, clear_org_features, ix, iy, linewidth, rows):
    data = {
        'func': 'CREATE_TABLE',
        'paras': {'jobname': jobname,
                  'stepname': stepname,
                  'layername': layername,
                  'clear_org_features': clear_org_features,
                  'ix': ix,
                  'iy': iy,
                  'linewidth': linewidth,
                  'rows': rows
                  }
    }
    js = json.dumps(data)
    # print(js)
    return deepline.process(js)


# 获取当前层feature数
def getLayerFeatureCount(jobName, stepName, layerName):
    data = {
        'func': 'GET_LAYER_FEATURE_COUNT',
        'paras': {'jobName': jobName,
                  'stepName': stepName,
                  'layerName': layerName}
    }
    return deepline.process(json.dumps(data))


def viaOptimization(job, step, move_stack_via, np2laser, rout2laser, np2via, rout2via, pth2via,
                    pth2laser, via2laser, via2via, laser2laser, consider_net, smd_conpensation,
                    same_netl, same_net_via2laser, same_net_via2via, same_net_laser2laser,
                    vcut2laser, vcut2via, vut_layer,
                    move_sm_via=False, laser_min_ring=0, via_pad_min_ring=0,
                    line_conpensation=0, bga_conpensation=0, other_conpensation=0,
                    include_all=False, drill2signalP=0, drill2signalS=0,
                    via2line=0, laser2line=0, viaAvoidRout=0, laserAvoidRout=0):
    data = {
        'func': 'AUTO_MOVE_DRILL_PAD',
        'paras': {
            'job': job,
            'step': step,
            'moveing_stack_via': move_stack_via,
            'np2laser': np2laser,
            'rout2laser': rout2laser,
            'np2via': np2via,
            'rout2via': rout2via,
            'pth2via': pth2via,
            'pth2laser': pth2laser,
            'via2laser': via2laser,
            'via2via': via2via,
            'laser2laser': laser2laser,
            'consider_net': consider_net,
            'smd_conpensation': smd_conpensation,
            'user_classify_same_net_drill': same_netl,
            'vcut_layername': vut_layer,
            'same_net_via2laser': same_net_via2laser,
            'same_net_via2via': same_net_via2via,
            'same_net_laser2laser': same_net_laser2laser,
            'vcut2laser': vcut2laser,
            'vcut2via': vcut2via,
            'move_sm_via': move_sm_via,
            'laser_min_ring': laser_min_ring,
            'via_pad_min_ring': via_pad_min_ring,
            'line_conpensation': line_conpensation,
            'bga_conpensation': bga_conpensation,
            'other_conpensation': other_conpensation,
            'include_all': include_all,
            'drill2signalP': drill2signalP,
            'drill2signalS': drill2signalS,
            'via2line': via2line,
            'laser2line': laser2line,
            'viaAvoidRout': viaAvoidRout,
            'laserAvoidRout': laserAvoidRout
        }
    }

    # js = json.dumps(data)
    # print(js)
    return deepline.process(json.dumps(data))


# 配置sys attr path
def setSysAttrPath(path):
    data = {
        'func': 'LOAD_SYSATTR',
        'paras': {
            'path': path
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 配置user attr path
def setUserAttrPath(path):
    data = {
        'func': 'LOAD_USERATTR',
        'paras': {
            'path': path
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def getOpenedJobs():
    data = {
        'func': 'GET_OPENED_JOBS'
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def copyJob(src_job, dst_job):
    data = {
        'func': 'COPY_JOB',
        'paras': {
            'src_job': src_job,
            'dst_job': dst_job
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# pad2line
def pad2line(job, step, layers):
    data = {
        'func': 'RESHAPE_PAD_TO_LINE',
        'paras': {
            'job': job,
            'step': step,
            'layers': layers
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def showLayer(job, step, layer):
    data = {
        'cmd': 'showLayer',
        'job': job,
        'step': step,
        'layer': layer
    }
    js = json.dumps(data)
    # print(js)
    return deepline.viewCmd(js)


def showMatrix(job):
    data = {
        'cmd': 'showMatrix',
        'job': job
    }
    js = json.dumps(data)
    # print(js)
    return deepline.viewCmd(js)


def hasProfile(job, step):
    data = {
        'func': 'HAS_PROFILE',
        'paras': {
            'job': job,
            'step': step
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


# 9.21新增
def getSystemAttrDefines():
    data = {
        'func': 'GET_SYSTEM_ATTR_DEFINES',
        'paras': {

        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def getUserAttrDefines():
    data = {
        'func': 'GET_USER_ATTR_DEFINES',
        'paras': {

        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def Dec2Bin(dec):
    temp = []
    result = []
    while dec:
        quo = dec % 2  # 取余数
        dec = dec // 2  # 商数
        temp.append(quo)
    while temp:
        result.append(temp.pop())
    return result


# 输出rout
def rout2File(job, step, layer, path, number_format_l=2, number_format_r=4, manufacator={},
              zeroes=2, unit=0, tool_unit=1, x_scale=1, y_scale=1, x_anchor=0, y_anchor=0, partial_order=0,
              num_in_x=0, num_in_y=0, order_type=0, serial_no=0, break_arcs=False, break_sr=False):
    data = {
        'func': 'ROUT2FILE',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'path': path,
            'number_format_l': number_format_l,
            'number_format_r': number_format_r,
            'zeroes': zeroes,
            'unit': unit,
            'tool_unit': tool_unit,
            'x_scale': x_scale,
            'y_scale': y_scale,
            'x_anchor': x_anchor,
            'y_anchor': y_anchor,
            'partial_order': partial_order,
            'num_in_x': num_in_x,
            'num_in_y': num_in_y,
            'order_type': order_type,
            'serial_no': serial_no,
            'break_arcs': break_arcs,
            'manufacator': manufacator,
            'break_sr': break_sr
        }
    }
    return deepline.process(json.dumps(data))


# 20221115
# dxf数据保存至文件


def dxf2File(job, step, layers: list, path):
    """
    savePath为全路径
    """
    if not isinstance(layers, list):
        raise TypeError(f"参数 'layers' 必须是 list 类型，当前传入的是: {type(layers).__name__}")

    data = {
        "func": "DXF2FILE",
        "paras": {
            "job": job,
            "step": step,
            "layers": layers,
            "path": path
        }
    }
    return deepline.process(json.dumps(data))


# MI 20221115
# 保存钻带数据
def saveDrillBelts(job, step, infoList, copperLayerNum):
    """
    info中单个obj参数样例
    {
        "drillBeltIndex": 1,
        "drillBeltType": 2,
        "drillLayerName": "drl1-8",
        "drillNumber": 1387,
        "endLayer": 8,
        "startLayer": 1
    }
    """
    data = {
        "func": "SAVE_DRILL_BELTS",
        "paras": {
            "job": job,
            "drillbelts": {
                "copperLayerNum": copperLayerNum,
                "info": infoList,
                "stepName": step
            }
        }
    }
    return deepline.process(json.dumps(data))


# 获取已开料的钻带数据
def getDrillBelts(job):
    data = {
        "func": "GET_DRILL_BELTS",
        "paras": {
            "job": job
        }
    }
    return deepline.process(json.dumps(data))


# 增加一条钻带数据
def addDrillBelt(job, drillLayerName, startLayer, endLayer, drillBeltType, drillNumber):
    data = {
        "func": "ADD_DRILL_BELT",
        "paras": {
            "job": job,
            "params": {
                "drillBeltType": drillBeltType,
                "drillLayerName": drillLayerName,
                "drillNumber": drillNumber,
                "endLayer": endLayer,
                "startLayer": startLayer
            }
        }
    }
    return deepline.process(json.dumps(data))


# 删除一条钻带数据
def deleteDrillBelt(job, index):
    data = {
        "func": "DELETE_DRILL_BELT",
        "paras": {
            "job": job,
            "index": index
        }
    }
    return deepline.process(json.dumps(data))


# 修改一条钻带数据
def updateDrillBelt(job, index, updateDrillBeltPara):
    """
    params参数样例，参数可不全给
    {
        "drillBeltIndex": 1,
        "drillBeltType": 2,
        "drillLayerName": "drl1-8",
        "drillNumber": 1387,
        "endLayer": 8,
        "startLayer": 1
    }
    """
    data = {
        "func": "UPDATE_DRILL_BELT",
        "paras": {
            "job": job,
            "index": index,
            "params": updateDrillBeltPara
        }
    }
    return deepline.process(json.dumps(data))


# 清空该资料中钻带数据
def clearDrillBelts(job):
    data = {
        "func": "CLEAR_DRILL_BELTS",
        "paras": {
            "job": job
        }
    }
    return deepline.process(json.dumps(data))


# 根据已导入的cam资料的孔层信息自动化生成钻带信息
def autoDrillBelts(job, step):
    data = {
        "func": "AUTO_DRILL_BELTS",
        "paras": {
            "job": job,
            "step": step
        }
    }
    return deepline.process(json.dumps(data))


# 根据资料钻带索引的一条指定钻带,获取cam资料中对应的孔层名
def getLinkedCamLayer(job, index):
    data = {
        "func": "GET_LINCKED_CAM_LAYER",
        "paras": {
            "job": job,
            "index": index
        }
    }
    return deepline.process(json.dumps(data))


# 保存叠构数据
def saveStackup(job, stackupInfo):
    """
    stackupSample = {
        "StackUpSegment": [
            {
                "layername": "",
                "materialConductivity": 0.0,
                "materialDielectric": 0.0,
                "materialLossTangent": 0.0,
                "materialName": "",
                "materialThkTolMinus": 0.0,
                "materialThkTolPlus": 0.0,
                "segmentThk": 0.0,
                "segmentType": "COPPER"
            }
        ],
        "symmetryStatus": True,
        "totalThk": 0.0
    }
    """
    data = {
        "func": "SAVE_STACKUP",
        "paras": {
            "job": job,
            "stackup": stackupInfo
        }
    }
    return deepline.process(json.dumps(data))


# 获取资料叠构数据
def getStackup(job):
    data = {
        "func": "GET_STACKUP",
        "paras": {
            "job": job
        }
    }
    return deepline.process(json.dumps(data))


# 清空资料中叠构数据
def clearStackup(job):
    data = {
        "func": "CLEAR_STACKUP",
        "paras": {
            "job": job
        }
    }
    return deepline.process(json.dumps(data))


# 根据已导入的cam资料的钻带信息自动化生成叠构信息
def autoStackup(job, step="", type=0):
    data = {
        "func": "AUTO_STACKUP",
        "paras": {
            "job": job
        }
    }
    return deepline.process(json.dumps(data))


# 在资料的叠构信息中增加一层叠构信息
def addStackupSegment(job, index, stackupParams):
    """
    {
        "layername": "l1",
        "materialName": "test",
        "segmentType": "PREPREG",
        "layerfunction": 1.1,
        "materialConductivity": 1.1,
        "conductivity_unit": 1.1,
        "materialDielectric": 1.1,
        "materialLossTangent": 1.1,
        "segmentThk": 1.1,
        "materialThkTolPlus": 1.1,
        "materialThkTolMinus": 1.1
    }
    """
    data = {
        "func": "ADD_STACKUP_SEGMENT",
        "paras": {
            "job": job,
            "index": index,
            "params": stackupParams
        }
    }
    return deepline.process(json.dumps(data))


# 删除叠构信息中某层叠构信息
def deleteStackupSegment(job, index):
    data = {
        "func": "DELETE_STACKUP_SEGMENT",
        "paras": {
            "job": job,
            "index": index
        }
    }
    return deepline.process(json.dumps(data))


# 修改叠构信息中某层叠构信息
def updateStackupSegment(job, index, updateParams):
    """
    {
        "layername": "l1",
        "materialName": "test",
        "segmentType": "PREPREG",
        "layerfunction": 1.1,
        "materialConductivity": 1.1,
        "conductivity_unit": 1.1,
        "materialDielectric": 1.1,
        "materialLossTangent": 1.1,
        "segmentThk": 1.1,
        "materialThkTolPlus": 1.1,
        "materialThkTolMinus": 1.1
    }
    """
    data = {
        "func": "UPDATE_STACKUP_SEGMENT",
        "paras": {
            "job": job,
            "index": index,
            "params": updateParams
        }
    }
    return deepline.process(json.dumps(data))


# 获取指定孔层下所有详情
def autoGetDrillInfo(job, step, layer):
    data = {
        "func": "AUTO_GET_DRILL_INFO",
        "paras": {
            "job": job,
            "step": step,
            "layer": layer
        }
    }
    return deepline.process(json.dumps(data))


# 20221129
def outputPdf(job, step, layers, layercolors, outputpath, pdfname, overlap):
    data = {
        "func": "OUTPUT_PDF",
        "paras": {
            "job": job,
            "step": step,
            "layers": layers,
            "layercolors": layercolors,
            "outputpath": outputpath,
            "pdfname": pdfname,
            "overlap": overlap
        }
    }
    return deepline.process(json.dumps(data))


def savePng(job, step, layers, xmin, ymin, xmax, ymax, picpath, picname, backcolor, layercolors):
    data = {
        "func": "OUTPUT_FIXED_PICTURE",
        "paras": {
            "job": job,
            "step": step,
            "layers": layers,
            "xmin": xmin,
            "ymin": ymin,
            "xmax": xmax,
            "ymax": ymax,
            "picpath": picpath,
            "picname": picname,
            "backcolor": backcolor,
            "layercolors": layercolors
        }
    }
    return deepline.process(json.dumps(data))


def getVersion():
    return deepline.getVersion()


def generateRoutLayer(job, step, sourceLayer, destinationLayer, mode):
    data = {
        "func": "GENERATE_ROUT_LAYER",
        "paras": {
            "job": job,
            "step": step,
            "sourceLayer": sourceLayer,
            "destinationLayer": destinationLayer,
            "mode": mode
        }
    }
    return deepline.process(json.dumps(data))


# 绕pointx,pointy顺时针旋转
def sRotate(angle: int, valuex: int, valuey: int, pointx: int, pointy: int):
    if angle % 180 != 0:
        sin = math.sin(math.radians(angle))
        cos = math.sqrt(1 - sin ** 2)
    else:
        cos = math.cos(math.radians(angle))
        sin = math.sqrt(1 - cos ** 2)
    sRotatex = (valuex - pointx) * cos + (valuey - pointy) * sin + pointx
    sRotatey = (valuey - pointy) * cos - (valuex - pointx) * sin + pointy
    return sRotatex, sRotatey


# 坐标平移
def move(x: int, y: int, delta_x: int, delta_y: int):
    end_x = delta_x + x
    end_y = delta_y + y
    return (end_x, end_y)


# 水平镜像
def mirrorY(point_x: int, point_y: int, datum_x: int):
    dx = point_x - datum_x
    if dx > 0:
        end_x = datum_x - dx
    elif dx < 0:
        end_x = datum_x - dx
    elif dx == 0:
        end_x = datum_x
    return (end_x, point_y)


# 坐标缩放(sx、sy为缩放系数0-1表示缩小，大于1表示扩大)(px、py为基准点坐标)
def scale(x: float, y: float, sx: float, sy: float, px: float, py: float):
    # x = inch2nm(x)
    # y = inch2nm(y)
    end_x = x * sx + px * (1 - sx)
    end_y = y * sy + py * (1 - sy)
    # end_x = nm2inch(end_x)
    # end_y = nm2inch(end_y)
    return (end_x, end_y)


def nm2mm(num: float):
    count = num / 1000000
    return count


def nm2inch(num: float):
    count = num / 25400000
    return count


def inch2mm(num: float):
    count = num * 25.4
    return count


def inch2nm(num: float):
    count = num * 25400000
    return count


# 数据转换
def dataProcessing(number: float, number_format_l: int, number_format_r: int, zeroes: int):
    number = round(number, number_format_r)
    d1 = str(number).split(".")[0]
    if d1[0] == '-':
        b = len(d1) - 1
        if b != number_format_l:
            d1 = d1.strip('-')
            d1 = d1.zfill(number_format_l)
            d1 = '-' + d1
    else:
        b = len(d1)
        if zeroes == 1:
            d1 = d1
        else:
            if b != number_format_l:
                d1 = d1.zfill(number_format_l)
    if d1 == '0':
        d1 = ''
    d2 = str(number).split(".")[1]
    c = len(d2)
    if zeroes == 0:
        pass
    else:
        if c < number_format_r:
            d2 = d2.ljust(number_format_r, '0')
    return (d1, d2)


# 槽孔数据
def slotLenth(location: dict, unit: bool, angle: float, mirror: bool, number_format_l: int, number_format_r: int,
              zeroes: int, pointx: float, pointy: float, delta_x: float, delta_y: float, x_scale: float,
              y_scale: float):
    xs = location['X1']
    xe = location['X2']
    ys = location['Y1']
    ye = location['Y2']
    if unit is False:
        xs = nm2mm(xs)
        ys = nm2mm(ys)
        xe = nm2mm(xe)
        ye = nm2mm(ye)
    elif unit is True:
        xs = nm2inch(xs)
        ys = nm2inch(ys)
        xe = nm2inch(xe)
        ye = nm2inch(ye)
    if angle != 0:
        xs, ys = sRotate(angle, xs, ys, pointx, pointy)
        xe, ye = sRotate(angle, xe, ye, pointx, pointy)
        xs = round(xs, number_format_r)
        ys = round(ys, number_format_r)
        xe = round(xe, number_format_r)
        ye = round(ye, number_format_r)
    if mirror is True:
        xs, ys = mirrorY(xs, ys, xs)
        xe, ye = mirrorY(xe, ye, xs)  # 根据实际情况修改
    if delta_x != 0 or delta_y != 0:
        xs, ys = move(xs, ys, delta_x, delta_y)
        xe, ye = move(xe, ye, delta_x, delta_y)
    if x_scale != 1 or y_scale != 1:
        xs, ys = scale(xs, ys, x_scale, y_scale, pointx, pointy)
        xe, ye = scale(xe, ye, x_scale, y_scale, pointx, pointy)
    xs = dataProcessing(xs, number_format_l, number_format_r, zeroes)
    ys = dataProcessing(ys, number_format_l, number_format_r, zeroes)
    xe = dataProcessing(xe, number_format_l, number_format_r, zeroes)
    ye = dataProcessing(ye, number_format_l, number_format_r, zeroes)
    xs = 'X' + xs[0] + xs[1]
    ys = 'Y' + ys[0] + ys[1]
    xe = 'X' + xe[0] + xe[1]
    ye = 'Y' + ye[0] + ye[1]
    digital = xs + ys + 'G85' + xe + ye
    return digital


# 圆孔
def isPad(location: dict, unit: bool, angle: float, mirror: bool, number_format_l: int, number_format_r: int,
          zeroes: int, pointx: float, pointy: float, delta_x: float, delta_y: float, x_scale: float, y_scale: float):
    x, y = location['X'], location['Y']
    if unit is True:
        x = nm2inch(x)
        y = nm2inch(y)
    else:
        x = nm2mm(x)
        y = nm2mm(y)
    if angle != 0:
        x, y = sRotate(angle, x, y, pointx, pointy)
        x = round(x, number_format_r)
        y = round(y, number_format_r)
    if mirror is True:
        x, y = mirrorY(x, y, x)  # 根据实际情况修改
    if delta_x != 0 or delta_y != 0:
        x, y = move(x, y, delta_x, delta_y)
    if x_scale != 1 or y_scale != 1:
        x, y = scale(x, y, x_scale, y_scale, pointx, pointy)
    x = dataProcessing(x, number_format_l, number_format_r, zeroes)
    y = dataProcessing(y, number_format_l, number_format_r, zeroes)
    x = 'X' + x[0] + x[1]
    y = 'Y' + y[0] + y[1]
    xy = x + y
    return xy


# arc2line
def arc2lines(job, step, layers, radius, sel_type):
    data = {
        'func': 'ARC2LINES',
        'paras': [
            {'job': job},
            {'step': step},
            {'layers': layers},
            {'radius': radius},
            {'sel_type': sel_type}
        ]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def saveSvg(jobName, stepName, layerNamesInfo, savePath, scale):
    data = {
        'func': 'EXPORT_SVG',
        'paras': {'jobName': jobName,
                  'stepName': stepName,
                  'layerNamesInfo': layerNamesInfo,
                  'savePath': savePath,
                  'scale': scale
                  }
    }
    ret = deepline.process(json.dumps(data))
    return ret


def getAllFeatureInfo(job, step, layer, featuretype=127):
    data = {
        'func': 'GET_ALL_FEATURE_INFO',
        'paras': {'job': job,
                  'step': step,
                  'layer': layer,
                  'featureType': featuretype
                  }
    }
    return deepline.process(json.dumps(data))


def getUserSymbolBox(job, userSymbolName):
    data = {
        'func': 'GET_USER_SYMBOL_BOX',
        'paras': {'job': job,
                  'userSymbolName': userSymbolName
                  }
    }
    return deepline.process(json.dumps(data))


# extendSlots
def changesize00(angle, size, sin, cos):
    changesize = {}
    if angle != 0 and angle != 90:
        xlen = size / 2 * cos
        ylen = size / 2 * sin
    else:
        xlen = size / 2
        ylen = size / 2
    changesize['xlen'] = xlen
    changesize['ylen'] = ylen
    return changesize


def changesize01(angle, size, sin, cos):
    changesize = {}
    if angle != 0 and angle != 90:
        xlen = size * cos
        ylen = size * sin
    else:
        xlen = size
        ylen = size
    changesize['xlen'] = xlen
    changesize['ylen'] = ylen
    return changesize


def changesize10(xs, xe, ys, ye, angle, size, sin, cos):
    changesize = {}
    height = abs(ye - ys) * 25400000
    width = abs(xe - xs) * 25400000
    if angle != 0 and angle != 90:
        lenorg = height / sin
    elif angle == 0:
        lenorg = width
    elif angle == 90:
        lenorg = height
    if angle != 0 and angle != 90:
        xlen = (size - lenorg) / 2 * cos
        ylen = (size - lenorg) / 2 * sin
    else:
        xlen = (size - lenorg) / 2
        ylen = (size - lenorg) / 2
    changesize['xlen'] = xlen
    changesize['ylen'] = ylen
    return changesize


def changesize11(xs, xe, ys, ye, angle, size, sin, cos):
    changesize = {}
    height = abs(ye - ys) * 25400000
    width = abs(xe - xs) * 25400000
    if angle != 0 and angle != 90:
        lenorg = height / sin
    elif angle == 0:
        lenorg = width
    elif angle == 90:
        lenorg = height
    if angle != 0 and angle != 90:
        xlen = (size - lenorg) * cos
        ylen = (size - lenorg) * sin
    else:
        xlen = size - lenorg
        ylen = size - lenorg
    changesize['xlen'] = xlen
    changesize['ylen'] = ylen
    return changesize


def lineMode00(xlen, ylen, info):
    location = {}
    xs = info[0]['XS']
    xe = info[0]['XE']
    ys = info[0]['YS']
    ye = info[0]['YE']
    polarity = info[0]['polarity']
    if polarity == 'POS':
        pol = True
    else:
        pol = False
    if xs < xe and ys < ye:
        xsnew = xs * 25400000 - xlen
        ysnew = ys * 25400000 - ylen
        xenew = xe * 25400000 + xlen
        yenew = ye * 25400000 + ylen
    elif xs < xe and ys > ye:
        xsnew = xs * 25400000 - xlen
        ysnew = ys * 25400000 + ylen
        xenew = xe * 25400000 + xlen
        yenew = ye * 25400000 - ylen
    elif xs > xe and ys < ye:
        xsnew = xs * 25400000 + xlen
        ysnew = ys * 25400000 - ylen
        xenew = xe * 25400000 - xlen
        yenew = ye * 25400000 + ylen
    elif xs > xe and ys > ye:
        xsnew = xs * 25400000 + xlen
        ysnew = ys * 25400000 + ylen
        xenew = xe * 25400000 - xlen
        yenew = ye * 25400000 - ylen
    elif xs == xe and ys < ye:
        xsnew = xs * 25400000
        ysnew = ys * 25400000 - ylen
        xenew = xe * 25400000
        yenew = ye * 25400000 + ylen
    elif xs == xe and ys > ye:
        xsnew = xs * 25400000
        ysnew = ys * 25400000 + ylen
        xenew = xe * 25400000
        yenew = ye * 25400000 - ylen
    elif xs < xe and ys == ye:
        xsnew = xs * 25400000 - xlen
        ysnew = ys * 25400000
        xenew = xe * 25400000 + xlen
        yenew = ye * 25400000
    elif xs > xe and ys == ye:
        xsnew = xs * 25400000 + xlen
        ysnew = ys * 25400000
        xenew = xe * 25400000 - xlen
        yenew = ye * 25400000
    location['xsnew'] = xsnew
    location['ysnew'] = ysnew
    location['xenew'] = xenew
    location['yenew'] = yenew
    location['pol'] = pol
    return location


def lineMode01(xlen, ylen, info):
    location = {}
    xs = info[0]['XS']
    xe = info[0]['XE']
    ys = info[0]['YS']
    ye = info[0]['YE']
    angle = abs(info[0]['angle'])
    symbol = info[0]['symbolname']
    polarity = info[0]['polarity']
    if polarity == 'POS':
        pol = True
    else:
        pol = False
    att = info[0]['attributes']
    xx = operator.le(xs, xe)
    yy = operator.le(ys, ye)
    if xx is True and yy is True and angle != 90 and angle != 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 + xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000 + ylen
    elif xx is True and yy is False and angle != 90 and angle != 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 + xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000 - ylen
    elif xx is False and yy is True and angle != 90 and angle != 0:
        xsnew = xs * 25400000 + xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000 - ylen
        yenew = ye * 25400000
    elif xx is False and yy is False and angle != 90 and angle != 0:
        xsnew = xs * 25400000 + xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000 + ylen
        yenew = ye * 25400000
    elif xx is True and angle == 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 + xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000
    elif xx is False and angle == 0:
        xsnew = xs * 25400000 + xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000
        yenew = ye * 25400000
    elif yy is True and angle == 90:
        xsnew = xs * 25400000
        xenew = xe * 25400000
        ysnew = ys * 25400000
        yenew = ye * 25400000 + ylen
    elif yy is False and angle == 90:
        xsnew = xs * 25400000
        xenew = xe * 25400000
        ysnew = ys * 25400000 + ylen
        yenew = ye * 25400000
    location['xsnew'] = xsnew
    location['ysnew'] = ysnew
    location['xenew'] = xenew
    location['yenew'] = yenew
    location['symbol'] = symbol
    location['pol'] = pol
    location['att'] = att
    return location


def lineMode02(xlen, ylen, info):
    location = {}
    xs = info[0]['XS']
    xe = info[0]['XE']
    ys = info[0]['YS']
    ye = info[0]['YE']
    angle = abs(info[0]['angle'])
    symbol = info[0]['symbolname']
    polarity = info[0]['polarity']
    if polarity == 'POS':
        pol = True
    else:
        pol = False
    att = info[0]['attributes']
    xx = operator.le(xs, xe)
    yy = operator.le(ys, ye)
    if xx is True and yy is True and angle != 90 and angle != 0:
        xsnew = xs * 25400000 - xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000 - ylen
        yenew = ye * 25400000
    elif xx is True and yy is False and angle != 90 and angle != 0:
        xsnew = xs * 25400000 - xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000 + ylen
        yenew = ye * 25400000
    elif xx is False and yy is True and angle != 90 and angle != 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 - xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000 + ylen
    elif xx is False and yy is False and angle != 90 and angle != 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 - xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000 - ylen
    elif xx is True and angle == 0:
        xsnew = xs * 25400000 - xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000
        yenew = ye * 25400000
    elif xx is False and angle == 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 - xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000
    elif yy is True and angle == 90:
        xsnew = xs * 25400000
        xenew = xe * 25400000
        ysnew = ys * 25400000 - ylen
        yenew = ye * 25400000
    elif yy is False and angle == 90:
        xsnew = xs * 25400000
        xenew = xe * 25400000
        ysnew = ys * 25400000
        yenew = ye * 25400000 - ylen
    location['xsnew'] = xsnew
    location['ysnew'] = ysnew
    location['xenew'] = xenew
    location['yenew'] = yenew
    location['symbol'] = symbol
    location['pol'] = pol
    location['att'] = att
    return location


def lineMode03(xlen, ylen, info):
    location = {}
    xs = info[0]['XS']
    xe = info[0]['XE']
    ys = info[0]['YS']
    ye = info[0]['YE']
    angle = abs(info[0]['angle'])
    symbol = info[0]['symbolname']
    polarity = info[0]['polarity']
    if polarity == 'POS':
        pol = True
    else:
        pol = False
    att = info[0]['attributes']

    xx = operator.le(xs, xe)
    yy = operator.le(ys, ye)
    if xx is True and yy is True and angle != 90 and angle != 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 + xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000 + ylen
    elif xx is True and yy is False and angle != 90 and angle != 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 + xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000 - ylen
    elif xx is False and yy is True and angle != 90 and angle != 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 - xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000 + ylen
    elif xx is False and yy is False and angle != 90 and angle != 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 - xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000 - ylen
    elif xx is True and angle == 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 + xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000
    elif xx is False and angle == 0:
        xsnew = xs * 25400000
        xenew = xe * 25400000 - xlen
        ysnew = ys * 25400000
        yenew = ye * 25400000
    elif yy is True and angle == 90:
        xsnew = xs * 25400000
        xenew = xe * 25400000
        ysnew = ys * 25400000
        yenew = ye * 25400000 + ylen
    elif yy is False and angle == 90:
        xsnew = xs * 25400000
        xenew = xe * 25400000
        ysnew = ys * 25400000
        yenew = ye * 25400000 - ylen
    location['xsnew'] = xsnew
    location['ysnew'] = ysnew
    location['xenew'] = xenew
    location['yenew'] = yenew
    location['symbol'] = symbol
    location['pol'] = pol
    location['att'] = att
    return location


def lineMode04(xlen, ylen, info):
    location = {}
    xs = info[0]['XS']
    xe = info[0]['XE']
    ys = info[0]['YS']
    ye = info[0]['YE']
    angle = abs(info[0]['angle'])
    symbol = info[0]['symbolname']
    polarity = info[0]['polarity']
    if polarity == 'POS':
        pol = True
    else:
        pol = False
    att = info[0]['attributes']
    xx = operator.le(xs, xe)
    yy = operator.le(ys, ye)
    if xx is True and yy is True and angle != 90 and angle != 0:
        xsnew = xs * 25400000 - xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000 - ylen
        yenew = ye * 25400000
    elif xx is True and yy is False and angle != 90 and angle != 0:
        xsnew = xs * 25400000 - xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000 + ylen
        yenew = ye * 25400000
    elif xx is False and yy is True and angle != 90 and angle != 0:
        xsnew = xs * 25400000 + xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000 - ylen
        yenew = ye * 25400000
    elif xx is False and yy is False and angle != 90 and angle != 0:
        xsnew = xs * 25400000 + xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000 + ylen
        yenew = ye * 25400000
    elif xx is True and angle == 0:
        xsnew = xs * 25400000 - xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000
        yenew = ye * 25400000
    elif xx is False and angle == 0:
        xsnew = xs * 25400000 + xlen
        xenew = xe * 25400000
        ysnew = ys * 25400000
        yenew = ye * 25400000
    elif yy is True and angle == 90:
        xsnew = xs * 25400000
        xenew = xe * 25400000
        ysnew = ys * 25400000 - ylen
        yenew = ye * 25400000
    elif yy is False and angle == 90:
        xsnew = xs * 25400000
        xenew = xe * 25400000
        ysnew = ys * 25400000 + ylen
        yenew = ye * 25400000
    location['xsnew'] = xsnew
    location['ysnew'] = ysnew
    location['xenew'] = xenew
    location['yenew'] = yenew
    location['symbol'] = symbol
    location['pol'] = pol
    location['att'] = att
    return location


def lineMode10(xlen, ylen, info):
    location = {}
    polarity = info[0]['polarity']
    if polarity == 'POS':
        pol = True
    else:
        pol = False
    new = lineMode00(xlen, ylen, info)
    location['xsnew'] = new['xsnew']
    location['ysnew'] = new['ysnew']
    location['xenew'] = new['xenew']
    location['yenew'] = new['yenew']
    location['pol'] = pol
    return location


def lineMode11(xlen, ylen, info):
    location = {}
    polarity = info[0]['polarity']
    if polarity == 'POS':
        pol = True
    else:
        pol = False
    new = lineMode01(xlen, ylen, info)
    location['xsnew'] = new['xsnew']
    location['ysnew'] = new['ysnew']
    location['xenew'] = new['xenew']
    location['yenew'] = new['yenew']
    location['pol'] = pol
    return location


def lineMode12(xlen, ylen, info):
    location = {}
    polarity = info[0]['polarity']
    if polarity == 'POS':
        pol = True
    else:
        pol = False
    new = lineMode02(xlen, ylen, info)
    location['xsnew'] = new['xsnew']
    location['ysnew'] = new['ysnew']
    location['xenew'] = new['xenew']
    location['yenew'] = new['yenew']
    location['pol'] = pol
    return location


def lineMode13(xlen, ylen, info):
    location = {}
    polarity = info[0]['polarity']
    if polarity == 'POS':
        pol = True
    else:
        pol = False
    new = lineMode03(xlen, ylen, info)
    location['xsnew'] = new['xsnew']
    location['ysnew'] = new['ysnew']
    location['xenew'] = new['xenew']
    location['yenew'] = new['yenew']
    location['pol'] = pol
    return location


def lineMode14(xlen, ylen, info):
    location = {}
    polarity = info[0]['polarity']
    if polarity == 'POS':
        pol = True
    else:
        pol = False
    new = lineMode04(xlen, ylen, info)
    location['xsnew'] = new['xsnew']
    location['ysnew'] = new['ysnew']
    location['xenew'] = new['xenew']
    location['yenew'] = new['yenew']
    location['pol'] = pol
    return location


def changeDatum00(locationx, locationy):
    location = {}
    location['x'] = locationx
    location['y'] = locationy
    return location


def changeDatum01(xsize, ysize, size, sin, cos, locationx, locationy, sepcial_angle, vertical_angle, angle, mirror):
    location = {}
    if 0 < angle < 90 or 180 < angle < 270:
        aa = True
    elif 90 < angle < 180 or 270 < angle < 360:
        aa = False
    if sepcial_angle is True and vertical_angle is False:
        location['x'] = locationx + size / 2
        location['y'] = locationy
    elif sepcial_angle is True:
        location['x'] = locationx
        location['y'] = locationy + size / 2
    # elif xsize>ysize and sepcial_angle ==True and vertical_angle==False:
    #     location['x']=locationx+size/2
    #     location['y']=locationy
    # elif xsize>ysize and vertical_angle==True:
    #     location['x']=locationx
    #     location['y']=locationy+size/2
    elif xsize < ysize and mirror is False and aa is True:
        location['x'] = locationx + size / 2 * cos
        location['y'] = locationy + size / 2 * sin
    elif xsize < ysize and mirror is True and aa is True:
        location['x'] = locationx + size / 2 * cos
        location['y'] = locationy - size / 2 * sin
    elif xsize < ysize and mirror is False and aa is False:
        location['x'] = locationx + size / 2 * cos
        location['y'] = locationy - size / 2 * sin
    elif xsize < ysize and mirror is True and aa is False:
        location['x'] = locationx + size / 2 * cos
        location['y'] = locationy + size / 2 * sin
    elif xsize > ysize and mirror is False and aa is True:
        location['x'] = locationx + size / 2 * cos
        location['y'] = locationy - size / 2 * sin
    elif xsize > ysize and mirror is True and aa is True:
        location['x'] = locationx + size / 2 * cos
        location['y'] = locationy + size / 2 * sin
    elif xsize > ysize and mirror is False and aa is False:
        location['x'] = locationx + size / 2 * cos
        location['y'] = locationy + size * sin
    elif xsize > ysize and mirror is True and aa is False:
        location['x'] = locationx + size / 2 * cos
        location['y'] = locationy - size / 2 * sin
    return location


def changeDatum02(xsize, ysize, size, sin, cos, locationx, locationy, sepcial_angle, vertical_angle, angle, mirror):
    location = {}
    if 0 < angle < 90 or 180 < angle < 270:
        aa = True
    elif 90 < angle < 180 or 270 < angle < 360:
        aa = False
    if xsize < ysize and sepcial_angle is True and vertical_angle is False:
        location['x'] = locationx - size / 2
        location['y'] = locationy
    elif xsize < ysize and sepcial_angle is True:
        location['x'] = locationx
        location['y'] = locationy - size / 2
    elif xsize > ysize and sepcial_angle is True and vertical_angle is False:
        location['x'] = locationx - size / 2
        location['y'] = locationy
    elif xsize > ysize and vertical_angle is True:
        location['x'] = locationx
        location['y'] = locationy - size / 2
    elif mirror is False and aa is True:
        location['x'] = locationx - size / 2 * cos
        location['y'] = locationy - size / 2 * sin
    elif mirror is True and aa is True:
        location['x'] = locationx - size / 2 * cos
        location['y'] = locationy + size / 2 * sin
    elif mirror is False and aa is False:
        location['x'] = locationx - size / 2 * cos
        location['y'] = locationy + size / 2 * sin
    elif mirror is True and aa is False:
        location['x'] = locationx - size / 2 * cos
        location['y'] = locationy - size / 2 * sin
    return location


def changeDatum03(xsize, ysize, size, sin, cos, locationx, locationy, angle, mirror, datum):
    location = {}
    if datum == 3:
        i = 1
    elif datum == 4:
        i = -1
    if angle == 0 or angle == 360:
        angle = 0
    if xsize < ysize:
        if angle == 0:
            location['x'] = locationx
            location['y'] = locationy + size / 2 * i
        elif angle == 180:
            location['x'] = locationx
            location['y'] = locationy - size / 2 * i
        elif angle == 90:
            location['x'] = locationx + size / 2 * i
            location['y'] = locationy
        elif angle == 270:
            location['x'] = locationx - size / 2 * i
            location['y'] = locationy
        elif 0 < angle < 90 and mirror is False:
            location['x'] = locationx + size / 2 * cos * i
            location['y'] = locationy + size / 2 * sin * i
        elif 0 < angle < 90 and mirror is True:
            location['x'] = locationx - size / 2 * cos * i
            location['y'] = locationy + size / 2 * sin * i
        elif 90 < angle < 180 and mirror is False:
            location['x'] = locationx + size / 2 * cos * i
            location['y'] = locationy - size / 2 * sin * i
        elif 90 < angle < 180 and mirror is True:
            location['x'] = locationx - size / 2 * cos * i
            location['y'] = locationy - size / 2 * sin * i
        elif 180 < angle < 270 and mirror is False:
            location['x'] = locationx - size / 2 * cos * i
            location['y'] = locationy - size / 2 * sin * i
        elif 180 < angle < 270 and mirror is True:
            location['x'] = locationx + size / 2 * cos * i
            location['y'] = locationy - size / 2 * sin * i
        elif 270 < angle < 360 and mirror is False:
            location['x'] = locationx - size / 2 * cos * i
            location['y'] = locationy + size / 2 * sin * i
        elif 270 < angle < 360 and mirror is True:
            location['x'] = locationx + size / 2 * cos * i
            location['y'] = locationy + size / 2 * sin * i
    elif xsize > ysize:
        if angle == 0:
            location['x'] = locationx + size / 2 * i
            location['y'] = locationy
        elif angle == 180:
            location['x'] = locationx - size / 2 * i
            location['y'] = locationy
        elif angle == 90:
            location['x'] = locationx
            location['y'] = locationy - size / 2 * i
        elif angle == 270:
            location['x'] = locationx
            location['y'] = locationy + size / 2 * i
        elif 0 < angle < 90 and mirror is False:
            location['x'] = locationx + size / 2 * cos * i
            location['y'] = locationy - size / 2 * sin * i
        elif 0 < angle < 90 and mirror is True:
            location['x'] = locationx + size / 2 * cos * i
            location['y'] = locationy + size / 2 * sin * i
        elif 90 < angle < 180 and mirror is False:
            location['x'] = locationx - size / 2 * cos * i
            location['y'] = locationy - size / 2 * sin * i
        elif 90 < angle < 180 and mirror is True:
            location['x'] = locationx - size / 2 * cos * i
            location['y'] = locationy + size / 2 * sin * i
        elif 180 < angle < 270 and mirror is False:
            location['x'] = locationx - size / 2 * cos * i
            location['y'] = locationy + size / 2 * sin * i
        elif 180 < angle < 270 and mirror is True:
            location['x'] = locationx - size / 2 * cos * i
            location['y'] = locationy - size / 2 * sin * i
        elif 270 < angle < 360 and mirror is False:
            location['x'] = locationx + size / 2 * cos * i
            location['y'] = locationy + size / 2 * sin * i
        elif 270 < angle < 360 and mirror is True:
            location['x'] = locationx + size / 2 * cos * i
            location['y'] = locationy - size / 2 * sin * i
    return location


def changeDatum11(xsize, ysize, size, sin, cos, locationx, locationy, sepcial_angle, vertical_angle, angle, mirror,
                  datum):
    location = {}
    if datum == 1:
        i = 1
    elif datum == 2:
        i = -1
    if 0 < angle < 90 or 180 < angle < 270:
        aa = 1
    elif 90 < angle < 180 or 270 < angle < 360:
        aa = 2
    if xsize < ysize and sepcial_angle is True and vertical_angle is False:
        location['x'] = locationx + (size - ysize * 25400) / 2 * i
        location['y'] = locationy
    elif xsize < ysize and sepcial_angle is True:
        location['x'] = locationx
        location['y'] = locationy + (size - ysize * 25400) / 2 * i
    elif xsize > ysize and sepcial_angle is True and vertical_angle is False:
        location['x'] = locationx + (size - xsize * 25400) / 2 * i
        location['y'] = locationy
    elif xsize > ysize and sepcial_angle is True:
        location['x'] = locationx
        location['y'] = locationy + (size - xsize * 25400) / 2 * i
    elif xsize < ysize and mirror is False and aa == 1:
        location['x'] = locationx + (size - ysize * 25400) / 2 * cos * i
        location['y'] = locationy + (size - ysize * 25400) / 2 * sin * i
    elif xsize > ysize and mirror is False and aa == 1:
        location['x'] = locationx + (size - xsize * 25400) / 2 * cos * i
        location['y'] = locationy - (size - xsize * 25400) / 2 * sin * i
    elif xsize < ysize and mirror is True and aa == 1:
        location['x'] = locationx + (size - ysize * 25400) / 2 * cos * i
        location['y'] = locationy - (size - ysize * 25400) / 2 * sin * i
    elif xsize > ysize and mirror is True and aa == 1:
        location['x'] = locationx + (size - xsize * 25400) / 2 * cos * i
        location['y'] = locationy + (size - xsize * 25400) / 2 * sin * i
    elif xsize < ysize and mirror is False and aa == 2:
        location['x'] = locationx + (size - ysize * 25400) / 2 * cos * i
        location['y'] = locationy - (size - ysize * 25400) / 2 * sin * i
    elif xsize > ysize and mirror is False and aa == 2:
        location['x'] = locationx + (size - xsize * 25400) / 2 * cos * i
        location['y'] = locationy + (size - xsize * 25400) / 2 * sin * i
    elif xsize < ysize and mirror is True and aa == 2:
        location['x'] = locationx + (size - ysize * 25400) / 2 * cos * i
        location['y'] = locationy + (size - ysize * 25400) / 2 * sin * i
    elif xsize > ysize and mirror is True and aa == 2:
        location['x'] = locationx + (size - xsize * 25400) / 2 * cos * i
        location['y'] = locationy - (size - xsize * 25400) / 2 * sin * i
    return location


def changeDatum13(xsize, ysize, size, sin, cos, locationx, locationy, angle, mirror, datum):
    location = {}
    if datum == 3:
        i = 1
    elif datum == 4:
        i = -1
    if angle == 0 or angle == 360:
        angle = 0
    if xsize < ysize:
        if angle == 0:
            location['x'] = locationx
            location['y'] = locationy + (size - ysize * 25400) / 2 * i
        elif angle == 180:
            location['x'] = locationx
            location['y'] = locationy - (size - ysize * 25400) / 2 * i
        elif angle == 90:
            location['x'] = locationx + (size - ysize * 25400) / 2 * i
            location['y'] = locationy
        elif angle == 270:
            location['x'] = locationx - (size - ysize * 25400) / 2 * i
            location['y'] = locationy
        elif 0 < angle < 90 and mirror is False:
            location['x'] = locationx + (size - ysize * 25400) / 2 * cos * i
            location['y'] = locationy + (size - ysize * 25400) / 2 * sin * i
        elif 0 < angle < 90 and mirror is True:
            location['x'] = locationx - (size - ysize * 25400) / 2 * cos * i
            location['y'] = locationy + (size - ysize * 25400) / 2 * sin * i
        elif 90 < angle < 180 and mirror is False:
            location['x'] = locationx + (size - ysize * 25400) / 2 * cos * i
            location['y'] = locationy - (size - ysize * 25400) / 2 * sin * i
        elif 90 < angle < 180 and mirror is True:
            location['x'] = locationx - (size - ysize * 25400) / 2 * cos * i
            location['y'] = locationy - (size - ysize * 25400) / 2 * sin * i
        elif 180 < angle < 270 and mirror is False:
            location['x'] = locationx - (size - ysize * 25400) / 2 * cos * i
            location['y'] = locationy - (size - ysize * 25400) / 2 * sin * i
        elif 180 < angle < 270 and mirror is True:
            location['x'] = locationx + (size - ysize * 25400) / 2 * cos * i
            location['y'] = locationy - (size - ysize * 25400) / 2 * sin * i
        elif 270 < angle < 360 and mirror is False:
            location['x'] = locationx - (size - ysize * 25400) / 2 * cos * i
            location['y'] = locationy + (size - ysize * 25400) / 2 * sin * i
        elif 270 < angle < 360 and mirror is True:
            location['x'] = locationx + (size - ysize * 25400) / 2 * cos * i
            location['y'] = locationy + (size - ysize * 25400) / 2 * sin * i
    elif xsize > ysize:
        if angle == 0:
            location['x'] = locationx + (size - xsize * 25400) / 2 * i
            location['y'] = locationy
        elif angle == 180:
            location['x'] = locationx - (size - xsize * 25400) / 2 * i
            location['y'] = locationy
        elif angle == 90:
            location['x'] = locationx
            location['y'] = locationy - (size - xsize * 25400) / 2 * i
        elif angle == 270:
            location['x'] = locationx
            location['y'] = locationy + (size - xsize * 25400) / 2 * i
        elif 0 < angle < 90 and mirror is False:
            location['x'] = locationx + (size - xsize * 25400) / 2 * cos * i
            location['y'] = locationy - (size - xsize * 25400) / 2 * sin * i
        elif 0 < angle < 90 and mirror is True:
            location['x'] = locationx + (size - xsize * 25400) / 2 * cos * i
            location['y'] = locationy + (size - xsize * 25400) / 2 * sin * i
        elif 90 < angle < 180 and mirror is False:
            location['x'] = locationx - (size - xsize * 25400) / 2 * cos * i
            location['y'] = locationy - (size - xsize * 25400) / 2 * sin * i
        elif 90 < angle < 180 and mirror is True:
            location['x'] = locationx - (size - xsize * 25400) / 2 * cos * i
            location['y'] = locationy + (size - xsize * 25400) / 2 * sin * i
        elif 180 < angle < 270 and mirror is False:
            location['x'] = locationx - (size - xsize * 25400) / 2 * cos * i
            location['y'] = locationy + (size - xsize * 25400) / 2 * sin * i
        elif 180 < angle < 270 and mirror is True:
            location['x'] = locationx - (size - xsize * 25400) / 2 * cos * i
            location['y'] = locationy - (size - xsize * 25400) / 2 * sin * i
        elif 270 < angle < 360 and mirror is False:
            location['x'] = locationx + (size - xsize * 25400) / 2 * cos * i
            location['y'] = locationy + (size - xsize * 25400) / 2 * sin * i
        elif 270 < angle < 360 and mirror is True:
            location['x'] = locationx + (size - xsize * 25400) / 2 * cos * i
            location['y'] = locationy - (size - xsize * 25400) / 2 * sin * i
    return location


def ovalMode00(xlen, ylen, sepcial_angle, xsize, ysize):
    location = {}
    if xsize > ysize and sepcial_angle is True:
        xnew = xsize + xlen
        ynew = ysize
    elif xsize > ysize and sepcial_angle is False:
        xnew = xsize + xlen
        ynew = ysize
    elif xsize < ysize and sepcial_angle is True:
        xnew = xsize
        ynew = ysize + ylen
    elif xsize < ysize and sepcial_angle is False:
        xnew = xsize
        ynew = ysize + ylen
    location['xnew'] = xnew
    location['ynew'] = ynew
    return location


def ovalMode10(xsize, ysize, size):
    location = {}
    if xsize > ysize:
        xnew = size / 1000000 / 25.4 * 1000
        ynew = ysize
    else:
        xnew = xsize
        ynew = size / 1000000 / 25.4 * 1000
    location['xnew'] = xnew
    location['ynew'] = ynew
    return location


def nearHoleSplitter(holeSize, holeSpacing, inPoints):
    data = {
        'func': 'NEAR_HOLE_SPLITTER',
        'paras': {'holeSize': holeSize,
                  'holeSpacing': holeSpacing,
                  'inPoints': inPoints
                  }
    }
    return deepline.process(json.dumps(data))


def Init():
    global _global_dict
    _global_dict = {}


def setValue(key, value):
    _global_dict[key] = value


def getValue(key):
    try:
        return _global_dict[key]
    except:
        print('读取' + key + '失败\r\n')


def refreshJoblist(jobname, stepname):
    data = {
        'func': 'REFRESH_JOBLIST',
        'paras': {
            'jobname': jobname,
            'stepname': stepname
        }
    }
    # print(json.dumps(data))
    return deepline.uiprocess(json.dumps(data))


def closeAllLayer(jobname, stepname):
    data = {
        'func': 'CLOSE_ALL_LAYER',
        'paras': {
            'jobname': jobname,
            'stepname': stepname
        }
    }
    # print(json.dumps(data))
    return deepline.uiprocess(json.dumps(data))


def displayLayers(job, step, clayer='', snaplayer='', displaylayers=[], affectedlayers=[]):
    data = {
        'func': 'DISPLAY_LAYERS',
        'paras': {
            'jobname': job,
            'stepname': step,
            'clayer': clayer,
            'snaplayer': snaplayer,
            'displaylayers': displaylayers,
            'affectedlayers': affectedlayers
        }
    }
    # print(json.dumps(data))
    return deepline.uiprocess(json.dumps(data))


def setLayerInfos(job, layerInfo, oldAndNewlayerParams):
    data = {
        'func': 'SET_LAYER_INFOS',
        'paras': {
            'job': job,
            'layerInfo': layerInfo,
            'oldAndNewlayerParams': oldAndNewlayerParams
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def getFillParam():
    data = {
        'func': 'GET_FILL_PARAM',
        'paras': {

        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def setFillParam(fillType, gridParams, patternParams, solidParams):
    data = {
        'func': 'SET_FILL_PARAM',
        'paras': {
            'fillType': fillType,
            'gridParams': gridParams,
            'patternParams': patternParams,
            'solidParams': solidParams
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def stepFlip(job, step):
    data = {
        'func': 'STEP_FLIP',
        'paras': {
            'job': job,
            'step': step
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def pcsAnalysis(job, step, path):
    data = {
        'cmd': 'pcsAnalysis',
        'job': job,
        'step': step,
        'path': path
    }
    return deepline.pcsAnalysis(json.dumps(data))


def readAutoMatrixRule(path):
    data = {
        'cmd': 'readPathFactoryJson',
        'path': path
    }
    return deepline.readPathFactoryJson(json.dumps(data))


def readAutoMatrixTemplate(path):
    data = {
        'cmd': 'readPathTemplateConfigJson',
        'path': path
    }
    return deepline.readPathTemplateConfigJson(json.dumps(data))


def autoMatrix(nameList):
    data = {
        'cmd': 'getMatchedLayers',
        'NameList': nameList
    }
    return deepline.getMatchedLayers(json.dumps(data))


def saveNewMatchRule(matchRule, path, ruleName):
    data = {
        'cmd': 'saveNewMatchRule',
        'MatchRule': matchRule,
        'path': path,
        'RuleName': ruleName
    }
    return deepline.saveNewMatchRule(json.dumps(data))


def getSignalLayers(layerInfos):
    signalLayers = []
    for v in layerInfos:
        if v["type"] == "signal":
            signalLayers.append(v['name'])
    return signalLayers


def typeMatchLayer2LayerInfo(matchLayers, layerInfos, oldList, newList, signalNames=[]):
    for vv in matchLayers:
        layerInfo = {}
        layerInfo['type'] = vv['attr']['type']
        layerInfo['name'] = vv['newname']
        layerInfo['context'] = vv['attr']['context']
        layerInfo['polarity'] = vv['attr']['polarity']
        layerInfo['start_name'] = ""
        layerInfo['end_name'] = ""
        layerInfo['old_name'] = vv['oldname']
        layerInfo['row'] = len(layerInfos) + 1
        if vv["LayerType"] == "drill":
            start_index = vv['attr']['startindex']
            end_index = vv['attr']['endindex']
            if (start_index < len(signalNames)) and (end_index < len(signalNames)):
                layerInfo['start_name'] = signalNames[start_index]
                layerInfo['end_name'] = signalNames[end_index]
        # nameMap.append({vv['oldname'] : vv['newname']})
        oldList.append(vv['oldname'])
        newList.append(vv['newname'])
        layerInfos.append(layerInfo)


def matchLayers2LayerInfos(matchLayers):
    layerInfos = []
    oldList = []
    newList = []
    solderPasteTop = []
    silkScreenTop = []
    solderMaskTop = []
    signalTop = []
    signalInner = []
    signalBot = []
    solderMaskBot = []
    silkScreenBot = []
    solderPasteBot = []
    drill = []
    for v in matchLayers:
        if v["LayerType"] == "solder-paste-top":
            solderPasteTop = v['MatchedLayer']
        if v["LayerType"] == "silk-screen-top":
            silkScreenTop = v['MatchedLayer']
        if v["LayerType"] == "solder-mask-top":
            solderMaskTop = v['MatchedLayer']
        if v["LayerType"] == "signal-top":
            signalTop = v['MatchedLayer']
        if v["LayerType"] == "signal-inner":
            signalInner = v['MatchedLayer']
        if v["LayerType"] == "signal-bot":
            signalBot = v['MatchedLayer']
        if v["LayerType"] == "solder-mask-bot":
            solderMaskBot = v['MatchedLayer']
        if v["LayerType"] == "silk-screen-bot":
            silkScreenBot = v['MatchedLayer']
        if v["LayerType"] == "solder-paste-bot":
            solderPasteBot = v['MatchedLayer']
        if v["LayerType"] == "drill":
            drill = v['MatchedLayer']
    typeMatchLayer2LayerInfo(solderPasteTop, layerInfos, oldList, newList)
    typeMatchLayer2LayerInfo(silkScreenTop, layerInfos, oldList, newList)
    typeMatchLayer2LayerInfo(solderMaskTop, layerInfos, oldList, newList)
    typeMatchLayer2LayerInfo(signalTop, layerInfos, oldList, newList)
    typeMatchLayer2LayerInfo(signalInner, layerInfos, oldList, newList)
    typeMatchLayer2LayerInfo(signalBot, layerInfos, oldList, newList)
    typeMatchLayer2LayerInfo(solderMaskBot, layerInfos, oldList, newList)
    typeMatchLayer2LayerInfo(silkScreenBot, layerInfos, oldList, newList)
    typeMatchLayer2LayerInfo(solderPasteBot, layerInfos, oldList, newList)
    signalNames = getSignalLayers(layerInfos)
    typeMatchLayer2LayerInfo(drill, layerInfos, oldList, newList, signalNames)
    return (layerInfos, oldList, newList)


def getLayerAttributes(job, step, layer):
    data = {
        'func': 'GET_LAYER_ATTRIBUTES',
        'paras': {
            'job': job,  # string
            'step': step,  # string
            'layer': layer  # string
        }
    }
    return deepline.process(json.dumps(data))


def editLayerAttributes(job, step, layer, edit_mode, edit_attr_name, edit_attr_value):
    data = {
        'func': 'EDIT_LAYER_ATTRIBUTES',
        'paras': {
            'job': job,  # string
            'step': step,  # string
            'layer': layer,  # string
            'editMode': edit_mode,  # int
            'editAttrName': edit_attr_name,  # string
            'editAttrValue': edit_attr_value  # string
        }
    }
    return deepline.process(json.dumps(data))


def getStepAttributes(job, step):
    data = {
        'func': 'GET_STEP_ATTRIBUTES',
        'paras': {
            'job': job,  # string
            'step': step  # string
        }
    }
    return deepline.process(json.dumps(data))


def editStepAttributes(job, step, edit_mode, edit_attr_name, edit_attr_value):
    data = {
        'func': 'EDIT_STEP_ATTRIBUTES',
        'paras': {
            'job': job,  # string
            'step': step,  # string
            'editMode': edit_mode,  # int
            'editAttrName': edit_attr_name,  # string
            'editAttrValue': edit_attr_value  # string
        }
    }
    return deepline.process(json.dumps(data))


def changeToGuideTool(jobname, stepname, type):
    data = {
        'func': 'CHANGE_TO_GUIDE_TOOL',
        'paras': {
            'jobname': jobname,
            'stepname': stepname,
            'type': type
        }
    }
    # print(json.dumps(data))
    return deepline.uiprocess(json.dumps(data))


def changeToLastTool(jobname, stepname):
    data = {
        'func': 'CHANGE_TO_LAST_TOOL',
        'paras': {
            'jobname': jobname,
            'stepname': stepname
        }
    }
    # print(json.dumps(data))
    return deepline.uiprocess(json.dumps(data))


def getClickedPoint(jobname, stepname):
    data = {
        'func': 'GET_CLICKED_POINT',
        'paras': {
            'jobname': jobname,
            'stepname': stepname
        }
    }
    # print(json.dumps(data))
    return deepline.uiprocess(json.dumps(data))


def getClickedBox(jobname, stepname):
    data = {
        'func': 'GET_CLICKED_BOX',
        'paras': {
            'jobname': jobname,
            'stepname': stepname
        }
    }
    # print(json.dumps(data))
    return deepline.uiprocess(json.dumps(data))


def layerBox(job, step, layers):
    data = {
        'func': 'LAYER_BOX',
        'paras': {
            'job': job,
            'step': step,
            'layers': layers
        }
    }
    return deepline.process(json.dumps(data))


def checkRoutOutput(job, step, layer):
    data = {
        'func': 'CHECK_ROUT_OUTPUT',
        'paras': {
            'job': job,
            'step': step,
            'sourceLayer': layer
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def editSelectedFeaturesAttributes(job, step, layer, mode, attributes):
    data = {
        'func': 'EDIT_SELECTED_FEATURES_ATTRIBUTES',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'mode': mode,
            'attributes': attributes
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def getActivedStepInfo(job):
    data = {
        'func': 'GET_ACTIVED_STEP_INFO',
        'paras': {
            'jobname': job
        }
    }
    # print(json.dumps(data))
    return deepline.uiprocess(json.dumps(data))


def addChain(job, step, layer, chain_number, first_index, comp, is_CCW, add_plunge, toolsize, rout_flag=0, feed=0,
             speed=0):
    data = {
        'func': 'ADDCHAIN',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer,
            'chainNumber': chain_number,
            'firstIndex': first_index,
            'comp': comp,
            'isCCW': is_CCW,
            'addPlunge': add_plunge,
            'toolSize': toolsize,
            'routflag': rout_flag,
            'feed': feed,
            'speed': speed
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def getAllFeaturesReportFlattern(job, step, layer):
    data = {
        'func': 'GET_ALL_FEATURES_REPORT_FLATTERN',
        'paras': {
            'job': job,
            'step': step,
            'layer': layer
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def selectFeaturesByNet(job, step, layer, vec_dest_layername, use_select_info, selectpolygon):
    data = {
        'func': 'SELECT_FEATURES_BY_NET',
        'paras': {
            'jobname': job,
            'stepname': step,
            'layername': layer,
            'vec_dest_layername': vec_dest_layername,
            'use_select_info': use_select_info,
            'selectpolygon': selectpolygon
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def usersymbolIsUsed(job, symbolname):
    data = {
        'func': 'USERSYMBOL_IS_USED',
        'paras': {
            'job': job,
            'symbolName': symbolname
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def deleteUsersymbol(job, symbolname):
    data = {
        'func': 'DELETE_USERSYMBOL',
        'paras': {
            'job': job,
            'symbolName': symbolname
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def renameUsersymbol(job, oldname, newname):
    data = {
        'func': 'RENAME_USERSYMBOL',
        'paras': {
            'job': job,
            'oldName': oldname,
            'newName': newname
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def setSymbolUiData(oldstr, unit):
    data = {
        'func': 'SET_SYMBOL_UI_DATA',
        'paras': {
            'oldstr': oldstr,
            'unit': unit
        }
    }
    # print(json.dumps(data))
    return deepline.uiprocess(json.dumps(data))


def exportDxf(jobName, stepName, layers, outputPath):
    data = {
        'func': 'EXPORT_DXF',
        'paras': {
            'job': jobName,
            'step': stepName,
            'layers': layers,
            'path': outputPath
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def importDxf(inputPath, jobName, stepName, layerName, scale, polylineEnds, units, proportionText,
              convertCircleToApertures, convertDonutsToApertures, fillClosedZeroWidthPolylines, layerApart):
    data = {
        'func': 'IMPORT_DXF',
        'paras': {
            'path': inputPath,
            'job': jobName,
            'step': stepName,
            'layer': layerName,
            'scale': scale,
            'polylineEnds': polylineEnds,
            'units': units,
            'proportionText': proportionText,
            'convertCircleToApertures': convertCircleToApertures,
            'convertDonutsToApertures': convertDonutsToApertures,
            'fillClosedZeroWidthPolylines': fillClosedZeroWidthPolylines,
            'layerApart': layerApart
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def exportGds2(jobName, stepName, layers, outputPath, dbu):
    data = {
        'func': 'EXPORT_GDS2',
        'paras': {
            'job': jobName,
            'step': stepName,
            'layers': layers,
            'path': outputPath,
            'dbu': dbu
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def autoZeroPoint(jobName, stepName, layers, targetX, targetY):
    data = {
        'func': 'AUTO_ZERO_POINT',
        'paras': {
            'job': jobName,
            'step': stepName,
            'layers': layers,
            'x': targetX,
            'y': targetY
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def deleteLayerWithName(jobName, layerName):
    data = {
        'func': 'DELETE_LAYER_WITH_NAME',
        'paras': {
            'job': jobName,
            'layer': layerName
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def maskAnalysis(jobName, stepName, layerName, userSymbol):
    data = {
        'func': 'MASK_ANALYSIS',
        'paras': {
            'job': jobName,
            'step': stepName,
            'layer': layerName,
            'user_symbol': userSymbol
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def newLayerFromSymbol(jobName, stepName, symbolName):
    data = {
        'func': 'NEW_LAYER_FROM_SYMBOL',
        'paras': [
            {'job': jobName},
            {'step': stepName},
            {'symbol': symbolName}
        ]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def updateSymbolFromLayer(jobName, stepName, symbolName, layerName):
    data = {
        'func': 'UPDATE_SYMBOL_FROM_LAYER',
        'paras': [
            {'job': jobName},
            {'step': stepName},
            {'symbol': symbolName},
            {'layer': layerName}
        ]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def createProfileBySelected(jobName, stepName, layerName):
    data = {
        'func': 'CREATE_PROFILE_BY_SELECTED',
        'paras': [
            {'job': jobName},
            {'step': stepName},
            {'layer': layerName}
        ]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def featureStepAndRepeat(jobName, stepName, layerName, nx, ny, dx, dy, xDir, yDir, mode):
    data = {
        'func': 'FEATURE_STEP_AND_REPEAT',
        'paras': [{
            'job': jobName,
            'step': stepName,
            'layer': layerName,
            'nx': nx,
            'ny': ny,
            'dx': dx,
            'dy': dy,
            'xDir': xDir,
            'yDir': yDir,
            'mode': mode
        }]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def reshapeBreak(jobName, stepName, layerName):
    data = {
        'func': 'RESHAPE_BREAK',
        'paras': [
            {'job': jobName},
            {'step': stepName},
            {'layer': layerName}
        ]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def arcToLine(jobName, stepName, layers, selectType, scopeParam):
    data = {
        'func': 'ARC_TO_LINE',
        'paras': {
            'job': jobName,
            'step': stepName,
            'layer': layers,
            'select_type': selectType,
            'scope_param': scopeParam
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def breakSurfaceArc(jobName, stepName, layers, scopeParam):
    data = {
        'func': 'BREAK_SURFACE_ARC',
        'paras': {
            'job': jobName,
            'step': stepName,
            'layer': layers,
            'scope_param': scopeParam
        }
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def outlineToSurface(jobName, stepName, layers, canToPad, size, unit, method):
    data = {
        'func': 'OUTLINE_TO_SURFACE',
        'paras': [
            {'job': jobName},
            {'step': stepName},
            {'layers': layers},
            {'can_to_pad': canToPad},
            {'size': size},
            {'unit': unit},
            {'method': method}
        ]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def dividePolygon(jobName, stepName, layers, vertex):
    data = {
        'func': 'DIVIDE_POLYGON',
        'paras': [
            {'job': jobName},
            {'step': stepName},
            {'layers': layers},
            {'vertex': vertex}
        ]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def getUserSymbolHistogram(job, step, layer):
    data = {
        'func': 'GET_USER_SYMBOL_HISTOGRAM',
        'paras': [
            {'job': job},
            {'step': step},
            {'layer': layer}
        ]
    }
    # print(json.dumps(data))
    return deepline.process(json.dumps(data))


def clipArea(job, step, layers, mode, points=None, reference_layer=None,
             clip_inside=False, clip_contour=False, margin=0.0,
             smooth_tolerance=1000.0, feature_type=0):
    """
    根据 mode 分发到三种不同的底层 CLIP_AREA 接口
    0: MANUAL, 1: REFERENCE, 2: PROFILE
    """
    if mode == 0:
        data = {
            'func': 'CLIP_AREA_USE_MANUAL',
            'paras': {
                'job': job,
                'step': step,
                'layers': layers,
                'points': points if points else [],
                'clipinside': clip_inside,
                'clipcontour': clip_contour,
                'margin': margin,
                'smooth_tolerance': smooth_tolerance,
                'featuretype': feature_type
            }
        }
    elif mode == 1:
        data = {
            'func': 'CLIP_AREA_USE_REFERENCE',
            'paras': {
                'jobname': job,
                'stepname': step,
                'work_layer': layers,
                'reference_layer': reference_layer,
                'clipcontour': clip_contour,
                'margin': margin,
                'smooth_tolerance': smooth_tolerance,
                'featuretype': feature_type
            }
        }
    elif mode == 2:
        data = {
            'func': 'CLIP_AREA_USE_PROFILE',
            'paras': {
                'job': job,
                'jobname': job,
                'step': step,
                'stepname': step,
                'layers': layers,
                'work_layer': layers,
                'clipinside': clip_inside,
                'clipcontour': clip_contour,
                'margin': margin,
                'smooth_tolerance': smooth_tolerance,
                'featuretype': feature_type
            }
        }
    else:
        return '{"status": false, "msg": "Invalid mode for clipArea"}'

    # print(json.dumps(data))
    return deepline.process(json.dumps(data))

