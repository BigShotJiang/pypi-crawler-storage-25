import json
import time

from deepKernel import deepline, base


def init(path: str):
    deepline.init(path)
    base.setConfigPath(path)
    v = deepline.getVersion()
    # version = v['dl_version'] + v['sub_version']
    # if not version == '1.1.3.19':
    #   print("deepKernel与bin包版本不匹配，请谨慎使用")


def setSysattrPath(path: str):
    try:
        base.setSysAttrPath(path)
    except Exception as e:
        print(e)
    return


def setUserattrPath(path: str):
    try:
        base.setUserAttrPath(path)
    except Exception as e:
        print(e)
    return


def readAutoMatrixRule(path: str) -> dict:
    try:
        ccc = base.readAutoMatrixRule(path)
        return json.loads(ccc)
    except Exception as e:
        print(e)
        return {}


def readAutoMatrixTemplate(path: str) -> dict:
    try:
        ccc = base.readAutoMatrixTemplate(path)
        return json.loads(ccc)
    except Exception as e:
        print(e)
        return {}


# def addNewMatchRule(layer_infos: list, path: str) -> dict:
#     try:
#         ruleName = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
#         ret = base.saveNewMatchRule(layer_infos, path, ruleName)
#         ret = json.loads(ret)
#         return ret
#    except Exception as e:
#        print(e)
#    return {}
