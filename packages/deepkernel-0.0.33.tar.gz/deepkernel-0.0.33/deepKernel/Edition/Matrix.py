import json

from deepKernel import base
from deepKernel.Action import Information


# 拷贝Layer
def copyLayer(job: str, old_layer_name: str) -> str:
    try:
        ret = base.getMatrix(job)
        data = json.loads(ret)
        layer_infos = data['paras']['info']
        src_layername = []
        src_layername = Information.getLayers(job)
        if old_layer_name in src_layername:
            for i in range(0, len(layer_infos)):
                if layer_infos[i]['name'] == old_layer_name:
                    old_layer_index = i + 1
        else:
            raise ValueError(f'layer not exist!')
        dst_layer = ''
        # 新建空layer
        createLayer(job, 'jbz')
        ret2 = base.copyLayer(job, old_layer_index,
                              dst_layer, len(layer_infos) + 1)
        data2 = json.loads(ret2)
        new_layer = data2['paras']['newname']
        # 删除新层
        deleteLayer(job, 'jbz')
        return new_layer
    except Exception as e:
        print(e)
    return ''


# 创建layer
def createLayer(job: str, layer: str, row_index: int = -1) -> bool:
    try:
        step = ''  # 在所有层创建
        res = base.createNewLayer(job, step, layer, row_index)
        return base.checkProcessStatus(res)
    except Exception as e:
        print(e)
    return False


# 删除layer
def deleteLayer(job: str, layername: str) -> bool:
    try:
        ret = base.getMatrix(job)
        data = json.loads(ret)
        layer_infos = data['paras']['info']
        for i in range(0, len(layer_infos)):
            if layer_infos[i]['name'] == layername:
                layer_index = i + 1
                res = base.deleteLayer(job, layer_index)
                return base.checkProcessStatus(res)
    except Exception as e:
        print(e)
    return False


# 创建step
def createStep(job: str, step: str, col_index: int = -1) -> bool:
    try:
        res = base.createStep(job, step, col_index)
        return base.checkProcessStatus(res)
    except Exception as e:
        print(e)
    return False


def changeMatrixRow(job: str, layer: str, context: str, type: str, layername: str, polarity: bool = True) -> bool:
    """
    #修改指定层别信息,若修改后信息与原层别一致，则此函数不执行
    :param     job
    :param     layer
    :param     context
    :param     type
    :param     layername
    :param     polarity
    :returns   : int
    :raises    Exception
    """
    try:
        ret = base.getMatrix(job)
        data = json.loads(ret)
        layer_infos = data['paras']['info']

        if polarity is True:
            polarity_str = 'positive'
        else:
            polarity_str = 'negative'

        layer_index = -1

        for i in range(0, len(layer_infos)):
            if layer_infos[i]['name'] == layer:
                layer_index = i + 1
                layer_infos[i]['context'] = context
                layer_infos[i]['type'] = type
                layer_infos[i]['name'] = layername
                layer_infos[i]['polarity'] = polarity_str
                break

        if layer_index != -1:
            res = base.changeMatrix(job, -1, layer_index, '', layer_infos[layer_index - 1])
            return base.checkProcessStatus(res)
        else:
            print(f"未能找到需要修改的层别: {layer}")
            return False

    except Exception as e:
        print(e)
    return False


def changeMatrixColumn(job: str, src_name: str, dst_name: str) -> bool:
    try:
        ret = base.getMatrix(job)
        data = json.loads(ret)
        step_infos = data['paras']['steps']

        if src_name in step_infos:
            old_step_index_int = step_infos.index(src_name) + 1
            dummy_layer_info = {
                'context': '',
                'end_name': '',
                'name': '',
                'old_name': '',
                'orientation': '',
                'polarity': '',
                'row': 0,
                'start_name': '',
                'step': '',
                'type': ''
            }

            # 传入完美符合签名的 dummy_layer_info
            res = base.changeMatrix(job, old_step_index_int, -1, dst_name, dummy_layer_info)
            return base.checkProcessStatus(res)
        else:
            print(f"未能找到需要修改的 Step 列: {src_name}")
            return False
    except Exception as e:
        print(f"changeMatrixColumn 异常: {e}")

    return False


def deleteStep(job: str, step: str) -> bool:
    try:
        ret = base.getMatrix(job)
        data = json.loads(ret)
        step_infos = data['paras']['steps']
        for i in range(0, len(step_infos)):
            if step_infos[i] == step:
                step_index = i + 1
                ret = base.deleteStep(job, step_index)
                return base.checkProcessStatus(ret)
    except Exception as e:
        print(e)
    return False


def copyStep(job: str, src_step_name: str) -> str:
    try:
        ret = base.getMatrix(job)
        data = json.loads(ret)
        step_infos = data['paras']['steps']
        if src_step_name in step_infos:
            for i in range(0, len(step_infos)):
                if step_infos[i] == src_step_name:
                    old_step_index = i + 1
            dst_step = ''
            # 新建空
            createStep(job, 'jbz')
            ret = Information.getSteps(job)
            ret2 = base.copyStep(job, old_step_index,
                                 dst_step, old_step_index + 1)
            data2 = json.loads(ret2)
            new_step = data2['paras']['newname']
            # 删除新层
            deleteStep(job, 'jbz')
        return new_step
    except Exception as e:
        print(e)
        return 'False'


# 备份多层（覆盖）(需备份层无选中feature)
# def backupLayer(job: str, step: str, layers: list, suffix: str):
#     try:
#         layer_list = Information.getLayers(job)
#         for layer in layers:
#             new_layer = layer + suffix
#             if new_layer not in layer_list:
#                 createLayer(job, new_layer)
#             else:
#                 base.clearSelectedFeatures(job, step, new_layer)
#                 Selection.reverseSelect(job, step, new_layer)
#                 Layers.deleteFeature(job, step, new_layer)
#                 base.clearSelectedFeatures(job, step, new_layer)
#             Layers.copy2otherLayer(job, step, layer, new_layer, False, 0, 0, 0, 0, 0, 0, 0)
#     except Exception as e:
#         print(e)
#         return None


def moveLayer(job: str, org_layer_index: int, dst_layer_index: int) -> bool:
    try:
        jobname = job
        res = base.moveLayer(jobname, org_layer_index, dst_layer_index)
        return base.checkProcessStatus(res)
    except Exception as e:
        print(e)
    return False


def setLayerInfos(job: str, layerInfos: list, oldList: list, newList: list) -> bool:
    try:
        if not len(oldList) == len(newList):
            return False
        if not len(oldList) == len(layerInfos):
            return False
        if len(oldList) == 0:
            return False
        nameMap = []
        for i in range(len(oldList)):
            nameMap.append({oldList[i]: newList[i]})
        ret = base.setLayerInfos(job, layerInfos, nameMap)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print(e)
    return False


def autoMatrix(job: str) -> tuple:
    try:
        # 获取所有层别名
        nameList = Information.getLayers(job)
        vv = base.autoMatrix(nameList)
        nn = json.loads(vv)
        ret = json.loads(nn['msg'])
        if ret == '':
            return ([], [], [])
        # 将匹配结果转为set_layer_infos需要的数据结构
        bbb = base.matchLayers2LayerInfos(ret)
        layerInfos = bbb[0]
        oldList = bbb[1]
        newList = bbb[2]

        # 加入将未匹配成功的层
        for v in layerInfos:
            nameList.remove(v["old_name"])

        vIndex = 1
        for vv in nameList:
            layerInfo = {}
            layerInfo['type'] = 'document'
            layerInfo['name'] = vv
            layerInfo['context'] = 'misc'
            layerInfo['polarity'] = 'positive'
            layerInfo['start_name'] = ""
            layerInfo['end_name'] = ""
            layerInfo['old_name'] = vv
            layerInfo['row'] = len(layerInfos) + vIndex
            layerInfos.append(layerInfo)
            # nameMap.append({vv : vv})
            oldList.append(vv)
            newList.append(vv)
        return (layerInfos, oldList, newList)
    except Exception as e:
        print(e)
        return ([], [], [])


def createFlip(job: str, step: str) -> bool:
    try:
        _ret = base.stepFlip(job, step)
        ret = json.loads(_ret)['paras']['result']
        return ret
    except Exception as e:
        print(e)
        return False


def editStepAttributes(job: str, step: str, edit_mode: int, edit_attr_name: str, edit_attr_value: str) -> bool:
    try:
        _ret = base.editStepAttributes(job, step, edit_mode, edit_attr_name, edit_attr_value)
        ret = json.loads(_ret)['status']
        if ret == 'true':
            ret = True
        else:
            ret = False
        return ret
    except Exception as e:
        print(e)
    return False


def editLayerAttributes(job: str, step: str, layer: str, edit_mode: int, edit_attr_name: str,
                        edit_attr_value: str) -> bool:
    try:
        ret = base.editLayerAttributes(job, step, layer, edit_mode, edit_attr_name, edit_attr_value)
        return base.checkProcessStatus(ret)
    except Exception as e:
        print(e)
    return False


def changeDrillCross(job: str, layer: str, start_name: str, end_name: str) -> bool:
    try:
        ret = base.getMatrix(job)
        data = json.loads(ret)
        layer_infos = data['paras']['info']

        layer_index = -1

        for i in range(0, len(layer_infos)):
            if layer_infos[i]['name'] == layer:
                layer_index = i + 1
                layer_infos[i]['start_name'] = start_name
                layer_infos[i]['end_name'] = end_name
                break

        if layer_index != -1:
            res = base.changeMatrix(job, -1, layer_index, '', layer_infos[layer_index - 1])
            return base.checkProcessStatus(res)
        else:
            print(f"未能找到需要修改起始/终止属性的图层: {layer}")
            return False

    except Exception as e:
        print(f"changeDrillCross 异常: {e}")
    return False
