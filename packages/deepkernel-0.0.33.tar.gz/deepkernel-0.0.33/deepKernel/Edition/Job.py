import json
import re

from deepKernel import base
from deepKernel.Action import Information


def deleteJob(job: str) -> None:
    try:
        base.jobDelete(job)
    except Exception as e:
        print(e)


def createJob(job: str) -> bool:
    try:
        openedjob = Information.getOpenedJobs()
        if job in openedjob:
            return False
        for ch in job:
            if u'\u4e00' <= ch <= u'\u9fff':
                return False
        if re.search('((?=[\x20-\x7e]+)[^A-Za-z0-9\_\+\-])', job) != None or job == 'eplib':
            return False
        else:
            ret = json.loads(base.jobCreate(job))['status']
            return bool(ret)
    except Exception as e:
        print(e)
        return False


def renameJob(src_jobname: str, dst_jobname: str) -> bool:
    try:
        openedjob = Information.getOpenedJobs()
        if dst_jobname in openedjob:
            return False
        if json.loads(base.isJobOpen(src_jobname))['paras']['status'] == True:
            # 判断料名中是否有中文
            for ch in dst_jobname:
                if u'\u4e00' <= ch <= u'\u9fff':
                    return False
            # 判断料号中是否有特殊符号
            if re.search('((?=[\x20-\x7e]+)[^A-Za-z0-9\_\+\-])', dst_jobname) != None or dst_jobname == 'eplib':
                return False
            else:
                base.jobRename(src_jobname, dst_jobname)
                return True
    except Exception as e:
        print(e)
        return False


# 判断指定料号是否打开
def isJobOpen(job: str) -> bool:
    try:
        _ret = base.isJobOpen(job)
        ret = json.loads(_ret)['paras']['status']
        return ret
    except Exception as e:
        print(e)
        return False


# 关闭指定料号(job)并清空内存,若不存在该料号名则不执行返回False值
def closeJob(job: str) -> bool:
    try:
        data = isJobOpen(job)
        if data:
            ret_ = base.closeJob(job)
            ret = json.loads(ret_)['status']
            return ret
        else:
            print(f'不存在{job}料号名!')
            return False
    except Exception as e:
        print(e)
    return False


def copyJob(src_job: str, dst_job: str) -> bool:
    try:
        ret = base.copyJob(src_job, dst_job)
        data = json.loads(ret)['paras'][0]
        return data
    except Exception as e:
        print(repr(e))
    return False
