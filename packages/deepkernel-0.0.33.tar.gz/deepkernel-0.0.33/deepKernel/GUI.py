from deepKernel import base
from deepKernel.Action import Information


def showLayer(job: str, step: str, layer: str) -> None:
    try:
        step_lst = Information.getSteps(job)
        if step != '':
            if step not in step_lst:
                print('step不存在')
                return
            else:
                base.showLayer(job, step, layer)
        else:
            print('step不存在')
            return
    except Exception as e:
        print(e)
    return


def showMatrix(job: str):
    try:
        base.showMatrix(job)
    except Exception as e:
        print(e)
    return
