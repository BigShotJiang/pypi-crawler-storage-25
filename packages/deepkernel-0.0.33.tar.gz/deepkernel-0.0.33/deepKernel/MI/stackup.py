import json

from deepKernel import base


def saveDrillBelts(job: str, drillbelts: dict) -> bool:
    try:
        step = drillbelts['stepName']
        infoList = drillbelts['info']
        copperLayerNum = drillbelts['copperLayerNum']
        _ret = base.saveDrillBelts(job, step, infoList, copperLayerNum)
        ret = json.loads(_ret)['status']
        if ret == 'true':
            ret = True
        else:
            ret = False
        return ret
    except Exception as e:
        print(e)
    return False


def getDrillBelts(job: str) -> dict:
    try:
        ret = base.getDrillBelts(job)
        ret = json.loads(ret)['paras']['result']
        return ret
    except Exception as e:
        print(e)
    return {}


def addDrillBelt(job: str, params: dict) -> int:
    try:
        drillLayerName = params['drillLayerName']
        startLayer = params['startLayer']
        endLayer = params['endLayer']
        drillBeltType = params['drillBeltType']
        drillNumber = params['drillNumber']
        _ret = base.addDrillBelt(job, drillLayerName, startLayer, endLayer, drillBeltType, drillNumber)
        ret = json.loads(_ret)['paras']['result']
        return ret
    except Exception as e:
        print(e)
    return None


def deleteDrillBelt(job: str, index: int) -> bool:
    try:
        _ret = base.deleteDrillBelt(job, index)
        ret = json.loads(_ret)['status']
        if ret == 'true':
            ret = True
        else:
            ret = False
        return ret
    except Exception as e:
        print(e)
    return False


def updateDrillBelt(job: str, index: int, params: dict) -> bool:
    try:
        updateDrillBeltPara = params
        _ret = base.updateDrillBelt(job, index, updateDrillBeltPara)
        ret = json.loads(_ret)['status']
        if ret == 'true':
            ret = True
        else:
            ret = False
        return ret
    except Exception as e:
        print(e)
    return False


def clearDrillBelts(job: str) -> bool:
    try:
        _ret = base.clearDrillBelts(job)
        ret = json.loads(_ret)['status']
        if ret == 'true':
            ret = True
        else:
            ret = False
        return ret
    except Exception as e:
        print(e)
    return False


def getLinkedCamLayer(job: str, index: int) -> dict:
    try:
        ret = base.getLinkedCamLayer(job, index)
        ret = json.loads(ret)['paras']['result']
        return ret
    except Exception as e:
        print(e)
    return ' '


def autoDrillBelts(job: str, step: str) -> bool:
    try:
        ret = base.autoDrillBelts(job, step)
        ret = json.loads(ret)['status']
        if ret == 'true':
            ret = True
        else:
            ret = False
        return ret
    except Exception as e:
        print(e)
    return False


def saveStackup(job: str, stackup: dict) -> bool:
    try:
        stackupInfo = stackup
        ret = base.saveStackup(job, stackupInfo)
        ret = json.loads(ret)['status']
        if ret == 'true':
            ret = True
        else:
            ret = False
        return ret
    except Exception as e:
        print(e)
    return False


def getStackup(job: str) -> dict:
    try:
        _ret = base.getStackup(job)
        ret = json.loads(_ret)['paras']['result']
        return ret
    except Exception as e:
        print(e)
    return {}


def addStackupSegment(job: str, params: dict, index: int) -> bool:
    try:
        stackupParams = params
        ret = base.addStackupSegment(job, index, stackupParams)
        ret = json.loads(ret)['paras']['result']
        return ret
    except Exception as e:
        print(e)
    return False


def deleteStackupSegment(job: str, index: int) -> bool:
    try:
        ret = base.deleteStackupSegment(job, index)
        ret = json.loads(ret)['paras']['result']
        return ret
    except Exception as e:
        print(e)
    return False


def updateStackupSegment(job: str, index: int, params: dict) -> bool:
    try:
        updateParams = params
        ret = base.updateStackupSegment(job, index, updateParams)
        ret = json.loads(ret)['paras']['result']
        return ret
    except Exception as e:
        print(e)
    return False


def clearStackup(job: str) -> bool:
    try:
        _ret = base.clearStackup(job)
        ret = json.loads(_ret)['status']
        if ret == 'true':
            ret = True
        else:
            ret = False
        return ret
    except Exception as e:
        print(e)
    return False
