import json

from deepKernel import base


def openJob(job: str, path: str) -> bool:
    try:
        ret = json.loads(base.openJob(path, job))['paras']['status']
        return ret
    except Exception as e:
        print(e)
        return False


def fileIdentify(path: str) -> dict:
    try:
        ret = base.fileIdentify(path)
        data = json.loads(ret)
        if 'paras' in data:
            return data['paras']
        return {}
    except Exception as e:
        print(f"fileIdentify 异常: {e}")
        return {}


def fileTranslate(path: str, job: str, step: str, layer: str, param: dict) -> bool:
    try:
        file_format = param['format']
        if file_format == 'Gerber274x' or file_format == 'Excellon2' or file_format == 'DXF' or (
                file_format == 'Excellon1'):
            ret = base.fileTranslate(path, job, step, layer, param, {}, {}, [])
            data = json.loads(ret)
            if 'paras' in data:
                if 'result' in data['paras']:
                    return data['paras']['result']
    except Exception as e:
        print(f"fileTranslate 异常: {e}")
        return False
    return False
