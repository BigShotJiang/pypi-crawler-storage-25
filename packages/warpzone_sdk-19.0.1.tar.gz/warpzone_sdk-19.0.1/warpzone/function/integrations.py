import os
from typing import Optional

import azure.functions as func
import datazone as dz
import pandas as pd
from azure.identity import DefaultAzureCredential
from azure.servicebus import ServiceBusClient, ServiceBusMessage

from warpzone.blobstorage.client import BlobData, WarpzoneBlobClient
from warpzone.enums.topicenum import Topic
from warpzone.servicebus.data.client import DataMessage, WarpzoneDataClient
from warpzone.servicebus.events.client import EventMessage, WarpzoneEventClient

# Singletons for clients and credentials. Azure SDK clients hold network
# resources (AMQP connections, HTTP transports, background threads) and must
# be reused across invocations. Use ``close_clients()`` for deterministic
# shutdown (e.g. between tests or on worker exit).
_credential: Optional[DefaultAzureCredential] = None
_sb_client: Optional[ServiceBusClient] = None
_data_client: Optional[WarpzoneDataClient] = None
_event_client: Optional[WarpzoneEventClient] = None
_archive_client: Optional[WarpzoneBlobClient] = None
_db_client: Optional[dz.DatabaseClient] = None


def _get_credential() -> DefaultAzureCredential:
    global _credential
    if _credential is None:
        _credential = DefaultAzureCredential()
    return _credential


def get_sb_client() -> ServiceBusClient:
    global _sb_client
    if _sb_client is None:
        service_bus_namespace = os.environ["SERVICE_BUS_NAMESPACE"]
        _sb_client = ServiceBusClient(
            fully_qualified_namespace=(
                f"{service_bus_namespace}.servicebus.windows.net"
            ),
            credential=_get_credential(),
        )
    return _sb_client


def get_data_client() -> WarpzoneDataClient:
    global _data_client
    if _data_client is None:
        _data_client = WarpzoneDataClient.from_resource_names(
            storage_account=os.environ["MESSAGE_STORAGE_ACCOUNT"],
            service_bus_namespace=os.environ["SERVICE_BUS_NAMESPACE"],
            credential=_get_credential(),
        )
    return _data_client


def get_event_client() -> WarpzoneEventClient:
    global _event_client
    if _event_client is None:
        _event_client = WarpzoneEventClient.from_resource_name(
            os.environ["SERVICE_BUS_NAMESPACE"], credential=_get_credential()
        )
    return _event_client


def get_db_client() -> dz.DatabaseClient:
    global _db_client
    if _db_client is None:
        _db_client = dz.DatabaseClient.from_resource_name(
            os.environ["OPERATIONAL_DATA_STORAGE_ACCOUNT"],
        )
    return _db_client


def get_archive_client() -> WarpzoneBlobClient:
    global _archive_client
    if _archive_client is None:
        _archive_client = WarpzoneBlobClient.from_resource_name(
            os.environ["ARCHIVE_STORAGE_ACCOUNT"], _get_credential()
        )
    return _archive_client


def close_clients() -> None:
    """Close all cached clients and reset module-level singletons.

    Best-effort: never raises. Safe to call multiple times.
    """
    global _credential, _sb_client, _data_client, _event_client
    global _archive_client, _db_client

    for client in (
        _sb_client,
        _data_client,
        _event_client,
        _archive_client,
        _db_client,
        _credential,
    ):
        if client is None:
            continue
        close = getattr(client, "close", None)
        if callable(close):
            try:
                close()
            except Exception:
                pass

    _credential = None
    _sb_client = None
    _data_client = None
    _event_client = None
    _archive_client = None
    _db_client = None


def func_msg_to_event(msg: func.ServiceBusMessage) -> EventMessage:
    event_msg = EventMessage.from_func_msg(msg)
    return event_msg


def func_msg_to_data(msg: func.ServiceBusMessage) -> DataMessage:
    data_client = get_data_client()
    event_msg = func_msg_to_event(msg)
    data_msg = data_client.event_to_data(event_msg)
    return data_msg


def func_msg_to_pandas(msg: func.ServiceBusMessage) -> pd.DataFrame:
    data_msg = func_msg_to_data(msg)
    return data_msg.to_pandas()


def send_func_msg(msg: ServiceBusMessage, topic: Topic):
    sb_client = get_sb_client()
    with sb_client.get_topic_sender(topic.value) as sender:
        sender.send_messages(message=msg)


def send_event(event_msg: EventMessage, topic: Topic) -> None:
    event_client = get_event_client()
    event_client.send(
        topic=topic,
        event_msg=event_msg,
    )


def send_data(data_msg: DataMessage, topic: Topic) -> None:
    data_client = get_data_client()
    data_client.send(
        topic=topic,
        data_msg=data_msg,
    )


def send_pandas(
    df: pd.DataFrame, topic: Topic, subject: str, schema: Optional[dict] = None
) -> None:
    data_msg = DataMessage.from_pandas(df, subject, schema=schema)
    send_data(data_msg, topic)


def upload_blob(blob_data: BlobData, container_name: str) -> None:
    blob_client = get_archive_client()
    blob_client.upload(container_name=container_name, blob_data=blob_data)
