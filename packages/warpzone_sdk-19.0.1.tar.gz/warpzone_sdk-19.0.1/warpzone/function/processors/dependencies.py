import datazone as dz

from warpzone.function import integrations
from warpzone.monitor import logs, traces

tracer = traces.get_tracer(__name__)
logger = logs.get_logger(__name__)


class DependencyProcessor:
    """Pre-processing dependency binding"""

    return_type: object = None

    def process(self, value):
        return value

    def initialize(self, value):
        return value

    def finalize(self, value):
        pass


class DeltaDatabaseDependency(DependencyProcessor):
    return_type = dz.DatabaseClient

    def initialize(self, value):
        db = integrations.get_db_client()
        return db
