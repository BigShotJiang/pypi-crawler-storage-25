from abc import ABC, abstractmethod
from typing import Any, Iterable

import azure.functions as func
import typeguard
from azure.servicebus import ServiceBusMessage

from warpzone.blobstorage.client import BlobData
from warpzone.enums.topicenum import Topic
from warpzone.function import integrations
from warpzone.servicebus.data.client import DataMessage
from warpzone.servicebus.events.client import EventMessage


def _as_iter(value: Any) -> Iterable[Any]:
    """Wrap ``value`` in a single-element list unless it's already iterable."""
    return value if isinstance(value, Iterable) else [value]


class OutputProcessor(ABC):
    """Post-processing output binding for a single returned value.

    Subclasses implement :meth:`process` over the value as-is.
    """

    return_type = None

    @abstractmethod
    def process(self, value: Any) -> Any:
        ...


class CollectionOutputProcessor(OutputProcessor, ABC):
    """Post-processing output binding for an iterable of returned values.

    Subclasses implement :meth:`process_values` over an iterable. A single
    returned value is normalized into a 1-element iterable, so subclasses
    never need to special-case the two shapes. ``None`` / empty output is
    accepted (allows intentional function breaks).
    """

    def process(self, value: Any) -> Any:
        if not value:
            return

        return self.process_values(_as_iter(value))

    @abstractmethod
    def process_values(self, values: Iterable[Any]) -> Any:
        ...


class BlobOutput(CollectionOutputProcessor):
    def __init__(self, container_name: str):
        typeguard.check_type(container_name, str)
        self.container_name = container_name


class MessageOutput(CollectionOutputProcessor):
    def __init__(self, topic: Topic):
        typeguard.check_type(topic, Topic)
        self.topic = topic

    def process_values(self, msgs: Iterable[ServiceBusMessage]) -> None:
        with integrations.get_sb_client().get_topic_sender(self.topic.value) as sender:
            for msg in msgs:
                sender.send_messages(message=msg)


class DataMessageOutput(MessageOutput):
    def process_values(self, data_msgs: Iterable[DataMessage]) -> None:
        integrations.get_data_client().send_many(self.topic, data_msgs)


class EventMessageOutput(MessageOutput):
    def process_values(self, event_msgs: Iterable[EventMessage]) -> None:
        integrations.get_event_client().send_many(self.topic, event_msgs)


class HttpOutput(OutputProcessor):
    return_type = func.HttpResponse

    def process(self, resp: func.HttpResponse) -> func.HttpResponse:
        return resp


class ArchiveBlobDataOutput(BlobOutput):
    def process_values(self, blob_data_collection: Iterable[BlobData]) -> None:
        for blob_data in blob_data_collection:
            integrations.upload_blob(blob_data, self.container_name)


class NoneOutput(OutputProcessor):
    def process(self, value: Any) -> None:
        return None
