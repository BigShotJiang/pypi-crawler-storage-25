"""Integration tests for Tempo charge intent against a real node.

Requires TEMPO_RPC_URL to be set. Run with:
    TEMPO_RPC_URL=http://localhost:8545 pytest -m integration -v
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta

import httpx
import pytest

from mpp import Challenge
from mpp.errors import VerificationError
from mpp.methods.tempo import ChargeIntent, TempoAccount, tempo
from mpp.methods.tempo._attribution import encode as encode_attribution
from mpp.methods.tempo._rpc import get_tx_params
from tests import INTEGRATION, TEST_REALM, make_credential
from tests.conftest import _fund_account

pytestmark = [pytest.mark.integration, INTEGRATION]


def _future_expires() -> str:
    return (datetime.now(UTC) + timedelta(hours=1)).isoformat().replace("+00:00", "Z")


async def _send_transfer(
    rpc_url: str,
    payer,
    currency: str,
    recipient_addr: str,
    amount: int,
    memo: str | None = None,
) -> str:
    from pytempo import Call, TempoTransaction

    cid, nonce, gas_price = await get_tx_params(rpc_url, payer.address)

    to_padded = recipient_addr[2:].lower().zfill(64)
    amount_padded = hex(amount)[2:].zfill(64)
    if memo is not None:
        selector = "95777d59"
        memo_clean = memo[2:] if memo.startswith("0x") else memo
        data = f"0x{selector}{to_padded}{amount_padded}{memo_clean.lower()}"
    else:
        selector = "a9059cbb"
        data = f"0x{selector}{to_padded}{amount_padded}"

    tx = TempoTransaction.create(
        chain_id=cid,
        gas_limit=500_000,
        max_fee_per_gas=gas_price,
        max_priority_fee_per_gas=gas_price,
        nonce=nonce,
        nonce_key=0,
        fee_token=currency,
        calls=(Call.create(to=currency, value=0, data=data),),
    )
    signed = tx.sign(payer.private_key)
    raw_tx = "0x" + signed.encode().hex()

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            rpc_url,
            json={
                "jsonrpc": "2.0",
                "method": "eth_sendRawTransaction",
                "params": [raw_tx],
                "id": 1,
            },
        )
        result = resp.json()
        if "error" in result:
            raise RuntimeError(f"RPC error: {result['error']}")
        tx_hash = result["result"]

    await _wait_for_receipt(rpc_url, tx_hash)
    return tx_hash


async def _wait_for_receipt(
    rpc_url: str, tx_hash: str, max_attempts: int = 30, delay: float = 1.0
) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        for _ in range(max_attempts):
            resp = await client.post(
                rpc_url,
                json={
                    "jsonrpc": "2.0",
                    "method": "eth_getTransactionReceipt",
                    "params": [tx_hash],
                    "id": 1,
                },
            )
            result = resp.json().get("result")
            if result is not None:
                if result.get("status") != "0x1":
                    raise RuntimeError(f"Transaction reverted: {tx_hash}")
                return result
            await asyncio.sleep(delay)
    raise RuntimeError(f"Receipt not found after {max_attempts} attempts: {tx_hash}")


class TestChargeIntegration:
    async def test_create_credential_builds_real_tx(
        self, rpc_url, funded_payer, funded_recipient, currency, chain_id
    ):
        method = tempo(
            account=funded_payer,
            chain_id=chain_id,
            rpc_url=rpc_url,
            intents={"charge": ChargeIntent()},
        )
        challenge = Challenge(
            id="integ-create-cred",
            method="tempo",
            intent="charge",
            request={
                "amount": "1000000",
                "currency": currency,
                "recipient": funded_recipient.address,
                "expires": _future_expires(),
            },
        )

        credential = await method.create_credential(challenge)

        assert credential.payload["type"] == "transaction"
        assert credential.payload["signature"].startswith("0x76")
        assert funded_payer.address in credential.source

    async def test_verify_transaction_credential(
        self, rpc_url, funded_payer, funded_recipient, currency, charge_intent, chain_id
    ):
        method = tempo(
            account=funded_payer,
            chain_id=chain_id,
            rpc_url=rpc_url,
            intents={"charge": ChargeIntent()},
        )
        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
            "methodDetails": {
                "feePayer": False,
                "chainId": chain_id,
            },
        }
        challenge = Challenge(
            id="integ-verify-tx",
            method="tempo",
            intent="charge",
            request=request_dict,
            expires=expires,
        )

        credential = await method.create_credential(challenge)
        receipt = await charge_intent.verify(credential, request_dict)

        assert receipt.status == "success"
        assert receipt.reference.startswith("0x")
        assert len(receipt.reference) >= 66

    async def test_verify_hash_credential(
        self, rpc_url, funded_payer, funded_recipient, currency, charge_intent
    ):
        challenge_id = "test-hash-cred"
        memo = encode_attribution(challenge_id=challenge_id, server_id=TEST_REALM)
        tx_hash = await _send_transfer(
            rpc_url, funded_payer, currency, funded_recipient.address, 1000000, memo=memo
        )

        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
        }
        credential = make_credential(
            payload={"type": "hash", "hash": tx_hash},
            challenge_id=challenge_id,
            expires=expires,
        )
        receipt = await charge_intent.verify(credential, request_dict)

        assert receipt.status == "success"
        assert receipt.reference == tx_hash

    async def test_verify_hash_rejects_plain_transfer_without_challenge_bound_memo(
        self, rpc_url, funded_payer, funded_recipient, currency, charge_intent
    ):
        challenge_id = "test-hash-no-memo"
        tx_hash = await _send_transfer(
            rpc_url, funded_payer, currency, funded_recipient.address, 1000000
        )

        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
        }
        credential = make_credential(
            payload={"type": "hash", "hash": tx_hash},
            challenge_id=challenge_id,
            expires=expires,
        )

        with pytest.raises(VerificationError, match="memo is not bound to this challenge"):
            await charge_intent.verify(credential, request_dict)

    async def test_verify_hash_rejects_wrong_challenge_binding(
        self, rpc_url, funded_payer, funded_recipient, currency, charge_intent
    ):
        challenge_id = "test-hash-wrong-binding"
        tx_hash = await _send_transfer(
            rpc_url,
            funded_payer,
            currency,
            funded_recipient.address,
            1000000,
            memo=encode_attribution(challenge_id="different-challenge", server_id=TEST_REALM),
        )

        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
        }
        credential = make_credential(
            payload={"type": "hash", "hash": tx_hash},
            challenge_id=challenge_id,
            expires=expires,
        )

        with pytest.raises(VerificationError, match="memo is not bound to this challenge"):
            await charge_intent.verify(credential, request_dict)

    async def test_verify_rejects_insufficient_transfer(
        self, rpc_url, funded_payer, funded_recipient, currency, charge_intent
    ):
        tx_hash = await _send_transfer(
            rpc_url, funded_payer, currency, funded_recipient.address, 100
        )

        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
        }
        credential = make_credential(payload={"type": "hash", "hash": tx_hash}, expires=expires)

        with pytest.raises(VerificationError):
            await charge_intent.verify(credential, request_dict)

    async def test_verify_rejects_wrong_recipient(
        self, rpc_url, funded_payer, currency, charge_intent
    ):
        tx_hash = await _send_transfer(
            rpc_url, funded_payer, currency, funded_payer.address, 1000000
        )

        wrong_recipient = "0x0000000000000000000000000000000000000001"
        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": wrong_recipient,
            "expires": expires,
        }
        credential = make_credential(payload={"type": "hash", "hash": tx_hash}, expires=expires)

        with pytest.raises(VerificationError):
            await charge_intent.verify(credential, request_dict)

    async def test_verify_premium_charge(
        self, rpc_url, funded_payer, funded_recipient, currency, charge_intent, chain_id
    ):
        premium_amount = "900000000"
        method = tempo(
            account=funded_payer,
            chain_id=chain_id,
            rpc_url=rpc_url,
            intents={"charge": ChargeIntent()},
        )
        expires = _future_expires()
        request_dict = {
            # The dev faucet funds exactly 1_000_000_000 units, and gas is paid
            # in the same token. Leave headroom so the payment can settle.
            "amount": premium_amount,
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
            "methodDetails": {
                "feePayer": False,
                "chainId": chain_id,
            },
        }
        challenge = Challenge(
            id="integ-premium",
            method="tempo",
            intent="charge",
            request=request_dict,
            expires=expires,
        )

        credential = await method.create_credential(challenge)
        receipt = await charge_intent.verify(credential, request_dict)

        assert receipt.status == "success"
        assert receipt.method == "tempo"
        assert receipt.reference.startswith("0x")
        assert len(receipt.reference) >= 66

    async def test_e2e_charge_with_fee_payer(
        self, rpc_url, funded_payer, funded_recipient, currency, chain_id
    ):
        fee_payer_account = TempoAccount.from_key("0x" + __import__("os").urandom(32).hex())
        _fund_account(rpc_url, fee_payer_account.address, currency)

        intent = ChargeIntent(rpc_url=rpc_url)
        tempo(
            chain_id=chain_id,
            rpc_url=rpc_url,
            fee_payer=fee_payer_account,
            intents={"charge": intent},
        )

        client_method = tempo(
            account=funded_payer,
            chain_id=chain_id,
            rpc_url=rpc_url,
            intents={"charge": ChargeIntent()},
        )

        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
            "methodDetails": {
                "feePayer": True,
                "chainId": chain_id,
            },
        }
        challenge = Challenge(
            id="integ-fee-payer",
            method="tempo",
            intent="charge",
            request=request_dict,
            expires=expires,
        )

        credential = await client_method.create_credential(challenge)
        receipt = await intent.verify(credential, request_dict)

        assert receipt.status == "success"
        assert receipt.method == "tempo"
        assert receipt.reference.startswith("0x")
        assert len(receipt.reference) >= 66

    async def test_verify_with_server_memo(
        self, rpc_url, funded_payer, funded_recipient, currency, charge_intent, chain_id
    ):
        """When server specifies memo, client should use
        transferWithMemo and server should verify."""
        memo = "0x" + "ab" * 32

        method = tempo(
            account=funded_payer,
            chain_id=chain_id,
            rpc_url=rpc_url,
            intents={"charge": ChargeIntent()},
        )
        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
            "methodDetails": {
                "feePayer": False,
                "chainId": chain_id,
                "memo": memo,
            },
        }
        challenge = Challenge(
            id="integ-memo",
            method="tempo",
            intent="charge",
            request=request_dict,
            expires=expires,
        )

        credential = await method.create_credential(challenge)
        receipt = await charge_intent.verify(credential, request_dict)

        assert receipt.status == "success"
        assert receipt.reference.startswith("0x")

    async def test_verify_rejects_wrong_memo(
        self, rpc_url, funded_payer, funded_recipient, currency, charge_intent, chain_id
    ):
        """Server should reject when tx has wrong memo."""
        client_memo = "0x" + "ab" * 32
        server_memo = "0x" + "cd" * 32

        method = tempo(
            account=funded_payer,
            chain_id=chain_id,
            rpc_url=rpc_url,
            intents={"charge": ChargeIntent()},
        )
        expires = _future_expires()

        # Client builds tx with client_memo
        challenge = Challenge(
            id="integ-wrong-memo",
            method="tempo",
            intent="charge",
            request={
                "amount": "1000000",
                "currency": currency,
                "recipient": funded_recipient.address,
                "expires": expires,
                "methodDetails": {
                    "feePayer": False,
                    "chainId": chain_id,
                    "memo": client_memo,
                },
            },
            expires=expires,
        )
        credential = await method.create_credential(challenge)

        # Server verifies with server_memo — should reject
        server_request = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
            "methodDetails": {
                "feePayer": False,
                "chainId": chain_id,
                "memo": server_memo,
            },
        }
        with pytest.raises(VerificationError, match="no matching payment call found"):
            await charge_intent.verify(credential, server_request)

    async def test_default_memo_accepted_when_server_omits_memo(
        self, rpc_url, funded_payer, funded_recipient, currency, charge_intent, chain_id
    ):
        """Auto-generated attribution memos should still verify without a server memo."""
        method = tempo(
            account=funded_payer,
            chain_id=chain_id,
            rpc_url=rpc_url,
            intents={"charge": ChargeIntent()},
        )
        expires = _future_expires()
        # Server request has NO memo — client will default one via encode_attribution
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
            "methodDetails": {
                "feePayer": False,
                "chainId": chain_id,
            },
        }
        challenge = Challenge(
            id="integ-default-memo",
            method="tempo",
            intent="charge",
            request=request_dict,
            realm="test.local",
            expires=expires,
        )

        credential = await method.create_credential(challenge)
        receipt = await charge_intent.verify(credential, request_dict)

        assert receipt.status == "success"
        assert receipt.reference.startswith("0x")

    async def test_verify_hash_replay_rejected_with_store(
        self, rpc_url, funded_payer, funded_recipient, currency
    ):
        """Same hash submitted twice with a store should fail the second time."""
        from mpp.store import MemoryStore

        challenge_id = "test-hash-replay-store"
        memo = encode_attribution(challenge_id=challenge_id, server_id=TEST_REALM)
        tx_hash = await _send_transfer(
            rpc_url, funded_payer, currency, funded_recipient.address, 1000000, memo=memo
        )

        store = MemoryStore()
        intent = ChargeIntent(rpc_url=rpc_url, store=store)

        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
        }
        credential = make_credential(
            payload={"type": "hash", "hash": tx_hash},
            challenge_id=challenge_id,
            expires=expires,
        )

        receipt = await intent.verify(credential, request_dict)
        assert receipt.status == "success"

        with pytest.raises(VerificationError, match="Transaction hash already used"):
            await intent.verify(credential, request_dict)

    async def test_verify_hash_replay_allowed_without_store(
        self, rpc_url, funded_payer, funded_recipient, currency
    ):
        """Same hash submitted twice without a store should succeed both times."""
        challenge_id = "test-hash-replay-no-store"
        memo = encode_attribution(challenge_id=challenge_id, server_id=TEST_REALM)
        tx_hash = await _send_transfer(
            rpc_url, funded_payer, currency, funded_recipient.address, 1000000, memo=memo
        )

        intent = ChargeIntent(rpc_url=rpc_url)  # no store

        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
        }
        credential = make_credential(
            payload={"type": "hash", "hash": tx_hash},
            challenge_id=challenge_id,
            expires=expires,
        )

        receipt1 = await intent.verify(credential, request_dict)
        assert receipt1.status == "success"
        receipt2 = await intent.verify(credential, request_dict)
        assert receipt2.status == "success"

    async def test_verify_hash_store_records_on_success(
        self, rpc_url, funded_payer, funded_recipient, currency
    ):
        """After successful verification, the hash should be recorded in the store."""
        from mpp.store import MemoryStore

        challenge_id = "test-hash-store-records"
        memo = encode_attribution(challenge_id=challenge_id, server_id=TEST_REALM)
        tx_hash = await _send_transfer(
            rpc_url, funded_payer, currency, funded_recipient.address, 1000000, memo=memo
        )

        store = MemoryStore()
        intent = ChargeIntent(rpc_url=rpc_url, store=store)

        store_key = f"mpp:charge:{tx_hash.lower()}"
        assert await store.get(store_key) is None

        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
        }
        credential = make_credential(
            payload={"type": "hash", "hash": tx_hash},
            challenge_id=challenge_id,
            expires=expires,
        )
        await intent.verify(credential, request_dict)

        assert await store.get(store_key) is not None

    async def test_verify_hash_tx_not_found(
        self, rpc_url, funded_recipient, currency, charge_intent
    ):
        """A fabricated hash that doesn't exist on-chain should be rejected."""
        bogus_hash = "0x" + "00" * 32

        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
        }
        credential = make_credential(payload={"type": "hash", "hash": bogus_hash}, expires=expires)

        with pytest.raises(VerificationError, match="Transaction not found"):
            await charge_intent.verify(credential, request_dict)

    async def test_verify_external_id_propagated(
        self, rpc_url, funded_payer, funded_recipient, currency, chain_id
    ):
        """externalId in request should be parseable and not break verification."""
        method = tempo(
            account=funded_payer,
            chain_id=chain_id,
            rpc_url=rpc_url,
            intents={"charge": ChargeIntent()},
        )
        expires = _future_expires()
        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
            "externalId": "order-42",
            "methodDetails": {
                "feePayer": False,
                "chainId": chain_id,
            },
        }
        challenge = Challenge(
            id="integ-ext-id",
            method="tempo",
            intent="charge",
            request=request_dict,
            expires=expires,
        )

        credential = await method.create_credential(challenge)
        intent = ChargeIntent(rpc_url=rpc_url)
        receipt = await intent.verify(credential, request_dict)

        assert receipt.status == "success"
        assert receipt.reference.startswith("0x")

    async def test_fee_payer_wrong_recipient_rejected(
        self, rpc_url, funded_payer, funded_recipient, currency, chain_id
    ):
        fee_payer_account = TempoAccount.from_key("0x" + __import__("os").urandom(32).hex())
        _fund_account(rpc_url, fee_payer_account.address, currency)

        intent = ChargeIntent(rpc_url=rpc_url)
        tempo(
            chain_id=chain_id,
            rpc_url=rpc_url,
            fee_payer=fee_payer_account,
            intents={"charge": intent},
        )

        wrong_recipient = "0x0000000000000000000000000000000000000001"
        expires = _future_expires()

        client_method = tempo(
            account=funded_payer,
            chain_id=chain_id,
            rpc_url=rpc_url,
            intents={"charge": ChargeIntent()},
        )
        challenge = Challenge(
            id="integ-fee-payer-wrong",
            method="tempo",
            intent="charge",
            request={
                "amount": "1000000",
                "currency": currency,
                "recipient": wrong_recipient,
                "expires": expires,
                "methodDetails": {
                    "feePayer": True,
                    "chainId": chain_id,
                },
            },
            expires=expires,
        )
        credential = await client_method.create_credential(challenge)

        request_dict = {
            "amount": "1000000",
            "currency": currency,
            "recipient": funded_recipient.address,
            "expires": expires,
            "methodDetails": {
                "feePayer": True,
                "chainId": chain_id,
            },
        }

        with pytest.raises(VerificationError):
            await intent.verify(credential, request_dict)
