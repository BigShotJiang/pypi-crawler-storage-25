"""JSON → dataclass conversion helpers shared across resource modules."""

from __future__ import annotations

from datetime import date, datetime, timezone
from decimal import Decimal

from mboek.models._enums import (
    AutoBookingActieType,
    AutoBookingBedragType,
    BoekingStatus,
    BoekjaarStatus,
    BtwAangifteStatus,
    BtwSoort,
    DagboekType,
    Regeltype,
    RekeningCategorie,
    RekeningType,
)
from mboek.models.administraties import Administratie
from mboek.models.auth import AuthToken, CurrentUser
from mboek.models.auto_booking_rules import AutoBookingRule, AutoBookingRuleLine
from mboek.models.boekingen import Boeking, Boekingsregel
from mboek.models.boekjaren import Boekjaar
from mboek.models.btw_aangifte import BtwAangifte, BtwBerekening, RubriekBedragen
from mboek.models.btw_codes import BtwCode
from mboek.models.dagboeken import Dagboek, DagboekWerkStatus
from mboek.models.export_import import (
    AdministratieExport,
    AdministratieImportResult,
    BoekingenImportResult,
    BoekingExport,
    BoekjaarExport,
    BoekjaarImportResult,
    ImportResult,
    MatchSuggestion,
)
from mboek.models.grootboekrekeningen import GrootboekMutatie, Grootboekrekening
from mboek.models.maintenance import VacuumResult
from mboek.models.reports import (
    BalansRegel,
    BalansReport,
    WinstVerliesRegel,
    WinstVerliesReport,
)


def _require_object(payload: object, *, response_name: str) -> dict:
    if not isinstance(payload, dict):
        raise ValueError(f"{response_name} response must be a JSON object")
    return payload


def _dt(s: str | None) -> datetime | None:
    if s is None:
        return None
    # ISO-8601 with optional trailing Z
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def _date(s: str | None) -> date | None:
    if s is None:
        return None
    return date.fromisoformat(s)


def _cents(v: int | None) -> Decimal | None:
    if v is None:
        return None
    return Decimal(v) / 100


def _require_dt(s: str | None) -> datetime:
    value = _dt(s)
    if value is None:
        raise ValueError("Expected datetime value")
    return value


def _require_date(s: str | None) -> date:
    value = _date(s)
    if value is None:
        raise ValueError("Expected date value")
    return value


def _require_cents(v: int | None) -> Decimal:
    value = _cents(v)
    if value is None:
        raise ValueError("Expected amount in cents")
    return value


def parse_login(d: dict) -> AuthToken:
    for key in ("token", "gebruikersnaam", "expires_at"):
        if key not in d:
            raise ValueError(f"Login response missing required key: {key!r}")
    return AuthToken(
        token=d["token"],
        gebruikersnaam=d["gebruikersnaam"],
        expires_at=datetime.fromtimestamp(d["expires_at"], tz=timezone.utc),
    )


def parse_current_user(payload: object) -> CurrentUser:
    d = _require_object(payload, response_name="Current user")
    for key in ("gebruikersnaam", "sub"):
        if key not in d:
            raise ValueError(f"Current user response missing required key: {key!r}")
    return CurrentUser(
        gebruikersnaam=d["gebruikersnaam"],
        sub=d["sub"],
    )


def parse_administratie(d: dict) -> Administratie:
    return Administratie(
        id=d["id"],
        naam=d["naam"],
        beschrijving=d.get("beschrijving"),
        kvk_nummer=d.get("kvk_nummer"),
        btw_nummer=d.get("btw_nummer"),
        adres=d.get("adres"),
        active=d.get("active", True),
        huidig_boekjaar_id=d.get("huidig_boekjaar_id"),
        bankimport_rekening_id=d.get("bankimport_rekening_id"),
        created_at=_require_dt(d["created_at"]),
        updated_at=_require_dt(d["updated_at"]),
    )


def parse_boekjaar(d: dict, *, client=None) -> Boekjaar:
    return Boekjaar(
        id=d["id"],
        administratie_id=d["administratie_id"],
        naam=d["naam"],
        start_datum=_require_date(d["start_datum"]),
        eind_datum=_require_date(d["eind_datum"]),
        status=BoekjaarStatus(d["status"]),
        created_at=_require_dt(d["created_at"]),
        updated_at=_require_dt(d["updated_at"]),
        client=client,
    )


def parse_dagboek(d: dict, *, client=None, boekjaar_id=None) -> Dagboek:
    if client is not None:
        client._dagboek_admin_cache[d["id"]] = d["administratie_id"]
    return Dagboek(
        id=d["id"],
        administratie_id=d["administratie_id"],
        code=d["code"],
        naam=d["naam"],
        dagboek_type=DagboekType(d["dagboek_type"]),
        grootboekrekening_id=d.get("grootboekrekening_id"),
        iban=d.get("iban"),
        created_at=_require_dt(d["created_at"]),
        updated_at=_require_dt(d["updated_at"]),
        client=client,
        boekjaar_id=boekjaar_id,
    )


def parse_werkstatus(d: dict) -> DagboekWerkStatus:
    return DagboekWerkStatus(
        dagboek_id=d["dagboek_id"],
        onverwerkt=d["onverwerkt"],
        te_bevestigen=d["te_bevestigen"],
    )


def parse_grootboekrekening(
    d: dict, *, client=None, boekjaar_id=None
) -> Grootboekrekening:
    return Grootboekrekening(
        id=d["id"],
        administratie_id=d["administratie_id"],
        code=d["code"],
        naam=d["naam"],
        rekening_type=RekeningType(d["rekening_type"]),
        categorie=RekeningCategorie(d["categorie"]),
        rgs_code=d.get("rgs_code"),
        parent_id=d.get("parent_id"),
        default_btw_id=d.get("default_btw_id"),
        actief=d.get("actief", True),
        created_at=_require_dt(d["created_at"]),
        updated_at=_require_dt(d["updated_at"]),
        client=client,
        boekjaar_id=boekjaar_id,
    )


def parse_grootboekrekening_met_saldo(
    d: dict, *, client=None, boekjaar_id=None
) -> Grootboekrekening:
    rekening_data = d.get("rekening", d)
    return Grootboekrekening(
        id=rekening_data["id"],
        administratie_id=rekening_data["administratie_id"],
        code=rekening_data["code"],
        naam=rekening_data["naam"],
        rekening_type=RekeningType(rekening_data["rekening_type"]),
        categorie=RekeningCategorie(rekening_data["categorie"]),
        rgs_code=rekening_data.get("rgs_code"),
        parent_id=rekening_data.get("parent_id"),
        default_btw_id=rekening_data.get("default_btw_id"),
        actief=rekening_data.get("actief", True),
        created_at=_require_dt(rekening_data["created_at"]),
        updated_at=_require_dt(rekening_data["updated_at"]),
        client=client,
        boekjaar_id=boekjaar_id,
        saldo=_require_cents(d["saldo"]),
        aantal_transacties=d["aantal_transacties"],
    )


def parse_grootboek_mutatie(d: dict) -> GrootboekMutatie:
    return GrootboekMutatie(
        regel_id=d["regel_id"],
        boeking_id=d["boeking_id"],
        dagboek_id=d["dagboek_id"],
        dagboek_type=DagboekType(d["dagboek_type"]),
        datum=_require_date(d["datum"]),
        dagboek_code=d["dagboek_code"],
        dagboek_naam=d["dagboek_naam"],
        boeking_omschrijving=d["boeking_omschrijving"],
        regel_omschrijving=d["regel_omschrijving"],
        bedrag=_require_cents(d["bedrag"]),
    )


def parse_btw_code(d: dict) -> BtwCode:
    return BtwCode(
        id=d["id"],
        administratie_id=d["administratie_id"],
        code=d["code"],
        omschrijving=d["omschrijving"],
        percentage=Decimal(str(d["percentage"])),
        soort=BtwSoort(d["soort"]),
        output_rekening_id=d.get("output_rekening_id"),
        input_rekening_id=d.get("input_rekening_id"),
        pct_aftrek=Decimal(str(d["pct_aftrek"])),
        actief=d.get("actief", True),
        created_at=_require_dt(d["created_at"]),
        updated_at=_require_dt(d["updated_at"]),
    )


def parse_boekingsregel(d: dict) -> Boekingsregel:
    return Boekingsregel(
        id=d["id"],
        boeking_id=d["boeking_id"],
        grootboekrekening_id=d["grootboekrekening_id"],
        omschrijving=d.get("omschrijving", ""),
        bedrag=_require_cents(d["bedrag"]),
        btw_code_id=d.get("btw_code_id"),
        regeltype=Regeltype(d["regeltype"]),
        netto_id=d.get("netto_id"),
        created_at=_require_dt(d["created_at"]),
    )


def parse_boeking_met_regels(d: dict, *, client=None, administratie_id=None) -> Boeking:
    resolved_admin_id = administratie_id
    if resolved_admin_id is None and client is not None:
        resolved_admin_id = client._dagboek_admin_cache.get(d["dagboek_id"])
    if resolved_admin_id is not None and client is not None:
        client._dagboek_admin_cache[d["dagboek_id"]] = resolved_admin_id
    return Boeking(
        id=d["id"],
        dagboek_id=d["dagboek_id"],
        boekjaar_id=d["boekjaar_id"],
        datum=_require_date(d["datum"]),
        omschrijving=d.get("omschrijving", ""),
        stuknummer=d.get("stuknummer"),
        status=BoekingStatus(d.get("status", "concept")),
        tegenpartij_naam=d.get("tegenpartij_naam"),
        tegenpartij_iban=d.get("tegenpartij_iban"),
        referentie_import=d.get("referentie_import"),
        import_hash=d.get("import_hash"),
        auto_geboekt=d.get("auto_geboekt", False),
        gecontroleerd=d.get("gecontroleerd", False),
        regels=[parse_boekingsregel(r) for r in d.get("regels", [])],
        created_at=_require_dt(d["created_at"]),
        updated_at=_require_dt(d["updated_at"]),
        client=client,
        administratie_id=resolved_admin_id,
    )


def _parse_rubriek(d: dict) -> RubriekBedragen:
    return RubriekBedragen(
        grondslag=Decimal(str(d["grondslag"])),
        btw=Decimal(str(d["btw"])),
    )


def parse_btw_berekening(d: dict) -> BtwBerekening:
    return BtwBerekening(
        r1a=_parse_rubriek(d["r1a"]),
        r1b=_parse_rubriek(d["r1b"]),
        r1c=_parse_rubriek(d["r1c"]),
        r1d=_parse_rubriek(d["r1d"]),
        r1e=_parse_rubriek(d["r1e"]),
        r2a=_parse_rubriek(d["r2a"]),
        r3a=_parse_rubriek(d["r3a"]),
        r3b=_parse_rubriek(d["r3b"]),
        r3c=_parse_rubriek(d["r3c"]),
        r4a=_parse_rubriek(d["r4a"]),
        r4b=_parse_rubriek(d["r4b"]),
        r5a=Decimal(str(d["r5a"])),
        r5b=Decimal(str(d["r5b"])),
        r5g=Decimal(str(d["r5g"])),
    )


def parse_btw_aangifte(d: dict) -> BtwAangifte:
    return BtwAangifte(
        id=d["id"],
        administratie_id=d["administratie_id"],
        boekjaar_id=d["boekjaar_id"],
        kwartaal=d["kwartaal"],
        periode_start=_require_date(d["periode_start"]),
        periode_eind=_require_date(d["periode_eind"]),
        berekening=parse_btw_berekening(d["berekening"]),
        r5g=Decimal(str(d["r5g"])),
        status=BtwAangifteStatus(d["status"]),
    )


def parse_auto_booking_rule_line(d: dict) -> AutoBookingRuleLine:
    return AutoBookingRuleLine(
        id=d["id"],
        rule_id=d["rule_id"],
        tegenrekening_id=d["tegenrekening_id"],
        btw_code_id=d.get("btw_code_id"),
        omschrijving=d.get("omschrijving"),
        bedrag_type=AutoBookingBedragType(d["bedrag_type"]),
        bedrag=_cents(d["bedrag"]) if d.get("bedrag") is not None else None,
    )


def parse_auto_booking_rule(d: dict) -> AutoBookingRule:
    return AutoBookingRule(
        id=d["id"],
        administratie_id=d["administratie_id"],
        naam=d["naam"],
        prioriteit=d["prioriteit"],
        actief=d["actief"],
        actie_type=AutoBookingActieType(d["actie_type"]),
        btw_code_id=d.get("btw_code_id"),
        iban_eigen=d.get("iban_eigen"),
        iban_tegenpartij=d.get("iban_tegenpartij"),
        omschrijving_regex=d.get("omschrijving_regex"),
        tegenrekening_id=d.get("tegenrekening_id"),
        lines=[parse_auto_booking_rule_line(ln) for ln in d.get("lines", [])],
        created_at=_require_dt(d["created_at"]),
        updated_at=_require_dt(d["updated_at"]),
    )


def _parse_balans_regel(d: dict) -> BalansRegel:
    return BalansRegel(
        code=d["code"],
        naam=d["naam"],
        debet=Decimal(str(d["debet"])),
        credit=Decimal(str(d["credit"])),
        saldo=Decimal(str(d["saldo"])),
    )


def parse_balans(d: dict) -> BalansReport:
    return BalansReport(
        boekjaar_naam=d["boekjaar_naam"],
        activa=[_parse_balans_regel(r) for r in d["activa"]],
        passiva=[_parse_balans_regel(r) for r in d["passiva"]],
        totaal_activa=Decimal(str(d["totaal_activa"])),
        totaal_passiva=Decimal(str(d["totaal_passiva"])),
        in_balans=d["in_balans"],
    )


def _parse_winst_verlies_regel(d: dict) -> WinstVerliesRegel:
    return WinstVerliesRegel(
        code=d["code"],
        naam=d["naam"],
        bedrag=Decimal(str(d["bedrag"])),
    )


def parse_winst_verlies(d: dict) -> WinstVerliesReport:
    return WinstVerliesReport(
        boekjaar_naam=d["boekjaar_naam"],
        opbrengsten=[_parse_winst_verlies_regel(r) for r in d["opbrengsten"]],
        kosten=[_parse_winst_verlies_regel(r) for r in d["kosten"]],
        bijzonder=[_parse_winst_verlies_regel(r) for r in d["bijzonder"]],
        totaal_opbrengsten=Decimal(str(d["totaal_opbrengsten"])),
        totaal_kosten=Decimal(str(d["totaal_kosten"])),
        totaal_bijzonder=Decimal(str(d["totaal_bijzonder"])),
        netto_resultaat=Decimal(str(d["netto_resultaat"])),
    )


def parse_import_result(d: dict) -> ImportResult:
    return ImportResult(
        imported=d["imported"],
        duplicates_skipped=d["duplicates_skipped"],
        zero_bedrag_skipped=d["zero_bedrag_skipped"],
        boekjaar_niet_gevonden_skipped=d["boekjaar_niet_gevonden_skipped"],
        auto_geboekt=d["auto_geboekt"],
        unmatched_ibans=d["unmatched_ibans"],
        parse_warnings=d.get("parse_warnings"),
    )


def parse_administratie_export(payload: object) -> AdministratieExport:
    d = _require_object(payload, response_name="Administratie export")
    return AdministratieExport.from_dict(d)


def parse_boekjaar_export(payload: object) -> BoekjaarExport:
    d = _require_object(payload, response_name="Boekjaar export")
    return BoekjaarExport.from_dict(d)


def parse_boeking_export(payload: object) -> BoekingExport:
    d = _require_object(payload, response_name="Boeking export")
    return BoekingExport.from_dict(d)


def parse_administratie_import_result(payload: object) -> AdministratieImportResult:
    d = _require_object(payload, response_name="Administratie import")
    for key in ("administratie_id", "naam", "boekingen_imported"):
        if key not in d:
            raise ValueError(
                f"Administratie import response missing required key: {key!r}"
            )
    return AdministratieImportResult(
        administratie_id=d["administratie_id"],
        naam=d["naam"],
        boekingen_imported=d["boekingen_imported"],
    )


def parse_boekjaar_import_result(payload: object) -> BoekjaarImportResult:
    d = _require_object(payload, response_name="Boekjaar import")
    for key in ("boekjaar_id", "naam", "boekingen_imported"):
        if key not in d:
            raise ValueError(f"Boekjaar import response missing required key: {key!r}")
    return BoekjaarImportResult(
        boekjaar_id=d["boekjaar_id"],
        naam=d["naam"],
        boekingen_imported=d["boekingen_imported"],
    )


def parse_boekingen_import_result(d: dict) -> BoekingenImportResult:
    return BoekingenImportResult(
        dagboek_id=d["dagboek_id"],
        boekingen_imported=d["boekingen_imported"],
    )


def parse_match_suggestion(d: dict) -> MatchSuggestion:
    return MatchSuggestion(
        contra_rekening_id=d["contra_rekening_id"],
        contra_rekening_code=d["contra_rekening_code"],
        contra_rekening_naam=d["contra_rekening_naam"],
        confidence=d["confidence"],
        reason=d["reason"],
    )


def parse_vacuum_result(payload: object) -> VacuumResult:
    d = _require_object(payload, response_name="Vacuum")
    if "message" not in d:
        raise ValueError("Vacuum response missing required key: 'message'")
    elapsed_ms = d.get("elapsed_ms")
    if elapsed_ms is not None and not isinstance(elapsed_ms, int):
        raise ValueError("Vacuum response field 'elapsed_ms' must be an int")
    return VacuumResult(
        message=d["message"],
        elapsed_ms=elapsed_ms,
    )
