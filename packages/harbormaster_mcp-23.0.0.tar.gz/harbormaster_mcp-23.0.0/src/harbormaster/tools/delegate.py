"""delegate_task MCP tool — delegates work to a project's Claude Code subagent.

The caller (agent A) authorises edits via ``allow_writes`` and chooses
between blocking (``mode="sync"``, default) and fire-and-forget
(``mode="async"``) execution. Async jobs land in a SQLite-backed
JobStore; agent A retrieves the result with ``get_delegated_task`` (or,
in v22.0.0a3+, ``recall_pending_results``).
"""
from __future__ import annotations

from typing import Literal

from mcp.server.fastmcp import FastMCP

from harbormaster.config import HarbormasterConfig
from harbormaster.tools._grounding import build_grounded_prompt
from harbormaster.tools._helpers import run_backend

_READ_ONLY_SUFFIX = (
    "Read-only mode. Do NOT edit files. "
    "Report what you would do and which files you would touch. "
    "Return markdown under 500 words."
)

_WRITES_SUFFIX = (
    "You may edit files in this project. Make the change directly, "
    "then return a markdown summary under 500 words listing: "
    "(1) files changed with one-line reasons, "
    "(2) any new tests added, "
    "(3) follow-ups left for the operator. "
    "Do NOT git commit — the operator will review and commit."
)


def register(mcp: FastMCP, config: HarbormasterConfig) -> None:
    @mcp.tool()
    def delegate_task(
        name: str,
        task: str,
        deliverable: str,
        allow_writes: bool = False,
        host: str | None = None,
        model: str | None = None,
        mode: Literal["sync", "async"] = "sync",
        inbox_id: str = "default",
        max_turns: int = 10,
    ) -> str:
        """Delegate a task to a project's Claude Code subagent.

        ``allow_writes`` is the caller's authorisation. ``False`` (default)
        renders a read-only prompt: the subagent is told not to edit files
        and to return a plan instead. ``True`` renders a writes-allowed
        prompt: the subagent edits files directly and returns a summary of
        what changed. The underlying ``--permission-mode bypassPermissions``
        flag is unchanged in both modes; the prompt is what gates behaviour.

        ``mode`` controls blocking vs fire-and-forget:

        - ``"sync"`` (default) blocks until the subagent finishes, then
          returns the result string — same shape as v22.0.0a1.
        - ``"async"`` enqueues the task in the JobStore, returns a
          handle string of the form ``"queued <job_id> (inbox=<id>)"``,
          and lets a background worker run it. Poll status with
          ``get_delegated_task(job_id)`` or fetch completed results
          with ``recall_pending_results(inbox_id)`` (v22.0.0a3+).

        ``inbox_id`` groups async jobs for ``recall_pending_results``;
        it has no effect when ``mode="sync"``.

        When ``[history] auto_ground = true``, the task description is
        prepended with a "Prior context" section listing the top-K past
        Q&A matches for this project.

        ``model`` is an optional alias ('haiku', 'sonnet', 'opus') or full
        model id; ``None`` = backend default. Subject to
        ``[backends.<name>] allowed_models`` whitelist when set.

        SSH/remote writes share the same gate — if ``host`` is set and
        ``allow_writes=True``, the subagent edits files on the remote host
        and the operator is responsible for pulling/diffing those changes.

        ``max_turns`` (v22.0.1) caps how many tool-use turns the
        subagent gets before ``claude -p`` exits. Default 10 matches
        the historical hardcoded value — fine for short read-only
        questions. Non-trivial writes (multi-file edits, tests,
        commit) typically need 30-80 turns; set explicitly per call
        rather than guessing. Hitting the cap surfaces as
        ``code=exit_nonzero: claude -p exit 1: (no stderr)`` because
        the subagent reaches ``max_turns_reached`` before producing
        a final result.
        """
        if mode == "async":
            # Late import to break the tools.delegate ↔ jobs.worker
            # ↔ tools._grounding circular path. The async subsystem
            # touches tool-helper modules at construction time.
            from harbormaster.jobs import get_subsystem
            sub = get_subsystem(config)
            job = sub.store.enqueue(
                project=name,
                host=host,
                task=task,
                deliverable=deliverable,
                allow_writes=allow_writes,
                model=model,
                inbox_id=inbox_id,
                max_turns=max_turns,
            )
            return (
                f"queued {job.id} (inbox={job.inbox_id}). "
                f"Poll with get_delegated_task({job.id!r}) or fetch "
                f"completed results with recall_pending_results("
                f"inbox_id={job.inbox_id!r})."
            )

        # mode == "sync" — existing v22.0.0a1 behaviour.
        grounded = build_grounded_prompt(
            question=f"{task}\n\nDeliverable: {deliverable}",
            project=name,
            host=host,
            config=config,
        )
        suffix = _WRITES_SUFFIX if allow_writes else _READ_ONLY_SUFFIX
        full_prompt = f"{grounded}\n\n{suffix}"
        return run_backend(
            name=name,
            prompt=full_prompt,
            max_turns=max_turns,
            host=host,
            config=config,
            label_prefix="delegate",
            model=model,
        )
