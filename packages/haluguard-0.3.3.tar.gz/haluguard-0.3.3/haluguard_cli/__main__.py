"""haluguard CLI — entry point.

Usage:
    haluguard auth login              # paste your token, save to ~/.haluguard/config.json
    haluguard auth logout
    haluguard auth status

    haluguard check FILE              # verify a file
    haluguard check                   # verify stdin
    haluguard check --json            # raw JSON output (for scripts)
    haluguard check --threshold 0.7   # exit non-zero if score >= 0.7

    haluguard version
    haluguard help

Env vars:
    HALUGUARD_TOKEN     — overrides config (used in CI/CD)
    HALUGUARD_API_URL   — defaults to https://api.haluguard.com (override for self-host/dev)

Exit codes:
    0    clean / no hallucinations above threshold
    1    hallucinations detected at or above threshold
    2    transient API error (rate-limited, 5xx)
    3    auth error (401/403)
    4    bad input / usage
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import urllib.error
import urllib.request


__version__ = "0.3.3"

DEFAULT_API_URL = "https://api.haluguard.com"
CONFIG_DIR  = Path.home() / ".haluguard"
CONFIG_FILE = CONFIG_DIR / "config.json"


# ---------- ANSI colors (auto-disable on non-TTY / NO_COLOR) ----------

def _supports_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    return sys.stdout.isatty()

def _c(code: str, text: str) -> str:
    if not _supports_color():
        return text
    return f"\033[{code}m{text}\033[0m"

def red(s):    return _c("31", s)
def green(s):  return _c("32", s)
def yellow(s): return _c("33", s)
def gray(s):   return _c("90", s)
def bold(s):   return _c("1", s)


# ---------- Config storage ----------

def load_config() -> dict:
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text())
    except Exception:  # noqa: BLE001
        return {}

def save_config(cfg: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))
    try:
        CONFIG_FILE.chmod(0o600)
    except Exception:  # noqa: BLE001
        pass

def resolve_token() -> str | None:
    return os.environ.get("HALUGUARD_TOKEN") or load_config().get("token")

def resolve_api_url() -> str:
    return (
        os.environ.get("HALUGUARD_API_URL")
        or load_config().get("api_url")
        or DEFAULT_API_URL
    ).rstrip("/")


# ---------- HTTP ----------

def call_check(text: str, user_prompt: str | None = None,
               token: str | None = None, api_url: str | None = None,
               timeout: float = 60.0, source: str = "cli") -> dict:
    payload = json.dumps({"text": text, "user_prompt": user_prompt}).encode("utf-8")
    req = urllib.request.Request(
        f"{api_url or resolve_api_url()}/v1/check",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token or resolve_token() or ''}",
            "User-Agent": f"haluguard-cli/{__version__}",
            "X-Haluguard-Source": source,   # cli | hook | ci | github-action
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        try:
            j = json.loads(body)
            detail = j.get("detail") or body
        except Exception:  # noqa: BLE001
            detail = body
        if e.code in (401, 403):
            sys.stderr.write(red(f"auth error ({e.code}): {detail}\n"))
            sys.stderr.write(gray("Run `haluguard auth login` or set HALUGUARD_TOKEN.\n"))
            sys.exit(3)
        if e.code == 429 or 500 <= e.code < 600:
            sys.stderr.write(yellow(f"transient API error ({e.code}): {detail}\n"))
            sys.exit(2)
        sys.stderr.write(red(f"API error ({e.code}): {detail}\n"))
        sys.exit(2)
    except urllib.error.URLError as e:
        sys.stderr.write(red(f"connection error: {e.reason}\n"))
        sys.exit(2)


# ---------- Hook commands (auto-verify Claude Code responses) ----------

CLAUDE_SETTINGS_PATH = Path.home() / ".claude" / "settings.json"


def _read_claude_settings() -> dict:
    if not CLAUDE_SETTINGS_PATH.exists():
        return {}
    try:
        return json.loads(CLAUDE_SETTINGS_PATH.read_text())
    except Exception:  # noqa: BLE001
        return {}


def _write_claude_settings(cfg: dict) -> None:
    CLAUDE_SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    CLAUDE_SETTINGS_PATH.write_text(json.dumps(cfg, indent=2) + "\n")


_HALUGUARD_HOOK_MARKER = "haluguard-stop-hook"  # used to find & remove later


def _haluguard_hook_entry(mode: str, threshold: float) -> dict:
    """A single hook entry Claude Code will execute on Stop."""
    return {
        "type": "command",
        "command": (
            f"haluguard hook-stop --mode={mode} --threshold={threshold}"
        ),
        # tag we can detect on uninstall
        "name": _HALUGUARD_HOOK_MARKER,
    }


def cmd_hook_install(args) -> int:
    """Wire haluguard into Claude Code's Stop hook so every response is auto-verified."""
    if not resolve_token():
        sys.stderr.write(red("Not logged in. Run `haluguard auth login` first.\n"))
        return 3

    cfg = _read_claude_settings()
    hooks = cfg.setdefault("hooks", {})
    stop_list = hooks.setdefault("Stop", [])

    # Remove any prior haluguard hook (idempotent)
    new_stop_list = []
    for entry in stop_list:
        sub = entry.get("hooks", []) if isinstance(entry, dict) else []
        sub = [h for h in sub if h.get("name") != _HALUGUARD_HOOK_MARKER]
        if sub:
            entry["hooks"] = sub
            new_stop_list.append(entry)
        elif not isinstance(entry, dict) or "hooks" not in entry:
            new_stop_list.append(entry)
    stop_list[:] = new_stop_list

    # Add ours
    stop_list.append({
        "matcher": "",   # all stops
        "hooks": [_haluguard_hook_entry(args.mode, args.threshold)],
    })

    _write_claude_settings(cfg)

    print(green("✓ haluguard Stop hook installed."))
    print(f"  config:    {CLAUDE_SETTINGS_PATH}")
    print(f"  mode:      {args.mode}")
    print(f"  threshold: {args.threshold}")
    print()
    print(gray("Restart Claude Code (cmd+Q then reopen) for the hook to take effect."))
    print(gray("Every response Claude generates will be auto-verified by haluguard."))
    return 0


def cmd_hook_uninstall(args) -> int:
    cfg = _read_claude_settings()
    hooks = cfg.get("hooks", {})
    stop_list = hooks.get("Stop", [])
    removed = 0
    new_stop_list = []
    for entry in stop_list:
        if not isinstance(entry, dict):
            new_stop_list.append(entry); continue
        sub = entry.get("hooks", [])
        before = len(sub)
        sub = [h for h in sub if h.get("name") != _HALUGUARD_HOOK_MARKER]
        removed += before - len(sub)
        if sub:
            entry["hooks"] = sub
            new_stop_list.append(entry)
    if "Stop" in hooks:
        hooks["Stop"] = new_stop_list
        if not hooks["Stop"]:
            del hooks["Stop"]
    _write_claude_settings(cfg)
    print(green(f"✓ Removed {removed} haluguard hook entries."))
    print(gray("Restart Claude Code for the change to take effect."))
    return 0


def cmd_hook_status(args) -> int:
    cfg = _read_claude_settings()
    hooks = cfg.get("hooks", {})
    stop_list = hooks.get("Stop", [])
    n = sum(
        1
        for entry in stop_list
        if isinstance(entry, dict)
        for h in entry.get("hooks", [])
        if h.get("name") == _HALUGUARD_HOOK_MARKER
    )
    if n:
        print(green(f"✓ haluguard Stop hook is INSTALLED ({n} entry)."))
        print(gray(f"  config: {CLAUDE_SETTINGS_PATH}"))
    else:
        print(yellow("haluguard Stop hook is NOT installed."))
        print(gray("Run `haluguard hook install` to enable auto-verification."))
    return 0


def cmd_hook_stop(args) -> int:
    """Called by Claude Code on the Stop event.

    Receives a JSON object on stdin: {session_id, transcript_path, ...}.
    We read the last assistant message from the transcript and verify it.

    Behaviors per `--mode`:
      - correct (default): on hallucinations, emit JSON decision=block with
                           detailed feedback. Claude reformulates the response
                           correcting the flagged claims.
      - warn             : print warning to stderr, never block.
      - block            : exit 2 (terminates the turn with an error message).
    """
    # Read hook payload from stdin
    try:
        raw = sys.stdin.read()
        payload = json.loads(raw) if raw.strip() else {}
    except Exception:  # noqa: BLE001
        return 0   # don't break Claude Code on parse error

    transcript_path = payload.get("transcript_path")
    if not transcript_path or not Path(transcript_path).exists():
        return 0

    # Find the most recent assistant message in the JSONL transcript
    last_text = _extract_last_assistant_text(Path(transcript_path))
    if not last_text or len(last_text.strip()) < 40:
        return 0  # too short to be worth verifying

    # Cap input size for cost / latency
    text = last_text[:4000]

    if not resolve_token():
        return 0  # silent no-op if not authed

    try:
        response = call_check(text, timeout=20.0, source="hook")
    except SystemExit:
        return 0  # call_check exits on auth/transient errors — never break the user
    except Exception:  # noqa: BLE001
        return 0

    verdict = response.get("verdict")
    score = float(response.get("score") or 0)
    severity = response.get("severity_tier") or ""
    n_h = response.get("n_hallucinations", 0)
    n_c = response.get("n_claims", 0)

    is_hallu = verdict == "hallucinations_found"
    above_threshold = score >= args.threshold

    if not is_hallu or not above_threshold:
        return 0  # quiet pass

    # Build a structured correction prompt that Claude can act on
    findings = response.get("findings") or []
    flagged = [f for f in findings if (f.get("verdict") or "").upper() == "CONTRADICTED"]

    summary = (
        f"haluguard flagged {n_h}/{n_c} claims (severity={severity}, score={score:.2f})"
    )

    # If we have NO specific CONTRADICTED findings, we can't cite an
    # authoritative source. Two sub-cases:
    #
    # (1) Score is moderate (above threshold but not "very high"): the signal
    #     is mostly probabilistic. Better to warn silently and let the response
    #     through — pushing Claude to "revise" without bullets produces worse
    #     output than the original.
    #
    # (2) Score is very high (≥ soft_revise_threshold) AND verdict is
    #     hallucinations_found: the meta-detector (LLM-judge / pattern detector)
    #     is confident the output is speculative or fabricated even though no
    #     verifier could pin a specific claim. Typical cases: invented TAM
    #     numbers, "the market is $5B" without a source, future predictions
    #     stated as facts. Here we DO want Claude to revise — but toward
    #     honest hedging, not toward citing a (non-existent) authoritative
    #     correction. We call this "soft-revise" mode.
    if not flagged:
        verdict_source = response.get("verdict_source") or ""
        soft_threshold = getattr(args, "soft_revise_threshold", 0.85)

        if args.mode == "correct" and score >= soft_threshold:
            reason = (
                f"{summary}.\n\n"
                f"haluguard flagged this as likely fabricated content but "
                f"could not pin a specific claim to an authoritative source "
                f"(verdict_source: {verdict_source}). This typically means the "
                f"output contains speculative numbers, invented statistics, "
                f"market sizes, or future predictions stated with unwarranted "
                f"confidence.\n\n"
                f"Please revise your previous response so that:\n"
                f"  1. Specific numbers/statistics you can't cite from a "
                f"     concrete source become explicit ranges with uncertainty "
                f"     markers (e.g. \"roughly $1–5B, very uncertain\"), or are "
                f"     replaced with an honest \"I don't have verified data on "
                f"     X\".\n"
                f"  2. Where the user could realistically check real data, "
                f"     point them to specific authoritative sources (analyst "
                f"     reports — Gartner/IDC/Grand View, regulatory filings — "
                f"     SEC EDGAR, official statistics agencies, peer-reviewed "
                f"     papers, etc.).\n"
                f"  3. Drop confident framings (\"the market is $5B\", "
                f"     \"this will happen by 2030\") for any claim you cannot "
                f"     ground. Use hedging language: \"estimated\", "
                f"     \"reportedly\", \"I'm not certain\".\n\n"
                f"Add a short visible callout at the TOP of the revised "
                f"response so the user knows the original was flagged:\n\n"
                f"  > ⚠️ haluguard: original response flagged as speculative. "
                f"Replaced unverified specifics with ranges + sources.\n\n"
                f"Keep the rest of the structure. Do not invent new facts. "
                f"If you cannot ground a claim, state the uncertainty "
                f"explicitly rather than making a number up."
            )
            out = {"decision": "block", "reason": reason}
            sys.stdout.write(json.dumps(out))
            return 0

        # Below soft threshold → keep the existing warn-only behavior
        sys.stderr.write(
            f"⚠️  {summary}\n"
            f"   verdict_source: {verdict_source}\n"
            f"   (no specific contradictions to cite — passed through as warning only)\n"
        )
        return 0

    # Build accionable bullets
    bullet_lines = []
    for f in flagged[:5]:
        v = f.get("verifier") or ""
        claim = (f.get("claim") or "").strip()
        ev = (f.get("evidence") or "").strip()
        fix = (f.get("suggested_correction") or "").strip()
        src = f.get("source_url") or ""
        bullet = f"- Claim: \"{claim}\"\n  Source ({v}): {ev}"
        if fix:
            bullet += f"\n  Correct value: {fix}"
        if src:
            bullet += f"\n  Reference: {src}"
        bullet_lines.append(bullet)
    bullets = "\n".join(bullet_lines)

    if args.mode == "correct":
        # JSON output with decision=block + reason → Claude Code re-prompts the
        # assistant with this reason as additional context. Claude then revises
        # the response, removing or correcting the flagged claims.
        #
        # We also instruct Claude to add a visible callout to the user so they
        # SEE what haluguard caught — silent corrections are a UX trap (user
        # can't tell whether the tool helped or whether the model was right
        # the first time).
        reason = (
            f"{summary}.\n\n"
            f"Please revise your previous response. Remove or correct the "
            f"following claims that conflict with authoritative sources:\n\n"
            f"{bullets}\n\n"
            f"After revising, add a short visible callout at the TOP of your "
            f"revised response so the user sees exactly what was corrected. "
            f"Use this exact format (one line per correction):\n\n"
            f"  > ⚠️ haluguard corrected: \"<original claim>\" → "
            f"\"<correct value>\" (source: <verifier or url>)\n\n"
            f"Keep the callout short and factual. Do not apologize or hedge. "
            f"After the callout, continue with the rest of the corrected "
            f"response normally. Do not invent new facts. If you cannot verify "
            f"a claim, omit it."
        )
        out = {"decision": "block", "reason": reason}
        sys.stdout.write(json.dumps(out))
        return 0

    if args.mode == "block":
        sys.stderr.write(summary + "\n" + bullets + "\n")
        return 2

    # warn mode — surface but don't block
    sys.stderr.write("⚠️  " + summary + "\n" + bullets + "\n")
    return 0


def _extract_last_assistant_text(transcript_path: Path) -> str:
    """Read the JSONL transcript and return the most recent assistant text."""
    try:
        lines = transcript_path.read_text(errors="ignore").splitlines()
    except Exception:  # noqa: BLE001
        return ""
    for raw_line in reversed(lines):
        try:
            entry = json.loads(raw_line)
        except Exception:  # noqa: BLE001
            continue
        # Claude Code transcript entries vary; try common shapes
        msg = entry.get("message") or entry
        if msg.get("role") != "assistant":
            continue
        content = msg.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            chunks = []
            for c in content:
                if isinstance(c, dict) and c.get("type") == "text":
                    chunks.append(c.get("text", ""))
            if chunks:
                return "\n".join(chunks)
    return ""


# ---------- Commands ----------

def cmd_auth_login(args) -> int:
    if args.token:
        token = args.token
    else:
        sys.stderr.write("Paste your haluguard API token (starts with hg_live_): ")
        sys.stderr.flush()
        token = sys.stdin.readline().strip()
    if not token.startswith("hg_"):
        sys.stderr.write(red("That doesn't look like a haluguard token.\n"))
        return 4
    cfg = load_config()
    cfg["token"] = token
    save_config(cfg)
    print(green(f"✓ Token saved to {CONFIG_FILE}"))
    return 0

def cmd_auth_logout(args) -> int:
    cfg = load_config()
    if cfg.pop("token", None) is None:
        print(gray("No token was saved."))
        return 0
    save_config(cfg)
    print(green("✓ Logged out (token removed)."))
    return 0

def cmd_auth_status(args) -> int:
    token = resolve_token()
    if not token:
        print(red("Not logged in. Run `haluguard auth login`."))
        return 3
    masked = token[:12] + "…" + token[-4:]
    print(green(f"Logged in. Token: {masked}"))
    print(gray(f"API: {resolve_api_url()}"))
    return 0

def cmd_check(args) -> int:
    if args.file == "-" or args.file is None:
        if sys.stdin.isatty() and args.file is None:
            sys.stderr.write(yellow("No input file or stdin. Pipe text or pass a file.\n"))
            sys.stderr.write(gray("Examples:\n"))
            sys.stderr.write(gray("  haluguard check report.md\n"))
            sys.stderr.write(gray('  echo "Microsoft was founded in 1981" | haluguard check\n'))
            return 4
        text = sys.stdin.read()
    else:
        p = Path(args.file)
        if not p.exists():
            sys.stderr.write(red(f"File not found: {p}\n"))
            return 4
        text = p.read_text()

    text = text.strip()
    if not text:
        sys.stderr.write(yellow("Empty input.\n"))
        return 4

    if not resolve_token():
        sys.stderr.write(red("Not logged in. Run `haluguard auth login` or set HALUGUARD_TOKEN.\n"))
        return 3

    response = call_check(text, user_prompt=args.user_prompt)

    if args.json:
        print(json.dumps(response, indent=2))
    else:
        _print_human_report(response)

    score = float(response.get("score") or 0)
    is_hallu = response.get("verdict") == "hallucinations_found"
    if args.threshold is not None:
        return 1 if score >= args.threshold else 0
    return 1 if is_hallu else 0

def _print_human_report(r: dict) -> None:
    is_hallu = r.get("verdict") == "hallucinations_found"
    tier = r.get("severity_tier") or "—"
    score = r.get("score", 0)
    n_h = r.get("n_hallucinations", 0)
    n_c = r.get("n_claims", 0)
    dur = r.get("duration_ms", 0)
    src = r.get("verdict_source") or ""

    head = red("✗ HALLUCINATIONS") if is_hallu else green("✓ CLEAN")
    print(f"{bold(head)}    severity={tier}  score={score:.2f}  claims={n_h}/{n_c}  latency={int(dur)}ms")
    if src:
        print(gray(f"verdict source: {src}"))
    print()

    findings = r.get("findings") or []
    if not findings:
        print(gray("No findings."))
        return

    for f in findings:
        verdict = (f.get("verdict") or "").upper()
        if verdict == "CONTRADICTED":
            label = red(f"[{verdict}]")
        elif verdict == "GROUNDED":
            label = green(f"[{verdict}]")
        else:
            label = gray(f"[{verdict}]")
        sev = f.get("severity") or ""
        sev_str = f" {sev}" if sev else ""
        verifier = f.get("verifier") or ""
        print(f"  {label}{sev_str} {gray('· ' + verifier)}")
        print(f"    {bold('claim:')}    {f.get('claim') or ''}")
        if f.get("evidence"):
            print(f"    {bold('evidence:')} {f.get('evidence')}")
        if f.get("source_url"):
            print(f"    {bold('source:')}   {gray(f.get('source_url'))}")
        if f.get("suggested_correction"):
            print(f"    {bold('fix:')}      {f.get('suggested_correction')}")
        print()


# ---------- Arg parser ----------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="haluguard",
        description="Verify LLM output for hallucinations from your terminal or CI/CD.",
    )
    p.add_argument("--version", action="version", version=f"haluguard {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    # check
    pc = sub.add_parser("check", help="Verify text from a file or stdin.")
    pc.add_argument("file", nargs="?", default=None, help="File path, or '-' for stdin (default: stdin).")
    pc.add_argument("--user-prompt", default=None, help="Optional user prompt that produced the text.")
    pc.add_argument("--json", action="store_true", help="Output raw JSON.")
    pc.add_argument("--threshold", type=float, default=None,
                    help="Exit 1 only if score >= THRESHOLD (default: any 'hallucinations_found' triggers exit 1).")
    pc.set_defaults(func=cmd_check)

    # hook — auto-verify Claude Code responses
    ph = sub.add_parser(
        "hook",
        help="Auto-verify every Claude Code response (install/uninstall/status).",
    )
    hook_sub = ph.add_subparsers(dest="hook_command", required=True)

    phi = hook_sub.add_parser("install",
        help="Register a Stop hook in ~/.claude/settings.json so every Claude response is checked.")
    phi.add_argument("--mode", choices=["correct", "warn", "block"], default="correct",
        help=("correct (default): force Claude to revise the response correcting flagged claims; "
              "warn: surface findings but let it pass; "
              "block: hard-stop the turn with an error."))
    phi.add_argument("--threshold", type=float, default=0.7,
        help="Only act on responses with score >= THRESHOLD (default: 0.7).")
    phi.set_defaults(func=cmd_hook_install)

    phu = hook_sub.add_parser("uninstall", help="Remove the haluguard Stop hook.")
    phu.set_defaults(func=cmd_hook_uninstall)

    phs = hook_sub.add_parser("status", help="Show whether the Stop hook is installed.")
    phs.set_defaults(func=cmd_hook_status)

    # hook-stop is the actual command Claude Code invokes (not for humans)
    phstop = sub.add_parser("hook-stop", help=argparse.SUPPRESS)
    phstop.add_argument("--mode", choices=["correct", "warn", "block"], default="correct")
    phstop.add_argument("--threshold", type=float, default=0.7)
    phstop.add_argument("--soft-revise-threshold", type=float, default=0.85,
        dest="soft_revise_threshold",
        help=("In correct mode, when no CONTRADICTED finding exists but score is "
              "≥ this threshold, ask Claude to revise toward honest hedging + "
              "cite sources instead of staying silent. Default: 0.85."))
    phstop.set_defaults(func=cmd_hook_stop)

    # auth
    pa = sub.add_parser("auth", help="Manage authentication token.")
    auth_sub = pa.add_subparsers(dest="auth_command", required=True)
    pal = auth_sub.add_parser("login", help="Save your API token locally.")
    pal.add_argument("--token", default=None, help="Pass token inline (otherwise prompts).")
    pal.set_defaults(func=cmd_auth_login)
    pao = auth_sub.add_parser("logout", help="Remove the saved token.")
    pao.set_defaults(func=cmd_auth_logout)
    pas = auth_sub.add_parser("status", help="Show whether a token is configured.")
    pas.set_defaults(func=cmd_auth_status)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
