"""Tests for QMLModel: PyTorch-style QML compute primitive."""

import math
import pytest
import torch

from qiskit.circuit import QuantumCircuit
from qiskit.quantum_info import SparsePauliOp

from qiskit_trev.qml import QMLModel
from qiskit_trev.model import TensorRingModel


def _make_circuit(n_qubits=4, n_layers=1):
    """Build a simple RY ansatz. Returns (circuit, data_indices, trainable_indices).

    Layout per layer: RY_data on each qubit, then RY_trainable on each qubit, then CNOTs.
    """
    qc = QuantumCircuit(n_qubits)
    data_indices = []
    trainable_indices = []
    param_idx = 0
    for _ in range(n_layers):
        for q in range(n_qubits):
            qc.ry(0.0, q)
            data_indices.append(param_idx)
            param_idx += 1
        for q in range(n_qubits):
            qc.ry(0.0, q)
            trainable_indices.append(param_idx)
            param_idx += 1
        for q in range(n_qubits - 1):
            qc.cx(q, q + 1)
    return qc, data_indices, trainable_indices


class TestInit:

    def test_creates_model(self):
        qc, di, ti = _make_circuit(n_qubits=3)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        assert model.n_qubits == 3
        assert model.n_trainable == len(ti)
        assert model.n_data == len(di)

    def test_precomputed_indices(self):
        """Index tensors should be precomputed at init."""
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        assert model._data_idx.shape == (len(di),)
        assert model._train_idx.shape == (len(ti),)


class TestBuildParamBatch:

    def test_shape(self):
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        X = torch.randn(5, 2)
        theta = torch.randn(len(ti))
        pb = model._build_param_batch(X, theta)
        total_params = len(di) + len(ti)
        assert pb.shape == (5, total_params)

    def test_data_placed_correctly(self):
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        X = torch.tensor([[1.0, 2.0], [3.0, 4.0]])
        theta = torch.tensor([10.0, 20.0])
        pb = model._build_param_batch(X, theta)
        for row in range(2):
            for j, idx in enumerate(di):
                assert pb[row, idx].item() == pytest.approx(X[row, j].item(), abs=1e-5)
        for j, idx in enumerate(ti):
            assert pb[0, idx].item() == pytest.approx(theta[j].item(), abs=1e-5)


class TestForward:

    def test_shape(self):
        """forward returns (n_qubits, N)."""
        qc, di, ti = _make_circuit(n_qubits=3)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        X = torch.randn(5, 3)
        theta = torch.randn(len(ti))
        evs = model(X, theta)
        assert evs.shape == (3, 5)

    def test_matches_individual_models(self):
        """Each row should match TensorRingModel with single-qubit Z."""
        n_qubits = 3
        qc, di, ti = _make_circuit(n_qubits=n_qubits)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")

        X = torch.randn(4, n_qubits)
        theta = torch.randn(len(ti))
        evs = model(X, theta)

        pb = model._build_param_batch(X, theta)
        for q in range(n_qubits):
            pauli = "I" * (n_qubits - 1 - q) + "Z" + "I" * q
            obs = SparsePauliOp.from_list([(pauli, 1.0)])
            tr_model = TensorRingModel(qc, obs, rank=4, device="cpu")
            ref = tr_model.evaluate_batch(pb)
            torch.testing.assert_close(evs[q], ref, atol=1e-5, rtol=1e-5)

    def test_single_sample(self):
        """N=1 edge case."""
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        evs = model(torch.randn(1, 2), torch.randn(len(ti)))
        assert evs.shape == (2, 1)

    def test_values_bounded(self):
        """Qubit Z expectations in [-1, 1]."""
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        evs = model(torch.randn(10, 2), torch.randn(len(ti)))
        assert evs.min() >= -1.0 - 1e-5
        assert evs.max() <= 1.0 + 1e-5


class TestParameterShiftGrad:

    def test_shape(self):
        """Returns (n_qubits, P, N)."""
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        X = torch.randn(4, 2)
        theta = torch.randn(len(ti))
        dZ = model.parameter_shift_grad(X, theta)
        assert dZ.shape == (2, len(ti), 4)

    def test_finite_difference(self):
        """dZ/dtheta should approximate finite difference."""
        n_qubits = 2
        qc, di, ti = _make_circuit(n_qubits=n_qubits)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        X = torch.randn(3, n_qubits)
        theta = torch.randn(len(ti))

        dZ = model.parameter_shift_grad(X, theta)

        eps = 1e-4
        for p in range(len(ti)):
            tp = theta.clone(); tp[p] += eps
            tm = theta.clone(); tm[p] -= eps
            evs_p = model(X, tp)
            evs_m = model(X, tm)
            fd = (evs_p - evs_m) / (2 * eps)  # (Q, N)
            torch.testing.assert_close(
                dZ[:, p, :], fd, atol=0.05, rtol=0.05,
                msg=f"param {p} gradient mismatch"
            )

    def test_single_sample(self):
        """N=1."""
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        dZ = model.parameter_shift_grad(torch.randn(1, 2), torch.randn(len(ti)))
        assert dZ.shape == (2, len(ti), 1)


class TestForwardPopulation:

    def test_shape(self):
        """Returns (n_qubits, pop_size, N)."""
        qc, di, ti = _make_circuit(n_qubits=3)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        X = torch.randn(5, 3)
        pop = torch.randn(8, len(ti))
        evs = model.forward_population(X, pop)
        assert evs.shape == (3, 8, 5)

    def test_matches_sequential(self):
        """Each candidate should match individual forward call."""
        n_qubits = 2
        qc, di, ti = _make_circuit(n_qubits=n_qubits)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        X = torch.randn(3, n_qubits)
        pop = torch.randn(4, len(ti))

        evs = model.forward_population(X, pop)

        for s in range(4):
            ref = model(X, pop[s])  # (Q, N)
            torch.testing.assert_close(
                evs[:, s, :], ref, atol=1e-5, rtol=1e-5,
                msg=f"candidate {s} mismatch"
            )

    def test_single_candidate(self):
        """pop_size=1."""
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        evs = model.forward_population(torch.randn(3, 2), torch.randn(1, len(ti)))
        assert evs.shape == (2, 1, 3)


class TestVariableBatchGrad:
    """parameter_shift_grad must handle varying N without OOM."""

    def test_varying_N_returns_correct_shape(self):
        """Calling with different N values should work and return correct shapes."""
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        theta = torch.randn(len(ti))

        # First call with small N
        dZ1 = model.parameter_shift_grad(torch.randn(5, 2), theta)
        assert dZ1.shape == (2, len(ti), 5)

        # Second call with larger N — should not reuse stale chunk size
        dZ2 = model.parameter_shift_grad(torch.randn(20, 2), theta)
        assert dZ2.shape == (2, len(ti), 20)

        # Third call back to small N
        dZ3 = model.parameter_shift_grad(torch.randn(3, 2), theta)
        assert dZ3.shape == (2, len(ti), 3)

    def test_varying_N_gradient_correctness(self):
        """Gradients should be correct regardless of previous N."""
        n_qubits = 2
        qc, di, ti = _make_circuit(n_qubits=n_qubits)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        theta = torch.randn(len(ti))

        # Call with N=5 first to populate cache
        model.parameter_shift_grad(torch.randn(5, n_qubits), theta)

        # Now call with N=10 and verify via finite difference
        X = torch.randn(10, n_qubits)
        dZ = model.parameter_shift_grad(X, theta)

        eps = 1e-4
        for p in range(len(ti)):
            tp = theta.clone(); tp[p] += eps
            tm = theta.clone(); tm[p] -= eps
            fd = (model(X, tp) - model(X, tm)) / (2 * eps)
            torch.testing.assert_close(
                dZ[:, p, :], fd, atol=0.05, rtol=0.05,
                msg=f"param {p} gradient mismatch after varying N"
            )

    def test_chunk_cache_invalidated_on_N_change(self):
        """Internal chunk cache should adapt to N, not be a single scalar."""
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        theta = torch.randn(len(ti))

        model.parameter_shift_grad(torch.randn(5, 2), theta)
        model.parameter_shift_grad(torch.randn(50, 2), theta)

        # _ps_chunk_cache should exist (replacing old _ps_chunk scalar)
        assert hasattr(model, '_ps_chunk_cache')


class TestForwardPopulationAutoTune:
    """forward_population should auto-tune batch_size if not set."""

    def test_no_manual_auto_tune_required(self):
        """forward_population should work without calling auto_tune first."""
        qc, di, ti = _make_circuit(n_qubits=3)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        # Don't call auto_tune — forward_population should handle it
        X = torch.randn(5, 3)
        pop = torch.randn(8, len(ti))
        evs = model.forward_population(X, pop)
        assert evs.shape == (3, 8, 5)

    def test_auto_tunes_on_cuda_when_batch_size_none(self):
        """On CPU batch_size stays None or gets set; on GPU it should auto-tune."""
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        assert model.batch_size is None
        X = torch.randn(3, 2)
        pop = torch.randn(4, len(ti))
        # Should still work even without auto_tune
        evs = model.forward_population(X, pop)
        assert evs.shape == (2, 4, 3)


class TestEndToEndWorkflow:
    """Verify the intended user workflow from the plan works."""

    def test_param_shift_workflow(self):
        """User-side param shift + output layer + loss computation."""
        n_qubits = 2
        N = 5
        C = 3
        qc, di, ti = _make_circuit(n_qubits=n_qubits)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")

        X = torch.randn(N, n_qubits)
        theta = torch.randn(len(ti))
        W = torch.randn(C, n_qubits, dtype=torch.float64)
        b = torch.zeros(C, dtype=torch.float64)
        y = torch.zeros(N, C, dtype=torch.float64)
        y[:, 0] = 1.0

        # Forward
        evs = model(X, theta)  # (Q, N)
        logits = torch.tanh(W @ evs + b.unsqueeze(1))  # (C, N)
        loss = ((logits.T - y) ** 2).mean()
        assert loss.item() >= 0

        # Gradient
        dl = 2 * (logits.T - y).T / (N * C) * (1 - logits ** 2)
        grad_W = dl @ evs.T
        grad_b = dl.sum(1)
        dZ = model.parameter_shift_grad(X, theta)  # (Q, P, N)
        grad_theta = torch.einsum('qn,qpn->p', W.T @ dl, dZ)

        assert grad_theta.shape == (len(ti),)
        assert grad_W.shape == (C, n_qubits)
        assert grad_b.shape == (C,)

    def test_cma_workflow(self):
        """User-side CMA-ES population evaluation workflow."""
        n_qubits = 2
        N = 4
        C = 2
        qc, di, ti = _make_circuit(n_qubits=n_qubits)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        P = len(ti)

        X = torch.randn(N, n_qubits)
        y = torch.zeros(N, C, dtype=torch.float64)
        y[:, 0] = 1.0

        pop_size = 6
        pop = torch.randn(pop_size, P + C * n_qubits + C)

        evs = model.forward_population(X, pop[:, :P])  # (Q, pop, N)

        all_W = pop[:, P:P + C * n_qubits].reshape(pop_size, C, n_qubits).double()
        all_b = pop[:, P + C * n_qubits:].double()  # (pop, C)
        logits = torch.tanh(
            torch.bmm(all_W, evs.permute(1, 0, 2).double()) + all_b.unsqueeze(-1)
        )

        costs = ((logits.permute(0, 2, 1) - y.unsqueeze(0)) ** 2).mean(dim=(1, 2))
        assert costs.shape == (pop_size,)


class TestPredict:

    def test_predict_shape(self):
        """predict() returns numpy array of class labels (lines 360-361)."""
        n_qubits = 2
        N = 6
        C = 3
        qc, di, ti = _make_circuit(n_qubits=n_qubits)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")

        X = torch.randn(N, n_qubits)
        theta = torch.randn(len(ti))
        W = torch.randn(C, n_qubits, dtype=torch.float64)
        b = torch.zeros(C, dtype=torch.float64)

        labels = model.predict(X, theta, W, b)
        assert labels.shape == (N,)
        assert all(0 <= l < C for l in labels)

    def test_predict_returns_numpy(self):
        """predict() returns a numpy array, not a tensor."""
        import numpy as np
        qc, di, ti = _make_circuit(n_qubits=2)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        X = torch.randn(4, 2)
        theta = torch.randn(len(ti))
        W = torch.randn(2, 2, dtype=torch.float64)
        b = torch.zeros(2, dtype=torch.float64)
        labels = model.predict(X, theta, W, b)
        assert isinstance(labels, np.ndarray)


class TestAutoTuneCPU:

    def test_auto_tune_cpu_sets_batch_size(self):
        """auto_tune on CPU sets batch_size = N and _ps_chunk = n_trainable (lines 109-112)."""
        n_qubits = 2
        N = 10
        qc, di, ti = _make_circuit(n_qubits=n_qubits)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        model.auto_tune(N)
        assert model.batch_size == N
        assert model._ps_chunk == len(ti)

    def test_auto_tune_cpu_does_not_change_forward(self):
        """auto_tune on CPU doesn't affect forward() results."""
        n_qubits = 2
        N = 5
        qc, di, ti = _make_circuit(n_qubits=n_qubits)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")

        X = torch.randn(N, n_qubits)
        theta = torch.randn(len(ti))
        evs_before = model(X, theta).clone()
        model.auto_tune(N)
        evs_after = model(X, theta)
        torch.testing.assert_close(evs_before, evs_after, atol=1e-5, rtol=1e-5)


class TestParameterShiftGradPresetChunk:

    def test_grad_with_preset_ps_chunk(self):
        """parameter_shift_grad with pre-set _ps_chunk bypasses auto-tuning (lines 296-313)."""
        n_qubits = 2
        N = 3
        qc, di, ti = _make_circuit(n_qubits=n_qubits)
        model = QMLModel(qc, di, ti, rank=4, device="cpu")
        # Pre-set _ps_chunk to bypass the auto_batch_size probe
        model._ps_chunk = len(ti)

        X = torch.randn(N, n_qubits)
        theta = torch.randn(len(ti))
        grad = model.parameter_shift_grad(X, theta)
        assert grad.shape == (n_qubits, len(ti), N)
