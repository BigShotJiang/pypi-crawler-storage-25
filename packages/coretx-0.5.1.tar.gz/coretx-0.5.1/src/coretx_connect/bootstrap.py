"""
Bootstrap KOs from Claude Code JSONL session logs.

Scans ~/.claude/projects/ for historical conversations and extracts
decisions, facts, preferences, and problems as KOs. Solves the cold
start problem for new users who have Claude Code history.

Usage:
    coretx-connect bootstrap           # extract and write KOs
    coretx-connect bootstrap --dry-run # show what would be written
    coretx-connect bootstrap --path /custom/path
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

from coretx_connect.server import _api_get, _api_post, API_KEY


DEFAULT_LOG_DIR = Path.home() / ".claude" / "projects"

# Patterns to detect extractable knowledge
DECISION_PATTERNS = [
    re.compile(r"(?:let's go with|we should|the plan is|I've decided|we're going to|decided to|approved|rejected)\s+(.{10,200})", re.I),
]

FACT_PATTERNS = [
    re.compile(r"(?:the (?:API|database|server|service) (?:is at|uses|runs on|is))\s+(.{5,200})", re.I),
    re.compile(r"(?:deployed (?:at|to))\s+(https?://\S+)", re.I),
    re.compile(r"(?:version|v)\s*(\d+\.\d+(?:\.\d+)?)", re.I),
]

PROBLEM_PATTERNS = [
    re.compile(r"(?:the (?:bug|issue|problem) is)\s+(.{10,200})", re.I),
    re.compile(r"(?:doesn't work|is broken|fails? (?:with|because|when))\s+(.{10,200})", re.I),
]

PREFERENCE_PATTERNS = [
    re.compile(r"(?:I prefer|always use|never do|from now on)\s+(.{5,200})", re.I),
]


def _extract_project_from_dir(dirname: str) -> str:
    """Extract project name from JSONL directory name.

    Directory format: -Users-anthony-Code-coretx-nanopub
    → /Users/anthony/Code/coretx/nanopub → "nanopub"
    """
    path = dirname.replace("-", "/")
    parts = path.rstrip("/").split("/")
    return parts[-1] if parts else ""


def _scan_jsonl(filepath: Path) -> list[dict]:
    """Scan a JSONL file for extractable knowledge."""
    found = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue

                # Only look at assistant messages (Claude's responses contain decisions/facts)
                if record.get("type") != "assistant":
                    continue

                message = record.get("message", {})
                content = message.get("content", "")
                if isinstance(content, list):
                    # Extract text from content blocks
                    content = " ".join(
                        block.get("text", "") for block in content
                        if isinstance(block, dict) and block.get("type") == "text"
                    )
                if not isinstance(content, str) or len(content) < 20:
                    continue

                timestamp = record.get("timestamp", "")

                # Check each pattern category
                for pattern in DECISION_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(1)[:80].strip().rstrip("."),
                            "predicate": "decided as",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "insight",
                            "memory_type": "semantic",
                            "tags": ["bootstrap"],
                            "timestamp": timestamp,
                        })

                for pattern in FACT_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(0)[:80].strip().rstrip("."),
                            "predicate": "established as",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "insight",
                            "memory_type": "semantic",
                            "tags": ["bootstrap"],
                            "timestamp": timestamp,
                        })

                for pattern in PROBLEM_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(1)[:80].strip().rstrip("."),
                            "predicate": "problem is",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "problem",
                            "tags": ["bootstrap"],
                            "timestamp": timestamp,
                        })

                for pattern in PREFERENCE_PATTERNS:
                    match = pattern.search(content)
                    if match:
                        found.append({
                            "subject": match.group(1)[:80].strip().rstrip("."),
                            "predicate": "preference is",
                            "object_value": match.group(0)[:300].strip(),
                            "ko_type": "insight",
                            "memory_type": "semantic",
                            "pinned": True,
                            "tags": ["bootstrap"],
                            "timestamp": timestamp,
                        })

    except Exception as e:
        print(f"  Error reading {filepath}: {e}", file=sys.stderr)

    return found


def bootstrap(log_dir: Path = DEFAULT_LOG_DIR, dry_run: bool = False) -> dict:
    """Scan Claude Code logs and extract KOs.

    Returns: {"sessions": N, "extracted": N, "written": N, "skipped": N}
    """
    if not log_dir.exists():
        print(f"Log directory not found: {log_dir}", file=sys.stderr)
        return {"sessions": 0, "extracted": 0, "written": 0, "skipped": 0}

    # Fetch existing KOs for dedup
    existing_subjects = set()
    if not dry_run and API_KEY:
        result = _api_get("list", {"limit": 500})
        for ko in result.get("kos", result.get("results", [])):
            existing_subjects.add(ko.get("subject", "").lower())

    sessions = 0
    extracted = 0
    written = 0
    skipped = 0

    for project_dir in sorted(log_dir.iterdir()):
        if not project_dir.is_dir():
            continue

        project = _extract_project_from_dir(project_dir.name)
        jsonl_files = list(project_dir.glob("*.jsonl"))

        for jsonl_file in jsonl_files:
            sessions += 1
            found = _scan_jsonl(jsonl_file)
            extracted += len(found)

            for ko in found:
                # Dedup
                if ko["subject"].lower() in existing_subjects:
                    skipped += 1
                    continue

                ko["project"] = project

                if dry_run:
                    print(f"  [{project}] {ko['ko_type']}: {ko['subject'][:60]} ({ko['predicate']})")
                    written += 1
                else:
                    result = _api_post({
                        "action": "write",
                        "subject": ko["subject"],
                        "predicate": ko["predicate"],
                        "object_value": ko["object_value"],
                        "ko_type": ko.get("ko_type", "insight"),
                        "memory_type": ko.get("memory_type", "episodic"),
                        "project": project,
                        "tags": ko.get("tags", []),
                        "pinned": ko.get("pinned", False),
                        "visibility": "private",
                    })
                    if "error" not in result:
                        written += 1
                        existing_subjects.add(ko["subject"].lower())
                    else:
                        skipped += 1

    return {"sessions": sessions, "extracted": extracted, "written": written, "skipped": skipped}


def main():
    dry_run = "--dry-run" in sys.argv
    log_path = DEFAULT_LOG_DIR

    for i, arg in enumerate(sys.argv):
        if arg == "--path" and i + 1 < len(sys.argv):
            log_path = Path(sys.argv[i + 1])

    if "--help" in sys.argv or "-h" in sys.argv:
        print("coretx-connect bootstrap [--dry-run] [--path PATH]")
        print("  Scan Claude Code logs and extract KOs for cold start.")
        print(f"  Default path: {DEFAULT_LOG_DIR}")
        return

    if not API_KEY and not dry_run:
        print("CORETX_API_KEY not set. Use --dry-run to preview without writing.", file=sys.stderr)
        sys.exit(1)

    print(f"Scanning {log_path}...")
    if dry_run:
        print("(dry run — nothing will be written)\n")

    stats = bootstrap(log_path, dry_run=dry_run)

    print(f"\nDone. Scanned {stats['sessions']} sessions, "
          f"extracted {stats['extracted']} candidates, "
          f"wrote {stats['written']} KOs, "
          f"skipped {stats['skipped']} (duplicates or errors).")


if __name__ == "__main__":
    main()
