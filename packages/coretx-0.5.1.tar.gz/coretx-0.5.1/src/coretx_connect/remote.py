"""
CoreTx Connect — Remote MCP server for claude.ai browser integration.

Wraps the same tool handlers as the local stdio server with FastMCP's
Streamable HTTP transport. Users authenticate via OAuth 2.1 and each
request carries a per-user Bearer token (npub_sk_* API key).

Usage:
    coretx-connect-remote --port 8080
    # Then in claude.ai: Add custom connector → https://mcp.coretx.ai/mcp
"""

from __future__ import annotations

import hashlib
import json
import os
import sys

from mcp.server.fastmcp import FastMCP

from coretx_connect import __version__

# Re-use tool handlers and API client from the local server
from coretx_connect import server as _server
from coretx_connect.server import (
    ko_write,
    ko_read,
    ko_search,
    ko_list,
    ko_delete,
    ko_context,
    ko_stats,
    ko_share,
    TOOLS,
    SERVER_INSTRUCTIONS,
    _request_api_key,
)

# Disable signing on the remote server — the private key would be on the
# server, not the user's device, which breaks the client-side signing
# trust model. KOs from claude.ai will be unsigned.
_server._signing_key = None
_server._signing_pub_b64 = ""
_server._signing_key_registered = False

API_URL = os.environ.get("CORETX_API_URL", "https://api.coretx.ai")
MCP_SERVER_URL = os.environ.get("MCP_SERVER_URL", "https://mcp.coretx.ai")

# ─── Server Setup ─────────────────────────────────────────────

mcp = FastMCP(
    name="CoreTx Connect",
    instructions=SERVER_INSTRUCTIONS,
    host="0.0.0.0",
    port=int(os.environ.get("PORT", "8080")),
    streamable_http_path="/mcp",
    stateless_http=True,
    json_response=True,
)

# ─── Tool Registration ────────────────────────────────────────

# Input size limit to prevent DoS via oversized payloads
MAX_STRING_LENGTH = 100_000  # 100KB per field

# Cloud tools only — local-only tools (working_memory, todos, set_context,
# session_summary) are excluded from the remote server because they require
# persistent in-process state which doesn't work in stateless HTTP mode.
TOOL_CONFIG = {
    "ko_write": {"handler": ko_write, "readOnlyHint": False, "destructiveHint": False},
    "ko_read": {"handler": ko_read, "readOnlyHint": True, "destructiveHint": False},
    "ko_search": {"handler": ko_search, "readOnlyHint": True, "destructiveHint": False},
    "ko_list": {"handler": ko_list, "readOnlyHint": True, "destructiveHint": False},
    "ko_delete": {"handler": ko_delete, "readOnlyHint": False, "destructiveHint": True},
    "ko_context": {"handler": ko_context, "readOnlyHint": True, "destructiveHint": False},
    "ko_stats": {"handler": ko_stats, "readOnlyHint": True, "destructiveHint": False},
    "ko_share": {"handler": ko_share, "readOnlyHint": False, "destructiveHint": False},
}

# Register each tool with FastMCP using low-level Tool objects
# so we can pass the original input schema (FastMCP can't infer
# parameter schemas from **kwargs wrapper functions).
from mcp.server.fastmcp.tools import Tool as FastMCPTool
from mcp.server.fastmcp.utilities.func_metadata import FuncMetadata
from mcp.types import ToolAnnotations

for tool_def in TOOLS:
    name = tool_def["name"]
    config = TOOL_CONFIG.get(name)
    if not config:
        continue

    handler = config["handler"]
    description = tool_def["description"]
    input_schema = tool_def.get("inputSchema", {})
    properties = input_schema.get("properties", {})
    required = input_schema.get("required", [])

    # Create async wrapper that validates input size and calls the handler
    def make_tool_handler(h):
        async def tool_handler(**kwargs) -> str:
            for k, v in kwargs.items():
                if isinstance(v, str) and len(v) > MAX_STRING_LENGTH:
                    return f"Error: field '{k}' exceeds maximum length ({MAX_STRING_LENGTH} chars)"
            return h(kwargs)
        return tool_handler

    async_handler = make_tool_handler(handler)

    # Build FuncMetadata that matches the original schema
    from mcp.server.fastmcp.utilities.func_metadata import ArgModelBase
    from pydantic import Field, create_model
    from typing import Optional

    arg_model_fields = {}
    for param_name, param_def in properties.items():
        if param_name in required:
            arg_model_fields[param_name] = (str, Field(description=param_def.get("description", "")))
        else:
            arg_model_fields[param_name] = (Optional[str], Field(default=None, description=param_def.get("description", "")))

    # Create a dynamic Pydantic model subclassing ArgModelBase
    arg_model = create_model(f"{name}Args", __base__=ArgModelBase, **arg_model_fields)

    func_meta = FuncMetadata(arg_model=arg_model, return_type=str)

    tool = FastMCPTool(
        fn=async_handler,
        name=name,
        description=description,
        parameters=properties,
        fn_metadata=func_meta,
        is_async=True,
        annotations=ToolAnnotations(
            readOnlyHint=config["readOnlyHint"],
            destructiveHint=config["destructiveHint"],
        ),
    )
    mcp._tool_manager._tools[name] = tool


# ─── Auth Middleware ──────────────────────────────────────────

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response


class BearerAuthMiddleware(BaseHTTPMiddleware):
    """
    Extract Bearer token from Authorization header and set as the
    per-request API key for tool calls. Returns 401 with
    WWW-Authenticate header if no token is present (triggers
    claude.ai OAuth discovery flow).
    """

    async def dispatch(self, request: Request, call_next):
        path = request.url.path

        # Well-known metadata and health check don't need auth
        if path.startswith("/.well-known") or path == "/health":
            return await call_next(request)

        # Extract Bearer token
        auth_header = request.headers.get("authorization", "")
        bearer_token = ""
        if auth_header.startswith("Bearer "):
            bearer_token = auth_header[7:]

        if not bearer_token and not os.environ.get("CORETX_API_KEY"):
            # No token and no fallback — return 401 with OAuth discovery
            return Response(
                content=json.dumps({
                    "error": "unauthorized",
                    "error_description": "Bearer token required. Authenticate via OAuth.",
                }),
                status_code=401,
                media_type="application/json",
                headers={
                    "WWW-Authenticate": f'Bearer resource_metadata="{MCP_SERVER_URL}/.well-known/oauth-protected-resource"',
                },
            )

        # Set per-request API key (Bearer token overrides env var)
        if bearer_token:
            _request_api_key.set(bearer_token)

        response = await call_next(request)

        # Reset after request
        if bearer_token:
            _request_api_key.set("")

        return response


# ─── Protected Resource Metadata ──────────────────────────────

async def well_known_protected_resource(request: Request):
    """Serve OAuth Protected Resource Metadata (RFC 9728)."""
    return JSONResponse({
        "resource": MCP_SERVER_URL,
        "authorization_servers": [API_URL],
        "bearer_methods_supported": ["header"],
    }, headers={"Cache-Control": "public, max-age=3600"})


async def health_check(request: Request):
    return JSONResponse({
        "status": "healthy",
        "server": "coretx-connect-remote",
        "version": __version__,
    })


# ─── Entry Point ──────────────────────────────────────────────

async def _run_server(port: int):
    """Run the MCP server with auth middleware and well-known routes."""
    import uvicorn
    from starlette.routing import Route

    # Get the FastMCP Starlette app (properly initialized with lifecycle)
    starlette_app = mcp.streamable_http_app()

    # Add well-known and health routes to the existing app
    starlette_app.routes.insert(0, Route("/.well-known/oauth-protected-resource", well_known_protected_resource))
    starlette_app.routes.insert(0, Route("/health", health_check))

    # Add auth middleware to the app stack
    starlette_app.add_middleware(BearerAuthMiddleware)

    config = uvicorn.Config(
        starlette_app,
        host="0.0.0.0",
        port=port,
        log_level="info",
    )
    server = uvicorn.Server(config)
    await server.serve()


def main():
    import anyio

    port = int(os.environ.get("PORT", "8080"))

    if "--version" in sys.argv:
        print(f"coretx-connect-remote {__version__}")
        return

    if "--help" in sys.argv or "-h" in sys.argv:
        print(f"CoreTx Connect Remote MCP Server v{__version__}")
        print(f"Usage: coretx-connect-remote [--port PORT]")
        print(f"  Starts a Streamable HTTP MCP server for claude.ai integration.")
        print(f"  Default port: 8080 (or PORT env var)")
        print(f"  Endpoint: http://0.0.0.0:{{port}}/mcp")
        return

    for i, arg in enumerate(sys.argv):
        if arg == "--port" and i + 1 < len(sys.argv):
            port = int(sys.argv[i + 1])

    if not os.environ.get("CORETX_API_KEY"):
        print(
            "[coretx-connect-remote] No CORETX_API_KEY env var set. "
            "Users must authenticate via OAuth to use cloud tools.",
            file=sys.stderr,
        )

    print(f"CoreTx Connect Remote v{__version__}", file=sys.stderr)
    print(f"Listening on http://0.0.0.0:{port}/mcp", file=sys.stderr)
    print(f"OAuth auth server: {API_URL}", file=sys.stderr)

    anyio.run(lambda: _run_server(port))


if __name__ == "__main__":
    main()
