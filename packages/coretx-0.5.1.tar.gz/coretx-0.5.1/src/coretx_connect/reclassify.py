"""
Reclassify KOs that have no project assigned.

Scans existing KOs, builds keyword sets from each project's KOs,
then classifies unassigned KOs based on title/content matching.

Usage:
    coretx-connect reclassify           # classify and update
    coretx-connect reclassify --dry-run # show what would change
"""

from __future__ import annotations

import re
import sys
from collections import Counter, defaultdict

from coretx_connect.server import _api_get, _api_post, API_KEY


def _build_project_keywords(kos: list[dict]) -> dict[str, set[str]]:
    """Build keyword sets from KOs that already have projects."""
    project_words: dict[str, Counter] = defaultdict(Counter)

    for ko in kos:
        project = ko.get("project", "")
        if not project:
            continue
        # Extract significant words from title + content
        text = f"{ko.get('subject', '')} {ko.get('title', '')} {ko.get('object_value', '')} {ko.get('content', '')}"
        words = re.findall(r'[a-zA-Z]{4,}', text.lower())
        for word in words:
            project_words[project][word] += 1

    # Keep top 50 keywords per project (most distinctive)
    result = {}
    for project, counts in project_words.items():
        # Filter out very common words
        common = {"this", "that", "with", "from", "have", "been", "will", "they",
                  "their", "what", "when", "which", "would", "could", "should",
                  "about", "into", "more", "than", "each", "other", "some", "just",
                  "also", "only", "then", "very", "well", "here", "there"}
        filtered = {w: c for w, c in counts.items() if w not in common and c >= 2}
        top = sorted(filtered.items(), key=lambda x: -x[1])[:50]
        result[project] = {w for w, _ in top}

    return result


def _score_ko_against_projects(ko: dict, project_keywords: dict[str, set[str]]) -> str | None:
    """Score a KO against project keyword sets. Returns best match or None."""
    text = f"{ko.get('subject', '')} {ko.get('title', '')} {ko.get('object_value', '')} {ko.get('content', '')}"
    words = set(re.findall(r'[a-zA-Z]{4,}', text.lower()))

    best_project = None
    best_score = 0

    for project, keywords in project_keywords.items():
        overlap = len(words & keywords)
        if overlap > best_score and overlap >= 2:  # Need at least 2 keyword matches
            best_score = overlap
            best_project = project

    return best_project


def reclassify(dry_run: bool = False) -> dict:
    """Reclassify unassigned KOs based on keyword matching.

    Returns: {"total": N, "unassigned": N, "classified": N, "unchanged": N}
    """
    # Fetch all KOs
    result = _api_get("list", {"limit": 500})
    all_kos = result.get("kos", result.get("results", []))

    if not all_kos:
        return {"total": 0, "unassigned": 0, "classified": 0, "unchanged": 0}

    # Split into assigned and unassigned
    assigned = [ko for ko in all_kos if ko.get("project")]
    unassigned = [ko for ko in all_kos if not ko.get("project")]

    print(f"Total KOs: {len(all_kos)}")
    print(f"Already assigned: {len(assigned)}")
    print(f"Unassigned: {len(unassigned)}")

    if not unassigned:
        print("Nothing to reclassify.")
        return {"total": len(all_kos), "unassigned": 0, "classified": 0, "unchanged": 0}

    # Build keyword sets from assigned KOs
    project_keywords = _build_project_keywords(assigned)
    print(f"\nProjects found: {', '.join(project_keywords.keys())}")
    for project, keywords in project_keywords.items():
        print(f"  {project}: {len(keywords)} keywords (top: {', '.join(list(keywords)[:5])})")

    # Classify unassigned KOs
    classified = 0
    unchanged = 0

    print(f"\nClassifying {len(unassigned)} unassigned KOs...\n")

    for ko in unassigned:
        best_project = _score_ko_against_projects(ko, project_keywords)
        subject = ko.get("subject", ko.get("title", "?"))

        if best_project:
            if dry_run:
                print(f"  {subject[:50]} -> {best_project}")
            else:
                # Update via write (upserts on subject+predicate)
                update_result = _api_post({
                    "action": "write",
                    "subject": ko.get("subject", ko.get("title", "")),
                    "predicate": ko.get("predicate", ""),
                    "object_value": ko.get("object_value", ko.get("content", "")),
                    "project": best_project,
                    "ko_type": ko.get("ko_type", "insight"),
                    "memory_type": ko.get("memory_type", "episodic"),
                    "tags": ko.get("tags", []),
                    "visibility": "private",
                })
                if "error" not in update_result:
                    print(f"  {subject[:50]} -> {best_project}")
                    classified += 1
                else:
                    print(f"  {subject[:50]} -> FAILED: {update_result.get('error')}")
                    unchanged += 1
            classified += 1 if dry_run else 0
        else:
            unchanged += 1

    return {
        "total": len(all_kos),
        "unassigned": len(unassigned),
        "classified": classified,
        "unchanged": unchanged,
    }


def main():
    dry_run = "--dry-run" in sys.argv

    if "--help" in sys.argv or "-h" in sys.argv:
        print("coretx-connect reclassify [--dry-run]")
        print("  Classify unassigned KOs into projects based on keyword matching.")
        return

    if not API_KEY and not dry_run:
        print("CORETX_API_KEY not set. Use --dry-run to preview.", file=sys.stderr)
        sys.exit(1)

    if dry_run:
        print("(dry run — nothing will be updated)\n")

    stats = reclassify(dry_run=dry_run)

    print(f"\nDone. {stats['classified']} classified, {stats['unchanged']} unchanged "
          f"(out of {stats['unassigned']} unassigned).")


if __name__ == "__main__":
    main()
