"""CoreTx Connect — thin MCP server for the CoreTx knowledge network."""
from importlib.metadata import version as _version
__version__ = _version("coretx-connect")
