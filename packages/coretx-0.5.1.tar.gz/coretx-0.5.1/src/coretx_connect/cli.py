"""CoreTx Connect CLI -- account setup and management."""
from __future__ import annotations
import getpass, json, os, re, sys, time
import urllib.error, urllib.request
from pathlib import Path
from typing import Any
from coretx_connect import __version__

CONFIG_DIR = Path.home() / ".coretx"
CONFIG_PATH = CONFIG_DIR / "config.json"
DEFAULT_API_URL = "https://api.coretx.ai"
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def load_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}

def save_config(config: dict[str, Any]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    try: os.chmod(CONFIG_PATH, 0o600)
    except OSError: pass

def remove_config() -> bool:
    if CONFIG_PATH.exists():
        CONFIG_PATH.unlink()
        return True
    return False

def get_api_key() -> str:
    return os.environ.get("CORETX_API_KEY", "") or load_config().get("api_key", "")

def get_api_url() -> str:
    return os.environ.get("CORETX_API_URL", "") or load_config().get("api_url", DEFAULT_API_URL)

# -- HTTP -------------------------------------------------------------------

def _post(url: str, body: dict, headers: dict | None = None) -> dict:
    hdrs = {"Content-Type": "application/json", **(headers or {})}
    return _do(urllib.request.Request(url, json.dumps(body).encode(), hdrs, method="POST"))

def _get(url: str, headers: dict | None = None) -> dict:
    return _do(urllib.request.Request(url, headers=headers or {}, method="GET"))

def _do(req: urllib.request.Request) -> dict:
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ""
        try: return {**json.loads(body), "_status": e.code}
        except Exception: return {"error": body[:300] or f"HTTP {e.code}", "_status": e.code}
    except urllib.error.URLError:
        return {"error": "network"}
    except Exception as e:
        return {"error": str(e)}

# -- Auth helpers -----------------------------------------------------------

def _try_endpoints(api_url: str, paths: list[str], body: dict, headers: dict | None = None) -> dict:
    for path in paths:
        result = _post(f"{api_url}{path}", body, headers)
        if result.get("_status") != 404:
            return result
    return {"error": "no endpoint found", "_status": 404}

def _try_signup(api_url: str, email: str, password: str) -> dict:
    return _try_endpoints(api_url, ["/api/auth/signup", "/api/auth/email", "/api/oauth/register"],
                          {"email": email, "password": password})

def _try_login(api_url: str, email: str, password: str) -> dict:
    return _try_endpoints(api_url, ["/api/auth/login", "/api/auth/email", "/api/auth/signin"],
                          {"email": email, "password": password})

def _try_generate_key(api_url: str, token: str) -> dict:
    return _try_endpoints(api_url, ["/api/keys/generate", "/api/keys", "/api/auth/api-key"],
                          {"label": "coretx-connect"}, {"Authorization": f"Bearer {token}"})

# -- Output helpers ---------------------------------------------------------

def _network_error() -> int:
    print("\n  Could not reach CoreTx servers. Check your connection.")
    print("  If the problem persists, try: coretx-connect init --key YOUR_API_KEY\n")
    return 1

def _manual_fallback() -> int:
    print("\n  Automatic setup not available yet. Please:")
    print("    1. Create an account at nanopub.coretx.ai")
    print("    2. Go to Settings > API Keys > Generate")
    print("    3. Run: coretx-connect init --key YOUR_API_KEY\n")
    return 1

def _save_and_verify(api_key: str, api_url: str, email: str = "") -> int:
    config = {"api_key": api_key, "api_url": api_url, "email": email,
              "tier": "network", "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    save_config(config)
    print(f"\n  API key saved to {CONFIG_PATH}")
    result = _get(f"{api_url}/api/kos?action=stats", {"Authorization": f"Bearer {api_key}"})
    if "error" not in result:
        total = result.get("total_kos", 0)
        print(f"  Connected. {total} KOs in your store.")
        config["tier"] = result.get("tier", "network")
        save_config(config)
    else:
        print("  Saved, but could not verify connection. Check your key.")
    print("\n  Your knowledge store is ready. Add to Claude Code:\n")
    print("    claude mcp add coretx-connect -- coretx-connect serve\n")
    print("  Or for claude.ai, visit: https://nanopub.coretx.ai/connect/setup\n")
    return 0

# -- Commands ---------------------------------------------------------------

def cmd_init(args: list[str]) -> int:
    api_url, manual_key = DEFAULT_API_URL, ""
    i = 0
    while i < len(args):
        if args[i] == "--api-url" and i + 1 < len(args):
            api_url = args[i + 1]; i += 2
        elif args[i] == "--key" and i + 1 < len(args):
            manual_key = args[i + 1]; i += 2
        else:
            i += 1
    api_url = os.environ.get("CORETX_API_URL", api_url)

    print("\n  CoreTx Connect")
    print("  Structured memory for AI that persists, attributes, and connects.")
    print("  Learn more: https://nanopub.coretx.ai/connect\n")

    existing = load_config()
    if existing.get("api_key"):
        print(f"  Found existing config ({existing.get('email', 'unknown')}).")
        if input("  Overwrite? [y/N] ").strip().lower() not in ("y", "yes"):
            print("  Keeping existing config.")
            return 0

    if manual_key:
        return _save_and_verify(manual_key, api_url, email="(manual)")

    print("  Create your CoreTx ID or sign in:\n")
    while True:
        email = input("  Email: ").strip()
        if _EMAIL_RE.match(email): break
        print("  Please enter a valid email address.")
    while True:
        password = getpass.getpass("  Password: ")
        if len(password) >= 8: break
        print("  Password must be at least 8 characters.")

    print("\n  Creating account...", end="", flush=True)
    result = _try_signup(api_url, email, password)
    session_token = ""

    if result.get("_status") == 409 or "already exists" in result.get("error", "").lower():
        print(" account already exists.")
        print("  Signing in...", end="", flush=True)
        result = _try_login(api_url, email, password)
        if result.get("error") == "network":
            print(" failed."); return _network_error()
        if "error" in result:
            print(" failed.")
            if result.get("_status") == 401:
                print("\n  Invalid password. Try again or reset at nanopub.coretx.ai")
            else:
                print(f"\n  {result.get('error', 'Unknown error')}")
            return 1
        session_token = result.get("token", result.get("session", ""))
    elif "error" in result:
        if result.get("error") == "network":
            print(" failed."); return _network_error()
        print(f" failed ({result.get('error', 'unknown')}).")
        print("  Trying to sign in instead...", end="", flush=True)
        result = _try_login(api_url, email, password)
        if "error" in result:
            print(" failed."); return _manual_fallback()
        session_token = result.get("token", result.get("session", ""))
    else:
        print(" done.")
        session_token = result.get("token", result.get("session", ""))

    if not session_token:
        return _manual_fallback()

    print("  Generating API key...", end="", flush=True)
    key_result = _try_generate_key(api_url, session_token)
    api_key = key_result.get("api_key", key_result.get("key", ""))
    if "error" in key_result or not api_key:
        print(" failed."); return _manual_fallback()
    print(" done.")
    return _save_and_verify(api_key, api_url, email=email)


def cmd_status(args: list[str]) -> int:
    print(f"\n  CoreTx Connect v{__version__}")
    api_key, api_url, config = get_api_key(), get_api_url(), load_config()
    if not api_key:
        print("  Status: not configured\n  Run 'coretx-connect init' to set up.\n")
        return 1
    print(f"  Email: {config.get('email', '(env var)')}")
    result = _get(f"{api_url}/api/kos?action=stats", {"Authorization": f"Bearer {api_key}"})
    if "error" not in result:
        tier = result.get("tier", config.get("tier", "network"))
        print(f"  Tier: {tier} (beta)")
        print(f"  KOs: {result.get('total_kos', 0)}")
        print(f"  API: {api_url} (connected)")
    else:
        print(f"  Tier: {config.get('tier', 'unknown')}")
        print(f"  API: {api_url} (unreachable)")
    print()
    return 0


def cmd_logout(args: list[str]) -> int:
    if remove_config():
        print(f"\n  Signed out. Config removed from {CONFIG_PATH}\n")
    else:
        print("\n  No config found. Nothing to remove.\n")
    return 0


def cmd_help() -> int:
    print(f"""
  CoreTx Connect v{__version__}
  Structured memory for AI that persists, attributes, and connects.

  Usage: coretx-connect <command> [options]

  Commands:
    init              Create account and configure API key
    init --key KEY    Set API key manually (skip signup)
    status            Show current config and connectivity
    logout            Remove saved config
    serve             Run the MCP server (default)
    setup [KEY]       Write config into Claude Desktop settings
    test              Verify API connectivity
    bootstrap         Extract KOs from Claude Code session logs

  Options:
    --api-url URL     Override API server URL
    --version         Show version
    --help            Show this message
""")
    return 0


# -- Entry point ------------------------------------------------------------

def main() -> None:
    args = sys.argv[1:]
    if not args or args[0] == "serve":
        from coretx_connect.server import main as server_main
        server_main()
        return
    cmd, rest = args[0], args[1:]
    if cmd == "--version":
        print(f"coretx-connect {__version__}"); return
    if cmd in ("--help", "-h", "help"):
        cmd_help(); return
    if cmd == "init":
        sys.exit(cmd_init(rest))
    if cmd == "status":
        sys.exit(cmd_status(rest))
    if cmd == "logout":
        sys.exit(cmd_logout(rest))
    if cmd in ("setup", "test", "--test"):
        from coretx_connect.server import main as server_main
        server_main(); return
    if cmd == "bootstrap":
        from coretx_connect.bootstrap import main as bootstrap_main
        bootstrap_main(); return
    if cmd == "reclassify":
        from coretx_connect.reclassify import main as reclassify_main
        reclassify_main(); return
    print(f"  Unknown command: {cmd}")
    print(f"  Run 'coretx-connect --help' for usage.")
    sys.exit(1)
