#!/usr/bin/env python
from __future__ import print_function

import json
import os
import subprocess
import time


CLOUD_WORK_SHUTDOWN_REQUEST_FILENAME = "cloud_work_shutdown_request.json"
OPERATOR_SHUTDOWN_REQUESTED = "OPERATOR_SHUTDOWN_REQUESTED"
ACTIVE_REQUEST_STATUSES = ("requested", "running", "acknowledged")
TERMINAL_REQUEST_STATUSES = ("canceled", "stopped", "completed", "terminal")


def iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _pid_running(pid):
    try:
        pid_int = int(pid)
    except Exception:
        return False
    if pid_int <= 0:
        return False
    if os.name == "nt":
        try:
            from MediCafe.win_pid_probe import windows_process_is_alive_or_unknown
            return windows_process_is_alive_or_unknown(pid_int)
        except Exception:
            return True
    try:
        os.kill(pid_int, 0)
        return True
    except OSError:
        return False


def process_is_running(pid):
    return _pid_running(pid)


def _devnull_handle():
    try:
        return subprocess.DEVNULL
    except Exception:
        return open(os.devnull, "w")


def terminate_process(pid, reason=""):
    result = {
        "attempted": False,
        "ok": False,
        "method": "",
        "pid": str(pid or ""),
        "return_code": "",
        "message": "",
        "reason": str(reason or ""),
    }
    try:
        pid_int = int(pid)
    except Exception:
        result["message"] = "invalid_pid"
        return result
    result["pid"] = str(pid_int)
    if pid_int <= 0:
        result["message"] = "invalid_pid"
        return result
    if pid_int == os.getpid():
        result["message"] = "refused_current_process"
        return result
    if not _pid_running(pid_int):
        result["ok"] = True
        result["message"] = "not_running"
        return result

    result["attempted"] = True
    stdout_handle = _devnull_handle()
    stderr_handle = _devnull_handle()
    close_stdout = stdout_handle is not getattr(subprocess, "DEVNULL", None)
    close_stderr = stderr_handle is not getattr(subprocess, "DEVNULL", None)
    try:
        if os.name == "nt":
            result["method"] = "taskkill"
            rc = subprocess.call(
                ["taskkill", "/PID", str(pid_int), "/T", "/F"],
                stdout=stdout_handle,
                stderr=stderr_handle)
            result["return_code"] = str(rc)
            result["ok"] = not _pid_running(pid_int)
        else:
            result["method"] = "os_kill"
            try:
                import signal
                os.kill(pid_int, signal.SIGTERM)
                time.sleep(0.2)
                if _pid_running(pid_int):
                    os.kill(pid_int, signal.SIGKILL)
                result["ok"] = not _pid_running(pid_int)
            except Exception as exc:
                result["message"] = str(exc)
                result["ok"] = not _pid_running(pid_int)
    except Exception as exc:
        result["message"] = str(exc)
        result["ok"] = not _pid_running(pid_int)
    finally:
        if close_stdout:
            try:
                stdout_handle.close()
            except Exception:
                pass
        if close_stderr:
            try:
                stderr_handle.close()
            except Exception:
                pass
    if result["ok"] and not result.get("message"):
        result["message"] = "terminated"
    elif not result["ok"] and not result.get("message"):
        result["message"] = "still_running"
    return result


def request_path(lab_root):
    return os.path.join(str(lab_root or ""), "reports", CLOUD_WORK_SHUTDOWN_REQUEST_FILENAME)


def read_request(lab_root):
    path = request_path(lab_root)
    try:
        if not os.path.isfile(path):
            return {}
        with open(path, "r") as handle:
            data = json.load(handle)
        if isinstance(data, dict):
            return data
    except Exception:
        return {}
    return {}


def write_request(lab_root, payload):
    path = request_path(lab_root)
    data = payload if isinstance(payload, dict) else {}
    try:
        reports_dir = os.path.dirname(path)
        if reports_dir and not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
        tmp_path = path + ".tmp"
        with open(tmp_path, "w") as handle:
            json.dump(data, handle, indent=2, sort_keys=True)
            handle.write("\n")
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass
        os.rename(tmp_path, path)
        return path
    except Exception:
        return ""


def active_request(lab_root):
    req = read_request(lab_root)
    status = str(req.get("status") or "").strip()
    if status in ACTIVE_REQUEST_STATUSES:
        return req
    return {}


def request_is_terminal(request):
    status = str((request if isinstance(request, dict) else {}).get("status") or "").strip()
    return status in TERMINAL_REQUEST_STATUSES


def mark_request_stopped(lab_root, request, updates):
    req = dict(request if isinstance(request, dict) else {})
    req["status"] = "stopped"
    req["stopped_at_utc"] = iso_utc_now()
    req["stop_reason"] = OPERATOR_SHUTDOWN_REQUESTED
    if isinstance(updates, dict):
        req.update(updates)
    write_request(lab_root, req)
    return req
