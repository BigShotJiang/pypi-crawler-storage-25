# -*- coding: utf-8 -*-
"""
Consolidated performance-event logging helpers.

Performance troubleshooting should enrich the log file without adding routine
timing chatter to the operator terminal.
"""

from __future__ import print_function


def _safe_text(value):
    try:
        return str(value)
    except Exception:
        return ''


def _format_elapsed_ms(elapsed_sec=None, elapsed_ms=None):
    try:
        if elapsed_ms is not None:
            return int(elapsed_ms)
    except Exception:
        pass
    try:
        if elapsed_sec is not None:
            return int(float(elapsed_sec) * 1000)
    except Exception:
        pass
    return None


def log_performance_event(component, stage, elapsed_sec=None, elapsed_ms=None, details=None, level='INFO'):
    """
    Log a single PERF_TIMING event. Never prints to the console.

    ``details`` may be a dict or a list of (key, value) pairs. Values should be
    concise scalars because this is intended for line-oriented XP logs.
    """
    parts = [
        'PERF_TIMING',
        'component={0}'.format(_safe_text(component or 'unknown')),
        'stage={0}'.format(_safe_text(stage or 'unknown')),
    ]
    elapsed = _format_elapsed_ms(elapsed_sec=elapsed_sec, elapsed_ms=elapsed_ms)
    if elapsed is not None:
        parts.append('elapsed_ms={0}'.format(elapsed))
    items = []
    if isinstance(details, dict):
        try:
            items = sorted(details.items())
        except Exception:
            items = []
    elif isinstance(details, (list, tuple)):
        items = details
    for item in items:
        try:
            key, value = item
        except Exception:
            continue
        key_text = _safe_text(key).replace(' ', '_')
        value_text = _safe_text(value).replace('\r', ' ').replace('\n', ' ')
        parts.append('{0}={1}'.format(key_text, value_text))
    message = ' '.join(parts)
    try:
        from MediCafe.MediLink_ConfigLoader import log as config_log
        # Pass an explicit empty config so ConfigLoader.load_configuration() can
        # emit timing while it is still loading without recursively re-entering.
        config_log(message, config={}, level=level, console_output=False)
        return
    except Exception:
        pass
    try:
        from MediCafe.logging_config import bootstrap_log
        bootstrap_log(level, message)
    except Exception:
        pass
