#!/usr/bin/env python3
"""
MediCafe Entry Point (__main__.py)

This module serves as the main entry point for the MediCafe package.
It can be called directly from the batch file and routes user choices
to the appropriate sub-applications without adding interface layers.

Usage:
    python -m MediCafe <command> [args...]
    
Commands:
    launcher [options]        - Launch interactive MediCafe UI menu
    medibot [config_file]     - Run MediBot data entry automation
    medilink                  - Run MediLink claims processing  
    claims_status             - Run United Claims Status checker
    deductible               - Run United Deductible checker
    download_emails          - Run email download functionality (legacy GAS helper by default)
    cloud_daemon            - Run MediLink cloud daemon client
    send_error_report         - Run support self-tests and email a support bundle
    send_queued_error_reports - Attempt to send queued error report bundles
    send_cpt_dx_review       - Run CPT/diagnosis review and email crosswalk proposal bundle
    send_minutes_charge_review - Run minutes/charge review and email summary bundle
    build_service_line_charge_anchor_index - Build Service Line Input charge-anchor index and email report
    docx_index_rebuild       - Force rebuild of DOCX schedule index
    docx_index_retry_failed  - Retry previously failed DOCX schedule parses
    csv_metadata_index_rebuild - Force rebuild of CSV metadata index
    preflight                - Run local readiness check (config, paths, imports)
    version                  - Show MediCafe version information
    
The entry point preserves user choices and navigational flow from the
batch script without adding unnecessary interface layers.
"""

import sys
import os
import argparse
import subprocess
import time
import json
import hashlib
import traceback
from MediCafe.core_utils import import_medilink_module, require_functions, print_import_diagnostics
try:
    from MediCafe.logging_config import bootstrap_log
except Exception:
    def bootstrap_log(level, message):
        return None

SERVICE_LINE_ANCHOR_ACTION_STATUS_BASENAME = 'service_line_charge_anchor_option_h_status_latest'
SERVICE_LINE_ANCHOR_ACTION_STATUS_SCHEMA = 'service_line_charge_anchor_option_h_status.v1'

# Set up module paths for proper imports
def setup_entry_point_paths():
    """Set up paths for the MediCafe entry point"""
    # Get the parent directory (workspace root)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    workspace_root = os.path.dirname(current_dir)
    
    # Add to Python path if not already present
    workspace_str = workspace_root
    if workspace_str not in sys.path:
        sys.path.insert(0, workspace_str)
    
    # Ensure we do NOT add package directories directly; only project root should be on sys.path
    # Clean any existing direct package paths that could break package imports (e.g., 'MediLink' is not a package)
    for pkg_dir in (os.path.join(workspace_root, 'MediBot'), os.path.join(workspace_root, 'MediLink')):
        while pkg_dir in sys.path:
            sys.path.remove(pkg_dir)

def validate_critical_imports():
    """Validate key modules and capabilities before launching subprocesses.
    - Ensures we resolve the in-repo MediLink_DataMgmt and it exposes required functions.
    Behavior depends on env flags handled inside core_utils.require_functions.
    """
    try:
        datamgmt = import_medilink_module('MediLink_DataMgmt')
        if datamgmt is not None:
            print_import_diagnostics('MediLink_DataMgmt', datamgmt)
            # These are used by both MediBot and MediLink flows
            require_functions(datamgmt, ['read_general_fixed_width_data', 'read_fixed_width_data', 'parse_fixed_width_data'])
    except Exception as e:
        # Fail fast only if strict mode is enabled (exception originates from require_functions)
        msg = "Import validation warning: {}".format(e)
        print(msg)
        try:
            from MediCafe.logging_config import bootstrap_log
            bootstrap_log("WARNING", msg)
        except Exception:
            pass

def _print_launch_status(message):
    """Print launcher-to-child progress messages with flush for XP consoles."""
    try:
        print(str(message or ''))
        sys.stdout.flush()
    except Exception:
        pass
    try:
        bootstrap_log("INFO", str(message or ''))
    except Exception:
        pass

def run_medibot(config_file=None):
    """Run MediBot application"""
    try:
        print("Starting MediBot...")
        launch_t0_ms = int(time.time() * 1000)

        # Resolve workspace root and MediBot.py path
        current_dir = os.path.dirname(os.path.abspath(__file__))
        workspace_root = os.path.dirname(current_dir)
        medibot_path = os.path.join(workspace_root, 'MediBot', 'MediBot.py')

        if not os.path.exists(medibot_path):
            print("Error: MediBot.py not found at {}".format(medibot_path))
            return 1

        # Pre-flight import validation (no-op unless strict/debug enabled)
        validate_critical_imports()

        # Build subprocess arguments
        args = [sys.executable, medibot_path]
        if config_file:
            args.append(config_file)

        # Ensure subprocess can import project packages
        env = os.environ.copy()
        python_path = workspace_root
        if 'PYTHONPATH' in env:
            env['PYTHONPATH'] = python_path + os.pathsep + env['PYTHONPATH']
        else:
            env['PYTHONPATH'] = python_path
        env['MEDICAFE_MEDIBOT_LAUNCH_T0_MS'] = str(launch_t0_ms)

        # Run MediBot as a script so its __main__ block executes
        result = subprocess.call(args, cwd=os.path.dirname(medibot_path), env=env)
        return result

    except Exception as e:
        print("Error running MediBot: {}".format(e))
        return 1

def run_medilink():
    """Run MediLink application"""
    try:
        _print_launch_status("Starting MediLink...")
        _print_launch_status("Preparing MediLink runtime...")
        # Pre-flight import validation (no-op unless strict/debug enabled)
        validate_critical_imports()
        # Use subprocess.call for Python 3.4.4 compatibility
        
        # Get the path to MediLink_main.py
        current_dir = os.path.dirname(os.path.abspath(__file__))
        workspace_root = os.path.dirname(current_dir)
        medilink_main_path = os.path.join(workspace_root, 'MediLink', 'MediLink_main.py')
        
        if os.path.exists(medilink_main_path):
            # Set up environment for subprocess to find MediCafe
            env = os.environ.copy()
            python_path = workspace_root
            if 'PYTHONPATH' in env:
                env['PYTHONPATH'] = python_path + os.pathsep + env['PYTHONPATH']
            else:
                env['PYTHONPATH'] = python_path
            
            # Set working directory to MediLink directory for proper file paths
            medilink_dir = os.path.dirname(medilink_main_path)
            env['MEDICAFE_STARTUP_PROGRESS'] = '1'
            _print_launch_status("Launching MediLink process...")
            
            # Use subprocess.call for Python 3.4.4 compatibility
            result = subprocess.call([sys.executable, medilink_main_path], 
                                   cwd=medilink_dir,
                                   env=env)
            return result
        else:
            print("Error: MediLink_main.py not found at {}".format(medilink_main_path))
            return 1
        
    except ImportError as e:
        print("Error: Unable to import MediLink: {}".format(e))
        return 1
    except Exception as e:
        print("Error running MediLink: {}".format(e))
        return 1

def run_claims_status():
    """Run United Claims Status checker"""
    try:
        print("Starting United Claims Status...")
        # Use subprocess.call for Python 3.4.4 compatibility
        
        # Get the path to MediLink_ClaimStatus.py
        current_dir = os.path.dirname(os.path.abspath(__file__))
        workspace_root = os.path.dirname(current_dir)
        claims_status_path = os.path.join(workspace_root, 'MediLink', 'MediLink_ClaimStatus.py')
        
        if os.path.exists(claims_status_path):
            # Set up environment for subprocess to find MediCafe
            env = os.environ.copy()
            python_path = workspace_root
            if 'PYTHONPATH' in env:
                env['PYTHONPATH'] = python_path + os.pathsep + env['PYTHONPATH']
            else:
                env['PYTHONPATH'] = python_path
            
            # Set working directory to MediLink directory for proper file paths
            medilink_dir = os.path.dirname(claims_status_path)
            
            # Use subprocess.call for Python 3.4.4 compatibility
            result = subprocess.call([sys.executable, claims_status_path], 
                                   cwd=medilink_dir,
                                   env=env)
            return result
        else:
            print("Error: MediLink_ClaimStatus.py not found at {}".format(claims_status_path))
            return 1
        
    except ImportError as e:
        print("Error: Unable to import MediLink_ClaimStatus: {}".format(e))
        return 1
    except Exception as e:
        print("Error running Claims Status: {}".format(e))
        return 1

def run_deductible():
    """Run United Deductible checker"""
    try:
        print("Starting United Deductible...")
        # Use subprocess.call for Python 3.4.4 compatibility
        
        # Get the path to MediLink_Deductible.py
        current_dir = os.path.dirname(os.path.abspath(__file__))
        workspace_root = os.path.dirname(current_dir)
        deductible_path = os.path.join(workspace_root, 'MediLink', 'MediLink_Deductible.py')
        
        if os.path.exists(deductible_path):
            # Set up environment for subprocess to find MediCafe
            env = os.environ.copy()
            python_path = workspace_root
            if 'PYTHONPATH' in env:
                env['PYTHONPATH'] = python_path + os.pathsep + env['PYTHONPATH']
            else:
                env['PYTHONPATH'] = python_path
            
            # Set working directory to MediLink directory for proper file paths
            medilink_dir = os.path.dirname(deductible_path)
            
            # Use subprocess.call for Python 3.4.4 compatibility
            result = subprocess.call([sys.executable, deductible_path], 
                                   cwd=medilink_dir,
                                   env=env)
            return result
        else:
            print("Error: MediLink_Deductible.py not found at {}".format(deductible_path))
            return 1
        
    except ImportError as e:
        print("Error: Unable to import MediLink_Deductible: {}".format(e))
        return 1
    except Exception as e:
        print("Error running Deductible checker: {}".format(e))
        return 1

def run_download_emails():
    """Run email download functionality."""
    try:
        cloud_mode = os.environ.get('MEDILINK_DOWNLOAD_MODE', '').strip().lower() == 'cloud'
        if cloud_mode:
            print("Starting email download (cloud mode)...")
            return run_cloud_daemon()

        print("Starting email download (legacy mode)...")
        # Use subprocess.call for Python 3.4.4 compatibility

        # Get the path to MediLink_Gmail.py
        current_dir = os.path.dirname(os.path.abspath(__file__))
        workspace_root = os.path.dirname(current_dir)
        medilink_gmail_path = os.path.join(workspace_root, 'MediLink', 'MediLink_Gmail.py')

        if os.path.exists(medilink_gmail_path):
            # Set up environment for subprocess to find MediCafe
            env = os.environ.copy()
            python_path = workspace_root
            if 'PYTHONPATH' in env:
                env['PYTHONPATH'] = python_path + os.pathsep + env['PYTHONPATH']
            else:
                env['PYTHONPATH'] = python_path
            
            # Set working directory to MediLink directory for proper file paths
            medilink_dir = os.path.dirname(medilink_gmail_path)
            
            # Use subprocess.call for Python 3.4.4 compatibility
            result = subprocess.call([sys.executable, medilink_gmail_path], 
                                   cwd=medilink_dir,
                                   env=env)
            return result
        else:
            print("Error: MediLink_Gmail.py not found at {}".format(medilink_gmail_path))
            return 1
        
    except ImportError as e:
        print("Error: Unable to import MediLink_Gmail: {}".format(e))
        return 1


def run_cloud_daemon(config_file=None):
    """Run MediLink cloud daemon client."""
    try:
        print("Starting MediLink cloud daemon...")

        current_dir = os.path.dirname(os.path.abspath(__file__))
        workspace_root = os.path.dirname(current_dir)
        daemon_path = os.path.join(workspace_root, 'xp_client', 'medilink_cloud_daemon.py')

        if not os.path.exists(daemon_path):
            print("Error: medilink_cloud_daemon.py not found at {}".format(daemon_path))
            return 1

        env = os.environ.copy()
        python_path = workspace_root
        if 'PYTHONPATH' in env:
            env['PYTHONPATH'] = python_path + os.pathsep + env['PYTHONPATH']
        else:
            env['PYTHONPATH'] = python_path

        daemon_dir = os.path.dirname(daemon_path)
        args = [sys.executable, daemon_path]
        if config_file:
            args.extend(['--config', config_file])

        result = subprocess.call(args, cwd=daemon_dir, env=env)
        return result

    except Exception as e:
        print("Error running MediLink cloud daemon: {}".format(e))
        return 1

def show_version():
    """Show MediCafe version information"""
    try:
        from MediCafe import __version__, __author__
        print("MediCafe version {}".format(__version__))
        print("Author: {}".format(__author__))
        return 0
    except ImportError:
        print("MediCafe version information not available")
        return 1

def run_docx_index_rebuild():
    """Force rebuild the DOCX schedule index from local storage."""
    try:
        from MediBot.MediBot_docx_index import update_docx_schedule_index
    except Exception as e:
        print("Error: Unable to load DOCX index helpers: {}".format(e))
        return 1

    local_storage_path = _load_local_storage_path_for_docx_index()
    if not local_storage_path:
        return 1

    print("Rebuilding DOCX schedule index from: {}".format(local_storage_path))
    index_data, stats = update_docx_schedule_index(
        local_storage_path,
        filepaths=None,
        capture_schedule_positions=True,
        force_rebuild=True,
        source='cli_rebuild'
    )
    print("DOCX index rebuild complete. Files parsed: {}, skipped: {}, errors: {}".format(
        stats.get('parsed', 0), stats.get('skipped', 0), stats.get('errors', 0)))
    failed_files = []
    try:
        file_index = index_data.get('files', {})
    except Exception:
        file_index = {}
    for fname, frec in file_index.items():
        if isinstance(frec, dict) and frec.get('parse_failed'):
            error_type = frec.get('parse_error_type', 'unknown')
            error_message = frec.get('parse_error_message', '')
            date_of_service = frec.get('date_of_service', '')
            if date_of_service:
                failed_files.append("{} ({}) [{}] {}".format(fname, error_type, date_of_service, error_message))
            else:
                failed_files.append("{} ({}) {}".format(fname, error_type, error_message))
    if failed_files:
        log_func = None
        try:
            from MediCafe import MediLink_ConfigLoader
            log_func = getattr(MediLink_ConfigLoader, 'log', None)
        except Exception:
            log_func = None
        if log_func:
            log_func("DOCX parse failures present ({} total).".format(len(failed_files)), level="WARNING")
            for detail in failed_files:
                log_func("DOCX parse failure: {}".format(detail), level="WARNING")
        print("DOCX parse failures ({} total):".format(len(failed_files))) 
        for line in failed_files[:10]:
            print("  - {}".format(line))
        if len(failed_files) > 10:
            print("  ... {} more (see .docx_schedule_index.json)".format(len(failed_files) - 10))
    if not index_data.get('schedules'):
        print("Warning: No schedule entries were indexed.")
    return 0


def _load_local_storage_path_for_docx_index():
    try:
        from MediCafe.MediLink_ConfigLoader import load_configuration
    except Exception as e:
        print("Error: Unable to load configuration helper: {}".format(e))
        return None

    try:
        config, _ = load_configuration()
    except Exception as e:
        print("Error: Failed to load configuration: {}".format(e))
        return None

    local_storage_path = config.get('MediLink_Config', {}).get('local_storage_path', '.')
    if not local_storage_path:
        print("Warning: local_storage_path is empty; using current directory.")
        local_storage_path = '.'
    if not os.path.exists(local_storage_path):
        print("Error: local_storage_path does not exist: {}".format(local_storage_path))
        return None
    return local_storage_path


def _load_paths_for_csv_metadata_index():
    try:
        from MediCafe.MediLink_ConfigLoader import load_configuration
    except Exception as e:
        print("Error: Unable to load configuration helper: {}".format(e))
        return None, None

    try:
        config, _ = load_configuration()
    except Exception as e:
        print("Error: Failed to load configuration: {}".format(e))
        return None, None

    medi = config.get('MediLink_Config', {}) if isinstance(config, dict) else {}
    if not isinstance(medi, dict):
        medi = {}
    local_storage_path = medi.get('local_storage_path') or config.get('local_storage_path') or '.'
    if not local_storage_path:
        print("Warning: local_storage_path is empty; using current directory.")
        local_storage_path = '.'
    local_storage_path = os.path.abspath(os.path.expanduser(local_storage_path))
    if not os.path.exists(local_storage_path):
        print("Error: local_storage_path does not exist: {}".format(local_storage_path))
        return None, None

    csv_dir = ''
    try:
        from MediLink.insurance_type_cache import get_csv_dir_from_config
        csv_dir = get_csv_dir_from_config(config) or ''
    except Exception:
        csv_dir = ''
    if not csv_dir:
        csv_file_path = config.get('CSV_FILE_PATH', '') if isinstance(config, dict) else ''
        if csv_file_path:
            csv_dir = os.path.dirname(csv_file_path)
    if not csv_dir:
        candidate = os.path.join(local_storage_path, 'CSV')
        if os.path.isdir(candidate):
            csv_dir = candidate
        else:
            csv_dir = local_storage_path
    csv_dir = os.path.abspath(os.path.expanduser(csv_dir))
    if not os.path.isdir(csv_dir):
        print("Error: CSV directory does not exist: {}".format(csv_dir))
        return None, None
    return local_storage_path, csv_dir


def run_csv_metadata_index_rebuild():
    """Force rebuild the narrow CSV metadata index from configured CSV storage."""
    try:
        from MediBot.MediBot_csv_metadata_index import update_csv_metadata_index
    except Exception as e:
        print("Error: Unable to load CSV metadata index helpers: {}".format(e))
        return 1

    local_storage_path, csv_dir = _load_paths_for_csv_metadata_index()
    if not local_storage_path or not csv_dir:
        return 1

    print("Rebuilding CSV metadata index from: {}".format(csv_dir))
    try:
        result = update_csv_metadata_index(
            local_storage_path,
            csv_dir,
            force_rebuild=True,
            source='cli_rebuild',
            max_csv_files=None,
        )
    except Exception as e:
        print("Error: CSV metadata index rebuild did not complete: {}".format(e))
        return 1
    index_data = getattr(result, 'index_data', None)
    stats = getattr(result, 'stats', None)
    if not isinstance(index_data, dict):
        index_data = {}
    if not isinstance(stats, dict):
        stats = {}
    files = index_data.get('files', {}) if isinstance(index_data.get('files'), dict) else {}
    skipped_files = index_data.get('skipped_files', {}) if isinstance(index_data.get('skipped_files'), dict) else {}
    failed_files = []
    for fname, frec in files.items():
        if isinstance(frec, dict) and frec.get('parse_failed'):
            failed_files.append("{} ({}) {}".format(
                fname,
                frec.get('parse_error_type', 'unknown'),
                frec.get('parse_error_message', ''),
            ))
    print("CSV metadata index rebuild complete. Files parsed: {}, unchanged: {}, skipped profiles: {}, errors: {}, indexed rows: {}".format(
        stats.get('parsed', 0),
        stats.get('skipped', 0),
        stats.get('profile_skipped', 0),
        stats.get('errors', 0),
        stats.get('indexed_rows', 0),
    ))
    print("Indexed CSV files: {}; skipped profile records: {}".format(len(files), len(skipped_files)))
    if failed_files:
        print("CSV parse failures ({} total):".format(len(failed_files)))
        for line in failed_files[:10]:
            print("  - {}".format(line))
        if len(failed_files) > 10:
            print("  ... {} more (see .csv_metadata_index.json)".format(len(failed_files) - 10))
    if not files:
        print("Warning: No CSV metadata rows were indexed.")
    return 0


def _print_docx_failed_retry_preview(candidates):
    print("Previously failed DOCX parse records: {}".format(len(candidates)))
    print("New DOCX files are not scanned by this command; normal lazy update still handles new files.")
    if not candidates:
        return

    grouped = {}
    for candidate in candidates:
        status = candidate.get('status') or 'unknown'
        error_type = candidate.get('parse_error_type') or 'unknown'
        key = (status, error_type)
        grouped[key] = int(grouped.get(key, 0) or 0) + 1

    print("")
    print("Preview by status and error type:")
    for key in sorted(grouped.keys()):
        status, error_type = key
        print("  - {} / {}: {}".format(status, error_type, grouped.get(key)))

    print("")
    print("Failed DOCX candidates:")
    for candidate in candidates[:25]:
        filename = candidate.get('filename') or '<unknown>'
        status = candidate.get('status') or 'unknown'
        error_type = candidate.get('parse_error_type') or 'unknown'
        date_of_service = candidate.get('date_of_service') or ''
        error_message = candidate.get('parse_error_message') or ''
        changed = ' changed_since_failure' if candidate.get('changed_since_failure') else ''
        if date_of_service:
            print("  - {} [{}{}] {} ({})".format(filename, status, changed, error_type, date_of_service))
        else:
            print("  - {} [{}{}] {}".format(filename, status, changed, error_type))
        if error_message:
            print("      {}".format(error_message))
    if len(candidates) > 25:
        print("  ... {} more (see .docx_schedule_index.json)".format(len(candidates) - 25))


def run_docx_index_retry_failed():
    """Retry only DOCX files previously recorded as failed parses."""
    try:
        from MediBot.MediBot_docx_index import (
            collect_failed_docx_parse_candidates,
            update_docx_schedule_index,
        )
    except Exception as e:
        print("Error: Unable to load DOCX index helpers: {}".format(e))
        return 1

    local_storage_path = _load_local_storage_path_for_docx_index()
    if not local_storage_path:
        return 1

    print("Inspecting DOCX schedule index from: {}".format(local_storage_path))
    try:
        candidates = collect_failed_docx_parse_candidates(local_storage_path)
    except Exception as e:
        print("Error: Failed to inspect failed DOCX parse records: {}".format(e))
        return 1

    if not candidates:
        print("No failed DOCX parses found")
        print("New DOCX files are not scanned by this command; normal lazy update still handles new files.")
        return 0

    _print_docx_failed_retry_preview(candidates)
    present_candidates = [c for c in candidates if c.get('present')]
    missing_candidates = [c for c in candidates if not c.get('present')]

    if missing_candidates:
        print("")
        print("Missing failed DOCX files skipped: {}".format(len(missing_candidates)))
        for candidate in missing_candidates[:25]:
            print("  - {}".format(candidate.get('filename') or '<unknown>'))
        if len(missing_candidates) > 25:
            print("  ... {} more".format(len(missing_candidates) - 25))

    if not present_candidates:
        print("No present failed DOCX files to retry.")
        return 0

    present_paths = [c.get('path') for c in present_candidates if c.get('path')]
    print("")
    print("Retrying present failed DOCX files: {}".format(len(present_paths)))
    try:
        index_data, stats = update_docx_schedule_index(
            local_storage_path,
            filepaths=present_paths,
            capture_schedule_positions=True,
            retry_failed=True,
            source='cli_retry_failed'
        )
    except Exception as e:
        print("Error: DOCX failed-parse retry did not complete: {}".format(e))
        return 1

    try:
        remaining_failures = collect_failed_docx_parse_candidates(local_storage_path, index_data=index_data)
    except Exception:
        remaining_failures = []

    print("")
    print("DOCX failed-parse retry complete.")
    print("  Candidates found: {}".format(len(candidates)))
    print("  Present retried: {}".format(len(present_paths)))
    print("  Missing skipped: {}".format(len(missing_candidates)))
    print("  Parsed: {}".format(stats.get('parsed', 0)))
    print("  Skipped: {}".format(stats.get('skipped', 0)))
    print("  Errors: {}".format(stats.get('errors', 0)))
    print("  Remaining failures: {}".format(len(remaining_failures)))
    return 0


def run_reconcile():
    """Run reconciliation gate: compare submission vs remittance, emit report."""
    import os
    try:
        from MediCafe.MediLink_ConfigLoader import load_configuration
        import MediCafe.MediLink_ConfigLoader as _loader
        from MediCafe.reconciliation import (
            run_reconciliation,
            print_reconciliation_summary,
            write_reconciliation_artifacts,
            SEVERITY_PASS,
            SEVERITY_WARN,
        )
    except ImportError as e:
        print("Error: {}".format(e))
        return 1
    try:
        config, _ = load_configuration()
    except Exception as e:
        print("Error: Failed to load configuration: {}".format(e))
        return 1
    medi = config.get('MediLink_Config', {})
    if not isinstance(medi, dict):
        medi = {}
    _repo = os.path.abspath(os.path.join(os.path.dirname(_loader.__file__), '..'))
    raw_storage = medi.get('local_storage_path', '.')
    raw_receipts = medi.get('local_claims_path') or raw_storage
    storage_path = os.path.abspath(os.path.join(_repo, raw_storage)) if not os.path.isabs(raw_storage) else raw_storage
    receipts_root = os.path.abspath(os.path.join(_repo, raw_receipts)) if not os.path.isabs(raw_receipts) else raw_receipts
    if not os.path.isdir(storage_path):
        try:
            os.makedirs(storage_path)
        except OSError:
            pass
    medi['local_storage_path'] = storage_path
    medi['local_claims_path'] = receipts_root
    config['MediLink_Config'] = medi

    result = run_reconciliation(config, receipts_root=receipts_root, storage_path=storage_path)
    severity = result.get('severity', SEVERITY_PASS)
    print_reconciliation_summary(result, storage_path)
    write_reconciliation_artifacts(result, storage_path)
    return 0 if severity in (SEVERITY_PASS, SEVERITY_WARN) else 1


def _service_line_anchor_utc_now():
    try:
        return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    except Exception:
        return ''


def _service_line_anchor_repo_root():
    try:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        return os.getcwd()


def _service_line_anchor_exc_payload(exc):
    payload = {
        'exception_class': exc.__class__.__name__ if exc is not None else '',
        'exception_message': str(exc or ''),
    }
    try:
        lines = traceback.format_exc().splitlines()
        payload['traceback_tail'] = lines[-20:]
    except Exception:
        payload['traceback_tail'] = []
    try:
        winerror = getattr(exc, 'winerror', None)
        if winerror is not None:
            payload['winerror'] = winerror
    except Exception:
        pass
    try:
        errno = getattr(exc, 'errno', None)
        if errno is not None:
            payload['errno'] = errno
    except Exception:
        pass
    return payload


def _service_line_anchor_file_fingerprint(path):
    out = {
        'path': path or '',
        'exists': False,
        'size_bytes': 0,
        'sha256_prefix': '',
    }
    if not path:
        return out
    try:
        out['exists'] = os.path.isfile(path)
        if not out['exists']:
            return out
        out['size_bytes'] = os.path.getsize(path)
        digest = hashlib.sha256()
        with open(path, 'rb') as handle:
            while True:
                chunk = handle.read(65536)
                if not chunk:
                    break
                digest.update(chunk)
        out['sha256_prefix'] = digest.hexdigest()[:16]
    except Exception as e:
        out['fingerprint_error'] = str(e)
    return out


def _service_line_anchor_load_config_for_status():
    try:
        from MediCafe.MediLink_ConfigLoader import load_configuration, get_last_load_diagnostics
        config, _crosswalk = load_configuration()
        diag = {}
        try:
            diag = get_last_load_diagnostics() or {}
        except Exception:
            diag = {}
        return config or {}, {
            'status': 'ok',
            'path_source': diag.get('path_source', ''),
            'config_path': diag.get('config_path', ''),
            'crosswalk_path': diag.get('crosswalk_path', ''),
            'overall_status': diag.get('overall_status', ''),
        }
    except Exception as e:
        return {}, {
            'status': 'failed',
            'error': _service_line_anchor_exc_payload(e),
        }


def _service_line_anchor_storage_from_config(config):
    try:
        medi = config.get('MediLink_Config', {}) if isinstance(config, dict) else {}
        path = medi.get('local_storage_path') or config.get('local_storage_path') or ''
        return path
    except Exception:
        return ''


def _service_line_anchor_candidate_report_dirs(config):
    dirs = []
    storage = _service_line_anchor_storage_from_config(config)
    if storage:
        dirs.append(os.path.join(storage, 'reports'))
    fallback = os.environ.get('MEDICAFE_SERVICE_LINE_ANCHOR_FALLBACK_DIR', '')
    if fallback:
        dirs.append(os.path.join(fallback, 'reports'))
    dirs.append(os.path.join(os.getcwd(), 'reports'))
    seen = {}
    out = []
    for directory in dirs:
        if not directory:
            continue
        try:
            key = os.path.abspath(directory)
        except Exception:
            key = directory
        if key in seen:
            continue
        seen[key] = True
        out.append(directory)
    return out


def _service_line_anchor_write_status_file(path, payload, text=False):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, 'w') as handle:
        if text:
            handle.write('Service Line Input charge-anchor Option H status\n')
            handle.write('schema_version={0}\n'.format(payload.get('schema_version', '')))
            handle.write('status={0}\n'.format(payload.get('status', '')))
            handle.write('failure_stage={0}\n'.format(payload.get('failure_stage', '')))
            handle.write('returncode={0}\n'.format(payload.get('returncode', '')))
            handle.write('helper_load_method={0}\n'.format(payload.get('helper_load_method', '')))
            handle.write('helper_path={0}\n'.format(payload.get('helper_path', '')))
            summary = payload.get('summary') if isinstance(payload.get('summary'), dict) else {}
            if summary:
                handle.write('anchor_count={0}\n'.format(summary.get('anchor_count', '')))
                handle.write('dat_record_count={0}\n'.format(summary.get('dat_record_count', '')))
                handle.write('x12_row_count={0}\n'.format(summary.get('x12_row_count', '')))
            error = payload.get('error') if isinstance(payload.get('error'), dict) else {}
            if error:
                handle.write('exception_class={0}\n'.format(error.get('exception_class', '')))
                handle.write('exception_message={0}\n'.format(error.get('exception_message', '')))
        else:
            json.dump(payload, handle, ensure_ascii=True, indent=2, sort_keys=True)
            handle.write('\n')


def _write_service_line_anchor_action_status(payload, config=None):
    data = dict(payload or {})
    data.setdefault('schema_version', SERVICE_LINE_ANCHOR_ACTION_STATUS_SCHEMA)
    data.setdefault('workflow_name', 'service_line_input')
    data.setdefault('workflow_boundary', 'report_only_review_required')
    data.setdefault('claims_completion', False)
    data.setdefault('mutates_billing_state', False)
    data.setdefault('mutates_dat', False)
    data.setdefault('mutates_837p', False)
    data.setdefault('charges_entered', False)
    data.setdefault('updated_at_utc', _service_line_anchor_utc_now())
    data.setdefault('runtime', {
        'python_exe': sys.executable,
        'python_version': sys.version,
        'cwd': os.getcwd(),
        'repo_root': _service_line_anchor_repo_root(),
    })
    errors = []
    written = {}
    for reports_dir in _service_line_anchor_candidate_report_dirs(config or {}):
        json_path = os.path.join(reports_dir, SERVICE_LINE_ANCHOR_ACTION_STATUS_BASENAME + '.json')
        txt_path = os.path.join(reports_dir, SERVICE_LINE_ANCHOR_ACTION_STATUS_BASENAME + '.txt')
        try:
            _service_line_anchor_write_status_file(json_path, data, text=False)
            _service_line_anchor_write_status_file(txt_path, data, text=True)
            written = {'json': json_path, 'txt': txt_path}
            break
        except Exception as e:
            errors.append({
                'reports_dir': reports_dir,
                'error': _service_line_anchor_exc_payload(e),
            })
    if errors and not written:
        data['status_write_errors'] = errors
    return written


def _send_service_line_anchor_report(status, payload, paths, config):
    try:
        from MediCafe.error_reporter import email_service_line_charge_anchor_report_flow
    except Exception as e:
        return {
            'status': 'failed',
            'stage': 'import_report_sender',
            'reason_code': 'report_sender_import_failed',
            'exception_class': e.__class__.__name__,
            'exception_message': str(e),
            'exit_code': 1,
        }
    try:
        return email_service_line_charge_anchor_report_flow(
            status=status,
            payload=payload,
            artifacts=paths,
            local_storage_path=_service_line_anchor_storage_from_config(config),
        )
    except Exception as e:
        return {
            'status': 'failed',
            'stage': 'send_report_bundle',
            'reason_code': 'exception',
            'exception_class': e.__class__.__name__,
            'exception_message': str(e),
            'exit_code': 1,
        }


def run_service_line_charge_anchor_index(send_report=False):
    """Build the review-only local Service Line Input charge-anchor index."""
    started = time.time()
    config_for_status, config_status = _service_line_anchor_load_config_for_status()
    status = {
        'schema_version': SERVICE_LINE_ANCHOR_ACTION_STATUS_SCHEMA,
        'command': 'build_service_line_charge_anchor_index',
        'status': 'started',
        'started_at_utc': _service_line_anchor_utc_now(),
        'config_loader': config_status,
        'runtime': {
            'python_exe': sys.executable,
            'python_version': sys.version,
            'cwd': os.getcwd(),
            'repo_root': _service_line_anchor_repo_root(),
        },
        'workflow_name': 'service_line_input',
        'workflow_boundary': 'report_only_review_required',
        'claims_completion': False,
        'mutates_billing_state': False,
        'mutates_dat': False,
        'mutates_837p': False,
        'charges_entered': False,
    }
    _write_service_line_anchor_action_status(status, config_for_status)
    try:
        from scripts.unified_model import build_service_line_charge_anchor_index as anchor_index
        status['helper_load_method'] = 'package_import'
        status['helper_path'] = getattr(anchor_index, '__file__', '')
    except Exception:
        status['package_import_error'] = _service_line_anchor_exc_payload(sys.exc_info()[1])
        try:
            from MediCafe.shadow_orchestrator import resolve_unified_model_script
            import imp
            repo_root = _service_line_anchor_repo_root()
            resolved = resolve_unified_model_script(
                repo_root,
                'build_service_line_charge_anchor_index.py',
                python_exe=sys.executable,
            )
            if isinstance(resolved, tuple):
                script_path = resolved[1]
                status['resolver_repo_root'] = resolved[0]
                status['resolver_checks'] = resolved[2]
            else:
                script_path = resolved
            status['helper_load_method'] = 'imp_load_source'
            status['helper_path'] = script_path
            anchor_index = imp.load_source('_medicafe_service_line_charge_anchor_index_cli', script_path)
        except Exception as e:
            status['status'] = 'failed'
            status['failure_stage'] = 'helper_load'
            status['returncode'] = 1
            status['error'] = _service_line_anchor_exc_payload(e)
            status['finished_at_utc'] = _service_line_anchor_utc_now()
            status['elapsed_ms'] = int((time.time() - started) * 1000)
            _write_service_line_anchor_action_status(status, config_for_status)
            print("Error: Unable to load charge-anchor index helper: {0}".format(e))
            return 1
    status['helper_fingerprint'] = _service_line_anchor_file_fingerprint(status.get('helper_path', ''))
    try:
        payload, paths = anchor_index.run(config=config_for_status, write_index=True)
        summary = payload.get('summary') if isinstance(payload, dict) else {}
        status['status'] = 'succeeded'
        status['failure_stage'] = ''
        status['returncode'] = 0
        status['summary'] = summary if isinstance(summary, dict) else {}
        if isinstance(summary, dict):
            if summary.get('advisory_code'):
                status['advisory_code'] = summary.get('advisory_code')
            if summary.get('advisory_detail'):
                status['advisory_detail'] = summary.get('advisory_detail')
        status['artifact_paths'] = paths if isinstance(paths, dict) else {}
        status['finished_at_utc'] = _service_line_anchor_utc_now()
        status['elapsed_ms'] = int((time.time() - started) * 1000)
        _write_service_line_anchor_action_status(status, config_for_status)
        for line in anchor_index.format_summary_lines(payload):
            print(line)
        print("Report JSON: {0}".format(paths.get('summary_json', '')))
        print("Anchor index: {0}".format(paths.get('state_path', '')))
        if send_report:
            print("Emailing Option H charge-anchor report bundle...")
            report_result = _send_service_line_anchor_report(status, payload, paths, config_for_status)
            status['report_bundle'] = report_result
            status['updated_at_utc'] = _service_line_anchor_utc_now()
            _write_service_line_anchor_action_status(status, config_for_status)
            if report_result.get('exit_code', 0) != 0:
                print("Option H report bundle was not sent: {0}".format(report_result.get('reason_code', 'unknown')))
                return 1
            if report_result.get('status') == 'sent':
                print("Option H report bundle emailed.")
            else:
                print("Option H report bundle created; email delivery is pending.")
        return 0
    except Exception as e:
        status['status'] = 'failed'
        status['failure_stage'] = 'helper_run'
        status['returncode'] = 1
        status['error'] = _service_line_anchor_exc_payload(e)
        status['finished_at_utc'] = _service_line_anchor_utc_now()
        status['elapsed_ms'] = int((time.time() - started) * 1000)
        _write_service_line_anchor_action_status(status, config_for_status)
        print("Error: Service Line Input charge-anchor index failed: {0}".format(e))
        return 1



def run_csv_excluded_insurance_analytics(send_report=False):
    from MediCafe.core_utils import get_config_loader_with_fallback
    config_loader = get_config_loader_with_fallback()
    config = {}
    if hasattr(config_loader, 'load_configuration'):
        loaded = config_loader.load_configuration()
        if isinstance(loaded, tuple):
            config = loaded[0] or {}
        else:
            config = loaded or {}
    elif hasattr(config_loader, 'load_config'):
        config = config_loader.load_config() or {}
    if not isinstance(config, dict):
        config = {}
    csv_path = config.get('CSV_FILE_PATH')
    storage = config.get('local_storage_path') or os.path.join(os.getcwd(), 'lab')
    report_dir = os.path.join(storage, 'reports')
    from MediBot import csv_excluded_insurance_analytics as analytics
    payload, paths = analytics.run(csv_path, report_dir)
    print('CSV excluded-insurance analysis complete.')
    print('Report JSON: {0}'.format(paths.get('json_path', '')))
    print('Report TXT:  {0}'.format(paths.get('txt_path', '')))
    if send_report:
        temporary_policy_note = getattr(
            analytics,
            'TEMPORARY_OPENNESS_POLICY_NOTE',
            (
                'Temporary policy: excluded-insurance analytics may include broader detail '
                'during design/stabilization; once stable, reduce detail via obfuscation or '
                'stop collecting extra data.'
            )
        )
        from MediCafe.error_reporter import collect_support_bundle, submit_support_bundle_email
        bundle = collect_support_bundle(
            include_traceback=False,
            extra_meta={
                'bundle_kind': 'csv_excluded_insurance_analytics_report',
                'error_summary': 'CSV excluded-insurance retrospective analysis report',
                'temporary_openness_policy_note': temporary_policy_note,
            },
            extra_files=[
                ('csv_excluded_insurance_analytics_latest.json', paths.get('json_path')),
                ('csv_excluded_insurance_analytics_latest.txt', paths.get('txt_path')),
            ],
        )
        sent = submit_support_bundle_email(bundle, include_traceback=False)
        if sent:
            print('CSV excluded-insurance report bundle emailed.')
        else:
            print('CSV excluded-insurance report bundle created; email delivery is pending.')
    return 0

def main():
    """Main entry point for MediCafe"""
    # Set up paths first
    setup_entry_point_paths()
    
    # Create argument parser
    parser = argparse.ArgumentParser(
        description='MediCafe - Medical Practice Management Automation Suite',
        prog='python -m MediCafe'
    )
    
    parser.add_argument(
        'command',
        choices=[
            'launcher',
            'medibot',
            'medilink',
            'claims_status',
            'deductible',
            'download_emails',
            'cloud_daemon',
            'send_error_report',
            'send_queued_error_reports',
            'send_cpt_dx_review',
            'send_minutes_charge_review',
            'build_service_line_charge_anchor_index',
            'version',
            'docx_index_rebuild',
            'docx_index_retry_failed',
            'csv_metadata_index_rebuild',
            'preflight',
            'reconcile',
            'analyze_csv_excluded_insurance'
        ],
        help='Command to execute'
    )
    
    parser.add_argument(
        'config_file',
        nargs='?',
        help='Configuration file path (for medibot command)'
    )
    
    # Parse arguments
    if len(sys.argv) < 2:
        parser.print_help()
        return 1
        
    args = parser.parse_args()
    
    # Route to appropriate function based on command
    try:
        if args.command == 'launcher':
            # Launcher has its own argument parser, so pass remaining args
            # Detect position of the 'launcher' token regardless of how python -m invoked us
            from MediCafe.launcher import main as launcher_main
            # Temporarily replace sys.argv so launcher's parser works correctly
            original_argv = sys.argv
            try:
                try:
                    launcher_index = original_argv.index('launcher')
                except ValueError:
                    launcher_index = 1  # default: treat everything after module as launcher args
                launcher_args = original_argv[launcher_index + 1:] if launcher_index + 1 < len(original_argv) else []
                sys.argv = [original_argv[0]] + launcher_args
                return launcher_main()
            finally:
                sys.argv = original_argv
        elif args.command == 'medibot':
            return run_medibot(args.config_file)
        elif args.command == 'medilink':
            return run_medilink()
        elif args.command == 'claims_status':
            return run_claims_status()
        elif args.command == 'deductible':
            return run_deductible()
        elif args.command == 'download_emails':
            return run_download_emails()
        elif args.command == 'cloud_daemon':
            return run_cloud_daemon(args.config_file)
        elif args.command == 'send_error_report':
            # Import lazily and call directly to avoid middlemen
            from MediCafe.error_reporter import email_test_error_report_flow
            return email_test_error_report_flow()
        elif args.command == 'send_queued_error_reports':
            from MediCafe.error_reporter import resolve_queued_bundles_flow
            return resolve_queued_bundles_flow()
        elif args.command == 'send_cpt_dx_review':
            from MediCafe.error_reporter import email_x12_cpt_dx_analytics_flow
            return email_x12_cpt_dx_analytics_flow()
        elif args.command == 'send_minutes_charge_review':
            from MediCafe.error_reporter import email_x12_minutes_charge_analytics_flow
            return email_x12_minutes_charge_analytics_flow()
        elif args.command == 'build_service_line_charge_anchor_index':
            return run_service_line_charge_anchor_index(send_report=True)
        elif args.command == 'version':
            return show_version()
        elif args.command == 'docx_index_rebuild':
            return run_docx_index_rebuild()
        elif args.command == 'docx_index_retry_failed':
            return run_docx_index_retry_failed()
        elif args.command == 'csv_metadata_index_rebuild':
            return run_csv_metadata_index_rebuild()
        elif args.command == 'preflight':
            from MediCafe.preflight import run_preflight, format_preflight_report
            exit_code, report = run_preflight()
            format_preflight_report(report)
            return exit_code
        elif args.command == 'reconcile':
            return run_reconcile()
        elif args.command == 'analyze_csv_excluded_insurance':
            return run_csv_excluded_insurance_analytics(send_report=True)
        else:
            print("Unknown command: {}".format(args.command))
            parser.print_help()
            return 1
            
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        return 1
    except Exception as e:
        print("Unexpected error: {}".format(e))
        return 1

if __name__ == '__main__':
    exit_code = main()
    sys.exit(exit_code)
