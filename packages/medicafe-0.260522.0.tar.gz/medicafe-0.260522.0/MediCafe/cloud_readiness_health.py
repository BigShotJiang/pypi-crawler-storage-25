#!/usr/bin/env python
"""
Cloud readiness health snapshot helpers for launcher menus.

Keeps health interpretation and ASCII rendering out of launcher.py so the
menu code can stay focused on routing actions.
"""
from __future__ import print_function

import json
import os
import textwrap

try:
    from MediCafe import cloud_readiness_artifact_tools as _artifact_tools
except Exception:
    try:
        import cloud_readiness_artifact_tools as _artifact_tools
    except Exception:
        _artifact_tools = None

try:
    from MediCafe import cloud_readiness_patient_tools as _patient_tools
except Exception:
    try:
        import cloud_readiness_patient_tools as _patient_tools
    except Exception:
        _patient_tools = None


_STATUS_MARK = {
    "ok": "+",
    "warn": "!",
    "fail": "x",
    "unknown": "?",
    "running": "~",
}

_STATUS_LABEL = {
    "ok": "OK",
    "warn": "WARN",
    "fail": "FAIL",
    "unknown": "UNKNOWN",
    "running": "RUNNING",
}

_PHASE_ORDER = {
    "A": 1,
    "B": 2,
    "C": 3,
    "D": 4,
    "E": 5,
    "F": 6,
}

# Operator console width guideline (~130 cols) for health snapshot framing and wrapped rows.
_HEALTH_SNAPSHOT_LINE_MAX = 130

_HEALTH_DIAGNOSTIC_LOG_SIGNATURE_COUNTS = {}
_HEALTH_ESCALATION_LOG_SIGNATURE_COUNTS = {}


def _safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


if _artifact_tools is not None:
    _safe_load_json = _artifact_tools._shared_load_json_dict
else:
    def _safe_load_json(path):
        if not path or not os.path.exists(path):
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
        except (IOError, OSError, ValueError):
            pass
        return {}


def _issue_severity_rank(severity):
    severity = str(severity or "").strip().lower()
    if severity == "fail":
        return 3
    if severity == "warn":
        return 2
    return 1


def _normalize_issue_severity(severity, fallback="warn"):
    severity = str(severity or "").strip().lower()
    if severity in ("fail", "warn", "ok"):
        return severity
    return fallback


def _is_phase_d_remediation_active(remediation):
    rem = remediation if isinstance(remediation, dict) else {}
    if not rem:
        return False
    status = str(rem.get("status", "") or "").strip().lower()
    issue_code = str(rem.get("issue_code", "") or "").strip()
    resolved_statuses = set(["resolved", "closed", "complete", "completed", "ok", "not_applicable"])
    if status in resolved_statuses:
        return False
    if status and status not in resolved_statuses:
        return True
    if rem.get("milestone_exit_ready") is False:
        return True
    if issue_code and status not in resolved_statuses:
        return True
    return False


def _phase_d_remediation_message(remediation):
    rem = remediation if isinstance(remediation, dict) else {}
    parts = []
    for key in ("issue_code", "status", "verification_target", "verification_scope", "context_run_id"):
        val = str(rem.get(key, "") or "").strip()
        if val:
            parts.append("{0}={1}".format(key, val))
    if rem.get("milestone_exit_ready") is not None:
        parts.append("milestone_exit_ready={0}".format(bool(rem.get("milestone_exit_ready"))))
    if not parts:
        parts.append("active remediation context present")
    parts.append(
        "note=DAT-lane remediation can be resolved without full milestone exit unless milestone_exit_ready=true"
    )
    return "Phase D remediation blocker: {0}.".format(", ".join(parts))


def _diagnostic_issue_signature(issue):
    issue = issue if isinstance(issue, dict) else {}
    return (
        str(issue.get('severity', '') or '').strip().lower(),
        str(issue.get('code', '') or '').strip(),
        str(issue.get('message', '') or '').strip(),
    )


def _log_health_diagnostic_issue(issue):
    signature = _diagnostic_issue_signature(issue)
    count = int(_HEALTH_DIAGNOSTIC_LOG_SIGNATURE_COUNTS.get(signature, 0) or 0) + 1
    _HEALTH_DIAGNOSTIC_LOG_SIGNATURE_COUNTS[signature] = count
    severity = signature[0]
    code = signature[1] or 'UNKNOWN_ISSUE'
    message = signature[2]
    if count == 1:
        level = 'ERROR' if severity == 'fail' else 'WARNING'
        detail = message
    else:
        level = 'DEBUG'
        detail = 'repeat suppressed ({0}x): {1}'.format(count, message)
    _log_health(level, 'Cloud readiness diagnostics [{0}] count-tracked: {1}'.format(code, detail))


def _health_escalation_signature(diagnostics, tracker_info):
    issues = diagnostics.get('issues', []) if isinstance(diagnostics, dict) else []
    parts = []
    for issue in issues:
        sig = _diagnostic_issue_signature(issue)
        parts.append('{0}:{1}:{2}'.format(sig[0], sig[1], sig[2]))
    try:
        parts.sort()
    except Exception:
        pass
    codes = tracker_info.get('escalated_codes', []) if isinstance(tracker_info, dict) else []
    code_parts = [str(code or '') for code in codes]
    try:
        code_parts.sort()
    except Exception:
        pass
    return 'codes={0}|issues={1}'.format(','.join(code_parts), '|'.join(parts))


def _log_health_escalation(tracker_info, diagnostics):
    signature = _health_escalation_signature(diagnostics, tracker_info)
    count = int(_HEALTH_ESCALATION_LOG_SIGNATURE_COUNTS.get(signature, 0) or 0) + 1
    _HEALTH_ESCALATION_LOG_SIGNATURE_COUNTS[signature] = count
    codes = ', '.join(tracker_info.get('escalated_codes', []))
    if count == 1:
        _log_health('WARNING', 'Cloud readiness escalation triggered for: {0}'.format(codes))
    else:
        _log_health(
            'DEBUG',
            'Cloud readiness escalation repeat suppressed count={0} for unchanged issue signature: {1}'.format(
                count,
                codes,
            ),
        )


def _short_state_error_message(state):
    state = state if isinstance(state, dict) else {}
    parts = []
    code = str(state.get("last_error_code", "") or "").strip()
    if code:
        parts.append("last_error_code={0}".format(code))
    detail = str(state.get("last_error_detail", "") or "").strip()
    if detail:
        parts.append("detail={0}".format(detail))
    recoverability = str(state.get("last_error_recoverability", "") or "").strip()
    if recoverability:
        parts.append("recoverability={0}".format(recoverability))
    exc = str(state.get("last_error_source_exception_class", "") or "").strip()
    if exc:
        parts.append("source_exception_class={0}".format(exc))
    if not parts:
        parts.append("last error context present")
    return "Diagnostics state active error: {0}.".format(", ".join(parts))


def _shadow_pipeline_error_message(state):
    state = state if isinstance(state, dict) else {}
    parts = []
    code = str(state.get("last_shadow_pipeline_error_code", "") or "").strip()
    if code:
        parts.append("error_code={0}".format(code))
    failed_phase = str(state.get("last_shadow_pipeline_failed_phase", "") or "").strip()
    if failed_phase:
        parts.append("failed_phase={0}".format(failed_phase))
    outcome = str(state.get("last_shadow_pipeline_outcome", "") or "").strip()
    if outcome:
        parts.append("outcome={0}".format(outcome))
    run_id = str(state.get("last_shadow_pipeline_run_id", "") or "").strip()
    if run_id:
        parts.append("run_id={0}".format(run_id))
    if not parts:
        parts.append("pipeline failure context present")
    return "Shadow pipeline active blocker: {0}.".format(", ".join(parts))


def _pid_running(pid):
    try:
        pid_int = int(pid)
    except (ValueError, TypeError):
        return False
    if pid_int <= 0:
        return False

    if os.name == "nt":
        from MediCafe.win_pid_probe import windows_process_is_alive_or_unknown
        return windows_process_is_alive_or_unknown(pid_int)

    try:
        os.kill(pid_int, 0)
        return True
    except OSError:
        return False


def is_pipeline_running(lab_root):
    """Check if shadow pipeline is running via lock file. Returns bool."""
    if not lab_root:
        return False
    lock_path = os.path.join(lab_root, 'shadow_pipeline.lock')
    running = _pipeline_running(lock_path)
    if running:
        return True
    # If the lock exists but no live PID owns it, treat it as stale and clear it
    # so XP operators do not need to manually remove dead locks.
    if os.path.exists(lock_path):
        try:
            os.remove(lock_path)
        except (IOError, OSError):
            pass
    return False


def _pipeline_running(lock_path):
    if not lock_path or not os.path.exists(lock_path):
        return False
    pid = None
    try:
        with open(lock_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("pid="):
                    pid = line[4:].strip()
                    break
    except (IOError, OSError):
        return True
    if pid is None or not str(pid).strip():
        return True
    return _pid_running(pid)


def _phase_status_from_bool(ok_value):
    if ok_value is True:
        return "ok"
    if ok_value is False:
        return "fail"
    return "unknown"


def _collect_data_plane_snapshot(lab_root):
    """Best-effort data-plane counters for inline health rendering."""
    if _patient_tools is None:
        return None
    try:
        return _patient_tools.collect_data_plane_snapshot(lab_root, safe_int_fn=_safe_int)
    except Exception:
        return None


def _build_data_plane_health_rows(snapshot):
    """Return compact one-line DB counters for the top health block."""
    snap = snapshot if isinstance(snapshot, dict) else {}
    if not snap:
        return ["Data Plane: status=UNKNOWN (snapshot unavailable)"]
    if not snap.get("ok"):
        err = str(snap.get("error", "") or "unknown")
        return ["Data Plane: status=FAIL, error={0}".format(err)]

    counts = snap.get("counts", {}) if isinstance(snap.get("counts", {}), dict) else {}
    status = str(snap.get("status", "unknown") or "unknown").upper()
    patient_rows = _safe_int(counts.get("patient"), 0)
    patient_count = _safe_int(
        snap.get("patient_count_effective"),
        _safe_int(snap.get("patient_latest_identity_count"), patient_rows))
    qa_reject = _safe_int(snap.get("qa_reject_count_effective"), _safe_int(snap.get("qa_reject_count"), 0))
    proj_success = _safe_int(
        snap.get("projection_success_count_effective"),
        _safe_int(snap.get("projection_success_count"), 0))
    proj_reject = _safe_int(
        snap.get("projection_reject_count_effective"),
        _safe_int(snap.get("projection_reject_count"), 0))
    qa_scope = str(snap.get("qa_scope_version", "") or "").strip()
    projection_scope = str(snap.get("projection_scope_version", "") or "").strip()
    row1 = (
        "Data Plane: status={0}, patient={1}, coverage={2}, encounter={3}".format(
            status,
            patient_count,
            _safe_int(counts.get("coverage"), 0),
            _safe_int(counts.get("encounter"), 0),
        )
    )
    if patient_rows != patient_count:
        row1 = (
            "Data Plane: status={0}, patient={1}, patient_rows={2}, coverage={3}, encounter={4}".format(
                status,
                patient_count,
                patient_rows,
                _safe_int(counts.get("coverage"), 0),
                _safe_int(counts.get("encounter"), 0),
            )
        )
    row2 = (
        "Row Totals: claim={0}, claim_line={1}, ingest_rows={2}, qa_rows={3}".format(
            _safe_int(counts.get("claim"), 0),
            _safe_int(counts.get("claim_line"), 0),
            _safe_int(counts.get("ingest_artifact"), 0),
            _safe_int(counts.get("qa_result"), 0),
        )
    )
    row3 = (
        "Row Totals: replay_rows={0}, canonical={1}, projection={2}".format(
            _safe_int(counts.get("replay_queue"), 0),
            _safe_int(counts.get("extracted_canonical_record"), 0),
            _safe_int(counts.get("projection_result"), 0),
        )
    )
    row4 = (
        "Quality: qa_reject={0}, replay_pending={1}, proj_success={2}, proj_reject={3}".format(
            qa_reject,
            _safe_int(snap.get("replay_pending_count"), 0),
            proj_success,
            proj_reject,
        )
    )
    row5 = (
        "Quality: orphan_claim_lines={0}, replay_pending=active backlog".format(
            _safe_int(snap.get("orphan_claim_lines"), 0),
        )
    )
    out = [row1, row2, row3, row4, row5]
    if qa_scope or projection_scope:
        out.append(
            "Quality Scope: qa_version={0}, projection_version={1}".format(
                qa_scope or "-",
                projection_scope or "-",
            )
        )
    return out


def _build_post_medisoft_rows(state):
    """Return compact DAT/post-MediSoft actuals for launcher health output."""
    state = state if isinstance(state, dict) else {}
    b_dat = state.get("last_discovery_dat_telemetry", {}) if isinstance(state.get("last_discovery_dat_telemetry", {}), dict) else {}
    summary = _patient_tools.derive_post_medisoft_summary(state, _safe_int) if _patient_tools else {}
    status = str(summary.get("status", "not_exercised") or "not_exercised")
    blocked_stage = str(summary.get("blocked_stage", "") or "")

    return [
        "Post-MediSoft: status={0}, blocked={1}, manifest={2}".format(
            status.upper(),
            blocked_stage or "-",
            int(summary.get("manifest_rows", 0) or 0),
        ),
        "DAT Roots: cfg={0}, missing={1}, selected={2}, selection={3}".format(
            _safe_int(b_dat.get("dat_configured_root_count"), 0),
            _safe_int(b_dat.get("dat_configured_root_missing_count"), 0),
            _safe_int(b_dat.get("dat_selected_root_count"), 0),
            str(b_dat.get("dat_selection_mode") or "-") or "-",
        ),
        "DAT Roots Detail: selected={0}, empty={1}, effective={2}".format(
            str(b_dat.get("dat_selected_root_source_id") or "-") or "-",
            _safe_int(b_dat.get("dat_existing_empty_root_count"), 0),
            str(b_dat.get("dat_effective_root_source_id") or "-") or "-",
        ),
        "DAT Phase D: selected={0}, qa_pass={1}, qa_reject={2}, canonical={3}".format(
            int(summary.get("selected", 0) or 0),
            int(summary.get("qa_pass", 0) or 0),
            int(summary.get("qa_reject", 0) or 0),
            int(summary.get("canonical", 0) or 0),
        ),
    ]


def _phase_run_id(state, phase_code):
    """Resolve phase run_id, guarding against stale v2 maps on failed in-flight phases."""
    legacy_keys = {
        "B": "last_phase_b_run_id",
        "C": "last_phase_c_run_id",
        "D": "last_phase_d_run_id",
        "E": "last_phase_e_run_id",
    }
    key = legacy_keys.get(phase_code, "")
    legacy_rid = str(state.get(key, "") if key else "").strip()
    phase_map = state.get("last_shadow_pipeline_phase_run_ids", {})
    if isinstance(phase_map, dict):
        rid = phase_map.get(phase_code, "")
        mapped_rid = str(rid).strip() if rid else ""
        if mapped_rid and legacy_rid and mapped_rid != legacy_rid:
            active_phase = str(state.get("active_phase", "") or "").strip().upper()
            failed_phase = str(state.get("last_shadow_pipeline_failed_phase", "") or "").strip().upper()
            # Phase B persists discovery failures as last_discovery_error_code; tests may set last_phase_b_error_code.
            if phase_code == "B":
                phase_has_error = bool(
                    str(state.get("last_discovery_error_code", "") or "").strip()
                    or str(state.get("last_phase_b_error_code", "") or "").strip()
                )
            else:
                ek = "last_phase_{0}_error_code".format(str(phase_code or "").lower())
                phase_has_error = bool(str(state.get(ek, "") or "").strip())
            if active_phase == phase_code or failed_phase == phase_code or phase_has_error:
                return legacy_rid
        if mapped_rid:
            return mapped_rid
    return legacy_rid


def _stale_lock_already_removed_error(exc):
    """True when stale lock vanished between exists-check and remove()."""
    try:
        errno_value = int(getattr(exc, "errno", 0) or 0)
    except Exception:
        errno_value = 0
    if errno_value == 2:
        return True
    try:
        winerror_value = int(getattr(exc, "winerror", 0) or 0)
    except Exception:
        winerror_value = 0
    if winerror_value == 2:
        return True
    text = str(exc or "").lower()
    return "winerror 2" in text or "no such file" in text or "cannot find the file" in text


def _phase_pending(state, phase_code, run_id, status, err):
    lifecycle_state = str(state.get("pipeline_state", "") or "").strip().lower()
    if lifecycle_state not in ("bootstrapping", "running"):
        return False
    if run_id or status != "unknown" or err:
        return False
    active_phase = str(state.get("active_phase", "") or "").strip().upper()
    if not active_phase:
        return False
    return _PHASE_ORDER.get(phase_code, 99) >= _PHASE_ORDER.get(active_phase, 0)


def _build_phase_b(state):
    run_id = _phase_run_id(state, "B")
    err = state.get("last_discovery_error_code")
    status = _phase_status_from_bool(state.get("last_discovery_ok"))
    counts = state.get("last_discovery_counts_by_class", {})
    if not isinstance(counts, dict):
        counts = {}
    total = 0
    class_bits = []
    for key in sorted(counts.keys()):
        val = _safe_int(counts.get(key), 0)
        total += val
        class_bits.append("{0}:{1}".format(key, val))
    if status == "ok" and total <= 0:
        status = "warn"
    detail_parts = [
        "run_id={0}".format(run_id or "-"),
        "total={0}".format(total),
    ]
    if class_bits:
        detail_parts.append("classes={0}".format(",".join(class_bits)))
    if err:
        detail_parts.append("err={0}".format(err))
    elif status == "unknown" and not run_id:
        if _phase_pending(state, "B", run_id, status, err):
            status = "running"
            detail_parts.append("state=awaiting_phase_write")
        else:
            status = "warn"
            detail_parts.append("state=not_run")
    return {
        "code": "B",
        "name": "Discovery",
        "status": status,
        "detail": ", ".join(detail_parts),
    }


def _build_phase_c(state):
    run_id = _phase_run_id(state, "C")
    err = state.get("last_phase_c_error_code")
    status = _phase_status_from_bool(state.get("last_phase_c_ok"))
    anomalies = _safe_int(state.get("last_phase_c_anomaly_count"), 0)
    if status == "ok" and anomalies > 0:
        status = "warn"
    detail_parts = [
        "run_id={0}".format(run_id or "-"),
        "inserted={0}".format(_safe_int(state.get("last_ingest_rows_inserted"), 0)),
        "failed={0}".format(_safe_int(state.get("last_ingest_rows_failed"), 0)),
        "anomalies={0}".format(anomalies),
    ]
    if err:
        detail_parts.append("err={0}".format(err))
    elif status == "unknown" and not run_id:
        if _phase_pending(state, "C", run_id, status, err):
            status = "running"
            detail_parts.append("state=awaiting_phase_write")
        else:
            status = "warn"
            detail_parts.append("state=not_run")
    return {
        "code": "C",
        "name": "Ingest",
        "status": status,
        "detail": ", ".join(detail_parts),
    }


def _build_phase_d(state):
    run_id = _phase_run_id(state, "D")
    err = state.get("last_phase_d_error_code")
    status = _phase_status_from_bool(state.get("last_phase_d_ok"))
    rejects = _safe_int(state.get("last_phase_d_reject_count"), 0)
    if status == "ok" and rejects > 0:
        status = "warn"
    detail_parts = [
        "run_id={0}".format(run_id or "-"),
        "pass={0}".format(_safe_int(state.get("last_phase_d_pass_count"), 0)),
        "reject={0}".format(rejects),
    ]
    if err:
        detail_parts.append("err={0}".format(err))
    elif status == "unknown" and not run_id:
        if _phase_pending(state, "D", run_id, status, err):
            status = "running"
            detail_parts.append("state=awaiting_phase_write")
        else:
            status = "warn"
            detail_parts.append("state=not_run")
    return {
        "code": "D",
        "name": "QA",
        "status": status,
        "detail": ", ".join(detail_parts),
    }


def _build_phase_e(state):
    run_id = _phase_run_id(state, "E")
    err = state.get("last_phase_e_error_code")
    status = _phase_status_from_bool(state.get("last_phase_e_ok"))
    contract_parity = (state.get("last_contract_parity_status") or "").strip().lower()
    baseline_parity = (state.get("last_baseline_parity_status") or "").strip().lower()
    if contract_parity == "fail":
        status = "fail"
    elif status == "ok" and contract_parity != "pass":
        status = "warn"
    detail_parts = [
        "run_id={0}".format(run_id or "-"),
        "projected={0}".format(_safe_int(state.get("last_phase_e_projected_count"), 0)),
        "parity={0}".format(contract_parity or "-"),
        "baseline={0}".format(baseline_parity or "-"),
    ]
    if err:
        detail_parts.append("err={0}".format(err))
    elif status == "unknown" and not run_id:
        if _phase_pending(state, "E", run_id, status, err):
            status = "running"
            detail_parts.append("state=awaiting_phase_write")
        else:
            status = "warn"
            detail_parts.append("state=not_run")
    return {
        "code": "E",
        "name": "Projection",
        "status": status,
        "detail": ", ".join(detail_parts),
    }


def _build_phase_f(state, pipeline_running):
    outcome = str(state.get("last_shadow_pipeline_outcome", "") or "").strip().lower()
    lifecycle_state = (state.get("pipeline_state") or "").strip().lower()
    if lifecycle_state in ("bootstrapping", "running"):
        status = "running"
    elif outcome == "interrupted":
        status = "fail"
    elif lifecycle_state == "failed":
        status = "fail"
    elif lifecycle_state == "completed":
        status = "ok"
    elif pipeline_running:
        status = "running"
    else:
        status = _phase_status_from_bool(state.get("last_shadow_pipeline_ok"))
    run_id = state.get("active_run_id", "") or state.get("last_shadow_pipeline_run_id", "") or ""
    detail_parts = [
        "run_id={0}".format(run_id or "-"),
        "active_phase={0}".format(state.get("active_phase", "") or "-"),
        "failed_phase={0}".format(state.get("last_shadow_pipeline_failed_phase", "") or "-"),
    ]
    if outcome:
        detail_parts.append("outcome={0}".format(outcome))
    if outcome == "interrupted":
        detail_parts.append(
            "interrupted_phase={0}".format(state.get("last_shadow_pipeline_interrupt_phase", "") or state.get("last_shadow_pipeline_failed_phase", "") or "-")
        )
        hx = str(state.get("last_shadow_pipeline_interrupt_code_hex", "") or "").strip()
        if hx:
            detail_parts.append("interrupt_code={0}".format(hx))
    error_code = state.get("last_error_code", "") or state.get("last_shadow_pipeline_error_code", "")
    if error_code and status != "running":
        detail_parts.append("err={0}".format(error_code))
    lock_diag = state.get("last_phase_f_lock_diag_path", "") or ""
    if lock_diag:
        detail_parts.append("lock_diag={0}".format(os.path.basename(lock_diag)))
    elif status == "unknown" and not run_id:
        status = "warn"
        detail_parts.append("state=not_run")
    return {
        "code": "F",
        "name": "Shadow Health",
        "status": status,
        "detail": ", ".join(detail_parts),
    }


def _append_phase_snapshot_lines(lines, row, line_max=_HEALTH_SNAPSHOT_LINE_MAX):
    """Append one or more lines for a phase row; wrap detail so rows stay within line_max."""
    status = row.get("status", "unknown")
    mark = _STATUS_MARK.get(status, "?")
    label = _STATUS_LABEL.get(status, "UNKNOWN")
    code_mark = "{0}:{1}".format(row.get("code", "?"), mark)
    name = str(row.get("name", "Phase"))
    detail = str(row.get("detail", "") or "")
    prefix = "{0:<5} {1:<16} {2:<10} ".format(code_mark, name, label)
    try:
        prefix_len = len(prefix)
    except Exception:
        prefix_len = 34
    budget = max(20, int(line_max) - prefix_len)
    if not detail:
        lines.append(prefix.rstrip())
        return
    chunks = textwrap.wrap(detail, width=budget)
    if not chunks:
        lines.append(prefix.rstrip())
        return
    pad = " " * prefix_len
    for idx, chunk in enumerate(chunks):
        if idx == 0:
            lines.append(prefix + chunk)
        else:
            lines.append(pad + chunk)


def build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True):
    """
    Build an interpreted, ASCII-only health snapshot for phases B..F.
    Returns a list of printable lines.
    """
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    lock_path = os.path.join(lab_root, "shadow_pipeline.lock")
    state = _safe_load_json(state_path)
    pipeline_running = _pipeline_running(lock_path)
    data_plane_snapshot = _collect_data_plane_snapshot(lab_root)

    phase_rows = [
        _build_phase_b(state),
        _build_phase_c(state),
        _build_phase_d(state),
        _build_phase_e(state),
        _build_phase_f(state, pipeline_running),
    ]

    path_bits = []
    count_ok = 0
    count_warn = 0
    count_fail = 0
    count_unknown = 0
    count_running = 0
    for row in phase_rows:
        st = row.get("status", "unknown")
        mark = _STATUS_MARK.get(st, "?")
        path_bits.append("[{0}:{1}]".format(row.get("code", "?"), mark))
        if st == "ok":
            count_ok += 1
        elif st == "warn":
            count_warn += 1
        elif st == "fail":
            count_fail += 1
        elif st == "running":
            count_running += 1
        else:
            count_unknown += 1

    if count_fail > 0:
        overall = "FAIL"
    elif count_warn > 0:
        overall = "WARN"
    elif count_running > 0:
        overall = "RUNNING"
    elif count_unknown > 0:
        overall = "UNKNOWN"
    else:
        overall = "OK"
    total_phases = len(phase_rows)
    flow_visual = " -> ".join(path_bits)
    headline = "Pipeline Health: {0} ({1}/{2} phases healthy)".format(
        overall, count_ok, total_phases
    )
    counts_line = "Counts: OK {0} | WARN {1} | FAIL {2} | UNKNOWN {3} | RUNNING {4}".format(
        count_ok, count_warn, count_fail, count_unknown, count_running
    )
    dash_width = _HEALTH_SNAPSHOT_LINE_MAX
    inner_width = dash_width - 4

    def _dash_row(text):
        clean = str(text or "")
        if len(clean) > inner_width:
            clean = clean[:inner_width]
        return "| {0:<{1}} |".format(clean, inner_width)

    lines = []
    lines.append("Pipeline Health Snapshot")
    lines.append("+" + ("=" * (dash_width - 2)) + "+")
    lines.append(_dash_row(headline))
    lines.append(_dash_row("Flow: {0}".format(flow_visual)))
    lines.append(_dash_row(counts_line))
    for row_text in _build_post_medisoft_rows(state):
        lines.append(_dash_row(row_text))
    for row_text in _build_data_plane_health_rows(data_plane_snapshot):
        lines.append(_dash_row(row_text))
    lines.append("+" + ("-" * (dash_width - 2)) + "+")
    lines.append("{0:<5} {1:<16} {2:<10} {3}".format("Phase", "Name", "Status", "Details"))
    lines.append("-" * dash_width)
    for row in phase_rows:
        _append_phase_snapshot_lines(lines, row)

    if pipeline_running:
        lines.append("-" * dash_width)
        lines.append("Note: shadow_pipeline.lock is present; pipeline activity may still be in progress.")

    lines.append("-" * dash_width)
    lines.append(
        "Automation: pipeline_auto={0}, health_telemetry_auto={1}".format(
            bool(auto_pipeline), bool(auto_health)
        )
    )
    return lines


from functools import wraps


_LOCAL_HELPER_NAMES = set([
    '_cloud_readiness_module',
    '_sync_cloud_readiness_globals',
    '_with_cloud_readiness_globals',
    '_safe_int',
    '_safe_load_json',
    '_pid_running',
    'is_pipeline_running',
    '_pipeline_running',
    '_phase_status_from_bool',
    '_collect_data_plane_snapshot',
    '_build_data_plane_health_rows',
    '_build_post_medisoft_rows',
    '_phase_run_id',
    '_phase_pending',
    '_build_phase_b',
    '_build_phase_c',
    '_build_phase_d',
    '_build_phase_e',
    '_build_phase_f',
    'build_cloud_health_lines',
    '_collect_health_diagnostics',
    'ensure_lab_ready',
    'get_health_lines',
])


def _cloud_readiness_module():
    from MediCafe import cloud_readiness as _cr
    return _cr


def _sync_cloud_readiness_globals():
    cr = _cloud_readiness_module()
    g = globals()
    for name, value in cr.__dict__.items():
        if name.startswith('__') and name.endswith('__'):
            continue
        if name in _LOCAL_HELPER_NAMES:
            continue
        g[name] = value


def _with_cloud_readiness_globals(fn):
    @wraps(fn)
    def _wrapped(*args, **kwargs):
        _sync_cloud_readiness_globals()
        return fn(*args, **kwargs)
    return _wrapped

@_with_cloud_readiness_globals
def _collect_health_diagnostics(lab_root, auto_resolve=True):
    """Collect cloud readiness diagnostics and small auto-resolve actions."""
    diagnostics = {
        'severity': 'ok',
        'issues': [],
        'auto_resolved': [],
    }
    seen_issues = {}

    def _issue_scope_from_code(code, source):
        code_text = str(code or "")
        source_text = str(source or "")
        if code_text.startswith("PHASE_D") or source_text == "phase_d_remediation":
            return "unified_model_phase_d"
        if code_text.startswith("PHASE_F") or "SHADOW_PIPELINE" in code_text or source_text == "shadow_pipeline":
            return "shadow_pipeline"
        if code_text.startswith("PHASE_"):
            return "cloud_readiness_pipeline"
        if code_text.startswith("LAB_ROOT") or code_text.startswith("DIAGNOSTICS_STATE"):
            return "local_xp_runtime"
        return "cloud_readiness"

    def _issue_run_id_for_source(source, phase_code=''):
        if source == 'phase_d_remediation':
            rem = state.get('phase_d_remediation') if isinstance(state.get('phase_d_remediation'), dict) else {}
            return str(rem.get('context_run_id', '') or rem.get('remediation_context_run_id', '') or state.get('last_phase_d_run_id', '') or '').strip()
        if source == 'shadow_pipeline':
            return str(state.get('active_run_id', '') or state.get('last_shadow_pipeline_run_id', '') or '').strip()
        if phase_code:
            return _phase_run_id(state, phase_code)
        return str(state.get('active_run_id', '') or state.get('last_shadow_pipeline_run_id', '') or '').strip()

    def _add_issue(severity, code, message, source='health_diagnostics', scope='', run_id='', evidence_status='current_live'):
        severity = _normalize_issue_severity(severity)
        code = str(code or 'UNKNOWN_ISSUE').strip() or 'UNKNOWN_ISSUE'
        message = str(message or '').strip()
        key = (code, message)
        existing_idx = seen_issues.get(key)
        if existing_idx is None:
            seen_issues[key] = len(diagnostics['issues'])
            diagnostics['issues'].append({
                'severity': severity,
                'code': code,
                'message': message,
                'source': str(source or 'health_diagnostics').strip() or 'health_diagnostics',
                'scope': str(scope or _issue_scope_from_code(code, source)).strip(),
                'run_id': str(run_id or '').strip(),
                'evidence_status': str(evidence_status or 'current_live').strip(),
            })
        else:
            existing = diagnostics['issues'][existing_idx]
            if _issue_severity_rank(severity) > _issue_severity_rank(existing.get('severity')):
                existing['severity'] = severity
        if severity == 'fail':
            diagnostics['severity'] = 'fail'
        elif severity == 'warn' and diagnostics['severity'] == 'ok':
            diagnostics['severity'] = 'warn'

    if not lab_root:
        _add_issue('fail', 'LAB_ROOT_MISSING', 'Lab root is empty and cannot be evaluated.')
        return diagnostics
    if not os.path.isdir(lab_root):
        _add_issue('fail', 'LAB_ROOT_NOT_FOUND', _describe_lab_root_issue(lab_root))
        return diagnostics

    reports_dir = os.path.join(lab_root, 'reports')
    if not os.path.exists(reports_dir) and auto_resolve:
        try:
            os.makedirs(reports_dir)
            diagnostics['auto_resolved'].append('Created missing reports directory: {0}'.format(reports_dir))
        except (IOError, OSError) as e:
            _add_issue('warn', 'REPORTS_DIR_CREATE_FAILED', 'Failed to create reports directory: {0}'.format(e))

    lock_path = os.path.join(lab_root, 'shadow_pipeline.lock')
    if os.path.exists(lock_path):
        running = is_pipeline_running(lab_root)
        if not running and auto_resolve:
            try:
                os.remove(lock_path)
                diagnostics['auto_resolved'].append('Removed stale pipeline lock: {0}'.format(lock_path))
            except (IOError, OSError) as e:
                if _stale_lock_already_removed_error(e):
                    diagnostics['auto_resolved'].append(
                        'Stale pipeline lock already removed during cleanup: {0}'.format(lock_path)
                    )
                else:
                    _add_issue('warn', 'STALE_LOCK_REMOVE_FAILED', 'Failed to remove stale lock: {0}'.format(e))

    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    if not os.path.exists(state_path):
        if auto_resolve and _seed_diagnostics_state_if_missing(state_path):
            diagnostics['auto_resolved'].append('Seeded missing diagnostics_state.json: {0}'.format(state_path))
        else:
            _add_issue('warn', 'DIAGNOSTICS_STATE_MISSING', 'diagnostics_state.json was not found: {0}'.format(state_path))
            return diagnostics
    try:
        with open(state_path, 'r', encoding='utf-8') as f:
            state = json.load(f)
    except (IOError, OSError) as e:
        _add_issue('fail', 'DIAGNOSTICS_STATE_READ_FAILED', 'Could not read diagnostics_state.json: {0}'.format(e))
        return diagnostics
    except ValueError as e:
        _add_issue('fail', 'DIAGNOSTICS_STATE_INVALID_JSON', 'diagnostics_state.json has invalid JSON: {0}'.format(e))
        return diagnostics
    if not isinstance(state, dict):
        _add_issue('fail', 'DIAGNOSTICS_STATE_INVALID_TYPE', 'diagnostics_state.json root must be an object/dict.')
        return diagnostics

    lifecycle_state_precheck = str(state.get('pipeline_state', '') or '').strip().lower()
    outcome_completed = (
        state.get('last_shadow_pipeline_ok') is True
        or str(state.get('last_shadow_pipeline_outcome', '') or '').strip().lower() in ('completed', 'ok', 'success', 'succeeded')
    )
    if lifecycle_state_precheck == 'running' and outcome_completed:
        _add_issue(
            'warn',
            'PIPELINE_STATE_CURSOR_INCONSISTENT',
            'pipeline_state is running but the last shadow pipeline outcome indicates completion; review diagnostics_state/run_cursor coherence.',
            source='diagnostics_state',
            run_id=_issue_run_id_for_source('diagnostics_state', 'F'),
        )

    phase_specs = [
        ('B', 'last_phase_b_run_id', 'last_discovery_ok', 'last_discovery_error_code'),
        ('C', 'last_phase_c_run_id', 'last_phase_c_ok', 'last_phase_c_error_code'),
        ('D', 'last_phase_d_run_id', 'last_phase_d_ok', 'last_phase_d_error_code'),
        ('E', 'last_phase_e_run_id', 'last_phase_e_ok', 'last_phase_e_error_code'),
        ('F', 'last_shadow_pipeline_run_id', 'last_shadow_pipeline_ok', 'last_shadow_pipeline_error_code'),
    ]
    lifecycle_state = str(state.get('pipeline_state', '') or '').strip().lower()
    active_phase = str(state.get('active_phase', '') or '').strip().upper()
    phase_run_ids = state.get('last_shadow_pipeline_phase_run_ids', {})
    if not isinstance(phase_run_ids, dict):
        phase_run_ids = {}
    for phase, run_key, ok_key, err_key in phase_specs:
        run_id = ''
        if phase in ('B', 'C', 'D', 'E'):
            run_id = str(phase_run_ids.get(phase, '') or '').strip()
        if not run_id:
            run_id = str(state.get(run_key, '') or '').strip()
        ok_value = state.get(ok_key, None)
        err_value = str(state.get(err_key, '') or '').strip()
        pending_write = (
            lifecycle_state in ('bootstrapping', 'running')
            and not run_id
            and ok_value is None
            and not err_value
            and bool(active_phase)
            and _PHASE_ORDER.get(phase, 99) >= _PHASE_ORDER.get(active_phase, 0)
        )
        if not run_id and ok_value is None:
            if pending_write:
                continue
            _add_issue('warn', 'PHASE_{0}_NOT_RUN'.format(phase),
                       'Phase {0} has no run id and no completion state.'.format(phase))
        elif ok_value is False:
            if err_value:
                _add_issue('fail', 'PHASE_{0}_FAILED'.format(phase),
                           'Phase {0} failed with error_code={1}.'.format(phase, err_value),
                           source='diagnostics_state',
                           run_id=_issue_run_id_for_source('diagnostics_state', phase))
            else:
                _add_issue('warn', 'PHASE_{0}_ERROR_CODE_MISSING'.format(phase),
                           'Phase {0} failed with no error code.'.format(phase),
                           source='diagnostics_state')

    pipeline_outcome = str(state.get('last_shadow_pipeline_outcome', '') or '').strip().lower()
    pipeline_failed = (
        lifecycle_state == 'failed'
        or state.get('last_shadow_pipeline_ok') is False
        or pipeline_outcome in ('failed', 'interrupted')
    )
    if pipeline_failed:
        shadow_error = str(state.get('last_shadow_pipeline_error_code', '') or '').strip()
        if shadow_error or str(state.get('last_shadow_pipeline_failed_phase', '') or '').strip() or pipeline_outcome:
            _add_issue(
                'fail',
                'SHADOW_PIPELINE_ACTIVE_BLOCKER',
                _shadow_pipeline_error_message(state),
                source='shadow_pipeline',
                run_id=_issue_run_id_for_source('shadow_pipeline'),
            )
    last_error_code = str(state.get('last_error_code', '') or '').strip()
    if last_error_code and (pipeline_failed or lifecycle_state in ('failed', 'error')):
        _add_issue(
            'fail',
            'DIAGNOSTICS_STATE_LAST_ERROR',
            _short_state_error_message(state),
            source='diagnostics_state',
            run_id=_issue_run_id_for_source('diagnostics_state'),
        )

    phase_d_remediation = state.get('phase_d_remediation')
    if _is_phase_d_remediation_active(phase_d_remediation):
        rem = phase_d_remediation if isinstance(phase_d_remediation, dict) else {}
        rem_severity = _normalize_issue_severity(
            rem.get('severity', 'fail' if rem.get('blocker') is True else 'warn'),
            fallback='warn',
        )
        if rem.get('blocker') is True:
            rem_severity = 'fail'
        remediation_code = str(rem.get('issue_code', '') or '').strip()
        if remediation_code:
            _add_issue(
                rem_severity,
                remediation_code,
                _phase_d_remediation_message(rem),
                source='phase_d_remediation',
                run_id=_issue_run_id_for_source('phase_d_remediation'),
            )
        _add_issue(
            rem_severity,
            'PHASE_D_REMEDIATION_ACTIVE',
            _phase_d_remediation_message(rem),
            source='phase_d_remediation',
            run_id=_issue_run_id_for_source('phase_d_remediation'),
        )

    skip_counts = state.get('last_phase_d_constraint_skip_counts')
    if isinstance(skip_counts, dict):
        inv = int(skip_counts.get('patient_invalid_external_id', 0) or 0)
        if inv > 0:
            passes = int(state.get('last_phase_d_pass_count', 0) or 0)
            denom = max(passes, 1)
            ratio = float(inv) / float(denom)
            tmpl = (
                'Phase D skipped {0} patient upsert(s) (external patient ID not ^[0-9]{{5}}$). '
                'Approx. ratio vs qa_pass_count={1}: {2:.4f}. See rule_decision_log and latest qa_canonical_summary.'
            )
            msg = tmpl.format(inv, denom, ratio)
            fam = skip_counts.get('patient_invalid_external_id_by_pattern_family') or {}
            ac = skip_counts.get('patient_invalid_external_id_by_artifact_class') or {}
            if isinstance(fam, dict) and fam:
                top_f = sorted(fam.items(), key=lambda kv: (-int(kv[1] or 0), kv[0]))[:4]
                msg += ' Leading invalid-ID pattern families: {0}.'.format(
                    ', '.join('{0}:{1}'.format(str(k), int(v or 0)) for k, v in top_f)
                )
            if isinstance(ac, dict) and ac:
                top_a = sorted(ac.items(), key=lambda kv: (-int(kv[1] or 0), kv[0]))[:4]
                msg += ' Source artifact classes: {0}.'.format(
                    ', '.join('{0}:{1}'.format(str(k), int(v or 0)) for k, v in top_a)
                )
            if ratio > _PHASE_D_INVALID_EXTERNAL_ID_RATIO_PASS_MAX:
                _add_issue('warn', 'PHASE_D_INVALID_EXTERNAL_ID_ELEVATED', msg)
            else:
                _add_issue('warn', 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT', msg)
    return diagnostics

@_with_cloud_readiness_globals
def resolve_lab_root(repo_root):
    """Resolve lab root: MEDICAFE_LAB_DIR > repo_root/lab."""
    env_lab = os.environ.get('MEDICAFE_LAB_DIR', '').strip()
    if env_lab:
        # Accept quoted values from .bat/.ini wrappers and expand shell vars.
        if len(env_lab) >= 2 and env_lab[0] == env_lab[-1] and env_lab[0] in ('"', "'"):
            env_lab = env_lab[1:-1]
        env_lab = os.path.expandvars(os.path.expanduser(env_lab))
        # Auto-heal malformed Windows bootstrap values like:
        #   "C: C:\\Python34\\Lib\\site-packages\\lab"
        # Keep only the real absolute drive path fragment.
        malformed_prefix = re.match(r'^([A-Za-z]:)\s+([A-Za-z]:[\\/].+)$', env_lab)
        if malformed_prefix:
            env_lab = malformed_prefix.group(2)

        # Auto-heal common XP launcher drift where MEDICAFE_LAB_DIR points to
        # site-packages (or site-packages\MediCafe) instead of a dedicated
        # lab root directory.
        env_lab_norm = os.path.normpath(env_lab)
        env_lab_tail, env_lab_parent_tail = _tail_parts_cross_platform(env_lab_norm)
        if env_lab_tail in ('site-packages', 'medicafe') and (
                env_lab_tail == 'site-packages' or env_lab_parent_tail == 'site-packages'):
            env_lab = os.path.join(env_lab_norm, 'lab')

        # If a Windows absolute drive path is provided, do not run posix abspath
        # on it (would incorrectly prefix cwd when tests run on non-Windows hosts).
        if re.match(r'^[A-Za-z]:[\\/]', env_lab):
            return os.path.normpath(env_lab)

        # Re-check after unquoting/expansion: empty value must fall back to repo_root/lab
        # (os.path.abspath('') resolves to cwd, which would mask bad config and corrupt placement)
        if env_lab and env_lab.strip():
            return os.path.abspath(env_lab)
    return os.path.join(repo_root, 'lab')


def _log_ensure_lab_ready_event(level, event_name, fields):
    try:
        payload = []
        for key in sorted((fields or {}).keys()):
            value = fields.get(key)
            payload.append('{0}={1}'.format(str(key), str(value)))
        _log_health(level, 'ENSURE_LAB_READY {0} {1}'.format(str(event_name or ''), ' '.join(payload)).strip())
    except Exception:
        pass


def _ensure_lab_ready_status_message(base_message, selected_root, state_name, baseline_needed):
    parts = []
    text = str(base_message or '').strip()
    if text:
        parts.append(text)
    parts.append('lab_root={0}'.format(str(selected_root or '')))
    parts.append('state={0}'.format(str(state_name or 'unknown')))
    parts.append('baseline_needed={0}'.format(bool(baseline_needed)))
    return ' | '.join(parts)

@_with_cloud_readiness_globals
def ensure_lab_ready(repo_root, python_exe, env, env_flag_fn, skip_recent_success_autopipeline=False):
    """
    Gate before Cloud Readiness UI: ensure lab exists or run Phase A bootstrap.
    Returns (ok, message, None). Avoids concurrent Phase A (lock rejection) by
    checking pipeline running and respecting MEDICAFE_PHASE_A_AUTO_VALIDATE.
    When skip_recent_success_autopipeline is True (Cloud Readiness menu entry only), may skip
    automatic full pipeline after baseline if diagnostics and Phase F artifacts are coherent.
    """
    lab_root = resolve_lab_root(repo_root)
    if not lab_root or not str(lab_root).strip():
        diag_path = _write_bootstrap_diag(repo_root, lab_root, 'LAB_ROOT_EMPTY', {
            'flow_stage': 'resolve_lab_root',
        })
        _log_ensure_lab_ready_event('ERROR', 'lab_root_empty', {
            'repo_root': repo_root,
            'diag_path': diag_path,
        })
        return (False, _bootstrap_fail_message('LAB_ROOT_EMPTY', 'Lab root could not be resolved', diag_path), None)
    candidate_roots = [lab_root]
    default_lab = os.path.join(repo_root, 'lab')
    if default_lab not in candidate_roots:
        candidate_roots.append(default_lab)
    selected_root = lab_root
    selected_from_fallback = False
    for idx, candidate in enumerate(candidate_roots):
        probe = _probe_lab_root(candidate)
        if probe.get('is_dir') and probe.get('has_core_artifacts'):
            if candidate != lab_root:
                os.environ['MEDICAFE_LAB_DIR'] = candidate
            _log_ensure_lab_ready_event('INFO', 'ready_existing_lab', {
                'selected_lab_root': candidate,
                'selected_from_fallback': bool(candidate != lab_root),
                'has_core_artifacts': True,
            })
            return (True, '', None)
        if probe.get('pipeline_running'):
            if candidate != lab_root:
                os.environ['MEDICAFE_LAB_DIR'] = candidate
            msg = _ensure_lab_ready_status_message('Initialization in progress.', candidate, 'pipeline_running', not probe.get('has_core_artifacts'))
            _log_ensure_lab_ready_event('INFO', 'pipeline_running', {
                'selected_lab_root': candidate,
                'selected_from_fallback': bool(candidate != lab_root),
                'pipeline_running': True,
            })
            return (True, msg, None)
        if probe.get('is_dir'):
            selected_root = candidate
            selected_from_fallback = (idx > 0)
            break
    if selected_from_fallback and selected_root:
        os.environ['MEDICAFE_LAB_DIR'] = selected_root
    env_with_root = dict(env or {})
    env_with_root['MEDICAFE_LAB_DIR'] = selected_root
    baseline_needed = not _lab_has_core_artifacts(selected_root)
    try:
        baseline_result = shadow_orchestrator.start_or_attach_shadow_pipeline(
            action_id=shadow_orchestrator.ACTION_ENSURE_PHASE_A_ONLY,
            entrypoint=shadow_orchestrator.ENTRYPOINT_MENU,
            repo_root=repo_root,
            python_exe=python_exe,
            env=env_with_root,
            env_flag_fn=env_flag_fn,
            ops=_orchestrator_ops(),
        )
        ok, msg, payload = _coerce_orchestrator_result_to_legacy(baseline_result)
        _log_ensure_lab_ready_event('INFO' if ok else 'WARNING', 'baseline_result', {
            'selected_lab_root': selected_root,
            'baseline_needed': baseline_needed,
            'ok': ok,
            'error_code': baseline_result.get('error_code', '') if isinstance(baseline_result, dict) else '',
            'message': msg or '',
        })
        if not ok:
            _maybe_send_orchestrator_failure_report(
                repo_root=repo_root,
                lab_root=selected_root,
                orchestration_result=baseline_result,
                trigger='ensure_lab_ready_baseline',
            )
            return (ok, msg, payload)

        # When baseline had to be reconciled, continue into full pipeline start-or-attach
        # so users are not stranded at B-F "not_run" after lab regeneration/degradation repair.
        if baseline_needed and _should_skip_followup_full_pipeline_after_baseline(
            selected_root, env_with_root, skip_recent_success_autopipeline
        ):
            if ok and (baseline_result.get('error_code') == shadow_orchestrator.ERROR_READY_NOOP or not msg):
                msg = ''
            elif ok:
                msg = _ensure_lab_ready_status_message(msg or 'Baseline bootstrap accepted.', selected_root, 'baseline_only', baseline_needed)
            return (ok, msg, payload)

        if baseline_needed:
            pipeline_result = shadow_orchestrator.start_or_attach_shadow_pipeline(
                action_id=shadow_orchestrator.ACTION_MANUAL_FULL_PIPELINE,
                entrypoint=shadow_orchestrator.ENTRYPOINT_MENU,
                repo_root=repo_root,
                python_exe=python_exe,
                env=env_with_root,
                env_flag_fn=env_flag_fn,
                ops=_orchestrator_ops(),
            )
            ok, msg, payload = _coerce_orchestrator_result_to_legacy(
                pipeline_result, default_running_message='Initialization in progress.'
            )
            _log_ensure_lab_ready_event('INFO' if ok else 'WARNING', 'full_pipeline_result', {
                'selected_lab_root': selected_root,
                'baseline_needed': baseline_needed,
                'ok': ok,
                'error_code': pipeline_result.get('error_code', '') if isinstance(pipeline_result, dict) else '',
                'message': msg or '',
            })
            if not ok:
                _maybe_send_orchestrator_failure_report(
                    repo_root=repo_root,
                    lab_root=selected_root,
                    orchestration_result=pipeline_result,
                    trigger='ensure_lab_ready_pipeline',
                )
            elif ok and isinstance(pipeline_result, dict) and pipeline_result.get('error_code') == shadow_orchestrator.ERROR_READY_NOOP:
                msg = ''
            elif ok:
                msg = _ensure_lab_ready_status_message(msg or 'Initialization in progress.', selected_root, 'full_pipeline_accepted', baseline_needed)
            return (ok, msg, payload)

        if ok and (baseline_result.get("error_code") == shadow_orchestrator.ERROR_READY_NOOP or not msg):
            msg = ''
        elif ok:
            msg = _ensure_lab_ready_status_message(msg or 'Baseline bootstrap accepted.', selected_root, 'baseline_accepted', baseline_needed)
        return (ok, msg, payload)
    except Exception as e:
        diag_path = _write_bootstrap_diag(repo_root, lab_root, 'BOOTSTRAP_EXCEPTION', {
            'flow_stage': 'bootstrap_execute',
            'exception': str(e),
            'python_exe': python_exe,
            'target_folder': env.get('target_folder', ''),
            'source_folder': env.get('source_folder', ''),
        })
        _log_ensure_lab_ready_event('ERROR', 'bootstrap_exception', {
            'selected_lab_root': selected_root,
            'diag_path': diag_path,
            'exception': str(e),
        })
        return (False, _bootstrap_fail_message('BOOTSTRAP_EXCEPTION', str(e), diag_path), None)

@_with_cloud_readiness_globals
def get_health_lines(lab_root, env_flag_fn, send_escalation=True):
    """Return list of health lines. Uses build_cloud_health_lines or diagnostics_state fallback."""
    diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
    if _has_invalid_lab_root(diagnostics):
        tracker_info = {'escalated_codes': [], 'resolved_codes': []}
    else:
        tracker_info = _update_health_issue_tracker(lab_root, diagnostics)

    for issue in diagnostics.get('issues', []):
        _log_health_diagnostic_issue(issue)
    for resolved_code in tracker_info.get('resolved_codes', []):
        _log_health('INFO', 'Cloud readiness diagnostics resolved: {0}'.format(resolved_code))
    for fix in diagnostics.get('auto_resolved', []):
        _log_health('INFO', 'Cloud readiness auto-resolve: {0}'.format(fix))

    if tracker_info.get('escalated_codes'):
        _log_health_escalation(tracker_info, diagnostics)
        if send_escalation and _maybe_send_cloud_health_failure_report(lab_root, diagnostics, tracker_info):
            _log_health('WARNING', 'Cloud readiness escalation report submitted (or queued).')

    diagnostics_lines = []
    if diagnostics.get('issues'):
        diagnostics_lines.append('-' * _HEALTH_SNAPSHOT_LINE_MAX)
        diagnostics_lines.append('Diagnostics Summary:')
        for issue in diagnostics.get('issues', []):
            diagnostics_lines.append(' - [{0}] {1}: {2}'.format(
                str(issue.get('severity', 'warn')).upper(),
                issue.get('code', 'UNKNOWN_ISSUE'),
                issue.get('message', ''),
            ))
    if diagnostics.get('auto_resolved'):
        diagnostics_lines.append('Auto-resolved:')
        for fix in diagnostics.get('auto_resolved', []):
            diagnostics_lines.append(' - {0}'.format(fix))
    if tracker_info.get('escalated_codes'):
        diagnostics_lines.append('Escalated diagnostics: {0}'.format(', '.join(tracker_info.get('escalated_codes', []))))

    if build_cloud_health_lines:
        try:
            lines = build_cloud_health_lines(
                lab_root,
                auto_pipeline=env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True),
                auto_health=env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True),
            )
            if diagnostics_lines:
                lines.extend(diagnostics_lines)
            return lines
        except Exception as e:
            _log_health('ERROR', 'build_cloud_health_lines failed; using fallback: {0}'.format(e))
    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    if not os.path.exists(state_path):
        auto_pipeline = env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True)
        auto_health = env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True)
        lines = [
            'No diagnostics state found yet: {0}'.format(state_path),
            'Automation: pipeline_auto={0}, health_telemetry_auto={1}'.format(
                auto_pipeline, auto_health),
        ]
        if diagnostics_lines:
            lines.extend(diagnostics_lines)
        return lines
    try:
        with open(state_path, 'r', encoding='utf-8') as f:
            state = json.load(f)
        rid = state.get('last_shadow_pipeline_run_id', '')
        ok = state.get('last_shadow_pipeline_ok', False)
        failed = state.get('last_shadow_pipeline_failed_phase', '')
        parity = state.get('last_contract_parity_status', '')
        auto_pipeline = env_flag_fn('MEDICAFE_SHADOW_AUTO_PIPELINE', True)
        auto_health = env_flag_fn('MEDICAFE_SHADOW_SEND_HEALTH', True)
        lines = [
            'Last run: {0}, ok={1}, failed_phase={2}, parity={3}'.format(
                rid or '(none)', ok, failed or '-', parity or '-'),
            'Automation: pipeline_auto={0}, health_telemetry_auto={1}'.format(
                auto_pipeline, auto_health),
        ]
        if diagnostics_lines:
            lines.extend(diagnostics_lines)
        return lines
    except (IOError, OSError, ValueError) as e:
        _log_health('ERROR', 'Fallback diagnostics_state parse failed: {0}'.format(e))
        return diagnostics_lines
_IMPL__safe_int = _safe_int
_IMPL__safe_load_json = _safe_load_json
_IMPL__pid_running = _pid_running
_IMPL_is_pipeline_running = is_pipeline_running
_IMPL__pipeline_running = _pipeline_running
_IMPL__phase_status_from_bool = _phase_status_from_bool
_IMPL__collect_data_plane_snapshot = _collect_data_plane_snapshot
_IMPL__build_data_plane_health_rows = _build_data_plane_health_rows
_IMPL__build_post_medisoft_rows = _build_post_medisoft_rows
_IMPL__phase_run_id = _phase_run_id
_IMPL__phase_pending = _phase_pending
_IMPL__build_phase_b = _build_phase_b
_IMPL__build_phase_c = _build_phase_c
_IMPL__build_phase_d = _build_phase_d
_IMPL__build_phase_e = _build_phase_e
_IMPL__build_phase_f = _build_phase_f
_IMPL_build_cloud_health_lines = build_cloud_health_lines
_IMPL__collect_health_diagnostics = _collect_health_diagnostics
_IMPL_resolve_lab_root = resolve_lab_root
_IMPL_ensure_lab_ready = ensure_lab_ready
_IMPL_get_health_lines = get_health_lines
