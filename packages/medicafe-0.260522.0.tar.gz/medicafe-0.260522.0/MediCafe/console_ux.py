#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Console UX helpers for concise operator-facing output.

Default behavior favors signal-first messages. Detailed progress and diagnostic
chatter can be surfaced via performance/debug verbosity flags.
"""

from __future__ import print_function

import os

try:
    from MediCafe.logging_config import DEBUG, PERFORMANCE_LOGGING
except Exception:
    DEBUG = False
    PERFORMANCE_LOGGING = False


def _env_truthy(name):
    try:
        value = str(os.environ.get(name, '') or '').strip().lower()
    except Exception:
        return False
    return value in ('1', 'true', 'yes', 'on')


def is_verbose_console():
    """Return True when explicit verbose/debug console detail should print."""
    return bool(
        DEBUG
        or _env_truthy('MEDICAFE_VERBOSE_LOGGING')
        or _env_truthy('MEDICAFE_DEBUG')
    )


def emit_info(message, verbose_only=False):
    """Print routine operator info, optionally gated behind verbose mode."""
    if verbose_only and not is_verbose_console():
        return
    print(message)


def emit_warning(message):
    """Always print warnings."""
    print(message)


def emit_error(message):
    """Always print errors."""
    print(message)
