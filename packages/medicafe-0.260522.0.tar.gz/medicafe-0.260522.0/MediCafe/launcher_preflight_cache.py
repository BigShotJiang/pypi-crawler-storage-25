"""
Persistent startup preflight cache for launcher workflows.

This module is intentionally standalone and Python 3.4-compatible so XP
runtime code can decide whether a previously successful preflight is still
valid without importing launcher or preflight internals.
"""
from __future__ import print_function

import io
import json
import os
import time


CACHE_SCHEMA_VERSION = 1
RESULT_SUCCESS = 'success'
RESULT_FAILURE = 'failure'


def utc_now_string():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def _text(value):
    if value is None:
        return ''
    try:
        return str(value)
    except Exception:
        return ''


def _artifact_items(artifact_paths):
    if not artifact_paths:
        return []
    if isinstance(artifact_paths, dict):
        return sorted((str(k), artifact_paths.get(k)) for k in artifact_paths.keys())
    items = []
    try:
        for path in artifact_paths:
            key = os.path.abspath(path) if path else ''
            items.append((key, path))
    except TypeError:
        return []
    return sorted(items)


def collect_artifact_mtimes(artifact_paths):
    """Return a stable name->mtime map; missing/unreadable artifacts use None."""
    mtimes = {}
    for name, path in _artifact_items(artifact_paths):
        if not name:
            continue
        try:
            mtimes[name] = os.path.getmtime(path) if path and os.path.exists(path) else None
        except (OSError, TypeError, ValueError):
            mtimes[name] = None
    return mtimes


def normalize_artifact_paths(artifact_paths):
    """Return a stable name->absolute path map for diagnostics only."""
    paths = {}
    for name, path in _artifact_items(artifact_paths):
        if not name:
            continue
        try:
            paths[name] = os.path.abspath(path) if path else ''
        except (OSError, TypeError, ValueError):
            paths[name] = _text(path)
    return paths


def build_preflight_cache_record(preflight_succeeded, app_version, artifact_paths, recorded_at_utc=None):
    success = bool(preflight_succeeded)
    return {
        'schema_version': CACHE_SCHEMA_VERSION,
        'result': RESULT_SUCCESS if success else RESULT_FAILURE,
        'success': success,
        'app_version': _text(app_version),
        'recorded_at_utc': recorded_at_utc or utc_now_string(),
        'artifact_paths': normalize_artifact_paths(artifact_paths),
        'artifact_mtimes': collect_artifact_mtimes(artifact_paths),
    }


def read_preflight_cache(cache_path):
    """Read a cache JSON object. Never raises; returns (payload, error_reason)."""
    if not cache_path:
        return None, 'cache_path_missing'
    if not os.path.exists(cache_path):
        return None, 'cache_missing'
    try:
        with io.open(cache_path, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
    except Exception:
        return None, 'cache_read_error'
    if not isinstance(payload, dict):
        return None, 'cache_not_object'
    return payload, ''


def write_preflight_cache(cache_path, preflight_succeeded, app_version, artifact_paths, recorded_at_utc=None):
    """
    Write cache state. Never raises; returns True on success.

    Uses remove+rename instead of os.replace for XP compatibility.
    """
    if not cache_path:
        return False
    payload = build_preflight_cache_record(
        preflight_succeeded,
        app_version,
        artifact_paths,
        recorded_at_utc=recorded_at_utc,
    )
    parent = os.path.dirname(os.path.abspath(cache_path))
    tmp_path = cache_path + '.tmp'
    try:
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        with io.open(tmp_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write('\n')
        if os.path.exists(cache_path):
            os.remove(cache_path)
        os.rename(tmp_path, cache_path)
        return True
    except Exception:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        return False


def describe_startup_preflight_cache(cache_path, app_version, artifact_paths):
    """
    Return a decision dict for whether startup preflight can be skipped.

    run_required=True is the fail-open path. Only a successful prior cache with
    matching app version and artifact mtimes returns can_skip=True.
    """
    current_mtimes = collect_artifact_mtimes(artifact_paths)
    payload, error = read_preflight_cache(cache_path)
    if error:
        return {
            'can_skip': False,
            'run_required': True,
            'reason': error,
            'current_artifact_mtimes': current_mtimes,
        }
    if payload.get('schema_version') != CACHE_SCHEMA_VERSION:
        return _run_required('schema_version_mismatch', payload, current_mtimes)
    if payload.get('success') is not True or payload.get('result') != RESULT_SUCCESS:
        return _run_required('previous_preflight_not_successful', payload, current_mtimes)
    if _text(payload.get('app_version')) != _text(app_version):
        return _run_required('app_version_mismatch', payload, current_mtimes)
    cached_mtimes = payload.get('artifact_mtimes')
    if not isinstance(cached_mtimes, dict):
        return _run_required('artifact_mtimes_missing', payload, current_mtimes)
    if cached_mtimes != current_mtimes:
        return _run_required('artifact_mtime_mismatch', payload, current_mtimes)
    return {
        'can_skip': True,
        'run_required': False,
        'reason': 'cache_valid',
        'cache': payload,
        'current_artifact_mtimes': current_mtimes,
    }


def _run_required(reason, payload, current_mtimes):
    return {
        'can_skip': False,
        'run_required': True,
        'reason': reason,
        'cache': payload,
        'current_artifact_mtimes': current_mtimes,
    }


def can_skip_startup_preflight(cache_path, app_version, artifact_paths):
    return describe_startup_preflight_cache(cache_path, app_version, artifact_paths).get('can_skip') is True
