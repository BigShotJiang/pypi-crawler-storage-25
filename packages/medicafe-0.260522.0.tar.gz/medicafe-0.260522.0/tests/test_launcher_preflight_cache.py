from __future__ import print_function

import io
import json
import os
import sys
import tempfile


_tests_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_tests_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)


from MediCafe.launcher_preflight_cache import (  # noqa: E402
    CACHE_SCHEMA_VERSION,
    build_preflight_cache_record,
    describe_startup_preflight_cache,
    read_preflight_cache,
    write_preflight_cache,
)


def _write_text(path, text):
    with io.open(path, 'w', encoding='utf-8') as handle:
        handle.write(text)


def _write_json(path, payload):
    with io.open(path, 'w', encoding='utf-8') as handle:
        json.dump(payload, handle, sort_keys=True)


def _artifact_paths(root):
    config_path = os.path.join(root, 'config.json')
    crosswalk_path = os.path.join(root, 'crosswalk.json')
    _write_text(config_path, '{}')
    _write_text(crosswalk_path, '{}')
    return {
        'config': config_path,
        'crosswalk': crosswalk_path,
    }


def test_skip_when_cache_success_version_and_mtimes_match():
    with tempfile.TemporaryDirectory() as tmp:
        paths = _artifact_paths(tmp)
        cache_path = os.path.join(tmp, 'startup_preflight_cache.json')
        assert write_preflight_cache(cache_path, True, '1.2.3', paths)

        decision = describe_startup_preflight_cache(cache_path, '1.2.3', paths)

        assert decision['can_skip'] is True
        assert decision['run_required'] is False
        assert decision['reason'] == 'cache_valid'


def test_run_required_when_cache_missing():
    with tempfile.TemporaryDirectory() as tmp:
        paths = _artifact_paths(tmp)
        cache_path = os.path.join(tmp, 'missing_cache.json')

        decision = describe_startup_preflight_cache(cache_path, '1.2.3', paths)

        assert decision['can_skip'] is False
        assert decision['run_required'] is True
        assert decision['reason'] == 'cache_missing'


def test_run_required_when_previous_result_failed():
    with tempfile.TemporaryDirectory() as tmp:
        paths = _artifact_paths(tmp)
        cache_path = os.path.join(tmp, 'startup_preflight_cache.json')
        assert write_preflight_cache(cache_path, False, '1.2.3', paths)

        decision = describe_startup_preflight_cache(cache_path, '1.2.3', paths)

        assert decision['run_required'] is True
        assert decision['reason'] == 'previous_preflight_not_successful'


def test_run_required_when_version_mismatches():
    with tempfile.TemporaryDirectory() as tmp:
        paths = _artifact_paths(tmp)
        cache_path = os.path.join(tmp, 'startup_preflight_cache.json')
        assert write_preflight_cache(cache_path, True, '1.2.3', paths)

        decision = describe_startup_preflight_cache(cache_path, '2.0.0', paths)

        assert decision['run_required'] is True
        assert decision['reason'] == 'app_version_mismatch'


def test_run_required_when_artifact_mtime_mismatches():
    with tempfile.TemporaryDirectory() as tmp:
        paths = _artifact_paths(tmp)
        cache_path = os.path.join(tmp, 'startup_preflight_cache.json')
        assert write_preflight_cache(cache_path, True, '1.2.3', paths)
        original_mtime = os.path.getmtime(paths['config'])
        os.utime(paths['config'], (original_mtime, original_mtime + 5))

        decision = describe_startup_preflight_cache(cache_path, '1.2.3', paths)

        assert decision['run_required'] is True
        assert decision['reason'] == 'artifact_mtime_mismatch'


def test_run_required_when_cache_is_corrupt_json():
    with tempfile.TemporaryDirectory() as tmp:
        paths = _artifact_paths(tmp)
        cache_path = os.path.join(tmp, 'startup_preflight_cache.json')
        _write_text(cache_path, '{not valid json')

        decision = describe_startup_preflight_cache(cache_path, '1.2.3', paths)

        assert decision['run_required'] is True
        assert decision['reason'] == 'cache_read_error'


def test_safe_write_and_read_round_trip():
    with tempfile.TemporaryDirectory() as tmp:
        paths = _artifact_paths(tmp)
        cache_path = os.path.join(tmp, 'nested', 'startup_preflight_cache.json')

        ok = write_preflight_cache(
            cache_path,
            True,
            '1.2.3',
            paths,
            recorded_at_utc='2026-05-19T00:00:00Z',
        )
        payload, error = read_preflight_cache(cache_path)

        assert ok is True
        assert error == ''
        assert payload['schema_version'] == CACHE_SCHEMA_VERSION
        assert payload['success'] is True
        assert payload['result'] == 'success'
        assert payload['app_version'] == '1.2.3'
        assert payload['recorded_at_utc'] == '2026-05-19T00:00:00Z'
        assert sorted(payload['artifact_mtimes'].keys()) == ['config', 'crosswalk']
        assert sorted(payload['artifact_paths'].keys()) == ['config', 'crosswalk']


def test_write_error_is_safe_and_next_read_fails_open():
    with tempfile.TemporaryDirectory() as tmp:
        paths = _artifact_paths(tmp)
        cache_path = os.path.join(tmp, 'cache_dir')
        os.mkdir(cache_path)

        ok = write_preflight_cache(cache_path, True, '1.2.3', paths)
        decision = describe_startup_preflight_cache(cache_path, '1.2.3', paths)

        assert ok is False
        assert decision['can_skip'] is False
        assert decision['run_required'] is True
        assert decision['reason'] == 'cache_read_error'


def test_build_record_can_represent_failure_without_writing():
    with tempfile.TemporaryDirectory() as tmp:
        paths = _artifact_paths(tmp)

        payload = build_preflight_cache_record(False, '1.2.3', paths)

        assert payload['schema_version'] == CACHE_SCHEMA_VERSION
        assert payload['success'] is False
        assert payload['result'] == 'failure'
