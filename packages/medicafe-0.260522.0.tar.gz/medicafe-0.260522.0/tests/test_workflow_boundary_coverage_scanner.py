import os
import sys


def _repo_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _tools_dir():
    return os.path.join(_repo_root(), "tools")


def _write(path, text):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(text)


def test_scanner_flags_feature_tests_without_workflow_boundary_contract(tmp_path):
    tools = _tools_dir()
    if tools not in sys.path:
        sys.path.insert(0, tools)

    import scan_workflow_boundary_coverage as scanner

    _write(
        str(tmp_path / "MediCafe" / "support_send_jobs.py"),
        """
def enqueue_support_send_job(request):
    job_id = request.get('job_id')
    status = 'queued'
    latest_path = request.get('artifact_path')
    if request.get('completed'):
        status = 'completed'
    return {'job_id': job_id, 'status': status, 'latest_path': latest_path}
""",
    )
    _write(
        str(tmp_path / "tests" / "test_support_send_jobs.py"),
        """
def test_enqueue_support_send_job_records_queue_state():
    assert 'queued'
""",
    )
    _write(
        str(tmp_path / "tests" / "test_workflow_boundary_contract.py"),
        """
from workflow_boundary_contract import WorkflowBoundaryContract
""",
    )

    result = scanner.scan_repo(str(tmp_path), limit=5)

    assert result["missing_contract_count"] >= 1
    finding = result["findings"][0]
    assert finding["workflow_boundary_contract_coverage_exists"] is False
    assert finding["existing_tests"][0]["file"] == "tests/test_support_send_jobs.py"


def test_scanner_recognizes_feature_level_contract_consumers(tmp_path):
    tools = _tools_dir()
    if tools not in sys.path:
        sys.path.insert(0, tools)

    import scan_workflow_boundary_coverage as scanner

    _write(
        str(tmp_path / "MediCafe" / "cloud_readiness_actions.py"),
        """
def run_phase_d_dat_smoke(request):
    attempt_id = request.get('attempt_id')
    anchor_run_id = request.get('anchor_run_id')
    status = 'started'
    report_path = 'reports/phase_d_dat_smoke_latest.json'
    return {'attempt_id': attempt_id, 'anchor_run_id': anchor_run_id, 'status': status, 'report_path': report_path}
""",
    )
    _write(
        str(tmp_path / "tests" / "test_cloud_readiness_actions.py"),
        """
from workflow_boundary_contract import assert_workflow_boundary_clean

def test_run_phase_d_dat_smoke_boundary():
    assert_workflow_boundary_clean('phase_d_dat_smoke', {'attempt_id': 'a1'}, [])
""",
    )

    result = scanner.scan_repo(str(tmp_path), limit=5)

    assert "tests/test_cloud_readiness_actions.py" in result["contract_consumers"]
    assert result["findings"]
    assert result["findings"][0]["workflow_boundary_contract_coverage_exists"] is True


def test_scanner_flags_preserved_context_plus_mutable_evidence_consumers(tmp_path):
    tools = _tools_dir()
    if tools not in sys.path:
        sys.path.insert(0, tools)

    import scan_workflow_boundary_coverage as scanner

    _write(
        str(tmp_path / "MediCafe" / "bundle_builder.py"),
        """
def finalize_bundle_from_snapshot(anchor_snapshot, lab_root):
    anchor_run_id = anchor_snapshot.get('anchor_run_id')
    frozen_recommendation = anchor_snapshot.get('recommendation')
    diagnostics_state_path = lab_root + '/diagnostics_state.json'
    latest_report_path = lab_root + '/reports/result_latest.json'
    attachment_paths = [diagnostics_state_path, latest_report_path]
    return {
        'anchor_run_id': anchor_run_id,
        'recommendation': frozen_recommendation,
        'bundle_path': 'bundle.zip',
        'attachment_paths': attachment_paths,
    }
""",
    )
    _write(
        str(tmp_path / "tests" / "test_bundle_builder.py"),
        """
def test_finalize_bundle_from_snapshot_attaches_latest_state():
    assert 'bundle.zip'
""",
    )

    result = scanner.scan_repo(str(tmp_path), limit=5)
    profile_ids = [finding["profile_id"] for finding in result["findings"]]

    assert "preserved_context_live_evidence" in profile_ids
    preserved = [
        finding for finding in result["findings"]
        if finding["profile_id"] == "preserved_context_live_evidence"
    ][0]
    assert preserved["workflow_boundary_contract_coverage_exists"] is False
    assert "snapshot" in preserved["matched_keywords"]
    assert "latest" in preserved["matched_keywords"]
    assert "bundle" in preserved["matched_keywords"]


def test_scanner_flags_operator_lifecycle_status_boundaries(tmp_path):
    tools = _tools_dir()
    if tools not in sys.path:
        sys.path.insert(0, tools)

    import scan_workflow_boundary_coverage as scanner

    _write(
        str(tmp_path / "MediCafe" / "launcher_lifecycle.py"),
        """
def render_operator_shutdown_status(snapshot):
    anchor_run_id = snapshot.get('anchor_run_id')
    active_run_id = snapshot.get('active_run_id')
    lock_path = snapshot.get('shadow_pipeline_lock_path')
    status = 'cancel_requested'
    report_path = snapshot.get('operator_shutdown_report_path')
    if snapshot.get('fresh_pipeline_timeout'):
        status = 'stale_timeout'
    return {
        'anchor_run_id': anchor_run_id,
        'active_run_id': active_run_id,
        'lock_path': lock_path,
        'status': status,
        'report_path': report_path,
    }
""",
    )
    _write(
        str(tmp_path / "tests" / "test_launcher_lifecycle.py"),
        """
def test_render_operator_shutdown_status_reports_cancel():
    assert 'cancel_requested'
""",
    )

    result = scanner.scan_repo(str(tmp_path), limit=10)
    profile_ids = [finding["profile_id"] for finding in result["findings"]]

    assert "operator_lifecycle_status" in profile_ids
    lifecycle = [
        finding for finding in result["findings"]
        if finding["profile_id"] == "operator_lifecycle_status"
    ][0]
    assert lifecycle["workflow_boundary_contract_coverage_exists"] is False
    assert "operator_shutdown" in lifecycle["matched_keywords"]
    assert "active_run_id" in lifecycle["matched_keywords"]
    assert "status" in lifecycle["matched_keywords"]
