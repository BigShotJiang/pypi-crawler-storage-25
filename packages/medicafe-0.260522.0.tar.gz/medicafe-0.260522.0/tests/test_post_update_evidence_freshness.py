# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import shutil
import tempfile
import unittest


def _write_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle)


class PostUpdateEvidenceFreshnessTests(unittest.TestCase):
    def setUp(self):
        self.lab = tempfile.mkdtemp(prefix="mc_post_update_fresh_")
        self.reports = os.path.join(self.lab, "reports")
        os.makedirs(self.reports)

    def tearDown(self):
        shutil.rmtree(self.lab, ignore_errors=True)

    def _write_complete_run(self, run_id, app_version, phase_ids=None, source_ids=None):
        phase_ids = phase_ids or {
            "B": "b-" + run_id,
            "C": "c-" + run_id,
            "D": "d-" + run_id,
            "E": "e-" + run_id,
        }
        source_ids = source_ids or dict(phase_ids)
        source_paths = []
        for phase, prefix in (
                ("B", "artifact_discovery_summary_"),
                ("C", "ingest_write_summary_"),
                ("D", "qa_canonical_summary_"),
                ("E", "projection_parity_summary_")):
            path = os.path.join(self.reports, prefix + source_ids[phase] + ".json")
            _write_json(path, {"run_id": source_ids[phase]})
            source_paths.append(path)
        _write_json(os.path.join(self.lab, "diagnostics_state.json"), {
            "last_shadow_pipeline_run_id": run_id,
            "pipeline_state": "idle",
        })
        _write_json(os.path.join(self.lab, "run_cursor.json"), {})
        _write_json(os.path.join(self.reports, "shadow_run_report_" + run_id + ".json"), {
            "run_id": run_id,
            "machine_app_version": app_version,
            "pipeline_ok": True,
            "failed_phase": "",
            "source_summary_paths": source_paths,
            "phase_run_ids": phase_ids,
        })

    def _write_shadow_pipeline_lock(self, pid=None):
        path = os.path.join(self.lab, "shadow_pipeline.lock")
        if pid is None:
            pid = os.getpid()
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("pid={0}\n".format(pid))
            handle.write("acquired_at_utc=2026-04-11T01:00:00Z\n")
            handle.write("heartbeat_at_utc=2026-04-11T01:00:00Z\n")

    def test_matching_version_and_aligned_phase_artifacts_is_fresh(self):
        from MediCafe.post_update_evidence_freshness import assess_post_update_evidence_freshness

        self._write_complete_run("run-new", "1.1.0")
        result = assess_post_update_evidence_freshness(self.lab, "1.1.0")

        self.assertEqual(result.get("post_update_evidence_freshness_status"), "fresh")
        self.assertEqual(result.get("post_update_fresh_shadow_run_id"), "run-new")
        self.assertEqual(result.get("post_update_fresh_machine_app_version"), "1.1.0")

    def test_run_id_coherent_but_old_machine_version_is_stale(self):
        from MediCafe.post_update_evidence_freshness import assess_post_update_evidence_freshness

        self._write_complete_run("run-old", "1.0.0")
        result = assess_post_update_evidence_freshness(self.lab, "1.1.0")

        self.assertEqual(result.get("post_update_evidence_freshness_status"), "stale")
        self.assertEqual(result.get("post_update_freshness_blocking_reason"), "machine_app_version_mismatch")
        self.assertEqual(result.get("post_update_fresh_machine_app_version"), "1.0.0")

    def test_phase_c_fresh_but_package_version_stale_is_rejected(self):
        from MediCafe.post_update_evidence_freshness import assess_post_update_evidence_freshness

        self._write_complete_run("run-old", "1.0.0")
        handoff = os.path.join(self.reports, "phase_c_execution_handoff_run-old.json")
        _write_json(handoff, {
            "schema_version": 1,
            "pipeline_run_id": "run-old",
            "snapshot_after": {
                "last_manifest_sha256": "sha-current",
                "last_ingest_manifest_sha256": "sha-current",
            },
        })
        _write_json(os.path.join(self.lab, "diagnostics_state.json"), {
            "last_shadow_pipeline_run_id": "run-old",
            "pipeline_state": "idle",
            "last_phase_c_execution_handoff_report_path": handoff,
            "last_manifest_sha256": "sha-current",
            "last_ingest_manifest_sha256": "sha-current",
        })
        result = assess_post_update_evidence_freshness(self.lab, "1.1.0")

        self.assertEqual(result.get("post_update_evidence_freshness_status"), "stale")
        self.assertEqual(result.get("post_update_freshness_blocking_reason"), "machine_app_version_mismatch")

    def test_phase_source_path_and_phase_run_id_conflict_is_stale(self):
        from MediCafe.post_update_evidence_freshness import assess_post_update_evidence_freshness

        self._write_complete_run(
            "run-new",
            "1.1.0",
            phase_ids={"B": "b-run-new", "C": "c-run-new", "D": "d-run-new", "E": "e-run-new"},
            source_ids={"B": "b-run-new", "C": "c-run-new", "D": "d-other", "E": "e-run-new"},
        )
        result = assess_post_update_evidence_freshness(self.lab, "1.1.0")

        self.assertEqual(result.get("post_update_evidence_freshness_status"), "stale")
        self.assertEqual(
            result.get("post_update_freshness_blocking_reason"),
            "phase_d_source_path_phase_run_id_conflict",
        )

    def test_active_pipeline_requires_live_status_not_completed_run_evidence(self):
        from MediCafe.post_update_evidence_freshness import assess_post_update_evidence_freshness

        self._write_complete_run("run-old", "1.1.0")
        self._write_shadow_pipeline_lock()
        _write_json(os.path.join(self.lab, "diagnostics_state.json"), {
            "last_shadow_pipeline_run_id": "run-old",
            "active_run_id": "run-active",
            "pipeline_state": "running",
        })
        result = assess_post_update_evidence_freshness(self.lab, "1.1.0")

        self.assertEqual(result.get("post_update_evidence_freshness_status"), "live_status")
        self.assertEqual(result.get("post_update_fresh_pipeline_status"), "running")
        self.assertEqual(result.get("post_update_pipeline_lifecycle_status"), "live_lock_owner")

    def test_stale_active_marker_without_pipeline_lock_does_not_block_freshness(self):
        from MediCafe.post_update_evidence_freshness import assess_post_update_evidence_freshness

        self._write_complete_run("run-old", "1.0.0")
        _write_json(os.path.join(self.lab, "diagnostics_state.json"), {
            "last_shadow_pipeline_run_id": "run-old",
            "active_run_id": "run-active",
            "pipeline_state": "running",
        })
        result = assess_post_update_evidence_freshness(self.lab, "1.1.0")

        self.assertEqual(result.get("post_update_evidence_freshness_status"), "stale")
        self.assertEqual(result.get("post_update_freshness_blocking_reason"), "machine_app_version_mismatch")
        self.assertEqual(result.get("post_update_pipeline_lifecycle_status"), "stale_marker_ignored")
        self.assertFalse(result.get("shadow_pipeline_lock_owner_running"))


if __name__ == "__main__":
    unittest.main()
