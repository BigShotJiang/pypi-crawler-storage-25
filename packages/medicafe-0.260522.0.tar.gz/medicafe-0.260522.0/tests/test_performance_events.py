from __future__ import print_function


def test_log_performance_event_uses_log_file_not_console(monkeypatch, capsys):
    from MediCafe import performance_events
    from MediCafe import MediLink_ConfigLoader

    messages = []

    def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=True):
        messages.append((level, message, console_output))

    monkeypatch.setattr(MediLink_ConfigLoader, 'log', capture_log)

    performance_events.log_performance_event(
        'component-a',
        'stage-b',
        elapsed_sec=1.25,
        details={'rows': 4},
    )

    captured = capsys.readouterr()
    assert captured.out == ''
    assert captured.err == ''
    assert len(messages) == 1
    assert messages[0][0] == 'INFO'
    assert messages[0][2] is False
    assert 'PERF_TIMING component=component-a stage=stage-b elapsed_ms=1250 rows=4' in messages[0][1]
