# -*- coding: utf-8 -*-
from __future__ import print_function

import csv
import json
import os
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch


_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _write_csv(path, headers, rows):
    with open(path, 'w') as handle:
        writer = csv.DictWriter(handle, fieldnames=headers, lineterminator='\n')
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _write_text(path, text):
    with open(path, 'w') as handle:
        handle.write(text)


def _entry_list(index):
    if isinstance(index, dict):
        if isinstance(index.get('files'), dict):
            return list(index.get('files').values())
        if isinstance(index.get('entries'), dict):
            return list(index.get('entries').values())
        if isinstance(index.get('files'), list):
            return list(index.get('files'))
        if isinstance(index.get('entries'), list):
            return list(index.get('entries'))
    return []


def _row_list(file_entry):
    for key in ('rows', 'metadata_rows', 'patients', 'service_rows'):
        value = file_entry.get(key)
        if isinstance(value, list):
            return value
    return []


def _find_file_entry(index, basename):
    for entry in _entry_list(index):
        if entry.get('file_basename') == basename or entry.get('basename') == basename:
            return entry
        path = entry.get('path') or entry.get('csv_path') or ''
        if os.path.basename(path) == basename:
            return entry
    raise AssertionError('missing index entry for {0}: {1!r}'.format(basename, index))


def _assert_no_key_recursive(testcase, value, forbidden_key):
    if isinstance(value, dict):
        testcase.assertNotIn(forbidden_key, value)
        for child in value.values():
            _assert_no_key_recursive(testcase, child, forbidden_key)
    elif isinstance(value, list):
        for child in value:
            _assert_no_key_recursive(testcase, child, forbidden_key)


class CsvMetadataIndexContractTests(unittest.TestCase):
    """Regression contract for the planned MediBot CSV metadata index API."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.csv_dir = os.path.join(self.tmp, 'csv')
        os.makedirs(self.csv_dir)
        self.index_path = os.path.join(self.tmp, 'csv_metadata_index.json')
        self.status_path = os.path.join(self.tmp, 'csv_metadata_index_status.json')

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmp, ignore_errors=True)

    def _module(self):
        from MediBot import MediBot_csv_metadata_index as metadata_index

        return metadata_index

    def _update(self):
        return self._module().update_csv_metadata_index(
            self.csv_dir,
            index_path=self.index_path,
            status_path=self.status_path,
        )

    def _load_index(self):
        return self._module().load_csv_metadata_index(self.index_path)

    def _load_status(self):
        return self._module().load_csv_metadata_index_status(self.status_path)

    def test_alias_extraction_canonicalizes_patient_and_service_date_headers(self):
        _write_csv(
            os.path.join(self.csv_dir, 'daily_aliases.csv'),
            ['Patient ID #2', 'DOS', 'Patient Last', 'Patient First', 'Notes'],
            [{
                'Patient ID #2': 'P-100',
                'DOS': '05/12/2026',
                'Patient Last': 'Doe',
                'Patient First': 'Jane',
                'Notes': 'not metadata',
            }],
        )

        result = self._update()
        index = self._load_index()

        self.assertTrue(result.get('ok'), msg=repr(result))
        entry = _find_file_entry(index, 'daily_aliases.csv')
        self.assertEqual(entry.get('status'), 'indexed')
        rows = _row_list(entry)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].get('patient_id'), 'P-100')
        self.assertEqual(rows[0].get('service_date'), '05/12/2026')
        self.assertEqual(rows[0].get('source_patient_id_header'), 'Patient ID #2')
        self.assertEqual(rows[0].get('source_service_date_header'), 'DOS')

    def test_unused_columns_are_not_persisted_in_index_rows(self):
        _write_csv(
            os.path.join(self.csv_dir, 'daily_unused.csv'),
            ['Patient ID', 'Surgery Date', 'Patient Last', 'Patient First', 'Huge Free Text', 'Raw Claim Blob'],
            [{
                'Patient ID': '12345',
                'Surgery Date': '05/12/2026',
                'Patient Last': 'Doe',
                'Patient First': 'Jane',
                'Huge Free Text': 'x' * 1000,
                'Raw Claim Blob': '{"unneeded": true}',
            }],
        )

        self._update()
        index = self._load_index()
        entry = _find_file_entry(index, 'daily_unused.csv')
        rows = _row_list(entry)

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].get('patient_id'), '12345')
        _assert_no_key_recursive(self, index, 'Huge Free Text')
        _assert_no_key_recursive(self, index, 'Raw Claim Blob')
        self.assertNotIn('x' * 200, json.dumps(index, sort_keys=True))

    def test_reconciliation_action_profile_is_skipped(self):
        _write_csv(
            os.path.join(self.csv_dir, 'action_report.csv'),
            ['category', 'patient_id', 'dos', 'payer_id', 'claim_key', 'claim_number', 'detail', 'next_action'],
            [{
                'category': 'reply_unblock',
                'patient_id': '12345',
                'dos': '05/12/2026',
                'payer_id': '87726',
                'claim_key': 'k',
                'claim_number': 'c',
                'detail': 'missing',
                'next_action': 'review',
            }],
        )

        self._update()
        index = self._load_index()
        status = self._load_status()

        self.assertEqual(_entry_list(index), [])
        self.assertEqual(status.get('skipped_action_or_reconciliation'), 1)
        self.assertEqual(status.get('indexed_count'), 0)

    def test_unchanged_mtime_and_size_skips_reparse(self):
        path = os.path.join(self.csv_dir, 'stable.csv')
        _write_csv(
            path,
            ['Patient ID', 'Surgery Date', 'Patient Last', 'Patient First'],
            [{'Patient ID': '1', 'Surgery Date': '05/12/2026', 'Patient Last': 'One', 'Patient First': 'A'}],
        )

        first = self._update()
        second = self._update()
        status = self._load_status()
        index = self._load_index()
        entry = _find_file_entry(index, 'stable.csv')

        self.assertTrue(first.get('ok'), msg=repr(first))
        self.assertTrue(second.get('ok'), msg=repr(second))
        self.assertEqual(status.get('skipped_unchanged'), 1)
        self.assertEqual(status.get('parsed_count'), 0)
        self.assertIn('mtime', entry)
        self.assertIn('size', entry)

    def test_removed_file_is_pruned_from_existing_index(self):
        path = os.path.join(self.csv_dir, 'remove_me.csv')
        _write_csv(
            path,
            ['Patient ID', 'Surgery Date', 'Patient Last', 'Patient First'],
            [{'Patient ID': '1', 'Surgery Date': '05/12/2026', 'Patient Last': 'One', 'Patient First': 'A'}],
        )
        self._update()
        os.remove(path)

        self._update()
        index = self._load_index()
        status = self._load_status()

        self.assertEqual(_entry_list(index), [])
        self.assertEqual(status.get('pruned_missing'), 1)

    def test_corrupt_csv_records_status_and_preserves_prior_good_index(self):
        good_path = os.path.join(self.csv_dir, 'daily.csv')
        _write_csv(
            good_path,
            ['Patient ID', 'Surgery Date', 'Patient Last', 'Patient First'],
            [{'Patient ID': '12345', 'Surgery Date': '05/12/2026', 'Patient Last': 'Doe', 'Patient First': 'Jane'}],
        )
        self._update()

        _write_text(good_path, '"Patient ID","Surgery Date"\n"unterminated,05/13/2026\n')
        os.utime(good_path, None)

        result = self._update()
        index = self._load_index()
        status = self._load_status()
        entry = _find_file_entry(index, 'daily.csv')
        rows = _row_list(entry)

        self.assertFalse(result.get('ok'))
        self.assertEqual(status.get('error_count'), 1)
        self.assertEqual(status.get('last_error_code'), 'csv_parse_failed')
        self.assertEqual(entry.get('status'), 'stale_parse_failed')
        self.assertEqual(rows[0].get('patient_id'), '12345')
        self.assertEqual(rows[0].get('service_date'), '05/12/2026')
        self.assertNotIn('12345', index.get('latest_by_patient_id', {}))
        by_pid, by_demog, meta = self._module().get_recent_service_dates_from_index(
            index,
            target_patient_ids=set(['12345']),
            max_age_days=90,
        )
        self.assertEqual(by_pid, {})
        self.assertEqual(by_demog, {})
        self.assertTrue(meta.get('index_used'))

    def test_recent_service_dates_are_unique_newest_first(self):
        _write_csv(
            os.path.join(self.csv_dir, 'dates_a.csv'),
            ['Patient ID', 'Surgery Date', 'Patient Last', 'Patient First'],
            [
                {'Patient ID': '1', 'Surgery Date': '05/12/2026', 'Patient Last': 'One', 'Patient First': 'A'},
                {'Patient ID': '2', 'Surgery Date': '05/13/2026', 'Patient Last': 'Two', 'Patient First': 'B'},
            ],
        )
        _write_csv(
            os.path.join(self.csv_dir, 'dates_b.csv'),
            ['Patient ID', 'Service Date', 'Patient Last', 'Patient First'],
            [
                {'Patient ID': '3', 'Service Date': '05/13/2026', 'Patient Last': 'Three', 'Patient First': 'C'},
                {'Patient ID': '4', 'Service Date': '05/10/2026', 'Patient Last': 'Four', 'Patient First': 'D'},
            ],
        )
        self._update()

        dates = self._module().get_recent_service_dates_from_index(
            self._load_index(),
            limit=2,
        )

        self.assertEqual(dates, ['05/13/2026', '05/12/2026'])

    def test_runtime_api_writes_default_local_storage_artifacts(self):
        storage = os.path.join(self.tmp, 'storage')
        os.makedirs(storage)
        _write_csv(
            os.path.join(self.csv_dir, 'daily.csv'),
            ['Patient ID', 'Surgery Date', 'Patient Last', 'Patient First'],
            [{'Patient ID': 'R1', 'Surgery Date': '05/12/2026', 'Patient Last': 'One', 'Patient First': 'A'}],
        )

        result = self._module().update_csv_metadata_index(storage, self.csv_dir)
        index_path = os.path.join(storage, self._module().INDEX_FILENAME)
        status_path = os.path.join(storage, self._module().STATUS_FILENAME)

        self.assertTrue(result.get('ok'), msg=repr(result))
        self.assertTrue(os.path.exists(index_path))
        self.assertTrue(os.path.exists(status_path))
        entry = _find_file_entry(self._module().load_csv_metadata_index(storage), 'daily.csv')
        self.assertEqual(_row_list(entry)[0].get('patient_id'), 'R1')

    def test_csv_metadata_index_rebuild_command_is_accepted_by_main(self):
        from MediCafe import __main__ as medicafe_main

        old_argv = list(sys.argv)
        try:
            sys.argv = ['python -m MediCafe', 'csv_metadata_index_rebuild']
            with patch.object(medicafe_main, 'run_csv_metadata_index_rebuild', return_value=0) as run_mock:
                rc = medicafe_main.main()
        finally:
            sys.argv = old_argv

        self.assertEqual(rc, 0)
        self.assertEqual(run_mock.call_count, 1)

    def test_csv_metadata_index_rebuild_cli_is_unbounded(self):
        from MediCafe import __main__ as medicafe_main

        class _Result(object):
            index_data = {'files': {}, 'skipped_files': {}}
            stats = {'parsed': 0, 'skipped': 0, 'profile_skipped': 0, 'errors': 0, 'indexed_rows': 0}

        with patch.object(medicafe_main, '_load_paths_for_csv_metadata_index', return_value=(self.tmp, self.csv_dir)):
            with patch('MediBot.MediBot_csv_metadata_index.update_csv_metadata_index', return_value=_Result()) as update_mock:
                rc = medicafe_main.run_csv_metadata_index_rebuild()

        self.assertEqual(rc, 0)
        self.assertEqual(update_mock.call_count, 1)
        self.assertIsNone(update_mock.call_args[1].get('max_csv_files'))


if __name__ == '__main__':
    unittest.main()
