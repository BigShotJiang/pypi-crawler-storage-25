from __future__ import print_function

import csv
import os
import shutil
import tempfile
import unittest
from datetime import datetime, timedelta

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch


class TestDeductibleReportNoise(unittest.TestCase):

    def test_run_batch_quiet_report_mode_suppresses_success_console_output(self):
        from MediLink import MediLink_Deductible_v1_5 as dv15

        cfg = {
            dv15._QUIET_SUCCESS_CONSOLE_KEY: True,
            'MediLink_Config': {
                'default_billing_provider_last_name': 'DOE',
                'default_billing_provider_npi': '1234567890',
            },
            'CSV_FILE_PATH': __file__,
        }
        patient = ('1', '1980-01-01', 'M1', '87726', '2026-05-01')
        cached_payload = {
            'remaining_amount': '0.00',
            'code': '12',
            'cached_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        }

        class _Client(object):
            pass

        with patch.object(dv15, 'cache_lookup', return_value=cached_payload), \
                patch.object(dv15, 'get_api_client', return_value=_Client()), \
                patch.object(dv15, 'load_cache', return_value={'by_patient_id': {}}), \
                patch('builtins.print') as print_mock, \
                patch.object(dv15, '_print_progress') as progress_mock:
            out = dv15.run_batch([patient], cfg, silent=False)

        self.assertEqual(out, [])
        self.assertEqual(print_mock.call_count, 0)
        self.assertEqual(progress_mock.call_count, 0)

    def test_filter_patients_skips_historical_scan_when_tuple_dates_cover_recency(self):
        from MediLink import MediLink_Deductible_v1_5 as dv15

        recent_iso = (datetime.now() - timedelta(days=5)).strftime('%Y-%m-%d')
        patients = [('1', '01/01/1980', 'M1', '87726', recent_iso)]
        cfg = {'CSV_FILE_PATH': __file__}

        with patch.object(dv15, '_collect_recent_service_dates_from_csv_dir_targeted') as scan_mock, \
                patch.object(dv15, '_collect_recent_service_dates_from_cache', return_value=({}, {})):
            out = dv15.filter_patients_for_menu_eligibility_report(
                patients, cfg, set(['87726']), window_days=90
            )

        self.assertEqual(out, patients)
        self.assertEqual(scan_mock.call_count, 0)

    def test_report_flow_reuses_historical_scan_context_within_same_run(self):
        from MediLink import MediLink_Deductible_v1_5 as dv15

        cfg = {'CSV_FILE_PATH': __file__}
        patient = ('1', '01/01/1980', 'M1', '87726', None)
        recent_dt = datetime.now() - timedelta(days=2)
        meta_calls = []

        def _fake_scan(cfg_arg, csv_dir, target_patient_ids=None, target_demog_keys=None,
                       max_age_days=None, max_csv_files=None, metadata_out=None):
            if metadata_out is not None:
                metadata_out['files_considered'] = 3
                metadata_out['files_loaded'] = 1
                metadata_out['target_patient_count'] = len(target_patient_ids or [])
                metadata_out['target_demog_count'] = len(target_demog_keys or [])
                metadata_out['early_stop'] = True
                meta_calls.append(dict(metadata_out))
            return ({'1': recent_dt}, {('1980-01-01', 'M1'): recent_dt})

        with patch.object(dv15, '_collect_recent_service_dates_from_csv_dir_targeted', side_effect=_fake_scan) as scan_mock, \
                patch.object(dv15, '_collect_recent_service_dates_from_cache', return_value=({}, {})):
            filtered = dv15.filter_patients_for_menu_eligibility_report(
                [patient], cfg, set(['87726']), window_days=90
            )
            rows = dv15._build_deductible_report_rows(cfg, filtered, processed=[])

        self.assertEqual(scan_mock.call_count, 1)
        self.assertEqual(filtered, [patient])
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].get('patient_id'), '1')
        self.assertEqual(rows[0].get('service_date_display'), recent_dt.strftime('%m/%d'))
        self.assertTrue(meta_calls)
        self.assertEqual(meta_calls[0].get('files_loaded'), 1)

    def test_report_recency_uses_csv_metadata_index_before_live_scan(self):
        from MediLink import MediLink_Deductible_v1_5 as dv15

        temp_root = tempfile.mkdtemp(prefix='mc_csv_index_recency_')
        try:
            csv_dir = os.path.join(temp_root, 'csv')
            local_storage = os.path.join(temp_root, 'storage')
            os.makedirs(csv_dir)
            os.makedirs(local_storage)
            csv_path = os.path.join(csv_dir, 'daily.csv')
            recent_date = (datetime.now() - timedelta(days=3)).strftime('%m/%d/%Y')
            with open(csv_path, 'w') as handle:
                writer = csv.DictWriter(handle, fieldnames=[
                    'Patient ID',
                    'Patient DOB',
                    'Primary Policy Number',
                    'Ins1 Payer ID',
                    'Surgery Date',
                    'Unused Notes',
                ])
                writer.writeheader()
                writer.writerow({
                    'Patient ID': 'IDX1',
                    'Patient DOB': '01/01/1980',
                    'Primary Policy Number': 'M1',
                    'Ins1 Payer ID': '87726',
                    'Surgery Date': recent_date,
                    'Unused Notes': 'not indexed',
                })
            cfg = {
                'CSV_FILE_PATH': csv_path,
                'MediLink_Config': {'local_storage_path': local_storage},
            }
            patient = ('IDX1', '01/01/1980', 'M1', '87726', None)

            with patch.object(dv15, '_collect_recent_service_dates_from_csv_dir_targeted') as scan_mock, \
                    patch.object(dv15, '_collect_recent_service_dates_from_cache', return_value=({}, {})):
                filtered = dv15.filter_patients_for_menu_eligibility_report(
                    [patient], cfg, set(['87726']), window_days=90
                )

            context = cfg.get(dv15._REPORT_RECENCY_CONTEXT_KEY, {})
            self.assertEqual(filtered, [patient])
            self.assertEqual(scan_mock.call_count, 0)
            self.assertTrue(context.get('csv_metadata_index_used'))
            self.assertEqual(context.get('csv_metadata_index_hits'), 2)
            self.assertFalse(context.get('historical_scan_used'))
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_stale_tuple_date_is_refreshed_from_csv_metadata_index(self):
        from MediLink import MediLink_Deductible_v1_5 as dv15

        temp_root = tempfile.mkdtemp(prefix='mc_csv_index_stale_tuple_')
        try:
            csv_dir = os.path.join(temp_root, 'csv')
            local_storage = os.path.join(temp_root, 'storage')
            os.makedirs(csv_dir)
            os.makedirs(local_storage)
            csv_path = os.path.join(csv_dir, 'daily.csv')
            recent_date = (datetime.now() - timedelta(days=2)).strftime('%m/%d/%Y')
            stale_date = (datetime.now() - timedelta(days=300)).strftime('%Y-%m-%d')
            with open(csv_path, 'w') as handle:
                writer = csv.DictWriter(handle, fieldnames=[
                    'Patient ID',
                    'Patient DOB',
                    'Primary Policy Number',
                    'Ins1 Payer ID',
                    'Surgery Date',
                ])
                writer.writeheader()
                writer.writerow({
                    'Patient ID': 'STALE1',
                    'Patient DOB': '01/01/1980',
                    'Primary Policy Number': 'M1',
                    'Ins1 Payer ID': '87726',
                    'Surgery Date': recent_date,
                })
            cfg = {
                'CSV_FILE_PATH': csv_path,
                'MediLink_Config': {'local_storage_path': local_storage},
            }
            patient = ('STALE1', '01/01/1980', 'M1', '87726', stale_date)

            with patch.object(dv15, '_collect_recent_service_dates_from_csv_dir_targeted') as scan_mock, \
                    patch.object(dv15, '_collect_recent_service_dates_from_cache', return_value=({}, {})):
                filtered = dv15.filter_patients_for_menu_eligibility_report(
                    [patient], cfg, set(['87726']), window_days=90
                )

            self.assertEqual(filtered, [patient])
            self.assertEqual(scan_mock.call_count, 0)
            self.assertTrue(cfg[dv15._REPORT_RECENCY_CONTEXT_KEY].get('csv_metadata_index_used'))
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_stale_tuple_date_falls_back_to_live_scan_when_index_misses(self):
        from MediLink import MediLink_Deductible_v1_5 as dv15

        cfg = {
            'CSV_FILE_PATH': __file__,
            'MediLink_Config': {'local_storage_path': os.path.dirname(__file__)},
        }
        stale_date = (datetime.now() - timedelta(days=300)).strftime('%Y-%m-%d')
        patient = ('LIVE1', '01/01/1980', 'M1', '87726', stale_date)
        recent_dt = datetime.now() - timedelta(days=1)

        def _fake_index(cfg_arg, csv_dir, target_patient_ids=None, target_demog_keys=None,
                        max_age_days=None, max_csv_files=None, metadata_out=None):
            if metadata_out is not None:
                metadata_out['index_used'] = True
            return {}, {}

        def _fake_scan(cfg_arg, csv_dir, target_patient_ids=None, target_demog_keys=None,
                       max_age_days=None, max_csv_files=None, metadata_out=None):
            if metadata_out is not None:
                metadata_out['files_loaded'] = 1
            return {'LIVE1': recent_dt}, {('1980-01-01', 'M1'): recent_dt}

        with patch.object(dv15, '_collect_recent_service_dates_from_csv_metadata_index', side_effect=_fake_index), \
                patch.object(dv15, '_collect_recent_service_dates_from_csv_dir_targeted', side_effect=_fake_scan) as scan_mock, \
                patch.object(dv15, '_collect_recent_service_dates_from_cache', return_value=({}, {})):
            filtered = dv15.filter_patients_for_menu_eligibility_report(
                [patient], cfg, set(['87726']), window_days=90
            )

        self.assertEqual(filtered, [patient])
        self.assertEqual(scan_mock.call_count, 1)


if __name__ == '__main__':
    unittest.main()
