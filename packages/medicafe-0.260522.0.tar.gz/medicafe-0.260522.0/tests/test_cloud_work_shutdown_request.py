#!/usr/bin/env python
from __future__ import print_function

import json
import os
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch


class CloudWorkShutdownRequestTests(unittest.TestCase):

    def test_shadow_pipeline_stops_before_next_phase_when_shutdown_requested(self):
        from scripts.unified_model import run_shadow_pipeline as rsp

        with tempfile.TemporaryDirectory() as lab_root:
            reports = os.path.join(lab_root, 'reports')
            os.makedirs(reports)
            request_path = os.path.join(reports, 'cloud_work_shutdown_request.json')
            with open(request_path, 'w') as handle:
                json.dump({
                    'schema_version': 1,
                    'request_id': 'req-unit',
                    'status': 'requested',
                    'reason': 'operator_safe_cancel',
                }, handle)

            calls = []
            original_run_phase = rsp._run_phase
            try:
                rsp._run_phase = lambda *args, **kwargs: calls.append(args) or (True, 0)
                ok, _rid, failed_phase, error_code = rsp.run_shadow_pipeline(lab_root)
            finally:
                rsp._run_phase = original_run_phase

            self.assertFalse(ok)
            self.assertEqual(failed_phase, 'A')
            self.assertEqual(error_code, rsp.OPERATOR_SHUTDOWN_REQUESTED)
            self.assertEqual(calls, [])
            with open(request_path, 'r') as handle:
                request = json.load(handle)
            self.assertEqual(request.get('status'), 'stopped')
            self.assertEqual(request.get('stopped_before_phase'), 'A')

    def test_terminate_process_refuses_invalid_and_current_pid(self):
        from MediCafe import cloud_work_shutdown as cws

        invalid = cws.terminate_process('not-a-pid', reason='unit')
        self.assertFalse(invalid.get('attempted'))
        self.assertFalse(invalid.get('ok'))
        self.assertEqual(invalid.get('message'), 'invalid_pid')

        current = cws.terminate_process(os.getpid(), reason='unit')
        self.assertFalse(current.get('attempted'))
        self.assertFalse(current.get('ok'))
        self.assertEqual(current.get('message'), 'refused_current_process')

    def test_terminate_process_windows_taskkill_success(self):
        from MediCafe import cloud_work_shutdown as cws

        with patch.object(cws.os, 'name', 'nt'):
            with patch.object(cws, '_pid_running', side_effect=[True, False]) as running:
                with patch.object(cws.subprocess, 'call', return_value=0) as call_mock:
                    res = cws.terminate_process(424242, reason='unit')
        self.assertTrue(res.get('attempted'))
        self.assertTrue(res.get('ok'))
        self.assertEqual(res.get('method'), 'taskkill')
        self.assertEqual(res.get('return_code'), '0')
        self.assertEqual(running.call_count, 2)
        call_mock.assert_called_once()


if __name__ == '__main__':
    unittest.main()
