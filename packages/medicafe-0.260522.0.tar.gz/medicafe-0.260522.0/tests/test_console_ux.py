#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import print_function

from MediCafe import console_ux


def _clear_console_env(monkeypatch):
    monkeypatch.delenv('MEDICAFE_VERBOSE_LOGGING', raising=False)
    monkeypatch.delenv('MEDICAFE_DEBUG', raising=False)
    monkeypatch.delenv('MEDICAFE_PERFORMANCE_LOGGING', raising=False)


def test_emit_info_verbose_only_default_quiet(monkeypatch, capsys):
    _clear_console_env(monkeypatch)
    monkeypatch.setattr(console_ux, 'DEBUG', False)
    monkeypatch.setattr(console_ux, 'PERFORMANCE_LOGGING', False)

    console_ux.emit_info('default quiet', verbose_only=True)

    captured = capsys.readouterr()
    assert captured.out == ''


def test_emit_info_verbose_only_perf_only_quiet(monkeypatch, capsys):
    _clear_console_env(monkeypatch)
    monkeypatch.setattr(console_ux, 'DEBUG', False)
    monkeypatch.setattr(console_ux, 'PERFORMANCE_LOGGING', True)
    monkeypatch.setenv('MEDICAFE_PERFORMANCE_LOGGING', '1')

    console_ux.emit_info('perf quiet', verbose_only=True)

    captured = capsys.readouterr()
    assert captured.out == ''


def test_emit_info_verbose_only_verbose_env_noisy(monkeypatch, capsys):
    _clear_console_env(monkeypatch)
    monkeypatch.setattr(console_ux, 'DEBUG', False)
    monkeypatch.setattr(console_ux, 'PERFORMANCE_LOGGING', False)
    monkeypatch.setenv('MEDICAFE_VERBOSE_LOGGING', '1')

    console_ux.emit_info('verbose env noisy', verbose_only=True)

    captured = capsys.readouterr()
    assert captured.out == 'verbose env noisy\n'


def test_emit_info_verbose_only_debug_env_noisy(monkeypatch, capsys):
    _clear_console_env(monkeypatch)
    monkeypatch.setattr(console_ux, 'DEBUG', False)
    monkeypatch.setattr(console_ux, 'PERFORMANCE_LOGGING', False)
    monkeypatch.setenv('MEDICAFE_DEBUG', '1')

    console_ux.emit_info('debug env noisy', verbose_only=True)

    captured = capsys.readouterr()
    assert captured.out == 'debug env noisy\n'
