#!/usr/bin/env python
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import time
import unittest
from io import StringIO

try:
    from unittest.mock import MagicMock, patch
except ImportError:
    from mock import MagicMock, patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class LauncherRenderSnapshotCachingTests(unittest.TestCase):

    def _make_orchestrator(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
        args = MagicMock()
        args.skip_csv = False
        args.direct_action = None
        args.debug_mode = False
        args.auto_choice = None
        session = SessionConfig(args)
        orch = MediCafeOrchestrator(session)
        orch._next_step_assistant_enabled = True
        return orch

    def test_assistant_render_snapshot_reuses_expensive_file_reads_across_providers(self):
        """Render-scoped assistant providers should consume one frozen IO snapshot.

        This intentionally targets the helper seam the launcher implementation
        should provide, rather than repeating the current provider-by-provider
        reads. The helper names are part of the test contract for the main
        implementation work.
        """
        orch = self._make_orchestrator()
        temp_root = tempfile.mkdtemp(prefix='mc_render_snapshot_')
        try:
            storage_root = os.path.join(temp_root, 'storage')
            claims_root = os.path.join(temp_root, 'claims')
            reports_queue = os.path.join(storage_root, 'reports_queue')
            os.makedirs(storage_root)
            os.makedirs(claims_root)
            os.makedirs(reports_queue)

            config_path = os.path.join(temp_root, 'config.json')
            config_payload = {
                'MediLink_Config': {
                    'local_storage_path': storage_root,
                    'local_claims_path': claims_root,
                }
            }
            with open(config_path, 'w') as handle:
                json.dump(config_payload, handle)
            with open(os.path.join(storage_root, 'remittance_file_ledger.jsonl'), 'w') as handle:
                handle.write(json.dumps({
                    'mtime': int(time.time()),
                    'new_records': 1,
                }) + '\n')
            with open(os.path.join(claims_root, 'submission_attempts.jsonl'), 'w') as handle:
                handle.write(json.dumps({
                    'claim_key': 'claim-1',
                    'status': 'conversion_failed',
                    'custody': 'in_custody',
                    'attempt_at': 1,
                }) + '\n')
            with open(os.path.join(reports_queue, 'queued.zip'), 'w') as handle:
                handle.write('x')
            with open(os.path.join(storage_root, 'schedule.docx'), 'w') as handle:
                handle.write('placeholder')

            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = storage_root
            orch.repo_root = temp_root

            original_load_config = orch._load_launcher_config_snapshot
            original_read_jsonl = orch._read_jsonl_tail
            original_listdir = os.listdir

            with patch.object(orch, '_load_launcher_config_snapshot', wraps=original_load_config) as config_mock:
                with patch.object(orch, '_read_jsonl_tail', wraps=original_read_jsonl) as jsonl_mock:
                    with patch('MediCafe.launcher.os.listdir', wraps=original_listdir) as listdir_mock:
                        snapshot = orch._build_launcher_render_snapshot()
                        providers = orch._assistant_signal_providers_for_render_snapshot(snapshot)

                        self.assertTrue(isinstance(snapshot, dict))
                        self.assertTrue(providers)

                        counts_after_snapshot = (
                            config_mock.call_count,
                            jsonl_mock.call_count,
                            listdir_mock.call_count,
                        )
                        merged = {}
                        for _idx in range(2):
                            for provider in providers:
                                payload = provider()
                                if isinstance(payload, dict):
                                    merged.update(payload)

                        self.assertEqual(
                            counts_after_snapshot,
                            (
                                config_mock.call_count,
                                jsonl_mock.call_count,
                                listdir_mock.call_count,
                            ),
                        )
                        self.assertLessEqual(config_mock.call_count, 1)
                        self.assertTrue(merged.get('zdat_pending'))
                        self.assertEqual(merged.get('retry_queue_pending_count'), 1)
                        self.assertEqual(merged.get('queued_error_reports_pending_count'), 1)
                        self.assertTrue(merged.get('docx_index_attention_needed'))
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_passive_menu_support_send_status_does_not_preflight_or_wake_worker(self):
        orch = self._make_orchestrator()
        manager = MagicMock()
        manager.list_jobs = MagicMock(return_value=[{
            'job_id': 'job-passive',
            'status': 'queued',
            'progress_stage': 'waiting',
        }])
        manager.preflight_reap_stale_running_jobs = MagicMock(return_value=[])
        manager._ensure_worker_locked = MagicMock()
        orch._support_send_job_manager = MagicMock(return_value=manager)

        with patch.object(orch, '_print_post_update_autofollow_status_banner', return_value=False):
            with patch.object(orch, '_print_cloud_work_status_snapshot'):
                with patch('sys.stdout', new=StringIO()):
                    printed = orch._print_menu_background_support_send_status_banner()

        self.assertTrue(printed)
        manager.preflight_reap_stale_running_jobs.assert_not_called()
        manager._ensure_worker_locked.assert_not_called()
        manager.list_jobs.assert_called()
        _, kwargs = manager.list_jobs.call_args
        self.assertEqual(kwargs.get('ensure_liveness'), False)

    def test_passive_menu_notice_and_status_share_one_job_snapshot(self):
        orch = self._make_orchestrator()
        manager = MagicMock()
        manager.list_jobs = MagicMock(return_value=[{
            'job_id': 'job-passive',
            'status': 'queued',
            'progress_stage': 'waiting',
        }])
        manager.preflight_reap_stale_running_jobs = MagicMock(return_value=[])
        manager._ensure_worker_locked = MagicMock()
        orch._support_send_job_manager = MagicMock(return_value=manager)
        orch._menu_support_send_render_context = None

        with patch.object(orch, '_print_post_update_autofollow_status_banner', return_value=False):
            with patch.object(orch, '_print_cloud_work_status_snapshot'):
                with patch('sys.stdout', new=StringIO()):
                    orch._try_print_menu_background_support_send_notice()
                    printed = orch._print_menu_background_support_send_status_banner()

        self.assertTrue(printed)
        manager.list_jobs.assert_called_once()
        manager.preflight_reap_stale_running_jobs.assert_not_called()
        manager._ensure_worker_locked.assert_not_called()


if __name__ == '__main__':
    unittest.main()
