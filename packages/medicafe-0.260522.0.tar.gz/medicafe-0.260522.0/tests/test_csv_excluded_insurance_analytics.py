import io
import json
import zipfile

from MediBot import csv_excluded_insurance_analytics as analytics
from MediCafe import __main__ as medicafe_main
from MediCafe import core_utils
from MediCafe import error_reporter


def _write_csv(path):
    with io.open(str(path), "w", encoding="utf-8", newline="") as handle:
        handle.write(
            "Primary Insurance,Patient ID,Name\n"
            "AETNA,123,Alice\n"
            "OTHER,999,Bob\n"
        )


def test_payload_includes_temporary_openness_policy_note():
    payload = analytics.analyze_csv_text(
        "Primary Insurance,Patient ID\n"
        "AETNA,123\n"
        "OTHER,456\n"
    )

    assert "policy_note" in payload
    assert payload["policy_note"] == analytics.TEMPORARY_OPENNESS_POLICY_NOTE


def test_txt_report_includes_same_policy_note(tmp_path):
    csv_path = tmp_path / "input.csv"
    report_dir = tmp_path / "reports"
    _write_csv(csv_path)

    payload, artifacts = analytics.run(str(csv_path), str(report_dir))

    txt = io.open(artifacts["txt_path"], "r", encoding="utf-8").read()
    expected_line = "policy_note={0}".format(payload["policy_note"])
    assert expected_line in txt
    assert payload["policy_note"] == analytics.TEMPORARY_OPENNESS_POLICY_NOTE


def test_send_report_bundle_meta_includes_same_policy_note(monkeypatch, tmp_path):
    csv_path = tmp_path / "input.csv"
    storage = tmp_path / "lab"
    _write_csv(csv_path)
    calls = {}

    class _Loader(object):
        def load_configuration(self):
            return {
                "CSV_FILE_PATH": str(csv_path),
                "local_storage_path": str(storage),
            }, {}

    monkeypatch.setattr(core_utils, "get_config_loader_with_fallback", lambda: _Loader())

    def fake_collect_support_bundle(**kwargs):
        calls["collect_kwargs"] = kwargs
        bundle = tmp_path / "bundle.zip"
        bundle.write_text("bundle", encoding="utf-8")
        return str(bundle)

    def fake_submit_support_bundle_email(zip_path, include_traceback=False, **kwargs):
        calls["submit_kwargs"] = {
            "zip_path": zip_path,
            "include_traceback": include_traceback,
            "kwargs": kwargs,
        }
        return True

    monkeypatch.setattr(error_reporter, "collect_support_bundle", fake_collect_support_bundle)
    monkeypatch.setattr(error_reporter, "submit_support_bundle_email", fake_submit_support_bundle_email)

    rc = medicafe_main.run_csv_excluded_insurance_analytics(send_report=True)

    assert rc == 0
    meta = calls["collect_kwargs"]["extra_meta"]
    assert meta["bundle_kind"] == "csv_excluded_insurance_analytics_report"
    assert meta["temporary_openness_policy_note"] == analytics.TEMPORARY_OPENNESS_POLICY_NOTE


def test_send_report_builds_real_bundle_with_named_attachments(monkeypatch, tmp_path):
    csv_path = tmp_path / "input.csv"
    storage = tmp_path / "lab"
    _write_csv(csv_path)
    calls = {}

    class _Loader(object):
        def load_configuration(self):
            return {
                "CSV_FILE_PATH": str(csv_path),
                "local_storage_path": str(storage),
            }, {}

    monkeypatch.setattr(core_utils, "get_config_loader_with_fallback", lambda: _Loader())
    monkeypatch.setattr(
        error_reporter,
        "load_configuration",
        lambda: ({"MediLink_Config": {"local_storage_path": str(storage)}}, {}),
    )

    def fake_submit_support_bundle_email(zip_path, include_traceback=False, **kwargs):
        calls["zip_path"] = zip_path
        return True

    monkeypatch.setattr(error_reporter, "submit_support_bundle_email", fake_submit_support_bundle_email)

    rc = medicafe_main.run_csv_excluded_insurance_analytics(send_report=True)

    assert rc == 0
    with zipfile.ZipFile(calls["zip_path"], "r") as z:
        names = set(z.namelist())
        assert "csv_excluded_insurance_analytics_latest.json" in names
        assert "csv_excluded_insurance_analytics_latest.txt" in names
        meta = json.loads(z.read("meta.json").decode("utf-8"))
    assert "claim_failure_summary" not in meta
    assert meta["extra_context"]["temporary_openness_policy_note"] == analytics.TEMPORARY_OPENNESS_POLICY_NOTE
