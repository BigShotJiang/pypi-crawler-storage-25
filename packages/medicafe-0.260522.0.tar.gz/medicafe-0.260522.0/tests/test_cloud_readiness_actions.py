#!/usr/bin/env python
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import MagicMock, patch
except ImportError:
    from mock import MagicMock, patch

_TESTS_ROOT = os.path.dirname(os.path.abspath(__file__))
if _TESTS_ROOT not in sys.path:
    sys.path.insert(0, _TESTS_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean


class CloudReadinessActionsTests(unittest.TestCase):

    def _resolve_script(self, repo_root, python_exe, script_name):
        return (
            True,
            '',
            repo_root,
            os.path.join(repo_root, 'scripts', 'unified_model', script_name),
            None,
        )

    def test_phase_d_dat_smoke_launches_tracked_wrapper_with_attempt_metadata(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        temp_root = tempfile.mkdtemp(prefix='mc_actions_')
        try:
            repo_root = os.path.join(temp_root, 'repo')
            lab_root = os.path.join(temp_root, 'lab')
            smoke_lab = os.path.join(repo_root, 'phase_d_dat_smoke_lab')
            state_path = os.path.join(lab_root, 'phase_d_dat_smoke_state.json')
            os.makedirs(os.path.join(repo_root, 'scripts', 'unified_model'))
            os.makedirs(lab_root)

            proc = MagicMock()
            proc.pid = 4321

            with patch.object(cr, '_resolve_unified_model_script', side_effect=self._resolve_script):
                with patch.object(cr, 'resolve_lab_root', return_value=lab_root):
                    with patch.object(cr, 'is_pipeline_running', return_value=False):
                        with patch.object(cr, 'phase_d_dat_smoke_state_path', return_value=state_path):
                            with patch.object(cr, 'begin_phase_d_dat_smoke_attempt', return_value=True):
                                with patch.object(actions, '_run_phase_d_dat_smoke_existing_lab_report', return_value=(False, 'no report', {})):
                                    with patch.object(cr.subprocess, 'Popen', return_value=proc) as popen_mock:
                                        ok, msg, meta = actions.run_phase_d_dat_smoke(
                                            repo_root,
                                            'python.exe',
                                            {'target_folder': 'target', 'source_folder': 'source'},
                                            reference_phase_d_summary_path='reference.json',
                                            recommendation_anchor_run_id='anchor-1',
                                            recommendation_context_run_id='context-1',
                                            recommendation_issue_code='issue-1',
                                        )

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(meta.get('async_launch'))
            self.assertEqual(meta.get('pid'), 4321)
            self.assertTrue(meta.get('attempt_id'))
            self.assertTrue(meta.get('attempt_path'))
            self.assertTrue(meta.get('tracked_wrapper_script').endswith('run_tracked_diagnostic.py'))
            self.assertTrue(meta.get('expected_artifacts'))
            self.assertEqual(meta.get('expected_artifact_status'), 'phase_d_dat_smoke_report_expected_async')
            self.assertTrue(any(
                row.get('kind') == 'phase_d_dat_smoke_report_json'
                for row in meta.get('expected_artifacts') or []))

            popen_mock.assert_called_once()
            cmd = popen_mock.call_args[0][0]
            kwargs = popen_mock.call_args[1]
            self.assertEqual(cmd[0], 'python.exe')
            self.assertTrue(cmd[1].endswith('run_tracked_diagnostic.py'))
            self.assertIn('--kind', cmd)
            self.assertEqual(cmd[cmd.index('--kind') + 1], 'phase_d_dat_smoke')
            self.assertIn('--lab-dir', cmd)
            self.assertEqual(cmd[cmd.index('--lab-dir') + 1], lab_root)
            self.assertIn('--attempt-id', cmd)
            self.assertEqual(cmd[cmd.index('--attempt-id') + 1], meta.get('attempt_id'))
            self.assertIn('--target-anchor-run-id', cmd)
            self.assertEqual(cmd[cmd.index('--target-anchor-run-id') + 1], 'anchor-1')
            self.assertIn('--target-context-run-id', cmd)
            self.assertEqual(cmd[cmd.index('--target-context-run-id') + 1], 'context-1')
            self.assertIn('--issue-code', cmd)
            self.assertEqual(cmd[cmd.index('--issue-code') + 1], 'issue-1')
            self.assertIn('--', cmd)
            child_cmd = cmd[cmd.index('--') + 1:]
            self.assertEqual(child_cmd[0], 'python.exe')
            self.assertTrue(child_cmd[1].endswith('run_phase_d_dat_smoke.py'))
            self.assertIn('--state-path', child_cmd)
            self.assertEqual(child_cmd[child_cmd.index('--state-path') + 1], state_path)
            self.assertIn('--attempt-id', child_cmd)
            self.assertEqual(child_cmd[child_cmd.index('--attempt-id') + 1], meta.get('attempt_id'))
            self.assertEqual(kwargs.get('cwd'), repo_root)
            self.assertEqual(kwargs.get('env').get('MEDICAFE_LAB_DIR'), smoke_lab)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_phase_d_dat_smoke_writes_report_only_from_existing_lab_before_async(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        temp_root = tempfile.mkdtemp(prefix='mc_actions_report_only_')
        try:
            repo_root = os.path.join(temp_root, 'repo')
            lab_root = os.path.join(temp_root, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(os.path.join(repo_root, 'scripts', 'unified_model'))
            os.makedirs(reports_dir)

            class ReportProc(object):
                returncode = 0

                def communicate(self):
                    payload = {
                        'anchor_run_id': 'anchor-1',
                        'assessment': 'dat_discovered_not_ingested',
                        'dat_funnel': {
                            'dat_manifest_rows_count': 7,
                            'matching_evaluation_status': 'blocked',
                            'patid_matching_evaluated': False,
                            'patid_matching_blocked_reason': 'phase_d_selected_zero_dat_rows',
                        },
                    }
                    with open(os.path.join(reports_dir, 'phase_d_dat_smoke_report_anchor-1.json'), 'w', encoding='utf-8') as f:
                        json.dump(payload, f)
                    with open(os.path.join(reports_dir, 'phase_d_dat_smoke_report_anchor-1.txt'), 'w', encoding='utf-8') as f:
                        f.write('assessment: dat_discovered_not_ingested\n')
                    return b'ok', b''

            with patch.object(cr, '_resolve_unified_model_script', side_effect=self._resolve_script):
                with patch.object(cr, 'resolve_lab_root', return_value=lab_root):
                    with patch.object(cr.subprocess, 'Popen', return_value=ReportProc()) as popen_mock:
                        ok, msg, meta = actions.run_phase_d_dat_smoke(
                            repo_root,
                            'python.exe',
                            {},
                            recommendation_anchor_run_id='anchor-1',
                            recommendation_context_run_id='context-1',
                            recommendation_issue_code='issue-1',
                        )
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(meta.get('report_only'))
            self.assertFalse(meta.get('async_launch'))
            self.assertEqual(meta.get('report_assessment'), 'dat_discovered_not_ingested')
            with patch.object(cr, 'resolve_lab_root', return_value=lab_root):
                state = cr.read_phase_d_dat_smoke_state(repo_root)
            self.assertEqual(state.get('last_status'), 'completed')
            self.assertEqual(state.get('last_requested_anchor_run_id'), 'anchor-1')
            self.assertEqual(state.get('last_report_path'), os.path.join(reports_dir, 'phase_d_dat_smoke_report_anchor-1.txt'))
            cmd = popen_mock.call_args[0][0]
            self.assertTrue(cmd[1].endswith('report_phase_d_dat_smoke.py'))
            self.assertIn('--anchor-run-id', cmd)
            self.assertEqual(cmd[cmd.index('--anchor-run-id') + 1], 'anchor-1')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_phase_b_manual_launches_tracked_wrapper_without_terminal_output(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        temp_root = tempfile.mkdtemp(prefix='mc_actions_phase_b_')
        try:
            repo_root = os.path.join(temp_root, 'repo')
            lab_root = os.path.join(temp_root, 'lab')
            os.makedirs(os.path.join(repo_root, 'scripts', 'unified_model'))
            os.makedirs(lab_root)

            proc = MagicMock()
            proc.pid = 9876

            with patch.object(cr, '_resolve_unified_model_script', side_effect=self._resolve_script):
                with patch.object(cr, 'resolve_lab_root', return_value=lab_root):
                    with patch.object(cr.subprocess, 'Popen', return_value=proc) as popen_mock:
                        ok, msg, meta = actions.run_phase_b_manual(
                            repo_root,
                            'python.exe',
                            {'target_folder': 'target', 'source_folder': 'source'},
                        )

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertIsNone(meta)
            popen_mock.assert_called_once()
            cmd = popen_mock.call_args[0][0]
            kwargs = popen_mock.call_args[1]
            self.assertTrue(cmd[1].endswith('run_tracked_diagnostic.py'))
            self.assertIn('--kind', cmd)
            self.assertEqual(cmd[cmd.index('--kind') + 1], 'phase_b_manual')
            self.assertNotIn('--echo-child-output', cmd)
            self.assertIn('--', cmd)
            child_cmd = cmd[cmd.index('--') + 1:]
            self.assertEqual(child_cmd[0], 'python.exe')
            self.assertTrue(child_cmd[1].endswith('discover_artifacts.py'))
            self.assertEqual(kwargs.get('env').get('MEDICAFE_LAB_DIR'), lab_root)
            self.assertEqual(kwargs.get('env').get('target_folder'), 'target')
            self.assertEqual(kwargs.get('env').get('source_folder'), 'source')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_open_phase_c_summary_uses_simple_phase_spec(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        with patch.object(cr, 'resolve_lab_root', return_value='C:\\lab'):
            with patch.object(cr, '_find_latest_by_prefix', return_value=('C:\\lab\\reports\\ingest.json', '')) as find_mock:
                ok, msg, path = actions.open_phase_c_summary('C:\\repo')

        self.assertTrue(ok)
        self.assertEqual(msg, '')
        self.assertEqual(path, 'C:\\lab\\reports\\ingest.json')
        find_mock.assert_called_once_with(
            os.path.join('C:\\lab', 'reports'),
            'ingest_write_summary_',
            ('.txt', '.json'),
        )

    def test_send_phase_d_evidence_uses_simple_phase_spec(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        with patch.object(cr, 'resolve_lab_root', return_value='C:\\lab'):
            with patch.object(cr, '_send_phase_evidence', return_value=(True, '', None)) as send_mock:
                ok, msg, meta = actions.send_phase_d_evidence('C:\\repo')

        self.assertTrue(ok)
        self.assertEqual(msg, '')
        self.assertIsNone(meta)
        send_mock.assert_called_once_with(
            'C:\\lab',
            [
                ('qa_canonical_summary_', '.json'),
                ('qa_canonical_summary_', '.txt'),
                ('qa_reject_samples_', '.jsonl'),
            ],
            'phase_d_evidence',
            'No Phase D summaries or reject samples to attach.',
        )

    def test_run_phase_d_manual_preserves_phase_d_classes_env(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        temp_root = tempfile.mkdtemp(prefix='mc_actions_phase_d_')
        try:
            repo_root = os.path.join(temp_root, 'repo')
            lab_root = os.path.join(temp_root, 'lab')
            os.makedirs(os.path.join(repo_root, 'scripts', 'unified_model'))
            os.makedirs(lab_root)

            proc = MagicMock()
            proc.pid = 2468

            with patch.object(cr, '_resolve_unified_model_script', side_effect=self._resolve_script):
                with patch.object(cr, 'resolve_lab_root', return_value=lab_root):
                    with patch.object(cr, '_normalize_phase_d_reprocess_classes', return_value=['csv', 'docx']):
                        with patch.object(cr.subprocess, 'Popen', return_value=proc) as popen_mock:
                            ok, msg, meta = actions.run_phase_d_manual(
                                repo_root,
                                'python.exe',
                                {},
                                artifact_classes=['csv', 'docx'],
                            )

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(isinstance(meta, dict))
            kwargs = popen_mock.call_args[1]
            self.assertEqual(kwargs.get('env').get('MEDICAFE_LAB_DIR'), lab_root)
            self.assertEqual(kwargs.get('env').get('MEDICAFE_PHASE_D_ARTIFACT_CLASSES'), 'csv,docx')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_run_phase_d_manual_stamps_target_identity_from_lab_state(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        temp_root = tempfile.mkdtemp(prefix='mc_actions_phase_d_target_')
        try:
            repo_root = os.path.join(temp_root, 'repo')
            lab_root = os.path.join(temp_root, 'lab')
            os.makedirs(os.path.join(repo_root, 'scripts', 'unified_model'))
            os.makedirs(lab_root)
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({
                    'last_shadow_pipeline_run_id': 'anchor-1',
                    'last_phase_d_run_id': 'phase-d-1',
                }, handle)

            proc = MagicMock()
            proc.pid = 2468

            with patch.object(cr, '_resolve_unified_model_script', side_effect=self._resolve_script):
                with patch.object(cr, 'resolve_lab_root', return_value=lab_root):
                    with patch.object(cr.subprocess, 'Popen', return_value=proc) as popen_mock:
                        ok, msg, meta = actions.run_phase_d_manual(repo_root, 'python.exe', {})

            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertTrue(isinstance(meta, dict))
            self.assertEqual(meta.get('expected_artifact_status'), 'phase_d_report_expected_async')
            self.assertTrue(meta.get('expected_primary_report_pattern', '').endswith(
                os.path.join('reports', 'qa_canonical_summary_<phase_d_run_id>.json')))
            self.assertTrue(meta.get('expected_artifacts'))
            cmd = popen_mock.call_args[0][0]
            self.assertIn('--target-anchor-run-id', cmd)
            self.assertEqual(cmd[cmd.index('--target-anchor-run-id') + 1], 'anchor-1')
            self.assertIn('--target-context-run-id', cmd)
            self.assertEqual(cmd[cmd.index('--target-context-run-id') + 1], 'phase-d-1')
            assert_workflow_boundary_clean('phase_d_manual_diagnostic_attempt', {
                'anchor_run_id': 'anchor-1',
                'context_run_id': 'phase-d-1',
            }, [
                {
                    'name': 'diagnostic_attempt_phase_d_manual',
                    'role': 'attempt',
                    'identity': {'anchor_run_id': 'anchor-1', 'context_run_id': 'phase-d-1'},
                    'status': 'started',
                },
            ])
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_phase_d_manual_terminal_reconciler_patches_primary_report_path(self):
        from MediCafe import diagnostic_attempts
        from MediCafe import cloud_readiness_actions as actions

        temp_root = tempfile.mkdtemp(prefix='mc_actions_phase_d_reconcile_')
        try:
            lab_root = os.path.join(temp_root, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            attempt_id = 'attempt-1'
            diagnostic_attempts.begin_attempt(
                lab_root,
                'phase_d_manual',
                target_anchor_run_id='PIPE',
                target_context_run_id='PIPE',
                attempt_id=attempt_id,
            )
            diagnostic_attempts.finish_attempt(
                lab_root,
                'phase_d_manual',
                attempt_id,
                returncode=0,
                primary_report_path='',
                resolved_artifacts=[],
            )
            rid = '20260512-122601-abcd1234'
            summary_json = os.path.join(reports_dir, 'qa_canonical_summary_{0}.json'.format(rid))
            summary_txt = os.path.join(reports_dir, 'qa_canonical_summary_{0}.txt'.format(rid))
            reject_samples = os.path.join(reports_dir, 'qa_reject_samples_{0}.jsonl'.format(rid))
            dat_anchor_profile_json = os.path.join(
                reports_dir, 'dat_anchor_failure_profile_{0}.json'.format(rid))
            dat_anchor_profile_txt = os.path.join(
                reports_dir, 'dat_anchor_failure_profile_{0}.txt'.format(rid))
            with open(summary_json, 'w', encoding='utf-8') as handle:
                json.dump({'run_id': rid, 'ok': True}, handle)
            with open(summary_txt, 'w', encoding='utf-8') as handle:
                handle.write('Phase D QA and Canonicalization Summary\n')
            with open(reject_samples, 'w', encoding='utf-8') as handle:
                handle.write('')
            with open(dat_anchor_profile_json, 'w', encoding='utf-8') as handle:
                json.dump({'run_id': rid, 'schema_version': 'dat_anchor_failure_profile_v1'}, handle)
            with open(dat_anchor_profile_txt, 'w', encoding='utf-8') as handle:
                handle.write('DAT Anchor Failure Profile\n')
            with open(os.path.join(lab_root, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({'last_phase_d_run_id': rid}, handle)

            patched = actions._finalize_phase_d_manual_attempt_report_hints(
                lab_root,
                attempt_id,
                started_epoch=0,
                prior_phase_d_run_id='old-run',
                returncode=0,
            )

            self.assertTrue(patched)
            doc = diagnostic_attempts.read_attempt(lab_root, 'phase_d_manual', attempt_id)
            self.assertEqual(doc.get('primary_report_path'), summary_json)
            self.assertEqual(doc.get('domain_status'), 'phase_d_report_resolved')
            self.assertIn(summary_json, doc.get('resolved_artifacts') or [])
            self.assertIn(dat_anchor_profile_json, doc.get('resolved_artifacts') or [])
            expected = doc.get('expected_artifacts') or []
            self.assertTrue(any(row.get('path') == summary_json for row in expected))
            self.assertTrue(any(row.get('path') == reject_samples for row in expected))
            self.assertTrue(any(row.get('path') == dat_anchor_profile_json for row in expected))
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_diagnostic_attempt_lifecycle_preserves_seeded_report_hints(self):
        from MediCafe import diagnostic_attempts

        temp_root = tempfile.mkdtemp(prefix='mc_actions_attempt_preserve_')
        try:
            lab_root = os.path.join(temp_root, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            attempt_id = 'attempt-1'
            summary_json = os.path.join(reports_dir, 'qa_canonical_summary_phase-d-1.json')
            expected = [{'kind': 'phase_d_qa_summary_json', 'path': summary_json}]
            diagnostic_attempts.begin_attempt(
                lab_root,
                'phase_d_manual',
                target_anchor_run_id='anchor-1',
                target_context_run_id='phase-d-1',
                attempt_id=attempt_id,
                expected_artifacts=expected,
            )
            diagnostic_attempts.finish_attempt(
                lab_root,
                'phase_d_manual',
                attempt_id,
                returncode=0,
                primary_report_path=summary_json,
                resolved_artifacts=[summary_json],
            )

            # The tracked diagnostic wrapper calls begin/finish around the child
            # command without expected_artifacts or primary_report_path. That
            # must not erase the richer launch-time/terminal hints.
            diagnostic_attempts.begin_attempt(
                lab_root,
                'phase_d_manual',
                target_anchor_run_id='anchor-1',
                target_context_run_id='phase-d-1',
                attempt_id=attempt_id,
            )
            diagnostic_attempts.finish_attempt(
                lab_root,
                'phase_d_manual',
                attempt_id,
                returncode=0,
            )

            doc = diagnostic_attempts.read_attempt(lab_root, 'phase_d_manual', attempt_id)
            self.assertEqual(doc.get('primary_report_path'), summary_json)
            self.assertEqual(doc.get('resolved_artifacts'), [summary_json])
            self.assertEqual(doc.get('expected_artifacts'), expected)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_run_historical_phase_d_reprocess_returns_expected_report_metadata(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        payload = {
            'ok': True,
            'targeted_artifact_classes': ['dat'],
            'remediation_context_run_id': 'PIPE',
            'execution_report_path': 'execution.txt',
        }
        run_meta = {
            'attempt_id': 'attempt-1',
            'attempt_path': 'attempt.json',
            'pid': 123,
            'expected_artifacts': [
                {
                    'kind': 'phase_d_qa_summary_json',
                    'pattern': 'reports/qa_canonical_summary_<phase_d_run_id>.json',
                    'status': 'expected_after_async_run_id',
                },
            ],
            'expected_artifact_status': 'phase_d_report_expected_async',
            'primary_report_path': '',
            'expected_primary_report_pattern': 'reports/qa_canonical_summary_<phase_d_run_id>.json',
        }
        with patch.object(actions, '_ensure_historical_phase_d_reprocess_helpers', return_value=(True, '', None)):
            with patch.object(cr, '_execute_historical_phase_d_reprocess_impl', return_value=payload):
                with patch.object(cr, 'resolve_lab_root', return_value='C:\\lab'):
                    with patch.object(cr, '_normalize_phase_d_reprocess_classes', return_value=['dat']):
                        with patch.object(cr, 'run_phase_d_manual', return_value=(True, '', run_meta)):
                            ok, msg, data = actions.run_historical_phase_d_reprocess(
                                'C:\\repo',
                                'python.exe',
                                {},
                                artifact_classes=['dat'],
                                remediation_context_run_id='PIPE',
                            )

        self.assertTrue(ok)
        self.assertIn('Historical Phase D re-evaluation', msg)
        self.assertEqual(data.get('phase_d_attempt_id'), 'attempt-1')
        self.assertEqual(data.get('phase_d_expected_artifact_status'), 'phase_d_report_expected_async')
        self.assertEqual(
            data.get('phase_d_expected_primary_report_pattern'),
            'reports/qa_canonical_summary_<phase_d_run_id>.json',
        )
        self.assertTrue(data.get('phase_d_expected_artifacts'))

    def test_run_phase_c_manual_propagates_launch_failure(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_actions as actions

        with patch.object(cr, '_resolve_unified_model_script', return_value=(True, '', 'C:\\repo', 'C:\\repo\\ingest_from_manifest.py', None)):
            with patch.object(cr, 'resolve_lab_root', return_value='C:\\lab'):
                with patch.object(actions, '_launch_tracked_diagnostic_async', return_value=(False, 'launch failed', {})):
                    ok, msg, meta = actions.run_phase_c_manual('C:\\repo', 'python.exe', {})

        self.assertFalse(ok)
        self.assertEqual(msg, 'launch failed')
        self.assertIsNone(meta)


if __name__ == '__main__':
    unittest.main()
