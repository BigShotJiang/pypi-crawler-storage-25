#!/usr/bin/env python
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import MagicMock, patch
except ImportError:
    from mock import MagicMock, patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class LauncherStartupPreflightCacheTests(unittest.TestCase):

    def _make_orchestrator(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
        args = MagicMock()
        args.skip_csv = False
        args.direct_action = None
        args.debug_mode = False
        args.auto_choice = None
        session = SessionConfig(args)
        session.non_interactive = True
        return MediCafeOrchestrator(session)

    def _write_json(self, path, payload):
        with open(path, 'w') as handle:
            json.dump(payload, handle)

    def _prepare_temp_env(self):
        root = tempfile.mkdtemp(prefix='mc_startup_preflight_')
        storage = os.path.join(root, 'storage')
        os.makedirs(storage)
        config_path = os.path.join(root, 'config.json')
        crosswalk_path = os.path.join(root, 'crosswalk.json')
        self._write_json(config_path, {'MediLink_Config': {'local_storage_path': storage}})
        self._write_json(crosswalk_path, {})
        return root, storage, config_path

    def _patch_prepare_fast_paths(self, orch):
        patches = [
            patch.object(orch, '_ensure_directories'),
            patch.object(orch, '_copy_update_script_to_legacy'),
            patch.object(orch, '_validate_config', return_value=True),
            patch.object(orch, '_apply_config_env'),
            patch.object(orch, '_determine_medicafe_version', side_effect=lambda: setattr(orch, 'medicafe_version', '1.0.0')),
            patch.object(orch, '_check_for_updates'),
            patch.object(orch, '_check_payer_list_update'),
        ]
        started = []
        for item in patches:
            started.append(item.start())
            self.addCleanup(item.stop)
        return started

    def test_prepare_skips_startup_preflight_when_cache_valid(self):
        from MediCafe.launcher_preflight_cache import write_preflight_cache
        root, storage, config_path = self._prepare_temp_env()
        try:
            orch = self._make_orchestrator()
            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = storage
            context = orch._build_preflight_context()
            cache_path = orch._launcher_preflight_cache_path()
            self.assertTrue(write_preflight_cache(
                cache_path,
                True,
                '1.0.0',
                orch._preflight_cache_artifact_paths(context),
            ))
            self._patch_prepare_fast_paths(orch)
            with patch('MediCafe.preflight.run_preflight') as run_preflight:
                orch.prepare()

            run_preflight.assert_not_called()
            self.assertFalse(orch._preflight_state.get('first_local_workflow'))
            self.assertTrue(orch._preflight_state.get('last_preflight_ok'))
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_prepare_runs_startup_preflight_when_cache_mtime_changes(self):
        from MediCafe.launcher_preflight_cache import write_preflight_cache
        root, storage, config_path = self._prepare_temp_env()
        try:
            orch = self._make_orchestrator()
            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = storage
            context = orch._build_preflight_context()
            cache_path = orch._launcher_preflight_cache_path()
            self.assertTrue(write_preflight_cache(
                cache_path,
                True,
                '1.0.0',
                orch._preflight_cache_artifact_paths(context),
            ))
            original_mtime = os.path.getmtime(config_path)
            os.utime(config_path, (original_mtime, original_mtime + 5))
            self._patch_prepare_fast_paths(orch)
            report = {
                'counts': {'pass': 7, 'warn': 0, 'fail': 0},
                'results': [],
                'duration_ms': 1,
            }
            with patch('MediCafe.preflight.run_preflight', return_value=(0, report)) as run_preflight:
                orch.prepare()

            run_preflight.assert_called_once()
            self.assertFalse(orch._preflight_state.get('first_local_workflow'))
            self.assertTrue(orch._preflight_state.get('last_preflight_ok'))
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_prepare_runs_startup_preflight_when_cache_version_mismatches(self):
        from MediCafe.launcher_preflight_cache import write_preflight_cache
        root, storage, config_path = self._prepare_temp_env()
        try:
            orch = self._make_orchestrator()
            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = storage
            context = orch._build_preflight_context()
            cache_path = orch._launcher_preflight_cache_path()
            self.assertTrue(write_preflight_cache(
                cache_path,
                True,
                '0.9.0',
                orch._preflight_cache_artifact_paths(context),
            ))
            self._patch_prepare_fast_paths(orch)
            report = {
                'counts': {'pass': 7, 'warn': 0, 'fail': 0},
                'results': [],
                'duration_ms': 1,
            }
            with patch('MediCafe.preflight.run_preflight', return_value=(0, report)) as run_preflight:
                orch.prepare()

            run_preflight.assert_called_once()
            self.assertTrue(orch._preflight_state.get('last_preflight_ok'))
        finally:
            shutil.rmtree(root, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
