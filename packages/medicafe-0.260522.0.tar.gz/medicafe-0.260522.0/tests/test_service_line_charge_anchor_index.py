import importlib.util
import json
import os
import sqlite3


_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
_SCRIPT = os.path.join(_ROOT, "scripts", "unified_model", "build_service_line_charge_anchor_index.py")


def _load_module():
    spec = importlib.util.spec_from_file_location("build_service_line_charge_anchor_index_test", _SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _write_saved_837p(path, claim_number="CHART20260120", charge="580", minutes="42", dos="20260120"):
    path.write_text(
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260120*1200*^*00501*1*0*P*:~"
        "GS*HC*SENDER*RECEIVER*20260120*1200*1*X*005010X222A1~"
        "ST*837*0001*005010X222A1~"
        "CLM*{0}*{1}***11:B:1*Y*A*Y*Y~"
        "HI*ABK:H25811~"
        "LX*1~"
        "SV1*HC:00142*{1}*MJ*{2}***1~"
        "DTP*472*D8*{3}~"
        "SE*8*0001~".format(claim_number, charge, minutes, dos),
        encoding="utf-8",
    )


def _write_saved_837p_batch(path, claims):
    chunks = [
        "ISA*00*          *00*          *ZZ*SENDER*ZZ*RECEIVER*260120*1200*^*00501*1*0*P*:~",
        "GS*HC*SENDER*RECEIVER*20260120*1200*1*X*005010X222A1~",
    ]
    index = 1
    for claim in claims:
        chunks.append(
            "ST*837*{0:04d}*005010X222A1~"
            "NM1*PR*2*UNITED*****PI*{1}~"
            "CLM*{2}*{3}***11:B:1*Y*A*Y*Y~"
            "HI*ABK:H25811~"
            "LX*1~"
            "SV1*HC:00142*{3}*MJ*{4}***1~"
            "DTP*472*D8*{5}~"
            "SE*9*{0:04d}~".format(
                index,
                claim.get("payer", "87726"),
                claim.get("claim_number", "CLAIM{0}".format(index)),
                claim.get("charge", "580"),
                claim.get("minutes", "42"),
                claim.get("dos", "20260120"),
            )
        )
        index += 1
    path.write_text("".join(chunks), encoding="utf-8")


def _write_submission_index(receipts, rows):
    with (receipts / "submission_index.jsonl").open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True))
            handle.write("\n")


def _write_canonical_dat_db(lab, rows):
    lab.mkdir(parents=True, exist_ok=True)
    db_path = lab / "unified_model_xp.db"
    conn = sqlite3.connect(str(db_path))
    try:
        conn.execute(
            "CREATE TABLE extracted_canonical_record ("
            "canonical_record_id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "artifact_id INTEGER,"
            "canonical_type TEXT,"
            "canonical_json TEXT,"
            "provenance_json TEXT)"
        )
        for idx, row in enumerate(rows):
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(artifact_id, canonical_type, canonical_json, provenance_json) "
                "VALUES (?, 'dat_record', ?, ?)",
                (
                    idx + 1,
                    json.dumps(row, sort_keys=True),
                    json.dumps({"record_index": idx, "source_ref": "redacted"}, sort_keys=True),
                ),
            )
        conn.commit()
    finally:
        conn.close()
    return db_path


def test_anchor_index_builds_dat_anchor_and_reports_unkeyable_837p():
    mod = _load_module()

    payload = mod.build_anchor_index(
        dat_records=[{
            "patid": "12345",
            "service_date": "01/20/2026",
            "charge_amount": "580",
            "anesthesia_minutes": "42",
        }],
        x12_rows=[{
            "service_date": "20260121",
            "line_charge_amount": "540.00",
            "anesthesia_minutes": "18",
        }],
        run_id="fixed-run",
        generated_at_utc="2026-05-15T00:00:00Z",
    )

    assert payload["schema_version"] == "service_line_charge_anchor_index.v1"
    assert payload["workflow_boundary"] == "report_only_review_required"
    assert payload["claims_completion"] is False
    assert payload["mutates_dat"] is False
    assert payload["mutates_837p"] is False
    assert payload["charges_entered"] is False
    assert payload["summary"]["anchor_count"] == 1
    assert payload["summary"]["x12_unkeyable_row_count"] == 1
    anchor = payload["anchors"][0]
    assert anchor["patient_id"] == "12345"
    assert anchor["anchor_source_dos"] == "01-20-2026"
    assert anchor["charge_amount"] == "580.00"
    assert anchor["charge_display"] == "$580"
    assert anchor["same_patient_anchor_charge_note"] == "same-patient DOS anchor from 01-20-2026"
    assert anchor["submitted_out_of_custody"] is True
    assert anchor["claims_completion"] is False


def test_anchor_index_reports_unkeyable_x12_advisory_when_no_local_patient_key():
    mod = _load_module()

    payload = mod.build_anchor_index(
        dat_records=[],
        x12_rows=[{
            "service_date": "20260121",
            "line_charge_amount": "540.00",
            "anesthesia_minutes": "18",
        }],
        run_id="fixed-run",
        generated_at_utc="2026-05-15T00:00:00Z",
    )

    summary = payload["summary"]
    assert summary["anchor_count"] == 0
    assert summary["x12_row_count"] == 1
    assert summary["x12_unkeyable_row_count"] == 1
    assert summary["rejected_counts"]["unkeyable_837p_patient_id"] == 1
    assert summary["advisory_code"] == "x12_rows_without_local_patient_key"
    assert "local patient key" in summary["advisory_detail"]


def test_anchor_index_dedupes_same_patient_dos_and_prefers_dat():
    mod = _load_module()

    payload = mod.build_anchor_index(
        dat_records=[{
            "patid": "12345",
            "service_date": "01-20-2026",
            "charge_amount": "450.00",
        }],
        x12_rows=[{
            "patient_id": "12345",
            "service_date": "20260120",
            "line_charge_amount": "580.00",
        }],
        run_id="fixed-run",
    )

    assert len(payload["anchors"]) == 1
    assert payload["anchors"][0]["anchor_source"] == "dat"
    assert payload["anchors"][0]["charge_amount"] == "450.00"
    assert payload["anchors"][0]["duplicate_source_count"] == 2


def test_dat_anchor_requires_patid_and_rejects_chart_only():
    mod = _load_module()

    payload = mod.build_anchor_index(
        dat_records=[{
            "CHART": "ABC123",
            "service_date": "01-20-2026",
            "charge_amount": "450.00",
        }],
        run_id="chart-only-run",
    )

    assert payload["summary"]["anchor_count"] == 0
    assert payload["summary"]["rejected_counts"]["dat_missing_patid"] == 1


def test_canonical_dat_anchor_uses_shadow_db_patient_id_and_charge(monkeypatch, tmp_path):
    mod = _load_module()
    lab = tmp_path / "lab"
    storage = tmp_path / "storage"
    _write_canonical_dat_db(lab, [{
        "patient_id": "12345",
        "date_of_service": "2026-01-20",
        "charged_amount": "580",
        "anesthesia_minutes": "42",
        "chart_number": "CHART123",
    }])

    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [str(lab)])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])
    monkeypatch.setattr(mod, "load_x12_rows_for_anchor", lambda config, configured, output: ([], {
        "x12_rows_resolution": "none",
        "x12_direct_scan_status": "not_needed",
        "x12_row_file_count": 0,
    }))

    payload, _paths = mod.run(
        config={"MediLink_Config": {"local_storage_path": str(storage)}},
        write_index=False,
        run_id="canonical-dat-run",
    )

    summary = payload["summary"]
    source = summary["source_summary"]
    assert summary["anchor_count"] == 1
    assert summary["canonical_dat_record_count"] == 1
    assert summary["canonical_dat_anchor_count"] == 1
    assert source["canonical_dat_read_status"] == "loaded"
    assert source["canonical_dat_db_present_count"] == 1
    anchor = payload["anchors"][0]
    assert anchor["anchor_source"] == "canonical_dat"
    assert anchor["patient_id"] == "12345"
    assert anchor["anchor_source_dos"] == "01-20-2026"
    assert anchor["charge_amount"] == "580.00"
    assert anchor["same_patient_anchor_charge_note"] == "same-patient DOS anchor from 01-20-2026"


def test_canonical_dat_rejects_chart_only_patient_identity():
    mod = _load_module()

    payload = mod.build_anchor_index(
        canonical_dat_records=[{
            "_anchor_source": "canonical_dat",
            "chart_number": "12345",
            "date_of_service": "01-20-2026",
            "charged_amount": "580",
        }],
        run_id="canonical-chart-only",
    )

    assert payload["summary"]["anchor_count"] == 0
    assert payload["summary"]["canonical_dat_record_count"] == 1
    assert payload["summary"]["rejected_counts"]["dat_missing_patid"] == 1


def test_anchor_index_dedupe_prefers_raw_dat_then_canonical_dat_then_saved_837p():
    mod = _load_module()

    payload = mod.build_anchor_index(
        dat_records=[{
            "patid": "12345",
            "service_date": "01-20-2026",
            "charge_amount": "450.00",
        }],
        canonical_dat_records=[{
            "_anchor_source": "canonical_dat",
            "patient_id": "12345",
            "date_of_service": "2026-01-20",
            "charged_amount": "580.00",
        }],
        x12_rows=[{
            "patient_id": "12345",
            "service_date": "20260120",
            "line_charge_amount": "540.00",
        }],
        run_id="dedupe-source-run",
    )

    assert len(payload["anchors"]) == 1
    assert payload["anchors"][0]["anchor_source"] == "dat"
    assert payload["anchors"][0]["charge_amount"] == "450.00"
    assert payload["anchors"][0]["duplicate_source_count"] == 3
    assert payload["summary"]["raw_dat_anchor_count"] == 1
    assert payload["summary"]["canonical_dat_anchor_count"] == 1
    assert payload["summary"]["saved_837p_anchor_count"] == 1


def test_anchor_index_writes_reports_and_optional_state(tmp_path):
    mod = _load_module()
    payload = mod.build_anchor_index(
        dat_records=[{
            "patid": "12345",
            "service_date": "01-20-2026",
            "charge_amount": "450.00",
        }],
        run_id="write-run",
    )

    paths = mod.write_reports(str(tmp_path), payload, write_index=True)

    assert os.path.exists(paths["summary_json"])
    assert os.path.exists(paths["summary_txt"])
    assert os.path.exists(paths["state_path"])
    assert paths["state_path"].endswith(".service_line_charge_anchor_index.json")


def test_discover_dat_files_skips_inaccessible_roots(monkeypatch):
    mod = _load_module()

    def fake_isfile(path):
        if path == "G:\\":
            raise OSError("access denied")
        return False

    def fake_isdir(path):
        if path == "G:\\":
            raise OSError("access denied")
        return False

    monkeypatch.setattr(mod.os.path, "isfile", fake_isfile)
    monkeypatch.setattr(mod.os.path, "isdir", fake_isdir)

    assert mod.discover_dat_files({
        "MediLink_Config": {
            "local_storage_path": "G:\\",
            "local_claims_path": "",
        }
    }) == []


def test_run_falls_back_when_configured_storage_is_inaccessible(monkeypatch, tmp_path):
    mod = _load_module()
    fallback = tmp_path / "fallback"

    def fake_directory_is_writable(path):
        return str(path) == str(fallback)

    monkeypatch.setenv("MEDICAFE_SERVICE_LINE_ANCHOR_FALLBACK_DIR", str(fallback))
    monkeypatch.setattr(mod, "_directory_is_writable", fake_directory_is_writable)
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])
    monkeypatch.setattr(mod, "load_x12_rows_for_anchor", lambda config, configured, output: ([], {
        "x12_report_dirs_checked": [],
        "x12_report_dirs_with_rows": [],
        "x12_row_file_count": 0,
    }))

    payload, paths = mod.run(
        config={"MediLink_Config": {"local_storage_path": "G:\\"}},
        write_index=True,
        run_id="fallback-run",
    )

    summary = payload["summary"]["source_summary"]
    assert summary["configured_local_storage_path"] == "G:\\"
    assert summary["output_local_storage_path"] == str(fallback)
    assert summary["storage_fallback_reason"] == "configured_storage_inaccessible"
    assert paths["state_path"].startswith(str(fallback))


def test_run_reports_no_anchor_source_rows_advisory(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"

    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])
    monkeypatch.setattr(mod, "load_x12_rows_for_anchor", lambda config, configured, output: ([], {
        "x12_rows_resolution": "none",
        "x12_report_dirs_checked": [str(storage / "reports")],
        "x12_report_dirs_with_rows": [],
        "x12_row_file_count": 0,
        "x12_direct_scan_status": "no_scan_roots",
    }))

    payload, _paths = mod.run(
        config={"MediLink_Config": {"local_storage_path": str(storage)}},
        write_index=True,
        run_id="no-source-run",
    )

    summary = payload["summary"]
    source = summary["source_summary"]
    assert summary["anchor_count"] == 0
    assert summary["dat_record_count"] == 0
    assert summary["x12_row_count"] == 0
    assert summary["advisory_code"] == "no_anchor_source_rows_found"
    assert source["x12_rows_resolution"] == "none"
    assert source["x12_direct_scan_status"] == "no_scan_roots"
    lines = mod.format_summary_lines(payload)
    assert "Advisory: no_anchor_source_rows_found" in lines


def test_run_reads_x12_rows_from_configured_storage_when_output_falls_back(monkeypatch, tmp_path):
    mod = _load_module()
    configured = tmp_path / "configured"
    fallback = tmp_path / "fallback"
    expected_rows = [{"patient_id": "12345", "service_date": "20260120", "line_charge_amount": "580.00"}]
    observed_paths = []

    def fake_directory_is_writable(path):
        return str(path) == str(fallback)

    def fake_load_x12_rows(config, configured_storage_path, output_storage_path):
        observed_paths.append((configured_storage_path, output_storage_path))
        if configured_storage_path == str(configured):
            return list(expected_rows), {
                "x12_report_dirs_checked": [str(configured / "reports")],
                "x12_report_dirs_with_rows": [str(configured / "reports")],
                "x12_row_file_count": 1,
                "x12_direct_scan_status": "not_attempted_existing_report_rows_found",
            }
        return [], {
            "x12_report_dirs_checked": [],
            "x12_report_dirs_with_rows": [],
            "x12_row_file_count": 0,
        }

    monkeypatch.setenv("MEDICAFE_SERVICE_LINE_ANCHOR_FALLBACK_DIR", str(fallback))
    monkeypatch.setattr(mod, "_directory_is_writable", fake_directory_is_writable)
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])
    monkeypatch.setattr(mod, "load_x12_rows_for_anchor", fake_load_x12_rows)

    payload, paths = mod.run(
        config={"MediLink_Config": {"local_storage_path": str(configured)}},
        write_index=True,
        run_id="fallback-read-run",
    )

    assert observed_paths == [(str(configured), str(fallback))]
    assert payload["summary"]["x12_row_count"] == 1
    assert payload["summary"]["source_summary"]["output_local_storage_path"] == str(fallback)
    assert payload["summary"]["source_summary"]["x12_row_file_count"] == 1
    assert payload["summary"]["source_summary"]["x12_direct_scan_status"] == "not_attempted_existing_report_rows_found"
    assert paths["state_path"].startswith(str(fallback))


def test_run_reads_x12_rows_from_troubleshooting_lab_reports(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"
    lab = tmp_path / "lab"
    reports = lab / "reports"
    reports.mkdir(parents=True)
    rows_path = reports / "x12_minutes_charge_rows_fixed-run.jsonl"
    rows_path.write_text(
        '{"patient_id":"12345","service_date":"20260120","line_charge_amount":"580.00","anesthesia_minutes":"42"}\n',
        encoding="utf-8",
    )

    monkeypatch.setenv("MEDICAFE_LAB_DIR", str(lab))
    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [str(lab)])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])

    payload, paths = mod.run(
        config={"MediLink_Config": {"local_storage_path": str(storage)}},
        write_index=True,
        run_id="lab-read-run",
    )

    summary = payload["summary"]["source_summary"]
    assert payload["summary"]["x12_row_count"] == 1
    assert payload["summary"]["anchor_count"] == 1
    assert summary["x12_row_file_count"] == 1
    assert summary["x12_direct_scan_status"] == "not_attempted_existing_keyed_report_rows_found"
    assert str(reports) in summary["x12_report_dirs_with_rows"]
    assert payload["anchors"][0]["anchor_source"] == "saved_837p"
    assert payload["anchors"][0]["source_artifact_id"] == "x12_minutes_charge_rows_fixed-run.jsonl"
    assert paths["state_path"].startswith(str(storage))


def test_local_837p_resolution_uses_submission_index_without_persisting_claim_number(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"
    claims = tmp_path / "claims"
    claims.mkdir()
    claim_path = claims / "claim_001.837p"
    _write_saved_837p(claim_path, claim_number="ABC20260120", charge="580", minutes="42", dos="20260120")
    _write_submission_index(claims, [{
        "record_type": "submission",
        "receipt_file": claim_path.name,
        "submitted_claim_number": "ABC20260120",
        "internal_patid": "12345",
        "internal_chart": "ABC",
        "dos": "20260120",
    }])

    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])

    payload, _paths = mod.run(
        config={"MediLink_Config": {
            "local_storage_path": str(storage),
            "local_claims_path": str(claims),
        }},
        write_index=True,
        run_id="local-resolution-run",
    )

    summary = payload["summary"]
    source = summary["source_summary"]
    assert summary["anchor_count"] == 1
    assert summary["x12_unkeyable_row_count"] == 0
    assert source["x12_rows_resolution"] == "local_837p_resolution"
    assert source["local_837p_resolution_status"] == "succeeded"
    assert source["local_837p_claims_seen"] == 1
    assert source["local_837p_submission_index_matches"] == 1
    assert source["local_837p_internal_patid_matches"] == 1
    anchor = payload["anchors"][0]
    assert anchor["patient_id"] == "12345"
    assert anchor["anchor_source"] == "saved_837p"
    assert anchor["anchor_source_dos"] == "01-20-2026"
    assert anchor["charge_amount"] == "580.00"
    serialized_summary = json.dumps(summary, sort_keys=True)
    assert "ABC20260120" not in serialized_summary


def test_local_837p_resolution_matches_mmddyy_clm01_to_submission_index_date_variant(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"
    claims = tmp_path / "claims"
    claims.mkdir()
    claim_path = claims / "claim_001.837p"
    _write_saved_837p(claim_path, claim_number="ABC012026", charge="580", minutes="42", dos="20260120")
    _write_submission_index(claims, [{
        "record_type": "submission",
        "receipt_file": claim_path.name,
        "submitted_claim_number": "ABC01202026",
        "internal_patid": "12345",
        "internal_chart": "ABC",
        "dos": "01/20/2026",
    }])

    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])

    payload, _paths = mod.run(
        config={"MediLink_Config": {
            "local_storage_path": str(storage),
            "local_claims_path": str(claims),
        }},
        write_index=True,
        run_id="variant-run",
    )

    source = payload["summary"]["source_summary"]
    assert payload["summary"]["anchor_count"] == 1
    assert source["local_837p_claim_number_variant_matches"] == 1
    assert payload["anchors"][0]["patient_id"] == "12345"


def test_local_837p_resolution_rejects_ambiguous_claim_number_variant(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"
    claims = tmp_path / "claims"
    claims.mkdir()
    claim_path = claims / "claim_001.837p"
    _write_saved_837p(claim_path, claim_number="ABC012026", charge="580", minutes="42", dos="20260120")
    _write_submission_index(claims, [{
        "record_type": "submission",
        "receipt_file": claim_path.name,
        "internal_patid": "12345",
        "internal_chart": "ABC",
        "dos": "01/20/2026",
    }, {
        "record_type": "submission",
        "receipt_file": claim_path.name,
        "internal_patid": "67890",
        "internal_chart": "ABC",
        "dos": "01/20/2026",
    }])

    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])

    payload, _paths = mod.run(
        config={"MediLink_Config": {
            "local_storage_path": str(storage),
            "local_claims_path": str(claims),
        }},
        write_index=True,
        run_id="ambiguous-run",
    )

    source = payload["summary"]["source_summary"]
    assert payload["summary"]["anchor_count"] == 0
    assert source["local_837p_ambiguous_identity_matches"] == 1
    assert source["local_837p_no_safe_identity_match"] == 1


def test_local_837p_resolution_handles_batch_claims_independently(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"
    claims = tmp_path / "claims"
    claims.mkdir()
    claim_path = claims / "batch_001.837p"
    _write_saved_837p_batch(claim_path, [
        {"claim_number": "AAA012026", "charge": "450", "minutes": "12", "dos": "20260120"},
        {"claim_number": "BBB012126", "charge": "580", "minutes": "42", "dos": "20260121"},
    ])
    _write_submission_index(claims, [{
        "record_type": "submission",
        "receipt_file": claim_path.name,
        "internal_patid": "11111",
        "internal_chart": "AAA",
        "dos": "01/20/2026",
    }, {
        "record_type": "submission",
        "receipt_file": claim_path.name,
        "internal_patid": "22222",
        "internal_chart": "BBB",
        "dos": "01/21/2026",
    }])

    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])

    payload, _paths = mod.run(
        config={"MediLink_Config": {
            "local_storage_path": str(storage),
            "local_claims_path": str(claims),
        }},
        write_index=True,
        run_id="batch-run",
    )

    assert payload["summary"]["anchor_count"] == 2
    assert [a["patient_id"] for a in payload["anchors"]] == ["11111", "22222"]


def test_local_837p_resolution_does_not_copy_single_batch_index_row_to_all_claims(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"
    claims = tmp_path / "claims"
    claims.mkdir()
    claim_path = claims / "batch_001.837p"
    _write_saved_837p_batch(claim_path, [
        {"claim_number": "AAA012026", "charge": "450", "minutes": "12", "dos": "20260120"},
        {"claim_number": "BBB012126", "charge": "580", "minutes": "42", "dos": "20260121"},
    ])
    _write_submission_index(claims, [{
        "record_type": "submission",
        "receipt_file": claim_path.name,
        "submitted_claim_number": "AAA012026",
        "internal_patid": "11111",
        "internal_chart": "AAA",
        "dos": "01/20/2026",
    }])

    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])

    payload, _paths = mod.run(
        config={"MediLink_Config": {
            "local_storage_path": str(storage),
            "local_claims_path": str(claims),
        }},
        write_index=True,
        run_id="batch-single-index-run",
    )

    source = payload["summary"]["source_summary"]
    assert payload["summary"]["anchor_count"] == 1
    assert payload["anchors"][0]["patient_id"] == "11111"
    assert source["local_837p_no_safe_identity_match"] == 1


def test_local_837p_resolution_allows_single_claim_receipt_tiebreak(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"
    claims = tmp_path / "claims"
    claims.mkdir()
    claim_path = claims / "single_001.837p"
    _write_saved_837p(claim_path, claim_number="UNINDEXED012026", charge="450", minutes="12", dos="20260120")
    _write_submission_index(claims, [{
        "record_type": "submission",
        "receipt_file": claim_path.name,
        "internal_patid": "99999",
        "internal_chart": "OTHER",
        "dos": "01/20/2026",
    }])

    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])

    payload, _paths = mod.run(
        config={"MediLink_Config": {
            "local_storage_path": str(storage),
            "local_claims_path": str(claims),
        }},
        write_index=True,
        run_id="single-receipt-run",
    )

    source = payload["summary"]["source_summary"]
    assert payload["summary"]["anchor_count"] == 1
    assert payload["anchors"][0]["patient_id"] == "99999"
    assert source["local_837p_receipt_tiebreak_matches"] == 1


def test_existing_unkeyable_x12_rows_trigger_local_837p_resolution(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"
    reports = storage / "reports"
    claims = tmp_path / "claims"
    reports.mkdir(parents=True)
    claims.mkdir()
    (reports / "x12_minutes_charge_rows_old.jsonl").write_text(
        '{"service_date":"20260121","line_charge_amount":"540.00","anesthesia_minutes":"18"}\n',
        encoding="utf-8",
    )
    claim_path = claims / "claim_001.837p"
    _write_saved_837p(claim_path, claim_number="XYZ20260120", charge="450", minutes="12", dos="20260120")
    _write_submission_index(claims, [{
        "record_type": "submission",
        "receipt_file": claim_path.name,
        "submitted_claim_number": "XYZ20260120",
        "internal_patid": "67890",
        "internal_chart": "XYZ",
        "dos": "20260120",
    }])

    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])

    payload, _paths = mod.run(
        config={"MediLink_Config": {
            "local_storage_path": str(storage),
            "local_claims_path": str(claims),
        }},
        write_index=True,
        run_id="unkeyable-plus-local-run",
    )

    source = payload["summary"]["source_summary"]
    assert payload["summary"]["anchor_count"] == 1
    assert payload["summary"]["x12_row_count"] == 2
    assert payload["summary"]["x12_unkeyable_row_count"] == 1
    assert payload["summary"].get("advisory_code", "") == ""
    assert source["x12_rows_resolution"] == "existing_unkeyable_rows_plus_local_837p_resolution"
    assert source["x12_existing_report_rows_with_local_key"] == 0
    assert source["local_837p_rows_emitted"] == 1
    assert payload["anchors"][0]["patient_id"] == "67890"


def test_local_837p_resolution_reports_unmatched_and_missing_patid(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"
    claims = tmp_path / "claims"
    claims.mkdir()
    matched_missing_patid = claims / "claim_missing_patid.837p"
    unmatched = claims / "claim_unmatched.837p"
    _write_saved_837p(matched_missing_patid, claim_number="NOPATID20260120", charge="580", minutes="42")
    _write_saved_837p(unmatched, claim_number="NOMATCH20260120", charge="540", minutes="18")
    _write_submission_index(claims, [{
        "record_type": "submission",
        "receipt_file": matched_missing_patid.name,
        "submitted_claim_number": "NOPATID20260120",
        "internal_chart": "NOPATID",
        "dos": "20260120",
    }, {
        "record_type": "submission",
        "receipt_file": "different_claim.837p",
        "submitted_claim_number": "OTHER20260120",
        "internal_patid": "11111",
        "internal_chart": "OTHER",
        "dos": "20260120",
    }])

    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])

    payload, _paths = mod.run(
        config={"MediLink_Config": {
            "local_storage_path": str(storage),
            "local_claims_path": str(claims),
        }},
        write_index=True,
        run_id="local-resolution-reject-run",
    )

    source = payload["summary"]["source_summary"]
    assert payload["summary"]["anchor_count"] == 0
    assert source["local_837p_resolution_status"] == "no_resolved_rows"
    assert source["local_837p_claims_seen"] == 2
    assert source["local_837p_submission_index_matches"] == 1
    assert source["local_837p_missing_internal_patid"] == 1
    assert source["local_837p_unmatched_claim_number"] == 1


def test_run_direct_scans_saved_837p_when_row_report_is_absent(monkeypatch, tmp_path):
    mod = _load_module()
    storage = tmp_path / "storage"
    lab = tmp_path / "lab"
    claims = tmp_path / "claims"
    outbox = tmp_path / "outbox"
    claims.mkdir()
    outbox.mkdir()
    captured = {}

    class FakeMinutesChargeModule(object):
        @staticmethod
        def run_analysis(scan_roots, lab_dir):
            captured["scan_roots"] = list(scan_roots)
            captured["lab_dir"] = lab_dir
            return {
                "run_id": "scan-run",
            }, [{
                "patient_id": "12345",
                "service_date": "20260120",
                "line_charge_amount": "540.00",
                "anesthesia_minutes": "18",
            }], {
                "rows_jsonl": os.path.join(lab_dir, "reports", "x12_minutes_charge_rows_scan-run.jsonl"),
            }

    monkeypatch.setenv("MEDICAFE_LAB_DIR", str(lab))
    monkeypatch.setattr(mod, "_candidate_x12_lab_roots", lambda config: [str(lab)])
    monkeypatch.setattr(mod, "discover_dat_files", lambda config: [])
    monkeypatch.setattr(mod, "load_dat_records", lambda dat_paths, config: [])
    monkeypatch.setattr(mod, "_load_x12_minutes_charge_module", lambda: FakeMinutesChargeModule)

    payload, _paths = mod.run(
        config={"MediLink_Config": {
            "local_storage_path": str(storage),
            "local_claims_path": str(claims),
            "outputFilePath": str(outbox),
        }},
        write_index=True,
        run_id="direct-scan-run",
    )

    summary = payload["summary"]["source_summary"]
    assert captured["scan_roots"] == [str(claims), str(outbox)]
    assert captured["lab_dir"] == str(lab)
    assert payload["summary"]["x12_row_count"] == 1
    assert payload["summary"]["anchor_count"] == 1
    assert summary["x12_rows_resolution"] == "direct_saved_837p_scan"
    assert summary["x12_direct_scan_status"] == "succeeded"
    assert summary["x12_direct_scan_run_id"] == "scan-run"
    assert payload["anchors"][0]["charge_amount"] == "540.00"
