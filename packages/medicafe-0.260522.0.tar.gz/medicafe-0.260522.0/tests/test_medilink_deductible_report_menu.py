from __future__ import print_function

import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class MediLinkDeductibleReportMenuTests(unittest.TestCase):

    def test_open_deductible_report_txt_is_quiet_on_success(self):
        from MediLink import MediLink_main as medilink_main

        temp_root = tempfile.mkdtemp(prefix='mc_deductible_report_menu_')
        report_path = os.path.join(temp_root, 'deductible_report.txt')
        try:
            with open(report_path, 'w') as handle:
                handle.write('ok\n')

            with patch.object(medilink_main, '_safe_log') as log_mock:
                with patch.object(medilink_main.MediLink_UI, 'prompt_press_enter_to_continue'):
                    with patch('builtins.print') as print_mock:
                        with patch('MediLink.MediLink_Deductible_v1_5.get_deductible_report_path', return_value=report_path):
                            with patch('MediLink.MediLink_Deductible_v1_5.run_menu_deductible_report', return_value=True) as run_mock:
                                with patch.object(os, 'startfile', create=True) as startfile_mock:
                                    rc = medilink_main._open_deductible_report_txt({'MediLink_Config': {}})

            self.assertEqual(rc, 0)
            run_mock.assert_called_once_with({'MediLink_Config': {}}, silent=False)
            startfile_mock.assert_called_once_with(report_path)
            print_mock.assert_not_called()
            log_mock.assert_any_call('Deductible report menu: refreshing operator report', level='INFO')
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
