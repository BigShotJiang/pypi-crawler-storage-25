# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediBot import MediBot_Preprocessor_lib as preprocessor_lib


class MedibotPreprocessorConsoleTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _write_csv(self, name):
        path = os.path.join(self.tmp, name)
        with open(path, 'w') as handle:
            handle.write('Surgery Date,Patient ID\n05/12/2026,12345\n')
        return path

    def test_load_csv_data_suppresses_encoding_console_chatter_in_perf_only_session(self):
        csv_path = self._write_csv('perf_only.csv')
        console_messages = []
        logs = []

        def capture_log(message, config=None, level="INFO", error_type=None, claim=None, verbose=False, console_output=False):
            logs.append((level, message))

        with patch.object(preprocessor_lib, 'DEBUG', False):
            with patch.object(preprocessor_lib, 'CONSOLE_LOGGING', False):
                with patch.object(preprocessor_lib, 'PERFORMANCE_LOGGING', True):
                    with patch.dict(os.environ, {}, clear=True):
                        with patch.object(preprocessor_lib, 'emit_info', side_effect=lambda message, verbose_only=False: console_messages.append((message, verbose_only))):
                            with patch.object(preprocessor_lib.MediLink_ConfigLoader, 'log', capture_log):
                                rows = preprocessor_lib.load_csv_data(csv_path)

        self.assertEqual(len(rows), 1)
        self.assertEqual(console_messages, [])
        self.assertTrue(any(
            level == 'DEBUG' and 'CSV encoding detected: encoding=' in message and 'source=load_csv_data' in message
            for level, message in logs
        ))
        self.assertTrue(any(
            level == 'INFO' and 'CSV load telemetry:' in message
            for level, message in logs
        ))

    def test_load_csv_data_keeps_encoding_console_detail_for_explicit_verbose_session(self):
        csv_path = self._write_csv('verbose.csv')
        console_messages = []

        with patch.object(preprocessor_lib, 'DEBUG', False):
            with patch.object(preprocessor_lib, 'CONSOLE_LOGGING', False):
                with patch.object(preprocessor_lib, 'PERFORMANCE_LOGGING', True):
                    with patch.dict(os.environ, {'MEDICAFE_VERBOSE_LOGGING': '1'}, clear=True):
                        with patch.object(preprocessor_lib, 'emit_info', side_effect=lambda message, verbose_only=False: console_messages.append((message, verbose_only))):
                            preprocessor_lib.load_csv_data(csv_path)

        self.assertEqual(len(console_messages), 1)
        self.assertIn('Detected encoding:', console_messages[0][0])
        self.assertTrue(console_messages[0][1])


if __name__ == '__main__':
    unittest.main()
