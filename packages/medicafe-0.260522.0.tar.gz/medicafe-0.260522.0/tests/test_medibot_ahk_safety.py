import importlib.util
import os
import sys

import pytest


_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_medibot_module():
    medibot_dir = os.path.join(_PROJECT_ROOT, "MediBot")
    if medibot_dir not in sys.path:
        sys.path.insert(0, medibot_dir)
    module_path = os.path.join(medibot_dir, "MediBot.py")
    spec = importlib.util.spec_from_file_location("medibot_ahk_safety_test", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class _FakeLoader(object):
    def __init__(self):
        self.messages = []

    def log(self, message, level='INFO', *args, **kwargs):
        self.messages.append((level, message))


class _FakeProcess(object):
    def __init__(self, returncode):
        self.returncode = returncode

    def communicate(self, input=None):
        return b'', b''

    def terminate(self):
        return None

    def kill(self):
        return None


def test_assert_medisoft_foreground_blocks_non_medisoft_window(monkeypatch):
    medibot = _load_medibot_module()
    loader = _FakeLoader()
    monkeypatch.setattr(medibot, 'MediLink_ConfigLoader', loader)
    monkeypatch.setattr(medibot, '_get_foreground_window_context', lambda: {
        'title': 'MediCafe Review Console',
        'process_name': 'python.exe',
        'pid': 4321,
        'hwnd': 77,
        'probe_error': None,
    })

    with pytest.raises(medibot.AHKSafetyStop) as excinfo:
        medibot._assert_medisoft_foreground('Last Name')

    message = str(excinfo.value)
    assert 'foreground_mismatch' in message
    assert 'Last Name' in message
    assert 'Reconcile the current Medisoft screen before retrying automation.' in message
    assert any(level == 'ERROR' and 'foreground_title=' in logged for level, logged in loader.messages)


def test_run_ahk_script_via_stdin_times_out_and_stops(monkeypatch):
    medibot = _load_medibot_module()
    loader = _FakeLoader()
    monkeypatch.setattr(medibot, 'MediLink_ConfigLoader', loader)
    monkeypatch.setattr(medibot.MediBot_Preprocessor_lib, 'AHK_EXECUTABLE', 'AutoHotkey.exe', raising=False)
    monkeypatch.setattr(medibot.subprocess, 'Popen', lambda *args, **kwargs: _FakeProcess(returncode=None))
    monkeypatch.setattr(
        medibot,
        '_bounded_communicate',
        lambda process, timeout_sec, input_bytes=None: (b'', b'', True, None)
    )

    with pytest.raises(medibot.AHKSafetyStop) as excinfo:
        medibot._run_ahk_script_via_stdin('Send, abc', 'OK', 'First Name', 1.5)

    message = str(excinfo.value)
    assert 'reason=timeout' in message
    assert 'method=stdin' in message
    assert 'First Name' in message
    assert any(level == 'ERROR' and 'reason=timeout' in logged for level, logged in loader.messages)


def test_run_ahk_script_via_stdin_requires_handshake_token(monkeypatch):
    medibot = _load_medibot_module()
    loader = _FakeLoader()
    monkeypatch.setattr(medibot, 'MediLink_ConfigLoader', loader)
    monkeypatch.setattr(medibot.MediBot_Preprocessor_lib, 'AHK_EXECUTABLE', 'AutoHotkey.exe', raising=False)
    monkeypatch.setattr(medibot.subprocess, 'Popen', lambda *args, **kwargs: _FakeProcess(returncode=0))
    monkeypatch.setattr(
        medibot,
        '_bounded_communicate',
        lambda process, timeout_sec, input_bytes=None: (b'not-done', b'', False, None)
    )

    with pytest.raises(medibot.AHKSafetyStop) as excinfo:
        medibot._run_ahk_script_via_stdin('Send, abc', 'OK', 'Zip', 2.0)

    message = str(excinfo.value)
    assert 'reason=missing_handshake_token' in message
    assert 'method=stdin' in message
    assert 'Zip' in message
    assert any(level == 'ERROR' and 'missing_handshake_token' in logged for level, logged in loader.messages)
