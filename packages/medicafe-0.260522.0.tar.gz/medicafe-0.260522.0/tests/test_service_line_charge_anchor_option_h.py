import builtins
import imp
import json
import os

from MediCafe import __main__ as medicafe_main
from MediCafe import error_reporter
from MediCafe import launcher


def _read_status(storage):
    path = storage / "reports" / "service_line_charge_anchor_option_h_status_latest.json"
    assert path.exists()
    return json.loads(path.read_text(encoding="utf-8"))


def _normalized_abs(path_value):
    return os.path.normcase(os.path.abspath(str(path_value)))


def _assert_path_under_root(path_value, root_value):
    assert os.path.commonpath([
        _normalized_abs(path_value),
        _normalized_abs(root_value),
    ]) == _normalized_abs(root_value)


def test_option_h_writes_success_status_artifact(monkeypatch, tmp_path):
    monkeypatch.setattr(
        medicafe_main,
        "_service_line_anchor_load_config_for_status",
        lambda: (
            {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
            {"status": "ok", "path_source": "test"},
        ),
    )

    rc = medicafe_main.run_service_line_charge_anchor_index()

    assert rc == 0
    status = _read_status(tmp_path)
    assert status["schema_version"] == "service_line_charge_anchor_option_h_status.v1"
    assert status["status"] == "succeeded"
    assert status["returncode"] == 0
    assert status["workflow_boundary"] == "report_only_review_required"
    assert status["claims_completion"] is False
    assert status["mutates_dat"] is False
    assert status["mutates_837p"] is False
    assert status["charges_entered"] is False
    assert status["helper_load_method"] == "package_import"
    assert status["summary"]["anchor_count"] == 0
    assert status["summary"]["advisory_code"]
    assert status["advisory_code"] == status["summary"]["advisory_code"]
    artifact_paths = status["artifact_paths"]
    assert artifact_paths["summary_json"]
    assert artifact_paths["state_path"]
    _assert_path_under_root(artifact_paths["summary_json"], tmp_path)
    _assert_path_under_root(artifact_paths["state_path"], tmp_path)

    with open(artifact_paths["summary_json"], "r", encoding="utf-8") as handle:
        helper_payload = json.loads(handle.read())
    helper_summary = helper_payload["summary"]
    assert status["summary"] == helper_summary
    assert _normalized_abs(helper_summary["source_summary"]["configured_local_storage_path"]) == _normalized_abs(tmp_path)
    assert _normalized_abs(helper_summary["source_summary"]["output_local_storage_path"]) == _normalized_abs(tmp_path)

    status_artifact_path = tmp_path / "reports" / "service_line_charge_anchor_option_h_status_latest.json"
    _assert_path_under_root(status_artifact_path, tmp_path)


def test_option_h_send_report_submits_dedicated_bundle(monkeypatch, tmp_path):
    calls = {}

    monkeypatch.setattr(
        medicafe_main,
        "_service_line_anchor_load_config_for_status",
        lambda: (
            {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
            {"status": "ok", "path_source": "test"},
        ),
    )

    def fake_collect_support_bundle(**kwargs):
        calls["collect_kwargs"] = kwargs
        bundle = tmp_path / "option_h_bundle.zip"
        bundle.write_text("bundle", encoding="utf-8")
        return str(bundle)

    def fake_submit_support_bundle_email(**kwargs):
        calls["submit_kwargs"] = kwargs
        return True

    monkeypatch.setattr(error_reporter, "collect_support_bundle", fake_collect_support_bundle)
    monkeypatch.setattr(error_reporter, "submit_support_bundle_email", fake_submit_support_bundle_email)

    rc = medicafe_main.run_service_line_charge_anchor_index(send_report=True)

    assert rc == 0
    meta = calls["collect_kwargs"]["extra_meta"]
    assert meta["bundle_kind"] == "service_line_charge_anchor_option_h_report"
    assert meta["workflow_boundary"] == "report_only_review_required"
    assert meta["claims_completion"] is False
    assert meta["mutates_dat"] is False
    assert meta["mutates_837p"] is False
    assert meta["charges_entered"] is False
    names = [name for name, _value in calls["collect_kwargs"]["extra_files"]]
    assert "service_line_charge_anchor_hydration_summary.json" in names
    assert "service_line_charge_anchor_hydration_summary.txt" in names
    assert "service_line_charge_anchor_index.json" not in names
    assert ".service_line_charge_anchor_index.json" not in names
    report_summary = dict(calls["collect_kwargs"]["extra_files"])["service_line_charge_anchor_hydration_summary.json"]
    assert report_summary["schema_version"] == "service_line_charge_anchor_option_h_report.v1"
    assert "anchors" not in report_summary
    index_build = report_summary["index_build"]
    assert index_build["index_build_status"] in ("written_empty", "written_with_anchors")
    assert index_build["index_write_requested"] is True
    assert index_build["index_artifact_present"] is True
    assert index_build["index_artifact_basename"] == ".service_line_charge_anchor_index.json"
    assert index_build["usable_anchor_count"] == report_summary["anchor_count"]
    assert "candidate_source_row_count" in index_build
    assert "anchor_source_counts" in index_build
    assert meta["index_build_status"] == index_build["index_build_status"]
    assert meta["index_artifact_present"] is True
    assert meta["index_usable_anchor_count"] == report_summary["anchor_count"]
    assert ".service_line_charge_anchor_index.json" in report_summary["private_artifacts_excluded"]
    assert calls["submit_kwargs"]["zip_path"].endswith("option_h_bundle.zip")
    assert calls["submit_kwargs"]["skip_interactive_reauth"] is True
    status = _read_status(tmp_path)
    assert status["report_bundle"]["status"] == "sent"


def test_option_h_report_includes_local_837p_resolution_counts_without_raw_claim_identity(monkeypatch, tmp_path):
    calls = {}
    payload = {
        "schema_version": "service_line_charge_anchor_index.v1",
        "workflow_name": "service_line_input",
        "workflow_boundary": "report_only_review_required",
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
        "summary": {
            "schema_version": "service_line_charge_anchor_summary.v1",
            "run_id": "local-resolution-run",
            "workflow_name": "service_line_input",
            "workflow_boundary": "report_only_review_required",
            "claims_completion": False,
            "mutates_billing_state": False,
            "mutates_dat": False,
            "mutates_837p": False,
            "charges_entered": False,
            "anchor_count": 1,
            "dat_record_count": 0,
            "canonical_dat_record_count": 2,
            "raw_dat_anchor_count": 0,
            "canonical_dat_anchor_count": 1,
            "saved_837p_anchor_count": 1,
            "x12_row_count": 1,
            "x12_unkeyable_row_count": 0,
            "rejected_counts": {},
            "source_summary": {
                "x12_rows_resolution": "local_837p_resolution",
                "x12_direct_scan_status": "not_attempted_local_837p_resolution_succeeded",
                "local_837p_resolution_status": "succeeded",
                "local_837p_claims_seen": 1,
                "local_837p_submission_index_matches": 1,
                "local_837p_internal_patid_matches": 1,
                "local_837p_unmatched_claim_number": 0,
                "canonical_dat_read_status": "loaded",
                "canonical_dat_db_present_count": 1,
                "canonical_dat_record_count": 2,
                "configured_local_storage_path": str(tmp_path),
            },
        },
        "anchors": [{
            "anchor_source": "saved_837p",
            "patient_id": "12345",
            "anchor_source_dos": "01-20-2026",
            "charge_amount": "580.00",
            "source_ref": "C:\\claims\\ABC20260120.837p",
        }],
    }
    status = {
        "status": "succeeded",
        "returncode": 0,
        "workflow_boundary": "report_only_review_required",
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
    }
    artifacts = {
        "summary_json": str(tmp_path / "summary.json"),
        "summary_txt": str(tmp_path / "summary.txt"),
        "state_path": str(tmp_path / ".service_line_charge_anchor_index.json"),
    }
    (tmp_path / "summary.txt").write_text("summary\n", encoding="utf-8")

    def fake_collect_support_bundle(**kwargs):
        calls["collect_kwargs"] = kwargs
        bundle = tmp_path / "option_h_bundle.zip"
        bundle.write_text("bundle", encoding="utf-8")
        return str(bundle)

    def fake_submit_support_bundle_email(**kwargs):
        calls["submit_kwargs"] = kwargs
        return True

    monkeypatch.setattr(error_reporter, "collect_support_bundle", fake_collect_support_bundle)
    monkeypatch.setattr(error_reporter, "submit_support_bundle_email", fake_submit_support_bundle_email)

    result = error_reporter.email_service_line_charge_anchor_report_flow(
        status=status,
        payload=payload,
        artifacts=artifacts,
        local_storage_path=str(tmp_path),
    )

    assert result["status"] == "sent"
    report_summary = dict(calls["collect_kwargs"]["extra_files"])["service_line_charge_anchor_hydration_summary.json"]
    source = report_summary["source_summary"]
    assert source["x12_rows_resolution"] == "local_837p_resolution"
    assert source["local_837p_resolution_status"] == "succeeded"
    assert source["local_837p_claims_seen"] == 1
    assert source["local_837p_submission_index_matches"] == 1
    assert source["local_837p_internal_patid_matches"] == 1
    assert report_summary["canonical_dat_record_count"] == 2
    assert report_summary["canonical_dat_anchor_count"] == 1
    assert source["canonical_dat_read_status"] == "loaded"
    assert source["canonical_dat_db_present_count"] == 1
    assert "raw canonical DAT row sources" in report_summary["private_artifacts_excluded"]
    serialized = json.dumps(report_summary, sort_keys=True)
    assert "ABC20260120" not in serialized
    assert "12345" not in serialized
    assert "canonical_json" not in serialized
    assert "provenance_json" not in serialized
    assert "anchors" not in report_summary
    assert report_summary["private_artifacts_excluded"]


def test_main_build_service_line_charge_anchor_index_sends_report(monkeypatch):
    captured = {}
    original_argv = list(medicafe_main.sys.argv)

    def fake_run(send_report=False):
        captured["send_report"] = send_report
        return 0

    monkeypatch.setattr(medicafe_main, "run_service_line_charge_anchor_index", fake_run)
    monkeypatch.setattr(medicafe_main.sys, "argv", ["python", "build_service_line_charge_anchor_index"])
    try:
        rc = medicafe_main.main()
    finally:
        medicafe_main.sys.argv = original_argv

    assert rc == 0
    assert captured["send_report"] is True


def test_main_analyze_csv_excluded_insurance_is_accepted_by_main(monkeypatch):
    captured = {}
    original_argv = list(medicafe_main.sys.argv)

    def fake_run(send_report=False):
        captured["send_report"] = send_report
        return 0

    monkeypatch.setattr(medicafe_main, "run_csv_excluded_insurance_analytics", fake_run)
    monkeypatch.setattr(medicafe_main.sys, "argv", ["python", "analyze_csv_excluded_insurance"])
    try:
        rc = medicafe_main.main()
    finally:
        medicafe_main.sys.argv = original_argv

    assert rc == 0
    assert captured["send_report"] is True


def test_option_h_packaged_fallback_uses_unified_script_resolver_signature(monkeypatch, tmp_path):
    captured = {}
    real_import = builtins.__import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "scripts.unified_model" and "build_service_line_charge_anchor_index" in (fromlist or ()):
            raise ImportError("simulate packaged data-file import path")
        return real_import(name, globals, locals, fromlist, level)

    class FakeAnchorModule(object):
        __file__ = os.path.join(str(tmp_path), "build_service_line_charge_anchor_index.py")

        @staticmethod
        def run(config=None, write_index=False):
            return {
                "summary": {
                    "anchor_count": 0,
                    "dat_record_count": 0,
                    "x12_row_count": 0,
                }
            }, {"summary_json": "summary.json", "state_path": "state.json"}

        @staticmethod
        def format_summary_lines(payload):
            return ["fake summary"]

    def fake_resolve(repo_root, script_name, python_exe=None):
        captured["repo_root"] = repo_root
        captured["script_name"] = script_name
        captured["python_exe"] = python_exe
        return repo_root, FakeAnchorModule.__file__, [{"script_exists": True}]

    monkeypatch.setattr(builtins, "__import__", fake_import)
    monkeypatch.setattr("MediCafe.shadow_orchestrator.resolve_unified_model_script", fake_resolve)
    monkeypatch.setattr(imp, "load_source", lambda name, path: FakeAnchorModule)
    monkeypatch.setattr(
        medicafe_main,
        "_service_line_anchor_load_config_for_status",
        lambda: (
            {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
            {"status": "ok", "path_source": "test"},
        ),
    )

    rc = medicafe_main.run_service_line_charge_anchor_index()

    assert rc == 0
    assert captured["script_name"] == "build_service_line_charge_anchor_index.py"
    assert captured["repo_root"].endswith("MediCafe")
    assert captured["python_exe"]
    status = _read_status(tmp_path)
    assert status["helper_load_method"] == "imp_load_source"
    assert status["helper_path"] == FakeAnchorModule.__file__
    assert status["status"] == "succeeded"


def test_option_h_status_records_helper_load_failure(monkeypatch, tmp_path):
    real_import = builtins.__import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "scripts.unified_model" and "build_service_line_charge_anchor_index" in (fromlist or ()):
            raise ImportError("simulate package import failure")
        return real_import(name, globals, locals, fromlist, level)

    def fake_resolve(repo_root, script_name, python_exe=None):
        raise RuntimeError("resolver failed")

    monkeypatch.setattr(builtins, "__import__", fake_import)
    monkeypatch.setattr("MediCafe.shadow_orchestrator.resolve_unified_model_script", fake_resolve)
    monkeypatch.setattr(
        medicafe_main,
        "_service_line_anchor_load_config_for_status",
        lambda: (
            {"MediLink_Config": {"local_storage_path": str(tmp_path)}},
            {"status": "ok", "path_source": "test"},
        ),
    )

    rc = medicafe_main.run_service_line_charge_anchor_index()

    assert rc == 1
    status = _read_status(tmp_path)
    assert status["status"] == "failed"
    assert status["failure_stage"] == "helper_load"
    assert status["returncode"] == 1
    assert status["error"]["exception_class"] == "RuntimeError"
    assert "resolver failed" in status["error"]["exception_message"]


def test_option_h_status_artifacts_attach_to_support_bundle_inputs(tmp_path):
    reports = tmp_path / "reports"
    reports.mkdir()
    json_path = reports / "service_line_charge_anchor_option_h_status_latest.json"
    txt_path = reports / "service_line_charge_anchor_option_h_status_latest.txt"
    json_path.write_text('{"status":"failed"}\n', encoding="utf-8")
    txt_path.write_text("status=failed\n", encoding="utf-8")
    launcher_json = reports / "service_line_charge_anchor_option_h_launcher_status_latest.json"
    launcher_txt = reports / "service_line_charge_anchor_option_h_launcher_status_latest.txt"
    launcher_json.write_text('{"status":"failed"}\n', encoding="utf-8")
    launcher_txt.write_text("status=failed\n", encoding="utf-8")

    extra_files = error_reporter._with_service_line_anchor_status_attachment([], str(tmp_path))
    names = [name for name, _path in extra_files]

    assert "service_line_charge_anchor_option_h_status_latest.json" in names
    assert "service_line_charge_anchor_option_h_status_latest.txt" in names
    assert "service_line_charge_anchor_option_h_launcher_status_latest.json" in names
    assert "service_line_charge_anchor_option_h_launcher_status_latest.txt" in names


def test_option_h_support_bundle_marks_stale_launcher_status_non_authoritative(tmp_path):
    reports = tmp_path / "reports"
    reports.mkdir()
    action_json = reports / "service_line_charge_anchor_option_h_status_latest.json"
    action_txt = reports / "service_line_charge_anchor_option_h_status_latest.txt"
    launcher_json = reports / "service_line_charge_anchor_option_h_launcher_status_latest.json"
    launcher_txt = reports / "service_line_charge_anchor_option_h_launcher_status_latest.txt"
    action_json.write_text(json.dumps({
        "schema_version": "service_line_charge_anchor_option_h_status.v1",
        "status": "succeeded",
        "returncode": 0,
        "updated_at_utc": "2026-05-19T10:00:00Z",
        "workflow_name": "service_line_input",
        "workflow_boundary": "report_only_review_required",
        "claims_completion": False,
        "summary": {
            "run_id": "current-run",
            "anchor_count": 12,
        },
    }), encoding="utf-8")
    action_txt.write_text("status=succeeded\nanchor_count=12\n", encoding="utf-8")
    launcher_json.write_text(json.dumps({
        "schema_version": "service_line_charge_anchor_option_h_launcher_status.v1",
        "status": "failed",
        "returncode": 1,
        "failure_stage": "subprocess_returned_nonzero",
        "written_at_utc": "2026-05-19T09:00:00Z",
        "workflow_name": "service_line_input",
        "workflow_boundary": "report_only_review_required",
        "claims_completion": False,
        "stdout_tail": "anchor_count=17\n",
        "stderr_tail": "old stderr anchor_count=17\n",
    }), encoding="utf-8")
    launcher_txt.write_text("status=failed\nanchor_count=17\n", encoding="utf-8")

    extra_files = error_reporter._with_service_line_anchor_status_attachment([], str(tmp_path))
    attachments = dict(extra_files)

    stale_json = attachments["service_line_charge_anchor_option_h_launcher_status_latest.json"]
    stale_txt = attachments["service_line_charge_anchor_option_h_launcher_status_latest.txt"]
    assert isinstance(stale_json, dict)
    assert stale_json["attachment_authority"] == "non_authoritative_launcher_telemetry"
    assert stale_json["stale_launcher_status"] is True
    assert stale_json["stale_reason_code"] == "launcher_status_older_than_authoritative_option_h_status"
    assert stale_json["authoritative_status_status"] == "succeeded"
    assert stale_json["authoritative_status_run_id"] == "current-run"
    assert stale_json["authoritative_status_anchor_count"] == 12
    assert stale_json["workflow_boundary"] == "report_only_review_required"
    assert stale_json["claims_completion"] is False
    assert stale_json["stale_launcher_stream_tails_suppressed"] is True
    assert "stdout_tail" not in stale_json
    assert "stderr_tail" not in stale_json
    assert sorted(stale_json["suppressed_stale_launcher_fields"]) == ["stderr_tail", "stdout_tail"]
    assert "17" not in json.dumps(stale_json, sort_keys=True)
    assert "attachment_authority=non_authoritative_launcher_telemetry" in stale_txt
    assert "authoritative_status_anchor_count=12" in stale_txt
    assert "stale_launcher_stream_tails_suppressed=True" in stale_txt
    assert "anchor_count=17" not in stale_txt


def test_option_h_support_bundle_keeps_current_launcher_status_authoritative(tmp_path):
    reports = tmp_path / "reports"
    reports.mkdir()
    action_json = reports / "service_line_charge_anchor_option_h_status_latest.json"
    launcher_json = reports / "service_line_charge_anchor_option_h_launcher_status_latest.json"
    launcher_txt = reports / "service_line_charge_anchor_option_h_launcher_status_latest.txt"
    action_json.write_text(json.dumps({
        "status": "succeeded",
        "returncode": 0,
        "updated_at_utc": "2026-05-19T10:00:00Z",
        "summary": {"run_id": "current-run", "anchor_count": 12},
    }), encoding="utf-8")
    launcher_json.write_text(json.dumps({
        "status": "succeeded",
        "returncode": 0,
        "written_at_utc": "2026-05-19T10:00:05Z",
        "workflow_name": "service_line_input",
        "workflow_boundary": "report_only_review_required",
    }), encoding="utf-8")
    launcher_txt.write_text("status=succeeded\n", encoding="utf-8")

    extra_files = error_reporter._with_service_line_anchor_status_attachment([], str(tmp_path))
    attachments = dict(extra_files)

    assert attachments["service_line_charge_anchor_option_h_launcher_status_latest.json"] == str(launcher_json)
    assert attachments["service_line_charge_anchor_option_h_launcher_status_latest.txt"] == str(launcher_txt)


def test_option_h_status_artifacts_attach_from_fallback_storage(monkeypatch, tmp_path):
    primary = tmp_path / "primary"
    fallback = tmp_path / "fallback"
    reports = fallback / "reports"
    reports.mkdir(parents=True)
    json_path = reports / "service_line_charge_anchor_option_h_status_latest.json"
    txt_path = reports / "service_line_charge_anchor_option_h_status_latest.txt"
    json_path.write_text('{"status":"succeeded"}\n', encoding="utf-8")
    txt_path.write_text("status=succeeded\n", encoding="utf-8")
    monkeypatch.setenv("MEDICAFE_SERVICE_LINE_ANCHOR_FALLBACK_DIR", str(fallback))

    extra_files = error_reporter._with_service_line_anchor_status_attachment([], str(primary))
    names = [name for name, _path in extra_files]

    assert "service_line_charge_anchor_option_h_status_latest.json" in names
    assert "service_line_charge_anchor_option_h_status_latest.txt" in names


def test_option_h_failure_auto_submits_support_bundle(monkeypatch, tmp_path):
    calls = {}
    orch = launcher.MediCafeOrchestrator.__new__(launcher.MediCafeOrchestrator)
    orch.environment = {"local_storage_path": str(tmp_path)}
    orch.repo_root = str(tmp_path)
    orch._last_command_exit_context = {
        "command": "build_service_line_charge_anchor_index",
        "stderr_tail": "helper failed",
        "stdout_tail": "",
    }
    notices = []
    orch._record_notice = lambda level, message, **kwargs: notices.append((level, message))

    def fake_collect_support_bundle(**kwargs):
        calls["collect_kwargs"] = kwargs
        bundle = tmp_path / "bundle.zip"
        bundle.write_text("bundle", encoding="utf-8")
        return str(bundle)

    def fake_submit_support_bundle_email(**kwargs):
        calls["submit_kwargs"] = kwargs
        return True

    monkeypatch.setattr(launcher, "collect_support_bundle", fake_collect_support_bundle)
    monkeypatch.setattr(launcher, "submit_support_bundle_email", fake_submit_support_bundle_email)

    assert orch._auto_submit_service_line_anchor_failure_bundle(1) is True

    meta = calls["collect_kwargs"]["extra_meta"]
    assert calls["collect_kwargs"]["include_traceback"] is False
    assert meta["bundle_kind"] == "service_line_charge_anchor_option_h_failure"
    assert meta["workflow_boundary"] == "report_only_review_required"
    assert meta["claims_completion"] is False
    assert meta["mutates_dat"] is False
    assert meta["mutates_837p"] is False
    assert meta["charges_entered"] is False
    assert calls["submit_kwargs"]["zip_path"].endswith("bundle.zip")
    assert calls["submit_kwargs"]["skip_interactive_reauth"] is True
    assert any("submitted" in message for _level, message in notices)
