#!/usr/bin/env python
from __future__ import print_function

import os
import sys
import tempfile
import time
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from workflow_boundary_contract import assert_workflow_boundary_clean


def _wait_worker_quiet(manager, rounds=500, delay_sec=0.02):
    for _ in range(int(max(1, rounds))):
        thread = getattr(manager, '_worker_thread', None)
        if thread is None or not thread.is_alive():
            return
        time.sleep(delay_sec)


class TestSupportSendQueuePolicy(unittest.TestCase):

    def test_dedup_key_includes_anchor_context_and_issue(self):
        from MediCafe.support_send_jobs import SupportSendQueuePolicy
        policy = SupportSendQueuePolicy(dedup_ttl_sec=60)
        key = policy.dedup_key({
            'send_type': 'run_evidence',
            'anchor_run_id': 'a1',
            'context_run_id': 'c1',
            'issue_code': 'x1',
            'source_scope_hash': 'h1',
        })
        self.assertEqual(key, 'run_evidence|a1|c1|x1|h1')


class TestSupportSendJobManager(unittest.TestCase):

    def test_enqueue_accepts_even_if_legacy_async_env_is_off(self):
        """MEDICAFE_SUPPORT_SEND_ASYNC is obsolete; queue is always used for supported types."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_ASYNC': '0',
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-legacy',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                self.assertNotEqual(str(res.get('policy_decision', '')), 'sync_fallback')
                _wait_worker_quiet(mgr)

    def test_background_job_logger_receives_progress_heartbeat(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        events = []

        def logger(event_name, details=None):
            events.append((event_name, dict(details or {})))

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root, logger_fn=logger)

                def _execute(_job, progress_callback):
                    progress_callback('creating zip bundle')
                    return True, 'sent', {}

                mgr._execute_send = _execute
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-heartbeat|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                _wait_worker_quiet(mgr)

        names = [name for name, _details in events]
        self.assertIn('job_accepted', names)
        self.assertIn('job_started', names)
        self.assertIn('job_progress', names)
        self.assertIn('job_finished', names)
        progress = [details for name, details in events if name == 'job_progress'][0]
        self.assertEqual(progress.get('progress_stage'), 'creating zip bundle')
        self.assertEqual(progress.get('installed_version'), '1.1.0')
        self.assertEqual(progress.get('recommendation_action_kind'), 'send_bundle')
        self.assertTrue(progress.get('heartbeat_at_utc'))
        self.assertTrue(isinstance(progress.get('progress_events'), list))
        self.assertGreaterEqual(len(progress.get('progress_events')), 2)
        self.assertIn('queue_wait_sec', progress)
        self.assertIn('delta_since_prior_stage_sec', progress.get('progress_events')[-1])

    def test_enqueue_records_post_update_autofollow_tags(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-post-update|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                job = mgr._read_job(str(res.get('job_id', '') or ''))
                self.assertEqual(job.get('source'), 'post_update_cloud_autofollow')
                self.assertEqual(job.get('installed_version'), '1.1.0')
                self.assertEqual(job.get('recommendation_action_kind'), 'send_bundle')
                _wait_worker_quiet(mgr)

    def test_preempt_jobs_for_update_cancels_queued_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr._ensure_dirs()
            mgr._write_job({
                'job_id': 'ssj-queued',
                'status': 'queued',
                'source': 'post_update_cloud_autofollow',
                'created_at_utc': '2026-04-11T01:00:00Z',
            })
            mgr._write_queue_state(['ssj-queued'])
            res = mgr.preempt_jobs_for_update(job_ids=['ssj-queued'], request_id='req-update')
            job = mgr._read_job('ssj-queued')
        self.assertTrue(res.get('ok'))
        self.assertEqual(job.get('status'), 'canceled')
        self.assertEqual(job.get('policy_reason'), 'update_preempt')
        self.assertTrue(job.get('suppress_restart_recovery'))
        self.assertEqual(job.get('shutdown_request_id'), 'req-update')

    def test_preempt_jobs_for_update_force_stops_detached_running_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr._ensure_dirs()
            mgr._write_job({
                'job_id': 'ssj-running',
                'status': 'running',
                'source': 'post_update_cloud_autofollow',
                'worker_pid': '424242',
                'worker_mode': 'detached_worker',
                'created_at_utc': '2026-04-11T01:00:00Z',
                'started_at_utc': '2026-04-11T01:00:01Z',
                'heartbeat_at_utc': '2026-04-11T01:00:02Z',
            })
            with patch('MediCafe.cloud_work_shutdown.terminate_process', return_value={
                'attempted': True,
                'ok': True,
                'method': 'taskkill',
                'pid': '424242',
                'return_code': '0',
                'message': 'terminated',
            }) as term_mock:
                res = mgr.preempt_jobs_for_update(job_ids=['ssj-running'], request_id='req-update')
            job = mgr._read_job('ssj-running')
        term_mock.assert_called_once_with('424242', reason='operator_update_priority')
        self.assertTrue(res.get('ok'))
        self.assertEqual(res.get('force_stopped_count'), 1)
        self.assertEqual(job.get('status'), 'failed')
        self.assertEqual(job.get('policy_reason'), 'update_preempted_force_stopped')
        self.assertTrue(job.get('suppress_restart_recovery'))
        self.assertEqual(job.get('worker_pid'), '')
        self.assertEqual(job.get('shutdown_request_id'), 'req-update')
        self.assertEqual((job.get('update_preempt_termination') or {}).get('message'), 'terminated')

    def test_preempt_jobs_for_update_refuses_self_or_failed_termination_without_terminalizing(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr._ensure_dirs()
            mgr._write_job({
                'job_id': 'ssj-self',
                'status': 'running',
                'source': 'post_update_cloud_autofollow',
                'worker_pid': str(os.getpid()),
                'worker_mode': 'detached_worker',
                'created_at_utc': '2026-04-11T01:00:00Z',
                'started_at_utc': '2026-04-11T01:00:01Z',
            })
            with patch('MediCafe.cloud_work_shutdown.terminate_process', return_value={
                'attempted': False,
                'ok': False,
                'method': '',
                'pid': str(os.getpid()),
                'return_code': '',
                'message': 'refused_current_process',
            }):
                res = mgr.preempt_jobs_for_update(job_ids=['ssj-self'], request_id='req-update')
            job = mgr._read_job('ssj-self')
        self.assertFalse(res.get('ok'))
        self.assertEqual(job.get('status'), 'running')
        self.assertEqual(job.get('policy_reason'), 'update_preempt_termination_failed')
        self.assertTrue(job.get('suppress_restart_recovery'))
        self.assertEqual((job.get('update_preempt_termination') or {}).get('message'), 'refused_current_process')

    def test_queue_wait_sec_falls_back_to_created_at_utc_without_created_epoch(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'anchor_run_id': 'run-wait-fallback',
                    'layer1_current_blocker': 'b1',
                    'source_scope_hash': 'scope-wait-fallback',
                }
                job = mgr._build_job_record(req, 'queued', 'queued_jobs_pending')
                try:
                    del job['created_epoch']
                except Exception:
                    job['created_epoch'] = 0.0
                job['created_at_utc'] = time.strftime(
                    '%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - 150))
                mgr._write_job(job)
                mgr._write_queue_state([job['job_id']])
                mgr._execute_send = lambda _j, _cb: (True, 'ok', {})
                mgr._run_single_job(dict(job))
                persisted = mgr._read_job(job['job_id'])
                self.assertGreaterEqual(float(persisted.get('queue_wait_sec') or 0), 60.0)

    def test_progress_events_bounded_to_forty(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)

                def _execute(_job, progress_callback):
                    for i in range(45):
                        progress_callback('stage_{0}'.format(i))
                    return True, 'ok', {}

                mgr._execute_send = _execute
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'anchor_run_id': 'run-bounds',
                    'layer1_current_blocker': 'b1',
                    'source_scope_hash': 'scope-bounds',
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                _wait_worker_quiet(mgr)
                jid = str(res.get('job_id') or '')
                persisted = mgr._read_job(jid)
                events = persisted.get('progress_events')
                self.assertTrue(isinstance(events, list))
                self.assertLessEqual(len(events), 40)
                self.assertEqual(events[-1].get('stage'), 'stage_44')

    def test_job_log_payload_includes_timing_and_progress_fields(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)

                def _execute(_job, progress_callback):
                    progress_callback('mid')
                    return True, 'ok', {}

                mgr._execute_send = _execute
                res = mgr.enqueue({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'anchor_run_id': 'run-payload',
                    'layer1_current_blocker': 'b1',
                    'source_scope_hash': 'scope-payload',
                })
                self.assertTrue(res.get('accepted'))
                _wait_worker_quiet(mgr)
                persisted = mgr._read_job(str(res.get('job_id') or ''))
                snap = mgr._job_log_payload(persisted)
                for key in (
                        'created_at_utc',
                        'started_at_utc',
                        'finished_at_utc',
                        'queue_wait_sec',
                        'progress_events'):
                    self.assertIn(key, snap)
                self.assertTrue(isinstance(snap.get('progress_events'), list))
                self.assertGreaterEqual(len(snap.get('progress_events')), 2)

    def test_enqueue_persists_evidence_manifest_enqueue_snapshot(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                snap = {
                    'schema_version': 1,
                    'request': {'bundle_kind': 'run_evidence_bundle'},
                    'scope': {},
                    'validation': {'attachment_contract_status': 'pass'},
                    'missing_required_evidence': [],
                    'operator_contract': {},
                    'attachments_summary': [{'archive_name': 'x.json', 'has_inline_content': False}],
                }
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-manifest',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                    'evidence_manifest_enqueue': snap,
                }
                res = mgr.enqueue(req)
                self.assertTrue(res.get('accepted'))
                job = mgr._read_job(str(res.get('job_id', '') or ''))
                self.assertEqual(job.get('evidence_manifest_enqueue'), snap)
                _wait_worker_quiet(mgr)

    def test_recover_requeues_running_post_update_job_after_launcher_restart(self):
        import json
        from MediCafe.support_send_jobs import SupportSendJobManager, _utc_now
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                req = {
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-recover|version=1.1.0|action=send_bundle',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                job = mgr._build_job_record(req, 'started', 'started_immediately')
                job['status'] = 'running'
                job['progress_stage'] = 'sending email to support'
                job['heartbeat_at_utc'] = _utc_now()
                job['worker_pid'] = '999999'
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': job.get('job_id')}, handle)
                with patch.object(mgr, '_ensure_worker_locked') as ensure_worker:
                    result = mgr.recover_jobs_after_launcher_restart(
                        source='post_update_cloud_autofollow',
                        installed_version='1.1.0')
                recovered = result.get('recovered_job_ids', [])
                self.assertIn(job.get('job_id'), recovered)
                recovered_job = mgr._read_job(job.get('job_id'))
                self.assertEqual(recovered_job.get('status'), 'queued')
                self.assertEqual(recovered_job.get('policy_reason'), 'running_job_recovered_after_launcher_restart')
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))
                queue_state = mgr._read_queue_state()
                self.assertIn(job.get('job_id'), queue_state.get('queued_job_ids', []))
                ensure_worker.assert_called_once_with()

    def test_preflight_reaps_weeks_old_running_job_and_releases_lock(self):
        import json
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-stale',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (14 * 24 * 60 * 60)))
                job['status'] = 'running'
                job['progress_stage'] = 'building anchored context pack'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (14 * 24 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = '999999'
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': job_id}, handle)

                reaped = mgr.preflight_reap_stale_running_jobs()
                reaped_job = mgr._read_job(job_id)

                self.assertEqual(reaped, [job_id])
                self.assertEqual(reaped_job.get('status'), 'failed')
                self.assertIn(str(reaped_job.get('policy_reason')), (
                    'abandoned_running_job_reaped',
                    'abandoned_running_job_reaped_pid_may_be_reused',
                    'abandoned_in_process_job_reaped_current_launcher',
                ))
                self.assertEqual(reaped_job.get('previous_status_before_stale_reap'), 'running')
                self.assertTrue(reaped_job.get('suppress_restart_recovery'))
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))
                self.assertNotIn(job_id, mgr._read_queue_state().get('queued_job_ids', []))
                self.assertEqual(mgr._find_active_job().get('job_id'), None)
                audit = mgr.read_stale_preflight_audit()
                self.assertEqual(audit.get('stale_running_jobs_found'), 1)
                self.assertEqual(audit.get('resolved_count'), 1)
                self.assertTrue(os.path.isfile(mgr.stale_preflight_latest_txt_path))
                self.assertTrue(os.path.isfile(mgr.stale_preflight_latest_path))

    def test_preflight_reaps_stale_dead_pid_without_waiting_for_abandoned_age(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-stale-dead-pid',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (2 * 60 * 60)))
                job['status'] = 'running'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (2 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = ''
                mgr._write_job(job)

                reaped = mgr.preflight_reap_stale_running_jobs()
                reaped_job = mgr._read_job(job_id)

                self.assertEqual(reaped, [job_id])
                self.assertEqual(reaped_job.get('status'), 'failed')
                self.assertEqual(reaped_job.get('policy_reason'), 'stale_running_job_reaped')
                self.assertGreaterEqual(int(reaped_job.get('stale_reap_heartbeat_age_sec') or 0), 3600)

    def test_preflight_terminates_stale_known_detached_worker(self):
        from MediCafe import support_send_jobs as jobs_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-stale-detached',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (2 * 60 * 60)))
                job['status'] = 'running'
                job['worker_mode'] = 'detached_worker'
                job['worker_pid'] = '424242'
                job['worker_command'] = os.path.join(repo, 'scripts', 'support_send_worker.py')
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (2 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                mgr._write_job(job)

                with patch.object(jobs_mod, '_pid_running', return_value=True), \
                        patch.object(mgr, '_terminate_stale_worker_process', return_value={
                            'attempted': True,
                            'ok': True,
                            'method': 'taskkill',
                            'return_code': '0',
                            'message': '',
                        }) as terminate:
                    reaped = mgr.preflight_reap_stale_running_jobs()

                reaped_job = mgr._read_job(job_id)
                self.assertEqual(reaped, [job_id])
                self.assertEqual(reaped_job.get('status'), 'failed')
                self.assertEqual(reaped_job.get('policy_reason'), 'stale_detached_worker_terminated')
                self.assertTrue(reaped_job.get('stale_reap_known_detached_worker'))
                self.assertTrue(reaped_job.get('stale_reap_termination', {}).get('attempted'))
                terminate.assert_called_once_with(424242)

    def test_preflight_keeps_stale_live_unknown_pid_until_abandoned(self):
        from MediCafe import support_send_jobs as jobs_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-live-unknown',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (2 * 60 * 60)))
                job['status'] = 'running'
                job['worker_mode'] = 'unknown_worker'
                job['worker_pid'] = '424243'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (2 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                mgr._write_job(job)

                with patch.object(jobs_mod, '_pid_running', return_value=True):
                    reaped = mgr.preflight_reap_stale_running_jobs()
                    active = mgr._find_active_job()

                self.assertEqual(reaped, [])
                self.assertEqual(active.get('job_id'), job_id)
                self.assertEqual(mgr._read_job(job_id).get('status'), 'running')
                audit = mgr.read_stale_preflight_audit()
                self.assertEqual(audit.get('stale_running_jobs_found'), 1)
                self.assertEqual(audit.get('resolved_count'), 0)
                self.assertEqual(audit.get('unresolved_count'), 1)
                self.assertEqual((audit.get('jobs') or [{}])[0].get('reason'), 'stale_running_job_pid_still_live')

    def test_preflight_does_not_abandon_reap_long_queued_job_recently_started_same_pid(self):
        """Abandonment must use running age (started_at), not enqueue age (created_at)."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        import json
        now = time.time()
        old_created = now - (14 * 24 * 60 * 60)
        recent_start = now - 120
        stale_hb = now - (2 * 60 * 60)
        created_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(old_created))
        started_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(recent_start))
        hb_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(stale_hb))
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': str(24 * 60 * 60),
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-long-queue-recent-start',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                job['status'] = 'running'
                job['created_at_utc'] = created_utc
                job['created_epoch'] = old_created
                job['started_at_utc'] = started_utc
                job['heartbeat_at_utc'] = hb_utc
                job['worker_pid'] = str(os.getpid())
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': job_id}, handle)

                reaped = mgr.preflight_reap_stale_running_jobs()
                still = mgr._read_job(job_id)

                self.assertEqual(reaped, [])
                self.assertEqual(still.get('status'), 'running')
                self.assertTrue(os.path.isfile(mgr.single_flight_lock_path))

    def test_enqueue_after_stale_running_job_starts_new_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                stale = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'source_scope_hash': 'scope-old',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }, 'started', 'started_immediately')
                stale_id = str(stale.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (14 * 24 * 60 * 60)))
                stale['status'] = 'running'
                stale['created_at_utc'] = old_utc
                stale['created_epoch'] = time.time() - (14 * 24 * 60 * 60)
                stale['heartbeat_at_utc'] = old_utc
                stale['worker_pid'] = '999999'
                mgr._write_job(stale)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})

                res = mgr.enqueue({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-new',
                    'context_run_id': 'run-new',
                    'issue_code': 'issue-new',
                    'source_scope_hash': 'scope-new',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                })

                self.assertTrue(res.get('accepted'))
                self.assertEqual(res.get('policy_decision'), 'started')
                self.assertEqual(mgr._read_job(stale_id).get('status'), 'failed')
                _wait_worker_quiet(mgr)

    def test_restart_recovery_does_not_requeue_stale_running_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '3600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-stale-recover',
                    'installed_version': '1.1.0',
                    'recommendation_action_kind': 'send_bundle',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - (14 * 24 * 60 * 60)))
                job['status'] = 'running'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - (14 * 24 * 60 * 60)
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = '999999'
                mgr._write_job(job)

                result = mgr.recover_jobs_after_launcher_restart(
                    source='post_update_cloud_autofollow',
                    installed_version='1.1.0')

                self.assertEqual(result.get('recovered_job_ids', []), [])
                self.assertEqual(mgr._read_job(job_id).get('status'), 'failed')
                self.assertEqual(mgr._read_queue_state().get('queued_job_ids', []), [])

    def test_run_single_job_defers_while_shadow_pipeline_lock_owned(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_DEFER_WHILE_PIPELINE_RUNNING': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-pipeline-active',
                }, 'started', 'started_immediately')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)

                with patch.object(mgr, '_shadow_pipeline_lock_owner', return_value={
                    'pid': str(os.getpid()),
                    'heartbeat_at_utc': '2026-05-03T05:45:29Z',
                    'lock_path': os.path.join(lab_root, 'shadow_pipeline.lock'),
                    'owner_running': True,
                }):
                    mgr._run_single_job(job)

                deferred = mgr._read_job(job_id)
                self.assertEqual(deferred.get('status'), 'queued')
                self.assertEqual(deferred.get('policy_reason'), 'shadow_pipeline_running')
                self.assertEqual(deferred.get('progress_stage'), 'waiting for shadow pipeline')
                self.assertEqual(deferred.get('shadow_pipeline_lock_pid'), str(os.getpid()))
                self.assertIn(job_id, mgr._read_queue_state().get('queued_job_ids', []))
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))

    def test_worker_waits_for_shadow_pipeline_before_running_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEFER_WHILE_PIPELINE_RUNNING': '1',
                'MEDICAFE_SUPPORT_SEND_PIPELINE_WAIT_POLL_SEC': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-pipeline-wait',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                calls = []

                def _execute(_job, progress_callback):
                    calls.append(_job.get('job_id'))
                    progress_callback('sending email to support')
                    return True, 'sent', {}

                owner = {
                    'pid': str(os.getpid()),
                    'heartbeat_at_utc': '2026-05-03T05:45:29Z',
                    'lock_path': os.path.join(lab_root, 'shadow_pipeline.lock'),
                    'owner_running': True,
                }
                mgr._execute_send = _execute
                with patch.object(mgr, '_shadow_pipeline_lock_owner', side_effect=[owner, owner, {}, {}, {}]), \
                        patch('MediCafe.support_send_jobs.time.sleep', return_value=None):
                    mgr._worker_loop()

                self.assertEqual(calls, [job_id])
                self.assertEqual(mgr._read_job(job_id).get('status'), 'succeeded')

    def test_worker_stamps_queued_job_during_predequeue_pipeline_wait(self):
        from MediCafe.support_send_jobs import SupportSendJobManager

        class StopWait(Exception):
            pass

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEFER_WHILE_PIPELINE_RUNNING': '1',
                'MEDICAFE_SUPPORT_SEND_PIPELINE_WAIT_POLL_SEC': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-pipeline-predequeue-wait',
                }, 'queued', 'queued_jobs_pending')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                owner = {
                    'pid': str(os.getpid()),
                    'heartbeat_at_utc': '2026-05-03T05:45:29Z',
                    'lock_path': os.path.join(lab_root, 'shadow_pipeline.lock'),
                    'owner_running': True,
                }
                with patch.object(mgr, '_shadow_pipeline_lock_owner', return_value=owner), \
                        patch('MediCafe.support_send_jobs.time.sleep', side_effect=StopWait):
                    with self.assertRaises(StopWait):
                        mgr._worker_loop()

                deferred = mgr._read_job(job_id)
                self.assertEqual(deferred.get('status'), 'queued')
                self.assertEqual(deferred.get('policy_reason'), 'shadow_pipeline_running')
                self.assertEqual(deferred.get('progress_stage'), 'waiting for shadow pipeline')
                self.assertEqual(deferred.get('shadow_pipeline_lock_pid'), str(os.getpid()))
                self.assertEqual(int(deferred.get('pipeline_defer_count') or 0), 1)
                self.assertTrue(deferred.get('pipeline_defer_started_at_utc'))
                self.assertTrue(deferred.get('pipeline_defer_last_at_utc'))
                self.assertEqual(
                    (deferred.get('pipeline_defer_policy_decision') or {}).get('reason'),
                    'shadow_pipeline_running')

    def test_enqueue_deduplicates_recent_equivalent_request(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                # Give worker a brief moment to persist running/terminal state.
                time.sleep(0.05)
                second = mgr.enqueue(req)
                self.assertTrue(second.get('accepted'))
                self.assertEqual(second.get('policy_decision'), 'deduplicated')
                msg = str(second.get('message') or '')
                self.assertIn('run_evidence', msg)
                self.assertIn('run-1', msg)
                self.assertIn('issue-1', msg)
                self.assertIn('scope-1', msg)
                _wait_worker_quiet(mgr)

    def test_enqueue_deduplicates_main_menu_autofollow_equivalent_request(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'main_menu_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'anchor-1',
                    'context_run_id': 'phase-d-1',
                    'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'source_scope_hash': 'main_menu_cloud_autofollow|main_menu_autofollow|anchored_review',
                    'operator_execution_mode': 'main_menu_autofollow',
                    'recommendation_action_kind': 'send_bundle',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                time.sleep(0.05)
                second = mgr.enqueue(dict(req))
                self.assertTrue(second.get('accepted'))
                self.assertEqual(second.get('policy_decision'), 'deduplicated')
                self.assertEqual(second.get('policy_reason'), 'duplicate_equivalent_request')
                self.assertEqual(second.get('job_id'), first.get('job_id'))
                assert_workflow_boundary_clean(
                    'main_menu_autofollow_support_send_dedup',
                    {
                        'anchor_run_id': 'anchor-1',
                        'context_run_id': 'phase-d-1',
                        'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    },
                    [
                        {
                            'name': 'first_enqueue',
                            'role': 'support_send_job',
                            'identity': {
                                'anchor_run_id': 'anchor-1',
                                'context_run_id': 'phase-d-1',
                                'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                            },
                            'status': 'queued',
                            'classification': 'in_flight',
                            'claims_completion': False,
                        },
                        {
                            'name': 'duplicate_enqueue',
                            'role': 'support_send_dedup',
                            'identity': {
                                'anchor_run_id': 'anchor-1',
                                'context_run_id': 'phase-d-1',
                                'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                            },
                            'status': 'skipped',
                            'classification': 'ignored',
                            'claims_completion': False,
                        },
                    ],
                )
                _wait_worker_quiet(mgr)

    def test_enqueue_suppresses_duplicate_when_blocked_run_evidence(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '900',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-blocked',
                    'context_run_id': 'run-blocked',
                    'issue_code': 'issue-blocked',
                    'source_scope_hash': 'scope-blocked',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                job = mgr._build_job_record(req, 'queued', 'single_flight_busy')
                job['status'] = 'blocked'
                job['policy_reason'] = 'single_flight_busy'
                mgr._write_job(job)
                dup = mgr.enqueue(req)
                self.assertTrue(dup.get('accepted'))
                self.assertEqual(str(dup.get('policy_decision')), 'deduplicated')
                self.assertEqual(str(dup.get('job_id')), str(job.get('job_id')))

    def test_queue_state_write_reclaims_orphan_lock_with_dead_owner_pid(self):
        """Orphan sibling ``.lock`` must not yield lock_acquire failures (errno 17) on queue state."""
        import json as json_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                lock_p = mgr.queue_state_path + '.lock'
                with open(lock_p, 'w') as handle:
                    json_mod.dump({
                        'pid': 999999991,
                        'created_at': time.time(),
                        'writer': 'support_send_jobs',
                        'artifact': 'support_send_queue',
                    }, handle)
                mgr._write_queue_state(['job-a'])
                self.assertFalse(os.path.exists(lock_p))
                st = mgr._read_queue_state()
                self.assertEqual(st.get('queued_job_ids'), ['job-a'])

    def test_blocked_job_is_requeued_when_single_flight_busy(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                }, 'queued', 'test')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                # Simulate post-dequeue state where picked job id was removed.
                mgr._write_queue_state([])
                mgr._acquire_single_flight = lambda _job_id: False
                mgr._run_single_job(job)
                refreshed = mgr._read_job(job_id)
                queue_state = mgr._read_queue_state()
                self.assertEqual(str(refreshed.get('status', '')), 'blocked')
                self.assertIn(job_id, queue_state.get('queued_job_ids', []))

    def test_retry_preserves_source_scope_hash_for_dedup_key(self):
        from MediCafe.support_send_jobs import SupportSendJobManager, SupportSendQueuePolicy
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'requested_artifact_scope': 'latest_live_snapshot',
                    'source_scope_hash': 'scope-1',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                _wait_worker_quiet(mgr)
                first_job_id = str(first.get('job_id', '') or '')
                retried = mgr.retry(first_job_id)
                self.assertTrue(retried.get('accepted'))
                retried_id = str(retried.get('job_id', '') or '')
                self.assertTrue(retried_id and retried_id != first_job_id)
                retried_job = mgr._read_job(retried_id)
                self.assertEqual(str(retried_job.get('source_scope_hash', '') or ''), 'scope-1')
                expected = SupportSendQueuePolicy().dedup_key({
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                })
                self.assertEqual(str(retried_job.get('dedup_key', '') or ''), expected)
                _wait_worker_quiet(mgr)

    def test_retry_deduplicates_against_active_equivalent_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '600',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'cloud_readiness_follow_recommendation',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-retry-active',
                    'context_run_id': 'run-retry-active',
                    'issue_code': 'issue-retry-active',
                    'requested_artifact_scope': 'latest_live_snapshot',
                    'source_scope_hash': 'scope-retry-active',
                    'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
                }
                first = mgr.enqueue(req)
                self.assertTrue(first.get('accepted'))
                _wait_worker_quiet(mgr)
                first_job_id = str(first.get('job_id', '') or '')

                active = mgr._build_job_record(req, 'queued', 'queued_jobs_pending')
                active['status'] = 'blocked'
                active['policy_reason'] = 'single_flight_busy'
                mgr._write_job(active)

                retried = mgr.retry(first_job_id)
                self.assertTrue(retried.get('accepted'))
                self.assertEqual(str(retried.get('policy_decision') or ''), 'deduplicated')
                self.assertEqual(str(retried.get('job_id') or ''), str(active.get('job_id') or ''))

    def test_cancel_queued_job_removes_from_queue_and_sets_canceled(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'run-1',
                    'context_run_id': 'run-1',
                    'issue_code': 'issue-1',
                    'source_scope_hash': 'scope-1',
                }, 'queued', 'test')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                res = mgr.cancel_job_if_possible(job_id, reason='test_cancel')
                self.assertTrue(res.get('ok'))
                self.assertEqual(str(res.get('policy_reason')), 'canceled_queued')
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'canceled')
                self.assertTrue(refreshed.get('suppress_restart_recovery'))
                queue_state = mgr._read_queue_state()
                self.assertNotIn(job_id, queue_state.get('queued_job_ids', []))

    def test_cancel_running_job_returns_running_not_cancelable(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'running'
            mgr._write_job(job)
            res = mgr.cancel_job_if_possible(job_id, reason='x')
            self.assertFalse(res.get('ok'))
            self.assertEqual(str(res.get('policy_reason')), 'running_not_cancelable')

    def test_run_single_job_skips_when_job_file_marked_canceled(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'canceled'
            mgr._write_job(job)
            calls = []

            def _track(_j, _cb):
                calls.append(1)
                return (True, 'ok', {})

            mgr._execute_send = _track
            mgr._run_single_job({'job_id': job_id})
            self.assertEqual(calls, [])

    def test_request_shutdown_running_job_marks_cancel_requested(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'running'
            mgr._write_job(job)
            res = mgr.request_job_shutdown_if_possible(job_id, reason='unit_safe_cancel', request_id='req-1')
            self.assertTrue(res.get('ok'))
            self.assertEqual(str(res.get('policy_reason')), 'cancel_requested_running')
            refreshed = mgr._read_job(job_id)
            self.assertTrue(refreshed.get('cancel_requested'))
            self.assertEqual(str(refreshed.get('shutdown_request_id')), 'req-1')

    def test_run_single_job_stops_at_progress_checkpoint_after_cancel_request(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            mgr._write_job(job)

            def _execute(_job, progress):
                running = mgr._read_job(job_id)
                running['cancel_requested'] = True
                running['cancel_reason'] = 'unit_checkpoint'
                mgr._write_job(running)
                progress('creating zip bundle')
                return (True, 'should not complete', {})

            mgr._execute_send = _execute
            mgr._run_single_job({'job_id': job_id})
            refreshed = mgr._read_job(job_id)
            self.assertEqual(str(refreshed.get('status')), 'canceled')
            self.assertEqual(str(refreshed.get('progress_stage')), 'canceled')
            self.assertFalse(bool(refreshed.get('result_ok')))

    def test_recover_skips_jobs_with_suppress_restart_recovery(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-1',
                'context_run_id': 'run-1',
                'issue_code': 'issue-1',
                'source_scope_hash': 'scope-1',
            }, 'queued', 'test')
            job_id = str(job.get('job_id'))
            job['status'] = 'canceled'
            job['suppress_restart_recovery'] = True
            mgr._write_job(job)
            mgr._write_queue_state([])
            recovery = mgr.recover_jobs_after_launcher_restart()
            self.assertEqual(recovery.get('recovered_job_ids', []), [])
            queue_state = mgr._read_queue_state()
            self.assertEqual(queue_state.get('queued_job_ids', []), [])

    def test_queued_job_is_active_and_kicks_worker_from_status_check(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'post_update_cloud_autofollow',
                'priority': 'high',
                'send_type': 'system_health',
                'source_scope_hash': 'scope-queued-active',
                'installed_version': '1.1.0',
                'recommendation_action_kind': 'resolve_layer1_upstream_blocker',
            }, 'started', 'started_immediately')
            job_id = str(job.get('job_id'))
            mgr._write_job(job)
            mgr._write_queue_state([job_id])

            with patch.object(mgr, '_ensure_worker_locked') as ensure_worker:
                active = mgr._find_active_job()

            self.assertEqual(active.get('job_id'), job_id)
            self.assertEqual(active.get('status'), 'queued')
            ensure_worker.assert_called_once_with()

    def test_enqueue_behind_queued_job_records_queued_pending_reason(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            first = mgr._build_job_record({
                'source': 'post_update_cloud_autofollow',
                'priority': 'high',
                'send_type': 'system_health',
                'anchor_run_id': 'queued-head',
                'source_scope_hash': 'scope-first',
            }, 'started', 'started_immediately')
            first_id = str(first.get('job_id'))
            mgr._write_job(first)
            mgr._write_queue_state([first_id])

            with patch.object(mgr, '_ensure_worker_locked') as ensure_worker:
                result = mgr.enqueue({
                    'source': 'deferred_operator_send',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'anchor_run_id': 'queued-tail',
                    'source_scope_hash': 'scope-second',
                })

            self.assertTrue(result.get('accepted'))
            self.assertEqual(result.get('policy_decision'), 'queued')
            second = mgr._read_job(str(result.get('job_id') or ''))
            self.assertEqual(second.get('policy_reason'), 'queued_jobs_pending')
            self.assertEqual(second.get('queued_before'), 1)
            queue_state = mgr._read_queue_state()
            self.assertEqual(queue_state.get('queued_job_ids', [])[0], first_id)
            self.assertIn(second.get('job_id'), queue_state.get('queued_job_ids', []))
            ensure_worker.assert_called_once_with()

    def test_queue_context_snapshot_includes_lifecycle_fields_and_post_update_context(self):
        import json
        from MediCafe import evidence_manifest
        from MediCafe.support_send_jobs import SupportSendJobManager

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            with open(os.path.join(reports_dir, 'post_update_cloud_autofollow_state.json'), 'w') as handle:
                json.dump({
                    'status': 'queued_send',
                    'stage': 'queued',
                    'job_id': 'ssj-post-update',
                    'installed_version': '1.1.0',
                    'last_reason': 'recommended_send_queued',
                    'updated_at_utc': '2026-05-03T05:50:00Z',
                    'post_update_evidence_freshness_status': 'fresh',
                    'post_update_fresh_shadow_run_id': 'run-ctx',
                    'post_update_fresh_machine_app_version': '1.1.0',
                    'post_update_freshness_blocking_reason': '',
                    'post_update_fresh_pipeline_status': 'completed',
                    'token': 'must_not_leak',
                }, handle)
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'post_update_cloud_autofollow',
                'priority': 'high',
                'send_type': 'run_evidence',
                'anchor_run_id': 'run-ctx',
                'context_run_id': 'run-ctx',
                'issue_code': 'issue-ctx',
                'source_scope_hash': 'scope-ctx',
                'operator_execution_mode': 'post_update_autofollow',
                'installed_version': '1.1.0',
                'recommendation_action_kind': 'send_bundle',
                'frozen_recommendation': {'recommended_action_kind': 'send_bundle'},
            }, 'queued', 'shadow_pipeline_running')
            job['pipeline_defer_count'] = 3
            job['pipeline_defer_started_at_utc'] = '2026-05-03T05:45:00Z'
            job['pipeline_defer_last_at_utc'] = '2026-05-03T05:47:00Z'
            job['delivery_state'] = 'queued_waiting'
            job['delivery_issue_code'] = 'SUPPORT_DELIVERY_REAUTH_REQUIRED'
            job['finished_at_utc'] = '2026-05-03T05:55:00Z'
            job['post_update_autofollow_lab_state'] = {
                'lab_status': 'queued_send',
                'lab_stage': 'queued',
                'lab_job_id': str(job.get('job_id')),
                'lab_last_reason': 'recommended_send_queued',
                'installed_version': '1.1.0',
                'lab_state_updated_at_utc': '2026-05-03T05:50:00Z',
                'post_update_evidence_freshness_status': 'fresh',
                'post_update_fresh_shadow_run_id': 'run-ctx',
                'post_update_fresh_machine_app_version': '1.1.0',
                'post_update_freshness_blocking_reason': '',
                'post_update_fresh_pipeline_status': 'completed',
                'token': 'must_not_leak',
            }
            mgr._write_job(job)

            path = evidence_manifest._write_support_send_queue_context_snapshot(lab_root)
            with open(path, 'r') as handle:
                snap = json.load(handle)
            rows = snap.get('recent_jobs') or []
            row = rows[0]

            self.assertEqual(snap.get('schema_version'), 2)
            self.assertEqual(
                snap.get('post_update_autofollow_lifecycle', {}).get('status'),
                'queued_send')
            self.assertNotIn('token', snap.get('post_update_autofollow_lifecycle', {}))
            self.assertEqual(row.get('source'), 'post_update_cloud_autofollow')
            self.assertEqual(row.get('operator_execution_mode'), 'post_update_autofollow')
            self.assertEqual(row.get('installed_version'), '1.1.0')
            self.assertEqual(row.get('recommendation_action_kind'), 'send_bundle')
            self.assertEqual(row.get('policy_reason'), 'shadow_pipeline_running')
            self.assertEqual(row.get('delivery_state'), 'queued_waiting')
            self.assertEqual(row.get('delivery_issue_code'), 'SUPPORT_DELIVERY_REAUTH_REQUIRED')
            self.assertEqual(row.get('finished_at_utc'), '2026-05-03T05:55:00Z')
            self.assertEqual(int(row.get('pipeline_defer_count') or 0), 3)
            self.assertEqual(
                row.get('post_update_autofollow_lifecycle', {}).get('lab_status'),
                'queued_send')
            self.assertEqual(
                snap.get('post_update_autofollow_lifecycle', {}).get('post_update_evidence_freshness_status'),
                'fresh')
            self.assertEqual(
                row.get('post_update_autofollow_lifecycle', {}).get('post_update_fresh_pipeline_status'),
                'completed')
            self.assertNotIn('token', row.get('post_update_autofollow_lifecycle', {}))


class TestFrozenRecommendationRunEvidence(unittest.TestCase):

    def test_run_evidence_send_skips_recompute_when_frozen_recommendation_provided(self):
        from MediCafe import cloud_readiness as cr_mod
        from MediCafe import cloud_readiness_recommendations as rec_mod
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            triage_path = os.path.join(reports_dir, 'artifact_triage_pack_test.txt')
            index_path = os.path.join(reports_dir, 'run_artifact_index_test.txt')
            bundle_path = os.path.join(reports_dir, 'support_bundle_test.zip')
            stale_txt = os.path.join(reports_dir, 'support_send_stale_preflight_latest.txt')
            stale_json = os.path.join(reports_dir, 'support_send_stale_preflight_latest.json')
            for p in (triage_path, index_path, bundle_path, stale_txt, stale_json):
                with open(p, 'w') as h:
                    h.write('x')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab_root,
                'reports_dir': reports_dir,
                'run_id': '20260410-011341-b73de336',
                'artifact_files': [],
                'context_files': [],
            }
            frozen = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_anchor_run_id': '20260410-011341-b73de336',
                'action_preview': {'anchor_run_id': '20260410-011341-b73de336'},
            }
            with patch.object(cr_mod, 'collect_support_bundle', return_value=bundle_path, create=True) as mock_collect, \
                    patch.object(cr_mod, 'submit_support_bundle_email', return_value=True, create=True), \
                    patch.object(cr_mod, '_build_run_artifact_snapshot', return_value=(True, '', snapshot), create=True), \
                    patch.object(cr_mod, '_artifact_bundle_quality', return_value={
                        'score': 100, 'label': 'GREEN', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'ready'
                    }, create=True), \
                    patch.object(cr_mod, '_write_artifact_triage_pack', return_value=triage_path, create=True), \
                    patch.object(cr_mod, '_write_run_artifact_index', return_value=index_path, create=True), \
                    patch.object(cr_mod, 'open_report_delivery_status', return_value=(False, '', ''), create=True), \
                    patch.object(cr_mod, '_collect_run_evidence_context_attachment', return_value=('', {}), create=True), \
                    patch.object(cr_mod, '_phase_d_dat_smoke_report_paths_for_run_evidence', return_value=[], create=True), \
                    patch.object(cr_mod, '_review_dat_qa_full_block_forced_attachment_paths', return_value=[], create=True), \
                    patch.object(cr_mod, '_phase_d_reprocess_report_paths_for_run_evidence', return_value=[], create=True), \
                    patch.object(cr_mod, '_latest_interrupt_report_paths', return_value=[], create=True), \
                    patch.object(cr_mod, '_submit_bundle_with_delivery_diagnostics', return_value=(True, 'sent', {}), create=True), \
                    patch.object(cr_mod, 'compute_operator_support_send_recommendation_core') as mock_compute:
                ok, msg, data = rec_mod.send_latest_run_evidence_bundle(
                    repo,
                    frozen_recommendation=frozen,
                )
            mock_compute.assert_not_called()
            self.assertTrue(isinstance(ok, bool))
            self.assertTrue(isinstance(msg, str))
            extra_files = mock_collect.call_args[1].get('extra_files', [])
            basenames = [item[0] for item in extra_files]
            self.assertIn('support_send_stale_preflight_latest.txt', basenames)
            self.assertIn('support_send_stale_preflight_latest.json', basenames)


class TestSupportSendDequeueAndDeliveryResolve(unittest.TestCase):
    """RCCA: blocked jobs must not disappear from queue when a queued job is dequeued."""

    def test_dequeue_preserves_blocked_job_ids_in_queue_order(self):
        from MediCafe.support_send_jobs import SupportSendJobManager

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr._ensure_dirs()
            jid_blocked = 'ssj_blocked_unit'
            jid_queued = 'ssj_queued_unit'
            mgr._write_job({
                'job_id': jid_blocked,
                'status': 'blocked',
                'send_type': 'system_health',
                'created_at_utc': '2020-01-01T00:00:00Z',
                'created_epoch': 1.0,
                'priority': 'normal',
                'progress_stage': 'blocked',
            })
            mgr._write_job({
                'job_id': jid_queued,
                'status': 'queued',
                'send_type': 'system_health',
                'created_at_utc': '2020-01-02T00:00:00Z',
                'created_epoch': 2.0,
                'priority': 'normal',
                'progress_stage': 'queued',
            })
            mgr._write_queue_state([jid_blocked, jid_queued])
            with mgr._state_lock:
                picked = mgr._dequeue_next_job_locked()
            self.assertEqual(str(picked.get('job_id')), jid_queued)
            state = mgr._read_queue_state()
            self.assertEqual(state.get('queued_job_ids'), [jid_blocked])

    def test_dequeue_no_ready_jobs_compacts_orphans_keeps_blocked(self):
        from MediCafe.support_send_jobs import SupportSendJobManager

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr._ensure_dirs()
            jid_blocked = 'ssj_blocked_only'
            mgr._write_job({
                'job_id': jid_blocked,
                'status': 'blocked',
                'send_type': 'system_health',
                'created_at_utc': '2020-01-01T00:00:00Z',
                'created_epoch': 1.0,
                'priority': 'normal',
                'progress_stage': 'blocked',
            })
            mgr._write_queue_state(['missing_job_json', jid_blocked])
            with mgr._state_lock:
                picked = mgr._dequeue_next_job_locked()
            self.assertEqual(picked, {})
            state = mgr._read_queue_state()
            self.assertEqual(state.get('queued_job_ids'), [jid_blocked])

    def test_resolve_delivery_diagnostics_falls_back_to_lab_report_status(self):
        from MediCafe.support_send_jobs import SupportSendJobManager

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            status_path = os.path.join(reports_dir, 'report_delivery_status.txt')
            with open(status_path, 'w') as handle:
                handle.write('delivery ok\n')
            mgr = SupportSendJobManager(repo, lab_root)
            path = mgr.resolve_delivery_diagnostics_path({
                'send_type': 'system_health',
                'status': 'queued',
                'delivery_status_path': '',
            })
            self.assertEqual(path, status_path)

    def test_list_jobs_includes_resolved_delivery_path(self):
        from MediCafe.support_send_jobs import SupportSendJobManager

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            reports_dir = os.path.join(lab_root, 'reports')
            os.makedirs(reports_dir)
            status_path = os.path.join(reports_dir, 'report_delivery_status.txt')
            with open(status_path, 'w') as handle:
                handle.write('x\n')
            mgr = SupportSendJobManager(repo, lab_root)
            mgr._ensure_dirs()
            mgr._write_job({
                'job_id': 'ssj_list_resolve',
                'status': 'queued',
                'send_type': 'system_health',
                'created_at_utc': '2020-01-03T00:00:00Z',
                'created_epoch': 3.0,
                'priority': 'normal',
                'delivery_status_path': '',
            })
            rows = mgr.list_jobs(limit=5)
            by_id = {str(r.get('job_id')): r for r in rows if isinstance(r, dict)}
            self.assertEqual(by_id['ssj_list_resolve'].get('delivery_diagnostics_resolved_path'), status_path)


class TestSystemHealthDedupAndWorkerPreflight(unittest.TestCase):

    def test_system_health_dedup_key_format(self):
        from MediCafe.support_send_jobs import SupportSendQueuePolicy
        policy = SupportSendQueuePolicy()
        with patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
            key = policy.dedup_key({
                'send_type': 'system_health',
                'anchor_run_id': 'run-a',
                'layer1_current_blocker': 'phase_c_db',
                'source_scope_hash': 'ignored-for-shp',
            })
        self.assertEqual(key, 'system_health|run-a|phase_c_db|20260505')

    def test_enqueue_suppresses_duplicate_when_blocked_system_health(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '900',
            }, clear=False):
                with patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
                    mgr = SupportSendJobManager(repo, lab_root)
                    req = {
                        'source': 'test',
                        'priority': 'high',
                        'send_type': 'system_health',
                        'anchor_run_id': 'ax',
                        'layer1_current_blocker': 'bx',
                    }
                    job = mgr._build_job_record(req, 'queued', 'queued_jobs_pending')
                    job['status'] = 'blocked'
                    job['policy_reason'] = 'single_flight_busy'
                    mgr._write_job(job)
                    dup = mgr.enqueue(req)
                self.assertTrue(dup.get('accepted'))
                self.assertEqual(str(dup.get('policy_decision')), 'deduplicated')

    def test_enqueue_system_health_allows_second_after_utc_day_changes(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DEDUP_TTL_SEC': '86400',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr._execute_send = lambda job, progress_callback: (True, 'ok', {})
                req = {
                    'source': 'test',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'anchor_run_id': 'same',
                    'layer1_current_blocker': 'same',
                }
                with patch('MediCafe.support_send_jobs.time.strftime', return_value='20260504'):
                    first = mgr.enqueue(req)
                    self.assertTrue(first.get('accepted'))
                _wait_worker_quiet(mgr)
                with patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
                    second = mgr.enqueue(req)
                self.assertTrue(second.get('accepted'))
                self.assertEqual(str(second.get('policy_decision')), 'started')
                self.assertNotEqual(str(second.get('job_id')), str(first.get('job_id')))
                _wait_worker_quiet(mgr)

    def test_worker_loop_invokes_preflight_before_handling_empty_queue(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        calls = []

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            real_preflight = mgr.preflight_reap_stale_running_jobs

            def _wrap_preflight():
                calls.append(1)
                return real_preflight()

            mgr.preflight_reap_stale_running_jobs = _wrap_preflight
            with patch.object(mgr, '_shadow_pipeline_lock_owner', return_value={}):
                mgr._worker_loop()
        self.assertEqual(calls, [1])

    def test_preflight_recovers_blocked_single_flight_jobs_when_lock_missing(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-blocked-missing-lock',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                job['status'] = 'blocked'
                job['policy_reason'] = 'single_flight_busy'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                _safe_lock = mgr.single_flight_lock_path
                if os.path.exists(_safe_lock):
                    os.remove(_safe_lock)
                recovered = mgr.preflight_reap_stale_running_jobs()
                self.assertEqual(recovered, [])
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'queued')
                self.assertEqual(str(refreshed.get('policy_reason')), 'single_flight_recovered_after_orphan_lock')
                self.assertEqual(int(refreshed.get('recovery_count') or 0), 1)

    def test_preflight_recovers_blocked_single_flight_jobs_when_lock_pid_dead(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-blocked-dead-pid',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                job['status'] = 'blocked'
                job['policy_reason'] = 'single_flight_busy'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    handle.write('{"job_id":"x","pid":"999999","acquired_at_utc":"2026-01-01T00:00:00Z","heartbeat_at_utc":"2026-01-01T00:00:00Z"}')
                mgr.preflight_reap_stale_running_jobs()
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'queued')
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))

    def test_preflight_does_not_recover_blocked_job_when_lock_pid_alive_and_owner_running(self):
        """Stale heartbeat must not orphan when the lock owner job is still running."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        import json
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-blocked-stale-hb-live-pid',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                job['status'] = 'blocked'
                job['policy_reason'] = 'single_flight_busy'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                owner_job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-live-owner',
                }, 'started', 'started_immediately')
                owner_job['job_id'] = 'other-job'
                owner_job['status'] = 'running'
                owner_job['worker_pid'] = str(os.getpid())
                owner_job['started_at_utc'] = str(owner_job.get('created_at_utc') or '')
                mgr._write_job(owner_job)
                live_pid = str(os.getpid())
                lock_body = {
                    'job_id': 'other-job',
                    'pid': live_pid,
                    'acquired_at_utc': '2000-01-01T00:00:00Z',
                    'heartbeat_at_utc': '2000-01-01T00:00:00Z',
                    'acquired_epoch': 946684800.0,
                }
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    handle.write(json.dumps(lock_body))
                mgr.preflight_reap_stale_running_jobs()
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'blocked')
                self.assertTrue(os.path.isfile(mgr.single_flight_lock_path))

    def test_preflight_recovers_blocked_job_when_lock_pid_alive_but_owner_missing(self):
        """Live PID + stale heartbeat should recover when lock owner metadata is stale."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        import json
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_HEARTBEAT_STALE_SEC': '300',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-live-pid-missing-owner',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                job['status'] = 'blocked'
                job['policy_reason'] = 'single_flight_busy'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                lock_body = {
                    'job_id': 'missing-owner-job',
                    'pid': str(os.getpid()),
                    'acquired_at_utc': '2000-01-01T00:00:00Z',
                    'heartbeat_at_utc': '2000-01-01T00:00:00Z',
                    'acquired_epoch': 946684800.0,
                }
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    handle.write(json.dumps(lock_body))
                mgr.preflight_reap_stale_running_jobs()
                refreshed = mgr._read_job(job_id)
                self.assertEqual(str(refreshed.get('status')), 'queued')
                self.assertEqual(str(refreshed.get('policy_reason')), 'single_flight_recovered_after_orphan_lock')
                self.assertFalse(os.path.isfile(mgr.single_flight_lock_path))

    def test_acquire_single_flight_open_failure_without_lock_file_returns_false(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))
                with patch('MediCafe.support_send_jobs.os.open', side_effect=OSError('open failed')):
                    ok = mgr._acquire_single_flight('job-1')
                self.assertFalse(ok)
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))

    def test_list_jobs_recovers_worker_liveness_when_queue_pending(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        events = []

        def logger(event_name, details=None):
            events.append((str(event_name or ''), dict(details or {})))

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root, logger_fn=logger)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-worker-liveness',
                }, 'queued', 'queued_jobs_pending')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                mgr._worker_thread = None
                with patch.object(mgr, '_worker_loop', return_value=None):
                    mgr.list_jobs(limit=5)
                names = [name for name, _payload in events]
                self.assertIn('worker_liveness_recovered', names)

    def test_ensure_pending_worker_liveness_wakes_queued_job_without_list_jobs(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        events = []

        def logger(event_name, details=None):
            events.append((str(event_name or ''), dict(details or {})))

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root, logger_fn=logger)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-autowake-no-list',
                }, 'queued', 'queued_jobs_pending')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                mgr._worker_thread = None
                with patch.object(mgr, '_worker_loop', return_value=None):
                    woke = mgr.ensure_pending_worker_liveness(reason='post_update_autofollow_poll')
                self.assertTrue(woke)
                names = [name for name, _payload in events]
                self.assertIn('worker_liveness_recovered', names)

    def test_worker_should_run_preflight_throttled_without_running_job(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr.preflight_min_interval_sec = 3600
            mgr._worker_preflight_last_epoch = time.time()
            self.assertFalse(mgr._worker_should_run_preflight())

    def test_worker_should_run_preflight_bypasses_throttle_when_running_job_present(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            mgr.preflight_min_interval_sec = 999999
            mgr._worker_preflight_last_epoch = time.time()
            job = mgr._build_job_record({
                'send_type': 'system_health',
                'anchor_run_id': 'x',
                'layer1_current_blocker': '',
            }, 'queued', 'test')
            job['status'] = 'running'
            mgr._write_job(job)
            self.assertTrue(mgr._worker_should_run_preflight())

    def test_find_existing_job_for_dedup_key_prefers_newest_active(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
                mgr = SupportSendJobManager(repo, lab_root)
                req = {
                    'send_type': 'system_health',
                    'anchor_run_id': 'a',
                    'layer1_current_blocker': 'b',
                }
                k = mgr.policy.dedup_key(req)
                old = mgr._build_job_record(req, 'queued', 'x')
                old['job_id'] = 'ssj_old'
                old['status'] = 'queued'
                old['created_epoch'] = 10.0
                old['dedup_key'] = k
                new = dict(old)
                new['job_id'] = 'ssj_new'
                new['created_epoch'] = 20.0
                mgr._write_job(old)
                mgr._write_job(new)
            found = mgr.find_existing_job_for_dedup_key(k)
            self.assertEqual(str(found.get('job_id')), 'ssj_new')

    def test_stuck_reap_preflight_does_not_require_new_enqueue(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': '60',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                mgr.running_stale_sec = 60
                job = mgr._build_job_record({
                    'send_type': 'system_health',
                    'anchor_run_id': 'a',
                    'layer1_current_blocker': 'b',
                }, 'queued', 'x')
                job_id = str(job.get('job_id'))
                old_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(time.time() - 120))
                job['status'] = 'running'
                job['created_at_utc'] = old_utc
                job['created_epoch'] = time.time() - 120
                job['heartbeat_at_utc'] = old_utc
                job['worker_pid'] = ''
                mgr._write_job(job)
                reaped = mgr.preflight_reap_stale_running_jobs()
                self.assertEqual(reaped, [job_id])
                self.assertEqual(mgr._read_job(job_id).get('status'), 'failed')

    def test_recover_and_start_pending_jobs_wakes_worker_without_list_jobs(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        events = []

        def logger(event_name, details=None):
            events.append((str(event_name or ''), dict(details or {})))

        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root, logger_fn=logger)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'source_scope_hash': 'scope-recover-start',
                }, 'queued', 'queued_jobs_pending')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                mgr._worker_thread = None
                with patch.object(mgr, '_worker_loop', return_value=None):
                    res = mgr.recover_and_start_pending_jobs(reason='post_update_autofollow_poll')
                self.assertTrue(res.get('worker_started'))
                names = [name for name, _payload in events]
                self.assertIn('worker_liveness_recovered', names)

    def test_token_restored_reason_stamps_queued_delivery_state(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'send_type': 'system_health',
                    'anchor_run_id': 'a',
                    'layer1_current_blocker': 'b',
                }, 'queued', 'x')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                mgr._worker_thread = None
                with patch.object(mgr, '_worker_loop', return_value=None):
                    mgr.recover_and_start_pending_jobs(reason='oauth_token_restored_queue_drain')
                stamped = mgr._read_job(job_id)
                self.assertEqual(
                    str(stamped.get('delivery_state') or ''),
                    'token_restored_queue_drain_pending')

    def test_auth_restored_true_stamps_with_benign_poll_reason(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'send_type': 'system_health',
                    'anchor_run_id': 'a',
                    'layer1_current_blocker': 'b',
                }, 'queued', 'x')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                mgr._worker_thread = None
                with patch.object(mgr, '_worker_loop', return_value=None):
                    mgr.recover_and_start_pending_jobs(
                        reason='post_update_autofollow_poll', auth_restored=True)
                stamped = mgr._read_job(job_id)
                self.assertEqual(
                    str(stamped.get('delivery_state') or ''),
                    'token_restored_queue_drain_pending')

    def test_auth_restored_true_stamps_blocked_jobs(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'send_type': 'system_health',
                    'anchor_run_id': 'a',
                    'layer1_current_blocker': 'b',
                }, 'queued', 'single_flight_busy')
                job_id = str(job.get('job_id'))
                job['status'] = 'blocked'
                job['policy_reason'] = 'single_flight_busy'
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                mgr._worker_thread = None
                with patch.object(mgr, '_worker_loop', return_value=None):
                    mgr.recover_and_start_pending_jobs(
                        reason='post_update_autofollow_poll', auth_restored=True)
                stamped = mgr._read_job(job_id)
                self.assertEqual(
                    str(stamped.get('delivery_state') or ''),
                    'token_restored_queue_drain_pending')

    def test_post_update_poll_without_auth_restored_does_not_stamp_token_pending(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'send_type': 'system_health',
                    'anchor_run_id': 'a',
                    'layer1_current_blocker': 'b',
                }, 'queued', 'x')
                job_id = str(job.get('job_id'))
                mgr._write_job(job)
                mgr._write_queue_state([job_id])
                mgr._worker_thread = None
                with patch.object(mgr, '_worker_loop', return_value=None):
                    mgr.recover_and_start_pending_jobs(
                        reason='post_update_autofollow_poll', auth_restored=False)
                stamped = mgr._read_job(job_id)
                self.assertNotEqual(
                    str(stamped.get('delivery_state') or ''),
                    'token_restored_queue_drain_pending')

    def test_newer_shp_success_supersedes_older_queued_equivalent(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False), patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
                mgr = SupportSendJobManager(repo, lab_root)
                req = {
                    'send_type': 'system_health',
                    'anchor_run_id': 'run-a',
                    'layer1_current_blocker': 'phase_c_db',
                    'source': 'test',
                    'priority': 'high',
                }
                old = mgr._build_job_record(req, 'queued', 'queued_jobs_pending')
                old_id = str(old.get('job_id'))
                old['status'] = 'queued'
                old['created_epoch'] = 10.0
                old['dedup_key'] = mgr.policy.dedup_key(req)
                mgr._write_job(old)
                mgr._write_queue_state([old_id])

                new = mgr._build_job_record(req, 'started', 'started_immediately')
                new_id = str(new.get('job_id'))
                new['status'] = 'queued'
                new['created_epoch'] = 100.0
                new['dedup_key'] = old['dedup_key']
                mgr._write_job(new)

                mgr._execute_send = lambda _job, _cb: (True, 'ok', {'zip_path': os.path.join(lab_root, 'reports', 'shp.zip')})
                mgr._run_single_job(new)

                old_after = mgr._read_job(old_id)
                new_after = mgr._read_job(new_id)
                self.assertEqual(str(old_after.get('status')), 'superseded')
                self.assertEqual(str(old_after.get('superseded_by_job_id')), new_id)
                self.assertEqual(
                    str(old_after.get('delivery_state') or ''),
                    'queued_superseded_by_newer_equivalent')
                self.assertEqual(str(new_after.get('status')), 'succeeded')
                self.assertNotIn(old_id, mgr._read_queue_state().get('queued_job_ids', []))

    def test_run_evidence_queued_not_superseded_by_shp_success(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False), patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
                mgr = SupportSendJobManager(repo, lab_root)
                che = mgr._build_job_record({
                    'send_type': 'run_evidence',
                    'anchor_run_id': 'esc-1',
                    'context_run_id': 'esc-1',
                    'issue_code': 'cloud_health_escalation',
                    'source_scope_hash': 'scope-che',
                    'source': 'test',
                    'priority': 'high',
                }, 'queued', 'queued_jobs_pending')
                che_id = str(che.get('job_id'))
                che['status'] = 'queued'
                che['created_epoch'] = 5.0
                mgr._write_job(che)
                mgr._write_queue_state([che_id])

                shp_req = {
                    'send_type': 'system_health',
                    'anchor_run_id': 'run-a',
                    'layer1_current_blocker': 'phase_c_db',
                    'source': 'test',
                    'priority': 'high',
                }
                shp = mgr._build_job_record(shp_req, 'started', 'started_immediately')
                shp_id = str(shp.get('job_id'))
                shp['created_epoch'] = 50.0
                shp['dedup_key'] = mgr.policy.dedup_key(shp_req)
                mgr._write_job(shp)

                mgr._execute_send = lambda _job, _cb: (True, 'ok', {'zip_path': os.path.join(lab_root, 'reports', 'shp2.zip')})
                mgr._run_single_job(shp)

                che_after = mgr._read_job(che_id)
                self.assertEqual(str(che_after.get('status')), 'queued')
                self.assertNotEqual(str(che_after.get('status')), 'superseded')

    def test_failed_shp_reauth_stamps_queued_equivalent_waiting_for_auth(self):
        from MediCafe.support_send_jobs import SupportSendJobManager
        try:
            from MediCafe.error_reporter import SUPPORT_DELIVERY_REAUTH_REQUIRED
        except ImportError:
            SUPPORT_DELIVERY_REAUTH_REQUIRED = 'SUPPORT_DELIVERY_REAUTH_REQUIRED'
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
            }, clear=False), patch('MediCafe.support_send_jobs.time.strftime', return_value='20260505'):
                mgr = SupportSendJobManager(repo, lab_root)
                req = {
                    'send_type': 'system_health',
                    'anchor_run_id': 'run-a',
                    'layer1_current_blocker': 'bx',
                    'source': 'test',
                    'priority': 'high',
                }
                tail = mgr._build_job_record(req, 'queued', 'queued_jobs_pending')
                tail_id = str(tail.get('job_id'))
                tail['created_epoch'] = 20.0
                tail['dedup_key'] = mgr.policy.dedup_key(req)
                mgr._write_job(tail)
                mgr._write_queue_state([tail_id])

                failed = mgr._build_job_record(req, 'started', 'started_immediately')
                failed['created_epoch'] = 10.0
                failed['dedup_key'] = tail['dedup_key']
                mgr._write_job(failed)

                mgr._execute_send = lambda _job, _cb: (False, 'auth', {})
                with patch(
                        'MediCafe.error_reporter.get_last_support_email_delivery_meta',
                        return_value={
                            'delivery_issue_code': SUPPORT_DELIVERY_REAUTH_REQUIRED,
                            'delivery_state': 'paused_waiting_for_operator_reauth',
                        },
                ):
                    mgr._run_single_job(failed)

                tail_after = mgr._read_job(tail_id)
                self.assertEqual(str(tail_after.get('delivery_state') or ''), 'queued_waiting_for_auth')


class TestSupportSendQueueWorkerRegressionFixes(unittest.TestCase):
    """Regression coverage for Issue 1: SHP send required manual operator trigger."""

    def test_enqueue_persists_queued_after_for_in_process_worker_path(self):
        """``support_send_job_context`` snapshots must show the finalized queue position.

        Before the fix, ``enqueue`` set ``queued_after`` on the in-memory job
        dict but never flushed it to disk. Re-reading via ``_run_single_job``
        produced a stale ``-1`` sentinel that surfaced inside support bundle
        ``meta.extra_context.support_send_job_context.queued_after``.
        """
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '0',
                'MEDICAFE_SUPPORT_SEND_DETACHED_WORKER': '0',
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                # Block worker_loop so the persisted record is preserved
                # exactly as enqueue left it.
                with patch.object(mgr, '_ensure_worker_locked', return_value=False):
                    res = mgr.enqueue({
                        'source': 'test',
                        'priority': 'high',
                        'send_type': 'system_health',
                        'anchor_run_id': 'queued-after-stamp',
                        'layer1_current_blocker': 'phase_c_db',
                        'source_scope_hash': 'scope-queued-after',
                    })
                self.assertTrue(res.get('accepted'))
                jid = str(res.get('job_id') or '')
                persisted = mgr._read_job(jid)
                self.assertEqual(int(persisted.get('queued_after')), 1)
                self.assertEqual(int(persisted.get('queued_before')), 0)
                # The snapshot built for cloud_readiness consumers must
                # reflect the persisted (>=0) value rather than the -1
                # sentinel that previously leaked through.
                snapshot = mgr._job_log_payload(persisted)
                self.assertEqual(int(snapshot.get('queued_after')), 1)

    def test_orphan_in_process_running_job_is_requeued_on_recover(self):
        """In-process worker dying mid-job must not strand the job for ``running_stale_sec``."""
        from MediCafe import support_send_jobs as jobs_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                # Long stale window to prove orphan recovery is independent
                # of the preflight running_stale_sec gate.
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': str(6 * 60 * 60),
                'MEDICAFE_SUPPORT_SEND_RUNNING_ABANDONED_SEC': str(24 * 60 * 60),
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                job = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'anchor_run_id': 'orphan',
                    'layer1_current_blocker': 'phase_c_db',
                    'source_scope_hash': 'scope-orphan',
                }, 'started', 'started_immediately')
                jid = str(job.get('job_id'))
                fresh_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
                job['status'] = 'running'
                job['progress_stage'] = 'starting'
                job['heartbeat_at_utc'] = fresh_utc
                job['created_at_utc'] = fresh_utc
                job['started_at_utc'] = fresh_utc
                job['worker_pid'] = '999999'
                job['worker_mode'] = 'in_process_worker'
                mgr._write_job(job)
                # Lock owned by the orphan worker.
                import json
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': jid, 'pid': '999999'}, handle)

                with patch.object(jobs_mod, '_pid_running', return_value=False), \
                        patch.object(mgr, '_ensure_worker_locked', return_value=False):
                    result = mgr.recover_and_start_pending_jobs(
                        reason='ensure_pending_worker_liveness')

                refreshed = mgr._read_job(jid)
                self.assertEqual(str(refreshed.get('status')), 'queued')
                self.assertEqual(
                    str(refreshed.get('policy_reason')),
                    'orphan_in_process_worker_requeued')
                self.assertEqual(str(refreshed.get('worker_pid')), '')
                self.assertEqual(str(refreshed.get('worker_mode')), '')
                self.assertEqual(int(refreshed.get('recovery_count') or 0), 1)
                self.assertIn(jid, mgr._read_queue_state().get('queued_job_ids', []))
                # Single-flight lock owned by the dead worker must be released
                # so the new attempt is not falsely blocked.
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))
                self.assertNotEqual(result.get('worker_started'), None)

    def test_orphan_recovery_skips_running_job_owned_by_current_pid(self):
        """Live in-process work must not be re-queued while the worker is busy."""
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'system_health',
                'anchor_run_id': 'live',
                'layer1_current_blocker': 'phase_c_db',
                'source_scope_hash': 'scope-live',
            }, 'started', 'started_immediately')
            jid = str(job.get('job_id'))
            job['status'] = 'running'
            job['worker_pid'] = str(os.getpid())
            job['worker_mode'] = 'in_process_worker'
            mgr._write_job(job)

            requeued = mgr._requeue_orphan_in_process_running_jobs(reason='unit')

            self.assertEqual(requeued, [])
            self.assertEqual(str(mgr._read_job(jid).get('status')), 'running')

    def test_orphan_recovery_does_not_touch_detached_worker(self):
        """Detached workers go through the dedicated termination ladder, not orphan re-queue."""
        from MediCafe import support_send_jobs as jobs_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'system_health',
                'anchor_run_id': 'detached',
                'layer1_current_blocker': 'phase_c_db',
                'source_scope_hash': 'scope-detached',
            }, 'started', 'started_immediately')
            jid = str(job.get('job_id'))
            job['status'] = 'running'
            job['worker_pid'] = '424242'
            job['worker_mode'] = 'detached_worker'
            mgr._write_job(job)

            with patch.object(jobs_mod, '_pid_running', return_value=False):
                requeued = mgr._requeue_orphan_in_process_running_jobs(reason='unit')

            self.assertEqual(requeued, [])
            self.assertEqual(str(mgr._read_job(jid).get('status')), 'running')

    def test_orphan_recovery_skips_jobs_with_suppress_restart_recovery(self):
        from MediCafe import support_send_jobs as jobs_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            mgr = SupportSendJobManager(repo, lab_root)
            job = mgr._build_job_record({
                'source': 'test',
                'priority': 'high',
                'send_type': 'system_health',
                'anchor_run_id': 'suppressed',
                'layer1_current_blocker': 'phase_c_db',
                'source_scope_hash': 'scope-suppressed',
            }, 'started', 'started_immediately')
            jid = str(job.get('job_id'))
            job['status'] = 'running'
            job['worker_pid'] = '999999'
            job['worker_mode'] = 'in_process_worker'
            job['suppress_restart_recovery'] = True
            mgr._write_job(job)

            with patch.object(jobs_mod, '_pid_running', return_value=False):
                requeued = mgr._requeue_orphan_in_process_running_jobs(reason='unit')

            self.assertEqual(requeued, [])

    def test_enqueue_clears_orphan_running_job_before_marking_busy(self):
        """``enqueue`` must clear orphan in-process workers so the new request can start."""
        from MediCafe import support_send_jobs as jobs_mod
        from MediCafe.support_send_jobs import SupportSendJobManager
        with tempfile.TemporaryDirectory() as repo:
            lab_root = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab_root, 'reports'))
            with patch.dict(os.environ, {
                'MEDICAFE_SUPPORT_SEND_SINGLE_FLIGHT': '1',
                'MEDICAFE_SUPPORT_SEND_RUNNING_STALE_SEC': str(6 * 60 * 60),
            }, clear=False):
                mgr = SupportSendJobManager(repo, lab_root)
                orphan = mgr._build_job_record({
                    'source': 'post_update_cloud_autofollow',
                    'priority': 'high',
                    'send_type': 'system_health',
                    'anchor_run_id': 'orphan-pre-enqueue',
                    'layer1_current_blocker': 'phase_c_db',
                    'source_scope_hash': 'scope-orphan-pre-enqueue',
                }, 'started', 'started_immediately')
                orphan_id = str(orphan.get('job_id'))
                fresh_utc = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
                orphan['status'] = 'running'
                orphan['progress_stage'] = 'starting'
                orphan['heartbeat_at_utc'] = fresh_utc
                orphan['created_at_utc'] = fresh_utc
                orphan['started_at_utc'] = fresh_utc
                orphan['worker_pid'] = '999999'
                orphan['worker_mode'] = 'in_process_worker'
                mgr._write_job(orphan)
                import json
                with open(mgr.single_flight_lock_path, 'w') as handle:
                    json.dump({'job_id': orphan_id, 'pid': '999999'}, handle)

                with patch.object(jobs_mod, '_pid_running', return_value=False), \
                        patch.object(mgr, '_ensure_worker_locked', return_value=False):
                    res = mgr.enqueue({
                        'source': 'manual_send',
                        'priority': 'high',
                        'send_type': 'system_health',
                        'anchor_run_id': 'fresh-after-orphan',
                        'layer1_current_blocker': 'phase_c_db',
                        'source_scope_hash': 'scope-fresh-after-orphan',
                    })

                self.assertTrue(res.get('accepted'))
                # Orphan must already be requeued so the fresh request can
                # advance through the normal queue path; the lock owned by
                # the dead worker must be released.
                refreshed_orphan = mgr._read_job(orphan_id)
                self.assertEqual(str(refreshed_orphan.get('status')), 'queued')
                self.assertEqual(
                    str(refreshed_orphan.get('policy_reason')),
                    'orphan_in_process_worker_requeued')
                self.assertFalse(os.path.exists(mgr.single_flight_lock_path))


class TestSupportBundleSelfObservation(unittest.TestCase):
    """Regression coverage for SUPPORT_SEND_JOB_INCOMPLETE_OBSERVATION false positive."""

    def _annotation_meta(self, job_payload, lab_root, current_pid_override=None):
        """Drive ``_annotate_support_job_self_observation`` against a fixture job json."""
        import json
        from MediCafe import error_reporter as er

        jobs_dir = os.path.join(lab_root, 'reports', 'support_send_jobs')
        if not os.path.isdir(jobs_dir):
            os.makedirs(jobs_dir)
        jid = str(job_payload.get('job_id') or '')
        with open(os.path.join(jobs_dir, 'job_{0}.json'.format(jid)), 'w') as handle:
            json.dump(job_payload, handle)

        meta = {
            'extra_context': {
                'support_send_job_context': {'job_id': jid},
                'lab_root': lab_root,
            }
        }
        extra_meta = {'lab_root': lab_root}
        if current_pid_override is None:
            er._annotate_support_job_self_observation(meta, extra_meta, {})
        else:
            with patch('MediCafe.error_reporter.os.getpid', return_value=int(current_pid_override)):
                er._annotate_support_job_self_observation(meta, extra_meta, {})
        return meta

    def test_self_observed_in_flight_when_worker_pid_matches_current_pid(self):
        """When the bundle is built BY the worker that owns the job, do not flag incomplete observation."""
        from MediCafe import error_reporter as er
        with tempfile.TemporaryDirectory() as lab_root:
            current_pid = 4321
            job_payload = {
                'job_id': 'self_obs_match',
                'status': 'running',
                'worker_pid': str(current_pid),
                'worker_mode': 'in_process_worker',
            }
            meta = self._annotation_meta(
                job_payload,
                lab_root,
                current_pid_override=current_pid,
            )
            ctx = meta.get('extra_context') or {}
            self.assertEqual(ctx.get('self_observation_status'), 'self_observed_in_flight')
            self.assertNotIn('delivery_issue_code_support', ctx)
            # Sanity: the support delivery code must not bleed in via legacy callers.
            self.assertNotEqual(
                ctx.get('delivery_issue_code_support'),
                er.SUPPORT_SEND_JOB_INCOMPLETE_OBSERVATION)

    def test_incomplete_observation_when_worker_pid_belongs_to_other_process(self):
        from MediCafe import error_reporter as er
        with tempfile.TemporaryDirectory() as lab_root:
            job_payload = {
                'job_id': 'self_obs_other',
                'status': 'running',
                'worker_pid': '7777777',
                'worker_mode': 'in_process_worker',
            }
            meta = self._annotation_meta(
                job_payload,
                lab_root,
                current_pid_override=12345,
            )
            ctx = meta.get('extra_context') or {}
            self.assertEqual(ctx.get('self_observation_status'), 'incomplete_observation')
            self.assertEqual(
                ctx.get('delivery_issue_code_support'),
                er.SUPPORT_SEND_JOB_INCOMPLETE_OBSERVATION)

    def test_incomplete_observation_when_worker_pid_missing(self):
        """Empty/0 worker_pid keeps legacy ``incomplete_observation`` flagging behavior."""
        from MediCafe import error_reporter as er
        with tempfile.TemporaryDirectory() as lab_root:
            job_payload = {
                'job_id': 'self_obs_empty',
                'status': 'running',
            }
            meta = self._annotation_meta(job_payload, lab_root)
            ctx = meta.get('extra_context') or {}
            self.assertEqual(ctx.get('self_observation_status'), 'incomplete_observation')
            self.assertEqual(
                ctx.get('delivery_issue_code_support'),
                er.SUPPORT_SEND_JOB_INCOMPLETE_OBSERVATION)
