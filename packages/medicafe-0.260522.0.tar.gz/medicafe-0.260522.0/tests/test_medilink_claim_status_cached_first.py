import os
import sys


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


def _recent_record():
    return {
        'patient_name': 'Alice Example',
        'patient_id': 'P100',
        'member_id': 'P100',
        'payer_id': '87726',
        'dos': '2026-05-01',
        'first_seen_str': '2026-05-01 08:00',
        'latest_seen_str': '2026-05-02 09:00',
        'transactionId': 'tx-100',
        'source': 'index',
    }


def test_recent_submissions_uses_cached_first_without_initial_live_refresh(monkeypatch):
    from MediLink import MediLink_ClaimStatus as claim_status
    from MediCafe import submission_query
    from MediCafe import claim_status_cache

    record = _recent_record()
    captured_rows = []

    monkeypatch.setattr(submission_query, 'get_consolidated_latest_variants_from_all_sources', lambda *a, **k: [record])
    monkeypatch.setattr(submission_query, 'get_recent_submissions_from_all_sources', lambda *a, **k: [record])
    monkeypatch.setattr(submission_query, 'get_last_submission_index_health', lambda: {})
    monkeypatch.setattr(claim_status, '_maybe_notify_json_health', lambda *a, **k: False)
    monkeypatch.setattr(claim_status, 'get_api_client', lambda: object())
    monkeypatch.setattr(claim_status, '_get_claim_status_payer_ids', lambda _client: ['87726'])
    monkeypatch.setattr(claim_status, 'display_recent_submissions_status_table', lambda rows: captured_rows.extend(rows))
    monkeypatch.setattr(claim_status, '_stdin_readline', lambda _prompt='': '')
    monkeypatch.setattr(claim_status, '_perform_submission_context_lookup', lambda *_a, **_k: (_ for _ in ()).throw(AssertionError('unexpected live refresh')))
    monkeypatch.setattr(claim_status_cache, 'get_cache_key', lambda _record: 'key-1')
    monkeypatch.setattr(
        claim_status_cache,
        'get_cached_status',
        lambda _root, _key: {
            'last_checked_at': 1.0,
            'final': False,
            'summary': {
                'status_display': 'Submitted',
                'claim_number': 'C100',
                'paid_amount': '0.00',
                'patient_name': 'Alice Example',
            },
        },
    )
    monkeypatch.setattr(claim_status_cache, 'is_within_refresh_window', lambda _ts: False)
    monkeypatch.setattr(claim_status_cache, 'set_cached_status', lambda *a, **k: None)
    monkeypatch.setattr(claim_status_cache, 'parse_result_to_summary', lambda result: ({}, False))

    ok = claim_status.run_recent_submissions_lookup({'MediLink_Config': {'local_claims_path': '.'}})

    assert ok is True
    assert len(captured_rows) == 1
    assert captured_rows[0]['status_display'] == 'Submitted'
    assert captured_rows[0]['_freshness_state'] == 'stale'
    assert captured_rows[0]['_status_source'] == 'cache'


def test_recent_submissions_refreshes_selected_row_when_cache_missing(monkeypatch):
    from MediLink import MediLink_ClaimStatus as claim_status
    from MediCafe import submission_query
    from MediCafe import claim_status_cache

    record = _recent_record()
    cache_store = {}
    displayed_results = []
    lookup_calls = []
    prompts = iter(['1', '', ''])

    monkeypatch.setattr(submission_query, 'get_consolidated_latest_variants_from_all_sources', lambda *a, **k: [record])
    monkeypatch.setattr(submission_query, 'get_recent_submissions_from_all_sources', lambda *a, **k: [record])
    monkeypatch.setattr(submission_query, 'get_last_submission_index_health', lambda: {})
    monkeypatch.setattr(claim_status, '_maybe_notify_json_health', lambda *a, **k: False)
    monkeypatch.setattr(claim_status, 'get_api_client', lambda: object())
    monkeypatch.setattr(claim_status, '_get_claim_status_payer_ids', lambda _client: ['87726'])
    monkeypatch.setattr(claim_status, 'display_recent_submissions_status_table', lambda rows: None)
    monkeypatch.setattr(claim_status, 'display_submission_context_results', lambda result: displayed_results.append(result))
    monkeypatch.setattr(claim_status, '_stdin_readline', lambda _prompt='': next(prompts))
    monkeypatch.setattr(claim_status, '_extract_member_data_from_submission', lambda _record, _config: {'payer_id': '87726', 'member_id': 'P100'})

    def _fake_lookup(member_data):
        lookup_calls.append(member_data)
        return {
            'statuscode': '000',
            'lookup_type': 'member_data',
            'message': 'ok',
            'claim_status': {
                'claims': [{
                    'claimNumber': 'C200',
                    'claimStatus': 'Paid',
                    'claimSummary': {'totalPaidAmt': '12.34'},
                    'memberInfo': {'ptntFn': 'Alice', 'ptntLn': 'Example'},
                }]
            },
        }

    monkeypatch.setattr(claim_status, '_perform_submission_context_lookup', _fake_lookup)
    monkeypatch.setattr(claim_status_cache, 'get_cache_key', lambda _record: 'key-2')
    monkeypatch.setattr(claim_status_cache, 'get_cached_status', lambda _root, key: cache_store.get(key))
    monkeypatch.setattr(claim_status_cache, 'is_within_refresh_window', lambda _ts: False)

    def _fake_set_cached_status(_root, key, final, summary, statuscode=None, lookup_type=None, last_result=None):
        cache_store[key] = {
            'last_checked_at': 10.0,
            'final': final,
            'summary': summary,
            'statuscode': statuscode,
            'lookup_type': lookup_type,
            'last_result': last_result,
        }

    monkeypatch.setattr(claim_status_cache, 'set_cached_status', _fake_set_cached_status)

    ok = claim_status.run_recent_submissions_lookup({'MediLink_Config': {'local_claims_path': '.'}})

    assert ok is True
    assert len(lookup_calls) == 1
    assert displayed_results
    assert cache_store['key-2']['summary']['status_display'] == 'Paid'
    assert cache_store['key-2']['final'] is True
