#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
XP-safe CSV metadata index for cheap deductible/report recency lookups.

This is intentionally not a general CSV content cache.  It stores only the
identity/date/payer fields currently reused by report flows, plus aggregate
file/header metadata and skip/error status.
"""
from __future__ import print_function

import codecs
import csv
import io
import json
import os
import time
from datetime import datetime, timedelta


INDEX_FILENAME = '.csv_metadata_index.json'
STATUS_FILENAME = '.csv_metadata_index_status.json'
INDEX_VERSION = 1
PARSE_ERROR_MESSAGE_LIMIT = 200

PATIENT_ID_ALIASES = [
    'Patient ID',
    'Patient ID 2',
    'Patient ID #2',
    'patient_id',
    'PATID',
    'patid',
    'internal_patid',
    'patientId',
    'PatientID',
]

DOB_ALIASES = [
    'Patient DOB',
    'DOB',
    'Birth Date',
    'birth_date',
    'dob',
    'date_of_birth',
    'member_dob',
]

MEMBER_ID_ALIASES = [
    'Primary Policy Number',
    'Ins1 Member ID',
    'Member ID',
    'member_id',
    'memberId',
    'policy_number',
]

PAYER_ID_ALIASES = [
    'Ins1 Payer ID',
    'Primary Payer ID',
    'payer_id',
    'Payer ID',
    'PAYERID',
]

DOS_ALIASES = [
    'Surgery Date',
    'Service Date',
    'Date of Service',
    'DOS',
    'dos',
    'DATE1',
    'Date',
    'service_date',
    'surgery_date',
    'surgery_date_iso',
    'date_of_service',
]

GROUP_NUMBER_ALIASES = [
    'Group Policy 1',
    'Group Policy1',
    'GroupPolicy1',
    'Group Policy',
    'Group #',
    'Group Number',
]

ACTION_STRONG_HEADERS = set([
    'claim_key',
    'Claim Key',
    'internal_claim_key',
    'next_action',
    'Next Action',
    'claim_number',
    'Claim #',
    'Claim Number',
    'submitted_claim_number',
])

ACTION_WEAK_HEADERS = set([
    'category',
    'Category',
    'detail',
    'patient_id',
    'payer_id',
])

DATE_FORMATS = (
    '%Y-%m-%d',
    '%Y/%m/%d',
    '%m/%d/%Y',
    '%m-%d-%Y',
    '%m/%d/%y',
    '%m-%d-%y',
)


def _default_index(csv_dir=''):
    return {
        'version': INDEX_VERSION,
        'csv_dir': csv_dir or '',
        'updated_at_utc': None,
        'files': {},
        'skipped_files': {},
        'latest_by_patient_id': {},
        'latest_by_demog': {},
    }


class CsvMetadataUpdateResult(dict):
    """Dict status payload that can also unpack as (index_data, stats)."""

    def __init__(self, index_data, stats, status_data):
        dict.__init__(self, status_data or {})
        self.index_data = index_data
        self.stats = stats

    def __iter__(self):
        return iter((self.index_data, self.stats))


def _safe_text(value):
    if value is None:
        return ''
    try:
        return str(value).strip()
    except Exception:
        return ''


def _safe_basename(path):
    try:
        return os.path.basename(str(path or '').replace('\\', '/'))
    except Exception:
        return ''


def _truncate_message(value, limit=PARSE_ERROR_MESSAGE_LIMIT):
    text = _safe_text(value)
    if len(text) <= limit:
        return text
    return text[:limit]


def _log(message, level='INFO'):
    try:
        from MediCafe.core_utils import get_config_loader_with_fallback
        logger = get_config_loader_with_fallback()
    except Exception:
        logger = None
    try:
        if logger and hasattr(logger, 'log'):
            logger.log(message, level=level)
            return
    except Exception:
        pass
    try:
        print('[{}] {}'.format(level, message))
    except Exception:
        pass


def _is_json_file_path(path):
    try:
        text = str(path or '')
    except Exception:
        return False
    return text.lower().endswith('.json')


def get_index_path(local_storage_path):
    if _is_json_file_path(local_storage_path):
        return local_storage_path
    return os.path.join(local_storage_path, INDEX_FILENAME)


def get_status_path(local_storage_path):
    if _is_json_file_path(local_storage_path):
        return local_storage_path
    return os.path.join(local_storage_path, STATUS_FILENAME)


def _artifact_parent(path):
    if _is_json_file_path(path):
        parent = os.path.dirname(os.path.abspath(path))
        return parent or '.'
    return path


def _safe_replace(src, dst):
    attempts = 0
    while attempts < 3:
        attempts += 1
        try:
            if os.path.exists(dst):
                os.remove(dst)
            os.rename(src, dst)
            return True
        except Exception:
            if attempts < 3:
                try:
                    time.sleep(0.05 * attempts)
                except Exception:
                    pass
    return False


def _save_json_payload(path, payload, write_label, warning_label):
    try:
        from MediCafe.json_io import write_json_atomic
    except ImportError:
        write_json_atomic = None
    if write_json_atomic is not None:
        if write_json_atomic(
                path,
                payload,
                write_label,
                'MediBot_csv_metadata_index',
                indent=2,
                sort_keys=True,
                lock=True,
                ensure_ascii=False,
        ):
            return True
        _log('Failed to write {}: atomic write returned false'.format(warning_label), level='WARNING')
        return False
    tmp_path = path + '.tmp'
    try:
        with io.open(tmp_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
        if _safe_replace(tmp_path, path):
            return True
        _log('Failed to write {}: replace returned false'.format(warning_label), level='WARNING')
        return False
    except Exception as exc:
        _log('Failed to write {}: {}'.format(warning_label, exc), level='WARNING')
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        return False


def load_csv_metadata_index(local_storage_path):
    index_path = get_index_path(local_storage_path)
    if not os.path.exists(index_path):
        return _default_index()
    try:
        with io.open(index_path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            return _default_index()
        if 'files' not in data or not isinstance(data.get('files'), dict):
            return _default_index()
        if data.get('version') != INDEX_VERSION:
            data.setdefault('files', {})
            data.setdefault('latest_by_patient_id', {})
            data.setdefault('latest_by_demog', {})
            data['version'] = INDEX_VERSION
        data.setdefault('csv_dir', '')
        data.setdefault('latest_by_patient_id', {})
        data.setdefault('latest_by_demog', {})
        return data
    except Exception:
        return _default_index()


def save_csv_metadata_index(local_storage_path, index_data):
    try:
        parent = _artifact_parent(local_storage_path)
        if parent and not os.path.isdir(parent):
            try:
                os.makedirs(parent)
            except Exception:
                pass
        index_data['updated_at_utc'] = int(time.time())
        return _save_json_payload(
            get_index_path(local_storage_path),
            index_data,
            'csv_metadata_index',
            'CSV metadata index',
        )
    except Exception as exc:
        _log('Failed to save CSV metadata index: {}'.format(exc), level='WARNING')
        return False


def load_csv_metadata_index_status(local_storage_path):
    status_path = get_status_path(local_storage_path)
    if not os.path.exists(status_path):
        return {}
    try:
        with io.open(status_path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_csv_metadata_index_status(local_storage_path, status_data):
    try:
        parent = _artifact_parent(local_storage_path)
        if parent and not os.path.isdir(parent):
            try:
                os.makedirs(parent)
            except Exception:
                pass
        return _save_json_payload(
            get_status_path(local_storage_path),
            status_data,
            'csv_metadata_index_status',
            'CSV metadata index status',
        )
    except Exception as exc:
        _log('Failed to save CSV metadata index status: {}'.format(exc), level='WARNING')
        return False


def _detect_encoding(raw_data):
    if raw_data.startswith(codecs.BOM_UTF8):
        return 'utf-8-sig', 1.0
    if raw_data.startswith(codecs.BOM_UTF16_LE) or raw_data.startswith(codecs.BOM_UTF16_BE):
        return 'utf-16', 1.0
    try:
        import chardet
        result = chardet.detect(raw_data)
        if isinstance(result, dict) and result.get('encoding'):
            return result.get('encoding'), result.get('confidence')
    except Exception:
        pass
    return 'utf-8-sig', 1.0


def _read_csv_dict_rows(path):
    with open(path, 'rb') as handle:
        raw_data = handle.read()
    encoding, confidence = _detect_encoding(raw_data)
    try:
        text = raw_data.decode(encoding)
    except Exception:
        text = raw_data.decode('cp1252')
        encoding = 'cp1252'
        confidence = 0.0
    reader = csv.DictReader(io.StringIO(text), strict=True)
    fieldnames = reader.fieldnames or []
    rows = []
    for row in reader:
        if isinstance(row, dict):
            rows.append(row)
    return fieldnames, rows, encoding, confidence, len(raw_data)


def _scrub_header(header):
    try:
        from MediBot.csv_intake_shape import scrub_csv_header_token
        return scrub_csv_header_token(header)
    except Exception:
        text = _safe_text(header)
        return ''.join(
            char for char in text
            if char.isalnum() or char.isspace() or char in ['-', '_', '#']
        )


def _canonicalize_header(header):
    cleaned = _scrub_header(header)
    lower = cleaned.strip().lower()
    for alias in DOS_ALIASES:
        if lower == alias.strip().lower():
            return 'Surgery Date'
    return cleaned


def _cleaned_headers(raw_headers):
    return [_scrub_header(h) for h in (raw_headers or [])]


def _canonical_headers(raw_headers):
    return [_canonicalize_header(h) for h in (raw_headers or [])]


def _header_alias_map(raw_headers):
    out = {}
    for raw in raw_headers or []:
        cleaned = _scrub_header(raw)
        canonical = _canonicalize_header(raw)
        for key in (raw, cleaned, canonical):
            if key and key not in out:
                out[key] = raw
    return out


def _first_nonempty(row, aliases, alias_map=None):
    if not isinstance(row, dict):
        return '', ''
    alias_map = alias_map or {}
    for alias in aliases:
        keys = [alias]
        actual = alias_map.get(alias)
        if actual and actual not in keys:
            keys.append(actual)
        for key in keys:
            value = _safe_text(row.get(key))
            if value:
                return value, key
    return '', ''


def _normalize_date_iso(value):
    text = _safe_text(value)
    if not text or text.upper() == 'MISSING':
        return '', None
    candidates = [text]
    if 'T' in text:
        candidates.append(text.split('T', 1)[0].strip())
    if ' ' in text:
        candidates.append(text.split(' ', 1)[0].strip())
    seen = set()
    for candidate in candidates:
        candidate = _safe_text(candidate)
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        for fmt in DATE_FORMATS:
            try:
                dt = datetime.strptime(candidate, fmt)
                return dt.strftime('%Y-%m-%d'), dt
            except Exception:
                pass
    return '', None


def _demog_key(dob_iso, member_id):
    dob_iso = _safe_text(dob_iso)
    member_id = _safe_text(member_id)
    if not dob_iso or not member_id:
        return ''
    return dob_iso + '|' + member_id


def _date_sort_value(iso_value):
    text = _safe_text(iso_value)
    try:
        return int(text.replace('-', ''))
    except Exception:
        return 0


def _is_better_latest(candidate, current):
    if not isinstance(candidate, dict):
        return False
    if not isinstance(current, dict) or not current:
        return True
    cand_sort = _date_sort_value(candidate.get('dos_iso'))
    cur_sort = _date_sort_value(current.get('dos_iso'))
    if cand_sort != cur_sort:
        return cand_sort > cur_sort
    try:
        return float(candidate.get('source_mtime') or 0) >= float(current.get('source_mtime') or 0)
    except Exception:
        return True


def _classify_header_profile(raw_headers):
    raw_set = set([_safe_text(h) for h in (raw_headers or []) if _safe_text(h)])
    cleaned = _cleaned_headers(raw_headers)
    canonical = _canonical_headers(raw_headers)
    cleaned_set = set(cleaned)
    canonical_set = set(canonical)
    strong = raw_set.intersection(ACTION_STRONG_HEADERS).union(cleaned_set.intersection(ACTION_STRONG_HEADERS))
    weak = raw_set.intersection(ACTION_WEAK_HEADERS).union(cleaned_set.intersection(ACTION_WEAK_HEADERS))
    has_patient_id = bool(canonical_set.intersection(set(PATIENT_ID_ALIASES)))
    has_dos = bool(canonical_set.intersection(set(['Surgery Date'])))
    has_dob = bool(canonical_set.intersection(set(DOB_ALIASES)))
    has_member = bool(canonical_set.intersection(set(MEMBER_ID_ALIASES)))
    has_payer = bool(canonical_set.intersection(set(PAYER_ID_ALIASES)))
    profile = 'legacy_or_mixed_intake'
    skip_reason = ''
    if strong or len(weak) >= 3:
        profile = 'reconciliation_action_report'
        skip_reason = 'action_or_reconciliation_csv'
    elif not has_dos:
        profile = 'non_service_date_csv'
        skip_reason = 'missing_service_date_header'
    return {
        'profile_name': profile,
        'skip_reason': skip_reason,
        'header_count': len(raw_headers or []),
        'raw_headers': list(raw_headers or []),
        'cleaned_headers': cleaned,
        'canonical_headers': canonical,
        'has_patient_id': bool(has_patient_id),
        'has_service_date': bool(has_dos),
        'has_dob': bool(has_dob),
        'has_member_id': bool(has_member),
        'has_payer_id': bool(has_payer),
        'action_markers': sorted(list(strong.union(weak))),
    }


def _index_entry_from_row(row, alias_map, row_ordinal, filename, stat_info):
    patient_id, patient_header = _first_nonempty(row, PATIENT_ID_ALIASES, alias_map)
    dos_raw, dos_header = _first_nonempty(row, DOS_ALIASES, alias_map)
    dob_raw, dob_header = _first_nonempty(row, DOB_ALIASES, alias_map)
    member_id, member_header = _first_nonempty(row, MEMBER_ID_ALIASES, alias_map)
    payer_id, payer_header = _first_nonempty(row, PAYER_ID_ALIASES, alias_map)
    group_number, group_header = _first_nonempty(row, GROUP_NUMBER_ALIASES, alias_map)
    dos_iso, _dos_dt = _normalize_date_iso(dos_raw)
    dob_iso, _dob_dt = _normalize_date_iso(dob_raw)
    if not dos_iso:
        return None
    if not patient_id and not (dob_iso and member_id):
        return None
    rec = {
        'row_ordinal': int(row_ordinal),
        'source_file': filename,
        'source_mtime': stat_info.st_mtime,
        'source_size': stat_info.st_size,
        'patient_id': patient_id,
        'dob_iso': dob_iso,
        'member_id': member_id,
        'payer_id': payer_id,
        'dos_iso': dos_iso,
        'service_date': dos_raw,
        'source_headers': {
            'patient_id': patient_header,
            'dob': dob_header,
            'member_id': member_header,
            'payer_id': payer_header,
            'dos': dos_header,
        },
        'source_patient_id_header': patient_header,
        'source_service_date_header': dos_header,
    }
    if group_number:
        rec['group_number'] = group_number
        rec['source_headers']['group_number'] = group_header
    return rec


def _parse_csv_file(path):
    stat_info = os.stat(path)
    raw_headers, rows, encoding, confidence, raw_size = _read_csv_dict_rows(path)
    profile = _classify_header_profile(raw_headers)
    alias_map = _header_alias_map(raw_headers)
    filename = _safe_basename(path)
    indexed_rows = []
    if not profile.get('skip_reason'):
        ordinal = 0
        for row in rows:
            ordinal += 1
            rec = _index_entry_from_row(row, alias_map, ordinal, filename, stat_info)
            if rec:
                indexed_rows.append(rec)
    return {
        'file_basename': filename,
        'basename': filename,
        'path': os.path.abspath(path),
        'mtime': stat_info.st_mtime,
        'size': stat_info.st_size,
        'row_count': len(rows),
        'indexed_row_count': len(indexed_rows),
        'encoding': encoding or '',
        'encoding_confidence': confidence,
        'header_profile': profile,
        'rows': indexed_rows,
        'parse_failed': False,
        'status': 'skipped' if profile.get('skip_reason') else 'indexed',
        'updated_at': int(time.time()),
    }


def _same_stat(path, rec):
    if not isinstance(rec, dict):
        return False
    try:
        stat_info = os.stat(path)
    except Exception:
        return False
    try:
        if int(rec.get('size')) != int(stat_info.st_size):
            return False
    except Exception:
        return False
    try:
        return abs(float(rec.get('mtime')) - float(stat_info.st_mtime)) <= 0.001
    except Exception:
        return False


def _candidate_paths(csv_dir, filepaths, max_csv_files):
    if filepaths is not None:
        return [p for p in list(filepaths or []) if _safe_text(p).lower().endswith('.csv')]
    out = []
    if not csv_dir or not os.path.isdir(csv_dir):
        return out
    try:
        for name in os.listdir(csv_dir):
            if _safe_text(name).lower().endswith('.csv'):
                out.append(os.path.join(csv_dir, name))
        out.sort(key=lambda p: os.path.getmtime(p), reverse=True)
        if max_csv_files is not None:
            out = out[:int(max_csv_files)]
    except Exception:
        return []
    return out


def _rebuild_latest_maps(index_data):
    latest_by_pid = {}
    latest_by_demog = {}
    files = index_data.get('files') if isinstance(index_data, dict) else {}
    if not isinstance(files, dict):
        files = {}
    for _filename, file_rec in files.items():
        if not isinstance(file_rec, dict):
            continue
        if file_rec.get('status') in ('parse_failed', 'stale_parse_failed'):
            continue
        for row_rec in file_rec.get('rows') or []:
            if not isinstance(row_rec, dict):
                continue
            patient_id = _safe_text(row_rec.get('patient_id'))
            if patient_id and _is_better_latest(row_rec, latest_by_pid.get(patient_id)):
                latest_by_pid[patient_id] = dict(row_rec)
            demog = _demog_key(row_rec.get('dob_iso'), row_rec.get('member_id'))
            if demog and _is_better_latest(row_rec, latest_by_demog.get(demog)):
                latest_by_demog[demog] = dict(row_rec)
    index_data['latest_by_patient_id'] = latest_by_pid
    index_data['latest_by_demog'] = latest_by_demog


def _format_status_payload(source, mode, csv_dir_abs, requested_file_count, max_csv_files, force_rebuild, started_at, stats):
    status = {
        'source': source or 'unknown',
        'mode': mode,
        'csv_dir': csv_dir_abs,
        'requested_file_count': requested_file_count,
        'max_csv_files': max_csv_files,
        'force_rebuild': bool(force_rebuild),
        'started_at': started_at,
        'completed_at': int(time.time()),
        'stats': stats,
        'ok': int(stats.get('errors', 0) or 0) == 0,
        'parsed_count': int(stats.get('parsed', 0) or 0),
        'skipped_unchanged': int(stats.get('skipped', 0) or 0),
        'pruned_missing': int(stats.get('pruned', 0) or 0),
        'skipped_action_or_reconciliation': int(stats.get('skipped_action_or_reconciliation', 0) or 0),
        'indexed_count': int(stats.get('indexed_rows', 0) or 0),
        'error_count': int(stats.get('errors', 0) or 0),
    }
    if status['error_count']:
        status['last_error_code'] = 'csv_parse_failed'
    return status


def update_csv_metadata_index(
        local_storage_path,
        csv_dir=None,
        filepaths=None,
        force_rebuild=False,
        source='unknown',
        max_csv_files=80,
        index_path=None,
        status_path=None):
    if index_path or status_path:
        csv_dir_value = local_storage_path
        index_artifact = index_path or get_index_path(os.path.dirname(os.path.abspath(status_path)))
        status_artifact = status_path or get_status_path(os.path.dirname(os.path.abspath(index_path)))
        local_storage_for_load = index_artifact
        local_storage_for_status = status_artifact
    else:
        csv_dir_value = csv_dir
        local_storage_for_load = local_storage_path
        local_storage_for_status = local_storage_path
    started_at = int(time.time())
    csv_dir_abs = os.path.abspath(os.path.expanduser(csv_dir_value or '')) if csv_dir_value else ''
    mode = 'targeted' if filepaths is not None else 'full_scan'
    index_data = _default_index(csv_dir_abs) if force_rebuild else load_csv_metadata_index(local_storage_for_load)
    if index_data.get('csv_dir') and csv_dir_abs and index_data.get('csv_dir') != csv_dir_abs and filepaths is None:
        index_data = _default_index(csv_dir_abs)
    index_data['csv_dir'] = csv_dir_abs
    files = index_data.setdefault('files', {})
    skipped_files = index_data.setdefault('skipped_files', {})
    paths = _candidate_paths(csv_dir_abs, filepaths, max_csv_files)
    requested_file_count = len(paths)
    parsed = 0
    skipped = 0
    errors = 0
    profile_skipped = 0
    skipped_action_or_reconciliation = 0
    indexed_rows = 0
    pruned = 0
    updated = False

    if filepaths is None:
        present = set([_safe_basename(p) for p in paths])
        for existing in list(files.keys()):
            if existing not in present:
                del files[existing]
                pruned += 1
                updated = True
        for existing in list(skipped_files.keys()):
            if existing not in present:
                del skipped_files[existing]
                pruned += 1
                updated = True

    for path in paths:
        if not os.path.isfile(path):
            continue
        filename = _safe_basename(path)
        rec = files.get(filename)
        if rec is None:
            rec = skipped_files.get(filename)
        if (not force_rebuild) and rec is not None and _same_stat(path, rec):
            skipped += 1
            try:
                indexed_rows += int(rec.get('indexed_row_count') or 0)
                if (rec.get('header_profile') or {}).get('skip_reason'):
                    profile_skipped += 1
                    if (rec.get('header_profile') or {}).get('skip_reason') == 'action_or_reconciliation_csv':
                        skipped_action_or_reconciliation += 1
            except Exception:
                pass
            continue
        try:
            new_rec = _parse_csv_file(path)
            skip_reason = (new_rec.get('header_profile') or {}).get('skip_reason') or ''
            if skip_reason:
                skipped_files[filename] = new_rec
                if filename in files:
                    del files[filename]
            else:
                files[filename] = new_rec
                if filename in skipped_files:
                    del skipped_files[filename]
            parsed += 1
            indexed_rows += int(new_rec.get('indexed_row_count') or 0)
            if skip_reason:
                profile_skipped += 1
                if skip_reason == 'action_or_reconciliation_csv':
                    skipped_action_or_reconciliation += 1
            updated = True
        except Exception as exc:
            errors += 1
            try:
                stat_info = os.stat(path)
                mtime = stat_info.st_mtime
                size = stat_info.st_size
            except Exception:
                mtime = 0
                size = 0
            prior = files.get(filename)
            if isinstance(prior, dict) and prior.get('rows'):
                failed_rec = dict(prior)
                failed_rec['mtime'] = mtime
                failed_rec['size'] = size
                failed_rec['parse_failed'] = True
                failed_rec['stale_parse_failed'] = True
                failed_rec['status'] = 'stale_parse_failed'
                failed_rec['parse_error_type'] = exc.__class__.__name__
                failed_rec['parse_error_message'] = _truncate_message(exc)
                failed_rec['parse_failed_at'] = int(time.time())
                failed_rec['updated_at'] = int(time.time())
                files[filename] = failed_rec
                if filename in skipped_files:
                    del skipped_files[filename]
                updated = True
                continue
            files[filename] = {
                'file_basename': filename,
                'basename': filename,
                'path': os.path.abspath(path),
                'mtime': mtime,
                'size': size,
                'row_count': 0,
                'indexed_row_count': 0,
                'header_profile': {},
                'rows': [],
                'parse_failed': True,
                'status': 'parse_failed',
                'parse_error_type': exc.__class__.__name__,
                'parse_error_message': _truncate_message(exc),
                'parse_failed_at': int(time.time()),
                'updated_at': int(time.time()),
            }
            updated = True

    _rebuild_latest_maps(index_data)
    if updated:
        save_csv_metadata_index(local_storage_for_load, index_data)
    stats = {
        'parsed': parsed,
        'skipped': skipped,
        'errors': errors,
        'profile_skipped': profile_skipped,
        'skipped_action_or_reconciliation': skipped_action_or_reconciliation,
        'indexed_rows': indexed_rows,
        'pruned': pruned,
        'updated': bool(updated),
    }
    status_data = _format_status_payload(
        source,
        mode,
        csv_dir_abs,
        requested_file_count,
        max_csv_files,
        force_rebuild,
        started_at,
        stats,
    )
    save_csv_metadata_index_status(local_storage_for_status, status_data)
    return CsvMetadataUpdateResult(index_data, stats, status_data)


def _parse_index_date(value):
    iso, dt = _normalize_date_iso(value)
    return dt


def _target_demog_key_set(target_demog_keys):
    out = set()
    for item in target_demog_keys or []:
        if not isinstance(item, tuple) or len(item) != 2:
            continue
        dob_iso, _dob_dt = _normalize_date_iso(item[0])
        member_id = _safe_text(item[1])
        key = _demog_key(dob_iso, member_id)
        if key:
            out.add(key)
    return out


def get_recent_service_dates_from_index(
        index_data,
        target_patient_ids=None,
        target_demog_keys=None,
        max_age_days=90,
        limit=None):
    if limit is not None:
        dates = {}
        if isinstance(index_data, dict):
            files = index_data.get('files') if isinstance(index_data.get('files'), dict) else {}
            for _filename, file_rec in files.items():
                if not isinstance(file_rec, dict):
                    continue
                for row_rec in file_rec.get('rows') or []:
                    if not isinstance(row_rec, dict):
                        continue
                    iso = _safe_text(row_rec.get('dos_iso'))
                    dt = _parse_index_date(iso)
                    if not dt:
                        continue
                    dates[iso] = dt.strftime('%m/%d/%Y')
        ordered = sorted(dates.keys(), key=_date_sort_value, reverse=True)
        return [dates[k] for k in ordered[:int(limit)]]
    by_pid = {}
    by_demog = {}
    metadata = {
        'index_used': False,
        'files_considered': 0,
        'files_loaded': 0,
        'target_patient_count': 0,
        'target_demog_count': 0,
        'early_stop': False,
        'stale_or_missing': False,
    }
    if not isinstance(index_data, dict):
        metadata['stale_or_missing'] = True
        return by_pid, by_demog, metadata
    latest_by_pid = index_data.get('latest_by_patient_id')
    latest_by_demog = index_data.get('latest_by_demog')
    if not isinstance(latest_by_pid, dict) or not isinstance(latest_by_demog, dict):
        metadata['stale_or_missing'] = True
        return by_pid, by_demog, metadata
    metadata['index_used'] = True
    files = index_data.get('files') if isinstance(index_data.get('files'), dict) else {}
    metadata['files_considered'] = len(files)
    metadata['files_loaded'] = 0
    cutoff = datetime.now() - timedelta(days=max_age_days)
    target_pids = set([_safe_text(v) for v in (target_patient_ids or []) if _safe_text(v)])
    target_demogs = _target_demog_key_set(target_demog_keys)
    metadata['target_patient_count'] = len(target_pids)
    metadata['target_demog_count'] = len(target_demogs)

    for pid, rec in latest_by_pid.items():
        pid_text = _safe_text(pid)
        if target_pids and pid_text not in target_pids:
            continue
        dt = _parse_index_date((rec or {}).get('dos_iso') if isinstance(rec, dict) else '')
        if dt and dt >= cutoff:
            by_pid[pid_text] = dt

    for key, rec in latest_by_demog.items():
        key_text = _safe_text(key)
        if target_demogs and key_text not in target_demogs:
            continue
        dt = _parse_index_date((rec or {}).get('dos_iso') if isinstance(rec, dict) else '')
        if dt and dt >= cutoff:
            parts = key_text.split('|', 1)
            if len(parts) == 2:
                by_demog[(parts[0], parts[1])] = dt

    if target_pids or target_demogs:
        found_pids = set(by_pid.keys())
        found_demogs = set([_demog_key(k[0], k[1]) for k in by_demog.keys()])
        metadata['early_stop'] = bool(
            (not target_pids or target_pids.issubset(found_pids)) and
            (not target_demogs or target_demogs.issubset(found_demogs))
        )
    return by_pid, by_demog, metadata
