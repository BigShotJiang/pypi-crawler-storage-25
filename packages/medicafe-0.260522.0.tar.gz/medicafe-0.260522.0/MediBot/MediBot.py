#MediBot.py
# pyright: reportOptionalMemberAccess=false, reportOptionalCall=false, reportGeneralTypeIssues=false, reportAttributeAccessIssue=false, reportIndexIssue=false, reportUnboundVariable=false
import os, sys  # Must be imported first

if sys.version_info[0] >= 3:
    raw_input = input

# Add parent directory of the project to the Python path
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_dir not in sys.path:
    # Ensure project root is at the front of sys.path to avoid site-packages shadowing
    sys.path.insert(0, project_dir)
else:
    # Ensure it's at the front to avoid site-packages shadowing even if already present
    try:
        if sys.path[0] != project_dir:
            sys.path.remove(project_dir)
            sys.path.insert(0, project_dir)
    except Exception:
        pass

import subprocess, tempfile, traceback, re, time, threading, json, io, hashlib, ctypes
try:
    import msvcrt  # Windows-specific module
except ImportError:
    msvcrt = None  # Not available on non-Windows systems
from collections import OrderedDict
from datetime import datetime # Added for primary surgery date logic
import MediBot_Notepad_Utils  # For generating notepad files
try:
    # Python 3.4.4 on XP does not have typing enhancements; avoid heavy typing usage
    from collections import namedtuple
except Exception:
    namedtuple = None

# Error reporting imports for automated crash reporting
try:
    from MediCafe.error_reporter import capture_unhandled_traceback, submit_support_bundle_email
except ImportError:
    capture_unhandled_traceback = None
    submit_support_bundle_email = None

# ============================================================================
# MINIMAL PROTECTION: Import State Validation
# ============================================================================

def validate_critical_imports():
    """Validate that critical imports are in expected state before proceeding"""
    critical_modules = {
        'MediBot_Preprocessor': None,
        'MediBot_Preprocessor_lib': None,
        'MediBot_UI': None,
        'MediBot_Crosswalk_Library': None
    }
    
    # Test imports and capture state
    try:
        from MediCafe.core_utils import import_medibot_module_with_debug
        
        for module_name in critical_modules.keys():
            try:
                module = import_medibot_module_with_debug(module_name)
                critical_modules[module_name] = module
            except Exception as e:
                print("  ERROR: {} import failed with exception: {}".format(module_name, e))
                critical_modules[module_name] = None
    except Exception as e:
        print("CRITICAL: Failed to import core utilities: {}".format(e))
        return False, critical_modules
    
    # Check for None imports (the specific failure pattern)
    failed_imports = []
    for module_name, module in critical_modules.items():
        if module is None:
            failed_imports.append(module_name)
    
    if failed_imports:
        print("CRITICAL: Import failures detected:")
        for failed in failed_imports:
            print("  - {}: Import returned None".format(failed))
        return False, critical_modules

    total_count = len(critical_modules)
    try:
        MediLink_ConfigLoader.log(
            "Import check: {}/{} critical modules loaded".format(total_count, total_count),
            level="INFO"
        )
    except Exception:
        pass
    return True, critical_modules

# Use core utilities for standardized imports
from MediCafe.core_utils import (
    import_medibot_module_with_debug, 
    get_config_loader_with_fallback,
    get_api_client_factory
)

# Initialize configuration loader with fallback
MediLink_ConfigLoader = get_config_loader_with_fallback()

# Import MediBot modules using centralized import functions with debugging
MediBot_dataformat_library = import_medibot_module_with_debug('MediBot_dataformat_library')
MediBot_Preprocessor = import_medibot_module_with_debug('MediBot_Preprocessor')
MediBot_Preprocessor_lib = import_medibot_module_with_debug('MediBot_Preprocessor_lib')
try:
    from MediBot.MediBot_docx_index import (
        load_docx_schedule_index,
        get_schedules_for_dates,
        normalize_date_value,
        collect_failed_docx_parse_candidates,
    )
except Exception:
    load_docx_schedule_index = None
    get_schedules_for_dates = None
    normalize_date_value = None
    collect_failed_docx_parse_candidates = None
try:
    from MediBot.MediBot_ServiceLineInput import calculate_service_line_amount_result
except Exception:
    try:
        from MediBot_ServiceLineInput import calculate_service_line_amount_result
    except Exception:
        try:
            from MediBot.MediBot_OptionA_Charge import calculate_option_a_charge_result
        except Exception:
            try:
                from MediBot_OptionA_Charge import calculate_option_a_charge_result
            except Exception:
                calculate_option_a_charge_result = None
            calculate_service_line_amount_result = calculate_option_a_charge_result
        else:
            calculate_service_line_amount_result = calculate_option_a_charge_result

calculate_option_a_charge_result = calculate_service_line_amount_result

try:
    from MediCafe import service_line_input_model as ServiceLineInputModel
except Exception:
    ServiceLineInputModel = None

# Import UI components with function extraction
MediBot_UI = import_medibot_module_with_debug('MediBot_UI')
if MediBot_UI:
    app_control = getattr(MediBot_UI, 'app_control', None)
    manage_script_pause = getattr(MediBot_UI, 'manage_script_pause', None)
    user_interaction = getattr(MediBot_UI, 'user_interaction', None)
    get_app_control = getattr(MediBot_UI, '_get_app_control', None)
else:
    app_control = None
    manage_script_pause = None
    user_interaction = None
    get_app_control = None


def _ac():
    if not MediBot_UI:
        return None
    try:
        return get_app_control() if get_app_control else getattr(MediBot_UI, 'app_control', None)
    except Exception:
        return getattr(MediBot_UI, 'app_control', None)


def _run_with_stage_heartbeat(stage_label, work_fn, warn_after_seconds=5.0, heartbeat_seconds=2.0):
    """Run a stage with delayed mandatory heartbeat for long operations.

    Silent for quick stages (< warn_after_seconds). For longer stages, prints
    progress heartbeat until completion.
    """
    started_at = time.time()
    stop_event = threading.Event()
    heartbeat_state = {'started': False}

    def _heartbeat_loop():
        while not stop_event.wait(0.25):
            elapsed = time.time() - started_at
            if elapsed < warn_after_seconds:
                continue
            if not heartbeat_state['started']:
                heartbeat_state['started'] = True
                print("[WORKING] {} (>{:.0f}s)".format(stage_label, warn_after_seconds))
                print("          Still running... elapsed {:.1f}s".format(elapsed))
                continue
            if stop_event.wait(heartbeat_seconds):
                break
            elapsed = time.time() - started_at
            print("          Still running... elapsed {:.1f}s ({})".format(elapsed, stage_label))

    worker = threading.Thread(target=_heartbeat_loop)
    worker.daemon = True
    worker.start()
    try:
        result = work_fn()
    finally:
        stop_event.set()
        try:
            worker.join(0.5)
        except Exception:
            pass
    elapsed = time.time() - started_at
    if heartbeat_state['started']:
        print("[DONE] {} ({:.1f}s)".format(stage_label, elapsed))
    return result

# Import crosswalk library
MediBot_Crosswalk_Library = import_medibot_module_with_debug('MediBot_Crosswalk_Library')
if MediBot_Crosswalk_Library:
    crosswalk_update = getattr(MediBot_Crosswalk_Library, 'crosswalk_update', None)
else:
    crosswalk_update = None

# Initialize API client variables
api_client = None
factory = None

try:
    # Try to get API client factory
    factory = get_api_client_factory()
    if factory:
        api_client = factory.get_shared_client()  # Use shared client for token caching benefits
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log("MediBot using API Factory with shared client", level="INFO")
except ImportError as e:
    # Fallback to basic API client
    try:
        from MediCafe.core_utils import get_api_client
        api_client = get_api_client()
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log("MediBot using fallback API client", level="WARNING")
    except ImportError as e2:
        # Make API client optional - don't log warning for now
        pass

# Buffer for startup warnings/errors so we can re-display them after clearing the console
STARTUP_NOTICES = []

# Flag to track non-normal startup conditions
_non_normal_startup = False

def mark_non_normal_startup():
    """Mark that a non-normal startup condition was detected."""
    global _non_normal_startup
    _non_normal_startup = True

def _record_startup_notice(level, message):
    """Record a startup notice, log it, and print it immediately.
    Stored notices will be reprinted after the screen is cleared.
    """
    try:
        STARTUP_NOTICES.append((level, message))
    except Exception:
        pass
    try:
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(message, level=level)
    except Exception:
        pass
    try:
        print(message)
    except Exception:
        pass

def record_startup_warning(message):
    """Record a startup warning."""
    _record_startup_notice('WARNING', message)
    mark_non_normal_startup()

def record_startup_error(message):
    """Record a startup error."""
    _record_startup_notice('ERROR', message)
    mark_non_normal_startup()

def _preprocessed_csv_has_rows(csv_data):
    """Return True when there is at least one row available for intake."""
    return bool(csv_data)

def _empty_preprocessed_csv_shape_blocked():
    """Return True when empty preprocessing was caused by the intake shape guard."""
    try:
        if MediBot_Preprocessor_lib and hasattr(MediBot_Preprocessor_lib, 'get_last_csv_preprocess_snapshot'):
            snapshot = MediBot_Preprocessor_lib.get_last_csv_preprocess_snapshot()
            return bool(snapshot and snapshot.get('stage') == 'intake_blocked_missing_patient_id_header')
    except Exception:
        pass
    return False

def _handle_empty_preprocessed_csv(csv_data):
    """Report an empty post-filter CSV and tell the caller whether to stop."""
    if _preprocessed_csv_has_rows(csv_data):
        return False

    summary_text = None
    shape_blocker_text = None
    try:
        if MediBot_Preprocessor_lib and hasattr(MediBot_Preprocessor_lib, 'get_last_filter_rows_summary'):
            summary = MediBot_Preprocessor_lib.get_last_filter_rows_summary()
            if summary and hasattr(MediBot_Preprocessor_lib, 'format_filter_rows_summary'):
                summary_text = MediBot_Preprocessor_lib.format_filter_rows_summary(summary)
    except Exception:
        summary_text = None
    try:
        if MediBot_Preprocessor_lib and hasattr(MediBot_Preprocessor_lib, 'get_last_csv_preprocess_snapshot'):
            snapshot = MediBot_Preprocessor_lib.get_last_csv_preprocess_snapshot()
            if snapshot and snapshot.get('stage') == 'intake_blocked_missing_patient_id_header':
                expected = snapshot.get('expected_patient_id_headers') or []
                headers = snapshot.get('cleaned_headers') or []
                shape_blocker_text = (
                    "CSV shape blocker: expected MediBot intake header 'Patient ID' "
                    "(accepted compatibility headers: {0}); "
                    "found headers (first {1}): {2}. "
                ).format(
                    expected,
                    min(len(headers), 12),
                    ", ".join([str(h) for h in headers[:12]]) if headers else "<none>",
                )
    except Exception:
        shape_blocker_text = None

    message = (
        "No eligible patient rows remain after CSV preprocessing. "
        "Rows without Patient ID values and excluded insurance rows "
        "(AETNA, AETNA MEDICARE, HUMANA MED HMO) are skipped. "
        "{}"
        "{}"
        "Please review the source CSV if patients were expected."
    ).format(
        shape_blocker_text or "",
        "Filter summary: {}. ".format(summary_text) if summary_text else ""
    )
    try:
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(message, level="WARNING")
    except Exception:
        pass
    try:
        print(message)
    except Exception:
        pass
    return True

def identify_field(header, field_mapping):
    for medisoft_field, patterns in field_mapping.items():
        for pattern in patterns:
            if re.search(pattern, header, re.IGNORECASE):
                return medisoft_field
    return None

    # Add this print to a function that is calling identify_field
    #print("Warning: No matching field found for CSV header '{}'".format(header))

def create_patient_entries_from_row(row, reverse_mapping):
    """
    Helper function to create patient entries from a row with surgery date handling.
    
    Args:
        row: The CSV row containing patient data
        reverse_mapping: The reverse mapping for field lookups
        
    Returns:
        list: List of tuples (surgery_date, patient_name, patient_id, diagnosis_code, row)
    """
    patient_id = row.get(reverse_mapping['Patient ID #2'])
    patient_name = row.get(reverse_mapping['Patient Name'])
    
    # Get all surgery dates for this patient
    all_surgery_dates = row.get('_all_surgery_dates', [row.get('Surgery Date')])
    surgery_date_to_diagnosis = row.get('_surgery_date_to_diagnosis', {})
    
    patient_entries = []
    
    # Sort surgery dates chronologically to ensure proper ordering
    sorted_surgery_dates = []
    for surgery_date in all_surgery_dates:
        try:
            if hasattr(surgery_date, 'strftime'):
                # Already a datetime object
                sorted_surgery_dates.append(surgery_date)
            elif isinstance(surgery_date, str):
                # Convert string to datetime for sorting
                surgery_date_dt = datetime.strptime(surgery_date, '%m-%d-%Y')
                sorted_surgery_dates.append(surgery_date_dt)
            else:
                # Fallback - use as is
                sorted_surgery_dates.append(surgery_date)
        except (ValueError, TypeError):
            # If parsing fails, use the original value
            sorted_surgery_dates.append(surgery_date)
    
    # Sort the dates chronologically
    sorted_surgery_dates.sort()
    
    # Create entries for each surgery date in chronological order
    # The enhanced table display will group by patient_id and show dashed lines for secondary dates
    for surgery_date in sorted_surgery_dates:
        try:
            if hasattr(surgery_date, 'strftime'):
                surgery_date_str = surgery_date.strftime('%m-%d-%Y')
            elif isinstance(surgery_date, str):
                surgery_date_str = surgery_date
            else:
                surgery_date_str = str(surgery_date)
        except Exception:
            surgery_date_str = str(surgery_date)
        
        # Get the diagnosis code for this surgery date
        diagnosis_code = surgery_date_to_diagnosis.get(surgery_date_str, 'N/A')
        
        # Add entry for this surgery date
        patient_entries.append((surgery_date, patient_name, patient_id, diagnosis_code, row))
    
    return patient_entries


def build_option_a_preview_session_patient_info_from_csv_rows(csv_data, reverse_mapping):
    """
    Build the broad in-memory session scope used by Service Line Input.

    This intentionally runs before Medicare/private and existing/new filters
    narrow the AHK intake path. Service Line Input uses these rows as the
    editable current-session anchor. DOCX data can later enrich diagnosis and
    printed order, but the upstream CSV/preprocessor data does not natively
    own diagnosis codes.
    """
    patient_info = []
    for row in csv_data or []:
        if not isinstance(row, dict):
            continue
        try:
            patient_info.extend(create_patient_entries_from_row(row, reverse_mapping))
        except Exception:
            continue
    return patient_info


def build_service_line_input_session_patient_info_from_csv_rows(csv_data, reverse_mapping):
    return build_option_a_preview_session_patient_info_from_csv_rows(csv_data, reverse_mapping)


def _normalize_option_a_preview_date(value):
    if ServiceLineInputModel is not None:
        try:
            normalized = ServiceLineInputModel.normalize_dos_string(value)
            if normalized:
                return normalized
        except Exception:
            pass
    if normalize_date_value is not None:
        try:
            return normalize_date_value(value)
        except Exception:
            pass
    if value is None:
        return None
    if hasattr(value, 'strftime'):
        try:
            return value.strftime('%m-%d-%Y')
        except Exception:
            return str(value)
    text = str(value).strip()
    if not text:
        return None
    for fmt in ('%m-%d-%Y', '%m/%d/%Y', '%Y-%m-%d', '%Y/%m/%d'):
        try:
            return datetime.strptime(text, fmt).strftime('%m-%d-%Y')
        except Exception:
            pass
    return text


def _option_a_preview_local_storage_path(config):
    try:
        local_storage_path = config.get('MediLink_Config', {}).get('local_storage_path')
    except Exception:
        local_storage_path = None
    if local_storage_path:
        return local_storage_path
    try:
        return config.get('local_storage_path')
    except Exception:
        return None


def _option_a_preview_docx_auto_status(diagnosis):
    text = str(diagnosis or '').strip().lower()
    if text in ('', 'unknown', 'not found', 'not_found', 'not-found'):
        return 'CANCELLED'
    return None


SERVICE_LINE_INPUT_STATE_FILENAME = '.service_line_input_state.json'
SERVICE_LINE_CHARGE_ANCHOR_INDEX_FILENAME = '.service_line_charge_anchor_index.json'
SERVICE_LINE_CHARGE_ANCHOR_INDEX_SCHEMA_VERSION = 'service_line_charge_anchor_index.v1'
SERVICE_LINE_INPUT_STATE_SCHEMA_VERSION = 'service_line_input_state.v1'
SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY = 'preview_only_review_required'
SERVICE_LINE_INPUT_WORKFLOW_NAME = 'service_line_input'
SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS = (
    'claims_completion',
    'mutates_billing_state',
    'mutates_dat',
    'mutates_837p',
    'charges_entered',
)

# SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: keep these constants and wrapper
# helpers through the first release cycle so existing XP sidecars/importers
# remain readable while new code writes `.service_line_input_state.json`.
OPTION_A_MINUTES_STATUS_FILENAME = '.option_a_minutes_status.json'
OPTION_A_MINUTES_STATUS_VERSION = 1


def _option_a_minutes_status_path(local_storage_path):
    if not local_storage_path:
        return None
    return os.path.join(local_storage_path, OPTION_A_MINUTES_STATUS_FILENAME)


def _service_line_input_state_path(local_storage_path):
    if not local_storage_path:
        return None
    return os.path.join(local_storage_path, SERVICE_LINE_INPUT_STATE_FILENAME)


def _service_line_charge_anchor_index_path(local_storage_path):
    if not local_storage_path:
        return None
    return os.path.join(local_storage_path, SERVICE_LINE_CHARGE_ANCHOR_INDEX_FILENAME)


def _option_a_minutes_row_key(patient_id, dos):
    if ServiceLineInputModel is not None:
        try:
            return ServiceLineInputModel.build_legacy_service_line_row_key(patient_id, dos)
        except Exception:
            pass
    return "{0}|{1}".format(str(patient_id or '').strip(), str(dos or '').strip())


def _load_service_line_input_json(path):
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, 'r') as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}
    return data


def _normalize_service_line_input_state(data, source_name=''):
    if not isinstance(data, dict):
        data = {}
    data.setdefault('version', OPTION_A_MINUTES_STATUS_VERSION)
    data.setdefault('schema_version', SERVICE_LINE_INPUT_STATE_SCHEMA_VERSION)
    data.setdefault('workflow_name', SERVICE_LINE_INPUT_WORKFLOW_NAME)
    if source_name:
        data.setdefault('state_source', source_name)
    data.setdefault('version', OPTION_A_MINUTES_STATUS_VERSION)
    if not isinstance(data.get('rows'), dict):
        data['rows'] = {}
    if not isinstance(data.get('sessions'), dict):
        data['sessions'] = {}
    if not isinstance(data.get('events'), list):
        data['events'] = []
    return data


def _load_service_line_input_state(local_storage_path):
    new_path = _service_line_input_state_path(local_storage_path)
    legacy_path = _option_a_minutes_status_path(local_storage_path)
    data = _load_service_line_input_json(new_path)
    if data is not None:
        return _normalize_service_line_input_state(data, 'service_line_input')
    data = _load_service_line_input_json(legacy_path)
    if data is not None:
        data = _normalize_service_line_input_state(data, 'legacy_option_a')
        data.setdefault('legacy_option_a_state_path', legacy_path)
        return data
    return _normalize_service_line_input_state({}, 'new_empty')


def _load_option_a_minutes_status(local_storage_path):
    return _load_service_line_input_state(local_storage_path)


def _load_service_line_charge_anchor_index(local_storage_path):
    path = _service_line_charge_anchor_index_path(local_storage_path)
    data = _load_service_line_input_json(path)
    if not isinstance(data, dict):
        data = {}
    if data.get('schema_version') != SERVICE_LINE_CHARGE_ANCHOR_INDEX_SCHEMA_VERSION:
        if not data.get('anchors'):
            data = {}
    anchors = data.get('anchors')
    if not isinstance(anchors, list):
        data['anchors'] = []
    data.setdefault('workflow_name', SERVICE_LINE_INPUT_WORKFLOW_NAME)
    data.setdefault('workflow_boundary', 'report_only_review_required')
    return data


def _write_service_line_input_json(path, data, schema_version=None):
    if not path:
        return False
    parent = os.path.dirname(path)
    try:
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
    except Exception:
        pass
    data = dict(data or {})
    data['version'] = OPTION_A_MINUTES_STATUS_VERSION
    if schema_version:
        data['schema_version'] = schema_version
        data['workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    data['updated_at_epoch'] = int(time.time())
    tmp_path = path + '.tmp'
    try:
        with open(tmp_path, 'w') as handle:
            json.dump(data, handle, indent=2, sort_keys=True)
        attempts = 0
        while attempts < 3:
            attempts += 1
            try:
                if os.path.exists(path):
                    os.remove(path)
                os.rename(tmp_path, path)
                return True
            except Exception:
                if attempts < 3:
                    time.sleep(0.05 * attempts)
        return False
    except Exception:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
    return False


def _write_service_line_input_state(local_storage_path, data):
    new_path = _service_line_input_state_path(local_storage_path)
    legacy_path = _option_a_minutes_status_path(local_storage_path)
    new_ok = _write_service_line_input_json(
        new_path,
        data,
        schema_version=SERVICE_LINE_INPUT_STATE_SCHEMA_VERSION,
    )
    legacy_ok = _write_service_line_input_json(legacy_path, data)
    return bool(new_ok or legacy_ok)


def _write_option_a_minutes_status(local_storage_path, data):
    return _write_service_line_input_state(local_storage_path, data)


def _service_line_input_reports_dir(local_storage_path):
    if not local_storage_path:
        return None
    return os.path.join(local_storage_path, 'reports')


def _service_line_input_safe_name(value):
    text = str(value or '').strip()
    out = []
    for ch in text:
        if ch.isalnum() or ch in ('-', '_'):
            out.append(ch)
        else:
            out.append('_')
    safe = ''.join(out).strip('_')
    return safe or 'service_line_input'


def _write_service_line_input_artifact_json(path, payload):
    if not path:
        return ''
    parent = os.path.dirname(path)
    try:
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
    except Exception:
        pass
    try:
        with io.open(path, 'w', encoding='utf-8') as handle:
            handle.write(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True))
            handle.write('\n')
        return path
    except Exception:
        return ''


def _write_service_line_input_artifact_text(path, text):
    if not path:
        return ''
    parent = os.path.dirname(path)
    try:
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
    except Exception:
        pass
    try:
        with io.open(path, 'w', encoding='utf-8') as handle:
            handle.write(str(text or ''))
        return path
    except Exception:
        return ''


def _service_line_input_cleanup_marker_rows():
    return [
        {
            'marker': 'SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP',
            'surface': 'runtime compatibility wrappers and legacy imports',
            'cleanup_condition': 'remove after release-cycle validation proves service_line_input entrypoints and sidecar keys are sufficient',
        },
        {
            'marker': OPTION_A_MINUTES_STATUS_FILENAME,
            'surface': 'legacy local sidecar mirror',
            'cleanup_condition': 'remove after XP deployments no longer read legacy Option A status files',
        },
        {
            'marker': 'run_option_a_minutes_entry_preview',
            'surface': 'legacy UI entrypoint',
            'cleanup_condition': 'remove after callers and tests use run_service_line_input_entry only',
        },
        {
            'marker': 'run_option_a_multi_dos_minutes_preview',
            'surface': 'legacy controller entrypoint',
            'cleanup_condition': 'remove after callers and tests use run_service_line_input_multi_dos_entry only',
        },
    ]


def _build_service_line_input_cleanup_readiness():
    if ServiceLineInputModel is not None:
        try:
            return ServiceLineInputModel.build_service_line_cleanup_readiness_report(
                _service_line_input_cleanup_marker_rows(),
                release_cycle_complete=False,
            )
        except Exception:
            pass
    return {
        'schema_version': 'service_line_input_cleanup_readiness.v1',
        'workflow_name': SERVICE_LINE_INPUT_WORKFLOW_NAME,
        'workflow_boundary': SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        'cleanup_readiness': 'not_ready',
        'legacy_marker_count': len(_service_line_input_cleanup_marker_rows()),
        'legacy_markers': _service_line_input_cleanup_marker_rows(),
        'blockers': ['release_cycle_validation_not_confirmed', 'legacy_option_a_markers_present'],
        'claims_completion': False,
        'mutates_billing_state': False,
        'mutates_dat': False,
        'mutates_837p': False,
        'charges_entered': False,
    }


def _write_service_line_input_review_artifacts(local_storage_path, session_id, completed_rows, review_completion):
    if not local_storage_path:
        return {}
    reports_dir = _service_line_input_reports_dir(local_storage_path)
    if not reports_dir:
        return {}
    safe_session = _service_line_input_safe_name(session_id)
    cleanup_readiness = _build_service_line_input_cleanup_readiness()
    package = None
    if ServiceLineInputModel is not None:
        try:
            package = ServiceLineInputModel.build_service_line_candidate_package(
                session_id,
                completed_rows,
            )
        except Exception:
            package = None
    if not isinstance(package, dict):
        package = {
            'schema_version': 'service_line_input_candidate_package.v1',
            'workflow_name': SERVICE_LINE_INPUT_WORKFLOW_NAME,
            'workflow_boundary': SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
            'service_line_input_session_id': session_id,
            'row_count': len(completed_rows or []),
            'candidate_rows': completed_rows or [],
            'review_completion': review_completion or {},
            'claims_completion': False,
            'mutates_billing_state': False,
            'mutates_dat': False,
            'mutates_837p': False,
            'charges_entered': False,
        }
    package['cleanup_readiness'] = cleanup_readiness
    package['review_completion'] = package.get('review_completion') or review_completion or {}
    package['claims_completion'] = False
    package['mutates_billing_state'] = False
    package['mutates_dat'] = False
    package['mutates_837p'] = False
    package['charges_entered'] = False
    json_path = os.path.join(reports_dir, 'service_line_input_candidate_{0}.json'.format(safe_session))
    txt_path = os.path.join(reports_dir, 'service_line_input_candidate_{0}.txt'.format(safe_session))
    written_json = _write_service_line_input_artifact_json(json_path, package)
    if ServiceLineInputModel is not None:
        try:
            text = ServiceLineInputModel.format_service_line_candidate_report_text(package)
        except Exception:
            text = ''
    else:
        text = ''
    if not text:
        text = 'Service Line Input Review Summary\nSession: {0}\nworkflow_boundary={1}\nclaims_completion=False\n'.format(
            session_id,
            SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        )
    written_txt = _write_service_line_input_artifact_text(txt_path, text)
    return {
        'candidate_json': written_json,
        'candidate_txt': written_txt,
        'cleanup_readiness': cleanup_readiness,
        'package': package,
    }


def _print_service_line_input_review_summary(review_completion, artifact_paths):
    review_completion = review_completion if isinstance(review_completion, dict) else {}
    print("\nService Line Input Review Summary")
    print("Rows: {0} | entered={1} skipped={2} cancelled={3} pending={4} invalid={5}".format(
        review_completion.get('row_count', 0),
        review_completion.get('entered', 0),
        review_completion.get('skipped', 0),
        review_completion.get('cancelled', 0),
        review_completion.get('pending', 0),
        review_completion.get('invalid', 0),
    ))
    print("Review complete: {0}".format(bool(review_completion.get('service_line_input_review_complete'))))
    txt_path = ''
    if isinstance(artifact_paths, dict):
        txt_path = artifact_paths.get('candidate_txt') or ''
    if txt_path:
        print("Review report: {0}".format(txt_path))
    print("Boundary: preview_only_review_required; no DAT/837P/Medisoft charge-entry mutation.")


def _new_service_line_input_session_id():
    return "service_line_input_{0}_{1}".format(int(time.time()), os.getpid())


def _new_option_a_session_id():
    # SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: legacy wrapper.
    return _new_service_line_input_session_id()


def _option_a_status_to_sidecar(status):
    text = str(status or '').strip().upper()
    if text == 'ENTERED':
        return 'entered'
    if text == 'SKIPPED':
        return 'skipped'
    if text == 'CANCELLED':
        return 'cancelled'
    return ''


def _option_a_bool_value(value):
    if isinstance(value, bool):
        return value
    text = str(value or '').strip().lower()
    if text in ('1', 'true', 'yes', 'y', 'on'):
        return True
    return False


def _sidecar_status_to_preview(status):
    text = str(status or '').strip().lower()
    if text == 'entered':
        return 'ENTERED'
    if text == 'skipped':
        return 'SKIPPED'
    if text == 'cancelled':
        return 'CANCELLED'
    return ''


def _set_service_line_input_payload(row_payload, service_key, legacy_key, value):
    row_payload[service_key] = value
    row_payload[legacy_key] = value


def _set_service_line_input_false_boundary_flags(row_payload):
    for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
        row_payload[false_key] = False
        row_payload['_service_line_input_{0}'.format(false_key)] = False
        row_payload['_option_a_preview_{0}'.format(false_key)] = False
    row_payload['workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    row_payload['_service_line_input_workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    row_payload['_option_a_preview_workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
    row_payload['workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
    row_payload['_service_line_input_workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
    row_payload['_option_a_preview_workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY


def _service_line_input_visible_charge_note(row):
    if not isinstance(row, dict):
        return ''
    note = str(row.get('charge_note') or '').strip()
    rule_id = str(row.get('charge_rule_id') or '').strip().lower()
    source = str(row.get('charge_source') or '').strip().lower()
    if note.lower().startswith('baseline ') or rule_id.startswith('baseline_') or source == 'baseline_minutes_tier':
        return ''
    return note


def _normalize_service_line_input_code(value):
    if ServiceLineInputModel is not None:
        try:
            return ServiceLineInputModel.normalize_service_line_code(value)
        except Exception:
            pass
    out = []
    for ch in str(value or '').upper():
        if ch.isalnum():
            out.append(ch)
    return ''.join(out)


def _service_line_input_cpt_suggestion(crosswalk, diagnosis):
    if ServiceLineInputModel is not None:
        try:
            return ServiceLineInputModel.predict_cpt_from_crosswalk(crosswalk, diagnosis)
        except Exception:
            pass
    if not isinstance(crosswalk, dict):
        return {}
    diagnosis_norm = _normalize_service_line_input_code(diagnosis)
    if not diagnosis_norm:
        return {}
    candidates = [diagnosis_norm]
    medisoft = crosswalk.get('diagnosis_to_medisoft')
    if isinstance(medisoft, dict):
        shorthand_matches = []
        for source_dx, mapped_dx in medisoft.items():
            source_norm = _normalize_service_line_input_code(source_dx)
            mapped_norm = _normalize_service_line_input_code(mapped_dx)
            if diagnosis_norm == source_norm and mapped_norm:
                candidates.append(mapped_norm)
            if diagnosis_norm == mapped_norm and source_norm:
                if source_norm not in shorthand_matches:
                    shorthand_matches.append(source_norm)
                candidates.append(source_norm)
        if len(shorthand_matches) > 1:
            return {}
    dx_to_proc = crosswalk.get('diagnosis_to_procedure')
    if not isinstance(dx_to_proc, dict):
        return {}
    for key, cpt in dx_to_proc.items():
        key_norm = _normalize_service_line_input_code(key)
        if key_norm in candidates:
            cpt_norm = _normalize_service_line_input_code(cpt)
            if cpt_norm:
                return {
                    'cpt': cpt_norm,
                    'cpt_source': 'crosswalk.diagnosis_to_procedure',
                    'cpt_confidence': 'crosswalk_confirmed',
                    'cpt_status': 'suggested',
                    'diagnosis_code': str(key or ''),
                }
    return {}


def _service_line_input_diagnosis_display_value(value):
    text = str(value or '').strip().upper()
    normalized = _normalize_service_line_input_code(text)
    if normalized and len(normalized) > 3 and normalized[0].isalpha():
        return "{0}.{1}".format(normalized[:3], normalized[3:])
    return text


def _service_line_input_amount_calculator_with_cpt(crosswalk, base_calculator):
    calculator = base_calculator or calculate_service_line_amount_result

    def calculate(context):
        ctx = dict(context or {})
        suggestion = {}
        if not ctx.get('cpt'):
            suggestion = _service_line_input_cpt_suggestion(crosswalk, ctx.get('diagnosis'))
            if suggestion.get('cpt'):
                ctx['cpt'] = suggestion.get('cpt')
        result = calculator(ctx) if calculator is not None else {}
        if not isinstance(result, dict):
            result = {}
        if suggestion.get('cpt'):
            result.setdefault('cpt', suggestion.get('cpt'))
            result['cpt_source'] = suggestion.get('cpt_source')
            result['cpt_confidence'] = suggestion.get('cpt_confidence')
            result['cpt_status'] = suggestion.get('cpt_status')
        result['workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
        result['workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
        for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
            result[false_key] = False
        return result

    return calculate


def _service_line_input_option_sets_from_crosswalk(crosswalk):
    diagnosis_options = []
    cpt_options = []
    diagnosis_display_map = {}

    def add_value(target, value):
        text = str(value or '').strip().upper()
        if text and text not in target:
            target.append(text)

    def add_display_mapping(raw_value, display_value):
        normalized = _normalize_service_line_input_code(raw_value)
        display = _service_line_input_diagnosis_display_value(display_value)
        if normalized and display:
            diagnosis_display_map[normalized] = display

    if not isinstance(crosswalk, dict):
        return {
            'diagnosis_options': diagnosis_options,
            'cpt_options': cpt_options,
            'diagnosis_display_map': diagnosis_display_map,
        }

    dx_to_proc = crosswalk.get('diagnosis_to_procedure')
    if isinstance(dx_to_proc, dict):
        for diagnosis, cpt in dx_to_proc.items():
            add_value(diagnosis_options, diagnosis)
            add_display_mapping(diagnosis, diagnosis)
            add_value(cpt_options, cpt)

    proc_to_dx = crosswalk.get('procedure_to_diagnosis')
    if isinstance(proc_to_dx, dict):
        for cpt, diagnoses in proc_to_dx.items():
            add_value(cpt_options, cpt)
            if isinstance(diagnoses, (list, tuple)):
                for diagnosis in diagnoses:
                    add_value(diagnosis_options, diagnosis)
                    add_display_mapping(diagnosis, diagnosis)
            else:
                add_value(diagnosis_options, diagnoses)
                add_display_mapping(diagnoses, diagnoses)

    medisoft = crosswalk.get('diagnosis_to_medisoft')
    if isinstance(medisoft, dict):
        medisoft_reverse = {}
        for source_dx, mapped_dx in medisoft.items():
            add_value(diagnosis_options, source_dx)
            add_value(diagnosis_options, mapped_dx)
            source_display = _service_line_input_diagnosis_display_value(source_dx)
            source_norm = _normalize_service_line_input_code(source_dx)
            mapped_norm = _normalize_service_line_input_code(mapped_dx)
            if source_norm:
                add_display_mapping(source_norm, source_display)
            if mapped_norm and source_display:
                medisoft_reverse.setdefault(mapped_norm, []).append(source_display)
        for mapped_norm, displays in medisoft_reverse.items():
            unique = []
            for display in displays:
                if _normalize_service_line_input_code(display) not in [
                        _normalize_service_line_input_code(item) for item in unique]:
                    unique.append(display)
            if len(unique) == 1:
                add_display_mapping(mapped_norm, unique[0])

    diagnosis_options.sort()
    cpt_options.sort()
    return {
        'diagnosis_options': diagnosis_options,
        'cpt_options': cpt_options,
        'diagnosis_display_map': diagnosis_display_map,
    }


def _service_line_input_prompt_required(prompt, default_value=''):
    default_text = str(default_value or '').strip()
    if default_text:
        raw = input("{0} [{1}]: ".format(prompt, default_text))
        value = str(raw or '').strip()
        if not value:
            return default_text
        return value
    return str(input("{0}: ".format(prompt)) or '').strip()


def _service_line_input_build_unknown_code_values(row, field_name, value, crosswalk):
    typed = str(value or '').strip().upper()
    current_dx = str(row.get('diagnosis') or row.get('diagnosis_code') or '').strip().upper()
    current_cpt = str(row.get('cpt') or row.get('cpt_code') or '').strip().upper()
    diagnosis = ''
    medisoft = ''
    cpt = ''
    if field_name == 'diagnosis':
        typed_norm = _normalize_service_line_input_code(typed)
        if typed_norm and typed_norm[0].isalpha():
            diagnosis = _service_line_input_diagnosis_display_value(typed)
            if ServiceLineInputModel is not None:
                try:
                    medisoft = ServiceLineInputModel.suggest_medisoft_shorthand_for_diagnosis(diagnosis)
                except Exception:
                    medisoft = ''
        else:
            medisoft = typed_norm
        cpt = current_cpt
    elif field_name == 'cpt':
        cpt = _normalize_service_line_input_code(typed)
        diagnosis = current_dx if current_dx and current_dx != '-NOT FOUND-' else ''
        if ServiceLineInputModel is not None:
            try:
                diagnosis = ServiceLineInputModel.resolve_diagnosis_display_from_crosswalk(crosswalk, diagnosis)
                if not ServiceLineInputModel.diagnosis_code_is_icd_like(diagnosis):
                    diagnosis = ''
            except Exception:
                pass
        if ServiceLineInputModel is not None:
            try:
                medisoft = ServiceLineInputModel.suggest_medisoft_shorthand_for_diagnosis(diagnosis)
            except Exception:
                medisoft = ''
    return diagnosis, medisoft, cpt


def _service_line_input_intake_conflict_message(conflict):
    if not isinstance(conflict, dict):
        return str(conflict)
    reason = str(conflict.get('reason') or '').strip()
    key = str(conflict.get('key') or '').strip()
    existing_key = str(conflict.get('existing_key') or '').strip()
    existing_value = str(conflict.get('existing_value') or '').strip()
    proposed_key = str(conflict.get('proposed_key') or '').strip()
    proposed_value = str(conflict.get('proposed_value') or '').strip()
    if reason == 'medisoft_shorthand_already_points_to_different_diagnosis':
        return (
            "Medisoft shorthand {0} is already mapped to {1}; row unchanged "
            "(medisoft_shorthand_already_points_to_different_diagnosis)."
        ).format(proposed_value or existing_value or 'that code', existing_key or 'another diagnosis')
    if key == 'diagnosis_to_procedure':
        return (
            "Diagnosis {0} already points to CPT {1}; row unchanged "
            "(diagnosis_to_procedure_conflict)."
        ).format(existing_key or proposed_key or 'this diagnosis', existing_value or 'another CPT')
    if key == 'diagnosis_to_medisoft':
        return (
            "Diagnosis {0} already has Medisoft shorthand {1}; row unchanged "
            "(diagnosis_to_medisoft_conflict)."
        ).format(existing_key or proposed_key or 'this diagnosis', existing_value or 'another value')
    return str(reason or key or 'crosswalk_conflict')


def _service_line_input_intake_problem_messages(errors=None, conflicts=None):
    messages = []
    for error in errors or []:
        code = str(error or '').strip()
        if code == 'diagnosis_code_must_be_full_icd10_like':
            messages.append(
                "Use the full ICD-10 diagnosis code, for example H25.812 "
                "(diagnosis_code_must_be_full_icd10_like)."
            )
        elif code == 'medisoft_shorthand_required':
            messages.append("Medisoft shorthand is required for the bridge (medisoft_shorthand_required).")
        elif code == 'cpt_code_must_be_5_alphanumeric_characters':
            messages.append("Use a 5-character CPT/procedure code such as 00142 (cpt_code_must_be_5_alphanumeric_characters).")
        elif code:
            messages.append(code)
    for conflict in conflicts or []:
        messages.append(_service_line_input_intake_conflict_message(conflict))
    return messages


def _service_line_input_intake_save_failure_message(apply_report):
    report = apply_report if isinstance(apply_report, dict) else {}
    save_error = str(report.get('save_error') or report.get('error') or '').strip()
    messages = _service_line_input_intake_problem_messages(
        report.get('revalidation_errors') or [],
        report.get('revalidation_conflicts') or [],
    )
    if save_error == 'service_line_crosswalk_intake_patch_revalidation_failed':
        lead = "Crosswalk changed while saving; row unchanged. Reopen the row and try again."
        if messages:
            lead = lead + " " + " ".join(messages)
        return lead + " ({0})".format(save_error)
    if save_error == 'save_crosswalk_returned_false':
        return "Crosswalk file could not be saved; row unchanged (save_crosswalk_returned_false)."
    if save_error == 'save_failed':
        return "Crosswalk save raised an error; row unchanged (save_failed)."
    if save_error == 'invalid_service_line_crosswalk_intake_boundary':
        return "Crosswalk update was rejected because it was not a config-update patch; row unchanged."
    if save_error == 'service_line_crosswalk_intake_patch_not_valid':
        return "Crosswalk update was rejected because the mapping was not valid; row unchanged."
    if save_error:
        return "Crosswalk intake not saved: {0}; row unchanged.".format(save_error)
    return "Crosswalk save failed; row unchanged."


def _service_line_input_crosswalk_intake_handler(config, crosswalk, option_sets):
    def handle(row, field_name, value):
        if ServiceLineInputModel is None:
            return {'ok': False, 'message': 'Crosswalk intake helper unavailable; row unchanged.'}
        print("\nNew Service Line Input code")
        print("This can update crosswalk config only; it does not enter charges, write DAT, or create 837P files.")
        diagnosis, medisoft, cpt = _service_line_input_build_unknown_code_values(
            row,
            field_name,
            value,
            crosswalk,
        )
        if not diagnosis:
            diagnosis = _service_line_input_prompt_required("Full ICD-10 diagnosis code")
        if not medisoft:
            try:
                medisoft = ServiceLineInputModel.suggest_medisoft_shorthand_for_diagnosis(diagnosis)
            except Exception:
                medisoft = ''
        medisoft = _service_line_input_prompt_required("Medisoft shorthand", medisoft)
        if not cpt:
            cpt = _service_line_input_prompt_required("CPT code")
        source = {
            'field_name': field_name,
            'typed_value': str(value or '').strip(),
            'patient_id': row.get('patient_id') or '',
            'dos': row.get('date') or '',
        }
        patch = ServiceLineInputModel.build_service_line_crosswalk_intake_patch(
            crosswalk,
            diagnosis,
            medisoft,
            cpt,
            source=source,
        )
        if not patch.get('valid'):
            problems = _service_line_input_intake_problem_messages(
                patch.get('errors') or [],
                patch.get('conflicts') or [],
            )
            try:
                MediLink_ConfigLoader.log(
                    "Service Line Input crosswalk intake rejected: {0}".format(
                        ', '.join(problems) or 'invalid mapping',
                    ),
                    config if isinstance(config, dict) else None,
                    level="WARNING",
                )
            except Exception:
                pass
            return {
                'ok': False,
                'message': 'Crosswalk intake not saved: {0}'.format(', '.join(problems) or 'invalid mapping'),
            }
        print("\nConfirm crosswalk update:")
        print("  Diagnosis: {0}".format(patch.get('diagnosis_code')))
        print("  Medisoft shorthand: {0}".format(patch.get('medisoft_code')))
        print("  CPT: {0}".format(patch.get('cpt_code')))
        print("  Updates: diagnosis_to_medisoft, diagnosis_to_procedure, procedure_to_diagnosis")
        choice = (input("Save this crosswalk update? [y/N]: ") or '').strip().lower()
        if choice not in ('y', 'yes'):
            return {'ok': False, 'message': 'Crosswalk update cancelled; row unchanged.'}
        save_ok = False
        apply_report = {}
        merged = crosswalk
        try:
            from MediBot.MediBot_Crosswalk_Utils import save_service_line_input_crosswalk_intake_patch
            merged, apply_report = save_service_line_input_crosswalk_intake_patch(
                config if isinstance(config, dict) else {},
                crosswalk,
                patch,
                row_target_identity={
                    'patient_id': row.get('patient_id') or source.get('patient_id') or '',
                    'dos': row.get('date') or source.get('dos') or '',
                },
            )
            save_ok = bool(apply_report.get('save_ok'))
        except Exception as exc:
            apply_report['error'] = 'save_failed:{0}'.format(str(exc)[:120])
            apply_report['save_error'] = 'save_failed'
            save_ok = False
        message = (
            'Crosswalk updated; Service Line Input row updated.'
            if save_ok else
            _service_line_input_intake_save_failure_message(apply_report)
        )
        if not save_ok and apply_report.get('save_error'):
            message = _service_line_input_intake_save_failure_message(apply_report)
        try:
            MediLink_ConfigLoader.log(
                "Service Line Input crosswalk intake {0}: diagnosis={1} medisoft={2} cpt={3}".format(
                    'saved' if save_ok else 'save_failed',
                    patch.get('diagnosis_code') or '',
                    patch.get('medisoft_code') or '',
                    patch.get('cpt_code') or '',
                ),
                config if isinstance(config, dict) else None,
                level="INFO" if save_ok else "WARNING",
            )
        except Exception:
            pass
        event = ServiceLineInputModel.build_service_line_crosswalk_intake_event(
            row,
            patch,
            apply_report=apply_report,
            save_ok=save_ok,
            message=message,
        )
        if not save_ok:
            return {
                'ok': False,
                'message': message,
                'crosswalk_intake_events': [event],
            }
        try:
            if isinstance(merged, dict) and merged is not crosswalk:
                crosswalk.clear()
                crosswalk.update(merged)
        except Exception:
            pass
        try:
            refreshed = _service_line_input_option_sets_from_crosswalk(crosswalk)
            option_sets.clear()
            option_sets.update(refreshed)
            option_sets['crosswalk_intake_handler'] = handle
        except Exception:
            pass
        return {
            'ok': True,
            'message': message,
            'row_updates': {
                'diagnosis': patch.get('diagnosis_code'),
                'diagnosis_code': patch.get('diagnosis_code'),
                'diagnosis_raw_value': (
                    str(value or '').strip().upper()
                    if field_name == 'diagnosis'
                    else patch.get('diagnosis_code')
                ),
                'diagnosis_source': 'operator_crosswalk_intake',
                'cpt': patch.get('cpt_code'),
                'cpt_code': patch.get('cpt_code'),
                'cpt_source': 'operator_crosswalk_intake',
                'cpt_confidence': 'operator_confirmed',
                'cpt_status': 'operator_corrected',
                'validation_status': 'review_required',
                'validation_note': 'crosswalk intake confirmed',
                'crosswalk_intake_save_ok': True,
                'crosswalk_intake_message': message,
            },
            'crosswalk_intake_events': [event],
        }
    return handle


def _run_service_line_input_ui_entry(entries, dos, charge_calculator, option_sets):
    try:
        return MediBot_UI.run_service_line_input_entry(
            entries,
            date_of_service_label=dos,
            charge_calculator=charge_calculator,
            diagnosis_options=option_sets.get('diagnosis_options') or [],
            cpt_options=option_sets.get('cpt_options') or [],
            diagnosis_display_map=option_sets.get('diagnosis_display_map') or {},
            crosswalk_intake_handler=option_sets.get('crosswalk_intake_handler'),
        )
    except TypeError:
        return MediBot_UI.run_service_line_input_entry(
            entries,
            date_of_service_label=dos,
            charge_calculator=charge_calculator,
        )


def _option_a_preview_fallback_name(patient_id):
    patient_id_text = str(patient_id or '').strip()
    if patient_id_text:
        return "Patient ID {0}".format(patient_id_text)
    return "Unknown Patient"


def _log_option_a_missing_upstream_name(patient_id, dos):
    try:
        MediLink_ConfigLoader.log(
            "Service Line Input DOCX row has no matching preprocessed patient name; using ID fallback. patient_id={} dos={}".format(
                str(patient_id or '').strip() or 'UNKNOWN',
                str(dos or '').strip() or 'UNKNOWN',
            ),
            level="WARNING",
        )
    except Exception:
        pass


def _log_service_line_input_docx_only_observation(patient_id, dos):
    try:
        MediLink_ConfigLoader.log(
            "Service Line Input DOCX row is outside the current CSV session; keeping it as a read-only observation. patient_id={} dos={}".format(
                str(patient_id or '').strip() or 'UNKNOWN',
                str(dos or '').strip() or 'UNKNOWN',
            ),
            level="INFO",
        )
    except Exception:
        pass


def _service_line_input_dos_sort_value(value):
    normalized = _normalize_option_a_preview_date(value) or str(value or '').strip()
    try:
        return int(datetime.strptime(normalized, '%m-%d-%Y').strftime('%Y%m%d'))
    except Exception:
        return 0


def _service_line_input_is_earlier_dos(source_dos, target_dos):
    source_value = _service_line_input_dos_sort_value(source_dos)
    target_value = _service_line_input_dos_sort_value(target_dos)
    return bool(source_value and target_value and source_value < target_value)


def _service_line_input_amount_rank(value):
    text = str(value or '').strip().replace('$', '').replace(',', '')
    if not text:
        return 0
    try:
        return int(float(text) * 100)
    except Exception:
        return 0


def _service_line_input_anchor_candidate(source, patient_id, dos):
    if not isinstance(source, dict):
        return {}
    patient_id_text = str(patient_id or '').strip()
    target_dos = _normalize_option_a_preview_date(dos) or str(dos or '').strip()
    row_patient = str(
        source.get('patient_id')
        or source.get('target_patient_id')
        or source.get('patid')
        or ''
    ).strip()
    row_dos = _normalize_option_a_preview_date(
        source.get('anchor_source_dos')
        or source.get('source_dos')
        or source.get('dos')
    ) or str(source.get('anchor_source_dos') or source.get('source_dos') or source.get('dos') or '').strip()
    if row_patient != patient_id_text:
        return {}
    if not _service_line_input_is_earlier_dos(row_dos, target_dos):
        return {}
    if str(source.get('status') or 'entered').strip().lower() not in ('entered', 'complete', 'completed', ''):
        return {}
    boundary = str(source.get('workflow_boundary') or SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY).strip()
    if boundary not in (SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY, 'report_only_review_required'):
        return {}
    if bool(source.get('claims_completion') or source.get('mutates_billing_state') or
            source.get('mutates_dat') or source.get('mutates_837p') or source.get('charges_entered')):
        return {}
    amount_text = str(source.get('charge_amount') or source.get('amount') or '').strip()
    display_text = str(source.get('charge_display') or '').strip()
    if not amount_text and display_text:
        amount_text = display_text.replace('$', '').replace(',', '').strip()
    if not amount_text and not display_text:
        return {}
    if not display_text and amount_text:
        display_text = '${0}'.format(int(float(amount_text))) if _service_line_input_amount_rank(amount_text) else ''
    note = (
        source.get('same_patient_anchor_charge_note')
        or source.get('charge_note')
        or 'same-patient DOS anchor from {0}'.format(row_dos or 'prior DOS')
    )
    return {
        'same_patient_anchor_charge_amount': amount_text,
        'same_patient_anchor_charge_display': display_text,
        'same_patient_anchor_charge_rule_id': (
            source.get('same_patient_anchor_charge_rule_id')
            or source.get('charge_rule_id')
            or 'same_patient_dos_anchor'
        ),
        'same_patient_anchor_charge_note': str(note or '').strip(),
        'same_patient_anchor_source_dos': row_dos,
        'same_patient_anchor_source': str(source.get('anchor_source') or source.get('charge_source') or 'service_line_input_state').strip(),
        'same_patient_anchor_confidence': str(source.get('confidence') or '').strip(),
    }


def _service_line_input_better_anchor(candidate, current):
    if not current:
        return True
    candidate_source = candidate.get('same_patient_anchor_source') or ''
    current_source = current.get('same_patient_anchor_source') or ''
    source_rank = {
        'dat': 0,
        'saved_837p': 1,
        'service_line_input_state': 2,
        'current_session': 2,
        'csv_session': 2,
    }
    cand_rank = source_rank.get(candidate_source, 3)
    curr_rank = source_rank.get(current_source, 3)
    if cand_rank != curr_rank:
        return cand_rank < curr_rank
    cand_dos = _service_line_input_dos_sort_value(candidate.get('same_patient_anchor_source_dos'))
    curr_dos = _service_line_input_dos_sort_value(current.get('same_patient_anchor_source_dos'))
    if cand_dos != curr_dos:
        return cand_dos > curr_dos
    cand_amount = _service_line_input_amount_rank(candidate.get('same_patient_anchor_charge_amount'))
    curr_amount = _service_line_input_amount_rank(current.get('same_patient_anchor_charge_amount'))
    return cand_amount > curr_amount


def _service_line_input_summary_rows_as_status(completed_rows):
    out = {}
    for row in completed_rows or []:
        if not isinstance(row, dict):
            continue
        patient_id = str(row.get('patient_id') or '').strip()
        dos = _normalize_option_a_preview_date(row.get('date') or row.get('dos')) or str(row.get('date') or row.get('dos') or '').strip()
        if not patient_id or not dos:
            continue
        key = _option_a_minutes_row_key(patient_id, dos)
        copy = dict(row)
        copy['patient_id'] = patient_id
        copy['dos'] = dos
        copy.setdefault('workflow_boundary', SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY)
        copy.setdefault('anchor_source', 'current_session')
        out[key] = copy
    return out


def _service_line_input_same_patient_anchor(status_rows, patient_id, dos,
                                            historical_anchor_rows=None,
                                            completed_rows=None):
    patient_id_text = str(patient_id or '').strip()
    dos_text = _normalize_option_a_preview_date(dos) or str(dos or '').strip()
    if not patient_id_text:
        return {}
    best = {}
    merged_status = {}
    if isinstance(status_rows, dict):
        merged_status.update(status_rows)
    merged_status.update(_service_line_input_summary_rows_as_status(completed_rows))
    for _row_key, row in merged_status.items():
        candidate = _service_line_input_anchor_candidate(row, patient_id_text, dos_text)
        if candidate:
            if str(row.get('workflow_boundary') or '').strip() == SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY:
                candidate['same_patient_anchor_source'] = 'service_line_input_state'
            else:
                candidate['same_patient_anchor_source'] = str(row.get('anchor_source') or 'service_line_input_state').strip()
            if _service_line_input_better_anchor(candidate, best):
                best = candidate
    for row in historical_anchor_rows or []:
        candidate = _service_line_input_anchor_candidate(row, patient_id_text, dos_text)
        if candidate and _service_line_input_better_anchor(candidate, best):
            best = candidate
    return best


def _option_a_preview_row_payload(upstream_entry):
    if (
        upstream_entry
        and len(upstream_entry) > 4
        and isinstance(upstream_entry[4], dict)
    ):
        return dict(upstream_entry[4])
    return {}


def _service_line_input_name_sort_key(value):
    return str(value or '').strip().upper()


def _service_line_input_dos_sort_key(value):
    normalized = _normalize_option_a_preview_date(value) or str(value or '').strip()
    try:
        return datetime.strptime(normalized, '%m-%d-%Y').strftime('%Y%m%d')
    except Exception:
        return normalized


def _service_line_input_docx_failure_counts(local_storage_path, index_data):
    counts = {}
    candidates = []
    if local_storage_path and collect_failed_docx_parse_candidates is not None:
        try:
            candidates = collect_failed_docx_parse_candidates(local_storage_path, index_data)
        except Exception:
            candidates = []
    elif isinstance(index_data, dict):
        try:
            for _filename, rec in (index_data.get('files') or {}).items():
                if isinstance(rec, dict) and rec.get('parse_failed'):
                    candidates.append(rec)
        except Exception:
            candidates = []
    for rec in candidates or []:
        if not isinstance(rec, dict):
            continue
        dos = _normalize_option_a_preview_date(rec.get('date_of_service')) or ''
        counts[dos] = int(counts.get(dos, 0) or 0) + 1
    return counts


def _service_line_input_docx_context_message(context):
    if not isinstance(context, dict):
        return ''
    status = str(context.get('docx_enrichment_status') or '').strip()
    if status == 'docx_matched':
        return ''
    if status == 'docx_matched_with_docx_only_observations':
        return (
            'DOCX context: all CSV-session rows matched; {0} DOCX-only read-only observation(s) are not prompted.'
        ).format(context.get('docx_only_observation_count', 0))
    if status == 'docx_missing':
        return (
            'DOCX context: no matched schedule for this DOS; rows are current '
            'CSV-session patients sorted by name. Diagnosis is unavailable until '
            'DOCX/crosswalk/operator edit supplies it.'
        )
    if status == 'docx_parse_failed':
        return (
            'DOCX context: a DOCX parse failure was recorded for this DOS; rows '
            'are CSV-session patients sorted by name and need diagnosis review.'
        )
    if status == 'docx_index_unavailable':
        return (
            'DOCX context: schedule index is unavailable; rows are CSV-session '
            'patients sorted by name and need diagnosis review.'
        )
    if status == 'docx_partial':
        return (
            'DOCX context: {0} matched, {1} CSV-only, {2} DOCX-only read-only observation(s).'
        ).format(
            context.get('docx_matched_row_count', 0),
            context.get('csv_only_row_count', 0),
            context.get('docx_only_observation_count', 0),
        )
    if status == 'docx_unmatched':
        return (
            'DOCX context: schedule exists but none of these CSV-session rows matched; '
            'rows are sorted by name and need diagnosis review.'
        )
    return ''


def _service_line_input_docx_enrichment_status(schedule_present, matched_count,
                                               csv_count, parse_failure_count,
                                               docx_index_status,
                                               docx_only_count=0):
    if schedule_present and csv_count and matched_count == csv_count:
        if docx_only_count:
            return 'docx_matched_with_docx_only_observations'
        return 'docx_matched'
    if schedule_present and matched_count:
        return 'docx_partial'
    if schedule_present:
        return 'docx_unmatched'
    if parse_failure_count:
        return 'docx_parse_failed'
    if docx_index_status != 'loaded':
        return 'docx_index_unavailable'
    return 'docx_missing'


def _service_line_input_add_persisted_state(row_payload, persisted):
    persisted_status = _sidecar_status_to_preview(persisted.get('status'))
    if persisted_status:
        _set_service_line_input_payload(
            row_payload,
            '_service_line_input_status',
            '_option_a_preview_status',
            persisted_status,
        )
        if persisted.get('minutes'):
            _set_service_line_input_payload(
                row_payload,
                '_service_line_input_minutes',
                '_option_a_preview_minutes',
                str(persisted.get('minutes')),
            )
        for state_key, service_key, legacy_key in (
            ('charge_display', '_service_line_input_charge_display', '_option_a_preview_charge_display'),
            ('charge_amount', '_service_line_input_charge_amount', '_option_a_preview_charge_amount'),
            ('charge_note', '_service_line_input_charge_note', '_option_a_preview_charge_note'),
            ('charge_rule_id', '_service_line_input_charge_rule_id', '_option_a_preview_charge_rule_id'),
            ('charge_status', '_service_line_input_charge_status', '_option_a_preview_charge_status'),
            ('charge_schema_version', '_service_line_input_charge_schema_version', '_option_a_preview_charge_schema_version'),
            ('charge_source', '_service_line_input_charge_source', '_option_a_preview_charge_source'),
            ('workflow_name', '_service_line_input_workflow_name', '_option_a_preview_workflow_name'),
            ('workflow_boundary', '_service_line_input_workflow_boundary', '_option_a_preview_workflow_boundary'),
            ('claims_completion', '_service_line_input_claims_completion', '_option_a_preview_claims_completion'),
            ('mutates_billing_state', '_service_line_input_mutates_billing_state', '_option_a_preview_mutates_billing_state'),
            ('billable', '_service_line_input_billable', '_option_a_preview_billable'),
            ('requires_operator_review', '_service_line_input_requires_operator_review', '_option_a_preview_requires_operator_review'),
            ('cpt', '_service_line_input_cpt', '_option_a_preview_cpt'),
            ('cpt_code', '_service_line_input_cpt_code', '_option_a_preview_cpt_code'),
            ('cpt_source', '_service_line_input_cpt_source', '_option_a_preview_cpt_source'),
            ('cpt_confidence', '_service_line_input_cpt_confidence', '_option_a_preview_cpt_confidence'),
            ('cpt_status', '_service_line_input_cpt_status', '_option_a_preview_cpt_status'),
            ('diagnosis', '_service_line_input_diagnosis', '_option_a_preview_diagnosis'),
            ('diagnosis_code', '_service_line_input_diagnosis_code', '_option_a_preview_diagnosis_code'),
            ('diagnosis_source', '_service_line_input_diagnosis_source', '_option_a_preview_diagnosis_source'),
            ('validation_status', '_service_line_input_validation_status', '_option_a_preview_validation_status'),
            ('validation_note', '_service_line_input_validation_note', '_option_a_preview_validation_note'),
        ):
            if persisted.get(state_key) is not None and persisted.get(state_key) != '':
                if state_key == 'charge_note':
                    persisted_note = _service_line_input_visible_charge_note(persisted)
                    if not persisted_note:
                        continue
                    _set_service_line_input_payload(
                        row_payload,
                        service_key,
                        legacy_key,
                        persisted_note,
                    )
                    continue
                _set_service_line_input_payload(
                    row_payload,
                    service_key,
                    legacy_key,
                    persisted.get(state_key),
                )
        status_reason = str(
            persisted.get('status_reason') or 'service_line_input_state_hydrated'
        )
        _set_service_line_input_payload(
            row_payload,
            '_service_line_input_status_reason',
            '_option_a_preview_status_reason',
            status_reason,
        )


def _service_line_input_docx_only_observations(patients, matched_patient_ids, dos):
    observations = []
    if not isinstance(patients, dict):
        return observations
    for patient_id, payload in patients.items():
        patient_id_text = str(patient_id or '').strip()
        if not patient_id_text or patient_id_text in matched_patient_ids:
            continue
        if not isinstance(payload, dict):
            payload = {}
        position = payload.get('position')
        try:
            position_key = int(position)
        except Exception:
            position_key = 999999
        observations.append((
            position_key,
            patient_id_text,
            {
                'classification': 'docx_only_observation',
                'editable': False,
                'patient_id': patient_id_text,
                'dos': dos,
                'docx_diagnosis': payload.get('diagnosis') or '',
                'docx_position': position,
            },
        ))
        _log_service_line_input_docx_only_observation(patient_id_text, dos)
    observations.sort(key=lambda item: (item[0], item[1]))
    return [item[2] for item in observations]


def build_option_a_preview_entries_from_docx_index(new_patient_info, config):
    """
    Compatibility wrapper returning the first CSV-anchored Service Line Input DOS.

    Editable rows are anchored to the current preprocessed CSV session. The DOCX
    index enriches matching rows with diagnosis/order context when available.
    """
    groups = build_option_a_preview_dos_groups_from_docx_index(new_patient_info, config)
    if not groups:
        return None, None
    active_date = None
    try:
        active_date = _normalize_option_a_preview_date(new_patient_info[0][0])
    except Exception:
        active_date = None
    for group in groups:
        if group.get('dos') == active_date:
            return group.get('entries') or [], group.get('dos')
    return groups[0].get('entries') or [], groups[0].get('dos')


def build_service_line_input_entries_from_docx_index(new_patient_info, config):
    return build_option_a_preview_entries_from_docx_index(new_patient_info, config)


def build_option_a_preview_dos_groups_from_docx_index(new_patient_info, config):
    """
    Build current-session Service Line Input groups from CSV-session rows.

    Returns a list of dicts: {dos, entries, source_scope}. The preprocessed CSV
    session owns editable patient identity and DOS scope. DOCX observations
    enrich matching rows with diagnosis and printed order; DOCX-only rows are
    preserved as read-only observations and are not prompted or persisted as
    completed Service Line Input rows.
    """
    if not new_patient_info:
        return []

    upstream_by_date = {}
    seen_by_date = {}
    for csv_position, entry in enumerate(new_patient_info or []):
        if not isinstance(entry, tuple) or len(entry) < 4:
            continue
        entry_date = _normalize_option_a_preview_date(entry[0])
        patient_id = str(entry[2] or '').strip()
        if not entry_date or not patient_id:
            continue
        seen = seen_by_date.setdefault(entry_date, set())
        if patient_id in seen:
            continue
        seen.add(patient_id)
        bucket = upstream_by_date.setdefault(entry_date, [])
        bucket.append({
            'entry': entry,
            'patient_id': patient_id,
            'patient_name': entry[1],
            'csv_session_position': csv_position + 1,
        })
    if not upstream_by_date:
        return []

    requested_dates = sorted(upstream_by_date.keys(), key=_service_line_input_dos_sort_key)
    local_storage_path = _option_a_preview_local_storage_path(config or {})
    index_data = {}
    schedules = {}
    docx_index_status = 'loaded'
    if not local_storage_path:
        docx_index_status = 'docx_index_unavailable'
    elif load_docx_schedule_index is None or get_schedules_for_dates is None:
        docx_index_status = 'docx_index_unavailable'
    else:
        try:
            index_data = load_docx_schedule_index(local_storage_path)
            schedules = get_schedules_for_dates(index_data, requested_dates)
            if not isinstance(schedules, dict):
                schedules = {}
                docx_index_status = 'docx_index_unavailable'
        except Exception:
            schedules = {}
            docx_index_status = 'docx_index_unavailable'

    parse_failure_counts = _service_line_input_docx_failure_counts(
        local_storage_path,
        index_data,
    )
    status_data = _load_option_a_minutes_status(local_storage_path) if local_storage_path else {}
    status_rows = status_data.get('rows', {}) if isinstance(status_data, dict) else {}
    anchor_index = _load_service_line_charge_anchor_index(local_storage_path) if local_storage_path else {}
    historical_anchor_rows = anchor_index.get('anchors', []) if isinstance(anchor_index, dict) else []
    groups = []
    for dos in requested_dates:
        current = schedules.get(dos) if isinstance(schedules, dict) else None
        patients = {}
        if isinstance(current, dict) and isinstance(current.get('patients'), dict):
            patients = current.get('patients') or {}
        schedule_present = bool(patients)
        parse_failure_count = int(parse_failure_counts.get(dos, 0) or 0)
        upstream_rows = upstream_by_date.get(dos, [])
        matched_patient_ids = set()
        ordered = []
        matched_count = 0
        csv_only_count = 0
        for upstream in upstream_rows:
            entry = upstream.get('entry')
            patient_id_text = upstream.get('patient_id')
            upstream_name = upstream.get('patient_name')
            if not patient_id_text or not entry:
                continue
            payload = patients.get(patient_id_text) if isinstance(patients, dict) else None
            matched_docx = isinstance(payload, dict)
            if matched_docx:
                matched_count += 1
                matched_patient_ids.add(patient_id_text)
                position = payload.get('position')
                try:
                    position_key = int(position)
                except Exception:
                    position_key = 999999
                diagnosis = payload.get('diagnosis') or ''
                diagnosis_source = 'docx_observation'
                docx_match_status = 'matched'
                sort_key = (0, position_key, _service_line_input_name_sort_key(upstream_name), patient_id_text)
                line_ordinal = position_key
            else:
                csv_only_count += 1
                position = None
                position_key = 999999
                diagnosis = 'N/A'
                if schedule_present:
                    diagnosis_source = 'docx_unmatched'
                    docx_match_status = 'csv_only_docx_unmatched'
                    sort_prefix = 1
                elif parse_failure_count:
                    diagnosis_source = 'docx_parse_failed'
                    docx_match_status = 'csv_only_docx_parse_failed'
                    sort_prefix = 0
                else:
                    diagnosis_source = 'docx_missing'
                    docx_match_status = 'csv_only_docx_missing'
                    sort_prefix = 0
                sort_key = (sort_prefix, position_key, _service_line_input_name_sort_key(upstream_name), patient_id_text)
                line_ordinal = upstream.get('csv_session_position') or 1

            row_payload = _option_a_preview_row_payload(entry)
            source_payload = {
                'patient_id': patient_id_text,
                'dos': dos,
                'primary_anchor': 'csv_session',
                'anchor_source': 'csv_session',
                'csv_session_position': upstream.get('csv_session_position'),
                'docx_match_status': docx_match_status,
                'docx_diagnosis': diagnosis if matched_docx else '',
                'docx_position': position,
                'line_ordinal': line_ordinal,
            }
            _set_service_line_input_payload(
                row_payload,
                '_service_line_input_source',
                '_option_a_preview_source',
                source_payload,
            )
            _set_service_line_input_payload(
                row_payload,
                '_service_line_input_diagnosis_source',
                '_option_a_preview_diagnosis_source',
                diagnosis_source,
            )
            if not matched_docx:
                _set_service_line_input_payload(
                    row_payload,
                    '_service_line_input_validation_status',
                    '_option_a_preview_validation_status',
                    'review_required',
                )
                _set_service_line_input_payload(
                    row_payload,
                    '_service_line_input_validation_note',
                    '_option_a_preview_validation_note',
                    'diagnosis unavailable because DOCX observation is missing for this CSV-session row',
                )
            anchor = _service_line_input_same_patient_anchor(
                status_rows,
                patient_id_text,
                dos,
                historical_anchor_rows=historical_anchor_rows,
            )
            for anchor_key, anchor_value in anchor.items():
                _set_service_line_input_payload(
                    row_payload,
                    '_service_line_input_{0}'.format(anchor_key),
                    '_option_a_preview_{0}'.format(anchor_key),
                    anchor_value,
                )
            persisted = status_rows.get(_option_a_minutes_row_key(patient_id_text, dos))
            if isinstance(persisted, dict):
                _service_line_input_add_persisted_state(row_payload, persisted)
            elif matched_docx:
                auto_status = _option_a_preview_docx_auto_status(diagnosis)
                if auto_status:
                    _set_service_line_input_payload(
                        row_payload,
                        '_service_line_input_status',
                        '_option_a_preview_status',
                        auto_status,
                    )
                    _set_service_line_input_payload(
                        row_payload,
                        '_service_line_input_status_reason',
                        '_option_a_preview_status_reason',
                        'docx_diagnosis_unknown',
                    )
            _set_service_line_input_false_boundary_flags(row_payload)
            ordered.append((
                sort_key,
                patient_id_text,
                (dos, upstream_name, patient_id_text, diagnosis, row_payload),
            ))

        if not ordered:
            continue
        docx_only = _service_line_input_docx_only_observations(
            patients,
            matched_patient_ids,
            dos,
        )
        source_scope = {
            'anchor_source': 'csv_session',
            'primary_anchor': 'csv_session',
            'dos': dos,
            'csv_candidate_row_count': len(upstream_rows),
            'docx_schedule_present': bool(schedule_present),
            'docx_matched_row_count': matched_count,
            'csv_only_row_count': csv_only_count,
            'docx_only_observation_count': len(docx_only),
            'docx_parse_failure_count': parse_failure_count,
            'docx_index_status': docx_index_status,
            'docx_enrichment_status': _service_line_input_docx_enrichment_status(
                schedule_present,
                matched_count,
                len(upstream_rows),
                parse_failure_count,
                docx_index_status,
                len(docx_only),
            ),
            'workflow_boundary': SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
            'claims_completion': False,
            'mutates_billing_state': False,
            'mutates_dat': False,
            'mutates_837p': False,
            'charges_entered': False,
        }
        source_scope['docx_context_message'] = _service_line_input_docx_context_message(source_scope)
        if docx_only:
            source_scope['docx_only_observations'] = docx_only
        ordered.sort(key=lambda item: item[0])
        entries = [item[2] for item in ordered]
        for display_position, entry in enumerate(entries):
            try:
                source_payload = entry[4].get('_service_line_input_source') or {}
                if source_payload.get('docx_position') in (None, ''):
                    source_payload['line_ordinal'] = display_position + 1
                source_payload['csv_display_position'] = display_position + 1
                source_payload.update(source_scope)
                entry[4]['_service_line_input_source'] = source_payload
                entry[4]['_option_a_preview_source'] = source_payload
            except Exception:
                pass
        groups.append({
            'dos': dos,
            'entries': entries,
            'source_scope': source_scope,
            'docx_only_observations': docx_only,
        })
    return groups


def build_service_line_input_dos_groups_from_docx_index(new_patient_info, config):
    return build_option_a_preview_dos_groups_from_docx_index(new_patient_info, config)


def persist_service_line_input_summary(local_storage_path, service_line_input_session_id, dos, summary):
    data = _load_service_line_input_state(local_storage_path)
    rows_state = data.setdefault('rows', {})
    events_state = data.setdefault('events', [])
    session_state = data.setdefault('sessions', {}).setdefault(service_line_input_session_id, {
        'started_at_epoch': int(time.time()),
        'dos_completed': [],
    })
    if dos not in session_state.get('dos_completed', []):
        session_state.setdefault('dos_completed', []).append(dos)
    session_state['updated_at_epoch'] = int(time.time())
    for row in summary.get('rows', []) if isinstance(summary, dict) else []:
        if ServiceLineInputModel is not None:
            try:
                row = ServiceLineInputModel.sanitize_service_line_preview_row(row)
            except Exception:
                pass
        source = row.get('source') if isinstance(row, dict) else {}
        if not isinstance(source, dict):
            source = {}
        patient_id = source.get('patient_id') or row.get('patient_id')
        row_dos = source.get('dos') or dos
        status = _option_a_status_to_sidecar(row.get('status'))
        if not patient_id or not row_dos or not status:
            continue
        status_reason = row.get('status_reason')
        review_status = status
        if status == 'cancelled' and str(status_reason or '').strip() == 'docx_diagnosis_unknown':
            review_status = 'auto_cancelled'
        state_row = {
            'patient_id': str(patient_id),
            'dos': _normalize_option_a_preview_date(row_dos) or str(row_dos),
            'status': status,
            'review_status': review_status,
            'docx_diagnosis': source.get('docx_diagnosis') or '',
            'docx_position': source.get('docx_position'),
            'diagnosis_code': row.get('diagnosis_code') or row.get('diagnosis') or source.get('docx_diagnosis') or '',
            'diagnosis_source': row.get('diagnosis_source') or source.get('diagnosis_source') or 'docx_observation',
            'validation_status': row.get('validation_status') or 'review_required',
            'validation_note': row.get('validation_note') or '',
            'primary_anchor': source.get('primary_anchor') or source.get('anchor_source') or 'csv_session',
            'anchor_source': source.get('anchor_source') or source.get('primary_anchor') or 'csv_session',
            'csv_session_position': source.get('csv_session_position'),
            'docx_match_status': source.get('docx_match_status') or '',
            'docx_enrichment_status': source.get('docx_enrichment_status') or '',
            'docx_only_observation_count': source.get('docx_only_observation_count') or 0,
            'docx_parse_failure_count': source.get('docx_parse_failure_count') or 0,
            'updated_at_epoch': int(time.time()),
            'service_line_input_session_id': service_line_input_session_id,
            'option_a_session_id': service_line_input_session_id,
        }
        if ServiceLineInputModel is not None:
            try:
                target_record = ServiceLineInputModel.build_service_line_target_record(
                    row=row,
                    patient_id=patient_id,
                    dos=row_dos,
                    line_ordinal=source.get('line_ordinal') or source.get('docx_position'),
                    docx_position=source.get('docx_position'),
                )
                state_row['target_identity'] = target_record.get('target_identity')
                state_row['legacy_row_key'] = target_record.get('legacy_row_key')
                state_row['service_line_row_key'] = target_record.get('service_line_row_key')
                state_row['service_line_kind'] = target_record.get('service_line_kind')
                state_row['line_ordinal'] = target_record.get('line_ordinal')
                state_row['target_schema_version'] = target_record.get('schema_version')
            except Exception:
                pass
        if status == 'entered':
            state_row['minutes'] = str(row.get('minutes') or '')
        for key in (
                'charge_display',
                'charge_amount',
                'charge_note',
                'charge_rule_id',
                'charge_status',
                'charge_schema_version',
                'charge_source',
                'workflow_name',
                'workflow_boundary',
                'claims_completion',
                'mutates_billing_state',
                'billable',
                'requires_operator_review',
                'cpt',
                'cpt_code',
                'cpt_source',
                'cpt_confidence',
                'cpt_status',
                'diagnosis',
                'diagnosis_code',
                'diagnosis_source',
                'validation_status',
                'validation_note',
                'crosswalk_intake_save_ok',
                'crosswalk_intake_message'):
            if row.get(key) is not None and row.get(key) != '':
                if key in ('claims_completion', 'mutates_billing_state'):
                    state_row[key] = False
                elif key in ('billable', 'requires_operator_review'):
                    state_row[key] = _option_a_bool_value(row.get(key))
                elif key == 'crosswalk_intake_save_ok':
                    state_row[key] = _option_a_bool_value(row.get(key))
                elif key == 'charge_note':
                    visible_note = _service_line_input_visible_charge_note(row)
                    if visible_note:
                        state_row[key] = visible_note
                else:
                    state_row[key] = str(row.get(key))
        if state_row.get('cpt') and not state_row.get('cpt_code'):
            state_row['cpt_code'] = state_row.get('cpt')
        if state_row.get('diagnosis') and not state_row.get('diagnosis_code'):
            state_row['diagnosis_code'] = state_row.get('diagnosis')
        state_row['workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
        state_row['workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
        for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
            state_row[false_key] = False
        intake_events = row.get('crosswalk_intake_events')
        if isinstance(intake_events, list):
            safe_events = []
            for intake_event in intake_events:
                if not isinstance(intake_event, dict):
                    continue
                event_copy = dict(intake_event)
                event_copy['service_line_input_session_id'] = service_line_input_session_id
                event_copy['workflow_boundary'] = 'confirmed_config_update'
                event_copy['claim_workflow_completion'] = False
                event_copy['claims_completion'] = False
                event_copy['mutates_billing_state'] = False
                event_copy['mutates_dat'] = False
                event_copy['mutates_837p'] = False
                event_copy['charges_entered'] = False
                safe_events.append(event_copy)
            if safe_events:
                state_row['crosswalk_intake_events'] = safe_events
        if ServiceLineInputModel is not None:
            try:
                state_row = ServiceLineInputModel.sanitize_service_line_preview_row(state_row)
            except Exception:
                pass
        for false_key in SERVICE_LINE_INPUT_FALSE_BOUNDARY_FIELDS:
            state_row[false_key] = False
        if isinstance(state_row.get('crosswalk_intake_events'), list):
            for event_copy in state_row.get('crosswalk_intake_events') or []:
                if isinstance(event_copy, dict):
                    event_copy['workflow_boundary'] = 'confirmed_config_update'
                    event_copy['claim_workflow_completion'] = False
                    event_copy['claims_completion'] = False
                    event_copy['mutates_billing_state'] = False
                    event_copy['mutates_dat'] = False
                    event_copy['mutates_837p'] = False
                    event_copy['charges_entered'] = False
        if status_reason:
            state_row['status_reason'] = str(status_reason)
        legacy_row_key = _option_a_minutes_row_key(patient_id, row_dos)
        previous_row = rows_state.get(legacy_row_key)
        if ServiceLineInputModel is not None:
            try:
                event = ServiceLineInputModel.build_service_line_overlay_event(
                    previous_row or {},
                    state_row,
                    service_line_input_session_id,
                    action='row_persisted',
                )
                if event:
                    events_state.append(event)
            except Exception:
                pass
        for intake_event in state_row.get('crosswalk_intake_events') or []:
            if isinstance(intake_event, dict):
                events_state.append(intake_event)
        rows_state[legacy_row_key] = state_row
    return _write_service_line_input_state(local_storage_path, data)


def persist_option_a_minutes_summary(local_storage_path, option_a_session_id, dos, summary):
    # SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: legacy wrapper.
    return persist_service_line_input_summary(
        local_storage_path,
        option_a_session_id,
        dos,
        summary,
    )


def _build_service_line_input_groups_for_session(new_patient_info, config):
    groups = build_service_line_input_dos_groups_from_docx_index(new_patient_info, config)
    if not groups:
        preview_entries, preview_dos = build_service_line_input_entries_from_docx_index(new_patient_info, config)
        if preview_entries:
            groups = [{'dos': preview_dos, 'entries': preview_entries}]
        else:
            groups = [{'dos': str(new_patient_info[0][0] or '') if new_patient_info else '', 'entries': new_patient_info}]
    return groups


def _service_line_input_row_identity_key(row):
    if not isinstance(row, dict):
        return ''
    key = str(row.get('service_line_row_key') or '').strip()
    if key:
        return key
    patient_id = str(row.get('patient_id') or '').strip()
    dos = _normalize_option_a_preview_date(row.get('date') or row.get('dos')) or str(row.get('date') or row.get('dos') or '').strip()
    line_ordinal = str(row.get('line_ordinal') or row.get('docx_position') or '1').strip()
    if not patient_id or not dos:
        return ''
    return "{0}|{1}|anesthesia|{2}".format(patient_id, dos, line_ordinal or '1')


def _service_line_input_latest_rows_list(row_map):
    rows = []
    for key in sorted((row_map or {}).keys()):
        rows.append(row_map[key])
    return rows


def _service_line_input_update_latest_rows(row_map, summary):
    if not isinstance(row_map, dict):
        row_map = {}
    if not isinstance(summary, dict):
        return row_map
    for row in summary.get('rows') or []:
        if not isinstance(row, dict):
            continue
        key = _service_line_input_row_identity_key(row)
        if key:
            row_map[key] = row
    return row_map


def _service_line_input_summary_is_reviewed(summary):
    if not isinstance(summary, dict):
        return False
    if summary.get('operator_return_requested'):
        return False
    if summary.get('review_complete') is False:
        return False
    pending = int(summary.get('pending', 0) or 0)
    invalid = int(summary.get('invalid', 0) or 0)
    return pending == 0 and invalid == 0


def _service_line_input_print_dos_list(groups, reviewed_dos, selected_index):
    print("")
    print("Service Line Input DOS list:")
    for idx, group in enumerate(groups or []):
        dos = group.get('dos') or 'Unknown'
        entries = group.get('entries') or []
        status = 'reviewed' if dos in reviewed_dos else 'pending'
        marker = '>' if idx == selected_index else ' '
        print(" {0} {1:>2}) {2} - {3} row(s) - {4}".format(
            marker,
            idx + 1,
            dos,
            len(entries),
            status,
        ))
    print("")


def _service_line_input_choose_next_index(groups, current_index, reviewed_dos):
    if not groups:
        return None
    for idx in range(current_index + 1, len(groups)):
        dos = groups[idx].get('dos') or ''
        if dos not in reviewed_dos:
            return idx
    for idx in range(0, len(groups)):
        dos = groups[idx].get('dos') or ''
        if dos not in reviewed_dos:
            return idx
    if current_index + 1 < len(groups):
        return current_index + 1
    return None


def _service_line_input_prompt_dos_navigation(groups, current_index, reviewed_dos):
    if groups and len(groups) > 1 and len(reviewed_dos or {}) == len(groups):
        print("\nAll available Service Line Input DOS screens have been reviewed.")
        while True:
            choice = (input("Enter/q=return, p=previous DOS, list=show DOS, go <#|DOS>, r=reopen current: ") or "").strip()
            low = choice.lower()
            if low in ('', 'q', 'quit', 'return'):
                return None, 'all_reviewed'
            if low in ('list', 'dos'):
                _service_line_input_print_dos_list(groups, reviewed_dos, current_index)
                continue
            if low in ('p', 'prev', 'previous'):
                for idx in range(current_index - 1, -1, -1):
                    if (groups[idx].get('dos') or '') in reviewed_dos:
                        return idx, 'previous'
                print("No previous reviewed DOS is available.")
                continue
            if low in ('r', 'current', 'reopen'):
                if current_index >= 0 and current_index < len(groups):
                    return current_index, 'reopen'
                print("No current DOS is available.")
                continue
            if low.startswith('go '):
                target = choice.split(None, 1)[1].strip()
                if target.isdigit():
                    idx = int(target) - 1
                    if idx >= 0 and idx < len(groups):
                        return idx, 'jump'
                target_dos = _normalize_option_a_preview_date(target) or target
                for idx, group in enumerate(groups):
                    if (group.get('dos') or '') == target_dos:
                        return idx, 'jump'
                print("DOS not found: {0}".format(target))
                continue
            print("Invalid entry. Press Enter to return, p for previous, list, go <#|DOS>, r, or q.")
    next_index = _service_line_input_choose_next_index(groups, current_index, reviewed_dos)
    if next_index is None:
        return None, 'all_reviewed'
    next_group = groups[next_index]
    print("\nNext Service Line Input DOS: {0} ({1} patient(s) pending in this session).".format(
        next_group.get('dos') or 'Unknown',
        len(next_group.get('entries') or []),
    ))
    while True:
        choice = (input("Enter/n=next, p=previous DOS, list=show DOS, go <#|DOS>, r=reopen current, q=return: ") or "").strip()
        low = choice.lower()
        if low in ('', 'n', 'next'):
            return next_index, 'next'
        if low in ('q', 'quit'):
            return None, 'quit'
        if low in ('list', 'dos'):
            _service_line_input_print_dos_list(groups, reviewed_dos, next_index)
            continue
        if low in ('p', 'prev', 'previous'):
            for idx in range(current_index - 1, -1, -1):
                if (groups[idx].get('dos') or '') in reviewed_dos:
                    return idx, 'previous'
            print("No previous reviewed DOS is available.")
            continue
        if low in ('r', 'current', 'reopen'):
            if current_index >= 0 and current_index < len(groups):
                return current_index, 'reopen'
            print("No current DOS is available.")
            continue
        if low.startswith('go '):
            target = choice.split(None, 1)[1].strip()
            if target.isdigit():
                idx = int(target) - 1
                if idx >= 0 and idx < len(groups):
                    return idx, 'jump'
            target_dos = _normalize_option_a_preview_date(target) or target
            for idx, group in enumerate(groups):
                if (group.get('dos') or '') == target_dos:
                    return idx, 'jump'
            print("DOS not found: {0}".format(target))
            continue
        print("Invalid entry. Press Enter for next, p for previous, list, go <#|DOS>, r, or q.")


def run_service_line_input_multi_dos_entry(new_patient_info, config, charge_calculator=None, crosswalk=None):
    local_storage_path = _option_a_preview_local_storage_path(config or {})
    if charge_calculator is None:
        charge_calculator = calculate_service_line_amount_result
    if not isinstance(crosswalk, dict):
        crosswalk = {}
    charge_calculator = _service_line_input_amount_calculator_with_cpt(crosswalk, charge_calculator)
    option_sets = _service_line_input_option_sets_from_crosswalk(crosswalk)
    option_sets['crosswalk_intake_handler'] = _service_line_input_crosswalk_intake_handler(
        config,
        crosswalk,
        option_sets,
    )
    groups = _build_service_line_input_groups_for_session(new_patient_info, config)
    session_id = _new_service_line_input_session_id()
    completed_by_dos = {}
    latest_rows = {}
    dos_visit_history = []
    reviewed_dos = {}
    current_index = 0
    operator_return_requested = False
    navigation_events = []
    while current_index is not None and current_index >= 0 and current_index < len(groups):
        # Rebuild before each DOS so just-persisted rows, historical anchors,
        # and same-session anchor effects are visible when reopening screens.
        refreshed_groups = _build_service_line_input_groups_for_session(new_patient_info, config)
        if refreshed_groups:
            groups = refreshed_groups
        group = groups[current_index]
        dos = group.get('dos') or ''
        entries = group.get('entries') or []
        summary = _run_service_line_input_ui_entry(
            entries,
            dos,
            charge_calculator,
            option_sets,
        )
        if local_storage_path:
            persist_service_line_input_summary(local_storage_path, session_id, dos, summary)
        completed_by_dos[dos] = {'dos': dos, 'summary': summary}
        dos_visit_history.append({
            'dos': dos,
            'visit_index': len(dos_visit_history) + 1,
            'terminal_action': summary.get('terminal_action') if isinstance(summary, dict) else '',
            'operator_return_requested': bool(summary.get('operator_return_requested')) if isinstance(summary, dict) else False,
        })
        if isinstance(summary, dict):
            latest_rows = _service_line_input_update_latest_rows(latest_rows, summary)
            if _service_line_input_summary_is_reviewed(summary):
                reviewed_dos[dos] = True
            if summary.get('operator_return_requested'):
                operator_return_requested = True
                break
        next_index, nav_action = _service_line_input_prompt_dos_navigation(
            groups,
            current_index,
            reviewed_dos,
        )
        navigation_events.append({
            'from_dos': dos,
            'action': nav_action,
            'to_dos': groups[next_index].get('dos') if next_index is not None and next_index < len(groups) else '',
        })
        if nav_action in ('quit', 'all_reviewed') or next_index is None:
            if nav_action == 'quit':
                operator_return_requested = True
            break
        current_index = next_index
    completed = []
    for group in groups:
        dos = group.get('dos') or ''
        if dos in completed_by_dos:
            completed.append(completed_by_dos[dos])
    completed_rows = _service_line_input_latest_rows_list(latest_rows)
    review_completion = {
        'workflow_name': SERVICE_LINE_INPUT_WORKFLOW_NAME,
        'workflow_boundary': SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY,
        'service_line_input_session_id': session_id,
        'service_line_input_review_complete': True,
        'claims_completion': False,
        'mutates_billing_state': False,
        'mutates_dat': False,
        'mutates_837p': False,
        'charges_entered': False,
    }
    if ServiceLineInputModel is not None:
        try:
            review_completion = ServiceLineInputModel.build_service_line_review_completion_summary(
                session_id,
                completed_rows,
            )
        except Exception:
            pass
    if len(reviewed_dos) != len(groups):
        review_completion['service_line_input_review_complete'] = False
        review_completion['review_completion_blocker'] = (
            'operator_returned_before_all_dos'
            if operator_return_requested
            else 'unreviewed_dos_remaining'
        )
    review_completion['operator_return_requested'] = bool(operator_return_requested)
    artifact_paths = {}
    if local_storage_path:
        artifact_paths = _write_service_line_input_review_artifacts(
            local_storage_path,
            session_id,
            completed_rows,
            review_completion,
        )
        if isinstance(artifact_paths, dict):
            if artifact_paths.get('candidate_json'):
                review_completion['candidate_json'] = artifact_paths.get('candidate_json')
            if artifact_paths.get('candidate_txt'):
                review_completion['candidate_txt'] = artifact_paths.get('candidate_txt')
            cleanup = artifact_paths.get('cleanup_readiness')
            if isinstance(cleanup, dict):
                review_completion['cleanup_readiness'] = cleanup.get('cleanup_readiness')
                review_completion['cleanup_blockers'] = cleanup.get('blockers') or []
    _print_service_line_input_review_summary(review_completion, artifact_paths)
    return {
        'service_line_input_session_id': session_id,
        'option_a_session_id': session_id,
        'dos_total': len(groups),
        'dos_completed': len(reviewed_dos),
        'dos_order': [group.get('dos') or '' for group in groups],
        'dos_navigation': navigation_events,
        'dos_visit_history': dos_visit_history,
        'unreviewed_dos': [group.get('dos') or '' for group in groups if (group.get('dos') or '') not in reviewed_dos],
        'operator_return_requested': bool(operator_return_requested),
        'review_completion': review_completion,
        'artifact_paths': artifact_paths,
        'completed': completed,
    }


def run_option_a_multi_dos_minutes_preview(new_patient_info, config, charge_calculator=None, crosswalk=None):
    # SERVICE_LINE_INPUT_LEGACY_OPTION_A_CLEANUP: legacy wrapper.
    return run_service_line_input_multi_dos_entry(
        new_patient_info,
        config,
        charge_calculator=charge_calculator,
        crosswalk=crosswalk,
    )

# Global flag to control AHK execution method - set to True to use optimized stdin method
USE_AHK_STDIN_OPTIMIZATION = True

DEFAULT_AHK_EXEC_TIMEOUT_SEC = 15.0


class AHKSafetyStop(Exception):
    """Raised when MediBot must stop AHK automation to avoid unsafe keystrokes."""
    pass

def _get_ahk_timing_settings():
    """Fetch AHK timing settings from config with safe defaults.
    Returns (key_delay_ms, key_press_ms, post_send_sleep_ms).
    """
    key_delay_ms = 0 
    key_press_ms = 0
    post_send_sleep_ms = 0
    try:
        config, _ = MediBot_Preprocessor_lib.get_cached_configuration()
        # Allow flat keys in config for simplicity/XP safety
        key_delay_ms = int(config.get('AHK_KEY_DELAY_MS', key_delay_ms))
        key_press_ms = int(config.get('AHK_KEY_PRESS_MS', key_press_ms))
        post_send_sleep_ms = int(config.get('AHK_POST_SEND_SLEEP_MS', post_send_sleep_ms))
    except Exception:
        # Use defaults on any error
        pass
    return key_delay_ms, key_press_ms, post_send_sleep_ms


def _get_ahk_exec_timeout_seconds():
    timeout_sec = DEFAULT_AHK_EXEC_TIMEOUT_SEC
    try:
        config, _ = MediBot_Preprocessor_lib.get_cached_configuration()
        timeout_sec = float(config.get('AHK_EXEC_TIMEOUT_SEC', timeout_sec))
    except Exception:
        pass
    if timeout_sec <= 0:
        timeout_sec = DEFAULT_AHK_EXEC_TIMEOUT_SEC
    return timeout_sec


def _get_foreground_window_context():
    context = {
        'title': '',
        'process_name': '',
        'pid': None,
        'hwnd': None,
        'probe_error': None,
    }
    if os.name != 'nt':
        context['probe_error'] = 'foreground_probe_windows_only'
        return context
    try:
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        psapi = ctypes.windll.psapi
        hwnd = user32.GetForegroundWindow()
        context['hwnd'] = int(hwnd or 0)
        if not hwnd:
            context['probe_error'] = 'no_foreground_window'
            return context
        title_buffer = ctypes.create_unicode_buffer(512)
        user32.GetWindowTextW(hwnd, title_buffer, len(title_buffer))
        context['title'] = title_buffer.value or ''
        pid = ctypes.c_ulong(0)
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        context['pid'] = int(pid.value or 0)
        if not context['pid']:
            return context
        process_handle = kernel32.OpenProcess(0x0410, 0, context['pid'])
        if not process_handle:
            context['probe_error'] = 'open_process_failed'
            return context
        try:
            name_buffer = ctypes.create_unicode_buffer(512)
            result = psapi.GetModuleBaseNameW(process_handle, None, name_buffer, len(name_buffer))
            if result:
                context['process_name'] = name_buffer.value or ''
        finally:
            kernel32.CloseHandle(process_handle)
    except Exception as exc:
        context['probe_error'] = str(exc)
    return context


def _is_medisoft_foreground_context(context):
    title = (context.get('title') or '').lower()
    process_name = (context.get('process_name') or '').lower()
    if process_name:
        return 'medisoft' in process_name
    if title:
        return 'medisoft' in title
    return False


def _format_ahk_safety_context(context):
    details = []
    details.append("reason={0}".format(context.get('reason') or 'unknown'))
    details.append("field={0}".format(context.get('field') or 'unknown'))
    details.append("method={0}".format(context.get('method') or 'unknown'))
    if context.get('timeout_sec') is not None:
        details.append("timeout_sec={0}".format(context.get('timeout_sec')))
    if context.get('returncode') is not None:
        details.append("returncode={0}".format(context.get('returncode')))
    if context.get('pid') is not None:
        details.append("foreground_pid={0}".format(context.get('pid')))
    if context.get('process_name'):
        details.append("foreground_process={0}".format(context.get('process_name')))
    if context.get('title'):
        details.append("foreground_title={0}".format(repr(context.get('title'))))
    if context.get('probe_error'):
        details.append("probe_error={0}".format(context.get('probe_error')))
    if context.get('stderr_tail'):
        details.append("stderr_tail={0}".format(repr(context.get('stderr_tail'))))
    if context.get('stdout_tail'):
        details.append("stdout_tail={0}".format(repr(context.get('stdout_tail'))))
    return "; ".join(details)


def _log_ahk_safety_event(context, level):
    message = "AHK safety stop: {0}".format(_format_ahk_safety_context(context))
    try:
        MediLink_ConfigLoader.log(message, level=level)
    except Exception:
        pass
    return message


def _raise_ahk_safety_stop(context, level):
    message = _log_ahk_safety_event(context, level)
    raise AHKSafetyStop(
        "{0}. Reconcile the current Medisoft screen before retrying automation.".format(message)
    )


def _terminate_process_safely(process):
    try:
        process.terminate()
    except Exception:
        try:
            process.kill()
        except Exception:
            pass


def _bounded_communicate(process, timeout_sec, input_bytes=None):
    state = {
        'stdout': None,
        'stderr': None,
        'error': None,
    }

    def _worker():
        try:
            if input_bytes is None:
                state['stdout'], state['stderr'] = process.communicate()
            else:
                state['stdout'], state['stderr'] = process.communicate(input=input_bytes)
        except Exception as exc:
            state['error'] = exc

    worker = threading.Thread(target=_worker)
    worker.daemon = True
    worker.start()
    worker.join(timeout_sec)
    if worker.is_alive():
        _terminate_process_safely(process)
        worker.join(2.0)
        return None, None, True, state.get('error')
    if state['error'] is not None:
        raise state['error']
    return state.get('stdout'), state.get('stderr'), False, None


def _decode_subprocess_stream(stream_value):
    try:
        return stream_value.decode('utf-8', errors='ignore') if stream_value else ''
    except Exception:
        try:
            return str(stream_value)
        except Exception:
            return ''


def _get_stream_tail(stream_value, max_len):
    decoded = _decode_subprocess_stream(stream_value)
    if len(decoded) <= max_len:
        return decoded
    return decoded[-max_len:]


def _assert_medisoft_foreground(expected_field):
    context = _get_foreground_window_context()
    if _is_medisoft_foreground_context(context):
        return
    context['reason'] = 'foreground_mismatch'
    context['field'] = expected_field
    context['method'] = 'preflight'
    _raise_ahk_safety_stop(context, level="ERROR")

def _build_ahk_script_with_handshake(core_send_command, done_token):
    """Build a complete AHK script that:
    - Sets stable, slightly slowed input timing (prevents UI overrun)
    - Executes the provided send command (expected to include {Enter} as field advance)
    - Sleeps briefly to allow UI to settle
    - Emits a completion token to stdout (so Python can block until completion)

    NOTE (future option - burst mode): To reduce process spawn overhead, we can batch
    multiple send commands into a single AHK script by concatenating several
    `SendInput, ...{Enter}` lines separated by short `Sleep` calls, then append a single
    `FileAppend, DONE, *` at the end. Python would then wait for "DONE" once per burst
    (e.g., 3–5 fields), instead of once per field.
    """
    # Keep delays configurable; defaults are tuned for responsiveness while avoiding overruns
    key_delay_ms, key_press_ms, post_send_sleep_ms = _get_ahk_timing_settings()
    # SetKeyDelay, DelayBetweenKeysMs, KeyPressDurationMs
    preamble = (
        "#NoEnv\r\n"
        "#NoTrayIcon\r\n"
        "SendMode, Input\r\n"
        "SetKeyDelay, {0}, {1}\r\n".format(key_delay_ms, key_press_ms)
    )
    # After each send, give UI a short moment before declaring done
    epilogue = (
        "\r\nSleep, {sleep}\r\n"
        "FileAppend, {done}, *\r\n"
        "ExitApp\r\n"
    ).format(sleep=post_send_sleep_ms, done=done_token)
    return preamble + core_send_command + epilogue

def _run_ahk_script_via_stdin(full_script, done_token, expected_field, timeout_sec):
    process = subprocess.Popen(
        [
            MediBot_Preprocessor_lib.AHK_EXECUTABLE,
            '/ErrorStdOut',
            '/CP65001',
            '*'
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=False
    )
    stdout, stderr, timed_out, _ = _bounded_communicate(
        process,
        timeout_sec,
        input_bytes=full_script.encode('utf-8')
    )
    decoded_out = _decode_subprocess_stream(stdout)
    if timed_out:
        _raise_ahk_safety_stop({
            'reason': 'timeout',
            'field': expected_field,
            'method': 'stdin',
            'timeout_sec': timeout_sec,
            'stdout_tail': _get_stream_tail(stdout, 200),
            'stderr_tail': _get_stream_tail(stderr, 200),
        }, level="ERROR")
    if process.returncode == 0 and done_token in decoded_out:
        return None
    if process.returncode == 0:
        _raise_ahk_safety_stop({
            'reason': 'missing_handshake_token',
            'field': expected_field,
            'method': 'stdin',
            'timeout_sec': timeout_sec,
            'returncode': process.returncode,
            'stdout_tail': _get_stream_tail(stdout, 200),
            'stderr_tail': _get_stream_tail(stderr, 200),
        }, level="ERROR")
    return {
        'reason': 'nonzero_exit',
        'field': expected_field,
        'method': 'stdin',
        'timeout_sec': timeout_sec,
        'returncode': process.returncode,
        'stdout_tail': _get_stream_tail(stdout, 200),
        'stderr_tail': _get_stream_tail(stderr, 200),
    }


def _run_ahk_script_via_file(full_script, done_token, expected_field, timeout_sec):
    temp_script_name = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.ahk', encoding='utf-8') as temp_script:
            temp_script_name = temp_script.name
            temp_script.write(full_script)
            temp_script.flush()
        process = subprocess.Popen(
            [MediBot_Preprocessor_lib.AHK_EXECUTABLE, temp_script_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=False
        )
        stdout, stderr, timed_out, _ = _bounded_communicate(process, timeout_sec)
        decoded_out = _decode_subprocess_stream(stdout)
        if timed_out:
            _raise_ahk_safety_stop({
                'reason': 'timeout',
                'field': expected_field,
                'method': 'file',
                'timeout_sec': timeout_sec,
                'stdout_tail': _get_stream_tail(stdout, 200),
                'stderr_tail': _get_stream_tail(stderr, 200),
            }, level="ERROR")
        if process.returncode != 0:
            _raise_ahk_safety_stop({
                'reason': 'nonzero_exit',
                'field': expected_field,
                'method': 'file',
                'timeout_sec': timeout_sec,
                'returncode': process.returncode,
                'stdout_tail': _get_stream_tail(stdout, 200),
                'stderr_tail': _get_stream_tail(stderr, 200),
            }, level="ERROR")
        if done_token not in decoded_out:
            _raise_ahk_safety_stop({
                'reason': 'missing_handshake_token',
                'field': expected_field,
                'method': 'file',
                'timeout_sec': timeout_sec,
                'returncode': process.returncode,
                'stdout_tail': _get_stream_tail(stdout, 200),
                'stderr_tail': _get_stream_tail(stderr, 200),
            }, level="ERROR")
    finally:
        if temp_script_name:
            try:
                os.unlink(temp_script_name)
            except Exception:
                pass


# Function to execute an AutoHotkey script
def run_ahk_script(script_content, expected_field):
    """
    Execute an AutoHotkey script using either optimized stdin method or traditional file method.
    Blocks until AHK confirms completion by writing a token to stdout.
    Automatically falls back to file method if stdin launch/execution fails before a safety stop.

    Future: Add optional burst mode to submit several send commands in one script, reducing
    process overhead while keeping a single completion token per burst.
    """
    done_token = "OK"
    timeout_sec = _get_ahk_exec_timeout_seconds()
    _assert_medisoft_foreground(expected_field)
    full_script = _build_ahk_script_with_handshake(script_content + "\r\n", done_token)
    if USE_AHK_STDIN_OPTIMIZATION:
        try:
            fallback_context = _run_ahk_script_via_stdin(
                full_script,
                done_token,
                expected_field,
                timeout_sec,
            )
            if fallback_context is None:
                return
            _log_ahk_safety_event(fallback_context, level="WARNING")
        except Exception as e:
            if isinstance(e, AHKSafetyStop):
                raise
            _log_ahk_safety_event({
                'reason': 'stdin_launch_failure',
                'field': expected_field,
                'method': 'stdin',
                'timeout_sec': timeout_sec,
                'stderr_tail': str(e),
            }, level="WARNING")

    _run_ahk_script_via_file(full_script, done_token, expected_field, timeout_sec)

# Module-scope context container for cross-callback state (XP/3.4.4 compatible)
try:
    # Avoid dataclasses to maintain 3.4.4 compatibility without external deps
    class MediBotContext(object):
        def __init__(self):
            self.last_processed_entry = None
            self.parsed_address_components = {}
            self.current_patient_context = None
    CTX = MediBotContext()
except Exception:
    # Fallback simple dict if class definition fails for any reason
    CTX = {
        'last_processed_entry': None,
        'parsed_address_components': {},
        'current_patient_context': None,
    }

# Backwards-compatible globals (maintain import contract for MediBot_UI and hotkeys)
last_processed_entry = None
parsed_address_components = {}
current_patient_context = None

def _service_line_input_is_diagnosis_field(medisoft_field, reverse_mapping):
    text = str(medisoft_field or '').strip()
    if text == 'Default Diagnosis #1':
        return True
    if isinstance(reverse_mapping, dict):
        header = str(reverse_mapping.get(medisoft_field) or '').strip()
        if header == 'Default Diagnosis #1':
            return True
    return False


def _service_line_input_row_patient_id(csv_row, reverse_mapping):
    if not isinstance(csv_row, dict):
        return ''
    for key in ('Patient ID #2', 'Patient ID 2', 'Patient ID', 'PATID', 'patid'):
        value = csv_row.get(key)
        if value:
            return str(value).strip()
    if isinstance(reverse_mapping, dict):
        for medisoft_field, csv_header in reverse_mapping.items():
            if str(medisoft_field or '').strip() in ('Patient ID #2', 'Patient ID 2', 'Patient ID'):
                value = csv_row.get(csv_header)
                if value:
                    return str(value).strip()
    return ''


def _service_line_input_row_dos(csv_row):
    if not isinstance(csv_row, dict):
        return ''
    for key in ('Surgery Date', 'Service Date', 'Date of Service', 'DOS', 'dos', 'DATE'):
        value = csv_row.get(key)
        if value:
            return _normalize_option_a_preview_date(value) or str(value).strip()
    return ''


def _service_line_input_hash_text(value):
    text = str(value or '')
    try:
        return hashlib.sha256(text.encode('utf-8')).hexdigest()[:12]
    except Exception:
        return hashlib.sha256(text.encode('latin-1', 'ignore')).hexdigest()[:12]


def _record_service_line_input_medisoft_handoff_event(config, event):
    try:
        medi = config.get('MediLink_Config', {}) if isinstance(config, dict) else {}
        local_storage_path = medi.get('local_storage_path') or ''
        if not local_storage_path:
            return
        telemetry_dir = os.path.join(local_storage_path, 'telemetry')
        if not os.path.isdir(telemetry_dir):
            os.makedirs(telemetry_dir)
        path = os.path.join(telemetry_dir, 'service_line_input_medisoft_handoff_events.jsonl')
        payload = dict(event or {})
        payload['schema_version'] = 'service_line_input_medisoft_handoff_event.v1'
        payload['workflow_name'] = SERVICE_LINE_INPUT_WORKFLOW_NAME
        payload['workflow_boundary'] = SERVICE_LINE_INPUT_WORKFLOW_BOUNDARY
        payload['claims_completion'] = False
        payload['mutates_billing_state'] = False
        payload['mutates_dat'] = False
        payload['mutates_837p'] = False
        payload['charges_entered'] = False
        payload['written_at_epoch'] = int(time.time())
        with open(path, 'a') as handle:
            handle.write(json.dumps(payload, sort_keys=True))
            handle.write('\n')
    except Exception:
        pass


def _service_line_input_medisoft_shorthand_for_diagnosis(value, crosswalk):
    text = str(value or '').strip()
    if not text:
        return '', 'empty_overlay_diagnosis'
    if ServiceLineInputModel is None:
        return '', 'service_line_input_model_unavailable'
    try:
        normalized = ServiceLineInputModel.normalize_diagnosis_code(text)
        bridge = ServiceLineInputModel.build_diagnosis_bridge_index(crosswalk or {})
    except Exception:
        return '', 'diagnosis_bridge_unavailable'
    if not normalized:
        return '', 'empty_overlay_diagnosis'
    if normalized in (bridge.get('ambiguous_shorthand') or {}):
        return '', 'ambiguous_diagnosis_to_medisoft_bridge'
    records = (bridge.get('by_any') or {}).get(normalized) or []
    if not records:
        return '', 'missing_diagnosis_to_medisoft_bridge'
    medisoft_values = []
    for record in records:
        value = str(record.get('medisoft_code') or '').strip().upper()
        if value and value not in medisoft_values:
            medisoft_values.append(value)
    if len(medisoft_values) != 1:
        return '', 'ambiguous_diagnosis_to_medisoft_bridge'
    return medisoft_values[0], ''


def _service_line_input_resolve_ahk_diagnosis_overlay(
        medisoft_field, value, csv_row, reverse_mapping, config, crosswalk):
    if not _service_line_input_is_diagnosis_field(medisoft_field, reverse_mapping):
        return value
    patient_id = _service_line_input_row_patient_id(csv_row, reverse_mapping)
    dos = _service_line_input_row_dos(csv_row)
    event = {
        'decision': 'normal_path',
        'medisoft_field': str(medisoft_field or ''),
        'patient_id_present': bool(patient_id),
        'dos_present': bool(dos),
    }
    if patient_id or dos:
        event['target_hash'] = _service_line_input_hash_text('{0}|{1}'.format(patient_id, dos))
    try:
        medi = config.get('MediLink_Config', {}) if isinstance(config, dict) else {}
        local_storage_path = medi.get('local_storage_path') or ''
        state = _load_service_line_input_state(local_storage_path) if local_storage_path else {}
        rows = state.get('rows', {}) if isinstance(state, dict) else {}
        row_key = _option_a_minutes_row_key(patient_id, dos)
        row = rows.get(row_key) if isinstance(rows, dict) else None
    except Exception:
        row = None
    if not isinstance(row, dict):
        _record_service_line_input_medisoft_handoff_event(config, event)
        return value
    diagnosis_source = str(row.get('diagnosis_source') or '').strip()
    if diagnosis_source not in ('operator_overlay', 'operator_crosswalk_intake'):
        event['decision'] = 'normal_path'
        event['overlay_diagnosis_source'] = diagnosis_source
        _record_service_line_input_medisoft_handoff_event(config, event)
        return value
    status = str(row.get('status') or '').strip().lower()
    if status not in ('entered', 'skipped'):
        event['decision'] = 'blocked'
        event['block_reason'] = 'overlay_status_not_entered_or_skipped'
        _record_service_line_input_medisoft_handoff_event(config, event)
        raise ValueError("Service Line Input diagnosis overlay exists but row status is not entry-safe.")
    if bool(row.get('claims_completion') or row.get('mutates_billing_state') or
            row.get('mutates_dat') or row.get('mutates_837p') or row.get('charges_entered')):
        event['decision'] = 'blocked'
        event['block_reason'] = 'overlay_boundary_not_clean'
        _record_service_line_input_medisoft_handoff_event(config, event)
        raise ValueError("Service Line Input diagnosis overlay has invalid workflow-boundary flags.")
    overlay_dx = row.get('diagnosis_code') or row.get('diagnosis') or ''
    medisoft_value, reason = _service_line_input_medisoft_shorthand_for_diagnosis(overlay_dx, crosswalk)
    event['overlay_diagnosis_source'] = diagnosis_source
    event['bridge_status'] = 'ok' if medisoft_value else reason
    if not medisoft_value:
        event['decision'] = 'blocked'
        event['block_reason'] = reason
        _record_service_line_input_medisoft_handoff_event(config, event)
        raise ValueError("Service Line Input diagnosis overlay cannot be converted to a Medisoft shorthand: {0}".format(reason))
    event['decision'] = 'applied'
    _record_service_line_input_medisoft_handoff_event(config, event)
    try:
        MediLink_ConfigLoader.log(
            "Service Line Input diagnosis overlay applied for AHK diagnosis field.",
            level="INFO",
        )
    except Exception:
        pass
    return medisoft_value


def process_field(medisoft_field, csv_row, parsed_address_components, reverse_mapping, csv_data, fixed_values,
                  config=None, crosswalk=None):
    global last_processed_entry
    
    try:
        # Attempt to retrieve the value for the current medisoft_field from parsed_address_components
        value = parsed_address_components.get(medisoft_field, '') if medisoft_field in parsed_address_components else ''
        
        # If no value is found, check if there is a fixed value available for this field
        if not value:
            if medisoft_field in fixed_values:
                value = fixed_values[medisoft_field][0]  # Use the fixed value if available
        
        # If still no value, check if the field is present in the reverse mapping
        if not value and medisoft_field in reverse_mapping:
            # Retrieve the corresponding CSV header from the reverse mapping
            csv_header = reverse_mapping[medisoft_field]
            value = csv_row.get(csv_header, '')  # Get the value from the CSV row using the header
            
            # Log the detected field and its value after assignment
            MediLink_ConfigLoader.log("Detected {}: {}".format(medisoft_field, value), level="DEBUG")

        value = _service_line_input_resolve_ahk_diagnosis_overlay(
            medisoft_field,
            value,
            csv_row,
            reverse_mapping,
            config,
            crosswalk,
        )

        # Format the value for the AutoHotkey script, or default to sending an Enter key if no value is found
        formatted_value = (MediBot_dataformat_library.format_data(medisoft_field, value, csv_data, reverse_mapping, parsed_address_components)
                           if value else 'Send, {Enter}')
        
        # Execute the AutoHotkey script with the formatted value
        run_ahk_script(formatted_value, medisoft_field)

        # Update the last processed entry with the current field and its value
        last_processed_entry = (medisoft_field, value)
        try:
            # Keep CTX in sync for consumers that adopt CTX
            if hasattr(CTX, 'last_processed_entry'):
                CTX.last_processed_entry = last_processed_entry
            else:
                CTX['last_processed_entry'] = last_processed_entry
        except Exception:
            pass
        return 'continue', last_processed_entry  # Indicate to continue processing
    except Exception as e:
        # Handle any exceptions that occur during processing
        return handle_error(e, medisoft_field, last_processed_entry, csv_data, reverse_mapping)

def handle_error(error, medisoft_field, last_processed_entry, csv_data, reverse_mapping):
    global current_patient_context
    try:
        MediLink_ConfigLoader.log("Error in process_field: {}".format(error), level="ERROR")
    except Exception:
        pass
    print("An error occurred while processing {0}: {1}".format(medisoft_field, error))
    
    # Update patient context with current error information for F11 menu
    if current_patient_context is None:
        current_patient_context = {}
    current_patient_context.update({
        'last_field': medisoft_field,
        'error_occurred': True,
        'error_message': str(error)
    })
    try:
        if hasattr(CTX, 'current_patient_context'):
            CTX.current_patient_context = current_patient_context
        else:
            CTX['current_patient_context'] = current_patient_context
    except Exception:
        pass
    
    # Assuming the interaction mode is 'error' in this case
    interaction_mode = 'error'
    response = user_interaction(csv_data, interaction_mode, str(error), reverse_mapping)
    return response, last_processed_entry

# iterating through each field defined in the field_mapping.
def iterate_fields(csv_row, field_mapping, parsed_address_components, reverse_mapping, csv_data, fixed_values,
                   config=None, crosswalk=None):
    global last_processed_entry
    # Check for user action at the start of each field processing
    for medisoft_field in field_mapping.keys():
        action = manage_script_pause(csv_data,'',reverse_mapping) # per-field pause availability. Necessary to provide frequent opportunities for the user to pause the script.
        if action != 0:  # If action is either 'Retry' (-1) or 'Skip' (1)
            return action  # Break out and pass the action up
        
        # Process each field in the row
        response, last_processed_entry = process_field(
            medisoft_field,
            csv_row,
            parsed_address_components,
            reverse_mapping,
            csv_data,
            fixed_values,
            config=config,
            crosswalk=crosswalk,
        )
        # Respect field-level control actions from process_field/user_interaction.
        if response in (-2, -1, 1):
            return response
        try:
            if hasattr(CTX, 'last_processed_entry'):
                CTX.last_processed_entry = last_processed_entry
            else:
                CTX['last_processed_entry'] = last_processed_entry
        except Exception:
            pass
        
    return 0 # Default action to continue

def _mark_charges_entered_if_possible(config, row, reverse_mapping):
    """
    Best-effort billing-status update after a row is fully entered in Medisoft.

    This marks charges_entered per DOS so downstream intake/reconciliation can
    reason about charge-entry progress without waiting for claim submission.
    """
    if not config or not isinstance(row, dict) or not isinstance(reverse_mapping, dict):
        return
    try:
        medilink_dir = os.path.join(project_dir, 'MediLink')
        if medilink_dir not in sys.path:
            sys.path.insert(0, medilink_dir)
        import MediLink_Scheduler as _billing_scheduler
        _billing_scheduler.mark_charges_entered_for_row(config, row, reverse_mapping)
    except Exception:
        # Never let billing-status bookkeeping block operator flow.
        pass


def data_entry_loop(csv_data, field_mapping, reverse_mapping, fixed_values, config=None, crosswalk=None):
    global last_processed_entry, parsed_address_components, current_patient_context
    # Do NOT convert these to locals. The F11 pause/retry menu and MediBot_UI depend on
    # these globals to reflect real-time state across callbacks and hotkey handlers.
    # last_processed_entry, parsed_address_components = None, {}  # This would break F11 context.
    error_message = ''  # Initialize error_message once
    current_row_index = 0
    # PERFORMANCE FIX: Cache list length to avoid repeated len() calls
    csv_data_length = len(csv_data)

    while current_row_index < csv_data_length:
        row = csv_data[current_row_index]
        
        # PERFORMANCE FIX: Clear accumulating memory while preserving F11 menu context
        # Store patient context before clearing last_processed_entry for F11 "Retry last entry" functionality
        if last_processed_entry is not None:
            patient_name = row.get(reverse_mapping.get('Patient Name', ''), 'Unknown Patient')
            surgery_date = row.get('Surgery Date', 'Unknown Date')
            current_patient_context = {
                'patient_name': patient_name,
                'surgery_date': surgery_date,
                'last_field': last_processed_entry[0] if last_processed_entry else None,
                'last_value': last_processed_entry[1] if last_processed_entry else None,
                'row_index': current_row_index
            }
            try:
                if hasattr(CTX, 'current_patient_context'):
                    CTX.current_patient_context = current_patient_context
                else:
                    CTX['current_patient_context'] = current_patient_context
            except Exception:
                pass
        
        # Clear memory-accumulating structures while preserving F11 context above
        last_processed_entry = None
        parsed_address_components = {}
        try:
            if hasattr(CTX, 'last_processed_entry'):
                CTX.last_processed_entry = None
                CTX.parsed_address_components = {}
            else:
                CTX['last_processed_entry'] = None
                CTX['parsed_address_components'] = {}
        except Exception:
            pass
        
        # Handle script pause at the start of each row (patient record). 
        manage_script_pause(csv_data, error_message, reverse_mapping)
        error_message = ''  # Clear error message for the next iteration
        
        if _ac() and _ac().get_pause_status():
            continue  # Skip processing this row if the script is paused

        # I feel like this is overwriting what would have already been idenfitied in the mapping. 
        # This probably needs to be initialized differently.
        # Note: parsed_address_components is now explicitly cleared above for performance
        # parsed_address_components = {'City': '', 'State': '', 'Zip Code': ''}
        # parsed_address_components = {}  # Moved to top of loop for memory management

        # Process each field in the row
        action = iterate_fields(
            row,
            field_mapping,
            parsed_address_components,
            reverse_mapping,
            csv_data,
            fixed_values,
            config=config,
            crosswalk=crosswalk,
        )
        # TODO (Low) add a feature here where if you accidentally started overwriting a patient that you could go back 2 patients.
        # Need to tell the user which patient we're talking about because it won't be obvious anymore.
        if action == -1:  # Retry
            continue  # Remain on the current row. 
        elif action == 1:  # Skip
            if current_row_index == len(csv_data) - 1:  # If it's the last row
                MediLink_ConfigLoader.log("Reached the end of the patient list.")
                print("Reached the end of the patient list. Looping back to the beginning.")
                current_row_index = 0  # Reset to the first row
            else:
                current_row_index += 1 # Move to the next row
            continue
        elif action == -2:  # Go back two patients and redo
            current_row_index = max(0, current_row_index - 2)  # Go back two rows, but not below 0
            continue

        # Row was entered without retry/skip: record charge-entry completion per DOS.
        _mark_charges_entered_if_possible(config, row, reverse_mapping)

        # Code to handle the end of a patient record
        # TODO One day this can just not pause...
        if _ac():
            _ac().set_pause_status(True)  # Pause at the end of processing each patient record
        
        # PERFORMANCE FIX: Explicit cleanup at end of patient processing
        # Clear global state to prevent accumulation over processing sessions
        # Note: current_patient_context is preserved for F11 menu functionality
        if current_row_index != len(csv_data) - 1:  # Not the last patient
            last_processed_entry = None
            parsed_address_components.clear()
            try:
                if hasattr(CTX, 'last_processed_entry'):
                    CTX.last_processed_entry = None
                    CTX.parsed_address_components = {}
                else:
                    CTX['last_processed_entry'] = None
                    CTX['parsed_address_components'] = {}
            except Exception:
                pass
            
        current_row_index += 1  # Move to the next row by default

def open_medisoft(shortcut_path):
    try:
        os.startfile(shortcut_path)
        print("Medisoft is being opened...\n")
    except subprocess.CalledProcessError as e:
        print("Failed to open Medisoft:", e)
        print("Please manually open Medisoft.")
    except Exception as e:
        print("An unexpected error occurred:", e)
        print("Please manually open Medisoft.")
    finally:
        print("Press 'F12' to begin data entry.")

# Placeholder for any cleanup
def cleanup():
    print("\n**** Medibot Finished! ****\n")
    # THis might need to delete the staging stuff that gets set up by mostly MediLink but maybe other stuff too.
    pass 

class ExecutionState:
    def __init__(self, config_path, crosswalk_path, preloaded_config=None, preloaded_crosswalk=None):
        """
        Initialize execution state with configuration.
        
        Args:
            config_path: Path to config file (used if preloaded_config is None)
            crosswalk_path: Path to crosswalk file (used if preloaded_crosswalk is None)
            preloaded_config: Optional pre-loaded config dict to avoid double-loading
            preloaded_crosswalk: Optional pre-loaded crosswalk dict to avoid double-loading
        """
        try:
            # Use pre-loaded values if provided, otherwise load from paths
            if preloaded_config is not None and preloaded_crosswalk is not None:
                config, crosswalk = preloaded_config, preloaded_crosswalk
                MediLink_ConfigLoader.log("Using pre-loaded configuration", level="DEBUG")
            else:
                config, crosswalk = MediLink_ConfigLoader.load_configuration(config_path, crosswalk_path)
                MediLink_ConfigLoader.log("Loaded configuration from paths", level="DEBUG")
            
            MediLink_ConfigLoader.log("Configuration type: {}".format(type(config)), level="DEBUG")
            self.verify_config_type(config)
            self.crosswalk = crosswalk
            self.config = config
            MediLink_ConfigLoader.log("Config loaded successfully...")

            # Get APIClient via factory
            try:
                from MediCafe.api_factory import APIClientFactory
                factory = APIClientFactory()
                self.api_client = factory.get_shared_client()  # Use shared client for token caching benefits
                MediLink_ConfigLoader.log("ExecutionState using API Factory with shared client", level="INFO")
            except ImportError as e:
                # Fallback to basic API client
                try:
                    from MediCafe.core_utils import get_api_client
                    self.api_client = get_api_client()
                    MediLink_ConfigLoader.log("ExecutionState using fallback API client", level="WARNING")
                except ImportError as e2:
                    self.api_client = None
            
            # Log before calling crosswalk_update
            if self.api_client is not None:
                MediLink_ConfigLoader.log("Updating crosswalk with client and config...", level="INFO")
                update_successful = crosswalk_update(self.api_client, config, crosswalk)
            else:
                MediLink_ConfigLoader.log("Skipping crosswalk update - API client not available", level="WARNING")
                update_successful = False
            if update_successful:
                MediLink_ConfigLoader.log("Crosswalk update completed successfully.", level="INFO")
                print("Crosswalk update completed successfully.")
            else:
                record_startup_error("Crosswalk update failed.")
            
            # Check for non-normal conditions from crosswalk update
            try:
                if MediBot_Crosswalk_Library and hasattr(MediBot_Crosswalk_Library, '_api_unavailability_detected'):
                    # Check if any endpoint is unavailable (set is truthy if non-empty)
                    if MediBot_Crosswalk_Library._api_unavailability_detected:
                        mark_non_normal_startup()
                if MediBot_Crosswalk_Library and hasattr(MediBot_Crosswalk_Library, '_mains_data_load_failed'):
                    if MediBot_Crosswalk_Library._mains_data_load_failed:
                        mark_non_normal_startup()
                if MediBot_Preprocessor_lib and hasattr(MediBot_Preprocessor_lib, '_mains_file_missing'):
                    if MediBot_Preprocessor_lib._mains_file_missing:
                        mark_non_normal_startup()
            except Exception:
                pass  # Don't let flag checking break startup

        except Exception as e:
            record_startup_error("MediBot: Failed to load or update configuration: {}".format(e))
            raise  # Re-throwing the exception or using a more sophisticated error handling mechanism might be needed
            # Handle the exception somehow (e.g., retry, halt, log)??
        
    def verify_config_type(self, config):
        MediLink_ConfigLoader.log("Verifying configuration type: {}".format(type(config)), level="DEBUG")
        if not isinstance(config, (dict, OrderedDict)):
            raise TypeError("Error: Configuration must be a dictionary or an OrderedDict. Check unpacking.")

# Import centralized logging configuration and timing utils
try:
    from MediCafe.logging_config import PERFORMANCE_LOGGING
except ImportError:
    PERFORMANCE_LOGGING = False
try:
    from MediCafe.performance_events import log_performance_event
except Exception:
    def log_performance_event(component, stage, elapsed_sec=None, elapsed_ms=None, details=None, level='INFO'):
        return None
try:
    from MediCafe.timing_utils import start_run, stage_timer, noop_timer, is_timing_enabled, get_storage_path
except ImportError:
    start_run = None
    stage_timer = None
    noop_timer = type('_Noop', (), {'__enter__': lambda self: self, '__exit__': lambda self, *a: False})()
    is_timing_enabled = None
    get_storage_path = None

def _elapsed_ms_since(start_time):
    try:
        return int((time.time() - start_time) * 1000)
    except Exception:
        return 0

def _record_timing_stage(run_id, workflow, stage, elapsed_ms, status='ok', meta=None):
    if not run_id:
        return
    try:
        from MediCafe.timing_utils import record_stage
        record_stage(run_id, workflow, stage, elapsed_ms, status=status, meta=meta)
    except Exception:
        pass

def _record_launch_to_banner(run_id):
    raw = os.environ.get('MEDICAFE_MEDIBOT_LAUNCH_T0_MS', '')
    try:
        start_ms = int(raw)
    except Exception:
        return
    elapsed_ms = int(time.time() * 1000) - start_ms
    if elapsed_ms < 0:
        return
    _record_timing_stage(
        run_id,
        'medibot',
        'launch_to_banner',
        elapsed_ms,
        meta={'from': 'Starting MediBot...', 'to': 'Welcome to MediBot banner'}
    )

# Main script execution wrapped in try-except for error handling
if __name__ == "__main__":
    _main_start_time = time.time()
    # Install unhandled exception hook to capture tracebacks
    try:
        if capture_unhandled_traceback is not None:
            sys.excepthook = capture_unhandled_traceback
    except Exception:
        pass

    e_state = None
    try:
        if PERFORMANCE_LOGGING:
            log_performance_event('medibot', 'initializing')
        
        # PROTECTION: Validate critical imports before proceeding
        import_valid, import_state = validate_critical_imports()
        if not import_valid:
            print("CRITICAL: Import validation failed. Cannot continue.")
            print("This indicates a fundamental system configuration issue.")
            print("Please check:")
            print("  1. All MediBot modules exist in the MediBot directory")
            print("  2. Python path is correctly configured")
            print("  3. No syntax errors in MediBot modules")
            sys.exit(1)
        
        # Default configuration paths
        json_dir = os.path.join(os.path.dirname(__file__), '..', 'json')
        default_config_path = os.path.join(json_dir, 'config.json')
        default_crosswalk_path = os.path.join(json_dir, 'crosswalk.json')
        
        # Use MediCafe configuration system
        preloaded_config, preloaded_crosswalk = None, None
        config_path, crosswalk_path = None, None
        
        _config_start_time = time.time()
        try:
            config_loader = get_config_loader_with_fallback()
            if config_loader and len(sys.argv) <= 1:
                preloaded_config, preloaded_crosswalk = config_loader.load_configuration()
            else:
                config_path = sys.argv[1] if len(sys.argv) > 1 else default_config_path
        except Exception:
            mark_non_normal_startup()  # Configuration loading failed
            config_path = sys.argv[1] if len(sys.argv) > 1 else default_config_path
        
        # Define crosswalk path if not pre-loaded
        if preloaded_crosswalk is None:
            crosswalk_path = sys.argv[2] if len(sys.argv) > 2 else default_crosswalk_path
        
        e_state = ExecutionState(config_path, crosswalk_path, preloaded_config, preloaded_crosswalk)
        _storage = get_storage_path(config=e_state.config, repo_root=project_dir) if get_storage_path else None
        run_id = start_run('medibot', storage_path=_storage) if (start_run and is_timing_enabled and is_timing_enabled()) else None
        _record_timing_stage(run_id, 'medibot', 'config_load', _elapsed_ms_since(_config_start_time))
        
        # Phase 3: Check and update OPTUMAI payer list (non-blocking)
        _payer_update_start_time = time.time()
        try:
            from MediCafe.payer_list_updater import update_optumai_payer_ids
            # Reuse ExecutionState's shared client for token caching benefits
            if e_state.api_client is not None:
                update_optumai_payer_ids(e_state.api_client, e_state.config, e_state.crosswalk, force=False)
        except Exception:
            mark_non_normal_startup()  # OPTUMAI payer list update failed
            # Silently skip on any error (non-blocking)
            pass
        _record_timing_stage(run_id, 'medibot', 'payer_list_update', _elapsed_ms_since(_payer_update_start_time))
        
        # Initialize constants from config
        _initialize_start_time = time.time()
        MediBot_Preprocessor_lib.initialize(e_state.config)
        _record_timing_stage(run_id, 'medibot', 'preprocessor_initialize', _elapsed_ms_since(_initialize_start_time))
        
        # PERFORMANCE OPTIMIZATION: Load both Medicare and Private patient databases during startup
        # Files are small (10K-20K rows each) so memory usage is minimal (~4MB total)
        # This eliminates the 1-2 second delay from user workflow entirely
        print("Loading patient databases...")
        MediLink_ConfigLoader.log("Loading patient databases...", level="INFO")
        
        _patient_db_start_time = time.time()
        try:
            medicare_path = e_state.config.get('MEDICARE_MAPAT_MED_PATH', "")
            private_path = e_state.config.get('MAPAT_MED_PATH', "")
            
            # Load both databases into separate caches
            medicare_cache = MediBot_Preprocessor.load_existing_patient_ids(medicare_path) if medicare_path else {}
            private_cache = MediBot_Preprocessor.load_existing_patient_ids(private_path) if private_path else {}
            
            # Store both caches for later use
            MediBot_Preprocessor.set_patient_caches(medicare_cache, private_cache)
            
            if PERFORMANCE_LOGGING:
                log_performance_event(
                    'medibot',
                    'patient_databases_loaded',
                    details={'medicare_patients': len(medicare_cache), 'private_patients': len(private_cache)},
                )
            MediLink_ConfigLoader.log("Patient databases loaded: {} Medicare, {} Private patients".format(
                len(medicare_cache), len(private_cache)), level="INFO")
                
        except Exception as e:
            mark_non_normal_startup()  # Patient database loading failed
            MediLink_ConfigLoader.log("Warning: Could not load patient databases: {}".format(e), level="WARNING")
            if PERFORMANCE_LOGGING:
                log_performance_event('medibot', 'patient_databases_load_failed', details={'fallback': 'load_on_demand'}, level='WARNING')
        _record_timing_stage(run_id, 'medibot', 'patient_db_load', _elapsed_ms_since(_patient_db_start_time))
        
        if PERFORMANCE_LOGGING:
            log_performance_event('medibot', 'csv_load_start')
        MediLink_ConfigLoader.log("Loading CSV Data...", level="INFO")
        _csv_load_start_time = time.time()
        csv_data = MediBot_Preprocessor_lib.load_csv_data(MediBot_Preprocessor_lib.CSV_FILE_PATH)
        _record_timing_stage(run_id, 'medibot', 'csv_load', _elapsed_ms_since(_csv_load_start_time))
        
        # Pre-process CSV data to add combined fields & crosswalk values
        if PERFORMANCE_LOGGING:
            log_performance_event('medibot', 'csv_preprocess_start')
        MediLink_ConfigLoader.log("Pre-processing CSV Data...", level="INFO")
        
        preprocessing_start_time = time.time()
        if PERFORMANCE_LOGGING:
            log_performance_event('medibot', 'csv_preprocess_started_at', details={'local_time': time.strftime("%H:%M:%S")})
        MediLink_ConfigLoader.log("Starting CSV preprocessing at: {}".format(time.strftime("%H:%M:%S")), level="INFO")

        _ctx = stage_timer(run_id, 'medibot', 'csv_preprocessing') if (run_id and stage_timer) else noop_timer

        # PROTECTION: Validate MediBot_Preprocessor before calling preprocess_csv_data
        if MediBot_Preprocessor is None:
            print("CRITICAL: MediBot_Preprocessor is None when trying to call preprocess_csv_data")
            print("This indicates the import failed silently during execution.")
            print("Import state at failure:")
            for module_name, module in import_state.items():
                status = "None" if module is None else "OK"
                print("  - {}: {}".format(module_name, status))
            print("Please check for syntax errors or missing dependencies in MediBot modules.")
            sys.exit(1)
        
        if not hasattr(MediBot_Preprocessor, 'preprocess_csv_data'):
            print("CRITICAL: MediBot_Preprocessor missing preprocess_csv_data function")
            print("Available functions: {}".format([attr for attr in dir(MediBot_Preprocessor) if not attr.startswith('_')]))
            sys.exit(1)

        with _ctx:
            MediBot_Preprocessor.preprocess_csv_data(csv_data, e_state.crosswalk)

        # TIMING: End CSV preprocessing timing
        preprocessing_end_time = time.time()
        preprocessing_duration = preprocessing_end_time - preprocessing_start_time
        if PERFORMANCE_LOGGING:
            log_performance_event(
                'medibot',
                'csv_preprocessing_complete',
                elapsed_sec=preprocessing_duration,
                details={'local_time': time.strftime("%H:%M:%S")},
            )
        MediLink_ConfigLoader.log("CSV preprocessing completed at: {} (Duration: {:.2f} seconds)".format(
            time.strftime("%H:%M:%S"), preprocessing_duration), level="INFO")

        if _handle_empty_preprocessed_csv(csv_data):
            try:
                from MediCafe.action_intent import (
                    mark_user_exit,
                    ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED,
                    ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS,
                )
                reason = ACTION_EXIT_REASON_INTAKE_NO_ELIGIBLE_ROWS
                if _empty_preprocessed_csv_shape_blocked():
                    reason = ACTION_EXIT_REASON_INTAKE_CSV_SHAPE_BLOCKED
                mark_user_exit(reason)
            except Exception:
                pass
            print("")
            if _empty_preprocessed_csv_shape_blocked():
                print("MediBot cannot continue: CSV_FILE_PATH does not look like the MediBot intake CSV.")
            else:
                print("MediBot cannot continue: no eligible patient rows remain after preprocessing.")
            print("Check: Patient ID column name (must match intake export, e.g. 'Patient ID'),")
            print("insurance exclusions, and CSV_FILE_PATH in config. Full filter summary is in the log.")
            print("")
            try:
                raw_input("Press Enter to return to the launcher...")
            except Exception:
                try:
                    input("Press Enter to return to the launcher...")
                except Exception:
                    pass
            sys.exit(0)
        
        headers = csv_data[0].keys()  # Ensure all headers are in place
        
        print("Running intake scan...")
        MediLink_ConfigLoader.log("Performing Intake Scan...", level="INFO")
        _intake_scan_start_time = time.time()
        identified_fields = MediBot_Preprocessor.intake_scan(headers, MediBot_Preprocessor_lib.field_mapping)
        _record_timing_stage(run_id, 'medibot', 'intake_scan', _elapsed_ms_since(_intake_scan_start_time))
        
        # Reverse the identified_fields mapping for lookup
        reverse_mapping = {v: k for k, v in identified_fields.items()}
        service_line_input_session_patient_info = build_service_line_input_session_patient_info_from_csv_rows(
            csv_data,
            reverse_mapping
        )
        
        # CSV Patient Triage
        interaction_mode = 'triage'  # Start in triage mode
        error_message = ""  # This will be filled if an error has occurred
        
        print("Load complete.")
        MediLink_ConfigLoader.log("Load Complete event triggered. Clearing console. Displaying Menu...", level="INFO")
        
        # If non-normal startup conditions were detected, pause before clearing screen
        if _non_normal_startup:
            print("\n" + "="*70)
            print("NON-NORMAL STARTUP CONDITIONS DETECTED")
            print("="*70)
            print("One or more issues were encountered during startup.")
            print("Please review the messages above before continuing.")
            print("="*70)
            raw_input("\nPress Enter to continue to the menu...")
        
        # Windows XP console buffer fix: Use cls with echo to reset buffer state
        # Add a debug switch to optionally skip clearing the console for debugging purposes
        CLEAR_CONSOLE_ON_LOAD = True  # Clear screen before menu for cleaner UI
        if CLEAR_CONSOLE_ON_LOAD:
            _ = os.system('cls && echo.')
            # Re-display critical startup notices so the user still sees them
            if STARTUP_NOTICES:
                print("Important notices from startup:")
                for lvl, msg in STARTUP_NOTICES:
                    try:
                        print("[{}] {}".format(lvl, msg))
                    except Exception:
                        print(msg)
                print("-" * 60)
        
        _record_timing_stage(run_id, 'medibot', 'startup_to_banner_ready', _elapsed_ms_since(_main_start_time))
        _record_launch_to_banner(run_id)
        proceed, selected_patient_ids, selected_indices, fixed_values, is_medicare = user_interaction(csv_data, interaction_mode, error_message, reverse_mapping)

        if proceed:
            # NOTE: Deductible v1.5 cache build happens during CSV intake (process_csvs),
            # not in this post-triage execution path.
            # Filter csv_data for selected patients from Triage mode
            csv_data = [row for index, row in enumerate(csv_data) if index in selected_indices]
            patient_id_field = reverse_mapping.get('Patient ID #2', '')
            rows_by_patient_id = {}
            if patient_id_field:
                for row in csv_data:
                    pid = row.get(patient_id_field)
                    if pid and pid not in rows_by_patient_id:
                        rows_by_patient_id[pid] = row
            
            # Check if MAPAT_MED_PATH is missing or invalid
            if (not _ac()) or (not _ac().get_mapat_med_path()) or (not os.path.exists(_ac().get_mapat_med_path())):
                record_startup_warning("Warning: MAPAT.MED PATH is missing or invalid. Please check the path configuration.")

            # PERFORMANCE OPTIMIZATION: Select the appropriate pre-loaded patient cache
            # Both caches were loaded during startup, now we just select the right one
            _run_with_stage_heartbeat(
                "Selecting {} patient cache".format("Medicare" if is_medicare else "Private"),
                lambda: MediBot_Preprocessor.select_active_cache(is_medicare)
            )
            if PERFORMANCE_LOGGING:
                log_performance_event(
                    'medibot',
                    'existing_patient_cache_selected',
                    details={'cache_type': "Medicare" if is_medicare else "Private"},
                )

            # Perform the existing patients check (now uses cached data)
            existing_patients, patients_to_process = _run_with_stage_heartbeat(
                "Checking existing patients",
                lambda: MediBot_Preprocessor.check_existing_patients(
                    selected_patient_ids,
                    _ac().get_mapat_med_path() if _ac() else ''
                )
            )
            
            # Initialize patient_info and table_title for notepad generation
            # These may be populated by existing_patients or remain empty
            patient_type = "MEDICARE" if is_medicare else "PRIVATE"
            patient_info = []
            table_title = "{} PATIENTS - EXISTING: No existing patients in this batch.".format(patient_type)
            
            if existing_patients:
                # Collect surgery dates and patient info for existing patients
                for patient_id, patient_name in existing_patients:
                    try:
                        # Find the row for this patient
                        patient_row = rows_by_patient_id.get(patient_id)
                        if patient_row is None:
                            raise ValueError("Patient row not found for patient ID: {}".format(patient_id))
                        
                        # Use helper function to create patient entries
                        patient_entries = create_patient_entries_from_row(patient_row, reverse_mapping)
                        patient_info.extend(patient_entries)
                            
                    except Exception as e:
                        MediLink_ConfigLoader.log("Warning: Error retrieving data for patient ID '{}': {}".format(patient_id, e), level="WARNING")
                        patient_info.append(('Unknown Date', patient_name, patient_id, 'N/A', None))  # Append with 'Unknown Date' if there's an error

                # Display existing patients table using the enhanced display function
                table_title = "{} PATIENTS - EXISTING: The following patient(s) already EXIST in the system but may have new dates of service.\n      Their diagnosis codes may need to be updated manually by the user to the following list:".format(patient_type)
                _run_with_stage_heartbeat(
                    "Rendering existing-patient table",
                    lambda: MediBot_UI.display_enhanced_patient_table(
                        patient_info,
                        table_title,
                        show_line_numbers=False,
                        config=e_state.config
                    )
                )
                
                # Existing patients should be shown in Notepad/reference tables only.
                # AHK intake must remain strictly limited to NEW patients to avoid
                # re-entering records that already exist in Medisoft.
                patients_to_process_set = set(patients_to_process)
                csv_data = [row for row in csv_data if row.get(patient_id_field) in patients_to_process_set]

            # Identify dual-date NEW patients for anticipatory display
            dual_date_new_patients = []
            for row in csv_data:
                if len(row.get('_all_surgery_dates', [])) > 1:
                    patient_entries = create_patient_entries_from_row(row, reverse_mapping)
                    dual_date_new_patients.extend(patient_entries)
            
            # Define dual-date title once if needed
            dual_date_title = "{} PATIENTS - DUAL DATE-OF-SERVICE (ANTICIPATORY): These patients have multiple dates of service.\n      After the first date is entered via AHK, they will become EXISTING patients and may need manual diagnosis updates:".format(patient_type) if dual_date_new_patients else None

            # Generate notepad file if there's content to display
            if patient_info or dual_date_new_patients:
                try:
                    if dual_date_new_patients:
                        notepad_file_path = _run_with_stage_heartbeat(
                            "Generating combined notepad reference table",
                            lambda: MediBot_Notepad_Utils.generate_combined_patients_notepad(
                                patient_info, table_title, dual_date_new_patients, dual_date_title, config=e_state.config
                            )
                        )
                    elif patient_info:
                        notepad_file_path = _run_with_stage_heartbeat(
                            "Generating existing-patient notepad reference table",
                            lambda: MediBot_Notepad_Utils.generate_existing_patients_notepad(
                                patient_info,
                                table_title,
                                config=e_state.config
                            )
                        )
                    else:
                        notepad_file_path = None

                    if notepad_file_path:
                        print("Patient reference table saved and opened in notepad: {}".format(notepad_file_path))
                except Exception as e:
                    print("Warning: Error creating notepad file: {}".format(e))

            # Display dual-date patients table on screen
            if dual_date_new_patients:
                _run_with_stage_heartbeat(
                    "Rendering dual-date anticipatory table",
                    lambda: MediBot_UI.display_enhanced_patient_table(
                        dual_date_new_patients,
                        dual_date_title,
                        show_line_numbers=False,
                        config=e_state.config
                    )
                )

            # Show NEW patients that will be processed (if any)
            new_patient_info = []
            if patients_to_process:
                # Collect surgery dates and patient info for NEW patients
                for row in csv_data:
                    # Use helper function to create patient entries
                    patient_entries = create_patient_entries_from_row(row, reverse_mapping)
                    new_patient_info.extend(patient_entries)

                # Display new patients table using the enhanced display function
                _run_with_stage_heartbeat(
                    "Rendering new-patient intake table",
                    lambda: MediBot_UI.display_enhanced_patient_table(
                        new_patient_info,
                        "{} PATIENTS - NEW: The following patient(s) will be automatically entered into Medisoft:".format(patient_type),
                        show_line_numbers=True,
                        config=e_state.config
                    )
                )

            service_line_input_patient_info = service_line_input_session_patient_info or new_patient_info
            service_line_input_docx_groups_available = False
            try:
                service_line_input_docx_groups_available = bool(
                    build_service_line_input_dos_groups_from_docx_index(
                        service_line_input_patient_info,
                        e_state.config
                    )
                )
            except Exception:
                service_line_input_docx_groups_available = False

            # Check if there are patients left to process
            if len(patients_to_process) == 0:
                if service_line_input_docx_groups_available:
                    try_preview = (input(
                        "\nOptional preview: open Service Line Input screen now? [y/N]: "
                    ) or "n").strip().lower()
                    if try_preview in ['y', 'yes']:
                        try:
                            run_service_line_input_multi_dos_entry(
                                service_line_input_patient_info,
                                e_state.config,
                                crosswalk=e_state.crosswalk
                            )
                        except Exception as e:
                            MediLink_ConfigLoader.log(
                                "Service Line Input failed: {}".format(e),
                                level="WARNING"
                            )
                proceed = input("\nAll patients have been processed. Continue anyway?: ").lower().strip() in ['yes', 'y']
            else:
                try_preview = (input(
                    "\nOptional preview: open Service Line Input screen now? [y/N]: "
                ) or "n").strip().lower()
                if try_preview in ['y', 'yes']:
                    try:
                        run_service_line_input_multi_dos_entry(
                            service_line_input_patient_info,
                            e_state.config,
                            crosswalk=e_state.crosswalk
                        )
                    except Exception as e:
                        MediLink_ConfigLoader.log(
                            "Service Line Input failed: {}".format(e),
                            level="WARNING"
                        )
                proceed = input("\nDo you want to proceed with entering {} new patient(s) into Medisoft? (yes/no): ".format(len(patients_to_process))).lower().strip() in ['yes', 'y']

            # Legacy MediBot_Charges / MediLink_Charges enrichment was quarantined.
            # Current charge work must stay on the Service Line Input preview-only boundary
            # unless a separate tested charge-entry workflow is designed.

            if proceed:
                print("\nRemember, when in Medisoft:")
                print("  Press 'F8'  to create a New Patient.")
                print("  Press 'F12' to begin data entry.")
                print("  Press 'F11' at any time to Pause.")
                print("\n*** Press [Enter] when ready to begin! ***")
                input()
                MediLink_ConfigLoader.log("Opening Medisoft...")
                open_medisoft(_ac().get_medisoft_shortcut() if _ac() else '')
                if _ac():
                    _ac().set_pause_status(True)
                _ = manage_script_pause(csv_data, error_message, reverse_mapping)
                data_entry_loop(
                    csv_data,
                    MediBot_Preprocessor_lib.field_mapping,
                    reverse_mapping,
                    fixed_values,
                    config=e_state.config,
                    crosswalk=e_state.crosswalk,
                )
                cleanup()                
            else:
                print("Data entry canceled by user. Exiting MediBot.")
    except Exception as e:
        if e_state:
            interaction_mode = 'error'  # Switch to error mode
            error_message = str(e)  # Capture the error message
        
        # ENHANCED ERROR DIAGNOSTICS
        print("\n" + "="*60)
        print("MEDIBOT EXECUTION FAILURE")
        print("=" * 60)
        print("Error: {}".format(e))
        print("Error type: {}".format(type(e).__name__))
        
        # Check for the specific failure pattern
        if "'NoneType' object has no attribute" in str(e):
            print("DIAGNOSIS: This is the import failure pattern.")
            print("A module import returned None, causing a method call to fail.")
            print("This typically indicates:")
            print("  1. Syntax error in a MediBot module")
            print("  2. Missing dependency")
            print("  3. Import path issue")
            print("  4. Circular import problem")
            
            # Show current import state
            print("Current import state:")
            try:
                import_state = {
                    'MediBot_Preprocessor': MediBot_Preprocessor,
                    'MediBot_Preprocessor_lib': MediBot_Preprocessor_lib,
                    'MediBot_UI': MediBot_UI,
                    'MediBot_Crosswalk_Library': MediBot_Crosswalk_Library
                }
                for module_name, module in import_state.items():
                    status = "None" if module is None else "OK"
                    print("  - {}: {}".format(module_name, status))
            except Exception as diag_e:
                print("  - Unable to diagnose import state: {}".format(diag_e))
        
        print("=" * 60)

        # Collect and submit error report
        try:
            if submit_support_bundle_email is not None:
                from MediCafe.error_reporter import collect_support_bundle, optional_error_report_manifest
                zip_path = collect_support_bundle(
                    include_traceback=True,
                    evidence_manifest=optional_error_report_manifest('medibot_startup_import_failure'),
                )
                if zip_path:
                    try:
                        from MediCafe.core_utils import check_internet_connection
                        online = check_internet_connection()
                    except ImportError:
                        # If we can't check connectivity during error reporting, assume offline
                        # to preserve the error bundle for later
                        online = False
                        print("Warning: Could not check internet connectivity - preserving error bundle.")
                    if online:
                        success = submit_support_bundle_email(zip_path)
                        if success:
                            # On success, remove the bundle
                            try:
                                os.remove(zip_path)
                            except Exception:
                                pass
                        else:
                            # Preserve bundle for manual retry
                            print("Error report send failed - bundle preserved at {} for retry.".format(zip_path))
                    else:
                        print("Offline - error bundle queued at {} for retry when online.".format(zip_path))
                else:
                    print("Failed to create error report bundle.")
            else:
                print("Error reporting not available - check MediCafe installation.")
        except Exception as report_e:
            print("Error report collection failed: {}".format(report_e))

        # Handle the error by calling user interaction with the error information
        if 'identified_fields' in locals():
            _ = user_interaction(csv_data, interaction_mode, error_message, reverse_mapping)
        else:
            print("Please ensure CSV headers match expected field names in config file, then re-run Medibot.")
