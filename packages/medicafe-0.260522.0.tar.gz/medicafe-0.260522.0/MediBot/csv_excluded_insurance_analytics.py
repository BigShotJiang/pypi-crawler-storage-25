import csv
import io
import json
import os
import time


EXCLUDED = set(['AETNA', 'AETNA MEDICARE', 'HUMANA MED HMO'])
TEMPORARY_OPENNESS_POLICY_NOTE = (
    'Temporary policy: excluded-insurance analytics remains intentionally open '
    'for design/stability validation and is expected to be obfuscated or reduced '
    'after implementation stabilizes.'
)


def _norm(v):
    return str(v or '').strip()


def _upper(v):
    return _norm(v).upper()


def analyze_csv_text(csv_text):
    rows = list(csv.DictReader(io.StringIO(csv_text or '')))
    excluded_rows = []
    for row in rows:
        if _upper(row.get('Primary Insurance')) in EXCLUDED:
            excluded_rows.append(row)
    cols = {}
    for row in excluded_rows:
        for k, v in row.items():
            key = _norm(k)
            if not key:
                continue
            bucket = cols.setdefault(key, {})
            token = _norm(v)
            if token:
                bucket[token] = bucket.get(token, 0) + 1
    top_patterns = {}
    for k, counts in cols.items():
        pairs = sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:10]
        top_patterns[k] = pairs
    return {
        'schema_version': 'csv_excluded_insurance_analytics.v1',
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'policy_note': TEMPORARY_OPENNESS_POLICY_NOTE,
        'input_rows': len(rows),
        'excluded_rows': len(excluded_rows),
        'excluded_insurance_values': sorted(list(EXCLUDED)),
        'column_top_patterns': top_patterns,
    }


def run(csv_path, report_dir):
    if not csv_path or not os.path.exists(csv_path):
        raise IOError('CSV path not found: {0}'.format(csv_path))
    with io.open(csv_path, 'r', encoding='utf-8-sig', newline='') as handle:
        text = handle.read()
    payload = analyze_csv_text(text)
    if not os.path.isdir(report_dir):
        os.makedirs(report_dir)
    json_path = os.path.join(report_dir, 'csv_excluded_insurance_analytics_latest.json')
    txt_path = os.path.join(report_dir, 'csv_excluded_insurance_analytics_latest.txt')
    with io.open(json_path, 'w', encoding='utf-8') as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
    with io.open(txt_path, 'w', encoding='utf-8') as handle:
        handle.write('CSV excluded-insurance retrospective analysis\n')
        handle.write('policy_note={0}\n'.format(payload.get('policy_note', '')))
        handle.write('input_rows={0}\n'.format(payload.get('input_rows', 0)))
        handle.write('excluded_rows={0}\n'.format(payload.get('excluded_rows', 0)))
        handle.write('\nTop deterministic patterns from excluded rows:\n')
        for col in sorted(payload.get('column_top_patterns', {}).keys()):
            handle.write('- {0}: '.format(col))
            pairs = payload['column_top_patterns'].get(col) or []
            if not pairs:
                handle.write('<none>\n')
                continue
            handle.write(', '.join(['{0} ({1})'.format(v, c) for v, c in pairs[:5]]) + '\n')
    return payload, {'json_path': json_path, 'txt_path': txt_path}
