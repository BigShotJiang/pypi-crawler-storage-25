#!/usr/bin/env python
from __future__ import print_function

import argparse
import os
import sys
import time


ACTIVE_STATUSES = (
    'evaluating_recommendation',
    'waiting_for_fresh_pipeline',
    'queued_send',
    'running_send',
    'running_diagnostic_action',
    'waiting_for_recommended_followup',
    'shutdown_requested',
)


def _parse_args(argv):
    parser = argparse.ArgumentParser(description='Reconcile post-update Cloud Readiness autofollow.')
    parser.add_argument('--repo-root', required=True)
    parser.add_argument('--installed-version', required=True)
    parser.add_argument('--max-sec', default='')
    parser.add_argument('--poll-sec', default='')
    return parser.parse_args(argv)


def _safe_int(value, default):
    try:
        return int(str(value or '').strip())
    except Exception:
        return default


class _Args(object):
    skip_csv = True
    direct_action = None
    debug_mode = False
    auto_choice = None


def main(argv=None):
    args = _parse_args(argv if argv is not None else sys.argv[1:])
    repo_root = os.path.abspath(str(args.repo_root or '').strip())
    version = str(args.installed_version or '').strip()
    if not repo_root or not version:
        return 2
    if repo_root not in sys.path:
        sys.path.insert(0, repo_root)

    from MediCafe.launcher import SessionConfig, MediCafeOrchestrator

    orch = MediCafeOrchestrator(SessionConfig(_Args()))
    max_sec = _safe_int(args.max_sec, orch._post_update_autofollow_stale_sec())
    poll_sec = _safe_int(args.poll_sec, orch._post_update_autofollow_watchdog_poll_sec())
    if max_sec < 60:
        max_sec = 60
    if poll_sec < 5:
        poll_sec = 5
    started = time.time()

    while True:
        try:
            state = orch._refresh_post_update_autofollow_state()
            if not isinstance(state, dict) or not state:
                return 0
            if version and str(state.get('installed_version', '') or '').strip() != version:
                return 0
            status = str(state.get('status', '') or '').strip()
            orch._patch_post_update_autofollow_state({
                'watchdog_mode': 'detached_reconciler',
                'reconciler_pid': str(os.getpid()),
                'reconciler_last_poll_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'reconciler_last_status': status,
            })
            if status not in ACTIVE_STATUSES:
                return 0
            if time.time() - started >= max_sec:
                orch._patch_post_update_autofollow_state({
                    'reconciler_status': 'timeout',
                    'reconciler_finished_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                    'last_reason': 'detached_reconciler_timeout',
                })
                return 1
        except Exception as exc:
            try:
                orch._patch_post_update_autofollow_state({
                    'reconciler_status': 'failed',
                    'reconciler_error': exc.__class__.__name__,
                    'reconciler_finished_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                })
            except Exception:
                pass
            return 1
        time.sleep(float(poll_sec))


if __name__ == '__main__':
    sys.exit(main())
