#!/usr/bin/env python
"""
Layer 1 join debug pack: deterministic parse-normalize-join diagnostics (CSV / DOCX / DAT).
XP-compatible: Python 3.4.4, stdlib only.

Not a readiness layer — narrow instrumentation at the annotate_csv_docx_join /
annotate_dat_csv_alignment boundary only.
"""
from __future__ import print_function

import hashlib
import json
import os
import re
import time

LAYER1_SCHEMA_VERSION = "layer1_join_debug_v1"
JOIN_KEY_POLICY = "patient_id+surgery_date"
RELAXED_DAT_POLICY = "debug_only_patid_date_before_payer_anchor"

SAMPLES_CAP_PER_KIND = 8
TOTAL_SAMPLES_CAP = 64


def _load_json_dict(text):
    try:
        data = json.loads(text or "{}")
    except (TypeError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _is_normalized_date_key_shape(value):
    text = str(value or "").strip()
    if not text:
        return False
    return bool(re.match(r"^[0-9]{2}-[0-9]{2}-[0-9]{4}$", text))


def _valid_normalized_date_key(value):
    text = str(value or "").strip()
    if not _is_normalized_date_key_shape(text):
        return False
    parts = text.split("-")
    if len(parts) != 3:
        return False
    return bool(_format_valid_date_key(parts[0], parts[1], parts[2]))


def _format_valid_date_key(month, day, year):
    try:
        m = int(month)
        d = int(day)
        y = int(year)
        if y < 1900 or y > 2099:
            return ""
        time.strptime("{0:04d}-{1:02d}-{2:02d}".format(y, m, d), "%Y-%m-%d")
        return "{0:02d}-{1:02d}-{2:04d}".format(m, d, y)
    except Exception:
        return ""


def _normalize_relaxed_dat_date_key(dos_raw, normalize_surgery_date_key_fn):
    """
    Relaxed DAT-only normalization for Layer 1 debug evidence.
    Keeps strict production policy unchanged by applying compact fallback parsing
    only when the shared normalizer does not yield MM-DD-YYYY.
    Supports YYYYMMDD and MMDDYY.
    """
    raw = str(dos_raw or "").strip()
    nk = ""
    try:
        nk = str(normalize_surgery_date_key_fn(raw) if callable(normalize_surgery_date_key_fn) else "").strip()
    except Exception:
        nk = ""
    if _valid_normalized_date_key(nk):
        return nk
    digits = re.sub(r"[^0-9]", "", raw)
    if len(digits) == 8:
        yyyy = digits[:4]
        mm = digits[4:6]
        dd = digits[6:8]
        if yyyy.isdigit() and mm.isdigit() and dd.isdigit():
            compact = _format_valid_date_key(mm, dd, yyyy)
            if compact:
                return compact
    if len(digits) == 6:
        mm = digits[:2]
        dd = digits[2:4]
        yy = digits[4:6]
        if mm.isdigit() and dd.isdigit() and yy.isdigit():
            try:
                y2 = int(yy)
                year = 2000 + y2 if y2 <= 69 else 1900 + y2
                compact = _format_valid_date_key(mm, dd, year)
                if compact:
                    return compact
            except Exception:
                pass
    return nk


def _normalize_relaxed_dat_date_key_with_meta(dos_raw, normalize_surgery_date_key_fn):
    """
    Debug-only relaxed DAT date normalization with compact-shape counters.
    Returns: (normalized_key, compact_kind)
      compact_kind in {"yyyymmdd", "mmddyy", "invalid", ""}
    """
    raw = str(dos_raw or "").strip()
    nk = ""
    try:
        nk = str(normalize_surgery_date_key_fn(raw) if callable(normalize_surgery_date_key_fn) else "").strip()
    except Exception:
        nk = ""
    if _valid_normalized_date_key(nk):
        return nk, ""

    digits = re.sub(r"[^0-9]", "", raw)
    if len(digits) == 8:
        yyyy = digits[:4]
        mm = digits[4:6]
        dd = digits[6:8]
        if yyyy.isdigit() and mm.isdigit() and dd.isdigit():
            compact = _format_valid_date_key(mm, dd, yyyy)
            if compact:
                return compact, "yyyymmdd"
        return nk, "invalid"
    if len(digits) == 6:
        mm = digits[:2]
        dd = digits[2:4]
        yy = digits[4:6]
        if mm.isdigit() and dd.isdigit() and yy.isdigit():
            try:
                y2 = int(yy)
                year = 2000 + y2 if y2 <= 69 else 1900 + y2
                compact = _format_valid_date_key(mm, dd, year)
                if compact:
                    return compact, "mmddyy"
            except Exception:
                pass
        return nk, "invalid"
    if digits:
        return nk, "invalid"
    return nk, ""


def _sanitize_ext_piece(suffix):
    """Keep a short extension fragment for telemetry; alphanumeric + dot only."""
    out = []
    try:
        for c in str(suffix or "").lower()[:16]:
            if c.isalnum() or c == ".":
                out.append(c)
    except Exception:
        return ""
    return "".join(out)


def _source_locator_evidence_token(locator_or_path):
    """
    Redacted locator sketch for support JSONL: SHA-256 prefix + extension +
    coarse shape (UTF-8 byte length, path segment count). Never embeds basename
    text (filenames often carry names, MRNs, or chart tokens).
    """
    s = ""
    try:
        s = str(locator_or_path or "").strip().replace("\\", "/")
    except Exception:
        s = ""
    if not s:
        return "h16:|ext:|path_bytes:0|segments:0"
    slash = s.rfind("/")
    dot = s.rfind(".")
    ext = "(none)"
    if dot > slash:
        ext = _sanitize_ext_piece(s[dot:])
        if not ext.startswith(".") or len(ext) < 2:
            ext = "(none)"
    try:
        b = len(s.encode("utf-8"))
    except Exception:
        b = len(s)
    seg_n = 0
    try:
        for part in s.split("/"):
            if part:
                seg_n += 1
    except Exception:
        seg_n = 0
    h = _sha16("layer1_source_locator|{0}".format(s))
    return "h16:{0}|ext:{1}|path_bytes:{2}|segments:{3}".format(h, ext, b, seg_n)


def _sha16(text):
    h = hashlib.sha256()
    try:
        h.update((text or "").encode("utf-8"))
    except Exception:
        h.update(b"")
    return h.hexdigest()[:16]


def _patient_id_token(pid, classify_fn):
    if pid is None or str(pid).strip() == "":
        return {"shape": "empty", "diag_token": "external_id_missing", "raw_len": 0}
    diag = classify_fn(pid, "layer1_join_debug") if callable(classify_fn) else {}
    if not isinstance(diag, dict):
        diag = {}
    if diag.get("is_valid"):
        return {
            "shape": "digits5_valid",
            "diag_token": "external_id_digits5",
            "raw_len": _to_int(diag.get("length"), len(str(pid).strip())),
        }
    reason = str(diag.get("reason") or "invalid").strip() or "invalid"
    fam = str(diag.get("pattern_family") or "").strip()
    pk = "{0}:{1}".format(reason, fam) if fam else reason
    return {
        "shape": "invalid",
        "diag_token": pk[:80],
        "raw_len": _to_int(diag.get("length"), len(str(pid).strip())),
    }


def _join_key_token(norm_key):
    if not norm_key:
        return ""
    parts = str(norm_key).split("|", 1)
    pid_tok = _sha16("pid|{0}".format(parts[0] if parts else ""))
    date_part = parts[1] if len(parts) > 1 else ""
    return "{0}|{1}".format(pid_tok, date_part)


def _csv_docx_join_key(extract_external_patient_id_fn, normalize_surgery_date_key_fn, row):
    pid = ""
    nk = ""
    try:
        pid = extract_external_patient_id_fn(row) if callable(extract_external_patient_id_fn) else ""
        dt_raw = ""
        try:
            from patient_field_mapper import extract_surgery_date

            dt_raw = extract_surgery_date(row) if isinstance(row, dict) else ""
        except Exception:
            dt_raw = ""
        nk = normalize_surgery_date_key_fn(dt_raw) if callable(normalize_surgery_date_key_fn) else ""
    except Exception:
        pid = ""
        nk = ""
    pid = str(pid or "").strip()
    nk = str(nk or "").strip()
    if not pid or not nk:
        return ""
    return "{0}|{1}".format(pid, nk)


def _verified_external_patient_id(mapping):
    if not isinstance(mapping, dict):
        return ""
    value = str(mapping.get("external_patient_id_verified_resolved") or "").strip()
    if not value:
        return ""
    try:
        from patient_field_mapper import is_valid_external_patient_id_5_digit
        if is_valid_external_patient_id_5_digit(value):
            return value
    except Exception:
        if len(value) == 5 and value.isdigit():
            return value
    return ""


def _docx_join_key_from_rec(rec, normalize_surgery_date_key_fn):
    provenance = _load_json_dict(rec.get("provenance_json"))
    data = _load_json_dict(rec.get("canonical_json"))
    pid = (
        _verified_external_patient_id(data)
        or _verified_external_patient_id(provenance)
        or str(provenance.get("patient_id") or data.get("patient_id") or "").strip()
    )
    sk = provenance.get("schedule_key") or data.get("schedule_key")
    nk = ""
    try:
        nk = normalize_surgery_date_key_fn(sk) if callable(normalize_surgery_date_key_fn) else ""
    except Exception:
        nk = ""
    nk = str(nk or "").strip()
    if not pid or not nk:
        return ""
    return "{0}|{1}".format(pid, nk)


def _dat_join_key_extract(rec, extract_dat_identity_fn, normalize_surgery_date_key_fn):
    """
    resolve_dat-backed patient id + date from canonical dat_record.
    extract_dat_identity_fn(rec) -> (pid, dos_raw); default uses join_contract.
    """
    data = _load_json_dict(rec.get("canonical_json"))
    provenance = _load_json_dict(rec.get("provenance_json"))
    if callable(extract_dat_identity_fn):
        pid, dos_raw = extract_dat_identity_fn(data)
    else:
        pid, dos_raw = "", ""
    pid = str(pid or "").strip()
    nk = ""
    try:
        nk = normalize_surgery_date_key_fn(dos_raw) if callable(normalize_surgery_date_key_fn) else ""
    except Exception:
        nk = ""
    nk = str(nk or "").strip()
    if not pid or not nk:
        return "", dos_raw or "", nk, provenance
    return "{0}|{1}".format(pid, nk), dos_raw or "", nk, provenance


def _infer_source_class(canonical_type):
    ct = str(canonical_type or "").strip().lower()
    if ct == "patient_csv_row":
        return "csv"
    if ct == "docx_schedule":
        return "docx"
    if ct == "dat_record":
        return "dat"
    return "other"


def _patient_id_source_alias(source_class):
    if source_class == "csv":
        return "patient_csv_row.Patient ID"
    if source_class == "docx":
        return "docx_schedule.patient_id"
    if source_class == "dat":
        return "dat_record.patient_id"
    return "external_patient_id"


def _fallback_patient_id_source_contract(source_alias):
    lower = str(source_alias or "").strip().lower()
    if lower in ("patient_csv_row.patient id", "patient_csv_row.patient_id"):
        return "medibot_csv_patient_id_field"
    if lower in ("docx_schedule.patient_id", "docx_schedule.patient id"):
        return "medibot_docx_patient_id_field"
    if lower in ("dat_record.patient_id", "dat_record.patid", "dat_record.chart"):
        return "medilink_dat_patient_id_field"
    if lower.endswith(".patient id") or lower.endswith(".patient_id"):
        return "patient_id_field"
    return "other_patient_id_source"


def _fallback_patient_id_contract_disposition(diag):
    d = diag if isinstance(diag, dict) else {}
    if d.get("is_valid"):
        return "valid_five_digit"
    family = str(d.get("pattern_family") or "").strip().lower()
    reason = str(d.get("reason") or "").strip().lower()
    if not family or family in ("empty", "missing", "whitespace"):
        return "missing_or_blank"
    if d.get("decimal_coerced"):
        return "lossless_decimal_normalized"
    if d.get("embedded_coerced"):
        return "unambiguous_embedded_5_digit_normalized"
    if family in ("embedded_text", "non_digit", "non_numeric", "embedded_5_digit"):
        return "patient_id_field_contains_display_text_or_wrong_column"
    if family in ("too_short", "too_long", "wrong_length") or reason == "wrong_length":
        return "numeric_wrong_length"
    if family in ("decimal_like", "punctuated"):
        return "decimal_or_punctuated_not_lossless"
    return "invalid_external_patient_id_other"


def _inc_int(mapping, key, amount):
    if not isinstance(mapping, dict):
        return
    k = str(key or "").strip() or "unknown"
    mapping[k] = _to_int(mapping.get(k), 0) + _to_int(amount, 0)


def _format_dict_counts(mapping):
    if not isinstance(mapping, dict) or not mapping:
        return "-"
    parts = []
    for key in sorted(mapping.keys()):
        parts.append("{0}:{1}".format(str(key), _to_int(mapping.get(key), 0)))
    return ",".join(parts)


def _count_multimap(keys_seq):
    m = {}
    for k in keys_seq:
        kk = str(k or "").strip()
        if not kk:
            continue
        m[kk] = m.get(kk, 0) + 1
    return m


def _ambiguous_distinct_keys(mm):
    return len([kk for kk, c in mm.items() if _to_int(c, 0) > 1])


def _source_inventory(canonical_records, ingress_stats, patient_field_mapper_mod, join_extract_fn):
    extract_pid = getattr(patient_field_mapper_mod, "extract_external_patient_id", lambda r: "")
    extract_surgery = getattr(patient_field_mapper_mod, "extract_surgery_date", lambda r: "")
    norm_date = getattr(patient_field_mapper_mod, "normalize_surgery_date_key", lambda v: "")
    is_valid = getattr(patient_field_mapper_mod, "is_valid_external_patient_id_5_digit", lambda v: False)
    classify_fn = getattr(patient_field_mapper_mod, "classify_external_patient_id_5_digit", lambda v, s=None: {})

    inv = {}
    classes = ("csv", "docx", "dat")
    for c in classes:
        inv[c] = {
            "total_canonical_records": 0,
            "keyable_records": 0,
            "missing_patient_id": 0,
            "invalid_patient_id": 0,
            "invalid_patient_id_by_contract_disposition": {},
            "leading_zero_loss_candidate_count": 0,
            "missing_date": 0,
            "parse_rejected_artifacts": 0,
            "artifacts_processed": 0,
        }

    stats = ingress_stats if isinstance(ingress_stats, dict) else {}
    for c in classes:
        block = stats.get(c) if isinstance(stats.get(c), dict) else {}
        inv[c]["parse_rejected_artifacts"] = _to_int(block.get("parse_rejected_artifacts"), 0)
        inv[c]["artifacts_processed"] = _to_int(block.get("artifacts_processed"), 0)

    for rec in canonical_records or []:
        sc = _infer_source_class(rec.get("canonical_type") or "")
        if sc not in inv:
            continue
        bucket = inv[sc]
        bucket["total_canonical_records"] += 1
        cid = ""

        raw = _load_json_dict(rec.get("canonical_json"))

        pid = ""
        dos_raw = ""

        keyable = False
        missing_pid = False
        invalid_pid = False
        missing_date = False

        try:
            if sc == "csv":
                pid = str(extract_pid(raw) if callable(extract_pid) else "").strip()
                dos_raw = str(extract_surgery(raw) if callable(extract_surgery) else "").strip()
            elif sc == "docx":
                prov_inner = _load_json_dict(rec.get("provenance_json"))
                pid = (
                    _verified_external_patient_id(raw)
                    or _verified_external_patient_id(prov_inner)
                    or str(prov_inner.get("patient_id") or raw.get("patient_id") or "").strip()
                )
                sk_in = prov_inner.get("schedule_key") or raw.get("schedule_key")
                dos_raw = str(sk_in or "").strip()
            else:
                pid, dos_raw = join_extract_fn(raw) if callable(join_extract_fn) else ("", "")
                pid = str(pid or "").strip()
                dos_raw = str(dos_raw or "").strip()

            nk = ""
            try:
                nk = str(norm_date(dos_raw) if callable(norm_date) else "").strip()
            except Exception:
                nk = ""

            if not pid:
                missing_pid = True
            elif callable(is_valid) and not is_valid(pid):
                invalid_pid = True
            if not nk:
                missing_date = True

            if sc == "csv":
                jk_inner = ""
                try:
                    jk_inner = _csv_docx_join_key(extract_pid, norm_date, raw)
                except Exception:
                    jk_inner = ""
                keyable = bool(jk_inner)
            elif sc == "docx":
                keyable = bool(_docx_join_key_from_rec(rec, norm_date))
            else:
                jk_inner = ""
                try:
                    jk_inner, _, __, ___ = _dat_join_key_extract(rec, join_extract_fn, norm_date)
                except Exception:
                    jk_inner = ""
                keyable = bool(jk_inner)

        except Exception:
            missing_pid = True
            missing_date = True
            keyable = False

        if keyable:
            bucket["keyable_records"] += 1
        if missing_pid:
            bucket["missing_patient_id"] += 1
        if invalid_pid:
            bucket["invalid_patient_id"] += 1
            try:
                source_alias = _patient_id_source_alias(sc)
                diag = classify_fn(pid, source_alias) if callable(classify_fn) else {}
                if not isinstance(diag, dict):
                    diag = {}
                disposition_fn = getattr(
                    patient_field_mapper_mod,
                    "external_patient_id_contract_disposition",
                    _fallback_patient_id_contract_disposition)
                disposition = disposition_fn(diag) if callable(disposition_fn) else _fallback_patient_id_contract_disposition(diag)
                _inc_int(bucket["invalid_patient_id_by_contract_disposition"], disposition, 1)
                if bool(diag.get("leading_zero_loss_candidate")):
                    bucket["leading_zero_loss_candidate_count"] += 1
            except Exception:
                _inc_int(bucket["invalid_patient_id_by_contract_disposition"], "invalid_external_patient_id_other", 1)
        if missing_date:
            bucket["missing_date"] += 1

    return inv, {
        "extract_external_patient_id": extract_pid,
        "normalize_surgery_date_key": norm_date,
        "is_valid_external_patient_id_5_digit": is_valid,
        "classify_external_patient_id_5_digit": classify_fn,
        "extract_dat_join_identity": join_extract_fn,
    }


def _invalid_patient_id_breakdowns_from_inventory(inv, patient_field_mapper_mod):
    by_source_contract = {}
    by_disposition = {}
    leading_zero_by_source = {}
    source_contract_fn = getattr(
        patient_field_mapper_mod,
        "external_patient_id_source_contract",
        _fallback_patient_id_source_contract)
    for sc in ("csv", "docx", "dat"):
        bucket = inv.get(sc) if isinstance(inv, dict) else {}
        if not isinstance(bucket, dict):
            bucket = {}
        invalid_count = _to_int(bucket.get("invalid_patient_id"), 0)
        source_alias = _patient_id_source_alias(sc)
        try:
            source_contract = source_contract_fn(source_alias) if callable(source_contract_fn) else _fallback_patient_id_source_contract(source_alias)
        except Exception:
            source_contract = _fallback_patient_id_source_contract(source_alias)
        if invalid_count > 0:
            _inc_int(by_source_contract, source_contract, invalid_count)
        disp_counts = bucket.get("invalid_patient_id_by_contract_disposition")
        if isinstance(disp_counts, dict):
            for key, value in disp_counts.items():
                _inc_int(by_disposition, key, value)
        lz_count = _to_int(bucket.get("leading_zero_loss_candidate_count"), 0)
        if lz_count > 0:
            _inc_int(leading_zero_by_source, source_contract, lz_count)
    return by_source_contract, by_disposition, leading_zero_by_source


def _overlap_metrics(csv_keys, docx_keys, dat_keys):
    """
    Arguments are flattened per-record join-key lists (empty strings filtered by callers).
    """
    scsv = set(csv_keys or [])
    sdoc = set(docx_keys or [])
    sdat = set(dat_keys or [])

    return {
        "csv_docx": len(scsv & sdoc),
        "dat_csv": len(sdat & scsv),
        "dat_docx": len(sdat & sdoc),
        "all_three": len(scsv & sdoc & sdat),
        "csv_only": len(scsv - sdoc - sdat),
        "docx_only": len(sdoc - scsv - sdat),
        "dat_only": len(sdat - scsv - sdoc),
    }


def _dat_relaxed_candidate_stats(relaxed_dat_records, csv_keys, docx_keys, helpers, join_extract_fn):
    """
    Debug-only DAT join candidates from parsed DAT rows that may have failed strict QA.
    These are never canonical records; they only tell support whether PATID+DATE would
    have joined before payer-anchor / relational-depth rules were applied.
    """
    norm_date = helpers["normalize_surgery_date_key"]
    is_valid = helpers["is_valid_external_patient_id_5_digit"]
    csv_set = set([k for k in csv_keys or [] if k])
    docx_set = set([k for k in docx_keys or [] if k])
    out = {
        "policy": RELAXED_DAT_POLICY,
        "total_records": 0,
        "dat_parsed_rows": 0,
        "dat_patid_present": 0,
        "dat_date_present": 0,
        "dat_patid_date_keyable": 0,
        "dat_relaxed_csv_overlap": 0,
        "dat_payer_id_missing": 0,
        "dat_iname_present_payer_missing": 0,
        "dat_chart_present_patid_missing": 0,
        "dat_date_unparseable_by_shape": 0,
        "dat_date_compact_yyyymmdd_normalized": 0,
        "dat_date_compact_mmddyy_normalized": 0,
        "dat_date_compact_invalid": 0,
        "keyable_records": 0,
        "distinct_normalized_key_count": 0,
        "csv_overlap_count": 0,
        "docx_overlap_count": 0,
        "missing_patient_id": 0,
        "invalid_patient_id": 0,
        "missing_date": 0,
        "payer_anchor_missing_count": 0,
        "insurance_name_present_payer_missing_count": 0,
    }
    keys = []
    for rec in relaxed_dat_records or []:
        raw = _load_json_dict(rec.get("canonical_json"))
        out["total_records"] += 1
        out["dat_parsed_rows"] += 1
        try:
            pid, dos_raw = join_extract_fn(raw) if callable(join_extract_fn) else ("", "")
        except Exception:
            pid, dos_raw = "", ""
        pid = str(pid or "").strip()
        dos_raw = str(dos_raw or "").strip()
        if pid:
            out["dat_patid_present"] += 1
        if dos_raw:
            out["dat_date_present"] += 1
        nk, compact_kind = _normalize_relaxed_dat_date_key_with_meta(dos_raw, norm_date)
        if compact_kind == "yyyymmdd":
            out["dat_date_compact_yyyymmdd_normalized"] += 1
        elif compact_kind == "mmddyy":
            out["dat_date_compact_mmddyy_normalized"] += 1
        elif compact_kind == "invalid":
            out["dat_date_compact_invalid"] += 1
        if dos_raw and not _valid_normalized_date_key(nk):
            out["dat_date_unparseable_by_shape"] += 1
            nk = ""
        if not pid:
            out["missing_patient_id"] += 1
        elif callable(is_valid) and not is_valid(pid):
            out["invalid_patient_id"] += 1
        if not nk:
            out["missing_date"] += 1
        if pid and nk:
            jk = "{0}|{1}".format(pid, nk)
            keys.append(jk)
            out["keyable_records"] += 1
            out["dat_patid_date_keyable"] += 1
        try:
            from dat_contract import resolve_dat_fields
            resolved = resolve_dat_fields(raw)
            if not str(resolved.get("payer_id") or "").strip():
                out["dat_payer_id_missing"] += 1
            if str(pid or "").strip() and not str(resolved.get("payer_id") or "").strip():
                out["payer_anchor_missing_count"] += 1
                if str(resolved.get("insurance_name") or raw.get("INAME") or raw.get("insurance_name") or "").strip():
                    out["insurance_name_present_payer_missing_count"] += 1
                    out["dat_iname_present_payer_missing"] += 1
            if str(resolved.get("chart_number") or raw.get("CHART") or "").strip() and not str(pid or "").strip():
                out["dat_chart_present_patid_missing"] += 1
        except Exception:
            pass
    key_set = set(keys)
    out["distinct_normalized_key_count"] = len(key_set)
    out["csv_overlap_count"] = len(key_set & csv_set)
    out["docx_overlap_count"] = len(key_set & docx_set)
    out["dat_relaxed_csv_overlap"] = out["csv_overlap_count"]
    return out, keys


def _normalized_key_presence(canonical_records, helpers):
    """Distinct join keys contributed by each source."""
    extract_pid = helpers["extract_external_patient_id"]
    norm_date = helpers["normalize_surgery_date_key"]
    extract_dat_join = helpers.get("extract_dat_join_identity")

    ckeys = []
    dkeys = []
    xkeys = []
    extract_dat = None
    try:
        from join_contract import extract_dat_join_identity
        extract_dat = extract_dat_join_identity
    except Exception:
        extract_dat = extract_dat_join

    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        raw = _load_json_dict(rec.get("canonical_json"))
        if ctype == "patient_csv_row":
            try:
                from patient_field_mapper import extract_surgery_date
                jk = _csv_docx_join_key(extract_pid, norm_date, raw)
                if jk:
                    ckeys.append(jk)
            except Exception:
                pass
        elif ctype == "docx_schedule":
            jk = _docx_join_key_from_rec(rec, norm_date)
            if jk:
                xkeys.append(jk)
        elif ctype == "dat_record":
            jk = ""
            try:
                jk, _, __, ___ = _dat_join_key_extract(rec, extract_dat, norm_date)
            except Exception:
                jk = ""
            if jk:
                dkeys.append(jk)

    return {
        "csv_distinct_normalized_key_count": len(set(ckeys)),
        "docx_distinct_normalized_key_count": len(set(xkeys)),
        "dat_distinct_normalized_key_count": len(set(dkeys)),
    }


def compute_layer1_support_bundle_attachment_recommended(
        summary_fragment,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        phase_d_ok=True,
        recommendation_kind=""):
    """
    True when run-evidence/support bundle should attach Layer 1 artifacts.
    """
    csv_docx_join_telemetry = csv_docx_join_telemetry or {}
    dat_csv_join_telemetry = dat_csv_join_telemetry or {}

    rk = str(recommendation_kind or "").strip()
    if rk == "review_dat_qa_full_block":
        return bool(summary_fragment.get("layer1_join_debug_generated"))

    if not summary_fragment.get("layer1_join_debug_generated"):
        return False

    if not phase_d_ok:
        return True

    cmat = _to_int(csv_docx_join_telemetry.get("matched_count"), 0)
    dmat = _to_int(dat_csv_join_telemetry.get("matched_count"), 0)
    if _to_int(summary_fragment.get("layer1_invalid_external_pressure"), 0) > 0:
        return True
    # zero overlap pressure
    ck = _to_int(csv_docx_join_telemetry.get("csv_join_key_count"), 0)
    dk = _to_int(csv_docx_join_telemetry.get("docx_join_key_count"), 0)
    if ck > 0 and dk > 0 and cmat == 0:
        return True
    dk2 = _to_int(summary_fragment.get("layer1_dat_keyable_count"), 0)
    dk_csv = _to_int(dat_csv_join_telemetry.get("dat_only_count"), 0)
    crc = _to_int(csv_docx_join_telemetry.get("csv_join_key_count"), 0)
    if crc > 0 and dk2 > 0 and dmat == 0:
        return True
    invalid_join = _to_int(dat_csv_join_telemetry.get("invalid_external_id_join_block_count"), 0)
    if invalid_join > 0:
        return True
    tb = str(summary_fragment.get("layer1_top_blocker") or "").strip()
    if tb:
        high_signal = (
            "dat_parse_rejects",
            "dat_zero_selected",
            "invalid_external_patient_id",
            "missing_dos",
            "csv_docx_zero_overlap",
            "dat_csv_zero_overlap",
            "ambiguous_join_keys",
        )
        if tb in high_signal:
            return True
    return False


def _rank_blockers(
        ingress_stats,
        source_inv,
        overlap,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        normalized_key_presence,
        _dat_keyable_count_unused,
        relaxed_dat_stats=None,
):
    blockers = []
    agg = ingress_stats if isinstance(ingress_stats, dict) else {}
    dat_parse = _to_int((agg.get("dat") or {}).get("parse_rejected_artifacts"), 0)

    csv_docx_join_telemetry = csv_docx_join_telemetry or {}
    dat_csv_join_telemetry = dat_csv_join_telemetry or {}

    if _to_int((agg.get("dat") or {}).get("artifacts_processed"), 0) == 0 and _to_int(
            source_inv.get("dat", {}).get("total_canonical_records"), 0
    ) == 0:
        blockers.append({
            "code": "dat_zero_selected",
            "rank": 1,
            "detail": "no_dat_artifacts_processed_or_canonical_records",
        })

    if dat_parse > 0:
        blockers.append({"code": "dat_parse_rejects", "rank": 2, "detail": str(dat_parse)})

    inv_csv = dat_csv_join_telemetry.get("invalid_external_id_csv_count") or 0
    inv_dat = dat_csv_join_telemetry.get("invalid_external_id_dat_count") or 0
    inv_join = dat_csv_join_telemetry.get("invalid_external_id_join_block_count") or 0
    inv_inventory = (
        _to_int(source_inv.get("csv", {}).get("invalid_patient_id"), 0)
        + _to_int(source_inv.get("docx", {}).get("invalid_patient_id"), 0)
        + _to_int(source_inv.get("dat", {}).get("invalid_patient_id"), 0)
    )
    if _to_int(inv_csv, 0) + _to_int(inv_dat, 0) + _to_int(inv_join, 0) + inv_inventory > 0:
        blockers.append({"code": "invalid_external_patient_id", "rank": 3, "detail": "csv={0},docx={1},dat={2},join_block={3}".format(
            _to_int(source_inv.get("csv", {}).get("invalid_patient_id"), 0),
            _to_int(source_inv.get("docx", {}).get("invalid_patient_id"), 0),
            _to_int(source_inv.get("dat", {}).get("invalid_patient_id"), 0),
            inv_join)})

    miss_dos = (
        _to_int(source_inv.get("csv", {}).get("missing_date"), 0)
        + _to_int(source_inv.get("docx", {}).get("missing_date"), 0)
        + _to_int(source_inv.get("dat", {}).get("missing_date"), 0)
    )
    if miss_dos > 0:
        blockers.append({"code": "missing_dos", "rank": 4, "detail": str(miss_dos)})

    cjx = csv_docx_join_telemetry.get("matched_count") or 0
    ck = normalized_key_presence.get("csv_distinct_normalized_key_count") or 0
    dk = normalized_key_presence.get("docx_distinct_normalized_key_count") or 0
    if ck > 0 and dk > 0 and _to_int(cjx, 0) == 0:
        blockers.append({"code": "csv_docx_zero_overlap", "rank": 5, "detail": "{0}:{1}:{2}".format(overlap.get("csv_docx"), ck, dk)})

    dj = dat_csv_join_telemetry.get("matched_count") or 0
    dnk = normalized_key_presence.get("dat_distinct_normalized_key_count") or 0
    csv_k = normalized_key_presence.get("csv_distinct_normalized_key_count") or 0
    if csv_k > 0 and dnk > 0 and _to_int(dj, 0) == 0:
        blockers.append({"code": "dat_csv_zero_overlap", "rank": 6, "detail": "{0}:{1}:{2}".format(overlap.get("dat_csv"), dnk, csv_k)})

    rds = relaxed_dat_stats if isinstance(relaxed_dat_stats, dict) else {}
    if _to_int(rds.get("keyable_records"), 0) > 0 and _to_int(rds.get("payer_anchor_missing_count"), 0) > 0:
        blockers.append({"code": "dat_payer_anchor_blocks_strict_qa_but_layer1_key_exists", "rank": 6, "detail": "keyable={0},iname_present={1},csv_overlap={2}".format(
            _to_int(rds.get("keyable_records"), 0),
            _to_int(rds.get("insurance_name_present_payer_missing_count"), 0),
            _to_int(rds.get("csv_overlap_count"), 0),
        )})

    amb = (_to_int(csv_docx_join_telemetry.get("ambiguous_count"), 0)
           + _to_int(dat_csv_join_telemetry.get("ambiguous_multi_dat_count"), 0))
    if amb > 0:
        blockers.append({"code": "ambiguous_join_keys", "rank": 7, "detail": str(amb)})

    blockers.sort(key=lambda b: _to_int(b.get("rank"), 99))
    return blockers


def _compose_samples(
        canonical_records,
        helpers,
        _membership_unused,
        ingress_stats,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        overlap_counts,
        relaxed_dat_records=None,
):
    extract_pid = helpers["extract_external_patient_id"]
    norm_date = helpers["normalize_surgery_date_key"]
    classify_fn = helpers["classify_external_patient_id_5_digit"]
    is_valid_pid = helpers["is_valid_external_patient_id_5_digit"]
    extract_dat_join = helpers.get("extract_dat_join_identity")

    try:
        from join_contract import extract_dat_join_identity
        if extract_dat_join is None:
            extract_dat_join = extract_dat_join_identity
    except Exception:
        pass

    samples = []
    counts = {}

    def _want(kind):
        counts[kind] = counts.get(kind, 0) + 1
        return counts[kind] <= SAMPLES_CAP_PER_KIND and len(samples) < TOTAL_SAMPLES_CAP

    mm_csv = {}
    mm_doc = {}
    mm_dat = {}

    csv_jkeys = []
    docx_jkeys = []
    dat_jkeys = []

    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        raw = _load_json_dict(rec.get("canonical_json"))
        join_key_u = ""

        if ctype == "patient_csv_row":
            try:
                join_key_u = _csv_docx_join_key(extract_pid, norm_date, raw)
            except Exception:
                join_key_u = ""
            csv_jkeys.append(join_key_u)
            if join_key_u:
                mm_csv[join_key_u] = mm_csv.get(join_key_u, 0) + 1
        elif ctype == "docx_schedule":
            join_key_u = _docx_join_key_from_rec(rec, norm_date)
            docx_jkeys.append(join_key_u)
            if join_key_u:
                mm_doc[join_key_u] = mm_doc.get(join_key_u, 0) + 1
        elif ctype == "dat_record":
            try:
                join_key_u = _dat_join_key_extract(rec, extract_dat_join, norm_date)[0]
            except Exception:
                join_key_u = ""
            dat_jkeys.append(join_key_u or "")
            if join_key_u:
                mm_dat[join_key_u] = mm_dat.get(join_key_u, 0) + 1

    set_csv_keys = set([k for k in csv_jkeys if k])
    set_doc_keys = set([k for k in docx_jkeys if k])
    set_dat_keys = set([k for k in dat_jkeys if k])

    csv_idx = 0
    doc_idx = 0
    dat_idx = 0

    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        if ctype not in ("patient_csv_row", "docx_schedule", "dat_record"):
            continue

        raw = _load_json_dict(rec.get("canonical_json"))
        prov = _load_json_dict(rec.get("provenance_json"))
        loc = str(prov.get("source_ref") or prov.get("locator") or "")
        artifact_id = rec.get("artifact_id")

        pid = ""
        dos_raw = ""
        join_key = ""
        nk_safe = ""
        pv = {}

        ctype_l = ctype
        idx_token = ""

        if ctype == "patient_csv_row":
            try:
                pid = extract_pid(raw) if callable(extract_pid) else ""
                from patient_field_mapper import extract_surgery_date as _esd

                dos_raw = _esd(raw) if isinstance(raw, dict) else ""
                join_key = _csv_docx_join_key(extract_pid, norm_date, raw)
                nk_safe = str(norm_date(dos_raw) or "").strip() if dos_raw else ""
            except Exception:
                join_key = ""
            idx_token = "csv_record_index:{0}".format(csv_idx)
            csv_idx += 1

        elif ctype == "docx_schedule":
            join_key = _docx_join_key_from_rec(rec, norm_date)
            try:
                prv2 = prov
                sk_in = prv2.get("schedule_key") or raw.get("schedule_key")
                pid = (
                    _verified_external_patient_id(raw)
                    or _verified_external_patient_id(prv2)
                    or str(prv2.get("patient_id") or raw.get("patient_id") or "").strip()
                )
                nk_safe = str(norm_date(sk_in) if sk_in else "").strip()
            except Exception:
                nk_safe = ""
                pid = ""
            idx_token = "docx_record_index:{0}".format(doc_idx)
            doc_idx += 1

        else:
            try:
                join_key, dos_raw, nk_safe, pv = _dat_join_key_extract(rec, extract_dat_join, norm_date)
                pid_u, _ddr = extract_dat_join(raw) if callable(extract_dat_join) else ("", "")
                pid = str(pid_u or "").strip()
            except Exception:
                join_key = dos_raw = nk_safe = ""
                pid = ""
            rid = pv.get("record_index")
            idx_token = "dat_record_index:{0}".format(rid if rid is not None else dat_idx)
            dat_idx += 1

        hk = bool(join_key and join_key in set_csv_keys)
        hc = bool(join_key and join_key in set_doc_keys)
        hm = bool(join_key and join_key in set_dat_keys)

        reason_codes = []
        key_status = "absent"
        ambiguous_row = False

        if ctype == "patient_csv_row" and join_key and mm_csv.get(join_key, 0) > 1:
            ambiguous_row = True
            reason_codes.append("csv_duplicate_normalized_key_bucket")
        if ctype == "docx_schedule" and join_key and mm_doc.get(join_key, 0) > 1:
            ambiguous_row = True
            reason_codes.append("docx_duplicate_normalized_key_bucket")
        if ctype == "dat_record" and join_key and mm_dat.get(join_key, 0) > 1:
            ambiguous_row = True
            reason_codes.append("dat_duplicate_normalized_key_bucket")

        if not join_key:
            key_status = "missing_join_key_components"
            if not str(pid or "").strip():
                reason_codes.append("missing_patient_id")
            elif not nk_safe:
                reason_codes.append("missing_or_unparsed_date")
        else:
            pid_s_chk = str(pid or "").strip()
            if ctype == "patient_csv_row" and pid_s_chk and callable(is_valid_pid) and not is_valid_pid(pid_s_chk):
                key_status = "invalid_external_patient_id"
                reason_codes.append("csv_external_id_contract_violation")
            elif ctype == "docx_schedule" and pid_s_chk and callable(is_valid_pid) and not is_valid_pid(pid_s_chk):
                key_status = "invalid_external_patient_id"
                reason_codes.append("docx_external_id_contract_violation")
            elif ctype == "dat_record" and pid_s_chk and callable(is_valid_pid) and not is_valid_pid(pid_s_chk):
                key_status = "invalid_external_patient_id"
                reason_codes.append("dat_external_id_contract_violation")
            elif ctype == "patient_csv_row":
                st_d = raw.get("docx_schedule_match_status") or ""
                st_a = raw.get("dat_alignment_status") or ""
                if st_d == "matched" or st_a == "matched":
                    key_status = "matched"
                elif st_d == "ambiguous":
                    ambiguous_row = True
                    key_status = "ambiguous_join_key_bucket"
                    reason_codes.append("csv_docx_ambiguous")
                elif st_a == "ambiguous_multi_dat":
                    ambiguous_row = True
                    key_status = "ambiguous_multi_dat"
                    reason_codes.append("dat_csv_ambiguous_multi_dat")
                elif st_a == "no_join_key":
                    key_status = "csv_row_no_alignment_key_in_annotation"
                    reason_codes.append("dat_alignment_missing_key_annotation")
                else:
                    key_status = "present"
            else:
                key_status = "present"

        jt = _join_key_token(join_key)
        pk_token = _patient_id_token(pid, classify_fn)

        skind = None
        if ambiguous_row and _want("ambiguous_key"):
            skind = "ambiguous_key"
        elif skind is None and key_status == "matched" and _want("matched"):
            skind = "matched"
        elif skind is None and ctype == "patient_csv_row" and raw.get("docx_schedule_match_status") == "csv_only" and join_key and _want("csv_only"):
            skind = "csv_only"
        elif skind is None and ctype == "docx_schedule" and join_key and join_key not in set_csv_keys and _want("docx_only"):
            skind = "docx_only"
        elif skind is None and ctype == "dat_record" and join_key and join_key not in set_csv_keys and _want("dat_only"):
            skind = "dat_only"
        elif skind is None and not join_key and _want("missing_key"):
            skind = "missing_key"
        elif skind is None and key_status == "invalid_external_patient_id" and _want("invalid_patient_id"):
            skind = "invalid_patient_id"

        if not skind:
            continue

        samples.append({
            "sample_kind": skind,
            "source_class": _infer_source_class(ctype_l),
            "source_file_token": _source_locator_evidence_token(loc),
            "artifact_id": artifact_id,
            "record_index": idx_token,
            "patient_id_shape": pk_token.get("shape"),
            "patient_id_diag_token": pk_token.get("diag_token"),
            "date_raw_shape": str(len(str(dos_raw or ""))),
            "normalized_date_safe": nk_safe or "",
            "join_key_token": jt if join_key else "",
            "key_status": key_status,
            "reason_codes": reason_codes,
            "has_csv": hk,
            "has_docx": hc,
            "has_dat": hm,
        })

    stats = ingress_stats if isinstance(ingress_stats, dict) else {}
    for cls in ("csv", "docx", "dat"):
        pr = stats.get(cls) if isinstance(stats.get(cls), dict) else {}
        prej = _to_int(pr.get("parse_rejected_artifacts"), 0)
        for i in range(min(prej, SAMPLES_CAP_PER_KIND)):
            if len(samples) >= TOTAL_SAMPLES_CAP:
                break
            samples.append({
                "sample_kind": "parse_reject",
                "source_class": cls,
                "source_file_token": "(parse_stage)",
                "artifact_id": None,
                "record_index": "parse:{0}:{1}".format(cls, i),
                "patient_id_shape": "n/a",
                "patient_id_diag_token": "parse_rejected_artifact",
                "date_raw_shape": "n/a",
                "normalized_date_safe": "",
                "join_key_token": "",
                "key_status": "parse_rejected",
                "reason_codes": ["qa_parse_failure"],
                "has_csv": False,
                "has_docx": False,
                "has_dat": False,
            })

    relaxed_count = 0
    for rec in relaxed_dat_records or []:
        if len(samples) >= TOTAL_SAMPLES_CAP:
            break
        if not _want("dat_relaxed_candidate"):
            continue
        raw = _load_json_dict(rec.get("canonical_json"))
        prov = _load_json_dict(rec.get("provenance_json"))
        loc = str(prov.get("source_ref") or prov.get("locator") or "")
        try:
            join_key, dos_raw, nk_safe, _pv = _dat_join_key_extract(rec, extract_dat_join, norm_date)
            pid_u, _ddr = extract_dat_join(raw) if callable(extract_dat_join) else ("", "")
            pid = str(pid_u or "").strip()
        except Exception:
            join_key = ""
            dos_raw = ""
            nk_safe = ""
            pid = ""
        reason_codes = ["debug_only_relaxed_dat_candidate"]
        nk_relaxed, compact_kind = _normalize_relaxed_dat_date_key_with_meta(dos_raw, norm_date)
        if compact_kind == "yyyymmdd":
            reason_codes.append("compact_date_yyyymmdd_normalized")
        elif compact_kind == "mmddyy":
            reason_codes.append("compact_date_mmddyy_normalized")
        elif compact_kind == "invalid":
            reason_codes.append("compact_date_invalid")
        nk_relaxed_valid = _valid_normalized_date_key(nk_relaxed)
        if pid and not nk_relaxed_valid:
            reason_codes.append("date_unparseable")
        relaxed_join_key = ""
        if pid and nk_relaxed_valid:
            relaxed_join_key = "{0}|{1}".format(pid, nk_relaxed)
        if relaxed_join_key and relaxed_join_key not in set_csv_keys:
            reason_codes.append("valid_patid_date_no_csv_overlap")
        if pid and callable(is_valid_pid) and not is_valid_pid(pid):
            reason_codes.append("invalid_external_patient_id")
        try:
            from dat_contract import resolve_dat_fields
            resolved = resolve_dat_fields(raw)
            if str(pid or "").strip() and not str(resolved.get("payer_id") or "").strip():
                reason_codes.append("payer_anchor_missing_strict_qa")
                reason_codes.append("payer_anchor_missing")
            if str(resolved.get("insurance_name") or "").strip() and not str(resolved.get("payer_id") or "").strip():
                reason_codes.append("insurance_name_present_not_payer_anchor")
        except Exception:
            pass
        pk_token = _patient_id_token(pid, classify_fn)
        samples.append({
            "sample_kind": "dat_relaxed_candidate",
            "source_class": "dat",
            "source_file_token": _source_locator_evidence_token(loc),
            "artifact_id": rec.get("artifact_id"),
            "record_index": "dat_relaxed_record_index:{0}".format(prov.get("record_index") if prov.get("record_index") is not None else relaxed_count),
            "patient_id_shape": pk_token.get("shape"),
            "patient_id_diag_token": pk_token.get("diag_token"),
            "date_raw_shape": str(len(str(dos_raw or ""))),
            "normalized_date_safe": nk_safe or "",
            "join_key_token": _join_key_token(join_key) if join_key else "",
            "key_status": "present" if join_key else "missing_join_key_components",
            "reason_codes": reason_codes,
            "has_csv": bool(join_key and join_key in set_csv_keys),
            "has_docx": bool(join_key and join_key in set_doc_keys),
            "has_dat": True,
        })
        relaxed_count += 1

    return samples


def build_layer1_text_pack(summary_blob, capped_samples_lines):
    lines = []

    evaluated = summary_blob.get("layer1_join_evaluated", True)

    lines.append("Layer 1 Join Debug Pack (developer/support)")
    lines.append("===========================================")
    lines.append("layer1_pipeline=parse_normalize_join (patient_id + surgery/service date)")
    lines.append("")
    lines.append("Key policy:")
    lines.append(" - normalized composite join key={0}".format(JOIN_KEY_POLICY))
    lines.append("")

    if not evaluated:
        lines.append("Layer 1 join evaluation:")
        lines.append(" - STATUS: NOT EVALUATED for this Phase D invocation.")
        br = summary_blob.get("layer1_evaluation_blocked_reason") or "unknown_blocker"
        lines.append(" - blocked_reason_code={0}".format(br))
        zr = summary_blob.get("phase_d_zero_selection_reason_codes") or []
        if isinstance(zr, list) and zr:
            lines.append(" - zero_selection_reason_codes={0}".format(",".join([str(z) for z in zr[:8]])))
        lines.append("")
        lines.append("Next developer action:")
        lines.append(
            " - Restore ingest selection (Phase B/C ingest into lab) until Phase D selects at least one artifact,"
            " then re-run Phase D.")
        lines.append("")
        lines.append("Capped sanitized examples:")
        lines.append(" - none (no canonical join rows materialized)")
        return "\n".join(lines)

    si = summary_blob.get("source_inventory") if isinstance(summary_blob.get("source_inventory"), dict) else {}
    for label in ("csv", "docx", "dat"):
        b = si.get(label) if isinstance(si.get(label), dict) else {}
        lines.append("{0}: total_canonical_records={1} keyable={2}".format(
            label,
            _to_int(b.get("total_canonical_records"), 0),
            _to_int(b.get("keyable_records"), 0),
        ))
        lines.append(
            "   missing_pid={0} invalid_pid={1} missing_date={2} parse_rejected_artifacts={3}".format(
                _to_int(b.get("missing_patient_id"), 0),
                _to_int(b.get("invalid_patient_id"), 0),
                _to_int(b.get("missing_date"), 0),
                _to_int(b.get("parse_rejected_artifacts"), 0),
            )
        )
    lines.append("")

    om = summary_blob.get("overlap_matrix") if isinstance(summary_blob.get("overlap_matrix"), dict) else {}
    lines.append("Overlap matrix (distinct normalized keys):")
    for k in sorted(om.keys()):
        lines.append(" - {0}={1}".format(k, _to_int(om.get(k), 0)))

    rds = summary_blob.get("relaxed_dat_candidate_debug") if isinstance(summary_blob.get("relaxed_dat_candidate_debug"), dict) else {}
    if _to_int(rds.get("total_records"), 0) > 0:
        lines.append("")
        lines.append("DAT relaxed Layer 1 candidates (debug-only, not canonical readiness):")
        lines.append(" - policy={0}".format(str(rds.get("policy") or RELAXED_DAT_POLICY)))
        lines.append(" - total={0} keyable={1} csv_overlap={2} docx_overlap={3}".format(
            _to_int(rds.get("total_records"), 0),
            _to_int(rds.get("keyable_records"), 0),
            _to_int(rds.get("csv_overlap_count"), 0),
            _to_int(rds.get("docx_overlap_count"), 0),
        ))
        lines.append(" - payer_anchor_missing={0} iname_present_payer_missing={1}".format(
            _to_int(rds.get("payer_anchor_missing_count"), 0),
            _to_int(rds.get("insurance_name_present_payer_missing_count"), 0),
        ))

    nk = summary_blob.get("normalized_key_counts") if isinstance(summary_blob.get("normalized_key_counts"), dict) else {}
    lines.append("")
    lines.append("Normalized key counts:")
    for k in sorted(nk.keys()):
        lines.append(" - {0}={1}".format(k, _to_int(nk.get(k), 0)))

    invalid_by_source = summary_blob.get("layer1_invalid_external_patient_id_by_source_contract")
    invalid_by_disp = summary_blob.get("layer1_invalid_external_patient_id_by_contract_disposition")
    if isinstance(invalid_by_source, dict) and invalid_by_source:
        lines.append("")
        lines.append("External patient ID contract diagnostics:")
        lines.append(" - source_contracts={0}".format(_format_dict_counts(invalid_by_source)))
        if isinstance(invalid_by_disp, dict) and invalid_by_disp:
            lines.append(" - contract_dispositions={0}".format(_format_dict_counts(invalid_by_disp)))
        lz = _to_int(summary_blob.get("layer1_leading_zero_loss_candidate_count"), 0)
        if lz > 0:
            lines.append(
                " - leading_zero_loss_candidates={0}; confirmation=requires_secondary_match".format(lz))

    lines.append("")
    lines.append("Top blockers (ranked):")
    for b in summary_blob.get("ranked_join_blockers") or []:
        if not isinstance(b, dict):
            continue
        lines.append(" - [{0}] {1}: {2}".format(
            _to_int(b.get("rank"), 0),
            b.get("code"),
            str(b.get("detail") or "")[:120],
        ))

    lines.append("")
    lines.append("Capped sanitized examples:")
    lines.extend(capped_samples_lines[:20])

    lines.append("")
    lines.append("Next developer action:")
    top = summary_blob.get("layer1_top_blocker") or ""

    hints = []
    if "invalid_external_patient_id" in top:
        hints.append(
            "Enforce strictly 5-digit external patient identifiers on CSV, DOCX, and DAT per contract; rerun Phase D.")
    if "csv_docx_zero_overlap" in top or str(summary_blob.get("layer1_csv_docx_overlap_count", "")) == "0":
        if _to_int(summary_blob.get("csv_docx_overlap_count_fallback"), -1) == 0:
            hints.append("Verify DOCX locator scope and Surgery Date normalization against CSV DOS align.")
    if "dat_csv_zero_overlap" in top:
        hints.append("Compare DAT payer/DOS anchors with CSV rows; reconcile Medisoft PATID+DOS aliases.")
    if "dat_payer_anchor_blocks_strict_qa" in top:
        hints.append("Layer 1 has DAT PATID+DOS candidates before payer anchoring; compare relaxed DAT overlap before changing relational QA.")
    if "dat_parse_rejects" in top or top.startswith("dat_parse"):
        hints.append("Repair tuple parse / ingest for DAT blobs; inspect qa_reject_samples for parse diagnostics.")

    hints.append(
        "Open layer1_join_debug_summary JSON for telemetry and layer1_join_debug_samples JSONL"
        " for sanitized row sketches.")
    hints.append(
        "Do not expose raw PHI: keep operator-facing Artifact Triage Pack + Follow recommendation; developers use packs.")

    for h in hints[:6]:
        lines.append(" - {0}".format(h))

    return "\n".join(lines)


def write_layer1_join_debug_artifacts(
        reports_dir,
        run_id,
        canonical_records,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        patient_field_mapper_mod,
        ingress_stats=None,
        phase_run_ids=None,
        layer1_evaluation_blocked_reason=None,
        zero_selection_reason_codes=None,
        relaxed_dat_records=None,
):
    """
    Write layer1_join_debug_* files and return flattened keys for qa_canonical_summary.
    """
    out = {}

    ingress_stats = ingress_stats if isinstance(ingress_stats, dict) else {}
    rid = str(run_id or "").strip()
    paths = {}

    iso_fn = None
    try:
        from phase_d_common import iso_utc_now
        iso_fn = iso_utc_now
    except Exception:
        iso_fn = None

    def _iso_now():
        if iso_fn:
            try:
                return iso_fn()
            except Exception:
                pass
        import time as _time
        return _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())

    generated_at = _iso_now()

    join_extract_fn = None
    try:
        from join_contract import extract_dat_join_identity
        join_extract_fn = extract_dat_join_identity
    except Exception:
        join_extract_fn = lambda d: ("", "")  # noqa: E731 simplification guarded

    inv = {"csv": {}, "docx": {}, "dat": {}}
    helpers = None
    try:
        inv, helpers = _source_inventory(canonical_records, ingress_stats, patient_field_mapper_mod, join_extract_fn)
    except Exception:
        inv = {"csv": {}, "docx": {}, "dat": {}}

    if helpers is None:
        classify_fn_dummy = getattr(
            patient_field_mapper_mod,
            "classify_external_patient_id_5_digit",
            lambda v, s=None: {})
        helpers = {
            "extract_external_patient_id": lambda r: "",
            "normalize_surgery_date_key": lambda v: "",
            "is_valid_external_patient_id_5_digit": lambda v: False,
            "classify_external_patient_id_5_digit": classify_fn_dummy,
            "extract_dat_join_identity": join_extract_fn,
        }

    mm_csv_mm = []
    mm_doc_mm = []
    mm_dat_mm = []
    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        raw = _load_json_dict(rec.get("canonical_json"))
        if ctype == "patient_csv_row":
            try:
                j = _csv_docx_join_key(helpers["extract_external_patient_id"], helpers["normalize_surgery_date_key"], raw)
            except Exception:
                j = ""
            if j:
                mm_csv_mm.append(j)
        elif ctype == "docx_schedule":
            j = _docx_join_key_from_rec(rec, helpers["normalize_surgery_date_key"])
            if j:
                mm_doc_mm.append(j)
        elif ctype == "dat_record":
            try:
                j, _, _, _ = _dat_join_key_extract(rec, join_extract_fn, helpers["normalize_surgery_date_key"])
            except Exception:
                j = ""
            if j:
                mm_dat_mm.append(j)

    mm_counts = (
        ("csv_source", mm_csv_mm),
        ("docx_source", mm_doc_mm),
        ("dat_source", mm_dat_mm),
    )
    dup_summary = {}
    for label, seq in mm_counts:
        m = _count_multimap(seq)
        dup_summary[label] = _ambiguous_distinct_keys(m)

    csv_keys = [k for k in mm_csv_mm if k]
    docx_keys = [k for k in mm_doc_mm if k]
    dat_keys = [k for k in mm_dat_mm if k]

    overlap = _overlap_metrics(csv_keys, docx_keys, dat_keys)
    relaxed_dat_stats, _relaxed_dat_keys = _dat_relaxed_candidate_stats(
        relaxed_dat_records,
        csv_keys,
        docx_keys,
        helpers,
        join_extract_fn,
    )
    nk_presence = _normalized_key_presence(canonical_records, helpers)
    if _to_int(relaxed_dat_stats.get("distinct_normalized_key_count"), 0) > _to_int(nk_presence.get("dat_distinct_normalized_key_count"), 0):
        nk_presence["dat_relaxed_distinct_normalized_key_count"] = _to_int(relaxed_dat_stats.get("distinct_normalized_key_count"), 0)

    dat_keyable = _to_int(inv.get("dat", {}).get("keyable_records"), 0)
    invalid_by_source_contract, invalid_by_disposition, leading_zero_by_source = _invalid_patient_id_breakdowns_from_inventory(
        inv,
        patient_field_mapper_mod,
    )
    invalid_external_patient_id_count = sum(_to_int(v, 0) for v in invalid_by_source_contract.values())
    leading_zero_candidate_count = sum(_to_int(v, 0) for v in leading_zero_by_source.values())

    evaluated = True
    blocked_reason = layer1_evaluation_blocked_reason or ""
    zsc = zero_selection_reason_codes if isinstance(zero_selection_reason_codes, list) else []

    if not canonical_records and blocked_reason:
        evaluated = False

    csv_docx_join_telemetry = csv_docx_join_telemetry or {}
    dat_csv_join_telemetry = dat_csv_join_telemetry or {}

    blockers = _rank_blockers(
        ingress_stats,
        inv,
        overlap,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        nk_presence,
        dat_keyable,
        relaxed_dat_stats,
    )

    top_blocker = str(blockers[0].get("code") or "") if blockers else ""

    summary_core = {
        "schema_version": LAYER1_SCHEMA_VERSION,
        "run_id": rid,
        "generated_at_utc": generated_at,
        "join_key_policy": JOIN_KEY_POLICY,
        "phase_run_ids": dict(phase_run_ids) if isinstance(phase_run_ids, dict) else {},
        "layer1_join_evaluated": evaluated,
        "layer1_evaluation_blocked_reason": blocked_reason or ("" if evaluated else "no_canonical_records"),
        "phase_d_zero_selection_reason_codes": list(zsc),
        "source_inventory": inv,
        "normalized_key_counts": nk_presence,
        "overlap_matrix": overlap,
        "duplicate_ambiguous_key_counts": dup_summary,
        "ranked_join_blockers": blockers,
        "layer1_top_blocker": top_blocker,
        "layer1_csv_docx_overlap_count": overlap.get("csv_docx", 0),
        "layer1_dat_csv_overlap_count": overlap.get("dat_csv", 0),
        "layer1_dat_keyable_count": dat_keyable,
        "relaxed_dat_candidate_debug": relaxed_dat_stats,
        "layer1_dat_relaxed_keyable_count": relaxed_dat_stats.get("keyable_records", 0),
        "layer1_dat_csv_relaxed_overlap_count": relaxed_dat_stats.get("csv_overlap_count", 0),
        "layer1_dat_relaxed_payer_anchor_missing_count": relaxed_dat_stats.get("payer_anchor_missing_count", 0),
        "layer1_dat_relaxed_iname_present_payer_missing_count": relaxed_dat_stats.get("insurance_name_present_payer_missing_count", 0),
        "layer1_dat_relaxed_parsed_rows": relaxed_dat_stats.get("dat_parsed_rows", 0),
        "layer1_dat_relaxed_patid_present": relaxed_dat_stats.get("dat_patid_present", 0),
        "layer1_dat_relaxed_date_present": relaxed_dat_stats.get("dat_date_present", 0),
        "layer1_dat_relaxed_patid_date_keyable": relaxed_dat_stats.get("dat_patid_date_keyable", 0),
        "layer1_dat_relaxed_csv_overlap": relaxed_dat_stats.get("dat_relaxed_csv_overlap", 0),
        "layer1_dat_relaxed_payer_id_missing": relaxed_dat_stats.get("dat_payer_id_missing", 0),
        "layer1_dat_relaxed_chart_present_patid_missing": relaxed_dat_stats.get("dat_chart_present_patid_missing", 0),
        "layer1_dat_relaxed_date_unparseable_by_shape": relaxed_dat_stats.get("dat_date_unparseable_by_shape", 0),
        "layer1_invalid_external_pressure": invalid_external_patient_id_count,
        "layer1_invalid_external_patient_id_count": invalid_external_patient_id_count,
        "layer1_invalid_external_patient_id_by_source_contract": invalid_by_source_contract,
        "layer1_invalid_external_patient_id_by_contract_disposition": invalid_by_disposition,
        "layer1_leading_zero_loss_candidate_count": leading_zero_candidate_count,
        "layer1_leading_zero_loss_candidate_by_source_contract": leading_zero_by_source,
        "layer1_leading_zero_loss_candidate_confirmation": (
            "requires_secondary_match" if leading_zero_candidate_count > 0 else ""
        ),
        "csv_docx_join_telemetry_ref": {
            "matched_count": _to_int(csv_docx_join_telemetry.get("matched_count"), 0),
            "primary_join_blocker_class": str(csv_docx_join_telemetry.get("primary_join_blocker_class") or ""),
        },
        "dat_csv_join_telemetry_ref": {
            "matched_count": _to_int(dat_csv_join_telemetry.get("matched_count"), 0),
            "primary_join_blocker_class": str(dat_csv_join_telemetry.get("primary_join_blocker_class") or ""),
        },
    }

    # samples
    try:
        samples = _compose_samples(
            canonical_records,
            helpers,
            {},
            ingress_stats,
            csv_docx_join_telemetry,
            dat_csv_join_telemetry,
            overlap,
            relaxed_dat_records=relaxed_dat_records,
        )
    except Exception:
        samples = []

    sample_lines = []
    for s in samples:
        try:
            sample_lines.append(json.dumps(s, ensure_ascii=False))
        except Exception:
            pass
    if not sample_lines:
        sentinel = {
            "sample_kind": "no_samples",
            "run_id": rid,
            "generated_at_utc": generated_at,
            "reason": "layer1_debug_no_sanitized_samples_available",
            "layer1_evaluation_blocked_reason": str(layer1_evaluation_blocked_reason or ""),
            "zero_selection_reason_codes": zsc,
        }
        try:
            sample_lines.append(json.dumps(sentinel, ensure_ascii=False, sort_keys=True))
        except Exception:
            sample_lines.append('{"sample_kind":"no_samples","reason":"layer1_debug_no_sanitized_samples_available"}')

    text_pack = build_layer1_text_pack(dict(summary_core, csv_docx_overlap_count_fallback=overlap.get("csv_docx", 0)), sample_lines)

    def _write(p, text):
        try:
            with open(p, "w", encoding="utf-8") as fh:
                fh.write(text)
            return True
        except (IOError, OSError):
            return False

    sum_path = os.path.join(reports_dir, "layer1_join_debug_summary_{0}.json".format(rid))
    smp_path = os.path.join(reports_dir, "layer1_join_debug_samples_{0}.jsonl".format(rid))
    txt_path = os.path.join(reports_dir, "layer1_join_debug_pack_{0}.txt".format(rid))

    summary_core["layer1_join_debug_samples_path"] = smp_path
    summary_core["layer1_join_debug_summary_path"] = sum_path
    summary_core["layer1_join_debug_pack_path"] = txt_path

    ok_sum = _write(sum_path, json.dumps(summary_core, ensure_ascii=False, indent=2, sort_keys=True))
    ok_smp = _write(smp_path, "\n".join(sample_lines) + ("\n" if sample_lines else ""))
    ok_txt = _write(txt_path, text_pack + "\n")

    generated = bool(ok_sum and ok_smp and ok_txt)

    flat_for_qa = {
        "layer1_join_debug_generated": generated,
        "layer1_join_debug_pack_path": txt_path if ok_txt else "",
        "layer1_join_debug_summary_path": sum_path if ok_sum else "",
        "layer1_join_debug_samples_path": smp_path if ok_smp else "",
        "layer1_top_blocker": summary_core.get("layer1_top_blocker") or "",
        "layer1_csv_docx_overlap_count": summary_core.get("layer1_csv_docx_overlap_count") or 0,
        "layer1_dat_csv_overlap_count": summary_core.get("layer1_dat_csv_overlap_count") or 0,
        "layer1_dat_keyable_count": summary_core.get("layer1_dat_keyable_count") or 0,
        "layer1_dat_relaxed_keyable_count": summary_core.get("layer1_dat_relaxed_keyable_count") or 0,
        "layer1_dat_csv_relaxed_overlap_count": summary_core.get("layer1_dat_csv_relaxed_overlap_count") or 0,
        "layer1_dat_relaxed_payer_anchor_missing_count": summary_core.get("layer1_dat_relaxed_payer_anchor_missing_count") or 0,
        "layer1_dat_relaxed_iname_present_payer_missing_count": summary_core.get("layer1_dat_relaxed_iname_present_payer_missing_count") or 0,
        "layer1_dat_relaxed_parsed_rows": summary_core.get("layer1_dat_relaxed_parsed_rows") or 0,
        "layer1_dat_relaxed_patid_present": summary_core.get("layer1_dat_relaxed_patid_present") or 0,
        "layer1_dat_relaxed_date_present": summary_core.get("layer1_dat_relaxed_date_present") or 0,
        "layer1_dat_relaxed_patid_date_keyable": summary_core.get("layer1_dat_relaxed_patid_date_keyable") or 0,
        "layer1_dat_relaxed_csv_overlap": summary_core.get("layer1_dat_relaxed_csv_overlap") or 0,
        "layer1_dat_relaxed_payer_id_missing": summary_core.get("layer1_dat_relaxed_payer_id_missing") or 0,
        "layer1_dat_relaxed_chart_present_patid_missing": summary_core.get("layer1_dat_relaxed_chart_present_patid_missing") or 0,
        "layer1_dat_relaxed_date_unparseable_by_shape": summary_core.get("layer1_dat_relaxed_date_unparseable_by_shape") or 0,
        "layer1_invalid_external_pressure": summary_core.get("layer1_invalid_external_pressure") or 0,
        "layer1_invalid_external_patient_id_count": summary_core.get("layer1_invalid_external_patient_id_count") or 0,
        "layer1_invalid_external_patient_id_by_source_contract": summary_core.get("layer1_invalid_external_patient_id_by_source_contract") or {},
        "layer1_invalid_external_patient_id_by_contract_disposition": summary_core.get("layer1_invalid_external_patient_id_by_contract_disposition") or {},
        "layer1_leading_zero_loss_candidate_count": summary_core.get("layer1_leading_zero_loss_candidate_count") or 0,
        "layer1_leading_zero_loss_candidate_by_source_contract": summary_core.get("layer1_leading_zero_loss_candidate_by_source_contract") or {},
        "layer1_leading_zero_loss_candidate_confirmation": summary_core.get("layer1_leading_zero_loss_candidate_confirmation") or "",
    }

    out["summary_fields"] = flat_for_qa
    out["summary_blob"] = summary_core
    out["paths"] = {"summary": sum_path, "samples": smp_path, "text": txt_path}
    return out


def finalize_layer1_qa_summary_fields(
        bundle_out,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        phase_d_success=True,
        recommendation_kind=""):
    flat = dict((bundle_out or {}).get("summary_fields") or {})
    flat["layer1_support_bundle_attachment_recommended"] = compute_layer1_support_bundle_attachment_recommended(
        {
            "layer1_join_debug_generated": flat.get("layer1_join_debug_generated"),
            "layer1_top_blocker": flat.get("layer1_top_blocker") or "",
            "layer1_invalid_external_pressure": flat.get("layer1_invalid_external_pressure"),
            "layer1_dat_keyable_count": flat.get("layer1_dat_keyable_count"),
        },
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        phase_d_ok=phase_d_success,
        recommendation_kind=recommendation_kind,
    )
    return flat


def format_layer1_triage_lines(phase_d_summary_payload):
    """
    Short lines for artifact triage pack (operator sees pointer; details are developer-facing).
    """
    if not isinstance(phase_d_summary_payload, dict):
        return []
    if not phase_d_summary_payload.get("layer1_join_debug_generated"):
        return []
    lines = []
    lines.append("Layer 1 join debug (developer/support; not operator diagnostics):")
    lines.append(
        " - pack={0}".format(
            _source_locator_evidence_token(phase_d_summary_payload.get("layer1_join_debug_pack_path") or "")
        )
    )
    lines.append(" - top_blocker={0}".format(str(phase_d_summary_payload.get("layer1_top_blocker") or "-")))
    lines.append(
        " - overlap_csv_docx={0} overlap_dat_csv={1} dat_keyable={2}".format(
            _to_int(phase_d_summary_payload.get("layer1_csv_docx_overlap_count"), 0),
            _to_int(phase_d_summary_payload.get("layer1_dat_csv_overlap_count"), 0),
            _to_int(phase_d_summary_payload.get("layer1_dat_keyable_count"), 0),
        )
    )
    attach = phase_d_summary_payload.get("layer1_support_bundle_attachment_recommended")
    lines.append(" - support_bundle_attachment_recommended={0}".format(bool(attach)))
    return lines


def collect_existing_layer1_paths_from_qa_summary(qa_summary_dict):
    """Return existing file paths for support bundle attachment."""
    out = []
    if not isinstance(qa_summary_dict, dict):
        return out
    if not qa_summary_dict.get("layer1_join_debug_generated"):
        return out
    for key in ("layer1_join_debug_pack_path", "layer1_join_debug_summary_path", "layer1_join_debug_samples_path"):
        p = str(qa_summary_dict.get(key) or "").strip()
        if p and os.path.isfile(p):
            out.append(p)
    return out
