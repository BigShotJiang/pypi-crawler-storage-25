#!/usr/bin/env python
"""
Build a review-only Service Line Input charge-anchor index.

This helper turns historical DAT / saved-837P observations into local anchor
evidence that the Service Line Input preview can consume. It does not mutate
DAT files, 837P files, Medisoft state, claim status, or billing custody.

XP-compatible: Python 3.4 stdlib only.
"""
from __future__ import print_function

import argparse
import datetime
import imp
import io
import json
import os
import sqlite3
import sys
import time
import uuid


SCHEMA_VERSION = "service_line_charge_anchor_index.v1"
SUMMARY_SCHEMA_VERSION = "service_line_charge_anchor_summary.v1"
WORKFLOW_NAME = "service_line_input"
WORKFLOW_BOUNDARY = "report_only_review_required"
STATE_FILENAME = ".service_line_charge_anchor_index.json"


def _clean_text(value):
    return str(value or "").strip()


def _utc_now():
    try:
        return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    except Exception:
        return ""


def _normalize_patient_id(value):
    text = _clean_text(value)
    if not text:
        return ""
    return text.upper()


def _normalize_patid(value):
    text = _clean_text(value)
    if len(text) == 5 and text.isdigit():
        return text
    return ""


def _parse_date_parts(value):
    text = _clean_text(value)
    if not text:
        return None
    if " " in text:
        text = text.split(" ", 1)[0]
    if len(text) == 8 and text.isdigit():
        try:
            return int(text[0:4]), int(text[4:6]), int(text[6:8])
        except Exception:
            return None
    normalized = text.replace("/", "-")
    parts = normalized.split("-")
    if len(parts) != 3:
        return None
    try:
        if len(parts[0]) == 4:
            year = int(parts[0])
            month = int(parts[1])
            day = int(parts[2])
        else:
            month = int(parts[0])
            day = int(parts[1])
            year = int(parts[2])
            if year < 100:
                year = 2000 + year if year < 50 else 1900 + year
        return year, month, day
    except Exception:
        return None


def normalize_dos(value):
    parts = _parse_date_parts(value)
    if not parts:
        return ""
    year, month, day = parts
    try:
        datetime.date(year, month, day)
    except Exception:
        return ""
    return "{0:02d}-{1:02d}-{2:04d}".format(month, day, year)


def _dos_sort_value(value):
    parts = _parse_date_parts(value)
    if not parts:
        return 0
    year, month, day = parts
    return year * 10000 + month * 100 + day


def _amount_to_cents(value):
    text = _clean_text(value).replace("$", "").replace(",", "")
    if not text:
        return None
    try:
        return int(round(float(text) * 100))
    except Exception:
        return None


def normalize_amount(value):
    cents = _amount_to_cents(value)
    if cents is None:
        return ""
    return "{0:.2f}".format(float(cents) / 100.0)


def amount_display(value):
    cents = _amount_to_cents(value)
    if cents is None:
        return ""
    if cents % 100 == 0:
        return "${0}".format(int(cents / 100))
    return "${0:.2f}".format(float(cents) / 100.0)


def normalize_minutes(value):
    text = _clean_text(value)
    if not text:
        return ""
    try:
        number = int(float(text))
    except Exception:
        return ""
    if number < 0:
        return ""
    return str(number)


def _boundary_fields():
    return {
        "workflow_name": WORKFLOW_NAME,
        "workflow_boundary": WORKFLOW_BOUNDARY,
        "claims_completion": False,
        "mutates_billing_state": False,
        "mutates_dat": False,
        "mutates_837p": False,
        "charges_entered": False,
        "operational_charge_update": False,
    }


def _source_file_ref(path):
    text = _clean_text(path)
    if not text:
        return ""
    return os.path.basename(text)


def _safe_isfile(path):
    try:
        return os.path.isfile(path)
    except Exception:
        return False


def _safe_isdir(path):
    try:
        return os.path.isdir(path)
    except Exception:
        return False


def _safe_makedirs(path):
    if not path:
        return False
    if _safe_isdir(path):
        return True
    try:
        os.makedirs(path)
        return True
    except Exception:
        return _safe_isdir(path)


def _directory_is_writable(path):
    if not _safe_makedirs(path):
        return False
    probe = os.path.join(path, ".service_line_charge_anchor_write_probe_{0}.tmp".format(os.getpid()))
    try:
        with io.open(probe, "w", encoding="utf-8") as handle:
            handle.write("ok\n")
        try:
            os.remove(probe)
        except Exception:
            pass
        return True
    except Exception:
        try:
            os.remove(probe)
        except Exception:
            pass
        return False


def dat_record_to_anchor(record, source_record_index=0, source_ref=""):
    if not isinstance(record, dict):
        return None, "record_not_mapping"
    anchor_source = _clean_text(record.get("_anchor_source")) or "dat"
    patient_source = (
        record.get("patid")
        or record.get("PATID")
        or record.get("internal_patid")
    )
    if not patient_source and anchor_source == "canonical_dat":
        patient_source = record.get("patient_id")
    patient_id = _normalize_patid(
        patient_source
    )
    dos = normalize_dos(
        record.get("service_date")
        or record.get("date_of_service")
        or record.get("DATE")
        or record.get("DOS")
        or record.get("DATE1")
    )
    charge_amount = normalize_amount(
        record.get("charge_amount")
        or record.get("charged_amount")
        or record.get("AMOUNT")
        or record.get("amount")
    )
    minutes = normalize_minutes(
        record.get("anesthesia_minutes")
        or record.get("MINTUES")
        or record.get("MINUTES")
    )
    if not patient_id:
        if _clean_text(record.get("CHART") or record.get("chart_number") or record.get("patient_id")):
            return None, "dat_missing_patid"
        return None, "missing_patient_id"
    if not dos:
        return None, "missing_dos"
    if not charge_amount:
        return None, "missing_charge"
    anchor = {
        "schema_version": "service_line_charge_anchor.v1",
        "anchor_source": anchor_source,
        "patient_id": patient_id,
        "anchor_source_dos": dos,
        "charge_amount": charge_amount,
        "charge_display": amount_display(charge_amount),
        "anesthesia_minutes": minutes,
        "same_patient_anchor_charge_rule_id": "same_patient_dos_anchor",
        "same_patient_anchor_charge_note": "same-patient DOS anchor from {0}".format(dos),
        "source_artifact_id": _source_file_ref(source_ref),
        "source_ref": _clean_text(source_ref),
        "source_record_index": int(source_record_index or 0),
        "confidence": "high",
        "selection_reason": (
            "historical_canonical_dat_charge_observation"
            if anchor_source == "canonical_dat"
            else "historical_dat_charge_observation"
        ),
        "custody_state_at_anchor": "submitted_or_exported_out_of_custody",
        "submitted_out_of_custody": True,
    }
    anchor.update(_boundary_fields())
    return anchor, ""


def x12_row_to_anchor(row, source_record_index=0, source_ref=""):
    if not isinstance(row, dict):
        return None, "record_not_mapping"
    patient_id = _normalize_patid(
        row.get("patient_id")
        or row.get("patid")
        or row.get("PATID")
        or row.get("internal_patid")
    )
    dos = normalize_dos(row.get("service_date") or row.get("dos") or row.get("DATE"))
    charge_amount = normalize_amount(row.get("line_charge_amount") or row.get("charge_amount"))
    minutes = normalize_minutes(row.get("anesthesia_minutes") or row.get("minutes"))
    if not patient_id:
        return None, "unkeyable_837p_patient_id"
    if not dos:
        return None, "missing_dos"
    if not charge_amount:
        return None, "missing_charge"
    anchor = {
        "schema_version": "service_line_charge_anchor.v1",
        "anchor_source": "saved_837p",
        "patient_id": patient_id,
        "anchor_source_dos": dos,
        "charge_amount": charge_amount,
        "charge_display": amount_display(charge_amount),
        "anesthesia_minutes": minutes,
        "same_patient_anchor_charge_rule_id": "same_patient_dos_anchor",
        "same_patient_anchor_charge_note": "same-patient DOS anchor from {0}".format(dos),
        "source_artifact_id": _source_file_ref(source_ref or row.get("source_file_basename")),
        "source_ref": _clean_text(source_ref),
        "source_record_index": int(source_record_index or 0),
        "confidence": "medium",
        "selection_reason": "historical_837p_charge_observation_with_local_patient_key",
        "custody_state_at_anchor": "submitted_out_of_custody",
        "submitted_out_of_custody": True,
    }
    anchor.update(_boundary_fields())
    return anchor, ""


def _anchor_key(anchor):
    return "{0}|{1}".format(
        _normalize_patient_id(anchor.get("patient_id")),
        normalize_dos(anchor.get("anchor_source_dos")),
    )


def _anchor_rank(anchor):
    source = _clean_text(anchor.get("anchor_source"))
    if source == "dat":
        source_rank = 0
    elif source == "canonical_dat":
        source_rank = 1
    else:
        source_rank = 2
    cents = _amount_to_cents(anchor.get("charge_amount")) or 0
    return (source_rank, -cents, int(anchor.get("source_record_index", 0) or 0))


def _dedupe_anchors(anchors):
    best = {}
    duplicate_counts = {}
    for anchor in anchors or []:
        if not isinstance(anchor, dict):
            continue
        key = _anchor_key(anchor)
        if not key or key == "|":
            continue
        duplicate_counts[key] = int(duplicate_counts.get(key, 0) or 0) + 1
        current = best.get(key)
        if current is None or _anchor_rank(anchor) < _anchor_rank(current):
            best[key] = anchor
    out = []
    for key in sorted(best.keys()):
        anchor = dict(best[key])
        anchor["duplicate_source_count"] = int(duplicate_counts.get(key, 1) or 1)
        out.append(anchor)
    out.sort(key=lambda row: (
        _normalize_patient_id(row.get("patient_id")),
        _dos_sort_value(row.get("anchor_source_dos")),
        _clean_text(row.get("anchor_source")),
    ))
    return out


def _anchor_advisory_code(summary):
    if not isinstance(summary, dict):
        return ""
    if int(summary.get("anchor_count", 0) or 0) != 0:
        return ""
    source_summary = summary.get("source_summary") if isinstance(summary.get("source_summary"), dict) else {}
    dat_count = (
        int(summary.get("dat_record_count", 0) or 0)
        + int(summary.get("canonical_dat_record_count", 0) or 0)
    )
    x12_count = int(summary.get("x12_row_count", 0) or 0)
    unkeyable = int(summary.get("x12_unkeyable_row_count", 0) or 0)
    rejected = summary.get("rejected_counts") if isinstance(summary.get("rejected_counts"), dict) else {}
    if dat_count == 0 and x12_count == 0:
        if source_summary.get("x12_rows_resolution") == "none":
            return "no_anchor_source_rows_found"
        return "no_anchor_rows_found"
    if x12_count > 0 and unkeyable >= x12_count and dat_count == 0:
        return "x12_rows_without_local_patient_key"
    if rejected:
        return "all_candidate_rows_rejected"
    return "no_eligible_anchor_rows_found"


def _anchor_advisory_detail(code):
    if code == "no_anchor_source_rows_found":
        return "No DAT records or saved-837P minutes/charge rows were available to build charge anchors."
    if code == "x12_rows_without_local_patient_key":
        return "Saved-837P rows were found, but none contained a local patient key usable by Service Line Input."
    if code == "all_candidate_rows_rejected":
        return "Candidate rows were found, but every row was rejected before anchor creation."
    if code == "no_anchor_rows_found":
        return "No charge-anchor rows were available."
    if code == "no_eligible_anchor_rows_found":
        return "Source rows were available, but no eligible same-patient charge anchor could be built."
    return ""


def build_anchor_index(dat_records=None, canonical_dat_records=None, x12_rows=None, run_id=None,
                       generated_at_utc=None, source_summary=None):
    anchors = []
    rejected = {}
    unkeyable_837p = 0
    raw_dat_anchor_count = 0
    canonical_dat_anchor_count = 0
    saved_837p_anchor_count = 0
    for idx, record in enumerate(dat_records or []):
        anchor, reason = dat_record_to_anchor(record, idx + 1, record.get("_source_ref", "") if isinstance(record, dict) else "")
        if anchor is not None:
            anchors.append(anchor)
            raw_dat_anchor_count += 1
        elif reason:
            rejected[reason] = int(rejected.get(reason, 0) or 0) + 1
    for idx, record in enumerate(canonical_dat_records or []):
        source_index = idx + 1
        if isinstance(record, dict) and record.get("_source_record_index") is not None:
            try:
                source_index = int(record.get("_source_record_index")) + 1
            except Exception:
                source_index = idx + 1
        anchor, reason = dat_record_to_anchor(record, source_index, record.get("_source_ref", "") if isinstance(record, dict) else "")
        if anchor is not None:
            anchors.append(anchor)
            canonical_dat_anchor_count += 1
        elif reason:
            rejected[reason] = int(rejected.get(reason, 0) or 0) + 1
    for idx, row in enumerate(x12_rows or []):
        anchor, reason = x12_row_to_anchor(row, idx + 1, row.get("_source_ref", "") if isinstance(row, dict) else "")
        if anchor is not None:
            anchors.append(anchor)
            saved_837p_anchor_count += 1
        elif reason:
            rejected[reason] = int(rejected.get(reason, 0) or 0) + 1
            if reason == "unkeyable_837p_patient_id":
                unkeyable_837p += 1
    anchors = _dedupe_anchors(anchors)
    generated = generated_at_utc or _utc_now()
    if not run_id:
        run_id = "sli-anchor-{0}".format(uuid.uuid4().hex[:8])
    summary = {
        "schema_version": SUMMARY_SCHEMA_VERSION,
        "run_id": run_id,
        "generated_at_utc": generated,
        "workflow_name": WORKFLOW_NAME,
        "workflow_boundary": WORKFLOW_BOUNDARY,
        "anchor_count": len(anchors),
        "dat_record_count": len(dat_records or []),
        "canonical_dat_record_count": len(canonical_dat_records or []),
        "x12_row_count": len(x12_rows or []),
        "raw_dat_anchor_count": raw_dat_anchor_count,
        "canonical_dat_anchor_count": canonical_dat_anchor_count,
        "saved_837p_anchor_count": saved_837p_anchor_count,
        "x12_unkeyable_row_count": int(unkeyable_837p),
        "rejected_counts": rejected,
    }
    summary.update(_boundary_fields())
    if isinstance(source_summary, dict):
        summary["source_summary"] = source_summary
    advisory_code = _anchor_advisory_code(summary)
    if advisory_code:
        summary["advisory_code"] = advisory_code
        summary["advisory_detail"] = _anchor_advisory_detail(advisory_code)
    payload = {
        "schema_version": SCHEMA_VERSION,
        "run_id": run_id,
        "generated_at_utc": generated,
        "workflow_name": WORKFLOW_NAME,
        "workflow_boundary": WORKFLOW_BOUNDARY,
        "summary": summary,
        "anchors": anchors,
    }
    payload.update(_boundary_fields())
    return payload


def _write_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not _safe_makedirs(parent):
        raise IOError("unable_to_create_output_directory: {0}".format(parent))
    with io.open(path, "w", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True))
        handle.write("\n")


def _write_text(path, lines):
    parent = os.path.dirname(path)
    if parent and not _safe_makedirs(parent):
        raise IOError("unable_to_create_output_directory: {0}".format(parent))
    with io.open(path, "w", encoding="utf-8") as handle:
        for line in lines:
            handle.write(_clean_text(line))
            handle.write("\n")


def format_summary_lines(payload):
    summary = payload.get("summary") if isinstance(payload, dict) else {}
    rejected = summary.get("rejected_counts") if isinstance(summary.get("rejected_counts"), dict) else {}
    lines = [
        "Service Line Input charge-anchor hydration",
        "Generated: {0}".format(summary.get("generated_at_utc", "")),
        "Run ID: {0}".format(summary.get("run_id", "")),
        "Workflow boundary: {0}".format(summary.get("workflow_boundary", WORKFLOW_BOUNDARY)),
        "Billing custody: claims_completion=False mutates_dat=False mutates_837p=False charges_entered=False",
        "Anchors: {0}".format(summary.get("anchor_count", 0)),
        "DAT records scanned: {0}".format(summary.get("dat_record_count", 0)),
        "Canonical DAT records scanned: {0}".format(summary.get("canonical_dat_record_count", 0)),
        "Saved 837P rows scanned: {0}".format(summary.get("x12_row_count", 0)),
        "Anchor source counts: raw_dat={0}, canonical_dat={1}, saved_837p={2}".format(
            summary.get("raw_dat_anchor_count", 0),
            summary.get("canonical_dat_anchor_count", 0),
            summary.get("saved_837p_anchor_count", 0),
        ),
        "Saved 837P rows without local patient key: {0}".format(summary.get("x12_unkeyable_row_count", 0)),
    ]
    if rejected:
        lines.append("Rejected rows:")
        for key in sorted(rejected.keys()):
            lines.append("  - {0}: {1}".format(key, rejected.get(key)))
    source_summary = summary.get("source_summary") if isinstance(summary.get("source_summary"), dict) else {}
    if source_summary:
        lines.append("X12 rows resolution: {0}".format(source_summary.get("x12_rows_resolution", "")))
        lines.append("X12 direct scan status: {0}".format(source_summary.get("x12_direct_scan_status", "")))
        if source_summary.get("canonical_dat_read_status"):
            lines.append("Canonical DAT read status: {0}".format(source_summary.get("canonical_dat_read_status", "")))
            lines.append("Canonical DAT DBs present: {0}".format(source_summary.get("canonical_dat_db_present_count", 0)))
            lines.append("Canonical DAT rows loaded: {0}".format(source_summary.get("canonical_dat_record_count", 0)))
        if source_summary.get("local_837p_resolution_status"):
            lines.append("Local 837P identity resolution: {0}".format(source_summary.get("local_837p_resolution_status", "")))
            lines.append("Local 837P claims seen: {0}".format(source_summary.get("local_837p_claims_seen", 0)))
            lines.append("Local 837P submission-index matches: {0}".format(source_summary.get("local_837p_submission_index_matches", 0)))
            lines.append("Local 837P PATID matches: {0}".format(source_summary.get("local_837p_internal_patid_matches", 0)))
    if summary.get("advisory_code"):
        lines.append("Advisory: {0}".format(summary.get("advisory_code")))
        if summary.get("advisory_detail"):
            lines.append("Advisory detail: {0}".format(summary.get("advisory_detail")))
    return lines


def write_reports(local_storage_path, payload, write_index=False):
    reports_dir = os.path.join(local_storage_path, "reports")
    run_id = payload.get("run_id") or "unknown"
    summary_json = os.path.join(reports_dir, "service_line_charge_anchor_hydration_{0}.json".format(run_id))
    summary_txt = os.path.join(reports_dir, "service_line_charge_anchor_hydration_{0}.txt".format(run_id))
    _write_json(summary_json, payload)
    _write_text(summary_txt, format_summary_lines(payload))
    paths = {
        "summary_json": summary_json,
        "summary_txt": summary_txt,
        "state_path": "",
    }
    if write_index:
        state_path = os.path.join(local_storage_path, STATE_FILENAME)
        _write_json(state_path, payload)
        paths["state_path"] = state_path
    return paths


def _iter_files(root, suffixes):
    if not root or not _safe_isdir(root):
        return
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            low = name.lower()
            for suffix in suffixes:
                if low.endswith(suffix):
                    yield os.path.join(dirpath, name)
                    break


def _dedupe_paths(paths):
    seen = {}
    out = []
    for path in paths or []:
        text = _clean_text(path)
        if not text:
            continue
        try:
            norm = os.path.normcase(os.path.abspath(os.path.expandvars(os.path.expanduser(text))))
        except Exception:
            norm = os.path.normcase(text)
        if norm in seen:
            continue
        seen[norm] = True
        out.append(text)
    return out


def _candidate_x12_lab_roots(config):
    medi = config.get("MediLink_Config", {}) if isinstance(config, dict) else {}
    lab_roots = []
    env_lab = os.environ.get("MEDICAFE_LAB_DIR", "")
    if env_lab:
        lab_roots.append(env_lab)
    for key in ("lab_root", "local_lab_path", "unified_model_lab_path"):
        value = medi.get(key)
        if value:
            lab_roots.append(value)

    # Match Troubleshooting analytics default: repo_root/lab where repo_root is
    # normally the current installed site-packages directory for XP commands.
    try:
        lab_roots.append(os.path.join(os.getcwd(), "lab"))
    except Exception:
        pass

    # Direct script execution resolves two levels above scripts/unified_model.
    try:
        script_root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
        lab_roots.append(os.path.join(script_root, "lab"))
    except Exception:
        pass

    # Packaged XP data-files may live under C:\Python34\scripts while the
    # analytics reports live under C:\Python34\Lib\site-packages\lab.
    try:
        lab_roots.append(os.path.join(sys.prefix, "Lib", "site-packages", "lab"))
    except Exception:
        pass
    return _dedupe_paths(lab_roots)


def _candidate_x12_report_dirs(config, configured_storage_path, output_storage_path):
    storage_roots = _dedupe_paths([configured_storage_path, output_storage_path, _local_storage_path(config)])
    report_dirs = []
    for root in storage_roots:
        report_dirs.append(os.path.join(root, "reports"))

    for lab_root in _candidate_x12_lab_roots(config):
        if os.path.basename(os.path.normpath(lab_root)).lower() == "reports":
            report_dirs.append(lab_root)
        else:
            report_dirs.append(os.path.join(lab_root, "reports"))
    return _dedupe_paths(report_dirs)


def load_x12_rows_from_report_dirs(report_dirs):
    rows = []
    files_seen = {}
    dirs_checked = []
    dirs_with_rows = []
    for reports_dir in _dedupe_paths(report_dirs):
        dirs_checked.append(reports_dir)
        if not _safe_isdir(reports_dir):
            continue
        found_in_dir = False
        for path in _iter_files(reports_dir, (".jsonl",)):
            base = os.path.basename(path)
            if not base.startswith("x12_minutes_charge_rows_"):
                continue
            files_seen[os.path.abspath(path)] = True
            try:
                with io.open(path, "r", encoding="utf-8") as handle:
                    for line in handle:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            row = json.loads(line)
                        except Exception:
                            continue
                        if isinstance(row, dict):
                            row["_source_ref"] = path
                            rows.append(row)
                            found_in_dir = True
            except Exception:
                continue
        if found_in_dir:
            dirs_with_rows.append(reports_dir)
    summary = {
        "x12_report_dirs_checked": dirs_checked,
        "x12_report_dirs_with_rows": dirs_with_rows,
        "x12_row_file_count": len(files_seen),
    }
    return rows, summary


def discover_dat_files(config):
    medi = config.get("MediLink_Config", {}) if isinstance(config, dict) else {}
    roots = []
    for key in ("local_storage_path", "local_claims_path", "DAT_FILE_PATH", "MEDISOFT_DAT_PATH", "dat_path"):
        value = medi.get(key)
        if value:
            roots.append(value)
    seen = {}
    out = []
    for root in roots:
        try:
            if _safe_isfile(root) and root.lower().endswith(".dat"):
                path = os.path.abspath(root)
                if path not in seen:
                    seen[path] = True
                    out.append(path)
            elif _safe_isdir(root):
                for path in _iter_files(root, (".dat",)):
                    ap = os.path.abspath(path)
                    if ap not in seen:
                        seen[ap] = True
                        out.append(ap)
        except Exception:
            continue
    return out


def load_dat_records(dat_paths, config):
    records = []
    try:
        from MediCafe.dat_utils import extract_member_data_from_dat_file
    except Exception:
        extract_member_data_from_dat_file = None
    if extract_member_data_from_dat_file is None:
        return records
    for path in dat_paths or []:
        try:
            parsed = extract_member_data_from_dat_file(path, config) or []
        except Exception:
            parsed = []
        for row in parsed:
            if isinstance(row, dict):
                copy = dict(row)
                copy["_source_ref"] = path
                records.append(copy)
    return records


def _load_json_dict(text):
    try:
        data = json.loads(text or "{}")
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _candidate_canonical_dat_db_paths(config):
    paths = []
    for lab_root in _candidate_x12_lab_roots(config):
        root = lab_root
        try:
            if os.path.basename(os.path.normpath(root)).lower() == "reports":
                root = os.path.dirname(os.path.normpath(root))
        except Exception:
            pass
        if root:
            paths.append(os.path.join(root, "unified_model_xp.db"))
    return _dedupe_paths(paths)


def load_canonical_dat_records(config):
    """
    Read local canonical DAT evidence from the shadow DB for Option H anchors.

    This is a read-only hydration path. It does not write to the DB and only
    returns local rows for the private anchor index; support bundles receive
    counts from the summary, not raw canonical rows.
    """
    records = []
    summary = {
        "canonical_dat_db_path_count": 0,
        "canonical_dat_db_present_count": 0,
        "canonical_dat_record_count": 0,
        "canonical_dat_read_status": "not_attempted",
    }
    db_paths = _candidate_canonical_dat_db_paths(config)
    summary["canonical_dat_db_path_count"] = len(db_paths)
    if not db_paths:
        summary["canonical_dat_read_status"] = "no_candidate_db_paths"
        return records, summary
    status = "no_canonical_dat_rows"
    for db_path in db_paths:
        if not _safe_isfile(db_path):
            continue
        summary["canonical_dat_db_present_count"] = int(summary.get("canonical_dat_db_present_count", 0) or 0) + 1
        conn = None
        try:
            conn = sqlite3.connect(db_path)
            cur = conn.execute(
                "SELECT artifact_id, canonical_json, provenance_json "
                "FROM extracted_canonical_record WHERE canonical_type='dat_record'"
            )
            for artifact_id, canonical_json, provenance_json in cur.fetchall():
                row = _load_json_dict(canonical_json)
                if not row:
                    continue
                prov = _load_json_dict(provenance_json)
                copy = dict(row)
                copy["_anchor_source"] = "canonical_dat"
                copy["_source_ref"] = "{0}#artifact:{1}".format(
                    os.path.basename(db_path),
                    _clean_text(artifact_id),
                )
                if prov.get("record_index") is not None:
                    copy["_source_record_index"] = prov.get("record_index")
                records.append(copy)
                summary["canonical_dat_record_count"] = int(summary.get("canonical_dat_record_count", 0) or 0) + 1
            status = "loaded" if records else status
        except Exception as exc:
            status = "read_error"
            summary["canonical_dat_read_error_class"] = exc.__class__.__name__
            summary["canonical_dat_read_error_detail"] = _clean_text(exc)[:200]
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass
    summary["canonical_dat_read_status"] = status
    return records, summary


def load_x12_rows_from_reports(local_storage_path):
    rows, _summary = load_x12_rows_from_report_dirs([os.path.join(local_storage_path, "reports")])
    return rows


def discover_x12_scan_roots(config):
    medi = config.get("MediLink_Config", {}) if isinstance(config, dict) else {}
    return _dedupe_paths([
        medi.get("local_claims_path"),
        medi.get("outputFilePath"),
    ])


def _select_x12_analysis_lab_dir(config, output_storage_path):
    for lab_root in _candidate_x12_lab_roots(config):
        if os.path.basename(os.path.normpath(lab_root)).lower() == "reports":
            lab_root = os.path.dirname(os.path.normpath(lab_root))
        if _directory_is_writable(lab_root):
            return lab_root
    fallback = os.path.join(output_storage_path or _fallback_storage_path(), "lab")
    if _directory_is_writable(fallback):
        return fallback
    return ""


def _load_x12_minutes_charge_module():
    try:
        from scripts.unified_model import run_x12_minutes_charge_association as mod
        return mod
    except Exception:
        pass
    script_path = os.path.join(os.path.dirname(__file__), "run_x12_minutes_charge_association.py")
    if not _safe_isfile(script_path):
        raise ImportError("run_x12_minutes_charge_association.py not found")
    return imp.load_source("_service_line_anchor_x12_minutes_charge_association", script_path)


def _load_x12_analytics_common_module():
    try:
        from scripts.unified_model import x12_analytics_common as mod
        return mod
    except Exception:
        pass
    script_path = os.path.join(os.path.dirname(__file__), "x12_analytics_common.py")
    if not _safe_isfile(script_path):
        raise ImportError("x12_analytics_common.py not found")
    return imp.load_source("_service_line_anchor_x12_analytics_common", script_path)


def load_x12_rows_from_direct_scan(config, output_storage_path):
    summary = {
        "x12_direct_scan_attempted": False,
        "x12_direct_scan_status": "not_attempted",
        "x12_direct_scan_root_count": 0,
        "x12_direct_scan_lab_dir": "",
    }
    scan_roots = discover_x12_scan_roots(config)
    summary["x12_direct_scan_root_count"] = len(scan_roots)
    if not scan_roots:
        summary["x12_direct_scan_status"] = "no_scan_roots"
        return [], summary
    lab_dir = _select_x12_analysis_lab_dir(config, output_storage_path)
    summary["x12_direct_scan_lab_dir"] = lab_dir
    if not lab_dir:
        summary["x12_direct_scan_status"] = "no_writable_lab_dir"
        return [], summary
    summary["x12_direct_scan_attempted"] = True
    try:
        mod = _load_x12_minutes_charge_module()
        analysis_summary, rows, artifacts = mod.run_analysis(scan_roots, lab_dir)
        rows_path = ""
        if isinstance(artifacts, dict):
            rows_path = artifacts.get("rows_jsonl", "")
        out_rows = []
        for row in rows or []:
            if isinstance(row, dict):
                copy = dict(row)
                if rows_path:
                    copy["_source_ref"] = rows_path
                out_rows.append(copy)
        summary["x12_direct_scan_status"] = "succeeded"
        summary["x12_direct_scan_run_id"] = analysis_summary.get("run_id", "") if isinstance(analysis_summary, dict) else ""
        summary["x12_direct_scan_rows_jsonl"] = rows_path
        return out_rows, summary
    except Exception as exc:
        summary["x12_direct_scan_status"] = "failed"
        summary["x12_direct_scan_error_class"] = exc.__class__.__name__
        summary["x12_direct_scan_error_detail"] = _clean_text(exc)
        return [], summary


def _x12_row_has_local_patient_key(row):
    if not isinstance(row, dict):
        return False
    return bool(_normalize_patient_id(
        row.get("patient_id")
        or row.get("patid")
        or row.get("PATID")
        or row.get("internal_patid")
    ))


def _x12_rows_local_key_count(rows):
    count = 0
    for row in rows or []:
        if _x12_row_has_local_patient_key(row):
            count += 1
    return count


def _parse_x12_clm01(segment):
    fields = _clean_text(segment).split("*")
    if len(fields) < 2:
        return ""
    return fields[1].strip()


def _normalize_claim_number(value):
    text = _clean_text(value).upper()
    if not text:
        return ""
    out = []
    for ch in text:
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


def _date_format_variants(value):
    parts = _parse_date_parts(value)
    if not parts:
        return []
    year, month, day = parts
    return [
        "{0:02d}{1:02d}{2:02d}".format(month, day, year % 100),
        "{0:02d}{1:02d}{2:04d}".format(month, day, year),
        "{0:04d}{1:02d}{2:02d}".format(year, month, day),
    ]


def _first_dtp_date_value(value):
    text = _clean_text(value)
    if "-" in text and len(text.split("-", 1)[0]) == 8:
        return text.split("-", 1)[0]
    return text


def _parse_x12_dtp_472(segment):
    fields = _clean_text(segment).split("*")
    if len(fields) < 4:
        return ""
    if fields[1].strip() != "472":
        return ""
    qualifier = fields[2].strip()
    value = fields[3].strip()
    if qualifier == "D8":
        return value
    if qualifier == "RD8":
        return _first_dtp_date_value(value)
    return ""


def _parse_x12_payer_id(segment):
    fields = _clean_text(segment).split("*")
    if len(fields) < 10:
        return ""
    if fields[0].strip() != "NM1" or fields[1].strip() != "PR":
        return ""
    if fields[8].strip() == "PI":
        return fields[9].strip()
    return ""


def _parse_x12_sv1_minutes_charge(segment):
    fields = _clean_text(segment).split("*")
    if len(fields) < 5:
        return None
    unit = fields[3].strip()
    if unit != "MJ":
        return None
    charge_amount = normalize_amount(fields[2].strip())
    minutes = normalize_minutes(fields[4].strip())
    if not charge_amount or not minutes:
        return None
    return {
        "line_charge_amount": charge_amount,
        "anesthesia_minutes": minutes,
    }


def _submission_index_path_for_root(receipts_root):
    if not receipts_root:
        return ""
    if os.path.basename(receipts_root).lower() == "submission_index.jsonl":
        return receipts_root
    return os.path.join(receipts_root, "submission_index.jsonl")


def _read_submission_index_rows(receipts_root):
    rows = []
    path = _submission_index_path_for_root(receipts_root)
    if not path or not _safe_isfile(path):
        return rows
    try:
        with io.open(path, "r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                if not isinstance(row, dict):
                    continue
                if _clean_text(row.get("record_type")) == "ack_event" or _clean_text(row.get("notes")) == "ack event":
                    continue
                record_type = _clean_text(row.get("record_type"))
                if record_type and record_type != "submission":
                    continue
                rows.append(row)
    except Exception:
        return []
    return rows


def _submission_receipt_basename(row):
    if not isinstance(row, dict):
        return ""
    value = row.get("receipt_file") or row.get("file_path") or row.get("file_name") or ""
    return os.path.basename(_clean_text(value))


def _submission_dos_values(row):
    values = []
    if not isinstance(row, dict):
        return values
    for key in ("dos", "service_start_date", "service_end_date", "DATE", "service_date"):
        value = _clean_text(row.get(key))
        if value:
            values.append(value)
    claim_key = _clean_text(row.get("claim_key"))
    parts = claim_key.split("|") if claim_key else []
    if len(parts) > 2 and parts[2]:
        values.append(parts[2])
    out = []
    seen = {}
    for value in values:
        norm = normalize_dos(_first_dtp_date_value(value))
        if norm and norm not in seen:
            seen[norm] = True
            out.append(norm)
    return out


def _submission_payer_values(row):
    values = []
    if not isinstance(row, dict):
        return values
    for key in ("payer_id", "PAYERID", "primary_payer_id"):
        value = _clean_text(row.get(key))
        if value:
            values.append(value.upper())
    return values


def _submission_claim_number_candidates(row):
    candidates = []
    if not isinstance(row, dict):
        return candidates

    def add(value, match_kind):
        norm = _normalize_claim_number(value)
        if norm:
            candidates.append((norm, match_kind))

    add(row.get("submitted_claim_number"), "exact")
    add(row.get("claim_number"), "exact")
    add(row.get("claimNumber"), "exact")

    chart = _normalize_claim_number(row.get("internal_chart") or row.get("patient_id"))
    if chart:
        for raw_dos in _submission_dos_values(row):
            for suffix in _date_format_variants(raw_dos):
                add(chart + suffix, "variant")

    out = []
    seen = {}
    for claim_number, match_kind in candidates:
        key = claim_number + "|" + match_kind
        if key in seen:
            continue
        seen[key] = True
        out.append((claim_number, match_kind))
    return out


def _latest_submitted_at_value(row):
    text = _clean_text(row.get("submitted_at") if isinstance(row, dict) else "")
    if not text:
        return ""
    return text


def _build_submitted_claim_resolver(config):
    medi = config.get("MediLink_Config", {}) if isinstance(config, dict) else {}
    receipts_root = _clean_text(medi.get("local_claims_path"))
    if not receipts_root:
        return {
            "by_claim": {},
            "by_receipt": {},
            "rows": [],
        }, {
            "local_837p_submission_index_present": False,
            "local_837p_submission_index_entries": 0,
        }
    rows = _read_submission_index_rows(receipts_root)
    resolver = {
        "by_claim": {},
        "by_receipt": {},
        "rows": rows,
    }
    for idx, row in enumerate(rows):
        wrapper = {
            "row": row,
            "row_index": idx + 1,
            "receipt_basename": _submission_receipt_basename(row),
            "dos_values": _submission_dos_values(row),
            "payer_values": _submission_payer_values(row),
            "submitted_at": _latest_submitted_at_value(row),
        }
        receipt = wrapper.get("receipt_basename")
        if receipt:
            resolver["by_receipt"].setdefault(receipt.lower(), []).append(wrapper)
        for claim_number, match_kind in _submission_claim_number_candidates(row):
            copy = dict(wrapper)
            copy["match_kind"] = match_kind
            resolver["by_claim"].setdefault(claim_number, []).append(copy)
    return resolver, {
        "local_837p_submission_index_present": bool(rows),
        "local_837p_submission_index_entries": len(rows),
        "local_837p_submission_index_claim_keys": len(resolver.get("by_claim", {})),
        "local_837p_submission_index_status": "loaded" if rows else "empty_or_missing",
    }


def _local_837p_summary_defaults():
    return {
        "local_837p_resolution_attempted": False,
        "local_837p_resolution_status": "not_attempted",
        "local_837p_scan_root_count": 0,
        "local_837p_candidate_file_count": 0,
        "local_837p_files_parsed": 0,
        "local_837p_claims_seen": 0,
        "local_837p_charge_rows_seen": 0,
        "local_837p_submission_index_matches": 0,
        "local_837p_internal_patid_matches": 0,
        "local_837p_unmatched_claim_number": 0,
        "local_837p_missing_claim_number": 0,
        "local_837p_missing_internal_patid": 0,
        "local_837p_exact_claim_number_matches": 0,
        "local_837p_claim_number_variant_matches": 0,
        "local_837p_ambiguous_identity_matches": 0,
        "local_837p_receipt_tiebreak_matches": 0,
        "local_837p_dos_tiebreak_matches": 0,
        "local_837p_no_safe_identity_match": 0,
        "local_837p_rows_emitted": 0,
    }


def _claim_source_basename(source_ref):
    return os.path.basename(_clean_text(source_ref))


def _filter_candidates_by_receipt(candidates, source_ref):
    base = _claim_source_basename(source_ref).lower()
    if not base:
        return candidates, False
    filtered = []
    for candidate in candidates or []:
        if _clean_text(candidate.get("receipt_basename")).lower() == base:
            filtered.append(candidate)
    if filtered:
        return filtered, len(filtered) != len(candidates or [])
    return candidates, False


def _filter_candidates_by_dos(candidates, claim_dos):
    norm = normalize_dos(_first_dtp_date_value(claim_dos))
    if not norm:
        return candidates, False
    filtered = []
    for candidate in candidates or []:
        if norm in (candidate.get("dos_values") or []):
            filtered.append(candidate)
    if filtered:
        return filtered, len(filtered) != len(candidates or [])
    return candidates, False


def _filter_candidates_by_payer(candidates, payer_id):
    payer = _clean_text(payer_id).upper()
    if not payer:
        return candidates
    filtered = []
    for candidate in candidates or []:
        if payer in (candidate.get("payer_values") or []):
            filtered.append(candidate)
    if filtered:
        return filtered
    return candidates


def _select_unique_submission_candidate(candidates):
    deduped = []
    seen_rows = {}
    for candidate in candidates or []:
        row_index = _clean_text(candidate.get("row_index") if isinstance(candidate, dict) else "")
        row = candidate.get("row") if isinstance(candidate, dict) else {}
        key = row_index or "{0}|{1}|{2}".format(
            _clean_text(row.get("internal_chart") if isinstance(row, dict) else ""),
            _clean_text(row.get("internal_patid") if isinstance(row, dict) else ""),
            _clean_text(row.get("submitted_claim_number") if isinstance(row, dict) else ""),
        )
        if key in seen_rows:
            continue
        seen_rows[key] = True
        deduped.append(candidate)
    candidates = deduped
    by_patid = {}
    for candidate in candidates or []:
        row = candidate.get("row") if isinstance(candidate, dict) else {}
        patid = _normalize_patient_id(
            row.get("internal_patid")
            or row.get("patid")
            or row.get("PATID")
        )
        if patid:
            by_patid.setdefault(patid, []).append(candidate)
    if not by_patid:
        if len(candidates or []) == 1:
            return candidates[0], "missing_patid"
        return None, "missing_patid"
    if len(by_patid) > 1:
        return None, "ambiguous"
    patid = sorted(by_patid.keys())[0]
    rows = by_patid.get(patid) or []
    rows.sort(key=lambda c: _latest_submitted_at_value(c.get("row") or {}), reverse=True)
    return rows[0], ""


def _resolve_submission_for_claim(claim_number, claim_dos, payer_id, source_ref,
                                  claim_count_in_file, resolver, stats):
    norm_claim = _normalize_claim_number(claim_number)
    candidates = []
    if norm_claim:
        candidates = list((resolver.get("by_claim") or {}).get(norm_claim, []))
    if not candidates and int(claim_count_in_file or 0) == 1:
        base = _claim_source_basename(source_ref).lower()
        receipt_candidates = list((resolver.get("by_receipt") or {}).get(base, []))
        if len(receipt_candidates) == 1:
            candidate, reason = _select_unique_submission_candidate(receipt_candidates)
            if candidate is not None:
                stats["local_837p_receipt_tiebreak_matches"] = int(stats.get("local_837p_receipt_tiebreak_matches", 0) or 0) + 1
                candidate = dict(candidate)
                candidate["match_kind"] = "receipt_single_claim"
                return candidate
            if reason == "missing_patid":
                return candidate
        return None
    if not candidates:
        return None

    original_count = len(candidates)
    candidates, receipt_filtered = _filter_candidates_by_receipt(candidates, source_ref)
    if receipt_filtered:
        stats["local_837p_receipt_tiebreak_matches"] = int(stats.get("local_837p_receipt_tiebreak_matches", 0) or 0) + 1
    before_dos = len(candidates)
    candidates, dos_filtered = _filter_candidates_by_dos(candidates, claim_dos)
    if dos_filtered and len(candidates) != before_dos:
        stats["local_837p_dos_tiebreak_matches"] = int(stats.get("local_837p_dos_tiebreak_matches", 0) or 0) + 1
    candidates = _filter_candidates_by_payer(candidates, payer_id)
    candidate, reason = _select_unique_submission_candidate(candidates)
    if candidate is not None:
        return candidate
    if reason == "ambiguous" or original_count > 1:
        stats["local_837p_ambiguous_identity_matches"] = int(stats.get("local_837p_ambiguous_identity_matches", 0) or 0) + 1
    return None


def _append_local_resolved_rows_from_text(rows, text, source_ref, source_index,
                                         submitted_resolver, stats):
    x12c = _load_x12_analytics_common_module()
    segments = x12c.split_x12_segments(text)
    claims = x12c.claim_records_from_segments(segments)
    claim_count_in_file = len(claims or [])
    for claim in claims:
        stats["local_837p_claims_seen"] = int(stats.get("local_837p_claims_seen", 0) or 0) + 1
        claim_number = ""
        payer_id = ""
        claim_rows = []
        for segment in claim.get("segments") or []:
            if segment.startswith("CLM*"):
                claim_number = _parse_x12_clm01(segment)
            elif segment.startswith("NM1*PR*"):
                payer_id = _parse_x12_payer_id(segment) or payer_id
            elif segment.startswith("SV1*"):
                parsed = _parse_x12_sv1_minutes_charge(segment)
                if parsed is not None:
                    claim_rows.append(parsed)
                    stats["local_837p_charge_rows_seen"] = int(stats.get("local_837p_charge_rows_seen", 0) or 0) + 1
            elif segment.startswith("DTP*472*") and claim_rows:
                dos = _parse_x12_dtp_472(segment)
                if dos:
                    claim_rows[-1]["service_date"] = dos
        if not claim_rows:
            continue
        if not claim_number:
            stats["local_837p_missing_claim_number"] = int(stats.get("local_837p_missing_claim_number", 0) or 0) + len(claim_rows)
            continue
        claim_dos = ""
        for item in claim_rows:
            claim_dos = item.get("service_date") or claim_dos
        candidate = _resolve_submission_for_claim(
            claim_number,
            claim_dos,
            payer_id,
            source_ref,
            claim_count_in_file,
            submitted_resolver,
            stats,
        )
        if not isinstance(candidate, dict):
            stats["local_837p_unmatched_claim_number"] = int(stats.get("local_837p_unmatched_claim_number", 0) or 0) + len(claim_rows)
            stats["local_837p_no_safe_identity_match"] = int(stats.get("local_837p_no_safe_identity_match", 0) or 0) + len(claim_rows)
            continue
        submission = candidate.get("row") if isinstance(candidate.get("row"), dict) else {}
        stats["local_837p_submission_index_matches"] = int(stats.get("local_837p_submission_index_matches", 0) or 0) + len(claim_rows)
        match_kind = _clean_text(candidate.get("match_kind"))
        if match_kind == "exact":
            stats["local_837p_exact_claim_number_matches"] = int(stats.get("local_837p_exact_claim_number_matches", 0) or 0) + len(claim_rows)
        elif match_kind == "variant":
            stats["local_837p_claim_number_variant_matches"] = int(stats.get("local_837p_claim_number_variant_matches", 0) or 0) + len(claim_rows)
        patid = _normalize_patient_id(
            submission.get("internal_patid")
            or submission.get("patid")
            or submission.get("PATID")
        )
        if not patid:
            stats["local_837p_missing_internal_patid"] = int(stats.get("local_837p_missing_internal_patid", 0) or 0) + len(claim_rows)
            continue
        stats["local_837p_internal_patid_matches"] = int(stats.get("local_837p_internal_patid_matches", 0) or 0) + len(claim_rows)
        for item in claim_rows:
            row = {
                "patient_id": patid,
                "internal_patid": patid,
                "service_date": item.get("service_date", ""),
                "line_charge_amount": item.get("line_charge_amount", ""),
                "anesthesia_minutes": item.get("anesthesia_minutes", ""),
                "_source_ref": source_ref,
                "_source_record_index": int(source_index or 0),
                "identity_resolution_source": "submission_index_{0}".format(match_kind or "claim_number"),
            }
            rows.append(row)
            stats["local_837p_rows_emitted"] = int(stats.get("local_837p_rows_emitted", 0) or 0) + 1


def load_x12_rows_from_local_837p_resolution(config):
    summary = _local_837p_summary_defaults()
    scan_roots = discover_x12_scan_roots(config)
    summary["local_837p_scan_root_count"] = len(scan_roots)
    if not scan_roots:
        summary["local_837p_resolution_status"] = "no_scan_roots"
        return [], summary
    submitted_resolver, lookup_summary = _build_submitted_claim_resolver(config)
    summary.update(lookup_summary)
    if not submitted_resolver.get("by_claim") and not submitted_resolver.get("by_receipt"):
        summary["local_837p_resolution_status"] = "no_submission_index_lookup"
        return [], summary
    summary["local_837p_resolution_attempted"] = True
    rows = []
    try:
        x12c = _load_x12_analytics_common_module()
        inventory, inventory_summary = x12c.build_x12_scan_inventory(scan_roots)
        summary["local_837p_candidate_file_count"] = len(inventory or [])
        summary["local_837p_inventory_submission_index_files"] = int(inventory_summary.get("unique_submission_index_files", 0) or 0)
        summary["local_837p_inventory_content_scan_files"] = int(inventory_summary.get("unique_content_scan_files", 0) or 0)
        source_index = 0
        for item in inventory or []:
            path = item.get("path") if isinstance(item, dict) else ""
            if not path:
                continue
            source_index += 1
            try:
                text = x12c.read_file_text(path)
            except Exception:
                continue
            if not text:
                continue
            summary["local_837p_files_parsed"] = int(summary.get("local_837p_files_parsed", 0) or 0) + 1
            _append_local_resolved_rows_from_text(
                rows,
                text,
                path,
                source_index,
                submitted_resolver,
                summary,
            )
        if rows:
            summary["local_837p_resolution_status"] = "succeeded"
        else:
            summary["local_837p_resolution_status"] = "no_resolved_rows"
    except Exception as exc:
        summary["local_837p_resolution_status"] = "failed"
        summary["local_837p_resolution_error_class"] = exc.__class__.__name__
        summary["local_837p_resolution_error_detail"] = _clean_text(exc)
        return [], summary
    return rows, summary


def load_x12_rows_for_anchor(config, configured_storage_path, output_storage_path):
    report_dirs = _candidate_x12_report_dirs(config, configured_storage_path, output_storage_path)
    rows, summary = load_x12_rows_from_report_dirs(report_dirs)
    if rows:
        keyed_count = _x12_rows_local_key_count(rows)
        summary["x12_existing_report_row_count"] = len(rows)
        summary["x12_existing_report_rows_with_local_key"] = keyed_count
        if keyed_count:
            summary["x12_rows_resolution"] = "existing_keyed_report_rows"
            summary["x12_direct_scan_status"] = "not_attempted_existing_keyed_report_rows_found"
            summary.update(_local_837p_summary_defaults())
            return rows, summary
        local_rows, local_summary = load_x12_rows_from_local_837p_resolution(config)
        summary.update(local_summary)
        if local_rows:
            summary["x12_rows_resolution"] = "existing_unkeyable_rows_plus_local_837p_resolution"
            summary["x12_direct_scan_status"] = "not_attempted_local_837p_resolution_succeeded"
            return rows + local_rows, summary
        summary["x12_rows_resolution"] = "existing_unkeyable_report_rows"
        summary["x12_direct_scan_status"] = "not_attempted_existing_unkeyable_report_rows_found"
        return rows, summary
    local_rows, local_summary = load_x12_rows_from_local_837p_resolution(config)
    summary.update(local_summary)
    if local_rows:
        summary["x12_rows_resolution"] = "local_837p_resolution"
        summary["x12_direct_scan_status"] = "not_attempted_local_837p_resolution_succeeded"
        summary["x12_row_file_count"] = max(int(summary.get("x12_row_file_count", 0) or 0), 1)
        return local_rows, summary
    scan_rows, scan_summary = load_x12_rows_from_direct_scan(config, output_storage_path)
    summary.update(scan_summary)
    if scan_rows:
        summary["x12_rows_resolution"] = "direct_saved_837p_scan"
        summary["x12_row_file_count"] = max(int(summary.get("x12_row_file_count", 0) or 0), 1)
        return scan_rows, summary
    summary["x12_rows_resolution"] = "none"
    return rows, summary


def _load_configuration(config_path=None):
    if config_path:
        with io.open(config_path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    try:
        from MediCafe.MediLink_ConfigLoader import load_configuration
        config, _crosswalk = load_configuration()
        return config
    except Exception:
        return {"MediLink_Config": {"local_storage_path": "."}}


def _local_storage_path(config):
    medi = config.get("MediLink_Config", {}) if isinstance(config, dict) else {}
    path = medi.get("local_storage_path") or "."
    return path


def _fallback_storage_path():
    env_path = os.environ.get("MEDICAFE_SERVICE_LINE_ANCHOR_FALLBACK_DIR", "")
    if env_path:
        return env_path
    return os.getcwd()


def _select_output_storage_path(config):
    configured = _local_storage_path(config)
    if _directory_is_writable(configured):
        return configured, configured, ""
    fallback = _fallback_storage_path()
    if _directory_is_writable(fallback):
        return fallback, configured, "configured_storage_inaccessible"
    return configured, configured, "configured_and_fallback_storage_inaccessible"


def run(config=None, config_path=None, write_index=False, run_id=None):
    if config is None:
        config = _load_configuration(config_path)
    local_storage_path, configured_storage_path, storage_fallback_reason = _select_output_storage_path(config)
    dat_paths = discover_dat_files(config)
    dat_records = load_dat_records(dat_paths, config)
    canonical_dat_records, canonical_dat_summary = load_canonical_dat_records(config)
    x12_rows, x12_source_summary = load_x12_rows_for_anchor(config, configured_storage_path, local_storage_path)
    source_summary = {
        "dat_file_count": len(dat_paths),
        "x12_rows_source": "candidate lab/storage reports/x12_minutes_charge_rows_*.jsonl",
        "configured_local_storage_path": configured_storage_path,
        "output_local_storage_path": local_storage_path,
    }
    source_summary.update(canonical_dat_summary)
    source_summary.update(x12_source_summary)
    if storage_fallback_reason:
        source_summary["storage_fallback_reason"] = storage_fallback_reason
    payload = build_anchor_index(
        dat_records=dat_records,
        canonical_dat_records=canonical_dat_records,
        x12_rows=x12_rows,
        run_id=run_id,
        source_summary=source_summary,
    )
    try:
        paths = write_reports(local_storage_path, payload, write_index=write_index)
    except Exception:
        fallback = _fallback_storage_path()
        if fallback == local_storage_path or not _directory_is_writable(fallback):
            raise
        payload["summary"]["source_summary"]["storage_fallback_reason"] = "report_write_failed"
        payload["summary"]["source_summary"]["output_local_storage_path"] = fallback
        paths = write_reports(fallback, payload, write_index=write_index)
    return payload, paths


def main(argv=None):
    parser = argparse.ArgumentParser(description="Build Service Line Input charge-anchor index")
    parser.add_argument("--config", default="", help="Optional config JSON path")
    parser.add_argument("--run-id", default="", help="Optional run id")
    parser.add_argument("--write-index", action="store_true", help="Write .service_line_charge_anchor_index.json")
    parser.add_argument("--dry-run", action="store_true", help="Write reports only")
    args = parser.parse_args(argv)
    write_index = bool(args.write_index and not args.dry_run)
    payload, paths = run(config_path=args.config or None, write_index=write_index, run_id=args.run_id or None)
    for line in format_summary_lines(payload):
        print(line)
    print("Report JSON: {0}".format(paths.get("summary_json", "")))
    if write_index:
        print("Anchor index: {0}".format(paths.get("state_path", "")))
    else:
        print("Dry run only: index was not updated.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
