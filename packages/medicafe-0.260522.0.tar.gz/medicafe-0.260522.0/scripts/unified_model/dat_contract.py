#!/usr/bin/env python
"""
Shared DAT field/provenance resolution used by parse, QA, join alignment,
canonical extraction, and Phase D decision logging.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

try:
    from patient_field_mapper import normalize_external_patient_id
except ImportError:
    normalize_external_patient_id = None

try:
    from dat_payer_resolution import (
        DAT_PAYER_RESOLUTION_DIAG_UNRESOLVED,
        DAT_PAYER_RESOLUTION_SOURCE_INAME_DISPLAY_NAME,
        DAT_PAYER_RESOLUTION_SOURCE_EXISTING,
        DAT_PAYER_RESOLUTION_SOURCE_INAME_MEDISOFT_ID,
        DAT_PAYER_RESOLUTION_STATUS_MISSING,
        DAT_PAYER_RESOLUTION_STATUS_RESOLVED,
        resolve_payer_id_from_iname,
    )
except ImportError:
    DAT_PAYER_RESOLUTION_DIAG_UNRESOLVED = "insurance_name_present_but_not_payer_anchor"
    DAT_PAYER_RESOLUTION_SOURCE_INAME_DISPLAY_NAME = "iname_display_name"
    DAT_PAYER_RESOLUTION_SOURCE_EXISTING = "existing_payer_anchor"
    DAT_PAYER_RESOLUTION_SOURCE_INAME_MEDISOFT_ID = "iname_medisoft_id"
    DAT_PAYER_RESOLUTION_STATUS_MISSING = "missing"
    DAT_PAYER_RESOLUTION_STATUS_RESOLVED = "resolved"
    resolve_payer_id_from_iname = None


_NORMALIZED_FIELD_KEYS = (
    "chart_number",
    "patient_id",
    "first_name",
    "last_name",
    "patient_name",
    "date_of_service",
    "payer_id",
    "insurance_name",
    "member_id",
    "dat_payer_resolution_status",
    "dat_payer_resolution_source",
    "dat_payer_resolution_diagnostic",
    "dat_payer_resolution_insurance_id",
    "dat_payer_resolution_insurance_name_key",
    "dat_payer_resolution_candidate_payer_ids",
)

_DAT_PAYER_ANCHOR_KEYS = ("payer_id", "PAYERID", "INSID", "insurance_id")
_DAT_INSURANCE_NAME_KEYS = ("insurance_name", "INAME")
_DAT_PATIENT_ANCHOR_KEYS = ("PATID", "patid", "patient_id")
_DAT_DATE_KEYS = ("date_of_service", "DOS", "DATE1", "service_date", "DATE")
_DAT_ANCHOR_SHAPE_KEYS = (
    "patient_id",
    "PATID",
    "patid",
    "CHART",
    "chart_number",
    "LAST",
    "last_name",
    "FIRST",
    "first_name",
)


def _to_text(value):
    if value is None:
        return ""
    return str(value).strip()


def _first_text(mapping, keys):
    if not isinstance(mapping, dict):
        return ""
    for key in keys:
        value = _to_text(mapping.get(key))
        if value:
            return value
    return ""


def _normalize_patient_id_boundary(value, source):
    text = _to_text(value)
    if normalize_external_patient_id is None:
        if len(text) == 5 and all(ch >= "0" and ch <= "9" for ch in text):
            return text
        return ""
    diag = normalize_external_patient_id(value, source)
    if diag.get("is_valid"):
        return diag.get("value") or ""
    return ""


def _resolve_dat_patient_anchor(record):
    """
    Resolve the DAT patient anchor.

    PATID/patid are the only authoritative DAT patient-id aliases. A normalized
    patient_id value is accepted only as a validated fallback when no explicit
    PATID alias is present, because MediLink-local rows may use patient_id for
    CHART while patid carries the true 5-digit PATID.
    """
    record = record if isinstance(record, dict) else {}
    explicit_present = False
    for key in ("PATID", "patid"):
        raw = _first_text(record, (key,))
        if raw:
            explicit_present = True
            value = _normalize_patient_id_boundary(raw, "dat_record.{0}".format(key))
            if value:
                return {
                    "patient_id": value,
                    "patient_anchor_source": key,
                    "patient_anchor_diagnostic": "explicit_patid_alias",
                    "explicit_patid_present": True,
                }
    if explicit_present:
        return {
            "patient_id": "",
            "patient_anchor_source": "",
            "patient_anchor_diagnostic": "explicit_patid_alias_invalid",
            "explicit_patid_present": True,
        }
    raw_patient_id = _first_text(record, ("patient_id",))
    if raw_patient_id:
        value = _normalize_patient_id_boundary(raw_patient_id, "dat_record.patient_id")
        if value:
            return {
                "patient_id": value,
                "patient_anchor_source": "patient_id",
                "patient_anchor_diagnostic": "validated_patient_id_fallback",
                "explicit_patid_present": False,
            }
        return {
            "patient_id": "",
            "patient_anchor_source": "",
            "patient_anchor_diagnostic": "patient_id_not_valid_patid",
            "explicit_patid_present": False,
        }
    return {
        "patient_id": "",
        "patient_anchor_source": "",
        "patient_anchor_diagnostic": "missing",
        "explicit_patid_present": False,
    }


def _first_text_with_source(mapping, keys):
    if not isinstance(mapping, dict):
        return "", ""
    for key in keys:
        value = _to_text(mapping.get(key))
        if value:
            return value, key
    return "", ""


def _empty_payer_resolution(status, source, diagnostic):
    return {
        "status": status,
        "source": source,
        "diagnostic": diagnostic,
        "insurance_id": "",
        "insurance_name_key": "",
        "candidate_payer_ids_text": "",
        "candidate_payer_ids": [],
    }


def _stored_payer_resolution(record, fallback_status, fallback_source, fallback_diagnostic):
    resolution = _empty_payer_resolution(fallback_status, fallback_source, fallback_diagnostic)
    if not isinstance(record, dict):
        return resolution
    stored_status = _to_text(record.get("dat_payer_resolution_status"))
    stored_source = _to_text(record.get("dat_payer_resolution_source"))
    stored_diagnostic = _to_text(record.get("dat_payer_resolution_diagnostic"))
    stored_insurance_id = _to_text(record.get("dat_payer_resolution_insurance_id"))
    stored_name_key = _to_text(record.get("dat_payer_resolution_insurance_name_key"))
    stored_candidates = _to_text(record.get("dat_payer_resolution_candidate_payer_ids"))
    if stored_status:
        resolution["status"] = stored_status
    if stored_source:
        resolution["source"] = stored_source
    if stored_diagnostic:
        resolution["diagnostic"] = stored_diagnostic
    if stored_insurance_id:
        resolution["insurance_id"] = stored_insurance_id
    if stored_name_key:
        resolution["insurance_name_key"] = stored_name_key
    if stored_candidates:
        resolution["candidate_payer_ids_text"] = stored_candidates
        resolution["candidate_payer_ids"] = stored_candidates.split(",")
    return resolution


def resolve_dat_payer_anchor(record, provenance=None, payer_resolution_context=None):
    """
    Resolve the DAT payer anchor and diagnostic-only insurance name.

    INAME/insurance_name is intentionally not a payer anchor. It is retained only
    for diagnostics so Medisoft rows with an insurance display name but no payer
    identifier still fail the payer-anchor contract.
    """
    record = record if isinstance(record, dict) else {}
    provenance = provenance if isinstance(provenance, dict) else {}
    payer_id, payer_source = _first_text_with_source(record, _DAT_PAYER_ANCHOR_KEYS)
    insurance_name, insurance_source = _first_text_with_source(record, _DAT_INSURANCE_NAME_KEYS)
    resolution = _empty_payer_resolution(
        DAT_PAYER_RESOLUTION_STATUS_MISSING,
        "",
        "",
    )
    if payer_id:
        status = DAT_PAYER_RESOLUTION_STATUS_RESOLVED
        resolution = _stored_payer_resolution(
            record,
            DAT_PAYER_RESOLUTION_STATUS_RESOLVED,
            DAT_PAYER_RESOLUTION_SOURCE_EXISTING,
            "",
        )
    elif _to_text(record.get("dat_payer_resolution_status")) == "ambiguous":
        resolution = _stored_payer_resolution(
            record,
            "ambiguous",
            _to_text(record.get("dat_payer_resolution_source")),
            _to_text(record.get("dat_payer_resolution_diagnostic")),
        )
        status = "ambiguous"
    elif insurance_name and resolve_payer_id_from_iname is not None:
        resolution = resolve_payer_id_from_iname(
            insurance_name,
            resolution_context=payer_resolution_context,
        )
        payer_id = resolution.get("payer_id") or ""
        payer_source = resolution.get("source") or ""
        status = resolution.get("status") or DAT_PAYER_RESOLUTION_STATUS_MISSING
    else:
        status = DAT_PAYER_RESOLUTION_STATUS_MISSING
    diagnostic = ""
    if not payer_id and insurance_name:
        diagnostic = resolution.get("diagnostic") or DAT_PAYER_RESOLUTION_DIAG_UNRESOLVED
    resolution_diagnostic = resolution.get("diagnostic") or diagnostic
    return {
        "payer_id": payer_id,
        "payer_anchor_source": payer_source,
        "payer_anchor_status": status,
        "payer_anchor_keys": ",".join(_DAT_PAYER_ANCHOR_KEYS),
        "insurance_name": insurance_name,
        "insurance_name_source": insurance_source,
        "insurance_name_diagnostic_only": bool(insurance_name and not payer_id),
        "payer_anchor_diagnostic": diagnostic,
        "dat_payer_resolution_status": resolution.get("status") or status,
        "dat_payer_resolution_source": resolution.get("source") or payer_source,
        "dat_payer_resolution_diagnostic": resolution_diagnostic,
        "dat_payer_resolution_insurance_id": resolution.get("insurance_id") or "",
        "dat_payer_resolution_insurance_name_key": resolution.get("insurance_name_key") or "",
        "dat_payer_resolution_candidate_payer_ids": resolution.get("candidate_payer_ids_text") or "",
        "source_ref": _first_text(provenance, ("source_ref",)) or _first_text(record, ("source_ref",)),
    }


def _to_int_or_none(value):
    if value is None:
        return None
    text = _to_text(value)
    if not text:
        return None
    try:
        return int(text)
    except (TypeError, ValueError):
        return None


def resolve_dat_fields(record, provenance=None, payer_resolution_context=None):
    """
    Resolve DAT join/contract fields plus row provenance from mixed legacy aliases.
    Returns a dict with normalized field names and available provenance keys.
    """
    record = record if isinstance(record, dict) else {}
    provenance = provenance if isinstance(provenance, dict) else {}

    chart_number = _first_text(record, ("chart_number", "CHART", "patient_chart"))
    patient_anchor = _resolve_dat_patient_anchor(record)
    patient_id = patient_anchor.get("patient_id") or ""
    first_name = _first_text(record, ("first_name", "FIRST", "FIRSTNAME"))
    last_name = _first_text(record, ("last_name", "LAST", "LASTNAME"))
    patient_name = _first_text(record, ("patient_name", "PATNAME"))
    if not patient_name:
        patient_name = _to_text((first_name + " " + last_name).strip())
    # Alias ladder note: keep existing date precedence stable.
    # `DATE` is the Medisoft fixed-width DAT service-date column (see
    # MediLink/MediLink_PatientProcessor.py and MediLink/MediLink_837p_encoder*.py which
    # treat parsed_data['DATE'] as surgery/service date). Placed after the pre-existing
    # CSV/DOCX-origin aliases so established precedence contracts (e.g.,
    # DAT patient-anchor precedence is handled separately by _resolve_dat_patient_anchor.
    date_of_service = _first_text(
        record,
        ("date_of_service", "DOS", "DATE1", "service_date", "DATE"),
    )
    payer_anchor = resolve_dat_payer_anchor(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    payer_id = payer_anchor.get("payer_id") or ""
    insurance_name = payer_anchor.get("insurance_name") or ""
    member_id = _first_text(record, ("member_id", "MEMID"))
    if not member_id:
        member_id = patient_id

    return {
        "chart_number": chart_number,
        "patient_id": patient_id,
        "patient_anchor_source": patient_anchor.get("patient_anchor_source") or "",
        "patient_anchor_diagnostic": patient_anchor.get("patient_anchor_diagnostic") or "",
        "explicit_patid_present": bool(patient_anchor.get("explicit_patid_present")),
        "first_name": first_name,
        "last_name": last_name,
        "patient_name": patient_name,
        "date_of_service": date_of_service,
        "payer_id": payer_id,
        "insurance_name": insurance_name,
        "member_id": member_id,
        "source_ref": _first_text(provenance, ("source_ref",)) or _first_text(record, ("source_ref",)),
        "record_index": _to_int_or_none(
            provenance.get("record_index") if provenance.get("record_index") is not None else record.get("record_index")
        ),
        "attachment_sha256": (
            _first_text(provenance, ("attachment_sha256", "sha256"))
            or _first_text(record, ("attachment_sha256", "sha256"))
        ),
    }


def normalize_dat_record(record, provenance=None, payer_resolution_context=None):
    """
    Copy record and inject normalized DAT aliases.
    Provenance is accepted for interface symmetry but not written back into the row.
    """
    if not isinstance(record, dict):
        return {}
    normalized = dict(record)
    resolved = resolve_dat_fields(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    payer_anchor = resolve_dat_payer_anchor(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    for key in _NORMALIZED_FIELD_KEYS:
        if key in resolved:
            normalized[key] = resolved.get(key) or ""
        else:
            normalized[key] = payer_anchor.get(key) or ""
    return normalized


def build_dat_decision_context(record, provenance=None, payer_resolution_context=None):
    """Context bundle shared by extractor_skip and constraint_fail DAT evidence."""
    resolved = resolve_dat_fields(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    payer_anchor = resolve_dat_payer_anchor(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    patient_id = resolved.get("patient_id") or ""
    chart_number = resolved.get("chart_number") or ""
    patient_anchor_status = "resolved" if patient_id else "missing"
    patient_anchor_diagnostic = ""
    if not patient_id and chart_number:
        patient_anchor_diagnostic = "patid_required_chart_not_usable"
    elif not patient_id:
        patient_anchor_diagnostic = resolved.get("patient_anchor_diagnostic") or ""
    elif resolved.get("patient_anchor_diagnostic"):
        patient_anchor_diagnostic = resolved.get("patient_anchor_diagnostic") or ""
    context = {
        "source_ref": resolved.get("source_ref") or "",
        "record_index": resolved.get("record_index"),
        "attachment_sha256": resolved.get("attachment_sha256") or "",
        "resolved_patient_id": patient_id,
        "dat_patient_anchor_status": patient_anchor_status,
        "dat_patient_anchor_keys": "PATID,patid,patient_id(validated fallback)",
        "dat_patient_anchor_diagnostic": patient_anchor_diagnostic,
        "resolved_date_of_service": resolved.get("date_of_service") or "",
        "resolved_payer_id": resolved.get("payer_id") or "",
        "resolved_payer_id_source": payer_anchor.get("payer_anchor_source") or "",
        "dat_payer_anchor_status": payer_anchor.get("payer_anchor_status") or "",
        "dat_payer_anchor_keys": payer_anchor.get("payer_anchor_keys") or "",
        "dat_payer_anchor_diagnostic": payer_anchor.get("payer_anchor_diagnostic") or "",
        "resolved_chart_number": chart_number,
        "chart_number_role": "supplemental_not_patient_anchor" if chart_number else "",
        "chart_anchor_usable": False,
        "resolved_insurance_name": resolved.get("insurance_name") or "",
        "resolved_insurance_name_source": payer_anchor.get("insurance_name_source") or "",
        "resolved_insurance_name_diagnostic_only": bool(payer_anchor.get("insurance_name_diagnostic_only")),
        "dat_payer_resolution_status": payer_anchor.get("dat_payer_resolution_status") or "",
        "dat_payer_resolution_source": payer_anchor.get("dat_payer_resolution_source") or "",
        "dat_payer_resolution_diagnostic": payer_anchor.get("dat_payer_resolution_diagnostic") or "",
        "dat_payer_resolution_insurance_id": payer_anchor.get("dat_payer_resolution_insurance_id") or "",
        "dat_payer_resolution_insurance_name_key": payer_anchor.get("dat_payer_resolution_insurance_name_key") or "",
        "dat_payer_resolution_candidate_payer_ids": payer_anchor.get("dat_payer_resolution_candidate_payer_ids") or "",
        "resolved_member_id": resolved.get("member_id") or "",
        "resolved_patient_name": resolved.get("patient_name") or "",
    }
    if context["record_index"] is None:
        context.pop("record_index")
    return context


def _shape_evidence(record, resolved, payer_anchor):
    record = record if isinstance(record, dict) else {}
    raw_keys = sorted([str(key) for key in record.keys() if str(key or "").strip()])
    present = {}
    for key in (
            "PATID", "patient_id", "patid", "CHART", "chart_number", "DATE", "DATE1", "DOS",
            "date_of_service", "PAYERID", "INSID", "payer_id", "insurance_id", "INAME",
            "insurance_name", "FIRST", "LAST", "first_name", "last_name"):
        if key in record and _to_text(record.get(key)):
            present[key] = True
    return {
        "raw_key_count": len(raw_keys),
        "raw_keys_sample": raw_keys[:12],
        "present_keys": present,
        "chart_present": bool(resolved.get("chart_number")),
        "patient_id_present": bool(resolved.get("patient_id")),
        "date_of_service_present": bool(resolved.get("date_of_service")),
        "payer_id_present": bool(payer_anchor.get("payer_id")),
        "insurance_name_present": bool(payer_anchor.get("insurance_name")),
        "payer_resolution_status": payer_anchor.get("dat_payer_resolution_status") or "",
        "payer_resolution_source": payer_anchor.get("dat_payer_resolution_source") or "",
        "payer_resolution_diagnostic": payer_anchor.get("dat_payer_resolution_diagnostic") or "",
    }


def build_dat_anchor_decision(record, provenance=None, payer_resolution_context=None):
    """
    Single DAT QA/join anchor decision.

    CHART remains supplemental and never satisfies the patient anchor. INAME can
    resolve a payer anchor only through deterministic payer-resolution rules.
    """
    record = record if isinstance(record, dict) else {}
    resolved = resolve_dat_fields(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    payer_anchor = resolve_dat_payer_anchor(
        record,
        provenance=provenance,
        payer_resolution_context=payer_resolution_context,
    )
    patient_anchor = resolved.get("patient_id") or ""
    service_date = resolved.get("date_of_service") or ""
    payer_id = payer_anchor.get("payer_id") or ""
    has_anchor_shape = False
    for key in _DAT_ANCHOR_SHAPE_KEYS:
        if _to_text(record.get(key)):
            has_anchor_shape = True
            break
    blocker_class = ""
    reject_code = ""
    reject_reason = ""
    if not has_anchor_shape:
        blocker_class = "unsupported_layout"
        reject_code = "QA_DAT_UNSUPPORTED_LAYOUT"
        reject_reason = "No valid dict records with PATID/CHART/LAST/FIRST"
    elif not patient_anchor:
        blocker_class = "patient_anchor_missing"
        reject_code = "QA_DAT_PATIENT_ANCHOR_MISSING"
        reject_reason = "DAT patient anchor missing (PATID required; CHART is supplemental)"
    elif not service_date:
        blocker_class = "date_of_service_missing"
        reject_code = "QA_DAT_DATE_OF_SERVICE_MISSING"
        reject_reason = "DAT service date missing (DATE/DOS/DATE1)"
    elif not payer_id:
        blocker_class = "payer_anchor_missing"
        reject_code = "QA_DAT_PAYER_ANCHOR_MISSING"
        reject_reason = "DAT payer anchor missing (PAYERID/INSID/INAME deterministic resolver)"
    decision = {
        "qa_pass": not bool(reject_code),
        "reject_code": reject_code,
        "reject_reason": reject_reason,
        "blocker_class": blocker_class or "ready",
        "patient_anchor": patient_anchor,
        "patient_anchor_source": resolved.get("patient_anchor_source") or "",
        "patient_anchor_status": "resolved" if patient_anchor else "missing",
        "patient_anchor_contract": "requires_5_digit_patid",
        "chart_number": resolved.get("chart_number") or "",
        "chart_number_role": "supplemental_not_patient_anchor" if resolved.get("chart_number") else "",
        "chart_anchor_usable": False,
        "service_date": service_date,
        "service_date_source": "date_of_service/DOS/DATE1/service_date/DATE" if service_date else "",
        "payer_anchor": payer_id,
        "payer_anchor_source": payer_anchor.get("payer_anchor_source") or "",
        "payer_anchor_status": payer_anchor.get("payer_anchor_status") or "",
        "insurance_name": payer_anchor.get("insurance_name") or "",
        "insurance_name_source": payer_anchor.get("insurance_name_source") or "",
        "insurance_name_diagnostic_only": bool(payer_anchor.get("insurance_name_diagnostic_only")),
        "payer_resolution_status": payer_anchor.get("dat_payer_resolution_status") or "",
        "payer_resolution_source": payer_anchor.get("dat_payer_resolution_source") or "",
        "payer_resolution_diagnostic": payer_anchor.get("dat_payer_resolution_diagnostic") or "",
        "payer_resolution_insurance_id": payer_anchor.get("dat_payer_resolution_insurance_id") or "",
        "payer_resolution_insurance_name_key": payer_anchor.get("dat_payer_resolution_insurance_name_key") or "",
        "payer_resolution_candidate_payer_ids": payer_anchor.get("dat_payer_resolution_candidate_payer_ids") or "",
        "safe_shape_evidence": _shape_evidence(record, resolved, payer_anchor),
    }
    decision["payer_anchor_synthetic_from_medisoft_id"] = (
        decision.get("payer_resolution_source") == DAT_PAYER_RESOLUTION_SOURCE_INAME_MEDISOFT_ID
    )
    decision["payer_anchor_synthetic_from_iname_display"] = (
        decision.get("payer_resolution_source") == DAT_PAYER_RESOLUTION_SOURCE_INAME_DISPLAY_NAME
    )
    return decision
