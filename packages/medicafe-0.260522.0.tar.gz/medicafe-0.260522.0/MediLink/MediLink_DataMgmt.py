import atexit, csv, errno, json, os, re, subprocess, sys, tempfile, time
from datetime import datetime, timedelta

# Import centralized logging configuration and timing utils
try:
    from MediCafe.logging_config import PERFORMANCE_LOGGING
except ImportError:
    PERFORMANCE_LOGGING = False
try:
    from MediCafe.timing_utils import record_stage, stage_timer, noop_timer, is_timing_enabled
except ImportError:
    record_stage = None
    stage_timer = None

    class _NoopTimer(object):
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

    noop_timer = _NoopTimer()
    is_timing_enabled = None

# Need this for running Medibot and MediLink
from MediCafe.core_utils import get_config_loader_with_fallback, extract_medilink_config

MediLink_ConfigLoader = get_config_loader_with_fallback()
try:
    import MediLink_Display_Utils
except ImportError:
    from MediLink import MediLink_Display_Utils

# Module-level flag to control skipping API-sourced insurance types during bulk edit
# Set to False to allow editing of API-sourced patients (useful for debugging)
# NOTE: API-sourced codes not in insurance_options will always be shown regardless of this flag
SKIP_API_SOURCED_INSURANCE_EDIT = True

_WINSCP_PROFILE_LOCK_FILENAME = '.medicafe_winscp_profile.lock'
_WINSCP_PROFILE_LOCK_WAIT_SEC = 900
# When liveness cannot be determined (None), do not use the same short threshold as
# for a confirmed-dead owner: the lock file mtime is not refreshed while held, so a
# long WinSCP run could otherwise be mistaken for abandon after tens of minutes.
_WINSCP_PROFILE_LOCK_UNKNOWN_OWNER_STALE_SEC = 48 * 3600
_WINSCP_PROFILE_LOCK_POLL_SEC = 0.5
_MEDISOFT_DAT_BOUNDARY_SUMMARY_BASENAME = 'medisoft_dat_boundary_summary_latest.json'
_MEDISOFT_DAT_BOUNDARY_DETAIL_BASENAME = 'medisoft_dat_boundary_detail_latest.jsonl'
_MEDISOFT_DAT_BOUNDARY_AGG = {
    'file_count': 0,
    'classifier_service_continue': 0,
    'classifier_next_patient': 0,
    'classifier_fallback': 0,
    'peek_blank_record_separator': 0,
    'peek_eof': 0,
    'slice_classifier_loaded_count': 0,
    'outliers': [],
    'latest_files': [],
}
_MEDISOFT_DAT_BOUNDARY_ROLLUP_LOGGED = False


# Import validation function
try:
    from MediLink.MediLink_insurance_utils import validate_insurance_type_from_config
except ImportError:
    validate_insurance_type_from_config = None


# MediBot imports will be done locally in functions to avoid circular imports
def _get_medibot_function(module_name, function_name):
    """Dynamically import MediBot functions when needed to avoid circular imports."""
    try:
        module = __import__('MediBot.{}'.format(module_name), fromlist=[function_name])
        return getattr(module, function_name)
    except (ImportError, AttributeError):
        return None


def _medisoft_dat_boundary_reports_dir():
    raw = str(os.environ.get('MEDICAFE_DAT_BOUNDARY_TELEMETRY_DIR', '') or '').strip()
    if raw:
        return raw
    lab = str(os.environ.get('MEDICAFE_LAB_DIR', '') or '').strip()
    if lab:
        if os.path.basename(os.path.normpath(lab)).lower() == 'reports':
            return lab
        return os.path.join(lab, 'reports')
    try:
        cfg, _ = MediLink_ConfigLoader.load_configuration()
        medi = extract_medilink_config(cfg)
        local_storage_path = medi.get('local_storage_path', '') if isinstance(medi, dict) else ''
        if local_storage_path:
            return os.path.join(local_storage_path, 'reports')
    except Exception:
        pass
    try:
        return os.path.join(os.getcwd(), 'reports')
    except Exception:
        return 'reports'


def _medisoft_dat_boundary_snapshot():
    agg = _MEDISOFT_DAT_BOUNDARY_AGG
    return {
        'schema_version': 1,
        'generated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'file_count': int(agg.get('file_count') or 0),
        'slice_classifier_loaded_count': int(agg.get('slice_classifier_loaded_count') or 0),
        'totals': {
            'classifier_service_continue': int(agg.get('classifier_service_continue') or 0),
            'classifier_next_patient': int(agg.get('classifier_next_patient') or 0),
            'classifier_fallback': int(agg.get('classifier_fallback') or 0),
            'peek_blank_record_separator': int(agg.get('peek_blank_record_separator') or 0),
            'peek_eof': int(agg.get('peek_eof') or 0),
        },
        'outliers': list(agg.get('outliers') or [])[-25:],
        'latest_files': list(agg.get('latest_files') or [])[-10:],
    }


def _write_medisoft_dat_boundary_artifacts(record):
    reports_dir = _medisoft_dat_boundary_reports_dir()
    if not reports_dir:
        return
    try:
        if not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        return
    try:
        summary_path = os.path.join(reports_dir, _MEDISOFT_DAT_BOUNDARY_SUMMARY_BASENAME)
        with open(summary_path, 'w') as f:
            json.dump(_medisoft_dat_boundary_snapshot(), f, sort_keys=True, indent=2)
            f.write('\n')
    except Exception:
        pass
    try:
        detail_path = os.path.join(reports_dir, _MEDISOFT_DAT_BOUNDARY_DETAIL_BASENAME)
        mode = 'w' if int(_MEDISOFT_DAT_BOUNDARY_AGG.get('file_count') or 0) <= 1 else 'a'
        with open(detail_path, mode) as f:
            f.write(json.dumps(record, sort_keys=True) + '\n')
    except Exception:
        pass


def _record_medisoft_dat_boundary_stats(file_path, config, boundary_stats):
    global _MEDISOFT_DAT_BOUNDARY_ROLLUP_LOGGED
    base = os.path.basename(file_path or '') or '-'
    has_slices = bool((config.get('personal_slices') or {}) and (config.get('service_slices') or {}))
    record = {
        'file_basename': base,
        'slice_classifier_loaded': bool(has_slices),
        'classifier_service_continue': int(boundary_stats.get('classifier_service') or 0),
        'classifier_next_patient': int(boundary_stats.get('classifier_next_patient') or 0),
        'classifier_fallback': int(boundary_stats.get('classifier_fallback') or 0),
        'peek_blank_record_separator': int(boundary_stats.get('peek_blank_separator') or 0),
        'peek_eof': int(boundary_stats.get('peek_eof') or 0),
    }
    agg = _MEDISOFT_DAT_BOUNDARY_AGG
    agg['file_count'] = int(agg.get('file_count') or 0) + 1
    if has_slices:
        agg['slice_classifier_loaded_count'] = int(agg.get('slice_classifier_loaded_count') or 0) + 1
    for pair in (
            ('classifier_service_continue', 'classifier_service_continue'),
            ('classifier_next_patient', 'classifier_next_patient'),
            ('classifier_fallback', 'classifier_fallback'),
            ('peek_blank_record_separator', 'peek_blank_record_separator'),
            ('peek_eof', 'peek_eof')):
        agg[pair[0]] = int(agg.get(pair[0]) or 0) + int(record.get(pair[1]) or 0)
    latest = list(agg.get('latest_files') or [])
    latest.append(record)
    agg['latest_files'] = latest[-10:]
    if record['classifier_fallback'] or record['classifier_next_patient'] or record['classifier_service_continue']:
        outliers = list(agg.get('outliers') or [])
        outliers.append(record)
        agg['outliers'] = outliers[-25:]
    _write_medisoft_dat_boundary_artifacts(record)
    try:
        MediLink_ConfigLoader.log(
            (
                'MEDISOFT_DAT_BOUNDARY_DETAIL file_basename={0} slice_classifier_loaded={1} '
                'classifier_service_continue={2} classifier_next_patient={3} classifier_fallback={4} '
                'peek_blank_record_separator={5} peek_eof={6}'
            ).format(
                base,
                int(has_slices),
                record['classifier_service_continue'],
                record['classifier_next_patient'],
                record['classifier_fallback'],
                record['peek_blank_record_separator'],
                record['peek_eof'],
            ),
            level='DEBUG',
        )
    except Exception:
        pass


def _log_medisoft_dat_boundary_rollup():
    global _MEDISOFT_DAT_BOUNDARY_ROLLUP_LOGGED
    if _MEDISOFT_DAT_BOUNDARY_ROLLUP_LOGGED:
        return
    agg = _MEDISOFT_DAT_BOUNDARY_AGG
    if int(agg.get('file_count') or 0) <= 0:
        return
    _MEDISOFT_DAT_BOUNDARY_ROLLUP_LOGGED = True
    try:
        MediLink_ConfigLoader.log(
            (
                'MEDISOFT_DAT_BOUNDARY_ROLLUP files={0} slice_classifier_loaded_files={1} '
                'classifier_service_continue={2} classifier_next_patient={3} classifier_fallback={4} '
                'peek_blank_record_separator={5} peek_eof={6} detail_artifact={7}'
            ).format(
                int(agg.get('file_count') or 0),
                int(agg.get('slice_classifier_loaded_count') or 0),
                int(agg.get('classifier_service_continue') or 0),
                int(agg.get('classifier_next_patient') or 0),
                int(agg.get('classifier_fallback') or 0),
                int(agg.get('peek_blank_record_separator') or 0),
                int(agg.get('peek_eof') or 0),
                _MEDISOFT_DAT_BOUNDARY_SUMMARY_BASENAME,
            ),
            level='INFO',
        )
    except Exception:
        pass


try:
    atexit.register(_log_medisoft_dat_boundary_rollup)
except Exception:
    pass


def _winscp_profile_lock_path(winscp_path):
    """Return the lock path shared by all calls using one portable WinSCP profile."""
    try:
        winscp_dir = os.path.dirname(os.path.abspath(winscp_path))
    except Exception:
        winscp_dir = ''
    if not winscp_dir:
        return ''
    return os.path.join(winscp_dir, _WINSCP_PROFILE_LOCK_FILENAME)


def _lock_owner_pid(lock_text):
    for line in (lock_text or '').splitlines():
        if line.startswith('pid='):
            try:
                return int(line.split('=', 1)[1].strip())
            except Exception:
                return None
    return None


def _process_is_alive_or_unknown(pid):
    if not pid or pid <= 0:
        return None
    if os.name == 'nt':
        try:
            from MediCafe.win_pid_probe import windows_process_is_alive_or_unknown
            return bool(windows_process_is_alive_or_unknown(pid))
        except Exception:
            return None
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False
    except Exception:
        return None


def _read_lock_text(lock_path):
    try:
        with open(lock_path, 'r') as handle:
            return handle.read(1024)
    except Exception:
        return ''


def _maybe_remove_stale_winscp_lock(lock_path, now):
    try:
        st = os.stat(lock_path)
    except OSError:
        return False
    except Exception:
        return False

    lock_age = max(0.0, now - float(getattr(st, 'st_mtime', now) or now))
    owner_pid = _lock_owner_pid(_read_lock_text(lock_path))
    owner_alive = _process_is_alive_or_unknown(owner_pid)
    stale_unknown = (
        owner_alive is None
        and lock_age > _WINSCP_PROFILE_LOCK_UNKNOWN_OWNER_STALE_SEC
    )
    if owner_alive is False or stale_unknown:
        try:
            os.remove(lock_path)
            MediLink_ConfigLoader.log(
                "Removed stale WinSCP profile lock at {} (age_sec={}, owner_pid={}, owner_alive={})".format(
                    lock_path,
                    int(lock_age),
                    owner_pid if owner_pid is not None else '',
                    owner_alive
                ),
                level="WARNING"
            )
            return True
        except Exception as e:
            MediLink_ConfigLoader.log(
                "Unable to remove stale WinSCP profile lock at {}: {}".format(lock_path, e),
                level="WARNING"
            )
    return False


def _acquire_winscp_profile_lock(lock_path, operation_type):
    """
    Serialize WinSCP.com launches that share one portable WinSCP.ini.

    WinSCP updates its profile/Jump List state on startup. Concurrent upload and
    download processes can race on WinSCP.ini and surface as "Error updating jump
    list" on XP, so we guard the subprocess boundary.
    """
    if not lock_path:
        return {'status': 'bypass'}

    lock_dir = os.path.dirname(lock_path)
    if not os.path.isdir(lock_dir):
        MediLink_ConfigLoader.log(
            "WinSCP profile lock directory is missing; continuing without lock: {}".format(lock_dir),
            level="WARNING"
        )
        return {'status': 'bypass'}

    started = time.time()
    last_wait_log = 0.0
    payload = "pid={}\noperation_type={}\ncreated_at={}\n".format(
        os.getpid(),
        operation_type,
        datetime.utcnow().isoformat() + 'Z'
    )
    while True:
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            try:
                os.write(fd, payload.encode('ascii', 'replace'))
            except Exception:
                pass
            waited = time.time() - started
            if waited >= 1.0:
                MediLink_ConfigLoader.log(
                    "WinSCP profile lock acquired after waiting {}s for operation_type={}".format(
                        int(waited),
                        operation_type
                    ),
                    level="INFO"
                )
            return {'status': 'acquired', 'fd': fd, 'path': lock_path}
        except OSError as e:
            if getattr(e, 'errno', None) != errno.EEXIST:
                MediLink_ConfigLoader.log(
                    "Unable to create WinSCP profile lock at {}; continuing without lock: {}".format(lock_path, e),
                    level="WARNING"
                )
                return {'status': 'bypass'}
        except Exception as e:
            MediLink_ConfigLoader.log(
                "Unexpected WinSCP profile lock error at {}; continuing without lock: {}".format(lock_path, e),
                level="WARNING"
            )
            return {'status': 'bypass'}

        now = time.time()
        _maybe_remove_stale_winscp_lock(lock_path, now)
        elapsed = now - started
        if elapsed >= _WINSCP_PROFILE_LOCK_WAIT_SEC:
            MediLink_ConfigLoader.log(
                "Timed out waiting {}s for WinSCP profile lock at {}; skipping {} to avoid WinSCP.ini contention.".format(
                    int(elapsed),
                    lock_path,
                    operation_type
                ),
                level="ERROR"
            )
            return None
        if now - last_wait_log >= 30.0:
            MediLink_ConfigLoader.log(
                "Waiting for WinSCP profile lock at {} before {} (elapsed_sec={})".format(
                    lock_path,
                    operation_type,
                    int(elapsed)
                ),
                level="INFO"
            )
            last_wait_log = now
        time.sleep(_WINSCP_PROFILE_LOCK_POLL_SEC)


def _release_winscp_profile_lock(lock_token):
    if not isinstance(lock_token, dict):
        return
    if lock_token.get('status') != 'acquired':
        return
    fd = lock_token.get('fd')
    lock_path = lock_token.get('path')
    try:
        if fd is not None:
            os.close(fd)
    except Exception:
        pass
    try:
        if lock_path and os.path.exists(lock_path):
            os.remove(lock_path)
    except Exception as e:
        MediLink_ConfigLoader.log(
            "Unable to release WinSCP profile lock at {}: {}".format(lock_path, e),
            level="WARNING"
        )

# Pre-compiled regex pattern for timestamp detection (performance optimization)
# Matches timestamps in the format YYYYMMDD_HHMMSS at the end of filename
_TIMESTAMP_PATTERN = re.compile(r'.*_\d{8}_\d{6}$')

# Helper function to slice and strip values with optional key suffix
def slice_data(data, slices, suffix=''):
    # Convert slices list to a tuple for slicing operation
    return {key + suffix: data[slice(*slices[key])].strip() for key in slices}


def _max_slice_end(slices_dict):
    """Largest end column index in a slice map (for padding fixed-width lines)."""
    m = 0
    if not isinstance(slices_dict, dict):
        return 0
    for v in slices_dict.values():
        if isinstance(v, (list, tuple)) and len(v) >= 2:
            try:
                m = max(m, int(v[1]))
            except Exception:
                continue
    return m


def _pad_line_for_slice_maps(line, *slice_dicts):
    """Right-pad line so all configured slices are addressable."""
    width = 0
    for d in slice_dicts:
        width = max(width, _max_slice_end(d))
    if width <= 0:
        return str(line or '')
    text = str(line or '').rstrip('\r\n')
    if len(text) < width:
        return text.ljust(width)
    return text


_MEDICAL_DATE_DIGITS = re.compile(r'^[\d./\-]{6,14}$')


def _looks_like_medical_date_token(text):
    """True if text plausibly encodes a DOS/service date (not a single digit)."""
    raw = str(text or '').strip()
    if len(raw) < 6:
        return False
    if not _MEDICAL_DATE_DIGITS.match(raw):
        return False
    digit_count = sum(1 for c in raw if c.isdigit())
    return digit_count >= 6


def _score_personal_vs_service_line(candidate_line, personal_slices, service_slices):
    """
    Return (personal_score, service_score) using fixed-width slice maps.
    Higher personal => physical line is shaped like a personal row (next patient).
    Higher service => line is shaped like an extra service line (continuation).
    """
    if not candidate_line or not personal_slices or not service_slices:
        return 0.0, 0.0
    pad = _pad_line_for_slice_maps(candidate_line, personal_slices, service_slices)
    try:
        pers = slice_data(pad, personal_slices)
    except Exception:
        pers = {}
    try:
        svc = slice_data(pad, service_slices)
    except Exception:
        svc = {}

    p_score = 0.0
    for key in ('FIRST', 'FNAME', 'LAST', 'LNAME', 'NAME', 'PTNAME', 'PATNAME'):
        v = str(pers.get(key, '') or '').strip()
        if len(v) >= 2 and any(c.isalpha() for c in v):
            p_score += 3.0
    for key in ('CHART', 'PATID', 'MRN', 'ACCT'):
        v = str(pers.get(key, '') or '').strip()
        if len(v) >= 1 and any(c.isdigit() for c in v):
            p_score += 1.5

    s_score = 0.0
    for key in ('DATE', 'DOS', 'DATE1', 'DATE2', 'SVDATE', 'FDOS', 'TDOS'):
        v = str(svc.get(key, '') or '').strip()
        if _looks_like_medical_date_token(v):
            s_score += 4.0
    for key in ('CPT', 'HCPCS', 'PROC', 'REV', 'CHG', 'UNITS'):
        v = str(svc.get(key, '') or '').strip()
        if v and len(v) >= 3 and (v[0].isdigit() or v.isalnum()):
            s_score += 2.0

    return p_score, s_score


def _classify_medisoft_continuation_line(candidate_stripped, personal_slices, service_slices):
    """
    After personal+insurance+service (or after 4 lines), the next physical line may be:
      - another service line for the same patient, or
      - the next patient's personal line (when blanks between patients are omitted).

    Returns: 'next_patient', 'service_continuation', or 'fallback' (use peek_yield_after policy).
    """
    if not candidate_stripped:
        return 'fallback'
    if not personal_slices or not service_slices:
        return 'fallback'
    p_score, s_score = _score_personal_vs_service_line(
        candidate_stripped, personal_slices, service_slices
    )
    margin = 0.5
    if s_score > p_score + margin:
        return 'service_continuation'
    if p_score > s_score + margin:
        return 'next_patient'
    return 'fallback'


def _load_classifier_slices_for_medisoft_reader():
    """Load personal/service slice maps from MediLink_Config (same source as parse_fixed_width_data)."""
    try:
        cfg, _ = MediLink_ConfigLoader.load_configuration()
        medi = extract_medilink_config(cfg)
        fw = medi.get('fixedWidthSlices') or {}
        ps = fw.get('personal_slices') or {}
        ss = fw.get('service_slices') or {}
        if isinstance(ps, dict) and isinstance(ss, dict) and ps and ss:
            return ps, ss
    except Exception:
        pass
    return {}, {}


def read_text_lines_with_fallback(path, preferred_encodings=None):
    """
    Read text files defensively across mixed/legacy encodings.
    Returns: (lines, encoding_used, used_replace_fallback)
    """
    encodings = preferred_encodings or ('utf-8-sig', 'cp1252')
    first_encoding = encodings[0] if encodings else 'utf-8'

    for encoding in encodings:
        try:
            with open(path, 'r', encoding=encoding, errors='strict') as handle:
                return handle.readlines(), encoding, False
        except UnicodeDecodeError:
            continue

    with open(path, 'r', encoding=first_encoding, errors='replace') as handle:
        return handle.readlines(), "{}+replace".format(first_encoding), True

# Function to parse fixed-width Medisoft output and extract claim data
def parse_fixed_width_data(personal_info, insurance_info, service_info, service_info_2=None, service_info_3=None, config=None):
    
    # Make sure we have the right config
    if not config:  # Checks if config is None or an empty dictionary
        MediLink_ConfigLoader.log("No config passed to parse_fixed_width_data. Re-loading config...", level="WARNING")
        config, _ = MediLink_ConfigLoader.load_configuration()
    
    medi = extract_medilink_config(config)
    
    # Load slice definitions from config within the MediLink_Config section
    personal_slices = medi['fixedWidthSlices']['personal_slices']
    insurance_slices = medi['fixedWidthSlices']['insurance_slices']
    service_slices = medi['fixedWidthSlices']['service_slices']

    # Parse each segment - core 3-line record structure
    parsed_data = {}
    parsed_data.update(slice_data(personal_info, personal_slices))    # Line 1: Personal info
    parsed_data.update(slice_data(insurance_info, insurance_slices))  # Line 2: Insurance info
    parsed_data.update(slice_data(service_info, service_slices))      # Line 3: Service info
    
    # Parse reserved expansion lines (future-ready design)
    if service_info_2:  # Line 4: Reserved for additional service data
        parsed_data.update(slice_data(service_info_2, service_slices, suffix='_2'))
    
    if service_info_3:  # Line 5: Reserved for additional service data
        parsed_data.update(slice_data(service_info_3, service_slices, suffix='_3'))
    
    # Replace underscores with spaces in first and last names since this is downstream of MediSoft. 
    if 'FIRST' in parsed_data:
        parsed_data['FIRST'] = parsed_data['FIRST'].replace('_', ' ')
    if 'LAST' in parsed_data:
        parsed_data['LAST'] = parsed_data['LAST'].replace('_', ' ')
    
    MediLink_ConfigLoader.log("Successfully parsed data from segments", level="DEBUG")
    
    return parsed_data

# Function to read fixed-width Medisoft output and extract claim data
def read_fixed_width_data(file_path):
    """
    Legacy function maintained for backward compatibility.
    Reads fixed-width Medisoft data with RESERVED 5-line patient record format.
    
    DESIGN NOTE: This implements a reserved record structure where each patient
    record can contain 3-5 lines (currently using 3, with 2 reserved for future expansion).
    The peek-ahead logic is intentional to handle variable-length records and maintain
    proper spacing between patient records.
    """
    # Use the consolidated function with Medisoft-specific configuration
    medisoft_config = {
        'mode': 'medisoft_records',
        'min_lines': 3,
        'max_lines': 5,
        'skip_header': False,
        # When slice maps are present, the reader scores line 4/5 as personal vs service
        # to disambiguate extra service lines from the next patient when blanks are missing.
        'medisoft_peek_yield_after_lines': 3,
    }
    ps, ss = _load_classifier_slices_for_medisoft_reader()
    if ps and ss:
        medisoft_config['personal_slices'] = ps
        medisoft_config['service_slices'] = ss
    return read_consolidated_fixed_width_data(file_path, config=medisoft_config)

def read_general_fixed_width_data(file_path, slices):
    """
    Legacy function maintained for backward compatibility.
    Handles fixed-width data based on provided slice definitions.
    """
    # Use the consolidated function with slice-based configuration
    slice_config = {
        'mode': 'slice_based',
        'slices': slices,
        'skip_header': True
    }
    return read_consolidated_fixed_width_data(file_path, config=slice_config)

# CONSOLIDATED IMPLEMENTATION - Replaces both read_fixed_width_data and read_general_fixed_width_data
def read_consolidated_fixed_width_data(file_path, config=None):
    """
    Unified function for reading various fixed-width data formats.
    
    Parameters:
    - file_path: Path to the fixed-width data file
    - config: Configuration dictionary with the following keys:
        - mode: 'medisoft_records' (reserved 5-line format) or 'slice_based'
        - slices: Dictionary of field slices (for slice_based mode)
        - skip_header: Boolean, whether to skip first line
        - min_lines: Minimum lines per record (for medisoft_records mode)
        - max_lines: Maximum lines per record (for medisoft_records mode)
    
    Returns:
    - Generator yielding parsed records based on the specified mode
    """
    if config is None:
        config = {'mode': 'medisoft_records', 'min_lines': 3, 'max_lines': 5, 'skip_header': False}
    
    mode = config.get('mode', 'medisoft_records')
    
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            # Skip header if configured
            if config.get('skip_header', False):
                next(file)
            
            if mode == 'medisoft_records':
                # Handle Medisoft reserved 5-line patient record format
                yield from _process_medisoft_records(file, file_path, config)
            elif mode == 'slice_based':
                # Handle slice-based field extraction
                yield from _process_slice_based_records(file, file_path, config)
            else:
                raise ValueError("Invalid mode '{}'. Use 'medisoft_records' or 'slice_based'".format(mode))
                
    except FileNotFoundError:
        print("File not found: {}".format(file_path))
        MediLink_ConfigLoader.log("File not found: {}".format(file_path), level="ERROR")
        return

def _process_medisoft_records(file, file_path, config):
    """Helper function to process Medisoft-style multi-line patient records
    
    RECORD FORMAT DESIGN (RESERVED 5-LINE STRUCTURE):
    ════════════════════════════════════════════════════════════════
    Each patient record is designed as a RESERVED 5-line block:
    
    Line 1: Personal Info     (REQUIRED - Always present)
    Line 2: Insurance Info    (REQUIRED - Always present)  
    Line 3: Service Info      (REQUIRED - Always present)
    Line 4: Service Info 2    (RESERVED - Future expansion)
    Line 5: Service Info 3    (RESERVED - Future expansion)
    [Blank line]             (Record separator)
    
    CURRENT PRODUCTION STATE:
    ────────────────────────────
    - Currently using: 3 active lines per record
    - Lines 4-5: Reserved for future service data expansion
    - Blank lines: Maintain proper record separation
    - Total: 5-line reserved format ready for expansion
    
    PEEK-AHEAD LOGIC PURPOSE:
    ────────────────────────────
    The peek-ahead logic serves to:
    1. Detect when we've reached the end of a record (blank line)
    2. Allow for future expansion to 4-5 lines without code changes
    3. Maintain proper spacing between patient records
    4. Handle variable-length records (3-5 lines) gracefully
    
    FUTURE EXPANSION READY:
    ────────────────────────────
    When additional service lines are needed:
    - No code changes required in reader logic
    - Parser automatically handles service_info_2 and service_info_3
    - Slice definitions can be extended in configuration
    - Maintains backward compatibility with 3-line records
    ════════════════════════════════════════════════════════════════
    """
    MediLink_ConfigLoader.log("Starting to read fixed width data...", level="DEBUG")
    MediLink_ConfigLoader.log("Successfully read data from file: {}".format(file_path), level="DEBUG")
    lines_buffer = []  # Buffer to hold lines for current patient data
    min_lines = config.get('min_lines', 3)
    max_lines = config.get('max_lines', 5)
    boundary_stats = {
        'classifier_service': 0,
        'classifier_next_patient': 0,
        'classifier_fallback': 0,
        'peek_blank_separator': 0,
        'peek_eof': 0,
    }
    
    # Helper function to extract record from buffer (reduces code duplication)
    def extract_record(buffer):
        """Extract record tuple from buffer, handling variable-length records (3-5 lines)."""
        personal_info = buffer[0]        # Line 1: Always present (personal data)
        insurance_info = buffer[1]       # Line 2: Always present (insurance data)
        service_info = buffer[2]         # Line 3: Always present (primary service data)
        service_info_2 = buffer[3] if len(buffer) > 3 else None  # Line 4: Reserved (future expansion)
        service_info_3 = buffer[4] if len(buffer) > 4 else None  # Line 5: Reserved (future expansion)
        return personal_info, insurance_info, service_info, service_info_2, service_info_3
    
    # Use readline() consistently to avoid iterator mixing issues
    # Maintain a look-ahead buffer for proper peek-ahead functionality
    look_ahead = None
    
    while True:
        # Get next line: use look-ahead if available, otherwise read from file
        if look_ahead is not None:
            line = look_ahead
            look_ahead = None
        else:
            line = file.readline()
            if not line:  # End of file
                break
        
        physical_line = line.rstrip('\r\n')
        stripped_line = physical_line.strip()

        if stripped_line:
            # Preserve leading/trailing spaces inside the line for fixed-width slice alignment.
            lines_buffer.append(physical_line)
            
            # Check if we're within the reserved record size (3-5 lines)
            if min_lines <= len(lines_buffer) <= max_lines:
                # Peek ahead to detect record boundary (intentional design)
                next_line = file.readline()
                if not next_line:
                    # End of file - yield complete record
                    boundary_stats['peek_eof'] += 1
                    yield extract_record(lines_buffer)
                    lines_buffer.clear()
                    break
                
                next_physical = next_line.rstrip('\r\n')
                next_stripped = next_physical.strip()
                if not next_stripped:
                    # Found record separator (blank line) - yield complete record
                    boundary_stats['peek_blank_separator'] += 1
                    yield extract_record(lines_buffer)
                    lines_buffer.clear()
                    # Don't store the blank line in look_ahead, just continue
                else:
                    # Next line has content: optional 4th/5th service line vs next patient.
                    try:
                        peek_yield_after = int(config.get('medisoft_peek_yield_after_lines', 3))
                    except Exception:
                        peek_yield_after = 3
                    if peek_yield_after < 1:
                        peek_yield_after = 3

                    ps = config.get('personal_slices') or {}
                    ss = config.get('service_slices') or {}
                    buf_len = len(lines_buffer)
                    if buf_len in (3, 4):
                        kind = _classify_medisoft_continuation_line(
                            next_physical, ps, ss
                        )
                    else:
                        kind = 'fallback'

                    if kind == 'service_continuation' and buf_len < max_lines:
                        boundary_stats['classifier_service'] += 1
                        look_ahead = next_line
                    elif kind == 'next_patient':
                        boundary_stats['classifier_next_patient'] += 1
                        yield extract_record(lines_buffer)
                        lines_buffer.clear()
                        look_ahead = next_line
                    elif kind == 'fallback':
                        boundary_stats['classifier_fallback'] += 1
                        if (buf_len == peek_yield_after
                                and peek_yield_after < max_lines):
                            yield extract_record(lines_buffer)
                            lines_buffer.clear()
                            look_ahead = next_line
                        elif buf_len < max_lines:
                            look_ahead = next_line
                        else:
                            yield extract_record(lines_buffer)
                            lines_buffer.clear()
                            look_ahead = next_line
        else:
            # Blank line encountered - end of current record
            if len(lines_buffer) >= min_lines:
                yield extract_record(lines_buffer)
                lines_buffer.clear()
                
    # Yield any remaining buffer if file ends without a blank line
    # Only yield if buffer has minimum required lines
    if len(lines_buffer) >= min_lines:
        yield extract_record(lines_buffer)

    try:
        _record_medisoft_dat_boundary_stats(file_path, config, boundary_stats)
    except Exception:
        pass

def _process_slice_based_records(file, file_path, config):
    """Helper function to process slice-based field extraction"""
    slices = config.get('slices', {})
    for line_number, line in enumerate(file, start=1):
        extracted_data = {key: line[start:end].strip() for key, (start, end) in slices.items()}
        yield extracted_data, line_number

# REFACTORING STATUS: COMPLETED - Legacy functions are PERMANENT compatibility layers
# 
# Consolidated read_fixed_width_data and read_general_fixed_width_data into
# read_consolidated_fixed_width_data with unified configuration-based approach.
# Legacy wrapper functions are maintained as PERMANENT compatibility layers (not temporary shims).
# 
# DESIGN NOTE: The reserved 5-line record format is intentional architecture:
# - Lines 1-3: Active data (personal, insurance, service)  
# - Lines 4-5: Reserved for future service expansion
# - Peek-ahead logic maintains proper record spacing and handles variable-length records
# 
# IMPLEMENTATION STATUS & RATIONALE:
# - Primary value achieved: Single consolidated implementation provides unified parsing and logging
#   behavior across MediLink UI, MediBot preprocessors, MediCafe CLI, and 837 encoder.
#   This reduces per-module parser drift and keeps config slice tweaks centralized.
# 
# - Legacy functions MUST remain: They provide type-safe APIs with incompatible return signatures:
#   * read_fixed_width_data: Returns 5-tuples (personal_info, insurance_info, service_info, 
#     service_info_2, service_info_3) for Medisoft record format
#   * read_general_fixed_width_data: Returns 2-tuples (extracted_data, line_number) for 
#     slice-based extraction
#   These cannot be unified without breaking all existing callers.
# 
# - Active callers (verified):
#   * read_fixed_width_data: MediLink_837p_encoder.py:256, MediLink_UI.py:150, 
#     MediLink_PatientProcessor.py:359 (all expect 5-tuple unpacking)
#   * read_general_fixed_width_data: MediBot_Preprocessor_lib.py:1803 (expects 2-tuple unpacking)
#   * MediCafe/__main__.py:59 validates both functions exist at startup
# 
# - Risk assessment: HIGH if legacy functions removed. Removing them would cause:
#   * ValueError: too many/few values to unpack in all callers
#   * Startup validation failures in MediCafe/__main__.py
#   * Breaking changes across 5+ files with no clear benefit
# 
# - Legacy wrappers are minimal (3-4 lines each) and correctly delegate to consolidated function.
#   They provide clear, type-safe APIs for each use case with no performance or maintenance burden.
#   Recommendation: Keep permanently as intentional compatibility layers.

def consolidate_csvs(source_directory, file_prefix="Consolidated", interactive=False):
    """
    Consolidate CSV files in the source directory into a single CSV file.
    
    Parameters:
        source_directory (str): The directory containing the CSV files to consolidate.
        file_prefix (str): The prefix for the consolidated file's name.
        interactive (bool): If True, prompt the user for confirmation before overwriting existing files.
    
    Returns:
        str: The filepath of the consolidated CSV file, or None if no files were consolidated.
    """
    today = datetime.now()
    consolidated_filename = "{}_{}.csv".format(file_prefix, today.strftime("%m%d%y"))
    consolidated_filepath = os.path.join(source_directory, consolidated_filename)

    consolidated_data = []
    header_saved = False
    expected_header = None

    # Check if the file already exists and log the action
    if os.path.exists(consolidated_filepath):
        MediLink_ConfigLoader.log("The file {} already exists. It will be overwritten.".format(consolidated_filename), level="INFO")
        if interactive:
            overwrite = input("The file {} already exists. Do you want to overwrite it? (y/n): ".format(consolidated_filename)).strip().lower()
            if overwrite != 'y':
                MediLink_ConfigLoader.log("User opted not to overwrite the file {}.".format(consolidated_filename), level="INFO")
                return None

    for filename in os.listdir(source_directory):
        filepath = os.path.join(source_directory, filename)
        if not filepath.endswith('.csv') or os.path.isdir(filepath) or filepath == consolidated_filepath:
            continue  # Skip non-CSV files, directories, and the target consolidated file itself

        # Check if the file was created within the last day
        modification_time = datetime.fromtimestamp(os.path.getmtime(filepath))
        if modification_time < today - timedelta(days=1):
            continue  # Skip files not modified in the last day

        try:
            with open(filepath, 'r', encoding='utf-8') as csvfile:
                reader = csv.reader(csvfile)
                header = next(reader)  # Read the header
                if not header_saved:
                    expected_header = header
                    consolidated_data.append(header)
                    header_saved = True
                elif header != expected_header:
                    MediLink_ConfigLoader.log("Header mismatch in file {}. Skipping file.".format(filepath), level="WARNING")
                    continue

                consolidated_data.extend(row for row in reader)
        except StopIteration:
            MediLink_ConfigLoader.log("File {} is empty or contains only header. Skipping file.".format(filepath), level="WARNING")
            continue
        except Exception as e:
            MediLink_ConfigLoader.log("Error processing file {}: {}".format(filepath, e), level="ERROR")
            continue

        os.remove(filepath)
        MediLink_ConfigLoader.log("Deleted source file after consolidation: {}".format(filepath), level="INFO")

    if consolidated_data:
        with open(consolidated_filepath, 'w', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(consolidated_data)
        MediLink_ConfigLoader.log("Consolidated CSVs into {}".format(consolidated_filepath), level="INFO")
        return consolidated_filepath
    else:
        MediLink_ConfigLoader.log("No valid CSV files were found for consolidation.", level="INFO")
        return None

def operate_winscp(operation_type, files, endpoint_config, local_storage_path, config, progress_callback=None):
    """
    General function to operate WinSCP for uploading or downloading files.
    """
    MediLink_ConfigLoader.log("Starting operate_winscp with operation_type: {}".format(operation_type))
    
    config = ensure_config_loaded(config)
    winscp_path = get_winscp_path(config)
    
    if not os.path.isfile(winscp_path):
        MediLink_ConfigLoader.log("WinSCP.com not found at {}".format(winscp_path), level="ERROR")
        return []

    validate_endpoint_config(endpoint_config)
    winscp_log_path = setup_logging(operation_type, local_storage_path)

    # Validate the local_storage_path and replace it if necessary
    local_storage_path = validate_local_storage_path(local_storage_path, config)

    remote_directory = get_remote_directory(endpoint_config, operation_type)
    if operation_type == "download":
        try:
            from MediLink_RemittancePipeline import get_winscp_fetch_tokens
        except ImportError:
            get_winscp_fetch_tokens = None
        default_mask = get_winscp_fetch_tokens() if get_winscp_fetch_tokens else [
            'era', '277', '277ibr', '277ebr', '277dpr', '999'
        ]
        filemask = endpoint_config.get('filemask')
        if filemask is None:
            filemask = default_mask
    else:
        filemask = None
    command = build_command(winscp_path, winscp_log_path, endpoint_config, remote_directory, operation_type, files, local_storage_path, newer_than=None, filemask=filemask)

    if config.get("TestMode", True):
        MediLink_ConfigLoader.log("Test mode is enabled. Simulating operation.")
        return simulate_operation(operation_type, files, config)
    
    pre_download_snapshot = None
    if operation_type == "download":
        remittance_extensions = _get_remittance_listing_extensions()
        pre_download_snapshot = {}
        candidate_paths = [local_storage_path]
        winscp_download_path = config.get('winscp_download_path')
        if winscp_download_path:
            candidate_paths.insert(0, winscp_download_path)

        seen = set()
        for candidate in candidate_paths:
            if not candidate:
                continue
            normalized = os.path.normpath(candidate)
            if normalized in seen:
                continue
            seen.add(normalized)
            pre_download_snapshot[normalized] = set(
                list_downloaded_files(normalized, allowed_extensions=remittance_extensions)
            )

    result = execute_winscp_command(
        command,
        operation_type,
        files,
        local_storage_path,
        pre_download_snapshot=pre_download_snapshot,
        winscp_lock_path=_winscp_profile_lock_path(winscp_path),
        progress_callback=progress_callback
    )
    MediLink_ConfigLoader.log("[Execute WinSCP Command] Result: {}".format(result), level="DEBUG")
    return result


def _filter_new_downloads(target_dir, downloaded_files, pre_download_snapshot):
    """Filter file listing to files that are new since the current WinSCP run started."""
    if not downloaded_files:
        return []
    if not pre_download_snapshot:
        return downloaded_files

    normalized_target = os.path.normpath(target_dir)
    baseline = pre_download_snapshot.get(normalized_target, set())
    if not baseline:
        return downloaded_files

    return [p for p in downloaded_files if p not in baseline]

def validate_local_storage_path(local_storage_path, config):
    """
    Validates the local storage path and replaces it with outputFilePath from config if it contains spaces.
    """
    if ' ' in local_storage_path:
        MediLink_ConfigLoader.log("Local storage path contains spaces, using outputFilePath from config.", level="WARN")
        output_file_path = config.get('outputFilePath', None)
        if not output_file_path:
            raise ValueError("outputFilePath not found in config.")
        return os.path.normpath(output_file_path)
    return os.path.normpath(local_storage_path)

def ensure_config_loaded(config):
    MediLink_ConfigLoader.log("Ensuring configuration is loaded.", level="DEBUG")
    if not config:
        MediLink_ConfigLoader.log("Warning: No config passed to ensure_config_loaded. Re-loading config...")
        config, _ = MediLink_ConfigLoader.load_configuration()
    
    # Check if config was successfully loaded
    if not config or 'MediLink_Config' not in config:
        MediLink_ConfigLoader.log("Failed to load the MediLink configuration. Config is None or missing 'MediLink_Config'.")
        raise RuntimeError("Failed to load the MediLink configuration. Config is None or missing 'MediLink_Config'.")

    # Check that 'endpoints' key exists within 'MediLink_Config'
    if 'endpoints' not in config['MediLink_Config']:
        MediLink_ConfigLoader.log("The loaded configuration is missing the 'endpoints' section.")
        raise ValueError("The loaded configuration is missing the 'endpoints' section.")

    # Additional checks can be added here to ensure all expected keys and structures are present
    if 'local_storage_path' not in config['MediLink_Config']:
        MediLink_ConfigLoader.log("The loaded configuration is missing the 'local_storage_path' setting.")
        raise ValueError("The loaded configuration is missing the 'local_storage_path' setting.")

    MediLink_ConfigLoader.log("Configuration loaded successfully.", level="DEBUG")
    return config['MediLink_Config']  # Return the relevant part of the config for simplicity

def get_winscp_path(config):
    MediLink_ConfigLoader.log("Retrieving WinSCP path from provided config.", level="DEBUG")
    
    def find_winscp_path(cfg):
        if 'winscp_path' in cfg:
            # cfg is already 'MediLink_Config'
            MediLink_ConfigLoader.log("Config provided directly as 'MediLink_Config'.", level="DEBUG")
            return cfg.get('winscp_path')
        else:
            # cfg is the full configuration, retrieve 'MediLink_Config'
            MediLink_ConfigLoader.log("Config provided as full configuration; accessing 'MediLink_Config'.", level="DEBUG")
            medi_link_config = cfg.get('MediLink_Config', {})
            return medi_link_config.get('winscp_path')

    # Attempt to find the WinSCP path using the provided config
    winscp_path = find_winscp_path(config)
    
    # If the path is not found, attempt to use default paths
    if not winscp_path:
        error_message = "WinSCP path not found in config. Attempting to use default paths."
        # print(error_message)
        MediLink_ConfigLoader.log(error_message)
        
        # Try the default paths
        default_paths = [
            os.path.join(os.getcwd(), "Installers", "WinSCP-Portable", "WinSCP.com"),
            os.path.join(os.getcwd(), "Necessary Programs", "WinSCP-Portable", "WinSCP.com")
        ]
        
        for path in default_paths:
            if os.path.exists(path):
                found_message = "WinSCP found at {}. Using this path.".format(path)
                # print(found_message)
                MediLink_ConfigLoader.log(found_message)
                return path
        
        # If no valid path is found, attempt to reload the configuration
        reload_message = "WinSCP not found in config or default paths. Reloading the entire configuration."
        # print(reload_message)
        MediLink_ConfigLoader.log(reload_message)
        
        try:
            config, _ = MediLink_ConfigLoader.load_configuration()
            winscp_path = find_winscp_path(config)
            
            if winscp_path:
                success_message = "WinSCP path found after reloading configuration. Using this path."
                # print(success_message)
                MediLink_ConfigLoader.log(success_message)
                return winscp_path
            else:
                raise FileNotFoundError("WinSCP path not found even after reloading configuration.")
        
        except Exception as e:
            error_message = "Failed to reload configuration or find WinSCP path: {}. Exiting script.".format(e)
            print(error_message)
            MediLink_ConfigLoader.log(error_message)
            raise FileNotFoundError(error_message)
    
    return winscp_path

def validate_endpoint_config(endpoint_config):
    MediLink_ConfigLoader.log("Validating endpoint configuration.", level="DEBUG")
    if not isinstance(endpoint_config, dict):
        MediLink_ConfigLoader.log("Endpoint configuration object is invalid. Expected a dictionary, got: {}".format(type(endpoint_config)))
        raise ValueError("Endpoint configuration object is invalid. Expected a dictionary, got: {}".format(type(endpoint_config)))

def setup_logging(operation_type, local_storage_path):
    MediLink_ConfigLoader.log("Setting up logging for operation type: {}".format(operation_type), level="DEBUG")
    log_filename = "winscp_upload.log" if operation_type == "upload" else "winscp_download.log"
    return os.path.join(local_storage_path, log_filename)

def get_remote_directory(endpoint_config, operation_type):
    MediLink_ConfigLoader.log("Getting remote directory for operation type: {}".format(operation_type), level="DEBUG")
    if endpoint_config is None:
        MediLink_ConfigLoader.log("Error: Endpoint configuration is None.")
        raise ValueError("Endpoint configuration is None. Expected a dictionary with configuration details.")

    if not isinstance(endpoint_config, dict):
        MediLink_ConfigLoader.log("Error: Endpoint configuration is invalid. Expected a dictionary, got: {}".format(type(endpoint_config)))
        raise TypeError("Endpoint configuration is invalid. Expected a dictionary, got: {}".format(type(endpoint_config)))

    try:
        if operation_type == "upload":
            return endpoint_config['remote_directory_up']
        elif operation_type == "download":
            return endpoint_config['remote_directory_down']
        else:
            MediLink_ConfigLoader.log("Invalid operation type: {}. Expected 'upload' or 'download'.".format(operation_type))
            raise ValueError("Invalid operation type: {}. Expected 'upload' or 'download'.".format(operation_type))
    except KeyError as e:
        MediLink_ConfigLoader.log("Critical Error: Endpoint config is missing key: {}".format(e))
        raise RuntimeError("Configuration error: Missing required remote directory in endpoint configuration.")

def _sanitize_winscp_filemask(mask):
    """
    Sanitize a filemask string for WinSCP. Removes backslashes and other
    characters that can break shell/argument parsing on Windows.
    """
    if not mask or not isinstance(mask, str):
        return '*'
    # Strip backslashes (can cause "Mask is invalid" when passed through subprocess on Windows)
    s = mask.replace('\\', '').strip()
    # Allow only WinSCP-safe chars: * . | ; 0-9 A-Z a-z _ -
    allowed = set('*.|;0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_-')
    if not all(c in allowed for c in s):
        return '*'
    return s if s else '*'


def normalize_filemask(filemask):
    """
    Normalize various filemask inputs into WinSCP-compatible string.
    Supports list of extensions, comma-separated string, or dict with 'extensions' and other filters.
    Falls back to '*' when input is invalid. Result is sanitized for WinSCP/shell safety.
    """
    try:
        if not filemask:
            return '*'
        if isinstance(filemask, list):
            parts = []
            for ext in filemask:
                s = str(ext).strip().lstrip('*.').lstrip('.')
                if s and all(ch.isalnum() or ch in '_-' for ch in s):
                    parts.append('*.{}'.format(s))
            # WinSCP expects multiple include masks to be separated with ';'.
            # '|' is reserved for include/exclude boundaries and breaks plain
            # multi-extension masks such as '*.era|*.277'.
            result = ';'.join(parts) if parts else '*'
            return _sanitize_winscp_filemask(result)
        if isinstance(filemask, dict):
            exts = filemask.get('extensions', [])
            other = []
            for k, v in filemask.items():
                if k == 'extensions':
                    continue
                other.append(str(v))
            ext_part = normalize_filemask(exts)
            other_part = ';'.join(other)
            if ext_part and other_part:
                result = '{};{}'.format(ext_part, other_part)
            else:
                result = ext_part or other_part or '*'
            return _sanitize_winscp_filemask(result)
        if isinstance(filemask, str):
            # Support comma-separated lists and normalize legacy pipe-separated
            # extension lists emitted by older code.
            raw = filemask.replace(' ', '')
            if ',' in raw:
                tokens = raw.split(',')
                return normalize_filemask([t for t in tokens if t])
            if '|' in raw:
                tokens = [t for t in raw.split('|') if t]
                simple_ext_tokens = True
                for token in tokens:
                    s = token.strip().lstrip('*.').lstrip('.')
                    if not (s and all(ch.isalnum() or ch in '_-' for ch in s)):
                        simple_ext_tokens = False
                        break
                if simple_ext_tokens:
                    return normalize_filemask(tokens)
            # If looks like an extension, prefix
            s = raw.lstrip('*.').lstrip('.')
            if s and all(ch.isalnum() or ch in '_-' for ch in s):
                result = '*.{}'.format(s)
            else:
                result = raw or '*'
            return _sanitize_winscp_filemask(result)
    except Exception as e:
        try:
            MediLink_ConfigLoader.log(
                "Filemask normalization failed: {} (input: {}); falling back to '*'.".format(e, filemask),
                level="WARNING"
            )
        except Exception:
            pass
        return '*'

def build_command(winscp_path, winscp_log_path, endpoint_config, remote_directory, operation_type, files, local_storage_path, newer_than=None, filemask=None):
    # Log the operation type
    MediLink_ConfigLoader.log("[Build Command] Building WinSCP command for operation type: {}".format(operation_type), level="DEBUG")

    session_name = endpoint_config.get('session_name', '')

    # Initial command structure with options to disable timestamp preservation and permission setting (should now be compatible with Availity, hopefully this doesn't break everything else)
    command = [
        winscp_path,
        '/log=' + winscp_log_path,
        '/loglevel=1',
        '/nopreservetime',  # Disable timestamp preservation
        '/nopermissions',   # Disable permission setting
        '/command',
        'open {}'.format(session_name),
        'cd /',
        'cd {}'.format(remote_directory)
    ]

    try:
        # Handle upload operation
        if operation_type == "upload":
            if not files:
                MediLink_ConfigLoader.log("Error: No files provided for upload operation.", level="ERROR")
                raise ValueError("No files provided for upload operation.")

            put_commands = []
            for f in files:
                # Normalize the path
                normalized_path = os.path.normpath(f)
                original_path = normalized_path  # Keep for logging

                # Remove leading slash if present
                if normalized_path.startswith('\\') or normalized_path.startswith('/'):
                    normalized_path = normalized_path.lstrip('\\/')
                    MediLink_ConfigLoader.log("Removed leading slash from path: {}".format(original_path), level="DEBUG")

                # Remove trailing slash if present
                if normalized_path.endswith('\\') or normalized_path.endswith('/'):
                    normalized_path = normalized_path.rstrip('\\/')
                    MediLink_ConfigLoader.log("Removed trailing slash from path: {}".format(original_path), level="DEBUG")

                # Determine if quotes are necessary (e.g., if path contains spaces)
                if ' ' in normalized_path:
                    put_command = 'put "{}"'.format(normalized_path)
                    MediLink_ConfigLoader.log("Constructed put command with quotes: {}".format(put_command), level="DEBUG")
                else:
                    put_command = 'put {}'.format(normalized_path)
                    MediLink_ConfigLoader.log("Constructed put command without quotes: {}".format(put_command), level="DEBUG")

                put_commands.append(put_command)
            command += put_commands

        # Handle download operation
        elif operation_type == "download":
            lcd_path = os.path.normpath(local_storage_path)
            original_lcd_path = lcd_path  # Keep for logging

            # Remove leading slash if present
            if lcd_path.startswith('\\') or lcd_path.startswith('/'):
                lcd_path = lcd_path.lstrip('\\/')
                MediLink_ConfigLoader.log("Removed leading slash from local storage path: {}".format(original_lcd_path), level="DEBUG")

            # Remove trailing slash if present
            if lcd_path.endswith('\\') or lcd_path.endswith('/'):
                lcd_path = lcd_path.rstrip('\\/')
                MediLink_ConfigLoader.log("Removed trailing slash from local storage path: {}".format(original_lcd_path), level="DEBUG")

            # Determine if quotes are necessary (e.g., if path contains spaces)
            if ' ' in lcd_path:
                lcd_command = 'lcd "{}"'.format(lcd_path)
                MediLink_ConfigLoader.log("Constructed lcd command with quotes: {}".format(lcd_command), level="DEBUG")
            else:
                lcd_command = 'lcd {}'.format(lcd_path)
                MediLink_ConfigLoader.log("Constructed lcd command without quotes: {}".format(lcd_command), level="DEBUG")

            # XP/WinSCP NOTE:
            # - On XP, shell parsing quirks can break unquoted paths; prefer explicit quoting as above.
            # - Also avoid trailing backslashes which can be treated as escape characters in some shells.
            # - If downloads still do not appear in 'local_storage_path', cross-check WinSCP's session logs
            #   for the absolute target path actually used.
            command.append(lcd_command)

            # Handle filemask input
            if filemask:
                # TODO (MEDIUM PRIORITY - WinSCP Filemask Implementation):
                # PROBLEM: Need to translate various filemask input formats into proper WinSCP syntax.
                # Current implementation is incomplete and may not handle all edge cases.
                #
                # WINSCP FILEMASK SYNTAX REQUIREMENTS:
                # - Multiple extensions: "*.ext1;*.ext2;*.ext3" (semicolon-separated)
                # - Single extension: "*.ext"
                # - All files: "*" or "*.*"
                # - Date patterns: "*YYYYMMDD*" for date-based filtering
                # - Size patterns: ">100K" for files larger than 100KB
                # - Combined: "*.csv;*.txt;>1K" (semicolon-separated masks/filters)
                #
                # INPUT FORMATS TO HANDLE:
                # 1. List: ['csv', 'txt', 'pdf'] -> "*.csv;*.txt;*.pdf"
                # 2. Dictionary: {'extensions': ['csv'], 'size': '>1K'} -> "*.csv;>1K"
                # 3. String: "csv,txt" -> "*.csv;*.txt" (comma-separated to semicolon-separated)
                # 4. None/Empty: -> "*" (all files)
                #
                # IMPLEMENTATION STEPS / RISK NOTES:
                # 1. normalize_filemask(filemask) exists but needs comprehensive tests (unit + on-box)
                #    to guarantee XP/legacy shells parse the resulting mask and to ensure we never
                #    silently skip remits. Guard with explicit logging when normalization falls back.
                # 2. Endpoint JSON sometimes stores dicts with extra keys (size, age); preserve those
                #    semantics by sorting AND/OR clauses deterministically before composing the mask.
                # 3. Add schema validation upfront (e.g., str/list/dict only) so automation pipelines
                #    fail fast instead of emitting malformed WinSCP commands.
                # 4. Document the supported structures in docs + example configs so endpoint owners
                #    can safely tune filters without touching Python.
                # 5. XP QUIRK: Prefer simple masks (e.g., *.csv;*.txt) and avoid complex AND/OR until
                #    verified on XP; consider feature flag to keep legacy behavior if issues arise.
                filemask_str = normalize_filemask(filemask)
                try:
                    MediLink_ConfigLoader.log("[Build Command] Filemask normalized to: {}".format(filemask_str), level="DEBUG")
                except Exception:
                    pass
            else:
                filemask_str = '*'  # Default to all files if filemask is None

            # Use synchronize command for efficient downloading.
            # Avoid embedding double-quotes in the script line: on Windows subprocess.list2cmdline
            # escapes them and WinSCP can receive \" causing "Mask is invalid" (e.g. near trailing \').
            # normalize_filemask may be typed as optional; membership needs a real str.
            _fm = filemask_str if isinstance(filemask_str, str) else '*'
            if newer_than:
                sync_cmd = 'synchronize local -filemask="{}" -newerthan={}'.format(_fm, newer_than) if ' ' in _fm else 'synchronize local -filemask={} -newerthan={}'.format(_fm, newer_than)
            else:
                sync_cmd = 'synchronize local -filemask="{}"'.format(_fm) if ' ' in _fm else 'synchronize local -filemask={}'.format(_fm)
            command.append(sync_cmd)

            # XP/WinSCP NOTE:
            # - If downloads still land elsewhere, introduce a 'winscp_download_path' override in config
            #   and use that here for lcd + listing. Keep default behavior unchanged for now.

        # Close and exit commands
        command += ['close', 'exit']
        MediLink_ConfigLoader.log("[Build Command] WinSCP command: {}".format(command), level="DEBUG")
        return command

    except Exception as e:
        MediLink_ConfigLoader.log("Error in build_command: {}. Reverting to original implementation.".format(e), level="ERROR")

        # Fallback to original implementation
        # Handle upload operation
        if operation_type == "upload":
            if not files:
                MediLink_ConfigLoader.log("Error: No files provided for upload operation.", level="ERROR")
                raise ValueError("No files provided for upload operation.")
            command.extend(["put {}".format(os.path.normpath(file_path)) for file_path in files])

        # Handle download operation
        else:
            command.append('get *')

        # Close and exit commands
        command.extend(['close', 'exit'])
        MediLink_ConfigLoader.log("[Build Command] Original WinSCP command: {}".format(command), level="DEBUG")
        return command

def simulate_operation(operation_type, files, config):
    MediLink_ConfigLoader.log("Test Mode is enabled! Simulating WinSCP {} operation.".format(operation_type))
    
    if operation_type == 'upload' and files:
        MediLink_ConfigLoader.log("Simulating 3 second delay for upload operation for files: {}".format(files))
        time.sleep(3)
        return [os.path.normpath(file) for file in files if os.path.exists(file)]
    elif operation_type == 'download':
        MediLink_ConfigLoader.log("Simulating 3 second delay for download operation. No files to download in test mode.")
        time.sleep(3)
        return []
    else:
        MediLink_ConfigLoader.log("Invalid operation type during simulation: {}".format(operation_type))
        return []

def _winscp_log_path_from_command(command):
    try:
        for item in command or []:
            text = str(item or '')
            lower = text.lower()
            if lower.startswith('/log='):
                return text[5:].strip('"')
    except Exception:
        pass
    return ''


def _safe_call_progress(progress_callback, event):
    if not progress_callback:
        return
    try:
        progress_callback(event)
    except Exception:
        pass


def _emit_winscp_progress(progress_callback, event_kind, operation_type, started_at, winscp_log_path, process=None, returncode=None):
    now = time.time()
    event = {
        'event': event_kind,
        'operation_type': operation_type,
        'elapsed_sec': int(max(0, now - started_at)),
        'log_updated_age_sec': None,
        'log_size_bytes': None,
        'returncode': returncode,
    }
    if winscp_log_path and os.path.exists(winscp_log_path):
        try:
            event['log_size_bytes'] = os.path.getsize(winscp_log_path)
        except Exception:
            event['log_size_bytes'] = None
        try:
            event['log_updated_age_sec'] = int(max(0, now - os.path.getmtime(winscp_log_path)))
        except Exception:
            event['log_updated_age_sec'] = None
    if process is not None:
        try:
            event['pid'] = process.pid
        except Exception:
            pass
    _safe_call_progress(progress_callback, event)


def _read_temp_stream(path):
    if not path or not os.path.exists(path):
        return b''
    try:
        with open(path, 'rb') as handle:
            return handle.read()
    except Exception:
        return b''


def execute_winscp_command(command, operation_type, files, local_storage_path, pre_download_snapshot=None, winscp_lock_path=None, progress_callback=None):
    """
    Execute the WinSCP command for the specified operation type.
    """
    MediLink_ConfigLoader.log("Executing WinSCP command for operation type: {}".format(operation_type), level="DEBUG")
    
    lock_token = _acquire_winscp_profile_lock(winscp_lock_path, operation_type)
    if lock_token is None:
        return []

    stdout_path = None
    stderr_path = None
    stdout = b''
    stderr = b''
    process = None
    outputs_to_files = False
    winscp_log_path = _winscp_log_path_from_command(command)
    started_at = time.time()
    heartbeat_interval_sec = 15
    try:
        stdout_handle = subprocess.PIPE
        stderr_handle = subprocess.PIPE
        try:
            fd_out, stdout_path = tempfile.mkstemp(prefix='winscp_stdout_', suffix='.tmp')
            try:
                fd_err, stderr_path = tempfile.mkstemp(prefix='winscp_stderr_', suffix='.tmp')
            except Exception:
                try:
                    os.close(fd_out)
                except Exception:
                    pass
                try:
                    if stdout_path and os.path.exists(stdout_path):
                        os.remove(stdout_path)
                except Exception:
                    pass
                stdout_path = None
                stderr_path = None
                raise
            stdout_handle = os.fdopen(fd_out, 'wb')
            stderr_handle = os.fdopen(fd_err, 'wb')
            outputs_to_files = True
        except Exception:
            stdout_path = None
            stderr_path = None
            stdout_handle = subprocess.PIPE
            stderr_handle = subprocess.PIPE
        try:
            process = subprocess.Popen(command, stdout=stdout_handle, stderr=stderr_handle, shell=False)
        finally:
            try:
                if stdout_handle is not subprocess.PIPE:
                    stdout_handle.close()
            except Exception:
                pass
            try:
                if stderr_handle is not subprocess.PIPE:
                    stderr_handle.close()
            except Exception:
                pass

        _emit_winscp_progress(progress_callback, 'started', operation_type, started_at, winscp_log_path, process=process)
        if outputs_to_files:
            last_heartbeat = started_at
            while process.poll() is None:
                time.sleep(1.0)
                now = time.time()
                if now - last_heartbeat >= heartbeat_interval_sec:
                    _emit_winscp_progress(progress_callback, 'heartbeat', operation_type, started_at, winscp_log_path, process=process)
                    last_heartbeat = now
            returncode = process.returncode
            stdout = _read_temp_stream(stdout_path)
            stderr = _read_temp_stream(stderr_path)
        else:
            # Child writes to PIPE streams: drain via communicate() while the process runs.
            # A poll-only loop without reads can deadlock once stdout/stderr buffers fill.
            stdout, stderr = process.communicate()
            returncode = process.returncode
        _emit_winscp_progress(progress_callback, 'finished', operation_type, started_at, winscp_log_path, process=process, returncode=returncode)
    except Exception as e:
        MediLink_ConfigLoader.log("Error occurred while executing WinSCP command: {}".format(e), level="ERROR")
        _emit_winscp_progress(progress_callback, 'failed_to_start', operation_type, started_at, winscp_log_path, process=process)
        return []  # Return an empty list instead of None
    finally:
        _release_winscp_profile_lock(lock_token)
        for temp_path in (stdout_path, stderr_path):
            try:
                if temp_path and os.path.exists(temp_path):
                    os.remove(temp_path)
            except Exception:
                pass

    if process.returncode == 0:
        MediLink_ConfigLoader.log("WinSCP {} operation completed successfully.".format(operation_type))

        if operation_type == 'download':
            remittance_extensions = _get_remittance_listing_extensions()
            # Prefer configured override if present
            winscp_download_path = None
            try:
                from MediCafe.core_utils import extract_medilink_config
                config, _ = MediLink_ConfigLoader.load_configuration()
                medi = extract_medilink_config(config)
                winscp_download_path = medi.get('winscp_download_path')
            except Exception:
                winscp_download_path = None

            target_dir = winscp_download_path or local_storage_path
            downloaded_files = list_downloaded_files(
                target_dir,
                allowed_extensions=remittance_extensions
            )
            downloaded_files = _filter_new_downloads(target_dir, downloaded_files, pre_download_snapshot)
            MediLink_ConfigLoader.log("Files currently located in target directory ({}): {}".format(target_dir, downloaded_files), level="DEBUG")

            if not downloaded_files and winscp_download_path and winscp_download_path != local_storage_path:
                # Fallback to original path if override empty
                fallback_files = list_downloaded_files(
                    local_storage_path,
                    allowed_extensions=remittance_extensions
                )
                fallback_files = _filter_new_downloads(local_storage_path, fallback_files, pre_download_snapshot)
                MediLink_ConfigLoader.log("Fallback to local_storage_path yielded: {}".format(fallback_files), level="DEBUG")
                downloaded_files = fallback_files

            if not downloaded_files:
                MediLink_ConfigLoader.log(
                    "WinSCP {} operation completed successfully, but no new files were found in the target directory.".format(operation_type),
                    level="INFO"
                )
            return downloaded_files

        elif operation_type == 'upload':
            uploaded_files = [os.path.normpath(file) for file in files if os.path.exists(file)]
            MediLink_ConfigLoader.log("Uploaded files: {}".format(uploaded_files), level="DEBUG")
            return uploaded_files
    else:
        # FIX: Check downloaded files FIRST before logging error to distinguish actual errors from expected "no files"
        error_message = stderr.decode('utf-8').strip() if stderr else ''
        error_message_lower = error_message.lower()
        
        # For download operations, check if files were actually downloaded despite exit code
        downloaded_files = []
        if operation_type == 'download':
            try:
                remittance_extensions = _get_remittance_listing_extensions()
                # Prefer configured override if present
                winscp_download_path = None
                try:
                    from MediCafe.core_utils import extract_medilink_config
                    config, _ = MediLink_ConfigLoader.load_configuration()
                    medi = extract_medilink_config(config)
                    winscp_download_path = medi.get('winscp_download_path')
                except Exception:
                    winscp_download_path = None
                
                target_dir = winscp_download_path or local_storage_path
                downloaded_files = list_downloaded_files(
                    target_dir,
                    allowed_extensions=remittance_extensions
                )
                downloaded_files = _filter_new_downloads(target_dir, downloaded_files, pre_download_snapshot)

                if not downloaded_files and winscp_download_path and winscp_download_path != local_storage_path:
                    # Fallback to original path if override empty
                    downloaded_files = list_downloaded_files(
                        local_storage_path,
                        allowed_extensions=remittance_extensions
                    )
                    downloaded_files = _filter_new_downloads(local_storage_path, downloaded_files, pre_download_snapshot)
            except Exception:
                pass  # If file listing fails, proceed with error classification
        
        # Classify error type based on downloaded files and error message
        if downloaded_files:
            # Files were downloaded despite exit code 1 - partial success
            MediLink_ConfigLoader.log("WinSCP {} operation completed with warnings. Exit code: {}. {} file(s) downloaded. Details: {}".format(
                operation_type, process.returncode, len(downloaded_files), error_message), level="WARNING")
            return downloaded_files
        elif not error_message or not any(keyword in error_message_lower for keyword in ['connection', 'timeout', 'authentication', 'auth', 'login', 'network', 'unreachable', 'refused']):
            # Exit code 1 but no connection/auth errors - likely "no files found" (expected)
            MediLink_ConfigLoader.log("WinSCP {} operation: No files found (exit code: {}). This is expected when remote directory is empty.".format(
                operation_type, process.returncode), level="WARNING")
            return []
        else:
            # Actual error: connection, auth, or network issue
            MediLink_ConfigLoader.log("Failed to {} files. Exit code: {}. Details: {}".format(
                operation_type, process.returncode, error_message), level="ERROR")
            return []  # Return an empty list instead of None

def _get_remittance_listing_extensions():
    """Return the extensions that represent actionable remittance downloads."""
    try:
        from MediLink_RemittancePipeline import get_move_extensions
        move_exts = get_move_extensions() if get_move_extensions else None
    except ImportError:
        move_exts = None
    if not move_exts:
        move_exts = [
            '.era', '.277', '.277ibr', '.277ebr', '.277dpr',
            '.999', '.dpt', '.ebt', '.ibt', '.txt'
        ]
    normalized = set()
    move_ext_list = list(move_exts or [])
    index = 0
    while index < len(move_ext_list):
        ext = move_ext_list[index]
        if ext:
            normalized.add(str(ext).lower())
        index += 1
    return normalized


def _lower_file_extension(path_value):
    dot_index = str(path_value or '').rfind('.')
    if dot_index < 0:
        return ''
    return str(path_value)[dot_index:].lower()


def _decode_bytes(value):
    if value is None:
        return ''
    if isinstance(value, bytes):
        try:
            return value.decode('utf-8')
        except Exception:
            try:
                return value.decode('latin-1')
            except Exception:
                return value.decode('utf-8', 'ignore')
    return str(value)


def list_downloaded_files(local_storage_path, allowed_extensions=None):

    MediLink_ConfigLoader.log("Listing downloaded files in local storage path: {}".format(local_storage_path), level="DEBUG")

    # Return paths RELATIVE to local_storage_path so downstream move logic can
    # resolve nested files deterministically (join(local_storage_path, relpath)).
    downloaded_files = []
    ignored_dirs = {'responses', '__pycache__'}
    normalized_extensions = None
    if allowed_extensions:
        normalized_extensions = set(ext.lower() for ext in allowed_extensions if ext)

    try:
        if not os.path.isdir(local_storage_path):
            MediLink_ConfigLoader.log(
                "Local storage path does not exist or is not a directory: {}".format(local_storage_path),
                level="WARNING"
            )
            return []

        for root, dirs, files in os.walk(local_storage_path):
            # Prevent re-processing already moved files and common noise folders.
            dirs[:] = [d for d in dirs if d.lower() not in ignored_dirs]
            for file in files:
                if normalized_extensions and _lower_file_extension(file) not in normalized_extensions:
                    continue
                file_path = os.path.join(root, file)
                relative_path = os.path.relpath(file_path, local_storage_path)
                downloaded_files.append(relative_path)
                MediLink_ConfigLoader.log("Downloaded file candidate found: {}".format(file_path), level="DEBUG")

        if not downloaded_files:
            MediLink_ConfigLoader.log("No files found in the directory: {}".format(local_storage_path), level="DEBUG")

    except Exception as e:
        MediLink_ConfigLoader.log("Error occurred while listing files in {}: {}".format(local_storage_path, e), level="ERROR")

    return downloaded_files


def probe_winscp_endpoint(endpoint_config, local_storage_path, config):
    """
    Perform a live WinSCP connectivity probe that opens the configured session
    and verifies the remote download directory is accessible.
    """
    try:
        config = ensure_config_loaded(config)
        winscp_path = get_winscp_path(config)
        if not os.path.isfile(winscp_path):
            return {
                'ok': False,
                'detail': "WinSCP.com not found at {}".format(winscp_path),
                'log_path': None,
                'returncode': None,
            }

        validate_endpoint_config(endpoint_config)
        local_storage_path = validate_local_storage_path(local_storage_path, config)
        remote_directory = get_remote_directory(endpoint_config, 'download')
        winscp_log_path = os.path.join(local_storage_path, 'winscp_probe.log')
        session_name = endpoint_config.get('session_name', '')
        command = [
            winscp_path,
            '/log=' + winscp_log_path,
            '/loglevel=1',
            '/command',
            'open {}'.format(session_name),
            'cd /',
            'cd {}'.format(remote_directory),
            'pwd',
            'ls',
            'close',
            'exit'
        ]
        # Same portable WinSCP.ini as operate_winscp; probe must take the profile lock
        # so a menu connectivity test cannot race a concurrent upload/download subprocess.
        lock_path = _winscp_profile_lock_path(winscp_path)
        lock_token = _acquire_winscp_profile_lock(lock_path, 'probe')
        if lock_token is None:
            return {
                'ok': False,
                'detail': "Timed out waiting for WinSCP profile lock before connectivity probe.",
                'log_path': winscp_log_path,
                'returncode': None,
            }
        try:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False)
            communicate_result = process.communicate()
            stdout = communicate_result[0] if len(communicate_result) > 0 else None
            stderr = communicate_result[1] if len(communicate_result) > 1 else None
            stdout_text = _decode_bytes(stdout).strip() if stdout else ''
            stderr_text = _decode_bytes(stderr).strip() if stderr else ''
            if process.returncode == 0:
                return {
                    'ok': True,
                    'detail': "Connected to session '{}' and accessed '{}'.".format(session_name, remote_directory),
                    'log_path': winscp_log_path,
                    'returncode': process.returncode,
                    'stdout': stdout_text,
                    'stderr': stderr_text,
                }

            detail = stderr_text or stdout_text or "WinSCP probe failed with exit code {}".format(process.returncode)
            return {
                'ok': False,
                'detail': detail,
                'log_path': winscp_log_path,
                'returncode': process.returncode,
                'stdout': stdout_text,
                'stderr': stderr_text,
            }
        finally:
            _release_winscp_profile_lock(lock_token)
    except Exception as e:
        return {
            'ok': False,
            'detail': "WinSCP probe raised {}: {}".format(e.__class__.__name__, e),
            'log_path': None,
            'returncode': None,
        }


def detect_new_files(directory_path, file_extension='.DAT', run_id=None):
    """
    Scans the specified directory for new files with a given extension and adds a timestamp if needed.
    Optimized version that uses single-pass iteration and pre-compiled regex.

    :param directory_path: Path to the directory containing files to be detected.
    :param file_extension: Extension of the files to detect.
    :param run_id: Optional run_id for structured timing (when provided and timing enabled).
    :return: Tuple ``(detected_paths, file_flagged, new_or_renamed_paths)`` where ``new_or_renamed_paths``
        lists paths that were just timestamp-renamed in this run (hot export anchors for current-export scope).
    """
    import time
    detect_start = time.time()
    if PERFORMANCE_LOGGING:
        try:
            from MediCafe.performance_events import log_performance_event
            log_performance_event('medilink_data', 'file_detection_start', details={'directory': directory_path})
        except Exception:
            MediLink_ConfigLoader.log("File detection started for directory: {}".format(directory_path), level="INFO", console_output=False)

    MediLink_ConfigLoader.log("Scanning directory: {}".format(directory_path), level="INFO")
    detected_file_paths = []
    file_flagged = False
    new_or_renamed_paths = []

    _listdir_ctx = stage_timer(run_id, 'medilink', 'directory_listing') if (run_id and stage_timer) else noop_timer
    try:
        with _listdir_ctx:
            filenames = os.listdir(directory_path)
        if PERFORMANCE_LOGGING:
            listdir_end = time.time()
            try:
                from MediCafe.performance_events import log_performance_event
                log_performance_event('medilink_data', 'directory_listing', elapsed_sec=listdir_end - detect_start)
            except Exception:
                pass

        # Single-pass optimization: filter, count, and process in one iteration
        matching_files = []
        timestamp_suffix = None  # Lazy evaluation: only create timestamp string if needed
        file_check_start = time.time()

        _filecheck_ctx = stage_timer(run_id, 'medilink', 'file_checking') if (run_id and stage_timer) else noop_timer
        with _filecheck_ctx:
            for filename in filenames:
                if not filename.endswith(file_extension):
                    continue
                matching_files.append(filename)  # For logging
                name, ext = os.path.splitext(filename)
                if not _TIMESTAMP_PATTERN.match(name):
                    if timestamp_suffix is None:
                        timestamp_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
                    new_name = "{}_{}{}".format(name, timestamp_suffix, ext)
                    old_path = os.path.join(directory_path, filename)
                    new_path = os.path.join(directory_path, new_name)
                    os.rename(old_path, new_path)
                    MediLink_ConfigLoader.log("Renamed file from {} to {}".format(filename, new_name), level="INFO")
                    file_flagged = True
                    new_or_renamed_paths.append(new_path)
                    filename = new_name  # Update filename for path construction
                file_path = os.path.join(directory_path, filename)
                detected_file_paths.append(file_path)

        if matching_files:
            MediLink_ConfigLoader.log("Found {} files with extension {}".format(
                len(matching_files), file_extension), level="INFO")

        file_check_end = time.time()
        if PERFORMANCE_LOGGING:
            try:
                from MediCafe.performance_events import log_performance_event
                log_performance_event('medilink_data', 'file_checking', elapsed_sec=file_check_end - file_check_start)
            except Exception:
                pass
    
    except Exception as e:
        MediLink_ConfigLoader.log("Error occurred: {}".format(str(e)), level="INFO")
    
    detect_end = time.time()
    if run_id and record_stage:
        record_stage(run_id, 'medilink', 'detection_total', int((detect_end - detect_start) * 1000))
    if PERFORMANCE_LOGGING:
        try:
            from MediCafe.performance_events import log_performance_event
            log_performance_event(
                'medilink_data',
                'file_detection_total',
                elapsed_sec=detect_end - detect_start,
                details={'detected_files': len(detected_file_paths), 'flagged': file_flagged},
            )
        except Exception:
            pass
    MediLink_ConfigLoader.log("Detected {} files, flagged: {}".format(len(detected_file_paths), file_flagged), level="DEBUG")

    return detected_file_paths, file_flagged, new_or_renamed_paths

def is_timestamped(name):
    """
    Checks if the given filename has a timestamp in the expected format.
    Uses pre-compiled regex pattern for better performance.
    
    :param name: The name of the file without extension.
    :return: True if the filename includes a timestamp, False otherwise.
    """
    return bool(_TIMESTAMP_PATTERN.match(name))

def organize_patient_data_by_endpoint(detailed_patient_data):
    """
    Organizes detailed patient data by their confirmed endpoints.
    This simplifies processing and conversion per endpoint basis, ensuring that claims are generated and submitted
    according to the endpoint-specific requirements.

    :param detailed_patient_data: A list of dictionaries, each containing detailed patient data including confirmed endpoint.
    :return: A dictionary with endpoints as keys and lists of detailed patient data as values for processing.
    """
    organized = {}
    for data in detailed_patient_data:
        # Retrieve endpoint in priority order: confirmed -> user_preferred -> suggested
        endpoint = (data.get('confirmed_endpoint') or 
                   data.get('user_preferred_endpoint') or 
                   data.get('suggested_endpoint', 'AVAILITY'))
        # Initialize a list for the endpoint if it doesn't exist
        if endpoint not in organized:
            organized[endpoint] = []
        organized[endpoint].append(data)
    return organized

def confirm_all_suggested_endpoints(detailed_patient_data):
    """
    Confirms all suggested endpoints for each patient's detailed data.
    """
    for data in detailed_patient_data:
        if 'confirmed_endpoint' not in data:
            data['confirmed_endpoint'] = data['suggested_endpoint']
    return detailed_patient_data

# Bulk edit + crosswalk NOTE:
# - These functions currently blend CLI prompts, validation, and persistence. They work for
#   interactive MediLink runs but block automation and make unit testing hard.
# - Implementation plan: extract a non-interactive service layer (e.g., validate_and_mutate_insurance,
#   apply_endpoint_override) that receives dependencies (validators, crosswalk saver) via parameters.
#   Keep thin CLI wrappers here that just format prompts.
# - Value: enables UI reuse, background automation, and makes `SKIP_API_SOURCED_INSURANCE_EDIT`
#   configurable instead of hard-coded. Also clarifies when crosswalk writes happen.
# - Risk / latent complexity: High-touch UX path. Need to preserve existing prompt order, handle
#   allow_unknown flows, and ensure crosswalk save failures do not corrupt in-memory state.
#   Coordinate with MediLink UI and MediBot teams before changing behavior; add tests that simulate
#   API-sourced + manual codes plus crosswalk updates.
def bulk_edit_insurance_types(detailed_patient_data, insurance_options):
    """Allow user to edit insurance types in a table-like format with validation"""
    print("\nEdit Insurance Type (Enter the code). Enter 'LIST' to display available insurance types.")

    for data in detailed_patient_data:
        patient_id = data.get('patient_id', 'Unknown')
        patient_name = data.get('patient_name', 'Unknown')
        current_insurance_type = data.get('insurance_type', '12')
        source = data.get('insurance_type_source', '')
        src_disp = 'API' if source == 'API' else ('MAN' if source == 'MANUAL' else 'DEF')
        
        # Validate current insurance type to determine status indicator
        validation_status = "[VALID]"
        show_warning = False
        
        # Use centralized validation if available
        if validate_insurance_type_from_config:
            try:
                validated_code, is_valid = validate_insurance_type_from_config(
                    current_insurance_type,
                    payer_id=patient_id,
                    source=source,
                    strict_mode=True,
                    allow_unknown=False
                )
                if is_valid:
                    validation_status = "[VALID]"
                else:
                    # Determine if format is valid or invalid
                    # Check format of original code to distinguish invalid format vs. not in config
                    format_valid = current_insurance_type and len(current_insurance_type) <= 3 and current_insurance_type.isalnum()
                    if not format_valid:
                        # Format was invalid
                        validation_status = "[INVALID]"
                    else:
                        # Format valid but not in config
                        validation_status = "[NOT IN CONFIG]"
                        if source == 'API':
                            show_warning = True
            except Exception as e:
                MediLink_ConfigLoader.log("Error validating insurance type in bulk edit display: {}".format(str(e)), level="WARNING")
                # Fallback to simple check
                if current_insurance_type in insurance_options:
                    validation_status = "[VALID]"
                elif current_insurance_type and len(current_insurance_type) <= 3 and current_insurance_type.isalnum():
                    validation_status = "[NOT IN CONFIG]"
                    if source == 'API':
                        show_warning = True
                else:
                    validation_status = "[INVALID]"
        else:
            # Fallback validation if function not available
            if current_insurance_type in insurance_options:
                validation_status = "[VALID]"
            elif current_insurance_type and len(current_insurance_type) <= 3 and current_insurance_type.isalnum():
                validation_status = "[NOT IN CONFIG]"
                if source == 'API':
                    show_warning = True
            else:
                validation_status = "[INVALID]"
        
        current_insurance_description = insurance_options.get(current_insurance_type, "Unknown")
        
        # Display with validation status
        print("({}) {:<25} | Src:{} | Current Ins. Type: {} {} - {}".format(
            patient_id, patient_name, src_disp, current_insurance_type, validation_status, current_insurance_description))
        
        # Show warning for API-sourced codes not in config
        if show_warning:
            print("  WARNING: API code '{}' not found in insurance_options. Please verify or edit.".format(current_insurance_type))

        # Determine if we should skip this patient
        # Always show API-sourced codes that are not in config, regardless of flag
        should_skip = False
        if source == 'API' and SKIP_API_SOURCED_INSURANCE_EDIT:
            # Only skip if code is valid in config
            if validation_status == "[VALID]":
                print("  -> Skipped (API-sourced, valid in config)")
                MediLink_ConfigLoader.log("Skipped editing insurance type for API-sourced patient: patient_id='{}'".format(patient_id), level="DEBUG")
                should_skip = True
            # Otherwise, always show for editing

        if should_skip:
            continue

        while True:
            new_insurance_type = input("Enter new insurance type (or press Enter to keep current): ").strip().upper()
            
            if new_insurance_type == 'LIST':
                MediLink_Display_Utils.display_insurance_options(insurance_options)
                continue
                
            elif not new_insurance_type:
                # Keep current insurance type
                break
            
            # Use centralized validation function
            if validate_insurance_type_from_config:
                try:
                    validated_code, is_valid = validate_insurance_type_from_config(
                        new_insurance_type,
                        payer_id=patient_id,
                        source='MANUAL',
                        strict_mode=True,
                        allow_unknown=False
                    )
                    
                    if is_valid:
                        # Valid code in config
                        data['insurance_type'] = validated_code
                        data['insurance_type_source'] = 'MANUAL'
                        print("Updated to: {} - {}".format(validated_code, insurance_options.get(validated_code, "Unknown")))
                        break
                    elif validated_code == '12':
                        # Either format invalid or not in config - check format manually
                        if new_insurance_type and len(new_insurance_type) <= 3 and new_insurance_type.isalnum():
                            # Format is valid but not in config - ask user
                            confirm = input("Code '{}' not found in configuration. Use it anyway? (y/n): ".format(new_insurance_type)).strip().lower()
                            if confirm in ['y', 'yes']:
                                validated_code, _ = validate_insurance_type_from_config(
                                    new_insurance_type,
                                    payer_id=patient_id,
                                    source='MANUAL',
                                    strict_mode=True,
                                    allow_unknown=True
                                )
                                data['insurance_type'] = validated_code
                                data['insurance_type_source'] = 'MANUAL'
                                print("Updated to: {} (not in config, but format valid)".format(validated_code))
                                break
                            else:
                                print("Please enter a valid code or type 'LIST' to see options.")
                                continue
                        else:
                            # Format invalid, fallback to PPO
                            print("Invalid format. Using default PPO (12).")
                            data['insurance_type'] = '12'
                            data['insurance_type_source'] = 'MANUAL'
                            break
                    else:
                        # validated_code is not '12' and not in config - format valid but not in config
                        # This case should not happen with allow_unknown=False, but handle it anyway
                        confirm = input("Code '{}' not found in configuration. Use it anyway? (y/n): ".format(new_insurance_type)).strip().lower()
                        if confirm in ['y', 'yes']:
                            # Re-validate with allow_unknown=True
                            validated_code, _ = validate_insurance_type_from_config(
                                new_insurance_type,
                                payer_id=patient_id,
                                source='MANUAL',
                                strict_mode=True,
                                allow_unknown=True
                            )
                            data['insurance_type'] = validated_code
                            data['insurance_type_source'] = 'MANUAL'
                            print("Updated to: {} (not in config, but format valid)".format(validated_code))
                            break
                        else:
                            print("Please enter a valid code or type 'LIST' to see options.")
                            continue
                except Exception as e:
                    MediLink_ConfigLoader.log("Error validating insurance type in bulk edit: {}".format(str(e)), level="WARNING")
                    # Fall through to legacy validation
                    if new_insurance_type in insurance_options:
                        data['insurance_type'] = new_insurance_type
                        data['insurance_type_source'] = 'MANUAL'
                        break
                    else:
                        confirm = input("Code '{}' not found in configuration. Use it anyway? (y/n): ".format(new_insurance_type)).strip().lower()
                        if confirm in ['y', 'yes']:
                            data['insurance_type'] = new_insurance_type
                            data['insurance_type_source'] = 'MANUAL'
                            break
                        else:
                            print("Invalid insurance type. Please enter a valid code or type 'LIST' to see options.")
                            continue
            else:
                # Fallback to legacy validation if function not available
                if new_insurance_type in insurance_options:
                    data['insurance_type'] = new_insurance_type
                    data['insurance_type_source'] = 'MANUAL'
                    break
                else:
                    confirm = input("Code '{}' not found in configuration. Use it anyway? (y/n): ".format(new_insurance_type)).strip().lower()
                    if confirm in ['y', 'yes']:
                        data['insurance_type'] = new_insurance_type
                        data['insurance_type_source'] = 'MANUAL'
                        break
                    else:
                        print("Invalid insurance type. Please enter a valid code or type 'LIST' to see options.")
                        continue


def review_and_confirm_changes(detailed_patient_data, insurance_options):
    # Review and confirm changes
    print("\nReview changes:")
    print("{:<20} {:<10} {:<30}".format("Patient Name", "Ins. Type", "Description"))
    print("="*65)
    for data in detailed_patient_data:
        # Fix: Add null checks to prevent AttributeError
        if data is None:
            continue
            
        insurance_type = data.get('insurance_type', 'Unknown')
        insurance_description = insurance_options.get(insurance_type, "Unknown")
        patient_name = data.get('patient_name', 'Unknown')
        print("{:<20} {:<10} {:<30}".format(patient_name, insurance_type, insurance_description))
    confirm = input("\nConfirm changes? (y/n): ").strip().lower()
    return confirm in ['y', 'yes', '']


def update_suggested_endpoint_with_user_preference(detailed_patient_data, patient_index, new_endpoint, config, crosswalk):
    """
    Updates the suggested endpoint for a patient and optionally updates the crosswalk 
    for future patients with the same insurance.
    
    :param detailed_patient_data: List of patient data dictionaries
    :param patient_index: Index of the patient being updated
    :param new_endpoint: The new endpoint selected by the user
    :param config: Configuration settings
    :param crosswalk: Crosswalk data for in-memory updates
    :return: Updated crosswalk if changes were made, None otherwise
    """
    # Note: load_insurance_data_from_mains is now imported at module level
    
    data = detailed_patient_data[patient_index]
    original_suggested = data.get('suggested_endpoint')
    
    # Update the patient's endpoint preference
    data['user_preferred_endpoint'] = new_endpoint
    data['confirmed_endpoint'] = new_endpoint
    
    # If user changed from the original suggestion, offer to update crosswalk
    if original_suggested != new_endpoint:
        primary_insurance = data.get('primary_insurance')
        primary_payer_id = str(data.get('primary_payer_id') or '').strip()
        patient_name = data.get('patient_name')
        
        print("\nYou changed the endpoint for {} from {} to {}.".format(patient_name, original_suggested, new_endpoint))
        update_future = input("Would you like to use {} as the default endpoint for future patients with {}? (Y/N): ".format(new_endpoint, primary_insurance)).strip().lower()
        
        if update_future in ['y', 'yes']:
            target_payer_id = primary_payer_id

            if not target_payer_id:
                # Backward-compatible fallback for older in-memory rows that do not yet
                # carry primary_payer_id.
                load_insurance_data_from_mains = _get_medibot_function('MediBot_Preprocessor_lib', 'load_insurance_data_from_mains')
                insurance_to_id = load_insurance_data_from_mains(config) if load_insurance_data_from_mains else {}
                insurance_id = insurance_to_id.get(primary_insurance)
                if insurance_id:
                    for payer_id, payer_data in crosswalk.get('payer_id', {}).items():
                        medisoft_ids = [str(id) for id in payer_data.get('medisoft_id', [])]
                        if str(insurance_id) in medisoft_ids:
                            target_payer_id = str(payer_id)
                            break

            if target_payer_id:
                routing_overrides = crosswalk.setdefault('routing_overrides', {})
                payer_overrides = routing_overrides.setdefault('payers', {})
                operation_overrides = payer_overrides.setdefault(str(target_payer_id), {})
                operation_overrides['claim_submission'] = {
                    'preferred_endpoint': new_endpoint,
                    'source': 'user',
                    'updated_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                }
                MediLink_ConfigLoader.log(
                    "Updated claim-submission routing override in memory: payer ID {} ({}) now prefers {}".format(
                        target_payer_id,
                        primary_insurance,
                        new_endpoint
                    ),
                    level="INFO"
                )

                # Update suggested_endpoint for other patients with the same payer in the current batch.
                for other_data in detailed_patient_data:
                    other_payer_id = str(other_data.get('primary_payer_id') or '').strip()
                    same_payer = other_payer_id and other_payer_id == str(target_payer_id)
                    same_insurance = (not other_payer_id and other_data.get('primary_insurance') == primary_insurance)
                    if (same_payer or same_insurance) and 'user_preferred_endpoint' not in other_data:
                        other_data['suggested_endpoint'] = new_endpoint

                if save_crosswalk_immediately(config, crosswalk):
                    print("Updated default endpoint for {} to {}".format(primary_insurance, new_endpoint))
                else:
                    print("Updated endpoint preference (will be saved during next crosswalk update)")
                return crosswalk

            MediLink_ConfigLoader.log("Could not find payer ID in crosswalk for insurance {}".format(primary_insurance), level="WARNING")
    
    return None


def save_crosswalk_immediately(config, crosswalk):
    """
    Saves crosswalk routing overrides to the state sidecar immediately.
    
    :param config: Configuration settings
    :param crosswalk: Crosswalk data to save
    :return: True if saved successfully, False otherwise
    """
    try:
        from MediBot.MediBot_Crosswalk_Utils import save_crosswalk_state_document

        routing_payload = {
            'routing_overrides': crosswalk.get('routing_overrides', {})
        }
        success, _state_path = save_crosswalk_state_document(
            config,
            crosswalk,
            routing_payload,
            writer='save_crosswalk_route_overrides',
        )
        if success:
            MediLink_ConfigLoader.log("Successfully saved crosswalk routing overrides", level="INFO")
        else:
            MediLink_ConfigLoader.log("Failed to save crosswalk routing overrides - preferences will be saved during next crosswalk update", level="WARNING")
            
        return success
        
    except ImportError:
        MediLink_ConfigLoader.log("Could not import MediBot_Crosswalk_Utils for saving crosswalk routing overrides", level="ERROR")
        return False
    except Exception as e:
        MediLink_ConfigLoader.log("Error saving crosswalk routing overrides: {}".format(e), level="ERROR")
        return False
