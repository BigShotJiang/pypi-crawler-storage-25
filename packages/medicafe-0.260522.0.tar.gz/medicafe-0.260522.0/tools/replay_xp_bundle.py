#!/usr/bin/env python
"""Replay XP evidence bundles into local review reports.

This is a developer-side tool. It never mutates the original bundle, never
starts the shadow pipeline, never starts DAT smoke, and never sends support
bundles. It hydrates one or more XP bundles into scratch lab layouts, runs the
same evidence manifest and Layer 1 decision models used by operator packs, and
emits a Codex-ready handoff prompt with exact paths.
"""
from __future__ import print_function

import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import sqlite3
import sys
import tempfile
import zipfile

_REPLAY_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_REPLAY_REPO_ROOT = os.path.abspath(os.path.join(_REPLAY_SCRIPT_DIR, ".."))
if _REPLAY_REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPLAY_REPO_ROOT)

from MediCafe.phase_d_movement import classify_phase_d_selector_residue


BUNDLE_MARKERS = ("meta.json", "diagnostics_state.json", "run_cursor.json", "evidence_scope.json")
STATE_NAMES = ("diagnostics_state.json", "run_cursor.json", "phase_d_dat_smoke_state.json")
REPORT_EXTENSIONS = (".json", ".txt", ".jsonl", ".csv", ".md", ".log")
HYDRATED_PATH_LIMIT = 240
HYDRATED_BASENAME_LIMIT = 120
HYDRATED_LONG_NAME_DIR = "__hydrated_long_names"
HYDRATED_BUNDLE_LABEL_LIMIT = 64
REVIEW_ONLY_ANALYTICS_BUNDLE_KINDS = set([
    "x12_cpt_dx_analytics",
    "x12_minutes_charge_analytics",
])
REVIEW_ONLY_SERVICE_LINE_BUNDLE_KINDS = set([
    "service_line_input_preview",
    "service_line_charge_anchor_option_h_failure",
])
REVIEW_ONLY_OPERATOR_CONTEXT_BUNDLE_KINDS = set([
    "operator_shutdown_report",
])
REVIEW_ONLY_BUNDLE_KINDS = REVIEW_ONLY_ANALYTICS_BUNDLE_KINDS.union(
    REVIEW_ONLY_SERVICE_LINE_BUNDLE_KINDS
).union(
    REVIEW_ONLY_OPERATOR_CONTEXT_BUNDLE_KINDS
)
REVIEW_ONLY_SELF_TEST_BUNDLE_KINDS = set([
    "test",
    "self_test",
    "self_test_report",
    "self_test_support",
])
DAT_SOURCE_SHAPE_SUBCODE = "DAT_PATID_UNREACHABLE_SOURCE_SHAPE"
DAT_SOURCE_SHAPE_ACTION = "resolve_dat_terminal_source_shape_rejects"


def _repo_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


ROOT = _repo_root()
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from MediCafe.phase_d_movement import classify_dat_reject_next_action
from MediCafe.phase_d_movement import classify_phase_d_movement
from MediCafe.phase_d_movement import extract_phase_d_dat_counts
from MediCafe.phase_d_movement import format_count_map


def _safe_str(value):
    if value is None:
        return ""
    try:
        return str(value)
    except Exception:
        return ""


def _safe_int(value, default=0):
    try:
        if value is None or value == "":
            return default
        return int(value)
    except Exception:
        return default


def _utc_now():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _timestamp():
    return datetime.datetime.utcnow().strftime("%Y%m%d-%H%M%S")


def _mkdir(path):
    if path and not os.path.isdir(path):
        os.makedirs(_fs_path(path))


def _fs_path(path):
    if os.name != "nt":
        return path
    text = _safe_str(path)
    if not text or text.startswith("\\\\?\\"):
        return path
    abs_path = os.path.abspath(text)
    if len(abs_path) < HYDRATED_PATH_LIMIT:
        return path
    if abs_path.startswith("\\\\"):
        return "\\\\?\\UNC\\" + abs_path.lstrip("\\")
    return "\\\\?\\" + abs_path


def _read_json(path, default=None):
    if default is None:
        default = {}
    if not path or not os.path.isfile(_fs_path(path)):
        return default
    try:
        with open(_fs_path(path), "r") as handle:
            data = json.load(handle)
        return data
    except Exception:
        return default


def _read_text(path):
    if not path or not os.path.isfile(_fs_path(path)):
        return ""
    try:
        with open(_fs_path(path), "r") as handle:
            return handle.read()
    except Exception:
        return ""


def _write_json(path, payload):
    with open(_fs_path(path), "w") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def _write_text(path, text):
    with open(_fs_path(path), "w") as handle:
        handle.write(text)


def _copy2(src, dst):
    parent = os.path.dirname(dst)
    if parent and not os.path.isdir(parent):
        os.makedirs(_fs_path(parent))
    shutil.copy2(_fs_path(src), _fs_path(dst))


def _looks_like_bundle_dir(path):
    if not os.path.isdir(path):
        return False
    for marker in BUNDLE_MARKERS:
        if os.path.isfile(os.path.join(path, marker)):
            return True
    try:
        for name in os.listdir(path):
            if name.startswith("shadow_run_report_") or name.startswith("qa_canonical_summary_"):
                return True
    except Exception:
        return False
    return False


def _find_bundle_dirs(parent):
    rows = []
    if not os.path.isdir(parent):
        return rows
    if _looks_like_bundle_dir(parent):
        return [os.path.abspath(parent)]
    try:
        names = sorted(os.listdir(parent))
    except Exception:
        return rows
    preferred = []
    fallback = []
    for name in names:
        path = os.path.join(parent, name)
        if not os.path.isdir(path) or not _looks_like_bundle_dir(path):
            continue
        if name.startswith("medicafe_bundle_"):
            preferred.append(os.path.abspath(path))
        else:
            fallback.append(os.path.abspath(path))
    return preferred or fallback


def _single_child_dir(path):
    try:
        names = [n for n in os.listdir(path) if os.path.isdir(os.path.join(path, n))]
    except Exception:
        return ""
    if len(names) == 1:
        return os.path.join(path, names[0])
    return ""


def discover_bundle_sources(input_path, scratch_root):
    path = os.path.abspath(input_path)
    if os.path.isfile(path) and path.lower().endswith(".zip"):
        extract_root = os.path.join(scratch_root, "zip_extract")
        _mkdir(extract_root)
        with zipfile.ZipFile(path, "r") as zf:
            zf.extractall(extract_root)
        child = _single_child_dir(extract_root)
        candidates = _find_bundle_dirs(child or extract_root)
        if candidates:
            return candidates
        return [extract_root] if _looks_like_bundle_dir(extract_root) else []
    if os.path.isdir(path):
        return _find_bundle_dirs(path)
    return []


def _sanitize_name(name):
    text = _safe_str(name).strip() or "bundle"
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", text)


def _iter_files(root):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in (".git", "__pycache__")]
        for name in filenames:
            yield os.path.join(dirpath, name)


def _bundle_relative_name(bundle_dir, path):
    try:
        rel = os.path.relpath(path, bundle_dir)
    except Exception:
        rel = os.path.basename(path)
    if rel.startswith(".."):
        rel = os.path.basename(path)
    return rel


def _hash_text(text, size=12):
    return hashlib.sha256(_safe_str(text).encode("utf-8")).hexdigest()[:size]


def _short_hydrated_basename(rel):
    base = _sanitize_name(os.path.basename(rel))
    stem, ext = os.path.splitext(base)
    digest = _hash_text(rel)
    budget = HYDRATED_BASENAME_LIMIT - len(ext) - len(digest) - 2
    if budget < 16:
        budget = 16
    if not stem:
        stem = "bundle_file"
    return "{0}__{1}{2}".format(stem[:budget], digest, ext)


def _short_hydrated_label(name):
    label = _sanitize_name(name)
    if len(label) <= HYDRATED_BUNDLE_LABEL_LIMIT:
        return label
    digest = _hash_text(label)
    budget = HYDRATED_BUNDLE_LABEL_LIMIT - len(digest) - 2
    if budget < 16:
        budget = 16
    return "{0}__{1}".format(label[:budget], digest)


def _shorten_hydrated_target(dst, rel, reports_dir):
    abs_dst = os.path.abspath(dst)
    base = os.path.basename(dst)
    if len(abs_dst) < HYDRATED_PATH_LIMIT and len(base) <= HYDRATED_BASENAME_LIMIT:
        return dst
    return os.path.join(reports_dir, HYDRATED_LONG_NAME_DIR, _short_hydrated_basename(rel))


def _target_for_bundle_file(bundle_dir, src, lab_dir, reports_dir):
    rel = _bundle_relative_name(bundle_dir, src)
    base = os.path.basename(src)
    if rel == base and base in STATE_NAMES:
        return os.path.join(lab_dir, base)
    if rel.startswith("reports" + os.sep) or rel.startswith("lab" + os.sep + "reports" + os.sep):
        parts = rel.split(os.sep)
        rel = os.path.join(*parts[1:]) if parts[0] == "reports" else os.path.join(*parts[2:])
    return _shorten_hydrated_target(os.path.join(reports_dir, rel), rel, reports_dir)


def _build_basename_map(lab_dir, reports_dir, copied_map=None):
    mapping = {}
    for root in (lab_dir, reports_dir):
        if not os.path.isdir(root):
            continue
        for path in _iter_files(root):
            base = os.path.basename(path)
            mapping[base] = os.path.abspath(path)
    if copied_map:
        for original, hydrated in copied_map.items():
            base = os.path.basename(original)
            if base:
                mapping[base] = os.path.abspath(hydrated)
    return mapping


def _candidate_basename(value):
    text = _safe_str(value).strip()
    if not text:
        return ""
    normalized = text.replace("\\", "/")
    if "/" not in normalized and ":" not in normalized:
        return ""
    return normalized.rstrip("/").split("/")[-1]


def _rebase_json_value(value, basename_map):
    if isinstance(value, dict):
        return dict((k, _rebase_json_value(v, basename_map)) for k, v in value.items())
    if isinstance(value, list):
        return [_rebase_json_value(v, basename_map) for v in value]
    if isinstance(value, tuple):
        return tuple(_rebase_json_value(v, basename_map) for v in value)
    if isinstance(value, str):
        base = _candidate_basename(value)
        if base and base in basename_map:
            return basename_map[base]
    return value


def hydrate_bundle(bundle_dir, lab_dir):
    reports_dir = os.path.join(lab_dir, "reports")
    _mkdir(reports_dir)
    copied = []
    copied_map = {}
    mapping_rows = []
    for src in _iter_files(bundle_dir):
        name = os.path.basename(src)
        ext = os.path.splitext(name)[1].lower()
        if name in STATE_NAMES or ext in REPORT_EXTENSIONS or name == "meta.json" or name == "evidence_scope.json":
            rel = _bundle_relative_name(bundle_dir, src)
            dst = _target_for_bundle_file(bundle_dir, src, lab_dir, reports_dir)
            _copy2(src, dst)
            copied.append(dst)
            copied_map[rel] = dst
            mapping_rows.append({
                "original_bundle_path": rel,
                "hydrated_lab_path": os.path.abspath(dst),
                "hydrated_name_changed": os.path.basename(src) != os.path.basename(dst),
            })
            if name in ("diagnostics_state.json", "run_cursor.json") and os.path.dirname(dst) != lab_dir:
                _copy2(src, os.path.join(lab_dir, name))
                copied.append(os.path.join(lab_dir, name))
            if name == "phase_d_dat_smoke_state.json" and os.path.dirname(dst) != reports_dir:
                _copy2(src, os.path.join(reports_dir, name))
                copied.append(os.path.join(reports_dir, name))
    basename_map = _build_basename_map(lab_dir, reports_dir, copied_map)
    for path in list(copied):
        if not path.lower().endswith(".json") or not os.path.isfile(path):
            continue
        payload = _read_json(path, default=None)
        if payload is None:
            continue
        rebased = _rebase_json_value(payload, basename_map)
        if rebased != payload:
            _write_json(path, rebased)
    return reports_dir, mapping_rows


def _find_first(prefix, suffix, directory):
    if not directory or not os.path.isdir(directory):
        return ""
    try:
        names = sorted(os.listdir(directory))
    except Exception:
        return ""
    for name in names:
        if name.startswith(prefix) and name.endswith(suffix):
            return os.path.join(directory, name)
    return ""


def _find_by_run(prefix, run_id, suffix, directory):
    if run_id:
        path = os.path.join(directory, "{0}{1}{2}".format(prefix, run_id, suffix))
        if os.path.isfile(path):
            return path
    return _find_first(prefix, suffix, directory)


def _phase_run_ids_from_files(reports_dir):
    out = {}
    if not os.path.isdir(reports_dir):
        return out
    try:
        names = os.listdir(reports_dir)
    except Exception:
        return out
    patterns = (
        ("B", "artifact_discovery_summary_", ".json"),
        ("C", "ingest_write_summary_", ".json"),
        ("D", "qa_canonical_summary_", ".json"),
        ("E", "projection_parity_summary_", ".json"),
    )
    for phase, prefix, suffix in patterns:
        for name in sorted(names):
            if name.startswith(prefix) and name.endswith(suffix):
                out[phase] = name[len(prefix):-len(suffix)]
                break
    return out


def _phase_map_from_any(*items):
    for item in items:
        if isinstance(item, dict):
            for key in ("phase_run_id_map", "phase_run_ids", "last_shadow_pipeline_phase_run_ids"):
                data = item.get(key)
                if isinstance(data, dict):
                    out = {}
                    for p, rid in data.items():
                        phase = _safe_str(p).strip().upper()
                        val = _safe_str(rid).strip()
                        if phase and val:
                            out[phase] = val
                    if out:
                        return out
    return {}


def _first_value(*values):
    for value in values:
        text = _safe_str(value).strip()
        if text:
            return text
    return ""


def _anchor_from_payloads(meta, evidence_scope, diagnostics, cursor, shadow):
    meta_scope = meta.get("evidence_scope") if isinstance(meta.get("evidence_scope"), dict) else {}
    return _first_value(
        evidence_scope.get("anchor_run_id"),
        evidence_scope.get("context_pack_anchor_run_id"),
        evidence_scope.get("recommendation_anchor_run_id"),
        evidence_scope.get("artifact_run_id"),
        meta_scope.get("anchor_run_id"),
        meta.get("anchor_run_id"),
        meta.get("recommendation_anchor_run_id"),
        diagnostics.get("last_shadow_pipeline_run_id"),
        cursor.get("last_shadow_pipeline_run_id"),
        shadow.get("run_id"),
        meta.get("run_id"),
    )


def _bundle_kind(meta, evidence_scope):
    return _first_value(meta.get("bundle_kind"), evidence_scope.get("bundle_kind"), "run_evidence_bundle")


def _is_review_only_analytics_bundle_kind(bundle_kind):
    return _safe_str(bundle_kind).strip() in REVIEW_ONLY_BUNDLE_KINDS.union(
        REVIEW_ONLY_SELF_TEST_BUNDLE_KINDS
    )


def _is_review_only_analytics_bundle_dir(bundle_dir):
    meta = _read_json(os.path.join(bundle_dir, "meta.json"), {})
    evidence_scope = _read_json(os.path.join(bundle_dir, "evidence_scope.json"), {})
    bundle_kind = _bundle_kind(meta, evidence_scope)
    if _is_review_only_analytics_bundle_kind(bundle_kind):
        return True
    base = os.path.basename(os.path.abspath(bundle_dir)).lower()
    if base.startswith("medicafe_bundle_test_") and (
            "self_test" in base or "service_line_charge" in base):
        return True
    if isinstance(meta, dict):
        if meta.get("self_test_report"):
            return True
        if _safe_str(meta.get("command")).strip() == "build_service_line_charge_anchor_index":
            return True
        if _safe_str(meta.get("dedup_channel")).strip() == "service_line_charge_anchor_option_h_failure":
            return True
    return False


def _recommendation_action(meta, evidence_scope, shadow, qa_summary):
    for data in (meta, evidence_scope, shadow, qa_summary):
        if not isinstance(data, dict):
            continue
        val = _first_value(
            data.get("recommended_action_kind"),
            data.get("recommendation_action_kind"),
            data.get("layer1_runbook_action_kind"),
        )
        if val:
            return val
    contract = qa_summary.get("phase_d_developer_unblock") if isinstance(qa_summary, dict) else {}
    if isinstance(contract, dict):
        return _safe_str(contract.get("recommended_action_kind")).strip()
    return "review_dat_qa_full_block"


def _dat_counts(qa_summary, shadow):
    return extract_phase_d_dat_counts(qa_summary, shadow)


def _parse_bool(value):
    return _safe_str(value).strip().lower() in ("1", "true", "yes", "y")


def _parse_key_value_note(path):
    out = {}
    for raw in _read_text(path).splitlines():
        line = raw.strip()
        while line.startswith("-") or line.startswith("*"):
            line = line[1:].strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key:
            out[key] = value.strip()
    return out


def _parse_phase_d_counts(text):
    out = {}
    for part in _safe_str(text).split(","):
        if ":" not in part:
            continue
        key, value = part.split(":", 1)
        key = key.strip()
        if key:
            out[key] = _safe_int(value, 0)
    return {
        "selected": _safe_int(out.get("selected"), 0),
        "qa_pass": _safe_int(out.get("qa_pass"), 0),
        "qa_reject": _safe_int(out.get("qa_reject"), 0),
        "canonical": _safe_int(out.get("canonical"), 0),
        "v2_inserted": _safe_int(out.get("v2_inserted"), 0),
    }


def _find_followup_note(reports_dir):
    return _find_first("run_evidence_phase_d_followup_note_", ".txt", reports_dir)


def _find_all(prefix, suffix, directory):
    if not directory or not os.path.isdir(directory):
        return []
    try:
        names = sorted(os.listdir(directory))
    except Exception:
        return []
    out = []
    for name in names:
        if name.startswith(prefix) and name.endswith(suffix):
            out.append(os.path.join(directory, name))
    return out


def _resolve_followup_path_from_note(path, reports_dir, prefix, run_id, suffix):
    path_s = _safe_str(path).strip()
    if path_s == "-":
        path_s = ""
    if path_s and os.path.isfile(path_s):
        return path_s
    base = os.path.basename(path_s)
    if base:
        candidate = os.path.join(reports_dir, base)
        if os.path.isfile(candidate):
            return candidate
    if run_id:
        return _find_by_run(prefix, run_id, suffix, reports_dir)
    return ""


def _count_source_shape_subcode_in_dict(data):
    if not isinstance(data, dict):
        return 0
    total = 0
    for key in (
            "dat_terminal_reject_subcode_counts",
            "dat_terminal_reject_counts_by_subcode",
            "dat_qa_reject_subcode_counts",
            "dat_qa_reject_counts_by_subcode",
            "dat_reject_subcode_counts",
            "terminal_dat_reject_counts_by_subcode",
            "reject_counts_by_subcode"):
        counts = data.get(key)
        if isinstance(counts, dict):
            total += _safe_int(counts.get(DAT_SOURCE_SHAPE_SUBCODE), 0)
    scalar_subcode_present = False
    for key in (
            "terminal_reject_subcode",
            "dominant_reject_subcode",
            "dominant_terminal_subcode",
            "dat_reject_subcode",
            "reject_subcode",
            "subcode"):
        if _safe_str(data.get(key)).strip() == DAT_SOURCE_SHAPE_SUBCODE:
            scalar_subcode_present = True
    if scalar_subcode_present:
        count = _safe_int(data.get("count"), 0)
        total += count if count > 0 else 1
    dat_tel = data.get("dat_telemetry")
    if isinstance(dat_tel, dict):
        total += _count_source_shape_subcode_in_dict(dat_tel)
    return total


def _count_source_shape_subcode_in_jsonl(path):
    if not path or not os.path.isfile(path):
        return 0
    total = 0
    try:
        with open(path, "r") as handle:
            for raw in handle:
                text = raw.strip()
                if not text:
                    continue
                if DAT_SOURCE_SHAPE_SUBCODE not in text:
                    continue
                try:
                    payload = json.loads(text)
                except Exception:
                    total += 1
                    continue
                count = _count_source_shape_subcode_in_dict(payload)
                total += count if count > 0 else 1
    except Exception:
        return total
    return total


def _find_source_shape_terminalization_report(reports_dir, followup_run_id):
    rid = _safe_str(followup_run_id).strip()
    if not reports_dir or not os.path.isdir(reports_dir):
        return ""
    candidates = []
    try:
        names = sorted(os.listdir(reports_dir))
    except Exception:
        names = []
    for name in names:
        lower = name.lower()
        if not (lower.endswith(".json") or lower.endswith(".txt")):
            continue
        if "source_shape" not in lower:
            continue
        if "terminal" not in lower and "terminalization" not in lower:
            continue
        if rid and rid not in name:
            continue
        path = os.path.join(reports_dir, name)
        text = _read_text(path)
        payload = _read_json(path, {}) if lower.endswith(".json") else {}
        if DAT_SOURCE_SHAPE_SUBCODE in text or _count_source_shape_subcode_in_dict(payload) > 0:
            candidates.append(path)
    return candidates[0] if candidates else ""


def _source_shape_next_gate_from_report(path):
    payload = _read_json(path, {}) if path and path.lower().endswith(".json") else {}
    if isinstance(payload, dict):
        for key in (
                "next_gate_action_kind",
                "next_recommended_action_kind",
                "next_step",
                "recommended_action_kind_after_terminalization"):
            value = _safe_str(payload.get(key)).strip()
            if value:
                return value
    note = _parse_key_value_note(path) if path else {}
    for key in (
            "next_gate_action_kind",
            "next_recommended_action_kind",
            "next_step",
            "recommended_action_kind_after_terminalization"):
        value = _safe_str(note.get(key)).strip()
        if value:
            return value
    return "continue_followup_phase_d_after_terminal_source_shape_rejects"


def _followup_phase_d_status(bundle_dir, reports_dir, reviewed_anchor_phase_d_run_id):
    note_path = _find_followup_note(reports_dir)
    if not note_path:
        return {}
    note = _parse_key_value_note(note_path)
    followup_run_id = _first_value(note.get("followup_phase_d_run_id"))
    qa_path = _resolve_followup_path_from_note(
        note.get("qa_canonical_summary_path"), reports_dir,
        "qa_canonical_summary_", followup_run_id, ".json")
    reject_path = _resolve_followup_path_from_note(
        note.get("qa_reject_samples_path"), reports_dir,
        "qa_reject_samples_", followup_run_id, ".jsonl")
    dat_anchor_profile_json = _resolve_followup_path_from_note(
        note.get("dat_anchor_failure_profile_json_path"), reports_dir,
        "dat_anchor_failure_profile_", followup_run_id, ".json")
    dat_anchor_profile_txt = _resolve_followup_path_from_note(
        note.get("dat_anchor_failure_profile_txt_path"), reports_dir,
        "dat_anchor_failure_profile_", followup_run_id, ".txt")
    qa_summary = _read_json(qa_path) if qa_path else {}
    counts = _dat_counts(qa_summary, {}) if qa_summary else _parse_phase_d_counts(note.get("phase_d_counts"))
    movement = _first_value(
        note.get("phase_d_movement_classification"),
        note.get("followup_classification"),
        classify_phase_d_movement(counts, followup_only=True),
    )
    reject_action = classify_dat_reject_next_action(qa_summary)
    source_shape_count = max(
        _count_source_shape_subcode_in_dict(qa_summary),
        _count_source_shape_subcode_in_jsonl(reject_path),
    )
    source_shape_terminal_report = _find_source_shape_terminalization_report(reports_dir, followup_run_id)
    if not reject_action.get("dominant_reject_code"):
        reject_action = {
            "dominant_reject_code": _safe_str(note.get("dominant_reject_code")).strip(),
            "dominant_reject_count": _safe_int(note.get("dominant_reject_count"), 0),
            "dat_reject_blocker_class": _safe_str(note.get("dat_reject_blocker_class")).strip(),
            "recommended_developer_action": _safe_str(note.get("recommended_developer_action")).strip(),
            "dat_reject_counts_by_reason": {},
            "safe_artifact_file_prefix_counts": {},
        }
    return {
        "reviewed_anchor_phase_d_run_id": _first_value(
            note.get("reviewed_anchor_phase_d_run_id"),
            reviewed_anchor_phase_d_run_id),
        "followup_phase_d_run_id": followup_run_id,
        "phase_d_movement_classification": movement,
        "selected_count": counts.get("selected", 0),
        "qa_pass_count": counts.get("qa_pass", 0),
        "qa_reject_count": counts.get("qa_reject", 0),
        "canonical_count": counts.get("canonical", 0),
        "v2_inserted_count": counts.get("v2_inserted", 0),
        "accepted_as_reviewed_anchor_milestone": _parse_bool(note.get("accepted_as_reviewed_anchor_milestone")),
        "qa_canonical_summary_path": qa_path,
        "qa_reject_samples_path": reject_path,
        "dat_anchor_failure_profile_json_path": dat_anchor_profile_json,
        "dat_anchor_failure_profile_txt_path": dat_anchor_profile_txt,
        "note_path": note_path,
        "dominant_reject_code": reject_action.get("dominant_reject_code", ""),
        "dominant_reject_count": reject_action.get("dominant_reject_count", 0),
        "dat_reject_blocker_class": reject_action.get("dat_reject_blocker_class", ""),
        "recommended_developer_action": reject_action.get("recommended_developer_action", ""),
        "terminal_reject_subcode": DAT_SOURCE_SHAPE_SUBCODE if source_shape_count > 0 else "",
        "terminal_reject_subcode_count": source_shape_count,
        "source_shape_terminalization_report_path": source_shape_terminal_report,
        "source_shape_terminalization_present": bool(source_shape_terminal_report),
        "source_shape_next_gate_action_kind": _source_shape_next_gate_from_report(source_shape_terminal_report)
        if source_shape_terminal_report else "",
        "live_state_warning": _safe_str(note.get("live_state_warning")).strip(),
    }


def _walk_dicts(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            for row in _walk_dicts(child):
                yield row
    elif isinstance(value, list):
        for child in value:
            for row in _walk_dicts(child):
                yield row


def _recommendation_surfaces(meta, evidence_scope, shadow, qa_summary, reports_dir):
    surfaces = []
    for source, payload in (
            ("meta.json", meta),
            ("evidence_scope.json", evidence_scope),
            ("shadow_run_report", shadow),
            ("qa_canonical_summary", qa_summary)):
        if not isinstance(payload, dict):
            continue
        for item in _walk_dicts(payload):
            action = _first_value(
                item.get("recommended_action_kind"),
                item.get("recommendation_action_kind"),
                item.get("layer1_runbook_action_kind"),
                item.get("preferred_when_stable_action_kind"),
            )
            if not action:
                continue
            row = {
                "source": source,
                "recommended_action_kind": action,
            }
            if "action_requires_confirmation" in item:
                row["action_requires_confirmation"] = bool(item.get("action_requires_confirmation"))
            if "historical_reprocess_available" in item:
                row["historical_reprocess_available"] = bool(item.get("historical_reprocess_available"))
            surfaces.append(row)
            break

    text_names = (
        "system_health_pack_latest.txt",
        "artifact_triage_pack_",
        "run_artifact_index_",
    )
    if reports_dir and os.path.isdir(reports_dir):
        try:
            names = sorted(os.listdir(reports_dir))
        except Exception:
            names = []
        for name in names:
            if not name.endswith(".txt"):
                continue
            if not any(name == prefix or name.startswith(prefix) for prefix in text_names):
                continue
            note = _parse_key_value_note(os.path.join(reports_dir, name))
            action = _first_value(
                note.get("recommended_action_kind"),
                note.get("recommendation_action_kind"),
                note.get("layer1_runbook_action_kind"),
            )
            if not action:
                continue
            row = {
                "source": name,
                "recommended_action_kind": action,
            }
            if "action_requires_confirmation" in note:
                row["action_requires_confirmation"] = _parse_bool(note.get("action_requires_confirmation"))
            if "historical_reprocess_available" in note:
                row["historical_reprocess_available"] = _parse_bool(note.get("historical_reprocess_available"))
            surfaces.append(row)
    return surfaces


def _historical_execution_status(reports_dir, anchor):
    path = os.path.join(reports_dir, "phase_d_historical_reprocess_execution_latest.txt")
    if not os.path.isfile(path):
        return {
            "present": False,
            "path": "",
            "same_anchor": False,
            "terminal": False,
            "status": "",
            "rows_reselected_for_next_phase_d_count": 0,
        }
    note = _parse_key_value_note(path)
    status = _safe_str(note.get("execution_status")).strip().lower()
    same_anchor = bool(anchor and _safe_str(note.get("remediation_context_run_id")).strip() == anchor)
    return {
        "present": True,
        "path": path,
        "same_anchor": same_anchor,
        "terminal": status in ("completed", "failed", "skipped", "cancelled", "timeout"),
        "status": status,
        "remediation_context_run_id": _safe_str(note.get("remediation_context_run_id")).strip(),
        "rows_reselected_for_next_phase_d_count": _safe_int(note.get("rows_reselected_for_next_phase_d_count"), 0),
        "rows_invalidated_count": _safe_int(note.get("rows_invalidated_count"), 0),
    }


def _diagnostic_attempts_status(reports_dir, anchor):
    out = []
    for path in _find_all("diagnostic_attempt_", ".json", reports_dir):
        payload = _read_json(path)
        if not isinstance(payload, dict):
            payload = {}
        kind = _first_value(payload.get("kind"), payload.get("action_kind"), payload.get("diagnostic_kind"))
        status = _safe_str(payload.get("status")).strip().lower()
        accepted = payload.get("accepted_for_anchor")
        if accepted is None:
            accepted = bool(anchor and _first_value(
                payload.get("target_anchor_run_id"),
                payload.get("anchor_run_id"),
                payload.get("target_context_run_id"),
            ) == anchor)
        out.append({
            "path": path,
            "kind": kind or os.path.basename(path),
            "status": status,
            "terminal": status in ("succeeded", "completed", "success", "ok", "failed", "timeout", "cancelled"),
            "accepted_for_anchor": bool(accepted),
            "primary_report_path": _safe_str(payload.get("primary_report_path")).strip(),
            "expected_artifacts": payload.get("expected_artifacts") if isinstance(payload.get("expected_artifacts"), list) else [],
            "pid": payload.get("pid"),
            "child_pid": payload.get("child_pid"),
            "returncode": payload.get("returncode"),
        })
    return out


def _compute_recommendation_against_hydrated_lab(repo_root, lab_dir):
    old_lab = os.environ.get("MEDICAFE_LAB_DIR")
    os.environ["MEDICAFE_LAB_DIR"] = lab_dir
    patched = []
    try:
        try:
            from MediCafe import cloud_readiness as cr
            for attr in ("collect_support_bundle", "submit_support_bundle_email"):
                if hasattr(cr, attr):
                    patched.append((cr, attr, getattr(cr, attr)))
                    setattr(cr, attr, None)
            rec = cr.compute_operator_support_send_recommendation(repo_root)
            if isinstance(rec, dict):
                return rec
        except Exception as exc:
            return {"error": _safe_str(exc)}
        return {}
    finally:
        for module, attr, value in reversed(patched):
            try:
                setattr(module, attr, value)
            except Exception:
                pass
        if old_lab is None:
            try:
                del os.environ["MEDICAFE_LAB_DIR"]
            except KeyError:
                pass
        else:
            os.environ["MEDICAFE_LAB_DIR"] = old_lab


def _workflow_boundary_status(repo_root, lab_dir, reports_dir, anchor, meta, evidence_scope, shadow, qa_summary, followup):
    captured = _recommendation_surfaces(meta, evidence_scope, shadow, qa_summary, reports_dir)
    execution = _historical_execution_status(reports_dir, anchor)
    attempts = _diagnostic_attempts_status(reports_dir, anchor)
    recomputed = _compute_recommendation_against_hydrated_lab(repo_root, lab_dir)
    recomputed_action = _safe_str(recomputed.get("recommended_action_kind")).strip()
    recomputed_requires_confirmation = bool(recomputed.get("action_requires_confirmation"))
    recomputed_hist_available = bool(recomputed.get("historical_reprocess_available"))

    captured_historical = [row for row in captured if row.get("recommended_action_kind") == "historical_phase_d_reprocess"]
    captured_confirmation = [row for row in captured_historical if row.get("action_requires_confirmation") is True]
    followup_has_movement = False
    if isinstance(followup, dict) and followup:
        followup_has_movement = (
            _safe_int(followup.get("selected_count"), 0) > 0
            or _safe_int(followup.get("qa_reject_count"), 0) > 0
            or _safe_int(followup.get("qa_pass_count"), 0) > 0
            or _safe_int(followup.get("canonical_count"), 0) > 0
        )
    terminal_replay_moved_phase_d = (
        execution.get("same_anchor")
        and execution.get("status") == "completed"
        and _safe_int(execution.get("rows_reselected_for_next_phase_d_count"), 0) > 0
        and followup_has_movement
    )
    accepted_attempts = [row for row in attempts if row.get("accepted_for_anchor") and row.get("terminal")]

    findings = []
    if captured_confirmation:
        findings.append("operator_burden_confirmation_prompt")
    if captured_historical and terminal_replay_moved_phase_d:
        findings.append("captured_recommendation_repeats_after_terminal_historical_replay")
    if recomputed_action == "historical_phase_d_reprocess" and terminal_replay_moved_phase_d:
        findings.append("local_recomputed_recommendation_repeats_after_terminal_historical_replay")
    if recomputed_action == "historical_phase_d_reprocess" and recomputed_requires_confirmation:
        findings.append("local_recomputed_historical_action_requires_confirmation")
    if captured_historical and not execution.get("present"):
        findings.append("historical_recommendation_without_execution_report")
    if execution.get("present") and not accepted_attempts:
        findings.append("historical_execution_without_terminal_diagnostic_attempt")
    for row in accepted_attempts:
        if not row.get("primary_report_path") and not row.get("expected_artifacts"):
            findings.append("terminal_diagnostic_attempt_missing_report_pointers")
            break

    status = "clean"
    if findings:
        status = "review_required"
    if any(item in findings for item in (
            "local_recomputed_recommendation_repeats_after_terminal_historical_replay",
            "local_recomputed_historical_action_requires_confirmation")):
        status = "local_code_regression"

    return {
        "schema_version": "xp_workflow_boundary_replay_v1",
        "status": status,
        "findings": findings,
        "target_identity": {
            "anchor_run_id": anchor,
            "phase_d_run_id": _safe_str(qa_summary.get("run_id") if isinstance(qa_summary, dict) else "").strip(),
        },
        "captured_recommendation_surfaces": captured,
        "recomputed_recommendation": {
            "recommended_action_kind": recomputed_action,
            "action_requires_confirmation": recomputed_requires_confirmation,
            "historical_reprocess_available": recomputed_hist_available,
            "historical_reprocess_not_triggered_reason": _safe_str(recomputed.get("historical_reprocess_not_triggered_reason")).strip(),
            "recommended_report_kind": _safe_str(recomputed.get("recommended_report_kind")).strip(),
            "summary_line": _safe_str(recomputed.get("summary_line")).strip(),
            "error": _safe_str(recomputed.get("error")).strip(),
        },
        "historical_reprocess_execution": execution,
        "diagnostic_attempts": attempts,
        "terminal_replay_moved_phase_d": terminal_replay_moved_phase_d,
    }


def _milestone_verdict(qa_summary, shadow):
    counts = _dat_counts(qa_summary, shadow)
    stage = _first_value(
        qa_summary.get("phase_d_data_plane_stage") if isinstance(qa_summary, dict) else "",
        shadow.get("phase_d_data_plane_stage") if isinstance(shadow, dict) else "",
    )
    if counts["selected"] > 0 and counts["qa_pass"] > 0 and counts["canonical"] > 0:
        if stage == "milestone_ready":
            return "Milestone-ready evidence", counts, stage
        return "Partially advanced", counts, stage
    if counts["selected"] > 0 or counts["qa_pass"] > 0 or counts["canonical"] > 0:
        return "Partially advanced", counts, stage
    return "Not advanced", counts, stage


def _developer_unblock_entries(qa_summary):
    try:
        from MediCafe.phase_d_developer_unblock import evidence_report_entries_from_summary
        return evidence_report_entries_from_summary(qa_summary)
    except Exception:
        pass
    data = qa_summary if isinstance(qa_summary, dict) else {}
    entries = []
    for key in (
            "phase_d_invalid_external_id_contract_report_json_path",
            "phase_d_invalid_external_id_contract_report_txt_path"):
        path = _safe_str(data.get(key)).strip()
        if path:
            entries.append({
                "path": path,
                "archive_name": os.path.basename(path),
                "required": True,
                "contains_pii": False,
                "safe_for_bundle": True,
            })
    return entries


def _developer_unblock_status(qa_summary):
    contract = qa_summary.get("phase_d_developer_unblock") if isinstance(qa_summary, dict) else {}
    reports = _developer_unblock_entries(qa_summary)
    if (not isinstance(contract, dict) or not contract) and not reports:
        return {
            "status": "absent",
            "missing_reports": [],
            "present_reports": [],
            "recommended_action_kind": "",
            "operator_manual_review_required": False,
        }
    missing = []
    present = []
    for row in reports:
        if not isinstance(row, dict):
            continue
        path = _safe_str(row.get("path")).strip()
        name = _safe_str(row.get("archive_name")).strip() or os.path.basename(path)
        if path and os.path.isfile(path):
            present.append(name)
        elif bool(row.get("required", True)):
            missing.append(name or path)
    status = "complete"
    if missing:
        status = "degraded"
    if not reports:
        status = "not_applicable"
    return {
        "status": status,
        "missing_reports": missing,
        "present_reports": present,
        "recommended_action_kind": _safe_str(contract.get("recommended_action_kind") if isinstance(contract, dict) else "").strip(),
        "operator_manual_review_required": bool(contract.get("operator_manual_review_required", False)) if isinstance(contract, dict) else False,
        "next_predicted_stall": _safe_str(contract.get("next_predicted_stall") if isinstance(contract, dict) else "").strip(),
    }


def _find_nested_dict_with_key(payload, wanted_key):
    key = _safe_str(wanted_key).strip()
    if not key:
        return {}
    for item in _walk_dicts(payload):
        if isinstance(item, dict) and isinstance(item.get(key), dict):
            return item.get(key)
    return {}


def _artifact_discovery_dat_shape_profile(reports_dir):
    for path in _find_all("artifact_discovery_summary_", ".json", reports_dir):
        payload = _read_json(path)
        profile = _find_nested_dict_with_key(payload, "dat_manifest_shape_profile")
        if profile:
            out = dict(profile)
            out["_source_path"] = path
            return out
    return {}


def _has_terminal_attempt_report_pointers(workflow_boundary):
    boundary = workflow_boundary if isinstance(workflow_boundary, dict) else {}
    for row in boundary.get("diagnostic_attempts") or []:
        if not isinstance(row, dict):
            continue
        if not row.get("terminal"):
            continue
        if row.get("primary_report_path") or row.get("expected_artifacts"):
            return True
    return False


def _next_xp_defect_telemetry_readiness(reports_dir, anchor, qa_summary, followup, workflow_boundary):
    """Summarize whether replay has enough safe telemetry to diagnose the next XP defect."""
    follow = followup if isinstance(followup, dict) else {}
    qa_path = _safe_str(follow.get("qa_canonical_summary_path")).strip()
    active_qa = _read_json(qa_path) if qa_path and os.path.isfile(qa_path) else qa_summary
    active_qa = active_qa if isinstance(active_qa, dict) else {}
    dat_tel = active_qa.get("dat_telemetry") if isinstance(active_qa.get("dat_telemetry"), dict) else {}
    dat_shape = dat_tel.get("dat_file_shape_diagnostics") if isinstance(dat_tel.get("dat_file_shape_diagnostics"), dict) else {}
    manifest_shape = _artifact_discovery_dat_shape_profile(reports_dir)
    db_note = _find_by_run("run_evidence_db_hydration_note_", anchor, ".txt", reports_dir)
    anchor_profile_json = _safe_str(follow.get("dat_anchor_failure_profile_json_path")).strip()
    anchor_profile_txt = _safe_str(follow.get("dat_anchor_failure_profile_txt_path")).strip()
    if not anchor_profile_json:
        rid = _safe_str(follow.get("followup_phase_d_run_id")).strip()
        anchor_profile_json = _find_by_run("dat_anchor_failure_profile_", rid, ".json", reports_dir)
        anchor_profile_txt = _find_by_run("dat_anchor_failure_profile_", rid, ".txt", reports_dir)
    followup_rejects = _safe_int(follow.get("qa_reject_count"), 0)
    readiness_items = {
        "followup_dat_rejects_present": followup_rejects > 0,
        "dat_anchor_failure_profile_present": bool(anchor_profile_json and os.path.isfile(anchor_profile_json)),
        "dat_anchor_failure_profile_txt_present": bool(anchor_profile_txt and os.path.isfile(anchor_profile_txt)),
        "dat_file_shape_diagnostics_present": bool(dat_shape),
        "dat_manifest_shape_profile_present": bool(manifest_shape),
        "db_hydration_note_present": bool(db_note and os.path.isfile(db_note)),
        "terminal_diagnostic_report_pointers_present": _has_terminal_attempt_report_pointers(workflow_boundary),
    }
    required_when_rejecting = [
        "dat_anchor_failure_profile_present",
        "dat_file_shape_diagnostics_present",
        "dat_manifest_shape_profile_present",
        "db_hydration_note_present",
        "terminal_diagnostic_report_pointers_present",
    ]
    missing = []
    if followup_rejects > 0:
        for key in required_when_rejecting:
            if not readiness_items.get(key):
                missing.append(key)
    status = "ready_for_next_xp_diagnosis"
    if followup_rejects > 0 and missing:
        status = "missing_defect_explanation_telemetry"
    elif followup_rejects <= 0:
        status = "not_applicable_no_followup_dat_rejects"
    return {
        "schema_version": "xp_next_defect_telemetry_readiness_v1",
        "status": status,
        "missing_items": missing,
        "items": readiness_items,
        "expected_next_bundle_artifacts": [
            "dat_anchor_failure_profile_<followup_phase_d_run_id>.json/.txt",
            "qa_canonical_summary_<followup_phase_d_run_id>.json with dat_file_shape_diagnostics",
            "artifact_discovery_summary_<phase_b_run_id>.json with dat_manifest_shape_profile",
            "run_evidence_db_hydration_note_<anchor_run_id>.txt",
            "terminal diagnostic_attempt_*.json with primary_report_path or expected_artifacts",
        ],
        "followup_phase_d_run_id": _safe_str(follow.get("followup_phase_d_run_id")).strip(),
        "followup_qa_reject_count": followup_rejects,
        "dat_anchor_failure_profile_json_path": anchor_profile_json,
        "dat_file_shape_diagnostics_source_path": qa_path,
        "dat_manifest_shape_profile_source_path": _safe_str(manifest_shape.get("_source_path")).strip(),
        "db_hydration_note_path": db_note,
    }


def _smoke_status(reports_dir, anchor):
    mismatch = _find_by_run("run_evidence_smoke_anchor_mismatch_", anchor, ".txt", reports_dir)
    if mismatch:
        return {
            "verdict": "ignored_mismatch",
            "accepted_for_anchor": False,
            "ignored_smoke_mismatch": True,
            "path": mismatch,
        }
    note = _find_by_run("run_evidence_dat_smoke_note_", anchor, ".txt", reports_dir)
    state_path = os.path.join(reports_dir, "phase_d_dat_smoke_state.json")
    if not os.path.isfile(state_path):
        state_path = ""
    state = _read_json(state_path) if state_path else {}
    last_anchor = _first_value(state.get("last_requested_anchor_run_id"), state.get("anchor_run_id"), state.get("last_anchor_run_id"))
    status = _safe_str(state.get("last_status")).strip()
    report_path = _safe_str(state.get("last_report_path")).strip()
    accepted = bool(anchor and last_anchor == anchor and status in ("completed", "success", "ok"))
    if accepted:
        return {
            "verdict": "accepted_for_anchor",
            "accepted_for_anchor": True,
            "ignored_smoke_mismatch": False,
            "path": report_path or state_path,
            "last_status": status,
        }
    if state_path:
        return {
            "verdict": "state_present_not_accepted",
            "accepted_for_anchor": False,
            "ignored_smoke_mismatch": False,
            "path": state_path,
            "last_status": status,
        }
    if note:
        return {
            "verdict": "note_present",
            "accepted_for_anchor": False,
            "ignored_smoke_mismatch": False,
            "path": note,
        }
    return {
        "verdict": "not_packaged",
        "accepted_for_anchor": False,
        "ignored_smoke_mismatch": False,
        "path": "",
    }


def _coherence(anchor, phase_map, qa_summary, shadow):
    warnings = []
    d_run = _safe_str(phase_map.get("D")).strip()
    qa_run = _safe_str(qa_summary.get("run_id") if isinstance(qa_summary, dict) else "").strip()
    shadow_run = _safe_str(shadow.get("run_id") if isinstance(shadow, dict) else "").strip()
    shadow_phase = _phase_map_from_any(shadow)
    if anchor and shadow_run and shadow_run != anchor:
        warnings.append("shadow_run_id_mismatch:{0}!={1}".format(shadow_run, anchor))
    if d_run and qa_run and qa_run != d_run:
        warnings.append("phase_d_summary_run_id_mismatch:{0}!={1}".format(qa_run, d_run))
    for phase, rid in phase_map.items():
        srid = _safe_str(shadow_phase.get(phase)).strip()
        if srid and srid != rid:
            warnings.append("phase_{0}_map_shadow_mismatch:{1}!={2}".format(phase, rid, srid))
    return "review_required" if warnings else "coherent", warnings


def _original_path_for_basename(bundle_dir, path):
    base = os.path.basename(_safe_str(path).strip())
    if not base:
        return ""
    for src in _iter_files(bundle_dir):
        if os.path.basename(src) == base:
            return os.path.abspath(src)
    return _safe_str(path).strip()


def _original_path_for_basename_from_sources(bundle_sources, path):
    sources = bundle_sources
    if not isinstance(sources, (list, tuple)):
        sources = [sources]
    for source in sources:
        found = _original_path_for_basename(source, path)
        if found and found != _safe_str(path).strip():
            return found
    return _safe_str(path).strip()


def _rewrite_deleted_lab_references(result, bundle_sources):
    for key in ("qa_canonical_summary_path", "shadow_run_report_path"):
        path = _safe_str(result.get(key)).strip()
        if path:
            result[key] = _original_path_for_basename_from_sources(bundle_sources, path)
    smoke = result.get("smoke")
    if isinstance(smoke, dict) and _safe_str(smoke.get("path")).strip():
        smoke["path"] = _original_path_for_basename_from_sources(bundle_sources, smoke.get("path"))
    followup = result.get("followup_phase_d")
    if isinstance(followup, dict):
        for key in ("qa_canonical_summary_path", "qa_reject_samples_path",
                    "dat_anchor_failure_profile_json_path", "dat_anchor_failure_profile_txt_path",
                    "note_path"):
            path = _safe_str(followup.get(key)).strip()
            if path:
                followup[key] = _original_path_for_basename_from_sources(bundle_sources, path)
    boundary = result.get("workflow_boundary")
    if isinstance(boundary, dict):
        hist = boundary.get("historical_reprocess_execution")
        if isinstance(hist, dict) and _safe_str(hist.get("path")).strip():
            hist["path"] = _original_path_for_basename_from_sources(bundle_sources, hist.get("path"))
        for row in boundary.get("diagnostic_attempts") or []:
            if isinstance(row, dict) and _safe_str(row.get("path")).strip():
                row["path"] = _original_path_for_basename_from_sources(bundle_sources, row.get("path"))
    result["scratch_lab_dir"] = ""
    return result


def _scenario_row(code, resolution_class, next_step, operator_state, app_state,
                  confidence="medium", evidence=None, blockers=None):
    return {
        "code": code,
        "resolution_class": resolution_class,
        "next_step": next_step,
        "operator_state": operator_state,
        "app_state": app_state,
        "confidence": confidence,
        "evidence": evidence or [],
        "blockers": blockers or [],
    }


def _scenario_priority(row):
    code = row.get("code")
    order = {
        "local_workflow_boundary_regression": 10,
        "dat_patid_unreachable_source_shape_terminalized_next_gate": 14,
        "dat_patid_unreachable_source_shape": 14,
        "phase_d_selector_empty_dat_residue": 15,
        "followup_phase_d_dat_qa_rejects_missing_historical_execution": 16,
        "followup_phase_d_selected_passed_no_canonical_missing_historical_execution": 17,
        "followup_phase_d_milestone_candidate_missing_historical_execution": 18,
        "historical_replay_completed_followup_dat_qa_rejects": 20,
        "historical_replay_completed_followup_selected_passed_no_canonical": 21,
        "historical_replay_completed_followup_milestone_candidate": 22,
        "historical_replay_completed_no_phase_d_movement": 25,
        "terminal_diagnostic_attempt_missing_report_pointers": 30,
        "dat_flowing_invalid_external_id_contract_pressure": 35,
        "historical_replay_missing_execution_evidence": 40,
        "milestone_ready_evidence": 50,
        "smoke_mismatch": 60,
        "recomputed_recommendation": 70,
        "manual_review_required": 90,
    }
    return order.get(code, 80)


def _followup_movement_from_counts(followup):
    if not isinstance(followup, dict) or not followup:
        return "zero_selection"
    selected = _safe_int(followup.get("selected_count"), 0)
    passed = _safe_int(followup.get("qa_pass_count"), 0)
    rejected = _safe_int(followup.get("qa_reject_count"), 0)
    canonical = _safe_int(followup.get("canonical_count"), 0)
    if selected <= 0 and passed <= 0 and rejected <= 0 and canonical <= 0:
        return "zero_selection"
    if selected > 0 and passed > 0 and canonical > 0:
        return "milestone_candidate"
    if selected > 0 and passed > 0 and canonical <= 0:
        return "selected_passed_no_canonical"
    return "selected_rejected"


def _invalid_external_id_evidence(qa_summary, shadow, unblock):
    qa = qa_summary if isinstance(qa_summary, dict) else {}
    sh = shadow if isinstance(shadow, dict) else {}
    ub = unblock if isinstance(unblock, dict) else {}
    evidence = qa.get("next_predicted_stall_evidence")
    if not isinstance(evidence, dict):
        evidence = sh.get("phase_d_next_predicted_stall_evidence")
    if not isinstance(evidence, dict):
        evidence = ub.get("next_predicted_stall_evidence")
    if not isinstance(evidence, dict):
        evidence = {}
    contract = qa.get("external_patient_id_contract") if isinstance(qa.get("external_patient_id_contract"), dict) else {}
    if not contract:
        contract = ub.get("external_patient_id_contract") if isinstance(ub.get("external_patient_id_contract"), dict) else {}
    constraints = qa.get("constraint_skip_counts") if isinstance(qa.get("constraint_skip_counts"), dict) else {}
    count = _safe_int(evidence.get("patient_invalid_external_id_count"), 0)
    primary_count = _safe_int(evidence.get("primary_invalid_external_patient_id_count"), 0)
    if primary_count <= 0 and contract:
        primary_count = _safe_int(contract.get("primary_invalid_external_patient_id_count"), 0)
    if count <= 0:
        count = _safe_int(constraints.get("patient_invalid_external_id"), 0)
    if count <= 0:
        count = primary_count
    by_contract = evidence.get("by_source_contract") if isinstance(evidence.get("by_source_contract"), dict) else {}
    if not by_contract and contract:
        by_contract = contract.get("primary_source_contract_counts") if isinstance(contract.get("primary_source_contract_counts"), dict) else {}
    if not by_contract:
        by_contract = constraints.get("patient_invalid_external_id_by_source_contract") if isinstance(constraints.get("patient_invalid_external_id_by_source_contract"), dict) else {}
    by_disposition = evidence.get("by_contract_disposition") if isinstance(evidence.get("by_contract_disposition"), dict) else {}
    if not by_disposition and contract:
        by_disposition = contract.get("primary_contract_disposition_counts") if isinstance(contract.get("primary_contract_disposition_counts"), dict) else {}
    if not by_disposition:
        by_disposition = constraints.get("patient_invalid_external_id_by_contract_disposition") if isinstance(constraints.get("patient_invalid_external_id_by_contract_disposition"), dict) else {}
    next_stall = _first_value(
        qa.get("next_predicted_stall"),
        sh.get("phase_d_next_predicted_stall"),
        ub.get("next_predicted_stall"),
    )
    blocker = _first_value(
        ub.get("blocker_code"),
        "invalid_external_patient_id" if count > 0 else "",
    )
    return {
        "next_predicted_stall": next_stall,
        "blocker_code": blocker,
        "patient_invalid_external_id_count": count,
        "primary_invalid_external_patient_id_count": primary_count or count,
        "primary_scope": _safe_str(contract.get("primary_scope")).strip() if contract else "",
        "layer1_invalid_external_patient_id_count": _safe_int(
            (contract.get("layer1_join_quality") or {}).get("count"), 0)
        if isinstance(contract.get("layer1_join_quality"), dict) else 0,
        "by_source_contract": by_contract,
        "by_contract_disposition": by_disposition,
    }


def _invalid_external_id_contract_scenario(result, boundary, action):
    qa_summary = result.get("_qa_summary_for_scenario") if isinstance(result.get("_qa_summary_for_scenario"), dict) else {}
    shadow = result.get("_shadow_for_scenario") if isinstance(result.get("_shadow_for_scenario"), dict) else {}
    unblock = result.get("developer_unblock") if isinstance(result.get("developer_unblock"), dict) else {}
    counts = result.get("phase_d_dat_counts") if isinstance(result.get("phase_d_dat_counts"), dict) else {}
    stage = _safe_str(result.get("phase_d_data_plane_stage")).strip()
    movement = _safe_str(result.get("phase_d_movement_classification")).strip()
    invalid = _invalid_external_id_evidence(qa_summary, shadow, unblock)
    next_stall = _safe_str(invalid.get("next_predicted_stall")).strip()
    blocker_code = _safe_str(invalid.get("blocker_code")).strip()
    invalid_count = _safe_int(invalid.get("patient_invalid_external_id_count"), 0)
    is_invalid_contract = (
        next_stall == "invalid_external_patient_id"
        or blocker_code == "invalid_external_patient_id"
        or action == "resolve_external_patient_id_contract_pressure"
        or invalid_count > 0
    )
    has_dat_movement = (
        _safe_int(counts.get("selected"), 0) > 0
        and _safe_int(counts.get("qa_pass"), 0) > 0
        and _safe_int(counts.get("canonical"), 0) > 0
    )
    if not (is_invalid_contract and has_dat_movement and stage == "data_quality_blocked"):
        return None
    dev_status = _safe_str(result.get("developer_unblock_status")).strip()
    blockers = ["invalid_external_patient_id"]
    if dev_status and dev_status not in ("complete", "not_applicable"):
        blockers.append("developer_unblock_report_{0}".format(dev_status))
    evidence = [
        "phase_d_data_plane_stage={0}".format(stage),
        "phase_d_movement_classification={0}".format(movement),
        "DAT selected/pass/canonical/v2={0}/{1}/{2}/{3}".format(
            _safe_int(counts.get("selected"), 0),
            _safe_int(counts.get("qa_pass"), 0),
            _safe_int(counts.get("canonical"), 0),
            _safe_int(counts.get("v2_inserted"), 0)),
        "next_predicted_stall={0}".format(next_stall or "-"),
        "patient_invalid_external_id_count={0}".format(invalid_count),
        "primary_invalid_external_patient_id_count={0}".format(
            _safe_int(invalid.get("primary_invalid_external_patient_id_count"), 0)),
        "external_patient_id_primary_scope={0}".format(
            _safe_str(invalid.get("primary_scope")).strip() or "-"),
        "developer_unblock_status={0}".format(dev_status or "-"),
    ]
    layer1_count = _safe_int(invalid.get("layer1_invalid_external_patient_id_count"), 0)
    if layer1_count > 0:
        evidence.append("layer1_invalid_external_patient_id_count={0}".format(layer1_count))
    by_contract = invalid.get("by_source_contract") if isinstance(invalid.get("by_source_contract"), dict) else {}
    by_disposition = invalid.get("by_contract_disposition") if isinstance(invalid.get("by_contract_disposition"), dict) else {}
    if by_contract:
        evidence.append("invalid_external_id_by_source_contract={0}".format(format_count_map(by_contract)))
    if by_disposition:
        evidence.append("invalid_external_id_by_contract_disposition={0}".format(format_count_map(by_disposition)))
    return _scenario_row(
        "dat_flowing_invalid_external_id_contract_pressure",
        "requires_developer_build",
        "resolve_external_patient_id_contract_pressure_from_attached_report",
        "operator should wait; no Cloud Readiness option, DAT smoke, or manual helper is needed",
        "DAT and v2 are flowing, but the next app state remains blocked on invalid 5-digit external patient IDs",
        confidence="high",
        evidence=evidence,
        blockers=blockers,
    )


def _followup_phase_d_movement_scenario(followup, historical_execution_proven):
    followup_movement = _followup_movement_from_counts(followup)
    if followup_movement == "zero_selection":
        return None

    source_shape_count = _safe_int(followup.get("terminal_reject_subcode_count"), 0)
    if source_shape_count > 0:
        report_path = _safe_str(followup.get("source_shape_terminalization_report_path")).strip()
        if report_path:
            next_gate = _safe_str(followup.get("source_shape_next_gate_action_kind")).strip()
            return _scenario_row(
                "dat_patid_unreachable_source_shape_terminalized_next_gate",
                "auto_resolve",
                next_gate or "continue_followup_phase_d_after_terminal_source_shape_rejects",
                "operator should not repeat historical replay; the terminal source-shape report is already packaged",
                "DAT no-PATID source-shape rejects have a matching terminalization report, so replay should forecast the next gate",
                confidence="high",
                evidence=[
                    "followup_phase_d.terminal_reject_subcode={0}".format(DAT_SOURCE_SHAPE_SUBCODE),
                    "followup_phase_d.terminal_reject_subcode_count={0}".format(source_shape_count),
                    "source_shape_terminalization_report_path={0}".format(report_path),
                ],
                blockers=[],
            )
        return _scenario_row(
            "dat_patid_unreachable_source_shape",
            "requires_developer_build",
            DAT_SOURCE_SHAPE_ACTION,
            "operator should wait for a build that terminally classifies DAT no-PATID source-shape rejects",
            "follow-up DAT reject telemetry shows PATID is unreachable because of source shape, not because historical replay should run again",
            confidence="high",
            evidence=[
                "followup_phase_d.terminal_reject_subcode={0}".format(DAT_SOURCE_SHAPE_SUBCODE),
                "followup_phase_d.terminal_reject_subcode_count={0}".format(source_shape_count),
                "accepted_as_reviewed_anchor_milestone={0}".format(
                    bool(followup.get("accepted_as_reviewed_anchor_milestone"))),
            ],
            blockers=[DAT_SOURCE_SHAPE_SUBCODE],
        )

    historical_evidence = (
        "historical_reprocess_execution.status=completed"
        if historical_execution_proven
        else "historical_reprocess_execution.present=false_or_unaccepted"
    )
    blockers = []
    blocker = _safe_str(followup.get("dat_reject_blocker_class")).strip()
    if blocker:
        blockers.append(blocker)
    if not historical_execution_proven:
        blockers.append("missing_historical_execution_report")

    if followup_movement == "selected_rejected":
        code = (
            "historical_replay_completed_followup_dat_qa_rejects"
            if historical_execution_proven
            else "followup_phase_d_dat_qa_rejects_missing_historical_execution"
        )
        return _scenario_row(
            code,
            "requires_developer_build",
            "resolve_followup_phase_d_dat_qa_rejects",
            "operator has moved past historical replay and should review follow-up DAT QA reject evidence"
            if historical_execution_proven
            else "operator should not repeat historical replay; follow-up DAT reject evidence is already packaged",
            "next app state is Phase D data-quality blocked on follow-up DAT rejects",
            confidence="high",
            evidence=[
                historical_evidence,
                "followup_phase_d.qa_reject_count={0}".format(_safe_int(followup.get("qa_reject_count"), 0)),
                "accepted_as_reviewed_anchor_milestone={0}".format(
                    bool(followup.get("accepted_as_reviewed_anchor_milestone"))),
            ],
            blockers=blockers,
        )

    if followup_movement == "selected_passed_no_canonical":
        code = (
            "historical_replay_completed_followup_selected_passed_no_canonical"
            if historical_execution_proven
            else "followup_phase_d_selected_passed_no_canonical_missing_historical_execution"
        )
        return _scenario_row(
            code,
            "requires_developer_build",
            "resolve_followup_phase_d_canonicalization_gap",
            "operator has moved past historical replay and should not rerun the replay"
            if historical_execution_proven
            else "operator should not repeat historical replay; follow-up pass/no-canonical evidence is already packaged",
            "next app state is Phase D DAT selected and QA-passed, but canonical/v2 depth has not closed",
            confidence="high",
            evidence=[
                historical_evidence,
                "followup_phase_d.qa_pass_count={0}".format(_safe_int(followup.get("qa_pass_count"), 0)),
                "followup_phase_d.canonical_count={0}".format(_safe_int(followup.get("canonical_count"), 0)),
                "accepted_as_reviewed_anchor_milestone={0}".format(
                    bool(followup.get("accepted_as_reviewed_anchor_milestone"))),
            ],
            blockers=blockers or ["canonicalization_gap"],
        )

    code = (
        "historical_replay_completed_followup_milestone_candidate"
        if historical_execution_proven
        else "followup_phase_d_milestone_candidate_missing_historical_execution"
    )
    return _scenario_row(
        code,
        "auto_resolve",
        "send_or_review_coherent_followup_run_evidence_bundle",
        "operator should let the app send/review the follow-up run bundle, not claim the old anchor"
        if historical_execution_proven
        else "operator should not repeat historical replay; app should package the follow-up run as its own review anchor",
        "follow-up Phase D is milestone-candidate but must be reviewed as its own coherent bundle",
        confidence="high",
        evidence=[
            historical_evidence,
            "followup_phase_d.qa_pass_count={0}".format(_safe_int(followup.get("qa_pass_count"), 0)),
            "followup_phase_d.canonical_count={0}".format(_safe_int(followup.get("canonical_count"), 0)),
            "accepted_as_reviewed_anchor_milestone={0}".format(
                bool(followup.get("accepted_as_reviewed_anchor_milestone"))),
        ],
        blockers=blockers,
    )


def _classify_replay_scenarios(result):
    boundary = result.get("workflow_boundary") if isinstance(result.get("workflow_boundary"), dict) else {}
    rec = boundary.get("recomputed_recommendation") if isinstance(boundary.get("recomputed_recommendation"), dict) else {}
    findings = boundary.get("findings") or []
    followup = result.get("followup_phase_d") if isinstance(result.get("followup_phase_d"), dict) else {}
    smoke = result.get("smoke") if isinstance(result.get("smoke"), dict) else {}
    hist = boundary.get("historical_reprocess_execution") if isinstance(boundary.get("historical_reprocess_execution"), dict) else {}
    current_selector = result.get("phase_d_selector_residue") if isinstance(result.get("phase_d_selector_residue"), dict) else {}
    selector_reproduction = result.get("selector_residue_reproduction") if isinstance(result.get("selector_residue_reproduction"), dict) else {}
    action = _safe_str(rec.get("recommended_action_kind")).strip()
    scenarios = []

    if boundary.get("status") == "local_code_regression":
        scenarios.append(_scenario_row(
            "local_workflow_boundary_regression",
            "requires_developer_build",
            "fix_local_recomputed_workflow_boundary_before_xp",
            "operator should not repeat the XP workflow until local replay stops reproducing the boundary bug",
            "current dev code still predicts a stale or burdensome recommendation",
            confidence="high",
            evidence=["workflow_boundary.status=local_code_regression"],
            blockers=findings,
        ))

    if current_selector.get("present") and not followup:
        scenarios.append(_scenario_row(
            "phase_d_selector_empty_dat_residue",
            "auto_resolve",
            "continue_dat_financial_extraction_diagnostics",
            "operator should not rerun historical replay, DAT smoke, or manual bundle sends for this state",
            "Phase D terminally classified empty DAT selector residue; the next halt is non-empty DAT financial/depth hydration",
            confidence="high",
            evidence=[
                "phase_d_selector_residue.present=true",
                "rows_selected={0}".format(_safe_int(current_selector.get("rows_selected"), 0)),
                "dat_pre_qa_terminal_result_count={0}".format(
                    _safe_int(current_selector.get("dat_pre_qa_terminal_result_count"), 0)),
                "dat_empty_file_skipped_count={0}".format(
                    _safe_int(current_selector.get("dat_empty_file_skipped_count"), 0)),
                "dat_selected_count={0}".format(_safe_int(current_selector.get("dat_selected_count"), 0)),
            ],
            blockers=["non-empty DAT financial extraction/depth remains unresolved after empty DAT residue is terminally classified"],
        ))

    if selector_reproduction.get("status") == "reproduced":
        scenarios.append(_scenario_row(
            "phase_d_selector_empty_dat_residue",
            "auto_resolve" if _safe_int(selector_reproduction.get("dat_pre_qa_terminal_result_count"), 0) > 0 else "requires_developer_build",
            "continue_dat_financial_extraction_diagnostics"
            if _safe_int(selector_reproduction.get("dat_pre_qa_terminal_result_count"), 0) > 0
            else "repair_phase_d_empty_dat_skip_persistence",
            "operator should not rerun historical replay, DAT smoke, or manual bundle sends for this state",
            "Phase D can repeatedly select zero-byte DAT residue after nonzero DAT artifacts are already evaluated",
            confidence="high",
            evidence=[
                "selector_residue_reproduction.status=reproduced",
                "synthetic_nonzero_already_evaluated_count={0}".format(
                    _safe_int(selector_reproduction.get("synthetic_nonzero_already_evaluated_count"), 0)),
                "synthetic_zero_byte_eligible_count={0}".format(
                    _safe_int(selector_reproduction.get("synthetic_zero_byte_eligible_count"), 0)),
                "rows_selected={0}".format(_safe_int(selector_reproduction.get("rows_selected"), 0)),
                "dat_selected_count={0}".format(_safe_int(selector_reproduction.get("dat_selected_count"), 0)),
            ],
            blockers=["empty DAT pre-QA skips remain selector-eligible instead of terminally classified"],
        ))

    if followup:
        historical_execution_proven = (
            boundary.get("terminal_replay_moved_phase_d")
            and hist.get("same_anchor")
            and hist.get("status") == "completed")
        followup_scenario = _followup_phase_d_movement_scenario(followup, historical_execution_proven)
        if followup_scenario:
            scenarios.append(followup_scenario)

    invalid_contract_scenario = _invalid_external_id_contract_scenario(result, boundary, action)
    if invalid_contract_scenario:
        scenarios.append(invalid_contract_scenario)

    if (
            hist.get("same_anchor")
            and hist.get("status") == "completed"
            and _safe_int(hist.get("rows_reselected_for_next_phase_d_count"), 0) > 0
            and not boundary.get("terminal_replay_moved_phase_d")):
        scenarios.append(_scenario_row(
            "historical_replay_completed_no_phase_d_movement",
            "requires_more_telemetry",
            "package_historical_replay_execution_and_phase_d_selector_telemetry",
            "operator should not repeat historical replay or DAT smoke manually",
            "historical replay completed and reselected rows, but no newer Phase D DAT movement is visible",
            confidence="high",
            evidence=[
                "historical_reprocess_execution.status=completed",
                "historical_reprocess_execution.rows_reselected_for_next_phase_d_count={0}".format(
                    _safe_int(hist.get("rows_reselected_for_next_phase_d_count"), 0)),
            ],
            blockers=["no newer Phase D movement after terminal historical replay"],
        ))

    if "terminal_diagnostic_attempt_missing_report_pointers" in findings:
        scenarios.append(_scenario_row(
            "terminal_diagnostic_attempt_missing_report_pointers",
            "requires_more_telemetry",
            "rerun_or_repackage_terminal_diagnostic_with_report_pointers",
            "operator cannot interpret the terminal diagnostic without primary report pointers",
            "diagnostic attempt reached a terminal state but did not publish readable evidence pointers",
            confidence="high",
            evidence=["workflow_boundary.finding=terminal_diagnostic_attempt_missing_report_pointers"],
            blockers=["terminal diagnostic attempts lack primary_report_path/expected_artifacts"],
        ))

    if (
            "historical_recommendation_without_execution_report" in findings
            or (action == "historical_phase_d_reprocess" and not hist.get("present"))):
        scenarios.append(_scenario_row(
            "historical_replay_missing_execution_evidence",
            "requires_more_telemetry",
            "bundle_or_machine_state_missing_historical_execution_report",
            "operator is being asked to replay but the bundle cannot prove execution outcome",
            "machine state lacks packaged historical reprocess execution evidence",
            confidence="high",
            evidence=[
                "workflow_boundary.finding=historical_recommendation_without_execution_report"
                if "historical_recommendation_without_execution_report" in findings
                else "recomputed_action_kind=historical_phase_d_reprocess"
            ],
            blockers=["cannot prove replay terminal outcome from available evidence"],
        ))

    if smoke.get("verdict") == "ignored_mismatch":
        scenarios.append(_scenario_row(
            "smoke_mismatch",
            "auto_resolve",
            "ignore_mismatched_smoke_for_anchor_review",
            "operator should not count stale smoke mismatch as anchored progress or blocker",
            "smoke artifact targets a mismatched or ignored anchor and should fall out of the current forecast",
            confidence="high",
            evidence=["smoke.verdict=ignored_mismatch"],
        ))

    if result.get("milestone_verdict") == "Milestone-ready evidence":
        scenarios.append(_scenario_row(
            "milestone_ready_evidence",
            "auto_resolve",
            "review_for_milestone_closure",
            "operator can review the anchored bundle for milestone closure",
            "Phase D has selected, QA-passed, and canonical DAT evidence at milestone-ready stage",
            confidence="high",
            evidence=["milestone_verdict=Milestone-ready evidence"],
        ))

    if not scenarios and action:
        scenarios.append(_scenario_row(
            "recomputed_recommendation",
            "requires_developer_build",
            "follow_recomputed_recommendation:{0}".format(action),
            "operator should follow the locally recomputed recommendation",
            "current app state still predicts an actionable developer remediation",
            evidence=["recomputed_action_kind={0}".format(action)],
        ))
    if not scenarios:
        scenarios.append(_scenario_row(
            "manual_review_required",
            "requires_more_telemetry",
            "manual_review_required",
            "operator needs a reviewer decision from the replay bundle",
            "harness could not forecast a specific next app state",
            confidence="low",
        ))

    return sorted(scenarios, key=_scenario_priority)


def _scenario_forecast(result):
    boundary = result.get("workflow_boundary") if isinstance(result.get("workflow_boundary"), dict) else {}
    rec = boundary.get("recomputed_recommendation") if isinstance(boundary.get("recomputed_recommendation"), dict) else {}
    findings = boundary.get("findings") or []
    scenarios = _classify_replay_scenarios(result)
    primary = scenarios[0] if scenarios else {}
    blockers = []
    for row in scenarios:
        for blocker in row.get("blockers") or []:
            if blocker and blocker not in blockers:
                blockers.append(blocker)
    if "operator_burden_confirmation_prompt" in findings and "captured operator-facing confirmation burden" not in blockers:
        blockers.append("captured operator-facing confirmation burden")

    return {
        "schema_version": "xp_replay_scenario_forecast_v2",
        "primary_scenario": primary.get("code") or "",
        "resolution_class": primary.get("resolution_class") or "",
        "next_step": primary.get("next_step") or "",
        "confidence": primary.get("confidence") or "low",
        "operator_state": primary.get("operator_state") or "",
        "app_state": primary.get("app_state") or "",
        "recomputed_action_kind": _safe_str(rec.get("recommended_action_kind")).strip(),
        "workflow_boundary_status": boundary.get("status") or "",
        "workflow_boundary_findings": findings,
        "blockers": blockers,
        "scenarios": scenarios,
    }


def _format_scenarios_compact(forecast):
    if not isinstance(forecast, dict):
        return ""
    parts = []
    for row in forecast.get("scenarios") or []:
        if not isinstance(row, dict):
            continue
        code = row.get("code") or ""
        klass = row.get("resolution_class") or ""
        step = row.get("next_step") or ""
        if code:
            parts.append("{0}:{1}:{2}".format(code, klass, step))
    return " | ".join(parts)


def _analyze_hydrated_lab(bundle_sources, source_label, source_path, out_dir, lab_dir, reports_dir,
                          hydrated_path_mapping, keep_labs=False, cohort=False):
    repo = _repo_root()
    if repo not in sys.path:
        sys.path.insert(0, repo)

    from MediCafe.evidence_manifest import build_evidence_request
    from MediCafe.evidence_manifest import resolve_evidence_manifest
    from MediCafe.layer1_readiness_model import build_layer1_readiness_model
    from MediCafe.layer1_runbook_model import build_layer1_runbook_model

    meta = _read_json(os.path.join(reports_dir, "meta.json"))
    evidence_scope = _read_json(os.path.join(reports_dir, "evidence_scope.json"))
    diagnostics = _read_json(os.path.join(lab_dir, "diagnostics_state.json"))
    cursor = _read_json(os.path.join(lab_dir, "run_cursor.json"))
    shadow_path = _find_first("shadow_run_report_", ".json", reports_dir)
    shadow = _read_json(shadow_path) if shadow_path else {}
    bundle_kind = _bundle_kind(meta, evidence_scope)
    source_base = os.path.basename(os.path.abspath(source_path)).lower()
    is_name_review_only = source_base.startswith("medicafe_bundle_test_") and (
        "self_test" in source_base or "service_line_charge" in source_base)
    is_meta_review_only = (
        bool(meta.get("self_test_report"))
        or _safe_str(meta.get("command")).strip() == "build_service_line_charge_anchor_index"
        or _safe_str(meta.get("dedup_channel")).strip() == "service_line_charge_anchor_option_h_failure"
    )
    if _is_review_only_analytics_bundle_kind(bundle_kind) or is_name_review_only or is_meta_review_only:
        is_service_line_preview = bundle_kind in REVIEW_ONLY_SERVICE_LINE_BUNDLE_KINDS
        is_service_line_charge = (
            bundle_kind == "service_line_charge_anchor_option_h_failure"
            or _safe_str(meta.get("command")).strip() == "build_service_line_charge_anchor_index"
            or _safe_str(meta.get("dedup_channel")).strip() == "service_line_charge_anchor_option_h_failure"
        )
        target_identity = {
            "bundle_kind": bundle_kind,
            "analytics_run_id": _first_value(
                meta.get("x12_cpt_dx_run_id"),
                meta.get("x12_minutes_charge_run_id"),
                meta.get("run_id"),
            ),
            "validation_mode": _first_value(meta.get("x12_minutes_charge_validation_mode"), ""),
            "historical_out_of_custody_expected": bool(meta.get("x12_minutes_charge_historical_out_of_custody_expected", False)),
            "operational_charge_update": bool(meta.get("x12_minutes_charge_operational_charge_update", False)),
        }
        if is_service_line_preview:
            target_identity = {
                "bundle_kind": bundle_kind,
                "service_line_input_session_id": _first_value(
                    meta.get("service_line_input_session_id"),
                    meta.get("run_id"),
                ),
                "workflow_boundary": _first_value(
                    meta.get("service_line_input_workflow_boundary"),
                    meta.get("workflow_boundary"),
                    "preview_only_review_required",
                ),
                "claims_completion": False,
                "mutates_billing_state": False,
                "mutates_dat": False,
                "mutates_837p": False,
                "charges_entered": False,
                "raw_sidecar_attachment_policy": "not_attached",
            }
        elif bundle_kind in REVIEW_ONLY_OPERATOR_CONTEXT_BUNDLE_KINDS:
            target_identity = {
                "bundle_kind": bundle_kind,
                "workflow_boundary": _first_value(
                    meta.get("workflow_boundary"),
                    "operator_requested_shutdown_context",
                ),
                "error_code": _first_value(meta.get("error_code"), "OPERATOR_SHUTDOWN_REQUESTED"),
                "run_id": _first_value(meta.get("run_id"), evidence_scope.get("anchor_run_id")),
                "current_data_plane_evidence": False,
                "operator_initiated": True,
            }
        elif is_service_line_charge:
            target_identity = {
                "bundle_kind": bundle_kind,
                "workflow_name": _first_value(meta.get("workflow_name"), "service_line_input"),
                "command": _first_value(meta.get("command"), "build_service_line_charge_anchor_index"),
                "dedup_channel": _first_value(
                    meta.get("dedup_channel"),
                    "service_line_charge_anchor_option_h_failure",
                ),
                "claims_completion": False,
                "mutates_billing_state": False,
            }
        elif is_name_review_only or meta.get("self_test_report"):
            target_identity = {
                "bundle_kind": bundle_kind,
                "self_test_bundle": True,
                "self_test_status": _first_value(
                    (meta.get("self_test_summary") or {}).get("status")
                    if isinstance(meta.get("self_test_summary"), dict) else "",
                    meta.get("status"),
                ),
                "claims_completion": False,
                "mutates_billing_state": False,
            }
        return {
            "schema_version": "xp_bundle_replay_v1",
            "generated_at_utc": _utc_now(),
            "bundle_dir": os.path.abspath(source_path),
            "bundle_dirs": [os.path.abspath(p) for p in bundle_sources] if isinstance(bundle_sources, (list, tuple)) else [os.path.abspath(bundle_sources)],
            "scratch_lab_dir": os.path.abspath(lab_dir),
            "bundle_name": source_label,
            "cohort_replay": bool(cohort),
            "hydrated_path_mapping": hydrated_path_mapping,
            "bundle_kind": bundle_kind,
            "anchor_run_id": "",
            "phase_run_id_map": {},
            "recommendation_action_kind": "",
            "coherence_status": "review_only",
            "coherence_warnings": [],
            "attachment_contract_status": "review_only",
            "missing_required_evidence_count": 0,
            "missing_required_evidence": [],
            "workflow_boundary": {
                "schema_version": "xp_workflow_boundary_replay_v1",
                "status": "review_only",
                "findings": [],
                "target_identity": target_identity,
            },
        }
    phase_map = _phase_map_from_any(evidence_scope, meta.get("evidence_scope") if isinstance(meta.get("evidence_scope"), dict) else {}, diagnostics, cursor, shadow)
    file_phase_map = _phase_run_ids_from_files(reports_dir)
    for key, value in file_phase_map.items():
        if key not in phase_map:
            phase_map[key] = value
    anchor = _anchor_from_payloads(meta, evidence_scope, diagnostics, cursor, shadow)
    phase_d_run = _first_value(phase_map.get("D"), diagnostics.get("last_phase_d_run_id"), cursor.get("last_phase_d_run_id"))
    qa_path = _find_by_run("qa_canonical_summary_", phase_d_run, ".json", reports_dir)
    qa_summary = _read_json(qa_path) if qa_path else {}
    rec_kind = _recommendation_action(meta, evidence_scope, shadow, qa_summary)

    pack_context = {
        "anchor_run_id": anchor,
        "app_version": meta.get("app_version"),
        "anchor_shadow_report_payload": shadow,
        "pack_scope": "completed_run",
    }
    layer1 = build_layer1_readiness_model(lab_dir, reports_dir, diagnostics, pack_context)
    request = build_evidence_request(
        bundle_kind,
        meta.get("send_source") or "local_replay",
        lab_dir,
        anchor_run_id=anchor,
        active_run_id=anchor,
        recommendation_action_kind=rec_kind,
        follow_recommendation_now=meta.get("follow_recommendation_now") or "send_bundle",
        phase_run_id_map=phase_map,
        phase_d_artifact_run_id=phase_d_run,
    )
    manifest = resolve_evidence_manifest(request)
    scope = manifest.get("scope") if isinstance(manifest.get("scope"), dict) else {}
    validation = manifest.get("validation") if isinstance(manifest.get("validation"), dict) else {}
    runbook = build_layer1_runbook_model(
        layer1,
        diagnostics,
        cursor,
        scope,
        app_version=meta.get("app_version") or "",
    )
    milestone, counts, stage = _milestone_verdict(qa_summary, shadow)
    unblock = _developer_unblock_status(qa_summary)
    smoke = _smoke_status(reports_dir, anchor)
    followup_source = bundle_sources[0] if isinstance(bundle_sources, (list, tuple)) and bundle_sources else source_path
    followup = _followup_phase_d_status(followup_source, reports_dir, phase_d_run)
    workflow_boundary = _workflow_boundary_status(
        repo,
        lab_dir,
        reports_dir,
        anchor,
        meta,
        evidence_scope,
        shadow,
        qa_summary,
        followup,
    )
    telemetry_readiness = _next_xp_defect_telemetry_readiness(
        reports_dir,
        anchor,
        qa_summary,
        followup,
        workflow_boundary,
    )
    coherence_status, coherence_warnings = _coherence(anchor, phase_map, qa_summary, shadow)
    missing = manifest.get("missing_required_evidence") or []

    result = {
        "schema_version": "xp_bundle_replay_v1",
        "generated_at_utc": _utc_now(),
        "bundle_dir": os.path.abspath(source_path),
        "bundle_dirs": [os.path.abspath(p) for p in bundle_sources] if isinstance(bundle_sources, (list, tuple)) else [os.path.abspath(bundle_sources)],
        "scratch_lab_dir": os.path.abspath(lab_dir),
        "bundle_name": source_label,
        "cohort_replay": bool(cohort),
        "hydrated_path_mapping": hydrated_path_mapping,
        "bundle_kind": bundle_kind,
        "anchor_run_id": anchor,
        "phase_run_id_map": phase_map,
        "phase_d_artifact_run_id": phase_d_run,
        "qa_canonical_summary_path": qa_path,
        "shadow_run_report_path": shadow_path,
        "recommendation_action_kind": rec_kind,
        "coherence_status": coherence_status,
        "coherence_warnings": coherence_warnings,
        "attachment_contract_status": validation.get("attachment_contract_status"),
        "missing_required_evidence_count": len(missing),
        "missing_required_evidence": missing,
        "layer1_readiness_status": layer1.get("layer1_readiness_status"),
        "layer1_data_status": layer1.get("layer1_data_status"),
        "layer1_data_quality_status": layer1.get("layer1_data_quality_status"),
        "layer1_current_blocker": layer1.get("layer1_current_blocker"),
        "layer1_current_run_id": layer1.get("layer1_current_run_id"),
        "layer1_runbook_key": runbook.get("layer1_runbook_key"),
        "layer1_runbook_action_kind": runbook.get("layer1_runbook_action_kind"),
        "layer1_runbook_reason": runbook.get("layer1_runbook_reason"),
        "developer_unblock_status": unblock.get("status"),
        "developer_unblock": unblock,
        "smoke": smoke,
        "followup_phase_d": followup,
        "workflow_boundary": workflow_boundary,
        "next_xp_defect_telemetry_readiness": telemetry_readiness,
        "phase_d_data_plane_stage": stage,
        "phase_d_dat_counts": counts,
        "phase_d_movement_classification": classify_phase_d_movement(counts),
        "phase_d_selector_residue": classify_phase_d_selector_residue(qa_summary),
        "milestone_verdict": milestone,
        "manifest_scope": scope,
        "_qa_summary_for_scenario": qa_summary,
        "_shadow_for_scenario": shadow,
    }
    result["scenario_forecast"] = _scenario_forecast(result)
    result.pop("_qa_summary_for_scenario", None)
    result.pop("_shadow_for_scenario", None)
    if not keep_labs:
        _rewrite_deleted_lab_references(result, bundle_sources)
        shutil.rmtree(lab_dir, ignore_errors=True)
    json_path = os.path.join(out_dir, "replay_{0}.json".format(source_label))
    md_path = os.path.join(out_dir, "replay_{0}.md".format(source_label))
    result["replay_json_path"] = os.path.abspath(json_path)
    result["replay_markdown_path"] = os.path.abspath(md_path)
    _write_json(json_path, result)
    _write_text(md_path, render_bundle_markdown(result))
    return result


def replay_bundle(bundle_dir, out_dir, keep_labs=False):
    base_name = _short_hydrated_label(os.path.basename(os.path.abspath(bundle_dir)))
    labs_root = os.path.join(out_dir, "labs")
    lab_dir = os.path.join(labs_root, base_name)
    if os.path.isdir(lab_dir):
        shutil.rmtree(lab_dir)
    reports_dir, hydrated_path_mapping = hydrate_bundle(bundle_dir, lab_dir)
    return _analyze_hydrated_lab(
        [bundle_dir],
        base_name,
        bundle_dir,
        out_dir,
        lab_dir,
        reports_dir,
        hydrated_path_mapping,
        keep_labs=keep_labs,
        cohort=False,
    )


def replay_cohort(bundle_dirs, out_dir, keep_labs=False):
    dirs = [os.path.abspath(p) for p in (bundle_dirs or [])]
    if not dirs:
        return {}
    base_name = "__cohort_current_machine_state"
    labs_root = os.path.join(out_dir, "labs")
    lab_dir = os.path.join(labs_root, base_name)
    if os.path.isdir(lab_dir):
        shutil.rmtree(lab_dir)
    reports_dir = os.path.join(lab_dir, "reports")
    hydrated_rows = []
    for bundle_dir in dirs:
        reports_dir, rows = hydrate_bundle(bundle_dir, lab_dir)
        source_name = os.path.basename(bundle_dir)
        for row in rows:
            row = dict(row)
            row["source_bundle"] = source_name
            hydrated_rows.append(row)
    return _analyze_hydrated_lab(
        dirs,
        base_name,
        os.path.dirname(dirs[0]),
        out_dir,
        lab_dir,
        reports_dir,
        hydrated_rows,
        keep_labs=keep_labs,
        cohort=True,
    )


def _copy_tree_clean(src, dst):
    if os.path.isdir(dst):
        shutil.rmtree(dst)
    shutil.copytree(src, dst)


def _remove_files_with_prefix(directory, prefix, suffix=""):
    if not os.path.isdir(directory):
        return
    try:
        names = os.listdir(directory)
    except Exception:
        return
    for name in names:
        if not name.startswith(prefix):
            continue
        if suffix and not name.endswith(suffix):
            continue
        try:
            os.remove(os.path.join(directory, name))
        except Exception:
            pass


def _write_historical_execution_report(reports_dir, anchor, rows=29):
    _write_text(os.path.join(reports_dir, "phase_d_historical_reprocess_execution_latest.txt"), "\n".join([
        "Historical Phase D Re-Evaluation Execution",
        "remediation_context_run_id={0}".format(anchor or "-"),
        "execution_status=completed",
        "rows_reselected_for_next_phase_d_count={0}".format(int(rows or 0)),
        "rows_invalidated_count={0}".format(int(rows or 0)),
        "",
    ]))


def _state_counts_for_followup(selected, passed, rejected, canonical):
    return {
        "last_phase_d_rows_selected": int(selected or 0),
        "last_phase_d_pass_count": int(passed or 0),
        "last_phase_d_reject_count": int(rejected or 0),
        "last_phase_d_dat_telemetry": {
            "dat_selected_count": int(selected or 0),
            "dat_qa_pass_count": int(passed or 0),
            "dat_qa_reject_count": int(rejected or 0),
            "dat_canonical_record_count": int(canonical or 0),
        },
    }


def _write_followup_phase_d(reports_dir, diagnostics_path, anchor, reviewed_d,
                            follow_d, selected, passed, rejected, canonical,
                            reject_counts=None, reject_subcode_counts=None):
    reject_counts = reject_counts if isinstance(reject_counts, dict) else {}
    reject_subcode_counts = reject_subcode_counts if isinstance(reject_subcode_counts, dict) else {}
    diagnostics = _read_json(diagnostics_path)
    if not isinstance(diagnostics, dict):
        diagnostics = {}
    diagnostics["last_phase_d_run_id"] = follow_d
    diagnostics.update(_state_counts_for_followup(selected, passed, rejected, canonical))
    diagnostics["phase_d_remediation"] = {
        "issue_code": "PHASE_D_DAT_QA_FULL_BLOCK" if int(rejected or 0) > 0 else "PHASE_D_FOLLOWUP_MOVEMENT",
        "status": "active",
        "context_run_id": follow_d,
        "verification_target": "phase_d_dat_lane",
        "verification_scope": "dat_lane_only",
        "milestone_exit_ready": False,
    }
    _write_json(diagnostics_path, diagnostics)

    qa_payload = {
        "run_id": follow_d,
        "phase_d_data_plane_stage": "milestone_ready" if int(passed or 0) > 0 and int(canonical or 0) > 0 else "data_quality_blocked",
        "dat_telemetry": {
            "dat_selected_count": int(selected or 0),
            "dat_qa_pass_count": int(passed or 0),
            "dat_qa_reject_count": int(rejected or 0),
            "dat_canonical_record_count": int(canonical or 0),
            "dat_qa_reject_counts_by_reason": reject_counts,
            "dat_terminal_reject_subcode_counts": reject_subcode_counts,
            "dat_file_shape_diagnostics": {
                "nonzero_dat_file_count": int(selected or 0),
                "median_nonzero_file_size_kb": 1.4 if int(selected or 0) > 0 else 0,
                "outlier_family_count": 0,
            },
        },
    }
    qa_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(follow_d))
    reject_path = os.path.join(reports_dir, "qa_reject_samples_{0}.jsonl".format(follow_d))
    dat_anchor_profile_json = os.path.join(reports_dir, "dat_anchor_failure_profile_{0}.json".format(follow_d))
    dat_anchor_profile_txt = os.path.join(reports_dir, "dat_anchor_failure_profile_{0}.txt".format(follow_d))
    qa_payload["dat_anchor_failure_profile_json_path"] = dat_anchor_profile_json
    qa_payload["dat_anchor_failure_profile_txt_path"] = dat_anchor_profile_txt
    note_path = os.path.join(reports_dir, "run_evidence_phase_d_followup_note_{0}.txt".format(_sanitize_name(anchor)))
    _write_json(qa_path, qa_payload)
    if int(rejected or 0) > 0:
        subcode = DAT_SOURCE_SHAPE_SUBCODE if reject_subcode_counts.get(DAT_SOURCE_SHAPE_SUBCODE) else ""
        sample = {
            "reject_code": "QA_DAT_PATIENT_ANCHOR_MISSING",
            "artifact_id": "redacted",
        }
        if subcode:
            sample["reject_subcode"] = subcode
            sample["terminal_reject_subcode"] = subcode
        _write_text(reject_path, json.dumps(sample, sort_keys=True) + "\n")
        _write_json(dat_anchor_profile_json, {
            "schema_version": "dat_anchor_failure_profile_v1",
            "run_id": follow_d,
            "dominant_failure_class": "patient_anchor_missing",
            "reject_counts_by_code": reject_counts,
            "reject_counts_by_subcode": reject_subcode_counts,
            "developer_next_step": "inspect DAT PATID extraction and patient-anchor availability",
        })
        _write_text(dat_anchor_profile_txt, "\n".join([
            "DAT Anchor Failure Profile",
            "run_id: {0}".format(follow_d),
            "dominant_failure_class: patient_anchor_missing",
            "developer_next_step: inspect DAT PATID extraction and patient-anchor availability",
            "",
        ]))
    elif os.path.isfile(reject_path):
        try:
            os.remove(reject_path)
        except Exception:
            pass
    _write_json(os.path.join(reports_dir, "artifact_discovery_summary_SCENARIO_{0}.json".format(_sanitize_name(follow_d))), {
        "run_id": "SCENARIO_{0}".format(_sanitize_name(follow_d)),
        "dat_manifest_shape_profile": {
            "nonzero_dat_file_count": int(selected or 0),
            "median_nonzero_file_size_kb": 1.4 if int(selected or 0) > 0 else 0,
            "outlier_family_count": 0,
        },
    })
    specific = classify_phase_d_movement({
        "selected": int(selected or 0),
        "qa_pass": int(passed or 0),
        "qa_reject": int(rejected or 0),
        "canonical": int(canonical or 0),
    })
    lines = [
        "Run Evidence Phase D Follow-up Note",
        "reviewed_anchor_phase_d_run_id={0}".format(reviewed_d or "-"),
        "followup_phase_d_run_id={0}".format(follow_d),
        "phase_d_movement_classification=followup_only_not_anchor_closure",
        "followup_specific_movement_classification={0}".format(specific),
        "accepted_as_reviewed_anchor_milestone=False",
        "phase_d_counts=selected:{0},qa_pass:{1},qa_reject:{2},canonical:{3}".format(
            int(selected or 0), int(passed or 0), int(rejected or 0), int(canonical or 0)),
        "dominant_reject_code={0}".format("QA_DAT_PATIENT_ANCHOR_MISSING" if int(rejected or 0) > 0 else "-"),
        "dominant_reject_count={0}".format(int(rejected or 0)),
        "dat_reject_blocker_class={0}".format("patient_anchor_missing" if int(rejected or 0) > 0 else "-"),
        "terminal_reject_subcode={0}".format(
            DAT_SOURCE_SHAPE_SUBCODE if reject_subcode_counts.get(DAT_SOURCE_SHAPE_SUBCODE) else "-"),
        "qa_canonical_summary_path={0}".format(qa_path),
        "qa_reject_samples_path={0}".format(reject_path if int(rejected or 0) > 0 else "-"),
        "dat_anchor_failure_profile_json_path={0}".format(dat_anchor_profile_json if int(rejected or 0) > 0 else "-"),
        "dat_anchor_failure_profile_txt_path={0}".format(dat_anchor_profile_txt if int(rejected or 0) > 0 else "-"),
        "live_state_warning=Current diagnostics_state may show post-anchor Phase D movement; do not count it as reviewed anchor milestone progress unless the matching Phase D summary is attached and marked as the reviewed anchor.",
        "",
    ]
    _write_text(note_path, "\n".join(lines))


def _write_invalid_external_id_contract_pressure(reports_dir, diagnostics_path, anchor, reviewed_d):
    qa_path = _find_by_run("qa_canonical_summary_", reviewed_d, ".json", reports_dir)
    qa_payload = _read_json(qa_path) if qa_path else {}
    if not isinstance(qa_payload, dict):
        qa_payload = {}
    run_id = reviewed_d or _safe_str(qa_payload.get("run_id")).strip() or "SCENARIO_PHASE_D"
    qa_payload.update({
        "run_id": run_id,
        "rows_selected": 842,
        "qa_pass_count": 799,
        "qa_reject_count": 43,
        "canonical_record_count": 13222,
        "phase_d_data_plane_stage": "data_quality_blocked",
        "phase_d_entity_scope": "v2",
        "phase_d_v2_execution_decision": "executed_v2_scope",
        "phase_d_v2_disabled_reason": "",
        "next_predicted_stall": "invalid_external_patient_id",
        "next_predicted_stall_evidence": {
            "patient_invalid_external_id_count": 13,
            "by_source_contract": {"medibot_csv_patient_id_field": 13},
            "by_contract_disposition": {"numeric_wrong_length": 12, "missing_or_blank": 1},
        },
        "constraint_skip_counts": {
            "patient_invalid_external_id": 13,
            "patient_invalid_external_id_by_source_contract": {"medibot_csv_patient_id_field": 13},
            "patient_invalid_external_id_by_contract_disposition": {"numeric_wrong_length": 12, "missing_or_blank": 1},
            "patient_invalid_external_id_by_pattern_family": {"too_short": 12, "empty": 1},
            "patient_invalid_external_id_by_artifact_class": {"patient_csv_row": 13},
        },
        "external_patient_id_contract": {
            "schema_version": "external_patient_id_contract_v1",
            "run_id": run_id,
            "primary_scope": "layer1_join_quality",
            "primary_invalid_external_patient_id_count": 20,
            "primary_source_contract_counts": {
                "medibot_csv_patient_id_field": 12,
                "medibot_docx_patient_id_field": 5,
                "medilink_dat_patient_id_field": 3,
            },
            "primary_contract_disposition_counts": {"numeric_wrong_length": 20},
            "phase_d_patient_upsert": {
                "scope": "phase_d_patient_upsert",
                "count": 13,
                "source_contract_counts": {"medibot_csv_patient_id_field": 13},
                "contract_disposition_counts": {"numeric_wrong_length": 12, "missing_or_blank": 1},
            },
            "layer1_join_quality": {
                "scope": "layer1_join_quality",
                "count": 20,
                "source_contract_counts": {
                    "medibot_csv_patient_id_field": 12,
                    "medibot_docx_patient_id_field": 5,
                    "medilink_dat_patient_id_field": 3,
                },
                "contract_disposition_counts": {"numeric_wrong_length": 20},
            },
            "leading_zero_loss_candidate_count": 20,
            "leading_zero_loss_confirmation": "requires_secondary_match",
            "contains_pii": False,
        },
        "dat_telemetry": {
            "dat_selected_count": 408,
            "dat_qa_pass_count": 400,
            "dat_qa_reject_count": 8,
            "dat_canonical_record_count": 1618,
            "phase_d_dat_v2_inserted_total": 7138,
            "dat_qa_reject_counts_by_reason": {"QA_DAT_PATIENT_ANCHOR_MISSING": 8},
            "dat_empty_file_skipped_count": 12,
            "dat_file_shape_diagnostics": {
                "parsed_file_count": 408,
                "abnormal_file_count": 10,
                "abnormal_reason_counts": {"no_patid_records": 8, "zm_prefix": 6},
            },
            "dat_anchor_diagnostics": {
                "patient_anchor_contract": "requires_5_digit_patid",
                "patient_anchor_present_count": 1618,
                "patient_anchor_missing_count": 649,
                "chart_role": "supplemental_not_patient_anchor",
            },
        },
    })
    json_report = os.path.join(reports_dir, "phase_d_invalid_external_id_contract_report_{0}.json".format(run_id))
    txt_report = os.path.join(reports_dir, "phase_d_invalid_external_id_contract_report_{0}.txt".format(run_id))
    qa_payload["phase_d_invalid_external_id_contract_report_json_path"] = json_report
    qa_payload["phase_d_invalid_external_id_contract_report_txt_path"] = txt_report
    qa_payload["phase_d_developer_unblock"] = {
        "schema_version": "phase_d_developer_unblock_v1",
        "status": "action_ready",
        "blocker_code": "invalid_external_patient_id",
        "recommended_action_kind": "resolve_external_patient_id_contract_pressure",
        "operator_manual_review_required": False,
        "safe_for_bundle": True,
        "contains_pii": False,
        "next_predicted_stall": "invalid_external_patient_id",
        "next_predicted_stall_evidence": qa_payload["next_predicted_stall_evidence"],
        "external_patient_id_contract": qa_payload["external_patient_id_contract"],
        "evidence_reports": [
            {"path": json_report, "archive_name": os.path.basename(json_report), "required": True, "contains_pii": False, "safe_for_bundle": True},
            {"path": txt_report, "archive_name": os.path.basename(txt_report), "required": True, "contains_pii": False, "safe_for_bundle": True},
        ],
    }
    if not qa_path:
        qa_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(run_id))
    _write_json(qa_path, qa_payload)
    _write_json(json_report, {
        "schema_version": "phase_d_invalid_external_id_contract_report_v1",
        "run_id": run_id,
        "contains_pii": False,
        "patient_invalid_external_id_count": 13,
        "primary_invalid_external_patient_id_count": 20,
        "primary_scope": "layer1_join_quality",
        "layer1_invalid_external_patient_id_count": 20,
        "external_patient_id_contract": qa_payload["external_patient_id_contract"],
        "rows": [
            {
                "source_contract": "medibot_csv_patient_id_field",
                "contract_disposition": "numeric_wrong_length",
                "artifact_class": "patient_csv_row",
                "field_name": "patient_csv_row.Patient ID",
                "count": 13,
                "shape_family": "redacted_external_patient_id_shape",
                "safe_examples": ["***"],
            },
        ],
    })
    _write_text(txt_report, "\n".join([
        "Phase D Invalid External Patient ID Contract Report",
        "run_id: {0}".format(run_id),
        "contains_pii: False",
        "patient_invalid_external_id_count: 13",
        "primary_scope: layer1_join_quality",
        "primary_invalid_external_patient_id_count: 20",
        "layer1_invalid_external_patient_id_count: 20",
        "contract=medibot_csv_patient_id_field; disposition=numeric_wrong_length; artifact_class=patient_csv_row; field_name=patient_csv_row.Patient ID; count=13; shape_family=redacted_external_patient_id_shape; source_token=***",
        "",
    ]))
    diagnostics = _read_json(diagnostics_path)
    if not isinstance(diagnostics, dict):
        diagnostics = {}
    diagnostics["last_shadow_pipeline_run_id"] = anchor
    diagnostics["last_phase_d_run_id"] = run_id
    diagnostics["last_phase_d_rows_selected"] = 842
    diagnostics["last_phase_d_pass_count"] = 799
    diagnostics["last_phase_d_reject_count"] = 43
    diagnostics["last_phase_d_dat_telemetry"] = dict(qa_payload["dat_telemetry"])
    _write_json(diagnostics_path, diagnostics)
    shadow_path = _find_by_run("shadow_run_report_", anchor, ".json", reports_dir)
    if shadow_path:
        shadow = _read_json(shadow_path)
        if isinstance(shadow, dict):
            shadow.update({
                "phase_d_rows_selected": 842,
                "phase_d_dat_selected_count": 408,
                "phase_d_dat_qa_pass_count": 400,
                "phase_d_dat_qa_reject_count": 8,
                "phase_d_dat_canonical_record_count": 1618,
                "phase_d_dat_v2_inserted_total": 7138,
                "phase_d_data_plane_stage": "data_quality_blocked",
                "phase_d_entity_scope": "v2",
                "phase_d_next_predicted_stall": "invalid_external_patient_id",
                "phase_d_next_predicted_stall_evidence": qa_payload["next_predicted_stall_evidence"],
            })
            _write_json(shadow_path, shadow)


def _write_terminal_attempt_with_pointers(reports_dir, anchor, follow_d):
    _write_json(os.path.join(reports_dir, "diagnostic_attempt_phase_d_manual_scenario_matrix.json"), {
        "schema_version": "diagnostic_attempt_v1",
        "diagnostic_kind": "phase_d_manual",
        "kind": "phase_d_manual",
        "status": "succeeded",
        "accepted_for_anchor": True,
        "target_anchor_run_id": anchor,
        "primary_report_path": os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(follow_d)),
        "expected_artifacts": [
            {
                "kind": "phase_d_qa_summary_json",
                "path": os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(follow_d)),
            },
        ],
        "returncode": 0,
    })


def _update_phase_d_scope_for_scenario(lab_dir, phase_d_run_id):
    rid = _safe_str(phase_d_run_id).strip()
    if not rid:
        return
    for name in ("evidence_scope.json", "diagnostics_state.json", "run_cursor.json"):
        path = os.path.join(lab_dir, name)
        payload = _read_json(path)
        if not isinstance(payload, dict):
            payload = {}
        if name == "evidence_scope.json":
            phase_map = payload.get("phase_run_id_map")
            if not isinstance(phase_map, dict):
                phase_map = {}
            phase_map["D"] = rid
            payload["phase_run_id_map"] = phase_map
        else:
            payload["last_phase_d_run_id"] = rid
            phase_map = payload.get("last_shadow_pipeline_phase_run_ids")
            if isinstance(phase_map, dict):
                phase_map["D"] = rid
                payload["last_shadow_pipeline_phase_run_ids"] = phase_map
        _write_json(path, payload)


def _selector_profile_counts(reports_dir):
    profile = _artifact_discovery_dat_shape_profile(reports_dir)
    stats = profile.get("nonzero_file_size_stats") if isinstance(profile.get("nonzero_file_size_stats"), dict) else {}
    zero = _safe_int(profile.get("zero_byte_count"), 0)
    if zero <= 0:
        zero = _safe_int(stats.get("excluded_zero_byte_count"), 0)
    nonzero = _safe_int(stats.get("nonzero_file_count"), 0)
    normal = _safe_int(profile.get("normal_looking_metadata_count"), 0)
    total = _safe_int(profile.get("manifest_dat_file_count"), 0)
    if nonzero <= 0 and total > zero:
        nonzero = total - zero
    return {
        "manifest_dat_file_count": total,
        "nonzero_file_count": nonzero,
        "normal_looking_metadata_count": normal,
        "zero_byte_count": zero,
        "profile_source_path": _safe_str(profile.get("_source_path")).strip(),
    }


def _insert_synthetic_dat_artifact(conn, artifact_id, locator, attachment_name, sha, already_evaluated):
    payload = {
        "artifact_class": "dat",
        "locator": locator,
        "attachment_name": attachment_name,
    }
    conn.execute(
        "INSERT INTO ingest_artifact "
        "(artifact_id, ingest_key, source_system, source_type, source_ref, message_id, attachment_name, "
        "attachment_sha256, payload_json, ingest_status) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            int(artifact_id),
            "selector_repro|{0}".format(int(artifact_id)),
            "xp_local",
            "file_dat",
            attachment_name,
            "selector_repro_{0}".format(int(artifact_id)),
            attachment_name,
            sha,
            json.dumps(payload, sort_keys=True),
            "ingested",
        ),
    )
    if already_evaluated:
        conn.execute(
            "INSERT INTO qa_result "
            "(artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
            "VALUES (?, 'phase_d', 'qa_v2', 'pass', NULL, NULL, ?)",
            (int(artifact_id), "selector_repro_dk_{0}".format(int(artifact_id))),
        )


def _build_phase_d_selector_residue_lab(lab_dir, reports_dir):
    """Create a minimal DB that reproduces nonzero-DAT exhaustion plus empty-DAT residue."""
    counts = _selector_profile_counts(reports_dir)
    nonzero = _safe_int(counts.get("nonzero_file_count"), 0)
    zero = _safe_int(counts.get("zero_byte_count"), 0)
    if zero <= 0:
        return {
            "status": "not_recreated",
            "reason": "bundle_dat_manifest_shape_profile_has_no_zero_byte_count",
            "counts": counts,
        }
    if nonzero <= 0:
        return {
            "status": "not_recreated",
            "reason": "bundle_dat_manifest_shape_profile_has_no_nonzero_file_count",
            "counts": counts,
        }
    db_path = os.path.join(lab_dir, "unified_model_xp.db")
    sql_path = os.path.join(_repo_root(), "sql", "unified_relational_model_v1.sql")
    if os.path.isfile(db_path):
        os.remove(db_path)
    conn = sqlite3.connect(db_path)
    try:
        with open(sql_path, "r") as handle:
            conn.executescript(handle.read())
        dat_dir = os.path.join(lab_dir, "selector_residue_dat")
        _mkdir(dat_dir)
        aid = 1
        for idx in range(nonzero):
            _insert_synthetic_dat_artifact(
                conn,
                aid,
                os.path.join(dat_dir, "Z_NONZERO_{0:04d}.DAT".format(idx + 1)),
                "Z_NONZERO_{0:04d}.DAT".format(idx + 1),
                "selector_repro_nonzero_{0}".format(idx + 1),
                True,
            )
            aid += 1
        for idx in range(zero):
            locator = os.path.join(dat_dir, "Z_EMPTY_{0:04d}.DAT".format(idx + 1))
            _write_text(locator, "")
            _insert_synthetic_dat_artifact(
                conn,
                aid,
                locator,
                "Z_EMPTY_{0:04d}.DAT".format(idx + 1),
                "selector_repro_empty_{0}".format(idx + 1),
                False,
            )
            aid += 1
        conn.commit()
    finally:
        conn.close()
    return {
        "status": "lab_built",
        "db_path": db_path,
        "counts": counts,
        "synthetic_nonzero_already_evaluated_count": nonzero,
        "synthetic_zero_byte_eligible_count": zero,
    }


def _run_phase_d_selector_residue_reproduction(lab_dir, reports_dir):
    setup = _build_phase_d_selector_residue_lab(lab_dir, reports_dir)
    if setup.get("status") != "lab_built":
        return setup
    scripts_dir = os.path.join(_repo_root(), "scripts", "unified_model")
    if scripts_dir not in sys.path:
        sys.path.insert(0, scripts_dir)
    try:
        import run_qa_canonical as rqc
        ok, rid, summary, err = rqc.run_qa_canonical(lab_dir, artifact_classes=["dat"])
    except Exception as exc:
        out = dict(setup)
        out.update({
            "status": "execution_failed",
            "error": str(exc),
        })
        return out
    summary = summary if isinstance(summary, dict) else {}
    dat_tel = summary.get("dat_telemetry") if isinstance(summary.get("dat_telemetry"), dict) else {}
    selector = classify_phase_d_selector_residue(summary)
    reproduced = (
        bool(ok)
        and bool(selector.get("present"))
        and _safe_int(summary.get("rows_selected"), 0) == _safe_int(setup.get("synthetic_zero_byte_eligible_count"), 0)
        and _safe_int(dat_tel.get("dat_empty_file_skipped_count"), 0) == _safe_int(setup.get("synthetic_zero_byte_eligible_count"), 0)
        and _safe_int(dat_tel.get("dat_selected_count"), 0) == 0
    )
    _update_phase_d_scope_for_scenario(lab_dir, rid)
    report = dict(setup)
    report.update({
        "status": "reproduced" if reproduced else "not_reproduced",
        "phase_d_ok": bool(ok),
        "phase_d_run_id": rid,
        "phase_d_error_code": err,
        "phase_d_summary_path": os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(rid)),
        "rows_selected": _safe_int(summary.get("rows_selected"), 0),
        "dat_candidate_count": _safe_int(dat_tel.get("dat_candidate_count"), 0),
        "dat_empty_file_skipped_count": _safe_int(dat_tel.get("dat_empty_file_skipped_count"), 0),
        "dat_selected_count": _safe_int(dat_tel.get("dat_selected_count"), 0),
        "dat_pre_qa_terminal_result_count": _safe_int(dat_tel.get("dat_pre_qa_terminal_result_count"), 0),
        "dat_pre_qa_skip_counts_by_reason": dat_tel.get("dat_pre_qa_skip_counts_by_reason") if isinstance(dat_tel.get("dat_pre_qa_skip_counts_by_reason"), dict) else {},
        "selector_trap_class": selector.get("selector_residue_class") if reproduced else "",
    })
    report_path = os.path.join(reports_dir, "phase_d_selector_residue_reproduction_{0}.json".format(_sanitize_name(rid or "unknown")))
    note_path = os.path.join(reports_dir, "phase_d_selector_residue_reproduction_{0}.txt".format(_sanitize_name(rid or "unknown")))
    report["report_path"] = report_path
    report["note_path"] = note_path
    _write_json(report_path, report)
    _write_text(note_path, "\n".join([
        "Phase D Selector Residue Reproduction",
        "status={0}".format(report.get("status")),
        "selector_trap_class={0}".format(report.get("selector_trap_class") or "-"),
        "phase_d_run_id={0}".format(report.get("phase_d_run_id") or "-"),
        "synthetic_nonzero_already_evaluated_count={0}".format(report.get("synthetic_nonzero_already_evaluated_count", 0)),
        "synthetic_zero_byte_eligible_count={0}".format(report.get("synthetic_zero_byte_eligible_count", 0)),
        "rows_selected={0}".format(report.get("rows_selected", 0)),
        "dat_empty_file_skipped_count={0}".format(report.get("dat_empty_file_skipped_count", 0)),
        "dat_pre_qa_terminal_result_count={0}".format(report.get("dat_pre_qa_terminal_result_count", 0)),
        "dat_selected_count={0}".format(report.get("dat_selected_count", 0)),
        "next_patch_target=Continue with non-empty DAT financial extraction/depth diagnostics after terminal empty-file classification.",
        "",
    ]))
    return report


def _run_dat_financial_alias_probe(lab_dir, reports_dir):
    probe_lab = os.path.join(lab_dir, "dat_financial_alias_probe_lab")
    if os.path.isdir(probe_lab):
        shutil.rmtree(probe_lab)
    _mkdir(probe_lab)
    _mkdir(os.path.join(probe_lab, "reports"))
    report_path = os.path.join(reports_dir, "dat_financial_alias_probe_latest.json")
    txt_path = os.path.join(reports_dir, "dat_financial_alias_probe_latest.txt")
    report = {
        "schema_version": "dat_financial_alias_probe_v1",
        "status": "failed",
        "probe_contract": "DAT CODE/CODEA plus MINTUES/AMOUNT should count as complete financial hydration",
    }
    try:
        from MediCafe.cloud_readiness_patient_tools import collect_db_enrichment_summary
        schema_path = os.path.join(_REPLAY_REPO_ROOT, "sql", "unified_relational_model_v1.sql")
        db_path = os.path.join(probe_lab, "unified_model_xp.db")
        with open(schema_path, "r", encoding="utf-8") as f:
            schema_sql = f.read()
        conn = sqlite3.connect(db_path)
        conn.executescript(schema_sql)
        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (1, 'probe_csv', 'xp_local', 'csv', 'probe.csv', '{}', 'projected')"
        )
        conn.execute(
            "INSERT INTO extracted_canonical_record "
            "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
            "VALUES (1, 1, 'patient_csv_row', 'probe-csv', 'canon_v1', "
            "'{\"Patient ID\":\"22222\",\"Surgery Date\":\"02/19/2026\"}', '{}')"
        )
        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (2, 'probe_dat', 'xp_local', 'dat', 'Z_20260219_120000.DAT', '{}', 'projected')"
        )
        conn.execute(
            "INSERT INTO extracted_canonical_record "
            "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
            "VALUES (2, 2, 'dat_record', 'probe-dat', 'canon_v1', "
            "'{\"PATID\":\"22222\",\"DATE\":\"02/19/2026\",\"CODEA\":\"66984\",\"MINTUES\":\"12\",\"AMOUNT\":\"1000.00\"}', '{}')"
        )
        conn.commit()
        conn.close()
        summary = collect_db_enrichment_summary(probe_lab)
        dat = summary.get("dat_financial_association") if isinstance(summary.get("dat_financial_association"), dict) else {}
        passed = (
            _safe_int(dat.get("dat_cpt_present_count"), 0) == 1
            and _safe_int(dat.get("dat_anesthesia_minutes_present_count"), 0) == 1
            and _safe_int(dat.get("dat_charged_amount_present_count"), 0) == 1
            and _safe_int(dat.get("csv_keys_with_dat_complete_financial_count"), 0) == 1
        )
        report.update({
            "status": "passed" if passed else "failed",
            "dat_cpt_present_count": _safe_int(dat.get("dat_cpt_present_count"), 0),
            "dat_anesthesia_minutes_present_count": _safe_int(dat.get("dat_anesthesia_minutes_present_count"), 0),
            "dat_charged_amount_present_count": _safe_int(dat.get("dat_charged_amount_present_count"), 0),
            "csv_keys_with_dat_complete_financial_count": _safe_int(
                dat.get("csv_keys_with_dat_complete_financial_count"), 0),
            "csv_keys_with_dat_complete_financial_pct": dat.get("csv_keys_with_dat_complete_financial_pct"),
        })
    except Exception as exc:
        report["error"] = _safe_str(exc)
    report["report_path"] = os.path.abspath(report_path)
    _write_json(report_path, report)
    _write_text(txt_path, "\n".join([
        "DAT Financial Alias Probe",
        "status={0}".format(report.get("status") or ""),
        "probe_contract={0}".format(report.get("probe_contract") or ""),
        "dat_cpt_present_count={0}".format(report.get("dat_cpt_present_count", 0)),
        "dat_anesthesia_minutes_present_count={0}".format(report.get("dat_anesthesia_minutes_present_count", 0)),
        "dat_charged_amount_present_count={0}".format(report.get("dat_charged_amount_present_count", 0)),
        "csv_keys_with_dat_complete_financial_count={0}".format(
            report.get("csv_keys_with_dat_complete_financial_count", 0)),
        "csv_keys_with_dat_complete_financial_pct={0}".format(
            report.get("csv_keys_with_dat_complete_financial_pct")),
        "",
    ]))
    return report


def _matrix_scenario_specs():
    return [
        {
            "name": "current_replayed_state",
            "description": "Actual hydrated cohort state from returned bundles.",
            "kind": "current",
        },
        {
            "name": "dat_flowing_invalid_external_id_contract",
            "description": "DAT/v2 are flowing on the reviewed anchor, but milestone remains blocked by invalid external patient IDs.",
            "kind": "invalid_external_id_contract_pressure",
        },
        {
            "name": "historical_completed_no_new_phase_d_movement",
            "description": "Historical replay completed, but Phase D still shows no DAT movement.",
            "kind": "no_movement",
        },
        {
            "name": "followup_dat_rejects",
            "description": "Historical replay produced follow-up DAT selected/rejected rows.",
            "kind": "followup",
            "selected": 10,
            "passed": 0,
            "rejected": 10,
            "canonical": 0,
            "reject_counts": {"QA_DAT_PATIENT_ANCHOR_MISSING": 8, "QA_DAT_PAYER_ANCHOR_MISSING": 2},
        },
        {
            "name": "dat_patid_unreachable_source_shape",
            "description": "Follow-up DAT rejects expose terminal no-PATID source-shape telemetry before terminalization.",
            "kind": "followup",
            "selected": 8,
            "passed": 0,
            "rejected": 8,
            "canonical": 0,
            "reject_counts": {"QA_DAT_PATIENT_ANCHOR_MISSING": 8},
            "reject_subcode_counts": {DAT_SOURCE_SHAPE_SUBCODE: 8},
        },
        {
            "name": "followup_pass_no_canonical",
            "description": "Follow-up Phase D selected and QA-passed DAT, but canonical remains zero.",
            "kind": "followup",
            "selected": 7,
            "passed": 7,
            "rejected": 0,
            "canonical": 0,
        },
        {
            "name": "followup_milestone_candidate",
            "description": "Follow-up Phase D selected, QA-passed, and canonicalized DAT.",
            "kind": "followup",
            "selected": 7,
            "passed": 7,
            "rejected": 0,
            "canonical": 7,
        },
        {
            "name": "selector_empty_dat_residue",
            "description": "Recreate Phase D selecting only zero-byte DAT residue after nonzero DAT artifacts are already evaluated.",
            "kind": "selector_residue",
        },
        {
            "name": "dat_financial_alias_contract",
            "description": "Probe whether Medisoft DAT CODE/CODEA, MINTUES, and AMOUNT aliases count as complete financial hydration.",
            "kind": "dat_financial_alias_probe",
        },
    ]


def _render_scenario_matrix_markdown(matrix):
    rows = matrix.get("scenarios") if isinstance(matrix.get("scenarios"), list) else []
    lines = [
        "# XP Replay Scenario Matrix",
        "",
        "- generated_at_utc: `{0}`".format(matrix.get("generated_at_utc") or ""),
        "- base_cohort_replay: `{0}`".format(matrix.get("base_cohort_replay_json") or ""),
        "",
        "| Scenario | Recomputed Action | Forecast | Next Step | Milestone | Telemetry | Workflow Boundary | Report |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for row in rows:
        forecast = row.get("scenario_forecast") if isinstance(row.get("scenario_forecast"), dict) else {}
        readiness = row.get("next_xp_defect_telemetry_readiness") if isinstance(row.get("next_xp_defect_telemetry_readiness"), dict) else {}
        selector = row.get("selector_residue_reproduction") if isinstance(row.get("selector_residue_reproduction"), dict) else {}
        alias_probe = row.get("dat_financial_alias_probe") if isinstance(row.get("dat_financial_alias_probe"), dict) else {}
        telemetry_status = selector.get("status") or alias_probe.get("status") or readiness.get("status") or ""
        lines.append(
            "| `{0}` | `{1}` | `{2}` | `{3}` | `{4}` | `{5}` | `{6}` | `{7}` |".format(
                row.get("name") or "",
                forecast.get("recomputed_action_kind") or "",
                forecast.get("primary_scenario") or "",
                forecast.get("next_step") or "",
                row.get("milestone_verdict") or "",
                telemetry_status,
                row.get("workflow_boundary_status") or "",
                row.get("replay_markdown_path") or "",
            )
        )
    lines.append("")
    lines.append("Use this matrix to decide whether the current build should auto-progress without another XP operator decision.")
    return "\n".join(lines) + "\n"


def build_scenario_matrix(input_path, out_dir, bundle_dirs):
    dirs = [os.path.abspath(p) for p in (bundle_dirs or [])]
    if not dirs:
        return {}
    scenario_dirs = [p for p in dirs if not _is_review_only_analytics_bundle_dir(p)]
    if not scenario_dirs:
        return {}
    matrix_root = os.path.join(out_dir, "scenario_matrix_labs")
    if os.path.isdir(matrix_root):
        shutil.rmtree(matrix_root)
    _mkdir(matrix_root)

    base = replay_cohort(scenario_dirs, out_dir, keep_labs=True) if len(scenario_dirs) > 1 else replay_bundle(scenario_dirs[0], out_dir, keep_labs=True)
    base_lab = base.get("scratch_lab_dir") or ""
    if not base_lab or not os.path.isdir(base_lab):
        return {}
    anchor = base.get("anchor_run_id") or ""
    phase_map = base.get("phase_run_id_map") if isinstance(base.get("phase_run_id_map"), dict) else {}
    reviewed_d = phase_map.get("D") or base.get("phase_d_artifact_run_id") or ""
    rows = []
    for spec in _matrix_scenario_specs():
        name = spec.get("name")
        lab_dir = os.path.join(matrix_root, name)
        _copy_tree_clean(base_lab, lab_dir)
        reports_dir = os.path.join(lab_dir, "reports")
        diagnostics_path = os.path.join(lab_dir, "diagnostics_state.json")
        if spec.get("kind") == "no_movement":
            _remove_files_with_prefix(reports_dir, "run_evidence_phase_d_followup_note_", ".txt")
            _write_historical_execution_report(reports_dir, anchor)
            diagnostics = _read_json(diagnostics_path)
            if not isinstance(diagnostics, dict):
                diagnostics = {}
            diagnostics["last_phase_d_run_id"] = reviewed_d
            diagnostics.update(_state_counts_for_followup(0, 0, 0, 0))
            _write_json(diagnostics_path, diagnostics)
        elif spec.get("kind") == "invalid_external_id_contract_pressure":
            _remove_files_with_prefix(reports_dir, "run_evidence_phase_d_followup_note_", ".txt")
            _remove_files_with_prefix(reports_dir, "phase_d_historical_reprocess_execution", ".txt")
            _remove_files_with_prefix(reports_dir, "phase_d_historical_reprocess_execution", ".json")
            _remove_files_with_prefix(reports_dir, "diagnostic_attempt_", ".json")
            _write_invalid_external_id_contract_pressure(reports_dir, diagnostics_path, anchor, reviewed_d)
        elif spec.get("kind") == "followup":
            _write_historical_execution_report(reports_dir, anchor)
            follow_d = "SCENARIO_{0}".format(_sanitize_name(name))
            _write_followup_phase_d(
                reports_dir,
                diagnostics_path,
                anchor,
                reviewed_d,
                follow_d,
                spec.get("selected"),
                spec.get("passed"),
                spec.get("rejected"),
                spec.get("canonical"),
                spec.get("reject_counts"),
                spec.get("reject_subcode_counts"),
            )
            _write_terminal_attempt_with_pointers(reports_dir, anchor, follow_d)
        selector_reproduction = {}
        alias_probe = {}
        if spec.get("kind") == "selector_residue":
            selector_reproduction = _run_phase_d_selector_residue_reproduction(lab_dir, reports_dir)
        elif spec.get("kind") == "dat_financial_alias_probe":
            alias_probe = _run_dat_financial_alias_probe(lab_dir, reports_dir)
        result = _analyze_hydrated_lab(
            scenario_dirs,
            "scenario_{0}".format(_sanitize_name(name)),
            input_path,
            out_dir,
            lab_dir,
            reports_dir,
            [],
            keep_labs=True,
            cohort=True,
        )
        if selector_reproduction:
            result["selector_residue_reproduction"] = selector_reproduction
            result["scenario_forecast"] = _scenario_forecast(result)
            replay_json_path = result.get("replay_json_path")
            replay_markdown_path = result.get("replay_markdown_path")
            if replay_json_path:
                _write_json(replay_json_path, result)
            if replay_markdown_path:
                _write_text(replay_markdown_path, render_bundle_markdown(result))
        if alias_probe:
            result["dat_financial_alias_probe"] = alias_probe
            replay_json_path = result.get("replay_json_path")
            replay_markdown_path = result.get("replay_markdown_path")
            if replay_json_path:
                _write_json(replay_json_path, result)
            if replay_markdown_path:
                _write_text(replay_markdown_path, render_bundle_markdown(result))
        forecast = result.get("scenario_forecast") if isinstance(result.get("scenario_forecast"), dict) else {}
        rows.append({
            "name": name,
            "description": spec.get("description") or "",
            "replay_json_path": result.get("replay_json_path") or "",
            "replay_markdown_path": result.get("replay_markdown_path") or "",
            "scenario_forecast": forecast,
            "next_xp_defect_telemetry_readiness": result.get("next_xp_defect_telemetry_readiness") if isinstance(result.get("next_xp_defect_telemetry_readiness"), dict) else {},
            "milestone_verdict": result.get("milestone_verdict") or "",
            "workflow_boundary_status": (result.get("workflow_boundary") or {}).get("status") if isinstance(result.get("workflow_boundary"), dict) else "",
            "selector_residue_reproduction": selector_reproduction,
            "dat_financial_alias_probe": alias_probe,
        })
    matrix = {
        "schema_version": "xp_replay_scenario_matrix_v1",
        "generated_at_utc": _utc_now(),
        "input_path": os.path.abspath(input_path),
        "output_dir": os.path.abspath(out_dir),
        "base_cohort_replay_json": base.get("replay_json_path") or "",
        "review_only_bundle_count": len(dirs) - len(scenario_dirs),
        "scenarios": rows,
    }
    matrix_json = os.path.abspath(os.path.join(out_dir, "scenario_matrix.json"))
    matrix_md = os.path.abspath(os.path.join(out_dir, "scenario_matrix.md"))
    matrix["scenario_matrix_json_path"] = matrix_json
    matrix["scenario_matrix_markdown_path"] = matrix_md
    _write_json(matrix_json, matrix)
    _write_text(matrix_md, _render_scenario_matrix_markdown(matrix))
    return matrix


def render_bundle_markdown(result):
    counts = result.get("phase_d_dat_counts") or {}
    followup = result.get("followup_phase_d") if isinstance(result.get("followup_phase_d"), dict) else {}
    boundary = result.get("workflow_boundary") if isinstance(result.get("workflow_boundary"), dict) else {}
    forecast = result.get("scenario_forecast") if isinstance(result.get("scenario_forecast"), dict) else {}
    lines = [
        "# XP Bundle Replay: {0}".format(result.get("bundle_name") or ""),
        "",
        "- bundle_dir: `{0}`".format(result.get("bundle_dir") or ""),
        "- cohort_replay: `{0}`".format(bool(result.get("cohort_replay"))),
        "- anchor_run_id: `{0}`".format(result.get("anchor_run_id") or ""),
        "- phase_run_id_map: `{0}`".format(json.dumps(result.get("phase_run_id_map") or {}, sort_keys=True)),
        "- coherence_status: `{0}`".format(result.get("coherence_status") or ""),
        "- attachment_contract_status: `{0}`".format(result.get("attachment_contract_status") or ""),
        "- smoke_verdict: `{0}` accepted_for_anchor=`{1}` ignored_smoke_mismatch=`{2}`".format(
            (result.get("smoke") or {}).get("verdict", ""),
            (result.get("smoke") or {}).get("accepted_for_anchor", False),
            (result.get("smoke") or {}).get("ignored_smoke_mismatch", False)),
        "- layer1: status=`{0}` data_status=`{1}` data_quality_status=`{2}` blocker=`{3}`".format(
            result.get("layer1_readiness_status") or "",
            result.get("layer1_data_status") or "",
            result.get("layer1_data_quality_status") or "",
            result.get("layer1_current_blocker") or ""),
        "- developer_unblock_status: `{0}`".format(result.get("developer_unblock_status") or ""),
        "- workflow_boundary_status: `{0}` findings=`{1}`".format(
            boundary.get("status") or "",
            ",".join(boundary.get("findings") or [])),
        "- scenario_forecast: primary=`{0}` class=`{1}` next_step=`{2}` confidence=`{3}`".format(
            forecast.get("primary_scenario") or "",
            forecast.get("resolution_class") or "",
            forecast.get("next_step") or "",
            forecast.get("confidence") or ""),
        "- phase_d_data_plane_stage: `{0}`".format(result.get("phase_d_data_plane_stage") or ""),
        "- phase_d_movement_classification: `{0}`".format(result.get("phase_d_movement_classification") or ""),
        "- DAT counts: selected=`{0}` qa_pass=`{1}` qa_reject=`{2}` canonical=`{3}` v2_inserted=`{4}`".format(
            counts.get("selected", 0), counts.get("qa_pass", 0), counts.get("qa_reject", 0),
            counts.get("canonical", 0), counts.get("v2_inserted", 0)),
        "- milestone_verdict: `{0}`".format(result.get("milestone_verdict") or ""),
        "",
    ]
    if followup:
        lines.extend([
            "## Follow-up Phase D",
            "- reviewed_anchor_phase_d_run_id: `{0}`".format(followup.get("reviewed_anchor_phase_d_run_id") or ""),
            "- followup_phase_d_run_id: `{0}`".format(followup.get("followup_phase_d_run_id") or ""),
            "- phase_d_movement_classification: `{0}`".format(followup.get("phase_d_movement_classification") or ""),
            "- accepted_as_reviewed_anchor_milestone: `{0}`".format(bool(followup.get("accepted_as_reviewed_anchor_milestone"))),
            "- DAT counts: selected=`{0}` qa_pass=`{1}` qa_reject=`{2}` canonical=`{3}` v2_inserted=`{4}`".format(
                followup.get("selected_count", 0), followup.get("qa_pass_count", 0),
                followup.get("qa_reject_count", 0), followup.get("canonical_count", 0),
                followup.get("v2_inserted_count", 0)),
            "- dominant_reject_code: `{0}` count=`{1}` blocker=`{2}`".format(
                followup.get("dominant_reject_code") or "",
                followup.get("dominant_reject_count", 0),
                followup.get("dat_reject_blocker_class") or ""),
            "- recommended_developer_action: `{0}`".format(followup.get("recommended_developer_action") or ""),
            "- qa_canonical_summary_path: `{0}`".format(followup.get("qa_canonical_summary_path") or ""),
            "- qa_reject_samples_path: `{0}`".format(followup.get("qa_reject_samples_path") or ""),
            "- dat_anchor_failure_profile_json_path: `{0}`".format(followup.get("dat_anchor_failure_profile_json_path") or ""),
            "",
        ])
    if boundary:
        rec = boundary.get("recomputed_recommendation") if isinstance(boundary.get("recomputed_recommendation"), dict) else {}
        hist = boundary.get("historical_reprocess_execution") if isinstance(boundary.get("historical_reprocess_execution"), dict) else {}
        lines.extend([
            "## Workflow Boundary",
            "- status: `{0}`".format(boundary.get("status") or ""),
            "- findings: `{0}`".format(",".join(boundary.get("findings") or [])),
            "- recomputed_recommendation: action=`{0}` confirmation=`{1}` historical_available=`{2}`".format(
                rec.get("recommended_action_kind") or "",
                bool(rec.get("action_requires_confirmation")),
                bool(rec.get("historical_reprocess_available"))),
            "- recomputed_historical_skip_reason: `{0}`".format(rec.get("historical_reprocess_not_triggered_reason") or ""),
            "- historical_execution: present=`{0}` same_anchor=`{1}` status=`{2}` rows_reselected=`{3}` path=`{4}`".format(
                bool(hist.get("present")),
                bool(hist.get("same_anchor")),
                hist.get("status") or "",
                hist.get("rows_reselected_for_next_phase_d_count", 0),
                hist.get("path") or ""),
            "- diagnostic_attempt_count: `{0}`".format(len(boundary.get("diagnostic_attempts") or [])),
            "",
        ])
    readiness = result.get("next_xp_defect_telemetry_readiness")
    if isinstance(readiness, dict) and readiness:
        lines.extend([
            "## Next XP Defect Telemetry Readiness",
            "- status: `{0}`".format(readiness.get("status") or ""),
            "- missing_items: `{0}`".format(",".join(readiness.get("missing_items") or [])),
            "- followup_phase_d_run_id: `{0}` reject_count=`{1}`".format(
                readiness.get("followup_phase_d_run_id") or "",
                readiness.get("followup_qa_reject_count", 0)),
            "- dat_anchor_failure_profile_json_path: `{0}`".format(
                readiness.get("dat_anchor_failure_profile_json_path") or ""),
            "- dat_file_shape_diagnostics_source_path: `{0}`".format(
                readiness.get("dat_file_shape_diagnostics_source_path") or ""),
            "- dat_manifest_shape_profile_source_path: `{0}`".format(
                readiness.get("dat_manifest_shape_profile_source_path") or ""),
            "- db_hydration_note_path: `{0}`".format(readiness.get("db_hydration_note_path") or ""),
            "",
        ])
    selector = result.get("selector_residue_reproduction")
    if isinstance(selector, dict) and selector:
        lines.extend([
            "## Phase D Selector Residue Reproduction",
            "- status: `{0}`".format(selector.get("status") or ""),
            "- selector_trap_class: `{0}`".format(selector.get("selector_trap_class") or ""),
            "- phase_d_run_id: `{0}`".format(selector.get("phase_d_run_id") or ""),
            "- synthetic_nonzero_already_evaluated_count: `{0}`".format(
                selector.get("synthetic_nonzero_already_evaluated_count", 0)),
            "- synthetic_zero_byte_eligible_count: `{0}`".format(
                selector.get("synthetic_zero_byte_eligible_count", 0)),
            "- rows_selected: `{0}`".format(selector.get("rows_selected", 0)),
            "- dat_empty_file_skipped_count: `{0}`".format(selector.get("dat_empty_file_skipped_count", 0)),
            "- dat_pre_qa_terminal_result_count: `{0}`".format(selector.get("dat_pre_qa_terminal_result_count", 0)),
            "- dat_selected_count: `{0}`".format(selector.get("dat_selected_count", 0)),
            "- reproduction_report: `{0}`".format(selector.get("report_path") or ""),
            "",
        ])
    current_selector = result.get("phase_d_selector_residue")
    if isinstance(current_selector, dict) and current_selector.get("present"):
        lines.extend([
            "## Phase D Selector Residue",
            "- present: `True`",
            "- selector_residue_class: `{0}`".format(current_selector.get("selector_residue_class") or ""),
            "- rows_selected: `{0}`".format(current_selector.get("rows_selected", 0)),
            "- dat_pre_qa_terminal_result_count: `{0}`".format(
                current_selector.get("dat_pre_qa_terminal_result_count", 0)),
            "- dat_empty_file_skipped_count: `{0}`".format(current_selector.get("dat_empty_file_skipped_count", 0)),
            "- dat_selected_count: `{0}`".format(current_selector.get("dat_selected_count", 0)),
            "- recommended_developer_action: `{0}`".format(current_selector.get("recommended_developer_action") or ""),
            "",
        ])
    alias_probe = result.get("dat_financial_alias_probe")
    if isinstance(alias_probe, dict) and alias_probe:
        lines.extend([
            "## DAT Financial Alias Probe",
            "- status: `{0}`".format(alias_probe.get("status") or ""),
            "- probe_contract: `{0}`".format(alias_probe.get("probe_contract") or ""),
            "- dat_cpt_present_count: `{0}`".format(alias_probe.get("dat_cpt_present_count", 0)),
            "- dat_anesthesia_minutes_present_count: `{0}`".format(
                alias_probe.get("dat_anesthesia_minutes_present_count", 0)),
            "- dat_charged_amount_present_count: `{0}`".format(alias_probe.get("dat_charged_amount_present_count", 0)),
            "- csv_keys_with_dat_complete_financial_count: `{0}`".format(
                alias_probe.get("csv_keys_with_dat_complete_financial_count", 0)),
            "- report_path: `{0}`".format(alias_probe.get("report_path") or ""),
            "",
        ])
    if forecast:
        lines.extend([
            "## Scenario Forecast",
            "- primary_scenario: `{0}`".format(forecast.get("primary_scenario") or ""),
            "- resolution_class: `{0}`".format(forecast.get("resolution_class") or ""),
            "- next_step: `{0}`".format(forecast.get("next_step") or ""),
            "- confidence: `{0}`".format(forecast.get("confidence") or ""),
            "- operator_state: `{0}`".format(forecast.get("operator_state") or ""),
            "- app_state: `{0}`".format(forecast.get("app_state") or ""),
            "- recomputed_action_kind: `{0}`".format(forecast.get("recomputed_action_kind") or ""),
        ])
        scenario_line = _format_scenarios_compact(forecast)
        if scenario_line:
            lines.append("- scenarios: `{0}`".format(scenario_line))
        blockers = forecast.get("blockers") or []
        if blockers:
            lines.append("- blockers: `{0}`".format("; ".join(blockers)))
        lines.append("")
    warnings = result.get("coherence_warnings") or []
    missing = result.get("missing_required_evidence") or []
    if warnings:
        lines.append("## Coherence Warnings")
        lines.extend(["- `{0}`".format(w) for w in warnings])
        lines.append("")
    if missing:
        lines.append("## Missing Required Evidence")
        for row in missing:
            if isinstance(row, dict):
                lines.append("- `{0}` reason=`{1}`".format(row.get("archive_name") or row.get("expected_path") or "", row.get("reason_code") or ""))
            else:
                lines.append("- `{0}`".format(row))
        lines.append("")
    return "\n".join(lines)


def render_summary_markdown(summary):
    lines = [
        "# XP Bundle Replay Summary",
        "",
        "- generated_at_utc: `{0}`".format(summary.get("generated_at_utc") or ""),
        "- input_path: `{0}`".format(summary.get("input_path") or ""),
        "- output_dir: `{0}`".format(summary.get("output_dir") or ""),
        "- bundle_count: `{0}`".format(len(summary.get("bundles") or [])),
        "",
        "## Bundles",
    ]
    for row in summary.get("bundles") or []:
        counts = row.get("phase_d_dat_counts") or {}
        followup = row.get("followup_phase_d") if isinstance(row.get("followup_phase_d"), dict) else {}
        boundary = row.get("workflow_boundary") if isinstance(row.get("workflow_boundary"), dict) else {}
        forecast = row.get("scenario_forecast") if isinstance(row.get("scenario_forecast"), dict) else {}
        followup_piece = "none"
        if followup:
            followup_piece = "{0}:{1}/{2}/{3}/{4},accepted={5}".format(
                followup.get("followup_phase_d_run_id") or "",
                followup.get("selected_count", 0),
                followup.get("qa_pass_count", 0),
                followup.get("qa_reject_count", 0),
                followup.get("canonical_count", 0),
                bool(followup.get("accepted_as_reviewed_anchor_milestone")),
            )
        lines.append(
            "- `{0}` anchor=`{1}` coherence=`{2}` workflow_boundary=`{3}` scenario=`{4}` class=`{5}` smoke=`{6}` milestone=`{7}` DAT selected/pass/canonical/v2=`{8}/{9}/{10}/{11}` followup_phase_d=`{12}` report=`{13}`".format(
                row.get("bundle_name") or "",
                row.get("anchor_run_id") or "",
                row.get("coherence_status") or "",
                boundary.get("status") or "",
                forecast.get("primary_scenario") or "",
                forecast.get("resolution_class") or "",
                (row.get("smoke") or {}).get("verdict", ""),
                row.get("milestone_verdict") or "",
                counts.get("selected", 0),
                counts.get("qa_pass", 0),
                counts.get("canonical", 0),
                counts.get("v2_inserted", 0),
                followup_piece,
                row.get("replay_markdown_path") or "",
            )
        )
    lines.append("")
    cohort = summary.get("cohort")
    if isinstance(cohort, dict) and cohort:
        forecast = cohort.get("scenario_forecast") if isinstance(cohort.get("scenario_forecast"), dict) else {}
        boundary = cohort.get("workflow_boundary") if isinstance(cohort.get("workflow_boundary"), dict) else {}
        counts = cohort.get("phase_d_dat_counts") or {}
        lines.extend([
            "## Cohort Machine-State Replay",
            "- workflow_boundary: `{0}` findings=`{1}`".format(
                boundary.get("status") or "",
                ",".join(boundary.get("findings") or [])),
            "- scenario_forecast: primary=`{0}` class=`{1}` next_step=`{2}` confidence=`{3}`".format(
                forecast.get("primary_scenario") or "",
                forecast.get("resolution_class") or "",
                forecast.get("next_step") or "",
                forecast.get("confidence") or ""),
            "- scenarios: `{0}`".format(_format_scenarios_compact(forecast)),
            "- recomputed_action_kind: `{0}`".format(forecast.get("recomputed_action_kind") or ""),
            "- milestone: `{0}` DAT selected/pass/canonical/v2=`{1}/{2}/{3}/{4}` report=`{5}`".format(
                cohort.get("milestone_verdict") or "",
                counts.get("selected", 0),
                counts.get("qa_pass", 0),
                counts.get("canonical", 0),
                counts.get("v2_inserted", 0),
                cohort.get("replay_markdown_path") or ""),
            "",
        ])
    matrix = summary.get("scenario_matrix")
    if isinstance(matrix, dict) and matrix:
        lines.extend([
            "## Scenario Matrix",
            "- matrix_json: `{0}`".format(matrix.get("scenario_matrix_json_path") or ""),
            "- matrix_markdown: `{0}`".format(matrix.get("scenario_matrix_markdown_path") or ""),
        ])
        for row in matrix.get("scenarios") or []:
            if not isinstance(row, dict):
                continue
            forecast = row.get("scenario_forecast") if isinstance(row.get("scenario_forecast"), dict) else {}
            readiness = row.get("next_xp_defect_telemetry_readiness") if isinstance(row.get("next_xp_defect_telemetry_readiness"), dict) else {}
            selector = row.get("selector_residue_reproduction") if isinstance(row.get("selector_residue_reproduction"), dict) else {}
            alias_probe = row.get("dat_financial_alias_probe") if isinstance(row.get("dat_financial_alias_probe"), dict) else {}
            lines.append(
                "- `{0}` recomputed_action=`{1}` scenario=`{2}` next_step=`{3}` milestone=`{4}` telemetry=`{5}`".format(
                    row.get("name") or "",
                    forecast.get("recomputed_action_kind") or "",
                    forecast.get("primary_scenario") or "",
                    forecast.get("next_step") or "",
                    row.get("milestone_verdict") or "",
                    selector.get("status") or alias_probe.get("status") or readiness.get("status") or "",
                )
            )
        lines.append("")
    return "\n".join(lines)


def render_codex_handoff(summary):
    lines = [
        "# Codex XP Bundle Review Handoff",
        "",
        "Use the replay reports and original bundle paths below to review the XP evidence bundle with a code-review mindset.",
        "",
        "Do not browse the internet. Do not treat docs alone, smoke auto-run, cumulative totals, or packaging quality as Phase D milestone closure. Accept one pipeline anchor run_id plus distinct B/C/D/E run_ids only when the mapping is internally coherent.",
        "",
        "Workflow-boundary check: review each helper, smoke, replay, diagnostic, and bundle as a stateful operation with a target identity, request/attempt state, terminal outcome, artifacts, packaging, and recommendation surface. Do not let a downstream recommendation, successful package build, newest file, or non-empty path stand in for the missing parts of that contract; classify stale, partial, mismatched, in-flight, ignored, and terminal states separately.",
        "",
        "Local harness check: inspect each bundle's `workflow_boundary` block. A status of `local_code_regression` means the current dev code still reproduces a bad recommendation/action boundary against the hydrated XP lab. A status of `review_required` means the returned bundle captured a stale, burdensome, partial, or poorly surfaced workflow even if current dev code now behaves differently.",
        "",
        "Required sections for the review:",
        "1. Findings",
        "2. Open questions / assumptions",
        "3. Smoke verdict: `Did not run`, `Ran but inconclusive`, `Ran and produced truthful diagnosis`, or `Ran and showed DAT-bearing breakthrough`",
        "4. Recommendation / provenance verdict: `Not trustworthy yet`, `Improved but still leaky`, or `Trustworthy for anchored review`",
        "5. Milestone verdict: `Not advanced`, `Partially advanced`, or `Milestone-ready evidence`",
        "6. Recommended next step",
        "",
        "Aggregate replay summary:",
        "- JSON: `{0}`".format(summary.get("summary_json_path") or ""),
        "- Markdown: `{0}`".format(summary.get("summary_markdown_path") or ""),
        "",
    ]
    cohort = summary.get("cohort")
    if isinstance(cohort, dict) and cohort:
        forecast = cohort.get("scenario_forecast") if isinstance(cohort.get("scenario_forecast"), dict) else {}
        boundary = cohort.get("workflow_boundary") if isinstance(cohort.get("workflow_boundary"), dict) else {}
        lines.extend([
            "Cohort machine-state replay:",
            "- replay_json: `{0}`".format(cohort.get("replay_json_path") or ""),
            "- replay_markdown: `{0}`".format(cohort.get("replay_markdown_path") or ""),
            "- workflow_boundary_status: `{0}`".format(boundary.get("status") or ""),
            "- workflow_boundary_findings: `{0}`".format(",".join(boundary.get("findings") or [])),
            "- scenario_forecast: primary=`{0}` class=`{1}` next_step=`{2}` confidence=`{3}`".format(
                forecast.get("primary_scenario") or "",
                forecast.get("resolution_class") or "",
                forecast.get("next_step") or "",
                forecast.get("confidence") or ""),
            "- scenarios: `{0}`".format(_format_scenarios_compact(forecast)),
            "- local_recomputed_action: `{0}`".format(forecast.get("recomputed_action_kind") or ""),
            "",
        ])
    matrix = summary.get("scenario_matrix")
    if isinstance(matrix, dict) and matrix:
        lines.extend([
            "Scenario matrix:",
            "- matrix_json: `{0}`".format(matrix.get("scenario_matrix_json_path") or ""),
            "- matrix_markdown: `{0}`".format(matrix.get("scenario_matrix_markdown_path") or ""),
            "",
        ])
    lines.append("Bundles to review:")
    for row in summary.get("bundles") or []:
        lines.extend([
            "",
            "## {0}".format(row.get("bundle_name") or ""),
            "- original_bundle_dir: `{0}`".format(row.get("bundle_dir") or ""),
            "- replay_json: `{0}`".format(row.get("replay_json_path") or ""),
            "- replay_markdown: `{0}`".format(row.get("replay_markdown_path") or ""),
            "- anchor_run_id: `{0}`".format(row.get("anchor_run_id") or ""),
            "- phase_run_id_map: `{0}`".format(json.dumps(row.get("phase_run_id_map") or {}, sort_keys=True)),
            "- qa_canonical_summary_path: `{0}`".format(row.get("qa_canonical_summary_path") or ""),
            "- shadow_run_report_path: `{0}`".format(row.get("shadow_run_report_path") or ""),
            "- smoke_verdict: `{0}`".format((row.get("smoke") or {}).get("verdict", "")),
            "- milestone_verdict: `{0}`".format(row.get("milestone_verdict") or ""),
        ])
        followup = row.get("followup_phase_d") if isinstance(row.get("followup_phase_d"), dict) else {}
        if followup:
            lines.extend([
                "- followup_phase_d_run_id: `{0}`".format(followup.get("followup_phase_d_run_id") or ""),
                "- followup_phase_d_counts: selected=`{0}` qa_pass=`{1}` qa_reject=`{2}` canonical=`{3}` accepted_as_reviewed_anchor_milestone=`{4}`".format(
                    followup.get("selected_count", 0),
                    followup.get("qa_pass_count", 0),
                    followup.get("qa_reject_count", 0),
                    followup.get("canonical_count", 0),
                    bool(followup.get("accepted_as_reviewed_anchor_milestone"))),
                "- followup_phase_d_note: `{0}`".format(followup.get("note_path") or ""),
            ])
        boundary = row.get("workflow_boundary") if isinstance(row.get("workflow_boundary"), dict) else {}
        if boundary:
            rec = boundary.get("recomputed_recommendation") if isinstance(boundary.get("recomputed_recommendation"), dict) else {}
            lines.extend([
                "- workflow_boundary_status: `{0}`".format(boundary.get("status") or ""),
                "- workflow_boundary_findings: `{0}`".format(",".join(boundary.get("findings") or [])),
                "- local_recomputed_action: `{0}` confirmation=`{1}` historical_available=`{2}`".format(
                    rec.get("recommended_action_kind") or "",
                    bool(rec.get("action_requires_confirmation")),
                    bool(rec.get("historical_reprocess_available"))),
            ])
        forecast = row.get("scenario_forecast") if isinstance(row.get("scenario_forecast"), dict) else {}
        if forecast:
            lines.extend([
                "- scenario_forecast: primary=`{0}` class=`{1}` next_step=`{2}`".format(
                    forecast.get("primary_scenario") or "",
                    forecast.get("resolution_class") or "",
                    forecast.get("next_step") or ""),
                "- scenarios: `{0}`".format(_format_scenarios_compact(forecast)),
            ])
    lines.append("")
    return "\n".join(lines)


def build_summary(input_path, out_dir, bundle_results, cohort_result=None):
    summary_json = os.path.abspath(os.path.join(out_dir, "replay_summary.json"))
    summary_md = os.path.abspath(os.path.join(out_dir, "replay_summary.md"))
    handoff = os.path.abspath(os.path.join(out_dir, "codex_handoff_prompt.md"))
    summary = {
        "schema_version": "xp_bundle_replay_summary_v1",
        "generated_at_utc": _utc_now(),
        "input_path": os.path.abspath(input_path),
        "output_dir": os.path.abspath(out_dir),
        "summary_json_path": summary_json,
        "summary_markdown_path": summary_md,
        "codex_handoff_prompt_path": handoff,
        "bundles": bundle_results,
    }
    if isinstance(cohort_result, dict) and cohort_result:
        summary["cohort"] = cohort_result
    _write_json(summary_json, summary)
    _write_text(summary_md, render_summary_markdown(summary))
    _write_text(handoff, render_codex_handoff(summary))
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_path_pos", nargs="?", help="Bundle ZIP, bundle directory, or parent bundle directory.")
    parser.add_argument("--input", dest="input_path", help="Bundle ZIP, bundle directory, or parent bundle directory.")
    parser.add_argument("--out-dir", help="Output directory for replay reports.")
    parser.add_argument("--keep-labs", action="store_true", help="Keep hydrated scratch lab directories under the output folder.")
    parser.add_argument("--scenario-matrix", action="store_true", help="Run a local what-if matrix from the hydrated cohort lab.")
    args = parser.parse_args(argv)

    repo = _repo_root()
    input_path = args.input_path or args.input_path_pos or os.path.join(repo, "input", "test", "test")
    out_dir = args.out_dir or os.path.join(repo, "input", "test", "replay_reports", _timestamp())
    out_dir = os.path.abspath(out_dir)
    _mkdir(out_dir)

    scratch_root = tempfile.mkdtemp(prefix="mc_xp_replay_")
    try:
        bundles = discover_bundle_sources(input_path, scratch_root)
        results = []
        for bundle in bundles:
            results.append(replay_bundle(bundle, out_dir, keep_labs=args.keep_labs))
        cohort_bundles = [b for b in bundles if not _is_review_only_analytics_bundle_dir(b)]
        cohort_result = replay_cohort(cohort_bundles, out_dir, keep_labs=args.keep_labs) if len(cohort_bundles) > 1 else {}
        if isinstance(cohort_result, dict) and cohort_result:
            cohort_result["review_only_bundle_count"] = len(bundles) - len(cohort_bundles)
        summary = build_summary(input_path, out_dir, results, cohort_result=cohort_result)
        scenario_matrix = build_scenario_matrix(input_path, out_dir, bundles) if args.scenario_matrix and bundles else {}
        if scenario_matrix:
            summary["scenario_matrix"] = scenario_matrix
            _write_json(summary.get("summary_json_path"), summary)
            _write_text(summary.get("summary_markdown_path"), render_summary_markdown(summary))
            _write_text(summary.get("codex_handoff_prompt_path"), render_codex_handoff(summary))
    finally:
        shutil.rmtree(scratch_root, ignore_errors=True)

    print("XP bundle replay complete.")
    print("bundles={0}".format(len(summary.get("bundles") or [])))
    print("summary_json={0}".format(summary.get("summary_json_path") or ""))
    print("summary_markdown={0}".format(summary.get("summary_markdown_path") or ""))
    print("codex_handoff_prompt={0}".format(summary.get("codex_handoff_prompt_path") or ""))
    if isinstance(summary.get("cohort"), dict):
        print("cohort_replay_json={0}".format(summary.get("cohort", {}).get("replay_json_path") or ""))
    if isinstance(summary.get("scenario_matrix"), dict) and summary.get("scenario_matrix"):
        print("scenario_matrix_json={0}".format(summary.get("scenario_matrix", {}).get("scenario_matrix_json_path") or ""))
        print("scenario_matrix_markdown={0}".format(summary.get("scenario_matrix", {}).get("scenario_matrix_markdown_path") or ""))
    if not summary.get("bundles"):
        print("No bundle directories were found under: {0}".format(os.path.abspath(input_path)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
