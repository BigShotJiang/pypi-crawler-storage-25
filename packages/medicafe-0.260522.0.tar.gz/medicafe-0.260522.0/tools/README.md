# Repository Tools

This folder contains auxiliary helper scripts that support cloud setup, auth checks, build validation, updater work, and focused experiments. These scripts are not the primary runtime path for MediCafe itself.

The canonical operator path for the cloud runtime remains:

```powershell
py -3.11 cloud/orchestrator/validate_and_complete_setup.py
```

## Current Tool Groups

### Auth and Gmail/GCP helpers

- `gmail_watch_bootstrap.py`
- `adc_check.py`
- `adc_file_check.py`
- `get_gmail_oauth_token.ps1`
- `verify_keyless_dwd.ps1`

### Build and updater helpers

- `copy_update_script.py`
- `prebuild_validation.py`
- `postbuild_validation.py`
- `verify_updater_fixes.py`
- `build_colors.py`

### Focused migration or one-off support scripts

- `replace_medilink_api_v3.py`
- `demo_humana_aetna_table.py`

### Local tool dependencies

- `requirements.txt`

### Repo audit (deterministic chore checks)

- Entry point: `repo_audit.py` (adds `tools/` to `sys.path` and runs the `repo_audit` package).
- Tiers: `--tier fast` (default), `weekly`, `monthly`, or `all`. Use `--strict` to fail on warnings.
- Canonical modern-install package names: `repo_audit/modern_install.txt` (referenced from `AGENTS.md`).
- CI: `.github/workflows/repo-audit.yml` (PR / main / manual), plus `repo-audit-weekly.yml` and `repo-audit-monthly.yml` for schedules.
- Dependency triage should use shared dependency pin coordination across `cloud/orchestrator/requirements.txt`, `tools/requirements.txt`, shared auth/Google packages, and `repo_audit/modern_install.txt` before recommending isolated upgrade slices.
- Weekly maintainability hotspot review: `repo_audit` check `dry_inelegance_hotspots` plus `CODEX_DRY_SCAN_AUTOMATION.md`.

### Workflow-boundary coverage scan

- Entry point: `scan_workflow_boundary_coverage.py`.
- Purpose: find likely stateful workflow boundaries where code has request/attempt/outcome/artifact/operator wording surfaces, but nearby feature tests do not consume `tests/workflow_boundary_contract.py`.
- The scan has a specific structural check for preserved context plus mutable evidence: snapshots, frozen recommendations, queued/deferred requests, or cached intent that later get combined with live/current/latest state, artifacts, attachments, packaging, recommendations, or operator text.
- Bundle reviewers should treat each manifest attachment row as a workflow-boundary surface. In particular, `latest` diagnostic/support artifacts need same-target acceptance, live/follow-up scope, or explicit ignored/mismatch handling.
- On-demand Codex workflow-boundary prompt: `CODEX_WORKFLOW_BOUNDARY_SCAN_AUTOMATION.md`.
- Human-readable scan:

```powershell
py -3.11 tools/scan_workflow_boundary_coverage.py --limit 15
```

- Machine-readable scan:

```powershell
py -3.11 tools/scan_workflow_boundary_coverage.py --format json --limit 30
```

- Optional gating mode for focused review branches:

```powershell
py -3.11 tools/scan_workflow_boundary_coverage.py --fail-on-missing-contract
```

Treat the output as a candidate list. The expected follow-up is to inspect the cited code path and add a feature-level test that imports `assert_workflow_boundary_clean`, not just another self-test for the helper.

### Codex change-surface and adversarial review prompts

- Build-time scaffold: `CODEX_CHANGE_SURFACE_CONTROL_AUTOMATION.md`
- Review-time pressure test: `CODEX_ADVERSARIAL_REVIEW_AUTOMATION.md`
- Scaffolding coherence review: `CODEX_SCAFFOLDING_COHERENCE_REVIEW.md`
- Canonical repo guidance: `../docs/CHANGE_SURFACE_CONTROL.md`

Use the build-time prompt at feature start to declare surfaces and choose a canonical helper. Use the adversarial prompt before merge to mutate nearby valid or stale shapes and verify no surface lies about completion or same-target identity.
Use the scaffolding coherence prompt when changing agent guidance, Codex automation docs, review checklists, installable skills, or other review-system scaffolding.

## Usage Guidance

- Prefer the package CLI and `cloud/orchestrator/` validator flow for normal operations.
- Use scripts in this folder when you specifically need helper behavior that is not part of the packaged runtime.
- Prune or archive obsolete helpers instead of letting this folder become a second unofficial runtime surface.
