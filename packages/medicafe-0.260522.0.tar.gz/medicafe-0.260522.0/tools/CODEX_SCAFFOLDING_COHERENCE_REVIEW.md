# Codex Scaffolding Coherence Review

Use this prompt when changing agent guidance, Codex automation docs, review
checklists, SKILL files, or workflow-boundary scaffolding. This is a review of
the review system: it checks whether future agents will receive one coherent
set of instructions after the change.

Do not use this as a substitute for normal feature review. For runtime workflow
changes, use `docs/CHANGE_SURFACE_CONTROL.md`,
`tools/CODEX_CHANGE_SURFACE_CONTROL_AUTOMATION.md`, and
`tools/CODEX_ADVERSARIAL_REVIEW_AUTOMATION.md`.

## Trigger surfaces

Run this review for changes to:

- `AGENTS.md`
- `docs/CODEX_DISCOVERY_AUTOMATION_PLAN.md`
- `docs/CHANGE_SURFACE_CONTROL.md`
- `docs/PR_REVIEW_CHECKLIST.md`
- `tools/CODEX_*_AUTOMATION.md`
- local or installable `SKILL.md` files
- Codex automation names, prompts, cadence, or scope

## Suggested prompt body

```text
Run a MediCafe scaffolding coherence review for this guidance/scaffolding change.

1. Identify the canonical guidance source for the changed behavior.
2. Build a propagation map of related docs, prompts, skills, and automations that must stay aligned.
3. Classify the affected review behavior:
   - workflow-boundary review
   - change-surface control
   - daily main-change risk review
   - maintainability hotspot review
   - dependency upgrade triage
   - skill triggering/discovery
   - other repo guidance
4. Check boundary impact. State whether the guidance change affects parsing, state/cursor, artifacts, bundles, recommendations, launcher flow, support-send, diagnostics, artifact lookup, XP packaging, dependency/release automation, or none.
5. State the agent behavior delta: what should a future Codex agent do differently after this change?
6. Check for duplicate, stale, or competing instructions. Identify names, prompts, docs, skills, or automations that should be retired or marked superseded.
7. If the change touches GitHub Actions, repo-audit behavior, or automation boundaries, apply the CI efficiency change checklist in `docs/CODEX_DISCOVERY_AUTOMATION_PLAN.md`.
8. Acceptance check: can a future agent choose the right workflow without asking the user?
9. Return concrete findings or a clean result. Do not edit files unless explicitly asked to implement the review findings.
```

## Output contract

Return these sections:

- `Canonical source`: the doc, prompt, skill, or automation that owns the behavior.
- `Propagation map`: related surfaces that must match.
- `Boundary impact`: affected workflow-boundary or runtime-track concerns.
- `Agent behavior delta`: the intended change in future Codex behavior.
- `Duplication/conflict check`: stale or competing guidance.
- `Retirement check`: old names, prompts, skills, or automation records to remove.
- `CI efficiency check`: trigger paths, permissions, timeouts, dependency install surface, local-vs-CI differences, and Actions-vs-Codex boundary when applicable.
- `Acceptance check`: whether a future agent can pick the right workflow without asking.

## Completion bar

The review is not complete until it names the canonical source and either:

- confirms every related guidance surface is aligned, or
- lists the exact stale/competing surfaces that must be updated or retired.
