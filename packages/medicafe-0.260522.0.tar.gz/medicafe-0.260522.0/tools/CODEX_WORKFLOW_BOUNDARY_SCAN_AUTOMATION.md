# Codex Workflow Boundary Scan Automation

Use this prompt for a focused agent run when bundle evidence, helper diagnostics,
background jobs, recommendations, or operator wording changed.

```text
Apply the workflow-boundary-review skill to this repository.

Run:
py -3.11 tools/scan_workflow_boundary_coverage.py --format json --limit 30

For each high-risk finding touching bundles, manifests, diagnostic attempts,
support-send status, run evidence, launcher follow-through, or recommendations:
1. Identify the target identity that must remain authoritative.
2. Identify any mutable latest/live/current artifacts consumed after that identity is selected.
3. Add or update a feature-level test that imports tests/workflow_boundary_contract.py.
4. Model every attachment row as a workflow-boundary surface when packaging is involved:
   archive_name, source_path, payload target identity, manifest run_id, scope,
   source_kind, freshness, accepted flag, and downstream wording.
5. Patch production code so wrong-target latest/live helper artifacts are omitted or
   explicitly marked ignored_mismatch, followup_only, or live_support_queue_status.
6. Re-run the scanner and the focused tests for the patched feature.

For evidence attachments and bundle manifests, also apply the Evidence Freshness
And Attachment Contract in `docs/PR_REVIEW_CHECKLIST.md`: every row should be
classified as accepted current evidence, stale, follow-up-only, ignored,
mismatched, running, or fail-closed before wording implies completion.

Do not count a helper self-test as integration. The answer is "not integrated yet"
until a production feature test consumes assert_workflow_boundary_clean.
```
