import re
from pathlib import Path
from typing import Optional
from .scanNameFiles import identify_file_type


def find_latest_file(folder_path: str, file_type: str) -> Optional[str]:
    """
    Busca el archivo más actual de un tipo específico en una carpeta.

    Args:
        folder_path: Ruta de la carpeta a buscar
        file_type: Tipo de archivo ("ZJ", "MANPOWER_BUDGET", "MANPOWER_DOCUMENTS", "MANPOWER", "REAL_TIME_PRODUCTION")

    Returns:
        str: Ruta del archivo más actual, None si no encuentra archivos del tipo especificado
    """
    folder = Path(folder_path)

    if not folder.is_dir():
        raise ValueError(f"La ruta '{folder_path}' no es una carpeta válida")

    # Obtener archivos del tipo especificado
    matching_files = []
    for file_path in folder.iterdir():
        if file_path.is_file():
            detected_type = identify_file_type(file_path.name)
            if detected_type == file_type:
                matching_files.append(file_path)

    if not matching_files:
        return None

    if len(matching_files) == 1:
        return str(matching_files[0])

    # Múltiples archivos: retornar el más actual según el tipo
    if file_type == "ZJ":
        return str(_find_latest_zj(matching_files))
    elif file_type == "MANPOWER_BUDGET":
        return str(_find_latest_manpower_budget(matching_files))
    elif file_type == "MANPOWER_DOCUMENTS":
        return str(_find_latest_manpower_documents(matching_files))
    elif file_type == "MANPOWER":
        return str(_find_latest_manpower(matching_files))
    elif file_type == "REAL_TIME_PRODUCTION":
        return str(matching_files[0])
    else:
        return str(matching_files[0])


def _find_latest_zj(files: list) -> Path:
    """
    Encuentra el ZJ más actual basado en fecha y versión.
    Formato: ZJ{YYMMDD}{DD}-{version}[(N)]
    """

    def parse_zj(filename: str) -> tuple:
        match = re.search(r'ZJ(\d{6})(\d{2})-(\d+)(?:\s\((\d+)\))?', filename.upper())
        if match:
            date = int(match.group(1))  # YYMMDD
            version_prefix = int(match.group(2))  # DD
            version_number = int(match.group(3))  # Número de versión
            duplicate_number = int(match.group(4)) if match.group(4) else 0
            return (date, version_number, version_prefix, duplicate_number)
        return (0, 0, 0, 0)

    return max(files, key=lambda f: parse_zj(f.name))


def _find_latest_manpower_budget(files: list) -> Path:
    """
    Encuentra el Manpower Budget más actual basado en versión y mes.
    Prioriza versión, luego mes.
    Busca patrones como: "Rev 18.1", "April", etc.
    """

    def parse_budget(filename: str) -> tuple:
        # Extraer versión (Rev X.X o similar)
        version_match = re.search(r'(?:Rev|rev|Version|version)\s+(\d+)(?:\.(\d+))?', filename)
        version_major = 0
        version_minor = 0
        if version_match:
            version_major = int(version_match.group(1))
            version_minor = int(version_match.group(2)) if version_match.group(2) else 0

        # Extraer mes si existe (menor prioridad que versión)
        months = {
            "january": 1, "february": 2, "march": 3, "april": 4,
            "may": 5, "june": 6, "july": 7, "august": 8,
            "september": 9, "october": 10, "november": 11, "december": 12
        }
        month = 0
        for month_name, month_num in months.items():
            if month_name in filename.lower():
                month = month_num
                break

        # Retornar con versión primero, luego mes
        return (version_major, version_minor, month)

    return max(files, key=lambda f: parse_budget(f.name))


def _find_latest_manpower_documents(files: list) -> Path:
    """
    Encuentra el Manpower Documents más actual basado en mes/año.
    Busca patrones como: "Q1 2026", "April 2026", etc.
    """

    def parse_documents(filename: str) -> tuple:
        # Extraer año si existe
        year_match = re.search(r'(\d{4})', filename)
        year = int(year_match.group(1)) if year_match else 0

        # Extraer mes si existe
        months = {
            "january": 1, "february": 2, "march": 3, "april": 4,
            "may": 5, "june": 6, "july": 7, "august": 8,
            "september": 9, "october": 10, "november": 11, "december": 12
        }
        month = 0
        for month_name, month_num in months.items():
            if month_name in filename.lower():
                month = month_num
                break

        # Extraer Q (Trimestre) si existe
        quarter_match = re.search(r'Q(\d)', filename.upper())
        quarter = int(quarter_match.group(1)) if quarter_match else 0

        return (year, month, quarter)

    return max(files, key=lambda f: parse_documents(f.name))


def _find_latest_manpower(files: list) -> Path:
    """
    Encuentra el Manpower más actual basado en fecha (Month_Day).
    Busca patrones como: "April_29", "March_28", etc.
    """

    def parse_manpower_date(filename: str) -> tuple:
        months = {
            "january": 1, "february": 2, "march": 3, "april": 4,
            "may": 5, "june": 6, "july": 7, "august": 8,
            "september": 9, "october": 10, "november": 11, "december": 12
        }

        month = 0
        day = 0

        # Buscar mes
        for month_name, month_num in months.items():
            if month_name in filename.lower():
                month = month_num
                # Buscar día después del mes
                day_match = re.search(rf'{month_name}[_\s](\d{{1,2}})', filename.lower())
                if day_match:
                    day = int(day_match.group(1))
                break

        return (month, day)

    return max(files, key=lambda f: parse_manpower_date(f.name))
