"""Document Processing Hub - File type identification and validation."""

from .scanNameFiles import identify_file_type, get_file_info
from .validators import (
    validate_zj_format,
    validate_manpower_budget,
    validate_manpower_documents,
    classify_manpower_type,
)
from .fileSelector import find_latest_file

__version__ = "0.2.0"
__all__ = [
    "identify_file_type",
    "get_file_info",
    "validate_zj_format",
    "validate_manpower_budget",
    "validate_manpower_documents",
    "classify_manpower_type",
    "find_latest_file",
]
