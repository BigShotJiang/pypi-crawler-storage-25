import re


def validate_zj_format(file_name: str) -> bool:
    """
    Valida que el archivo ZJ cumple con el formato: ZJ{YYMMDD}{DD}-{version}
    Ejemplo: ZJ26042804-8170 = ZJ + 260428 (fecha) + 04 (inicio versión) + 8170 (versión)
    La versión debe ser solo números después del guion.
    Soporta sufijos como (1), (2) para archivos duplicados.

    Args:
        file_name: Nombre del archivo en mayúsculas

    Returns:
        bool: True si cumple el formato, False en caso contrario
    """
    pattern = r'^ZJ\d{8}-\d+(\s\(\d+\))?(\.\w+)?$'
    return bool(re.match(pattern, file_name))


def validate_manpower_budget(file_name: str) -> bool:
    """
    Valida que el archivo sea de tipo Manpower Budget.

    Args:
        file_name: Nombre del archivo en mayúsculas

    Returns:
        bool: True si contiene 'BUDGET', False en caso contrario
    """
    return "BUDGET" in file_name


def validate_manpower_documents(file_name: str) -> bool:
    """
    Valida que el archivo sea de tipo Manpower Documents.

    Args:
        file_name: Nombre del archivo en mayúsculas

    Returns:
        bool: True si contiene 'DOCUMENTS', False en caso contrario
    """
    return "DOCUMENTS" in file_name


def classify_manpower_type(file_name: str) -> str:
    """
    Clasifica el tipo específico de archivo Manpower.

    Args:
        file_name: Nombre del archivo en mayúsculas

    Returns:
        str: Tipo de Manpower ("MANPOWER_BUDGET", "MANPOWER_DOCUMENTS" o "MANPOWER")
    """
    if "BUDGET" in file_name:
        return "MANPOWER_BUDGET"
    elif "DOCUMENTS" in file_name:
        return "MANPOWER_DOCUMENTS"
    else:
        return "MANPOWER"
