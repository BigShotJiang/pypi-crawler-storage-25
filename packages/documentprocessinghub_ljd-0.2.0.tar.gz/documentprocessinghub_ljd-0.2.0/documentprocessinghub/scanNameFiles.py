import os
from pathlib import Path
from .validators import validate_zj_format, classify_manpower_type


def identify_file_type(file_path: str) -> str:
    """
    Identifica el tipo de archivo basándose en su nombre.

    Args:
        file_path: Ruta completa o nombre del archivo

    Returns:
        str: Tipo de archivo identificado o "archivo no conocido"
    """
    file_name = Path(file_path).name.upper()

    match file_name:
        # Manpower files - subcategorize by keywords
        case _ if "MANPOWER" in file_name:
            return classify_manpower_type(file_name)

        # ZJ - valida formato completo
        case _ if file_name.startswith("ZJ"):
            if validate_zj_format(file_name):
                return "ZJ"
            else:
                return "ZJ_NO_CLASIFICADO_FALTA_DE_DATOS"

        # Real-time production
        case _ if "REAL-TIME" in file_name and "PRODUCTION" in file_name:
            return "REAL_TIME_PRODUCTION"

        # Archivo no reconocido
        case _:
            return "ARCHIVO_NO_CONOCIDO"


def get_file_info(file_path: str) -> dict:
    """
    Obtiene información detallada del archivo incluyendo su tipo.

    Args:
        file_path: Ruta completa o nombre del archivo

    Returns:
        dict: Diccionario con información del archivo
    """
    file_name = Path(file_path).name
    file_type = identify_file_type(file_path)

    return {
        "file_name": file_name,
        "file_type": file_type,
        "recognized": file_type != "ARCHIVO_NO_CONOCIDO"
    }
