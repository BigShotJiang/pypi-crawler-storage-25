import sys
import io
import tempfile
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

from documentprocessinghub import find_latest_file

print("=" * 70)
print("PRUEBA DE FILE SELECTOR - find_latest_file()")
print("=" * 70)

# Crear carpeta temporal con archivos de prueba
with tempfile.TemporaryDirectory() as tmpdir:
    tmpdir_path = Path(tmpdir)

    # Test 1: ZJ Format - Elegir el mas reciente por fecha
    print("\n1. ZJ Format - Archivo mas reciente por fecha:")
    zj_files = [
        "ZJ26042912-8102.xlsx",
        "ZJ26042912-8105.xlsx",
        "ZJ26042822-8005.xlsx",
        "ZJ26042615-6102.xlsx",
    ]
    for f in zj_files:
        (tmpdir_path / f).touch()

    result = find_latest_file(tmpdir, "ZJ")
    filename = Path(result).name if result else None
    print(f"   Archivos: {zj_files}")
    print(f"   Resultado: {filename}")
    print(f"   Esperado: ZJ26042912-8105.xlsx")
    print(f"   Estado: [{'PASS' if filename == 'ZJ26042912-8105.xlsx' else 'FAIL'}]\n")

    # Limpiar
    for f in zj_files:
        (tmpdir_path / f).unlink()

    # Test 2: ZJ Format - Elegir con duplicados (N)
    print("2. ZJ Format - Con duplicados, elegir el numero mas alto:")
    zj_dup_files = [
        "ZJ26042912-8105 (1).xlsx",
        "ZJ26042912-8105 (3).xlsx",
        "ZJ26042912-8105 (4).xlsx",
    ]
    for f in zj_dup_files:
        (tmpdir_path / f).touch()

    result = find_latest_file(tmpdir, "ZJ")
    filename = Path(result).name if result else None
    print(f"   Archivos: {zj_dup_files}")
    print(f"   Resultado: {filename}")
    print(f"   Esperado: ZJ26042912-8105 (4).xlsx")
    print(f"   Estado: [{'PASS' if filename == 'ZJ26042912-8105 (4).xlsx' else 'FAIL'}]\n")

    # Limpiar
    for f in zj_dup_files:
        (tmpdir_path / f).unlink()

    # Test 3: Manpower Budget - Version mas nueva
    print("3. Manpower Budget - Version mas nueva:")
    budget_files = [
        "副本Manpower Budget-Rev 15 April.xlsx",
        "副本Manpower Budget-Rev 16.1 April.xlsx",
        "副本Manpower Budget-Rev 17.xlsx",
        "副本Manpower Budget-Rev 18.1.xlsx",
    ]
    for f in budget_files:
        (tmpdir_path / f).touch()

    result = find_latest_file(tmpdir, "MANPOWER_BUDGET")
    filename = Path(result).name if result else None
    print(f"   Archivos: {budget_files}")
    print(f"   Resultado: {filename}")
    print(f"   Esperado: 副本Manpower Budget-Rev 18.1.xlsx")
    print(f"   Estado: [{'PASS' if filename == '副本Manpower Budget-Rev 18.1.xlsx' else 'FAIL'}]\n")

    # Limpiar
    for f in budget_files:
        (tmpdir_path / f).unlink()

    # Test 4: Manpower - Fecha mas nueva (Month_Day)
    print("4. Manpower - Fecha mas nueva (Month_Day):")
    manpower_files = [
        "Manpower_April_28.xlsx",
        "Manpower_April_29.xlsx",
        "Manpower_April_25.xlsx",
        "Manpower_April_5.xlsx",
        "Manpower_March_28.xlsx",
    ]
    for f in manpower_files:
        (tmpdir_path / f).touch()

    result = find_latest_file(tmpdir, "MANPOWER")
    filename = Path(result).name if result else None
    print(f"   Archivos: {manpower_files}")
    print(f"   Resultado: {filename}")
    print(f"   Esperado: Manpower_April_29.xlsx")
    print(f"   Estado: [{'PASS' if filename == 'Manpower_April_29.xlsx' else 'FAIL'}]\n")

    # Limpiar
    for f in manpower_files:
        (tmpdir_path / f).unlink()

    # Test 5: Archivo unico - Retornar directamente
    print("5. Archivo unico - Retorna directamente:")
    single_file = "ZJ26042912-8105.xlsx"
    (tmpdir_path / single_file).touch()

    result = find_latest_file(tmpdir, "ZJ")
    filename = Path(result).name if result else None
    print(f"   Archivo: {single_file}")
    print(f"   Resultado: {filename}")
    print(f"   Esperado: ZJ26042912-8105.xlsx")
    print(f"   Estado: [{'PASS' if filename == 'ZJ26042912-8105.xlsx' else 'FAIL'}]\n")

    # Test 6: No hay archivos del tipo
    print("6. No hay archivos del tipo especificado:")
    result = find_latest_file(tmpdir, "REAL_TIME_PRODUCTION")
    print(f"   Resultado: {result}")
    print(f"   Esperado: None")
    print(f"   Estado: [{'PASS' if result is None else 'FAIL'}]\n")

print("=" * 70)
print("Tests completados")
print("=" * 70)
