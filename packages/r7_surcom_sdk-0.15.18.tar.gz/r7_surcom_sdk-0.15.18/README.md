# Surface Command SDK

The `surcom-sdk` helps you build data connectors for the Rapid7 Surface Command platform.

Source code for all connectors is available in our [GitHub repository](https://github.com/rapid7/r7-surcom-connectors).

## Getting Started

1. Install the SDK:

   ```bash
   pip install r7-surcom-sdk
   ```

2. [Configure the SDK](https://docs.rapid7.com/surface-command/build-custom-connectors/#install-and-configure-the-sdk) with your API key

3. [Build your first connector](https://docs.rapid7.com/surface-command/build-custom-connectors/#build-an-example-connector) by following our tutorial

4. [Contribute](https://github.com/rapid7/r7-surcom-connectors?tab=contributing-ov-file) to our open source connectors or share your own connector with the community! 

## Documentation

- [Troubleshoot connector issues](https://docs.rapid7.com/surface-command/build-custom-connectors/#troubleshoot-your-connector)
- [Understand the Attack Surface Management type system](https://docs.rapid7.com/surface-command/asm-type-system)
