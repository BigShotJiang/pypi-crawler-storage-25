---
name: sc-surcom-sdk
description: Understanding how to install and configure the surcom-sdk
compatibility: Requires Python >= 3.11, < 3.14, pip and access to the internet
metadata:
  version: "1.1"
---

# Surface Command SDK
The Surface Command Software Development Kit (SDK), is hosted on [PyPI](https://pypi.org/project/r7-surcom-sdk/) and provides a `surcom` CLI with tools to:

- develop and install Connectors
- develop and install Types
- interact with Surface Command Data
- download the Data Model
- download Agent Skills

## Prerequisites
- Python version >= 3.11, < 3.14
- Permissions to access Attack Surface Management capabilities and create an API key in the Command Platform
- Familiarity with the Attack Surface Management type system

### Optional Prerequisites
- 1Password for securely storing API keys and other secrets in the config file
- To develop and test Connectors, ensure docker is fully configured and running

## Installation
```
pip install r7-surcom-sdk
```

## Configuration

- Configuration is controlled by the `surcom_config` file, which is created when you initialize the SDK configuration by running `surcom config init`
- You define a single Workspace (only needed if Developing Connectors)
- You can define multiple connections to different instances of Surface Command, which is useful for managing multiple environments (e.g. production vs staging) or different regions (e.g. US vs EU)
- You must define at least one connection

### Create a Surface Command API Key
- Follow our [docs](https://docs.rapid7.com/insight/managing-platform-api-keys/#generating-a-user-key) to generate a new user API key in the Command Platform and copy the key before closing the window
- You can save the key as an API Credential in 1Password (recommended) so it can be accessed using a [1Password Secret Reference](https://developer.1password.com/docs/cli/secret-reference-syntax/#get-secret-references). Alternatively, you can save it as plain text (not recommended).

### Initialize the SDK configuration

- Initialize the SDK by running:
```
surcom config init
```
- This prompts for the following:
| Setting | Description |
|---------|-------------|
| Connector Workspace | The absolute path of the repository where connectors will be created |
| Surface Command URL | The URL for Surface Command with or without the scheme e.g. https://us.surface.insight.rapid7.com |
| Connection Name | A name for this initial connection that will be used in the config file e.g. `company-a-us` or `company-b-eu`. We recommend including the region in the name for readability. |
| Surface Command API Key | The API key for authenticating with Surface Command. You can enter the key directly, or if you saved it as a 1Password Secret, you can enter the corresponding 1Password Secret Reference e.g. `op://MyVault/MyItem/api_key` |
| Default Connection | Whether this connection should be the active connection that is used by default when you run surcom-sdk commands that require a connection to Surface Command. Only one connection can be active at a time. You can change the active connection later by running `surcom config use <connection-name>` |

> **Note:** The Connector Workspace is the absolute path to the directory where your connectors will be created when you run `surcom connector init`. This is typically one of the `rapid7`, `partners` or `community` folders in the `connectors/` directory. If not intending to develop Connectors, you can set this to any directory and it will not impact your use of other features of the SDK.

- See [valid-sc-urls.md](./references/valid-sc-urls.md) for all valid Surface Command URLs
- The command creates a `surcom_config` file at `~/.r7-surcom-sdk/surcom_config` with default settings
- You will then be prompted to install the provided Agent Skills

For a complete walkthrough, follow our guide at https://docs.rapid7.com/surface-command/build-custom-connectors/#install-and-configure-the-sdk

## Test the Connection
- After initializing the config, test the connection by running:
```
surcom connection test
```

# The `surcom_config` file

- It is just a plain text file in an INI-style format with sections
- By default, it's located at `~/.r7-surcom-sdk/surcom_config`
- The main section for the SDK is `[surcom-sdk]`
- Any setting can be a 1Password Secret Reference (`op://vault/key...`)
- See the [config file reference](./references/config-file-settings-ref.md) for details on each setting

The config file allows you to:
- Configure surcom-sdk settings in the `[surcom-sdk]` section
- Configure connections to multiple instances of Surface Command in sections prefixed with `connection`
- Store API keys and other secrets (optionally using 1Password integration) for each connector in sections prefixed with `connector`

- To comment out a setting prefix it with `-`, for example:
```
[connector.demo.connector]
url = http://host.docker.internal:1080
api_key = "op://MyVault/MockServer/api_key"
-total_pages = 10
```

## Connection Sections
- These are sections in the config file that are prefixed with `connection` like `[connection.<instance-name>]` e.g. `[connection.company-a-us]` or `[connection.company-b-eu]`
- We recommend to include the region for readability
- They define connections to different instances of Surface Command, allowing you to easily switch between them
- A connection section includes:
 - `url`: the URL for Surface Command e.g. https://us.surface.insight.rapid7.com
 - `api_key`: the API key for authenticating with the instance
 - `active`: a boolean that indicates whether this connection is active. Only one connection can be active at a time, and the active connection is used by default when you run surcom-sdk commands that require a connection to Surface Command
- Change the active connection by running `surcom config use <instance-name>`
- The config file can optionally include settings to be used when invoking specific connectors 

## Connector Section
- These are sections in the config file that are prefixed with `connector` like `[connector.<connector.id>]` e.g. `[connector.demo.connector]`
- The section name includes the connector ID that is in the connector.spec.yaml file
- When you first run `surcom connector invoke` you will be prompted for each of the connector's settings. The values entered will be stored in the corresponding connector section in the config file
- To modify the settings for a connector, edit the config file directly
- Settings are OpenAPI-style definitions of the configuration options for a Connector that are stored in the config file and used when invoking a connector
- Settings values will be read as per the markup in the connector.spec.yaml in the `settings` block
- To learn more about Connector settings, see the `sc-connectors` Agent Skill