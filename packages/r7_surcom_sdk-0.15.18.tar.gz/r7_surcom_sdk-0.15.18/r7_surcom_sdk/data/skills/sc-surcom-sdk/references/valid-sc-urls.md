# Valid Surface Command URLs

- The Surface Command URL is the URL for the Surface Command instance that you want to connect to with the surcom-sdk. It can be entered with or without the scheme (e.g. `https://`), but it must be a valid URL that points to a Surface Command instance.

- Depending on the region your Surface Command instance is hosted in, the URL will be different. The URL typically follows the format `https://<region>.surface.insight.rapid7.com/surface` where `<region>` is a code that represents the region (e.g. `us`, `eu`, `ap`, etc.)

- The following table maps each region to its Surface Command URL.
These are derived from the [Allowlist Surface Command IPs](https://docs.rapid7.com/exposure-command/allowlist-surface-command-ips/) documentation, with `api` replaced by `surface` in each URL.

| Region | URL |
| --- | --- |
| United States - 1 | `https://us.surface.insight.rapid7.com/surface` |
| United States - 2 | `https://us2.surface.insight.rapid7.com/surface` |
| United States - 3 | `https://us3.surface.insight.rapid7.com/surface` |
| Europe - 1 (Central) | `https://eu.surface.insight.rapid7.com/surface` |
| Asia-Pacific - 1 (Northeast) | `https://ap.surface.insight.rapid7.com/surface` |
| Canada - 1 (Central) | `https://ca.surface.insight.rapid7.com/surface` |
| Asia-Pacific - 2 (Southeast) | `https://au.surface.insight.rapid7.com/surface` |
| Asia-Pacific - 2 (South) | `https://aps2.surface.insight.rapid7.com/surface` |
| Middle East - 1 (Central) | `https://me1.surface.insight.rapid7.com/surface` |
