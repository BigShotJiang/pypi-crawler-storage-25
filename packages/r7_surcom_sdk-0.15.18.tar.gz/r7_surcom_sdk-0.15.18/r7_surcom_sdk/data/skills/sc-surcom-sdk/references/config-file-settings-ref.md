# surcom-sdk configuration file reference

- This reference describes the configuration options for the `surcom_config` file used by the Surface Command SDK

- Each of the following settings can be set in the `[surcom-sdk]` section of the `surcom_config` file, which is typically located at `~/.r7-surcom-sdk/surcom_config`

| Setting | Type | Description |
|---------|------|-------------|
| path_connector_ws | str | The Connector Workspace. Normally this is the absolute path to the connectors/partners folder in a local copy of the r7-surcom-connectors-internal repo. Used when we create a new connector |
| requests_timeout_seconds | int | The number of seconds to timeout when making any request. Defaults to 20 seconds |
| timeout_install_connector | int | The number of seconds to wait for a connector to install. Defaults to 300 seconds (5 minutes) |
| path_p12_file | str | The absolute path to the PKCS#12 file that is used by jarsigner when you run the connector sign or install command |
| p12_file_password | str | The password that jarsigner will use to read the p12 file. This can be a 1Password Secret Reference |