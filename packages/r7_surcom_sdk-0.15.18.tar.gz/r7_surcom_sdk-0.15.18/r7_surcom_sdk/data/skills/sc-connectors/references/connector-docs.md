# Connector Documentation

- When a connector is released, the documentation is generated and published to the [Extension Library](https://extensions.rapid7.com/extension?product=SC)
- The documentation is produced from the `settings` block in the `connector.spec.yaml` file and the `docs/INSTRUCTIONS.md` file in the connector's directory
- Each connector must have a `docs/INSTRUCTIONS.md` file
- There are 3 sections in it: `# __Description__`, `# __Overview__`, `# __Documentation__` - details on these below. **Only these sections should be surrounded by the double underscores. Other sections should not use double underscores.**

## Content Accuracy

- A customer should be able to browse the Extension Library and at first glance be able tell what data a Connector will import and what Types and Import Feeds will be created
- A customer should be able to setup and configure the Connector, run the Import Feed without any aid from Support
- INSTRUCTIONS.md must accurately describe **only the settings and data types that are actually implemented**. Do not describe features that are not yet built.
- Do not just list settings — describe the **steps to obtain** each credential (API key generation, token creation, etc.).
- Reference the vendor's documentation for credential generation with direct links.
- Specify the minimum required permissions or roles needed for API access.
- When connectors support multiple deployment modes (e.g., cloud vs. on-prem), clearly describe the configuration differences for each.
- All settings exposed in `connector.spec.yaml` must be documented — do not omit optional settings like `verify_tls`, `page_limit`, etc.

## Screenshots
- Screenshots should be included in the `docs/` directory and referenced in the INSTRUCTIONS.md file to help guide users through setup
- All screenshots should have any PII removed and should be clearly labeled with alt text that describes what the screenshot is showing
- They can be referenced in the markdown like this:
```
![Alt Text](1.png)
```

## Example

Here is an example format for most Connectors with the correct spacing and indentation:

```markdown
# __Documentation__
  
  ## __Setup__
  
  This connector requires a Web Service URL, Tenant Name and an API Key 
  to be configured.

  To get these settings, follow the below steps:

  ### Web Service URL and Tenant Name

  1. Login to the portal
  2. Click the user icon in the top right
    ![user_icon](1.png)
  3. View the Web Service URL and Tenant Name and copy them

  ### API Key

  * To generate the API Key, refer to the
    SecurityScorecard [documentation](https://securityscorecard.readme.io/reference/quickstart)

  #### Permissions Required

  Ensure the API Key generated has the following permissions:

  * `READ_ISSUES`
  * `READ_USERS`
  * `READ_DEVICES`
```

---

## Description Section (docs/INSTRUCTIONS.md:__Description__)

- This section should be one or two lines of a description of the connector.
- Appears on the content card in the Extensions Library.
- It should be indented with 2 spaces and have no blank lines.
- Max 150 characters long and plain text only, no special formatting.
- Example: "Connector for Surface Command that imports Asset and Vulnerability data"

---

## Overview Section (docs/INSTRUCTIONS.md:__Overview__)

- This section is an Overview of what the connector does. It should be a short paragraph or two that describes the connector and its purpose.
- Appears on the landing page for this Connector in the Extensions Library and also on the "Summary" tab of the Connector in Surface Command.
- It can be over multiple lines with a single blank line between paragraphs and each line indented by 2 spaces.
- Max 2000 characters long and plain text only, no special formatting.

---

## Documentation Section (docs/INSTRUCTIONS.md:__Documentation__)

- This section should be a full set of instructions that are needed to configure this Connector
- In the INSTRUCTIONS.md file, there is a subsection `__Setup__` under the `__Documentation__` section that is where you should put all the instructions for setting up the connector
- It will appear on the Extensions Library, in the **Documentation** tab for this Connector, under the *Setup* heading
- Tabs should be 2 spaces
- It should include;
  - all details required to setup the Connector
  - instructions on how to authenticate this Connector with the Third Party
  - any links to information on how to setup or get the required credentials
  - some screenshots with any PII removed that may help guide the user when setting up
- This section supports most Markdown syntax. Supported elements include:
  - Bold
  - Italic
  - Inline code
  - Code blocks
  - Hyperlinks
  - Screenshot references (e.g. `![Alt Text](1.png)`)
  - Blockquotes
  - Ordered and unordered lists
  - Tables
  - Sub headings (e.g. `### Subheading`)
- Do not include any elements that are not supported in markdown such as HTML, videos, gifs, etc. Unsupported elements will not render in the Extensions Library and may cause formatting issues for the rest of the documentation.
- To add another Menu Item (e.g. *Another Section*), add another heading with in the `## __Documentation__` section (e.g. `## Another Section`) and it will appear as a separate section in the Documentation tab for this Connector in the Extensions Library

---