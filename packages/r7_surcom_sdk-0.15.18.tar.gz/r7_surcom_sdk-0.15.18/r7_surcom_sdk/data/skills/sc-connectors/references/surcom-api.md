# Surface Command Connector API

The `r7-surcom-api` is a lightweight Python library that Surface Command uses to run Connectors

Available on PyPI: https://pypi.org/project/r7-surcom-api/

## `furl`

The `furl` library is bundled with `r7-surcom-api` and available for use in all connectors. It provides a convenient way to construct and manipulate URLs.

```python
from furl import furl

# Build a URL with query parameters
url = furl(base_url)
url.path /= "api" / "devices"
url.args["page"] = page_number
url.args["limit"] = page_limit

# Result: https://example.com/api/devices?page=1&limit=10
response = session.get(url.url)
```

This is the standard pattern used across all connectors for URL construction.

## `HttpSession`

The `HttpSession` is a wrapper around `requests.Session` that provides several default behaviors for connector code:

* Provides correct behavior for `verify=False` in the connector runtime environment.  This can be used ONLY WHEN NECESSARY to connect to a service that presents a self-signed or otherwise invalid TLS certificate.

* Configures a default timeout adapter for http: and https: schemes, so that connection timeouts are resolved in a consistent way

* Configures a default retry-handler, so that retryable status codes and the `Retry-After` header are handled appropriately.


### HttpSession Customization

⚠️ DO NOT customize the HttpSession parameters unless there are specific requirements based on the source REST APIs.

```python
# Override the default timeout
session = HttpSession(timeout=(123, 456))  # (connection-timeout, read-timeout)
```

```python
# Override the default retry handler to only retry on a special 599 status code
retry_methods = ["GET"] # will not retry on HEAD, OPTIONS, etc.
retry_statuses = [599] # will not retry on 429, etc.
retry_handler = Retry(
    total=5,
    backoff_factor=2,
    allowed_methods=retry_methods,
    status_forcelist=retry_statuses,
    respect_retry_after_header=True
)
session = HttpSession(max_retries=retry_handler)
```