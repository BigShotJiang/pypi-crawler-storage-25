# Connector Spec File (connector.spec.yaml)

- Each connector has one
- Generated with the `init` command
- Contains all the metadata
- Values used from here:
  - when running `codegen`
  - when displaying it in the UI

The properties are:

## id
- Unique identifier for the connector
- Formatted as `<namespace>.<name>`
- For example `demo.connector`

## name
- Display name for the connector
- For example `Demo Connector`

## author
- The name of the connector's author, normally the name of the company that built the connector
- For example `Rapid7`

## version
- The version of the connector
- Formatted as `<major>.<minor>.<patch>`
- The `patch` number must always be `0`
- It is replaced with a unique build number during the build process
- Must be incremented with each release of the connector
- If surcom types are added or deprecated, the `major` version must be incremented
- For example `1.0.0`

## notice
- A legal notice that is displayed in the UI when a user tries to install the connector
- For example `Copyright © 2026 Rapid7. All rights reserved.`

## current_changes
- A description of the changes that were made in the current version of the connector
- It is a list with each item a string describing a change
- Each item is shown in the Extension Library in that connector's Change Log section
- For example:
```yaml
current_changes:
  - "Added new types: `AsimilyAnomaly` and `AsimilyAsset`"
  - "Updated the Import All function to pull in the new types"
```

## reference-schemas
- A list of objects where each item represents a reference to an external schema that is used in the connector's type definitions
- The `url` property is the URL that is used in the `$ref` field in the connector's type definitions to reference this schema
- The `file` property is the path to the actual schema file in the connector's directory
- IT MUST BE IN THE `refdocs/` DIRECTORY
- For example:
```yaml
reference-schemas:
  - url: "https://example.com/schemas/asset.json"
    file: "refdocs/asset.json"
```

## depends-on
- A list of connector IDs that this connector depends on. This is used to ensure that connectors are installed in the correct order when there are dependencies between them. For example, if Connector A has a type that references a type from Connector B, then Connector A should list Connector B in its `depends-on` block to ensure that Connector B is installed first.
- Only required if you have type references to other connectors.
- For example:
```yaml
depends-on:
  - "mitre.attack.app"
```

## types
- A list of strings of the name of the connector's type definitions that will be installed into Surface Command when the connector is installed
- Each type listed here must have a corresponding YAML file in the `types/` directory of the connector with the same name as the type
- For example:
```yaml
types:
  - "AsimilyAnomaly"
  - "AsimilyAsset"
```

## functions
- Is a list of objects where each item represents a function definition that will be installed into Surface Command when the connector is installed
- Each function listed here must have a corresponding Python file in the `functions/` directory of the connector that is prefixed with `fn_` and has the same name as the function
- Each connector must have a `test` function
- `test` is a unique function id. It is linked to `fn_test.py` in the `functions/` directory and is used when a user clicks the "Test Connection" button in the UI to validate that the connector is properly configured and can pull in data
- Each other function must specify a unique `id`, a `title`, a `description`, and a list of `return_types` that reference the connector's types
- For example:
```yaml
functions:
  - id: import_all
    title: Import All
    description: Import all devices and users from Demo Connector
    return_types:
      - DemoConnectorDevice
      - DemoConnectorUser
```

## settings
- See [connector-settings.md](references/connector-settings.md) for more details

## runtime
- The runtime that the connector's functions will run on
- Valid value currently is `py311`

## python_dependencies
- This is a list of PyPI packages that are dependencies for the connector's functions
- During the `codegen` process, this list plus the `r7-surcom-api` package are combined and pinned to the latest versions in a generated `requirements.txt` file
- If there are no extra dependencies, this property can be omitted

## categories
- A list of strings that represent the categories that the connector belongs to
- Used for filtering connectors in the Extension Library
- A connector must have one category at minimum, but can not have more than three
- Available categories include: `endpoint_detection_response`, `vulnerability_management`, `asset_management`, `cloud_security`, `iam`, `ticketing`, and others
- The full list of available categories:

```json
[
  { "id": "endpoint_detection_response", "displayName": "Endpoint Detection & Response", "examples": "Cybereason, CrowdStrike Falcon, Microsoft Defender for Endpoint, SentinelOne, Carbon Black" },
  { "id": "vulnerability_management", "displayName": "Vulnerability Management", "examples": "Tenable.io, Qualys VMDR, Rapid7 InsightVM, SCADAfence, Nozomi" },
  { "id": "asset_management", "displayName": "Asset Management", "examples": "SCADAfence, LANsweeper, ServiceNow ITAM, KACE SMA, SnipeIT" },
  { "id": "external_attack_surface", "displayName": "External Attack Surface", "examples": "Microsoft Defender EASM, Shodan, SecurityScorecard, Cloudflare, Hardenize" },
  { "id": "network_firewall", "displayName": "Network & Firewall", "examples": "Infoblox NIOS, Netbox, Zscaler, Darktrace" },
  { "id": "application_development", "displayName": "Application Development & Security", "examples": "GitHub, Snyk, Semgrep, Sonarqube, Jira" },
  { "id": "database", "displayName": "Database", "examples": "Snowflake, Microsoft SQL Server, PostgreSQL, Amazon S3" },
  { "id": "security_operations", "displayName": "Security Operations", "examples": "Incydr, XSOAR, SolarWinds Orion, Nexthink, Splunk, Devo SIEM, Exabeam" },
  { "id": "endpoint_management", "displayName": "Endpoint Management", "examples": "Microsoft Intune, Jamf, Kaseya VSA, NinjaOne, baramundi" },
  { "id": "phishing", "displayName": "Phishing", "examples": "KnowBe4, Proofpoint TAP" },
  { "id": "iam", "displayName": "Identity & Access Management", "examples": "CyberArk PAM, PingOne, Entra ID, Okta, Cisco Duo" },
  { "id": "cloud_service_provider", "displayName": "Cloud Provider / Infrastructure", "examples": "AWS, Azure Compute, VMWare" },
  { "id": "cloud_security", "displayName": "Cloud Security", "examples": "Orca, Wiz, Trend CloudOne, Cisco Umbrella, Aqua CSPM" },
  { "id": "case_management", "displayName": "Case Management", "examples": "Jira, ServiceNow, Freshservice" },
  { "id": "ticketing", "displayName": "Ticketing", "examples": "Jira, ServiceNow, Freshservice, Ivanti Neurons ITSM" },
  { "id": "alerting_and_notifications", "displayName": "Alerting & Notifications" },
  { "id": "threat_intel", "displayName": "Threat Intelligence", "examples": "HaveIBeenPwned, Recorded Future, Proofpoint TAP" },
  { "id": "collaboration", "displayName": "Collaboration", "examples": "Slack, Google Drive, Microsoft Teams" }
]
```

## show_orchestrator_ui
- A boolean value that determines whether or not to show the Orchestrator UI for this connector's functions in the Surface Command UI
- Defaults to `false`
- If `true`, when users configure this connector they will see a slightly different UI with additional steps on how to setup and run this connector on an Orchestrator