# Connector Settings

- When you first run `surcom connector invoke` you will be prompted for each of the connector's settings. The values entered will be stored in the corresponding connector section in the config file
- To modify the settings for a connector, edit the config file directly
- Settings are OpenAPI-style definitions of the configuration options for a Connector that are stored in the config file and used when invoking a connector
- Settings values will be read as per the markup in the connector.spec.yaml in the `settings` block
- The `key` in the `settings` block is the setting name that will be used in the config file
- `nullable: true` means the setting is optional
- If the setting `type` is `array`, the values in the config file should be comma-separated. In the Surface Command UI, these will be shown as a multi-select dropdown
- If the setting has an `enum`, the value in the config file must be one of the values in the enum. In the Surface Command UI, these will be shown as a dropdown with the enum values as options

## `connector.spec.yaml` example
```
settings:
  url:
    type: string
    title: URL
    description: >-
      Base URL of where the MockServer is hosted when you run it using the surcom-sdk.
    example: http://host.docker.internal:1080
    default: http://host.docker.internal:1080

  api_key:
    type: string
    title: API Key
    description: >-
      API key for the MockServer that is provided in the instructions.
      for this tutorial.
    format: password

  verify_tls:
    type: boolean
    title: Verify TLS?
    description: If enabled, verify the server's identity.
    default: true

  page_limit:
    type: integer
    title: Page Limit
    description: Maximum number of items to return per page.
    enum:
      - 2
      - 4
      - 6
    default: 6

  # This is an optional setting that can be used to control pagination.
  total_pages:
    type: integer
    title: Total Pages
    description: >-
      Total number of pages to retrieve. Set it to 0 to retrieve all pages.
    default: 2
    nullable: true

  filter_device_types:
    type: array
    title: Filter Device Types
    description: >-
      A list of device types to filter devices by. Only devices with types in this list will be imported.
      If empty, all devices will be imported.
    default:
      - Laptop
      - Desktop
    items:
      type: string
      enum:
        - Workstation
        - Desktop
        - Laptop
        - Tablet
    nullable: true
```


## `surcom_config` example

Settings can be specified as plain text values or, optionally, as 1Password secret references (e.g., `op://...`) if you have the 1Password CLI configured.

```
[connector.demo.connector]
url = http://host.docker.internal:1080
api_key = "op://MyVault/MockServer/api_key"
verify_tls = True
page_limit = 6
total_pages = 2
filter_device_types = Laptop, Desktop
```