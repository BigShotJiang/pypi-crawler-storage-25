# Troubleshoot your connector

## How can I debug my connector?

The Surface Command SDK also has optional debug functionality.

To install and configure the SDK debugger using Microsoft Visual Studio Code:

1. Open Microsoft Visual Studio Code and open an integrated terminal.
1. Install the extra debugger dependencies:

    ```bash
    pip install 'r7-surcom-sdk[debug]'
    ```

1. Open `.vscode/launch.json` and copy and paste the example launch configuration.
1. In the duplicate example launch configuration:
   1. Update `name` with the name of your connector.
   1. Update the `pathMappings.localRoot` to the path of your connector's `functions` code.
1. Save `.vscode/launch.json`.
1. In the terminal, change directory to your connector:

    ```bash
    cd ~/r7-surcom-connectors/connectors/partners/<connector-name>
    ```

1. Run:

    ```bash
    surcom connector invoke -f import_all --debug
    ```

1. In the code window, add a breakpoint and when you see the terminal return `Debug mode enabled, waiting for debugger to attach`, launch the debugger in Microsoft Visual Studio Code.

---

## How do I view the help menu?

```bash
surcom --help           # view high-level help
surcom connector --help # view help for a sub-command
```

---

## How can I turn on tab completion?

To turn on tab completion:

1. Run:

    ```bash
    surcom config enable-tabs
    ```

1. Restart your shell.

---

## How do I find the surcom_config file?

To find the location of the `surcom_config` file:

1. Run:

    ```bash
    surcom config init
    ```

**Configuration file hidden:** The configuration file is hidden and prefixed with a `.`

---

## How do I manage configuration file settings?

You can comment out a setting in the configuration file by prefixing with a `-`. For example, to ignore the `total_pages` setting:

```text
[connector.demo.connector]
url = http://host.docker.internal:1080
api_key = "op://Employee/DEMO/SURCOM DEMO API KEY"
verify_tls = True
page_limit = 6
-total_pages = 2
```

---

## How do I turn on verbose logging?

To turn on verbose logging:

1. Add the `-v` flag command. For example:

    ```bash
    surcom -v connector invoke -f import_all --import-data
    ```

---

## How do I preview my documentation?

Microsoft Visual Studio Code has a built-in preview feature for Markdown files.

To preview your connector's documentation:

1. Open the `docs/INSTRUCTIONS.md` file in Microsoft Visual Studio Code.
1. Right-click the file's name in the file explorer.
1. Click **Open Preview**.

---

## How do I run a function locally?

Use the `invoke` command with the `-f` flag and its ID:

```bash
surcom connector invoke -f test
```

---

## How do I overwrite the settings from the CLI?

Use the `invoke` command to pass any settings and overwrite values in the `surcom_config` file. For example:

```bash
surcom connector invoke -f import_all -s page_limit=4,api_key=xxx
```

---

## How do I add Python dependencies?

To add a dependency:

1. List the PyPI package in the `python_dependencies` block of the `connector.spec.yaml` file. For example:

    ```yaml
    python_dependencies:
        -  sampleproject
    ```

1. Run the `codegen` command to generate a `requirements.txt` file with all the Python dependencies for your connector:

    ```bash
    surcom connector codegen
    ```

    **Pinned Dependencies:** Each connector depends on the r7-surcom-api package by default. This, plus any additional dependencies you specify and all other transient dependencies will be included in the generated `requirements.txt` file.

1. Modify your `functions` code to import the new dependency and use it as needed.
1. `invoke` the function.
