# Connector Python Code (functions/)

- This directory contains the core implementation files for a Surface Command connector. These files handle data ingestion from third-party APIs, connection testing, and type definitions.

- This guide uses the [Demo Connector](https://github.com/rapid7/r7-surcom-connectors/tree/main/connectors/rapid7/demo_connector) as a reference implementation. Your connector's structure will be similar but may differ in API patterns, authentication methods, and pagination strategies.

## High-Level Overview

In the Demo Connector, the `functions/` directory is organized into several functional categories:

- **Entry Points** (`fn_import_all.py`, `fn_test.py`): Main connector operations exposed to the Surface Command platform
- **Shared Utilities** (`helpers.py`): Common code and API client implementation
- **Configuration** (`sc_settings.py`, `sc_types.py`): Type definitions and settings schemas (auto-generated with `codegen`) 
- **Initialization** (`__init__.py`): Module-level exports (auto-generated with `codegen`)

---

## File Reference

### `__init__.py`

**Purpose**: Module entry point that exports public functions to the Surface Command platform.

**Technical Details**:
- **Status**: Auto-generated (do not edit)
- **Generated From**: `connector.spec.yaml` via `surcom connector codegen`
- **Functionality**: Exports `test()` and `import_all()` functions from their respective modules

---

### `fn_import_all.py`

**Purpose**: Implements the primary data ingestion pipeline that retrieves and yields all asset types from the connected third-party system.

**Technical Details**:
- **Entry Function**: `import_all(user_log: Logger, settings: Settings) -> Iterator`
- **Core Workflow**:
  1. Instantiates an API client using `helpers.DemoConnectorClient`
  2. Implements paginated data retrieval through the `_get_asset()` helper function
  3. Applies optional post-processing filters (e.g., device type filtering) via `_post_process_device()`
  4. Yields typed asset objects (`DemoConnectorDevice`, `DemoConnectorUser`) for ingestion
- **Pagination Logic**:
  - Tracks current page number and fetches data via API method callbacks
  - Validates response structure and presence of data
  - Stops when reaching last page or respecting `total_pages` setting limit
  - Uses dependency injection for external methods (e.g., `add_one()` from sample dependency)
- **Dependencies**:
  - `sample.simple.add_one()`: External library function for incrementing page numbers
  - `helpers.DemoConnectorClient`: API client for making requests
  - `sc_settings.Settings`: Settings TypedDict for configuration access
  - `sc_types.DemoConnectorDevice`, `DemoConnectorUser`: Output type definitions

---

### `fn_test.py`

**Purpose**: Validates connector connectivity and required permissions before enabling data ingestion.

**Technical Details**:
- **Entry Function**: `test(user_log: Logger, **settings: Settings) -> dict`
- **Note on Signature**: The `test()` function uses `**settings` (kwargs unpacking) while `import_all()` uses `settings` (direct parameter). This is an intentional design pattern — `test()` receives settings as keyword arguments for flexibility in the platform's test invocation, while `import_all()` receives the full settings dictionary directly for efficient iteration.
- **Validation Steps**:
  1. Creates a `DemoConnectorClient` instance with provided settings
  2. Queries the `/api/permissions` endpoint via `client.get_permissions()`
  3. Checks that all `REQUIRED_PERMISSIONS` are present in the API response
  4. Raises `ValueError` if any required permission is missing
- **Return Value**: Dictionary with status and message (e.g., `{"status": "success", "message": "Successfully Connected"}`)
- **Usage**: Called by the Surface Command platform when a user clicks the "Test Connection" button to verify authentication and authorization before enabling the connector

---

### `helpers.py`

**Purpose**: Encapsulates shared code and provides a reusable API client for interacting with the third-party system.

**Technical Details**:
- **REQUIRED_PERMISSIONS**: List constant defining permissions needed for connector operation (`readUsers`, `readDevices`)
- **DemoConnectorClient Class**: Stateful HTTP client wrapping third-party API interactions
  - **Initialization**:
    - Stores logger and settings references
    - Normalizes base URL (strips whitespace and trailing slashes)
    - Configures HTTP session with TLS verification based on `verify_tls` setting
    - Sets authentication header with API key from settings
  - **Methods**:
    - `get_devices(page_number: int)`: Fetches paginated device data from `/api/devices` endpoint
    - `get_users(page_number: int)`: Fetches paginated user data from `/api/users` endpoint
    - `get_permissions()`: Queries `/api/permissions` endpoint for authorization validation
  - **Session Management**: Uses `r7_surcom_api.HttpSession` for HTTP communication with automatic JSON parsing and error handling

---

### `sc_settings.py`

**Purpose**: Defines the configuration schema for connector settings through TypedDict.

**Technical Details**:
- **Status**: Auto-generated (do not edit)
- **Generated From**: `connector.spec.yaml` via `surcom connector codegen`
- **Type Definition**: `Settings` TypedDict with the following fields:
  - `url: str` — Base URL for the third-party API (required)
  - `api_key: str` — API key for authentication (required)
  - `verify_tls: bool` — Whether to verify TLS certificates (required)
  - `page_limit: int` — Number of items per page in paginated requests (required)
  - `total_pages: Optional[int]` — Maximum number of pages to fetch; if not set, fetches all (optional)
  - `filter_device_types: Optional[list]` — List of device type keywords for filtering; only devices matching these types are ingested (optional)
- **Usage**: Used throughout connector code for type-safe access to configuration values via `settings.get(key, default)`

---

### `sc_types.py`

**Purpose**: Defines output asset type classes that wrapper raw API response data for structured ingestion.

**Technical Details**:
- **Status**: Auto-generated (do not edit)
- **Generated From**: `connector.spec.yaml` via `surcom connector codegen`
- **Type Classes**: Both inherit from `dict` to provide a typed wrapper around API response dictionaries
  - **DemoConnectorDevice**:
    - Wraps device data returned from `/api/devices` endpoint
    - Structure: `{"type": "DemoConnectorDevice", "content": {...}}`
  - **DemoConnectorUser**:
    - Wraps user data returned from `/api/users` endpoint
    - Structure: `{"type": "DemoConnectorUser", "content": {...}}`
- **Pattern**: Constructor accepts raw API response dict and stores it under the `content` key with type metadata, enabling the Surface Command platform to route and process assets correctly

---

## Development Notes

- **Code Generation**: Files marked "DO NOT EDIT" (`__init__.py`, `sc_settings.py`, `sc_types.py`) are regenerated automatically when running `surcom connector codegen`. Any manual changes will be lost.
- **Editing Workflow**: Modify only `fn_import_all.py`, `fn_test.py`, and `helpers.py` when developing connector logic.
- **Logging**: All functions receive a `user_log: Logger` parameter for structured logging. Use this instead of print statements.
- **Settings Access**: Use `settings.get(key, default)` for safe configuration access with fallback defaults.
- **Error Handling**: API client methods use `raise_for_status()` to propagate HTTP errors; wrap calls in try-except if graceful error handling is needed.


