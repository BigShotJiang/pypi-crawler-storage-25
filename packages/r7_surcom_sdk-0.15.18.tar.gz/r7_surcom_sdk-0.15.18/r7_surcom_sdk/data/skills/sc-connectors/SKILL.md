---
name: sc-connectors
description: "Build and develop Surface Command Connectors. Use when: creating connector.spec.yaml, running surcom connector codegen/invoke/validate/install, writing connector Python code, troubleshooting connector errors, or creating sample data."
compatibility: Requires Docker and the surcom-sdk
metadata:
  version: "1.0"
---

# ⚠️ CRITICAL INSTRUCTIONS ⚠️

- IF asked to generate a new connector, follow the instructions in our guide on how to [Build Your First Connector](https://docs.rapid7.com/surface-command/build-custom-connectors/#build-an-example-connector)
- Firstly, create the `connector.spec.yaml` file and then run `surcom connector codegen` to generate the boilerplate code. This will ensure you have the correct file structure and dependencies for your connector.

# Surface Command Connectors
A Connector is a software component that enables Surface Command to collect data from an information source, such as vulnerability scanners, endpoint protection platforms, or cloud services.

Each connector understands the API and data schema of its target source. Surface Command provides connectors for most major tools and supports custom connectors for enterprise-specific systems.

To keep the data current, connectors periodically pull from their information source for new or changing situations. Surface Command then manages the data ingestion process, including correlation and mapping data from each connector.

## Quick Reference

| Task | Reference |
|------|-----------|
| Understand the spec file | [connector-spec-file.md](references/connector-spec-file.md) |
| Write connector settings | [connector-settings.md](references/connector-settings.md) |
| Write Python code | [connector-py-code.md](references/connector-py-code.md) |
| Write documentation | [connector-docs.md](references/connector-docs.md) |
| Use the HTTP API | [surcom-api.md](references/surcom-api.md) |
| Debug/troubleshoot | [troubleshooting.md](references/troubleshooting.md) |

## Documentation + Tutorial
- For first time Connector developers we recommend following our guide on how to [Build Your First Connector](https://docs.rapid7.com/surface-command/build-custom-connectors/#build-an-example-connector)
- The guide shows how to build an example connector that fetches data from the [MockServer](https://www.mock-server.com/) that is loaded with sample data using the surcom-sdk
- Complete documentation can be found at https://docs.rapid7.com/surface-command/build-custom-connectors

## Metadata (connector.spec.yaml)
- This file is also known as the "spec" file
- It contains all the metadata for a connector that is used when displaying it in the UI and also when running `codegen`
- For more details see our [connector-spec-file.md](references/connector-spec-file.md) reference

## Settings (connector.spec.yaml:settings)
- Connector settings are defined in the spec file and values are set in the config file
- For more details see our [connector-settings.md](references/connector-settings.md) reference

## Connector Dependencies (connector.spec.yaml:depends-on)
- If a connector's types references a source type in another connector we MUST specify the id of that connector here
- For example the `AsimilyAnomaly` type references the `MitreAttackTactic` type so it needs to have `mitre.attack.app` listed in its `depends-on` block

## Python Dependencies (requirements.txt)
- By default each connector automatically depends on the [`r7-surcom-api`](references/surcom-api.md)
- During the `codegen` process, this package plus any PyPI packages that are listed in the `python_dependencies` section of the spec file are combined
- We then leverage `uv` to generate a `requirements.txt` file with all the dependencies pinned to the latest versions
- If you need a specific version of a dependency, pin the dependency in the `python_dependencies` block and re-run `codegen`

## Python Code (functions/)
- For more details see our [connector-py-code.md](references/connector-py-code.md) reference

## Reference Schemas or Reference Documents (refdocs/)
- To learn more about reference schemas or reference documents, see the `sc-type-system` skill at `r7_surcom_sdk/data/skills/sc-type-system/references/refdoc.md`

## Documentation (docs/)
- For more details see our [connector-docs.md](references/connector-docs.md) reference

## Icon (icon.svg)
- MUST be a `svg` file
- MUST be named `icon.svg`
- Normally be a logo of the external data source
- Must be a valid representation of the data source

## Sample Data (sample_data/)
- Sample data are JSON files that contain the data that match the connector type definitions
- They are anonymized versions of the connector output
- Sample data files must **exactly match** the type name casing (e.g., `BeyondTrustEPMComputer.json`, not `BeyondtrustEPMComputer.json`).
- Sample data must be derived from **actual API responses** — never generated from scratch.
- Sample data must validate against the type schema
- Sample data for related types must be referentially consistent — IDs referenced across types should actually match.
- Include enough records (preferably ~100 per type) and ensure they relate correctly across types so references and graph views work.
- **No real customer data — EVER**. Do not include real customer names, email addresses, employee names, hostnames, account IDs, or identifiers that could identify a specific organization.
- Use RFC-reserved safe values for anonymization:
  - Email domains: `example.com`, `example.org`, `example.net`
  - IPv4: `192.0.2.x`, `198.51.100.x`, `203.0.113.x` (RFC 5737)
  - IPv6: `2001:db8::` prefix (RFC 3849)
  - Domain names: `example.com`, `example.org` (RFC 2606)
  - Person names: clearly fictitious (`Jane Doe`, `John Smith`)
- Do not include company-internal or proprietary URLs that would be visible in the public repo.

## Main `surcom connector` commands
- All commands in the surcom-sdk have help prompts, so find out more info by adding the `-h` flag.
- `surcom connector -h` shows high-level help
- `surcom connector codegen -h` shows low-level help

### `surcom connector init`
- Initialize a connector
- Prompts you for basic details
- Generates a `connector.spec.yaml` (spec) file for that connector in the connector workspace

### `surcom connector codegen`
- Uses the metadata in the `connector.spec.yaml` file to generate all the boilerplate code
- Any time you make a change to the spec file you should re-run `codegen`
- Generates a requirements.txt file using `uv` depending on the entries in the `python_dependencies` list

### `surcom connector invoke`
- Runs a connector function
- Outputs any recorded data to the `build/output` directory
- IT IS IMPORTANT NOT TO MODIFY THE `build/output` DIRECTORY AS THIS IS WHERE the generated data from the connector will be outputted and used for testing and development
- It is OK to remove it, but do not modify it in any other way

### `surcom connector validate`
- Runs a validation on the connector prior to install
- Checks that the connector meets our connector schema, required file layout, and metadata requirements before installation
- Validation results are categorized into three levels:
  - **CRITICAL**: Must be fixed before the connector can be installed
  - **WARNING**: Should be addressed but won't block installation
  - **INFO**: Suggestions for improvement

### `surcom connector package`
- Creates a ZIP package of your connector that you can use to install
on the Rapid7 Surface Command Platform.
- The package will be saved in the connector `build` directory.

### `surcom connector sign`
- Signs the connector package using jarsigner via Docker
- Required for non-custom connectors being published to the Connector Store
- Requires a `.p12` certificate configured in your environment

### `surcom connector install`
- Installs a connector into Surface Command
- Supports installation from source, ZIP package, or the Connector Store
- Supports flags:
  - `--sample-data`: Installs sample data along with the connector
  - `--connector-id`: Specifies the connector ID when installing from the Connector Store

## Debugging + Troubleshooting
- To setup debugging and for troubleshooting tips, see [troubleshooting.md](references/troubleshooting.md)

## GitHub Repository
- Source code for all Connectors lives in https://github.com/rapid7/r7-surcom-connectors
- All of our Connectors have a [MIT License](https://github.com/rapid7/r7-surcom-connectors?tab=MIT-1-ov-file)
- Users must review and agree to our [Code of Conduct](https://github.com/rapid7/r7-surcom-connectors?tab=coc-ov-file) guidelines before contributing
- To submit a new connector or update an existing one, open a PR against our public repo. See our [Contributing Guide](https://github.com/rapid7/r7-surcom-connectors?tab=contributing-ov-file) for more