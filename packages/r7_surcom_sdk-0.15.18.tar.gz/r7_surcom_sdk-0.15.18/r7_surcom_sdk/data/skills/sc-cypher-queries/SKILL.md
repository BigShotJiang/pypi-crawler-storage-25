---
name: sc-cypher-queries
description: Writing Cypher queries against the Surface Command graph database.
metadata:
  version: "1.0"
---

# ⚠️ CRITICAL FIRST STEP ⚠️

**YOU MUST PERFORM THIS CHECK FIRST - BEFORE WRITING ANY QUERIES:**

**Step 1:** Use `list_dir` to check if `~/.r7-surcom-sdk/sc-data-model/` exists
**Step 2:** Also check if the `types.duckdb` file exists in `~/.r7-surcom-sdk/sc-data-model/`
**Step 3:** If it does NOT exist, immediately:
  - STOP reading this skill
  - Tell the user: "⚠️ **The Surface Command model and its index are not present.** I cannot write queries without it."
  - Instruct them to run: `surcom model download --all --index`
  - END your response - do not write queries or guess at type/property names

**Step 4:** If it DOES exist, use the model to verify all type names, properties, and edge labels before writing queries.

---

# Cypher Queries for Surface Command

This skill provides guidance on writing Cypher queries against the Surface Command graph database. Surface Command uses standard OpenCypher syntax with custom extensions.

## Quick Reference

| Guide | Description |
|-------|-------------|
| [cypher.md](guides/cypher.md) | Complete Cypher query guide with syntax, extensions, and examples |
| [query_and_search.md](guides/query_and_search.md) | Query and search the type system using DuckDB |

## Key Concepts

The Surface Command graph is built from the type system data model:
- **Nodes** = entity types (e.g., `Machine`, `User`, `Vulnerability`)
- **Properties** = type properties
- **Edges** = reference properties from `x-samos-ref-types`; edge labels match the property name

## Before Writing Queries

**Always verify against the data model:**
- Consult `~/.r7-surcom-sdk/sc-data-model/` to confirm type names exist
- Verify property names are correct for the type
- Check that edge labels (reference properties) exist in `x-samos-ref-types`

## Surface Command Extensions

**Case-insensitive operators:**
`ICONTAINS`, `ISTARTS WITH`, `IENDS WITH`, `IEQUALS`, `INOTEQUALS`, `IIN`

**Correlation functions:**
- `EVERY(property)` — list of values from each source entity
- `TOP(property)` — value from the preferred source entity

**Date functions:**
- `SINCE(timestamp, "DAYS")` — days since timestamp
- `UTCNOW()` — current date/time
- `TODAY()` — current date

**Networking functions:**
- `IP_IN_CIDR(ip, cidr)` — IP within CIDR range
- `IS_RFC1918(ip)` — RFC1918/RFC6598 address
- `IP_IS_PUBLIC(ip)` — publicly-routable address

## Performance Rules

- **Filter Early:** Produce the smallest dataset before each operation
- **Prefer Source Types:** Concrete types are more efficient than unified types
- **Use Directional Arrows:** Always include `-->` or `<--` in relationship patterns
- **Verify Before Using:** Never invent edge labels — check the model

See [cypher.md](guides/cypher.md) for complete documentation and examples.
