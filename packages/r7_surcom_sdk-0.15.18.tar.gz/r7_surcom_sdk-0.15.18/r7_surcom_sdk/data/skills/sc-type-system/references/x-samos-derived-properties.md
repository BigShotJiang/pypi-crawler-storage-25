## `x-samos-derived-properties`: declares properties that are computed from original data

Derived properties provide expressions that are evaluated to build values that aren't in the raw type content but are convenient for reference or display. These properties are computed at import time using one of three supported syntaxes: `jsonpath`, `jmespath`, or `expression`.

Derived properties must be used sparingly.  Don't create a derived property simply to fulfill a unified property; instead, apply `x-samos-fulfills` to the original property.

Generally there are only two reasons to use a derived property:
- When a *calculated value* is required, transforming values from the original data, or
- When one source property should fulfill *more than one* unified property with the same value.

## `jsonpath` Syntax

The `jsonpath` syntax is suitable for addressing, extracting, and combining portions of the original content in flexible ways. It also includes extension functions for common operations.

To learn more about the syntax, see the [documentation](https://github.com/h2non/jsonpath-ng#jsonpath-syntax).

### Basic Property Access

```yaml
# Direct nested property access
syntax: jsonpath
value: '$.propertyName'

# Deep nested access
syntax: jsonpath
value: '$.cve.CVE_data_meta.ID'

# Multi-level nesting
syntax: jsonpath
value: '$.properties.nested.value'
```

### Array Filtering

```yaml
# Filter array by condition, extract field
syntax: jsonpath
value: '$.cve.description.description_data[?(@.lang=="en")].value'

# Filter objects by key-value pair
syntax: jsonpath
value: '$.Tags[?(@.Key=="Name")].Value'

# Filter nested array by type
syntax: jsonpath
value: '$.status.addresses[?(@.type=="InternalIP")].address'

# Extract IDs from objects matching source
syntax: jsonpath
value: '$.unique_identifiers[?(@.source=="azure")].id'

# Recursive descent with filter
syntax: jsonpath
value: '$.noetic_sensorReadings[?name=="Cloud Instance ID"]..values[*]'

# Filter strings using regex match
syntax: jsonpath
value: '$.local_metadata.host.ip[?(@ =~ "\\.")]'

# Access nested array element by index
syntax: jsonpath
value: '$.cves[0].cvss'
```

### Type Casting

```yaml
# Convert integer to string
syntax: jsonpath
value: '$.id.`cast(string)`'

# Convert to boolean
syntax: jsonpath
value: '$.service_provider_account_id.`cast(boolean)`'
```

### String Splitting

```yaml
# Split comma-separated string into array
syntax: jsonpath
value: '$.content.`splitlist(,, string)`'

# Split string by delimiter, take specific index
syntax: jsonpath
value: '$.name.`split(., 0, 1)`'

# Split email to get username
syntax: jsonpath
value: '$.primaryEmail.`split(@, 0, 1)`'

# Split CPE string, get from index 3 to end
syntax: jsonpath
value: '$.osCPE.`split(:, 3, -1)`'

# Split by space, get last element
syntax: jsonpath
value: '$.name.`splitlist( , string)`[-1]'

# Split by space, get first element
syntax: jsonpath
value: '$.name.`splitlist( , string)`[0]'
```

### String Manipulation

```yaml
# Lowercase/normalize string (case-insensitive ID)
syntax: jsonpath
value: '$.id.`casefold()`'

# Regex extract first 4 path segments, lowercase
syntax: jsonpath
value: '$.id.`sub(/((.+?(?=\/)){4}).*/, \\1)`.`casefold()`'

# Extract first 8 segments of resource ID
syntax: jsonpath
value: '$.id.`sub(/((.+?(?=\/)){8}).*/, \\1)`'

# Extract attack vector from CVSS string
syntax: jsonpath
value: '$.cvss_vector.`sub(/.*(AV:.).*/, \\1)`'

# Strip CIDR notation, split to array
syntax: jsonpath
value: '$.status.["platform_ip_addresses", "platform_ip_addresses_v6"].`sub(/\\/\\d+/, )`.`splitlist( , string)`'
```

### Date/Time Conversion

```yaml
# Convert epoch seconds to ISO date string
syntax: jsonpath
value: '$.created.`epoch(second, :19)` + "Z"'

# Epoch milliseconds to datetime
syntax: jsonpath
value: '$.device.registration_timestamp.`epoch(millis, :19)` + "Z"'

# Parse custom datetime format
syntax: jsonpath
value: '$.noetic_sensorReadings[?name=="EID Last Seen"]..values[*].`datetime(%a, %d %b %Y %H:%M:%S +0000, :19)`'
```

### Boolean Matching

```yaml
# Boolean match — return "true" or "False"
syntax: jsonpath
value: '$.internet_facing.`match(true, False)`'

# Match specific value or return fallback
syntax: jsonpath
value: '$.operational_status.`match(Operational, False)`'
```

### Alternate Property Access

```yaml
# First property found (alternates)
syntax: jsonpath
value: '$.(cpu_count|cpus)'

# Multiple property paths, extract value
syntax: jsonpath
value: '$.(managed_by,assigned_to).value'

# First element from alternates with regex
syntax: jsonpath
value: '$.(v2_vector_string|v3_vector_string)[:1].`sub(/.*(AV:.).*/, \\1)`'
```

### Array Length

```yaml
# Get count/length of array
syntax: jsonpath
value: '$.macs.`len`'
```

### String Concatenation

```yaml
# Concatenate strings with cast
syntax: jsonpath
value: '$.network + "/" + $.mask_bits.`cast(string)`'

# Simple string concatenation
syntax: jsonpath
value: '$.name + "@" + $.image_name'

# Prefix string concatenation
syntax: jsonpath
value: '"Severity: " + $.cvssv3.baseSeverity'
```

### Complex Chained Operations

```yaml
# Filter, split, then regex replace
syntax: jsonpath
value: '$.services[*].configurations[?(@.name=="ssl.cert.subject.dn")].value.`splitlist(,, string)`.`sub(/CN=/, )`'
```

---

## `jmespath` Syntax

The `jmespath` syntax has similar capabilities to `jsonpath` but with a different expression format. It is often preferred for complex transformations.
To learn more about the `jmespath` syntax, see the [website](https://jmespath.org/).

### Basic Property Access

```yaml
# Direct property access
syntax: jmespath
value: 'id'

# Nested property access
syntax: jmespath
value: 'info.hostname'

# Deep nested access
syntax: jmespath
value: 'metadata.Endpoint.status'
```

### Type Conversion

```yaml
# Convert to string
syntax: jmespath
value: 'to_string(id)'

# Convert to number
syntax: jmespath
value: 'to_number(value)'

# Get array length
syntax: jmespath
value: 'length(associatedThreats)'
```

### Null Coalescing

```yaml
# Return first non-null value
syntax: jmespath
value: 'not_null(cvssV3BaseScore, baseScore)'

# Coalesce with nested paths
syntax: jmespath
value: 'not_null(metrics.cvssMetricV31[0].cvssData.baseScore, metrics.cvssMetricV30[0].cvssData.baseScore)'

# Coalesce to empty array if null
syntax: jmespath
value: 'os.addresses || []'

# Coalescing chain — first non-null
syntax: jmespath
value: 'hostname || ip || name'
```

### Array Operations

```yaml
# Combine arrays and flatten
syntax: jmespath
value: '[IPAddress, IPv6Address][]'

# Create array from multiple sources, filter nulls
syntax: jmespath
value: '[primary_ip4.host, primary_ip6.host][?@]'

# Combine single value with array elements
syntax: jmespath
value: '[mac_address, x_mac_addresses[*]][]'

# Flatten nested arrays, filter nulls
syntax: jmespath
value: '[PublicIps,PrivateIps][][][?@]'

# Combine projected array with scalar
syntax: jmespath
value: '[ipAddresses[*].ipAddress, lastIpAddress][]'
```

### Array Projection

```yaml
# Project field from all array elements
syntax: jmespath
value: 'x_network_components[*].mac'

# Extract IDs from array of objects
syntax: jmespath
value: 'tags[*].id'

# Alternative projection syntax
syntax: jmespath
value: 'locations[].id'

# Project then filter nulls
syntax: jmespath
value: 'interfaces[*].address | [?@]'

# Nested array projection
syntax: jmespath
value: 'detail.NICS[].MAC'
```

### Filtering

```yaml
# Filter by nested property, get first value
syntax: jmespath
value: 'sensorReadings.columns[?@.name==`Cloud Instance ID`].values[0]'

# Filter IPs containing dot (IPv4)
syntax: jmespath
value: 'x_ip_list | [?@.contains(@,`.`)]'

# Filter IPs containing colon (IPv6)
syntax: jmespath
value: 'x_ip_list | [?@.contains(@,`:`)]'

# Filter by prefix
syntax: jmespath
value: 'x_state_data.statuses[].code|[?@ && starts_with(@,`PowerState`)]'
```

### Quoted Key Access

```yaml
# Quoted key for special characters
syntax: jmespath
value: '"@assignments".locations[0].location.id'

# Multiple quoted key projections
syntax: jmespath
value: '["@assignments".persons[].personGroup.id,"@assignments".persons[].person.id][]'

# Quoted key with null filter
syntax: jmespath
value: '"MAC Address"|[?@]'

# Array of quoted keys, filter nulls
syntax: jmespath
value: '["Computer Name", "DNS Name"][?@]'
```

### Equality Comparisons

```yaml
# Integer equality (backticks for literals)
syntax: jmespath
value: 'status == `1`'

# String equality (single quotes)
syntax: jmespath
value: "status.name == 'Active'"

# String literal comparison
syntax: jmespath
value: 'driverStatusString == `Active`'

# Inequality comparison
syntax: jmespath
value: "twoFactorMethod != 'None'"

# Nested equality check
syntax: jmespath
value: 'type_fields.asset_state == `In Use`'
```

### Conditional Logic with Contains

```yaml
# Qualified hostname detection (contains dot)
syntax: jmespath
value: 'hostname && contains(hostname, `.`) && hostname || null'

# Unqualified hostname (no dot)
syntax: jmespath
value: 'name && !contains(name, `.`) && name || null'

# Email detection pattern
syntax: jmespath
value: 'contains(account_id, `@`) && account_id || null'

# Conditional string return based on platform
syntax: jmespath
value: "platform && contains(platform,`Linux`) && `OSFamily: Linux` || null"

# Check if model is virtual
syntax: jmespath
value: 'model && contains(model, `Virtual`)'
```

### Boolean Operations

```yaml
# Boolean negation
syntax: jmespath
value: '!disabled'

# Check for public visibility
syntax: jmespath
value: '!is_private'

# Active Directory disabled flag
syntax: jmespath
value: '!ACCOUNTDISABLE'

# Privileged account detection
syntax: jmespath
value: 'adminCount==`1`'

# Status code comparison
syntax: jmespath
value: 'Online == `11`'
```

### Conditional Mitigation Assignment

```yaml
# Single mitigation on condition
syntax: jmespath
value: 'isEncrypted && `M1041` || null'

# Return array if condition true
syntax: jmespath
value: 'av_enabled && [`M1049`]'

# Multiple mitigations on condition
syntax: jmespath
value: "health.overall == 'good' && [`M1040`, `M1049`] || null"

# Conditional with filter
syntax: jmespath
value: '[managedState == `1` && `M1051`] | [?@]'

# Multiple conditions, filter nulls
syntax: jmespath
value: >-
  [
    (isEncrypted && `M1041` || null),
    (sentinel.windowsDefender.antivirusEnabled && `M1049` || null)
  ]|[]
```

### String Join Operations

```yaml
# Join non-null values with space
syntax: jmespath
value: "join(' ', [type_fields.os, type_fields.os_version][?@])||null"

# Join with literal prefix
syntax: jmespath
value: "join(':', [`enterprise-attack`, mitreTactic])"

# Create composite key
syntax: jmespath
value: "join('_', [site.name, site.location])"

# Build hierarchy path
syntax: jmespath
value: "join('>', [ParentOrganizationName, ParentSiteName, Name])"

# Conditional prefixed ID
syntax: jmespath
value: "group.id && [join(':', [`NetBoxContactGroup`, to_string(group.id)])]"
```

### Complex Transformations

```yaml
# Prefix IDs, map array to strings, flatten
syntax: jmespath
value: "[user.id && join('', ['user_', to_string(user.id)]), group[*].id | map(&to_string(@), @)][]"

# Flatten, filter nulls, join with space
syntax: jmespath
value: "[os.id, os.version][] | [? @ != null] | join(' ', @)"

# Complex state-dependent timestamp selection
syntax: jmespath
value: "State.Name=='running' && x_utcnow || (contains(['pending','shutting-down'],State.Name) && UsageOperationUpdateTime) || null"

# Nested type conversions with fallback
syntax: jmespath
value: 'to_number(not_null(CVSS3_SCORE.CVSS3_TEMPORAL, CVSS3_SCORE.CVSS3_BASE, sum([to_number(SEVERITY), to_number(SEVERITY)])))'
```

### Validation Patterns

```yaml
# Multiple validation conditions
syntax: jmespath
value: "phoneNumber != '' && !contains(phoneNumber, '*') && phoneNumber || null"

# Non-empty and not placeholder
syntax: jmespath
value: "solution && solution != 'n/a'"

# Conditional with exclusion
syntax: jmespath
value: "remediation.recommendation.text != `None Provided` && remediation.recommendation.text || null"
```

### Value Mapping

```yaml
# Map numeric values to labels
syntax: jmespath
value: "(family.value | @==`4` && `v4` || @==`6` && `v6`)"

# Check if provider matches list
syntax: jmespath
value: '["Provider Name"][0] | @==`Amazon Web Services` || @==`Microsoft Azure`'
```

### Static Values

```yaml
# Static array with literal
syntax: jmespath
value: '[`ExposureType: Configuration`]'

# Single-element mitigation array
syntax: jmespath
value: '[`M1016`]'

# Explicit null (for deprecated properties)
syntax: jmespath
value: 'null'
```

---

## `expression` Syntax

A simple expression-substitution language where you can combine string values from existing properties. To learn more about this, see the [Python `f-strings` syntax documentation](https://docs.python.org/3/tutorial/inputoutput.html#tut-f-strings).

```yaml
# Simple property substitution
syntax: expression
value: '{id}'

# Combine multiple properties
syntax: expression
value: '{id} (from {source})'

# Create composite ID
syntax: expression
value: '{Key}_{Value}_{Type}'

# Build full name
syntax: expression
value: '{firstname} {lastname}'

# Create prefixed reference
syntax: expression
value: '{group_id}'

# Static value assignment
syntax: expression
value: 'Virtual Machine'
```

---

## Complete Examples

### Example: Combining Arrays for IP Fulfillment

When source data has separate properties for IPv4 and IPv6 addresses, use derived properties to combine them:

```yaml
x-samos-derived-properties:
  d_ips:
    # Combine IPv4 and IPv6 addresses into single array for Machine:ips
    x-samos-hidden: true
    type: array
    syntax: jmespath
    value: '[v4IpAddrs, v6IpAddrs][]'
    items:
      type: string
      format: ip-addr
    x-samos-fulfills:
      type-name: Machine
      property-name: ips
```

### Example: Qualified vs Unqualified Hostname Detection

```yaml
x-samos-derived-properties:
  d_qualified_hostname:
    x-samos-hidden: true
    type: string
    syntax: jmespath
    value: 'hostname && contains(hostname, `.`) && hostname || null'
    x-samos-correlation:
      correlation-key: Machine.qualified-hostname
      correlation-type: Machine
      priority: 2

  d_unqualified_hostname:
    x-samos-hidden: true
    type: string
    syntax: jmespath
    value: 'hostname && !contains(hostname, `.`) && hostname || null'
    x-samos-correlation:
      correlation-key: Machine.unqualified-hostname
      correlation-type: Machine
      priority: 2
```

### Example: Conditional Mitigation Assignment

```yaml
x-samos-derived-properties:
  d_mitigations:
    x-samos-hidden: true
    type: array
    items:
      type: string
      x-samos-ref-types:
        - type-name: Mitigation
          key-name: id
    syntax: jmespath
    # M1041 - Encrypt Sensitive Information
    # M1049 - Antivirus/Antimalware
    value: >-
      [
        (isEncrypted && `M1041` || null),
        (sentinel.windowsDefender.antivirusEnabled && `M1049` || null)
      ]|[]
    x-samos-fulfills:
      type-name: core.component
      property-name: mitigations
```

### Example: Type Casting for ID Fulfillment

```yaml
x-samos-derived-properties:
  d_id:
    # The "id" property is an integer in the response
    # Derived to string type to fulfill 'core.component.id'
    type: string
    syntax: jmespath
    value: to_string(id)
    x-samos-hidden: true
    x-samos-immutable: true
    x-samos-fulfills:
      type-name: core.component
      property-name: id
```

### Example: Boolean Active Status from Integer

```yaml
x-samos-derived-properties:
  d_active:
    # The "status" property is 1 (active) or 2 (inactive)
    title: Active?
    type: boolean
    value: 'status == `1`'
    syntax: jmespath
    x-samos-fulfills:
      type-name: core.principal
      property-name: active
```

### Example: Splitting Comma-Separated Values

```yaml
x-samos-derived-properties:
  d_content:
    # The "content" property is a comma-separated string
    # Derive to array for proper handling
    title: Content List
    type: array
    syntax: jsonpath
    value: '$.content.`splitlist(,, string)`'
    items:
      type: string
```

### Example: Extracting Resource Group from Azure ID

```yaml
x-samos-derived-properties:
  d_resource_group:
    title: Azure Resource Group
    type: string
    syntax: jsonpath
    value: '$.id.`sub(/((.+?(?=\/)){4}).*/, \\1)`.`casefold()`'
    x-samos-fulfills:
      type-name: core.component
      property-name: is_part_of_ref
    x-samos-ref-types:
      - type-name: AzureResourceGroup
        key-name: d_canonicalized_id
```