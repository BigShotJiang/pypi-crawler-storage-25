
import logging

from r7_surcom_sdk.lib import SurcomSDKException, SurcomAPI, constants, sdk_helpers, sdk_config
from r7_surcom_sdk.lib.sdk_argparse import Args
from r7_surcom_sdk.lib.sdk_cmd import SurcomSDKSubCommand
from r7_surcom_sdk.lib.sdk_terminal_fonts import colors, fmt, formats

LOG = logging.getLogger(constants.LOGGER_NAME)


class DeleteCommand(SurcomSDKSubCommand):
    """
    [help]
    Delete type data from {PRODUCT_NAME}.
    ---

    [description]
    This command deletes type data from {PRODUCT_NAME}.

You can specify data to delete by Import feed ID or Connector ID, or you can delete all tutorial data.

When using a Connector ID, only data imported by invoking the connector with the SDK will be deleted.

WARNING: This operation is destructive and cannot be undone.
    ---

    [usage]
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD} -i 'sys.surcom.sdk.import.data.2026-03-23T12:09:33.699529'
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD} -id 'demo.connector'
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD} --tutorial --dry-run -y
    ---
    """
    def __init__(self, data_parser):

        self.cmd_name = constants.CMD_DATA
        self.sub_cmd_name = constants.CMD_DELETE

        cmd_docstr = self.__doc__.format(
            PLATFORM_NAME=constants.PLATFORM_NAME,
            PROGRAM_NAME=constants.PROGRAM_NAME,
            PRODUCT_NAME=constants.PRODUCT_NAME,
            COMMAND=self.cmd_name,
            SUB_CMD=self.sub_cmd_name
        )

        super().__init__(
            parent=data_parser,
            cmd_name=self.sub_cmd_name,
            cmd_docstr=cmd_docstr
        )

        self.cmd_parser.add_argument(
            "-i", "--import-feed-id",
            help="ID of the import-feed with data to delete.",
        )

        self.cmd_parser.add_argument(
            "-id", "--connector-id",
            help="ID of the connector that was invoked with the SDK.",
        )

        self.cmd_parser.add_argument(
            "--dry-run",
            help="Show what would be deleted without actually deleting.",
            action="store_true"
        )

        self.cmd_parser.add_argument(*Args.yes.flag, **Args.yes.kwargs)

        self.cmd_parser.add_argument(
            "--tutorial",
            help="Delete any tutorial data - "
                 "specifically any data imported while invoking the demo.connector with the SDK.",
            action="store_true"
        )

    def _reset_import_feed(
        self,
        args,
        surcom_client: SurcomAPI,
        import_feed_id: str
    ) -> str:

        sdk_helpers.print_log_msg(
            f"Attempting to reset import feed: '{import_feed_id}'...",
            log_color=colors.OKBLUE
        )

        if args.dry_run:
            warning = fmt("All data in this import feed would be "
                          "deleted if you ran this command without the '--dry-run' flag.", colors.WARNING)
            sdk_helpers.print_log_msg(f"{warning}")
            return None

        # 1. Create an empty batch for that import feed
        batch_id = surcom_client.import_batch_create(import_id=import_feed_id)

        # 2. Run the import workflow with an empty batch that will delete all
        # data associated with that import feed id
        execution_id = surcom_client.run_import_workflow(import_id=import_feed_id, batch_id=batch_id)

        LOG.debug(f"Started import workflow with execution ID '{execution_id}'")

        return execution_id

    def _wait_for_workflow_and_print_logs(
        self,
        surcom_client: SurcomAPI,
        execution_id: str,
        import_id: str
    ):
        # Wait for the workflow to complete and print logs while we wait
        surcom_client.print_workflow_logs(execution_id=execution_id, only_user_msgs=True)

        sdk_helpers.print_log_msg(
            f"Finished deleting data associated with import feed ID '{import_id}'",
            log_color=colors.OKGREEN
        )

    def _delete_data_for_connector_id(
        self,
        args,
        surcom_client: SurcomAPI,
        connector_id: str
    ):

        sdk_helpers.print_log_msg(f"Attempting to delete data for connector '{connector_id}'...")

        # Get unique import feed ids associated with the connector
        import_feeds = surcom_client.get_import_feeds_for_connector(
            connector_id=connector_id
        )

        if not import_feeds:
            sdk_helpers.print_log_msg(
                f"No data found for '{connector_id}'. Nothing to delete.", log_color=colors.OKGREEN)
            return

        for import_id in import_feeds:

            execution_id = self._reset_import_feed(args, surcom_client=surcom_client, import_feed_id=import_id)

            if not execution_id:
                continue

            self._wait_for_workflow_and_print_logs(
                surcom_client=surcom_client,
                execution_id=execution_id,
                import_id=import_id
            )

    def run(self, args):
        SurcomSDKException.command_ran = f"{self.cmd_name} {self.sub_cmd_name}"

        sdk_helpers.print_log_msg(
            f"Deleting data from {constants.PRODUCT_NAME}",
            divider=True
        )

        # Check that exactly one of the mutually exclusive options is provided
        options_provided = sum([
            bool(args.import_feed_id),
            bool(args.connector_id),
            bool(args.tutorial)
        ])

        if options_provided == 0:
            raise SurcomSDKException(
                "You must specify at least one of the following options: "
                "--import-feed-id, --connector-id, or --tutorial"
            )

        if options_provided > 1:
            raise SurcomSDKException(
                "Only one of --import-feed-id, --connector-id, or --tutorial can be specified at a time"
            )

        connection = sdk_config.get_default_connection(prompt=True, default_to_yes=args.yes)

        surcom_client = SurcomAPI(
            base_url=connection.url,
            api_key=connection.api_key,
            user_agent_str="data delete command"
        )

        if args.import_feed_id:

            # Check if the import feed ID exists before attempting to reset it

            if not surcom_client.does_import_feed_exist(args.import_feed_id):
                raise SurcomSDKException(
                    f"Import feed ID '{args.import_feed_id}' does not exist. Please provide a valid import feed ID."
                )

            execution_id = self._reset_import_feed(
                args=args,
                surcom_client=surcom_client,
                import_feed_id=args.import_feed_id
            )

            if not execution_id:
                return

            self._wait_for_workflow_and_print_logs(
                surcom_client=surcom_client,
                execution_id=execution_id,
                import_id=args.import_feed_id
            )

        if args.connector_id or args.tutorial:

            connector_id = args.connector_id if args.connector_id else "demo.connector"

            self._delete_data_for_connector_id(
                args=args,
                surcom_client=surcom_client,
                connector_id=connector_id
            )

        if not args.dry_run:
            sdk_helpers.print_log_msg(
                f"Successfully deleted all data for '{args.import_feed_id or connector_id}' "
                f"from {constants.PRODUCT_NAME}",
                log_color=colors.OKGREEN,
                log_format=formats.BOLD
            )

        sdk_helpers.print_log_msg(f"Finished running the '{self.sub_cmd_name}' command", divider=True)
