import configparser
import logging

from r7_surcom_sdk.lib import (SurcomSDKException, constants, sdk_config,
                               sdk_helpers, agent_skills_helpers)
from r7_surcom_sdk.lib.sdk_cmd import SurcomSDKSubCommand
from r7_surcom_sdk.lib.sdk_terminal_fonts import fmt, formats, colors

LOG = logging.getLogger(constants.LOGGER_NAME)


class InitCommand(SurcomSDKSubCommand):
    """
    [help]
    Create an initial {CONFIG_FILE_NAME} file if one doesn't exist.
    ---

    [description]
    Create an initial configuration file and prompt for details of a new
connection. If a configuration file already exists, show details of the
active connection.
    ---

    [usage]
    $ {PROGRAM_NAME} {COMMAND} {SUB_CMD}
    ---
    """
    def __init__(self, connectors_parser):

        self.cmd_name = constants.CMD_CONFIG
        self.sub_cmd_name = constants.CMD_INIT

        cmd_docstr = self.__doc__.format(
            PROGRAM_NAME=constants.PROGRAM_NAME,
            CONFIG_FILE_NAME=constants.CONFIG_FILE_NAME,
            COMMAND=self.cmd_name,
            SUB_CMD=self.sub_cmd_name
        )

        super().__init__(
            parent=connectors_parser,
            cmd_name=self.sub_cmd_name,
            cmd_docstr=cmd_docstr)

    def run(self, args, cmd_test_connection=None):
        SurcomSDKException.command_ran = f"{self.cmd_name} {self.sub_cmd_name}"

        sdk_helpers.print_log_msg(f"Initializing the {constants.FULL_PROGRAM_NAME}", divider=True)

        configs = sdk_config.get_configs(constants.PATH_SURCOM_CONFIG_FILE)

        if not configs:

            sdk_helpers.print_log_msg(
                "No configuration file found so we will create one!",
                log_level=logging.WARNING
            )

            ws_prompt = fmt("Enter the path to your Connectors Workspace (optional)", f=formats.BOLD)

            ws_prompt_note = fmt(
                'This is where Connectors are created when running `surcom connector init`',
                f=formats.ITALIC
            )

            path_connector_ws = sdk_helpers.get_cli_input(
                prompt=f"{ws_prompt}\n{ws_prompt_note}",
                default=constants.CONFIG_DEFAULT_CONNECTOR_DEV
            )

            conn = sdk_config.prompt_for_new_connection(initial_prompt=True)

            config = configparser.ConfigParser()

            config.add_section(constants.CONFIG_SEC_MAIN)
            config.set(constants.CONFIG_SEC_MAIN, constants.CONFIG_NAME_PATH_CONNECTOR_WS, path_connector_ws)

            config.add_section(conn.name)
            config.set(conn.name, constants.CONFIG_NAME_URL, conn.original_url)
            config.set(conn.name, constants.CONFIG_NAME_API_KEY, conn.api_key)
            config.set(conn.name, constants.CONFIG_NAME_ACTIVE, str(conn.default))

            sdk_config.write_config_file(config=config)

            install_skills = sdk_helpers.prompt_to_confirm(
                f'''\n{fmt("Do you want to copy our Agent Skills to "
                "'~/.agents/skills'?", f=formats.BOLD)} (y/n)''',
                raise_exception=False,
                add_continue_to_prompt=False
            )

            if install_skills:
                agent_skills_helpers.install_agent_skills()

                sdk_helpers.print_log_msg(
                    "Agent Skills have been installed. You can find them in '~/.agents/skills'",
                    log_color=colors.OKGREEN
                )

        else:
            sdk_helpers.print_log_msg(f"The {constants.FULL_PROGRAM_NAME} is already configured",
                                      log_level=logging.WARNING)

            sdk_helpers.print_log_msg(f"Configuration file: '{constants.PATH_SURCOM_CONFIG_FILE}'")

            path_connector_ws = configs[constants.CONFIG_SEC_MAIN][constants.CONFIG_NAME_PATH_CONNECTOR_WS]
            sdk_helpers.print_log_msg(f"Connector workspace: '{path_connector_ws}'")

            default_connection = sdk_config.get_default_connection(constants.PATH_SURCOM_CONFIG_FILE)

            sdk_helpers.print_log_msg(f"Active connection:\n\n{default_connection}")

        sdk_helpers.print_log_msg(
            f"Finished running the '{self.sub_cmd_name}' command.\n\nTest the active connection with:\n"
            "> surcom config test",
            divider=True
        )

        run_test = sdk_helpers.prompt_to_confirm(
            f'''\n{fmt("Do you want to run 'surcom config test' to test your active connection now?",
                       f=formats.BOLD)} (y/n)''',
            raise_exception=False,
            add_continue_to_prompt=False
        )
        if run_test:
            cmd_test_connection.run(args)
