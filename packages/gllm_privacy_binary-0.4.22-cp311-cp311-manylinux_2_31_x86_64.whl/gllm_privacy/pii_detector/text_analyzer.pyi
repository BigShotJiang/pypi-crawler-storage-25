from _typeshed import Incomplete
from collections.abc import Awaitable
from gllm_privacy.pii_detector.analyzer import BaseTextAnalyzer as BaseTextAnalyzer
from gllm_privacy.pii_detector.constants import RecognizerResult as RecognizerResult
from gllm_privacy.pii_detector.custom_lemma_context_aware_enhancer import CustomLemmaContextAwareEnhancer as CustomLemmaContextAwareEnhancer
from gllm_privacy.pii_detector.recognizer import BPJSNumberRecognizer as BPJSNumberRecognizer, BankAccountNumberRecognizer as BankAccountNumberRecognizer, CreditCardRecognizer as CreditCardRecognizer, FacebookAccountRecognizer as FacebookAccountRecognizer, FamilyCardNumberRecognizer as FamilyCardNumberRecognizer, GDPLabsEmployeeIdRecognizer as GDPLabsEmployeeIdRecognizer, IndonesianPhoneNumberRecognizer as IndonesianPhoneNumberRecognizer, KTPRecognizer as KTPRecognizer, LinkedinAccountRecognizer as LinkedinAccountRecognizer, MoneyRecognizer as MoneyRecognizer, NPWPRecognizer as NPWPRecognizer, OrganizationNameRecognizer as OrganizationNameRecognizer, ProjectNameRecognizer as ProjectNameRecognizer
from gllm_privacy.pii_detector.utils.spacy_model_loader import ensure_spacy_model as ensure_spacy_model
from presidio_analyzer import EntityRecognizer
from presidio_analyzer.nlp_engine import NlpArtifacts
from typing import Any, Sequence

DEFAULT_NLP_CONFIGURATION: Incomplete
MAX_PII_TEXT_LENGTH: int

class _AsyncAwaitableRunner:
    """Run awaitables on a dedicated background event loop.

    This helper keeps one persistent loop in a daemon thread so synchronous
    code can await async recognizer outputs without creating a new event loop
    per call.
    """
    def __init__(self) -> None:
        """Start the background event loop thread and wait until ready."""
    def run(self, awaitable: Awaitable[Any]) -> Any:
        """Resolve an awaitable on the background loop.

        Args:
            awaitable (Awaitable[Any]): Awaitable object to execute.

        Returns:
            Any: Result produced by the awaitable.

        Raises:
            RuntimeError: If the background loop is not initialized.
        """
    def close(self) -> None:
        """Stop the background loop thread and release loop resources."""

class _SyncAwaitableEntityRecognizerProxy(EntityRecognizer):
    """Proxy wrapper for additional recognizers with awaitable outputs.

    The proxy preserves recognizer metadata expected by Presidio while
    converting awaitable outputs from `analyze` into synchronous values.
    """
    is_loaded: Incomplete
    def __init__(self, recognizer: EntityRecognizer) -> None:
        """Initialize proxy from an existing recognizer instance.

        Args:
            recognizer (EntityRecognizer): Wrapped recognizer.
        """
    def load(self) -> None:
        """Load wrapped recognizer when needed."""
    def analyze(self, text: str, entities: list[str], nlp_artifacts: NlpArtifacts) -> list[RecognizerResult]:
        """Analyze text via wrapped recognizer and normalize async outputs.

        Args:
            text (str): Input text to analyze.
            entities (list[str]): Entities to detect.
            nlp_artifacts (NlpArtifacts): NLP artifacts from Presidio pipeline.

        Returns:
            list[RecognizerResult]: Analysis results from the wrapped recognizer.
        """
    def enhance_using_context(self, text: str, raw_recognizer_results: list[RecognizerResult], other_raw_recognizer_results: list[RecognizerResult], nlp_artifacts: NlpArtifacts, context: list[str] | None = None) -> list[RecognizerResult]:
        """Delegate context-based score enhancement to wrapped recognizer.

        Args:
            text (str): Input text.
            raw_recognizer_results (list[RecognizerResult]): Results from this recognizer.
            other_raw_recognizer_results (list[RecognizerResult]): Results from other recognizers.
            nlp_artifacts (NlpArtifacts): NLP artifacts from Presidio pipeline.
            context (list[str] | None): Optional external context words.

        Returns:
            list[RecognizerResult]: Enhanced recognizer results.
        """

class TextAnalyzer(BaseTextAnalyzer):
    """TextAnalyzer class to analyze the text and extract the PII entities.

    Implemented using presidio pii library.

    Additional recognizers with `async def analyze(...)` are wrapped so the
    public `analyze` method remains synchronous.

    Attributes:
        analyzer (AnalyzerEngine): The analyzer engine to analyze the text and extract the PII entities.
    """
    analyzer: Incomplete
    def __init__(self, additional_recognizers: Sequence[EntityRecognizer] | None = None, nlp_configuration: dict[str, Any] | None = None) -> None:
        """Initialize the TextAnalyzer class and add custom recognizer.

        The predefined recognizers are BankAccountNumberRecognizer, BPJSNumberRecognizer,
        IndonesianPhoneNumberRecognizer, GDPLabsEmployeeIdRecognizer, FacebookAccountRecognizer,
        FamilyCardNumberRecognizer, KTPRecognizer, LinkedinAccountRecognizer, MoneyRecognizer, NPWPRecognizer,
        OrganizationNameRecognizer, and ProjectNameRecognizer.
        We also add Presidio EmailRecognizer and PhoneRecognizer for Indonesian language.

        Args:
            additional_recognizers (Sequence[EntityRecognizer] | None, optional): The list of additional recognizers
                    to be added. Default is None.
                    Async recognizers are wrapped internally to support sync analysis flow.
            nlp_configuration (dict[str, Any] | None, optional): The configuration for the NLP engine
                    see https://microsoft.github.io/presidio/analyzer/customizing_nlp_models/. Default is None.
        """
    def analyze(self, text: str, language: str = 'id', entities: list[str] | None = None, score_threshold: float | None = 0.46, allow_list: list[str] | None = None, allow_list_match: str | None = 'exact', regex_flags: int | None = ..., **kwargs: Any) -> list[RecognizerResult]:
        '''Analyze the text and extract the PII entities.

        The method intentionally stays synchronous for backward compatibility.
        If an additional recognizer returns an awaitable result, it is resolved
        through an internal background event loop.

        Note:
            This method blocks the caller thread. In async application flows,
            call this method from a worker thread.

        Args:
            text (str): The text to be analyzed.
            language (str, optional): The language of the text to be analyzed. Default is "id".
            entities (list[str]|None, optional): The list of entities to be extracted. If you need to extract
                other entities, add the recognizer in the constructor. Default is None.
            score_threshold (float|None, optional): The minimum score threshold for the extracted entities.
                Default is 0.46.
            allow_list (list | None, optional): List of words that the user defines as being allowed to keep in
                the text. Default is None.
            allow_list_match (str | None, optional): The matching strategy for the allow list. Default is "exact".
            regex_flags (int | None, optional): The regex flags for the text analysis.
            **kwargs (Any): Additional keyword arguments that may be needed for the text analysis process.

        Returns:
            list[RecognizerResult]: The list of extracted entities
        '''
