from _typeshed import Incomplete
from gllm_privacy.pii_detector.constants import GLLM_PRIVACY_ENTITIES as GLLM_PRIVACY_ENTITIES, RecognizerResult as RecognizerResult
from presidio_analyzer import AnalysisExplanation, RemoteRecognizer
from presidio_analyzer.nlp_engine import NlpArtifacts
from typing import Any

manager: Incomplete
logger: Incomplete

class GDPLabsNerApiRemoteRecognizerBase(RemoteRecognizer):
    """Base class for GDPLabs NER API remote recognizers.

    Provides shared utility methods for converting NER API responses
    to Presidio RecognizerResult objects.

    Attributes:
        DEFAULT_EXPLANATION (str): Default explanation format for analysis results.
        api_endpoint (str): Full URL of the NER API endpoint.
        api_headers (dict): Headers for API requests.
        supported_entities (list[str]): Supported entity types.
        supported_language (str): Supported language.
    """
    DEFAULT_EXPLANATION: str
    api_endpoint: Incomplete
    api_headers: Incomplete
    def __init__(self, api_url: str, supported_entities: list[str] | None = None, api_headers: dict[str, str] | None = None, supported_language: str = 'en') -> None:
        '''Initialize the base recognizer.

        Args:
            api_url (str): Full URL of the NER API endpoint.
            supported_entities (list[str] | None): Supported entity types.
                Defaults to GLLM_PRIVACY_ENTITIES.
            api_headers (dict[str, str] | None): Headers for API requests.
            supported_language (str): Supported language. Defaults to "en".
        '''
    def get_supported_entities(self) -> list[str]:
        """Get the list of supported entities for the recognizer.

        Returns:
            list[str]: List of supported entity types.
        """
    @staticmethod
    def convert_response_to_recognizer_result(entities: list[str] | None, ner_results: dict[str, Any], recognizer_name: str, default_explanation: str) -> list[RecognizerResult]:
        """Convert NER API response to a list of RecognizerResults.

        Args:
            entities (list[str] | None): List of entity types to filter.
                If None, all entities are included.
            ner_results (dict[str, Any]): NER API response containing entities.
            recognizer_name (str): Name of the recognizer for analysis explanation.
            default_explanation (str): Explanation format string.

        Returns:
            list[RecognizerResult]: List of RecognizerResults.
        """
    @staticmethod
    def build_analysis_explanation(recognizer_name: str, score: float, explanation: str) -> AnalysisExplanation:
        """Build an AnalysisExplanation object.

        Args:
            recognizer_name (str): Name of the recognizer.
            score (float): Score given by the recognizer.
            explanation (str): Explanation of the analysis.

        Returns:
            AnalysisExplanation: Analysis explanation object.
        """

class GDPLabsNerApiRemoteRecognizer(GDPLabsNerApiRemoteRecognizerBase):
    """Synchronous Remote NER Recognizer that calls an external NER API.

    Attributes:
        api_timeout (float): Timeout for API request in seconds.
    """
    api_timeout: Incomplete
    def __init__(self, api_url: str, supported_entities: list[str] | None = None, api_headers: dict[str, str] | None = None, api_timeout: float = 60.0, supported_language: str = 'en') -> None:
        '''Initialize a Remote NER Recognizer that calls an external NER API.

        Args:
            api_url (str): Full URL of the NER API endpoint.
            supported_entities (list[str] | None): List of entity types supported.
                Defaults to GLLM_PRIVACY_ENTITIES.
            api_headers (dict[str, str] | None): Headers for API requests.
            api_timeout (float): Timeout for API request in seconds. Defaults to 60.0.
            supported_language (str): Language supported. Defaults to "en".
        '''
    def analyze(self, text: str, entities: list[str] | None = None, nlp_artifacts: NlpArtifacts | None = None) -> list[RecognizerResult]:
        """Analyze text using the remote NER API.

        Args:
            text (str): Input text to analyze.
            entities (list[str] | None): Entity types to recognize. Defaults to None.
            nlp_artifacts (NlpArtifacts | None): NLP artifacts. Defaults to None.

        Returns:
            list[RecognizerResult]: List of RecognizerResults.
        """

class GDPLabsNerApiRemoteRecognizerAsync(GDPLabsNerApiRemoteRecognizerBase):
    """Async Remote NER Recognizer with mTLS support.

    Uses httpx for async HTTP requests with native mTLS support.

    Attributes:
        api_timeout (float): Total request timeout in seconds. Defaults to 60.0.
        connect_timeout (float): Connection timeout in seconds. Defaults to 10.0.
        max_connections (int): Maximum concurrent connections.
        max_keepalive_connections (int): Maximum keepalive connections.
        keepalive_expiry (float): Keepalive expiry in seconds.
        DEFAULT_EXPLANATION (str): Default explanation for results.
    """
    DEFAULT_EXPLANATION: str
    api_timeout: Incomplete
    api_connect_timeout: Incomplete
    max_connections: Incomplete
    max_keepalive_connections: Incomplete
    keepalive_expiry: Incomplete
    def __init__(self, api_url: str, supported_entities: list[str] | None = None, api_headers: dict[str, str] | None = None, api_timeout: float = 60.0, api_connect_timeout: float = 10.0, max_connections: int = 10, max_keepalive_connections: int = 5, keepalive_expiry: float = 30.0, supported_language: str = 'en', client_cert_path: str | None = None, client_key_path: str | None = None, ca_cert_path: str | None = None) -> None:
        '''Initialize the async NER recognizer.

        Args:
            api_url (str): Full URL of the NER API endpoint.
            supported_entities (list[str] | None): Supported entity types.
                Defaults to GLLM_PRIVACY_ENTITIES.
            api_headers (dict[str, str] | None): Headers for API requests.
            api_timeout (float): Total request timeout in seconds. Defaults to 60.0.
            api_connect_timeout (float): Connection timeout in seconds. Defaults to 10.0.
            max_connections (int): Maximum concurrent connections. Defaults to 10.
            max_keepalive_connections (int): Maximum keepalive connections. Defaults to 5.
            keepalive_expiry (float): Keepalive expiry in seconds. Defaults to 30.0.
            supported_language (str): Language code. Defaults to "en".
            client_cert_path (str | None): Path to mTLS client certificate.
            client_key_path (str | None): Path to mTLS client private key.
            ca_cert_path (str | None): Path to CA certificate for server verification.

        Raises:
            ValueError: If only one of client certificate or key path is provided.
        '''
    async def close(self) -> None:
        """Close the cached HTTP client and reset loop ownership state."""
    async def analyze(self, text: str, entities: list[str] | None = None, nlp_artifacts: NlpArtifacts | None = None) -> list[RecognizerResult]:
        """Analyze text asynchronously using the remote NER API.

        Args:
            text (str): Input text to analyze.
            entities (list[str] | None): Entity types to recognize. Defaults to None.
            nlp_artifacts (NlpArtifacts | None): NLP artifacts. Defaults to None.

        Returns:
            list[RecognizerResult]: List of RecognizerResults.
        """
    async def __aenter__(self) -> GDPLabsNerApiRemoteRecognizerAsync:
        """Async context manager entry."""
    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
