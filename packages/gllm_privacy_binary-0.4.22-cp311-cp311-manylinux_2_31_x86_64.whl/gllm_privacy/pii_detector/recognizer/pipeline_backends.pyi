from _typeshed import Incomplete
from dataclasses import dataclass
from typing import Any

manager: Incomplete
logger: Incomplete
BACKEND_AUTO: str
BACKEND_MPS: str
BACKEND_TRANSFORMERS: str
BACKEND_ONNX: str
BACKEND_CUDA: str
BACKEND_OPENVINO: str
DEVICE_AUTO: str
DEVICE_MPS: str
DEVICE_CUDA: str
DEVICE_CPU: str
ERR_TRANSFORMERS_NOT_INSTALLED: str

@dataclass(frozen=True)
class BackendCapabilities:
    """Availability of optional pipeline backends and providers."""
    transformers: bool
    onnx_cpu: bool
    onnx_cuda: bool
    openvino: bool
    available_providers: tuple[str, ...]

def get_backend_capabilities() -> BackendCapabilities:
    """Detect backend capabilities with lazy imports."""

class OptimumPipelineManager:
    """Manages different pipeline backends for optimal performance.

    This class handles the creation and management of different pipeline types:
    - NVIDIA TensorRT-LLM (via optimum-nvidia) for maximum GPU performance
    - ONNX Runtime for CPU optimization
    - Standard transformers as fallback

    Attributes:
        backend (str): The current backend being used.
        pipeline: The active pipeline instance.
        config (dict): Configuration for the pipeline.
    """
    config: Incomplete
    backend: Incomplete
    pipeline: Incomplete
    model: Incomplete
    def __init__(self, config: dict[str, Any]) -> None:
        """Initialize the pipeline manager.

        Args:
            config (dict): Configuration dictionary containing Optimum settings.
        """
    def create_pipeline(self, model_path: str, tokenizer, aggregation_strategy: str = 'simple', ignore_labels: list | None = None) -> None:
        """Create a pipeline with the optimal backend.

        Args:
            model_path (str): Path to the model.
            tokenizer: The tokenizer instance.
            aggregation_strategy (str): Strategy for aggregating sub-word tokens.
            ignore_labels (list): Labels to ignore during inference.
        """
    def get_pipeline(self) -> Any:
        """Get the current pipeline instance."""
    def get_backend_info(self) -> dict[str, Any]:
        """Get information about the current backend."""
