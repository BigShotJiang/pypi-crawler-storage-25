from _typeshed import Incomplete
from gllm_privacy.pii_detector.constants import Entities as Entities
from presidio_analyzer import PatternRecognizer

URL_PATTERN: Incomplete

class ProjectNameRecognizer(PatternRecognizer):
    '''Recognize Project name using regex pattern.

    Project name start with "Project" or contain specific terms like GDP Labs, Catapa, GLAIR, KASKUS, Project E, BOSA,
    SWISS.
    '''
    PATTERNS: Incomplete
    def __init__(self, supported_language: str = 'id', additional_project_names: list[str] | None = None) -> None:
        '''Initialize ProjectNameRecognizer.

        Args:
            supported_language (str, optional): The supported language for the recognizer. Default is "id".
            additional_project_names (list[str], optional): List of additional project names to be recognized.
                    Default is None.
        '''
    def analyze(self, text: str, entities: list[str], nlp_artifacts=None, regex_flags: int | None = None):
        """Analyze text and drop project-name matches which fall inside URLs.

        Presidio deny-list matching can detect known project names inside URL hostnames,
        such as ``https://catapa-...``. Those hits are false positives for this recognizer,
        so results overlapping URL spans are filtered out after the base pattern analysis.

        Args:
            text (str): Text to analyze.
            entities (list[str]): Requested entities.
            nlp_artifacts: Optional NLP artifacts passed through to Presidio.
            regex_flags (int | None): Optional regex flags used by Presidio.

        Returns:
            list: Project-name recognizer results excluding URL-overlapping matches.
        """
