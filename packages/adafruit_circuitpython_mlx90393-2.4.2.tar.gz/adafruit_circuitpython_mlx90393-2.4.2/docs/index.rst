.. include:: ../README.rst

Table of Contents
=================

.. toctree::
    :maxdepth: 4
    :hidden:

    self

.. toctree::
    :caption: Examples

    examples

.. toctree::
    :caption: API Reference
    :maxdepth: 3

    api

.. toctree::
    :caption: Tutorials

    Adafruit Wide-Range Triple-axis Magnetometer - MLX90393 Learning Guide <https://learn.adafruit.com/mlx90393-wide-range-3-axis-magnetometer>

.. toctree::
    :caption: Related Products

    Adafruit Wide-Range Triple-axis Magnetometer - MLX90393 <https://www.adafruit.com/product/4022>

.. toctree::
    :caption: Other Links

    Download from GitHub <https://github.com/adafruit/CircuitPython_Adafruit_CircuitPython_MLX90393/releases/latest>
    Download Library Bundle <https://circuitpython.org/libraries>
    CircuitPython Reference Documentation <https://docs.circuitpython.org>
    CircuitPython Support Forum <https://forums.adafruit.com/viewforum.php?f=60>
    Discord Chat <https://adafru.it/discord>
    Adafruit Learning System <https://learn.adafruit.com>
    Adafruit Blog <https://blog.adafruit.com>
    Adafruit Store <https://www.adafruit.com>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
