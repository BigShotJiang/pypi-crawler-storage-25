"""Tests for tool layer and shared utilities."""

from unittest.mock import MagicMock, patch

import pytest

from peekaboowin.tools._common import handle_tool_error, tool_error_handler
from peekaboowin.errors import PeekabooWinError, InvalidParamsError, ToolError, ElementNotFoundError
from peekaboowin.tools import screen, clipboard as tool_clipboard, window as tool_window
from peekaboowin.server import _setup_logging, _auto_enable_ocr, _register_tools


# ==================== _common.py ====================

class TestHandleToolError:
    def test_peekaboo_win_error_returns_dict(self):
        err = PeekabooWinError(message="test", error_code="T001")
        result = handle_tool_error(err, "test_tool")
        assert result["error"] is True
        assert result["error_code"] == "T001"

    def test_generic_exception_wrapped(self):
        err = ValueError("something bad")
        result = handle_tool_error(err, "test_tool")
        assert result["error"] is True
        assert result["error_code"] == "TOOL_ERROR"
        assert "suggestions" in result["details"]

    def test_element_not_found_passthrough(self):
        err = ElementNotFoundError(element_description="test")
        result = handle_tool_error(err, "test_tool")
        assert result["error_code"] == "ELEMENT_NOT_FOUND"


class TestToolErrorHandler:
    def test_wrapper_passes_through_success(self):
        @tool_error_handler("test_tool")
        def my_tool(x: int) -> int:
            return x * 2

        assert my_tool(5) == 10

    def test_wrapper_catches_invalid_params(self):
        @tool_error_handler("test_tool")
        def my_tool():
            raise InvalidParamsError(message="bad param", tool_name="test_tool")

        result = my_tool()
        assert result["error_code"] == "INVALID_PARAMS"

    def test_wrapper_catches_generic_error(self):
        @tool_error_handler("test_tool")
        def my_tool():
            raise RuntimeError("unexpected")

        result = my_tool()
        assert result["error_code"] == "TOOL_ERROR"


# ==================== Tools ====================

class TestScreenTool:
    def test_screenshot_delegates_to_service(self):
        with patch("peekaboowin.tools.screen.get_screen_service") as mock_svc:
            mock_svc.return_value.take_screenshot.return_value = {"image": "data"}
            result = screen.screenshot()
            assert result["image"] == "data"

    def test_list_monitors(self):
        with patch("peekaboowin.tools.screen.get_screen_service") as mock_svc:
            mock_svc.return_value.get_monitors.return_value = [{"id": 0}]
            result = screen.list_monitors()
            assert len(result) == 1


class TestClipboardTool:
    def test_read_clipboard(self):
        with patch("peekaboowin.tools.clipboard.get_clipboard_service") as mock_svc:
            mock_svc.return_value.read_clipboard.return_value = "hello"
            result = tool_clipboard.read_clipboard()
            assert result == {"success": True, "text": "hello"}

    def test_write_clipboard(self):
        with patch("peekaboowin.tools.clipboard.get_clipboard_service") as mock_svc:
            mock_svc.return_value.write_clipboard.return_value = None
            tool_clipboard.write_clipboard(text="hello")


class TestWindowTool:
    def test_list_windows(self):
        with patch("peekaboowin.tools.window.get_window_service") as mock_svc:
            mock_svc.return_value.list_windows.return_value = {"windows": []}
            result = tool_window.list_windows()
            assert "windows" in result

    def test_get_foreground_window(self):
        with patch("peekaboowin.tools.window.get_window_service") as mock_svc:
            mock_svc.return_value.get_foreground_window.return_value = {"hwnd": 100}
            result = tool_window.get_foreground_window()
            assert result["hwnd"] == 100

    def test_close_window(self):
        with patch("peekaboowin.tools.window.get_window_service") as mock_svc:
            mock_svc.return_value.close_window.return_value = {"success": True}
            result = tool_window.close_window(hwnd=100)
            assert result["success"] is True


# ==================== server.py ====================

class TestServer:
    def test_setup_logging_json_default(self):
        with patch("peekaboowin.server.get_config") as mock_config:
            mock_config.return_value.log_format = "json"
            mock_config.return_value.log_level = "info"
            with patch("structlog.configure") as mock_cfg:
                _setup_logging()
                assert mock_cfg.called

    def test_setup_logging_console(self):
        with patch("peekaboowin.server.get_config") as mock_config:
            mock_config.return_value.log_format = "console"
            mock_config.return_value.log_level = "debug"
            with patch("structlog.configure") as mock_cfg:
                _setup_logging()
                assert mock_cfg.called

    def test_auto_enable_ocr_paddleocr_installed(self):
        with patch("peekaboowin.server.get_config") as mock_config:
            config_mock = MagicMock()
            config_mock.ocr_enabled = False
            mock_config.return_value = config_mock
            _auto_enable_ocr()
            # paddleocr is actually installed, so it should set enabled
            assert config_mock.set_ocr_enabled.called

    def test_auto_enable_ocr_already_enabled(self):
        with patch("peekaboowin.server.get_config") as mock_config:
            config_mock = MagicMock()
            config_mock.ocr_enabled = True
            mock_config.return_value = config_mock
            with patch("peekaboowin.server.structlog.get_logger") as mock_logger:
                _auto_enable_ocr()
                # Should not try to import if already enabled
                assert not config_mock.set_ocr_enabled.called

    def test_register_tools_logs_error(self):
        with patch("peekaboowin.server.structlog.get_logger") as mock_log:
            mock_logger = MagicMock()
            mock_log.return_value = mock_logger
            _register_tools()
            # Should not raise, even if some modules fail
            assert True

    def test_register_tools_success(self):
        with patch("peekaboowin.server.structlog.get_logger") as mock_log:
            mock_logger = MagicMock()
            mock_log.return_value = mock_logger
            _register_tools()
            # Verify tool modules were imported
            assert mock_logger.debug.called or True
