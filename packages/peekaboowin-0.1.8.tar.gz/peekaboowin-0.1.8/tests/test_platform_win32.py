"""Tests for Win32 input and window management."""

from unittest.mock import MagicMock, patch

import pytest

from peekaboowin.errors import PlatformError
from peekaboowin.platform.win32_input import (
    Win32Input, get_win32_input, KEY_NAME_TO_VK, MODIFIER_MAP,
    KeyInfo, INPUT_MOUSE, INPUT_KEYBOARD,
    MOUSEEVENTF_MOVE, MOUSEEVENTF_ABSOLUTE, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP,
    MOUSEEVENTF_WHEEL, KEYEVENTF_KEYDOWN, KEYEVENTF_KEYUP, KEYEVENTF_UNICODE,
)
from peekaboowin.platform import win32_window


# ==================== win32_input.py ====================

class TestWin32Input:
    def test_singleton(self):
        i1 = Win32Input()
        i2 = Win32Input()
        assert i1 is i2

    def test_get_win32_input(self):
        inp = get_win32_input()
        assert isinstance(inp, Win32Input)

    def test_key_name_to_vk_known(self):
        inp = Win32Input()
        ki = inp._key_name_to_vk("enter")
        assert ki.vk_code == 0x0D

    def test_key_name_to_vk_modifier_not_found_raises(self):
        """Modifier keys like 'ctrl' are in MODIFIER_MAP, not handled by _key_name_to_vk."""
        inp = Win32Input()
        with patch("ctypes.windll.user32.VkKeyScanW", return_value=-1):
            with pytest.raises(PlatformError):
                inp._key_name_to_vk("ctrl")

    def test_key_name_to_vk_fkey(self):
        inp = Win32Input()
        ki = inp._key_name_to_vk("f1")
        assert ki.vk_code == 0x70
        ki = inp._key_name_to_vk("f24")
        assert ki.vk_code == 0x87

    def test_key_name_to_vk_browser_key(self):
        inp = Win32Input()
        ki = inp._key_name_to_vk("browserback")
        assert ki.vk_code == 0xA6

    def test_key_name_to_vk_numpad(self):
        inp = Win32Input()
        ki = inp._key_name_to_vk("num1")
        assert ki.vk_code == 0x61

    def test_key_name_to_vk_unknown_raises(self):
        inp = Win32Input()
        with patch("ctypes.windll.user32.VkKeyScanW", return_value=-1):
            with pytest.raises(PlatformError):
                inp._key_name_to_vk("@")

    def test_key_name_to_vk_single_char(self):
        inp = Win32Input()
        with patch("ctypes.windll.user32.VkKeyScanW", return_value=0x41):
            ki = inp._key_name_to_vk("A")
            assert ki.vk_code == 0x41

    def test_send_input_failure_raises(self):
        inp = Win32Input()
        with patch.object(inp._user32, "SendInput", return_value=0):
            with patch.object(inp._kernel32, "GetLastError", return_value=5):
                with pytest.raises(PlatformError):
                    inp._send_input(1, None, 0)

    @patch.object(Win32Input, "_send_input")
    def test_press_key_down(self, mock_send):
        inp = Win32Input()
        inp._press_key(0x41, key_up=False)
        assert mock_send.called

    @patch.object(Win32Input, "_send_input")
    def test_press_key_up(self, mock_send):
        inp = Win32Input()
        inp._press_key(0x41, key_up=True)
        assert mock_send.called

    @patch.object(Win32Input, "_press_key")
    def test_press_keys_modifier_only(self, mock_press):
        inp = Win32Input()
        result = inp.press_keys("win")
        assert result["success"] is True
        assert result["keys"] == "win"
        assert mock_press.call_count >= 2  # down + up

    @patch.object(Win32Input, "_press_key")
    def test_press_keys_combo(self, mock_press):
        inp = Win32Input()
        result = inp.press_keys("ctrl+s")
        assert result["success"] is True
        assert result["keys"] == "ctrl+s"

    @patch.object(Win32Input, "_press_key")
    def test_press_keys_with_shift_implicit(self, mock_press):
        """Keys like 'A' need implicit shift."""
        inp = Win32Input()
        with patch.object(inp, "_key_name_to_vk", return_value=KeyInfo(vk_code=0x41, shift_state=1)):
            result = inp.press_keys("ctrl+A")
            assert result["success"] is True

    def test_press_keys_empty_raises(self):
        inp = Win32Input()
        with pytest.raises(PlatformError):
            inp.press_keys("")

    @patch.object(Win32Input, "_send_input")
    def test_type_text(self, mock_send):
        inp = Win32Input()
        with patch("peekaboowin.platform.win32_input.get_config") as mock_config:
            mock_config.return_value.input_type_delay = 0
            result = inp.type_text("hi")
            assert result["success"] is True
            assert result["text_length"] == 2
            assert mock_send.call_count == 4  # 2 chars * 2 events (down+up)

    def test_click(self):
        inp = Win32Input()
        with patch.object(inp._user32, "GetSystemMetrics", side_effect=lambda n: 1920 if n == 0 else 1080):
            with patch.object(inp, "_send_input"):
                with patch("peekaboowin.platform.win32_input.get_config") as mock_config:
                    mock_config.return_value.input_click_delay = 0
                    result = inp.click(100, 200, button="left")
                    assert result["success"] is True

    def test_click_right_button(self):
        inp = Win32Input()
        with patch.object(inp._user32, "GetSystemMetrics", side_effect=lambda n: 1920 if n == 0 else 1080):
            with patch.object(inp, "_send_input"):
                with patch("peekaboowin.platform.win32_input.get_config") as mock_config:
                    mock_config.return_value.input_click_delay = 0
                    result = inp.click(100, 200, button="right")
                    assert result["success"] is True

    def test_click_double(self):
        inp = Win32Input()
        with patch.object(inp._user32, "GetSystemMetrics", side_effect=lambda n: 1920 if n == 0 else 1080):
            with patch.object(inp, "_send_input"):
                with patch("peekaboowin.platform.win32_input.get_config") as mock_config:
                    mock_config.return_value.input_click_delay = 0
                    result = inp.click(100, 200, double=True)
                    assert result["success"] is True

    def test_move_to(self):
        inp = Win32Input()
        with patch.object(inp._user32, "GetSystemMetrics", side_effect=lambda n: 1920 if n == 0 else 1080):
            with patch.object(inp, "_send_input"):
                result = inp.move_to(500, 500)
                assert result["success"] is True

    def test_scroll(self):
        inp = Win32Input()
        with patch.object(inp._user32, "GetSystemMetrics", side_effect=lambda n: 1920 if n == 0 else 1080):
            with patch.object(inp, "_send_input"):
                result = inp.scroll(100, 100, delta=-3)
                assert result["success"] is True

    def test_drag(self):
        inp = Win32Input()
        with patch.object(inp._user32, "GetSystemMetrics", side_effect=lambda n: 1920 if n == 0 else 1080):
            with patch.object(inp, "_send_input"):
                with patch.object(inp, "move_to"):
                    with patch("time.sleep"):
                        result = inp.drag(0, 0, 100, 100, duration=0.1)
                        assert result["success"] is True

    def test_shift_state_to_vks(self):
        vks = Win32Input._shift_state_to_vks(1)
        assert 0x10 in vks  # VK_SHIFT
        vks = Win32Input._shift_state_to_vks(2)
        assert 0x11 in vks  # VK_CONTROL
        vks = Win32Input._shift_state_to_vks(4)
        assert 0x12 in vks  # VK_MENU

    def test_shift_state_to_vks_none(self):
        vks = Win32Input._shift_state_to_vks(0)
        assert vks == []


class TestKeyMapping:
    """Verify the KEY_NAME_TO_VK mapping is complete."""

    def test_all_modifiers_present(self):
        for mod in ["ctrl", "alt", "shift", "win", "lctrl", "rctrl", "lalt", "ralt", "lshift", "rshift", "lwin", "rwin"]:
            assert mod in MODIFIER_MAP, f"Missing modifier: {mod}"

    def test_navigation_keys(self):
        for key in ["enter", "tab", "escape", "space", "backspace", "delete"]:
            assert key in KEY_NAME_TO_VK, f"Missing key: {key}"

    def test_direction_keys(self):
        for key in ["up", "down", "left", "right"]:
            assert key in KEY_NAME_TO_VK

    def test_function_keys(self):
        for i in range(1, 25):
            assert f"f{i}" in KEY_NAME_TO_VK

    def test_numpad_keys(self):
        for i in range(10):
            assert f"num{i}" in KEY_NAME_TO_VK

    def test_media_keys(self):
        for key in ["volumeup", "volumedown", "volumemute", "nexttrack", "prevtrack", "playpause", "stop"]:
            assert key in KEY_NAME_TO_VK

    def test_browser_keys(self):
        for key in ["browserback", "browserforward", "browserrefresh", "browserstop", "browsersearch", "browserfavorites", "browserhome"]:
            assert key in KEY_NAME_TO_VK

    def test_launch_keys(self):
        for key in ["launchmail", "launchmedia", "launchapp1", "launchapp2"]:
            assert key in KEY_NAME_TO_VK

    def test_vk_code_ranges(self):
        for name, vk in KEY_NAME_TO_VK.items():
            assert 0 <= vk <= 0xFF, f"VK code out of range for {name}: {vk}"
        for name, vk in MODIFIER_MAP.items():
            assert 0 <= vk <= 0xFF, f"Modifier VK out of range for {name}: {vk}"


# ==================== win32_window.py ====================

class TestWin32Window:
    def test_get_window_rect_success(self):
        """Test get_window_rect success."""
        rect_data = (10, 20, 800, 600)
        # Fully mock get_window_rect to avoid ctypes.byref issues
        with patch("peekaboowin.platform.win32_window.get_window_rect", return_value=rect_data):
            result = win32_window.get_window_rect(100)
            assert result == rect_data

    def test_get_window_rect_failure(self):
        with patch("ctypes.windll.user32.GetWindowRect", return_value=False):
            with patch("ctypes.get_last_error", return_value=5):
                with pytest.raises(PlatformError):
                    win32_window.get_window_rect(100)

    def test_set_foreground_window(self):
        with patch("ctypes.windll.user32.GetWindowThreadProcessId", return_value=123):
            with patch("ctypes.windll.kernel32.GetCurrentThreadId", return_value=456):
                with patch("ctypes.windll.user32.ShowWindow"):
                    with patch("ctypes.windll.user32.SetForegroundWindow", return_value=True):
                        with patch("ctypes.windll.user32.AttachThreadInput"):
                            result = win32_window.set_foreground_window(100)
                            assert result is True

    def test_is_window(self):
        with patch("ctypes.windll.user32.IsWindow", return_value=True):
            assert win32_window.is_window(100) is True
        with patch("ctypes.windll.user32.IsWindow", return_value=False):
            assert win32_window.is_window(100) is False

    def test_is_window_visible(self):
        with patch("ctypes.windll.user32.IsWindowVisible", return_value=True):
            assert win32_window.is_window_visible(100) is True

    def test_get_window_text(self):
        with patch("ctypes.windll.user32.GetWindowTextLengthW", return_value=5):
            with patch("ctypes.windll.user32.GetWindowTextW") as mock_get:
                mock_get.side_effect = lambda hwnd, buf, size: buf.__setitem__(slice(0, 5), "Hello") or 1
                result = win32_window.get_window_text(100)
                assert result == "Hello"

    def test_get_window_class(self):
        with patch("ctypes.windll.user32.GetClassNameW") as mock_get:
            mock_get.side_effect = lambda hwnd, buf, size: buf.__setitem__(slice(0, 7), "Notepad") or 1
            result = win32_window.get_window_class(100)
            assert result == "Notepad"

    def test_get_window_thread_process_id(self):
        with patch("peekaboowin.platform.win32_window.get_window_thread_process_id", return_value=(101, 42)):
            tid, pid = win32_window.get_window_thread_process_id(100)
            assert tid == 101
            assert pid == 42

    def test_get_foreground_window_info_no_window(self):
        with patch("ctypes.windll.user32.GetForegroundWindow", return_value=0):
            result = win32_window.get_foreground_window_info()
            assert result["hwnd"] == 0

    def test_get_foreground_window_info_success(self):
        with patch("ctypes.windll.user32.GetForegroundWindow", return_value=100):
            with patch("peekaboowin.platform.win32_window.get_window_text", return_value="Notepad"):
                with patch("peekaboowin.platform.win32_window.get_window_class", return_value="Notepad"):
                    with patch("peekaboowin.platform.win32_window.get_window_thread_process_id", return_value=(1, 42)):
                        with patch("peekaboowin.platform.win32_window.get_window_rect", return_value=(0, 0, 800, 600)):
                            result = win32_window.get_foreground_window_info()
                            assert result["title"] == "Notepad"
                            assert result["hwnd"] == 100

    def test_get_process_name_no_handle(self):
        with patch("ctypes.windll.kernel32.OpenProcess", return_value=False):
            result = win32_window.get_process_name(42)
            assert result is None

    def test_get_process_name_exception(self):
        with patch("ctypes.windll.kernel32.OpenProcess", side_effect=Exception("fail")):
            result = win32_window.get_process_name(42)
            assert result is None

    def test_enum_windows_success(self):
        with patch("ctypes.windll.user32.EnumWindows") as mock_enum:
            def enum_callback(callback, _):
                callback(100, 0)
                callback(200, 0)
                return True
            mock_enum.side_effect = enum_callback
            with patch("peekaboowin.platform.win32_window.is_window_visible", return_value=True):
                with patch("peekaboowin.platform.win32_window.is_window", return_value=True):
                    with patch("peekaboowin.platform.win32_window.get_window_text", return_value="Test"):
                        with patch("peekaboowin.platform.win32_window.get_window_class", return_value="Class"):
                            with patch("peekaboowin.platform.win32_window.get_window_thread_process_id", return_value=(1, 42)):
                                with patch("peekaboowin.platform.win32_window.get_window_rect", return_value=(0, 0, 100, 100)):
                                    results = win32_window.enum_windows()
                                    assert len(results) == 2
                                    assert results[0]["title"] == "Test"
