"""Tests for all service layer modules."""

from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from peekaboowin.errors import PlatformError, ServiceError, ElementNotFoundError, InvalidParamsError
from peekaboowin.services.screen_service import ScreenService, get_screen_service
from peekaboowin.services.clipboard_service import ClipboardService, get_clipboard_service
from peekaboowin.services.window_service import WindowService, get_window_service
from peekaboowin.services.ocr_service import OCRService
from peekaboowin.services.input_service import InputService
from peekaboowin.services.wait_service import WaitService
from peekaboowin.platform.uia import TreeScope_Children, TreeScope_Descendants, TreeScope_Element
from peekaboowin.services.uia_service import UIAService


# ==================== screen_service.py ====================

class TestScreenService:
    def test_singleton(self):
        ScreenService._instance = None
        s1 = ScreenService.get_instance()
        s2 = ScreenService.get_instance()
        assert s1 is s2

    def test_init_failure_raises(self):
        ScreenService._instance = None
        with patch("peekaboowin.services.screen_service.ScreenCapture", side_effect=Exception("fail")):
            with pytest.raises(Exception):
                ScreenService()

    def test_apply_max_width_resize(self):
        service = ScreenService()
        from PIL import Image
        img = Image.new("RGB", (3840, 2160))
        result = service._apply_max_width(img, 1920)
        assert result.width == 1920

    def test_apply_max_width_no_resize(self):
        service = ScreenService()
        from PIL import Image
        img = Image.new("RGB", (100, 100))
        result = service._apply_max_width(img, 1920)
        assert result is img

    def test_take_screenshot_monitor_success(self):
        service = ScreenService()
        from PIL import Image
        img = Image.new("RGB", (100, 100))
        with patch.object(service._capture, "capture_monitor", return_value=img):
            with patch.object(service._capture, "image_to_base64", return_value="base64data"):
                result = service.take_screenshot(monitor=0)
                assert "image" in result
                assert result["monitor_index"] == 0

    def test_take_screenshot_region_success(self):
        service = ScreenService()
        from PIL import Image
        img = Image.new("RGB", (100, 100))
        with patch.object(service._capture, "capture_region", return_value=img):
            with patch.object(service._capture, "image_to_base64", return_value="base64data"):
                result = service.take_screenshot(region={"left": 0, "top": 0, "width": 100, "height": 100})
                assert "image" in result

    def test_take_screenshot_default_monitor(self):
        service = ScreenService()
        from PIL import Image
        img = Image.new("RGB", (100, 100))
        with patch.object(service._capture, "capture_monitor", return_value=img):
            with patch.object(service._capture, "image_to_base64", return_value="base64data"):
                result = service.take_screenshot()
                assert result["monitor_index"] == 0

    def test_take_screenshot_platform_error_passthrough(self):
        service = ScreenService()
        with patch.object(service._capture, "capture_monitor", side_effect=PlatformError("fail")):
            with pytest.raises(PlatformError):
                service.take_screenshot(monitor=0)

    def test_take_screenshot_unknown_error_wrapped(self):
        service = ScreenService()
        with patch.object(service._capture, "capture_monitor", side_effect=ValueError("bad")):
            with pytest.raises(ServiceError):
                service.take_screenshot(monitor=0)

    def test_get_monitors(self):
        service = ScreenService()
        with patch.object(service._capture, "list_monitors", return_value=[{"id": 0}]):
            result = service.get_monitors()
            assert len(result) == 1

    def test_get_monitors_failure(self):
        service = ScreenService()
        with patch.object(service._capture, "list_monitors", side_effect=Exception("fail")):
            result = service.get_monitors()
            assert result == []

    def test_capture_window_success(self):
        service = ScreenService()
        from PIL import Image
        img = Image.new("RGB", (100, 100))
        with patch.object(service._capture, "capture_window_by_hwnd", return_value=img):
            with patch.object(service._capture, "image_to_base64", return_value="base64data"):
                result = service.capture_window(hwnd=12345)
                assert "image" in result

    def test_capture_window_format_override(self):
        service = ScreenService()
        from PIL import Image
        img = Image.new("RGB", (100, 100))
        with patch.object(service._capture, "capture_window_by_hwnd", return_value=img):
            with patch.object(service._capture, "image_to_base64", return_value="base64data"):
                result = service.capture_window(hwnd=12345, format="jpeg", quality=50)
                assert "image" in result

    def test_get_screen_service(self):
        ScreenService._instance = None
        svc = get_screen_service()
        assert isinstance(svc, ScreenService)


# ==================== clipboard_service.py ====================

class TestClipboardService:
    def test_singleton(self):
        ClipboardService._instance = None
        with patch("peekaboowin.services.clipboard_service.get_win32_clipboard", return_value=MagicMock()):
            s1 = ClipboardService.get_instance()
            s2 = ClipboardService.get_instance()
            assert s1 is s2

    def test_init_failure(self):
        ClipboardService._instance = None
        with patch("peekaboowin.services.clipboard_service.get_win32_clipboard", side_effect=Exception("fail")):
            with pytest.raises(ServiceError):
                ClipboardService()

    def test_read_clipboard_success(self):
        clipboard_mock = MagicMock()
        clipboard_mock.read_text.return_value = "hello"
        with patch("peekaboowin.services.clipboard_service.get_win32_clipboard", return_value=clipboard_mock):
            ClipboardService._instance = None
            service = ClipboardService()
            result = service.read_clipboard()
            assert result == "hello"

    def test_read_clipboard_platform_error(self):
        clipboard_mock = MagicMock()
        clipboard_mock.read_text.side_effect = PlatformError("fail")
        with patch("peekaboowin.services.clipboard_service.get_win32_clipboard", return_value=clipboard_mock):
            ClipboardService._instance = None
            service = ClipboardService()
            with pytest.raises(PlatformError):
                service.read_clipboard()

    def test_write_clipboard_success(self):
        clipboard_mock = MagicMock()
        with patch("peekaboowin.services.clipboard_service.get_win32_clipboard", return_value=clipboard_mock):
            ClipboardService._instance = None
            service = ClipboardService()
            service.write_clipboard("test")

    def test_get_clipboard_service(self):
        with patch("peekaboowin.services.clipboard_service.get_win32_clipboard", return_value=MagicMock()):
            ClipboardService._instance = None
            svc = get_clipboard_service()
            assert isinstance(svc, ClipboardService)


# ==================== window_service.py ====================

class TestWindowService:
    def test_singleton(self):
        WindowService._instance = None
        s1 = WindowService.get_instance()
        s2 = WindowService.get_instance()
        assert s1 is s2

    def test_list_windows(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.enum_windows", return_value=[{"hwnd": 1}]):
            service = WindowService()
            result = service.list_windows()
            assert "windows" in result

    def test_list_windows_failure(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.enum_windows", side_effect=Exception("fail")):
            service = WindowService()
            with pytest.raises(ServiceError):
                service.list_windows()

    def test_get_foreground_window(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.get_foreground_window_info", return_value={"hwnd": 100}):
            service = WindowService()
            result = service.get_foreground_window()
            assert result["hwnd"] == 100

    def test_is_valid_window(self):
        with patch("peekaboowin.services.window_service.win32.is_window", return_value=True):
            with patch("peekaboowin.services.window_service.win32.is_window_visible", return_value=True):
                service = WindowService()
                assert service.is_valid_window(100) is True

    def test_activate_window_invalid(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.is_window", return_value=False):
            service = WindowService()
            with pytest.raises(InvalidParamsError):
                service.activate_window(0)

    def test_activate_window_success(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.is_window", return_value=True):
            with patch("peekaboowin.services.window_service.win32.set_foreground_window", return_value=True):
                service = WindowService()
                result = service.activate_window(100)
                assert result["success"] is True

    def test_move_window_invalid(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.is_window", return_value=False):
            service = WindowService()
            with pytest.raises(InvalidParamsError):
                service.move_window(0, 100, 100)

    def test_resize_window_success(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.is_window", return_value=True):
            with patch("ctypes.windll.user32.SetWindowPos", return_value=True):
                service = WindowService()
                result = service.resize_window(100, 800, 600)
                assert result["success"] is True

    def test_minimize_window(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.is_window", return_value=True):
            with patch("ctypes.windll.user32.ShowWindow", return_value=True):
                service = WindowService()
                result = service.minimize_window(100)
                assert result["success"] is True

    def test_maximize_window(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.is_window", return_value=True):
            with patch("ctypes.windll.user32.ShowWindow", return_value=True):
                service = WindowService()
                result = service.maximize_window(100)
                assert result["success"] is True

    def test_restore_window(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.is_window", return_value=True):
            with patch("ctypes.windll.user32.ShowWindow", return_value=True):
                service = WindowService()
                result = service.restore_window(100)
                assert result["success"] is True

    def test_close_window(self):
        WindowService._instance = None
        with patch("peekaboowin.services.window_service.win32.is_window", return_value=True):
            with patch("ctypes.windll.user32.PostMessageW", return_value=True):
                service = WindowService()
                result = service.close_window(100)
                assert result["success"] is True

    def test_get_window_service(self):
        WindowService._instance = None
        svc = get_window_service()
        assert isinstance(svc, WindowService)


# ==================== uia_service.py ====================

class TestUIAService:
    def test_singleton(self):
        UIAService._instance = None
        with patch("peekaboowin.services.uia_service.get_uia", return_value=MagicMock()):
            s1 = UIAService.get_instance()
            s2 = UIAService.get_instance()
            assert s1 is s2

    def test_scope_to_treescope_valid(self):
        with patch("peekaboowin.services.uia_service.get_uia", return_value=MagicMock()):
            UIAService._instance = None
            service = UIAService()
            assert service._scope_to_treescope("children") == TreeScope_Children
            assert service._scope_to_treescope("descendants") == TreeScope_Descendants
            assert service._scope_to_treescope("self") == TreeScope_Element

    def test_scope_to_treescope_invalid(self):
        with patch("peekaboowin.services.uia_service.get_uia", return_value=MagicMock()):
            UIAService._instance = None
            service = UIAService()
            with pytest.raises(InvalidParamsError):
                service._scope_to_treescope("invalid")

    def test_validate_search_criteria_empty_raises(self):
        with patch("peekaboowin.services.uia_service.get_uia", return_value=MagicMock()):
            UIAService._instance = None
            service = UIAService()
            with pytest.raises(InvalidParamsError):
                service._validate_search_criteria()

    def test_validate_search_criteria_valid(self):
        with patch("peekaboowin.services.uia_service.get_uia", return_value=MagicMock()):
            UIAService._instance = None
            service = UIAService()
            service._validate_search_criteria(name="test")  # should not raise

    def test_is_ocr_available(self):
        with patch("peekaboowin.services.uia_service.get_uia", return_value=MagicMock()):
            with patch("peekaboowin.services.uia_service.get_config") as mc:
                mc.return_value.ocr_enabled = True
                UIAService._instance = None
                service = UIAService()
                assert service.is_ocr_available() is True

    def test_get_element_info_desktop(self):
        uia_mock = MagicMock()
        uia_mock.get_root_element.return_value = MagicMock()
        uia_mock.get_element_properties.return_value = {"name": "Desktop"}
        with patch("peekaboowin.services.uia_service.get_uia", return_value=uia_mock):
            UIAService._instance = None
            service = UIAService()
            result = service.get_element_info("desktop")
            assert result is not None

    def test_get_element_info_hwnd_not_found(self):
        uia_mock = MagicMock()
        uia_mock.element_from_hwnd.return_value = None
        with patch("peekaboowin.services.uia_service.get_uia", return_value=uia_mock):
            UIAService._instance = None
            service = UIAService()
            with pytest.raises(ElementNotFoundError):
                service.get_element_info("hwnd:99999")

    def test_get_element_info_invalid_ref(self):
        with patch("peekaboowin.services.uia_service.get_uia", return_value=MagicMock()):
            UIAService._instance = None
            service = UIAService()
            with pytest.raises(InvalidParamsError):
                service.get_element_info("bad-ref")

    def test_find_element_not_found(self):
        uia_mock = MagicMock()
        uia_mock.find_element.return_value = None
        with patch("peekaboowin.services.uia_service.get_uia", return_value=uia_mock):
            UIAService._instance = None
            service = UIAService()
            result = service.find_element(name="does_not_exist")
            assert result is None

    def test_find_element_found(self):
        uia_mock = MagicMock()
        uia_mock.find_element.return_value = MagicMock()
        uia_mock.get_element_properties.return_value = {"name": "Found", "is_enabled": True, "is_offscreen": False}
        with patch("peekaboowin.services.uia_service.get_uia", return_value=uia_mock):
            UIAService._instance = None
            service = UIAService()
            result = service.find_element(name="test")
            assert result["name"] == "Found"

    def test_get_children_desktop(self):
        uia_mock = MagicMock()
        windows = [{
            "hwnd": 100,
            "title": "Notepad",
            "class_name": "Notepad",
            "is_enabled": True,
            "bounds": (0, 0, 800, 600),
            "process_id": 42,
        }]
        with patch("peekaboowin.services.uia_service.get_uia", return_value=uia_mock):
            with patch("peekaboowin.services.uia_service.get_config") as mc:
                with patch("peekaboowin.services.uia_service.win32.enum_windows", return_value=windows):
                    mc.return_value.uia_max_depth = 10
                    UIAService._instance = None
                    service = UIAService()
                    result = service.get_children("desktop", depth=1)
                    assert result["children"][0]["name"] == "Notepad"
                    assert result["children"][0]["control_type"] == "Window"
                    uia_mock.get_children.assert_not_called()

    def test_get_desktop(self):
        uia_mock = MagicMock()
        windows = [{
            "hwnd": 100,
            "title": "Notepad",
            "class_name": "Notepad",
            "is_enabled": True,
            "bounds": (0, 0, 800, 600),
            "process_id": 42,
        }]
        with patch("peekaboowin.services.uia_service.get_uia", return_value=uia_mock):
            with patch("peekaboowin.services.uia_service.get_config") as mc:
                with patch("peekaboowin.services.uia_service.win32.enum_windows", return_value=windows):
                    mc.return_value.uia_max_depth = 10
                    UIAService._instance = None
                    service = UIAService()
                    result = service.get_desktop(depth=2)
                    assert result["name"] == "Desktop"
                    assert len(result["_children"]) == 1
                    assert result["_children"][0]["hwnd"] == 100
                    uia_mock.get_root_element.assert_not_called()

    def test_get_desktop_min_depth(self):
        with patch("peekaboowin.services.uia_service.get_uia", return_value=MagicMock()):
            UIAService._instance = None
            service = UIAService()
            with patch("peekaboowin.services.uia_service.win32.enum_windows", return_value=[]):
                with patch("peekaboowin.services.uia_service.get_config") as mc:
                    mc.return_value.uia_max_depth = 10
                    result = service.get_desktop(depth=0)
                    assert result is not None

    def test_window_to_element_marks_minimized_offscreen(self):
        with patch("peekaboowin.services.uia_service.get_uia", return_value=MagicMock()):
            UIAService._instance = None
            service = UIAService()
            element = service._window_to_element_dict({
                "hwnd": 100,
                "title": "Hidden",
                "class_name": "HiddenClass",
                "is_enabled": True,
                "bounds": (-32000, -32000, -31840, -31972),
            })
            assert element["is_offscreen"] is True


# ==================== input_service.py ====================

class TestInputService:
    def test_singleton(self):
        InputService._instance = None
        with patch("peekaboowin.services.input_service.get_win32_input", return_value=MagicMock()):
            with patch("peekaboowin.services.input_service.get_uia_service", return_value=MagicMock()):
                s1 = InputService.get_instance()
                s2 = InputService.get_instance()
                assert s1 is s2

    def test_click_with_hwnd(self):
        input_mock = MagicMock()
        uia_mock = MagicMock()
        with patch("peekaboowin.services.input_service.get_win32_input", return_value=input_mock):
            with patch("peekaboowin.services.input_service.get_uia_service", return_value=uia_mock):
                InputService._instance = None
                service = InputService()
                with patch.object(service, "_get_hwnd_at_point", return_value=100):
                    with patch.object(service, "_ensure_window_focused", return_value=True):
                        result = service.click(100, 200)
                        assert result["success"] is True

    def test_click_no_hwnd(self):
        input_mock = MagicMock()
        uia_mock = MagicMock()
        with patch("peekaboowin.services.input_service.get_win32_input", return_value=input_mock):
            with patch("peekaboowin.services.input_service.get_uia_service", return_value=uia_mock):
                InputService._instance = None
                service = InputService()
                with patch.object(service, "_get_hwnd_at_point", return_value=None):
                    with patch.object(service, "_ensure_window_focused") as mock_focus:
                        result = service.click(100, 200)
                        assert result["success"] is True
                        mock_focus.assert_not_called()

    def test_move_mouse(self):
        input_mock = MagicMock()
        uia_mock = MagicMock()
        with patch("peekaboowin.services.input_service.get_win32_input", return_value=input_mock):
            with patch("peekaboowin.services.input_service.get_uia_service", return_value=uia_mock):
                InputService._instance = None
                service = InputService()
                with patch.object(service, "_get_hwnd_at_point", return_value=None):
                    result = service.move_mouse(100, 200)
                    assert result["success"] is True

    def test_drag(self):
        input_mock = MagicMock()
        uia_mock = MagicMock()
        with patch("peekaboowin.services.input_service.get_win32_input", return_value=input_mock):
            with patch("peekaboowin.services.input_service.get_uia_service", return_value=uia_mock):
                InputService._instance = None
                service = InputService()
                with patch.object(service, "_get_hwnd_at_point", return_value=None):
                    result = service.drag(0, 0, 100, 100)
                    assert result["success"] is True

    def test_scroll(self):
        input_mock = MagicMock()
        uia_mock = MagicMock()
        with patch("peekaboowin.services.input_service.get_win32_input", return_value=input_mock):
            with patch("peekaboowin.services.input_service.get_uia_service", return_value=uia_mock):
                InputService._instance = None
                service = InputService()
                with patch.object(service, "_get_hwnd_at_point", return_value=None):
                    result = service.scroll(100, 200)
                    assert result["success"] is True

    def test_type_text(self):
        input_mock = MagicMock()
        uia_mock = MagicMock()
        with patch("peekaboowin.services.input_service.get_win32_input", return_value=input_mock):
            with patch("peekaboowin.services.input_service.get_uia_service", return_value=uia_mock):
                InputService._instance = None
                service = InputService()
                result = service.type_text("hello")
                assert result["success"] is True

    def test_press_keys(self):
        input_mock = MagicMock()
        uia_mock = MagicMock()
        with patch("peekaboowin.services.input_service.get_win32_input", return_value=input_mock):
            with patch("peekaboowin.services.input_service.get_uia_service", return_value=uia_mock):
                InputService._instance = None
                service = InputService()
                result = service.press_keys("ctrl+s")
                assert result["success"] is True

    def test_click_element(self):
        input_mock = MagicMock()
        uia_mock = MagicMock()
        uia_mock.get_element_info.return_value = {"hwnd": 100, "bounding_box": (0, 0, 100, 100)}
        with patch("peekaboowin.services.input_service.get_win32_input", return_value=input_mock):
            with patch("peekaboowin.services.input_service.get_uia_service", return_value=uia_mock):
                InputService._instance = None
                service = InputService()
                with patch.object(service, "_ensure_window_focused", return_value=True):
                    with patch("peekaboowin.services.input_service.check_elevation", return_value=True):
                        result = service.click_element("hwnd:100")
                        assert result["success"] is True

    def test_type_into_element(self):
        input_mock = MagicMock()
        uia_mock = MagicMock()
        uia_mock.get_element_info.return_value = {"hwnd": 100, "bounding_box": (0, 0, 100, 100)}
        with patch("peekaboowin.services.input_service.get_win32_input", return_value=input_mock):
            with patch("peekaboowin.services.input_service.get_uia_service", return_value=uia_mock):
                InputService._instance = None
                service = InputService()
                with patch.object(service, "_ensure_window_focused", return_value=True):
                    with patch("peekaboowin.services.input_service.check_elevation", return_value=True):
                        result = service.type_into_element("hwnd:100", "hello")
                        assert result["success"] is True

    def test_get_clickable_point_no_bbox_raises(self):
        uia_mock = MagicMock()
        uia_mock.get_element_info.return_value = {"hwnd": 100}
        with patch("peekaboowin.services.input_service.get_uia_service", return_value=uia_mock):
            InputService._instance = None
            service = InputService()
            with pytest.raises(ElementNotFoundError):
                service._get_clickable_point("hwnd:100")


# ==================== wait_service.py ====================

class TestWaitService:
    def test_wait_for_element_timeout(self):
        with patch("peekaboowin.services.wait_service.get_uia_service", return_value=MagicMock()):
            with patch("peekaboowin.services.wait_service.get_window_service", return_value=MagicMock()):
                WaitService._instance = None
                service = WaitService()
                with patch("time.monotonic", side_effect=[0, 11]):  # immediate timeout
                    with patch.object(service._uia_service, "find_element", return_value=None):
                        result = service.wait_for_element(name="test", timeout=10, interval=0.1)
                        assert result.found is False

    def test_wait_for_element_found(self):
        with patch("peekaboowin.services.wait_service.get_uia_service", return_value=MagicMock()):
            with patch("peekaboowin.services.wait_service.get_window_service", return_value=MagicMock()):
                WaitService._instance = None
                service = WaitService()
                with patch("time.monotonic", side_effect=[0, 0.5]):
                    with patch.object(service._uia_service, "find_element", return_value={"name": "test"}):
                        result = service.wait_for_element(name="test", timeout=10, interval=0.1)
                        assert result.found is True

    def test_wait_for_window_timeout(self):
        with patch("peekaboowin.services.wait_service.get_uia_service", return_value=MagicMock()):
            with patch("peekaboowin.services.wait_service.get_window_service", return_value=MagicMock()):
                WaitService._instance = None
                service = WaitService()
                with patch("time.monotonic", side_effect=[0, 11]):
                    with patch.object(service._window_service, "list_windows", return_value={"windows": []}):
                        result = service.wait_for_window(title="notepad", timeout=10, interval=0.1)
                        assert result.found is False

    def test_wait_for_window_found(self):
        with patch("peekaboowin.services.wait_service.get_uia_service", return_value=MagicMock()):
            with patch("peekaboowin.services.wait_service.get_window_service", return_value=MagicMock()):
                WaitService._instance = None
                service = WaitService()
                with patch("time.monotonic", side_effect=[0, 0.5]):
                    with patch.object(service._window_service, "list_windows", return_value={"windows": [{"title": "Notepad", "class_name": "Notepad"}]}):
                        result = service.wait_for_window(title="notepad", timeout=10, interval=0.1)
                        assert result.found is True

    def test_wait_for_element_control_type_mismatch(self):
        with patch("peekaboowin.services.wait_service.get_uia_service", return_value=MagicMock()):
            with patch("peekaboowin.services.wait_service.get_window_service", return_value=MagicMock()):
                WaitService._instance = None
                with patch("time.monotonic", side_effect=[0, 11]):
                    with patch("time.sleep"):
                        WaitService._instance = None
                        service = WaitService()
                        with patch.object(service._uia_service, "find_element", return_value={"name": "test", "control_type": "Edit"}):
                            result = service.wait_for_element(name="test", control_type="Button", timeout=10, interval=0.1)
                            assert result.found is False


# ==================== ocr_service.py ====================

class TestOCRService:
    def test_ocr_read_disabled_raises(self):
        OCRService._instance = None
        with patch("peekaboowin.services.ocr_service.get_screen_service", return_value=MagicMock()):
            with patch("peekaboowin.services.ocr_service.get_ocr_engine", return_value=MagicMock()):
                service = OCRService()
                with patch.object(service._config, "ocr_enabled", False):
                    with pytest.raises(ServiceError):
                        service.ocr_read()

    def test_ocr_read_screen(self):
        OCRService._instance = None
        screen_mock = MagicMock()
        screen_mock.take_screenshot.return_value = {"image": ""}
        with patch("peekaboowin.services.ocr_service.get_screen_service", return_value=screen_mock):
            with patch("peekaboowin.services.ocr_service.get_ocr_engine", return_value=MagicMock()):
                service = OCRService()
                with patch.object(service, "_decode_image", return_value=MagicMock()):
                    with patch.object(service._ocr_engine, "recognize", return_value=[]):
                        with patch.object(service._config, "ocr_enabled", True):
                            result = service.ocr_read(source="screen", lang="ch")
                            assert result.source == "screen"
                            assert result.items == []

    def test_ocr_read_invalid_source(self):
        OCRService._instance = None
        with patch("peekaboowin.services.ocr_service.get_screen_service", return_value=MagicMock()):
            with patch("peekaboowin.services.ocr_service.get_ocr_engine", return_value=MagicMock()):
                service = OCRService()
                with patch.object(service._config, "ocr_enabled", True):
                    with pytest.raises(ServiceError):
                        service.ocr_read(source="invalid")
