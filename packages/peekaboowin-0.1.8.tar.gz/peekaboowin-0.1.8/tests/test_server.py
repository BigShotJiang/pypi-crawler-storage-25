"""Tests for server module."""

from peekaboowin import __version__


class TestVersion:
    def test_version(self):
        assert __version__ == "0.1.3"


class TestServerImports:
    """Verify server module can be imported without side effects."""

    def test_import_server_module(self):
        """Importing server should work (but mcp.run won't be called without main)."""
        import importlib
        import peekaboowin.server
        importlib.reload(peekaboowin.server)
        assert hasattr(peekaboowin.server, "mcp")
        assert hasattr(peekaboowin.server, "main")
        assert hasattr(peekaboowin.server, "setup")

    def test_mcp_instance(self):
        from peekaboowin.server import mcp
        assert mcp.name == "peekaboowin"

    def test_tool_modules_importable(self):
        """All tool modules should be importable without error."""
        modules = [
            "peekaboowin.tools.screen",
            "peekaboowin.tools.clipboard",
            "peekaboowin.tools.window",
            "peekaboowin.tools.ocr",
            "peekaboowin.tools.harvest",
        ]
        import importlib
        for mod_name in modules:
            mod = importlib.import_module(mod_name)
            assert mod is not None
