"""Window management service."""

import ctypes
from typing import Optional

import structlog

from peekaboowin.errors import InvalidParamsError, PlatformError, ServiceError
from peekaboowin.models.windows import WindowInfo
from peekaboowin.platform import win32_window as win32

logger = structlog.get_logger(__name__)


class WindowService:
    """Business logic for window management operations."""

    _instance: Optional["WindowService"] = None

    def __init__(self) -> None:
        try:
            logger.info("window_service_initialized")
        except Exception as e:
            logger.error("window_service_init_failed", error=str(e))
            raise ServiceError(message=f"Failed to initialize window service: {e}", service_name="Window")

    @classmethod
    def get_instance(cls) -> "WindowService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _hwnd_to_window_info(self, hwnd: int) -> Optional[WindowInfo]:
        try:
            if not win32.is_window(hwnd):
                return None
            title = win32.get_window_text(hwnd)
            class_name = win32.get_window_class(hwnd)
            _, pid = win32.get_window_thread_process_id(hwnd)
            try:
                rect = win32.get_window_rect(hwnd)
                from peekaboowin.models.elements import BoundingBox
                bounds = BoundingBox(left=rect[0], top=rect[1], right=rect[2], bottom=rect[3])
            except Exception:
                bounds = None
            return WindowInfo(
                hwnd=hwnd, title=title, class_name=class_name,
                is_visible=win32.is_window_visible(hwnd),
                is_enabled=bool(ctypes.windll.user32.IsWindowEnabled(hwnd)),
                bounds=bounds, process_id=pid,
                process_name=win32.get_process_name(pid) if pid else None,
            )
        except Exception as e:
            logger.debug("hwnd_to_window_info_failed", hwnd=hwnd, error=str(e))
            return None

    def list_windows(self) -> dict:
        try:
            windows = win32.enum_windows()
            return {"windows": windows}
        except Exception as e:
            logger.error("list_windows_failed", error=str(e))
            raise ServiceError(message=f"Failed to list windows: {e}", service_name="Window")

    def get_foreground_window(self) -> dict:
        try:
            info = win32.get_foreground_window_info()
            return info
        except Exception as e:
            logger.error("get_foreground_window_failed", error=str(e))
            raise ServiceError(message=f"Failed to get foreground window: {e}", service_name="Window")

    def is_valid_window(self, hwnd: int) -> bool:
        return win32.is_window(hwnd) and win32.is_window_visible(hwnd)

    def activate_window(self, hwnd: int) -> dict:
        try:
            if not win32.is_window(hwnd):
                raise InvalidParamsError(message=f"Invalid window handle: {hwnd}", tool_name="activate_window", param_name="hwnd")

            success = win32.set_foreground_window(hwnd)
            return {"success": success, "hwnd": hwnd, "operation": "activate", "message": "Window activated" if success else "Failed to activate window"}
        except InvalidParamsError:
            raise
        except Exception as e:
            logger.error("activate_window_failed", hwnd=hwnd, error=str(e))
            raise ServiceError(message=f"Failed to activate window: {e}", service_name="Window")

    def move_window(self, hwnd: int, x: int, y: int) -> dict:
        try:
            if not win32.is_window(hwnd):
                raise InvalidParamsError(message=f"Invalid window handle: {hwnd}", tool_name="move_window", param_name="hwnd")

            result = ctypes.windll.user32.SetWindowPos(hwnd, 0, x, y, 0, 0, 0x0001 | 0x0004)
            return {"success": bool(result), "hwnd": hwnd, "x": x, "y": y, "operation": "move"}
        except InvalidParamsError:
            raise
        except Exception as e:
            logger.error("move_window_failed", hwnd=hwnd, error=str(e))
            raise ServiceError(message=f"Failed to move window: {e}", service_name="Window")

    def resize_window(self, hwnd: int, width: int, height: int) -> dict:
        try:
            if not win32.is_window(hwnd):
                raise InvalidParamsError(message=f"Invalid window handle: {hwnd}", tool_name="resize_window", param_name="hwnd")

            result = ctypes.windll.user32.SetWindowPos(hwnd, 0, 0, 0, width, height, 0x0002 | 0x0004)
            return {"success": bool(result), "hwnd": hwnd, "width": width, "height": height, "operation": "resize"}
        except InvalidParamsError:
            raise
        except Exception as e:
            logger.error("resize_window_failed", hwnd=hwnd, error=str(e))
            raise ServiceError(message=f"Failed to resize window: {e}", service_name="Window")

    def _show_window(self, hwnd: int, cmd: int) -> dict:
        if not win32.is_window(hwnd):
            raise InvalidParamsError(message=f"Invalid window handle: {hwnd}")

        result = ctypes.windll.user32.ShowWindow(hwnd, cmd)
        return {"success": True, "hwnd": hwnd}

    def minimize_window(self, hwnd: int) -> dict:
        return self._show_window(hwnd, 6)

    def maximize_window(self, hwnd: int) -> dict:
        return self._show_window(hwnd, 3)

    def restore_window(self, hwnd: int) -> dict:
        return self._show_window(hwnd, 9)

    def close_window(self, hwnd: int) -> dict:
        try:
            if not win32.is_window(hwnd):
                raise InvalidParamsError(message=f"Invalid window handle: {hwnd}", tool_name="close_window", param_name="hwnd")

            ctypes.windll.user32.PostMessageW(hwnd, 0x0010, 0, 0)
            return {"success": True, "hwnd": hwnd, "operation": "close", "message": "WM_CLOSE sent"}
        except InvalidParamsError:
            raise
        except Exception as e:
            logger.error("close_window_failed", hwnd=hwnd, error=str(e))
            raise ServiceError(message=f"Failed to close window: {e}", service_name="Window")


def get_window_service() -> WindowService:
    return WindowService.get_instance()
