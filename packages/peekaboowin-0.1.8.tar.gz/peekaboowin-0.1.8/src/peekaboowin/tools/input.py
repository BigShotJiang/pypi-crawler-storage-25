"""Input simulation tools."""

import ctypes
import structlog

from peekaboowin.errors import InvalidParamsError
from peekaboowin.services.input_service import get_input_service
from peekaboowin.tools._common import tool_error_handler
from peekaboowin.server import mcp

logger = structlog.get_logger(__name__)


def _validate_screen_coordinates(x: int, y: int, tool_name: str) -> None:
    """Validate coordinates are within screen bounds."""
    screen_w = ctypes.windll.user32.GetSystemMetrics(0)  # SM_CXSCREEN
    screen_h = ctypes.windll.user32.GetSystemMetrics(1)  # SM_CYSCREEN
    if x < 0 or y < 0 or x >= screen_w or y >= screen_h:
        raise InvalidParamsError(
            message=f"Coordinates ({x}, {y}) out of screen bounds (0-{screen_w-1}, 0-{screen_h-1})",
            tool_name=tool_name,
            param_name="x/y"
        )


@mcp.tool()
@tool_error_handler("click")
def click(x: int, y: int, button: str = "left", double: bool = False) -> dict:
    """Click at screen coordinates. Coordinates must be within screen bounds. Auto-focuses target window."""
    if button not in ("left", "right", "middle"):
        raise InvalidParamsError(message=f"Invalid button: {button}", tool_name="click", param_name="button")
    _validate_screen_coordinates(x, y, "click")
    service = get_input_service()
    return service.click(x=x, y=y, button=button, double=double)


@mcp.tool()
@tool_error_handler("move_mouse")
def move_mouse(x: int, y: int) -> dict:
    """Move mouse cursor to screen coordinates. Auto-focuses target window."""
    _validate_screen_coordinates(x, y, "move_mouse")
    service = get_input_service()
    return service.move_mouse(x=x, y=y)


@mcp.tool()
@tool_error_handler("drag")
def drag(x1: int, y1: int, x2: int, y2: int, duration: float = 0.5) -> dict:
    """Drag from (x1,y1) to (x2,y2). All coordinates must be within screen bounds. Auto-focuses start window."""
    if duration <= 0:
        raise InvalidParamsError(message="duration must be positive", tool_name="drag", param_name="duration")
    _validate_screen_coordinates(x1, y1, "drag")
    _validate_screen_coordinates(x2, y2, "drag")
    service = get_input_service()
    return service.drag(x1=x1, y1=y1, x2=x2, y2=y2, duration=duration)


@mcp.tool()
@tool_error_handler("scroll")
def scroll(x: int, y: int, delta: int = -3) -> dict:
    """Scroll at screen coordinates. Negative delta = scroll down, positive = scroll up."""
    _validate_screen_coordinates(x, y, "scroll")
    service = get_input_service()
    return service.scroll(x=x, y=y, delta=delta)


@mcp.tool()
@tool_error_handler("type_text")
def type_text(text: str) -> dict:
    """Type Unicode text via SendInput. Blind send — activate target window first."""
    if not text:
        raise InvalidParamsError(message="Text cannot be empty", tool_name="type_text", param_name="text")
    service = get_input_service()
    return service.type_text(text=text)


@mcp.tool()
@tool_error_handler("press_keys")
def press_keys(keys: str) -> dict:
    """Press a key combination.

    格式: "ctrl+s", "alt+tab", "win+r", "shift+2" 等，用 "+" 连接。

    修饰键: ctrl (control), alt, shift, win (lwin, rwin)
    功能键: f1-f24
    导航: enter (return), tab, esc (escape), space, backspace (back), delete (del), ins (insert)
    方向: up, down, left, right
    编辑: home, end, pageup (pgup), pagedown (pgdn)
    锁定: capslock, numlock, scrolllock
    小键盘: num0-num9 / numpad0-numpad9, numpad_add, numpad_subtract, numpad_multiply, numpad_divide, numpad_decimal
    符号单字符: = + - [ ] \\ ; ' , . / `（自动通过 VkKeyScanW 解析大小写）
    其他: printscreen (prtsc), pause, apps, sleep, volumeup/down/mute, playpause

    任何不在列表中的可见字符（如 a, 2, =）自动通过 Win32 VkKeyScanW 解析，
    无需手动指定 Shift 状态。press_keys("+") 会自动按下 Shift。
    press_keys("win") 单独发送 Win 键（打开开始菜单）。
    """
    if not keys or not keys.strip():
        raise InvalidParamsError(message="Keys cannot be empty", tool_name="press_keys", param_name="keys")
    service = get_input_service()
    return service.press_keys(keys=keys)


@mcp.tool()
@tool_error_handler("click_element")
def click_element(element_ref: str) -> dict:
    """Click a UI element by reference. Auto-focuses target window. element_ref format: 'hwnd:NNNN', 'point:X,Y', or 'desktop'."""
    if not element_ref or not element_ref.strip():
        raise InvalidParamsError(message="element_ref cannot be empty", tool_name="click_element", param_name="element_ref")
    service = get_input_service()
    return service.click_element(element_ref=element_ref)


@mcp.tool()
@tool_error_handler("type_into_element")
def type_into_element(element_ref: str, text: str) -> dict:
    """Click element then type text. Auto-focuses target window. element_ref format: 'hwnd:NNNN', 'point:X,Y', or 'desktop'."""
    if not element_ref or not element_ref.strip():
        raise InvalidParamsError(message="element_ref cannot be empty", tool_name="type_into_element", param_name="element_ref")
    if not text:
        raise InvalidParamsError(message="Text cannot be empty", tool_name="type_into_element", param_name="text")
    service = get_input_service()
    return service.type_into_element(element_ref=element_ref, text=text)
