"""PeekabooWin - Windows 桌面自动化 MCP 服务器."""

__version__ = "0.1.7"
