"""PaddleOCR engine wrapper."""

import concurrent.futures
import threading
import time
from typing import Optional

import numpy as np
import structlog
from PIL import Image

logger = structlog.get_logger(__name__)


_OCR_INIT_TIMEOUT = 30  # PaddleOCR 初始化最长等 30 秒


class OCREngine:
    """PaddleOCR engine wrapper with lazy initialization and timeout."""

    _instance: Optional["OCREngine"] = None
    _lock: threading.Lock = threading.Lock()

    def __init__(self) -> None:
        self._engine = None
        self._init_error: Optional[str] = None
        self._engine_lock = threading.Lock()

    @classmethod
    def get_instance(cls) -> "OCREngine":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @property
    def _paddle_engine(self):
        if self._engine is not None:
            return self._engine
        if self._init_error:
            raise RuntimeError(f"OCR 引擎初始化失败: {self._init_error}")
        with self._engine_lock:
            if self._engine is not None:
                return self._engine
            if self._init_error:
                raise RuntimeError(f"OCR 引擎初始化失败: {self._init_error}")
            start = time.time()

            def _init():
                from paddleocr import PaddleOCR
                return PaddleOCR(use_angle_cls=True, lang="ch", show_log=False)

            pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
            future = pool.submit(_init)
            try:
                self._engine = future.result(timeout=_OCR_INIT_TIMEOUT)
                elapsed = time.time() - start
                logger.info("paddleocr_initialized", elapsed_seconds=round(elapsed, 2))
            except concurrent.futures.TimeoutError:
                self._init_error = f"初始化超时（>{_OCR_INIT_TIMEOUT}秒），可能是首次下载模型"
                future.cancel()
                logger.warning("paddleocr_init_timeout")
            except Exception as e:
                self._init_error = str(e)
                logger.warning("paddleocr_init_failed", error=str(e))
            finally:
                pool.shutdown(wait=False)
            return self._engine

    def _pil_to_numpy(self, image: Image.Image) -> np.ndarray:
        if image.mode != "RGB":
            image = image.convert("RGB")
        return np.array(image)

    def recognize(self, image: Image.Image, lang: str = "ch") -> list:
        try:
            engine = self._paddle_engine
        except RuntimeError:
            return []  # OCR 不可用，返回空结果
        if engine is None:
            return []
        img_array = self._pil_to_numpy(image)
        result = engine.ocr(img_array, cls=True)
        items = []
        if result and result[0]:
            for line in result[0]:
                bbox, (text, confidence) = line
                x_coords = [p[0] for p in bbox]
                y_coords = [p[1] for p in bbox]
                from peekaboowin.models.elements import BoundingBox
                from peekaboowin.models.ocr import OCRTextItem
                items.append(OCRTextItem(
                    text=text,
                    bbox=BoundingBox(
                        left=int(min(x_coords)),
                        top=int(min(y_coords)),
                        right=int(max(x_coords)),
                        bottom=int(max(y_coords)),
                    ),
                    confidence=confidence,
                ))
        return items


def get_ocr_engine() -> OCREngine:
    """Get the singleton OCR engine instance."""
    return OCREngine.get_instance()
