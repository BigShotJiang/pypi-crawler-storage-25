"""PeekabooWin MCP Server entry point."""

import logging
import sys

import structlog

from mcp.server.fastmcp import FastMCP

from peekaboowin.config import get_config
mcp = FastMCP("peekaboowin")


def _setup_logging() -> None:
    config = get_config()
    processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]
    if config.log_format == "json":
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer(colors=True))
    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(getattr(logging, config.log_level.upper(), logging.INFO)),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )


def _auto_enable_ocr() -> None:
    config = get_config()
    if not config.ocr_enabled:
        try:
            import paddleocr  # noqa: F401
            config.set_ocr_enabled(True)
            structlog.get_logger().info("ocr_auto_enabled", reason="paddleocr_installed")
        except ImportError:
            pass


def _register_tools() -> None:
    import importlib
    tool_modules = [
        "peekaboowin.tools.screen", "peekaboowin.tools.find", "peekaboowin.tools.input",
        "peekaboowin.tools.window", "peekaboowin.tools.wait", "peekaboowin.tools.clipboard",
        "peekaboowin.tools.harvest", "peekaboowin.tools.ocr",
    ]
    logger = structlog.get_logger()
    for module_name in tool_modules:
        try:
            importlib.import_module(module_name)
            logger.debug("tool_module_registered", module=module_name)
        except Exception as e:
            logger.error("tool_module_register_error", module=module_name, error=str(e), error_type=type(e).__name__)


def main() -> None:
    """Main entry point for the MCP server."""
    from peekaboowin.platform.permissions import enable_dpi_awareness
    enable_dpi_awareness()
    _setup_logging()
    _auto_enable_ocr()
    logger = structlog.get_logger()
    logger.info("peekaboowin_starting", version="0.1.7")
    _register_tools()
    try:
        mcp.run()
    except KeyboardInterrupt:
        logger.info("peekaboowin_shutdown")
    except Exception as e:
        logger.exception("peekaboowin_fatal_error")
        sys.exit(1)


def setup() -> None:
    """预下载 OCR 模型和依赖，避免首次调用卡顿。"""
    import sys
    print("PeekabooWin Setup - 预下载 OCR 模型...")
    print()

    # 尝试安装 paddleocr
    print("1/2 检查 PaddleOCR 依赖...")
    try:
        import paddleocr  # noqa: F401
        print("   ✅ PaddleOCR 已安装")
    except ImportError:
        print("   请先安装: uv pip install paddleocr")
        sys.exit(1)

    # 预初始化 OCR 引擎（触发模型下载）
    print("2/2 下载 OCR 模型（约 500MB，首次下载较慢）...")
    import time
    start = time.time()
    try:
        from peekaboowin.platform.ocr_engine import OCREngine
        engine = OCREngine()
        _ = engine._paddle_engine
        elapsed = time.time() - start
        print(f"   ✅ OCR 模型就绪 ({elapsed:.0f} 秒)")
    except Exception as e:
        print(f"   ❌ OCR 模型下载失败: {e}")
        sys.exit(1)

    print()
    print("PeekabooWin 安装完成！")
    print("启动服务: peekaboowin")


if __name__ == "__main__":
    main()
