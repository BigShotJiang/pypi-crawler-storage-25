from __future__ import annotations

import gzip
from pathlib import Path
import threading
import time
from typing import IO

import pytest

import dr_llm.project.project_service as project_service_module
from dr_llm.errors import TransientPersistenceError
from dr_llm.project.docker_project_metadata import (
    ContainerStatus,
    DockerProjectCreateMetadata,
)
from dr_llm.project.errors import (
    DockerContainerConflictError,
    DockerContainerNotFoundError,
    DockerContainerNotRunningError,
    DockerPortAllocatedError,
    ProjectAlreadyExistsError,
    ProjectError,
    ProjectNotFoundError,
)
from dr_llm.project.models import (
    CreateProjectRequest,
    DeleteProjectRequest,
    ProjectCreationBlockReason,
    ProjectDeletionStatus,
    ProjectPoolInspectionReason,
    ProjectPoolInspectionStatus,
)
from dr_llm.pool.admin.deletion import PoolDeletionResult, PoolDeletionStatus
from dr_llm.project.project_info import ProjectInfo
from dr_llm.project.project_service import (
    assess_project_creation,
    delete_project,
    backup_project,
    create_project,
    get_project,
    inspect_projects,
    restore_project,
    start_project,
)


def test_create_project_retries_when_docker_reports_port_collision(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    attempted_ports: list[int] = []

    monkeypatch.setattr(
        project_service_module,
        "get_all_docker_project_metadata",
        list,
    )

    def fake_create(**kwargs: object) -> None:
        project = kwargs["project"]
        assert isinstance(project, DockerProjectCreateMetadata)
        attempted_ports.append(project.port)
        if project.port == 5500:
            raise DockerPortAllocatedError()

    monkeypatch.setattr(project_service_module, "create_project_container", fake_create)
    monkeypatch.setattr(
        project_service_module, "_port_has_listener", lambda port: False
    )
    monkeypatch.setattr(
        project_service_module,
        "wait_docker_ready",
        lambda **kwargs: ContainerStatus.RUNNING,
    )
    monkeypatch.setattr(project_service_module, "wait_dsn_ready", lambda dsn: None)

    project = create_project(CreateProjectRequest(project_name="demo"))

    assert attempted_ports == [5500, 5501]
    assert project.port == 5501
    assert project.status == ContainerStatus.RUNNING


def test_create_project_skips_ports_with_existing_listeners(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    attempted_ports: list[int] = []

    monkeypatch.setattr(
        project_service_module,
        "get_all_docker_project_metadata",
        list,
    )
    monkeypatch.setattr(
        project_service_module, "_port_has_listener", lambda port: port == 5500
    )

    def fake_create(**kwargs: object) -> None:
        project = kwargs["project"]
        assert isinstance(project, DockerProjectCreateMetadata)
        attempted_ports.append(project.port)

    monkeypatch.setattr(project_service_module, "create_project_container", fake_create)
    monkeypatch.setattr(
        project_service_module,
        "wait_docker_ready",
        lambda **kwargs: ContainerStatus.RUNNING,
    )
    monkeypatch.setattr(project_service_module, "wait_dsn_ready", lambda dsn: None)

    project = create_project(CreateProjectRequest(project_name="demo"))

    assert attempted_ports == [5501]
    assert project.port == 5501
    assert project.status == ContainerStatus.RUNNING


def test_create_project_translates_container_conflict(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        project_service_module,
        "get_all_docker_project_metadata",
        list,
    )

    def fake_create(**kwargs: object) -> None:
        _ = kwargs
        raise DockerContainerConflictError()

    monkeypatch.setattr(project_service_module, "create_project_container", fake_create)
    monkeypatch.setattr(
        project_service_module, "_port_has_listener", lambda port: False
    )

    with pytest.raises(
        ProjectAlreadyExistsError,
        match="Project 'demo' already exists",
    ):
        create_project(CreateProjectRequest(project_name="demo"))


def test_create_project_cleans_up_container_when_ready_check_fails(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    destroyed: list[tuple[str, str]] = []

    monkeypatch.setattr(
        project_service_module,
        "get_all_docker_project_metadata",
        list,
    )
    monkeypatch.setattr(
        project_service_module, "_port_has_listener", lambda port: False
    )
    monkeypatch.setattr(
        project_service_module, "create_project_container", lambda **kwargs: None
    )

    def fake_wait_docker_ready(**kwargs: object) -> ContainerStatus:
        _ = kwargs
        raise ProjectError("container did not become ready")

    def fake_destroy(container_name: str, volume_name: str) -> None:
        destroyed.append((container_name, volume_name))

    monkeypatch.setattr(
        project_service_module, "wait_docker_ready", fake_wait_docker_ready
    )
    monkeypatch.setattr(project_service_module, "call_docker_destroy", fake_destroy)

    with pytest.raises(ProjectError, match="container did not become ready"):
        create_project(CreateProjectRequest(project_name="demo"))

    assert destroyed == [("dr-llm-pg-demo", "dr-llm-data-demo")]


def test_create_project_cleans_up_container_when_dsn_probe_fails(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the host-side DSN probe fails after wait_docker_ready succeeds,
    the freshly-created container must still be destroyed so callers don't
    leak Docker resources on a failed startup."""
    destroyed: list[tuple[str, str]] = []
    probed_dsns: list[str] = []

    monkeypatch.setattr(
        project_service_module,
        "get_all_docker_project_metadata",
        list,
    )
    monkeypatch.setattr(
        project_service_module, "_port_has_listener", lambda port: False
    )
    monkeypatch.setattr(
        project_service_module, "create_project_container", lambda **kwargs: None
    )
    monkeypatch.setattr(
        project_service_module,
        "wait_docker_ready",
        lambda **kwargs: ContainerStatus.RUNNING,
    )

    def fake_wait_dsn_ready(dsn: str) -> None:
        probed_dsns.append(dsn)
        raise ProjectError("postgres did not accept SQL connections")

    monkeypatch.setattr(project_service_module, "wait_dsn_ready", fake_wait_dsn_ready)
    monkeypatch.setattr(
        project_service_module,
        "call_docker_destroy",
        lambda container_name, volume_name: destroyed.append(
            (container_name, volume_name)
        ),
    )

    with pytest.raises(ProjectError, match="did not accept SQL connections"):
        create_project(CreateProjectRequest(project_name="demo"))

    assert probed_dsns == ["postgresql://postgres:postgres@localhost:5500/dr_llm"]
    assert destroyed == [("dr-llm-pg-demo", "dr-llm-data-demo")]


def test_assess_project_creation_reports_invalid_name_existing_project_and_cooldown(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    recent = ProjectInfo(
        name="demo",
        port=5500,
        created_at=project_service_module.datetime.now(project_service_module.UTC),
    )
    monkeypatch.setattr(project_service_module, "list_projects", lambda: [recent])

    readiness = assess_project_creation(CreateProjectRequest(project_name="Demo"))

    assert readiness.allowed is False
    assert {violation.reason for violation in readiness.violations} == {
        ProjectCreationBlockReason.invalid_name,
        ProjectCreationBlockReason.cooldown_active,
    }


def test_assess_project_creation_reports_duplicate_project(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        project_service_module,
        "list_projects",
        lambda: [ProjectInfo(name="demo", port=5500)],
    )

    readiness = assess_project_creation(CreateProjectRequest(project_name="demo"))

    assert readiness.allowed is False
    assert [violation.reason for violation in readiness.violations] == [
        ProjectCreationBlockReason.already_exists
    ]


def test_inspect_projects_includes_discovered_pool_names(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    projects = [
        ProjectInfo(name="running", port=5500, status=ContainerStatus.RUNNING),
        ProjectInfo(name="stopped", status=ContainerStatus.STOPPED),
    ]
    monkeypatch.setattr(project_service_module, "list_projects", lambda: projects)
    monkeypatch.setattr(
        "dr_llm.pool.admin.discovery.discover_pools",
        lambda dsn: ["alpha", "beta"] if dsn.endswith(":5500/dr_llm") else [],
    )

    summaries = inspect_projects()

    running_summary, stopped_summary = summaries

    assert running_summary.project.name == "running"
    assert (
        running_summary.pool_inspection.status == ProjectPoolInspectionStatus.discovered
    )
    assert running_summary.pool_inspection.reason is None
    assert running_summary.pool_inspection.pool_names == ["alpha", "beta"]
    assert running_summary.pool_inspection.pool_count == 2
    assert running_summary.pool_inspection.inspected_at is not None

    assert stopped_summary.project.name == "stopped"
    assert stopped_summary.pool_inspection.status == ProjectPoolInspectionStatus.skipped
    assert (
        stopped_summary.pool_inspection.reason
        == ProjectPoolInspectionReason.project_not_running
    )
    assert stopped_summary.pool_inspection.pool_names == []
    assert stopped_summary.pool_inspection.pool_count == 0
    assert stopped_summary.pool_inspection.inspected_at is not None


def test_inspect_projects_skips_projects_with_missing_dsn(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project = ProjectInfo(name="running", status=ContainerStatus.RUNNING)
    monkeypatch.setattr(project_service_module, "list_projects", lambda: [project])
    monkeypatch.setattr(
        "dr_llm.pool.admin.discovery.discover_pools",
        lambda dsn: (_ for _ in ()).throw(AssertionError("should not inspect pools")),
    )

    summaries = inspect_projects()
    summary = summaries[0]

    assert summary.project.name == "running"
    assert summary.pool_inspection.status == ProjectPoolInspectionStatus.skipped
    assert summary.pool_inspection.reason == ProjectPoolInspectionReason.missing_dsn
    assert summary.pool_inspection.pool_names == []
    assert summary.pool_inspection.pool_count == 0


def test_inspect_projects_reports_connection_failures(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    project = ProjectInfo(name="running", port=5500, status=ContainerStatus.RUNNING)
    monkeypatch.setattr(project_service_module, "list_projects", lambda: [project])
    monkeypatch.setattr(
        "dr_llm.pool.admin.discovery.discover_pools",
        lambda dsn: (_ for _ in ()).throw(TransientPersistenceError("db unavailable")),
    )

    with caplog.at_level("WARNING", logger="dr_llm.project.project_service"):
        summaries = inspect_projects()

    summary = summaries[0]
    assert summary.project.name == "running"
    assert summary.pool_inspection.status == ProjectPoolInspectionStatus.failed
    assert (
        summary.pool_inspection.reason == ProjectPoolInspectionReason.connection_failed
    )
    assert summary.pool_inspection.pool_names == []
    assert summary.pool_inspection.pool_count == 0
    assert not any(record.levelname == "ERROR" for record in caplog.records)


def test_inspect_projects_does_not_log_skipped_projects(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    project = ProjectInfo(name="stopped", status=ContainerStatus.STOPPED)
    monkeypatch.setattr(project_service_module, "list_projects", lambda: [project])

    with caplog.at_level("WARNING", logger="dr_llm.project.project_service"):
        summaries = inspect_projects()

    summary = summaries[0]
    assert summary.pool_inspection.status == ProjectPoolInspectionStatus.skipped
    assert caplog.records == []


def test_get_project_raises_project_not_found(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        project_service_module,
        "get_docker_project_metadata",
        lambda container_name: None,
    )

    with pytest.raises(ProjectNotFoundError, match="Project 'demo' not found"):
        get_project("demo")


@pytest.mark.parametrize(
    ("function_name", "docker_call_name"),
    [
        ("start_project", "call_docker_start"),
        ("stop_project", "call_docker_stop"),
    ],
)
def test_direct_operations_translate_missing_container_to_project_not_found(
    monkeypatch: pytest.MonkeyPatch,
    function_name: str,
    docker_call_name: str,
) -> None:
    def raise_missing_container(*args: object, **kwargs: object) -> None:
        _ = (args, kwargs)
        raise DockerContainerNotFoundError()

    monkeypatch.setattr(
        project_service_module, docker_call_name, raise_missing_container
    )

    with pytest.raises(ProjectNotFoundError, match="Project 'demo' not found"):
        getattr(project_service_module, function_name)("demo")


def test_destroy_project_wrapper_translates_missing_project(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        project_service_module,
        "delete_project",
        lambda request: project_service_module.ProjectDeletionResult(
            request=request,
            status=project_service_module.ProjectDeletionStatus.blocked,
            violations=[
                project_service_module.ProjectDeletionViolation(
                    reason=project_service_module.ProjectDeletionBlockReason.project_not_found,
                    message="Project 'demo' not found",
                    project_name="demo",
                )
            ],
            message="Project 'demo' not found",
        ),
    )

    with pytest.raises(ProjectNotFoundError, match="Project 'demo' not found"):
        project_service_module.destroy_project("demo")


def test_start_project_returns_fresh_project_metadata_after_ready(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    started_containers: list[str] = []
    waited_for: list[tuple[str, str, str]] = []

    def fake_start(container_name: str) -> None:
        started_containers.append(container_name)

    def fake_wait_docker_ready(
        *,
        container_name: str,
        db_user: str,
        db_name: str,
    ) -> ContainerStatus:
        waited_for.append((container_name, db_user, db_name))
        return ContainerStatus.RUNNING

    def fake_get_project(name: str) -> ProjectInfo:
        return ProjectInfo(name=name, port=5500, status=ContainerStatus.RUNNING)

    probed_dsns: list[str] = []

    def fake_wait_dsn_ready(dsn: str) -> None:
        probed_dsns.append(dsn)

    monkeypatch.setattr(project_service_module, "call_docker_start", fake_start)
    monkeypatch.setattr(
        project_service_module, "wait_docker_ready", fake_wait_docker_ready
    )
    monkeypatch.setattr(project_service_module, "wait_dsn_ready", fake_wait_dsn_ready)
    monkeypatch.setattr(project_service_module, "get_project", fake_get_project)

    project = start_project("demo")

    assert started_containers == ["dr-llm-pg-demo"]
    assert waited_for == [("dr-llm-pg-demo", "postgres", "dr_llm")]
    assert probed_dsns == ["postgresql://postgres:postgres@localhost:5500/dr_llm"]
    assert project.port == 5500
    assert project.status == ContainerStatus.RUNNING


def test_backup_project_does_not_precheck_cached_running_status(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    def fake_pg_dump_stream(
        *,
        container_name: str,
        db_user: str,
        db_name: str,
        output_stream: IO[bytes],
    ) -> None:
        assert container_name == "dr-llm-pg-demo"
        assert db_user == "postgres"
        assert db_name == "dr_llm"
        output_stream.write(b"select 1;\n")

    monkeypatch.setattr(
        project_service_module,
        "call_docker_pg_dump_stream",
        fake_pg_dump_stream,
    )

    backup_file = backup_project("demo", tmp_path)

    assert backup_file.exists()
    with gzip.open(backup_file, "rb") as f:
        assert f.read() == b"select 1;\n"


def test_backup_project_translates_missing_container_to_project_not_found(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    def fake_pg_dump_stream(
        *,
        container_name: str,
        db_user: str,
        db_name: str,
        output_stream: IO[bytes],
    ) -> None:
        _ = (container_name, db_user, db_name, output_stream)
        raise DockerContainerNotFoundError()

    monkeypatch.setattr(
        project_service_module,
        "call_docker_pg_dump_stream",
        fake_pg_dump_stream,
    )

    with pytest.raises(ProjectNotFoundError, match="Project 'demo' not found"):
        backup_project("demo", tmp_path)


def test_backup_project_translates_stopped_container_to_project_error(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    def fake_pg_dump_stream(
        *,
        container_name: str,
        db_user: str,
        db_name: str,
        output_stream: IO[bytes],
    ) -> None:
        _ = (container_name, db_user, db_name, output_stream)
        raise DockerContainerNotRunningError()

    monkeypatch.setattr(
        project_service_module,
        "call_docker_pg_dump_stream",
        fake_pg_dump_stream,
    )

    with pytest.raises(
        ProjectError,
        match="Project 'demo' is not running\\. Start it first\\.",
    ):
        backup_project("demo", tmp_path)


def test_restore_project_does_not_precheck_cached_running_status(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    backup_file = tmp_path / "demo.sql.gz"
    with gzip.open(backup_file, "wb") as f:
        f.write(b"select 1;\n")
    captured: dict[str, object] = {}

    def fake_swap_in_db(
        *,
        sql_stream: IO[bytes],
        container_name: str,
        db_user: str,
        target_db_name: str,
    ) -> None:
        captured["sql_bytes"] = sql_stream.read()
        captured.update(
            {
                "container_name": container_name,
                "db_user": db_user,
                "target_db_name": target_db_name,
            }
        )

    monkeypatch.setattr(project_service_module, "docker_swap_in_db", fake_swap_in_db)

    restore_project("demo", backup_file)

    assert captured["sql_bytes"] == b"select 1;\n"
    assert captured["container_name"] == "dr-llm-pg-demo"
    assert captured["target_db_name"] == "dr_llm"


def test_restore_project_translates_missing_container_to_project_not_found(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    backup_file = tmp_path / "demo.sql.gz"
    with gzip.open(backup_file, "wb") as f:
        f.write(b"select 1;\n")

    def fake_swap_in_db(
        *,
        sql_stream: IO[bytes],
        container_name: str,
        db_user: str,
        target_db_name: str,
    ) -> None:
        _ = (sql_stream, container_name, db_user, target_db_name)
        raise DockerContainerNotFoundError()

    monkeypatch.setattr(project_service_module, "docker_swap_in_db", fake_swap_in_db)

    with pytest.raises(ProjectNotFoundError, match="Project 'demo' not found"):
        restore_project("demo", backup_file)


def test_restore_project_translates_stopped_container_to_project_error(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    backup_file = tmp_path / "demo.sql.gz"
    with gzip.open(backup_file, "wb") as f:
        f.write(b"select 1;\n")

    def fake_swap_in_db(
        *,
        sql_stream: IO[bytes],
        container_name: str,
        db_user: str,
        target_db_name: str,
    ) -> None:
        _ = (sql_stream, container_name, db_user, target_db_name)
        raise DockerContainerNotRunningError()

    monkeypatch.setattr(project_service_module, "docker_swap_in_db", fake_swap_in_db)

    with pytest.raises(
        ProjectError,
        match="Project 'demo' is not running\\. Start it first\\.",
    ):
        restore_project("demo", backup_file)


def test_restore_project_missing_file_raises_native_file_not_found(
    tmp_path: Path,
) -> None:
    backup_file = tmp_path / "missing.sql.gz"

    with pytest.raises(FileNotFoundError, match=str(backup_file)):
        restore_project("demo", backup_file)


def test_restore_project_rejects_plain_sql_files(
    tmp_path: Path,
) -> None:
    backup_file = tmp_path / "demo.sql"
    backup_file.write_text("select 1;\n")

    with pytest.raises(
        ProjectError,
        match=r"Restore only supports gzip-compressed SQL backups \(.sql.gz\)\.",
    ):
        restore_project("demo", backup_file)


def test_backup_project_removes_partial_file_when_streaming_fails(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    def fake_pg_dump_stream(
        *,
        container_name: str,
        db_user: str,
        db_name: str,
        output_stream: IO[bytes],
    ) -> None:
        assert container_name == "dr-llm-pg-demo"
        assert db_user == "postgres"
        assert db_name == "dr_llm"
        output_stream.write(b"partial dump\n")
        raise RuntimeError("pg_dump failed")

    monkeypatch.setattr(
        project_service_module,
        "call_docker_pg_dump_stream",
        fake_pg_dump_stream,
    )

    with pytest.raises(RuntimeError, match="pg_dump failed"):
        backup_project("demo", tmp_path)

    assert list((tmp_path / "demo").glob("*.sql.gz")) == []


def test_delete_project_destroys_running_project_with_no_pools(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    destroyed: list[tuple[str, str]] = []
    project = ProjectInfo(name="demo", port=5500, status=ContainerStatus.RUNNING)

    monkeypatch.setattr(
        project_service_module, "maybe_get_project", lambda name: project
    )
    monkeypatch.setattr(
        "dr_llm.pool.admin.discovery.discover_pools",
        lambda dsn: [],
    )
    monkeypatch.setattr(
        project_service_module,
        "call_docker_destroy",
        lambda container_name, volume_name: destroyed.append(
            (container_name, volume_name)
        ),
    )

    result = delete_project(DeleteProjectRequest(project_name="demo"))

    assert result.status == ProjectDeletionStatus.deleted
    assert result.destroyed_project_resources is True
    assert result.pool_results == []
    assert destroyed == [("dr-llm-pg-demo", "dr-llm-data-demo")]


def test_delete_project_autostarts_stopped_project(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    started: list[str] = []
    destroyed: list[tuple[str, str]] = []
    stopped_project = ProjectInfo(name="demo", status=ContainerStatus.STOPPED)
    running_project = ProjectInfo(
        name="demo", port=5500, status=ContainerStatus.RUNNING
    )

    monkeypatch.setattr(
        project_service_module, "maybe_get_project", lambda name: stopped_project
    )
    monkeypatch.setattr(
        project_service_module,
        "start_project",
        lambda name: started.append(name) or running_project,
    )
    monkeypatch.setattr(
        "dr_llm.pool.admin.discovery.discover_pools",
        lambda dsn: [],
    )
    monkeypatch.setattr(
        project_service_module,
        "call_docker_destroy",
        lambda container_name, volume_name: destroyed.append(
            (container_name, volume_name)
        ),
    )

    result = delete_project(DeleteProjectRequest(project_name="demo"))

    assert result.status == ProjectDeletionStatus.deleted
    assert result.temporarily_started is True
    assert started == ["demo"]
    assert destroyed == [("dr-llm-pg-demo", "dr-llm-data-demo")]


def test_delete_project_preserves_discovered_pool_order(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    destroyed: list[tuple[str, str]] = []
    project = ProjectInfo(name="demo", port=5500, status=ContainerStatus.RUNNING)
    beta_completed = threading.Event()
    gamma_completed = threading.Event()

    def fake_delete_one(project_name: str, pool_name: str) -> PoolDeletionResult:
        _ = project_name
        if pool_name == "alpha":
            beta_completed.wait(timeout=1)
            gamma_completed.wait(timeout=1)
        if pool_name == "beta":
            beta_completed.set()
        if pool_name == "gamma":
            gamma_completed.set()
        return PoolDeletionResult(
            request=project_service_module.DeletePoolRequest(
                project_name="demo",
                pool_name=pool_name,
            ),
            status=PoolDeletionStatus.deleted,
            deleted_table_names=[f"pool_{pool_name}_samples"],
        )

    monkeypatch.setattr(
        project_service_module, "maybe_get_project", lambda name: project
    )
    monkeypatch.setattr(
        "dr_llm.pool.admin.discovery.discover_pools",
        lambda dsn: ["alpha", "beta", "gamma"],
    )
    monkeypatch.setattr(
        project_service_module,
        "_delete_single_pool_for_project",
        fake_delete_one,
    )
    monkeypatch.setattr(
        project_service_module,
        "call_docker_destroy",
        lambda container_name, volume_name: destroyed.append(
            (container_name, volume_name)
        ),
    )

    result = delete_project(DeleteProjectRequest(project_name="demo"))

    assert result.status == ProjectDeletionStatus.deleted
    assert [pool_result.request.pool_name for pool_result in result.pool_results] == [
        "alpha",
        "beta",
        "gamma",
    ]
    assert destroyed == [("dr-llm-pg-demo", "dr-llm-data-demo")]


def test_delete_project_fail_fast_restores_temporary_start_state(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    started: list[str] = []
    stopped: list[str] = []
    destroyed: list[tuple[str, str]] = []
    observed_calls: list[str] = []
    stopped_project = ProjectInfo(name="demo", status=ContainerStatus.STOPPED)
    running_project = ProjectInfo(
        name="demo", port=5500, status=ContainerStatus.RUNNING
    )

    def fake_delete_one(project_name: str, pool_name: str) -> PoolDeletionResult:
        _ = project_name
        observed_calls.append(pool_name)
        if pool_name == "alpha":
            return PoolDeletionResult(
                request=project_service_module.DeletePoolRequest(
                    project_name="demo",
                    pool_name=pool_name,
                ),
                status=PoolDeletionStatus.failed,
                message="boom",
            )
        time.sleep(0.02)
        return PoolDeletionResult(
            request=project_service_module.DeletePoolRequest(
                project_name="demo",
                pool_name=pool_name,
            ),
            status=PoolDeletionStatus.deleted,
        )

    monkeypatch.setattr(
        project_service_module, "maybe_get_project", lambda name: stopped_project
    )
    monkeypatch.setattr(
        project_service_module,
        "start_project",
        lambda name: started.append(name) or running_project,
    )
    monkeypatch.setattr(
        project_service_module,
        "stop_project",
        lambda name: stopped.append(name),
    )
    monkeypatch.setattr(
        "dr_llm.pool.admin.discovery.discover_pools",
        lambda dsn: ["alpha", "beta", "gamma"],
    )
    monkeypatch.setattr(
        project_service_module,
        "_POOL_DELETE_MAX_WORKERS",
        2,
    )
    monkeypatch.setattr(
        project_service_module,
        "_delete_single_pool_for_project",
        fake_delete_one,
    )
    monkeypatch.setattr(
        project_service_module,
        "call_docker_destroy",
        lambda container_name, volume_name: destroyed.append(
            (container_name, volume_name)
        ),
    )

    result = delete_project(DeleteProjectRequest(project_name="demo"))

    assert result.status == ProjectDeletionStatus.failed
    assert result.temporarily_started is True
    assert started == ["demo"]
    assert stopped == ["demo"]
    assert destroyed == []
    assert observed_calls == ["alpha", "beta"]
    assert [pool_result.status for pool_result in result.pool_results] == [
        PoolDeletionStatus.failed,
        PoolDeletionStatus.deleted,
        PoolDeletionStatus.cancelled,
    ]
