initialized = False
