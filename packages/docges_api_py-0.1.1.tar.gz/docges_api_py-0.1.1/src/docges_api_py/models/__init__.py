"""DocGes API models (Pydantic)."""
from .auth import AuthRequest, AuthResponse, DocGesAuthError
from .document import Document
from .requests import (
    FileUpload,
    ReqAuthData,
    ReqCreateCategory,
    ReqData,
    ReqDeleteCategory,
    ReqMoveContent,
    ReqRemoveContent,
    ReqRenameCategory,
    ReqSearchContent,
    ReqUpdateContent,
    ReqUpload,
    SearchDateValue,
    SearchFilterValue,
)
from .responses import (
    FileDownloadResponse,
    ResCat,
    ResCatItem,
    ResFileDownload,
    ResSearch,
    ResSearchItem,
    ResultActionModel,
)

__all__ = [
    "AuthRequest",
    "AuthResponse",
    "DocGesAuthError",
    "Document",
    "FileDownloadResponse",
    "FileUpload",
    "ReqAuthData",
    "ReqCreateCategory",
    "ReqData",
    "ReqDeleteCategory",
    "ReqMoveContent",
    "ReqRemoveContent",
    "ReqRenameCategory",
    "ReqSearchContent",
    "ReqUpdateContent",
    "ReqUpload",
    "ResCat",
    "ResCatItem",
    "ResFileDownload",
    "ResSearch",
    "ResSearchItem",
    "ResultActionModel",
    "SearchDateValue",
    "SearchFilterValue",
]
