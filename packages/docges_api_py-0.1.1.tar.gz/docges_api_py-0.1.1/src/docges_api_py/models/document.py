"""Pydantic models for DocGes document/content operations."""

from __future__ import annotations

from pydantic import BaseModel


class Document(BaseModel):
    """Represents a DocGes document (subset — extend as needed)."""

    id: str
    name: str
    # Add more fields as discovered from API responses
    # e.g., size: int | None = None
    #       mime_type: str | None = None
