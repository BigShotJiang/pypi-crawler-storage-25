"""Pydantic v2 models for DocGes API responses."""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class DocGesResponseModel(BaseModel):
    """Base model for DocGes responses. Allows underscore-prefixed fields (e.g., _Nombre)."""
    model_config = ConfigDict(underscore_attrs_are_private=False)


# --- Category & Tree Responses ---

class ResCatItem(DocGesResponseModel):
    """Single category item in tree responses."""
    Nombre: str
    SID: str
    CategoriasHijas: list[dict] | None = None
    Documentos: list[dict] | None = None
    CategoriasHijas: list[dict] | None = None
    Documentos: list[dict] | None = None


class ResCat(DocGesResponseModel):
    """Response from /Content/LoadIniCats and /Content/LoadChilds."""
    CategoriasHijas: list[dict] | None = None
    Documentos: list[dict] | None = None

    @classmethod
    def from_json(cls, data: dict) -> ResCat:
        """Create ResCat from API JSON response."""
        # Map underscore-prefixed fields in nested items
        if data.get("CategoriasHijas"):
            mapped_cats = []
            for cat in data["CategoriasHijas"]:
                mapped = {k[1:] if k.startswith('_') else k: v for k, v in cat.items()}
                mapped_cats.append(mapped)
            data["CategoriasHijas"] = mapped_cats
        return cls(**data)


# --- Search Responses ---

class ResSearchItem(DocGesResponseModel):
    """Single search result item."""
    SID: str
    Nombre: str
    Tamanyo: int | None = None
    FechaModificacion: str | None = None
    model_config = ConfigDict(
        extra='ignore'
    )

    @classmethod
    def from_json(cls, data: dict) -> ResSearchItem:
        """Create from API JSON, mapping underscore-prefixed fields."""
        mapped = {}
        for key, val in data.items():
            new_key = key[1:] if key.startswith('_') else key
            mapped[new_key] = val
        return cls(**mapped)
    # Add more fields as discovered from API


class ResSearch(DocGesResponseModel):
    """Response from /Content/SearchContent."""
    results: list[dict] | None = None
    message: str = "OK"

    @classmethod
    def from_json(cls, data: dict) -> ResSearch:
        """Create ResSearch from API JSON response."""
        # Handle nested result structure if present
        if "result" in data:
            return cls(results=data["result"].get("results"), message=data.get("message", "OK"))
        return cls(results=data.get("results"), message=data.get("message", "OK"))


# --- Download Responses ---

class FileDownloadResponse(DocGesResponseModel):
    """File data in download response."""
    data: str  # base64-encoded
    name: str
    type: str = "application/octet-stream"


class ResFileDownload(DocGesResponseModel):
    """Response from /Content/Download."""
    result: FileDownloadResponse
    message: str = "OK"

    @classmethod
    def from_json(cls, data: dict) -> ResFileDownload:
        """Create ResFileDownload from API JSON response."""
        if data.get("result") and isinstance(data["result"], dict):
            return cls(result=FileDownloadResponse(**data["result"]), message=data.get("message", "OK"))
        # Handle error case (result is None or non-dict)
        return cls(result=FileDownloadResponse(data="", name="", type=""), message=data.get("message", "Error"))


# --- Generic Response ---

class ResultActionModel(DocGesResponseModel):
    """Generic API response wrapper (result + message)."""
    result: object | None = None
    message: str = "OK"
