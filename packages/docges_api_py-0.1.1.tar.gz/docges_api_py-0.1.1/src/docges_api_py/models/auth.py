"""Pydantic models for DocGes authentication."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class AuthRequest(BaseModel):
    username: str
    password: str
    appID: str


class AuthResponse(BaseModel):
    """Response from /Auth/Login — session-based, NOT JWT.

    The DocGes API returns userInfo + wareHouseInfo (EF Core objects with
    $id, ChangeTracker, etc.). There is no token.
    """

    user_info: dict[str, Any] = Field(alias="userInfo")
    ware_house_info: dict[str, Any] = Field(alias="wareHouseInfo")

    model_config = {"populate_by_name": True}


class DocGesAuthError(Exception):
    """Raised when DocGes login fails or the response payload is invalid."""
