"""Pydantic v2 models for DocGes API requests."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from .auth import AuthRequest

# --- Auth & Session ---

class ReqAuthData(BaseModel):
    """Login data + response context for authenticated requests.

    Both fields are optional so that this model can be used in either direction:
    - auth phase: only login_docges_data is set
    - content phase: only login_response (the stored session dict) is set
    """

    login_docges_data: AuthRequest | None = None
    login_response: dict[str, Any] | None = None


# --- Content Models ---

class FileUpload(BaseModel):
    """File data for upload requests."""
    fileData: str  # base64-encoded
    fileName: str
    SIDCategory: str
    erpRelation: str = ""
    erpProperty: str = ""


class ReqUpload(BaseModel):
    """Upload request payload."""
    fileModel: FileUpload
    requestModel: dict


class ReqData(BaseModel):
    """Generic content request with SID."""
    contenidoModel: dict  # {"SIDContenido": str}
    requestModel: dict | None = None


# --- Search Models ---

class SearchFilterValue(BaseModel):
    """Field value filter for search."""
    field: str
    mode: str
    text: str


class SearchDateValue(BaseModel):
    """Date range filter for search."""
    field: str
    exactDate: str | None = None
    fromDate: str | None = None
    toDate: str | None = None


class ReqSearchContent(BaseModel):
    """Search content request payload."""
    fieldValues: list[dict] | None = None
    dateValues: list[dict] | None = None
    requestModel: dict | None = None


# --- Category Models ---

class ReqCreateCategory(BaseModel):
    """Create category request."""
    parentSID: str
    name: str
    requestModel: dict


class ReqRenameCategory(BaseModel):
    """Rename category request."""
    SID: str
    name: str
    requestModel: dict


class ReqDeleteCategory(BaseModel):
    """Delete category request."""
    SID: str
    requestModel: dict


# --- Document Management Models ---

class ReqMoveContent(BaseModel):
    """Move document request."""
    contentSID: str
    destinationSID: str
    requestModel: dict


class ReqUpdateContent(BaseModel):
    """Update document metadata request."""
    contentModel: dict
    requestModel: dict


class ReqRemoveContent(BaseModel):
    """Remove multiple documents request."""
    contenidos: list[dict]
    requestModel: dict
