"""DocGes API Python client — async, typed, tested."""

from docges_api_py.client import AsyncDocGes, AuthenticationError, DocGesError, Endpoints, RequestError
from docges_api_py.models import (
    # Auth
    AuthRequest,
    AuthResponse,
    # Document
    Document,
    FileDownloadResponse,
    FileUpload,
    ReqAuthData,
    ReqCreateCategory,
    # Requests
    ReqData,
    ReqDeleteCategory,
    ReqMoveContent,
    ReqRemoveContent,
    ReqRenameCategory,
    ReqSearchContent,
    ReqUpdateContent,
    ReqUpload,
    # Responses
    ResCat,
    ResCatItem,
    ResFileDownload,
    ResSearch,
    ResSearchItem,
    ResultActionModel,
    SearchDateValue,
    SearchFilterValue,
)
from docges_api_py.models.auth import DocGesAuthError

__version__ = "0.2.0"  # Phase 5: All endpoints implemented
__all__ = [
    "AsyncDocGes",
    "AuthRequest",
    "AuthResponse",
    "AuthenticationError",
    "DocGesAuthError",
    "DocGesError",
    "Document",
    "Endpoints",
    "FileDownloadResponse",
    "FileUpload",
    "ReqAuthData",
    "ReqCreateCategory",
    "ReqData",
    "ReqDeleteCategory",
    "ReqMoveContent",
    "ReqRemoveContent",
    "ReqRenameCategory",
    "ReqSearchContent",
    "ReqUpdateContent",
    "ReqUpload",
    "RequestError",
    "ResCat",
    "ResCatItem",
    "ResFileDownload",
    "ResSearch",
    "ResSearchItem",
    "ResultActionModel",
    "SearchDateValue",
    "SearchFilterValue",
]
