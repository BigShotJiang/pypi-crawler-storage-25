"""Tests for AsyncDocGes.get_document()."""

import httpx
import pytest
import respx

from docges_api_py import AsyncDocGes, RequestError
from docges_api_py.models.document import Document

REAL_LOGIN_PAYLOAD = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg"},
}


@pytest.mark.asyncio
async def test_get_document_success():
    """Test that get_document returns a Document on success."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        router.post(f"{base_url}/Content/Download").mock(
            return_value=httpx.Response(
                200,
                json={
                    "result": {"name": "test.pdf", "data": "base64content", "type": "application/pdf"},
                    "message": "OK",
                },
            )
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD  # inject session, skip auth

        doc = await client.get_document("doc-123")

        assert isinstance(doc, Document)
        assert doc.id == "doc-123"
        assert doc.name == "test.pdf"

        await client.close()


@pytest.mark.asyncio
async def test_get_document_failure():
    """Test that get_document raises RequestError on persistent 500s."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx", assert_all_called=False) as router:
        router.post(f"{base_url}/Content/Download").mock(
            return_value=httpx.Response(500, json={"error": "Internal Server Error"})
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD
        client.timeout = 0.01  # fast backoff
        client.intents = 1    # only 1 attempt

        with pytest.raises(RequestError):
            await client.get_document("doc-123")

        await client.close()
