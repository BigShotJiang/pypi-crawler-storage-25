"""Tests for models/responses.py — TDD RED phase."""
from docges_api_py.models.responses import (
    FileDownloadResponse,
    ResCat,
    ResFileDownload,
    ResSearch,
    ResSearchItem,
)


def test_res_cat_creation():
    """Test ResCat can be created with CategoriasHijas."""
    cat = ResCat(
        CategoriasHijas=[{"Nombre": "Cat1", "SID": "sid-1"}],
        Documentos=[])
    assert len(cat.CategoriasHijas) == 1
    assert cat.CategoriasHijas[0]["Nombre"] == "Cat1"


def test_res_cat_from_json():
    """Test ResCat.from_json classmethod."""
    data = {
        "CategoriasHijas": [{"Nombre": "Child1", "SID": "c1"}],
        "Documentos": [{"Nombre": "Doc1", "SID": "d1"}]
    }
    res = ResCat.from_json(data)
    assert isinstance(res, ResCat)
    assert len(res.Documentos) == 1


def test_res_file_download():
    """Test ResFileDownload with FileDownloadResponse nested."""
    file_resp = FileDownloadResponse(
        data="base64data",
        name="test.pdf",
        type="application/pdf"
    )
    res = ResFileDownload(result=file_resp, message="OK")
    assert res.result.name == "test.pdf"
    assert res.message == "OK"


def test_res_file_download_from_json():
    """Test ResFileDownload.from_json with nested result."""
    data = {
        "result": {
            "data": "abc123",
            "name": "doc.docx",
            "type": "application/octet-stream"
        },
        "message": "OK"
    }
    res = ResFileDownload.from_json(data)
    assert res.result.data == "abc123"
    assert res.result.type == "application/octet-stream"


def test_res_search():
    """Test ResSearch with results list."""
    # Use from_json to map API fields (_Nombre -> Nombre)
    data = {
        "results": [{"_SID": "s1", "_Nombre": "Doc"}],
        "message": "OK"
    }
    res = ResSearch.from_json(data)
    assert len(res.results) == 1
    # Access the dict directly (results is List[dict])
    assert res.results[0]["_Nombre"] == "Doc"  # API returns with underscore


def test_res_search_model():
    """Triangulation: Test ResSearchItem model directly."""
    item = ResSearchItem(SID="s1", Nombre="Doc")
    assert item.SID == "s1"
    assert item.Nombre == "Doc"
    # model_dump should work with non-underscore fields
    dumped = item.model_dump()
    assert dumped["SID"] == "s1"
    assert dumped["Nombre"] == "Doc"


def test_res_search_empty():
    """Triangulation: ResSearch with no results."""
    res = ResSearch(results=[], message="OK")
    assert len(res.results) == 0
