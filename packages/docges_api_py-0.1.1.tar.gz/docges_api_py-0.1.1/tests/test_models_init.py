"""Tests for models/__init__.py — TDD RED phase."""


def test_models_init_imports():
    """Test that all models are exported from models/__init__.py."""
    from docges_api_py.models import (
        # Auth (existing)
        AuthRequest,
        DocGesAuthError,
        # Document (existing)
        ResFileDownload,
    )
    # If we get here, all imports succeed
    assert AuthRequest is not None
    assert DocGesAuthError is not None
    assert ResFileDownload is not None
