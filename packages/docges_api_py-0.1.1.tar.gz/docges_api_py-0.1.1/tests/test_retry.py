"""Tests for retry behavior in AsyncDocGes.do_request()."""

import httpx
import pytest
import respx

from docges_api_py import AsyncDocGes, RequestError

REAL_LOGIN_PAYLOAD = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg"},
}


@pytest.mark.asyncio
async def test_do_request_retries_on_server_error():
    """Test that do_request retries on 5xx errors and eventually succeeds."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        route = router.post(f"{base_url}/Content/Download").mock(
            side_effect=[
                httpx.Response(500, json={"error": "Internal Server Error"}),
                httpx.Response(500, json={"error": "Internal Server Error"}),
                httpx.Response(200, json={"result": {"name": "test.pdf", "id": "doc-123"}}),
            ]
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD  # inject session
        client.timeout = 0.1  # small timeout to reduce backoff sleep
        client.intents = 3

        result = await client.do_request("/Content/Download")

        assert route.called
        assert len(route.calls) == 3
        assert result == {"result": {"name": "test.pdf", "id": "doc-123"}}

        await client.close()


@pytest.mark.asyncio
async def test_do_request_fails_after_max_retries():
    """Test that do_request raises RequestError after all intents are exhausted."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        route = router.post(f"{base_url}/Content/Download").mock(
            return_value=httpx.Response(500, json={"error": "Internal Server Error"})
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD
        client.timeout = 0.1
        client.intents = 2  # only 2 attempts

        with pytest.raises(RequestError):
            await client.do_request("/Content/Download")

        assert len(route.calls) == 2

        await client.close()
