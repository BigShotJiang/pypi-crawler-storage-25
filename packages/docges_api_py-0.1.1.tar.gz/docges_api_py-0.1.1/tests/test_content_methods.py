"""Tests for get_cat_info() and download_content() — TDD GREEN/TRIANGULATE phases."""
import pytest
import respx

from docges_api_py import AsyncDocGes
from docges_api_py.models.responses import ResCat, ResFileDownload

REAL_LOGIN_PAYLOAD = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg"},
}


@pytest.mark.asyncio
async def test_get_cat_info_success():
    """Test get_cat_info returns ResCat on success."""
    with respx.mock:
        respx.post("http://test.com/Content/LoadChilds").respond(
            json={
                "result": {
                    "CategoriasHijas": [{"Nombre": "Child1", "SID": "ch1"}],
                    "Documentos": [{"Nombre": "Doc1", "SID": "d1"}]
                },
                "message": "OK"
            }
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            result = await client.get_cat_info("ch1")
            assert isinstance(result, ResCat)
            assert len(result.CategoriasHijas) == 1
            assert result.Documentos[0]["Nombre"] == "Doc1"


@pytest.mark.asyncio
async def test_get_cat_info_auto_auth():
    """Triangulation: Test get_cat_info triggers auth if no session."""
    with respx.mock:
        respx.post("http://test.com/Auth/Login").respond(json=REAL_LOGIN_PAYLOAD)
        respx.post("http://test.com/Content/LoadChilds").respond(
            json={
                "result": {"CategoriasHijas": [], "Documentos": []},
                "message": "OK"
            }
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            result = await client.get_cat_info("any-sid")
            assert isinstance(result, ResCat)
            assert len(result.CategoriasHijas) == 0


@pytest.mark.asyncio
async def test_download_content_success():
    """Test download_content returns ResFileDownload."""
    with respx.mock:
        respx.post("http://test.com/Content/Download").respond(
            json={
                "result": {
                    "data": "base64data123",
                    "name": "test.pdf",
                    "type": "application/pdf"
                },
                "message": "OK"
            }
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            result = await client.download_content("d1")
            assert isinstance(result, ResFileDownload)
            assert result.result.data == "base64data123"
            assert result.result.name == "test.pdf"


@pytest.mark.asyncio
async def test_download_content_error():
    """Triangulation: Test download_content handles missing document gracefully."""
    with respx.mock:
        respx.post("http://test.com/Content/Download").respond(
            json={"result": None, "message": "Document not found"}
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            result = await client.download_content("invalid-sid")
            assert result.message == "Document not found"
