"""Tests for AsyncDocGes auth with real login response format."""

from __future__ import annotations

import httpx
import pytest
import respx

from docges_api_py import AsyncDocGes, AuthenticationError, DocGesAuthError
from docges_api_py.models.auth import AuthResponse

# Real API response format (session-based, no JWT)
REAL_LOGIN_PAYLOAD = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg", "SIDraiz": "someroot"},
}


@pytest.mark.asyncio
async def test_auth_success_stores_login_response():
    """auth() must store the full loginResponse dict in _login_response."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        router.post(f"{base_url}/Auth/Login").mock(
            return_value=httpx.Response(200, json=REAL_LOGIN_PAYLOAD)
        )

        client = AsyncDocGes(base_url, "user", "pass", "app")
        auth_resp = await client.auth()

        assert isinstance(auth_resp, AuthResponse)
        assert auth_resp.user_info["Nombre"] == "Administrador"
        assert auth_resp.ware_house_info["Nombre"] == "devbg"
        # Critical: the raw dict must be stored for session injection
        assert client._login_response is not None
        assert client._login_response["userInfo"]["SID"] == "a6e65fd7-1234-5678-abcd-ef0123456789"

        await client.close()


@pytest.mark.asyncio
async def test_auth_failure_raises_authentication_error():
    """auth() must raise AuthenticationError on 401."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        router.post(f"{base_url}/Auth/Login").mock(
            return_value=httpx.Response(401, json={"error": "Unauthorized"})
        )

        client = AsyncDocGes(base_url, "bad", "bad", "bad", intents=1)

        with pytest.raises(AuthenticationError):
            await client.auth()

        await client.close()


@pytest.mark.asyncio
async def test_ensure_session_calls_auth_when_no_session():
    """_ensure_session() must call auth() when _login_response is None."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        auth_route = router.post(f"{base_url}/Auth/Login").mock(
            return_value=httpx.Response(200, json=REAL_LOGIN_PAYLOAD)
        )

        client = AsyncDocGes(base_url, "user", "pass", "app")
        assert client._login_response is None

        await client._ensure_session()

        assert auth_route.called
        assert client._login_response is not None

        await client.close()


@pytest.mark.asyncio
async def test_ensure_session_skips_auth_when_session_exists():
    """_ensure_session() must NOT call auth() when _login_response is set."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx", assert_all_called=False) as router:
        auth_route = router.post(f"{base_url}/Auth/Login").mock(
            return_value=httpx.Response(200, json=REAL_LOGIN_PAYLOAD)
        )

        client = AsyncDocGes(base_url, "user", "pass", "app")
        client._login_response = REAL_LOGIN_PAYLOAD  # already authenticated

        await client._ensure_session()

        assert not auth_route.called

        await client.close()


@pytest.mark.asyncio
async def test_do_request_injects_login_response_for_content_endpoints():
    """do_request() must inject loginResponse in requestModel for /Content/* endpoints."""
    base_url = "https://fake-docges.example.com"

    captured_body: dict = {}

    def capture_request(request: httpx.Request) -> httpx.Response:
        import json
        captured_body.update(json.loads(request.content))
        return httpx.Response(200, json={"result": {}, "message": "OK"})

    with respx.mock(using="httpx") as router:
        router.post(f"{base_url}/Content/LoadIniCats").mock(side_effect=capture_request)

        client = AsyncDocGes(base_url, "user", "pass", "app")
        client._login_response = REAL_LOGIN_PAYLOAD

        await client.do_request("/Content/LoadIniCats")

        # The requestModel must contain the real loginResponse
        assert "requestModel" in captured_body
        assert captured_body["requestModel"]["loginResponse"] == REAL_LOGIN_PAYLOAD

        await client.close()


@pytest.mark.asyncio
async def test_do_request_does_not_inject_login_response_for_auth_endpoint():
    """do_request() must NOT inject loginResponse for /Auth/* endpoints."""
    base_url = "https://fake-docges.example.com"

    captured_body: dict = {}

    def capture_request(request: httpx.Request) -> httpx.Response:
        import json
        captured_body.update(json.loads(request.content))
        return httpx.Response(200, json=REAL_LOGIN_PAYLOAD)

    with respx.mock(using="httpx") as router:
        router.post(f"{base_url}/Auth/Login").mock(side_effect=capture_request)

        client = AsyncDocGes(base_url, "user", "pass", "app")
        client._login_response = REAL_LOGIN_PAYLOAD

        from docges_api_py.models.auth import AuthRequest
        payload_model = AuthRequest(username="user", password="pass", appID="app")
        await client.do_request("/Auth/Login", payload_model)

        # Auth endpoint should NOT have loginResponse injected
        assert captured_body.get("requestModel", {}).get("loginResponse") is None

        await client.close()


@pytest.mark.asyncio
async def test_backward_compat_token_field_removed():
    """Spec REQ-AUTH-FIX-1: accessing .token must fail since AuthResponse no longer has it."""
    auth_resp = AuthResponse(
        user_info={"SID": "x", "Nombre": "Admin", "Id": 1},
        ware_house_info={"SID": "y", "Nombre": "WH", "SIDraiz": "z"},
    )

    # Accessing .token should raise AttributeError (backward compat break)
    with pytest.raises(AttributeError):
        _ = auth_resp.token


@pytest.mark.asyncio
async def test_ensure_session_network_failure_before_content_request():
    """Spec scenario: network/5xx error during _ensure_session() aborts content request."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx") as router:
        # Auth endpoint returns 500 on first call (simulate network/server error)
        router.post(f"{base_url}/Auth/Login").mock(
            return_value=httpx.Response(500, json={"error": "Internal Server Error"})
        )

        client = AsyncDocGes(base_url, "user", "pass", "app", intents=1)

        # Calling a content method should trigger _ensure_session() -> auth() -> fail
        with pytest.raises((DocGesAuthError, AuthenticationError)):
            await client.get_initial_cats()

        await client.close()
