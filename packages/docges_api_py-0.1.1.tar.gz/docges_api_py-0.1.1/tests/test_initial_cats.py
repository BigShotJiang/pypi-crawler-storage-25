"""Tests for get_initial_cats() — TDD GREEN phase."""
import httpx
import pytest
import respx

from docges_api_py import AsyncDocGes
from docges_api_py.models.responses import ResCat

REAL_LOGIN_PAYLOAD = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg"},
}


@pytest.mark.asyncio
async def test_get_initial_cats_success():
    """Test get_initial_cats returns ResCat on success."""
    with respx.mock:
        respx.post("http://test.com/Content/LoadIniCats").respond(
            json={
                "result": {
                    "CategoriasHijas": [{"Nombre": "Cat1", "SID": "c1"}],
                    "Documentos": []
                },
                "message": "OK"
            }
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            # Inject session to skip auth
            client._login_response = REAL_LOGIN_PAYLOAD

            result = await client.get_initial_cats()
            assert isinstance(result, ResCat)
            assert len(result.CategoriasHijas) == 1
            assert result.CategoriasHijas[0]["Nombre"] == "Cat1"


@pytest.mark.asyncio
async def test_get_initial_cats_auto_auth():
    """Triangulation: Test get_initial_cats triggers auth if no session."""
    with respx.mock:
        respx.post("http://test.com/Auth/Login").respond(json=REAL_LOGIN_PAYLOAD)
        respx.post("http://test.com/Content/LoadIniCats").respond(
            json={
                "result": {"CategoriasHijas": [], "Documentos": []},
                "message": "OK"
            }
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            # No session set - should auto-auth
            result = await client.get_initial_cats()
            assert isinstance(result, ResCat)
            assert len(result.CategoriasHijas) == 0


@pytest.mark.asyncio
async def test_get_initial_cats_injects_login_response():
    """get_initial_cats must send loginResponse in requestModel."""
    captured_body: dict = {}

    def capture(request: httpx.Request) -> httpx.Response:
        import json
        captured_body.update(json.loads(request.content))
        return httpx.Response(200, json={"result": {"CategoriasHijas": [], "Documentos": []}, "message": "OK"})

    with respx.mock:
        respx.post("http://test.com/Content/LoadIniCats").mock(side_effect=capture)

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD
            await client.get_initial_cats()

        assert captured_body["requestModel"]["loginResponse"] == REAL_LOGIN_PAYLOAD
