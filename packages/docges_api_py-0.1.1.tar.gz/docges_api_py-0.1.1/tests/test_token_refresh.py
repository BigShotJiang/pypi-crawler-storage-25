"""Tests for session auto-refresh in AsyncDocGes."""

import httpx
import pytest
import respx

from docges_api_py import AsyncDocGes

REAL_LOGIN_PAYLOAD = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg", "SIDraiz": "someroot"},
}


@pytest.mark.asyncio
async def test_session_auto_created_on_first_request():
    """_ensure_session() triggers auth when _login_response is None."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx", assert_all_called=False) as router:
        auth_route = router.post(f"{base_url}/Auth/Login").mock(
            return_value=httpx.Response(200, json=REAL_LOGIN_PAYLOAD)
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        assert client._login_response is None

        await client._ensure_session()

        assert auth_route.called
        assert client._login_response is not None
        assert client._login_response["userInfo"]["SID"] == "a6e65fd7-1234-5678-abcd-ef0123456789"

        await client.close()


@pytest.mark.asyncio
async def test_session_not_recreated_if_present():
    """_ensure_session() does NOT re-auth when _login_response is already set."""
    base_url = "https://fake-docges.example.com"

    with respx.mock(using="httpx", assert_all_called=False) as router:
        auth_route = router.post(f"{base_url}/Auth/Login").mock(
            return_value=httpx.Response(200, json=REAL_LOGIN_PAYLOAD)
        )

        client = AsyncDocGes(base_url, "user", "pass", "appid")
        client._login_response = REAL_LOGIN_PAYLOAD  # already authenticated

        await client._ensure_session()

        assert not auth_route.called

        await client.close()
