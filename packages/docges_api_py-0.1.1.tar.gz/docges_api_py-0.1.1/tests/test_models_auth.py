"""Tests for AuthResponse and DocGesAuthError models — TDD RED/GREEN/TRIANGULATE."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from docges_api_py.models.auth import AuthResponse

# ---------------------------------------------------------------------------
# Task 1.1 — AuthResponse with real API structure
# ---------------------------------------------------------------------------

REAL_LOGIN_RESPONSE = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg", "SIDraiz": "someroot"},
}


def test_auth_response_parses_real_api_structure():
    """AuthResponse must parse userInfo and wareHouseInfo from real login response."""
    resp = AuthResponse(**REAL_LOGIN_RESPONSE)

    assert resp.user_info["SID"] == "a6e65fd7-1234-5678-abcd-ef0123456789"
    assert resp.user_info["Nombre"] == "Administrador"
    assert resp.ware_house_info["Nombre"] == "devbg"


def test_auth_response_rejects_token_only_payload():
    """AuthResponse must raise ValidationError when given old token-based payload."""
    with pytest.raises(ValidationError):
        AuthResponse(token="fake-jwt-token-12345")  # type: ignore[call-arg]


def test_auth_response_rejects_missing_ware_house_info():
    """AuthResponse must raise ValidationError when wareHouseInfo is missing."""
    with pytest.raises(ValidationError):
        AuthResponse(userInfo={"SID": "x"})  # type: ignore[call-arg]


def test_auth_response_accepts_extra_ef_core_fields():
    """AuthResponse must accept EF Core objects with $id, ChangeTracker, etc."""
    payload = {
        "userInfo": {"$id": "1", "SID": "abc", "ChangeTracker": {"state": "Unchanged"}},
        "wareHouseInfo": {"$id": "2", "SID": "def", "Nombre": "Test"},
    }
    resp = AuthResponse(**payload)

    assert resp.user_info["SID"] == "abc"
    assert resp.ware_house_info["Nombre"] == "Test"
