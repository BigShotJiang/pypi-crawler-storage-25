"""Tests for models/requests.py — TDD RED phase."""
from docges_api_py.models.requests import (
    FileUpload,
    ReqAuthData,
    ReqData,
    ReqSearchContent,
    ReqUpload,
    SearchFilterValue,
)


def test_req_data_creation():
    """Test ReqData can be created with valid fields."""
    req = ReqData(
        contenidoModel={"SIDContenido": "test-sid"},
        requestModel={"loginDocGesData": {}, "loginResponse": {}}
    )
    assert req.contenidoModel["SIDContenido"] == "test-sid"
    assert req.requestModel["loginDocGesData"] == {}


def test_req_data_optional_fields():
    """Test ReqData works with minimal fields."""
    req = ReqData(contenidoModel={"SIDContenido": "test-sid"})
    assert req.requestModel is None


def test_req_auth_data_creation():
    """Test ReqAuthData can be created with optional fields (new dict-based loginResponse)."""
    from docges_api_py.models.auth import AuthRequest
    login_req = AuthRequest(username="user", password="pass", appID="app1")
    auth_data = ReqAuthData(
        login_docges_data=login_req,
        login_response={"userInfo": {"SID": "u1"}, "wareHouseInfo": {"SID": "w1"}},
    )
    assert auth_data.login_docges_data.username == "user"
    assert auth_data.login_response["userInfo"]["SID"] == "u1"


def test_req_auth_data_all_optional():
    """Test ReqAuthData can be created with no fields (all optional)."""
    auth_data = ReqAuthData()
    assert auth_data.login_docges_data is None
    assert auth_data.login_response is None


def test_req_upload_creation():
    """Test ReqUpload with FileUpload nested model."""
    file_upload = FileUpload(
        fileData="base64data",
        fileName="test.pdf",
        SIDCategory="cat-123"
    )
    req = ReqUpload(
        fileModel=file_upload,
        requestModel={"loginResponse": {}}
    )
    assert req.fileModel.fileName == "test.pdf"
    assert req.fileModel.erpRelation == ""  # default


def test_req_upload_with_erp_relation():
    """Test ReqUpload with erpRelation filled (triangulation)."""
    file_upload = FileUpload(
        fileData="base64data2",
        fileName="doc.docx",
        SIDCategory="cat-456",
        erpRelation="Baseges/123/PM-1"
    )
    req = ReqUpload(fileModel=file_upload, requestModel={})
    assert req.fileModel.erpRelation == "Baseges/123/PM-1"
    assert req.fileModel.erpProperty == ""


def test_req_search_content():
    """Test ReqSearchContent with field values."""
    filter_val = SearchFilterValue(field="name", mode="contains", text="invoice")
    req = ReqSearchContent(
        fieldValues=[filter_val.model_dump()],
        requestModel={"loginResponse": {}}
    )
    assert len(req.fieldValues) == 1
    assert req.fieldValues[0]["field"] == "name"


def test_req_search_content_no_fields():
    """Test ReqSearchContent with no fields (triangulation)."""
    req = ReqSearchContent()
    assert req.fieldValues is None
    assert req.dateValues is None
