"""Tests for remaining Phase 2 methods — TDD GREEN phase."""
import tempfile

import pytest
import respx

from docges_api_py import AsyncDocGes

REAL_LOGIN_PAYLOAD = {
    "userInfo": {"SID": "a6e65fd7-1234-5678-abcd-ef0123456789", "Nombre": "Administrador", "Id": 5},
    "wareHouseInfo": {"SID": "16cf3ed3-aaaa-bbbb-cccc-ddddeeee0001", "Nombre": "devbg"},
}


@pytest.mark.asyncio
async def test_upload_file_success(tmp_path):
    """Test upload_file returns SID on success."""
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
        f.write(b"test content")
        temp_path = f.name

    with respx.mock:
        respx.post("http://test.com/Content/UploadExtended").respond(
            json={"result": "new-sid-123", "message": "OK"}
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            sid = await client.upload_file("cat-1", temp_path)
            assert sid == "new-sid-123"


@pytest.mark.asyncio
async def test_search_content_success():
    """Test search_content returns ResSearch."""
    with respx.mock:
        respx.post("http://test.com/Content/SearchContent").respond(
            json={
                "result": {
                    "results": [{"_SID": "d1", "_Nombre": "Doc1"}],
                    "message": "OK"
                }
            }
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            result = await client.search_content(
                field_values=[{"field": "name", "mode": "contains", "text": "invoice"}]
            )
            assert result.results is not None
            assert len(result.results) == 1


@pytest.mark.asyncio
async def test_create_category_success():
    """Test create_category returns SID."""
    with respx.mock:
        respx.post("http://test.com/Content/CreateCategory").respond(
            json={"result": "new-cat-sid", "message": "OK"}
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            sid = await client.create_category("parent-1", "New Cat")
            assert sid == "new-cat-sid"


@pytest.mark.asyncio
async def test_rename_category_success():
    """Test rename_category returns True."""
    with respx.mock:
        respx.post("http://test.com/Content/RenameCategory").respond(
            json={"result": True, "message": "OK"}
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            result = await client.rename_category("cat-1", "New Name")
            assert result is True


@pytest.mark.asyncio
async def test_delete_category_success():
    """Test delete_category returns True."""
    with respx.mock:
        respx.post("http://test.com/Content/DeleteCategory").respond(
            json={"result": True, "message": "OK"}
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            result = await client.delete_category("cat-1")
            assert result is True


@pytest.mark.asyncio
async def test_remove_document_success():
    """Test remove_document returns True."""
    with respx.mock:
        respx.post("http://test.com/Content/RemoveDocument").respond(
            json={"result": True, "message": "OK"}
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            result = await client.remove_document("doc-1")
            assert result is True


@pytest.mark.asyncio
async def test_move_content_success():
    """Test move_content returns True."""
    with respx.mock:
        respx.post("http://test.com/Content/Move").respond(
            json={"result": True, "message": "OK"}
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            result = await client.move_content("doc-1", "cat-2")
            assert result is True


@pytest.mark.asyncio
async def test_update_content_success():
    """Test update_content returns SID."""
    with respx.mock:
        respx.post("http://test.com/Content/Update").respond(
            json={"result": "doc-1", "message": "OK"}
        )

        async with AsyncDocGes("http://test.com", "user", "pass", "app") as client:
            client._login_response = REAL_LOGIN_PAYLOAD

            sid = await client.update_content("doc-1", erp_relation="Baseges/123")
            assert sid == "doc-1"
