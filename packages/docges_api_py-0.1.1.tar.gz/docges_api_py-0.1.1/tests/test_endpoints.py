"""Tests for Endpoints class in client.py — TDD RED phase."""
from docges_api_py.client import Endpoints


def test_endpoints_class_has_all_routes():
    """Test Endpoints class has all required API routes."""
    # New routes that should exist
    assert hasattr(Endpoints, 'content_load_ini_cats')
    assert hasattr(Endpoints, 'content_load_childs')
    assert hasattr(Endpoints, 'content_download')
    assert hasattr(Endpoints, 'content_upload')
    assert hasattr(Endpoints, 'content_upload_extended')
    assert hasattr(Endpoints, 'content_search')
    assert hasattr(Endpoints, 'content_create_category')
    assert hasattr(Endpoints, 'content_rename_category')
    assert hasattr(Endpoints, 'content_delete_category')
    assert hasattr(Endpoints, 'content_remove_document')
    assert hasattr(Endpoints, 'content_move')
    assert hasattr(Endpoints, 'content_update')


def test_endpoints_values_are_correct():
    """Test route values match docges-ctg-api spec."""
    assert Endpoints.content_load_ini_cats == "/Content/LoadIniCats"
    assert Endpoints.content_download == "/Content/Download"
    assert Endpoints.content_upload_extended == "/Content/UploadExtended"
    assert Endpoints.content_search == "/Content/SearchContent"
    assert Endpoints.content_create_category == "/Content/CreateCategory"
    assert Endpoints.content_move == "/Content/Move"
    assert Endpoints.content_update == "/Content/Update"


def test_existing_endpoints_still_present():
    """Triangulation: Ensure existing routes were not removed."""
    assert Endpoints.auth_login == "/Auth/Login"
    assert Endpoints.content_download == "/Content/Download"  # Should now exist
