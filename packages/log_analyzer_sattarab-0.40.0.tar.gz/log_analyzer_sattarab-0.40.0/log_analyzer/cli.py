\
from . import __version__
import os
import sys
import json

from log_analyzer.parser import parse_cli_date, parse_line
from .analyzer import analyze_logs
from .io_utils import read_file, parse_date, is_within_range
from .output import iter_rows, print_csv, print_json, print_table
from .parser_args import build_parser
from datetime import datetime, timedelta
from collections import OrderedDict

def build_date_summary(lines, levels=None):
    summary = OrderedDict()

    for line in lines:
        line = line.strip()
        if not line:
            continue

        parts = line.split(maxsplit=1)
        if len(parts) < 2:
            continue

        try:
            line_date = parse_cli_date(parts[0])
        except ValueError:
            continue

        rest = parts[1]
        level = parse_line(rest)
                
        if level is None:
            continue

        if levels and level not in levels:
            continue

        date_key = line_date.isoformat()        
        if date_key not in summary:
            summary[date_key] = {
                "ERROR": 0,
                "WARNING": 0,
                "INFO": 0,
                "DEBUG": 0,
            }

        summary[date_key][level] += 1

    return summary

def parse_cli_date(value):
    for fmt in ("%Y-%m-%d", "%Y/%m/%d"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    raise ValueError

def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.summary:
        args.date_summary = True
        args.sort = "total"

    if args.summary and args.format is None:
        args.format = "table"

    
    if args.version:
        print(__version__)
        return 0

    if args.percent_decimals < 0:
            print("Error: --percent_decimals must be >= 0", file=sys.stderr)
            return 2

    if not args.version and not args.file:
        print("Error: -f/--file is required", file=sys.stderr)
        return 2
        
    # --- Read input ---
    try:
        if args.file == "-":
            lines = sys.stdin.read().splitlines(True)
        else:
            lines = read_file(args.file)
    except (FileNotFoundError, PermissionError, OSError):
        print(f"Error: file '{args.file}' not found", file=sys.stderr)
        return 2

    # --- Date filter ---
    date_filter_active = any([
        args.since, args.until, args.today, args.last_days is not None
    ])

    if (args.today or args.last_days is not None) and (args.since or args.until):
        print("Error: cannot combine --today/--last-days with --since/--until", file=sys.stderr)
        return 2

    has_any_date = False

    if date_filter_active or args.date_summary:
        for line in lines:
            parts = line.strip().split(maxsplit=1)
            if not parts:
                continue
            try:
                _ = parse_cli_date(parts[0])
                has_any_date = True
                break
            except ValueError:
                continue

    if date_filter_active or args.date_summary:
        if not has_any_date:
            print(
                "Error: date filtering requires log lines to start with YYYY-MM-DD or YYYY/MM/DD",
                file=sys.stderr,
            )
            return 2
        
    since_date = None
    until_date = None
    today = datetime.now().date()
    if args.today:
        since_date = today
        until_date = today

    elif args.last_days is not None:
        if args.last_days <= 0:
            print("Error: --last-days must be > 0", file=sys.stderr)
            return 2
        since_date = today - timedelta(days=args.last_days - 1)
        until_date = today

    try:        
                        
        if args.since:
            since_date = parse_cli_date(args.since)
        if args.until:
            until_date = parse_cli_date(args.until)
    except ValueError:
        print("Error: invalid date. use YYYY-MM-DD or YYYY/MM/DD", file=sys.stderr)
        return 2

    if since_date and until_date and since_date > until_date:
        print("Error: --since cannot be later than --until", file=sys.stderr)
        return 2
    
    if since_date or until_date:
        filtered_lines = []
        for line in lines:
            line = line.strip()
            if not line:
                continue

            parts = line.split(maxsplit=1)

            try:
                line_date = parse_date(parts[0])
            except (ValueError, IndexError):
                continue

            if since_date and line_date < since_date:
                continue

            if until_date and line_date > until_date:
                continue

            if args.date_summary:
                filtered_lines.append(line)
            else:
                if len(parts) > 1:
                    filtered_lines.append(parts[1])
                else:
                    filtered_lines.append("")                                                                            
        lines = filtered_lines
                        
    counts = analyze_logs(lines)   
    full_total = sum(counts.values())
    show_header = not args.no_header
    decimals = args.percent_decimals
    show_percent = not args.no_percent
    output_path = args.output or args.output_json_file

    if args.output_json_file:
        print(
            "Warning: --output-json-file is deprecated. Use --output instead.",
            file=sys.stderr,
        )

    inferred_format = None

    if output_path:        
        _, ext = os.path.splitext(output_path.lower())

        if ext == ".json":
            inferred_format = "json"
        elif ext == ".csv":
            inferred_format = "csv"
        elif ext == ".txt":
            inferred_format = "table"
        elif ext:
            print(f"Error: cannot infer output format from '{ext}'", file=sys.stderr)
            return 2
    
    final_format = args.format

    # Priority 1: explicit override
    if args.output_format != "auto":
        final_format = args.output_format

    # Priority 2: inferred from extension
    elif inferred_format:
        final_format = inferred_format
    
    if output_path and inferred_format == "json" and not args.date_summary and not(args.summary_json or args.full_json):
        args.full_json = True
           
    if args.indent is not None and not (
        args.summary_json or args.full_json or final_format == "json"
    ):
        print(
            "Error: --indent requires --summary-json or --full-json",
            file=sys.stderr
        )
        return 2

    if args.indent is not None and args.indent < 0:
        print("Error: --indent must be >= 0", file=sys.stderr)
        return 2

    if args.full_json and args.summary_json:
        print(
            "Error: cannot use --full-json with --summary-json",
            file=sys.stderr,
        )
        return 2
                           
    if (args.summary_json or args.full_json) and not args.date_summary:
        payload = {
            "total": full_total,
            "levels": {}
        }

        for level in ["ERROR", "WARNING", "INFO", "DEBUG"]:
            count = counts.get(level, 0)
            percent = (count / full_total * 100) if full_total else 0
            payload["levels"][level] = {
                "count": count,
                "percent": round(percent, args.percent_decimals)
            }
        
        if args.indent is not None:
            json_output = json.dumps(payload, indent=args.indent)
        else:
            json_output = json.dumps(payload)

        try:
            if output_path:
                if os.path.exists(output_path) and not (args.force or args.append):
                    print(f"Error: output file already exists: {output_path}", file=sys.stderr)
                    return 2

                dir_path = os.path.dirname(output_path)
                if dir_path:
                    os.makedirs(dir_path, exist_ok=True)

                with open(output_path, "w", encoding="utf-8") as f:
                    f.write(json_output)

            elif args.output_json_file:
                dir_path = os.path.dirname(args.output_json_file)
                if dir_path:
                    os.makedirs(dir_path, exist_ok=True)

                with open(args.output_json_file, "w", encoding="utf-8") as f:
                    f.write(json_output)

            else:
                print(json_output)

        except (PermissionError, OSError):
            target_path = output_path if output_path else args.output_json_file
            print(
                f"Error: cannot write to '{target_path}'",
                file=sys.stderr,
            )
            return 2

        return 0
                       
    # Optional level filter

    levels = []

    if args.level:
        levels.extend([level.upper() for level in args.level])

    if args.levels:
        extra_levels = [item.strip().upper() for item in args.levels.split(",") if item.strip()]
        valid_levels = {"ERROR", "WARNING", "INFO", "DEBUG"}

        for level in extra_levels:
            if level not in valid_levels:
                print(f"Error: invalid level '{level}'. Valid values: ERROR, WARNING, INFO, DEBUG", file=sys.stderr)                
                return 2

        levels.extend(extra_levels)

    seen = set()
    clean_levels = []

    for level in levels:
        if level not in seen:
            seen.add(level)
            clean_levels.append(level)

    levels = clean_levels if clean_levels else None
        
    # Build rows
    rows = iter_rows(counts, args.sort, args.reverse, levels=levels)
    if args.min_count is not None:
        if args.min_count < 0:
            print("Error: --mini-count must be >= 0", file=sys.stderr)
            return 2
        rows = [(lvl, cnt) for lvl, cnt in rows if cnt >= args.min_count]
    
    if args.top is not None:
        if args.top <= 0:
            print("Error: --top must be greater than 0", file=sys.stderr)
            return 2
        rows = rows[:args.top]

    full_total = sum(cnt for _, cnt in rows)
    show_total = not args.no_total

    out_fh = None
    try:
        
        # --- Output destination ---
        if args.output is not None:
            if args.append and args.force:
                print("Error: cannot use --append with --force", file=sys.stderr)
                return 2
             
            if (not args.force and not args.append) and os.path.exists(args.output):
                print(f"Error: output file already exists: {args.output}", file=sys.stderr)
                return 2

            try:
                mode = "a" if args.append else "w"
                out_fh = open(output_path, mode, encoding="utf-8", newline="")
                
            except PermissionError:
                print(
                    f"Error: cannot write to '{args.output}' (file may be open in Excel). Close it and try again.",
                    file=sys.stderr,
                )
                return 2

            target = out_fh
        else:
            target = sys.stdout
                                        
        if args.date_summary:
            summary = build_date_summary(lines, levels=levels)
            summary_items = list(summary.items())
                                                                                        
            if args.min_total is not None and args.min_total < 0:
                print("Error: --min-total must be >= 0", file=sys.stderr)
                return 2
             
            if args.min_total is not None:
                summary_items = [
                    (date_key, counts)
                    for date_key, counts in summary_items
                    if sum(counts.values()) >= args.min_total
                ]
                                       
            if args.sort == "date":
                summary_items.sort(
                    key=lambda item: item[0],
                    
                )

            elif args.sort == "total":
                summary_items.sort(
                    key=lambda item: (-sum(item[1].values()), item[0])                    
                )

            if args.reverse:
                summary_items.reverse()
            
            if args.limit is not None and args.limit <= 0:
                print("Error: --limit must be > 0", file=sys.stderr)
                return 2

            if args.limit is not None:
                summary_items = summary_items[:args.limit]
                decimals = args.percent_decimals

            # After summary_items is ready

            if args.output and args.output_dir:
                print("Error: cannot use --output with --output-dir", file=sys.stderr)
                return 2
        
            if args.output_dir:            
                os.makedirs(args.output_dir, exist_ok=True)

                for date_key, counts_by_level in summary_items:
                    file_path = os.path.join(args.output_dir, f"{date_key}.txt")

                    if os.path.exists(file_path) and not (args.force or args.append):
                        print(f"Error: file exists: {file_path}", file=sys.stderr)
                        return 2

                    mode = "a" if args.append else "w"

                    with open(file_path, mode, encoding="utf-8") as fh:                
                        total = sum(counts_by_level.values())
                    if args.append:
                        fh.write("\n")
                        print(
                            f"{date_key} "
                            f"ERROR: {counts_by_level['ERROR']} "
                            f"WARNING: {counts_by_level['WARNING']} "
                            f"INFO: {counts_by_level['INFO']} "
                            f"DEBUG: {counts_by_level['DEBUG']} "
                            f"TOTAL: {total}",
                            file=fh,
                        )

                return 0            
            
            if final_format == "json":
                result = {}
                for date_key, counts_by_level in summary_items:
                    total = sum(counts_by_level.values())
                    result[date_key] = {
                        **counts_by_level,
                        "TOTAL": total,
                    }
                
                json.dump(result, target, indent=args.indent)                
                print(file=target)
                return 0

            if final_format == "csv":                
                print("date,ERROR,WARNING,INFO,DEBUG,TOTAL", file=target)
                for date_key, counts_by_level in summary_items:
                    total = sum(counts_by_level.values())
                    print(
                        f"{date_key},"
                        f"{counts_by_level['ERROR']},"
                        f"{counts_by_level['WARNING']},"
                        f"{counts_by_level['INFO']},"
                        f"{counts_by_level['DEBUG']},"
                        f"{total}",
                        file=target,
                    )
                return 0
                                            
            #  text output

            LEVELS = ["ERROR", "WARNING", "INFO", "DEBUG"]

            for date_key, counts_by_level in summary_items:
                total = sum(counts_by_level.values())

                if total > 0:
                    pct = {
                        level: (counts_by_level[level] / total) * 100
                        for level in LEVELS
                    }
                else:
                    pct = {level: 0.0 for level in LEVELS}

                if show_percent:
                    print(
                        f"{date_key} "
                        f"ERROR: {counts_by_level['ERROR']} ({pct['ERROR']:.{decimals}f}%) "
                        f"WARNING: {counts_by_level['WARNING']} ({pct['WARNING']:.{decimals}f}%) "
                        f"INFO: {counts_by_level['INFO']} ({pct['INFO']:.{decimals}f}%) "
                        f"DEBUG: {counts_by_level['DEBUG']} ({pct['DEBUG']:.{decimals}f}%) "
                        f"TOTAL: {total}",
                        file=target,
                    )
                else:
                    print(
                        f"{date_key} "
                        f"ERROR: {counts_by_level['ERROR']} "
                        f"WARNING: {counts_by_level['WARNING']} "
                        f"INFO: {counts_by_level['INFO']} "
                        f"DEBUG: {counts_by_level['DEBUG']} "
                        f"TOTAL: {total}",
                        file=target,
                    )
            return 0
                                                                                      
        # --- Output format ---        
        
        if args.summary_only:
            print(f"TOTAL: {full_total}", file=target)
            return 0
                    
        if final_format == "csv":            
            print_csv(
                rows,
                file=target,
                total=full_total,
                show_total=show_total,
                show_header=show_header,
                show_percent=show_percent,
                percent_decimals=decimals,                
            )
        elif final_format == "json":            
            print_json(
                rows,
                file=target,
                total=full_total,                
                percent_decimals=decimals,
                show_percent=show_percent,                
            )
        else:            
            print_table(
                rows,
                file=target,
                total=full_total,
                show_total=show_total,
                show_header=show_header,
                show_percent=show_percent,
                percent_decimals=decimals,                
            )
            
        return 0

    finally:
        if out_fh is not None:
            out_fh.close()


def cli_main() -> None:
    raise SystemExit(main())


if __name__ == "__main__":
    cli_main()





    
































              
        
