from dataclasses import dataclass, field
from typing import ClassVar
from ..BaseModel.eModelBase import eOptimizerType
from ..BaseModel.eSegmentationModel import eDinoUperNetModel

_DINO_IMAGE_SIZE: dict = {
    eDinoUperNetModel.DINO_S: 336,
    eDinoUperNetModel.DINO_B: 518,
    eDinoUperNetModel.DINO_L: 518,
}

_DINO_BACKBONE_MAP: dict = {
    eDinoUperNetModel.DINO_S: "dinov2_vits14",
    eDinoUperNetModel.DINO_B: "dinov2_vitb14",
    eDinoUperNetModel.DINO_L: "dinov2_vitl14",
}

_DINO_FEATURE_DIM: dict = {
    eDinoUperNetModel.DINO_S: 384,
    eDinoUperNetModel.DINO_B: 768,
    eDinoUperNetModel.DINO_L: 1024,
}

@dataclass
class TrainingConfig:
    # ── ModelParams ──────────────────────────────
    ProcessName:        str       = ""
    ImageSize:          int       = None
    Architecture:       object    = eDinoUperNetModel.DINO_S
    NumClasses:         int       = 2
    DecoderChannels:    int       = 512
    Dropout:            float     = 0.1
    PoolScales:         tuple     = field(default=(1, 2, 3, 6))
    Project:            str       = "TrainResult"

    # ── Training ─────────────────────────────────
    Epochs:             int       = 100
    BatchSize:          int       = 64
    LearningRate:       float     = 1e-3
    WeightDecay:        float     = 1e-4
    OptimizerType:      object    = eOptimizerType.AdamW
    Patience:           int       = 5

    # ── Warmup ───────────────────────────────────
    WarmupEpochs:       int       = 10
    WarmupStartFactor:  float     = 0.01

    # ── Backbone ─────────────────────────────────
    FreezeBackbone:     bool      = True
    BackboneLR:         float     = 1e-5
    HeadLR:             float     = 1e-4
    UnfreezeAt:         int       = 0   # 0 = disabled (always freeze)
    Stage2WarmupEpochs: int       = 3

    # ── Scheduler ────────────────────────────────
    Scheduler:          str       = "cosine"
    LRMin:              float     = 1e-6
    LRMilestones:       list      = field(default_factory=lambda: [50])
    LRGamma:            float     = 0.1

    # ── DataPaths ────────────────────────────────
    DatasetPath:        str       = ""
    PretrainedPath:     str       = ""

    # ── Augmentation ──
    HFlipP:         float     = 0.5
    GaussianBlurP:  float     = 0.1
    GaussianBlurLimit: int    = 3
    ColorJitterP:   float     = 0.5
    BrightnessFactor: tuple   = field(default_factory=lambda: (0.8, 1.2))
    ContrastFactor:  tuple    = field(default_factory=lambda: (0.8, 1.2))
    SaturationFactor: tuple   = field(default_factory=lambda: (0.8, 1.2))
    HueFactor:      tuple     = field(default_factory=lambda: (-0.1, 0.1))
    LongSideScaleMin: float    = 0.5

    # ── Class variable (không vào __init__) ──────
    _category_map: ClassVar[dict] = {
        "ModelParams":  ["ProcessName", "ImageSize", "Architecture", "NumClasses",
                         "DecoderChannels", "Dropout", "PoolScales", "Project"],
        "Training":     ["Epochs", "BatchSize", "LearningRate", "WeightDecay",
                         "OptimizerType", "Patience"],
        "Warmup":       ["WarmupEpochs", "WarmupStartFactor"],
        "Backbone":     ["FreezeBackbone", "BackboneLR", "HeadLR",
                         "UnfreezeAt", "Stage2WarmupEpochs"],
        "Scheduler":    ["Scheduler", "LRMin", "LRMilestones", "LRGamma"],
        "DataPaths":    ["DatasetPath", "PretrainedPath"],
        "Augmentation": ["HFlipP", "GaussianBlurP", "GaussianBlurLimit",
                         "ColorJitterP", "BrightnessFactor", "ContrastFactor",
                         "SaturationFactor", "HueFactor", "LongSideScaleMin"],
    }

    # ─────────────────────────────────────────────
    def __post_init__(self):
        object.__setattr__(self, "_image_size_overridden", self.ImageSize is not None)

        if self.ImageSize is None:
            object.__setattr__(self, "ImageSize",
                               _DINO_IMAGE_SIZE.get(self.Architecture, 336))

        if getattr(self, "WarmupStartFactor", None) is None:
            object.__setattr__(self, "WarmupStartFactor", 0.01)

    def __setattr__(self, name: str, value):
        super().__setattr__(name, value)

        if name == "ImageSize":
            object.__setattr__(self, "_image_size_overridden", True)

        elif name == "Architecture":
            if not getattr(self, "_image_size_overridden", False):
                super().__setattr__("ImageSize",
                                    _DINO_IMAGE_SIZE.get(value, 336))

    # ── Category helpers ──────────────────────────
    def get_category(self, prop_name: str) -> str:
        for cat, props in self._category_map.items():
            if prop_name in props:
                return cat
        return "Uncategorized"

    def get_by_category(self, cat: str) -> dict:
        return {k: getattr(self, k) for k in self._category_map.get(cat, [])}

    def set_by_category(self, cat: str, **kwargs):
        allowed = self._category_map.get(cat, [])
        for k, v in kwargs.items():
            if k in allowed:
                setattr(self, k, v)
            else:
                raise KeyError(f"'{k}' không thuộc category '{cat}'")

    def reset_image_size(self):
        """ Reset ImageSize về auto theo Architecture """
        object.__setattr__(self, "_image_size_overridden", False)
        object.__setattr__(self, "ImageSize",
                           _DINO_IMAGE_SIZE.get(self.Architecture, 336))

    def get_backbone_name(self):
        return _DINO_BACKBONE_MAP.get(self.Architecture, "dinov2_vits14")

    def get_feature_dim(self):
        return _DINO_FEATURE_DIM.get(self.Architecture, 384)
