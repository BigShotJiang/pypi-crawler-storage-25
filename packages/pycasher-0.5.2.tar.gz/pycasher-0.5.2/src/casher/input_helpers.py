from pathlib import Path


def expand_input_dir(root: str | Path, pattern: str = "*") -> list[Path]:
    """Return a sorted recursive file list for explicit input_files usage."""
    root_path = Path(root)
    return sorted(
        (path for path in root_path.rglob(pattern) if path.is_file()),
        key=str,
    )