from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
from click.testing import CliRunner

from pyXenium.__main__ import app


def _write_adapter_dry_run_fixture(tmp_path: Path) -> Path:
    benchmark = tmp_path / "benchmark"
    (benchmark / "configs").mkdir(parents=True)
    (benchmark / "data").mkdir(parents=True)
    methods_yaml = """methods:
  - slug: squidpy
    display_name: Squidpy ligrec
    language: python
    env_name: pyx-cci-squidpy
    runner: runners/python/run_squidpy.py
  - slug: liana
    display_name: LIANA+ bivariate
    language: python
    env_name: pyx-cci-liana
    runner: runners/python/run_liana.py
  - slug: commot
    display_name: COMMOT
    language: python
    env_name: pyx-cci-commot
    runner: runners/python/run_commot.py
  - slug: cellchat
    display_name: CellChat v3 / Spatial CellChat
    language: r
    env_name: r-cci-cellchat
    runner: runners/r/run_cellchat.R
"""
    (benchmark / "configs" / "methods.yaml").write_text(methods_yaml, encoding="utf-8")
    (benchmark / "envs").mkdir()
    (benchmark / "scripts").mkdir()
    (benchmark / "runners").mkdir()
    (benchmark / "logs").mkdir()
    (benchmark / "runs").mkdir()
    (benchmark / "results").mkdir()
    (tmp_path / "pyproject.toml").write_text("[project]\nname='toy'\n", encoding="utf-8")
    (tmp_path / "README.md").write_text("toy\n", encoding="utf-8")
    (tmp_path / "LICENSE").write_text("toy\n", encoding="utf-8")
    (tmp_path / "src").mkdir(exist_ok=True)
    cci_resource = benchmark / "data" / "cci_resource_common.tsv"
    smoke_panel = benchmark / "data" / "atera_smoke_panel.tsv"
    (benchmark / "data" / "smoke").mkdir()
    (benchmark / "data" / "smoke" / "adata_smoke.h5ad").touch()
    cci_resource.write_text("ligand\treceptor\nCXCL12\tCXCR4\n", encoding="utf-8")
    smoke_panel.write_text("ligand\treceptor\nCXCL12\tCXCR4\n", encoding="utf-8")
    manifest = {
        "smoke_h5ad": str(benchmark / "data" / "smoke" / "adata_smoke.h5ad"),
        "full_h5ad": None,
        "cci_resource_common_tsv": str(cci_resource),
        "atera_smoke_panel_tsv": str(smoke_panel),
        "smoke_bundle": {},
        "full_bundle": {"counts_symbol_mtx": str(benchmark / "data" / "full" / "counts_symbol.mtx")},
    }
    (benchmark / "data" / "input_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return benchmark


def test_benchmark_prepare_command(monkeypatch, tmp_path):
    captured = {}

    def fake_prepare_atera_cci_benchmark(**kwargs):
        captured.update(kwargs)
        return {
            "dataset_root": kwargs["dataset_root"],
            "benchmark_root": str(tmp_path / "benchmark"),
            "smoke_n_cells": kwargs["smoke_n_cells"],
        }

    monkeypatch.setattr("pyXenium.__main__.prepare_atera_cci_benchmark", fake_prepare_atera_cci_benchmark)

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "prepare",
            "--dataset-root",
            str(tmp_path / "dataset"),
            "--benchmark-root",
            str(tmp_path / "benchmark"),
            "--smoke-n-cells",
            "123",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["smoke_n_cells"] == 123
    assert captured["dataset_root"] == str(tmp_path / "dataset")
    assert captured["write_full_h5ad"] is True


def test_benchmark_prepare_command_accepts_xenium_root_alias(monkeypatch, tmp_path):
    captured = {}

    def fake_prepare_atera_cci_benchmark(**kwargs):
        captured.update(kwargs)
        return {
            "dataset_root": kwargs["dataset_root"],
            "benchmark_root": str(tmp_path / "benchmark"),
            "smoke_n_cells": kwargs["smoke_n_cells"],
        }

    monkeypatch.setattr("pyXenium.__main__.prepare_atera_cci_benchmark", fake_prepare_atera_cci_benchmark)

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "prepare",
            "--xenium-root",
            str(tmp_path / "dataset"),
            "--benchmark-root",
            str(tmp_path / "benchmark"),
            "--smoke-n-cells",
            "123",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["smoke_n_cells"] == 123
    assert captured["dataset_root"] == str(tmp_path / "dataset")
    assert captured["write_full_h5ad"] is True


def test_benchmark_prepare_dataset_dry_run(monkeypatch, tmp_path):
    dataset = {
        "id": "atera_cervical_wta",
        "local_xenium_root": str(tmp_path / "cervical"),
        "local_tbc_results": str(tmp_path / "cervical" / "sfplot_tbc_formal_wta" / "results"),
        "cell_groups_relpath": "WTA_Preview_FFPE_Cervical_Cancer_cell_groups.csv",
        "benchmark_subdir": "datasets/atera_cervical_wta",
        "role": "cross_tissue_xenium_generalization",
        "platform": "Xenium WTA",
        "tissue": "cervical cancer",
    }

    monkeypatch.setattr("pyXenium.__main__.resolve_dataset_entry", lambda dataset_id, datasets_config=None: dataset)
    monkeypatch.setattr(
        "pyXenium.__main__.resolve_layout",
        lambda: type("Layout", (), {"root": tmp_path / "benchmark"})(),
    )

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "prepare-dataset",
            "--dataset-id",
            "atera_cervical_wta",
            "--dry-run",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["status"] == "planned"
    assert payload["dataset_id"] == "atera_cervical_wta"
    assert payload["tissue"] == "cervical cancer"
    assert payload["cell_groups_relpath"] == "WTA_Preview_FFPE_Cervical_Cancer_cell_groups.csv"
    assert payload["benchmark_root"].endswith("datasets\\atera_cervical_wta") or payload["benchmark_root"].endswith("datasets/atera_cervical_wta")


def test_benchmark_smoke_pyxenium_command(monkeypatch, tmp_path):
    captured = {}

    def fake_resolve_layout(*, relative_root):
        root = Path(relative_root)
        return type(
            "Layout",
            (),
            {
                "root": root,
                "data_dir": root / "data",
                "runs_dir": root / "runs",
                "results_dir": root / "results",
                "reports_dir": root / "reports",
                "config_dir": root / "configs",
            },
        )()

    def fake_run_pyxenium_smoke(**kwargs):
        captured.update(kwargs)
        return {"method": "pyxenium", "output_dir": str(kwargs["output_dir"])}

    monkeypatch.setattr("pyXenium.__main__.resolve_layout", fake_resolve_layout)
    monkeypatch.setattr("pyXenium.__main__.run_pyxenium_smoke", fake_run_pyxenium_smoke)

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "smoke-pyxenium",
            "--benchmark-root",
            str(tmp_path / "benchmark"),
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["method"] == "pyxenium"
    assert captured["input_h5ad"] == tmp_path / "benchmark" / "data" / "smoke" / "adata_smoke.h5ad"


def test_benchmark_report_command(monkeypatch, tmp_path):
    combined = tmp_path / "combined.tsv"
    combined.write_text(
        "method\tdatabase_mode\tligand\treceptor\tsender\treceiver\tscore_raw\tscore_std\trank_within_method\trank_fraction\tfdr_or_pvalue\tresolution\tspatial_support_type\tartifact_path\n"
        "pyxenium\tcommon-db\tCXCL12\tCXCR4\tCAFs, DCIS Associated\tT Lymphocytes\t1.0\t0.0\t1\t1.0\t\tcelltype_pair\ttopology\tartifacts\n",
        encoding="utf-8",
    )

    def fake_resolve_layout(*, relative_root):
        root = Path(relative_root)
        (root / "configs").mkdir(parents=True, exist_ok=True)
        (root / "reports").mkdir(parents=True, exist_ok=True)
        (root / "results").mkdir(parents=True, exist_ok=True)
        return type(
            "Layout",
            (),
            {
                "root": root,
                "data_dir": root / "data",
                "runs_dir": root / "runs",
                "results_dir": root / "results",
                "reports_dir": root / "reports",
                "config_dir": root / "configs",
            },
        )()

    monkeypatch.setattr("pyXenium.__main__.resolve_layout", fake_resolve_layout)
    monkeypatch.setattr("pyXenium.__main__.compute_canonical_recovery", lambda combined, canonical_axes: (None, pd.DataFrame([{"method": "pyxenium", "database_mode": "common-db", "canonical_recovery_score": 1.0}])))
    monkeypatch.setattr("pyXenium.__main__.compute_pathway_relevance", lambda combined, pathway_config: (None, pd.DataFrame([{"method": "pyxenium", "database_mode": "common-db", "pathway_relevance_score": 1.0}])))
    monkeypatch.setattr("pyXenium.__main__.compute_spatial_coherence", lambda combined: pd.DataFrame([{"method": "pyxenium", "database_mode": "common-db", "spatial_coherence_score": 1.0}]))
    monkeypatch.setattr("pyXenium.__main__.compute_novelty_support", lambda combined: (None, pd.DataFrame([{"method": "pyxenium", "database_mode": "common-db", "novelty_support_score": 0.0}])))
    monkeypatch.setattr("pyXenium.__main__.compute_robustness", lambda combined: pd.DataFrame([{"method": "pyxenium", "database_mode": "common-db", "robustness_score": 0.0}]))
    monkeypatch.setattr("pyXenium.__main__.score_biological_performance", lambda **kwargs: pd.DataFrame([{"method": "pyxenium", "database_mode": "common-db", "biology_score": 0.75, "spatial_coherence_score": 1.0}]))
    monkeypatch.setattr("pyXenium.__main__.render_atera_cci_benchmark_report", lambda **kwargs: "# report\n")

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "report",
            "--benchmark-root",
            str(tmp_path / "benchmark"),
            "--combined-results",
            str(combined),
            "--output-path",
            str(tmp_path / "benchmark" / "reports" / "benchmark_report.md"),
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert Path(payload["report_md"]).exists()


def test_benchmark_run_method_dry_run_command(tmp_path):
    benchmark = _write_adapter_dry_run_fixture(tmp_path)

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "run-method",
            "--method",
            "squidpy",
            "--benchmark-root",
            str(benchmark),
            "--dry-run",
            "--max-cci-pairs",
            "1",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["method"] == "squidpy"
    assert payload["will_execute"] is True
    assert payload["interaction_pairs"] == 1
    assert payload["output_dir"].endswith("squidpy_smoke_common_db")


def test_benchmark_run_method_dry_run_accepts_chunk_and_gzip_options(tmp_path):
    benchmark = _write_adapter_dry_run_fixture(tmp_path)

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "run-method",
            "--method",
            "commot",
            "--benchmark-root",
            str(benchmark),
            "--phase",
            "full",
            "--chunk-id",
            "2",
            "--num-chunks",
            "8",
            "--bounded-mode",
            "commot_chunked_full",
            "--gzip-standardized",
            "--dry-run",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["method"] == "commot"
    assert payload["chunk_id"] == 2
    assert payload["num_chunks"] == 8
    assert payload["bounded_mode"] == "commot_chunked_full"
    assert payload["gzip_standardized"] is True


def test_benchmark_smoke_core_dry_run_command(tmp_path):
    benchmark = _write_adapter_dry_run_fixture(tmp_path)

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "smoke-core",
            "--benchmark-root",
            str(benchmark),
            "--methods",
            "squidpy,liana,commot,cellchat",
            "--dry-run",
            "--max-cci-pairs",
            "1",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["status"] == "completed"
    assert [item["method"] for item in payload["methods"]] == ["squidpy", "liana", "commot", "cellchat"]
    assert all(item["status"] == "dry-run" for item in payload["methods"])


def test_benchmark_stage_a100_plan_only_command(tmp_path, monkeypatch):
    benchmark = _write_adapter_dry_run_fixture(tmp_path)
    monkeypatch.chdir(tmp_path)

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "stage-a100",
            "--benchmark-root",
            str(benchmark),
            "--plan-only",
            "--transfer-mode",
            "tar-scp",
            "--remote-xenium-root",
            "/mnt/taobo.hu/long/10X_datasets/Xenium/Atera/WTA_Preview_FFPE_Breast_Cancer_outs",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["kind"] == "a100_stage_plan"
    assert payload["requires_host"] is True
    assert payload["stage_data"] is False
    assert payload["transfer_mode"] == "tar-scp"
    assert payload["readonly_xenium_root"].startswith("/mnt/taobo.hu")
    assert payload["path_policy"]["valid"] is True


def test_benchmark_prepare_a100_bundle_command(tmp_path, monkeypatch):
    benchmark = _write_adapter_dry_run_fixture(tmp_path)
    monkeypatch.chdir(tmp_path)

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "prepare-a100-bundle",
            "--benchmark-root",
            str(benchmark),
            "--methods",
            "squidpy",
            "--allow-missing-full",
            "--transfer-mode",
            "tar-scp",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["status"] in {"ready", "ready_after_remote_prepare"}
    assert payload["remote_xenium_root"].startswith("/mnt/taobo.hu")
    assert payload["job_manifest"]["jobs"]
    assert payload["job_manifest"]["jobs"][0]["job_id"] == "prepare_full_bundle"
    assert payload["stage_plan"]["kind"] == "a100_stage_plan"
    assert payload["stage_plan"]["transfer_mode"] == "tar-scp"
    assert payload["path_policy"]["valid"] is True


def test_benchmark_run_a100_plan_dry_run_command(tmp_path):
    plan = tmp_path / "plan.json"
    plan.write_text(
        json.dumps(
            {
                "kind": "a100_job_manifest",
                "jobs": [
                    {
                        "job_id": "full_common_db_squidpy",
                        "method": "squidpy",
                        "command": "echo squidpy",
                        "status": "planned",
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "run-a100-plan",
            "--plan-json",
            str(plan),
            "--remote",
            "--host",
            "sscb-a100.scilifelab.se",
            "--user",
            "taobo.hu",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["dry_run"] is True
    assert payload["remote"] is True
    assert payload["jobs"][0]["status"] == "dry-run"
    assert payload["jobs"][0]["wrapper_command"].startswith("ssh taobo.hu@sscb-a100.scilifelab.se ")


def test_benchmark_collect_a100_results_dry_run_command(tmp_path, monkeypatch):
    benchmark = _write_adapter_dry_run_fixture(tmp_path)
    monkeypatch.chdir(tmp_path)

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "collect-a100-results",
            "--benchmark-root",
            str(benchmark),
            "--transfer-mode",
            "scp",
            "--since-last",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["dry_run"] is True
    assert payload["since_last"] is True
    assert payload["transfer_mode"] == "scp"
    assert len(payload["commands"]) == 4


def test_benchmark_a100_matrix_submit_monitor_finalize_commands(tmp_path, monkeypatch):
    benchmark = _write_adapter_dry_run_fixture(tmp_path)
    monkeypatch.chdir(tmp_path)
    matrix_json = benchmark / "logs" / "matrix.json"
    status_tsv = benchmark / "results" / "status.tsv"

    build = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "build-a100-matrix",
            "--benchmark-root",
            str(benchmark),
            "--methods",
            "commot,cellchat",
            "--phase",
            "full",
            "--commot-chunks",
            "4",
            "--include-bootstrap",
            "--include-audit",
            "--output-json",
            str(matrix_json),
        ],
    )
    assert build.exit_code == 0
    build_payload = json.loads(build.output)
    assert matrix_json.exists()
    assert build_payload["kind"] == "a100_job_matrix"
    assert build_payload["include_bootstrap"] is True
    assert any(job["job_type"] == "env_bootstrap" for job in build_payload["jobs"])
    assert any(job["chunk_id"] == 0 for job in build_payload["jobs"] if job["method"] == "commot" and job["job_type"] == "method_run")

    submit = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "submit-a100-matrix",
            "--matrix-json",
            str(matrix_json),
            "--host",
            "sscb-a100.scilifelab.se",
            "--user",
            "taobo.hu",
            "--job-type",
            "env_bootstrap",
        ],
    )
    assert submit.exit_code == 0
    submit_payload = json.loads(submit.output)
    assert submit_payload["dry_run"] is True
    assert submit_payload["jobs"][0]["status"] == "dry-run"
    assert all(job["job_type"] == "env_bootstrap" for job in submit_payload["jobs"])

    monitor = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "monitor-a100-jobs",
            "--matrix-json",
            str(matrix_json),
            "--benchmark-root",
            str(benchmark),
            "--output-tsv",
            str(status_tsv),
        ],
    )
    assert monitor.exit_code == 0
    assert status_tsv.exists()

    finalize = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "finalize-a100-all",
            "--benchmark-root",
            str(benchmark),
        ],
    )
    assert finalize.exit_code == 0
    finalize_payload = json.loads(finalize.output)
    assert finalize_payload["n_rows"] == 0


def test_benchmark_build_a100_sidecar_command(tmp_path, monkeypatch):
    benchmark = _write_adapter_dry_run_fixture(tmp_path)
    monkeypatch.chdir(tmp_path)
    output_json = benchmark / "logs" / "sidecar.json"

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "build-a100-sidecar",
            "--benchmark-root",
            str(benchmark),
            "--methods",
            "squidpy,cellchat",
            "--ready-methods",
            "squidpy",
            "--output-json",
            str(output_json),
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert output_json.exists()
    assert payload["kind"] == "a100_sidecar_matrix"
    assert payload["ready_methods"] == ["squidpy"]
    assert any(job["job_id"] == "sidecar_smoke_common_db_squidpy" for job in payload["jobs"])
    assert not any(job["method"] == "cellchat" for job in payload["jobs"])


def test_benchmark_finalize_source_of_truth_command(tmp_path, monkeypatch):
    benchmark = _write_adapter_dry_run_fixture(tmp_path)
    monkeypatch.chdir(tmp_path)

    result = CliRunner().invoke(
        app,
        [
            "benchmark",
            "atera-cci",
            "finalize-source-of-truth",
            "--benchmark-root",
            str(benchmark),
            "--skip-report",
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["kind"] == "cci_source_of_truth_finalize"
    assert payload["n_rows"] == 0
