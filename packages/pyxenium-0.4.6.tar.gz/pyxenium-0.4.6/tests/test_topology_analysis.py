from __future__ import annotations

import pandas as pd
import pytest

from pyXenium import (
    compute_pathway_activity_matrix,
    cci_topology_analysis,
    pathway_topology_analysis,
)
from pyXenium.cci import cci_topology_analysis as cci_topology_analysis_direct
from pyXenium.pathway import (
    compute_pathway_activity_matrix as compute_pathway_activity_matrix_direct,
    pathway_topology_analysis as pathway_topology_analysis_direct,
)


def _toy_reference() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "cell_id": ["c1", "c2", "c3", "c4", "c5", "c6"],
            "x": [0.0, 1.0, 5.0, 6.0, 10.0, 11.0],
            "y": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            "celltype": ["A", "A", "B", "B", "C", "C"],
        }
    )


def _toy_expression(reference: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "L1": [5.0, 4.0, 0.0, 0.0, 0.0, 0.0],
            "R1": [0.0, 0.0, 4.0, 5.0, 0.0, 0.0],
            "L2": [0.0, 0.0, 0.0, 0.0, 5.0, 4.0],
            "R2": [4.0, 5.0, 0.0, 0.0, 0.0, 0.0],
            "G1": [5.0, 4.0, 0.0, 0.0, 0.0, 0.0],
            "G2": [0.0, 0.0, 5.0, 4.0, 0.0, 0.0],
            "G3": [0.0, 0.0, 0.0, 0.0, 5.0, 4.0],
        },
        index=reference["cell_id"],
    )


def _toy_t_and_c() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "A": [0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0],
            "B": [1.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0],
            "C": [1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0],
        },
        index=["L1", "R1", "L2", "R2", "G1", "G2", "G3"],
    )


def _toy_structure_map() -> pd.DataFrame:
    return pd.DataFrame(
        [[0.0, 0.3, 0.8], [0.3, 0.0, 0.5], [0.8, 0.5, 0.0]],
        index=["A", "B", "C"],
        columns=["A", "B", "C"],
    )


def test_public_topology_exports_are_importable():
    assert callable(cci_topology_analysis)
    assert callable(pathway_topology_analysis)
    assert callable(compute_pathway_activity_matrix)
    assert callable(cci_topology_analysis_direct)
    assert callable(pathway_topology_analysis_direct)
    assert callable(compute_pathway_activity_matrix_direct)


def test_analysis_topology_compatibility_imports_warn_and_resolve():
    with pytest.warns(DeprecationWarning):
        from pyXenium.analysis.cci_topology import (
            cci_topology_analysis as analysis_cci_topology_analysis,
        )

    with pytest.warns(DeprecationWarning):
        from pyXenium.analysis.pathway_topology import (
            compute_pathway_activity_matrix as legacy_compute_pathway_activity_matrix,
            pathway_topology_analysis as legacy_pathway_topology_analysis,
        )

    assert analysis_cci_topology_analysis is cci_topology_analysis_direct
    assert legacy_pathway_topology_analysis is pathway_topology_analysis_direct
    assert legacy_compute_pathway_activity_matrix is compute_pathway_activity_matrix_direct


def test_cci_precomputed_anchors_match_supplied_topology():
    reference = _toy_reference()
    expression = _toy_expression(reference)
    t_and_c = _toy_t_and_c()
    structure_map = _toy_structure_map()
    interaction_pairs = pd.DataFrame([{"ligand": "L1", "receptor": "R1", "evidence_weight": 1.0}])

    result = cci_topology_analysis(
        reference_df=reference,
        expression_df=expression,
        interaction_pairs=interaction_pairs,
        t_and_c_df=t_and_c,
        structure_map_df=structure_map,
        export_figures=False,
    )

    assert result["ligand_to_cell"].loc["L1", "A"] == 0.0
    assert result["receptor_to_cell"].loc["R1", "B"] == 0.0
    assert set(result["scores"]["anchor_source_ligand"]) == {"precomputed"}
    assert set(result["scores"]["anchor_source_receptor"]) == {"precomputed"}


def test_cci_hybrid_marks_fallback_sources_and_zeroes_sparse_contact():
    reference = _toy_reference()
    expression = _toy_expression(reference)
    t_and_c = _toy_t_and_c().drop(index=["R2"])
    structure_map = _toy_structure_map()
    interaction_pairs = pd.DataFrame([{"ligand": "L2", "receptor": "R2", "evidence_weight": 1.0}])

    result = cci_topology_analysis(
        reference_df=reference,
        expression_df=expression,
        interaction_pairs=interaction_pairs,
        t_and_c_df=t_and_c,
        structure_map_df=structure_map,
        anchor_mode="hybrid",
        min_cross_edges=999,
        export_figures=False,
    )

    assert "precomputed" in set(result["scores"]["anchor_source_ligand"])
    assert "recompute" in set(result["scores"]["anchor_source_receptor"])
    assert float(result["scores"]["local_contact"].fillna(0.0).max()) == 0.0
    assert not result["scores"]["local_contact"].isna().any()


def test_cci_calibration_modes_downstream_and_hotspots_are_optional(tmp_path):
    reference = _toy_reference()
    expression = _toy_expression(reference)
    t_and_c = _toy_t_and_c()
    structure_map = _toy_structure_map()
    interaction_pairs = pd.DataFrame(
        [
            {
                "ligand": "L1",
                "receptor": "R1",
                "evidence_weight": 1.0,
                "interaction_mode": "secreted/paracrine",
            },
            {
                "ligand": "L2",
                "receptor": "R2",
                "evidence_weight": 0.5,
                "interaction_mode": "juxtacrine/contact",
            },
        ]
    )

    result = cci_topology_analysis(
        reference_df=reference,
        expression_df=expression,
        interaction_pairs=interaction_pairs,
        t_and_c_df=t_and_c,
        structure_map_df=structure_map,
        null_model="component_shuffle",
        n_permutations=8,
        random_state=42,
        distance_kernel="mechanism_aware",
        downstream_targets={"L1^R1": ["G2", "missing_gene"]},
        output_dir=tmp_path,
        export_figures=False,
    )

    scores = result["scores"]
    assert {"interaction_mode", "distance_kernel_component", "cci_pvalue", "cci_fdr", "null_z"}.issubset(scores.columns)
    assert scores["cci_pvalue"].between(0.0, 1.0).all()
    assert scores["cci_fdr"].between(0.0, 1.0).all()
    assert scores.loc[(scores["ligand"] == "L1") & (scores["receptor"] == "R1"), "downstream_target_count"].max() == 1
    assert not result["null_calibration_summary"].empty
    assert not result["hotspot_table"].empty
    assert (tmp_path / "cci_null_calibration_summary.csv").exists()


def test_cci_return_hotspots_false_suppresses_hotspot_table():
    reference = _toy_reference()
    expression = _toy_expression(reference)
    interaction_pairs = pd.DataFrame([{"ligand": "L1", "receptor": "R1", "evidence_weight": 1.0}])

    result = cci_topology_analysis(
        reference_df=reference,
        expression_df=expression,
        interaction_pairs=interaction_pairs,
        t_and_c_df=_toy_t_and_c(),
        structure_map_df=_toy_structure_map(),
        return_hotspots=False,
        export_figures=False,
    )

    assert result["hotspot_table"].empty


def test_pathway_topology_writes_dual_outputs_and_diagnostics(tmp_path):
    reference = _toy_reference()
    expression = _toy_expression(reference)
    t_and_c = _toy_t_and_c()
    structure_map = _toy_structure_map()

    result = pathway_topology_analysis(
        reference_df=reference,
        expression_df=expression,
        pathway_definitions={
            "ProgA": ["G1"],
            "ProgB": ["G2", "G3"],
        },
        t_and_c_df=t_and_c,
        structure_map_df=structure_map,
        output_dir=tmp_path,
        export_figures=False,
    )

    assert (tmp_path / "pathway_to_cell.csv").exists()
    assert (tmp_path / "pathway_structuremap.csv").exists()
    assert (tmp_path / "pathway_activity_to_cell.csv").exists()
    assert (tmp_path / "pathway_activity_structuremap.csv").exists()
    assert (tmp_path / "pathway_mode_comparison.csv").exists()
    assert {"retained_cell_count", "retained_quantile", "activity_mode"}.issubset(
        result["pathway_mode_comparison"].columns
    )
    assert result["pathway_to_cell"].loc["ProgA"].astype(float).idxmin() == "A"
