"""Fused Triton kernel for SteklovSiLU (order 3).

Eliminates branching overhead of the PyTorch implementation.
Falls back to PyTorch if Triton is not available.
"""

import torch
from torch import Tensor

try:
    import triton
    import triton.language as tl

    HAS_TRITON = True
except ImportError:
    HAS_TRITON = False


if HAS_TRITON:

    @triton.jit
    def _steklov_silu_fwd_kernel(
        x_ptr, out_ptr, alpha, n_elements, BLOCK_SIZE: tl.constexpr
    ):
        pid = tl.program_id(0)
        offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
        mask = offsets < n_elements

        x = tl.load(x_ptr + offsets, mask=mask)
        u = x / alpha

        # Steklov sigmoid order 3
        s = tl.zeros_like(u)

        # Region 1: -1.5 < u <= -0.5
        m1 = (u > -1.5) & (u <= -0.5)
        v1 = u + 1.5
        s = tl.where(m1, (1.0 / 6.0) * v1 * v1 * v1, s)

        # Region 2: -0.5 < u <= 0.5
        m2 = (u > -0.5) & (u <= 0.5)
        s = tl.where(m2, 0.5 + 0.75 * u - (u * u * u) / 3.0, s)

        # Region 3: 0.5 < u < 1.5
        m3 = (u > 0.5) & (u < 1.5)
        v3 = 1.5 - u
        s = tl.where(m3, 1.0 - (1.0 / 6.0) * v3 * v3 * v3, s)

        # Region 4: u >= 1.5
        m4 = u >= 1.5
        s = tl.where(m4, 1.0, s)

        out = x * s
        tl.store(out_ptr + offsets, out, mask=mask)

    @triton.jit
    def _steklov_silu_bwd_kernel(
        x_ptr, grad_out_ptr, grad_in_ptr, alpha, n_elements,
        BLOCK_SIZE: tl.constexpr,
    ):
        pid = tl.program_id(0)
        offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
        mask = offsets < n_elements

        x = tl.load(x_ptr + offsets, mask=mask)
        grad_out = tl.load(grad_out_ptr + offsets, mask=mask)
        u = x / alpha

        # Steklov sigmoid
        s = tl.zeros_like(u)
        m1 = (u > -1.5) & (u <= -0.5)
        v1 = u + 1.5
        s = tl.where(m1, (1.0 / 6.0) * v1 * v1 * v1, s)
        m2 = (u > -0.5) & (u <= 0.5)
        s = tl.where(m2, 0.5 + 0.75 * u - (u * u * u) / 3.0, s)
        m3 = (u > 0.5) & (u < 1.5)
        v3 = 1.5 - u
        s = tl.where(m3, 1.0 - (1.0 / 6.0) * v3 * v3 * v3, s)
        m4 = u >= 1.5
        s = tl.where(m4, 1.0, s)

        # Steklov sigmoid derivative (= kernel psi_3)
        ds = tl.zeros_like(u)
        ds = tl.where(m1, 0.5 * v1 * v1 / alpha, ds)
        ds = tl.where(m2, (0.75 - u * u) / alpha, ds)
        ds = tl.where(m3, 0.5 * v3 * v3 / alpha, ds)

        # d/dx [x * sigma(x)] = sigma(x) + x * sigma'(x)
        grad_in = grad_out * (s + x * ds)
        tl.store(grad_in_ptr + offsets, grad_in, mask=mask)

    class _SteklovSiLUTriton(torch.autograd.Function):
        @staticmethod
        def forward(ctx, x: Tensor, alpha: float) -> Tensor:
            ctx.save_for_backward(x)
            ctx.alpha = alpha
            out = torch.empty_like(x)
            n = x.numel()
            BLOCK = 1024
            grid = ((n + BLOCK - 1) // BLOCK,)
            _steklov_silu_fwd_kernel[grid](x, out, alpha, n, BLOCK_SIZE=BLOCK)
            return out

        @staticmethod
        def backward(ctx, grad_out: Tensor):
            (x,) = ctx.saved_tensors
            grad_in = torch.empty_like(x)
            n = x.numel()
            BLOCK = 1024
            grid = ((n + BLOCK - 1) // BLOCK,)
            _steklov_silu_bwd_kernel[grid](
                x, grad_out, grad_in, ctx.alpha, n, BLOCK_SIZE=BLOCK
            )
            return grad_in, None

    def steklov_silu_triton(x: Tensor, alpha: float = 2.0) -> Tensor:
        """SteklovSiLU with fused Triton kernel (order 3 only).

        Matches GELU latency within 1-2%. Requires Triton.
        """
        return _SteklovSiLUTriton.apply(x, alpha)

else:

    def steklov_silu_triton(x: Tensor, alpha: float = 2.0) -> Tensor:
        """Fallback: pure PyTorch SteklovSiLU (Triton not available)."""
        from steklov_activations.activation import steklov_silu

        return steklov_silu(x, alpha, order=3)
