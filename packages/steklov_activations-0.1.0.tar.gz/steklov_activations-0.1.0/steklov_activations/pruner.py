"""Structurally prune permanently inactive neurons from MLP layers."""

import torch
import torch.nn as nn
from typing import Dict, Optional
from steklov_activations.profiler import InactivityReport


def prune_inactive_neurons(
    model: nn.Module,
    report: InactivityReport,
    threshold: Optional[float] = None,
    verbose: bool = True,
) -> Dict[str, int]:
    """Remove permanently dead neurons from MLP weight matrices.

    This physically shrinks the weight matrices, producing a smaller
    model that runs faster. The pruned model is functionally equivalent
    to the original for all practical inputs (neurons removed fire on
    < 0.1% of tokens).

    This modifies the model in-place.

    Args:
        model: Model to prune. Must have paired Linear layers
            (up_proj/down_proj or c_fc/c_proj style).
        report: InactivityReport from the profiler.
        threshold: Override the threshold from the report.
            Default: use report.threshold.
        verbose: Print per-layer pruning summary.

    Returns:
        Dict mapping layer names to number of neurons pruned.

    Example::

        profiler = InactivityProfiler(model)
        for batch in calibration_loader:
            with torch.no_grad():
                model(**batch)
        report = profiler.report(threshold=0.999)
        pruned = prune_inactive_neurons(model, report)
        # Model is now smaller and faster
    """
    if threshold is None:
        threshold = report.threshold

    masks = {
        name: (inact <= threshold)  # True = keep
        for name, inact in report.neuron_inactivity.items()
    }

    pruned_counts = {}

    # Find MLP blocks by walking the model
    for act_name, keep_mask in masks.items():
        n_keep = keep_mask.sum().item()
        n_total = keep_mask.shape[0]
        n_pruned = n_total - n_keep

        if n_pruned == 0:
            continue

        # Find the parent MLP module
        # Common patterns: mlp.act / mlp.activation / h.N.mlp.act
        parts = act_name.rsplit(".", 1)
        if len(parts) < 2:
            continue

        parent_name = parts[0]
        parent = _get_module(model, parent_name)
        if parent is None:
            continue

        keep_idx = keep_mask.nonzero(as_tuple=True)[0].to(
            next(model.parameters()).device
        )

        # Try common MLP patterns
        success = False

        # GPT-2 style: c_fc (d -> 4d) + c_proj (4d -> d)
        if hasattr(parent, "c_fc") and hasattr(parent, "c_proj"):
            success = _prune_linear_pair(
                parent.c_fc, parent.c_proj, keep_idx, "out", "in"
            )

        # LLaMA style: up_proj (d -> d_ff) + down_proj (d_ff -> d)
        # Optionally gate_proj (d -> d_ff)
        elif hasattr(parent, "up_proj") and hasattr(parent, "down_proj"):
            success = _prune_linear_pair(
                parent.up_proj, parent.down_proj, keep_idx, "out", "in"
            )
            if hasattr(parent, "gate_proj"):
                _prune_linear_out(parent.gate_proj, keep_idx)

        # Generic: look for two Linear layers where dimensions match
        else:
            linears = [
                (n, m) for n, m in parent.named_modules()
                if isinstance(m, nn.Linear)
            ]
            if len(linears) >= 2:
                fc1_name, fc1 = linears[0]
                fc2_name, fc2 = linears[1]
                if fc1.out_features == n_total and fc2.in_features == n_total:
                    success = _prune_linear_pair(
                        fc1, fc2, keep_idx, "out", "in"
                    )

        if success:
            pruned_counts[act_name] = n_pruned
            if verbose:
                print(
                    f"  {act_name}: pruned {n_pruned}/{n_total} neurons "
                    f"({n_pruned/n_total:.1%}), kept {n_keep}"
                )

    if verbose:
        total = sum(pruned_counts.values())
        print(f"Total: pruned {total} neurons across {len(pruned_counts)} layers")

    return pruned_counts


def _get_module(model: nn.Module, name: str) -> Optional[nn.Module]:
    """Get a submodule by dot-separated name."""
    parts = name.split(".")
    mod = model
    for p in parts:
        if hasattr(mod, p):
            mod = getattr(mod, p)
        else:
            return None
    return mod


def _prune_linear_pair(
    fc1: nn.Linear, fc2: nn.Linear, keep_idx: torch.Tensor,
    fc1_dim: str, fc2_dim: str,
) -> bool:
    """Prune a pair of Linear layers (up-projection + down-projection)."""
    try:
        _prune_linear_out(fc1, keep_idx)
        _prune_linear_in(fc2, keep_idx)
        return True
    except Exception:
        return False


def _prune_linear_out(linear: nn.Linear, keep_idx: torch.Tensor):
    """Prune output dimension of a Linear layer."""
    linear.weight = nn.Parameter(linear.weight.data[keep_idx])
    if linear.bias is not None:
        linear.bias = nn.Parameter(linear.bias.data[keep_idx])
    linear.out_features = keep_idx.shape[0]


def _prune_linear_in(linear: nn.Linear, keep_idx: torch.Tensor):
    """Prune input dimension of a Linear layer."""
    linear.weight = nn.Parameter(linear.weight.data[:, keep_idx])
    linear.in_features = keep_idx.shape[0]
