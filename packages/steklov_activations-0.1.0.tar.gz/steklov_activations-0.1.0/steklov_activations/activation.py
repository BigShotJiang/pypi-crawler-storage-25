"""SteklovSiLU activation function and PyTorch module."""

import torch
import torch.nn as nn
from torch import Tensor


def steklov_sigmoid(x: Tensor, alpha: float | Tensor, order: int = 3) -> Tensor:
    """Steklov sigmoid of given order.

    Compactly supported, C^{r-1} smooth sigmoid that is exactly 0 for
    x <= -r*alpha/2 and exactly 1 for x >= r*alpha/2.

    Args:
        x: Input tensor.
        alpha: Scale parameter (transition width). Scalar or broadcastable tensor.
        order: Kernel order r. Supports 1, 2, 3.

    Returns:
        Tensor of same shape as x, values in [0, 1].
    """
    u = x / alpha

    if order == 1:
        return torch.clamp(u + 0.5, 0.0, 1.0)

    elif order == 2:
        s = torch.zeros_like(u)
        m1 = (u > -1.0) & (u <= 0.0)
        m2 = (u > 0.0) & (u < 1.0)
        m3 = u >= 1.0
        s[m1] = 0.5 * (u[m1] + 1.0) ** 2
        s[m2] = 1.0 - 0.5 * (1.0 - u[m2]) ** 2
        s[m3] = 1.0
        return s

    elif order == 3:
        s = torch.zeros_like(u)
        m1 = (u > -1.5) & (u <= -0.5)
        m2 = (u > -0.5) & (u <= 0.5)
        m3 = (u > 0.5) & (u < 1.5)
        m4 = u >= 1.5
        s[m1] = (1.0 / 6.0) * (u[m1] + 1.5) ** 3
        s[m2] = 0.5 + 0.75 * u[m2] - (u[m2] ** 3) / 3.0
        s[m3] = 1.0 - (1.0 / 6.0) * (1.5 - u[m3]) ** 3
        s[m4] = 1.0
        return s

    else:
        raise ValueError(f"Order {order} not supported. Use 1, 2, or 3.")


def steklov_silu(x: Tensor, alpha: float | Tensor, order: int = 3) -> Tensor:
    """SteklovSiLU activation: x * steklov_sigmoid(x, alpha, order).

    Compact-support piecewise-polynomial activation.
    - order=3, alpha=2.0: approximates GELU (sup error < 0.0091)
    - order=1, alpha=6.0: exactly HardSwish
    - alpha -> 0: approaches ReLU
    - alpha -> inf: approaches x/2

    Args:
        x: Input tensor.
        alpha: Scale parameter controlling support width and sparsity.
        order: Kernel order r (1, 2, or 3).

    Returns:
        Tensor of same shape as x.
    """
    return x * steklov_sigmoid(x, alpha, order)


class SteklovSiLU(nn.Module):
    """SteklovSiLU activation module.

    Drop-in replacement for GELU/SiLU/ReLU. Compact support produces
    exact zero output and gradient outside [-r*alpha/2, r*alpha/2].

    Args:
        alpha: Initial scale parameter. Default 2.0 (GELU-like).
        order: Kernel order r. Default 3 (C^2 smooth).
        learnable: If True, alpha is optimized during training.

    Example::

        # Fixed alpha (GELU-like)
        act = SteklovSiLU(alpha=2.0)

        # Learnable alpha
        act = SteklovSiLU(alpha=2.0, learnable=True)

        # High sparsity
        act = SteklovSiLU(alpha=0.1)  # ~87% per-token zeros on LLaMA
    """

    def __init__(self, alpha: float = 2.0, order: int = 3, learnable: bool = False):
        super().__init__()
        self.order = order

        if learnable:
            self.alpha = nn.Parameter(torch.tensor(float(alpha)))
        else:
            self.register_buffer("alpha", torch.tensor(float(alpha)))

    @property
    def learnable(self) -> bool:
        return isinstance(self.alpha, nn.Parameter)

    @property
    def support_width(self) -> float:
        """Full support width: r * alpha."""
        return self.order * self.alpha.item()

    def forward(self, x: Tensor) -> Tensor:
        return steklov_silu(x, self.alpha, self.order)

    def extra_repr(self) -> str:
        return (
            f"alpha={self.alpha.item():.4f}, order={self.order}, "
            f"learnable={self.learnable}"
        )
