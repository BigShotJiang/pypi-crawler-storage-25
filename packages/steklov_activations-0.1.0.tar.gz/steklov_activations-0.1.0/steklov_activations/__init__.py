"""Steklov Activations: compact-support piecewise-polynomial gates."""

from steklov_activations.activation import SteklovSiLU, steklov_silu, steklov_sigmoid
from steklov_activations.swap import swap_activation
from steklov_activations.profiler import InactivityProfiler
from steklov_activations.pruner import prune_inactive_neurons

__version__ = "0.1.0"
__all__ = [
    "SteklovSiLU",
    "steklov_silu",
    "steklov_sigmoid",
    "swap_activation",
    "InactivityProfiler",
    "prune_inactive_neurons",
]
