"""Profile neuron inactivity across a calibration dataset."""

import torch
import torch.nn as nn
from torch import Tensor
from typing import Dict, List, Optional
from dataclasses import dataclass


@dataclass
class InactivityReport:
    """Results from inactivity profiling."""

    # Per-layer stats
    layer_names: List[str]
    total_neurons: List[int]
    inactive_counts: List[int]  # at the specified threshold
    inactivity_rates: List[float]  # fraction inactive per layer

    # Global stats
    global_dynamic_sparsity: float  # mean fraction of zeros per token
    global_structural_sparsity: float  # fraction permanently dead (> threshold)
    total_profiled_tokens: int
    threshold: float

    # Per-neuron data (for pruning)
    neuron_inactivity: Dict[str, Tensor]  # layer_name -> fraction inactive

    def summary(self) -> str:
        lines = [
            f"Inactivity Report ({self.total_profiled_tokens:,} tokens, "
            f"threshold={self.threshold:.1%})",
            f"  Dynamic sparsity (per-token zeros): {self.global_dynamic_sparsity:.1%}",
            f"  Structural sparsity (permanently dead): {self.global_structural_sparsity:.1%}",
            "",
        ]
        for name, total, inactive, rate in zip(
            self.layer_names, self.total_neurons,
            self.inactive_counts, self.inactivity_rates
        ):
            lines.append(f"  {name}: {inactive}/{total} inactive ({rate:.1%})")
        return "\n".join(lines)

    def neurons_to_prune(self) -> Dict[str, Tensor]:
        """Return boolean mask per layer: True = should be pruned."""
        return {
            name: (inact > self.threshold)
            for name, inact in self.neuron_inactivity.items()
        }

    def nm_compliance(self, n: int = 2, m: int = 4) -> Optional[float]:
        """Estimate N:M structured sparsity compliance from dynamic sparsity.

        This is an approximation. For exact compliance, use
        measure_nm_compliance() on actual activation tensors.
        """
        p = self.global_dynamic_sparsity
        if p <= 0:
            return 0.0
        # Probability that >= n out of m consecutive values are zero
        # assuming independent Bernoulli(p) zeros
        from math import comb
        compliance = sum(
            comb(m, k) * (p ** k) * ((1 - p) ** (m - k))
            for k in range(n, m + 1)
        )
        return compliance


class InactivityProfiler:
    """Profile which neurons are inactive across a dataset.

    Hooks into MLP activation layers and counts how often each neuron
    produces exact zero output.

    Args:
        model: The model to profile.
        layer_pattern: Substring to match layer names containing SteklovSiLU.
            Default matches common patterns.

    Example::

        profiler = InactivityProfiler(model)
        for batch in calibration_loader:
            with torch.no_grad():
                model(**batch)
        report = profiler.report(threshold=0.999)
        print(report.summary())
        masks = report.neurons_to_prune()
    """

    def __init__(
        self,
        model: nn.Module,
        layer_pattern: Optional[str] = None,
    ):
        self.model = model
        self.hooks: List[torch.utils.hooks.RemovableHook] = []
        self.zero_counts: Dict[str, Tensor] = {}
        self.total_counts: Dict[str, int] = {}
        self.dynamic_zeros: List[float] = []
        self.dynamic_totals: List[int] = []
        self._layer_names: List[str] = []

        # Find and hook SteklovSiLU layers
        from steklov_activations.activation import SteklovSiLU

        for name, module in model.named_modules():
            if isinstance(module, SteklovSiLU):
                if layer_pattern is None or layer_pattern in name:
                    self._register_hook(name, module)

        if not self.hooks:
            print(
                "Warning: no SteklovSiLU layers found. "
                "Make sure the model uses SteklovSiLU activations."
            )

    def _register_hook(self, name: str, module: nn.Module):
        self._layer_names.append(name)

        def hook_fn(mod, inp, out, layer_name=name):
            with torch.no_grad():
                # out shape: [..., d_ff]
                flat = out.reshape(-1, out.shape[-1])
                n_tokens = flat.shape[0]
                is_zero = (flat == 0.0).float()

                if layer_name not in self.zero_counts:
                    self.zero_counts[layer_name] = torch.zeros(
                        out.shape[-1], device=out.device
                    )
                    self.total_counts[layer_name] = 0

                self.zero_counts[layer_name] += is_zero.sum(dim=0)
                self.total_counts[layer_name] += n_tokens

                # Track dynamic sparsity
                self.dynamic_zeros.append(is_zero.sum().item())
                self.dynamic_totals.append(flat.numel())

        self.hooks.append(module.register_forward_hook(hook_fn))

    def report(self, threshold: float = 0.999) -> InactivityReport:
        """Generate inactivity report.

        Args:
            threshold: Fraction of tokens a neuron must be inactive on
                to be considered permanently dead. Default 0.999 (99.9%).

        Returns:
            InactivityReport with per-layer and global statistics.
        """
        layer_names = []
        total_neurons = []
        inactive_counts = []
        inactivity_rates = []
        neuron_inactivity = {}

        total_structural = 0
        total_n = 0

        for name in self._layer_names:
            if name not in self.zero_counts:
                continue

            counts = self.zero_counts[name]
            n_tokens = self.total_counts[name]
            n_neurons = counts.shape[0]

            frac_inactive = counts / max(n_tokens, 1)
            n_dead = (frac_inactive > threshold).sum().item()

            layer_names.append(name)
            total_neurons.append(n_neurons)
            inactive_counts.append(int(n_dead))
            inactivity_rates.append(n_dead / max(n_neurons, 1))
            neuron_inactivity[name] = frac_inactive.cpu()

            total_structural += n_dead
            total_n += n_neurons

        # Global dynamic sparsity
        total_dyn_zeros = sum(self.dynamic_zeros)
        total_dyn_elements = sum(self.dynamic_totals)
        global_dynamic = total_dyn_zeros / max(total_dyn_elements, 1)
        global_structural = total_structural / max(total_n, 1)

        total_tokens = max(self.total_counts.values()) if self.total_counts else 0

        return InactivityReport(
            layer_names=layer_names,
            total_neurons=total_neurons,
            inactive_counts=inactive_counts,
            inactivity_rates=inactivity_rates,
            global_dynamic_sparsity=global_dynamic,
            global_structural_sparsity=global_structural,
            total_profiled_tokens=total_tokens,
            threshold=threshold,
            neuron_inactivity=neuron_inactivity,
        )

    def remove_hooks(self):
        """Remove all forward hooks."""
        for h in self.hooks:
            h.remove()
        self.hooks.clear()

    def reset(self):
        """Reset all counters."""
        self.zero_counts.clear()
        self.total_counts.clear()
        self.dynamic_zeros.clear()
        self.dynamic_totals.clear()
