"""Swap activation functions in an existing model."""

import torch.nn as nn
from steklov_activations.activation import SteklovSiLU


def swap_activation(
    model: nn.Module,
    new_activation: nn.Module | None = None,
    alpha: float = 2.0,
    order: int = 3,
    learnable: bool = False,
    target_types: tuple = (nn.GELU, nn.SiLU, nn.ReLU),
    verbose: bool = True,
) -> nn.Module:
    """Replace activation functions in a model with SteklovSiLU.

    Walks the module tree and replaces all instances of target_types
    with SteklovSiLU (or a custom module).

    Note: post-hoc swapping on a pretrained model will NOT produce
    the sparsity patterns observed when training from scratch.
    This utility is for starting new training runs, not for
    converting existing checkpoints.

    Args:
        model: The model to modify (in-place).
        new_activation: Custom replacement module. If None, uses
            SteklovSiLU with the specified alpha/order/learnable.
        alpha: Scale parameter for SteklovSiLU.
        order: Kernel order for SteklovSiLU.
        learnable: Whether alpha should be trainable.
        target_types: Tuple of activation classes to replace.
        verbose: Print replacement summary.

    Returns:
        The modified model (same object, modified in-place).

    Example::

        from transformers import AutoModelForCausalLM
        model = AutoModelForCausalLM.from_pretrained("gpt2")
        swap_activation(model, alpha=0.8)
        # Now train from scratch or fine-tune
    """
    count = 0

    def _make_new():
        if new_activation is not None:
            import copy
            return copy.deepcopy(new_activation)
        return SteklovSiLU(alpha=alpha, order=order, learnable=learnable)

    for name, module in model.named_modules():
        for attr_name, child in list(module.named_children()):
            if isinstance(child, target_types):
                setattr(module, attr_name, _make_new())
                count += 1

    if verbose:
        act_desc = new_activation or f"SteklovSiLU(alpha={alpha}, order={order})"
        print(f"Replaced {count} activation(s) with {act_desc}")

    return model
