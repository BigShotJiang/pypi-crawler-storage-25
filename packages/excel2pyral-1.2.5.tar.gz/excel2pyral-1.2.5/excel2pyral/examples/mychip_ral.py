"""
PyUVM Register Abstraction Layer Model

Auto-generated from SystemRDL specification using excel2pyral
Package  : mychip_ral
Generated: 2026-03-31 02:32:11
"""

import logging
from pyuvm import uvm_reg, uvm_reg_field, uvm_reg_map
from pyuvm import uvm_reg_block

logger = logging.getLogger(__name__)


# ============================================================================
# Register Classes
# ============================================================================

class CrtlReg(uvm_reg):
    """CRTL_REG"""

    def __init__(self, name="CRTL_REG", reg_width=32):
        super().__init__(name, reg_width)
        self.ENABLE = uvm_reg_field("ENABLE")
        self.MODE = uvm_reg_field("MODE")

    def build(self):
        self.ENABLE.configure(self, size=1, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self.MODE.configure(self, size=3, lsb_pos=1, access="RO", is_volatile=False, reset=0x0)
        self._set_lock()


class StatusReg(uvm_reg):
    """STATUS_REG"""

    def __init__(self, name="STATUS_REG", reg_width=32):
        super().__init__(name, reg_width)
        self.READY = uvm_reg_field("READY")

    def build(self):
        self.READY.configure(self, size=1, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class GpioCrtlReg(uvm_reg):
    """CRTL_REG"""

    def __init__(self, name="CRTL_REG", reg_width=32):
        super().__init__(name, reg_width)
        self.ENABLE = uvm_reg_field("ENABLE")
        self.MODE = uvm_reg_field("MODE")

    def build(self):
        self.ENABLE.configure(self, size=1, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self.MODE.configure(self, size=3, lsb_pos=1, access="RO", is_volatile=False, reset=0x0)
        self._set_lock()


class GpioStatusReg(uvm_reg):
    """STATUS_REG"""

    def __init__(self, name="STATUS_REG", reg_width=32):
        super().__init__(name, reg_width)
        self.READY = uvm_reg_field("READY")

    def build(self):
        self.READY.configure(self, size=1, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class ResetReg(uvm_reg):
    """RESET_REG"""

    def __init__(self, name="RESET_REG", reg_width=32):
        super().__init__(name, reg_width)
        self.PAUSE = uvm_reg_field("PAUSE")
        self.START = uvm_reg_field("START")

    def build(self):
        self.PAUSE.configure(self, size=1, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self.START.configure(self, size=3, lsb_pos=1, access="RO", is_volatile=False, reset=0x0)
        self._set_lock()


class StopReg(uvm_reg):
    """STOP_REG"""

    def __init__(self, name="STOP_REG", reg_width=32):
        super().__init__(name, reg_width)
        self.END = uvm_reg_field("END")

    def build(self):
        self.END.configure(self, size=1, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class UartResetReg(uvm_reg):
    """RESET_REG"""

    def __init__(self, name="RESET_REG", reg_width=32):
        super().__init__(name, reg_width)
        self.PAUSE = uvm_reg_field("PAUSE")
        self.START = uvm_reg_field("START")

    def build(self):
        self.PAUSE.configure(self, size=1, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self.START.configure(self, size=3, lsb_pos=1, access="RO", is_volatile=False, reset=0x0)
        self._set_lock()


class UartStopReg(uvm_reg):
    """STOP_REG"""

    def __init__(self, name="STOP_REG", reg_width=32):
        super().__init__(name, reg_width)
        self.END = uvm_reg_field("END")

    def build(self):
        self.END.configure(self, size=1, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


# ============================================================================
# Register Block Classes
# ============================================================================

class Gpio(uvm_reg_block):
    """GPIO — register block (default base 0x1000)."""

    def __init__(self, name="GPIO"):
        super().__init__(name)
        self.def_map = None

    def build(self, base_address=0x1000):
        """Create the register map and add all registers."""
        self.def_map = uvm_reg_map("def_map")
        self.def_map.configure(self, base_address)
        self.default_map = self.def_map

        self.def_map.crtl_reg_reg = CrtlReg("crtl_reg_reg")
        self.def_map.crtl_reg_reg.configure(self, hex(base_address + 0x0), "", False, False)
        self.def_map.add_reg(self.def_map.crtl_reg_reg, "0", "RW")

        self.def_map.status_reg_reg = StatusReg("status_reg_reg")
        self.def_map.status_reg_reg.configure(self, hex(base_address + 0x4), "", False, False)
        self.def_map.add_reg(self.def_map.status_reg_reg, "0", "RW")

        logger.info(
            f"Gpio build completed — def_map ({hex(base_address)}), 2 registers")


class Uart(uvm_reg_block):
    """UART — register block (default base 0x2000)."""

    def __init__(self, name="UART"):
        super().__init__(name)
        self.def_map = None

    def build(self, base_address=0x2000):
        """Create the register map and add all registers."""
        self.def_map = uvm_reg_map("def_map")
        self.def_map.configure(self, base_address)
        self.default_map = self.def_map

        self.def_map.reset_reg_reg = ResetReg("reset_reg_reg")
        self.def_map.reset_reg_reg.configure(self, hex(base_address + 0x8), "", False, False)
        self.def_map.add_reg(self.def_map.reset_reg_reg, "0", "RW")

        self.def_map.stop_reg_reg = StopReg("stop_reg_reg")
        self.def_map.stop_reg_reg.configure(self, hex(base_address + 0x16), "", False, False)
        self.def_map.add_reg(self.def_map.stop_reg_reg, "0", "RW")

        logger.info(
            f"Uart build completed — def_map ({hex(base_address)}), 2 registers")


# ============================================================================
# Top-Level Container Class
# ============================================================================

class MychipTop:
    """
    Top-level RAL container — holds one uvm_reg_block per hardware module.
    get_all_maps() and set_sequencer_adapter() discover sub-blocks automatically
    via Python introspection; no changes needed elsewhere when a new block is added.
    """

    def __init__(self, name="mychip_top"):
        self.name = name
        self.gpio0 = Gpio("gpio0")
        self.gpio1 = Gpio("gpio1")
        self.uart0 = Uart("uart0")
        self.uart1 = Uart("uart1")

    def build(self):
        self.gpio0.build(base_address=0x1000)
        self.gpio1.build(base_address=0x1100)
        self.uart0.build(base_address=0x2000)
        self.uart1.build(base_address=0x3000)

    def get_all_maps(self):
        """Return default_map of every uvm_reg_block attribute."""
        return [
            getattr(self, attr).default_map
            for attr in vars(self)
            if isinstance(getattr(self, attr), uvm_reg_block)
        ]

    def set_sequencer_adapter(self, seqr, adp):
        """Wire adapter+sequencer on every sub-block map — call once from connect_phase."""
        for m in self.get_all_maps():
            m.set_sequencer(seqr)
            m.set_adapter(adp)
