"""
PyUVM Register Abstraction Layer Model

Auto-generated from SystemRDL specification using excel2pyral
Package  : PROJECT_TEST_ral
Generated: 2026-03-31 02:32:12
"""

import logging
from pyuvm import uvm_reg, uvm_reg_field, uvm_reg_map
from pyuvm import uvm_reg_block

logger = logging.getLogger(__name__)


# ============================================================================
# Register Classes
# ============================================================================

class TestCtrlAddr(uvm_reg):
    """TEST_CTRL_ADDR"""

    def __init__(self, name="TEST_CTRL_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CTRL_ADDR = uvm_reg_field("TEST_CTRL_ADDR")

    def build(self):
        self.TEST_CTRL_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestStsAddr(uvm_reg):
    """TEST_STS_ADDR"""

    def __init__(self, name="TEST_STS_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_STS_ADDR = uvm_reg_field("TEST_STS_ADDR")

    def build(self):
        self.TEST_STS_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestRuptcntAddr(uvm_reg):
    """TEST_RUPTCNT_ADDR"""

    def __init__(self, name="TEST_RUPTCNT_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_RUPTCNT_ADDR = uvm_reg_field("TEST_RUPTCNT_ADDR")

    def build(self):
        self.TEST_RUPTCNT_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh0EnAddr(uvm_reg):
    """TEST_CH0_EN_ADDR"""

    def __init__(self, name="TEST_CH0_EN_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH0_EN_ADDR = uvm_reg_field("TEST_CH0_EN_ADDR")

    def build(self):
        self.TEST_CH0_EN_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh0DdrAddr(uvm_reg):
    """TEST_CH0_DDR_ADDR"""

    def __init__(self, name="TEST_CH0_DDR_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH0_DDR_ADDR = uvm_reg_field("TEST_CH0_DDR_ADDR")

    def build(self):
        self.TEST_CH0_DDR_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh0PktAddr(uvm_reg):
    """TEST_CH0_PKT_ADDR"""

    def __init__(self, name="TEST_CH0_PKT_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH0_PKT_ADDR = uvm_reg_field("TEST_CH0_PKT_ADDR")

    def build(self):
        self.TEST_CH0_PKT_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh0BufAddr(uvm_reg):
    """TEST_CH0_BUF_ADDR"""

    def __init__(self, name="TEST_CH0_BUF_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH0_BUF_ADDR = uvm_reg_field("TEST_CH0_BUF_ADDR")

    def build(self):
        self.TEST_CH0_BUF_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh0StsAddr(uvm_reg):
    """TEST_CH0_STS_ADDR"""

    def __init__(self, name="TEST_CH0_STS_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH0_STS_ADDR = uvm_reg_field("TEST_CH0_STS_ADDR")

    def build(self):
        self.TEST_CH0_STS_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh0WrpAddr(uvm_reg):
    """TEST_CH0_WRP_ADDR"""

    def __init__(self, name="TEST_CH0_WRP_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH0_WRP_ADDR = uvm_reg_field("TEST_CH0_WRP_ADDR")

    def build(self):
        self.TEST_CH0_WRP_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh0MfifoAddr(uvm_reg):
    """TEST_CH0_MFIFO_ADDR"""

    def __init__(self, name="TEST_CH0_MFIFO_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH0_MFIFO_ADDR = uvm_reg_field("TEST_CH0_MFIFO_ADDR")

    def build(self):
        self.TEST_CH0_MFIFO_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh0IfifoAddr(uvm_reg):
    """TEST_CH0_IFIFO_ADDR"""

    def __init__(self, name="TEST_CH0_IFIFO_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH0_IFIFO_ADDR = uvm_reg_field("TEST_CH0_IFIFO_ADDR")

    def build(self):
        self.TEST_CH0_IFIFO_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh1EnAddr(uvm_reg):
    """TEST_CH1_EN_ADDR"""

    def __init__(self, name="TEST_CH1_EN_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH1_EN_ADDR = uvm_reg_field("TEST_CH1_EN_ADDR")

    def build(self):
        self.TEST_CH1_EN_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh1DdrAddr(uvm_reg):
    """TEST_CH1_DDR_ADDR"""

    def __init__(self, name="TEST_CH1_DDR_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH1_DDR_ADDR = uvm_reg_field("TEST_CH1_DDR_ADDR")

    def build(self):
        self.TEST_CH1_DDR_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh1PktAddr(uvm_reg):
    """TEST_CH1_PKT_ADDR"""

    def __init__(self, name="TEST_CH1_PKT_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH1_PKT_ADDR = uvm_reg_field("TEST_CH1_PKT_ADDR")

    def build(self):
        self.TEST_CH1_PKT_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh1BufAddr(uvm_reg):
    """TEST_CH1_BUF_ADDR"""

    def __init__(self, name="TEST_CH1_BUF_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH1_BUF_ADDR = uvm_reg_field("TEST_CH1_BUF_ADDR")

    def build(self):
        self.TEST_CH1_BUF_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh1StsAddr(uvm_reg):
    """TEST_CH1_STS_ADDR"""

    def __init__(self, name="TEST_CH1_STS_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH1_STS_ADDR = uvm_reg_field("TEST_CH1_STS_ADDR")

    def build(self):
        self.TEST_CH1_STS_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh1WrpAddr(uvm_reg):
    """TEST_CH1_WRP_ADDR"""

    def __init__(self, name="TEST_CH1_WRP_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH1_WRP_ADDR = uvm_reg_field("TEST_CH1_WRP_ADDR")

    def build(self):
        self.TEST_CH1_WRP_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh1MfifoAddr(uvm_reg):
    """TEST_CH1_MFIFO_ADDR"""

    def __init__(self, name="TEST_CH1_MFIFO_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH1_MFIFO_ADDR = uvm_reg_field("TEST_CH1_MFIFO_ADDR")

    def build(self):
        self.TEST_CH1_MFIFO_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh1IfifoAddr(uvm_reg):
    """TEST_CH1_IFIFO_ADDR"""

    def __init__(self, name="TEST_CH1_IFIFO_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH1_IFIFO_ADDR = uvm_reg_field("TEST_CH1_IFIFO_ADDR")

    def build(self):
        self.TEST_CH1_IFIFO_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh2EnAddr(uvm_reg):
    """TEST_CH2_EN_ADDR"""

    def __init__(self, name="TEST_CH2_EN_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH2_EN_ADDR = uvm_reg_field("TEST_CH2_EN_ADDR")

    def build(self):
        self.TEST_CH2_EN_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh2DdrAddr(uvm_reg):
    """TEST_CH2_DDR_ADDR"""

    def __init__(self, name="TEST_CH2_DDR_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH2_DDR_ADDR = uvm_reg_field("TEST_CH2_DDR_ADDR")

    def build(self):
        self.TEST_CH2_DDR_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh2PktAddr(uvm_reg):
    """TEST_CH2_PKT_ADDR"""

    def __init__(self, name="TEST_CH2_PKT_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH2_PKT_ADDR = uvm_reg_field("TEST_CH2_PKT_ADDR")

    def build(self):
        self.TEST_CH2_PKT_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh2BufAddr(uvm_reg):
    """TEST_CH2_BUF_ADDR"""

    def __init__(self, name="TEST_CH2_BUF_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH2_BUF_ADDR = uvm_reg_field("TEST_CH2_BUF_ADDR")

    def build(self):
        self.TEST_CH2_BUF_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh2StsAddr(uvm_reg):
    """TEST_CH2_STS_ADDR"""

    def __init__(self, name="TEST_CH2_STS_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH2_STS_ADDR = uvm_reg_field("TEST_CH2_STS_ADDR")

    def build(self):
        self.TEST_CH2_STS_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh2WrpAddr(uvm_reg):
    """TEST_CH2_WRP_ADDR"""

    def __init__(self, name="TEST_CH2_WRP_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH2_WRP_ADDR = uvm_reg_field("TEST_CH2_WRP_ADDR")

    def build(self):
        self.TEST_CH2_WRP_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh2MfifoAddr(uvm_reg):
    """TEST_CH2_MFIFO_ADDR"""

    def __init__(self, name="TEST_CH2_MFIFO_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH2_MFIFO_ADDR = uvm_reg_field("TEST_CH2_MFIFO_ADDR")

    def build(self):
        self.TEST_CH2_MFIFO_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh2IfifoAddr(uvm_reg):
    """TEST_CH2_IFIFO_ADDR"""

    def __init__(self, name="TEST_CH2_IFIFO_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH2_IFIFO_ADDR = uvm_reg_field("TEST_CH2_IFIFO_ADDR")

    def build(self):
        self.TEST_CH2_IFIFO_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh3EnAddr(uvm_reg):
    """TEST_CH3_EN_ADDR"""

    def __init__(self, name="TEST_CH3_EN_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH3_EN_ADDR = uvm_reg_field("TEST_CH3_EN_ADDR")

    def build(self):
        self.TEST_CH3_EN_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh3DdrAddr(uvm_reg):
    """TEST_CH3_DDR_ADDR"""

    def __init__(self, name="TEST_CH3_DDR_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH3_DDR_ADDR = uvm_reg_field("TEST_CH3_DDR_ADDR")

    def build(self):
        self.TEST_CH3_DDR_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh3PktAddr(uvm_reg):
    """TEST_CH3_PKT_ADDR"""

    def __init__(self, name="TEST_CH3_PKT_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH3_PKT_ADDR = uvm_reg_field("TEST_CH3_PKT_ADDR")

    def build(self):
        self.TEST_CH3_PKT_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh3BufAddr(uvm_reg):
    """TEST_CH3_BUF_ADDR"""

    def __init__(self, name="TEST_CH3_BUF_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH3_BUF_ADDR = uvm_reg_field("TEST_CH3_BUF_ADDR")

    def build(self):
        self.TEST_CH3_BUF_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh3StsAddr(uvm_reg):
    """TEST_CH3_STS_ADDR"""

    def __init__(self, name="TEST_CH3_STS_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH3_STS_ADDR = uvm_reg_field("TEST_CH3_STS_ADDR")

    def build(self):
        self.TEST_CH3_STS_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh3WrpAddr(uvm_reg):
    """TEST_CH3_WRP_ADDR"""

    def __init__(self, name="TEST_CH3_WRP_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH3_WRP_ADDR = uvm_reg_field("TEST_CH3_WRP_ADDR")

    def build(self):
        self.TEST_CH3_WRP_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh3MfifoAddr(uvm_reg):
    """TEST_CH3_MFIFO_ADDR"""

    def __init__(self, name="TEST_CH3_MFIFO_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH3_MFIFO_ADDR = uvm_reg_field("TEST_CH3_MFIFO_ADDR")

    def build(self):
        self.TEST_CH3_MFIFO_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh3IfifoAddr(uvm_reg):
    """TEST_CH3_IFIFO_ADDR"""

    def __init__(self, name="TEST_CH3_IFIFO_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH3_IFIFO_ADDR = uvm_reg_field("TEST_CH3_IFIFO_ADDR")

    def build(self):
        self.TEST_CH3_IFIFO_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestInpFmtCtrl0Addr(uvm_reg):
    """TEST_INP_FMT_CTRL0_ADDR"""

    def __init__(self, name="TEST_INP_FMT_CTRL0_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_INP_FMT_CTRL0_ADDR = uvm_reg_field("TEST_INP_FMT_CTRL0_ADDR")

    def build(self):
        self.TEST_INP_FMT_CTRL0_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestInpFmtCtrl1Addr(uvm_reg):
    """TEST_INP_FMT_CTRL1_ADDR"""

    def __init__(self, name="TEST_INP_FMT_CTRL1_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_INP_FMT_CTRL1_ADDR = uvm_reg_field("TEST_INP_FMT_CTRL1_ADDR")

    def build(self):
        self.TEST_INP_FMT_CTRL1_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestLclpulseCtrlAddr(uvm_reg):
    """TEST_LCLPULSE_CTRL_ADDR"""

    def __init__(self, name="TEST_LCLPULSE_CTRL_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_LCLPULSE_CTRL_ADDR = uvm_reg_field("TEST_LCLPULSE_CTRL_ADDR")

    def build(self):
        self.TEST_LCLPULSE_CTRL_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestLclpulseRdataAddr(uvm_reg):
    """TEST_LCLPULSE_RDATA_ADDR"""

    def __init__(self, name="TEST_LCLPULSE_RDATA_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_LCLPULSE_RDATA_ADDR = uvm_reg_field("TEST_LCLPULSE_RDATA_ADDR")

    def build(self):
        self.TEST_LCLPULSE_RDATA_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class Advci2DataReplayCtrlAddr(uvm_reg):
    """ADVCI2_DATA_REPLAY_CTRL_ADDR"""

    def __init__(self, name="ADVCI2_DATA_REPLAY_CTRL_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.ADVCI2_DATA_REPLAY_CTRL_ADDR = uvm_reg_field("ADVCI2_DATA_REPLAY_CTRL_ADDR")

    def build(self):
        self.ADVCI2_DATA_REPLAY_CTRL_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class Advci2DataReplayStsAddr(uvm_reg):
    """ADVCI2_DATA_REPLAY_STS_ADDR"""

    def __init__(self, name="ADVCI2_DATA_REPLAY_STS_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.ADVCI2_DATA_REPLAY_STS_ADDR = uvm_reg_field("ADVCI2_DATA_REPLAY_STS_ADDR")

    def build(self):
        self.ADVCI2_DATA_REPLAY_STS_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class Advci2DataReplayTxfrLengthAddr(uvm_reg):
    """ADVCI2_DATA_REPLAY_TXFR_LENGTH_ADDR"""

    def __init__(self, name="ADVCI2_DATA_REPLAY_TXFR_LENGTH_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.ADVCI2_DATA_REPLAY_TXFR_LENGTH_ADDR = uvm_reg_field("ADVCI2_DATA_REPLAY_TXFR_LENGTH_ADDR")

    def build(self):
        self.ADVCI2_DATA_REPLAY_TXFR_LENGTH_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestLclpulseBufrLengthAddr(uvm_reg):
    """TEST_LCLPULSE_BUFR_LENGTH_ADDR"""

    def __init__(self, name="TEST_LCLPULSE_BUFR_LENGTH_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_LCLPULSE_BUFR_LENGTH_ADDR = uvm_reg_field("TEST_LCLPULSE_BUFR_LENGTH_ADDR")

    def build(self):
        self.TEST_LCLPULSE_BUFR_LENGTH_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestLclpulseWdataAddr(uvm_reg):
    """TEST_LCLPULSE_WDATA_ADDR"""

    def __init__(self, name="TEST_LCLPULSE_WDATA_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_LCLPULSE_WDATA_ADDR = uvm_reg_field("TEST_LCLPULSE_WDATA_ADDR")

    def build(self):
        self.TEST_LCLPULSE_WDATA_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestLclpulseCexPosCntsAddr(uvm_reg):
    """TEST_LCLPULSE_CEX_POS_CNTS_ADDR"""

    def __init__(self, name="TEST_LCLPULSE_CEX_POS_CNTS_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_LCLPULSE_CEX_POS_CNTS_ADDR = uvm_reg_field("TEST_LCLPULSE_CEX_POS_CNTS_ADDR")

    def build(self):
        self.TEST_LCLPULSE_CEX_POS_CNTS_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestCh0RuptcntrAddr(uvm_reg):
    """TEST_CH0_RUPTCNTR_ADDR"""

    def __init__(self, name="TEST_CH0_RUPTCNTR_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH0_RUPTCNTR_ADDR = uvm_reg_field("TEST_CH0_RUPTCNTR_ADDR")

    def build(self):
        self.TEST_CH0_RUPTCNTR_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh1RuptcntrAddr(uvm_reg):
    """TEST_CH1_RUPTCNTR_ADDR"""

    def __init__(self, name="TEST_CH1_RUPTCNTR_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH1_RUPTCNTR_ADDR = uvm_reg_field("TEST_CH1_RUPTCNTR_ADDR")

    def build(self):
        self.TEST_CH1_RUPTCNTR_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh2RuptcntrAddr(uvm_reg):
    """TEST_CH2_RUPTCNTR_ADDR"""

    def __init__(self, name="TEST_CH2_RUPTCNTR_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH2_RUPTCNTR_ADDR = uvm_reg_field("TEST_CH2_RUPTCNTR_ADDR")

    def build(self):
        self.TEST_CH2_RUPTCNTR_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestCh3RuptcntrAddr(uvm_reg):
    """TEST_CH3_RUPTCNTR_ADDR"""

    def __init__(self, name="TEST_CH3_RUPTCNTR_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_CH3_RUPTCNTR_ADDR = uvm_reg_field("TEST_CH3_RUPTCNTR_ADDR")

    def build(self):
        self.TEST_CH3_RUPTCNTR_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestInterruptMaskAddr(uvm_reg):
    """TEST_INTERRUPT_MASK_ADDR"""

    def __init__(self, name="TEST_INTERRUPT_MASK_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_INTERRUPT_MASK_ADDR = uvm_reg_field("TEST_INTERRUPT_MASK_ADDR")

    def build(self):
        self.TEST_INTERRUPT_MASK_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestInterruptClrAddr(uvm_reg):
    """TEST_INTERRUPT_CLR_ADDR"""

    def __init__(self, name="TEST_INTERRUPT_CLR_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_INTERRUPT_CLR_ADDR = uvm_reg_field("TEST_INTERRUPT_CLR_ADDR")

    def build(self):
        self.TEST_INTERRUPT_CLR_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


class TestInterruptStateAddr(uvm_reg):
    """TEST_INTERRUPT_STATE_ADDR"""

    def __init__(self, name="TEST_INTERRUPT_STATE_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_INTERRUPT_STATE_ADDR = uvm_reg_field("TEST_INTERRUPT_STATE_ADDR")

    def build(self):
        self.TEST_INTERRUPT_STATE_ADDR.configure(self, size=32, lsb_pos=0, access="RO", is_volatile=True, reset=0x0)
        self._set_lock()


class TestDumpAddr(uvm_reg):
    """TEST_DUMP_ADDR"""

    def __init__(self, name="TEST_DUMP_ADDR", reg_width=32):
        super().__init__(name, reg_width)
        self.TEST_DUMP_ADDR = uvm_reg_field("TEST_DUMP_ADDR")

    def build(self):
        self.TEST_DUMP_ADDR.configure(self, size=32, lsb_pos=0, access="RW", is_volatile=False, reset=0x0)
        self._set_lock()


# ============================================================================
# Register Block Classes
# ============================================================================

class DesignOne(uvm_reg_block):
    """design_one — register block (default base 0xA00C0000)."""

    def __init__(self, name="design_one"):
        super().__init__(name)
        self.def_map = None

    def build(self, base_address=0xA00C0000):
        """Create the register map and add all registers."""
        self.def_map = uvm_reg_map("def_map")
        self.def_map.configure(self, base_address)
        self.default_map = self.def_map

        self.def_map.test_ctrl_addr_reg = TestCtrlAddr("test_ctrl_addr_reg")
        self.def_map.test_ctrl_addr_reg.configure(self, hex(base_address + 0x0), "", False, False)
        self.def_map.add_reg(self.def_map.test_ctrl_addr_reg, "0", "RW")

        self.def_map.test_sts_addr_reg = TestStsAddr("test_sts_addr_reg")
        self.def_map.test_sts_addr_reg.configure(self, hex(base_address + 0x10), "", False, False)
        self.def_map.add_reg(self.def_map.test_sts_addr_reg, "0", "RO")

        self.def_map.test_ruptcnt_addr_reg = TestRuptcntAddr("test_ruptcnt_addr_reg")
        self.def_map.test_ruptcnt_addr_reg.configure(self, hex(base_address + 0x14), "", False, False)
        self.def_map.add_reg(self.def_map.test_ruptcnt_addr_reg, "0", "RW")

        self.def_map.test_ch0_en_addr_reg = TestCh0EnAddr("test_ch0_en_addr_reg")
        self.def_map.test_ch0_en_addr_reg.configure(self, hex(base_address + 0x20), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch0_en_addr_reg, "0", "RW")

        self.def_map.test_ch0_ddr_addr_reg = TestCh0DdrAddr("test_ch0_ddr_addr_reg")
        self.def_map.test_ch0_ddr_addr_reg.configure(self, hex(base_address + 0x24), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch0_ddr_addr_reg, "0", "RW")

        self.def_map.test_ch0_pkt_addr_reg = TestCh0PktAddr("test_ch0_pkt_addr_reg")
        self.def_map.test_ch0_pkt_addr_reg.configure(self, hex(base_address + 0x28), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch0_pkt_addr_reg, "0", "RW")

        self.def_map.test_ch0_buf_addr_reg = TestCh0BufAddr("test_ch0_buf_addr_reg")
        self.def_map.test_ch0_buf_addr_reg.configure(self, hex(base_address + 0x2c), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch0_buf_addr_reg, "0", "RW")

        self.def_map.test_ch0_sts_addr_reg = TestCh0StsAddr("test_ch0_sts_addr_reg")
        self.def_map.test_ch0_sts_addr_reg.configure(self, hex(base_address + 0x30), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch0_sts_addr_reg, "0", "RO")

        self.def_map.test_ch0_wrp_addr_reg = TestCh0WrpAddr("test_ch0_wrp_addr_reg")
        self.def_map.test_ch0_wrp_addr_reg.configure(self, hex(base_address + 0x34), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch0_wrp_addr_reg, "0", "RO")

        self.def_map.test_ch0_mfifo_addr_reg = TestCh0MfifoAddr("test_ch0_mfifo_addr_reg")
        self.def_map.test_ch0_mfifo_addr_reg.configure(self, hex(base_address + 0x38), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch0_mfifo_addr_reg, "0", "RO")

        self.def_map.test_ch0_ififo_addr_reg = TestCh0IfifoAddr("test_ch0_ififo_addr_reg")
        self.def_map.test_ch0_ififo_addr_reg.configure(self, hex(base_address + 0x3c), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch0_ififo_addr_reg, "0", "RO")

        self.def_map.test_ch1_en_addr_reg = TestCh1EnAddr("test_ch1_en_addr_reg")
        self.def_map.test_ch1_en_addr_reg.configure(self, hex(base_address + 0x40), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch1_en_addr_reg, "0", "RW")

        self.def_map.test_ch1_ddr_addr_reg = TestCh1DdrAddr("test_ch1_ddr_addr_reg")
        self.def_map.test_ch1_ddr_addr_reg.configure(self, hex(base_address + 0x44), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch1_ddr_addr_reg, "0", "RW")

        self.def_map.test_ch1_pkt_addr_reg = TestCh1PktAddr("test_ch1_pkt_addr_reg")
        self.def_map.test_ch1_pkt_addr_reg.configure(self, hex(base_address + 0x48), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch1_pkt_addr_reg, "0", "RW")

        self.def_map.test_ch1_buf_addr_reg = TestCh1BufAddr("test_ch1_buf_addr_reg")
        self.def_map.test_ch1_buf_addr_reg.configure(self, hex(base_address + 0x4c), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch1_buf_addr_reg, "0", "RW")

        self.def_map.test_ch1_sts_addr_reg = TestCh1StsAddr("test_ch1_sts_addr_reg")
        self.def_map.test_ch1_sts_addr_reg.configure(self, hex(base_address + 0x50), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch1_sts_addr_reg, "0", "RO")

        self.def_map.test_ch1_wrp_addr_reg = TestCh1WrpAddr("test_ch1_wrp_addr_reg")
        self.def_map.test_ch1_wrp_addr_reg.configure(self, hex(base_address + 0x54), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch1_wrp_addr_reg, "0", "RO")

        self.def_map.test_ch1_mfifo_addr_reg = TestCh1MfifoAddr("test_ch1_mfifo_addr_reg")
        self.def_map.test_ch1_mfifo_addr_reg.configure(self, hex(base_address + 0x58), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch1_mfifo_addr_reg, "0", "RO")

        self.def_map.test_ch1_ififo_addr_reg = TestCh1IfifoAddr("test_ch1_ififo_addr_reg")
        self.def_map.test_ch1_ififo_addr_reg.configure(self, hex(base_address + 0x5c), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch1_ififo_addr_reg, "0", "RO")

        self.def_map.test_ch2_en_addr_reg = TestCh2EnAddr("test_ch2_en_addr_reg")
        self.def_map.test_ch2_en_addr_reg.configure(self, hex(base_address + 0x60), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch2_en_addr_reg, "0", "RW")

        self.def_map.test_ch2_ddr_addr_reg = TestCh2DdrAddr("test_ch2_ddr_addr_reg")
        self.def_map.test_ch2_ddr_addr_reg.configure(self, hex(base_address + 0x64), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch2_ddr_addr_reg, "0", "RW")

        self.def_map.test_ch2_pkt_addr_reg = TestCh2PktAddr("test_ch2_pkt_addr_reg")
        self.def_map.test_ch2_pkt_addr_reg.configure(self, hex(base_address + 0x68), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch2_pkt_addr_reg, "0", "RW")

        self.def_map.test_ch2_buf_addr_reg = TestCh2BufAddr("test_ch2_buf_addr_reg")
        self.def_map.test_ch2_buf_addr_reg.configure(self, hex(base_address + 0x6c), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch2_buf_addr_reg, "0", "RW")

        logger.info(
            f"DesignOne build completed — def_map ({hex(base_address)}), 23 registers")


class DesignTwo(uvm_reg_block):
    """design_two — register block (default base 0xA00C0080)."""

    def __init__(self, name="design_two"):
        super().__init__(name)
        self.def_map = None

    def build(self, base_address=0xA00C0080):
        """Create the register map and add all registers."""
        self.def_map = uvm_reg_map("def_map")
        self.def_map.configure(self, base_address)
        self.default_map = self.def_map

        self.def_map.test_ch2_sts_addr_reg = TestCh2StsAddr("test_ch2_sts_addr_reg")
        self.def_map.test_ch2_sts_addr_reg.configure(self, hex(base_address + 0x70), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch2_sts_addr_reg, "0", "RO")

        self.def_map.test_ch2_wrp_addr_reg = TestCh2WrpAddr("test_ch2_wrp_addr_reg")
        self.def_map.test_ch2_wrp_addr_reg.configure(self, hex(base_address + 0x74), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch2_wrp_addr_reg, "0", "RO")

        self.def_map.test_ch2_mfifo_addr_reg = TestCh2MfifoAddr("test_ch2_mfifo_addr_reg")
        self.def_map.test_ch2_mfifo_addr_reg.configure(self, hex(base_address + 0x78), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch2_mfifo_addr_reg, "0", "RO")

        self.def_map.test_ch2_ififo_addr_reg = TestCh2IfifoAddr("test_ch2_ififo_addr_reg")
        self.def_map.test_ch2_ififo_addr_reg.configure(self, hex(base_address + 0x7c), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch2_ififo_addr_reg, "0", "RO")

        self.def_map.test_ch3_en_addr_reg = TestCh3EnAddr("test_ch3_en_addr_reg")
        self.def_map.test_ch3_en_addr_reg.configure(self, hex(base_address + 0x80), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch3_en_addr_reg, "0", "RW")

        self.def_map.test_ch3_ddr_addr_reg = TestCh3DdrAddr("test_ch3_ddr_addr_reg")
        self.def_map.test_ch3_ddr_addr_reg.configure(self, hex(base_address + 0x84), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch3_ddr_addr_reg, "0", "RW")

        self.def_map.test_ch3_pkt_addr_reg = TestCh3PktAddr("test_ch3_pkt_addr_reg")
        self.def_map.test_ch3_pkt_addr_reg.configure(self, hex(base_address + 0x88), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch3_pkt_addr_reg, "0", "RW")

        self.def_map.test_ch3_buf_addr_reg = TestCh3BufAddr("test_ch3_buf_addr_reg")
        self.def_map.test_ch3_buf_addr_reg.configure(self, hex(base_address + 0x8c), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch3_buf_addr_reg, "0", "RW")

        self.def_map.test_ch3_sts_addr_reg = TestCh3StsAddr("test_ch3_sts_addr_reg")
        self.def_map.test_ch3_sts_addr_reg.configure(self, hex(base_address + 0x90), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch3_sts_addr_reg, "0", "RO")

        self.def_map.test_ch3_wrp_addr_reg = TestCh3WrpAddr("test_ch3_wrp_addr_reg")
        self.def_map.test_ch3_wrp_addr_reg.configure(self, hex(base_address + 0x94), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch3_wrp_addr_reg, "0", "RO")

        self.def_map.test_ch3_mfifo_addr_reg = TestCh3MfifoAddr("test_ch3_mfifo_addr_reg")
        self.def_map.test_ch3_mfifo_addr_reg.configure(self, hex(base_address + 0x98), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch3_mfifo_addr_reg, "0", "RO")

        self.def_map.test_ch3_ififo_addr_reg = TestCh3IfifoAddr("test_ch3_ififo_addr_reg")
        self.def_map.test_ch3_ififo_addr_reg.configure(self, hex(base_address + 0x9c), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch3_ififo_addr_reg, "0", "RO")

        self.def_map.test_inp_fmt_ctrl0_addr_reg = TestInpFmtCtrl0Addr("test_inp_fmt_ctrl0_addr_reg")
        self.def_map.test_inp_fmt_ctrl0_addr_reg.configure(self, hex(base_address + 0xa0), "", False, False)
        self.def_map.add_reg(self.def_map.test_inp_fmt_ctrl0_addr_reg, "0", "RW")

        self.def_map.test_inp_fmt_ctrl1_addr_reg = TestInpFmtCtrl1Addr("test_inp_fmt_ctrl1_addr_reg")
        self.def_map.test_inp_fmt_ctrl1_addr_reg.configure(self, hex(base_address + 0xa4), "", False, False)
        self.def_map.add_reg(self.def_map.test_inp_fmt_ctrl1_addr_reg, "0", "RW")

        self.def_map.test_lclpulse_ctrl_addr_reg = TestLclpulseCtrlAddr("test_lclpulse_ctrl_addr_reg")
        self.def_map.test_lclpulse_ctrl_addr_reg.configure(self, hex(base_address + 0xa8), "", False, False)
        self.def_map.add_reg(self.def_map.test_lclpulse_ctrl_addr_reg, "0", "RW")

        self.def_map.test_lclpulse_rdata_addr_reg = TestLclpulseRdataAddr("test_lclpulse_rdata_addr_reg")
        self.def_map.test_lclpulse_rdata_addr_reg.configure(self, hex(base_address + 0xac), "", False, False)
        self.def_map.add_reg(self.def_map.test_lclpulse_rdata_addr_reg, "0", "RO")

        self.def_map.advci2_data_replay_ctrl_addr_reg = Advci2DataReplayCtrlAddr("advci2_data_replay_ctrl_addr_reg")
        self.def_map.advci2_data_replay_ctrl_addr_reg.configure(self, hex(base_address + 0xb0), "", False, False)
        self.def_map.add_reg(self.def_map.advci2_data_replay_ctrl_addr_reg, "0", "RW")

        self.def_map.advci2_data_replay_sts_addr_reg = Advci2DataReplayStsAddr("advci2_data_replay_sts_addr_reg")
        self.def_map.advci2_data_replay_sts_addr_reg.configure(self, hex(base_address + 0xb4), "", False, False)
        self.def_map.add_reg(self.def_map.advci2_data_replay_sts_addr_reg, "0", "RO")

        self.def_map.advci2_data_replay_txfr_length_addr_reg = Advci2DataReplayTxfrLengthAddr("advci2_data_replay_txfr_length_addr_reg")
        self.def_map.advci2_data_replay_txfr_length_addr_reg.configure(self, hex(base_address + 0xb8), "", False, False)
        self.def_map.add_reg(self.def_map.advci2_data_replay_txfr_length_addr_reg, "0", "RW")

        self.def_map.test_lclpulse_bufr_length_addr_reg = TestLclpulseBufrLengthAddr("test_lclpulse_bufr_length_addr_reg")
        self.def_map.test_lclpulse_bufr_length_addr_reg.configure(self, hex(base_address + 0xc0), "", False, False)
        self.def_map.add_reg(self.def_map.test_lclpulse_bufr_length_addr_reg, "0", "RW")

        self.def_map.test_lclpulse_wdata_addr_reg = TestLclpulseWdataAddr("test_lclpulse_wdata_addr_reg")
        self.def_map.test_lclpulse_wdata_addr_reg.configure(self, hex(base_address + 0xc4), "", False, False)
        self.def_map.add_reg(self.def_map.test_lclpulse_wdata_addr_reg, "0", "RW")

        self.def_map.test_lclpulse_cex_pos_cnts_addr_reg = TestLclpulseCexPosCntsAddr("test_lclpulse_cex_pos_cnts_addr_reg")
        self.def_map.test_lclpulse_cex_pos_cnts_addr_reg.configure(self, hex(base_address + 0xc8), "", False, False)
        self.def_map.add_reg(self.def_map.test_lclpulse_cex_pos_cnts_addr_reg, "0", "RW")

        self.def_map.test_ch0_ruptcntr_addr_reg = TestCh0RuptcntrAddr("test_ch0_ruptcntr_addr_reg")
        self.def_map.test_ch0_ruptcntr_addr_reg.configure(self, hex(base_address + 0xe0), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch0_ruptcntr_addr_reg, "0", "RO")

        self.def_map.test_ch1_ruptcntr_addr_reg = TestCh1RuptcntrAddr("test_ch1_ruptcntr_addr_reg")
        self.def_map.test_ch1_ruptcntr_addr_reg.configure(self, hex(base_address + 0xe4), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch1_ruptcntr_addr_reg, "0", "RO")

        self.def_map.test_ch2_ruptcntr_addr_reg = TestCh2RuptcntrAddr("test_ch2_ruptcntr_addr_reg")
        self.def_map.test_ch2_ruptcntr_addr_reg.configure(self, hex(base_address + 0xe8), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch2_ruptcntr_addr_reg, "0", "RO")

        self.def_map.test_ch3_ruptcntr_addr_reg = TestCh3RuptcntrAddr("test_ch3_ruptcntr_addr_reg")
        self.def_map.test_ch3_ruptcntr_addr_reg.configure(self, hex(base_address + 0xec), "", False, False)
        self.def_map.add_reg(self.def_map.test_ch3_ruptcntr_addr_reg, "0", "RO")

        self.def_map.test_interrupt_mask_addr_reg = TestInterruptMaskAddr("test_interrupt_mask_addr_reg")
        self.def_map.test_interrupt_mask_addr_reg.configure(self, hex(base_address + 0xf0), "", False, False)
        self.def_map.add_reg(self.def_map.test_interrupt_mask_addr_reg, "0", "RW")

        self.def_map.test_interrupt_clr_addr_reg = TestInterruptClrAddr("test_interrupt_clr_addr_reg")
        self.def_map.test_interrupt_clr_addr_reg.configure(self, hex(base_address + 0xf4), "", False, False)
        self.def_map.add_reg(self.def_map.test_interrupt_clr_addr_reg, "0", "RW")

        self.def_map.test_interrupt_state_addr_reg = TestInterruptStateAddr("test_interrupt_state_addr_reg")
        self.def_map.test_interrupt_state_addr_reg.configure(self, hex(base_address + 0xf8), "", False, False)
        self.def_map.add_reg(self.def_map.test_interrupt_state_addr_reg, "0", "RO")

        self.def_map.test_dump_addr_reg = TestDumpAddr("test_dump_addr_reg")
        self.def_map.test_dump_addr_reg.configure(self, hex(base_address + 0xfc), "", False, False)
        self.def_map.add_reg(self.def_map.test_dump_addr_reg, "0", "RW")

        logger.info(
            f"DesignTwo build completed — def_map ({hex(base_address)}), 30 registers")


# ============================================================================
# Top-Level Container Class
# ============================================================================

class ProjectTestTop:
    """
    Top-level RAL container — holds one uvm_reg_block per hardware module.
    get_all_maps() and set_sequencer_adapter() discover sub-blocks automatically
    via Python introspection; no changes needed elsewhere when a new block is added.
    """

    def __init__(self, name="PROJECT_TEST_top"):
        self.name = name
        self.design_u1 = DesignOne("design_u1")
        self.design_u2 = DesignTwo("design_u2")

    def build(self):
        self.design_u1.build(base_address=0xA00C0000)
        self.design_u2.build(base_address=0xA00C0080)

    def get_all_maps(self):
        """Return default_map of every uvm_reg_block attribute."""
        return [
            getattr(self, attr).default_map
            for attr in vars(self)
            if isinstance(getattr(self, attr), uvm_reg_block)
        ]

    def set_sequencer_adapter(self, seqr, adp):
        """Wire adapter+sequencer on every sub-block map — call once from connect_phase."""
        for m in self.get_all_maps():
            m.set_sequencer(seqr)
            m.set_adapter(adp)
