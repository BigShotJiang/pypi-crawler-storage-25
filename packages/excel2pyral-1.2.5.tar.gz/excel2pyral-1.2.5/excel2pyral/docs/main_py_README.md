# main.py - Command Line Interface Documentation

## Overview

The `main.py` module provides the primary command-line interface for the excel2pyral tool, offering two main commands:
- **`pyral`** - Complete Excel to PyUVM RAL conversion with SystemRDL intermediate step
- **`genrdl`** - Excel to SystemRDL conversion with built-in validation

## Architecture

### Core Components

```python
# Main converter components
from . import ExcelToPyRALConverter, ExcelToSystemRDLImporter, SystemRDLCompiler, ExcelEditorGUI
```

- **ExcelToPyRALConverter**: Orchestrates the complete Excel → SystemRDL → PyUVM RAL pipeline
- **ExcelToSystemRDLImporter**: Handles Excel parsing and SystemRDL code generation
- **SystemRDLCompiler**: Validates and compiles SystemRDL files
- **ExcelEditorGUI**: Provides Excel editing interface

### Command Structure

The module implements two separate CLI parsers:
1. `create_parser()` - For the `pyral` command (full conversion)
2. `create_genrdl_parser()` - For the `genrdl` command (SystemRDL only)

## Features

### 🔧 Priority-Based Top Name Logic

The tool determines the top-level addrmap name using priority logic:

```python
# 1. If -t/--top-name explicitly provided, use it
# 2. If -s specified (selective submodules), use "{submodules}_top"  
# 3. If no -s (all submodules), use filename without extension
```

### 🎯 Selective Submodule Processing

Use the `-s/--submodules` flag to process specific submodules:

```bash
# Process only specific submodules
pyral file.xlsx -s design_one design_two
```

### 📁 Individual File Generation

Use the `-i/--individual` flag with multiple submodules to generate separate files:

```bash
# Generate individual files for each submodule
pyral file.xlsx -s design_one design_two -i
# Results in: design_one.rdl, design_one_ral.py, design_two.rdl, design_two_ral.py
```

### 📝 Excel Editor Integration

Built-in Excel editor for quick modifications:

```bash
# Open Excel editor (standalone action)
pyral file.xlsx -e
```

## Command Reference

### pyral Command

```bash
pyral [-h] [--version] [-o OUTPUT] [-r] [-t TOP_NAME] [--package-name PACKAGE_NAME]
      [--enhanced-classes] [--hierarchy-sheet HIERARCHY_SHEET]
      [--default-sheet DEFAULT_SHEET] [-s SUBMODULES [SUBMODULES ...]] [-i] 
      [-e] [-v] [-q] excel_file
```

#### Key Arguments

| Argument | Description | Default |
|----------|-------------|---------|
| `excel_file` | Path to Excel file with register specifications | Required |
| `-o, --output` | Output directory for generated files | `output` |
| `-r, --keep-rdl` | Keep intermediate SystemRDL file | `False` |
| `-t, --top-name` | Override top-level addrmap name | Auto-determined |
| `-s, --submodules` | Specific sheet names to process | All sheets |
| `-i, --individual` | Generate separate files for each submodule | `False` |
| `-e, --edit` | Open Excel file for editing | `False` |
| `-v, --verbose` | Enable verbose output | `False` |
| `-q, --quiet` | Suppress all output except errors | `False` |

### genrdl Command

```bash
genrdl [-h] [--version] [-o OUTPUT] [-t TOP_NAME] [--hierarchy-sheet HIERARCHY_SHEET]
       [--default-sheet DEFAULT_SHEET] [-s SUBMODULES [SUBMODULES ...]] [-i]
       [-v] [-q] [-e] excel_file
```

Similar to `pyral` but only generates SystemRDL files with validation.

## Code Structure

### 1. Argument Parsing and Validation

```python
def validate_args(args):
    """Validate command line arguments."""
    # Check file existence and extension
    if not os.path.exists(args.excel_file):
        return f"Excel file not found: {args.excel_file}"
    
    if not args.excel_file.lower().endswith(('.xlsx', '.xls')):
        return f"Excel file must have .xlsx or .xls extension: {args.excel_file}"
```

### 2. Excel Editor Integration

```python
# Handle edit flag - standalone action
if args.edit:
    import tkinter as tk
    root = tk.Tk()
    editor = ExcelEditorGUI(root, args.excel_file)
    root.mainloop()
    sys.exit(0)  # Exit after editing
```

### 3. Individual File Generation Logic

```python
if args.individual and args.submodules and len(args.submodules) > 1:
    # Generate separate files for each submodule
    for submodule in args.submodules:
        # Use unique top name to avoid SystemRDL conflicts
        individual_top_name = args.top_name if args.top_name else f"{submodule}_top"
        
        # Process each submodule separately
        result = converter.convert(
            excel_file=args.excel_file,
            submodule_sheets=[submodule],  # Only this submodule
            top_name=individual_top_name
        )
        
        # Rename files to clean names
        old_rdl = result['systemrdl_file']
        new_rdl = os.path.join(args.output, f"{submodule}.rdl")
        shutil.move(old_rdl, new_rdl)
```

### 4. Error Handling

The module implements comprehensive error handling with specific exit codes:

| Exit Code | Meaning |
|-----------|---------|
| 1 | Argument validation error |
| 2 | File not found |
| 3 | Conversion/generation error |
| 4 | Unexpected error |
| 130 | User interrupt (Ctrl+C) |

## Usage Examples

### Basic Conversion

```bash
# Convert entire Excel file to PyUVM RAL
pyral registers.xlsx

# Keep SystemRDL intermediate file
pyral registers.xlsx --keep-rdl

# Specify custom output directory
pyral registers.xlsx -o my_output/
```

### Selective Processing

```bash
# Process only specific submodules
pyral registers.xlsx -s CPU_Regs Memory_Regs

# Generate individual files for each submodule
pyral registers.xlsx -s CPU_Regs Memory_Regs -i

# Custom top name for selective processing
pyral registers.xlsx -s CPU_Regs -t my_cpu_top
```

### SystemRDL Only

```bash
# Generate and validate SystemRDL only
genrdl registers.xlsx

# Individual SystemRDL files
genrdl registers.xlsx -s design_one design_two -i
```

### Excel Editing

```bash
# Open Excel editor (standalone)
pyral registers.xlsx -e
genrdl registers.xlsx -e
```

### Advanced Configuration

```bash
# Custom sheet names and verbose output
pyral registers.xlsx \
  --hierarchy-sheet Submodules \
  --default-sheet defaults \
  --verbose

# Quiet mode with custom package name
pyral registers.xlsx \
  --package-name my_ral_pkg \
  --quiet
```

## Implementation Notes

### Naming Conflict Resolution

When using individual mode (`-i`), the tool:
1. Uses `{submodule}_top` as internal SystemRDL top name to avoid conflicts
2. Generates files with complex names initially
3. Renames to clean names (`submodule.rdl`, `submodule_ral.py`)

### File Management

```python
# Create output directory
os.makedirs(args.output, exist_ok=True)

# File renaming for clean individual mode
if old_rdl != new_rdl and os.path.exists(old_rdl):
    import shutil
    shutil.move(old_rdl, new_rdl)
```

### Verbose and Quiet Modes

```python
# Configure logging based on verbosity
if args.quiet:
    logging.getLogger().setLevel(logging.ERROR)
elif args.verbose:
    logging.getLogger().setLevel(logging.DEBUG)
```

## Dependencies

- **argparse**: Command-line argument parsing
- **os**: File system operations
- **sys**: System-specific parameters and exit codes
- **pathlib**: Object-oriented filesystem paths
- **tkinter**: GUI toolkit for Excel editor
- **shutil**: High-level file operations

## Error Scenarios

### Common Issues

1. **Missing Excel File**: File path doesn't exist
2. **Invalid Extension**: Not `.xlsx` or `.xls`
3. **Missing Sheets**: Required hierarchy or submodule sheets not found
4. **SystemRDL Conflicts**: Naming conflicts in individual mode (automatically resolved)
5. **GUI Errors**: Display issues when running Excel editor without X11

### Debugging

Use verbose mode for detailed debugging information:

```bash
pyral registers.xlsx -v
```

This enables:
- SystemRDL compilation details
- Step-by-step processing information
- Stack traces for errors

## Integration with Other Modules

The CLI module integrates with:
- **excel_importer.py**: Excel parsing and SystemRDL generation
- **systemrdl_compiler.py**: SystemRDL validation and compilation
- **pyuvm_generator.py**: PyUVM RAL model generation
- **excel_editor.py**: GUI Excel editing functionality

## Future Enhancements

Potential improvements:
- Configuration file support
- Batch processing capabilities
- Plugin system for custom generators
- Web-based interface option