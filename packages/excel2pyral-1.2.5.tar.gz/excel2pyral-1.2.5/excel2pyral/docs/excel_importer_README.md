# excel_importer.py - Excel to SystemRDL Converter Documentation

## Overview

The `excel_importer.py` module is the core engine that converts Excel register specifications into SystemRDL source code. It handles Excel parsing, data validation, hierarchy management, and SystemRDL code generation with comprehensive error checking and flexible configuration options.

## Architecture

### Core Class: ExcelToSystemRDLImporter

```python
class ExcelToSystemRDLImporter:
    """
    Converts Excel register specifications into SystemRDL source code.
    
    The Excel file should contain:
    - A 'Submodules' sheet with submodule hierarchy
    - A 'default' sheet with default properties (optional)  
    - One sheet per submodule containing register/field definitions
    """
```

### Key Dependencies

```python
import pandas as pd  # Excel file parsing and DataFrame operations
import os           # File path operations
import re           # Regular expression for field bits parsing
```

## Features

### 🔍 Comprehensive Validation

The module implements robust validation with the `_validate_sheets_in_hierarchy()` helper function:

```python
def _validate_sheets_in_hierarchy(self, sheets: list, available_submodules: list, 
                                hierarchy_sheet: str, context: str = "sheets") -> None:
    """
    Validate that all specified sheets have corresponding entries in the hierarchy sheet.
    """
```

**Validation Scenarios:**
- **Sheet-Hierarchy Consistency**: All register sheets must have hierarchy entries
- **Requested Submodules**: User-specified submodules must exist in hierarchy
- **Missing Sheets**: Comprehensive error messages for missing components

### 📊 Flexible Field Bits Parsing

Supports multiple field bit specification formats:

```python
def parse_field_bits(self, bits: str) -> Tuple[Optional[int], Optional[int], int]:
    """Parse field bits from Excel format like [7:0], [3:3], or just "8"."""
```

**Supported Formats:**
- `[7:0]` - MSB:LSB range format
- `[3]` - Single bit format  
- `8` - Width-only format (auto-positioned)

### 🎯 Priority-Based Top Name Logic

Implements intelligent naming strategy based on usage context:

```python
# Priority logic for top_name:
# 1. If top_name explicitly provided, use it
# 2. If submodule_sheets specified (selective), use "{submodules}_top"
# 3. If no submodule_sheets (all), use filename
if top_name is None:
    if submodule_sheets is not None:
        submodule_names = "_".join(submodule_sheets)
        top_name = f"{submodule_names}_top"
    else:
        top_name = os.path.splitext(os.path.basename(excel_file))[0]
```

### 📋 Selective Submodule Processing

Supports filtering submodules based on user selection:

```python
# Filter submodules based on -s selection
if submodule_sheets is not None:
    # Only include this submodule if it's in the specified list
    if name not in submodule_sheets:
        continue
```

## Code Structure Analysis

### 1. Main Entry Point

```python
def excel_to_systemrdl(
    self, 
    excel_file: str, 
    top_name: Optional[str] = None, 
    hierarchy_sheet: str = "Hierarchy",
    default_sheet: str = "default",
    submodule_sheets: Optional[list] = None
) -> str:
```

**Parameters:**
- `excel_file`: Path to Excel file containing register specifications
- `top_name`: Override for top-level addrmap name (None for auto-determination)
- `hierarchy_sheet`: Name of sheet containing submodule hierarchy (default: "Hierarchy")
- `default_sheet`: Name of sheet containing default properties (default: "default")
- `submodule_sheets`: List of specific sheets to process (None for all sheets)

### 2. Excel File Processing

```python
# Load and validate Excel file
try:
    xls = pd.ExcelFile(excel_file)
except Exception as e:
    raise ValueError(f"Cannot read Excel file: {e}")

# Validate required sheets
if hierarchy_sheet not in xls.sheet_names:
    raise ValueError(f"Excel file must have a '{hierarchy_sheet}' sheet for hierarchy")
```

### 3. Default Properties Handling

```python
# Read default values (optional)
if default_sheet in xls.sheet_names:
    default_df = pd.read_excel(xls, sheet_name=default_sheet).fillna("")
    if not default_df.empty:
        first_row = default_df.iloc[0]
        sw_default = str(first_row.get("SW Access", "")).strip() or None
        hw_default = str(first_row.get("HW Access", "")).strip() or None
```

**Supported Default Properties:**
- SW Access (Software access permissions)
- HW Access (Hardware access permissions)  
- Access Width (Data access width)
- Reg Width (Register width)

### 4. Hierarchy Management

```python
# Process submodule hierarchy with filtering
submodules_info = []
for _, row in submodules_df.iterrows():
    name = str(row["Submodule Name"]).strip()
    if not name:
        continue
    
    # Filter submodules based on -s selection
    if submodule_sheets is not None:
        if name not in submodule_sheets:
            continue
            
    instances = [inst.strip() for inst in str(row["Instances"]).split(",") if inst.strip()]
    offsets = [offset.strip() for offset in str(row["Base Addresses"]).split(",") if offset.strip()]
```

**Hierarchy Structure:**
- **Submodule Name**: Name of the register file
- **Instances**: Comma-separated instance names
- **Base Addresses**: Comma-separated base addresses

### 5. Register Processing

```python
# Forward fill to reduce repetition
df['Register Name'] = df['Register Name'].replace("", pd.NA).ffill()
df['Offset'] = df['Offset'].replace("", pd.NA).ffill()

# Process registers grouped by name and offset
grouped = df.groupby(["Register Name", "Offset"], sort=False)

for (reg_name, offset), group in grouped:
    rdl_lines.append(f"    reg {{")
    
    current_bit_pos = 0
    for _, field_row in group.iterrows():
        # Process each field within the register
```

**Required Columns:**
- **Register Name**: Name of the register
- **Offset**: Register offset address
- **Field Name**: Name of the field within register
- **Field Bits**: Bit specification ([7:0], [3], or width)

**Optional Columns:**
- **Field Description**: Field documentation
- **SW Access**: Software access (r, w, rw, etc.)
- **HW Access**: Hardware access (r, w, rw, etc.)
- **Reset Value**: Field or register reset value
- **Behaviour**: SystemRDL behavior properties

## Field Bits Parsing Logic

### Detailed Implementation

```python
def parse_field_bits(self, bits: str) -> Tuple[Optional[int], Optional[int], int]:
    """Parse field bits from Excel format like [7:0], [3:3], or just "8"."""
    bits = str(bits).strip()
    
    # Handle [msb:lsb] format
    m = re.match(r"\[(\d+)\s*:\s*(\d+)\]", bits)
    if m:
        msb = int(m.group(1))
        lsb = int(m.group(2))
        width = abs(msb - lsb) + 1
        return (msb, lsb, width)
    
    # Handle [n] single bit format
    m_single = re.match(r"\[(\d+)\]", bits)
    if m_single:
        bit_pos = int(m_single.group(1))
        return (bit_pos, bit_pos, 1)
    
    # Handle just a number - treat as width
    try:
        width = int(bits)
        return (None, None, width)
    except Exception:
        raise ValueError(f"Unrecognized field bits format: {bits}")
```

### Auto-Positioning Logic

```python
# Auto-assign positions if missing
if msb is None or lsb is None:
    lsb = current_bit_pos
    msb = current_bit_pos + width - 1
    current_bit_pos += width
```

When MSB/LSB are not specified, the system automatically assigns consecutive bit positions.

## SystemRDL Code Generation

### Generated Structure

```systemrdl
// Auto-generated SystemRDL from Excel
// Source: example.xlsx

regfile design_one {
    name = "design_one Register File";
    desc = "Register file description for design_one Factory FPGA";
    
    default accesswidth = 32;
    default regwidth = 32;
    default sw = rw;
    default hw = rw;
    
    reg {
        field {
            name = "field_name";
            desc = "Field description";
            sw = rw;
            hw = r;
            reset = 0x0;
        } field_name[7:0];
    } REGISTER_NAME @ 0x100;
};

addrmap top_name {
    addressing=regalign;
    design_one instance_name @ 0x1000;
};
```

### Field Property Mapping

```python
# Field properties from Excel columns
if field_desc:
    rdl_lines.append(f'            desc = "{field_desc}";')
if sw_access:
    rdl_lines.append(f"            sw = {sw_access};")
if hw_access:
    rdl_lines.append(f"            hw = {hw_access};")
if behav:
    rdl_lines.append(f"            {behav};")
```

### Reset Value Processing

```python
# Smart reset value handling
if reset_value:
    if sw_access == "r" and hw_access == "r":
        # For constant fields, extract from register reset
        reg_reset_int = int(reset_value, 0)
        field_mask = (1 << width) - 1
        field_value = (reg_reset_int >> lsb) & field_mask
        rdl_lines.append(f"            reset = 0x{field_value:X};")
    else:
        # For non-constant fields, use direct value
        rdl_lines.append(f"            reset = {reset_value};")
```

## Validation and Error Handling

### DRY Principle Implementation

The module follows the DRY (Don't Repeat Yourself) principle with the `_validate_sheets_in_hierarchy()` helper:

```python
def _validate_sheets_in_hierarchy(self, sheets: list, available_submodules: list, 
                                hierarchy_sheet: str, context: str = "sheets") -> None:
    """Centralized validation for sheet-hierarchy consistency."""
    missing_sheets = [sheet for sheet in sheets if sheet not in available_submodules]
    if missing_sheets:
        if context == "requested submodules":
            raise ValueError(f"Requested submodules not found in '{hierarchy_sheet}' sheet: {missing_sheets}. "
                           f"Available submodules: {available_submodules}")
        else:
            raise ValueError(f"Found register sheets without corresponding entries in '{hierarchy_sheet}' sheet: "
                           f"{missing_sheets}")
```

### Error Scenarios

1. **File Reading Errors**
   ```python
   except Exception as e:
       raise ValueError(f"Cannot read Excel file: {e}")
   ```

2. **Missing Required Sheets**
   ```python
   if hierarchy_sheet not in xls.sheet_names:
       raise ValueError(f"Excel file must have a '{hierarchy_sheet}' sheet for hierarchy")
   ```

3. **Missing Columns**
   ```python
   missing_columns = [col for col in required_columns if col not in df.columns]
   if missing_columns:
       raise ValueError(f"Sheet '{sheet}' missing required columns: {missing_columns}")
   ```

4. **Invalid Field Bits Format**
   ```python
   except Exception:
       raise ValueError(f"Unrecognized field bits format: {bits}")
   ```

## Data Flow

### Processing Pipeline

```mermaid
graph TD
    A[Excel File] --> B[Load with pandas]
    B --> C[Validate Required Sheets]
    C --> D[Read Default Properties]
    D --> E[Process Hierarchy Sheet]
    E --> F[Filter Submodules if -s specified]
    F --> G[Validate Sheet-Hierarchy Consistency]
    G --> H[Process Each Register Sheet]
    H --> I[Parse Field Bits]
    I --> J[Generate SystemRDL Code]
    J --> K[Create Top-Level Addrmap]
    K --> L[Return Complete SystemRDL]
```

### Data Structures

**Submodule Information:**
```python
submodules_info = [
    (name, instances, offsets),  # Tuple for each submodule
    # name: str - submodule name
    # instances: list - instance names
    # offsets: list - base addresses
]
```

**Field Processing:**
```python
# Per-field data
msb, lsb, width = self.parse_field_bits(field_bits)
field_desc = str(field_row.get("Field Description", "")).strip()
sw_access = str(field_row.get("SW Access", "")).strip()
# ... other properties
```

## Usage Examples

### Basic Usage

```python
importer = ExcelToSystemRDLImporter()

# Convert entire Excel file
systemrdl_code = importer.excel_to_systemrdl(
    excel_file="registers.xlsx"
)
```

### Selective Submodule Processing

```python
# Process only specific submodules
systemrdl_code = importer.excel_to_systemrdl(
    excel_file="registers.xlsx",
    submodule_sheets=["CPU_Regs", "Memory_Regs"]
)
```

### Custom Configuration

```python
# Custom sheet names and top name
systemrdl_code = importer.excel_to_systemrdl(
    excel_file="registers.xlsx",
    top_name="my_chip_top",
    hierarchy_sheet="Submodules", 
    default_sheet="defaults",
    submodule_sheets=["design_one"]
)
```

### Integration with CLI

```python
# Called from main.py
systemrdl_content = importer.excel_to_systemrdl(
    excel_file=args.excel_file,
    top_name=args.top_name,
    hierarchy_sheet=args.hierarchy_sheet,
    default_sheet=args.default_sheet,
    submodule_sheets=args.submodules
)
```

## Performance Considerations

### Memory Optimization

```python
# Efficient DataFrame operations
df['Register Name'] = df['Register Name'].replace("", pd.NA).ffill()

# Process in groups to reduce memory usage
grouped = df.groupby(["Register Name", "Offset"], sort=False)
```

### String Operations

```python
# Efficient string building
rdl_lines = []  # List for O(1) append
# ... build content
return "\n".join(rdl_lines)  # Single join operation
```

## Configuration Options

### Pandas Settings

```python
# Suppress pandas future warnings
pd.set_option('future.no_silent_downcasting', True)
```

### Forward Fill Strategy

```python
# Register-level properties inherit to fields
df['Register Name'] = df['Register Name'].replace("", pd.NA).ffill()
df['Offset'] = df['Offset'].replace("", pd.NA).ffill()
if 'Reset Value' in df.columns:
    df['Reset Value'] = df['Reset Value'].replace("", pd.NA).ffill()
```

## Integration Points

The module integrates with:
- **SystemRDL Compiler**: Generated code is validated
- **PyUVM Generator**: SystemRDL serves as intermediate representation
- **CLI Interface**: Provides core conversion functionality
- **Excel Editor**: Can be used with editor-modified files

## Future Enhancements

Potential improvements:
- **Caching**: Cache parsed Excel data for repeated operations
- **Streaming**: Process large Excel files in chunks
- **Templates**: Customizable SystemRDL output templates
- **Validation**: Enhanced pre-generation validation
- **Performance**: Parallel processing for large files