"""
PyUVM RAL Generator

Generates Python PyUVM Register Abstraction Layer models from compiled SystemRDL.

Output structure matches the reference python_based_ral.py pattern:
  - Each register  -> uvm_reg subclass  (fields in __init__, configured in build())
  - Each regfile   -> uvm_reg_block subclass  (build() uses absolute addresses)
  - Top addrmap    -> plain Python container class  (holds block instances)
"""

from systemrdl.node import RootNode, AddrmapNode, RegNode, FieldNode, RegfileNode, MemNode
from systemrdl import RDLWalker, RDLListener
from systemrdl.rdltypes import AccessType
from typing import Optional, Dict, Any, List
import os
import re
from datetime import datetime

# ---------------------------------------------------------------------------
# Access-type helpers
# ---------------------------------------------------------------------------

_SW_ACCESS_MAP = {
    AccessType.r:   "RO",
    AccessType.w:   "WO",
    AccessType.rw:  "RW",
    AccessType.w1:  "W1",
    AccessType.rw1: "RW1",
    AccessType.na:  "RW",
}

# Hardware write types — if hw can write the field, mark it volatile
_HW_WRITE_TYPES = {AccessType.w, AccessType.rw, AccessType.rw1}


def _to_class_name(name: str) -> str:
    """Convert a SystemRDL identifier to a PythonCamelCase class name."""
    clean = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    return ''.join(part.capitalize() for part in clean.split('_') if part)


# ---------------------------------------------------------------------------
# Generator
# ---------------------------------------------------------------------------

class PyUVMRALGenerator:
    """Generates Python PyUVM RAL models from compiled SystemRDL designs."""

    def __init__(self, **kwargs):
        self.user_template_dir = kwargs.get('user_template_dir', None)
        self.package_name = kwargs.get('package_name', 'generated_ral')
        self.output_file = None

    def generate(
        self,
        root_node: RootNode,
        output_file: str,
        package_name: Optional[str] = None,
        top_name: Optional[str] = None,
        **kwargs
    ) -> None:
        """
        Generate a PyUVM RAL model file from a compiled SystemRDL root node.

        Args:
            root_node:    Compiled SystemRDL root node.
            output_file:  Destination Python file path.
            package_name: Optional package/module name for the header comment.
            top_name:     Optional override for the top-level addrmap name.

        Raises:
            ValueError:         If tree walking or generation fails.
            FileNotFoundError:  If the output directory does not exist.
        """
        try:
            output_dir = os.path.dirname(os.path.abspath(output_file))
            if output_dir and not os.path.exists(output_dir):
                raise FileNotFoundError(f"Output directory does not exist: {output_dir}")

            node = root_node
            if isinstance(node, RootNode):
                if not hasattr(node, 'top') or node.top is None:
                    raise ValueError("Root node does not contain a top-level addrmap")
                node = node.top

            if not isinstance(node, AddrmapNode):
                raise ValueError(f"Expected AddrmapNode, got {type(node)}")

            self.output_file = output_file
            self.package_name = package_name or f"{node.inst_name}_ral"

            # Walk the SystemRDL tree
            walker = PyUVMRALWalker(node)
            RDLWalker(unroll=True, skip_not_present=False).walk(node, walker)

            if walker.top_class is None:
                raise ValueError("Walker did not find a top-level addrmap")
            if not walker.register_classes:
                raise ValueError("Walker found no register classes — check the SystemRDL file")

            # Emit the Python file
            with open(output_file, 'w', encoding='utf-8') as f:
                self._write_header(f)
                self._write_imports(f)
                self._write_register_classes(f, walker.register_classes)
                self._write_block_classes(f, walker.block_classes)
                self._write_top_class(f, walker.top_class, node.inst_name)

            print(f"✅ PyUVM RAL model generated: {output_file}")

        except Exception as e:
            raise ValueError(f"PyUVM RAL generation failed: {e}") from e
    
    # ------------------------------------------------------------------
    # File-level sections
    # ------------------------------------------------------------------

    def _write_header(self, f):
        """Write the file docstring header."""
        f.write(
            f'"""\n'
            f'PyUVM Register Abstraction Layer Model\n\n'
            f'Auto-generated from SystemRDL specification using excel2pyral\n'
            f'Package  : {self.package_name}\n'
            f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n'
            f'"""\n\n'
        )

    def _write_imports(self, f):
        """Write the standard import block."""
        f.write(
            'import logging\n'
            'from pyuvm import uvm_reg, uvm_reg_field, uvm_reg_map\n'
            'from pyuvm import uvm_reg_block\n\n'
            'logger = logging.getLogger(__name__)\n\n\n'
        )


    # ------------------------------------------------------------------
    # Register classes
    # ------------------------------------------------------------------

    def _write_register_classes(self, f, register_classes: Dict[str, Any]):
        f.write(
            '# ' + '=' * 76 + '\n'
            '# Register Classes\n'
            '# ' + '=' * 76 + '\n\n'
        )
        for class_name, reg_info in register_classes.items():
            self._write_one_register_class(f, class_name, reg_info)

    def _write_one_register_class(self, f, class_name: str, reg_info: Dict[str, Any]):
        inst_name = reg_info['inst_name']
        width     = reg_info.get('width', 32)
        desc      = reg_info.get('description') or inst_name
        fields    = reg_info.get('fields', [])

        f.write(f'class {class_name}(uvm_reg):\n')
        f.write(f'    """{desc}"""\n\n')
        f.write(f'    def __init__(self, name="{inst_name}", reg_width={width}):\n')
        f.write( '        super().__init__(name, reg_width)\n')
        for fi in fields:
            f.write(f'        self.{fi["name"]} = uvm_reg_field("{fi["name"]}")\n')

        f.write('\n    def build(self):\n')
        for fi in fields:
            volatile = 'True' if fi['is_volatile'] else 'False'
            reset    = fi.get('reset') or 0
            f.write(
                f'        self.{fi["name"]}.configure('
                f'self, size={fi["width"]}, lsb_pos={fi["lsb"]}, '
                f'access="{fi["access"]}", is_volatile={volatile}, '
                f'reset=0x{reset:X})\n'
            )
        f.write('        self._set_lock()\n\n\n')

    # ------------------------------------------------------------------
    # Block (regfile) classes
    # ------------------------------------------------------------------

    def _write_block_classes(self, f, block_classes: Dict[str, Any]):
        f.write(
            '# ' + '=' * 76 + '\n'
            '# Register Block Classes\n'
            '# ' + '=' * 76 + '\n\n'
        )
        for class_name, block_info in block_classes.items():
            self._write_one_block_class(f, class_name, block_info)

    def _write_one_block_class(self, f, class_name: str, block_info: Dict[str, Any]):
        type_name = block_info['type_name']
        base_addr = block_info['base_address']
        registers = block_info.get('registers', [])

        f.write(f'class {class_name}(uvm_reg_block):\n')
        f.write(f'    """{type_name} \u2014 register block (default base 0x{base_addr:X})."""\n\n')
        f.write(f'    def __init__(self, name="{type_name}"):\n')
        f.write( '        super().__init__(name)\n')
        f.write( '        self.def_map = None\n\n')

        f.write(f'    def build(self, base_address=0x{base_addr:X}):\n')
        f.write( '        """Create the register map and add all registers."""\n')
        f.write( '        self.def_map = uvm_reg_map("def_map")\n')
        f.write( '        self.def_map.configure(self, base_address)\n')
        f.write( '        self.default_map = self.def_map\n\n')

        for reg_info in registers:
            reg_attr   = reg_info['inst_name'].lower() + '_reg'
            reg_class  = reg_info['class_name']
            offset     = reg_info['absolute_address'] - base_addr
            reg_access = reg_info['dominant_access']

            f.write(f'        self.def_map.{reg_attr} = {reg_class}("{reg_attr}")\n')
            f.write(f'        self.def_map.{reg_attr}.configure(self, hex(base_address + 0x{offset:x}), "", False, False)\n')
            f.write(f'        self.def_map.add_reg(self.def_map.{reg_attr}, "0", "{reg_access}")\n\n')

        f.write(
            f'        logger.info(\n'
            f'            f"{class_name} build completed \u2014 '
            f'def_map ({{hex(base_address)}}), {len(registers)} registers")\n\n\n'
        )

    # ------------------------------------------------------------------
    # Top-level container class
    # ------------------------------------------------------------------

    def _write_top_class(self, f, top_class_info: Dict[str, Any], inst_name: str):
        top_class_name = top_class_info['class_name'] + 'Top'
        sub_blocks     = top_class_info.get('sub_blocks', [])

        f.write(
            '# ' + '=' * 76 + '\n'
            '# Top-Level Container Class\n'
            '# ' + '=' * 76 + '\n\n'
        )
        f.write(f'class {top_class_name}:\n')
        f.write(
            '    """\n'
            '    Top-level RAL container \u2014 holds one uvm_reg_block per hardware module.\n'
            '    get_all_maps() and set_sequencer_adapter() discover sub-blocks automatically\n'
            '    via Python introspection; no changes needed elsewhere when a new block is added.\n'
            '    """\n\n'
        )
        f.write(f'    def __init__(self, name="{inst_name}_top"):\n')
        f.write( '        self.name = name\n')
        for sb in sub_blocks:
            f.write(f'        self.{sb["inst_name"]} = {sb["class_name"]}("{sb["inst_name"]}")\n')

        f.write('\n    def build(self):\n')
        for sb in sub_blocks:
            addr = sb.get('base_address')
            if addr is not None:
                f.write(f'        self.{sb["inst_name"]}.build(base_address=0x{addr:X})\n')
            else:
                f.write(f'        self.{sb["inst_name"]}.build()\n')
        if not sub_blocks:
            f.write('        pass\n')

        f.write(
            '\n    def get_all_maps(self):\n'
            '        """Return default_map of every uvm_reg_block attribute."""\n'
            '        return [\n'
            '            getattr(self, attr).default_map\n'
            '            for attr in vars(self)\n'
            '            if isinstance(getattr(self, attr), uvm_reg_block)\n'
            '        ]\n'
            '\n    def set_sequencer_adapter(self, seqr, adp):\n'
            '        """Wire adapter+sequencer on every sub-block map \u2014 call once from connect_phase."""\n'
            '        for m in self.get_all_maps():\n'
            '            m.set_sequencer(seqr)\n'
            '            m.set_adapter(adp)\n'
        )







# ---------------------------------------------------------------------------
# Walker / Listener
# ---------------------------------------------------------------------------

class PyUVMRALWalker(RDLListener):
    """
    Traverses a compiled SystemRDL tree and collects the information needed
    to generate a PyUVM RAL model.

    Handles three node types:
      * AddrmapNode  — top-level container (-> plain Python class)
      * RegfileNode  — hardware register block (-> uvm_reg_block subclass)
      * RegNode      — individual register (-> uvm_reg subclass)
    """

    def __init__(self, top_node: AddrmapNode):
        super().__init__()
        self.top_node         = top_node
        # Ordered dicts: class_name -> info dict
        self.register_classes: Dict[str, Any] = {}
        self.block_classes:    Dict[str, Any] = {}
        self.top_class:        Optional[Dict[str, Any]] = None
        self._block_stack:     List[Dict[str, Any]] = []

    # ------------------------------------------------------------------
    # Addrmap (top-level container)
    # ------------------------------------------------------------------

    def enter_Addrmap(self, node: AddrmapNode):
        info = self._make_block_info(node)
        self._block_stack.append(info)
        if node == self.top_node:
            self.top_class = info

    def exit_Addrmap(self, node: AddrmapNode):
        if not self._block_stack:
            return
        current = self._block_stack.pop()
        if node == self.top_node:
            return  # top class is kept as-is

        # Nested addrmap — treat as a block
        class_name = current['class_name']
        if class_name not in self.block_classes:
            self.block_classes[class_name] = current

        if self._block_stack:
            self._block_stack[-1]['sub_blocks'].append({
                'inst_name': current['inst_name'],
                'class_name': current['class_name'],
            })

    # ------------------------------------------------------------------
    # Regfile (hardware block -> uvm_reg_block subclass)
    # ------------------------------------------------------------------

    def enter_Regfile(self, node: RegfileNode):
        type_name  = node.type_name or node.inst_name
        class_name = _to_class_name(type_name)
        info = {
            'inst_name':    node.inst_name,
            'type_name':    type_name,
            'class_name':   class_name,
            'description':  node.get_property('desc', default=''),
            'base_address': node.absolute_address,
            'registers':    [],
            'sub_blocks':   [],
        }
        self._block_stack.append(info)

    def exit_Regfile(self, node: RegfileNode):
        if not self._block_stack:
            return
        current    = self._block_stack.pop()
        class_name = current['class_name']

        if class_name not in self.block_classes:
            self.block_classes[class_name] = current

        if self._block_stack:
            self._block_stack[-1]['sub_blocks'].append({
                'inst_name':   current['inst_name'],
                'class_name':  current['class_name'],
                'base_address': current['base_address'],
            })

    # ------------------------------------------------------------------
    # Register
    # ------------------------------------------------------------------

    def enter_Reg(self, node: RegNode):
        if not self._block_stack:
            return

        inst_name  = node.inst_name
        class_name = _to_class_name(inst_name)

        # If a class with this name already exists but has different fields,
        # prefix with the parent block name to avoid collision.
        if class_name in self.register_classes:
            parent_type = self._block_stack[-1].get('type_name', '')
            class_name = _to_class_name(parent_type + '_' + inst_name)

        # Collect fields
        fields = []
        for fld in node.fields():
            sw_access  = fld.get_property('sw', default=AccessType.rw)
            hw_access  = fld.get_property('hw', default=AccessType.r)
            reset_val  = fld.get_property('reset', default=0) or 0
            fields.append({
                'name':        fld.inst_name,
                'width':       fld.width,
                'lsb':         fld.lsb,
                'msb':         fld.msb,
                'access':      _SW_ACCESS_MAP.get(sw_access, 'RW'),
                'is_volatile': hw_access in _HW_WRITE_TYPES,
                'reset':       reset_val,
                'description': fld.get_property('desc', default=''),
            })

        # Dominant access for add_reg
        if fields and all(fi['access'] == 'RO' for fi in fields):
            dominant = 'RO'
        elif fields and all(fi['access'] == 'WO' for fi in fields):
            dominant = 'WO'
        else:
            dominant = 'RW'

        reg_info = {
            'inst_name':        inst_name,
            'class_name':       class_name,
            'width':            node.get_property('regwidth', default=32),
            'description':      node.get_property('desc', default='') or inst_name,
            'fields':           fields,
            'dominant_access':  dominant,
            'absolute_address': node.absolute_address,
        }

        if class_name not in self.register_classes:
            self.register_classes[class_name] = reg_info

        self._block_stack[-1]['registers'].append(reg_info)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _make_block_info(self, node: AddrmapNode) -> Dict[str, Any]:
        type_name  = node.type_name or node.inst_name
        class_name = _to_class_name(type_name)
        return {
            'inst_name':    node.inst_name,
            'type_name':    type_name,
            'class_name':   class_name,
            'description':  node.get_property('desc', default=''),
            'base_address': node.absolute_address,
            'registers':    [],
            'sub_blocks':   [],
        }

