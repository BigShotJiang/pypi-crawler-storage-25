"""
Command Line Interface for Excel2PyRAL Converter

This module provides the main CLI entry point for converting Excel register 
specifications to PyUVM RAL models.
"""

import argparse
import sys
import os
import subprocess
from pathlib import Path
from typing import Optional

from . import ExcelToPyRALConverter, ExcelToSystemRDLImporter, SystemRDLCompiler, ExcelEditorGUI, __version__

def create_parser() -> argparse.ArgumentParser:
    """Create and configure the argument parser."""
    parser = argparse.ArgumentParser(
        description="Convert Excel register specifications to PyUVM RAL models",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic conversion
  pyral registers.xlsx
  
  # Specify output directory
  pyral registers.xlsx -o output/
  
  # Keep intermediate SystemRDL file
  pyral registers.xlsx --keep-rdl
  
  # Custom top-level name and package name
  pyral registers.xlsx --top-name chip_top --package-name chip_ral_pkg
  
  # Process only specific submodule sheets
  pyral registers.xlsx --submodules CPU_Regs Memory_Regs
  
  # Open Excel file for editing (standalone action)
  pyral registers.xlsx --edit
  pyral registers.xlsx -e
  
  # Use custom sheet names
  pyral registers.xlsx --hierarchy-sheet Hierarchy --default-sheet defaults

Excel File Format:
  Required sheets:
    - 'Hierarchy': Contains submodule hierarchy with columns:
      * Submodule Name, Instances, Base Addresses
    - One sheet per submodule with register definitions:
      * Register Name, Offset, Field Name, Field Bits, [optional columns]
  
  Optional sheets:
    - 'default': Contains default properties with columns:
      * SW Access, HW Access, Access Width, Reg Width

For more information, visit: https://github.com/SanCodex/excel2pyral
        """
    )
    
    # Version
    parser.add_argument(
        "--version",
        action="version", 
        version=f"excel2pyral {__version__}"
    )
    
    # Input file (required)
    parser.add_argument(
        "excel_file",
        help="Path to Excel file containing register specifications"
    )
    
    # Output options
    output_group = parser.add_argument_group("output options")
    output_group.add_argument(
        "-o", "--output",
        dest="output",
        default="output",
        help="Output directory for generated files (default: output)"
    )
    output_group.add_argument(
        "-r", "--keep-rdl",
        action="store_true",
        help="Keep intermediate SystemRDL file"
    )
    
    # Naming options
    naming_group = parser.add_argument_group("naming options")
    naming_group.add_argument(
        "-t", "--top-name",
        help="Override top-level addrmap name (default: from filename)"
    )
    naming_group.add_argument(
        "--package-name",
        help="Name for generated UVM package (default: {top}_ral)"
    )
    
    # Sheet configuration
    sheet_group = parser.add_argument_group("Excel sheet options")
    sheet_group.add_argument(
        "--hierarchy-sheet",
        default="Hierarchy",
        help="Name of sheet containing submodule hierarchy (default: Hierarchy)"
    )
    sheet_group.add_argument(
        "--default-sheet", 
        default="default",
        help="Name of sheet containing default properties (default: default)"
    )
    sheet_group.add_argument(
        "-s", "--submodules",
        nargs='+',
        help="Specific sheet names to process for register definitions. If not specified, all sheets are processed."
    )
    sheet_group.add_argument(
        "-i", "--individual",
        action="store_true",
        help="Generate separate SystemRDL files for each submodule when using -s with multiple names. Only effective with multiple submodules."
    )
    
    # Edit option
    edit_group = parser.add_argument_group("edit options")
    edit_group.add_argument(
        "-e", "--edit",
        action="store_true",
        help="Open Excel file for editing (standalone action - exits after editing)"
    )
    
    # Verbosity
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    parser.add_argument(
        "-q", "--quiet",
        action="store_true", 
        help="Suppress all output except errors"
    )
    
    return parser

def validate_args(args):
    """Validate command line arguments."""
    # Check Excel file exists
    if not os.path.exists(args.excel_file):
        return f"Excel file not found: {args.excel_file}"
    
    # Check extension
    if not args.excel_file.lower().endswith(('.xlsx', '.xls')):
        return f"Excel file must have .xlsx or .xls extension: {args.excel_file}"
        
    return None

def main():
    """Main entry point for pyral command."""
    parser = create_parser()
    args = parser.parse_args()
    
    # Validate arguments
    error = validate_args(args)
    if error:
        print(f"Error: {error}", file=sys.stderr)
        sys.exit(1)
    
    # Handle edit flag - just call excel_editor.py and exit
    if args.edit:
        if not args.quiet:
            print(f"🔧 Launching Excel editor for: {args.excel_file}")
        
        try:
            # Create Tkinter root window and launch editor
            import tkinter as tk
            root = tk.Tk()
            root.configure(bg='#f0f0f0')
            root.option_add('*Font', 'Arial 9')
            
            # Use the imported ExcelEditorGUI class with proper Tkinter root
            editor = ExcelEditorGUI(root, args.excel_file)
            
            if not args.quiet:
                print("✅ Excel editor launched")
            
            root.mainloop()
        except Exception as e:
            if not args.quiet:
                print(f"❌ Excel editor failed: {e}")
            sys.exit(1)
        
        # Exit after editing - don't continue with PyUVM RAL generation
        sys.exit(0)
    
    # Configure output verbosity  
    if args.quiet:
        import logging
        logging.getLogger().setLevel(logging.ERROR)
    elif args.verbose:
        import logging
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # Create converter with all components
        converter = ExcelToPyRALConverter()
        
        if not args.quiet:
            print(f"🚀 excel2pyral PyUVM RAL Generator v{__version__}")
            print(f"📊 Input: {args.excel_file}")
            print(f"📁 Output: {args.output}")
            if args.keep_rdl:
                print("🔍 Keeping intermediate SystemRDL file")
            print()
            
        # Convert Excel to PyUVM RAL
        if args.individual and args.submodules and len(args.submodules) > 1:
            # Generate individual files for each submodule
            if not args.quiet:
                print(f"🔄 Generating individual files for {len(args.submodules)} submodules...")
            
            results = []
            for submodule in args.submodules:
                if not args.quiet:
                    print(f"📊 Processing submodule: {submodule}")
                
                # Use unique top name to avoid conflicts with regfile names
                individual_top_name = args.top_name if args.top_name else f"{submodule}_top"
                
                result = converter.convert(
                    excel_file=args.excel_file,
                    output=args.output,
                    top_name=individual_top_name,
                    package_name=f"{submodule}_ral" if not args.package_name else f"{args.package_name}_{submodule}",
                    hierarchy_sheet=args.hierarchy_sheet,
                    default_sheet=args.default_sheet,
                    submodule_sheets=[submodule],  # Process only this submodule
                    keep_rdl=args.keep_rdl,
                )
                
                # Rename files to cleaner names for individual mode
                if 'systemrdl_file' in result:
                    old_rdl = result['systemrdl_file']
                    new_rdl = os.path.join(args.output, f"{submodule}.rdl")
                    if old_rdl != new_rdl and os.path.exists(old_rdl):
                        import shutil
                        shutil.move(old_rdl, new_rdl)
                        result['systemrdl_file'] = new_rdl
                
                old_pyuvm = result['pyuvm_file']
                new_pyuvm = os.path.join(args.output, f"{submodule}_ral.py")
                if old_pyuvm != new_pyuvm and os.path.exists(old_pyuvm):
                    import shutil
                    shutil.move(old_pyuvm, new_pyuvm)
                    result['pyuvm_file'] = new_pyuvm
                
                results.append(result)
            
            # Auto-generate SV register interface for each individual RDL
            regif_results = []
            if args.keep_rdl:
                from .sv_regif_generator import SVRegifGenerator
                sv_gen = SVRegifGenerator()
                for submodule, result in zip(args.submodules, results):
                    if 'systemrdl_file' in result:
                        if not args.quiet:
                            print(f"🔧 Generating SV register interface for {result['systemrdl_file']}...")
                        regif_results.append(sv_gen.generate(
                            rdl_file=result['systemrdl_file'],
                            output_dir=args.output,
                            pkg_name=f"regif_{submodule}_pkg",
                        ))

            if not args.quiet:
                print()
                print("📋 Individual Files Summary:")
                print(f"   Excel file:  {args.excel_file}")
                for i, (submodule, result) in enumerate(zip(args.submodules, results), 1):
                    print(f"   {i}. {submodule}:")
                    print(f"      PyUVM RAL:   {result['pyuvm_file']}")
                    if args.keep_rdl:
                        print(f"      SystemRDL:   {result['systemrdl_file']}")
                    if i - 1 < len(regif_results):
                        print(f"      SV Package:  {regif_results[i-1]['pkg_file']}")
                        print(f"      SV Top:      {regif_results[i-1]['top_file']}")
                print(f"   Directory:   {args.output}")
                print()
                print("✅ Individual file generation completed successfully!")
        else:
            # Standard conversion (existing logic)
            result = converter.convert(
                excel_file=args.excel_file,
                output=args.output,
                top_name=args.top_name,  # Pass through the CLI argument directly (None if not specified)
                package_name=args.package_name,
                hierarchy_sheet=args.hierarchy_sheet,
                default_sheet=args.default_sheet,
                submodule_sheets=args.submodules,
                keep_rdl=args.keep_rdl,
            )
            
            # Auto-generate SV register interface when RDL is kept
            regif_result = None
            if args.keep_rdl and 'systemrdl_file' in result:
                from .sv_regif_generator import SVRegifGenerator
                if not args.quiet:
                    print("🔧 Generating SV register interface files...")
                regif_result = SVRegifGenerator().generate(
                    rdl_file=result['systemrdl_file'],
                    output_dir=args.output,
                )

            if not args.quiet:
                print()
                print("📋 Conversion Summary:")
                print(f"   Excel file:  {args.excel_file}")
                print(f"   PyUVM RAL:   {result['pyuvm_file']}")
                if args.keep_rdl:
                    print(f"   SystemRDL:   {result['systemrdl_file']}")
                if regif_result:
                    print(f"   SV Package:  {regif_result['pkg_file']}")
                    print(f"   SV Top:      {regif_result['top_file']}")
                print(f"   Directory:   {args.output}")
                print()
                print("✅ Conversion completed successfully!")
            
    except KeyboardInterrupt:
        if not args.quiet:
            print("\n⚠️  Conversion interrupted by user")
        sys.exit(130)
        
    except FileNotFoundError as e:
        print(f"❌ File not found: {e}", file=sys.stderr)
        sys.exit(2)
        
    except ValueError as e:
        print(f"❌ Conversion error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(3)
    
    except Exception as e:
        print(f"❌ Unexpected error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(4)

def create_genrdl_parser() -> argparse.ArgumentParser:
    """Create and configure the argument parser specifically for genrdl command."""
    parser = argparse.ArgumentParser(
        description="Convert Excel register specifications to SystemRDL with built-in validation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic conversion to SystemRDL (includes validation)
  genrdl registers.xlsx
  
  # Specify output directory
  genrdl registers.xlsx -o output/
  
  # Custom top-level name
  genrdl registers.xlsx --top-name chip_top
  
  # Process only specific submodule sheets
  genrdl registers.xlsx --submodules CPU_Regs Memory_Regs
  
  # Open Excel file for editing (standalone action)
  genrdl registers.xlsx --edit
  genrdl registers.xlsx -e
  
  # Use custom sheet names and show validation details
  genrdl registers.xlsx --hierarchy-sheet Hierarchy --default-sheet defaults -v
        """
    )
    
    # Version
    parser.add_argument(
        "--version",
        action="version", 
        version=f"excel2pyral {__version__}"
    )
    
    # Input file (required)
    parser.add_argument(
        "excel_file",
        help="Path to Excel file containing register specifications"
    )
    
    # Output options
    output_group = parser.add_argument_group("output options")
    output_group.add_argument(
        "-o", "--output",
        dest="output",
        default="output",
        help="Output directory for generated files (default: output)"
    )
    
    # Naming options
    naming_group = parser.add_argument_group("naming options")
    naming_group.add_argument(
        "-t", "--top-name",
        help="Override top-level addrmap name (default: from filename)"
    )
    
    # Sheet configuration
    sheet_group = parser.add_argument_group("Excel sheet options")
    sheet_group.add_argument(
        "--hierarchy-sheet",
        default="Hierarchy",
        help="Name of sheet containing submodule hierarchy (default: Hierarchy)"
    )
    sheet_group.add_argument(
        "--default-sheet", 
        default="default",
        help="Name of sheet containing default properties (default: default)"
    )
    sheet_group.add_argument(
        "-s", "--submodules",
        nargs='+',
        help="Specific sheet names to process for register definitions. If not specified, all sheets are processed."
    )
    sheet_group.add_argument(
        "-i", "--individual",
        action="store_true",
        help="Generate separate SystemRDL files for each submodule when using -s with multiple names. Only effective with multiple submodules."
    )
    
    # Verbosity
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    parser.add_argument(
        "-q", "--quiet",
        action="store_true", 
        help="Suppress all output except errors"
    )
    
    # Edit option
    edit_group = parser.add_argument_group("edit options")
    edit_group.add_argument(
        "-e", "--edit",
        action="store_true",
        help="Open Excel file for editing (standalone action - exits after editing)"
    )
    
    return parser

def genrdl_main():
    """Entry point for genrdl command to generate and validate SystemRDL file."""
    parser = create_genrdl_parser()
    args = parser.parse_args()
    
    # Validate arguments
    error = validate_args(args)
    if error:
        print(f"Error: {error}", file=sys.stderr)
        sys.exit(1)
    
    # Handle edit flag - just call excel_editor.py and exit
    if args.edit:
        if not args.quiet:
            print(f"🔧 Launching Excel editor for: {args.excel_file}")
        
        try:
            # Create Tkinter root window and launch editor
            import tkinter as tk
            root = tk.Tk()
            root.configure(bg='#f0f0f0')
            root.option_add('*Font', 'Arial 9')
            
            # Use the imported ExcelEditorGUI class with proper Tkinter root
            editor = ExcelEditorGUI(root, args.excel_file)
            
            if not args.quiet:
                print("✅ Excel editor launched")
            
            root.mainloop()
        except Exception as e:
            if not args.quiet:
                print(f"❌ Excel editor failed: {e}")
            sys.exit(1)
        
        # Exit after editing - don't continue with SystemRDL generation
        sys.exit(0)
    
    # Configure output verbosity
    if args.quiet:
        import logging
        logging.getLogger().setLevel(logging.ERROR)
    elif args.verbose:
        import logging
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # Create necessary components
        importer = ExcelToSystemRDLImporter()
        compiler = SystemRDLCompiler()
        
        if not args.quiet:
            print(f"🚀 excel2pyral SystemRDL Generator v{__version__}")
            print(f"📊 Input: {args.excel_file}")
            print(f"📁 Output: {args.output}")
            print("🔍 SystemRDL validation enabled")
            print()
        
        # Create output directory
        os.makedirs(args.output, exist_ok=True)
        
        # Convert Excel to SystemRDL
        if args.individual and args.submodules and len(args.submodules) > 1:
            # Generate individual files for each submodule
            if not args.quiet:
                print(f"🔄 Generating individual SystemRDL files for {len(args.submodules)} submodules...")
            
            generated_files = []
            for submodule in args.submodules:
                if not args.quiet:
                    print(f"📊 Processing submodule: {submodule}")
                
                # Use unique top name to avoid conflicts with regfile names
                individual_top_name = args.top_name if args.top_name else f"{submodule}_top"
                
                systemrdl_content = importer.excel_to_systemrdl(
                    excel_file=args.excel_file,
                    top_name=individual_top_name,
                    hierarchy_sheet=args.hierarchy_sheet,
                    default_sheet=args.default_sheet,
                    submodule_sheets=[submodule]  # Process only this submodule
                )
                
                # Use clean filename for individual mode
                rdl_file = os.path.join(args.output, f"{submodule}.rdl")
                
                # Write SystemRDL file
                with open(rdl_file, 'w', encoding='utf-8') as f:
                    f.write(systemrdl_content)
                
                # Validate with SystemRDL compiler
                if not args.quiet:
                    print(f"🔍 Validating {submodule} SystemRDL...")
                compiler.compile(rdl_file)
                if not args.quiet:
                    print(f"✓ {submodule} SystemRDL validation passed")

                generated_files.append(rdl_file)

            # Auto-generate SV register interface for each individual RDL
            from .sv_regif_generator import SVRegifGenerator
            sv_gen = SVRegifGenerator()
            regif_results = []
            for submodule, rdl_file in zip(args.submodules, generated_files):
                if not args.quiet:
                    print(f"🔧 Generating SV register interface for {os.path.basename(rdl_file)}...")
                regif_results.append(sv_gen.generate(
                    rdl_file=rdl_file,
                    output_dir=args.output,
                    pkg_name=f"regif_{submodule}_pkg",
                ))

            if not args.quiet:
                print()
                print("📋 Individual Files Summary:")
                print(f"   Excel file: {args.excel_file}")
                for i, (submodule, rdl_file) in enumerate(zip(args.submodules, generated_files), 1):
                    print(f"   {i}. {submodule}:")
                    print(f"      SystemRDL:  {rdl_file}")
                    if i - 1 < len(regif_results):
                        print(f"      SV Package: {regif_results[i-1]['pkg_file']}")
                        print(f"      SV Top:     {regif_results[i-1]['top_file']}")
                print(f"   Directory:  {args.output}")
                print()
                print("✅ Individual SystemRDL + SV register interface generation completed successfully!")
        else:
            # Standard conversion (existing logic)
            systemrdl_content = importer.excel_to_systemrdl(
                excel_file=args.excel_file,
                top_name=args.top_name,  # Pass through the CLI argument directly (None if not specified)
                hierarchy_sheet=args.hierarchy_sheet,
                default_sheet=args.default_sheet,
                submodule_sheets=args.submodules
            )
            
            # Determine output filename based on top_name logic (same as in excel_importer)
            if args.top_name:
                output_top_name = args.top_name
            elif args.submodules:
                output_top_name = f"{'_'.join(args.submodules)}_top"
            else:
                output_top_name = os.path.splitext(os.path.basename(args.excel_file))[0]
            
            # Write SystemRDL file using the determined top name
            rdl_file = os.path.join(args.output, f"{output_top_name}.rdl")
            with open(rdl_file, 'w', encoding='utf-8') as f:
                f.write(systemrdl_content)
            
            # Always validate with SystemRDL compiler
            if not args.quiet:
                print("\n🔍 Validating SystemRDL...")
            compiler.compile(rdl_file)
            if not args.quiet:
                print("✓ SystemRDL validation passed")

            # Auto-generate SV register interface files
            from .sv_regif_generator import SVRegifGenerator
            if not args.quiet:
                print("🔧 Generating SV register interface files...")
            regif_result = SVRegifGenerator().generate(
                rdl_file=rdl_file,
                output_dir=args.output,
            )

            if not args.quiet:
                print()
                print("📋 Conversion Summary:")
                print(f"   Excel file: {args.excel_file}")
                print(f"   SystemRDL:  {rdl_file}")
                print(f"   SV Package: {regif_result['pkg_file']}")
                print(f"   SV Top:     {regif_result['top_file']}")
                print(f"   Directory:  {args.output}")
                print()
                print("✅ SystemRDL + SV register interface generation completed successfully!")
            
    except KeyboardInterrupt:
        if not args.quiet:
            print("\n⚠️  Generation interrupted by user")
        sys.exit(130)
        
    except FileNotFoundError as e:
        print(f"❌ File not found: {e}", file=sys.stderr)
        sys.exit(2)
        
    except ValueError as e:
        print(f"❌ Generation error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(3)
        
    except Exception as e:
        print(f"❌ Unexpected error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(4)


# ============================================================================
# genregif command — SystemVerilog register interface generator from RDL
# ============================================================================

def create_genregif_parser() -> argparse.ArgumentParser:
    """Create argument parser for the genregif command."""
    parser = argparse.ArgumentParser(
        description="Generate SystemVerilog register interface files from SystemRDL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage — generates regif_pkg.sv and regif_{prefix}_top.sv
  genregif rdl_datacap.rdl

  # Specify output directory
  genregif rdl_datacap.rdl -o rtl/

  # Override struct prefix (default: derived from addrmap name)
  genregif rdl_datacap.rdl --prefix datacap

  # Override SV package name (default: regif_pkg)
  genregif rdl_datacap.rdl --sv-pkg my_reg_pkg

  # Override generated top module name
  genregif rdl_datacap.rdl --module-name regif_dc_top

Output files:
  - regif_pkg.sv          : SV package with {prefix}_reg_in_t / {prefix}_reg_out_t structs
  - regif_{prefix}_top.sv : Glue module bridging peakrdl block to HW signal structs

Classification (based on 'hw' property in RDL):
  hw = w  → status  register → {prefix}_reg_in_t  struct  → hwif_in.REG.field.next
  hw = r  → control register → {prefix}_reg_out_t struct  → hwif_out.REG.field.value
        """
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"excel2pyral {__version__}"
    )

    parser.add_argument(
        "rdl_file",
        help="Path to SystemRDL (.rdl) input file"
    )

    out_group = parser.add_argument_group("output options")
    out_group.add_argument(
        "-o", "--output",
        default="output",
        help="Output directory for generated .sv files (default: output)"
    )

    naming_group = parser.add_argument_group("naming options")
    naming_group.add_argument(
        "--prefix",
        dest="struct_prefix",
        default=None,
        help="Struct/module name prefix (default: derived from addrmap name, "
             "e.g. 'rdl_datacap' → 'datacap')"
    )
    naming_group.add_argument(
        "--module-name",
        dest="top_module_name",
        default=None,
        help="Override generated top module name (default: regif_{prefix}_top)"
    )
    naming_group.add_argument(
        "--sv-pkg",
        dest="pkg_name",
        default="regif_pkg",
        help="SV package name (default: regif_pkg)"
    )
    naming_group.add_argument(
        "--data-width",
        dest="reg_data_width",
        type=int,
        default=None,
        help="Register data width in bits (default: auto-detected from 'default regwidth' in RDL)"
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output"
    )
    parser.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="Suppress all output except errors"
    )

    return parser


def genregif_main():
    """Entry point for genregif command — generate SV register interface from SystemRDL."""
    parser = create_genregif_parser()
    args = parser.parse_args()

    if not os.path.exists(args.rdl_file):
        print(f"❌ RDL file not found: {args.rdl_file}", file=sys.stderr)
        sys.exit(1)

    if not args.rdl_file.lower().endswith(".rdl"):
        print(f"❌ Input must be a .rdl file: {args.rdl_file}", file=sys.stderr)
        sys.exit(1)

    try:
        from .sv_regif_generator import SVRegifGenerator

        if not args.quiet:
            print(f"🚀 excel2pyral SV Register Interface Generator v{__version__}")
            print(f"📄 Input  : {args.rdl_file}")
            print(f"📁 Output : {args.output}")
            print()

        gen = SVRegifGenerator()
        result = gen.generate(
            rdl_file=args.rdl_file,
            output_dir=args.output,
            pkg_name=args.pkg_name,
            top_module_name=args.top_module_name,
            struct_prefix=args.struct_prefix,
            reg_data_width=args.reg_data_width,
        )

        if not args.quiet:
            print("📋 Generation Summary:")
            print(f"   RDL input  : {args.rdl_file}")
            print(f"   SV Package : {result['pkg_file']}")
            print(f"   Top Module : {result['top_file']}")
            print(f"   Directory  : {args.output}")
            print()
            print("✅ SV register interface generation completed!")

    except KeyboardInterrupt:
        if not args.quiet:
            print("\n⚠️  Generation interrupted by user")
        sys.exit(130)

    except FileNotFoundError as e:
        print(f"❌ File not found: {e}", file=sys.stderr)
        sys.exit(2)

    except ValueError as e:
        print(f"❌ Generation error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(3)

    except Exception as e:
        print(f"❌ Unexpected error: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(4)


if __name__ == "__main__":
    main()