"""
SystemVerilog Register Interface Generator

Generates two output files from a SystemRDL input:

1. regif_pkg.sv
   - Contains typedef structs for register HW signals, grouped by direction:
     * {prefix}_reg_in_t  : registers where hw=w  (hardware writes, SW reads = status)
     * {prefix}_reg_out_t : registers where hw=r  (software writes, HW reads = control)

2. regif_{prefix}_top.sv
   - Bridges the peakrdl-generated register block to the structured HW signal interface
   - always_comb block 1: assign hw=w fields → hwif_in.inst.REG.field.next
   - always_comb block 2: extract hwif_out.inst.REG.field.value → hw=r fields

Usage:
    from excel2pyral import SVRegifGenerator

    gen = SVRegifGenerator()
    result = gen.generate("rdl_datacap.rdl", output_dir="output/")
    print(result['pkg_file'], result['top_file'])
"""

import os
from systemrdl import RDLCompiler
from systemrdl.node import AddrmapNode, RegfileNode, RegNode, FieldNode
from systemrdl.rdltypes import AccessType


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _strip_prefix(name, prefixes=("rdl_", "reg_", "regs_")):
    """Strip a common RDL prefix from a name to produce a short module tag."""
    for p in prefixes:
        if name.startswith(p):
            return name[len(p):]
    return name


# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------

class SVRegifGenerator:
    """
    Generates SystemVerilog register interface files from a SystemRDL source.

    The generator analyses hw/sw access properties of every register field and
    produces:
      - A typedef-struct package (regif_pkg.sv) with _reg_in_t / _reg_out_t
      - A glue module (regif_{prefix}_top.sv) with always_comb assignment blocks
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(self,
                 rdl_file,
                 output_dir="output",
                 pkg_name="regif_pkg",
                 top_module_name=None,
                 struct_prefix=None,
                 reg_data_width=None):
        """
        Generate regif_pkg.sv and regif_{prefix}_top.sv from a SystemRDL file.

        Args:
            rdl_file        : Path to input .rdl file
            output_dir      : Directory for generated .sv files
            pkg_name        : SV package name  (default: regif_pkg)
            top_module_name : Override module name (default: regif_{prefix}_top)
            struct_prefix   : Override struct prefix (default: derived from addrmap)
            reg_data_width  : Register data width in bits. If None (default),
                              derived automatically from 'default regwidth' in RDL.

        Returns:
            dict with keys 'pkg_file' and 'top_file' pointing to generated files
        """
        # ---- Parse RDL ----
        rdlc = RDLCompiler()
        rdlc.compile_file(rdl_file)
        root = rdlc.elaborate()

        # ---- Find top addrmap ----
        top = None
        for child in root.children():
            if isinstance(child, AddrmapNode):
                top = child
                break
        if top is None:
            raise ValueError(f"No top addrmap found in {rdl_file}")

        addrmap_name = top.inst_name          # e.g. "rdl_datacap"

        # ---- Derive reg_data_width from RDL 'regwidth' property if not overridden ----
        if reg_data_width is None:
            reg_data_width = self._get_regwidth(top)

        # ---- Derive naming ----
        if struct_prefix is None:
            struct_prefix = _strip_prefix(addrmap_name)   # e.g. "datacap"
            # Strip auto-generated trailing "_top" (e.g. "design_one_top" → "design_one")
            if struct_prefix.endswith("_top"):
                struct_prefix = struct_prefix[:-4]

        if top_module_name is None:
            top_module_name = f"regif_{struct_prefix}_top"

        rdl_module = addrmap_name                          # e.g. "rdl_datacap"
        rdl_pkg    = f"{addrmap_name}_pkg"                 # e.g. "rdl_datacap_pkg"

        # ---- Walk tree: collect instances → registers → fields ----
        instances = self._collect_instances(top)

        os.makedirs(output_dir, exist_ok=True)

        # ---- Write pkg ----
        pkg_file = os.path.join(output_dir, f"{pkg_name}.sv")
        self._write_pkg(pkg_file, instances, struct_prefix,
                        pkg_name, reg_data_width)

        # ---- Write top module ----
        top_file = os.path.join(output_dir, f"{top_module_name}.sv")
        self._write_top(top_file, instances, struct_prefix, pkg_name,
                        top_module_name, rdl_module, rdl_pkg)

        return {"pkg_file": pkg_file, "top_file": top_file}

    # ------------------------------------------------------------------
    # Derive reg width from RDL tree
    # ------------------------------------------------------------------

    @staticmethod
    def _get_regwidth(addrmap_node, default=32):
        """
        Walk the addrmap tree looking for the first RegNode and read its
        'regwidth' property.  Falls back to `default` if none is found.
        This reflects 'default regwidth = N' declared in the regfile.
        """
        from systemrdl.node import RegNode as _RegNode
        def _walk(node):
            for child in node.children():
                if isinstance(child, _RegNode):
                    return child.get_property("regwidth")
                result = _walk(child)
                if result is not None:
                    return result
            return None

        width = _walk(addrmap_node)
        return int(width) if width is not None else default

    # ------------------------------------------------------------------
    # Tree walker
    # ------------------------------------------------------------------

    def _collect_instances(self, addrmap_node):
        """
        Return a list of instances found directly under the top addrmap.

        Each instance dict:
          inst_name : str
          regs      : list of reg dicts
            name       : str
            fields     : list of field dicts
              name     : str
              msb      : int
              lsb      : int
              hw_w     : bool  (True if hw=w or hw=rw → hardware writes this field)
            has_hw_w   : bool  (register has at least one hw=w field)
            has_hw_r   : bool  (register has at least one hw=r/rw field)
        """
        instances = []

        for child in addrmap_node.children():
            if isinstance(child, (RegfileNode, AddrmapNode)):
                regs = self._collect_regs(child)
                instances.append({
                    "inst_name": child.inst_name,
                    "regs": regs,
                })
            elif isinstance(child, RegNode):
                # Registers directly under addrmap — group as a single instance
                if not instances or instances[-1]["inst_name"] == "__direct__":
                    if not instances:
                        instances.append({"inst_name": "__direct__", "regs": []})
                    instances[-1]["regs"].extend(self._collect_regs_from_list([child]))

        return instances

    def _collect_regs(self, node):
        """Recursively collect all RegNodes under a node."""
        regs = []
        for child in node.children():
            if isinstance(child, RegNode):
                regs.extend(self._collect_regs_from_list([child]))
            elif isinstance(child, (RegfileNode, AddrmapNode)):
                regs.extend(self._collect_regs(child))
        return regs

    def _collect_regs_from_list(self, reg_nodes):
        regs = []
        for reg_node in reg_nodes:
            reg_name = reg_node.inst_name
            fields = []
            has_hw_w = False
            has_hw_r = False

            for field in reg_node.children():
                if not isinstance(field, FieldNode):
                    continue
                hw = field.get_property("hw")
                # hw=w or hw=rw means hardware CAN WRITE this field
                is_hw_w = hw in (AccessType.w, AccessType.rw)
                fields.append({
                    "name": field.inst_name,
                    "msb":  field.msb,
                    "lsb":  field.lsb,
                    "hw_w": is_hw_w,
                })
                if is_hw_w:
                    has_hw_w = True
                else:
                    has_hw_r = True

            # Sort fields MSB-first (matches reference coding style)
            fields.sort(key=lambda f: f["msb"], reverse=True)

            regs.append({
                "name":     reg_name,
                "fields":   fields,
                "has_hw_w": has_hw_w,
                "has_hw_r": has_hw_r,
            })
        return regs

    # ------------------------------------------------------------------
    # Classify a register for the pkg struct
    # ------------------------------------------------------------------

    @staticmethod
    def _reg_class(reg):
        """
        'in'    → all/majority fields are hw=w  (status: HW writes → pkg reg_in_t)
        'out'   → all/majority fields are hw=r  (control: SW writes → pkg reg_out_t)
        'mixed' → register has both hw=w and hw=r fields
        """
        if reg["has_hw_w"] and not reg["has_hw_r"]:
            return "in"
        if reg["has_hw_r"] and not reg["has_hw_w"]:
            return "out"
        # Mixed: classify by count
        n_hw_w = sum(1 for f in reg["fields"] if f["hw_w"])
        n_hw_r = len(reg["fields"]) - n_hw_w
        return "in" if n_hw_w >= n_hw_r else "out"

    # ------------------------------------------------------------------
    # regif_pkg.sv writer
    # ------------------------------------------------------------------

    def _write_pkg(self, pkg_file, instances, struct_prefix,
                   pkg_name, reg_data_width):
        """Generate the SV typedef-struct package file."""

        # Collect ordered, deduplicated register names for each struct
        reg_in_names  = []
        reg_out_names = []
        seen_in  = set()
        seen_out = set()

        for inst in instances:
            for reg in inst["regs"]:
                cls  = self._reg_class(reg)
                name = reg["name"]
                if cls in ("in", "mixed"):
                    if name not in seen_in:
                        reg_in_names.append(name)
                        seen_in.add(name)
                if cls in ("out", "mixed"):
                    if name not in seen_out:
                        reg_out_names.append(name)
                        seen_out.add(name)

        # Column padding: align ';' after the longest register name
        all_names   = reg_in_names + reg_out_names
        max_name    = max((len(n) for n in all_names), default=20)
        name_col    = max_name + 2     # 2 trailing spaces before ';'

        # Cosmetic labels
        disp_upper  = struct_prefix.upper()

        L = []   # output lines

        # --- Header ---
        L.append(f"//{'='*77}")
        L.append(f"// Auto-generated by excel2pyral SVRegifGenerator")
        L.append(f"// Package : {pkg_name}")
        L.append(f"// Description: Register HW signal typedef structs.")
        L.append(f"//")
        L.append(f"// {struct_prefix}_reg_in_t  : hw=w registers (status,  HW writes → SW reads)")
        L.append(f"// {struct_prefix}_reg_out_t : hw=r registers (control, SW writes → HW reads)")
        L.append(f"//{'='*77}")
        L.append("")
        L.append(f"package {pkg_name};")
        L.append("")
        L.append(f"        localparam REG_DATA_WIDTH = {reg_data_width}; "
                 f"// take from default sheet reg width")
        L.append("")

        # ---- Input struct (hw=w / status registers) ----
        sep78 = "-" * 78
        L.append(f"//{sep78}")
        L.append(f"//--------{disp_upper} REGISTER INTERFACE----------------------------")
        L.append(f"//------------------------{disp_upper} Inputs"
                 f"------------------------------------")
        L.append("// Check SW access, if r only then put those in reg_in struct")
        L.append("typedef struct {")
        if reg_in_names:
            for rn in reg_in_names:
                pad = " " * (name_col - len(rn))
                L.append(f"          logic  [REG_DATA_WIDTH-1:0]  {rn}{pad};")
        else:
            L.append(f"          logic  [REG_DATA_WIDTH-1:0]  RESERVED_IN  ;  // no hw=w registers")
        L.append("                  ")
        L.append(f"        }} {struct_prefix}_reg_in_t;")
        L.append("")

        # ---- Output struct (hw=r / control registers) ----
        L.append(f"//------------------------{disp_upper} Outputs"
                 "------------------------------------")
        L.append("// Check SW access, if rw  then put those in reg_out struct")
        L.append("typedef struct {")
        if reg_out_names:
            for rn in reg_out_names:
                pad = " " * (name_col - len(rn))
                L.append(f"          logic  [REG_DATA_WIDTH-1:0]  {rn}{pad};")
        else:
            L.append(f"          logic  [REG_DATA_WIDTH-1:0]  RESERVED_OUT ;  // no hw=r registers")
        L.append("                  ")
        L.append(f"        }} {struct_prefix}_reg_out_t;")
        L.append("")
        L.append("endpackage")

        with open(pkg_file, "w", encoding="utf-8") as fh:
            fh.write("\n".join(L) + "\n")

    # ------------------------------------------------------------------
    # regif_{prefix}_top.sv writer
    # ------------------------------------------------------------------

    def _write_top(self, top_file, instances, struct_prefix, pkg_name,
                   top_module_name, rdl_module, rdl_pkg):
        """Generate the SV glue module file."""

        L = []

        # --- Header ---
        eq77 = "=" * 77
        L.append(f"//{'='*77}")
        L.append(f"// Auto-generated by excel2pyral SVRegifGenerator")
        L.append(f"// Module  : {top_module_name}")
        L.append(f"// Description: Register interface glue module.")
        L.append(f"// Interfaces peakrdl-generated {rdl_module} to the design.")
        L.append(f"//")
        L.append(f"// If a field is read from PL to PS >> assign to .next")
        L.append(f"// If a field is write from PS to PL >> take .value")
        L.append(f"//{'='*77}")
        L.append("")
        L.append("")

        # --- Module declaration ---
        L.append(f"module {top_module_name}")
        L.append(f" (  ")
        L.append(f"  input                       S_AXI_CLK             ,   "
                 f"// AXI clock signal")
        L.append(f"  input                       S_AXI_RESET           ,   "
                 f"// AXI active high reset signal")
        L.append(f"  axi4lite_intf.slave         s_axi4l               ,")
        L.append(f"  ")
        L.append(f"  input     {pkg_name}::{struct_prefix}_reg_in_t  "
                 f"{struct_prefix}_reg_in ,")
        L.append(f"  output    {pkg_name}::{struct_prefix}_reg_out_t "
                 f"{struct_prefix}_reg_out")
        L.append(f"  );")
        L.append("")

        # --- Imports + signals ---
        L.append(f"import {rdl_pkg}:: *;")
        L.append(f"import {pkg_name}:: *;")
        L.append("")
        L.append(f" {rdl_module}__in_t  hwif_in_1;     //{rdl_pkg}::")
        L.append(f" {rdl_module}__out_t hwif_out_1;   //{rdl_pkg}::")
        L.append("")

        # --- peakrdl module instantiation ---
        L.append(f" {rdl_module}  {rdl_module}_i (  ")
        L.append(f"   .clk      (S_AXI_CLK    ),")
        L.append(f"   .rst      (S_AXI_RESET  ),")
        L.append(f"   .s_axil   (s_axi4l      ),")
        L.append(f"   .hwif_in  (hwif_in_1    ),")
        L.append(f"   .hwif_out (hwif_out_1   )")
        L.append(f");")
        L.append("")
        L.append("")

        # --- always_comb #1: hw=w fields → hwif_in.inst.REG.field.next ---
        L.append("   // HW writes (status): assign reg_in → hwif_in .next fields")
        L.append("        always_comb ")
        L.append("        begin  ")

        for inst in instances:
            inst_name = inst["inst_name"]
            for reg in inst["regs"]:
                reg_name   = reg["name"]
                hw_w_fields = [f for f in reg["fields"] if f["hw_w"]]
                if not hw_w_fields:
                    continue
                for fld in hw_w_fields:
                    lhs = (f"                hwif_in_1.{inst_name}"
                           f".{reg_name}.{fld['name']}.next")
                    rhs = (f"{struct_prefix}_reg_in.{reg_name}"
                           f"[{fld['msb']}:{fld['lsb']}]")
                    # Pad LHS to column 95
                    pad = max(1, 95 - len(lhs))
                    L.append(f"{lhs}{' ' * pad}= {rhs}      ;")
                L.append("          ")

        L.append("    end")
        L.append("")

        # --- always_comb #2: hwif_out.inst.REG.field.value → reg_out ---
        L.append("    // SW writes (control): extract hwif_out .value → reg_out fields")
        L.append("    always_comb")
        L.append("    begin")

        for inst in instances:
            inst_name = inst["inst_name"]
            for reg in inst["regs"]:
                reg_name   = reg["name"]
                hw_r_fields = [f for f in reg["fields"] if not f["hw_w"]]
                if not hw_r_fields:
                    continue
                for fld in hw_r_fields:
                    lhs = (f"        {struct_prefix}_reg_out"
                           f".{reg_name}[{fld['msb']}:{fld['lsb']}]")
                    rhs = (f"hwif_out_1.{inst_name}"
                           f".{reg_name}.{fld['name']}.value")
                    pad = max(1, 68 - len(lhs))
                    L.append(f"{lhs}{' ' * pad}=    {rhs};")
                L.append("")

        L.append("    end")
        L.append("")
        L.append("")
        L.append(f"endmodule: {top_module_name} ")

        with open(top_file, "w", encoding="utf-8") as fh:
            fh.write("\n".join(L) + "\n")
