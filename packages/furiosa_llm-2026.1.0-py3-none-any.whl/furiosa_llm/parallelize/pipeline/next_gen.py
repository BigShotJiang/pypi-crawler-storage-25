import base64
import enum
from functools import cached_property
from typing import (
    Annotated,
    Any,
    Dict,
    Final,
    List,
    NewType,
    Optional,
    Tuple,
    Union,
)

import pydantic
from pydantic import (
    AfterValidator,
    BaseModel,
    BeforeValidator,
    RootModel,
    field_serializer,
    field_validator,
)
from pydantic.dataclasses import dataclass
import torch
from typing_extensions import Self

from furiosa_llm.parallelize.export.tensor import ParamFileInfo
from furiosa_llm.parallelize.mppp.config import Device as MpppDevice

ParamFileId = NewType('ParamFileId', str)
TensorId = NewType('TensorId', str)
StageTensorId = NewType('StageTensorId', str)
DeviceId = NewType('DeviceId', str)
BlobId = NewType('BlobId', str)
StageId = NewType('StageId', str)
Symbol = NewType('Symbol', str)

SYMBOL_VAL_SEPARATOR: Final[str] = ","


def _validate_symbol_val(value: str) -> str:
    if SYMBOL_VAL_SEPARATOR in value:
        raise ValueError(f"Symbol should not contain a comma: {value}")
    return value


@dataclass(frozen=True)
class SymbolVal:
    val: Annotated[str, AfterValidator(_validate_symbol_val)]

    def __str__(self) -> str:
        return self.val

    @pydantic.model_serializer
    def ser_model(self) -> str:
        return self.val

    @pydantic.model_validator(mode='before')
    @classmethod
    def validate_model(cls, data: Any):
        if isinstance(data, str):
            return {"val": data}
        else:
            return data


class Dtype(str, enum.Enum):
    F32 = "f32"
    F64 = "f64"
    I64 = "i64"
    I32 = "i32"
    BF16 = "bf16"
    BOOL = "bool"
    I8 = "i8"
    U8 = "u8"
    F8E4M3FN = "f8e4m3fn"

    def to_torch_dtype(self) -> torch.dtype:
        if self is Dtype.F32:
            return torch.float32
        elif self is Dtype.F64:
            return torch.float64
        elif self is Dtype.I64:
            return torch.int64
        elif self is Dtype.I32:
            return torch.int32
        elif self is Dtype.BF16:
            return torch.bfloat16
        elif self is Dtype.BOOL:
            return torch.bool
        elif self is Dtype.I8:
            return torch.int8
        elif self is Dtype.U8:
            return torch.uint8
        elif self is Dtype.F8E4M3FN:
            return torch.float8_e4m3fn
        else:
            raise NotImplementedError(f"Not supported dtype: {self}")


@dataclass
class TensorOrigin:
    name: str
    indices: List[Union[int, str]]


@dataclass
class TensorInfo:
    shape: List[int]
    dtype: Dtype
    origin: Optional[TensorOrigin]


@dataclass
class ParamValue:
    param_file: ParamFileId
    name: str
    name_in_graph: str  # name in graph/dfg


@dataclass
class ParamInfo(TensorInfo):
    value: ParamValue


class TaskKind(str, enum.Enum):
    FX = "fx"
    DFG = "dfg"
    KERNEL = "kernel"
    EDF = "edf"
    POSTLOWER_EDF = "postlower+edf"


@dataclass
class Task:
    kind: TaskKind
    inputs: List[TensorId]
    outputs: List[TensorId]
    data_blob: BlobId
    metadata: Dict[str, Any]


class StageKind(str, enum.Enum):
    ATTENTION = "attention"
    TOKENWISE = "tokenwise"
    COMPOSED = "composed"


def _validate_tasks(tasks: Dict):
    return {
        tuple(k.split(SYMBOL_VAL_SEPARATOR)) if isinstance(k, str) else k: v
        for k, v in tasks.items()
    }


@dataclass
class Stage:
    kind: StageKind
    symbols: List[Symbol]

    inputs_from_prev_stages: List[StageTensorId]
    outputs: List[StageTensorId]

    device: DeviceId
    # During serialization into json, key becomes a single string conatining elements seperated by comma.
    tasks: Annotated[Dict[Tuple[SymbolVal, ...], Task], BeforeValidator(_validate_tasks)]

    task_input_to_stage_input: Dict[TensorId, StageTensorId]
    metadata: Dict[str, Any]

    def to_json(self) -> str:
        return RootModel[self.__class__](self).model_dump_json(indent=2)  # type: ignore [name-defined]

    @field_serializer("tasks")
    def serialize_tasks(self, tasks: Dict[Tuple[SymbolVal, ...], Task]):
        return {
            SYMBOL_VAL_SEPARATOR.join(str(symbol) for symbol in key): value
            for key, value in tasks.items()
        }


@dataclass
class AttentionStage(Stage):
    seq_dim: int


class Device(pydantic.BaseModel):
    val: str

    def __init__(self, val: str):
        super(Device, self).__init__(val=val)
        self.val = val

    @cached_property
    def num_pe_per_chip(self) -> int:
        # FIXME: do this without using MpppDevice
        return MpppDevice(self.val).num_pe_per_chip

    @cached_property
    def num_chip(self) -> int:
        # FIXME: do this without using MpppDevice
        return MpppDevice(self.val).num_chip

    def __str__(self) -> str:
        return self.val

    @pydantic.model_serializer
    def ser_model(self) -> str:
        return self.val

    @pydantic.model_validator(mode='before')
    @classmethod
    def validate_model(cls, data: Any) -> Any:
        if isinstance(data, str):
            return {"val": data}
        return data


class Pipeline(BaseModel):
    name: str
    devices: Dict[DeviceId, Device]
    tensors: Dict[TensorId, Union[TensorInfo, ParamInfo]]

    inputs: List[TensorId]
    outputs: List[TensorId]
    stages: Dict[StageId, Union[AttentionStage, Stage]]

    blobs: Dict[BlobId, Any]
    composable_blobs: Optional[Dict[BlobId, Any]]

    param_files: Dict[ParamFileId, ParamFileInfo]
    version: str

    def get_blob_kind(self) -> Dict[BlobId, TaskKind]:
        """Returns a mapping of blob ID to its kind."""

        return {
            task.data_blob: task.kind  # type: ignore [misc]
            for stage in self.stages.values()
            for task in stage.tasks.values()
        }

    def get_stages_in_topo_order(self) -> List[Tuple[StageId, Stage]]:
        """Returns the stages in topological order."""

        stage_tensor_to_producer = {
            tensor_id: stage_id
            for stage_id, stage in self.stages.items()
            for tensor_id in stage.outputs
        }

        adj: Dict[StageId, List[StageId]] = {stage_id: [] for stage_id in self.stages}
        in_degree: Dict[StageId, int] = {stage_id: 0 for stage_id in self.stages}

        for stage_id, stage in self.stages.items():
            for input_tensor in stage.inputs_from_prev_stages:
                if input_tensor in stage_tensor_to_producer:
                    producer_id = stage_tensor_to_producer[input_tensor]
                    adj[producer_id].append(stage_id)
                    in_degree[stage_id] += 1

        queue = [stage_id for stage_id, degree in in_degree.items() if degree == 0]
        sorted_order = []

        while queue:
            u = queue.pop(0)
            sorted_order.append((u, self.stages[u]))

            for v in adj[u]:
                in_degree[v] -= 1
                if in_degree[v] == 0:
                    queue.append(v)

        if len(sorted_order) != len(self.stages):
            raise ValueError("Pipeline contains a cycle")

        return sorted_order

    def to_json(self) -> str:
        return RootModel[self.__class__](self).model_dump_json(indent=2)  # type: ignore [name-defined]

    @classmethod
    def from_json(cls, val: str, strict: Optional[bool] = None) -> Self:
        """Create a Pipeline instance from a JSON string."""
        return cls(**RootModel[cls].model_validate_json(val, strict=strict).model_dump())  # type: ignore [valid-type]

    @field_serializer("blobs")
    def serialize_blobs(self, blobs: Dict[BlobId, Any]) -> Dict[BlobId, Any]:
        # Don't serialize blobs - they will be loaded from disk on the Rust side using load_blobs()
        # This significantly reduces JSON size and serialization/deserialization time
        return {blob_id: None for blob_id in blobs.keys()}

    @field_serializer("composable_blobs")
    def serialize_composable_blobs(
        self, composable_blobs: Dict[BlobId, Any]
    ) -> Optional[Dict[BlobId, Any]]:
        # Don't serialize blobs - they will be loaded from disk on the Rust side using load_blobs()
        # This significantly reduces JSON size and serialization/deserialization time
        if composable_blobs is None:
            return None
        return {blob_id: None for blob_id in composable_blobs.keys()}

    @field_validator('blobs', mode='before')
    @classmethod
    def validate_blobs(cls, blobs: Any) -> Any:
        from furiosa.native_compiler import CompiledGraph

        if not isinstance(blobs, dict):
            return blobs

        for blob_id, blob in blobs.items():
            try:
                if isinstance(blob, str):
                    # Exactly reverse of serialize_blobs. For the reason of using base64, see serialize_blobs.
                    blob_in_bytes = base64.b64decode(blob.encode('utf-8'))
                elif isinstance(blob, bytes):
                    blob_in_bytes = blob
                else:
                    raise TypeError(f"Invalid blob type: {type(blob)}")
                blob = CompiledGraph.deserialize(blob_in_bytes, tag="")
                blobs[blob_id] = blob
            except Exception:
                pass
        return blobs
