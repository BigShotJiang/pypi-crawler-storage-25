import functools
import operator
from typing import Any, Dict, Optional, Sequence, Tuple

import torch
from torch.fx import GraphModule, Node

from furiosa_llm.parallelize.node_meta import (
    get_original_name,
)


def get_indexes_in_nested_tuple(haystack: Sequence[Any], needle: Any) -> Optional[Tuple[int, ...]]:
    if not isinstance(haystack, (tuple, list)):
        return None
    try:
        return (haystack.index(needle),)
    except ValueError:
        for i, item in enumerate(haystack):
            indexes = get_indexes_in_nested_tuple(item, needle)
            if indexes:
                return (i,) + indexes
        return None


def nested_equal(a, b) -> bool:
    if isinstance(a, (list, tuple)):
        if not isinstance(b, (list, tuple)):
            return False
        return all(map(lambda e1, e2: nested_equal(e1, e2), a, b))
    elif a is None:
        return b is None
    else:
        return a.equal(b)


def rgetattr(obj, attr, *args):
    def _getattr(obj, attr):
        return getattr(obj, attr, *args)

    return functools.reduce(_getattr, [obj] + attr.split("."))


def is_getitem(node: Node) -> bool:
    return node.op == "call_function" and node.target == operator.getitem


def get_tensor_name_with_idx(parent_name: str, idx: int) -> str:
    return f"{parent_name}:{idx}"


def get_tensor_name(node: Node, idx: Optional[int] = None) -> str:
    if node.op == "placeholder":
        node_name = node.name
    elif node.op == "call_module":
        node_name = node.name
    elif node.op == "get_attr":
        node_name = node.name
    elif is_getitem(node):
        # getitem node does not exist in Pipeline format.
        assert len(node.args) == 2
        parent, output_idx = node.args
        assert isinstance(parent, Node) and isinstance(output_idx, int)
        assert not is_getitem(parent)
        return get_tensor_name_with_idx(get_tensor_name(parent), output_idx)
    elif node.op == "call_function":
        return node.name
    else:
        raise NotImplementedError(f"node {node.name} cannot be converted to tensor name")

    if idx is not None:
        node_name = get_tensor_name_with_idx(node_name, idx)
    return node_name


# Get names of parameters saved in the param file
def get_constant_tensors_with_original_name(
    model: GraphModule,
) -> Dict[str, torch.Tensor]:
    """Get tensor constants in ``model`` that has original name and its original name is not in ``excludes``."""

    # Get param tensors that has original name but not in ``excludes``.
    return {
        original_name: getattr(model, node.target)
        for node in model.graph.nodes
        if node.op == "get_attr" and (original_name := get_original_name(node)) is not None
    }
