from collections import defaultdict
from itertools import chain
import json
import logging
import operator
import os
from pathlib import Path
from time import time
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Mapping,
    MutableMapping,
    Optional,
    Sequence,
    Set,
    Tuple,
    Type,
    Union,
)

from furiosa_torch_ext.torch_ext import SIDE_EFFECT_OPS, preprocess
import torch
from torch._subclasses import FakeTensorMode
from torch.fx import Graph, GraphModule, Node
from torch.fx.node import _side_effectful_functions
from torch.fx.passes.fake_tensor_prop import FakeTensorProp
from torch.fx.passes.split_module import split_module
from torch.utils._pytree import tree_flatten
from transformers import PretrainedConfig

from furiosa_llm.parallelize.block_slicer import (
    ModuleMarkConfig,
    PartitionInfo,
    add_marker_op_hooks,
    get_block_slicing_edges,
    get_blockwise_sliced_color_map,
    get_submodule_paths_in_modulelists,
    is_marker_op,
    remove_marker_nodes,
)
from furiosa_llm.parallelize.compiler_config import (
    CompilerConfigContext,
)
from furiosa_llm.parallelize.export.tensor import (
    ParamfileFormat,
    ParamFileInfo,
    ParamFileMetadata,
    save_tensors,
    write_without_concurrency_issue,
)
from furiosa_llm.parallelize.hash import get_env_independent_hash, hash_example_inputs, hash_model
from furiosa_llm.parallelize.layer_range import LayerRange, LayerType
from furiosa_llm.parallelize.model_creation_info import ModelCreationInfo
from furiosa_llm.parallelize.model_rewriter.api import ModelRewriter
from furiosa_llm.parallelize.model_rewriter.ops import custom_ops  # noqa: F401
from furiosa_llm.parallelize.mppp.api import Mppp
from furiosa_llm.parallelize.mppp.config import Device, MpppConfig
from furiosa_llm.parallelize.node_meta import (
    InputKind,
    get_color,
    get_original_name,
    set_color,
    set_input_kind,
    set_to_be_embedded,
    set_unsharded_tensor_meta,
)
from furiosa_llm.parallelize.pipeline.builder.arg_types import (
    LogitsSliceConfig,
)
from furiosa_llm.parallelize.pipeline.builder.converter import (
    ADDITIONAL_PARAM_FILE_ID,
    DEFAULT_MAX_EMBEDDABLE_CONSTANT_SIZE,
    DEFAULT_PARAM_FILE_ID_PREFIX,
    GraphModuleConverter,
    convert_into_partitioned_gm,
)
from furiosa_llm.parallelize.pipeline.builder.transform import (
    OpInfo,
    append_op_to_the_graph,
)
from furiosa_llm.parallelize.pipeline.builder.utils import get_constant_tensors_with_original_name
from furiosa_llm.parallelize.pipeline.types import (
    MetadataTensor,
    MetadataTensorSlice,
    ParamFileId,
    ParamInfo,
    Pipeline,
    SuperTaskKind,
)
from furiosa_llm.parallelize.trace import get_aten_graph_with_metadata
from furiosa_llm.parallelize.utils import (
    get_cache_path_if_exists,
    get_fake_mode,
    is_aten_op,
    is_custom_op,
    zip_equal,
)
from furiosa_llm.parallelize.visualize import draw_graph

from .transform import (
    remove_dead_placeholder_nodes,
    remove_output,
    replicate_nodes_with_multiple_colors,
)

logger = logging.getLogger(__file__)


def _info_log_for_ray(msg: str):
    logger.info(f"[furiosa-llm] {msg}")


def _get_sliced_torch_where_get_attr_nodes(gm: GraphModule) -> Tuple[Node, ...]:
    """Find get_attr nodes if it's used as ``torch.ops.aten.where``'s condition tensor (first input tensor) after a slice operation."""

    cache = set()
    to_be_embedded = set()
    for node in gm.graph.nodes:
        if not (node.op == "call_function" and node.target == torch.ops.aten.where.self):
            continue

        queue: List[Tuple[Node, bool]] = [(node.args[0], False)]

        while queue:
            node, found_slice = queue.pop()
            if node.op == "get_attr" and found_slice:
                to_be_embedded.add(node)
                continue
            flattened_args, _ = tree_flatten((node.args, node.kwargs))
            for arg in flattened_args:
                if not isinstance(arg, Node) or arg in cache:
                    continue
                cache.add(arg)
                queue.append((arg, found_slice or arg.target == torch.ops.aten.slice.Tensor))
    return tuple(to_be_embedded)


def _mark_constants_to_be_embedded(gm: GraphModule) -> None:
    """Mark some constants (get_attr nodes) to be embedded in FX graph as it is."""
    for node in _get_sliced_torch_where_get_attr_nodes(gm):
        set_to_be_embedded(node)


def _get_commit_id() -> str:
    import furiosa_llm

    if furiosa_llm.__version__:
        return furiosa_llm.__version__.hash
    else:
        import git  # type: ignore

        repo = git.Repo(Path(__file__).parent, search_parent_directories=True)
        return repo.head.object.hexsha


def _add_block_id_info(
    original_model_type: Type,
    aten_gm: GraphModule,
    num_blocks_per_supertask: Union[int, Sequence[int]],
    embedding_layer_as_single_block: bool,
    use_marker_based_block_slicer: bool,
    # FIXME: redesign this arg
    do_kernelwise_slicing: bool,
) -> Optional[Dict[int, PartitionInfo]]:
    """Add block id info for nodes in ``aten_gm``."""
    if use_marker_based_block_slicer:
        if embedding_layer_as_single_block:
            raise NotImplementedError(
                "Marker based block slicing with embedding as single block is not supported yet."
            )
        assert any(is_marker_op(node) for node in aten_gm.graph.nodes)

        if do_kernelwise_slicing:
            method = "marker_based_kernel_slicing"
        else:
            method = "marker"

        # Get block id map for nodes. Nodes with same block id belongs to same block.
        _, block_info = get_blockwise_sliced_color_map(
            aten_gm, method=method, mark_color_to_meta=True
        )
        remove_marker_nodes(aten_gm)
    else:
        slicing_edges = get_block_slicing_edges(
            aten_gm, original_model_type, embedding_layer_as_single_block
        )

        # Get block id map for nodes. Nodes with same block id belongs to same block.
        _, block_info = get_blockwise_sliced_color_map(
            aten_gm, method="split_by_edges", split_edges=slicing_edges, mark_color_to_meta=True
        )

    draw_graph(aten_gm, "after_coloring", visualize_color_info=True)

    all_colors: Set[int] = set()
    for node in aten_gm.graph.nodes:
        if colors := get_color(node):
            all_colors.update(colors)

    if isinstance(num_blocks_per_supertask, Sequence):
        color_to_new_color = []

        acc = 0
        for i, num_blocks in enumerate(num_blocks_per_supertask):
            for _ in range(num_blocks):
                color_to_new_color.append(i)
            acc += num_blocks

        if acc != len(all_colors):
            raise ValueError(
                f"num_blocks_per_supertask {num_blocks_per_supertask} does not match the number of colors {len(all_colors)}."
            )
    else:
        assert isinstance(num_blocks_per_supertask, int)
        color_to_new_color = [i // num_blocks_per_supertask for i in range(len(all_colors))]

    # Change block ids according to `num_blocks_per_supertask``.
    for node in aten_gm.graph.nodes:
        colors = get_color(node)
        if colors is None:
            continue
        new_colors = [color_to_new_color[color] for color in colors]
        set_color(node, new_colors)

    # Update block info according to new colors
    if block_info:
        new_block_info = {}
        new_color_to_colors = defaultdict(list)
        for color, new_color in enumerate(color_to_new_color):
            new_color_to_colors[new_color].append(color)
        for new_color, belonging_colors in new_color_to_colors.items():
            if len(belonging_colors) == 1:
                # If only one color belongs to this new color, just reuse original one.
                new_block_info[new_color] = block_info[belonging_colors[0]]
                continue

            first_color_layer_range = block_info[belonging_colors[0]].layer_range
            last_color_layer_range = block_info[belonging_colors[-1]].layer_range

            if first_color_layer_range is not None and last_color_layer_range is not None:
                start = first_color_layer_range.start
                end: Optional[LayerType] = last_color_layer_range.get_end()
                if start == end:
                    end = None
                new_layer_range = LayerRange(
                    start=start,
                    end=end,
                )
            else:
                new_layer_range = None
            new_block_info[new_color] = PartitionInfo(
                layer_range=new_layer_range,
            )
        block_info = new_block_info

    return block_info


def _apply_last_block_slice(
    graph: Graph,
    slice_direction: str,
    slice_dim: int,
):
    logger.info("Add slice op at the end of the graph.")

    # Find logits node
    output_node = next(iter(reversed(graph.nodes)))
    assert output_node.op == "output"

    output_tensor_nodes = output_node.args[0]

    if len(output_tensor_nodes) == 1:
        logits_node = output_tensor_nodes[0]
    else:
        original_names = get_original_name(output_node)
        assert isinstance(original_names, tuple)
        assert len(output_tensor_nodes) == len(original_names)
        logits_index = original_names.index("logits")
        logits_node = output_tensor_nodes[logits_index]

    if slice_direction == "left":
        args: Tuple = (slice_dim, 0, 1)
    elif slice_direction == "right":
        args = (slice_dim, -1)
    else:
        raise ValueError(f"Invalid slice direction {slice_direction}.")
    append_op_to_the_graph(graph, OpInfo(torch.ops.aten.slice.Tensor, args), logits_node)


class PipelineBuilder:
    model: Union[torch.nn.Module, ModelCreationInfo]
    model_config: Optional[PretrainedConfig]

    def __init__(
        self,
        model: Union[torch.nn.Module, ModelCreationInfo],
        model_config: Optional[PretrainedConfig],
        tmp_dir: Union[str, os.PathLike],
    ):
        self.model = model
        self.model_config = model_config
        self.tmp_dir = Path(tmp_dir)

    def __gen_pipeline_hash(
        self,
        example_args: Sequence[Any],
        example_kwargs: Dict[str, Any],
        mppp_config: MpppConfig,
        param_file_metadata: ParamFileMetadata,
        comp_supertask_kind: SuperTaskKind,
        use_blockwise_compile: bool,
        do_decompositions_for_model_rewrite: bool,
        padding_block_idx: Optional[int],
        sparse_select_version: str,
        embed_all_constants_into_graph: bool,
        max_embeddable_constant_size: int,
        num_blocks_per_supertask: Sequence[int],
        *args,
    ) -> str:
        if isinstance(self.model, ModelCreationInfo):
            original_model_type = self.model.metadata.get_optimized_cls()
            model_config = self.model.metadata.config
            # In tests, _weights_hash can be None
            weights_hash = self.model.metadata._weights_hash or model_config.name_or_path
            quantization_config = self.model.metadata.quantization_config
            seed = self.model.seed
            is_random_weight_model = self.model.random_weight_model
        else:
            # TODO
            raise NotImplementedError("Don't support pipeline hashing for non-metadata models.")

        saved_param_names = param_file_metadata.get_saved_param_names()
        saved_param_names.sort()

        if weights_hash is None:
            raise ValueError("Pipeline hashing for no model name or path is not supported.")

        to_be_hashed = (
            _get_commit_id(),
            hash_model(  # Keep the consistency with other hash_model() usages
                original_model_type,
                model_config,
                quantization_config,
                weights_hash,
                seed,
                is_random_weight_model,
            ),
            hash_example_inputs(example_args, example_kwargs),
            mppp_config.to_json(),
            json.dumps(saved_param_names),
            str(comp_supertask_kind),
            str(use_blockwise_compile),
            str(do_decompositions_for_model_rewrite),
            str(padding_block_idx),
            str(num_blocks_per_supertask),
            str(embed_all_constants_into_graph),
            str(max_embeddable_constant_size),
            sparse_select_version,
        ) + tuple(str(arg) for arg in args)

        return get_env_independent_hash(to_be_hashed)

    @staticmethod
    def __is_aten_graph(graph: Graph) -> bool:
        return all(
            node.op in ("placeholder", "get_attr", "output")
            or (
                node.op == "call_function"
                and (
                    is_aten_op(node.target)
                    or is_custom_op(node.target)
                    or node.target == operator.getitem
                )
            )
            for node in graph.nodes
        )

    @staticmethod
    def _add_unsharded_tensor_meta(
        graph: Graph,
    ):
        # store unsharded shape info for placeholder/output nodes.
        for node in graph.nodes:
            if node.op == "placeholder":
                set_unsharded_tensor_meta(node, node.meta["tensor_meta"])
            elif node.op == "output":
                set_unsharded_tensor_meta(
                    node, tuple(arg.meta["tensor_meta"] for arg in node.args[0])
                )

    def __additional_param_file_path(self, pipeline_name: str) -> Path:
        cnt = 0
        while os.path.exists(self.tmp_dir / f"add_const_file-{pipeline_name}-{cnt}.safetensors"):
            cnt += 1
        return self.tmp_dir / f"add_const_file-{pipeline_name}-{cnt}.safetensors"

    def save_additional_params(
        self,
        example_args: Sequence[Any],
        example_kwargs: Dict[str, Any],
        file_path: os.PathLike,
        target_params: Sequence[str],
        save_format: ParamfileFormat = ParamfileFormat.SAFETENSORS,
        cache_dir: Optional[os.PathLike] = None,
    ) -> None:
        """Save parameters in ``model``, but not in ``excludes`` to ``file_path``."""
        assert not os.path.exists(file_path)

        # Some additional params appear in aten-level, so lower it to aten level.
        aten_gm = get_aten_graph_with_metadata(
            self.model,
            example_args,
            example_kwargs,
            cache_dir=cache_dir,
        )[0]

        all_tensor_constants = get_constant_tensors_with_original_name(aten_gm)
        constants_to_be_saved = {name: all_tensor_constants[name] for name in target_params}

        # Save additional params to ``file_path`` if exists.
        if constants_to_be_saved:
            save_tensors(constants_to_be_saved, file_path, save_format)

    def __gen_pipeline(
        self,
        aten_gm: Optional[GraphModule],
        pipeline_name: str,
        example_args: Sequence[Any],
        example_kwargs: Dict[str, Any],
        mppp_config: MpppConfig,
        param_file_metadata: ParamFileMetadata,
        export_path: Optional[Path],
        comp_supertask_kind: SuperTaskKind,
        # current context: model_qname, beam_size, phase, bucket
        compiler_config_context: CompilerConfigContext,
        input_names: Optional[Sequence[str]],
        output_names: Optional[Sequence[str]],
        one_supertask_per_device: bool,
        use_blockwise_compile: bool,
        use_composable_kernel: bool,
        use_marker_based_block_slicer: bool,
        embedding_layer_as_single_block: bool,
        do_decompositions_for_model_rewrite: bool,
        padding_block_idx: Optional[int],
        sparse_select_version: str,
        embed_all_constants_into_graph: bool,
        max_embeddable_constant_size: int,
        num_blocks_per_supertask: Union[int, Sequence[int]],
        logits_slice_config: Optional[LogitsSliceConfig],
        add_valid_length_input_tensor: bool,
        cache_dir: Optional[os.PathLike],
        *,
        return_graphmodule: bool,
        _raise_error_if_compile: bool,
    ) -> Any:
        if not aten_gm:
            aten_gm = self._get_transformed_aten_graph_with_original_names(
                example_args,
                example_kwargs,
                input_names,
                output_names,
                do_decompositions_for_model_rewrite,
                cache_dir,
                param_file_metadata,
                padding_block_idx,
                sparse_select_version,
                logits_slice_config,
                use_marker_based_block_slicer,
                use_composable_kernel,
                check_compilability=comp_supertask_kind is not SuperTaskKind.FX,
            )

        logger.info("Add metadata and rewrite fx graph.")
        start = time()

        # What we want to do is to prevent only side-effect ops with no user from being eliminated by dead code elimination.
        # But union of ``_side_effectful_functions`` and ``SIDE_EFFECT_OPS`` contains only some of those side-effect ops.
        # TODO: Find a way to get a list of all side-effect aten ops.
        for node in aten_gm.graph.nodes:
            if (
                node.op != "output"
                and len(node.users) == 0
                and node.target not in _side_effectful_functions.union(SIDE_EFFECT_OPS)
            ):
                logger.warning(
                    f"Node with no user found, this might means meaningful nodes can disappear during postprocess: {node}"
                )

        assert PipelineBuilder.__is_aten_graph(aten_gm.graph)

        # mark some tensor constants (get_attr nodes) to be embedded in FX graph as it is
        # (instead of converting them as placeholders in future stages).
        _mark_constants_to_be_embedded(aten_gm)

        # NOTE: add block id info before graph transformations because those transformations
        # might make it hard to find block boundaries.
        if use_blockwise_compile:
            if isinstance(self.model, ModelCreationInfo):
                original_model_type = self.model.metadata.get_optimized_cls()
            else:
                assert isinstance(self.model, torch.nn.Module)
                original_model_type = type(self.model)

            # Add block id information for nodes if possible.
            # TODO: do this before any transformation and make all transformations preserve this information.
            block_info = _add_block_id_info(
                original_model_type,
                aten_gm,
                num_blocks_per_supertask,
                embedding_layer_as_single_block,
                use_marker_based_block_slicer,
                use_composable_kernel,
            )
            draw_graph(aten_gm, "blockwise_sliced_graph", visualize_color_info=True)
        else:
            block_info = None

        # All marker nodes should be removed before model rewriting stage.
        if use_marker_based_block_slicer:
            remove_marker_nodes(aten_gm)

        # Get constants that are not saved in given parameter file.
        # This will be passed to PipelineConverter.
        constants_not_in_param_file = get_constant_tensors_with_original_name(
            aten_gm,
        )

        # Exclude already saved ones
        for name in param_file_metadata.get_saved_param_names():
            constants_not_in_param_file.pop(name, None)

        # Save parameters not in parameter saved file referenced by `param_file_info`.
        additional_param_file_info = ParamFileInfo(
            str(self.__additional_param_file_path(pipeline_name)), ParamfileFormat.SAFETENSORS
        )

        PipelineBuilder._add_unsharded_tensor_meta(aten_gm.graph)

        fake_mode = get_fake_mode(chain(aten_gm.parameters(), aten_gm.buffers()))
        fake_args_for_aten_gm = tuple(
            fake_mode.from_tensor(node.meta["val"])
            for node in aten_gm.graph.nodes
            if node.op == "placeholder"
        )

        model_rewriter = ModelRewriter(aten_gm, mppp_config)

        rewritten_model = model_rewriter.rewrite(fake_args_for_aten_gm)

        logger.info("Adding metadata and rewriting fx graph took %.2f seconds.", time() - start)

        start = time()

        # Update `num_blocks_per_graph` info in compiler config.
        compiler_config_context.num_blocks_per_graph = num_blocks_per_supertask

        partitioned_gm = convert_into_partitioned_gm(
            rewritten_model,
            mppp_config.devices,
            model_rewriter.get_device_id_map(),
            one_supertask_per_device,
            use_blockwise_compile,
            embed_all_constants_into_graph,
            add_valid_length_input_tensor,
            color_to_partition_info=block_info,
            do_preprocess_for_compiler=return_graphmodule,
            max_embeddable_constant_size=max_embeddable_constant_size,
        )

        if return_graphmodule:
            return partitioned_gm

        gm_converter = GraphModuleConverter(
            partitioned_gm,
            mppp_config.devices,
            model_rewriter.get_device_id_map(),
        )

        pipeline = gm_converter.convert(
            pipeline_name,
            param_file_metadata,
            comp_supertask_kind,
            compiler_config_context,
            additional_param_file_info,
            constants_not_in_param_file,
            cache_dir=cache_dir,
            _raise_error_if_compile=_raise_error_if_compile,
        )
        logger.info("Converting GraphModule to pipeline took %.2f seconds.", time() - start)

        if export_path is not None:
            write_without_concurrency_issue(pipeline.to_json(), export_path)

        return pipeline

    @staticmethod
    def __replace_original_tensor_names(
        origin: MutableMapping[str, MetadataTensor],
        slices: Mapping[str, MetadataTensorSlice],
        new_names: Sequence[str],
    ) -> bool:
        need_resave = False
        replace_map = {}

        # Find original tensor names that need to be replaced.
        for cur_name, original_tensor_info in tuple(origin.items()):
            new_name = new_names[original_tensor_info.idx]
            if cur_name != new_name:
                origin[new_name] = original_tensor_info
                need_resave = True
                replace_map[cur_name] = new_name

        # Replace original tensor names in tensor slices.
        for tensor_slice_meta in slices.values():
            if tensor_slice_meta.origin in replace_map:
                tensor_slice_meta.origin = replace_map[tensor_slice_meta.origin]
        return need_resave

    def build(
        self,
        pipeline_name: str,
        devices: Sequence[Device],
        example_args: Sequence[Any],
        example_kwargs: Dict[str, Any],
        mppp_or_mppp_config: Union[MpppConfig, Mppp],
        param_file_metadata: Union[ParamFileMetadata, ParamFileInfo],
        # current context: model_qname, beam_size, phase, bucket
        compiler_config_context: CompilerConfigContext,
        comp_supertask_kind: SuperTaskKind = SuperTaskKind.FX,
        input_names: Optional[Sequence[str]] = None,
        output_names: Optional[Sequence[str]] = None,
        cache_dir: Optional[Path] = None,
        one_supertask_per_device: bool = False,
        use_blockwise_compile: bool = False,
        use_composable_kernel: bool = False,
        embedding_layer_as_single_block: bool = False,
        do_decompositions_for_model_rewrite: bool = False,
        padding_block_idx: Optional[int] = None,
        sparse_select_version: str = "v1.5",
        embed_all_constants_into_graph: bool = False,
        max_embeddable_constant_size: int = DEFAULT_MAX_EMBEDDABLE_CONSTANT_SIZE,
        num_blocks_per_supertask: Union[int, Sequence[int]] = 1,
        logits_slice_config: Optional[LogitsSliceConfig] = None,
        add_valid_length_input_tensor: bool = False,
        *,
        _return_graphmodule: bool = False,
        # `_raise_error_if_compile` is a flag that prevents
        # the invocation of the compiler during pipeline building.
        # It is used for testing purposes to ensure that no compilation occurs,
        # but cached compiled graphs are used.
        _raise_error_if_compile: bool = False,
    ) -> Pipeline:
        if isinstance(param_file_metadata, ParamFileInfo):
            param_file_metadata = ParamFileMetadata.load(
                param_file_metadata.path, param_file_metadata.format
            )

        # Use marker based block slicer if MCP is not used.
        use_marker_based_block_slicer = isinstance(self.model, ModelCreationInfo)
        if use_composable_kernel and not use_marker_based_block_slicer:
            raise ValueError(
                "Composable kernel is only supported with marker based block slicer. "
                "Please set `use_marker_based_block_slicer=True`."
            )

        if isinstance(mppp_or_mppp_config, Mppp):
            # Add original name information and do all graph transformations before generating mppp config.
            # Original name information might be needed for mppp config generation (e.g., block slicer).
            # And Graph transformations might affect mppp config to be generated.
            aten_gm = self._get_transformed_aten_graph_with_original_names(
                example_args,
                example_kwargs,
                input_names,
                output_names,
                do_decompositions_for_model_rewrite,
                cache_dir,
                param_file_metadata,
                padding_block_idx,
                sparse_select_version,
                logits_slice_config,
                use_marker_based_block_slicer,
                use_composable_kernel,
                check_compilability=comp_supertask_kind is not SuperTaskKind.FX,
            )

            mppp_config = mppp_or_mppp_config.gen_config(
                self.model,
                self.model_config,
                devices,
                example_args,
                example_kwargs,
                graph_module=aten_gm,
                other_configs={"use_marker_based_block_slicer": use_marker_based_block_slicer},
            )
        else:
            mppp_config = mppp_or_mppp_config
            aten_gm = None

        # We cache models only if model is `ModelCreationInfo` now.
        # TODO: add caching support for ordinary nn.Module.
        if (
            cache_dir is not None
            and isinstance(self.model, ModelCreationInfo)
            and self.model.is_hashable()
            and os.getenv("FURIOSA_DISABLE_PIPELINE_CACHE") != "1"
            and not _return_graphmodule
        ):
            if isinstance(num_blocks_per_supertask, int):
                num_hidden_layers = self.model.metadata.num_hidden_layers
                num_blocks_per_supertask_: Sequence[int] = [
                    layer_idx // num_blocks_per_supertask for layer_idx in range(num_hidden_layers)
                ]
            else:
                num_blocks_per_supertask_ = num_blocks_per_supertask

            # name is not used for hashing because it doesn't affect other fields of pipeline.
            pipeline_hash = self.__gen_pipeline_hash(
                example_args,
                example_kwargs,
                mppp_config,
                param_file_metadata,
                comp_supertask_kind,
                use_blockwise_compile,
                do_decompositions_for_model_rewrite,
                padding_block_idx,
                sparse_select_version,
                embed_all_constants_into_graph,
                max_embeddable_constant_size,
                num_blocks_per_supertask_,
                logits_slice_config,
                use_marker_based_block_slicer,
                add_valid_length_input_tensor,
            )
            need_additional_param_save = False  # whether parameters not in parameter file referenced by ``param_info`` exists.
            additional_params_to_be_saved = []
            additional_param_file_path = self.__additional_param_file_path(pipeline_name)
            export_path = cache_dir / "pipelines" / f"{pipeline_name}-{pipeline_hash}.json"
            os.makedirs(cache_dir / "pipelines", exist_ok=True)

            cached_pipeline_path = get_cache_path_if_exists(pipeline_hash, "json", cache_dir)

            if cached_pipeline_path:
                # cached pipeline exists.
                cached_pipeline = Pipeline.load(cached_pipeline_path)
                if cached_pipeline.name != pipeline_name:
                    cached_pipeline.name = pipeline_name

                if input_names is not None:
                    PipelineBuilder.__replace_original_tensor_names(
                        cached_pipeline.metadata.tensors.inputs,
                        cached_pipeline.metadata.tensor_slices.inputs,
                        input_names,
                    )
                if output_names is not None:
                    PipelineBuilder.__replace_original_tensor_names(
                        cached_pipeline.metadata.tensors.outputs,
                        cached_pipeline.metadata.tensor_slices.outputs,
                        output_names,
                    )

                new_param_files: Dict[ParamFileId, ParamFileInfo] = {}
                param_file_path_to_id: Dict[str, ParamFileId] = {}
                for tensor_info in cached_pipeline.tensors.values():
                    if not isinstance(tensor_info, ParamInfo):
                        continue
                    cached_param_file_info = cached_pipeline.param_files[
                        tensor_info.value.param_file
                    ]

                    if saved_param_file_path := param_file_metadata.get_saved_param_file(
                        tensor_info.value.name
                    ):
                        # check given param file has same param names as
                        # param file used for cached pipeline
                        if cached_param_file_info.path != saved_param_file_path:
                            saved_param_file_path = os.fspath(saved_param_file_path)
                            if saved_param_file_path not in param_file_path_to_id:
                                new_param_file_id = ParamFileId(
                                    f"{DEFAULT_PARAM_FILE_ID_PREFIX}_{len(param_file_path_to_id)}"
                                )
                                assert new_param_file_id not in new_param_files
                                param_file_path_to_id[saved_param_file_path] = new_param_file_id
                                new_param_files[new_param_file_id] = ParamFileInfo(
                                    saved_param_file_path,
                                    param_file_metadata.format,
                                )
                            new_param_file_id = param_file_path_to_id[saved_param_file_path]
                            tensor_info.value.param_file = new_param_file_id
                    else:
                        # This param doesn't exist in given param file. Add this to  ``additional_params_to_be_saved``.
                        tensor_info.value.param_file = ADDITIONAL_PARAM_FILE_ID
                        need_additional_param_save = True
                        additional_params_to_be_saved.append(tensor_info.value.name)

                additional_file_save_format = ParamfileFormat.SAFETENSORS
                if need_additional_param_save:
                    new_param_files[ADDITIONAL_PARAM_FILE_ID] = ParamFileInfo(
                        os.fspath(additional_param_file_path), additional_file_save_format
                    )

                cached_pipeline.param_files = new_param_files

                if need_additional_param_save:
                    self.save_additional_params(
                        example_args,
                        example_kwargs,
                        additional_param_file_path,
                        additional_params_to_be_saved,
                        additional_file_save_format,
                        cache_dir=cache_dir,
                    )

                return cached_pipeline
        else:
            # don't cache
            export_path = None

        # Don't cache if comp_supertask_kind != "fx" because other formats
        # cannot be serialized properly.
        # FIXME: cache other formats after fixing issues.
        if comp_supertask_kind != "fx":
            export_path = None

        return self.__gen_pipeline(
            aten_gm,
            pipeline_name,
            example_args,
            example_kwargs,
            mppp_config,
            param_file_metadata,
            export_path,
            comp_supertask_kind,
            compiler_config_context,
            input_names,
            output_names,
            one_supertask_per_device,
            use_blockwise_compile,
            use_composable_kernel,
            use_marker_based_block_slicer,
            embedding_layer_as_single_block,
            do_decompositions_for_model_rewrite,
            padding_block_idx,
            sparse_select_version,
            embed_all_constants_into_graph,
            max_embeddable_constant_size,
            num_blocks_per_supertask,
            logits_slice_config,
            add_valid_length_input_tensor,
            cache_dir=cache_dir,
            return_graphmodule=_return_graphmodule,
            _raise_error_if_compile=_raise_error_if_compile,
        )

    def _transform_graph(
        self,
        gm: GraphModule,
        padding_block_idx: Optional[int],
        sparse_select_version: str,
        logits_slice_config: Optional[LogitsSliceConfig],
    ) -> None:
        """Transform graph in-place."""

        apply_pre_parallelization_llm_graph_optimizations(
            gm,
            padding_block_idx,
            logits_slice_config,
            (
                self.model.metadata.seq_dim_in_logits
                if isinstance(self.model, ModelCreationInfo)
                else None
            ),
            sparse_select_version=sparse_select_version,
        )
        gm.recompile()

    def _get_transformed_aten_graph_with_original_names(
        self,
        # Args for tracing
        example_args: Sequence[Any],
        example_kwargs: Dict[str, Any],
        input_names: Optional[Sequence[str]],
        output_names: Optional[Sequence[str]],
        do_decompositions_for_model_rewrite: bool,
        cache_dir: Optional[os.PathLike],
        param_file_info: ParamFileMetadata,
        # Args for graph transformation
        padding_block_idx: Optional[int],
        sparse_select_version: str,
        logits_slice_config: Optional[LogitsSliceConfig],
        use_marker_based_block_slicer: bool,
        use_composable_kernel: bool,
        check_compilability: bool,
    ) -> GraphModule:
        if use_marker_based_block_slicer:
            if use_composable_kernel:
                # For composable kernel case, mark embedding, attention layers, and decoder layers.
                # FIXME: make this robust. avoid hardcoding.
                module_mark_config = ModuleMarkConfig(
                    # "embed_tokens" is a pattern used to capture the embedding module
                    # from instances of model classes '~Model' (e.g., `Qwen3Model`).
                    module_path_pattern=r"(.*self_attn\.attn)|(model\.embed_tokens)|(embed_tokens)",
                    include_submodules_in_modulelists=True,
                )
            else:
                module_mark_config = ModuleMarkConfig(include_submodules_in_modulelists=True)
        else:
            module_mark_config = None

        aten_gm = get_aten_graph_with_metadata(
            self.model,
            example_args,
            example_kwargs,
            input_names=input_names,
            output_names=output_names,
            do_decompositions_for_model_rewrite=do_decompositions_for_model_rewrite,
            cache_dir=cache_dir,
            param_file_metadata=param_file_info,
            module_mark_config=module_mark_config,
            check_compilability=check_compilability,
        )[0]

        self._transform_graph(
            aten_gm,
            padding_block_idx,
            sparse_select_version,
            logits_slice_config,
        )

        aten_gm.graph.eliminate_dead_code()
        remove_dead_placeholder_nodes(aten_gm.graph)

        return aten_gm


def partition_graph_with_marker(
    model: torch.nn.Module,
    example_args: Sequence,
    example_kwargs: Mapping[str, Any],
    module_selector: Optional[Callable[[str, torch.nn.Module], bool]] = None,
    include_modules_in_module_lists: bool = False,
    aten_graph: bool = True,
    include_common_ancestor_in_first_partition: bool = False,
    dynamic_shape: bool = False,
    dynamic_shapes_config: Optional[Union[Dict[str, Any], Tuple[Any], List[Any]]] = None,
    do_preprocess_for_compile: bool = False,
) -> GraphModule:
    """Trace model and get sub fx graph partitions using marker.

    Args:
        model (torch.nn.Module): model to be traced.
        example_args (Sequence): Positional arguments for tracing.
        example_kwargs (Mapping[str, Any]): Keyword arguments for tracing.
        module_selector (Optional[Callable[[str, torch.nn.Module], bool]], optional): Selects which submodule to be one partition.
            The function should accept two arguments: submodule path and submodule itself, and return True
            if the submodule is selected.
        include_modules_in_module_lists (bool, optional): If true, submodules in `torch.nn.ModuleList` is included in
            target modules and each of them becomes independent sub fx graph. Defaults to False.
        aten_graph (bool, optional): If true, ATen IR level fx graph is returned. Otherwise, Torch IR level fx graph is returned.
            Defaults to True.
        include_common_ancestor_in_first_partition (bool, optional): If True, common ancestor nodes that belong to multiple partitions are
            only included in first partition containing them. Otherwise, common nodes are replicated to all block
        dynamic_shape (bool, optional): Whether to get dynamic shape graph. Defaults to False.
        dynamic_shapes_config (Optional[Union[Dict[str, Any], Tuple[Any], List[Any]]], optional): Dynamic shape config
            which will be passed to `dynamic_shapes` argument of `torch._dynamo.export`. Defaults to None.
        do_preprocess_for_compile (bool, optional): If true, the sub graphmodules are preprocessed for compilation.
            This includes functionalization and decomposition.
    Returns:
        GraphModule: contains multiple sub graphmodules each of which corresponds to each piece.
            Each submodule's placeholder node has input kind (i.e., whether it is originally an input, constant or intermediate tensor)
            information and this can be obtained by calling `get_input_kind` for the placeholder node.
    """

    if include_modules_in_module_lists:
        additional_target_module_paths = set(get_submodule_paths_in_modulelists(model))
    else:
        additional_target_module_paths = set()

    def submodule_selector(path: str, submodule: torch.nn.Module) -> bool:
        return (module_selector is not None and module_selector(path, submodule)) or (
            path in additional_target_module_paths
        )

    hook_remover = add_marker_op_hooks(
        model,
        submodule_selector,
        allow_overlapping_submodule_selection=False,
    )

    # Tracing marker module might affect or be affected by other `torch._dynamo.export` calls.
    torch._dynamo.reset()

    gm = torch._dynamo.export(
        model,
        aten_graph=aten_graph,
        tracing_mode="symbolic" if dynamic_shape else "static",
        dynamic_shapes=dynamic_shapes_config,
    )(*example_args, **example_kwargs).graph_module
    torch._dynamo.reset()

    hook_remover()

    _, color_to_module_name = get_blockwise_sliced_color_map(
        gm,
        method="marker",
        mark_common_ancestor_as_first_layer=include_common_ancestor_in_first_partition,
    )

    remove_marker_nodes(gm)
    replicate_nodes_with_multiple_colors(gm)

    def splitter(node):
        colors = get_color(node)
        assert len(colors) == 1
        return color_to_module_name[colors[0]]

    splitted = split_module(gm, gm, splitter)

    assert isinstance(splitted, GraphModule)

    if do_preprocess_for_compile:
        # fill "val" metadata for all nodes in `splitted`.
        example_args = []
        for node in splitted.graph.find_nodes(op="placeholder"):
            if not node.users:
                arg = node.meta.get("val")
            else:
                arg = node.meta["val"]
            example_args.append(arg)
        FakeTensorProp(splitted, FakeTensorMode(allow_non_fake_inputs=True)).propagate(
            *example_args
        )

        for node in splitted.graph.nodes:
            if node.op != "call_module":
                continue
            sub_gm = splitted.get_submodule(node.target)

            args = []

            for arg in node.args:
                if isinstance(arg, Node):
                    arg = arg.meta["val"]
                args.append(arg)

            sub_gm = preprocess(
                sub_gm,
                args,
            )
            splitted.set_submodule(node.target, sub_gm)

    # Add input kind information for each sub graphmodule inputs.
    for node in splitted.graph.find_nodes(op="call_module"):
        sub_gm = splitted.get_submodule(node.target)
        assert isinstance(sub_gm, GraphModule)
        for arg_node_in_container, ph_node_in_submodule in zip_equal(
            node.args, sub_gm.graph.find_nodes(op="placeholder")
        ):
            if arg_node_in_container.op == "get_attr":
                set_input_kind(ph_node_in_submodule, InputKind.CONSTANT_TENSOR)
            elif arg_node_in_container.op == "placeholder":
                set_input_kind(ph_node_in_submodule, InputKind.USER_INPUT)
            else:
                set_input_kind(ph_node_in_submodule, InputKind.INTERMEDIATE_TENSOR)

    return splitted


def apply_pre_parallelization_llm_graph_optimizations(
    gm: GraphModule,
    padding_block_idx: Optional[int],
    logits_slice_config: Optional[LogitsSliceConfig],
    seq_dim_in_logits: Optional[int],
    sparse_select_version: str = "v1.5",
) -> None:
    """Apply LLM-specific graph optimizations If possible."""

    _ = padding_block_idx, sparse_select_version

    if logits_slice_config:
        if logits_slice_config.slice_size == 0:
            remove_output(gm.graph, eliminate_dead_code=True)
        else:
            if not logits_slice_config.slice_direction:
                raise ValueError("slice direction must be given when slice size is not 0.")
            if seq_dim_in_logits is None:
                raise ValueError(
                    "seq dim in logits must be given when logits slice config is provided."
                )
            _apply_last_block_slice(
                gm.graph, logits_slice_config.slice_direction, seq_dim_in_logits
            )

    # Replicate get_attr nodes shared by multiple users so that all get_attr nodes have
    # exactly one user. This makes partitioning process later easier.
    gm.recompile()
