from collections import defaultdict
import copy
from functools import reduce
import hashlib
from hashlib import blake2b
from itertools import chain
import logging
import operator
import os
from time import time
import typing
from typing import (
    Any,
    DefaultDict,
    Dict,
    Final,
    List,
    Mapping,
    MutableMapping,
    Optional,
    Sequence,
    Set,
    Tuple,
    Union,
    cast,
)

from furiosa_torch_ext.torch_ext import preprocess
from safetensors import safe_open
import torch
from torch._guards import detect_fake_mode
from torch._subclasses.fake_tensor import FakeTensor, FakeTensorMode
from torch.func import functionalize
from torch.fx import Graph, GraphModule, Node
from torch.fx.experimental.proxy_tensor import make_fx
from torch.fx.passes.shape_prop import TensorMetadata, _extract_tensor_metadata

from furiosa_llm.parallelize.block_slicer import PartitionInfo

if typing.TYPE_CHECKING:
    from furiosa.native_compiler import GraphMetadataBuilder

from furiosa_llm.parallelize.compiler_config import (
    CompilerConfigContext,
    GraphMetadata,
)
from furiosa_llm.parallelize.export.graphmodule import serialize_gm
from furiosa_llm.parallelize.export.tensor import (
    ParamfileFormat,
    ParamFileInfo,
    ParamFileMetadata,
    get_saved_param_names,
    save_tensors,
)
from furiosa_llm.parallelize.hash import (
    hash_fx_graph,
    hash_fx_graph_excluding_num_paged_attention_blocks,
    hash_tensor,
)
import furiosa_llm.parallelize.model_rewriter.mppp_config as mrw
from furiosa_llm.parallelize.model_rewriter.mppp_config import Device, ShardSpec
from furiosa_llm.parallelize.model_rewriter.ops.types import SingleDeviceCommOp
from furiosa_llm.parallelize.model_rewriter.ops.utils import is_single_dev_comm_op
from furiosa_llm.parallelize.node_meta import (
    ConstantKind,
    get_color,
    get_constant_kind,
    get_device_id,
    get_gm_hash,
    get_original_name,
    get_partition_info,
    get_spec,
    get_unsharded_tensor_meta,
    set_device_id,
    set_gm_hash,
    set_original_name,
    set_partition_info,
    set_spec,
    set_to_be_embedded,
    set_to_be_input,
    set_unsharded_tensor_meta,
    should_be_embedded,
    should_be_input,
)
from furiosa_llm.parallelize.pipeline.builder.single_device_comm_op_converter import (
    convert_to_single_device_comm_ops,
)
from furiosa_llm.parallelize.pipeline.builder.transform import is_attn_mask_node, partition_gm
from furiosa_llm.parallelize.pipeline.builder.utils import get_tensor_name, is_getitem
from furiosa_llm.parallelize.pipeline.types import (
    CommSuperTask,
    CompSuperTask,
    DataBlobId,
    DeviceId,
    InOutputSuperTask,
    MetaData,
    MetadataTensor,
    MetadataTensors,
    MetadataTensorSlice,
    MetadataTensorSlices,
    NameAfterMakeFx,
    ParamFileId,
    ParamInfo,
    ParamValue,
    Pipeline,
    Placements,
    SuperTask,
    SuperTaskId,
    SuperTaskKind,
    TensorInfo,
    TensorInfoWithPlacement,
)
from furiosa_llm.parallelize.utils import (
    get_fake_mode,
    propagate_shape_info_without_real_computation,
    zip_equal,
)
from furiosa_llm.parallelize.visualize import draw_graph
from furiosa_llm.utils import get_logger_with_tz

logger = get_logger_with_tz(logging.getLogger(__name__))

SUBMOD_PREFIX: Final[str] = "submod"
DEFAULT_PARAM_FILE_ID_PREFIX: Final[str] = "DEFAULT_PARAM_FILE"
ADDITIONAL_PARAM_FILE_ID: Final[ParamFileId] = ParamFileId("ADDITIONAL_PARAM_FILE")

DEFAULT_MAX_EMBEDDABLE_CONSTANT_SIZE = 1024  # 1KB

_is_comm_supertask = is_single_dev_comm_op

COMPILED_CACHE_SUB_DIR: Final[str] = "compiled_graphs"

# Refer to https://furiosa-ai.slack.com/archives/C07RVETN63D/p1747016534261599?thread_ts=1740630490.164769&cid=C07RVETN63D.
DEFAULT_SPARSE_RATIO_MEAN: Final[float] = 0.5
DEFAULT_SPARSE_RATIO_SIGMA: Final[float] = 0.15

VALID_LENGTH_NODE_NAME: Final[str] = "valid_length_for_compiler"


def _is_comp_supertask(node):
    return node.op == "call_module" and node.name.startswith(SUBMOD_PREFIX)


def _tensor_exists_in_file(tensor_name: str, param_file_info: ParamFileInfo) -> bool:
    file_format = param_file_info.format
    if file_format == ParamfileFormat.SAFETENSORS:
        # The example shows safe_open with 'with clause'; https://huggingface.co/docs/safetensors/index
        # It still causes 'error: "safe_open" has no attribute "__enter__"'. Why? for workaround, ignore it.
        with safe_open(param_file_info.path, framework="pt", device="cpu") as f:  # type: ignore
            # If this is a shared tensor, get actually stored tensor's name.
            if metadata := f.metadata():
                tensor_name = metadata.get(tensor_name, tensor_name)
            return tensor_name in f.keys()
    else:
        raise NotImplementedError(f"file format {file_format} is not supported")


class InOutputTensorInfo(TensorInfoWithPlacement):
    original_name: str
    idx: int
    device: DeviceId
    kind: str  # either "input" or "output"

    def __init__(
        self,
        tensor_info: TensorInfoWithPlacement,
        original_name: str,
        idx: int,
        device_id: DeviceId,
        kind: str,
    ):
        super().__init__(tensor_info.shape, tensor_info.dtype, tensor_info.placements)
        self.original_name = original_name
        self.idx = idx
        self.device_id = device_id
        assert kind in ("input", "output")
        self.kind = kind


def _propagate_device_id(gm: GraphModule):
    """Propagate meta["device_id"]"""
    for node in gm.graph.nodes:
        if node.op in ("placeholder", "get_attr"):
            assert "device_id" in node.meta
            continue
        elif node.op == "output":
            continue
        else:
            if len(node.args) == 0:
                assert "device_id" in node.meta
                continue
            # propagate device_id
            device_id = get_device_id(node.args[0])
            assert all(
                device_id == get_device_id(arg) for arg in node.args if isinstance(arg, Node)
            )
            set_device_id(node, device_id)


def _get_saved_name(param_file_info: ParamFileInfo, tensor_name: str) -> str:
    """This is for shared tensors, one of which is stored in parameter file."""
    if param_file_info.format == ParamfileFormat.SAFETENSORS:
        with safe_open(param_file_info.path, framework="pt", device="cpu") as f:  # type: ignore
            if metadata := f.metadata():
                tensor_name = metadata.get(tensor_name, tensor_name)
            return tensor_name
    else:
        raise NotImplementedError("Only SAFETENSORS format is supported currently")


def _node_to_be_embedded(
    node: Node, actual_tensor: torch.Tensor, max_embeddable_constant_size: int
) -> bool:
    if should_be_embedded(node):
        return True
    elif should_be_input(node):
        return False
    else:
        # If not marked, only embed constants with size smaller than or equal to `max_embeddable_constant_size`.
        return _get_tensor_size(actual_tensor) <= max_embeddable_constant_size


def _maybe_embed_attr_node(node: Node, gm: GraphModule, max_embeddable_constant_size: int) -> None:
    if node.op != "get_attr":
        return

    attr_name = node.target
    assert isinstance(attr_name, str)
    actual_tensor = getattr(gm, attr_name)

    if not _node_to_be_embedded(node, actual_tensor, max_embeddable_constant_size):
        return

    # Actual tensor should not be fake tensor.
    if isinstance(actual_tensor, FakeTensor):
        raise ValueError("All get_attr nodes without original name should not be fake tensor")

    if any(not _is_comp_supertask(user) for user in node.users):
        # If any non-comp-supertask user exists, this node cannot be embedded.
        assert not should_be_embedded(node)
        return

    # Embed attr node into submodule. The node will exist as a constant embedded in the sub-GraphModule,
    # instead of being exposed as an input.
    for user in tuple(node.users):
        # All users are sub GraphModule nodes.
        assert _is_comp_supertask(user)

        # Do we need to relax this assumption?
        assert isinstance(user, Node)
        assert user.op == "call_module" and isinstance(user.target, str)
        submod = getattr(gm, user.target)
        assert isinstance(submod, GraphModule)

        assert not hasattr(submod, attr_name)

        # Find first non placeholder node in sub GraphModule, so that
        # we can insert get_attr node before it.
        input_idx = user.args.index(node)
        original_placeholder = tuple(submod.graph.nodes)[input_idx]
        first_non_placeholder_node = tuple(submod.graph.nodes)[len(user.args)]
        assert first_non_placeholder_node.op != "placeholder"

        # create get_attr node inside sub GraphModule and replace placeholder node with it.
        if isinstance(actual_tensor, torch.nn.Parameter):
            submod.register_parameter(attr_name, actual_tensor)
        else:
            assert isinstance(actual_tensor, torch.Tensor)
            submod.register_buffer(attr_name, actual_tensor)

        with submod.graph.inserting_before(first_non_placeholder_node):
            new_node = submod.graph.get_attr(attr_name)
        new_node.meta = original_placeholder.meta.copy()

        original_placeholder.replace_all_uses_with(new_node)
        submod.graph.erase_node(original_placeholder)

        # change submod node (in global graph)'s args
        user.args = tuple(arg for arg in user.args if arg != node)
        submod.recompile()
    gm.graph.erase_node(node)


def _get_tensor_size(tensor: torch.Tensor) -> int:
    """Get size of the tensor in bytes. This function calculates size with just shape and dtype (i.e., doesn't consider actual physical size)."""
    return reduce(operator.mul, tensor.size(), tensor.element_size())


def _is_not_constant_node(node: Node) -> bool:
    if node.op == "get_attr":
        return False
    elif node.op == "placeholder":
        return True
    elif is_getitem(node):
        return any(_is_not_constant_node(arg) for arg in node.args if isinstance(arg, Node))
    else:
        return True


def _get_hash_for_get_attr_node(node: Node, gm: GraphModule) -> str:
    if get_constant_kind(node) is ConstantKind.WEIGHT:
        # Don't hash weight parameters and just consider them as unique ones for performance reason.
        return str(hash(get_original_name(node)))
    else:
        return hash_tensor(getattr(gm, cast(str, node.target)))


def _node_to_be_input(
    submod_input_nodes: Sequence[Node],
    container_gm: GraphModule,
    max_embeddable_constant_size: Optional[int],
) -> bool:
    """Check if the node should be an input."""

    assert isinstance(submod_input_nodes[0].target, str)
    if _get_tensor_size(getattr(container_gm, submod_input_nodes[0].target)) > (
        max_embeddable_constant_size or 0
    ) and all(
        not should_be_embedded(submod_input_node) for submod_input_node in submod_input_nodes
    ):
        return True
    else:
        first_constant_tensor_hash = _get_hash_for_get_attr_node(
            submod_input_nodes[0], container_gm
        )
        # If there are different constant tensors, we should make it as an input.
        return any(
            _get_hash_for_get_attr_node(submod_input_node, container_gm)
            != first_constant_tensor_hash
            for submod_input_node in submod_input_nodes[1:]
        )


def _mark_not_repeating_constants_for_blocks_to_be_input(
    gm: GraphModule,
    max_embeddable_constant_size: Optional[int] = None,
):
    """Mark not repeating constant tensors (get_attr nodes) for blocks (i.e., not all corresponding constants for blocks are not same) to be inputs of each block (sub GraphModule)"""

    hash_to_subgms: MutableMapping[str, List[Tuple[Node, GraphModule]]] = defaultdict(list)

    # Group submodules by hash value.
    for node in gm.graph.nodes:
        if not _is_comp_supertask(node):
            continue
        sub_gm = getattr(gm, node.target)
        hash_ = get_gm_hash(node)
        if hash_ is None:
            continue

        # Append tuple of call_module node for the submodule and submodule's GraphModule.
        hash_to_subgms[hash_].append((node, sub_gm))

    # Let's call call_module node in global fx graph as "call_submod_node",
    # and call_submod_node's arg nodes in global fx graph as "submod_input_node".
    for subgms in hash_to_subgms.values():
        if len(subgms) == 1:
            # This submodule is not a repeated one.
            continue

        num_submod_inputs = len(subgms[0][0].args)
        assert all(len(submod_info[0].args) == num_submod_inputs for submod_info in subgms)

        for input_idx in range(num_submod_inputs):
            submod_input_nodes: List[Node] = [
                cast(Node, call_submod_node.args[input_idx]) for call_submod_node, _ in subgms
            ]
            assert all(isinstance(node, Node) for node in submod_input_nodes)

            # If this submod_input_node is not a constant (i.e., other submod's output), we don't do anything.
            if any(
                _is_not_constant_node(submod_input_node) for submod_input_node in submod_input_nodes
            ):
                # If any of submod_input node is not a constant, it's impossible to embed it (because value for each submodule can be different.).
                assert all(
                    not set_to_be_embedded(submod_input_node)
                    for submod_input_node in submod_input_nodes
                    if not _is_not_constant_node(submod_input_node)
                )
                continue

            assert all(
                isinstance(submod_input_node, Node) and submod_input_node.op == "get_attr"
                for submod_input_node in submod_input_nodes
            )

            # Input constants for submodules.
            constant_inputs = [
                getattr(gm, cast(str, submod_input_node.target))
                for submod_input_node in submod_input_nodes
            ]

            if _node_to_be_input(submod_input_nodes, gm, max_embeddable_constant_size):
                # Input constant value is not same for all repeating submodules.
                # we should make it as an input.
                logger.debug(
                    f"Not Embedding constant tensor {submod_input_nodes} into submodules, shape: {constant_inputs[0].shape}"
                )
                for sub_gm, input_constant_node in zip_equal(subgms, submod_input_nodes):
                    assert isinstance(input_constant_node, Node)
                    assert not should_be_embedded(
                        input_constant_node
                    ), f"node {input_constant_node} was marked to be embedded, but needed to be made as an input for blockwise compile."
                    set_to_be_input(input_constant_node)


def _add_hash_for_sub_gms(gm: GraphModule):
    for node in gm.graph.nodes:
        if not _is_comp_supertask(node):
            continue
        assert node.name.startswith(SUBMOD_PREFIX)
        sub_gm = getattr(gm, node.target)

        submod_input_node_tensor_metas = [arg.meta["tensor_meta"] for arg in node.args]

        # Fill tensor meta info for placeholder nodes in sub GraphModule. This is needed for FX graph hashing.
        for input_node, tensor_meta in zip(sub_gm.graph.nodes, submod_input_node_tensor_metas):
            assert input_node.op == "placeholder"
            input_node.meta["tensor_meta"] = tensor_meta

        # TODO: change `include_tensor_stride_info` option to True after graphmodule exporter
        # to restore stride info across gm save and load. Currently, all constant tensors become
        # contiguous in the process of saving GraphModule for caching, might losing its original
        # stride. To make hash value and blob id consistent whether or not cached graphmodule is used,
        # we do not include stride information now.
        hash_ = hash_fx_graph(sub_gm, include_tensor_stride_info=False)
        set_gm_hash(node, hash_)


def _get_torch_device(
    node: Node,
    device_id_map: Mapping[mrw.DeviceId, DeviceId],
    devices: Mapping[DeviceId, Device],
) -> torch.device:
    device_id = get_device_id(node)
    if not isinstance(device_id, mrw.DeviceId):
        raise ValueError(f"Expected single DeviceId, but got {device_id}")
    return devices[device_id_map[device_id]].to_torch_device()


def convert_into_partitioned_gm(
    model: GraphModule,
    devices: Mapping[DeviceId, Device],
    device_id_map: Mapping[mrw.DeviceId, DeviceId],
    one_supertask_per_device: bool,
    use_color_for_partitioning: bool,
    embed_all_constants_into_graph: bool,
    add_valid_length_input_tensor: bool,
    *,
    max_embeddable_constant_size: int,
    do_preprocess_for_compiler: bool = False,
    color_to_partition_info: Optional[Mapping[int, PartitionInfo]] = None,
) -> GraphModule:
    fake_mode = get_fake_mode((*model.parameters(), *model.buffers()))

    # Generate fake arg tensors used for tracing.
    # Intentionally ignore cpu index via self._get_torch_device() to ensure created fake tensors are on exactly same device as constants (real tensors) in the model.
    # Real tensors loses cpu index information when it's created, but fake tensors preserve it. And when two kind of tensors created
    # with same torch cpu device with index (e.g., "cpu:1") are used together as inputs of certain operator, the operator fails to run
    # because two devices (cpu device without index and cpu device with index) are regarded as different ones by FakeTensor operators.
    # This doesn't affect GraphModule conversion process because this fake args are used only for Shape Propagation and derived device info
    # is not used.
    def _get_unsharded_tensor_meta(node: Node) -> TensorMetadata:
        tensor_meta = get_unsharded_tensor_meta(node)
        if not isinstance(tensor_meta, TensorMetadata):
            raise ValueError(f"Expect all placeholder nodes are single tensor, but {node} is not.")
        return tensor_meta

    example_fake_args = tuple(
        GraphModuleConverter._get_fake_slice(
            _get_unsharded_tensor_meta(node),
            cast(ShardSpec, get_spec(node)),
            device=_get_torch_device(node, device_id_map, devices),
            fake_mode=fake_mode,
        )
        for node in model.graph.nodes
        if node.op == "placeholder"
    )

    # transform rewritten fx graph
    model = GraphModuleConverter._transform_gm(
        model,
        example_fake_args,
        one_supertask_per_device,
        use_color_for_partitioning,
        embed_all_constants_into_graph,
        max_embeddable_constant_size,
    )

    if use_color_for_partitioning and color_to_partition_info:
        for node in model.graph.nodes:
            if node.op != "call_module":
                continue
            color = get_color(node)
            assert color and len(color) == 1

            set_partition_info(node, color_to_partition_info[color[0]])

    if add_valid_length_input_tensor:
        _add_valid_length_nodes(model)

    if do_preprocess_for_compiler:
        for node in model.graph.nodes:
            if node.op != "call_module":
                continue
            submod = getattr(model, node.target)
            tensor_metas = (arg.meta["tensor_meta"] for arg in node.args)  # type: ignore
            fake_mode = detect_fake_mode() or FakeTensorMode(allow_non_fake_inputs=True)
            with fake_mode:
                example_input = tuple(
                    torch.zeros(
                        tensor_meta.shape,
                        dtype=tensor_meta.dtype,
                        device="cpu",
                    )
                    for tensor_meta in tensor_metas
                )
            preprocessed = preprocess(submod, example_input)

            # Move placeholder metadata
            for original_ph_node, preprocessed_ph_node in zip_equal(
                submod.graph.find_nodes(op="placeholder"),
                preprocessed.graph.find_nodes(op="placeholder"),
            ):
                preprocessed_ph_node.meta = original_ph_node.meta.copy()
            setattr(model, node.target, preprocessed)
        model.recompile()

    return model


class GraphModuleConverter:
    """Convert rewritten GraphModule to Pipeline"""

    tensors: Dict[NameAfterMakeFx, Union[TensorInfo, ParamInfo, InOutputTensorInfo]]
    supertasks: Dict[SuperTaskId, SuperTask]

    # Temporary fields for new PipelineBuilder.
    supertask_id_to_partition_info: Dict[SuperTaskId, PartitionInfo]
    intermediate_tensor_id_to_global_id: Dict[str, Optional[str]]

    def __init__(
        self,
        model: GraphModule,
        devices: Mapping[DeviceId, Device],
        device_id_map: Mapping[mrw.DeviceId, DeviceId],
    ):
        self.model = model

        self.tensors = {}
        self.supertasks = {}

        self.devices = dict(devices)
        self.device_id_map = device_id_map

        self._next_supertask_id = 0

        self._unsharded_shape_per_input: Dict[str, Tuple[int, ...]] = {}
        self._unsharded_shape_per_output: Dict[str, Tuple[int, ...]] = {}

        self.data_blobs: Dict[DataBlobId, str] = {}
        self._next_blob_id = 0

        self._gm_hash_to_data_blob_id: Dict[str, DataBlobId] = {}

        # Information for new PipelineBuilder
        self.supertask_id_to_partition_info: Dict[SuperTaskId, PartitionInfo] = {}
        self.intermediate_tensor_id_to_global_id: Dict[str, Optional[str]] = {}

    def convert(
        self,
        pipeline_name: str,
        param_file_metadata: Optional[ParamFileMetadata],
        comp_supertask_kind: SuperTaskKind,
        compiler_config_context: CompilerConfigContext,
        additional_param_file_info: Optional[ParamFileInfo],
        original_model_params: Mapping[str, torch.Tensor],
        cache_dir: Optional[os.PathLike] = None,
        _raise_error_if_compile: bool = False,
    ) -> Pipeline:
        """Convert partitioned graphmodule into ``Pipeline``"""
        self.pipeline_name = pipeline_name

        param_files = {}

        params_to_be_saved = self._get_additional_params_to_save(param_file_metadata)

        if params_to_be_saved:
            if not additional_param_file_info:
                raise ValueError(
                    "There's additional parameters to save, but `additional_param_file_info` is not given."
                )
            save_tensors(
                {
                    param_name: original_model_params[param_name]
                    for param_name in params_to_be_saved
                },
                additional_param_file_info.path,
                additional_param_file_info.format,
            )
            param_files[ADDITIONAL_PARAM_FILE_ID] = additional_param_file_info

        if param_file_metadata:
            for i, param_file_path in enumerate(param_file_metadata.get_param_files()):
                param_file_id = ParamFileId(f"{DEFAULT_PARAM_FILE_ID_PREFIX}_{i}")
                assert param_file_id not in param_files
                param_files[param_file_id] = ParamFileInfo(
                    param_file_path,
                    param_file_metadata.format,
                )

        logger.info("Add tensors and supertasks")
        start = time()
        self._add_tensors(param_files)
        self._add_supertasks(
            comp_supertask_kind, compiler_config_context, cache_dir, _raise_error_if_compile
        )
        logger.info("Add tensors and supertasks took %.2f seconds", time() - start)

        self.metadata = self._construct_metadata()

        # convert ``InOutputTensorInfo`` to ``TensorInfo``
        def convert_to_tensor_info(info) -> TensorInfo:
            return (
                TensorInfo(info.shape, info.dtype) if isinstance(info, InOutputTensorInfo) else info
            )

        self.tensors = {name: convert_to_tensor_info(info) for name, info in self.tensors.items()}

        return Pipeline(
            name=pipeline_name,
            devices=dict(self.devices),
            tensors=self.tensors,
            supertasks=cast(
                Dict[SuperTaskId, Union[InOutputSuperTask, CompSuperTask, CommSuperTask]],
                self.supertasks,
            ),
            metadata=self.metadata,
            blobs=self.data_blobs,  # type: ignore[arg-type]
            param_files=param_files,
            # TODO: add proper device constraints after implementing interface for it.
            device_constraints=[],
        )

    def _get_additional_params_to_save(
        self,
        param_file_info: Optional[ParamFileMetadata],
    ) -> Set[str]:
        if param_file_info:
            saved_param_names = set(param_file_info.get_saved_param_names())
        else:
            saved_param_names = set()

        # Save params that are not in ``param_file``, but in the model.
        return set(
            original_name
            for node in self.model.graph.nodes
            if node.op == "get_attr"
            and (original_name := get_original_name(node))
            and original_name not in saved_param_names
        )

    @staticmethod
    def _transform_gm(
        gm: GraphModule,
        example_args: Sequence,
        one_supertask_per_device: bool,
        use_color_for_partitioning: bool,
        embed_all_constants_into_graph: bool,
        max_embeddable_constant_size: int,
    ) -> GraphModule:
        # Propagate shape info. This information is needed for
        # single device communication op conversion.
        # TODO: remove this after fix model rewriter to add tensor meta info for all newly created nodes.
        logger.info("Propagating shape info for fx graph")
        start = time()

        propagate_shape_info_without_real_computation(gm, example_args)

        logger.info("Propagating shape info took %.2f seconds", time() - start)

        # Convert multi-device comm ops to single device comm ops.
        convert_to_single_device_comm_ops(gm)
        draw_graph(gm, "stage4")

        # Cluster adjacent computation nodes that runs on same device without communication operation.
        # Computation nodes are grouped into multiple call_module nodes, each of which exactly corresponds to single ``SuperTask``.
        logger.info("Partitioning GraphModule into sub GraphModules")
        start = time()
        gm = partition_gm(gm, SUBMOD_PREFIX, one_supertask_per_device, use_color_for_partitioning)
        logger.info("Partitioning GraphModule took %.2f seconds", time() - start)

        _propagate_device_id(gm)

        # If not embedding all constants, add hash value for each sub GraphModule.
        if embed_all_constants_into_graph:
            # If embedding all constants, there's little possibility of any two sub graphmodules becoming same.
            # So we don't calculate graph hash for each sub GraphModule and use unique hash value for each submodule.
            for node in gm.graph.nodes:
                if not _is_comp_supertask(node):
                    continue
                assert isinstance(node.target, str)
                hash_value = blake2b(node.target.encode("ascii")).hexdigest()
                set_gm_hash(node, hash_value)
        else:
            _add_hash_for_sub_gms(gm)

        draw_graph(gm, "stage5")

        start = time()
        # Embed some get_attr nodes into sub``GraphModule``s according to each node's marked state.
        GraphModuleConverter._embed_get_attr_nodes_into_submodules(
            gm, embed_all_constants_into_graph, max_embeddable_constant_size
        )

        draw_graph(gm, "stage6")

        return gm

    @staticmethod
    def _embed_get_attr_nodes_into_submodules(
        gm: GraphModule, embed_all: bool, max_embeddable_constant_size: int
    ):
        """Embed get_attr nodes according to their marked constant embedding policies.

        This function determines whether each get_attr node should be embedded or not with the following rules:
        * If node is marked to be embedded (using ``set_to_be_embedded``), then it will be embedded into submodules as constant.
        * If node is marked to be an input (using ``set_to_be_input``), then it will be an input (placeholder node) of submodules.
        * Otherwise (not marked), make it as an input only if the size of constant tensor that the node refers to is greater than ``MAX_EMBEDDABLE_CONSTANT_SIZE``.

        If ``use_colors_for_partitioning=True``, set of constants that are in same position in each colored subgraph but have different values will be
            marked to be inputs. get_attr nodes referring to these constants should have not been marked to be embedded.
            For set of constants that are in same position in each colored subgraph and have same value will follow the above rules.
        """
        if embed_all:
            for node in gm.graph.nodes:
                if node.op != "get_attr":
                    continue
                set_to_be_embedded(node)
        else:
            start = time()
            _mark_not_repeating_constants_for_blocks_to_be_input(
                gm,
                max_embeddable_constant_size,
            )
            logger.info(
                "Marking not repeating constants for blocks takes %.2f seconds", time() - start
            )

        for node in gm.graph.nodes:
            _maybe_embed_attr_node(node, gm, max_embeddable_constant_size)

        gm.recompile()

    def _construct_metadata(self) -> MetaData:
        unsharded_tensors = MetadataTensors({}, {})
        tensor_slices = MetadataTensorSlices({}, {})

        for name, tensor_slice_info in self.tensors.items():
            # we only care about input/output tensors
            if not isinstance(tensor_slice_info, InOutputTensorInfo):
                continue
            original_name = tensor_slice_info.original_name

            sliced_tensor_meta = MetadataTensorSlice(
                placements=tensor_slice_info.placements,
                origin=original_name,
                dtype=tensor_slice_info.dtype,
                device=tensor_slice_info.device_id,
            )
            assert tensor_slice_info.kind in ("input", "output")
            kind = tensor_slice_info.kind + "s"

            getattr(tensor_slices, kind)[name] = sliced_tensor_meta
            tensors = getattr(unsharded_tensors, kind)

            if original_name not in tensors:
                unsharded_shape = (
                    self._unsharded_shape_per_input[original_name]
                    if tensor_slice_info.kind == "input"
                    else self._unsharded_shape_per_output[original_name]
                )

                # if there's no original tensor info, generate  it.
                tensors[original_name] = MetadataTensor(
                    shape=list(unsharded_shape),
                    dtype=tensor_slice_info.dtype,
                    idx=tensor_slice_info.idx,
                )
        return MetaData(unsharded_tensors, tensor_slices)

    def _add_supertasks(
        self,
        comp_supertask_kind: SuperTaskKind,
        # current context: model_qname, beam_size, phase, bucket
        compiler_config_context: CompilerConfigContext,
        cache_dir: Optional[os.PathLike],
        _raise_error_if_compile: bool = False,
    ):
        self._add_input_supertask(self.model)
        self._add_output_supertask(self.model)

        self.model.graph.lint()

        # Add normal (comm/comp) supertasks.
        # Sort nodes by device that it runs on first, and sort by topological order among nodes on same devices.
        # This order should be preserved because compiler has assumption on nodes' names in mid block graphmodule
        # when blockwise compile is used.
        for _, node in sorted(
            (
                (i, node)
                for i, node in enumerate(self.model.graph.nodes)
                if _is_comm_supertask(node) or _is_comp_supertask(node)
            ),
            key=lambda x: (get_device_id(x[1]), x[0]),
        ):
            supertask = self._get_supertask_from_node(
                node,
                comp_supertask_kind,
                compiler_config_context,
                cache_dir,
                _raise_error_if_compile,
            )
            supertask_id = self._add_new_supertask(supertask)
            if partition_info := get_partition_info(node):
                self.supertask_id_to_partition_info[supertask_id] = partition_info

    @staticmethod
    def compile_gm_and_get_preprocessed_gm_hash(
        gm: GraphModule,
        example_input: Sequence,
        target_npu: str,
        target_ir: str,
        compiler_config: Optional[Mapping],
        graph_metadata: Optional[Union[GraphMetadata, str]],
        dump_path: Optional[str],
        cache_dir: Optional[Union[str, os.PathLike]],
        extra_dump_tag: Optional[str] = None,
        _raise_error_if_compile: bool = False,
    ) -> Tuple[Any, str]:
        try:
            from furiosa.native_compiler import CompileResult, compile  # type: ignore[import]
        except ImportError:
            logger.error(
                "furiosa-native-compiler is required to compile GraphModule into DFG/EDF format"
            )
            raise

        preprocessed = preprocess(gm, example_input)

        # Move metadata for ph nodes in original gm to preprocessed because compiler make use of some of them.
        for preprocessed_ph, original_ph in zip_equal(
            preprocessed.graph.find_nodes(op="placeholder"),
            gm.graph.find_nodes(op="placeholder"),
        ):
            preprocessed_ph.meta.update(original_ph.meta)

        hash_after_preprocess = hash_fx_graph_excluding_num_paged_attention_blocks(preprocessed)
        logger.info(f"hash for the graph: {hash_after_preprocess}")
        dump_tag = (
            f"{hash_after_preprocess}+{extra_dump_tag.replace(' ', '_')}"
            if extra_dump_tag
            else hash_after_preprocess
        )
        logger.info(f"will be using dump_tag as : {dump_tag}")

        if isinstance(graph_metadata, GraphMetadata):
            graph_metadata_str: Optional[str] = graph_metadata.to_yaml()
        else:
            graph_metadata_str = graph_metadata

        try:
            if os.environ.get("ENFORCE_DFG_COMPILE") == "1":
                target_ir = "dfg"
                logger.info("Enforced DFG compilation method invoked; returning compiled DFG")
            compiled = compile(
                preprocessed,
                example_input,
                target_ir=target_ir,
                config=compiler_config,
                skip_trace=True,
                skip_preprocess=True,
                target_npu=target_npu,
                only_cpu_tasks=False,
                graph_metadata=graph_metadata_str,
                dump_path=dump_path,
                dump_tag=dump_tag,
                cache_dir=f"{cache_dir}/{COMPILED_CACHE_SUB_DIR}" if cache_dir else None,
                extra_args_for_hash={"graph_serde_bug_fixed": True},
                _raise_error_if_compile=_raise_error_if_compile,
            )
            assert isinstance(compiled, CompileResult)
            return compiled, hash_after_preprocess
        except Exception as e:
            raise RuntimeError(f"Compilation error: {e}")

    @staticmethod
    def get_target_npu_from_device(device: Device) -> str:
        if not device.is_npu:
            raise ValueError("target ir is dfg or edf, but device kind is not npu or rngd")

        num_pe = device.num_pe_per_chip
        num_chip = device.num_chip

        num_pe_suffix = f"-{num_pe}pe" if num_pe > 1 else ""
        num_chips_suffix = f"-{num_chip}chip" if num_chip > 1 else ""
        return f"renegade{num_pe_suffix}{num_chips_suffix}"

    def _next_data_blob_id(
        self,
    ) -> DataBlobId:
        self._next_blob_id += 1
        ret = DataBlobId(str(self._next_blob_id - 1))
        assert ret not in self.data_blobs
        return ret

    def _get_data_blob_id(
        self,
        node: Node,
        comp_supertask_kind: SuperTaskKind,
        # current context: model_qname, beam_size, phase, bucket
        compiler_config_context: CompilerConfigContext,
        cache_dir: Optional[os.PathLike] = None,
        _raise_error_if_compile: bool = False,
    ) -> DataBlobId:
        if gm_hash := get_gm_hash(node):
            blob_id = self._gm_hash_to_data_blob_id.get(gm_hash, DataBlobId(gm_hash))
        else:
            blob_id = self._next_data_blob_id()

        if blob_id in self.data_blobs:
            return blob_id

        # Dump an intermediate artifact (e.g., DFG, ir graphs, dot graphs) for debugging purpose
        dump_path = os.getenv("FURIOSA_COMPILE_DUMP_PATH")

        device_id = self._get_device_id(node)
        assert isinstance(node.target, str)
        submod = getattr(self.model, node.target)
        assert all(isinstance(arg, Node) for arg in node.args)
        tensor_metas = (arg.meta["tensor_meta"] for arg in node.args)  # type: ignore
        fake_mode = detect_fake_mode() or FakeTensorMode(allow_non_fake_inputs=True)
        with fake_mode:
            example_input = tuple(
                torch.zeros(
                    tensor_meta.shape,
                    dtype=tensor_meta.dtype,
                    device=self.devices[device_id].to_torch_device(),
                )
                for tensor_meta in tensor_metas
            )
        submod = GraphModuleConverter._preprocess_gm_for_serialization(submod, node)
        # preprocess submod GraphModule for serialization.
        # Always do this to ensure consistent compile result for `PipelineBuilder.build` and `PipelineBuilder.build_pipelines`.
        # TODO: Unify compile code pass for `PipelineBuilder.build` and `PipelineBuilder.build_pipelines`.
        for node_in_parent_mod, ph_node_in_submod in zip_equal(
            node.args, submod.graph.find_nodes(op="placeholder")
        ):
            ph_node_in_submod.meta.update(node_in_parent_mod.meta)
        if comp_supertask_kind is SuperTaskKind.FX:
            data = serialize_gm(submod, include_node_metadata=True)
        elif comp_supertask_kind in (SuperTaskKind.DFG, SuperTaskKind.EDF):
            # IMPORTANT: Compiler config generation part part in this function must be kept same as `_compile_supertasks_in_pipeline` in api.py.
            target_ir = comp_supertask_kind.value
            target_npu = GraphModuleConverter.get_target_npu_from_device(self.devices[device_id])

            compiler_config_context = copy.deepcopy(compiler_config_context)
            compiler_config_context.num_pe_per_chip = self.devices[device_id].num_pe_per_chip
            compiler_config_context.num_chip = self.devices[device_id].num_chip

            # TODO: improve logging
            # logging only if blockwise compile is used now.
            splitted = node.name.split("_")
            if len(splitted) == 3 and splitted[-1].startswith("c"):
                block_id = int(splitted[-1][1:])
                # This pipeline is generated with blockwise compile.
                logger.info(
                    f"Compiling pipeline {self.pipeline_name}, block={block_id}, target_npu={target_npu}"
                )

                compiler_config_context.block_idx = block_id
            else:
                # Whole block
                compiler_config_context.block_idx = None
                compiler_config_context.merge_all_blocks = True

            compiler_config = compiler_config_context.load_config()
            logger.info(f"Using compiler config {compiler_config}")

            output_consumer_info = _get_output_consumer_info(node, comp_supertask_kind)
            graph_metadata = generate_graph_metadata(
                compiler_config_context,
                submod,
                output_consumer_info,
                # Current function only handles transformer blockwise cases.
                True,
            )
            logger.info(f"Generated graph metadata: {graph_metadata}")

            # TODO: Use 4pe for now by default, and it should be given from a super task's metadata later.
            compiled, preprocessed_gm_hash = (
                GraphModuleConverter.compile_gm_and_get_preprocessed_gm_hash(
                    submod,
                    example_input,
                    target_npu,
                    target_ir,
                    compiler_config,
                    graph_metadata,
                    dump_path,
                    cache_dir,
                    _raise_error_if_compile=_raise_error_if_compile,
                )
            )
            data = compiled.graphs[0]  # type: ignore [assignment]
            assert len(compiled.graphs) == 1
            blob_id = DataBlobId(preprocessed_gm_hash)
            if gm_hash:
                self._gm_hash_to_data_blob_id[gm_hash] = blob_id
        else:
            raise NotImplementedError("dfg format is not supported currently")

        self.data_blobs[blob_id] = data
        return blob_id

    def _get_supertask_from_node(
        self,
        node: Node,
        comp_supertask_kind: SuperTaskKind,
        # current context: model_qname, beam_size, phase, bucket
        context: CompilerConfigContext,
        cache_dir: Optional[os.PathLike],
        _raise_error_if_compile: bool = False,
    ) -> SuperTask:
        assert _is_comm_supertask(node) or _is_comp_supertask(node)

        inputs = []
        for input_node in node.args:
            assert isinstance(input_node, Node)
            inputs.append(NameAfterMakeFx(get_tensor_name(input_node)))

        # tensor_meta value can be `None`.
        tensor_meta = node.meta.get("tensor_meta", None)
        if tensor_meta is None:
            tensor_meta = ()

        num_outputs = (
            1
            if isinstance(tensor_meta, torch.fx.passes.shape_prop.TensorMetadata)
            else len(tensor_meta)
        )

        outputs = (
            [
                NameAfterMakeFx(get_tensor_name(node)),
            ]
            if num_outputs == 1
            else [NameAfterMakeFx(get_tensor_name(node, i)) for i in range(num_outputs)]
        )

        supertask: Optional[SuperTask] = None

        device_id = self._get_device_id(node)
        assert isinstance(device_id, DeviceId)

        if _is_comp_supertask(node):
            # comp node
            blob_id = self._get_data_blob_id(
                node, comp_supertask_kind, context, cache_dir, _raise_error_if_compile
            )

            supertask = CompSuperTask(
                kind=comp_supertask_kind,
                data_blob=DataBlobId(blob_id),
                inputs=inputs,
                outputs=outputs,
                device=device_id,
            )
        else:
            # comm supertask
            my_device_id = get_device_id(node)
            assert isinstance(my_device_id, mrw.DeviceId)
            assert isinstance(node.target, SingleDeviceCommOp)
            comm_op = node.target

            def convert_device_ids(metadata: Dict) -> Dict:
                return {
                    k: self.device_id_map[v] if isinstance(v, mrw.DeviceId) else v
                    for k, v in metadata.items()
                }

            supertask = CommSuperTask(
                kind=comm_op.kind(),
                inputs=inputs,
                outputs=outputs,
                device=device_id,
                group=str(comm_op.group.id),
                device_idx=comm_op.group.index(my_device_id),
                metadata=convert_device_ids(comm_op.metadata()),
            )

        assert isinstance(supertask, SuperTask)

        return supertask

    def _add_input_supertask(self, gm: GraphModule):
        placeholder_nodes = tuple(filter(lambda x: x.op == "placeholder", gm.graph.nodes))
        # Do we need to raise error?
        if not all(len(node.users) > 0 for node in placeholder_nodes):
            logger.warning("Some placeholder nodes in rewritten model are not used.")
        input_names = [NameAfterMakeFx(get_tensor_name(node)) for node in placeholder_nodes]

        self.input_supertask = InOutputSuperTask(
            kind=SuperTaskKind.INPUT,
            inputs=[],
            outputs=input_names,
        )

        self._add_new_supertask(self.input_supertask)

    def _add_output_supertask(self, gm: GraphModule):
        output_node = next(filter(lambda x: x.op == "output", gm.graph.nodes))
        output_names = [NameAfterMakeFx(get_tensor_name(node)) for node in output_node.args[0]]

        self.output_supertask = InOutputSuperTask(
            kind=SuperTaskKind.OUTPUT,
            inputs=output_names,
            outputs=[],
        )

        self._add_new_supertask(self.output_supertask)

    @staticmethod
    def _preprocess_gm_for_serialization(gm: GraphModule, node: Node) -> GraphModule:
        fake_mode = get_fake_mode(chain(gm.parameters(), gm.buffers()))
        original_allow_non_fake_inputs = fake_mode.allow_non_fake_inputs
        fake_mode.allow_non_fake_inputs = True
        try:
            # All submodules accept only nodes as an input.
            assert all(isinstance(arg, Node) for arg in node.args)

            # derive example inputs from node info
            tensor_metas = (cast(Node, arg).meta["tensor_meta"] for arg in node.args)

            gm_devices = set(tensor.device for tensor in chain(gm.parameters(), gm.buffers()))
            assert len(gm_devices) <= 1
            gm_device = gm_devices.pop() if len(gm_devices) > 0 else torch.device("cpu")

            with fake_mode:
                inputs = [
                    torch.zeros(tensor_meta.shape, dtype=tensor_meta.dtype, device=gm_device)
                    for tensor_meta in tensor_metas
                ]

            # lower graphmodule into aten level.
            lowered_gm = make_fx(functionalize(gm, remove="mutations_and_views"))(*inputs)

            gm.graph.lint()
            output_node = next(iter(reversed(lowered_gm.graph.nodes)))
            assert output_node.op == "output"
            node_args = output_node.args[0]

            # If GraphModule's output node args format doesn't follow what ``GraphModuleSerializer`` expects, transform it.
            # This happens when gm has no output.
            # https://github.com/pytorch/pytorch/blob/7bcf7da3a268b435777fe87c7794c382f444e86d/torch/_export/serde/serialize.py#L369-L375
            if not isinstance(node_args, (tuple, list, torch.fx.Node)):
                assert node_args is None
                output_node.args = ((),)

            return lowered_gm
        finally:
            fake_mode.allow_non_fake_inputs = original_allow_non_fake_inputs

    @staticmethod
    def _get_fake_slice(
        tensor_meta: TensorMetadata,
        spec: mrw.ShardSpec,
        device: torch.device,
        fake_mode: FakeTensorMode,
    ) -> FakeTensor:
        sliced_shape = list(tensor_meta.shape)
        for placement, dim_width in zip(spec.placements, spec.mesh.size()):
            if placement.is_shard():
                dim = cast(mrw.Shard, placement).dim
                assert sliced_shape[dim] % dim_width == 0
                sliced_shape[dim] //= dim_width
        with fake_mode:
            return cast(
                FakeTensor, torch.empty(sliced_shape, dtype=tensor_meta.dtype, device=device)
            )

    def _get_device_id(self, node: Node) -> DeviceId:
        dev_id = get_device_id(node)
        assert isinstance(dev_id, mrw.DeviceId)
        return self.device_id_map[dev_id]

    def _add_new_supertask(self, super_task: SuperTask) -> SuperTaskId:
        id_ = self._get_next_supertask_id()
        self.supertasks[id_] = super_task
        return id_

    def _get_next_supertask_id(self) -> SuperTaskId:
        self._next_supertask_id += 1
        return SuperTaskId(str(self._next_supertask_id - 1))

    def _add_tensors(
        self,
        param_files: Mapping[ParamFileId, ParamFileInfo],
    ):
        """Add `TensorInfo` for all node in FX graph"""

        # Track index of original placeholder node in original FX graph that placeholder originates from.
        original_placeholder_idx_cnt = 0

        placeholder_met = set()
        # Prepare mapping from tensor name to saved ParamFileInfo in advance.
        constant_name_to_param_file = {}
        for param_file_id, param_file_info in param_files.items():
            for saved_const_name in get_saved_param_names(param_file_info):
                constant_name_to_param_file[saved_const_name] = ParamFileId(param_file_id)

        for node in self.model.graph.nodes:
            if node.op == "placeholder":
                self._add_input_tensor(node, original_placeholder_idx_cnt)
                original_name = get_original_name(node)
                assert original_name
                if original_name not in placeholder_met:
                    original_placeholder_idx_cnt += 1
                    placeholder_met.add(original_name)
            elif node.op == "get_attr":
                original_name = get_original_name(node)
                assert original_name
                param_file_id = constant_name_to_param_file[original_name]
                param_file_info = param_files[param_file_id]
                self._add_constant_tensor(
                    node,
                    param_file_id,
                    param_file_info,
                )
            elif is_getitem(node):
                tensor_name = get_tensor_name(node)
                assert tensor_name in self.tensors
                # inputs of getitem nodes doesn't need to be handled
                # because we only consider tensors, not tuple of tensors.
                continue
            elif _is_comm_supertask(node) or _is_comp_supertask(node):
                self._add_supertask_output_tensors(node)
            elif node.op == "output":
                self._add_output_tensors(node)
            else:
                raise NotImplementedError(f"node {node.name} is not supported")

    def _add_input_tensor(self, node: Node, original_placeholder_idx: int):
        # Get ``TensorInfoWithPlacement`` for input nodes
        tensor_name = get_tensor_name(node)
        assert tensor_name not in self.tensors
        device_id = self._get_device_id(node)
        assert isinstance(device_id, DeviceId)

        self.tensors[NameAfterMakeFx(tensor_name)] = self._get_inoutput_tensor_info_from_node(
            node,
            kind="input",
            idx=original_placeholder_idx,
        )

        original_name = get_original_name(node)
        assert original_name
        if original_name not in self._unsharded_shape_per_input:
            unsharded_tensor_meta = get_unsharded_tensor_meta(node)
            assert isinstance(unsharded_tensor_meta, TensorMetadata)
            self._unsharded_shape_per_input[original_name] = tuple(unsharded_tensor_meta.shape)

    def _add_constant_tensor(
        self, node: Node, param_file_id: ParamFileId, param_file_info: ParamFileInfo
    ):
        # parameter or buffer stored in parameter file
        original_name = get_original_name(node)
        assert original_name, "All get_attr nodes should have original name"
        assert _tensor_exists_in_file(
            original_name, param_file_info
        ), f"{original_name} does not exist in parameter file."

        param_value = ParamValue(
            param_file_id,
            _get_saved_name(param_file_info, original_name),
            node.name,
            Placements.from_node(node),
        )

        tensor_info = TensorInfo.from_node(node)
        tensor_name = get_tensor_name(node)
        assert tensor_name not in self.tensors
        self.tensors[NameAfterMakeFx(tensor_name)] = ParamInfo(
            tensor_info.shape, tensor_info.dtype, param_value
        )

    def _add_supertask_output_tensors(self, node: Node):
        # all call_module nodes are either submodule containing multiple computation ops
        # or submodule for single collective communication op.
        assert _is_comm_supertask(node) or _is_comp_supertask(node)

        if _is_comp_supertask(node):
            assert isinstance(node.target, str)
            submod = getattr(self.model, node.target)
            assert isinstance(submod, GraphModule)
            submod_placeholders = tuple(
                node for node in submod.graph.nodes if node.op == "placeholder"
            )

            assert len(submod_placeholders) == len(node.args)

        # register output tensors of the node.
        tensor_meta = node.meta.get("tensor_meta", None)
        if isinstance(tensor_meta, torch.fx.passes.shape_prop.TensorMetadata):
            tensor_name = get_tensor_name(node)
            assert tensor_name not in self.tensors
            self.tensors[NameAfterMakeFx(tensor_name)] = TensorInfo.from_node(node)
            # Add global id info for each output tensor of the submodule.
            # This information will later be used for matching intermediate tensors
            # across multiple local pipelines.
            if get_partition_info(node):
                self.intermediate_tensor_id_to_global_id[tensor_name] = (
                    _get_global_id_for_interm_tensor(node, 0)
                )
        elif isinstance(tensor_meta, (list, tuple)):
            for idx, meta in enumerate(tensor_meta):
                tensor_name = get_tensor_name(node, idx)
                assert tensor_name not in self.tensors
                self.tensors[NameAfterMakeFx(tensor_name)] = TensorInfo.from_node_tensor_meta_data(
                    meta
                )
                if get_partition_info(node):
                    self.intermediate_tensor_id_to_global_id[tensor_name] = (
                        _get_global_id_for_interm_tensor(node, idx)
                    )
        else:
            # There can be supertasks with no user (child). It can be in-place update ops or communication ops.
            assert len(node.users) == 0

    def _add_output_tensors(self, node: Node):
        args = node.args[0]
        assert node.op == "output"
        assert isinstance(args, tuple)

        specs_for_outputs = []
        original_names = get_original_name(node)

        unsharded_tensor_metas = get_unsharded_tensor_meta(node)
        assert isinstance(unsharded_tensor_metas, tuple)

        unsharded_shapes = []
        for unsharded_tensor_meta in unsharded_tensor_metas:
            assert isinstance(unsharded_tensor_meta, TensorMetadata)
            unsharded_shapes.append(unsharded_tensor_meta.shape)

        specs = get_spec(node)

        if not isinstance(specs, Sequence):
            specs = (specs,)

        assert isinstance(original_names, Sequence)
        assert (
            len(original_names) == len(unsharded_shapes) == len(specs)
        ), "Metadata for output node is not correct"

        for idx, (spec, original_name, unsharded_shape) in enumerate(
            zip(specs, original_names, unsharded_shapes)
        ):
            for _ in spec.mesh.get_all_devices():
                specs_for_outputs.append((idx, spec, original_name))

            assert original_name not in self._unsharded_shape_per_output
            self._unsharded_shape_per_output[original_name] = unsharded_shape

        for arg, (idx, spec, obtained_original_name) in zip(args, specs_for_outputs):
            assert isinstance(arg, Node)
            tensor_name = get_tensor_name(arg)
            assert tensor_name in self.tensors
            set_spec(arg, spec)
            set_original_name(arg, obtained_original_name)

            self.tensors[NameAfterMakeFx(tensor_name)] = self._get_inoutput_tensor_info_from_node(
                arg, kind="output", idx=idx
            )

    def _get_inoutput_tensor_info_from_node(
        self, node: Node, kind: str, idx: int, original_name: Optional[str] = None
    ) -> InOutputTensorInfo:
        tensor_info = TensorInfoWithPlacement.from_node(node)

        # calculate original tensor shape
        original_name = original_name or get_original_name(node)
        assert original_name
        device_id = self._get_device_id(node)
        assert isinstance(device_id, DeviceId)
        return InOutputTensorInfo(
            tensor_info,
            original_name,
            idx=idx,
            device_id=device_id,
            kind=kind,
        )


def generate_graph_metadata(
    compiler_config_context: CompilerConfigContext,
    gm: GraphModule,
    output_consumer_info: Sequence[Sequence[SuperTaskKind]],
    tr_blockwise_compile_used: bool,
) -> str:
    """Generate graph metadata with the given information.

    Args:
        compiler_config_context (CompilerConfigContext): Compiler config context that contains various metadata.
        gm (GraphModule): GraphModule to be compiled.
        output_consumer_info (Sequence[Sequence[SuperTaskKind]]): Information about the consumer supertasks of the supetask that corresponds to `gm`.
            It's a 2-d sequence whose [i][j] element is `i`th output tensor's `j`th consumer node's kind. Order of node kinds for each output
            tensor doesn't matter, but the order among output tensors should be same as the order of output nodes in the graph.
        tr_blockwise_compile_used: Whether the graph(`gm`) is produced by transformer blockwise slicing.

    Returns:
        str: Serialized graph metadata.
    """

    from furiosa.native_compiler import GraphMetadataBuilder

    graph_metadata_builder = GraphMetadataBuilder()

    _add_valid_length_info_if_possible(gm, compiler_config_context, graph_metadata_builder)

    return graph_metadata_builder.build()


def is_valid_length_node(node: Node) -> bool:
    return node.op == "placeholder" and get_original_name(node) == VALID_LENGTH_NODE_NAME


def _has_attention_mask_ancestor(
    submod_node: Node,
) -> bool:
    to_visit = list(submod_node.all_input_nodes)
    visited: Set[Node] = set()

    while to_visit:
        node = to_visit.pop()

        if is_attn_mask_node(node):
            return True

        for parent in node.all_input_nodes:
            if parent in visited:
                continue
            to_visit.append(parent)

    return False


def _create_valid_length_node(
    graph: Graph,
    device_id: mrw.DeviceId,
    batch_size: int,
    fake_mode: FakeTensorMode,
) -> Node:
    last_ph_node = graph.find_nodes(op="placeholder")[-1]
    with graph.inserting_after(last_ph_node):
        valid_length_node = graph.placeholder(VALID_LENGTH_NODE_NAME)

    # Add various metadata needed for later conversion stages.
    set_original_name(valid_length_node, VALID_LENGTH_NODE_NAME)
    set_device_id(valid_length_node, device_id)
    with fake_mode:
        example_tensor = torch.zeros(batch_size, dtype=torch.int32)
    valid_length_node.meta["tensor_meta"] = _extract_tensor_metadata(example_tensor)
    valid_length_node.meta["val"] = example_tensor
    set_spec(
        valid_length_node,
        ShardSpec(
            placements=(mrw.Replicate(),),
            mesh=mrw.DeviceMesh(torch.tensor([device_id], dtype=torch.int64)),  # type: ignore [arg-type]
        ),
    )
    set_unsharded_tensor_meta(valid_length_node, valid_length_node.meta["tensor_meta"])

    return valid_length_node


def _add_valid_length_nodes(
    container_gm: GraphModule,
):
    # Add valid length input tensor to container module and each submodule.
    input_ids_node = [
        node
        for node in container_gm.graph.find_nodes(op="placeholder")
        if get_original_name(node) == "input_ids"
    ]
    assert (
        len(input_ids_node) == 1
    ), f"Expected exactly one input_ids node, but got {len(input_ids_node)}"
    batch_size = input_ids_node[0].meta["tensor_meta"].shape[0]

    device_id_to_valid_length_node = {}

    fake_mode = get_fake_mode((*container_gm.parameters(), *container_gm.buffers()))

    for node in container_gm.graph.find_nodes(op="call_module"):
        sub_gm = getattr(container_gm, node.target)
        assert isinstance(sub_gm, GraphModule)

        if not _has_attention_mask_ancestor(node):
            # This submodule doesn't accept mask as an input.
            # valid length optimization cannot be applied.
            continue

        device_id = get_device_id(node)
        assert isinstance(device_id, mrw.DeviceId)

        # Valid length nodes should be added both to container gm and submodule gm for consistency.
        # And there should be exactly one pair of valid length nodes for each device id because
        # each submodule is expected to receive only nodes with same device id as an input in GraphModule conversion stage.
        _create_valid_length_node(sub_gm.graph, device_id, batch_size, fake_mode)
        if device_id not in device_id_to_valid_length_node:
            device_id_to_valid_length_node[device_id] = _create_valid_length_node(
                container_gm.graph, device_id, batch_size, fake_mode
            )
        valid_length_node_in_container_gm = device_id_to_valid_length_node[device_id]
        node.args = (*node.args, valid_length_node_in_container_gm)
        sub_gm.recompile()


def _get_output_consumer_info(
    node: Node, comp_supertask_kind: SuperTaskKind
) -> List[List[SuperTaskKind]]:
    to_visit: List[Tuple[Node, Optional[int]]] = [(user, None) for user in node.users]
    output_idx_to_users: DefaultDict[Optional[int], List[SuperTaskKind]] = defaultdict(list)

    # Traverse the graph to complete `output_idx_to_users`.
    while to_visit:
        cur_node, cur_idx = to_visit.pop()
        if is_getitem(cur_node):
            assert cur_idx is None
            _, output_idx = cur_node.args
            assert isinstance(output_idx, int)
            for user in cur_node.users:
                to_visit.append((user, output_idx))
        else:
            if cur_node.op == "output":
                user_kind = SuperTaskKind.OUTPUT
            else:
                assert cur_node.op == "call_module"
                if _is_comp_supertask(cur_node):
                    user_kind = comp_supertask_kind
                else:
                    assert _is_comm_supertask(cur_node)
                    assert isinstance(cur_node.target, SingleDeviceCommOp)
                    user_kind = cur_node.target.kind()
            output_idx_to_users[cur_idx].append(user_kind)

    tensor_meta = node.meta["tensor_meta"]
    if isinstance(tensor_meta, TensorMetadata):
        num_outputs = 1
    else:
        assert isinstance(tensor_meta, (tuple, list))
        num_outputs = len(tensor_meta)

    if None in output_idx_to_users:
        # `node` has only one output tensor
        assert isinstance(node.meta["tensor_meta"], TensorMetadata)
        assert len(output_idx_to_users) == 1
        output_idx_to_users[0] = output_idx_to_users.pop(None)

    assert len(output_idx_to_users) == num_outputs
    return [output_idx_to_users[i] for i in range(num_outputs)]


def _add_valid_length_info_if_possible(
    gm: GraphModule,
    compiler_config_context: CompilerConfigContext,
    graph_metadata_builder: "GraphMetadataBuilder",
) -> None:
    """Add valid length info to the graph metadata builder if valid_length node exists in the graph."""

    valid_length_node_indices = [
        idx
        for idx, node in enumerate(gm.graph.find_nodes(op="placeholder"))
        if is_valid_length_node(node)
    ]
    assert len(valid_length_node_indices) <= 1, "Multiple valid length nodes found in the graph."

    if not valid_length_node_indices:
        # Valid length node not found. It's not possible to add valid length info.
        return

    if not compiler_config_context.bucket:
        raise ValueError("`bucket` information is needed for generating valid length info.")
    is_prefill = compiler_config_context.bucket.is_prefill

    # atttention / causal mask node
    mask_node_and_idx = [
        (idx, node)
        for idx, node in enumerate(gm.graph.find_nodes(op="placeholder"))
        if is_attn_mask_node(node)
    ]
    if len(mask_node_and_idx) > 1:
        raise ValueError("Multiple mask nodes found in the graph.")

    valid_length_node_idx = valid_length_node_indices[0]

    graph_metadata_builder.set_valid_length(
        target_input_index=mask_node_and_idx[0][0],
        valid_length_input_index=valid_length_node_idx,
        valid_length_axis=compiler_config_context.model_metadata.attn_dim_in_mask(
            "prefill" if is_prefill else "decode"
        ),  # attn axis
        sparse_key_axis=compiler_config_context.model_metadata.batch_dim_in_mask,  # batch axis
        sparse_ratio_mean=DEFAULT_SPARSE_RATIO_MEAN,
        sparse_ratio_sigma=DEFAULT_SPARSE_RATIO_SIGMA,
        sparse_ratio_sorted=False,
    )


def _get_global_id_for_interm_tensor(node_in_container_gm: Node, idx: int) -> str:
    """Get a unique global id for the tensor node corresponding to certain position in the graph.
    This global id should be same if and only if nodes across multiple graphs corresponds to
    exactly same code.
    """
    # TODO: index-based method is fragile. Find better way.
    assert get_partition_info(node_in_container_gm)

    return hashlib.sha256(
        (
            get_partition_info(node_in_container_gm),
            idx,
        )
        .__repr__()
        .encode("utf-8")
    ).hexdigest()
