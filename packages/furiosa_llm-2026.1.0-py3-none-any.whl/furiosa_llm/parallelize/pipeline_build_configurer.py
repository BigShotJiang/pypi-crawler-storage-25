import abc
from typing import List, Optional, Sequence, Tuple

from furiosa_llm.models.config_types import AttentionBucket, LLMPartitioningConfig
from furiosa_llm.parallelize.layer_range import LayerRange
from furiosa_llm.parallelize.pipeline.next_gen import StageKind, Symbol, SymbolVal


# TODO: better name
class PipelineBuildConfigGenerator(abc.ABC):
    """Base class for pipeline build config generators."""

    @abc.abstractmethod
    def get_needed_buckets(
        self,
    ) -> List[AttentionBucket]:
        """Get the list of needed buckets for the pipeline."""
        ...

    @property
    @abc.abstractmethod
    def collapse_batch_seq_dim(
        self,
    ) -> bool:
        """Check if the batch and sequence dimensions should be collapsed in the tokenwise ops."""
        ...

    @abc.abstractmethod
    def get_task_symbol_values(
        self,
        bucket: AttentionBucket,
        layer_range: LayerRange,
    ) -> Optional[Tuple[SymbolVal, ...]]:
        """Get the actual symbol values for the task with given bucket and layer range if the task should be selected. Otherwise, return None."""
        ...

    @abc.abstractmethod
    def get_stage_info(self, layer_range: LayerRange) -> Tuple[StageKind, List[Symbol]]:
        """Get the symbols for the stage with given layer range."""
        ...

    @abc.abstractmethod
    def get_partitioning_config(
        self,
    ) -> Optional[LLMPartitioningConfig]:
        """Get the partitioning config for the pipeline."""
        ...


class ComposableKernelPipelineBuildConfigGenerator(PipelineBuildConfigGenerator):
    """Pipeline build config generator for composable kernel granularity pipelines."""

    def __init__(
        self,
        attention_buckets: Sequence[AttentionBucket],
        tokenwise_seq_lens: Sequence[int],
    ):
        self.attention_buckets = attention_buckets

        self._attn_bucket_set = set(attention_buckets)

        self.tokenwise_seq_lens = tokenwise_seq_lens
        self._calculate_buckets()

    def _calculate_buckets(self) -> None:
        """Calculate list of needed buckets for the pipeline."""
        self.needed_buckets = []

        # Add attention buckets
        for attn_bucket in self.attention_buckets:
            self.needed_buckets.append(attn_bucket)

        # Add tokenwise buckets
        self.tokenwise_buckets = set()
        # NOTE: The following constraint for `bucket.is_prefill` is a temporary workaround
        # to support compilation for tokenwise-kernel.
        # Prefill bucket of batch=1 is required specifically for compiling
        # the tokenwise-kernel. This constraint is expected to be resolved in the future.
        query_len_to_attn_bucket = {
            bucket.batch_size * bucket.input_ids_size: bucket
            for bucket in self.attention_buckets
            if bucket.is_prefill and bucket.batch_size == 1
        }
        for tokenwise_seq_len in self.tokenwise_seq_lens:
            # Skip seq lens that can be obtained from attention bucket graph.
            if bucket := query_len_to_attn_bucket.get(tokenwise_seq_len):
                # This tokenwise seq length exists in attention bucket pipeline
                pass
            else:
                bucket = AttentionBucket.prefill(1, tokenwise_seq_len)
                self.needed_buckets.append(bucket)
            self.tokenwise_buckets.add(bucket)

    def get_needed_buckets(self) -> List[AttentionBucket]:
        return self.needed_buckets

    @property
    def collapse_batch_seq_dim(self) -> bool:
        return True

    def get_task_symbol_values(
        self,
        bucket: AttentionBucket,
        layer_range: LayerRange,
    ) -> Optional[Tuple[SymbolVal, ...]]:
        if layer_range.is_attention and bucket in self._attn_bucket_set:
            # Attention task (batch_size, q_len, kv_len)
            return (
                SymbolVal(str(bucket.batch_size)),
                SymbolVal(str(bucket.input_ids_size)),
                SymbolVal(str(bucket.attention_size)),
            )
        elif not layer_range.is_attention and bucket in self.tokenwise_buckets:
            # Tokenwise task (q_len)
            return (SymbolVal(str(bucket.batch_size * bucket.input_ids_size)),)
        else:
            # This task is not selected.
            return None

    def get_stage_info(self, layer_range: LayerRange) -> Tuple[StageKind, List[Symbol]]:
        if layer_range.is_attention:
            # Attention task
            return (StageKind.ATTENTION, [Symbol("batch_size"), Symbol("q_len"), Symbol("kv_len")])
        else:
            return (StageKind.TOKENWISE, [Symbol("q_len")])

    def get_partitioning_config(self) -> Optional[LLMPartitioningConfig]:
        return LLMPartitioningConfig(
            building_block_granularity="kernel",
        )
