import abc
from abc import abstractmethod
import dataclasses
from typing import Dict, List, NamedTuple, Optional, Sequence, Tuple, Type, Union

import torch
from torch.fx import GraphModule
from typing_extensions import Literal, TypeAlias

from .block_slicer import (
    ModuleMarkConfig,
    PartitionInfo,
    _get_blockwise_sliced_color_bitmap_with_split_edges,
    convert_bitflag_metadata_to_binary_digit_based,
    get_block_slicing_edges,
    get_blockwise_sliced_color_bitmap_with_marker,
    get_kernelwise_sliced_color_bitmap_with_marker,
)
from .layer_range import Embedding, LayerRange, OutputHeadAndPostProcess, TransformerBlock

PartitionedGraphModule: TypeAlias = GraphModule
PartitionId: TypeAlias = int


class PartitioningResult(NamedTuple):
    node_name_to_partition_ids: Dict[str, Tuple[PartitionId, ...]]
    partition_infos: Optional[Dict[PartitionId, PartitionInfo]]


class GraphPartitioner(abc.ABC):
    """Abstract base class for fx graph partitioners."""

    @abstractmethod
    def get_module_mark_config(self) -> ModuleMarkConfig:
        """Get module mark configuration used when tracing the model.
        GraphModule generated with this configuration will be given to `partition_gm`.
        """
        ...

    @abstractmethod
    def partition_gm(
        self,
        gm: GraphModule,
    ) -> PartitioningResult:
        """Partition the given GraphModule and return the partitioning result."""
        ...


class TransformerBlockwisePartitioner(GraphPartitioner):
    """Split the graph module by transformer blocks. Each partition becomes a single transformer block with optional embedding or output head."""

    def __init__(
        self,
    ):
        pass

    def get_module_mark_config(self) -> ModuleMarkConfig:
        return ModuleMarkConfig(include_submodules_in_modulelists=True)

    def partition_gm(
        self,
        gm: GraphModule,
    ) -> PartitioningResult:
        node_to_color_bitflag, color_bitflag_to_partition_info = (
            get_blockwise_sliced_color_bitmap_with_marker(
                gm,
            )
        )
        node_to_color_bitmap, color_to_partition_info = (
            convert_bitflag_metadata_to_binary_digit_based(
                gm, node_to_color_bitflag, color_bitflag_to_partition_info
            )
        )
        assert color_to_partition_info

        # add layer range info to each partition info in `color_to_partition_info`.
        for i, color in enumerate(sorted(color_to_partition_info.keys())):
            if i == 0:
                layer_range = LayerRange(
                    start=Embedding(),
                    end=TransformerBlock(
                        idx=0,
                    ),
                )
            elif i == len(color_to_partition_info) - 1:
                layer_range = LayerRange(
                    start=TransformerBlock(idx=i),
                    end=OutputHeadAndPostProcess(),
                )
            else:
                layer_range = LayerRange(
                    start=TransformerBlock(idx=i),
                )
            color_to_partition_info[color] = dataclasses.replace(
                color_to_partition_info[color], layer_range=layer_range
            )

        return PartitioningResult(node_to_color_bitmap, color_to_partition_info)


class PatternMatchingBasedTransformerBlockwisePartitioner(GraphPartitioner):
    """Split the graph by transformer blocks. Each partition becomes a single transformer block with optional embedding or output head."""

    def __init__(
        self,
        original_model_type: Type[torch.nn.Module],
        *,
        embedding_layer_as_single_partition: bool,
    ):
        self.original_model_type = original_model_type
        self.embedding_layer_as_single_partition = embedding_layer_as_single_partition

    def get_module_mark_config(self) -> ModuleMarkConfig:
        # Mark nothing. This marker works without any module markers.
        return ModuleMarkConfig()

    def partition_gm(
        self,
        gm: GraphModule,
    ) -> PartitioningResult:
        slicing_edges = get_block_slicing_edges(
            gm, self.original_model_type, self.embedding_layer_as_single_partition
        )

        node_to_bitflag = _get_blockwise_sliced_color_bitmap_with_split_edges(gm, slicing_edges)
        node_to_color_bitmap, _ = convert_bitflag_metadata_to_binary_digit_based(
            gm, node_to_bitflag, None
        )

        return PartitioningResult(node_to_color_bitmap, None)


class KernelwisePartitioner(GraphPartitioner):
    """Split the graph by kernel. Each attention becomes one partition and contiguous tokenwise operations become another partition."""

    def __init__(self) -> None:
        pass

    def get_module_mark_config(self) -> ModuleMarkConfig:
        # For composable kernel case, mark embedding, attention layers, and decoder layers.
        # FIXME: make this robust. avoid hardcoding.
        return ModuleMarkConfig(
            # "embed_tokens" is a pattern used to capture the embedding module
            # from instances of model classes '~Model' (e.g., `Qwen3Model`).
            module_path_pattern=r"(.*self_attn\.attn)|(model\.embed_tokens)|(embed_tokens)",
            include_submodules_in_modulelists=True,
        )

    def partition_gm(
        self,
        gm: GraphModule,
    ) -> PartitioningResult:
        node_to_color_bitflag, color_bitflag_to_partition_info = (
            get_kernelwise_sliced_color_bitmap_with_marker(
                gm,
            )
        )
        node_to_color_bitmap, color_to_metadata = convert_bitflag_metadata_to_binary_digit_based(
            gm, node_to_color_bitflag, color_bitflag_to_partition_info
        )

        return PartitioningResult(node_to_color_bitmap, color_to_metadata)


class PartitionComposer(GraphPartitioner):
    """Partitioner that composes multiple sub partitions generated from given partitioners into a single partition."""

    def __init__(
        self,
        sub_partition_marker: GraphPartitioner,
        num_sub_partitions_per_partition: Union[int, Sequence[int]],
    ) -> None:
        self.sub_partition_marker = sub_partition_marker
        self.num_sub_partitions_per_partition = num_sub_partitions_per_partition

    def get_module_mark_config(self) -> ModuleMarkConfig:
        return self.sub_partition_marker.get_module_mark_config()

    def partition_gm(
        self,
        gm: GraphModule,
    ) -> PartitioningResult:
        """Composes the node-partition mapping and partition info from the sub partition marker into a new mapping and partition info."""

        node_to_original_partition_ids, original_partition_info = (
            self.sub_partition_marker.partition_gm(gm)
        )
        all_original_partition_ids = set(
            partition_id
            for belonging_partition_ids in node_to_original_partition_ids.values()
            for partition_id in belonging_partition_ids
        )

        # Create a mapping from original partition id to new partition id.
        if isinstance(self.num_sub_partitions_per_partition, Sequence):
            original_partition_id_to_new_partition_id = []

            acc = 0
            for i, num_blocks in enumerate(self.num_sub_partitions_per_partition):
                for _ in range(num_blocks):
                    original_partition_id_to_new_partition_id.append(i)
                acc += num_blocks

            if acc != len(all_original_partition_ids):
                raise ValueError(
                    f"`num_sub_partitions_per_partition` {self.num_sub_partitions_per_partition} does not match the number of partitions {len(all_original_partition_ids)}."
                )
        else:
            assert isinstance(self.num_sub_partitions_per_partition, int)
            original_partition_id_to_new_partition_id = [
                i // self.num_sub_partitions_per_partition
                for i in range(len(all_original_partition_ids))
            ]

        # Create new node-partition id mapping.
        node_to_new_partition_ids = {
            node: tuple(
                map(
                    lambda sub_partition_id: original_partition_id_to_new_partition_id[
                        sub_partition_id
                    ],
                    sub_partition_ids,
                )
            )
            for node, sub_partition_ids in node_to_original_partition_ids.items()
        }

        # Create new partition info.
        if original_partition_info is not None:
            new_partition_info = {}

            new_partition_to_original_partition_ids: Dict[PartitionId, List[PartitionId]] = {}
            for original_partition_id, new_partition_id in enumerate(
                original_partition_id_to_new_partition_id
            ):
                new_partition_to_original_partition_ids.setdefault(new_partition_id, []).append(
                    original_partition_id
                )

            for (
                new_partition_id,
                belonging_original_partitions,
            ) in new_partition_to_original_partition_ids.items():
                if len(belonging_original_partitions) == 1:
                    # If only one color belongs to this new color, just reuse original one.
                    new_partition_info[new_partition_id] = original_partition_info[
                        belonging_original_partitions[0]
                    ]
                    continue

                # Merge layer ranges of all original partitions that belong to this new partition.
                first_color_layer_range = original_partition_info[
                    belonging_original_partitions[0]
                ].layer_range
                last_color_layer_range = original_partition_info[
                    belonging_original_partitions[-1]
                ].layer_range

                if first_color_layer_range is not None and last_color_layer_range is not None:
                    new_layer_range = LayerRange(
                        start=first_color_layer_range.start,
                        end=last_color_layer_range.get_end(),
                    )
                else:
                    new_layer_range = None
                new_partition_info[new_partition_id] = PartitionInfo(
                    layer_range=new_layer_range,
                )
        else:
            new_partition_info = None

        return PartitioningResult(node_to_new_partition_ids, new_partition_info)


def get_graph_partitioner(
    partition_granularity: Literal["transformer_block", "kernel"],
    *,
    embedding_layer_as_single_partition: bool,
    original_model_type: Optional[Type[torch.nn.Module]] = None,
    use_module_marker: bool = True,
) -> GraphPartitioner:
    """Get graph partitioner based on the partition granularity.

    Args:
        partition_granularity: The granularity to use for partitioning. It can be either "transformer_block" or "kernel".
        embedding_layer_as_single_partition: If True, embedding layer becomes a single independent partition.
        original_model_type: Original model class type of the model. For pattern matching based partitioners, the original model type is required.
        use_module_marker: If True, return module marker based partitioner.

    Returns:
        GraphPartitioner: The graph partitioner instance.
    """
    if partition_granularity == "transformer_block":
        if use_module_marker:
            if embedding_layer_as_single_partition:
                raise NotImplementedError(
                    "`embedding_layer_as_single_partition` is not implemented for module marker based partitioning method."
                )
            return TransformerBlockwisePartitioner()
        else:
            if original_model_type is None:
                raise ValueError(
                    "`original_model_type` must be provided for pattern matching method."
                )
            return PatternMatchingBasedTransformerBlockwisePartitioner(
                original_model_type,
                embedding_layer_as_single_partition=embedding_layer_as_single_partition,
            )
    elif partition_granularity == "kernel":
        if embedding_layer_as_single_partition:
            raise ValueError(
                "`embedding_as_single_layer` cannot be used with kernelwise partitioning."
            )
        if not use_module_marker:
            raise ValueError("`use_module_marker` must be True for kernelwise partitioning.")
        return KernelwisePartitioner()
    else:
        raise ValueError(f"Invalid partition granularity: {partition_granularity}")
