from dataclasses import dataclass
import enum
from typing import Optional


class SubLayerType(str, enum.Enum):
    QkvProjection = "qkv_projection"
    Attention = "attention"
    FeedForward = "feed_forward"
    OutputProjection = "output_projection"


class LayerType: ...


@dataclass(frozen=True)
class Embedding(LayerType):
    """Represents the 'Embedding' variant."""

    pass


@dataclass(frozen=True)
class TransformerBlock(LayerType):
    """Represents the 'TransformerBlock' variant with its data."""

    idx: int
    sub_layer: Optional[SubLayerType] = None


@dataclass(frozen=True)
class OutputHeadAndPostProcess(LayerType):
    """Represents the 'OutputHeadAndPostProcess' variant."""

    pass


@dataclass(frozen=True)
class LayerRange:
    start: LayerType
    end: Optional[LayerType] = None

    def get_end(self) -> LayerType:
        """Returns the end layer type, or the start layer type if end is None."""
        return self.end if self.end is not None else self.start

    @property
    def is_attention(self) -> bool:
        """Checks if the layer range is an attention layer."""
        return (
            isinstance(self.start, TransformerBlock)
            and self.start.sub_layer is SubLayerType.Attention
            and self.end is None
        )

    @property
    def is_embedding(self) -> bool:
        """Checks if the layer range is an embedding layer."""
        return isinstance(self.start, Embedding) and (
            self.end is None
            or (
                isinstance(self.end, TransformerBlock)
                and self.end.idx == 0
                and self.end.sub_layer is SubLayerType.QkvProjection
            )
        )

    @property
    def is_inter_tr_block_tokenwise(self) -> bool:
        """Checks if the layer range spans from the output projection of one transformer block
        to the QKV projection of the succeeding transformer block."""
        return (
            isinstance(self.start, TransformerBlock)
            and isinstance(self.end, TransformerBlock)
            and self.start.idx + 1 == self.end.idx
            and self.start.sub_layer is SubLayerType.OutputProjection
            and self.end.sub_layer is SubLayerType.QkvProjection
        )

    def is_last_tr_block_projection_to_output_head(self, num_total_layers: int) -> bool:
        """
        Checks if the layer range spans from the output projection of last transformer block
        to the output head.
        """
        return (
            isinstance(self.start, TransformerBlock)
            and self.start.idx + 1 == num_total_layers
            and self.start.sub_layer is SubLayerType.OutputProjection
            and isinstance(self.end, OutputHeadAndPostProcess)
        )

    def is_tokenwise(self, num_total_layers: int) -> bool:
        """Checks if the layer range is a tokenwise layer."""
        conditions = [
            self.is_embedding,
            self.is_inter_tr_block_tokenwise,
            self.is_last_tr_block_projection_to_output_head(num_total_layers),
        ]
        assert sum(conditions) <= 1, "Only one condition should be true for tokenwise check"
        return any(conditions)
