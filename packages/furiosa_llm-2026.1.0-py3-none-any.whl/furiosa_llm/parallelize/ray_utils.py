import logging
import os
import threading
import time
from typing import Any, Dict, List, Optional, Union

import ray
from ray.actor import ActorHandle
from tqdm import tqdm


@ray.remote
class LogActor:
    """
    Actor for collecting logs from Ray workers.
    """

    def __init__(self):
        self._buffer: List[tuple[Any, Optional[Dict[str, int]]]] = []

    def add_buffer(self, msg: Any, meta: Optional[Dict[str, int]] = None):
        self._buffer.append((msg, meta))

    def flush(self) -> List[tuple[Any, Optional[Dict[str, int]]]]:
        if not self._buffer:
            return []
        logs = self._buffer
        self._buffer = []
        return logs


class RayForwardHandler(logging.Handler):
    def __init__(self, log_actor: ActorHandle[LogActor]):
        super().__init__()
        self.log_actor = log_actor
        self.meta = {"pid": os.getpid()}

    def emit(self, record):
        msg = self.format(record)
        self.log_actor.add_buffer.remote(msg, self.meta)


def drain_logs(log_actor: ActorHandle[LogActor]) -> None:
    """
    flush the logs from the log actor and write them to stdout (by tqdm.write).
    """
    logs = ray.get(log_actor.flush.remote())
    for msg, meta in logs:
        prefix = ""
        if meta:
            prefix = "[" + " ".join(f"{k}={v}" for k, v in meta.items()) + "] "

        tqdm.write(prefix + msg)


def in_ray_worker() -> bool:
    """
    Checks if the current process is a Ray worker.
    """
    try:
        import ray

        return ray.is_initialized()
    except Exception:
        return False


def setup_logging(
    level: int = logging.WARNING,
    log_actor: Optional[ActorHandle[LogActor]] = None,
    *,
    capture_fds: bool = False,
) -> Optional["FdForwarder"]:
    """
    Sets up logging specific to Ray workers.
    """
    logging.basicConfig(
        level=level,
    )
    logging.captureWarnings(True)
    root = logging.getLogger()

    for h in list(root.handlers):
        root.removeHandler(h)

    handler: Union[logging.Handler, RayForwardHandler]
    if in_ray_worker() and log_actor is not None:
        # Ray worker: forward only
        handler = RayForwardHandler(log_actor)
    else:
        # local / driver
        handler = logging.StreamHandler()

    formatter = logging.Formatter("[%(levelname)s][%(name)s] %(message)s")
    handler.setFormatter(formatter)
    root.addHandler(handler)

    if in_ray_worker() and log_actor is not None and capture_fds:
        forwarder = FdForwarder(log_actor)
        forwarder.start()
        return forwarder

    return None


class FdForwarder:
    """
    A utility to intercept and forward stdout/stderr file descriptors (FDs) to a LogActor.

    This is particularly useful for capturing output from our EDF-compilation tool (npu-tools), and redirecting it to a centralized logging mechanism.
    """

    def __init__(
        self,
        log_actor: ActorHandle[LogActor],
        capture_stdout: bool = True,
        capture_stderr: bool = True,
    ):
        self.log_actor = log_actor
        self.capture_stdout = capture_stdout
        self.capture_stderr = capture_stderr
        self._threads: List[threading.Thread] = []
        self._stop_event = threading.Event()
        self._saved_fds: Dict[int, int] = {}
        self._read_fds: Dict[int, int] = {}

    def _start_one(self, fd: int, fd_name: str) -> None:
        read_fd, write_fd = os.pipe()
        os.set_blocking(read_fd, False)

        saved_fd = os.dup(fd)
        os.dup2(write_fd, fd)
        os.close(write_fd)

        self._saved_fds[fd] = saved_fd
        self._read_fds[fd] = read_fd

        meta = {"pid": os.getpid(), "fd": fd_name}

        def _reader():
            buffer = ""
            while not self._stop_event.is_set():
                try:
                    data = os.read(read_fd, 4096)
                except BlockingIOError:
                    time.sleep(0.05)
                    continue
                if not data:
                    time.sleep(0.05)
                    continue
                buffer += data.decode(errors="replace")
                if "\n" in buffer:
                    lines = buffer.split("\n")
                    buffer = lines.pop()
                    for line in lines:
                        if line:
                            self.log_actor.add_buffer.remote(line, meta)
            if buffer:
                self.log_actor.add_buffer.remote(buffer, meta)

        thread = threading.Thread(target=_reader, daemon=True)
        thread.start()
        self._threads.append(thread)

    def start(self) -> None:
        if self.capture_stdout:
            self._start_one(1, "stdout")
        if self.capture_stderr:
            self._start_one(2, "stderr")

    def stop(self) -> None:
        """
        Stop forwarding, restore original file descriptors, and clean up resources.

        This method:
        - Signals reader threads to stop.
        - Restores any redirected file descriptors to their original targets.
        - Closes all duplicated and pipe read file descriptors.
        - Waits briefly for reader threads to finish.
        """
        self._stop_event.set()

        # Restore and close saved file descriptors
        for fd, saved_fd in self._saved_fds.items():
            try:
                os.dup2(saved_fd, fd)
            except OSError as e:
                logging.debug(f"Failed to restore FD {fd} from saved FD {saved_fd}: {e}")
            finally:
                try:
                    os.close(saved_fd)
                except OSError as e:
                    logging.debug(f"Failed to close saved FD {saved_fd}: {e}")

        # Close read file descriptors from pipes
        for fd, read_fd in self._read_fds.items():
            try:
                os.close(read_fd)
            except OSError as e:
                logging.debug(f"Failed to close read FD {read_fd}: {e}")

        # Wait for reader threads to finish
        for thread in self._threads:
            thread.join(timeout=1.0)
