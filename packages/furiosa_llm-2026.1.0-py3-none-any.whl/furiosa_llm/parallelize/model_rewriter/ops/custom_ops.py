import torch
import torch.lib


@torch.library.custom_op("furiosa::gather_i32", mutates_args=())
def gather_i32(x: torch.Tensor, dim: int, index: torch.Tensor, sparse_grad: bool) -> torch.Tensor:
    """torch.ops.aten.gather.default that receives i32 index tensor."""
    assert index.dtype == torch.int32
    return torch.ops.aten.gather.default(x, dim, index.to(torch.int64), sparse_grad=sparse_grad)


@torch.library.register_fake("furiosa::gather_i32")
def _gather_i32_fake(
    x: torch.Tensor, dim: int, index: torch.Tensor, sparse_grad: bool
) -> torch.Tensor:
    return torch.ops.aten.gather.default(x, dim, index.to(torch.int64), sparse_grad=sparse_grad)


@torch.library.custom_op("furiosa::module_marker", mutates_args=())
def module_marker(
    x: torch.Tensor,
    kind: str,  # "input", "output"
    module_path: str,
    module_class: str,
    arg_name: str,
) -> torch.Tensor:
    return x.clone()


@torch.library.register_fake(
    "furiosa::module_marker",
)
def module_marker_fake(
    x: torch.Tensor,
    kind: str,
    module_path: str,
    module_class: str,
    arg_name: str,
) -> torch.Tensor:
    return x
