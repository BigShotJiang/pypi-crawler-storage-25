import enum
from typing import List, Optional, Union

from pydantic import BaseModel
from typing_extensions import Self

from furiosa_llm.models.config_types import AttentionBucket, SchedulerConfig, TokenwiseBucket
from furiosa_llm.sampling_params import GuidedDecodingBackend


class GeneratorFrontendConfig(BaseModel):
    num_speculative_tokens: Optional[int]


class GeneratorConfig(BaseModel):
    scheduler_config: SchedulerConfig
    frontend_config: GeneratorFrontendConfig
    struct_output_backend: GuidedDecodingBackend

    def to_json(self) -> str:
        return self.model_dump_json()

    @classmethod
    def from_json(cls, val: str) -> Self:
        return cls.model_validate_json(val, strict=True)


class CompositionType(str, enum.Enum):
    COMPOSED = "composed"
    KERNELWISE = "kernelwise"

    @classmethod
    def from_str(cls, s: str):
        s = s.lower()
        for member in cls:
            if member.value == s:
                return member
        raise ValueError(f"Invalid CompositionType: {s}")


class ComposableKernelMetadata(BaseModel, frozen=True):
    attention_buckets: List[AttentionBucket]
    tokenwise_buckets: List[TokenwiseBucket]
    composition_type: CompositionType

    def __init__(
        self,
        attention_buckets: List[AttentionBucket],
        tokenwise_buckets: List[Union[int, TokenwiseBucket]],
        composition_type: CompositionType,
    ):
        tokenwise_bucket_objects = [
            TokenwiseBucket(input_size=input_size) if isinstance(input_size, int) else input_size
            for input_size in tokenwise_buckets
        ]
        super().__init__(
            attention_buckets=attention_buckets,
            tokenwise_buckets=tokenwise_bucket_objects,
            composition_type=composition_type,
        )

    def to_json(self) -> str:
        return self.model_dump_json()


class ComposedBuckets(BaseModel, frozen=True):
    attention_buckets: List[AttentionBucket]
    tokenwise_bucket: TokenwiseBucket

    def to_json(self) -> str:
        return self.model_dump_json()

    @classmethod
    def from_json(cls, val: str) -> Self:
        return cls.model_validate_json(val, strict=True)

    def to_symbol(self) -> List[str]:
        attention_symbols = ["batch_size", "q_len", "kv_len"]
        tokenwise_symbols = ["q_len"]
        return tokenwise_symbols + attention_symbols * len(self.attention_buckets)

    def to_symbol_values(self) -> str:
        attention_symbol_values = [
            ",".join(
                [str(bucket.batch_size), str(bucket.attention_size), str(bucket.kv_cache_size)]
            )
            for bucket in self.attention_buckets
        ]
        tokenwise_symbol_values = [str(self.tokenwise_bucket)]
        return "|".join(tokenwise_symbol_values + attention_symbol_values)


PipelineMetadata = ComposableKernelMetadata
