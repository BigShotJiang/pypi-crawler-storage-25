from contextlib import ExitStack
import copy
from copy import deepcopy
import functools
import logging
import os
from pathlib import Path
import sys
import typing
from typing import Any, Dict, Final, Iterable, List, Mapping, Optional, Sequence, Tuple, Type, Union

import cachetools
from cachetools.keys import hashkey
from optimum.modeling_base import OptimizedModel
from pydantic import BaseModel, Field, PrivateAttr, model_validator
import torch
import transformers
from transformers.configuration_utils import PretrainedConfig
from transformers.modeling_utils import PreTrainedModel
from transformers.models.auto.configuration_auto import AutoConfig
from transformers.models.auto.modeling_auto import MODEL_FOR_CAUSAL_LM_MAPPING
from transformers.quantizers.auto import AutoQuantizationConfig
from transformers.trainer_utils import set_seed
from transformers.utils.quantization_config import FineGrainedFP8Config, Mxfp4Config
from typing_extensions import Self

from furiosa.models.common.export.serve import CausalModelServer
from furiosa_llm.models.config_types import AttentionBucket
from furiosa_llm.models.tasks import (
    EMBED,
    GENERATE,
    GENERATION_TASKS,
    POOLING_TASKS,
    SCORE,
    TEXT_GENERATION,
    GenerationTask,
    PoolingTask,
)
from furiosa_llm.optimum import (
    AttentionType,
    OptimizationConfig,
    QDtype,
    QuantizationConfig,
    modeling,
)
from furiosa_llm.optimum.modeling import (
    AutoModel,
    AutoModelForCausalLM,
    _FuriosaBaseAutoModelClass,
    get_optimized_cls,
    is_model_path,
    set_default_torch_dtype,
)
from furiosa_llm.optimum.types import LLMConfig

from ..utils import get_logger_with_tz, zip_equal
from .config_types import GeneratorConfig, PipelineMetadata
from .utils import generate_input_sample

# Moved from tasks.py to avoid circular imports (tasks.py -> modeling.py -> tasks.py)
TASK_TYPE_TO_AUTO_MODEL_CLASS: Final[Dict[str, Type[OptimizedModel]]] = {
    GENERATE: AutoModelForCausalLM,
    TEXT_GENERATION: AutoModelForCausalLM,
    EMBED: AutoModel,
    SCORE: AutoModelForCausalLM,
}

if typing.TYPE_CHECKING:
    from furiosa_llm.parallelize.pipeline.types import Pipeline

DEFAULT_SEED_VALUE: Final = 42

# The maximum number of `Model.pretrained_models` kept.
# A custom pytest hook is used to group parametrized tests to work around this limit.
# Note that this should be at least 2 because quantized models recursively load base models!
PRETRAINED_MODEL_CACHE_SIZE: Final = 2

logger = get_logger_with_tz(logging.getLogger(__name__))


# TODO : currently assignment of default task onto pretrained id is done by hard-coded id string match
# as follows. We need to resolve such hard-coding
SUPPORTED_EMBEDDING_MODEL: Final[List[str]] = [
    "Qwen/Qwen3-Embedding-8B",
]

SUPPORTED_SCORE_MODEL: Final[List[str]] = [
    "Qwen/Qwen3-Reranker-8B",
]


# Cache based on `pretrained_id` and `revision` only.
@cachetools.cached(
    cache=cachetools.LRUCache(128),
    key=lambda pretrained_id, trust_remote_code, revision: hashkey(pretrained_id, revision),
)
def get_config_from_pretrained_id(
    pretrained_id: Union[str, Path],
    trust_remote_code: Optional[bool],
    revision: Optional[str],
) -> PretrainedConfig:
    return AutoConfig.from_pretrained(
        pretrained_id, trust_remote_code=trust_remote_code, revision=revision
    )


class DummyModel(torch.nn.Module):
    def __init__(self, batch_size: int = 1):
        super(DummyModel, self).__init__()
        self.linear1 = torch.nn.Linear(16, batch_size)

    def forward(self, x):
        return self.linear1(x)


def get_model_cls_from_pretrained_id(
    pretrained_id: Union[str, Path],
    trust_remote_code: Optional[bool],
    revision: Optional[str] = None,
    task_type: Optional[str] = None,
) -> Type[PreTrainedModel]:
    model_config = get_config_from_pretrained_id(pretrained_id, trust_remote_code, revision)
    supported_architectures = getattr(model_config, "architectures", [])

    if task_type:
        if auto_model_cls := TASK_TYPE_TO_AUTO_MODEL_CLASS.get(task_type):
            return auto_model_cls.find_model_class(
                pretrained_id,
                model_config,
                trust_remote_code=trust_remote_code,
            )
        else:
            raise NotImplementedError(f"Unsupported task_type: {task_type}")
    else:
        if len(supported_architectures) != 1:
            raise ValueError(
                f"Task type not given, but multiple architectures found: {supported_architectures}"
            )

        if model_cls := getattr(transformers, supported_architectures[0], None):
            return model_cls

        # Model should be loaded with remote code.
        if not hasattr(model_config, "auto_map"):
            raise ValueError(
                f"Model {pretrained_id} is not a local model, but does not have an auto map in config."
            )
        auto_class_names = [
            auto_class_name
            for auto_class_name, class_ref in model_config.auto_map.items()
            if class_ref.rsplit('.', maxsplit=1)[-1] == supported_architectures[0]
        ]
        assert len(auto_class_names) == 1
        auto_class_name = auto_class_names[0]
        if not (module_finder := getattr(modeling, auto_class_name)):
            raise ValueError(f"Unsupported auto model class type: {auto_class_name}")
        assert issubclass(module_finder, _FuriosaBaseAutoModelClass)
        return module_finder.find_model_class(
            pretrained_id,
            model_config,
            trust_remote_code=trust_remote_code,
        )


def get_default_task_type_from_pretrained_id(
    pretrained_id: str, trust_remote_code: Optional[bool], revision: Optional[str] = None
) -> Union[GenerationTask, PoolingTask]:
    if pretrained_id in SUPPORTED_EMBEDDING_MODEL:
        return EMBED  # type: ignore[return-value]
    elif pretrained_id in SUPPORTED_SCORE_MODEL:
        return SCORE  # type: ignore[return-value]
    model_cls = get_model_cls_from_pretrained_id(pretrained_id, trust_remote_code, revision)
    if model_cls in MODEL_FOR_CAUSAL_LM_MAPPING.values():
        return GENERATE  # type: ignore[return-value]
    else:
        raise ValueError(f"cannot set task_type automatically for {model_cls}")


def download_model_and_get_hash(model_id: str, revision: str) -> str:
    """
    Extract the commit SHA from the huggingface_hub snapshot directory path.
    For example: .../snapshots/11c5a3d5811f50298f278a704980280950aedb10/config.json
    """
    from huggingface_hub import snapshot_download

    assert not is_model_path(model_id), "must be called when the model id is given"
    path = snapshot_download(repo_id=model_id, repo_type="model", revision=revision)

    p = Path(path)
    parts = p.parts
    if "snapshots" in parts:
        i = parts.index("snapshots")
        if i + 1 < len(parts):
            return parts[i + 1]

    raise ValueError("Could not find commit hash in snapshot path.")


def calculate_dir_hashsum(path: os.PathLike) -> str:
    import time

    import blake3

    BLOCK_SIZE: int = 8192
    start_ts = time.perf_counter()
    hasher = blake3.blake3()
    path = Path(path)
    if not path.is_dir():
        raise ValueError(f"{path} is not a directory")

    # Collect all files recursively, sort for determinism
    files = sorted([p for p in path.rglob("*") if p.is_file()])
    total_files = len(files)
    total_bytes = 0

    # Calculate the hashsum of all found files
    for file in files:
        # Update with relative path for uniqueness
        rel_path = str(file.relative_to(path)).encode()
        hasher.update(rel_path)
        # Update with file content
        with open(file, "rb") as f:
            while True:
                chunk = f.read(BLOCK_SIZE)
                if not chunk:
                    break
                hasher.update(chunk)
                total_bytes += len(chunk)

    digest = hasher.hexdigest()
    elapsed = time.perf_counter() - start_ts
    mb = total_bytes / (1024 * 1024)
    mbps = (mb / elapsed) if elapsed > 0 else 0.0

    logger.info(
        "Calculated the hashsum in %.3fs for '%s' (files=%d, size=%.2f MB, throughput=%.2f MB/s)",
        elapsed,
        str(path),
        total_files,
        mb,
        mbps,
    )
    return digest


@functools.total_ordering
class ModelMetadata(BaseModel):
    # TODO - Rename pretrained_id to distinguish two roles: a model_id to choose the LLM
    # optimization and a Hub repo ID for model weights
    pretrained_id: str  # Canonical model ID
    # TODO: Rename the argument `task_type` to `task` for consistency.
    # Be cautious of potential breaking changes in `artifact.json`.
    task_type: Optional[GenerationTask | PoolingTask] = None
    llm_config: LLMConfig = Field(default_factory=LLMConfig)
    hf_configs: Dict[str, Any] = Field(default_factory=dict)
    # path to load pre-trained model weights (optional)
    model_weight_path: Optional[os.PathLike] = None
    trust_remote_code: Optional[bool] = None

    # If True, the model uses the binary sequence classification head for optimization
    use_binary_seq_class: bool = False

    # FIXME(elpis): This field is not serialized in artifact.json.
    # This field is used as a workaround to avoid fetching config.json from HF using pretrained_id.
    # Fetching config.json using pretrained_id is unnecessary, since it is already present in the downloaded artifact.
    # Remove this when LLM-1303 is resolved.
    model_id_or_path: Union[str, Path] = ""

    # Below fields are not serialized in artifact.json.
    # So, they exist only in Python part and Rust part shouldn't rely on them.
    _revision: Optional[str] = PrivateAttr(default=None)
    # Hash sum via blake3, huggingface git commit, or pretrained_id (only for tests)
    _weights_hash: Optional[str] = PrivateAttr(default=None)

    @model_validator(mode='after')
    def validate_model_metadata(self):
        if self.task_type is None:
            # Here, we cannot use _model_id_or_path and _revision because PrivateAttr
            # must be set after __init__. But, it's ok now because we just get a task type here.
            # TODO: For more precise behavior, we need to use both _model_id_or_path and _revision.
            #  Fine-tuned models may be able to support different tasks.
            self.task_type = get_default_task_type_from_pretrained_id(
                self.pretrained_id, self.trust_remote_code
            )
        assert self.task_type in (
            GENERATION_TASKS + POOLING_TASKS
        ), f"unsupported task_type : {self.task_type}"
        return self

    @property
    @functools.lru_cache
    def model_cls(self) -> Type[PreTrainedModel]:
        return get_model_cls_from_pretrained_id(
            self.model_id_or_path, self.trust_remote_code, self._revision, self.task_type
        )

    @property
    def num_hidden_layers(self) -> int:
        return (
            self.config_dict.get("num_hidden_layers")
            or self.config_dict.get("num_layers")
            or self.config_dict["n_layer"]
        )

    @property
    def attention_type(self) -> AttentionType:
        return self.llm_config.optimization_config.attention_type

    @property
    def optimize_options(self) -> OptimizationConfig:
        return self.llm_config.optimization_config

    @property
    def quantization_config(self) -> Optional[QuantizationConfig]:
        return self.llm_config.quantization_config

    def __init__(
        self,
        pretrained_id: str,
        task_type: Optional[str] = None,
        llm_config: LLMConfig = LLMConfig(),
        hf_configs: Dict = {},
        model_weight_path: Optional[os.PathLike] = None,
        trust_remote_code: Optional[bool] = None,
        # model id or path for weights
        model_id_or_path: Optional[Union[str, Path]] = None,
        revision: Optional[str] = None,
        use_binary_seq_class: bool = False,
    ):
        super(ModelMetadata, self).__init__(
            pretrained_id=pretrained_id,
            task_type=task_type,
            llm_config=llm_config,
            hf_configs=hf_configs,
            model_weight_path=model_weight_path,
            trust_remote_code=trust_remote_code,
            model_id_or_path=model_id_or_path or pretrained_id,
        )
        # pretrained_id is allowed only for tests
        self._revision = revision
        self.use_binary_seq_class = use_binary_seq_class
        self._update_quantization_config_from_hf_config()

        # If the model is not quantized and can be casted to bfloat16, enable auto bf16 cast.
        if not self.quantization_config and (
            (self.config_dict.get("torch_dtype") or self.config_dict.get("dtype")) == "bfloat16"
        ):
            self._enable_auto_bfloat16_cast()

    def _update_quantization_config_from_hf_config(self, overwrite: bool = False) -> None:
        if hf_quant_config := getattr(self.config, "quantization_config", None):
            quantization_config = self._get_quantization_config_from_hf_quant_config(
                hf_quant_config
            )
            if (
                self.quantization_config
                and self.quantization_config != quantization_config
                and not overwrite
            ):
                raise ValueError(
                    "Two quantization configs (from hf model config and `llm_config`) are given at the same time."
                    "Please make sure exactly one of them is given."
                )

            self.llm_config = self.llm_config.with_quantization_config(quantization_config)

    def with_hf_configs(self, hf_configs: Mapping[str, Any]) -> Self:
        new_hf_configs = deepcopy(self.hf_configs)
        new_hf_configs.update(hf_configs)
        copied = self.model_copy(
            update={
                "hf_configs": new_hf_configs,
            },
            deep=True,
        )
        copied._update_quantization_config_from_hf_config(overwrite=True)
        return copied

    def with_quantization_config(self, quantization_config: QuantizationConfig) -> Self:
        return self.model_copy(
            update={
                "llm_config": self.llm_config.with_quantization_config(quantization_config),
            },
            deep=True,
        )

    @staticmethod
    def _get_quantization_config_from_hf_quant_config(
        hf_quant_config: Dict[str, Any],
    ) -> QuantizationConfig:
        quant_config = AutoQuantizationConfig.from_dict(hf_quant_config)
        if isinstance(quant_config, Mxfp4Config):
            if quant_config.dequantize:
                weight_dtype = QDtype.BF16
            else:
                weight_dtype = QDtype.MXFP4
            return QuantizationConfig(
                weight=weight_dtype,
                activation=QDtype.BF16,
                kv_cache=QDtype.BF16,
            )
        elif isinstance(quant_config, FineGrainedFP8Config):
            return QuantizationConfig(
                weight=QDtype.FP8,
                activation=QDtype.BF16,
                kv_cache=QDtype.BF16,
            )
        else:
            raise NotImplementedError(f"Unsupported quantization config type: {type(quant_config)}")

    def __str__(self):
        name = str(self.model_id_or_path).rsplit("/", maxsplit=1)[-1]

        return "{}_{}L{}{}".format(
            name,
            self.get_num_hidden_layers(),
            f"_{self.get_optimized_cls().__module__}",
            f"_{self.quantization_config}" if self.is_quantized else "",
        )

    @property
    def name(self):
        return self.__str__()

    @property
    def __hash_key(self):
        """A hashable key to uniquely identify the model metadata."""

        # Convert the nested values to hashable types in a recursively way
        def hashable_dict(d):
            return frozenset(
                (
                    k,
                    (
                        hashable_dict(v)
                        if isinstance(v, dict)
                        else tuple(v) if isinstance(v, list) else v
                    ),
                )
                for k, v in d.items()
            )

        hashable_hf_configs = {
            k: (hashable_dict(v) if isinstance(v, dict) else tuple(v) if isinstance(v, list) else v)
            for k, v in self.hf_configs.items()
        }

        return (
            self.model_id_or_path,
            self.task_type,
            self.hf_configs.get("num_hidden_layers"),
            self.attention_type,
            self.optimize_options,
            self.quantization_config,
            frozenset(hashable_hf_configs.items()),
        )

    def __eq__(self, other):
        if not isinstance(other, ModelMetadata):
            return False
        return self.__hash_key == other.__hash_key

    def __lt__(self, other):
        if not isinstance(other, ModelMetadata):
            return NotImplemented
        return self.__hash_key < other.__hash_key

    def __hash__(self):
        return hash(self.__hash_key)

    def get_num_hidden_layers(self) -> int:
        """Retrieve the number of hidden layers in the model.

        If the number of hidden layers was specified during initialization, it returns that value.
        Otherwise, it returns the total number of layers in the model variant.

        Returns:
            int: The number of hidden layers.

        Raises:
            ValueError: If the number of layers in the model variant is unknown.
        """
        return self.hf_configs.get("num_hidden_layers", self.full_layer_count)

    @property
    def is_generative_model(self) -> bool:
        return self.task_type in GENERATION_TASKS

    @property
    def kv_cache_torch_dtype(self) -> Optional[torch.dtype]:
        return self.kv_cache_dtype.to_torch_dtype() if self.kv_cache_dtype else None

    @property
    def kv_cache_dtype(self) -> Optional[QDtype]:
        if not self.is_generative_model:
            return None
        if self.quantization_config:
            return self.quantization_config.kv_cache
        return QDtype.FP32

    @property
    def is_quantized(self) -> bool:
        return self.quantization_config is not None

    def _enable_auto_bfloat16_cast(self) -> None:
        if self.is_generative_model:
            quant_config = QuantizationConfig.w_16_a_16_kv_16()
        else:
            quant_config = QuantizationConfig.w_16_a_16()
        self.llm_config = self.llm_config.with_quantization_config(quant_config)

    @property
    def full_layer_count(self) -> int:
        config = get_config_from_pretrained_id(
            self.model_id_or_path, self.trust_remote_code, self._revision
        )

        if full_layer_cnt := getattr(
            config, "num_hidden_layers", getattr(config, "n_layers", None)
        ):
            return full_layer_cnt
        raise ValueError(f"Unknown number of hidden layers for {self}")

    @property
    def config(self) -> PretrainedConfig:
        config_original: PretrainedConfig = get_config_from_pretrained_id(
            self.model_id_or_path, self.trust_remote_code, self._revision
        )
        config = copy.deepcopy(config_original)

        # Some `PretrainedConfig` types may have non-standard attribute names,
        # so we use the config's `attribute_map` to validate key names.
        attribute_map_of_config = getattr(config, "attribute_map", {})
        valid_config_attributes = {*config.__dict__.keys(), *attribute_map_of_config.keys()}
        for key, val in self.hf_configs.items():
            if key not in valid_config_attributes:
                logger.warning(
                    f"{key} in hf_configs is not valid attribute of {type(config_original)}, and it will be ignored."
                )
            setattr(config, key, val)

        return config

    @property
    def config_dict(self) -> Dict[str, Any]:
        return self.config.to_dict()

    def get_optimized_cls(self) -> Type[torch.nn.Module]:
        return get_optimized_cls(self.model_cls, self.task_type, self.use_binary_seq_class)

    @property
    def model_qname(self) -> str:
        cls_type = self.get_optimized_cls()
        return f"{cls_type.__module__}.{cls_type.__name__}"

    def ensure_model_and_update_weight_hash(self):
        if is_model_path(self.model_id_or_path):
            if self._revision is not None:
                logging.warning("Ignoring Huggingface model revision because the model is local.")
            self._revision = None
            self._weights_hash = calculate_dir_hashsum(self.model_id_or_path)
        else:
            self._revision = download_model_and_get_hash(self.model_id_or_path, self._revision)
            self._weights_hash = self._revision

    @functools.lru_cache(maxsize=1)
    def _random_weight_model(
        self,
        seed: int,
        run_gc: bool,
    ) -> torch.nn.Module:
        # FIXME: This is a workaround to reduce memory usage
        self._pretrained_model.cache_clear()
        if run_gc:
            import gc

            gc.collect()
        set_seed(seed)
        print(f"\x1b[1;36m(Creating {self} with random weights)\x1b[0m", end="", file=sys.stderr)
        sys.stderr.flush()

        contexts = []
        if self.quantization_config and self.quantization_config.is_bf16:
            contexts.append(set_default_torch_dtype(torch.bfloat16))
        with ExitStack() as stack:
            for ctx in contexts:
                stack.enter_context(ctx)

            config = self.config
            optimized_cls = self.get_optimized_cls()
            if issubclass(optimized_cls, PreTrainedModel):
                model: torch.nn.Module = optimized_cls(config=config)
            elif issubclass(optimized_cls, CausalModelServer):
                if not self.quantization_config:
                    model_dtype = "float32"
                    kv_cache_dtype = model_dtype if self.is_generative_model else None
                else:
                    model_dtype = _qdtype_to_model_lang_dtype(self.quantization_config.weight)
                    kv_cache_dtype = (
                        _qdtype_to_model_lang_dtype(self.quantization_config.kv_cache)
                        if self.quantization_config.kv_cache
                        else None
                    )

                model = optimized_cls.create(
                    None,
                    config=config,
                    model_dtype=model_dtype,
                    kv_cache_dtype=kv_cache_dtype,
                )
            else:
                raise ValueError(
                    f"Unsupported model class: {optimized_cls.__module__}.{optimized_cls.__name__}"
                )

        model.eval()
        model.requires_grad_(False)

        return model

    # FIXME: This wraps internal function to properly cache the model(because of default args)
    def random_weight_model(
        self,
        seed: int = DEFAULT_SEED_VALUE,
        run_gc: bool = True,
    ) -> torch.nn.Module:
        return self._random_weight_model(seed, run_gc)  # type: ignore[arg-type]

    @functools.lru_cache(maxsize=PRETRAINED_MODEL_CACHE_SIZE)
    def _pretrained_model(
        self,
        run_gc: bool = True,
    ) -> torch.nn.Module:
        # FIXME: This is a workaround to reduce memory usage
        self._random_weight_model.cache_clear()
        if run_gc:
            import gc

            gc.collect()
        logger.info(f"\x1b[1;36m(Loading {self})\x1b[0m")

        auto_model_cls: Optional[Type[OptimizedModel]]
        if self.task_type is None:
            auto_model_cls = AutoModel
        else:
            auto_model_cls = TASK_TYPE_TO_AUTO_MODEL_CLASS.get(self.task_type)
            if auto_model_cls is None:
                raise ValueError(f"Unsupported task_type: {self.task_type}")

        if self.quantization_config:
            torch_dtype = self.quantization_config.activation.to_torch_dtype()
        else:
            torch_dtype = None

        return auto_model_cls.from_pretrained(
            model_id=self.model_id_or_path,
            config=self.config,
            optimization_config=self.optimize_options,
            trust_remote_code=self.trust_remote_code,
            revision=self._revision,
            _disable_implicit_typecast=True,
            torch_dtype=torch_dtype,
            task=self.task_type,
            use_binary_seq_class=self.use_binary_seq_class,
        )

    # FIXME: This wraps internal function to properly cache the model
    def pretrained_model(
        self,
        run_gc: bool = True,
    ) -> torch.nn.Module:
        return self._pretrained_model(run_gc)  # type: ignore[arg-type]

    def has_side_effect(self) -> bool:
        return self.attention_type == AttentionType.PAGED_ATTENTION

    def is_available(self) -> bool:
        return True

    def uses_models(self) -> Iterable[str]:
        return [self.name]

    # Add random weight only model if any.
    def is_random_weight_only_model(self) -> bool:
        return False

    @property
    def seq_dim_in_logits(self) -> Optional[int]:
        """Returns which dimension is sequence dimension in output logits tensor."""
        # This function is used for prefill last block slicing.

        if (
            self.model_cls in MODEL_FOR_CAUSAL_LM_MAPPING.values()
            or self.model_cls is transformers.BertForQuestionAnswering
        ):
            return 1

        if self.task_type == EMBED:
            return None
        else:
            raise NotImplementedError(f"Sequence dimension in logits for model {self} is unknown")

    @property
    def batch_dim_in_mask(self) -> int:
        if self.task_type in GENERATION_TASKS:
            return 0
        else:
            raise ValueError(f"Batch dimension in mask for model {self} is unknown")

    def attn_dim_in_mask(self, phase: str) -> int:
        if issubclass(self.get_optimized_cls(), CausalModelServer):
            # expect 3d mask (batch_size, input_ids_size, attention_size)
            return 2
        else:
            raise ValueError(f"attention dimension in {phase} mask for model {self} is unknown")

    @property
    def hidden_size(self) -> int:
        return self.config_dict.get("hidden_size") or self.config_dict["n_embd"]

    @functools.cached_property
    def prefill_mask_dim(self) -> int:
        if issubclass(self.get_optimized_cls(), CausalModelServer):
            # For models-lang models, the mask dimension is always 3.
            return 3
        elif self.model_cls is transformers.BertForQuestionAnswering:
            # For BERT models, the mask dimension is always 2.
            return 2
        else:
            raise ValueError(f"Prefill mask dimension for model {self} is unknown. ")

    @functools.cached_property
    def decode_mask_dim(self) -> Optional[int]:
        if not self.is_generative_model:
            return None
        elif issubclass(self.get_optimized_cls(), CausalModelServer):
            # For For models-lang models, the mask dimension is always 3.
            return 3
        else:
            raise ValueError(f"Decode mask dimension for model {self} is unknown. ")

    def get_output_logits_size(self, bucket: AttentionBucket) -> Optional[int]:
        if not self.is_generative_model:
            return None
        return bucket.input_ids_size

    def get_example_input(
        self,
        bucket: AttentionBucket,
        paged_attention_num_blocks: Optional[int] = None,
        paged_attention_block_size: Optional[int] = None,
        collapse_batch_seq_dim: bool = False,
        random_value: bool = False,
        device: torch.device = torch.device("cpu"),
    ) -> Tuple[Tuple, Dict]:
        if self.is_generative_model and self.attention_type is AttentionType.PAGED_ATTENTION:
            if not paged_attention_num_blocks:
                raise ValueError(
                    "`paged_attention_num_blocks` should be given for paged attention models."
                )
            if not paged_attention_block_size:
                raise ValueError(
                    "`paged_attention_block_size` should be given for paged attention models."
                )
        elif self.is_generative_model:
            if paged_attention_num_blocks is not None:
                raise ValueError(
                    "`paged_attention_num_blocks` should be given if and only if the model is paged attention model."
                )
            if paged_attention_block_size is not None:
                raise ValueError(
                    "`paged_attention_block_size` should be given if and only if the model is paged attention model."
                )

        if not self.is_generative_model and not bucket.is_prefill:
            raise ValueError("only generative model supports non-prefill bucket")

        return (), generate_input_sample(
            self.get_optimized_cls(),
            self.config,
            bucket,
            self.task_type,
            self.kv_cache_torch_dtype,
            paged_attention_num_blocks,
            paged_attention_block_size,
            collapse_batch_seq_dim=collapse_batch_seq_dim,
            device=device,
        )


def _get_bucket_from_pipeline_name(pipeline_name: str) -> AttentionBucket:
    # Returns: tuple of (is_prefill, bucket)
    # Possible pipeline name formats:
    # * f"{model_name}-{mode}-b{bucket.batch_size}-attn{bucket.attention_size} (will be deprecated)
    # * f"{model_name}-kv{bucket.kv_cache_size}-b{bucket.batch_size}-attn{bucket.attention_size}
    _, mode_or_kv_cache_size, b_batch_size, attn_attn_size = pipeline_name.split("-")

    batch_size = int(b_batch_size[1:])
    attn_size = int(attn_attn_size[4:])

    if mode_or_kv_cache_size == "prefill":
        kv_size = 0
    elif mode_or_kv_cache_size == "decode":
        kv_size = attn_size - 1
    else:
        assert mode_or_kv_cache_size.startswith("kv")
        kv_size = int(mode_or_kv_cache_size[2:])

    return AttentionBucket(batch_size, attn_size, kv_size)


# NOTE: make sure to sync the logic with the rust-side implementation in `furiosa-llm-common/src/config.rs`
class GeneratorPipelineMetadata(BaseModel):
    batch_size: int
    attention_size: int
    kv_cache_size: int
    output_logits_size: Optional[int]
    include_softmax_in_graph: bool
    mask_dim: int
    sliding_window_size: Optional[int] = None

    @staticmethod
    def from_pipeline_metadata(
        generator_config: GeneratorConfig,
        pipelines: Sequence["Pipeline"],
        pipeline_metadata: Sequence[PipelineMetadata],
    ) -> list["GeneratorPipelineMetadata"]:
        # TODO: use actual model info, not match over qname
        model_qname = generator_config.model_qname
        sliding_window_size = None

        if model_qname in [
            "transformers.models.gptj.modeling_gptj.GPTJForCausalLM",
        ]:
            include_softmax_in_graph = False
            prefill_mask_dim = 2
            decode_mask_dim = 2
        elif model_qname in [
            "furiosa.models.language.architecture.qwen2.Qwen2ForCausalLM",
            "furiosa_models.architecture.models.qwen2.Qwen2ForCausalLM",
        ]:
            include_softmax_in_graph = False
            prefill_mask_dim = 3
            decode_mask_dim = 3
        elif model_qname in [
            "furiosa.models.language.architecture.exaone4.Exaone4ForCausalLM",
            "furiosa_models.architecture.models.exaone4.Exaone4ForCausalLM",
        ]:
            include_softmax_in_graph = False
            prefill_mask_dim = 3
            decode_mask_dim = 3
            sliding_window_size = 4096
        elif model_qname in [
            "furiosa.models.language.architecture.gpt_oss.GptOssForCausalLM",
            "furiosa_models.architecture.models.gpt_oss.GptOssForCausalLM",
        ]:
            include_softmax_in_graph = False
            prefill_mask_dim = 3
            decode_mask_dim = 3
            # FIXME: avoid hardcoding sliding_window_size
            sliding_window_size = 128
        else:
            raise ValueError(f"unknown model qname: {model_qname}")

        # TODO: avoid getting bucket from pipeline name and directly include it in
        # pipeline metadata.
        buckets = [_get_bucket_from_pipeline_name(pipeline.name) for pipeline in pipelines]

        return [
            GeneratorPipelineMetadata(
                batch_size=bucket.batch_size,
                attention_size=bucket.attention_size,
                kv_cache_size=bucket.kv_cache_size,
                output_logits_size=pipeline.output_logits_size,
                include_softmax_in_graph=include_softmax_in_graph,
                # TODO: specify fine-grained per-pipeline mask dimension
                mask_dim=prefill_mask_dim if bucket.is_prefill else decode_mask_dim,
                sliding_window_size=sliding_window_size,
            )
            for bucket, pipeline in zip_equal(buckets, pipeline_metadata)
        ]


def _qdtype_to_model_lang_dtype(qdtype: QDtype) -> str:
    if qdtype is QDtype.FP32:
        return "float32"
    elif qdtype is QDtype.BF16:
        return "bfloat16"
    else:
        raise ValueError(f"Unsupported qdtype: {qdtype}")
