from typing import Final, List, Literal, get_args

# Reference : https://github.com/vllm-project/vllm/blob/v0.11.1/vllm/tasks.py

# Generation task constants
GENERATE: Final[str] = "generate"
TEXT_GENERATION: Final[str] = "text-generation"
TRANSCRIPTION: Final[str] = "transcription"

# NOTE: The following "write twice" approach is required for Python 3.10, as it lacks support for variadic arguments
# in Literal[...] definitions (a feature introduced in Python 3.11+).
# While this approach is not ideal, it can be replaced with an Enum-based implementation.

GenerationTask = Literal[
    "generate",
    # NOTE: The literal "text-generation" is included for compatibility with older versions of artifacts.
    # It is treated as equivalent to the "generate" task and will be deprecated in the future.
    "text-generation",
    "transcription",
]

# Pooling task constants
EMBED: Final[Literal["embed"]] = "embed"
CLASSIFY: Final[Literal["classify"]] = "classify"
SCORE: Final[Literal["score"]] = "score"
TOKEN_EMBED: Final[Literal["token_embed"]] = "token_embed"
TOKEN_CLASSIFY: Final[Literal["token_classify"]] = "token_classify"
PLUGIN: Final[Literal["plugin"]] = "plugin"

PoolingTask = Literal[
    "embed",
    "classify",
    "score",
    "token_embed",
    "token_classify",
    "plugin",
]


GENERATION_TASKS: Final[List[str]] = list(get_args(GenerationTask))
POOLING_TASKS: Final[List[str]] = list(get_args(PoolingTask))

POOLING: Final[str] = "pooling"
