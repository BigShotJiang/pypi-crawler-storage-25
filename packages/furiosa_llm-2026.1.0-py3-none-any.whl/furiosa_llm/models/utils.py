import logging
from typing import Any, Dict, Optional, Type, Union

import torch
from transformers import PretrainedConfig

from furiosa.models.common.export.serve import CausalModelServer
from furiosa_llm.models.tasks import (
    GENERATION_TASKS,
    POOLING,
    POOLING_TASKS,
    GenerationTask,
    PoolingTask,
)

from .config_types import AttentionBucket

logger = logging.getLogger(__name__)


def generate_input_sample(
    model_cls: Type[torch.nn.Module],
    model_config: PretrainedConfig,
    bucket: AttentionBucket,
    task: Optional[Union[GenerationTask, PoolingTask]],
    kv_cache_dtype: Optional[torch.dtype],
    paged_attention_num_blocks: Optional[int],
    paged_attention_block_size: Optional[int],
    collapse_batch_seq_dim: bool,
    device: torch.device = torch.device("cpu"),
) -> Dict[str, Any]:
    """Generate input samples of nn.Module, which are used to traces through Torch Dynamo

    :param model_cls: Class of the model.
    :param model_config: Hf config of the model.
    :param bucket: Bucket used to generate input sample.
    :param task: Specifies the task for the current model. The model's behavior or expected inputs may vary depending on the defined task.
    :param kv_cache_dtype: Dtype of kv cache.
    :param paged_attention_num_blocks: Number of paged attenetion blocks for model trace.
    :param paged_attention_block_size: The maximum number of tokens that can be stored in a single paged attention block.
    :param collapse_batch_seq_dim: Whether to collapse batch and sequence dimensions into single dimension.
    :return: Input sample of type Dict. Model can be run with ``model(**sample)``.
    """
    if model_config.architectures is None or len(model_config.architectures) != 1:
        raise NotImplementedError("Currently, only single architecture model is supported.")

    if issubclass(model_cls, CausalModelServer):
        # furiosa-models-lang models. Use its own input sample generation API.
        window_size = getattr(model_config, "sliding_window", None)
        sliding_attention_size = None
        if window_size is not None:
            # NOTE: Refer to the following for the background on the rule used
            # to derive `sliding_attention_size`:
            # https://furiosa-ai.slack.com/archives/C07SSCQQDK5/p1760947055048739?thread_ts=1760938542.064459&cid=C07SSCQQDK5
            if bucket.kv_cache_size == 0:
                sliding_attention_size = None
            else:
                if bucket.input_ids_size == 1:
                    sliding_attention_size = min(window_size, bucket.kv_cache_size + 1)
                elif bucket.input_ids_size > 1:
                    sliding_attention_size = min(
                        window_size + bucket.input_ids_size,
                        bucket.kv_cache_size + bucket.input_ids_size,
                    )

        if task in POOLING_TASKS:
            assert (
                bucket.kv_cache_size == 0
            ), "bucket of non-zero 'kv_cache_size' is invalid for pooling"
            return model_cls.make_example_inputs(
                model_config,
                batch_size=bucket.batch_size,
                attention_size=bucket.attention_size,
                collapse_batch_seq_dim=collapse_batch_seq_dim,
                task=POOLING,
            )
        elif task in GENERATION_TASKS:

            assert (
                kv_cache_dtype is not None
            ), "'kv_cache_dtype' must be specified for generation tasks"

            return model_cls.make_example_inputs(
                model_config,
                batch_size=bucket.batch_size,
                attention_size=bucket.attention_size,
                kv_cache_size=bucket.kv_cache_size,
                paged_attention_block_size=paged_attention_block_size,
                paged_attention_num_blocks=paged_attention_num_blocks,
                sliding_attention_size=sliding_attention_size,
                kv_cache_dtype=kv_cache_dtype,
                collapse_batch_seq_dim=collapse_batch_seq_dim,
                device=device,
            )
        else:
            raise ValueError(f"unsupported task: {task}")
    else:
        raise ValueError(f"Unsupported model class: {model_cls}")
