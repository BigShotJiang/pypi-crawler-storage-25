from collections import Counter
import copy
from itertools import chain
import logging
from typing import List, Optional, Sequence, Tuple, Type, Union

import torch
from torch._subclasses import FakeTensorMode
from torch.overrides import TorchFunctionMode

from furiosa_llm.parallelize.pipeline.builder.arg_types import (
    LogitsSliceConfig,
    NonSharedPipelineBuildConfig,
)
from furiosa_llm.parallelize.pipeline.types import (
    CommSuperTask,
    CompSuperTask,
    SuperTaskKind,
)
from furiosa_llm.utils import (
    get_list_with_no_dup_with_order_preserved,
    maybe_register_config_serialize_by_value,
)

from ..models import ModelMetadata
from ..models.config_types import (
    AttentionBucket,
    BucketConfig,
    BucketWithOutputLogitsSize,
    ManualBucketConfig,
    MinimalBucketConfig,
    PagedAttentionConfig,
)
from ..models.utils import generate_input_sample
from ..parallelize.compiler_config import CompilerConfigContext, PipelineMode
from ..parallelize.pipeline.types import TensorGenInfo

logger = logging.getLogger(__name__)

# TODO: do we need to relax this assumption?
_CHUNKED_PREFILL_BUCKETS_BATCH_SIZE = 1
_FAKE_TENSOR_MODE = FakeTensorMode(allow_non_fake_inputs=True)


class TensorToTensorGenInfoMode(TorchFunctionMode):
    """Converts Tensor to TensorGenInfo when clone or deepcopy is called on a tensor."""

    def __init__(self):
        super().__init__()

    def __torch_function__(self, func, types, args=(), kwargs=None):
        kwargs = kwargs if kwargs else {}

        if func == torch._C._TensorBase.clone:
            tensor = args[0]
            tensor_info = extract_tensor_info(tensor)
            return tensor_info
        elif func == torch.Tensor.__deepcopy__:
            assert len(args) == 2 and len(kwargs) == 0
            tensor, memo = args

            if id(tensor) in memo:
                return memo[id(tensor)]

            tensor_info = extract_tensor_info(tensor)
            memo[id(tensor)] = tensor_info
            return tensor_info
        elif func == torch.device:
            return None
        else:
            raise ValueError(f"Not clone or deepcopy op: {func}")


def extract_tensor_info(tensor: torch.Tensor) -> TensorGenInfo:
    return TensorGenInfo(shape=tensor.shape, dtype=tensor.dtype)


def generate_non_shared_pipeline_build_config(
    model_metadata: ModelMetadata,
    bucket: AttentionBucket,
    kv_cache_dtype: Optional[torch.dtype],
    paged_attention_config: Optional[PagedAttentionConfig],
    prefill_pipeline_mode: PipelineMode,
    decode_pipeline_mode: PipelineMode,
    original_model_type: Type,
    num_blocks_per_supertask: Union[int, Sequence[int]],
    compiler_config_context: CompilerConfigContext,
    target_output_logits_size: Optional[int],
    output_logits_slice_direction: Optional[str] = "left",
) -> NonSharedPipelineBuildConfig:

    # https://furiosa-ai.slack.com/archives/C04HK6EK8RL/p1747286933388599?thread_ts=1747212852.183939&cid=C04HK6EK8RL
    # This value has effect on compilation result.
    paged_attention_num_blocks = bucket.batch_size * bucket.attention_size + 100

    with _FAKE_TENSOR_MODE:
        input_sample_data = generate_input_sample(
            model_metadata.get_optimized_cls(),
            model_metadata.config,
            bucket,
            model_metadata.task_type,
            kv_cache_dtype,
            paged_attention_num_blocks if paged_attention_config else None,
            paged_attention_config.block_size if paged_attention_config else None,
            # TODO: use value from argument instead of hardcoding.
            collapse_batch_seq_dim=False,
        )
        with TensorToTensorGenInfoMode():
            input_sample_data = copy.deepcopy(input_sample_data)
        model_name = f"{original_model_type.__module__}.{original_model_type.__name__}"
        # Please reflect the implementation of PipelineName in furiosa-llm-tests/src/e2e_base.rs
        # TODO: save needed information in Pipeline's metadata, instead of saving it in pipeline name.
        pipeline_name = f"{model_name}-kv{bucket.kv_cache_size}-b{bucket.batch_size}-attn{bucket.attention_size}"
        compiler_config_context = copy.deepcopy(compiler_config_context)

        if bucket.is_prefill:
            compiler_config_context.phase = prefill_pipeline_mode
        elif bucket.is_decode:
            compiler_config_context.phase = decode_pipeline_mode
        else:
            # FIXME: change this to proper phase config
            compiler_config_context.phase = PipelineMode.UNKNOWN
        compiler_config_context.bucket = bucket

        logits_slice_config = None
        if target_output_logits_size is not None:
            original_output_logits_size = model_metadata.get_output_logits_size(bucket)
            if original_output_logits_size is None:
                raise ValueError("Failed to get expected output logit size of the model.")
            if original_output_logits_size != target_output_logits_size:
                if target_output_logits_size == 0:
                    output_logits_slice_direction = None
                logits_slice_config = LogitsSliceConfig(
                    output_logits_slice_direction, target_output_logits_size
                )

        return NonSharedPipelineBuildConfig(
            args_data=(),  # assumed LLM models have kwargs only
            kwargs_data=input_sample_data,
            pipeline_name=pipeline_name,
            compile_config=compiler_config_context,
            logits_slice_config=logits_slice_config,
            num_blocks_per_supertask=num_blocks_per_supertask,
        )


def _get_buckets_for_chunked_prefill(
    max_prompt_len: int,
    chunk_size: int,
) -> List[AttentionBucket]:
    assert chunk_size <= max_prompt_len

    share, remainder = divmod(max_prompt_len, chunk_size)
    buckets = []

    # XXX: We only consider buckets with batch 1 if chunked prefill is used.
    for i in range(1, share + 1):
        buckets.append(
            AttentionBucket(
                _CHUNKED_PREFILL_BUCKETS_BATCH_SIZE,
                i * chunk_size,
                (i - 1) * chunk_size,
            )
        )
    if remainder:
        buckets.append(
            AttentionBucket(
                _CHUNKED_PREFILL_BUCKETS_BATCH_SIZE,
                max_prompt_len,
                share * chunk_size,
            )
        )
    return buckets


def _get_optimized_buckets_with_output_logits_size(
    bucket_config: BucketConfig,
    is_generative_model: bool,
    max_prompt_len: int,
    max_seq_len_to_capture: int,
    num_speculative_tokens: Optional[int],
    prefill_chunk_size: Optional[int],
    allow_buckets_with_no_output: bool = False,
) -> Tuple[
    List[BucketWithOutputLogitsSize],
    List[BucketWithOutputLogitsSize],
    List[BucketWithOutputLogitsSize],
]:
    if isinstance(bucket_config, MinimalBucketConfig):
        assert bucket_config.max_seq_len == max_seq_len_to_capture
        if prefill_chunk_size:
            # If chunked prefill is used, original prefill buckets are not used.
            prefill_buckets = []
        else:
            prefill_buckets = [AttentionBucket.prefill(1, max_prompt_len)]
        decode_buckets = (
            [AttentionBucket.decode(1, max_seq_len_to_capture)] if is_generative_model else []
        )
    elif isinstance(bucket_config, ManualBucketConfig):
        duplicate_prefill_buckets = [
            bucket for bucket, cnt in Counter(bucket_config.prefill_buckets).items() if cnt > 1
        ]
        if duplicate_prefill_buckets:
            logger.warning(f"Duplicate prefill buckets are found: {duplicate_prefill_buckets}. ")

        if bucket_config.decode_buckets:
            duplicate_decode_buckets = [
                bucket for bucket, cnt in Counter(bucket_config.decode_buckets).items() if cnt > 1
            ]
            if duplicate_decode_buckets:
                logger.warning(f"Duplicate decode buckets are found: {duplicate_decode_buckets}. ")

        prefill_buckets = [
            AttentionBucket.prefill(*bucket) for bucket in bucket_config.prefill_buckets
        ]
        if is_generative_model:
            # FIXME: This is a temporary workaround to support empty decode bucket case,
            # just for getting fx graphs using `LLM.get_splitted_gms` without creating `NativeLLMEngine`.
            if bucket_config.decode_buckets is None:
                raise ValueError("decode_buckets must be given for generative models.")
            decode_buckets = [
                AttentionBucket.decode(*bucket) for bucket in bucket_config.decode_buckets
            ]
        else:
            if bucket_config.decode_buckets:
                logger.warning(
                    "decode_buckets will be ignored because the model is not a generative model."
                )
            decode_buckets = []
    else:
        raise ValueError(f"Invalid bucket config: {bucket_config}")

    if is_generative_model:
        prefill_output_logits_size = 1
    else:
        prefill_output_logits_size = None

    prefill_buckets_with_output_size = [
        BucketWithOutputLogitsSize(bucket=bucket, output_logits_size=prefill_output_logits_size)
        for bucket in prefill_buckets
    ]
    assert all(bucket.input_ids_size == 1 for bucket in decode_buckets)
    decode_buckets_with_output_size = [
        BucketWithOutputLogitsSize(bucket, output_logits_size=1) for bucket in decode_buckets
    ]

    other_buckets_with_output_size: List[BucketWithOutputLogitsSize] = []

    # Generate buckets for speculative decoding if needed.
    if num_speculative_tokens is not None:
        if num_speculative_tokens == 0:
            raise ValueError("`num_speculative_tokens` must be larger than 0.")
        for bucket_with_output_size in decode_buckets_with_output_size:
            bucket = bucket_with_output_size.bucket
            new_bucket = AttentionBucket(
                bucket.batch_size,
                bucket.attention_size,
                # NOTE: Why input_ids length become (num_speculative_tokens + 1) instead of num_speculative_tokens?
                # Whenever target model verifies draft model's suggested tokens, it generates exactly one bonus token regardless
                # of how many suggestion tokens are actually accepted. And at the time of next verification, this bonus token
                # (from previous verification) should be given as an input_ids (not kv cache!) because there is no kv cache for this bonus token.
                # So input_ids length for each verification should be num_speculative_tokens + 1 (for bonus token).
                bucket.attention_size - (num_speculative_tokens + 1),
            )
            other_buckets_with_output_size.append(
                BucketWithOutputLogitsSize(new_bucket, output_logits_size=new_bucket.input_ids_size)
            )

    if prefill_chunk_size:
        # Add buckets for chunked prefill.
        if prefill_chunk_size > max_prompt_len:
            raise ValueError("`prefill_chunk_size` should be smaller than `max_prompt_len`.")
        buckets_for_chunked_prefill = _get_buckets_for_chunked_prefill(
            max_prompt_len, prefill_chunk_size
        )
        for bucket in buckets_for_chunked_prefill:
            # Always need output from chunked prefill bucket graph with `max_prompt_len` attention size.
            generate_no_output_graph = bucket.attention_size != max_prompt_len
            if generate_no_output_graph and allow_buckets_with_no_output:
                output_logits_sizes: Tuple[int, ...] = (0, 1)
            else:
                output_logits_sizes = (1,)

            for output_logits_size in output_logits_sizes:
                if bucket.is_prefill:
                    prefill_buckets_with_output_size.append(
                        BucketWithOutputLogitsSize(bucket, output_logits_size)
                    )
                else:
                    other_buckets_with_output_size.append(
                        BucketWithOutputLogitsSize(bucket, output_logits_size)
                    )

    return (
        prefill_buckets_with_output_size,
        decode_buckets_with_output_size,
        other_buckets_with_output_size,
    )


def get_buckets_with_output_logits_size(
    model_metadata: ModelMetadata,
    bucket_config: BucketConfig,
    max_prompt_len: int,
    max_seq_len_to_capture: int,
    num_speculative_tokens: Optional[int],
    prefill_chunk_size: Optional[int],
    optimize_bucket_output_logits_size: bool,
) -> Tuple[
    List[BucketWithOutputLogitsSize],
    List[BucketWithOutputLogitsSize],
    List[BucketWithOutputLogitsSize],
]:
    (
        prefill_buckets_with_output_size,
        decode_buckets_with_output_size,
        other_buckets_with_output_size,
    ) = _get_optimized_buckets_with_output_logits_size(
        bucket_config,
        model_metadata.is_generative_model,
        max_prompt_len,
        max_seq_len_to_capture,
        num_speculative_tokens,
        prefill_chunk_size,
    )

    if not optimize_bucket_output_logits_size:
        # If bucket output logit optimization is disabled, change each bucket's output logit size to original model's expected one.
        for bucket_with_output_size in chain(
            prefill_buckets_with_output_size,
            decode_buckets_with_output_size,
            other_buckets_with_output_size,
        ):
            bucket_with_output_size.output_logits_size = model_metadata.get_output_logits_size(
                bucket_with_output_size.bucket
            )

    # Remove duplication
    prefill, decode, others = (
        get_list_with_no_dup_with_order_preserved(buckets_with_output_size)
        for buckets_with_output_size in (
            prefill_buckets_with_output_size,
            decode_buckets_with_output_size,
            other_buckets_with_output_size,
        )
    )

    return prefill, decode, others


def _is_match_in_inoutputs(
    sp_task: Union[CommSuperTask, CompSuperTask],
    succ_sp_task: Union[CommSuperTask, CompSuperTask],
) -> bool:
    """
    Determine whether two supertasks will execute sequentially by verifying if the outputs of `sp_task` are passed as inputs to `succ_sp_task`.
    If so, we record outputs of `sp_task` to mark them as inter-supertask input arg for `succ_sp_task`.
    """
    if isinstance(sp_task, CompSuperTask) and isinstance(succ_sp_task, CompSuperTask):
        return (
            set(sp_task.outputs).issubset(set(succ_sp_task.inputs))
            and sp_task != succ_sp_task
            and bool(sp_task.outputs)
        )
    elif isinstance(sp_task, CompSuperTask) and isinstance(succ_sp_task, CommSuperTask):
        return sp_task.outputs == succ_sp_task.inputs and succ_sp_task.kind is SuperTaskKind.SEND
    elif isinstance(sp_task, CommSuperTask):
        if sp_task.kind is SuperTaskKind.RECV:
            return isinstance(succ_sp_task, CompSuperTask) and set(sp_task.outputs).issubset(
                set(succ_sp_task.inputs)
            )
        elif sp_task.kind is SuperTaskKind.SEND:
            return (
                isinstance(succ_sp_task, CommSuperTask)
                and succ_sp_task.kind is SuperTaskKind.RECV
                and succ_sp_task.group == sp_task.group
            )
        else:
            raise ValueError(f"Invalid CommSuperTask {sp_task} is encountered.")
    else:
        raise ValueError(f"Unexpected Supertask {sp_task} and {succ_sp_task}")


def prestep_for_remote_code_model(
    model_metadata: ModelMetadata,
    num_pipeline_builder_workers: int,
):
    # If `trust_remote_code` and parallel pipeline building is used,
    # serialization logic for remote model config should be registered. Otherwise,
    # it fails to send model metadata to remote ray tasks.
    if num_pipeline_builder_workers > 1:
        # Ensure remote model config is registered in transformers by calling `ModelMetadata.config`.
        model_metadata.config
        maybe_register_config_serialize_by_value()
