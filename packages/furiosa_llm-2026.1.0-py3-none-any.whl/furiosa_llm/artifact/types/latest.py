import json
import logging
import os
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, RootModel
from typing_extensions import Self

from furiosa_llm.models.metadata import ModelMetadata

from ...models.config_types import (
    GeneratorConfig,
    ModelRewritingConfig,
    PipelineMetadata,
)
from .commons import ArtifactBase, SchemaVersion
from .config import ParallelConfig

logger = logging.getLogger(__name__)


SCHEMA_VERSION = SchemaVersion(major=2, minor=0)


class ArtifactMetadata(BaseModel):
    artifact_id: str
    name: str
    timestamp: int
    furiosa_llm_version: str
    furiosa_compiler_version: str
    includes_composable_ir: bool


class ModelArtifact(BaseModel):
    generator_config: GeneratorConfig
    hf_config: Dict[str, Any]
    model_metadata: ModelMetadata
    model_rewriting_config: ModelRewritingConfig
    parallel_config: ParallelConfig

    pipelines: List[Dict[str, Any]] = []
    pipeline_metadata_list: List[PipelineMetadata]

    # TODO: store this field somewhere else.
    max_prompt_len: Optional[int]

    def append_pipeline(self, pipeline_dict: Dict[str, Any]):
        self.pipelines.append(pipeline_dict)


class Artifact(ArtifactBase):
    metadata: ArtifactMetadata
    model: ModelArtifact
    speculative_model: Optional[ModelArtifact] = None
    version: SchemaVersion

    # TODO : `prefill_chunk_size` will be moved to `GeneratorConfig` later
    prefill_chunk_size: Optional[int] = None

    def export(self, path: Union[str, os.PathLike]):
        with open(path, "w") as f:
            f.write(RootModel[Artifact](self).model_dump_json(indent=2))

    @classmethod
    def from_previous_version(cls, _previous_version_artifact) -> Self:
        raise ValueError(
            "There's no previous version artifact that can be converted into this version of artifact."
        )

    @classmethod
    def load(cls, path: Union[str, os.PathLike]) -> "Artifact":

        with open(path) as f:
            artifact_data: Dict[str, Any] = json.load(f)

        artifact_schema_version = artifact_data.get("version")
        if not artifact_schema_version:
            raise ValueError(
                "Invalid or incompatible version of artifact: schema version doesn't exist."
            )
        try:
            return convert_to_latest_version(artifact_data)
        except Exception as e:
            logger.error(e)
            raise ValueError("Artifact schema mismatched.")


# Map for major schema version to corresponding Artifact type
SCHEMA_MAJOR_VERSION_MAPPING = {2: Artifact}


def convert_to_latest_version(old_artifact_data: Dict[str, Any]) -> Artifact:
    artifact_schema_major_version = old_artifact_data.get("version", {}).get("major", 0)
    assert type(artifact_schema_major_version) is int
    if artifact_schema_major_version not in SCHEMA_MAJOR_VERSION_MAPPING:
        raise ValueError(
            f"Artifact of version {artifact_schema_major_version}.x is not supported anymore. Please use more recent version."
        )

    old_version_artifact_cls = SCHEMA_MAJOR_VERSION_MAPPING[artifact_schema_major_version]
    old_artifact = old_version_artifact_cls(**old_artifact_data)

    current_converting_version: int = artifact_schema_major_version
    converted_artifact = old_artifact
    while not isinstance(converted_artifact, Artifact):
        current_converting_version += 1
        converted_artifact = SCHEMA_MAJOR_VERSION_MAPPING[current_converting_version].from_previous_version(converted_artifact)  # type: ignore[attr-defined]
    return converted_artifact
