import os
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, RootModel
from typing_extensions import Self

from furiosa_llm.artifact.types.commons import ArtifactBase, SchemaVersion
from furiosa_llm.artifact.types.config import ParallelConfig
from furiosa_llm.artifact.types.latest import ArtifactMetadata
from furiosa_llm.models.metadata import ModelMetadata
from furiosa_llm.models.next_gen_config_types import PipelineMetadata

# TODO: Remove types here and use Rust-side counterparts instead.

SCHEMA_VERSION = SchemaVersion(major=3, minor=0)


class GeneratorConfig(BaseModel):
    num_speculative_tokens: Optional[int]


class ModelArtifact(BaseModel):
    hf_config: Dict[str, Any]
    model_metadata: ModelMetadata
    # TODO: add new field corresponding to this.
    # model_rewriting_config: ModelRewritingConfig
    parallel_config: ParallelConfig

    pipelines: List[Dict[str, Any]] = []
    pipeline_metadata_list: List[PipelineMetadata]

    # TODO: store this field somewhere else.
    max_prompt_len: Optional[int]

    def append_pipeline(self, pipeline_dict: Dict[str, Any]):
        self.pipelines.append(pipeline_dict)


class Artifact(ArtifactBase):
    metadata: ArtifactMetadata
    model: ModelArtifact
    generator_config: GeneratorConfig
    speculative_model: Optional[ModelArtifact] = None
    version: SchemaVersion

    @classmethod
    def from_previous_version(cls, previous_version_artifact) -> Self:
        raise ValueError("Conversion from previous version is not supported")

    def export(self, path: Union[str, os.PathLike]):
        with open(path, "w") as f:
            f.write(RootModel[Artifact](self).model_dump_json(indent=2))
