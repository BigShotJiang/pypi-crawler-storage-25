import asyncio
import logging
import time
from typing import AsyncGenerator, Optional, Union, cast

from fastapi import Request

from furiosa_llm.api import LLM
from furiosa_llm.llm_engine import AsyncLLMEngine
from furiosa_llm.outputs import PoolingOutput, PoolingRequestOutput
from furiosa_llm.server.protocol import (
    EmbeddingRequest,
    EmbeddingResponse,
    EmbeddingResponseData,
    ErrorResponse,
    UsageInfo,
)
from furiosa_llm.server.serving_base import OpenAIServing
from furiosa_llm.server.utils import (
    handle_disconnect,
    is_list_of,
    merge_async_iterators,
    random_uuid,
)
from furiosa_llm.vllm_compat import SingletonPrompt, TokensPrompt

logger = logging.getLogger(__name__)


class OpenAIServingEmbedding(OpenAIServing):
    def __init__(self, llm: LLM, served_model_name: Optional[str] = None):
        self.async_llm_engine: AsyncLLMEngine = AsyncLLMEngine.from_llm(llm)
        self.tokenizer = llm.tokenizer
        self.model_name = served_model_name or llm.model_metadata.pretrained_id

    async def create_embedding(
        self,
        request: EmbeddingRequest,
        raw_request: Request,
    ) -> Union[EmbeddingResponse, ErrorResponse]:
        """
        Embedding API similar to OpenAI's API.

        See https://platform.openai.com/docs/api-reference/embeddings
        for the API specification. This API mimics the OpenAI Embeddings API.
        """
        request_id = f"embd-{random_uuid()}"
        created_time = int(time.time())
        inputs: list[SingletonPrompt]

        try:
            # Process the input based on its type
            if isinstance(request.input, str):
                inputs = [request.input]
            elif is_list_of(request.input, str):
                inputs = cast(list[SingletonPrompt], request.input)
            elif is_list_of(request.input, int):
                inputs = [TokensPrompt(prompt_token_ids=request.input)]
            else:
                inputs = [TokensPrompt(prompt_token_ids=token_ids) for token_ids in request.input]

            # Create pooling parameters
            pooling_params = request.to_pooling_params()

            # XXX: AsyncLLMEngine does not accept duplicate request ids,
            # so we need to generate multiple requests with -i suffix.
            request_ids = [f"{request_id}-{i}" for i in range(len(inputs))]
            result_generator: list[AsyncGenerator[PoolingRequestOutput[PoolingOutput], None]] = [
                self.async_llm_engine.encode(
                    input,
                    pooling_params,
                    request_ids[i],
                )
                for i, input in enumerate(inputs)
            ]
            merged_generator = merge_async_iterators(*result_generator)
            asyncio.create_task(
                handle_disconnect(raw_request, lambda: self._abort_request(request_ids))
            )

            # Generate embedding response data for each input
            response_data: list[EmbeddingResponseData] = []
            total_prompt_tokens = 0

            async for i, output in merged_generator:
                if output.finished:
                    embedding_data = output.outputs.data
                    response_data.append(
                        EmbeddingResponseData(
                            index=i,
                            embedding=embedding_data.tolist(),
                        )
                    )
                    total_prompt_tokens += len(output.prompt_token_ids)
            response_data.sort(key=lambda x: x.index)

            # Create usage info
            usage = UsageInfo(
                prompt_tokens=total_prompt_tokens,
                total_tokens=total_prompt_tokens,
            )

            response = EmbeddingResponse(
                data=response_data,
                model=self.model_name,
                created=created_time,
                usage=usage,
            )
            return response

        except Exception as e:
            logger.error(f"Error in embedding generation: {e}", exc_info=True)
            return self.create_error_response("Internal server error")

    async def _abort_request(self, request_ids: list[str]) -> None:
        for request_id in request_ids:
            await self.async_llm_engine.abort(request_id)
