import datetime
import hashlib
import json
import logging
from logging import Formatter
import secrets
import sys

from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.types import ASGIApp


class JsonFormatter(Formatter):
    def __init__(self):
        super(JsonFormatter, self).__init__()

    def format(self, record):
        json_record = {}
        json_record["timestamp"] = (
            datetime.datetime.fromtimestamp(record.created)
            .astimezone()
            .isoformat("T", "milliseconds")
        )
        json_record["message"] = record.getMessage()
        if "req" in record.__dict__:
            json_record["req"] = record.__dict__["req"]
        if "res" in record.__dict__:
            json_record["res"] = record.__dict__["res"]
        if record.levelno == logging.ERROR and record.exc_info:
            json_record["err"] = self.formatException(record.exc_info)
        return json.dumps(json_record)


access_logger = logging.getLogger("uvicorn.access")
json_logger = logging.getLogger("serve")
handler = logging.StreamHandler(stream=sys.stdout)
handler.setFormatter(JsonFormatter())
json_logger.handlers = [handler]
json_logger.setLevel(logging.DEBUG)
json_logger.propagate = False


class RequestLoggerMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        remote_addr = f"{request.client.host}:{request.client.port}" if request.client else ""
        body = await request.body()
        req_time = datetime.datetime.now().astimezone()
        try:
            body_json = json.loads(body)
        except json.JSONDecodeError:
            body_json = json.dumps(body.decode("utf-8"))

        response = await call_next(request)
        resp_time = datetime.datetime.now().astimezone()
        json_logger.info(
            "request",
            extra={
                "req": {
                    "timestamp": req_time.isoformat("T", "milliseconds"),
                    "method": request.method,
                    "url": str(request.url),
                    "remote_addr": remote_addr,
                    "payload": body_json,
                },
                "res": {
                    "timestamp": resp_time.isoformat("T", "milliseconds"),
                    "status_code": response.status_code,
                },
            },
        )
        return response


class AuthenticationMiddleware(BaseHTTPMiddleware):
    """
    HTTP middleware that authenticates each request by checking
    if the Authorization Bearer token exists and equals any of "{api_key}".

    Notes
    -----
    There are two cases in which authentication is skipped:
        1. The HTTP method is OPTIONS.
        2. The request path doesn't start with /v1 (e.g. /health).
    """

    def __init__(self, app: ASGIApp, tokens: list[str]) -> None:
        super().__init__(app)
        self.api_tokens = [hashlib.sha256(t.encode("utf-8")).digest() for t in tokens]

    def verify_token(self, request: Request) -> bool:
        authorization_header_value = request.headers.get("Authorization")
        if not authorization_header_value:
            return False

        scheme, _, param = authorization_header_value.partition(" ")
        if scheme.lower() != "bearer":
            return False

        param_hash = hashlib.sha256(param.encode("utf-8")).digest()

        token_match = any(
            secrets.compare_digest(param_hash, token_hash) for token_hash in self.api_tokens
        )

        return token_match

    async def dispatch(self, request: Request, call_next):
        # Skip authentication for OPTIONS requests
        if request.method == "OPTIONS":
            return await call_next(request)

        # Skip authentication for non-/v1 paths (e.g. /health)
        root_path = request.scope.get("root_path", "")
        url_path = request.url.path.removeprefix(root_path)

        if url_path.startswith("/v1") and not self.verify_token(request):
            return JSONResponse(
                headers={"WWW-Authenticate": "Bearer"},
                content={"error": "Unauthorized"},
                status_code=401,
            )

        return await call_next(request)


class Log4xx5xxMiddleware(BaseHTTPMiddleware):
    """Middleware to log 4xx/5xx responses in uvicorn access log format at warning level."""

    async def dispatch(self, request: Request, call_next):
        scope = request.scope
        client = scope.get("client")
        client_addr = f"{client[0]}:{client[1]}" if client else "-"

        http_version = scope.get("http_version", "1.1")
        path = (scope.get("root_path", "") or "") + (scope.get("path", "") or "")
        qs = scope.get("query_string", b"")
        if qs:
            path = f"{path}?{qs.decode('latin-1')}"

        try:
            response = await call_next(request)
        except Exception:
            access_logger.warning(
                '%s - "%s %s HTTP/%s" %d', client_addr, request.method, path, http_version, 500
            )
            raise

        if response.status_code >= 400:
            access_logger.warning(
                '%s - "%s %s HTTP/%s" %d',
                client_addr,
                request.method,
                path,
                http_version,
                response.status_code,
            )

        return response
