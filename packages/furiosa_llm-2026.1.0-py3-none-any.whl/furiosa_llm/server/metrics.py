from dataclasses import dataclass, field
import logging
import re
import threading
import time
from typing import Callable

from starlette.routing import Mount

from furiosa.native_runtime.llm import (
    DeviceGroupMetrics,
    get_device_group_metrics,
    get_metrics_as_prometheus_string,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# Code obtained and modified from Prometheus Python client.
# https://github.com/prometheus/client_python/blob/73680284ce63f0bc0f23cfc42af06e74fd7e3ccf/prometheus_client/asgi.py#L8
# TODO(elpis): Add gzip compression.
def _make_prometheus_endpoint() -> Callable:
    async def prometheus_app(scope, receive, send):
        assert scope.get("type") == "http"
        # Bake output
        status = "200 OK"
        headers = [("Content-Type", "text/plain; version=0.0.4; charset=utf-8")]
        output = get_metrics_as_prometheus_string(with_unit=True).encode("utf8")
        formatted_headers = []
        for header in headers:
            formatted_headers.append(tuple(x.encode("utf8") for x in header))
        # Return output
        payload = await receive()
        if payload.get("type") == "http.request":
            await send(
                {
                    "type": "http.response.start",
                    "status": int(status.split(" ")[0]),
                    "headers": formatted_headers,
                }
            )
            await send({"type": "http.response.body", "body": output})

    return prometheus_app


def get_metrics_mount() -> Mount:
    metrics_route = Mount("/metrics", _make_prometheus_endpoint())
    # Workaround for 307 Redirect for /metrics
    metrics_route.path_regex = re.compile("^/metrics(?P<path>.*)$")
    return metrics_route


# NOTE(elpis): Example vLLM Log format:
# INFO 06-22 08:13:23 [loggers.py:118] Engine 000: Avg prompt throughput: 3155.9 tokens/s, Avg generation throughput: 2673.9 tokens/s, Running: 12 reqs, Waiting: 0 reqs, GPU KV cache usage: 0.8%, Prefix cache hit rate: 60.4%


@dataclass
class LogMetrics:
    time: float = field(default_factory=time.monotonic)
    device_group_metrics: dict[str, DeviceGroupMetrics] = field(
        default_factory=get_device_group_metrics
    )

    def print_diff_log(self, prev: "LogMetrics"):
        time_diff = self.time - prev.time
        if time_diff <= 0:
            return

        all_device_keys = set(self.device_group_metrics.keys()) | set(
            prev.device_group_metrics.keys()
        )

        for device_key in sorted(all_device_keys):
            cur_metrics = self.device_group_metrics.get(device_key)
            prev_metrics = prev.device_group_metrics.get(device_key)

            if cur_metrics is None:
                continue

            prompt_token_diff = cur_metrics.prompt_tokens - (
                prev_metrics.prompt_tokens if prev_metrics else 0
            )
            generation_token_diff = cur_metrics.generation_tokens - (
                prev_metrics.generation_tokens if prev_metrics else 0
            )

            tokens_processed = prompt_token_diff + generation_token_diff
            requests_in_device = cur_metrics.running_samples + cur_metrics.waiting_samples

            if tokens_processed == 0 and requests_in_device == 0:
                continue

            log_string = (
                f"[{device_key}] "
                f"Avg prompt throughput: {prompt_token_diff / time_diff:.1f} tokens/s"
                f", Avg generation throughput: {generation_token_diff / time_diff:.1f} tokens/s"
                f", Running: {cur_metrics.running_samples} reqs"
                f", Waiting: {cur_metrics.waiting_samples} reqs"
                f", RNGD KV cache usage: {cur_metrics.kv_cache_usage * 100.0:.1f}%"
                f", Prefix cache hit rate: {cur_metrics.prefix_cache_hit_rate * 100.0:.1f}%"
                f", Wire pipeline hit rate: {cur_metrics.wire_hit_rate * 100.0:.1f}%"
            )
            logger.info(log_string)


def install_metrics_logging_thread():
    def log_time_periodically():
        prev = LogMetrics()
        while True:
            cur = LogMetrics()
            cur.print_diff_log(prev)
            prev = cur
            time.sleep(10)

    thread = threading.Thread(target=log_time_periodically, daemon=True)
    thread.start()
