from argparse import Namespace
import logging
from typing import List, Optional, Tuple

from furiosa_llm.api import LLM
from furiosa_llm.llm_engine import SchedulerConfig
from furiosa_llm.utils import get_logger_with_tz

logger = get_logger_with_tz(logging.getLogger(__name__))


def load_llm_from_args(args: Namespace) -> LLM:
    """
    Returns LLM object and an identifier for representing the model.
    The identifier will be:
      - pretrained_id if args.model is a pretrained model id.
      - artifact_id if args.model is an artifact path.
    """
    model: str = args.model
    pp: Optional[int] = args.pipeline_parallel_size
    dp: Optional[int] = args.data_parallel_size
    devices = args.devices

    prefill_buckets = parse_bucket_args(args.prefill_buckets) if args.prefill_buckets else None
    decode_buckets = parse_bucket_args(args.decode_buckets) if args.decode_buckets else None

    if model == "furiosa-ai/fake-llm":
        from transformers import AutoTokenizer

        from tests.utils import FakeLLM, FakeNativeLLMEngine

        engine = FakeNativeLLMEngine.from_text_output(
            AutoTokenizer.from_pretrained("unsloth/Llama-3.1-8B-Instruct"),
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
            append_eos=True,
        )
        return FakeLLM(engine)

    logger.info(f"Loading LLM from artifact: {model}")
    if args.tensor_parallel_size:
        logger.warning("When loading LLM from artifact, given -tp value will be ignored.")

    scheduler_config = SchedulerConfig.load_from_args(args)

    return LLM(
        model,
        revision=args.revision,
        devices=devices,
        data_parallel_size=dp,
        pipeline_parallel_size=pp,
        scheduler_config=scheduler_config,
        prefill_buckets=prefill_buckets,
        decode_buckets=decode_buckets,
        max_prompt_len=args.max_prompt_len,
        max_model_len=args.max_model_len,
        max_batch_size=args.max_batch_size,
        min_batch_size=args.min_batch_size,
        guided_decoding_backend=args.guided_decoding_backend,
        max_io_memory_mb=args.max_io_memory_mb,
        enable_jit_wiring=args.enable_jit_wiring,
        # TODO: support speculative_model, num_speculative_tokens
    )


def parse_bucket_args(bucket_args: List[str]) -> List[Tuple[int, int]]:
    try:
        return [tuple(map(int, b.split(",", 1))) for b in bucket_args]  # type: ignore
    except ValueError:
        raise ValueError(
            "Invalid bucket format. Buckets should be in the format of 'batch_size,sequence_length', space-separated."
        )
