from argparse import Namespace
from contextlib import asynccontextmanager
import logging
from typing import Optional

import anyio
from fastapi import APIRouter, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import ORJSONResponse, Response, StreamingResponse
import numpy as np
import uvicorn

import furiosa.native_runtime
from furiosa.native_runtime.llm import NativePoolingOutput
from furiosa_llm.api import LLM
from furiosa_llm.models.tasks import EMBED, GENERATION_TASKS, POOLING_TASKS, SCORE
from furiosa_llm.server.chat_utils import (
    ConversationMessage,
    ModelConfigAdapter,
    apply_hf_chat_template,
    resolve_chat_template_content_format,
    resolve_hf_chat_template,
)
from furiosa_llm.server.metrics import get_metrics_mount, install_metrics_logging_thread
from furiosa_llm.server.middleware import (
    AuthenticationMiddleware,
    Log4xx5xxMiddleware,
    RequestLoggerMiddleware,
)
from furiosa_llm.server.models import load_llm_from_args
from furiosa_llm.server.protocol import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    CompletionRequest,
    CompletionResponse,
    EmbeddingRequest,
    EmbeddingResponse,
    ErrorResponse,
    ModelsResponse,
    RerankRequest,
    RerankResponse,
    ScoreRequest,
    ScoreResponse,
)
from furiosa_llm.server.serving_chat import OpenAIServingChat
from furiosa_llm.server.serving_completions import OpenAIServingCompletion
from furiosa_llm.server.serving_embedding import OpenAIServingEmbedding
from furiosa_llm.server.serving_score import ServingScores
from furiosa_llm.server.utils import parse_request
from furiosa_llm.version import FURIOSA_LLM_VERSION
from furiosa_llm.vllm_compat import get_score_prompt

router = APIRouter()

llm: LLM
openai_serving_completion: Optional[OpenAIServingCompletion] = None
openai_serving_chat: Optional[OpenAIServingChat] = None
openai_serving_embedding: Optional[OpenAIServingEmbedding] = None
serving_score: Optional[ServingScores] = None
openai_serving_models_response: ModelsResponse


@router.get("/health")
async def health() -> Response:
    """Health check."""
    if llm.engine.is_alive():
        return Response(status_code=200)
    else:
        return Response(status_code=503)


@router.get("/version")
async def show_version():
    return ORJSONResponse(
        content={
            "version": FURIOSA_LLM_VERSION.version,
            "furiosa-llm": {
                "stage": FURIOSA_LLM_VERSION.stage,
                "version": FURIOSA_LLM_VERSION.version,
                "git_hash": FURIOSA_LLM_VERSION.hash,
            },
            "furiosa-runtime": {
                "version": furiosa.native_runtime.__version__,
                "git_hash": furiosa.native_runtime.__git_short_hash__,
                "build_time": furiosa.native_runtime.__build_timestamp__,
            },
            "npu-ir": {
                "version": furiosa.native_runtime.__ir_version__,
                "git_hash": furiosa.native_runtime.__ir_git_short_hash__,
                "build_time": furiosa.native_runtime.__ir_build_timestamp__,
            },
        }
    )


@router.get("/v1/models")
async def show_available_models(raw_request: Request):
    return ORJSONResponse(content=openai_serving_models_response.model_dump())


@router.get("/v1/models/{model_id:path}")
async def show_model(raw_request: Request, model_id: str):
    for model in openai_serving_models_response.data:
        if model.id == model_id:
            return ORJSONResponse(content=model.model_dump())
    return ORJSONResponse(
        content={
            "error": {
                "message": f"The model '{model_id}' does not exist",
                "type": "invalid_request_error",
                "param": "model",
                "code": "model_not_found",
            }
        },
        status_code=404,
    )


@router.post("/v1/completions")
async def create_completion(raw_request: Request):
    if not openai_serving_completion:
        return unsupported_task_response("text generation")
    request = await parse_request(raw_request, CompletionRequest)
    generator = await openai_serving_completion.create_completion(request, raw_request)
    if isinstance(generator, ErrorResponse):
        return ORJSONResponse(content=generator.model_dump(), status_code=generator.code)
    elif isinstance(generator, CompletionResponse):
        return ORJSONResponse(content=generator.model_dump())

    return StreamingResponse(content=generator, media_type="text/event-stream")


@router.post("/v1/chat/completions")
async def create_chat_completion(raw_request: Request):
    if not openai_serving_chat:
        return unsupported_task_response("text generation")
    request = await parse_request(raw_request, ChatCompletionRequest)
    generator = await openai_serving_chat.create_chat_completion(request, raw_request)
    if isinstance(generator, ErrorResponse):
        return ORJSONResponse(content=generator.model_dump(), status_code=generator.code)
    elif isinstance(generator, ChatCompletionResponse):
        return ORJSONResponse(content=generator.model_dump())

    return StreamingResponse(content=generator, media_type="text/event-stream")


@router.post("/v1/embeddings")
async def create_embedding(raw_request: Request):
    if not openai_serving_embedding:
        return unsupported_task_response("embedding")
    request = await parse_request(raw_request, EmbeddingRequest)
    response = await openai_serving_embedding.create_embedding(request, raw_request)

    if isinstance(response, ErrorResponse):
        return ORJSONResponse(content=response.model_dump(), status_code=response.code)
    elif isinstance(response, EmbeddingResponse):
        return ORJSONResponse(content=response.model_dump())
    raise RuntimeError("Unexpected response type from create_embedding")


@router.post("/score")
async def create_score(raw_request: Request):
    if not serving_score:
        return unsupported_task_response("score")
    request = await parse_request(raw_request, ScoreRequest)
    response = await serving_score.create_score(request, raw_request)

    if isinstance(response, ErrorResponse):
        return ORJSONResponse(content=response.model_dump(), status_code=response.code)
    elif isinstance(response, ScoreResponse):
        return ORJSONResponse(content=response.model_dump())
    raise RuntimeError("Unexpected response type from create_score")


@router.post("/v1/score")
async def create_score_v1(raw_request: Request):
    return await create_score(raw_request)


@router.post("/rerank")
async def do_rerank(raw_request: Request):
    if not serving_score:
        return unsupported_task_response("rerank")
    request = await parse_request(raw_request, RerankRequest)
    response = await serving_score.create_rerank(request, raw_request)

    if isinstance(response, ErrorResponse):
        return ORJSONResponse(content=response.model_dump(), status_code=response.code)
    elif isinstance(response, RerankResponse):
        return ORJSONResponse(content=response.model_dump())
    raise RuntimeError("Unexpected response type from create_rerank")


@router.post("/v1/rerank")
async def do_rerank_v1(raw_request: Request):
    return await do_rerank(raw_request)


@router.post("/v2/rerank")
async def do_rerank_v2(raw_request: Request):
    return await do_rerank(raw_request)


def unsupported_task_response(task: str) -> ORJSONResponse:
    return ORJSONResponse(
        content={
            "error": {
                "message": f"The model does not support {task} task.",
                "type": "invalid_request_error",
                "param": "model",
                "code": "model_not_supported",
            }
        },
        status_code=400,
    )


def init_app(
    args: Namespace,
) -> FastAPI:
    global llm
    global openai_serving_completion
    global openai_serving_chat
    global openai_serving_embedding
    global serving_score
    global openai_serving_models_response

    llm = load_llm_from_args(args)
    task = llm.model_metadata.task_type
    served_model_name = getattr(args, "served_model_name", None) or args.model

    override_chat_template = None
    if args.chat_template is not None:
        try:
            # Use a context manager to ensure the file is properly closed
            with open(args.chat_template, "r", encoding="utf-8") as f:
                override_chat_template = f.read()
        except Exception as e:
            raise ValueError(f"Error in reading chat template file: {e}")

    openai_serving_models_response = ModelsResponse.from_llm(
        llm, served_model_name=served_model_name
    )
    # XXX(n0gu): Currently we only support one task per LLM instance.
    # However in the future we may want to support multiple tasks per LLM.
    # In that case we need to modify type of ModelMetadata.task_type.
    if task in GENERATION_TASKS:
        try:
            llm.tokenizer.get_chat_template()
        except Exception as e:
            raise ValueError(
                f"Failed to load chat template from tokenizer: {e}. Please specify a chat template using the --chat-template option."
            )
        openai_serving_completion = OpenAIServingCompletion(
            llm, served_model_name=served_model_name
        )
        openai_serving_chat = OpenAIServingChat(
            llm,
            args.response_role,
            chat_template=override_chat_template,
            served_model_name=served_model_name,
            reasoning_parser=args.reasoning_parser,
            enable_auto_tools=args.enable_auto_tool_choice,
            tool_parser=args.tool_call_parser,
        )
    if task == EMBED:
        openai_serving_embedding = OpenAIServingEmbedding(llm, served_model_name=served_model_name)
    if task == SCORE:
        serving_score = ServingScores(llm, served_model_name=served_model_name)

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        if not args.disable_log_stats:
            install_metrics_logging_thread()

        try:
            await prewarm_server(llm, override_chat_template)
        except Exception as e:
            logging.warning(f"Error while pre-warming server: {e}")

        yield
        llm.engine.shutdown()

    app = FastAPI(lifespan=lifespan)
    app.include_router(router)
    if args.uvicorn_log_level in ("warning", "error", "critical"):
        app.add_middleware(Log4xx5xxMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=args.allowed_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.routes.append(get_metrics_mount())

    return app


async def prewarm_server(llm: LLM, chat_template: str | None):
    # Scarlette (used by FastAPI) uses anyio for asynchronous response streaming.
    # When anyio runs for the first time, it takes 2-4 ms just importing its async backend.
    # Do that here in advance, with a dummy async job.
    await anyio.sleep(0)

    # Prewarm tokenizer (first call to it takes 10-20 ms)
    llm.tokenizer.encode('Tokenizer test.')

    task = llm.model_metadata.task_type
    if task in POOLING_TASKS:
        # XXX(seungwon): ndarray::to_pyarray() lazy-loads Rust Numpy bindings;
        # Trigger the loading here in advance, in order to prevent first-time delays.
        _ = NativePoolingOutput(data=np.array([0], dtype=np.float32)).data

    if task in GENERATION_TASKS:
        model_config = ModelConfigAdapter(llm.model_config)
        resolved_chat_template = resolve_hf_chat_template(
            llm.tokenizer,
            chat_template=chat_template,
            tools=None,
            model_config=model_config,
        )
        resolve_chat_template_content_format(
            resolved_chat_template, None, "auto", llm.tokenizer, model_config=model_config
        )
        apply_hf_chat_template(
            llm.tokenizer,
            [ConversationMessage({"role": "user", "content": "Hello!"})],  # type: ignore[arg-type]
            resolved_chat_template,
            None,
            model_config=model_config,
        )

    if task == SCORE:
        # Create scoring prompt (to trigger Jinja template compilation)
        _ = get_score_prompt(
            llm.tokenizer, data_1="dummy query", data_2="dummy document", score_template=None
        )


def run_server(args, **uvicorn_kwargs) -> None:
    app = init_app(args)

    if args.enable_payload_logging:
        app.add_middleware(RequestLoggerMiddleware)
        logging.warning(
            "Payload logging is enabled. This might expose sensitive data. If you do not fully understand the risks associated with this option, do not enable it."
        )
        # Disable uvicorn's access log
        args.disable_uvicorn_access_log = True

    if args.api_key:
        app.add_middleware(AuthenticationMiddleware, tokens=[args.api_key])

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        log_level=args.uvicorn_log_level,
        access_log=not args.disable_uvicorn_access_log,
        **uvicorn_kwargs,
    )
