import argparse
import os

from ..api import CACHE_DIR
from ..artifact import (
    ArtifactBuilder,
    ArtifactConfig,
    BucketConfig,
    CompilerConfig,
    ModelConfig,
    ParallelConfig,
)


def add_convert_args(convert_parser):
    convert_parser.add_argument(
        "model",
        type=str,
        help='A Hugging Face model id or a local path. A path should start with \'.\' or \'/\'.',
    )

    convert_parser.add_argument(
        "output_path",
        type=str,
        help='The path to export the artifacts.',
    )

    convert_parser.add_argument(
        "--name",
        type=str,
        default="",
        help='The name of the artifact to build.',
    )

    convert_parser.add_argument(
        "-tp",
        "--tensor-parallel-size",
        type=int,
        default=8,
        help='The number of PEs for each tensor parallelism group. (default: 8)',
    )

    convert_parser.add_argument(
        "-pp",
        "--pipeline-parallel-size",
        type=int,
        default=1,
        help='The pipeline parallel size that will be used when loading the model by default. (default: 1)',
    )

    convert_parser.add_argument(
        "-pb",
        "--prefill-buckets",
        type=str,
        action='append',
        default=[],
        help='Specify the bucket size for prefill in the format batch_size,context_length. Multiple entries are allowed (e.g., `--pb 1,128 --pb 1,256`).',
    )

    convert_parser.add_argument(
        "-db",
        "--decode-buckets",
        type=str,
        action='append',
        default=[],
        help='Specify the bucket size for decode in the format batch_size,context_length. Multiple entries are allowed (e.g., `--db 4,2048 --db 16,2048`).',
    )

    convert_parser.add_argument(
        "--max-seq-len-to-capture",
        type=int,
        default=2048,
        help='The maximum sequence length supported by the LLM engine. Sequences exceeding this length will not be handled.',
    )

    convert_parser.add_argument(
        "--prefill-chunk-size",
        type=int,
        default=None,
        help='Chunk size used for chunked prefill. If this value is specified, chunked prefill is enabled. Chunked prefill is disabled by default.',
    )

    convert_parser.add_argument(
        "--additional-model-config",
        type=str,
        action='append',
        default=[],
        help='Specify compilation settings or optimization settings to apply to your model. You can specify multiple items in the form `key=value`.',
    )

    convert_parser.add_argument(
        "--num-pipeline-builder-workers",
        type=int,
        default=1,
        help='The number of workers for building pipelines (excluding compilation). Defaults to 1 (no parallelism). Higher values reduce build time for large models but require more memory.',
    )

    convert_parser.add_argument(
        "--num-compile-workers",
        type=int,
        default=1,
        help='The number of workers used for compilation.',
    )

    convert_parser.add_argument(
        "--trust-remote-code",
        action='store_true',
        default=False,
        help='Trust remote code from huggingface (default: False).',
    )

    convert_parser.add_argument(
        "--bundle-binaries",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Bundle all compiled binaries into a single archive file (binary_bundle.zip) in the output directory. "
        "By default, bundling is enabled.",
    )

    convert_parser.add_argument(
        "--cache-dir",
        type=str,
        default=str(CACHE_DIR),
        help='The cache directory for all generated files during artifact building. The default is "$HOME/.cache/furiosa/llm"',
    )

    convert_parser.set_defaults(dispatch_function=convert)


def convert(args):
    if args.prefill_buckets:
        try:
            prefill_buckets = [tuple(map(int, item.split(","))) for item in args.prefill_buckets]
        except Exception:
            raise ValueError(f"Invalid argument value: --prefill-buckets {args.prefill_buckets}'")
    else:
        prefill_buckets = []

    if args.decode_buckets:
        try:
            decode_buckets = [tuple(map(int, item.split(","))) for item in args.decode_buckets]
        except Exception:
            raise ValueError(f"Invalid argument value: --decode-buckets {args.decode_buckets}'")
    else:
        decode_buckets = []

    ## set values from `--additional-model-config``
    hf_overrides = {}
    seed_for_random_weight = None
    do_decompositions_for_model_rewrite = False
    use_blockwise_compile = True
    num_blocks_per_supertask = 1
    embed_all_constants_into_graph = False
    use_2d_attention_masks = False
    merge_kv_cache_indices = False

    if args.additional_model_config:
        for item in args.additional_model_config:
            key, _, value = item.partition("=")

            if key == "num_hidden_layers":
                hf_overrides["num_hidden_layers"] = int(value)
            elif key == "seed" or key == "seed_for_random_weight":
                seed_for_random_weight = int(value)
            elif key == "do_decompositions_for_model_rewrite":
                do_decompositions_for_model_rewrite = value.lower() == "true"
            elif key == "use_blockwise_compile":
                use_blockwise_compile = value.lower() == "true"
            elif key == "num_blocks_per_supertask":
                num_blocks_per_supertask = int(value)
            elif key == "embed_all_constants_into_graph":
                embed_all_constants_into_graph = value.lower() == "true"
            elif key == "use_2d_attention_masks":
                use_2d_attention_masks = value.lower() == "true"
            elif key == "merge_kv_cache_indices":
                merge_kv_cache_indices = value.lower() == "true"
            else:
                raise ValueError(f"Unknown model configuration key: '{key}'")

    # Build config objects
    model_config = ModelConfig(
        trust_remote_code=args.trust_remote_code,
        hf_overrides=hf_overrides,
        seed_for_random_weight=seed_for_random_weight,
    )

    parallel_config = ParallelConfig(
        tensor_parallel_size=args.tensor_parallel_size,
        pipeline_parallel_size=args.pipeline_parallel_size,
    )

    bucket_config = BucketConfig(
        prefill_buckets=prefill_buckets,
        decode_buckets=decode_buckets,
        max_seq_len_to_capture=args.max_seq_len_to_capture,
        prefill_chunk_size=args.prefill_chunk_size,
    )

    compiler_config = CompilerConfig(
        do_decompositions_for_model_rewrite=do_decompositions_for_model_rewrite,
        use_blockwise_compile=use_blockwise_compile,
        num_blocks_per_supertask=num_blocks_per_supertask,
        embed_all_constants_into_graph=embed_all_constants_into_graph,
        use_2d_attention_masks=use_2d_attention_masks,
        merge_kv_cache_indices=merge_kv_cache_indices,
    )

    artifact_config = ArtifactConfig(
        bundle_binaries=args.bundle_binaries,
    )

    builder = ArtifactBuilder(
        args.model,
        args.name,
        model_config=model_config,
        parallel_config=parallel_config,
        bucket_config=bucket_config,
        compiler_config=compiler_config,
        artifact_config=artifact_config,
    )

    # Set logging options for ray.
    if "RAY_COLOR_PREFIX" not in os.environ:
        os.environ["RAY_COLOR_PREFIX"] = "1"
    if "RAY_DEDUP_LOGS_ALLOW_REGEX" not in os.environ:
        # For not to dedup our info logs.
        os.environ["RAY_DEDUP_LOGS_ALLOW_REGEX"] = "INFO:*[furiosa-llm]*"

    builder.build(
        args.output_path,
        num_pipeline_builder_workers=args.num_pipeline_builder_workers,
        num_compile_workers=args.num_compile_workers,
        cache_dir=args.cache_dir,
    )

    print("Artifact Build Completed")
