<script lang="ts">
  import { parseFormula } from "@hyrr/compute";
  import type { Issue, Row } from "./define-form-rows";

  interface Props {
    row: Row;
    issues: Issue[];
    /** Parent splices immutably. No bind: into nested $state per #92 §3.2. */
    onchange: (patch: Partial<Row>) => void;
    onremove: () => void;
    /** Open ElementPopup scoped to this row's element (#93). Only fired
     *  for single-element rows (compounds defer to a future cycle). */
    oneditenrichment?: (rowId: string, element: string) => void;
  }

  let { row, issues, onchange, onremove, oneditenrichment }: Props = $props();

  /** Single-element rows expose a per-row "E" button to override that
   *  element's isotopic vector. Compound rows hide it (no obvious choice
   *  of which element to enrich; would need disambiguation UI). */
  const singleElement = $derived.by((): string | null => {
    try {
      const counts = parseFormula(row.formula);
      const elements = Object.keys(counts);
      return elements.length === 1 ? elements[0] : null;
    } catch { return null; }
  });

  const hasRowEnrichment = $derived(
    singleElement !== null && row.enrichment !== undefined && row.enrichment[singleElement] !== undefined,
  );
</script>

<div class="row" role="row" data-row-id={row.id}>
  <span class="formula" role="gridcell">{row.formula}</span>

  <input
    type="number"
    class="value-input"
    role="gridcell"
    inputmode="decimal"
    step="any"
    min="0"
    placeholder={row.isBalance ? "balance" : "0"}
    aria-label={`Value for ${row.formula}`}
    disabled={row.isBalance}
    value={row.value ?? ""}
    oninput={(e) => {
      const v = parseFloat((e.target as HTMLInputElement).value);
      onchange({ value: Number.isFinite(v) ? v : null });
    }}
  />

  <div role="gridcell">
    <label class="balance-label" title="Use this row to balance to 100% — click again to clear">
      <input
        type="checkbox"
        checked={row.isBalance}
        aria-label={row.isBalance ? `Clear balance for ${row.formula}` : `Set ${row.formula} as the balance row`}
        onchange={(e) => {
          const checked = (e.target as HTMLInputElement).checked;
          onchange({ isBalance: checked, ...(checked ? { value: null } : {}) });
        }}
      />
      <span class="balance-text">balance</span>
    </label>
  </div>

  {#if singleElement && oneditenrichment}
    <button
      type="button"
      class="enrich-btn"
      class:active={hasRowEnrichment}
      role="gridcell"
      aria-label={`Edit isotope enrichment for ${singleElement}`}
      title={hasRowEnrichment ? `Row enrichment set for ${singleElement} — click to edit` : `Override natural isotope abundance for ${singleElement}`}
      onclick={() => oneditenrichment(row.id, singleElement)}
    >enr</button>
  {/if}

  <button
    type="button"
    class="remove-btn"
    role="gridcell"
    aria-label={`Remove ${row.formula}`}
    onclick={onremove}
  >×</button>
</div>

{#if issues.length > 0}
  <div class="row-issues">
    {#each issues as issue}
      <p class="issue-{issue.level}">{issue.message}</p>
    {/each}
  </div>
{/if}

<style>
  .row {
    display: grid;
    grid-template-columns: minmax(2.5rem, auto) minmax(0, 5rem) auto auto 1.5rem;
    gap: 0.4rem;
    align-items: center;
    padding: 0.25rem 0.4rem;
    background: var(--c-bg-subtle);
    border: 1px solid var(--c-border);
    border-radius: 4px;
    font-size: 0.75rem;
  }

  .enrich-btn {
    background: var(--c-bg-default);
    border: 1px solid var(--c-border);
    border-radius: 3px;
    color: var(--c-text-muted);
    font-size: 0.6rem;
    padding: 0.1rem 0.25rem;
    height: 1.4rem;
    line-height: 1;
    cursor: pointer;
    font-weight: 600;
    white-space: nowrap;
  }
  .enrich-btn:hover { color: var(--c-accent); border-color: var(--c-accent); }
  .enrich-btn.active {
    color: var(--c-gold, var(--c-accent));
    border-color: var(--c-gold, var(--c-accent));
    background: var(--c-gold-tint-subtle, var(--c-bg-active));
  }
  .enrich-btn:focus-visible { outline: 2px solid var(--c-accent); outline-offset: 1px; }

  .formula {
    font-weight: 500;
    color: var(--c-text);
    font-family: monospace;
  }

  .value-input {
    background: var(--c-bg-default);
    border: 1px solid var(--c-border);
    border-radius: 3px;
    color: var(--c-text);
    padding: 0.15rem 0.3rem;
    font-size: 0.75rem;
    min-width: 0;
  }

  .value-input:focus {
    outline: none;
    border-color: var(--c-accent);
  }

  .value-input:disabled {
    color: var(--c-text-subtle);
    background: var(--c-bg-muted);
  }

  .balance-label {
    display: inline-flex;
    align-items: center;
    gap: 0.25rem;
    color: var(--c-text-muted);
    font-size: 0.7rem;
    cursor: pointer;
  }

  .balance-label input[type="checkbox"] {
    accent-color: var(--c-accent);
    cursor: pointer;
  }

  .balance-text {
    user-select: none;
  }

  .remove-btn {
    background: none;
    border: none;
    color: var(--c-text-subtle);
    font-size: 1rem;
    line-height: 1;
    cursor: pointer;
    padding: 0;
    border-radius: 3px;
  }

  .remove-btn:hover { color: var(--c-red); }
  .remove-btn:focus-visible { outline: 2px solid var(--c-accent); outline-offset: 1px; }

  .row-issues {
    margin: 0.15rem 0 0.3rem 0.6rem;
  }

  .issue-error {
    color: var(--c-red);
    font-size: 0.7rem;
    margin: 0;
  }

  .issue-warning {
    color: var(--c-yellow, var(--c-text-muted));
    font-size: 0.7rem;
    margin: 0;
  }
</style>
