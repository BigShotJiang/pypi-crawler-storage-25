<script lang="ts">
  import { getConfig, getSerializableConfig } from "../stores/config.svelte";
  import { getResult, getResultError } from "../stores/results.svelte";
  import { buildBugReportBody } from "./bug-report-body";
  import { getShareableUrl } from "../config-url";
  import { getBugReportOpen, closeBugReport } from "../stores/bugreport.svelte";
  import { isTauri } from "../utils/platform";
  import { openExternalUrl } from "../utils/open-url";
  import { buildIssueTitle } from "./bug-report-title";

  let open = $derived(getBugReportOpen());

  let name = $state("");
  let email = $state("");
  let title = $state("");
  let description = $state("");
  let screenshot = $state<Blob | null>(null);
  let screenshotPreview = $state<string | null>(null);
  let reportType = $state<"bug" | "feature">("bug");
  let submitting = $state(false);
  let capturing = $state(false);
  let resultMsg = $state<{ ok: boolean; text: string } | null>(null);
  let turnstileToken = $state<string | null>(null);
  let turnstileWidgetId = $state<string | null>(null);
  let turnstileEl: HTMLDivElement | undefined = $state();

  const WORKER_URL = import.meta.env.VITE_ISSUE_WORKER_URL ?? "";
  const TURNSTILE_SITE_KEY = import.meta.env.VITE_TURNSTILE_SITE_KEY ?? "";
  const REPO = "exoma-ch/hyrr";
  const desktop = isTauri();
  const MAX_DIM = 1280;
  const JPEG_QUALITY = 0.8;

  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  let emailValid = $derived(!email.trim() || EMAIL_RE.test(email));
  /** Worker submit requires email + description; GitHub route only needs description. */
  let canSubmitWorker = $derived(
    (description.trim().length > 0 || screenshot !== null) &&
    email.trim().length > 0 &&
    EMAIL_RE.test(email) &&
    !submitting
  );
  let canOpenGitHub = $derived((description.trim().length > 0 || screenshot !== null) && !submitting);
  /** Why the GH/email/save buttons are disabled, so the title= tooltip can
   *  tell the user what's missing instead of nothing happening on click. */
  let disabledReason = $derived.by(() => {
    if (submitting) return "Submitting…";
    if (description.trim().length === 0 && screenshot === null) {
      return "Add a description or attach a screenshot first";
    }
    return "";
  });

  // Localhost / dev: the Cloudflare Turnstile widget doesn't validate and the
  // worker rejects submissions, so the direct Submit path is dead. Fall
  // back to Open-on-GitHub / Mailto. Detect common dev hosts.
  let isLocalhost = $derived.by(() => {
    if (typeof window === "undefined") return false;
    const h = window.location.hostname;
    return h === "localhost" || h === "127.0.0.1" || h === "" || h === "0.0.0.0" || h.endsWith(".local");
  });

  const MAILTO_TARGET: string = ((import.meta.env as Record<string, string | undefined>).VITE_BUG_REPORT_EMAIL) ?? "";

  function openMailto() {
    if (!canOpenGitHub) return;
    const subj = buildIssueTitle(reportType, title, description);
    const body = buildBody();
    const qs = new URLSearchParams({ subject: subj, body }).toString();
    const to = MAILTO_TARGET;
    window.location.href = `mailto:${to}?${qs}`;
  }

  /** Wait for the Turnstile API to become available (loaded async). */
  function waitForTurnstile(timeout = 5000): Promise<boolean> {
    if (typeof window.turnstile !== "undefined") return Promise.resolve(true);
    return new Promise((resolve) => {
      const start = Date.now();
      const check = setInterval(() => {
        if (typeof window.turnstile !== "undefined") { clearInterval(check); resolve(true); }
        else if (Date.now() - start > timeout) { clearInterval(check); resolve(false); }
      }, 100);
    });
  }

  /** Render or re-render the invisible Turnstile widget. Returns a token promise. */
  async function getTurnstileToken(): Promise<string | null> {
    if (!TURNSTILE_SITE_KEY) return null;
    const ready = await waitForTurnstile();
    if (!ready || !turnstileEl) return null;

    try {
      // Clean up previous widget
      if (turnstileWidgetId !== null) {
        window.turnstile.remove(turnstileWidgetId);
        turnstileWidgetId = null;
      }
      turnstileToken = null;

      return new Promise((resolve) => {
        turnstileWidgetId = window.turnstile.render(turnstileEl!, {
          sitekey: TURNSTILE_SITE_KEY,
          size: "invisible",
          callback: (token: string) => { turnstileToken = token; resolve(token); },
          "error-callback": () => { turnstileToken = null; resolve(null); },
          "expired-callback": () => { turnstileToken = null; resolve(null); },
        });
        // Trigger the invisible challenge
        window.turnstile.execute(turnstileWidgetId!);
        // Timeout fallback
        setTimeout(() => resolve(turnstileToken), 10000);
      });
    } catch (e) {
      console.warn("Turnstile failed:", e);
      return null;
    }
  }

  /** Capture the page behind this panel using html2canvas. */
  async function captureScreen() {
    capturing = true;
    try {
      const html2canvas = (await import("html2canvas")).default;
      // Hide the bug report panel during capture
      const panel = document.querySelector(".bug-panel") as HTMLElement | null;
      if (panel) panel.style.visibility = "hidden";

      const canvas = await html2canvas(document.body, {
        backgroundColor: getComputedStyle(document.documentElement).getPropertyValue("--c-bg-default").trim() || "#0d1117",
        scale: 1,
        logging: false,
        useCORS: true,
      });

      if (panel) panel.style.visibility = "";

      // Downsample if needed
      const blob = await downsampleCanvas(canvas);
      screenshot = blob;
      screenshotPreview = canvas.toDataURL("image/jpeg", 0.6);
    } catch (e) {
      console.warn("Screenshot capture failed:", e);
    } finally {
      capturing = false;
    }
  }

  function handleFileSelect(e: Event) {
    const input = e.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file || !file.type.startsWith("image/")) return;

    // Downsample the file
    downsampleFile(file).then((blob) => {
      screenshot = blob;
    });

    // Preview
    const reader = new FileReader();
    reader.onload = () => { screenshotPreview = reader.result as string; };
    reader.readAsDataURL(file);
  }

  function removeScreenshot() {
    screenshot = null;
    screenshotPreview = null;
  }

  async function downsampleCanvas(canvas: HTMLCanvasElement): Promise<Blob> {
    let { width, height } = canvas;
    if (width > MAX_DIM || height > MAX_DIM) {
      const scale = MAX_DIM / Math.max(width, height);
      const w = Math.round(width * scale);
      const h = Math.round(height * scale);
      const oc = new OffscreenCanvas(w, h);
      const ctx = oc.getContext("2d")!;
      ctx.drawImage(canvas, 0, 0, w, h);
      return oc.convertToBlob({ type: "image/jpeg", quality: JPEG_QUALITY });
    }
    return new Promise((r) => canvas.toBlob((b) => r(b!), "image/jpeg", JPEG_QUALITY));
  }

  async function downsampleFile(file: File): Promise<Blob> {
    const bitmap = await createImageBitmap(file);
    let { width, height } = bitmap;
    if (width > MAX_DIM || height > MAX_DIM) {
      const scale = MAX_DIM / Math.max(width, height);
      width = Math.round(width * scale);
      height = Math.round(height * scale);
    }
    const canvas = new OffscreenCanvas(width, height);
    const ctx = canvas.getContext("2d")!;
    ctx.drawImage(bitmap, 0, 0, width, height);
    bitmap.close();
    return canvas.convertToBlob({ type: "image/jpeg", quality: JPEG_QUALITY });
  }

  async function uploadScreenshot(blob: Blob): Promise<string | null> {
    if (!WORKER_URL) return null;
    try {
      const res = await fetch(`${WORKER_URL}/upload`, {
        method: "POST",
        headers: { "Content-Type": "image/jpeg" },
        body: blob,
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.url;
    } catch {
      return null;
    }
  }

  function buildBody(screenshotUrl?: string): string {
    // getShareableUrl requires SerializableConfig (with `items`, group-aware);
    // getConfig returns SimulationConfig (flat `layers`). Use the right shape
    // for the URL, keep the flat shape for the human-readable debug summary.
    return buildBugReportBody({
      reportType,
      title,
      name,
      email,
      description,
      screenshotUrl,
      config: getConfig(),
      configUrl: getShareableUrl(getSerializableConfig()),
      result: getResult(),
      computeError: getResultError(),
      appVersion: __APP_VERSION__,
      userAgent: navigator.userAgent,
    });
  }

  /** Submit via worker (requires email + Turnstile). */
  async function submitViaWorker() {
    if (!canSubmitWorker || !WORKER_URL) return;
    if (!description.trim() && !screenshot) return;

    submitting = true;
    resultMsg = null;

    // Get Turnstile token (renders widget on demand, waits for challenge)
    const token = await getTurnstileToken();

    const issueTitle = buildIssueTitle(reportType, title, description);

    try {
      let screenshotUrl: string | undefined;
      if (screenshot) {
        const url = await uploadScreenshot(screenshot);
        if (url) screenshotUrl = url;
      }

      const body = buildBody(screenshotUrl);
      const res = await fetch(WORKER_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: issueTitle,
          body,
          labels: [reportType === "bug" ? "bug" : "enhancement"],
          email,
          "cf-turnstile-response": token ?? "",
        }),
      });
      const data = await res.json();
      if (res.ok) {
        resultMsg = { ok: true, text: `Issue #${data.number} created` };
        resetForm();
        setTimeout(() => { resultMsg = null; closeBugReport(); }, 2000);
      } else {
        resultMsg = { ok: false, text: data.error ?? "Failed to create issue" };
      }
    } catch {
      resultMsg = { ok: false, text: "Network error — try 'Open on GitHub' instead" };
    } finally {
      submitting = false;
    }
  }

  /** Open on GitHub directly (user authenticates via their GH session). */
  function openOnGitHub() {
    if (!canOpenGitHub) return;
    const issueTitle = buildIssueTitle(reportType, title, description);
    const body = buildBody();

    const url = `https://github.com/${REPO}/issues/new?` + new URLSearchParams({
      title: issueTitle,
      body,
      labels: reportType === "bug" ? "bug" : "enhancement",
    }).toString();

    void openExternalUrl(url);
    resetForm();
    closeBugReport();
  }

  /** Save bug report + screenshot to a local folder via Tauri dialog. */
  async function saveToFile() {
    if (!description.trim() && !screenshot) return;
    submitting = true;
    resultMsg = null;

    try {
      const { save } = await import("@tauri-apps/plugin-dialog");
      const { writeTextFile, writeFile } = await import("@tauri-apps/plugin-fs");

      const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
      const baseName = `hyrr-bugreport-${ts}`;

      // Save markdown report
      const reportPath = await save({
        defaultPath: `${baseName}.md`,
        filters: [{ name: "Markdown", extensions: ["md"] }],
        title: "Save bug report",
      });
      if (!reportPath) { submitting = false; return; }

      const body = buildBody();
      const issueTitle = buildIssueTitle(reportType, title, description);
      const content = `# ${issueTitle}\n\n${body}`;
      await writeTextFile(reportPath, content);

      // Save screenshot alongside the report if present
      if (screenshot) {
        const imgPath = reportPath.replace(/\.md$/, ".jpg");
        const buf = await screenshot.arrayBuffer();
        await writeFile(imgPath, new Uint8Array(buf));
      }

      resultMsg = { ok: true, text: `Saved to ${reportPath}` };
      resetForm();
      setTimeout(() => { resultMsg = null; closeBugReport(); }, 2500);
    } catch (e) {
      resultMsg = { ok: false, text: `Save failed: ${e}` };
    } finally {
      submitting = false;
    }
  }

  function resetForm() {
    title = "";
    description = "";
    screenshot = null;
    screenshotPreview = null;
  }
</script>

{#if open}
  <div class="bug-panel" role="dialog" aria-label={reportType === "bug" ? "Report a Bug" : "Request a Feature"}>
    <div class="panel-header">
      <h3>{reportType === "bug" ? "Report a Bug" : "Request a Feature"}</h3>
      <button class="close-btn" onclick={closeBugReport}>&times;</button>
    </div>

    <div class="panel-body">
      <p class="tip">
        Tip: Keep the bug visible behind this panel before capturing.
      </p>

      <div class="type-toggle">
        <button
          class="type-btn"
          class:active={reportType === "bug"}
          onclick={() => reportType = "bug"}
        >Bug</button>
        <button
          class="type-btn"
          class:active={reportType === "feature"}
          onclick={() => reportType = "feature"}
        >Feature</button>
      </div>

      <div class="field">
        <label for="bug-name">Your name <span class="optional">(optional, for follow-up — leave blank for anonymous)</span></label>
        <input id="bug-name" type="text" bind:value={name} placeholder="leave blank for anonymous" />
      </div>

      {#if !desktop}
        <div class="field">
          <label for="bug-email">Email {#if WORKER_URL}<span class="required">* for Submit</span>{:else}<span class="optional">(optional)</span>{/if}</label>
          <input
            id="bug-email"
            type="email"
            bind:value={email}
            placeholder="your@email.com"
            class:invalid={email.length > 0 && !emailValid}
          />
          {#if email.length > 0 && !emailValid}
            <span class="field-error">Please enter a valid email address</span>
          {/if}
        </div>
      {/if}

      <div class="field">
        <label for="bug-title">Title <span class="optional">(optional — auto-generated from description if blank)</span></label>
        <input
          id="bug-title"
          type="text"
          bind:value={title}
          placeholder="Short summary, e.g. 'Heavy ions crash compute'"
          maxlength="70"
        />
      </div>

      <div class="field">
        <label for="bug-desc">Description <span class="required">*</span></label>
        <textarea
          id="bug-desc"
          bind:value={description}
          placeholder={reportType === "bug" ? "What happened? What did you expect?" : "What would you like to see?"}
          rows="3"
        ></textarea>
      </div>

      <div class="field">
        <span class="field-label">Screenshot <span class="optional">(optional)</span></span>
        {#if screenshotPreview}
          <div class="preview-wrap">
            <img src={screenshotPreview} alt="Screenshot preview" class="preview-img" />
            <button class="remove-btn" onclick={removeScreenshot} title="Remove">&times;</button>
          </div>
        {:else}
          <div class="screenshot-actions">
            <button class="capture-btn" onclick={captureScreen} disabled={capturing}>
              {#if capturing}Capturing...{:else}Capture tab{/if}
            </button>
            <label class="file-drop-inline" for="bug-screenshot">
              or attach file
              <input
                id="bug-screenshot"
                type="file"
                accept="image/*"
                onchange={handleFileSelect}
                class="file-input"
              />
            </label>
          </div>
        {/if}
      </div>

      {#if !desktop}
        <!-- Invisible Turnstile widget container -->
        <div bind:this={turnstileEl}></div>
      {/if}

      <p class="hint">
        Config and simulation state attached automatically.
        {#if desktop}
          Save the report as a file and email it, or open on GitHub if you have internet.
        {:else if WORKER_URL}
          Have a GitHub account? Use "Open on GitHub" — no email needed.
        {/if}
      </p>

      {#if resultMsg}
        <p class="result-msg" class:success={resultMsg.ok} class:error={!resultMsg.ok}>
          {resultMsg.text}
        </p>
      {/if}

      {#if isLocalhost && !desktop}
        <p class="hint">
          Running locally — direct submit is disabled (Turnstile can't validate).
          Use <strong>Open on GitHub</strong>{MAILTO_TARGET ? " or " : ""}{#if MAILTO_TARGET}<strong>Email</strong>{/if}.
        </p>
      {/if}

      <div class="actions">
        <button class="cancel-btn" onclick={closeBugReport}>Cancel</button>
        {#if desktop}
          <button
            class="gh-btn"
            onclick={openOnGitHub}
            disabled={!canOpenGitHub}
            title={disabledReason || "Opens GitHub in your browser (needs internet)"}
          >
            Open on GitHub
          </button>
          <button
            class="submit-btn"
            onclick={saveToFile}
            disabled={!canOpenGitHub || submitting}
            title={disabledReason || "Save report as a file to share later"}
          >
            {#if submitting}Saving...{:else}Save to file{/if}
          </button>
        {:else}
          <button
            class="gh-btn"
            onclick={openOnGitHub}
            disabled={!canOpenGitHub}
            title={disabledReason || "Opens GitHub — you'll review before submitting"}
          >
            Open on GitHub
          </button>
          {#if MAILTO_TARGET}
            <button
              class="gh-btn"
              onclick={openMailto}
              disabled={!canOpenGitHub}
              title={disabledReason || "Send via your email client"}
            >
              Email
            </button>
          {/if}
          {#if WORKER_URL && !isLocalhost}
            <button
              class="submit-btn"
              onclick={submitViaWorker}
              disabled={!canSubmitWorker}
              title="Submit directly (requires email)"
            >
              {#if submitting}Submitting...{:else}Submit{/if}
            </button>
          {/if}
        {/if}
      </div>
    </div>
  </div>
{/if}

<style>
  .bug-panel {
    position: fixed;
    bottom: 1rem;
    right: 1rem;
    width: 340px;
    max-height: 80vh;
    background: var(--c-bg-subtle);
    border: 1px solid var(--c-border);
    border-radius: 10px;
    box-shadow: 0 8px 32px var(--c-overlay-heavy);
    z-index: 2000;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.6rem 0.75rem;
    border-bottom: 1px solid var(--c-border);
    cursor: grab;
    flex-shrink: 0;
  }

  .panel-header h3 {
    margin: 0;
    font-size: 0.9rem;
    color: var(--c-text);
  }

  .close-btn {
    background: none;
    border: none;
    color: var(--c-text-muted);
    font-size: 1.2rem;
    cursor: pointer;
    padding: 0.1rem 0.3rem;
    border-radius: 4px;
    line-height: 1;
  }

  .close-btn:hover {
    color: var(--c-text);
    background: var(--c-bg-muted);
  }

  .panel-body {
    padding: 0.75rem;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 0.6rem;
  }

  .tip {
    font-size: 0.7rem;
    color: var(--c-gold);
    margin: 0;
    padding: 0.3rem 0.5rem;
    background: var(--c-gold-tint-faint);
    border-radius: 4px;
    border-left: 2px solid var(--c-gold);
  }

  .type-toggle {
    display: flex;
    gap: 0.2rem;
  }

  .type-btn {
    flex: 1;
    padding: 0.2rem;
    background: var(--c-bg-default);
    border: 1px solid var(--c-border);
    border-radius: 3px;
    color: var(--c-text-muted);
    font-size: 0.7rem;
    cursor: pointer;
  }

  .type-btn:hover {
    border-color: var(--c-accent);
  }

  .type-btn.active {
    background: var(--c-bg-active);
    border-color: var(--c-accent);
    color: var(--c-accent);
  }

  .field {
    display: flex;
    flex-direction: column;
    gap: 0.2rem;
  }

  label, .field-label {
    font-size: 0.75rem;
    color: var(--c-text-label);
  }

  .optional {
    color: var(--c-text-subtle);
    font-weight: normal;
  }

  .required {
    color: var(--c-red);
  }

  input, textarea {
    background: var(--c-bg-default);
    border: 1px solid var(--c-border);
    border-radius: 4px;
    color: var(--c-text);
    padding: 0.35rem 0.45rem;
    font-size: 0.8rem;
    font-family: inherit;
    resize: vertical;
  }

  input:focus, textarea:focus {
    outline: none;
    border-color: var(--c-accent);
  }

  input.invalid {
    border-color: var(--c-red);
  }

  .field-error {
    font-size: 0.65rem;
    color: var(--c-red);
  }

  .screenshot-actions {
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .capture-btn {
    background: var(--c-bg-muted);
    border: 1px solid var(--c-border);
    border-radius: 4px;
    color: var(--c-text-label);
    padding: 0.35rem 0.6rem;
    font-size: 0.75rem;
    cursor: pointer;
    white-space: nowrap;
  }

  .capture-btn:hover:not(:disabled) {
    background: var(--c-border-muted);
    border-color: var(--c-text-faint);
  }

  .capture-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .file-drop-inline {
    font-size: 0.7rem;
    color: var(--c-accent);
    cursor: pointer;
  }

  .file-drop-inline:hover {
    text-decoration: underline;
  }

  .file-input {
    display: none;
  }

  .preview-wrap {
    position: relative;
    display: inline-block;
  }

  .preview-img {
    max-width: 100%;
    max-height: 120px;
    border-radius: 4px;
    border: 1px solid var(--c-border);
  }

  .remove-btn {
    position: absolute;
    top: 4px;
    right: 4px;
    background: var(--c-overlay-heavy);
    border: 1px solid var(--c-border);
    border-radius: 50%;
    color: var(--c-red);
    width: 18px;
    height: 18px;
    font-size: 0.7rem;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    line-height: 1;
  }

  .hint {
    font-size: 0.7rem;
    color: var(--c-text-subtle);
    margin: 0;
  }

  .result-msg {
    font-size: 0.75rem;
    margin: 0;
    padding: 0.3rem 0.45rem;
    border-radius: 4px;
  }

  .result-msg.success {
    color: var(--c-green-bright);
    background: var(--c-green-tint);
  }

  .result-msg.error {
    color: var(--c-red);
    background: var(--c-red-tint-subtle);
  }

  .actions {
    display: flex;
    justify-content: flex-end;
    gap: 0.4rem;
  }

  .cancel-btn {
    background: none;
    border: 1px solid var(--c-border);
    border-radius: 4px;
    color: var(--c-text-muted);
    padding: 0.35rem 0.6rem;
    font-size: 0.75rem;
    cursor: pointer;
  }

  .cancel-btn:hover {
    color: var(--c-text);
    border-color: var(--c-text-faint);
  }

  .gh-btn {
    background: var(--c-bg-muted);
    border: 1px solid var(--c-border);
    border-radius: 4px;
    color: var(--c-text);
    padding: 0.35rem 0.6rem;
    font-size: 0.75rem;
    cursor: pointer;
    font-weight: 500;
  }

  .gh-btn:hover:not(:disabled) {
    background: var(--c-border-muted);
    border-color: var(--c-text-faint);
  }

  .gh-btn:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }

  .submit-btn {
    background: var(--c-green);
    border: 1px solid var(--c-green-emphasis);
    border-radius: 4px;
    color: #fff;
    padding: 0.35rem 0.6rem;
    font-size: 0.75rem;
    cursor: pointer;
    font-weight: 500;
  }

  .submit-btn:hover:not(:disabled) {
    background: var(--c-green-emphasis);
  }

  .submit-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
</style>
