/**
 * Shared formatting utilities for activity, yield, and time units.
 */

import { Z_TO_SYMBOL } from "./formula";

/** SI prefix table — descending so the first row ≤ |v| wins. */
const SI_PREFIXES: ReadonlyArray<readonly [number, string]> = [
  [1e12, "T"], [1e9, "G"], [1e6, "M"], [1e3, "k"],
  [1, ""],
  [1e-3, "m"], [1e-6, "µ"], [1e-9, "n"], [1e-12, "p"],
];

/**
 * Format a value with the best SI-prefixed unit. `precision` is passed to
 * `toPrecision`. Falls back to scientific notation outside the prefix range.
 * Returns `"—"` for non-finite input and `"0"` for exact zero.
 */
function fmtSI(value: number, baseUnit: string, precision: number): string {
  if (typeof value !== "number" || !isFinite(value)) return "—";
  if (value === 0) return "0";
  const abs = Math.abs(value);
  for (const [factor, prefix] of SI_PREFIXES) {
    if (abs >= factor) return `${(value / factor).toPrecision(precision)} ${prefix}${baseUnit}`;
  }
  return `${value.toExponential(2)} ${baseUnit}`;
}

/** Pick the SI prefix label + divisor for a magnitude (for plot axes / column headers). */
function bestSIUnit(maxAbs: number, baseUnit: string): { label: string; divisor: number } {
  for (const [factor, prefix] of SI_PREFIXES) {
    if (maxAbs >= factor) return { label: `${prefix}${baseUnit}`, divisor: factor };
  }
  return { label: baseUnit, divisor: 1 };
}

/** Auto-scale activity to the best human-readable unit. */
export function fmtActivity(bq: number): string {
  return fmtSI(bq, "Bq", 4);
}

/** Auto-scale saturation yield. */
export function fmtYield(val: number): string {
  return fmtSI(val, "Bq/µA", 3);
}

/** Auto-scale dose rate (µSv/h input) to the best human-readable unit. */
export function fmtDoseRate(uSvPerH: number): string {
  if (typeof uSvPerH !== "number" || !isFinite(uSvPerH)) return "—";
  if (uSvPerH === 0) return "0";
  // Input arrives in µSv/h; rebase to Sv/h so the SI prefix table picks the right rung.
  return fmtSI(uSvPerH * 1e-6, "Sv/h", 3);
}

/** Find the best unit and divisor for a set of activity values. */
export function bestActivityUnit(maxBq: number): { label: string; divisor: number } {
  return bestSIUnit(maxBq, "Bq");
}

/** Pick best time unit for display. */
export function bestTimeUnit(maxS: number): { label: string; divisor: number } {
  if (maxS >= 86400 * 2) return { label: "d", divisor: 86400 };
  if (maxS >= 3600 * 2) return { label: "h", divisor: 3600 };
  if (maxS >= 120) return { label: "min", divisor: 60 };
  return { label: "s", divisor: 1 };
}

/** Build NuDat 3.0 URL for an isotope. */
export function nudatUrl(Z: number, A: number, _state?: string): string {
  const sym = Z_TO_SYMBOL[Z] ?? "";
  return `https://www.nndc.bnl.gov/nudat3/getdataset.jsp?nucleus=${A}${sym.toUpperCase()}`;
}

/** Unicode superscript digits for mass number formatting. */
const SUPERSCRIPT_DIGITS = "\u2070\u00B9\u00B2\u00B3\u2074\u2075\u2076\u2077\u2078\u2079";
const SUPERSCRIPT_CHARS: Record<string, string> = { m: "\u1D50" };

/** Convert a string of digits (and optional 'm') to unicode superscript. */
export function toSuperscript(s: string | number): string {
  return String(s).split("").map((c) => {
    const d = parseInt(c, 10);
    if (!isNaN(d)) return SUPERSCRIPT_DIGITS[d];
    return SUPERSCRIPT_CHARS[c] ?? c;
  }).join("");
}

/**
 * Parse an isotope name like "Co-58m" or "Na-22" into parts.
 * Returns null if the format doesn't match.
 */
function parseIsotopeName(name: string): { symbol: string; mass: string; state: string } | null {
  const m = name.match(/^([A-Z][a-z]?)-(\d+)(m\d?)?$/);
  if (!m) return null;
  return { symbol: m[1], mass: m[2], state: m[3] ?? "" };
}

/**
 * Spectroscopy notation with unicode superscripts (for Plotly legends, plain text).
 * "Co-58m" → "⁵⁸ᵐCo", "Na-22" → "²²Na"
 */
export function nucLabel(name: string): string {
  const p = parseIsotopeName(name);
  if (!p) return name;
  return `${toSuperscript(p.mass + p.state)}${p.symbol}`;
}

/**
 * Spectroscopy notation with HTML superscripts (for Svelte {@html}).
 * "Co-58m" → "<sup>58m</sup>Co", "Na-22" → "<sup>22</sup>Na"
 */
export function nucHtml(name: string): string {
  const p = parseIsotopeName(name);
  if (!p) return name;
  return `<sup>${p.mass}${p.state}</sup>${p.symbol}`;
}

/** Known light particles by (Z, A). */
const PARTICLE_MAP: Array<[number, number, string]> = [
  [0, 0, "\u03B3"],
  [0, 1, "n"],
  [1, 1, "p"],
  [1, 2, "d"],
  [1, 3, "t"],
  [2, 3, "\u00B3He"],
  [2, 4, "\u03B1"],
];

/**
 * Decompose total ejectile (Z, A) into known light particles.
 * Greedy: tries heaviest particles first.
 */
function decomposeEjectiles(ejectileZ: number, ejectileA: number): string {
  if (ejectileZ === 0 && ejectileA === 0) return "\u03B3";

  let remZ = ejectileZ;
  let remA = ejectileA;
  const counts: Array<[string, number]> = [];

  // Try particles from heaviest to lightest (skip γ)
  for (let i = PARTICLE_MAP.length - 1; i >= 1; i--) {
    const [pZ, pA, sym] = PARTICLE_MAP[i];
    if (pZ === 0 && pA === 0) continue;
    let count = 0;
    while (remZ >= pZ && remA >= pA && (remZ > 0 || remA > 0)) {
      remZ -= pZ;
      remA -= pA;
      count++;
    }
    if (count > 0) counts.push([sym, count]);
  }

  if (remZ !== 0 || remA !== 0) {
    // Couldn't fully decompose — fall back to raw notation
    return `Z=${ejectileZ},A=${ejectileA}`;
  }

  return counts.map(([sym, n]) => (n > 1 ? `${n}${sym}` : sym)).join("");
}

/**
 * Build nuclear reaction notation string.
 *
 * Example: ¹⁰⁰Mo(p,2n)⁹⁹Tc
 *
 * Uses conservation laws to determine ejectile:
 *   ejectileZ = targetZ + projZ - residualZ
 *   ejectileA = targetA + projA - residualA
 */
export function buildReactionNotation(
  projZ: number,
  projA: number,
  targetZ: number,
  targetA: number,
  residualZ: number,
  residualA: number,
): string {
  const ejectileZ = targetZ + projZ - residualZ;
  const ejectileA = targetA + projA - residualA;

  const targetSym = Z_TO_SYMBOL[targetZ] ?? `Z${targetZ}`;
  const residualSym = Z_TO_SYMBOL[residualZ] ?? `Z${residualZ}`;

  // Projectile symbol
  const projMatch = PARTICLE_MAP.find(([z, a]) => z === projZ && a === projA);
  const projSym = projMatch ? projMatch[2] : `Z${projZ}`;

  const ejectileSym = decomposeEjectiles(ejectileZ, ejectileA);

  return `${toSuperscript(targetA)}${targetSym}(${projSym},${ejectileSym})${toSuperscript(residualA)}${residualSym}`;
}
