"""Tests for hyrr."""
