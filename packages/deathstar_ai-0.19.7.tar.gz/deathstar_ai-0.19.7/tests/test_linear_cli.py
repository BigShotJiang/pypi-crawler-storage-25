from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx
from typer.testing import CliRunner

from deathstar_cli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_config() -> MagicMock:
    """Return a minimal CLIConfig mock."""
    cfg = MagicMock()
    cfg.region = "us-east-1"
    cfg.linear_parameter_name = "/deathstar/integrations/linear/api_key"
    cfg.linear_webhook_secret_parameter_name = "/deathstar/integrations/linear/webhook_secret"
    cfg.tailscale_hostname = "deathstar"
    cfg.web_ui_port = 8443
    cfg.remote_transport = "ssm"
    cfg.enable_tailscale_funnel = False
    return cfg


# ---------------------------------------------------------------------------
# deathstar linear setup — API key only (--skip-webhook)
# ---------------------------------------------------------------------------


class TestLinearSetup:
    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.resolve_secret_target")
    @patch("deathstar_cli.main.put_secret_value")
    @patch("deathstar_cli.main.prompt_for_secret", return_value="lin_api_key_123")
    def test_stores_api_key(
        self,
        mock_prompt: MagicMock,
        mock_put: MagicMock,
        mock_resolve: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_resolve.return_value = MagicMock(parameter_name="/deathstar/integrations/linear/api_key")
        mock_put.return_value = ("Created", 1)

        result = runner.invoke(app, ["linear", "setup", "--skip-webhook"])

        assert result.exit_code == 0
        assert "Created" in result.output
        assert "/deathstar/integrations/linear/api_key" in result.output
        assert "deathstar redeploy" in result.output
        mock_prompt.assert_called_once_with("Linear API key")
        mock_put.assert_called_once()
        # Verify the secret value passed to put_secret_value
        _, kwargs = mock_put.call_args
        if not kwargs:
            args = mock_put.call_args[0]
            assert args[3] == "lin_api_key_123"

    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.resolve_secret_target")
    @patch("deathstar_cli.main.put_secret_value")
    @patch("deathstar_cli.main.prompt_for_secret", return_value="lin_api_key_456")
    def test_region_override(
        self,
        mock_prompt: MagicMock,
        mock_put: MagicMock,
        mock_resolve: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_resolve.return_value = MagicMock(parameter_name="/deathstar/integrations/linear/api_key")
        mock_put.return_value = ("Created", 1)

        result = runner.invoke(app, ["linear", "setup", "--skip-webhook", "--region", "eu-west-1"])

        assert result.exit_code == 0
        # Verify put_secret_value was called with the overridden region
        args = mock_put.call_args[0]
        assert args[1] == "eu-west-1"

    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.resolve_secret_target")
    @patch("deathstar_cli.main.put_secret_value")
    @patch("deathstar_cli.main.prompt_for_secret", return_value="lin_api_key_789")
    def test_yes_flag_passes_force(
        self,
        mock_prompt: MagicMock,
        mock_put: MagicMock,
        mock_resolve: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_resolve.return_value = MagicMock(parameter_name="/deathstar/integrations/linear/api_key")
        mock_put.return_value = ("Updated", 2)

        result = runner.invoke(app, ["linear", "setup", "--skip-webhook", "--yes"])

        assert result.exit_code == 0
        assert "Updated" in result.output
        _, kwargs = mock_put.call_args
        assert kwargs.get("force") is True


# ---------------------------------------------------------------------------
# deathstar linear setup — with webhook registration
# ---------------------------------------------------------------------------


class TestLinearSetupWebhook:
    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.resolve_secret_target")
    @patch("deathstar_cli.main.put_secret_value")
    @patch("deathstar_cli.main.prompt_for_secret", return_value="lin_api_key_wh")
    @patch("deathstar_cli.main._linear_list_teams")
    @patch("deathstar_cli.main._linear_create_webhook")
    def test_registers_webhook_with_team_id(
        self,
        mock_create_wh: MagicMock,
        mock_list_teams: MagicMock,
        mock_prompt: MagicMock,
        mock_put: MagicMock,
        mock_resolve: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_resolve.return_value = MagicMock(parameter_name="/deathstar/integrations/linear/api_key")
        mock_put.return_value = ("Created", 1)
        mock_create_wh.return_value = {
            "success": True,
            "webhook": {"id": "wh_123", "url": "https://example.com/wh", "enabled": True},
        }

        result = runner.invoke(app, [
            "linear", "setup", "--yes",
            "--team-id", "team_abc",
            "--webhook-url", "https://example.com/web/api/webhooks/linear",
        ])

        assert result.exit_code == 0
        assert "Webhook created" in result.output
        assert "wh_123" in result.output
        # put_secret_value called twice: API key + webhook secret
        assert mock_put.call_count == 2
        # Second call stores the webhook secret
        second_call = mock_put.call_args_list[1]
        secret_target = second_call[0][2]
        assert secret_target.parameter_name == "/deathstar/integrations/linear/webhook_secret"
        # Should not call list_teams when --team-id is provided
        mock_list_teams.assert_not_called()

    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.resolve_secret_target")
    @patch("deathstar_cli.main.put_secret_value")
    @patch("deathstar_cli.main.prompt_for_secret", return_value="lin_api_key_wh2")
    @patch("deathstar_cli.main._linear_list_teams")
    @patch("deathstar_cli.main._linear_create_webhook")
    @patch("deathstar_cli.main.terraform_outputs")
    def test_auto_detects_webhook_url(
        self,
        mock_tf_outputs: MagicMock,
        mock_create_wh: MagicMock,
        mock_list_teams: MagicMock,
        mock_prompt: MagicMock,
        mock_put: MagicMock,
        mock_resolve: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_resolve.return_value = MagicMock(parameter_name="/deathstar/integrations/linear/api_key")
        mock_put.return_value = ("Created", 1)
        mock_list_teams.return_value = [{"id": "team_1", "name": "Eng", "key": "ENG"}]
        mock_tf_outputs.return_value = {"tailscale_hostname": "deathstar"}
        mock_create_wh.return_value = {
            "success": True,
            "webhook": {"id": "wh_456", "url": "auto", "enabled": True},
        }

        result = runner.invoke(app, [
            "linear", "setup", "--yes", "--team-id", "team_1",
        ])

        assert result.exit_code == 0
        assert "Auto-detected webhook URL" in result.output
        assert "Webhook created" in result.output
        # Verify the auto-detected URL was used
        create_args = mock_create_wh.call_args
        assert "/web/api/webhooks/linear" in create_args[1]["url"]

    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.resolve_secret_target")
    @patch("deathstar_cli.main.put_secret_value")
    @patch("deathstar_cli.main.prompt_for_secret", return_value="lin_api_key_wh3")
    @patch("deathstar_cli.main._linear_list_teams")
    def test_graceful_failure_on_team_list_error(
        self,
        mock_list_teams: MagicMock,
        mock_prompt: MagicMock,
        mock_put: MagicMock,
        mock_resolve: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_resolve.return_value = MagicMock(parameter_name="/deathstar/integrations/linear/api_key")
        mock_put.return_value = ("Created", 1)
        mock_list_teams.side_effect = RuntimeError("Unauthorized")

        result = runner.invoke(app, ["linear", "setup", "--yes"])

        assert result.exit_code == 0
        # API key should still be stored
        assert "Created" in result.output
        assert "could not list teams" in result.output
        # put_secret_value called only once (API key, no webhook secret)
        assert mock_put.call_count == 1

    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.resolve_secret_target")
    @patch("deathstar_cli.main.put_secret_value")
    @patch("deathstar_cli.main.prompt_for_secret", return_value="lin_api_key_wh4")
    @patch("deathstar_cli.main._linear_list_teams")
    @patch("deathstar_cli.main._linear_create_webhook")
    def test_graceful_failure_on_webhook_creation_error(
        self,
        mock_create_wh: MagicMock,
        mock_list_teams: MagicMock,
        mock_prompt: MagicMock,
        mock_put: MagicMock,
        mock_resolve: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_resolve.return_value = MagicMock(parameter_name="/deathstar/integrations/linear/api_key")
        mock_put.return_value = ("Created", 1)
        mock_list_teams.return_value = [{"id": "team_1", "name": "Eng", "key": "ENG"}]
        mock_create_wh.side_effect = RuntimeError("Rate limited")

        result = runner.invoke(app, [
            "linear", "setup", "--yes",
            "--team-id", "team_1",
            "--webhook-url", "https://example.com/wh",
        ])

        assert result.exit_code == 0
        assert "webhook registration failed" in result.output
        # API key stored + webhook secret stored before creation attempt
        assert mock_put.call_count == 2
        assert "signing secret is already stored" in result.output


# ---------------------------------------------------------------------------
# deathstar linear status
# ---------------------------------------------------------------------------


class TestLinearStatus:
    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.RemoteAPIClient")
    def test_shows_configured_status(
        self,
        mock_client_cls: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_client = MagicMock()
        mock_client._request.return_value = {
            "configured": True,
            "linked_projects": 3,
            "last_synced_at": "2026-04-13T12:00:00Z",
        }
        mock_client_cls.return_value = mock_client

        result = runner.invoke(app, ["linear", "status"])

        assert result.exit_code == 0
        assert "Configured:      yes" in result.output
        assert "Linked projects: 3" in result.output
        assert "2026-04-13T12:00:00Z" in result.output
        # Should NOT show setup prompt when configured
        assert "deathstar linear setup" not in result.output
        mock_client._request.assert_called_once_with("GET", "/web/api/linear/status")

    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.RemoteAPIClient")
    def test_shows_unconfigured_status(
        self,
        mock_client_cls: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_client = MagicMock()
        mock_client._request.return_value = {
            "configured": False,
            "linked_projects": 0,
            "last_synced_at": None,
        }
        mock_client_cls.return_value = mock_client

        result = runner.invoke(app, ["linear", "status"])

        assert result.exit_code == 0
        assert "Configured:      no" in result.output
        assert "Linked projects: 0" in result.output
        assert "deathstar linear setup" in result.output

    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.RemoteAPIClient")
    def test_404_shows_upgrade_message(
        self,
        mock_client_cls: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_client = MagicMock()

        # Build a real-looking HTTPStatusError for 404
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.status_code = 404
        mock_response.request = MagicMock()
        mock_client._request.side_effect = httpx.HTTPStatusError(
            "Not Found",
            request=mock_response.request,
            response=mock_response,
        )
        mock_client_cls.return_value = mock_client

        result = runner.invoke(app, ["linear", "status"])

        assert result.exit_code == 1
        assert "not available" in result.output
        assert "deathstar upgrade" in result.output

    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.RemoteAPIClient")
    def test_passes_region_and_transport(
        self,
        mock_client_cls: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        mock_config.return_value = _mock_config()
        mock_client = MagicMock()
        mock_client._request.return_value = {
            "configured": True,
            "linked_projects": 0,
            "last_synced_at": None,
        }
        mock_client_cls.return_value = mock_client

        result = runner.invoke(
            app,
            ["linear", "status", "--region", "ap-southeast-1", "--transport", "ssm"],
        )

        assert result.exit_code == 0
        # Verify RemoteAPIClient was constructed correctly
        mock_client_cls.assert_called_once_with(
            mock_config.return_value,
            "ap-southeast-1",
            transport="ssm",
        )

    @patch("deathstar_cli.main._config")
    @patch("deathstar_cli.main.RemoteAPIClient")
    def test_uses_default_region_when_not_specified(
        self,
        mock_client_cls: MagicMock,
        mock_config: MagicMock,
    ) -> None:
        cfg = _mock_config()
        cfg.region = "us-west-2"
        mock_config.return_value = cfg
        mock_client = MagicMock()
        mock_client._request.return_value = {
            "configured": False,
            "linked_projects": 0,
            "last_synced_at": None,
        }
        mock_client_cls.return_value = mock_client

        result = runner.invoke(app, ["linear", "status"])

        assert result.exit_code == 0
        mock_client_cls.assert_called_once_with(cfg, "us-west-2", transport=None)
