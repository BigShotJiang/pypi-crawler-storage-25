from __future__ import annotations

import pytest

from deathstar_server.web.linear_store import (
    LinearStore,
    SyncResult,
    derive_branch_name,
    _slugify,
)


@pytest.fixture
def store(db_engine) -> LinearStore:
    return LinearStore(db_engine)


# ------------------------------------------------------------------
# Helper function tests
# ------------------------------------------------------------------


class TestSlugify:
    def test_simple_text(self) -> None:
        assert _slugify("Add user auth") == "add-user-auth"

    def test_special_characters(self) -> None:
        assert _slugify("Fix bug #42 (urgent!)") == "fix-bug-42-urgent"

    def test_multiple_spaces_and_underscores(self) -> None:
        assert _slugify("refactor__the   api") == "refactor-the-api"

    def test_empty_string(self) -> None:
        assert _slugify("") == ""

    def test_only_special_characters(self) -> None:
        assert _slugify("!!!@@@") == ""

    def test_truncates_at_60(self) -> None:
        long_title = "a" * 100
        assert len(_slugify(long_title)) == 60

    def test_leading_trailing_hyphens_stripped(self) -> None:
        assert _slugify("--hello--") == "hello"


class TestDeriveBranchName:
    def test_standard_case(self) -> None:
        assert derive_branch_name("ENG-123", "Add user auth") == "eng-123/add-user-auth"

    def test_empty_title(self) -> None:
        assert derive_branch_name("ENG-99", "") == "eng-99"

    def test_special_title(self) -> None:
        result = derive_branch_name("PROJ-1", "Fix: login page (v2)")
        assert result == "proj-1/fix-login-page-v2"


# ------------------------------------------------------------------
# link_project tests
# ------------------------------------------------------------------


class TestLinkProject:
    def test_creates_project(self, store: LinearStore) -> None:
        project = store.link_project(
            repo="my-repo",
            linear_project_id="proj-abc",
            conversation_id=None,
            team_id="team-1",
            project_data={
                "name": "Sprint 1",
                "slugId": "sprint-1",
                "status": {"id": "s1", "name": "Started", "type": "started"},
                "url": "https://linear.app/p/1",
            },
        )
        assert project.repo == "my-repo"
        assert project.linear_project_id == "proj-abc"
        assert project.name == "Sprint 1"
        assert project.state == "started"
        assert project.id  # UUID generated

    def test_idempotent_update(self, store: LinearStore) -> None:
        store.link_project(
            repo="my-repo",
            linear_project_id="proj-abc",
            conversation_id=None,
            team_id="team-1",
            project_data={"name": "Sprint 1"},
        )
        updated = store.link_project(
            repo="my-repo",
            linear_project_id="proj-abc",
            conversation_id=None,
            team_id="team-1",
            project_data={"name": "Sprint 1 (updated)"},
        )
        assert updated.name == "Sprint 1 (updated)"

        # Should still be just one project
        projects = store.list_projects_for_repo("my-repo")
        assert len(projects) == 1

    def test_extracts_state_from_status_object_on_update(self, store: LinearStore) -> None:
        store.link_project(
            repo="r",
            linear_project_id="proj-1",
            conversation_id=None,
            team_id="t",
            project_data={"name": "P", "status": {"type": "planned"}},
        )
        updated = store.link_project(
            repo="r",
            linear_project_id="proj-1",
            conversation_id=None,
            team_id="t",
            project_data={"name": "P", "status": {"id": "s2", "name": "Started", "type": "started"}},
        )
        assert updated.state == "started"

    def test_defaults_state_when_no_status(self, store: LinearStore) -> None:
        project = store.link_project(
            repo="r",
            linear_project_id="proj-2",
            conversation_id=None,
            team_id="t",
            project_data={"name": "No Status"},
        )
        assert project.state == "planned"

    def test_integrity_error_fallback(self, db_engine) -> None:
        """Concurrent inserts with the same linear_project_id should not crash."""
        store_a = LinearStore(db_engine)
        store_b = LinearStore(db_engine)

        proj_a = store_a.link_project(
            repo="repo", linear_project_id="same-id",
            conversation_id=None, team_id="t1",
            project_data={"name": "A"},
        )
        # Second insert for the same linear_project_id goes through the
        # update path since we share the same DB.
        proj_b = store_b.link_project(
            repo="repo", linear_project_id="same-id",
            conversation_id=None, team_id="t1",
            project_data={"name": "B"},
        )
        assert proj_a.linear_project_id == proj_b.linear_project_id
        # The second call updates the name
        assert proj_b.name == "B"


class TestGetProject:
    def test_found(self, store: LinearStore) -> None:
        store.link_project(
            repo="r", linear_project_id="p1",
            conversation_id=None, team_id="t1",
            project_data={"name": "P"},
        )
        result = store.get_project_by_linear_id("p1")
        assert result is not None
        assert result.name == "P"

    def test_not_found(self, store: LinearStore) -> None:
        assert store.get_project_by_linear_id("nonexistent") is None


class TestListProjects:
    def test_filters_by_repo(self, store: LinearStore) -> None:
        store.link_project(repo="a", linear_project_id="p1", conversation_id=None, team_id="t", project_data={"name": "A"})
        store.link_project(repo="b", linear_project_id="p2", conversation_id=None, team_id="t", project_data={"name": "B"})
        results = store.list_projects_for_repo("a")
        assert len(results) == 1
        assert results[0].repo == "a"

    def test_list_all_projects(self, store: LinearStore) -> None:
        store.link_project(repo="a", linear_project_id="p1", conversation_id=None, team_id="t", project_data={"name": "A"})
        store.link_project(repo="b", linear_project_id="p2", conversation_id=None, team_id="t", project_data={"name": "B"})
        results = store.list_all_projects()
        assert len(results) == 2

    def test_list_all_projects_empty(self, store: LinearStore) -> None:
        assert store.list_all_projects() == []


# ------------------------------------------------------------------
# sync_issues tests
# ------------------------------------------------------------------


class TestSyncIssues:
    def _link_project(self, store: LinearStore) -> str:
        project = store.link_project(
            repo="my-repo", linear_project_id="lp-1",
            conversation_id=None, team_id="t1",
            project_data={"name": "Test"},
        )
        return project.id

    def test_creates_issues(self, store: LinearStore) -> None:
        pid = self._link_project(store)
        result = store.sync_issues(pid, [
            {
                "id": "issue-1", "identifier": "ENG-1", "title": "First",
                "state": {"name": "Todo", "type": "unstarted"},
                "priority": 2, "url": "https://linear.app/1",
            },
            {
                "id": "issue-2", "identifier": "ENG-2", "title": "Second",
                "state": {"name": "Backlog"},
                "priority": 4, "url": "https://linear.app/2",
            },
        ])
        assert result.created == 2
        assert result.updated == 0
        assert result.deleted_ids == ()

        issues = store.list_issues_for_project(pid)
        assert len(issues) == 2

    def test_updates_changed_issues(self, store: LinearStore) -> None:
        pid = self._link_project(store)
        store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "Original", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])

        result = store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "Updated title", "state": {"name": "In Progress"}, "priority": 1, "url": ""},
        ])
        assert result.created == 0
        assert result.updated == 1

        issue = store.get_issue_by_linear_id("i1")
        assert issue is not None
        assert issue.title == "Updated title"
        assert issue.status == "In Progress"
        assert issue.priority == 1

    def test_no_op_when_unchanged(self, store: LinearStore) -> None:
        pid = self._link_project(store)
        data = [{"id": "i1", "identifier": "ENG-1", "title": "Same", "state": {"name": "Todo"}, "priority": 0, "url": ""}]
        store.sync_issues(pid, data)
        result = store.sync_issues(pid, data)
        assert result.created == 0
        assert result.updated == 0

    def test_deletes_removed_issues(self, store: LinearStore) -> None:
        pid = self._link_project(store)
        store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "Keep", "state": {"name": "Todo"}, "priority": 0, "url": ""},
            {"id": "i2", "identifier": "ENG-2", "title": "Remove", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])

        result = store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "Keep", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])
        assert len(result.deleted_ids) == 1
        # deleted_ids should contain the Linear issue ID, not the internal UUID
        assert result.deleted_ids[0] == "i2"
        assert store.get_issue_by_linear_id("i2") is None

    def test_derives_branch_name(self, store: LinearStore) -> None:
        pid = self._link_project(store)
        store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-42", "title": "Add user auth", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])
        issue = store.get_issue_by_linear_id("i1")
        assert issue is not None
        assert issue.branch == "eng-42/add-user-auth"

    def test_uses_remote_branch_name(self, store: LinearStore) -> None:
        pid = self._link_project(store)
        store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "Stuff", "branchName": "custom/branch", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])
        issue = store.get_issue_by_linear_id("i1")
        assert issue is not None
        assert issue.branch == "custom/branch"

    def test_extracts_assignee(self, store: LinearStore) -> None:
        pid = self._link_project(store)
        store.sync_issues(pid, [
            {
                "id": "i1", "identifier": "ENG-1", "title": "Task",
                "state": {"name": "Todo"}, "priority": 0, "url": "",
                "assignee": {"displayName": "Alice", "name": "alice"},
            },
        ])
        issue = store.get_issue_by_linear_id("i1")
        assert issue is not None
        assert issue.assignee == "Alice"

    def test_missing_project_returns_empty(self, store: LinearStore) -> None:
        result = store.sync_issues("nonexistent-id", [])
        assert result.created == 0
        assert result.deleted_ids == ()

    def test_skips_issues_without_id(self, store: LinearStore) -> None:
        pid = self._link_project(store)
        result = store.sync_issues(pid, [
            {"identifier": "ENG-1", "title": "No ID"},
        ])
        assert result.created == 0

    def test_empty_remote_list_deletes_all(self, store: LinearStore) -> None:
        """Syncing with empty remote list should delete all existing issues."""
        pid = self._link_project(store)
        store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "A", "state": {"name": "Todo"}, "priority": 0, "url": ""},
            {"id": "i2", "identifier": "ENG-2", "title": "B", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])

        result = store.sync_issues(pid, [])
        assert result.deleted_ids == ("i1", "i2") or set(result.deleted_ids) == {"i1", "i2"}
        assert result.created == 0
        assert result.updated == 0
        assert store.list_issues_for_project(pid) == []

    def test_duplicate_ids_in_same_batch(self, store: LinearStore) -> None:
        """If the remote API returns duplicate issue IDs, last one wins."""
        pid = self._link_project(store)
        result = store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "First", "state": {"name": "Todo"}, "priority": 0, "url": ""},
            {"id": "i1", "identifier": "ENG-1", "title": "Second", "state": {"name": "Done"}, "priority": 1, "url": ""},
        ])
        # Only one issue should be created (the duplicate is pre-deduped)
        assert result.created == 1
        issues = store.list_issues_for_project(pid)
        assert len(issues) == 1
        # Last occurrence wins
        assert issues[0].title == "Second"
        assert issues[0].status == "Done"

    def test_sync_updates_project_last_synced_at(self, store: LinearStore) -> None:
        """sync_issues should update the project's last_synced_at."""
        pid = self._link_project(store)
        project_before = store.get_project_by_linear_id("lp-1")
        assert project_before is not None
        initial_synced = project_before.last_synced_at

        store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "A", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])

        project_after = store.get_project_by_linear_id("lp-1")
        assert project_after is not None
        assert project_after.last_synced_at >= initial_synced


# ------------------------------------------------------------------
# Issue lookup tests
# ------------------------------------------------------------------


class TestGetIssueByBranch:
    def test_found(self, store: LinearStore) -> None:
        project = store.link_project(
            repo="my-repo", linear_project_id="lp-1",
            conversation_id=None, team_id="t1",
            project_data={"name": "P"},
        )
        store.sync_issues(project.id, [
            {"id": "i1", "identifier": "ENG-1", "title": "Auth", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])
        result = store.get_issue_by_branch("my-repo", "eng-1/auth")
        assert result is not None
        assert result.linear_issue_id == "i1"

    def test_not_found(self, store: LinearStore) -> None:
        assert store.get_issue_by_branch("repo", "no-such-branch") is None


class TestUpdateIssueStatus:
    def test_updates_existing(self, store: LinearStore) -> None:
        project = store.link_project(
            repo="r", linear_project_id="p1",
            conversation_id=None, team_id="t",
            project_data={"name": "P"},
        )
        store.sync_issues(project.id, [
            {"id": "i1", "identifier": "ENG-1", "title": "T", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])
        assert store.update_issue_status("i1", "Done") is True
        issue = store.get_issue_by_linear_id("i1")
        assert issue is not None
        assert issue.status == "Done"

    def test_not_found_returns_false(self, store: LinearStore) -> None:
        assert store.update_issue_status("nonexistent", "Done") is False


class TestListIssuesPriorityOrder:
    """Verify Urgent (1) sorts before No Priority (0)."""

    def test_urgent_before_no_priority(self, store: LinearStore) -> None:
        project = store.link_project(
            repo="r", linear_project_id="p1",
            conversation_id=None, team_id="t",
            project_data={"name": "P"},
        )
        store.sync_issues(project.id, [
            {"id": "i-none", "identifier": "ENG-1", "title": "None", "state": {"name": "Backlog"}, "priority": 0, "url": ""},
            {"id": "i-urgent", "identifier": "ENG-2", "title": "Urgent", "state": {"name": "Todo"}, "priority": 1, "url": ""},
            {"id": "i-high", "identifier": "ENG-3", "title": "High", "state": {"name": "Todo"}, "priority": 2, "url": ""},
            {"id": "i-low", "identifier": "ENG-4", "title": "Low", "state": {"name": "Backlog"}, "priority": 4, "url": ""},
        ])
        issues = store.list_issues_for_project(project.id)
        priorities = [i.priority for i in issues]
        # Expected: Urgent(1), High(2), Low(4), None(0)
        assert priorities == [1, 2, 4, 0]


class TestUpsertIssue:
    def test_creates_new_issue(self, store: LinearStore) -> None:
        project = store.link_project(
            repo="my-repo",
            linear_project_id="lp-1",
            conversation_id=None,
            team_id="t-1",
            project_data={"name": "Test"},
        )
        issue = store.upsert_issue(
            linear_project_id=project.id,
            repo="my-repo",
            linear_issue_id="li-1",
            identifier="ENG-1",
            title="First issue",
            status="Todo",
            priority=2,
            branch="eng-1/first-issue",
            url="https://linear.app/issue/1",
        )
        assert issue.linear_issue_id == "li-1"
        assert issue.branch == "eng-1/first-issue"
        assert issue.status == "Todo"

        # Queryable by branch immediately
        found = store.get_issue_by_branch("my-repo", "eng-1/first-issue")
        assert found is not None
        assert found.linear_issue_id == "li-1"

    def test_updates_existing_issue(self, store: LinearStore) -> None:
        project = store.link_project(
            repo="my-repo",
            linear_project_id="lp-1",
            conversation_id=None,
            team_id="t-1",
            project_data={"name": "Test"},
        )
        store.upsert_issue(
            linear_project_id=project.id,
            repo="my-repo",
            linear_issue_id="li-1",
            identifier="ENG-1",
            title="First issue",
            status="Todo",
        )
        updated = store.upsert_issue(
            linear_project_id=project.id,
            repo="my-repo",
            linear_issue_id="li-1",
            identifier="ENG-1",
            title="Updated title",
            status="In Progress",
            branch="eng-1/updated",
        )
        assert updated.title == "Updated title"
        assert updated.status == "In Progress"
        assert updated.branch == "eng-1/updated"

    def test_idempotent_on_linear_issue_id(self, store: LinearStore) -> None:
        project = store.link_project(
            repo="my-repo",
            linear_project_id="lp-1",
            conversation_id=None,
            team_id="t-1",
            project_data={"name": "Test"},
        )
        i1 = store.upsert_issue(
            linear_project_id=project.id,
            repo="my-repo",
            linear_issue_id="li-1",
            identifier="ENG-1",
            title="Same issue",
            status="Todo",
        )
        i2 = store.upsert_issue(
            linear_project_id=project.id,
            repo="my-repo",
            linear_issue_id="li-1",
            identifier="ENG-1",
            title="Same issue",
            status="Todo",
        )
        assert i1.id == i2.id


class TestSyncResultImmutability:
    def test_deleted_ids_is_tuple(self) -> None:
        result = SyncResult(created=1, updated=0, deleted_ids=("a", "b"))
        assert isinstance(result.deleted_ids, tuple)
        with pytest.raises(AttributeError):
            result.created = 99  # type: ignore[misc]
