from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from deathstar_server.errors import AppError
from deathstar_server.services.event_bus import (
    EVENT_AGENT_COMPLETED,
    EVENT_AGENT_STARTED,
    EVENT_LINEAR_ISSUE_CREATED,
    EVENT_LINEAR_ISSUE_DELETED,
    EVENT_LINEAR_ISSUE_UPDATED,
    EVENT_PR_UPDATE,
    EventBus,
    RepoEvent,
    SOURCE_AGENT,
    SOURCE_GITHUB,
    SOURCE_LINEAR,
)
from deathstar_server.services.linear import LinearService
from deathstar_server.services.linear_sync import (
    LinearSyncOrchestrator,
    _CachedState,
    _WorkflowStateCache,
)
from deathstar_server.web.conversations import ConversationStore
from deathstar_server.web.linear_store import LinearStore
from deathstar_shared.models import ErrorCode


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------


@pytest.fixture
def settings() -> MagicMock:
    s = MagicMock()
    s.linear_api_key = "lin_test_key"
    s.projects_root = Path("/tmp/fake-projects")
    return s


@pytest.fixture
def settings_no_key() -> MagicMock:
    s = MagicMock()
    s.linear_api_key = None
    s.projects_root = Path("/tmp/fake-projects")
    return s


@pytest.fixture
def linear_store(db_engine) -> LinearStore:
    return LinearStore(db_engine)


@pytest.fixture
def conversation_store(db_engine) -> ConversationStore:
    return ConversationStore(db_engine)


@pytest.fixture
def linear_service() -> MagicMock:
    svc = MagicMock(spec=LinearService)
    svc.list_workflow_states = AsyncMock(return_value=[
        {"id": "state-backlog", "name": "Backlog", "type": "backlog", "position": 0},
        {"id": "state-todo", "name": "Todo", "type": "unstarted", "position": 1},
        {"id": "state-inprogress", "name": "In Progress", "type": "started", "position": 2},
        {"id": "state-done", "name": "Done", "type": "completed", "position": 3},
        {"id": "state-cancelled", "name": "Cancelled", "type": "cancelled", "position": 4},
    ])
    svc.update_issue_state = AsyncMock(return_value={"success": True})
    return svc


@pytest.fixture
def git_service() -> MagicMock:
    return MagicMock()


@pytest.fixture
def event_bus() -> EventBus:
    return EventBus()


@pytest.fixture
def orchestrator(
    settings, linear_service, linear_store, conversation_store, git_service, event_bus,
) -> LinearSyncOrchestrator:
    return LinearSyncOrchestrator(
        settings, linear_service, linear_store, conversation_store, git_service, event_bus,
    )


def _link_project_with_issues(linear_store: LinearStore, repo: str = "my-repo") -> str:
    """Helper: link a project and sync issues into the store.

    Returns the internal project PK.
    """
    project = linear_store.link_project(
        repo=repo,
        linear_project_id="proj-1",
        conversation_id=None,
        team_id="team-1",
        project_data={"name": "Sprint 1", "status": {"type": "started"}},
    )
    linear_store.sync_issues(project.id, [
        {
            "id": "li-1", "identifier": "ENG-1", "title": "Add login",
            "state": {"name": "Todo"}, "priority": 1, "url": "",
        },
        {
            "id": "li-2", "identifier": "ENG-2", "title": "Fix bug",
            "state": {"name": "Backlog"}, "priority": 2, "url": "",
        },
    ])
    return project.id


# ------------------------------------------------------------------
# Workflow state cache
# ------------------------------------------------------------------


class TestWorkflowStateCache:
    def test_put_and_get(self) -> None:
        cache = _WorkflowStateCache()
        cache.put("team-1", [
            {"id": "s1", "name": "Todo", "type": "unstarted", "position": 0},
            {"id": "s2", "name": "In Progress", "type": "started", "position": 1},
            {"id": "s3", "name": "Done", "type": "completed", "position": 2},
        ])
        started = cache.get("team-1", "started")
        assert started is not None
        assert started.id == "s2"
        assert started.name == "In Progress"
        completed = cache.get("team-1", "completed")
        assert completed is not None
        assert completed.id == "s3"
        assert completed.name == "Done"
        assert cache.get("team-1", "nonexistent") is None

    def test_cache_miss(self) -> None:
        cache = _WorkflowStateCache()
        assert cache.get("unknown-team", "started") is None

    def test_is_cached(self) -> None:
        cache = _WorkflowStateCache()
        assert cache.is_cached("team-1") is False
        cache.put("team-1", [{"id": "s1", "name": "X", "type": "started", "position": 0}])
        assert cache.is_cached("team-1") is True

    def test_expiry(self) -> None:
        cache = _WorkflowStateCache()
        cache.put("team-1", [{"id": "s1", "name": "X", "type": "started", "position": 0}])
        # Force expiry
        cache._fetched_at["team-1"] = 0
        assert cache.get("team-1", "started") is None
        assert cache.is_cached("team-1") is False

    def test_is_cached_cleans_up_expired(self) -> None:
        """is_cached() evicts expired entries, consistent with get()."""
        cache = _WorkflowStateCache()
        cache.put("team-1", [{"id": "s1", "name": "X", "type": "started", "position": 0}])
        cache._fetched_at["team-1"] = 0  # Force expiry
        assert cache.is_cached("team-1") is False
        # Entry should be evicted from internal dicts
        assert "team-1" not in cache._cache
        assert "team-1" not in cache._fetched_at

    def test_first_state_per_type_wins(self) -> None:
        """When multiple states have the same type, the first one wins."""
        cache = _WorkflowStateCache()
        cache.put("team-1", [
            {"id": "s1", "name": "In Progress", "type": "started", "position": 0},
            {"id": "s2", "name": "In Review", "type": "started", "position": 1},
        ])
        started = cache.get("team-1", "started")
        assert started is not None
        assert started.id == "s1"
        assert started.name == "In Progress"

    def test_stores_display_name(self) -> None:
        """Cache entries preserve the human-readable display name."""
        cache = _WorkflowStateCache()
        cache.put("team-1", [
            {"id": "s1", "name": "In Progress", "type": "started", "position": 0},
            {"id": "s2", "name": "Done", "type": "completed", "position": 1},
        ])
        assert cache.get("team-1", "started") == _CachedState(id="s1", name="In Progress")
        assert cache.get("team-1", "completed") == _CachedState(id="s2", name="Done")

    def test_missing_name_falls_back_to_type(self) -> None:
        """States without a name field fall back to the type string."""
        cache = _WorkflowStateCache()
        cache.put("team-1", [
            {"id": "s1", "type": "started", "position": 0},
        ])
        cached = cache.get("team-1", "started")
        assert cached is not None
        assert cached.name == "started"

    def test_missing_id_skipped(self) -> None:
        """States without an id field are silently skipped."""
        cache = _WorkflowStateCache()
        cache.put("team-1", [
            {"type": "started", "name": "In Progress", "position": 0},
            {"id": "", "type": "completed", "name": "Done", "position": 1},
            {"id": "s3", "type": "cancelled", "name": "Cancelled", "position": 2},
        ])
        assert cache.get("team-1", "started") is None
        assert cache.get("team-1", "completed") is None
        cached = cache.get("team-1", "cancelled")
        assert cached is not None
        assert cached.id == "s3"


# ------------------------------------------------------------------
# Lifecycle
# ------------------------------------------------------------------


class TestOrchestratorLifecycle:
    @pytest.mark.asyncio
    async def test_disabled_without_api_key(
        self, settings_no_key, linear_service, linear_store, conversation_store,
        git_service, event_bus,
    ) -> None:
        orch = LinearSyncOrchestrator(
            settings_no_key, linear_service, linear_store,
            conversation_store, git_service, event_bus,
        )
        await orch.start()
        assert orch._running is False
        assert orch._task is None

    @pytest.mark.asyncio
    async def test_start_and_stop(self, orchestrator) -> None:
        await orchestrator.start()
        assert orchestrator._running is True
        assert orchestrator._task is not None
        await orchestrator.stop()
        assert orchestrator._running is False
        assert orchestrator._task is None

    @pytest.mark.asyncio
    async def test_start_idempotent(self, orchestrator) -> None:
        await orchestrator.start()
        task1 = orchestrator._task
        await orchestrator.start()
        assert orchestrator._task is task1
        await orchestrator.stop()

    @pytest.mark.asyncio
    async def test_listener_restarts_on_unexpected_error(
        self, settings, linear_service, linear_store, conversation_store,
        git_service,
    ) -> None:
        """The listener loop restarts after an unexpected exception.

        Simulates the subscription context manager raising a non-operational
        exception.  The loop should log it and re-subscribe rather than
        dying silently.
        """
        import asyncio

        bus = EventBus()
        orch = LinearSyncOrchestrator(
            settings, linear_service, linear_store,
            conversation_store, git_service, bus,
        )

        call_count = 0
        original_subscribe = bus.subscribe

        def flaky_subscribe():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("simulated subscription failure")
            return original_subscribe()

        bus.subscribe = flaky_subscribe
        orch._running = True

        # Run the loop briefly — it should survive the first RuntimeError,
        # sleep 5s (we'll cancel before that completes), and attempt to
        # re-subscribe.
        task = asyncio.create_task(orch._listen_loop())
        # Give enough time for the first iteration to fail and log
        await asyncio.sleep(0.1)
        orch._running = False
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        # The flaky subscribe was called at least once (the failure path)
        assert call_count >= 1


# ------------------------------------------------------------------
# Inbound: linear_issue_created
# ------------------------------------------------------------------


class TestOnLinearIssueCreated:
    @pytest.mark.asyncio
    async def test_poller_events_are_skipped(self, orchestrator) -> None:
        """Poller summary events don't trigger branch creation."""
        event = RepoEvent(
            event_type=EVENT_LINEAR_ISSUE_CREATED,
            repo="my-repo",
            source=SOURCE_LINEAR,
            data={"count": 3, "source": "poller"},
        )
        await orchestrator._dispatch(event)
        orchestrator._git_service.ensure_branch.assert_not_called()

    @pytest.mark.asyncio
    async def test_creates_branch_from_webhook(
        self, orchestrator, linear_store,
    ) -> None:
        """Webhook events create branches and link to conversations."""
        _link_project_with_issues(linear_store)

        orchestrator._settings.projects_root = Path("/tmp/fake")
        with patch("pathlib.Path.is_dir", return_value=True):
            event = RepoEvent(
                event_type=EVENT_LINEAR_ISSUE_CREATED,
                repo="my-repo",
                source=SOURCE_LINEAR,
                data={
                    "linear_issue_id": "li-new",
                    "identifier": "ENG-3",
                    "title": "New feature",
                    "branch": "eng-3/new-feature",
                    "conversation_id": "conv-1",
                    "project_id": "proj-1",
                },
            )
            await orchestrator._dispatch(event)

        orchestrator._git_service.ensure_branch.assert_called_once()

    @pytest.mark.asyncio
    async def test_webhook_persists_issue_to_db(
        self, orchestrator, linear_store,
    ) -> None:
        """Webhook-created issues are upserted so outbound handlers can find them."""
        _link_project_with_issues(linear_store)

        orchestrator._settings.projects_root = Path("/tmp/fake")
        with patch("pathlib.Path.is_dir", return_value=True):
            event = RepoEvent(
                event_type=EVENT_LINEAR_ISSUE_CREATED,
                repo="my-repo",
                source=SOURCE_LINEAR,
                data={
                    "linear_issue_id": "li-new",
                    "identifier": "ENG-50",
                    "title": "Webhook issue",
                    "status": "Todo",
                    "priority": 2,
                    "branch": "eng-50/webhook-issue",
                    "project_id": "proj-1",
                    "url": "https://linear.app/issue/new",
                },
            )
            await orchestrator._dispatch(event)

        # The issue should be queryable by branch immediately
        issue = linear_store.get_issue_by_branch("my-repo", "eng-50/webhook-issue")
        assert issue is not None
        assert issue.linear_issue_id == "li-new"
        assert issue.identifier == "ENG-50"
        assert issue.status == "Todo"

    @pytest.mark.asyncio
    async def test_webhook_issue_without_project_id_still_creates_branch(
        self, orchestrator, linear_store,
    ) -> None:
        """Events missing project_id skip DB upsert but still create the branch."""
        _link_project_with_issues(linear_store)

        orchestrator._settings.projects_root = Path("/tmp/fake")
        with patch("pathlib.Path.is_dir", return_value=True):
            event = RepoEvent(
                event_type=EVENT_LINEAR_ISSUE_CREATED,
                repo="my-repo",
                source=SOURCE_LINEAR,
                data={
                    "linear_issue_id": "li-no-proj",
                    "identifier": "ENG-60",
                    "title": "No project",
                    "branch": "eng-60/no-project",
                    # No project_id
                },
            )
            await orchestrator._dispatch(event)

        # Branch should still be created
        orchestrator._git_service.ensure_branch.assert_called_once()
        # But no DB row since we couldn't resolve the project
        issue = linear_store.get_issue_by_branch("my-repo", "eng-60/no-project")
        assert issue is None

    @pytest.mark.asyncio
    async def test_derives_branch_from_identifier_when_missing(
        self, orchestrator, linear_store,
    ) -> None:
        """When branch is not in event data, derive from identifier/title."""
        _link_project_with_issues(linear_store)

        orchestrator._settings.projects_root = Path("/tmp/fake")
        with patch("pathlib.Path.is_dir", return_value=True):
            event = RepoEvent(
                event_type=EVENT_LINEAR_ISSUE_CREATED,
                repo="my-repo",
                source=SOURCE_LINEAR,
                data={
                    "linear_issue_id": "li-new",
                    "identifier": "ENG-99",
                    "title": "Some task",
                    # No "branch" key — orchestrator should derive it
                },
            )
            await orchestrator._dispatch(event)

        # Should have derived "eng-99/some-task" and called ensure_branch
        call_args = orchestrator._git_service.ensure_branch.call_args
        assert call_args is not None
        branch_arg = call_args[0][1]
        assert branch_arg == "eng-99/some-task"

    @pytest.mark.asyncio
    async def test_no_branch_and_no_identifier_skips(self, orchestrator) -> None:
        """Events without branch or identifier are skipped."""
        event = RepoEvent(
            event_type=EVENT_LINEAR_ISSUE_CREATED,
            repo="my-repo",
            source=SOURCE_LINEAR,
            data={"linear_issue_id": "li-1", "branch": ""},
        )
        await orchestrator._dispatch(event)
        orchestrator._git_service.ensure_branch.assert_not_called()

    @pytest.mark.asyncio
    async def test_branch_exists_logged_not_fatal(
        self, orchestrator, linear_store,
    ) -> None:
        """If git branch already exists (AppError), log and continue."""
        _link_project_with_issues(linear_store)

        orchestrator._settings.projects_root = Path("/tmp/fake")
        orchestrator._git_service.ensure_branch.side_effect = AppError(
            ErrorCode.INVALID_REQUEST, "branch already exists",
        )
        with patch("pathlib.Path.is_dir", return_value=True):
            event = RepoEvent(
                event_type=EVENT_LINEAR_ISSUE_CREATED,
                repo="my-repo",
                source=SOURCE_LINEAR,
                data={
                    "linear_issue_id": "li-new",
                    "identifier": "ENG-3",
                    "title": "New",
                    "branch": "eng-3/new",
                },
            )
            # Should not raise
            await orchestrator._dispatch(event)


# ------------------------------------------------------------------
# Inbound: linear_issue_updated
# ------------------------------------------------------------------


class TestOnLinearIssueUpdated:
    @pytest.mark.asyncio
    async def test_updates_status_from_webhook(
        self, orchestrator, linear_store,
    ) -> None:
        _link_project_with_issues(linear_store)

        event = RepoEvent(
            event_type=EVENT_LINEAR_ISSUE_UPDATED,
            repo="my-repo",
            source=SOURCE_LINEAR,
            data={
                "linear_issue_id": "li-1",
                "status": "In Progress",
            },
        )
        await orchestrator._dispatch(event)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None
        assert issue.status == "In Progress"

    @pytest.mark.asyncio
    async def test_poller_events_are_skipped(self, orchestrator) -> None:
        """Poller summary events are already synced via sync_issues()."""
        event = RepoEvent(
            event_type=EVENT_LINEAR_ISSUE_UPDATED,
            repo="my-repo",
            source=SOURCE_LINEAR,
            data={"count": 1, "source": "poller"},
        )
        # Should not raise or call update_issue_status
        await orchestrator._dispatch(event)

    @pytest.mark.asyncio
    async def test_missing_status_skips(self, orchestrator, linear_store) -> None:
        """Events with empty status don't update the DB."""
        _link_project_with_issues(linear_store)
        event = RepoEvent(
            event_type=EVENT_LINEAR_ISSUE_UPDATED,
            repo="my-repo",
            source=SOURCE_LINEAR,
            data={"linear_issue_id": "li-1", "status": ""},
        )
        await orchestrator._dispatch(event)
        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None
        assert issue.status == "Todo"  # Unchanged


# ------------------------------------------------------------------
# Inbound: linear_issue_deleted
# ------------------------------------------------------------------


class TestOnLinearIssueDeleted:
    @pytest.mark.asyncio
    async def test_marks_cancelled(
        self, orchestrator, linear_store,
    ) -> None:
        _link_project_with_issues(linear_store)

        event = RepoEvent(
            event_type=EVENT_LINEAR_ISSUE_DELETED,
            repo="my-repo",
            source=SOURCE_LINEAR,
            data={"linear_issue_id": "li-1"},
        )
        await orchestrator._dispatch(event)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None
        assert issue.status == "Cancelled"

    @pytest.mark.asyncio
    async def test_missing_issue_no_error(self, orchestrator) -> None:
        """Deleting an unknown issue doesn't raise."""
        event = RepoEvent(
            event_type=EVENT_LINEAR_ISSUE_DELETED,
            repo="my-repo",
            source=SOURCE_LINEAR,
            data={"linear_issue_id": "nonexistent"},
        )
        await orchestrator._dispatch(event)  # No exception

    @pytest.mark.asyncio
    async def test_poller_deleted_events_are_no_op(
        self, orchestrator, linear_store,
    ) -> None:
        """Poller deletes the row in sync_issues() before publishing.

        The handler tries update_issue_status on a gone row — should
        be harmless (returns False).
        """
        project = linear_store.link_project(
            repo="my-repo",
            linear_project_id="proj-1",
            conversation_id=None,
            team_id="team-1",
            project_data={"name": "P", "status": {"type": "started"}},
        )
        # Sync one issue, then sync with empty list to simulate deletion
        linear_store.sync_issues(project.id, [
            {"id": "li-del", "identifier": "ENG-X", "title": "Gone", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])
        linear_store.sync_issues(project.id, [])  # Deletes li-del

        # Now the poller event fires — row is already gone
        event = RepoEvent(
            event_type=EVENT_LINEAR_ISSUE_DELETED,
            repo="my-repo",
            source=SOURCE_LINEAR,
            data={"linear_issue_id": "li-del", "source": "poller"},
        )
        await orchestrator._dispatch(event)  # No exception


# ------------------------------------------------------------------
# Outbound: agent_completed
# ------------------------------------------------------------------


class TestOnAgentCompleted:
    @pytest.mark.asyncio
    async def test_transitions_to_started(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        _link_project_with_issues(linear_store)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        event = RepoEvent(
            event_type=EVENT_AGENT_COMPLETED,
            repo="my-repo",
            source=SOURCE_AGENT,
            data={
                "conversation_id": "conv-1",
                "branch": issue.branch,
                "status": "completed",
            },
        )
        await orchestrator._dispatch(event)

        linear_service.list_workflow_states.assert_called_once_with("team-1")
        linear_service.update_issue_state.assert_called_once_with(
            "li-1", "state-inprogress",
        )

    @pytest.mark.asyncio
    async def test_failed_agent_skipped(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """Failed agent completions don't trigger transitions."""
        _link_project_with_issues(linear_store)

        event = RepoEvent(
            event_type=EVENT_AGENT_COMPLETED,
            repo="my-repo",
            source=SOURCE_AGENT,
            data={
                "conversation_id": "conv-1",
                "branch": "eng-1/add-login",
                "status": "failed",
            },
        )
        await orchestrator._dispatch(event)
        linear_service.update_issue_state.assert_not_called()

    @pytest.mark.asyncio
    async def test_no_branch_skipped(
        self, orchestrator, linear_service,
    ) -> None:
        event = RepoEvent(
            event_type=EVENT_AGENT_COMPLETED,
            repo="my-repo",
            source=SOURCE_AGENT,
            data={"conversation_id": "conv-1", "branch": "", "status": "completed"},
        )
        await orchestrator._dispatch(event)
        linear_service.update_issue_state.assert_not_called()

    @pytest.mark.asyncio
    async def test_unlinked_branch_skipped(
        self, orchestrator, linear_service,
    ) -> None:
        """Agent completed on a branch not linked to any Linear issue."""
        event = RepoEvent(
            event_type=EVENT_AGENT_COMPLETED,
            repo="my-repo",
            source=SOURCE_AGENT,
            data={
                "conversation_id": "conv-1",
                "branch": "unlinked-branch",
                "status": "completed",
            },
        )
        await orchestrator._dispatch(event)
        linear_service.update_issue_state.assert_not_called()


# ------------------------------------------------------------------
# Outbound: pr_update
# ------------------------------------------------------------------


class TestOnPrUpdate:
    @pytest.mark.asyncio
    async def test_pr_opened_transitions_to_started(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        _link_project_with_issues(linear_store)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        event = RepoEvent(
            event_type=EVENT_PR_UPDATE,
            repo="my-repo",
            source=SOURCE_GITHUB,
            data={
                "action": "opened",
                "number": 42,
                "title": "Add login",
                "state": "open",
                "merged": False,
                "head_branch": issue.branch,
                "sender": "alice",
            },
        )
        await orchestrator._dispatch(event)

        linear_service.update_issue_state.assert_called_once_with(
            "li-1", "state-inprogress",
        )

    @pytest.mark.asyncio
    async def test_pr_merged_transitions_to_completed(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        _link_project_with_issues(linear_store)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        event = RepoEvent(
            event_type=EVENT_PR_UPDATE,
            repo="my-repo",
            source=SOURCE_GITHUB,
            data={
                "action": "closed",
                "number": 42,
                "title": "Add login",
                "state": "closed",
                "merged": True,
                "head_branch": issue.branch,
                "sender": "alice",
            },
        )
        await orchestrator._dispatch(event)

        linear_service.update_issue_state.assert_called_once_with(
            "li-1", "state-done",
        )

    @pytest.mark.asyncio
    async def test_pr_action_merged_transitions_to_completed(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """Defensive: handle a bare action="merged" if ever sent by the Events API.

        GitHub currently always sends action="closed" + merged=true, but
        we handle action="merged" defensively in case the Events API
        ever diverges from the webhook contract.
        """
        _link_project_with_issues(linear_store)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        event = RepoEvent(
            event_type=EVENT_PR_UPDATE,
            repo="my-repo",
            source=SOURCE_GITHUB,
            data={
                "action": "merged",
                "number": 42,
                "title": "Add login",
                "state": "closed",
                "merged": True,
                "head_branch": issue.branch,
                "sender": "alice",
            },
        )
        await orchestrator._dispatch(event)

        linear_service.update_issue_state.assert_called_once_with(
            "li-1", "state-done",
        )

    @pytest.mark.asyncio
    async def test_pr_closed_not_merged_skipped(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """Closed but not merged PRs don't trigger transitions."""
        _link_project_with_issues(linear_store)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        event = RepoEvent(
            event_type=EVENT_PR_UPDATE,
            repo="my-repo",
            source=SOURCE_GITHUB,
            data={
                "action": "closed",
                "number": 42,
                "state": "closed",
                "merged": False,
                "head_branch": issue.branch,
                "sender": "alice",
            },
        )
        await orchestrator._dispatch(event)
        linear_service.update_issue_state.assert_not_called()

    @pytest.mark.asyncio
    async def test_pr_update_from_linear_source_ignored(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """Source-aware filtering: LINEAR-sourced PR events are ignored."""
        _link_project_with_issues(linear_store)

        event = RepoEvent(
            event_type=EVENT_PR_UPDATE,
            repo="my-repo",
            source=SOURCE_LINEAR,  # Would cause loop
            data={
                "action": "opened",
                "number": 42,
                "head_branch": "eng-1/add-login",
                "sender": "linear-bot",
            },
        )
        await orchestrator._dispatch(event)
        linear_service.update_issue_state.assert_not_called()

    @pytest.mark.asyncio
    async def test_pr_synchronize_ignored(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """PR synchronize events (new commits pushed) don't trigger transitions."""
        _link_project_with_issues(linear_store)
        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        event = RepoEvent(
            event_type=EVENT_PR_UPDATE,
            repo="my-repo",
            source=SOURCE_GITHUB,
            data={
                "action": "synchronize",
                "number": 42,
                "head_branch": issue.branch,
            },
        )
        await orchestrator._dispatch(event)
        linear_service.update_issue_state.assert_not_called()


# ------------------------------------------------------------------
# Source-aware loop prevention
# ------------------------------------------------------------------


class TestLoopPrevention:
    @pytest.mark.asyncio
    async def test_agent_completed_from_linear_source_ignored(
        self, orchestrator, linear_service,
    ) -> None:
        """SOURCE_LINEAR events never call back to Linear API."""
        event = RepoEvent(
            event_type=EVENT_AGENT_COMPLETED,
            repo="my-repo",
            source=SOURCE_LINEAR,
            data={"branch": "eng-1/x", "status": "completed"},
        )
        await orchestrator._dispatch(event)
        linear_service.update_issue_state.assert_not_called()


# ------------------------------------------------------------------
# Transition error handling
# ------------------------------------------------------------------


class TestTransitionIssue:
    @pytest.mark.asyncio
    async def test_caches_workflow_states(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """Workflow states are fetched once per team then cached."""
        _link_project_with_issues(linear_store)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        # First transition — cache miss, fetches states
        await orchestrator._transition_issue(
            "li-1", issue.linear_project_id, "started",
        )
        assert linear_service.list_workflow_states.call_count == 1

        # Second transition — cache hit, no fetch
        await orchestrator._transition_issue(
            "li-1", issue.linear_project_id, "completed",
        )
        assert linear_service.list_workflow_states.call_count == 1  # Still 1

    @pytest.mark.asyncio
    async def test_missing_project_returns_false(
        self, orchestrator,
    ) -> None:
        result = await orchestrator._transition_issue(
            "li-1", "nonexistent-pk", "started",
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_missing_state_type_returns_false(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """If the target state type doesn't exist for this team, return False."""
        _link_project_with_issues(linear_store)

        # Override to return states without "started"
        linear_service.list_workflow_states = AsyncMock(return_value=[
            {"id": "s1", "name": "Backlog", "type": "backlog", "position": 0},
        ])

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        result = await orchestrator._transition_issue(
            "li-1", issue.linear_project_id, "started",
        )
        assert result is False
        linear_service.update_issue_state.assert_not_called()

    @pytest.mark.asyncio
    async def test_api_error_returns_false(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """AppError during transition is caught and returns False."""
        _link_project_with_issues(linear_store)

        linear_service.update_issue_state = AsyncMock(
            side_effect=AppError(ErrorCode.INTERNAL_ERROR, "API down"),
        )

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        result = await orchestrator._transition_issue(
            "li-1", issue.linear_project_id, "started",
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_api_returns_failure(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """API returns success=False — transition returns False."""
        _link_project_with_issues(linear_store)

        linear_service.update_issue_state = AsyncMock(
            return_value={"success": False},
        )

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        result = await orchestrator._transition_issue(
            "li-1", issue.linear_project_id, "started",
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_successful_transition_stores_display_name(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """After a successful transition, the local DB stores the display name
        (e.g. "In Progress"), not the raw type string (e.g. "started")."""
        _link_project_with_issues(linear_store)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None
        assert issue.status == "Todo"  # Initial status

        result = await orchestrator._transition_issue(
            "li-1", issue.linear_project_id, "started",
        )
        assert result is True

        # Verify local DB was updated with the display name
        updated = linear_store.get_issue_by_linear_id("li-1")
        assert updated is not None
        assert updated.status == "In Progress"  # NOT "started"

    @pytest.mark.asyncio
    async def test_completed_transition_stores_done(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """Completed transition stores 'Done' display name."""
        _link_project_with_issues(linear_store)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        result = await orchestrator._transition_issue(
            "li-1", issue.linear_project_id, "completed",
        )
        assert result is True

        updated = linear_store.get_issue_by_linear_id("li-1")
        assert updated is not None
        assert updated.status == "Done"  # NOT "completed"

    @pytest.mark.asyncio
    async def test_workflow_state_fetch_error(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """Error fetching workflow states returns False gracefully."""
        _link_project_with_issues(linear_store)

        linear_service.list_workflow_states = AsyncMock(
            side_effect=AppError(ErrorCode.INTERNAL_ERROR, "API error"),
        )

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        result = await orchestrator._transition_issue(
            "li-1", issue.linear_project_id, "started",
        )
        assert result is False

    @pytest.mark.asyncio
    async def test_db_failure_after_api_success_still_returns_true(
        self, orchestrator, linear_store, linear_service,
    ) -> None:
        """A DB error after a successful API transition is logged but
        doesn't mask the success — the poller will reconcile."""
        from sqlalchemy.exc import SQLAlchemyError

        _link_project_with_issues(linear_store)

        issue = linear_store.get_issue_by_linear_id("li-1")
        assert issue is not None

        # Make the local DB update fail after the API call succeeds
        original = linear_store.update_issue_status

        def failing_update(lid: str, status: str) -> bool:
            raise SQLAlchemyError("simulated DB failure")

        linear_store.update_issue_status = failing_update  # type: ignore[assignment]

        result = await orchestrator._transition_issue(
            "li-1", issue.linear_project_id, "started",
        )
        # API call succeeded → should still return True
        assert result is True
        linear_service.update_issue_state.assert_called_once()

        # Restore for other tests
        linear_store.update_issue_status = original  # type: ignore[assignment]


# ------------------------------------------------------------------
# Event bus agent lifecycle events
# ------------------------------------------------------------------


class TestAgentLifecycleEvents:
    """Verify that EVENT_AGENT_STARTED and EVENT_AGENT_COMPLETED exist."""

    def test_event_constants_exist(self) -> None:
        assert EVENT_AGENT_STARTED == "agent_started"
        assert EVENT_AGENT_COMPLETED == "agent_completed"


# ------------------------------------------------------------------
# LinearStore.get_project_by_pk
# ------------------------------------------------------------------


class TestGetProjectByPk:
    def test_returns_project(self, linear_store) -> None:
        project = linear_store.link_project(
            repo="my-repo",
            linear_project_id="proj-1",
            conversation_id=None,
            team_id="team-1",
            project_data={"name": "P", "status": {"type": "started"}},
        )
        found = linear_store.get_project_by_pk(project.id)
        assert found is not None
        assert found.name == "P"

    def test_returns_none_for_missing(self, linear_store) -> None:
        assert linear_store.get_project_by_pk("nonexistent") is None


# ------------------------------------------------------------------
# Webhook → Orchestrator data contract (integration-style)
# ------------------------------------------------------------------


class TestWebhookToOrchestratorContract:
    """Verify that the webhook handler produces event data that the
    orchestrator can actually consume — the critical data contract
    between linear_webhooks.py and linear_sync.py.
    """

    def test_webhook_issue_created_includes_branch(self) -> None:
        """Webhook-produced created events include a derived branch name."""
        from deathstar_server.web.linear_webhooks import _handle_issue_event

        store = MagicMock()
        project = MagicMock()
        project.repo = "my-repo"
        project.name = "Test"
        project.conversation_id = None
        store.get_project_by_linear_id.return_value = project

        data = {
            "id": "issue-1",
            "identifier": "ENG-42",
            "title": "Add login page",
            "state": {"name": "Todo"},
            "priority": 2,
            "url": "https://linear.app/issue/1",
            "team": {"id": "team-1"},
            "project": {"id": "proj-1"},
        }
        event = _handle_issue_event(data, "create", store)
        assert event is not None
        assert event.data["branch"] == "eng-42/add-login-page"

    def test_webhook_uses_linear_branch_name_when_present(self) -> None:
        """If Linear provides a branchName, use it instead of deriving."""
        from deathstar_server.web.linear_webhooks import _handle_issue_event

        store = MagicMock()
        project = MagicMock()
        project.repo = "my-repo"
        project.conversation_id = None
        store.get_project_by_linear_id.return_value = project

        data = {
            "id": "issue-1",
            "identifier": "ENG-42",
            "title": "Add login page",
            "state": {"name": "Todo"},
            "team": {"id": "t1"},
            "project": {"id": "p1"},
            "branchName": "custom/my-branch",
        }
        event = _handle_issue_event(data, "create", store)
        assert event is not None
        assert event.data["branch"] == "custom/my-branch"

    def test_webhook_no_identifier_no_branch(self) -> None:
        """Without identifier, branch can't be derived — should be empty."""
        from deathstar_server.web.linear_webhooks import _handle_issue_event

        store = MagicMock()
        project = MagicMock()
        project.repo = "my-repo"
        project.conversation_id = None
        store.get_project_by_linear_id.return_value = project

        data = {
            "id": "issue-1",
            "state": {"name": "Todo"},
            "project": {"id": "p1"},
        }
        event = _handle_issue_event(data, "create", store)
        assert event is not None
        assert event.data["branch"] == ""

    def test_webhook_issue_created_includes_conversation_id(self) -> None:
        """Webhook events carry conversation_id from the linked project."""
        from deathstar_server.web.linear_webhooks import _handle_issue_event

        store = MagicMock()
        project = MagicMock()
        project.repo = "my-repo"
        project.conversation_id = "conv-abc"
        store.get_project_by_linear_id.return_value = project

        data = {
            "id": "issue-1",
            "identifier": "ENG-42",
            "title": "Add login page",
            "state": {"name": "Todo"},
            "priority": 2,
            "url": "https://linear.app/issue/1",
            "team": {"id": "team-1"},
            "project": {"id": "proj-1"},
        }
        event = _handle_issue_event(data, "create", store)
        assert event is not None
        assert event.data["conversation_id"] == "conv-abc"

    def test_webhook_issue_created_conversation_id_none(self) -> None:
        """When project has no conversation, event carries None."""
        from deathstar_server.web.linear_webhooks import _handle_issue_event

        store = MagicMock()
        project = MagicMock()
        project.repo = "my-repo"
        project.conversation_id = None
        store.get_project_by_linear_id.return_value = project

        data = {
            "id": "issue-1",
            "identifier": "ENG-42",
            "title": "Fix bug",
            "state": {"name": "Todo"},
            "team": {"id": "t1"},
            "project": {"id": "p1"},
        }
        event = _handle_issue_event(data, "create", store)
        assert event is not None
        assert event.data["conversation_id"] is None

    @pytest.mark.asyncio
    async def test_end_to_end_webhook_event_creates_branch(
        self, orchestrator, linear_store,
    ) -> None:
        """Full path: webhook event data → orchestrator → branch creation.

        Simulates what happens when a real webhook fires: the webhook handler
        builds event_data with a derived branch, and the orchestrator
        consumes it.
        """
        from deathstar_server.web.linear_webhooks import _handle_issue_event

        _link_project_with_issues(linear_store)

        # Build the event exactly as the webhook handler would
        store_mock = MagicMock()
        project_mock = MagicMock()
        project_mock.repo = "my-repo"
        project_mock.conversation_id = "conv-1"
        store_mock.get_project_by_linear_id.return_value = project_mock

        webhook_data = {
            "id": "li-new",
            "identifier": "ENG-99",
            "title": "New feature",
            "state": {"name": "Todo"},
            "priority": 1,
            "url": "",
            "team": {"id": "team-1"},
            "project": {"id": "proj-1"},
        }
        event = _handle_issue_event(webhook_data, "create", store_mock)
        assert event is not None
        assert event.data["branch"] == "eng-99/new-feature"
        assert event.data["conversation_id"] == "conv-1"

        # Now dispatch through the orchestrator
        orchestrator._settings.projects_root = Path("/tmp/fake")
        with patch("pathlib.Path.is_dir", return_value=True):
            await orchestrator._dispatch(event)

        # Branch should have been created
        orchestrator._git_service.ensure_branch.assert_called_once()
        call_args = orchestrator._git_service.ensure_branch.call_args
        assert call_args[0][1] == "eng-99/new-feature"

    @pytest.mark.asyncio
    async def test_end_to_end_webhook_links_branch_to_conversation(
        self, orchestrator, linear_store,
    ) -> None:
        """When webhook event carries conversation_id, orchestrator links the branch."""
        _link_project_with_issues(linear_store)

        # Replace the real ConversationStore with a mock so we can verify
        # the add_branch call (the real store would require a valid
        # conversation row to exist in the DB).
        mock_conv_store = MagicMock()
        orchestrator._conversation_store = mock_conv_store

        event = RepoEvent(
            event_type=EVENT_LINEAR_ISSUE_CREATED,
            repo="my-repo",
            source=SOURCE_LINEAR,
            data={
                "linear_issue_id": "li-new",
                "identifier": "ENG-77",
                "title": "Link test",
                "branch": "eng-77/link-test",
                "conversation_id": "conv-1",
            },
        )
        orchestrator._settings.projects_root = Path("/tmp/fake")
        with patch("pathlib.Path.is_dir", return_value=True):
            await orchestrator._dispatch(event)

        mock_conv_store.add_branch.assert_called_once_with(
            "conv-1", "eng-77/link-test",
        )
