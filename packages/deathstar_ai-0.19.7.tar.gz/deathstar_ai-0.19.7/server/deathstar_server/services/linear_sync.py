"""Linear sync orchestrator — bidirectional sync between Linear and DeathStar.

Subscribes to EventBus events and translates them into sync operations:

Inbound (Linear → DeathStar):
- linear_issue_created  → create git branch, link to conversation
- linear_issue_updated  → update local DB status
- linear_issue_deleted  → mark cancelled in DB (keep git branch)

Outbound (DeathStar → Linear):
- agent_completed       → transition issue to "started" (In Progress)
- pr_update (opened)    → transition issue to "started" (In Progress)
- pr_update (merged)    → transition issue to "completed" (Done)

Source-aware filtering prevents bidirectional loops: events originating
from SOURCE_LINEAR only update the DB — they never call back to the
Linear API.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Any

import httpx

from deathstar_server.config import Settings
from deathstar_server.errors import AppError
from deathstar_server.services.event_bus import (
    EVENT_AGENT_COMPLETED,
    EVENT_LINEAR_ISSUE_CREATED,
    EVENT_LINEAR_ISSUE_DELETED,
    EVENT_LINEAR_ISSUE_UPDATED,
    EVENT_PR_UPDATE,
    EventBus,
    RepoEvent,
    SOURCE_LINEAR,
)
from sqlalchemy.exc import SQLAlchemyError

from deathstar_server.services.gitops import GitService
from deathstar_server.services.linear import LinearService
from deathstar_server.web.conversations import ConversationStore
from deathstar_server.web.linear_store import LinearStore, derive_branch_name

logger = logging.getLogger(__name__)

# Workflow state cache TTL — Linear state IDs are team-specific UUIDs.
# Caching avoids an API call per event.
_STATE_CACHE_TTL_SECONDS = 3600  # 1 hour

# Mapping from Linear workflow state *type* strings to the state types
# we use for outbound transitions.
_STATE_TYPE_STARTED = "started"     # In Progress
_STATE_TYPE_COMPLETED = "completed"  # Done


@dataclass(frozen=True)
class _CachedState:
    """A cached workflow state entry (id + display name)."""

    id: str
    name: str


class _WorkflowStateCache:
    """Cache of Linear workflow state IDs keyed by team_id and state type.

    Linear workflow states have ``type`` values like "backlog", "unstarted",
    "started", "completed", "cancelled".  Each team defines its own set
    with team-specific UUIDs, so we cache:
    team_id → {state_type → _CachedState(id, name)}.

    Both the state UUID (for the API call) and the display name (for
    writing to the local DB) are stored so that outbound transitions
    can write human-readable status values consistent with the rest of
    the codebase.
    """

    def __init__(self) -> None:
        self._cache: dict[str, dict[str, _CachedState]] = {}
        self._fetched_at: dict[str, float] = {}

    def get(self, team_id: str, state_type: str) -> _CachedState | None:
        """Return the cached state for a team + type, or None if miss."""
        if team_id not in self._cache:
            return None
        if time.time() - self._fetched_at.get(team_id, 0) > _STATE_CACHE_TTL_SECONDS:
            # Expired
            del self._cache[team_id]
            del self._fetched_at[team_id]
            return None
        return self._cache[team_id].get(state_type)

    def put(self, team_id: str, states: list[dict[str, Any]]) -> None:
        """Populate the cache for a team from a list_workflow_states() result.

        Each entry has: {id, name, type, position}.  We pick the first
        state per type (lowest position wins since states are usually
        returned in position order).
        """
        by_type: dict[str, _CachedState] = {}
        for state in states:
            stype = state.get("type", "")
            state_id = state.get("id", "")
            if stype and state_id and stype not in by_type:
                by_type[stype] = _CachedState(
                    id=state_id,
                    name=state.get("name", stype),
                )
        self._cache[team_id] = by_type
        self._fetched_at[team_id] = time.time()

    def is_cached(self, team_id: str) -> bool:
        """True if we have a non-expired cache entry for this team."""
        if team_id not in self._cache:
            return False
        if time.time() - self._fetched_at.get(team_id, 0) > _STATE_CACHE_TTL_SECONDS:
            # Expired — clean up, consistent with get()
            del self._cache[team_id]
            del self._fetched_at[team_id]
            return False
        return True


class LinearSyncOrchestrator:
    """Subscribes to EventBus and performs Linear ↔ DeathStar sync.

    Lifecycle: ``start()`` spawns a background task that listens to
    all EventBus events.  ``stop()`` cancels it.

    The orchestrator only activates when ``linear_api_key`` is configured.
    """

    def __init__(
        self,
        settings: Settings,
        linear_service: LinearService,
        linear_store: LinearStore,
        conversation_store: ConversationStore,
        git_service: GitService,
        event_bus: EventBus,
    ) -> None:
        self._settings = settings
        self._linear_service = linear_service
        self._linear_store = linear_store
        self._conversation_store = conversation_store
        self._git_service = git_service
        self._event_bus = event_bus
        self._state_cache = _WorkflowStateCache()
        self._task: asyncio.Task | None = None
        self._running = False

    async def start(self) -> None:
        if not self._settings.linear_api_key:
            logger.info("Linear sync orchestrator disabled — no LINEAR_API_KEY configured")
            return
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._listen_loop(), name="linear-sync")
        logger.info("Linear sync orchestrator started")

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        logger.info("Linear sync orchestrator stopped")

    # ------------------------------------------------------------------
    # Main event loop
    # ------------------------------------------------------------------

    async def _listen_loop(self) -> None:
        """Subscribe to all events and dispatch to handlers.

        Wraps the subscription in a ``while self._running`` loop so that
        truly unexpected exceptions (outside the four types caught per-event)
        are logged and the listener restarts after a brief delay — matching
        the resilience pattern used by GitHubPoller and LinearPoller.
        """
        while self._running:
            try:
                async with self._event_bus.subscribe() as events:
                    async for event in events:
                        if not self._running:
                            break
                        try:
                            await self._dispatch(event)
                        except asyncio.CancelledError:
                            raise
                        except (AppError, SQLAlchemyError, httpx.RequestError, OSError) as exc:
                            # Per-event isolation: log and continue so one bad
                            # event doesn't take down the entire listener loop.
                            logger.warning(
                                "Linear sync: error handling event %s for %s: %s",
                                event.event_type,
                                event.repo,
                                exc,
                            )
            except asyncio.CancelledError:
                return
            except Exception:
                # Unexpected error at the subscription level — log and
                # restart after a brief delay to avoid a tight crash loop.
                logger.exception("Linear sync: listener crashed, restarting in 5s")
                await asyncio.sleep(5)

    async def _dispatch(self, event: RepoEvent) -> None:
        """Route an event to the appropriate handler."""
        etype = event.event_type

        # --- Inbound: Linear → DeathStar ---
        if etype == EVENT_LINEAR_ISSUE_CREATED:
            await self._on_linear_issue_created(event)
        elif etype == EVENT_LINEAR_ISSUE_UPDATED:
            await self._on_linear_issue_updated(event)
        elif etype == EVENT_LINEAR_ISSUE_DELETED:
            await self._on_linear_issue_deleted(event)

        # --- Outbound: DeathStar → Linear ---
        # Only process non-Linear-sourced events to prevent sync loops
        elif etype == EVENT_AGENT_COMPLETED and event.source != SOURCE_LINEAR:
            await self._on_agent_completed(event)
        elif etype == EVENT_PR_UPDATE and event.source != SOURCE_LINEAR:
            await self._on_pr_update(event)

    # ------------------------------------------------------------------
    # Inbound handlers (Linear → DeathStar)
    # ------------------------------------------------------------------

    async def _on_linear_issue_created(self, event: RepoEvent) -> None:
        """Handle new Linear issues — persist to DB, create git branch, link to conversation.

        For webhook-sourced events (single issue), we upsert a LinearIssue
        row so the issue is immediately queryable by ``get_issue_by_branch``
        for outbound transitions, then create the git branch.
        For poller-sourced events (batch summary), the DB was already
        updated in sync_issues() — nothing extra to do.
        """
        data = event.data

        # Poller emits summary events with "count" — no per-issue data
        if data.get("source") == "poller":
            return

        branch = data.get("branch", "")
        repo = event.repo
        conversation_id = data.get("conversation_id")
        linear_issue_id = data.get("linear_issue_id", "")
        identifier = data.get("identifier", "")
        title = data.get("title", "")

        # Derive branch from identifier/title if the event doesn't include one
        if not branch and identifier:
            branch = derive_branch_name(identifier, title)

        if not branch or not repo:
            return

        # Upsert the LinearIssue row so outbound handlers (agent_completed,
        # pr_update) can find it via get_issue_by_branch() immediately,
        # without waiting for the next poller cycle.
        if linear_issue_id:
            project_id = data.get("project_id", "")
            project = self._linear_store.get_project_by_linear_id(project_id) if project_id else None
            if project:
                try:
                    self._linear_store.upsert_issue(
                        linear_project_id=project.id,
                        repo=repo,
                        linear_issue_id=linear_issue_id,
                        identifier=identifier,
                        title=title,
                        status=data.get("status", ""),
                        priority=data.get("priority", 0) or 0,
                        branch=branch,
                        assignee=data.get("assignee"),
                        url=data.get("url", ""),
                    )
                except SQLAlchemyError:
                    logger.warning(
                        "Linear sync: failed to upsert issue %s in DB",
                        linear_issue_id,
                        exc_info=True,
                    )

        # Create git branch if it doesn't exist
        projects_root = self._settings.projects_root
        repo_root = projects_root / repo
        if repo_root.is_dir():
            try:
                self._git_service.ensure_branch(repo_root, branch)
                logger.info(
                    "Linear sync: created branch %s for %s in %s",
                    branch, data.get("identifier", "?"), repo,
                )
            except AppError:
                # Branch already exists or git error — not fatal
                logger.debug(
                    "Linear sync: branch %s already exists or could not be created in %s",
                    branch, repo,
                    exc_info=True,
                )

        # Link branch to conversation if we have one
        if conversation_id:
            try:
                self._conversation_store.add_branch(conversation_id, branch)
            except SQLAlchemyError:
                logger.debug(
                    "Linear sync: could not link branch %s to conversation %s",
                    branch, conversation_id,
                    exc_info=True,
                )

    async def _on_linear_issue_updated(self, event: RepoEvent) -> None:
        """Handle Linear issue updates — sync status to local DB.

        For webhook events the status was already in the event data.
        For poller events the DB was already updated in sync_issues().
        """
        data = event.data

        # Poller events already synced via sync_issues()
        if data.get("source") == "poller":
            return

        linear_issue_id = data.get("linear_issue_id", "")
        status = data.get("status", "")
        if linear_issue_id and status:
            self._linear_store.update_issue_status(linear_issue_id, status)

    async def _on_linear_issue_deleted(self, event: RepoEvent) -> None:
        """Handle Linear issue deletion — mark cancelled in DB.

        We keep the git branch (don't delete branches on issue removal)
        but update the local status to "Cancelled".

        Note: for poller-sourced events, ``sync_issues()`` already
        deleted the DB row before publishing the event, so
        ``update_issue_status`` will return False (row not found).
        This handler primarily serves webhook-sourced deletions where
        the row still exists in the DB.
        """
        data = event.data
        linear_issue_id = data.get("linear_issue_id", "")
        if linear_issue_id:
            self._linear_store.update_issue_status(linear_issue_id, "Cancelled")

    # ------------------------------------------------------------------
    # Outbound handlers (DeathStar → Linear)
    # ------------------------------------------------------------------

    async def _on_agent_completed(self, event: RepoEvent) -> None:
        """Agent finished work on a branch → transition Linear issue to In Progress.

        Only triggers for successful completions (status=completed).
        """
        data = event.data
        if data.get("status") != "completed":
            return

        branch = data.get("branch", "")
        repo = event.repo
        if not branch:
            return

        issue = self._linear_store.get_issue_by_branch(repo, branch)
        if not issue:
            return

        await self._transition_issue(
            issue.linear_issue_id,
            issue.linear_project_id,
            _STATE_TYPE_STARTED,
            context=f"agent completed on {branch}",
        )

    async def _on_pr_update(self, event: RepoEvent) -> None:
        """PR opened or merged → transition Linear issue state.

        - PR opened → "started" (In Progress)
        - PR merged → "completed" (Done)

        A future iteration could look up a team-specific "In Review"
        state for PR-opened transitions if teams configure one.
        """
        data = event.data
        action = data.get("action", "")
        branch = data.get("head_branch", "")
        repo = event.repo

        if not branch:
            return

        issue = self._linear_store.get_issue_by_branch(repo, branch)
        if not issue:
            return

        if action == "opened":
            # Transition to "started" (In Progress) on PR open.
            await self._transition_issue(
                issue.linear_issue_id,
                issue.linear_project_id,
                _STATE_TYPE_STARTED,
                context=f"PR opened for {branch}",
            )
        elif action == "closed" and data.get("merged"):
            await self._transition_issue(
                issue.linear_issue_id,
                issue.linear_project_id,
                _STATE_TYPE_COMPLETED,
                context=f"PR merged for {branch}",
            )
        elif action == "merged":
            # Defensive: GitHub always sends action="closed" + merged=true,
            # but handle a bare "merged" action in case the Events API
            # ever diverges from the webhook contract.
            await self._transition_issue(
                issue.linear_issue_id,
                issue.linear_project_id,
                _STATE_TYPE_COMPLETED,
                context=f"PR merged for {branch}",
            )

    # ------------------------------------------------------------------
    # Workflow state transitions
    # ------------------------------------------------------------------

    async def _transition_issue(
        self,
        linear_issue_id: str,
        project_id: str,
        target_state_type: str,
        *,
        context: str = "",
    ) -> bool:
        """Transition a Linear issue to a target workflow state type.

        ``project_id`` is the internal DB PK (from LinearIssue.linear_project_id
        FK).  Resolves the team_id from the project, looks up (or caches)
        the team's workflow states, then calls update_issue_state().

        Returns True if the transition succeeded, False otherwise.
        """
        # project_id is the internal PK — look up via session.get()
        project = self._linear_store.get_project_by_pk(project_id)
        if not project:
            logger.debug(
                "Linear sync: cannot find project for issue %s — skipping transition",
                linear_issue_id,
            )
            return False

        team_id = project.linear_team_id

        if not team_id:
            logger.debug(
                "Linear sync: no team_id for project %s — skipping transition",
                project_id,
            )
            return False

        # Resolve the target state from cache or API
        cached = self._state_cache.get(team_id, target_state_type)
        if not cached:
            try:
                states = await self._linear_service.list_workflow_states(team_id)
                self._state_cache.put(team_id, states)
                cached = self._state_cache.get(team_id, target_state_type)
            except (AppError, httpx.RequestError) as exc:
                logger.warning(
                    "Linear sync: failed to fetch workflow states for team %s: %s",
                    team_id, exc,
                )
                return False

        if not cached:
            logger.debug(
                "Linear sync: no '%s' state found for team %s — skipping",
                target_state_type, team_id,
            )
            return False

        try:
            result = await self._linear_service.update_issue_state(
                linear_issue_id, cached.id,
            )
        except (AppError, httpx.RequestError) as exc:
            logger.warning(
                "Linear sync: error transitioning issue %s to %s: %s",
                linear_issue_id, target_state_type, exc,
            )
            return False

        success = result.get("success", False)
        if success:
            logger.info(
                "Linear sync: transitioned issue %s to %s (%s)",
                linear_issue_id, cached.name, context,
            )
            # Update local DB with the display name (e.g. "In Progress",
            # "Done") to stay consistent with poller/webhook code paths
            # that also write display names.  A DB failure here should not
            # mask the successful API transition — the poller will reconcile.
            try:
                self._linear_store.update_issue_status(
                    linear_issue_id, cached.name,
                )
            except SQLAlchemyError:
                logger.warning(
                    "Linear sync: API transition succeeded but local DB "
                    "update failed for issue %s (poller will reconcile)",
                    linear_issue_id,
                    exc_info=True,
                )
        else:
            logger.warning(
                "Linear sync: transition failed for issue %s to %s",
                linear_issue_id, target_state_type,
            )
        return success
