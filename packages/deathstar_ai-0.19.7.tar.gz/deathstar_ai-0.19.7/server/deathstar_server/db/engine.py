"""SQLAlchemy engine creation and configuration."""

from __future__ import annotations

from sqlalchemy import Engine, create_engine


def create_db_engine(database_url: str) -> Engine:
    """Create a SQLAlchemy engine from a PostgreSQL database URL."""
    return create_engine(
        database_url,
        pool_pre_ping=True,
        pool_size=10,
        max_overflow=20,
    )
