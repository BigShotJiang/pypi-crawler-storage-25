"""
LiuCodeAgent CLI - 主入口

Usage:
    liuagent "创建一个 Flask Web API，包含用户注册和登录功能"
    liuagent --scenario write_file "创建 hello.py"
    liuagent --scenario complex_task --complexity complex "重构整个项目架构"
    liuagent -i
    python -m liu_agent "任务描述"
"""
import asyncio
import argparse
import json
import sys
import uuid

from liu_agent.harness.core_loop import Harness, PermissionLevel, PermissionManager
from liu_agent.harness.context_compressor import ContextCompressor, CompressionConfig
from liu_agent.harness.orchestrator import MultiAgentOrchestrator
from liu_agent.model.engine import MockModelEngine, OpenAIEngine, AnthropicEngine
from liu_agent.tools.tool_registry import ToolRegistry
from liu_agent.tools.implementations import FileTools, ShellTools, GitTools, TestTools
from liu_agent.environment.sandbox import Sandbox


def create_tool_registry() -> ToolRegistry:
    """创建并注册所有工具"""
    registry = ToolRegistry(default_top_k=8)

    registry.register(
        name="read_file",
        description="读取文件内容。参数: path (文件路径)",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "文件路径"}
            },
            "required": ["path"]
        },
        handler=FileTools.read_file,
        is_read_only=True,
        tags=["file", "read"]
    )

    registry.register(
        name="list_directory",
        description="列出目录内容。参数: path (目录路径, 默认当前目录)",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "目录路径", "default": "."}
            }
        },
        handler=FileTools.list_directory,
        is_read_only=True,
        tags=["file", "list"]
    )

    registry.register(
        name="search_code",
        description="在代码库中搜索。参数: query (搜索关键词), path (搜索路径)",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "搜索关键词"},
                "path": {"type": "string", "description": "搜索路径", "default": "."}
            },
            "required": ["query"]
        },
        handler=FileTools.search_code,
        is_read_only=True,
        tags=["search", "code"]
    )

    registry.register(
        name="write_file",
        description="写入文件。参数: path (文件路径), content (文件内容)",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "文件路径"},
                "content": {"type": "string", "description": "文件内容"}
            },
            "required": ["path", "content"]
        },
        handler=FileTools.write_file,
        is_read_only=False,
        tags=["file", "write"]
    )

    registry.register(
        name="edit_file",
        description="编辑文件（搜索替换）。参数: path, old_string, new_string",
        parameters={
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "old_string": {"type": "string", "description": "要替换的字符串"},
                "new_string": {"type": "string", "description": "新字符串"}
            },
            "required": ["path", "old_string", "new_string"]
        },
        handler=FileTools.edit_file,
        is_read_only=False,
        tags=["file", "edit"]
    )

    registry.register(
        name="execute_shell",
        description="执行 shell 命令。参数: command (命令字符串)",
        parameters={
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "要执行的命令"}
            },
            "required": ["command"]
        },
        handler=ShellTools.execute_shell,
        is_read_only=False,
        tags=["shell", "system"]
    )

    registry.register(
        name="git_status",
        description="查看 git 状态",
        parameters={"type": "object", "properties": {}},
        handler=GitTools.git_status,
        is_read_only=True,
        tags=["git"]
    )

    registry.register(
        name="git_commit",
        description="提交代码。参数: message (提交信息)",
        parameters={
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "提交信息"}
            },
            "required": ["message"]
        },
        handler=GitTools.git_commit,
        is_read_only=False,
        tags=["git"]
    )

    registry.register(
        name="run_tests",
        description="运行测试。参数: test_path (测试路径), framework (测试框架)",
        parameters={
            "type": "object",
            "properties": {
                "test_path": {"type": "string", "default": "."},
                "framework": {"type": "string", "enum": ["pytest", "unittest", "jest"], "default": "pytest"}
            }
        },
        handler=TestTools.run_tests,
        is_read_only=True,
        tags=["test"]
    )

    return registry


def create_harness(task: str, scenario: str = "default",
                   model_type: str = "mock", complexity: str = "simple") -> Harness:
    """创建 Harness 实例"""

    if model_type == "mock":
        model = MockModelEngine(scenario=scenario)
    elif model_type == "openai":
        model = OpenAIEngine()
    elif model_type == "anthropic":
        model = AnthropicEngine()
    else:
        model = MockModelEngine(scenario=scenario)

    tools = create_tool_registry()

    sandbox = Sandbox(
        workspace_dir="./agent_workspace",
        permission="write-workspace",
        use_docker=False,
    )

    compressor = ContextCompressor(
        config=CompressionConfig(
            snip_threshold=3000,
            preserve_recent_turns=5
        )
    )

    permission = PermissionManager(level=PermissionLevel.AUTO_WRITE)

    harness = Harness(
        model_engine=model,
        tool_registry=tools,
        sandbox=sandbox,
        context_compressor=compressor,
        permission_manager=permission,
        max_turns=20,
        token_budget=100000,
        enable_speculation=True,
        enable_concurrent_reads=True
    )

    return harness


class HarnessFactory:
    """Harness 工厂 - 用于多 Agent 编排"""

    def __init__(self, model_type: str = "mock", scenario: str = "default"):
        self.model_type = model_type
        self.scenario = scenario
        self.tools = create_tool_registry()
        self.shared_cache = {}

    def create(self, archetype=None, tools_subset=None, shared_cache=None):
        """创建 Harness 实例"""
        model = MockModelEngine(scenario=self.scenario)

        sandbox = Sandbox(
            workspace_dir=f"./agent_workspace_{uuid.uuid4().hex[:6]}",
            permission="write-workspace",
            use_docker=False
        )

        harness = Harness(
            model_engine=model,
            tool_registry=self.tools,
            sandbox=sandbox,
            context_compressor=ContextCompressor(),
            permission_manager=PermissionManager(level=PermissionLevel.AUTO_WRITE),
            max_turns=15,
            token_budget=50000
        )

        return harness


async def run_single_task(task: str, scenario: str, model_type: str):
    """执行单任务"""
    print(f"\n{'='*60}")
    print(f"LiuCodeAgent - 单任务模式")
    print(f"任务: {task}")
    print(f"场景: {scenario}")
    print(f"{'='*60}\n")

    harness = create_harness(task, scenario, model_type)

    turn_count = 0
    async for turn in harness.run(task):
        turn_count += 1
        print(f"\n第 {turn.turn_id + 1} 轮 [{turn.state.name}]")
        print(f"思考: {turn.thought[:200]}...")

        if turn.tool_calls:
            print(f"工具调用:")
            for tc in turn.tool_calls:
                print(f"  - {tc.name}: {tc.parameters}")

        if turn.tool_results:
            print(f"执行结果:")
            for tr in turn.tool_results:
                status = "[OK]" if tr.success else "[FAIL]"
                print(f"  {status} {tr.output[:150]}...")

        print(f"Token 使用: {turn.token_usage}")

    print(f"\n{'='*60}")
    print(f"任务完成! 共 {turn_count} 轮")

    summary = harness.get_session_summary()
    print(f"\n会话摘要:")
    print(f"  总 Token: {summary['session']['total_tokens']}")
    print(f"  思考时间: {summary['stats']['total_thinking_time']:.2f}s")
    print(f"  执行时间: {summary['stats']['total_execution_time']:.2f}s")
    print(f"{'='*60}\n")

    return summary


async def run_complex_task(task: str, complexity: str, model_type: str):
    """执行复杂任务（多 Agent）"""
    print(f"\n{'='*60}")
    print(f"LiuCodeAgent - 多 Agent 编排模式")
    print(f"任务: {task}")
    print(f"复杂度: {complexity}")
    print(f"{'='*60}\n")

    factory = HarnessFactory(model_type=model_type)
    orchestrator = MultiAgentOrchestrator(factory)

    result = await orchestrator.run_task(task, complexity=complexity)

    print(f"\n执行策略: {result['strategy']}")

    if result['strategy'] == 'sequential':
        for i, r in enumerate(result['results']):
            print(f"\n子任务 {i+1}:")
            print(f"  轮次: {len(r['results'])}")
            print(f"  Token: {r['summary']['session']['total_tokens']}")

    print(f"\n{'='*60}\n")
    return result


def main():
    """CLI 入口（同步包装）"""
    asyncio.run(_async_main())


async def _async_main():
    parser = argparse.ArgumentParser(
        prog="liuagent",
        description="LiuCodeAgent - 基于 Harness 架构的自主代码编写 Agent"
    )
    parser.add_argument("task", nargs="?", help="要执行的任务")
    parser.add_argument("--scenario", default="default",
                       choices=["default", "write_file", "edit_file", "complex_task"],
                       help="模拟场景")
    parser.add_argument("--model", default="mock",
                       choices=["mock", "openai", "anthropic"],
                       help="模型类型")
    parser.add_argument("--complexity", default="simple",
                       choices=["simple", "medium", "complex", "auto"],
                       help="任务复杂度")
    parser.add_argument("--interactive", "-i", action="store_true",
                       help="交互模式")
    parser.add_argument("--version", "-v", action="version",
                       version=f"%(prog)s {__import__('liu_agent').__version__}")

    args = parser.parse_args()

    if args.interactive or not args.task:
        print("\nLiuCodeAgent 交互模式")
        print("输入任务（或 'quit' 退出）:\n")

        while True:
            try:
                task = input("> ").strip()
                if task.lower() in ['quit', 'exit', 'q']:
                    break
                if not task:
                    continue

                await run_single_task(task, args.scenario, args.model)

            except KeyboardInterrupt:
                print("\n\n收到中断信号，退出...")
                break
            except Exception as e:
                print(f"错误: {e}")
    else:
        if args.complexity in ["medium", "complex"]:
            await run_complex_task(args.task, args.complexity, args.model)
        else:
            await run_single_task(args.task, args.scenario, args.model)


if __name__ == "__main__":
    main()
