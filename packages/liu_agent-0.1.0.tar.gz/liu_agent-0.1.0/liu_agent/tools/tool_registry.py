"""
三层懒加载工具注册表
基于 Hermes 论文的 Tiered Lazy Loading 策略
"""
import asyncio
import json
import re
from typing import Dict, List, Any, Optional, Callable, Coroutine
from dataclasses import dataclass, field
from collections import defaultdict
from liu_agent.harness.core_loop import ToolCall, ToolResult


@dataclass
class ToolSchema:
    """工具 Schema 定义"""
    name: str
    description: str
    parameters: Dict[str, Any]
    is_read_only: bool = True
    server: str = "default"
    tags: List[str] = field(default_factory=list)

    def to_tier1(self) -> Dict:
        """Tier 1: 仅名称+描述（~50 tokens）"""
        return {
            "name": self.name,
            "description": self.description[:100] + "..." if len(self.description) > 100 else self.description
        }

    def to_tier2(self) -> Dict:
        """Tier 2: 完整 Schema（~300-500 tokens）"""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
            "read_only": self.is_read_only
        }


class ToolPredictor:
    """
    预测性工具选择器
    混合策略：关键词匹配 + 语义相似度
    """

    def __init__(self):
        self.keyword_map = defaultdict(set)
        self.tool_embeddings = {}

    def index_tool(self, tool_id: str, schema: ToolSchema):
        """索引工具用于快速检索"""
        # 关键词索引
        words = set(re.findall(r'\w+', schema.description.lower()))
        words.update(schema.tags)
        for word in words:
            self.keyword_map[word].add(tool_id)

    def predict(self, context: str, available_tools: List[str], top_k: int = 8) -> List[str]:
        """预测最相关的工具"""
        if not context:
            return available_tools[:top_k]

        # 关键词匹配
        context_words = set(re.findall(r'\w+', context.lower()))
        scores = defaultdict(float)

        for word in context_words:
            for tool_id in self.keyword_map.get(word, set()):
                if tool_id in available_tools:
                    scores[tool_id] += 1.0

        # 按分数排序
        sorted_tools = sorted(
            scores.keys(), 
            key=lambda x: scores[x], 
            reverse=True
        )

        # 如果预测不足，补充默认工具
        result = sorted_tools[:top_k]
        for tool_id in available_tools:
            if len(result) >= top_k:
                break
            if tool_id not in result:
                result.append(tool_id)

        return result[:top_k]


class ToolRegistry:
    """
    三层懒加载工具注册表

    Tier 1: 仅工具名称和简要描述（默认加载，~1,400 tokens）
    Tier 2: 完整 Schema（按需加载，~8,000 tokens）
    Tier 3: 预测性选择（上下文感知，动态调整）
    """

    def __init__(self, default_top_k: int = 8):
        self._tools: Dict[str, ToolSchema] = {}
        self._handlers: Dict[str, Callable] = {}
        self._tier1_cache: Dict[str, Dict] = {}
        self._tier2_cache: Dict[str, Dict] = {}
        self._predictor = ToolPredictor()
        self.default_top_k = default_top_k

    def register(
        self, 
        name: str,
        description: str,
        parameters: Dict[str, Any],
        handler: Callable,
        is_read_only: bool = True,
        server: str = "default",
        tags: List[str] = None
    ):
        """注册工具"""
        schema = ToolSchema(
            name=name,
            description=description,
            parameters=parameters,
            is_read_only=is_read_only,
            server=server,
            tags=tags or []
        )

        self._tools[name] = schema
        self._handlers[name] = handler
        self._tier1_cache[name] = schema.to_tier1()
        self._predictor.index_tool(name, schema)

    def get_active_tools(self, context: str = "", top_k: int = None) -> List[Dict]:
        """
        获取活跃工具列表

        策略：
        - 无上下文：返回 Tier 1（所有工具名称）
        - 有上下文：Tier 3 预测 + Tier 2 加载
        """
        top_k = top_k or self.default_top_k

        if not context or len(self._tools) <= top_k:
            # 工具数量少，直接返回 Tier 1
            return list(self._tier1_cache.values())

        # Tier 3: 预测相关工具
        relevant = self._predictor.predict(
            context, 
            list(self._tools.keys()), 
            top_k
        )

        # Tier 2: 加载相关工具的完整 Schema
        active = []
        for tool_id in relevant:
            if tool_id not in self._tier2_cache:
                self._tier2_cache[tool_id] = self._tools[tool_id].to_tier2()
            active.append(self._tier2_cache[tool_id])

        return active

    async def execute(self, tool_call: ToolCall, sandbox=None) -> str:
        """执行工具调用"""
        if tool_call.name not in self._handlers:
            raise ValueError(f"未知工具: {tool_call.name}")

        handler = self._handlers[tool_call.name]

        # 注入 sandbox 环境
        kwargs = dict(tool_call.parameters)
        if sandbox is not None:
            kwargs["sandbox"] = sandbox

        # 支持同步和异步 handler
        if asyncio.iscoroutinefunction(handler):
            result = await handler(**kwargs)
        else:
            result = handler(**kwargs)

        return str(result) if result is not None else ""

    def is_read_only(self, tool_call: ToolCall) -> bool:
        """检查工具是否为只读"""
        if tool_call.name in self._tools:
            return self._tools[tool_call.name].is_read_only
        return True

    def list_tools(self) -> List[str]:
        """列出所有可用工具"""
        return list(self._tools.keys())

    def get_tool_schema(self, name: str) -> Optional[ToolSchema]:
        """获取工具 Schema"""
        return self._tools.get(name)
