"""
代码编写 Agent 核心工具实现

工具集：
- FileTools: 文件读写、搜索、编辑
- ShellTools: Shell 命令执行
- GitTools: Git 版本控制
- TestTools: 测试运行
- BuildTools: 构建/依赖管理
"""
import os
import subprocess
import json
import re
from typing import Dict, List, Any, Optional
from pathlib import Path


class FileTools:
    """文件操作工具集"""

    CODE_EXTENSIONS = (
        '.py', '.js', '.ts', '.tsx', '.jsx', '.java', '.go', '.rs',
        '.c', '.cpp', '.h', '.hpp', '.cs', '.rb', '.php', '.swift',
        '.kt', '.scala', '.sh', '.yaml', '.yml', '.toml', '.json',
        '.md', '.rst', '.sql', '.html', '.css', '.scss'
    )

    @staticmethod
    async def read_file(path: str, sandbox=None) -> str:
        if sandbox:
            result = await sandbox.execute(f"cat '{path}'")
            return result["stdout"]

        try:
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                return f.read()
        except FileNotFoundError:
            return f"错误: 文件不存在: {path}"
        except PermissionError:
            return f"错误: 权限不足，无法读取: {path}"
        except Exception as e:
            return f"错误: 无法读取文件 {path}: {e}"

    @staticmethod
    async def write_file(path: str, content: str, sandbox=None) -> str:
        if sandbox:
            escaped = content.replace("'", "'\\''")
            cmd = f"cat > '{path}' << 'HERMES_EOF'\n{content}\nHERMES_EOF"
            result = await sandbox.execute(cmd)
            if result["exit_code"] != 0:
                return f"错误: 无法写入文件: {result['stderr']}"
            return f"成功写入文件: {path}"

        try:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            return f"成功写入文件: {path}"
        except PermissionError:
            return f"错误: 权限不足，无法写入: {path}"
        except Exception as e:
            return f"错误: 无法写入文件 {path}: {e}"

    @staticmethod
    async def edit_file(path: str, old_string: str, new_string: str, sandbox=None) -> str:
        content = await FileTools.read_file(path, sandbox)

        if content.startswith("错误:"):
            return content

        if old_string not in content:
            return f"错误: 未找到目标字符串 in {path}"

        new_content = content.replace(old_string, new_string, 1)
        return await FileTools.write_file(path, new_content, sandbox)

    @staticmethod
    async def list_directory(path: str = ".", sandbox=None) -> str:
        if sandbox:
            result = await sandbox.execute(f"ls -la '{path}'")
            return result["stdout"]

        try:
            entries = []
            for entry in sorted(os.listdir(path)):
                full = os.path.join(path, entry)
                if os.path.isdir(full):
                    entries.append(f"📁 {entry}/")
                else:
                    size = os.path.getsize(full)
                    entries.append(f"📄 {entry} ({size}B)")
            return "\n".join(entries) if entries else "(空目录)"
        except FileNotFoundError:
            return f"错误: 目录不存在: {path}"
        except Exception as e:
            return f"错误: {e}"

    @staticmethod
    async def search_code(query: str, path: str = ".", sandbox=None) -> str:
        if sandbox:
            ext_pattern = " ".join(f"--include='*{ext}'" for ext in ['.py', '.js', '.ts', '.java', '.go', '.rs'])
            result = await sandbox.execute(
                f"grep -r '{query}' '{path}' {ext_pattern} -n 2>/dev/null || true"
            )
            return result["stdout"] or "未找到匹配结果"

        results = []
        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != 'node_modules' and d != '__pycache__']
            for file in files:
                if file.endswith(FileTools.CODE_EXTENSIONS):
                    filepath = os.path.join(root, file)
                    try:
                        with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                            for i, line in enumerate(f, 1):
                                if query in line:
                                    results.append(f"{filepath}:{i}: {line.rstrip()}")
                                    if len(results) >= 50:
                                        return "\n".join(results)
                    except (OSError, UnicodeDecodeError) as e:
                        results.append(f"{filepath}:0: [读取失败: {e}]")

        return "\n".join(results) if results else "未找到匹配结果"

    @staticmethod
    async def glob(pattern: str, path: str = ".", sandbox=None) -> str:
        """按 glob 模式搜索文件"""
        if sandbox:
            result = await sandbox.execute(f"find '{path}' -name '{pattern}' -type f 2>/dev/null | head -50")
            return result["stdout"] or "未找到匹配文件"

        results = []
        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != 'node_modules' and d != '__pycache__']
            for file in files:
                from fnmatch import fnmatch
                if fnmatch(file, pattern):
                    results.append(os.path.join(root, file))
                    if len(results) >= 50:
                        break
            if len(results) >= 50:
                break

        return "\n".join(results) if results else "未找到匹配文件"


class ShellTools:
    """Shell 执行工具"""

    @staticmethod
    async def execute_shell(command: str, sandbox=None, timeout: int = 60) -> str:
        if sandbox:
            result = await sandbox.execute(command, timeout=timeout)
            output = result["stdout"]
            if result["stderr"]:
                output += f"\n[stderr]\n{result['stderr']}"
            if result["exit_code"] != 0:
                output += f"\n[exit_code: {result['exit_code']}]"
            return output

        try:
            proc = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            output = proc.stdout
            if proc.stderr:
                output += f"\n[stderr]\n{proc.stderr}"
            if proc.returncode != 0:
                output += f"\n[exit_code: {proc.returncode}]"
            return output
        except subprocess.TimeoutExpired:
            return f"错误: 命令执行超时 ({timeout}s)"
        except FileNotFoundError:
            return f"错误: 命令未找到: {command.split()[0]}"
        except Exception as e:
            return f"错误: 命令执行失败: {e}"


class GitTools:
    """Git 操作工具"""

    @staticmethod
    async def git_status(sandbox=None) -> str:
        return await ShellTools.execute_shell("git status", sandbox)

    @staticmethod
    async def git_log(n: int = 5, sandbox=None) -> str:
        return await ShellTools.execute_shell(f"git log --oneline -{n}", sandbox)

    @staticmethod
    async def git_commit(message: str, sandbox=None) -> str:
        add_result = await ShellTools.execute_shell("git add -A", sandbox)
        if "错误" in add_result:
            return f"git add 失败: {add_result}"
        return await ShellTools.execute_shell(f'git commit -m "{message}"', sandbox)

    @staticmethod
    async def git_diff(sandbox=None) -> str:
        return await ShellTools.execute_shell("git diff", sandbox)

    @staticmethod
    async def git_branch(sandbox=None) -> str:
        return await ShellTools.execute_shell("git branch -a", sandbox)


class TestTools:
    """测试运行工具"""

    @staticmethod
    async def run_tests(test_path: str = ".", framework: str = "pytest", sandbox=None) -> str:
        if framework == "pytest":
            cmd = f"pytest '{test_path}' -v --tb=short 2>&1"
        elif framework == "unittest":
            cmd = f"python -m unittest discover -s '{test_path}' -v 2>&1"
        elif framework == "jest":
            cmd = f"npx jest '{test_path}' --no-coverage 2>&1"
        else:
            return f"不支持的测试框架: {framework}"

        return await ShellTools.execute_shell(cmd, sandbox, timeout=120)

    @staticmethod
    async def run_linter(path: str = ".", sandbox=None) -> str:
        return await ShellTools.execute_shell(
            f"flake8 '{path}' --max-line-length=100 --exclude=__pycache__,.git 2>&1",
            sandbox
        )


class BuildTools:
    """构建和依赖管理工具"""

    PYTHON_MANAGERS = ["pip", "pipenv", "poetry", "uv"]
    JS_MANAGERS = ["npm", "yarn", "pnpm"]

    @staticmethod
    async def install_dependencies(path: str = ".", sandbox=None) -> str:
        """自动检测并安装项目依赖"""
        results = []

        if os.path.exists(os.path.join(path, "requirements.txt")):
            result = await ShellTools.execute_shell(
                f"pip install -r '{path}/requirements.txt' 2>&1 | tail -5",
                sandbox, timeout=120
            )
            results.append(f"[pip/requirements.txt]\n{result}")

        elif os.path.exists(os.path.join(path, "Pipfile")):
            result = await ShellTools.execute_shell(
                f"cd '{path}' && pipenv install 2>&1 | tail -5",
                sandbox, timeout=120
            )
            results.append(f"[pipenv]\n{result}")

        elif os.path.exists(os.path.join(path, "pyproject.toml")):
            result = await ShellTools.execute_shell(
                f"cd '{path}' && poetry install 2>&1 | tail -5",
                sandbox, timeout=120
            )
            results.append(f"[poetry]\n{result}")

        if os.path.exists(os.path.join(path, "package.json")):
            if os.path.exists(os.path.join(path, "yarn.lock")):
                result = await ShellTools.execute_shell(
                    f"cd '{path}' && yarn install 2>&1 | tail -5",
                    sandbox, timeout=120
                )
                results.append(f"[yarn]\n{result}")
            elif os.path.exists(os.path.join(path, "pnpm-lock.yaml")):
                result = await ShellTools.execute_shell(
                    f"cd '{path}' && pnpm install 2>&1 | tail -5",
                    sandbox, timeout=120
                )
                results.append(f"[pnpm]\n{result}")
            else:
                result = await ShellTools.execute_shell(
                    f"cd '{path}' && npm install 2>&1 | tail -5",
                    sandbox, timeout=120
                )
                results.append(f"[npm]\n{result}")

        return "\n\n".join(results) if results else "未检测到依赖文件 (requirements.txt / Pipfile / pyproject.toml / package.json)"

    @staticmethod
    async def build_project(path: str = ".", sandbox=None) -> str:
        """自动检测并构建项目"""
        results = []

        if os.path.exists(os.path.join(path, "setup.py")) or os.path.exists(os.path.join(path, "pyproject.toml")):
            result = await ShellTools.execute_shell(
                f"cd '{path}' && python -m build 2>&1 | tail -10",
                sandbox, timeout=180
            )
            results.append(f"[Python build]\n{result}")

        if os.path.exists(os.path.join(path, "Makefile")):
            result = await ShellTools.execute_shell(
                f"cd '{path}' && make 2>&1 | tail -10",
                sandbox, timeout=180
            )
            results.append(f"[make]\n{result}")

        if os.path.exists(os.path.join(path, "package.json")):
            pkg = os.path.join(path, "package.json")
            try:
                with open(pkg, 'r') as f:
                    data = json.load(f)
                if "build" in data.get("scripts", {}):
                    result = await ShellTools.execute_shell(
                        f"cd '{path}' && npm run build 2>&1 | tail -10",
                        sandbox, timeout=180
                    )
                    results.append(f"[npm build]\n{result}")
            except Exception:
                pass

        return "\n\n".join(results) if results else "未检测到构建配置 (setup.py / Makefile / package.json build script)"

    @staticmethod
    async def check_project_structure(path: str = ".", sandbox=None) -> str:
        """检查项目结构并返回分析"""
        if sandbox:
            result = await sandbox.execute(f"find '{path}' -maxdepth 3 -type f 2>/dev/null | head -50")
            return result["stdout"]

        info = {
            "languages": set(),
            "frameworks": [],
            "has_tests": False,
            "has_build": False,
            "key_files": []
        }

        try:
            for root, dirs, files in os.walk(path):
                dirs[:] = [d for d in dirs if not d.startswith('.') and d != 'node_modules' and d != '__pycache__' and d != '.git']
                for f in files:
                    fp = os.path.join(root, f)
                    rel = os.path.relpath(fp, path)
                    info["key_files"].append(rel)

                    if f.endswith('.py'):
                        info["languages"].add('Python')
                    elif f.endswith(('.js', '.ts', '.jsx', '.tsx')):
                        info["languages"].add('JavaScript/TypeScript')
                    elif f.endswith('.go'):
                        info["languages"].add('Go')
                    elif f.endswith('.rs'):
                        info["languages"].add('Rust')
                    elif f.endswith('.java'):
                        info["languages"].add('Java')

                if len(info["key_files"]) > 100:
                    break
        except Exception as e:
            return f"错误: {e}"

        if os.path.exists(os.path.join(path, "pytest.ini")) or os.path.exists(os.path.join(path, "conftest.py")):
            info["has_tests"] = True
            info["frameworks"].append("pytest")
        if os.path.exists(os.path.join(path, "jest.config.js")) or os.path.exists(os.path.join(path, "jest.config.ts")):
            info["has_tests"] = True
            info["frameworks"].append("jest")

        if os.path.exists(os.path.join(path, "requirements.txt")):
            info["frameworks"].append("pip")
        if os.path.exists(os.path.join(path, "package.json")):
            info["frameworks"].append("npm")
        if os.path.exists(os.path.join(path, "Makefile")):
            info["has_build"] = True

        info["languages"] = list(info["languages"])

        return json.dumps(info, indent=2, ensure_ascii=False)
