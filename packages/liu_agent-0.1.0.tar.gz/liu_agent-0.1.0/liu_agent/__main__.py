"""支持 python -m liu_agent 运行"""
from liu_agent.cli import main

main()
