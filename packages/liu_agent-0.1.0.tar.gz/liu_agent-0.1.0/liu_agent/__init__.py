"""
LiuCodeAgent - 基于 Harness 架构的自主代码编写 Agent

Usage:
    liuagent "创建一个 Flask Web API"
    liuagent -i
    python -m liu_agent "任务描述"
"""

__version__ = "0.1.0"
