"""skills module"""
