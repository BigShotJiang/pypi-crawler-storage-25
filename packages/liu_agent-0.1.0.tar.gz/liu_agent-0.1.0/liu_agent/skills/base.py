"""
Skills 系统 - 可复用的高级能力封装

三层架构：
- SkillDefinition: 技能定义（元数据 + Prompt 模板 + 工具集）
- SkillRegistry: 技能注册表
- SkillExecutor: 技能执行器
"""
import json
import logging
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class SkillCategory(Enum):
    ARCHITECT = "architect"
    DEVELOPER = "developer"
    REVIEWER = "reviewer"
    TESTER = "tester"


class SkillState(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class SkillDefinition:
    name: str
    description: str
    category: SkillCategory
    system_prompt: str
    required_tools: List[str] = field(default_factory=list)
    optional_tools: List[str] = field(default_factory=list)
    max_turns: int = 15
    token_budget: int = 50000
    parameters: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "system_prompt": self.system_prompt[:100] + "...",
            "required_tools": self.required_tools,
            "optional_tools": self.optional_tools,
            "max_turns": self.max_turns,
            "token_budget": self.token_budget
        }


@dataclass
class SkillResult:
    skill_name: str
    state: SkillState
    output: str = ""
    artifacts: List[str] = field(default_factory=list)
    turns_used: int = 0
    tokens_used: int = 0
    error: Optional[str] = None

    def to_dict(self) -> Dict:
        return {
            "skill_name": self.skill_name,
            "state": self.state.value,
            "output": self.output[:500],
            "artifacts": self.artifacts,
            "turns_used": self.turns_used,
            "tokens_used": self.tokens_used,
            "error": self.error
        }


class SkillRegistry:
    def __init__(self):
        self._skills: Dict[str, SkillDefinition] = {}
        self._load_builtin_skills()

    def register(self, skill: SkillDefinition):
        self._skills[skill.name] = skill
        logger.info(f"[SkillRegistry] 注册技能: {skill.name} ({skill.category.value})")

    def get(self, name: str) -> Optional[SkillDefinition]:
        return self._skills.get(name)

    def list_skills(self, category: SkillCategory = None) -> List[SkillDefinition]:
        if category:
            return [s for s in self._skills.values() if s.category == category]
        return list(self._skills.values())

    def match_skill(self, task: str) -> Optional[SkillDefinition]:
        task_lower = task.lower()
        scores: Dict[str, float] = {}

        for name, skill in self._skills.items():
            score = 0.0
            for keyword in skill.description.lower().split():
                if keyword in task_lower:
                    score += 1.0
            for keyword in name.lower().split("_"):
                if keyword in task_lower:
                    score += 2.0
            scores[name] = score

        if not scores:
            return None

        best = max(scores, key=scores.get)
        if scores[best] > 0:
            return self._skills[best]
        return None

    def _load_builtin_skills(self):
        self.register(SkillDefinition(
            name="architect",
            description="架构设计 代码结构分析 技术方案 项目结构",
            category=SkillCategory.ARCHITECT,
            system_prompt="""你是一个专业的软件架构师。你的职责是：

1. 分析项目结构和代码组织
2. 设计技术方案和架构
3. 识别设计问题和改进点
4. 制定重构计划

工作原则：
- 先用 read_file 和 search_code 了解现有代码
- 使用 check_project_structure 分析项目结构
- 给出清晰的技术方案，包含文件列表和关键接口
- 考虑可维护性、可扩展性和性能""",
            required_tools=["read_file", "list_directory", "search_code", "glob", "check_project_structure"],
            optional_tools=["git_status", "git_diff"],
            max_turns=15,
            token_budget=50000
        ))

        self.register(SkillDefinition(
            name="developer",
            description="代码编写 功能实现 开发 创建文件 修改代码 添加功能",
            category=SkillCategory.DEVELOPER,
            system_prompt="""你是一个专业的软件开发者。你的职责是：

1. 实现具体功能
2. 编写和修改代码
3. 遵循现有代码风格
4. 确保代码质量

工作原则：
- 修改前先读取现有代码（read_file）
- 遵循 TDD：先写测试，再写实现
- 每次修改后运行测试验证（run_tests）
- 使用 edit_file 进行精确替换，避免重写整个文件
- 写有意义的提交信息""",
            required_tools=["read_file", "write_file", "edit_file", "search_code", "list_directory"],
            optional_tools=["execute_shell", "git_commit", "run_tests", "install_dependencies", "build_project"],
            max_turns=25,
            token_budget=80000
        ))

        self.register(SkillDefinition(
            name="reviewer",
            description="代码审查 安全检查 review 质量检查 代码审查",
            category=SkillCategory.REVIEWER,
            system_prompt="""你是一个专业的代码审查者。你的职责是：

1. 审查代码质量和风格
2. 识别安全漏洞
3. 发现性能问题
4. 检查错误处理

工作原则：
- 先用 read_file 读取要审查的代码
- 用 search_code 查找相关代码和调用
- 用 run_linter 运行静态分析
- 给出具体的改进建议，包含代码示例
- 按严重程度分级：Critical / Warning / Info""",
            required_tools=["read_file", "search_code", "glob", "run_linter"],
            optional_tools=["git_diff", "git_log"],
            max_turns=10,
            token_budget=30000
        ))

        self.register(SkillDefinition(
            name="tester",
            description="测试 测试生成 单元测试 测试运行 TDD 测试报告",
            category=SkillCategory.TESTER,
            system_prompt="""你是一个专业的测试工程师。你的职责是：

1. 设计和编写测试用例
2. 运行测试并分析结果
3. 生成测试报告
4. 确保代码覆盖率

工作原则：
- 先用 read_file 了解要测试的代码
- 用 search_code 查找依赖和接口
- 编写测试时覆盖：正常路径、边界条件、异常处理
- 运行测试（run_tests）并分析失败原因
- 失败时修复测试或代码，再次运行""",
            required_tools=["read_file", "write_file", "search_code", "run_tests"],
            optional_tools=["execute_shell", "git_diff"],
            max_turns=20,
            token_budget=60000
        ))


class SkillExecutor:
    def __init__(self, harness_factory: Callable):
        self._harness_factory = harness_factory
        self._registry = SkillRegistry()

    @property
    def registry(self) -> SkillRegistry:
        return self._registry

    async def execute(self, task: str, skill_name: str = None, context: Dict = None) -> SkillResult:
        if skill_name:
            skill = self._registry.get(skill_name)
            if not skill:
                return SkillResult(
                    skill_name=skill_name,
                    state=SkillState.FAILED,
                    error=f"技能未找到: {skill_name}"
                )
        else:
            skill = self._registry.match_skill(task)
            if not skill:
                skill = self._registry.get("developer")

        logger.info(f"[SkillExecutor] 使用技能: {skill.name} 执行任务: {task[:80]}...")

        harness = self._harness_factory(
            system_prompt=skill.system_prompt,
            tool_subset=skill.required_tools + skill.optional_tools,
            max_turns=skill.max_turns,
            token_budget=skill.token_budget
        )

        turns_used = 0
        tokens_used = 0
        artifacts = []
        output_parts = []

        try:
            async for turn in harness.run(task, context=context):
                turns_used += 1
                tokens_used += turn.token_usage.get("total", 0)

                if turn.thought:
                    output_parts.append(f"[思考] {turn.thought[:200]}")

                for tc in turn.tool_calls:
                    if tc.name == "write_file":
                        artifacts.append(tc.parameters.get("path", ""))

            final_state = harness.state
            output = "\n".join(output_parts[-5:]) if output_parts else "技能执行完成"

            return SkillResult(
                skill_name=skill.name,
                state=SkillState.COMPLETED if final_state.name == "COMPLETED" else SkillState.FAILED,
                output=output,
                artifacts=[a for a in artifacts if a],
                turns_used=turns_used,
                tokens_used=tokens_used
            )

        except Exception as e:
            logger.error(f"[SkillExecutor] 技能 {skill.name} 执行失败: {e}")
            return SkillResult(
                skill_name=skill.name,
                state=SkillState.FAILED,
                error=str(e),
                turns_used=turns_used,
                tokens_used=tokens_used
            )

    async def execute_chain(self, task: str, skill_names: List[str], context: Dict = None) -> List[SkillResult]:
        results = []
        current_context = context or {}

        for skill_name in skill_names:
            result = await self.execute(task, skill_name=skill_name, context=current_context)
            results.append(result)

            if result.state == SkillState.FAILED:
                break

            current_context["previous_skill"] = skill_name
            current_context["previous_output"] = result.output
            current_context["artifacts"] = result.artifacts

        return results
