"""
Memory 系统 - 上下文记忆、决策存储与压缩

模块：
- ContextMemory: 会话级上下文管理
- DecisionStore: 跨会话决策持久化 (SQLite)
- MemoryCompactor: 记忆压缩与 nudge 机制
"""
import json
import sqlite3
import time
import hashlib
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class MemoryEntry:
    key: str
    content: str
    category: str = "general"
    importance: float = 0.5
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    accessed_at: str = field(default_factory=lambda: datetime.now().isoformat())
    access_count: int = 0
    source_session: str = ""

    def to_dict(self) -> Dict:
        return {
            "key": self.key,
            "content": self.content[:200],
            "category": self.category,
            "importance": self.importance,
            "created_at": self.created_at,
            "accessed_at": self.accessed_at,
            "access_count": self.access_count
        }


class ContextMemory:
    """会话级上下文记忆管理"""

    def __init__(self, max_context_tokens: int = 100000, nudge_interval: int = 10):
        self.max_context_tokens = max_context_tokens
        self.nudge_interval = nudge_interval
        self._entries: List[MemoryEntry] = []
        self._nudge_counter = 0
        self._project_facts: List[str] = []
        self._user_preferences: Dict[str, str] = {}
        self._decision_log: List[Dict] = []

    def add(self, key: str, content: str, category: str = "general", importance: float = 0.5, source_session: str = ""):
        entry = MemoryEntry(
            key=key,
            content=content,
            category=category,
            importance=importance,
            source_session=source_session
        )
        self._entries.append(entry)

    def add_project_fact(self, fact: str):
        self._project_facts.append(fact)
        self.add(f"fact:{len(self._project_facts)}", fact, category="project_fact", importance=0.7)

    def add_user_preference(self, key: str, value: str):
        self._user_preferences[key] = value
        self.add(f"pref:{key}", value, category="user_preference", importance=0.8)

    def add_decision(self, decision: str, reasoning: str = "", turn: int = 0):
        entry = {
            "decision": decision,
            "reasoning": reasoning,
            "turn": turn,
            "timestamp": datetime.now().isoformat()
        }
        self._decision_log.append(entry)
        self.add(f"decision:{len(self._decision_log)}", decision, category="decision", importance=0.6)

    def get_nudge(self) -> Optional[str]:
        self._nudge_counter += 1
        if self._nudge_counter % self.nudge_interval != 0:
            return None

        nudges = []

        if self._project_facts:
            recent_facts = self._project_facts[-3:]
            nudges.append(f"项目关键信息: {'; '.join(recent_facts)}")

        if self._decision_log:
            recent_decisions = self._decision_log[-2:]
            decision_strs = [d["decision"] for d in recent_decisions]
            nudges.append(f"近期决策: {'; '.join(decision_strs)}")

        if self._user_preferences:
            pref_strs = [f"{k}={v}" for k, v in list(self._user_preferences.items())[-3:]]
            nudges.append(f"用户偏好: {'; '.join(pref_strs)}")

        return "\n".join(nudges) if nudges else None

    def get_relevant(self, query: str, top_k: int = 5) -> List[MemoryEntry]:
        query_words = set(query.lower().split())
        scored = []

        for entry in self._entries:
            entry_words = set(entry.content.lower().split())
            overlap = len(query_words & entry_words)
            if overlap > 0:
                score = overlap * entry.importance
                scored.append((score, entry))

        scored.sort(key=lambda x: x[0], reverse=True)

        results = []
        for score, entry in scored[:top_k]:
            entry.accessed_at = datetime.now().isoformat()
            entry.access_count += 1
            results.append(entry)

        return results

    def build_context_injection(self) -> str:
        parts = []

        if self._project_facts:
            parts.append("## 项目信息\n" + "\n".join(f"- {f}" for f in self._project_facts[-5:]))

        if self._user_preferences:
            parts.append("## 用户偏好\n" + "\n".join(
                f"- {k}: {v}" for k, v in list(self._user_preferences.items())[-5:]
            ))

        if self._decision_log:
            parts.append("## 近期决策\n" + "\n".join(
                f"- {d['decision']}" for d in self._decision_log[-3:]
            ))

        return "\n\n".join(parts) if parts else ""

    def to_dict(self) -> Dict:
        return {
            "entry_count": len(self._entries),
            "project_facts": len(self._project_facts),
            "user_preferences": len(self._user_preferences),
            "decisions": len(self._decision_log),
            "nudge_counter": self._nudge_counter
        }


class DecisionStore:
    """跨会话决策持久化 (SQLite)"""

    def __init__(self, db_path: str = None):
        if db_path is None:
            db_dir = Path.home() / ".liu_agent"
            db_dir.mkdir(exist_ok=True)
            db_path = str(db_dir / "memory.db")

        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with self._get_conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS decisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    reasoning TEXT,
                    context TEXT,
                    category TEXT DEFAULT 'general',
                    importance REAL DEFAULT 0.5,
                    created_at TEXT NOT NULL,
                    accessed_at TEXT,
                    access_count INTEGER DEFAULT 0
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS project_facts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_path TEXT NOT NULL,
                    fact TEXT NOT NULL,
                    category TEXT DEFAULT 'general',
                    created_at TEXT NOT NULL,
                    updated_at TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS user_preferences (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_decisions_session
                ON decisions(session_id)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_decisions_category
                ON decisions(category)
            """)

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def save_decision(self, session_id: str, decision: str, reasoning: str = "",
                      context: str = "", category: str = "general", importance: float = 0.5):
        with self._get_conn() as conn:
            conn.execute(
                """INSERT INTO decisions (session_id, decision, reasoning, context, category, importance, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (session_id, decision, reasoning, context, category, importance, datetime.now().isoformat())
            )

    def get_decisions(self, session_id: str = None, category: str = None, limit: int = 20) -> List[Dict]:
        with self._get_conn() as conn:
            query = "SELECT * FROM decisions WHERE 1=1"
            params = []
            if session_id:
                query += " AND session_id = ?"
                params.append(session_id)
            if category:
                query += " AND category = ?"
                params.append(category)
            query += " ORDER BY created_at DESC LIMIT ?"
            params.append(limit)

            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]

    def save_project_fact(self, project_path: str, fact: str, category: str = "general"):
        with self._get_conn() as conn:
            existing = conn.execute(
                "SELECT id FROM project_facts WHERE project_path = ? AND fact = ?",
                (project_path, fact)
            ).fetchone()
            if existing:
                conn.execute(
                    "UPDATE project_facts SET updated_at = ? WHERE id = ?",
                    (datetime.now().isoformat(), existing["id"])
                )
            else:
                conn.execute(
                    "INSERT INTO project_facts (project_path, fact, category, created_at) VALUES (?, ?, ?, ?)",
                    (project_path, fact, category, datetime.now().isoformat())
                )

    def get_project_facts(self, project_path: str, limit: int = 30) -> List[Dict]:
        with self._get_conn() as conn:
            rows = conn.execute(
                "SELECT * FROM project_facts WHERE project_path = ? ORDER BY created_at DESC LIMIT ?",
                (project_path, limit)
            ).fetchall()
            return [dict(r) for r in rows]

    def save_preference(self, key: str, value: str):
        with self._get_conn() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO user_preferences (key, value, updated_at)
                   VALUES (?, ?, ?)""",
                (key, value, datetime.now().isoformat())
            )

    def get_preference(self, key: str) -> Optional[str]:
        with self._get_conn() as conn:
            row = conn.execute(
                "SELECT value FROM user_preferences WHERE key = ?",
                (key,)
            ).fetchone()
            return row["value"] if row else None

    def get_all_preferences(self) -> Dict[str, str]:
        with self._get_conn() as conn:
            rows = conn.execute("SELECT key, value FROM user_preferences").fetchall()
            return {r["key"]: r["value"] for r in rows}

    def cleanup(self, max_age_days: int = 90):
        cutoff = datetime.now().timestamp() - (max_age_days * 86400)
        cutoff_str = datetime.fromtimestamp(cutoff).isoformat()

        with self._get_conn() as conn:
            conn.execute("DELETE FROM decisions WHERE created_at < ?", (cutoff_str,))
            conn.execute("DELETE FROM project_facts WHERE updated_at < ? AND updated_at IS NOT NULL", (cutoff_str,))


class MemoryCompactor:
    """记忆压缩与 nudge 机制"""

    def __init__(self, decision_store: DecisionStore = None, summary_model=None):
        self.decision_store = decision_store
        self.summary_model = summary_model

    def compact_session(self, context_memory: ContextMemory, session_id: str) -> Dict:
        result = {
            "decisions_saved": 0,
            "facts_saved": 0,
            "preferences_saved": 0,
            "entries_compacted": 0
        }

        if not self.decision_store:
            return result

        for decision in context_memory._decision_log:
            self.decision_store.save_decision(
                session_id=session_id,
                decision=decision.get("decision", ""),
                reasoning=decision.get("reasoning", ""),
                category="session"
            )
            result["decisions_saved"] += 1

        for entry in context_memory._entries:
            if entry.category == "project_fact" and entry.importance >= 0.6:
                self.decision_store.save_project_fact(
                    project_path=".",
                    fact=entry.content,
                    category=entry.category
                )
                result["facts_saved"] += 1

        for key, value in context_memory._user_preferences.items():
            self.decision_store.save_preference(key, value)
            result["preferences_saved"] += 1

        result["entries_compacted"] = len(context_memory._entries)
        return result

    def load_session_context(self, project_path: str = ".") -> ContextMemory:
        memory = ContextMemory()

        if not self.decision_store:
            return memory

        facts = self.decision_store.get_project_facts(project_path, limit=10)
        for fact in facts:
            memory.add_project_fact(fact["fact"])

        prefs = self.decision_store.get_all_preferences()
        for key, value in prefs.items():
            memory.add_user_preference(key, value)

        recent_decisions = self.decision_store.get_decisions(limit=5)
        for dec in recent_decisions:
            memory.add_decision(
                decision=dec["decision"],
                reasoning=dec.get("reasoning", ""),
                turn=0
            )

        return memory

    def generate_session_summary(self, context_memory: ContextMemory) -> str:
        parts = []

        if context_memory._decision_log:
            parts.append("## 本次会话决策")
            for d in context_memory._decision_log:
                parts.append(f"- {d['decision']}")

        if context_memory._project_facts:
            parts.append("## 发现的项目信息")
            for f in context_memory._project_facts[-5:]:
                parts.append(f"- {f}")

        return "\n".join(parts) if parts else "无显著内容可总结"
