"""memory module"""
