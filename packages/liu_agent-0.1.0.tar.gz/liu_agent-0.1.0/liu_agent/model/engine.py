"""
模型引擎层
支持 OpenAI、Anthropic、本地模型，以及模拟模式（用于测试）
特性：错误重试、指数退避、模型回退、Token 计费跟踪
"""
import os
import json
import re
import time
import logging
from typing import Dict, List, Any, Optional, AsyncGenerator
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
import asyncio

logger = logging.getLogger(__name__)


@dataclass
class RetryConfig:
    max_retries: int = 3
    base_delay: float = 1.0
    max_delay: float = 60.0
    exponential_base: float = 2.0
    retryable_status_codes: tuple = (429, 500, 502, 503, 504)


class BaseModelEngine(ABC):
    """模型引擎抽象基类"""

    @abstractmethod
    async def generate(
        self,
        messages: List[Dict],
        tools: List[Dict] = None,
        system_prompt: str = None
    ) -> Dict:
        pass

    @abstractmethod
    def estimate_tokens(self, text: str) -> int:
        pass


class MockModelEngine(BaseModelEngine):
    """模拟模型引擎（用于开发和测试）"""

    def __init__(self, scenario: str = "default"):
        self.scenario = scenario
        self.turn_count = 0
        self._scenarios = {
            "write_file": self._scenario_write_file,
            "edit_file": self._scenario_edit_file,
            "complex_task": self._scenario_complex,
            "default": self._scenario_default
        }

    async def generate(
        self,
        messages: List[Dict],
        tools: List[Dict] = None,
        system_prompt: str = None
    ) -> Dict:
        await asyncio.sleep(0.5)
        self.turn_count += 1
        last_message = messages[-1]["content"] if messages else ""
        handler = self._scenarios.get(self.scenario, self._scenario_default)
        return handler(last_message, tools or [])

    def _scenario_write_file(self, message: str, tools: List[Dict]) -> Dict:
        if self.turn_count == 1:
            return {
                "thought": "用户要求创建一个 Python 脚本。我需要先查看当前目录结构，然后创建文件。",
                "tool_calls": [
                    {"name": "list_directory", "parameters": {"path": "."}, "is_read_only": True}
                ],
                "token_usage": {"prompt": 150, "completion": 80, "total": 230}
            }
        elif self.turn_count == 2:
            return {
                "thought": "目录已确认。现在我将创建 hello.py 文件，包含一个简单的问候函数。",
                "tool_calls": [
                    {
                        "name": "write_file",
                        "parameters": {
                            "path": "hello.py",
                            "content": "def greet(name):\n    return f'Hello, {name}!'\n\nif __name__ == '__main__':\n    print(greet('World'))\n"
                        },
                        "is_read_only": False
                    }
                ],
                "token_usage": {"prompt": 200, "completion": 120, "total": 320}
            }
        else:
            return {
                "thought": "文件已成功创建。任务完成！",
                "tool_calls": [],
                "token_usage": {"prompt": 100, "completion": 50, "total": 150}
            }

    def _scenario_edit_file(self, message: str, tools: List[Dict]) -> Dict:
        if self.turn_count == 1:
            return {
                "thought": "用户要求修改 hello.py，添加一个 goodbye 函数。我先读取现有文件。",
                "tool_calls": [
                    {"name": "read_file", "parameters": {"path": "hello.py"}, "is_read_only": True}
                ],
                "token_usage": {"prompt": 120, "completion": 60, "total": 180}
            }
        elif self.turn_count == 2:
            return {
                "thought": "已读取文件。现在添加 goodbye 函数。",
                "tool_calls": [
                    {
                        "name": "edit_file",
                        "parameters": {
                            "path": "hello.py",
                            "old_string": "if __name__ == '__main__':",
                            "new_string": "def goodbye(name):\n    return f'Goodbye, {name}!'\n\nif __name__ == '__main__':"
                        },
                        "is_read_only": False
                    }
                ],
                "token_usage": {"prompt": 180, "completion": 100, "total": 280}
            }
        else:
            return {
                "thought": "修改完成。hello.py 现在包含 greet 和 goodbye 两个函数。",
                "tool_calls": [],
                "token_usage": {"prompt": 80, "completion": 40, "total": 120}
            }

    def _scenario_complex(self, message: str, tools: List[Dict]) -> Dict:
        if self.turn_count == 1:
            return {
                "thought": "这是一个复杂任务：创建一个 Web API。我需要先了解项目结构，然后设计架构。",
                "tool_calls": [
                    {"name": "list_directory", "parameters": {"path": "."}, "is_read_only": True},
                    {"name": "search_code", "parameters": {"query": "app", "path": "."}, "is_read_only": True}
                ],
                "token_usage": {"prompt": 200, "completion": 100, "total": 300}
            }
        elif self.turn_count == 2:
            return {
                "thought": "项目结构已了解。我将创建 Flask API，包含用户注册和登录功能。先创建 requirements.txt。",
                "tool_calls": [
                    {
                        "name": "write_file",
                        "parameters": {
                            "path": "requirements.txt",
                            "content": "flask==2.3.0\nflask-restful==0.3.10\n"
                        },
                        "is_read_only": False
                    }
                ],
                "token_usage": {"prompt": 250, "completion": 150, "total": 400}
            }
        elif self.turn_count == 3:
            return {
                "thought": "现在创建主应用文件 app.py。",
                "tool_calls": [
                    {
                        "name": "write_file",
                        "parameters": {
                            "path": "app.py",
                            "content": "from flask import Flask, request, jsonify\n\napp = Flask(__name__)\n\n@app.route('/api/register', methods=['POST'])\ndef register():\n    data = request.get_json()\n    return jsonify({'message': 'User registered', 'username': data.get('username')})\n\n@app.route('/api/login', methods=['POST'])\ndef login():\n    data = request.get_json()\n    return jsonify({'message': 'Login successful', 'token': 'mock-token-123'})\n\nif __name__ == '__main__':\n    app.run(debug=True)\n"
                        },
                        "is_read_only": False
                    }
                ],
                "token_usage": {"prompt": 300, "completion": 200, "total": 500}
            }
        elif self.turn_count == 4:
            return {
                "thought": "应用已创建。现在创建测试文件验证功能。",
                "tool_calls": [
                    {
                        "name": "write_file",
                        "parameters": {
                            "path": "test_app.py",
                            "content": "import pytest\nfrom app import app\n\ndef test_register():\n    client = app.test_client()\n    response = client.post('/api/register', json={'username': 'test'})\n    assert response.status_code == 200\n\ndef test_login():\n    client = app.test_client()\n    response = client.post('/api/login', json={'username': 'test'})\n    assert response.status_code == 200\n"
                        },
                        "is_read_only": False
                    }
                ],
                "token_usage": {"prompt": 250, "completion": 180, "total": 430}
            }
        elif self.turn_count == 5:
            return {
                "thought": "运行测试验证功能是否正确。",
                "tool_calls": [
                    {"name": "run_tests", "parameters": {"test_path": "test_app.py", "framework": "pytest"}, "is_read_only": True}
                ],
                "token_usage": {"prompt": 150, "completion": 80, "total": 230}
            }
        else:
            return {
                "thought": "所有测试通过！Web API 项目创建完成，包含：\n1. requirements.txt - 依赖管理\n2. app.py - Flask API（注册/登录）\n3. test_app.py - 单元测试\n",
                "tool_calls": [],
                "token_usage": {"prompt": 100, "completion": 60, "total": 160}
            }

    def _scenario_default(self, message: str, tools: List[Dict]) -> Dict:
        return {
            "thought": f"收到消息: {message[:50]}... 我将分析任务并执行相应操作。",
            "tool_calls": [],
            "token_usage": {"prompt": 100, "completion": 50, "total": 150}
        }

    def estimate_tokens(self, text: str) -> int:
        return len(text) // 3


def _calculate_retry_delay(attempt: int, config: RetryConfig) -> float:
    delay = config.base_delay * (config.exponential_base ** attempt)
    return min(delay, config.max_delay)


class OpenAIEngine(BaseModelEngine):
    """OpenAI GPT 引擎，支持重试和回退"""

    def __init__(
        self,
        api_key: str = None,
        model: str = "gpt-4",
        fallback_model: str = "gpt-3.5-turbo",
        retry_config: RetryConfig = None
    ):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.model = model
        self.fallback_model = fallback_model
        self.retry_config = retry_config or RetryConfig()
        self._client = None
        self._total_tokens_used = 0
        self._call_count = 0

    def _get_client(self):
        if self._client is None:
            try:
                import openai
                self._client = openai.AsyncOpenAI(api_key=self.api_key)
            except ImportError:
                raise ImportError("请安装 openai: pip install openai")
        return self._client

    async def generate(
        self,
        messages: List[Dict],
        tools: List[Dict] = None,
        system_prompt: str = None
    ) -> Dict:
        models_to_try = [self.model]
        if self.fallback_model and self.fallback_model != self.model:
            models_to_try.append(self.fallback_model)

        last_error = None
        for model in models_to_try:
            for attempt in range(self.retry_config.max_retries):
                try:
                    result = await self._call_api(model, messages, tools, system_prompt)
                    self._call_count += 1
                    self._total_tokens_used += result.get("token_usage", {}).get("total", 0)
                    return result
                except Exception as e:
                    last_error = e
                    should_retry = self._is_retryable(e)
                    if not should_retry or attempt == self.retry_config.max_retries - 1:
                        logger.warning(f"[OpenAI] 模型 {model} 调用失败 (attempt {attempt+1}): {e}")
                        break

                    delay = _calculate_retry_delay(attempt, self.retry_config)
                    logger.info(f"[OpenAI] 重试 {attempt+1}/{self.retry_config.max_retries}, 等待 {delay:.1f}s...")
                    await asyncio.sleep(delay)

        raise last_error or RuntimeError("OpenAI API 调用失败")

    async def _call_api(
        self,
        model: str,
        messages: List[Dict],
        tools: List[Dict],
        system_prompt: str
    ) -> Dict:
        client = self._get_client()

        openai_tools = []
        if tools:
            for tool in tools:
                params = tool.get("parameters", {"type": "object", "properties": {}})
                if "required" not in params and "properties" in params:
                    params["required"] = []
                openai_tools.append({
                    "type": "function",
                    "function": {
                        "name": tool["name"],
                        "description": tool.get("description", ""),
                        "parameters": params
                    }
                })

        msgs = []
        if system_prompt:
            msgs.append({"role": "system", "content": system_prompt})
        msgs.extend(messages)

        kwargs = {
            "model": model,
            "messages": msgs,
            "temperature": 0.2
        }
        if openai_tools:
            kwargs["tools"] = openai_tools
            kwargs["tool_choice"] = "auto"

        response = await client.chat.completions.create(**kwargs)

        choice = response.choices[0]
        message = choice.message

        result = {
            "thought": message.content or "",
            "tool_calls": [],
            "token_usage": {
                "prompt": response.usage.prompt_tokens if response.usage else 0,
                "completion": response.usage.completion_tokens if response.usage else 0,
                "total": response.usage.total_tokens if response.usage else 0
            }
        }

        if message.tool_calls:
            for tc in message.tool_calls:
                try:
                    params = json.loads(tc.function.arguments) if tc.function.arguments else {}
                except json.JSONDecodeError:
                    params = {}
                result["tool_calls"].append({
                    "name": tc.function.name,
                    "parameters": params,
                    "id": tc.id
                })

        return result

    def _is_retryable(self, error: Exception) -> bool:
        error_str = str(error).lower()
        if "rate_limit" in error_str or "429" in error_str:
            return True
        if "timeout" in error_str:
            return True
        if any(str(code) in error_str for code in self.retry_config.retryable_status_codes):
            return True
        if "connection" in error_str:
            return True
        return False

    @property
    def usage_stats(self) -> Dict:
        return {
            "total_tokens": self._total_tokens_used,
            "call_count": self._call_count
        }

    def estimate_tokens(self, text: str) -> int:
        try:
            import tiktoken
            enc = tiktoken.encoding_for_model(self.model)
            return len(enc.encode(text))
        except Exception:
            return len(text) // 3


class AnthropicEngine(BaseModelEngine):
    """Anthropic Claude 引擎，支持重试和回退"""

    def __init__(
        self,
        api_key: str = None,
        model: str = "claude-3-sonnet-20240229",
        fallback_model: str = "claude-3-haiku-20240307",
        retry_config: RetryConfig = None
    ):
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        self.model = model
        self.fallback_model = fallback_model
        self.retry_config = retry_config or RetryConfig()
        self._client = None
        self._total_tokens_used = 0
        self._call_count = 0

    def _get_client(self):
        if self._client is None:
            try:
                import anthropic
                self._client = anthropic.AsyncAnthropic(api_key=self.api_key)
            except ImportError:
                raise ImportError("请安装 anthropic: pip install anthropic")
        return self._client

    async def generate(
        self,
        messages: List[Dict],
        tools: List[Dict] = None,
        system_prompt: str = None
    ) -> Dict:
        models_to_try = [self.model]
        if self.fallback_model and self.fallback_model != self.model:
            models_to_try.append(self.fallback_model)

        last_error = None
        for model in models_to_try:
            for attempt in range(self.retry_config.max_retries):
                try:
                    result = await self._call_api(model, messages, tools, system_prompt)
                    self._call_count += 1
                    self._total_tokens_used += result.get("token_usage", {}).get("total", 0)
                    return result
                except Exception as e:
                    last_error = e
                    should_retry = self._is_retryable(e)
                    if not should_retry or attempt == self.retry_config.max_retries - 1:
                        logger.warning(f"[Anthropic] 模型 {model} 调用失败 (attempt {attempt+1}): {e}")
                        break

                    delay = _calculate_retry_delay(attempt, self.retry_config)
                    logger.info(f"[Anthropic] 重试 {attempt+1}/{self.retry_config.max_retries}, 等待 {delay:.1f}s...")
                    await asyncio.sleep(delay)

        raise last_error or RuntimeError("Anthropic API 调用失败")

    async def _call_api(
        self,
        model: str,
        messages: List[Dict],
        tools: List[Dict],
        system_prompt: str
    ) -> Dict:
        client = self._get_client()

        anthropic_tools = []
        if tools:
            for tool in tools:
                params = tool.get("parameters", {"type": "object", "properties": {}})
                if "required" not in params and "properties" in params:
                    params["required"] = []
                anthropic_tools.append({
                    "name": tool["name"],
                    "description": tool.get("description", ""),
                    "input_schema": params
                })

        kwargs = {
            "model": model,
            "messages": messages,
            "max_tokens": 4096,
            "temperature": 0.2
        }
        if system_prompt:
            kwargs["system"] = system_prompt
        if anthropic_tools:
            kwargs["tools"] = anthropic_tools

        response = await client.messages.create(**kwargs)

        content = response.content
        thought = ""
        tool_calls = []

        for block in content:
            if block.type == "text":
                thought += block.text
            elif block.type == "tool_use":
                tool_calls.append({
                    "name": block.name,
                    "parameters": block.input,
                    "id": block.id
                })

        return {
            "thought": thought,
            "tool_calls": tool_calls,
            "token_usage": {
                "prompt": response.usage.input_tokens,
                "completion": response.usage.output_tokens,
                "total": response.usage.input_tokens + response.usage.output_tokens
            }
        }

    def _is_retryable(self, error: Exception) -> bool:
        error_str = str(error).lower()
        if "rate_limit" in error_str or "429" in error_str:
            return True
        if "timeout" in error_str:
            return True
        if "overloaded" in error_str or "529" in error_str:
            return True
        if "connection" in error_str:
            return True
        if any(str(code) in error_str for code in self.retry_config.retryable_status_codes):
            return True
        return False

    @property
    def usage_stats(self) -> Dict:
        return {
            "total_tokens": self._total_tokens_used,
            "call_count": self._call_count
        }

    def estimate_tokens(self, text: str) -> int:
        return len(text) // 3


class FallbackEngine(BaseModelEngine):
    """多模型回退引擎：依次尝试多个模型"""

    def __init__(self, engines: List[BaseModelEngine]):
        self.engines = engines

    async def generate(
        self,
        messages: List[Dict],
        tools: List[Dict] = None,
        system_prompt: str = None
    ) -> Dict:
        if not self.engines:
            raise RuntimeError("没有可用的模型引擎")

        last_error = None
        for i, engine in enumerate(self.engines):
            try:
                logger.info(f"[FallbackEngine] 尝试引擎 {i+1}/{len(self.engines)}: {type(engine).__name__}")
                return await engine.generate(messages, tools, system_prompt)
            except Exception as e:
                last_error = e
                logger.warning(f"[FallbackEngine] 引擎 {type(engine).__name__} 失败: {e}")
                continue

        raise last_error or RuntimeError("所有模型引擎均失败")

    def estimate_tokens(self, text: str) -> int:
        if self.engines:
            return self.engines[0].estimate_tokens(text)
        return len(text) // 3
