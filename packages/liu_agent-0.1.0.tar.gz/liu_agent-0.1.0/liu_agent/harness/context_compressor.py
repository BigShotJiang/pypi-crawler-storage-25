"""
4层上下文压缩器
基于 Claude Code 的压缩策略 + Hermes 的决策摘要
"""
import json
from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class CompressionConfig:
    snip_threshold: int = 4000
    microcompact_threshold: int = 8000
    collapse_threshold: int = 12000
    autocompact_threshold: int = 16000
    preserve_recent_turns: int = 5


class ContextCompressor:
    """
    4层上下文压缩策略

    Layer 1 - Snip: 截断过长的工具输出
    Layer 2 - Microcompact: 提取关键行（错误、摘要）
    Layer 3 - Collapse: 合并早期历史为决策摘要
    Layer 4 - Autocompact: LLM 生成摘要替代原始内容
    """

    def __init__(self, config: CompressionConfig = None, summary_model=None):
        self.config = config or CompressionConfig()
        self._summary_model = summary_model

    def compress(self, messages: List[Dict], max_tokens: int) -> List[Dict]:
        current_tokens = self._estimate_tokens(messages)

        if current_tokens <= max_tokens:
            return messages

        messages = self._snip_long_outputs(messages)
        current_tokens = self._estimate_tokens(messages)
        if current_tokens <= max_tokens:
            return messages

        messages = self._microcompact(messages)
        current_tokens = self._estimate_tokens(messages)
        if current_tokens <= max_tokens:
            return messages

        messages = self._collapse_history(messages)
        current_tokens = self._estimate_tokens(messages)
        if current_tokens <= max_tokens:
            return messages

        messages = self._autocompact(messages, max_tokens)
        return messages

    def _snip_long_outputs(self, messages: List[Dict]) -> List[Dict]:
        result = []
        for msg in messages:
            if msg.get("role") == "tool" or "观察结果" in msg.get("content", ""):
                content = msg.get("content", "")
                if len(content) > self.config.snip_threshold:
                    head = content[:1000]
                    tail = content[-1000:]
                    msg = dict(msg)
                    msg["content"] = (
                        f"{head}\n"
                        f"... [{len(content)} 字符已截断] ...\n"
                        f"{tail}"
                    )
            result.append(msg)
        return result

    def _microcompact(self, messages: List[Dict]) -> List[Dict]:
        KEYWORDS = ["Error", "FAIL", "失败", "错误", "Summary", "总结", "===", "---",
                     "PASSED", "SUCCESS", "成功", "assert", "Exception", "WARNING",
                     "Traceback", "NameError", "TypeError", "ValueError", "ImportError"]

        result = []
        for msg in messages:
            if msg.get("role") == "tool" or "观察结果" in msg.get("content", ""):
                content = msg.get("content", "")
                if len(content) > self.config.microcompact_threshold:
                    lines = content.split("\n")
                    key_lines = []
                    for line in lines:
                        if any(kw in line for kw in KEYWORDS):
                            key_lines.append(line)

                    header = lines[:5] if len(lines) > 5 else lines
                    footer = lines[-3:] if len(lines) > 8 else []
                    compacted = "\n".join(header + ["... (关键行) ..."] + key_lines[:20] + footer)

                    msg = dict(msg)
                    msg["content"] = compacted
            result.append(msg)
        return result

    def _collapse_history(self, messages: List[Dict]) -> List[Dict]:
        system_msgs = [m for m in messages if m.get("role") == "system"]
        user_initial = []
        if len(messages) > 1 and messages[1].get("role") == "user":
            user_initial = [messages[1]]
        history_start = len(system_msgs) + len(user_initial)
        history = messages[history_start:]

        preserve = self.config.preserve_recent_turns * 2

        if len(history) > preserve:
            early_history = history[:-preserve]
            recent_history = history[-preserve:]

            summary = self._generate_decision_summary(early_history)

            return system_msgs + user_initial + [summary] + recent_history

        return messages

    def _generate_decision_summary(self, history: List[Dict]) -> Dict:
        decisions = []
        facts = []
        tool_calls_summary = []

        for msg in history:
            content = msg.get("content", "")
            role = msg.get("role", "")

            if role == "assistant":
                if any(kw in content for kw in ["决定", "计划", "步骤", "将", "需要"]):
                    decisions.append(content[:200])
                if "tool_call" in content or "```" in content:
                    tool_calls_summary.append(content[:100])
            elif role in ("tool", "user") and any(kw in content for kw in ["成功", "失败", "Error", "完成"]):
                facts.append(content[:150])

        summary_text = "【历史摘要】\n"
        if decisions:
            summary_text += "关键决策:\n" + "\n".join(f"- {d}" for d in decisions[:5]) + "\n"
        if facts:
            summary_text += "关键结果:\n" + "\n".join(f"- {f}" for f in facts[:5]) + "\n"
        if tool_calls_summary:
            summary_text += "工具调用摘要:\n" + "\n".join(f"- {t}" for t in tool_calls_summary[:3]) + "\n"
        if not decisions and not facts and not tool_calls_summary:
            summary_text += f"共 {len(history)} 条历史消息已压缩。\n"

        return {
            "role": "user",
            "content": summary_text
        }

    def _autocompact(self, messages: List[Dict], max_tokens: int) -> List[Dict]:
        if self._summary_model:
            try:
                return self._llm_summarize(messages, max_tokens)
            except Exception:
                pass

        system_msgs = [m for m in messages if m.get("role") == "system"]
        user_initial = [m for m in messages if m.get("role") == "user" and "任务:" in m.get("content", "")]

        other_msgs = [m for m in messages if m not in system_msgs and m not in user_initial]
        recent = other_msgs[-6:] if len(other_msgs) > 6 else other_msgs

        return system_msgs + user_initial + recent

    def _llm_summarize(self, messages: List[Dict], max_tokens: int) -> List[Dict]:
        system_msgs = [m for m in messages if m.get("role") == "system"]
        user_initial = [m for m in messages if m.get("role") == "user" and "任务:" in m.get("content", "")]

        other_msgs = [m for m in messages if m not in system_msgs and m not in user_initial]
        preserve_count = max(4, self.config.preserve_recent_turns * 2)
        recent = other_msgs[-preserve_count:] if len(other_msgs) > preserve_count else other_msgs
        to_summarize = other_msgs[:-preserve_count] if len(other_msgs) > preserve_count else []

        if not to_summarize:
            return system_msgs + user_initial + recent

        summary_text = "以下是之前的对话历史，请总结关键决策和当前状态：\n\n"
        for msg in to_summarize:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")[:500]
            summary_text += f"[{role}]: {content}\n---\n"

        import asyncio
        if asyncio.iscoroutinefunction(self._summary_model.generate):
            loop = asyncio.get_event_loop()
            if loop.is_running():
                summary_result = {"thought": summary_text[:1000]}
            else:
                summary_result = loop.run_until_complete(
                    self._summary_model.generate(
                        messages=[{"role": "user", "content": summary_text}],
                        system_prompt="请用中文简洁总结以下对话中的关键决策、执行结果和当前状态。保留重要细节。"
                    )
                )
        else:
            summary_result = self._summary_model.generate(
                messages=[{"role": "user", "content": summary_text}]
            )

        summary_content = summary_result.get("thought", summary_text[:1000])

        summary_msg = {
            "role": "user",
            "content": f"【LLM 压缩摘要】\n{summary_content}"
        }

        return system_msgs + user_initial + [summary_msg] + recent

    def _estimate_tokens(self, messages: List[Dict]) -> int:
        total = 0
        for msg in messages:
            content = msg.get("content", "")
            total += len(content) // 3 + 50
        return total

    def set_summary_model(self, model):
        self._summary_model = model
