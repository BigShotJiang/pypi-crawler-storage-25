"""
Harness Core - ReAct 控制循环实现
基于 Anthropic 的 Harness 架构 + Claude Code 并发优化 + Hermes 懒加载
"""
import asyncio
import uuid
import json
import time
from typing import AsyncGenerator, List, Dict, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AgentState(Enum):
    """Agent 执行状态机"""
    IDLE = auto()
    INITIALIZING = auto()
    THINKING = auto()
    TOOL_CALLING = auto()
    EXECUTING = auto()
    OBSERVING = auto()
    COMPLETED = auto()
    ERROR = auto()
    PAUSED = auto()


class AgentError(Exception):
    """Agent 基础异常"""
    pass


class TokenBudgetExceeded(AgentError):
    """Token 预算超限"""
    pass


class MaxTurnsExceeded(AgentError):
    """最大轮次超限"""
    pass


class PermissionDenied(AgentError):
    """权限不足"""
    pass


@dataclass
class ToolCall:
    """工具调用定义"""
    id: str
    name: str
    parameters: Dict[str, Any]
    server: str = "default"
    is_read_only: bool = True

    @classmethod
    def from_dict(cls, data: Dict) -> 'ToolCall':
        return cls(
            id=data.get("id", str(uuid.uuid4())[:8]),
            name=data["name"],
            parameters=data.get("parameters", {}),
            server=data.get("server", "default"),
            is_read_only=data.get("is_read_only", True)
        )


@dataclass
class ToolResult:
    """工具执行结果"""
    call_id: str
    success: bool
    output: str
    error: Optional[str] = None
    execution_time: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Turn:
    """单轮交互记录"""
    turn_id: int
    thought: str
    tool_calls: List[ToolCall]
    tool_results: List[ToolResult]
    token_usage: Dict[str, int] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    state: AgentState = AgentState.COMPLETED

    def to_dict(self) -> Dict:
        return {
            "turn_id": self.turn_id,
            "thought": self.thought,
            "tool_calls": [{"name": tc.name, "params": tc.parameters} for tc in self.tool_calls],
            "tool_results": [{"success": tr.success, "output": tr.output[:200]} for tr in self.tool_results],
            "token_usage": self.token_usage,
            "timestamp": self.timestamp.isoformat(),
            "state": self.state.name
        }


@dataclass
class Session:
    """会话管理 - 持久化事件流"""
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: datetime = field(default_factory=datetime.now)
    turns: List[Turn] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def append_turn(self, turn: Turn):
        self.turns.append(turn)

    def get_token_usage(self) -> int:
        return sum(
            t.token_usage.get("total", 0) for t in self.turns
        )

    def get_last_n_turns(self, n: int) -> List[Turn]:
        return self.turns[-n:] if n > 0 else []

    def to_dict(self) -> Dict:
        return {
            "session_id": self.session_id,
            "created_at": self.created_at.isoformat(),
            "turn_count": len(self.turns),
            "total_tokens": self.get_token_usage(),
            "turns": [t.to_dict() for t in self.turns]
        }


class PermissionLevel(Enum):
    """权限等级 - 5层防御"""
    AUTO_READ = "auto_read"           # 自动执行读操作
    AUTO_WRITE = "auto_write"         # 自动执行工作区写操作
    ASK_WRITE = "ask_write"           # 写操作需确认
    ASK_SYSTEM = "ask_system"         # 系统级操作需确认
    BLOCKED = "blocked"              # 完全禁止


class PermissionManager:
    """权限管理器"""

    READ_ONLY_TOOLS = {"read_file", "search_code", "list_directory", "git_status", "git_log"}
    WRITE_TOOLS = {"write_file", "edit_file", "delete_file", "git_commit", "git_push"}
    SYSTEM_TOOLS = {"execute_shell", "install_package", "docker_run"}

    def __init__(self, level: PermissionLevel = PermissionLevel.ASK_WRITE):
        self.level = level
        self.approved_operations: set = set()
        self.blocked_operations: set = set()

    def check(self, tool_call: ToolCall) -> bool:
        """检查工具调用权限"""
        if self.level == PermissionLevel.BLOCKED:
            return False

        if tool_call.name in self.READ_ONLY_TOOLS:
            return True

        if self.level == PermissionLevel.AUTO_READ:
            return False

        if self.level == PermissionLevel.AUTO_WRITE:
            if tool_call.name in self.WRITE_TOOLS:
                return True
            return tool_call.name not in self.SYSTEM_TOOLS

        if self.level == PermissionLevel.ASK_WRITE:
            if tool_call.name in self.WRITE_TOOLS or tool_call.name in self.SYSTEM_TOOLS:
                op_key = f"{tool_call.name}:{json.dumps(tool_call.parameters, sort_keys=True)}"
                return op_key in self.approved_operations
            return True

        if self.level == PermissionLevel.ASK_SYSTEM:
            if tool_call.name in self.SYSTEM_TOOLS:
                op_key = f"{tool_call.name}:{json.dumps(tool_call.parameters, sort_keys=True)}"
                return op_key in self.approved_operations
            return True

        return False

    def approve(self, tool_call: ToolCall):
        """批准操作"""
        op_key = f"{tool_call.name}:{json.dumps(tool_call.parameters, sort_keys=True)}"
        self.approved_operations.add(op_key)

    def block(self, tool_call: ToolCall):
        """阻止操作"""
        op_key = f"{tool_call.name}:{json.dumps(tool_call.parameters, sort_keys=True)}"
        self.blocked_operations.add(op_key)


class Harness:
    """
    Harness 核心 - Agent 运行时

    职责：
    1. 持续调用模型（维持 ReAct 循环）
    2. 路由工具调用（并发安全执行）
    3. 管理会话状态（持久化事件流）
    4. 控制 Token 预算和轮次限制
    """

    def __init__(
        self,
        model_engine,
        tool_registry,
        sandbox,
        context_compressor=None,
        permission_manager=None,
        max_turns: int = 50,
        token_budget: int = 200000,
        enable_speculation: bool = True,
        enable_concurrent_reads: bool = True
    ):
        self.model = model_engine
        self.tools = tool_registry
        self.sandbox = sandbox
        self.compressor = context_compressor
        self.permission = permission_manager or PermissionManager()

        self.max_turns = max_turns
        self.token_budget = token_budget
        self.enable_speculation = enable_speculation
        self.enable_concurrent_reads = enable_concurrent_reads

        self.state = AgentState.IDLE
        self.session = Session()
        self._current_task = ""
        self._interrupt_requested = False

        # 性能统计
        self.stats = {
            "total_thinking_time": 0,
            "total_execution_time": 0,
            "speculative_hits": 0,
            "speculative_misses": 0
        }

    async def run(self, task: str, context: Dict[str, Any] = None) -> AsyncGenerator[Turn, None]:
        """
        核心 ReAct 循环

        Args:
            task: 用户任务描述
            context: 额外上下文（如代码库结构、历史任务等）

        Yields:
            Turn: 每轮交互记录
        """
        self.state = AgentState.INITIALIZING
        self._current_task = task
        self._interrupt_requested = False

        # 初始化上下文
        messages = await self._bootstrap_context(task, context)

        logger.info(f"[Harness] 开始执行任务: {task[:100]}...")

        for turn_num in range(self.max_turns):
            if self._interrupt_requested:
                logger.info("[Harness] 收到中断请求")
                break

            # 1. 检查 Token 预算
            current_tokens = self.session.get_token_usage()
            if current_tokens >= self.token_budget:
                raise TokenBudgetExceeded(
                    f"Token 预算已用完: {current_tokens}/{self.token_budget}"
                )

            # 2. 上下文压缩（如果启用）
            if self.compressor:
                messages = self.compressor.compress(
                    messages, 
                    max_tokens=self.token_budget - current_tokens
                )

            # 3. 调用模型生成 Thought + Actions
            self.state = AgentState.THINKING
            think_start = time.time()

            try:
                response = await self._generate_with_model(messages, turn_num)
                self.stats["total_thinking_time"] += time.time() - think_start
            except Exception as e:
                logger.error(f"[Harness] 模型调用失败: {e}")
                self.state = AgentState.ERROR
                raise

            # 4. 解析工具调用
            tool_calls = self._parse_tool_calls(response)

            if not tool_calls:
                # 没有工具调用，任务完成
                self.state = AgentState.COMPLETED
                turn = Turn(
                    turn_id=turn_num,
                    thought=response.get("thought", ""),
                    tool_calls=[],
                    tool_results=[],
                    token_usage=response.get("token_usage", {}),
                    state=AgentState.COMPLETED
                )
                self.session.append_turn(turn)
                yield turn
                break

            # 5. 并发安全执行工具
            self.state = AgentState.EXECUTING
            exec_start = time.time()

            try:
                tool_results = await self._execute_tool_calls(tool_calls)
                self.stats["total_execution_time"] += time.time() - exec_start
            except Exception as e:
                logger.error(f"[Harness] 工具执行失败: {e}")
                self.state = AgentState.ERROR
                raise

            # 6. 构建观察结果
            self.state = AgentState.OBSERVING
            observations = self._build_observations(tool_results)

            # 7. 构建 Turn 记录
            turn = Turn(
                turn_id=turn_num,
                thought=response.get("thought", ""),
                tool_calls=tool_calls,
                tool_results=tool_results,
                token_usage=response.get("token_usage", {}),
                state=AgentState.OBSERVING
            )
            self.session.append_turn(turn)
            yield turn

            # 8. 更新消息历史
            messages = self._update_messages(messages, response, observations)

            logger.info(f"[Harness] 完成第 {turn_num + 1} 轮")

        else:
            raise MaxTurnsExceeded(f"达到最大轮次限制: {self.max_turns}")

        logger.info(f"[Harness] 任务完成，共 {len(self.session.turns)} 轮")

    async def _generate_with_model(self, messages: List[Dict], turn_num: int) -> Dict:
        """调用模型生成响应"""
        # 获取活跃工具（懒加载）
        active_tools = self.tools.get_active_tools(
            context=messages[-1].get("content", "") if messages else ""
        )

        # 调用模型
        response = await self.model.generate(
            messages=messages,
            tools=active_tools,
            system_prompt=self._get_system_prompt(turn_num)
        )

        return response

    async def _execute_tool_calls(self, tool_calls: List[ToolCall]) -> List[ToolResult]:
        """
        并发安全执行工具调用
        策略：读操作并行，写操作串行
        """
        # 权限检查
        for tc in tool_calls:
            if not self.permission.check(tc):
                raise PermissionDenied(f"权限不足: {tc.name}")

        # 分离读写操作
        read_calls = [tc for tc in tool_calls if tc.is_read_only]
        write_calls = [tc for tc in tool_calls if not tc.is_read_only]

        results = []

        # 并行执行读操作
        if read_calls and self.enable_concurrent_reads:
            logger.info(f"[Harness] 并行执行 {len(read_calls)} 个读操作")
            read_tasks = [
                self._execute_single_tool(tc) for tc in read_calls
            ]
            read_results = await asyncio.gather(*read_tasks, return_exceptions=True)
            results.extend(self._handle_results(read_calls, read_results))
        elif read_calls:
            for tc in read_calls:
                result = await self._execute_single_tool(tc)
                results.append(result)

        # 串行执行写操作（保证事务性）
        if write_calls:
            logger.info(f"[Harness] 串行执行 {len(write_calls)} 个写操作")
            for tc in write_calls:
                result = await self._execute_single_tool(tc)
                results.append(result)

        return results

    async def _execute_single_tool(self, tool_call: ToolCall) -> ToolResult:
        """执行单个工具调用"""
        start_time = time.time()

        try:
            # 通过 Tool Registry 路由到具体实现
            result = await self.tools.execute(tool_call, sandbox=self.sandbox)

            return ToolResult(
                call_id=tool_call.id,
                success=True,
                output=str(result),
                execution_time=time.time() - start_time
            )
        except Exception as e:
            logger.error(f"[Harness] 工具执行错误 {tool_call.name}: {e}")
            return ToolResult(
                call_id=tool_call.id,
                success=False,
                output="",
                error=str(e),
                execution_time=time.time() - start_time
            )

    def _parse_tool_calls(self, response: Dict) -> List[ToolCall]:
        """解析模型响应中的工具调用"""
        tool_calls = []

        raw_calls = response.get("tool_calls", [])
        for call in raw_calls:
            tool_calls.append(ToolCall.from_dict(call))

        return tool_calls

    def _build_observations(self, results: List[ToolResult]) -> str:
        """构建观察结果文本"""
        observations = []
        for result in results:
            if result.success:
                observations.append(f"[成功] 输出:\n{result.output}")
            else:
                observations.append(f"[失败] 错误:\n{result.error}")
        return "\n\n".join(observations)

    async def _bootstrap_context(self, task: str, extra_context: Dict = None) -> List[Dict]:
        """初始化上下文消息"""
        messages = []

        # 系统提示
        system_prompt = self._get_system_prompt(0)
        messages.append({"role": "system", "content": system_prompt})

        # 用户任务
        task_msg = f"任务: {task}"
        if extra_context:
            task_msg += f"\n\n上下文: {json.dumps(extra_context, ensure_ascii=False)}"

        messages.append({"role": "user", "content": task_msg})

        return messages

    def _get_system_prompt(self, turn_num: int) -> str:
        """获取系统提示"""
        return f"""你是一个专业的代码编写 Agent。当前是第 {turn_num + 1} 轮。

## 工作原则
1. 先思考，再行动。每轮先输出思考过程，再决定工具调用
2. 复杂任务分解为多个步骤，逐步执行
3. 代码修改前先看现有代码，避免破坏性变更
4. 测试驱动开发：先写测试，再写实现
5. 每次修改后运行测试验证

## 可用工具
- read_file: 读取文件内容
- write_file: 写入文件
- edit_file: 编辑文件（支持搜索替换）
- search_code: 搜索代码
- list_directory: 列出目录
- execute_shell: 执行 shell 命令
- git_status: 查看 git 状态
- git_commit: 提交代码
- run_tests: 运行测试

## 输出格式
思考过程后，如果需要工具调用，使用以下格式：
```tool_call
{{"name": "tool_name", "parameters": {{...}}}}
```
"""

    def _update_messages(self, messages: List[Dict], response: Dict, observations: str) -> List[Dict]:
        """更新消息历史"""
        # 添加助手回复
        messages.append({
            "role": "assistant",
            "content": response.get("thought", "")
        })

        # 添加观察结果
        messages.append({
            "role": "user",
            "content": f"观察结果:\n{observations}"
        })

        return messages

    def _handle_results(self, calls: List[ToolCall], results: List[Any]) -> List[ToolResult]:
        """处理批量执行结果"""
        processed = []
        for call, result in zip(calls, results):
            if isinstance(result, Exception):
                processed.append(ToolResult(
                    call_id=call.id,
                    success=False,
                    output="",
                    error=str(result)
                ))
            else:
                processed.append(result)
        return processed

    def interrupt(self):
        """请求中断执行"""
        self._interrupt_requested = True
        logger.info("[Harness] 中断请求已发送")

    def get_session_summary(self) -> Dict:
        """获取会话摘要"""
        return {
            "session": self.session.to_dict(),
            "stats": self.stats,
            "final_state": self.state.name
        }
