"""
多 Agent 编排器
基于 Claude Code 的 Star Topology + Agent 原型模式
"""
import asyncio
import uuid
from typing import Dict, List, Any, Optional, AsyncGenerator
from enum import Enum, auto
from dataclasses import dataclass, field
from liu_agent.harness.core_loop import Harness, Turn, AgentState


class AgentArchetype(Enum):
    """Agent 原型类型"""
    EXPLORER = "explorer"          # 探索代码库结构
    BUILDER = "builder"            # 实现功能
    SURGEON = "surgeon"            # 精准修改
    ORCHESTRATOR = "orchestrator"  # 协调其他 Agent
    TESTER = "tester"              # 测试验证
    REVIEWER = "reviewer"          # 代码审查
    SPECIALIST = "specialist"      # 特定领域专家


@dataclass
class SubTask:
    """子任务定义"""
    task_id: str
    description: str
    archetype: AgentArchetype
    dependencies: List[str] = field(default_factory=list)
    status: str = "pending"
    result: Any = None


class MultiAgentOrchestrator:
    """
    Star Topology 多 Agent 编排器

    架构：
    - 中心协调器（Orchestrator）负责任务分解和调度
    - 子 Agent 执行具体任务，共享 Prompt Cache
    """

    def __init__(self, harness_factory):
        """
        Args:
            harness_factory: Harness 工厂函数，接收配置返回 Harness 实例
        """
        self.harness_factory = harness_factory
        self.agents: Dict[str, Harness] = {}
        self.tasks: Dict[str, SubTask] = {}
        self.shared_cache: Dict[str, Any] = {}

    async def run_task(self, task: str, complexity: str = "auto") -> Dict:
        """
        执行复杂任务

        Args:
            task: 用户任务
            complexity: 复杂度级别 (simple/medium/complex/auto)

        Returns:
            Dict: 执行结果和报告
        """
        if complexity == "auto":
            complexity = self._assess_complexity(task)

        if complexity == "simple":
            return await self._run_simple(task)
        elif complexity == "medium":
            return await self._run_medium(task)
        elif complexity == "complex":
            return await self._run_complex(task)
        else:
            return await self._run_simple(task)

    def _assess_complexity(self, task: str) -> str:
        """评估任务复杂度"""
        # 简单启发式：根据关键词判断
        complex_indicators = ["重构", "架构", "系统", "集成", "迁移", "多模块"]
        medium_indicators = ["添加功能", "修改", "优化", "测试"]

        task_lower = task.lower()

        if any(w in task_lower for w in complex_indicators):
            return "complex"
        elif any(w in task_lower for w in medium_indicators):
            return "medium"
        return "simple"

    async def _run_simple(self, task: str) -> Dict:
        """简单任务：单 Agent 直接执行"""
        harness = self.harness_factory.create()

        results = []
        async for turn in harness.run(task):
            results.append(turn.to_dict())

        return {
            "strategy": "single_agent",
            "results": results,
            "summary": harness.get_session_summary()
        }

    async def _run_medium(self, task: str) -> Dict:
        """中等任务：分解为子任务，顺序执行"""
        # 1. 分解任务
        subtasks = await self._decompose_task(task)

        # 2. 顺序执行
        results = []
        for subtask in subtasks:
            harness = self.harness_factory.create(
                archetype=subtask.archetype
            )

            sub_results = []
            async for turn in harness.run(subtask.description):
                sub_results.append(turn.to_dict())

            subtask.result = {
                "task": subtask.description,
                "results": sub_results,
                "summary": harness.get_session_summary()
            }
            subtask.status = "completed"
            results.append(subtask.result)

        return {
            "strategy": "sequential",
            "subtasks": [st.to_dict() if hasattr(st, 'to_dict') else str(st) for st in subtasks],
            "results": results
        }

    async def _run_complex(self, task: str) -> Dict:
        """
        复杂任务：RFC 驱动的 DAG 执行

        1. 生成 RFC（设计文档）
        2. 构建依赖图
        3. 并行执行无依赖的任务
        """
        # 1. 生成 RFC
        rfc = await self._generate_rfc(task)

        # 2. 构建 DAG
        dag = self._build_dag(rfc)

        # 3. 执行 DAG
        completed_tasks = await self._execute_dag(dag)

        return {
            "strategy": "dag_parallel",
            "rfc": rfc,
            "completed_tasks": completed_tasks,
            "execution_order": dag.get("execution_order", [])
        }

    async def _decompose_task(self, task: str) -> List[SubTask]:
        """分解任务为子任务"""
        # 使用 Orchestrator Agent 分解任务
        orchestrator = self.harness_factory.create(archetype=AgentArchetype.ORCHESTRATOR)

        decompose_prompt = f"""请将以下任务分解为 3-5 个具体子任务。
每个子任务应明确说明：
1. 具体做什么
2. 需要什么 Agent 类型（explorer/builder/tester/reviewer）
3. 依赖哪些前置任务

任务: {task}

请按以下格式输出：
子任务1 [builder]: 具体描述
子任务2 [tester]: 具体描述 (依赖: 子任务1)
..."""

        # 模拟分解结果（实际应调用模型）
        subtasks = [
            SubTask(
                task_id="1",
                description=f"探索现有代码结构，了解项目布局: {task}",
                archetype=AgentArchetype.EXPLORER
            ),
            SubTask(
                task_id="2",
                description=f"实现核心功能: {task}",
                archetype=AgentArchetype.BUILDER,
                dependencies=["1"]
            ),
            SubTask(
                task_id="3",
                description="编写单元测试验证功能",
                archetype=AgentArchetype.TESTER,
                dependencies=["2"]
            ),
            SubTask(
                task_id="4",
                description="代码审查和优化",
                archetype=AgentArchetype.REVIEWER,
                dependencies=["2", "3"]
            )
        ]

        return subtasks

    async def _generate_rfc(self, task: str) -> Dict:
        """生成 RFC 设计文档"""
        return {
            "title": task,
            "overview": "任务概述",
            "components": [
                {"name": "component_1", "description": "组件1"},
                {"name": "component_2", "description": "组件2"}
            ],
            "dependencies": [
                {"from": "component_1", "to": "component_2"}
            ]
        }

    def _build_dag(self, rfc: Dict) -> Dict:
        """构建依赖图"""
        nodes = {}
        deps = {}

        for comp in rfc.get("components", []):
            node_id = comp["name"]
            nodes[node_id] = comp
            deps[node_id] = []

        for dep in rfc.get("dependencies", []):
            if dep["to"] in deps:
                deps[dep["to"]].append(dep["from"])

        return {
            "nodes": nodes,
            "deps": deps,
            "execution_order": []
        }

    async def _execute_dag(self, dag: Dict) -> Dict[str, Any]:
        """并行执行 DAG"""
        completed = set()
        results = {}

        nodes = dag["nodes"]
        deps = dag["deps"]

        while len(completed) < len(nodes):
            # 找到所有可执行的节点
            ready = [
                n for n in nodes 
                if n not in completed 
                and all(d in completed for d in deps.get(n, []))
            ]

            if not ready:
                break

            # 并行执行
            tasks = [self._run_node(n, nodes[n]) for n in ready]
            batch_results = await asyncio.gather(*tasks)

            for node_id, result in zip(ready, batch_results):
                results[node_id] = result
                completed.add(node_id)
                dag["execution_order"].append(node_id)

        return results

    async def _run_node(self, node_id: str, node_config: Dict) -> Dict:
        """执行单个 DAG 节点"""
        harness = self.harness_factory.create()

        task_desc = node_config.get("description", f"执行任务: {node_id}")

        results = []
        async for turn in harness.run(task_desc):
            results.append(turn.to_dict())

        return {
            "node_id": node_id,
            "results": results,
            "summary": harness.get_session_summary()
        }

    async def spawn_agent(
        self, 
        archetype: AgentArchetype,
        task: str,
        tools_subset: List[str] = None
    ) -> str:
        """Fork 一个子 Agent"""
        agent_id = f"{archetype.value}-{uuid.uuid4().hex[:8]}"

        harness = self.harness_factory.create(
            archetype=archetype,
            tools_subset=tools_subset,
            shared_cache=self.shared_cache
        )

        self.agents[agent_id] = harness
        return agent_id
