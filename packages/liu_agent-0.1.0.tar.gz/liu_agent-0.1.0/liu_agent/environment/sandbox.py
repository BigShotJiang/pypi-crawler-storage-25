"""
沙箱环境实现
支持 Docker 隔离 + 本地降级模式
"""
import os
import tempfile
import subprocess
import json
from typing import Dict, List, Any, Optional
from pathlib import Path


class Sandbox:
    """
    隔离执行环境

    权限分级：
    - read-only: 只读文件系统
    - write-workspace: 可读写工作区
    - full-access: 完全访问（含网络和系统）
    """

    PERMISSION_LEVELS = {
        "read-only": {"read": True, "write": False, "network": False, "system": False},
        "write-workspace": {"read": True, "write": True, "network": False, "system": False},
        "full-access": {"read": True, "write": True, "network": True, "system": True}
    }

    def __init__(
        self, 
        workspace_dir: str = None,
        permission: str = "write-workspace",
        use_docker: bool = False,
        docker_image: str = "python:3.11-slim",
        memory_limit: str = "512m",
        cpu_limit: str = "1.0"
    ):
        self.workspace = workspace_dir or tempfile.mkdtemp(prefix="agent_workspace_")
        self.permission = self.PERMISSION_LEVELS.get(permission, self.PERMISSION_LEVELS["write-workspace"])
        self.use_docker = use_docker
        self.docker_image = docker_image
        self.memory_limit = memory_limit
        self.cpu_limit = cpu_limit
        self.container = None
        self._docker_client = None

        # 确保工作区存在
        os.makedirs(self.workspace, exist_ok=True)

        if use_docker:
            self._init_docker()

    def _init_docker(self):
        """初始化 Docker 环境"""
        try:
            import docker
            self._docker_client = docker.from_env()
            # 测试连接
            self._docker_client.ping()
            print(f"[Sandbox] Docker 连接成功")
        except Exception as e:
            print(f"[Sandbox] Docker 不可用，降级到本地模式: {e}")
            self.use_docker = False

    async def start(self):
        """启动沙箱"""
        if not self.use_docker:
            return

        try:
            volumes = {
                os.path.abspath(self.workspace): {
                    "bind": "/workspace",
                    "mode": "rw" if self.permission["write"] else "ro"
                }
            }

            network_mode = "bridge" if self.permission["network"] else "none"

            self.container = self._docker_client.containers.run(
                self.docker_image,
                command="sleep infinity",
                volumes=volumes,
                network_mode=network_mode,
                mem_limit=self.memory_limit,
                cpu_quota=int(float(self.cpu_limit) * 100000),
                detach=True,
                working_dir="/workspace",
                labels={"agent-sandbox": "true"}
            )
            print(f"[Sandbox] Docker 容器启动: {self.container.id[:12]}")
        except Exception as e:
            print(f"[Sandbox] Docker 启动失败，降级到本地模式: {e}")
            self.use_docker = False

    async def execute(self, command: str, timeout: int = 60) -> Dict:
        """
        在沙箱中执行命令

        Returns:
            Dict: {exit_code, stdout, stderr, command}
        """
        if self.use_docker and self.container:
            return await self._execute_docker(command, timeout)
        else:
            return await self._execute_local(command, timeout)

    async def _execute_docker(self, command: str, timeout: int) -> Dict:
        """Docker 执行"""
        try:
            exec_result = self.container.exec_run(
                f"bash -c '{command.replace("'", "'\''")}'",
                workdir="/workspace",
                demux=True
            )

            stdout = exec_result.output[0].decode() if exec_result.output[0] else ""
            stderr = exec_result.output[1].decode() if exec_result.output[1] else ""

            return {
                "exit_code": exec_result.exit_code,
                "stdout": stdout,
                "stderr": stderr,
                "command": command
            }
        except Exception as e:
            return {
                "exit_code": -1,
                "stdout": "",
                "stderr": str(e),
                "command": command
            }

    async def _execute_local(self, command: str, timeout: int) -> Dict:
        """本地执行（降级模式）"""
        try:
            # 在工作区目录执行
            proc = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=self.workspace
            )

            return {
                "exit_code": proc.returncode,
                "stdout": proc.stdout,
                "stderr": proc.stderr,
                "command": command
            }
        except subprocess.TimeoutExpired:
            return {
                "exit_code": -1,
                "stdout": "",
                "stderr": f"执行超时 ({timeout}s)",
                "command": command
            }
        except Exception as e:
            return {
                "exit_code": -1,
                "stdout": "",
                "stderr": str(e),
                "command": command
            }

    async def install_dependencies(self, packages: List[str]) -> Dict:
        """安装依赖包"""
        if not self.permission["write"]:
            return {
                "exit_code": -1,
                "stdout": "",
                "stderr": "沙箱为只读模式，无法安装依赖",
                "command": "pip install"
            }

        package_str = " ".join(packages)
        return await self.execute(f"pip install {package_str}", timeout=120)

    async def snapshot(self) -> str:
        """创建沙箱快照"""
        if self.use_docker and self.container:
            try:
                snapshot = self.container.commit(
                    repository="agent-sandbox",
                    tag=f"snap-{self.container.id[:8]}"
                )
                return snapshot.id
            except Exception as e:
                return f"快照失败: {e}"
        return "本地模式不支持快照"

    def get_workspace_path(self, relative_path: str = "") -> str:
        """获取工作区绝对路径"""
        return os.path.join(self.workspace, relative_path)

    def read_workspace_file(self, relative_path: str) -> str:
        """读取工作区文件"""
        path = self.get_workspace_path(relative_path)
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            return f"读取失败: {e}"

    def write_workspace_file(self, relative_path: str, content: str):
        """写入工作区文件"""
        if not self.permission["write"]:
            raise PermissionError("沙箱为只读模式")

        path = self.get_workspace_path(relative_path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)

    async def cleanup(self):
        """清理沙箱"""
        if self.use_docker and self.container:
            try:
                self.container.stop()
                self.container.remove()
                print(f"[Sandbox] 容器已清理: {self.container.id[:12]}")
            except Exception as e:
                print(f"[Sandbox] 清理容器失败: {e}")

        # 清理临时工作区
        if self.workspace.startswith(tempfile.gettempdir()):
            import shutil
            try:
                shutil.rmtree(self.workspace)
                print(f"[Sandbox] 工作区已清理: {self.workspace}")
            except Exception as e:
                print(f"[Sandbox] 清理工作区失败: {e}")

    def __repr__(self):
        return f"Sandbox(workspace={self.workspace}, docker={self.use_docker}, perm={self.permission})"
