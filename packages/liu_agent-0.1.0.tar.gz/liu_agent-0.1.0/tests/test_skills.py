"""
技能系统测试
- SkillRegistry: 注册、查询、匹配
- SkillDefinition: 元数据
- SkillExecutor: 执行技能链
- 内置技能: architect/developer/reviewer/tester
"""
import pytest
import asyncio
from liu_agent.skills.base import SkillRegistry, SkillDefinition, SkillExecutor, SkillCategory, SkillState
from liu_agent.harness.core_loop import Harness, PermissionLevel, PermissionManager
from liu_agent.tools.tool_registry import ToolRegistry
from liu_agent.model.engine import MockModelEngine
from liu_agent.environment.sandbox import Sandbox
from liu_agent.harness.context_compressor import ContextCompressor


def create_test_harness(system_prompt=None, tool_subset=None, max_turns=3, token_budget=5000):
    tools = ToolRegistry()
    tools.register(name="read_file", description="读取文件", parameters={"type": "object", "properties": {}}, handler=lambda: "content", is_read_only=True)
    tools.register(name="write_file", description="写入文件", parameters={"type": "object", "properties": {}}, handler=lambda: "ok", is_read_only=False)
    tools.register(name="list_directory", description="列出目录", parameters={"type": "object", "properties": {}}, handler=lambda: "dir", is_read_only=True)
    tools.register(name="search_code", description="搜索代码", parameters={"type": "object", "properties": {}}, handler=lambda: "found", is_read_only=True)
    tools.register(name="execute_shell", description="执行命令", parameters={"type": "object", "properties": {}}, handler=lambda: "output", is_read_only=False)
    tools.register(name="run_tests", description="运行测试", parameters={"type": "object", "properties": {}}, handler=lambda: "passed", is_read_only=True)
    tools.register(name="git_status", description="Git状态", parameters={"type": "object", "properties": {}}, handler=lambda: "ok", is_read_only=True)
    tools.register(name="git_diff", description="Git差异", parameters={"type": "object", "properties": {}}, handler=lambda: "diff", is_read_only=True)
    tools.register(name="glob", description="Glob搜索", parameters={"type": "object", "properties": {}}, handler=lambda: "files", is_read_only=True)
    tools.register(name="run_linter", description="Linter", parameters={"type": "object", "properties": {}}, handler=lambda: "clean", is_read_only=True)
    tools.register(name="check_project_structure", description="检查项目结构", parameters={"type": "object", "properties": {}}, handler=lambda: "{}", is_read_only=True)
    tools.register(name="install_dependencies", description="安装依赖", parameters={"type": "object", "properties": {}}, handler=lambda: "installed", is_read_only=False)
    tools.register(name="build_project", description="构建项目", parameters={"type": "object", "properties": {}}, handler=lambda: "built", is_read_only=False)
    tools.register(name="git_commit", description="提交代码", parameters={"type": "object", "properties": {}}, handler=lambda: "committed", is_read_only=False)
    tools.register(name="edit_file", description="编辑文件", parameters={"type": "object", "properties": {}}, handler=lambda: "edited", is_read_only=False)

    return Harness(
        model_engine=MockModelEngine(scenario="default"),
        tool_registry=tools,
        sandbox=Sandbox(use_docker=False),
        permission_manager=PermissionManager(level=PermissionLevel.AUTO_WRITE),
        max_turns=max_turns,
        token_budget=token_budget
    )


class TestSkillCategory:
    def test_categories(self):
        assert SkillCategory.ARCHITECT.value == "architect"
        assert SkillCategory.DEVELOPER.value == "developer"
        assert SkillCategory.REVIEWER.value == "reviewer"
        assert SkillCategory.TESTER.value == "tester"


class TestSkillDefinition:
    def test_creation(self):
        skill = SkillDefinition(
            name="test_skill",
            description="A test skill",
            category=SkillCategory.DEVELOPER,
            system_prompt="You are a test assistant",
            required_tools=["read_file"],
            max_turns=10,
            token_budget=30000
        )
        assert skill.name == "test_skill"
        assert skill.category == SkillCategory.DEVELOPER
        assert skill.max_turns == 10

    def test_to_dict(self):
        skill = SkillDefinition(
            name="test_skill",
            description="A test skill",
            category=SkillCategory.DEVELOPER,
            system_prompt="You are a test assistant with a very long prompt that should be truncated",
            required_tools=["read_file", "write_file"]
        )
        d = skill.to_dict()
        assert d["name"] == "test_skill"
        assert "..." in d["system_prompt"]
        assert len(d["required_tools"]) == 2


class TestSkillRegistry:
    def test_builtin_skills_loaded(self):
        registry = SkillRegistry()
        skills = registry.list_skills()
        assert len(skills) >= 4
        skill_names = [s.name for s in skills]
        assert "architect" in skill_names
        assert "developer" in skill_names
        assert "reviewer" in skill_names
        assert "tester" in skill_names

    def test_register_custom_skill(self):
        registry = SkillRegistry()
        skill = SkillDefinition(
            name="custom_skill",
            description="自定义技能 特殊任务",
            category=SkillCategory.DEVELOPER,
            system_prompt="Custom prompt"
        )
        registry.register(skill)
        assert registry.get("custom_skill") is not None

    def test_get_nonexistent_skill(self):
        registry = SkillRegistry()
        assert registry.get("nonexistent") is None

    def test_list_skills_by_category(self):
        registry = SkillRegistry()
        dev_skills = registry.list_skills(category=SkillCategory.DEVELOPER)
        assert all(s.category == SkillCategory.DEVELOPER for s in dev_skills)

    def test_match_skill_by_keyword(self):
        registry = SkillRegistry()
        skill = registry.match_skill("编写代码功能实现")
        assert skill is not None
        assert skill.name == "developer"

    def test_match_skill_architect(self):
        registry = SkillRegistry()
        skill = registry.match_skill("分析代码结构 架构设计")
        assert skill is not None
        assert skill.name == "architect"

    def test_match_skill_tester(self):
        registry = SkillRegistry()
        skill = registry.match_skill("编写单元测试")
        assert skill is not None
        assert skill.name == "tester"

    def test_match_skill_reviewer(self):
        registry = SkillRegistry()
        skill = registry.match_skill("代码审查 review")
        assert skill is not None
        assert skill.name == "reviewer"

    def test_match_skill_no_match(self):
        registry = SkillRegistry()
        skill = registry.match_skill("xyz_random_no_match")
        assert skill is None or skill.name == "developer"


class TestSkillExecutor:
    @pytest.mark.asyncio
    async def test_execute_with_skill_name(self):
        executor = SkillExecutor(harness_factory=create_test_harness)
        result = await executor.execute("创建文件", skill_name="developer")
        assert result.skill_name == "developer"
        assert result.state in (SkillState.COMPLETED, SkillState.FAILED)

    @pytest.mark.asyncio
    async def test_execute_auto_match(self):
        executor = SkillExecutor(harness_factory=create_test_harness)
        result = await executor.execute("编写代码")
        assert result.state in (SkillState.COMPLETED, SkillState.FAILED)

    @pytest.mark.asyncio
    async def test_execute_nonexistent_skill(self):
        executor = SkillExecutor(harness_factory=create_test_harness)
        result = await executor.execute("task", skill_name="nonexistent_skill")
        assert result.state == SkillState.FAILED
        assert "未找到" in result.error

    @pytest.mark.asyncio
    async def test_execute_chain(self):
        executor = SkillExecutor(harness_factory=create_test_harness)
        results = await executor.execute_chain(
            "创建项目",
            skill_names=["architect", "developer"]
        )
        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_execute_chain_stops_on_failure(self):
        executor = SkillExecutor(harness_factory=create_test_harness)
        results = await executor.execute_chain(
            "task",
            skill_names=["nonexistent_skill", "developer"]
        )
        assert len(results) == 1
        assert results[0].state == SkillState.FAILED

    @pytest.mark.asyncio
    async def test_result_has_metrics(self):
        executor = SkillExecutor(harness_factory=create_test_harness)
        result = await executor.execute("简单任务", skill_name="developer")
        assert result.turns_used >= 0
        assert result.tokens_used >= 0

    @pytest.mark.asyncio
    async def test_result_to_dict(self):
        executor = SkillExecutor(harness_factory=create_test_harness)
        result = await executor.execute("test", skill_name="developer")
        d = result.to_dict()
        assert "skill_name" in d
        assert "state" in d
