"""
沙箱环境测试
- 本地执行模式
- 权限分级
- 文件操作
- 依赖安装
- Docker 降级
"""
import pytest
import os
import tempfile
import shutil
from liu_agent.environment.sandbox import Sandbox


class TestSandboxPermissionLevels:
    def test_read_only_permission(self):
        sandbox = Sandbox(permission="read-only", use_docker=False)
        assert sandbox.permission["read"] is True
        assert sandbox.permission["write"] is False
        assert sandbox.permission["network"] is False
        assert sandbox.permission["system"] is False

    def test_write_workspace_permission(self):
        sandbox = Sandbox(permission="write-workspace", use_docker=False)
        assert sandbox.permission["read"] is True
        assert sandbox.permission["write"] is True
        assert sandbox.permission["network"] is False
        assert sandbox.permission["system"] is False

    def test_full_access_permission(self):
        sandbox = Sandbox(permission="full-access", use_docker=False)
        assert sandbox.permission["read"] is True
        assert sandbox.permission["write"] is True
        assert sandbox.permission["network"] is True
        assert sandbox.permission["system"] is True

    def test_invalid_permission_defaults(self):
        sandbox = Sandbox(permission="invalid", use_docker=False)
        assert sandbox.permission["read"] is True
        assert sandbox.permission["write"] is True


class TestSandboxLocalExecution:
    @pytest.mark.asyncio
    async def test_execute_echo(self):
        sandbox = Sandbox(use_docker=False)
        result = await sandbox.execute("echo hello world")
        assert result["exit_code"] == 0
        assert "hello world" in result["stdout"]

    @pytest.mark.asyncio
    async def test_execute_with_stderr(self):
        sandbox = Sandbox(use_docker=False)
        result = await sandbox.execute("echo error >&2")
        assert result["exit_code"] == 0
        assert "error" in result["stderr"]

    @pytest.mark.asyncio
    async def test_execute_failing_command(self):
        sandbox = Sandbox(use_docker=False)
        result = await sandbox.execute("false")
        assert result["exit_code"] != 0

    @pytest.mark.asyncio
    async def test_execute_timeout(self):
        sandbox = Sandbox(use_docker=False)
        result = await sandbox.execute("sleep 10", timeout=1)
        assert result["exit_code"] == -1
        assert "超时" in result["stderr"]

    @pytest.mark.asyncio
    async def test_execute_captures_output(self):
        sandbox = Sandbox(use_docker=False)
        result = await sandbox.execute("echo 'line1' && echo 'line2'")
        assert result["exit_code"] == 0
        assert "line1" in result["stdout"]
        assert "line2" in result["stdout"]


class TestSandboxFileOperations:
    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.sandbox = Sandbox(workspace_dir=self.tmpdir, permission="write-workspace", use_docker=False)

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_write_and_read_file(self):
        self.sandbox.write_workspace_file("test.txt", "hello sandbox")
        content = self.sandbox.read_workspace_file("test.txt")
        assert content == "hello sandbox"

    def test_write_nested_file(self):
        self.sandbox.write_workspace_file("sub/dir/test.py", "print('hi')")
        content = self.sandbox.read_workspace_file("sub/dir/test.py")
        assert "print" in content

    def test_read_nonexistent_file(self):
        content = self.sandbox.read_workspace_file("nonexistent.txt")
        assert "读取失败" in content

    def test_write_in_readonly_raises(self):
        readonly_sandbox = Sandbox(
            workspace_dir=self.tmpdir,
            permission="read-only",
            use_docker=False
        )
        with pytest.raises(PermissionError):
            readonly_sandbox.write_workspace_file("test.txt", "nope")

    def test_get_workspace_path(self):
        path = self.sandbox.get_workspace_path("test.py")
        assert path.endswith("test.py")
        assert self.tmpdir in path

    def test_get_workspace_path_empty(self):
        path = self.sandbox.get_workspace_path()
        assert path.rstrip('/') == self.tmpdir.rstrip('/')


class TestSandboxDockerFallback:
    def test_docker_unavailable_falls_back(self):
        sandbox = Sandbox(use_docker=True, docker_image="nonexistent:latest")
        assert sandbox.use_docker is False


class TestSandboxInstallDependencies:
    @pytest.mark.asyncio
    async def test_install_in_readonly_fails(self):
        sandbox = Sandbox(permission="read-only", use_docker=False)
        result = await sandbox.install_dependencies(["requests"])
        assert result["exit_code"] == -1
        assert "只读" in result["stderr"]


class TestSandboxSnapshot:
    @pytest.mark.asyncio
    async def test_snapshot_local_mode(self):
        sandbox = Sandbox(use_docker=False)
        result = await sandbox.snapshot()
        assert "不支持快照" in result


class TestSandboxRepr:
    def test_repr(self):
        sandbox = Sandbox(use_docker=False)
        repr_str = repr(sandbox)
        assert "Sandbox" in repr_str
        assert "docker=False" in repr_str


class TestSandboxCleanup:
    @pytest.mark.asyncio
    async def test_cleanup_local(self):
        sandbox = Sandbox(use_docker=False)
        await sandbox.cleanup()
