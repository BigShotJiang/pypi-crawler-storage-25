"""
模型引擎测试
- MockModelEngine 场景测试
- OpenAIEngine 重试/回退逻辑测试
- AnthropicEngine 重试/回退逻辑测试
- FallbackEngine 多模型回退测试
- Token 估算测试
"""
import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from liu_agent.model.engine import (
    MockModelEngine, OpenAIEngine, AnthropicEngine,
    FallbackEngine, RetryConfig, _calculate_retry_delay
)


class TestMockModelEngine:
    @pytest.mark.asyncio
    async def test_default_scenario(self):
        model = MockModelEngine(scenario="default")
        result = await model.generate([{"role": "user", "content": "hello"}])
        assert "thought" in result
        assert "tool_calls" in result
        assert "token_usage" in result
        assert "total" in result["token_usage"]

    @pytest.mark.asyncio
    async def test_write_file_scenario(self):
        model = MockModelEngine(scenario="write_file")
        result = await model.generate([{"role": "user", "content": "创建文件"}])
        assert len(result["tool_calls"]) > 0
        assert result["tool_calls"][0]["name"] == "list_directory"

        result2 = await model.generate([{"role": "user", "content": "继续"}])
        assert any(tc["name"] == "write_file" for tc in result2["tool_calls"])

        result3 = await model.generate([{"role": "user", "content": "继续"}])
        assert len(result3["tool_calls"]) == 0

    @pytest.mark.asyncio
    async def test_edit_file_scenario(self):
        model = MockModelEngine(scenario="edit_file")
        result = await model.generate([{"role": "user", "content": "修改文件"}])
        assert result["tool_calls"][0]["name"] == "read_file"

        result2 = await model.generate([{"role": "user", "content": "继续"}])
        assert any(tc["name"] == "edit_file" for tc in result2["tool_calls"])

    @pytest.mark.asyncio
    async def test_complex_scenario_multi_turn(self):
        model = MockModelEngine(scenario="complex_task")
        all_calls = []
        for _ in range(6):
            result = await model.generate([{"role": "user", "content": "继续"}])
            for tc in result["tool_calls"]:
                all_calls.append(tc["name"])

        assert "list_directory" in all_calls
        assert "write_file" in all_calls
        assert "run_tests" in all_calls

    @pytest.mark.asyncio
    async def test_estimate_tokens(self):
        model = MockModelEngine()
        tokens = model.estimate_tokens("hello world this is a test")
        assert tokens > 0
        assert isinstance(tokens, int)


class TestRetryConfig:
    def test_default_config(self):
        config = RetryConfig()
        assert config.max_retries == 3
        assert config.base_delay == 1.0
        assert config.max_delay == 60.0

    def test_calculate_retry_delay(self):
        config = RetryConfig(base_delay=1.0, exponential_base=2.0, max_delay=60.0)
        assert _calculate_retry_delay(0, config) == 1.0
        assert _calculate_retry_delay(1, config) == 2.0
        assert _calculate_retry_delay(2, config) == 4.0
        assert _calculate_retry_delay(10, config) == 60.0


class TestOpenAIEngine:
    def test_init_with_env_key(self):
        with patch.dict("os.environ", {"OPENAI_API_KEY": "test-key"}):
            engine = OpenAIEngine()
            assert engine.api_key == "test-key"
            assert engine.model == "gpt-4"

    def test_init_with_custom_model(self):
        engine = OpenAIEngine(api_key="test", model="gpt-3.5-turbo")
        assert engine.model == "gpt-3.5-turbo"
        assert engine.fallback_model == "gpt-3.5-turbo"

    def test_is_retryable_rate_limit(self):
        engine = OpenAIEngine(api_key="test")
        assert engine._is_retryable(Exception("rate_limit exceeded")) is True
        assert engine._is_retryable(Exception("429 Too Many Requests")) is True
        assert engine._is_retryable(Exception("timeout")) is True
        assert engine._is_retryable(Exception("connection reset")) is True
        assert engine._is_retryable(Exception("invalid api key")) is False

    @pytest.mark.asyncio
    async def test_generate_with_mock_client(self):
        engine = OpenAIEngine(api_key="test-key")

        mock_choice = MagicMock()
        mock_choice.message.content = "test response"
        mock_choice.message.tool_calls = None

        mock_usage = MagicMock()
        mock_usage.prompt_tokens = 10
        mock_usage.completion_tokens = 20
        mock_usage.total_tokens = 30

        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_response.usage = mock_usage

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)
        engine._client = mock_client

        result = await engine.generate(
            messages=[{"role": "user", "content": "hello"}],
            system_prompt="test"
        )
        assert result["thought"] == "test response"
        assert result["token_usage"]["total"] == 30

    @pytest.mark.asyncio
    async def test_generate_with_tool_calls(self):
        engine = OpenAIEngine(api_key="test-key")

        mock_tc = MagicMock()
        mock_tc.id = "call_123"
        mock_tc.function.name = "read_file"
        mock_tc.function.arguments = '{"path": "test.py"}'

        mock_choice = MagicMock()
        mock_choice.message.content = "reading file"
        mock_choice.message.tool_calls = [mock_tc]

        mock_usage = MagicMock()
        mock_usage.prompt_tokens = 10
        mock_usage.completion_tokens = 20
        mock_usage.total_tokens = 30

        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_response.usage = mock_usage

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(return_value=mock_response)
        engine._client = mock_client

        result = await engine.generate(
            messages=[{"role": "user", "content": "read test.py"}],
            tools=[{"name": "read_file", "description": "read", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}}}]
        )
        assert len(result["tool_calls"]) == 1
        assert result["tool_calls"][0]["name"] == "read_file"

    @pytest.mark.asyncio
    async def test_fallback_on_failure(self):
        engine = OpenAIEngine(api_key="test-key", model="gpt-4", fallback_model="gpt-3.5-turbo")

        mock_client = AsyncMock()
        mock_client.chat.completions.create = AsyncMock(
            side_effect=Exception("rate_limit exceeded")
        )
        engine._client = mock_client

        with pytest.raises(Exception):
            await engine.generate(messages=[{"role": "user", "content": "hello"}])

    def test_usage_stats(self):
        engine = OpenAIEngine(api_key="test-key")
        stats = engine.usage_stats
        assert "total_tokens" in stats
        assert "call_count" in stats
        assert stats["total_tokens"] == 0


class TestAnthropicEngine:
    def test_init(self):
        with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "test-key"}):
            engine = AnthropicEngine()
            assert engine.api_key == "test-key"
            assert "claude" in engine.model

    def test_is_retryable(self):
        engine = AnthropicEngine(api_key="test")
        assert engine._is_retryable(Exception("rate_limit")) is True
        assert engine._is_retryable(Exception("overloaded")) is True
        assert engine._is_retryable(Exception("529")) is True
        assert engine._is_retryable(Exception("invalid key")) is False

    @pytest.mark.asyncio
    async def test_generate_with_mock_client(self):
        engine = AnthropicEngine(api_key="test-key")

        mock_text = MagicMock()
        mock_text.type = "text"
        mock_text.text = "test response"

        mock_usage = MagicMock()
        mock_usage.input_tokens = 10
        mock_usage.output_tokens = 20

        mock_response = MagicMock()
        mock_response.content = [mock_text]
        mock_response.usage = mock_usage

        mock_client = AsyncMock()
        mock_client.messages.create = AsyncMock(return_value=mock_response)
        engine._client = mock_client

        result = await engine.generate(
            messages=[{"role": "user", "content": "hello"}]
        )
        assert result["thought"] == "test response"
        assert result["token_usage"]["total"] == 30


class TestFallbackEngine:
    @pytest.mark.asyncio
    async def test_fallback_to_second_engine(self):
        mock1 = MockModelEngine(scenario="default")

        fail_engine = AsyncMock()
        fail_engine.generate = AsyncMock(side_effect=RuntimeError("API failed"))

        good_engine = MockModelEngine(scenario="write_file")

        fallback = FallbackEngine([fail_engine, good_engine])
        result = await fallback.generate([{"role": "user", "content": "test"}])
        assert "thought" in result

    @pytest.mark.asyncio
    async def test_all_engines_fail(self):
        fail1 = AsyncMock()
        fail1.generate = AsyncMock(side_effect=RuntimeError("fail1"))
        fail2 = AsyncMock()
        fail2.generate = AsyncMock(side_effect=RuntimeError("fail2"))

        fallback = FallbackEngine([fail1, fail2])
        with pytest.raises(RuntimeError):
            await fallback.generate([{"role": "user", "content": "test"}])

    @pytest.mark.asyncio
    async def test_empty_engines(self):
        fallback = FallbackEngine([])
        with pytest.raises(RuntimeError, match="没有可用的模型引擎"):
            await fallback.generate([{"role": "user", "content": "test"}])

    def test_estimate_tokens(self):
        mock = MockModelEngine()
        fallback = FallbackEngine([mock])
        assert fallback.estimate_tokens("hello") > 0
