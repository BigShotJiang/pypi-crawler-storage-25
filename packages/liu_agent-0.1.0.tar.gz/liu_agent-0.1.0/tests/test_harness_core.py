"""
Harness 核心循环测试
- ReAct 循环执行
- 权限管理 (5层防御)
- 并发安全执行 (读并行/写串行)
- Token 预算限制
- 最大轮次限制
- 中断机制
- 会话管理
"""
import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock
from liu_agent.harness.core_loop import (
    Harness, AgentState, PermissionLevel, PermissionManager,
    ToolCall, ToolResult, Turn, Session,
    TokenBudgetExceeded, MaxTurnsExceeded, PermissionDenied
)
from liu_agent.tools.tool_registry import ToolRegistry
from liu_agent.model.engine import MockModelEngine
from liu_agent.environment.sandbox import Sandbox


def create_test_harness(max_turns=10, token_budget=50000, permission_level=PermissionLevel.AUTO_WRITE):
    model = MockModelEngine(scenario="write_file")
    tools = ToolRegistry()

    async def read_handler(path: str = "test.py", sandbox=None):
        return "file content"

    async def write_handler(path: str = "test.py", content: str = "", sandbox=None):
        return f"写入成功: {path}"

    tools.register(name="read_file", description="读取文件", parameters={"type": "object", "properties": {"path": {"type": "string"}}}, handler=read_handler, is_read_only=True, tags=["file", "read"])
    tools.register(name="write_file", description="写入文件", parameters={"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}}, handler=write_handler, is_read_only=False, tags=["file", "write"])
    tools.register(name="list_directory", description="列出目录", parameters={"type": "object", "properties": {"path": {"type": "string"}}}, handler=lambda path=".": "dir listing", is_read_only=True, tags=["file", "list"])

    sandbox = Sandbox(use_docker=False)
    permission = PermissionManager(level=permission_level)

    return Harness(
        model_engine=model,
        tool_registry=tools,
        sandbox=sandbox,
        permission_manager=permission,
        max_turns=max_turns,
        token_budget=token_budget,
        enable_concurrent_reads=True
    )


class TestAgentState:
    def test_state_values(self):
        assert AgentState.IDLE.name == "IDLE"
        assert AgentState.THINKING.name == "THINKING"
        assert AgentState.COMPLETED.name == "COMPLETED"
        assert AgentState.ERROR.name == "ERROR"
        assert AgentState.PAUSED.name == "PAUSED"


class TestToolCall:
    def test_from_dict(self):
        data = {"name": "read_file", "parameters": {"path": "test.py"}, "id": "abc123"}
        tc = ToolCall.from_dict(data)
        assert tc.name == "read_file"
        assert tc.parameters["path"] == "test.py"
        assert tc.id == "abc123"

    def test_from_dict_defaults(self):
        data = {"name": "test", "parameters": {}}
        tc = ToolCall.from_dict(data)
        assert tc.is_read_only is True
        assert tc.server == "default"
        assert len(tc.id) > 0


class TestToolResult:
    def test_success_result(self):
        result = ToolResult(call_id="1", success=True, output="ok")
        assert result.success is True
        assert result.error is None

    def test_failure_result(self):
        result = ToolResult(call_id="1", success=False, output="", error="fail")
        assert result.success is False
        assert result.error == "fail"


class TestTurn:
    def test_to_dict(self):
        turn = Turn(
            turn_id=0,
            thought="test thought",
            tool_calls=[ToolCall(id="1", name="read_file", parameters={"path": "a.py"})],
            tool_results=[ToolResult(call_id="1", success=True, output="content")],
            token_usage={"total": 100}
        )
        d = turn.to_dict()
        assert d["turn_id"] == 0
        assert len(d["tool_calls"]) == 1
        assert d["token_usage"]["total"] == 100


class TestSession:
    def test_append_and_get_turns(self):
        session = Session()
        turn = Turn(turn_id=0, thought="t", tool_calls=[], tool_results=[])
        session.append_turn(turn)
        assert len(session.turns) == 1
        assert session.get_last_n_turns(1)[0].thought == "t"

    def test_get_token_usage(self):
        session = Session()
        session.append_turn(Turn(turn_id=0, thought="", tool_calls=[], tool_results=[], token_usage={"total": 50}))
        session.append_turn(Turn(turn_id=1, thought="", tool_calls=[], tool_results=[], token_usage={"total": 30}))
        assert session.get_token_usage() == 80

    def test_to_dict(self):
        session = Session()
        d = session.to_dict()
        assert "session_id" in d
        assert "turn_count" in d


class TestPermissionManager:
    def test_auto_read_level(self):
        pm = PermissionManager(level=PermissionLevel.AUTO_READ)
        read_tc = ToolCall(id="1", name="read_file", parameters={}, is_read_only=True)
        write_tc = ToolCall(id="2", name="write_file", parameters={}, is_read_only=False)
        system_tc = ToolCall(id="3", name="execute_shell", parameters={}, is_read_only=False)
        assert pm.check(read_tc) is True
        assert pm.check(write_tc) is False
        assert pm.check(system_tc) is False

    def test_auto_write_level(self):
        pm = PermissionManager(level=PermissionLevel.AUTO_WRITE)
        read_tc = ToolCall(id="1", name="read_file", parameters={})
        write_tc = ToolCall(id="2", name="write_file", parameters={})
        system_tc = ToolCall(id="3", name="execute_shell", parameters={})
        assert pm.check(read_tc) is True
        assert pm.check(write_tc) is True
        assert pm.check(system_tc) is False

    def test_ask_write_level(self):
        pm = PermissionManager(level=PermissionLevel.ASK_WRITE)
        read_tc = ToolCall(id="1", name="read_file", parameters={})
        write_tc = ToolCall(id="2", name="write_file", parameters={"path": "a.py"})
        assert pm.check(read_tc) is True
        assert pm.check(write_tc) is False

        pm.approve(write_tc)
        assert pm.check(write_tc) is True

    def test_ask_system_level(self):
        pm = PermissionManager(level=PermissionLevel.ASK_SYSTEM)
        read_tc = ToolCall(id="1", name="read_file", parameters={})
        write_tc = ToolCall(id="2", name="write_file", parameters={})
        system_tc = ToolCall(id="3", name="execute_shell", parameters={"command": "rm -rf /"})
        assert pm.check(read_tc) is True
        assert pm.check(write_tc) is True
        assert pm.check(system_tc) is False

        pm.approve(system_tc)
        assert pm.check(system_tc) is True

    def test_blocked_level(self):
        pm = PermissionManager(level=PermissionLevel.BLOCKED)
        tc = ToolCall(id="1", name="read_file", parameters={})
        assert pm.check(tc) is False

    def test_block_operation(self):
        pm = PermissionManager(level=PermissionLevel.AUTO_WRITE)
        tc = ToolCall(id="1", name="write_file", parameters={"path": "a.py"})
        assert pm.check(tc) is True

        pm.block(tc)
        pm.level = PermissionLevel.ASK_WRITE
        assert pm.check(tc) is False

    def test_unknown_tool_permissions(self):
        pm = PermissionManager(level=PermissionLevel.AUTO_WRITE)
        unknown_tc = ToolCall(id="1", name="custom_tool", parameters={})
        assert pm.check(unknown_tc) is True


class TestHarness:
    @pytest.mark.asyncio
    async def test_basic_run(self):
        harness = create_test_harness(max_turns=5)
        turns = []
        async for turn in harness.run("创建hello.py"):
            turns.append(turn)
        assert len(turns) >= 1
        assert harness.state in (AgentState.COMPLETED, AgentState.IDLE)

    @pytest.mark.asyncio
    async def test_max_turns_limit(self):
        harness = create_test_harness(max_turns=1, token_budget=999999)

        class AlwaysCallTool(MockModelEngine):
            async def generate(self, messages, tools=None, system_prompt=None):
                await asyncio.sleep(0)
                self.turn_count += 1
                return {
                    "thought": "calling tool",
                    "tool_calls": [{"name": "read_file", "parameters": {"path": "test.py"}, "is_read_only": True}],
                    "token_usage": {"total": 50}
                }

        harness.model = AlwaysCallTool(scenario="default")
        with pytest.raises(MaxTurnsExceeded):
            async for turn in harness.run("do something"):
                pass

    @pytest.mark.asyncio
    async def test_token_budget_exceeded(self):
        harness = create_test_harness(max_turns=100, token_budget=50)

        class HighTokenModel(MockModelEngine):
            async def generate(self, messages, tools=None, system_prompt=None):
                await asyncio.sleep(0)
                self.turn_count += 1
                return {
                    "thought": "thinking",
                    "tool_calls": [{"name": "read_file", "parameters": {"path": "test.py"}, "is_read_only": True}],
                    "token_usage": {"total": 10000}
                }

        harness.model = HighTokenModel(scenario="default")
        with pytest.raises(TokenBudgetExceeded):
            async for turn in harness.run("big task"):
                pass

    @pytest.mark.asyncio
    async def test_interrupt(self):
        harness = create_test_harness(max_turns=100, token_budget=999999)
        turn_count = 0

        class AlwaysCallTool(MockModelEngine):
            async def generate(self, messages, tools=None, system_prompt=None):
                await asyncio.sleep(0)
                self.turn_count += 1
                return {
                    "thought": "calling tool",
                    "tool_calls": [{"name": "read_file", "parameters": {"path": "test.py"}, "is_read_only": True}],
                    "token_usage": {"total": 50}
                }

        harness.model = AlwaysCallTool(scenario="default")

        async for turn in harness.run("long task"):
            turn_count += 1
            if turn_count >= 2:
                harness.interrupt()

        assert turn_count <= 3

    @pytest.mark.asyncio
    async def test_permission_denied(self):
        harness = create_test_harness(permission_level=PermissionLevel.BLOCKED)

        class WriteModel(MockModelEngine):
            async def generate(self, messages, tools=None, system_prompt=None):
                await asyncio.sleep(0)
                self.turn_count += 1
                if self.turn_count == 1:
                    return {
                        "thought": "writing",
                        "tool_calls": [{"name": "write_file", "parameters": {"path": "test.py", "content": "code"}, "is_read_only": False}],
                        "token_usage": {"total": 50}
                    }
                return {"thought": "done", "tool_calls": [], "token_usage": {"total": 10}}

        harness.model = WriteModel(scenario="default")
        with pytest.raises(PermissionDenied):
            async for turn in harness.run("write file"):
                pass

    @pytest.mark.asyncio
    async def test_session_summary(self):
        harness = create_test_harness()
        async for turn in harness.run("创建hello.py"):
            pass
        summary = harness.get_session_summary()
        assert "session" in summary
        assert "stats" in summary
        assert "final_state" in summary

    @pytest.mark.asyncio
    async def test_concurrent_read_execution(self):
        tools = ToolRegistry()

        async def read_handler(path: str = "test.py", sandbox=None):
            return "file content"

        async def list_handler(path: str = ".", sandbox=None):
            return "dir listing"

        tools.register(name="read_file", description="读取文件", parameters={"type": "object", "properties": {"path": {"type": "string"}}}, handler=read_handler, is_read_only=True, tags=["file", "read"])
        tools.register(name="list_directory", description="列出目录", parameters={"type": "object", "properties": {"path": {"type": "string"}}}, handler=list_handler, is_read_only=True, tags=["file", "list"])

        harness = create_test_harness()
        harness.tools = tools
        harness.enable_concurrent_reads = True

        class MultiReadModel(MockModelEngine):
            async def generate(self, messages, tools=None, system_prompt=None):
                await asyncio.sleep(0)
                self.turn_count += 1
                if self.turn_count == 1:
                    return {
                        "thought": "reading multiple files",
                        "tool_calls": [
                            {"name": "read_file", "parameters": {"path": "a.py"}, "is_read_only": True},
                            {"name": "read_file", "parameters": {"path": "b.py"}, "is_read_only": True},
                            {"name": "list_directory", "parameters": {"path": "."}, "is_read_only": True}
                        ],
                        "token_usage": {"total": 100}
                    }
                return {"thought": "done", "tool_calls": [], "token_usage": {"total": 10}}

        harness.model = MultiReadModel(scenario="default")
        turns = []
        async for turn in harness.run("read files"):
            turns.append(turn)

        assert len(turns) >= 1
        if turns[0].tool_results:
            assert all(r.success for r in turns[0].tool_results)

    @pytest.mark.asyncio
    async def test_bootstrap_context(self):
        harness = create_test_harness()
        messages = await harness._bootstrap_context("test task", {"extra": "info"})
        assert len(messages) == 2
        assert messages[0]["role"] == "system"
        assert messages[1]["role"] == "user"
        assert "test task" in messages[1]["content"]

    def test_handle_results_with_exception(self):
        harness = create_test_harness()
        calls = [ToolCall(id="1", name="test", parameters={})]
        results = [RuntimeError("boom")]
        processed = harness._handle_results(calls, results)
        assert len(processed) == 1
        assert processed[0].success is False
        assert "boom" in processed[0].error

    def test_build_observations(self):
        harness = create_test_harness()
        results = [
            ToolResult(call_id="1", success=True, output="file content"),
            ToolResult(call_id="2", success=False, output="", error="not found")
        ]
        obs = harness._build_observations(results)
        assert "成功" in obs
        assert "失败" in obs
