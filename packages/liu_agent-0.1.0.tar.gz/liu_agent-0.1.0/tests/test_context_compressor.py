"""
上下文压缩器测试
- Layer 1: Snip 截断过长输出
- Layer 2: Microcompact 提取关键行
- Layer 3: Collapse 合并早期历史
- Layer 4: Autocompact LLM摘要/保底策略
- Token 估算
"""
import pytest
from liu_agent.harness.context_compressor import ContextCompressor, CompressionConfig


class TestCompressionConfig:
    def test_defaults(self):
        config = CompressionConfig()
        assert config.snip_threshold == 4000
        assert config.microcompact_threshold == 8000
        assert config.collapse_threshold == 12000
        assert config.autocompact_threshold == 16000
        assert config.preserve_recent_turns == 5

    def test_custom_config(self):
        config = CompressionConfig(
            snip_threshold=1000,
            microcompact_threshold=2000,
            preserve_recent_turns=3
        )
        assert config.snip_threshold == 1000
        assert config.preserve_recent_turns == 3


class TestSnipLayer:
    def test_snip_long_output(self):
        compressor = ContextCompressor(config=CompressionConfig(snip_threshold=200))
        long_content = "a" * 5000
        messages = [
            {"role": "system", "content": "system"},
            {"role": "tool", "content": long_content}
        ]
        result = compressor._snip_long_outputs(messages)
        assert len(result) == 2
        assert "截断" in result[1]["content"]
        assert len(result[1]["content"]) < len(long_content)

    def test_snip_preserves_short_output(self):
        compressor = ContextCompressor(config=CompressionConfig(snip_threshold=10000))
        messages = [
            {"role": "tool", "content": "short content"}
        ]
        result = compressor._snip_long_outputs(messages)
        assert result[0]["content"] == "short content"

    def test_snip_preserves_non_tool_messages(self):
        compressor = ContextCompressor(config=CompressionConfig(snip_threshold=100))
        long_content = "a" * 500
        messages = [
            {"role": "assistant", "content": long_content}
        ]
        result = compressor._snip_long_outputs(messages)
        assert result[0]["content"] == long_content


class TestMicrocompactLayer:
    def test_microcompact_extracts_key_lines(self):
        compressor = ContextCompressor(config=CompressionConfig(microcompact_threshold=200))
        content_lines = ["normal line"] * 20 + ["Error: something failed"] + ["normal"] * 20
        content = "\n".join(content_lines)
        messages = [{"role": "tool", "content": content}]

        result = compressor._microcompact(messages)
        assert "Error" in result[0]["content"]

    def test_microcompact_preserves_short_content(self):
        compressor = ContextCompressor(config=CompressionConfig(microcompact_threshold=100000))
        messages = [{"role": "tool", "content": "short"}]
        result = compressor._microcompact(messages)
        assert result[0]["content"] == "short"

    def test_microcompact_detects_keywords(self):
        compressor = ContextCompressor(config=CompressionConfig(microcompact_threshold=100))
        content = "\n".join(["line"] * 30 + ["FAIL: test failed"] + ["line"] * 30)
        messages = [{"role": "tool", "content": content}]
        result = compressor._microcompact(messages)
        assert "FAIL" in result[0]["content"]


class TestCollapseLayer:
    def test_collapse_old_history(self):
        compressor = ContextCompressor(config=CompressionConfig(preserve_recent_turns=2))
        messages = [
            {"role": "system", "content": "system"},
            {"role": "user", "content": "任务: do something"},
        ]
        for i in range(10):
            messages.append({"role": "assistant", "content": f"决定: step {i}"})
            messages.append({"role": "user", "content": f"观察结果: 成功 step {i}"})

        result = compressor._collapse_history(messages)
        assert any("历史摘要" in m.get("content", "") or "摘要" in m.get("content", "") for m in result)

    def test_collapse_preserves_recent(self):
        compressor = ContextCompressor(config=CompressionConfig(preserve_recent_turns=3))
        messages = [
            {"role": "system", "content": "system"},
            {"role": "user", "content": "任务: test"},
        ]
        for i in range(4):
            messages.append({"role": "assistant", "content": f"step {i}"})
            messages.append({"role": "user", "content": f"result {i}"})

        result = compressor._collapse_history(messages)
        recent_content = [m["content"] for m in result[-6:]]
        assert any("step 3" in c for c in recent_content)

    def test_no_collapse_when_few_messages(self):
        compressor = ContextCompressor(config=CompressionConfig(preserve_recent_turns=10))
        messages = [
            {"role": "system", "content": "system"},
            {"role": "user", "content": "task"},
            {"role": "assistant", "content": "response"},
        ]
        result = compressor._collapse_history(messages)
        assert len(result) == len(messages)


class TestAutocompactLayer:
    def test_autocompact_without_model(self):
        compressor = ContextCompressor()
        messages = [
            {"role": "system", "content": "system"},
            {"role": "user", "content": "任务: test"},
        ]
        for i in range(20):
            messages.append({"role": "assistant", "content": f"step {i}"})
            messages.append({"role": "user", "content": f"result {i}"})

        result = compressor._autocompact(messages, max_tokens=100)
        assert len(result) < len(messages)

    def test_autocompact_preserves_system(self):
        compressor = ContextCompressor()
        messages = [
            {"role": "system", "content": "important system prompt"},
            {"role": "user", "content": "任务: test"},
        ]
        for i in range(10):
            messages.append({"role": "assistant", "content": f"step {i}"})

        result = compressor._autocompact(messages, max_tokens=50)
        system_msgs = [m for m in result if m["role"] == "system"]
        assert len(system_msgs) >= 1
        assert system_msgs[0]["content"] == "important system prompt"


class TestFullCompressPipeline:
    def test_compress_under_budget(self):
        compressor = ContextCompressor()
        messages = [
            {"role": "system", "content": "system"},
            {"role": "user", "content": "short task"},
        ]
        result = compressor.compress(messages, max_tokens=100000)
        assert len(result) == len(messages)

    def test_compress_over_budget_triggers_snip(self):
        compressor = ContextCompressor(config=CompressionConfig(snip_threshold=100))
        messages = [
            {"role": "system", "content": "system"},
            {"role": "tool", "content": "a" * 10000}
        ]
        result = compressor.compress(messages, max_tokens=500)
        assert len(result[1]["content"]) < 10000

    def test_generate_decision_summary(self):
        compressor = ContextCompressor()
        history = [
            {"role": "assistant", "content": "决定: 使用Flask框架"},
            {"role": "user", "content": "观察结果: 成功安装Flask"},
            {"role": "assistant", "content": "决定: 创建app.py文件"},
            {"role": "user", "content": "观察结果: 文件创建成功"},
        ]
        summary = compressor._generate_decision_summary(history)
        assert "决定" in summary["content"]

    def test_set_summary_model(self):
        compressor = ContextCompressor()
        mock_model = object()
        compressor.set_summary_model(mock_model)
        assert compressor._summary_model is mock_model


class TestTokenEstimation:
    def test_estimate_tokens(self):
        compressor = ContextCompressor()
        messages = [
            {"role": "user", "content": "hello world"},
            {"role": "assistant", "content": "hi there"}
        ]
        tokens = compressor._estimate_tokens(messages)
        assert tokens > 0
        assert isinstance(tokens, int)

    def test_estimate_tokens_empty(self):
        compressor = ContextCompressor()
        tokens = compressor._estimate_tokens([])
        assert tokens == 0
