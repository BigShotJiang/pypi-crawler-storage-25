"""
记忆系统测试
- ContextMemory: 会话记忆、nudge机制、上下文注入
- DecisionStore: SQLite持久化、查询、清理
- MemoryCompactor: 会话压缩、上下文恢复
"""
import pytest
import os
import tempfile
import shutil
from liu_agent.memory.base import ContextMemory, DecisionStore, MemoryCompactor, MemoryEntry


class TestMemoryEntry:
    def test_creation(self):
        entry = MemoryEntry(key="test", content="test content", category="general", importance=0.7)
        assert entry.key == "test"
        assert entry.content == "test content"
        assert entry.importance == 0.7
        assert entry.access_count == 0

    def test_to_dict(self):
        entry = MemoryEntry(key="test", content="a" * 300, category="test")
        d = entry.to_dict()
        assert d["key"] == "test"
        assert len(d["content"]) <= 200


class TestContextMemory:
    def test_add_entry(self):
        memory = ContextMemory()
        memory.add("key1", "content1", category="test", importance=0.8)
        assert len(memory._entries) == 1

    def test_add_project_fact(self):
        memory = ContextMemory()
        memory.add_project_fact("项目使用Python 3.11")
        assert len(memory._project_facts) == 1
        assert len(memory._entries) == 1

    def test_add_user_preference(self):
        memory = ContextMemory()
        memory.add_user_preference("language", "Python")
        assert memory._user_preferences["language"] == "Python"

    def test_add_decision(self):
        memory = ContextMemory()
        memory.add_decision("使用Flask框架", reasoning="轻量级", turn=1)
        assert len(memory._decision_log) == 1

    def test_nudge_returns_none_before_interval(self):
        memory = ContextMemory(nudge_interval=10)
        memory.add_project_fact("fact1")
        for i in range(9):
            result = memory.get_nudge()
            assert result is None

    def test_nudge_returns_content_at_interval(self):
        memory = ContextMemory(nudge_interval=2)
        memory.add_project_fact("fact1")
        memory.add_decision("decision1")

        memory.get_nudge()
        result = memory.get_nudge()
        assert result is not None
        assert "fact1" in result

    def test_get_relevant(self):
        memory = ContextMemory()
        memory.add("k1", "Python web framework Flask", importance=0.8)
        memory.add("k2", "JavaScript React component", importance=0.7)
        memory.add("k3", "Database SQL query optimization", importance=0.6)

        results = memory.get_relevant("Python Flask", top_k=2)
        assert len(results) <= 2
        assert any("Python" in e.content for e in results)

    def test_get_relevant_no_match(self):
        memory = ContextMemory()
        memory.add("k1", "some content", importance=0.5)
        results = memory.get_relevant("xyz_not_matching", top_k=5)
        assert len(results) == 0

    def test_build_context_injection(self):
        memory = ContextMemory()
        memory.add_project_fact("使用Python")
        memory.add_user_preference("style", "PEP8")
        memory.add_decision("使用Flask")

        injection = memory.build_context_injection()
        assert "项目信息" in injection
        assert "用户偏好" in injection
        assert "近期决策" in injection

    def test_build_context_injection_empty(self):
        memory = ContextMemory()
        injection = memory.build_context_injection()
        assert injection == ""

    def test_to_dict(self):
        memory = ContextMemory()
        memory.add("k1", "content")
        memory.add_project_fact("fact")
        d = memory.to_dict()
        assert d["entry_count"] == 2
        assert d["project_facts"] == 1


class TestDecisionStore:
    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test_memory.db")
        self.store = DecisionStore(db_path=self.db_path)

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_save_and_get_decisions(self):
        self.store.save_decision("session1", "使用Flask", reasoning="轻量级", category="framework")
        decisions = self.store.get_decisions(session_id="session1")
        assert len(decisions) == 1
        assert decisions[0]["decision"] == "使用Flask"

    def test_get_decisions_by_category(self):
        self.store.save_decision("s1", "dec1", category="framework")
        self.store.save_decision("s1", "dec2", category="testing")
        self.store.save_decision("s1", "dec3", category="framework")

        framework = self.store.get_decisions(category="framework")
        testing = self.store.get_decisions(category="testing")
        assert len(framework) == 2
        assert len(testing) == 1

    def test_get_decisions_limit(self):
        for i in range(10):
            self.store.save_decision("s1", f"decision {i}")
        decisions = self.store.get_decisions(limit=5)
        assert len(decisions) == 5

    def test_save_and_get_project_facts(self):
        self.store.save_project_fact("/project", "使用Python 3.11")
        facts = self.store.get_project_facts("/project")
        assert len(facts) == 1
        assert facts[0]["fact"] == "使用Python 3.11"

    def test_project_facts_dedup(self):
        self.store.save_project_fact("/project", "fact1")
        self.store.save_project_fact("/project", "fact1")
        facts = self.store.get_project_facts("/project")
        assert len(facts) == 1

    def test_save_and_get_preferences(self):
        self.store.save_preference("theme", "dark")
        assert self.store.get_preference("theme") == "dark"
        assert self.store.get_preference("nonexistent") is None

    def test_get_all_preferences(self):
        self.store.save_preference("theme", "dark")
        self.store.save_preference("language", "Python")
        prefs = self.store.get_all_preferences()
        assert prefs["theme"] == "dark"
        assert prefs["language"] == "Python"

    def test_cleanup(self):
        self.store.save_decision("s1", "old decision", category="old")
        self.store.cleanup(max_age_days=0)
        decisions = self.store.get_decisions()
        assert len(decisions) == 0


class TestMemoryCompactor:
    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test_memory.db")

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_compact_session(self):
        store = DecisionStore(db_path=self.db_path)
        compactor = MemoryCompactor(decision_store=store)

        memory = ContextMemory()
        memory.add_decision("dec1", reasoning="r1")
        memory.add_decision("dec2", reasoning="r2")
        memory.add_project_fact("fact1")
        memory.add_user_preference("key1", "val1")

        result = compactor.compact_session(memory, "session1")
        assert result["decisions_saved"] == 2
        assert result["facts_saved"] == 1
        assert result["preferences_saved"] == 1

    def test_compact_without_store(self):
        compactor = MemoryCompactor()
        memory = ContextMemory()
        memory.add_decision("dec1")
        result = compactor.compact_session(memory, "session1")
        assert result["decisions_saved"] == 0

    def test_load_session_context(self):
        store = DecisionStore(db_path=self.db_path)
        store.save_project_fact("/project", "使用Flask")
        store.save_preference("style", "PEP8")
        store.save_decision("s1", "使用SQLite")

        compactor = MemoryCompactor(decision_store=store)
        memory = compactor.load_session_context("/project")

        assert len(memory._project_facts) > 0
        assert len(memory._user_preferences) > 0

    def test_generate_session_summary(self):
        compactor = MemoryCompactor()
        memory = ContextMemory()
        memory.add_decision("使用Flask框架")
        memory.add_decision("创建app.py")
        memory.add_project_fact("Python 3.11")

        summary = compactor.generate_session_summary(memory)
        assert "Flask" in summary
        assert "Python" in summary

    def test_generate_session_summary_empty(self):
        compactor = MemoryCompactor()
        memory = ContextMemory()
        summary = compactor.generate_session_summary(memory)
        assert "无显著内容" in summary
