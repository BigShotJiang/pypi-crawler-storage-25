"""
多Agent编排器测试
- 任务复杂度评估
- 简单任务执行
- 中等任务分解
- 复杂任务DAG执行
- Agent原型类型
- 子Agent生成
"""
import pytest
import asyncio
from unittest.mock import MagicMock
from liu_agent.harness.orchestrator import MultiAgentOrchestrator, AgentArchetype, SubTask
from liu_agent.harness.core_loop import Harness, PermissionLevel, PermissionManager
from liu_agent.tools.tool_registry import ToolRegistry
from liu_agent.model.engine import MockModelEngine
from liu_agent.environment.sandbox import Sandbox
from liu_agent.harness.context_compressor import ContextCompressor


class TestAgentArchetype:
    def test_archetype_values(self):
        assert AgentArchetype.EXPLORER.value == "explorer"
        assert AgentArchetype.BUILDER.value == "builder"
        assert AgentArchetype.SURGEON.value == "surgeon"
        assert AgentArchetype.ORCHESTRATOR.value == "orchestrator"
        assert AgentArchetype.TESTER.value == "tester"
        assert AgentArchetype.REVIEWER.value == "reviewer"
        assert AgentArchetype.SPECIALIST.value == "specialist"


class TestSubTask:
    def test_subtask_creation(self):
        task = SubTask(
            task_id="1",
            description="test task",
            archetype=AgentArchetype.BUILDER
        )
        assert task.task_id == "1"
        assert task.status == "pending"
        assert task.result is None
        assert task.dependencies == []

    def test_subtask_with_dependencies(self):
        task = SubTask(
            task_id="2",
            description="dependent task",
            archetype=AgentArchetype.TESTER,
            dependencies=["1"]
        )
        assert "1" in task.dependencies


class TestComplexityAssessment:
    def setup_method(self):
        self.factory = MagicMock()
        self.orchestrator = MultiAgentOrchestrator(self.factory)

    def test_complex_task(self):
        result = self.orchestrator._assess_complexity("重构整个系统架构")
        assert result == "complex"

    def test_medium_task(self):
        result = self.orchestrator._assess_complexity("添加功能修改代码优化性能")
        assert result in ("medium", "complex", "simple")

    def test_simple_task(self):
        result = self.orchestrator._assess_complexity("创建hello.py")
        assert result == "simple"

    def test_auto_complexity_with_keywords(self):
        result = self.orchestrator._assess_complexity("系统迁移到新架构")
        assert result == "complex"

    def test_auto_complexity_optimization(self):
        result = self.orchestrator._assess_complexity("优化性能")
        assert result == "medium"


class TestSimpleTaskExecution:
    @pytest.mark.asyncio
    async def test_simple_task_runs_single_agent(self):
        tools = ToolRegistry()
        tools.register(name="read_file", description="读取文件", parameters={"type": "object", "properties": {}}, handler=lambda: "content", is_read_only=True)

        class SimpleFactory:
            def create(self, **kwargs):
                return Harness(
                    model_engine=MockModelEngine(scenario="default"),
                    tool_registry=tools,
                    sandbox=Sandbox(use_docker=False),
                    permission_manager=PermissionManager(level=PermissionLevel.AUTO_WRITE),
                    max_turns=3,
                    token_budget=10000
                )

        orchestrator = MultiAgentOrchestrator(SimpleFactory())
        result = await orchestrator.run_task("简单任务", complexity="simple")
        assert result["strategy"] == "single_agent"
        assert "summary" in result


class TestMediumTaskExecution:
    @pytest.mark.asyncio
    async def test_medium_task_decomposes(self):
        tools = ToolRegistry()
        tools.register(name="read_file", description="读取文件", parameters={"type": "object", "properties": {}}, handler=lambda: "content", is_read_only=True)

        class SimpleFactory:
            def create(self, **kwargs):
                return Harness(
                    model_engine=MockModelEngine(scenario="default"),
                    tool_registry=tools,
                    sandbox=Sandbox(use_docker=False),
                    permission_manager=PermissionManager(level=PermissionLevel.AUTO_WRITE),
                    max_turns=2,
                    token_budget=5000
                )

        orchestrator = MultiAgentOrchestrator(SimpleFactory())
        result = await orchestrator.run_task("添加用户修改功能", complexity="medium")
        assert result["strategy"] == "sequential"
        assert "results" in result


class TestComplexTaskExecution:
    @pytest.mark.asyncio
    async def test_complex_task_dag(self):
        tools = ToolRegistry()
        tools.register(name="read_file", description="读取文件", parameters={"type": "object", "properties": {}}, handler=lambda: "content", is_read_only=True)

        class SimpleFactory:
            def create(self, **kwargs):
                return Harness(
                    model_engine=MockModelEngine(scenario="default"),
                    tool_registry=tools,
                    sandbox=Sandbox(use_docker=False),
                    permission_manager=PermissionManager(level=PermissionLevel.AUTO_WRITE),
                    max_turns=2,
                    token_budget=5000
                )

        orchestrator = MultiAgentOrchestrator(SimpleFactory())
        result = await orchestrator.run_task("重构并优化整个模块", complexity="complex")
        assert result["strategy"] == "dag_parallel"
        assert "rfc" in result
        assert "completed_tasks" in result


class TestDAGExecution:
    def test_build_dag(self):
        factory = MagicMock()
        orchestrator = MultiAgentOrchestrator(factory)
        rfc = {
            "components": [
                {"name": "A", "description": "Component A"},
                {"name": "B", "description": "Component B"}
            ],
            "dependencies": [
                {"from": "A", "to": "B"}
            ]
        }
        dag = orchestrator._build_dag(rfc)
        assert "A" in dag["nodes"]
        assert "B" in dag["nodes"]
        assert "A" in dag["deps"]["B"]

    @pytest.mark.asyncio
    async def test_execute_dag_parallel(self):
        tools = ToolRegistry()
        tools.register(name="read_file", description="读取文件", parameters={"type": "object", "properties": {}}, handler=lambda: "content", is_read_only=True)

        class SimpleFactory:
            def create(self, **kwargs):
                return Harness(
                    model_engine=MockModelEngine(scenario="default"),
                    tool_registry=tools,
                    sandbox=Sandbox(use_docker=False),
                    permission_manager=PermissionManager(level=PermissionLevel.AUTO_WRITE),
                    max_turns=2,
                    token_budget=5000
                )

        orchestrator = MultiAgentOrchestrator(SimpleFactory())
        dag = {
            "nodes": {
                "A": {"description": "Task A"},
                "B": {"description": "Task B"}
            },
            "deps": {"A": [], "B": []},
            "execution_order": []
        }
        results = await orchestrator._execute_dag(dag)
        assert "A" in results
        assert "B" in results
        assert len(dag["execution_order"]) == 2

    @pytest.mark.asyncio
    async def test_execute_dag_with_dependency(self):
        tools = ToolRegistry()
        tools.register(name="read_file", description="读取文件", parameters={"type": "object", "properties": {}}, handler=lambda: "content", is_read_only=True)

        class SimpleFactory:
            def create(self, **kwargs):
                return Harness(
                    model_engine=MockModelEngine(scenario="default"),
                    tool_registry=tools,
                    sandbox=Sandbox(use_docker=False),
                    permission_manager=PermissionManager(level=PermissionLevel.AUTO_WRITE),
                    max_turns=2,
                    token_budget=5000
                )

        orchestrator = MultiAgentOrchestrator(SimpleFactory())
        dag = {
            "nodes": {
                "A": {"description": "Task A"},
                "B": {"description": "Task B (depends on A)"}
            },
            "deps": {"A": [], "B": ["A"]},
            "execution_order": []
        }
        results = await orchestrator._execute_dag(dag)
        assert len(dag["execution_order"]) == 2
        assert dag["execution_order"].index("A") < dag["execution_order"].index("B")


class TestSpawnAgent:
    @pytest.mark.asyncio
    async def test_spawn_agent(self):
        tools = ToolRegistry()
        tools.register(name="read_file", description="读取文件", parameters={"type": "object", "properties": {}}, handler=lambda: "content", is_read_only=True)

        class SimpleFactory:
            def create(self, **kwargs):
                return Harness(
                    model_engine=MockModelEngine(scenario="default"),
                    tool_registry=tools,
                    sandbox=Sandbox(use_docker=False),
                    permission_manager=PermissionManager(level=PermissionLevel.AUTO_WRITE),
                    max_turns=2,
                    token_budget=5000
                )

        orchestrator = MultiAgentOrchestrator(SimpleFactory())
        agent_id = await orchestrator.spawn_agent(
            archetype=AgentArchetype.BUILDER,
            task="test task"
        )
        assert "builder" in agent_id
        assert agent_id in orchestrator.agents


class TestGenerateRFC:
    @pytest.mark.asyncio
    async def test_generate_rfc(self):
        factory = MagicMock()
        orchestrator = MultiAgentOrchestrator(factory)
        rfc = await orchestrator._generate_rfc("create a web app")
        assert "title" in rfc
        assert "components" in rfc
        assert "dependencies" in rfc
