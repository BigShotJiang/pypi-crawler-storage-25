"""
工具系统测试
- ToolRegistry 注册/查询/执行
- ToolSchema 三层懒加载 (Tier1/Tier2/Tier3)
- ToolPredictor 预测性选择
- FileTools / ShellTools / GitTools / TestTools 实现
"""
import pytest
import asyncio
import os
import tempfile
import shutil
from liu_agent.harness.core_loop import ToolCall, ToolResult
from liu_agent.tools.tool_registry import ToolRegistry, ToolSchema, ToolPredictor
from liu_agent.tools.implementations import FileTools, ShellTools, GitTools, TestTools, BuildTools


class TestToolSchema:
    def test_tier1_short_description(self):
        schema = ToolSchema(
            name="test_tool",
            description="A" * 200,
            parameters={"type": "object", "properties": {}},
            is_read_only=True
        )
        tier1 = schema.to_tier1()
        assert tier1["name"] == "test_tool"
        assert "..." in tier1["description"]
        assert len(tier1["description"]) < 200

    def test_tier1_normal_description(self):
        schema = ToolSchema(
            name="test_tool",
            description="short desc",
            parameters={"type": "object", "properties": {}}
        )
        tier1 = schema.to_tier1()
        assert tier1["description"] == "short desc"

    def test_tier2_full_schema(self):
        schema = ToolSchema(
            name="read_file",
            description="读取文件",
            parameters={"type": "object", "properties": {"path": {"type": "string"}}},
            is_read_only=True
        )
        tier2 = schema.to_tier2()
        assert tier2["name"] == "read_file"
        assert "parameters" in tier2
        assert tier2["read_only"] is True


class TestToolPredictor:
    def test_index_and_predict(self):
        predictor = ToolPredictor()
        predictor.index_tool("read_file", ToolSchema(
            name="read_file", description="读取文件内容",
            parameters={}, tags=["file", "read"]
        ))
        predictor.index_tool("write_file", ToolSchema(
            name="write_file", description="写入文件内容",
            parameters={}, tags=["file", "write"]
        ))
        predictor.index_tool("execute_shell", ToolSchema(
            name="execute_shell", description="执行shell命令",
            parameters={}, tags=["shell", "system"]
        ))

        results = predictor.predict("读取代码文件", ["read_file", "write_file", "execute_shell"], top_k=2)
        assert "read_file" in results
        assert len(results) <= 2

    def test_predict_empty_context(self):
        predictor = ToolPredictor()
        predictor.index_tool("tool1", ToolSchema(
            name="tool1", description="test", parameters={}
        ))
        results = predictor.predict("", ["tool1", "tool2"], top_k=5)
        assert len(results) <= 5

    def test_predict_fills_to_top_k(self):
        predictor = ToolPredictor()
        predictor.index_tool("a", ToolSchema(name="a", description="alpha", parameters={}))
        predictor.index_tool("b", ToolSchema(name="b", description="beta", parameters={}))
        predictor.index_tool("c", ToolSchema(name="c", description="gamma", parameters={}))
        results = predictor.predict("alpha", ["a", "b", "c"], top_k=3)
        assert "a" in results


class TestToolRegistry:
    def test_register_tool(self):
        registry = ToolRegistry()
        registry.register(
            name="test_tool",
            description="测试工具",
            parameters={"type": "object", "properties": {}},
            handler=lambda: "result",
            is_read_only=True
        )
        assert "test_tool" in registry.list_tools()

    def test_register_multiple_tools(self):
        registry = ToolRegistry()
        for i in range(5):
            registry.register(
                name=f"tool_{i}",
                description=f"工具 {i}",
                parameters={"type": "object", "properties": {}},
                handler=lambda: f"result_{i}",
                is_read_only=True
            )
        assert len(registry.list_tools()) == 5

    @pytest.mark.asyncio
    async def test_execute_tool(self):
        registry = ToolRegistry()
        call_count = 0

        async def my_handler(name: str = "world"):
            nonlocal call_count
            call_count += 1
            return f"hello {name}"

        registry.register(
            name="greet",
            description="问候",
            parameters={"type": "object", "properties": {"name": {"type": "string"}}},
            handler=my_handler,
            is_read_only=True
        )

        tool_call = ToolCall(id="1", name="greet", parameters={"name": "test"})
        result = await registry.execute(tool_call)
        assert "hello test" in result
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_execute_sync_handler(self):
        registry = ToolRegistry()

        def sync_handler(x: int = 0):
            return x * 2

        registry.register(
            name="double",
            description="翻倍",
            parameters={"type": "object", "properties": {"x": {"type": "integer"}}},
            handler=sync_handler
        )

        tool_call = ToolCall(id="1", name="double", parameters={"x": 5})
        result = await registry.execute(tool_call)
        assert result == "10"

    @pytest.mark.asyncio
    async def test_execute_unknown_tool(self):
        registry = ToolRegistry()
        tool_call = ToolCall(id="1", name="nonexistent", parameters={})
        with pytest.raises(ValueError, match="未知工具"):
            await registry.execute(tool_call)

    def test_get_active_tools_tier1(self):
        registry = ToolRegistry(default_top_k=10)
        for i in range(3):
            registry.register(
                name=f"tool_{i}",
                description=f"工具 {i}",
                parameters={"type": "object", "properties": {}},
                handler=lambda: "",
                is_read_only=True
            )

        tools = registry.get_active_tools()
        assert len(tools) == 3
        assert all("name" in t for t in tools)

    def test_get_active_tools_tier3_prediction(self):
        registry = ToolRegistry(default_top_k=2)
        registry.register(
            name="read_file",
            description="读取文件内容 代码查看",
            parameters={"type": "object", "properties": {}},
            handler=lambda: "",
            tags=["file", "read"]
        )
        registry.register(
            name="write_file",
            description="写入文件",
            parameters={"type": "object", "properties": {}},
            handler=lambda: "",
            tags=["file", "write"]
        )
        registry.register(
            name="execute_shell",
            description="执行命令 shell",
            parameters={"type": "object", "properties": {}},
            handler=lambda: "",
            tags=["shell", "system"]
        )

        tools = registry.get_active_tools(context="读取代码文件", top_k=2)
        assert len(tools) <= 2
        assert "parameters" in tools[0]

    def test_is_read_only(self):
        registry = ToolRegistry()
        registry.register(name="r", description="r", parameters={}, handler=lambda: "", is_read_only=True)
        registry.register(name="w", description="w", parameters={}, handler=lambda: "", is_read_only=False)

        assert registry.is_read_only(ToolCall(id="1", name="r", parameters={})) is True
        assert registry.is_read_only(ToolCall(id="2", name="w", parameters={})) is False

    def test_get_tool_schema(self):
        registry = ToolRegistry()
        registry.register(
            name="my_tool",
            description="my tool",
            parameters={"type": "object", "properties": {"x": {"type": "int"}}},
            handler=lambda: ""
        )
        schema = registry.get_tool_schema("my_tool")
        assert schema is not None
        assert schema.name == "my_tool"
        assert registry.get_tool_schema("nonexistent") is None


class TestFileTools:
    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()

    def teardown_method(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    @pytest.mark.asyncio
    async def test_write_and_read_file(self):
        path = os.path.join(self.tmpdir, "test.txt")
        result = await FileTools.write_file(path, "hello world")
        assert "成功" in result

        content = await FileTools.read_file(path)
        assert content == "hello world"

    @pytest.mark.asyncio
    async def test_read_nonexistent_file(self):
        result = await FileTools.read_file(os.path.join(self.tmpdir, "nonexistent.txt"))
        assert "错误" in result

    @pytest.mark.asyncio
    async def test_edit_file(self):
        path = os.path.join(self.tmpdir, "edit_test.py")
        await FileTools.write_file(path, "def foo():\n    pass\n")
        result = await FileTools.edit_file(path, "pass", "return 42")
        assert "成功" in result

        content = await FileTools.read_file(path)
        assert "return 42" in content

    @pytest.mark.asyncio
    async def test_edit_file_not_found_string(self):
        path = os.path.join(self.tmpdir, "edit_test2.py")
        await FileTools.write_file(path, "hello world\n")
        result = await FileTools.edit_file(path, "not_exist", "new")
        assert "错误" in result

    @pytest.mark.asyncio
    async def test_list_directory(self):
        result = await FileTools.list_directory(self.tmpdir)
        assert isinstance(result, str)

    @pytest.mark.asyncio
    async def test_list_nonexistent_directory(self):
        result = await FileTools.list_directory("/nonexistent/path")
        assert "错误" in result

    @pytest.mark.asyncio
    async def test_search_code(self):
        py_file = os.path.join(self.tmpdir, "sample.py")
        await FileTools.write_file(py_file, "def hello():\n    print('hello')\n")

        results = await FileTools.search_code("hello", self.tmpdir)
        assert "hello" in results

    @pytest.mark.asyncio
    async def test_search_code_no_match(self):
        results = await FileTools.search_code("zzz_nonexistent_zzz", self.tmpdir)
        assert "未找到" in results

    @pytest.mark.asyncio
    async def test_glob_pattern(self):
        py_file = os.path.join(self.tmpdir, "test_glob.py")
        await FileTools.write_file(py_file, "print('test')\n")

        results = await FileTools.glob("*.py", self.tmpdir)
        assert "test_glob.py" in results

    @pytest.mark.asyncio
    async def test_glob_no_match(self):
        results = await FileTools.glob("*.xyz123", self.tmpdir)
        assert "未找到" in results


class TestShellTools:
    @pytest.mark.asyncio
    async def test_execute_echo(self):
        result = await ShellTools.execute_shell("echo hello")
        assert "hello" in result

    @pytest.mark.asyncio
    async def test_execute_failing_command(self):
        result = await ShellTools.execute_shell("false")
        assert "exit_code" in result

    @pytest.mark.asyncio
    async def test_execute_timeout(self):
        result = await ShellTools.execute_shell("sleep 10", timeout=1)
        assert "超时" in result


class TestGitTools:
    @pytest.mark.asyncio
    async def test_git_status_not_repo(self):
        result = await GitTools.git_status()
        assert isinstance(result, str)


class TestTestTools:
    @pytest.mark.asyncio
    async def test_run_tests_unsupported_framework(self):
        result = await TestTools.run_tests(framework="mocha")
        assert "不支持" in result

    @pytest.mark.asyncio
    async def test_run_linter(self):
        result = await TestTools.run_linter("/nonexistent")
        assert isinstance(result, str)


class TestBuildTools:
    @pytest.mark.asyncio
    async def test_project_structure_no_path(self):
        tmpdir = tempfile.mkdtemp()
        result = await BuildTools.check_project_structure(tmpdir)
        data = __import__("json").loads(result)
        assert "languages" in data
        shutil.rmtree(tmpdir, ignore_errors=True)
