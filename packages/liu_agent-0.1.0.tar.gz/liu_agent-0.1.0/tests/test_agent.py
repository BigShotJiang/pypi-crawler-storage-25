"""
测试文件
"""
import pytest
import asyncio
from liu_agent.harness.core_loop import Harness, ToolCall, ToolResult, Turn
from liu_agent.tools.tool_registry import ToolRegistry
from liu_agent.model.engine import MockModelEngine
from liu_agent.environment.sandbox import Sandbox


@pytest.fixture
def basic_harness():
    """创建基础 Harness 实例"""
    model = MockModelEngine(scenario="default")
    tools = ToolRegistry()
    sandbox = Sandbox(use_docker=False)

    return Harness(
        model_engine=model,
        tool_registry=tools,
        sandbox=sandbox,
        max_turns=10,
        token_budget=50000
    )


@pytest.mark.asyncio
async def test_harness_initialization(basic_harness):
    """测试 Harness 初始化"""
    assert basic_harness.state.name == "IDLE"
    assert basic_harness.max_turns == 10
    assert basic_harness.token_budget == 50000


@pytest.mark.asyncio
async def test_harness_run_single_turn(basic_harness):
    """测试单轮执行"""
    turns = []
    async for turn in basic_harness.run("测试任务"):
        turns.append(turn)

    assert len(turns) >= 1
    assert turns[-1].state.name == "COMPLETED"


@pytest.mark.asyncio
async def test_tool_registry():
    """测试工具注册表"""
    registry = ToolRegistry()

    # 注册测试工具
    registry.register(
        name="test_tool",
        description="测试工具",
        parameters={"type": "object", "properties": {}},
        handler=lambda: "test_result",
        is_read_only=True
    )

    assert "test_tool" in registry.list_tools()

    # 测试懒加载
    tools = registry.get_active_tools()
    assert len(tools) == 1
    assert "name" in tools[0]


@pytest.mark.asyncio
async def test_sandbox_local():
    """测试本地沙箱"""
    sandbox = Sandbox(use_docker=False)

    # 测试执行命令
    result = await sandbox.execute("echo hello")
    assert result["exit_code"] == 0
    assert "hello" in result["stdout"]

    # 测试文件操作
    sandbox.write_workspace_file("test.txt", "test content")
    content = sandbox.read_workspace_file("test.txt")
    assert content == "test content"

    await sandbox.cleanup()


@pytest.mark.asyncio
async def test_context_compressor():
    """测试上下文压缩"""
    from liu_agent.harness.context_compressor import ContextCompressor, CompressionConfig

    compressor = ContextCompressor(
        config=CompressionConfig(snip_threshold=100)
    )

    messages = [
        {"role": "system", "content": "system prompt"},
        {"role": "user", "content": "a" * 200}  # 长消息
    ]

    compressed = compressor.compress(messages, max_tokens=1000)
    assert len(compressed) <= len(messages)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
