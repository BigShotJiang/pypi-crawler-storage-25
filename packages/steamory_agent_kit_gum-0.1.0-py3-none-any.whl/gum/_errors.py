from __future__ import annotations

from typing import Any

import httpx


class GumError(Exception):
    """Base class for Gum SDK errors."""


class GumApiError(GumError):
    """Raised when the Gum API returns a non-2xx response."""

    def __init__(
        self,
        *,
        status_code: int,
        status_text: str,
        headers: httpx.Headers,
        body: Any,
    ) -> None:
        self.status_code = status_code
        self.status = status_code
        self.status_text = status_text
        self.headers = headers
        self.body = body
        self.detail = _get_error_detail(body)
        message = (
            self.detail
            if isinstance(self.detail, str)
            else f"Gum API request failed with status {status_code}"
        )
        super().__init__(message)


class GumConnectionError(GumError):
    """Raised when a request fails before Gum returns a response."""

    def __init__(self, message: str, cause: BaseException) -> None:
        self.cause = cause
        super().__init__(message)


class GumTimeoutError(GumConnectionError):
    """Raised when a request times out."""

    def __init__(self, timeout_ms: int, cause: BaseException) -> None:
        self.timeout_ms = timeout_ms
        super().__init__(f"Gum API request timed out after {timeout_ms}ms", cause)


def _get_error_detail(body: Any) -> Any:
    if isinstance(body, dict) and "detail" in body:
        return body["detail"]
    return None

