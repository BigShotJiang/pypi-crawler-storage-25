from __future__ import annotations

from typing import Any, Mapping, Optional, Sequence, Union, cast

import httpx

from ._types import (
    ActionLogInput,
    AddMessagesRequest,
    GetSessionMemoryParams,
    GumEnvelope,
    Message,
    RequestOptions,
    SessionCreateRequest,
)
from ._utils import (
    DEFAULT_TIMEOUT_MS,
    build_query,
    encode_path_segment,
    merge_headers,
    normalize_api_key,
    normalize_host,
    parse_response,
    raise_for_status,
    request_timeout_ms,
    serialize_body,
    timeout_from_ms,
    wrap_request_error,
)


class GumClient:
    """Synchronous client for the Gum Memory API."""

    def __init__(
        self,
        api_key: str,
        host: Optional[str] = None,
        timeout_ms: Optional[int] = DEFAULT_TIMEOUT_MS,
        headers: Optional[Mapping[str, str]] = None,
        client: Optional[httpx.Client] = None,
    ) -> None:
        self.host = normalize_host(host)
        self.timeout_ms = timeout_ms
        self._api_key = normalize_api_key(api_key)
        self._headers = headers
        self._owns_client = client is None
        self._client = client or httpx.Client(trust_env=False)
        self.sessions = SessionsResource(self)
        self.user_actions = UserActionsResource(self)

    def __enter__(self) -> "GumClient":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def health(self, options: Optional[RequestOptions] = None) -> Any:
        return self.request("GET", "/healthz", options=options)

    def request(
        self,
        method: str,
        path: str,
        body: Any = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        timeout_ms = request_timeout_ms(self.timeout_ms, options)
        has_body = body is not None
        try:
            response = self._client.request(
                method,
                f"{self.host}{path}",
                headers=merge_headers(self._api_key, self._headers, options, has_body),
                json=serialize_body(body) if has_body else None,
                timeout=timeout_from_ms(timeout_ms),
            )
        except httpx.HTTPError as error:
            raise wrap_request_error(error, timeout_ms) from error

        parsed = parse_response(response)
        raise_for_status(response, parsed)
        return parsed


class Session:
    def __init__(
        self,
        sessions: "SessionsResource",
        session_id: str,
        raw_response: GumEnvelope,
    ) -> None:
        self._sessions = sessions
        self.id = session_id
        self.raw_response = raw_response

    def add_message(
        self,
        message: Message,
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        return self.add_messages([message], options)

    def add_messages(
        self,
        input: Union[AddMessagesRequest, Sequence[Message]],
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        return self._sessions.add_messages(self.id, input, options)

    def get_memory(
        self,
        params: Optional[GetSessionMemoryParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        return self._sessions.get_memory(self.id, params, options)


class SessionsResource:
    def __init__(self, client: GumClient) -> None:
        self._client = client

    def from_id(self, session_id: str) -> Session:
        return Session(self, session_id, {"data": {"session_id": session_id}})

    def create(
        self,
        input: SessionCreateRequest,
        options: Optional[RequestOptions] = None,
    ) -> Session:
        response = cast(GumEnvelope, self._client.request("POST", "/api/sessions", input, options))
        session_id = _extract_session_id(response)
        return Session(self, session_id, response)

    def add_messages(
        self,
        session_id: str,
        input: Union[AddMessagesRequest, Sequence[Message]],
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        body: Any = {"messages": list(input)} if isinstance(input, (list, tuple)) else input
        return cast(
            GumEnvelope,
            self._client.request(
                "POST",
                f"/api/sessions/{encode_path_segment(session_id)}/messages",
                body,
                options,
            ),
        )

    def get_memory(
        self,
        session_id: str,
        params: Optional[GetSessionMemoryParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        memory_params: GetSessionMemoryParams = params or {}
        query = build_query(
            {
                "query": memory_params.get("query"),
                "details": memory_params.get("details"),
            }
        )
        path = f"/api/sessions/{encode_path_segment(session_id)}/context{query}"

        if "recall_config" in memory_params:
            return cast(
                GumEnvelope,
                self._client.request(
                    "POST",
                    path,
                    {"recall_config": memory_params.get("recall_config")},
                    options,
                ),
            )

        return cast(GumEnvelope, self._client.request("GET", path, options=options))


class UserActionsResource:
    def __init__(self, client: GumClient) -> None:
        self._client = client

    def create(
        self,
        input: ActionLogInput,
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        return cast(GumEnvelope, self._client.request("POST", "/api/user/actions", input, options))


def _extract_session_id(response: Any) -> str:
    if isinstance(response, dict):
        data = response.get("data")
        if isinstance(data, dict):
            session_id = data.get("session_id")
            if isinstance(session_id, str) and session_id:
                return session_id
    raise ValueError("Gum API did not return data.session_id")
