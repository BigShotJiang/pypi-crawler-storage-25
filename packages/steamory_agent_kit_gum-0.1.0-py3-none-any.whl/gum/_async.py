from __future__ import annotations

from typing import Any, Mapping, Optional, Sequence, Union, cast

import httpx

from ._sync import _extract_session_id
from ._types import (
    ActionLogInput,
    AddMessagesRequest,
    GetSessionMemoryParams,
    GumEnvelope,
    Message,
    RequestOptions,
    SessionCreateRequest,
)
from ._utils import (
    DEFAULT_TIMEOUT_MS,
    build_query,
    encode_path_segment,
    merge_headers,
    normalize_api_key,
    normalize_host,
    parse_response,
    raise_for_status,
    request_timeout_ms,
    serialize_body,
    timeout_from_ms,
    wrap_request_error,
)


class AsyncGumClient:
    """Asynchronous client for the Gum Memory API."""

    def __init__(
        self,
        api_key: str,
        host: Optional[str] = None,
        timeout_ms: Optional[int] = DEFAULT_TIMEOUT_MS,
        headers: Optional[Mapping[str, str]] = None,
        client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        self.host = normalize_host(host)
        self.timeout_ms = timeout_ms
        self._api_key = normalize_api_key(api_key)
        self._headers = headers
        self._owns_client = client is None
        self._client = client or httpx.AsyncClient(trust_env=False)
        self.sessions = AsyncSessionsResource(self)
        self.user_actions = AsyncUserActionsResource(self)

    async def __aenter__(self) -> "AsyncGumClient":
        return self

    async def __aexit__(self, exc_type: object, exc: object, traceback: object) -> None:
        await self.close()

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def health(self, options: Optional[RequestOptions] = None) -> Any:
        return await self.request("GET", "/healthz", options=options)

    async def request(
        self,
        method: str,
        path: str,
        body: Any = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        timeout_ms = request_timeout_ms(self.timeout_ms, options)
        has_body = body is not None
        try:
            response = await self._client.request(
                method,
                f"{self.host}{path}",
                headers=merge_headers(self._api_key, self._headers, options, has_body),
                json=serialize_body(body) if has_body else None,
                timeout=timeout_from_ms(timeout_ms),
            )
        except httpx.HTTPError as error:
            raise wrap_request_error(error, timeout_ms) from error

        parsed = parse_response(response)
        raise_for_status(response, parsed)
        return parsed


class AsyncSession:
    def __init__(
        self,
        sessions: "AsyncSessionsResource",
        session_id: str,
        raw_response: GumEnvelope,
    ) -> None:
        self._sessions = sessions
        self.id = session_id
        self.raw_response = raw_response

    async def add_message(
        self,
        message: Message,
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        return await self.add_messages([message], options)

    async def add_messages(
        self,
        input: Union[AddMessagesRequest, Sequence[Message]],
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        return await self._sessions.add_messages(self.id, input, options)

    async def get_memory(
        self,
        params: Optional[GetSessionMemoryParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        return await self._sessions.get_memory(self.id, params, options)


class AsyncSessionsResource:
    def __init__(self, client: AsyncGumClient) -> None:
        self._client = client

    def from_id(self, session_id: str) -> AsyncSession:
        return AsyncSession(self, session_id, {"data": {"session_id": session_id}})

    async def create(
        self,
        input: SessionCreateRequest,
        options: Optional[RequestOptions] = None,
    ) -> AsyncSession:
        response = cast(
            GumEnvelope,
            await self._client.request("POST", "/api/sessions", input, options),
        )
        session_id = _extract_session_id(response)
        return AsyncSession(self, session_id, response)

    async def add_messages(
        self,
        session_id: str,
        input: Union[AddMessagesRequest, Sequence[Message]],
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        body: Any = {"messages": list(input)} if isinstance(input, (list, tuple)) else input
        return cast(
            GumEnvelope,
            await self._client.request(
                "POST",
                f"/api/sessions/{encode_path_segment(session_id)}/messages",
                body,
                options,
            ),
        )

    async def get_memory(
        self,
        session_id: str,
        params: Optional[GetSessionMemoryParams] = None,
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        memory_params: GetSessionMemoryParams = params or {}
        query = build_query(
            {
                "query": memory_params.get("query"),
                "details": memory_params.get("details"),
            }
        )
        path = f"/api/sessions/{encode_path_segment(session_id)}/context{query}"

        if "recall_config" in memory_params:
            return cast(
                GumEnvelope,
                await self._client.request(
                    "POST",
                    path,
                    {"recall_config": memory_params.get("recall_config")},
                    options,
                ),
            )

        return cast(GumEnvelope, await self._client.request("GET", path, options=options))


class AsyncUserActionsResource:
    def __init__(self, client: AsyncGumClient) -> None:
        self._client = client

    async def create(
        self,
        input: ActionLogInput,
        options: Optional[RequestOptions] = None,
    ) -> GumEnvelope:
        return cast(
            GumEnvelope,
            await self._client.request("POST", "/api/user/actions", input, options),
        )
