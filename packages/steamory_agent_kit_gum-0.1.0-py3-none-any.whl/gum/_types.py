from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Mapping, Optional, TypeVar, Union

from typing_extensions import Literal, NotRequired, Required, TypedDict

T = TypeVar("T")

GumEnvelope = Dict[str, Any]
AnchorSet = Dict[str, str]
ProcessingStatus = Literal["pending", "chunked", "processed", "failed"]
QueryRouter = Literal["single_hop_direct", "single_hop_parallel", "multi_hop_chain"]


class GumClientOptions(TypedDict, total=False):
    api_key: Required[str]
    host: NotRequired[Optional[str]]
    timeout_ms: NotRequired[Optional[int]]
    headers: NotRequired[Optional[Mapping[str, str]]]


class RequestOptions(TypedDict, total=False):
    timeout_ms: NotRequired[Optional[int]]
    headers: NotRequired[Optional[Mapping[str, str]]]


class SessionCreateRequest(TypedDict, total=False):
    user_id: Required[str]
    title: NotRequired[Optional[str]]
    metadata: NotRequired[Optional[Dict[str, Any]]]


class Message(TypedDict, total=False):
    role: Required[str]
    content: Required[str]
    id: NotRequired[Optional[str]]
    metadata: NotRequired[Dict[str, Any]]
    timestamp: NotRequired[Optional[Union[str, datetime]]]
    created_at: NotRequired[Optional[Union[str, datetime]]]
    status: NotRequired[ProcessingStatus]


class AddMessagesRequest(TypedDict, total=False):
    messages: Required[List[Message]]
    user_id: NotRequired[Optional[str]]


class RecallConfig(TypedDict, total=False):
    message_recent_limit: NotRequired[int]
    message_semantic_top_k: NotRequired[int]
    message_semantic_min_score: NotRequired[float]
    query_router: NotRequired[Optional[QueryRouter]]
    observation_recent_limit: NotRequired[int]
    observation_semantic_top_k: NotRequired[int]
    observation_semantic_min_score: NotRequired[float]
    proposition_top_k: NotRequired[int]
    topic_top_k: NotRequired[int]
    observation_context_top_k: NotRequired[int]
    long_term_rrf_k: NotRequired[int]
    enable_long_term_rerank: NotRequired[bool]
    enable_long_term_recall: NotRequired[bool]


class GetSessionMemoryParams(TypedDict, total=False):
    query: NotRequired[str]
    details: NotRequired[bool]
    recall_config: NotRequired[Optional[RecallConfig]]


class CreateSessionResponse(TypedDict, total=False):
    session_id: Required[str]


class AddMessagesResponse(TypedDict, total=False):
    pass


class SessionMemory(TypedDict, total=False):
    messages: NotRequired[List[Any]]
    observations: NotRequired[List[Any]]
    propositions: NotRequired[List[Any]]


class ActionLog(TypedDict, total=False):
    user_id: Required[str]
    timestamp: Required[str]
    content: Required[str]
    log_id: NotRequired[Optional[str]]
    session_id: NotRequired[Optional[str]]
    device_id: NotRequired[Optional[str]]
    app: NotRequired[Optional[str]]
    platform: NotRequired[Optional[str]]
    event_type: NotRequired[Optional[str]]
    page: NotRequired[Optional[str]]
    anchors: NotRequired[Optional[AnchorSet]]
    metadata: NotRequired[Optional[Dict[str, Any]]]
    entities: NotRequired[Optional[List[str]]]


class ActionLogInput(TypedDict, total=False):
    user_id: Required[str]
    timestamp: Required[Union[str, datetime]]
    content: Required[str]
    log_id: NotRequired[Optional[str]]
    session_id: NotRequired[Optional[str]]
    device_id: NotRequired[Optional[str]]
    app: NotRequired[Optional[str]]
    platform: NotRequired[Optional[str]]
    event_type: NotRequired[Optional[str]]
    page: NotRequired[Optional[str]]
    anchors: NotRequired[Optional[AnchorSet]]
    metadata: NotRequired[Optional[Dict[str, Any]]]
    entities: NotRequired[Optional[List[str]]]


class CreateActionResponse(TypedDict, total=False):
    log_id: NotRequired[Optional[str]]

