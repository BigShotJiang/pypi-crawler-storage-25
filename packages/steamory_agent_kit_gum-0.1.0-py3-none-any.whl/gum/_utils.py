from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping, Optional
from urllib.parse import quote, urlencode

import httpx

from ._errors import GumApiError, GumConnectionError, GumTimeoutError
from ._types import RequestOptions

DEFAULT_HOST = "gum.asix.inc"
DEFAULT_TIMEOUT_MS = 30_000


def normalize_host(host: Optional[str] = None) -> str:
    value = DEFAULT_HOST if host is None else host
    trimmed = value.strip()
    if not trimmed:
        raise ValueError("host must not be empty")
    if trimmed.lower().startswith(("http://", "https://")):
        with_protocol = trimmed
    else:
        with_protocol = f"https://{trimmed}"
    return with_protocol.rstrip("/")


def normalize_api_key(api_key: str) -> str:
    trimmed = api_key.strip()
    if not trimmed:
        raise ValueError("api_key must not be empty")
    if trimmed.startswith("Api-Key "):
        return trimmed
    return f"Api-Key {trimmed}"


def encode_path_segment(value: str) -> str:
    return quote(value, safe="")


def build_query(params: Mapping[str, Any]) -> str:
    pairs = []
    for key, value in params.items():
        if value is None:
            continue
        pairs.append((key, serialize_query_value(value)))
    query = urlencode(pairs)
    return f"?{query}" if query else ""


def serialize_body(value: Any) -> Any:
    if isinstance(value, datetime):
        return serialize_datetime(value)
    if isinstance(value, list):
        return [serialize_body(item) for item in value]
    if isinstance(value, tuple):
        return [serialize_body(item) for item in value]
    if isinstance(value, dict):
        return {key: serialize_body(nested) for key, nested in value.items()}
    return value


def serialize_query_value(value: Any) -> str:
    if isinstance(value, datetime):
        return serialize_datetime(value)
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def serialize_datetime(value: datetime) -> str:
    if value.tzinfo is not None and value.utcoffset() == timezone.utc.utcoffset(value):
        utc_value = value.astimezone(timezone.utc).replace(tzinfo=None)
        return utc_value.isoformat(timespec="seconds") + "Z"
    return value.isoformat()


def timeout_from_ms(timeout_ms: Optional[int]) -> Optional[float]:
    if timeout_ms is None:
        return DEFAULT_TIMEOUT_MS / 1000
    if timeout_ms == 0:
        return None
    return timeout_ms / 1000


def merge_headers(
    authorization: str,
    default_headers: Optional[Mapping[str, str]],
    options: Optional[RequestOptions],
    has_body: bool,
) -> dict[str, str]:
    headers = {
        "Authorization": authorization,
        "Accept": "application/json",
    }
    if has_body:
        headers["Content-Type"] = "application/json"
    if default_headers:
        headers.update(default_headers)
    if options and options.get("headers"):
        headers.update(options["headers"] or {})
    return headers


def request_timeout_ms(
    default_timeout_ms: Optional[int],
    options: Optional[RequestOptions],
) -> Optional[int]:
    if options and "timeout_ms" in options:
        return options["timeout_ms"]
    return default_timeout_ms


def parse_response(response: httpx.Response) -> Any:
    if not response.content:
        return None
    content_type = response.headers.get("content-type", "")
    if "application/json" in content_type.lower():
        return response.json()
    return response.text


def raise_for_status(response: httpx.Response, body: Any) -> None:
    if response.is_success:
        return
    raise GumApiError(
        status_code=response.status_code,
        status_text=response.reason_phrase,
        headers=response.headers,
        body=body,
    )


def wrap_request_error(error: httpx.HTTPError, timeout_ms: Optional[int]) -> GumConnectionError:
    if isinstance(error, httpx.TimeoutException):
        return GumTimeoutError(timeout_ms or 0, error)
    return GumConnectionError("Gum API request failed", error)
