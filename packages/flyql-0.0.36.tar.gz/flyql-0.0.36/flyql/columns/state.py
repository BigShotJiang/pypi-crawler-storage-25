from enum import Enum


class State(Enum):
    ERROR = "Error"
    COLUMN = "Name"
    EXPECT_COLUMN = "ExpectColumn"
    EXPECT_ALIAS = "ExpectAlias"
    EXPECT_ALIAS_OPERATOR = "ExpectAliasOperator"
    EXPECT_ALIAS_DELIMITER = "ExpectAliasDelimiter"
    EXPECT_TRANSFORMER = "ExpectTransformer"
    TRANSFORMER = "Transformer"
    TRANSFORMER_COMPLETE = "TransformerComplete"
    TRANSFORMER_OPERATOR = "TransformerOperator"
    TRANSFORMER_ARGUMENT = "TransformerArgument"
    TRANSFORMER_ARGUMENT_DOUBLE_QUOTED = "TransformerArgumentDoubleQuoted"
    TRANSFORMER_ARGUMENT_SINGLE_QUOTED = "TransformerArgumentSingleQuoted"
    EXPECT_TRANSFORMER_ARGUMENT = "ExpectTransformerArgument"
    EXPECT_TRANSFORMER_ARGUMENT_DELIMITER = "ExpectTransformerArgumentDelimiter"
    SINGLE_QUOTED_ARGUMENT = "SingleQuotedArgument"
    DOUBLE_QUOTED_ARGUMENT = "DoubleQuotedArgument"
    TRANSFORMER_ARGUMENT_DELIMITER = "ArgumentDelimiter"
