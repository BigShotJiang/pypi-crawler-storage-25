from yta_editor_nodes.processor.video.transitions.base import _TransitionProcessor
from yta_editor_parameters.specifications import ParameterSpecification
from yta_editor_nodes_gpu.processor.video.transitions.direction_scaled import DirectionScaledTransitionNodeProcessorGPU


class DirectionScaledTransitionProcessor(_TransitionProcessor):
    """
    A transition between the frames of 2 videos that
    will make the first video dissapear going down and
    scaling, and make the second one appear just behind.

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU.

    Mandatory inputs:
    - `first_input`
    - `second_input`

    Optional inputs:
    - `None`

    Parameters:
    - `*x_direction`
    - `*y_direction`
    - `*scale`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['first_input', 'second_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'x_direction',
            type = float,
            is_required = True,
            default = 0.0,
            min = -1.0,
            max = 1.0
        ),
        ParameterSpecification(
            name = 'y_direction',
            type = float,
            is_required = True,
            default = 1.0,
            min = -1.0,
            max = 1.0
        ),
        ParameterSpecification(
            name = 'scale',
            type = float,
            is_required = True,
            default = 0.7,
            min = 0.5,
            max = 0.9
        )
    ]
    cpu_class = None
    gpu_class = DirectionScaledTransitionNodeProcessorGPU

    def _format_parameters(
        self,
        parameters: dict[str, any]
    ) -> dict[str, any]:
        # The 'x_direction' and 'y_direction' exist always
        parameters['direction'] = (parameters.pop('x_direction'), parameters.pop('y_direction'))

        return parameters