from yta_editor_nodes.utils import validate_render_target
from yta_editor_time.evaluation_context import EvaluationContext
from yta_editor_nodes.utils import render_context_to_gpu_render_context, render_context_to_cpu_render_context
from yta_editor_frame.decorators import force_frame
from yta_editor_frame.frame import Frame
from yta_editor_nodes_common import _Node
from typing import Union


class _ProcessorGPUAndCPU(
    _Node
):
    """
    *For internal use only*

    *Abstract class*

    Abstract class to share the common behaviour of
    being able to handle a process with a GPU and/or
    a CPU processor, chosen by the user.

    Mandatory inputs:
    - `None`

    Optional inputs:
    - `None`
    """

    mandatory_inputs = []
    optional_inputs = []
    parameters_specifications = []

    @property
    def is_gpu_available(
        self
    ) -> bool:
        """
        Boolean flag to indicate if the GPU is available
        or not, that means that the processor that uses
        GPU is set.
        """
        return self._processor_gpu is not None
    
    @property
    def is_cpu_available(
        self
    ) -> bool:
        """
        Boolean flag to indicate if the CPU is available
        or not, that means that the processor that uses
        CPU is set.
        """
        return self._processor_cpu is not None
    
    @property
    def _do_use_gpu(
        self
    ) -> bool:
        """
        *For internal use only*

        Check if we should use GPU or not, according
        to what the user is requesting within the
        `RenderContext`, but checking if it is
        available in the node itself.

        This method is useful to know if we have to
        transform a frame to a specific format (for
        GPU or CPU) before sending it as an argument.
        """
        from yta_editor_nodes.utils import _do_use_gpu

        return _do_use_gpu(
            node_processor = self,
            do_use_gpu = self.render_context.config.do_use_gpu
        )
    
    def __init__(
        self,
        render_context: 'RenderContext',
        processor_cpu: Union['_ProcessorGPU', None] = None,
        processor_gpu: Union['_ProcessorCPU', None] = None
    ):
        """
        The `processor_cpu` and `processor_gpu` have to be
        set by the developer when building the specific
        classes, but the `do_use_gpu` boolean flag will be
        set by the user when instantiating the class to
        choose between GPU and CPU.

        The `opengl_context` is needed to instantiate the
        GPU unit but also to transform the input into a
        `moderngl.Texture` if needed.
        """
        if (
            processor_cpu is None and
            processor_gpu is None
        ):
            raise Exception('No node processor provided. At least one node processor is needed.')

        self._processor_cpu: Union['_ProcessorCPU', None] = processor_cpu
        """
        *For internal use only*

        The transition processor that is able to do the
        processing by using the CPU. If it is None we cannot
        process it with CPU.
        """
        self._processor_gpu: Union['_ProcessorGPU', None] = processor_gpu
        """
        *For internal use only*

        The transition processor that is able to do the
        processing by using the GPU. If it is None we cannot
        process it with GPU.
        """
        self.render_context: 'RenderContext' = render_context
        """
        The `RenderContext` instance that stores all the
        configuration and resources we need to render,
        including the `opengl_context`.
        """

    def _get_processor(
        self
    ) -> Union['ProcessorGPU', 'ProcessorCPU']:
        """
        *For internal use only*

        Get the processor according to the configuration
        set in the `RenderContext` and if the one
        requested is available or not.
        """
        return (
            (
                # Prefer GPU if available
                self._processor_gpu or
                self._processor_cpu
            ) if self.render_context.config.do_use_gpu else (
                # Prefer CPU if available
                self._processor_cpu or
                self._processor_gpu
            )
        )

    # TODO: Maybe move to a more general thing (?)
    def _prepare_input(
        self,
        input: 'Frame',
        do_use_gpu: bool
    ) -> Union['moderngl.Texture', 'np.ndarray']:
        """
        *For internal use only*

        Prepare the `input` provided based on the `do_use_gpu`
        parameter given to be used with the processer,
        according to the availability.

        This method will transform a `texture` into a `numpy`
        array if they are asking for CPU and it is available,
        or a `numpy` into a `texture` if they are asking for
        GPU and it is available.
        """

        """
        We transform the input to a new format, if needed,
        but creating a new instance. We will need to
        handle the ownership and release the original
        input if needed.
        """
        return (
            # Return `moderngl.Texture`
            input.to_texture()#.resource.frame
            if do_use_gpu else
            # Return `np.ndarray`
            input.to_numpy()#.resource.frame
        )
    
    def _validate_and_prepare_inputs_for_node(
        self,
        inputs: dict[str, 'Frame'],
        do_use_gpu: bool
    ) -> dict[str, Union['np.ndarray', 'moderngl.Texture']]:
        """
        *For internal use only*

        Validate the `inputs` provided and prepare and
        convert them (if needed) to be used in CPU or GPU
        according to the `do_use_gpu` parameter.
        
        This must be done before sending the `inputs` to
        the node processor.
        """
        # 1. Validate
        super()._validate_inputs(inputs, 'Frame')

        """
        2. Prepare for the node (GPU or CPU)
        This will obtain the `np.ndarray` or the
        `moderngl.Texture` that will be send directly
        (unwrapped) to the specific nodes that accept
        only that raw input.
        """
        # 2. Prepare for the node (GPU or CPU), obtaining
        # the `np.ndarray` or `moderngl.Texture` directly
        for input_name in inputs:
            if inputs[input_name] is not None:
                """
                We make copies of 'Frame' with the format we need,
                so we keep them to be able to release them later,
                but what we need is the Texture or ndarray.
                """
                inputs[input_name] = self._prepare_input(
                    input = inputs[input_name],
                    do_use_gpu = do_use_gpu
                )

        return inputs
    
    def _format_parameters(
        self,
        parameters: dict[str, any]
    ) -> dict[str, any]:
        """
        *For internal use only*

        Format the parameters to be sent to the node.
        This method must be called after the parameters
        have been validated and prepared, and before
        sending them to the node so we can format some
        of them.

        For example, we use `x` and `y` parameters that
        we transform into a `position` tuple when being
        sent to the node. This is what must be done here.
        """
        return parameters
    
    def use_gpu(
        self
    ) -> '_Blender':
        """
        Activate the desire to use GPU (and no CPU) by
        setting the `do_use_gpu` parameter to `True`.
        """
        self.render_context.use_gpu()

        return self
    
    def use_cpu(
        self
    ) -> '_Blender':
        """
        Activate the desire to use CPU (and not GPU) by
        setting the `do_use_gpu` parameter to `False`.
        """
        self.render_context.use_cpu()

        return self

    @force_frame('inputs')
    def process(
        self,
        render_target: Union['RenderTarget', None],
        inputs: dict[str, 'Frame'],
        evaluation_context: EvaluationContext,
        parameters: dict[str, any] = {}
    ) -> Frame:
        """
        Prepare the `inputs` provided to be processed by
        this processor node according to if the GPU or
        CPU is requested and available, returning the
        result as a `moderngl.Texture` or a `np.ndarray`.
        """
        # Check if GPU is requested and available
        do_use_gpu = self._do_use_gpu

        # We cannot GPU without 'render_target'
        validate_render_target(
            render_target = render_target,
            do_use_gpu = do_use_gpu
        )
        
        """
        We changed this. Now we are receiving the whole
        'Frame' instances so we can release them.
        """
        input_frames: list['Frame'] = self._validate_and_prepare_inputs_for_node(
            inputs = inputs,
            do_use_gpu = do_use_gpu
        )
        # Get the Texture or ndarray to pass it
        inputs = {}
        for input_frame in input_frames:
            if input_frames[input_frame] is not None:
                inputs[input_frame] = input_frames[input_frame].resource.frame

        parameters = self._validate_and_prepare_parameters(
            parameters = parameters
        )
        parameters = self._format_parameters(
            parameters = parameters
        )

        processor = self._get_processor()

        # This will be 'np.ndarray' (CPU) or 'RenderTarget' (GPU)
        processed_frame = processor.process(
            render_target = render_target,
            inputs = inputs,
            render_context = self.render_context,
            evaluation_context = evaluation_context,
            # TODO: Should we pass 'dict' and parse again instead (?)
            **parameters
        )

        # Release the 'Frame' copies we made before
        for input_frame in input_frames:
            if input_frames[input_frame] is not None:
                """
                TODO: This exists at 'yta_editor.utils' but should
                be moved to the general utils to be able to use it
                here and not repeat the code
                """
                id_frame = id(input_frames[input_frame])
                try:
                    input_frames[input_frame].release()
                    print(f'Frame[id={id_frame}] released in "_ProcessorGPUandCPU.process()"')
                    # ConsolePrinter().print(f'Frame[id={id_frame}] released in "_ProcessorGPUandCPU.process()"')
                except:
                    print(f'Could not released in "_ProcessorGPUandCPU.process()"')
                    # ConsolePrinter().print(f'Could not released in "_ProcessorGPUandCPU.process()"')

        return Frame.from_frame(
            frame = processed_frame,
            render_context = self.render_context,
            metadata = {}
        )
        # If it is a special node and we know some
        # metadata we could store it in the `process`
        # method we use to overwrite in the subclass

class _ProcessorGPUAndCPUConfigured(
    _ProcessorGPUAndCPU
):
    """
    Class to define the behaviour of our nodes that
    are able to handle the inputs and process them
    with GPU and/or CPU, depending on how they are
    defined.
    
    This class has been created to be able to
    separate behaviour and configuration.
    """

    mandatory_inputs = []
    optional_inputs = []
    parameters_specifications = []
    # Nodes
    cpu_class: Union['NodeProcessorCPU', None] = None
    gpu_class: Union['NodeProcessorGPU', None] = None

    def __init_subclass__(
        cls,
        **kwargs
    ):
        super().__init_subclass__(**kwargs)

        # Children must define them
        if not hasattr(cls, 'mandatory_inputs'):
            raise Exception('The "mandatory_inputs" is not defined.')
        
        if not hasattr(cls, 'optional_inputs'):
            raise Exception('The "optional_inputs" is not defined.')
        
        if not hasattr(cls, 'parameters_specifications'):
            raise Exception('The "parameters_specifications" is not defined.')

        if (
            len(cls.mandatory_inputs) == 0 and
            len(cls.optional_inputs) == 0
        ):
            raise Exception('The mandatory and optional inputs lists are empty.')
        
        cpu_cls = getattr(cls, 'cpu_class', None)
        gpu_cls = getattr(cls, 'gpu_class', None)

        if (
            not cls._is_marker and
            cpu_cls is None and
            gpu_cls is None
        ):
            raise Exception('No CPU nor GPU node classes define. At least one is needed.')

    def __init__(
        self,
        render_context: 'RenderContext'
    ):
        if (
            self.gpu_class is not None and
            render_context._opengl_context is None
        ):
            raise Exception('The node has a GPU node processor but no OpenGLContext found in the RenderContext.')

        node_processor_cpu = (
            self.cpu_class(
                cpu_render_context = render_context_to_cpu_render_context(render_context)
            )
            if self.cpu_class is not None else
            None
        )

        node_processor_gpu = (
            self.gpu_class(
                gpu_render_context = render_context_to_gpu_render_context(render_context)
            )
            if self.gpu_class is not None else
            None
        )

        super().__init__(
            render_context = render_context,
            processor_cpu = node_processor_cpu,
            processor_gpu = node_processor_gpu
        )