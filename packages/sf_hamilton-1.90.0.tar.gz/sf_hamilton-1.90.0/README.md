<!--
     Licensed to the Apache Software Foundation (ASF) under one
     or more contributor license agreements.  See the NOTICE file
     distributed with this work for additional information
     regarding copyright ownership.  The ASF licenses this file
     to you under the Apache License, Version 2.0 (the
     "License"); you may not use this file except in compliance
     with the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing,
     software distributed under the License is distributed on an
     "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
     KIND, either express or implied.  See the License for the
     specific language governing permissions and limitations
     under the License.
-->

# sf-hamilton has moved to apache-hamilton

This package is a redirect. The Hamilton project is now developed under the
Apache Software Foundation as **Apache Hamilton (incubating)**.

## Migration

Replace `sf-hamilton` with `apache-hamilton` in your dependencies:

```bash
pip install apache-hamilton
```

All functionality is identical. The package name changed as part of the
move to the Apache Software Foundation.

For documentation and getting started, see:
- https://hamilton.apache.org/
- https://github.com/apache/hamilton
