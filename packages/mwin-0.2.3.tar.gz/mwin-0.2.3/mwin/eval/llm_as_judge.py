"""LLM as a judge
Calls default llm without base_url and api_key
Caller can set his/her model and llm inference serve.
llm_as_judge defaults to be tracked in a new 'mwin_judge' project
"""