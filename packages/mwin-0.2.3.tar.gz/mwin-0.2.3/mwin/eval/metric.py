"""Eval metric offered by mwin
mwin offers serveral basic metric for caller.
"""