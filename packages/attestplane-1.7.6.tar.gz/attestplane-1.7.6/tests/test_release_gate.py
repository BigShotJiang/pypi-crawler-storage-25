from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
SCRIPT_PATH = REPO_ROOT / "scripts/release/release_gate.py"

spec = importlib.util.spec_from_file_location("release_gate", SCRIPT_PATH)
assert spec is not None and spec.loader is not None
release_gate = importlib.util.module_from_spec(spec)
sys.modules["release_gate"] = release_gate
spec.loader.exec_module(release_gate)

REAL_RELEASE_PREP_RANGE_FILES = [
    "api/public/python_v1.json",
    "api/public/typescript_v1.json",
    "docs/release-notes/v1.7.5.draft.md",
    "docs/validation/local_codex_runner/issue-172/code.md",
    "release/artifacts/v1.7.5/artifact-manifest.json",
    "release/artifacts/v1.7.5/checksums.sha256",
    "scripts/local_codex_runner/run_once.py",
    "sdk/python/pyproject.toml",
    "sdk/python/src/attestplane/__init__.py",
    "sdk/python/src/attestplane/cli/main.py",
    "sdk/python/src/attestplane/verifier.py",
    "sdk/python/src/attestplane/verify_reason_codes.py",
    "sdk/python/tests/cli/test_verify_errors.py",
    "sdk/python/tests/test_local_codex_runner_queue.py",
    "sdk/python/tests/test_release_gate.py",
    "sdk/python/tests/test_stable_auto_train_queue.py",
    "sdk/python/uv.lock",
    "sdk/typescript/package-lock.json",
    "sdk/typescript/package.json",
    "sdk/typescript/src/index.ts",
    "sdk/typescript/src/index_version.ts",
    "sdk/typescript/src/verifier.ts",
    "sdk/typescript/src/verify_reason_codes.ts",
    "sdk/typescript/test/verifier.test.ts",
    "sdk/typescript/test/verify_reason_codes.test.ts",
    "tests/canonicalization/test_canonicalization_properties.py",
    "tests/local_codex_runner/test_run_once.py",
    "tests/verifier/test_verify_reason_codes.py",
]


def test_stable_patch_release_defaults_to_fast_track() -> None:
    decision = release_gate.decide_release_gate(
        release_tag="v0.8.10",
        channel="latest",
        labels=[],
        release_audit=False,
        milestone=None,
        dependency_major_bump=False,
        env={},
    )

    assert decision.track == "fast"
    assert decision.audit_required is False
    assert decision.reasons == ["default_fast_track"]


def test_major_boundary_uses_audit_track() -> None:
    decision = release_gate.decide_release_gate(
        release_tag="v1.0.0",
        channel="latest",
        labels=[],
        release_audit=False,
        milestone=None,
        dependency_major_bump=False,
        env={},
    )

    assert decision.track == "audit"
    assert decision.audit_required is True
    assert decision.reasons == ["major_boundary"]


def test_minor_zero_release_after_major_defaults_to_fast_track() -> None:
    decision = release_gate.decide_release_gate(
        release_tag="v1.1.0",
        channel="latest",
        labels=[],
        release_audit=False,
        milestone=None,
        dependency_major_bump=False,
        env={},
    )

    assert decision.track == "fast"
    assert decision.audit_required is False
    assert decision.reasons == ["default_fast_track"]


def test_next_major_zero_zero_release_uses_audit_track() -> None:
    decision = release_gate.decide_release_gate(
        release_tag="v2.0.0",
        channel="latest",
        labels=[],
        release_audit=False,
        milestone=None,
        dependency_major_bump=False,
        env={},
    )

    assert decision.track == "audit"
    assert decision.audit_required is True
    assert decision.reasons == ["major_boundary"]


def test_kill_switch_forces_fast_track_even_at_major_boundary() -> None:
    decision = release_gate.decide_release_gate(
        release_tag="v1.0.0",
        channel="latest",
        labels=[],
        release_audit=False,
        milestone=None,
        dependency_major_bump=False,
        env={"ATTESTPLANE_RELEASE_AUDIT": "off"},
    )

    assert decision.track == "fast"
    assert decision.audit_required is False
    assert decision.reasons == ["audit_disabled"]


def test_security_and_compat_labels_use_audit_track() -> None:
    decision = release_gate.decide_release_gate(
        release_tag="v0.8.10",
        channel="latest",
        labels=["security", "compat-break"],
        release_audit=False,
        milestone=None,
        dependency_major_bump=False,
        env={},
    )

    assert decision.track == "audit"
    assert decision.audit_required is True
    assert decision.reasons == ["label:compat-break", "label:security"]


def test_manual_release_audit_and_ga_ca_milestones_use_audit_track() -> None:
    ga = release_gate.decide_release_gate(
        release_tag="v0.8.10",
        channel="latest",
        labels=[],
        release_audit=False,
        milestone="GA",
        dependency_major_bump=False,
        env={},
    )
    manual_ca = release_gate.decide_release_gate(
        release_tag="v0.8.10",
        channel="latest",
        labels=[],
        release_audit=True,
        milestone="ca",
        dependency_major_bump=False,
        env={},
    )

    assert ga.track == "audit"
    assert ga.reasons == ["milestone:ga"]
    assert manual_ca.track == "audit"
    assert manual_ca.reasons == ["manual_release_audit", "milestone:ca"]


def test_dependency_major_bump_uses_audit_track() -> None:
    decision = release_gate.decide_release_gate(
        release_tag="v0.8.10",
        channel="latest",
        labels=[],
        release_audit=False,
        milestone=None,
        dependency_major_bump=True,
        env={},
    )

    assert decision.track == "audit"
    assert decision.reasons == ["dependency_major_bump"]


def test_audit_gate_blocks_without_verified_plan() -> None:
    decision = release_gate.decide_release_gate(
        release_tag="v1.0.0",
        channel="latest",
        labels=[],
        release_audit=False,
        milestone=None,
        dependency_major_bump=False,
        env={},
    )

    result = release_gate.validate_audit_verification(
        decision,
        audit_verified=False,
        audit_plan_url="",
    )

    assert result.allowed is False
    assert result.reason == "audit_required_without_verified_plan"


def test_audit_gate_allows_verified_plan() -> None:
    decision = release_gate.decide_release_gate(
        release_tag="v1.0.0",
        channel="latest",
        labels=[],
        release_audit=False,
        milestone=None,
        dependency_major_bump=False,
        env={},
    )

    result = release_gate.validate_audit_verification(
        decision,
        audit_verified=True,
        audit_plan_url="https://github.com/attestplane/attestplane/issues/1",
    )

    assert result.allowed is True
    assert result.reason == "audit_verified"


def test_product_delta_allows_product_implementation_change() -> None:
    result = release_gate.classify_product_delta(
        [
            "sdk/python/src/attestplane/verifier.py",
            "docs/release-notes/v1.6.3.md",
            "sdk/python/src/attestplane/__init__.py",
        ],
        labels=[],
        env={},
    )

    assert result.allowed is True
    assert result.reason == "product_implementation_delta"
    assert result.product_files == ["sdk/python/src/attestplane/verifier.py"]
    assert result.ignored_files == ["sdk/python/src/attestplane/__init__.py"]


def test_product_delta_allows_real_sdk_changes_in_release_prep_range() -> None:
    result = release_gate.classify_product_delta(REAL_RELEASE_PREP_RANGE_FILES, labels=[], env={})

    assert result.allowed is True
    assert result.reason == "product_implementation_delta"
    assert result.product_files == [
        "sdk/python/src/attestplane/cli/main.py",
        "sdk/python/src/attestplane/verifier.py",
        "sdk/python/src/attestplane/verify_reason_codes.py",
        "sdk/typescript/src/index.ts",
        "sdk/typescript/src/verifier.ts",
        "sdk/typescript/src/verify_reason_codes.ts",
    ]
    assert result.product_support_files == [
        "sdk/python/tests/cli/test_verify_errors.py",
        "sdk/python/tests/test_local_codex_runner_queue.py",
        "sdk/python/tests/test_release_gate.py",
        "sdk/python/tests/test_stable_auto_train_queue.py",
    ]
    assert result.support_only_files == [
        "api/public/python_v1.json",
        "api/public/typescript_v1.json",
        "docs/release-notes/v1.7.5.draft.md",
        "docs/validation/local_codex_runner/issue-172/code.md",
        "release/artifacts/v1.7.5/artifact-manifest.json",
        "release/artifacts/v1.7.5/checksums.sha256",
        "scripts/local_codex_runner/run_once.py",
        "sdk/typescript/test/verifier.test.ts",
        "sdk/typescript/test/verify_reason_codes.test.ts",
        "tests/canonicalization/test_canonicalization_properties.py",
        "tests/local_codex_runner/test_run_once.py",
        "tests/verifier/test_verify_reason_codes.py",
    ]
    assert result.ignored_files == [
        "sdk/python/pyproject.toml",
        "sdk/python/src/attestplane/__init__.py",
        "sdk/python/uv.lock",
        "sdk/typescript/package-lock.json",
        "sdk/typescript/package.json",
        "sdk/typescript/src/index_version.ts",
    ]


def test_product_delta_blocks_release_only_change() -> None:
    result = release_gate.classify_product_delta(
        [
            ".github/workflows/release-cd.yml",
            "scripts/release/stable_auto_train.py",
            "docs/release-notes/v1.6.3.md",
        ],
        labels=[],
        env={},
    )

    assert result.allowed is False
    assert result.reason == "product_delta_required_without_product_change"
    assert result.support_only_files == [
        ".github/workflows/release-cd.yml",
        "docs/release-notes/v1.6.3.md",
        "scripts/release/stable_auto_train.py",
    ]


def test_product_delta_allows_observability_release_planning_change() -> None:
    result = release_gate.classify_product_delta(
        [
            "docs/observability/events.md",
            "scripts/observability/events.py",
            "scripts/release/plan_to_issues.py",
            "tests/observability/test_events.py",
        ],
        labels=[],
        env={},
    )

    assert result.allowed is True
    assert result.reason == "product_implementation_delta"
    assert result.product_files == [
        "scripts/observability/events.py",
        "scripts/release/plan_to_issues.py",
    ]
    assert result.support_only_files == [
        "docs/observability/events.md",
        "tests/observability/test_events.py",
    ]


def test_product_delta_blocks_tests_without_product_code() -> None:
    result = release_gate.classify_product_delta(
        ["sdk/python/tests/test_verifier_negative.py"],
        labels=[],
        env={},
    )

    assert result.allowed is False
    assert result.reason == "product_support_delta_without_implementation"
    assert result.product_support_files == ["sdk/python/tests/test_verifier_negative.py"]


def test_product_delta_allows_explicit_bypass_label() -> None:
    result = release_gate.classify_product_delta(
        ["sdk/python/tests/test_verifier_negative.py"],
        labels=["test-only"],
        env={},
    )

    assert result.allowed is True
    assert result.reason == "product_support_delta_bypassed"


def test_product_delta_allows_explicit_bypass_env() -> None:
    result = release_gate.classify_product_delta(
        ["scripts/release/stable_auto_train.py"],
        labels=[],
        env={"ATTESTPLANE_PRODUCT_DELTA_BYPASS": "true"},
    )

    assert result.allowed is True
    assert result.reason == "product_delta_bypassed"
