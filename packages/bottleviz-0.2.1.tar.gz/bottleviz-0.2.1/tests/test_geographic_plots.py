"""
Test geographic plot types: Choropleth, Scatter Geo, Flow Map, Tile Map, Cartogram.
"""

import pytest
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend for testing

import bottleviz as vz
from bottleviz.exceptions import VisualizerError


# Skip all tests if geopandas not available
pytest.importorskip('geopandas')
from shapely.geometry import Polygon
import geopandas as gpd


def test_choropleth_success():
    """Test choropleth with valid GeoDataFrame."""
    poly1 = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    poly2 = Polygon([(1, 0), (2, 0), (2, 1), (1, 1)])
    gdf = gpd.GeoDataFrame({'val': [1, 2]}, geometry=[poly1, poly2])
    fig = vz.plot(gdf, kind='choropleth', geometry='geometry', value='val')
    assert fig is not None
    vz.close(fig)


def test_choropleth_missing_geometry():
    """Test choropleth raises error when geometry not provided."""
    df = pd.DataFrame({'val': [1, 2]})
    with pytest.raises(VisualizerError, match="requires 'geometry'"):
        vz.plot(df, kind='choropleth', value='val')


def test_choropleth_missing_value():
    """Test choropleth raises error when value column not provided."""
    poly = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    gdf = gpd.GeoDataFrame(geometry=[poly])
    with pytest.raises(VisualizerError, match="requires .* and .* columns"):
        vz.plot(gdf, kind='choropleth', geometry='geometry')


def test_scatter_geo_success():
    """Test scatter_geo with lat/lon columns."""
    df = pd.DataFrame({
        'lat': [40.7128, 34.0522],
        'lon': [-74.0060, -118.2437],
        'val': [10, 20]
    })
    fig = vz.plot(df, kind='scatter_geo', lat='lat', lon='lon', value='val')
    assert fig is not None
    vz.close(fig)


def test_scatter_geo_missing_latlon():
    """Test scatter_geo requires lat and lon columns."""
    df = pd.DataFrame({'val': [1, 2]})
    with pytest.raises(VisualizerError, match="requires 'lat' and 'lon'"):
        vz.plot(df, kind='scatter_geo', value='val')


def test_flow_map_success():
    """Test flow_map with origin and destination coordinates."""
    df = pd.DataFrame({
        'olat': [40.7128, 34.0522],
        'olon': [-74.0060, -118.2437],
        'dlat': [40.7589, 34.0522],
        'dlon': [-73.9851, -118.2437],
        'flow': [100, 200]
    })
    fig = vz.plot(df, kind='flow_map', origin_lat='olat', origin_lon='olon',
                  dest_lat='dlat', dest_lon='dlon')
    assert fig is not None
    vz.close(fig)


def test_flow_map_missing_coords():
    """Test flow_map requires both origin and destination coordinates."""
    df = pd.DataFrame({'olat': [40.7], 'olon': [-74.0]})
    with pytest.raises(VisualizerError, match="requires origin and destination coordinates"):
        vz.plot(df, kind='flow_map', origin_lat='olat', origin_lon='olon')


def test_tile_map_success():
    """Test tile_map with GeoDataFrame."""
    pytest.importorskip('contextily')
    poly = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    gdf = gpd.GeoDataFrame({'val': [1]}, geometry=[poly], crs='EPSG:4326')
    fig = vz.plot(gdf, kind='tile_map', value='val')
    assert fig is not None
    vz.close(fig)


def test_cartogram_success():
    """Test cartogram with GeoDataFrame."""
    poly = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    gdf = gpd.GeoDataFrame({'val': [1]}, geometry=[poly])
    fig = vz.plot(gdf, kind='cartogram', geometry='geometry', value='val')
    assert fig is not None
    vz.close(fig)
