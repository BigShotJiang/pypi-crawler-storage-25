"""
Test core functionality of BottleViz.
"""

import pytest
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend for testing

import bottleviz as vz
from bottleviz.exceptions import DataError, VisualizerError


class TestDataValidation:
    """Test data validation and conversion."""

    def test_validate_dataframe(self):
        """Test validation with pandas DataFrame."""
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
        validated = vz.utils.validate_data(df)
        assert len(validated) == 3
        assert list(validated.columns) == ['x', 'y']

    def test_validate_series(self):
        """Test validation with pandas Series."""
        s = pd.Series([1, 2, 3], name='values')
        validated = vz.utils.validate_data(s)
        assert 'values' in validated.columns
        assert len(validated) == 3

    def test_validate_numpy_array_1d(self):
        """Test validation with 1D numpy array."""
        arr = np.array([1, 2, 3, 4, 5])
        validated = vz.utils.validate_data(arr)
        assert '_values' in validated.columns
        assert len(validated) == 5

    def test_validate_numpy_array_2d(self):
        """Test validation with 2D numpy array."""
        arr = np.array([[1, 2], [3, 4], [5, 6]])
        validated = vz.utils.validate_data(arr)
        assert len(validated) == 3
        assert len(validated.columns) == 2

    def test_validate_list(self):
        """Test validation with Python list."""
        data = [1, 2, 3, 4, 5]
        validated = vz.utils.validate_data(data)
        assert '_values' in validated.columns
        assert len(validated) == 5

    def test_validate_dict(self):
        """Test validation with dictionary."""
        data = {'x': [1, 2, 3], 'y': [4, 5, 6]}
        validated = vz.utils.validate_data(data)
        assert set(validated.columns) == {'x', 'y'}
        assert len(validated) == 3

    def test_validate_none_raises(self):
        """Test that None data raises error."""
        with pytest.raises(DataError):
            vz.utils.validate_data(None)

    def test_validate_empty_dataframe_raises(self):
        """Test that empty DataFrame raises error."""
        df = pd.DataFrame()
        with pytest.raises(DataError):
            vz.utils.validate_data(df)

    def test_validate_missing_column_raises(self):
        """Test that missing column raises error."""
        df = pd.DataFrame({'x': [1, 2, 3]})
        with pytest.raises(DataError, match="Column 'y' not found"):
            vz.utils.validate_data(df, x='x', y='y')


class TestPlotTypeInference:
    """Test automatic plot type detection."""

    def test_infer_scatter(self):
        """Test scatter inference for two numeric columns."""
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
        plot_type = vz.utils.infer_plot_type(df, x='x', y='y')
        assert plot_type in ['scatter', 'line']

    def test_infer_histogram(self):
        """Test histogram inference for single numeric."""
        df = pd.DataFrame({'x': [1, 2, 3, 4, 5]})
        plot_type = vz.utils.infer_plot_type(df, y='x')
        assert plot_type == 'hist'

    def test_infer_line_for_sorted_x(self):
        """Test line inference for sorted x-axis."""
        df = pd.DataFrame({'x': [1, 2, 3, 4, 5], 'y': [2, 4, 6, 8, 10]})
        plot_type = vz.utils.infer_plot_type(df, x='x', y='y')
        assert plot_type == 'line'

    def test_infer_bar_for_categorical(self):
        """Test bar inference for categorical x."""
        df = pd.DataFrame({'cat': ['A', 'B', 'C'], 'val': [1, 2, 3]})
        plot_type = vz.utils.infer_plot_type(df, x='cat', y='val')
        assert plot_type == 'bar'

    def test_infer_box_for_multiple_numeric(self):
        """Test box inference for multiple numeric columns."""
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6], 'z': [7, 8, 9]})
        plot_type = vz.utils.infer_plot_type(df)
        assert plot_type in ['box', 'line']


class TestMainPlotFunction:
    """Test the main plot() function."""

    def test_basic_scatter(self):
        """Test basic scatter plot creation."""
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
        fig = vz.plot(df, x='x', y='y')
        assert fig is not None

    def test_automatic_plot_type(self):
        """Test automatic plot type detection."""
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
        fig = vz.plot(df, x='x', y='y')  # Should auto-detect
        assert fig is not None

    def test_explicit_plot_type(self):
        """Test forcing a specific plot type."""
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
        fig = vz.plot(df, x='x', y='y', kind='line')
        assert fig is not None

    def test_histogram(self):
        """Test histogram plot."""
        df = pd.DataFrame({'values': [1, 2, 2, 3, 3, 3, 4, 4, 5]})
        fig = vz.plot(df, kind='hist', x='values')
        assert fig is not None

    def test_bar_plot(self):
        """Test bar plot."""
        df = pd.DataFrame({'cat': ['A', 'B', 'C'], 'val': [1, 2, 3]})
        fig = vz.plot(df, x='cat', y='val', kind='bar')
        assert fig is not None

    def test_plot_with_title(self):
        """Test plot with custom title."""
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
        fig = vz.plot(df, x='x', y='y', title='My Plot')
        assert fig is not None

    def test_invalid_kind_raises(self):
        """Test that invalid plot kind raises error."""
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
        with pytest.raises(VisualizerError):
            vz.plot(df, x='x', y='y', kind='invalid_type')


class TestQuickPlot:
    """Test quickplot function."""

    def test_quickplot_with_list(self):
        """Test quickplot with simple list."""
        fig = vz.quickplot([1, 2, 3, 4, 5])
        assert fig is not None

    def test_quickplot_with_xy(self):
        """Test quickplot with x and y lists."""
        fig = vz.quickplot(x=[1, 2, 3], y=[4, 5, 6])
        assert fig is not None


class TestStyles:
    """Test style management."""

    def test_set_style_default(self):
        """Test setting default style."""
        vz.set_style('default')
        assert vz.get_current_style() == 'default'

    def test_set_style_dark(self):
        """Test setting dark style."""
        vz.set_style('dark')
        assert vz.get_current_style() == 'dark'

    def test_available_styles(self):
        """Test listing available styles."""
        styles = vz.available_styles()
        assert 'default' in styles
        assert 'dark' in styles
        assert 'minimal' in styles

    def test_invalid_style_raises(self):
        """Test that invalid style raises error."""
        with pytest.raises(vz.exceptions.StyleError):
            vz.set_style('nonexistent_style')


class TestVisualize:
    """Test visualize (dashboard) function."""

    def test_visualize_basic(self):
        """Test basic visualization dashboard."""
        df = pd.DataFrame({
            'a': np.random.randn(100),
            'b': np.random.randn(100),
            'c': np.random.randn(100)
        })
        fig = vz.visualize(df, max_plots=3)
        assert fig is not None

    def test_visualize_with_columns(self):
        """Test dashboard with specific columns."""
        df = pd.DataFrame({
            'x': np.random.randn(100),
            'y': np.random.randn(100),
            'z': np.random.randn(100)
        })
        fig = vz.visualize(df, columns=['x', 'y'])
        assert fig is not None


class TestSuggestPlots:
    """Test plot suggestions."""

    def test_suggest_plots_dataframe(self):
        """Test getting plot recommendations."""
        df = pd.DataFrame({
            'numeric1': [1, 2, 3, 4, 5],
            'numeric2': [5, 4, 3, 2, 1],
            'category': ['A', 'B', 'C', 'A', 'B']
        })
        recs = vz.suggest_plots(df)
        assert isinstance(recs, pd.DataFrame)
        assert len(recs) > 0
        assert 'type' in recs.columns
        assert 'rationale' in recs.columns


class TestShowClose:
    """Test show and close functions."""

    def test_show_function_exists(self):
        """Test that show function is available."""
        assert hasattr(vz, 'show')
        assert callable(vz.show)

    def test_close_function_exists(self):
        """Test that close function is available."""
        assert hasattr(vz, 'close')
        assert callable(vz.close)

    def test_show_with_plot(self):
        """Test that show works after creating a plot."""
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
        fig = vz.plot(df, x='x', y='y')
        # show() should not raise an error
        try:
            vz.show()
        except Exception as e:
            pytest.fail(f"show() raised unexpected error: {e}")

    def test_close_all_figures(self):
        """Test closing all figures."""
        # Create multiple plots
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
        fig1 = vz.plot(df, x='x', y='y')
        fig2 = vz.plot(df, x='x', y='y', kind='line')
        # Close all should not raise an error
        try:
            vz.close()
        except Exception as e:
            pytest.fail(f"close() raised unexpected error: {e}")

    def test_close_specific_figure(self):
        """Test closing a specific figure."""
        df = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
        fig = vz.plot(df, x='x', y='y')
        # Close specific figure should not raise an error
        try:
            vz.close(fig)
        except Exception as e:
            pytest.fail(f"close(fig) raised unexpected error: {e}")
