"""
Validation script for Visualizer package.
Tests that the package can be imported and basic functions work.
"""

import sys

print("Bottle Visualizer Package Validation")
print("=" * 60)

# Test 1: Import package
print("\n1. Testing package import...")
try:
    import bottleviz as vz
    print("   [OK] Package imported successfully")
except ImportError as e:
    print(f"   [FAIL] Failed to import: {e}")
    sys.exit(1)

# Test 2: Check version
print("\n2. Checking version...")
print(f"   Version: {vz.__version__}")

# Test 3: Check exports
print("\n3. Checking API exports...")
expected_exports = [
    'plot', 'visualize', 'quickplot',
    'set_style', 'available_styles',
    'suggest_plots', 'report', 'save_report', 'explore', 'compare'
]
missing = [exp for exp in expected_exports if not hasattr(vz, exp)]
if missing:
    print(f"   [FAIL] Missing exports: {missing}")
    sys.exit(1)
else:
    print(f"   [OK] All {len(expected_exports)} exports available")

# Test 4: Test data creation
print("\n4. Testing data handling...")
try:
    import pandas as pd
    import numpy as np

    df = pd.DataFrame({
        'x': [1, 2, 3, 4, 5],
        'y': [2, 4, 6, 8, 10],
        'cat': ['A', 'B', 'C', 'A', 'B']
    })
    print("   [OK] Test DataFrame created")

except Exception as e:
    print(f"   [FAIL] Failed to create test data: {e}")
    sys.exit(1)

# Test 5: Test basic plot creation (without displaying)
print("\n5. Testing basic plot creation...")
try:
    import matplotlib
    matplotlib.use('Agg')  # Non-interactive backend

    # Test scatter plot
    fig = vz.plot(df, x='x', y='y')
    assert fig is not None
    print("   [OK] Scatter plot created")

    # Test line plot
    fig = vz.plot(df, x='x', y='y', kind='line')
    assert fig is not None
    print("   [OK] Line plot created")

    # Test bar plot
    fig = vz.plot(df, x='cat', y='x', kind='bar')
    assert fig is not None
    print("   [OK] Bar plot created")

    # Test histogram
    fig = vz.plot(df, kind='hist', x='x')
    assert fig is not None
    print("   [OK] Histogram created")

    # Test quickplot
    fig = vz.quickplot([1, 2, 3, 4, 5])
    assert fig is not None
    print("   [OK] Quickplot created")

    # Test style setting
    vz.set_style('dark')
    assert vz.get_current_style() == 'dark'
    print("   [OK] Style setting works")

    # Reset style
    vz.set_style('default')
    assert vz.get_current_style() == 'default'
    print("   [OK] Style reset works")

except Exception as e:
    import traceback
    print(f"   [FAIL] Plot creation failed: {e}")
    traceback.print_exc()
    sys.exit(1)

# Test 6: Test utility functions
print("\n6. Testing utility functions...")
try:
    from bottleviz.utils import validate_data, infer_plot_type
    validated = validate_data(df)
    assert len(validated) == 5
    print("   [OK] Data validation works")

    plot_type = infer_plot_type(df, x='x', y='y')
    assert plot_type in ['scatter', 'line']
    print(f"   [OK] Plot type inference works (detected: {plot_type})")

except Exception as e:
    print(f"   [FAIL] Utility functions failed: {e}")
    sys.exit(1)

# Test 7: Test suggest_plots
print("\n7. Testing suggest_plots...")
try:
    recs = vz.suggest_plots(df)
    assert isinstance(recs, pd.DataFrame)
    assert len(recs) > 0
    print(f"   [OK] Plot suggestions generated ({len(recs)} recommendations)")
except Exception as e:
    print(f"   [FAIL] suggest_plots failed: {e}")
    # Don't exit, this is secondary

# Test 8: Test visualize (dashboard)
print("\n8. Testing visualize (dashboard)...")
try:
    fig = vz.visualize(df, max_plots=2)
    assert fig is not None
    print("   [OK] Dashboard created")
except Exception as e:
    print(f"   [FAIL] Dashboard creation failed: {e}")
    # Don't exit, this is secondary

# Test 9: Test exceptions
print("\n9. Testing error handling...")
try:
    from bottleviz.exceptions import VisualizerError, DataError
    # Test invalid data
    try:
        vz.plot(None)
        print("   [FAIL] Should have raised error for None data")
        sys.exit(1)
    except (VisualizerError, DataError):
        print("   [OK] Error handling works correctly")
except Exception as e:
    print(f"   [FAIL] Error handling test failed: {e}")

# Test 10: Test file structure
print("\n10. Checking package file structure...")
import os
package_dir = os.path.dirname(vz.__file__)
expected_files = [
    '__init__.py',
    'core.py',
    'styles.py',
    'backends.py',
    'utils.py',
    'exceptions.py',
    'types.py',
    'auto.py'
]
missing_files = []
for fname in expected_files:
    fpath = os.path.join(package_dir, fname)
    if not os.path.exists(fpath):
        missing_files.append(fname)

if missing_files:
    print(f"   [FAIL] Missing files: {missing_files}")
else:
    print(f"   [OK] All {len(expected_files)} core files present")

print("\n" + "=" * 60)
print("VALIDATION COMPLETE [DONE]")
print("=" * 60)
print("\nBottleVisualizer is ready to use!")
print("\nQuick examples:")
print("  import bottleviz as vz")
print("  vz.plot(df, x='col1', y='col2')")
print("  vz.set_style('dark')")
print("  vz.visualize(df)")
print("  vz.suggest_plots(df)")
print("\nSee README.md for full documentation.")
print("=" * 60)
