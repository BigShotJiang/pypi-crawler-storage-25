"""
Test advanced plot types: Sankey, Sunburst, Treemap, Network, Candlestick.
"""

import pytest
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend for testing

import bottleviz as vz
from bottleviz.exceptions import VisualizerError


# Helper to check optional dependencies
def is_module_available(name):
    try:
        __import__(name)
        return True
    except ImportError:
        return False


class TestSankeyPlot:
    """Test Sankey diagrams."""

    @pytest.mark.skipif(not is_module_available('networkx'), reason="networkx not installed")
    def test_sankey_bipartite(self):
        """Test basic two-level Sankey."""
        data = pd.DataFrame({
            'source': ['A', 'A', 'B', 'B'],
            'target': ['X', 'Y', 'X', 'Y'],
            'value': [10, 20, 30, 40]
        })
        fig = vz.plot(data, kind='sankey', source='source', target='target', value='value')
        assert fig is not None
        vz.close(fig)

    @pytest.mark.skipif(not is_module_available('networkx'), reason="networkx not installed")
    def test_sankey_with_missing_value(self):
        """Test Sankey with count aggregation."""
        data = pd.DataFrame({
            'source': ['A', 'A', 'B', 'B'],
            'target': ['X', 'Y', 'X', 'Y']
        })
        fig = vz.plot(data, kind='sankey', source='source', target='target')
        assert fig is not None
        vz.close(fig)

    @pytest.mark.skipif(not is_module_available('networkx'), reason="networkx not installed")
    def test_sankey_multistage(self):
        """Test multi-stage Sankey using path."""
        data = pd.DataFrame({
            'stage1': ['A', 'A', 'B', 'B'],
            'stage2': ['X', 'Y', 'X', 'Y'],
            'stage3': ['M', 'N', 'M', 'N'],
            'value': [5, 10, 15, 20]
        })
        fig = vz.plot(data, kind='sankey', path=['stage1', 'stage2', 'stage3'], value='value')
        assert fig is not None
        vz.close(fig)

    @pytest.mark.skipif(not is_module_available('networkx'), reason="networkx not installed")
    def test_sankey_missing_columns(self):
        """Test Sankey raises error when required columns missing."""
        data = pd.DataFrame({'a': [1, 2], 'b': [3, 4]})
        with pytest.raises(VisualizerError):
            vz.plot(data, kind='sankey', source='x', target='y')


class TestSunburstPlot:
    """Test Sunburst charts."""

    def test_sunburst_basic(self):
        """Test basic sunburst chart."""
        data = pd.DataFrame({
            'region': ['North', 'North', 'South', 'South'],
            'city': ['NYC', 'Boston', 'Austin', 'Miami'],
            'value': [100, 80, 120, 90]
        })
        fig = vz.plot(data, kind='sunburst', path=['region', 'city'], value='value')
        assert fig is not None
        vz.close(fig)

    def test_sunburst_missing_path(self):
        """Test sunburst raises error without path."""
        data = pd.DataFrame({'a': [1, 2], 'value': [10, 20]})
        with pytest.raises(VisualizerError):
            vz.plot(data, kind='sunburst', value='value')

    def test_sunburst_missing_value(self):
        """Test sunburst raises error without value."""
        data = pd.DataFrame({'region': ['A', 'B'], 'city': ['X', 'Y']})
        with pytest.raises(VisualizerError):
            vz.plot(data, kind='sunburst', path=['region', 'city'])


class TestTreemapPlot:
    """Test Treemap charts."""

    @pytest.mark.skipif(not is_module_available('squarify'), reason="squarify not installed")
    def test_treemap_basic(self):
        """Test basic treemap."""
        data = pd.DataFrame({
            'group': ['A', 'B', 'C'],
            'value': [100, 200, 150]
        })
        fig = vz.plot(data, kind='treemap', path='group', value='value')
        assert fig is not None
        vz.close(fig)

    @pytest.mark.skipif(not is_module_available('squarify'), reason="squarify not installed")
    def test_treemap_hierarchical(self):
        """Test hierarchical treemap."""
        data = pd.DataFrame({
            'region': ['North', 'North', 'South', 'South'],
            'city': ['NYC', 'Boston', 'Austin', 'Miami'],
            'value': [100, 80, 120, 90]
        })
        fig = vz.plot(data, kind='treemap', path=['region', 'city'], value='value')
        assert fig is not None
        vz.close(fig)

    @pytest.mark.skipif(not is_module_available('squarify'), reason="squarify not installed")
    def test_treemap_missing_value(self):
        """Test treemap requires value column."""
        data = pd.DataFrame({'group': ['A', 'B']})
        with pytest.raises(VisualizerError):
            vz.plot(data, kind='treemap', path='group')


class TestNetworkPlot:
    """Test Network graphs."""

    @pytest.mark.skipif(not is_module_available('networkx'), reason="networkx not installed")
    def test_network_basic(self):
        """Test basic network graph."""
        data = pd.DataFrame({
            'source': ['A', 'A', 'B'],
            'target': ['X', 'Y', 'X'],
            'weight': [1, 2, 3]
        })
        fig = vz.plot(data, kind='network', source='source', target='target', weight='weight')
        assert fig is not None
        vz.close(fig)

    @pytest.mark.skipif(not is_module_available('networkx'), reason="networkx not installed")
    def test_network_without_weight(self):
        """Test network graph without explicit weight."""
        data = pd.DataFrame({
            'source': ['A', 'B', 'C'],
            'target': ['X', 'Y', 'Z']
        })
        fig = vz.plot(data, kind='network', source='source', target='target')
        assert fig is not None
        vz.close(fig)

    @pytest.mark.skipif(not is_module_available('networkx'), reason="networkx not installed")
    def test_network_missing_columns(self):
        """Test network raises error when source/target missing."""
        data = pd.DataFrame({'a': [1, 2], 'b': [3, 4]})
        with pytest.raises(VisualizerError):
            vz.plot(data, kind='network')


class TestCandlestickPlot:
    """Test Candlestick charts."""

    def test_candlestick_basic(self):
        """Test basic candlestick chart."""
        data = pd.DataFrame({
            'date': pd.date_range('2024-01-01', periods=10, freq='D'),
            'open': np.random.rand(10) * 100 + 100,
            'high': np.random.rand(10) * 100 + 120,
            'low': np.random.rand(10) * 100 + 80,
            'close': np.random.rand(10) * 100 + 100,
            'volume': np.random.randint(1000, 5000, 10)
        })
        # Ensure high >= open, close and low <= open, close
        data['high'] = data[['open', 'close', 'high']].max(axis=1)
        data['low'] = data[['open', 'close', 'low']].min(axis=1)
        fig = vz.plot(data, x='date', kind='candlestick',
                      open='open', high='high', low='low', close='close')
        assert fig is not None
        vz.close(fig)

    def test_candlestick_custom_column_names(self):
        """Test candlestick with custom OHLC column names."""
        data = pd.DataFrame({
            'day': pd.date_range('2024-01-01', periods=5, freq='D'),
            'opening': [100, 101, 102, 103, 104],
            'high': [105, 106, 107, 108, 109],
            'low': [95, 96, 97, 98, 99],
            'closing': [102, 103, 104, 105, 106]
        })
        fig = vz.plot(data, x='day', kind='candlestick',
                      open='opening', high='high', low='low', close='closing')
        assert fig is not None
        vz.close(fig)

    def test_candlestick_missing_ohlc(self):
        """Test candlestick raises error when OHLC columns missing."""
        data = pd.DataFrame({'date': pd.date_range('2024-01-01', periods=5)})
        with pytest.raises(VisualizerError):
            vz.plot(data, x='date', kind='candlestick')

    def test_candlestick_without_x(self):
        """Test candlestick uses index if x not provided."""
        data = pd.DataFrame({
            'open': [100, 101, 102],
            'high': [105, 106, 107],
            'low': [95, 96, 97],
            'close': [102, 103, 104]
        })
        fig = vz.plot(data, kind='candlestick',
                      open='open', high='high', low='low', close='close')
        assert fig is not None
        vz.close(fig)


# ========== New Plot Types Tests ==========


class TestStackedBarPlot:
    """Test stacked bar charts."""

    def test_stacked_bar_basic(self):
        """Test basic stacked bar with two numeric columns."""
        data = pd.DataFrame({
            'category': ['A', 'B', 'C'],
            'value1': [10, 20, 30],
            'value2': [15, 25, 35]
        })
        fig = vz.plot(data, x='category', y=['value1', 'value2'], kind='stacked_bar')
        assert fig is not None
        vz.close(fig)

    def test_stacked_bar_single_y(self):
        """Test stacked bar with single y (no stacking)."""
        data = pd.DataFrame({
            'category': ['A', 'B'],
            'value': [10, 20]
        })
        fig = vz.plot(data, x='category', y='value', kind='stacked_bar')
        assert fig is not None
        vz.close(fig)

    def test_stacked_bar_auto_y(self):
        """Test stacked bar auto-selects all numeric columns."""
        data = pd.DataFrame({
            'category': ['A', 'B'],
            'v1': [10, 20],
            'v2': [15, 25],
            'v3': [5, 10]
        })
        fig = vz.plot(data, x='category', kind='stacked_bar')
        assert fig is not None
        vz.close(fig)


class TestGroupedBarPlot:
    """Test grouped bar charts."""

    def test_grouped_bar_basic(self):
        """Test basic grouped bar with two numeric columns."""
        data = pd.DataFrame({
            'category': ['A', 'B', 'C'],
            'value1': [10, 20, 30],
            'value2': [15, 25, 35]
        })
        fig = vz.plot(data, x='category', y=['value1', 'value2'], kind='grouped_bar')
        assert fig is not None
        vz.close(fig)

    def test_grouped_bar_three_groups(self):
        """Test grouped bar with three groups."""
        data = pd.DataFrame({
            'group': ['X', 'Y', 'Z'],
            'A': [5, 10, 15],
            'B': [8, 12, 18],
            'C': [3, 7, 11]
        })
        fig = vz.plot(data, x='group', y=['A', 'B', 'C'], kind='grouped_bar')
        assert fig is not None
        vz.close(fig)

    def test_grouped_bar_without_x(self):
        """Test grouped bar without explicit x uses index."""
        data = pd.DataFrame({
            'A': [1, 2, 3],
            'B': [4, 5, 6]
        })
        fig = vz.plot(data, y=['A', 'B'], kind='grouped_bar')
        assert fig is not None
        vz.close(fig)


class TestHexbinPlot:
    """Test hexbin plots."""

    def test_hexbin_basic(self):
        """Test basic hexbin plot."""
        np.random.seed(42)
        data = pd.DataFrame({
            'x': np.random.randn(500),
            'y': np.random.randn(500)
        })
        fig = vz.plot(data, x='x', y='y', kind='hexbin')
        assert fig is not None
        vz.close(fig)

    def test_hexbin_large_dataset(self):
        """Test hexbin with larger dataset."""
        np.random.seed(42)
        data = pd.DataFrame({
            'x': np.random.randn(2000),
            'y': np.random.randn(2000)
        })
        fig = vz.plot(data, x='x', y='y', kind='hexbin', gridsize=30)
        assert fig is not None
        vz.close(fig)

    def test_hexbin_custom_params(self):
        """Test hexbin with custom parameters."""
        np.random.seed(42)
        data = pd.DataFrame({
            'x': np.random.randn(1000),
            'y': np.random.randn(1000)
        })
        fig = vz.plot(data, x='x', y='y', kind='hexbin',
                     gridsize=20, cmap='plasma', alpha=0.8)
        assert fig is not None
        vz.close(fig)

    def test_hexbin_requires_y(self):
        """Test hexbin raises error when y missing."""
        data = pd.DataFrame({'x': [1, 2, 3]})
        with pytest.raises(VisualizerError):
            vz.plot(data, x='x', kind='hexbin')


class TestStepPlot:
    """Test step plots."""

    def test_step_basic(self):
        """Test basic step plot."""
        data = pd.DataFrame({
            'x': [0, 1, 2, 3, 4],
            'y': [1, 3, 2, 4, 3]
        })
        fig = vz.plot(data, x='x', y='y', kind='step')
        assert fig is not None
        vz.close(fig)

    def test_step_multiple_series(self):
        """Test step plot with multiple y columns."""
        data = pd.DataFrame({
            'time': [0, 1, 2, 3],
            'A': [1, 2, 1, 2],
            'B': [2, 1, 2, 1]
        })
        fig = vz.plot(data, x='time', y=['A', 'B'], kind='step')
        assert fig is not None
        vz.close(fig)

    def test_step_where_pre(self):
        """Test step plot with where='pre'."""
        data = pd.DataFrame({'val': [1, 2, 3, 4]})
        fig = vz.plot(data, y='val', kind='step', where='pre')
        assert fig is not None
        vz.close(fig)

    def test_step_where_mid(self):
        """Test step plot with where='mid'."""
        data = pd.DataFrame({'val': [1, 2, 3, 4]})
        fig = vz.plot(data, y='val', kind='step', where='mid')
        assert fig is not None
        vz.close(fig)


class TestFillBetweenPlot:
    """Test fill_between plots."""

    def test_fill_between_basic(self):
        """Test basic fill between line and zero."""
        data = pd.DataFrame({
            'x': [0, 1, 2, 3, 4],
            'y': [1, 3, 2, 4, 3]
        })
        fig = vz.plot(data, x='x', y='y', kind='fill_between')
        assert fig is not None
        vz.close(fig)

    def test_fill_between_bounds(self):
        """Test fill between upper and lower bounds."""
        data = pd.DataFrame({
            'x': [0, 1, 2, 3, 4],
            'y': [2, 3, 4, 3, 2],
            'lower': [1, 2, 3, 2, 1],
            'upper': [3, 4, 5, 4, 3]
        })
        fig = vz.plot(data, x='x', y_lower='lower', y_upper='upper', kind='fill_between')
        assert fig is not None
        vz.close(fig)

    def test_fill_between_with_line(self):
        """Test fill between with explicit line."""
        data = pd.DataFrame({
            't': [0, 1, 2, 3],
            'val': [1, 2, 1, 2]
        })
        fig = vz.plot(data, x='t', y='val', kind='fill_between', show_line=True)
        assert fig is not None
        vz.close(fig)

    def test_fill_between_requires_y(self):
        """Test fill_between raises error when y missing."""
        data = pd.DataFrame({'x': [1, 2, 3]})
        with pytest.raises(VisualizerError):
            vz.plot(data, x='x', kind='fill_between')


class TestContourPlot:
    """Test 2D contour plots."""

    def test_contour_basic(self):
        """Test basic contour plot."""
        # Create gridded data
        x = np.linspace(-3, 3, 30)
        y = np.linspace(-3, 3, 30)
        X, Y = np.meshgrid(x, y)
        Z = np.exp(-(X**2 + Y**2))
        data = pd.DataFrame({
            'x': X.flatten(),
            'y': Y.flatten(),
            'z': Z.flatten()
        })
        fig = vz.plot(data, x='x', y='y', z='z', kind='contour')
        assert fig is not None
        vz.close(fig)

    def test_contour_filled(self):
        """Test filled contour plot."""
        x = np.linspace(-2, 2, 25)
        y = np.linspace(-2, 2, 25)
        X, Y = np.meshgrid(x, y)
        Z = np.sin(X) * np.cos(Y)
        data = pd.DataFrame({
            'x': X.flatten(),
            'y': Y.flatten(),
            'value': Z.flatten()
        })
        fig = vz.plot(data, x='x', y='y', value='value', kind='contour', filled=True)
        assert fig is not None
        vz.close(fig)

    def test_contour_requires_xyz(self):
        """Test contour raises error when x, y, or z missing."""
        data = pd.DataFrame({'x': [1, 2], 'y': [3, 4]})
        with pytest.raises(VisualizerError):
            vz.plot(data, x='x', y='y', kind='contour')


class TestPcolormeshPlot:
    """Test pcolormesh plots."""

    def test_pcolormesh_basic(self):
        """Test basic pcolormesh."""
        x = np.linspace(0, 1, 6)
        y = np.linspace(0, 1, 5)
        X, Y = np.meshgrid(x, y)
        Z = np.random.rand(5, 6)
        data = pd.DataFrame({
            'x': X.flatten(),
            'y': Y.flatten(),
            'value': Z.flatten()
        })
        fig = vz.plot(data, x='x', y='y', value='value', kind='pcolormesh')
        assert fig is not None
        vz.close(fig)

    def test_pcolormesh_custom_cmap(self):
        """Test pcolormesh with custom colormap."""
        x = np.arange(5)
        y = np.arange(5)
        X, Y = np.meshgrid(x, y)
        Z = np.random.randint(0, 10, (5, 5))
        data = pd.DataFrame({
            'x': X.flatten(),
            'y': Y.flatten(),
            'z': Z.flatten()
        })
        fig = vz.plot(data, x='x', y='y', z='z', kind='pcolormesh', cmap='hot')
        assert fig is not None
        vz.close(fig)


class TestQuiverPlot:
    """Test quiver (vector field) plots."""

    def test_quiver_basic(self):
        """Test basic quiver plot."""
        x = np.linspace(0, 2*np.pi, 10)
        y = np.linspace(0, 2*np.pi, 10)
        X, Y = np.meshgrid(x, y)
        U = np.cos(X)
        V = np.sin(Y)
        data = pd.DataFrame({
            'x': X.flatten(),
            'y': Y.flatten(),
            'u': U.flatten(),
            'v': V.flatten()
        })
        fig = vz.plot(data, x='x', y='y', u='u', v='v', kind='quiver')
        assert fig is not None
        vz.close(fig)

    def test_quiver_simple(self):
        """Test simple quiver with small dataset."""
        data = pd.DataFrame({
            'x': [0, 1, 0, 1],
            'y': [0, 0, 1, 1],
            'u': [1, 0, -1, 0],
            'v': [0, 1, 0, -1]
        })
        fig = vz.plot(data, x='x', y='y', u='u', v='v', kind='quiver')
        assert fig is not None
        vz.close(fig)

    def test_quiver_requires_all(self):
        """Test quiver raises error when any component missing."""
        data = pd.DataFrame({'x': [1], 'y': [2], 'u': [3]})
        with pytest.raises(VisualizerError):
            vz.plot(data, x='x', y='y', u='u', kind='quiver')


class TestSpyPlot:
    """Test spy plots for sparse matrices."""

    def test_spy_basic(self):
        """Test basic spy plot from 2D array."""
        matrix = np.eye(10)  # Identity matrix
        # Add some zeros
        matrix[0, 5] = 1
        matrix[5, 0] = 1
        data = pd.DataFrame(matrix)
        fig = vz.plot(data, kind='spy')
        assert fig is not None
        vz.close(fig)

    def test_spy_sparse_matrix(self):
        """Test spy with sparse pattern."""
        # Diagonal with random sparse off-diagonal
        matrix = np.diag(np.ones(20))
        for _ in range(5):
            i, j = np.random.randint(0, 20, 2)
            matrix[i, j] = 1
        data = pd.DataFrame(matrix)
        fig = vz.plot(data, kind='spy', markersize=3)
        assert fig is not None
        vz.close(fig)

    def test_spy_with_matrix_column(self):
        """Test spy with explicit matrix column."""
        data = pd.DataFrame({
            'id': [1, 2],
            'matrix': [np.eye(3).flatten(), np.eye(3).flatten()]
        })
        # This should fail because matrix column needs special handling
        with pytest.raises(VisualizerError):
            vz.plot(data, matrix='matrix', kind='spy')


class TestPolarPlot:
    """Test polar coordinate plots."""

    def test_polar_basic(self):
        """Test basic polar plot."""
        theta = np.linspace(0, 2*np.pi, 100)
        r = np.abs(np.sin(theta)) + 0.5
        data = pd.DataFrame({'theta': theta, 'r': r})
        fig = vz.plot(data, theta='theta', r='r', kind='polar')
        assert fig is not None
        vz.close(fig)

    def test_polar_spiral(self):
        """Test polar plot with spiral data."""
        theta = np.linspace(0, 6*np.pi, 200)
        r = theta / (2*np.pi)
        data = pd.DataFrame({'angle': theta, 'radius': r})
        fig = vz.plot(data, theta='angle', radius='radius', kind='polar')
        assert fig is not None
        vz.close(fig)

    def test_polar_requires_r(self):
        """Test polar plot raises error when r missing."""
        data = pd.DataFrame({'theta': [0, 1, 2]})
        with pytest.raises(VisualizerError):
            vz.plot(data, theta='theta', kind='polar')

    def test_polar_with_fill(self):
        """Test polar plot with filled area."""
        data = pd.DataFrame({
            'theta': np.linspace(0, 2*np.pi, 50),
            'r': 1 + np.cos(2 * np.linspace(0, 2*np.pi, 50))
        })
        fig = vz.plot(data, theta='theta', r='r', kind='polar', fill=True, alpha=0.5)
        assert fig is not None
        vz.close(fig)


class TestTablePlot:
    """Test table plots."""

    def test_table_basic(self):
        """Test basic table from DataFrame."""
        data = pd.DataFrame({
            'Name': ['Alice', 'Bob', 'Charlie'],
            'Score': [95, 88, 92],
            'Grade': ['A', 'B', 'A']
        })
        fig = vz.plot(data, kind='table')
        assert fig is not None
        vz.close(fig)

    def test_table_with_max_rows(self):
        """Test table with limited rows."""
        data = pd.DataFrame({
            'A': range(20),
            'B': range(20, 40),
            'C': range(40, 60)
        })
        fig = vz.plot(data, kind='table', max_rows=10)
        assert fig is not None
        vz.close(fig)

    def test_table_no_index(self):
        """Test table without showing index."""
        data = pd.DataFrame({'X': [1, 2], 'Y': [3, 4]})
        fig = vz.plot(data, kind='table', show_index=False)
        assert fig is not None
        vz.close(fig)

    def test_table_custom_fontsize(self):
        """Test table with custom font size."""
        data = pd.DataFrame({'Col1': [1, 2], 'Col2': [3, 4]})
        fig = vz.plot(data, kind='table', fontsize=12)
        assert fig is not None
        vz.close(fig)


class TestEventplotPlot:
    """Test eventplot plots."""

    def test_eventplot_basic(self):
        """Test basic event plot with single sequence."""
        data = pd.DataFrame({
            'time': range(10),
            'event': [0, 1, 0, 0, 1, 0, 0, 0, 1, 0]
        })
        fig = vz.plot(data, y='event', kind='eventplot')
        assert fig is not None
        vz.close(fig)

    def test_eventplot_multiple_sequences(self):
        """Test event plot with multiple event sequences."""
        data = pd.DataFrame({
            'A': [0, 1, 0, 0, 1, 0],
            'B': [0, 0, 1, 0, 0, 1],
            'C': [1, 0, 0, 1, 0, 0]
        })
        fig = vz.plot(data, kind='eventplot')
        assert fig is not None
        vz.close(fig)

    def test_eventplot_columns_param(self):
        """Test event plot with explicit columns."""
        data = pd.DataFrame({
            'id': [1, 2, 3],
            'X': [0, 1, 0],
            'Y': [1, 0, 1]
        })
        fig = vz.plot(data, columns=['X', 'Y'], kind='eventplot')
        assert fig is not None
        vz.close(fig)

    def test_eventplot_custom_kwargs(self):
        """Test event plot with custom parameters."""
        data = pd.DataFrame({
            'A': [0, 1, 0, 1],
            'B': [1, 0, 1, 0]
        })
        fig = vz.plot(data, kind='eventplot',
                     orientation='horizontal',
                     linelengths=1.5)
        assert fig is not None
        vz.close(fig)


# ========== Additional Plot Types (Waterfall, Gantt, OHLC+Volume) ==========


class TestWaterfallPlot:
    """Test waterfall charts."""

    def test_waterfall_basic(self):
        """Test basic waterfall chart showing cumulative changes."""
        data = pd.DataFrame({
            'category': ['Starting', 'Revenue', 'Cost', 'Investment', 'Return'],
            'value': [100, 50, -30, -20, 40]
        })
        fig = vz.plot(data, x='category', y='value', kind='waterfall')
        assert fig is not None
        vz.close(fig)

    def test_waterfall_financial(self):
        """Test waterfall chart for financial statement."""
        data = pd.DataFrame({
            'item': ['Previous Year', 'Price Increase', 'Volume Increase', 'One-time Costs', 'Tax Effect'],
            'change': [5000, 1200, 800, -500, -300]
        })
        fig = vz.plot(data, x='item', y='change', kind='waterfall',
                     title='Profit Walk')
        assert fig is not None
        vz.close(fig)

    def test_waterfall_requires_xy(self):
        """Test waterfall raises error when x or y missing."""
        data = pd.DataFrame({'a': [1, 2], 'b': [3, 4]})
        with pytest.raises(VisualizerError):
            vz.plot(data, kind='waterfall')


class TestGanttPlot:
    """Test Gantt charts."""

    def test_gantt_basic_with_end(self):
        """Test basic Gantt chart with start and end dates."""
        data = pd.DataFrame({
            'task': ['Design', 'Development', 'Testing', 'Deployment'],
            'start': ['2024-01-01', '2024-02-01', '2024-03-01', '2024-04-01'],
            'end': ['2024-01-31', '2024-03-01', '2024-03-31', '2024-04-15']
        })
        fig = vz.plot(data, task='task', start='start', end='end', kind='gantt')
        assert fig is not None
        vz.close(fig)

    def test_gantt_with_duration(self):
        """Test Gantt chart with start and duration."""
        data = pd.DataFrame({
            'task': ['Phase 1', 'Phase 2', 'Phase 3'],
            'start': ['2024-01-01', '2024-02-15', '2024-04-01'],
            'duration': [45, 60, 30]
        })
        fig = vz.plot(data, task='task', start='start', duration='duration', kind='gantt')
        assert fig is not None
        vz.close(fig)

    def test_gantt_with_numeric_days(self):
        """Test Gantt chart with numeric day numbers."""
        data = pd.DataFrame({
            'activity': ['A', 'B', 'C'],
            'start': [0, 10, 20],
            'end': [10, 20, 30]
        })
        fig = vz.plot(data, task='activity', start='start', end='end', kind='gantt')
        assert fig is not None
        vz.close(fig)

    def test_gantt_requires_task_start(self):
        """Test Gantt raises error when task or start missing."""
        data = pd.DataFrame({'a': [1, 2], 'b': [3, 4]})
        with pytest.raises(VisualizerError):
            vz.plot(data, kind='gantt')

    def test_gantt_requires_end_or_duration(self):
        """Test Gantt raises error when both end and duration missing."""
        data = pd.DataFrame({'task': ['A'], 'start': ['2024-01-01']})
        with pytest.raises(VisualizerError):
            vz.plot(data, task='task', start='start', kind='gantt')


class TestOHLCVolumePlot:
    """Test OHLC with volume charts."""

    def test_ohlc_volume_basic(self):
        """Test basic OHLC chart with volume."""
        data = pd.DataFrame({
            'date': pd.date_range('2024-01-01', periods=10, freq='D'),
            'open': np.random.rand(10) * 100 + 100,
            'high': np.random.rand(10) * 110 + 100,
            'low': np.random.rand(10) * 90 + 100,
            'close': np.random.rand(10) * 100 + 100,
            'volume': np.random.randint(1000, 5000, 10)
        })
        # Ensure high >= open, close and low <= open, close
        data['high'] = data[['open', 'close', 'high']].max(axis=1)
        data['low'] = data[['open', 'close', 'low']].min(axis=1)

        fig = vz.plot(data, x='date', open='open', high='high', low='low',
                     close='close', volume='volume', kind='ohlc_volume')
        assert fig is not None
        vz.close(fig)

    def test_ohlc_volume_custom_columns(self):
        """Test OHLC+Volume with custom column names."""
        data = pd.DataFrame({
            'day': pd.date_range('2024-01-01', periods=5, freq='D'),
            'opening': [100, 101, 102, 103, 104],
            'high': [105, 106, 107, 108, 109],
            'low': [95, 96, 97, 98, 99],
            'closing': [102, 103, 104, 105, 106],
            'vol': [1000, 1500, 1200, 1800, 2000]
        })
        fig = vz.plot(data, x='day', open='opening', high='high', low='low',
                     close='closing', volume='vol', kind='ohlc_volume')
        assert fig is not None
        vz.close(fig)

    def test_ohlc_volume_missing_params(self):
        """Test OHLC+Volume raises error when required columns missing."""
        data = pd.DataFrame({'date': pd.date_range('2024-01-01', periods=5)})
        with pytest.raises(VisualizerError):
            vz.plot(data, x='date', kind='ohlc_volume')

    def test_ohlc_volume_without_x(self):
        """Test OHLC+Volume uses index if x not provided."""
        data = pd.DataFrame({
            'open': [100, 101, 102],
            'high': [105, 106, 107],
            'low': [95, 96, 97],
            'close': [102, 103, 104],
            'volume': [1000, 1500, 1200]
        })
        fig = vz.plot(data, open='open', high='high', low='low',
                     close='close', volume='volume', kind='ohlc_volume')
        assert fig is not None
        vz.close(fig)
