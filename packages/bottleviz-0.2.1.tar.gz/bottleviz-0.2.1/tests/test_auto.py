"""
Tests for the automated features (suggest_plots, report, save_report, explore, compare).
"""

import pytest
import pandas as pd
import numpy as np
import bottleviz as vz
from pathlib import Path


class TestReport:
    """Test the report generation functions."""

    def test_report_returns_string(self):
        """Test that report() returns a string."""
        df = pd.DataFrame({
            'x': [1, 2, 3, 4, 5],
            'y': [2, 4, 6, 8, 10],
            'cat': ['A', 'B', 'C', 'A', 'B']
        })
        result = vz.report(df)
        assert isinstance(result, str)
        assert len(result) > 0

    def test_report_contains_unicode(self):
        """Test that report contains Unicode box-drawing characters."""
        df = pd.DataFrame({
            'x': [1, 2, 3],
            'y': [4, 5, 6]
        })
        result = vz.report(df)
        # Check for Unicode box-drawing character
        assert '─' in result

    def test_save_report_creates_file(self, tmp_path):
        """Test that save_report() creates a file with UTF-8 encoding."""
        df = pd.DataFrame({
            'x': [1, 2, 3, 4, 5],
            'y': [2, 4, 6, 8, 10],
            'cat': ['A', 'B', 'C', 'A', 'B']
        })
        filepath = tmp_path / "report.txt"
        vz.save_report(df, str(filepath))

        assert filepath.exists()

        # Read with UTF-8 to verify content
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        assert isinstance(content, str)
        assert len(content) > 0
        assert 'DATA VISUALIZATION REPORT' in content

    def test_save_report_with_unicode_data(self, tmp_path):
        """Test that save_report handles data with Unicode characters."""
        df = pd.DataFrame({
            'name': ['José', 'François', '李明', 'Müller'],
            'value': [1, 2, 3, 4]
        })
        filepath = tmp_path / "unicode_report.txt"
        vz.save_report(df, str(filepath))

        # Read back and verify Unicode characters are preserved
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        assert 'José' in content
        assert 'François' in content
        assert '李明' in content
        assert 'Müller' in content

    def test_save_report_with_pathlib(self, tmp_path):
        """Test that save_report accepts pathlib.Path objects."""
        df = pd.DataFrame({'x': [1, 2, 3]})
        filepath = tmp_path / "report_pathlib.txt"
        vz.save_report(df, filepath)  # Pass Path object directly

        assert filepath.exists()


