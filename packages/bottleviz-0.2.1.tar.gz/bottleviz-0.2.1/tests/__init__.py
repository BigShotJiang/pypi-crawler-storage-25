"""
Tests for Visualizer package.
"""
