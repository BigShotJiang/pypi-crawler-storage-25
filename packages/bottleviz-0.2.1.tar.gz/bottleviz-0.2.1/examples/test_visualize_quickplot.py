"""
Test examples for visualize and quickplot functions.
"""

import bottleviz as vz
import pandas as pd
import numpy as np

print("=" * 60)
print("Testing visualize() - Automated EDA Dashboard")
print("=" * 60)

# Create sample dataset for testing visualize()
np.random.seed(42)
df = pd.DataFrame({
    'age': np.random.randint(18, 70, 100),
    'income': np.random.normal(50000, 15000, 100),
    'score': np.random.uniform(0, 100, 100),
    'category': np.random.choice(['A', 'B', 'C', 'D'], 100),
    'date': pd.date_range('2024-01-01', periods=100, freq='D')
})

print(f"\nDataset shape: {df.shape}")
print(f"Columns: {df.columns.tolist()}")
print(f"\nFirst few rows:")
print(df.head())

# Test 1: visualize() with auto column selection
print("\n1. Creating automated EDA dashboard with all numeric columns...")
fig1 = vz.visualize(df)
vz.show()
vz.close()
print("   [OK] Dashboard created successfully")

# Test 2: visualize() with specific columns
print("\n2. Creating dashboard with selected columns...")
fig2 = vz.visualize(df, columns=['age', 'income', 'score'], max_plots=6)
vz.show()
vz.close()
print("   [OK] Selected columns dashboard created")

# Test 3: visualize() with plot_type='distribution'
print("\n3. Creating distribution-only dashboard...")
fig3 = vz.visualize(df, columns=['age', 'income'], plot_type='distribution')
vz.show()
vz.close()
print("   [OK] Distribution dashboard created")

# Test 4: visualize() with plot_type='correlation'
print("\n4. Creating correlation dashboard...")
fig4 = vz.visualize(df, columns=['age', 'income', 'score'], plot_type='correlation')
vz.show()
vz.close()
print("   [OK] Correlation dashboard created")


print("\n" + "=" * 60)
print("Testing quickplot() - Ultra-Simplified One-Liners")
print("=" * 60)

# Test 5: quickplot with a single list (line plot)
print("\n5. quickplot with single list (line chart)...")
data1 = [1, 3, 2, 5, 4, 6, 8, 7, 9]
vz.quickplot(data1, title='Simple Line from List')
vz.show()
vz.close()
print("   [OK] Line plot from single list")

# Test 6: quickplot with two lists (scatter)
print("\n6. quickplot with two lists (scatter)...")
x_data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
y_data = [2, 4, 1, 5, 3, 7, 6, 9, 8, 10]
vz.quickplot(x_data, y_data, title='Scatter from Two Lists')
vz.show()
vz.close()
print("   [OK] Scatter plot from two lists")

# Test 7: quickplot with keyword arguments (x=..., y=...)
print("\n7. quickplot with keyword arguments...")
vz.quickplot(x=[1, 2, 3, 4, 5], y=[3, 5, 2, 7, 4], kind='bar', title='Bar from Keywords')
vz.show()
vz.close()
print("   [OK] Bar plot from keyword arguments")

# Test 8: quickplot with DataFrame
print("\n8. quickplot with DataFrame (auto-detection)...")
df_simple = pd.DataFrame({
    'x': [1, 2, 3, 4, 5],
    'y': [2, 4, 1, 5, 3]
})
vz.quickplot(df_simple, x='x', y='y', title='DataFrame Quickplot')
vz.show()
vz.close()
print("   [OK] Quickplot from DataFrame")

# Test 9: quickplot series (histogram from Series)
print("\n9. quickplot with Series (histogram)...")
series = pd.Series(np.random.randn(100))
vz.quickplot(series, kind='hist', bins=20, title='Histogram from Series')
vz.show()
vz.close()
print("   [OK] Histogram from Series")

# Test 10: quickplot with time series data
print("\n10. quickplot with time series (line)...")
ts_data = pd.DataFrame({
    'date': pd.date_range('2024-01-01', periods=30, freq='D'),
    'value': np.random.randn(30).cumsum() + 100
})
vz.quickplot(ts_data, x='date', y='value', title='Time Series Quickplot')
vz.show()
vz.close()
print("   [OK] Time series line plot")


print("\n" + "=" * 60)
print("All tests completed successfully!")
print("=" * 60)
print("\nSummary:")
print("- visualize() creates automated multi-plot dashboards")
print("- quickplot() creates single plots with minimal syntax")
print("Both functions are working correctly!")
