import pandas as pd
import numpy as np
import bottleviz as vz
import time

print("=" * 60)
print("BottleViz Large Dataset Performance Test")
print("=" * 60)

# Test with increasing dataset sizes
sizes = [1000, 10000, 100000, 500000, 1000000]

for size in sizes:
    print(f"\nTesting with {size:,} data points...")

    # Generate sample data
    np.random.seed(42)
    df = pd.DataFrame({
        'x': np.random.randn(size),
        'y': np.random.randn(size),
        'category': np.random.choice(['A', 'B', 'C', 'D', 'E'], size)
    })

    # Time the plotting operation
    start = time.time()
    try:
        fig = vz.plot(df, x='x', y='y', title=f'Scatter with {size:,} points')
        elapsed = time.time() - start
        print(f"  [OK] Plotted successfully in {elapsed:.3f} seconds")

        # Save the last plot (1M points) to file
        if size == 1000000:
            output_file = f'scatter_{size}_points.png'
            fig.savefig(output_file, dpi=150, bbox_inches='tight')
            print(f"  [SAVED] {output_file}")

        vz.close('all')  # Clean up
    except Exception as e:
        print(f"  [ERR] Error: {e}")

print("\n" + "=" * 60)
print("Test complete!")
print("=" * 60)
