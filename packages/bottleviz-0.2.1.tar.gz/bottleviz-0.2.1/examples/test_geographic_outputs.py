"""
Comprehensive test to verify all geographic plot types work and save outputs.

Run: python test_geographic_outputs.py
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')

import bottleviz as vz
import os
from shapely.geometry import Polygon

# Create output directory
output_dir = 'plots_output_geographic_test'
os.makedirs(output_dir, exist_ok=True)

print(f"Testing and generating geographic plots in '{output_dir}/'\n")
print("=" * 60)

results = []

# 1. Choropleth Map
print("\n1. CHOROPLETH MAP")
print("-" * 60)
try:
    import geopandas as gpd
    poly1 = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    poly2 = Polygon([(1, 0), (2, 0), (2, 1), (1, 1)])
    poly3 = Polygon([(2, 0), (3, 0), (3, 1), (2, 1)])
    gdf = gpd.GeoDataFrame({
        'region': ['Region A', 'Region B', 'Region C'],
        'population': [1000, 4000, 2500],
        'area_sqkm': [10, 15, 12]
    }, geometry=[poly1, poly2, poly3], crs='EPSG:4326')

    # Test with explicit geometry and value parameters
    fig = vz.plot(gdf, kind='choropleth', geometry='geometry', value='population',
                  title='Choropleth: Population by Region',
                  cmap='viridis', edgecolor='black', linewidth=0.5)
    fig.savefig(f'{output_dir}/choropleth.png', dpi=150, bbox_inches='tight')
    vz.close(fig)

    # Also test with 'color' parameter alias
    fig2 = vz.plot(gdf, kind='choropleth', geometry='geometry', color='area_sqkm',
                   title='Choropleth: Area by Region', cmap='Blues')
    fig2.savefig(f'{output_dir}/choropleth_by_area.png', dpi=150, bbox_inches='tight')
    vz.close(fig2)

    print("[OK] Choropleth works!")
    print("  - Saved: choropleth.png, choropleth_by_area.png")
    results.append(('choropleth', True, None))
except Exception as e:
    print(f"[FAIL] Choropleth: {e}")
    results.append(('choropleth', False, str(e)))

# 2. Scatter Geo
print("\n2. SCATTER GEO")
print("-" * 60)
try:
    import geopandas as gpd
    from shapely.geometry import Point
    np.random.seed(42)
    n_points = 150
    df_scatter_geo = pd.DataFrame({
        'latitude': np.random.uniform(30, 50, n_points),
        'longitude': np.random.uniform(-120, -70, n_points),
        'temperature': np.random.uniform(-5, 35, n_points),
        'humidity': np.random.uniform(30, 90, n_points),
        'city': [f'City_{i}' for i in range(n_points)]
    })

    # Test with lat/lon and value coloring
    fig = vz.plot(df_scatter_geo, kind='scatter_geo', lat='latitude', lon='longitude',
                  value='temperature', title='Scatter Geo: Temperature Distribution',
                  cmap='plasma', markersize=60, alpha=0.7, edgecolor='black')
    fig.savefig(f'{output_dir}/scatter_geo_temperature.png', dpi=150, bbox_inches='tight')
    vz.close(fig)

    # Test with just points (no value)
    fig2 = vz.plot(df_scatter_geo, kind='scatter_geo', lat='latitude', lon='longitude',
                   title='Scatter Geo: Simple Points', color='red', markersize=30)
    fig2.savefig(f'{output_dir}/scatter_geo_simple.png', dpi=150, bbox_inches='tight')
    vz.close(fig2)

    # Test with size encoding
    fig3 = vz.plot(df_scatter_geo, kind='scatter_geo', lat='latitude', lon='longitude',
                   value='humidity', title='Scatter Geo: Humidity (size encoded)',
                   cmap='coolwarm', markersize=100, alpha=0.6)
    fig3.savefig(f'{output_dir}/scatter_geo_humidity.png', dpi=150, bbox_inches='tight')
    vz.close(fig3)

    print("[OK] Scatter Geo works!")
    print("  - Saved: scatter_geo_temperature.png, scatter_geo_simple.png, scatter_geo_humidity.png")
    results.append(('scatter_geo', True, None))
except Exception as e:
    print(f"[FAIL] Scatter Geo: {e}")
    results.append(('scatter_geo', False, str(e)))

# 3. Flow Map
print("\n3. FLOW MAP")
print("-" * 60)
try:
    import geopandas as gpd
    from shapely.geometry import LineString
    df_flow = pd.DataFrame({
        'origin_lat': [40.7128, 34.0522, 41.8781, 51.5074, 35.6762],
        'origin_lon': [-74.0060, -118.2437, -87.6298, -0.1278, 139.6503],
        'dest_lat': [40.7589, 34.0522, 47.6062, 48.8566, 35.6895],
        'dest_lon': [-73.9851, -118.2437, -122.3321, 2.3522, 139.6917],
        'volume': [1000, 500, 800, 1200, 900],
        'route': ['NYC: Central Park', 'LA: Downtown', 'Chicago: Seattle', 'London: Paris', 'Tokyo: Osaka']
    })

    # Test with flow width proportional to volume
    fig = vz.plot(df_flow, kind='flow_map', origin_lat='origin_lat', origin_lon='origin_lon',
                  dest_lat='dest_lat', dest_lon='dest_lon', flow='volume',
                  title='Flow Map: Intercity Connections', color='#2196F3',
                  linewidth_scale=True, alpha=0.7, figsize=(12, 8))
    fig.savefig(f'{output_dir}/flow_map_with_volume.png', dpi=150, bbox_inches='tight')
    vz.close(fig)

    # Test without flow (simple lines)
    fig2 = vz.plot(df_flow, kind='flow_map', origin_lat='origin_lat', origin_lon='origin_lon',
                   dest_lat='dest_lat', dest_lon='dest_lon',
                   title='Flow Map: Simple Routes', color='#F44336', linewidth=2)
    fig2.savefig(f'{output_dir}/flow_map_simple.png', dpi=150, bbox_inches='tight')
    vz.close(fig2)

    print("[OK] Flow Map works!")
    print("  - Saved: flow_map_with_volume.png, flow_map_simple.png")
    results.append(('flow_map', True, None))
except Exception as e:
    print(f"[FAIL] Flow Map: {e}")
    results.append(('flow_map', False, str(e)))

# 4. Tile Map
print("\n4. TILE MAP")
print("-" * 60)
try:
    import contextily as ctx
    import geopandas as gpd
    from shapely.geometry import Polygon

    # Create realistic polygons around London
    polys = []
    labels = []
    pop = []
    for i in range(4):
        lon = -0.1 + i * 0.02
        lat = 51.5 + i * 0.01
        poly = Polygon([
            (lon, lat),
            (lon + 0.015, lat),
            (lon + 0.015, lat + 0.01),
            (lon, lat + 0.01)
        ])
        polys.append(poly)
        labels.append(f'Sector {chr(65+i)}')
        pop.append([1000, 2500, 1800, 3200][i])

    gdf = gpd.GeoDataFrame({
        'district': labels,
        'population': pop
    }, geometry=polys, crs='EPSG:4326')

    # Convert to Web Mercator for contextily
    gdf_3857 = gdf.to_crs(epsg=3857)

    # Test with tile background
    fig = vz.plot(gdf_3857, kind='tile_map', value='population',
                  title='Tile Map: Population Density with Basemap',
                  cmap='Reds', alpha=0.6, tile_source=ctx.providers.OpenStreetMap.Mapnik,
                  figsize=(10, 8))
    fig.savefig(f'{output_dir}/tile_map_with_basemap.png', dpi=150, bbox_inches='tight')
    vz.close(fig)

    # Test with Stamen Terrain tiles (if available)
    try:
        fig2 = vz.plot(gdf_3857, kind='tile_map', value='population',
                       title='Tile Map: Stamen Terrain', cmap='YlOrRd',
                       tile_source=ctx.providers.Stamen.Terrain, figsize=(10, 8))
        fig2.savefig(f'{output_dir}/tile_map_stamen.png', dpi=150, bbox_inches='tight')
        vz.close(fig2)
    except:
        pass

    print("[OK] Tile Map works!")
    print("  - Saved: tile_map_with_basemap.png")
    results.append(('tile_map', True, None))
except Exception as e:
    print(f"[FAIL] Tile Map: {e}")
    results.append(('tile_map', False, str(e)))

# 5. Cartogram
print("\n5. CARTOGRAM")
print("-" * 60)
try:
    import geopandas as gpd
    from shapely.geometry import Polygon

    # Create polygons with varying sizes
    poly1 = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    poly2 = Polygon([(1, 0), (2, 0), (2, 1), (1, 1)])
    poly3 = Polygon([(2, 0), (3, 0), (3, 1), (2, 1)])
    poly4 = Polygon([(0, 1), (1, 1), (1, 2), (0, 2)])

    gdf = gpd.GeoDataFrame({
        'region': ['North', 'South', 'East', 'West'],
        'population': [1000, 4000, 2000, 800],
        'gdp': [50, 200, 120, 40]
    }, geometry=[poly1, poly2, poly3, poly4])

    # Test cartogram with population
    fig = vz.plot(gdf, kind='cartogram', geometry='geometry', value='population',
                  title='Cartogram: Population Distortion', color='#4CAF50',
                  edgecolor='black', linewidth=0.5, figsize=(8, 6))
    fig.savefig(f'{output_dir}/cartogram_population.png', dpi=150, bbox_inches='tight')
    vz.close(fig)

    # Test with GDP
    fig2 = vz.plot(gdf, kind='cartogram', geometry='geometry', value='gdp',
                   title='Cartogram: GDP Distortion', color='#2196F3',
                   edgecolor='darkblue', linewidth=0.5, figsize=(8, 6))
    fig2.savefig(f'{output_dir}/cartogram_gdp.png', dpi=150, bbox_inches='tight')
    vz.close(fig2)

    print("[OK] Cartogram works!")
    print("  - Saved: cartogram_population.png, cartogram_gdp.png")
    results.append(('cartogram', True, None))
except Exception as e:
    print(f"[FAIL] Cartogram: {e}")
    results.append(('cartogram', False, str(e)))

# Summary
print("\n" + "=" * 60)
print("SUMMARY")
print("=" * 60)
total = len(results)
passed = sum(1 for _, success, _ in results if success)
failed = total - passed

print(f"\nGeographic Plot Types Tested: {total}")
print(f"[OK] Working: {passed}")
print(f"[FAIL] Failed: {failed}")

if failed > 0:
    print("\nFailed plots:")
    for name, success, error in results:
        if not success:
            print(f"  - {name}: {error}")

print(f"\n{'='*60}")
print(f"All output files saved to: {output_dir}/")
print("Files generated:")
for filename in sorted(os.listdir(output_dir)):
    if filename.endswith('.png'):
        filepath = os.path.join(output_dir, filename)
        size = os.path.getsize(filepath) / 1024  # KB
        print(f"  - {filename} ({size:.1f} KB)")
print(f"{'='*60}\n")

if failed == 0:
    print("SUCCESS! All geographic plot types are working correctly!")
else:
    print(f"ATTENTION: {failed} plot type(s) need attention.")
