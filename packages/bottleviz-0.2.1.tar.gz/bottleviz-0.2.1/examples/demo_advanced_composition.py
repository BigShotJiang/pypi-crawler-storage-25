"""
Demo: Advanced Plot Composition & Specialized Plots

This script demonstrates the 5 new advanced plot types:
1. Subplots with shared axes
2. Inset axes
3. Annotated heatmaps
4. Streamplot (vector field flow)
5. Tricontour/tricontourf (unstructured grid contours)

Requirements:
- bottleviz
- numpy, pandas, matplotlib

Run:
    python examples/demo_advanced_composition.py
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import bottleviz as vz

print("=" * 70)
print("BottleViz Advanced Composition & Specialized Plots Demo")
print("=" * 70)

# Create output directory
import os
output_dir = 'plots_output_advanced'
os.makedirs(output_dir, exist_ok=True)

# ============================================================================
# 1. SUBPLOTS WITH SHARED AXES
# ============================================================================
print("\n[1/5] Subplots with shared axes...")

# Generate correlated data
np.random.seed(42)
n = 100
x = np.linspace(0, 10, n)
y1 = np.sin(x) + np.random.randn(n) * 0.2
y2 = np.cos(x) + np.random.randn(n) * 0.2
y3 = np.sin(2*x) + np.random.randn(n) * 0.2

fig, axes = vz.subplots(
    n_rows=3, n_cols=1,
    sharex=True,  # Share x-axis across all subplots
    figsize=(10, 8),
    title='Multiple Series with Shared X-Axis'
)

# Plot each series
axes[0, 0].plot(x, y1, color='blue', linewidth=2)
axes[0, 0].set_ylabel('Series 1')
axes[0, 0].grid(True, alpha=0.3)

axes[1, 0].plot(x, y2, color='red', linewidth=2)
axes[1, 0].set_ylabel('Series 2')
axes[1, 0].grid(True, alpha=0.3)

axes[2, 0].plot(x, y3, color='green', linewidth=2)
axes[2, 0].set_ylabel('Series 3')
axes[2, 0].set_xlabel('Time')
axes[2, 0].grid(True, alpha=0.3)

plt.tight_layout()
fig.savefig(f'{output_dir}/01_subplots_shared.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 01_subplots_shared.png")

# ============================================================================
# 2. INSET AXES
# ============================================================================
print("\n[2/5] Inset axes (zoomed detail)...")

# Main plot
x_main = np.linspace(0, 10, 100)
y_main = np.exp(-x_main/3) * np.sin(x_main*2)

fig, main_ax, inset_ax = vz.inset(
    x=x_main, y=y_main,
    kind='line',
    title='Exponential Decay with Inset Zoom',
    xlabel='Time',
    ylabel='Amplitude',
    figsize=(10, 6)
)

# Add zoomed region in inset
inset_bounds = (0.4, 0.4, 0.5, 0.5)  # left, bottom, width, height
# Actually, let's use the proper vz.inset API
# Recreate with proper API

fig, ax = vz.figure()
ax.plot(x_main, y_main, 'b-', linewidth=2)
ax.set_xlabel('Time')
ax.set_ylabel('Amplitude')
ax.set_title('Main Plot with Inset Zoom')
ax.grid(True, alpha=0.3)

# Create inset axes showing zoomed region
inset_ax = ax.inset_axes([0.6, 0.6, 0.35, 0.35])  # [left, bottom, width, height]
zoom_mask = (x_main >= 2) & (x_main <= 4)
inset_ax.plot(x_main[zoom_mask], y_main[zoom_mask], 'r-', linewidth=2)
inset_ax.set_xlim(2, 4)
inset_ax.set_ylim(-0.5, 0.5)
inset_ax.grid(True, alpha=0.3)
inset_ax.set_title('Zoomed Region', fontsize=9)

plt.tight_layout()
fig.savefig(f'{output_dir}/02_inset.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 02_inset.png")

# ============================================================================
# 3. ANNOTATED HEATMAP
# ============================================================================
print("\n[3/5] Annotated heatmap...")

# Generate correlation matrix
np.random.seed(123)
n_vars = 6
data = np.random.randn(200, n_vars)
corr_matrix = np.corrcoef(data.T)
var_names = [f'Var{i}' for i in range(1, n_vars+1)]

df_corr = pd.DataFrame(corr_matrix, index=var_names, columns=var_names)

# Use vz.plot with kind='heatmap' but enhanced annotations
fig = vz.plot(
    df_corr,
    kind='heatmap',
    title='Correlation Matrix with Annotations',
    cmap='RdYlBu',
    center=0,
    vmin=-1,
    vmax=1,
    annot=True,
    fmt='.2f',
    annot_fontsize=9,
    cbar=True
)
fig.savefig(f'{output_dir}/03_annotated_heatmap.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 03_annotated_heatmap.png")

# ============================================================================
# 4. STREAMPLOT (Vector Field Flow Lines)
# ============================================================================
print("\n[4/5] Streamplot (vector field)...")

# Create 2D vector field on regular grid
x = np.linspace(-3, 3, 20)
y = np.linspace(-3, 3, 20)
X, Y = np.meshgrid(x, y)

# Create a flow field (spiral pattern)
U = -Y / (X**2 + Y**2 + 0.1)  # x component
V = X / (X**2 + Y**2 + 0.1)   # y component

# Normalize for better visualization
mag = np.sqrt(U**2 + V**2)
U_norm = U / mag
V_norm = V / mag

# Convert to DataFrame for BottleViz
stream_df = pd.DataFrame({
    'x': X.flatten(),
    'y': Y.flatten(),
    'u': U_norm.flatten(),
    'v': V_norm.flatten(),
    'magnitude': mag.flatten()
})

fig = vz.plot(
    stream_df,
    kind='streamplot',
    x='x', y='y', u='u', v='v',
    density=2,
    linewidth=1,
    color='magnitude',  # Color by speed
    cmap='viridis',
    arrowsize=1.2,
    title='Streamplot: Vector Field Flow Lines'
)
fig.savefig(f'{output_dir}/04_streamplot.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 04_streamplot.png")

# ============================================================================
# 5. TRICONTOUR / TRICONTOURF (Unstructured Grid)
# ============================================================================
print("\n[5/5] Tricontour & Tricontourf (scattered data)...")

# Generate scattered data points
np.random.seed(42)
n_points = 500
x_tri = np.random.uniform(-3, 3, n_points)
y_tri = np.random.uniform(-3, 3, n_points)
# Create a smooth function with some noise
z_tri = np.sin(x_tri) * np.cos(y_tri) + np.random.randn(n_points) * 0.1

tri_df = pd.DataFrame({'x': x_tri, 'y': y_tri, 'z': z_tri})

# Tricontour (lines)
fig1 = vz.plot(
    tri_df,
    x='x', y='y', z='z',
    kind='tricontour',
    levels=15,
    cmap='coolwarm',
    linewidths=1.0,
    colorbar=True,
    title='Tricontour: Contour Lines on Scattered Data'
)
fig1.savefig(f'{output_dir}/05a_tricontour.png', dpi=150, bbox_inches='tight')
vz.close(fig1)
print("   [OK] Saved: 05a_tricontour.png")

# Tricontourf (filled)
fig2 = vz.plot(
    tri_df,
    x='x', y='y', z='z',
    kind='tricontourf',
    levels=20,
    cmap='viridis',
    colorbar=True,
    title='Tricontourf: Filled Contours on Scattered Data'
)
fig2.savefig(f'{output_dir}/05b_tricontourf.png', dpi=150, bbox_inches='tight')
vz.close(fig2)
print("   [OK] Saved: 05b_tricontourf.png")

# ============================================================================
# SUMMARY
# ============================================================================
print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)
print(f"\nAll plots saved to: {output_dir}/")
print("\nFiles created:")
print("  1. subplots_shared.png - Multi-panel figure with shared axes")
print("  2. inset.png - Main plot with zoomed inset axes")
print("  3. annotated_heatmap.png - Heatmap with values in each cell")
print("  4. streamplot.png - Vector field flow lines")
print("  5a. tricontour.png - Contour lines on scattered data")
print("  5b. tricontourf.png - Filled contours on scattered data")
print("\nKey features demonstrated:")
print("  - Subplot sharing axes for synchronized zooming")
print("  - Inset axes for focused detail views")
print("  - Text annotations directly on heatmaps")
print("  - Streamlines that follow vector field direction")
print("  - Contours on unstructured (non-gridded) data points")
print("=" * 70)
