"""
Quick Reference: figure3d() for Custom 3D Plots

This minimal example demonstrates the core pattern for using figure3d().
"""

import bottleviz as vz
import numpy as np

# 1. Generate or prepare your data
x = np.linspace(-5, 5, 50)
y = np.linspace(-5, 5, 50)
X, Y = np.meshgrid(x, y)
Z = np.sin(np.sqrt(X**2 + Y**2))

# 2. Create empty 3D figure - returns (fig, ax)
fig, ax = vz.figure3d(
    title='My 3D Plot',
    xlabel='X',
    ylabel='Y',
    zlabel='Z',
    figsize=(10, 8)
)

# 3. Use standard matplotlib 3D methods on ax
ax.plot_surface(X, Y, Z, cmap='viridis', alpha=0.9)
ax.contour(X, Y, Z, levels=15, colors='black', alpha=0.5, offset=Z.min())

# 4. Display
vz.show()

# 5. Clean up (optional but recommended)
vz.close(fig)
