"""
Demo: Interactive Plotly Visualizations with BottleViz

This script demonstrates how to create interactive HTML plots using
vz.show_plotly() and vz.save_plotly().

Requirements:
- bottleviz[plotly] or pip install plotly

Run:
    python examples/demo_plotly_interactive.py
"""

import numpy as np
import pandas as pd
import bottleviz as vz

print("=" * 70)
print("BottleViz Interactive Plotly Demo")
print("=" * 70)

# Generate sample data
np.random.seed(42)
n = 200

df = pd.DataFrame({
    'x': np.random.randn(n),
    'y': np.random.randn(n) * 2 + 1,
    'z': np.random.randn(n) * 3,
    'category': np.random.choice(['Group A', 'Group B', 'Group C'], n),
    'size': np.random.randint(10, 100, n)
})

print(f"\nCreated dataset with {len(df)} rows and columns: {list(df.columns)}")

# Create output directory
import os
output_dir = 'plots_output_interactive'
os.makedirs(output_dir, exist_ok=True)

# ============================================================================
# 1. SCATTER PLOT (interactive with hover, zoom, pan)
# ============================================================================
print("\n[1/5] Creating interactive scatter plot...")
html = vz.show_plotly(
    df, x='x', y='y',
    kind='scatter',
    title='Interactive Scatter Plot',
    color='category',
    size='size'
)
with open(f'{output_dir}/01_scatter_interactive.html', 'w', encoding='utf-8') as f:
    f.write(html)
print("   Saved: 01_scatter_interactive.html")

# ============================================================================
# 2. LINE PLOT
# ============================================================================
print("\n[2/5] Creating interactive line plot...")
ts = pd.DataFrame({
    'date': pd.date_range('2024-01-01', periods=100, freq='D'),
    'value': np.random.randn(100).cumsum() + 50,
    'series': np.random.choice(['A', 'B'], 100)
})
vz.save_plotly(
    ts, f'{output_dir}/02_line_interactive.html',
    x='date', y='value',
    kind='line',
    title='Interactive Time Series',
    color='series'
)
print("   Saved: 02_line_interactive.html")

# ============================================================================
# 3. BAR CHART
# ============================================================================
print("\n[3/5] Creating interactive bar chart...")
summary = df.groupby('category')['y'].mean().reset_index()
vz.save_plotly(
    summary, f'{output_dir}/03_bar_interactive.html',
    x='category', y='y',
    kind='bar',
    title='Average Value by Category',
    color='category'
)
print("   Saved: 03_bar_interactive.html")

# ============================================================================
# 4. HISTOGRAM
# ============================================================================
print("\n[4/5] Creating interactive histogram...")
vz.save_plotly(
    df, f'{output_dir}/04_hist_interactive.html',
    x='x',
    kind='hist',
    title='Distribution of X',
    nbins=30,
    color='category'
)
print("   Saved: 04_hist_interactive.html")

# ============================================================================
# 5. BOX PLOT
# ============================================================================
print("\n[5/5] Creating interactive box plot...")
vz.save_plotly(
    df, f'{output_dir}/05_box_interactive.html',
    x='category', y='y',
    kind='box',
    title='Distribution by Category',
    boxmode='group'
)
print("   Saved: 05_box_interactive.html")

# ============================================================================
# 6. 3D SCATTER
# ============================================================================
print("\n[6/7] Creating interactive 3D scatter...")
vz.save_plotly(
    df, f'{output_dir}/06_scatter3d_interactive.html',
    x='x', y='y', z='z',
    kind='3d',
    title='3D Scatter Plot',
    color='category'
)
print("   Saved: 06_scatter3d_interactive.html")

# ============================================================================
# 7. 3D SURFACE
# ============================================================================
# print("\n[7/7] Creating interactive 3D surface plot...")

# # Generate surface data: sinc function
# x_surf = np.linspace(-5, 5, 50)
# y_surf = np.linspace(-5, 5, 50)
# X_surf, Y_surf = np.meshgrid(x_surf, y_surf)
# Z_surf = np.sin(np.sqrt(X_surf**2 + Y_surf**2))

# df_surface = pd.DataFrame({
#     'x': X_surf.flatten(),
#     'y': Y_surf.flatten(),
#     'z': Z_surf.flatten()
# })

# vz.save_plotly(
#     df_surface, f'{output_dir}/07_surface_interactive.html',
#     x='x', y='y', z='z',
#     kind='surface',
#     title='3D Surface Plot (Sinc Function)',
#     colorscale='Viridis'
# )
# print("   Saved: 07_surface_interactive.html")

# ============================================================================
# SUMMARY
# ============================================================================
print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)
print(f"\nAll interactive HTML plots saved to: {output_dir}/")
print("\nFiles created:")
print("  1. scatter_interactive.html - Interactive scatter with hover tooltips")
print("  2. line_interactive.html - Time series with zoom/pan")
print("  3. bar_interactive.html - Bar chart with clickable legend")
print("  4. hist_interactive.html - Histogram with bin selection")
print("  5. box_interactive.html - Box plot with hover statistics")
print("  6. scatter3d_interactive.html - 3D scatter with rotation")
print("  7. surface_interactive.html - 3D surface with zoom/rotate")
print("\nTo view: Open the HTML files in any web browser.")
print("=" * 70)
