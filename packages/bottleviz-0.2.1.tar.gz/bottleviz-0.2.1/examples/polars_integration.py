"""
Using Bottleviz with Polars DataFrames

This example demonstrates how to use Bottleviz with polars DataFrames,
and also shows polars' native plotting capabilities for comparison.
"""

import numpy as np
import pandas as pd

# Import both libraries
try:
    import polars as pl
    POLARS_AVAILABLE = True
except ImportError:
    POLARS_AVAILABLE = False
    print("Polars not installed. Skipping polars examples.")

import bottleviz as vz

# ============================================================================
# Create sample data using polars
# ============================================================================
if POLARS_AVAILABLE:
    print("="*60)
    print("POLARS + BOTTLEVIZ INTEGRATION")
    print("="*60)

    # Create a polars DataFrame
    n_days = 365
    dates = pd.date_range(start='2024-01-01', periods=n_days, freq='D')

    df_pl = pl.DataFrame({
        'date': dates,
        'sales': np.random.randn(n_days).cumsum() + 100,
        'profit': np.random.randn(n_days).cumsum() + 20,
        'category': np.random.choice(['A', 'B', 'C'], n_days),
        'quantity': np.random.randint(1, 100, n_days)
    })

    print("\n1. Polars DataFrame created successfully")
    print(f"   Shape: {df_pl.shape}")
    print(f"   Columns: {', '.join(df_pl.columns)}")

    # ========================================================================
    # Bottleviz with polars (convert to pandas first)
    # ========================================================================
    print("\n2. Using Bottleviz with polars DataFrame (via .to_pandas())")

    # Convert polars to pandas for Bottleviz compatibility
    # Note: full to_pandas() may require pyarrow. Alternative: use to_dict()
    try:
        df_pd = df_pl.to_pandas()
    except Exception:
        # Fallback without pyarrow
        df_pd = pd.DataFrame(df_pl.to_dict())

    # Line plot - auto-detected due to datetime column
    vz.plot(df_pd, x='date', y='sales', title='Sales Over Time (Bottleviz)')
    vz.show()
    vz.close()

    # Scatter plot
    vz.plot(df_pd, x='sales', y='profit', title='Sales vs Profit')
    vz.show()
    vz.close()

    # Bar chart - vz.suggest_plots() works with pandas data
    print("\n3. Auto-suggested plots:")
    suggestions = vz.suggest_plots(df_pd)
    print(suggestions)

    # Dashboard visualization
    vz.visualize(df_pd[['sales', 'profit', 'quantity']])
    vz.show()
    vz.close()

    # ========================================================================
    # Polars native plotting (using plotly backend)
    # ========================================================================
    print("\n4. Polars native plotting (requires 'plotly' engine)")

    try:
        # Polars has built-in plotting methods that use plotly
        # These create interactive HTML plots

        # Simple line plot using polars' .plot() method
        fig1 = df_pl.plot(
            x='date',
            y='sales',
            kind='line',
            title='Sales Over Time (Polars Native)'
        )
        print("   - Polars line plot created (would open in browser if in notebook)")

        # Multiple lines
        fig2 = df_pl.select(['date', 'sales', 'profit']).plot(
            x='date',
            title='Sales & Profit Over Time'
        )
        print("   - Polars multi-line plot created")

        # Scatter matrix
        fig3 = df_pl.select(['sales', 'profit', 'quantity']).plot.scatter_matrix()
        print("   - Polars scatter matrix created")

        print("\n   Note: Polars plots are interactive Plotly figures.")
        print("   They display automatically in Jupyter notebooks.")
        print("   In scripts, save them with .write_html()")

    except Exception as e:
        print(f"   Polars plotting error (optional dependency): {e}")

    # ========================================================================
    # Performance comparison - Bottleviz optimizations
    # ========================================================================
    print("\n5. Large dataset optimization (Bottleviz)")

    # Create larger polars DataFrame
    large_df = pl.DataFrame({
        'x': np.random.randn(100000),
        'y': np.random.randn(100000),
        'category': np.random.choice(['A', 'B', 'C', 'D'], 100000)
    })

    print(f"   Dataset size: {len(large_df):,} rows")

    # Bottleviz automatically downsamples for performance
    vz.plot(large_df, x='x', y='y', title='Large Dataset (auto downsampled)')
    vz.show()
    vz.close()

    # Convert polars to pandas if needed (zero-copy when possible)
    print("\n6. Converting between polars and pandas")

    # Polars -> Pandas (zero-copy for numeric columns)
    df_pd = df_pl.to_pandas()
    print(f"   Polars -> Pandas: {type(df_pd).__name__}")

    # Bottleviz handles both seamlessly
    vz.plot(df_pd, x='sales', y='profit', title='From Pandas (converted)')
    vz.show()
    vz.close()

    # ========================================================================
    # Advanced: Custom 3D with polars data
    # ========================================================================
    print("\n7. Custom 3D plots using polars data")

    # Create 3D data in polars
    x = np.linspace(-5, 5, 50)
    y = np.linspace(-5, 5, 50)
    X, Y = np.meshgrid(x, y)
    Z = np.cos(X) * np.sin(Y)

    df_3d = pl.DataFrame({
        'x': X.flatten(),
        'y': Y.flatten(),
        'z': Z.flatten()
    })

    # Use figure3d() for custom plotting
    fig, ax = vz.figure3d(title='3D Surface from Polars Data')
    n = int(np.sqrt(len(df_3d)))
    ax.plot_surface(
        df_3d['x'].to_numpy().reshape(n, n),
        df_3d['y'].to_numpy().reshape(n, n),
        df_3d['z'].to_numpy().reshape(n, n),
        cmap='coolwarm',
        alpha=0.9
    )
    vz.show()
    vz.close()

    # ========================================================================
    # Summary
    # ========================================================================
    print("\n" + "="*60)
    print("SUMMARY: Bottleviz + Polars")
    print("="*60)
    print("✓ Pass polars DataFrames directly to Bottleviz functions")
    print("✓ Automatic type detection works with polars dtypes")
    print("✓ Use .to_pandas() for explicit conversion if needed")
    print("✓ Polars has native .plot() method (plotly-based, interactive)")
    print("✓ Bottleviz: static, publication-ready plots with smart defaults")
    print("✓ Polars: interactive, browser-based plots")
    print("="*60)

else:
    print("Polars is not installed. Install with: pip install polars")
    print("This example requires polars to run.")
