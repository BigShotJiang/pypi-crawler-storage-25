"""
Demonstration of the new show() and close() functions.

This shows how users can now display plots without importing matplotlib.
"""

import bottleviz as vz
import pandas as pd
import numpy as np

# Create sample data for an empty cone surface
# Generate a meshgrid for a continuous surface
n_theta = 50  # Points around the circumference
n_z = 50      # Points along the height

theta = np.linspace(0, 2*np.pi, n_theta)  # Angle around cone
z = np.linspace(1, 10, n_z)  # Height of cone

# Create meshgrid
Theta, Z = np.meshgrid(theta, z)

# Cone equation: radius increases linearly with height
# r = slope * z, where slope determines the cone's steepness
slope = 0.5
R = slope * Z

# Convert to Cartesian coordinates
X = R * np.cos(Theta)
Y = R * np.sin(Theta)

# Flatten for DataFrame
data = pd.DataFrame({
    'x': X.flatten(),
    'y': Y.flatten(),
    'z': Z.flatten()
})
# Create a surface plot (points connected by planes)
fig = vz.plot(data, x='x', y='y', z='z', kind='3d', surface=True, title='Cone Surface Plot')

vz.show()
vz.close()