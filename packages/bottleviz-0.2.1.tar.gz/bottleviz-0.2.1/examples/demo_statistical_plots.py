"""
Comprehensive demo for all new Statistical & EDA plot types in BottleViz

This script tests all 13 new plot types added:
- pairplot, jointplot, boxen, rug, strip, swarm
- qqplot, residualplot, autocorrelation, lagplot
- andrews_curves, parallel_coordinates, radviz

Requirements:
- bottleviz
- pandas, numpy, matplotlib
- scipy (for some plots like qqplot, kde options)

Run:
    python examples/demo_statistical_plots.py
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import bottleviz as vz

# Create output directory
output_dir = 'plots_output_statistical'
os.makedirs(output_dir, exist_ok=True)

print("=" * 70)
print("BottleViz Statistical & EDA Plots Demo")
print("=" * 70)

# ============================================================================
# GENERATE TEST DATA
# ============================================================================
print("\n[1/4] Generating test data...")

np.random.seed(42)
n = 200

# Main dataset for most plots
df = pd.DataFrame({
    'numeric1': np.random.randn(n),
    'numeric2': np.random.randn(n) + 2,
    'numeric3': np.random.randn(n) * 2 + 1,
    'category': np.random.choice(['Group A', 'Group B', 'Group C'], n),
    'category2': np.random.choice(['X', 'Y'], n),
    'value': np.random.exponential(2, n)
})

# Time series data
ts_data = pd.DataFrame({
    'time': pd.date_range('2024-01-01', periods=100, freq='D'),
    'value': np.random.randn(100).cumsum() + 50
})

# Iris dataset for multivariate plots
try:
    iris = pd.read_csv('https://raw.githubusercontent.com/mwaskom/seaborn-data/master/iris.csv')
    print("  [OK] Loaded Iris dataset for multivariate plots")
except Exception as e:
    print(f"  [WARN] Could not load Iris dataset: {e}")
    # Create synthetic alternative
    iris = pd.DataFrame({
        'sepal_length': np.random.randn(150) * 0.5 + 5.8,
        'sepal_width': np.random.randn(150) * 0.5 + 3.0,
        'petal_length': np.random.randn(150) * 0.5 + 3.8,
        'petal_width': np.random.randn(150) * 0.5 + 1.2,
        'species': np.random.choice(['setosa', 'versicolor', 'virginica'], 150)
    })
    print("  ✓ Using synthetic Iris-like dataset")

print(f"  Created {len(df)} samples for general testing")
print(f"  Created {len(ts_data)} time points for time series")
if 'iris' in locals():
    print(f"  Loaded {len(iris)} samples for multivariate analysis")

# ============================================================================
# 2. CREATE PLOTS
# ============================================================================
print("\n[2/4] Generating visualizations...")

success_count = 0
failures = []

# --- Univariate & Distribution plots ---

# 1. Rug Plot
print("  - rug...", end=" ")
try:
    fig = vz.plot(df, x='numeric1', kind='rug', title='Rug Plot: Numeric 1')
    fig.savefig(f'{output_dir}/01_rug.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('rug', str(e)))

# 2. Histogram
print("  - hist...", end=" ")
try:
    fig = vz.plot(df, x='value', kind='hist', title='Histogram')
    fig.savefig(f'{output_dir}/02_hist.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('hist', str(e)))

# 3. KDE Plot
print("  - kde...", end=" ")
try:
    fig = vz.plot(df, x='value', kind='kde', title='KDE Plot')
    fig.savefig(f'{output_dir}/03_kde.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('kde', str(e)))

# 4. Boxen Plot
print("  - boxen...", end=" ")
try:
    fig = vz.plot(df, x='category', y='value', kind='boxen', title='Boxen Plot by Category')
    fig.savefig(f'{output_dir}/04_boxen.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('boxen', str(e)))

# 5. Strip Plot
print("  - strip...", end=" ")
try:
    fig = vz.plot(df, x='category', y='numeric1', kind='strip', title='Strip Plot')
    fig.savefig(f'{output_dir}/05_strip.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('strip', str(e)))

# 6. Swarm Plot
print("  - swarm...", end=" ")
try:
    fig = vz.plot(df, x='category', y='numeric1', kind='swarm', title='Swarm Plot')
    fig.savefig(f'{output_dir}/06_swarm.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('swarm', str(e)))

# --- Bivariate plots ---

# 7. Scatter Plot
print("  - scatter...", end=" ")
try:
    fig = vz.plot(df, x='numeric1', y='numeric2', kind='scatter', title='Scatter Plot')
    fig.savefig(f'{output_dir}/07_scatter.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('scatter', str(e)))

# 8. Joint Plot
print("  - jointplot...", end=" ")
try:
    fig = vz.plot(df, x='numeric1', y='numeric2', kind='jointplot', title='Joint Plot')
    fig.savefig(f'{output_dir}/08_jointplot.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('jointplot', str(e)))

# 9. Joint Plot with KDE
print("  - jointplot (kde)...", end=" ")
try:
    fig = vz.plot(df, x='numeric1', y='numeric2', kind='jointplot', marginal_kind='kde', title='Joint Plot with KDE')
    fig.savefig(f'{output_dir}/09_jointplot_kde.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('jointplot_kde', str(e)))

# 10. Residual Plot
print("  - residualplot...", end=" ")
try:
    fig = vz.plot(df, x='numeric1', y='numeric2', kind='residualplot', title='Residual Plot')
    fig.savefig(f'{output_dir}/10_residual.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('residualplot', str(e)))

# --- Q-Q plot ---

# 11. Q-Q Plot
print("  - qqplot...", end=" ")
try:
    fig = vz.plot(df, x='value', kind='qqplot', title='Q-Q Plot (Normal)')
    fig.savefig(f'{output_dir}/11_qqplot.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('qqplot', str(e)))

# --- Time Series plots ---

# 12. Lag Plot
print("  - lagplot...", end=" ")
try:
    fig = vz.plot(ts_data, x='value', kind='lagplot', lag=1, title='Lag Plot (lag=1)')
    fig.savefig(f'{output_dir}/12_lagplot.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('lagplot', str(e)))

# 13. Autocorrelation
print("  - autocorrelation...", end=" ")
try:
    fig = vz.plot(ts_data, x='value', kind='autocorrelation', lags=30, title='Autocorrelation (ACF)')
    fig.savefig(f'{output_dir}/13_autocorrelation.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('autocorrelation', str(e)))

# --- Multivariate plots ---

# 14. Andrews Curves
print("  - andrews_curves...", end=" ")
try:
    fig = vz.plot(iris, x='species',
                  columns=['sepal_length', 'sepal_width', 'petal_length', 'petal_width'],
                  kind='andrews_curves', title='Andrews Curves')
    fig.savefig(f'{output_dir}/14_andrews.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('andrews_curves', str(e)))

# 15. Parallel Coordinates
print("  - parallel_coordinates...", end=" ")
try:
    fig = vz.plot(iris, x='species',
                  columns=['sepal_length', 'sepal_width', 'petal_length', 'petal_width'],
                  kind='parallel_coordinates', title='Parallel Coordinates')
    fig.savefig(f'{output_dir}/15_parallel.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('parallel_coordinates', str(e)))

# 16. RadViz
print("  - radviz...", end=" ")
try:
    fig = vz.plot(iris, x='species',
                  columns=['sepal_length', 'sepal_width', 'petal_length', 'petal_width'],
                  kind='radviz', title='RadViz')
    fig.savefig(f'{output_dir}/16_radviz.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('radviz', str(e)))

# --- Pairplot (matrix of plots) ---

# 17. Pair Plot
print("  - pairplot...", end=" ")
try:
    fig = vz.plot(df,
                  columns=['numeric1', 'numeric2', 'numeric3'],
                  kind='pairplot', title='Pair Plot (Scatter Matrix)')
    fig.savefig(f'{output_dir}/17_pairplot.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("[OK]")
    success_count += 1
except Exception as e:
    print(f"[FAIL] {e}")
    failures.append(('pairplot', str(e)))

# ============================================================================
# 3. SUMMARY
# ============================================================================
print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)
total = success_count + len(failures)
print(f"\nTotal plots generated: {total}")
print(f"[OK] Successful: {success_count}")
print(f"[FAIL] Failed: {len(failures)}")

if failures:
    print("\nFailed plots:")
    for kind, error in failures:
        print(f"  - {kind}: {error[:80]}...")

print(f"\nAll plots saved to: {output_dir}/")
print("=" * 70)

# Print instructions for viewing
print("\nTo view the plots:")
print(f"  1. Open the '{output_dir}' folder")
print("  2. Check the PNG files")
print("  3. Compare outputs to ensure all plot types render correctly")
