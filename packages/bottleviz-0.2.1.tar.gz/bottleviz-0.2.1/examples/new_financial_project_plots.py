"""
Demo script showcasing the three newest plot types: Waterfall, Gantt, and OHLC+Volume.

Run: python examples/new_financial_project_plots.py
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')

import bottleviz as vz
import os

output_dir = 'plots_output_financial'
os.makedirs(output_dir, exist_ok=True)

print("Generating 3 new financial/project plot types...\n")

# 1. Waterfall Chart
print(" [1/3] Waterfall Chart...")
waterfall_data = pd.DataFrame({
    'category': ['Net Income', 'Operating Expenses', 'Taxes', 'Investments', 'Other'],
    'change': [1000, -300, -150, -200, 50]
})
fig = vz.plot(waterfall_data, x='category', y='change', kind='waterfall',
             title='Profit Waterfall Chart', figsize=(10, 6))
fig.savefig(f'{output_dir}/waterfall.png', dpi=100, bbox_inches='tight')
vz.close(fig)

# 2. Gantt Chart
print(" [2/3] Gantt Chart...")
gantt_data = pd.DataFrame({
    'task': ['Project Planning', 'Design', 'Implementation', 'Testing', 'Deployment'],
    'start': ['2024-01-01', '2024-02-15', '2024-03-15', '2024-05-01', '2024-06-01'],
    'end': ['2024-02-14', '2024-03-14', '2024-05-01', '2024-06-01', '2024-06-30']
})
fig = vz.plot(gantt_data, task='task', start='start', end='end', kind='gantt',
             title='Project Timeline Gantt Chart', figsize=(12, 6))
fig.savefig(f'{output_dir}/gantt.png', dpi=100, bbox_inches='tight')
vz.close(fig)

# 3. OHLC with Volume
print(" [3/3] OHLC+Volume Chart...")
np.random.seed(42)
n_days = 30
dates = pd.date_range('2024-01-01', periods=n_days, freq='D')
opens = 100 + np.random.randn(n_days).cumsum() * 0.5
highs = opens + np.random.rand(n_days) * 3
lows = opens - np.random.rand(n_days) * 3
closes = lows + np.random.rand(n_days) * (highs - lows)
volumes = np.random.randint(1000, 5000, n_days)

ohlc_data = pd.DataFrame({
    'date': dates,
    'open': opens,
    'high': highs,
    'low': lows,
    'close': closes,
    'volume': volumes
})
# Ensure high is max and low is min
ohlc_data['high'] = ohlc_data[['open', 'close', 'high']].max(axis=1)
ohlc_data['low'] = ohlc_data[['open', 'close', 'low']].min(axis=1)

fig = vz.plot(ohlc_data, x='date', open='open', high='high', low='low',
             close='close', volume='volume', kind='ohlc_volume',
             title='Stock Price with Volume', figsize=(14, 8))
fig.savefig(f'{output_dir}/ohlc_volume.png', dpi=100, bbox_inches='tight')
vz.close(fig)

print(f"\nAll 3 plots generated and saved to '{output_dir}/'")
print("=" * 60)
