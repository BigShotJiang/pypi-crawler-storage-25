"""
Demo script showcasing all 12 new plot types added to BottleViz.

Run: python -m bottleviz.examples.new_plots_demo
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Non-interactive for demo

import bottleviz as vz

print("Generating demonstrations of 12 new plot types...")

# 1. Stacked Bar Chart
print(" 1. Stacked Bar...")
df = pd.DataFrame({
    'category': ['Q1', 'Q2', 'Q3', 'Q4'],
    'Revenue': [120, 150, 180, 200],
    'Cost': [80, 90, 100, 110]
})
fig = vz.plot(df, x='category', y=['Revenue', 'Cost'], kind='stacked_bar',
              title='Quarterly Performance (Stacked)')
vz.close(fig)

# 2. Grouped Bar Chart
print(" 2. Grouped Bar...")
df = pd.DataFrame({
    'group': ['A', 'B', 'C'],
    '2023': [100, 120, 90],
    '2024': [110, 130, 100]
})
fig = vz.plot(df, x='group', y=['2023', '2024'], kind='grouped_bar',
              title='Year-over-Year Comparison')
vz.close(fig)

# 3. Hexbin Plot
print(" 3. Hexbin...")
np.random.seed(42)
df = pd.DataFrame({
    'x': np.random.randn(2000),
    'y': np.random.randn(2000)
})
fig = vz.plot(df, x='x', y='y', kind='hexbin',
              title='2D Density with Hexbin', gridsize=30, cmap='viridis')
vz.close(fig)

# 4. Step Plot
print(" 4. Step...")
df = pd.DataFrame({
    'time': [0, 1, 2, 3, 4, 5],
    'signal': [0, 1, 1, 0, 1, 0]
})
fig = vz.plot(df, x='time', y='signal', kind='step',
              title='Digital Signal (Step Plot)', where='pre')
vz.close(fig)

# 5. Fill Between
print(" 5. Fill Between...")
df = pd.DataFrame({
    'day': range(30),
    'temperature': 20 + 10 * np.sin(np.linspace(0, 3*np.pi, 30)) + np.random.randn(30)*2,
})
# Simulate confidence interval
df['upper'] = df['temperature'] + 3
df['lower'] = df['temperature'] - 3
fig = vz.plot(df, x='day', y='temperature', y_lower='lower', y_upper='upper',
              kind='fill_between', title='Temperature with Confidence Interval')
vz.close(fig)

# 6. 2D Contour Plot
print(" 6. Contour...")
x = np.linspace(-3, 3, 40)
y = np.linspace(-3, 3, 40)
X, Y = np.meshgrid(x, y)
Z = np.sin(X) * np.cos(Y) + 0.5 * np.sin(2*X)
df_contour = pd.DataFrame({
    'x': X.flatten(),
    'y': Y.flatten(),
    'z': Z.flatten()
})
fig = vz.plot(df_contour, x='x', y='y', z='z', kind='contour',
              title='2D Contour Lines', levels=15)
vz.close(fig)

# 7. Pcolormesh
print(" 7. Pcolormesh...")
fig = vz.plot(df_contour, x='x', y='y', value='z', kind='pcolormesh',
              title='Pcolormesh', cmap='plasma')
vz.close(fig)

# 8. Quiver (2D Vector Field)
print(" 8. Quiver...")
x = np.linspace(0, 2*np.pi, 10)
y = np.linspace(0, 2*np.pi, 10)
X, Y = np.meshgrid(x, y)
U = np.cos(X)
V = -np.sin(Y)
df_quiver = pd.DataFrame({
    'x': X.flatten(),
    'y': Y.flatten(),
    'u': U.flatten(),
    'v': V.flatten()
})
fig = vz.plot(df_quiver, x='x', y='y', u='u', v='v', kind='quiver',
              title='2D Vector Field')
vz.close(fig)

# 9. Spy Plot
print(" 9. Spy...")
# Create a sparse block diagonal matrix
sparse = np.block([
    [np.eye(10), np.zeros((10, 10))],
    [np.zeros((10, 10)), np.eye(10)]
])
df_sparse = pd.DataFrame(sparse)
fig = vz.plot(df_sparse, kind='spy', markersize=2,
              title='Sparse Matrix Structure')
vz.close(fig)

# 10. Polar Plot
print("10. Polar...")
theta = np.linspace(0, 2*np.pi, 200)
r = 1 + 0.5 * np.cos(3 * theta) + 0.3 * np.sin(5 * theta)
df_polar = pd.DataFrame({'theta': theta, 'r': r})
fig = vz.plot(df_polar, theta='theta', r='r', kind='polar',
              title='Polar Plot (Rose Curve)', fill=True, alpha=0.6)
vz.close(fig)

# 11. Table Plot
print("11. Table...")
data = pd.DataFrame({
    'Model': ['ResNet-50', 'BERT', 'GPT-3', 'XLNet', 'T5'],
    'Accuracy': [92.1, 93.2, 95.0, 94.5, 93.8],
    'Speed (tok/s)': [1250, 890, 45, 320, 280],
    'Params (B)': [0.25, 0.11, 175, 0.34, 11]
})
fig = vz.plot(data, kind='table', max_rows=5, fontsize=9,
              title='Model Comparison Table')
vz.close(fig)

# 12. Eventplot
print("12. Eventplot...")
# Simulate patient medication timeline
events = pd.DataFrame({
    'Patient A': [0, 1, 0, 1, 0, 0, 1],
    'Patient B': [1, 0, 0, 1, 0, 0, 0],
    'Patient C': [0, 0, 1, 1, 0, 1, 1]
})
fig = vz.plot(events, kind='eventplot',
              title='Medication Events Over Time',
              ylabel='Patient')
vz.close(fig)

# 13. Choropleth Map
print("13. Choropleth Map...")
try:
    from shapely.geometry import Polygon
    import geopandas as gpd
    poly1 = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    poly2 = Polygon([(1, 0), (2, 0), (2, 1), (1, 1)])
    gdf = gpd.GeoDataFrame({
        'region': ['Region A', 'Region B'],
        'population': [1000, 2000]
    }, geometry=[poly1, poly2], crs='EPSG:4326')
    fig = vz.plot(gdf, kind='choropleth', geometry='geometry', value='population',
                  title='Choropleth: Population by Region', cmap='Oranges')
    vz.close(fig)
except ImportError as e:
    print(f" 13. Skipped (missing dependencies: {e})")

# 14. Scatter Geo
print("14. Scatter Geo...")
try:
    np.random.seed(42)
    df_scatter_geo = pd.DataFrame({
        'latitude': np.random.uniform(-10, 10, 100),
        'longitude': np.random.uniform(-10, 10, 100),
        'value': np.random.randint(0, 100, 100)
    })
    fig = vz.plot(df_scatter_geo, kind='scatter_geo', lat='latitude', lon='longitude',
                  value='value', title='Scatter Geo: Points on Map',
                  cmap='viridis', markersize=30, alpha=0.7)
    vz.close(fig)
except ImportError as e:
    print(f" 14. Skipped (missing dependencies: {e})")

# 15. Flow Map
print("15. Flow Map...")
try:
    df_flow = pd.DataFrame({
        'origin_lat': [40.7128, 34.0522, 41.8781],
        'origin_lon': [-74.0060, -118.2437, -87.6298],
        'dest_lat': [40.7589, 34.0522, 47.6062],
        'dest_lon': [-73.9851, -118.2437, -122.3321],
        'volume': [1000, 500, 800]
    })
    fig = vz.plot(df_flow, kind='flow_map', origin_lat='origin_lat', origin_lon='origin_lon',
                  dest_lat='dest_lat', dest_lon='dest_lon', flow='volume',
                  title='Flow Map: Connections', color='#1976D2')
    vz.close(fig)
except ImportError as e:
    print(f" 15. Skipped (missing dependencies: {e})")

# 16. Tile Map
print("16. Tile Map...")
try:
    import contextily as ctx
    import geopandas as gpd
    from shapely.geometry import Polygon
    poly1 = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    poly2 = Polygon([(1, 0), (2, 0), (2, 1), (1, 1)])
    gdf = gpd.GeoDataFrame({
        'region': ['Region A', 'Region B'],
        'population': [1000, 2000]
    }, geometry=[poly1, poly2], crs='EPSG:4326')
    gdf_3857 = gdf.to_crs(epsg=3857)
    fig = vz.plot(gdf_3857, kind='tile_map', value='population',
                  title='Tile Map with Basemap', cmap='Reds')
    vz.close(fig)
except ImportError as e:
    print(f" 16. Skipped (missing dependencies: {e})")

# 17. Cartogram
print("17. Cartogram...")
try:
    from shapely.geometry import Polygon
    import geopandas as gpd
    poly1 = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    poly2 = Polygon([(1, 0), (2, 0), (2, 1), (1, 1)])
    gdf = gpd.GeoDataFrame({
        'region': ['Region A', 'Region B'],
        'population': [1000, 2000]
    }, geometry=[poly1, poly2])
    fig = vz.plot(gdf, kind='cartogram', geometry='geometry', value='population',
                  title='Cartogram: Distorted by Population', color='#4CAF50')
    vz.close(fig)
except ImportError as e:
    print(f" 17. Skipped (missing dependencies: {e})")

print("\nAll 17 new plot types demonstrated successfully!")
print("Check the examples/ directory to run these demos individually.")
