# """
# Simple test to verify bottleviz is working correctly.
# """

# import bottleviz as vz
# import pandas as pd
# import numpy as np

# print("Testing bottleviz...")

# # Create simple normal distribution data
# np.random.seed(42)
# data = pd.DataFrame({
#     'x': np.random.randn(100),
#     'y': np.random.randn(100)
# })

# print(f"Data shape: {data.shape}")
# print(f"Sample data:\n{data.head()}")

# # Create a simple scatter plot
# print("\nCreating scatter plot...")
# fig = vz.plot(data, x='x', y='y', kind='scatter', title='Test Scatter Plot')

# # Show the plot
# print("Displaying plot...")
# vz.show()

# print("\n✓ bottleviz is working!")
# vz.close()


import bottleviz as vz
import pandas as pd
import numpy as np

np.random.seed(42)
data = pd.DataFrame({
    'x': np.random.randn(100),
    'y': np.random.randn(100)
})


# fig = vz.suggest_plots(data, x='x', y='y', kind='scatter', title='Test Scatter Plot')
report = vz.report(data, show_plots=True)

vz.show()
vz.close()
