import pandas as pd
import bottleviz as vz

  # Create or load your DataFrame
df = pd.DataFrame({
      'sales': [100, 200, 150, 300, 250],
      'profit': [20, 35, 30, 50, 45]
  })
vz.plot(df, x='sales', y='profit')
vz.show()