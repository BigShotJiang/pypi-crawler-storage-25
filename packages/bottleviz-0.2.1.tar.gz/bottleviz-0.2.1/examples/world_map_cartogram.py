"""
World Population Cartogram using BottleViz

This script creates a cartogram using real world map data.
It loads Natural Earth shapefiles and merges with World Bank population data.

Requirements:
- bottleviz
- pandas
- numpy
- geopandas
- shapely
- matplotlib

Usage:
  python world_map_cartogram.py

The script will:
  1. Load Natural Earth world map
  2. Load and merge population data from CSV
  3. Create a continuous cartogram (area-scaled by population)
  4. Save visualizations to plots_output_world_cartogram/
"""

import os
import numpy as np
import pandas as pd

import bottleviz as vz

print("World Population Cartogram")
print("=" * 60)

try:
    # ========================
    # 1. LOAD WORLD MAP DATA
    # ========================
    print("\n[1/4] Loading Natural Earth world map...")

    import geopandas as gpd
    import requests

    # Try to load from cache first
    cache_file = 'examples/naturalearth_data/countries.geojson'

    if os.path.exists(cache_file):
        print("  Loading from cached GeoJSON...")
        world = gpd.read_file(cache_file)
    else:
        # Download from GitHub mirror (reliable, no auth required)
        url = "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson"
        print(f"  Downloading from Natural Earth GitHub mirror...")

        try:
            response = requests.get(url, timeout=30)
            response.raise_for_status()

            # Cache for future use
            os.makedirs('examples/naturalearth_data', exist_ok=True)
            with open(cache_file, 'wb') as f:
                f.write(response.content)

            print(f"  Downloaded and cached to {cache_file}")
            world = gpd.read_file(cache_file)
        except Exception as e:
            print(f"  ERROR: Failed to download world map data: {e}")
            print("  You can manually download and save to:")
            print("    examples/naturalearth_data/countries.geojson")
            exit(1)

    print(f"  Loaded {len(world)} geographic features")

    # Filter to sovereign countries with valid ISO codes
    # The dataset uses 'ISO_A3' for 3-letter ISO country codes
    before = len(world)
    if 'ISO_A3' in world.columns:
        world = world[world['ISO_A3'].str.match(r'^[A-Z]{3}$', na=False)]
    elif 'ADM0_A3' in world.columns:
        world = world[world['ADM0_A3'].str.match(r'^[A-Z]{3}$', na=False)]
    else:
        print("  Warning: No ISO code column found, using all features")

    # Exclude Antarctica (ISO code ATA)
    if 'ISO_A3' in world.columns:
        world = world[world['ISO_A3'] != 'ATA']
    elif 'ADM0_A3' in world.columns:
        world = world[world['ADM0_A3'] != 'ATA']

    print(f"  Using {len(world)} countries")

    # ========================
    # 2. LOAD POPULATION DATA
    # ========================
    print("\n[2/4] Loading population data from CSV...")

    csv_file = "examples/API_SP.POP.TOTL_DS2_en_csv_v2.csv"

    if not os.path.exists(csv_file):
        print(f"  ERROR: CSV file not found: {csv_file}")
        print("  Please download the World Bank population data:")
        print("  https://data.worldbank.org/indicator/SP.POP.TOTL")
        print("  Save it as 'API_SP.POP.TOTL_DS2_en_csv_v2.csv' in this directory.")
        exit(1)

    # Read the World Bank data
    pop_df = pd.read_csv(csv_file, skiprows=[1, 2, 3], encoding='utf-8-sig')
    print(f"  Loaded {len(pop_df)} entries from CSV")

    # Clean column names
    pop_df.columns = pop_df.columns.str.strip()

    # Extract needed columns
    pop_df = pop_df[['Country Name', 'Country Code', '2022']].rename(
        columns={'Country Name': 'name', 'Country Code': 'iso_a3', '2022': 'population'}
    )

    # Convert population to numeric
    pop_df['population'] = pd.to_numeric(pop_df['population'], errors='coerce').fillna(0)

    # ========================
    # 3. MERGE DATA
    # ========================
    print("\n[3/4] Merging population data with world map...")

    # The GeoJSON uses ISO_A3 for ISO codes
    # The population data uses 'iso_a3' (lowercase)
    merge_col = 'ISO_A3' if 'ISO_A3' in world.columns else 'ADM0_A3'

    if merge_col not in world.columns:
        print(f"  ERROR: Could not find ISO code column in Natural Earth data")
        print(f"  Available columns: {list(world.columns)}")
        exit(1)

    # Merge on ISO codes
    world_pop = world.merge(pop_df, left_on=merge_col, right_on='iso_a3', how='left')
    print(f"  Merged dataset: {len(world_pop)} countries")

    # Check which countries are missing population data
    missing = world_pop[world_pop['population'].isna()]
    if len(missing) > 0:
        print(f"  Warning: {len(missing)} countries missing population data:")
        for _, row in missing.head(10).iterrows():
            print(f"    - {row.get('NAME', row.get('name', 'Unknown'))}")
        if len(missing) > 10:
            print(f"    ... and {len(missing)-10} more")

    # Fill missing with median (or 0 if no median available)
    median_pop = world_pop['population'].median()
    if pd.isna(median_pop):
        median_pop = 0
    world_pop['population'] = world_pop['population'].fillna(median_pop)
    if len(missing) > 0:
        print(f"  Filled missing values with median: {median_pop:,.0f}")

    # Remove any invalid geometries (rare but can happen)
    before = len(world_pop)
    world_pop = world_pop[world_pop.is_valid]
    if len(world_pop) < before:
        print(f"  Removed {before - len(world_pop)} entries with invalid geometries")

    print(f"  Final dataset: {len(world_pop)} countries with population")

    pop_min = world_pop['population'].min()
    pop_max = world_pop['population'].max()
    print(f"  Population range: {pop_min:,.0f} to {pop_max:,.0f}")

    # ========================
    # 4. CREATE output directory
    # ========================
    output_dir = 'plots_output_world_cartogram'
    os.makedirs(output_dir, exist_ok=True)

    # ========================
    # 5. CREATE VISUALIZATIONS
    # ========================
    print("\n[4/4] Creating visualizations...")

    # PLOT 1: Standard choropleth
    print("  - Plot 1: Standard choropleth map")
    fig1 = vz.plot(world_pop, kind='choropleth',
                   geometry='geometry',
                   value='population',
                   title='World Population by Country',
                   cmap='YlOrRd',
                   legend=True,
                   figsize=(14, 10))
    fig1.savefig(f'{output_dir}/01_choropleth.png', dpi=150, bbox_inches='tight')
    vz.close(fig1)

    # PLOT 2: Cartogram - area-scaled by population
    print("  - Plot 2: Population cartogram")
    fig2 = vz.plot(world_pop, kind='cartogram',
                   geometry='geometry',
                   value='population',
                   title='World Population Cartogram',
                   cmap='viridis',
                   edgecolor='black',
                   linewidth=0.3,
                   figsize=(14, 10))
    fig2.savefig(f'{output_dir}/02_cartogram.png', dpi=150, bbox_inches='tight')
    vz.close(fig2)

    # PLOT 3: Cartogram with logarithmic scaling
    print("  - Plot 3: Cartogram with log-scaled population")
    world_pop['log_population'] = np.log1p(world_pop['population'])
    fig3 = vz.plot(world_pop, kind='cartogram',
                   geometry='geometry',
                   value='log_population',
                   title='World Population Cartogram (Log Scale)',
                   cmap='plasma',
                   edgecolor='black',
                   linewidth=0.3,
                   alpha=0.9,
                   figsize=(14, 10))
    fig3.savefig(f'{output_dir}/03_cartogram_log.png', dpi=150, bbox_inches='tight')
    vz.close(fig3)

    # ========================
    # DONE
    # ========================
    print("\n" + "=" * 60)
    print("SUCCESS! Cartogram visualizations created.")
    print(f"\nOutputs saved to: {output_dir}/")
    print("  - 01_choropleth.png")
    print("  - 02_cartogram.png")
    print("  - 03_cartogram_log.png")
    print("\nCartograms distort country areas proportional to population.")
    print("=" * 60)

except ImportError as e:
    print(f"\nERROR: Missing dependency: {e}")
    print("\nPlease install:")
    print("  pip install bottleviz pandas numpy geopandas shapely matplotlib")
except Exception as e:
    print(f"\nERROR: {e}")
    import traceback
    traceback.print_exc()

