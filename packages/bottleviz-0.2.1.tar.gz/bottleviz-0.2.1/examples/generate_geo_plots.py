"""
Generate and save all geographic plot types to output files.

Run: python generate_geo_plots.py
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')

import bottleviz as vz
import os
from shapely.geometry import Polygon

# Create output directory
output_dir = 'plots_output_geographic'
os.makedirs(output_dir, exist_ok=True)

print(f"Generating geographic plots in '{output_dir}/'...")

# 1. Choropleth Map
print(" 1. Choropleth Map...")
try:
    import geopandas as gpd
    poly1 = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    poly2 = Polygon([(1, 0), (2, 0), (2, 1), (1, 1)])
    poly3 = Polygon([(2, 0), (3, 0), (3, 1), (2, 1)])
    gdf = gpd.GeoDataFrame({
        'region': ['Region A', 'Region B', 'Region C'],
        'population': [1000, 2000, 1500],
        'density': [100, 200, 150]
    }, geometry=[poly1, poly2, poly3], crs='EPSG:4326')
    fig = vz.plot(gdf, kind='choropleth', geometry='geometry', value='population',
                  title='Choropleth: Population by Region', cmap='Oranges', figsize=(8, 6))
    fig.savefig(f'{output_dir}/01_choropleth.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("   ✓ Saved 01_choropleth.png")
except ImportError as e:
    print(f"   ✗ Skipped (missing dependencies: {e})")

# 2. Scatter Geo
print(" 2. Scatter Geo...")
try:
    import geopandas as gpd
    from shapely.geometry import Point
    np.random.seed(42)
    n_points = 100
    df_scatter_geo = pd.DataFrame({
        'latitude': np.random.uniform(-10, 10, n_points),
        'longitude': np.random.uniform(-10, 10, n_points),
        'temperature': np.random.uniform(-10, 35, n_points),
        'city': [f'City_{i}' for i in range(n_points)]
    })
    fig = vz.plot(df_scatter_geo, kind='scatter_geo', lat='latitude', lon='longitude',
                  value='temperature', title='Scatter Geo: Temperature by Location',
                  cmap='plasma', markersize=50, alpha=0.7, figsize=(8, 6))
    fig.savefig(f'{output_dir}/02_scatter_geo.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("   ✓ Saved 02_scatter_geo.png")
except ImportError as e:
    print(f"   ✗ Skipped (missing dependencies: {e})")

# 3. Flow Map
print(" 3. Flow Map...")
try:
    import geopandas as gpd
    from shapely.geometry import LineString
    df_flow = pd.DataFrame({
        'origin_lat': [40.7128, 34.0522, 41.8781, 51.5074],
        'origin_lon': [-74.0060, -118.2437, -87.6298, -0.1278],
        'dest_lat': [40.7589, 34.0522, 47.6062, 48.8566],
        'dest_lon': [-73.9851, -118.2437, -122.3321, 2.3522],
        'volume': [1000, 500, 800, 1200],
        'route': ['NYC->Central Park', 'LA->LA', 'Chicago->Seattle', 'London->Paris']
    })
    fig = vz.plot(df_flow, kind='flow_map', origin_lat='origin_lat', origin_lon='origin_lon',
                  dest_lat='dest_lat', dest_lon='dest_lon', flow='volume',
                  title='Flow Map: Migration/Travel Routes', color='#1976D2', figsize=(10, 8))
    fig.savefig(f'{output_dir}/03_flow_map.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("   ✓ Saved 03_flow_map.png")
except ImportError as e:
    print(f"   ✗ Skipped (missing dependencies: {e})")

# 4. Tile Map
print(" 4. Tile Map...")
try:
    import contextily as ctx
    import geopandas as gpd
    from shapely.geometry import Polygon
    # Create polygons for a city district
    poly1 = Polygon([(-0.01, 51.50), (-0.00, 51.50), (-0.00, 51.51), (-0.01, 51.51)])
    poly2 = Polygon([(-0.02, 51.49), (-0.01, 51.49), (-0.01, 51.50), (-0.02, 51.50)])
    poly3 = Polygon([(-0.03, 51.48), (-0.02, 51.48), (-0.02, 51.49), (-0.03, 51.49)])
    gdf = gpd.GeoDataFrame({
        'district': ['District 1', 'District 2', 'District 3'],
        'population': [5000, 8000, 3000]
    }, geometry=[poly1, poly2, poly3], crs='EPSG:4326')
    # Reproject to Web Mercator for contextily
    gdf_3857 = gdf.to_crs(epsg=3857)
    fig = vz.plot(gdf_3857, kind='tile_map', value='population',
                  title='Tile Map with OpenStreetMap Basemap', cmap='Reds', figsize=(10, 8))
    fig.savefig(f'{output_dir}/04_tile_map.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("   ✓ Saved 04_tile_map.png")
except ImportError as e:
    print(f"   ✗ Skipped (missing dependencies: {e})")

# 5. Cartogram
print(" 5. Cartogram...")
try:
    import geopandas as gpd
    from shapely.geometry import Polygon
    poly1 = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    poly2 = Polygon([(1, 0), (2, 0), (2, 1), (1, 1)])
    poly3 = Polygon([(2, 0), (3, 0), (3, 1), (2, 1)])
    gdf = gpd.GeoDataFrame({
        'region': ['Region A', 'Region B', 'Region C'],
        'population': [1000, 4000, 2000]  # B has 4x population, will be scaled larger
    }, geometry=[poly1, poly2, poly3])
    fig = vz.plot(gdf, kind='cartogram', geometry='geometry', value='population',
                  title='Cartogram: Areas Distorted by Population', color='#4CAF50', figsize=(8, 6))
    fig.savefig(f'{output_dir}/05_cartogram.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("   ✓ Saved 05_cartogram.png")
except ImportError as e:
    print(f"   ✗ Skipped (missing dependencies: {e})")

print(f"\n✅ All geographic plots saved to '{output_dir}/' directory!")
print(f"   - 01_choropleth.png")
print(f"   - 02_scatter_geo.png")
print(f"   - 03_flow_map.png")
print(f"   - 04_tile_map.png")
print(f"   - 05_cartogram.png")
