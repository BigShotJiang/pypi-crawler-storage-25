"""
Dashboard Showcase Example for BottleViz

This script demonstrates the power of the automated visualization dashboard
with different datasets and configuration options.
"""

import numpy as np
import pandas as pd
import bottleviz as vz

print("=" * 70)
print("BOTTLEVIZ DASHBOARD SHOWCASE")
print("=" * 70)

# Set a nice style
vz.set_style('default')

# ============================================
# DATASET 1: Customer Analytics
# ============================================
print("\n" + "=" * 70)
print("Dataset 1: Customer Analytics (E-commerce)")
print("=" * 70)

np.random.seed(42)
n_customers = 200

customer_df = pd.DataFrame({
    'customer_id': range(1, n_customers + 1),
    'age': np.random.randint(18, 70, n_customers),
    'income': np.random.lognormal(10, 0.5, n_customers).round(0),
    'spent': np.random.exponential(500, n_customers).round(2),
    'visits': np.random.poisson(15, n_customers),
    'satisfaction': np.random.normal(4.2, 0.8, n_customers).clip(1, 5).round(1)
})

print(f"\nDataset shape: {customer_df.shape}")
print(f"Columns: {customer_df.columns.tolist()}")
print(f"\nFirst few rows:")
print(customer_df.head())

# Dashboard 1: Auto-detected distribution plots for all numeric columns
print("\n" + "-" * 70)
print("Dashboard 1: Automatic Distribution Analysis (All Numeric Columns)")
print("-" * 70)
fig1 = vz.visualize(customer_df, max_plots=6)
print("[OK] Created: 6-panel dashboard showing distributions of all numeric features")
vz.show()
vz.close(fig1)

# Dashboard 2: Focus on specific columns
print("\n" + "-" * 70)
print("Dashboard 2: Specific Columns (Age, Income, Spent)")
print("-" * 70)
fig2 = vz.visualize(customer_df, columns=['age', 'income', 'spent'], max_plots=3)
print("[OK] Created: 3-panel dashboard with selected metrics")
vz.show()
vz.close(fig2)

# ============================================
# DATASET 2: Time Series Data
# ============================================
print("\n" + "=" * 70)
print("Dataset 2: Sales Time Series")
print("=" * 70)

dates = pd.date_range('2024-01-01', periods=180, freq='D')
sales_df = pd.DataFrame({
    'date': dates,
    'revenue': np.random.normal(50000, 15000, 180).cumsum() + 100000,
    'transactions': np.random.poisson(200, 180),
    'avg_order_value': np.random.normal(250, 50, 180),
    'customers': np.random.poisson(150, 180),
    'returns': np.random.poisson(5, 180),
    'discounts': np.random.binomial(1, 0.3, 180) * np.random.uniform(0.1, 0.5, 180)
})

print(f"\nDataset shape: {sales_df.shape}")
print(f"Date range: {sales_df['date'].min().date()} to {sales_df['date'].max().date()}")

# Dashboard 3: Correlation analysis for time series metrics
print("\n" + "-" * 70)
print("Dashboard 3: Distribution Analysis (Sales Metrics)")
print("-" * 70)
# Select only numeric columns (excluding date)
numeric_cols = sales_df.select_dtypes(include=[np.number]).columns.tolist()
fig3 = vz.visualize(sales_df, columns=numeric_cols[:4], max_plots=4)
print("[OK] Created: 4-panel dashboard showing distributions")
vz.show()
vz.close(fig3)

# ============================================
# DATASET 3: Product Categories
# ============================================
print("\n" + "=" * 70)
print("Dataset 3: Product Categories")
print("=" * 70)

product_df = pd.DataFrame({
    'product_id': range(100, 150),
    'category': np.random.choice(['Electronics', 'Clothing', 'Home', 'Books', 'Sports', 'Toys'], 50),
    'price': np.random.exponential(100, 50).round(2),
    'cost': np.random.exponential(60, 50).round(2),
    'inventory': np.random.randint(0, 200, 50),
    'sales_qty': np.random.poisson(25, 50),
    'rating': np.random.normal(4.0, 0.8, 50).clip(1, 5).round(1)
})

print(f"\nDataset shape: {product_df.shape}")
print(f"Categories: {product_df['category'].unique().tolist()}")

# Dashboard 4: Correlation plot type
print("\n" + "-" * 70)
print("Dashboard 4: Correlation Analysis (Numeric Product Features)")
print("-" * 70)
numeric_product_cols = product_df.select_dtypes(include=[np.number]).columns.tolist()
fig4 = vz.visualize(product_df, columns=numeric_product_cols, plot_type='correlation', max_plots=6)
print("[OK] Created: Scatter plots showing correlations between numeric features")
vz.show()
vz.close(fig4)

# ============================================
# DATASET 4: Wide Dataset (Many Numeric Columns)
# ============================================
print("\n" + "=" * 70)
print("Dataset 4: Financial Metrics (Wide Dataset)")
print("=" * 70)

financial_df = pd.DataFrame({
    'quarter': [f'Q{i//3+1}-{2024+(i//12)}' for i in range(24)],
    'revenue': np.random.uniform(1000000, 5000000, 24),
    'gross_profit': np.random.uniform(400000, 2500000, 24),
    'operating_expenses': np.random.uniform(200000, 1500000, 24),
    'net_income': np.random.uniform(50000, 1000000, 24),
    'cash_flow': np.random.uniform(100000, 2000000, 24),
    'debt': np.random.uniform(500000, 3000000, 24),
    'assets': np.random.uniform(2000000, 10000000, 24),
    'equity': np.random.uniform(1000000, 5000000, 24),
    'roi': np.random.uniform(0.05, 0.25, 24),
    'eps': np.random.uniform(1.5, 8.5, 24),
    'pe_ratio': np.random.uniform(10, 35, 24),
    'dividend': np.random.uniform(0.5, 3.0, 24)
})

print(f"\nDataset shape: {financial_df.shape}")
print(f"Number of numeric columns: {len(financial_df.select_dtypes(include=[np.number]).columns)}")

# Dashboard 5: Large dashboard with many plots
print("\n" + "-" * 70)
print("Dashboard 5: Comprehensive Financial Analysis (Max Plots)")
print("-" * 70)
fig5 = vz.visualize(financial_df, max_plots=6)
print("[OK] Created: 6-panel dashboard (auto-layout: 2 rows x 3 cols)")
vz.show()
vz.close(fig5)

# ============================================
# BONUS: Compare plot types
# ============================================
print("\n" + "=" * 70)
print("BONUS: Different Plot Types")
print("=" * 70)

# Using plot_type='distribution' explicitly
print("\n" + "-" * 70)
print("Explicit Distribution Plots: vz.visualize(..., plot_type='distribution')")
print("-" * 70)
fig6 = vz.visualize(customer_df, columns=['age', 'income', 'spent'], plot_type='distribution')
print("[OK] Created: Histograms with KDE overlays")
vz.show()
vz.close(fig6)

print("\n" + "=" * 70)
print("DASHBOARD SHOWCASE COMPLETE!")
print("=" * 70)

print("\nKey Features Demonstrated:")
print("  • Automatic plot type detection (distribution, correlation)")
print("  • Smart subplot layout (auto-calculates rows/cols)")
print("  • Selective column inclusion")
print("  • max_plots parameter to control output size")
print("  • Works with datasets of various sizes and types")
print("  • Beautiful default styling")

print("\nQuick Usage Guide:")
print("  vz.visualize(df)                              # Auto-analyze all numeric columns")
print("  vz.visualize(df, max_plots=4)                # Limit to 4 plots")
print("  vz.visualize(df, columns=['x','y','z'])      # Select specific columns")
print("  vz.visualize(df, plot_type='distribution')   # Force distribution plots")
print("  vz.visualize(df, plot_type='correlation')    # Force correlation/scatter plots")

print("\nBest Practices:")
print("  • Use smaller max_plots (3-6) for clarity")
print("  • Select specific columns for focused analysis")
print("  • Use plot_type parameter to control visualization style")
print("  • Combine with vz.set_style() for custom themes")

print("\n" + "=" * 70)
