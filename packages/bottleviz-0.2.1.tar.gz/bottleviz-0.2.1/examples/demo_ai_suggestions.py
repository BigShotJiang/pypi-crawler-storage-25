"""
Demo: AI-Powered Plot Suggestions with BottleViz

This script demonstrates how to use AI to get intelligent plot
recommendations for your data.

Requirements:
- bottleviz[ai]  OR  pip install openai  (or anthropic, ollama)

Usage:
    python examples/demo_ai_suggestions.py
"""

import os
import numpy as np
import pandas as pd
import bottleviz as vz
from bottleviz.processors._ai_integration import get_ai_suggestion

print("=" * 70)
print("BottleViz AI-Powered Suggestions Demo")
print("=" * 70)

# Create sample data
np.random.seed(42)
df = pd.DataFrame({
    'height': np.random.normal(170, 10, 200),
    'weight': np.random.normal(70, 15, 200),
    'age': np.random.randint(18, 65, 200),
    'gender': np.random.choice(['M', 'F'], 200),
    'score': np.random.exponential(1, 200)
})

print(f"\nDataset: {len(df)} rows, columns: {list(df.columns)}")
print("\nData preview:")
print(df.head(3))

# ============================================================================
# 1. Rule-based suggestions (no AI)
# ============================================================================
print("\n" + "=" * 70)
print("1. RULE-BASED SUGGESTIONS (no AI)")
print("=" * 70)

recs = vz.suggest_plots(df)
print("\nTop recommendations (rule-based):")
print(recs[['type', 'x', 'y', 'source']].head(5).to_string())

# ============================================================================
# 2. Check AI provider availability
# ============================================================================
print("\n" + "=" * 70)
print("2. AI PROVIDER AVAILABILITY CHECK")
print("=" * 70)

def check_ollama_available(host="http://localhost:11434"):
    """Check if Ollama server is running."""
    try:
        import requests
        response = requests.get(host, timeout=2)
        if response.status_code == 200:
            # Also check if any models are available
            models_resp = requests.get(f"{host}/api/tags", timeout=2)
            if models_resp.status_code == 200:
                models = models_resp.json().get("models", [])
                model_names = [m["name"] for m in models]
                return True, model_names
        return False, []
    except Exception:
        return False, []

def check_openai_available():
    """Check if OpenAI API key is set."""
    api_key = os.getenv("OPENAI_API_KEY")
    return bool(api_key), api_key

def check_anthropic_available():
    """Check if Anthropic API key is set."""
    api_key = os.getenv("ANTHROPIC_API_KEY")
    return bool(api_key), api_key

# Check each provider
ollama_ok, ollama_models = check_ollama_available()
openai_ok, openai_key = check_openai_available()
anthropic_ok, anthropic_key = check_anthropic_available()

print("\nProvider status:")
print(f"  Ollama:       {'[OK] Available' if ollama_ok else '[FAIL] Not running'}")
if ollama_ok:
    print(f"    Models: {', '.join(ollama_models[:3])}")
    if len(ollama_models) > 3:
        print(f"    ... and {len(ollama_models)-3} more")

print(f"  OpenAI:       {'[OK] API key set' if openai_ok else '[FAIL] No API key (set OPENAI_API_KEY)'}")
print(f"  Anthropic:    {'[OK] API key set' if anthropic_ok else '[FAIL] No API key (set ANTHROPIC_API_KEY)'}")

# ============================================================================
# 3. AI-powered suggestions (only if provider available)
# ============================================================================
print("\n" + "=" * 70)
print("3. AI-POWERED SUGGESTIONS")
print("=" * 70)

# Try with available providers
ai_providers_to_try = []

if ollama_ok:
    ai_providers_to_try.append(('ollama', ollama_models[0] if ollama_models else 'llama3.2:1b', None))
elif openai_ok:
    ai_providers_to_try.append(('openai', 'gpt-4o-mini', openai_key))
elif anthropic_ok:
    ai_providers_to_try.append(('anthropic', 'claude-3-haiku-20240307', anthropic_key))

if ai_providers_to_try:
    provider, model, key = ai_providers_to_try[0]
    print(f"\nAttempting AI suggestion using {provider.upper()} (model: {model})...")

    try:
        ai_recs = vz.suggest_plots(
            df,
            ai=True,
            ai_provider=provider,
            api_key=key,
            model=model
        )

        if 'ai' in ai_recs['source'].values:
            print("SUCCESS! AI added a suggestion:")
            ai_row = ai_recs[ai_recs['source'] == 'ai'].iloc[0]
            print(f"    Plot type: {ai_row['type']}")
            print(f"    x: {ai_row['x']}")
            print(f"    y: {ai_row['y']}")
            print(f"    Reason: {ai_row['rationale'][:150]}...")
            print(f"\n    Full example code:")
            print(f"    {ai_row['example_code']}")
        else:
            print("No AI suggestion was added.")
    except Exception as e:
        print(f"ERROR: {e}")
else:
    print("\nNo AI providers are available.")
    print("  To enable AI suggestions:")
    print("    - Start Ollama: ollama serve && ollama pull llama3.2:1b")
    print("    - Or set OPENAI_API_KEY / ANTHROPIC_API_KEY environment variable")

# ============================================================================
# 4. Examples for different setups
# ============================================================================
print("\n" + "=" * 70)
print("4. USAGE EXAMPLES FOR DIFFERENT SETUPS")
print("=" * 70)

print("""
# Ollama (local, free, no API key)
# 1. Install: https://ollama.com/download
# 2. Start server: ollama serve
# 3. Pull model: ollama pull llama3.2:1b
vz.suggest_plots(df, ai=True, ai_provider='ollama', model='llama3.2:1b')

# OpenAI (requires API key)
vz.suggest_plots(df, ai=True, api_key="sk-...")  # Or set OPENAI_API_KEY
vz.suggest_plots(df, ai=True, api_key="sk-...", model='gpt-4o')

# Anthropic (requires API key)
vz.suggest_plots(df, ai=True, ai_provider='anthropic', api_key="sk-ant-...")
vz.suggest_plots(df, ai=True, ai_provider='anthropic', model='claude-3-opus-20240229')

# Use environment variable (recommended for security)
export OPENAI_API_KEY="sk-..."
vz.suggest_plots(df, ai=True)  # Auto-detects OpenAI
""")

print("\n" + "=" * 70)
print("Demo complete!")
print("=" * 70)
