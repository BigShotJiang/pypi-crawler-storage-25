"""
Comprehensive demonstration of ALL plot types added in BottleViz v0.2.0

This script creates sample data and generates visualizations for:
- Geographic plots (5 types)
- Advanced statistical/temporal plots (15+ types)
- Developer tools

Requirements:
- bottleviz[all] or individual dependencies
- For geographic plots: geopandas, shapely, contextily
"""

import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('Agg')
import warnings

import bottleviz as vz
import os

# Create output directory
output_dir = 'plots_output_v0.2.0_all'
os.makedirs(output_dir, exist_ok=True)

print("=" * 70)
print("BottleViz v0.2.0 - Complete Plot Type Demonstration")
print("=" * 70)

# ============================================================================
# 1. GEOGRAPHIC VISUALIZATIONS (5 types)
# ============================================================================
print("\n" + "=" * 70)
print("PART 1: GEOGRAPHIC VISUALIZATIONS")
print("=" * 70)

try:
    import geopandas as gpd
    from shapely.geometry import Polygon, Point, LineString

    # Create synthetic country shapes
    countries = [
        ('Northland', 'NOR', Polygon([(-130, 30), (-60, 30), (-60, 50), (-130, 50)]), 250000000),
        ('Southland', 'SOU', Polygon([(-90, -60), (-30, -60), (-30, 0), (-90, 0)]), 180000000),
        ('Europia', 'EUR', Polygon([(-10, 35), (40, 35), (40, 60), (-10, 60)]), 380000000),
        ('Afriqua', 'AFR', Polygon([(-20, -35), (50, -35), (50, 35), (-20, 35)]), 950000000),
        ('Asiana', 'ASI', Polygon([(60, 10), (140, 10), (140, 60), (60, 60)]), 3800000000),
        ('Oceania', 'OCE', Polygon([(110, -45), (155, -45), (155, 0), (110, 0)]), 32000000),
    ]

    gdf = gpd.GeoDataFrame(
        [{'name': n, 'code': c, 'geometry': g, 'population': p, 'gdp': p/100, 'area': np.random.randint(100, 500)}
         for n, c, g, p in countries],
        crs='EPSG:4326'
    )

    # 1.1 Choropleth
    print("\n1. Choropleth Map")
    fig = vz.plot(gdf, kind='choropleth', geometry='geometry', value='population',
                  title='Population by Country', cmap='YlOrRd')
    fig.savefig(f'{output_dir}/01_choropleth.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("   [OK] Saved: 01_choropleth.png")

    # 1.2 Scatter Geo
    print("2. Scatter Geo")
    cities = pd.DataFrame({
        'city': ['Metro A', 'Metro B', 'Metro C', 'Metro D', 'Metro E'],
        'lat': [40.7, 34.0, 41.8, 35.6, 51.5],
        'lon': [-74.0, -118.2, -87.6, 139.6, -0.1],
        'population': [8.4, 4.0, 2.7, 13.9, 9.0],
        'temperature': [22, 18, 10, 16, 12]
    })
    fig = vz.plot(cities, kind='scatter_geo', lat='lat', lon='lon', value='temperature',
                  title='City Temperatures', cmap='coolwarm', markersize=100)
    fig.savefig(f'{output_dir}/02_scatter_geo.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("   [OK] Saved: 02_scatter_geo.png")

    # 1.3 Flow Map
    print("3. Flow Map")
    flows = pd.DataFrame({
        'origin_lat': [40.7, 34.0, 51.5, 35.6],
        'origin_lon': [-74.0, -118.2, -0.1, 139.6],
        'dest_lat': [34.0, 51.5, 35.6, 40.7],
        'dest_lon': [-118.2, -0.1, 139.6, -74.0],
        'volume': [5000, 3000, 4000, 2000]
    })
    fig = vz.plot(flows, kind='flow_map', origin_lat='origin_lat', origin_lon='origin_lon',
                  dest_lat='dest_lat', dest_lon='dest_lon', flow='volume',
                  title='Migration Flows', color='#2196F3')
    fig.savefig(f'{output_dir}/03_flow_map.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("   [OK] Saved: 03_flow_map.png")

    # 1.4 Tile Map
    print("4. Tile Map")
    gdf_3857 = gdf.to_crs(epsg=3857)
    try:
        import contextily as ctx
        fig = vz.plot(gdf_3857, kind='tile_map', value='population',
                      title='Tile Map with Basemap', cmap='Reds')
        fig.savefig(f'{output_dir}/04_tile_map.png', dpi=150, bbox_inches='tight')
        vz.close(fig)
        print("   [OK] Saved: 04_tile_map.png")
    except ImportError:
        print("   [SKIP] Tile map (contextily not installed)")

    # 1.5 Cartogram
    print("5. Cartogram")
    fig = vz.plot(gdf, kind='cartogram', geometry='geometry', value='population',
                  title='Population Cartogram (Areas Scaled)', color='#4CAF50')
    fig.savefig(f'{output_dir}/05_cartogram.png', dpi=150, bbox_inches='tight')
    vz.close(fig)
    print("   [OK] Saved: 05_cartogram.png")

except ImportError as e:
    print(f"\n[WARN] Geographic plots skipped: {e}")
    print("Install with: pip install geopandas shapely contextily")

# ============================================================================
# 2. ADVANCED PLOTS (15+ types)
# ============================================================================
print("\n" + "=" * 70)
print("PART 2: ADVANCED VISUALIZATIONS")
print("=" * 70)

np.random.seed(42)

# 2.1 Stacked Bar
print("\n6. Stacked Bar Chart")
df = pd.DataFrame({
    'quarter': ['Q1', 'Q2', 'Q3', 'Q4'],
    'Product A': [120, 150, 180, 200],
    'Product B': [80, 90, 100, 110],
    'Product C': [60, 75, 90, 105]
})
fig = vz.plot(df, x='quarter', y=['Product A', 'Product B', 'Product C'],
              kind='stacked_bar', title='Quarterly Sales by Product')
fig.savefig(f'{output_dir}/06_stacked_bar.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 06_stacked_bar.png")

# 2.2 Grouped Bar
print("7. Grouped Bar Chart")
df = pd.DataFrame({
    'category': ['A', 'B', 'C', 'D'],
    '2022': [100, 120, 90, 80],
    '2023': [110, 130, 100, 90],
    '2024': [125, 140, 110, 95]
})
fig = vz.plot(df, x='category', y=['2022', '2023', '2024'],
              kind='grouped_bar', title='Year-over-Year Comparison')
fig.savefig(f'{output_dir}/07_grouped_bar.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 07_grouped_bar.png")

# 2.3 Hexbin
print("8. Hexbin Plot")
n = 5000
df = pd.DataFrame({
    'x': np.random.randn(n),
    'y': np.random.randn(n)
})
fig = vz.plot(df, x='x', y='y', kind='hexbin', gridsize=30, cmap='viridis',
              title='Density Distribution (Hexbin)')
fig.savefig(f'{output_dir}/08_hexbin.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 08_hexbin.png")

# 2.4 Step Plot
print("9. Step Plot")
df = pd.DataFrame({
    'time': np.arange(0, 10, 0.5),
    'signal': np.random.randint(0, 2, 20)
})
fig = vz.plot(df, x='time', y='signal', kind='step', title='Digital Signal', where='mid')
fig.savefig(f'{output_dir}/09_step.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 09_step.png")

# 2.5 Fill Between
print("10. Fill Between (Confidence Interval)")
days = 30
df = pd.DataFrame({
    'day': range(days),
    'temperature': 20 + 5 * np.sin(np.linspace(0, 3*np.pi, days)) + np.random.randn(days)*0.5,
})
df['upper'] = df['temperature'] + 2
df['lower'] = df['temperature'] - 2
fig = vz.plot(df, x='day', y='temperature', y_lower='lower', y_upper='upper',
              kind='fill_between', title='Temperature with Confidence Interval',
              ylabel='Temperature (C)')
fig.savefig(f'{output_dir}/10_fill_between.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 10_fill_between.png")

# 2.6 Contour (2D)
print("11. Contour Plot")
x = np.linspace(-3, 3, 50)
y = np.linspace(-3, 3, 50)
X, Y = np.meshgrid(x, y)
Z = np.sin(X) * np.cos(Y) + 0.3 * np.sin(2*X)
df_contour = pd.DataFrame({'x': X.flatten(), 'y': Y.flatten(), 'z': Z.flatten()})
fig = vz.plot(df_contour, x='x', y='y', z='z', kind='contour',
              title='2D Contour Lines', levels=15)
fig.savefig(f'{output_dir}/11_contour.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 11_contour.png")

# 2.7 Pcolormesh
print("12. Pcolormesh")
fig = vz.plot(df_contour, x='x', y='y', value='z', kind='pcolormesh',
              title='Pcolormesh', cmap='plasma')
fig.savefig(f'{output_dir}/12_pcolormesh.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 12_pcolormesh.png")

# 2.8 Quiver
print("13. Quiver (Vector Field)")
x = np.linspace(0, 2*np.pi, 12)
y = np.linspace(0, 2*np.pi, 12)
X, Y = np.meshgrid(x, y)
U = np.cos(X)
V = -np.sin(Y)
df_quiver = pd.DataFrame({'x': X.flatten(), 'y': Y.flatten(), 'u': U.flatten(), 'v': V.flatten()})
fig = vz.plot(df_quiver, x='x', y='y', u='u', v='v', kind='quiver',
              title='2D Vector Field')
fig.savefig(f'{output_dir}/13_quiver.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 13_quiver.png")

# 2.9 Spy
print("14. Spy Plot (Sparse Matrix)")
sparse = np.block([[np.eye(15), np.zeros((15, 15))], [np.zeros((15, 15)), np.eye(15)]])
df_sparse = pd.DataFrame(sparse > 0)
fig = vz.plot(df_sparse, kind='spy', markersize=3, title='Sparse Matrix Structure')
fig.savefig(f'{output_dir}/14_spy.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 14_spy.png")

# 2.10 Polar
print("15. Polar Plot")
theta = np.linspace(0, 2*np.pi, 200)
r = 1 + 0.8 * np.cos(4*theta) + 0.3 * np.sin(6*theta)
df_polar = pd.DataFrame({'theta': theta, 'r': r})
fig = vz.plot(df_polar, theta='theta', r='r', kind='polar', fill=True, alpha=0.6,
              title='Rose Curve (Polar)')
fig.savefig(f'{output_dir}/15_polar.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 15_polar.png")

# 2.11 Table
print("16. Table Plot")
data = pd.DataFrame({
    'Model': ['ResNet-50', 'BERT', 'GPT-3', 'XLNet', 'T5'],
    'Accuracy': [92.1, 93.2, 95.0, 94.5, 93.8],
    'Speed (t/s)': [1250, 890, 45, 320, 280],
    'Params (B)': [0.25, 0.11, 175, 0.34, 11]
})
fig = vz.plot(data, kind='table', max_rows=5, fontsize=9, title='Model Comparison')
fig.savefig(f'{output_dir}/16_table.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 16_table.png")

# 2.12 Eventplot
print("17. Eventplot (Timelines)")
events = pd.DataFrame({
    'Patient A': [0, 1, 0, 1, 0, 0, 1],
    'Patient B': [1, 0, 0, 1, 0, 0, 0],
    'Patient C': [0, 0, 1, 1, 0, 1, 1]
})
fig = vz.plot(events, kind='eventplot', title='Treatment Timeline', ylabel='Patient')
fig.savefig(f'{output_dir}/17_eventplot.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 17_eventplot.png")

# 2.13 Waterfall
print("18. Waterfall Chart")
waterfall = pd.DataFrame({
    'category': ['Starting', 'Revenue', 'Cost', 'Investment', 'Return', 'Tax', 'Ending'],
    'value': [100, 50, -30, -20, 40, -15, 0]  # Ending will be calculated
})
fig = vz.plot(waterfall, x='category', y='value', kind='waterfall',
              title='Profit Waterfall', threshold=0)
fig.savefig(f'{output_dir}/18_waterfall.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 18_waterfall.png")

# 2.14 Gantt
print("19. Gantt Chart")
gantt = pd.DataFrame({
    'task': ['Planning', 'Design', 'Development', 'Testing', 'Deployment'],
    'start': ['2024-01-01', '2024-02-01', '2024-03-01', '2024-04-01', '2024-05-01'],
    'end': ['2024-01-31', '2024-02-28', '2024-04-15', '2024-04-30', '2024-05-15']
})
fig = vz.plot(gantt, task='task', start='start', end='end', kind='gantt',
              title='Project Timeline')
fig.savefig(f'{output_dir}/19_gantt.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 19_gantt.png")

# 2.15 OHLC with Volume
print("20. OHLC with Volume")
dates = pd.date_range('2024-01-01', periods=30, freq='D')
np.random.seed(42)
base = 100 + np.random.randn(30).cumsum()
ohlc = pd.DataFrame({
    'date': dates,
    'open': base + np.random.randn(30) * 2,
    'high': base + np.random.rand(30) * 3,
    'low': base - np.random.rand(30) * 3,
    'close': base + np.random.randn(30) * 2,
    'volume': np.random.randint(100000, 500000, 30)
})
ohlc['high'] = ohlc[['open', 'close', 'high']].max(axis=1)
ohlc['low'] = ohlc[['open', 'close', 'low']].min(axis=1)
fig = vz.plot(ohlc, x='date', open='open', high='high', low='low', close='close',
              volume='volume', kind='ohlc_volume', title='Stock Price with Volume')
fig.savefig(f'{output_dir}/20_ohlc_volume.png', dpi=150, bbox_inches='tight')
vz.close(fig)
print("   [OK] Saved: 20_ohlc_volume.png")

# ============================================================================
# 3. DEVELOPER TOOLS DEMONSTRATION
# ============================================================================
print("\n" + "=" * 70)
print("PART 3: DEVELOPER TOOLS (Not Plots)")
print("=" * 70)

# Create sample dataset
sample_df = pd.DataFrame({
    'age': np.random.randint(18, 70, 100),
    'salary': np.random.randint(30000, 120000, 100),
    'experience': np.random.randint(0, 40, 100),
    'department': np.random.choice(['IT', 'HR', 'Sales', 'Marketing', 'Finance'], 100),
    'city': np.random.choice(['NYC', 'LA', 'Chicago', 'Houston', 'Phoenix'], 100)
})

# 3.1 suggest_plots
print("\n21. suggest_plots() - Auto-recommendations")
recs = vz.suggest_plots(sample_df)
print("    Recommendations generated:")
print(f"    {len(recs)} plot types suggested")
recs.to_csv(f'{output_dir}/21_suggestions.csv', index=False)
print(f"    Saved: 21_suggestions.csv")

# 3.2 report
print("22. report() - Data Profile")
report = vz.report(sample_df, show_plots=False)
with open(f'{output_dir}/22_report.txt', 'w', encoding='utf-8') as f:
    f.write(report)
print(f"    Saved: 22_report.txt")

# 3.3 explore
print("23. explore() - Smart EDA")
explore_results = vz.explore(sample_df, mode='auto')
print(f"    Saved: explore results (text output)")

# 3.4 optimize_for_large_data
print("24. optimize_for_large_data() - Downsampling")
large_df = pd.DataFrame({
    'x': np.random.randn(50000),
    'y': np.random.randn(50000)
})
optimized = vz.optimize_for_large_data(large_df, max_points=10000)
print(f"    Original: {len(large_df)} rows -> Optimized: {len(optimized)} rows")
with open(f'{output_dir}/24_optimization_info.txt', 'w', encoding='utf-8') as f:
    f.write(f"Original size: {len(large_df)}\nOptimized size: {len(optimized)}\n")
print(f"    Saved: 24_optimization_info.txt")

# ============================================================================
# DONE
# ============================================================================
print("\n" + "=" * 70)
print("✅ COMPLETE! All v0.2.0 visualizations generated.")
print("=" * 70)
print(f"\nOutput directory: {output_dir}/")
print("\nFiles created:")
files = sorted([f for f in os.listdir(output_dir) if f.endswith(('.png', '.csv', '.txt'))])
for i, f in enumerate(files, 1):
    print(f"  {i:2d}. {f}")
print(f"\nTotal: {len(files)} files")
print("\nNote: Some geographic plots may be skipped if dependencies are missing.")
print("=" * 70)

# Print summary of what was created
print("\nSUMMARY OF V0.2.0 FEATURES DEMONSTRATED:")
print("-" * 70)
print("Geographic (5):")
print("  1. Choropleth Map")
print("  2. Scatter Geo")
print("  3. Flow Map")
print("  4. Tile Map")
print("  5. Cartogram")
print("\nAdvanced Plots (15+):")
print("  6. Stacked Bar")
print("  7. Grouped Bar")
print("  8. Hexbin")
print("  9. Step Plot")
print(" 10. Fill Between")
print(" 11. Contour Plot")
print(" 12. Pcolormesh")
print(" 13. Quiver")
print(" 14. Spy Plot")
print(" 15. Polar Plot")
print(" 16. Table Plot")
print(" 17. Eventplot")
print(" 18. Waterfall Chart")
print(" 19. Gantt Chart")
print(" 20. OHLC with Volume")
print("\nDeveloper Tools (4):")
print(" 21. suggest_plots()")
print(" 22. report()")
print(" 23. explore()")
print(" 24. optimize_for_large_data()")
print("-" * 70)
