"""
Custom 3D Plotting with figure3d()

Demonstrates how to create custom 3D visualizations using figure3d(),
which returns (fig, ax) for full manual control over the plotting.
"""

import bottleviz as vz
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ============================================================================
# Example 1: Basic Custom 3D Surface with Multiple Plot Types
# ============================================================================
print("Example 1: Custom 3D visualization with multiple elements")

# Generate data for a complex surface
x = np.linspace(-5, 5, 50)
y = np.linspace(-5, 5, 50)
X, Y = np.meshgrid(x, y)
Z = np.sin(np.sqrt(X**2 + Y**2))

# Create empty 3D figure
fig, ax = vz.figure3d(
    title='Custom 3D Visualization',
    xlabel='X Axis',
    ylabel='Y Axis',
    zlabel='Z Axis',
    figsize=(10, 8)
)

# Add multiple plot types to the same axes
# Surface plot
ax.plot_surface(X, Y, Z, cmap='viridis', alpha=0.8, edgecolor='none')

# Wireframe overlay
ax.plot_wireframe(X, Y, Z, color='black', alpha=0.3, linewidth=0.5)

# Contour lines projected onto the surface
ax.contour(X, Y, Z, levels=15, cmap='autumn', offset=Z.min())

# Add a point annotation
ax.scatter([0], [0], [Z[25, 25]], color='red', s=100, label='Center')

# Customize view angle
ax.view_init(elev=25, azim=45)

vz.show()
vz.close(fig)


# ============================================================================
# Example 2: Multiple Surfaces in One Figure
# ============================================================================
print("\nExample 2: Multiple surfaces in custom layout")

# Create the figure
fig, ax = vz.figure3d(title='Multiple 3D Surfaces')

# First surface - Saddle shape
Z1 = X**2 - Y**2
ax.plot_surface(X, Y, Z1, cmap='coolwarm', alpha=0.7, label='Saddle')

# Second surface - Exponential decay (shifted)
Z2 = np.exp(-(X**2 + Y**2)/10) - 1.5
ax.plot_surface(X, Y, Z2, cmap='plasma', alpha=0.7, label='Gaussian')

# Add contours at different levels
ax.contourf(X, Y, Z1, levels=20, cmap='coolwarm', alpha=0.5, offset=Z2.min()-0.5)

vz.show()
vz.close(fig)


# ============================================================================
# Example 3: 3D Scatter and Vector Field
# ============================================================================
print("\nExample 3: 3D scatter plot with vector field")

fig, ax = vz.figure3d(title='3D Points and Flow Field')

# Generate random points
np.random.seed(42)
n_points = 100
x_scatter = np.random.uniform(-3, 3, n_points)
y_scatter = np.random.uniform(-3, 3, n_points)
z_scatter = np.random.uniform(-3, 3, n_points)

# Color by distance from origin
colors = np.sqrt(x_scatter**2 + y_scatter**2 + z_scatter**2)

# Scatter plot
scatter = ax.scatter(x_scatter, y_scatter, z_scatter,
                     c=colors, cmap='rainbow', s=50, alpha=0.8)

# Add colorbar
fig.colorbar(scatter, ax=ax, label='Distance from Origin')

# Add a simple vector field (quiver) - sparse 2D grid for clarity
x_q = np.linspace(-3, 3, 8)
y_q = np.linspace(-3, 3, 8)
Xq, Yq = np.meshgrid(x_q, y_q)
Zq = np.zeros_like(Xq)  # Flat plane at z=0

# Vector field: points toward center in XY, slight Z variation
U = -Xq * 0.5
V = -Yq * 0.5
W = 0.1 * np.sin(Xq) * np.cos(Yq)  # Gentle wave pattern

# Plot vectors
ax.quiver(Xq, Yq, Zq, U, V, W, length=0.3, color='gray', alpha=0.6, pivot='tail')

vz.show()
vz.close(fig)


# ============================================================================
# Example 4: 3D Line Plot and Marker Points
# ============================================================================
print("\nExample 4: 3D line with sampled points")

fig, ax = vz.figure3d(title='3D Parametric Curve')

# Parametric helix
t = np.linspace(0, 6*np.pi, 100)
x_helix = np.cos(t)
y_helix = np.sin(t)
z_helix = t / (6*np.pi) * 3

# Plot the continuous line
ax.plot(x_helix, y_helix, z_helix,
        color='blue', linewidth=2, label='Helix')

# Add markers at intervals
marker_indices = range(0, len(t), 10)
ax.scatter(x_helix[marker_indices], y_helix[marker_indices], z_helix[marker_indices],
           color='red', s=50, depthshade=False, label='Samples')

ax.legend()

vz.show()
vz.close(fig)


# ============================================================================
# Example 5: Interactive-style Visualization with vz.show() workflow
# ============================================================================
print("\nExample 5: Complete workflow with show/close")

# Generate data
theta = np.linspace(0, 2*np.pi, 30)
z_vals = np.linspace(-2, 2, 30)
Theta, Z = np.meshgrid(theta, z_vals)
R = 2 + np.cos(2*Theta)  # Ripple torus
X = R * np.cos(Theta)
Y = R * np.sin(Theta)

# Step 1: Create figure
fig, ax = vz.figure3d(
    title='Torus Surface',
    xlabel='X',
    ylabel='Y',
    zlabel='Z',
    figsize=(12, 8)
)

# Step 2: Add surface
surf = ax.plot_surface(X, Y, Z, cmap='twilight_shifted',
                       linewidth=0.5, edgecolor='white', alpha=0.9)

# Step 3: Add colorbar
fig.colorbar(surf, ax=ax, shrink=0.5, aspect=20, label='Height')

# Step 4: Customize
ax.set_box_aspect([1, 1, 0.5])  # Aspect ratio
ax.view_init(elev=30, azim=-60)

# Step 5: Display
vz.show()

# Step 6: Clean up (important to free memory in long scripts)
vz.close(fig)


# ============================================================================
# Example 6: Using Different Backend Styles
# ============================================================================
print("\nExample 6: Styling with Bottleviz themes")

# Try with dark style
vz.set_style('dark')

fig, ax = vz.figure3d(title='Dark Theme 3D Plot')

# Simple surface
Z_dark = np.cos(np.sqrt(X**2 + Y**2))
ax.plot_surface(X, Y, Z_dark, cmap='inferno', alpha=0.9)

vz.show()
vz.close(fig)

# Reset to default
vz.set_style('default')


# ============================================================================
# Example 7: Using DataFrame + plot_3d functions directly
# ============================================================================
print("\nExample 7: DataFrame approach with custom enhancements")

# Create a DataFrame from the grid data
df_3d = pd.DataFrame({
    'x': X.flatten(),
    'y': Y.flatten(),
    'z': Z.flatten()
})

# Option A: Use vz.plot() to generate the surface, then enhance it
fig = vz.plot(df_3d, x='x', y='y', z='z', kind='3d',
              surface=True, title='Auto-generated Surface', cmap='Blues')

# Get the axes from the figure
ax = fig.axes[0]

# Manually add contours
ax.contour(X, Y, Z, levels=10, colors='black', alpha=0.5, offset=Z.min())
ax.set_title('Enhanced with Manual Contours')

vz.show()
vz.close(fig)


# Option B: Full manual control with figure3d() and DataFrame data
print("\nExample 7b: Full manual customization with DataFrame")

fig, ax = vz.figure3d(title='Manual Surface from DataFrame')

# Extract columns and reshape
n = int(np.sqrt(len(df_3d)))
X_grid = df_3d['x'].values.reshape(n, n)
Y_grid = df_3d['y'].values.reshape(n, n)
Z_grid = df_3d['z'].values.reshape(n, n)

# Plot manually
surf = ax.plot_surface(X_grid, Y_grid, Z_grid, cmap='plasma', alpha=0.9)
ax.contour(X_grid, Y_grid, Z_grid, levels=15, cmap='Greys', alpha=0.5, offset=Z_grid.min())
fig.colorbar(surf, ax=ax, shrink=0.5)

vz.show()
vz.close(fig)
vz.close()


print("\n" + "="*60)
print("KEY TAKEAWAYS:")
print("="*60)
print("1. vz.figure3d() returns (fig, ax) - full manual control")
print("2. vz.plot(..., kind='3d') returns only fig - auto surface/scatter")
print("3. ax has methods: plot_surface, plot_wireframe, contour, contourf,")
print("   scatter, plot, quiver, bar3d, voxels, etc.")
print("4. vz.show() displays all figures - no need to import matplotlib")
print("5. vz.close(fig) or vz.close() cleans up")
print("6. Works with vz.set_style() for theming")
print("7. Both approaches can be customized after creation")
