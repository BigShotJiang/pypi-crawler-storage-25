"""
Comprehensive demonstration of all 3D plotting functions in BottleViz.

This example showcases all matplotlib 3D plot types available through
BottleViz's simple API.
"""

import bottleviz as vz
import numpy as np

print("=" * 60)
print("BottleViz - All 3D Plot Types")
print("=" * 60)

# Generate sample data
x = np.linspace(-5, 5, 50)
y = np.linspace(-5, 5, 50)
X, Y = np.meshgrid(x, y)
Z = np.sin(np.sqrt(X**2 + Y**2))

# 1. Surface Plot
print("\n1. Creating 3D Surface Plot...")
fig, ax = vz.plot_3d_surface(X, Y, Z, title='3D Surface Plot', cmap='viridis')
vz.show()
vz.close(fig)

# 2. Wireframe Plot
print("2. Creating 3D Wireframe Plot...")
fig, ax = vz.plot_3d_wireframe(X, Y, Z, title='3D Wireframe Plot', color='blue', linewidth=0.5)
vz.show()
vz.close(fig)

# 3. Triangular Surface Plot (with scattered data)
print("3. Creating 3D Triangular Surface Plot...")
n_points = 500
x_rand = np.random.uniform(-5, 5, n_points)
y_rand = np.random.uniform(-5, 5, n_points)
z_rand = np.sin(np.sqrt(x_rand**2 + y_rand**2))
fig, ax = vz.plot_3d_trisurf(x_rand, y_rand, z_rand, title='3D Triangular Surface', cmap='plasma')
vz.show()
vz.close(fig)

# 4. 3D Contour Lines
print("4. Creating 3D Contour Plot...")
fig, ax = vz.plot_3d_contour(X, Y, Z, title='3D Contour Lines', levels=15, cmap='coolwarm')
vz.show()
vz.close(fig)

# 5. Filled 3D Contour Plot
print("5. Creating Filled 3D Contour Plot...")
fig, ax = vz.plot_3d_contourf(X, Y, Z, title='Filled 3D Contour', levels=20, cmap='RdYlBu')
vz.show()
vz.close(fig)

# 6. 3D Quiver Plot (vector field)
print("6. Creating 3D Quiver Plot...")
x_q = np.linspace(-2, 2, 10)
y_q = np.linspace(-2, 2, 10)
z_q = np.linspace(-2, 2, 10)
X_q, Y_q, Z_q = np.meshgrid(x_q, y_q, z_q)
U = -Y_q
V = X_q
W = np.zeros_like(Z_q)
fig, ax = vz.plot_3d_quiver(X_q, Y_q, Z_q, U, V, W, title='3D Quiver Plot (Rotational Field)', length=0.3, normalize=True)
vz.show()
vz.close(fig)

# 7. 3D Stem Plot
print("7. Creating 3D Stem Plot...")
x_s = np.linspace(0, 10, 20)
y_s = np.sin(x_s)
z_s = np.cos(x_s)
fig, ax = vz.plot_3d_stem(x_s, y_s, z_s, title='3D Stem Plot', linefmt='b-', markerfmt='bo')
vz.show()
vz.close(fig)

# 8. 3D Bar Plot
print("8. Creating 3D Bar Plot...")
x_b = np.arange(0, 5, 1)
y_b = np.arange(0, 5, 1)
X_b, Y_b = np.meshgrid(x_b, y_b)
Z_b = np.random.rand(5, 5).flatten()
dx = dy = 0.8
dz = Z_b
fig, ax = vz.plot_3d_bar(X_b.flatten(), Y_b.flatten(), np.zeros_like(Z_b), dx, dy, dz,
                         title='3D Bar Plot', shade=True)
vz.show()
vz.close(fig)

# 9. 3D Voxel Plot
print("9. Creating 3D Voxel Plot...")
# Create a simple 3D shape (sphere)
voxels = np.zeros((20, 20, 20), dtype=bool)
x_v = np.linspace(-10, 10, 20)
y_v = np.linspace(-10, 10, 20)
z_v = np.linspace(-10, 10, 20)
X_v, Y_v, Z_v = np.meshgrid(x_v, y_v, z_v)
sphere = X_v**2 + Y_v**2 + Z_v**2 <= 100
voxels[sphere] = True
fig, ax = vz.plot_3d_voxels(voxels, title='3D Voxel Plot (Sphere)', edgecolor='k', facecolors='cyan')
vz.show()
vz.close(fig)

# 10. Cone Surface (from earlier demo)
print("10. Creating Cone Surface Plot...")
n_theta = 50
n_z = 50
theta = np.linspace(0, 2*np.pi, n_theta)
z_cone = np.linspace(1, 10, n_z)
Theta, Z_cone = np.meshgrid(theta, z_cone)
slope = 0.5
R = slope * Z_cone
X_cone = R * np.cos(Theta)
Y_cone = R * np.sin(Theta)
fig, ax = vz.plot_3d_surface(X_cone, Y_cone, Z_cone, title='Cone Surface', cmap='hot')
vz.show()
vz.close(fig)

print("\n" + "=" * 60)
print("All 3D plot types demonstrated successfully!")
print("=" * 60)
