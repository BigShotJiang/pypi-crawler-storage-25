"""
BottleViz Library - Comprehensive Examples

This script demonstrates the full capabilities of the BottleViz library
with realistic, complex datasets and various plot types.
"""

import bottleviz as vz
import pandas as pd
import numpy as np

def show_plot():
    """Display current figure and wait for user to close window."""
    vz.show()
    vz.close()

# ------------------------------------------------------------
# COMPLEX DATASET 1: Sales & Customer Analytics
# ------------------------------------------------------------
np.random.seed(42)

# Create a realistic e-commerce dataset
dates = pd.date_range('2024-01-01', periods=200, freq='D')
n_customers = 50

customer_data = pd.DataFrame({
    'customer_id': range(1, n_customers + 1),
    'age': np.random.randint(18, 70, n_customers),
    'city': np.random.choice(['NYC', 'LA', 'Chicago', 'Houston', 'Phoenix'], n_customers),
    'segment': np.random.choice(['Bronze', 'Silver', 'Gold', 'Platinum'], n_customers, p=[0.4, 0.3, 0.2, 0.1]),
    'join_date': pd.date_range('2023-01-01', periods=n_customers, freq='7D')
})

# Generate transactions with realistic patterns
n_transactions = 1000
transaction_data = pd.DataFrame({
    'transaction_id': range(1000, 1000 + n_transactions),
    'date': np.random.choice(dates, n_transactions),
    'customer_id': np.random.randint(1, n_customers + 1, n_transactions),
    'product_category': np.random.choice(['Electronics', 'Clothing', 'Home', 'Books', 'Sports'], n_transactions,
                                          p=[0.3, 0.25, 0.2, 0.15, 0.1]),
    'amount': np.random.exponential(100, n_transactions).round(2),
    'quantity': np.random.randint(1, 5, n_transactions),
    'rating': np.random.choice([1, 2, 3, 4, 5, np.nan], n_transactions, p=[0.05, 0.1, 0.15, 0.3, 0.35, 0.05])
})

# Enrich with customer info
transaction_data = transaction_data.merge(
    customer_data[['customer_id', 'segment', 'age', 'city']],
    on='customer_id'
)

# Calculate additional metrics
transaction_data['revenue'] = transaction_data['amount'] * transaction_data['quantity']
transaction_data['day_of_week'] = transaction_data['date'].dt.day_name()
transaction_data['month'] = transaction_data['date'].dt.month_name()

print("=== DATASET 1: E-Commerce Sales ===\n")
print(f"Shape: {transaction_data.shape}")
print(f"Columns: {transaction_data.columns.tolist()}")
print(f"Missing values:\n{transaction_data.isnull().sum()}\n")


# ------------------------------------------------------------
# DEMONSTRATIONS WITH COMPLEX DATA
# ------------------------------------------------------------

print("\n=== VISUALIZATION EXAMPLES ===\n")

# 1. SCATTER PLOT: Revenue vs Amount by Customer Segment
print("1. Revenue vs Amount by Segment (Scatter with multiple groups)")
gold_data = transaction_data[transaction_data['segment'] == 'Gold']
fig = vz.plot(gold_data, x='amount', y='revenue', kind='scatter', title='Gold Segment: Amount vs Revenue')
show_plot()

# 2. LINE PLOT: Daily Revenue Trend
print("2. Daily Revenue Trend (Time Series)")
daily_revenue = transaction_data.groupby('date')['revenue'].sum().reset_index()
fig = vz.plot(daily_revenue, x='date', y='revenue', kind='line', title='Daily Revenue Over Time')
show_plot()

# 3. BAR CHART: Revenue by Product Category
print("3. Revenue by Product Category (Bar Chart)")
category_revenue = transaction_data.groupby('product_category')['revenue'].sum().sort_values().reset_index()
fig = vz.plot(category_revenue, x='product_category', y='revenue', kind='bar',
               title='Total Revenue by Category', xlabel='Category', ylabel='Revenue ($)')
show_plot()

# 4. GROUPED BAR CHART: Average Rating by Segment and City
print("4. Average Rating by Segment and City (Grouped Bar)")
pivot_rating = transaction_data.pivot_table(
    values='rating',
    index='segment',
    columns='city',
    aggfunc='mean'
).reset_index()
# Melt for grouped bar format
melted = pd.melt(pivot_rating, id_vars='segment', var_name='city', value_name='avg_rating')
fig = vz.plot(melted, x='segment', y='avg_rating', hue='city', kind='bar',
               title='Average Rating by Segment and City')
show_plot()

# 5. HISTOGRAM: Distribution of Customer Age
print("5. Customer Age Distribution (Histogram)")
fig = vz.plot(customer_data, x='age', kind='hist', bins=15, title='Customer Age Distribution')
show_plot()

# 6. BOX PLOT: Amount by Product Category
print("6. Transaction Amount by Category (Box Plot)")
fig = vz.plot(transaction_data, x='product_category', y='amount', kind='box',
               title='Amount Distribution by Category')
show_plot()

# 7. VIOLIN PLOT: Revenue by Customer Segment
print("7. Revenue by Customer Segment (Violin Plot)")
fig = vz.plot(transaction_data, x='segment', y='revenue', kind='violin',
               title='Revenue Distribution by Customer Segment')
show_plot()

# 8. KDE PLOT: Smooth distribution of transaction amounts
print("8. Transaction Amount Distribution (KDE)")
fig = vz.plot(transaction_data, x='amount', kind='kde', title='Density of Transaction Amounts')
show_plot()

# 9. HEATMAP: Correlation Matrix of Numeric Features
print("9. Feature Correlation Heatmap")
numeric_features = ['age', 'amount', 'quantity', 'revenue', 'rating']
correlation_matrix = transaction_data[numeric_features].corr()
fig = vz.plot(correlation_matrix, kind='heatmap', title='Feature Correlations', cmap='coolwarm')
show_plot()

# 10. AREA PLOT: Cumulative Revenue Over Time
print("10. Cumulative Revenue Trend (Area Chart)")
daily_cumulative = daily_revenue.copy()
daily_cumulative['cumulative_revenue'] = daily_cumulative['revenue'].cumsum()
fig = vz.plot(daily_cumulative, x='date', y='cumulative_revenue', kind='area',
                title='Cumulative Revenue Over Time')
show_plot()

# 11. DASHBOARD: Multi-panel visualization
print("11. Automated EDA Dashboard")
fig = vz.visualize(transaction_data[numeric_features], max_plots=4)
show_plot()

# 12. STYLE CHANGES: Different visual styles
print("12. Testing Different Styles")
available = vz.available_styles()
print(f"   Available styles: {available}")

vz.set_style('default')
fig = vz.plot(transaction_data, x='amount', y='revenue', kind='scatter', title='Default Style')
show_plot()

vz.set_style('dark')
fig = vz.plot(transaction_data, x='amount', y='revenue', kind='scatter', title='Dark Style')
show_plot()

vz.set_style('minimal')
fig = vz.plot(transaction_data, x='amount', y='revenue', kind='scatter', title='Minimal Style')
show_plot()

vz.set_style('default')  # Reset to default

# 13. AUTO-SUGGESTIONS: Get plot recommendations
print("13. Automated Plot Suggestions")
suggestions = vz.suggest_plots(transaction_data[numeric_features])
print(suggestions[['type', 'x', 'y', 'rationale']].to_string(index=False))

# 14. COMPLEX MULTI-Y: Multiple metrics over time
print("14. Multiple Metrics Over Time")
multi_ts = daily_revenue.copy()
multi_ts['transaction_count'] = transaction_data.groupby('date').size().values
fig = vz.plot(multi_ts, x='date', y=['revenue', 'transaction_count'], kind='line',
                title='Revenue and Transaction Count Over Time', ylabel='Value')
show_plot()

# 15. PIE CHART: Customer Segment Distribution
print("15. Customer Segment Distribution (Pie Chart)")
segment_dist = customer_data['segment'].value_counts()
# Pie chart uses categorical x and numeric y
fig = vz.plot(pd.DataFrame({'segment': segment_dist.index, 'count': segment_dist.values}),
                x='segment', y='count', kind='pie', title='Customer Segments')
show_plot()

# 16. STEM PLOT: Daily transaction counts (lollipop chart)
print("16. Daily Transaction Count (Stem Plot)")
daily_counts = transaction_data.groupby('date').size().reset_index(name='count')
# Sample every 10 days for clarity
sampled_daily = daily_counts.iloc[::10]
fig = vz.plot(sampled_daily, x='date', y='count', kind='stem',
                title='Daily Transaction Count (Sampled)', ylabel='Number of Transactions')
show_plot()

# 17. ERROR BAR PLOT: Average amount by product category with confidence intervals
print("17. Average Transaction Amount by Category (Error Bars)")
category_stats = transaction_data.groupby('product_category')['amount'].agg(['mean', 'std', 'count']).reset_index()
category_stats['ci'] = 1.96 * category_stats['std'] / np.sqrt(category_stats['count'])  # 95% CI
fig = vz.plot(category_stats, x='product_category', y='mean', yerr='ci', kind='errorbar',
                title='Average Transaction Amount by Category (95% CI)',
                xlabel='Product Category', ylabel='Average Amount ($)',
                capsize=5, capthick=2, fmt='o')
show_plot()


# ------------------------------------------------------------
# SECOND COMPLEX DATASET: Geographic & Temporal Data
# ------------------------------------------------------------
print("\n\n=== DATASET 2: Geographic & Weather Data ===\n")

# Create weather data for multiple cities
cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix']
dates_wide = pd.date_range('2024-01-01', periods=90, freq='D')

weather_data = []
for city in cities:
    base_temp = {'New York': 15, 'Los Angeles': 22, 'Chicago': 12, 'Houston': 24, 'Phoenix': 28}[city]
    for date in dates_wide:
        # Seasonal variation + random noise
        day_of_year = date.dayofyear
        seasonal = 15 * np.sin(2 * np.pi * (day_of_year - 80) / 365)
        temp = base_temp + seasonal + np.random.normal(0, 3)
        weather_data.append({
            'city': city,
            'date': date,
            'temperature': round(temp, 1),
            'humidity': np.random.randint(30, 90),
            'precipitation': max(0, np.random.exponential(2)),
            'wind_speed': np.random.randint(5, 25),
            'region': {'New York': 'Northeast', 'Los Angeles': 'West', 'Chicago': 'Midwest',
                       'Houston': 'South', 'Phoenix': 'Southwest'}[city]
        })

weather_df = pd.DataFrame(weather_data)

print(f"Weather dataset shape: {weather_df.shape}")
print(f"Temperature ranges: {weather_df.groupby('city')['temperature'].agg(['min', 'max', 'mean']).round(1)}")


# 18. MULTI-LINE PLOT: Temperature trends by city
print("\n18. Temperature Trends by City (Multi-Line)")
# Pivot for easier plotting
temp_pivot = weather_df.pivot(index='date', columns='city', values='temperature').reset_index()
fig = vz.plot(temp_pivot, x='date', y=cities, kind='line', title='Temperature Trends Across Cities',
                ylabel='Temperature (°C)', figsize=(14, 6))
show_plot()

# 19. FACETED/BATCH PLOTS: Separate plots by region
print("19. Temperature Distribution by Region (Histograms)")
for region in weather_df['region'].unique():
    region_data = weather_df[weather_df['region'] == region]
    fig = vz.plot(region_data, x='temperature', kind='hist', bins=20,
                  title=f'{region} - Temperature Distribution', alpha=0.7)
    show_plot()

# 20. SCATTER WITH CONTEXT: Humidity vs Temperature colored by city
print("20. Humidity vs Temperature (Scatter Matrix)")
sample = weather_df.sample(200, random_state=42)  # Sample for clarity
ny_data = sample[sample['city'] == 'New York']
la_data = sample[sample['city'] == 'Los Angeles']
# Plot separately since no hue support
fig = vz.plot(ny_data, x='temperature', y='humidity', kind='scatter', title='NYC: Temp vs Humidity')
show_plot()
fig = vz.plot(la_data, x='temperature', y='humidity', kind='scatter', title='LA: Temp vs Humidity')
show_plot()

# 21. CORRELATION HEATMAP: Weather features
print("21. Weather Feature Correlations")
weather_numeric = weather_df[['temperature', 'humidity', 'precipitation', 'wind_speed']]
weather_corr = weather_numeric.corr()
fig = vz.plot(weather_corr, kind='heatmap', title='Weather Feature Correlations',
                cmap='RdYlBu', center=0)
show_plot()

# ============================================
# ADVANCED VISUALIZATIONS
# ============================================

# 22. SANKEY DIAGRAM: Flow of revenue from Product Category to Customer Segment
print("\n22. Sankey Diagram: Revenue Flow")
sankey_data = transaction_data.groupby(['product_category', 'segment'])['revenue'].sum().reset_index()
sankey_data = sankey_data.rename(columns={
    'product_category': 'source',
    'segment': 'target',
    'revenue': 'value'
})
try:
    fig = vz.plot(sankey_data, kind='sankey', source='source', target='target', value='value',
                  title='Revenue Flow: Product Category -> Customer Segment')
    show_plot()
except vz.exceptions.VisualizerError as e:
    print(f"   Skipped: {e}")

# 23. SUNBURST CHART: Hierarchical view of customers by Region -> City -> Segment
print("\n23. Sunburst Chart: Customer Distribution")
city_region = {
    'NYC': 'Northeast',
    'LA': 'West',
    'Chicago': 'Midwest',
    'Houston': 'South',
    'Phoenix': 'Southwest'
}
customer_data['region'] = customer_data['city'].map(city_region)
sunburst_data = customer_data.groupby(['region', 'city', 'segment']).size().reset_index(name='count')
try:
    fig = vz.plot(sunburst_data, kind='sunburst', path=['region', 'city', 'segment'],
                  value='count', title='Customer Distribution by Region/City/Segment')
    show_plot()
except vz.exceptions.VisualizerError as e:
    print(f"   Skipped: {e}")

# 24. TREEMAP: Same hierarchical data as rectangular layout
print("\n24. Treemap: Customer Distribution")
try:
    fig = vz.plot(sunburst_data, kind='treemap', path=['region', 'city', 'segment'],
                  value='count', title='Customer Distribution (Treemap)')
    show_plot()
except vz.exceptions.VisualizerError as e:
    print(f"   Skipped: {e}")

# 25. NETWORK GRAPH: Bipartite network of Product Categories and Customer Segments
print("\n25. Network Graph: Category-Segment Relationships")
try:
    fig = vz.plot(sankey_data, kind='network', source='source', target='target',
                  title='Category-Segment Network', layout='spring', node_size=500)
    show_plot()
except vz.exceptions.VisualizerError as e:
    print(f"   Skipped: {e}")

# 26. CANDLESTICK CHART: Financial OHLC data
print("\n26. Candlestick Chart: Stock Price Movement")
np.random.seed(42)
n_days = 30
dates = pd.date_range('2024-01-01', periods=n_days, freq='D')
start_price = 100
returns = np.random.normal(0.001, 0.02, n_days)
prices = [start_price]
for r in returns:
    prices.append(prices[-1] * (1 + r))
prices = prices[1:]
prices = np.array(prices)

stock_data = pd.DataFrame({
    'date': dates,
    'open': prices * (1 + np.random.uniform(-0.01, 0.01, n_days)),
    'high': prices * (1 + np.random.uniform(0.01, 0.03, n_days)),
    'low': prices * (1 + np.random.uniform(-0.03, -0.01, n_days)),
    'close': prices,
    'volume': np.random.randint(1000, 10000, n_days)
})
stock_data['high'] = stock_data[['open', 'close', 'high']].max(axis=1)
stock_data['low'] = stock_data[['open', 'close', 'low']].min(axis=1)

try:
    fig = vz.plot(stock_data, x='date', kind='candlestick',
                  open='open', high='high', low='low', close='close',
                  title='Stock Price Candlestick Chart', figsize=(12, 6))
    show_plot()
except vz.exceptions.VisualizerError as e:
    print(f"   Skipped: {e}")

print("\n" + "="*60)
print("All plots completed successfully!")
print("="*60)
