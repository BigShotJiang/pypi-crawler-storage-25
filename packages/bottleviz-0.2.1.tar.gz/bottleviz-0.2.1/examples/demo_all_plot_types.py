"""
Comprehensive BottleViz Demo - All Plot Types (Matplotlib + Plotly)

This script demonstrates EVERY plot type available in BottleViz,
generating both PNG (matplotlib) and HTML (plotly) outputs where supported.

Output structure:
  plots_all/
    matplotlib/   - All plot types as PNG
    plotly/       - Only plotly-supported types as HTML
    report.txt    - Summary with success/failure counts
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import bottleviz as vz
from bottleviz.publishers.backends import set_backend
from pathlib import Path
import traceback

# Create output directories
output_root = Path('plots_all')
mpl_dir = output_root / 'matplotlib'
plotly_dir = output_root / 'plotly'
mpl_dir.mkdir(parents=True, exist_ok=True)
plotly_dir.mkdir(parents=True, exist_ok=True)

print("=" * 80)
print("BOTTEVIZ COMPREHENSIVE DEMO - ALL PLOT TYPES")
print("=" * 80)

# Set matplotlib as default for PNG generation
set_backend('matplotlib')

# Check if plotly backend is available
plotly_available = False
try:
    import plotly
    from bottleviz.publishers.plotly_backend import PlotlyBackend
    from bottleviz.publishers.backends import register_backend
    register_backend('plotly', PlotlyBackend())
    plotly_available = True
    set_backend('plotly')
    # Switch back to matplotlib for default
    set_backend('matplotlib')
except ImportError:
    print("\n[INFO] Plotly backend not available - skipping HTML outputs")

# ============================================================================
# TEST REGISTRY: Each entry defines a test case
# ============================================================================
# Labels: y-axis, description, generate_data_fn, plot_kwargs

tests = []

# --- 1. LINE PLOT ---
def gen_line():
    x = np.linspace(0, 10, 100)
    y = np.sin(x) + 0.1*np.random.randn(100)
    return pd.DataFrame({'x': x, 'y': y})
tests.append(('line', 'Line Plot', gen_line, dict(x='x', y='y', kind='line', title='Line Plot')))

# --- 2. SCATTER PLOT ---
def gen_scatter():
    np.random.seed(42)
    x = np.random.randn(200)
    y = 2*x + np.random.randn(200)
    size = np.random.uniform(10, 100, 200)
    return pd.DataFrame({'x': x, 'y': y, 'size': size})
tests.append(('scatter', 'Scatter Plot', gen_scatter, dict(x='x', y='y', kind='scatter', title='Scatter Plot')))

# --- 3. BAR PLOT ---
def gen_bar():
    categories = ['A', 'B', 'C', 'D', 'E']
    values = [23, 45, 56, 12, 78]
    return pd.DataFrame({'cat': categories, 'val': values})
tests.append(('bar', 'Bar Plot', gen_bar, dict(x='cat', y='val', kind='bar', title='Bar Plot')))

# --- 4. STACKED BAR PLOT ---
def gen_stacked_bar():
    data = {
        'category': ['Q1', 'Q2', 'Q3', 'Q4'],
        'Product A': [100, 120, 130, 140],
        'Product B': [80, 90, 100, 110],
        'Product C': [60, 70, 80, 90]
    }
    return pd.DataFrame(data)
tests.append(('stacked_bar', 'Stacked Bar Plot', gen_stacked_bar,
              dict(x='category', y=['Product A', 'Product B', 'Product C'], kind='stacked_bar', title='Stacked Bar')))

# --- 5. GROUPED BAR PLOT ---
def gen_grouped_bar():
    data = {
        'category': ['Q1', 'Q2', 'Q3', 'Q4'],
        'Product A': [100, 120, 130, 140],
        'Product B': [80, 90, 100, 110],
        'Product C': [60, 70, 80, 90]
    }
    return pd.DataFrame(data)
tests.append(('grouped_bar', 'Grouped Bar Plot', gen_grouped_bar,
              dict(x='category', y=['Product A', 'Product B', 'Product C'], kind='grouped_bar', title='Grouped Bar')))

# --- 6. HISTOGRAM ---
def gen_hist():
    np.random.seed(42)
    data = np.random.normal(0, 1, 1000)
    return pd.DataFrame({'val': data})
tests.append(('hist', 'Histogram', gen_hist, dict(x='val', kind='hist', title='Histogram', bins=30)))

# --- 7. BOX PLOT ---
def gen_box():
    np.random.seed(42)
    groups = ['A']*50 + ['B']*50 + ['C']*50
    values = np.concatenate([np.random.normal(0, 1, 50),
                             np.random.normal(2, 1.2, 50),
                             np.random.normal(-1, 0.8, 50)])
    return pd.DataFrame({'group': groups, 'value': values})
tests.append(('box', 'Box Plot', gen_box, dict(x='group', y='value', kind='box', title='Box Plot')))

# --- 8. VIOLIN PLOT ---
def gen_violin():
    np.random.seed(42)
    groups = ['A']*50 + ['B']*50 + ['C']*50
    values = np.concatenate([np.random.normal(0, 1, 50),
                             np.random.normal(2, 1.2, 50),
                             np.random.normal(-1, 0.8, 50)])
    return pd.DataFrame({'group': groups, 'value': values})
tests.append(('violin', 'Violin Plot', gen_violin, dict(x='group', y='value', kind='violin', title='Violin Plot')))

# --- 9. HEATMAP ---
def gen_heatmap():
    np.random.seed(42)
    corr = np.random.randn(5, 5)
    corr = np.corrcoef(np.random.randn(100, 5).T)
    var_names = [f'Var{i+1}' for i in range(5)]
    return pd.DataFrame(corr, index=var_names, columns=var_names)
tests.append(('heatmap', 'Heatmap', gen_heatmap, dict(kind='heatmap', title='Correlation Heatmap', cmap='RdYlBu', center=0, annot=True)))

# --- 10. PCOLORMESH ---
def gen_pcolormesh():
    x = np.linspace(0, 10, 20)
    y = np.linspace(0, 5, 10)
    X, Y = np.meshgrid(x, y)
    Z = np.sin(X) * np.cos(Y)
    # Return as long-format DataFrame with x, y, z columns
    df = pd.DataFrame({
        'x': X.flatten(),
        'y': Y.flatten(),
        'z': Z.flatten()
    })
    return df
tests.append(('pcolormesh', 'Pcolormesh', gen_pcolormesh, dict(x='x', y='y', z='z', kind='pcolormesh', title='Pcolormesh')))

# --- 11. PIE PLOT ---
def gen_pie():
    labels = ['Apple', 'Banana', 'Cherry', 'Date', 'Elderberry']
    sizes = [30, 25, 20, 15, 10]
    return pd.DataFrame({'label': labels, 'size': sizes})
tests.append(('pie', 'Pie Chart', gen_pie, dict(x='label', y='size', kind='pie', title='Pie Chart')))

# --- 12. AREA PLOT ---
def gen_area():
    x = np.linspace(0, 10, 100)
    y1 = np.sin(x) + 1
    y2 = np.cos(x) + 1
    return pd.DataFrame({'x': x, 'y1': y1, 'y2': y2})
tests.append(('area', 'Area Plot', gen_area, dict(x='x', y=['y1', 'y2'], kind='area', title='Area Plot')))

# --- 13. KDE PLOT ---
def gen_kde():
    np.random.seed(42)
    data = np.random.normal(0, 1, 500)
    return pd.DataFrame({'val': data})
tests.append(('kde', 'KDE Plot', gen_kde, dict(x='val', kind='kde', title='KDE Plot')))

# --- 14. 3D PLOT (scatter) ---
def gen_3d():
    np.random.seed(42)
    n = 100
    x = np.random.randn(n)
    y = np.random.randn(n)
    z = x**2 + y**2 + np.random.randn(n)*0.5
    return pd.DataFrame({'x': x, 'y': y, 'z': z})
tests.append(('3d', '3D Scatter', gen_3d, dict(x='x', y='y', z='z', kind='3d', title='3D Scatter')))

# --- 15. 3D SURFACE PLOT ---
def gen_surface():
    x = np.linspace(-5, 5, 50)
    y = np.linspace(-5, 5, 50)
    X, Y = np.meshgrid(x, y)
    Z = np.sin(np.sqrt(X**2 + Y**2))
    return X, Y, Z
tests.append(('plot_3d_surface', '3D Surface Plot', gen_surface, dict(title='3D Surface', cmap='viridis')))

# --- 16. 3D WIREFRAME PLOT ---
def gen_wireframe():
    x = np.linspace(-5, 5, 30)
    y = np.linspace(-5, 5, 30)
    X, Y = np.meshgrid(x, y)
    Z = np.cos(X) * np.sin(Y)
    return X, Y, Z
tests.append(('plot_3d_wireframe', '3D Wireframe', gen_wireframe, dict(title='3D Wireframe', rstride=2, cstride=2)))

# --- 17. 3D TRIANGULAR SURFACE ---
def gen_trisurf():
    np.random.seed(42)
    n = 500
    x = np.random.uniform(-5, 5, n)
    y = np.random.uniform(-5, 5, n)
    z = np.sin(np.sqrt(x**2 + y**2)) + np.random.randn(n)*0.1
    return x, y, z
tests.append(('plot_3d_trisurf', '3D Triangular Surface', gen_trisurf, dict(title='3D Trisurf', cmap='plasma')))

# --- 18. 3D CONTOUR LINES ---
def gen_contour3d():
    x = np.linspace(-3, 3, 40)
    y = np.linspace(-3, 3, 40)
    X, Y = np.meshgrid(x, y)
    Z = X**2 + Y**2
    return X, Y, Z
tests.append(('plot_3d_contour', '3D Contour Lines', gen_contour3d, dict(title='3D Contour', levels=15)))

# --- 19. 3D FILLED CONTOUR ---
def gen_contourf3d():
    x = np.linspace(-3, 3, 40)
    y = np.linspace(-3, 3, 40)
    X, Y = np.meshgrid(x, y)
    Z = np.exp(-(X**2 + Y**2))
    return X, Y, Z
tests.append(('plot_3d_contourf', '3D Filled Contour', gen_contourf3d, dict(title='3D Contourf', levels=20)))

# --- 20. 3D QUIVER (Vector Field) ---
def gen_quiver3d():
    x = np.linspace(-2, 2, 8)
    y = np.linspace(-2, 2, 8)
    z = np.linspace(-2, 2, 8)
    X, Y, Z = np.meshgrid(x, y, z)
    U = -Y
    V = X
    W = 0
    return X, Y, Z, U, V, W
tests.append(('plot_3d_quiver', '3D Quiver Arrows', gen_quiver3d, dict(title='3D Quiver', length=0.3, normalize=True)))

# --- 21. 3D STEM PLOT ---
def gen_stem3d():
    theta = np.linspace(0, 4*np.pi, 20)
    z = np.linspace(0, 4, 20)
    r = 2 + np.sin(theta)
    x = r * np.cos(theta)
    y = r * np.sin(theta)
    return x, y, z
tests.append(('plot_3d_stem', '3D Stem Plot', gen_stem3d, dict(title='3D Stem', bottom=0)))

# --- 22. 3D BAR CHART ---
def gen_bar3d():
    np.random.seed(42)
    x = [1, 2, 3]
    y = [1, 2, 3]
    z = np.zeros((3, 3))
    dx = dy = 0.5
    dz = np.random.rand(3, 3).flatten() * 2
    # Create grid
    X, Y = np.meshgrid(x, y)
    X_flat = X.flatten()
    Y_flat = Y.flatten()
    return X_flat, Y_flat, z.flatten(), dx, dy, dz
tests.append(('plot_3d_bar', '3D Bar Chart', gen_bar3d, dict(title='3D Bars')))

# --- 23. 3D VOXELS (Volume Rendering) ---
def gen_voxels():
    np.random.seed(42)
    # Create a 10x10x10 binary volume
    voxels = np.random.rand(10, 10, 10) > 0.7
    return (voxels,)  # Return as tuple for unpacking
tests.append(('plot_3d_voxels', '3D Voxels', gen_voxels, dict(title='3D Voxels', edgecolor='k', alpha=0.5)))

# --- 24. FIGURE3D (empty 3D axes) ---
def test_figure3d():
    # Not data-driven; will call directly
    pass
tests.append(('figure3d', '3D Figure (empty)', None, dict(kind='figure3d', title='3D Figure')))

# --- 16. STEM PLOT ---
def gen_stem():
    x = np.linspace(0, 10, 20)
    y = np.sin(x)
    return pd.DataFrame({'x': x, 'y': y})
tests.append(('stem', 'Stem Plot', gen_stem, dict(x='x', y='y', kind='stem', title='Stem Plot')))

# --- 17. ERRORBAR PLOT ---
def gen_errorbar():
    x = np.linspace(0, 10, 10)
    y = np.sin(x) + 2
    yerr = 0.2 * np.random.rand(10)
    return pd.DataFrame({'x': x, 'y': y, 'yerr': yerr})
tests.append(('errorbar', 'Errorbar Plot', gen_errorbar, dict(x='x', y='y', yerr='yerr', kind='errorbar', title='Errorbar Plot')))

# --- 18. SANKEY PLOT ---
def gen_sankey():
    # Sankey requires source-target format
    data = {
        'source': ['A', 'A', 'B', 'B', 'C', 'C'],
        'target': ['B', 'C', 'C', 'D', 'D', 'E'],
        'value': [10, 20, 30, 40, 50, 60]
    }
    return pd.DataFrame(data)
tests.append(('sankey', 'Sankey Diagram', gen_sankey, dict(source='source', target='target', value='value', kind='sankey', title='Sankey')))

# --- 19. SUNBURST PLOT ---
def gen_sunburst():
    data = {
        'region': ['North', 'North', 'North', 'South', 'South', 'South'],
        'city': ['Metro A', 'Metro B', 'Metro C', 'Metro D', 'Metro E', 'Metro F'],
        'value': [100, 50, 50, 30, 20, 30]
    }
    return pd.DataFrame(data)
tests.append(('sunburst', 'Sunburst', gen_sunburst, dict(path=['region', 'city'], value='value', kind='sunburst', title='Sunburst')))

# --- 20. TREEMAP PLOT ---
def gen_treemap():
    data = {
        'region': ['North', 'North', 'North', 'South', 'South', 'South'],
        'city': ['Metro A', 'Metro B', 'Metro C', 'Metro D', 'Metro E', 'Metro F'],
        'value': [100, 50, 50, 30, 20, 30]
    }
    return pd.DataFrame(data)
tests.append(('treemap', 'Treemap', gen_treemap, dict(path=['region', 'city'], value='value', kind='treemap', title='Treemap')))

# --- 21. NETWORK PLOT ---
def gen_network():
    # Edge list format
    edges = pd.DataFrame({
        'source': ['A', 'A', 'B', 'C', 'D', 'E'],
        'target': ['B', 'C', 'D', 'E', 'F', 'F'],
        'weight': [1, 2, 3, 4, 5, 6]
    })
    return edges
tests.append(('network', 'Network Graph', gen_network, dict(source='source', target='target', weight='weight', kind='network', title='Network')))

# --- 22. CANDLESTICK PLOT ---
def gen_candlestick():
    # Financial OHLC data
    np.random.seed(42)
    n = 30
    dates = pd.date_range('2024-01-01', periods=n, freq='D')
    opens = np.random.randn(n).cumsum() + 100
    closes = opens + np.random.randn(n) * 2
    highs = np.maximum(opens, closes) + np.random.rand(n) * 3
    lows = np.minimum(opens, closes) - np.random.rand(n) * 3
    return pd.DataFrame({
        'date': dates,
        'open': opens,
        'high': highs,
        'low': lows,
        'close': closes
    })
tests.append(('candlestick', 'Candlestick', gen_candlestick,
              dict(x='date', open='open', high='high', low='low', close='close', kind='candlestick', title='Candlestick')))

# --- 23. HEXBIN PLOT ---
def gen_hexbin():
    np.random.seed(42)
    n = 1000
    x = np.random.randn(n)
    y = 2*x + np.random.randn(n)*0.5
    return pd.DataFrame({'x': x, 'y': y})
tests.append(('hexbin', 'Hexbin', gen_hexbin, dict(x='x', y='y', kind='hexbin', title='Hexbin', gridsize=30)))

# --- 24. STEP PLOT ---
def gen_step():
    x = np.linspace(0, 10, 20)
    y = np.sin(x)
    return pd.DataFrame({'x': x, 'y': y})
tests.append(('step', 'Step Plot', gen_step, dict(x='x', y='y', kind='step', title='Step Plot')))

# --- 25. FILL_BETWEEN ---
def gen_fill_between():
    x = np.linspace(0, 10, 100)
    y1 = np.sin(x)
    y2 = np.sin(x) - 0.5
    return pd.DataFrame({'x': x, 'y1': y1, 'y2': y2})
tests.append(('fill_between', 'Fill Between', gen_fill_between, dict(x='x', y='y1', y2='y2', kind='fill_between', title='Fill Between')))

# --- 26. CONTOUR PLOT ---
def gen_contour():
    x = np.linspace(-3, 3, 50)
    y = np.linspace(-3, 3, 50)
    X, Y = np.meshgrid(x, y)
    Z = np.exp(-(X**2 + Y**2))
    # Return as DataFrame with x, y, z columns (long format)
    df = pd.DataFrame({
        'x': X.flatten(),
        'y': Y.flatten(),
        'z': Z.flatten()
    })
    return df
tests.append(('contour', 'Contour Plot', gen_contour, dict(x='x', y='y', z='z', kind='contour', title='Contour', levels=15)))

# --- 27. QUIVER PLOT ---
def gen_quiver():
    x = np.linspace(-2, 2, 10)
    y = np.linspace(-2, 2, 10)
    X, Y = np.meshgrid(x, y)
    U = -Y
    V = X
    df = pd.DataFrame({
        'x': X.flatten(),
        'y': Y.flatten(),
        'u': U.flatten(),
        'v': V.flatten()
    })
    return df
tests.append(('quiver', 'Quiver Plot', gen_quiver, dict(x='x', y='y', u='u', v='v', kind='quiver', title='Quiver')))

# --- 28. SPY PLOT ---
def gen_spy():
    # Sparse matrix
    np.random.seed(42)
    A = np.random.rand(20, 20)
    A[A < 0.7] = 0  # Make sparse
    return pd.DataFrame(A)
tests.append(('spy', 'Sparsity Pattern', gen_spy, dict(kind='spy', title='Spy Plot')))

# --- 29. POLAR PLOT ---
def gen_polar():
    theta = np.linspace(0, 2*np.pi, 100)
    r = np.abs(np.sin(4*theta)) + 0.5
    return pd.DataFrame({'theta': theta, 'r': r})
tests.append(('polar', 'Polar Plot', gen_polar, dict(theta='theta', r='r', kind='polar', title='Polar Plot')))

# --- 30. CARTOGRAM PLOT ---
# Cartogram requires geometric shapes; will skip/skip gracefully

# --- 31. CHOROPLETH ---
def gen_choropleth():
    try:
        import geopandas as gpd
        from shapely.geometry import Polygon
        # Create synthetic regions
        polygons = [
            Polygon([(-130, 30), (-60, 30), (-60, 50), (-130, 50)]),
            Polygon([(-90, -60), (-30, -60), (-30, 0), (-90, 0)]),
            Polygon([(-10, 35), (40, 35), (40, 60), (-10, 60)]),
            Polygon([(60, 10), (140, 10), (140, 60), (60, 60)])
        ]
        gdf = gpd.GeoDataFrame({
            'region': ['North', 'South', 'Euro', 'Asia'],
            'value': [100, 80, 120, 200]
        }, geometry=polygons, crs='EPSG:4326')
        return gdf
    except ImportError:
        return None
tests.append(('choropleth', 'Choropleth Map', gen_choropleth, dict(geometry='geometry', value='value', kind='choropleth', title='Choropleth')))

# --- 32. CARTOGRAM ---
def gen_cartogram():
    try:
        import geopandas as gpd
        from shapely.geometry import Polygon
        # Simple polygons representing regions with a value to distort
        polygons = [
            Polygon([(-130, 30), (-60, 30), (-60, 50), (-130, 50)]),
            Polygon([(-90, -60), (-30, -60), (-30, 0), (-90, 0)]),
            Polygon([(-10, 35), (40, 35), (40, 60), (-10, 60)]),
            Polygon([(60, 10), (140, 10), (140, 60), (60, 60)])
        ]
        gdf = gpd.GeoDataFrame({
            'region': ['North', 'South', 'Euro', 'Asia'],
            'value': [100, 80, 120, 200]
        }, geometry=polygons, crs='EPSG:4326')
        return gdf
    except ImportError:
        return None
tests.append(('cartogram', 'Cartogram', gen_cartogram, dict(geometry='geometry', value='value', kind='cartogram', title='Cartogram')))

# --- 33. FLOW MAP ---
def gen_flow_map():
    try:
        import geopandas as gpd
        from shapely.geometry import Point, LineString
        flows = pd.DataFrame({
            'origin_lat': [40.7, 34.0, 51.5],
            'origin_lon': [-74.0, -118.2, -0.1],
            'dest_lat': [34.0, 51.5, 35.6],
            'dest_lon': [-118.2, -0.1, 139.6],
            'volume': [5000, 3000, 4000]
        })
        return flows
    except ImportError:
        return None
tests.append(('flow_map', 'Flow Map', gen_flow_map, dict(origin_lat='origin_lat', origin_lon='origin_lon',
                                                        dest_lat='dest_lat', dest_lon='dest_lon', flow='volume',
                                                        kind='flow_map', title='Flow Map')))

# --- 33. SCATTER_GEO ---
def gen_scatter_geo():
    try:
        import geopandas as gpd
        cities = pd.DataFrame({
            'city': ['A', 'B', 'C', 'D'],
            'lat': [40.7, 34.0, 51.5, 35.6],
            'lon': [-74.0, -118.2, -0.1, 139.6],
            'temp': [22, 18, 10, 16]
        })
        return cities
    except ImportError:
        return None
tests.append(('scatter_geo', 'Scatter on Map', gen_scatter_geo, dict(lat='lat', lon='lon', value='temp', kind='scatter_geo', title='Scatter Geo')))

# --- 34. TILE MAP ---
def gen_tile_map():
    try:
        import geopandas as gpd
        from shapely.geometry import Polygon
        # Simple bounding box
        gdf = gpd.GeoDataFrame(
            {'id': [1], 'value': [100]},
            geometry=[Polygon([(-180, -85), (180, -85), (180, 85), (-180, 85)])],
            crs='EPSG:4326'
        ).to_crs(epsg=3857)
        return gdf
    except ImportError:
        return None
tests.append(('tile_map', 'Tile Map', gen_tile_map, dict(geometry='geometry', value='value', kind='tile_map', title='Tile Map')))

# --- 35. TABLE PLOT ---
def gen_table():
    data = {
        'Name': ['Alice', 'Bob', 'Charlie'],
        'Age': [25, 30, 35],
        'City': ['NYC', 'LA', 'Chicago']
    }
    return pd.DataFrame(data)
tests.append(('table', 'Table', gen_table, dict(kind='table', title='Table Plot')))

# --- 36. EVENTPLOT ---
def gen_eventplot():
    np.random.seed(42)
    events = [np.random.uniform(0, 10, 50) for _ in range(3)]
    df = pd.DataFrame({'event1': events[0], 'event2': events[1], 'event3': events[2]})
    return df
tests.append(('eventplot', 'Event Plot', gen_eventplot, dict(kind='eventplot', title='Event Plot')))

# --- 37. WATERFALL PLOT ---
def gen_waterfall():
    data = {
        'category': ['Start', 'Q1', 'Q2', 'Q3', 'Q4', 'End'],
        'value': [100, 20, 30, -10, 40, 180]
    }
    return pd.DataFrame(data)
tests.append(('waterfall', 'Waterfall', gen_waterfall, dict(x='category', y='value', kind='waterfall', title='Waterfall')))

# --- 38. GANTT PLOT ---
def gen_gantt():
    data = {
        'task': ['Task A', 'Task B', 'Task C', 'Task D'],
        'start': [0, 2, 4, 6],
        'duration': [3, 4, 2, 5]
    }
    return pd.DataFrame(data)
tests.append(('gantt', 'Gantt Chart', gen_gantt, dict(x='task', start='start', duration='duration', kind='gantt', title='Gantt')))

# --- 39. OHLC_VOLUME PLOT ---
def gen_ohlc_volume():
    np.random.seed(42)
    dates = pd.date_range('2024-01-01', periods=30, freq='D')
    base = 100 + np.random.randn(30).cumsum()
    df = pd.DataFrame({
        'date': dates,
        'open': base - np.random.rand(30),
        'high': base + np.random.rand(30)*2,
        'low': base - np.random.rand(30)*2,
        'close': base + np.random.randn(30),
        'volume': np.random.randint(1000, 10000, 30)
    })
    return df
tests.append(('ohlc_volume', 'OHLC with Volume', gen_ohlc_volume,
              dict(x='date', open='open', high='high', low='low', close='close', volume='volume',
                   kind='ohlc_volume', title='OHLC Volume')))

# --- 40. STREAMPLOT ---
def gen_streamplot():
    x = np.linspace(-3, 3, 20)
    y = np.linspace(-3, 3, 20)
    X, Y = np.meshgrid(x, y)
    U = -Y / (X**2 + Y**2 + 0.1)
    V = X / (X**2 + Y**2 + 0.1)
    mag = np.sqrt(U**2 + V**2)
    df = pd.DataFrame({
        'x': X.flatten(),
        'y': Y.flatten(),
        'u': U.flatten(),
        'v': V.flatten(),
        'magnitude': mag.flatten()
    })
    return df
tests.append(('streamplot', 'Streamplot', gen_streamplot,
              dict(x='x', y='y', u='u', v='v', kind='streamplot', title='Streamplot', color='magnitude')))

# --- 41. TRICONTOUR ---
def gen_tricontour():
    np.random.seed(42)
    n = 500
    x = np.random.uniform(-3, 3, n)
    y = np.random.uniform(-3, 3, n)
    z = np.sin(x) * np.cos(y) + np.random.randn(n)*0.1
    return pd.DataFrame({'x': x, 'y': y, 'z': z})
tests.append(('tricontour', 'Tricontour', gen_tricontour, dict(x='x', y='y', z='z', kind='tricontour', title='Tricontour', levels=15)))

# --- 42. TRICONTOURF ---
def gen_tricontourf():
    np.random.seed(42)
    n = 500
    x = np.random.uniform(-3, 3, n)
    y = np.random.uniform(-3, 3, n)
    z = np.sin(x) * np.cos(y) + np.random.randn(n)*0.1
    return pd.DataFrame({'x': x, 'y': y, 'z': z})
tests.append(('tricontourf', 'Tricontourf', gen_tricontourf, dict(x='x', y='y', z='z', kind='tricontourf', title='Tricontourf', levels=20)))

# ============================================================================
# STATISTICAL & SEABORN-STYLE PLOTS (v0.2.3+)
# ============================================================================

# --- 43. RUG PLOT ---
def gen_rug():
    np.random.seed(42)
    data = np.random.randn(200)
    return pd.DataFrame({'x': data})
tests.append(('rug', 'Rug Plot', gen_rug, dict(x='x', kind='rug', title='Rug Plot')))

# --- 44. STRIP PLOT ---
def gen_strip():
    np.random.seed(42)
    groups = ['A']*50 + ['B']*50 + ['C']*50
    values = np.concatenate([np.random.normal(0, 1, 50),
                             np.random.normal(2, 1.2, 50),
                             np.random.normal(-1, 0.8, 50)])
    return pd.DataFrame({'group': groups, 'value': values})
tests.append(('strip', 'Strip Plot', gen_strip, dict(x='group', y='value', kind='strip', title='Strip Plot')))

# --- 45. SWARM PLOT ---
def gen_swarm():
    np.random.seed(42)
    groups = ['A']*50 + ['B']*50 + ['C']*50
    values = np.concatenate([np.random.normal(0, 1, 50),
                             np.random.normal(2, 1.2, 50),
                             np.random.normal(-1, 0.8, 50)])
    return pd.DataFrame({'group': groups, 'value': values})
tests.append(('swarm', 'Swarm Plot', gen_swarm, dict(x='group', y='value', kind='swarm', title='Swarm Plot')))

# --- 46. BOXEN PLOT ---
def gen_boxen():
    np.random.seed(42)
    groups = ['A']*50 + ['B']*50 + ['C']*50
    values = np.concatenate([np.random.normal(0, 1, 50),
                             np.random.normal(2, 1.2, 50),
                             np.random.normal(-1, 0.8, 50)])
    return pd.DataFrame({'group': groups, 'value': values})
tests.append(('boxen', 'Boxen Plot (Letter-Value)', gen_boxen, dict(x='group', y='value', kind='boxen', title='Boxen Plot')))

# --- 47. QQ PLOT ---
def gen_qqplot():
    np.random.seed(42)
    data = np.random.gamma(2, 2, 200)  # skewed distribution
    return pd.DataFrame({'value': data})
tests.append(('qqplot', 'Q-Q Plot', gen_qqplot, dict(x='value', kind='qqplot', title='Q-Q Plot (Gamma)')))

# --- 48. RESIDUAL PLOT ---
def gen_residual():
    np.random.seed(42)
    x = np.linspace(0, 10, 100)
    y = 2*x + 3 + np.random.randn(100)*2
    residuals = y - (2*x + 3)
    return pd.DataFrame({'fitted': x, 'residuals': residuals})
tests.append(('residualplot', 'Residual Plot', gen_residual, dict(x='fitted', y='residuals', kind='residualplot', title='Residual Plot')))

# --- 49. JOINT PLOT ---
def gen_jointplot():
    np.random.seed(42)
    n = 200
    x = np.random.randn(n)
    y = 2*x + np.random.randn(n)*0.8
    return pd.DataFrame({'x': x, 'y': y})
tests.append(('jointplot', 'Joint Plot', gen_jointplot, dict(x='x', y='y', kind='jointplot', title='Joint Plot')))

# --- 50. LAG PLOT ---
def gen_lagplot():
    np.random.seed(42)
    # Create time series with autocorrelation
    n = 100
    values = np.zeros(n)
    values[0] = np.random.randn()
    for i in range(1, n):
        values[i] = 0.7 * values[i-1] + np.random.randn()*0.5
    return pd.DataFrame({'value': values})
tests.append(('lagplot', 'Lag Plot', gen_lagplot, dict(x='value', kind='lagplot', lag=1, title='Lag Plot (lag=1)')))

# --- 50. AUTOCORRELATION ---
def gen_autocorr():
    np.random.seed(42)
    n = 200
    values = np.zeros(n)
    values[0] = np.random.randn()
    for i in range(1, n):
        values[i] = 0.6 * values[i-1] + np.random.randn()*0.8
    return pd.DataFrame({'value': values})
tests.append(('autocorrelation', 'Autocorrelation (ACF)', gen_autocorr, dict(x='value', kind='autocorrelation', lags=30, title='Autocorrelation')))

# --- 51. ANDREWS CURVES ---
def gen_andrews():
    np.random.seed(42)
    # Multivariate data with 3 groups
    n_per_group = 50
    data = []
    labels = []
    for i, mean in enumerate([[0,0,0], [2,2,2], [-2,2,-2]]):
        for _ in range(n_per_group):
            features = np.random.randn(3) + mean
            data.append(features)
            labels.append(f'Group {i+1}')
    df = pd.DataFrame(data, columns=['feat1', 'feat2', 'feat3'])
    df['group'] = labels
    return df
tests.append(('andrews_curves', 'Andrews Curves', gen_andrews,
              dict(x='group', columns=['feat1', 'feat2', 'feat3'], kind='andrews_curves', title='Andrews Curves')))

# --- 52. PARALLEL COORDINATES ---
def gen_parallel():
    np.random.seed(42)
    n_per_class = 50
    data = []
    classes = []
    for cls in ['Setosa', 'Versicolor', 'Virginica']:
        for _ in range(n_per_class):
            # Simulate iris-like features
            if cls == 'Setosa':
                feats = [5.1 + np.random.randn()*0.3, 3.5 + np.random.randn()*0.2,
                         1.4 + np.random.randn()*0.2, 0.2 + np.random.randn()*0.05]
            elif cls == 'Versicolor':
                feats = [5.9 + np.random.randn()*0.5, 2.8 + np.random.randn()*0.3,
                         4.0 + np.random.randn()*0.4, 1.3 + np.random.randn()*0.2]
            else:
                feats = [6.5 + np.random.randn()*0.6, 3.0 + np.random.randn()*0.4,
                         5.5 + np.random.randn()*0.5, 2.0 + np.random.randn()*0.3]
            data.append(feats)
            classes.append(cls)
    df = pd.DataFrame(data, columns=['sepal_length', 'sepal_width', 'petal_length', 'petal_width'])
    df['species'] = classes
    return df
tests.append(('parallel_coordinates', 'Parallel Coordinates', gen_parallel,
              dict(x='species', columns=['sepal_length', 'sepal_width', 'petal_length', 'petal_width'],
                   kind='parallel_coordinates', title='Parallel Coordinates')))

# --- 53. RADVIZ ---
def gen_radviz():
    # Same data as Andrews for consistency
    return gen_parallel()
tests.append(('radviz', 'RadViz', gen_radviz,
              dict(x='species', columns=['sepal_length', 'sepal_width', 'petal_length', 'petal_width'],
                   kind='radviz', title='RadViz')))

# --- 54. PAIR PLOT ---
def gen_pairplot():
    np.random.seed(42)
    n = 150
    data = {
        'feat1': np.random.randn(n),
        'feat2': np.random.randn(n) * 2 + 1,
        'feat3': np.random.randn(n) * 0.5 - 1,
        'feat4': np.random.randn(n) * 3 + 2
    }
    return pd.DataFrame(data)
tests.append(('pairplot', 'Pair Plot', gen_pairplot,
              dict(columns=['feat1', 'feat2', 'feat3', 'feat4'], kind='pairplot', title='Pair Plot')))

# ============================================================================
# RUN TESTS - MATPLOTLIB
# ============================================================================
print("\n" + "=" * 80)
print("MATPLOTLIB BACKEND (PNG OUTPUT)")
print("=" * 80)

set_backend('matplotlib')
results = []

for plot_kind, label, gen_fn, plot_kwargs in tests:
    print(f"\n[{plot_kind}] {label}...")
    try:
        # Generate data
        if gen_fn is None:
            # For non-data-driven plots like figure3d
            data = None
        else:
            data = gen_fn()
            if data is None:
                print(f"   [SKIP] Data not available (missing dependency)")
                results.append((plot_kind, False, "Missing dependency"))
                continue

        # Create plot using vz.plot or direct 3D functions
        if plot_kind in ['figure3d', 'plot_3d_surface', 'plot_3d_wireframe', 'plot_3d_trisurf',
                        'plot_3d_contour', 'plot_3d_contourf', 'plot_3d_quiver',
                        'plot_3d_stem', 'plot_3d_bar', 'plot_3d_voxels']:
            # 3D functions return (fig, ax) tuple
            plot_func = getattr(vz, plot_kind)
            if data is None:
                # No data needed (e.g., figure3d)
                result = plot_func(**plot_kwargs)
            else:
                # Data is tuple of positional arguments (X, Y, Z, etc.)
                result = plot_func(*data, **plot_kwargs)
            if isinstance(result, tuple):
                fig, _ = result
            else:
                fig = result
        else:
            # Normal data-driven plot
            fig = vz.plot(data, **plot_kwargs)

        # Save as PNG
        filename = mpl_dir / f"{plot_kind}.png"
        fig.savefig(str(filename), dpi=150, bbox_inches='tight')
        vz.close(fig)
        print(f"   [OK] Saved: {filename}")
        results.append((plot_kind, True, str(filename)))
    except Exception as e:
        print(f"   [FAIL] {str(e)}")
        results.append((plot_kind, False, str(e)))
        traceback.print_exc()

# ============================================================================
# RUN TESTS - PLOTLY (if available)
# ============================================================================
if plotly_available:
    print("\n" + "=" * 80)
    print("PLOTLY BACKEND (HTML OUTPUT)")
    print("=" * 80)

    set_backend('plotly')

    for plot_kind, label, gen_fn, plot_kwargs in tests:
        print(f"\n[{plot_kind}] {label}...")
        try:
            # Check if backend likely supports this plot kind
            # (If it uses _not_implemented, we'll get an error)
            data = gen_fn() if gen_fn else None
            if data is None:
                print(f"   [SKIP] Data not available")
                continue

            if plot_kind in ['figure3d', 'plot_3d_surface', 'plot_3d_wireframe', 'plot_3d_trisurf',
                            'plot_3d_contour', 'plot_3d_contourf', 'plot_3d_quiver',
                            'plot_3d_stem', 'plot_3d_bar', 'plot_3d_voxels']:
                # 3D functions are Matplotlib-only; skip in Plotly backend
                raise NotImplementedError(f"'{plot_kind}' is Matplotlib-only")
            else:
                fig = vz.plot(data, **plot_kwargs)

            # Save as HTML using Plotly's native method
            filename = plotly_dir / f"{plot_kind}.html"
            fig.write_html(str(filename))
            vz.close(fig)
            print(f"   [OK] Saved: {filename}")
        except Exception as e:
            # Plotly may not implement this kind
            print(f"   [SKIP] Not implemented in plotly backend: {str(e)}")
else:
    print("\n[INFO] Plotly backend not available - skipping HTML outputs")

# ============================================================================
# SUMMARY REPORT
# ============================================================================
print("\n" + "=" * 80)
print("SUMMARY")
print("=" * 80)

success_count = sum(1 for _, success, _ in results if success)
fail_count = len(results) - success_count

print(f"\nTotal plot types: {len(results)}")
print(f"  Successful:  {success_count}")
print(f"  Failed:      {fail_count}")

if fail_count > 0:
    print("\nFailed plot types:")
    for kind, success, msg in results:
        if not success:
            print(f"  - {kind}: {msg}")

print(f"\nOutput saved to: {output_root}/")
print(f"  Matplotlib PNGs: {mpl_dir}/")
if plotly_available:
    print(f"  Plotly HTMLs: {plotly_dir}/")
print("=" * 80)
