"""
Demo: Using open_browser parameter with show_plotly() and save_plotly()

This demonstrates the new open_browser feature that automatically
opens the interactive plot in your default web browser.
"""

import numpy as np
import pandas as pd
import bottleviz as vz

print("=" * 60)
print("BottleViz open_browser Demo")
print("=" * 60)

# Create sample data
np.random.seed(42)
df = pd.DataFrame({
    'x': np.random.randn(100),
    'y': np.random.randn(100),
    'category': np.random.choice(['A', 'B', 'C'], 100)
})

print("\n1. Using show_plotly() with open_browser=True")
print("   This creates the HTML and automatically opens it in your browser.")
print("   Example: vz.show_plotly(df, x='x', y='y', kind='scatter', open_browser=True)")
# Uncomment to test:
vz.show_plotly(df, x='x', y='y', kind='scatter', open_browser=True)

print("\n2. Using save_plotly() with open_browser=True")
print("   This saves to file AND opens it automatically.")
print("   Example: vz.save_plotly(df, 'my_plot.html', x='x', y='y', kind='scatter', open_browser=True)")
# Uncomment to test:
vz.save_plotly(df, 'my_plot.html', x='x', y='y', kind='scatter', open_browser=True)

print("\n3. Default behavior (backward compatible)")
print("   Without open_browser, returns HTML string only (doesn't open browser).")
print("   Example: html = vz.show_plotly(df, x='x', y='y', kind='scatter')")
html = vz.show_plotly(df, x='x', y='y', kind='scatter')
print(f"   Generated {len(html)} chars of HTML")

print("\n" + "=" * 60)
print("Demo complete!")
print("=" * 60)
