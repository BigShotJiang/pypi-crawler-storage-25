"""
Exceptions module for BottleViz.

Re-exports exceptions from core.exceptions for backward compatibility.
"""

from .core.exceptions import VisualizerError, DataError, StyleError

__all__ = ['VisualizerError', 'DataError', 'StyleError']
