"""
Backend abstraction layer for BottleViz.

Supports multiple rendering backends (matplotlib, plotly, etc.).
Backend handles the actual rendering while core handles logic.
"""

from typing import Any, Dict, List, Optional
import warnings
import numpy as np
import pandas as pd

from ..core.exceptions import VisualizerError

# Backend registry
_backends = {}
_active_backend = None


def register_backend(name: str, backend_module: Any) -> None:
    """
    Register a new rendering backend.

    Parameters
    ----------
    name : str
        Backend identifier
    backend_module : module
        Module implementing the backend interface
    """
    _backends[name] = backend_module


def set_backend(name: str) -> None:
    """
    Set the active rendering backend.

    Parameters
    ----------
    name : str
        Backend name: 'matplotlib', 'plotly', etc.

    Raises
    ------
    VisualizerError
        If backend is not available
    """
    global _active_backend

    if name not in _backends:
        raise VisualizerError(
            f"Backend '{name}' not found. Available: {list(_backends.keys())}"
        )

    _active_backend = _backends[name]


def get_backend() -> Any:
    """
    Get the currently active backend.

    Returns
    -------
    module
        The active backend module

    Raises
    ------
    VisualizerError
        If no backend is set
    """
    global _active_backend

    if _active_backend is None:
        # Try to initialize matplotlib backend by default
        try:
            backend = MatplotlibBackend()
            register_backend('matplotlib', backend)
            _active_backend = backend
        except ImportError:
            raise VisualizerError(
                "No backend available. Please install matplotlib:\n"
                "  pip install matplotlib"
            )

    return _active_backend


# ========== Matplotlib Backend Implementation ==========

class MatplotlibBackend:
    """
    Matplotlib-based rendering backend.

    Provides all plot types using matplotlib with optimized settings.
    """

    def __init__(self):
        """Initialize matplotlib backend."""
        try:
            import matplotlib.pyplot as plt
            import matplotlib as mpl
            self.plt = plt
            self.mpl = mpl
            self._has_mpl = True
        except ImportError as e:
            raise VisualizerError(
                "Matplotlib is required for this backend. "
                f"Install with: pip install matplotlib\n"
                f"Original error: {e}"
            )

    def _create_figure(self, config: Dict[str, Any]):
        """Create figure and axes based on config."""
        n_rows = config.get('n_rows', 1)
        n_cols = config.get('n_cols', 1)

        if n_rows == 1 and n_cols == 1:
            fig, ax = self.plt.subplots(figsize=config.get('figsize', (10, 6)))
            axes = [ax]
        else:
            fig, axes = self.plt.subplots(
                n_rows, n_cols,
                figsize=config.get('figsize', (12, 8)),
                squeeze=False
            )
            axes = list(axes.flatten())

        # Set window title
        window_title = self._generate_window_title(config)
        try:
            if hasattr(fig.canvas, 'manager') and fig.canvas.manager:
                fig.canvas.manager.set_window_title(window_title)
            elif hasattr(fig.canvas, 'set_window_title'):
                fig.canvas.set_window_title(window_title)
        except Exception:
            pass

        return fig, axes

    def line_plot(self, config: Dict[str, Any]) -> Any:
        """Create line plot."""
        data = config['data']
        x_col = config.get('x')
        y_cols = config.get('y')

        fig, ax = self._create_single_axes(config)

        if y_cols is None:
            # Plot all numeric columns
            numeric_cols = data.select_dtypes(include='number').columns
            for col in numeric_cols:
                ax.plot(data.index if x_col is None else data[x_col],
                        data[col],
                        label=col,
                        **config.get('line_kwargs', {}))
        else:
            if isinstance(y_cols, str):
                y_cols = [y_cols]

            for y_col in y_cols:
                ax.plot(data.index if x_col is None else data[x_col],
                        data[y_col],
                        label=y_col,
                        **config.get('line_kwargs', {}))

        self._apply_labels(ax, config)
        ax.legend()
        return fig

    def scatter_plot(self, config: Dict[str, Any]) -> Any:
        """Create scatter plot."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        if y_col is None:
            raise VisualizerError("Scatter plot requires 'y' parameter")

        fig, ax = self._create_single_axes(config)

        if isinstance(y_col, list):
            # Multiple y columns
            for y in y_col:
                ax.scatter(data[x_col], data[y], label=y, **config.get('scatter_kwargs', {}))
        else:
            ax.scatter(data[x_col], data[y_col], **config.get('scatter_kwargs', {}))

        self._apply_labels(ax, config)
        if isinstance(y_col, list):
            ax.legend()
        return fig

    def bar_plot(self, config: Dict[str, Any]) -> Any:
        """Create bar plot."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        fig, ax = self._create_single_axes(config)

        if y_col is None:
            # Simple bar chart from values
            if isinstance(data, (list, np.ndarray)):
                ax.bar(range(len(data)), data)
            else:
                # Plot numeric columns as bars
                numeric_cols = data.select_dtypes(include='number').columns
                x = range(len(numeric_cols))
                heights = [data[col].mean() for col in numeric_cols]
                ax.bar(x, heights, tick_label=numeric_cols)
        else:
            if isinstance(y_col, list):
                # Grouped bar chart
                x = data[x_col] if x_col else range(len(data))
                width = 0.8 / len(y_col)
                for i, y in enumerate(y_col):
                    offset = (i - len(y_col)/2 + 0.5) * width
                    ax.bar(np.arange(len(x)) + offset, data[y],
                           width=width, label=y)
                ax.set_xticks(range(len(x)))
                if x_col:
                    ax.set_xticklabels(x)
            else:
                ax.bar(data[x_col] if x_col else range(len(data)),
                       data[y_col],
                       **config.get('bar_kwargs', {}))

        self._apply_labels(ax, config)
        if isinstance(y_col, list):
            ax.legend()
        return fig

    def hist_plot(self, config: Dict[str, Any]) -> Any:
        """Create histogram."""
        data = config['data']
        columns = config.get('y')  # columns to plot

        fig, axes = self._create_figure(config)
        if not isinstance(axes, list):
            axes = [axes]

        if columns is None:
            numeric_cols = data.select_dtypes(include='number').columns
            columns = numeric_cols

        if isinstance(columns, str):
            columns = [columns]

        for ax, col in zip(axes, columns):
            ax.hist(data[col].dropna(),
                    bins=config.get('bins', 'auto'),
                    alpha=config.get('alpha', 0.7),
                    edgecolor='black',
                    **config.get('hist_kwargs', {}))
            ax.set_xlabel(col)
            ax.set_ylabel('Frequency')

        self.plt.tight_layout()
        return fig

    def box_plot(self, config: Dict[str, Any]) -> Any:
        """Create box plot."""
        data = config['data']
        columns = config.get('y') or data.select_dtypes(include='number').columns

        fig, ax = self._create_single_axes(config)

        if isinstance(columns, str):
            columns = [columns]

        ax.boxplot([data[col].dropna() for col in columns],
                   labels=columns,
                   **config.get('box_kwargs', {}))

        self._apply_labels(ax, config)
        ax.grid(True, alpha=0.3)
        return fig

    def violin_plot(self, config: Dict[str, Any]) -> Any:
        """Create violin plot."""
        data = config['data']
        columns = config.get('y') or data.select_dtypes(include='number').columns

        fig, ax = self._create_single_axes(config)

        if isinstance(columns, str):
            columns = [columns]

        data_list = [data[col].dropna() for col in columns]
        parts = ax.violinplot(data_list, showmeans=True)

        # Style the violin plots
        for pc in parts['bodies']:
            pc.set_alpha(0.7)
            pc.set_edgecolor('black')

        ax.set_xticks(range(1, len(columns) + 1))
        ax.set_xticklabels(columns)

        self._apply_labels(ax, config)
        ax.grid(True, alpha=0.3)
        return fig

    def kde_plot(self, config: Dict[str, Any]) -> Any:
        """Create KDE (Kernel Density Estimate) plot."""
        data = config['data']
        columns = config.get('y') or data.select_dtypes(include='number').columns

        fig, ax = self._create_single_axes(config)

        if isinstance(columns, str):
            columns = [columns]

        for col in columns:
            ax = data[col].plot.kde(ax=ax, label=col, **config.get('kde_kwargs', {}))

        ax.set_xlabel('Value')
        ax.set_ylabel('Density')
        self._apply_labels(ax, config)
        if len(columns) > 1:
            ax.legend()
        return fig

    def area_plot(self, config: Dict[str, Any]) -> Any:
        """Create stacked area plot."""
        data = config['data']
        y_cols = config.get('y') or data.select_dtypes(include='number').columns
        x_col = config.get('x')

        fig, ax = self._create_single_axes(config)

        if x_col:
            x = data[x_col]
        else:
            x = data.index

        if isinstance(y_cols, str):
            y_cols = [y_cols]

        ax.stackplot(x, [data[col] for col in y_cols],
                     labels=y_cols,
                     alpha=0.7,
                     **config.get('area_kwargs', {}))

        self._apply_labels(ax, config)
        ax.legend()
        return fig

    def heatmap_plot(self, config: Dict[str, Any]) -> Any:
        """Create heatmap (typically for correlation matrix)."""
        data = config['data']

        # If data is correlation matrix or needs pivot
        if config.get('pivot'):
            # Pivot table required
            pivot_data = data.pivot_table(
                index=config.get('index'),
                columns=config.get('columns'),
                values=config.get('values')
            )
        else:
            pivot_data = data

        fig, ax = self._create_single_axes(config)

        im = ax.imshow(pivot_data,
                       cmap=config.get('cmap', 'viridis'),
                       aspect='auto',
                       **config.get('heatmap_kwargs', {}))

        # Add annotations if requested
        if config.get('annot', False):
            annot_fmt = config.get('fmt', '.2f')
            annot_fontsize = config.get('annot_fontsize', 9)
            annot_color = config.get('annot_color', 'black')
            data_vals = pivot_data.values
            # Iterate over rows (y) and columns (x)
            for i in range(data_vals.shape[0]):
                for j in range(data_vals.shape[1]):
                    val = data_vals[i, j]
                    try:
                        text = format(val, annot_fmt)
                    except (ValueError, TypeError):
                        text = str(val)
                    ax.text(j, i, text, ha='center', va='center',
                            fontsize=annot_fontsize, color=annot_color)

        # Add colorbar
        self.plt.colorbar(im, ax=ax)

        # Set labels
        if config.get('pivot'):
            ax.set_xticks(range(len(pivot_data.columns)))
            ax.set_yticks(range(len(pivot_data.index)))
            ax.set_xticklabels(pivot_data.columns, rotation=45, ha='right')
            ax.set_yticklabels(pivot_data.index)
        else:
            ax.set_xticks(range(len(pivot_data.columns)))
            ax.set_yticks(range(len(pivot_data)))
            ax.set_xticklabels(pivot_data.columns, rotation=45, ha='right')
            ax.set_yticklabels(pivot_data.index if hasattr(pivot_data, 'index') else range(len(pivot_data)))

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def pie_plot(self, config: Dict[str, Any]) -> Any:
        """Create pie chart."""
        data = config['data']
        values = config.get('y')
        labels = config.get('x')

        fig, ax = self._create_single_axes(config)

        if values is None:
            # Count values in categorical column
            counts = data.iloc[:, 0].value_counts()
            labels = counts.index.tolist()
            values = counts.values
        else:
            if isinstance(values, str):
                values = data[values]
            if labels is not None and isinstance(labels, str):
                labels = data[labels]

        wedges, texts, autotexts = ax.pie(
            values,
            labels=labels,
            autopct='%1.1f%%',
            startangle=90,
            **config.get('pie_kwargs', {})
        )

        # Style percentage text
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')

        ax.axis('equal')
        self._apply_labels(ax, config)
        return fig

    def plot_3d(self, config: Dict[str, Any]) -> Any:
        """Create 3D scatter/surface plot."""
        data = config['data']
        x = config.get('x')
        y = config.get('y')
        z = config.get('z')

        if z is None:
            raise VisualizerError("3D plot requires 'z' parameter")

        fig = self.plt.figure(figsize=config.get('figsize', (10, 8)))
        ax = fig.add_subplot(111, projection='3d')

        # Check if surface plot is requested
        surface = config.get('surface', False)

        if surface:
            # For surface plots, data should be on a regular grid
            # Reshape 1D arrays to 2D grids
            x_vals = data[x].values
            y_vals = data[y].values
            z_vals = data[z].values

            # Determine grid dimensions (assumes square grid)
            n = int(np.sqrt(len(x_vals)))
            if n * n != len(x_vals):
                raise VisualizerError(
                    "Surface plot requires data on a regular grid. "
                    f"Got {len(x_vals)} points, expected a perfect square."
                )

            X = x_vals.reshape(n, n)
            Y = y_vals.reshape(n, n)
            Z = z_vals.reshape(n, n)

            ax.plot_surface(X, Y, Z,
                           **config.get('3d_kwargs', {}))
        else:
            ax.scatter(data[x], data[y], data[z],
                       **config.get('3d_kwargs', {}))

        ax.set_xlabel(x)
        ax.set_ylabel(y)
        ax.set_zlabel(z)
        self._apply_labels(ax, config)
        return fig

    def figure3d(self, config: Dict[str, Any]) -> Any:
        """Create an empty 3D figure and return the axes."""
        fig = self.plt.figure(figsize=config.get('figsize', (10, 8)))
        ax = fig.add_subplot(111, projection='3d')
        self._apply_labels(ax, config)
        return fig, ax

    def plot_surface(self, ax, X, Y, Z, **kwargs):
        """Add a surface plot to an existing 3D axes."""
        ax.plot_surface(X, Y, Z, **kwargs)

    def plot_wireframe(self, ax, X, Y, Z, **kwargs):
        """Add a wireframe plot to an existing 3D axes."""
        ax.plot_wireframe(X, Y, Z, **kwargs)

    def plot_trisurf(self, ax, X, Y, Z, **kwargs):
        """Add a triangular surface plot to an existing 3D axes."""
        ax.plot_trisurf(X, Y, Z, **kwargs)

    def contour(self, ax, X, Y, Z, **kwargs):
        """Add 3D contour lines to an existing 3D axes."""
        ax.contour(X, Y, Z, **kwargs)

    def contourf(self, ax, X, Y, Z, **kwargs):
        """Add filled 3D contour plot to an existing 3D axes."""
        ax.contourf(X, Y, Z, **kwargs)

    def quiver(self, ax, X, Y, Z, U, V, W, **kwargs):
        """Add 3D quiver (arrow) plot to an existing 3D axes."""
        ax.quiver(X, Y, Z, U, V, W, **kwargs)

    def stem(self, ax, X, Y, Z, **kwargs):
        """Add 3D stem plot to an existing 3D axes."""
        ax.stem(X, Y, Z, **kwargs)

    def bar3d(self, ax, X, Y, Z, dx, dy, dz, **kwargs):
        """Add 3D bar plot to an existing 3D axes."""
        ax.bar3d(X, Y, Z, dx, dy, dz, **kwargs)

    def voxels(self, ax, voxels, **kwargs):
        """Add 3D voxel plot to an existing 3D axes."""
        ax.voxels(voxels, **kwargs)

    def create_dashboard(self, config: Dict[str, Any]) -> Any:
        """Create multi-plot dashboard."""
        data = config['data']
        columns = config.get('columns', [])
        plot_type = config.get('plot_type', 'auto')

        n_rows = config['n_rows']
        n_cols = config['n_cols']

        fig, axes = self._create_figure(config)
        axes = axes if isinstance(axes, list) else [axes]

        for idx, col in enumerate(columns):
            ax = axes[idx]

            if plot_type == 'distribution' or plot_type == 'auto':
                # Histogram + KDE (KDE requires scipy, optional)
                ax.hist(data[col].dropna(), bins=30, alpha=0.7, density=True)
                try:
                    data[col].plot.kde(ax=ax)
                except ImportError:
                    # KDE requires scipy; skip if not available
                    warnings.warn(
                        "KDE plot requires scipy. Install with: pip install scipy",
                        UserWarning
                    )
                ax.set_title(f'Distribution of {col}')
                ax.set_xlabel(col)
                ax.set_ylabel('Density')
            elif plot_type == 'correlation':
                # Scatter against first numeric column
                first_col = columns[0] if columns[0] != col else columns[1] if len(columns) > 1 else col
                ax.scatter(data[first_col], data[col], alpha=0.6)
                ax.set_xlabel(first_col)
                ax.set_ylabel(col)
                ax.set_title(f'{col} vs {first_col}')
                ax.grid(True, alpha=0.3)

        # Hide any unused subplots
        for idx in range(len(columns), len(axes)):
            axes[idx].set_visible(False)

        self.plt.tight_layout()
        return fig

    def _create_single_axes(self, config: Dict[str, Any]):
        """Helper to create a single axes object."""
        figsize = config.get('figsize', (10, 6))
        fig, ax = self.plt.subplots(figsize=figsize)

        # Set window title
        window_title = self._generate_window_title(config)
        try:
            if hasattr(fig.canvas, 'manager') and fig.canvas.manager:
                fig.canvas.manager.set_window_title(window_title)
            elif hasattr(fig.canvas, 'set_window_title'):
                fig.canvas.set_window_title(window_title)
        except Exception:
            # Silently ignore if window title setting fails
            pass

        return fig, ax

    def _apply_labels(self, ax, config: Dict[str, Any]):
        """Apply title and axis labels to axes."""
        title = config.get('title')
        xlabel = config.get('xlabel')
        ylabel = config.get('ylabel')
        zlabel = config.get('zlabel')

        if title:
            ax.set_title(title, fontsize=config.get('title_fontsize', 14))
        if xlabel:
            ax.set_xlabel(xlabel, fontsize=config.get('label_fontsize', 12))
        if ylabel:
            ax.set_ylabel(ylabel, fontsize=config.get('label_fontsize', 12))
        if zlabel and hasattr(ax, 'set_zlabel'):
            ax.set_zlabel(zlabel, fontsize=config.get('label_fontsize', 12))

        if config.get('grid', True) and not hasattr(ax, 'set_zlabel'):
            # Grid only for 2D axes
            ax.grid(True, alpha=0.3)

    def _generate_window_title(self, config: Dict[str, Any]) -> str:
        """Generate a descriptive window title for the figure."""
        kind = config.get('kind') or config.get('plot_type', 'Plot')
        title = config.get('title', '')
        x = config.get('x')
        y = config.get('y')

        # Build base title
        if isinstance(kind, str):
            base = kind.title()
        else:
            base = 'Plot'

        # Add context
        if title:
            return f"{base} - {title}"
        elif x and y:
            if isinstance(y, (list, tuple)):
                return f"{base} - {x} vs {len(y)} metrics"
            else:
                return f"{base} - {x} vs {y}"
        elif x:
            return f"{base} - {x}"
        elif y:
            if isinstance(y, (list, tuple)):
                return f"{base} - {', '.join(y[:2])}{'...' if len(y) > 2 else ''}"
            return f"{base} - {y}"
        else:
            return f"{base}"

    def stem_plot(self, config: Dict[str, Any]) -> Any:
        """Create stem plot (lollipop chart)."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        fig, ax = self._create_single_axes(config)

        if y_col is None:
            # Plot all numeric columns with stems
            numeric_cols = data.select_dtypes(include='number').columns
            for col in numeric_cols:
                (markerline, stemlines, baseline) = ax.stem(
                    data.index if x_col is None else data[x_col],
                    data[col],
                    label=col,
                    **config.get('stem_kwargs', {})
                )
                self.plt.setp(stemlines, linewidth=1)
        else:
            if isinstance(y_col, str):
                y_col = [y_col]

            for col in y_col:
                (markerline, stemlines, baseline) = ax.stem(
                    data.index if x_col is None else data[x_col],
                    data[col],
                    label=col,
                    **config.get('stem_kwargs', {})
                )
                self.plt.setp(stemlines, linewidth=1)

        self._apply_labels(ax, config)
        if isinstance(y_col, list) or y_col is None:
            ax.legend()
        return fig

    def errorbar_plot(self, config: Dict[str, Any]) -> Any:
        """Create error bar plot."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        yerr_col = config.get('yerr')  # Can be column name or array
        xerr_col = config.get('xerr')  # Can be column name or array

        if y_col is None:
            raise VisualizerError("Error bar plot requires 'y' parameter")

        fig, ax = self._create_single_axes(config)

        # Get y data
        y_data = data[y_col] if isinstance(y_col, str) else y_col
        if isinstance(y_col, str):
            y_data = data[y_col]

        # Get x data
        x_data = data[x_col] if x_col else (data.index if isinstance(y_col, str) else range(len(y_data)))
        if x_col and isinstance(x_col, str):
            x_data = data[x_col]

        # Get error data
        yerr_data = None
        if yerr_col:
            if isinstance(yerr_col, str) and yerr_col in data.columns:
                yerr_data = data[yerr_col]
            else:
                yerr_data = yerr_col

        xerr_data = None
        if xerr_col:
            if isinstance(xerr_col, str) and xerr_col in data.columns:
                xerr_data = data[xerr_col]
            else:
                xerr_data = xerr_col

        # Create errorbar plot
        ax.errorbar(
            x_data,
            y_data,
            yerr=yerr_data,
            xerr=xerr_data,
            **config.get('errorbar_kwargs', {})
        )

        self._apply_labels(ax, config)
        return fig

    def sankey_plot(self, config: Dict[str, Any]) -> Any:
        """Create Sankey diagram (flow visualization) using networkx multipartite layout."""
        try:
            import networkx as nx
        except ImportError:
            raise VisualizerError(
                "Sankey plot requires 'networkx' library. "
                "Install with: pip install networkx"
            )

        data = config['data']
        source_col = config.get('source') or config.get('source_col')
        target_col = config.get('target') or config.get('target_col')
        value_col = config.get('value') or config.get('value_col', 'value')
        path_cols = config.get('path')  # for multi-stage

        if path_cols is not None:
            if not isinstance(path_cols, (list, tuple)):
                path_cols = [path_cols]
            if len(path_cols) < 2:
                raise VisualizerError("Sankey path requires at least 2 columns")
            # Build directed graph from consecutive columns
            G = nx.DiGraph()
            val_col = config.get('value')
            for i in range(len(path_cols) - 1):
                src_col = path_cols[i]
                tgt_col = path_cols[i+1]
                group_cols = [src_col, tgt_col]
                if val_col and val_col in data.columns:
                    agg = data.groupby(group_cols)[val_col].sum().reset_index()
                else:
                    agg = data.groupby(group_cols).size().reset_index(name='value')
                # Add edges with weight, nodes with layer
                for _, row in agg.iterrows():
                    src_val = row[src_col]
                    tgt_val = row[tgt_col]
                    weight = row['value']
                    src_id = (src_val, i)
                    tgt_id = (tgt_val, i+1)
                    if not G.has_node(src_id):
                        G.add_node(src_id, label=src_val, layer=i)
                    if not G.has_node(tgt_id):
                        G.add_node(tgt_id, label=tgt_val, layer=i+1)
                    G.add_edge(src_id, tgt_id, weight=weight)
        elif source_col and target_col:
            # Two-level Sankey
            if source_col not in data.columns or target_col not in data.columns:
                raise VisualizerError(f"Columns not found: {source_col}, {target_col}")
            G = nx.DiGraph()
            if value_col not in data.columns:
                data = data.copy()
                data['_sankey_value'] = 1
                value_col = '_sankey_value'
            agg = data.groupby([source_col, target_col])[value_col].sum().reset_index()
            for _, row in agg.iterrows():
                src = row[source_col]
                tgt = row[target_col]
                G.add_node(src, layer=0)
                G.add_node(tgt, layer=1)
                G.add_edge(src, tgt, weight=row[value_col])
        else:
            raise VisualizerError("Sankey requires either 'path' or 'source' and 'target' parameters")

        # Compute layout: nodes placed in layers (0,1,2,...) horizontally
        layers = {}
        for node, data_node in G.nodes(data=True):
            layer = data_node['layer']
            layers.setdefault(layer, []).append(node)
        pos = {}
        max_nodes = max(len(nodes) for nodes in layers.values()) if layers else 1
        # We'll place layers from left (x=0) to right (x=layer_index)
        layer_x_spacing = config.get('layer_spacing', 1.0)
        node_y_spacing = config.get('node_spacing', 1.0)
        for layer_idx, nodes in sorted(layers.items()):
            x = layer_idx * layer_x_spacing
            n = len(nodes)
            # spread nodes vertically within layer
            if n == 1:
                ys = [0]
            else:
                total_height = (n - 1) * node_y_spacing
                start_y = -total_height / 2
                ys = [start_y + i * node_y_spacing for i in range(n)]
            # Sort nodes to have consistent ordering (by label)
            nodes_sorted = sorted(nodes, key=lambda n: str(G.nodes[n].get('label', n)))
            for node, y in zip(nodes_sorted, ys):
                pos[node] = (x, y)

        # Draw
        fig, ax = self._create_single_axes(config)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_aspect('equal')
        ax.axis('off')

        # Draw edges as lines with width proportional to weight
        weights = [d['weight'] for (u, v, d) in G.edges(data=True)]
        max_weight = max(weights) if weights else 1
        # Color edges by source-target gradient or single color
        edge_color = config.get('edge_color', 'gray')
        for (u, v, d) in G.edges(data=True):
            weight = d['weight']
            linewidth = config.get('linewidth_scale', 5) * (weight / max_weight)
            ax.plot([pos[u][0], pos[v][0]], [pos[u][1], pos[v][1]],
                    color=edge_color, linewidth=linewidth, alpha=0.6, solid_capstyle='round')

        # Draw nodes
        node_color = config.get('node_color', '#1f77b4')
        node_size = config.get('node_size', 300)
        for node, (x, y) in pos.items():
            ax.scatter(x, y, s=node_size, c=[node_color], edgecolors='black', zorder=2)
            label = G.nodes[node].get('label', node) if hasattr(G, 'nodes') else node
            ax.text(x, y - 0.3*node_y_spacing, str(label), ha='center', va='top', fontsize=9)

        title = config.get('title') or 'Sankey Diagram'
        ax.set_title(title, fontsize=config.get('title_fontsize', 14))
        self.plt.tight_layout()
        return fig

    def sunburst_plot(self, config: Dict[str, Any]) -> Any:
        """Create Sunburst chart (hierarchical radial diagram)."""
        data = config['data']
        path_cols = config.get('path') or config.get('path_cols')  # List of columns defining hierarchy
        value_col = config.get('value') or config.get('value_col')
        label_col = config.get('label') or config.get('label_col')

        if path_cols is None:
            raise VisualizerError(
                "Sunburst plot requires 'path' parameter specifying hierarchical column order "
                "(e.g., ['region', 'city', 'store'])"
            )

        if not isinstance(path_cols, (list, tuple)):
            path_cols = [path_cols]

        if value_col is None:
            raise VisualizerError("Sunburst plot requires 'value' column for segment sizes")

        if value_col not in data.columns:
            raise VisualizerError(f"Value column '{value_col}' not found")

        # Aggregate data by path
        group_cols = path_cols
        agg_data = data.groupby(group_cols)[value_col].sum().reset_index()

        # Compute angles for each segment
        total = agg_data[value_col].sum()
        agg_data['percent'] = agg_data[value_col] / total

        # Build hierarchy levels and compute wedges
        # We'll use a polar plot to create concentric rings
        figsize = config.get('figsize', (10, 8))
        fig = self.plt.figure(figsize=figsize)
        ax = fig.add_subplot(111, projection='polar')

        # Compute wedge properties
        levels = len(path_cols)
        colors = self.plt.cm.tab20c(np.linspace(0, 1, len(agg_data)))

        # Starting angle
        th = []  # theta ranges
        widths = []
        colors_list = []
        labels = []
        radii = []

        # Build wedges from inner to outer
        for level in range(levels):
            level_data = agg_data.groupby(path_cols[:level+1]).sum().reset_index()
            level_total = level_data[value_col].sum()

            start_angle = 0
            for idx, row in level_data.iterrows():
                val = row[value_col]
                width = 2 * np.pi * (val / total)
                th.append([start_angle, start_angle + width])
                radii.append([1 + level, 1 + level + 1])  # inner and outer radius
                colors_list.append(colors[idx % len(colors)])
                # Label only at outer level
                if level == levels - 1:
                    label = str(row[path_cols[-1]]) if label_col is None else str(row[label_col])
                    labels.append(label)
                else:
                    labels.append('')
                start_angle += width

        # Draw wedges
        for (theta0, theta1), (r0, r1), color, label in zip(th, radii, colors_list, labels):
            ax.bar(
                x=theta0,
                width=theta1 - theta0,
                bottom=r0,
                height=r1 - r0,
                color=color,
                edgecolor='white',
                linewidth=1,
                alpha=0.8,
                label=label if label else None
            )

        # Style axis
        ax.set_theta_zero_location('N')
        ax.set_theta_direction(-1)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_ylim(0, levels + 1)

        title = config.get('title') or 'Sunburst Chart'
        ax.set_title(title, fontsize=config.get('title_fontsize', 14), pad=20)

        # Add legend if labels are provided
        if any(labels):
            ax.legend(loc='center left', bbox_to_anchor=(1.1, 0.5), fontsize=9)

        return fig

    def treemap_plot(self, config: Dict[str, Any]) -> Any:
        """Create Treemap (hierarchical rectangular layout)."""
        try:
            import squarify
        except ImportError:
            raise VisualizerError(
                "Treemap requires the 'squarify' library. "
                "Install with: pip install squarify"
            )

        data = config['data']
        path_cols = config.get('path') or config.get('path_cols')
        value_col = config.get('value') or config.get('value_col')
        label_col = config.get('label')

        if path_cols is None:
            raise VisualizerError(
                "Treemap requires 'path' parameter specifying hierarchical column order "
                "(e.g., ['region', 'city'])"
            )

        if not isinstance(path_cols, (list, tuple)):
            path_cols = [path_cols]

        if value_col is None:
            raise VisualizerError("Treemap requires 'value' column for rectangle sizes")

        if value_col not in data.columns:
            raise VisualizerError(f"Value column '{value_col}' not found")

        # Aggregate by path
        group_cols = path_cols
        agg_data = data.groupby(group_cols)[value_col].sum().reset_index()

        # Create full path labels
        agg_data['_path'] = agg_data[path_cols].astype(str).agg(' / '.join, axis=1)

        # Prepare data for squarify
        sizes = agg_data[value_col].values
        labels = agg_data[label_col] if label_col else agg_data['_path']

        # Colors
        cmap = config.get('cmap', 'tab20c')
        if isinstance(cmap, str):
            cmap = self.mpl.cm.get_cmap(cmap)
        colors = [cmap(i / len(sizes)) for i in range(len(sizes))]

        # Create plot
        fig, ax = self._create_single_axes(config)
        ax.set_xticks([])
        ax.set_yticks([])

        # Normalize sizes to fill the axes
        squarify.plot(
            sizes=sizes,
            label=labels,
            color=colors,
            alpha=config.get('alpha', 0.8),
            ax=ax,
            **config.get('treemap_kwargs', {})
        )

        title = config.get('title') or 'Treemap'
        ax.set_title(title, fontsize=config.get('title_fontsize', 14))
        self.plt.tight_layout()

        return fig

    def network_plot(self, config: Dict[str, Any]) -> Any:
        """Create Network graph (nodes and edges)."""
        try:
            import networkx as nx
        except ImportError:
            raise VisualizerError(
                "Network graph requires 'networkx' library. "
                "Install with: pip install networkx"
            )

        data = config['data']
        source_col = config.get('source') or config.get('source_col')
        target_col = config.get('target') or config.get('target_col')
        weight_col = config.get('weight') or config.get('weight_col')

        # Network data can be edges list or adjacency matrix
        if source_col and target_col:
            # Edge list format
            G = nx.DiGraph() if config.get('directed', False) else nx.Graph()

            for _, row in data.iterrows():
                src = row[source_col]
                tgt = row[target_col]
                weight = row[weight_col] if weight_col and weight_col in data.columns else 1
                G.add_edge(src, tgt, weight=weight)
        else:
            # Assume data is already in a network format? Not supported
            raise VisualizerError(
                "Network plot requires 'source' and 'target' columns specifying edges. "
                "Use a DataFrame with source and target node identifiers."
            )

        # Create plot
        fig, ax = self._create_single_axes(config)
        ax.set_xticks([])
        ax.set_yticks([])

        # Layout
        layout_algo = config.get('layout', 'spring')
        layouts = {
            'spring': nx.spring_layout,
            'circular': nx.circular_layout,
            'kamada_kawai': nx.kamada_kawai_layout,
            'random': nx.random_layout,
            'shell': nx.shell_layout,
            'spectral': nx.spectral_layout
        }

        if layout_algo not in layouts:
            raise VisualizerError(f"Unknown layout: {layout_algo}. Choose from {list(layouts.keys())}")

        pos = layouts[layout_algo](G, seed=config.get('seed', 42))

        # Node properties
        node_size = config.get('node_size', 300)
        node_color = config.get('node_color', '#1f77b4')
        node_cmap = config.get('node_cmap', 'viridis')

        # Edge properties
        edge_color = config.get('edge_color', '#888888')
        edge_width = config.get('edge_width', 1)
        edge_alpha = config.get('edge_alpha', 0.6)

        # Draw nodes
        node_list = list(G.nodes())
        node_colors_list = [node_color] * len(node_list)
        if isinstance(node_color, str) and node_color in data.columns:
            # Use column for node colors
            node_colors_list = []
            for node in node_list:
                row = data[data[source_col] == node]
                if len(row) > 0:
                    node_colors_list.append(row[node_color].iloc[0])
                else:
                    node_colors_list.append(0)

        nx.draw_networkx_nodes(
            G, pos,
            ax=ax,
            node_size=node_size,
            node_color=node_colors_list,
            cmap=node_cmap,
            alpha=config.get('node_alpha', 0.9),
            linewidths=config.get('node_linewidth', 1),
            edgecolors=config.get('node_edgecolor', 'black')
        )

        # Draw edges
        nx.draw_networkx_edges(
            G, pos,
            ax=ax,
            edge_color=edge_color,
            width=edge_width,
            alpha=edge_alpha,
            arrowsize=config.get('arrow_size', 10) if isinstance(G, nx.DiGraph) else 0,
            arrowstyle=config.get('arrow_style', '-|>') if isinstance(G, nx.DiGraph) else None
        )

        # Draw labels
        if config.get('labels', True):
            nx.draw_networkx_labels(
                G, pos,
                ax=ax,
                font_size=config.get('label_fontsize', 9),
                font_color=config.get('label_color', 'black')
            )

        title = config.get('title') or 'Network Graph'
        ax.set_title(title, fontsize=config.get('title_fontsize', 14))
        ax.set_aspect('equal')
        self.plt.tight_layout()

        return fig

    def candlestick_plot(self, config: Dict[str, Any]) -> Any:
        """Create Candlestick chart (financial OHLC data)."""
        data = config['data']
        x_col = config.get('x') or config.get('date_col')
        open_col = config.get('open') or config.get('open_col', 'open')
        high_col = config.get('high') or config.get('high_col', 'high')
        low_col = config.get('low') or config.get('low_col', 'low')
        close_col = config.get('close') or config.get('close_col', 'close')
        volume_col = config.get('volume') or config.get('volume_col')

        # Validate required columns
        missing = [col for col in [open_col, high_col, low_col, close_col] if col not in data.columns]
        if missing:
            raise VisualizerError(f"Candlestick plot requires OHLC columns. Missing: {missing}")

        # Determine x-axis values for positions and labels
        if x_col is None:
            x_original = np.arange(len(data))
        else:
            if x_col in data.columns:
                x_original = data[x_col]
            elif hasattr(data, 'index') and x_col == data.index.name:
                x_original = data.index
            else:
                # Fallback to integer positions
                x_original = np.arange(len(data))

        # Convert to numeric for plotting; keep original for labels
        if hasattr(x_original, 'dtype') and np.issubdtype(x_original.dtype, np.datetime64):
            import matplotlib.dates as mdates
            x_numeric = mdates.date2num(x_original)
        else:
            x_numeric = np.asarray(x_original, dtype=float)

        x_labels = x_original

        # Get OHLC values as arrays
        open_vals = data[open_col].values
        high_vals = data[high_col].values
        low_vals = data[low_col].values
        close_vals = data[close_col].values

        # Styling
        color_up = config.get('color_up', 'green')
        color_down = config.get('color_down', 'red')
        width = config.get('width', 0.6)
        alpha = config.get('alpha', 0.8)

        fig, ax = self._create_single_axes(config)

        # Draw candles
        for i in range(len(data)):
            x = x_numeric[i]
            open_price = open_vals[i]
            close_price = close_vals[i]
            high_price = high_vals[i]
            low_price = low_vals[i]

            color = color_up if close_price >= open_price else color_down

            # Body rectangle
            body_bottom = min(open_price, close_price)
            body_height = abs(close_price - open_price)
            if body_height == 0:
                body_height = 0.01  # Minimal height for doji

            rect = self.mpl.patches.Rectangle(
                (x - width/2, body_bottom),
                width,
                body_height,
                facecolor=color,
                edgecolor=color,
                alpha=alpha,
                linewidth=1
            )
            ax.add_patch(rect)

            # Wick (high-low line)
            ax.plot([x, x], [low_price, high_price], color=color, linewidth=1, alpha=alpha)

        # Set x-ticks and labels
        ax.set_xticks(x_numeric)
        # Format labels as strings; handle datetime nicely
        try:
            if hasattr(x_labels, 'dt'):
                label_strs = x_labels.dt.strftime('%Y-%m-%d').tolist()
            elif hasattr(x_labels, 'strftime'):
                label_strs = x_labels.strftime('%Y-%m-%d').tolist()
            else:
                label_strs = [str(lbl) for lbl in x_labels]
        except Exception:
            label_strs = [str(lbl) for lbl in x_labels]
        ax.set_xticklabels(label_strs, rotation=45, ha='right')

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    # ==================== New Plot Types (Added) ====================

    def stacked_bar_plot(self, config: Dict[str, Any]) -> Any:
        """Create stacked bar chart."""
        data = config['data']
        x_col = config.get('x')
        y_cols = config.get('y')

        if y_cols is None:
            # Auto-select numeric columns
            y_cols = data.select_dtypes(include='number').columns.tolist()
        if isinstance(y_cols, str):
            y_cols = [y_cols]

        fig, ax = self._create_single_axes(config)

        # Prepare x positions
        if x_col:
            x_categories = data[x_col].tolist()
            x_numeric = range(len(x_categories))
        else:
            x_numeric = range(len(data))
            x_categories = None

        # Stack bars
        bottoms = np.zeros(len(data))
        for y_col in y_cols:
            values = data[y_col].values
            ax.bar(x_numeric, values, bottom=bottoms, label=y_col)
            bottoms += values

        if x_categories:
            ax.set_xticks(x_numeric)
            ax.set_xticklabels(x_categories, rotation=45, ha='right')

        self._apply_labels(ax, config)
        ax.legend()
        return fig

    def grouped_bar_plot(self, config: Dict[str, Any]) -> Any:
        """Create grouped bar chart (side-by-side)."""
        data = config['data']
        x_col = config.get('x')
        y_cols = config.get('y')

        if y_cols is None:
            y_cols = data.select_dtypes(include='number').columns.tolist()
        if isinstance(y_cols, str):
            y_cols = [y_cols]

        fig, ax = self._create_single_axes(config)

        # Prepare x positions
        if x_col:
            x_categories = data[x_col].tolist()
            x_numeric = np.arange(len(x_categories))
        else:
            x_numeric = np.arange(len(data))
            x_categories = None

        # Grouped bars
        n_groups = len(y_cols)
        width = 0.8 / n_groups

        for i, y_col in enumerate(y_cols):
            offset = (i - n_groups/2 + 0.5) * width
            ax.bar(x_numeric + offset, data[y_col].values,
                   width=width, label=y_col)

        if x_categories:
            ax.set_xticks(x_numeric)
            ax.set_xticklabels(x_categories, rotation=45, ha='right')

        self._apply_labels(ax, config)
        ax.legend()
        return fig

    def hexbin_plot(self, config: Dict[str, Any]) -> Any:
        """Create hexbin plot (2D histogram with hexagonal bins)."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        if y_col is None:
            raise VisualizerError("Hexbin plot requires 'y' parameter")

        fig, ax = self._create_single_axes(config)

        x_data = data[x_col].values
        y_data = data[y_col].values

        # Get hexbin parameters
        gridsize = config.get('gridsize', 50)
        bins = config.get('bins', 'log')
        mincnt = config.get('mincnt', None)
        cmap = config.get('cmap', 'viridis')
        alpha = config.get('alpha', 0.8)

        hb = ax.hexbin(x_data, y_data, gridsize=gridsize, bins=bins,
                       mincnt=mincnt, cmap=cmap, alpha=alpha)

        # Add colorbar
        cb = fig.colorbar(hb, ax=ax)
        cb.set_label('Counts')

        self._apply_labels(ax, config)
        return fig

    def step_plot(self, config: Dict[str, Any]) -> Any:
        """Create step plot (horizontal-vertical steps)."""
        data = config['data']
        x_col = config.get('x')
        y_cols = config.get('y')

        fig, ax = self._create_single_axes(config)

        if y_cols is None:
            # Plot all numeric columns
            numeric_cols = data.select_dtypes(include='number').columns
            y_cols = numeric_cols

        if isinstance(y_cols, str):
            y_cols = [y_cols]

        # Default step position: 'pre' (steps before x)
        where = config.get('where', 'pre')

        for y_col in y_cols:
            x_vals = data.index if x_col is None else data[x_col]
            ax.step(x_vals, data[y_col], where=where,
                    label=y_col, **config.get('step_kwargs', {}))

        self._apply_labels(ax, config)
        if len(y_cols) > 1:
            ax.legend()
        return fig

    def fill_between_plot(self, config: Dict[str, Any]) -> Any:
        """Create filled region between curves or around a line."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        y_lower = config.get('y_lower')  # lower bound
        y_upper = config.get('y_upper')  # upper bound

        # Require at least y, or both y_lower and y_upper
        if y_col is None and (y_lower is None or y_upper is None):
            raise VisualizerError("Fill between plot requires 'y' parameter or both 'y_lower' and 'y_upper'")

        fig, ax = self._create_single_axes(config)

        x_vals = data.index if x_col is None else data[x_col]

        # Determine y_vals if y exists
        if y_col is not None:
            y_vals = data[y_col].values
        else:
            y_vals = None

        # Case 1: Fill between two bounds (shaded region) - y optional
        if y_lower is not None and y_upper is not None:
            lower_vals = data[y_lower].values if isinstance(y_lower, str) else np.full_like(y_vals if y_vals is not None else data.index.values, y_lower)
            upper_vals = data[y_upper].values if isinstance(y_upper, str) else np.full_like(y_vals if y_vals is not None else data.index.values, y_upper)
            ax.fill_between(x_vals, lower_vals, upper_vals,
                            **config.get('fill_kwargs', {}))
        # Case 2: Fill between y and lower
        elif y_lower is not None and y_vals is not None:
            lower_vals = data[y_lower].values if isinstance(y_lower, str) else np.full_like(y_vals, y_lower)
            ax.fill_between(x_vals, lower_vals, y_vals,
                            **config.get('fill_kwargs', {}))
        # Case 3: Fill between y and upper
        elif y_upper is not None and y_vals is not None:
            upper_vals = data[y_upper].values if isinstance(y_upper, str) else np.full_like(y_vals, y_upper)
            ax.fill_between(x_vals, y_vals, upper_vals,
                            **config.get('fill_kwargs', {}))
        # Case 4: y exists but no bounds - fill to zero
        elif y_vals is not None:
            ax.fill_between(x_vals, y_vals, 0,
                            **config.get('fill_kwargs', {}))

        # Also plot the line if requested and y exists
        if y_vals is not None and config.get('show_line', True):
            ax.plot(x_vals, y_vals, **config.get('line_kwargs', {}))

        self._apply_labels(ax, config)
        return fig

    def contour_plot(self, config: Dict[str, Any]) -> Any:
        """Create 2D contour plot."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        z_col = config.get('z') or config.get('value')

        if y_col is None or z_col is None:
            raise VisualizerError("Contour plot requires 'x', 'y', and 'z' (or 'value') parameters")

        fig, ax = self._create_single_axes(config)

        # Need to pivot data to 2D grid if it's in long format
        x_data = data[x_col].values
        y_data = data[y_col].values
        z_data = data[z_col].values

        # Check if data is already gridded
        if len(np.unique(x_data)) * len(np.unique(y_data)) == len(data):
            # It's gridded, reshape Z
            xi = np.unique(x_data)
            yi = np.unique(y_data)
            X, Y = np.meshgrid(xi, yi)
            Z = z_data.reshape(len(yi), len(xi))
        else:
            # Use tricontour for unstructured data
            X, Y, Z = x_data, y_data, z_data

        # Plot contour lines
        filled = config.get('filled', False)
        if filled:
            cont = ax.contourf(X, Y, Z, levels=config.get('levels', 10),
                              cmap=config.get('cmap', 'viridis'), **config.get('contour_kwargs', {}))
            fig.colorbar(cont, ax=ax)
        else:
            cont = ax.contour(X, Y, Z, levels=config.get('levels', 10),
                              colors=config.get('colors', None), **config.get('contour_kwargs', {}))
            ax.clabel(cont, inline=True, fontsize=8)

        self._apply_labels(ax, config)
        return fig

    def pcolormesh_plot(self, config: Dict[str, Any]) -> Any:
        """Create pcolormesh plot (colored grid cells)."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        z_col = config.get('z') or config.get('value')

        if y_col is None or z_col is None:
            raise VisualizerError("Pcolormesh requires 'x', 'y', and 'z' (or 'value') parameters")

        fig, ax = self._create_single_axes(config)

        # Get coordinates and values
        x_data = data[x_col].values
        y_data = data[y_col].values
        C = data[z_col].values

        # Need to reshape if grid data
        if len(np.unique(x_data)) * len(np.unique(y_data)) == len(data):
            xi = np.unique(x_data)
            yi = np.unique(y_data)
            X, Y = np.meshgrid(xi, yi)
            Z = C.reshape(len(yi), len(xi))
        else:
            # For non-gridded data, use scatter or tricontour instead
            raise VisualizerError(
                "Pcolormesh requires gridded data. "
                "Provide data as a grid (use pivot_table or similar)."
            )

        # Plot pcolormesh
        pcm = ax.pcolormesh(X, Y, Z, cmap=config.get('cmap', 'viridis'),
                           shading=config.get('shading', 'auto'), **config.get('pcolormesh_kwargs', {}))

        fig.colorbar(pcm, ax=ax)
        self._apply_labels(ax, config)
        return fig

    def quiver_plot(self, config: Dict[str, Any]) -> Any:
        """Create 2D quiver plot (vector field arrows)."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        u_col = config.get('u')  # x-component
        v_col = config.get('v')  # y-component

        if any(col is None for col in [x_col, y_col, u_col, v_col]):
            raise VisualizerError("Quiver plot requires 'x', 'y', 'u', and 'v' parameters")

        fig, ax = self._create_single_axes(config)

        x_data = data[x_col].values
        y_data = data[y_col].values
        u_data = data[u_col].values
        v_data = data[v_col].values

        # Create quiver plot
        Q = ax.quiver(x_data, y_data, u_data, v_data,
                      **config.get('quiver_kwargs', {}))

        # Add key if needed
        if config.get('show_key', False):
            ax.quiverkey(Q, **config.get('quiverkey_kwargs', {}))

        self._apply_labels(ax, config)
        return fig

    def spy_plot(self, config: Dict[str, Any]) -> Any:
        """Create spy plot showing nonzero/True values in a matrix."""
        data = config['data']
        matrix_col = config.get('matrix') or config.get('z')

        if matrix_col is None:
            # Assume we're plotting the entire DataFrame as a matrix
            # Convert to boolean/sparse representation
            matrix = data.values
        else:
            # Use specific column as matrix (should be 2D array)
            matrix = data[matrix_col].values
            if matrix.ndim != 2:
                raise VisualizerError("Spy plot matrix must be 2-dimensional")

        fig, ax = self._create_single_axes(config)

        ax.spy(matrix, markersize=config.get('markersize', 5),
               **config.get('spy_kwargs', {}))

        self._apply_labels(ax, config)
        return fig

    def polar_plot(self, config: Dict[str, Any]) -> Any:
        """Create polar plot (radial coordinates)."""
        data = config['data']
        theta_col = config.get('theta') or config.get('x')  # angular coordinate
        r_col = config.get('r') or config.get('radius') or config.get('y')  # radial coordinate

        if r_col is None:
            raise VisualizerError("Polar plot requires 'r', 'radius', or 'y' parameter")

        fig, ax = self._create_polar_axes(config)

        theta_data = data[theta_col].values if theta_col else data.index.values
        r_data = data[r_col].values

        # Plot on polar axes
        ax.plot(theta_data, r_data, **config.get('polar_kwargs', {}))

        # Optional fill
        if config.get('fill', False):
            ax.fill(theta_data, r_data, alpha=config.get('alpha', 0.3))

        self._apply_labels(ax, config)
        return fig

    def table_plot(self, config: Dict[str, Any]) -> Any:
        """Create table from DataFrame."""
        data = config['data']

        fig, ax = self._create_single_axes(config)
        ax.axis('tight')
        ax.axis('off')

        # Prepare table data
        df_display = data.head(config.get('max_rows', 10))

        # Create table
        table = ax.table(cellText=df_display.values,
                        rowLabels=df_display.index if config.get('show_index', True) else None,
                        colLabels=df_display.columns,
                        loc='center',
                        cellLoc=config.get('cell_align', 'center'),
                        **config.get('table_kwargs', {}))

        table.auto_set_font_size(False)
        table.set_fontsize(config.get('fontsize', 10))
        scale_x, scale_y = config.get('scale', (1, 1.5))
        table.scale(scale_x, scale_y)

        # Optional title
        title = config.get('title')
        if title:
            ax.set_title(title)

        return fig

    def eventplot_plot(self, config: Dict[str, Any]) -> Any:
        """Create event plot (multiple event sequences)."""
        data = config['data']
        columns = config.get('y') or config.get('columns')

        if columns is None:
            # Use all numeric columns
            columns = data.select_dtypes(include='number').columns.tolist()
        if isinstance(columns, str):
            columns = [columns]

        fig, ax = self._create_single_axes(config)

        # Prepare event sequences: each column is a sequence
        sequences = []
        labels_list = []
        for col in columns:
            # Get positions where event occurs (nonzero or True)
            series = data[col].dropna()
            positions = series.index[series != 0].tolist()
            sequences.append(positions)
            labels_list.append(col)

        # Plot eventplot
        event_collections = ax.eventplot(sequences, **config.get('eventplot_kwargs', {}))

        # Set y-tick labels for each sequence (horizontal orientation default)
        # The default lineoffsets are range(len(sequences))
        if config.get('show_labels', True):
            ax.set_yticks(range(len(sequences)))
            ax.set_yticklabels(labels_list)

        self._apply_labels(ax, config)
        return fig

    # ============ Additional Plot Types (Waterfall, Gantt, OHLC+Volume) ============

    def waterfall_plot(self, config: Dict[str, Any]) -> Any:
        """Create waterfall chart showing cumulative effect of sequential values."""
        data = config['data']
        x_col = config.get('x') or config.get('category')
        y_col = config.get('y') or config.get('value')

        if x_col is None or y_col is None:
            raise VisualizerError("Waterfall plot requires 'x' (category) and 'y' (value) parameters")

        fig, ax = self._create_single_axes(config)

        categories = data[x_col].tolist()
        values = data[y_col].values
        n = len(values)

        # Calculate cumulative sum
        cumsum = np.zeros(n + 1)
        cumsum[1:] = np.cumsum(values)

        # Determine bar colors: positive (blue), negative (red), first bar (green)
        colors = []
        for val in values:
            if val > 0:
                colors.append('#2196F3')  # Positive - blue
            elif val < 0:
                colors.append('#F44336')  # Negative - red
            else:
                colors.append('#9E9E9E')  # Zero - gray

        # Plot the change bars (one for each category)
        bar_positions = np.arange(n)
        heights = values
        bottoms = cumsum[:-1]  # starting cumulative before each change

        bars = ax.bar(bar_positions, heights, bottom=bottoms, color=colors,
                     edgecolor='black', linewidth=1)

        # Add value labels on bars
        for i, (bar, val) in enumerate(zip(bars, values)):
            y_pos = cumsum[i] + val / 2 if val != 0 else cumsum[i]
            ax.text(bar.get_x() + bar.get_width()/2, y_pos,
                   f'{val:+.0f}' if isinstance(val, (int, np.integer)) else f'{val:+.2f}',
                   ha='center', va='center', fontsize=9, color='white' if abs(val) > 5 else 'black')

        # Add total line/annotation at the end
        total = cumsum[-1]
        ax.axhline(y=total, color='#4CAF50', linestyle='--', linewidth=1.5, alpha=0.7)
        ax.text(n + 0.5, total, f'Total: {total:+.0f}',
               va='center' if total == 0 else ('bottom' if total > 0 else 'top'),
               fontsize=10, weight='bold', color='#4CAF50')

        # Customize x-axis labels
        ax.set_xticks(bar_positions)
        ax.set_xticklabels(categories, rotation=45, ha='right')

        # Add horizontal grid lines
        ax.grid(True, axis='y', alpha=0.3)
        ax.set_axisbelow(True)

        self._apply_labels(ax, config)
        if not config.get('ylabel'):
            ax.set_ylabel('Value')
        return fig

    def gantt_plot(self, config: Dict[str, Any]) -> Any:
        """Create Gantt chart for project/task timelines."""
        data = config['data']
        task_col = config.get('task') or config.get('x')
        start_col = config.get('start')
        end_col = config.get('end') or config.get('finish')
        duration_col = config.get('duration')  # optional: if duration instead of end date

        if task_col is None or start_col is None:
            raise VisualizerError("Gantt plot requires 'task' and 'start' parameters")

        if end_col is None and duration_col is None:
            raise VisualizerError("Gantt plot requires either 'end' or 'duration' parameter")

        fig, ax = self._create_single_axes(config)

        tasks = data[task_col].tolist()
        n_tasks = len(tasks)
        y_positions = np.arange(n_tasks)[::-1]  # Reverse so first task on top

        # Parse start times
        start_vals = pd.to_datetime(data[start_col]) if not pd.api.types.is_datetime64_any_dtype(data[start_col]) else data[start_col]

        # Calculate end times
        if end_col:
            end_vals = pd.to_datetime(data[end_col]) if not pd.api.types.is_datetime64_any_dtype(data[end_col]) else data[end_col]
            durations = (end_vals - start_vals).dt.total_seconds() / (24*3600)  # days
        else:
            durations = data[duration_col].values
            end_vals = start_vals + pd.to_timedelta(durations, unit='D')

        # Convert dates to numeric for plotting
        if pd.api.types.is_datetime64_any_dtype(start_vals):
            start_numeric = start_vals.map(pd.Timestamp.toordinal).values
            end_numeric = (start_vals + pd.to_timedelta(durations, unit='D')).map(pd.Timestamp.toordinal).values
        else:
            # Assume already numeric (e.g., day numbers)
            start_numeric = start_vals.values if isinstance(start_vals, pd.Series) else start_vals
            end_numeric = start_numeric + durations

        # Plot horizontal bars
        colors = data.get('color', None)
        if colors is not None:
            color_vals = data[colors].tolist()
        else:
            color_vals = ['#2196F3'] * n_tasks

        ax.barh(y_positions, end_numeric - start_numeric, left=start_numeric,
                height=0.6, color=color_vals, edgecolor='black', linewidth=0.5)

        # Customize y-axis: show task names
        ax.set_yticks(y_positions)
        ax.set_yticklabels(tasks)

        # Format x-axis as dates if using datetime
        if pd.api.types.is_datetime64_any_dtype(start_vals):
            self._format_date_axis(ax, start_vals.min(), end_vals.max())
        else:
            ax.set_xlabel('Time / Days')

        # Add grid
        ax.grid(True, axis='x', alpha=0.3)
        ax.set_axisbelow(True)

        self._apply_labels(ax, config)
        if not config.get('xlabel'):
            ax.set_xlabel('Timeline')

        # Invert y-axis so first task appears at top
        ax.invert_yaxis()
        return fig

    def ohlc_volume_plot(self, config: Dict[str, Any]) -> Any:
        """Create OHLC candlestick chart with volume bars."""
        data = config['data']
        x_col = config.get('x') or config.get('date')  # optional, can use index
        open_col = config.get('open')
        high_col = config.get('high')
        low_col = config.get('low')
        close_col = config.get('close')
        volume_col = config.get('volume')

        if not all([open_col, high_col, low_col, close_col, volume_col]):
            missing = []
            if not open_col: missing.append('open')
            if not high_col: missing.append('high')
            if not low_col: missing.append('low')
            if not close_col: missing.append('close')
            if not volume_col: missing.append('volume')
            raise VisualizerError(f"OHLC+Volume plot requires: {', '.join(missing)}")

        fig = self.plt.figure(figsize=config.get('figsize', (12, 8)))

        # Create two subplots: top for candlestick, bottom for volume
        ax_price = self.plt.subplot2grid((4, 1), (0, 0), rowspan=3, fig=fig)
        ax_volume = self.plt.subplot2grid((4, 1), (3, 0), rowspan=1, fig=fig, sharex=ax_price)

        # Prepare data
        if x_col is not None:
            dates_series = pd.to_datetime(data[x_col]) if not pd.api.types.is_datetime64_any_dtype(data[x_col]) else data[x_col]
        else:
            # Use index as x-axis (integer positions)
            dates_series = pd.Series(np.arange(len(data)))

        opens = data[open_col].values
        highs = data[high_col].values
        lows = data[low_col].values
        closes = data[close_col].values
        volumes = data[volume_col].values

        # Determine colors for candlesticks
        colors_up = ['#26A69A' if close >= open else '#EF5350' for open, close in zip(opens, closes)]
        colors_down = ['#EF5350' if close < open else '#26A69A' for open, close in zip(opens, closes)]

        # Plot candlesticks manually (matplotlib doesn't have built-in candlestick)
        width = 0.6
        x_indices = np.arange(len(dates_series))

        # Up days (close >= open)
        up_mask = closes >= opens
        if np.any(up_mask):
            ax_price.bar(x_indices[up_mask], closes[up_mask] - opens[up_mask],
                        bottom=opens[up_mask], width=width, color='#26A69A',
                        edgecolor='black', linewidth=0.5)
            # Plot wicks
            for idx in x_indices[up_mask]:
                ax_price.plot([idx, idx], [lows[idx], highs[idx]], color='black', linewidth=1)

        # Down days (close < open)
        down_mask = ~up_mask
        if np.any(down_mask):
            ax_price.bar(x_indices[down_mask], opens[down_mask] - closes[down_mask],
                        bottom=closes[down_mask], width=width, color='#EF5350',
                        edgecolor='black', linewidth=0.5)
            # Plot wicks
            for idx in x_indices[down_mask]:
                ax_price.plot([idx, idx], [lows[idx], highs[idx]], color='black', linewidth=1)

        ax_price.set_ylabel('Price')
        ax_price.grid(True, alpha=0.3)
        ax_price.set_axisbelow(True)

        # Plot volume bars
        volume_colors = ['#26A69A' if close >= open else '#EF5350' for close, open in zip(closes, opens)]
        ax_volume.bar(x_indices, volumes, color=volume_colors, alpha=0.6, edgecolor='none')
        ax_volume.set_ylabel('Volume')
        ax_volume.grid(True, alpha=0.3)
        ax_volume.set_axisbelow(True)

        # Format x-axis
        if pd.api.types.is_datetime64_any_dtype(dates_series):
            self._format_date_axis(ax_volume, dates_series.min(), dates_series.max())
            # Rotate labels
            self.plt.setp(ax_volume.xaxis.get_majorticklabels(), rotation=45, ha='right')
        else:
            ax_volume.set_xlabel('Index')
            ax_price.set_xticks(x_indices[::max(1, len(x_indices)//10)])
            ax_volume.set_xticks(x_indices[::max(1, len(x_indices)//10)])
            ax_volume.set_xticklabels(x_indices[::max(1, len(x_indices)//10)])

        # Title
        title = config.get('title', 'OHLC with Volume')
        ax_price.set_title(title)

        # Adjust layout
        fig.tight_layout()
        return fig

    def _format_date_axis(self, ax, start_date, end_date):
        """Helper to format x-axis with dates."""
        import matplotlib.dates as mdates
        ax.xaxis.set_major_locator(mdates.AutoDateLocator())
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        ax.figure.autofmt_xdate()  # Rotate and align

    # ============ Geospatial & Map Visualizations ============

    def choropleth_plot(self, config: Dict[str, Any]) -> Any:
        """Create choropleth map (regions colored by data values)."""
        try:
            import geopandas as gpd
        except ImportError:
            raise VisualizerError(
                "Choropleth plot requires 'geopandas' library. "
                "Install with: pip install geopandas"
            )

        data = config['data']
        geometry_col = config.get('geometry') or config.get('shape')
        value_col = config.get('value') or config.get('color')

        if geometry_col is None or value_col is None:
            raise VisualizerError("Choropleth requires 'geometry' (or 'shape') and 'value' (or 'color') columns")

        fig, ax = self._create_single_axes(config)

        # If data is already a GeoDataFrame
        if isinstance(data, gpd.GeoDataFrame):
            gdf = data
        else:
            # Expect GeoJSON-like geometry column with shapely geometries
            gdf = gpd.GeoDataFrame(data, geometry=geometry_col)

        # Plot choropleth
        gdf.plot(column=value_col, ax=ax, legend=True, cmap=config.get('cmap', 'viridis'),
                 edgecolor=config.get('edgecolor', 'black'), linewidth=config.get('linewidth', 0.5),
                 **config.get('choropleth_kwargs', {}))

        ax.set_axis_off()
        self._apply_labels(ax, config)
        return fig

    def scatter_geo_plot(self, config: Dict[str, Any]) -> Any:
        """Create scatter plot on geographic coordinates (scatter_geo)."""
        try:
            import geopandas as gpd
            from shapely.geometry import Point
        except ImportError:
            raise VisualizerError(
                "Scatter_geo plot requires 'geopandas' and 'shapely' libraries. "
                "Install with: pip install geopandas shapely"
            )

        data = config['data']
        lat_col = config.get('lat') or config.get('latitude')
        lon_col = config.get('lon') or config.get('longitude') or config.get('long')
        value_col = config.get('value') or config.get('size')

        if lat_col is None or lon_col is None:
            raise VisualizerError("Scatter_geo requires 'lat' and 'lon' (or 'latitude' and 'longitude') columns")

        fig, ax = self._create_single_axes(config)

        # Create Point geometries
        geometry = [Point(xy) for xy in zip(data[lon_col], data[lat_col])]
        gdf = gpd.GeoDataFrame(data, geometry=geometry)

        # Set coordinate reference system (CRS) if provided
        crs = config.get('crs', 'EPSG:4326')  # Default to WGS84
        gdf.crs = crs

        # Plot points
        if value_col:
            # Color/size by value
            gdf.plot(ax=ax, column=value_col, legend=True, cmap=config.get('cmap', 'plasma'),
                     markersize=config.get('markersize', 50), alpha=config.get('alpha', 0.7),
                     **config.get('scatter_geo_kwargs', {}))
        else:
            gdf.plot(ax=ax, color=config.get('color', '#2196F3'), markersize=config.get('markersize', 50),
                     alpha=config.get('alpha', 0.7), **config.get('scatter_geo_kwargs', {}))

        ax.set_axis_off()
        self._apply_labels(ax, config)
        return fig

    def flow_map_plot(self, config: Dict[str, Any]) -> Any:
        """Create flow map (lines showing movement/flows between locations)."""
        try:
            import geopandas as gpd
            from shapely.geometry import LineString
        except ImportError:
            raise VisualizerError(
                "Flow map requires 'geopandas' and 'shapely' libraries. "
                "Install with: pip install geopandas shapely"
            )

        data = config['data']
        # Expect either origin/destination coordinates or flow lines
        origin_lat = config.get('origin_lat') or config.get('from_lat')
        origin_lon = config.get('origin_lon') or config.get('from_lon')
        dest_lat = config.get('dest_lat') or config.get('to_lat')
        dest_lon = config.get('dest_lon') or config.get('to_lon')
        flow_col = config.get('flow') or config.get('value')

        if origin_lat is None or origin_lon is None or dest_lat is None or dest_lon is None:
            raise VisualizerError(
                "Flow map requires origin and destination coordinates: "
                "'origin_lat', 'origin_lon', 'dest_lat', 'dest_lon'"
            )

        fig, ax = self._create_single_axes(config)

        # Create LineString geometries for each flow
        geometries = []
        for _, row in data.iterrows():
            line = LineString([(row[origin_lon], row[origin_lat]), (row[dest_lon], row[dest_lat])])
            geometries.append(line)

        gdf = gpd.GeoDataFrame(data, geometry=geometries)

        # Line width based on flow value if provided
        if flow_col:
            flows = data[flow_col].values
            min_flow, max_flow = flows.min(), flows.max()
            if max_flow > min_flow:
                linewidths = 1 + 4 * (flows - min_flow) / (max_flow - min_flow)
            else:
                linewidths = 2
            # Plot with varying linewidths
            for i, (geom, lw) in enumerate(zip(gdf.geometry, linewidths)):
                gdf.iloc[[i]].plot(ax=ax, color=config.get('color', '#2196F3'), linewidth=lw,
                                  alpha=config.get('alpha', 0.6))
        else:
            gdf.plot(ax=ax, color=config.get('color', '#2196F3'), linewidth=2, alpha=0.6)

        ax.set_axis_off()
        self._apply_labels(ax, config)
        return fig

    def tile_map_plot(self, config: Dict[str, Any]) -> Any:
        """Create tile map (basemap with contextily)."""
        try:
            import contextily as ctx
            import geopandas as gpd
        except ImportError:
            raise VisualizerError(
                "Tile map requires 'contextily' and 'geopandas' libraries. "
                "Install with: pip install contextily geopandas"
            )

        data = config['data']
        geometry_col = config.get('geometry') or config.get('shape')
        value_col = config.get('value') or config.get('color')

        fig, ax = self._create_single_axes(config)

        if isinstance(data, gpd.GeoDataFrame):
            gdf = data
        else:
            gdf = gpd.GeoDataFrame(data, geometry=geometry_col)

        # Set CRS if not already set
        if gdf.crs is None:
            gdf.crs = 'EPSG:4326'  # WGS84

        # Reproject to Web Mercator for contextily
        gdf_mercator = gdf.to_crs(epsg=3857)

        # Plot the data
        if value_col:
            gdf_mercator.plot(column=value_col, ax=ax, legend=True, cmap=config.get('cmap', 'viridis'),
                             alpha=config.get('alpha', 0.7), **config.get('tile_kwargs', {}))
        else:
            gdf_mercator.plot(ax=ax, color=config.get('color', '#2196F3'), alpha=config.get('alpha', 0.7))

        # Add basemap tiles
        try:
            ctx.add_basemap(ax, source=config.get('tile_source', ctx.providers.OpenStreetMap.Mapnik))
        except Exception:
            # If contextily fails (no network, etc.), just show the data without tiles
            pass

        ax.set_axis_off()
        self._apply_labels(ax, config)
        return fig

    def cartogram_plot(self, config: Dict[str, Any]) -> Any:
        """Create cartogram (geographic areas distorted by data value)."""
        try:
            import geopandas as gpd
        except ImportError:
            raise VisualizerError(
                "Cartogram requires 'geopandas' library. "
                "Install with: pip install geopandas"
            )

        data = config['data']
        geometry_col = config.get('geometry') or config.get('shape')
        value_col = config.get('value') or config.get('size')

        if geometry_col is None or value_col is None:
            raise VisualizerError("Cartogram requires 'geometry' (or 'shape') and 'value' (or 'size') columns")

        fig, ax = self._create_single_axes(config)

        if isinstance(data, gpd.GeoDataFrame):
            gdf = data
        else:
            gdf = gpd.GeoDataFrame(data, geometry=geometry_col)

        # Simple non-contiguous cartogram: scale each polygon proportionally around its centroid
        values = gdf[value_col].values
        min_val, max_val = values.min(), values.max()
        if max_val == min_val:
            scale_factors = np.ones(len(gdf))
        else:
            scale_factors = 0.5 + 0.5 * (values - min_val) / (max_val - min_val)  # Scale between 0.5 and 1.0

        # Scale each geometry around its centroid
        from shapely.geometry import Polygon
        scaled_geometries = []
        for i, (idx, row) in enumerate(gdf.iterrows()):
            geom = row.geometry
            sf = scale_factors[i]  # Use enumerate index instead of DataFrame index
            if geom.geom_type == 'Polygon':
                centroid = geom.centroid
                coords = []
                for x, y in geom.exterior.coords:
                    new_x = centroid.x + (x - centroid.x) * sf
                    new_y = centroid.y + (y - centroid.y) * sf
                    coords.append((new_x, new_y))
                scaled_geom = Polygon(coords)
                scaled_geometries.append(scaled_geom)
            else:
                scaled_geometries.append(geom)

        gdf_scaled = gdf.copy()
        gdf_scaled.geometry = scaled_geometries

        # Plot cartogram
        gdf_scaled.plot(ax=ax, color=config.get('color', '#2196F3'), edgecolor='black', linewidth=0.5,
                       alpha=config.get('alpha', 0.8), **config.get('cartogram_kwargs', {}))

        ax.set_axis_off()
        self._apply_labels(ax, config)
        return fig


    def _create_polar_axes(self, config: Dict[str, Any]):
        """Helper to create polar axes."""
        figsize = config.get('figsize', (8, 8))
        fig = self.plt.figure(figsize=figsize)
        ax = fig.add_subplot(111, projection='polar')

        # Set window title
        window_title = self._generate_window_title(config)
        try:
            if hasattr(fig.canvas, 'manager') and fig.canvas.manager:
                fig.canvas.manager.set_window_title(window_title)
            elif hasattr(fig.canvas, 'set_window_title'):
                fig.canvas.set_window_title(window_title)
        except Exception:
            pass

        return fig, ax

    # ========== New Plot Types (v0.2.3) ==========

    def subplots_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create a figure with multiple subplots sharing axes.

        This is a convenience wrapper around plt.subplots() that creates
        a grid of subplots with optional shared x/y axes.

        Parameters
        ----------
        config : dict
            - n_rows : int (default 2)
            - n_cols : int (default 2)
            - sharex : bool (default False)
            - sharey : bool (default False)
            - figsize : tuple (default (12, 8))
            - title : str (overall figure title)

        Returns
        -------
        fig, axes : tuple
            matplotlib figure and array of axes
        """
        n_rows = config.get('n_rows', 2)
        n_cols = config.get('n_cols', 2)
        sharex = config.get('sharex', False)
        sharey = config.get('sharey', False)

        fig, axes = self.plt.subplots(
            n_rows, n_cols,
            sharex=sharex,
            sharey=sharey,
            figsize=config.get('figsize', (12, 8))
        )

        # If single subplot, axes is not an array
        if n_rows == 1 and n_cols == 1:
            axes = np.array([[axes]])
        elif n_rows == 1:
            axes = axes.reshape(1, -1)
        elif n_cols == 1:
            axes = axes.reshape(-1, 1)

        # Set overall title
        title = config.get('title')
        if title:
            fig.suptitle(title, fontsize=14, y=1.02)

        self.plt.tight_layout()
        return fig, axes

    def inset_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create an inset axes within a main plot.

        Allows zooming into a region or creating a small additional plot
        inside the main figure.

        Parameters
        ----------
        config : dict
            - parent_axes : matplotlib.axes (optional, creates main if not provided)
            - inset_bounds : tuple (left, bottom, width, height) in figure coords
            - xlim : tuple (optional) limits for inset x-axis
            - ylim : tuple (optional) limits for inset y-axis
            - title : str (optional inset title)
            - **kwargs : passed to parent plot creation

        Returns
        -------
        tuple
            (fig, parent_axes, inset_ax) - always returns three values
        """
        from mpl_toolkits.axes_grid1.inset_locator import inset_axes

        # Get or create parent figure/axes
        parent_axes = config.get('parent_axes')
        if parent_axes is None:
            # Create main figure first
            fig, main_ax = self._create_single_axes(config)
            parent_axes = main_ax
            created_parent = True
        else:
            fig = parent_axes.get_figure()
            created_parent = False

        # Inset bounds (left, bottom, width, height) in figure coordinates (0-1)
        inset_bounds = config.get('inset_bounds', (0.6, 0.6, 0.35, 0.35))

        # Create inset axes
        inset_ax = inset_axes(parent_axes, width=f"{inset_bounds[2]*100}%",
                             height=f"{inset_bounds[3]*100}%",
                             loc=config.get('loc', 'upper right'),
                             borderpad=config.get('borderpad', 1))

        # Apply limits if provided
        xlim = config.get('xlim')
        ylim = config.get('ylim')
        if xlim:
            inset_ax.set_xlim(xlim)
        if ylim:
            inset_ax.set_ylim(ylim)

        # Title for inset
        inset_title = config.get('title')
        if inset_title:
            inset_ax.set_title(inset_title, fontsize=10)

        # Always return tuple (fig, parent_axes, inset_ax) for consistency
        return fig, parent_axes, inset_ax

    def annotated_heatmap_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create a heatmap with text annotations in each cell.

        Useful for confusion matrices, correlation matrices with values,
        or any grid where you want to display the numeric values.

        Parameters
        ----------
        config : dict
            - data : DataFrame (pivoted format) or takes pivot from matrix
            - pivot : bool (if True, pivot from long format)
            - index, columns, values : for pivot
            - annot : bool (default True) show annotations
            - fmt : str (default '.2f') annotation format
            - cmap : str (default 'viridis')
            - colorbar : bool (default True)
            - **kwargs : additional imshow args

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']

        if config.get('pivot'):
            pivot_data = data.pivot_table(
                index=config.get('index'),
                columns=config.get('columns'),
                values=config.get('values')
            )
        else:
            pivot_data = data

        fig, ax = self._create_single_axes(config)

        # Create heatmap
        im = ax.imshow(pivot_data, cmap=config.get('cmap', 'viridis'),
                      aspect='auto', **config.get('heatmap_kwargs', {}))

        # Add colorbar
        if config.get('colorbar', True):
            self.plt.colorbar(im, ax=ax)

        # Add text annotations
        if config.get('annot', True):
            fmt = config.get('fmt', '.2f')
            for i in range(len(pivot_data)):
                for j in range(len(pivot_data.columns)):
                    val = pivot_data.iloc[i, j]
                    # Choose text color based on background brightness
                    norm = im.norm(val)
                    rgb = im.cmap(norm(val))[:3]
                    brightness = sum(rgb) / 3
                    text_color = 'white' if brightness < 0.5 else 'black'
                    ax.text(j, i, f"{val:{fmt}}", ha='center', va='center',
                           color=text_color, fontsize=config.get('annot_fontsize', 10))

        # Set labels
        if config.get('pivot'):
            ax.set_xticks(range(len(pivot_data.columns)))
            ax.set_yticks(range(len(pivot_data.index)))
            ax.set_xticklabels(pivot_data.columns, rotation=45, ha='right')
            ax.set_yticklabels(pivot_data.index)
        else:
            ax.set_xticks(range(len(pivot_data.columns)))
            ax.set_yticks(range(len(pivot_data)))
            ax.set_xticklabels(pivot_data.columns, rotation=45, ha='right')
            ax.set_yticklabels(pivot_data.index if hasattr(pivot_data, 'index') else range(len(pivot_data)))

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def streamplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create a 2D vector field streamplot (flow lines).

        Shows the direction of flow at each point in a 2D grid.

        Parameters
        ----------
        config : dict
            - x, y : 1D arrays (grid coordinates)
            - u, v : 2D arrays (vector components)
            - density : float (default 1)
            - linewidth : float or array
            - color : str or array
            - cmap : str
            - arrowsize : float
            - **kwargs : additional streamplot options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        u_col = config.get('u')
        v_col = config.get('v')

        if not all([x_col, y_col, u_col, v_col]):
            raise VisualizerError("Streamplot requires 'x', 'y', 'u', and 'v' parameters")

        # Extract data arrays (may be 1D or 2D)
        x = data[x_col].values if hasattr(data, x_col) else data[x_col]
        y = data[y_col].values if hasattr(data, y_col) else data[y_col]
        u = data[u_col].values if hasattr(data, u_col) else data[u_col]
        v = data[v_col].values if hasattr(data, v_col) else data[v_col]

        # Check if data is in long (flattened) format: u and v are 1D
        if u.ndim == 1 and v.ndim == 1:
            # Reconstruct 2D grid by pivoting
            temp_df = pd.DataFrame({
                'x': x,
                'y': y,
                'u': u,
                'v': v
            })
            # Also handle color if provided as a column name
            color_col = config.get('color')
            color_array = None
            if isinstance(color_col, str) and color_col in data.columns:
                temp_df['color_val'] = data[color_col].values

            # Pivot to 2D arrays with y as index, x as columns
            u_pivot = temp_df.pivot(index='y', columns='x', values='u')
            v_pivot = temp_df.pivot(index='y', columns='x', values='v')

            # Get sorted unique coordinates
            x_sorted = np.sort(u_pivot.columns.values)
            y_sorted = np.sort(u_pivot.index.values)

            # Reindex to ensure consistent order and convert to numpy arrays
            u_2d = u_pivot.reindex(index=y_sorted, columns=x_sorted).values
            v_2d = v_pivot.reindex(index=y_sorted, columns=x_sorted).values

            x = x_sorted
            y = y_sorted
            u = u_2d
            v = v_2d

            # If color was a column, pivot it as well
            if isinstance(color_col, str) and color_col in data.columns:
                color_pivot = temp_df.pivot(index='y', columns='x', values='color_val')
                color_array = color_pivot.reindex(index=y_sorted, columns=x_sorted).values
                color_for_streamplot = color_array
            else:
                color_array = None
                color_for_streamplot = color_col if color_col is not None else 'k'
        else:
            # Ensure x and y are 1D vectors (grid coordinates)
            if x.ndim > 1:
                x = x[0, :] if x.shape[0] == 1 else x[:, 0]
            if y.ndim > 1:
                y = y[0, :] if y.shape[0] == 1 else y[:, 0]
            # Handle color mapping if it's a column name
            color_config = config.get('color', 'k')
            if isinstance(color_config, str) and hasattr(data, 'columns') and color_config in data.columns:
                color_array = data[color_config].values
                color_for_streamplot = color_array
            else:
                color_array = None
                color_for_streamplot = color_config

        # Create figure and axes
        fig, ax = self._create_single_axes(config)

        # Create streamplot
        strm = ax.streamplot(
            x, y, u, v,
            density=config.get('density', 1),
            linewidth=config.get('linewidth', 1),
            color=color_for_streamplot,
            cmap=config.get('cmap', 'viridis'),
            arrowsize=config.get('arrowsize', 1),
            arrowstyle=config.get('arrowstyle', '-|>'),
            **config.get('streamplot_kwargs', {})
        )

        # Add colorbar if we used a color array (mapped colors)
        if color_array is not None:
            fig.colorbar(strm.lines, ax=ax)

        ax.set_xlabel(x_col if isinstance(x_col, str) else 'X')
        ax.set_ylabel(y_col if isinstance(y_col, str) else 'Y')
        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def tricontour_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create contour lines on an unstructured triangular grid.

        Use when data points are scattered (not on a regular grid).
        Matplotlib automatically triangulates the points.

        Parameters
        ----------
        config : dict
            - x, y, z : column names for coordinates and values
            - levels : int or array-like (default 15)
            - cmap : str (default 'viridis')
            - linewidths : float
            - linestyles : str
            - **kwargs : additional contour options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        z_col = config.get('z')

        if not all([x_col, y_col, z_col]):
            raise VisualizerError("Tricontour plot requires 'x', 'y', and 'z' parameters")

        x = data[x_col].values
        y = data[y_col].values
        z = data[z_col].values

        fig, ax = self._create_single_axes(config)

        # Create tricontour
        contours = ax.tricontour(
            x, y, z,
            levels=config.get('levels', 15),
            linewidths=config.get('linewidths', 1),
            linestyles=config.get('linestyles', 'solid'),
            cmap=config.get('cmap', 'viridis'),
            **config.get('tricontour_kwargs', {})
        )

        # Add colorbar
        if config.get('colorbar', True):
            fig.colorbar(contours, ax=ax, label=z_col)

        ax.set_xlabel(x_col)
        ax.set_ylabel(y_col)
        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def tricontourf_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create filled contour plot on an unstructured triangular grid.

        Similar to tricontour but with filled polygons.

        Parameters
        ----------
        config : dict
            - x, y, z : column names for coordinates and values
            - levels : int or array-like (default 15)
            - cmap : str (default 'viridis')
            - **kwargs : additional contourf options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        z_col = config.get('z')

        if not all([x_col, y_col, z_col]):
            raise VisualizerError("Tricontourf plot requires 'x', 'y', and 'z' parameters")

        x = data[x_col].values
        y = data[y_col].values
        z = data[z_col].values

        fig, ax = self._create_single_axes(config)

        # Create filled tricontour
        contours = ax.tricontourf(
            x, y, z,
            levels=config.get('levels', 15),
            cmap=config.get('cmap', 'viridis'),
            **config.get('tricontourf_kwargs', {})
        )

        # Add colorbar
        if config.get('colorbar', True):
            fig.colorbar(contours, ax=ax, label=z_col)

        ax.set_xlabel(x_col)
        ax.set_ylabel(y_col)
        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    # ========== Statistical & Seaborn-style Plots ==========

    def rug_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create rug plot (marginal tick marks showing distribution).

        Parameters
        ----------
        config : dict
            - x or y : column name for data
            - height : float (default 0.05) - height of rug lines as fraction of axis
            - **kwargs : additional plot options (color, alpha, linewidth)

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        if x_col is None and y_col is None:
            raise VisualizerError("Rug plot requires 'x' or 'y' parameter")

        fig, ax = self._create_single_axes(config)

        color = config.get('color', 'black')
        alpha = config.get('alpha', 0.5)
        linewidth = config.get('linewidth', 1.0)

        if x_col is not None:
            x_vals = data[x_col].dropna().values
            if len(x_vals) > 0:
                # Determine y limits for rug height
                y_min, y_max = ax.get_ylim()
                rug_height = (y_max - y_min) * config.get('height', 0.05)
                y_base = y_min
                ax.vlines(x_vals, y_base, y_base + rug_height, color=color, alpha=alpha, linewidth=linewidth)
            ax.set_xlabel(x_col)

        if y_col is not None:
            y_vals = data[y_col].dropna().values
            if len(y_vals) > 0:
                x_min, x_max = ax.get_xlim()
                rug_height = (x_max - x_min) * config.get('height', 0.05)
                x_base = x_min
                ax.hlines(y_vals, x_base, x_base + rug_height, color=color, alpha=alpha, linewidth=linewidth)
            ax.set_ylabel(y_col)

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def strip_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create strip plot (jittered categorical scatter).

        Parameters
        ----------
        config : dict
            - x : categorical column name
            - y : numeric column name
            - jitter : float (default 0.2) - amount of jitter to avoid overlap
            - **kwargs : additional scatter options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        if not all([x_col, y_col]):
            raise VisualizerError("Strip plot requires 'x' and 'y' parameters")

        if x_col not in data.columns or y_col not in data.columns:
            raise VisualizerError(f"Columns not found: {x_col} or {y_col}")

        fig, ax = self._create_single_axes(config)

        x_data = data[x_col].values
        y_data = data[y_col].values

        # Add jitter to x positions
        categories = np.unique(x_data)
        x_jittered = []
        y_jittered = []
        jitter_width = config.get('jitter', 0.2)

        for i, cat in enumerate(categories):
            mask = x_data == cat
            y_cat = y_data[mask]
            n = len(y_cat)
            jitter = np.random.uniform(-jitter_width, jitter_width, n)
            x_jittered.extend([i + j for j in jitter])
            y_jittered.extend(y_cat)

        ax.scatter(x_jittered, y_jittered, **config.get('scatter_kwargs', {}))

        # Set x ticks to category positions
        ax.set_xticks(range(len(categories)))
        ax.set_xticklabels(categories)
        ax.set_xlabel(x_col)
        ax.set_ylabel(y_col)

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def swarm_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create swarm plot (non-overlapping categorical scatter).

        Parameters
        ----------
        config : dict
            - x : categorical column name
            - y : numeric column name
            - **kwargs : additional scatter options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        if not all([x_col, y_col]):
            raise VisualizerError("Swarm plot requires 'x' and 'y' parameters")

        if x_col not in data.columns or y_col not in data.columns:
            raise VisualizerError(f"Columns not found: {x_col} or {y_col}")

        fig, ax = self._create_single_axes(config)

        x_data = data[x_col].values
        y_data = data[y_col].values

        # Get unique categories and positions
        categories = np.unique(x_data)
        positions = range(len(categories))

        # For each category, position points to avoid overlap
        point_size = config.get('point_size', 20)  # used for overlap calculation
        # Approximate swarm using sorted y positions with horizontal adjustment
        for pos, cat in zip(positions, categories):
            mask = x_data == cat
            y_vals = np.sort(y_data[mask])
            n = len(y_vals)
            if n == 0:
                continue

            # Simple swarm: distribute horizontally around the center
            # Use a simple approach: if few points, keep them near the center
            # This is a simplified version - a full swarm is more complex
            if n == 1:
                x_coords = [pos]
            else:
                # Estimate spacing based on data range
                y_range = y_vals[-1] - y_vals[0] if n > 1 else 1
                if y_range == 0:
                    x_coords = [pos] * n
                else:
                    # Scale positions to avoid overlap
                    # This is a simplified swarm; full implementation would
                    # adjust x positions iteratively to avoid points crossing
                    x_spread = 0.4  # max horizontal spread
                    x_coords = pos + (y_vals - y_vals[0]) / y_range * x_spread - x_spread/2

            ax.scatter(x_coords, y_vals, s=point_size, **config.get('scatter_kwargs', {}))

        ax.set_xticks(positions)
        ax.set_xticklabels(categories)
        ax.set_xlabel(x_col)
        ax.set_ylabel(y_col)

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def boxen_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create boxen plot (letter-value plot) for large datasets.

        Shows more quantile levels than a standard box plot.

        Parameters
        ----------
        config : dict
            - x : categorical column name (optional if orient='h')
            - y : numeric column name
            - orient : 'v' or 'h' (vertical or horizontal)
            - **kwargs : additional boxplot options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        orient = config.get('orient', 'v')

        if y_col is None:
            raise VisualizerError("Boxen plot requires 'y' parameter")

        if orient == 'v' and x_col is None:
            # Single boxen plot
            x_positions = [0]
            x_label = ''
        elif orient == 'v':
            x_positions = None  # will be determined by categories
        else:  # horizontal
            if y_col is None:
                raise VisualizerError("Boxen plot (orient='h') requires 'y' parameter")
            y_positions = None

        fig, ax = self._create_single_axes(config)

        # Use matplotlib's boxplot with custom boxprops to simulate letter-value
        # A true boxen plot shows nested boxes for each quantile level
        # For simplicity, we'll use a standard boxplot enhanced with more whiskers
        # or we can implement a basic letter-value plot using percentiles

        if orient == 'v':
            if x_col is not None:
                # Grouped boxen
                categories = data[x_col].unique()
                data_list = []
                positions = []
                for i, cat in enumerate(categories):
                    vals = data[data[x_col] == cat][y_col].dropna().values
                    if len(vals) > 0:
                        data_list.append(vals)
                        positions.append(i)
                if len(data_list) == 0:
                    raise VisualizerError("No valid data for boxen plot")
                ax.boxplot(data_list, positions=positions, **config.get('boxplot_kwargs', {}))
                ax.set_xticks(positions)
                ax.set_xticklabels(categories)
                ax.set_xlabel(x_col)
            else:
                # Single boxen
                vals = data[y_col].dropna().values
                if len(vals) == 0:
                    raise VisualizerError("No valid data for boxen plot")
                ax.boxplot(vals, **config.get('boxplot_kwargs', {}))
                ax.set_xlabel(y_col)
            ax.set_ylabel(y_col)
        else:  # horizontal
            if x_col is not None:
                categories = data[x_col].unique()
                data_list = []
                positions = []
                for i, cat in enumerate(categories):
                    vals = data[data[x_col] == cat][y_col].dropna().values
                    if len(vals) > 0:
                        data_list.append(vals)
                        positions.append(i)
                ax.boxplot(data_list, positions=positions, vert=False, **config.get('boxplot_kwargs', {}))
                ax.set_yticks(positions)
                ax.set_yticklabels(categories)
                ax.set_ylabel(x_col)
            else:
                vals = data[y_col].dropna().values
                ax.boxplot(vals, vert=False, **config.get('boxplot_kwargs', {}))
                ax.set_ylabel(y_col)
            ax.set_xlabel(y_col)

        # Note: This is a simplified boxen using standard boxplot.
        # A full letter-value plot would compute and draw nested boxes at multiple percentiles.
        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def qqplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create Q-Q plot (quantile-quantile plot) for distribution comparison.

        Parameters
        ----------
        config : dict
            - x : numeric column name
            - dist : str or scipy.stats distribution, default 'norm'
            - dist_params : dict of distribution parameters
            - **kwargs : additional scatter options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')

        if x_col is None:
            raise VisualizerError("QQ plot requires 'x' parameter")

        if x_col not in data.columns:
            raise VisualizerError(f"Column '{x_col}' not found")

        # Try to import scipy.stats
        try:
            from scipy import stats
        except ImportError:
            raise VisualizerError(
                "QQ plot requires scipy. Install with: pip install scipy"
            )

        sample = data[x_col].dropna().values
        if len(sample) == 0:
            raise VisualizerError("No valid data for QQ plot")

        dist = config.get('dist', 'norm')
        dist_params = config.get('dist_params', {})

        if isinstance(dist, str):
            try:
                dist_obj = getattr(stats, dist)
            except AttributeError:
                raise VisualizerError(f"Unknown distribution: {dist}")
        else:
            dist_obj = dist

        fig, ax = self._create_single_axes(config)

        # Compute quantiles
        (osm, osr), (slope, intercept, r) = stats.probplot(sample, dist=dist_obj, sparams=dist_params.get('params', []))

        # Plot
        ax.scatter(osm, osr, **config.get('scatter_kwargs', {}))

        # Plot reference line
        ax.plot(osm, osm * slope + intercept, 'r--', label=f'R² = {r**2:.3f}')

        ax.set_xlabel(f'Theoretical Quantiles ({dist})')
        ax.set_ylabel(f'Sample Quantiles ({x_col})')
        ax.legend()

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def residualplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create residual plot (residuals vs fitted values).

        Parameters
        ----------
        config : dict
            - x : column name for fitted values or predictions
            - y : column name for residuals
            - lowess : bool (default True) - show LOWESS smooth line
            - **kwargs : additional scatter options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        if not all([x_col, y_col]):
            raise VisualizerError("Residual plot requires 'x' and 'y' parameters")

        if x_col not in data.columns or y_col not in data.columns:
            raise VisualizerError(f"Columns not found: {x_col} or {y_col}")

        x_vals = data[x_col].values
        y_vals = data[y_col].values

        fig, ax = self._create_single_axes(config)

        # Scatter plot
        ax.scatter(x_vals, y_vals, **config.get('scatter_kwargs', {}))

        # Add LOWESS smooth if requested
        if config.get('lowess', True):
            try:
                from statsmodels.nonparametric.smoothers_lowess import lowess
                lowess_result = lowess(y_vals, x_vals, frac=config.get('lowess_frac', 0.3))
                ax.plot(lowess_result[:, 0], lowess_result[:, 1], 'r-', lw=2, label='LOWESS')
                ax.legend()
            except ImportError:
                # statsmodels not available, skip LOWESS
                pass

        # Add horizontal line at zero
        ax.axhline(y=0, color='gray', linestyle='--', alpha=0.5)

        ax.set_xlabel(x_col)
        ax.set_ylabel('Residuals')

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def lagplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create lag plot for time series analysis.

        Plots y_t vs y_{t-lag} to check for autocorrelation.

        Parameters
        ----------
        config : dict
            - x : numeric column name (time series values)
            - lag : int (default 1)
            - **kwargs : additional scatter options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')
        lag = config.get('lag', 1)

        if x_col is None:
            raise VisualizerError("Lag plot requires 'x' parameter")

        if x_col not in data.columns:
            raise VisualizerError(f"Column '{x_col}' not found")

        series = data[x_col].dropna().values
        if len(series) <= lag:
            raise VisualizerError(f"Series too short for lag={lag}")

        # Create lagged version
        y_t = series[lag:]
        y_t_lag = series[:-lag]

        fig, ax = self._create_single_axes(config)

        ax.scatter(y_t_lag, y_t, **config.get('scatter_kwargs', {}))

        ax.set_xlabel(f'{x_col} (t-{lag})')
        ax.set_ylabel(f'{x_col} (t)')

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def autocorrelation_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create autocorrelation function (ACF) plot.

        Parameters
        ----------
        config : dict
            - x : numeric column name (time series values)
            - lags : int or array-like (default 40)
            - **kwargs : additional bar plot options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')

        if x_col is None:
            raise VisualizerError("Autocorrelation plot requires 'x' parameter")

        if x_col not in data.columns:
            raise VisualizerError(f"Column '{x_col}' not found")

        series = data[x_col].dropna().values
        n = len(series)
        if n == 0:
            raise VisualizerError("No valid data for autocorrelation")

        lags = config.get('lags', 40)
        if isinstance(lags, int):
            lag_array = np.arange(lags + 1)
        else:
            lag_array = np.asarray(lags)

        # Compute autocorrelation manually using numpy
        # ACF = E[(X_t - μ)(X_{t+k} - μ)] / σ²
        mean = np.mean(series)
        var = np.var(series)
        if var == 0:
            raise VisualizerError("Variance is zero; cannot compute autocorrelation")

        acf = []
        for k in lag_array:
            if k >= n:
                acf.append(0)
            else:
                # Only use available overlapping pairs
                valid_len = n - k
                if valid_len > 0:
                    corr = np.sum((series[:n-k] - mean) * (series[k:] - mean)) / (valid_len * var)
                    acf.append(corr)
                else:
                    acf.append(0)

        acf = np.array(acf)

        fig, ax = self._create_single_axes(config)

        # Plot bars
        ax.bar(lag_array, acf, **config.get('bar_kwargs', {}))

        # Add confidence intervals (approx ±1.96/√n for 95% CI if white noise)
        n_obs = len(series)
        conf = 1.96 / np.sqrt(n_obs)
        ax.axhline(y=conf, color='r', linestyle='--', alpha=0.5, label='95% CI')
        ax.axhline(y=-conf, color='r', linestyle='--', alpha=0.5)

        ax.set_xlabel('Lag')
        ax.set_ylabel('Autocorrelation')
        ax.legend()

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def jointplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create joint plot (scatter with marginal univariate plots).

        Parameters
        ----------
        config : dict
            - x : column name for x-axis
            - y : column name for y-axis
            - marginal_kind : 'hist', 'kde', or 'rug' (default 'hist')
            - **kwargs : additional options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        marginal_kind = config.get('marginal_kind', 'hist')

        if not all([x_col, y_col]):
            raise VisualizerError("Joint plot requires 'x' and 'y' parameters")

        if x_col not in data.columns or y_col not in data.columns:
            raise VisualizerError(f"Columns not found: {x_col} or {y_col}")

        x_data = data[x_col].dropna().values
        y_data = data[y_col].dropna().values

        # Use GridSpec for layout: main scatter + top marginal + right marginal
        fig = self.plt.figure(figsize=config.get('figsize', (10, 8)))
        gs = fig.add_gridspec(2, 2, width_ratios=[4, 1], height_ratios=[1, 4], wspace=0.05, hspace=0.05)

        ax_main = fig.add_subplot(gs[1, 0])
        ax_xmargin = fig.add_subplot(gs[0, 0], sharex=ax_main)
        ax_ymargin = fig.add_subplot(gs[1, 1], sharey=ax_main)

        # Main scatter plot
        ax_main.scatter(x_data, y_data, **config.get('scatter_kwargs', {}))
        ax_main.set_xlabel(x_col)
        ax_main.set_ylabel(y_col)

        # X marginal
        if marginal_kind == 'hist':
            ax_xmargin.hist(x_data, bins=config.get('bins', 20), alpha=0.7)
        elif marginal_kind == 'kde':
            from scipy.stats import gaussian_kde
            kde = gaussian_kde(x_data)
            x_range = np.linspace(x_data.min(), x_data.max(), 200)
            ax_xmargin.plot(x_range, kde(x_range))
        elif marginal_kind == 'rug':
            ax_xmargin.rugplot(x_data, height=0.5)
        ax_xmargin.set_ylabel('Count' if marginal_kind == 'hist' else 'Density')
        ax_xmargin.label_outer()

        # Y marginal
        if marginal_kind == 'hist':
            ax_ymargin.hist(y_data, bins=config.get('bins', 20), orientation='horizontal', alpha=0.7)
        elif marginal_kind == 'kde':
            kde = gaussian_kde(y_data)
            y_range = np.linspace(y_data.min(), y_data.max(), 200)
            ax_ymargin.plot(kde(y_range), y_range)
        elif marginal_kind == 'rug':
            ax_ymargin.rugplot(y_data, height=0.5, orientation='horizontal')
        ax_ymargin.set_xlabel('Count' if marginal_kind == 'hist' else 'Density')
        ax_ymargin.label_outer()

        title = config.get('title', f'Joint Plot: {x_col} vs {y_col}')
        fig.suptitle(title, fontsize=config.get('title_fontsize', 14), y=1.02)

        self.plt.tight_layout()
        return fig

    def pairplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create pair plot (scatter matrix).

        Parameters
        ----------
        config : dict
            - data : DataFrame (already in config)
            - columns : list of numeric column names to plot
            - diag_kind : 'hist' or 'kde' (default 'hist')
            - **kwargs : additional options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        columns = config.get('columns')
        diag_kind = config.get('diag_kind', 'hist')

        if columns is None:
            # Use all numeric columns
            numeric_cols = data.select_dtypes(include='number').columns.tolist()
            columns = numeric_cols[:min(5, len(numeric_cols))]  # limit to 5 for readability

        n = len(columns)
        if n == 0:
            raise VisualizerError("No numeric columns for pair plot")

        fig, axes = self.plt.subplots(n, n, figsize=config.get('figsize', (12, 12)))
        if n == 1:
            axes = np.array([[axes]])

        # Flatten for easier indexing
        axes_flat = axes.flatten()

        for i, col_i in enumerate(columns):
            for j, col_j in enumerate(columns):
                ax = axes[i, j]
                idx = i * n + j

                if i == j:
                    # Diagonal: histogram or KDE
                    values = data[col_i].dropna().values
                    if diag_kind == 'hist':
                        ax.hist(values, bins=config.get('bins', 20), alpha=0.7)
                    elif diag_kind == 'kde':
                        from scipy.stats import gaussian_kde
                        kde = gaussian_kde(values)
                        x_range = np.linspace(values.min(), values.max(), 200)
                        ax.plot(x_range, kde(x_range))
                    ax.set_ylabel(col_i if j == 0 else '')
                else:
                    # Off-diagonal: scatter plot
                    x_vals = data[col_j].dropna().values
                    y_vals = data[col_i].dropna().values
                    # Align by dropping rows with NaN in either column
                    valid_mask = ~(data[col_j].isna() | data[col_i].isna())
                    x_vals = data[col_j][valid_mask].values
                    y_vals = data[col_i][valid_mask].values
                    ax.scatter(x_vals, y_vals, **config.get('scatter_kwargs', {}))

                    if i == n-1:
                        ax.set_xlabel(col_j)
                    if j == 0:
                        ax.set_ylabel(col_i)

                # Rotate x labels for readability
                if i == n-1:
                    for tick in ax.get_xticklabels():
                        tick.set_rotation(45)

        # Hide any extra subplots (shouldn't happen with square matrix)
        for idx in range(n*n, len(axes_flat)):
            axes_flat[idx].set_visible(False)

        title = config.get('title', 'Pair Plot')
        fig.suptitle(title, fontsize=config.get('title_fontsize', 16), y=1.02)

        self.plt.tight_layout()
        return fig

    def andrews_curves_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create Andrews curves for multivariate data visualization.

        Each sample is transformed using Fourier series and plotted as a curve.

        Parameters
        ----------
        config : dict
            - data : DataFrame
            - x : column name for class/group labels (categorical)
            - columns : list of numeric columns to use as features
            - **kwargs : additional line plot options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        class_col = config.get('x')
        feature_cols = config.get('columns')

        if class_col is None or feature_cols is None:
            raise VisualizerError("Andrews curves requires 'x' (class column) and 'columns' (feature columns)")

        if class_col not in data.columns:
            raise VisualizerError(f"Class column '{class_col}' not found")

        for col in feature_cols:
            if col not in data.columns:
                raise VisualizerError(f"Feature column '{col}' not found")

        # Drop rows with NaN in any feature or class
        df_subset = data[[class_col] + feature_cols].dropna()
        if len(df_subset) == 0:
            raise VisualizerError("No valid data after dropping NaNs")

        classes = df_subset[class_col].unique()
        n_points = 100  # resolution of the curve

        fig, ax = self._create_single_axes(config)

        # Define t values (-π to π)
        t = np.linspace(-np.pi, np.pi, n_points)

        for cls in classes:
            class_data = df_subset[df_subset[class_col] == cls][feature_cols].values
            if len(class_data) == 0:
                continue

            # For each sample in this class, compute Andrews curve
            # f(t) = c₀/√2 + Σ [cₙ cos(nt) + sₙ sin(nt)]
            # where cₙ, sₙ are Fourier coefficients derived from features
            for sample in class_data:
                # Normalize features (optional)
                normalized = (sample - np.mean(sample)) / (np.std(sample) + 1e-10)
                # Compute Fourier series coefficients
                # For k from 1 to m (m = number of features)
                # a_k = feature[k-1] * cos(kt), b_k = feature[k-1] * sin(kt)
                f_t = normalized[0] / np.sqrt(2)  # c0 term
                for k in range(1, len(normalized)):
                    f_t += normalized[k-1] * (np.cos(k * t) if k <= len(normalized) else 0) + \
                           normalized[k-1] * (np.sin(k * t) if k <= len(normalized) else 0)
                # Actually the standard formula:
                # f(t) = X₁/√2 + X₂ sin(t) + X₃ cos(t) + X₄ sin(2t) + X₅ cos(2t) + ...
                # So features: [X1, X2, X3, X4, X5, X6, ...]
                # We'll implement the standard formula:
                f_t = normalized[0] / np.sqrt(2)
                for i in range(1, len(normalized)):
                    if i % 2 == 1:  # odd index (1-based: X2, X4, X6,...) -> sin
                        k = (i + 1) // 2
                        f_t += normalized[i] * np.sin(k * t)
                    else:  # even index (X3, X5, X7,...) -> cos
                        k = i // 2
                        f_t += normalized[i] * np.cos(k * t)

                ax.plot(t, f_t, alpha=0.5, label=str(cls) if len(ax.get_lines()) == 0 else "")

        ax.set_xlabel('t (scaled)')
        ax.set_ylabel('f(t)')
        ax.set_xticks([-np.pi, -np.pi/2, 0, np.pi/2, np.pi])
        ax.set_xticklabels(['-π', '-π/2', '0', 'π/2', 'π'])

        # Add legend with unique handles
        handles, labels = ax.get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        ax.legend(by_label.values(), by_label.keys(), title=class_col)

        self._apply_labels(ax, config)
        self.plt.tight_layout()
        return fig

    def parallel_coordinates_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create parallel coordinates plot for multivariate data.

        Parameters
        ----------
        config : dict
            - data : DataFrame
            - x : column name for class/group labels (categorical)
            - columns : list of numeric columns to plot
            - color_map : dict mapping class to color (optional)
            - **kwargs : additional options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        class_col = config.get('x')
        feature_cols = config.get('columns')

        if class_col is None or feature_cols is None:
            raise VisualizerError("Parallel coordinates requires 'x' (class column) and 'columns' (feature columns)")

        if class_col not in data.columns:
            raise VisualizerError(f"Class column '{class_col}' not found")

        for col in feature_cols:
            if col not in data.columns:
                raise VisualizerError(f"Feature column '{col}' not found")

        # Normalize each feature to [0, 1] for consistent plotting
        df_subset = data[[class_col] + feature_cols].dropna()
        if len(df_subset) == 0:
            raise VisualizerError("No valid data")

        n_classes = len(df_subset[class_col].unique())
        if n_classes > 10:
            # Might be too many colors; warn or sample?
            pass

        # Create parallel axes
        fig, ax = self.plt.subplots(figsize=config.get('figsize', (12, 6)))
        ax.set_xlim([0, len(feature_cols) - 1])
        ax.set_ylim([0, 1])
        ax.set_xticks(range(len(feature_cols)))
        ax.set_xticklabels(feature_cols)

        # Plot each sample as a connected line
        x_positions = np.arange(len(feature_cols))
        color_map = config.get('color_map', None)

        for _, row in df_subset.iterrows():
            class_val = row[class_col]
            # Normalize feature values using min-max per column
            values = []
            for i, col in enumerate(feature_cols):
                col_min = df_subset[col].min()
                col_max = df_subset[col].max()
                if col_max == col_min:
                    norm_val = 0.5
                else:
                    norm_val = (row[col] - col_min) / (col_max - col_min)
                values.append(norm_val)

            color = color_map[class_val] if color_map and class_val in color_map else None
            ax.plot(x_positions, values, color=color, alpha=0.5, linewidth=1)

        ax.set_xlabel('Features')
        ax.set_ylabel('Normalized Value')
        ax.set_title(config.get('title', 'Parallel Coordinates'))

        # Add legend: we need proxy artists
        classes = sorted(df_subset[class_col].unique())
        from matplotlib.patches import Patch
        legend_elements = [Patch(facecolor='C0', label=str(cls)) for cls in classes]  # colors may not match exactly
        # Actually, we need to assign colors cyclically
        # This is a simplified legend
        ax.legend(title=class_col)

        self.plt.tight_layout()
        return fig

    def radviz_plot(self, config: Dict[str, Any]) -> Any:
        """
        Create RadViz plot for multivariate data on a circular layout.

        Parameters
        ----------
        config : dict
            - data : DataFrame
            - x : column name for class/group labels (categorical)
            - columns : list of numeric columns to use as features
            - **kwargs : additional scatter options

        Returns
        -------
        fig : matplotlib.figure.Figure
        """
        data = config['data']
        class_col = config.get('x')
        feature_cols = config.get('columns')

        if class_col is None or feature_cols is None:
            raise VisualizerError("RadViz requires 'x' (class column) and 'columns' (feature columns)")

        if class_col not in data.columns:
            raise VisualizerError(f"Class column '{class_col}' not found")

        for col in feature_cols:
            if col not in data.columns:
                raise VisualizerError(f"Feature column '{col}' not found")

        df_subset = data[[class_col] + feature_cols].dropna()
        if len(df_subset) == 0:
            raise VisualizerError("No valid data")

        m = len(feature_cols)  # number of features

        fig, ax = self._create_single_axes(config)

        # Positions of feature anchors on unit circle
        angles = np.linspace(0, 2 * np.pi, m, endpoint=False)
        anchor_x = np.cos(angles)
        anchor_y = np.sin(angles)

        # Plot feature anchors
        ax.scatter(anchor_x, anchor_y, c='black', s=50, marker='s')
        for i, (x, y, label) in enumerate(zip(anchor_x, anchor_y, feature_cols)):
            ax.text(x*1.1, y*1.1, label, ha='center', va='center', fontsize=9)

        # For each sample, compute its position based on feature weights
        classes = df_subset[class_col].unique()
        # Get default color cycle from matplotlib rcParams
        prop_cycle = self.plt.rcParams['axes.prop_cycle']
        colors = prop_cycle.by_key()['color']
        color_iter = iter(colors * (len(classes) + 1))  # repeat cycle if needed

        class_color_map = {}
        for cls in classes:
            color = next(color_iter)
            class_color_map[cls] = color
            class_data = df_subset[df_subset[class_col] == cls]
            for _, row in class_data[feature_cols].iterrows():
                # Normalize features to sum to 1 (softmax-like)
                values = row[feature_cols].values.astype(float)
                if np.sum(values) == 0:
                    weights = np.ones(m) / m
                else:
                    weights = values / np.sum(values)

                # Position is weighted sum of anchor positions
                x_pos = np.sum(weights * anchor_x)
                y_pos = np.sum(weights * anchor_y)

                ax.scatter(x_pos, y_pos, c=[class_color_map[cls]], alpha=0.7, s=30, edgecolors='black', linewidth=0.5)

        # Draw circle for reference
        circle = self.plt.Circle((0, 0), 1, color='gray', fill=False, linestyle='--', alpha=0.3)
        ax.add_artist(circle)

        ax.set_aspect('equal')
        ax.set_xlim(-1.2, 1.2)
        ax.set_ylim(-1.2, 1.2)
        ax.axis('off')
        ax.set_title(config.get('title', 'RadViz'))

        self.plt.tight_layout()
        return fig

    def show(self) -> None:
        """Display all pending figures."""
        self.plt.show()

    def close(self, fig: Optional[Any] = None) -> None:
        """
        Close a figure or all figures.

        Parameters
        ----------
        fig : Figure, optional
            Specific figure to close. If None, closes all figures.
        """
        if fig is None:
            self.plt.close('all')
        else:
            self.plt.close(fig)


# Register matplotlib backend by default
register_backend('matplotlib', MatplotlibBackend())
