"""
Plotly backend for BottleViz.

Provides interactive HTML-based visualizations using Plotly.
"""

from typing import Any, Dict, List, Optional
import numpy as np
import pandas as pd

from ..core.exceptions import VisualizerError


class PlotlyBackend:
    """
    Plotly-based interactive rendering backend.

    Provides interactive, web-based visualizations with zoom, pan,
    hover tooltips, and animation capabilities.
    """

    def __init__(self):
        """Initialize plotly backend."""
        try:
            import plotly.graph_objects as go
            import plotly.express as px
            from plotly.subplots import make_subplots
            self.go = go
            self.px = px
            self.make_subplots = make_subplots
            self._has_plotly = True
        except ImportError as e:
            raise VisualizerError(
                "Plotly is required for this backend. "
                f"Install with: pip install plotly\n"
                f"Original error: {e}"
            )

    def __getattr__(self, name: str):
        """
        Dynamically handle missing plot methods.

        Returns a callable that raises NotImplementedError for
        unsupported plot types.
        """
        if name.endswith('_plot'):
            # Dynamically create a method that raises NotImplementedError
            def _unimpl_method(config, plot_name=name[:-5]):
                raise NotImplementedError(
                    f"'{plot_name}' is not yet implemented in Plotly backend. "
                    f"Use Matplotlib backend: vz.plot(..., kind='{plot_name}')"
                )
            return _unimpl_method
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")

    def _create_single_axes(self, config: Dict[str, Any]):
        """Create a plotly figure (no axes concept, returns figure)."""
        return self.go.Figure()

    def _apply_layout(self, fig, config: Dict[str, Any]):
        """Apply common layout settings to plotly figure."""
        title = config.get('title', '')
        xlabel = config.get('xlabel', '')
        ylabel = config.get('ylabel', '')

        fig.update_layout(
            title=dict(text=title, font=dict(size=16)),
            xaxis_title=xlabel,
            yaxis_title=ylabel,
            template=config.get('template', 'plotly_white'),
            width=config.get('width', 900),
            height=config.get('height', 600),
            margin=dict(l=50, r=50, t=80, b=50),
            showlegend=config.get('showlegend', True)
        )
        return fig

    def line_plot(self, config: Dict[str, Any]) -> Any:
        """Create line plot."""
        data = config['data']
        x_col = config.get('x')
        y_cols = config.get('y')

        if y_cols is None:
            # Plot all numeric columns
            numeric_cols = data.select_dtypes(include='number').columns.tolist()
            if x_col and x_col in numeric_cols:
                numeric_cols.remove(x_col)
            y_cols = numeric_cols

        if isinstance(y_cols, str):
            y_cols = [y_cols]

        fig = self.go.Figure()

        for y_col in y_cols:
            x = data[x_col] if x_col else data.index
            fig.add_trace(
                self.go.Scatter(
                    x=x,
                    y=data[y_col],
                    mode='lines+markers',
                    name=y_col,
                    line=dict(width=2)
                )
            )

        self._apply_layout(fig, config)
        if x_col:
            fig.update_layout(xaxis_title=x_col)
        return fig

    def scatter_plot(self, config: Dict[str, Any]) -> Any:
        """Create scatter plot."""
        data = config['data']
        x_col = config.get('x')
        y_cols = config.get('y')

        if y_cols is None:
            numeric_cols = data.select_dtypes(include='number').columns.tolist()
            if x_col in numeric_cols:
                numeric_cols.remove(x_col)
            y_cols = numeric_cols[:1] if numeric_cols else None

        if y_cols is None:
            raise VisualizerError("Scatter plot requires 'y' parameter")

        if isinstance(y_cols, str):
            y_cols = [y_cols]

        fig = self.go.Figure()
        color_col = config.get('color')

        for i, y_col in enumerate(y_cols):
            if color_col:
                # Color by categorical column
                for cat_val in data[color_col].dropna().unique():
                    subset = data[data[color_col] == cat_val]
                    fig.add_trace(
                        self.go.Scatter(
                            x=subset[x_col],
                            y=subset[y_col],
                            mode='markers',
                            name=f'{y_col} ({cat_val})',
                            marker=dict(size=6, opacity=0.7),
                            showlegend=i == 0  # Only show legend for first y column
                        )
                    )
            else:
                fig.add_trace(
                    self.go.Scatter(
                        x=data[x_col],
                        y=data[y_col],
                        mode='markers',
                        name=y_col,
                        marker=dict(size=6, opacity=0.7)
                    )
                )

        self._apply_layout(fig, config)
        return fig

    def bar_plot(self, config: Dict[str, Any]) -> Any:
        """Create bar plot."""
        data = config['data']
        x_col = config.get('x')
        y_cols = config.get('y')

        if y_cols is None:
            numeric_cols = data.select_dtypes(include='number').columns.tolist()
            y_cols = numeric_cols[:1] if numeric_cols else None

        if isinstance(y_cols, str):
            y_cols = [y_cols]

        fig = self.go.Figure()
        for y_col in y_cols:
            fig.add_trace(
                self.go.Bar(
                    x=data[x_col],
                    y=data[y_col],
                    name=y_col
                )
            )

        self._apply_layout(fig, config)
        return fig

    def hist_plot(self, config: Dict[str, Any]) -> Any:
        """Create histogram."""
        data = config['data']
        columns = config.get('y')

        if columns is None:
            columns = data.select_dtypes(include='number').columns.tolist()
        elif isinstance(columns, str):
            columns = [columns]

        fig = self.go.Figure()
        for col in columns:
            fig.add_trace(
                self.go.Histogram(
                    x=data[col].dropna(),
                    name=col,
                    opacity=0.7,
                    nbinsx=config.get('bins', 30)
                )
            )

        self._apply_layout(fig, config)
        return fig

    def box_plot(self, config: Dict[str, Any]) -> Any:
        """Create box plot."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        if y_col is None:
            numeric_cols = data.select_dtypes(include='number').columns.tolist()
            y_col = numeric_cols[0] if numeric_cols else None

        fig = self.go.Figure()

        if x_col:
            # Grouped box plot
            for cat_val in data[x_col].dropna().unique():
                subset = data[data[x_col] == cat_val]
                fig.add_trace(
                    self.go.Box(
                        y=subset[y_col].dropna(),
                        name=str(cat_val),
                        boxmean=config.get('boxmean', False)
                    )
                )
        else:
            fig.add_trace(
                self.go.Box(
                    y=data[y_col].dropna(),
                    name=y_col,
                    boxmean=config.get('boxmean', False)
                )
            )

        self._apply_layout(fig, config)
        return fig

    def violin_plot(self, config: Dict[str, Any]) -> Any:
        """Create violin plot using plotly box/violin combo."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        if y_col is None:
            numeric_cols = data.select_dtypes(include='number').columns.tolist()
            y_col = numeric_cols[0] if numeric_cols else None

        fig = self.go.Figure()

        if x_col:
            for cat_val in data[x_col].dropna().unique():
                subset = data[data[x_col] == cat_val]
                fig.add_trace(
                    self.go.Violin(
                        y=subset[y_col].dropna(),
                        name=str(cat_val),
                        box_visible=True,
                        meanline_visible=True
                    )
                )
        else:
            fig.add_trace(
                self.go.Violin(
                    y=data[y_col].dropna(),
                    name=y_col,
                    box_visible=True,
                    meanline_visible=True
                )
            )

        self._apply_layout(fig, config)
        return fig

    def kde_plot(self, config: Dict[str, Any]) -> Any:
        """Create KDE plot using histogram + density overlay."""
        data = config['data']
        column = config.get('y') or config.get('x')

        if column is None:
            numeric_cols = data.select_dtypes(include='number').columns.tolist()
            column = numeric_cols[0] if numeric_cols else None

        fig = self.go.Figure()

        # Use histogram with density normalization
        fig.add_trace(
            self.go.Histogram(
                x=data[column].dropna(),
                name=column,
                opacity=0.7,
                histnorm='probability density',
                nbinsx=config.get('bins', 50)
            )
        )

        self._apply_layout(fig, config)
        fig.update_layout(yaxis_title='Density')
        return fig

    def surface_plot(self, config: Dict[str, Any]) -> Any:
        """Create 3D surface plot."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        z_col = config.get('z')

        if not z_col:
            raise VisualizerError("Surface plot requires 'z' parameter for height values")

        # If x and y are provided, we need to pivot the data into a grid
        if x_col and y_col:
            # Pivot long format to wide matrix: rows=y, columns=x, values=z
            try:
                pivot = data.pivot(index=y_col, columns=x_col, values=z_col)
                x_vals = pivot.columns.values
                y_vals = pivot.index.values
                z_matrix = pivot.values
            except Exception as e:
                raise VisualizerError(
                    f"Failed to pivot data for surface plot. Ensure that x and y columns "
                    f"create a unique index/column combination: {e}"
                )
        else:
            # If no x/y provided, assume data is already a 2D DataFrame (matrix)
            # where index is y, columns are x
            if isinstance(data, pd.DataFrame):
                z_matrix = data.values
                x_vals = data.columns.values
                y_vals = data.index.values
            else:
                raise VisualizerError("Surface plot requires either a DataFrame with x and y column names, or a 2D DataFrame")

        fig = self.go.Figure()

        fig.add_trace(
            self.go.Surface(
                z=z_matrix,
                x=x_vals,
                y=y_vals,
                colorscale=config.get('colorscale', 'Viridis'),
                showscale=True,
                colorbar_title=z_col if z_col else 'Value'
            )
        )

        # Layout
        fig.update_layout(
            title=dict(text=config.get('title', '3D Surface Plot'), font=dict(size=16)),
            scene=dict(
                xaxis_title=x_col if x_col else 'X',
                yaxis_title=y_col if y_col else 'Y',
                zaxis_title=z_col if z_col else 'Z',
                aspectmode='cube'
            ),
            width=config.get('width', 900),
            height=config.get('height', 700),
            margin=dict(l=50, r=50, t=80, b=50)
        )

        return fig

    def scatter_geo_plot(self, config: Dict[str, Any]) -> Any:
        """Create scatter plot on geographic coordinates."""
        data = config['data']
        lat = config.get('lat')
        lon = config.get('lon')
        value = config.get('value')

        if lat is None or lon is None:
            raise VisualizerError("Scatter geo requires 'lat' and 'lon' parameters")

        fig = self.go.Figure()

        if value:
            # Color by value
            fig.add_trace(
                self.go.Scattergeo(
                    lat=data[lat],
                    lon=data[lon],
                    mode='markers',
                    marker=dict(
                        size=config.get('markersize', 8),
                        color=data[value],
                        colorscale=config.get('colorscale', 'Viridis'),
                        showscale=True,
                        colorbar_title=value
                    ),
                    text=data.get('name', [f'Point {i}' for i in range(len(data))])
                )
            )
        else:
            fig.add_trace(
                self.go.Scattergeo(
                    lat=data[lat],
                    lon=data[lon],
                    mode='markers',
                    marker=dict(
                        size=config.get('markersize', 8),
                        color=config.get('marker_color', 'red')
                    ),
                    text=data.get('name', [f'Point {i}' for i in range(len(data))])
                )
            )

        fig.update_geos(
            projection_type='natural earth',
            showland=True,
            landcolor='rgb(243, 243, 243)',
            countrycolor='rgb(204, 204, 204)'
        )

        title = config.get('title', 'Geographic Scatter Plot')
        fig.update_layout(title=dict(text=title), geo=dict(scope='world'))
        return fig

    def choropleth_plot(self, config: Dict[str, Any]) -> Any:
        """Create choropleth map (colored regions)."""
        try:
            import geopandas as gpd
        except ImportError:
            raise VisualizerError("Choropleth requires geopandas")

        data = config['data']
        geometry_col = config.get('geometry')
        value_col = config.get('value')

        if geometry_col is None or value_col is None:
            raise VisualizerError("Choropleth requires 'geometry' and 'value'")

        # Ensure GeoDataFrame
        if not isinstance(data, gpd.GeoDataFrame):
            gdf = gpd.GeoDataFrame(data, geometry=geometry_col)
        else:
            gdf = data

        # Convert to GeoJSON
        # We'll use the index as location id if there's no name column
        locations = data.get('name') if 'name' in data.columns else data.index.astype(str)

        # Build GeoJSON feature collection
        features = []
        for idx, row in gdf.iterrows():
            geom = row[geometry_col]
            if geom.geom_type == 'Polygon':
                coords = [list(geom.exterior.coords)]
            elif geom.geom_type == 'MultiPolygon':
                coords = [list(poly.exterior.coords) for poly in geom.geoms]
            else:
                continue
            features.append({
                'type': 'Feature',
                'id': str(idx),
                'geometry': {
                    'type': geom.geom_type,
                    'coordinates': coords
                }
            })
        geojson = {'type': 'FeatureCollection', 'features': features}

        fig = self.go.Figure(self.go.Choropleth(
            geojson=geojson,
            locations=[str(idx) for idx in gdf.index],
            z=gdf[value_col],
            colorscale=config.get('cmap', 'Viridis'),
            marker_opacity=0.7,
            marker_line_width=1
        ))
        fig.update_geos(fitbounds='locations', resolution=50)
        self._apply_layout(fig, config)
        return fig

    def flow_map_plot(self, config: Dict[str, Any]) -> Any:
        """Create flow map (lines between points on map)."""
        data = config['data']
        olat = config.get('origin_lat')
        olon = config.get('origin_lon')
        dlat = config.get('dest_lat')
        dlon = config.get('dest_lon')
        flow_col = config.get('flow')

        if not all([olat, olon, dlat, dlon]):
            raise VisualizerError("Flow map requires origin/dest lat/lon")

        fig = self.go.Figure()

        # Draw lines for each flow
        for _, row in data.iterrows():
            fig.add_trace(self.go.Scattergeo(
                lat=[row[olat], row[dlat]],
                lon=[row[olon], row[dlon]],
                mode='lines',
                line=dict(width=row[flow_col] / data[flow_col].max() * 5 if flow_col else 2),
                showlegend=False
            ))

        fig.update_geos(
            projection_type='natural earth',
            showland=True,
            landcolor='rgb(243, 243, 243)',
            countrycolor='rgb(204, 204, 204)'
        )
        self._apply_layout(fig, config)
        return fig

    def tile_map_plot(self, config: Dict[str, Any]) -> Any:
        """Create tile map with basemap."""
        try:
            import geopandas as gpd
        except ImportError:
            raise VisualizerError("Tile map requires geopandas")

        data = config['data']
        geometry_col = config.get('geometry')
        value_col = config.get('value')

        if geometry_col is None or value_col is None:
            raise VisualizerError("Tile map requires 'geometry' and 'value'")

        if not isinstance(data, gpd.GeoDataFrame):
            gdf = gpd.GeoDataFrame(data, geometry=geometry_col)
        else:
            gdf = data

        # Reproject to Web Mercator if not already
        if gdf.crs and gdf.crs != 'EPSG:3857':
            gdf = gdf.to_crs(epsg=3857)

        # Get centroids for plotting points
        gdf['_centroid'] = gdf.geometry.centroid
        lons = gdf['_centroid'].x.tolist()
        lats = gdf['_centroid'].y.tolist()

        fig = self.go.Figure(self.go.Scattermapbox(
            lat=lats,
            lon=lons,
            mode='markers',
            marker=dict(
                size=gdf[value_col] / gdf[value_col].max() * 20,
                color=gdf[value_col],
                colorscale=config.get('cmap', 'Viridis'),
                showscale=True
            )
        ))
        fig.update_layout(
            mapbox=dict(
                style='open-street-map',
                center=dict(lon=np.mean(lons), lat=np.mean(lats)),
                zoom=config.get('zoom', 4)
            )
        )
        self._apply_layout(fig, config)
        return fig

    def cartogram_plot(self, config: Dict[str, Any]) -> Any:
        """Create cartogram (area-scaled polygons)."""
        try:
            import geopandas as gpd
        except ImportError:
            raise VisualizerError("Cartogram requires geopandas")

        data = config['data']
        geometry_col = config.get('geometry')
        value_col = config.get('value')

        if geometry_col is None or value_col is None:
            raise VisualizerError("Cartogram requires 'geometry' and 'value'")

        if not isinstance(data, gpd.GeoDataFrame):
            gdf = gpd.GeoDataFrame(data, geometry=geometry_col)
        else:
            gdf = data

        # Simple area scaling based on value (non-uniform scaling)
        # This is a crude approximation: scale each polygon about its centroid
        scale_factor = np.sqrt(gdf[value_col] / gdf[value_col].max())
        scaled_geoms = []
        for _, row in gdf.iterrows():
            geom = row[geometry_col]
            centroid = geom.centroid
            coords = []
            if geom.geom_type == 'Polygon':
                # Scale polygon vertices about centroid
                ext = list(geom.exterior.coords)
                scaled_ext = [
                    (centroid.x + (x - centroid.x) * sf,
                     centroid.y + (y - centroid.y) * sf)
                    for x, y, *rest in ext
                    for sf in [scale_factor[_]]
                ]
                from shapely.geometry import Polygon
                scaled_geoms.append(Polygon(scaled_ext))
            else:
                scaled_geoms.append(geom)  # fallback

        gdf = gdf.copy()
        gdf['_scaled_geometry'] = scaled_geoms

        # Plot as choropleth-like using the scaled geometries as an overlay
        # For simplicity, plot centroids sized by value
        fig = self.go.Figure()
        gdf['_centroid'] = gdf.geometry.centroid
        fig.add_trace(self.go.Scattermapbox(
            lat=gdf['_centroid'].y.tolist(),
            lon=gdf['_centroid'].x.tolist(),
            mode='markers',
            marker=dict(
                size=gdf[value_col] / gdf[value_col].max() * 30,
                color=gdf[value_col],
                colorscale=config.get('cmap', 'Viridis'),
                showscale=True
            )
        ))
        # Add polygon outlines
        for geom in gdf['_scaled_geometry']:
            if geom.geom_type == 'Polygon':
                x, y = geom.exterior.xy
                fig.add_trace(self.go.Scattermapbox(
                    lat=list(y),
                    lon=list(x),
                    mode='lines',
                    line=dict(width=1, color='black'),
                    showlegend=False
                ))
        fig.update_layout(
            mapbox=dict(
                style='open-street-map',
                center=dict(lon=gdf['_centroid'].x.mean(), lat=gdf['_centroid'].y.mean()),
                zoom=4
            )
        )
        self._apply_layout(fig, config)
        return fig

    # Stubs for remaining plot types (raise helpful errors)
    def _not_implemented(self, plot_name: str):
        """Helper to create NotImplementedError for unimplemented plots."""
        return lambda config: raise_(NotImplementedError(
            f"'{plot_name}' is not yet implemented in Plotly backend. "
            f"Use Matplotlib backend: vz.plot(..., kind='{plot_name}')"
        ))

    # ==================== BAR VARIATIONS ====================
    def stacked_bar_plot(self, config: Dict[str, Any]) -> Any:
        """Stacked bar chart."""
        data = config['data']
        x_col = config.get('x')
        y_cols = config.get('y')
        if not x_col or not y_cols:
            raise VisualizerError("Stacked bar requires 'x' (categories) and 'y' (stack columns)")

        if isinstance(y_cols, str):
            y_cols = [y_cols]

        fig = self.go.Figure()
        for y_col in y_cols:
            fig.add_trace(self.go.Bar(
                x=data[x_col],
                y=data[y_col],
                name=y_col
            ))
        fig.update_layout(barmode='stack')
        self._apply_layout(fig, config)
        return fig

    def grouped_bar_plot(self, config: Dict[str, Any]) -> Any:
        """Grouped bar chart (side-by-side)."""
        data = config['data']
        x_col = config.get('x')
        y_cols = config.get('y')
        if not x_col or not y_cols:
            raise VisualizerError("Grouped bar requires 'x' and 'y'")

        if isinstance(y_cols, str):
            y_cols = [y_cols]

        fig = self.go.Figure()
        for y_col in y_cols:
            fig.add_trace(self.go.Bar(
                x=data[x_col],
                y=data[y_col],
                name=y_col
            ))
        fig.update_layout(barmode='group')
        self._apply_layout(fig, config)
        return fig

    # ==================== PIE & AREA ====================
    def pie_plot(self, config: Dict[str, Any]) -> Any:
        """Pie chart."""
        data = config['data']
        labels_col = config.get('x')
        values_col = config.get('y')
        if not labels_col or not values_col:
            raise VisualizerError("Pie chart requires 'x' (labels) and 'y' (values)")

        fig = self.go.Figure(self.go.Pie(
            labels=data[labels_col],
            values=data[values_col]
        ))
        self._apply_layout(fig, config)
        return fig

    def area_plot(self, config: Dict[str, Any]) -> Any:
        """Area plot (stacked by default)."""
        data = config['data']
        x_col = config.get('x')
        y_cols = config.get('y')
        if not x_col or not y_cols:
            raise VisualizerError("Area plot requires 'x' and 'y'")

        if isinstance(y_cols, str):
            y_cols = [y_cols]

        fig = self.go.Figure()
        for y_col in y_cols:
            fig.add_trace(self.go.Scatter(
                x=data[x_col],
                y=data[y_col],
                fill='tozeroy',
                name=y_col
            ))
        self._apply_layout(fig, config)
        return fig

    # ==================== STEP, STEM, FILL_BETWEEN ====================
    def step_plot(self, config: Dict[str, Any]) -> Any:
        """Step plot."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        if not x_col or not y_col:
            raise VisualizerError("Step plot requires 'x' and 'y'")

        fig = self.go.Figure()
        fig.add_trace(self.go.Scatter(
            x=data[x_col],
            y=data[y_col],
            mode='lines',
            line=dict(shape='hv'),  # step shape
            name=y_col
        ))
        self._apply_layout(fig, config)
        return fig

    def fill_between_plot(self, config: Dict[str, Any]) -> Any:
        """Fill between plot (confidence intervals)."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        y2_col = config.get('y2')

        if not x_col or not y_col:
            raise VisualizerError("Fill between requires 'x' and 'y'")

        fig = self.go.Figure()
        # Main line
        fig.add_trace(self.go.Scatter(
            x=data[x_col],
            y=data[y_col],
            mode='lines',
            name=y_col,
            line=dict(color='blue')
        ))

        if y2_col:
            # Fill between y and y2
            fig.add_trace(self.go.Scatter(
                x=data[x_col].tolist() + data[x_col].tolist()[::-1],
                y=data[y2_col].tolist() + data[y_col].tolist()[::-1],
                fill='toself',
                mode='none',
                fillcolor='rgba(0,100,255,0.2)',
                name='fill'
            ))
        else:
            # Fill to zero
            fig.add_trace(self.go.Scatter(
                x=data[x_col].tolist() + data[x_col].tolist()[::-1],
                y=[0]*len(data) + data[y_col].tolist()[::-1],
                fill='toself',
                mode='none',
                fillcolor='rgba(0,100,255,0.2)',
                name='fill'
            ))

        self._apply_layout(fig, config)
        return fig

    def errorbar_plot(self, config: Dict[str, Any]) -> Any:
        """Line plot with error bars."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        yerr_col = config.get('yerr')

        if not x_col or not y_col:
            raise VisualizerError("Errorbar plot requires 'x' and 'y'")

        fig = self.go.Figure()
        fig.add_trace(self.go.Scatter(
            x=data[x_col],
            y=data[y_col],
            mode='lines+markers',
            error_y=dict(
                type='data',
                array=data[yerr_col] if yerr_col else None,
                visible=True
            ) if yerr_col else None,
            name=y_col
        ))
        self._apply_layout(fig, config)
        return fig

    def stem_plot(self, config: Dict[str, Any]) -> Any:
        """Stem plot (lollipop chart)."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        if not x_col or not y_col:
            raise VisualizerError("Stem plot requires 'x' and 'y'")

        fig = self.go.Figure()
        # For stem, we simulate with scatter markers and lines
        fig.add_trace(self.go.Scatter(
            x=data[x_col],
            y=data[y_col],
            mode='markers',
            marker=dict(symbol='circle', size=10),
            name=y_col
        ))
        # Add stems (vertical lines)
        for xi, yi in zip(data[x_col], data[y_col]):
            fig.add_shape(
                type='line',
                x0=xi, y0=0, x1=xi, y1=yi,
                line=dict(color='black', width=1)
            )
        self._apply_layout(fig, config)
        return fig

    # ==================== HEXBIN & PCOLORMESH ====================
    def hexbin_plot(self, config: Dict[str, Any]) -> Any:
        """Hexbin plot for 2D density."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        if not x_col or not y_col:
            raise VisualizerError("Hexbin requires 'x' and 'y'")

        # Plotly doesn't have native hexbin; use density hex as workaround
        # Using a 2D histogram approximation
        fig = self.go.Figure()
        fig.add_trace(self.go.Histogram2d(
            x=data[x_col],
            y=data[y_col],
            colorscale=config.get('colorscale', 'Viridis'),
            nbinsx=config.get('gridsize', 30),
            nbinsy=config.get('gridsize', 30),
            colorbar=dict(title='Count')
        ))
        fig.update_layout(
            xaxis_title=x_col,
            yaxis_title=y_col
        )
        self._apply_layout(fig, config)
        return fig

    def pcolormesh_plot(self, config: Dict[str, Any]) -> Any:
        """Pcolormesh plot (colored grid cells)."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        z_col = config.get('z') or config.get('value')

        if not all([x_col, y_col, z_col]):
            raise VisualizerError("Pcolormesh requires 'x', 'y', and 'z' (or 'value') parameters")

        # Plotly doesn't have native pcolormesh; use heatmap as approximation
        # Pivot data to matrix format
        pivot_data = data.pivot(index=y_col, columns=x_col, values=z_col)
        fig = self.go.Figure(self.go.Heatmap(
            z=pivot_data.values,
            x=pivot_data.columns.astype(str).tolist(),
            y=pivot_data.index.astype(str).tolist(),
            colorscale=config.get('cmap', 'Viridis')
        ))
        fig.update_layout(
            xaxis_title=x_col,
            yaxis_title=y_col
        )
        self._apply_layout(fig, config)
        return fig

    # ==================== HEATMAP ====================
    def heatmap_plot(self, config: Dict[str, Any]) -> Any:
        """Heatmap with optional annotations."""
        data = config['data']

        # Check if data is already pivoted (matrix)
        if isinstance(data, pd.DataFrame) and data.select_dtypes(include=[np.number]).shape == data.shape:
            # Assume it's a matrix
            pivot_data = data
        else:
            # Need to pivot
            if config.get('pivot'):
                pivot_data = data.pivot_table(
                    index=config.get('index'),
                    columns=config.get('columns'),
                    values=config.get('value')
                )
            else:
                pivot_data = data

        # Create heatmap
        fig = self.go.Figure(self.go.Heatmap(
            z=pivot_data.values,
            x=[str(col) for col in pivot_data.columns],
            y=[str(idx) for idx in pivot_data.index],
            colorscale=config.get('cmap', 'Viridis'),
            showscale=config.get('colorbar', True)
        ))

        # Add annotations if requested
        if config.get('annot', False):
            annot_fmt = config.get('fmt', '.2f')
            for i, row in enumerate(pivot_data.values):
                for j, val in enumerate(row):
                    try:
                        text = format(val, annot_fmt)
                    except:
                        text = str(val)
                    fig.add_annotation(
                        x=j,
                        y=i,
                        text=text,
                        showarrow=False,
                        font=dict(size=config.get('annot_fontsize', 9), color='black')
                    )

        fig.update_layout(
            xaxis=dict(side='bottom'),
            yaxis=dict(autorange='reversed')  # Heatmap typically has y reversed
        )
        self._apply_layout(fig, config)
        return fig

    # ==================== POLAR & TABLE & EVENTPLOT ====================
    def polar_plot(self, config: Dict[str, Any]) -> Any:
        """Polar plot (radial coordinates)."""
        data = config['data']
        theta_col = config.get('theta')
        r_col = config.get('r')

        if not theta_col or not r_col:
            raise VisualizerError("Polar plot requires 'theta' and 'r' parameters")

        fig = self.go.Figure()
        fig.add_trace(self.go.Scatterpolar(
            r=data[r_col],
            theta=data[theta_col],
            mode='lines+markers'
        ))
        self._apply_layout(fig, config)
        return fig

    def table_plot(self, config: Dict[str, Any]) -> Any:
        """Table visualization."""
        data = config['data']
        max_rows = config.get('max_rows', 20)

        fig = self.go.Figure(data=[self.go.Table(
            header=dict(
                values=list(data.columns),
                fill_color='paleturquoise',
                align='left'
            ),
            cells=dict(
                values=[data[col].head(max_rows) for col in data.columns],
                fill_color='lavender',
                align='left'
            )
        )])
        fig.update_layout(title=config.get('title', 'Table'))
        return fig

    def eventplot_plot(self, config: Dict[str, Any]) -> Any:
        """Event plot (sequences)."""
        data = config['data']
        columns = config.get('columns') or data.columns.tolist()

        fig = self.go.Figure()
        for i, col in enumerate(columns):
            fig.add_trace(self.go.Scatter(
                x=data[col],
                y=[i] * len(data),
                mode='markers',
                name=col,
                marker=dict(size=10, symbol='line-ns')
            ))
        fig.update_layout(
            yaxis=dict(
                tickmode='array',
                tickvals=list(range(len(columns))),
                ticktext=columns
            ),
            xaxis_title='Event Time',
            showlegend=False
        )
        self._apply_layout(fig, config)
        return fig

    def waterfall_plot(self, config: Dict[str, Any]) -> Any:
        """Waterfall chart."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')

        if not x_col or not y_col:
            raise VisualizerError("Waterfall requires 'x' and 'y'")

        values = data[y_col].tolist()
        categories = data[x_col].tolist()

        # Calculate positions
        y_pos = [0]
        for v in values[:-1]:
            y_pos.append(y_pos[-1] + v)

        fig = self.go.Figure()
        colors = ['green' if v >= 0 else 'red' for v in values]
        fig.add_trace(self.go.Bar(
            x=categories,
            y=values,
            base=y_pos[:-1],
            marker_color=colors
        ))

        # Add total line
        fig.add_trace(self.go.Scatter(
            x=[categories[-1]],
            y=[y_pos[-1] + values[-1]],
            mode='markers+text',
            text=[f'Total: {y_pos[-1] + values[-1]:.1f}'],
            marker=dict(size=10)
        ))

        self._apply_layout(fig, config)
        return fig

    def gantt_plot(self, config: Dict[str, Any]) -> Any:
        """Gantt chart."""
        data = config['data']
        task_col = config.get('task') or config.get('x')
        start_col = config.get('start')
        duration_col = config.get('duration')
        end_col = config.get('end')

        if not all([task_col, start_col]):
            raise VisualizerError("Gantt requires 'task' and 'start' columns")

        tasks = data[task_col].tolist()
        if duration_col:
            starts = pd.to_datetime(data[start_col]) if not pd.api.types.is_datetime64_any_dtype(data[start_col]) else data[start_col]
            durations = data[duration_col]
            ends = starts + pd.to_timedelta(durations, unit='D')
        elif end_col:
            starts = pd.to_datetime(data[start_col]) if not pd.api.types.is_datetime64_any_dtype(data[start_col]) else data[start_col]
            ends = pd.to_datetime(data[end_col]) if not pd.api.types.is_datetime64_any_dtype(data[end_col]) else data[end_col]
        else:
            raise VisualizerError("Gantt requires either 'duration' or 'end' column")

        fig = self.go.Figure()
        for i, (task, start, end) in enumerate(zip(tasks, starts, ends)):
            fig.add_trace(self.go.Bar(
                x=[(end - start).days],
                y=[task],
                orientation='h',
                base=start,
                name=task,
                marker=dict(color=f'rgb({50+i*30}, {100+i*20}, {150+i*10})')
            ))

        fig.update_layout(
            xaxis_title='Timeline',
            yaxis=dict(autorange='reversed'),
            showlegend=False
        )
        self._apply_layout(fig, config)
        return fig

    def ohlc_volume_plot(self, config: Dict[str, Any]) -> Any:
        """OHLC candlestick with volume bars."""
        data = config['data']
        x_col = config.get('x')
        open_col = config.get('open')
        high_col = config.get('high')
        low_col = config.get('low')
        close_col = config.get('close')
        volume_col = config.get('volume')

        if not all([x_col, open_col, high_col, low_col, close_col]):
            raise VisualizerError("OHLC requires 'x', 'open', 'high', 'low', 'close'")

        fig = self.go.Figure()

        # Candlestick
        fig.add_trace(self.go.Candlestick(
            x=data[x_col],
            open=data[open_col],
            high=data[high_col],
            low=data[low_col],
            close=data[close_col],
            name='OHLC'
        ))

        # Volume bars
        if volume_col:
            fig.add_trace(self.go.Bar(
                x=data[x_col],
                y=data[volume_col],
                name='Volume',
                yaxis='y2',
                marker_color='rgba(100,100,200,0.5)'
            ))
            fig.update_layout(
                yaxis2=dict(
                    title='Volume',
                    overlaying='y',
                    side='right'
                )
            )

        self._apply_layout(fig, config)
        return fig

    def plot_3d(self, config: Dict[str, Any]) -> Any:
        """Create 3D scatter plot."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        z_col = config.get('z')

        if not all([x_col, y_col, z_col]):
            raise VisualizerError("3D plot requires 'x', 'y', and 'z' parameters")

        color_col = config.get('color')
        size_col = config.get('size')

        fig = self.go.Figure()

        # Determine color handling
        if color_col:
            # Check if color column is categorical/object type OR has few unique values
            is_categorical = (
                pd.api.types.is_categorical_dtype(data[color_col]) or
                data[color_col].dtype == 'object' or
                data[color_col].nunique() <= 10
            )
            if is_categorical:
                # Categorical: create separate traces
                for cat_val in data[color_col].dropna().unique():
                    mask = data[color_col] == cat_val
                    fig.add_trace(
                        self.go.Scatter3d(
                            x=data.loc[mask, x_col],
                            y=data.loc[mask, y_col],
                            z=data.loc[mask, z_col],
                            mode='markers',
                            name=str(cat_val),
                            marker=dict(
                                size=data[size_col] if size_col else 5,
                                sizemode='diameter' if size_col else None,
                                sizeref=2 if size_col else None,
                                sizemin=1 if size_col else None,
                                opacity=0.7
                            )
                        )
                    )
            else:
                # Numeric color: single trace with colorscale
                marker_dict = dict(
                    size=data[size_col] if size_col else 5,
                    sizemode='diameter' if size_col else None,
                    sizeref=2 if size_col else None,
                    sizemin=1 if size_col else None,
                    opacity=0.7,
                    color=data[color_col],
                    colorscale=config.get('colorscale', 'Viridis'),
                    showscale=True,
                    colorbar_title=color_col
                )
                fig.add_trace(
                    self.go.Scatter3d(
                        x=data[x_col],
                        y=data[y_col],
                        z=data[z_col],
                        mode='markers',
                        marker=marker_dict
                    )
                )
        else:
            # No color column
            fig.add_trace(
                self.go.Scatter3d(
                    x=data[x_col],
                    y=data[y_col],
                    z=data[z_col],
                    mode='markers',
                    marker=dict(
                        size=data[size_col] if size_col else 5,
                        sizemode='diameter' if size_col else None,
                        sizeref=2 if size_col else None,
                        sizemin=1 if size_col else None,
                        opacity=0.7
                    )
                )
            )

        # Layout
        fig.update_layout(
            title=dict(text=config.get('title', '3D Scatter Plot'), font=dict(size=16)),
            scene=dict(
                xaxis_title=x_col,
                yaxis_title=y_col,
                zaxis_title=z_col,
                aspectmode='cube'
            ),
            width=config.get('width', 900),
            height=config.get('height', 700),
            margin=dict(l=50, r=50, t=80, b=50)
        )

        return fig

    # ==================== SCIENTIFIC PLOTS ====================
    def contour_plot(self, config: Dict[str, Any]) -> Any:
        """Contour plot (2D)."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        z_col = config.get('z')

        if not all([x_col, y_col, z_col]):
            raise VisualizerError("Contour plot requires 'x', 'y', and 'z'")

        # Pivot to grid
        pivot_data = data.pivot(index=y_col, columns=x_col, values=z_col)
        fig = self.go.Figure(self.go.Contour(
            z=pivot_data.values,
            x=pivot_data.columns.astype(float).tolist(),
            y=pivot_data.index.astype(float).tolist(),
            colorscale=config.get('cmap', 'Viridis'),
            contours=dict(coloring='lines') if config.get('lines') else None
        ))
        fig.update_layout(
            xaxis_title=x_col,
            yaxis_title=y_col
        )
        self._apply_layout(fig, config)
        return fig

    def quiver_plot(self, config: Dict[str, Any]) -> Any:
        """Quiver plot (2D vector field)."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        u_col = config.get('u')
        v_col = config.get('v')

        if not all([x_col, y_col, u_col, v_col]):
            raise VisualizerError("Quiver requires 'x', 'y', 'u', and 'v'")

        fig = self.go.Figure()
        fig.add_trace(self.go.Scatter(
            x=data[x_col],
            y=data[y_col],
            mode='markers+lines',
            marker=dict(symbol='arrow', size=10, angleref='previous'),
            line=dict(width=1)
        ))
        # Plotly doesn't have native quiver; using arrows on markers as approximation
        self._apply_layout(fig, config)
        return fig

    def spy_plot(self, config: Dict[str, Any]) -> Any:
        """Spy plot (sparsity pattern)."""
        data = config['data']
        # If data is not already a 2D array, assume it's a DataFrame of 0/1 or NaN
        if isinstance(data, pd.DataFrame):
            mat = data.values
        else:
            mat = data

        # Get non-zero indices
        rows, cols = np.nonzero(mat)
        fig = self.go.Figure()
        fig.add_trace(self.go.Scatter(
            x=cols.tolist(),
            y=rows.tolist(),
            mode='markers',
            marker=dict(size=config.get('markersize', 5), color='black')
        ))
        fig.update_layout(
            xaxis=dict(scaleanchor='y', scaleratio=1),
            yaxis=dict(autorange='reversed'),
            title='Sparsity Pattern'
        )
        self._apply_layout(fig, config)
        return fig

    def streamplot_plot(self, config: Dict[str, Any]) -> Any:
        """Streamplot (vector field) - arrow representation.

        Creates a quiver-like visualization showing direction and relative magnitude.
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        u_col = config.get('u')
        v_col = config.get('v')

        if not all([x_col, y_col, u_col, v_col]):
            raise VisualizerError("Streamplot requires 'x', 'y', 'u', and 'v'")

        x = data[x_col].values
        y = data[y_col].values
        u = data[u_col].values
        v = data[v_col].values

        # Normalize vectors for consistent arrow length
        mag = np.sqrt(u**2 + v**2)
        # Avoid division by zero
        mag[mag == 0] = 1
        scale = config.get('scale', 1.0)  # Arrow length scaling factor
        u_norm = u / mag * scale
        v_norm = v / mag * scale

        # Build line segments for arrows (each arrow: start -> end, then break)
        xs = []
        ys = []
        for i in range(len(x)):
            xs.extend([x[i], x[i] + u_norm[i], None])
            ys.extend([y[i], y[i] + v_norm[i], None])

        fig = self.go.Figure()
        color = config.get('color', 'blue')
        # If color is a column name, ignore - Plotly quiver doesn't support per-line coloring
        if isinstance(color, str) and color in data.columns:
            color = 'blue'
        fig.add_trace(self.go.Scatter(
            x=xs, y=ys,
            mode='lines',
            line=dict(width=1, color=color),
            showlegend=False
        ))

        fig.update_layout(
            xaxis_title=x_col,
            yaxis_title=y_col
        )
        self._apply_layout(fig, config)
        return fig

    def tricontour_plot(self, config: Dict[str, Any]) -> Any:
        """Tricontour (contour on unstructured grid) using interpolation."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        z_col = config.get('z')
        levels = config.get('levels', 15)

        if not all([x_col, y_col, z_col]):
            raise VisualizerError("Tricontour requires 'x', 'y', and 'z'")

        x = data[x_col].values
        y = data[y_col].values
        z = data[z_col].values

        # Interpolate onto a regular grid using scipy if available
        try:
            from scipy.interpolate import griddata
        except ImportError:
            raise VisualizerError(
                "Tricontour requires scipy for interpolation. "
                "Install with: pip install scipy"
            )

        # Create regular grid
        xi = np.linspace(np.nanmin(x), np.nanmax(x), 100)
        yi = np.linspace(np.nanmin(y), np.nanmax(y), 100)
        xi_grid, yi_grid = np.meshgrid(xi, yi)
        zi_grid = griddata((x, y), z, (xi_grid, yi_grid), method='cubic')

        fig = self.go.Figure(self.go.Contour(
            x=xi,
            y=yi,
            z=zi_grid,
            colorscale=config.get('cmap', 'Viridis'),
            ncontours=levels,
            line_smoothing=1.0
        ))
        fig.update_layout(xaxis_title=x_col, yaxis_title=y_col)
        self._apply_layout(fig, config)
        return fig

    def tricontourf_plot(self, config: Dict[str, Any]) -> Any:
        """Tricontourf (filled contour on unstructured grid) using interpolation."""
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        z_col = config.get('z')
        levels = config.get('levels', 15)

        if not all([x_col, y_col, z_col]):
            raise VisualizerError("Tricontourf requires 'x', 'y', and 'z'")

        x = data[x_col].values
        y = data[y_col].values
        z = data[z_col].values

        try:
            from scipy.interpolate import griddata
        except ImportError:
            raise VisualizerError(
                "Tricontourf requires scipy for interpolation. "
                "Install with: pip install scipy"
            )

        xi = np.linspace(np.nanmin(x), np.nanmax(x), 100)
        yi = np.linspace(np.nanmin(y), np.nanmax(y), 100)
        xi_grid, yi_grid = np.meshgrid(xi, yi)
        zi_grid = griddata((x, y), z, (xi_grid, yi_grid), method='cubic')

        fig = self.go.Figure(self.go.Contour(
            x=xi,
            y=yi,
            z=zi_grid,
            colorscale=config.get('cmap', 'Viridis'),
            ncontours=levels,
            contours_coloring='fill',
            line_smoothing=1.0
        ))
        fig.update_layout(xaxis_title=x_col, yaxis_title=y_col)
        self._apply_layout(fig, config)
        return fig

    def figure3d(self, config): return self._not_implemented('figure3d')(config)

    def sankey_plot(self, config: Dict[str, Any]) -> Any:
        """Sankey diagram."""
        data = config['data']
        source_col = config.get('source') or config.get('from')
        target_col = config.get('target') or config.get('to')
        value_col = config.get('value')

        if not all([source_col, target_col, value_col]):
            raise VisualizerError("Sankey requires 'source', 'target', and 'value' columns")

        # Build node list
        all_nodes = pd.concat([data[source_col], data[target_col]]).unique()
        node_idx = {node: i for i, node in enumerate(all_nodes)}

        fig = self.go.Figure(self.go.Sankey(
            node=dict(
                label=all_nodes.tolist(),
                pad=15,
                thickness=20
            ),
            link=dict(
                source=[node_idx[s] for s in data[source_col]],
                target=[node_idx[t] for t in data[target_col]],
                value=data[value_col]
            )
        ))
        self._apply_layout(fig, config)
        return fig

    def sunburst_plot(self, config: Dict[str, Any]) -> Any:
        """Sunburst chart (hierarchical radial)."""
        data = config['data']
        path_cols = config.get('path') or config.get('path_cols')
        value_col = config.get('value')

        if not path_cols:
            raise VisualizerError("Sunburst requires 'path' parameter with hierarchical columns")

        if not isinstance(path_cols, (list, tuple)):
            path_cols = [path_cols]

        fig = self.go.Figure(self.go.Sunburst(
            labels=data[path_cols[-1]],
            parents=data[path_cols[-2]] if len(path_cols) > 1 else [''] * len(data),
            values=data[value_col] if value_col else None
        ))
        self._apply_layout(fig, config)
        return fig

    def treemap_plot(self, config: Dict[str, Any]) -> Any:
        """Treemap (hierarchical rectangles)."""
        data = config['data']
        path_cols = config.get('path') or config.get('path_cols')
        value_col = config.get('value')

        if not path_cols:
            raise VisualizerError("Treemap requires 'path' parameter with hierarchical columns")

        if not isinstance(path_cols, (list, tuple)):
            path_cols = [path_cols]

        fig = self.go.Figure(self.go.Treemap(
            labels=data[path_cols[-1]],
            parents=data[path_cols[-2]] if len(path_cols) > 1 else [''] * len(data),
            values=data[value_col] if value_col else None
        ))
        self._apply_layout(fig, config)
        return fig

    def network_plot(self, config: Dict[str, Any]) -> Any:
        """Network graph."""
        data = config['data']
        source_col = config.get('source')
        target_col = config.get('target')
        weight_col = config.get('weight')

        if not source_col or not target_col:
            raise VisualizerError("Network requires 'source' and 'target' columns")

        # Build networkx graph and convert to edge trace
        import networkx as nx
        G = nx.Graph()
        for _, row in data.iterrows():
            G.add_edge(row[source_col], row[target_col], weight=row[weight_col] if weight_col else 1)

        # Compute layout
        pos = nx.spring_layout(G)

        # Edge trace
        edge_x = []
        edge_y = []
        for edge in G.edges():
            x0, y0 = pos[edge[0]]
            x1, y1 = pos[edge[1]]
            edge_x += [x0, x1, None]
            edge_y += [y0, y1, None]

        edge_trace = self.go.Scatter(
            x=edge_x, y=edge_y,
            line=dict(width=1, color='#888'),
            hoverinfo='none',
            mode='lines'
        )

        # Node trace
        node_x = [pos[node][0] for node in G.nodes()]
        node_y = [pos[node][1] for node in G.nodes()]
        node_trace = self.go.Scatter(
            x=node_x, y=node_y,
            mode='markers',
            hoverinfo='text',
            marker=dict(size=10, color='blue')
        )

        fig = self.go.Figure(data=[edge_trace, node_trace])
        fig.update_layout(showlegend=False)
        self._apply_layout(fig, config)
        return fig

    def candlestick_plot(self, config: Dict[str, Any]) -> Any:
        """Candlestick chart."""
        data = config['data']
        x_col = config.get('x')
        open_col = config.get('open')
        high_col = config.get('high')
        low_col = config.get('low')
        close_col = config.get('close')

        if not all([x_col, open_col, high_col, low_col, close_col]):
            raise VisualizerError("Candlestick requires 'x', 'open', 'high', 'low', 'close'")

        fig = self.go.Figure(self.go.Candlestick(
            x=data[x_col],
            open=data[open_col],
            high=data[high_col],
            low=data[low_col],
            close=data[close_col]
        ))
        self._apply_layout(fig, config)
        return fig

    def autocorrelation_plot(self, config: Dict[str, Any]) -> Any:
        """
        Autocorrelation function (ACF) plot.
        Parameters
        ----------
        config : dict
            - x : numeric column name (time series values)
            - lags : int or array-like (default 40)
            - **kwargs : additional options
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        x_col = config.get('x')
        if x_col is None:
            raise VisualizerError("Autocorrelation plot requires 'x' parameter")
        series = data[x_col].dropna().values
        n = len(series)
        if n == 0:
            raise VisualizerError("No valid data for autocorrelation")
        lags = config.get('lags', 40)
        if isinstance(lags, int):
            lag_array = np.arange(lags + 1)
        else:
            lag_array = np.asarray(lags)
        mean = np.mean(series)
        var = np.var(series)
        if var == 0:
            raise VisualizerError("Variance is zero; cannot compute autocorrelation")
        acf = []
        for k in lag_array:
            if k >= n:
                acf.append(0)
            else:
                valid_len = n - k
                if valid_len > 0:
                    corr = np.sum((series[:n-k] - mean) * (series[k:] - mean)) / (valid_len * var)
                    acf.append(corr)
                else:
                    acf.append(0)
        acf = np.array(acf)
        fig = self.go.Figure()
        fig.add_trace(self.go.Bar(x=lag_array, y=acf))
        conf = 1.96 / np.sqrt(n)
        fig.add_hline(y=conf, line_dash='dash', line_color='red', annotation_text='95% CI')
        fig.add_hline(y=-conf, line_dash='dash', line_color='red')
        fig.update_xaxes(title_text='Lag')
        fig.update_yaxes(title_text='Autocorrelation')
        self._apply_layout(fig, config)
        return fig

    def jointplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Joint plot (scatter with marginal distributions).
        Parameters
        ----------
        config : dict
            - x, y : column names
            - marginal_x, marginal_y : 'hist', 'kde', 'rug' (default 'hist')
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        if not all([x_col, y_col]):
            raise VisualizerError("Joint plot requires 'x' and 'y'")
        try:
            fig = self.px.scatter(data, x=x_col, y=y_col,
                                  marginal_x=config.get('marginal_x', 'hist'),
                                  marginal_y=config.get('marginal_y', 'hist'),
                                  **config.get('px_kwargs', {}))
        except Exception:
            fig = self.px.scatter(data, x=x_col, y=y_col, **config.get('px_kwargs', {}))
        self._apply_layout(fig, config)
        return fig

    def lagplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Lag plot for time series analysis.
        Parameters
        ----------
        config : dict
            - x : numeric column (time series values)
            - lag : int default 1
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        x_col = config.get('x')
        lag = config.get('lag', 1)
        if x_col is None:
            raise VisualizerError("Lag plot requires 'x' parameter")
        series = data[x_col].dropna().values
        n = len(series)
        if n <= lag:
            raise VisualizerError(f"Series too short for lag={lag}")
        y_t = series[lag:]
        y_t_lag = series[:-lag]
        fig = self.go.Figure()
        fig.add_trace(self.go.Scatter(x=y_t_lag, y=y_t, mode='markers'))
        fig.update_xaxes(title_text=f'{x_col} (t-{lag})')
        fig.update_yaxes(title_text=f'{x_col} (t)')
        self._apply_layout(fig, config)
        return fig

    def pairplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Pair plot (scatter matrix).
        Parameters
        ----------
        config : dict
            - data : DataFrame
            - columns : list of numeric columns
            - diag_kind : ignored for plotly
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        columns = config.get('columns')
        if columns is None:
            numeric_cols = data.select_dtypes(include='number').columns.tolist()
            columns = numeric_cols[:min(5, len(numeric_cols))]
        try:
            fig = self.px.scatter_matrix(data, dimensions=columns, **config.get('px_kwargs', {}))
        except AttributeError:
            raise VisualizerError("Scatter matrix not available in this Plotly version")
        self._apply_layout(fig, config)
        return fig

    def parallel_coordinates_plot(self, config: Dict[str, Any]) -> Any:
        """
        Parallel coordinates plot.
        Parameters
        ----------
        config : dict
            - data : DataFrame
            - x : class column name (categorical or numeric)
            - columns : list of numeric feature columns
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        class_col = config.get('x')
        feature_cols = config.get('columns')
        if class_col is None or feature_cols is None:
            raise VisualizerError("Parallel coordinates requires 'x' (class) and 'columns' (features)")
        try:
            # Convert categorical class to numeric codes for color
            color_series = data[class_col]
            if not pd.api.types.is_numeric_dtype(color_series):
                categories = color_series.dropna().unique()
                color_map = {cat: i for i, cat in enumerate(categories)}
                color_vals = color_series.map(color_map)
            else:
                color_vals = color_series
            fig = self.px.parallel_coordinates(data, dimensions=feature_cols, color=color_vals, **config.get('px_kwargs', {}))
        except AttributeError:
            raise VisualizerError("Parallel coordinates not available in this Plotly version")
        self._apply_layout(fig, config)
        return fig

    def qqplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Q-Q plot for distribution comparison.
        Parameters
        ----------
        config : dict
            - x : numeric column
            - dist : str (e.g., 'norm') default 'norm'
            - dist_params : dict of distribution parameters
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        x_col = config.get('x')
        if x_col is None:
            raise VisualizerError("QQ plot requires 'x' parameter")
        sample = data[x_col].dropna().values
        if len(sample) == 0:
            raise VisualizerError("No valid data for QQ plot")
        try:
            from scipy import stats
        except ImportError:
            raise VisualizerError("QQ plot requires scipy. Install with: pip install scipy")
        dist_name = config.get('dist', 'norm')
        try:
            dist = getattr(stats, dist_name)
        except AttributeError:
            raise VisualizerError(f"Unknown distribution: {dist_name}")
        dist_params = config.get('dist_params', {})
        res = stats.probplot(sample, dist=dist, sparams=dist_params.get('params', []))
        osm, osr = res[0]
        slope, intercept, r = res[1]
        fig = self.go.Figure()
        fig.add_trace(self.go.Scatter(x=osm, y=osr, mode='markers', name='Quantiles'))
        line_x = np.array([osm.min(), osm.max()])
        line_y = slope * line_x + intercept
        fig.add_trace(self.go.Scatter(x=line_x, y=line_y, mode='lines', name=f'Fit (R²={r**2:.3f})'))
        fig.update_xaxes(title_text=f'Theoretical Quantiles ({dist_name})')
        fig.update_yaxes(title_text=f'Sample Quantiles ({x_col})')
        self._apply_layout(fig, config)
        return fig

    def residualplot_plot(self, config: Dict[str, Any]) -> Any:
        """
        Residual plot (residuals vs fitted).
        Parameters
        ----------
        config : dict
            - x : fitted values column
            - y : residuals column
            - lowess : bool (default True)
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        if not all([x_col, y_col]):
            raise VisualizerError("Residual plot requires 'x' and 'y'")
        x_vals = data[x_col].values
        y_vals = data[y_col].values
        fig = self.go.Figure()
        fig.add_trace(self.go.Scatter(x=x_vals, y=y_vals, mode='markers'))
        if config.get('lowess', True):
            try:
                from statsmodels.nonparametric.smoothers_lowess import lowess
                lowess_res = lowess(y_vals, x_vals, frac=config.get('lowess_frac', 0.3))
                fig.add_trace(self.go.Scatter(x=lowess_res[:, 0], y=lowess_res[:, 1], mode='lines', line=dict(color='red'), name='LOWESS'))
            except ImportError:
                pass
        fig.add_hline(y=0, line_dash='dash', line_color='gray')
        fig.update_xaxes(title_text=x_col)
        fig.update_yaxes(title_text='Residuals')
        self._apply_layout(fig, config)
        return fig

    def rug_plot(self, config: Dict[str, Any]) -> Any:
        """
        Rug plot using shapes.
        Parameters
        ----------
        config : dict
            - x or y : column name
            - height : float (default 0.02)
            - color : str (default 'black')
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        if x_col is None and y_col is None:
            raise VisualizerError("Rug plot requires 'x' or 'y' parameter")
        fig = self.go.Figure()
        color = config.get('color', 'black')
        height = config.get('height', 0.02)
        if x_col is not None:
            x_vals = data[x_col].dropna().values
            for xv in x_vals:
                fig.add_shape(type='line', x0=xv, x1=xv, y0=0, y1=height,
                              line=dict(color=color, width=1), yref='paper')
        if y_col is not None:
            y_vals = data[y_col].dropna().values
            for yv in y_vals:
                fig.add_shape(type='line', x0=0, x1=height, y0=yv, y1=yv,
                              line=dict(color=color, width=1), xref='paper')
        if x_col:
            fig.update_xaxes(title_text=x_col)
        if y_col:
            fig.update_yaxes(title_text=y_col)
        self._apply_layout(fig, config)
        return fig

    def strip_plot(self, config: Dict[str, Any]) -> Any:
        """
        Strip plot (jittered categorical scatter).
        Parameters
        ----------
        config : dict
            - x : categorical column
            - y : numeric column
            - jitter : float (default 0.2)
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        if not all([x_col, y_col]):
            raise VisualizerError("Strip plot requires 'x' and 'y'")
        try:
            fig = self.px.strip(data, x=x_col, y=y_col, **config.get('px_kwargs', {}))
        except AttributeError:
            fig = self.go.Figure()
            categories = data[x_col].unique()
            y_vals_all = []
            x_positions = []
            jitter_width = config.get('jitter', 0.2)
            for i, cat in enumerate(categories):
                mask = data[x_col] == cat
                y_cat = data.loc[mask, y_col].dropna().values
                n = len(y_cat)
                jitter = np.random.uniform(-jitter_width/2, jitter_width/2, n)
                x_positions.extend([i + j for j in jitter])
                y_vals_all.extend(y_cat)
            fig.add_trace(self.go.Scatter(x=x_positions, y=y_vals_all, mode='markers'))
            fig.update_xaxes(tickmode='array', tickvals=list(range(len(categories))), ticktext=list(categories))
            fig.update_xaxes(title_text=x_col)
            fig.update_yaxes(title_text=y_col)
        self._apply_layout(fig, config)
        return fig

    def swarm_plot(self, config: Dict[str, Any]) -> Any:
        """
        Swarm plot (non-overlapping categorical scatter).
        Parameters
        ----------
        config : dict
            - x : categorical column
            - y : numeric column
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        if not all([x_col, y_col]):
            raise VisualizerError("Swarm plot requires 'x' and 'y'")
        categories = data[x_col].dropna().unique()
        n_cats = len(categories)
        fig = self.go.Figure()
        # Simple swarm: avoid overlap by spreading points horizontally
        for i, cat in enumerate(categories):
            y_vals = data[data[x_col] == cat][y_col].dropna().values
            if len(y_vals) == 0:
                continue
            # Sort by y to help with positioning
            y_sorted = np.sort(y_vals)
            # Compute x positions based on local density
            # This is a simplified swarm; we'll use small random jitter if points overlap
            x_pos = np.full(len(y_sorted), i, dtype=float)
            # If many points have same y, need to adjust x
            # Use a simple approach: for points with close y values, add small horizontal offsets
            if len(y_sorted) > 1:
                y_diff = np.diff(y_sorted)
                close_threshold = (y_sorted[-1] - y_sorted[0]) * 0.02  # 2% of range
                for j in range(1, len(y_sorted)):
                    if y_diff[j-1] < close_threshold:
                        # Nudge x slightly based on index to avoid perfect overlap
                        x_pos[j] += (j % 2) * 0.1 - 0.05  # jitter ±0.05
            fig.add_trace(self.go.Scatter(x=x_pos, y=y_sorted, mode='markers', name=str(cat)))
        fig.update_xaxes(tickmode='array', tickvals=list(range(n_cats)), ticktext=list(categories))
        fig.update_xaxes(title_text=x_col)
        fig.update_yaxes(title_text=y_col)
        self._apply_layout(fig, config)
        return fig

    def boxen_plot(self, config: Dict[str, Any]) -> Any:
        """
        Boxen plot (letter-value plot) showing extended quantiles.
        Parameters
        ----------
        config : dict
            - x : categorical column (optional)
            - y : numeric column
            - orient : 'v' (default) or 'h'
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        x_col = config.get('x')
        y_col = config.get('y')
        orient = config.get('orient', 'v')
        if y_col is None:
            raise VisualizerError("Boxen plot requires 'y' parameter")
        fig = self.go.Figure()
        if x_col is not None:
            categories = data[x_col].dropna().unique()
        else:
            categories = [None]
        # For each category, compute letter-value statistics
        for i, cat in enumerate(categories):
            if cat is None:
                vals = data[y_col].dropna().values
            else:
                vals = data[data[x_col] == cat][y_col].dropna().values
            if len(vals) == 0:
                continue
            # Compute quantiles: median, quartiles, and additional percentiles
            quantiles = [0.5, 0.25, 0.75, 0.125, 0.875, 0.0625, 0.9375, 0.03125, 0.96875]
            q_vals = np.percentile(vals, [int(q*100) for q in quantiles])
            # Box width
            width = 0.6
            x_center = i if orient == 'v' else 0
            # Draw nested boxes (letter-values)
            # Use different box sizes for each quantile level
            for idx, q in enumerate(quantiles):
                q_val = q_vals[idx]
                # Box width decreases for outer quantiles
                box_w = width * (0.8 ** idx) if orient == 'v' else width * (0.8 ** idx)
                x0 = x_center - box_w/2
                x1 = x_center + box_w/2
                y0 = q_val - box_w*0.1 if orient == 'h' else q_val - box_w*0.1  # minimal padding
                y1 = q_val + box_w*0.1 if orient == 'h' else q_val + box_w*0.1
                if orient == 'v':
                    fig.add_trace(self.go.Scatter(
                        x=[x0, x1], y=[q_val, q_val],
                        mode='lines', line=dict(color='steelblue', width=2+int(0.5*(len(quantiles)-idx))),
                        showlegend=False
                    ))
                else:
                    fig.add_trace(self.go.Scatter(
                        x=[q_val, q_val], y=[y0, y1],
                        mode='lines', line=dict(color='steelblue', width=2+int(0.5*(len(quantiles)-idx))),
                        showlegend=False
                    ))
            # Add a median line
            med = np.median(vals)
            if orient == 'v':
                fig.add_trace(self.go.Scatter(
                    x=[x_center - width/2, x_center + width/2], y=[med, med],
                    mode='lines', line=dict(color='red', width=3), showlegend=False
                ))
            else:
                fig.add_trace(self.go.Scatter(
                    x=[med, med], y=[x_center - width/2, x_center + width/2],
                    mode='lines', line=dict(color='red', width=3), showlegend=False
                ))
        # Layout
        if x_col:
            if orient == 'v':
                fig.update_xaxes(tickmode='array', tickvals=list(range(len(categories))), ticktext=[str(c) for c in categories])
                fig.update_xaxes(title_text=x_col)
                fig.update_yaxes(title_text=y_col)
            else:
                fig.update_yaxes(tickmode='array', tickvals=list(range(len(categories))), ticktext=[str(c) for c in categories])
                fig.update_yaxes(title_text=x_col)
                fig.update_xaxes(title_text=y_col)
        else:
            if orient == 'v':
                fig.update_xaxes(title_text='Value')
            else:
                fig.update_yaxes(title_text='Value')
        self._apply_layout(fig, config)
        return fig

    def andrews_curves_plot(self, config: Dict[str, Any]) -> Any:
        """
        Andrews curves for multivariate data visualization.
        Parameters
        ----------
        config : dict
            - data : DataFrame
            - x : class column name (categorical)
            - columns : list of numeric columns (features)
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        class_col = config.get('x')
        feature_cols = config.get('columns')
        if class_col is None or feature_cols is None:
            raise VisualizerError("Andrews curves requires 'x' (class) and 'columns' (features)")
        df_subset = data[[class_col] + feature_cols].dropna()
        if len(df_subset) == 0:
            raise VisualizerError("No valid data after dropping NaNs")
        classes = sorted(df_subset[class_col].dropna().unique())
        m = len(feature_cols)
        t = np.linspace(-np.pi, np.pi, 200)
        fig = self.go.Figure()
        # Precompute colors
        color_cycle = self.go.Figure().layout.template.layout.colorway or ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf']
        for idx, cls in enumerate(classes):
            class_data = df_subset[df_subset[class_col] == cls][feature_cols].values
            if len(class_data) == 0:
                continue
            color = color_cycle[idx % len(color_cycle)]
            # For each sample
            for sample in class_data:
                # Normalize
                mean = np.mean(sample)
                std = np.std(sample)
                if std == 0:
                    normalized = sample - mean
                else:
                    normalized = (sample - mean) / std
                # Compute Andrews curve: f(t) = X0/√2 + Σ [X_{2k} sin(kt) + X_{2k+1} cos(kt)]
                # Note: features are X0, X1, X2, ... (0-indexed)
                # X0/√2 + X1 sin(t) + X2 cos(t) + X3 sin(2t) + X4 cos(2t) + ...
                f_t = normalized[0] / np.sqrt(2)
                for k in range(1, len(normalized)):
                    if k % 2 == 1:  # odd index (1,3,5,...) -> sin(ceil(k/2)*t)
                        coeff = (k + 1) // 2
                        f_t += normalized[k] * np.sin(coeff * t)
                    else:  # even index (2,4,6,...) -> cos(k/2 * t)
                        coeff = k // 2
                        f_t += normalized[k] * np.cos(coeff * t)
                # Normalize f_t to avoid huge values
                if np.max(np.abs(f_t)) > 0:
                    f_t = f_t / np.max(np.abs(f_t))
                fig.add_trace(self.go.Scatter(x=t, y=f_t, mode='lines', line=dict(color=color, width=1), opacity=0.6, showlegend=False))
            # Add a trace for legend entry for this class only once
            if len(class_data) > 0:
                fig.add_trace(self.go.Scatter(x=[None], y=[None], mode='lines', line=dict(color=color, width=2), name=str(cls)))
        fig.update_xaxes(title_text='t')
        fig.update_yaxes(title_text='f(t)')
        fig.update_xaxes(tickmode='array', tickvals=[-np.pi, -np.pi/2, 0, np.pi/2, np.pi], ticktext=['-π', '-π/2', '0', 'π/2', 'π'])
        self._apply_layout(fig, config)
        return fig

    def radviz_plot(self, config: Dict[str, Any]) -> Any:
        """
        RadViz plot (radial visualization of multivariate data).
        Parameters
        ----------
        config : dict
            - data : DataFrame
            - x : class column (categorical)
            - columns : list of numeric feature columns
            - **kwargs
        Returns
        -------
        fig : plotly.graph_objects.Figure
        """
        data = config['data']
        class_col = config.get('x')
        feature_cols = config.get('columns')
        if class_col is None or feature_cols is None:
            raise VisualizerError("RadViz requires 'x' (class) and 'columns' (features)")
        df_subset = data[[class_col] + feature_cols].dropna()
        if len(df_subset) == 0:
            raise VisualizerError("No valid data")
        m = len(feature_cols)
        # Anchor points on unit circle
        angles = np.linspace(0, 2*np.pi, m, endpoint=False)
        anchor_x = np.cos(angles)
        anchor_y = np.sin(angles)
        fig = self.go.Figure()
        colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf']
        class_colors = {cls: colors[i % len(colors)] for i, cls in enumerate(sorted(df_subset[class_col].unique()))}
        # Plot anchor points and labels
        fig.add_trace(self.go.Scatter(x=anchor_x.tolist(), y=anchor_y.tolist(), mode='markers+text',
                                      marker=dict(size=12, color='black', symbol='square'),
                                      text=feature_cols, textposition='top center',
                                      showlegend=False, hoverinfo='skip'))
        # For each sample, compute RadViz position
        for cls in sorted(df_subset[class_col].unique()):
            class_data = df_subset[df_subset[class_col] == cls]
            xs, ys = [], []
            for _, row in class_data[feature_cols].iterrows():
                values = row[feature_cols].values.astype(float)
                # Normalize to sum to 1 (Softmax-like)
                if np.sum(values) == 0:
                    weights = np.ones(m) / m
                else:
                    # Optionally normalize by feature min/max to equalize influence?
                    # For now, just use actual values
                    weights = values / np.sum(values)
                x_pos = np.sum(weights * anchor_x)
                y_pos = np.sum(weights * anchor_y)
                xs.append(x_pos)
                ys.append(y_pos)
            fig.add_trace(self.go.Scatter(x=xs, y=ys, mode='markers', name=str(cls),
                                          marker=dict(size=8, opacity=0.7, line=dict(width=0.5, color='black')),
                                          showlegend=True, hoverinfo='skip'))
        # Draw reference circle
        theta = np.linspace(0, 2*np.pi, 200)
        fig.add_trace(self.go.Scatter(x=np.cos(theta).tolist(), y=np.sin(theta).tolist(),
                                      mode='lines', line=dict(color='gray', dash='dash'), showlegend=False, hoverinfo='skip'))
        fig.update_xaxes(range=[-1.2, 1.2], title_text='', showgrid=False, zeroline=False, visible=False)
        fig.update_yaxes(range=[-1.2, 1.2], title_text='', showgrid=False, zeroline=False, visible=False, scaleanchor='x', scaleratio=1)
        fig.update_layout(width=500, height=500)
        self._apply_layout(fig, config)
        return fig

    def show(self, fig):
        """Display plotly figure (opens in browser)."""
        fig.show()

    def to_html(self, fig, full_html=True) -> str:
        """
        Convert figure to HTML string.
        """
        return fig.to_html(full_html=full_html)

    def write_html(self, fig, filepath: str, full_html=True):
        """
        Write figure to HTML file.
        """
        fig.write_html(filepath, full_html=full_html)

    def close(self, fig=None):
        """Plotly doesn't need explicit closing."""
        pass

    def _generate_window_title(self, config: Dict[str, Any]) -> str:
        """Generate window title for figure."""
        title = config.get('title', 'BottleViz Plot')
        kind = config.get('kind', 'plot')
        return f"{kind.capitalize()}: {title}"


def raise_(ex):
    raise ex


# Convenience functions
def show_plotly(data, kind: str, open_browser: bool = False, **kwargs) -> str:
    """
    Create an interactive Plotly visualization and return as HTML.

    This is an alternative to vz.show() that renders interactive
    plots using Plotly with zoom, pan, hover tooltips, etc.

    Parameters
    ----------
    data : DataFrame, Series, etc.
        Data to plot
    kind : str
        Plot type (same as vz.plot())
    open_browser : bool, default False
        If True, automatically opens the plot in the default web browser.
        The HTML is still returned as a string.
    **kwargs
        Additional arguments passed to vz.plot()

    Returns
    -------
    str
        HTML string with embedded interactive plot

    Example
    -------
    >>> import bottleviz as vz
    >>> import pandas as pd
    >>> df = pd.DataFrame({'x': [1,2,3], 'y': [4,5,6]})
    >>> html = vz.show_plotly(df, x='x', y='y', kind='scatter')
    >>> # Save to file
    >>> with open('plot.html', 'w') as f:
    ...     f.write(html)
    >>> # Or display in Jupyter
    >>> from IPython.display import HTML
    >>> HTML(html)
    >>> # Or automatically open in browser
    >>> vz.show_plotly(df, x='x', y='y', kind='scatter', open_browser=True)
    """
    import bottleviz as vz

    # Temporarily set plotly backend
    original_backend = None
    try:
        # Import here to avoid circular imports
        from ..publishers import backends

        # Get or register plotly backend
        if 'plotly' not in backends._backends:
            backends.register_backend('plotly', PlotlyBackend())

        # Switch to plotly backend temporarily
        original_backend = backends._active_backend
        backends.set_backend('plotly')

        # Create plot
        fig = vz.plot(data, kind=kind, **kwargs)

        # Revert to original backend
        if original_backend:
            backends._active_backend = original_backend

        # Convert to HTML
        plotly_backend = backends._backends['plotly']
        html = plotly_backend.to_html(fig, full_html=kwargs.get('full_html', True))

        # Optionally open in browser
        if open_browser:
            import tempfile
            import webbrowser
            import pathlib

            # Create temporary file with HTML
            with tempfile.NamedTemporaryFile(
                mode='w',
                suffix='.html',
                delete=False,
                encoding='utf-8'
            ) as f:
                f.write(html)
                temp_path = f.name

            # Open in browser (file:// URI)
            try:
                webbrowser.open(f'file://{pathlib.Path(temp_path).resolve()}')
            except Exception as e:
                # Log but don't fail if browser can't open
                import warnings
                warnings.warn(f"Failed to open browser: {e}. HTML saved to temp file: {temp_path}")

        return html

    except Exception as e:
        # Restore backend on error
        if original_backend:
            backends._active_backend = original_backend
        raise VisualizerError(f"Failed to create Plotly visualization: {e}") from e


def save_plotly(data, filepath: str, kind: str, open_browser: bool = False, **kwargs):
    """
    Create an interactive Plotly visualization and save to HTML file.

    Parameters
    ----------
    data : DataFrame, Series, etc.
        Data to plot
    filepath : str
        Output HTML file path
    kind : str
        Plot type
    open_browser : bool, default False
        If True, automatically opens the saved file in the default web browser.
    **kwargs
        Additional arguments passed to vz.plot()

    Example
    -------
    >>> import bottleviz as vz
    >>> df = pd.DataFrame({'x': [1,2,3], 'y': [4,5,6]})
    >>> vz.save_plotly(df, 'interactive_plot.html', x='x', y='y', kind='scatter')
    >>> # Save and automatically open
    >>> vz.save_plotly(df, 'interactive_plot.html', x='x', y='y', kind='scatter', open_browser=True)
    """
    html = show_plotly(data, kind=kind, open_browser=False, **kwargs)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(html)

    if open_browser:
        import webbrowser
        import pathlib
        try:
            webbrowser.open(f'file://{pathlib.Path(filepath).resolve()}')
        except Exception as e:
            import warnings
            warnings.warn(f"Failed to open browser: {e}. File saved to: {filepath}")
