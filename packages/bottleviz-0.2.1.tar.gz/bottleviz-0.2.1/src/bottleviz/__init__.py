"""
BottleWiz - A modern Python data visualization library.

Addresses gaps in Matplotlib, Seaborn, and Plotly by providing:
- Simple, intuitive API
- Excellent performance with large datasets
- Beautiful defaults out of the box
- Seamless pandas/polars integration
- Smart automatic plot type selection
"""

__version__ = "0.2.0"
__author__ = "Pavan Paari - DHS Tech"

# Core imports
from .core.core import (
    plot, visualize, quickplot, show, close, figure3d,
    figure, subplots, inset,
    plot_3d_surface, plot_3d_wireframe, plot_3d_trisurf,
    plot_3d_contour, plot_3d_contourf, plot_3d_quiver,
    plot_3d_stem, plot_3d_bar, plot_3d_voxels
)
from .publishers.backends import get_backend
from .core.styles import set_style, available_styles, get_current_style
from .processors.auto import suggest_plots, report, explore, compare, save_report
from .utils.utils import optimize_for_large_data

# Plotly interactive backend (optional)
try:
    from .publishers.plotly_backend import show_plotly, save_plotly
    _has_plotly_backend = True
except ImportError:
    _has_plotly_backend = False

# Re-export key types
from .core.types import DataProfile, ColumnInfo

__all__ = [
    # Main plotting functions
    "plot",
    "visualize",
    "quickplot",
    "figure3d",
    "figure",
    "subplots",
    "inset",
    # 3D plotting functions
    "plot_3d_surface",
    "plot_3d_wireframe",
    "plot_3d_trisurf",
    "plot_3d_contour",
    "plot_3d_contourf",
    "plot_3d_quiver",
    "plot_3d_stem",
    "plot_3d_bar",
    "plot_3d_voxels",
    # Display functions
    "show",
    "close",
    # Backend management
    "get_backend",
    # Style customization
    "set_style",
    "available_styles",
    "get_current_style",
    # Automated features
    "suggest_plots",
    "report",
    "save_report",
    "explore",
    "compare",
    # Utilities
    "optimize_for_large_data",
    # Types
    "DataProfile",
    "ColumnInfo",
]

# Conditionally add plotly functions to __all__
if _has_plotly_backend:
    __all__.extend(["show_plotly", "save_plotly"])
