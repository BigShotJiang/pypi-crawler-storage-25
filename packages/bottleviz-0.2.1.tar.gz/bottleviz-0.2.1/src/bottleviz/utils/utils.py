"""
Utility functions for BottleViz.

Data validation, type inference, and helper functions.
"""

from typing import Any, Dict, List, Union, Tuple, Optional
import warnings
import numpy as np
import pandas as pd

from ..core.exceptions import DataError

# Try to import polars for Polars DataFrame support
try:
    import polars as pl
    POLARS_AVAILABLE = True
except ImportError:
    POLARS_AVAILABLE = False
    pl = None


def validate_data(
    data: Any,
    x: Optional[str] = None,
    y: Optional[Union[str, List[str]]] = None
) -> pd.DataFrame:
    """
    Validate and convert input data to pandas DataFrame.

    Parameters
    ----------
    data : DataFrame, Series, ndarray, list, dict, or Polars DataFrame
        Input data to validate
    x : str, optional
        x-axis column name (for validation)
    y : str or list of str, optional
        y-axis column name(s) (for validation)

    Returns
    -------
    pd.DataFrame
        Validated and converted data

    Raises
    ------
    DataError
        If data is invalid or conversion fails
    """
    if data is None:
        raise DataError("Data cannot be None")

    # Convert to DataFrame
    if isinstance(data, pd.DataFrame):
        df = data.copy()
    elif POLARS_AVAILABLE and isinstance(data, pl.DataFrame):
        # Convert Polars DataFrame to pandas
        try:
            df = data.to_pandas()
        except Exception as e:
            raise DataError(f"Failed to convert Polars DataFrame to pandas: {e}")
    elif isinstance(data, pd.Series):
        df = data.to_frame()
    elif isinstance(data, np.ndarray):
        if data.ndim == 1:
            df = pd.DataFrame({'_values': data})
        elif data.ndim == 2:
            # Try to create meaningful column names
            n_cols = data.shape[1]
            if n_cols == 1:
                df = pd.DataFrame({'_values': data[:, 0]})
            else:
                col_names = [f'col_{i}' for i in range(n_cols)]
                df = pd.DataFrame(data, columns=col_names)
        else:
            raise DataError(
                f"NumPy array must be 1D or 2D, got {data.ndim}D array"
            )
    elif isinstance(data, (list, tuple)):
        if all(isinstance(x, (int, float)) for x in data):
            # Simple numeric list
            df = pd.DataFrame({'_values': data})
        else:
            # List of records or mixed
            try:
                df = pd.DataFrame(data)
            except Exception as e:
                raise DataError(f"Cannot convert list to DataFrame: {e}")
    elif isinstance(data, dict):
        # Dictionary of arrays/series
        try:
            df = pd.DataFrame(data)
        except Exception as e:
            raise DataError(f"Cannot convert dict to DataFrame: {e}")
    else:
        supported_types = ["DataFrame", "Series", "ndarray", "list", "dict"]
        if POLARS_AVAILABLE:
            supported_types.append("Polars DataFrame")
        raise DataError(
            f"Unsupported data type: {type(data).__name__}. "
            f"Supported: {', '.join(supported_types)}"
        )

    # Validate row count
    if len(df) == 0:
        raise DataError("Data contains no rows")

    # Validate column existence
    if x is not None and x not in df.columns:
        raise DataError(f"Column '{x}' not found in data. Available: {list(df.columns)}")

    if y is not None:
        if isinstance(y, (list, tuple)):
            missing = [col for col in y if col not in df.columns]
            if missing:
                raise DataError(
                    f"Columns not found: {missing}. "
                    f"Available: {list(df.columns)}"
                )
        elif isinstance(y, str) and y not in df.columns:
            raise DataError(f"Column '{y}' not found in data. Available: {list(df.columns)}")

    return df


def infer_plot_type(
    df: pd.DataFrame,
    x: Optional[str] = None,
    y: Optional[Union[str, List[str]]] = None
) -> str:
    """
    Intelligently infer the best plot type from data characteristics.

    Parameters
    ----------
    df : pd.DataFrame
        Validated data
    x : str, optional
        x-axis column
    y : str or list of str, optional
        y-axis column(s)

    Returns
    -------
    str
        Inferred plot type: 'line', 'scatter', 'bar', 'hist', 'box',
        'violin', 'heatmap', 'pie', 'area', 'kde', '3d', 'hexbin',
        'step', 'fill_between', 'contour', 'pcolormesh', 'quiver',
        'spy', 'polar', 'table', 'eventplot', 'stacked_bar', 'grouped_bar'
    """
    # Default to scatter if both x and y provided
    if x is not None and y is not None:
        # Check if x is numeric and y exists
        if pd.api.types.is_numeric_dtype(df[x]):
            # For very large datasets, hexbin is better
            if len(df) > 50000:
                return 'hexbin'
            # Most likely scatter or line
            # If data is sorted by x, it might be a line plot
            if len(df) > 1:
                # Check if x is sorted (simple heuristic)
                x_sorted = df[x].is_monotonic_increasing or df[x].is_monotonic_decreasing
                if x_sorted:
                    return 'line'
                else:
                    return 'scatter'
            return 'scatter'
        else:
            # If x is categorical, probably a bar chart
            return 'bar'

    # If only y provided
    if y is not None and x is None:
        y_cols = [y] if isinstance(y, str) else y
        if len(y_cols) == 1:
            # Single column - histogram or KDE
            return 'hist'
        else:
            # Multiple columns - could be line (if each represents a series)
            return 'line'

    # If only x provided
    if x is not None and y is None:
        # Single categorical variable - bar or pie
        if pd.api.types.is_numeric_dtype(df[x]):
            return 'hist'
        else:
            # Categorical - could be bar or pie
            n_unique = df[x].nunique()
            if n_unique <= 6:
                return 'pie'
            else:
                return 'bar'

    # If neither x nor y explicitly provided
    if x is None and y is None:
        # Try to infer from data structure
        numeric_cols = df.select_dtypes(include='number').columns.tolist()

        if len(numeric_cols) == 0:
            # No numeric data - probably categorical counts
            first_col = df.columns[0]
            n_unique = df[first_col].nunique()
            if n_unique <= 10:
                return 'pie'
            else:
                return 'bar'

        elif len(numeric_cols) == 1:
            # Single numeric column - histogram
            return 'hist'

        elif len(numeric_cols) == 2:
            # Two numeric columns - scatter
            return 'scatter'

        elif len(numeric_cols) >= 3:
            # For 3+ numeric columns, consider the index type
            if pd.api.types.is_datetime64_any_dtype(df.index):
                return 'line'
            else:
                # Multiple numeric columns - box plot to compare distributions
                return 'box'


def infer_color_palette(n_colors: int, palette: str = 'default') -> List[str]:
    """
    Generate a color palette with n_colors colors.

    Parameters
    ----------
    n_colors : int
        Number of colors needed
    palette : str
        Palette name: 'default', 'dark', 'seaborn', 'colorblind', etc.

    Returns
    -------
    list of str
        List of color hex codes
    """
    palettes = {
        'default': [
            '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
            '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
        ],
        'colorblind': [
            '#0072B2', '#E69F00', '#56B4E9', '#009E73', '#F0E442',
            '#0072B2', '#D55E00', '#CC79A7'
        ],
        'dark': [
            '#4c72b0', '#dd8452', '#55a868', '#c44e52', '#8172b3',
            '#937860', '#da8bc3', '#8c8c8c', '#ccb974', '#64b5cd'
        ],
        'pastel': [
            '#92c5de', '#fdb863', '#b2df8a', '#fb9a99', '#a6cee3',
            '#fdbf6f', '#b15928', '#6a3d9a', '#ffff99', '#b3de69'
        ]
    }

    if palette not in palettes:
        palette = 'default'

    base_colors = palettes[palette]

    # If we need more colors than available, cycle
    if n_colors <= len(base_colors):
        return base_colors[:n_colors]
    else:
        # Repeat the palette to get enough colors
        result = []
        for i in range(n_colors):
            result.append(base_colors[i % len(base_colors)])
        return result


def optimize_for_large_data(
    df: pd.DataFrame,
    max_points: int = 10000
) -> pd.DataFrame:
    """
    Optimize data for plotting by downsampling if too large.

    For datasets larger than max_points, performs intelligent downsampling
    to maintain visual quality while improving performance.

    Parameters
    ----------
    df : pd.DataFrame
        Data to optimize
    max_points : int
        Maximum number of points to plot

    Returns
    -------
    pd.DataFrame
        Downsampled data (or original if already small)
    """
    if len(df) <= max_points:
        return df

    # Simple random sampling for now
    # Could be enhanced with LTTB (Largest Triangle Three Buckets) for line charts
    sampled = df.sample(n=max_points, random_state=42)
    warnings.warn(
        f"Data has {len(df)} rows (>{max_points}). Downsampled to {max_points} points. "
        "For more sophisticated downsampling, use the 'datashader' backend.",
        UserWarning
    )
    return sampled


def is_datetime_column(series: pd.Series) -> bool:
    """
    Check if a series contains datetime data.

    Parameters
    ----------
    series : pd.Series
        Series to check

    Returns
    -------
    bool
        True if series is datetime-like
    """
    return (
        pd.api.types.is_datetime64_any_dtype(series) or
        pd.api.types.is_timedelta64_dtype(series) or
        (series.dtype == 'object' and
         pd.to_datetime(series, errors='coerce').notna().any())
    )


def is_categorical(series: pd.Series, max_unique: int = 20) -> bool:
    """
    Check if a series should be treated as categorical.

    Parameters
    ----------
    series : pd.Series
        Series to check
    max_unique : int
        Maximum number of unique values to consider categorical

    Returns
    -------
    bool
        True if series appears categorical
    """
    dtype = series.dtype
    is_object = dtype == 'object' or dtype.name == 'category'
    n_unique = series.nunique()

    return (is_object or n_unique <= max_unique) and n_unique < len(series) * 0.5
