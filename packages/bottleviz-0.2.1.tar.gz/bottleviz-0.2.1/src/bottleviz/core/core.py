"""
Core plotting functionality for BottleWiz.

This module provides the main plotting functions with smart defaults
and intuitive APIs.
"""

import warnings
from typing import Any, Dict, List, Optional, Union
import numpy as np
import pandas as pd

from .styles import get_current_style
from ..publishers.backends import get_backend
from ..utils.utils import infer_plot_type, validate_data
from .exceptions import VisualizerError, DataError


def plot(
    data: Union[pd.DataFrame, pd.Series, np.ndarray, List, Dict],
    x: Optional[str] = None,
    y: Optional[Union[str, List[str]]] = None,
    kind: Optional[str] = None,
    **kwargs
) -> Any:
    """
    Main plotting function with smart defaults.

    Creates visualizations with minimal code. Automatically infers plot type
    based on data structure if not specified.

    Parameters
    ----------
    data : pd.DataFrame, pd.Series, np.ndarray, list, or dict
        The data to plot
    x : str, optional
        Column name for x-axis (for DataFrame) or data for x-axis
    y : str or list of str, optional
        Column name(s) for y-axis
    kind : str, optional
        Plot type: 'line', 'scatter', 'bar', 'hist', 'box', 'violin',
        'heatmap', 'pie', 'area', 'kde', '3d', 'stem', 'errorbar',
        'sankey', 'sunburst', 'treemap', 'network', 'candlestick', etc.
        If None, automatically inferred from data
    **kwargs
        Additional arguments passed to the specific plot function

    Returns
    -------
    Figure or Axes object from the backend

    Examples
    --------
    >>> import bottlewiz as vz
    >>> import pandas as pd
    >>> df = pd.DataFrame({'x': [1,2,3], 'y': [4,5,6]})
    >>> vz.plot(df, x='x', y='y')  # Auto-detects scatter/line

    >>> vz.plot([1,2,3,4,5])  # Auto-detects line plot from list

    >>> vz.plot(df, kind='hist')  # Force histogram
    """
    try:
        # Validate and convert data
        df = validate_data(data, x, y)

        # Infer plot type if not specified
        if kind is None:
            kind = infer_plot_type(df, x, y)

        # Get current style and backend
        style = get_current_style()
        backend = get_backend()

        # Build plot configuration
        config = {
            'data': df,
            'x': x,
            'y': y,
            'kind': kind,
            'style': style,
            **kwargs
        }

        # Create plot using backend
        result = _create_plot(backend, config)

        return result

    except Exception as e:
        if isinstance(e, VisualizerError):
            raise
        raise VisualizerError(f"Failed to create plot: {str(e)}") from e


def quickplot(
    *args,
    **kwargs
) -> Any:
    """
    Ultra-simple plotting for one-liners.

    Even simpler than plot() - tries to do the right thing with minimal input.

    Supports:
    - quickplot(data)                : plot with auto-detection
    - quickplot(x=..., y=...)        : plot from two sequences
    - quickplot(list)                : line plot from list
    - quickplot(list1, list2)        : scatter from two lists

    Examples
    --------
    >>> quickplot([1,2,3,4,5])  # Line plot from list
    >>> quickplot([1,2,3], [4,5,6])  # Scatter from two lists
    >>> quickplot(x=[1,2,3], y=[4,5,6])  # Named arguments
    """
    # Case 1: x and y provided as keyword arguments -> construct DataFrame
    if not args and 'x' in kwargs and 'y' in kwargs:
        x = kwargs.pop('x')
        y = kwargs.pop('y')
        import pandas as pd
        data = pd.DataFrame({'x': x, 'y': y})
        return plot(data, x='x', y='y', **kwargs)

    # Case 2: two positional arguments (likely two sequences)
    elif len(args) == 2 and 'data' not in kwargs:
        # Interpret as x_data, y_data
        import pandas as pd
        data = pd.DataFrame({'x': args[0], 'y': args[1]})
        return plot(data, x='x', y='y', **kwargs)

    # Case 3: single positional argument or explicit data
    else:
        return plot(*args, **kwargs)


def visualize(
    data: Any,
    columns: Optional[List[str]] = None,
    plot_type: str = 'auto',
    max_plots: int = 6,
    **kwargs
) -> Any:
    """
    Create comprehensive visualization dashboard for a dataset.

    Automatically generates multiple plots to explore data characteristics.
    Ideal for exploratory data analysis (EDA).

    Parameters
    ----------
    data : DataFrame or array-like
        Data to visualize
    columns : list of str, optional
        Specific columns to plot. If None, uses all numeric columns
    plot_type : str, default 'auto'
        Type of visualization: 'auto', 'all', 'distribution', 'correlation'
    max_plots : int, default 6
        Maximum number of subplots to create
    **kwargs
        Additional plotting arguments

    Returns
    -------
    Figure with multiple subplots
    """
    df = validate_data(data)

    if columns is None:
        # Auto-select numeric columns
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        columns = numeric_cols[:max_plots]

    # Create a figure with subplots
    n_cols = min(3, len(columns))
    n_rows = (len(columns) + n_cols - 1) // n_cols

    style = get_current_style()
    backend = get_backend()

    # Build multi-plot configuration
    config = {
        'data': df,
        'columns': columns,
        'plot_type': plot_type,
        'n_rows': n_rows,
        'n_cols': n_cols,
        'style': style,
        **kwargs
    }

    return _create_visualization_dashboard(backend, config)


def _create_plot(backend, config: Dict[str, Any]) -> Any:
    """
    Internal function to create a single plot using the backend.

    Parameters
    ----------
    backend : module
        The rendering backend (matplotlib, plotly, etc.)
    config : dict
        Plot configuration

    Returns
    -------
    Backend-specific figure/axes object
    """
    kind = config['kind']

    # Map plot kinds to backend functions
    plot_funcs = {
        'line': backend.line_plot,
        'scatter': backend.scatter_plot,
        'bar': backend.bar_plot,
        'stacked_bar': backend.stacked_bar_plot,
        'grouped_bar': backend.grouped_bar_plot,
        'hist': backend.hist_plot,
        'box': backend.box_plot,
        'violin': backend.violin_plot,
        'heatmap': backend.heatmap_plot,
        'pcolormesh': backend.pcolormesh_plot,
        'pie': backend.pie_plot,
        'area': backend.area_plot,
        'kde': backend.kde_plot,
        '3d': backend.plot_3d,
        'figure3d': backend.figure3d,
        'stem': backend.stem_plot,
        'errorbar': backend.errorbar_plot,
        'sankey': backend.sankey_plot,
        'sunburst': backend.sunburst_plot,
        'treemap': backend.treemap_plot,
        'network': backend.network_plot,
        'candlestick': backend.candlestick_plot,
        'hexbin': backend.hexbin_plot,
        'step': backend.step_plot,
        'fill_between': backend.fill_between_plot,
        'contour': backend.contour_plot,
        'quiver': backend.quiver_plot,
        'spy': backend.spy_plot,
        'polar': backend.polar_plot,
        # Geographic & Map visualizations
        'cartogram': backend.cartogram_plot,
        'choropleth': backend.choropleth_plot,
        'flow_map': backend.flow_map_plot,
        'scatter_geo': backend.scatter_geo_plot,
        'tile_map': backend.tile_map_plot,
        'table': backend.table_plot,
        'eventplot': backend.eventplot_plot,
        'waterfall': backend.waterfall_plot,
        'gantt': backend.gantt_plot,
        'ohlc_volume': backend.ohlc_volume_plot,
        # Advanced/Scientific plots
        'streamplot': backend.streamplot_plot,
        'tricontour': backend.tricontour_plot,
        'tricontourf': backend.tricontourf_plot,
        # Statistical & Seaborn-style plots
        'pairplot': backend.pairplot_plot,
        'jointplot': backend.jointplot_plot,
        'boxen': backend.boxen_plot,
        'rug': backend.rug_plot,
        'strip': backend.strip_plot,
        'swarm': backend.swarm_plot,
        'qqplot': backend.qqplot_plot,
        'residualplot': backend.residualplot_plot,
        'autocorrelation': backend.autocorrelation_plot,
        'lagplot': backend.lagplot_plot,
        'andrews_curves': backend.andrews_curves_plot,
        'parallel_coordinates': backend.parallel_coordinates_plot,
        'radviz': backend.radviz_plot,
    }

    if kind not in plot_funcs:
        raise VisualizerError(f"Unsupported plot type: {kind}")

    return plot_funcs[kind](config)


def _create_visualization_dashboard(backend, config: Dict[str, Any]) -> Any:
    """
    Internal function to create a multi-plot dashboard.
    """
    return backend.create_dashboard(config)


def show() -> None:
    """
    Display all pending figures.

    This function shows all created plots without requiring matplotlib imports.
    Works with the currently active backend.

    Examples
    --------
    >>> import bottlewiz as vz
    >>> fig = vz.plot(data, x='col1', y='col2')
    >>> vz.show()  # Displays the plot
    """
    backend = get_backend()
    backend.show()


def close(fig: Optional[Any] = None) -> None:
    """
    Close a figure or all figures.

    Parameters
    ----------
    fig : Figure, optional
        Specific figure to close. If None, closes all figures.

    Examples
    --------
    >>> import bottlewiz as vz
    >>> fig = vz.plot(data, x='col1', y='col2')
    >>> vz.show()
    >>> vz.close()  # Clean up all figures
    >>> # or close a specific figure:
    >>> vz.close(fig)
    """
    backend = get_backend()
    backend.close(fig)


def figure3d(
    xlabel: str = 'X',
    ylabel: str = 'Y',
    zlabel: str = 'Z',
    title: Optional[str] = None,
    **kwargs
) -> Any:
    """
    Create an empty 3D figure and return (fig, ax).

    This allows manual plotting on the axes, useful for advanced
    visualizations like multiple surfaces or custom 3D plots.

    Parameters
    ----------
    xlabel : str
        Label for x-axis
    ylabel : str
        Label for y-axis
    zlabel : str
        Label for z-axis
    title : str, optional
        Plot title
    **kwargs
        Additional arguments (figsize, etc.)

    Returns
    -------
    tuple
        (fig, ax) tuple with matplotlib figure and 3D axes

    Examples
    --------
    >>> import bottlewiz as vz
    >>> import numpy as np
    >>> fig, ax = vz.figure3d(title='My 3D Plot')
    >>> # Add custom surfaces or plots to ax
    >>> vz.show()
    """
    backend = get_backend()
    config = {
        'kind': 'figure3d',
        'xlabel': xlabel,
        'ylabel': ylabel,
        'zlabel': zlabel,
        'title': title,
        **kwargs
    }
    return backend.figure3d(config)


def subplots(
    n_rows: int = 2,
    n_cols: int = 2,
    sharex: bool = False,
    sharey: bool = False,
    figsize: tuple = (12, 8),
    title: Optional[str] = None,
    **kwargs
) -> Any:
    """
    Create a figure with multiple subplots sharing axes.

    This is a convenience wrapper around plt.subplots().

    Parameters
    ----------
    n_rows, n_cols : int
        Number of rows and columns in the subplot grid
    sharex, sharey : bool
        Whether to share x/y axes across subplots
    figsize : tuple
        Figure size (width, height)
    title : str, optional
        Overall figure title
    **kwargs
        Additional arguments passed to backend or matplotlib

    Returns
    -------
    tuple
        (fig, axes) where axes is a 2D numpy array of Axes objects

    Examples
    --------
    >>> import bottlewiz as vz
    >>> fig, axes = vz.subplots(2, 2, sharex=True, figsize=(10, 8))
    >>> axes[0,0].plot([1,2,3], [4,5,6])
    >>> vz.show()
    """
    backend = get_backend()
    config = {
        'kind': 'subplots',
        'n_rows': n_rows,
        'n_cols': n_cols,
        'sharex': sharex,
        'sharey': sharey,
        'figsize': figsize,
        'title': title,
        **kwargs
    }
    return backend.subplots_plot(config)


def figure(figsize=None, **kwargs):
    """
    Create a new figure with a single axes.

    Parameters
    ----------
    figsize : tuple, optional
        Figure size (width, height)
    **kwargs
        Additional arguments (facecolor, edgecolor, etc.) passed to subplots

    Returns
    -------
    tuple
        (fig, ax) - matplotlib Figure and Axes

    Examples
    --------
    >>> import bottlewiz as vz
    >>> fig, ax = vz.figure()
    >>> ax.plot([1, 2, 3], [4, 5, 6])
    >>> vz.show()
    """
    backend = get_backend()
    config = {
        'kind': 'subplots',
        'n_rows': 1,
        'n_cols': 1,
        'figsize': figsize,
        **kwargs
    }
    fig, axes = backend.subplots_plot(config)
    # axes is a 2D array (1, 1)
    ax = axes[0, 0]
    return fig, ax


def inset(
    x=None,
    y=None,
    kind: Optional[str] = None,
    title: Optional[str] = None,
    xlabel: Optional[str] = None,
    ylabel: Optional[str] = None,
    figsize: Optional[tuple] = None,
    inset_bounds: tuple = (0.6, 0.6, 0.35, 0.35),
    xlim: Optional[tuple] = None,
    ylim: Optional[tuple] = None,
    loc: str = 'upper right',
    borderpad: float = 1,
    **kwargs
) -> Any:
    """
    Create a main plot with an inset axes for zoomed detail.

    Useful for showing a close-up of an interesting region within the main plot.

    Parameters
    ----------
    x, y : array-like or column names
        Data for the main plot
    kind : str, optional
        Plot type for main axes (e.g., 'line', 'scatter')
    title, xlabel, ylabel, figsize : passed to main plot
    inset_bounds : tuple (left, bottom, width, height) in figure coords (0-1)
        Defines the position and size of the inset
    xlim, ylim : tuple, optional
        Axis limits for the inset axes
    loc : str
        Location code for inset (default 'upper right')
    borderpad : float
        Padding around inset
    **kwargs
        Additional arguments passed to main plot or backend

    Returns
    -------
    tuple
        (fig, main_ax, inset_ax)

    Examples
    --------
    >>> import bottlewiz as vz
    >>> import numpy as np
    >>> x = np.linspace(0, 10, 100)
    >>> y = np.sin(x)
    >>> fig, main_ax, inset_ax = vz.inset(x=x, y=y, kind='line',
    ...                                   title='Sine Wave with Inset',
    ...                                   xlim=(2, 4), ylim=(-0.5, 0.5))
    >>> # Customize main_ax or inset_ax as needed
    >>> vz.show()
    """
    # Separate kwargs for main plot and inset
    inset_specific_keys = {'inset_bounds', 'xlim', 'ylim', 'loc', 'borderpad'}
    inset_kwargs = {k: v for k, v in kwargs.items() if k in inset_specific_keys}
    main_kwargs = {k: v for k, v in kwargs.items() if k not in inset_specific_keys}

    # Create the main plot first using quickplot which handles x,y arrays without explicit data
    main_fig = quickplot(
        x=x, y=y, kind=kind,
        title=title, xlabel=xlabel, ylabel=ylabel,
        figsize=figsize,
        **main_kwargs
    )
    # Get the main axes (assume first axes)
    if not hasattr(main_fig, 'axes') or len(main_fig.axes) == 0:
        raise VisualizerError("Main plot did not create any axes")
    main_ax = main_fig.axes[0]

    # Prepare config for backend.inset_plot
    backend = get_backend()
    inset_config = {
        'parent_axes': main_ax,
        'inset_bounds': inset_bounds,
        'xlim': xlim,
        'ylim': ylim,
        'loc': loc,
        'borderpad': borderpad,
        **inset_kwargs
    }
    # Call backend.inset_plot - it now always returns (fig, parent_axes, inset_ax)
    fig, parent_ax, inset_ax = backend.inset_plot(inset_config)
    return fig, main_ax, inset_ax


def plot_3d_surface(
    X: np.ndarray,
    Y: np.ndarray,
    Z: np.ndarray,
    title: Optional[str] = None,
    xlabel: str = 'X',
    ylabel: str = 'Y',
    zlabel: str = 'Z',
    **kwargs
) -> Any:
    """
    Create a 3D surface plot.

    Parameters
    ----------
    X, Y, Z : np.ndarray
        2D arrays of coordinates and heights
    title : str, optional
        Plot title
    xlabel, ylabel, zlabel : str
        Axis labels
    **kwargs
        Additional arguments passed to ax.plot_surface()

    Returns
    -------
    tuple
        (fig, ax) with the surface plot
    """
    backend = get_backend()
    fig, ax = backend.figure3d({
        'kind': 'figure3d',
        'title': title,
        'xlabel': xlabel,
        'ylabel': ylabel,
        'zlabel': zlabel,
        **kwargs
    })
    backend.plot_surface(ax, X, Y, Z, **kwargs)
    return fig, ax


def plot_3d_wireframe(
    X: np.ndarray,
    Y: np.ndarray,
    Z: np.ndarray,
    title: Optional[str] = None,
    xlabel: str = 'X',
    ylabel: str = 'Y',
    zlabel: str = 'Z',
    **kwargs
) -> Any:
    """Create a 3D wireframe plot."""
    backend = get_backend()
    fig, ax = backend.figure3d({
        'kind': 'figure3d',
        'title': title,
        'xlabel': xlabel,
        'ylabel': ylabel,
        'zlabel': zlabel,
        **kwargs
    })
    backend.plot_wireframe(ax, X, Y, Z, **kwargs)
    return fig, ax


def plot_3d_trisurf(
    X: np.ndarray,
    Y: np.ndarray,
    Z: np.ndarray,
    title: Optional[str] = None,
    xlabel: str = 'X',
    ylabel: str = 'Y',
    zlabel: str = 'Z',
    **kwargs
) -> Any:
    """Create a 3D triangular surface plot."""
    backend = get_backend()
    fig, ax = backend.figure3d({
        'kind': 'figure3d',
        'title': title,
        'xlabel': xlabel,
        'ylabel': ylabel,
        'zlabel': zlabel,
        **kwargs
    })
    backend.plot_trisurf(ax, X, Y, Z, **kwargs)
    return fig, ax


def plot_3d_contour(
    X: np.ndarray,
    Y: np.ndarray,
    Z: np.ndarray,
    title: Optional[str] = None,
    xlabel: str = 'X',
    ylabel: str = 'Y',
    zlabel: str = 'Z',
    **kwargs
) -> Any:
    """Create a 3D contour line plot."""
    backend = get_backend()
    fig, ax = backend.figure3d({
        'kind': 'figure3d',
        'title': title,
        'xlabel': xlabel,
        'ylabel': ylabel,
        'zlabel': zlabel,
        **kwargs
    })
    backend.contour(ax, X, Y, Z, **kwargs)
    return fig, ax


def plot_3d_contourf(
    X: np.ndarray,
    Y: np.ndarray,
    Z: np.ndarray,
    title: Optional[str] = None,
    xlabel: str = 'X',
    ylabel: str = 'Y',
    zlabel: str = 'Z',
    **kwargs
) -> Any:
    """Create a filled 3D contour plot."""
    backend = get_backend()
    fig, ax = backend.figure3d({
        'kind': 'figure3d',
        'title': title,
        'xlabel': xlabel,
        'ylabel': ylabel,
        'zlabel': zlabel,
        **kwargs
    })
    backend.contourf(ax, X, Y, Z, **kwargs)
    return fig, ax


def plot_3d_quiver(
    X: np.ndarray,
    Y: np.ndarray,
    Z: np.ndarray,
    U: np.ndarray,
    V: np.ndarray,
    W: np.ndarray,
    title: Optional[str] = None,
    xlabel: str = 'X',
    ylabel: str = 'Y',
    zlabel: str = 'Z',
    **kwargs
) -> Any:
    """Create a 3D quiver (arrow) plot."""
    backend = get_backend()
    fig, ax = backend.figure3d({
        'kind': 'figure3d',
        'title': title,
        'xlabel': xlabel,
        'ylabel': ylabel,
        'zlabel': zlabel,
        **kwargs
    })
    backend.quiver(ax, X, Y, Z, U, V, W, **kwargs)
    return fig, ax


def plot_3d_stem(
    X: np.ndarray,
    Y: np.ndarray,
    Z: np.ndarray,
    title: Optional[str] = None,
    xlabel: str = 'X',
    ylabel: str = 'Y',
    zlabel: str = 'Z',
    **kwargs
) -> Any:
    """Create a 3D stem plot."""
    backend = get_backend()
    fig, ax = backend.figure3d({
        'kind': 'figure3d',
        'title': title,
        'xlabel': xlabel,
        'ylabel': ylabel,
        'zlabel': zlabel,
        **kwargs
    })
    backend.stem(ax, X, Y, Z, **kwargs)
    return fig, ax


def plot_3d_bar(
    X: np.ndarray,
    Y: np.ndarray,
    Z: np.ndarray,
    dx: float,
    dy: float,
    dz: np.ndarray,
    title: Optional[str] = None,
    xlabel: str = 'X',
    ylabel: str = 'Y',
    zlabel: str = 'Z',
    **kwargs
) -> Any:
    """Create a 3D bar plot."""
    backend = get_backend()
    fig, ax = backend.figure3d({
        'kind': 'figure3d',
        'title': title,
        'xlabel': xlabel,
        'ylabel': ylabel,
        'zlabel': zlabel,
        **kwargs
    })
    backend.bar3d(ax, X, Y, Z, dx, dy, dz, **kwargs)
    return fig, ax


def plot_3d_voxels(
    voxels: np.ndarray,
    title: Optional[str] = None,
    xlabel: str = 'X',
    ylabel: str = 'Y',
    zlabel: str = 'Z',
    **kwargs
) -> Any:
    """Create a 3D voxel plot."""
    backend = get_backend()
    fig, ax = backend.figure3d({
        'kind': 'figure3d',
        'title': title,
        'xlabel': xlabel,
        'ylabel': ylabel,
        'zlabel': zlabel,
        **kwargs
    })
    backend.voxels(ax, voxels, **kwargs)
    return fig, ax
