"""
Custom exceptions for BottleViz.

Provides clear, actionable error messages to help users.
"""

from typing import Optional, Dict, Any


class VisualizerError(Exception):
    """
    Base exception for BottleViz errors.

    All BottleViz-specific errors inherit from this class.
    """

    def __init__(self, message: str, suggestion: Optional[str] = None):
        """
        Initialize VisualizerError.

        Parameters
        ----------
        message : str
            Error message
        suggestion : str, optional
            Helpful suggestion for fixing the issue
        """
        self.message = message
        self.suggestion = suggestion

        full_message = message
        if suggestion:
            full_message = f"{message}\n\nSuggestion: {suggestion}"

        super().__init__(full_message)


class DataError(VisualizerError):
    """
    Raised when data validation fails.

    Examples: missing columns, wrong data format, empty data.
    """

    def __init__(self, message: str):
        suggestions = {
            "Column": "Check column name spelling or use df.columns to see available columns",
            "not found": "Make sure you're using the correct DataFrame or column name",
            "None": "Data cannot be empty. Check your data source.",
            "Unsupported data type": "Convert to pandas DataFrame first: df = pd.DataFrame(data)"
        }

        # Add context-specific suggestions
        suggestion = None
        for key, value in suggestions.items():
            if key in message:
                suggestion = value
                break

        if not suggestion:
            suggestion = (
                "Review the data parameter and ensure it's in a supported format. "
                "See documentation for valid input types."
            )

        super().__init__(message, suggestion)


class PlotError(VisualizerError):
    """
    Raised when plot creation fails.

    Examples: invalid plot parameters, unsupported combinations.
    """

    def __init__(self, message: str):
        suggestion = (
            "Check plot parameters. Common issues:\n"
            "  - For scatter plots, both x and y are required\n"
            "  - For bar plots, provide categorical x or numeric y\n"
            "  - Use kind parameter to explicitly set plot type\n"
            "  - See bottleviz.available_styles() for style options"
        )
        super().__init__(message, suggestion)


class BackendError(VisualizerError):
    """
    Raised when backend operations fail.

    Examples: matplotlib not installed, rendering errors.
    """

    def __init__(self, message: str):
        suggestion = (
            "Backend error. Try:\n"
            "  - Installing required dependencies: pip install matplotlib\n"
            "  - Switching backends: bottleviz.set_backend('matplotlib')\n"
            "  - Checking for version compatibility"
        )
        super().__init__(message, suggestion)


class StyleError(VisualizerError):
    """
    Raised when style operations fail.

    Examples: invalid style name, style configuration errors.
    """

    def __init__(self, message: str):
        suggestion = (
            f"Use a valid style name: {', '.join(['default', 'dark', 'minimal', 'publication', 'seaborn'])}\n"
            "Or provide a path to a custom .mplstyle file"
        )
        super().__init__(message, suggestion)


class ConfigurationError(VisualizerError):
    """
    Raised when configuration is invalid.

    Examples: invalid parameters, incompatible options.
    """

    def __init__(self, message: str):
        suggestion = (
            "Review your configuration parameters. Check the documentation "
            "for valid options and combinations."
        )
        super().__init__(message, suggestion)


def format_error_message(
    error: Exception,
    context: Optional[Dict[str, Any]] = None
) -> str:
    """
    Format an error message with helpful context.

    Parameters
    ----------
    error : Exception
        The exception to format
    context : dict, optional
        Additional context (data shape, column names, etc.)

    Returns
    -------
    str
        Formatted error message with suggestions
    """
    base_msg = f"Error: {type(error).__name__}: {error}"

    if context:
        context_str = "\nContext:"
        for key, value in context.items():
            context_str += f"\n  {key}: {value}"

        base_msg += context_str

    suggestions = []

    if isinstance(error, DataError):
        suggestions.append("\n💡 Suggestions:")
        suggestions.append("  - Check data format and column names")
        suggestions.append("  - Ensure DataFrame has the expected columns")
        suggestions.append("  - Use vz.plot(df) without parameters to see auto-detection")

    elif isinstance(error, PlotError):
        suggestions.append("\n💡 Suggestions:")
        suggestions.append("  - Specify plot type with 'kind' parameter")
        suggestions.append("  - Check parameter names and types")
        suggestions.append("  - See vz.help() for usage examples")

    if suggestions:
        base_msg += ''.join(suggestions)

    return base_msg
