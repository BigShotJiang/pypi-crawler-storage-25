"""
Type definitions and data type detection for BottleViz.

Provides utilities for automatically detecting data types and
suggesting appropriate plot types.
"""

from typing import Any, Dict, List, Tuple, Optional
import numpy as np
import pandas as pd
from dataclasses import dataclass


@dataclass
class ColumnInfo:
    """Information about a DataFrame column."""
    name: str
    dtype: str
    is_numeric: bool
    is_categorical: bool
    is_temporal: bool
    n_unique: int
    n_missing: int
    sample_values: List[Any]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'name': self.name,
            'dtype': str(self.dtype),
            'is_numeric': self.is_numeric,
            'is_categorical': self.is_categorical,
            'is_temporal': self.is_temporal,
            'n_unique': self.n_unique,
            'n_missing': self.n_missing,
            'sample_values': self.sample_values[:5]
        }


@dataclass
class DataProfile:
    """Profile of a dataset's characteristics."""
    n_rows: int
    n_columns: int
    columns: List[ColumnInfo]
    numeric_columns: List[str]
    categorical_columns: List[str]
    temporal_columns: List[str]
    has_datetime_index: bool
    memory_usage_mb: float
    suggested_plots: List[Tuple[str, str, str]]  # [(plot_type, x, y), ...]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'n_rows': self.n_rows,
            'n_columns': self.n_columns,
            'columns': [col.to_dict() for col in self.columns],
            'numeric_columns': self.numeric_columns,
            'categorical_columns': self.categorical_columns,
            'temporal_columns': self.temporal_columns,
            'has_datetime_index': self.has_datetime_index,
            'memory_usage_mb': self.memory_usage_mb,
            'suggested_plots': [
                {'type': p[0], 'x': p[1], 'y': p[2]}
                for p in self.suggested_plots
            ]
        }


def detect_column_types(df: pd.DataFrame) -> List[ColumnInfo]:
    """
    Detect and classify column types.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to analyze

    Returns
    -------
    list of ColumnInfo
        Information about each column
    """
    column_info = []

    for col in df.columns:
        series = df[col]
        dtype = series.dtype

        # Check if numeric
        is_numeric = pd.api.types.is_numeric_dtype(dtype)

        # Check if temporal
        is_temporal = pd.api.types.is_datetime64_any_dtype(dtype) or \
                      pd.api.types.is_timedelta64_dtype(dtype)

        # Check if categorical
        is_categorical = False
        if dtype.name == 'category' or dtype == 'object':
            is_categorical = True
        elif is_numeric:
            # Numeric can be categorical if few unique values
            n_unique = series.nunique()
            if n_unique <= 20 and n_unique < len(series) * 0.1:
                is_categorical = True

        n_unique = series.nunique()
        n_missing = series.isna().sum()

        # Get sample values (handle large cardinality)
        unique_vals = series.dropna().unique()
        if len(unique_vals) > 5:
            sample = list(unique_vals[:5])
        else:
            sample = list(unique_vals)
            if n_missing > 0:
                sample.append('...')  # indicate missing values

        column_info.append(ColumnInfo(
            name=col,
            dtype=str(dtype),
            is_numeric=is_numeric,
            is_categorical=is_categorical,
            is_temporal=is_temporal,
            n_unique=n_unique,
            n_missing=int(n_missing),
            sample_values=sample
        ))

    return column_info


def profile_dataframe(df: pd.DataFrame) -> DataProfile:
    """
    Generate a comprehensive profile of a DataFrame.

    Analyzes the data structure and suggests appropriate visualizations.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to profile

    Returns
    -------
    DataProfile
        Complete profile with suggestions
    """
    column_info = detect_column_types(df)

    numeric_cols = [col.name for col in column_info if col.is_numeric and not col.is_categorical]
    categorical_cols = [col.name for col in column_info if col.is_categorical]
    temporal_cols = [col.name for col in column_info if col.is_temporal]

    # Check if index is datetime
    has_datetime_index = False
    if isinstance(df.index, pd.DatetimeIndex):
        has_datetime_index = True

    # Memory usage in MB
    memory_mb = df.memory_usage(deep=True).sum() / 1024**2

    # Generate plot suggestions
    suggested_plots = _suggest_plots(df, column_info)

    return DataProfile(
        n_rows=len(df),
        n_columns=len(df.columns),
        columns=column_info,
        numeric_columns=numeric_cols,
        categorical_columns=categorical_cols,
        temporal_columns=temporal_cols,
        has_datetime_index=has_datetime_index,
        memory_usage_mb=memory_mb,
        suggested_plots=suggested_plots
    )


def _suggest_plots(
    df: pd.DataFrame,
    column_info: List[ColumnInfo]
) -> List[Tuple[str, str, str]]:
    """
    Suggest appropriate plot types based on data characteristics.

    Returns
    -------
    list of tuples
        Each tuple: (plot_type, x_column, y_column)
    """
    suggestions = []

    numeric = [col.name for col in column_info if col.is_numeric and not col.is_categorical]
    categorical = [col.name for col in column_info if col.is_categorical]
    temporal = [col.name for col in column_info if col.is_temporal]

    # Single numeric variable -> histogram
    if len(numeric) >= 1:
        suggestions.append(('hist', numeric[0], None))
        if len(numeric) >= 2:
            suggestions.append(('scatter', numeric[0], numeric[1]))

    # Numeric over time
    if temporal and numeric:
        suggestions.append(('line', temporal[0], numeric[0]))

    # Categorical distributions
    for cat in categorical[:2]:  # Suggest up to 2 categorical plots
        if len(numeric) >= 1:
            suggestions.append(('bar', cat, numeric[0]))
        else:
            suggestions.append(('bar', cat, None))

    # Correlation matrix if multiple numeric columns
    if len(numeric) >= 3:
        suggestions.append(('heatmap', None, None))

    # Box plots for numeric distributions by category
    if numeric and categorical:
        suggestions.append(('box', categorical[0], numeric[0]))

    # KDE for numeric distributions
    if len(numeric) >= 1:
        suggestions.append(('kde', numeric[0], None))

    return suggestions


def get_column_summary(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create a summary table of DataFrame columns.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to summarize

    Returns
    -------
    pd.DataFrame
        Summary table with column statistics
    """
    summary_data = []

    for col in df.columns:
        series = df[col]
        dtype = series.dtype

        info = {
            'column': col,
            'dtype': str(dtype),
            'non_null': series.notna().sum(),
            'null_count': series.isna().sum(),
            'null_pct': (series.isna().sum() / len(df)) * 100,
            'unique_values': series.nunique(),
            'sample': str(series.dropna().iloc[0] if len(series.dropna()) > 0 else 'NaN')
        }

        if pd.api.types.is_numeric_dtype(dtype):
            info.update({
                'mean': series.mean(),
                'std': series.std(),
                'min': series.min(),
                'max': series.max(),
                'median': series.median()
            })
        else:
            info.update({
                'top_value': series.mode().iloc[0] if len(series.mode()) > 0 else None,
                'top_count': (series == series.mode().iloc[0]).sum() if len(series.mode()) > 0 else 0
            })

        summary_data.append(info)

    return pd.DataFrame(summary_data)


def get_recommendations(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """
    Get recommendations for visualizations based on data profile.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to analyze

    Returns
    -------
    list of dict
        Recommended plots with rationale
    """
    profile = profile_dataframe(df)
    recommendations = []

    for plot_type, x, y in profile.suggested_plots[:5]:
        rec = {
            'type': plot_type,
            'x': x,
            'y': y,
            'rationale': _get_rationale(plot_type, x, y, df),
            'example_code': _generate_example_code(plot_type, x, y)
        }
        recommendations.append(rec)

    return recommendations


def _get_rationale(plot_type: str, x: Optional[str], y: Optional[str], df: pd.DataFrame) -> str:
    """Generate rationale for a recommended plot."""
    rationales = {
        'hist': f"Distribution of '{x}' - shows data spread and central tendency",
        'scatter': f"Relationship between '{x}' and '{y}' - reveals correlations",
        'line': f"Trend of '{y}' over '{x}' - ideal for time series",
        'bar': f"Comparison of '{y}' across '{x}' categories",
        'box': f"Distribution of '{y}' split by '{x}' categories",
        'kde': f"Smooth distribution of '{x}'",
        'heatmap': "Correlation matrix for numeric variables",
        'violin': f"Detailed distribution of '{y}' by '{x}' categories",
        'area': f"Cumulative '{y}' values over '{x}'",
        'pie': f"Proportional breakdown of '{x}'"
    }

    base = rationales.get(plot_type, f"Visualize your data with {plot_type} plot")
    return base


def _generate_example_code(plot_type: str, x: Optional[str], y: Optional[str]) -> str:
    """Generate example code for a recommended plot."""
    if y:
        return f"vz.plot(df, x='{x}', y='{y}')  # or kind='{plot_type}'"
    else:
        return f"vz.plot(df, x='{x}')  # or kind='{plot_type}'"
