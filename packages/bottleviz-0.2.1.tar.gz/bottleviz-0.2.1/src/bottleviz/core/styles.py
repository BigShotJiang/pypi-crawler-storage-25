"""
Style management for BottleViz.

Provides beautiful default styles and theme customization.
"""

from typing import Dict, Any, List
import matplotlib.pyplot as plt
import warnings

from .exceptions import VisualizerError, StyleError

# Current style (thread-safe storage)
_current_style = None

# Available style presets - modern, beautiful defaults
STYLE_PRESETS = {
    'default': {
        'figure.figsize': (10, 6),
        'figure.dpi': 100,
        'axes.titlesize': 14,
        'axes.labelsize': 12,
        'axes.grid': True,
        'grid.alpha': 0.3,
        'legend.frameon': False,
        'legend.fontsize': 10,
        'font.size': 11,
        'lines.linewidth': 2.5,
        'lines.markersize': 8,
        'patch.edgecolor': 'none',
        # Modern color palette
        'axes.prop_cycle': plt.cycler('color', [
            '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
            '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
        ])
    },

    'dark': {
        'figure.figsize': (10, 6),
        'figure.dpi': 100,
        'axes.titlesize': 14,
        'axes.labelsize': 12,
        'axes.grid': True,
        'grid.alpha': 0.3,
        'legend.frameon': False,
        'legend.fontsize': 10,
        'font.size': 11,
        'lines.linewidth': 2.5,
        'lines.markersize': 8,
        'patch.edgecolor': 'none',
        # Dark theme colors
        'axes.prop_cycle': plt.cycler('color', [
            '#4c72b0', '#dd8452', '#55a868', '#c44e52', '#8172b3',
            '#937860', '#da8bc3', '#8c8c8c', '#ccb974', '#64b5cd'
        ]),
        'axes.facecolor': '#2e2e2e',
        'figure.facecolor': '#1e1e1e',
        'axes.edgecolor': '#cccccc',
        'axes.labelcolor': '#cccccc',
        'xtick.color': '#cccccc',
        'ytick.color': '#cccccc',
        'grid.color': '#555555',
        'text.color': '#cccccc',
    },

    'minimal': {
        'figure.figsize': (10, 6),
        'figure.dpi': 100,
        'axes.titlesize': 14,
        'axes.labelsize': 12,
        'axes.spines.left': True,
        'axes.spines.bottom': True,
        'axes.spines.right': False,
        'axes.spines.top': False,
        'axes.grid': True,
        'grid.alpha': 0.2,
        'grid.linestyle': '--',
        'legend.frameon': False,
        'legend.fontsize': 10,
        'font.size': 11,
        'lines.linewidth': 2,
        'lines.markersize': 6,
        'patch.edgecolor': 'none',
        'axes.prop_cycle': plt.cycler('color', [
            '#0072B2', '#E69F00', '#56B4E9', '#009E73', '#F0E442',
            '#0072B2', '#D55E00', '#CC79A7'
        ])
    },

    'publication': {
        'figure.figsize': (8, 6),
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'savefig.format': 'pdf',
        'axes.titlesize': 12,
        'axes.labelsize': 11,
        'axes.linewidth': 1.5,
        'axes.grid': False,
        'legend.frameon': False,
        'legend.fontsize': 9,
        'font.size': 10,
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'DejaVu Serif', 'Computer Modern'],
        'lines.linewidth': 1.5,
        'lines.markersize': 6,
        'patch.edgecolor': 'none',
        'axes.prop_cycle': plt.cycler('color', [
            '#00468B', '#FF6E00', '#00A087', '#F39B7F', '#A65628',
            '#FDAE61', '#FFFF99', '#1B9E77', '#D95F02', '#7570B3'
        ])
    },

    'seaborn': {
        # Compatible with seaborn color palette
        'figure.figsize': (10, 6),
        'figure.dpi': 100,
        'axes.titlesize': 14,
        'axes.labelsize': 12,
        'axes.grid': True,
        'grid.alpha': 0.3,
        'legend.frameon': True,
        'legend.edgecolor': 'white',
        'legend.framealpha': 0.8,
        'legend.fontsize': 10,
        'font.size': 11,
        'lines.linewidth': 2.5,
        'lines.markersize': 8,
        'patch.edgecolor': 'none',
        'axes.prop_cycle': plt.cycler('color', [
            '#4C72B0', '#55A868', '#C44E52', '#8172B3', '#937860',
            '#DA8BC3', '#8C8C8C', '#CCB974', '#64B5CD', '#1B9E77'
        ])
    }
}


def set_style(style: str = 'default') -> None:
    """
    Set the global visual style for plots.

    Parameters
    ----------
    style : str
        Style name. Options: 'default', 'dark', 'minimal',
        'publication', 'seaborn', or path to custom mplstyle file

    Examples
    --------
    >>> import bottleviz as vz
    >>> vz.set_style('dark')  # Use dark theme
    >>> vz.set_style('minimal')  # Minimal ink design
    """
    global _current_style

    if style in STYLE_PRESETS:
        # Apply preset style
        from ..publishers.backends import get_backend
        backend = get_backend()

        preset = STYLE_PRESETS[style].copy()
        _current_style = style

        # Apply matplotlib rcParams if available
        try:
            import matplotlib
            for key, value in preset.items():
                plt.rcParams[key] = value
        except ImportError:
            warnings.warn(
                f"Matplotlib not available. Style '{style}' will be applied "
                "when matplotlib is installed.",
                UserWarning
            )
    else:
        # Try to load custom style file
        try:
            plt.style.use(style)
            _current_style = style
        except Exception as e:
            raise StyleError(f"Could not load style '{style}': {str(e)}")


def get_current_style() -> str:
    """
    Get the currently active style name.

    Returns
    -------
    str
        Current style name ('default' if none explicitly set)
    """
    global _current_style
    if _current_style is None:
        return 'default'
    return _current_style


def available_styles() -> List[str]:
    """
    List all available style presets.

    Returns
    -------
    list of str
        Names of available style presets
    """
    return list(STYLE_PRESETS.keys())


def create_custom_style(
    name: str,
    **kwargs
) -> None:
    """
    Create a custom style preset.

    Parameters
    ----------
    name : str
        Name for the custom style
    **kwargs
        Matplotlib rcParams to set

    Examples
    --------
    >>> vz.create_custom_style('my_style', figure.figsize=(12,8))
    >>> vz.set_style('my_style')
    """
    if name in STYLE_PRESETS:
        raise VisualizerError(f"Style '{name}' already exists. Use a different name.")

    STYLE_PRESETS[name] = kwargs
    warnings.warn(f"Custom style '{name}' created. It will only persist for this session.",
                  UserWarning)


def list_style_params(style: str = 'default') -> Dict[str, Any]:
    """
    List all parameters for a given style.

    Parameters
    ----------
    style : str
        Style name to inspect

    Returns
    -------
    dict
        Dictionary of rcParam values
    """
    if style not in STYLE_PRESETS:
        raise VisualizerError(f"Style '{style}' not found.")

    return STYLE_PRESETS[style].copy()
