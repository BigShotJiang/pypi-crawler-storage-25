"""
Automated visualization suggestions for BottleViz.

Provides smart recommendations and automatic dashboard generation.
"""

from typing import Any, List, Dict, Optional
import pandas as pd
from ..core.types import profile_dataframe, get_recommendations, DataProfile
from ..core.core import visualize
from ..utils.utils import optimize_for_large_data


def suggest_plots(
    data: Any,
    interactive: bool = False,
    ai: bool = False,
    ai_provider: Optional[str] = None,
    api_key: Optional[str] = None,
    **ai_kwargs
) -> pd.DataFrame:
    """
    Automatically suggest appropriate visualizations for your data.

    Analyzes your dataset and returns a table of recommended plots
    with rationale and example code.

    Parameters
    ----------
    data : DataFrame, Series, array-like
        Data to analyze
    interactive : bool, default False
        If True and in notebook, returns interactive widget (not implemented yet)
    ai : bool, default False
        If True, includes AI-powered suggestions alongside rule-based ones
    ai_provider : str, optional
        AI provider to use: 'openai', 'anthropic', or 'ollama'.
        Default: 'openai' (if ai=True)
    api_key : str, optional
        API key for the AI provider. If not provided, uses environment variables:
        - OpenAI: OPENAI_API_KEY
        - Anthropic: ANTHROPIC_API_KEY
        - Ollama: No API key needed (local)
    **ai_kwargs
        Additional arguments passed to AI provider (e.g., model, temperature,
        host for Ollama)

    Returns
    -------
    pd.DataFrame
        Table of recommendations with columns:
        - type: plot type (hist, scatter, line, etc.)
        - x: x-axis column
        - y: y-axis column (or None)
        - rationale: why this plot is suggested
        - example_code: code to generate the plot
        - source: "rule" or "ai" (when ai=True)

    Examples
    --------
    >>> import bottleviz as vz
    >>> df = pd.DataFrame({'x': [1,2,3], 'y': [4,5,6], 'cat': ['a','b','c']})
    >>> vz.suggest_plots(df)
    >>> # With AI suggestion (OpenAI)
    >>> vz.suggest_plots(df, ai=True, api_key="sk-...")
    >>> # With local Ollama model
    >>> vz.suggest_plots(df, ai=True, ai_provider='ollama')
    """
    # Validate and convert data
    from ..utils.utils import validate_data
    df = validate_data(data)

    # Get rule-based recommendations
    recs = get_recommendations(df)
    sources = ["rule"] * len(recs)

    # Add AI recommendation if requested
    if ai:
        try:
            from ._ai_integration import get_ai_suggestion
            ai_suggestion_dict = get_ai_suggestion(
                df,
                provider=ai_provider or "openai",
                api_key=api_key,
                **ai_kwargs
            )
            if ai_suggestion_dict is not None:
                ai_rec = {
                    'type': ai_suggestion_dict['kind'],
                    'x': ai_suggestion_dict.get('x'),
                    'y': ai_suggestion_dict.get('y', [None])[0] if ai_suggestion_dict.get('y') else None,
                    'rationale': ai_suggestion_dict.get('reason', ''),
                    'example_code': f"vz.plot(df, x='{ai_suggestion_dict.get('x')}', y='{ai_suggestion_dict['y'][0] if ai_suggestion_dict.get('y') else None}', kind='{ai_suggestion_dict['kind']}')"
                }
                recs.append(ai_rec)
                sources.append("ai")
            else:
                import warnings
                warnings.warn(
                    "AI provider failed or returned no suggestion. "
                    "Only rule-based recommendations will be shown. "
                    "Check your API key or ensure local server (Ollama) is running."
                )
        except Exception as e:
            # Log but don't fail if AI unavailable
            import warnings
            warnings.warn(f"AI suggestion failed: {e}. Returning rule-based only.")

    # Create DataFrame
    rec_df = pd.DataFrame(recs)
    rec_df.index.name = 'recommendation'
    rec_df['source'] = sources

    return rec_df


def report(
    data: Any,
    show_plots: bool = False,
    max_recommendations: int = 5
) -> str:
    """
    Generate a comprehensive data report with visualization suggestions.

    Creates a text report summarizing dataset characteristics and
    suggesting visualizations.

    Parameters
    ----------
    data : DataFrame, Series, array-like
        Data to analyze
    show_plots : bool, default False
        If True, also generates a dashboard plot (returns fig instead of string)
    max_recommendations : int, default 5
        Maximum number of plot recommendations to include

    Returns
    -------
    str or Figure
        Report string, or Figure if show_plots=True

    Notes
    -----
    The returned report string contains Unicode characters for formatting.
    If writing to a file on Windows, use UTF-8 encoding:

        >>> with open('report.txt', 'w', encoding='utf-8') as f:
        ...     f.write(vz.report(df))

    Or use the save_report() function which handles encoding automatically.

    Examples
    --------
    >>> import bottleviz as vz
    >>> df = pd.DataFrame({'x': [1,2,3], 'y': [4,5,6]})
    >>> report = vz.report(df)
    >>> print(report)
    """
    from ..utils.utils import validate_data
    df = validate_data(data)

    if show_plots:
        return visualize(df, max_plots=min(6, max_recommendations))

    profile: DataProfile = profile_dataframe(df)

    lines = []
    lines.append("=" * 60)
    lines.append("DATA VISUALIZATION REPORT")
    lines.append("=" * 60)
    lines.append(f"\nDataset Shape: {profile.n_rows:,} rows × {profile.n_columns} columns")
    lines.append(f"Memory Usage: {profile.memory_usage_mb:.2f} MB")

    lines.append("\n" + "─" * 60)
    lines.append("COLUMN DETAILS:")
    lines.append("─" * 60)

    for col in profile.columns:
        lines.append(f"\n{col.name} ({col.dtype})")
        lines.append(f"  Type: {'Numeric' if col.is_numeric else 'Categorical' if col.is_categorical else 'Temporal' if col.is_temporal else 'Other'}")
        lines.append(f"  Unique: {col.n_unique:,} | Missing: {col.n_missing:,} ({col.n_missing/profile.n_rows*100:.1f}%)")
        if col.sample_values:
            lines.append(f"  Sample: {', '.join(map(str, col.sample_values[:3]))}")

    lines.append("\n" + "─" * 60)
    lines.append("RECOMMENDED VISUALIZATIONS:")
    lines.append("─" * 60)

    recommendations = get_recommendations(df)[:max_recommendations]

    for i, rec in enumerate(recommendations, 1):
        lines.append(f"\n{i}. {rec['type'].upper()}: {rec['rationale']}")
        lines.append(f"   Code: {rec['example_code']}")

    lines.append("\n" + "=" * 60)
    lines.append("\nQuick commands:")
    lines.append("  vz.quickplot(df, x='col', y='col')    # create plot")
    lines.append("  vz.plot(df, kind='scatter')          # specify plot type")
    lines.append("  vz.visualize(df)                     # auto-dashboard")
    lines.append("  vz.suggest_plots(df)                 # more recommendations")
    lines.append("=" * 60 + "\n")

    return "\n".join(lines)


def save_report(
    data: Any,
    filepath: str,
    max_recommendations: int = 5
) -> None:
    """
    Generate and save a comprehensive data report to a file.

    Creates a text report summarizing dataset characteristics and
    suggesting visualizations, then saves it to the specified file
    with UTF-8 encoding.

    This function automatically handles UTF-8 encoding, making it
    safe to use on Windows and other platforms.

    Parameters
    ----------
    data : DataFrame, Series, array-like
        Data to analyze
    filepath : str or Path
        Path where the report will be saved
    max_recommendations : int, default 5
        Maximum number of plot recommendations to include

    Returns
    -------
    None

    Examples
    --------
    >>> import bottleviz as vz
    >>> df = pd.DataFrame({'x': [1,2,3], 'y': [4,5,6]})
    >>> vz.save_report(df, 'my_report.txt')
    """
    report_text = report(data, max_recommendations=max_recommendations)

    # Use UTF-8 encoding explicitly to avoid Windows encoding errors
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(report_text)


def explore(
    data: Any,
    mode: str = 'auto'
) -> Any:
    """
    Smart exploratory data analysis with automatic visualizations.

    Parameters
    ----------
    data : DataFrame, Series, array-like
        Data to explore
    mode : str, default 'auto'
        Exploration mode:
        - 'auto': automatically choose best visualizations
        - 'all': create comprehensive dashboard with all plot types
        - 'distribution': focus on distribution plots
        - 'relationship': focus on relationship plots

    Returns
    -------
    Figure
        Matplotlib figure with visualizations

    Examples
    --------
    >>> vz.explore(df)  # Auto-explore
    >>> vz.explore(df, mode='distribution')  # Distribution plots only
    """
    if mode == 'auto':
        profile: DataProfile = profile_dataframe(data)

        # Choose mode based on data characteristics
        if len(profile.numeric_columns) >= 3:
            mode = 'relationship'
        elif len(profile.numeric_columns) <= 2 and len(profile.categorical_columns) >= 1:
            mode = 'categorical'
        else:
            mode = 'distribution'

    return visualize(data, plot_type=mode)


def compare(
    *dataframes: Any,
    names: Optional[List[str]] = None # type: ignore
) -> Any:
    """
    Compare multiple datasets side-by-side.

    Generates comparison plots for multiple DataFrames or Series.

    Parameters
    ----------
    *dataframes : DataFrame or Series
        Datasets to compare
    names : list of str, optional
        Names for each dataset. If None, uses 'Dataset 1', 'Dataset 2', etc.

    Returns
    -------
    Figure
        Comparison figure

    Examples
    --------
    >>> vz.compare(df1, df2, names=['Training', 'Test'])
    """
    if len(dataframes) == 0:
        raise ValueError("At least one dataset required")

    if names is None:
        names = [f'Dataset {i+1}' for i in range(len(dataframes))]

    assert len(names) == len(dataframes), "Number of names must match number of datasets"

    # Create overlaid plots for comparison
    from ..publishers.backends import get_backend
    backend = get_backend()

    config = {
        'dataframes': dataframes,
        'names': names,
        'kind': 'compare'
    }

    return _create_comparison_plot(backend, config)


def _create_comparison_plot(backend, config: Dict[str, Any]) -> Any:
    """Internal: Create comparison visualization."""
    dataframes = config['dataframes']
    names = config['names']
    backend_module = backend

    import matplotlib.pyplot as plt
    n_dfs = len(dataframes)

    # Create multi-column figure
    fig, axes = plt.subplots(1, n_dfs, figsize=(5*n_dfs, 4), squeeze=False)
    axes = axes.flatten()

    for ax, df, name in zip(axes, dataframes, names):
        # Plot first numeric column from each
        numeric_cols = df.select_dtypes(include='number').columns
        if len(numeric_cols) > 0:
            col = numeric_cols[0]
            ax.hist(df[col].dropna(), alpha=0.7, label=name)
            ax.set_title(name)
            ax.set_xlabel(col)
            ax.set_ylabel('Frequency')
        else:
            ax.text(0.5, 0.5, 'No numeric data',
                    ha='center', va='center', transform=ax.transAxes)
            ax.set_title(name)

    plt.tight_layout()
    return fig
