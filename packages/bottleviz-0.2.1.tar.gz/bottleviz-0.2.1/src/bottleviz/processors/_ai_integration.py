"""
AI integration for BottleViz plot suggestions.

This module provides optional AI-powered plot recommendations through
various providers (OpenAI, Anthropic, Ollama, or custom).

Dependencies (optional):
- openai: pip install openai
- anthropic: pip install anthropic
- ollama: pip install ollama (or use local server)
"""

import json
import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Valid plot types
VALID_PLOT_TYPES = {
    'line', 'scatter', 'bar', 'hist', 'box', 'violin', 'heatmap',
    'kde', 'area', 'pie', 'step', 'hexbin', '3d', 'contour',
    'barh', 'stacked_bar', 'grouped_bar', 'pairplot', 'jointplot',
    'boxen', 'rug', 'strip', 'swarm', 'qqplot', 'residualplot',
    'autocorrelation', 'lagplot', 'andrews_curves',
    'parallel_coordinates', 'radviz', 'sankey', 'treemap', 'network'
}

# Prompt template
PLOT_SUGGESTION_PROMPT = """
You are an expert data visualization consultant. Your task is to recommend the best plot type and parameters for a given dataset.

## Dataset Metadata
{metadata}

## Available Plot Types
{plot_types_list}

## Your Task
Analyze the dataset characteristics and suggest the optimal visualization.

Consider:
1. Data types: datetime columns often work with line plots
2. Categorical vs numeric: bar charts for categorical x-axis
3. Unique values: high cardinality numeric might need hexbin
4. Dataset size: >50k points may benefit from aggregation
5. Multi-series: if categorical column exists, suggest coloring by it
6. Outliers: box/violin show distributions well

## Output Format
Respond with ONLY a JSON object (no markdown, no commentary):
{{
    "kind": "plot_type_from_list_above",
    "x": "recommended_x_column_name",
    "y": ["y_column1", "y_column2", ...],
    "color": "optional_category_column_for_grouping",
    "size": "optional_numeric_column_for_point_size",
    "confidence": 0.0-1.0,
    "reason": "Brief 1-2 sentence explanation"
}}

If the dataset has multiple numeric columns and no obvious x/y, suggest a box plot to compare distributions.
If data is time-series (datetime index or column), suggest line plot.
If only one numeric column, suggest histogram.
If two numeric columns with many points (>5000), consider hexbin.
"""


class AIProvider(ABC):
    """Abstract base class for AI providers."""

    @abstractmethod
    def generate(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Generate a response from the AI."""
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """Check if the provider is available and configured."""
        pass


class OpenAIProvider(AIProvider):
    """OpenAI GPT provider."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gpt-4o-mini",
        max_tokens: int = 500
    ):
        """
        Initialize OpenAI provider.

        Parameters
        ----------
        api_key : str, optional
            OpenAI API key. If not provided, uses OPENAI_API_KEY env var.
        model : str, default "gpt-4o-mini"
            Model to use
        max_tokens : int, default 500
            Maximum tokens in response
        """
        self.model = model
        self.max_tokens = max_tokens
        self.api_key = api_key
        self._client = None

    def _get_client(self):
        """Lazy import and create client."""
        if self._client is None:
            try:
                from openai import OpenAI
                self._client = OpenAI(api_key=self.api_key)
            except ImportError:
                raise ImportError(
                    "OpenAI SDK not installed. Install with: pip install openai"
                )
        return self._client

    def generate(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Generate response from OpenAI."""
        client = self._get_client()

        try:
            response = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a helpful data visualization expert."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=self.max_tokens,
                temperature=kwargs.get("temperature", 0.3)
            )
            response_text = response.choices[0].message.content
            return self._parse_json_response(response_text)
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            return {"error": "api_error", "details": str(e)}

    def _parse_json_response(self, text: str) -> Dict[str, Any]:
        """Extract JSON from response."""
        json_start = text.find('{')
        json_end = text.rfind('}') + 1
        if json_start != -1 and json_end != -1:
            json_str = text[json_start:json_end]
            try:
                return json.loads(json_str)
            except json.JSONDecodeError as e:
                logger.error(f"JSON parse error: {e}")
                return {"error": "json_parse_failed", "raw_response": text}
        return {"raw_response": text, "error": "no_json_found"}

    def is_available(self) -> bool:
        """Check if API key is available."""
        return bool(self.api_key or os.getenv("OPENAI_API_KEY"))


class AnthropicProvider(AIProvider):
    """Anthropic Claude provider."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "claude-3-haiku-20240307",
        max_tokens: int = 500
    ):
        """
        Initialize Anthropic provider.

        Parameters
        ----------
        api_key : str, optional
            Anthropic API key. If not provided, uses ANTHROPIC_API_KEY env var.
        model : str, default "claude-3-haiku-20240307"
            Model to use
        max_tokens : int, default 500
            Maximum tokens in response
        """
        self.model = model
        self.max_tokens = max_tokens
        self.api_key = api_key
        self._client = None

    def _get_client(self):
        """Lazy import and create client."""
        if self._client is None:
            try:
                import anthropic
                self._client = anthropic.Anthropic(api_key=self.api_key)
            except ImportError:
                raise ImportError(
                    "Anthropic SDK not installed. Install with: pip install anthropic"
                )
        return self._client

    def generate(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Generate response from Anthropic."""
        client = self._get_client()

        try:
            message = client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                temperature=kwargs.get("temperature", 0.3),
                messages=[{"role": "user", "content": prompt}]
            )
            response_text = message.content[0].text
            return self._parse_json_response(response_text)
        except Exception as e:
            logger.error(f"Anthropic API error: {e}")
            return {"error": "api_error", "details": str(e)}

    def _parse_json_response(self, text: str) -> Dict[str, Any]:
        """Extract JSON from response."""
        json_start = text.find('{')
        json_end = text.rfind('}') + 1
        if json_start != -1 and json_end != -1:
            json_str = text[json_start:json_end]
            try:
                return json.loads(json_str)
            except json.JSONDecodeError as e:
                logger.error(f"JSON parse error: {e}")
                return {"error": "json_parse_failed", "raw_response": text}
        return {"raw_response": text, "error": "no_json_found"}

    def is_available(self) -> bool:
        """Check if API key is available."""
        return bool(self.api_key or os.getenv("ANTHROPIC_API_KEY"))


class OllamaProvider(AIProvider):
    """Ollama local model provider."""

    def __init__(
        self,
        model: str = "llama3.2:1b",
        host: str = "http://localhost:11434",
        timeout: int = 30
    ):
        """
        Initialize Ollama provider.

        Parameters
        ----------
        model : str, default "llama3.2:1b"
            Model name (must be pulled in Ollama)
        host : str, default "http://localhost:11434"
            Ollama server host
        timeout : int, default 30
            Request timeout in seconds
        """
        self.model = model
        self.host = host.rstrip('/')
        self.timeout = timeout
        self._api_url = f"{self.host}/api/generate"

    def generate(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """Generate response from Ollama."""
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": kwargs.get("temperature", 0.3),
                "top_p": kwargs.get("top_p", 0.9),
            }
        }

        try:
            import requests
            response = requests.post(
                self._api_url,
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()
            result = response.json()
            response_text = result.get("response", "")
            return self._parse_json_response(response_text)
        except requests.exceptions.ConnectionError:
            logger.error(f"Cannot connect to Ollama at {self.host}. Make sure Ollama is running.")
            return {"error": "ollama_unavailable"}
        except requests.exceptions.RequestException as e:
            logger.error(f"Ollama request failed: {e}")
            return {"error": "request_failed", "details": str(e)}
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON from Ollama response: {e}")
            return {"error": "invalid_json", "raw_response": response_text}

    def _parse_json_response(self, text: str) -> Dict[str, Any]:
        """Extract JSON from response."""
        json_start = text.find('{')
        json_end = text.rfind('}') + 1
        if json_start != -1 and json_end != -1:
            json_str = text[json_start:json_end]
            try:
                return json.loads(json_str)
            except json.JSONDecodeError:
                pass
        return {"raw_response": text, "error": "json_extraction_failed"}

    def is_available(self) -> bool:
        """Check if Ollama server is running and model is available."""
        try:
            import requests
            response = requests.get(self.host, timeout=5)
            if response.status_code == 200:
                # Check if model exists
                models_resp = requests.get(f"{self.host}/api/tags", timeout=5)
                if models_resp.status_code == 200:
                    models = models_resp.json().get("models", [])
                    model_names = [m["name"] for m in models]
                    return self.model in model_names
            return False
        except requests.exceptions.RequestException:
            return False


# Provider registry
PROVIDERS = {
    'openai': OpenAIProvider,
    'anthropic': AnthropicProvider,
    'ollama': OllamaProvider,
}


def _format_metadata_for_ai(df_metadata: Dict[str, Any]) -> str:
    """Format DataFrame metadata into a readable prompt."""
    lines = []
    lines.append(f"- Rows: {df_metadata['n_rows']:,}")
    lines.append(f"- Columns: {df_metadata['n_cols']}")
    lines.append("")
    lines.append("### Column Details:")

    for col in df_metadata.get("columns", []):
        col_name = col.get("name", "unknown")
        col_type = col.get("dtype", "unknown")
        unique_count = col.get("unique_count", "?")
        is_datetime = col.get("is_datetime", False)
        is_categorical = col.get("is_categorical", False)

        markers = []
        if is_datetime:
            markers.append("datetime")
        if is_categorical:
            markers.append("categorical")
        if unique_count and unique_count < 10:
            markers.append(f"low cardinality ({unique_count})")
        elif unique_count and unique_count > 100:
            markers.append(f"high cardinality ({unique_count})")

        marker_str = f" ({', '.join(markers)})" if markers else ""
        lines.append(f"- `{col_name}` ({col_type}){marker_str}")

    if "sample" in df_metadata:
        lines.append("")
        lines.append("### Sample Data (first 5 rows):")
        sample = df_metadata["sample"]
        lines.append(str(sample)[:500])  # Truncate for token limits

    return "\n".join(lines)


def _extract_metadata(df) -> Dict[str, Any]:
    """Extract metadata from DataFrame for AI analysis."""
    import pandas as pd

    n_rows = len(df)
    n_cols = len(df.columns)

    columns = []
    for col in df.columns:
        col_series = df[col]
        dtype_str = str(col_series.dtype)
        unique_count = col_series.nunique()
        is_datetime = pd.api.types.is_datetime64_any_dtype(col_series)
        is_categorical = (
            isinstance(col_series.dtype, pd.CategoricalDtype) or
            (unique_count < min(20, len(df) * 0.5) and dtype_str == 'object')
        )

        columns.append({
            "name": col,
            "dtype": dtype_str,
            "unique_count": unique_count,
            "is_datetime": is_datetime,
            "is_categorical": is_categorical
        })

    sample = None
    if n_rows > 0:
        try:
            sample_df = df.head(5).copy()
            # Convert datetime columns to strings for JSON serialization
            for col in sample_df.select_dtypes(include=['datetime64', 'datetime']).columns:
                sample_df[col] = sample_df[col].astype(str)
            sample = sample_df.to_dict(orient='records')
        except Exception:
            pass

    return {
        "n_rows": n_rows,
        "n_cols": n_cols,
        "columns": columns,
        "sample": sample
    }


def get_ai_suggestion(
    df,
    provider: str = "openai",
    api_key: Optional[str] = None,
    model: Optional[str] = None,
    **kwargs
) -> Optional[Dict[str, Any]]:
    """
    Get AI-powered plot suggestion.

    Parameters
    ----------
    df : pandas.DataFrame
        DataFrame to analyze
    provider : str, default "openai"
        AI provider: 'openai', 'anthropic', or 'ollama'
    api_key : str, optional
        API key for the provider. If not provided, uses environment variable:
        - OpenAI: OPENAI_API_KEY
        - Anthropic: ANTHROPIC_API_KEY
        - Ollama: No API key needed (local)
    model : str, optional
        Model name. Provider-specific defaults:
        - OpenAI: gpt-4o-mini
        - Anthropic: claude-3-haiku-20240307
        - Ollama: llama3.2:1b
    **kwargs
        Additional arguments (temperature, host for Ollama, etc.)

    Returns
    -------
    dict or None
        Suggestion with keys: kind, x, y, color, size, confidence, reason
        Returns None if AI fails or is not available.
    """
    if provider not in PROVIDERS:
        logger.warning(f"Unknown AI provider: {provider}. Available: {list(PROVIDERS.keys())}")
        return None

    # Create provider instance
    provider_class = PROVIDERS[provider]
    provider_kwargs = {}

    if api_key:
        provider_kwargs['api_key'] = api_key

    if model:
        provider_kwargs['model'] = model

    # Provider-specific args
    if provider == 'ollama':
        if 'host' in kwargs:
            provider_kwargs['host'] = kwargs['host']
    elif provider == 'openai':
        # OpenAI-specific
        pass
    elif provider == 'anthropic':
        # Anthropic-specific
        pass

    try:
        ai_provider = provider_class(**provider_kwargs)
    except Exception as e:
        logger.error(f"Failed to initialize AI provider: {e}")
        return None

    # Check availability
    if not ai_provider.is_available():
        logger.warning(f"AI provider '{provider}' is not available (missing API key or server not running)")
        return None

    # Extract metadata
    metadata = _extract_metadata(df)

    # Build prompt
    plot_types_list = ", ".join(sorted(VALID_PLOT_TYPES))
    prompt = PLOT_SUGGESTION_PROMPT.format(
        metadata=_format_metadata_for_ai(metadata),
        plot_types_list=plot_types_list
    )

    # Generate suggestion
    logger.debug(f"Requesting AI suggestion from {provider}...")
    response = ai_provider.generate(prompt, **kwargs)

    if "error" in response:
        logger.warning(f"AI suggestion failed: {response['error']}")
        return None

    # Validate and normalize
    kind = response.get("kind", "scatter")
    if kind not in VALID_PLOT_TYPES:
        logger.warning(f"AI suggested invalid plot type: {kind}")
        return None

    # Normalize y to list
    y = response.get("y", [])
    if isinstance(y, str):
        y = [y]

    suggestion = {
        "kind": kind,
        "x": response.get("x"),
        "y": y,
        "color": response.get("color"),
        "size": response.get("size"),
        "confidence": float(response.get("confidence", 0.5)),
        "reason": response.get("reason", "")
    }

    logger.info(f"AI suggestion: {kind} plot (confidence: {suggestion['confidence']:.2f})")
    return suggestion
