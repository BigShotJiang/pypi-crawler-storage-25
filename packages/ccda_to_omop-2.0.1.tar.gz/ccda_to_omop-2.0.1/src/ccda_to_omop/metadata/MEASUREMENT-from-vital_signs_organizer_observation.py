
from numpy import int32
import ccda_to_omop.value_transformations as VT
# VITAL SIGNS
metadata = {
    'MEASUREMENT-from-vital_signs_organizer_observation': {
        'root': {
            'config_type': 'ROOT',
            'expected_domain_id': 'Measurement',
            # Vital Signs section
            'element':
              ("./hl7:component/hl7:structuredBody/hl7:component/hl7:section/"
               "hl7:templateId[@root='2.16.840.1.113883.10.20.22.2.4'  or @root='2.16.840.1.113883.10.20.22.2.4.1']"
               "/../hl7:entry/hl7:organizer/hl7:component/hl7:observation")
        },

        'measurement_id_root': {
            'config_type': 'FIELD',
            'element': 'hl7:id[not(@nullFlavor="UNK")]',
            'attribute': 'root'
        },
        'measurement_id_extension': {
            'config_type': 'FIELD',
            'element': 'hl7:id[not(@nullFlavor="UNK")]',
            'attribute': 'extension'
        },
        'measurement_id': {
            'config_type': 'HASH',
            'fields' : ['person_id', 'provider_id',
                        # 'visit_occurrence_id',
                        'measurement_concept_code', 'measurement_concept_codeSystem',
                        'measurement_date', 'measurement_datetime',
                        'value_as_number', 'value_as_concept_id',
                        'measurement_id_root', 'measurement_id_extension',
                        'value_source_value', 'unit_source_value'],
            'order': 1
        },

        'person_id': {
            'config_type': 'FK',
            'FK': 'person_id',
            'order': 2
        },

        'measurement_concept_code': {
            'config_type': 'FIELD',
            'element': "hl7:code" ,
            'attribute': "code"
        },
        'measurement_concept_codeSystem': {
            'config_type': 'FIELD',
            'element': "hl7:code",
            'attribute': "codeSystem"
        },
        'measurement_concept_id': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_concept_id,
            'argument_names': {
                'concept_code': 'measurement_concept_code',
                'vocabulary_oid': 'measurement_concept_codeSystem',
            },
            'order': 3
        },

        'domain_id': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_domain_id,
            'argument_names': {
                'concept_code': 'measurement_concept_code',
                'vocabulary_oid': 'measurement_concept_codeSystem',
            }
        },

        'measurement_date_eT': {
            'config_type': 'FIELD',
            'data_type':'DATE',
            'element': "hl7:effectiveTime",
            'attribute': "value",
            'priority' : ['measurement_date', 1]
        },
        'measurement_date_low': {
            'config_type': 'FIELD',
            'data_type':'DATE',
            'element': "hl7:effectiveTime/hl7:low",
            'attribute': "value",
            'priority' : ['measurement_date', 2]
        },
        'measurement_date_high': {
            'config_type': 'FIELD',
            'data_type':'DATE',
            'element': "hl7:effectiveTime/hl7:high",
            'attribute': "value",
            'priority' : ['measurement_date', 3]
        },
        'measurement_date': {
            'config_type': 'PRIORITY',
            'order': 4
        },

        'measurement_datetime_eT': {
            'config_type': 'FIELD',
            'data_type':'DATETIME',
            'element': "hl7:effectiveTime",
            'attribute': "value",
            'priority' : ['measurement_datetime', 1]
        },
        'measurement_datetime_low': {
            'config_type': 'FIELD',
            'data_type':'DATETIME',
            'element': "hl7:effectiveTime/hl7:low",
            'attribute': "value",
            'priority' : ['measurement_datetime', 2]
        },
        'measurement_datetime_high': {
            'config_type': 'FIELD',
            'data_type':'DATETIME',
            'element': "hl7:effectiveTime/hl7:high",
            'attribute': "value",
            'priority' : ['measurement_datetime', 3]
        },
        'measurement_datetime': {
            'config_type': 'PRIORITY',
            'order': 5
        },
        'measurement_time': {
            'config_type': 'CONSTANT',
            'constant_value' : '',
            'order': 6
        },
        'measurement_type_concept_id': {
            'config_type': 'CONSTANT',
            'constant_value' : int32(32827),
            'order': 7
        },
        'operator_concept_id': {
            'config_type': 'CONSTANT',
            'constant_value': "0",
            'order': 8
        },

        'value_type': {
            'config_type': 'FIELD',
            'element': "hl7:value",
            'attribute': "{http://www.w3.org/2001/XMLSchema-instance}type",
        },

        'value_as_number_pq': {
            'config_type': 'FIELD',
            'data_type': 'FLOAT',
            'element': 'hl7:value[@xsi:type="PQ"]' ,
            'attribute': "value",
            'priority': ['value_as_number', 1]
        },
        'value_as_number': {
            'config_type': 'PRIORITY',
            'order': 9
        },


        'value_as_code_CD': {
            'config_type': 'FIELD',
            'element': 'hl7:value[@xsi:type="CD"]' ,
            'attribute': "code",
        },
        'value_as_codeSystem_CD': {
            'config_type': 'FIELD',
            'element': 'hl7:value[@xsi:type="CD"]' ,
            'attribute': "codeSystem",
        },
        'value_as_concept_id_CD': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_concept_id,
            'argument_names': {
                'concept_code': 'value_as_code_CD',
                'vocabulary_oid': 'value_as_codeSystem_CD',
            },
            'priority': ['value_as_concept_id', 2]
        },
        'value_as_code_CE': {
            'config_type': 'FIELD',
            'element': 'hl7:value[@xsi:type="CE"]' ,
            'attribute': "code",
        },
        'value_as_codeSystem_CE': {
            'config_type': 'FIELD',
            'element': 'hl7:value[@xsi:type="CE"]' ,
            'attribute': "codeSystem",
        },
        'value_as_concept_id_CE': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_concept_id,
            'argument_names': {
                'concept_code': 'value_as_code_CE',
                'vocabulary_oid': 'value_as_codeSystem_CE',
            },
            'priority': ['value_as_concept_id', 1]
        },
        'value_as_code_XX': {
            'config_type': 'FIELD',
            'element': 'hl7:value' ,
            'attribute': "code",
        },
        'value_as_codeSystem_XX': {
            'config_type': 'FIELD',
            'element': 'hl7:value' ,
            'attribute': "codeSystem",
        },
        'value_as_concept_id_XX': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_concept_id,
            'argument_names': {
                'concept_code': 'value_as_code_XX',
                'vocabulary_oid': 'value_as_codeSystem_XX',
            },
            'priority': ['value_as_concept_id', 3]
        },
        'value_as_concept_id': {
            'config_type': 'PRIORITY',
            'order':  10
        },

        'unit_source_value':  {
            'config_type': 'FIELD',
            'element': 'hl7:value',
            'attribute': 'unit',
            'order':  19
        },
        'unit_codeSystem':  {
            'config_type': 'CONSTANT',
            'constant_value' : '2.16.840.1.113883.6.8',
        },
        'unit_concept_id': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_concept_id,
            'argument_names': {
                'concept_code': 'unit_source_value',
                'vocabulary_oid': 'unit_codeSystem',
            },
            'order': 11
        },

        'range_low': { 'config_type': None, 'order':  12 },
        'range_high': { 'config_type': None, 'order':  13 },
        'provider_id': { 'config_type': None, 'order':  14 },

        'visit_occurrence_id':  {
            'config_type': 'FK',
            'FK': 'visit_occurrence_id',
            'order':  15
        },
        'visit_detail_id':  { 'config_type': None, 'order':  16 },

        'measurement_source_value':     {
           'config_type': 'DERIVED',
           'FUNCTION': VT.concat_fields,
           'argument_names': {
                   'first_field': 'measurement_concept_code',
                   'second_field': 'measurement_concept_codeSystem',
           },
            'order':  17
        },


        'measurement_source_concept_id': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_source_concept_id,
            'argument_names': {
                'concept_code': 'measurement_concept_code',
                'vocabulary_oid': 'measurement_concept_codeSystem',
            },
            'order': 18
        },
        # (above) 'unit_source_value': { 'config_type': None,  'order':  19}

        'value_source_value_text': {
            'config_type': 'FIELD',
            'element': 'hl7:value' ,
            'attribute': "#text",
        },
        'value_source_value_quantity': {
            'config_type': 'FIELD',
            'element': 'hl7:value' ,
            'attribute': "value",
        },
        'value_source_value': {
            'config_type': 'DERIVED2',
            'FUNCTION': VT.concat_field_list_values,
            'argument_list': {
                'key_list': [
                    'value_as_codeSystem_CE',
                    'value_as_code_CE',
                    'value_as_codeSystem_CD',
                    'value_as_code_CD',
                    'value_as_codeSystem_XX',
                    'value_as_code_XX',
                    'value_source_value_quantity',
                    'value_source_value_text'
                ]
            },
            'order':20
        },

        'data_partner_id': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.get_data_partner_id,
            'argument_names': { 'filename': 'filename' },
            'order': 24
        },

        'filename' : {
            'config_type': 'FILENAME',
            'order':100
        },
        'cfg_name' : {
            'config_type': 'CONSTANT',
            'constant_value': 'MEASUREMENT-from-vital_signs_organizer_observation',
            'length': 100,
            'order':101
        }
    }
}
