
from numpy import int32
import ccda_to_omop.value_transformations as VT

metadata = {
    'Observation': {
        'root': {
            'config_type': 'ROOT',
            'expected_domain_id': 'Observation',
            # Results section
            'element':
              ("./hl7:component/hl7:structuredBody/hl7:component/hl7:section/"
               "hl7:templateId[@root='2.16.840.1.113883.10.20.22.2.3.1'  or @root='2.16.840.1.113883.10.20.22.2.3']"
               "/../hl7:entry/hl7:organizer/hl7:component/hl7:observation")
             },

        'observation_id_root': {
            'config_type': 'FIELD',
            'element': 'hl7:id[not(@nullFlavor="UNK")]',
            'attribute': 'root'
        },
        'observation_id_extension': {
            'config_type': 'FIELD',
            'element': 'hl7:id[not(@nullFlavor="UNK")]',
            'attribute': 'extension'
        },
        'observation_id': {
            'config_type': 'HASH',
            'fields' : ['person_id', 'provider_id',
                        # 'visit_occurrence_id',
                        'observation_concept_code', 'observation_concept_codeSystem',
                        'observation_date', 'observation_datetime',
                        'value_as_string', 'value_as_number', 'value_as_concept_id',
                        'observation_id_extension', 'observation_id_root','unit_source_value'],
            'order': 1
        },


        'person_id': {
            'config_type': 'FK',
            'FK': 'person_id',
            'order': 2
        },

        'observation_concept_code': {
            'config_type': 'FIELD',
            'element': "hl7:code" ,
            'attribute': "code"
        },
        'observation_concept_codeSystem': {
            'config_type': 'FIELD',
            'element': "hl7:code",
            'attribute': "codeSystem"
        },
        'observation_concept_id': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_concept_id,
            'argument_names': {
                'concept_code': 'observation_concept_code',
                'vocabulary_oid': 'observation_concept_codeSystem',
            },
            'order': 3
        },

        'domain_id': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_domain_id,
            'argument_names': {
                'concept_code': 'observation_concept_code',
                'vocabulary_oid': 'observation_concept_codeSystem',
            }
        },

        'observation_date_effectiveTime': {
            'config_type': 'FIELD',
            'data_type':'DATE',
            'element': "hl7:effectiveTime",
            'attribute': "value",
            'priority': ['observation_date', 1]
        },
        'observation_date_low': {
            'config_type': 'FIELD',
            'data_type':'DATE',
            'element': "hl7:effectiveTime/hl7:low",
            'attribute': "value",
            'priority': ['observation_date', 2]
        },
        'observation_date_high': {
            'config_type': 'FIELD',
            'data_type':'DATE',
            'element': "hl7:effectiveTime/hl7:high",
            'attribute': "value",
            'priority': ['observation_date', 3]
        },
        'observation_date': {
            'config_type': 'PRIORITY',
            'order': 4
        },

        'observation_datetime_effectiveTime': {
            'config_type': 'FIELD',
            'element': "hl7:effectiveTime",
            'attribute': "value",
            'data_type': 'DATETIME',
            'priority': ['observation_datetime', 1]
        },
        'observation_datetime_low': {
            'config_type': 'FIELD',
            'element': "hl7:effectiveTime/hl7:low",
            'attribute': "value",
            'data_type': 'DATETIME',
            'priority': ['observation_datetime', 2]
        },
        'observation_datetime_high': {
            'config_type': 'FIELD',
            'data_type':'DATETIME',
            'element': "hl7:effectiveTime/hl7:high",
            'attribute': "value",
            'priority': ['observation_datetime', 3]
        },
        'observation_datetime': {
            'config_type': 'PRIORITY',
            'order': 5
        },

        'observation_type_concept_id': {
            'config_type': 'CONSTANT',
            'constant_value' : int32(32827),
            'order': 6
        },

        'value_as_number': {
            'config_type': 'FIELD',
            'data_type':'FLOAT',
            'element': 'hl7:value[@xsi:type="PQ"]' ,
            'attribute': "value",
            'order': 7
        },

        'value_as_string': {
            'config_type': 'FIELD',
            'element': 'hl7:value',  # 'element': 'hl7:value[@xsi:type="ST"]',
            'attribute': "#text",
            'order': 8
        },

        'value_as_code_CD': {
            'config_type': 'FIELD',
            'element': 'hl7:value[@xsi:type="CD"]' ,
            'attribute': "code",
        },
        'value_as_codeSystem_CD': {
            'config_type': 'FIELD',
            'element': 'hl7:value[@xsi:type="CD"]' ,
            'attribute': "codeSystem",
        },
        'value_as_concept_id_CD': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_concept_id,
            'argument_names': {
                'concept_code': 'value_as_code_CD',
                'vocabulary_oid': 'value_as_codeSystem_CD',
            },
            'priority': ['value_as_concept_id', 2]
        },
        'value_as_code_CE': {
            'config_type': 'FIELD',
            'element': 'hl7:value[@xsi:type="CE"]' ,
            'attribute': "code",
        },
        'value_as_codeSystem_CE': {
            'config_type': 'FIELD',
            'element': 'hl7:value[@xsi:type="CE"]' ,
            'attribute': "codeSystem",
        },
        'value_as_concept_id_CE': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_concept_id,
            'argument_names': {
                'concept_code': 'value_as_code_CE',
                'vocabulary_oid': 'value_as_codeSystem_CE',
            },
            'priority': ['value_as_concept_id', 1]
        },
        'value_as_concept_id_na': {
            'config_type': 'CONSTANT',
            'constant_value' : 0,
            'priority': ['value_as_concept_id', 100]
        },
        'value_as_concept_id': {
            'config_type': 'PRIORITY',
            'order':  9
        },

        'qualifier_concept_id' : { 'config_type': None, 'order': 10 },

        'unit_source_value':  {
            'config_type': 'FIELD',
            'element': 'hl7:value',
            'attribute': 'unit',
            'order':  17
        },
        'unit_codeSystem':  {
            'config_type': 'CONSTANT',
            'constant_value' : 'http://unitsofmeasure.org',
        },
        'unit_concept_id': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.codemap_xwalk_concept_id,
            'argument_names': {
                'concept_code': 'unit_source_value',
                'vocabulary_oid': 'unit_codeSystem',
            },
            'order': 11
        },

        'provider_id': { 'config_type': None, 'order': 12 },

        'visit_occurrence_id':  {
            'config_type': 'FK',
            'FK': 'visit_occurrence_id',
            'order': 13
        },

        'visit_detail_id': { 'config_type': None, 'order': 14 },

        'observation_source_value': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.concat_fields,
            'argument_names': {
                'first_field': 'observation_concept_code',
                'second_field': 'observation_concept_codeSystem',
            },
            'order' : 15
        },

        'observation_source_concept_id': { 'config_type': None, 'order': 16 },

        # (above) 'unit_source_value': {  'config_type': 'CONSTANT', 'constant_value' : '', 'order': 17  },
        'qualifier_source_value': {
            'config_type': 'CONSTANT',
            'constant_value' : '',
            'order': 18
        },
        'data_partner_id': {
            'config_type': 'DERIVED',
            'FUNCTION': VT.get_data_partner_id,
            'argument_names': { 'filename': 'filename' },
            'order': 20
        },

        'filename' : {
            'config_type': 'FILENAME',
            'order':100
        },
        'cfg_name' : {
            'config_type': 'CONSTANT',
            'constant_value': 'Observation',
            'length': 100,
            'order':101
        }
    }
}




