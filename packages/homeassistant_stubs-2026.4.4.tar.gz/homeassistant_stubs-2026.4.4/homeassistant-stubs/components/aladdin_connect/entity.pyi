from .const import DOMAIN as DOMAIN
from .coordinator import AladdinConnectCoordinator as AladdinConnectCoordinator
from _typeshed import Incomplete
from genie_partner_sdk.client import AladdinConnectClient as AladdinConnectClient
from genie_partner_sdk.model import GarageDoor as GarageDoor
from homeassistant.helpers.device_registry import DeviceInfo as DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity as CoordinatorEntity

class AladdinConnectEntity(CoordinatorEntity[AladdinConnectCoordinator]):
    _attr_has_entity_name: bool
    _door_id: Incomplete
    _attr_device_info: Incomplete
    _device_id: Incomplete
    _number: Incomplete
    def __init__(self, coordinator: AladdinConnectCoordinator, door_id: str) -> None: ...
    @property
    def available(self) -> bool: ...
    @property
    def door(self) -> GarageDoor: ...
    @property
    def client(self) -> AladdinConnectClient: ...
