"""Tests for assets module."""
