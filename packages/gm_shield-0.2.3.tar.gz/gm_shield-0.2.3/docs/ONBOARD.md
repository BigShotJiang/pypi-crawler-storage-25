# Market Maker Onboarding

Securely share your exchange API credentials with Glass using isolated enclaves.

## How It Works

```mermaid
flowchart LR
    MM[Market Maker]
    S3[Encrypted S3 Storage]
    KMS[KMS Key]
    Enclave[Isolated EC2 Enclave]
    Glass[Glass Team]

    MM -->|1. Store and configure API keys| S3
    S3 -.->|Encryption| KMS
    Glass -->|2. Deploy| Enclave
    MM -->|3. Approve access| KMS
    Enclave -->|4. Utilize access| S3
    Enclave -.->|Decrypt| KMS

    style MM fill:#3B82F6,color:#fff
    style S3 fill:#3B82F6,color:#fff
    style KMS fill:#3B82F6,color:#fff
    style Enclave fill:#10B981,color:#fff
    style Glass fill:#8B5CF6,color:#fff
```

**Your credentials never leave the isolated enclave**

## Security Model

| Layer          | What You Control        | Security Guarantee                 |
|----------------|-------------------------|------------------------------------|
| **Storage**    | S3 bucket + KMS key     | Credentials encrypted at rest      |
| **Access**     | Enclave approval (PCR8) | Only approved enclaves can decrypt |
| **Revocation** | Revoke anytime          | Instantly cut off enclave access   |

**Key point**: Glass deploys and manages enclaves, but you control who can access your keys through KMS policies.

## Prerequisites

- Python 3.12+
- AWS CLI configured with credentials

## Installation

```bash
uv tool install gm-shield
```
Or from directly from the repo:
```bash
git clone git@github.com:glassmarkets/glassmarkets-keyshare.git
cd exchange-keyshare
git checkout v2
uv tool install
```

## Quick Start

### Step 1: Set up infrastructure

```bash
gm-shield setup
```

This creates:
- S3 bucket for encrypted credentials
- KMS key (you control it)
- Config saved to `~/.config/gm-shield/config.yaml`

**Share with Glass:**
- Bucket name
- Region

### Step 2: Glass deploys enclave

Glass will:
1. Deploy a Nitro Enclave in their AWS account
2. Provide you with the enclave's **Role ARN**
3. Provide you with the enclave's outbound **IP address** (for whitelisting)

### Step 3: Add your exchange credentials

```bash
gm-shield keys create
```

Interactive prompts for exchange and API credentials.

The enclave can now fetch and use your credentials securely.

**Note:** Remember to add the outbound IP address to your exchange API allowlist!

### Step 4: Approve enclave access

```bash
gm-shield enclave approve
```

- Enter the enclave Role ARN (from Glass)
- Enter the enclave PCR8 value: `2d4bd2e9ce136106537f13262b545c459e08ea760dacaef62350cbea418495f3be47926f8f8785ce1b2a653045bcd14c`
- **Optional:**
  - You can verify all PCRs in the https://github.com/glassmarkets/shield-worker/actions/workflows/release.yml release notes under the `Measurements` section. Optionally add `PCR0` if you want to approve each release build.

This updates your KMS policy to allow the enclave to decrypt credentials and S3 policy to allow the enclave to read from S3.

## Daily Operations

### View credentials

```bash
gm-shield keys list
```

### Update credential

```bash
gm-shield keys update <key-name>
```

### Delete credential

```bash
gm-shield keys delete <key-name>
```

### View configuration

```bash
gm-shield config
```

Shows:
- S3 bucket and KMS key
- Deployed enclaves (with labels)
- Approved enclave attestation values

## Access Control

### Approve additional enclaves

```bash
gm-shield enclave approve
```

### Revoke all access

```bash
gm-shield enclave revoke
```

### Rotate PCR0
```bash
gm-shield enclave rotate
```

Immediately removes all enclave access to your credentials.

### Delete all infrastructure
- You can delete all resources, revoking access to all keys using the following command

```bash
gm-shield teardown
```

## Troubleshooting

### "No approved enclave"

Run `gm-shield enclave approve` with the Role ARN and PCR8 from Glass.

### "Enclave already approved"

Run `gm-shield enclave revoke` first, then approve with new values.

### View config

```bash
gm-shield config
```

Check the "Approved Enclave" section for current PCR8 and Role ARN.