# gm-shield

CLI tool for securely sharing exchange API credentials using Nitro Enclaves for isolated credential access.

## Architecture

**Complete isolation:**
- Credentials are stored in S3 with KMS encryption
- Nitro Enclave runs in an isolated VM with no persistent storage
- Enclave fetches credentials using KMS attestation (PCR8(optionally PCR0) values)
- Credentials never exposed to the host EC2 instance

**Single or multi-account:**
- **Multi-account**: GM runs enclave infrastructure, MM owns KMS/S3 (recommended)
- **Single account**: Run everything in one AWS account yourself

### Data Flow

```mermaid
sequenceDiagram
    participant MM as Market Maker
    participant S3 as S3 Bucket
    participant KMS as KMS Key
    participant Enclave as Nitro Enclave
    participant GM as GlassMarkets

    MM->>S3: 1. Store encrypted credentials
    MM->>KMS: 2. Grant enclave access (PCR8)
    GM->>Enclave: 3. Deploy enclave
    Enclave->>KMS: 4. Request decryption (PCR8 attestation)
    KMS->>Enclave: 5. Return credentials
    Note over Enclave: Credentials isolated from host
```

### Component Isolation

```mermaid
graph TB
    subgraph "Market Maker Account"
        S3[S3 Bucket<br/>Encrypted Credentials]
        KMS[KMS Key<br/>You Control]
        S3 -.->|Encryption| KMS
    end

    subgraph "GlassMarkets Account"
        EC2[EC2 Instance<br/>Host]
        Enclave[Nitro Enclave<br/>Isolated VM]

        EC2 -->|Hosts| Enclave
    end

    Enclave -->|PCR8 Attestation| KMS
    KMS -->|Decrypt| Enclave
    Enclave -->|Fetch| S3

    style Enclave fill:#10B981,stroke:#047857,color:#fff
    style EC2 fill:#F59E0B,stroke:#D97706,color:#fff
    style KMS fill:#3B82F6,stroke:#2563EB,color:#fff
    style S3 fill:#3B82F6,stroke:#2563EB,color:#fff
```

### Security Model

| Layer              | Access                       | Isolation                      |
|--------------------|------------------------------|--------------------------------|
| **Host EC2**       | Run/stop enclaves            | No credential access           |
| **Nitro Enclave**  | KMS decrypt + S3 read        | Isolated VM, vsock only        |
| **KMS Key Policy** | Requires PCR8 (signing cert) | Optional PCR0 (proof of build) |
| **Credentials**    | S3 encrypted, versioned      | Never exposed to host          |


## Prerequisites

- Python 3.12+
- AWS CLI configured with credentials

## Installation

```bash
pip install gm-shield
```

## Quick Start

### Set up keyshare infra

```bash
gm-shield setup
```

This creates:
- An S3 bucket for storing credentials (KMS-encrypted, versioned)
- A KMS key for encryption (you control it)
- Config saved to `~/.config/gm-shield/config.yaml`

### Deploy enclave infrastructure

```bash
gm-shield enclave deploy
```

This deploys:
- EC2 instance with Nitro Enclave support
- IAM role for the enclave
- Outputs the **Role ARN** attached to the instance profile needed for approval

### Get PCR values

- From the `https://github.com/glassmarkets/shield-worker/actions/workflows/release.yml` release notes pick up PCR values.

- Look for the `PCR8` value in the `Measurements` section.
- If you want to approve each release build optionally add `PCR0` value.

### Approve enclave access

```bash
gm-shield enclave approve \
  --role-arn <enclave-role-arn> \
  --pcr8 <pcr8-value>
```
or interactive
```bash
gm-shield enclave approve
```

This updates the KMS key policy to allow the enclave (with PCR8 attestation) to decrypt credentials.

### Add credentials

```bash
gm-shield keys create
```

Follow the interactive prompts to select an exchange and enter your API credentials. The enclave will fetch and use them securely.

## Commands

### Market Maker: Credential Storage

```bash
gm-shield setup              # Create S3 bucket, KMS key
gm-shield config             # Display current configuration
gm-shield teardown           # Delete infrastructure
gm-shield keys list          # List all credentials
gm-shield keys create        # Add new credential (interactive)
gm-shield keys update        # Update pairs or labels
gm-shield keys delete        # Delete a credential
```

### GlassMarkets: Enclave Infrastructure

```bash
gm-shield enclave deploy     # Deploy Nitro Enclave infrastructure (prompts for labels)
gm-shield enclave teardown   # Delete enclave infrastructure (interactive if multiple)
gm-shield config             # Display configuration (shows all enclaves)
```

### Access Control (Market Maker approves/revokes)

```bash
gm-shield enclave approve    # Grant enclave access (requires PCR8)
gm-shield enclave revoke     # Revoke enclave access
gm-shield enclave rotate     # Rotate PCR attestation values
```

## Configuration

Config is stored at `~/.config/gm-shield/config.yaml`:

```yaml
bucket: my-credentials-bucket
region: us-east-1
stack_name: my-keyshare-stack
stack_id: arn:aws:cloudformation:...
kms_key_arn: arn:aws:kms:...

enclaves:
  - stack_name: gm-enclave-mm1
    stack_id: arn:aws:cloudformation:...
    region: eu-central-1
    role_arn: arn:aws:iam::...:role/...
    instance_profile_arn: arn:aws:iam::...:instance-profile/...
    instance_id: i-xxxxxxxx
    labels:
      - mm1
      - production

approved_enclave:
  role_arn: arn:aws:iam::...:role/...
  pcr8: 2d4bd2e9ce136106537f13262b545c459e08ea760dacaef62350cbea418495f3be47926f8f8785ce1b2a653045bcd14c
  pcr0: null
  approved_at: 2026-03-31T21:00:00Z
```


## Workflow

1. **Run setup**: `gm-shield setup` → creates KMS + S3
2. **Deploy enclave**: `gm-shield enclave deploy` → deploys enclave stack (prompts for labels)
3. **Get PCR8**: From GitHub Actions release notes (shield-worker release workflow)
4. **Approve**: `gm-shield enclave approve --role-arn <...> --pcr8 <...>`
5. **Add credentials**: `gm-shield keys create`

**Multiple enclaves**: Run `gm-shield enclave deploy` multiple times to deploy additional enclaves. Each deployment prompts for labels (e.g., `mm1,production`) to track which MM each enclave serves.

## Security Model

- **Credentials** are stored in S3 with KMS encryption
- **Enclave access** is scoped to specific PCR8 (signing certificate) values
- **Revoke anytime** with `gm-shield enclave revoke`
- **Isolation**: Credentials decrypted only inside the Nitro Enclave, never exposed to the host

## Development

```bash
uv sync

uv run pytest

uv run pyright
```