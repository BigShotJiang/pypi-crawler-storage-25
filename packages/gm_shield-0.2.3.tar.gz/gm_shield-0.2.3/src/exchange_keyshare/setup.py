"""Credentials stack creation logic."""

from __future__ import annotations

import secrets
import string
from dataclasses import dataclass
from typing import TYPE_CHECKING

import boto3
from botocore.exceptions import ClientError

from exchange_keyshare.cfn import load_credentials_template

if TYPE_CHECKING:
    from mypy_boto3_cloudformation import CloudFormationClient

from exchange_keyshare.config import get_default_region


def generate_bucket_name() -> str:
    """Generate a unique S3 bucket name."""
    chars = string.ascii_lowercase + string.digits
    suffix = "".join(secrets.choice(chars) for _ in range(12))
    return f"gm-shield-{suffix}"


@dataclass
class SetupResult:
    """Result of stack creation."""

    bucket: str
    region: str
    stack_name: str
    stack_id: str
    kms_key_arn: str


def start_stack_creation(
    bucket_name: str | None = None,
    region: str | None = None,
) -> tuple[str, str, CloudFormationClient]:
    """Start CloudFormation stack creation. Returns (stack_name, region, cfn_client)."""
    bucket = bucket_name or generate_bucket_name()
    region = region or get_default_region()
    stack_name = bucket

    cfn: CloudFormationClient = boto3.client("cloudformation", region_name=region)  # type: ignore[reportUnknownVariableType]
    template = load_credentials_template()

    params = [
        {"ParameterKey": "BucketName", "ParameterValue": bucket},
    ]

    try:
        cfn.create_stack(
            StackName=stack_name,
            TemplateBody=template,
            Parameters=params,  # type: ignore[reportArgumentType]
            OnFailure="DELETE",
        )
    except ClientError as e:
        if "AlreadyExistsException" in str(e):
            raise Exception(f"Stack {stack_name} already exists") from e
        raise

    return stack_name, region, cfn


def get_stack_outputs(stack_name: str, region: str) -> SetupResult:
    """Get outputs from a completed stack."""
    cfn: CloudFormationClient = boto3.client("cloudformation", region_name=region)  # type: ignore[reportUnknownVariableType]  # type: ignore[reportUnknownVariableType]

    response = cfn.describe_stacks(StackName=stack_name)
    stack = response["Stacks"][0]
    stack_id = stack.get("StackId", "")
    outputs: dict[str, str] = {
        o["OutputKey"]: o["OutputValue"]
        for o in stack.get("Outputs", [])
        if "OutputKey" in o and "OutputValue" in o
    }

    return SetupResult(
        bucket=outputs["BucketName"],
        region=region,
        stack_name=stack_name,
        stack_id=stack_id,
        kms_key_arn=outputs["KmsKeyArn"],
    )
