"""Version check against PyPI with a one-day cache."""

import json
import sys
import urllib.request
from datetime import UTC, datetime, timedelta
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

_PACKAGE_NAME = "gm-shield"
_PYPI_URL = f"https://pypi.org/pypi/{_PACKAGE_NAME}/json"
_CACHE_TTL = timedelta(days=1)


def _cache_path() -> Path:
    return Path.home() / ".config" / "gm-shield" / "meta.json"


def _current_version() -> str:
    try:
        return version(_PACKAGE_NAME)
    except PackageNotFoundError:
        return "0.0.0"


def _load_cache(path: Path) -> dict[str, str] | None:
    if not path.exists():
        return None
    try:
        with open(path) as f:
            data = json.load(f)
        if isinstance(data, dict):
            versions = data.get("versions")
            if isinstance(versions, dict):
                return versions  # type: ignore[return-value]
    except Exception:
        pass
    return None


def _save_cache(path: Path, latest: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # Preserve any existing top-level keys
    existing: dict[str, object] = {}
    if path.exists():
        try:
            with open(path) as f:
                existing = json.load(f)
        except Exception:
            pass
    existing["versions"] = {
        "latest": latest,
        "checked_at": datetime.now(tz=UTC).isoformat(),
    }
    try:
        with open(path, "w") as f:
            json.dump(existing, f, indent=2)
    except Exception:
        pass


def _is_stale(versions: dict[str, str] | None) -> bool:
    if versions is None:
        return True
    raw = versions.get("checked_at", "")
    if not raw:
        return True
    try:
        checked_at = datetime.fromisoformat(raw)
        return datetime.now(tz=UTC) - checked_at > _CACHE_TTL
    except Exception:
        return True


def _fetch_latest() -> str | None:
    try:
        req = urllib.request.Request(
            _PYPI_URL,
            headers={"User-Agent": f"gm-shield/{_current_version()} version-check"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data: dict[str, object] = json.loads(resp.read())
            info = data.get("info")
            if isinstance(info, dict):
                v = info.get("version")
                if isinstance(v, str):
                    return v
    except Exception:
        pass
    return None


def _version_tuple(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.split(".")[:3])
    except Exception:
        return 0, 0, 0


def check_for_update() -> tuple[str, str] | None:
    """Return (latest, current) if a newer version is available, else None.

    Fetches from PyPI when the cache is stale (once per day, max 5s).
    Called from call_on_close so the wait occurs after command output.
    """
    if not sys.stdout.isatty():
        return None

    path = _cache_path()
    versions = _load_cache(path)

    if _is_stale(versions):
        latest = _fetch_latest()
        if latest:
            _save_cache(path, latest)
            versions = {"latest": latest, "checked_at": datetime.now(tz=UTC).isoformat()}

    if versions is None:
        return None

    latest = versions.get("latest", "")
    if not latest:
        return None

    current = _current_version()
    if _version_tuple(latest) > _version_tuple(current):
        return latest, current

    return None
