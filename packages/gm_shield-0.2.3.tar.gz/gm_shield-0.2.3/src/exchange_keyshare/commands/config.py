"""Config command for displaying the current configuration."""

import click
from rich.console import Console
from rich.table import Table

from exchange_keyshare.config import Config


@click.command()
@click.pass_context
def config(ctx: click.Context) -> None:
    """Display current configuration."""
    cfg: Config = ctx.obj["config"]
    console = Console()

    if not cfg.stack_name:
        console.print("Not configured. Run [cyan]gm-shield setup[/cyan] first.")
        return

    table = Table(show_header=False, box=None)
    table.add_row("[cyan]Keyshare[/cyan]", "")
    table.add_column("Key", style="dim")
    table.add_column("Value", style="cyan")

    table.add_row("Bucket", cfg.bucket or "")
    table.add_row("Region", cfg.region or "")
    table.add_row("Stack Name", cfg.stack_name or "")
    table.add_row("Stack ID", cfg.stack_id or "")
    table.add_row("KMS Key ARN", cfg.kms_key_arn or "")
    table.add_row("Config Path", str(cfg.config_path))

    if cfg.enclaves:
        table.add_row("", "")
        table.add_row("[purple]Enclaves[/purple]", "")
        for i, enclave in enumerate(cfg.enclaves):
            labels_str = ", ".join(enclave.labels) if enclave.labels else "-"
            table.add_row(f"{i + 1}. Stack Name", enclave.stack_name)
            table.add_row("   Stack ID", enclave.stack_id)
            table.add_row("   Region", enclave.region)
            table.add_row("   Host Ref", enclave.host_ref)
            table.add_row("   Role ARN", enclave.role_arn)
            table.add_row("   Elastic IP", enclave.eip)
            table.add_row("   Labels", labels_str)
            if i < len(cfg.enclaves):
                table.add_row("", "")

    if cfg.approved_enclave:
        table.add_row("", "")
        table.add_row("[green]Approved Enclave[/green]", "")
        table.add_row("Role ARN", cfg.approved_enclave.role_arn)
        table.add_row("PCR8", cfg.approved_enclave.pcr8)
        if cfg.approved_enclave.pcr0:
            table.add_row("PCR0", cfg.approved_enclave.pcr0)
        table.add_row("Approved At", cfg.approved_enclave.approved_at)

    console.print(table)
