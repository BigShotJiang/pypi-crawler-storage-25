"""Enclave command group — deploy, approve, revoke, teardown, run."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any, NoReturn

import boto3
import click
import questionary
from botocore.exceptions import ClientError
from rich.console import Console, Group, RenderableType
from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner
from rich.table import Table
from rich.text import Text

from exchange_keyshare.cfn import (
    ResourceStatus,
    StackProgress,
    get_friendly_type,
    get_stack_console_url,
    poll_stack_deletion,
    poll_stack_progress,
    start_stack_deletion,
)
from exchange_keyshare.config import ApprovedEnclave, Config, EnclaveConfig, get_default_region
from exchange_keyshare.enclave import (
    ENCLAVE_DEFAULT_REGION,
    get_enclave_stack_outputs,
    resolve_enclave_network,
    start_enclave_stack_creation,
)
from exchange_keyshare.run import (
    ALL_RUNTIME_PARAMS,
    METADATA_PARAMS,
    REQUIRED_CREDS,
    STATUS_PROBES,
    acquire_lock,
    delete_stack_params,
    fetch_log_tail,
    force_unlock,
    get_lock_holder,
    get_runtime_params,
    poll_command,
    release_lock,
    resolve_active_instance,
    send_restart_command,
    send_shell_command,
    upsert_param,
    validate_preflight,
)


def _get_status_style(status: str) -> str:
    if "COMPLETE" in status and "ROLLBACK" not in status:
        return "green"
    elif "IN_PROGRESS" in status:
        return "yellow"
    elif "FAILED" in status or "ROLLBACK" in status:
        return "red"
    return "white"


def _get_status_icon(status: str) -> str:
    if "COMPLETE" in status and "ROLLBACK" not in status:
        return "[green]✓[/green]"
    elif "IN_PROGRESS" in status:
        return "[yellow]⋯[/yellow]"
    elif "FAILED" in status or "ROLLBACK" in status:
        return "[red]✗[/red]"
    return " "


def _build_progress_display(progress: StackProgress) -> RenderableType:
    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("", width=2)
    table.add_column("Resource", style="cyan", min_width=25)
    table.add_column("Type", style="dim")
    table.add_column("Status")

    def sort_key(item: tuple[str, ResourceStatus]) -> tuple[int, str]:
        _, r = item
        if "IN_PROGRESS" in r.status:
            return 0, r.logical_id
        elif "COMPLETE" in r.status:
            return 2, r.logical_id
        return 1, r.logical_id

    for _, resource in sorted(progress.resources.items(), key=sort_key):
        icon = _get_status_icon(resource.status)
        style = _get_status_style(resource.status)
        friendly_type = get_friendly_type(resource.resource_type)
        status_text = resource.status.replace("_", " ").title()
        table.add_row(icon, resource.logical_id, friendly_type, f"[{style}]{status_text}[/{style}]")

    if not progress.is_complete and not progress.is_failed:
        spinner = Spinner("dots", text=Text(" Deploying enclave infrastructure...", style="bold"))
        return Group(spinner, Text(""), table)

    return table


def _prompt_cancelled() -> NoReturn:
    click.echo("\nAborted.", err=True)
    raise SystemExit(1)


def _validate_required(text: str) -> bool | str:
    return True if text.strip() else "This field is required"


_MIN_MEMORY_MIB = 5120
_MIN_CPU_COUNT = 2
_MIN_VOLUME_GIB = 20
_ALLOWED_INSTANCE_TYPES = [
    "m5.xlarge",
    "m5.2xlarge",
    "c5.xlarge",
    "c5.2xlarge",
    "r5.xlarge",
    "r5.2xlarge",
]


def _validate_uri(text: str) -> bool | str:
    return True if text.strip() else "This field is required"


def _validate_memory_mib(text: str) -> bool | str:
    try:
        val = int(text.strip())
    except ValueError:
        return "Must be an integer"
    return True if val >= _MIN_MEMORY_MIB else f"Minimum is {_MIN_MEMORY_MIB} MiB"


def _validate_cpu_count(text: str) -> bool | str:
    try:
        val = int(text.strip())
    except ValueError:
        return "Must be an integer"
    if val < _MIN_CPU_COUNT:
        return f"Minimum {_MIN_CPU_COUNT} vCPUs (Nitro Enclave requirement)"
    return True


def _validate_volume_gib(text: str) -> bool | str:
    try:
        val = int(text.strip())
    except ValueError:
        return "Must be an integer"
    return True if val >= _MIN_VOLUME_GIB else f"Minimum is {_MIN_VOLUME_GIB} GiB"


def _parse_subnet_ids(text: str | None) -> list[str] | None:
    if text is None:
        return None
    subnet_ids = [item.strip() for item in text.split(",") if item.strip()]
    return subnet_ids or None


def _validate_pcr(text: str, required: bool = True) -> bool | str:
    text = text.strip()
    if not text:
        return "Value is required" if required else True
    if len(text) != 96 or not all(c in "0123456789abcdefABCDEF" for c in text):
        return "Must be a 96-character hex string (SHA384)"
    return True


def _prompt_pcr_values(
    pcr8: str | None, pcr0: str | None, prefix: str = ""
) -> tuple[str, str | None]:
    if pcr8 is None:
        pcr8 = questionary.text(f"{prefix}PCR8:", validate=_validate_pcr).ask()
        if pcr8 is None:
            _prompt_cancelled()
    if pcr0 is None:
        raw = questionary.text(
            f"{prefix}PCR0 (optional, leave blank to skip):",
            validate=lambda t: _validate_pcr(t, required=False),
        ).ask()
        if raw is None:
            _prompt_cancelled()
        pcr0 = raw.strip() or None
    return pcr8, pcr0


def _revoke_enclave_access(kms_key_arn: str, bucket: str, region: str, console: Console) -> None:
    """Remove enclave KMS and S3 policy statements. Raises SystemExit(1) on error."""
    console.print("Updating KMS key policy...", end=" ")
    try:
        kms = boto3.client("kms", region_name=region)  # type: ignore[reportUnknownVariableType]
        response = kms.get_key_policy(KeyId=kms_key_arn, PolicyName="default")
        kms_policy: dict[str, Any] = json.loads(response["Policy"])
        kms_policy["Statement"] = [
            s for s in kms_policy.get("Statement", []) if s.get("Sid") != "AllowEnclaveDecrypt"
        ]
        kms.put_key_policy(KeyId=kms_key_arn, PolicyName="default", Policy=json.dumps(kms_policy))
        console.print("[green]✓[/green]")
    except Exception as e:
        console.print(f"[red]✗[/red]\n[red]Error: {e}[/red]")
        raise SystemExit(1)

    console.print("Updating S3 bucket policy...", end=" ")
    try:
        s3 = boto3.client("s3", region_name=region)  # type: ignore[reportUnknownVariableType]
        try:
            s3_response = s3.get_bucket_policy(Bucket=bucket)
            s3_policy: dict[str, Any] = json.loads(s3_response["Policy"])
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchBucketPolicy":
                s3_policy = {"Version": "2012-10-17", "Statement": []}
            else:
                raise
        sids = {"AllowEnclaveListBucket", "AllowEnclaveGetObject"}
        s3_policy["Statement"] = [
            s for s in s3_policy.get("Statement", []) if s.get("Sid") not in sids
        ]
        s3.put_bucket_policy(Bucket=bucket, Policy=json.dumps(s3_policy))
        console.print("[green]✓[/green]")
    except Exception as e:
        console.print(f"[red]✗[/red]\n[red]Error: {e}[/red]")
        raise SystemExit(1)


_ENCLAVE_KMS_SID = "AllowEnclaveDecrypt"


def _build_kms_attestation_policy(
    role_arn: str, pcr8: str, pcr0: str | None = None
) -> dict[str, Any]:
    attestation: dict[str, str] = {
        "kms:RecipientAttestation:PCR8": pcr8,
        **({"kms:RecipientAttestation:PCR0": pcr0} if pcr0 else {}),
    }
    return {
        "Sid": _ENCLAVE_KMS_SID,
        "Effect": "Allow",
        "Principal": {"AWS": role_arn},
        "Action": ["kms:Decrypt", "kms:DescribeKey"],
        "Resource": "*",
        "Condition": {"StringEqualsIgnoreCase": attestation},
    }


_ENCLAVE_S3_LIST_SID = "AllowEnclaveListBucket"
_ENCLAVE_S3_GET_SID = "AllowEnclaveGetObject"
_ENCLAVE_S3_SIDS = {
    _ENCLAVE_S3_LIST_SID,
    _ENCLAVE_S3_GET_SID,
}


def _build_s3_policy(role_arn: str, bucket: str) -> list[dict[str, Any]]:
    return [
        {
            "Sid": _ENCLAVE_S3_LIST_SID,
            "Effect": "Allow",
            "Principal": {"AWS": role_arn},
            "Action": "s3:ListBucket",
            "Resource": f"arn:aws:s3:::{bucket}",
            "Condition": {"StringLike": {"s3:prefix": "exchange-credentials/*"}},
        },
        {
            "Sid": _ENCLAVE_S3_GET_SID,
            "Effect": "Allow",
            "Principal": {"AWS": role_arn},
            "Action": "s3:GetObject",
            "Resource": f"arn:aws:s3:::{bucket}/exchange-credentials/*",
        },
    ]


def _get_policy_statements(policy: dict[str, Any]) -> list[dict[str, Any]]:
    raw = policy.get("Statement", [])
    if isinstance(raw, dict):
        return [raw]
    if isinstance(raw, list):
        return [statement for statement in raw if isinstance(statement, dict)]
    return []


def _upsert_managed_statements(
    policy: dict[str, Any],
    managed_sids: set[str],
    new_statements: list[dict[str, Any]],
) -> dict[str, Any]:
    statements = [
        statement
        for statement in _get_policy_statements(policy)
        if statement.get("Sid") not in managed_sids
    ]
    statements.extend(new_statements)
    return {
        "Version": policy.get("Version", "2012-10-17"),
        "Statement": statements,
    }


def _error_code(error: ClientError) -> str:
    code = error.response.get("Error", {}).get("Code")
    return code if isinstance(code, str) else ""


def _error_message(error: ClientError) -> str:
    message = error.response.get("Error", {}).get("Message")
    return message if isinstance(message, str) else ""


def _is_kms_invalid_principal_error(error: ClientError) -> bool:
    return _error_code(error) == "MalformedPolicyDocumentException"


def _is_s3_invalid_principal_error(error: ClientError) -> bool:
    return (
        _error_code(error) == "MalformedPolicy"
        and "invalid principal" in _error_message(error).lower()
    )


def _put_enclave_policies(
    role_arn: str,
    pcr8: str,
    pcr0: str | None,
    kms_key_arn: str,
    bucket: str,
    region: str,
    console: Console,
) -> None:
    """Update KMS and S3 policies to grant enclave access.

    Replaces managed enclave policy statements in-place. This removes stale
    enclave ARNs while preserving unrelated account policy statements.
    """

    kms = boto3.client("kms", region_name=region)
    s3 = boto3.client("s3", region_name=region)
    console.print("Updating KMS key policy...", end=" ")
    desired_statement = _build_kms_attestation_policy(role_arn, pcr8, pcr0)
    desired_kms_policy: dict[str, Any]
    cleaned_kms_policy: dict[str, Any]

    try:
        response = kms.get_key_policy(KeyId=kms_key_arn, PolicyName="default")
        policy: dict[str, Any] = json.loads(response["Policy"])
        desired_kms_policy = _upsert_managed_statements(
            policy,
            managed_sids={_ENCLAVE_KMS_SID},
            new_statements=[desired_statement],
        )
        try:
            kms.put_key_policy(
                KeyId=kms_key_arn,
                PolicyName="default",
                Policy=json.dumps(desired_kms_policy),
            )
        except ClientError as error:
            if not _is_kms_invalid_principal_error(error):
                raise

            cleaned_kms_policy = _upsert_managed_statements(
                policy,
                managed_sids={_ENCLAVE_KMS_SID},
                new_statements=[],
            )
            kms.put_key_policy(
                KeyId=kms_key_arn,
                PolicyName="default",
                Policy=json.dumps(cleaned_kms_policy),
            )

            kms.put_key_policy(
                KeyId=kms_key_arn,
                PolicyName="default",
                Policy=json.dumps(desired_kms_policy),
            )
        console.print("[green]✓[/green]")
    except ClientError as e:
        console.print(f"[red]✗[/red]\n[red]Error: {e}[/red]")
        if _is_kms_invalid_principal_error(e):
            console.print(
                "[yellow]Hint: invalid principal can mean deleted role ARN (new principal) "
                "or invalid principals in existing KMS policy "
                "outside managed enclave SIDs.[/yellow]"
            )
        raise SystemExit(1)

    console.print("Updating S3 bucket policy...", end=" ")
    desired_s3_statements = _build_s3_policy(role_arn, bucket)
    try:
        try:
            response = s3.get_bucket_policy(Bucket=bucket)
            existing_policy: dict[str, Any] = json.loads(response["Policy"])
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchBucketPolicy":
                existing_policy = {"Version": "2012-10-17", "Statement": []}
            else:
                raise

        desired_s3_policy = _upsert_managed_statements(
            existing_policy,
            managed_sids=_ENCLAVE_S3_SIDS,
            new_statements=desired_s3_statements,
        )
        try:
            s3.put_bucket_policy(Bucket=bucket, Policy=json.dumps(desired_s3_policy))
        except ClientError as error:
            if not _is_s3_invalid_principal_error(error):
                raise

            cleaned_s3_policy = _upsert_managed_statements(
                existing_policy,
                managed_sids=_ENCLAVE_S3_SIDS,
                new_statements=[],
            )
            s3.put_bucket_policy(Bucket=bucket, Policy=json.dumps(cleaned_s3_policy))

            s3.put_bucket_policy(Bucket=bucket, Policy=json.dumps(desired_s3_policy))

        console.print("[green]✓[/green]")
    except ClientError as e:
        console.print(f"[red]✗[/red]\n[red]Error: {e}[/red]")
        if _is_s3_invalid_principal_error(e):
            console.print(
                "[yellow]Hint: invalid principal can mean deleted role ARN (new principal) "
                "or invalid principals in existing S3 policy outside managed enclave SIDs.[/yellow]"
            )
        raise SystemExit(1)


@click.group()
def enclave() -> None:
    """Manage Nitro Enclave deployment and access."""


@enclave.command("list", hidden=True)
@click.pass_context
def enclave_list(ctx: click.Context) -> None:
    """List all deployed enclaves."""
    cfg: Config = ctx.obj["config"]
    console = Console()

    if not cfg.enclaves:
        console.print("No enclaves deployed. Run [cyan]gm-shield enclave deploy[/cyan] first.")
        return

    table = Table(title=f"{len(cfg.enclaves)} Enclave(s)")
    table.add_column("Stack Name", style="cyan")
    table.add_column("Labels", style="dim")
    table.add_column("EIP", style="dim")
    table.add_column("Instance", style="dim")
    table.add_column("Region", style="dim")

    for e in cfg.enclaves:
        labels_str = ", ".join(e.labels) if e.labels else "-"
        try:
            instance_id = resolve_active_instance(e.host_ref, e.region)
        except Exception:
            instance_id = "-"
        table.add_row(e.stack_name, labels_str, e.eip, instance_id, e.region)

    console.print()
    console.print(table)


@enclave.command(hidden=True)
@click.argument("stack_name")
@click.pass_context
def describe(ctx: click.Context, stack_name: str) -> None:
    """Describe an enclave."""
    cfg: Config = ctx.obj["config"]
    console = Console()

    if not cfg.enclaves:
        console.print("No enclaves deployed. Run [cyan]gm-shield enclave deploy[/cyan] first.")
        return

    curr = next((e for e in cfg.enclaves if e.stack_name == stack_name), None)
    if not curr:
        console.print(f"Enclave [cyan]{stack_name}[/cyan] not found.")
        return

    stack_status = "-"
    try:
        cfn = boto3.client("cloudformation", region_name=curr.region)
        resp = cfn.describe_stacks(StackName=curr.stack_name)
        stack_status = resp["Stacks"][0].get("StackStatus", "-")
    except Exception:
        pass

    instance_id = "-"
    instance_state = "-"
    try:
        instance_id = resolve_active_instance(curr.host_ref, curr.region)
        ec2 = boto3.client("ec2", region_name=curr.region)
        ec2_resp = ec2.describe_instances(InstanceIds=[instance_id])
        reservations = ec2_resp.get("Reservations", [])
        if reservations:
            instance_state = reservations[0]["Instances"][0].get("State", {}).get("Name", "-")
    except Exception:
        pass

    status_style = _get_status_style(stack_status)
    instance_style = (
        "green"
        if instance_state == "running"
        else ("yellow" if instance_state in ("pending", "stopping") else "red")
    )

    console.print()

    console.print(
        f"[bold]{curr.stack_name}[/bold]"
        f"   [{status_style}]{stack_status.replace('_', ' ').title()}[/{status_style}]"
    )
    console.print(f"[dim]Stack ID:[/dim]  {curr.stack_id or '-'}")
    console.print(f"[dim]Region:[/dim]    {curr.region}")
    console.print()

    console.print("[bold]Network[/bold]")
    console.print(f"  [dim]Elastic IP[/dim]   {curr.eip}")
    console.print(f"  [dim]Host Ref[/dim]     {curr.host_ref}")
    console.print(
        f"  [dim]Instance[/dim]     {instance_id}"
        + (
            f"   [{instance_style}]{instance_state}[/{instance_style}]"
            if instance_id != "-"
            else ""
        )
    )
    console.print()

    console.print("[bold]IAM[/bold]")
    console.print(f"  [dim]Role ARN[/dim]          {curr.role_arn}")
    console.print(f"  [dim]Instance Profile[/dim]  {curr.instance_profile_arn}")
    console.print()

    # Labels
    if curr.labels:
        console.print(f"[dim]Labels:[/dim]  {', '.join(curr.labels)}")


@enclave.command(hidden=True)
@click.option(
    "--instance-type",
    default="m5.xlarge",
    show_default=True,
    help="EC2 instance type (must support Nitro Enclaves)",
)
@click.option("--memory", default=6144, show_default=True, help="Enclave memory in MiB")
@click.option("--cpu", default=2, show_default=True, help="vCPUs allocated to the enclave")
@click.option("--volume-size", default=30, show_default=True, help="EBS volume size in GiB")
@click.option("--vpc-id", default=None, help="VPC ID for the enclave host")
@click.option(
    "--subnet-ids",
    default=None,
    help="Comma-separated subnet IDs for ASG placement (defaults to detected public subnets)",
)
@click.option("--region", default=None, help="AWS region (defaults to AWS_REGION env var)")
@click.option(
    "--credentials-region",
    default=None,
    help="Region of the credentials bucket and KMS key (defaults to enclave region)",
)
@click.pass_context
def deploy(
    ctx: click.Context,
    instance_type: str,
    memory: int,
    cpu: int,
    volume_size: int,
    vpc_id: str | None,
    subnet_ids: str | None,
    region: str | None,
    credentials_region: str | None,
) -> None:
    """Deploy Nitro Enclave infrastructure."""
    cfg: Config = ctx.obj["config"]
    console = Console()

    if cfg.enclaves:
        console.print("[bold]Existing enclaves:[/bold]")
        for i, e in enumerate(cfg.enclaves, 1):
            labels_str = ", ".join(e.labels) if e.labels else "no labels"
            console.print(f"  {i}. [cyan]{e.stack_name}[/cyan] ({labels_str})")
        console.print()

    console.print()
    console.print("[bold]GlassMarkets Enclave Deploy[/bold]")
    console.print("=" * 40)
    console.print()
    console.print("[dim]Press Enter to accept recommended values.[/dim]")
    console.print()

    if region is None:
        region_input = questionary.text(
            "Region:",
            default=get_default_region(ENCLAVE_DEFAULT_REGION),
        ).ask()
        if region_input is None:
            _prompt_cancelled()
        region = region_input.strip()

    if credentials_region is None:
        credentials_region_input = questionary.text(
            "Credentials region:",
            default=cfg.region or "",
            validate=_validate_uri,
        ).ask()
        if credentials_region_input is None:
            _prompt_cancelled()
        credentials_region = credentials_region_input.strip()

    instance_type_input = questionary.select(
        "Instance type:",
        choices=_ALLOWED_INSTANCE_TYPES,
        default=instance_type
        if instance_type in _ALLOWED_INSTANCE_TYPES
        else _ALLOWED_INSTANCE_TYPES[0],  # noqa: E501
    ).ask()
    if instance_type_input is None:
        _prompt_cancelled()
    instance_type = instance_type_input

    memory_input = questionary.text(
        f"Memory (MiB) [min {_MIN_MEMORY_MIB}]:",
        default=str(memory),
        validate=_validate_memory_mib,
    ).ask()
    if memory_input is None:
        _prompt_cancelled()
    memory = int(memory_input.strip())

    cpu_input = questionary.text(
        f"vCPUs [min {_MIN_CPU_COUNT}]:",
        default=str(cpu),
        validate=_validate_cpu_count,
    ).ask()
    if cpu_input is None:
        _prompt_cancelled()
    cpu = int(cpu_input.strip())

    volume_input = questionary.text(
        f"Volume size (GiB) [min {_MIN_VOLUME_GIB}]:",
        default=str(volume_size),
        validate=_validate_volume_gib,
    ).ask()
    if volume_input is None:
        _prompt_cancelled()
    volume_size = int(volume_input.strip())

    selected_vpc_id = vpc_id.strip() if vpc_id else None
    if vpc_id is None:
        vpc_input = questionary.text(
            "VPC ID (optional, Enter for default VPC in region):",
            default="",
        ).ask()
        if vpc_input is None:
            _prompt_cancelled()
        selected_vpc_id = vpc_input.strip() or None

    selected_subnet_ids = _parse_subnet_ids(subnet_ids)
    if subnet_ids is None:
        subnet_input = questionary.text(
            "Subnet IDs (optional, comma-separated, Enter for auto selection):",
            default="",
        ).ask()
        if subnet_input is None:
            _prompt_cancelled()
        selected_subnet_ids = _parse_subnet_ids(subnet_input)

    try:
        resolved_vpc_id, resolved_subnet_ids = resolve_enclave_network(
            region=region,  # pyright: ignore[reportArgumentType]
            vpc_id=selected_vpc_id,
            subnet_ids=selected_subnet_ids,
        )
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise SystemExit(1)

    labels_input = questionary.text(
        "Labels (comma-separated, e.g., mm1, production):",
        default="",
    ).ask()
    if labels_input is None:
        _prompt_cancelled()
    labels = [lbl.strip() for lbl in labels_input.split(",") if lbl.strip()]

    console.print()
    console.print(f"  Instance type:  [cyan]{instance_type}[/cyan]")
    console.print(f"  Memory:         [cyan]{memory} MiB[/cyan]")
    console.print(f"  vCPUs:          [cyan]{cpu}[/cyan]")
    console.print(f"  Volume size:    [cyan]{volume_size} GiB[/cyan]")
    console.print(f"  Region:         [cyan]{region}[/cyan]")
    console.print(f"  Creds region:   [cyan]{credentials_region}[/cyan]")
    console.print(f"  VPC:            [cyan]{resolved_vpc_id}[/cyan]")
    console.print(f"  Subnets:        [cyan]{', '.join(resolved_subnet_ids)}[/cyan]")
    if labels:
        console.print(f"  Labels:         [cyan]{', '.join(labels)}[/cyan]")
    console.print()

    confirm = questionary.confirm("Deploy enclave?", default=True).ask()
    if not confirm:
        _prompt_cancelled()

    console.print()

    try:
        stack_name, region, cfn = start_enclave_stack_creation(
            instance_type=instance_type,
            memory_mib=memory,
            cpu_count=cpu,
            volume_size=volume_size,
            credentials_region=credentials_region,  # pyright: ignore[reportArgumentType]
            vpc_id=resolved_vpc_id,
            subnet_ids=resolved_subnet_ids,
            region=region,
        )
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise SystemExit(1)

    stack_id: str = ""
    try:
        response = cfn.describe_stacks(StackName=stack_name)
        stack_id = response["Stacks"][0].get("StackId", "")
    except Exception:
        pass

    if stack_id and region:
        console_url = get_stack_console_url(stack_id, region)
        console.print("[dim]Monitor in AWS Console:[/dim]")
        console.print(f"[link={console_url}]{console_url}[/link]")
        console.print()

    final_progress: StackProgress | None = None

    with Live(console=console, refresh_per_second=10) as live:
        for progress in poll_stack_progress(stack_name, cfn):
            live.update(_build_progress_display(progress))
            final_progress = progress
            if progress.is_complete or progress.is_failed:
                break

    if final_progress is None or final_progress.is_failed:
        console.print()
        reason = final_progress.failure_reason if final_progress else "Unknown error"
        console.print(f"[red]Error: {reason}[/red]")
        raise SystemExit(1)

    result = get_enclave_stack_outputs(stack_name, region)  # pyright: ignore[reportArgumentType]

    cfg.enclaves.append(
        EnclaveConfig(
            stack_name=result.stack_name,
            stack_id=result.stack_id,
            region=result.region,
            role_arn=result.role_arn,
            instance_profile_arn=result.instance_profile_arn,
            host_ref=result.host_ref,
            labels=labels,
            eip=result.eip,
        )
    )
    cfg.save()

    console.print()
    console.print("[green bold]Enclave deployed![/green bold]")
    console.print()
    console.print(f"  Role ARN:         [cyan]{result.role_arn}[/cyan]")
    console.print(f"  Instance Profile: [cyan]{result.instance_profile_arn}[/cyan]")
    console.print(f"  Host Ref:         [cyan]{result.host_ref}[/cyan]")
    console.print()
    console.print("Share the Role ARN with the market maker so they can run:")
    console.print(
        f"  [dim]gm-shield enclave approve --role-arn {result.role_arn} --pcr8 <value>[/dim]"
    )


@enclave.command()
@click.option("--role-arn", default=None, help="IAM role ARN of the enclave instance")
@click.option("--pcr8", default=None, help="PCR8 value of the enclave signing certificate")
@click.option(
    "--pcr0", default=None, help="PCR0 value of the EIF image (optional, stricter attestation)"
)
@click.pass_context
def approve(ctx: click.Context, role_arn: str | None, pcr8: str | None, pcr0: str | None) -> None:
    """Grant a Nitro Enclave access to credentials.

    Adds KMS and S3 policy statements scoped to the enclave's IAM role
    and PCR8 value. Optionally also enforces PCR0 (EIF image hash) for stricter attestation.
    """
    cfg: Config = ctx.obj["config"]
    console = Console()

    if not cfg.stack_name:
        console.print("Not configured. Run [cyan]gm-shield setup[/cyan] first.")
        raise SystemExit(1)

    if cfg.approved_enclave:
        console.print("[red]An enclave is already approved.[/red]")
        console.print(f"  Role ARN: {cfg.approved_enclave.role_arn}")
        console.print(f"  PCR8:     {cfg.approved_enclave.pcr8}")
        console.print()
        console.print("Run [cyan]gm-shield enclave revoke[/cyan] first.")
        raise SystemExit(1)

    if role_arn is None:
        role_arn = questionary.text("Role ARN:", validate=_validate_required).ask()
        if role_arn is None:
            _prompt_cancelled()

    pcr8, pcr0 = _prompt_pcr_values(pcr8, pcr0)

    console.print()

    region = cfg.region or "us-east-1"
    bucket = cfg.bucket or ""
    kms_key_arn = cfg.kms_key_arn or ""

    console.print("[bold]Approving enclave access[/bold]")
    console.print(f"  Role ARN: [cyan]{role_arn}[/cyan]")
    console.print(f"  PCR8:     [cyan]{pcr8}[/cyan]")
    if pcr0:
        console.print(f"  PCR0:     [cyan]{pcr0}[/cyan]")
    console.print()

    confirm = questionary.confirm("Approve this enclave?", default=True).ask()
    if not confirm:
        _prompt_cancelled()

    console.print()

    _put_enclave_policies(role_arn, pcr8, pcr0, kms_key_arn, bucket, region, console)

    cfg.approved_enclave = ApprovedEnclave(
        role_arn=role_arn,
        pcr8=pcr8,
        pcr0=pcr0,
        approved_at=datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    )
    cfg.save()

    console.print()
    console.print("[green bold]Approved.[/green bold]")


@enclave.command()
@click.pass_context
def revoke(ctx: click.Context) -> None:
    """Revoke enclave access to credentials.

    Removes the KMS and S3 policy statements added by approve.
    """
    cfg: Config = ctx.obj["config"]
    console = Console()

    if not cfg.stack_name:
        console.print("Not configured.")
        raise SystemExit(1)

    if not cfg.approved_enclave:
        console.print("No approved enclave.")
        console.print("Run [cyan]gm-shield enclave approve[/cyan] first.")
        raise SystemExit(1)

    region = cfg.region or "us-east-1"
    bucket = cfg.bucket or ""
    kms_key_arn = cfg.kms_key_arn or ""
    role_arn = cfg.approved_enclave.role_arn

    console.print("[bold]Revoking enclave access[/bold]")
    console.print(f"  Role ARN: [cyan]{role_arn}[/cyan]")
    console.print(f"  PCR8:     [cyan]{cfg.approved_enclave.pcr8}[/cyan]")
    console.print()

    confirm = questionary.confirm("Revoke access for this enclave?", default=False).ask()
    if not confirm:
        _prompt_cancelled()

    console.print()
    _revoke_enclave_access(kms_key_arn, bucket, region, console)

    cfg.delete_approved_enclave(role_arn)
    cfg.save()

    console.print()
    console.print("[green bold]Revoked.[/green bold] Enclave no longer has access.")


@enclave.command()
@click.option("--pcr0", default=None, help="New PCR0 value of the EIF image")
@click.pass_context
def rotate(ctx: click.Context, pcr0: str | None) -> None:
    """
    Rotate the PCR0 attestation value for the approved enclave.
    """
    cfg: Config = ctx.obj["config"]
    console = Console()

    if not cfg.stack_name:
        console.print("Not configured. Run [cyan]gm-shield setup[/cyan] first.")
        raise SystemExit(1)

    if not cfg.approved_enclave:
        console.print("No approved enclave.")
        console.print("Run [cyan]gm-shield enclave approve[/cyan] first.")
        raise SystemExit(1)

    role_arn = cfg.approved_enclave.role_arn
    pcr8 = cfg.approved_enclave.pcr8

    console.print("[bold]Current approval[/bold]")
    console.print(f"  Role ARN: [cyan]{role_arn}[/cyan]")
    console.print(f"  PCR8:     [dim]{pcr8}[/dim]")
    if cfg.approved_enclave.pcr0:
        console.print(f"  PCR0:     [dim]{cfg.approved_enclave.pcr0}[/dim]")
    console.print()

    if pcr0 is None:
        raw = questionary.text(
            "New PCR0:",
            validate=_validate_pcr,
        ).ask()
        if raw is None:
            _prompt_cancelled()
        pcr0 = raw.strip()

    console.print()
    console.print("[bold]New attestation[/bold]")
    console.print(f"  PCR8: [dim]{pcr8}[/dim]  (unchanged)")
    console.print(f"  PCR0: [cyan]{pcr0}[/cyan]")
    console.print()

    confirm = questionary.confirm("Rotate attestation values?", default=True).ask()
    if not confirm:
        _prompt_cancelled()

    console.print()

    region = cfg.region or "us-east-1"
    bucket = cfg.bucket or ""
    kms_key_arn = cfg.kms_key_arn or ""

    _put_enclave_policies(role_arn, pcr8, pcr0, kms_key_arn, bucket, region, console)

    cfg.approved_enclave = ApprovedEnclave(
        role_arn=role_arn,
        pcr8=pcr8,
        pcr0=pcr0,
        approved_at=datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    )
    cfg.save()

    console.print()
    console.print("[green bold]Rotated.[/green bold]")


def _build_deletion_display(progress: StackProgress) -> RenderableType:
    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("", width=2)
    table.add_column("Resource", style="cyan", min_width=25)
    table.add_column("Type", style="dim")
    table.add_column("Status")

    def sort_key(item: tuple[str, ResourceStatus]) -> tuple[int, str]:
        _, r = item
        if "IN_PROGRESS" in r.status:
            return 0, r.logical_id
        elif "COMPLETE" in r.status or "SKIPPED" in r.status:
            return 2, r.logical_id
        return 1, r.logical_id

    for _, resource in sorted(progress.resources.items(), key=sort_key):
        icon = _get_status_icon(resource.status)
        style = _get_status_style(resource.status)
        friendly_type = get_friendly_type(resource.resource_type)
        status_text = resource.status.replace("_", " ").title()
        table.add_row(icon, resource.logical_id, friendly_type, f"[{style}]{status_text}[/{style}]")

    if not progress.is_complete and not progress.is_failed:
        spinner = Spinner("dots", text=Text(" Deleting enclave infrastructure...", style="bold"))
        return Group(spinner, Text(""), table)

    return table


@enclave.command(hidden=True)
@click.argument("stack_name")
@click.pass_context
def teardown(ctx: click.Context, stack_name: str) -> None:
    """Delete enclave infrastructure and revoke access.

    Deletes the enclave CloudFormation stack. If an enclave is approved, policies
    are revoked first.
    """
    cfg: Config = ctx.obj["config"]
    console = Console()

    if not cfg.enclaves:
        console.print("No enclave deployed. Run [cyan]gm-shield enclave deploy[/cyan] first.")
        return

    selected_enclave = next((e for e in cfg.enclaves if e.stack_name == stack_name), None)
    if selected_enclave is None:
        console.print(f"[red]Error: No enclave found with stack name '{stack_name}'[/red]")
        raise SystemExit(1)

    region = selected_enclave.region
    stack_name = selected_enclave.stack_name
    stack_id = selected_enclave.stack_id
    role_arn = selected_enclave.role_arn
    labels = ", ".join(selected_enclave.labels) if selected_enclave.labels else "-"

    try:
        instance_id = resolve_active_instance(selected_enclave.host_ref, region)
    except Exception:
        instance_id = selected_enclave.host_ref

    manual_cmd = f"aws cloudformation delete-stack --stack-name {stack_name} --region {region}"

    warning = Panel(
        "[bold red]WARNING: This action cannot be undone![/bold red]\n\n"
        "[bold]Resources that will be DELETED:[/bold]\n"
        f"Enclave Instance:    [cyan]{instance_id}[/cyan]\n"
        f"IAM Role:            [cyan]{role_arn}[/cyan]\n"
        f"Stack:               [cyan]{stack_name}[/cyan]\n"
        f"Region:              [cyan]{region}[/cyan]\n"
        f"Labels:              [cyan]{labels}[/cyan]\n\n"
        f"[dim]Manual command: {manual_cmd}[/dim]",
        title="[bold red]Teardown Enclave[/bold red]",
        border_style="red",
    )
    console.print(warning)
    console.print()

    console_url = get_stack_console_url(stack_id, region) if stack_id else ""

    console.print(f"To confirm, type the stack name: [bold]{stack_name}[/bold]")
    confirmation = click.prompt("", default="", show_default=False)

    if confirmation != stack_name:
        console.print("[yellow]Aborted.[/yellow] Stack name did not match.")
        raise SystemExit(1)

    console.print()

    if console_url:
        console.print("[dim]Monitor progress in AWS Console:[/dim]")
        console.print(f"[link={console_url}]{console_url}[/link]")
        console.print()
        console.print(
            "[dim]You can safely cancel this command (Ctrl+C) - deletion will continue in AWS.[/dim]"
        )
        console.print()

    try:
        cfn = start_stack_deletion(stack_name, region)
    except Exception as e:
        console.print(f"[red]Error starting deletion: {e}[/red]")
        raise SystemExit(1)

    final_progress: StackProgress | None = None

    try:
        with Live(console=console, refresh_per_second=10) as live:
            for progress in poll_stack_deletion(stack_name, cfn):
                live.update(_build_deletion_display(progress))
                final_progress = progress
                if progress.is_complete or progress.is_failed:
                    break
    except KeyboardInterrupt:
        console.print()
        console.print("[yellow]Interrupted.[/yellow] Deletion continues in AWS.")
        if console_url:
            console.print(f"[dim]Monitor progress:[/dim] {console_url}")
        raise SystemExit(0)

    if final_progress is None or final_progress.is_failed:
        console.print()
        reason = final_progress.failure_reason if final_progress else "Unknown error"
        console.print(f"[red]Error: {reason}[/red]")
        if console_url:
            console.print(f"[dim]Check AWS Console:[/dim] {console_url}")
        raise SystemExit(1)

    cfg.delete_enclave(selected_enclave.stack_id)
    cfg.save()

    # Clean up SSM runtime parameters for this stack
    try:
        delete_stack_params(stack_name, region)
    except Exception as e:
        console.print(f"[yellow]Warning: could not delete SSM parameters: {e}[/yellow]")

    console.print()
    console.print("[green bold]Enclave teardown complete.[/green bold]")
    console.print()


# ── run ───────────────────────────────────────────────────────────────────────

_PARAM_LABELS: dict[str, str] = {
    "image_name": "Image Name (IMAGE_NAME)",
    "eif_s3_uri": "EIF S3 URI",
    "org_name": "Org Name (ENCLAVE_GM_ORG)",
    "bucket_name": "Bucket Name (BUCKET_NAME)",
    "bucket_region": "Bucket Region (BUCKET_REGION)",
    "root_url": "Root URL (ROOT_URL)",
    "log_stream_name": "Log Stream Name",
    "log_region": "Log Region",
    "gm_user": "GM User (ENCLAVE_GM_USER)",
    "gm_password": "GM Password (ENCLAVE_GM_PASSWORD)",
    "deployed_at": "Deployed At",
    "deployed_by": "Deployed By",
}

# Keys shown in status view, in display order
_STATUS_KEYS = (
    [k for k in ALL_RUNTIME_PARAMS if k not in METADATA_PARAMS]
    + list(REQUIRED_CREDS)
    + list(METADATA_PARAMS)
)

# Maps each required SSM key to its CLI flag for preflight hint output
_FLAG_FOR_KEY: dict[str, str] = {
    "eif_s3_uri": "--eif-s3-uri",
    "image_name": "--image-name",
    "org_name": "--org-name",
    "bucket_name": "--bucket-name",
    "bucket_region": "--bucket-region",
    "root_url": "--root-url",
    "gm_user": "--gm-user",
    "gm_password": "--gm-password",
}


def _build_params_table(
    current: dict[str, str | None],
    updates: dict[str, str],
    *,
    status_mode: bool = False,
    verbose: bool = False,
) -> Table:
    """Build a Rich table showing the current SSM state or an update diff.

    In status_mode: show all params with their current values.
    In diff mode: show only params that will be changed (or all if status_mode).
    """
    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("Parameter", style="cyan", min_width=30)
    if status_mode:
        table.add_column("Value")
    else:
        table.add_column("Current")
        table.add_column("New")

    if status_mode:
        keys_to_show = (
            list(_STATUS_KEYS) if verbose else [k for k in _STATUS_KEYS if k not in METADATA_PARAMS]
        )
    else:
        keys_to_show = list(updates)

    for key in keys_to_show:
        label = _PARAM_LABELS.get(key, key)
        cur = current.get(key)
        cur_display = f"[dim]{cur}[/dim]" if cur else "[red]not set[/red]"

        if status_mode:
            table.add_row(label, cur_display)
        else:
            new_val = updates[key]
            is_secret = key in REQUIRED_CREDS
            new_display = "[green]***[/green]" if is_secret else f"[green]{new_val}[/green]"
            if cur is None:
                cur_display = "[red]not set[/red]"
                table.add_row(label, cur_display, new_display)
            elif (is_secret and cur == "***") or cur == new_val:
                table.add_row(
                    label,
                    f"[dim]{cur}[/dim]",
                    f"[dim]{new_val if not is_secret else '***'}[/dim] [dim](unchanged)[/dim]",
                )
            else:
                table.add_row(label, f"[dim]{cur}[/dim]", new_display)

    return table


_HEALTHY_STATES: dict[str, set[str]] = {
    "service": {"active"},
    "container": {"running"},
    "enclave": {"running"},
}
_TRANSITIONAL_STATES: dict[str, set[str]] = {
    "service": {"activating", "deactivating", "reloading"},
    "container": {"created", "restarting"},
    "enclave": set(),
}


def _probe_style(probe: str, status: str) -> str:
    if status.startswith("error"):
        return "red"
    if status in _HEALTHY_STATES.get(probe, set()):
        return "green"
    if status in _TRANSITIONAL_STATES.get(probe, set()):
        return "yellow"
    return "red"


def _build_status_display(probes: list[tuple[str, str]]) -> Table:
    table = Table(show_header=False, box=None)
    table.add_column("", width=2)
    table.add_column("", style="cyan", min_width=10)
    table.add_column("")
    for name, status in probes:
        style = _probe_style(name, status)
        icon = "●" if style == "yellow" else ("✓" if style == "green" else "✗")
        table.add_row(
            f"[{style}]{icon}[/{style}]",
            name,
            f"[{style}]{status}[/{style}]",
        )
    return table


@enclave.command(hidden=True)
@click.argument("stack_name")
@click.option("--image-name", default=None, help="ECR image URI for host container (IMAGE_NAME)")
@click.option("--eif-s3-uri", default=None, help="S3 URI of signed EIF (eif_s3_uri)")
@click.option("--org-name", default=None, help="Org name (ENCLAVE_GM_ORG)")
@click.option("--bucket-name", default=None, help="Credentials S3 bucket (BUCKET_NAME)")
@click.option("--bucket-region", default=None, help="Credentials bucket region (BUCKET_REGION)")
@click.option("--root-url", default=None, help="Glass backend URL (ROOT_URL)")
@click.option("--log-stream-name", default=None, help="CloudWatch log stream name")
@click.option("--log-region", default=None, help="CloudWatch log region (LOG_REGION)")
@click.option(
    "--gm-user", default=None, envvar="ENCLAVE_GM_USER", help="GM user credential (ENCLAVE_GM_USER)"
)
@click.option(
    "--gm-password",
    default=None,
    envvar="ENCLAVE_GM_PASSWORD",
    hide_input=True,
    help="GM password credential (ENCLAVE_GM_PASSWORD)",
)
@click.option(
    "--dry-run", is_flag=True, default=False, help="Show changes without writing or restarting"
)
@click.option(
    "--no-restart", is_flag=True, default=False, help="Write SSM params only; skip restart"
)
@click.option(
    "--restart",
    "do_restart",
    is_flag=True,
    default=False,
    help="Restart the service without changing params",
)
@click.option(
    "--verbose", is_flag=True, default=False, help="Show metadata params (deployed_at, deployed_by)"
)
@click.option(
    "--wait-timeout", default=300, show_default=True, help="Restart wait timeout in seconds"
)
@click.option(
    "--health",
    "do_health",
    is_flag=True,
    default=False,
    help="Also run health probes after params display",
)
@click.option(
    "--logs",
    "do_logs",
    is_flag=True,
    default=False,
    help="Also show recent log lines after params display",
)
@click.option(
    "--force-unlock",
    "do_force_unlock",
    is_flag=True,
    default=False,
    help="Clear stuck lock before proceeding",
)
@click.pass_context
def run(  # noqa: PLR0912, PLR0915
    ctx: click.Context,
    stack_name: str,
    image_name: str | None,
    eif_s3_uri: str | None,
    org_name: str | None,
    bucket_name: str | None,
    bucket_region: str | None,
    root_url: str | None,
    log_stream_name: str | None,
    log_region: str | None,
    gm_user: str | None,
    gm_password: str | None,
    dry_run: bool,
    no_restart: bool,
    do_restart: bool,
    verbose: bool,
    wait_timeout: int,
    do_health: bool,
    do_logs: bool,
    do_force_unlock: bool,
) -> None:
    """Deploy or update the shield-worker runtime on an enclave host.

    Writes environment variables to SSM Parameter Store and rolls out the
    shield-worker service via SSM RunCommand.

    With no update flags: shows current SSM state.
    Use --restart to restart the service without changing params.
    """
    cfg: Config = ctx.obj["config"]
    console = Console()

    if not cfg.enclaves:
        console.print("No enclave deployed. Run [cyan]gm-shield enclave deploy[/cyan] first.")
        raise SystemExit(1)

    selected = next((e for e in cfg.enclaves if e.stack_name == stack_name), None)
    if selected is None:
        console.print(f"[red]Error: no enclave with stack name '{stack_name}'[/red]")
        raise SystemExit(1)

    enc_stack_name = selected.stack_name
    enc_region = selected.region
    enc_host_ref = selected.host_ref
    enc_eip = selected.eip

    has_any_updates = bool(
        image_name
        or eif_s3_uri
        or org_name
        or bucket_name
        or bucket_region
        or root_url
        or log_stream_name
        or log_region
        or gm_user
        or gm_password
    )
    needs_lock = (has_any_updates or do_restart) and not dry_run

    if needs_lock:
        if do_force_unlock:
            force_unlock(enc_stack_name, enc_region)
            console.print("[yellow]Lock cleared.[/yellow]")
        caller = _get_caller_identity()
        if not acquire_lock(enc_stack_name, enc_region, caller):
            holder = get_lock_holder(enc_stack_name, enc_region)
            if holder:
                identity, iso_ts, pid = holder
                console.print(f"[red]Locked by:[/red] {identity}  (pid {pid}, since {iso_ts})")
                console.print("[dim]Use --force-unlock to clear.[/dim]")
            else:
                console.print("[red]Could not acquire lock (race condition — retry).[/red]")
            raise SystemExit(1)
    elif do_force_unlock:
        force_unlock(enc_stack_name, enc_region)
        console.print("[yellow]Lock cleared.[/yellow]")

    try:
        _run_inner(
            console=console,
            enc_stack_name=enc_stack_name,
            enc_region=enc_region,
            enc_host_ref=enc_host_ref,
            enc_eip=enc_eip,
            image_name=image_name,
            eif_s3_uri=eif_s3_uri,
            org_name=org_name,
            bucket_name=bucket_name,
            bucket_region=bucket_region,
            root_url=root_url,
            log_stream_name=log_stream_name,
            log_region=log_region,
            gm_user=gm_user,
            gm_password=gm_password,
            dry_run=dry_run,
            no_restart=no_restart,
            do_restart=do_restart,
            verbose=verbose,
            wait_timeout=wait_timeout,
            do_health=do_health,
            do_logs=do_logs,
        )
    finally:
        if needs_lock:
            release_lock(enc_stack_name, enc_region)


def _get_caller_identity() -> str:
    """Return a short caller identity string for the lock."""
    try:
        sts = boto3.client("sts")
        response = sts.get_caller_identity()
        arn: str = response.get("Arn", "unknown")
        # Shorten: keep last two segments
        parts = arn.split(":")
        return ":".join(parts[-2:]) if len(parts) >= 2 else arn
    except Exception:
        return "unknown"


def _run_inner(
    *,
    console: Console,
    enc_stack_name: str,
    enc_region: str,
    enc_host_ref: str,
    enc_eip: str,
    image_name: str | None,
    eif_s3_uri: str | None,
    org_name: str | None,
    bucket_name: str | None,
    bucket_region: str | None,
    root_url: str | None,
    log_stream_name: str | None,
    log_region: str | None,
    gm_user: str | None,
    gm_password: str | None,
    dry_run: bool,
    no_restart: bool,
    do_restart: bool,
    verbose: bool,
    wait_timeout: int,
    do_health: bool = False,
    do_logs: bool = False,
) -> None:
    console.print(
        f"[dim]Stack:[/dim] [cyan]{enc_stack_name}[/cyan]  [dim]EIP:[/dim] [cyan]{enc_eip}[/cyan]"
    )
    console.print()

    current = get_runtime_params(enc_stack_name, enc_region)

    runtime_updates: dict[str, str] = {}
    if image_name is not None:
        runtime_updates["image_name"] = image_name
    if eif_s3_uri is not None:
        runtime_updates["eif_s3_uri"] = eif_s3_uri
    if org_name is not None:
        runtime_updates["org_name"] = org_name
    if bucket_name is not None:
        runtime_updates["bucket_name"] = bucket_name
    if bucket_region is not None:
        runtime_updates["bucket_region"] = bucket_region
    if root_url is not None:
        runtime_updates["root_url"] = root_url
    if log_stream_name is not None:
        runtime_updates["log_stream_name"] = log_stream_name
    if log_region is not None:
        runtime_updates["log_region"] = log_region

    has_any_updates = bool(runtime_updates) or gm_user is not None or gm_password is not None

    if not has_any_updates:
        console.print("[bold]Parameters[/bold]")
        console.print(_build_params_table(current, {}, status_mode=True, verbose=verbose))
        console.print()

        # Preflight — informational only in status mode; never exits here
        missing = validate_preflight(enc_stack_name, enc_region)
        if missing:
            console.print("[bold]Preflight[/bold]")
            for m in missing:
                key = m.split("/", 1)[-1]
                flag = _FLAG_FOR_KEY.get(key, f"--{key.replace('_', '-')}")
                console.print(f"  [red]•[/red] [dim]{m}[/dim]  →  [cyan]{flag} <value>[/cyan]")
            console.print()
        else:
            console.print("[dim]Preflight:[/dim] [green]✓ all required params set[/green]")
            console.print()

        if do_health:
            console.print("[bold]Health[/bold]")
            try:
                instance_id = resolve_active_instance(enc_host_ref, enc_region)
                console.print(f"  Instance: [cyan]{instance_id}[/cyan]")
                _run_snapshot_probes_live(console, instance_id, enc_region)
            except Exception as e:
                console.print(f"  [red]Could not run health probes: {e}[/red]")
            console.print()

        if do_logs:
            console.print("[bold]Logs[/bold]")
            with Live(console=console, refresh_per_second=4) as live:
                live.update(Spinner("dots", text=Text(" Fetching logs...", style="bold")))
                lines = fetch_log_tail(enc_stack_name, enc_region, n=20)
            if lines:
                for line in lines:
                    console.print(f"  [dim]{line.rstrip()}[/dim]")
            else:
                console.print("  [dim]No log lines found.[/dim]")
            console.print()

        if do_restart:
            if dry_run:
                console.print("[dim]Dry run — restart skipped.[/dim]")
                return
            if missing:
                console.print(
                    "[red]Cannot restart — required SSM params not set (see above).[/red]"
                )
                raise SystemExit(1)
            confirmed = questionary.confirm("Restart service?", default=False).ask()
            if confirmed is None:
                _prompt_cancelled()
            if not confirmed:
                return
            _do_restart(
                console=console,
                enc_region=enc_region,
                enc_host_ref=enc_host_ref,
                wait_timeout=wait_timeout,
            )
            return

        # Status hint
        if missing:
            key = missing[0].split("/", 1)[-1]
            flag = _FLAG_FOR_KEY.get(key, "--<flag>")
            console.print(
                f"[dim]Configure with [cyan]{flag} <value>[/cyan]"
                f" then restart with [cyan]--restart[/cyan].[/dim]"
            )
        else:
            console.print("[dim]Run with [cyan]--restart[/cyan] to restart the service.[/dim]")
        return

    console.print("[bold]Changes to apply[/bold]")
    all_updates = dict(runtime_updates)
    if gm_user is not None:
        all_updates["gm_user"] = "***"
    if gm_password is not None:
        all_updates["gm_password"] = "***"
    console.print(_build_params_table(current, all_updates))
    console.print()

    if dry_run:
        console.print("[dim]Dry run — no changes written.[/dim]")
        return

    confirm = questionary.confirm("Apply changes?", default=True).ask()
    if not confirm:
        _prompt_cancelled()

    console.print()
    console.print("Writing SSM parameters...", end=" ")
    try:
        for key, value in runtime_updates.items():
            upsert_param(enc_stack_name, key, value, enc_region)
        if gm_user is not None:
            upsert_param(enc_stack_name, "gm_user", gm_user, enc_region, secret=True)
        if gm_password is not None:
            upsert_param(enc_stack_name, "gm_password", gm_password, enc_region, secret=True)
        # Write deployment metadata
        upsert_param(enc_stack_name, "deployed_at", datetime.now(UTC).isoformat(), enc_region)
        upsert_param(enc_stack_name, "deployed_by", _get_caller_identity(), enc_region)
        console.print("[green]✓[/green]")
    except Exception as e:
        console.print(f"[red]✗[/red]\n[red]Error writing SSM: {e}[/red]")
        raise SystemExit(1)

    missing = validate_preflight(enc_stack_name, enc_region)
    if missing:
        console.print()
        console.print("[red]Pre-flight failed. Required SSM params not set:[/red]")
        for m in missing:
            key = m.split("/", 1)[-1]
            flag = _FLAG_FOR_KEY.get(key, f"--{key.replace('_', '-')}")
            console.print(f"  [red]•[/red] [dim]{m}[/dim]  →  [cyan]{flag} <value>[/cyan]")
        raise SystemExit(1)

    if no_restart:
        console.print()
        console.print("[green]SSM updated.[/green] Restart skipped [dim](--no-restart)[/dim].")
        return

    _do_restart(
        console=console,
        enc_region=enc_region,
        enc_host_ref=enc_host_ref,
        wait_timeout=wait_timeout,
    )


def _run_snapshot_probes_live(
    console: Console,
    instance_id: str,
    region: str,
) -> list[tuple[str, str]]:
    """Run status probes and display current state of each (no polling for success)."""
    probes: list[tuple[str, str]] = []
    with Live(console=console, refresh_per_second=4) as live:
        for probe_name, command in STATUS_PROBES:
            live.update(
                Group(
                    Spinner("dots", text=Text(f" {probe_name}...", style="bold")),
                    _build_status_display(probes),
                )
            )
            try:
                cid = send_shell_command(instance_id, region, [command])
                _, output = poll_command(cid, instance_id, region, timeout=30)
                status = output.strip() or "unknown"
            except Exception as e:
                status = f"error: {str(e)[:60]}"
            probes.append((probe_name, status))
            live.update(_build_status_display(probes))
    return probes


def _do_restart(
    *,
    console: Console,
    enc_region: str,
    enc_host_ref: str,
    wait_timeout: int,
) -> None:
    """Resolve instance, send restart, poll, run health probes."""
    console.print()
    console.print("Resolving instance...", end=" ")
    try:
        instance_id = resolve_active_instance(enc_host_ref, enc_region)
        console.print(f"[green]✓[/green] [cyan]{instance_id}[/cyan]")
    except Exception as e:
        console.print(f"[red]✗[/red]\n[red]Error: {e}[/red]")
        raise SystemExit(1)

    console.print("Sending restart command...", end=" ")
    try:
        command_id = send_restart_command(instance_id, enc_region)
        console.print(f"[green]✓[/green] [dim]{command_id}[/dim]")
    except Exception as e:
        console.print(f"[red]✗[/red]\n[red]Error: {e}[/red]")
        raise SystemExit(1)

    spinner_text = Text(" Waiting for service restart...", style="bold")
    with Live(console=console, refresh_per_second=4) as live:
        live.update(Spinner("dots", text=spinner_text))
        restart_status, _ = poll_command(command_id, instance_id, enc_region, timeout=wait_timeout)

    if restart_status == "Success":
        console.print("[green]✓[/green] Restart command sent")
    else:
        console.print(
            f"[yellow]~[/yellow] Restart returned [dim]{restart_status}[/dim]"
            " [dim](service may still be starting up)[/dim]"
        )

    console.print()
    console.print(
        "[dim]Run with [cyan]--health[/cyan] and [cyan]--logs[/cyan]"
        " in a few minutes to check status.[/dim]"
    )
