"""Configuration file handling for exchange-keyshare."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


def get_default_region(fallback: str | None = None) -> str:
    return os.environ.get(
        "AWS_REGION",
        os.environ.get("AWS_DEFAULT_REGION", fallback if fallback else "us-east-1"),
    )


def _default_config_path() -> Path:
    """Get the default config path, respecting GM_SHIELD_CONFIG env var."""
    env_path = os.environ.get("GM_SHIELD_CONFIG")
    if env_path:
        return Path(env_path)

    home = Path.home()
    return home / ".config" / "gm-shield" / "config.yaml"


@dataclass
class ApprovedEnclave:
    """A Nitro Enclave approved to access credentials."""

    role_arn: str
    pcr8: str
    approved_at: str
    pcr0: str | None = None


@dataclass
class EnclaveConfig:
    """Persisted state for a deployed enclave stack."""

    stack_name: str
    stack_id: str
    region: str
    role_arn: str
    instance_profile_arn: str
    host_ref: str
    eip: str
    labels: list[str] = field(default_factory=list)


@dataclass
class Config:
    """Configuration container."""

    config_path: Path = field(default_factory=_default_config_path)
    bucket: str | None = None
    region: str | None = None
    stack_name: str | None = None
    stack_id: str | None = None
    kms_key_arn: str | None = None
    enclaves: list[EnclaveConfig] = field(default_factory=list)
    approved_enclave: ApprovedEnclave | None = None

    def load(self) -> None:
        """Load config from file."""
        data = load_config(self.config_path)

        self.bucket = data.get("bucket")
        self.region = data.get("region")
        self.stack_name = data.get("stack_name")
        self.stack_id = data.get("stack_id")
        self.kms_key_arn = data.get("kms_key_arn")

        enclaves_data = data.get("enclaves", [])
        self.enclaves = [
            EnclaveConfig(
                stack_name=e["stack_name"],
                stack_id=e["stack_id"],
                region=e["region"],
                role_arn=e.get("role_arn", ""),
                instance_profile_arn=e.get("instance_profile_arn", ""),
                host_ref=e.get("host_ref", e.get("instance_id", "")),
                labels=e.get("labels", []),
                eip=e.get("eip", ""),
            )
            for e in enclaves_data
        ]

        approved_data = data.get("approved_enclave")
        if approved_data:
            self.approved_enclave = ApprovedEnclave(
                role_arn=approved_data["role_arn"],
                pcr8=approved_data["pcr8"],
                approved_at=approved_data["approved_at"],
                pcr0=approved_data.get("pcr0"),
            )

    def save(self) -> None:
        """Save config to file."""
        data: dict[str, Any] = {}
        if self.bucket:
            data["bucket"] = self.bucket
        if self.region:
            data["region"] = self.region
        if self.stack_name:
            data["stack_name"] = self.stack_name
        if self.stack_id:
            data["stack_id"] = self.stack_id
        if self.kms_key_arn:
            data["kms_key_arn"] = self.kms_key_arn
        if self.enclaves:
            data["enclaves"] = [
                {
                    "stack_name": e.stack_name,
                    "stack_id": e.stack_id,
                    "region": e.region,
                    "role_arn": e.role_arn,
                    "instance_profile_arn": e.instance_profile_arn,
                    "host_ref": e.host_ref,
                    "eip": e.eip,
                    "labels": e.labels,
                }
                for e in self.enclaves
            ]
        if self.approved_enclave:
            data["approved_enclave"] = {
                "role_arn": self.approved_enclave.role_arn,
                "pcr8": self.approved_enclave.pcr8,
                **({"pcr0": self.approved_enclave.pcr0} if self.approved_enclave.pcr0 else {}),
                "approved_at": self.approved_enclave.approved_at,
            }
        save_config(self.config_path, data)

    def delete_credentials(self) -> None:
        """Delete credentials from config."""
        self.bucket = None
        self.region = None
        self.stack_name = None
        self.stack_id = None
        self.kms_key_arn = None
        self.approved_enclave = None

    def delete_enclave(self, stack_id: str) -> None:
        """Delete an enclave from the config by stack ID."""
        self.enclaves = [e for e in self.enclaves if e.stack_id != stack_id]

    def delete_approved_enclave(self, role_arn: str) -> None:
        """Delete the approved enclave from the config."""
        if not self.approved_enclave:
            return
        self.approved_enclave = None
        self.enclaves = [e for e in self.enclaves if e.role_arn != role_arn]


def load_config(path: Path) -> dict[str, Any]:
    """Load config from the YAML file. Returns empty dict if file doesn't exist."""
    if not path.exists():
        return {}

    with open(path) as f:
        data = yaml.safe_load(f)
        return data if data else {}


def save_config(path: Path, data: dict[str, Any]) -> None:
    """Save config to the YAML file. Creates parent directories if needed.

    Config file is created with 0600 permissions (owner read/write only).
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w") as f:
            yaml.dump(data, f, default_flow_style=False)
    except Exception:
        os.close(fd)
        raise
