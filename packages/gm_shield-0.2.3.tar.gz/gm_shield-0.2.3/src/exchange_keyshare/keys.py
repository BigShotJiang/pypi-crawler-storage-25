"""Key management operations with client-side KMS encryption."""

from __future__ import annotations

import base64
import secrets
import string
from collections.abc import Buffer
from dataclasses import dataclass

import boto3
import yaml

from exchange_keyshare.schema import CredentialSchema, validate_credential


def generate_s3_key(exchange: str) -> str:
    """Generate a unique S3 key for a credential."""
    chars = string.ascii_lowercase + string.digits
    suffix = "".join(secrets.choice(chars) for _ in range(12))
    return f"exchange-credentials/{exchange}-{suffix}.yaml"


def parse_credential_from_yaml(content: str) -> CredentialSchema:
    """Parse and validate credential from YAML string."""
    data = yaml.safe_load(content)
    return validate_credential(data)


@dataclass
class CredentialInfo:
    """Info about a stored credential (for listing)."""

    key: str
    exchange: str
    pairs: list[str] | None
    labels: list[dict[str, str]] | None


def _kms_encrypt(plaintext: bytes, kms_key_arn: str, region: str) -> bytes:
    """Encrypt plaintext with KMS. Returns raw ciphertext blob."""
    kms = boto3.client("kms", region_name=region)  # type: ignore[reportUnknownVariableType]
    response = kms.encrypt(KeyId=kms_key_arn, Plaintext=plaintext)
    ciphertext: bytes = response["CiphertextBlob"]
    return ciphertext


def _kms_decrypt(ciphertext: bytes, region: str) -> bytes:
    """Decrypt KMS ciphertext. Returns plaintext bytes."""
    kms = boto3.client("kms", region_name=region)  # type: ignore[reportUnknownVariableType]
    plaintext: bytes = kms.decrypt(CiphertextBlob=ciphertext)["Plaintext"]
    return plaintext


def _base64_encode(data: bytes) -> str:
    """Base64 encode bytes."""
    return base64.b64encode(data).decode("utf-8")


def _base64_decode(data: str | Buffer) -> bytes:
    """Base64 decode string."""
    return base64.b64decode(data)


def list_credentials(bucket: str, region: str) -> list[CredentialInfo]:
    """List all credentials in the bucket."""
    s3 = boto3.client("s3", region_name=region)  # type: ignore[reportUnknownVariableType]

    result: list[CredentialInfo] = []

    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix="exchange-credentials/"):
        for obj in page.get("Contents", []):
            key = obj.get("Key")
            if not key or not key.endswith(".yaml"):
                continue

            response = s3.get_object(Bucket=bucket, Key=key)
            ciphertext = base64.b64decode(response["Body"].read())
            plaintext = _kms_decrypt(ciphertext, region)
            cred = parse_credential_from_yaml(plaintext.decode())
            result.append(
                CredentialInfo(
                    key=key,
                    exchange=cred.exchange,
                    pairs=cred.pairs,
                    labels=cred.labels,
                )
            )

    return result


def upload_credential(
    bucket: str,
    region: str,
    credential: CredentialSchema,
    kms_key_arn: str,
    s3_key: str | None = None,
) -> str:
    """Encrypt credential with KMS and upload to S3. Returns the S3 key used."""
    s3 = boto3.client("s3", region_name=region)  # type: ignore[reportUnknownVariableType]

    key = s3_key or generate_s3_key(credential.exchange)
    plaintext = yaml.dump(credential.to_dict(), default_flow_style=False).encode()
    ciphertext = _kms_encrypt(plaintext, kms_key_arn, region)

    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=_base64_encode(ciphertext),
        ContentType="text/plain",
    )

    return key


def get_credential(bucket: str, region: str, key: str) -> CredentialSchema:
    """Get and decrypt a credential from S3."""
    s3 = boto3.client("s3", region_name=region)  # type: ignore[reportUnknownVariableType]

    response = s3.get_object(Bucket=bucket, Key=key)
    ciphertext = _base64_decode(response["Body"].read())
    plaintext = _kms_decrypt(ciphertext, region)
    return parse_credential_from_yaml(plaintext.decode())


def delete_credential(bucket: str, region: str, key: str) -> None:
    """Delete a credential from S3."""
    s3 = boto3.client("s3", region_name=region)  # type: ignore[reportUnknownVariableType]
    s3.delete_object(Bucket=bucket, Key=key)
