"""CLI entrypoint for exchange-keyshare."""

from pathlib import Path

import click
from rich.console import Console

from exchange_keyshare.commands.config import config
from exchange_keyshare.commands.enclave import enclave
from exchange_keyshare.commands.keys import keys
from exchange_keyshare.commands.setup import setup
from exchange_keyshare.commands.teardown import teardown
from exchange_keyshare.config import Config
from exchange_keyshare.meta import check_for_update


@click.group()
@click.version_option(package_name="gm-shield")
@click.option(
    "--config",
    "config_path",
    envvar="GM_SHIELD_CONFIG",
    type=click.Path(),
    help="Path to config file",
)
@click.pass_context
def main(ctx: click.Context, config_path: str | None) -> None:
    """GM Shield - Securely share exchange API credentials."""
    ctx.ensure_object(dict)
    cfg = Config()
    if config_path:
        cfg.config_path = Path(config_path)
    cfg.load()
    ctx.obj["config"] = cfg

    def _notify_update() -> None:
        result = check_for_update()
        if result is None:
            return
        latest, current = result
        console = Console(stderr=True)
        console.print()
        console.print(
            f"  [dim]A new version of gm-shield is available: "
            f"[bold]{latest}[/bold] [dim](you have {current})[/dim][/dim]"
        )
        console.print("  [dim]Update: [italic]uv tool upgrade gm-shield[/italic][/dim]")
        console.print()

    ctx.call_on_close(_notify_update)


main.add_command(setup)
main.add_command(config)
main.add_command(teardown)
main.add_command(keys)
main.add_command(enclave)


if __name__ == "__main__":
    main()
