"""Shared CloudFormation infrastructure — templates, polling, progress."""

from __future__ import annotations

import time
from collections.abc import Generator
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import quote

import boto3
from botocore.exceptions import ClientError

if TYPE_CHECKING:
    from mypy_boto3_cloudformation import CloudFormationClient


def load_credentials_template() -> str:
    """Load the creds CloudFormation template as a string."""
    path = Path(__file__).parent / "templates" / "credentials-stack.yaml"
    return path.read_text()


def load_enclave_template() -> str:
    """Load the enclave CloudFormation template as a string."""
    path = Path(__file__).parent / "templates" / "enclave-stack.yaml"
    return path.read_text()


@dataclass
class ResourceStatus:
    logical_id: str
    resource_type: str
    status: str
    reason: str | None = None


@dataclass
class StackProgress:
    resources: dict[str, ResourceStatus]
    stack_status: str
    is_complete: bool
    is_failed: bool
    failure_reason: str | None = None


RESOURCE_TYPE_NAMES: dict[str, str] = {
    "AWS::S3::Bucket": "S3 Bucket",
    "AWS::S3::BucketPolicy": "Bucket Policy",
    "AWS::KMS::Key": "KMS Key",
    "AWS::KMS::Alias": "KMS Alias",
    "AWS::IAM::Role": "IAM Role",
    "AWS::IAM::InstanceProfile": "Instance Profile",
    "AWS::EC2::Instance": "EC2 Instance",
    "AWS::EC2::LaunchTemplate": "EC2 Launch Template",
    "AWS::AutoScaling::AutoScalingGroup": "Auto Scaling Group",
}


def get_friendly_type(resource_type: str) -> str:
    """Get a more readable name for a resource type."""
    return RESOURCE_TYPE_NAMES.get(resource_type, resource_type)


def get_stack_console_url(stack_id: str, region: str) -> str:
    encoded = quote(stack_id, safe="")
    return f"https://{region}.console.aws.amazon.com/cloudformation/home?region={region}#/stacks/stackinfo?stackId={encoded}"


def poll_stack_progress(
    stack_name: str,
    cfn: CloudFormationClient,
    poll_interval: float = 2.0,
    max_attempts: int = 300,
) -> Generator[StackProgress, None, None]:
    resources: dict[str, ResourceStatus] = {}

    for _ in range(max_attempts):
        try:
            stacks_response = cfn.describe_stacks(StackName=stack_name)
        except ClientError:
            yield StackProgress(
                resources=resources,
                stack_status="DELETE_IN_PROGRESS",
                is_complete=False,
                is_failed=True,
                failure_reason="Stack creation failed and is being deleted",
            )
            return

        stack = stacks_response["Stacks"][0]
        stack_status = stack.get("StackStatus", "UNKNOWN")

        for event in cfn.describe_stack_events(StackName=stack_name)["StackEvents"]:
            logical_id = event.get("LogicalResourceId", "")
            resource_type = event.get("ResourceType", "")
            status = event.get("ResourceStatus", "")
            reason = event.get("ResourceStatusReason")

            if resource_type == "AWS::CloudFormation::Stack":
                continue
            is_newer = logical_id not in resources or _is_newer_status(
                status, resources[logical_id].status
            )
            if is_newer:
                resources[logical_id] = ResourceStatus(
                    logical_id=logical_id, resource_type=resource_type, status=status, reason=reason
                )

        is_complete = stack_status == "CREATE_COMPLETE"
        is_failed = stack_status in (
            "CREATE_FAILED",
            "ROLLBACK_COMPLETE",
            "ROLLBACK_IN_PROGRESS",
            "DELETE_IN_PROGRESS",
        )
        failure_reason: str | None = None
        if is_failed:
            failed = [r for r in resources.values() if "FAILED" in r.status]
            reasons = [r.reason for r in failed if r.reason]
            failure_reason = (
                "; ".join(reasons[:3]) if reasons else ("Unknown error" if failed else None)
            )

        yield StackProgress(
            resources=resources,
            stack_status=stack_status,
            is_complete=is_complete,
            is_failed=is_failed,
            failure_reason=failure_reason,
        )

        if is_complete or is_failed:
            return
        time.sleep(poll_interval)

    yield StackProgress(
        resources=resources,
        stack_status="TIMEOUT",
        is_complete=False,
        is_failed=True,
        failure_reason="Stack creation timed out",
    )


def _is_newer_status(new_status: str, old_status: str) -> bool:
    order = [
        "CREATE_IN_PROGRESS",
        "CREATE_COMPLETE",
        "CREATE_FAILED",
        "DELETE_IN_PROGRESS",
        "DELETE_COMPLETE",
    ]
    try:
        return order.index(new_status) > order.index(old_status)
    except ValueError:
        return True


def start_stack_deletion(stack_name: str, region: str):
    cfn = boto3.client("cloudformation", region_name=region)  # type: ignore[reportUnknownVariableType]
    try:
        cfn.delete_stack(StackName=stack_name)
    except ClientError as e:
        raise Exception(f"Failed to delete stack: {e}") from e
    return cfn


def poll_stack_deletion(
    stack_name: str,
    cfn: CloudFormationClient,
    poll_interval: float = 2.0,
    max_attempts: int = 300,
) -> Generator[StackProgress, None, None]:
    resources: dict[str, ResourceStatus] = {}

    for _ in range(max_attempts):
        try:
            stacks_response = cfn.describe_stacks(StackName=stack_name)
        except ClientError as e:
            if "does not exist" in str(e):
                yield StackProgress(
                    resources=resources,
                    stack_status="DELETE_COMPLETE",
                    is_complete=True,
                    is_failed=False,
                )
                return
            raise

        stack = stacks_response["Stacks"][0]
        stack_status = stack.get("StackStatus", "UNKNOWN")

        try:
            for event in cfn.describe_stack_events(StackName=stack_name)["StackEvents"]:
                logical_id = event.get("LogicalResourceId", "")
                resource_type = event.get("ResourceType", "")
                status = event.get("ResourceStatus", "")
                reason = event.get("ResourceStatusReason")

                if resource_type == "AWS::CloudFormation::Stack":
                    continue
                if "DELETE" not in status:
                    continue
                is_newer = logical_id not in resources or _is_newer_delete_status(
                    status, resources[logical_id].status
                )
                if is_newer:
                    resources[logical_id] = ResourceStatus(
                        logical_id=logical_id,
                        resource_type=resource_type,
                        status=status,
                        reason=reason,
                    )
        except ClientError:
            pass

        is_complete = stack_status == "DELETE_COMPLETE"
        is_failed = stack_status == "DELETE_FAILED"
        failure_reason = None
        if is_failed:
            failed = [r for r in resources.values() if "FAILED" in r.status]
            reasons = [r.reason for r in failed if r.reason]
            failure_reason = (
                "; ".join(reasons[:3]) if reasons else ("Unknown error" if failed else None)
            )

        yield StackProgress(
            resources=resources,
            stack_status=stack_status,
            is_complete=is_complete,
            is_failed=is_failed,
            failure_reason=failure_reason,
        )

        if is_complete or is_failed:
            return
        time.sleep(poll_interval)

    yield StackProgress(
        resources=resources,
        stack_status="TIMEOUT",
        is_complete=False,
        is_failed=True,
        failure_reason="Stack deletion timed out",
    )


def _is_newer_delete_status(new_status: str, old_status: str) -> bool:
    order = [
        "CREATE_COMPLETE",
        "DELETE_IN_PROGRESS",
        "DELETE_COMPLETE",
        "DELETE_FAILED",
        "DELETE_SKIPPED",
    ]
    try:
        return order.index(new_status) > order.index(old_status)
    except ValueError:
        return True
