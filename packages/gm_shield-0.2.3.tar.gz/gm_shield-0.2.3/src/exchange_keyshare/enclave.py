"""Enclave deployment logic for Nitro Enclave infrastructure."""

from __future__ import annotations

import secrets
import string
from dataclasses import dataclass
from typing import TYPE_CHECKING

import boto3
from botocore.exceptions import ClientError

from exchange_keyshare.cfn import load_enclave_template
from exchange_keyshare.config import get_default_region

if TYPE_CHECKING:
    from mypy_boto3_cloudformation import CloudFormationClient

ENCLAVE_DEFAULT_REGION = "eu-central-1"


def generate_enclave_stack_name() -> str:
    """Generate a unique enclave stack name."""
    chars = string.ascii_lowercase + string.digits
    suffix = "".join(secrets.choice(chars) for _ in range(8))
    return f"gm-enclave-{suffix}"


@dataclass
class EnclaveStackResult:
    """Result of enclave stack creation."""

    stack_name: str
    stack_id: str
    region: str
    role_arn: str
    instance_profile_arn: str
    host_ref: str
    eip: str


def _normalize_subnet_ids(subnet_ids: list[str] | None) -> list[str]:
    normalized: list[str] = []
    seen: set[str] = set()
    for raw in subnet_ids or []:
        subnet_id = raw.strip()
        if subnet_id and subnet_id not in seen:
            normalized.append(subnet_id)
            seen.add(subnet_id)
    return normalized


def _client_error_message(exc: ClientError) -> str:
    error = exc.response.get("Error", {})
    return str(error.get("Message", str(exc)))


def resolve_enclave_network(
    region: str,
    vpc_id: str | None = None,
    subnet_ids: list[str] | None = None,
) -> tuple[str, list[str]]:
    """Resolve a deployable VPC/subnet set for enclave infrastructure."""
    ec2 = boto3.client("ec2", region_name=region)  # type: ignore[reportUnknownVariableType]
    requested_subnet_ids = _normalize_subnet_ids(subnet_ids)
    normalized_vpc_id = vpc_id.strip() if vpc_id else ""

    if requested_subnet_ids:
        try:
            subnet_response = ec2.describe_subnets(SubnetIds=requested_subnet_ids)
        except ClientError as e:
            raise Exception(
                f"Unable to describe subnets in {region}: {_client_error_message(e)}"
            ) from e

        subnets = subnet_response.get("Subnets", [])
        found_ids = {s.get("SubnetId") for s in subnets if s.get("SubnetId")}
        missing = [sid for sid in requested_subnet_ids if sid not in found_ids]
        if missing:
            raise Exception(f"Subnet IDs not found in {region}: {', '.join(missing)}")

        subnet_vpc_ids = {s.get("VpcId") for s in subnets if s.get("VpcId")}
        if len(subnet_vpc_ids) != 1:
            raise Exception("Provided subnet IDs must belong to a single VPC")
        subnet_vpc_id = next(iter(subnet_vpc_ids))
        if not subnet_vpc_id:
            raise Exception("Unable to determine VPC ID from provided subnet IDs")

        if normalized_vpc_id and normalized_vpc_id != subnet_vpc_id:
            raise Exception(
                f"Subnet VPC mismatch: VpcId={normalized_vpc_id}, subnet VPC={subnet_vpc_id}"
            )
        return subnet_vpc_id, requested_subnet_ids

    resolved_vpc_id = normalized_vpc_id
    if not resolved_vpc_id:
        try:
            default_vpcs = ec2.describe_vpcs(
                Filters=[{"Name": "is-default", "Values": ["true"]}]
            ).get("Vpcs", [])
        except ClientError as e:
            raise Exception(f"Unable to list VPCs in {region}: {_client_error_message(e)}") from e

        default_vpc_ids = sorted(v.get("VpcId", "") for v in default_vpcs if v.get("VpcId"))
        if default_vpc_ids:
            resolved_vpc_id = default_vpc_ids[0]
        else:
            try:
                vpcs = ec2.describe_vpcs(Filters=[{"Name": "state", "Values": ["available"]}]).get(
                    "Vpcs", []
                )
            except ClientError as e:
                raise Exception(
                    f"Unable to list VPCs in {region}: {_client_error_message(e)}"
                ) from e
            vpc_ids = sorted(v.get("VpcId", "") for v in vpcs if v.get("VpcId"))
            if not vpc_ids:
                raise Exception(
                    f"No available VPCs found in {region}. Create a VPC/subnet or provide --vpc-id and --subnet-ids."
                )
            resolved_vpc_id = vpc_ids[0]

    try:
        vpc_response = ec2.describe_vpcs(VpcIds=[resolved_vpc_id])
    except ClientError as e:
        raise Exception(
            f"Unable to describe VPC {resolved_vpc_id} in {region}: {_client_error_message(e)}"
        ) from e
    if not vpc_response.get("Vpcs"):
        raise Exception(f"VPC {resolved_vpc_id} not found in {region}")

    try:
        subnet_response = ec2.describe_subnets(
            Filters=[
                {"Name": "vpc-id", "Values": [resolved_vpc_id]},
                {"Name": "state", "Values": ["available"]},
            ]
        )
    except ClientError as e:
        raise Exception(
            f"Unable to list subnets in VPC {resolved_vpc_id}: {_client_error_message(e)}"
        ) from e

    all_subnets = subnet_response.get("Subnets", [])
    if not all_subnets:
        raise Exception(f"No available subnets found in VPC {resolved_vpc_id} ({region})")

    preferred_subnets = [s for s in all_subnets if s.get("MapPublicIpOnLaunch")]
    candidate_subnets = preferred_subnets if preferred_subnets else all_subnets
    resolved_subnet_ids = [
        s["SubnetId"]
        for s in sorted(
            candidate_subnets,
            key=lambda s: (s.get("AvailabilityZone", ""), s.get("SubnetId", "")),
        )
        if s.get("SubnetId")
    ]
    if not resolved_subnet_ids:
        raise Exception(f"No valid subnet IDs found in VPC {resolved_vpc_id} ({region})")

    return resolved_vpc_id, resolved_subnet_ids


def start_enclave_stack_creation(
    instance_type: str,
    memory_mib: int,
    cpu_count: int,
    volume_size: int,
    credentials_region: str,
    vpc_id: str | None = None,
    subnet_ids: list[str] | None = None,
    region: str | None = None,
    stack_name: str | None = None,
) -> tuple[str, str | None, CloudFormationClient]:
    """Start enclave CloudFormation stack creation. Returns (stack_name, region, cfn_client)."""
    region = region or get_default_region(ENCLAVE_DEFAULT_REGION)
    name = stack_name or generate_enclave_stack_name()
    template = load_enclave_template()
    resolved_vpc_id, resolved_subnet_ids = resolve_enclave_network(
        region=region,
        vpc_id=vpc_id,
        subnet_ids=subnet_ids,
    )

    cfn: CloudFormationClient = boto3.client("cloudformation", region_name=region)  # type: ignore[reportUnknownVariableType]

    params = [
        {"ParameterKey": "InstanceType", "ParameterValue": instance_type},
        {"ParameterKey": "EnclaveMemoryMib", "ParameterValue": str(memory_mib)},
        {"ParameterKey": "EnclaveCpuCount", "ParameterValue": str(cpu_count)},
        {"ParameterKey": "RootVolumeSize", "ParameterValue": str(volume_size)},
        {"ParameterKey": "VpcId", "ParameterValue": resolved_vpc_id},
        {"ParameterKey": "SubnetIds", "ParameterValue": ",".join(resolved_subnet_ids)},
        {"ParameterKey": "CredentialsRegion", "ParameterValue": credentials_region},
    ]

    try:
        cfn.create_stack(
            StackName=name,
            TemplateBody=template,
            Parameters=params,  # type: ignore[reportArgumentType]
            Capabilities=["CAPABILITY_IAM"],
            OnFailure="DELETE",
        )
    except ClientError as e:
        if "AlreadyExistsException" in str(e):
            raise Exception(f"Stack {name} already exists") from e
        raise

    return name, region, cfn


def get_enclave_stack_outputs(stack_name: str, region: str) -> EnclaveStackResult:
    """Get outputs from a completed enclave stack."""
    cfn: CloudFormationClient = boto3.client("cloudformation", region_name=region)  # type: ignore[reportUnknownVariableType]

    response = cfn.describe_stacks(StackName=stack_name)
    stack = response["Stacks"][0]
    stack_id = stack.get("StackId", "")
    outputs: dict[str, str] = {
        o["OutputKey"]: o["OutputValue"]
        for o in stack.get("Outputs", [])
        if "OutputKey" in o and "OutputValue" in o
    }
    host_ref = outputs.get("HostRef") or outputs.get("InstanceId")
    if not host_ref:
        raise KeyError("Missing HostRef/InstanceId output in enclave stack")

    return EnclaveStackResult(
        stack_name=stack_name,
        stack_id=stack_id,
        region=region,
        role_arn=outputs["RoleArn"],
        instance_profile_arn=outputs["InstanceProfileArn"],
        host_ref=host_ref,
        eip=outputs["EIP"],
    )
