"""Runtime orchestration for the Nitro Enclave host service.

Manages SSM Parameter Store state, ASG instance resolution, SSM RunCommand
dispatch, distributed lock, health probes, and CloudWatch log tail.
"""

from __future__ import annotations

import os
import time
from datetime import UTC, datetime

import boto3
from botocore.exceptions import ClientError

REQUIRED_PARAMS = (
    "image_name",
    "eif_s3_uri",
    "org_name",
    "bucket_name",
    "bucket_region",
    "root_url",
)
OPTIONAL_PARAMS = (
    "log_stream_name",
    "log_region",
)
# Written by `run` on every invocation; not required for service start
METADATA_PARAMS = (
    "deployed_at",
    "deployed_by",
)
ALL_RUNTIME_PARAMS = REQUIRED_PARAMS + OPTIONAL_PARAMS + METADATA_PARAMS

REQUIRED_CREDS = ("gm_user", "gm_password")

_LOCK_TTL_SECONDS = 900  # 15 minutes


def ssm_runtime_path(stack_name: str, key: str) -> str:
    return f"/gm-shield/enclaves/{stack_name}/runtime/{key}"


def ssm_creds_path(stack_name: str, key: str) -> str:
    return f"/gm-shield/enclaves/{stack_name}/creds/{key}"


def _ssm_lock_path(stack_name: str) -> str:
    return f"/gm-shield/enclaves/{stack_name}/lock"


def get_runtime_params(stack_name: str, region: str) -> dict[str, str | None]:
    """Fetch all runtime params for a stack.

    Returns a dict with all ALL_RUNTIME_PARAMS + REQUIRED_CREDS keys.
    Secret values are shown as '***' when set, None when not set.
    Non-secret values are shown as their actual value or None.
    """
    ssm = boto3.client("ssm", region_name=region)

    result: dict[str, str | None] = {k: None for k in ALL_RUNTIME_PARAMS + REQUIRED_CREDS}

    # Fetch non-secret runtime params in one call (up to 10 at a time)
    runtime_paths = [ssm_runtime_path(stack_name, k) for k in ALL_RUNTIME_PARAMS]
    try:
        response = ssm.get_parameters(Names=runtime_paths)
        for param in response.get("Parameters", []):
            name: str = param["Name"]
            value: str = param["Value"]
            for k in ALL_RUNTIME_PARAMS:
                if name == ssm_runtime_path(stack_name, k):
                    result[k] = value
                    break
    except ClientError:
        pass

    # Fetch creds — just check existence, never expose values
    for cred_key in REQUIRED_CREDS:
        try:
            ssm.get_parameter(
                Name=ssm_creds_path(stack_name, cred_key),
                WithDecryption=False,
            )
            result[cred_key] = "***"
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code not in ("ParameterNotFound", "ParameterVersionNotFound"):
                raise

    return result


def upsert_param(
    stack_name: str,
    key: str,
    value: str,
    region: str,
    *,
    secret: bool = False,
) -> None:
    """Write or update a single SSM parameter."""
    ssm = boto3.client("ssm", region_name=region)
    path = ssm_creds_path(stack_name, key) if secret else ssm_runtime_path(stack_name, key)
    ssm.put_parameter(
        Name=path,
        Value=value,
        Type="SecureString" if secret else "String",
        Overwrite=True,
    )


def delete_stack_params(stack_name: str, region: str) -> None:
    """Delete all SSM parameters under /gm-shield/enclaves/<stack-name>/."""
    ssm = boto3.client("ssm", region_name=region)
    prefix = f"/gm-shield/enclaves/{stack_name}/"
    names: list[str] = []
    paginator = ssm.get_paginator("describe_parameters")
    for page in paginator.paginate(
        ParameterFilters=[{"Key": "Path", "Option": "Recursive", "Values": [prefix]}]
    ):
        for param in page.get("Parameters", []):
            names.append(param["Name"])

    # SSM delete_parameters accepts max 10 names at a time
    for i in range(0, len(names), 10):
        batch = names[i : i + 10]
        if batch:
            ssm.delete_parameters(Names=batch)


def validate_preflight(stack_name: str, region: str) -> list[str]:
    """Return a list of required SSM param names that are not yet set."""
    params = get_runtime_params(stack_name, region)
    missing: list[str] = []
    for key in REQUIRED_PARAMS:
        if not params.get(key):
            missing.append(f"runtime/{key}")
    for key in REQUIRED_CREDS:
        if not params.get(key):
            missing.append(f"creds/{key}")
    return missing


def resolve_active_instance(host_ref: str, region: str) -> str:
    """Resolve an active EC2 instance ID from a host_ref.

    Supported formats:
        asg/<asg-name> — returns the InService instance from the ASG
        i-<id> — returned as-is (direct instance reference)
    """
    if host_ref.startswith("asg/"):
        asg_name = host_ref[4:]
        asg = boto3.client("autoscaling", region_name=region)
        response = asg.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
        groups = response.get("AutoScalingGroups", [])
        if not groups:
            raise ValueError(f"ASG not found: {asg_name} (region: {region})")
        instances = [
            i for i in groups[0].get("Instances", []) if i.get("LifecycleState") == "InService"
        ]
        if not instances:
            all_states = [i.get("LifecycleState") for i in groups[0].get("Instances", [])]
            raise ValueError(
                f"No InService instance in ASG: {asg_name} (region: {region}, "
                f"instance states: {all_states or 'none'})"
            )
        return str(instances[0]["InstanceId"])

    if host_ref.startswith("i-"):
        return host_ref

    raise ValueError(
        f"Unsupported host_ref format: {host_ref!r} (expected 'asg/<name>' or 'i-<id>')"
    )


def send_shell_command(instance_id: str, region: str, commands: list[str]) -> str:
    """Send an AWS-RunShellScript command and return the command ID."""
    ssm = boto3.client("ssm", region_name=region)
    response = ssm.send_command(
        InstanceIds=[instance_id],
        DocumentName="AWS-RunShellScript",
        Parameters={"commands": commands},
    )
    return str(response["Command"]["CommandId"])


def send_restart_command(instance_id: str, region: str) -> str:
    """Send a systemctl restart shield-worker.service command."""
    return send_shell_command(instance_id, region, ["systemctl restart shield-worker.service"])


def poll_command(
    command_id: str,
    instance_id: str,
    region: str,
    timeout: int = 300,
    poll_interval: float = 2.0,
) -> tuple[str, str]:
    """Poll SSM command status until terminal state or timeout.

    Returns (status, combined_output). Status is one of:
    Success, Failed, Cancelled, TimedOut, DeliveryTimedOut, ExecutionTimedOut.
    """
    ssm = boto3.client("ssm", region_name=region)
    deadline = time.monotonic() + timeout
    terminal = {
        "Success",
        "Failed",
        "Cancelled",
        "TimedOut",
        "DeliveryTimedOut",
        "ExecutionTimedOut",
    }

    while time.monotonic() < deadline:
        try:
            response = ssm.get_command_invocation(
                CommandId=command_id,
                InstanceId=instance_id,
            )
            status: str = response.get("Status", "Pending")
            if status in terminal:
                stdout: str = response.get("StandardOutputContent", "")
                stderr: str = response.get("StandardErrorContent", "")
                return status, (stdout + stderr).strip()
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            # InvocationDoesNotExist is transient — command not yet registered
            if code != "InvocationDoesNotExist":
                raise

        time.sleep(poll_interval)

    return "TimedOut", ""


# Status-outputting probe commands — each prints the current state string to stdout.
_STATUS_SERVICE = "systemctl is-active shield-worker.service || true"
_STATUS_CONTAINER = (
    "docker inspect --format '{{.State.Status}}' shield-w-host 2>/dev/null || echo not-found"
)
_STATUS_ENCLAVE = (
    "nitro-cli describe-enclaves 2>/dev/null | "
    "python3 -c \"import sys,json; e=json.load(sys.stdin); print('running' if e else 'not-running')\""
    " || echo unknown"
)

STATUS_PROBES: list[tuple[str, str]] = [
    ("service", _STATUS_SERVICE),
    ("container", _STATUS_CONTAINER),
    ("enclave", _STATUS_ENCLAVE),
]


def get_lock_holder(stack_name: str, region: str) -> tuple[str, str, str] | None:
    """Return (identity, iso_timestamp, pid) if a valid (non-expired) lock exists, else None."""
    ssm = boto3.client("ssm", region_name=region)
    try:
        response = ssm.get_parameter(Name=_ssm_lock_path(stack_name))
        value: str = response["Parameter"]["Value"]
        parts = value.split("|")
        if len(parts) >= 3:
            identity, iso_ts, pid = parts[0], parts[1], parts[2]
            try:
                lock_time = datetime.fromisoformat(iso_ts)
                age = (datetime.now(UTC) - lock_time).total_seconds()
                if age < _LOCK_TTL_SECONDS:
                    return identity, iso_ts, pid
            except (ValueError, TypeError):
                pass  # malformed value — treat as expired
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code not in ("ParameterNotFound", "ParameterVersionNotFound"):
            raise
    return None


def acquire_lock(stack_name: str, region: str, identity: str) -> bool:
    """Attempt to acquire the deployment lock.

    Returns True if acquired, False if a valid lock is held by another caller.
    Note: there is a small TOCTOU window acceptable for a CLI tool.
    """
    holder = get_lock_holder(stack_name, region)
    if holder is not None:
        return False

    ssm = boto3.client("ssm", region_name=region)
    now_iso = datetime.now(UTC).isoformat()
    pid = str(os.getpid())
    ssm.put_parameter(
        Name=_ssm_lock_path(stack_name),
        Value=f"{identity}|{now_iso}|{pid}",
        Type="String",
        Overwrite=True,
    )
    return True


def force_unlock(stack_name: str, region: str) -> None:
    """Unconditionally delete the lock parameter."""
    ssm = boto3.client("ssm", region_name=region)
    try:
        ssm.delete_parameter(Name=_ssm_lock_path(stack_name))
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code not in ("ParameterNotFound", "ParameterVersionNotFound"):
            raise


def release_lock(stack_name: str, region: str) -> None:
    """Release the deployment lock (best-effort)."""
    try:
        force_unlock(stack_name, region)
    except Exception:
        pass


def fetch_log_tail(
    stack_name: str,
    region: str,
    n: int = 20,
) -> list[str]:
    """Fetch the last n log lines for the stack's shield-worker log stream.

    Uses log_stream_name and log_region from SSM if available.
    Returns an empty list on any error.
    """
    ssm = boto3.client("ssm", region_name=region)

    try:
        stream_response = ssm.get_parameter(Name=ssm_runtime_path(stack_name, "log_stream_name"))
        log_stream: str = stream_response["Parameter"]["Value"]
    except ClientError:
        # Fall back to org_name as stream name
        try:
            org_response = ssm.get_parameter(Name=ssm_runtime_path(stack_name, "org_name"))
            log_stream = org_response["Parameter"]["Value"]
        except ClientError:
            return []

    try:
        log_region_response = ssm.get_parameter(Name=ssm_runtime_path(stack_name, "log_region"))
        log_region: str = log_region_response["Parameter"]["Value"]
    except ClientError:
        log_region = region

    logs = boto3.client("logs", region_name=log_region)
    try:
        response = logs.get_log_events(
            logGroupName="/shield-worker",
            logStreamName=log_stream,
            startFromHead=False,
            limit=n,
        )
        return [str(e["message"]) for e in response.get("events", [])]
    except ClientError:
        return []
