"""Tests for CloudFormation operations."""

from exchange_keyshare.cfn import (
    get_friendly_type,
    get_stack_console_url,
    load_credentials_template,
    load_enclave_template,
)


def test_load_keys_template_returns_string() -> None:
    """keys-stack template should be loadable as string."""
    template = load_credentials_template()
    assert isinstance(template, str)
    assert "AWSTemplateFormatVersion" in template
    assert "CredentialsBucket" in template
    assert "CredentialsKey" in template


def test_keys_template_has_no_consumer_role() -> None:
    """keys-stack template must not have ConsumerAccessRole or ExternalId."""
    template = load_credentials_template()
    assert "ConsumerAccessRole" not in template
    assert "ExternalId" not in template


def test_load_enclave_template_returns_string() -> None:
    """enclave-stack template is loadable and defines the role and launch template resources."""
    template = load_enclave_template()
    assert isinstance(template, str)
    assert "EnclaveRole" in template
    assert "EnclaveLaunchTemplate" in template


def test_enclave_template_declares_vpc_params() -> None:
    """enclave-stack template must explicitly target a VPC and subnet set."""
    template = load_enclave_template()
    assert "VpcId" in template
    assert "SubnetIds" in template
    assert "VPCZoneIdentifier" in template


def test_get_stack_console_url_contains_region_and_encoded_stack_id() -> None:
    """Console URL contains the region subdomain and a URL-encoded stack ID."""
    stack_id = "arn:aws:cloudformation:us-east-1:123456789012:stack/my-stack/abc"
    url = get_stack_console_url(stack_id, "us-east-1")
    assert "us-east-1.console.aws.amazon.com" in url
    assert "stackId=" in url
    # Colons and slashes in the ARN are percent-encoded
    assert "arn%3A" in url


def test_get_friendly_type_returns_readable_name_for_known_resources() -> None:
    """Known AWS resource types map to human-readable names."""
    assert get_friendly_type("AWS::S3::Bucket") == "S3 Bucket"
    assert get_friendly_type("AWS::KMS::Key") == "KMS Key"
    assert get_friendly_type("AWS::IAM::Role") == "IAM Role"


def test_get_friendly_type_returns_original_for_unknown_resource() -> None:
    """Unknown resource types pass through unchanged."""
    assert get_friendly_type("AWS::Custom::Resource") == "AWS::Custom::Resource"
