"""Tests for keys module."""

from unittest.mock import MagicMock, patch

import pytest

from exchange_keyshare.keys import (
    _kms_decrypt,  # pyright: ignore [reportPrivateUsage]
    _kms_encrypt,  # pyright: ignore [reportPrivateUsage]
    generate_s3_key,
    parse_credential_from_yaml,
)


def test_generate_s3_key() -> None:
    """Generated keys have correct format and are unique."""
    key = generate_s3_key("binance")
    assert key.startswith("exchange-credentials/binance-")
    assert key.endswith(".yaml")

    # Keys should be unique
    assert generate_s3_key("binance") != generate_s3_key("binance")


def test_parse_credential_from_yaml_valid() -> None:
    """Valid YAML is parsed correctly."""
    yaml_content = """
version: "1.0"
exchange: binance
credential:
  api_key: test_key
  api_secret: test_secret
pairs:
  - BTC/USDT
"""
    result = parse_credential_from_yaml(yaml_content)
    assert result.exchange == "binance"
    assert result.pairs == ["BTC/USDT"]


def test_parse_credential_from_yaml_invalid() -> None:
    """Invalid YAML raises error."""
    yaml_content = """
version: "1.0"
exchange: unknown_exchange
credential:
  api_key: test
  api_secret: test
"""
    with pytest.raises(Exception):
        parse_credential_from_yaml(yaml_content)


@patch("exchange_keyshare.keys.boto3")
def test_kms_encrypt_calls_kms(mock_boto3: MagicMock) -> None:
    """_kms_encrypt calls kms.encrypt and returns the ciphertext blob."""
    mock_kms = MagicMock()
    mock_boto3.client.return_value = mock_kms
    mock_kms.encrypt.return_value = {"CiphertextBlob": b"encrypted-bytes"}

    result = _kms_encrypt(b"hello world", "arn:aws:kms:us-east-1:123:key/abc", "us-east-1")

    mock_boto3.client.assert_called_once_with("kms", region_name="us-east-1")
    mock_kms.encrypt.assert_called_once_with(
        KeyId="arn:aws:kms:us-east-1:123:key/abc", Plaintext=b"hello world"
    )
    assert result == b"encrypted-bytes"


@patch("exchange_keyshare.keys.boto3")
def test_kms_decrypt_calls_kms(mock_boto3: MagicMock) -> None:
    """_kms_decrypt calls kms.decrypt and returns the plaintext."""
    mock_kms = MagicMock()
    mock_boto3.client.return_value = mock_kms
    mock_kms.decrypt.return_value = {"Plaintext": b"hello world"}

    result = _kms_decrypt(b"encrypted-bytes", "us-east-1")

    mock_boto3.client.assert_called_once_with("kms", region_name="us-east-1")
    mock_kms.decrypt.assert_called_once_with(CiphertextBlob=b"encrypted-bytes")
    assert result == b"hello world"


@patch("exchange_keyshare.keys.boto3")
def test_kms_encrypt_decrypt_roundtrip(mock_boto3: MagicMock) -> None:
    """Encrypting then decrypting returns the original plaintext."""
    plaintext = b"exchange: binance\napi_key: secret123"
    ciphertext = b"opaque-kms-blob"

    mock_kms = MagicMock()
    mock_boto3.client.return_value = mock_kms
    mock_kms.encrypt.return_value = {"CiphertextBlob": ciphertext}
    mock_kms.decrypt.return_value = {"Plaintext": plaintext}

    encrypted = _kms_encrypt(plaintext, "arn:aws:kms:us-east-1:123:key/abc", "us-east-1")
    decrypted = _kms_decrypt(encrypted, "us-east-1")

    assert decrypted == plaintext
