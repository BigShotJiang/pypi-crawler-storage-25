"""Tests for exchange-keyshare."""
