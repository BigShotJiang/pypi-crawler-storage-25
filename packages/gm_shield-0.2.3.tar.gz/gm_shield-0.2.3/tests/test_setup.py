"""Tests for setup command logic."""

from exchange_keyshare.setup import generate_bucket_name


def test_generate_bucket_name() -> None:
    """Generated bucket names have correct format and are unique."""
    name = generate_bucket_name()
    assert name.startswith("gm-shield-")
    assert len(name) <= 63

    # Names should be unique
    assert generate_bucket_name() != generate_bucket_name()
