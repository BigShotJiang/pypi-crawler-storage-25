"""Tests for enclave CLI commands: approve, revoke, rotate, enclave teardown."""

from pathlib import Path
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from exchange_keyshare.cfn import StackProgress
from exchange_keyshare.cli import main
from exchange_keyshare.config import load_config, save_config

PCR8 = "a" * 96
PCR8_NEW = "b" * 96
PCR0_NEW = "c" * 96
ROLE_ARN = "arn:aws:iam::123456789012:role/enclave-role"


def _keyshare_config(tmp_path: Path) -> Path:
    """Config with keyshare stack deployed but no enclave."""
    path = tmp_path / "config.yaml"
    save_config(
        path,
        {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "stack_name": "test-stack",
            "kms_key_arn": "arn:aws:kms:us-east-1:123456789012:key/test",
        },
    )
    return path


def _config_with_approved_enclave(tmp_path: Path) -> Path:
    path = tmp_path / "config.yaml"
    save_config(
        path,
        {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "stack_name": "test-stack",
            "kms_key_arn": "arn:aws:kms:us-east-1:123456789012:key/test",
            "approved_enclave": {
                "role_arn": ROLE_ARN,
                "pcr8": PCR8,
                "approved_at": "2026-03-31T12:00:00Z",
            },
        },
    )
    return path


def _config_with_enclave(tmp_path: Path) -> Path:
    path = tmp_path / "config.yaml"
    save_config(
        path,
        {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "stack_name": "test-stack",
            "kms_key_arn": "arn:aws:kms:us-east-1:123456789012:key/test",
            "enclaves": [
                {
                    "stack_name": "gm-enclave-abc12345",
                    "stack_id": "arn:aws:cloudformation:us-east-1:123456789012:stack/gm-enclave-abc12345/xyz",
                    "region": "us-east-1",
                    "role_arn": ROLE_ARN,
                    "instance_profile_arn": "arn:aws:iam::123456789012:instance-profile/enclave-profile",
                    "host_ref": "i-0abc123def456",
                    "labels": [],
                }
            ],
        },
    )
    return path


def test_enclave_approve_shows_error_when_not_configured(tmp_path: Path) -> None:
    """Approve exits with error when keyshare stack is not configured."""
    runner = CliRunner()

    result = runner.invoke(
        main,
        [
            "--config",
            str(tmp_path / "config.yaml"),
            "enclave",
            "approve",
            "--role-arn",
            ROLE_ARN,
            "--pcr8",
            PCR8,
        ],
    )

    assert result.exit_code != 0, result.output
    assert "not configured" in result.output.lower()


def test_enclave_approve_shows_error_when_already_approved(tmp_path: Path) -> None:
    """Approve exits with error when an enclave is already approved."""
    config_path = _config_with_approved_enclave(tmp_path)
    runner = CliRunner()

    result = runner.invoke(
        main,
        [
            "--config",
            str(config_path),
            "enclave",
            "approve",
            "--role-arn",
            ROLE_ARN,
            "--pcr8",
            PCR8_NEW,
        ],
    )

    assert result.exit_code != 0, result.output
    assert "already approved" in result.output.lower()
    assert "revoke" in result.output.lower()


@patch("exchange_keyshare.commands.enclave._put_enclave_policies")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_enclave_approve_saves_approved_enclave_to_config(
    mock_questionary: MagicMock,
    mock_put_policies: MagicMock,
    tmp_path: Path,
) -> None:
    """Approve calls policy update and persists approved_enclave to config on confirmation."""
    mock_questionary.text.return_value.ask.return_value = ""  # pcr0 empty → None
    mock_questionary.confirm.return_value.ask.return_value = True
    config_path = _keyshare_config(tmp_path)
    runner = CliRunner()

    result = runner.invoke(
        main,
        [
            "--config",
            str(config_path),
            "enclave",
            "approve",
            "--role-arn",
            ROLE_ARN,
            "--pcr8",
            PCR8,
        ],
    )

    assert result.exit_code == 0, result.output
    mock_put_policies.assert_called_once()
    saved = load_config(config_path)
    assert saved["approved_enclave"]["role_arn"] == ROLE_ARN
    assert saved["approved_enclave"]["pcr8"] == PCR8


@patch("exchange_keyshare.commands.enclave._put_enclave_policies")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_enclave_approve_does_not_update_policies_when_declined(
    mock_questionary: MagicMock,
    mock_put_policies: MagicMock,
    tmp_path: Path,
) -> None:
    """Approve does not update policies when user declines the confirmation prompt."""
    mock_questionary.text.return_value.ask.return_value = ""
    mock_questionary.confirm.return_value.ask.return_value = False
    config_path = _keyshare_config(tmp_path)
    runner = CliRunner()

    result = runner.invoke(
        main,
        [
            "--config",
            str(config_path),
            "enclave",
            "approve",
            "--role-arn",
            ROLE_ARN,
            "--pcr8",
            PCR8,
        ],
    )

    assert result.exit_code != 0, result.output
    mock_put_policies.assert_not_called()


def test_enclave_revoke_shows_error_when_not_configured(tmp_path: Path) -> None:
    """Revoke exits with error when keyshare stack is not configured."""
    runner = CliRunner()

    result = runner.invoke(main, ["--config", str(tmp_path / "config.yaml"), "enclave", "revoke"])

    assert result.exit_code != 0, result.output
    assert "not configured" in result.output.lower()


def test_enclave_revoke_shows_error_when_no_approved_enclave(tmp_path: Path) -> None:
    """Revoke exits with error when no enclave is currently approved."""
    config_path = _keyshare_config(tmp_path)
    runner = CliRunner()

    result = runner.invoke(main, ["--config", str(config_path), "enclave", "revoke"])

    assert result.exit_code != 0, result.output
    assert "no approved enclave" in result.output.lower() or "approve" in result.output.lower()


@patch("exchange_keyshare.commands.enclave._revoke_enclave_access")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_enclave_revoke_clears_approved_enclave_from_config(
    mock_questionary: MagicMock,
    mock_revoke: MagicMock,
    tmp_path: Path,
) -> None:
    """Revoke calls revoke_access and removes approved_enclave from config on confirmation."""
    mock_questionary.confirm.return_value.ask.return_value = True
    config_path = _config_with_approved_enclave(tmp_path)
    runner = CliRunner()

    result = runner.invoke(main, ["--config", str(config_path), "enclave", "revoke"])

    assert result.exit_code == 0, result.output
    mock_revoke.assert_called_once()
    saved = load_config(config_path)
    assert "approved_enclave" not in saved


@patch("exchange_keyshare.commands.enclave._revoke_enclave_access")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_enclave_revoke_does_not_revoke_access_when_declined(
    mock_questionary: MagicMock,
    mock_revoke: MagicMock,
    tmp_path: Path,
) -> None:
    """Revoke does not call revoke_access when user declines the confirmation prompt."""
    mock_questionary.confirm.return_value.ask.return_value = False
    config_path = _config_with_approved_enclave(tmp_path)
    runner = CliRunner()

    result = runner.invoke(main, ["--config", str(config_path), "enclave", "revoke"])

    assert result.exit_code != 0, result.output
    mock_revoke.assert_not_called()


def test_enclave_rotate_shows_error_when_not_configured(tmp_path: Path) -> None:
    """Rotate exits with error when keyshare stack is not configured."""
    runner = CliRunner()

    result = runner.invoke(
        main,
        ["--config", str(tmp_path / "config.yaml"), "enclave", "rotate", "--pcr0", PCR0_NEW],
    )

    assert result.exit_code != 0, result.output
    assert "not configured" in result.output.lower()


def test_enclave_rotate_shows_error_when_no_approved_enclave(tmp_path: Path) -> None:
    """Rotate exits with error when no enclave is currently approved."""
    config_path = _keyshare_config(tmp_path)
    runner = CliRunner()

    result = runner.invoke(
        main,
        ["--config", str(config_path), "enclave", "rotate", "--pcr0", PCR0_NEW],
    )

    assert result.exit_code != 0, result.output
    assert "no approved enclave" in result.output.lower() or "approve" in result.output.lower()


@patch("exchange_keyshare.commands.enclave._put_enclave_policies")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_enclave_rotate_updates_pcr0_and_preserves_pcr8_in_config(
    mock_questionary: MagicMock,
    mock_put_policies: MagicMock,
    tmp_path: Path,
) -> None:
    """Rotate updates PCR0 in config while preserving PCR8 and role ARN."""
    mock_questionary.confirm.return_value.ask.return_value = True
    config_path = _config_with_approved_enclave(tmp_path)
    runner = CliRunner()

    result = runner.invoke(
        main,
        ["--config", str(config_path), "enclave", "rotate", "--pcr0", PCR0_NEW],
    )

    assert result.exit_code == 0, result.output
    mock_put_policies.assert_called_once()
    saved = load_config(config_path)
    assert saved["approved_enclave"]["pcr0"] == PCR0_NEW
    assert saved["approved_enclave"]["pcr8"] == PCR8
    assert saved["approved_enclave"]["role_arn"] == ROLE_ARN


@patch("exchange_keyshare.commands.enclave._put_enclave_policies")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_enclave_rotate_does_not_update_policies_when_declined(
    mock_questionary: MagicMock,
    mock_put_policies: MagicMock,
    tmp_path: Path,
) -> None:
    """Rotate does not update policies when user declines the confirmation prompt."""
    mock_questionary.confirm.return_value.ask.return_value = False
    config_path = _config_with_approved_enclave(tmp_path)
    runner = CliRunner()

    result = runner.invoke(
        main,
        ["--config", str(config_path), "enclave", "rotate", "--pcr0", PCR0_NEW],
    )

    assert result.exit_code != 0, result.output
    mock_put_policies.assert_not_called()


def test_enclave_teardown_shows_message_when_no_enclaves_deployed(tmp_path: Path) -> None:
    """Enclave teardown exits cleanly with a message when no enclaves are in config."""
    config_path = _keyshare_config(tmp_path)
    runner = CliRunner()

    result = runner.invoke(main, ["--config", str(config_path), "enclave", "teardown", "nonexistent"])

    assert result.exit_code == 0, result.output
    assert "no enclave" in result.output.lower() or "deploy" in result.output.lower()


def test_enclave_teardown_aborts_when_confirmation_does_not_match(
    tmp_path: Path,
) -> None:
    """Enclave teardown aborts when the typed confirmation does not match the stack name."""
    config_path = _config_with_enclave(tmp_path)
    runner = CliRunner()

    result = runner.invoke(
        main,
        ["--config", str(config_path), "enclave", "teardown", "gm-enclave-abc12345"],
        input="wrong-name\n",
    )

    assert result.exit_code != 0, result.output
    assert "aborted" in result.output.lower() or "did not match" in result.output.lower()


@patch("exchange_keyshare.commands.enclave.poll_stack_deletion")
@patch("exchange_keyshare.commands.enclave.start_stack_deletion")
def test_enclave_teardown_deletes_stack_and_removes_enclave_from_config(
    mock_start_deletion: MagicMock,
    mock_poll_deletion: MagicMock,
    tmp_path: Path,
) -> None:
    """Enclave teardown deletes the CloudFormation stack and removes the entry from config."""
    mock_start_deletion.return_value = MagicMock()
    mock_poll_deletion.return_value = iter(
        [
            StackProgress(
                resources={},
                stack_status="DELETE_COMPLETE",
                is_complete=True,
                is_failed=False,
            )
        ]
    )
    config_path = _config_with_enclave(tmp_path)
    runner = CliRunner()

    result = runner.invoke(
        main,
        ["--config", str(config_path), "enclave", "teardown", "gm-enclave-abc12345"],
        input="gm-enclave-abc12345\n",
    )

    assert result.exit_code == 0, result.output
    mock_start_deletion.assert_called_once_with("gm-enclave-abc12345", "us-east-1")
    saved = load_config(config_path)
    assert not saved.get("enclaves")
