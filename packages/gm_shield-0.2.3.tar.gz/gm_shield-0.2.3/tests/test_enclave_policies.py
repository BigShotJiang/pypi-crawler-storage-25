"""Tests for enclave KMS/S3 policy update helpers."""

from __future__ import annotations

import json
from io import StringIO
from unittest.mock import MagicMock, patch

import pytest
from botocore.exceptions import ClientError
from rich.console import Console

from exchange_keyshare.commands.enclave import (
    _ENCLAVE_S3_SIDS,  # pyright: ignore[reportPrivateUsage]
    _put_enclave_policies,  # pyright: ignore[reportPrivateUsage]
)


def _client_error(code: str, message: str, operation: str) -> ClientError:
    return ClientError({"Error": {"Code": code, "Message": message}}, operation)


def _console() -> Console:
    return Console(file=StringIO(), force_terminal=False, color_system=None)


@patch("exchange_keyshare.commands.enclave.boto3.client")
def test_update_enclave_policies_replaces_stale_managed_statements(
    mock_boto3_client: MagicMock,
) -> None:
    """Managed enclave statements are replaced and other policy statements stay intact."""
    mock_kms = MagicMock()
    mock_s3 = MagicMock()
    mock_boto3_client.side_effect = [mock_kms, mock_s3]

    old_role = "arn:aws:iam::123456789012:role/enclave-old"
    new_role = "arn:aws:iam::123456789012:role/enclave-new"
    key_arn = "arn:aws:kms:us-east-1:123456789012:key/test"

    mock_kms.get_key_policy.return_value = {
        "Policy": json.dumps(
            {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "AllowAccountRoot",
                        "Effect": "Allow",
                        "Principal": {"AWS": "arn:aws:iam::123456789012:root"},
                        "Action": "kms:*",
                        "Resource": "*",
                    },
                    {
                        "Sid": "AllowEnclaveDecrypt",
                        "Effect": "Allow",
                        "Principal": {"AWS": old_role},
                        "Action": ["kms:Decrypt", "kms:DescribeKey"],
                        "Resource": "*",
                    },
                ],
            }
        )
    }
    mock_s3.get_bucket_policy.return_value = {
        "Policy": json.dumps(
            {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "DenyInsecureTransport",
                        "Effect": "Deny",
                        "Principal": "*",
                        "Action": "s3:*",
                        "Resource": ["arn:aws:s3:::bucket", "arn:aws:s3:::bucket/*"],
                    },
                    {
                        "Sid": "AllowEnclaveListBucket",
                        "Effect": "Allow",
                        "Principal": {"AWS": old_role},
                        "Action": "s3:ListBucket",
                        "Resource": "arn:aws:s3:::bucket",
                    },
                    {
                        "Sid": "AllowEnclaveGetObject",
                        "Effect": "Allow",
                        "Principal": {"AWS": old_role},
                        "Action": "s3:GetObject",
                        "Resource": "arn:aws:s3:::bucket/exchange-credentials/*",
                    },
                ],
            }
        )
    }

    _put_enclave_policies(
        role_arn=new_role,
        pcr8="a" * 96,
        pcr0=None,
        kms_key_arn=key_arn,
        bucket="bucket",
        region="us-east-1",
        console=_console(),
    )

    kms_policy = json.loads(mock_kms.put_key_policy.call_args.kwargs["Policy"])
    kms_enclave = [s for s in kms_policy["Statement"] if s.get("Sid") == "AllowEnclaveDecrypt"]
    assert len(kms_enclave) == 1
    assert kms_enclave[0]["Principal"]["AWS"] == new_role
    assert any(s.get("Sid") == "AllowAccountRoot" for s in kms_policy["Statement"])

    s3_policy = json.loads(mock_s3.put_bucket_policy.call_args.kwargs["Policy"])
    assert any(s.get("Sid") == "DenyInsecureTransport" for s in s3_policy["Statement"])
    assert sum(1 for s in s3_policy["Statement"] if s.get("Sid") in _ENCLAVE_S3_SIDS) == len(
        _ENCLAVE_S3_SIDS
    )
    for sid in _ENCLAVE_S3_SIDS:
        statement = next(s for s in s3_policy["Statement"] if s.get("Sid") == sid)
        assert statement["Principal"]["AWS"] == new_role


@patch("exchange_keyshare.commands.enclave.boto3.client")
def test_update_enclave_policies_handles_missing_s3_policy(mock_boto3_client: MagicMock) -> None:
    """NoSuchBucketPolicy creates a new policy with enclave statements."""
    mock_kms = MagicMock()
    mock_s3 = MagicMock()
    mock_boto3_client.side_effect = [mock_kms, mock_s3]

    mock_kms.get_key_policy.return_value = {"Policy": json.dumps({"Version": "2012-10-17"})}
    mock_s3.get_bucket_policy.side_effect = _client_error(
        "NoSuchBucketPolicy", "No bucket policy", "GetBucketPolicy"
    )

    _put_enclave_policies(
        role_arn="arn:aws:iam::123456789012:role/enclave-new",
        pcr8="b" * 96,
        pcr0=None,
        kms_key_arn="arn:aws:kms:us-east-1:123456789012:key/test",
        bucket="bucket",
        region="us-east-1",
        console=_console(),
    )

    s3_policy = json.loads(mock_s3.put_bucket_policy.call_args.kwargs["Policy"])
    assert s3_policy["Version"] == "2012-10-17"
    assert sum(1 for s in s3_policy["Statement"] if s.get("Sid") in _ENCLAVE_S3_SIDS) == len(
        _ENCLAVE_S3_SIDS
    )


@patch("exchange_keyshare.commands.enclave.boto3.client")
def test_update_enclave_policies_cleans_managed_statements_once_on_invalid_principal(
    mock_boto3_client: MagicMock,
) -> None:
    """Invalid principal triggers one-shot cleanup then a second apply."""
    mock_kms = MagicMock()
    mock_s3 = MagicMock()
    mock_boto3_client.side_effect = [mock_kms, mock_s3]

    key_arn = "arn:aws:kms:us-east-1:123456789012:key/test"
    role_arn = "arn:aws:iam::123456789012:role/enclave-new"

    mock_kms.get_key_policy.return_value = {"Policy": json.dumps({"Version": "2012-10-17"})}
    mock_kms.put_key_policy.side_effect = [
        _client_error(
            "MalformedPolicyDocumentException",
            "Policy contains invalid principal",
            "PutKeyPolicy",
        ),
        {},
        {},
    ]
    mock_s3.get_bucket_policy.side_effect = _client_error(
        "NoSuchBucketPolicy", "No bucket policy", "GetBucketPolicy"
    )

    _put_enclave_policies(
        role_arn=role_arn,
        pcr8="c" * 96,
        pcr0=None,
        kms_key_arn=key_arn,
        bucket="bucket",
        region="us-east-1",
        console=_console(),
    )

    assert mock_kms.put_key_policy.call_count == 3
    cleaned_policy = json.loads(mock_kms.put_key_policy.call_args_list[1].kwargs["Policy"])
    reapplied_policy = json.loads(mock_kms.put_key_policy.call_args_list[2].kwargs["Policy"])
    assert all(s.get("Sid") != "AllowEnclaveDecrypt" for s in cleaned_policy["Statement"])
    enclave_statements = [
        s for s in reapplied_policy["Statement"] if s.get("Sid") == "AllowEnclaveDecrypt"
    ]
    assert len(enclave_statements) == 1
    assert enclave_statements[0]["Principal"]["AWS"] == role_arn


@patch("exchange_keyshare.commands.enclave.boto3.client")
def test_update_enclave_policies_fails_for_invalid_new_principal(
    mock_boto3_client: MagicMock,
) -> None:
    """If new role ARN is invalid, command fails after one-shot cleanup attempt."""
    mock_kms = MagicMock()
    mock_s3 = MagicMock()
    mock_boto3_client.side_effect = [mock_kms, mock_s3]

    mock_kms.get_key_policy.return_value = {"Policy": json.dumps({"Version": "2012-10-17"})}
    mock_kms.put_key_policy.side_effect = [
        _client_error(
            "MalformedPolicyDocumentException",
            "Policy contains invalid principal",
            "PutKeyPolicy",
        ),
        {},
        _client_error(
            "MalformedPolicyDocumentException",
            "Policy contains invalid principal",
            "PutKeyPolicy",
        ),
    ]

    with pytest.raises(SystemExit):
        _put_enclave_policies(
            role_arn="arn:aws:iam::123456789012:role/enclave-missing",
            pcr8="d" * 96,
            pcr0=None,
            kms_key_arn="arn:aws:kms:us-east-1:123456789012:key/test",
            bucket="bucket",
            region="us-east-1",
            console=_console(),
        )

    # KMS failed, so S3 update should not run.
    mock_s3.get_bucket_policy.assert_not_called()
