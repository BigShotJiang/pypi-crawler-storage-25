"""Tests for src/exchange_keyshare/run.py and gm-shield enclave run command."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from botocore.exceptions import ClientError
from click.testing import CliRunner

from exchange_keyshare.cli import main
from exchange_keyshare.config import save_config
from exchange_keyshare.run import (
    ALL_RUNTIME_PARAMS,
    REQUIRED_CREDS,
    REQUIRED_PARAMS,
    acquire_lock,
    delete_stack_params,
    force_unlock,
    get_runtime_params,
    ssm_creds_path,
    ssm_runtime_path,
    upsert_param,
    validate_preflight,
)

STACK = "gm-enclave-test1234"
REGION = "eu-central-1"
INSTANCE_ID = "i-0abc1234567890def"
ASG_NAME = "gm-enclave-test1234-EnclaveAutoScalingGroup-XXXX"


def _enclave_config(tmp_path: Path) -> Path:
    path = tmp_path / "config.yaml"
    save_config(
        path,
        {
            "enclaves": [
                {
                    "stack_name": STACK,
                    "stack_id": f"arn:aws:cloudformation:{REGION}:123456789012:stack/{STACK}/abc",
                    "region": REGION,
                    "role_arn": "arn:aws:iam::123456789012:role/enclave-role",
                    "instance_profile_arn": "arn:aws:iam::123456789012:instance-profile/enclave-ip",
                    "host_ref": f"asg/{ASG_NAME}",
                    "eip": "1.2.3.4",
                }
            ]
        },
    )
    return path


def _not_found_error() -> ClientError:
    return ClientError(
        {"Error": {"Code": "ParameterNotFound", "Message": "not found"}},
        "GetParameter",
    )


# ── SSM path helpers ──────────────────────────────────────────────────────────


def test_ssm_runtime_path() -> None:
    assert (
        ssm_runtime_path("my-stack", "image_name")
        == "/gm-shield/enclaves/my-stack/runtime/image_name"
    )


def test_ssm_creds_path() -> None:
    assert ssm_creds_path("my-stack", "gm_user") == "/gm-shield/enclaves/my-stack/creds/gm_user"


def test_all_runtime_params_contains_required_and_optional() -> None:
    for k in REQUIRED_PARAMS:
        assert k in ALL_RUNTIME_PARAMS
    assert "log_stream_name" in ALL_RUNTIME_PARAMS
    assert "log_region" in ALL_RUNTIME_PARAMS


def test_get_runtime_params_all_set() -> None:
    mock_ssm = MagicMock()
    mock_ssm.get_parameters.return_value = {
        "Parameters": [
            {"Name": ssm_runtime_path(STACK, k), "Value": f"val-{k}"} for k in ALL_RUNTIME_PARAMS
        ]
    }
    mock_ssm.get_parameter.return_value = {"Parameter": {"Value": "ignored"}}

    with patch("exchange_keyshare.run.boto3") as mock_boto3:
        mock_boto3.client.return_value = mock_ssm
        result = get_runtime_params(STACK, REGION)

    for k in ALL_RUNTIME_PARAMS:
        assert result[k] == f"val-{k}"
    for k in REQUIRED_CREDS:
        assert result[k] == "***"


def test_get_runtime_params_creds_not_set() -> None:
    mock_ssm = MagicMock()
    mock_ssm.get_parameters.return_value = {"Parameters": []}
    mock_ssm.get_parameter.side_effect = _not_found_error()

    with patch("exchange_keyshare.run.boto3") as mock_boto3:
        mock_boto3.client.return_value = mock_ssm
        result = get_runtime_params(STACK, REGION)

    for k in REQUIRED_CREDS:
        assert result[k] is None


def test_upsert_param_string() -> None:
    mock_ssm = MagicMock()
    with patch("exchange_keyshare.run.boto3") as mock_boto3:
        mock_boto3.client.return_value = mock_ssm
        upsert_param(STACK, "image_name", "my-image:v1", REGION)

    mock_ssm.put_parameter.assert_called_once_with(
        Name=ssm_runtime_path(STACK, "image_name"),
        Value="my-image:v1",
        Type="String",
        Overwrite=True,
    )


def test_upsert_param_secret() -> None:
    mock_ssm = MagicMock()
    with patch("exchange_keyshare.run.boto3") as mock_boto3:
        mock_boto3.client.return_value = mock_ssm
        upsert_param(STACK, "gm_password", "s3cr3t!", REGION, secret=True)

    mock_ssm.put_parameter.assert_called_once_with(
        Name=ssm_creds_path(STACK, "gm_password"),
        Value="s3cr3t!",
        Type="SecureString",
        Overwrite=True,
    )


def test_delete_stack_params_batches() -> None:
    names = [f"/gm-shield/enclaves/{STACK}/runtime/param{i}" for i in range(15)]
    mock_ssm = MagicMock()
    mock_paginator = MagicMock()
    mock_paginator.paginate.return_value = [{"Parameters": [{"Name": n} for n in names]}]
    mock_ssm.get_paginator.return_value = mock_paginator

    with patch("exchange_keyshare.run.boto3") as mock_boto3:
        mock_boto3.client.return_value = mock_ssm
        delete_stack_params(STACK, REGION)

    assert mock_ssm.delete_parameters.call_count == 2
    first_batch = mock_ssm.delete_parameters.call_args_list[0][1]["Names"]
    second_batch = mock_ssm.delete_parameters.call_args_list[1][1]["Names"]
    assert len(first_batch) == 10
    assert len(second_batch) == 5


def test_delete_stack_params_no_params() -> None:
    mock_ssm = MagicMock()
    mock_paginator = MagicMock()
    mock_paginator.paginate.return_value = [{"Parameters": []}]
    mock_ssm.get_paginator.return_value = mock_paginator

    with patch("exchange_keyshare.run.boto3") as mock_boto3:
        mock_boto3.client.return_value = mock_ssm
        delete_stack_params(STACK, REGION)

    mock_ssm.delete_parameters.assert_not_called()


# ── validate_preflight ────────────────────────────────────────────────────────


def test_validate_preflight_all_set() -> None:
    params = {k: f"val-{k}" for k in ALL_RUNTIME_PARAMS}
    params.update({k: "***" for k in REQUIRED_CREDS})

    with patch("exchange_keyshare.run.get_runtime_params", return_value=params):
        missing = validate_preflight(STACK, REGION)

    assert missing == []


def test_validate_preflight_missing_required() -> None:
    params: dict[str, str | None] = {k: None for k in ALL_RUNTIME_PARAMS + REQUIRED_CREDS}
    params["image_name"] = "some-image"

    with patch("exchange_keyshare.run.get_runtime_params", return_value=params):
        missing = validate_preflight(STACK, REGION)

    assert "runtime/eif_s3_uri" in missing
    assert "runtime/org_name" in missing
    assert "creds/gm_user" in missing
    assert "runtime/image_name" not in missing


def test_resolve_active_instance_direct() -> None:
    from exchange_keyshare.run import resolve_active_instance

    result = resolve_active_instance(INSTANCE_ID, REGION)
    assert result == INSTANCE_ID


def test_send_restart_command_uses_systemctl() -> None:
    from exchange_keyshare.run import send_restart_command

    mock_ssm = MagicMock()
    mock_ssm.send_command.return_value = {"Command": {"CommandId": "cmd-restart"}}

    with patch("exchange_keyshare.run.boto3") as mock_boto3:
        mock_boto3.client.return_value = mock_ssm
        cid = send_restart_command(INSTANCE_ID, REGION)

    assert cid == "cmd-restart"
    sent_params = mock_ssm.send_command.call_args[1]
    assert sent_params["Parameters"]["commands"] == ["systemctl restart shield-worker.service"]


def test_acquire_lock_no_existing() -> None:
    mock_ssm = MagicMock()
    mock_ssm.get_parameter.side_effect = _not_found_error()

    with (
        patch("exchange_keyshare.run.boto3") as mock_boto3,
        patch("exchange_keyshare.run.os.getpid", return_value=1234),
    ):
        mock_boto3.client.return_value = mock_ssm
        result = acquire_lock(STACK, REGION, "test-user")

    assert result is True
    mock_ssm.put_parameter.assert_called_once()
    value = mock_ssm.put_parameter.call_args[1]["Value"]
    assert value.startswith("test-user|")
    assert "|1234" in value


def test_acquire_lock_held_and_fresh() -> None:
    from datetime import UTC, datetime

    fresh_ts = datetime.now(UTC).isoformat()
    mock_ssm = MagicMock()
    mock_ssm.get_parameter.return_value = {"Parameter": {"Value": f"other-user|{fresh_ts}|9999"}}

    with patch("exchange_keyshare.run.boto3") as mock_boto3:
        mock_boto3.client.return_value = mock_ssm
        result = acquire_lock(STACK, REGION, "test-user")

    assert result is False
    mock_ssm.put_parameter.assert_not_called()


def test_force_unlock_deletes_param() -> None:
    mock_ssm = MagicMock()
    with patch("exchange_keyshare.run.boto3") as mock_boto3:
        mock_boto3.client.return_value = mock_ssm
        force_unlock(STACK, REGION)

    mock_ssm.delete_parameter.assert_called_once_with(Name=f"/gm-shield/enclaves/{STACK}/lock")


def _full_params() -> dict[str, str | None]:
    return {
        "image_name": "123.dkr.ecr.eu-central-1.amazonaws.com/shield-worker-host:v1",
        "eif_s3_uri": "s3://my-eif-bucket/shield-w.eif",
        "org_name": "glass-sales",
        "bucket_name": "my-creds-bucket",
        "bucket_region": "eu-central-1",
        "root_url": "https://backend.example.com",
        "log_stream_name": "glass-sales",
        "log_region": "eu-central-1",
        "deployed_at": None,
        "deployed_by": None,
        "gm_user": "***",
        "gm_password": "***",
    }


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.upsert_param")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=[])
@patch("exchange_keyshare.commands.enclave.acquire_lock", return_value=True)
@patch("exchange_keyshare.commands.enclave.release_lock")
@patch("exchange_keyshare.commands.enclave._get_caller_identity", return_value="test:user")
@patch("exchange_keyshare.run.send_shell_command", return_value="cmd-probe")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_run_updates_image_name(
    mock_q: MagicMock,
    _mock_send_shell: MagicMock,
    _mock_identity: MagicMock,
    _mock_release: MagicMock,
    _mock_acquire: MagicMock,
    _mock_preflight: MagicMock,
    mock_upsert: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """--image-name: SSM written, service restarted, rollout complete."""
    mock_q.confirm.return_value.ask.return_value = True
    mock_get_params.return_value = _full_params()
    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "--config",
            str(_enclave_config(tmp_path)),
            "enclave",
            "run",
            STACK,
            "--image-name",
            "new-image:v2",
            "--no-restart",  # Avoid health check complexity
        ],
    )
    assert result.exit_code == 0, result.output
    # Verify SSM write happened
    upsert_calls = {c[0][1]: c[0][2] for c in mock_upsert.call_args_list}
    assert upsert_calls.get("image_name") == "new-image:v2"
    assert "Restart skipped" in result.output


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
def test_run_dry_run_no_writes(
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """--dry-run: shows diff, no SSM writes, no lock acquired."""
    mock_get_params.return_value = _full_params()
    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "--config",
            str(_enclave_config(tmp_path)),
            "enclave",
            "run",
            STACK,
            "--image-name",
            "new-image:v2",
            "--dry-run",
        ],
    )
    assert result.exit_code == 0, result.output
    assert "Dry run" in result.output


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.upsert_param")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=["runtime/eif_s3_uri"])
@patch("exchange_keyshare.commands.enclave.acquire_lock", return_value=True)
@patch("exchange_keyshare.commands.enclave.release_lock")
@patch("exchange_keyshare.commands.enclave._get_caller_identity", return_value="test:user")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_run_preflight_failure_exits_nonzero(
    mock_q: MagicMock,
    _mock_identity: MagicMock,
    _mock_release: MagicMock,
    _mock_acquire: MagicMock,
    _mock_preflight: MagicMock,
    _mock_upsert: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """Missing required SSM params abort with exit code 1."""
    mock_q.confirm.return_value.ask.return_value = True
    mock_get_params.return_value = _full_params()
    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "--config",
            str(_enclave_config(tmp_path)),
            "enclave",
            "run",
            STACK,
            "--image-name",
            "new-image:v2",
        ],
    )
    assert result.exit_code == 1
    assert "Pre-flight failed" in result.output
    assert "eif_s3_uri" in result.output


@patch("exchange_keyshare.commands.enclave.get_lock_holder")
@patch("exchange_keyshare.commands.enclave.acquire_lock", return_value=False)
@patch("exchange_keyshare.commands.enclave._get_caller_identity", return_value="test:user")
def test_run_locked_aborts(
    _mock_identity: MagicMock,
    _mock_acquire: MagicMock,
    mock_holder: MagicMock,
    tmp_path: Path,
) -> None:
    """When another caller holds the lock, abort with helpful message."""
    from datetime import UTC, datetime

    mock_holder.return_value = ("other:user", datetime.now(UTC).isoformat(), "5678")

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "--config",
            str(_enclave_config(tmp_path)),
            "enclave",
            "run",
            STACK,
            "--image-name",
            "new-image:v2",
        ],
    )
    assert result.exit_code == 1
    assert "Locked by" in result.output
    assert "force-unlock" in result.output


def test_run_no_enclaves_configured(tmp_path: Path) -> None:
    """No enclave in config → exit 1 with helpful message."""
    path = tmp_path / "config.yaml"
    save_config(path, {})
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["--config", str(path), "enclave", "run", "any-stack"],
    )
    assert result.exit_code == 1
    assert "No enclave deployed" in result.output


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=[])
@patch("exchange_keyshare.commands.enclave.acquire_lock")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_run_status_no_flags_no_confirm_no_lock(
    mock_q: MagicMock,
    mock_acquire: MagicMock,
    _mock_preflight: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """Status-only: no questionary.confirm, no lock acquired, exit 0, hint shown."""
    mock_get_params.return_value = _full_params()
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["--config", str(_enclave_config(tmp_path)), "enclave", "run", STACK],
    )
    assert result.exit_code == 0, result.output
    mock_q.confirm.assert_not_called()
    mock_acquire.assert_not_called()
    assert "--restart" in result.output


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=["runtime/eif_s3_uri"])
def test_run_status_preflight_failure_informational(
    _mock_preflight: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """Preflight failure in status path is informational — exit 0, flag hint shown."""
    mock_get_params.return_value = _full_params()
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["--config", str(_enclave_config(tmp_path)), "enclave", "run", STACK],
    )
    assert result.exit_code == 0, result.output
    assert "--eif-s3-uri" in result.output
    assert "Pre-flight failed" not in result.output


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=[])
def test_run_status_hides_metadata_by_default(
    _mock_preflight: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """Without --verbose, deployed_at / deployed_by are hidden from status output."""
    params = _full_params()
    params["deployed_at"] = "2026-04-01T12:00:00+00:00"
    params["deployed_by"] = "assumed-role/ops"
    mock_get_params.return_value = params
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["--config", str(_enclave_config(tmp_path)), "enclave", "run", STACK],
    )
    assert result.exit_code == 0, result.output
    assert "Deployed At" not in result.output
    assert "Deployed By" not in result.output


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=[])
def test_run_verbose_shows_metadata(
    _mock_preflight: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """--verbose: deployed_at and deployed_by appear in status output."""
    params = _full_params()
    params["deployed_at"] = "2026-04-01T12:00:00+00:00"
    params["deployed_by"] = "assumed-role/ops"
    mock_get_params.return_value = params
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["--config", str(_enclave_config(tmp_path)), "enclave", "run", STACK, "--verbose"],
    )
    assert result.exit_code == 0, result.output
    assert "Deployed At" in result.output
    assert "Deployed By" in result.output


# ── --restart flag ────────────────────────────────────────────────────────────


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=[])
@patch("exchange_keyshare.commands.enclave.acquire_lock", return_value=True)
@patch("exchange_keyshare.commands.enclave.release_lock")
@patch("exchange_keyshare.commands.enclave._get_caller_identity", return_value="test:user")
@patch("exchange_keyshare.commands.enclave._do_restart")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_run_rollout_flag_confirm_and_restart(
    mock_q: MagicMock,
    mock_do_restart: MagicMock,
    _mock_identity: MagicMock,
    _mock_release: MagicMock,
    mock_acquire: MagicMock,
    _mock_preflight: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """--rollout: confirm shown, lock acquired, _do_restart called on yes."""
    mock_q.confirm.return_value.ask.return_value = True
    mock_get_params.return_value = _full_params()
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["--config", str(_enclave_config(tmp_path)), "enclave", "run", STACK, "--restart"],
    )
    assert result.exit_code == 0, result.output
    mock_q.confirm.assert_called_once()
    mock_do_restart.assert_called_once()
    mock_acquire.assert_called_once()


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=["runtime/eif_s3_uri"])
@patch("exchange_keyshare.commands.enclave.acquire_lock", return_value=True)
@patch("exchange_keyshare.commands.enclave.release_lock")
@patch("exchange_keyshare.commands.enclave._get_caller_identity", return_value="test:user")
@patch("exchange_keyshare.commands.enclave._do_restart")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_run_rollout_flag_preflight_failure(
    mock_q: MagicMock,
    mock_do_restart: MagicMock,
    _mock_identity: MagicMock,
    _mock_release: MagicMock,
    _mock_acquire: MagicMock,
    _mock_preflight: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """--rollout with missing required params: exit 1, no confirm, no restart."""
    mock_get_params.return_value = _full_params()
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["--config", str(_enclave_config(tmp_path)), "enclave", "run", STACK, "--restart"],
    )
    assert result.exit_code == 1
    assert "Cannot restart" in result.output
    mock_q.confirm.assert_not_called()
    mock_do_restart.assert_not_called()


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=[])
@patch("exchange_keyshare.commands.enclave.acquire_lock")
def test_run_restart_dry_run_no_lock(
    mock_acquire: MagicMock,
    _mock_preflight: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """--rollout --dry-run: no lock acquired, exit 0, dry run message shown."""
    mock_get_params.return_value = _full_params()
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["--config", str(_enclave_config(tmp_path)), "enclave", "run", STACK, "--restart", "--dry-run"],
    )
    assert result.exit_code == 0, result.output
    mock_acquire.assert_not_called()
    assert "Dry run" in result.output


# ── Credentials flags ─────────────────────────────────────────────────────────


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.upsert_param")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=[])
@patch("exchange_keyshare.commands.enclave.acquire_lock", return_value=True)
@patch("exchange_keyshare.commands.enclave.release_lock")
@patch("exchange_keyshare.commands.enclave._get_caller_identity", return_value="test:user")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_run_gm_user_password_flags_write_secure(
    mock_q: MagicMock,
    _mock_identity: MagicMock,
    _mock_release: MagicMock,
    _mock_acquire: MagicMock,
    _mock_preflight: MagicMock,
    mock_upsert: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """--gm-user and --gm-password write SecureString SSM params."""
    mock_q.confirm.return_value.ask.return_value = True
    mock_get_params.return_value = _full_params()
    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "--config",
            str(_enclave_config(tmp_path)),
            "enclave",
            "run",
            STACK,
            "--gm-user",
            "alice@example.com",
            "--gm-password",
            "s3cr3t",
            "--no-restart",
        ],
    )
    assert result.exit_code == 0, result.output
    secret_calls = {c[0][1]: c[1].get("secret", False) for c in mock_upsert.call_args_list}
    assert secret_calls.get("gm_user") is True
    assert secret_calls.get("gm_password") is True


@patch("exchange_keyshare.commands.enclave.get_runtime_params")
@patch("exchange_keyshare.commands.enclave.upsert_param")
@patch("exchange_keyshare.commands.enclave.validate_preflight", return_value=[])
@patch("exchange_keyshare.commands.enclave.acquire_lock", return_value=True)
@patch("exchange_keyshare.commands.enclave.release_lock")
@patch("exchange_keyshare.commands.enclave._get_caller_identity", return_value="test:user")
@patch("exchange_keyshare.commands.enclave.questionary")
def test_run_gm_credentials_from_env(
    mock_q: MagicMock,
    _mock_identity: MagicMock,
    _mock_release: MagicMock,
    _mock_acquire: MagicMock,
    _mock_preflight: MagicMock,
    mock_upsert: MagicMock,
    mock_get_params: MagicMock,
    tmp_path: Path,
) -> None:
    """ENCLAVE_GM_USER / ENCLAVE_GM_PASSWORD env vars are picked up automatically."""
    mock_q.confirm.return_value.ask.return_value = True
    mock_get_params.return_value = _full_params()
    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "--config",
            str(_enclave_config(tmp_path)),
            "enclave",
            "run",
            STACK,
            "--no-restart",
        ],
        env={"ENCLAVE_GM_USER": "env-user", "ENCLAVE_GM_PASSWORD": "env-pass"},
    )
    assert result.exit_code == 0, result.output
    upsert_keys = [c[0][1] for c in mock_upsert.call_args_list]
    assert "gm_user" in upsert_keys
    assert "gm_password" in upsert_keys


@patch("exchange_keyshare.commands.enclave.delete_stack_params")
@patch("exchange_keyshare.commands.enclave.start_stack_deletion")
@patch("exchange_keyshare.commands.enclave.poll_stack_deletion")
def test_teardown_cleans_ssm_params(
    mock_poll: MagicMock,
    mock_start: MagicMock,
    mock_delete_params: MagicMock,
    tmp_path: Path,
) -> None:
    """enclave teardown deletes all SSM params after CFN stack is gone."""
    from exchange_keyshare.cfn import StackProgress

    mock_cfn = MagicMock()
    mock_start.return_value = mock_cfn
    final = StackProgress(
        resources={}, stack_status="DELETE_COMPLETE", is_complete=True, is_failed=False
    )
    mock_poll.return_value = iter([final])
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["--config", str(_enclave_config(tmp_path)), "enclave", "teardown", STACK],
        input=f"{STACK}\n",
    )
    assert result.exit_code == 0, result.output
    mock_delete_params.assert_called_once_with(STACK, REGION)
