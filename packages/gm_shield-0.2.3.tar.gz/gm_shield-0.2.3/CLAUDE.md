# CLAUDE.md - gm-shield

CLI tool for market makers to securely share exchange API credentials.

## Tech Stack

- Python 3.12+, pyright strict mode
- Click (CLI), boto3 (AWS), rich (terminal UI), questionary (interactive prompts)
- uv (package manager)

## Project Structure

```
src/exchange_keyshare/
├── cli.py              # CLI entrypoint
├── config.py           # Config file (~/.config/gm-shield/config.yaml)
├── cfn.py              # CloudFormation polling helpers
├── setup.py            # Credentials stack creation
├── enclave.py          # Enclave stack creation
├── keys.py             # S3 credential operations
├── schema.py           # Credential validation
├── templates/
│   ├── credentials-stack.yaml  # CFN template: S3 bucket, KMS key, IAM role
│   └── enclave-stack.yaml      # CFN template: EC2 + Nitro Enclave
└── commands/
    ├── setup.py        # `setup` / `teardown` commands
    ├── teardown.py
    ├── config.py       # `config` command
    ├── keys.py         # `keys` subcommands
    └── enclave.py      # `enclave` subcommands
```

## Commands

```bash
gm-shield setup            # Deploy credentials stack (S3, KMS, IAM)
gm-shield teardown         # Delete credentials stack
gm-shield config           # Show current config

gm-shield keys list        # List credentials
gm-shield keys create      # Create credential (interactive)
gm-shield keys delete      # Delete credential
gm-shield keys update      # Update pairs/labels

gm-shield enclave approve  # Grant enclave access (add KMS/S3 policy)
gm-shield enclave revoke   # Revoke enclave access
gm-shield enclave rotate   # Rotate PCR attestation values
# hidden: enclave deploy / enclave teardown
```

## Configuration

`~/.config/gm-shield/config.yaml` — written by `setup`, read by all other commands.

Credentials stack fields: `bucket`, `region`, `stack_name`, `stack_id`, `kms_key_arn`

Enclave stack fields (`enclave` key): `stack_name`, `stack_id`, `region`, `role_arn`, `instance_profile_arn`, `host_ref`, `eip`, `labels`

Approved enclave fields (`approved_enclave` key): `role_arn`, `pcr8`, `pcr0` (optional), `approved_at`

Override path: `GM_SHIELD_CONFIG` env var. Region fallback: `AWS_REGION` / `AWS_DEFAULT_REGION`.

## CloudFormation Stacks

**credentials-stack.yaml** (`setup` / `teardown`):
- S3 bucket (versioned, KMS-encrypted, access logged) + KMS key (auto-rotating)
- `ConsumerAccessRole` — read-only IAM role for credential consumer (external ID required)
- `DeletionPolicy: Retain` on bucket and KMS key

**enclave-stack.yaml** (`enclave deploy` / `enclave teardown`):
- EC2 instance with Nitro Enclave enabled, static EIP, locked-down security group

**Enclave attestation:** `approve` adds KMS + S3 policy statements scoped to the enclave's IAM role and PCR values (PCR8 required, PCR0 optional).

## Credential Schema

Stored as YAML in S3 under `exchange-credentials/` prefix:

```yaml
version: "1"
exchange: binance  # binance, coinbase, kraken, kucoin, bitget, okx
credential:
  api_key: "..."
  api_secret: "..."
  passphrase: "..."  # required for coinbase, kucoin, bitget, okx
pairs:              # optional, BASE/QUOTE format
  - BTC/USDT
labels:             # optional
  - key: environment
    value: production
```

## Development

```bash
uv sync
uv run pytest
uv run pyright
uv run ruff check src/
```

## Worktrees

Use `.worktrees/` for feature branches (already in `.gitignore`).