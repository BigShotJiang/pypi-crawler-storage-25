#!/usr/bin/env python
"""
Command-line utility to display descriptions of d3dtools functionality.
"""

import argparse
import sys
import webbrowser
from textwrap import dedent

TOOL_DESCRIPTIONS = {
    'evaluate':
    """
        Calculate flood simulation accuracy and catch rate metrics.

        This tool compares simulated flood extent shapefiles with observed flood extent
        shapefiles to calculate accuracy and catch rate metrics, which are important for
        validating flood model performance.

        Examples:
            evaluate --sim SHP/SIM.shp --obs SHP/OBS.shp
            evaluate --sim SHP/SIM.shp --obs SHP/OBS.shp --output results.csv
    """,
    'evaluate_sensor':
    """
        Evaluate flood simulation accuracy and recall using sensor data.

        This tool compares simulated flood extent shapefiles with observed flood extent
        shapefiles to calculate accuracy and recall metrics, which are important for
        validating flood model performance.

        Examples:
            evaluate_sensor --sim SHP/SIM.shp --obs SHP/OBS.shp
            evaluate_sensor --sim SHP/SIM.shp --obs SHP/OBS.shp --buffer 50 --threshold 20
            evaluate_sensor --sim SHP/SIM.shp --obs SHP/OBS.shp --output results.csv
    """,
    'evaluate_sensor2':
    """
        Evaluate flood simulation accuracy using sensor data with dual-threshold shapefiles.

        This tool compares two simulated flood extent shapefiles (low and high depth threshold)
        with observed sensor point data to calculate accuracy and recall metrics. TP/FN are
        determined against the low-threshold simulation; FP/TN against the high-threshold one.

        Examples:
            evaluate_sensor2 --sim-low SHP/SIM_thrd125.shp --sim-high SHP/SIM_thrd475.shp --obs SHP/OBS_SENSOR.shp
            evaluate_sensor2 --sim-low SHP/SIM_thrd125.shp --sim-high SHP/SIM_thrd475.shp --obs SHP/OBS_SENSOR.shp --buffer 50 --threshold 20
            evaluate_sensor2 --sim-low SHP/SIM_thrd125.shp --sim-high SHP/SIM_thrd475.shp --obs SHP/OBS_SENSOR.shp --output results.csv
    """,
    'sensor':
    """
        Extract time series data at observation points from Delft3D FM NetCDF files.

        This tool extracts water depth or other parameters at specified observation points
        from Delft3D FM NetCDF output files and exports the results to CSV and/or Excel.

        Examples:
            sensor --nc-file results.nc --obs-shp observation_points.shp
            sensor --nc-file results.nc --obs-shp points.shp --output-csv depth.csv
            sensor --nc-file results.nc --obs-shp points.shp --plot --verbose
    """,
    'ncrain':
    """
        Generate a NetCDF file from rainfall data and thiessen polygon shapefiles.

        This tool processes rainfall data in CSV format along with thiessen polygon
        shapefiles to create NetCDF files for use in Delft3D modeling.

        Note: Currently only works for Taiwan data in EPSG:3826 projection.

        Examples:
            ncrain                      # Process all CSV files in the input folder
            ncrain --single rainfall.csv  # Process only a specific CSV file
            ncrain --verbose            # Display additional processing information
            ncrain --no-clean           # Keep intermediate files
    """,
    'snorain':
    """
        Process rainfall scenario data and generate time series CSV files.

        This tool processes rainfall scenario data from CSV files and generates
        time series files for use in modeling.

        Examples:
            snorain -i rainfall_scenarios.csv -o custom/TAB
            snorain --input rainfall_scenarios.csv --output custom/TAB --verbose
    """,
    'shp2ldb':
    """
        Convert boundary line shapefiles to LDB files for Delft3D.

        This tool converts boundary line shapefiles to the LDB format used in
        Delft3D modeling.

        Examples:
            shp2ldb
            shp2ldb -i custom/SHP_LDB -o custom/LDB
            shp2ldb --id_field BoundaryName
    """,
    'shpbc2pli':
    """
        Convert boundary line shapefiles to PLI files for Delft3D.

        This tool converts boundary line shapefiles to the PLI format used in
        Delft3D modeling.

        Examples:
            shpbc2pli
            shpbc2pli -i custom/SHP_BC -o custom/PLI_BC
            shpbc2pli --id_field BoundaryName
    """,
    'shp2pli':
    """
        Alias for shpbc2pli. Convert boundary line shapefiles to PLI files.

        Examples:
            shp2pli
            shp2pli -i custom/SHP_BC -o custom/PLI_BC
    """,
    'shpblock2pol':
    """
        Convert shapefile blocks to POL files for Delft3D.

        This tool converts polygon shapefiles to the POL format used in
        Delft3D modeling.

        Examples:
            shpblock2pol
            shpblock2pol -i custom/SHP_BLOCK -o custom/POL_BLOCK
    """,
    'shp2pol':
    """
        Alias for shpblock2pol. Convert shapefile blocks to POL files.

        Examples:
            shp2pol
            shp2pol -i custom/SHP_BLOCK -o custom/POL_BLOCK
    """,
    'shpdike2pliz':
    """
        Convert bankline shapefiles to PLIZ files for Delft3D.

        This tool converts bankline/dike shapefiles to the PLIZ format used in
        Delft3D modeling.

        Examples:
            shpdike2pliz
            shpdike2pliz -i custom/SHP_DIKE -o custom/PLIZ_DIKE
            shpdike2pliz --id_field DikeName
    """,
    'shp2pliz':
    """
        Alias for shpdike2pliz. Convert bankline shapefiles to PLIZ files.

        Examples:
            shp2pliz
            shp2pliz -i custom/SHP_DIKE -o custom/PLIZ_DIKE
    """,
    'shp2xyz':
    """
        Convert point shapefiles to XYZ files.

        This tool converts point shapefiles to XYZ files for use in Delft3D modeling.

        Examples:
            shp2xyz
            shp2xyz -i custom/SHP_SAMPLE -o custom/XYZ_SAMPLE
            shp2xyz --z_field ELEVATION
    """,
    'getfacez':
    """
        Extract Mesh2d_face_z values from Delft3D FM NetCDF files at observation points.

        This tool extracts bed level/bathymetry values (Mesh2d_face_z) at specified observation
        points from Delft3D FM NetCDF output files and exports the results to CSV and/or Excel.

        Examples:
            getfacez --nc-file results.nc --obs-shp observation_points.shp
            getfacez --nc-file results.nc --obs-shp points.shp --output-csv bathymetry.csv
            getfacez --nc-file results.nc --obs-shp points.shp --output-excel bathymetry.xlsx --verbose
    """,
    'fou2shp':
    """
        Reconstruct FlowFM 2D mesh faces as polygons in threshold shapefiles from FOU NetCDF output.

        This tool reads a Delft3D FM fourier/statistics NetCDF file, extracts 2D mesh face
        polygons with depth values, and writes multiple threshold-based shapefiles (e.g.,
        SIM_thrd125, SIM_thrd300, SIM_thrd475) to an output directory.

        Examples:
            fou2shp
            fou2shp --input NC/FlowFM_fou.nc --out-dir SHP
            fou2shp --input NC/FlowFM_fou.nc --var Mesh2d_fourier002_max_depth --out-dir output
    """,
    'pliz2shp':
    """
        Convert Delft3D PLIZ files to ESRI Shapefiles.

        This tool reads all *.pliz files from an input folder and converts each polyline
        (with Z values) to a shapefile in the output folder.

        Examples:
            pliz2shp
            pliz2shp -i custom/PLIZ -o custom/SHP
    """,
    'rmgrid':
    """
        Remove (clear) the 2D computational mesh and 1D2D links from a D-Flow FM .dsproj project.

        This tool empties the 2D mesh in the project's NetCDF net file while preserving the
        1D network (pipes/branches). It also strips any 2D-specific sections from the
        IniFieldFile. The original net file is backed up as <name>.nc.bak so the change can
        be reverted with --restore.

        Examples:
            rmgrid
            rmgrid -i MyProject.dsproj
            rmgrid -i MyProject.dsproj --restore
            rmgrid -i MyProject.dsproj --force-backup
    """
}


def _build_tool_listing():
    """Build the formatted listing of all available tools."""
    lines = [
        "D3DTOOLS - A collection of tools for working with shapefiles and converting them for Delft3D modeling.",
        "",
        "Available tools:",
        "",
    ]
    for tool, description in TOOL_DESCRIPTIONS.items():
        short_desc = description.strip().split('\n')[0]
        lines.append(f"  {tool:<18} - {short_desc}")
    lines.append("")
    lines.append("Use 'd3dtools <tool_name>' to get detailed information about a specific tool.")
    lines.append("Use '<tool_name> --help' to see command-line options for each tool.")
    return "\n".join(lines)


def main():
    """Main function to display tool descriptions."""
    parser = argparse.ArgumentParser(
        prog='d3dtools',
        description='Display descriptions of d3dtools functionality.',
        epilog=_build_tool_listing(),
        formatter_class=argparse.RawDescriptionHelpFormatter)

    parser.add_argument('tool',
                        nargs='?',
                        choices=[*TOOL_DESCRIPTIONS.keys(), 'all'],
                        default='all',
                        help='The specific tool to describe (default: all)')

    parser.add_argument('--version',
                        action='store_true',
                        help='Show the d3dtools version')

    parser.add_argument('--pypi',
                        action='store_true',
                        help='Open the d3dtools PyPI project page in a web browser')

    args = parser.parse_args()

    if args.version:
        from . import __version__
        print(f"d3dtools version {__version__}")
        return

    if args.pypi:
        print("Opening d3dtools PyPI project page in your web browser...")
        webbrowser.open("https://pypi.org/project/d3dtools/")
        return

    if args.tool == 'all':
        print(_build_tool_listing())
    else:
        print(dedent(TOOL_DESCRIPTIONS[args.tool]).strip())
        print(f"\nUse '{args.tool} --help' to see all command-line options.\n")


if __name__ == "__main__":
    main()
