import os
import re
import subprocess
from typing import List
from .dcmi import dcmi

class UrmaDevice:
    def __init__(self, name, product_type = "server"):
        self.name = name
        self.product_type = product_type
        self.eid_list = []

    @staticmethod
    def get_phy_port_by_eid(eid) -> int:
        """
        获取EID的物理口编号, 有效的编号是1-9,不区分硬件形态
        """
        last = eid[-2:]
        h = int(last, 16)
        p = ((~128) & h) >> 3
        return p

    def get_pg_eid(self):
        for eid in self.eid_list:
            # NPU的物理口编号为0-9
            if self.get_phy_port_by_eid(eid) > 9:
                return eid
        raise ValueError(f"Failed to find PG EID for {self.name}")
    
    @staticmethod
    def get_server_die_id_by_eid(eid) -> int:
        h = int(eid[-2], 16)
        die_id = (8 & h) >> 3
        return die_id

    @staticmethod
    def get_pod_die_id_by_eid(eid) -> int:
        h = int(eid[-3], 16)
        die_id = (4 & h) >> 2
        return die_id
    
    def is_uboe(self):
        """
        判断是否为UBOE设备
        """
        if len(self.eid_list) == 0:
            return False
        bits = int(self.eid_list[0][13], 16)
        return (8 & bits) != 0
    
    def get_uboe_ip(self):
        """
        获取UBOE设备的IP地址
        """
        if not self.is_uboe():
            raise ValueError(f"{self.name} is not a UBOE device")
        for eid in  self.eid_list:
            ip = eid[-8:]
            if ip.startswith("fe"):
                continue
            return f"{int(ip[0:2],16)}.{int(ip[2:4],16)}.{int(ip[4:6],16)}.{int(ip[6:8],16)}"
        
    def get_die_id(self):
        eid = self.eid_list[0]
        try:
            eid = self.get_pg_eid()
        except:
            pass
        if self.product_type == "server":
            die_id = self.get_server_die_id_by_eid(eid)
        elif self.product_type == "pod":
            die_id = self.get_pod_die_id_by_eid(eid)
        else:
            raise ValueError(f"Unknown product type: {product_type}")
        return die_id
    
    def get_fe_id(self):
        bits = int(self.eid_list[0][13:15], 16)
        fe_id = (126 & bits) >> 1
        return fe_id

def parse_urma_device_list(output, product_type) -> List[UrmaDevice]:
    urma_device_list = []
    lines = output.strip().splitlines()
    start = False
    for line in lines:
        if re.match(r".*?Name.*?EID Index.*?EID", line):
            start = True
            continue
        if start:
            result = re.findall(r'[^\|\s]+', line)
            if len(result) == 3:
                eid = result[2].replace(":", "")
                if len(eid) < 8: # 无效EID,  UBOE在未配置EID时为NA
                    continue
                urma_device_list.append(UrmaDevice(result[0], product_type))
                urma_device_list[-1].eid_list.append(eid)
            elif len(result) == 2:
                eid = result[1].replace(":", "")
                urma_device_list[-1].eid_list.append(eid)

    return urma_device_list

def get_urma_device_list_by_dcmi(npu_id, product_type):
    urma_device_list = []
    urma_device_count = dcmi.get_urma_device_cnt_v2(npu_id)
    for i in range(urma_device_count):
        try:
            urma_device = UrmaDevice(f"udma{i}", product_type)
            eids = dcmi.get_eid_list_by_urma_dev_index_v2(npu_id, i)
            if (len(eids) == 0):
                # UBOE使用的urmadevice在未配置eid之前是空的
                continue
            urma_device.eid_list.extend([e for e in eids])
            urma_device_list.append(urma_device)
        except Exception as e:
            raise(e)
    return urma_device_list

def get_urma_device_list_by_hccl_tool(npu_id, product_type):
    output = subprocess.check_output(f"hccn_tool -g -dev_info -i {npu_id}", shell=True).decode().strip()
    urma_device_list = parse_urma_device_list(output, product_type)
    return urma_device_list

def get_urma_device_list(npu_id, product_type="server"):
    urma_device_list = []
    try:
        urma_device_list = get_urma_device_list_by_dcmi(npu_id, product_type)
        print(f"NPU[{npu_id}] get urma device list by dcmi success")
    except Exception as e:
        print(f"call dcmi failed:{e}")
        urma_device_list = get_urma_device_list_by_hccl_tool(npu_id, product_type)
        print(f"NPU[{npu_id}] get urma device list by hccn_tool success")
    return urma_device_list

if __name__ == '__main__':
    output = """
+------------------------+---------------+-------------------------------------------+
| Name                   | EID Index     | EID                                       |
+------------------------+---------------+-------------------------------------------+
| udma1                  | 0             | 0000:0000:0000:0000:0000:0000:0000:0000   |
|                        | 1             | 0000:0000:0000:0000:0000:0000:0000:0000   |
|                        | 2             | 0000:0000:0000:0000:0000:0000:0000:0000   |
|                        | 3             | 0000:0000:0000:0000:0000:0000:0000:0000   |
+------------------------+------------------+-------------------------------------------+
| udma2                  | 0             | 0000:0000:0000:0000:0000:0000:0000:1000   |
|                        | 1             | 0000:0000:0000:0000:0000:0000:0000:0200   |
|                        | 2             | 0000:0000:0000:0000:0000:0000:0000:0030   |
|                        | 3             | 0000:0000:0000:0000:0000:0000:0000:0004   |
|                        | 4             | 0000:0000:0000:0000:0000:0000:0000:0004   |
+------------------------+------------------+-------------------------------------------+
"""
    urma_dev_list = parse_urma_device_list(output)
    for i in urma_dev_list:
        print(i.name, i.eid_list)