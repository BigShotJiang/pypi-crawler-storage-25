import os
import platform
import re

def get_server_unique_id() -> str:
    """
    基于 Linux 网卡 MAC 地址获取服务器唯一标识
    返回值: (格式化的MAC字符串/None, 获取说明)
    """
    # 2. 定义 MAC 地址正则（匹配 xx:xx:xx:xx:xx:xx 格式）
    mac_pattern = re.compile(r"([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}")

    # 方案1：读取 /sys/class/net/ 目录（推荐，无需执行外部命令）
    net_path = "/sys/class/net/"
    if not os.path.exists(net_path):
        raise Exception("not network")

    for iface in os.listdir(net_path):
        if iface in ["lo"] or iface.startswith(("v", "docker", "tap", "tun")):
            continue
        # 读取网卡 MAC 地址文件
        addr_path = os.path.join(net_path, iface, "address")
        if os.path.exists(addr_path):
            try:
                with open(addr_path, "r", encoding="utf-8") as f:
                    mac = f.read().strip().lower()
                # 验证 MAC 格式有效性（排除全0等无效MAC）
                if mac_pattern.match(mac) and mac != "00:00:00:00:00:00":
                    return "".join(mac.split(":"))
            except (PermissionError, IOError):
                continue
