from typing import List
from .config import ConfigMgr
from .dcmi import dcmi
from .topo import TopoSingleFactory
from .npu import NPU, EID, IP, process_roce
from .tool import get_server_unique_id
from .urma_device import UrmaDevice, get_urma_device_list

def get_eid_port(eid):
    last = eid[-2:]
    h = int(last, 16)
    p = ((~128) & h) >> 3
    return p

def get_eid_die_id(eid):
    low = eid[-2]
    die_id = 8 & int(low, 16)
    return die_id >> 3

def process_level0(npu):
    topo = TopoSingleFactory.get_topo()
    #for eid in npu.addr_list:
    max_fe = 0
    mesh_dev = None
    for urma_dev in npu.urma_dev_list:
        try:
            fe = urma_dev.get_fe_id()
            die_id = urma_dev.get_die_id()
        except Exception:
            continue
        if die_id == 0:
            # 服务器使用1die组mesh
            continue
        if fe > max_fe:
            max_fe = fe
            mesh_dev = urma_dev
    
    for eid in mesh_dev.eid_list:
        p = get_eid_port(eid)
        if p > 9:
            # EID中获取到的port id为1-9
            continue
        die_id = get_eid_die_id(eid)
        ports = [f"{die_id}/{p - 1}"]  # 需要-1映射到0-8
        plane_id = f"plane_{die_id}"
        npu.level(0).append(EID(eid, ports, plane_id))

    #server_id = get_server_unique_id()
    sp_id = ConfigMgr().get("super_pod_id")
    server_index = ConfigMgr().get("server_index")
    # 标卡每4个卡在同一个mesh链接，因此每4个卡的net_instance_id相同
    npu.level(0).net_instance_id = f"sp_{sp_id}_srv_{server_index}"


def get_level1_config():
    """
    获取端口规则 (die_id, fe_id, (ports))
    """
    mainboard_id = ConfigMgr().get("mainboard_id")
    if mainboard_id == 35: # 2+4 服务器
        return [(0, 3,(4,5,6,7)), (1, 2, (5,6))]
    if mainboard_id in (37, 39):
        return [(0, 3, (1,2,3,4,5,6,7,8))]

def process_level1(npu):
    configs = get_level1_config()
    for urma_dev in npu.urma_dev_list:
        fe_id = urma_dev.get_fe_id()
        try:
            die_id = urma_dev.get_die_id()
            eid = urma_dev.get_pg_eid()
        except Exception:
            continue
        for target_die, target_fe, ports in configs:
            if die_id == target_die and fe_id == target_fe:
                port_list = [f"{die_id}/{p}" for p in ports]
                plane_id = f"plane_{die_id}"
                npu.level(1).append(EID(eid, port_list, plane_id))

    npu.level(1).net_instance_id = f"""superpod_{ConfigMgr().get("super_pod_id")}"""

def process_level2(npu):
    configs = get_level1_config()
    for urma_dev in npu.urma_dev_list:
        try:
            ip = urma_dev.get_uboe_ip()
            npu.level(2).append(IP(ip, "plane_uboe", ["0/8"]))
            npu.level(2).net_instance_id = "cluster"
            return
        except Exception:
            continue

def process_npu_for_server(npu):
    max_level = int(ConfigMgr().get("max_level"))
    levels = TopoSingleFactory.get_topo().get_level_list()[:max_level]
    for level in levels:
        if level == 0:
            process_level0(npu)
        if level == 1:
            process_level1(npu)
        if level == 2:
            process_level2(npu)
        if level == 3:
            process_roce(npu, level)

def process_rootinfo_server(rootinfo):
    for npu in rootinfo.rank_list:
        try:
            npu.urma_dev_list = get_urma_device_list(npu.npu_id, "server")
            process_npu_for_server(npu)
        except Exception as e:
            print(e)