# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import ssl
import tomllib
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

import httpx
from click import ClickException
from pydantic import BaseModel, Field
from xdg_base_dirs import xdg_config_dirs, xdg_config_home

from . import util
from .model import XtaIdentifier


class Config(BaseModel):
    base_url: str = "https://localhost:8443"
    management_port_path: str = "/services/XTAService/ManagementPort"
    msg_box_port_path: str = "/services/XTAService/MsgBoxPort"
    send_port_path: str = "/services/XTAService/SendXtaPort"
    verify: bool = True
    cafile: str = "ca.crt"
    certfile: str = "tls.crt"
    keyfile: str = "tls.key"
    self_identifier: XtaIdentifier = XtaIdentifier(value="*")
    user_agent: str = "Apache-CXF/4.0.7"
    verbose: bool = False
    max_save_base64_size: int = 1 << 20  # 1 MiB
    max_response_envelope_size: int = 10 << 20  # 10 MiB
    max_list_items: int = 100
    extra_config_path: Optional[Path] = Field(default=None, exclude=True)

    @property
    def management_port_url(self):
        return self.base_url + self.management_port_path

    @property
    def msg_box_port_url(self):
        return self.base_url + self.msg_box_port_path

    @property
    def send_port_url(self):
        return self.base_url + self.send_port_path

    @property
    def cafile_path(self) -> Optional[Path]:
        return self._find_in_config_directory(self.cafile)

    @property
    def certfile_path(self) -> Optional[Path]:
        return self._find_in_config_directory(self.certfile)

    @property
    def keyfile_path(self) -> Optional[Path]:
        return self._find_in_config_directory(self.keyfile)

    def _find_in_config_directory(self, name: str) -> Optional[Path]:
        if not name:
            return None
        candiates = [
            config_path.parent / name
            for config_path in _xta_config_files(self.extra_config_path)
        ]
        for candidate in reversed(candiates):
            if candidate.is_file():
                return candidate


def _xta_config_files(extra: Optional[Path]):
    return [config_dir / "config.toml" for config_dir in _xta_config_dirs(extra)] + (
        [extra] if extra is not None and extra.is_file() else []
    )


def _xta_config_dirs(extra: Optional[Path]) -> list[Path]:
    return [
        base_dir / "xta"
        for base_dir in xdg_config_dirs() + [xdg_config_home()]
        if base_dir.is_dir()
    ] + ([extra] if extra is not None and extra.is_dir() else [])


CONFIG: Config | None = None

LOADED_CONFIG_FILES: list[Path] = []


def get_config() -> Config:
    if CONFIG is None:
        raise RuntimeError("init_global_config not called?")
    return CONFIG


def init_global_config(extra_config_path: Optional[Path], profiles: str):
    global CONFIG
    LOADED_CONFIG_FILES.clear()

    profile_names = [""] + [
        profile_str.strip()
        for profile_str in profiles.split(",")
        if profile_str.strip()
    ]
    config_file_paths = [
        _to_profile_path(base_path, profile)
        for profile in profile_names
        for base_path in _xta_config_files(extra_config_path)
    ]
    config_dict = dict()
    for config_path in config_file_paths:
        config_dict = util.merge_dict(
            config_dict,
            _load_toml_config(config_path),
        )
    CONFIG = Config(**config_dict, extra_config_path=extra_config_path)


def _load_toml_config(config_path: Path):
    LOADED_CONFIG_FILES.append(config_path.absolute())
    if config_path.is_file():
        with open(config_path, "rb") as file:
            try:
                return util.translate_dict_to_snake_case(tomllib.load(file))
            except tomllib.TOMLDecodeError as e:
                raise ClickException(f"Failed to load toml config '{config_path}! {e}")
    return dict()


def _to_profile_path(config_path: Path, profile: str) -> Path:
    if not profile:
        return config_path
    name = config_path.name
    suffix = ""
    parts = name.rsplit(".", 1)
    if len(parts) == 2:
        name, extension = parts
        suffix = f".{extension}"
    return config_path.parent / f"{name}-{profile}{suffix}"


@contextmanager
def create_http_client():
    cfg = get_config()
    ctx = ssl.create_default_context(cafile=cfg.cafile_path)
    ctx.verify_mode = (
        ssl.VerifyMode.CERT_REQUIRED if cfg.verify else ssl.VerifyMode.CERT_NONE
    )
    if cfg.certfile_path:
        ctx.load_cert_chain(certfile=cfg.certfile_path, keyfile=cfg.keyfile_path)
    with httpx.Client(verify=ctx) as client:
        yield client
