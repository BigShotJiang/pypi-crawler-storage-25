# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import click
import httpx
from click import ClickException

from . import config as cfg
from . import file, soap
from .model import XtaFile, XtaMessage, XtaMetadata, XtaTransportReport


@dataclass
class XtaClient:
    client: httpx.Client
    config: cfg.Config
    output_directory: Optional[Path]

    def new(self) -> str:
        resp = self._request(self._prepare_new())
        return resp.text("{*}Body/{*}MessageID")

    def _prepare_new(self) -> soap.XtaSoapRequest:
        return soap.XtaSoapRequest(
            url=self.config.management_port_url,
            action="http://www.xta.de/XTA/CreateMessageID",
            header_template="Author.xml",
            context=self._config_context(),
        )

    def send(self, message: XtaMessage):
        self._request(self._prepare_send(message))

    def _prepare_send(self, message: XtaMessage) -> soap.XtaSoapRequest:
        context = self._prepare_send_context(message)
        return soap.XtaSoapRequest(
            url=self.config.send_port_url,
            action="http://www.xta.de/XTA/SendMessage",
            header_template="MessageMetaData.xml",
            body_template="GenericContentContainer.xml",
            attachments=self._prepare_send_attachments(message, context),
            context=context,
        )

    def _prepare_send_attachments(
        self, message: XtaMessage, context: dict
    ) -> list[soap.AttachmentResource]:
        return [
            self._prepare_file(xta_file, message.source_directory, context)
            for xta_file in [message.message] + message.attachments
        ]

    def _prepare_file(
        self, xta_file: XtaFile, source_directory: Optional[Path], context: dict
    ) -> soap.AttachmentResource:
        return soap.AttachmentResource(
            content_id=xta_file.content_id,
            content=file.load_xta_file_content(
                xta_file.content, source_directory, context
            ),
        )

    def _prepare_send_context(self, message: XtaMessage) -> dict:
        return {**message.model_dump(), **self._config_context()}

    def get(self, message_id: str) -> XtaMessage:
        resp = self._request(self._prepare_get(message_id))
        xta_message = self._map_xta_message(resp)
        return file.save_xta_message(
            xta_message, resp.attachments, self.config.max_save_base64_size
        )

    def _prepare_get(self, message_id: str) -> soap.XtaSoapRequest:
        return soap.XtaSoapRequest(
            url=self.config.msg_box_port_url,
            action="http://www.osci.eu/ws/2008/05/transport/urn/messageTypes/MsgBoxFetchRequest",
            header_template="Author.xml",
            body_template="MsgBoxFetchRequest.xml",
            context=self._prepare_get_context(message_id),
        )

    def _prepare_get_context(self, message_id: str):
        return {"config": cfg.get_config(), "message_id": message_id}

    def _map_xta_message(self, resp: soap.IncomingSoapMessage) -> XtaMessage:
        return XtaMessage.from_xml(
            resp.select("{*}Header/{*}MessageMetaData"),
            resp.select("{*}Body/{*}GenericContentContainer"),
            (
                self.output_directory / "xta-message.yaml"
                if self.output_directory
                else None
            ),
        )

    def ls(self) -> list[XtaMetadata]:
        resp = self._request(self._prepare_ls())
        body = resp.select("{*}Body/{*}MsgStatusList")
        return [
            XtaMetadata.from_xml(metadata_element)
            for metadata_element in body.findall("{*}MessageMetaData")
        ]

    def _prepare_ls(self):
        return soap.XtaSoapRequest(
            url=self.config.msg_box_port_url,
            action="http://www.osci.eu/ws/2008/05/transport/urn/messageTypes/MsgBoxStatusListRequest",
            header_template="Author.xml",
            body_template="MsgBoxStatusListRequest.xml",
            context=self._prepare_ls_context(),
        )

    def _prepare_ls_context(self):
        return {"config": cfg.get_config()}

    def inspect(self, message_id: str) -> XtaTransportReport:
        resp = self._request(self._prepare_inspect(message_id))
        report_element = resp.select("{*}Body/{*}TransportReport")
        return XtaTransportReport.from_xml(report_element)

    def _prepare_inspect(self, message_id: str) -> soap.XtaSoapRequest:
        return soap.XtaSoapRequest(
            url=self.config.management_port_url,
            action="http://www.xta.de/XTA/GetTransportReport",
            header_template="Author.xml",
            body_template="MessageID.xml",
            context=self._config_and_message_id_context(message_id),
        )

    def close(self, message_id: str):
        self._request(self._prepare_close(message_id))

    def _prepare_close(self, message_id: str) -> soap.XtaSoapRequest:
        return soap.XtaSoapRequest(
            url=self.config.msg_box_port_url,
            action="http://www.osci.eu/ws/2008/05/transport/urn/messageTypes/MsgBoxCloseRequest",
            header_template="Author.xml",
            body_template="MsgBoxCloseRequest.xml",
            context=self._config_and_message_id_context(message_id),
        )

    def _config_and_message_id_context(self, message_id):
        return {**self._config_context(), "message_id": message_id}

    def _config_context(self):
        return {"config": self.config}

    def _request(self, soap_request: soap.XtaSoapRequest) -> soap.IncomingSoapMessage:
        request = soap_request.prepare()
        request.headers["User-Agent"] = self.config.user_agent

        # send request
        try:
            http_response = self.client.send(request, stream=True)
        except httpx.RequestError as e:
            raise ClickException(f"{e} - [{request.method}] {request.url}")

        # process response
        if self.config.verbose:
            header_lines = "\n".join(
                f"{key}: {value}" for key, value in http_response.headers.items()
            )
            click.echo(f"{header_lines}\n", err=True)
        soap_response = soap.receive(
            http_response.headers.get("content-type", ""),
            http_response.iter_bytes(),
            self.config.max_response_envelope_size,
        )

        if self.config.verbose:
            click.echo(soap_response.envelope_xml + "\n", err=True)

        # handle fault response
        if soap_response.fault:
            raise soap.SoapError(soap_response.fault)
        try:
            http_response.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise ClickException(f"{e} - [{request.method}] {request.url}")

        return soap_response


@contextmanager
def create_xta_client(output_directory: Optional[Path] = None):
    with cfg.create_http_client() as client:
        yield XtaClient(client, cfg.get_config(), output_directory)
