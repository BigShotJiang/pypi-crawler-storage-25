#
# This file is part of the reVote distribution (https://codeberg.org/Boeingflieger/reVote).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

# Rack

# "." relative import with parent package
from .ttyRevox import ttyRevox

import logging
logger = logging.getLogger( __name__)

#
#
#

class Rack ( ttyRevox):

    # ...
    # 4 b'400\r\n'
    # 5 b'500\r\n'
    # 6 b'600\r\n'
    # 7 b'700\r\n'
    # 8 b'800\r\n'
    # 9 b'\x07\r\n'   <- parallel

    def scan ( self, channels = [ 0, 1, 2, 3, 4, 5, 6, 7, 8]):
        logger.info( "scan")

        slots = [ ]

        ID = [ "n/a",  "PR99 MKII", "A725", "B285", "B215", "B225-2", "B226", "A725-2", "B291"]

        for channel in channels:
            if isinstance( channel, tuple):

                if 1 == len(channel):
                    pass
                elif 2 == len(channel):
                    slots.append( channel + ( True, ))
                elif 3 == len(channel):
                    slots.append( channel)
                else:
                    pass
            else:
                res = self.command( f"{channel}X", True)
                print( res)

                id = int( res[1:3])

                if 50 <= id:
                    logger.info( f"channel {channel} {'B203'}")
                    slots.append( ( channel, 'B203', True))
                elif 0 != id:
                    logger.info( f"channel {channel} {ID[id]}")
                    slots.append( ( channel, ID[id], True))
                else:
                    logger.info( f"channel {channel} {ID[id]}")

        return slots

    #
    #
    #

    def sync ( self, date, time):
        # version = int( res[ 1: 3])
        # date_dd = int( res[ 3: 5])
        # date_mm = int( res[ 5: 7])
        # date_yy = int( res[ 7: 9])
        # time_hh = int( res[ 9:11])
        # time_mm = int( res[11:13])
        # time_ss = int( res[13:15])
        # lang    = int( res[15:16])
        # easy    = int( res[16:17])
        # timer   = int( res[17:18])
        # speaker = int( res[18:19])
        # ir_rcvr = int( res[19:20])

        # dt = datetime.now( )
        #
        # date = dt.strftime( "0D%d%m%y")
        # time = dt.strftime( "0T%H%M%S")

        # TODO: Actually this would be part of a B203 component, not of the rack object.
        res = self.command( f"0X", True)
        print( res)
        print( res[ 3: 9])
        print( date[ 2: ].encode( encoding="ascii"))

        if date[ 2: ].encode( encoding="ascii") != res[ 3: 9]:
            logger.info( "autosync")

            # command: 0D241025 response: 0 b''
            # command: 0T230532 response: 0 b''
            self.command( date)
            self.command( time)

            # Command
            # #            0Eaabcccccccdeeffffgggggghhhhhh
            # ser.write( b'0E01W11111111000010070000080000\r')

            # settings.ini
            # E01=W11111111000010070000080000

            # Response
            # b'05001W11111111000010070000080000\r\n'
            # b'05002E\r\n'
            # b'05003E\r\n'
            # b'05004E\r\n'
            # b'05005E\r\n'

            # for n in range( 1, 6):
            #     self.command( f"0E{n:0>2}{app.revox_config.get( 'B203', f'E{n:0>2}', fallback='E')}")

        return

#
#
#
