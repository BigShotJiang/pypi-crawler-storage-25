#
# This file is part of the reVote distribution (https://codeberg.org/Boeingflieger/reVote).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

# Serielle Kommunikation mit Revox B 203

# pySerial
# https://pyserial.readthedocs.io/en/latest/pyserial.html
import serial
import threading

import logging
logger = logging.getLogger( __name__)

#
#
#

class ttyRevox:

    #
    #
    #

    def __init__ ( self, port):
        self.lock = threading.Lock( )

        self.device = serial.Serial( )

        # studer-revox_b203_techinfo.pdf
        # 1.5 RS 232 Interface
        # Full-duplex, 3 wire connection (GND, Tx, Rx)
        # 1200 baud, 1 start bit, 1 stop bit, 8 data bits, no parity bit.
        # Software handshaking (Xon, Xoff)
        self.device.baudrate = 1200
        self.device.port = port
        self.device.bytesize = 8
        self.device.parity = 'N'
        self.device.stopbits = 1
        self.device.timeout = 2 # seconds
        self.device.xonxoff = 1
        self.device.rtscts = 0

        try:
            self.device.open( )

            if self.device.is_open:
                self.device.reset_input_buffer( )
            # else:
            #     logger.critical( f"cannot open {self.device.port}.")
            #     exit( )

        # except serial.SerialException as e:
        # except IOError as e:
        except Exception as e:
            print( type( e))
            print( e)


    #
    #
    #

    def __del__ ( self):
        if self.device is not None:
            self.device.close( )

    #
    #
    #

    # 1.5.3 Feedback format
    # A. Channel number (1st string segment)
    #
    # 0-9 ist in Verwendung. Blieben uns A-F bzw. alle Buchstaben.
    #
    # B. Device identifier (2nd and 3rd segment)
    #
    # 00-08 sowie 50-99, wobei 55 das höchste ist was ich gesehen habe.
    #
    # Sowie 000, da der B203 niemals eine "unit without repsonse" sein kann.
    #
    # Ich nehme channel F für Fehlermeldungen und device nn ist dann die Fehlernummer.
    #
    # F00  empty response
    # F01  incomplete response
    # F02  channel mismatch
    # F03  exception
    # F07  invalid command (BEL)

    def command ( self, data, has_response = False):

        try:
            self.lock.acquire( )

            if self.device.isOpen( ) == False:
                logger.debug( "Reconnecting")
                self.device.open( )

            if self.device.isOpen( ) == False:
                logger.debug( f"cannot open {self.device.port}.")

                self.lock.release( )
                return 'F03' # exception

            # Flush the buffer always before sending.
            self.device.reset_input_buffer( )

            self.device.write( f"{data}\r".encode( encoding="ascii"))

            # Command has no response, so do not wait for any.
            if not has_response:
                logger.debug( f"command: {data} response: do not wait")

                self.lock.release( )
                return 'F00' # empty response

            # There are three possbilites how the B203 responds to a command.
            # - ASCII 007 (BEL) (b'\x07\r\n') if the command is invalid.
            # - A message if the command has a feedback.
            # - No response at all for a valid command without feedback.

            # 1.5.2 Command format
            # An invalid entry is acknowledged by the B203 with ASCII 007 (BEL).

            # 1.5.3 Feedback format
            # The string is terminated with <CR LF> (Carriage Return, Line Feed).
            res = ""
            errno = 0
            retries = 3
            while True:
                res += self.device.readline( ).decode( 'utf-8')

                # - No response at all for a valid command without feedback.
                # - Interrrupted connection.
                if 0 == len( res):
                    logger.debug( f"command: {data} response: {len( res):2} {res:20} empty response {errno}")
                    if errno < retries:
                        errno += 1
                        continue

                    self.lock.release( )
                    return 'F00' # empty response

                # Check if the response is complete.
                if  '\r\n' == res[-2:]:
                    res = res[:-2] # Strip '\r\n'.
                else:
                    logger.debug( f"command: {data} response: {len( res):2} {res:20} incomplete response")
                    if errno < retries:
                        errno += 1
                        continue

                    self.lock.release( )
                    return 'F01' # incomplete response

                # - ASCII 007 (BEL) (b'\x07\r\n') if the command is invalid.
                if  '\x07' == res:
                    # NOTE: To run into here disable flushing the input buffer above.
                    # Only commands like "V" (without channel) return BELL.
                    # Invalid commands for a channel e.g. "2V" does not.
                    logger.debug( f"command: {data} response: {len( res):2} {res:20} invalid command")
                    res = ""
                    continue

                    self.lock.release( )
                    # return res
                    return 'F07' # invalid command
                else:
                    logger.debug( f"command: {data} response: {len( res):2} {res[0:1]} {res[1:3]} {res[3:]}")

                # Check if the data match the requested channel.
                if int( res[0:1]) != int( data[0:1]):
                    logger.error( f"expecting channel {int( data[0:1])} got {int( res[0:1])}")

                    self.lock.release( )
                    return 'F02' # channel mismatch

                self.lock.release( )
                return res

        # except serial.SerialException as e:
        # except IOError as e:
        except Exception as e:
            print( type( e))
            print( e)

            if self.device.isOpen( ) == True:
                logger.debug( "No Connection")
                self.device.close( )

            self.lock.release( )

            return 'F03' # exception

    #
    #
    #

#
#
#
