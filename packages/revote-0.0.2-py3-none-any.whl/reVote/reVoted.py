#
# This file is part of the reVote distribution (https://codeberg.org/Boeingflieger/reVote).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

# Websockets
import sys
print( sys.executable)  # Shows which Python installation is running
print( sys.path)       # Shows where Python looks for modules
# Websockets

import sys # exit
import argparse, configparser
import logging
import time # sleep
from datetime import datetime
import ast # literal_eval

# Designing a RESTful API with Python and Flask
# https://blog.miguelgrinberg.com/post/designing-a-restful-api-with-python-and-flask
from flask import Flask, render_template
from flask import jsonify
from flask import abort
# from flask import g

# Websockets
import importlib.util # find_spec
websockets_found = importlib.util.find_spec( "flask_socketio") is not None

if websockets_found:
    from flask import request
    from flask_socketio import SocketIO, emit
    from threading import Lock
# else:
#     print( "Websockets not found, fallback to polling.")

# Websockets

# How to import the class within the same directory or sub directory?
# https://stackoverflow.com/questions/4142151/how-to-import-the-class-within-the-same-directory-or-sub-directory

# "." relative import with parent package
from .rack import Rack


app = Flask( __name__)

# http://127.0.0.1:5001/
@app.route('/')
def index ( ):
    # if app.lock.locked( ):
    #     print( "Lock acquired, release")
    #     app.lock.release( )

    # flask include template with variable
    # https://stackoverflow.com/questions/67930867/flask-include-template-with-variable
    return render_template \
        ( 'bare/index.html'
        , style="bare"
        , slots=app.slots
        , websockets=app.websockets
        , title=app.revox_config.get( 'reVote', 'Title', fallback='ReVote')
        , b203_toggle=app.revox_config.getboolean( 'B203', 'Toggle', fallback=False)
        )

# NOTE: Only GET method can be put as URL in the browser.
# http://127.0.0.1:5001/model/api/v1.0/command/0X
@app.route( '/<string:model>/api/v1.0/command/<string:data>', methods=['PUT'])
def command ( model, data):
    # print( model)

    app.revox.command( data)

    return jsonify( )

@app.route( '/<string:model>/api/v1.0/command/0O', methods=['PUT'])
def standby ( model):
    # print( model)

    for channel, model, respond in app.slots:
        # Cannot turn off the B 203 itself.
        if 0 != channel:
            app.revox.command( f"{channel}O")

    return jsonify( )

@app.route( '/<string:model>/api/v1.0/command/sync', methods=['PUT'])
def sync ( model):
    # print( model)

    dt = datetime.now( )

    date = dt.strftime( "0D%d%m%y")
    time = dt.strftime( "0T%H%M%S")

    # command: 0D241025 response: 0 b''
    # command: 0T230532 response: 0 b''
    app.revox.command( date)
    app.revox.command( time)

    # Command
    # #            0Eaabcccccccdeeffffgggggghhhhhh
    # ser.write( b'0E01W11111111000010070000080000\r')

    # settings.ini
    # E01=W11111111000010070000080000

    # Response
    # b'05001W11111111000010070000080000\r\n'
    # b'05002E\r\n'
    # b'05003E\r\n'
    # b'05004E\r\n'
    # b'05005E\r\n'

    for n in range( 1, 6):
        app.revox.command( f"0E{n:0>2}{app.revox_config.get( 'B203', f'E{n:0>2}', fallback='E')}")

    return jsonify( )

@app.route( '/<string:model>/api/v1.0/status', methods=['PUT'])
def status ( model):
#     print( model)

    response = [ ]

    for channel, model, repsond in app.slots:
        # print( channel)

        if not response:
            continue

        res = app.revox.command( f"{channel}X", True)

        # device = int( res[  1:  3])
        # status = int( res[  3:  4])

        response.append( res)

    return jsonify( response)

# Websockets
# Websockets
# Websockets
if websockets_found:
    socketio = SocketIO( app, debug=True, cors_allowed_origins='*', async_mode='eventlet')

    def background_thread ( ):
        print( "background_thread")

    # @socketio.on( "status")
    # def status_event ( ):
        fast = [ False] * 8 # Is the channel in fast mode.

        # x = 0
        while True:
        # while not ws.closed:
            # response = { }
            standby = 0

            # For every round we calculate a sequence of slow and fast channel calls.
            # Changes are applied before the next round to avoid that a removed fast disappears before it shows up as slow.
            slow_list = [ channel for channel, model, respond in app.slots if respond and not fast[int( channel)]]
            fast_list = [ channel for channel, model, respond in app.slots if respond and fast[int( channel)]]
            curr_list = [ ]

            for channel in slow_list:
                curr_list.append( channel)
                curr_list.extend( fast_list)

            # print( f'slow {slow_list}')
            # print( f'fast {fast_list}')
            # print( f'curr {curr_list}')

            for channel in curr_list:
            # for channel, model, respond in app.slots:
                # print( channel)

                # start = time.perf_counter()
                res = app.revox.command( f"{channel}X", True)
                # end = time.perf_counter()

                # print( f'elapsed {(end - start):.6f} seconds')

                if 'F' == res[  0:  1]: # Error
                    app.logger.error( f"Error: {res}")
                    continue

                # # The response to the Status message is of the form ABBn...
                # # A   Channel number
                # # BB  Device identifier
                # # n   Status or similar
                # # so it should have at least 4 digits.
                # if res[  0:  4].isdigit( ):
                #     app.logger.error( f"Error: {res}")
                #     continue
                # Problem mit 00 no response.

                # channel = res[  0:  1] # Already tested in revox.command()
                device = res[  1:  3]

                # Check if the device is a "unit without repsonse".
                # Powered off or SERIAL LINK cable removed.
                if '00' == device:
                    # app.logger.warning( f"lost connection to channel {channel}")
                    app.logger.warning( f"no response from channel {channel}")
                elif res[  3:  4].isdigit( ):
                    # Actually this is specific to the device, but it should be a digit for all of them.
                    status = int( res[  3:  4])
                    # Bisher einmalig beim Abschalten der Anlage.
                    # ValueError: invalid literal for int() with base 10: b''

                    if '04' == device: # B215
                        # |===
                        # | 0 | Standby                   |
                        # | 1 | Stop                      |
                        # | 2 | Play                      | <-
                        # | 3 | Play und Autostop         | <-
                        # | 4 | Play und Loop             | <-
                        # | 5 | Play, Autostop und Loop   | <-
                        # | 6 | Pause                     |
                        # | 7 | Pause und Loop            |
                        # | 9 | Pause ohne stummschaltung |
                        # |===
                        fast[int( channel)] = status in [ 2, 3, 4, 5]
                        standby += status

                    elif '06' == device: # B226
                        # |===
                        # | 0 | Standby                   |
                        # | 1 | Stop                      |
                        # | 2 | Play                      | <-
                        # | 3 | Vorspulen                 | <-
                        # | 4 | Rückspulen                | <-
                        # | 5 | Aufnahme-Play             | <-
                        # | 7 | Stop                      |
                        # | 9 | Status unbekannt          |
                        # |===
                        fast[int( channel)] = status in [ 2, 3, 4, 5]
                        standby += status

                    # elif 50 <= int( device): # B203
                        # # TODO: bis 2035 im Manual suchen.
                        # if date_yy <= 35:
                        #     date_yy += 2000
                        # else:
                        #     date_yy += 1900
                        #
                        # dt = datetime( date_yy, date_mm, date_dd, time_hh, time_mm, time_ss)
                        #
                        # display = dt.strftime( "%b %d %p %I:%M*").upper( )
                        #
                        # # print( display)

                    elif '03' == device: # B285
                        standby += status
                # After reconnection of SERIAL LINK, power on or reset there
                # could be incomplete response, e.g. b'203               \r\n'.
                # elif b' ' == res[  3:  4]:
                    # app.logger.warning( f"device {device} not ready on channel {channel}")
                else:
                    app.logger.warning( f"incomplete response : {res} from device {device} on channel {channel}")

                # response = { }
                # response[ f"channel{channel}"] = \
                #         { 'status': f"{res}"
                #         # , 'n' : x
                #         }

                response = [ ]
                response.append( res)

                with app.test_request_context( '/'):
                    # emit( 'server', response, room=request.sid)
                    emit( 'server', response, namespace='/test', broadcast=True)

                socketio.sleep( 0)

            # All components in standby.
            # print( f"standby: {standby}")

            if 0 == standby:
                socketio.sleep( 1)

            # x += 1
            # emit('server', response, room=request.sid)
            # socketio.sleep( 1)
            # socketio.sleep( 0)

    # @socketio.on( 'command')
    @socketio.on( 'command', namespace='/test')
    def command_event ( data):
        # We do not need a timer to reset the IR light.
        # The B203 is so slow that we reset when the command has finished.

        # emit( 'server', ['F10'], room=request.sid)
        emit( 'server', ['F10'], broadcast=True)

        # To emit immediately. However it works.
        socketio.sleep( 0)

        if 'sync' == data:
            sync( 'revox')
            res = 'F00'
        elif '0O' == data: # standby
            for channel, model, respond in app.slots:
                # Cannot turn off the B 203 itself.
                if 0 != channel:
                    app.revox.command( f"{channel}O")
            res = 'F00'
        else:
            res = app.revox.command( data)

        response = [ ]
        response.append( res)

        # emit( 'server', response, room=request.sid)
        emit( 'server', response, broadcast=True)

    # Start backgound thread.
    thread = socketio.start_background_task( background_thread)
# Websockets
# Websockets
# Websockets

@app.route( '/<string:model>/api/v1.0/timer', methods=['PUT'])
def timer ( model):
#     print( model)

    response = { }

    for event in range( 1, 6):
        res = app.revox.command( f"0C{event:0>2}", True)

        response[ f"event{event:0>2}"] = \
                { 'event': f"{res}"
                }

    return jsonify( response)

# ----------------------------------------
# Main entrance.
# ----------------------------------------

def main ( ) -> int:
# def main ( ):

    # ----------------------------------------
    # Command line arguments.
    # ----------------------------------------

    CONFIG = \
        [ "~/.config/reVote/settings.ini"
        , "/etc/reVote/settings.ini"
        ]

    # First pre-parser to determine the configuration file.
    parser = argparse.ArgumentParser( add_help=False)

    # Values are appended to the default rather than replacing it.
    # Use an empty list as default and
    parser.add_argument \
        ( "-c", "--config", required=False
        , type=str
        , help='path to config file'
        , action='append', default=[ ]
        )

    args, remaining_argv = parser.parse_known_args( )

    # add values later only when there was no optional argument given.
    if not args.config:
        # args.config = CONFIG
        args.config.extend( CONFIG)

    # Do something with 'args.config'.
    print( args)

    config = configparser.ConfigParser( )
    config.read( args.config)

    # Full and real parser.
    parser = argparse.ArgumentParser \
        ( description=__doc__
        # ( description='Script to learn basic argparse'
        , formatter_class=argparse.ArgumentDefaultsHelpFormatter
        )

    # Add the config option again to provide a help message.
    # This time the default value must be set.
    parser.add_argument \
        ( "-c", "--config", required=False
        , type=str
        , help='path to config file'
        , action='append', default=CONFIG
        )

    parser.add_argument \
        ( '-H', '--host', required=False
        , default=config.get( 'Server', 'Host', fallback='127.0.0.1')
        , help='network interfaces the server is listen too'
        )

    parser.add_argument \
        ( '-p', '--port', required=False
        , default=config.get( 'Server', 'Port', fallback=5001)
        , help='port the server is listen too'
        )

    parser.add_argument \
        ( '-w', '--websockets', required=False
        , default=config.getboolean( 'Server', 'Websockets', fallback=websockets_found)
        , help='force use of websockets instead of polling'
        , action='store_true'
        )

    parser.add_argument \
        ( '-d', '--device', required=False
        , default=config.get( 'reVote', 'Device', fallback='/dev/ttyReVote')
        , help='serial tty device the B203 is connected'
        )

    parser.add_argument \
        ( '-D', '--debug', required=False
        , help='set debug mode for Socket.IO'
        , action='store_true'
        # added in 3.9
        # , action=argparse.BooleanOptionalAction
        )

    parser.add_argument \
        ( '-v', '--verbose', required=False
        , help='set verbose mode'
        , action='count', default=0
        )

    args = parser.parse_args( remaining_argv)

#     print( args)
#     exit()

    # The default level is WARNING
    # Level     Numeric value
    # CRITICAL  50
    # ERROR     40
    # WARNING   30
    # INFO      20
    # DEBUG     10
    # NOTSET     0

    level = logging.WARNING - 10 * args.verbose

    if level < logging.NOTSET:
        level = logging.NOTSET

    # logging.basicConfig( level=logging.DEBUG)
    logging.basicConfig( level=level)

    # app.logger = logging.getLogger( "reVote")
    app.logger = logging.getLogger( __name__)

    # ----------------------------------------
    # Init instrument.
    # ----------------------------------------

    # can't initialize values before starting App in Flask
    # https://stackoverflow.com/questions/65858686/cant-initialize-values-before-starting-app-in-flask

    # Create a "revox" attribute for the app.
    # Create a "revox" app property.
    app.revox = Rack( args.device)

    # Da gibts die von Revox angedachte Anordnung.
    # antora/audio/modules/Revox B203 Timer Controller/assets/attachments/User Manuals/studer_revox_b203_info.pdf
    # Revox B203 Bedienungsanleitung
    # Seite 6
    # Aufstellen, Anschliessen

    # slots = [ 0, 1, 2, 3, 4, 5, 6, 7, 8]
    # slots = [ 2, ( 0, 'B230'), 1]
    # print( config.get( 'reVote', 'Slots'))
    slots = ast.literal_eval( config.get( 'reVote', 'Slots', fallback='[ 0, 1, 2, 3, 4, 5, 6, 7, 8]'))
    # print( slots)

    app.slots = app.revox.scan( slots)
    print( app.slots)

    app.revox_config = config

    b203_sync = app.revox_config.getboolean( 'B203', 'Autosync', fallback=False)

    if b203_sync:
        dt = datetime.now( )

        date = dt.strftime( "0D%d%m%y")
        time = dt.strftime( "0T%H%M%S")

        app.revox.sync( date, time)

    # ----------------------------------------
    # Run the server
    # ----------------------------------------

    # Websockets
    # if websockets_found:
    if args.websockets:
        app.websockets = True
        # Kommt mit localhost nicht klar.
        socketio.run( app, host=args.host, port=args.port, debug=args.debug)
    # Websockets
    else:
        app.logger.warning( "Websockets not found, fallback to polling.")
        app.websockets = False
        app.run( host=args.host, port=args.port, debug=args.debug)

    return 0
