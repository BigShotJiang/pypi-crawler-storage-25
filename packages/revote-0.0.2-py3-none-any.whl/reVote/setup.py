#!/usr/bin/env python3.12

#
# This file is part of the reVote distribution (https://codeberg.org/Boeingflieger/reVote).
# Copyright (c) 2026 Christian Grosz.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#

import sys
import os # path
import pathlib

import urllib.request
import zipfile
import io

#
#
#

def my_input ( prompt: str, default: bool) -> bool:
    user_input = input( prompt)

    if not user_input:
        return default

    if user_input.lower() in ["yes", "y"]:
        return True

    return False

# ----------------------------------------
# Main entrance.
# ----------------------------------------

def main ( ) -> int:

    site_dir = pathlib.Path( __file__).parent.resolve( )
    print( site_dir)

    #
    # Download the "SF Digital Readout" font.
    #

    download_font = my_input( 'Download the "SF Digital Readout" font.? (Y/n): ', True)

    if download_font:
        font_dir = site_dir / "static" / "fonts"
        font_path = font_dir / "SF Digital Readout" / "TrueType" / "SFDigitalReadout-Medium.ttf"

        # print( font_dir)
        # print( font_path)

        if font_path.is_file( ):
            # file exists
            download_font = my_input( "Already installed, overwrite? (y/N): ", False)
        else:
            # file missing
            pass

        if download_font:
            url = "https://www.1001fonts.com/download/digital-readout.zip"
            response = urllib.request.urlopen( url)
            data = response.read( )      # a `bytes` object

            with zipfile.ZipFile( io.BytesIO( data)) as zip_ref:
                zip_ref.extractall( font_dir / "SF Digital Readout")

    #
    # Download Socket.IO.
    #

    download_socketio = my_input( 'Download Socket.IO? (Y/n): ', True)

    if download_socketio:
        # socketio_dir = site_dir / "static" / "js" / "socket.io" / "3.0.4"
        # socketio_dir = site_dir / "static" / "js" / "socket.io" / "3.1.3"
        socketio_dir = site_dir / "static" / "js" / "socket.io" / "4.8.3"
        socketio_path = socketio_dir  / "socket.io.js"

        # print( socketio_dir)
        # print( socketio_path)

        if socketio_path.is_file( ):
            # file exists
            download_socketio = my_input( "Already installed, overwrite? (y/N): ", False)
        else:
            # file missing
            socketio_dir.mkdir(parents=True, exist_ok=True)

        if download_socketio:
            # url = "https://cdnjs.cloudflare.com/ajax/libs/socket.io/3.0.4/socket.io.js"
            # url = "https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.8.1/socket.io.js"
            # url = "https://cdn.socket.io/3.0.4/socket.io.js"
            # url = "https://cdn.socket.io/3.1.3/socket.io.js"
            url = "https://cdn.socket.io/4.8.3/socket.io.js"
            urllib.request.urlretrieve \
                ( url
                , socketio_path
                )

    #
    # Create a configuration file.
    #

    create_configuration = my_input( 'Create a configuration file? (Y/n): ', True)

    if create_configuration:
        settings_dir = pathlib.Path( '/') / "etc" / "reVote"
        settings_path = settings_dir  / "settings.ini"

        # TODO: '~/.config/reVote/settings.ini'

        # print( settings_dir)
        # print( settings_path)

        if settings_path.is_file( ):
            # file exists
            create_configuration = my_input( "File exists, overwrite? (y/N): ", False)
        else:
            # file missing
            settings_dir.mkdir(parents=True, exist_ok=True)

        if create_configuration:
            with settings_path.open( mode='w+') as f:
                f.writelines( \
'''[Server]
; Listen on all public IPs.
; Host=0.0.0.0
; Port=5001
; Websockets=False
; Style = bare

[reVote]
; Title=reVote
; Slots = [ 2, 0, 0, 1, 3]
; Slots = [ ( 5, 'B291', False), (2, 'B285'), (0, 'B203'), (1, 'B226'), ( 3, 'B215')]
; Device=/dev/ttyReVote

[B203]
; Autosync=True
; Toggle=True
; ;   bcccccccdeeffffgggggghhhhhh
; E01=W11111111000010070000080000
''')

    #
    # Create an udev rule.
    #

    create_udev_rule = my_input( 'Create an udev rule? (Y/n): ', True)

    if create_udev_rule:
        udev_dir = pathlib.Path( '/') / "etc" / "udev" / "rules.d"
        udev_path = udev_dir  / "99-reVote.rules"

        # print( udev_dir)
        # print( udev_path)

        if udev_path.is_file( ):
            # file exists
            create_udev_rule = my_input( "File exists, overwrite? (y/N): ", False)
        else:
            # file missing
            pass

        if create_udev_rule:
            with udev_path.open( mode='w+') as f:
                f.writelines( \
'''ACTION=="add",ENV{ID_BUS}=="usb",ENV{ID_SERIAL_SHORT}=="A403Q7B5",SYMLINK+="ttyReVote"
#,GROUP="dialout"
''')

    #
    # Create systemd service.
    #

    create_systemd_service = my_input( 'Create systemd service? (Y/n): ', True)

    if create_systemd_service:
        systemd_dir = pathlib.Path( '/') / "usr" / "lib" / "systemd" / "system"
        systemd_path = systemd_dir  / "reVote.service"

        # print( systemd_dir)
        # print( systemd_path)

        if systemd_path.is_file( ):
            # file exists
            create_systemd_service = my_input( "File exists, overwrite? (y/N): ", False)
        else:
            # file missing
            pass

        if create_systemd_service:
            with systemd_path.open( mode='w+') as f:
                f.writelines( \
'''[Unit]
Description=reVote Service
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/reVoted -c /etc/reVote/settings.ini

[Install]
Alias=reVote
WantedBy=default.target
''')

    return 0

# ----------------------------------------
# Execute Code when the file runs as a script
# ----------------------------------------

if __name__ == "__main__":
    sys.exit( main( ))
