//! `derive` — build an accepted program from a partial prefix read from stdin.
//!
//! Reads a grammar specification from `--spec` and a partial program from
//! stdin, then uses repeated `feed()` steps over allowed token examples to build
//! a soft accepted witness.
//!
//! Exit codes
//! ----------
//! 0  A witness was found; the full program is printed to stdout.
//! 1  No witness found within the configured budget.
//! 2  Usage / I/O error (bad spec file, missing flag, …).

use clap::Args;
use std::io::{self, Read};
use std::path::PathBuf;

use aufbau::logic::grammar::Grammar;
use aufbau::validation::completability;

/// Derive an accepted program from a partial prefix.
///
/// Examples
/// --------
///
///   echo "let x : Int =" | aufbau derive -s examples/fun.auf
///
///   echo "let" | aufbau derive -s examples/fun.auf --depth 12
///
///   echo "(x : Int) =>" | aufbau derive -s examples/fun.auf --info
#[derive(Args, Debug, Clone)]
pub struct CompleteCmd {
    /// Path to the grammar / typing-rules specification file (.auf)
    #[arg(short = 's', long = "spec", value_name = "FILE")]
    pub spec: PathBuf,

    /// Maximum number of extra feed steps beyond the prefix
    #[arg(long = "depth", default_value_t = 10)]
    pub depth: usize,

    /// Print extra information about the derivation attempt
    #[arg(short = 'i', long = "info", action = clap::ArgAction::SetTrue)]
    pub info: bool,

    /// Reserved for richer diagnostics
    #[arg(long = "dump-visited", action = clap::ArgAction::SetTrue)]
    pub dump_visited: bool,
}

pub fn run(args: &CompleteCmd) {
    // ── 1. Load grammar ──────────────────────────────────────────────────
    let spec_src = match std::fs::read_to_string(&args.spec) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("error: cannot read spec '{}': {}", args.spec.display(), e);
            std::process::exit(2);
        }
    };
    let grammar = match Grammar::load(&spec_src) {
        Ok(g) => g,
        Err(e) => {
            eprintln!("error: failed to load grammar: {}", e);
            std::process::exit(2);
        }
    };

    // ── 2. Read partial program from stdin ───────────────────────────────
    let mut input = String::new();
    if let Err(e) = io::stdin().read_to_string(&mut input) {
        eprintln!("error: failed to read stdin: {}", e);
        std::process::exit(2);
    }
    let input = input.trim_end_matches('\n');

    if args.info {
        eprintln!("input    : {:?}", input);
        eprintln!("depth    : {}", args.depth);
    }

    // ── 3. Run greedy feed-based derivation ──────────────────────────────
    let results = completability::derive_k(&grammar, input, args.depth, 1, None);
    if let Some(derived_input) = results.first() {
        if args.info {
            eprintln!("status   : success");
        }
        println!("{}", derived_input);
        std::process::exit(0);
    }

    eprintln!("error: no accepted witness found");
    std::process::exit(1);
}
