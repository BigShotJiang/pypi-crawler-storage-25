use crate::debug_debug;
use crate::debug_trace;
use crate::logic::completion::TokenSet;
use crate::logic::grammar::Grammar;
use crate::logic::parse::{CtxId, TypedParser};
use crate::logic::structure::ast::FusionAST;
use crate::logic::typing::Context;
use crate::regex::Regex;

use crate::logic::typing::runtime::RuleRuntime;


#[cfg(test)]
mod tests;



#[cfg(test)]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) struct SynthStats {
    pub full_parses: usize,
    pub incremental_advances: usize,
}

pub struct Synthesizer {
    grammar: Grammar,
    runtime: RuleRuntime,
    parser: TypedParser<RuleRuntime>,

    input: String,
    ctx: Context,
    tree: Option<FusionAST>,

    #[cfg(test)]
    stats: SynthStats,
}

impl Synthesizer {
    pub fn new(grammar: Grammar, input: impl Into<String>) -> Self {
        let input = input.into();
        debug_trace!("synth", "new: input='{}'", input);
        let runtime = RuleRuntime::new(grammar.clone());
        let parser = TypedParser::new(grammar.clone(), runtime.clone());

        Self {
            grammar,
            runtime,
            parser,
            ctx: Context::new(),
            input,
            tree: None,
            #[cfg(test)]
            stats: SynthStats::default(),
        }
    }

    pub fn grammar(&self) -> &Grammar {
        &self.grammar
    }

    pub fn runtime(&self) -> &RuleRuntime {
        &self.runtime
    }

    pub fn ctx(&self) -> &Context {
        &self.ctx
    }
    pub fn set_ctx(&mut self, ctx: Context) {
        self.ctx = ctx;
        self.tree = None;
        let _ = self.ast(); // reload the AST
    }
    pub fn add_ctx(&mut self, ctx: Context) {
        self.ctx.merge(&ctx);
        self.tree = None;
        let _ = self.ast(); // reload the AST
    }

    pub fn input(&self) -> &str {
        &self.input
    }
    pub fn set_input(&mut self, input: impl Into<String>) {
        self.input = input.into();
        self.tree = None;
        let _ = self.ast(); // reload the AST
    }

    pub fn ast(&mut self) -> Result<FusionAST, String> {
        match &self.tree {
            Some(ast) => Ok(ast.clone()),
            None => {
                match self
                    .parser
                    .parse(&self.input, ctx_id(&self.ctx, &self.runtime))
                {
                    Ok(ast) => {
                        debug_trace!("synth", "ast: input='{}' parsed successfully", self.input);
                        self.tree = Some(ast.clone());
                        return Ok(ast);
                    }
                    Err(err) => {
                        debug_trace!("synth", "ast: input='{}' parse failed: {}", self.input, err);
                        Err(format!("Parse error: {}", err))
                    }
                }
            }
        }
    }

    pub fn parse_with(&mut self, ctx: &Context) -> Result<FusionAST, String> {
        self.set_ctx(ctx.clone());
        self.ast()
    }

    pub fn feed_with(&mut self, token: &str, ctx: &Context) -> Result<FusionAST, String> {
        self.set_ctx(ctx.clone());
        self.feed(token)
    }

    pub fn allowed_tokens_with(&mut self, ctx: &Context) -> Result<TokenSet, String> {
        self.add_ctx(ctx.clone());
        Ok(self.allowed_tokens()?)
    }

    pub fn allowed_tokens(&mut self) -> Result<TokenSet, String> {
        debug_trace!("synth", "allowed_tokens: input='{}'", self.input);
        let out_tokens = self.ast()?.completions(&self.grammar);
        debug_debug!(
            "tokens",
            "allowed_tokens: input='{}' tokens={}",
            self.input,
            out_tokens.len()
        );
        for token in out_tokens.iter().take(16) {
            debug_debug!(
                "tokens",
                "allowed_tokens: token='{}' example={:?}",
                token.to_pattern(),
                token.example()
            );
        }
        Ok(TokenSet::from_tokens(out_tokens))
    }

    // feed mutates the synthesizer
    pub fn feed(&mut self, token: &str) -> Result<FusionAST, String> {
        debug_trace!("synth", "feed: input='{}' token='{}'", self.input, token);
        let extended =
            crate::logic::grammar::extend::extend_input(&mut self.grammar, &self.input, token);
        // realoding might be improved but not time
        self.set_input(extended);
        self.ast()
    }

    // doesnt mutate
    pub fn try_feed(&mut self, token: &str) -> Result<FusionAST, String> {
        debug_trace!("synth", "try: input='{}' token='{}'", self.input, token);
        let extended =
            crate::logic::grammar::extend::extend_input(&mut self.grammar, &self.input, token);
        let mut p = self.parser.fork();
        match p.parse(&extended, ctx_id(&self.ctx, &self.runtime)) {
            Ok(ast) => Ok(ast),
            Err(err) => Err(format!("try_feed failed: {}", err)),
        }
    }

    #[cfg(test)]
    pub(crate) fn stats(&self) -> SynthStats {
        self.stats
    }
}

fn ctx_id(ctx: &Context, runtime: &RuleRuntime) -> CtxId {
    runtime.intern_context(ctx.clone())
}
