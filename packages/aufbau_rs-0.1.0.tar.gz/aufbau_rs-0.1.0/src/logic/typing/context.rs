//! Formal typing environments and tree-level status objects.

use crate::logic::path::TreePath;
use crate::logic::typing::rule::TypeOperation;
use crate::logic::typing::Type;
use std::collections::BTreeMap;

/// Typing environment for a derivation point.
#[derive(Clone, Debug, Default, Hash, PartialEq, Eq)]
pub struct Context {
    pub bindings: BTreeMap<String, Type>,
    pub unresolved_bindings: BTreeMap<TreePath, Type>,
}

impl Context {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn lookup(&self, x: &str) -> Option<&Type> {
        self.bindings.get(x)
    }

    pub fn merge(&self, other: &Self) -> Self {
        let mut new = self.clone();
        for (k, v) in &other.bindings {
            new.bindings.insert(k.clone(), v.clone());
        }
        for (k, v) in &other.unresolved_bindings {
            new.unresolved_bindings.insert(k.clone(), v.clone());
        }
        new
    }

    pub fn lookup_unresolved(&self, path: &TreePath) -> Option<&Type> {
        self.unresolved_bindings.get(path)
    }

    pub fn lookup_starts_with(&self, prefix: &str) -> Option<&Type> {
        self.bindings
            .iter()
            .find(|(k, _)| k.starts_with(prefix))
            .map(|(_, v)| v)
    }

    pub fn extend(&self, x: String, ty: Type) -> Result<Self, String> {
        if self.bindings.contains_key(&x) {
            return Err(format!("Context already contains binding for '{}'", x));
        }

        let mut new = self.clone();
        new.bindings.insert(x, ty);
        Ok(new)
    }

    pub fn shadow(&self, x: String, ty: Type) -> Self {
        let mut new = self.clone();
        new.bindings.insert(x, ty);
        new
    }

    pub fn extend_unresolved(&self, path: TreePath, ty: Type) -> Result<Self, String> {
        if self.unresolved_bindings.contains_key(&path) {
            return Err(format!(
                "Context already contains unresolved binding for path '{:?}'",
                path
            ));
        }

        let mut new = self.clone();
        new.unresolved_bindings.insert(path, ty);
        Ok(new)
    }

    pub fn add(&mut self, x: String, ty: Type) {
        self.bindings.insert(x, ty);
    }
}

/// One composable context assignment.
#[derive(Clone, Debug, Hash, PartialEq, Eq)]
pub struct ContextEdit {
    pub name: String,
    pub ty: Type,
    pub overwrite: bool,
}

/// A context morphism between two interned contexts.
#[derive(Clone, Debug, Default, Hash, PartialEq, Eq)]
pub struct ContextTransition {
    pub source: usize,
    pub target: usize,
    pub edits: Vec<ContextEdit>,
}

impl ContextTransition {
    pub fn identity(ctx: usize) -> Self {
        Self {
            source: ctx,
            target: ctx,
            edits: Vec::new(),
        }
    }

    pub fn opaque(source: usize, target: usize) -> Self {
        Self {
            source,
            target,
            edits: Vec::new(),
        }
    }

    pub fn retarget(&self, target: usize) -> Self {
        Self {
            source: self.source,
            target,
            edits: self.edits.clone(),
        }
    }

    pub fn compose(&self, next: &Self) -> Self {
        debug_assert_eq!(self.target, next.source);
        let mut edits = self.edits.clone();
        edits.extend(next.edits.clone());
        Self {
            source: self.source,
            target: next.target,
            edits,
        }
    }

    pub fn is_identity(&self) -> bool {
        self.source == self.target && self.edits.is_empty()
    }
}

/// Semantic classification of a parsed tree.
#[derive(Clone, Debug)]
pub enum TreeStatus {
    Valid(Type),
    Partial(Type),
    Malformed,
    TooDeep,
}

impl TreeStatus {
    pub fn is_ok(&self) -> bool {
        !matches!(self, TreeStatus::Malformed)
    }

    pub fn ty(&self) -> Option<&Type> {
        match self {
            TreeStatus::Valid(t) | TreeStatus::Partial(t) => Some(t),
            TreeStatus::Malformed | TreeStatus::TooDeep => None,
        }
    }
}

