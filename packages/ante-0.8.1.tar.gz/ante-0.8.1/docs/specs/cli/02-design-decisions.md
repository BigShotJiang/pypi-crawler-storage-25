# CLI 모듈 세부 설계 - 설계 결정

> 인덱스: [README.md](README.md) | 호환 문서: [cli.md](cli.md)

# 설계 결정

### CLI 프레임워크

**근거**:
- `click` 라이브러리 채택 — 그룹/서브커맨드, 타입 검증, 자동 `--help` 생성
- `--format json` 글로벌 옵션 — Agent가 모든 커맨드 출력을 파싱 가능 (D-010)
- `--config-dir` 글로벌 옵션 — 설정 디렉토리 경로 (환경변수 `ANTE_CONFIG_DIR`로도 설정 가능)
- `--version` — 버전 정보 출력 (`ante --version`)
- `click.Context`로 공유 상태(format, formatter, config_dir, member) 전달
- 루트 그룹에서 `authenticate_member(ctx)` 호출하여 인증 수행

**유틸 함수**: `get_formatter(ctx) -> OutputFormatter` — 컨텍스트에서 포맷터 인스턴스 획득

소스: `src/ante/cli/main.py`

### OutputFormatter

text/json 모드를 지원하는 CLI 출력 포맷터.

| 프로퍼티/메서드 | 파라미터 | 반환값 | 설명 |
|----------------|----------|--------|------|
| `is_json` (property) | — | bool | JSON 모드 여부 |
| `output` | data: dict \| list, text_template: str = "" | None | 데이터 출력 (json 모드: JSON dump, text 모드: 템플릿 포맷) |
| `table` | rows: list[dict], columns: list[str] | None | 테이블 형태 출력 |
| `error` | message: str, code: str = "" | None | 에러 출력 |
| `success` | message: str, data: dict \| None = None | None | 성공 메시지 출력 (json 모드: `{status: "ok", message, data}`) |

소스: `src/ante/cli/formatter.py`

### 인증 미들웨어

> 소스: `src/ante/cli/middleware.py`

CLI 커맨드에 멤버 인증과 스코프 기반 접근 제어를 적용하는 미들웨어.

| 함수/데코레이터 | 설명 |
|----------------|------|
| `authenticate_member(ctx)` | 루트 그룹에서 호출. `ANTE_MEMBER_TOKEN` 환경변수로 `MemberService.authenticate()` 실행, 성공 시 `ctx.obj["member"]`에 저장 |
| `@require_auth` | 커맨드 데코레이터. `ctx.obj["member"]`가 None이면 에러 출력 후 SystemExit(1) |
| `@require_scope(*scopes)` | 커맨드 데코레이터. Human 멤버(`MemberType.HUMAN`)는 스코프 무제한 통과. Agent 멤버는 등록된 scope에 필요 scope가 모두 포함되어야 함 |
| `get_member_id(ctx)` | 인증된 멤버 ID 반환. 미인증 시 `"unknown"` |

**인증 면제 커맨드 경로**: `ante init`, `ante member reset-password`, `ante member regenerate-recovery-key` (토큰 없이 실행 가능)

매칭은 leaf 이름이 아니라 **전체 커맨드 경로** 기준이다. `ante feed init`처럼 leaf 이름이 우연히 `init`인 다른 서브커맨드는 면제 대상이 아니다 (`@require_auth` + `@require_scope`로 인증 필요). 구현은 `LeafAwareGroup`(src/ante/cli/main.py)이 루트 그룹 진입 직후 전체 경로 tuple을 `ctx.obj["_leaf_command_path"]`에 저장하고, `authenticate_member`가 이 tuple과 `_AUTH_EXEMPT_COMMAND_PATHS`(src/ante/cli/middleware.py)를 비교한다.

### DB 경로 일관성 (config_dir 기반)

**배경**: `ante init`은 `<config_dir>/db/ante.db`를 생성하지만, 후속 CLI들이 과거 `Database("db/ante.db")`를 CWD 기준으로 하드코딩하면 서로 다른 DB 파일을 참조하게 되어 방금 만든 master 토큰으로도 인증이 실패한다.

**규칙**:
- 모든 CLI는 `ante.cli.main.get_db_path(ctx)` 헬퍼로 DB 경로를 해석한다.
- 우선순위:
  1. `ctx.obj["config_dir"]` (루트 그룹이 `--config-dir` 또는 `ANTE_CONFIG_DIR` 환경변수로부터 확정한 Path)
  2. 기본값 `~/.config/ante/` (init과 동일)
- `--db-path` 옵션을 가진 커맨드(`ante approval`, `ante backtest`, `ante instrument`, `ante report`, `ante data`)는 사용자 override를 위해 기본값을 `None`으로 두고, 값이 없을 때 `get_db_path(ctx)`로 폴백한다. 이로써 기존 사용자의 `--db-path` 지정은 그대로 동작한다.
- 서버(`ante system start`)는 이미 `system.toml`의 `db.path` 설정을 읽고 `ANTE_CONFIG_DIR`을 하위 프로세스로 전달하므로, CLI 쪽 경로 해석이 서버 동작에 영향을 주지 않는다.

### `--db-path` 옵션의 인증 DB / 작업 DB 분리

일부 CLI 커맨드(`ante approval`, `ante backtest`, `ante data`, `ante instrument`, `ante report`)는 대용량 조회·백테스트·스냅샷 조회 등을 위해 보조 DB를 지정할 수 있는 `--db-path <경로>` 옵션을 제공한다. 이 옵션은 **작업 대상 DB만 바꾸며 인증 DB를 바꾸지 않는다**. 아래 분리는 의도된 설계다.

- **인증 단계(루트 그룹)**: `authenticate_member(ctx)`는 항상 `get_db_path(ctx)` — 즉 `resolve_config_dir()`이 해석한 **기본 설정 DB** — 에서 `ANTE_MEMBER_TOKEN`을 검증한다. 서브커맨드의 `--db-path` 값은 루트 콜백 실행 시점에 파싱되기 전이므로 인증 대상 DB에 영향을 줄 수 없다.
- **작업 단계(서브커맨드)**: 인증이 성공하면 서브커맨드가 `--db-path`로 지정된 DB(또는 미지정 시 `get_db_path(ctx)` 폴백)를 열어 실제 조회/기록을 수행한다.

예: `ante approval list --db-path /tmp/backup.db`는

1. 기본 설정 DB(`<config_dir>/db/ante.db`)에서 `ANTE_MEMBER_TOKEN`을 검증한 뒤 (루트 콜백),
2. `/tmp/backup.db`에서 approval 목록을 조회한다 (서브커맨드 콜백).

**이 분리를 유지하는 이유**:

- **보안**: 토큰 검증은 신뢰할 수 있는 기본 DB에서만 수행한다. 호출자가 임의의 경로를 넘겨 인증을 우회하거나, 준비된 가짜 DB로 멤버 레코드를 위조하는 공격 벡터를 차단한다.
- **운영 시나리오**: 사용자·Agent가 백테스트 DB, 스냅샷, 아카이브를 조회할 때마다 해당 DB에 별도 멤버·토큰을 심어둘 필요가 없다. 한 번 발급받은 토큰으로 여러 데이터셋을 오가며 조회할 수 있다.

**부수 효과**:

- `--db-path`로 지정한 DB 자체의 유효성(존재 여부, 스키마 호환 등)은 서브커맨드 실행 시점에 검증되며, 인증이 실패하면 그 지점에 도달하지 않으므로 경로 유효성 오류는 노출되지 않을 수 있다. 이는 의도된 순서(인증 먼저)다.
- 반대로 `--config-dir`(또는 `ANTE_CONFIG_DIR`)은 루트 콜백 시점에 해석되므로 **인증 DB와 작업 DB를 함께** 바꾼다. 두 DB를 한 번에 스위치하려면 `--db-path`가 아니라 `--config-dir`을 사용한다.

`--db-path`가 인증 DB까지 바꾸도록 재구성하는 것은 구조적 리팩터링(루트 콜백에서 서브커맨드 파라미터 선해석)이 필요하며, 현재 범위에 포함하지 않는다. 필요 시 별도 설계 결정으로 다룬다.

### 시스템 통신

CLI 커맨드는 **오프라인**과 **런타임** 두 가지 방식으로 시스템과 통신한다.

구분 기준: **서버의 EventBus 구독자가 반응해야 하는 부수효과(이벤트 발행 또는 인메모리 상태 변경)가 있는가?**

| 분류 | 실행 방식 | 설명 |
|------|----------|------|
| **오프라인** | 직접 모듈 임포트 | 조회, 백테스트, 데이터 관리 등 서버 런타임에 영향이 없는 커맨드. 서비스를 직접 생성하여 호출한다. |
| **런타임** | IPC (Unix domain socket) | 봇 중지, 예산 할당, 설정 변경 등 서버의 EventBus 구독자가 반응해야 하는 커맨드. 서버 프로세스의 서비스 계층에 위임한다. |

런타임 커맨드의 상세 목록과 IPC 프로토콜은 [ipc.md](../ipc/ipc.md)를 참조한다.

**런타임 커맨드 실행 흐름**:
1. CLI에서 `ANTE_MEMBER_TOKEN` 인증 + `@require_scope` 권한 확인 (기존과 동일)
2. `IPCClient`로 서버의 Unix socket에 커맨드 전달
3. 서버의 `IPCServer`가 수신 → `ServiceRegistry`의 서비스 실행 → EventBus 이벤트 전파
4. 결과를 CLI에 반환하여 출력
