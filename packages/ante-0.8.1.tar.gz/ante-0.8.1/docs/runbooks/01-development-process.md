# 01. AI 에이전트 기반 개발 프로세스

> Claude Code가 구현을 담당하고, Codex가 사전 브랜치 리뷰를 담당하며, PR 단계에서는 두 모델이 독립적으로 승인하는 개발 체계를 정의한다.

---

## 1. 개발 철학

- 주 개발은 Claude Code가 담당한다.
- 스펙 문서(`docs/specs/`)가 설계의 단일 출처(SSOT)다. 변경이 필요하면 **스펙 최신화 → 이슈 발행 → 코드 반영** 순서를 따른다.
- PR은 구현 완료 사실을 알리는 문서가 아니라, **이미 한 차례 Codex 사전 리뷰를 통과한 변경**을 통합 후보로 올리는 단계다.
- 최종 머지 결정은 사람 감각이 아니라 **명시적인 게이트 상태**로 판단한다.
- `docs/specs/`와 `docs/architecture/`는 코드보다 앞선 계약이며, 리뷰와 승인 단계 모두 이 문서를 기준으로 판정한다.
- 고위험 변경은 구현 전에 **조건부 계획 리뷰**를 통과해야 한다.
- 리뷰는 수정된 파일 목록만으로 끝내지 않는다.
  - 캐시, 연결, 생성 산출물, 소비자 경로가 보이면 호출자와 후속 경로까지 넓혀 본다.

## 2. 역할 구성

> Claude 측 역할과 `.agent/` 구조 상세: [02-agent-structure.md](02-agent-structure.md)
> 리뷰/승인/머지 게이트 상세: [07-review-gate.md](07-review-gate.md)

- **Claude 오케스트레이터**: 이슈 분석, 스펙 확인, 구현 에이전트 위임, GitHub 기록 관리
- **Claude 개발 에이전트**: 구현, 로컬 검증, 브랜치 푸시, Codex 피드백 반영
- **Claude 코드 리뷰어**: 조건부 계획 리뷰, 구조 리스크 메타 리뷰, 반복 failure 원인 분석
- **Codex 브랜치 리뷰어**: PR 전 브랜치 단위 사전 리뷰, blocking issue 식별
- **Claude PR 승인 워커**: PR head SHA 기준 최종 승인 체크
- **Codex PR 승인 워커**: PR head SHA 기준 최종 승인 체크
- **GitHub merge gate**: 두 모델 승인과 CI 성공 여부를 기준으로 auto-merge 실행

## 3. 상호작용 흐름

```
사용자 (요구사항/이슈)
  │
  ▼
Claude 오케스트레이터
  │  ◄──── AGENTS.md + docs/specs/* + docs/architecture/*
  │
  ├── 분석: 이슈 읽기 → 스펙 확인 → 구현 에이전트 결정
  │
  ├── 경량 계획: 파일 맵 → 작업 분해 → risk flags → verification plan
  │
  ├── 조건부 계획 리뷰 (`@code-reviewer`)
  │         ├── not required / approve-implement → 진행
  │         ├── narrow-scope → 범위 축소 후 진행
  │         └── split-issue / invoke-human → 구현 중단
  │
  ├── 착수 기록: 이슈 코멘트
  │
  ├──▶ Claude 개발 에이전트 (worktree 격리)
  │         │
  │         ├── 구현 + 로컬 lint/test
  │         ├── 브랜치 push
  │         ▼
  │    Codex 브랜치 리뷰 (`codex-branch-review`)
  │         │
  │         ├── FAIL → Claude가 같은 브랜치에서 수정 후 재push
  │         ├── 고위험 변경 / 반복 risk class → Claude `@code-reviewer` 메타 리뷰
  │         └── PASS → PR 생성
  │
  ├── PR 생성 후
  │    ├── CI
  │    ├── Claude PR 승인 (`claude-pr-approve`)
  │    └── Codex PR 승인 (`codex-pr-approve`)
  │
  ├── PR 승인 content FAIL → Claude 자동 재수정 (최대 10회)
  │
  ├── 모든 게이트 green → GitHub auto-merge
  │
  ├── post-merge automation → 이슈 체크박스 갱신 + close
  │
  ▼
결과 보고
```

**핵심 차이**:
- Codex의 첫 리뷰는 **PR 전 브랜치 리뷰**다.
- PR 단계의 Claude/Codex 승인 체크는 **같은 head SHA**를 기준으로 독립 실행된다.
- 머지는 Claude 오케스트레이터가 직접 하지 않고, GitHub auto-merge가 수행한다.

## 4. 작업 실행 체계

에이전트의 구체적인 작업 절차는 `.agent/commands/`에 정의된 커맨드가 단일 출처(SSOT)다.

| 커맨드 | 역할 | 파일 |
|--------|------|------|
| `/implement-issue` | 이슈 구현 전체 흐름 (분석 → 경량 계획 → 조건부 계획 리뷰(필요 시) → 구현 → Codex 브랜치 리뷰 → PR 생성) | `.agent/commands/implement-issue.md` |
| `/autopilot` | 오픈 이슈 큐 순차 처리 (선별 → 의견 검토 → `/implement-issue` → merge/post-merge 모니터링, 기본 `limit=10`) | `.agent/commands/autopilot.md` |
| `/qa-test` | 지정 TC 실행 (`@qa-engineer` 위임) | `.agent/commands/qa-test.md` |
| `/qa-sweep` | 전체 TC 순차 실행 (전수 검사) | `.agent/commands/qa-sweep.md` |
| `/api-docs` | OpenAPI 스키마 조회 | `.agent/commands/api-docs.md` |
| `/arch-review` | 이슈 사전 아키텍처 검토 | `.agent/commands/arch-review.md` |
| `/qa-review` | 이슈 사전 QA 커버리지 검토 | `.agent/commands/qa-review.md` |

야간 배치나 backlog 정리에서는 `/autopilot`이 오픈 이슈 큐 snapshot을 잡고, 필요 시 `/arch-review`와 `/qa-review` 증적을 이슈 코멘트로 남긴 뒤 `/implement-issue`에 개별 구현을 위임한다. 사전 리뷰의 `ready`/`caution`은 구현 체크리스트로 승격되며, `/autopilot`은 기본적으로 **한 번에 최대 10개 이슈를 review → implement → merge/post-merge까지 순차 모니터링**한다.

운영 중인 이슈의 현재 단계는 최신 `🤖 **Autopilot 사이클 상태**` 코멘트로 노출하며, 여기서 `review-state`, `implement-state`, `merge-monitor-state`를 각각 `pending | running | blocked | done`으로 추적한다.

### 4.1 조건부 계획 리뷰

조건부 계획 리뷰는 GitHub status check가 아니라, **구현 시작 전에만 거는 사전 게이트**다.

- 오케스트레이터는 구현 전에 경량 계획 체크리스트를 만든다.
- 경량 계획은 `.agent/skills/lightweight-planning.md`의 형식을 따른다.
- 기본 흐름에서는 바로 구현 에이전트로 위임한다.
- 아래 조건이 하나라도 맞으면 `@code-reviewer` 계획 리뷰를 먼저 통과해야 한다.
  - 캐시, 세션, 연결, long-lived adapter, mutable config 변경
  - endpoint / schema / field / CLI rename
  - OpenAPI, 생성 타입, 생성 문서, schema drift 가능성
  - 둘 이상의 모듈과 소비자 경로 동시 영향
  - 운영 health / readiness / background task와 연결된 동작 변경
  - 같은 `risk class` failure가 과거 리뷰에서 2회 반복

계획 리뷰의 출력은 다음 중 하나다.

- `approve-implement`
- `narrow-scope`
- `split-issue`
- `invoke-human`

`split-issue`나 `invoke-human`이면 구현을 시작하지 않는다.

### 4.2 브랜치 전략

> Git 컨벤션 상세: [03-git-workflow.md](03-git-workflow.md)

**독립 이슈**:

```
main
  └─ {branch-prefix}/#{issue번호}-{짧은설명}
       ├─ 구현 + push
       ├─ codex-branch-review PASS
       └─ PR → main → auto-merge
```

`branch-prefix`는 [00-issue-management.md 섹션 2.1](00-issue-management.md#21-이슈-타입과-브랜치-prefix-매핑)의 canonical 매핑을 따른다.

**에픽 이슈**:

```
main
  └─ epic/#{에픽번호}-{짧은설명}
       ├─ feat/#{하위1} → Codex 브랜치 리뷰 → PR → epic/*
       ├─ feat/#{하위2} → Codex 브랜치 리뷰 → PR → epic/*
       └─ feat/#{하위3} → Codex 브랜치 리뷰 → PR → epic/*
     epic 브랜치 자체도 최종 PR 전에 Codex 브랜치 리뷰를 거친다.
```

### 4.2.1 에픽 하위 브랜치 정렬 규칙

- 에픽 구현은 통합용 `epic/*` 브랜치 1개와 하위 이슈별 작업 브랜치를 분리한다.
- 에픽과 하위 이슈를 하나의 공용 작업 브랜치에 순차 누적하지 않는다.
- sibling PR이 `epic/*`에 머지되면, 아직 열려 있는 다른 하위 이슈 브랜치는 다음 push 전에 최신 에픽 기준으로 재정렬한다.
- 최소 확인 절차:
  - `git fetch origin`
  - `git rebase origin/epic/#{에픽번호}-{짧은설명}` 또는 필요 시 새 브랜치 재생성
  - `git cherry -v origin/epic/#{에픽번호}-{짧은설명} HEAD`
  - rebase/히스토리 정리 전후 차이를 확인해야 하면 `git range-diff <정리 전 브랜치> <정리 후 브랜치>`
- 중복 커밋, stale base, base regression이 보이면 PR 생성이나 리뷰 재시도보다 히스토리 정리를 먼저 수행한다.

### 4.3 Worktree 격리

모든 구현 작업은 **git worktree**로 격리하여 로컬 main을 보호한다.

| 상황 | Worktree 사용 |
|------|:------------:|
| 독립 모듈 병렬 구현 | O |
| 에픽 하위 이슈 병렬 구현 | O |
| 의존성 있는 순차 구현 | O |
| PR 승인 실패 후 재수정 | O (같은 이슈 브랜치 재사용) |

### 4.3.1 공유 `.venv` 사용 시 재현성 주의

- 여러 worktree가 하나의 editable install을 공유하면, 현재 작업 중인 worktree가 아닌 다른 worktree의 `src/ante`를 잘못 import할 수 있다.
- 로컬 검증 전 `pip show ante`로 editable project location을 확인한다.
- 대상 worktree에서만 검증해야 할 때는 `PYTHONPATH=$PWD/src`를 명시하거나 editable install을 현재 worktree 기준으로 다시 맞춘다.

## 5. 실패 복구 루프

구체적 절차는 `/implement-issue`, 리뷰 게이트 상세는 [07-review-gate.md](07-review-gate.md)가 SSOT이며, 이 섹션은 정책만 정의한다.

| 실패 유형 | 원인 분류 | 복구 담당 | 복구 후 |
|-----------|----------|----------|--------|
| `codex-branch-review` FAIL | 코드/설계 문제 | Claude 개발 에이전트 | 같은 브랜치에서 수정 후 재push |
| CI 실패 — 코드 문제 | 테스트/lint/type 오류 | Claude 개발 에이전트 | 새 커밋 push 후 체크 재실행 |
| CI 실패 — 인프라 문제 | Docker/CI 설정/스크립트 | `@devops` | 수정 후 동일 PR에서 재실행 |
| `claude-pr-approve` FAIL — `content` | 스펙·계약·테스트 누락 | Claude 자동 재수정 워커 | 동일 PR 브랜치 수정 후 재검증 |
| `codex-pr-approve` FAIL — `content` | 버그/회귀/설계 위반 | Claude 자동 재수정 워커 | 동일 PR 브랜치 수정 후 재검증 |
| `claude-pr-approve` FAIL — `quota/script_error/auth_error/infra_error` | AI CLI/runner 문제 | `@devops` 또는 사람 개입 | 재수정 없이 워커 복구 후 재실행 |
| `codex-pr-approve` FAIL — `quota/script_error/auth_error/infra_error` | AI CLI/runner 문제 | `@devops` 또는 사람 개입 | 재수정 없이 워커 복구 후 재실행 |
| QA FAIL | 기능 버그 | 오케스트레이터가 버그 이슈 등록 → Claude 개발 에이전트 | 재검증 속행 |

### 5.1 재시도 규칙

- 동일 head SHA에 대해 같은 실패를 반복 판정하지 않는다. 새 커밋이 push되어야 새 시도로 본다.
- 이슈 코멘트에 Codex 브랜치 리뷰 실패 횟수를 누적한다.
- 같은 blocking finding 제목이 2회 이상 연속 반복되면 escalation 신호로 본다.
- 같은 `risk class` failure가 2회 반복되면 `@code-reviewer` 메타 리뷰를 호출하고, 그 전까지는 얕은 auto-fix만 반복하지 않는다.
- 반복되는 구조 리스크가 현재 계획 자체의 문제로 보이면, 다시 구현을 밀기보다 조건부 계획 리뷰 단계로 되돌린다.
- 동일 유형의 blocking failure가 10회 누적되면 `blocked:review-loop` 라벨을 붙이고 자동 브랜치 리뷰를 중단한다.
- `blocked:review-loop`가 최초 부착되거나, PR 자동 재수정 결과가 `NO_CHANGES`로 끝나면 얕은 자동 수정 루프를 중단하고 `@code-reviewer` 메타 리뷰 또는 사람 확인을 우선한다.
- Codex 브랜치 리뷰에서 잡힌 이슈는 PR 생성 전에 해소해야 한다.
- PR 승인 단계에서는 `content` 실패에 한해 Claude 자동 재수정을 최대 10회 시도한다.
- 자동 재수정 전에는 `.agent/skills/receive-review.md` 규칙으로 finding을 재서술하고 영향 범위를 다시 그린다.
- `quota`, `script_error`, `auth_error`, `infra_error`는 자동 재수정 예산에 포함하지 않는다.
- PR 승인 content 실패가 10회 재수정 후에도 해소되지 않으면 `blocked:pr-review-loop` 라벨을 붙이고 자동 재수정을 중단한다.
- PR 승인에서 `lifecycle`, `contract-drift`, `generated-artifact-sync` 같은 구조 리스크가 2회 반복되면 자동 재수정보다 `@code-reviewer` 또는 사람 개입을 우선한다.

### 5.2 승인 루프 수동 복구

- 같은 head SHA에서 워크플로우/러너 문제로 보이는 실패는 코드 수정 없이 `gh run rerun`을 우선한다.
- `NO_CHANGES`는 성공이 아니라 “자동 수정이 안전한 패치를 만들지 못했다”는 신호로 해석한다.
- `pull_request` 이벤트 자체가 누락되었거나 재트리거가 꼭 필요할 때만 PR `close → reopen`을 예외적으로 허용한다.
- 수동 복구를 수행한 경우 PR 또는 이슈 코멘트에 다음을 남긴다.
  - 왜 자동 루프로 복구되지 않았는지
  - 어떤 방식으로 재트리거했는지
  - 새 run 링크 또는 확인 근거

## 6. 리뷰와 머지 게이트

> 상세 규칙: [07-review-gate.md](07-review-gate.md)

- **브랜치 리뷰 단계**: Codex만 수행한다. PR 전 품질 게이트다.
- **PR 승인 단계**: Claude와 Codex가 각각 독립적으로 수행한다.
- **메타 리뷰 단계**: `@code-reviewer`는 상시 게이트가 아니라, 고위험 변경과 반복 failure에서만 호출한다.
- **소스 오브 트루스**: GitHub PR review 코멘트보다 **status check 결과**를 merge gate의 기준으로 삼는다.
- **머지 담당**: GitHub auto-merge
- **이슈 close**: PR 본문의 `Closes #N`으로 GitHub 기본 auto-close를 우선 사용하고, `post-merge`가 체크박스/에픽 동기화와 수동 복구를 맡는다.
- **원격 브랜치 삭제**: GitHub의 "Automatically delete head branches" 기능 사용
- **로컬 worktree 정리**: Claude 측에서 후속 작업 시 `git worktree prune` 또는 명시적 remove

## 7. 생성 문서 동기화 규칙

`docs/architecture/generated/` 하위 문서는 소스 코드에서 추출한 정보를 정리한 것이다. 해당 소스가 변경되면 반드시 생성 문서도 함께 갱신한다.

| 생성 문서 | 갱신 트리거 | 대상 소스 | 갱신 방법 |
|-----------|-----------|----------|----------|
| `guide/cli.md` | 명령어 추가/삭제, 인자·옵션·scope 변경 | `src/ante/cli/commands/` | `python scripts/generate_cli_reference.py` |
| `docs/architecture/generated/db-schema.md` | CREATE TABLE / CREATE INDEX 변경, 테이블 추가/삭제 | `src/ante/**/` 내 `_DDL` 상수 | `python scripts/generate_db_schema.py` |
| `docs/architecture/generated/project-structure.md` | 디렉토리·모듈 추가/삭제/이동 | 프로젝트 디렉토리 트리 | 수동 편집 |

### 7.1 자동 생성 스크립트

| 문서 | 스크립트 | 비고 |
|------|---------|------|
| `guide/cli.md` | `python scripts/generate_cli_reference.py` | 스크립트가 SSOT이며 수동 편집 금지 |
| `docs/architecture/generated/db-schema.md` | `python scripts/generate_db_schema.py` | 스크립트가 SSOT이며 수동 편집 금지 |
| `docs/architecture/generated/project-structure.md` | 미구현 | 디렉토리 구조 변경 시 수동 편집 |

### 7.2 갱신 규칙

- **CLI 변경 시**: `guide/cli.md`를 재생성한다.
- **DDL 변경 시**: `db-schema.md`를 재생성한다.
- **디렉토리 구조 변경 시**: `project-structure.md`를 갱신한다.
- **API 엔드포인트**: Swagger UI(`/docs`)에 자동 반영되므로 별도 문서 갱신은 불필요하다.

## 8. API 스키마 변경 규칙

API 응답 스키마(`src/ante/web/schemas.py`의 Pydantic 모델)는 백엔드와 프론트엔드 양쪽에 영향을 미치는 계약(contract)이다. 스키마 변경은 별도 이슈로 분리하여 양쪽 영향을 통제한다.

### 8.1 스키마 변경 = 별도 이슈

- `src/ante/web/schemas.py`의 Pydantic 모델 추가·수정·삭제는 **구현 이슈와 분리하여 별도 이슈로 등록**한다.
- 구현 이슈 진행 중 스키마 변경이 필요하다고 판단되면, 해당 이슈 안에서 직접 변경하지 않고 새 이슈를 발행한다.
- 스키마 변경 이슈와 구현 이슈 사이에 의존성을 명시한다.

### 8.2 오케스트레이터 검증

- 오케스트레이터는 구현 요청에 API 스키마 변경이 포함되어 있는지 감지한다.
- 스키마 변경이 감지되면, 스키마 변경을 별도 이슈로 분리하도록 안내한다.
- API 스키마 변경 이슈는 오케스트레이터가 **백엔드·프론트엔드 양쪽 영향**을 확인한 뒤 진행한다.

### 8.3 백엔드 규칙

- 모든 새 엔드포인트는 반드시 `response_model`을 명시한다.
- `dict`를 직접 반환하는 것은 금지한다.
- 기존 `response_model` 변경은 별도 스키마 변경 이슈를 거친다.

### 8.4 프론트엔드 규칙

- API 응답 타입은 `openapi-typescript`로 자동 생성된 `api.generated.ts`에서만 import한다.
- 수동으로 API 응답 인터페이스를 정의하지 않는다.
- 스키마 변경 이슈가 머지되면 `npm run generate-types`로 타입을 재생성한다.
- 백엔드에 존재하지 않는 API를 프론트엔드에서 임의로 만들지 않는다.

## 9. AGENTS.md 경량화 원칙

AGENTS.md는 모든 세션에 주입되므로 핵심 규칙만 유지한다.

- 핵심 설계 원칙, 기술 스택, 디렉토리 구조만 유지
- 모듈별 세부 설계는 `docs/specs/`에 분리
- 상세 가이드는 `.agent/skills/`로 분리

## 관련 문서

| 문서 | 내용 |
|------|------|
| [00-issue-management.md](00-issue-management.md) | 이슈 등록, 분류, 추적 규칙 |
| [02-agent-structure.md](02-agent-structure.md) | Claude 역할과 Codex 외부 리뷰 워커 구조 |
| [03-git-workflow.md](03-git-workflow.md) | 커밋 컨벤션, 브랜치/PR 규칙 |
| [04-ci-cd.md](04-ci-cd.md) | CI/CD 파이프라인과 status check 구성 |
| [05-testing.md](05-testing.md) | 테스트 전략, 커버리지 기준 |
| [07-review-gate.md](07-review-gate.md) | 브랜치 리뷰, PR 승인, merge gate 상세 |
