오픈 이슈를 QA 엔지니어 관점에서 순회하며, TC 추가 작성 및 보완 필요 여부를 파악하고 GitHub 코멘트로 남긴다.

GitHub 조회/코멘트 절차는 `.agent/skills/github-ops.md`를 따르고, 쓰기 작업 전 인증은 `.agent/skills/github-auth.md`를 먼저 따른다.

## 인자

$ARGUMENTS — 옵션 (생략 가능)
- 없음: 전체 오픈 이슈 대상 (`feature`, `bug`, `epic` 라벨)
- `--label {라벨}`: 특정 라벨의 이슈만 대상
- `#{번호}`: 단일 이슈만 대상

## 목적

구현 완료 후 QA 검증이 원활하게 이루어지려면, 이슈의 수용 조건에 대응하는 TC가 사전에 준비되어야 한다.
이 커맨드는 오픈 이슈를 순회하며 다음을 확인한다:

1. 이슈의 수용 조건을 검증할 TC가 이미 존재하는가
2. 기존 TC가 수용 조건을 충분히 커버하는가
3. 새 TC 작성 또는 기존 TC 보완이 필요한가

## 실행 절차

### 1단계: 이슈 목록 수집

```bash
# 전체 모드
gh issue list --state open --label "feature,bug,epic" --limit 50 --json number,title,labels,body

# 단일 이슈 모드
gh issue view #{번호} --json number,title,labels,body
```

기존 QA 리뷰는 먼저 확인하되, 아래 경우에는 **refresh 리뷰**를 새 코멘트로 다시 남긴다:
```bash
gh issue view #{번호} --json comments --jq '.comments[].body' | rg "🧪 \\*\\*QA 리뷰\\*\\*"
```

- 최신 리뷰에 `verdict:` 필드가 없다
- 최신 verdict가 `blocked` 또는 `caution`인데, 수용 조건/TC 경로/선행 이슈가 이후 정리되었다
- 사용자가 `/qa-review`를 다시 호출해 최신 판단을 요청했다

같은 헤더가 있다는 이유만으로 무조건 스킵하지 않는다. verdict를 구현 게이트로 사용하는 이상, 최신 TC 판단으로 갱신할 수 있어야 한다.

### 2단계: 이슈별 분석

각 이슈에 대해 다음을 순서대로 수행한다.

#### 2-1. 수용 조건 추출

이슈 본문에서 수용 조건(Acceptance Criteria)을 추출한다.
수용 조건은 보통 다음 형태로 기술된다:
- `- [ ]` 체크박스 목록
- "수용 조건" / "완료 조건" 섹션
- 유저스토리의 Then 절

각 수용 조건을 개별 검증 항목으로 분리한다.

#### 2-2. 기존 TC 매칭

`tests/tc/` 하위의 `.feature` 파일을 탐색하여, 수용 조건과 대응하는 시나리오가 있는지 확인한다.

매칭 기준:
- 이슈가 변경하는 모듈에 대응하는 TC 카테고리 (`tests/tc/{카테고리}/`)
- 시나리오 이름(`Scenario:`)이나 스텝(`Given/When/Then`)이 수용 조건의 동작을 검증하는가
- API 엔드포인트, CLI 커맨드 등 구체적 검증 대상이 일치하는가

| 이슈 변경 대상 | TC 카테고리 |
|---------------|------------|
| `src/ante/account/` | `tests/tc/account/` |
| `src/ante/bot/` | `tests/tc/bot/` |
| `src/ante/strategy/` | `tests/tc/strategy/` |
| `src/ante/treasury/` | `tests/tc/treasury/` |
| `src/ante/trade/` | `tests/tc/trade/` |
| `src/ante/member/` | `tests/tc/member/` |
| `src/ante/approval/` | `tests/tc/approval/` |
| `src/ante/config/` | `tests/tc/config/` |
| `src/ante/data/` | `tests/tc/data/` |
| CLI / 초기 설정 | `tests/tc/scenario/` |

#### 2-3. 검토 체크리스트

##### A. TC 커버리지

| # | 검토 항목 |
|---|----------|
| A1 | 이슈의 각 수용 조건에 대응하는 시나리오가 존재하는가 |
| A2 | 커버되지 않는 수용 조건이 있다면, 어떤 시나리오를 추가해야 하는가 |
| A3 | 기존 시나리오가 있지만 수용 조건의 변경으로 인해 수정이 필요한가 |

##### B. 시나리오 품질

| # | 검토 항목 |
|---|----------|
| B1 | 정상 경로(happy path)뿐 아니라 에러 경로(에러 응답, 유효성 검증 실패 등)도 커버되는가 |
| B2 | 경계값 케이스가 있다면 시나리오에 포함되어 있는가 (빈 목록, 0, 음수, 최대값 등) |
| B3 | 기존 TC의 Gherkin 문법이 `gherkin-guide.md` 규칙에 맞는가 (변수 치환, API 스텝 패턴 등) |

##### C. 의존성 및 실행 순서

| # | 검토 항목 |
|---|----------|
| C1 | 새 TC가 기존 TC에 의존하는 선행 데이터(계좌, 전략, 봇 등)를 필요로 하는가 |
| C2 | `qa-sweep`의 실행 순서(scenario → member → account → ... → data)에서 새 TC의 위치가 적절한가 |
| C3 | Background 단계에서 필요한 사전 조건이 누락되지 않았는가 |

##### D. 에픽 이슈 전용 (epic 라벨인 경우)

| # | 검토 항목 |
|---|----------|
| D1 | 각 하위 이슈의 TC 현황을 개별 파악하고 요약 |
| D2 | 하위 이슈 간 통합 시나리오(end-to-end)가 필요한가 |

### 3단계: 코멘트 작성 및 게시

```bash
gh issue comment #{이슈번호} --body "{코멘트}"
```

코멘트 포맷:

```markdown
🧪 **QA 리뷰**

### 판정
- verdict: `ready | caution | blocked`
- next-step: `implement-issue | add-tc-followup | invoke-human`
- review-mode: `fresh | refresh`

### TC 커버리지 현황

| 수용 조건 | 기존 TC | 상태 |
|-----------|---------|------|
| {수용 조건 1 요약} | `tests/tc/{카테고리}/{파일}.feature` Scenario: {이름} | ✅ 커버됨 |
| {수용 조건 2 요약} | — | ❌ TC 없음 |
| {수용 조건 3 요약} | `tests/tc/{카테고리}/{파일}.feature` Scenario: {이름} | ⚠️ 보완 필요 |

### TC 추가/보완 제안

{실제 제안이 있는 경우만 작성}

1. **{제안 제목}**: {상세 — 어떤 파일에 어떤 시나리오를 추가/수정해야 하는지}
   ```gherkin
   Scenario: {시나리오 이름 초안}
     Given {전제 조건}
     When {동작}
     Then {기대 결과}
   ```

2. ...

### 에러/경계값 케이스
{B1~B2 검토 결과 추가 커버리지가 필요한 경우만 작성}

- {케이스 설명}

---
🤖 Reviewed by Claude Code (`/qa-review`)
```

**작성 원칙:**

1. **구체적 Gherkin 초안 제공**: "시나리오가 필요합니다"로 끝내지 않고, 실행 가능한 수준의 Gherkin 초안을 제안한다.
2. **기존 TC 참조**: 새 시나리오 작성 시, 같은 카테고리의 기존 `.feature` 파일 스타일(Background, 변수명, 스텝 패턴)을 따르도록 안내한다.
3. **과도한 TC 방지**: 수용 조건에 직접 대응하는 TC만 제안한다. 이슈 범위를 넘는 "있으면 좋을" TC는 제안하지 않는다.
4. **QA 환경 고려**: TC 초안은 Docker QA 환경(`ante-qa` 컨테이너)에서 실행 가능한 형태로 작성한다. `gherkin-guide.md`의 스텝 패턴을 준수한다.
5. **판정 명시**: 구현을 바로 시작할 수 있는지(`ready`), 구현은 가능하지만 TC follow-up이 필요한지(`caution`), 수용 조건/검증 경로가 불명확해 사람 판단이 먼저인지(`blocked`)를 명확히 남긴다.
6. **refresh 허용**: 이전 QA 리뷰가 있어도 verdict가 오래되었거나 수용 조건/TC 정보가 바뀌면 같은 헤더로 새 코멘트를 남겨 최신 verdict를 갱신한다.

### 4단계: 결과 요약

```
## QA 리뷰 완료

| 이슈 | 제목 | TC 현황 |
|------|------|---------|
| #101 | 계좌 CRUD | ✅ 전체 커버 |
| #102 | 봇 라이프사이클 | ⚠️ 에러 경로 TC 2건 추가 제안 |
| #103 | 리스크 엔진 | ❌ TC 없음 — 신규 3건 제안 |

리뷰 완료: {N}건
기존 리뷰 재사용: {M}건
refresh 리뷰: {K}건
TC 추가 제안: {총 건수}건
TC 보완 제안: {총 건수}건
```
