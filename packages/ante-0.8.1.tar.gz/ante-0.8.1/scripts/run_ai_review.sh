#!/bin/bash
set -euo pipefail

ENGINE="${1:?engine is required (claude|codex)}"
PHASE="${2:?phase is required (branch|pr)}"

WORKSPACE="${GITHUB_WORKSPACE:-$(pwd)}"
SCHEMA_PATH="$WORKSPACE/.github/review-output.schema.json"
TMP_DIR="$(mktemp -d)"
RAW_PATH="$TMP_DIR/raw.json"
RESULT_PATH="$TMP_DIR/result.json"
SUMMARY_PATH="$TMP_DIR/summary.md"
STATUS_PATH="${REVIEW_STATUS_PATH:-$TMP_DIR/status.json}"
CLAUDE_BIN="${CLAUDE_BIN:-$HOME/actions-runners/bin/claude}"
CODEX_BIN="${CODEX_BIN:-$HOME/actions-runners/bin/codex}"

HEAD_REF="${HEAD_REF:-${GITHUB_HEAD_REF:-${GITHUB_REF_NAME:-$(git branch --show-current)}}}"
DEFAULT_BRANCH="${DEFAULT_BRANCH:-main}"
BASE_REF="${BASE_REF:-}"

cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

copy_review_artifacts() {
  if [[ -n "${REVIEW_RESULT_PATH:-}" && -f "$RESULT_PATH" && "$RESULT_PATH" != "$REVIEW_RESULT_PATH" ]]; then
    cp "$RESULT_PATH" "$REVIEW_RESULT_PATH"
  fi

  if [[ -n "${REVIEW_SUMMARY_PATH:-}" && -f "$SUMMARY_PATH" && "$SUMMARY_PATH" != "$REVIEW_SUMMARY_PATH" ]]; then
    cp "$SUMMARY_PATH" "$REVIEW_SUMMARY_PATH"
  fi

  if [[ -n "${REVIEW_RAW_PATH:-}" && -f "$RAW_PATH" && "$RAW_PATH" != "${REVIEW_RAW_PATH}" ]]; then
    cp "$RAW_PATH" "$REVIEW_RAW_PATH"
  fi
}

write_failure_status() {
  python3 "$WORKSPACE/scripts/ai_review.py" classify-failure \
    --engine "$ENGINE" \
    --phase "$PHASE" \
    --input "$RAW_PATH" \
    --output "$STATUS_PATH"
  copy_review_artifacts
}

write_completed_status() {
  python3 "$WORKSPACE/scripts/ai_review.py" build-review-status \
    --engine "$ENGINE" \
    --phase "$PHASE" \
    --input "$RESULT_PATH" \
    --output "$STATUS_PATH"
  copy_review_artifacts
}

BASE_REF="$(
  python3 "$WORKSPACE/scripts/ai_review.py" detect-base \
    --head-ref "$HEAD_REF" \
    --default-branch "$DEFAULT_BRANCH" \
    --base-ref "$BASE_REF"
)"

BASE_SHORT="${BASE_REF#origin/}"
git fetch --no-tags origin "$BASE_SHORT" || true

if [[ "$PHASE" == "branch" ]]; then
  REVIEW_ROLE="$ENGINE branch reviewer"
  PHASE_GOAL="PR을 만들기 전 브랜치 단위 사전 리뷰"
else
  REVIEW_ROLE="$ENGINE PR approver"
  PHASE_GOAL="PR head SHA 기준 최종 승인 판정"
fi

PROMPT=$(cat <<EOF
You are the $REVIEW_ROLE for the ANTE repository.

Context:
- Workspace root: $WORKSPACE
- Phase: $PHASE
- Goal: $PHASE_GOAL
- Base ref: $BASE_REF
- Head ref: $HEAD_REF

Instructions:
1. Review the current checkout against $BASE_REF.
2. Focus only on blocking issues: correctness bugs, regressions, spec/contract violations, missing critical tests, security issues.
3. Use AGENTS.md, docs/architecture/README.md, docs/runbooks/07-review-gate.md, and relevant docs/specs for changed modules as the source of truth.
4. Do not modify files.
5. Approve only if there are zero blocking findings.
6. Return JSON that matches the provided schema exactly.

Helpful commands you may use:
- git diff --name-only $BASE_REF...HEAD
- git diff $BASE_REF...HEAD
- rg -n "pattern" path
- sed -n '1,200p' file
EOF
)

if [[ "$ENGINE" == "codex" ]]; then
  # `set -e` already aborts the script when the codex CLI exits non-zero,
  # so we rely on that for exec-level failure visibility. The structured
  # output lives in `$RESULT_PATH` and is validated downstream.
  set +e
  "$CODEX_BIN" exec \
    --cd "$WORKSPACE" \
    --sandbox read-only \
    --output-schema "$SCHEMA_PATH" \
    --output-last-message "$RESULT_PATH" \
    "$PROMPT" > "$RAW_PATH" 2>&1
  CODEX_EXIT=$?
  set -e

  if [[ "$CODEX_EXIT" -ne 0 ]]; then
    echo "::error title=Codex CLI failed::Codex CLI exited with status $CODEX_EXIT" >&2
    echo "----- Codex CLI raw output (exit $CODEX_EXIT) -----" >&2
    if [[ -s "$RAW_PATH" ]]; then
      cat "$RAW_PATH" >&2
    else
      echo "(raw output is empty)" >&2
    fi
    echo "----- end raw output -----" >&2
    write_failure_status
    exit 1
  fi

  if [[ ! -s "$RESULT_PATH" ]]; then
    printf '%s\n' "Codex CLI finished without writing a structured review result." >> "$RAW_PATH"
    echo "::error title=Codex result missing::Codex CLI did not create $RESULT_PATH" >&2
    write_failure_status
    exit 1
  fi
elif [[ "$ENGINE" == "claude" ]]; then
  CLAUDE_SCHEMA="$(python3 - <<'PY' "$SCHEMA_PATH"
import json, sys
from pathlib import Path
print(json.dumps(json.loads(Path(sys.argv[1]).read_text()), separators=(",", ":")))
PY
)"
  # Feed the review prompt via stdin. `--add-dir` is variadic, so passing the
  # prompt positionally after it can be parsed as another directory instead of
  # the actual print-mode input. We stage the prompt in a temp file and
  # redirect it as stdin so we can capture the CLI's exit code directly
  # (pipelines under `pipefail` make exit-code capture fragile).
  PROMPT_FILE="$TMP_DIR/prompt.txt"
  printf '%s' "$PROMPT" > "$PROMPT_FILE"

  set +e
  "$CLAUDE_BIN" -p \
    --output-format json \
    --json-schema "$CLAUDE_SCHEMA" \
    --allowedTools "Bash(git *) Bash(rg *) Bash(cat *) Bash(sed *) Read Glob Grep" \
    --add-dir "$WORKSPACE" \
    < "$PROMPT_FILE" > "$RAW_PATH"
  CLAUDE_EXIT=$?
  set -e

  if [[ "$CLAUDE_EXIT" -ne 0 ]]; then
    echo "::error title=Claude CLI failed::Claude CLI exited with status $CLAUDE_EXIT" >&2
    echo "----- Claude CLI raw output (exit $CLAUDE_EXIT) -----" >&2
    if [[ -s "$RAW_PATH" ]]; then
      cat "$RAW_PATH" >&2
    else
      echo "(raw.json is empty)" >&2
    fi
    echo "----- end raw output -----" >&2
    write_failure_status
    exit 1
  fi

  # Claude CLI sometimes exits 0 even when the session itself failed
  # (auth, tool error, etc). In that case the JSON payload carries
  # `is_error: true` and a human-readable `result`. Surface it so the
  # failure is visible in the CI log instead of silently falling through.
  set +e
  python3 - "$RAW_PATH" <<'PY'
import json, sys
from pathlib import Path
try:
    data = json.loads(Path(sys.argv[1]).read_text())
except Exception:
    sys.exit(0)
if isinstance(data, dict) and data.get("is_error") is True:
    sys.exit(1)
sys.exit(0)
PY
  IS_ERROR_EXIT=$?
  set -e

  if [[ "$IS_ERROR_EXIT" -ne 0 ]]; then
    RESULT_MSG="$(python3 - "$RAW_PATH" <<'PY'
import json, sys
from pathlib import Path
try:
    data = json.loads(Path(sys.argv[1]).read_text())
except Exception as exc:
    print(f"(failed to parse raw.json: {exc})")
    sys.exit(0)
if isinstance(data, dict):
    print(data.get("result") or data.get("error") or "(no result field)")
else:
    print("(raw.json is not an object)")
PY
)"
    echo "::error title=Claude CLI session error::${RESULT_MSG}" >&2
    echo "----- Claude CLI raw output (is_error=true) -----" >&2
    cat "$RAW_PATH" >&2
    echo "----- end raw output -----" >&2
    write_failure_status
    exit 1
  fi

  set +e
  python3 "$WORKSPACE/scripts/ai_review.py" extract-claude --input "$RAW_PATH" --output "$RESULT_PATH"
  EXTRACT_EXIT=$?
  set -e

  if [[ "$EXTRACT_EXIT" -ne 0 ]]; then
    printf '\nClaude structured output extraction failed (exit %s).\n' "$EXTRACT_EXIT" >> "$RAW_PATH"
    echo "::error title=Claude output parse failed::Failed to extract structured review output" >&2
    write_failure_status
    exit 1
  fi
else
  echo "Unknown engine: $ENGINE" >&2
  exit 2
fi

python3 "$WORKSPACE/scripts/ai_review.py" render \
  --engine "$ENGINE" \
  --phase "$PHASE" \
  --input "$RESULT_PATH" > "$SUMMARY_PATH"

write_completed_status

cat "$SUMMARY_PATH"

if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
  cat "$SUMMARY_PATH" >> "$GITHUB_STEP_SUMMARY"
fi

APPROVED="false"
if python3 "$WORKSPACE/scripts/ai_review.py" check --input "$RESULT_PATH"; then
  APPROVED="true"
fi

if [[ -n "${GITHUB_OUTPUT:-}" ]]; then
  {
    echo "approved=$APPROVED"
    echo "base_ref=$BASE_REF"
  } >> "$GITHUB_OUTPUT"
fi

if [[ "$APPROVED" != "true" ]]; then
  exit 1
fi
