# VulnFeed — Marketplace Listing Content

Use this content when submitting to MCP directories.

## Name
VulnFeed

## Tagline
Dependency vulnerability monitoring for Claude Code. Knows your lockfile, prioritizes by exploit probability, tells you what matters.

## Description (short — 280 chars)
An MCP server that scans your lockfiles (npm, PyPI, Go, Rust, Ruby, PHP) for known vulnerabilities, enriches with EPSS exploit probability scores, and recommends fix versions. $14/mo — not per-seat.

## Description (full)
VulnFeed monitors your project's dependencies for security vulnerabilities — native to Claude Code.

**What it does:**
- Reads your lockfile (package-lock.json, requirements.txt, go.sum, Cargo.lock, Gemfile.lock, composer.lock, yarn.lock, Pipfile.lock, pnpm-lock.yaml)
- Queries NVD + GitHub Advisory Database for known CVEs
- Enriches with EPSS (Exploit Prediction Scoring System) scores to filter noise
- Recommends exact fix versions from package registries
- Monitors projects continuously — get alerts when new CVEs drop

**9 tools:**
- `scan_project` — auto-detect and scan all lockfiles in a directory
- `scan_lockfile` — scan a specific lockfile
- `check_package` — check a single package for vulns
- `lookup_cve` — detailed CVE info with EPSS + fix versions
- `monitor_project` — register for continuous monitoring
- `check_alerts` — new vulns since last scan
- `update_deps` — update snapshot after upgrading packages
- `list_monitored` — see all monitored projects
- `unmonitor_project` — remove from monitoring

**Free tier:** 10 scans/day, 1 monitored project. No signup required.
**Paid:** $14/mo via Polar.sh. Unlimited scans + projects.

## Homepage
https://vulnfeed.novadyne.ai

## Purchase URL
https://buy.polar.sh/polar_cl_l2u7OfEs3L3NaMKsCQByy271MbERK5JO6ePqR0mRfBj

## Transport
stdio (local install), SSE (remote)

## Tool count
9

## Supported ecosystems
npm, PyPI, Go, crates.io, RubyGems, Packagist (9 lockfile formats)

## Author
Novadyne (an Infai company)

## Install snippet

**Free tier** (no signup, 10 scans/day):
```json
{
  "mcpServers": {
    "vulnfeed": {
      "command": "uvx",
      "args": ["vulnfeed-mcp"]
    }
  }
}
```

**Paid** ($14/mo, unlimited):
```json
{
  "mcpServers": {
    "vulnfeed": {
      "command": "uvx",
      "args": ["vulnfeed-mcp"],
      "env": {
        "VULNFEED_API_KEY": "YOUR_LICENSE_KEY_HERE"
      }
    }
  }
}
```

## GitHub
https://github.com/infai-tech/vulnfeed-mcp

## PyPI
https://pypi.org/project/vulnfeed-mcp/ — LIVE. `uvx vulnfeed-mcp` works now.

## Categories
- Security
- DevOps
- Dependency management
- Vulnerability scanning

---

## Submission steps — do these in order

### 1. mcp.so (biggest directory, ~2 min)
1. Go to https://mcp.so/submit (or find the "Submit" link on the homepage)
2. Fill in:
   - **Name:** VulnFeed
   - **GitHub URL:** https://github.com/infai-tech/vulnfeed-mcp
   - **Description:** (paste the "Description (short)" above)
   - **Homepage:** https://vulnfeed.novadyne.ai
   - **Install config:** (paste the free-tier JSON snippet above)
   - **PyPI:** https://pypi.org/project/vulnfeed-mcp/
   - **Categories:** Security, DevOps
3. Submit. They typically list within 24-48h.

### 2. glama.ai (~2 min)
1. Go to https://glama.ai/mcp/servers
2. Click "Submit a server" or "Add Server"
3. Fill in:
   - **GitHub URL:** https://github.com/infai-tech/vulnfeed-mcp
   - **Package name:** vulnfeed-mcp (on PyPI)
   - **Homepage:** https://vulnfeed.novadyne.ai
   - **Description:** (paste the "Description (short)" above)
   - **Install config:** (paste the free-tier JSON snippet above)
4. Submit.

### 3. Smithery (smithery.ai, ~5 min)
1. Go to https://smithery.ai and create a publisher account
2. Click "Publish" or "Add Server"
3. Fill in:
   - **Name:** VulnFeed
   - **GitHub URL:** https://github.com/infai-tech/vulnfeed-mcp
   - **Description:** (paste "Description (full)" above)
   - **Install:** `uvx vulnfeed-mcp`
   - **Auth method:** API key (env var `VULNFEED_API_KEY`)
   - **Pricing:** Free tier (10 scans/day) + $14/mo paid
   - **Homepage:** https://vulnfeed.novadyne.ai
4. Submit.
