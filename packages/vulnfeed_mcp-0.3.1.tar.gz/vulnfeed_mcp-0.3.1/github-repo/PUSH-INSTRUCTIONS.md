# How to create the public GitHub repo

The MCP marketplaces (mcp.so, glama.ai, Smithery) require a GitHub URL.
The code is already public on PyPI — this just gives it a browsable home.

## Steps

1. Create a new public repo on GitHub:
   - Org: `infai-tech` (or whatever GitHub org you prefer)
   - Name: `vulnfeed-mcp`
   - Description: "Dependency vulnerability monitoring MCP server"
   - Public, no template, no README (we have one)

2. From this directory (`products/security-mcp/github-repo/`):
   ```bash
   cd products/security-mcp/github-repo
   git init
   git add .
   git commit -m "Initial release — VulnFeed MCP v0.3.0"
   git remote add origin git@github.com:infai-tech/vulnfeed-mcp.git
   git push -u origin main
   ```

3. Use `https://github.com/infai-tech/vulnfeed-mcp` as the GitHub URL
   in marketplace submissions.

## What's in this repo

- `vulnfeed_mcp/` — the MCP server package (same code as PyPI)
- `pyproject.toml` — package metadata
- `README.md` — user-facing docs with install + setup
- `LICENSE` — MIT
- `.gitignore`

The backend (Worker) stays private. This repo is just the client that
talks to the backend — same as what's already public on PyPI.

## If you prefer a different org/name

Update the `[project.urls]` in `pyproject.toml` and the marketplace listing
at `products/security-mcp/marketplace/listing.md` to match.
