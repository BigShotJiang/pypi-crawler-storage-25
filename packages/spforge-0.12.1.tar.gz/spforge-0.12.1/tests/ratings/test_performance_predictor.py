import pickle

import polars as pl
import pytest

from spforge.data_structures import ColumnNames
from spforge.ratings import (
    PerformancePredictor,
    PlayerRatingGenerator,
    PredictedPerformanceOptimizer,
    RatingKnownFeatures,
    RatingUnknownFeatures,
    TeamRatingGenerator,
)
from spforge.ratings.player_performance_predictor import (
    RatingPlayerDifferencePerformancePredictor,
    create_performance_predictor,
)


def test_performance_predictor__uses_sigmoid_by_default():
    predictor = PerformancePredictor(coefficients={"rating_difference": 0.01})

    prediction = predictor.predict({"rating_difference": 0.0})

    assert prediction == pytest.approx(0.5)


def test_performance_predictor__can_return_unbounded_linear_prediction():
    predictor = PerformancePredictor(
        coefficients={"rating_difference": 0.0},
        intercept=2.0,
        sigmoid=False,
    )

    prediction = predictor.predict({"rating_difference": 10.0})

    assert prediction == pytest.approx(2.0)


def test_performance_predictor__uses_injected_feature_coefficients():
    predictor = PerformancePredictor(
        coefficients={"rating_difference": 0.0, "is_playoffs": -0.1},
        intercept=0.5,
        sigmoid=False,
    )

    prediction = predictor.predict({"rating_difference": 0.0, "is_playoffs": 1.0})

    assert prediction == pytest.approx(0.4)


def test_performance_predictor__unpickles_state_without_target_model_fields():
    predictor = PerformancePredictor(coefficients={"rating_difference": 0.01})
    for attr in [
        "_target_model_explicit",
        "target_model_name",
        "target_model",
        "fit_features",
        "fit_intercept",
        "fit_regularization",
        "selected_target_model",
    ]:
        delattr(predictor, attr)

    restored = pickle.loads(pickle.dumps(predictor))

    assert restored.predict({"rating_difference": 0.0}) == pytest.approx(0.5)
    assert restored.selected_target_model == "logistic"


def test_legacy_rating_difference_predictor__unpickles_as_current_predictor():
    predictor = RatingPlayerDifferencePerformancePredictor.__new__(
        RatingPlayerDifferencePerformancePredictor
    )
    predictor.rating_diff_coef = 0.01
    predictor.rating_diff_team_from_entity_coef = 0.02
    predictor.team_rating_diff_coef = 0.03
    predictor.max_predict_value = 0.9
    predictor.participation_weight_coef = None

    restored = pickle.loads(pickle.dumps(predictor))

    assert isinstance(restored, PerformancePredictor)
    assert restored.coefficients == {
        "rating_difference": pytest.approx(0.01),
        "rating_diff_team_from_entity": pytest.approx(0.02),
        "team_rating_diff": pytest.approx(0.03),
    }
    assert restored.predict(
        {
            "rating_difference": 0.0,
            "rating_diff_team_from_entity": 0.0,
            "team_rating_diff": -1000.0,
        }
    ) == pytest.approx(0.1)


def test_performance_predictor_fit__learns_linear_context_coefficient():
    predictor = PerformancePredictor(
        coefficients={"rating_difference": 0.0, "home": 0.0},
        sigmoid=False,
        fit_features=["home"],
    )
    df = pl.DataFrame({"home": [0, 0, 1, 1], "perf": [1.0, 1.0, 2.0, 2.0]})

    predictor.fit(df, "perf")

    assert predictor.intercept == pytest.approx(1.0)
    assert predictor.coefficients["home"] == pytest.approx(1.0)
    assert predictor.coefficients["rating_difference"] == pytest.approx(0.0)
    assert predictor.target_mean == pytest.approx(1.5)
    assert predictor.target_zero_fraction == pytest.approx(0.0)


def test_performance_predictor_fit__learns_sigmoid_context_coefficient():
    predictor = PerformancePredictor(
        coefficients={"home": 0.0},
        sigmoid=True,
        fit_features=["home"],
    )
    df = pl.DataFrame({"home": [0, 0, 1, 1], "perf": [0.3, 0.3, 0.7, 0.7]})

    predictor.fit(df, "perf")

    assert predictor.predict({"home": 1.0}) > predictor.predict({"home": 0.0})


def test_performance_predictor_fit__requires_fit_features_in_coefficients():
    with pytest.raises(ValueError, match="fit_features"):
        PerformancePredictor(coefficients={"rating_difference": 0.0}, fit_features=["home"])


def test_performance_predictor_fit__missing_or_non_numeric_columns_raise():
    predictor = PerformancePredictor(
        coefficients={"home": 0.0},
        sigmoid=False,
        fit_features=["home"],
    )

    with pytest.raises(ValueError, match="home"):
        predictor.fit(pl.DataFrame({"perf": [1.0]}), "perf")
    with pytest.raises(ValueError, match="numeric"):
        predictor.fit(pl.DataFrame({"home": ["yes"], "perf": [1.0]}), "perf")


def test_performance_predictor_fit__sigmoid_requires_unit_target():
    predictor = PerformancePredictor(
        coefficients={"home": 0.0},
        sigmoid=True,
        fit_features=["home"],
    )

    with pytest.raises(ValueError, match="between 0 and 1"):
        predictor.fit(pl.DataFrame({"home": [1], "perf": [2.0]}), "perf")


def test_performance_predictor_fit__log1p_learns_skewed_non_negative_target():
    predictor = PerformancePredictor(
        coefficients={"home": 0.0},
        target_model="log1p",
        fit_features=["home"],
    )
    df = pl.DataFrame({"home": [0, 0, 1, 1], "perf": [1.0, 1.0, 7.0, 7.0]})

    predictor.fit(df, "perf")

    assert predictor.selected_target_model == "log1p"
    assert predictor.predict({"home": 0.0}) == pytest.approx(1.0, abs=1e-5)
    assert predictor.predict({"home": 1.0}) == pytest.approx(7.0, abs=1e-5)


def test_performance_predictor_fit__auto_selects_zero_inflated_log1p_for_sparse_rates():
    predictor = PerformancePredictor(
        coefficients={"home": 0.0},
        target_model="auto",
        fit_features=["home"],
    )
    df = pl.DataFrame(
        {
            "home": [0, 0, 0, 1, 0, 1, 0, 1],
            "block_rate": [0.0, 0.0, 0.0, 0.04, 0.0, 0.05, 0.0, 0.06],
        }
    )

    predictor.fit(df, "block_rate")

    assert predictor.selected_target_model == "zero_inflated_log1p"
    assert predictor.predict({"home": 1.0}) > 0.0


def test_performance_predictor_fit__target_model_fits_without_fit_features():
    predictor = PerformancePredictor(
        coefficients={"rating_difference": 0.0},
        target_model="auto",
    )
    df = pl.DataFrame({"block_rate": [0.0, 0.0, 0.0, 0.04]})

    predictor.fit(df, "block_rate")

    assert predictor.selected_target_model == "zero_inflated_log1p"
    assert predictor.predict({"rating_difference": 0.0}) > 0.0


def test_create_performance_predictor__keeps_supported_presets():
    difference = create_performance_predictor("difference", sigmoid=False)
    mean = create_performance_predictor("mean", sigmoid=False)
    ignore_opponent = create_performance_predictor("ignore_opponent", sigmoid=False)

    assert difference.coefficients == {"rating_difference": pytest.approx(0.005757)}
    assert mean.coefficients == {"rating_mean_over_reference": pytest.approx(0.005757)}
    assert ignore_opponent.coefficients == {"rating_over_reference": pytest.approx(0.0015)}


@pytest.mark.parametrize("preset", ["linear_difference", "performance", "learned_linear"])
def test_create_performance_predictor__rejects_removed_presets(preset):
    with pytest.raises(ValueError, match="not supported"):
        create_performance_predictor(preset)


def test_create_performance_predictor__rejects_removed_presets_even_with_coefficients():
    with pytest.raises(ValueError, match="not supported"):
        create_performance_predictor("performance", performance_coefficients={"is_playoffs": 0.0})


def test_rating_generator__removed_participation_weight_coef_fails_fast():
    cn = ColumnNames(player_id="pid", team_id="tid", match_id="mid", start_date="dt")

    with pytest.raises(TypeError, match="participation_weight_coef"):
        PlayerRatingGenerator(
            performance_column="perf",
            column_names=cn,
            participation_weight_coef=0.1,
        )


def test_create_performance_predictor__explicit_coefficients_override_predictor_coefficients():
    predictor = PerformancePredictor(
        coefficients={"rating_difference": 0.01},
        intercept=0.2,
        sigmoid=False,
        requires_centered_target_mean=False,
    )

    resolved = create_performance_predictor(
        predictor,
        performance_coefficients={"rating_difference": 0.0, "is_playoffs": -0.1},
    )

    assert resolved.coefficients == {"rating_difference": 0.0, "is_playoffs": -0.1}
    assert resolved.intercept == pytest.approx(0.2)
    assert resolved.sigmoid is False
    assert resolved.requires_centered_target_mean is False


def test_create_performance_predictor__max_predict_value_keeps_legacy_lower_clamp():
    predictor = create_performance_predictor("difference", max_predict_value=0.9)

    assert predictor.predict({"rating_difference": -1000.0}) == pytest.approx(0.1)


def test_rating_generator__coefficients_override_preset_compatibility_side_effects():
    cn = ColumnNames(player_id="pid", team_id="tid", match_id="mid", start_date="dt")
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2"],
            "tid": ["T1", "T2"],
            "mid": ["M1", "M1"],
            "dt": ["2024-05-01", "2024-05-01"],
            "perf": [0.4, 0.6],
            "is_playoffs": [1, 1],
        }
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor="ignore_opponent",
        performance_coefficients={"rating_difference": 0.0, "is_playoffs": 0.0},
        use_off_def_split=False,
        rating_mean_adjustment_enabled=False,
    )

    out = gen.fit_transform(df)

    assert out.height == 2


def test_player_rating_generator__mean_preset_uses_legacy_historical_reference():
    cn = ColumnNames(player_id="pid", team_id="tid", match_id="mid", start_date="dt")
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2"],
            "tid": ["T1", "T2"],
            "mid": ["M1", "M1"],
            "dt": ["2024-05-01", "2024-05-01"],
            "perf": [0.5, 0.5],
        }
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor="mean",
        use_off_def_split=False,
        start_harcoded_start_rating=1100.0,
        rating_mean_adjustment_enabled=False,
        features_out=[RatingUnknownFeatures.PLAYER_PREDICTED_PERFORMANCE],
    )

    out = gen.fit_transform(df)

    assert out["player_predicted_performance_perf"].to_list() == pytest.approx([0.5, 0.5])


@pytest.mark.parametrize(
    "preset, expected_feature",
    [
        ("difference", RatingKnownFeatures.TEAM_RATING_DIFFERENCE_PROJECTED),
        ("mean", RatingKnownFeatures.RATING_MEAN_PROJECTED),
        ("ignore_opponent", RatingKnownFeatures.TEAM_RATING_PROJECTED),
    ],
)
def test_rating_generator__supported_presets_keep_legacy_default_features(preset, expected_feature):
    cn = ColumnNames(player_id="pid", team_id="tid", match_id="mid", start_date="dt")

    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=preset,
    )

    assert gen.features_out == [f"{expected_feature}_perf"]


def test_player_rating_generator__performance_features_affect_rating_delta():
    cn = ColumnNames(
        player_id="pid",
        team_id="tid",
        match_id="mid",
        start_date="dt",
        participation_weight="pw",
    )
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2", "P3", "P4"],
            "tid": ["T1", "T1", "T2", "T2"],
            "mid": ["M1", "M1", "M1", "M1"],
            "dt": ["2024-05-01"] * 4,
            "perf": [0.4, 0.4, 0.4, 0.4],
            "pw": [1.0, 1.0, 1.0, 1.0],
            "is_playoffs": [1, 1, 1, 1],
        }
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=PerformancePredictor(
            intercept=0.5,
            sigmoid=False,
            requires_centered_target_mean=False,
        ),
        performance_coefficients={"rating_difference": 0.0, "is_playoffs": -0.1},
        use_off_def_split=False,
        start_harcoded_start_rating=1000.0,
        rating_change_multiplier_offense=100.0,
        rating_change_multiplier_defense=100.0,
        rating_mean_adjustment_enabled=False,
        features_out=[RatingUnknownFeatures.PLAYER_PREDICTED_PERFORMANCE],
    )

    out = gen.fit_transform(df)

    assert out.filter(pl.col("pid") == "P1")["player_predicted_performance_perf"][0] == 0.4
    assert gen._player_off_ratings["P1"].rating_value == pytest.approx(1000.0)
    assert gen._player_def_ratings["P1"].rating_value == pytest.approx(1000.0)


def test_player_rating_generator__prefits_context_coefficients_before_rating_updates():
    cn = ColumnNames(player_id="pid", team_id="tid", match_id="mid", start_date="dt")
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2", "P3", "P4"],
            "tid": ["T1", "T2", "T1", "T2"],
            "mid": ["M1", "M1", "M2", "M2"],
            "dt": ["2024-05-01", "2024-05-01", "2024-05-02", "2024-05-02"],
            "perf": [2.0, 1.0, 2.0, 1.0],
            "home": [1, 0, 1, 0],
        }
    )
    predictor = PerformancePredictor(
        coefficients={"rating_difference": 0.0, "home": 0.0},
        sigmoid=False,
        requires_centered_target_mean=False,
        fit_features=["home"],
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=predictor,
        use_off_def_split=False,
        rating_mean_adjustment_enabled=False,
    )

    gen.fit_transform(df)

    assert gen._performance_predictor.coefficients["home"] == pytest.approx(1.0)
    assert gen._performance_predictor.coefficients["rating_difference"] == pytest.approx(0.0)


def test_team_rating_generator__performance_features_affect_rating_delta():
    cn = ColumnNames(team_id="tid", match_id="mid", start_date="dt")
    df = pl.DataFrame(
        {
            "tid": ["T1", "T2"],
            "mid": ["M1", "M1"],
            "dt": ["2024-05-01", "2024-05-01"],
            "perf": [0.4, 0.6],
            "is_playoffs": [1, 1],
        }
    )
    gen = TeamRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=PerformancePredictor(sigmoid=True),
        performance_coefficients={"rating_difference": 0.0, "is_playoffs": -0.4054651081081643},
        use_off_def_split=False,
        start_harcoded_start_rating=1000.0,
        rating_change_multiplier_offense=100.0,
        rating_change_multiplier_defense=100.0,
    )

    gen.fit_transform(df)

    assert gen._team_off_ratings["T1"].rating_value == pytest.approx(1000.0)


def test_performance_features__missing_or_non_numeric_raises():
    cn = ColumnNames(player_id="pid", team_id="tid", match_id="mid", start_date="dt")
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_coefficients={"rating_difference": 0.0, "is_playoffs": 0.0},
    )
    missing_df = pl.DataFrame(
        {
            "pid": ["P1", "P2"],
            "tid": ["T1", "T2"],
            "mid": ["M1", "M1"],
            "dt": ["2024-05-01", "2024-05-01"],
            "perf": [0.4, 0.4],
        }
    )
    bad_df = missing_df.with_columns(pl.lit("yes").alias("is_playoffs"))

    with pytest.raises(ValueError, match="is_playoffs"):
        gen.fit_transform(missing_df)
    with pytest.raises(ValueError, match="numeric"):
        gen.fit_transform(bad_df)


def test_performance_coefficients__built_ins_do_not_require_dataframe_columns():
    cn = ColumnNames(player_id="pid", team_id="tid", match_id="mid", start_date="dt")
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_coefficients={"rating_difference": 0.0},
    )

    df = pl.DataFrame(
        {
            "pid": ["P1", "P2"],
            "tid": ["T1", "T2"],
            "mid": ["M1", "M1"],
            "dt": ["2024-05-01", "2024-05-01"],
            "perf": [0.4, 0.6],
        }
    )

    assert gen.fit_transform(df).height == 2


def test_player_rating_generator__linear_predictor_accepts_unbounded_performance():
    cn = ColumnNames(
        player_id="pid",
        team_id="tid",
        match_id="mid",
        start_date="dt",
        participation_weight="pw",
    )
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2"],
            "tid": ["T1", "T2"],
            "mid": ["M1", "M1"],
            "dt": ["2024-05-01", "2024-05-01"],
            "perf": [2.0, -1.0],
            "pw": [1.0, 1.0],
        }
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=PerformancePredictor(
            coefficients={"rating_difference": 0.0},
            sigmoid=False,
            requires_centered_target_mean=False,
        ),
        use_off_def_split=False,
        rating_mean_adjustment_enabled=False,
    )

    out = gen.fit_transform(df)

    assert out.height == 2


def test_player_rating_generator__sigmoid_predictor_rejects_unbounded_performance():
    cn = ColumnNames(player_id="pid", team_id="tid", match_id="mid", start_date="dt")
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2"],
            "tid": ["T1", "T2"],
            "mid": ["M1", "M1"],
            "dt": ["2024-05-01", "2024-05-01"],
            "perf": [2.0, -1.0],
        }
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=PerformancePredictor(),
        rating_mean_adjustment_enabled=False,
    )

    with pytest.raises(ValueError, match="auto_scale_performance"):
        gen.fit_transform(df)


def test_predicted_performance_optimizer__updates_intercept():
    cn = ColumnNames(
        player_id="pid",
        team_id="tid",
        match_id="mid",
        start_date="dt",
        participation_weight="pw",
    )
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2"],
            "tid": ["T1", "T2"],
            "mid": ["M1", "M1"],
            "dt": ["2024-05-01", "2024-05-01"],
            "perf": [2.0, 2.0],
            "pw": [1.0, 1.0],
        }
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=PerformancePredictor(
            coefficients={"rating_difference": 0.0},
            sigmoid=False,
            requires_centered_target_mean=False,
        ),
        use_off_def_split=False,
        rating_mean_adjustment_enabled=False,
    )
    optimizer = PredictedPerformanceOptimizer(
        rating_generator=gen,
        learning_rate=0.1,
        max_iterations=3,
    )

    result = optimizer.optimize(df)

    assert result.intercept > 0.0
    assert result.loss_history[-1] < result.loss_history[0]


def test_predicted_performance_optimizer__uses_target_model_derivative():
    cn = ColumnNames(
        player_id="pid",
        team_id="tid",
        match_id="mid",
        start_date="dt",
        participation_weight="pw",
    )
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2"],
            "tid": ["T1", "T2"],
            "mid": ["M1", "M1"],
            "dt": ["2024-05-01", "2024-05-01"],
            "perf": [4.0, 4.0],
            "pw": [1.0, 1.0],
        }
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=PerformancePredictor(
            coefficients={"rating_difference": 0.0},
            target_model="log1p",
            fit_intercept=False,
            requires_centered_target_mean=False,
        ),
        use_off_def_split=False,
        rating_mean_adjustment_enabled=False,
    )
    optimizer = PredictedPerformanceOptimizer(
        rating_generator=gen,
        learning_rate=0.05,
        max_iterations=4,
    )

    result = optimizer.optimize(df)

    assert result.loss_history[-1] < result.loss_history[0]


def test_predicted_performance_optimizer__returns_fitted_auto_target_model():
    cn = ColumnNames(
        player_id="pid",
        team_id="tid",
        match_id="mid",
        start_date="dt",
        participation_weight="pw",
    )
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2", "P3", "P4"],
            "tid": ["T1", "T2", "T1", "T2"],
            "mid": ["M1", "M1", "M2", "M2"],
            "dt": ["2024-05-01", "2024-05-01", "2024-05-02", "2024-05-02"],
            "perf": [0.0, 0.0, 0.0, 0.04],
            "pw": [1.0, 1.0, 1.0, 1.0],
        }
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=PerformancePredictor(
            coefficients={"rating_difference": 0.0},
            target_model="auto",
            requires_centered_target_mean=False,
        ),
        use_off_def_split=False,
        rating_mean_adjustment_enabled=False,
    )
    optimizer = PredictedPerformanceOptimizer(
        rating_generator=gen,
        learning_rate=0.01,
        max_iterations=1,
    )

    result = optimizer.optimize(df)
    predictor = result.rating_generator._performance_predictor

    assert predictor.selected_target_model == "zero_inflated_log1p"
    assert predictor.predict({"rating_difference": 0.0}) > 0.0


def test_predicted_performance_optimizer__learns_context_feature_coefficient():
    cn = ColumnNames(
        player_id="pid",
        team_id="tid",
        match_id="mid",
        start_date="dt",
        participation_weight="pw",
    )
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2", "P3", "P4"],
            "tid": ["T1", "T1", "T2", "T2"],
            "mid": ["M1", "M1", "M1", "M1"],
            "dt": ["2024-05-01"] * 4,
            "perf": [0.4, 0.4, 0.4, 0.4],
            "pw": [1.0, 1.0, 1.0, 1.0],
            "is_playoffs": [1, 1, 1, 1],
        }
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=PerformancePredictor(
            requires_centered_target_mean=False,
        ),
        performance_coefficients={"rating_difference": 0.0, "is_playoffs": 0.0},
        use_off_def_split=False,
        start_harcoded_start_rating=1000.0,
        rating_mean_adjustment_enabled=False,
    )
    optimizer = PredictedPerformanceOptimizer(
        rating_generator=gen,
        learning_rate=0.2,
        max_iterations=8,
    )

    result = optimizer.optimize(df)

    assert result.loss_history[-1] < result.loss_history[0]
    assert result.coefficients["is_playoffs"] < 0.0


def test_predicted_performance_optimizer__refines_prefit_context_coefficient():
    cn = ColumnNames(
        player_id="pid",
        team_id="tid",
        match_id="mid",
        start_date="dt",
        participation_weight="pw",
    )
    df = pl.DataFrame(
        {
            "pid": ["P1", "P2", "P3", "P4"],
            "tid": ["T1", "T2", "T1", "T2"],
            "mid": ["M1", "M1", "M2", "M2"],
            "dt": ["2024-05-01", "2024-05-01", "2024-05-02", "2024-05-02"],
            "perf": [2.0, 1.0, 2.0, 1.0],
            "pw": [1.0, 1.0, 1.0, 1.0],
            "home": [1, 0, 1, 0],
        }
    )
    predictor = PerformancePredictor(
        coefficients={"rating_difference": 0.0, "home": 0.0},
        sigmoid=False,
        requires_centered_target_mean=False,
        fit_features=["home"],
    )
    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=cn,
        performance_predictor=predictor,
        use_off_def_split=False,
        rating_mean_adjustment_enabled=False,
    )
    optimizer = PredictedPerformanceOptimizer(
        rating_generator=gen,
        learning_rate=0.01,
        max_iterations=2,
    )

    result = optimizer.optimize(df)

    assert result.coefficients["home"] == pytest.approx(1.0, abs=0.2)
    assert result.rating_generator._performance_predictor.fit_features == []
