"""Test that player ratings are frozen within a series (update_match_id boundary).

When two concurrent series interleave by timestamp (e.g., series A game 1,
series B game 2, series A game 2), the rating system must not apply updates
between games of the same series. All games within a series must see identical
pre-match player ratings.
"""

import polars as pl
import pytest

from spforge import ColumnNames
from spforge.ratings import PlayerRatingGenerator, RatingKnownFeatures


@pytest.fixture
def series_cn():
    return ColumnNames(
        player_id="pid",
        team_id="tid",
        match_id="mid",
        start_date="dt",
        update_match_id="series_id",
        participation_weight="pw",
    )


def _make_interleaved_series_df() -> pl.DataFrame:
    """Two BO3 series (A vs B and C vs D) with games interleaved by timestamp.

    Chronological order:
      1. Series X, Game 1: A vs B  (dt=2024-01-10 10:00)
      2. Series Y, Game 1: C vs D  (dt=2024-01-10 10:05)
      3. Series X, Game 2: A vs B  (dt=2024-01-10 11:00)
      4. Series Y, Game 2: C vs D  (dt=2024-01-10 11:05)
      5. Series X, Game 3: A vs B  (dt=2024-01-10 12:00)
      6. Series Y, Game 3: C vs D  (dt=2024-01-10 12:05)

    Plus a prior match to establish initial ratings.
    """
    rows = []

    # Prior match to establish ratings (different series)
    for pid, tid, perf in [("P1", "A", 0.7), ("P2", "A", 0.6), ("P3", "B", 0.4), ("P4", "B", 0.3)]:
        rows.append(
            {
                "pid": pid,
                "tid": tid,
                "mid": "M0",
                "series_id": "S0",
                "dt": "2024-01-01 10:00:00",
                "perf": perf,
                "pw": 1.0,
            }
        )
    for pid, tid, perf in [("P5", "C", 0.8), ("P6", "C", 0.5), ("P7", "D", 0.3), ("P8", "D", 0.2)]:
        rows.append(
            {
                "pid": pid,
                "tid": tid,
                "mid": "M00",
                "series_id": "S00",
                "dt": "2024-01-01 11:00:00",
                "perf": perf,
                "pw": 1.0,
            }
        )

    # Series X: A vs B, 3 games
    for game_num, dt in [
        (1, "2024-01-10 10:00:00"),
        (2, "2024-01-10 11:00:00"),
        (3, "2024-01-10 12:00:00"),
    ]:
        mid = f"SX_G{game_num}"
        for pid, tid, perf in [
            ("P1", "A", 0.7),
            ("P2", "A", 0.6),
            ("P3", "B", 0.4),
            ("P4", "B", 0.3),
        ]:
            rows.append(
                {
                    "pid": pid,
                    "tid": tid,
                    "mid": mid,
                    "series_id": "SX",
                    "dt": dt,
                    "perf": perf,
                    "pw": 1.0,
                }
            )

    # Series Y: C vs D, 3 games — interleaved timestamps with series X
    for game_num, dt in [
        (1, "2024-01-10 10:05:00"),
        (2, "2024-01-10 11:05:00"),
        (3, "2024-01-10 12:05:00"),
    ]:
        mid = f"SY_G{game_num}"
        for pid, tid, perf in [
            ("P5", "C", 0.8),
            ("P6", "C", 0.5),
            ("P7", "D", 0.3),
            ("P8", "D", 0.2),
        ]:
            rows.append(
                {
                    "pid": pid,
                    "tid": tid,
                    "mid": mid,
                    "series_id": "SY",
                    "dt": dt,
                    "perf": perf,
                    "pw": 1.0,
                }
            )

    return pl.DataFrame(rows)


def test_ratings_frozen_within_interleaved_series(series_cn):
    """Player ratings must be identical across all games within a series,
    even when another series' games are interleaved by timestamp."""
    df = _make_interleaved_series_df()

    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=series_cn,
        auto_scale_performance=True,
        features_out=[RatingKnownFeatures.PLAYER_RATING],
    )
    result = gen.fit_transform(df)
    player_rating_col = gen.PLAYER_RATING_COL

    # Extract player ratings per game within series X
    sx = result.filter(pl.col("series_id") == "SX").select(["mid", "pid", player_rating_col])
    # Group by player — all games should have the same rating
    for pid in ["P1", "P2", "P3", "P4"]:
        player_rows = sx.filter(pl.col("pid") == pid)
        ratings = player_rows[player_rating_col].unique()
        assert len(ratings) == 1, (
            f"Player {pid} has different ratings across games within series SX: "
            f"{player_rows.select(['mid', player_rating_col]).to_dicts()}"
        )

    # Same check for series Y
    sy = result.filter(pl.col("series_id") == "SY").select(["mid", "pid", player_rating_col])
    for pid in ["P5", "P6", "P7", "P8"]:
        player_rows = sy.filter(pl.col("pid") == pid)
        ratings = player_rows[player_rating_col].unique()
        assert len(ratings) == 1, (
            f"Player {pid} has different ratings across games within series SY: "
            f"{player_rows.select(['mid', player_rating_col]).to_dicts()}"
        )


def test_series_updates_are_ordered_by_series_start_date_not_series_id(series_cn):
    """A later series id that sorts earlier lexically must not be processed first.

    The early series intentionally has update_match_id="Z_..." while the later
    series has update_match_id="A_...". If update ids are sorted before dates,
    the later series sees the unadjusted starting rating. The expected behavior
    is to process the early series first, freeze ratings within that series, then
    apply its net-below-expected update before the later series.
    """
    df = pl.DataFrame(
        {
            "pid": [
                "P1",
                "P2",
                "P1",
                "P2",
                "P1",
                "P2",
                "P1",
                "P2",
            ],
            "tid": [
                "T1",
                "T2",
                "T1",
                "T2",
                "T1",
                "T2",
                "T1",
                "T2",
            ],
            "mid": [
                "EARLY_G1",
                "EARLY_G1",
                "EARLY_G2",
                "EARLY_G2",
                "LATE_G1",
                "LATE_G1",
                "LATE_G2",
                "LATE_G2",
            ],
            "series_id": [
                "Z_EARLY_SERIES",
                "Z_EARLY_SERIES",
                "Z_EARLY_SERIES",
                "Z_EARLY_SERIES",
                "A_LATE_SERIES",
                "A_LATE_SERIES",
                "A_LATE_SERIES",
                "A_LATE_SERIES",
            ],
            "dt": [
                "2024-01-01 10:00:00",
                "2024-01-01 10:00:00",
                "2024-01-01 11:00:00",
                "2024-01-01 11:00:00",
                "2024-01-02 10:00:00",
                "2024-01-02 10:00:00",
                "2024-01-02 11:00:00",
                "2024-01-02 11:00:00",
            ],
            "perf": [0.0, 1.0, 0.0, 1.0, 0.5, 0.5, 0.5, 0.5],
            "pw": [1.0] * 8,
        }
    )

    gen = PlayerRatingGenerator(
        performance_column="perf",
        column_names=series_cn,
        features_out=[RatingKnownFeatures.PLAYER_RATING],
    )
    result = gen.fit_transform(df)
    player_rating_col = gen.PLAYER_RATING_COL

    early_p1_ratings = (
        result.filter((pl.col("series_id") == "Z_EARLY_SERIES") & (pl.col("pid") == "P1"))
        .select(player_rating_col)
        .unique()
    )
    late_p1_rating = result.filter((pl.col("mid") == "LATE_G1") & (pl.col("pid") == "P1"))[
        player_rating_col
    ][0]

    assert early_p1_ratings.height == 1
    assert late_p1_rating < early_p1_ratings[player_rating_col][0]
