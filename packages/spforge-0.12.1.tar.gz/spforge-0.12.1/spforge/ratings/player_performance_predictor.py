from __future__ import annotations

import copy
import math
import sys
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

import narwhals.stable.v2 as nw
import numpy as np

DEFAULT_RATING_DIFFERENCE_COEF = 0.005757
DEFAULT_REFERENCE_RATING_COEF = 0.0015
DEFAULT_REFERENCE_RATING = 1000.0
DEFAULT_RATING_MEAN_COEF = 0.005757
TargetModelName = Literal["linear", "logistic", "log1p", "zero_inflated_log1p", "auto"]


@dataclass(slots=True)
class PredictedPerformanceSample:
    features: dict[str, float]
    prediction: float
    target: float
    weight: float = 1.0


@dataclass(slots=True)
class PerformanceTargetDiagnostics:
    mean: float
    std: float
    zero_fraction: float
    min: float
    max: float
    skewness: float
    positive_skewness: float | None
    is_non_negative: bool
    is_unit_interval: bool
    is_binary: bool


class PerformanceTargetModel:
    name = "linear"

    def fit(self, target: np.ndarray, diagnostics: PerformanceTargetDiagnostics) -> None:
        pass

    def fit_mask(self, target: np.ndarray) -> np.ndarray:
        return np.ones(target.shape, dtype=bool)

    def transform(self, target: np.ndarray) -> np.ndarray:
        return target

    def inverse(self, score: float) -> float:
        return float(score)

    def derivative(self, score: float, prediction: float) -> float:
        return 1.0


class LinearTargetModel(PerformanceTargetModel):
    name = "linear"


class LogisticTargetModel(PerformanceTargetModel):
    name = "logistic"

    def transform(self, target: np.ndarray) -> np.ndarray:
        if np.any((target < 0.0) | (target > 1.0)):
            raise ValueError("logistic performance target model requires target between 0 and 1")
        clipped = np.clip(target, 1e-6, 1 - 1e-6)
        return np.log(clipped / (1 - clipped))

    def inverse(self, score: float) -> float:
        return float(1 / (1 + math.exp(-score)))

    def derivative(self, score: float, prediction: float) -> float:
        return float(prediction * (1.0 - prediction))


class Log1pTargetModel(PerformanceTargetModel):
    name = "log1p"

    def transform(self, target: np.ndarray) -> np.ndarray:
        if np.any(target < 0.0):
            raise ValueError("log1p performance target model requires non-negative target")
        return np.log1p(target)

    def inverse(self, score: float) -> float:
        return float(max(0.0, math.expm1(score)))

    def derivative(self, score: float, prediction: float) -> float:
        return float(math.exp(score))


class ZeroInflatedLog1pTargetModel(Log1pTargetModel):
    name = "zero_inflated_log1p"

    def __init__(self) -> None:
        self.nonzero_probability = 1.0

    def fit(self, target: np.ndarray, diagnostics: PerformanceTargetDiagnostics) -> None:
        if np.any(target < 0.0):
            raise ValueError(
                "zero_inflated_log1p performance target model requires non-negative target"
            )
        self.nonzero_probability = float(np.mean(~np.isclose(target, 0.0)))

    def fit_mask(self, target: np.ndarray) -> np.ndarray:
        return ~np.isclose(target, 0.0)

    def inverse(self, score: float) -> float:
        return float(self.nonzero_probability * max(0.0, math.expm1(score)))

    def derivative(self, score: float, prediction: float) -> float:
        return float(self.nonzero_probability * math.exp(score))


class AutoTargetModel(PerformanceTargetModel):
    name = "auto"

    def __init__(self) -> None:
        self.selected_model: PerformanceTargetModel = LinearTargetModel()

    def fit(self, target: np.ndarray, diagnostics: PerformanceTargetDiagnostics) -> None:
        if diagnostics.is_binary:
            self.selected_model = LogisticTargetModel()
        elif diagnostics.is_non_negative and diagnostics.zero_fraction >= 0.35:
            self.selected_model = ZeroInflatedLog1pTargetModel()
        elif diagnostics.is_non_negative and diagnostics.skewness > 1.0:
            self.selected_model = Log1pTargetModel()
        elif diagnostics.is_unit_interval:
            self.selected_model = LogisticTargetModel()
        else:
            self.selected_model = LinearTargetModel()
        self.selected_model.fit(target, diagnostics)

    def fit_mask(self, target: np.ndarray) -> np.ndarray:
        return self.selected_model.fit_mask(target)

    def transform(self, target: np.ndarray) -> np.ndarray:
        return self.selected_model.transform(target)

    def inverse(self, score: float) -> float:
        return self.selected_model.inverse(score)

    def derivative(self, score: float, prediction: float) -> float:
        return self.selected_model.derivative(score, prediction)


def _create_target_model(
    target_model: PerformanceTargetModel | TargetModelName,
) -> PerformanceTargetModel:
    if isinstance(target_model, PerformanceTargetModel):
        return copy.deepcopy(target_model)
    if target_model == "linear":
        return LinearTargetModel()
    if target_model == "logistic":
        return LogisticTargetModel()
    if target_model == "log1p":
        return Log1pTargetModel()
    if target_model == "zero_inflated_log1p":
        return ZeroInflatedLog1pTargetModel()
    if target_model == "auto":
        return AutoTargetModel()
    raise ValueError(f"target_model {target_model} is not supported")


def _skewness(values: np.ndarray) -> float:
    if values.size < 2:
        return 0.0
    std = float(np.std(values))
    if np.isclose(std, 0.0):
        return 0.0
    centered = (values - float(np.mean(values))) / std
    return float(np.mean(centered**3))


class PerformancePredictor:
    requires_centered_target_mean = True

    def __init__(
        self,
        coefficients: Mapping[str, float] | None = None,
        intercept: float = 0.0,
        sigmoid: bool = True,
        min_prediction: float | None = None,
        max_prediction: float | None = None,
        reference_rating: float = DEFAULT_REFERENCE_RATING,
        requires_centered_target_mean: bool = True,
        fit_features: list[str] | None = None,
        fit_intercept: bool = True,
        fit_regularization: float = 1e-6,
        target_model: PerformanceTargetModel | TargetModelName | None = None,
    ):
        if coefficients is None:
            coefficients = {"rating_difference": DEFAULT_RATING_DIFFERENCE_COEF}
        if not coefficients:
            raise ValueError("coefficients must contain at least one feature coefficient")

        self.coefficients = {str(feature): float(coef) for feature, coef in coefficients.items()}
        self.intercept = float(intercept)
        self._target_model_explicit = target_model is not None
        target_model = "logistic" if target_model is None and sigmoid else target_model
        target_model = "linear" if target_model is None else target_model
        self.target_model_name = (
            target_model.name if isinstance(target_model, PerformanceTargetModel) else target_model
        )
        self.target_model = _create_target_model(target_model)
        self.sigmoid = self.target_model.name == "logistic"
        self.min_prediction = min_prediction
        self.max_prediction = max_prediction
        self.reference_rating = float(reference_rating)
        self.requires_centered_target_mean = bool(requires_centered_target_mean)
        self.fit_features = [str(feature) for feature in fit_features or []]
        self.fit_intercept = bool(fit_intercept)
        self.fit_regularization = float(fit_regularization)
        self.target_mean: float | None = None
        self.target_std: float | None = None
        self.target_zero_fraction: float | None = None
        self.target_min: float | None = None
        self.target_max: float | None = None
        self.target_diagnostics: PerformanceTargetDiagnostics | None = None
        self.selected_target_model: str = self.target_model.name

        if (
            self.min_prediction is not None
            and self.max_prediction is not None
            and self.min_prediction > self.max_prediction
        ):
            raise ValueError("min_prediction must be less than or equal to max_prediction")
        if self.fit_regularization < 0:
            raise ValueError("fit_regularization must be non-negative")
        missing_fit_coefficients = [
            feature for feature in self.fit_features if feature not in self.coefficients
        ]
        if missing_fit_coefficients:
            raise ValueError(
                f"fit_features must also be present in coefficients: {missing_fit_coefficients}"
            )

    @property
    def coef(self) -> float:
        if len(self.coefficients) != 1:
            raise ValueError("coef is only defined when exactly one coefficient is configured")
        return next(iter(self.coefficients.values()))

    @property
    def _reference_rating(self) -> float:
        return self.reference_rating

    @_reference_rating.setter
    def _reference_rating(self, value: float) -> None:
        self.reference_rating = float(value)

    def __setstate__(self, state: dict[str, Any]) -> None:
        self.__dict__.update(state)
        self._ensure_compatible_state()

    def _ensure_compatible_state(self) -> None:
        if not hasattr(self, "coefficients"):
            self.coefficients = {"rating_difference": DEFAULT_RATING_DIFFERENCE_COEF}
        if not hasattr(self, "intercept"):
            self.intercept = 0.0
        if not hasattr(self, "sigmoid"):
            self.sigmoid = True
        if not hasattr(self, "min_prediction"):
            self.min_prediction = None
        if not hasattr(self, "max_prediction"):
            self.max_prediction = None
        if not hasattr(self, "reference_rating"):
            self.reference_rating = DEFAULT_REFERENCE_RATING
        if not hasattr(self, "requires_centered_target_mean"):
            self.requires_centered_target_mean = True
        if not hasattr(self, "_target_model_explicit"):
            self._target_model_explicit = False
        if not hasattr(self, "target_model"):
            target_model_name = "logistic" if self.sigmoid else "linear"
            self.target_model = _create_target_model(target_model_name)
        if not hasattr(self, "target_model_name"):
            self.target_model_name = self.target_model.name
        if not hasattr(self, "fit_features"):
            self.fit_features = []
        if not hasattr(self, "fit_intercept"):
            self.fit_intercept = True
        if not hasattr(self, "fit_regularization"):
            self.fit_regularization = 1e-6
        if not hasattr(self, "target_mean"):
            self.target_mean = None
        if not hasattr(self, "target_std"):
            self.target_std = None
        if not hasattr(self, "target_zero_fraction"):
            self.target_zero_fraction = None
        if not hasattr(self, "target_min"):
            self.target_min = None
        if not hasattr(self, "target_max"):
            self.target_max = None
        if not hasattr(self, "target_diagnostics"):
            self.target_diagnostics = None
        if not hasattr(self, "selected_target_model"):
            self.selected_target_model = self.target_model.name

    def reset(self) -> None:
        pass

    def fit(self, df: Any, target_column: str) -> PerformancePredictor:
        nw_df = df if hasattr(df, "implementation") else nw.from_native(df)
        missing = [
            feature
            for feature in [*self.fit_features, target_column]
            if feature not in nw_df.columns
        ]
        if missing:
            raise ValueError(f"Missing performance predictor fit columns: {missing}")

        y = self._numeric_column(nw_df, target_column)
        valid_mask = np.isfinite(y)
        x_columns = []
        for feature in self.fit_features:
            values = self._numeric_column(nw_df, feature)
            valid_mask &= np.isfinite(values)
            x_columns.append(values)

        y = y[valid_mask]
        if y.size == 0:
            if not self.fit_features:
                return self
            raise ValueError("performance predictor fit has no finite target rows")

        diagnostics = PerformanceTargetDiagnostics(
            mean=float(np.mean(y)),
            std=float(np.std(y)),
            zero_fraction=float(np.mean(np.isclose(y, 0.0))),
            min=float(np.min(y)),
            max=float(np.max(y)),
            skewness=_skewness(y),
            positive_skewness=_skewness(y[y > 0.0]) if np.any(y > 0.0) else None,
            is_non_negative=bool(np.all(y >= 0.0)),
            is_unit_interval=bool(np.all((y >= 0.0) & (y <= 1.0))),
            is_binary=bool(np.all(np.isclose(y, 0.0) | np.isclose(y, 1.0))),
        )
        self.target_diagnostics = diagnostics
        self.target_mean = diagnostics.mean
        self.target_std = diagnostics.std
        self.target_zero_fraction = diagnostics.zero_fraction
        self.target_min = diagnostics.min
        self.target_max = diagnostics.max
        self.target_model.fit(y, diagnostics)
        if isinstance(self.target_model, AutoTargetModel):
            self.selected_target_model = self.target_model.selected_model.name
        else:
            self.selected_target_model = self.target_model.name
        self.sigmoid = self.selected_target_model == "logistic"

        should_fit_parameters = bool(self.fit_features) or (
            self._target_model_explicit and self.fit_intercept
        )
        if not should_fit_parameters:
            return self
        fit_mask = self.target_model.fit_mask(y)
        if not np.any(fit_mask):
            raise ValueError(
                f"performance predictor fit has no rows for {self.selected_target_model} target model"
            )
        transformed_y = self.target_model.transform(y[fit_mask])
        if x_columns:
            x = np.column_stack([values[valid_mask] for values in x_columns])[fit_mask]
        else:
            x = np.empty((transformed_y.size, 0))
        if self.fit_intercept:
            x = np.column_stack([np.ones(transformed_y.size), x])

        penalty = self.fit_regularization * np.eye(x.shape[1])
        if self.fit_intercept:
            penalty[0, 0] = 0.0
        try:
            params = np.linalg.solve(x.T @ x + penalty, x.T @ transformed_y)
        except np.linalg.LinAlgError:
            params = np.linalg.lstsq(x, transformed_y, rcond=None)[0]

        offset = 0
        if self.fit_intercept:
            self.intercept = float(params[0])
            offset = 1
        for index, feature in enumerate(self.fit_features):
            self.coefficients[feature] = float(params[index + offset])

        return self

    @staticmethod
    def _numeric_column(df: Any, column: str) -> np.ndarray:
        try:
            return df[column].to_numpy().astype(float)
        except Exception as exc:
            raise ValueError(
                f"performance predictor fit column '{column}' must be numeric or boolean"
            ) from exc

    def _score(self, features: Mapping[str, float]) -> float:
        missing = [feature for feature in self.coefficients if feature not in features]
        if missing:
            raise ValueError(f"Missing performance predictor features: {missing}")

        value = self.intercept
        for feature, coefficient in self.coefficients.items():
            value += coefficient * float(features[feature])
        return float(value)

    def _prediction_derivative(self, features: Mapping[str, float]) -> float:
        score = self._score(features)
        prediction = self.target_model.inverse(score)
        return self.target_model.derivative(score, prediction)

    def predict(self, features: Mapping[str, float]) -> float:
        self._ensure_compatible_state()
        value = self.target_model.inverse(self._score(features))
        if self.min_prediction is not None:
            value = max(float(self.min_prediction), value)
        if self.max_prediction is not None:
            value = min(float(self.max_prediction), value)
        return float(value)


def _legacy_clamp_min(max_predict_value: float | None) -> float | None:
    if max_predict_value is None:
        return None
    return 1.0 - float(max_predict_value)


def _legacy_clamp_max(max_predict_value: float | None) -> float | None:
    if max_predict_value is None:
        return None
    return float(max_predict_value)


class _LegacyRatingPlayerDifferencePerformancePredictor(PerformancePredictor):
    def __init__(
        self,
        rating_diff_coef: float = DEFAULT_RATING_DIFFERENCE_COEF,
        rating_diff_team_from_entity_coef: float = 0.0,
        team_rating_diff_coef: float = 0.0,
        max_predict_value: float = 1.0,
        participation_weight_coef: float | None = None,
    ) -> None:
        coefficients = {"rating_difference": float(rating_diff_coef)}
        if rating_diff_team_from_entity_coef:
            coefficients["rating_diff_team_from_entity"] = float(rating_diff_team_from_entity_coef)
        if team_rating_diff_coef:
            coefficients["team_rating_diff"] = float(team_rating_diff_coef)
        super().__init__(
            coefficients=coefficients,
            sigmoid=True,
            min_prediction=_legacy_clamp_min(max_predict_value),
            max_prediction=_legacy_clamp_max(max_predict_value),
        )
        self.rating_diff_coef = float(rating_diff_coef)
        self.rating_diff_team_from_entity_coef = float(rating_diff_team_from_entity_coef)
        self.team_rating_diff_coef = float(team_rating_diff_coef)
        self.max_predict_value = float(max_predict_value)
        self.participation_weight_coef = participation_weight_coef

    def __setstate__(self, state: dict[str, Any]) -> None:
        rating_diff_coef = float(state.get("rating_diff_coef", DEFAULT_RATING_DIFFERENCE_COEF))
        rating_diff_team_from_entity_coef = float(
            state.get("rating_diff_team_from_entity_coef", 0.0)
        )
        team_rating_diff_coef = float(state.get("team_rating_diff_coef", 0.0))
        max_predict_value = float(state.get("max_predict_value", 1.0))
        participation_weight_coef = state.get("participation_weight_coef")
        self.__init__(
            rating_diff_coef=rating_diff_coef,
            rating_diff_team_from_entity_coef=rating_diff_team_from_entity_coef,
            team_rating_diff_coef=team_rating_diff_coef,
            max_predict_value=max_predict_value,
            participation_weight_coef=participation_weight_coef,
        )
        for key, value in state.items():
            if not hasattr(self, key):
                setattr(self, key, value)

    def predict_performance_value(
        self,
        player_rating_value: float,
        opponent_team_rating_value: float,
        team_rating_value: float,
        **_: Any,
    ) -> float:
        return self.predict(
            {
                "rating_difference": player_rating_value - opponent_team_rating_value,
                "rating_diff_team_from_entity": team_rating_value - player_rating_value,
                "team_rating_diff": team_rating_value - opponent_team_rating_value,
            }
        )


class _LegacyPlayerRatingNonOpponentPerformancePredictor(PerformancePredictor):
    def __init__(
        self,
        coef: float = DEFAULT_REFERENCE_RATING_COEF,
        last_sample_count: int = 1500,
        min_count_for_historical_average: int = 200,
    ) -> None:
        super().__init__(
            coefficients={"rating_over_reference": float(coef)},
            sigmoid=True,
        )
        self.coef = float(coef)
        self.last_sample_count = int(last_sample_count)
        self.min_count_for_historical_average = int(min_count_for_historical_average)

    def __setstate__(self, state: dict[str, Any]) -> None:
        self.__init__(
            coef=float(state.get("coef", DEFAULT_REFERENCE_RATING_COEF)),
            last_sample_count=int(state.get("last_sample_count", 1500)),
            min_count_for_historical_average=int(
                state.get("min_count_for_historical_average", 200)
            ),
        )
        for key, value in state.items():
            if not hasattr(self, key):
                setattr(self, key, value)

    def predict_performance_value(
        self,
        player_rating_value: float,
        *_: Any,
        **__: Any,
    ) -> float:
        return self.predict({"rating_over_reference": player_rating_value - self.reference_rating})


class _LegacyRatingMeanPerformancePredictor(PerformancePredictor):
    def __init__(
        self,
        coef: float = DEFAULT_RATING_MEAN_COEF,
        max_predict_value: float = 1.0,
        last_sample_count: int = 1500,
    ) -> None:
        super().__init__(
            coefficients={"rating_mean_over_reference": float(coef)},
            sigmoid=True,
            min_prediction=_legacy_clamp_min(max_predict_value),
            max_prediction=_legacy_clamp_max(max_predict_value),
        )
        self.coef = float(coef)
        self.max_predict_value = float(max_predict_value)
        self.last_sample_count = int(last_sample_count)
        self.sum_ratings: list[float] = []

    def __setstate__(self, state: dict[str, Any]) -> None:
        self.__init__(
            coef=float(state.get("coef", DEFAULT_RATING_MEAN_COEF)),
            max_predict_value=float(state.get("max_predict_value", 1.0)),
            last_sample_count=int(state.get("last_sample_count", 1500)),
        )
        self.sum_ratings = list(state.get("sum_ratings", []))
        for key, value in state.items():
            if not hasattr(self, key):
                setattr(self, key, value)

    def reset(self) -> None:
        self.sum_ratings = []

    def predict_performance_value(
        self,
        player_rating_value: float,
        opponent_team_rating_value: float,
        *_: Any,
        **__: Any,
    ) -> float:
        self.sum_ratings.append(float(player_rating_value))
        self.sum_ratings = self.sum_ratings[-self.last_sample_count :]
        reference_rating = sum(self.sum_ratings) / len(self.sum_ratings)
        rating_mean = 0.5 * float(player_rating_value) + 0.5 * float(opponent_team_rating_value)
        return self.predict({"rating_mean_over_reference": rating_mean - reference_rating})


_legacy_aliases = {
    "PlayerPerformancePredictor": PerformancePredictor,
    "RatingPlayerDifferencePerformancePredictor": _LegacyRatingPlayerDifferencePerformancePredictor,
    "PlayerRatingNonOpponentPerformancePredictor": _LegacyPlayerRatingNonOpponentPerformancePredictor,
    "RatingMeanPerformancePredictor": _LegacyRatingMeanPerformancePredictor,
}
_current_module = sys.modules[__name__]
for _alias_name, _alias_class in _legacy_aliases.items():
    if not hasattr(_current_module, _alias_name):
        _alias_class.__name__ = _alias_name
        _alias_class.__qualname__ = _alias_name
        setattr(_current_module, _alias_name, _alias_class)


def create_performance_predictor(
    performance_predictor: PerformancePredictor
    | Literal["difference", "mean", "ignore_opponent"]
    | None = None,
    *,
    performance_coefficients: Mapping[str, float] | None = None,
    rating_diff_coef: float = DEFAULT_RATING_DIFFERENCE_COEF,
    rating_diff_team_from_entity_coef: float = 0.0,
    team_rating_diff_coef: float = 0.0,
    coef: float | None = None,
    intercept: float = 0.0,
    sigmoid: bool = True,
    min_prediction: float | None = None,
    max_prediction: float | None = None,
    min_predict_value: float | None = None,
    max_predict_value: float | None = None,
    reference_rating: float = DEFAULT_REFERENCE_RATING,
    requires_centered_target_mean: bool = True,
    last_sample_count: int = 1500,
    min_count_for_historical_average: int = 200,
    fit_features: list[str] | None = None,
    fit_intercept: bool = True,
    fit_regularization: float = 1e-6,
    target_model: PerformanceTargetModel | TargetModelName | None = None,
) -> PerformancePredictor:
    if min_predict_value is not None:
        min_prediction = min_predict_value
    if max_predict_value is not None:
        if min_prediction is None:
            min_prediction = 1 - max_predict_value
        max_prediction = max_predict_value
    if last_sample_count < 1:
        raise ValueError("last_sample_count must be positive")
    if min_count_for_historical_average < 1:
        raise ValueError("min_count_for_historical_average must be positive")

    if isinstance(performance_predictor, PerformancePredictor):
        if performance_coefficients is None:
            return performance_predictor
        return PerformancePredictor(
            coefficients=performance_coefficients,
            intercept=performance_predictor.intercept,
            sigmoid=performance_predictor.sigmoid,
            min_prediction=performance_predictor.min_prediction,
            max_prediction=performance_predictor.max_prediction,
            reference_rating=performance_predictor.reference_rating,
            requires_centered_target_mean=performance_predictor.requires_centered_target_mean,
            fit_features=performance_predictor.fit_features
            if fit_features is None
            else fit_features,
            fit_intercept=performance_predictor.fit_intercept,
            fit_regularization=performance_predictor.fit_regularization,
            target_model=(
                performance_predictor.target_model
                if target_model is None
                and getattr(performance_predictor, "_target_model_explicit", False)
                else target_model
            ),
        )
    if performance_predictor not in {None, "difference", "mean", "ignore_opponent"}:
        raise ValueError(f"performance_predictor {performance_predictor} is not supported")

    if performance_coefficients is not None:
        return PerformancePredictor(
            coefficients=performance_coefficients,
            intercept=intercept,
            sigmoid=sigmoid,
            min_prediction=min_prediction,
            max_prediction=max_prediction,
            reference_rating=reference_rating,
            requires_centered_target_mean=requires_centered_target_mean,
            fit_features=fit_features,
            fit_intercept=fit_intercept,
            fit_regularization=fit_regularization,
            target_model=target_model,
        )

    preset = "difference" if performance_predictor is None else performance_predictor
    if preset == "mean":
        return PerformancePredictor(
            coefficients={
                "rating_mean_over_reference": (DEFAULT_RATING_MEAN_COEF if coef is None else coef)
            },
            intercept=intercept,
            sigmoid=sigmoid,
            min_prediction=min_prediction,
            max_prediction=max_prediction,
            reference_rating=reference_rating,
            requires_centered_target_mean=requires_centered_target_mean,
            fit_features=fit_features,
            fit_intercept=fit_intercept,
            fit_regularization=fit_regularization,
            target_model=target_model,
        )
    if preset == "ignore_opponent":
        return PerformancePredictor(
            coefficients={
                "rating_over_reference": DEFAULT_REFERENCE_RATING_COEF if coef is None else coef
            },
            intercept=intercept,
            sigmoid=sigmoid,
            min_prediction=min_prediction,
            max_prediction=max_prediction,
            reference_rating=reference_rating,
            requires_centered_target_mean=requires_centered_target_mean,
            fit_features=fit_features,
            fit_intercept=fit_intercept,
            fit_regularization=fit_regularization,
            target_model=target_model,
        )
    coefficients = {"rating_difference": rating_diff_coef}
    if rating_diff_team_from_entity_coef:
        coefficients["rating_diff_team_from_entity"] = rating_diff_team_from_entity_coef
    if team_rating_diff_coef:
        coefficients["team_rating_diff"] = team_rating_diff_coef
    return PerformancePredictor(
        coefficients=coefficients,
        intercept=intercept,
        sigmoid=sigmoid,
        min_prediction=min_prediction,
        max_prediction=max_prediction,
        reference_rating=reference_rating,
        requires_centered_target_mean=requires_centered_target_mean,
        fit_features=fit_features,
        fit_intercept=fit_intercept,
        fit_regularization=fit_regularization,
        target_model=target_model,
    )
