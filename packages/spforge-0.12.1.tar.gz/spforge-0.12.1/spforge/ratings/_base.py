# rating_generator_base.py
from __future__ import annotations

import logging
import math
import numbers
from abc import abstractmethod
from collections.abc import Mapping
from typing import Any, Literal

import narwhals.stable.v2 as nw
import numpy as np
import polars as pl
from narwhals.stable.v2 import DataFrame
from narwhals.stable.v2.typing import IntoFrameT

from spforge.base_feature_generator import FeatureGenerator
from spforge.data_structures import ColumnNames, RatingState
from spforge.feature_generator._utils import to_polars
from spforge.performance_transformers._performance_manager import (
    ColumnWeight,
    PerformanceManager,
    PerformanceWeightsManager,
)
from spforge.ratings.enums import RatingKnownFeatures, RatingUnknownFeatures
from spforge.ratings.league_identifier import LeagueIdentifer2
from spforge.ratings.player_performance_predictor import (
    PerformancePredictor,
    PredictedPerformanceSample,
    create_performance_predictor,
)

MATCH_CONTRIBUTION_TO_SUM_VALUE = 1
EXPECTED_MEAN_CONFIDENCE_SUM = 30
BUILT_IN_PERFORMANCE_FEATURES = {
    "player_rating",
    "team_rating",
    "rating",
    "opponent_team_rating",
    "opponent_rating",
    "rating_difference",
    "rating_diff_team_from_entity",
    "team_rating_diff",
    "team_rating_difference",
    "rating_mean",
    "rating_over_reference",
    "rating_mean_over_reference",
}

PerformancePredictorPreset = Literal["difference", "mean", "ignore_opponent"]


class RatingGenerator(FeatureGenerator):
    def __init__(
        self,
        performance_column: str,
        performance_weights: list[ColumnWeight | dict[str, float]] | None,
        column_names: ColumnNames,
        features_out: list[str] | None,
        performance_manager: PerformanceManager | None,
        auto_scale_performance: bool,
        performance_predictor: PerformancePredictor | PerformancePredictorPreset | None,
        rating_change_multiplier_offense: float,
        rating_change_multiplier_defense: float,
        confidence_days_ago_multiplier: float,
        confidence_max_days: int,
        confidence_value_denom: float,
        confidence_max_sum: float,
        confidence_weight: float,
        non_predictor_features_out: list[RatingKnownFeatures | RatingUnknownFeatures] | None,
        min_rating_change_multiplier_ratio: float,
        league_rating_change_update_threshold: float,
        league_rating_adjustor_multiplier: float,
        output_suffix: str | None = None,
        performance_coefficients: Mapping[str, float] | None = None,
        **kwargs: Any,
    ):
        if "performance_features" in kwargs:
            raise TypeError(
                "performance_features has been removed; include dataframe context feature names "
                "in performance_coefficients instead"
            )
        if "participation_weight_coef" in kwargs:
            raise TypeError(
                "participation_weight_coef is no longer supported; include participation context "
                "as a performance coefficient feature instead"
            )
        if isinstance(performance_predictor, str) and performance_coefficients is None:
            self._performance_predictor_preset: PerformancePredictorPreset | None = (
                performance_predictor
            )
        elif performance_predictor is None and performance_coefficients is None:
            self._performance_predictor_preset = "difference"
        else:
            self._performance_predictor_preset = None

        if self._performance_predictor_preset == "mean":
            default_features = [RatingKnownFeatures.RATING_MEAN_PROJECTED]
        elif self._performance_predictor_preset == "ignore_opponent":
            default_features = [RatingKnownFeatures.TEAM_RATING_PROJECTED]
        else:
            default_features = [RatingKnownFeatures.TEAM_RATING_DIFFERENCE_PROJECTED]

        self.output_suffix = performance_column if output_suffix is None else output_suffix
        if features_out is None:
            _features_out = [self._suffix(str(f)) for f in default_features]
        else:
            _features_out = [self._suffix(str(f)) for f in features_out]
        super().__init__(features_out=_features_out)

        self._prediction_samples: list[PredictedPerformanceSample] = []
        self._collect_prediction_samples = False
        self.performance_weights = performance_weights

        self.league_rating_adjustor_multiplier = league_rating_adjustor_multiplier
        self.league_rating_change_update_threshold = league_rating_change_update_threshold

        self.confidence_max_days = confidence_max_days
        self._league_rating_changes: dict[str | None, float] = {}
        self._league_rating_changes_count: dict[str, float] = {}

        self.min_rating_change_multiplier_ratio = float(min_rating_change_multiplier_ratio)

        # NEW: store both base multipliers
        self.rating_change_multiplier_offense = float(rating_change_multiplier_offense)
        self.rating_change_multiplier_defense = float(rating_change_multiplier_defense)

        self.confidence_max_sum = float(confidence_max_sum)
        self.non_predictor_features_out = non_predictor_features_out or []
        self.non_predictor_features_out = [
            self._suffix(str(c)) for c in self.non_predictor_features_out
        ]

        predictor_params = {
            name: kwargs[name]
            for name in create_performance_predictor.__annotations__
            if name in kwargs
        }
        self._performance_predictor = create_performance_predictor(
            performance_predictor,
            performance_coefficients=performance_coefficients,
            **predictor_params,
        )
        self.performance_predictor = self._performance_predictor
        self._performance_features = [
            feature
            for feature in self._performance_predictor.coefficients
            if feature not in BUILT_IN_PERFORMANCE_FEATURES
        ]
        self._performance_mean_last_sample_count = int(kwargs.get("last_sample_count", 1500))
        self._performance_mean_ratings: list[float] = []

        self.auto_scale_performance = bool(auto_scale_performance)
        self.performance_manager = performance_manager
        self.performance_column = performance_column
        self.performance_manager = self._create_performance_manager()
        self.performance_column = (
            self.performance_manager.performance_column
            if self.performance_manager
            else self.performance_column
        )
        self.column_names = column_names
        self.kwargs = kwargs

        self.confidence_days_ago_multiplier = float(confidence_days_ago_multiplier)
        self.confidence_value_denom = float(confidence_value_denom)
        self.confidence_weight = float(confidence_weight)

        self.league_identifier = (
            LeagueIdentifer2(column_names=self.column_names)
            if getattr(self.column_names, "league", None)
            else None
        )

    def clear_prediction_samples(self) -> None:
        self._prediction_samples = []

    def enable_prediction_sample_collection(self, enabled: bool = True) -> None:
        self._collect_prediction_samples = bool(enabled)
        if enabled:
            self.clear_prediction_samples()

    @property
    def prediction_samples(self) -> list[PredictedPerformanceSample]:
        return list(self._prediction_samples)

    def _record_prediction_sample(
        self,
        *,
        side: str,
        features: dict[str, float] | None,
        prediction: float,
        target: float | None,
        weight: float | None = 1.0,
    ) -> None:
        _ = side
        if not self._collect_prediction_samples or features is None or target is None:
            return
        target_value = float(target)
        sample_weight = 1.0 if weight is None else float(weight)
        if not np.isfinite(target_value) or not np.isfinite(sample_weight) or sample_weight <= 0:
            return
        self._prediction_samples.append(
            PredictedPerformanceSample(
                features=dict(features),
                prediction=float(prediction),
                target=target_value,
                weight=sample_weight,
            )
        )

    def _validate_performance_features(self, df: pl.DataFrame) -> None:
        columns = list(df.columns)
        missing = [feature for feature in self._performance_features if feature not in columns]
        if missing:
            raise ValueError(f"Missing performance coefficient feature columns: {missing}")
        for feature in self._performance_features:
            try:
                df.select(pl.col(feature).cast(pl.Float64, strict=True))
            except Exception as exc:
                raise ValueError(
                    f"performance coefficient feature column '{feature}' must be numeric or boolean"
                ) from exc

    def _extract_performance_context(self, source: Mapping[str, Any]) -> dict[str, float]:
        context: dict[str, float] = {}
        for feature in self._performance_features:
            if feature not in source:
                raise ValueError(f"Missing performance feature {feature!r}")
            value = source[feature]
            if value is None:
                raise ValueError(f"performance feature {feature!r} contains null values")
            if isinstance(value, bool):
                context[feature] = 1.0 if value else 0.0
                continue
            if not isinstance(value, numbers.Real):
                raise ValueError(
                    f"performance feature {feature!r} must be numeric or boolean, "
                    f"got {type(value).__name__}"
                )
            numeric_value = float(value)
            if not math.isfinite(numeric_value):
                raise ValueError(f"performance feature {feature!r} must be finite")
            context[feature] = numeric_value
        return context

    def _performance_prediction_is_bounded(self) -> bool:
        return bool(self._performance_predictor.sigmoid)

    def _rating_mean_reference(self, rating_value: float) -> float:
        self._performance_mean_ratings.append(float(rating_value))
        start_index = max(
            0,
            len(self._performance_mean_ratings) - self._performance_mean_last_sample_count,
        )
        self._performance_mean_ratings = self._performance_mean_ratings[start_index:]
        return sum(self._performance_mean_ratings) / len(self._performance_mean_ratings)

    def _reset_performance_predictor_state(self) -> None:
        self._performance_predictor.reset()
        self._performance_mean_ratings = []

    @property
    def rating_diff_coef(self) -> float:
        return self._performance_predictor.coefficients.get("rating_difference", 0.0)

    @rating_diff_coef.setter
    def rating_diff_coef(self, value: float) -> None:
        self._performance_predictor.coefficients["rating_difference"] = float(value)

    @property
    def rating_diff_team_from_entity_coef(self) -> float:
        return self._performance_predictor.coefficients.get("rating_diff_team_from_entity", 0.0)

    @rating_diff_team_from_entity_coef.setter
    def rating_diff_team_from_entity_coef(self, value: float) -> None:
        self._performance_predictor.coefficients["rating_diff_team_from_entity"] = float(value)

    @property
    def team_rating_diff_coef(self) -> float:
        return self._performance_predictor.coefficients.get("team_rating_diff", 0.0)

    @team_rating_diff_coef.setter
    def team_rating_diff_coef(self, value: float) -> None:
        self._performance_predictor.coefficients["team_rating_diff"] = float(value)

    @property
    def coef(self) -> float:
        return self._performance_predictor.coef

    @coef.setter
    def coef(self, value: float) -> None:
        if len(self._performance_predictor.coefficients) != 1:
            raise ValueError("coef can only be set when exactly one coefficient is configured")
        feature = next(iter(self._performance_predictor.coefficients))
        self._performance_predictor.coefficients[feature] = float(value)

    def _suffix(self, col: str) -> str:
        if not self.output_suffix:
            return col
        return f"{col}_{self.output_suffix}"

    @staticmethod
    def _to_polars_eager(df: Any) -> tuple[pl.DataFrame, bool]:
        """Convert any narwhals/native frame to an eager pl.DataFrame.

        Returns (eager_df, was_lazy) so callers can restore LazyFrame on output.
        """
        if isinstance(df, pl.LazyFrame):
            return df.collect(), True
        if isinstance(df, pl.DataFrame):
            return df, False
        # narwhals-wrapped frame
        native = df.to_native() if hasattr(df, "to_native") else nw.to_native(df)
        if isinstance(native, pl.LazyFrame):
            return native.collect(), True
        if isinstance(native, pl.DataFrame):
            return native, False
        # pandas / other backend — convert to polars
        return nw.from_native(native).to_polars().to_native(), False

    @to_polars
    @nw.narwhalify
    def fit_transform(
        self,
        df: IntoFrameT,
        column_names: ColumnNames | None = None,
    ) -> DataFrame | IntoFrameT:
        pl_df, was_lazy = self._to_polars_eager(df)
        df = nw.from_native(pl_df)
        self._validate_performance_features(pl_df)

        if not self.performance_manager:
            assert self.performance_column in df.columns, (
                f"{self.performance_column} not in df. If performance_weights are not set, "
                "performance_column must exist in dataframe"
            )

        self.column_names = column_names if column_names else self.column_names

        if self.column_names.league:
            self.league_identifier = LeagueIdentifer2(column_names=self.column_names)

        if self.performance_manager and self.performance_manager:
            ori_perf_values = df[self.performance_manager.ori_performance_column].to_list()
            df = nw.from_native(self.performance_manager.fit_transform(df))
            assert df[self.performance_manager.ori_performance_column].to_list() == ori_perf_values

        self._performance_predictor.fit(df, self.performance_column)

        perf = df[self.performance_column]
        # Filter to finite values for validation (NaN/inf are treated as missing data)
        finite_perf = perf.filter(perf.is_finite())
        if len(finite_perf) > 0 and self._performance_prediction_is_bounded():
            if finite_perf.max() > 1.02 or finite_perf.min() < -0.02:
                raise ValueError(
                    f"Max {self.performance_column} must be less than than 1.02 and min value larger than -0.02. "
                    "Either transform it manually or set auto_scale_performance to True"
                )

            # Use weighted mean when weighted quantile scaling is active
            # because the weighted mean is what's calibrated to 0.5
            if (
                self.performance_manager
                and self.performance_manager._using_quantile_scaler
                and self.performance_manager.quantile_weight_column
                and self.performance_manager.quantile_weight_column in df.columns
            ):
                weights = df[self.performance_manager.quantile_weight_column]
                valid_mask = perf.is_finite() & weights.is_finite() & (weights > 0)
                if valid_mask.sum() > 0:
                    perf_values = perf.filter(valid_mask).to_numpy()
                    weight_values = weights.filter(valid_mask).to_numpy()
                    mean_val = float(np.average(perf_values, weights=weight_values))
                else:
                    mean_val = float(finite_perf.mean())
            else:
                mean_val = float(finite_perf.mean())

            if getattr(self._performance_predictor, "requires_centered_target_mean", True) and (
                mean_val < 0.42 or mean_val > 0.58
            ):
                raise ValueError(
                    f"Mean {self.performance_column} must be between 0.42 and 0.58. "
                    "Either transform it manually or set auto_scale_performance to True"
                )

        pl_df = df.to_native() if df.implementation.is_polars() else df.to_polars().to_native()
        result = self._historical_transform(pl_df)
        return result.lazy() if was_lazy else result

    @to_polars
    @nw.narwhalify
    def transform(self, df: IntoFrameT) -> IntoFrameT:
        pl_df, was_lazy = self._to_polars_eager(df)
        df = nw.from_native(pl_df)
        self._validate_performance_features(pl_df)

        if (
            self.performance_manager
            and self.performance_manager.ori_performance_column in df.columns
        ):
            df = nw.from_native(self.performance_manager.transform(df))

        pl_df = df.to_native() if df.implementation.is_polars() else df.to_polars().to_native()
        result = self._historical_transform(pl_df)
        return result.lazy() if was_lazy else result

    @to_polars
    @nw.narwhalify
    def future_transform(self, df: IntoFrameT) -> IntoFrameT:
        """
        Called only for future fixtures:
        - use existing ratings to compute pre-match ratings/features
        - do NOT update ratings
        """
        pl_df, was_lazy = self._to_polars_eager(df)
        self._validate_performance_features(pl_df)
        result = self._future_transform(pl_df)
        return result.lazy() if was_lazy else result

    @abstractmethod
    def _future_transform(self, df: pl.DataFrame):
        pass

    @abstractmethod
    def _historical_transform(self, df: pl.DataFrame):
        pass

    def _create_performance_manager(self) -> PerformanceManager | None:
        if self.performance_manager:
            if (
                self.performance_column
                and self.performance_column != self.performance_manager.performance_column
            ):
                self.performance_manager.performance_column = self.performance_column
                logging.info(f"Renamed performance column to performance_{self.performance_column}")
            elif not self.performance_column:
                self.performance_column = self.performance_manager.performance_column
            return self.performance_manager

        if self.performance_weights:
            if isinstance(self.performance_weights[0], dict):
                # Map 'col' to 'name' for backward compatibility
                converted_weights = []
                for weight in self.performance_weights:
                    weight_dict = dict(weight)
                    if "col" in weight_dict and "name" not in weight_dict:
                        weight_dict["name"] = weight_dict.pop("col")
                    converted_weights.append(ColumnWeight(**weight_dict))
                self.performance_weights = converted_weights
            return PerformanceWeightsManager(
                weights=self.performance_weights,
                performance_column=self.performance_column,
            )

        if self.auto_scale_performance and not self.performance_manager:
            assert self.performance_column, (
                "performance_column must be set if auto_scale_performance is True"
            )
            if not self.performance_weights:
                return PerformanceManager(
                    features=[self.performance_column],
                    performance_column=self.performance_column,
                )
            return PerformanceWeightsManager(
                weights=self.performance_weights,
                performance_column=self.performance_column,
            )

        return None

    def _add_day_number(
        self,
        df: pl.DataFrame,
        date_col: str | None = None,
        out_col: str = "__day_number",
        ref_date: str = "2000-01-01",  # <- new: reference epoch (YYYY-MM-DD)
        one_based: bool = True,  # <- optional: keep 1-based numbering like before
    ) -> pl.DataFrame:
        """
        Add day_number column to dataframe relative to a fixed reference date.

        day_number = (date - ref_date) + (1 if one_based else 0)

        Supports various date formats: string, Date, Datetime (with or without timezone).

        Args:
            df: Input dataframe
            date_col: Column name containing dates (defaults to column_names.start_date)
            out_col: Output column name (defaults to "__day_number")
            ref_date: Reference date in YYYY-MM-DD (defaults to 2000-01-01)
            one_based: If True, 2000-01-01 -> 1. If False, 2000-01-01 -> 0.

        Returns:
            DataFrame with added day_number column
        """
        cn = self.column_names
        date_column = date_col if date_col else cn.start_date

        if date_column not in df.columns:
            raise ValueError(
                f"Date column '{date_column}' not found in dataframe columns: {df.columns}"
            )

        dtype = df.schema.get(date_column)
        c = pl.col(date_column)

        if dtype == pl.Utf8 or (hasattr(pl, "String") and dtype == pl.String):
            dt = (
                c.str.strptime(pl.Datetime(time_zone=None), "%Y-%m-%d", strict=False)
                .fill_null(
                    c.str.strptime(pl.Datetime(time_zone=None), "%Y-%m-%d %H:%M:%S", strict=False)
                )
                .fill_null(
                    c.str.strptime(pl.Datetime(time_zone=None), "%Y-%m-%dT%H:%M:%S", strict=False)
                )
                .fill_null(c.cast(pl.Datetime(time_zone=None), strict=False))
            )
            dt = dt.dt.replace_time_zone(None)
        elif dtype == pl.Date:
            dt = c.cast(pl.Datetime(time_zone=None))
        elif isinstance(dtype, pl.Datetime):
            dt = (
                c
                if dtype.time_zone is None
                else c.dt.convert_time_zone("UTC").dt.replace_time_zone(None)
            )
        else:
            dt = c.cast(pl.Datetime(time_zone=None), strict=False).dt.replace_time_zone(None)

        start_as_int = dt.cast(pl.Date).cast(pl.Int32)

        ref_int = pl.lit(ref_date).str.strptime(pl.Date, "%Y-%m-%d", strict=True).cast(pl.Int32)

        offset = 1 if one_based else 0
        day_number = (start_as_int - ref_int + offset).fill_null(offset)

        return df.with_columns(day_number.alias(out_col))

    def _applied_multiplier(self, state: RatingState, base_multiplier: float) -> float:
        min_mult = base_multiplier * self.min_rating_change_multiplier_ratio
        conf_mult = base_multiplier * (
            (EXPECTED_MEAN_CONFIDENCE_SUM - state.confidence_sum) / self.confidence_value_denom + 1
        )
        applied = (
            conf_mult * self.confidence_weight + (1 - self.confidence_weight) * base_multiplier
        )
        return max(float(min_mult), float(applied))

    def _post_match_confidence_sum(
        self, state: RatingState, day_number: int, participation_weight: float
    ) -> float:
        days_ago = (
            0.0
            if state.last_match_day_number is None
            else float(day_number - state.last_match_day_number)
        )
        val = (
            -min(days_ago, self.confidence_max_days) * self.confidence_days_ago_multiplier
            + state.confidence_sum
            + MATCH_CONTRIBUTION_TO_SUM_VALUE * participation_weight
        )
        return max(0.0, min(float(val), self.confidence_max_sum))

    def _calculate_days_ago_since_last_match(self, last_match_day_number, day_number: int) -> float:
        if last_match_day_number is None:
            return 0.0
        return float(day_number - last_match_day_number)
