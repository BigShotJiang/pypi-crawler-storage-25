from __future__ import annotations

import copy
import math
from dataclasses import dataclass
from typing import Any

import numpy as np
from narwhals.typing import IntoFrameT

from spforge.ratings.player_performance_predictor import (
    PerformancePredictor,
    PredictedPerformanceSample,
)


@dataclass
class PredictedPerformanceOptimizationResult:
    coefficients: dict[str, float]
    intercept: float
    loss_history: list[float]
    n_iterations: int
    rating_generator: Any

    @property
    def learned_coefficients(self) -> dict[str, float]:
        return self.coefficients


class PredictedPerformanceOptimizer:
    def __init__(
        self,
        rating_generator: Any,
        learning_rate: float = 0.01,
        l2_penalty: float = 0.0,
        max_iterations: int = 25,
        tolerance: float = 1e-6,
    ):
        self.rating_generator = rating_generator
        self.learning_rate = learning_rate
        self.l2_penalty = l2_penalty
        self.max_iterations = max_iterations
        self.tolerance = tolerance
        if self.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        if self.l2_penalty < 0:
            raise ValueError("l2_penalty must be non-negative")
        if self.max_iterations < 1:
            raise ValueError("max_iterations must be positive")
        if self.tolerance < 0:
            raise ValueError("tolerance must be non-negative")

    def optimize(self, df: IntoFrameT) -> PredictedPerformanceOptimizationResult:
        working_generator = copy.deepcopy(self.rating_generator)
        predictor = self._ensure_performance_predictor(working_generator)
        fit_features = list(getattr(predictor, "fit_features", []))
        should_prefit = fit_features or getattr(predictor, "_target_model_explicit", False)
        if should_prefit:
            prefit_generator = copy.deepcopy(working_generator)
            prefit_generator.fit_transform(df)
            prefit_predictor = self._ensure_performance_predictor(prefit_generator)
            coefficients = dict(prefit_predictor.coefficients)
            intercept = float(prefit_predictor.intercept)
        else:
            coefficients = dict(predictor.coefficients)
            intercept = float(predictor.intercept)
        loss_history: list[float] = []
        fitted_predictor: PerformancePredictor | None = None

        for iteration in range(self.max_iterations):
            pass_generator = copy.deepcopy(working_generator)
            pass_predictor = self._ensure_performance_predictor(pass_generator)
            pass_predictor.coefficients = dict(coefficients)
            pass_predictor.intercept = float(intercept)
            pass_predictor.fit_features = []
            pass_predictor._target_model_explicit = False
            pass_generator.enable_prediction_sample_collection(True)
            pass_generator.fit_transform(df)
            fitted_predictor = pass_predictor

            samples = pass_generator.prediction_samples
            if not samples:
                raise ValueError("No predicted performance samples were collected")

            loss = self._loss(samples)
            loss_history.append(loss)
            if iteration > 0 and abs(loss_history[-2] - loss) <= self.tolerance:
                break

            coefficient_gradients, intercept_gradient = self._gradients(
                samples=samples,
                coefficients=coefficients,
                predictor=pass_predictor,
            )
            coefficients, intercept = self._apply_gradients(
                coefficients=coefficients,
                intercept=intercept,
                coefficient_gradients=coefficient_gradients,
                intercept_gradient=intercept_gradient,
            )

        result_generator = copy.deepcopy(self.rating_generator)
        result_predictor = self._ensure_performance_predictor(result_generator)
        result_predictor.coefficients = dict(coefficients)
        result_predictor.intercept = float(intercept)
        if fitted_predictor is not None:
            result_predictor.target_model = copy.deepcopy(fitted_predictor.target_model)
            result_predictor.target_model_name = fitted_predictor.target_model_name
            result_predictor.selected_target_model = fitted_predictor.selected_target_model
            result_predictor.sigmoid = fitted_predictor.sigmoid
            result_predictor.target_diagnostics = fitted_predictor.target_diagnostics
            result_predictor.target_mean = fitted_predictor.target_mean
            result_predictor.target_std = fitted_predictor.target_std
            result_predictor.target_zero_fraction = fitted_predictor.target_zero_fraction
            result_predictor.target_min = fitted_predictor.target_min
            result_predictor.target_max = fitted_predictor.target_max
        result_predictor.fit_features = []
        result_predictor._target_model_explicit = False

        return PredictedPerformanceOptimizationResult(
            coefficients=coefficients,
            intercept=intercept,
            loss_history=loss_history,
            n_iterations=len(loss_history),
            rating_generator=result_generator,
        )

    @staticmethod
    def _ensure_performance_predictor(rating_generator: Any) -> PerformancePredictor:
        predictor = getattr(rating_generator, "_performance_predictor", None)
        if isinstance(predictor, PerformancePredictor):
            return predictor

        predictor = PerformancePredictor()
        rating_generator._performance_predictor = predictor
        rating_generator.performance_predictor = predictor
        return predictor

    @staticmethod
    def _loss(samples: list[PredictedPerformanceSample]) -> float:
        weighted_error_sum = 0.0
        weight_sum = 0.0
        for sample in samples:
            error = float(sample.prediction) - float(sample.target)
            weight = float(sample.weight)
            weighted_error_sum += weight * error * error
            weight_sum += weight
        return weighted_error_sum / weight_sum if weight_sum else math.inf

    def _gradients(
        self,
        *,
        samples: list[PredictedPerformanceSample],
        coefficients: dict[str, float],
        predictor: PerformancePredictor,
    ) -> tuple[dict[str, float], float]:
        gradients: dict[str, float] = {}
        intercept_gradient = 0.0
        weight_sum = 0.0

        for sample in samples:
            prediction = float(sample.prediction)
            error = prediction - float(sample.target)
            derivative = predictor._prediction_derivative(sample.features)
            weight = float(sample.weight)
            weight_sum += weight
            intercept_gradient += 2.0 * weight * error * derivative
            for feature, value in sample.features.items():
                if feature not in coefficients:
                    continue
                gradients[feature] = (
                    gradients.get(feature, 0.0) + 2.0 * weight * error * derivative * value
                )

        denom = weight_sum if weight_sum else 1.0
        intercept_gradient = float(np.clip(intercept_gradient / denom, -1e6, 1e6))
        for feature in list(gradients):
            gradient = gradients[feature] / denom
            gradient += 2.0 * self.l2_penalty * coefficients.get(feature, 0.0)
            gradients[feature] = float(np.clip(gradient, -1e6, 1e6))

        return gradients, intercept_gradient

    def _apply_gradients(
        self,
        *,
        coefficients: dict[str, float],
        intercept: float,
        coefficient_gradients: dict[str, float],
        intercept_gradient: float,
    ) -> tuple[dict[str, float], float]:
        updated = dict(coefficients)
        for feature, gradient in coefficient_gradients.items():
            updated[feature] = updated.get(feature, 0.0) - self.learning_rate * gradient
        return updated, float(intercept - self.learning_rate * intercept_gradient)
