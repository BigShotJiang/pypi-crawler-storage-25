"""Mapping-aware client-side conversion of Python values to OpenSearch types.

Recursively walks a data dict alongside an OpenSearch index mapping and
coerces Python values so they match the expected field types (text, keyword,
integer, date, binary, knn_vector, nested, etc.).

Primary entry point:
    ``convert_clientside(data, curr_mapping)``

The *curr_mapping* can be either the raw ``{"properties": {...}}`` tree or
just the inner ``properties`` dict -- the function handles both.
"""

from .dict import travel_dict
from .timestamp import string_to_datetime
import json
import base64
import logging
import datetime as dt
from typing import Dict, Any

logger = logging.getLogger(__name__)

vector_nomenclature_order = [
    "model_name",
    "dim",
    "model_version",
]

conversion_matrix = {
    ("str", "text"): lambda d: (d, False),
    ("str", "keyword"): lambda d: (d, False),
    ("str", "boolean"): lambda d: (bool(d), False),
    ("str", "integer"): lambda d: (int(d), False),
    ("str", "long"): lambda d: (int(d), False),
    ("str", "float"): lambda d: (float(d), False),
    ("str", "double"): lambda d: (float(d), False),
    ("str", "date"): lambda d: (
        string_to_datetime(d).strftime("%Y-%m-%dT%H:%M:%SZ"),
        False,
    ),
    ("str", "binary"): lambda d: (
        base64.b64encode(d.encode("utf-8")).decode("utf-8"),
        False,
    ),
    ("str", "object"): lambda d: (json.loads(d), True),
    ("str", "nested"): lambda d: (json.loads(d), True),
    ("bool", "text"): lambda d: (str(d), False),
    ("bool", "keyword"): lambda d: (str(d), False),
    ("bool", "boolean"): lambda d: (d, False),
    ("bool", "integer"): lambda d: (int(d), False),
    ("bool", "long"): lambda d: (int(d), False),
    ("bool", "float"): lambda d: (float(int(d)), False),
    ("bool", "double"): lambda d: (float(int(d)), False),
    ("bool", "binary"): lambda d: (
        base64.b64encode(str(int(d)).encode("utf-8")).decode("utf-8"),
        False,
    ),
    ("int", "text"): lambda d: (str(d), False),
    ("int", "keyword"): lambda d: (str(d), False),
    ("int", "boolean"): lambda d: (bool(d), False),
    ("int", "integer"): lambda d: (d, False),
    ("int", "long"): lambda d: (d, False),
    ("int", "float"): lambda d: (float(d), False),
    ("int", "double"): lambda d: (float(d), False),
    ("int", "date"): lambda d: (
        dt.datetime.fromtimestamp(d).strftime("%Y-%m-%dT%H:%M:%SZ"),
        False,
    ),
    ("int", "binary"): lambda d: (
        base64.b64encode(str(d).encode("utf-8")).decode("utf-8"),
        False,
    ),
    ("float", "text"): lambda d: (str(d), False),
    ("float", "keyword"): lambda d: (str(d), False),
    ("float", "boolean"): lambda d: (bool(d), False),
    ("float", "integer"): lambda d: (int(d), False),
    ("float", "long"): lambda d: (int(d), False),
    ("float", "float"): lambda d: (d, False),
    ("float", "double"): lambda d: (d, False),
    ("float", "date"): lambda d: (
        dt.datetime.fromtimestamp(int(d)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        False,
    ),
    ("float", "binary"): lambda d: (
        base64.b64encode(str(d).encode("utf-8")).decode("utf-8"),
        False,
    ),
    ("bytes", "text"): lambda d: (d.decode("utf-8"), False),
    ("bytes", "keyword"): lambda d: (d.decode("utf-8"), False),
    ("bytes", "boolean"): lambda d: (
        d.decode("utf-8").lower() in ["true", "1", "yes", "y", "on"],
        False,
    ),
    ("bytes", "integer"): lambda d: (int(d.decode("utf-8")), False),
    ("bytes", "long"): lambda d: (int(d.decode("utf-8")), False),
    ("bytes", "float"): lambda d: (float(d.decode("utf-8")), False),
    ("bytes", "double"): lambda d: (float(d.decode("utf-8")), False),
    ("bytes", "date"): lambda d: (
        string_to_datetime(d.decode("utf-8")).strftime("%Y-%m-%dT%H:%M:%SZ"),
        False,
    ),
    ("bytes", "binary"): lambda d: (base64.b64encode(d).decode("utf-8"), False),
    ("bytes", "object"): lambda d: (json.loads(d.decode("utf-8")), True),
    ("bytes", "nested"): lambda d: (json.loads(d.decode("utf-8")), True),
    ("dict", "text"): lambda d: (json.dumps(d), False),
    ("dict", "keyword"): lambda d: (json.dumps(d), False),
    ("dict", "boolean"): lambda d: (bool(d), False),
    ("dict", "object"): lambda d: (d, True),
    ("dict", "nested"): lambda d: (d, True),
}


_CANONICAL_TYPES = (str, bool, int, float, bytes, dict, list)


def _canonical_type_name(value):
    """Return the base Python type name for *value*, collapsing subclasses."""
    for t in _CANONICAL_TYPES:
        if isinstance(value, t):
            return t.__name__
    return type(value).__name__


def has_opensearch_type(mapping):
    return "type" in mapping and isinstance(mapping["type"], str)


def has_opensearch_properties(mapping):
    return (
        "properties" in mapping
        and isinstance(mapping["properties"], dict)
        and ("type" not in mapping or has_opensearch_type(mapping))
    )


def mapping_from_data(data, mapping):
    python_to_os_types = {
        "str": "text",
        "bool": "boolean",
        "int": "long",
        "float": "double",
    }
    if not mapping:
        mapping = {}
    if data is None:
        return mapping
    datatype = _canonical_type_name(data)
    if datatype == "NoneType" or data == {} or data == []:
        return {}
    if datatype not in ["str", "bool", "int", "float", "bytes", "dict", "list"]:
        raise TypeError()
    elif datatype == "dict":
        for key, value in data.items():
            mapping[key] = mapping_from_data(value, {})
    elif datatype == "list":
        mapping = mapping_from_data(data[0], {})
    else:
        if datatype == "bytes":
            datatype = "str"
        datatype = python_to_os_types[datatype]
        if datatype == "text":
            try:
                dt.datetime.fromisoformat(data)
                datatype = "date"
            except Exception:
                pass
        mapping = {"type": datatype}
    return mapping


def convert_data_type(data, curr_mapping, key):
    data_elem = travel_dict(data, key, "r", True)
    if data_elem is None or data_elem == []:
        return
    data_type = _canonical_type_name(data_elem)
    if not curr_mapping:
        curr_mapping = mapping_from_data(data_elem, {})
    if not has_opensearch_type(curr_mapping):
        mapping_type = "object"
    else:
        mapping_type = curr_mapping.get("type", "object")
    recurse = False
    try:
        converted_elem, recurse = conversion_matrix[(data_type, mapping_type)](
            data_elem
        )
    except BaseException as e:
        logger.warning(f"{type(e).__name__}: {str(e)}")
        converted_elem = None
    if converted_elem and recurse:
        converted_elem = convert_clientside(converted_elem, curr_mapping)
    travel_dict(data, key, "w", True)(converted_elem)


def handle_incompatible_data_type(data, key):
    value = travel_dict(data, key, "r", True)
    datatype = _canonical_type_name(value)
    if datatype == "NoneType":
        return data
    if datatype not in ["str", "bool", "int", "float", "bytes", "dict", "list"]:
        travel_dict(data, key, "w")(str(value))
    return data


def handle_data_dict(data, curr_mapping, key):
    curr_data = travel_dict(data, key, "r")
    if (
        curr_mapping
        and has_opensearch_type(curr_mapping)
        and curr_mapping.get("type") not in ["object", "nested"]
    ):
        convert_data_type(data, curr_mapping, key)
    else:
        for subkey in list(curr_data.keys()):
            convert_clientside(data, curr_mapping.get(subkey), key + [subkey])
            sub_val = curr_data.get(subkey)
            if isinstance(sub_val, dict):
                sub_val.pop("#type", None)


def get_vector_name(metadata: Dict[str, Any]) -> str:
    vector_name = "vector"
    for prop in vector_nomenclature_order:
        if prop in metadata:
            vector_name += f"_{metadata[prop]}"
    return vector_name


def validate_vector_data(vector_data, curr_mapping):
    try:
        assert "data" in vector_data, "'data' field missing in vector_data"
        assert (
            isinstance(vector_data["data"], list) and vector_data["data"]
        ), "'data' must be a non-empty list"
        assert "metadata" in vector_data, "'metadata' field missing in vector_data"
        assert isinstance(
            vector_data["metadata"], dict
        ), "'metadata' must be a dictionary"
        assert "dim" in vector_data["metadata"], "'dim' field missing in 'metadata'"
        assert (
            isinstance(vector_data["metadata"]["dim"], int)
            and vector_data["metadata"]["dim"] > 0
        ), "'dim' must be a positive integer"
        assert vector_data["metadata"]["dim"] == len(
            vector_data["data"]
        ), "'dim' must match the length of 'data'"
        return True
    except AssertionError as e:
        logger.warning(f"Validation failed: {str(e)}")
        return False


def handle_data_vector(data, curr_mapping, key, vector_data=None):
    if vector_data is None:
        vector_data = travel_dict(data, key, "r")

    if not validate_vector_data(vector_data, curr_mapping):
        convert_clientside(data, curr_mapping, key)
        return

    vector_name = get_vector_name(vector_data["metadata"])

    if vector_name not in curr_mapping:
        logger.warning(
            f"Found valid vector in input data but no field '{vector_name}' allocated in OpenSearch for it"
        )
        convert_clientside(data, curr_mapping, key)
        return

    travel_dict(data, key, "w")(
        {
            vector_name: {
                "value": vector_data["data"],
            },
            "#type": "VECTOR",
        }
    )


def handle_data_list(data, curr_mapping, key):
    def _align_elems_to_mapping(
        data, super_path, i, path, elem_structure, curr_mapping
    ):
        path = []
        for key in elem_structure.keys() | curr_mapping.keys():
            sub_path = path + [key]
            if key not in curr_mapping:
                continue
            if key not in elem_structure:
                convert_clientside(data, elem_structure, super_path + [i] + sub_path)
            else:
                if isinstance(elem_structure[key], dict) and isinstance(
                    curr_mapping[key], dict
                ):
                    _align_elems_to_mapping(
                        data,
                        super_path,
                        i,
                        sub_path,
                        elem_structure[key],
                        curr_mapping[key],
                    )
                elif elem_structure[key] != curr_mapping[key]:
                    convert_clientside(
                        data, elem_structure, super_path + [i] + sub_path
                    )

    curr_data = travel_dict(data, key, "r")
    if len(curr_data) == 0:
        return

    elem_structure = {}
    for i, elem in enumerate(curr_data):
        data = convert_clientside(data, curr_mapping, key + [i])
        elem = travel_dict(data, key + [i], "r")
        elem_structure = {**mapping_from_data(elem, {}), **elem_structure}
    elem_structure = {**elem_structure, **curr_mapping}

    if isinstance(curr_data[0], dict) and curr_data[0].get("#type") == "VECTOR":
        vectors_data = {}
        for i, elem in enumerate(curr_data):
            elem.pop("#type", None)
            for vector_name in elem:
                if vector_name not in vectors_data:
                    vectors_data[vector_name] = []
                vectors_data[vector_name].append({"value": elem[vector_name]["value"]})
        travel_dict(data, key, "w")(vectors_data)
        elem_structure.pop("#type")

    if elem_structure != curr_mapping:
        _align_elems_to_mapping(data, key, i, [], elem_structure, curr_mapping)


def convert_clientside(data, curr_mapping, parent_keylist=[]):
    """Recursively convert *data* so values match the OpenSearch *curr_mapping*.

    *curr_mapping* may be a full mapping dict (with a ``"properties"`` key) or
    the inner properties dict directly.  *parent_keylist* is used internally
    for recursive traversal and should normally be left empty.
    """
    if not curr_mapping:
        curr_mapping = {}
    if has_opensearch_properties(curr_mapping):
        curr_mapping = curr_mapping["properties"]
    if parent_keylist:
        curr_data = travel_dict(data, parent_keylist, "r")
    else:
        curr_data = data
    if isinstance(curr_data, dict):
        if curr_data.get("#type") == "VECTOR":
            curr_data.pop("#type", None)
            handle_data_vector(data, curr_mapping, parent_keylist)
        else:
            curr_data.pop("#type", None)
            handle_data_dict(data, curr_mapping, parent_keylist)
    elif isinstance(curr_data, list):
        handle_data_list(data, curr_mapping, parent_keylist)
    elif isinstance(curr_data, (str, bool, int, float, bytes)):
        convert_data_type(data, curr_mapping, parent_keylist)
    else:
        handle_incompatible_data_type(data, parent_keylist)
        convert_data_type(data, curr_mapping, parent_keylist)
    return data
