def is_child_concept(type, parent_type, ontology):
    return type == parent_type or parent_type in ontology["concepts"][type]["parents"]

def get_label_keys(type, ontology):
    parents = set(ontology["concepts"][type]["parents"])
    parents.add(type)
    parents = list(parents)
    parents.reverse()
    label_keys = {} # for guaranteed insertion order
    for parent in parents:
        for label_key in ontology["concepts"][parent]["labelKeys"]:
            if not label_key:
                continue
            label_keys[label_key] = None
    return list(label_keys.keys())

def get_label(record, ontology):
    if record.get("os_entity_label_materialized") not in (None, ""):
        return str(record.get("os_entity_label_materialized")).strip()
    if record.get("os_entity_label") not in (None, ""):
        return str(record.get("os_entity_label")).strip()
    label_keys = get_label_keys(record["entity_type"], ontology)
    fields = [record.get(field) for field in label_keys]
    fields = [f for f in fields if f is not None]
    fields = [str(f) for f in fields if f]
    label = " ".join(fields)
    return label.strip() or None