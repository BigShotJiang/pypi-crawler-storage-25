"""
运行时上下文。

所有模块通过 CyberneticsContext 访问共享状态。
"""

from __future__ import annotations

import threading
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .config import CyberneticsConfig
from .core.base import CyberneticsEvent, EventType, ICyberneticsModule
from .runtime.event_bus import EventBus
from .runtime.metrics_collector import MetricsCollector
from .runtime.plugin_loader import PluginLoader
from .runtime.state_manager import StateManager

if TYPE_CHECKING:
    from pathlib import Path


class CyberneticsContext:
    """
    控制论运行时上下文。

    是整个控制论层的中心胞，负责：
    - 管理模块生命周期
    - 路由事件
    - 维护全局状态
    - 采集统计指标

    使用示例:
        >>> from cybernetics_agent import CyberneticsContext, CyberneticsConfig
        >>> config = CyberneticsConfig.from_json("cybernetics.json")
        >>> ctx = CyberneticsContext(config)
        >>> ctx.emit_tool_result("search", ["result1", "result2"])
    """

    def __init__(self, config: CyberneticsConfig) -> None:
        self.config = config
        self.event_bus = EventBus()
        self.state_manager = StateManager(config.storage)
        self.metrics = MetricsCollector()
        self._modules: dict[str, ICyberneticsModule] = {}
        self._session_id = f"sess_{uuid.uuid4().hex[:8]}"
        self._lock = threading.Lock()
        self._plugin_loader = PluginLoader()

    def load_plugins(self, plugin_dirs: list[str] | None = None) -> int:
        """
        加载插件目录中的所有插件。

        Args:
            plugin_dirs: 插件目录列表，默认使用配置中的 plugins.paths

        Returns:
            成功加载的插件数量
        """
        if plugin_dirs is None:
            plugin_cfg = getattr(self.config, "plugins", None) or {}
            plugin_dirs = plugin_cfg.get("paths", ["./plugins"]) if isinstance(plugin_cfg, dict) else ["./plugins"]

        loaded = 0
        for dir_str in plugin_dirs:
            plugin_dir = Path(dir_str)
            discovered = self._plugin_loader.discover(plugin_dir)
            for info in discovered:
                # 插件配置：优先使用配置文件中的插件特定配置
                plugin_cfg = (getattr(self.config, "plugins", None) or {}).get(info.name, {}) if isinstance(getattr(self.config, "plugins", None), dict) else {}
                instance = self._plugin_loader.load(info, plugin_cfg, self)
                if instance:
                    self.register_module(instance)
                    loaded += 1

        return loaded

    def unload_plugin(self, name: str) -> bool:
        """卸载指定插件。"""
        self._plugin_loader.unload(name)
        self.unregister_module(name)
        return True

    def list_plugins(self) -> dict[str, Any]:
        """列出已加载的插件状态。"""
        return {
            "loaded": self._plugin_loader.list_loaded(),
            "modules": list(self._modules.keys()),
        }

    @property
    def session_id(self) -> str:
        """当前 session ID。"""
        return self._session_id

    def register_module(self, module: ICyberneticsModule) -> None:
        """
        注册模块。

        模块注册后会自动订阅事件总线。
        """
        if not module.enabled:
            return
        with self._lock:
            self._modules[module.name] = module
        self.event_bus.subscribe(module)
        module.initialize()

    def unregister_module(self, name: str) -> None:
        """卸载模块。"""
        with self._lock:
            module = self._modules.pop(name, None)
        if module:
            self.event_bus.unsubscribe(module)
            module.shutdown()

    def emit(self, event: CyberneticsEvent) -> None:
        """
        发射事件到事件总线。

        所有订阅了该事件类型的模块会收到通知。
        """
        self.event_bus.emit(event)
        self.metrics.record_event(event)
        self.state_manager.save_event(event)

    def emit_tool_result(
        self,
        tool_name: str,
        result: Any,
        success: bool = True,
        duration: float = 0.0,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """便捷方法：发射工具调用结果事件。"""
        event = CyberneticsEvent.create(
            event_type=EventType.TOOL_RESULT,
            session_id=self._session_id,
            payload={
                "tool_name": tool_name,
                "result": result,
                "success": success,
                "duration": duration,
            },
            metadata=metadata or {},
        )
        self.emit(event)

    def emit_tool_error(
        self,
        tool_name: str,
        error: str,
        error_type: str = "unknown",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """便捷方法：发射工具错误事件。"""
        event = CyberneticsEvent.create(
            event_type=EventType.TOOL_ERROR,
            session_id=self._session_id,
            payload={
                "tool_name": tool_name,
                "error": error,
                "error_type": error_type,
            },
            metadata=metadata or {},
        )
        self.emit(event)

    def emit_llm_request(
        self,
        model: str,
        prompt_tokens: int = 0,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """便捷方法：发射 LLM 请求事件。"""
        event = CyberneticsEvent.create(
            event_type=EventType.LLM_REQUEST,
            session_id=self._session_id,
            payload={"model": model, "prompt_tokens": prompt_tokens},
            metadata=metadata or {},
        )
        self.emit(event)

    def emit_llm_response(
        self,
        model: str,
        completion_tokens: int = 0,
        duration: float = 0.0,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """便捷方法：发射 LLM 响应事件。"""
        event = CyberneticsEvent.create(
            event_type=EventType.LLM_RESPONSE,
            session_id=self._session_id,
            payload={
                "model": model,
                "completion_tokens": completion_tokens,
                "duration": duration,
            },
            metadata=metadata or {},
        )
        self.emit(event)

    def get_module(self, name: str) -> ICyberneticsModule | None:
        """获取指定名称的模块实例。"""
        with self._lock:
            return self._modules.get(name)

    def get_all_modules(self) -> dict[str, ICyberneticsModule]:
        """获取所有已注册模块。"""
        with self._lock:
            return dict(self._modules)

    def get_status(self) -> dict[str, Any]:
        """获取整体状态报告。"""
        with self._lock:
            modules = dict(self._modules)
        return {
            "session_id": self._session_id,
            "project_name": self.config.project_name,
            "modules": {
                name: mod.get_status()
                for name, mod in modules.items()
            },
            "metrics": self.metrics.get_summary(),
        }

    def shutdown(self) -> None:
        """关闭上下文，清理所有模块。"""
        with self._lock:
            names = list(self._modules.keys())
        for name in names:
            self.unregister_module(name)
        self.state_manager.close()
