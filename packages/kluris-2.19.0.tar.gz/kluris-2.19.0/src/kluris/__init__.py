"""Kluris — Turn AI agents into team subject matter experts."""

__version__ = "2.19.0"
