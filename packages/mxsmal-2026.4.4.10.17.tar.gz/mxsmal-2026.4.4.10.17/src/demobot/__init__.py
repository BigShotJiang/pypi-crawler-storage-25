from .demobot import main
