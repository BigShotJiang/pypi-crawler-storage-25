from .smalsetup import smalsetup
