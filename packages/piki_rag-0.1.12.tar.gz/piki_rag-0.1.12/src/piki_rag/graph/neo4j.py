from neo4j import Driver
from sentence_transformers import SentenceTransformer

from .db import GraphDataBaseProvider
from .model import GraphSearchResponse, Relation, Entity, KnowledgeExtraction


class TextNeo4jDataBaseProvider(GraphDataBaseProvider):
    def __init__(self, driver: Driver, n_results: int = 5):
        self.driver = driver
        self.n_results = n_results

    def search(
        self, knowledge: KnowledgeExtraction, n_results: int = None, **kwargs
    ) -> GraphSearchResponse:
        query_entities = [entity.text for entity in knowledge.entities]
        n_results = n_results if n_results is not None else self.n_results
        with self.driver.session() as session:
            result = session.run(
                """
                UNWIND $entities AS q
                MATCH (e:Entity {text: q})
                WITH DISTINCT e
                MATCH (e)-[r]->(o:Entity)
                RETURN
                    e.text AS subject_text,
                    e.type AS subject_type,
                    r.type AS relation_type,
                    o.text AS object_text,
                    o.type AS object_type,
                    r.source AS source
                LIMIT $limit
            """,
                entities=query_entities,
                limit=n_results,
            )
            relations = []
            for record in result:
                subject = Entity(
                    text=record["subject_text"], type=record["subject_type"]
                )
                object_ = Entity(text=record["object_text"], type=record["object_type"])
                relations.append(
                    Relation(
                        subject=subject,
                        predicate=record["relation_type"],
                        object=object_,
                        source=record["source"] or "",
                    )
                )
            return GraphSearchResponse(
                relations=relations, full_response=result.consume()
            )

    def add_knowledge(self, knowledge: list[KnowledgeExtraction], **kwargs):
        with self.driver.session() as session:
            for extraction in knowledge:
                entities_payload = [
                    {
                        "text": e.text,
                        "type": e.type,
                        "embedding": e.embedding or [],
                        "source": extraction.source,
                        "key": f"{e.type}:{e.text}",
                    }
                    for e in extraction.entities
                ]
                entity_result = session.run(
                    """
                    UNWIND $entities AS e
                    MERGE (n:Entity {text: e.text, type: e.type})
                    ON CREATE SET n.created_at = timestamp(),
                        n.embedding = e.embedding,
                        n.source = e.source
                    ON MATCH SET n.updated_at = timestamp()
                    WITH e, n
                    RETURN e.key AS key, elementId(n) AS entity_id
                """,
                    entities=entities_payload,
                )
                entity_map = {
                    record["key"]: record["entity_id"] for record in entity_result
                }
                relations_payload = []
                for r in extraction.relations:
                    subject_key = f"{r.subject.type}:{r.subject.text}"
                    object_key = f"{r.object.type}:{r.object.text}"
                    if subject_key in entity_map and object_key in entity_map:
                        relations_payload.append(
                            {
                                "subject_id": entity_map[subject_key],
                                "object_id": entity_map[object_key],
                                "type": r.predicate,
                                "source": r.source,
                            }
                        )
                if relations_payload:
                    session.run(
                        """
                        UNWIND $rels AS rel
                        MATCH (s:Entity) WHERE elementId(s) = rel.subject_id
                        MATCH (o:Entity) WHERE elementId(o) = rel.object_id
                        MERGE (s)-[r:RELATION {type: rel.type}]->(o)
                        SET r.source = rel.source
                    """,
                        rels=relations_payload,
                    )

    def close(self):
        if self.driver:
            self.driver.close()


class SemanticNeo4JDataBaseProvider(TextNeo4jDataBaseProvider):
    def __init__(
        self,
        driver: Driver,
        embedding_model: SentenceTransformer,
        n_results: int = 5,
        threshold=0.75,
    ):
        super().__init__(driver, n_results)
        self.embedding_model = embedding_model
        self.threshold = threshold
        self._setup_vector_index()

    def _setup_vector_index(self):
        with self.driver.session() as session:
            session.run(
                """
                CREATE VECTOR INDEX entity_embeddings IF NOT EXISTS
                FOR (e:Entity) ON e.embedding
                OPTIONS {indexConfig: {
                    `vector.dimensions`: $dimensions,
                    `vector.similarity_function`: 'cosine'
                }}
            """,
                dimensions=self.embedding_model.get_sentence_embedding_dimension(),
            )

    def search(
        self, knowledge: KnowledgeExtraction, n_results: int = None, **kwargs
    ) -> GraphSearchResponse:
        n_results = n_results if n_results is not None else self.n_results
        relations = []
        texts = [e.text for e in knowledge.entities]
        query_embeddings = self.embedding_model.encode(texts, batch_size=32)
        with self.driver.session() as session:
            result = session.run(
                """
                UNWIND $embeddings AS embedding
                CALL db.index.vector.queryNodes(
                    'entity_embeddings',
                    $top_k,
                    embedding
                ) YIELD node, score
                WITH node, score
                WHERE score > $threshold
                WITH DISTINCT node, score
                ORDER BY score DESC
                LIMIT $limit
                MATCH (node)-[r]->(related:Entity)
                RETURN
                    node.text AS subject_text,
                    node.type AS subject_type,
                    r.type AS relation_type,
                    related.text AS object_text,
                    related.type AS object_type,
                    r.source AS source,
                    score
            """,
                embeddings=query_embeddings,
                top_k=n_results,
                limit=n_results,
                threshold=self.threshold
            )
            for record in result:
                subject = Entity(
                    text=record["subject_text"], type=record["subject_type"]
                )
                object_ = Entity(text=record["object_text"], type=record["object_type"])
                relations.append(
                    Relation(
                        subject=subject,
                        predicate=record["relation_type"],
                        object=object_,
                        source=record["source"] or "",
                    )
                )
            return GraphSearchResponse(relations=relations)

    def add_knowledge(self, knowledge: list[KnowledgeExtraction], **kwargs):
        for extraction in knowledge:
            for entity in extraction.entities:
                entity.embedding = self.embedding_model.encode(entity.text).tolist()
        super().add_knowledge(knowledge, **kwargs)
