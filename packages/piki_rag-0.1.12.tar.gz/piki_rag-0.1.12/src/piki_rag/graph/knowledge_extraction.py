from abc import ABC, abstractmethod
from typing import List

from .model import KnowledgeExtraction
from ..vector.db import VectorSearchResponse, VectorSearchResponseItem


class KnowledgeExtractor(ABC):

    @abstractmethod
    def extract(
        self, vector_search_response_items: List[VectorSearchResponseItem]
    ) -> List[KnowledgeExtraction]:
        pass

    def extract_text(self, text: str) -> KnowledgeExtraction:
        knowledge_extractions = self.extract(
            [VectorSearchResponseItem(id=None, text=text, source=None, processed=False)]
        )
        if knowledge_extractions:
            return knowledge_extractions[0]
        return KnowledgeExtraction(chunk=text, entities=[], relations=[], source="")
