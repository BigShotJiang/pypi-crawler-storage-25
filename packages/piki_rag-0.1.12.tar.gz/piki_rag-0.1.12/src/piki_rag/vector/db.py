from abc import ABC, abstractmethod
from typing import List, Dict

from attr import dataclass


@dataclass
class VectorSearchResponseItem:
    id: str
    text: str
    source: str
    processed: bool


@dataclass
class VectorSearchResponse:
    answers: list[VectorSearchResponseItem]


class VectorDataBaseProvider(ABC):

    @abstractmethod
    def search(self, query: str, n_results: int = 5, **kwargs) -> VectorSearchResponse:
        pass

    @abstractmethod
    def update_processed(self, ids: List[str]):
        pass
