from typing import List

import chromadb

from .db import VectorDataBaseProvider, VectorSearchResponse, VectorSearchResponseItem


class ChromaDbProvider(VectorDataBaseProvider):
    def __init__(self, collection: chromadb.Collection):
        self.collection = collection

    def search(self, query: str, n_results: int = 5, **kwargs) -> VectorSearchResponse:
        results = self.collection.query(query_texts=[query], n_results=n_results)
        ids = results.get("ids", [[]])[0]
        documents = results.get("documents", [[]])[0]
        metadatas = results.get("metadatas", [[]])[0]
        answers = []
        for doc_id, text, meta in zip(ids, documents, metadatas):
            source = meta.get("source") if meta else None
            processed = meta.get("processed") if meta else None
            answers.append(
                VectorSearchResponseItem(
                    id=doc_id,
                    text=text,
                    source=source or doc_id,
                    processed=processed or False,
                )
            )
        return VectorSearchResponse(answers=answers)

    def update_processed(self, ids: List[str]):
        self.collection.update(
            ids=ids, metadatas=[{"processed": True} for i in range(len(ids))]
        )
