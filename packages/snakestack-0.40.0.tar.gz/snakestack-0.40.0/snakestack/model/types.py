from typing import Any

SnakeResponseDoc = dict[int | str, dict[str, Any]]
