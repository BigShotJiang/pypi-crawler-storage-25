from http import HTTPStatus
from typing import Any, Type

from pydantic import BaseModel

from snakestack.model.error import SnakeErrorModel
from snakestack.model.types import SnakeResponseDoc


def _create_http_status_code(status_code: int) -> HTTPStatus:
    return HTTPStatus(status_code)


def make_standard_response(
    status_code: int,
    *,
    model: Type[BaseModel],
    example: dict[str, Any] | None,
    content_type: str = "application/json",
    override_description: str | None = None,
) -> SnakeResponseDoc:
    status = _create_http_status_code(status_code=status_code)

    result = {
        "model": model,
        "description": override_description or status.description,
        "content": {
            content_type: {
                "example": example
            }
        },
    }

    if status_code == 204:
        result.pop("model")
        result.pop("content")
    elif not example:
        result.pop("content")

    return {
        status_code: result
    }


def make_standard_error_response(
    status_code: int,
    *,
    model: Type[BaseModel] | None = None,
    content_type: str = "application/json",
    example: dict[str, Any] | None = None,
    override_description: str | None = None,
    override_example: str | None = None
) -> SnakeResponseDoc:
    model = model or SnakeErrorModel
    desc_error = override_example or "Error"
    example = example or SnakeErrorModel(detail=desc_error).model_dump()
    return make_standard_response(
        status_code=status_code,
        model=model or SnakeErrorModel,
        override_description=override_description,
        example=example,
        content_type=content_type
    )


def make_standard_success_response(
    status_code: int,
    model: Type[BaseModel],
    *,
    description: str | None = None,
    example: dict[str, Any] | None = None,
    content_type: str = "application/json"
) -> SnakeResponseDoc:
    example = example or {"foo": "bar"}
    return make_standard_response(
        status_code=status_code,
        model=model,
        override_description=description,
        example=example,
        content_type=content_type
    )
