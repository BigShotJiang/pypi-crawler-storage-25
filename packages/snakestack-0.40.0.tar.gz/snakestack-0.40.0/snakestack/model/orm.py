from pydantic import BaseModel, ConfigDict


class SnakeOrmModel(BaseModel):
    model_config = ConfigDict(
        extra='forbid',
        from_attributes=True
    )
