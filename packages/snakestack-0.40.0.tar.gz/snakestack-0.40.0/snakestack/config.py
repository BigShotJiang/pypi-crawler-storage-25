from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from snakestack import version
from snakestack.cache.settings import CacheSettings
from snakestack.circuit_breaker.settings import CircuitBreakerSettings
from snakestack.log.settings import LogSettings
from snakestack.mongodb.settings import MongoDbSettings
from snakestack.pubsub.settings import PubSubSettings
from snakestack.retry.settings import RetrySettings
from snakestack.telemetry.settings import TelemetrySettings


class SnakeStackSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="SNAKESTACK_APP_",
        env_file_encoding="utf-8",
        env_nested_delimiter="__",
    )

    version: str = Field(
        default=version.__version__,
        description=""
    )

    cache: CacheSettings = Field(default_factory=CacheSettings)
    circuit_breaker: CircuitBreakerSettings = Field(default_factory=CircuitBreakerSettings)
    log: LogSettings = Field(default_factory=LogSettings)
    mongo: MongoDbSettings = Field(default_factory=MongoDbSettings)
    pubsub: PubSubSettings = Field(default_factory=PubSubSettings)
    telemetry: TelemetrySettings = Field(default_factory=TelemetrySettings)
    retry: RetrySettings = Field(default_factory=RetrySettings)


@lru_cache
def get_settings() -> SnakeStackSettings:
    return SnakeStackSettings()
