from typing import Any

from pydantic import Field, computed_field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from snakestack.log.enumerators import SnakeLogFilters, SnakeLogFormatter


class LogSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SNAKESTACK_LOG_")

    level: str = Field(
        default="INFO",
        description="Logging level for the application (e.g., DEBUG, INFO, WARNING, ERROR)."
    )

    name: str = Field(
        default="__main__",
        description="Name of the application (e.g., snakestack)."
    )

    lib_level: str = Field(
        default="WARNING",
        description="Logging level for the third libraries (e.g., INFO, WARNING, ERROR)."
    )

    formatter: str = Field(
        default="default",
        description="Default formatter to be used in the logging configuration (e.g., default, json, with_request_id)."
    )

    filters: str = Field(
        default="request_id",
        description="Comma-separated list of default filters to be applied to log records (e.g., request_id, excluded_name, filter_paths)."
    )

    filter_excluded_name: list[str] | None = Field(
        default=None,
        description="Logger name or pattern to exclude from logging output (e.g., 'exclude.me' to suppress logs from that logger)."
    )

    filter_paths: list[str] | None = Field(
        default=None,
        description="Comma-separated list of paths to filter log records (e.g., '/healthcheck' to suppress logs)."
    )

    @field_validator("formatter")
    @classmethod
    def validate_log_formatter(cls, v: str) -> str:
        allowed = [str(member.value) for member in SnakeLogFormatter]
        if v not in allowed:
            raise ValueError(f"Invalid formatter '{v}'. Must be one of: {', '.join(allowed)}.")
        return v

    @field_validator("filters")
    @classmethod
    def validate_log_filter(cls, v: Any) -> str:
        allowed = [str(member.value) for member in SnakeLogFilters]
        items = [i.strip() for i in v.split(",") if i.strip()]
        invalid = [i for i in items if i not in allowed]
        if invalid:
            raise ValueError(f"Invalid filters: {invalid}. Must be one of: {allowed}.")
        return str(v)

    @computed_field
    def filters_list(self) -> list[str]:
        return [i.strip() for i in self.filters.split(",") if i.strip()]

    @field_validator("filter_excluded_name", mode="before")
    @classmethod
    def convert_filter_excluded_name(cls, v: Any) -> list[str]:
        if not isinstance(v, str):
            return []

        return [p.strip() for p in v.split(",") if p.strip()]

    @field_validator("filter_paths", mode="before")
    @classmethod
    def convert_filter_paths(cls, v: Any) -> list[str]:
        if not isinstance(v, str):
            return []

        return [p.strip() for p in v.split(",") if p.strip()]

    @field_validator("level", "lib_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        allowed = {"CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG", "NOTSET"}
        value = v.upper().strip()
        if value not in allowed:
            raise ValueError(f"Invalid log level '{v}'. Must be one of {', '.join(allowed)}.")
        return value
