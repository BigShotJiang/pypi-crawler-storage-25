import logging
import logging.config
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from snakestack.config import SnakeStackSettings


def setup_logging(
    settings: "SnakeStackSettings"
) -> None:
    filters = {
        "request_id": {"()": "snakestack.log.filters.SnakeRequestIdFilter"},
        "excluded_name": {
            "()": "snakestack.log.filters.SnakeExcludeLoggerFilter",
            "excluded_name": settings.log.filter_excluded_name
        },
        "path_filter": {
            "()": "snakestack.log.filters.SnakePathFilter",
            "paths": settings.log.filter_paths
        }
    }

    third_party_formatter = (
        "default"
        if settings.log.formatter == "with_request_id"
        else settings.log.formatter
    )

    handlers = {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": settings.log.formatter,
            "filters": settings.log.filters_list,
        },
        "third_party_console": {
            "class": "logging.StreamHandler",
            "formatter": third_party_formatter
        },
    }

    formatters = {
        "default": {
            "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        },
        "with_request_id": {
            "format": (
                "%(asctime)s [%(levelname)s] [req_id=%(request_id)s] "
                "%(name)s: %(message)s"
            )
        },
        "json": {
            "()": "snakestack.log.formatters.SnakeJsonFormatter"
        }
    }

    logging_config: dict[str, Any] = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": formatters,
        "handlers": handlers,
        "filters": filters,
        "loggers": {
            settings.log.name: {
                "level": settings.log.level,
                "handlers": ["console"],
                "propagate": False,
            },
            "snakestack": {
                "level": settings.log.level,
                "handlers": ["console"],
                "propagate": False,
            }
        },
        "root": {
            "level": settings.log.lib_level,
            "handlers": ["console"]
        }
    }

    logging.config.dictConfig(logging_config)
