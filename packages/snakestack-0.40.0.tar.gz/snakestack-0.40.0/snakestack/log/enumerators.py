from enum import Enum, StrEnum


class SnakeLogLevel(int, Enum):
    CRITICAL = 50
    ERROR = 40
    WARNING = 30
    INFO = 20
    DEBUG = 10
    NOT_SET = 0


class SnakeLogFormatter(StrEnum):
    DEFAULT = "default"
    JSON = "json"
    WITH_REQUEST_ID = "with_request_id"


class SnakeLogFilters(StrEnum):
    REQUEST_ID = "request_id"
    EXCLUDED_NAME = "excluded_name"
    PATH_FILTER = "path_filter"
