from typing import Any, Self, cast

import orjson

try:
    from redis import Redis
except ImportError:
    raise RuntimeError("Cache extra is not installed. Run `pip install snakestack[cache]`.")

from snakestack.cache.decorators import handle_cache_error
from snakestack.log.encoders import safe_jsonable_encoder


class SnakeRedisService:
    def __init__(
        self: Self,
        client: Redis,
        default_ttl: int | None = None,
        prefix: str = "",
    ) -> None:
        self._client = client
        self._default_ttl = default_ttl
        self._prefix = prefix.strip(":")

    def _format_key(self: Self, key: str) -> str:
        return f"{self._prefix}:{key}" if self._prefix else key

    @handle_cache_error(default=False)
    def set(self: Self, key: str, value: Any, ex: int | None = None) -> bool:
        serialized = orjson.dumps(value, default=safe_jsonable_encoder)
        return bool(self._client.set(
            name=self._format_key(key),
            value=serialized,
            ex=ex if ex is not None else self._default_ttl,
        ))

    @handle_cache_error(default=None)
    def get(self: Self, key: str) -> Any | None:
        raw = cast("bytes | None", self._client.get(self._format_key(key)))
        if raw is None:
            return None
        try:
            return orjson.loads(raw)
        except orjson.JSONDecodeError:
            return raw

    @handle_cache_error(default=0)
    def delete(self: Self, key: str) -> int:
        result = self._client.delete(self._format_key(key))
        return cast(int, result)

    @handle_cache_error(default=False)
    def exists(self: Self, key: str) -> bool:
        return bool(self._client.exists(self._format_key(key)))

    @handle_cache_error(default=False)
    def expire(self: Self, key: str, ttl: int) -> bool:
        return bool(self._client.expire(self._format_key(key), ttl))

    @handle_cache_error(default=0)
    def incr(self: Self, key: str, amount: int = 1) -> int:
        result = self._client.incr(self._format_key(key), amount)
        return cast(int, result)

    @handle_cache_error(default=0)
    def decr(self: Self, key: str, amount: int = 1) -> int:
        result = self._client.decr(self._format_key(key), amount)
        return cast(int, result)

    @handle_cache_error(default=0)
    def ttl(self: Self, key: str) -> int:
        result = self._client.ttl(self._format_key(key))
        return cast(int, result)

    @handle_cache_error(default=False)
    def ping(self: Self) -> bool:
        result = self._client.ping()
        return cast(bool, result)
