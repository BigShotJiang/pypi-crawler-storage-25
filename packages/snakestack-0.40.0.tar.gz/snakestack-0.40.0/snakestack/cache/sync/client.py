from typing import Any

try:
    from redis import Redis
except ImportError:
    raise RuntimeError("Cache extra is not installed. Run `pip install snakestack[cache]`.")


def create_redis_client(
    host: str = "localhost",
    port: int = 6379,
    db: int = 0,
    username: str | None = None,
    password: str | None = None,
    decode_responses: bool = True,
    **kwargs: Any,
) -> Redis:
    return Redis(
        host=host,
        port=port,
        db=db,
        username=username,
        password=password,
        decode_responses=decode_responses,
        **kwargs,
    )
