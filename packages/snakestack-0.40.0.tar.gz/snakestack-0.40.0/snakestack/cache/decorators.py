import inspect
import logging
from functools import wraps
from typing import Any, Callable, TypeVar, cast

try:
    from redis.exceptions import RedisError
except ImportError:
    raise RuntimeError("Cache extra is not installed. Run `pip install snakestack[cache]`.")

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


def handle_cache_error(
    default: Any = None
) -> Callable[[F], F]:
    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return func(*args, **kwargs)
            except RedisError:
                logger.exception("Redis operation failed.")
                from snakestack.config import (
                    get_settings,  # lazy import to avoid circular
                )
                if not get_settings().cache.suppress_errors:
                    raise
                return default

        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return await func(*args, **kwargs)
            except RedisError:
                logger.exception("Redis operation failed.")
                from snakestack.config import (
                    get_settings,  # lazy import to avoid circular
                )
                if not get_settings().cache.suppress_errors:
                    raise
                return default

        if inspect.iscoroutinefunction(func):
            return cast(F, async_wrapper)
        return cast(F, wrapper)

    return decorator
