from typing import Any, Self, cast

import orjson

try:
    from redis.asyncio import Redis
except ImportError:
    raise RuntimeError("Cache extra is not installed. Run `pip install snakestack[cache]`.")

from snakestack.cache.decorators import handle_cache_error
from snakestack.log.encoders import safe_jsonable_encoder


class SnakeAsyncRedisService:
    def __init__(
        self: Self,
        client: Redis,
        default_ttl: int | None = None,
        prefix: str = "",
    ) -> None:
        self._client = client
        self._default_ttl = default_ttl
        self._prefix = prefix.strip(":")

    def _format_key(self: Self, key: str) -> str:
        return f"{self._prefix}:{key}" if self._prefix else key

    @handle_cache_error(default=False)
    async def set(self: Self, key: str, value: Any, ex: int | None = None) -> bool:
        serialized = orjson.dumps(value, default=safe_jsonable_encoder)
        return bool(await self._client.set(
            name=self._format_key(key),
            value=serialized,
            ex=ex if ex is not None else self._default_ttl,
        ))

    @handle_cache_error(default=None)
    async def get(self: Self, key: str) -> Any | None:
        raw = await self._client.get(self._format_key(key))
        if raw is None:
            return None
        try:
            return orjson.loads(raw)
        except orjson.JSONDecodeError:
            return raw

    @handle_cache_error(default=0)
    async def delete(self: Self, key: str) -> int:
        result = await self._client.delete(self._format_key(key))
        return cast(int, result)

    @handle_cache_error(default=False)
    async def exists(self: Self, key: str) -> bool:
        return bool(await self._client.exists(self._format_key(key)))

    @handle_cache_error(default=False)
    async def expire(self: Self, key: str, ttl: int) -> bool:
        return bool(await self._client.expire(self._format_key(key), ttl))

    @handle_cache_error(default=0)
    async def incr(self: Self, key: str, amount: int = 1) -> int:
        result = await self._client.incr(self._format_key(key), amount)
        return cast(int, result)

    @handle_cache_error(default=0)
    async def decr(self: Self, key: str, amount: int = 1) -> int:
        result = await self._client.decr(self._format_key(key), amount)
        return cast(int, result)

    @handle_cache_error(default=0)
    async def ttl(self: Self, key: str) -> int:
        result = await self._client.ttl(self._format_key(key))
        return cast(int, result)

    @handle_cache_error(default=False)
    async def ping(self: Self) -> bool:
        result = await self._client.ping()
        return cast(bool, result)
