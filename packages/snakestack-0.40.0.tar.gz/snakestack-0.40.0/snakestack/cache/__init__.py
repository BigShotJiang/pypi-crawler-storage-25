from __future__ import annotations

_import_error: RuntimeError | None = None

try:
    from snakestack.cache.asyncio.client import create_async_redis_client
    from snakestack.cache.asyncio.service import SnakeAsyncRedisService
    from snakestack.cache.sync.client import create_redis_client
    from snakestack.cache.sync.service import SnakeRedisService
except RuntimeError as e:
    _import_error = e


def __getattr__(name: str) -> object:
    if _import_error is not None:
        raise _import_error
    raise AttributeError(f"module 'snakestack.cache' has no attribute {name!r}")  # pragma: no cover


__all__ = [
    "create_async_redis_client",
    "SnakeAsyncRedisService",
    "create_redis_client",
    "SnakeRedisService",
]
