from __future__ import annotations


class SnakeCircuitBreakerError(Exception):
    ...


class SnakeCircuitOpenError(SnakeCircuitBreakerError):
    def __init__(self, name: str) -> None:
        super().__init__(f"Circuit breaker '{name}' is open and not accepting calls.")
        self.name = name
