from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, Literal, TypeVar

import httpx

from snakestack.circuit_breaker.decorators import circuit_breaker
from snakestack.circuit_breaker.types import ExcludeItem

if TYPE_CHECKING:
    from redis import Redis

F = TypeVar("F", bound=Callable[..., Any])


def _is_http_4xx_error(exc: BaseException) -> bool:
    from snakestack.http_client.exceptions import SnakeHttpRequestError

    original = exc
    if isinstance(exc, SnakeHttpRequestError):
        original = exc.original_exception

    return (
        isinstance(original, httpx.HTTPStatusError)
        and original.response.status_code < 500
    )


_HTTP_EXCLUDE: tuple[ExcludeItem, ...] = (_is_http_4xx_error,)


def circuit_breaker_http(
    name: str,
    *,
    fail_max: int = 5,
    reset_timeout: float = 30,
    success_threshold: int = 2,
    exclude: tuple[ExcludeItem, ...] = _HTTP_EXCLUDE,
    backend: Literal["memory", "redis"] = "memory",
    redis_client: Redis | None = None,
    enable_logging: bool = True,
    enable_tracing: bool = False,
) -> Callable[[F], F]:
    return circuit_breaker(
        name=name,
        fail_max=fail_max,
        reset_timeout=reset_timeout,
        success_threshold=success_threshold,
        exclude=exclude,
        backend=backend,
        redis_client=redis_client,
        enable_logging=enable_logging,
        enable_tracing=enable_tracing,
    )


def circuit_breaker_database(
    name: str,
    *,
    fail_max: int = 3,
    reset_timeout: float = 60,
    success_threshold: int = 1,
    exclude: tuple[ExcludeItem, ...] = (),
    backend: Literal["memory", "redis"] = "memory",
    redis_client: Redis | None = None,
    enable_logging: bool = True,
    enable_tracing: bool = False,
) -> Callable[[F], F]:
    return circuit_breaker(
        name=name,
        fail_max=fail_max,
        reset_timeout=reset_timeout,
        success_threshold=success_threshold,
        exclude=exclude,
        backend=backend,
        redis_client=redis_client,
        enable_logging=enable_logging,
        enable_tracing=enable_tracing,
    )
