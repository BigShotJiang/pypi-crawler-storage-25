from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Self

try:
    import pybreaker
except ImportError:
    raise RuntimeError(
        "Circuit breaker extra is not installed. Run `pip install snakestack[circuit-breaker]`."
    )

if TYPE_CHECKING:
    from pybreaker import CircuitBreaker, CircuitBreakerState

logger = logging.getLogger(__name__)


class SnakeCircuitBreakerListener(pybreaker.CircuitBreakerListener):

    def __init__(self, enable_tracing: bool = False) -> None:
        self._enable_tracing = enable_tracing

    def state_change(
        self: Self,
        cb: CircuitBreaker,
        old_state: CircuitBreakerState | None,
        new_state: CircuitBreakerState,
    ) -> None:
        old_name = old_state.name if old_state else None
        if self._enable_tracing:
            from snakestack.circuit_breaker.tracing import record_state_change_event
            record_state_change_event(cb.name or "", old_name, new_state.name)
        logger.warning(
            "Circuit breaker state changed",
            extra={
                "extra_data": {
                    "circuit_breaker": cb.name,
                    "old_state": old_name,
                    "new_state": new_state.name,
                }
            },
        )

    def failure(
        self: Self,
        cb: CircuitBreaker,
        exc: BaseException,
    ) -> None:
        logger.warning(
            "Circuit breaker recorded failure",
            extra={
                "extra_data": {
                    "circuit_breaker": cb.name,
                    "failure_count": cb.fail_counter,
                    "fail_max": cb.fail_max,
                    "exception_type": type(exc).__name__,
                    "exception": str(exc),
                }
            },
        )

    def success(self: Self, cb: CircuitBreaker) -> None:
        logger.debug(
            "Circuit breaker recorded success",
            extra={
                "extra_data": {
                    "circuit_breaker": cb.name,
                }
            },
        )
