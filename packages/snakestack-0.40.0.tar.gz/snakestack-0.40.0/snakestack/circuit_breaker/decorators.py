from __future__ import annotations

from contextlib import nullcontext
from datetime import datetime, timedelta, timezone
from functools import wraps
from typing import TYPE_CHECKING, Any, Callable, Literal, TypeVar, cast

try:
    import pybreaker
except ImportError:
    raise RuntimeError(
        "Circuit breaker extra is not installed. Run `pip install snakestack[circuit-breaker]`."
    )

from snakestack.circuit_breaker.exceptions import SnakeCircuitOpenError
from snakestack.circuit_breaker.listeners import SnakeCircuitBreakerListener
from snakestack.circuit_breaker.registry import get_or_create
from snakestack.circuit_breaker.storage import build_storage
from snakestack.circuit_breaker.tracing import circuit_breaker_span, record_span_outcome
from snakestack.circuit_breaker.types import ExcludeItem

if TYPE_CHECKING:
    from redis import Redis

F = TypeVar("F", bound=Callable[..., Any])


async def _call_async(
    cb: pybreaker.CircuitBreaker,
    func: Callable[..., Any],
    *args: Any,
    enable_tracing: bool = False,
    **kwargs: Any,
) -> Any:
    cb_name: str = cb.name or ""
    span_ctx = circuit_breaker_span(cb_name, cb.current_state) if enable_tracing else nullcontext(None)
    with span_ctx as span:
        if cb.current_state == pybreaker.STATE_OPEN:
            opened_at = cb._state_storage.opened_at
            if opened_at and datetime.now(timezone.utc) < opened_at + timedelta(seconds=cb.reset_timeout):
                record_span_outcome(span, "blocked")
                raise SnakeCircuitOpenError(cb_name)
            cb.half_open()

        for listener in cb.listeners:
            listener.before_call(cb, func, *args, **kwargs)

        try:
            result = await func(*args, **kwargs)
        except BaseException as exc:
            try:
                cb.state._handle_error(exc, reraise=False)
            except pybreaker.CircuitBreakerError:
                record_span_outcome(span, "tripped", exc)
                raise SnakeCircuitOpenError(cb_name)
            record_span_outcome(span, "failure", exc)
            raise

        record_span_outcome(span, "success")
        cb.state._handle_success()
        return result


def circuit_breaker(
    name: str,
    *,
    fail_max: int = 5,
    reset_timeout: float = 60,
    success_threshold: int = 1,
    exclude: tuple[ExcludeItem, ...] = (),
    backend: Literal["memory", "redis"] = "memory",
    redis_client: Redis | None = None,
    enable_logging: bool = True,
    enable_tracing: bool = False,
) -> Callable[[F], F]:
    def decorator(func: F) -> F:
        resolved_name = name or func.__qualname__

        listeners: list[pybreaker.CircuitBreakerListener] = [SnakeCircuitBreakerListener(enable_tracing=enable_tracing)] if enable_logging else []
        from snakestack.config import (
            get_settings,  # lazy import to avoid circular dependency
        )
        namespace = get_settings().circuit_breaker.namespace
        storage = build_storage(backend=backend, name=resolved_name, redis_client=redis_client, namespace=namespace)
        cb = get_or_create(
            resolved_name,
            fail_max=fail_max,
            reset_timeout=reset_timeout,
            success_threshold=success_threshold,
            exclude=exclude,
            state_storage=storage,
            listeners=listeners,
        )

        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            return await _call_async(cb, func, *args, enable_tracing=enable_tracing, **kwargs)

        return cast(F, wrapper)

    return decorator
