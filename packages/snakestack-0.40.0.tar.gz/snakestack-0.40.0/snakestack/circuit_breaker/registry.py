from __future__ import annotations

from typing import TYPE_CHECKING

try:
    import pybreaker
except ImportError:
    raise RuntimeError(
        "Circuit breaker extra is not installed. Run `pip install snakestack[circuit-breaker]`."
    )

from snakestack.circuit_breaker.types import ExcludeItem

if TYPE_CHECKING:
    from pybreaker import CircuitBreakerListener, CircuitBreakerStorage

_registry: dict[str, pybreaker.CircuitBreaker] = {}


def get_or_create(
    name: str,
    *,
    fail_max: int,
    reset_timeout: float,
    success_threshold: int,
    exclude: tuple[ExcludeItem, ...],
    state_storage: CircuitBreakerStorage,
    listeners: list[CircuitBreakerListener],
) -> pybreaker.CircuitBreaker:
    if name not in _registry:
        _registry[name] = pybreaker.CircuitBreaker(
            name=name,
            fail_max=fail_max,
            reset_timeout=reset_timeout,
            success_threshold=success_threshold,
            exclude=list(exclude),
            state_storage=state_storage,
            listeners=listeners,
        )
    return _registry[name]


def get(name: str) -> pybreaker.CircuitBreaker | None:
    return _registry.get(name)


def reset(name: str) -> None:
    _registry.pop(name, None)


def reset_all() -> None:
    _registry.clear()
