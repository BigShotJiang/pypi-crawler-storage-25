from typing import Callable, Type, Union

ExcludeItem = Union[Type[BaseException], Callable[[BaseException], bool]]
