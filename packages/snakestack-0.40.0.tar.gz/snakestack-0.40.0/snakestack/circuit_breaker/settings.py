from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class CircuitBreakerSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SNAKESTACK_CIRCUIT_BREAKER_")

    namespace: str = Field(
        default="snakestack",
        description=(
            "Namespace prefix used to build Redis keys for circuit breaker state. "
            "Keys follow the pattern '{namespace}:cb:{name}'. "
            "Override to avoid key collisions in a shared Redis instance "
            "(e.g., SNAKESTACK_CIRCUIT_BREAKER_NAMESPACE=myapp)."
        ),
    )

    redis_host: str = Field(
        default="localhost",
        description="Redis hostname for circuit breaker state storage (SNAKESTACK_CIRCUIT_BREAKER_REDIS_HOST).",
    )
    redis_port: int = Field(
        default=6379,
        description="Redis port for circuit breaker state storage (SNAKESTACK_CIRCUIT_BREAKER_REDIS_PORT).",
    )
    redis_db: int = Field(
        default=0,
        description="Redis database index for circuit breaker state storage (SNAKESTACK_CIRCUIT_BREAKER_REDIS_DB).",
    )
    redis_username: str | None = Field(
        default=None,
        description="Redis ACL username for circuit breaker state storage (SNAKESTACK_CIRCUIT_BREAKER_REDIS_USERNAME).",
    )
    redis_password: str | None = Field(
        default=None,
        description="Redis password for circuit breaker state storage (SNAKESTACK_CIRCUIT_BREAKER_REDIS_PASSWORD).",
    )
