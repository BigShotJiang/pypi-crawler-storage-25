from __future__ import annotations

from typing import TYPE_CHECKING, Literal

try:
    import pybreaker
except ImportError:
    raise RuntimeError(
        "Circuit breaker extra is not installed. Run `pip install snakestack[circuit-breaker]`."
    )

if TYPE_CHECKING:
    from redis import Redis


def build_storage(
    backend: Literal["memory", "redis"],
    name: str,
    redis_client: Redis | None = None,
    namespace: str = "snakestack",
) -> pybreaker.CircuitBreakerStorage:
    if backend == "redis":
        if redis_client is None:
            raise ValueError(
                "A synchronous redis.Redis client must be provided when using the 'redis' backend."
            )
        return pybreaker.CircuitRedisStorage(
            state=pybreaker.STATE_CLOSED,
            redis_object=redis_client,
            namespace=f"{namespace}:cb:{name}",
            fallback_circuit_state=pybreaker.STATE_CLOSED,
        )

    return pybreaker.CircuitMemoryStorage(pybreaker.STATE_CLOSED)
