from __future__ import annotations

_import_error: RuntimeError | None = None

try:
    from snakestack.circuit_breaker.decorators import circuit_breaker
    from snakestack.circuit_breaker.exceptions import (
        SnakeCircuitBreakerError,
        SnakeCircuitOpenError,
    )
    from snakestack.circuit_breaker.presets import (
        circuit_breaker_database,
        circuit_breaker_http,
    )
    from snakestack.circuit_breaker.registry import get, get_or_create, reset, reset_all
    from snakestack.circuit_breaker.types import ExcludeItem
except RuntimeError as e:
    _import_error = e


def __getattr__(name: str) -> object:
    if _import_error is not None:
        raise _import_error
    raise AttributeError(f"module 'snakestack.circuit_breaker' has no attribute {name!r}")  # pragma: no cover


__all__ = [
    "circuit_breaker",
    "circuit_breaker_http",
    "circuit_breaker_database",
    "SnakeCircuitBreakerError",
    "SnakeCircuitOpenError",
    "ExcludeItem",
    "get",
    "get_or_create",
    "reset",
    "reset_all",
]
