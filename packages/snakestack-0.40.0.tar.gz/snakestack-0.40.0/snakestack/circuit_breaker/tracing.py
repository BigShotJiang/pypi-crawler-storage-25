from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Generator


@contextmanager
def circuit_breaker_span(name: str, state: str) -> Generator[Any, None, None]:
    try:
        from opentelemetry import trace
        from opentelemetry.trace import SpanKind
    except ImportError:
        raise RuntimeError(
            "Telemetry extra is not installed. Run `pip install snakestack[telemetry]`."
        )

    tracer = trace.get_tracer("snakestack.circuit_breaker")
    with tracer.start_as_current_span("circuit_breaker.call", kind=SpanKind.INTERNAL) as span:
        span.set_attributes({
            "circuit_breaker.name": name,
            "circuit_breaker.state": state,
        })
        yield span


def record_span_outcome(
    span: Any | None,
    outcome: str,
    exc: BaseException | None = None,
) -> None:
    if span is None:
        return
    try:
        from opentelemetry.trace import Status, StatusCode
    except ImportError:
        return

    span.set_attribute("circuit_breaker.outcome", outcome)
    if outcome == "success":
        span.set_status(Status(StatusCode.OK))
    else:
        if exc is not None:
            span.record_exception(exc)
        span.set_status(Status(StatusCode.ERROR, outcome))


def record_state_change_event(
    cb_name: str,
    old_state_name: str | None,
    new_state_name: str,
) -> None:
    try:
        from opentelemetry import trace
    except ImportError:
        return

    span = trace.get_current_span()
    if span and span.is_recording():
        span.add_event(
            "circuit_breaker.state_changed",
            attributes={
                "circuit_breaker.name": cb_name,
                "circuit_breaker.old_state": old_state_name or "none",
                "circuit_breaker.new_state": new_state_name,
            },
        )
