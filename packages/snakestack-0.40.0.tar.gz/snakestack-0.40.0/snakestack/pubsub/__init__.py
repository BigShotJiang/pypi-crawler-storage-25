from __future__ import annotations

_import_error: RuntimeError | None = None

try:
    from snakestack.pubsub.exceptions import (
        SnakePubSubError,
    )
    from snakestack.pubsub.publisher.client import SnakePublisher
    from snakestack.pubsub.publisher.exceptions import (
        SnakeInvalidAttributesError,
        SnakePublishError,
    )
    from snakestack.pubsub.publisher.factory import SnakePubSubPublisherFactory
    from snakestack.pubsub.settings import PubSubSettings
    from snakestack.pubsub.subscriber.client import SnakeSubscriber
    from snakestack.pubsub.subscriber.exceptions import (
        SnakeAckableError,
        SnakeBaseMessageError,
        SnakeBlockRuleError,
        SnakeRetryableError,
    )
    from snakestack.pubsub.subscriber.factory import SnakePubSubFlowControlFactory
    from snakestack.pubsub.subscriber.models import SnakeBatchSettingsModel
    from snakestack.pubsub.subscriber.processors import (
        BatchProtocol,
        SimpleProtocol,
        SnakeBatchProcessor,
        SnakeSimpleProcessor,
    )
    from snakestack.pubsub.subscriber.utils import setup_signal_handlers
except RuntimeError as e:
    _import_error = e


def __getattr__(name: str) -> object:
    if _import_error is not None:
        raise _import_error
    raise AttributeError(f"module 'snakestack.pubsub' has no attribute {name!r}")  # pragma: no cover

__all__ = [
    "SnakePublisher",
    "SnakePubSubPublisherFactory",
    "SnakeSubscriber",
    "SnakePubSubFlowControlFactory",
    "SnakeSimpleProcessor",
    "SnakeBatchProcessor",
    "SimpleProtocol",
    "BatchProtocol",
    "SnakeBatchSettingsModel",
    "PubSubSettings",
    "SnakePubSubError",
    "SnakePublishError",
    "SnakeInvalidAttributesError",
    "SnakeAckableError",
    "SnakeRetryableError",
    "SnakeBlockRuleError",
    "SnakeBaseMessageError",
    "setup_signal_handlers",
]
