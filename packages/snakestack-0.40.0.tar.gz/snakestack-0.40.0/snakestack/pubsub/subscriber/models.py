try:
    from google.cloud.pubsub_v1 import SubscriberClient
except ImportError:
    raise RuntimeError("Pubsub extra is not installed. Run `pip install snakestack[pubsub]`.")

from snakestack.model.lenient import SnakeLenientModel


class SnakeBatchSettingsModel(SnakeLenientModel):
    size: int
    timeout: float
    name: str
    subscriber_client: SubscriberClient | None = None
    subscription_path: str | None = None
