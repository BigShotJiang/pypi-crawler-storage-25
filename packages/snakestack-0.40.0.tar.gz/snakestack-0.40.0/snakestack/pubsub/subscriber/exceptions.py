from snakestack.pubsub.exceptions import SnakePubSubError


class SnakeBaseMessageError(SnakePubSubError):
    def __init__(self, message: str = "", *, message_id: str | None = None) -> None:
        super().__init__(message)
        self.message_id = message_id


class SnakeAckableError(SnakeBaseMessageError): ...


class SnakeRetryableError(SnakeBaseMessageError): ...


class SnakeBlockRuleError(SnakeRetryableError): ...
