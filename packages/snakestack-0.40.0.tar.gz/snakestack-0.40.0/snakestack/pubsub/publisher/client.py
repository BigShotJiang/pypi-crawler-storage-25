import logging
from concurrent.futures import Future
from typing import Callable, Self

try:
    from google.cloud.pubsub_v1 import PublisherClient
except ImportError:
    raise RuntimeError("Pubsub extra is not installed. Run `pip install snakestack[pubsub]`.")

from snakestack.pubsub.publisher.exceptions import (
    SnakeInvalidAttributesError,
    SnakePublishError,
)
from snakestack.pubsub.settings import PubSubSettings

logger = logging.getLogger(__name__)


class SnakePublisher:

    def __init__(self: Self, client: "PublisherClient", timeout: int | None = None) -> None:
        self.client = client
        self.timeout = timeout if timeout is not None else PubSubSettings().publisher_timeout

    def publish(
        self: Self,
        project_id: str,
        topic_name: str,
        data: bytes,
        attributes: dict[str, str | bytes] | None = None,
        callback: Callable[[Future[None]], None] | None = None,
        timeout: int | None = None
    ) -> None:
        topic_path = self.client.topic_path(project=project_id, topic=topic_name)
        attributes = attributes or {}

        for k, v in attributes.items():
            if not isinstance(v, (str, bytes)):
                raise SnakeInvalidAttributesError(key=k, value=v)

        future = self.client.publish(data=data, topic=topic_path, **attributes)

        if callback:
            future.add_done_callback(callback)
            logger.debug(f"Callback added to future for topic {topic_path}")
        else:
            effective_timeout = timeout if timeout is not None else self.timeout
            try:
                future.result(timeout=effective_timeout)
            except Exception as e:
                logger.exception("Error while publishing message.", exc_info=e)
                raise SnakePublishError(topic=topic_path, original_exception=e)
            else:
                logger.debug(f"Successfully sent on topic {topic_path}")
