from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class PubSubSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SNAKESTACK_PUBSUB_")
    project_id: str = Field(
        default="snakestack-project",
        description="Google Cloud project ID used for Pub/Sub operations."
    )
    subscription_name: str | None = Field(
        default=None,
        description="Default Pub/Sub subscription name used by the subscriber client."
    )
    topic_name: str | None = Field(
        default=None,
        description="Default Pub/Sub topic name used by the publisher client."
    )
    publisher_timeout: int = Field(
        default=5,
        description="Timeout in seconds for synchronous publish calls (future.result). Only used when no callback is provided."
    )
