from typing import Any, Self

import httpx

from snakestack.http_client.model import SnakeHttpErrorDetail


class SnakeHttpError(Exception):
    ...


class SnakeHttpRequestError(SnakeHttpError):
    def __init__(self: Self, api: str, original_exception: Exception) -> None:
        super().__init__(f"Failed to request to api '{api}': {original_exception}")
        self.api = api
        self.original_exception = original_exception

    def get_details(self) -> SnakeHttpErrorDetail:
        error = self.original_exception

        details_map: dict[str, Any] = {
            "message": str(error),
            "is_timeout": isinstance(error, httpx.TimeoutException),
            "is_network_error": isinstance(error, httpx.NetworkError) and not isinstance(error, httpx.TimeoutException),
        }

        if isinstance(error, httpx.HTTPStatusError):
            details_map["status_code"] = error.response.status_code
            details_map["headers"] = dict(error.response.headers)
            try:
                details_map["body"] = error.response.json()
            except Exception:
                details_map["body"] = error.response.text

        return SnakeHttpErrorDetail(**details_map)
