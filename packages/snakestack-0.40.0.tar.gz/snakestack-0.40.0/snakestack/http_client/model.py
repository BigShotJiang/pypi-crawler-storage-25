from typing import Any

import httpx
from pydantic import Field

from snakestack.model.lenient import SnakeLenientModel


class SnakeHttpErrorDetail(SnakeLenientModel):
    status_code: int | None = Field(
        default=None,
        description="HTTP status code returned by the server, if available.",
    )
    headers: dict[str, str] | None = Field(
        default=None,
        description="Response headers returned by the server, if available.",
    )
    body: Any | None = Field(
        default=None,
        description="Response body returned by the server, if available.",
    )
    is_timeout: bool = Field(
        default=False,
        description="True if the request failed due to a timeout.",
    )
    is_network_error: bool = Field(
        default=False,
        description="True if the request failed due to a network error (excluding timeouts).",
    )
    message: str = Field(
        default="",
        description="Human-readable error message describing the failure.",
    )


class SnakeHttpResponse(SnakeLenientModel):
    status_code: int = Field(
        ...,
        description="HTTP status code returned by the server.",
    )
    data: Any | None = Field(
        default=None,
        description="Parsed response body. Contains a dict for JSON responses, or a string for text/HTML.",
    )
    headers: dict[str, str] = Field(
        ...,
        description="Response headers returned by the server.",
    )
    raw: httpx.Response = Field(
        ...,
        description="Original httpx.Response object for low-level access.",
    )

    @property
    def is_success(self) -> bool:
        return 200 <= self.status_code <= 299
