import inspect
import logging
from functools import wraps
from typing import Any, Callable, TypeVar, cast

try:
    from pymongo.errors import DuplicateKeyError, PyMongoError
except ImportError:
    raise RuntimeError("Mongodb extra is not installed. Run `pip install snakestack[mongodb]`.")

from snakestack.mongodb.exceptions import SnakeMongoDbError

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


def _handle_duplicate_key(error: DuplicateKeyError, duplicate_key_exception: type[Exception] | None) -> None:
    logger.exception("Mongodb duplicate key error.")
    if duplicate_key_exception is not None:
        raise duplicate_key_exception from error
    raise SnakeMongoDbError(error)


def handle_mongodb_error(
    duplicate_key_exception: type[Exception] | None = None,
) -> Callable[[F], F]:
    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return func(*args, **kwargs)
            except DuplicateKeyError as error:
                _handle_duplicate_key(error, duplicate_key_exception)
            except PyMongoError as error:
                logger.exception("Mongodb operation failed.")
                raise SnakeMongoDbError(error)

        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return await func(*args, **kwargs)
            except DuplicateKeyError as error:
                _handle_duplicate_key(error, duplicate_key_exception)
            except PyMongoError as error:
                logger.exception("Mongodb operation failed.")
                raise SnakeMongoDbError(error)

        if inspect.iscoroutinefunction(func):
            return cast(F, async_wrapper)
        return cast(F, wrapper)

    return decorator
