from typing import Any, Self

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class MongoDbSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SNAKESTACK_MONGODB_")

    uri: str | None = Field(
        default=None,
        description=(
            "Full MongoDB connection URI. When set, all granular connection fields "
            "(host, port, user, password, auth_source) are ignored. "
            "The dbname field is still used to select the database. "
            "Example: mongodb+srv://user:pass@cluster.mongodb.net/?retryWrites=true"
        ),
    )

    host: str = Field(
        default="localhost",
        description="MongoDB server hostname or IP address. Used only when 'uri' is not set.",
    )
    port: int = Field(
        default=27017,
        description="MongoDB server port. Used only when 'uri' is not set.",
    )
    user: str | None = Field(
        default=None,
        description=(
            "MongoDB authentication username. "
            "Must be set together with 'password'. Used only when 'uri' is not set."
        ),
    )
    password: str | None = Field(
        default=None,
        description=(
            "MongoDB authentication password. "
            "Must be set together with 'user'. Used only when 'uri' is not set."
        ),
    )
    auth_source: str = Field(
        default="admin",
        description=(
            "Database used for authentication. Defaults to 'admin', "
            "which is standard for most self-hosted deployments. "
            "Used only when 'uri' is not set."
        ),
    )

    dbname: str = Field(
        default="snakestack",
        description="Name of the MongoDB database to connect to. Used in both URI and granular modes.",
    )

    @model_validator(mode="after")
    def validate_partial_credentials(self: Self) -> Self:
        if bool(self.user) != bool(self.password):
            raise ValueError("'user' and 'password' must both be set or both be omitted.")
        return self

    def get_connection_uri(self: Self) -> str:
        if self.uri:
            return self.uri
        return f"mongodb://{self.host}:{self.port}"

    def get_kwargs(self: Self) -> dict[str, Any]:
        if self.uri:
            return {}
        config = {}
        if self.user and self.password:
            config["username"] = self.user
            config["password"] = self.password
            config["authSource"] = self.auth_source
        return config
