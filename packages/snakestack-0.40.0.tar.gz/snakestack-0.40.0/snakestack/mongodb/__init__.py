from __future__ import annotations

_import_error: RuntimeError | None = None

try:
    from snakestack.mongodb.asyncio.client import (
        close_mongodb_connection as async_close_mongodb_connection,
    )
    from snakestack.mongodb.asyncio.client import (
        get_collection as async_get_collection,
    )
    from snakestack.mongodb.asyncio.client import (
        get_database as async_get_database,
    )
    from snakestack.mongodb.asyncio.client import (
        open_mongodb_connection as async_open_mongodb_connection,
    )
    from snakestack.mongodb.asyncio.client import (
        ping as async_ping,
    )
    from snakestack.mongodb.base import (
        AsyncCollection,
        AsyncDatabase,
        SnakeBaseMongoDbAsyncClient,
        SnakeBaseMongoDbClient,
    )
    from snakestack.mongodb.exceptions import SnakeMongoDbError
    from snakestack.mongodb.models import SnakeMongoDbModel
    from snakestack.mongodb.settings import MongoDbSettings
    from snakestack.mongodb.sync.client import (
        close_mongodb_connection,
        get_collection,
        get_database,
        open_mongodb_connection,
        ping,
    )
    from snakestack.mongodb.utils import get_mongo_db_projection
except RuntimeError as e:
    _import_error = e


def __getattr__(name: str) -> object:
    if _import_error is not None:
        raise _import_error
    raise AttributeError(f"module 'snakestack.mongodb' has no attribute {name!r}")  # pragma: no cover


__all__ = [
    "async_open_mongodb_connection",
    "async_close_mongodb_connection",
    "async_get_database",
    "async_get_collection",
    "async_ping",
    "AsyncCollection",
    "AsyncDatabase",
    "close_mongodb_connection",
    "get_collection",
    "get_database",
    "get_mongo_db_projection",
    "open_mongodb_connection",
    "MongoDbSettings",
    "ping",
    "SnakeBaseMongoDbAsyncClient",
    "SnakeBaseMongoDbClient",
    "SnakeMongoDbModel",
    "SnakeMongoDbError",
]
