from typing import Self


class SnakeMongoDbError(Exception):
    def __init__(self: Self, original_exception: Exception) -> None:
        self.original_exception = original_exception
