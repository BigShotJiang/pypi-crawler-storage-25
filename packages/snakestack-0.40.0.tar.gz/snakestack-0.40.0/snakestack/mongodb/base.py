from __future__ import annotations

from typing import Any

try:
    from pymongo.asynchronous.collection import AsyncCollection as AsyncCollection
    from pymongo.asynchronous.database import AsyncDatabase as AsyncDatabase
    from pymongo.collection import Collection
    from pymongo.database import Database
except ImportError:
    raise RuntimeError("Mongodb extra is not installed. Run `pip install snakestack[mongodb]`.")


class SnakeBaseMongoDbAsyncClient:
    def __init__(self, db: AsyncDatabase[Any]) -> None:
        self._db = db

    def get_collection(self, name: str) -> AsyncCollection[Any]:
        return self._db[name]


class SnakeBaseMongoDbClient:
    def __init__(self, db: Database[Any]) -> None:
        self._db = db

    def get_collection(self, name: str) -> Collection[Any]:
        return self._db[name]
