from pydantic import BaseModel


def get_mongo_db_projection(model: type[BaseModel], show_id: bool = False) -> dict[str, int]:
    projection = {}
    for field_name, field_info in model.model_fields.items():
        key = field_info.alias or field_name
        if key == "_id":
            continue
        projection[key] = 1
    return {"_id": 1 if show_id else 0, **projection}
