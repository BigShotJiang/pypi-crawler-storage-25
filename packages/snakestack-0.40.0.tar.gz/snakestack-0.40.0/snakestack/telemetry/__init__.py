from __future__ import annotations

_import_error: RuntimeError | None = None

try:
    from snakestack.telemetry.helpers import (
        get_current_span,
        get_tracer,
        instrumented_span,
        set_span_attributes,
    )
    from snakestack.telemetry.instrumentor import instrument_app
except RuntimeError as e:
    _import_error = e


def __getattr__(name: str) -> object:
    if _import_error is not None:
        raise _import_error
    raise AttributeError(f"module 'snakestack.telemetry' has no attribute {name!r}")  # pragma: no cover


__all__ = [
    "get_current_span",
    "get_tracer",
    "instrumented_span",
    "set_span_attributes",
    "instrument_app",
]
