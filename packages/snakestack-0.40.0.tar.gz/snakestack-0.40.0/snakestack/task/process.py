import asyncio
import logging
from typing import Any, Awaitable, Callable, Self

logger = logging.getLogger(__name__)


class SnakeTaskProcess:
    def __init__(
        self: Self,
        queue_max_size: int = 100,
        func_callback: Callable[..., Awaitable[Any]] | None = None,
        sentinel: Any = None,
        concurrency: int | None = 5,
        num_workers: int = 2
    ) -> None:
        self.queue = asyncio.Queue[Any](maxsize=queue_max_size)
        self.sentinel = sentinel
        self.func_callback = func_callback
        self.semaphore = asyncio.BoundedSemaphore(concurrency) if concurrency else None
        self.num_workers = num_workers

    async def enqueue(self: Self, message: Any) -> None:
        logger.debug("Queue size: %s", self.queue.qsize())
        await self.queue.put(message)

    async def wait(self: Self) -> None:
        await self.queue.join()

    async def worker(
        self: Self,
        num: int
    ) -> None:
        logger.info("Starting worker [%s]", num)
        try:
            while True:
                logger.debug("Worker [%s] waiting messages...", num)
                message = await self.queue.get()

                if message is self.sentinel:
                    self.queue.task_done()
                    logger.debug("Worker [%s] finished after sentinel", num)
                    break

                try:
                    logger.debug("Worker [%s] pulled message", num)
                    cb = self.func_callback or self.callback

                    if self.semaphore:
                        async with self.semaphore:
                            await cb(num=num, message=message)
                    else:
                        await cb(num=num, message=message)
                except Exception:
                    logger.exception("Error on process")
                finally:
                    self.queue.task_done()

        except asyncio.CancelledError:
            logger.debug("Worker [%s] cancelled while waiting; exiting.", num)
            raise

    async def callback(
        self: Self,
        num: int,
        message: Any
    ) -> None:
        await asyncio.sleep(0.1)
        logger.debug("Worker [%s] process item %s", num, message)

    async def stop(
        self: Self,
        num_workers: int | None = None,
    ) -> None:
        n = num_workers if num_workers is not None else self.num_workers
        logger.debug("Publishing %s sentinels", n)
        for _ in range(n):
            await self.enqueue(message=self.sentinel)
