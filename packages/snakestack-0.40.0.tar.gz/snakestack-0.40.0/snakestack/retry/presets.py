from __future__ import annotations

from collections.abc import Callable
from typing import Any, TypeVar

try:
    from tenacity import (
        retry,
        retry_if_exception,
        stop_after_attempt,
        stop_after_delay,
        wait_random_exponential,
    )
except ImportError:
    raise RuntimeError("Retry extra is not installed. Run `pip install snakestack[retry]`.")

from snakestack.retry.callbacks import callback_before_sleep, callback_retry_exhausted
from snakestack.retry.helpers import is_retryable_http_exception

F = TypeVar("F", bound=Callable[..., Any])


def retry_external_api(
    *,
    operation_name: str | None = None,
    attempts: int = 5,
    max_delay_seconds: float = 30,
    max_total_seconds: float = 120,
    enable_logging: bool = True,
    enable_tracing: bool = False,
) -> Callable[[F], F]:
    def decorator(func: F) -> F:
        resolved_operation_name = operation_name or func.__qualname__

        return retry(
            retry=retry_if_exception(is_retryable_http_exception),
            wait=wait_random_exponential(multiplier=1, max=max_delay_seconds),
            stop=stop_after_attempt(attempts) | stop_after_delay(max_total_seconds),
            before_sleep=callback_before_sleep(
              operation_name=resolved_operation_name,
              enable_logging=enable_logging,
              enable_tracing=enable_tracing,
            ),
            retry_error_callback=callback_retry_exhausted(
                operation_name=resolved_operation_name,
                enable_logging=enable_logging,
                enable_tracing=enable_tracing,
            ),
        )(func)

    return decorator
