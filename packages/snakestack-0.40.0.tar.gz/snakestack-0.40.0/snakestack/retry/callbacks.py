import logging
from collections.abc import Callable

try:
    from tenacity import RetryCallState
except ImportError:
    raise RuntimeError("Retry extra is not installed. Run `pip install snakestack[retry]`.")

logger = logging.getLogger(__name__)


def callback_before_sleep(
    operation_name: str,
    enable_logging: bool,
    enable_tracing: bool,
) -> Callable[[RetryCallState], None]:
    def _callback(retry_state: RetryCallState) -> None:
        exc = retry_state.outcome.exception() if retry_state.outcome else None
        sleep_seconds = retry_state.next_action.sleep if retry_state.next_action else 0
        exception_type = type(exc).__name__ if exc else None
        if enable_logging:
            logger.warning(
                f"Retrying external API {operation_name}",
                extra={
                    "extra_data": {
                        "operation_name": operation_name,
                        "attempt_number": retry_state.attempt_number,
                        "sleep_seconds": sleep_seconds,
                        "exception_type": exception_type,
                        "exception_name": str(exc) if exc else None,
                    }
                }
            )

        if enable_tracing:
            from snakestack.telemetry.helpers import get_current_span
            span = get_current_span()
            if span and span.is_recording():
                span.add_event(
                    "retry.scheduled",
                    attributes={
                        "retry.operation_name": operation_name,
                        "retry.attempt_number": retry_state.attempt_number,
                        "retry.sleep_seconds": sleep_seconds,
                        "retry.exception_type": exception_type or "null",
                    }
                )

    return _callback


def callback_retry_exhausted(
    operation_name: str,
    enable_logging: bool,
    enable_tracing: bool,
) -> Callable[[RetryCallState], None]:
    def _callback(retry_state: RetryCallState) -> None:
        exc = retry_state.outcome.exception() if retry_state.outcome else None
        exception_type = type(exc).__name__ if exc else None
        exception_name = str(exc) if exc else None

        if enable_logging:
            logger.error(
                f"Retry exhausted for external API {operation_name}",
                extra={
                    "extra_data": {
                        "operation_name": operation_name,
                        "attempts": retry_state.attempt_number,
                        "exception_type": exception_type,
                        "exception_name": exception_name,
                    }
                }
            )

        if enable_tracing:
            from snakestack.telemetry.helpers import get_current_span
            span = get_current_span()
            if span and span.is_recording():
                span.add_event(
                    "retry.exhausted",
                    attributes={
                        "retry.operation_name": operation_name,
                        "retry.attempt_number": retry_state.attempt_number,
                        "retry.exception_type": exception_type or "null",
                        "retry.exception_name": exception_name or "null",
                    }
                )

        raise exc or RuntimeError(f"Retry exhausted for {operation_name} without an exception.")

    return _callback
