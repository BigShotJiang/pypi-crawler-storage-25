from __future__ import annotations

_import_error: RuntimeError | None = None

try:
    from snakestack.retry.presets import (
        retry_external_api,
    )
except RuntimeError as e:
    _import_error = e


def __getattr__(name: str) -> object:
    if _import_error is not None:
        raise _import_error
    raise AttributeError(f"module 'snakestack.retry' has no attribute {name!r}")  # pragma: no cover


__all__ = [
    "retry_external_api",
]
