import httpx

from snakestack.http_client.exceptions import SnakeHttpRequestError


def is_retryable_http_exception(exc: BaseException) -> bool:
    if isinstance(exc, SnakeHttpRequestError):
        exc = exc.original_exception

    if isinstance(exc, httpx.TimeoutException):
        return True

    if isinstance(exc, httpx.NetworkError):
        return True

    if isinstance(exc, httpx.HTTPStatusError):
        from snakestack.config import (
            get_settings,  # lazy import: avoids circular at load time
        )
        return exc.response.status_code in get_settings().retry.http_status_code

    return False
