from typing import Any

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from snakestack.constants import DEFAULT_RETRY_HTTP_STATUS_CODE


class RetrySettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SNAKESTACK_RETRY_")

    http_status_code: list[int] = Field(
        default=DEFAULT_RETRY_HTTP_STATUS_CODE,
        description=(
            "List of HTTP status codes that should trigger a retry attempt. "
            "When set via environment variable, provide a comma-separated string "
            "(e.g., SNAKESTACK_RETRY_HTTP_STATUS_CODE=429,500,502,503,504)."
        )
    )

    @field_validator("http_status_code", mode="before")
    def http_status_code_validator(cls, v: Any) -> list[int]:
        if not isinstance(v, str):
            return DEFAULT_RETRY_HTTP_STATUS_CODE

        return [int(p.strip()) for p in v.split(",") if p.strip().isdigit()]
