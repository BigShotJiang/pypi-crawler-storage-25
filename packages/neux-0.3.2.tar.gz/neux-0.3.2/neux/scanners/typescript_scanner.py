"""JavaScript / TypeScript / JSX / TSX scanner using tree-sitter.

Uses ``tree-sitter-language-pack`` (active fork of ``tree-sitter-languages``).
Handles `.js`, `.jsx`, `.ts`, `.tsx`. Extracts:

* function / arrow / method declarations → ``function``/``method``
* class declarations → ``class``
* React components (functions that return JSX) → ``component``
* import statements → ``imports`` edges
* call expressions → ``calls`` edges
* JSX element usages → ``renders`` edges
* ``useState|useEffect|useRef|useMemo|useCallback|use[A-Z]\\w+`` identifiers → ``hook``
* ``interface``/``type``/``enum`` declarations
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from neux.engine import compute_file_hash, make_node_id
from neux.scanners.base import BaseScanner, EdgeData, NodeData, ScanResult

HOOK_RE = re.compile(r"^use[A-Z]\w*$")

# Per-extension tree-sitter language name
_EXT_TO_LANG: dict[str, str] = {
    ".js": "javascript",
    ".jsx": "tsx",
    ".ts": "typescript",
    ".tsx": "tsx",
}


class TypeScriptScanner(BaseScanner):
    name = "typescript"
    language = "typescript"
    extensions = [".js", ".jsx", ".ts", ".tsx"]

    def __init__(self) -> None:
        self._parsers: dict[str, Any] = {}

    def _get_parser(self, ext: str) -> Any:
        lang_name = _EXT_TO_LANG.get(ext, "tsx")
        cached = self._parsers.get(lang_name)
        if cached is not None:
            return cached
        from tree_sitter_language_pack import get_parser
        parser = get_parser(lang_name)
        self._parsers[lang_name] = parser
        return parser

    def scan_file(self, file_path: Path, content: str) -> ScanResult:
        result = ScanResult()
        ext = file_path.suffix.lower()
        parser = self._get_parser(ext)
        src_bytes = content.encode("utf-8", errors="replace")
        tree = parser.parse(src_bytes)
        root = tree.root_node

        rel_path = str(file_path)
        file_hash = compute_file_hash(content)
        file_node_id = make_node_id(rel_path, "file", file_path.stem)

        lang_label = "typescript" if ext in {".ts", ".tsx"} else "javascript"
        is_test = any(p in file_path.name for p in (".test.", ".spec."))

        result.nodes.append(
            NodeData(
                id=file_node_id,
                kind="test" if is_test else "file",
                name=file_path.name,
                file_path=rel_path,
                line_start=1,
                line_end=len(content.splitlines()) or 1,
                language=lang_label,
                file_hash=file_hash,
            )
        )

        walker = _TSWalker(
            file_path=rel_path,
            file_node_id=file_node_id,
            file_hash=file_hash,
            language=lang_label,
            source=src_bytes,
            result=result,
            is_test=is_test,
        )
        walker.walk(root)
        return result


class _TSWalker:
    def __init__(
        self,
        file_path: str,
        file_node_id: str,
        file_hash: str,
        language: str,
        source: bytes,
        result: ScanResult,
        is_test: bool,
    ):
        self.file_path = file_path
        self.file_node_id = file_node_id
        self.file_hash = file_hash
        self.language = language
        self.source = source
        self.result = result
        self.is_test = is_test
        self.scope_stack: list[str] = [file_node_id]
        self.in_class: bool = False

    # ------------------------------------------------------------------

    def _text(self, node: Any) -> str:
        return self.source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")

    def _field(self, node: Any, name: str) -> Any:
        return node.child_by_field_name(name)

    def walk(self, root: Any) -> None:
        # Depth-first but handled at node-type granularity.
        self._visit(root)

    def _visit(self, node: Any) -> None:
        t = node.type
        handler = _HANDLERS.get(t)
        if handler is not None:
            consumed = handler(self, node)
            if consumed:
                return
        for child in node.children:
            self._visit(child)

    # ------------------------------------------------------------------
    # Handlers — return True if the node is fully consumed (don't descend)
    # ------------------------------------------------------------------

    def handle_import(self, node: Any) -> bool:
        # import_statement: grab the string literal source
        source_node = None
        for child in node.children:
            if child.type == "string":
                source_node = child
                break
        if source_node is None:
            return True
        raw = self._text(source_node).strip("'\"`")
        target_id = make_node_id(raw, "module_node", raw.rsplit("/", 1)[-1])
        self.result.edges.append(
            EdgeData(
                source_id=self.file_node_id,
                target_id=target_id,
                relation="imports",
                metadata={"module": raw},
            )
        )
        self.result.unresolved.append(target_id)
        return True

    def handle_class(self, node: Any) -> bool:
        name_node = self._field(node, "name")
        if name_node is None:
            return False
        name = self._text(name_node)
        cls_id = self._qualname(name, "class")
        heritage_node = self._field(node, "heritage") or node.child_by_field_name("superclass")
        self.result.nodes.append(
            NodeData(
                id=cls_id,
                kind="class",
                name=name,
                file_path=self.file_path,
                line_start=node.start_point[0] + 1,
                line_end=node.end_point[0] + 1,
                language=self.language,
                signature=f"class {name}",
                file_hash=self.file_hash,
                metadata={"heritage": self._text(heritage_node) if heritage_node else None},
            )
        )
        # Walk body with class context
        prev = self.in_class
        self.in_class = True
        self.scope_stack.append(cls_id)
        for child in node.children:
            self._visit(child)
        self.scope_stack.pop()
        self.in_class = prev
        return True

    def handle_function_decl(self, node: Any) -> bool:
        name_node = self._field(node, "name")
        if name_node is None:
            return False
        name = self._text(name_node)
        is_component = _name_is_component(name) and _body_returns_jsx(self._field(node, "body"))
        kind = "component" if is_component else "function"
        fn_id = self._qualname(name, kind)
        self._emit_function_node(fn_id, name, kind, node)
        self._walk_function_body(fn_id, self._field(node, "body"))
        return True

    def handle_method(self, node: Any) -> bool:
        name_node = self._field(node, "name")
        if name_node is None:
            return False
        name = self._text(name_node)
        fn_id = self._qualname(name, "method")
        self._emit_function_node(fn_id, name, "method", node)
        if self.scope_stack and self.scope_stack[-1] != self.file_node_id:
            self.result.edges.append(
                EdgeData(source_id=fn_id, target_id=self.scope_stack[-1], relation="wraps")
            )
        self._walk_function_body(fn_id, self._field(node, "body"))
        return True

    def handle_variable_declarator(self, node: Any) -> bool:
        """Catch ``const Foo = () => { ... }`` — potential component/function."""
        name_node = self._field(node, "name")
        value_node = self._field(node, "value")
        if name_node is None or value_node is None:
            return False
        if value_node.type not in {"arrow_function", "function_expression"}:
            return False
        name = self._text(name_node)
        # Only care if it's actually an identifier
        if name_node.type != "identifier":
            return False
        is_component = _name_is_component(name) and _body_returns_jsx(self._field(value_node, "body"))
        kind = "component" if is_component else "function"
        fn_id = self._qualname(name, kind)
        self._emit_function_node(fn_id, name, kind, value_node)
        self._walk_function_body(fn_id, self._field(value_node, "body"))
        return True

    def handle_interface(self, node: Any) -> bool:
        return self._emit_type_decl(node, "interface")

    def handle_type_alias(self, node: Any) -> bool:
        return self._emit_type_decl(node, "type")

    def handle_enum(self, node: Any) -> bool:
        return self._emit_type_decl(node, "enum")

    def _emit_type_decl(self, node: Any, kind: str) -> bool:
        name_node = self._field(node, "name")
        if name_node is None:
            return False
        name = self._text(name_node)
        node_id = self._qualname(name, kind)
        self.result.nodes.append(
            NodeData(
                id=node_id,
                kind=kind,
                name=name,
                file_path=self.file_path,
                line_start=node.start_point[0] + 1,
                line_end=node.end_point[0] + 1,
                language=self.language,
                file_hash=self.file_hash,
            )
        )
        return True

    # ------------------------------------------------------------------

    def _emit_function_node(self, fn_id: str, name: str, kind: str, node: Any) -> None:
        params_node = self._field(node, "parameters")
        return_node = self._field(node, "return_type")
        params = self._text(params_node) if params_node else "()"
        returns = self._text(return_node) if return_node else ""
        sig = f"{kind} {name}{params}{returns}"
        if self.is_test and name.startswith(("test", "it", "describe")):
            kind = "test"
        self.result.nodes.append(
            NodeData(
                id=fn_id,
                kind=kind,
                name=name,
                file_path=self.file_path,
                line_start=node.start_point[0] + 1,
                line_end=node.end_point[0] + 1,
                language=self.language,
                signature=sig,
                file_hash=self.file_hash,
            )
        )

    def _walk_function_body(self, fn_id: str, body: Any) -> None:
        if body is None:
            return
        prev_scope = self.scope_stack[-1]
        self.scope_stack.append(fn_id)
        try:
            for descendant in _iter_descendants(body):
                t = descendant.type
                if t == "call_expression":
                    self._handle_call(fn_id, descendant)
                elif t in {"jsx_opening_element", "jsx_self_closing_element"}:
                    self._handle_jsx(fn_id, descendant)
        finally:
            self.scope_stack.pop()
            # Defensive: should not change but keeps the invariant clear.
            assert self.scope_stack[-1] == prev_scope

    def _handle_call(self, caller_id: str, call: Any) -> None:
        fn_node = self._field(call, "function")
        if fn_node is None:
            return
        name = self._text(fn_node).split(".")[-1].split("(")[0]
        # Could contain generic args; strip them
        name = name.split("<")[0].strip()
        if not name:
            return

        if HOOK_RE.match(name):
            hook_id = make_node_id(self.file_path, "hook", name)
            # Emit node for custom hooks only (not built-in core React)
            if name not in {"useState", "useEffect", "useRef", "useMemo", "useCallback", "useContext", "useReducer"}:
                self.result.nodes.append(
                    NodeData(
                        id=hook_id,
                        kind="hook",
                        name=name,
                        file_path=self.file_path,
                        line_start=call.start_point[0] + 1,
                        line_end=call.end_point[0] + 1,
                        language=self.language,
                        file_hash=self.file_hash,
                    )
                )
            self.result.edges.append(
                EdgeData(source_id=caller_id, target_id=hook_id, relation="calls", confidence=0.7)
            )
            self.result.unresolved.append(hook_id)
            return

        target = make_node_id(self.file_path, "function", name)
        self.result.edges.append(
            EdgeData(source_id=caller_id, target_id=target, relation="calls", confidence=0.4)
        )
        self.result.unresolved.append(target)

    def _handle_jsx(self, caller_id: str, elem: Any) -> None:
        # Opening/self-closing has child 'identifier' or 'member_expression' as name
        name_node = None
        for child in elem.children:
            if child.type in {"identifier", "member_expression", "jsx_namespace_name"}:
                name_node = child
                break
        if name_node is None:
            return
        raw_name = self._text(name_node)
        first = raw_name.split(".")[0]
        if not first or not first[0].isupper():
            return  # lowercased = host element like <div>
        target = make_node_id(self.file_path, "component", raw_name)
        self.result.edges.append(
            EdgeData(source_id=caller_id, target_id=target, relation="renders", confidence=0.6)
        )
        self.result.unresolved.append(target)

    def _qualname(self, name: str, kind: str) -> str:
        parent = self.scope_stack[-1]
        if parent == self.file_node_id:
            return make_node_id(self.file_path, kind, name)
        return f"{parent}.{name}"


# ======================================================================
# Module-level helpers
# ======================================================================


def _iter_descendants(node: Any):
    """Depth-first pre-order walk yielding every descendant of ``node``."""
    stack = [node]
    while stack:
        current = stack.pop()
        for child in current.children:
            yield child
            stack.append(child)


def _name_is_component(name: str) -> bool:
    return bool(name) and name[0].isupper()


_JSX_TYPES = {"jsx_element", "jsx_self_closing_element", "jsx_fragment"}


def _body_returns_jsx(body: Any) -> bool:
    """Heuristic: body is (or contains) a JSX element.

    For block bodies (``function Foo() { return <div/>; }``) we scan descendants.
    For expression bodies (``() => <div/>``) the body node itself IS the JSX.
    """
    if body is None:
        return False
    if body.type in _JSX_TYPES:
        return True
    for descendant in _iter_descendants(body):
        if descendant.type in _JSX_TYPES:
            return True
    return False


_HANDLERS = {
    "import_statement": _TSWalker.handle_import,
    "class_declaration": _TSWalker.handle_class,
    "function_declaration": _TSWalker.handle_function_decl,
    "method_definition": _TSWalker.handle_method,
    "variable_declarator": _TSWalker.handle_variable_declarator,
    "interface_declaration": _TSWalker.handle_interface,
    "type_alias_declaration": _TSWalker.handle_type_alias,
    "enum_declaration": _TSWalker.handle_enum,
}
