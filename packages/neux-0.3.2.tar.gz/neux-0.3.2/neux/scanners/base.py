"""Base classes and dataclasses shared by all language scanners."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class NodeData:
    """A single node emitted by a scanner.

    Mirrors the `nodes` table but kept dataclass-light so scanners don't have to
    import the engine. The engine adapts these into DB rows.
    """
    id: str
    kind: str
    name: str
    file_path: str
    line_start: int = 0
    line_end: int = 0
    language: str = ""
    module: str | None = None
    signature: str | None = None
    docstring: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    file_hash: str | None = None


@dataclass(slots=True)
class EdgeData:
    """A relationship between two nodes emitted by a scanner."""
    source_id: str
    target_id: str
    relation: str
    confidence: float = 1.0
    source_type: str = "scan"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ScanResult:
    """Everything produced by scanning a single file."""
    nodes: list[NodeData] = field(default_factory=list)
    edges: list[EdgeData] = field(default_factory=list)
    unresolved: list[str] = field(default_factory=list)
    """Target ids referenced by edges but not present as nodes in this file.

    The orchestrator resolves these globally after all files are scanned.
    """


class BaseScanner(ABC):
    """Abstract scanner for a language. Concrete scanners live in `neux/scanners/`."""

    name: str = ""
    language: str = ""
    extensions: list[str] = []

    @abstractmethod
    def scan_file(self, file_path: Path, content: str) -> ScanResult:
        """Parse ``content`` and return the nodes + edges it contains.

        Implementations must be pure: no DB access, no filesystem writes.
        The orchestrator persists the result through :class:`GraphEngine`.
        """

    def handles(self, file_path: Path) -> bool:
        """Return True if this scanner can process the given path."""
        return file_path.suffix.lower() in self.extensions
