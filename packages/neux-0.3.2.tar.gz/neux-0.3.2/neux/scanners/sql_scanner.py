"""SQL scanner — regex based, no real parser.

Covers ``.sql`` files and SQL embedded inside string literals of ``.py`` / ``.ts``
files (rough heuristic). Extracts:

* ``CREATE TABLE`` → ``table`` + one ``column`` node per column
* ``CREATE INDEX`` / ``CREATE VIEW`` / ``CREATE TRIGGER`` → respective nodes
* ``ALTER TABLE`` → edge against the existing table
* Files under a ``migrations/`` folder are stamped with kind ``migration``
* Inline ``SELECT|INSERT|UPDATE|DELETE`` inside non-SQL files emits
  ``reads_from`` / ``writes_to`` edges to referenced tables
"""

from __future__ import annotations

import re
from pathlib import Path

from neux.engine import compute_file_hash, make_node_id
from neux.scanners.base import BaseScanner, EdgeData, NodeData, ScanResult

_CREATE_TABLE_RE = re.compile(
    r"CREATE\s+(?:VIRTUAL\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`\"]?(\w+)[`\"]?\s*(?:USING\s+\w+)?\s*\(([^;]+?)\)\s*;",
    re.IGNORECASE | re.DOTALL,
)

_CREATE_INDEX_RE = re.compile(
    r"CREATE\s+(?:UNIQUE\s+)?INDEX\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)\s+ON\s+(\w+)",
    re.IGNORECASE,
)
_CREATE_VIEW_RE = re.compile(
    r"CREATE\s+(?:TEMPORARY\s+)?VIEW\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)", re.IGNORECASE
)
_CREATE_TRIGGER_RE = re.compile(
    r"CREATE\s+TRIGGER\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)", re.IGNORECASE
)
_ALTER_TABLE_RE = re.compile(r"ALTER\s+TABLE\s+(\w+)", re.IGNORECASE)

_SELECT_FROM_RE = re.compile(r"(?:SELECT\b.*?FROM|DELETE\s+FROM)\s+[`\"]?(\w+)[`\"]?", re.IGNORECASE | re.DOTALL)
_INSERT_RE = re.compile(r"INSERT\s+(?:OR\s+\w+\s+)?INTO\s+[`\"]?(\w+)[`\"]?", re.IGNORECASE)
_UPDATE_RE = re.compile(r"UPDATE\s+[`\"]?(\w+)[`\"]?\s+SET", re.IGNORECASE)

_STRING_LITERAL_RE = re.compile(
    r'"""(.*?)"""|\'\'\'(.*?)\'\'\'|"([^"\n]{10,})"|\'([^\'\n]{10,})\'|`([^`]{10,})`',
    re.DOTALL,
)


class SQLScanner(BaseScanner):
    name = "sql"
    language = "sql"
    extensions = [".sql"]

    def scan_file(self, file_path: Path, content: str) -> ScanResult:
        result = ScanResult()
        rel_path = str(file_path)
        file_hash = compute_file_hash(content)
        file_node_id = make_node_id(rel_path, "file", file_path.stem)

        is_migration = "migrations" in Path(rel_path).parts or "migration" in file_path.name.lower()
        file_kind = "migration" if is_migration else "file"

        result.nodes.append(
            NodeData(
                id=file_node_id,
                kind=file_kind,
                name=file_path.name,
                file_path=rel_path,
                line_start=1,
                line_end=len(content.splitlines()) or 1,
                language="sql",
                file_hash=file_hash,
            )
        )

        _extract_schema_objects(
            content=content,
            file_path=rel_path,
            file_node_id=file_node_id,
            file_hash=file_hash,
            result=result,
        )
        return result


def scan_sql_in_source(
    file_path: Path,
    content: str,
    owner_node_id: str,
) -> ScanResult:
    """Scan SQL fragments embedded in Python/TS/JS source files.

    Only emits ``reads_from`` / ``writes_to`` edges from ``owner_node_id`` to
    table nodes. Does not create tables — that's the job of the real SQL scanner
    on schema files.
    """
    result = ScanResult()
    for match in _STRING_LITERAL_RE.finditer(content):
        literal = next((g for g in match.groups() if g), "")
        if not literal:
            continue
        upper = literal.upper()
        if not any(kw in upper for kw in ("SELECT ", "INSERT ", "UPDATE ", "DELETE ")):
            continue
        _emit_sql_edges(literal, owner_node_id, str(file_path), result)
    return result


# ======================================================================


def _extract_schema_objects(
    content: str,
    file_path: str,
    file_node_id: str,
    file_hash: str,
    result: ScanResult,
) -> None:
    for match in _CREATE_TABLE_RE.finditer(content):
        table_name = match.group(1)
        columns_src = match.group(2)
        line = content[: match.start()].count("\n") + 1

        table_id = make_node_id(file_path, "table", table_name)
        result.nodes.append(
            NodeData(
                id=table_id,
                kind="table",
                name=table_name,
                file_path=file_path,
                line_start=line,
                line_end=line + columns_src.count("\n") + 1,
                language="sql",
                file_hash=file_hash,
            )
        )
        result.edges.append(
            EdgeData(source_id=file_node_id, target_id=table_id, relation="configures")
        )
        for col_name in _parse_columns(columns_src):
            col_id = f"{table_id}.{col_name}"
            result.nodes.append(
                NodeData(
                    id=col_id,
                    kind="column",
                    name=col_name,
                    file_path=file_path,
                    line_start=line,
                    line_end=line,
                    language="sql",
                    file_hash=file_hash,
                )
            )
            result.edges.append(
                EdgeData(source_id=col_id, target_id=table_id, relation="wraps")
            )

    for match in _CREATE_INDEX_RE.finditer(content):
        idx_name, table_name = match.group(1), match.group(2)
        line = content[: match.start()].count("\n") + 1
        idx_id = make_node_id(file_path, "schema", f"idx_{idx_name}")
        result.nodes.append(
            NodeData(
                id=idx_id,
                kind="schema",
                name=idx_name,
                file_path=file_path,
                line_start=line,
                line_end=line,
                language="sql",
                file_hash=file_hash,
                metadata={"type": "index", "on_table": table_name},
            )
        )
        target_table = make_node_id(file_path, "table", table_name)
        result.edges.append(
            EdgeData(source_id=idx_id, target_id=target_table, relation="depends_on", confidence=0.8)
        )
        result.unresolved.append(target_table)

    for match in _CREATE_VIEW_RE.finditer(content):
        name = match.group(1)
        line = content[: match.start()].count("\n") + 1
        vid = make_node_id(file_path, "schema", f"view_{name}")
        result.nodes.append(
            NodeData(
                id=vid,
                kind="schema",
                name=name,
                file_path=file_path,
                line_start=line,
                line_end=line,
                language="sql",
                file_hash=file_hash,
                metadata={"type": "view"},
            )
        )

    for match in _CREATE_TRIGGER_RE.finditer(content):
        name = match.group(1)
        line = content[: match.start()].count("\n") + 1
        tid = make_node_id(file_path, "schema", f"trg_{name}")
        result.nodes.append(
            NodeData(
                id=tid,
                kind="schema",
                name=name,
                file_path=file_path,
                line_start=line,
                line_end=line,
                language="sql",
                file_hash=file_hash,
                metadata={"type": "trigger"},
            )
        )

    for match in _ALTER_TABLE_RE.finditer(content):
        table_name = match.group(1)
        target_table = make_node_id(file_path, "table", table_name)
        result.edges.append(
            EdgeData(source_id=file_node_id, target_id=target_table, relation="mutates", confidence=0.7)
        )
        result.unresolved.append(target_table)


def _parse_columns(columns_src: str) -> list[str]:
    """Best-effort column name extractor from a CREATE TABLE body."""
    names: list[str] = []
    # Strip nested parens (for CHECK constraints etc)
    depth = 0
    buffer = []
    cleaned: list[str] = []
    for ch in columns_src:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if depth == 0 and ch == ",":
            cleaned.append("".join(buffer))
            buffer = []
        else:
            buffer.append(ch)
    if buffer:
        cleaned.append("".join(buffer))

    for raw in cleaned:
        token = raw.strip().lstrip("`\"").split()
        if not token:
            continue
        name = token[0].strip("`\"")
        upper = name.upper()
        if upper in {"PRIMARY", "FOREIGN", "UNIQUE", "CHECK", "CONSTRAINT", "INDEX", "KEY"}:
            continue
        if name and name.isidentifier():
            names.append(name)
    return names


def _emit_sql_edges(
    literal: str,
    owner_node_id: str,
    file_path: str,
    result: ScanResult,
) -> None:
    for match in _SELECT_FROM_RE.finditer(literal):
        table = match.group(1)
        target = make_node_id(f"_schema/{table}.sql", "table", table)
        result.edges.append(
            EdgeData(source_id=owner_node_id, target_id=target, relation="reads_from", confidence=0.5)
        )
        result.unresolved.append(target)
    for match in _INSERT_RE.finditer(literal):
        table = match.group(1)
        target = make_node_id(f"_schema/{table}.sql", "table", table)
        result.edges.append(
            EdgeData(source_id=owner_node_id, target_id=target, relation="writes_to", confidence=0.5)
        )
        result.unresolved.append(target)
    for match in _UPDATE_RE.finditer(literal):
        table = match.group(1)
        target = make_node_id(f"_schema/{table}.sql", "table", table)
        result.edges.append(
            EdgeData(source_id=owner_node_id, target_id=target, relation="mutates", confidence=0.5)
        )
        result.unresolved.append(target)
