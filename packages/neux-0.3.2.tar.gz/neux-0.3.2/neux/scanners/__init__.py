"""Language-specific code scanners that produce graph nodes and edges."""
