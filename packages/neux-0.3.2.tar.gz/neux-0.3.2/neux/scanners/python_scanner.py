"""Python scanner using the stdlib `ast` module — no third-party deps.

Extracts:
* functions, async functions, classes, methods (with signatures and docstrings)
* imports → ``imports`` edges
* direct ``Call`` sites → ``calls`` edges
* decorators → ``decorates`` edges; ``@app.get/@router.post/...`` promoted to ``endpoint``
* ``os.environ[...]`` / ``os.getenv(...)`` reads → ``env_var`` nodes
"""

from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

from neux.engine import compute_file_hash, make_node_id
from neux.scanners.base import BaseScanner, EdgeData, NodeData, ScanResult

ROUTE_DECORATORS: set[str] = {
    "get", "post", "put", "patch", "delete", "options", "head", "route", "api_route",
}

TEST_FILE_PREFIXES = ("test_",)
TEST_FILE_SUFFIXES = ("_test.py",)


class PythonScanner(BaseScanner):
    name = "python"
    language = "python"
    extensions = [".py"]

    def scan_file(self, file_path: Path, content: str) -> ScanResult:
        result = ScanResult()
        try:
            tree = ast.parse(content, filename=str(file_path))
        except SyntaxError:
            return result

        rel_path = str(file_path)
        file_hash = compute_file_hash(content)
        file_node_id = make_node_id(rel_path, "file", Path(rel_path).stem)

        is_test = _is_test_file(file_path)
        file_kind = "test" if is_test else "file"
        result.nodes.append(
            NodeData(
                id=file_node_id,
                kind=file_kind,
                name=Path(rel_path).name,
                file_path=rel_path,
                line_start=1,
                line_end=len(content.splitlines()) or 1,
                language="python",
                file_hash=file_hash,
                metadata={"is_test": is_test},
            )
        )

        visitor = _PyVisitor(
            file_path=rel_path,
            file_node_id=file_node_id,
            file_hash=file_hash,
            result=result,
            source=content,
            is_test_file=is_test,
        )
        visitor.visit(tree)
        # Second pass for module-level env var reads (top-level statements)
        for stmt in tree.body:
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            for child in ast.walk(stmt):
                if isinstance(child, ast.Call):
                    visitor._handle_module_level_call(child)
                elif isinstance(child, ast.Subscript):
                    visitor._maybe_env_var(file_node_id, child)
        return result


class _PyVisitor(ast.NodeVisitor):
    """AST walker that emits NodeData/EdgeData into a shared ScanResult."""

    def __init__(
        self,
        file_path: str,
        file_node_id: str,
        file_hash: str,
        result: ScanResult,
        source: str,
        is_test_file: bool,
    ):
        self.file_path = file_path
        self.file_node_id = file_node_id
        self.file_hash = file_hash
        self.result = result
        self.source = source
        self.is_test_file = is_test_file
        self.scope_stack: list[str] = [file_node_id]
        self.class_stack: list[str] = []

    # ------------------------------------------------------------------
    # Module-level stuff
    # ------------------------------------------------------------------

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            target_id = make_node_id(_module_to_path(alias.name), "module_node", alias.name.rsplit(".", 1)[-1])
            self.result.edges.append(
                EdgeData(
                    source_id=self.file_node_id,
                    target_id=target_id,
                    relation="imports",
                    metadata={"module": alias.name, "asname": alias.asname},
                )
            )
            self.result.unresolved.append(target_id)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module = node.module or ""
        for alias in node.names:
            name = alias.name
            full = f"{module}.{name}" if module else name
            target_id = make_node_id(_module_to_path(module or name), "module_node", name)
            self.result.edges.append(
                EdgeData(
                    source_id=self.file_node_id,
                    target_id=target_id,
                    relation="imports",
                    metadata={"module": full, "level": node.level},
                )
            )
            self.result.unresolved.append(target_id)

    # ------------------------------------------------------------------
    # Classes / functions
    # ------------------------------------------------------------------

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        cls_id = self._qualname(node.name, kind="class")
        self.result.nodes.append(
            NodeData(
                id=cls_id,
                kind="class",
                name=node.name,
                file_path=self.file_path,
                line_start=node.lineno,
                line_end=node.end_lineno or node.lineno,
                language="python",
                signature=_class_signature(node),
                docstring=ast.get_docstring(node),
                file_hash=self.file_hash,
                metadata={
                    "bases": [ast.unparse(b) for b in node.bases],
                    "decorators": [ast.unparse(d) for d in node.decorator_list],
                },
            )
        )
        # inherits edges (unresolved; resolved later by orchestrator if matched)
        for base in node.bases:
            base_name = _extract_name(base)
            if base_name:
                target = make_node_id(self.file_path, "class", base_name)
                self.result.edges.append(
                    EdgeData(source_id=cls_id, target_id=target, relation="inherits", confidence=0.7)
                )
                self.result.unresolved.append(target)

        self._emit_decorator_edges(cls_id, node.decorator_list)

        self.class_stack.append(cls_id)
        self.scope_stack.append(cls_id)
        self.generic_visit(node)
        self.scope_stack.pop()
        self.class_stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._handle_function(node, is_async=False)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._handle_function(node, is_async=True)

    def _handle_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef, is_async: bool) -> None:
        in_class = bool(self.class_stack)
        kind: str = "method" if in_class else "function"

        endpoint_info = _detect_endpoint(node.decorator_list)
        if endpoint_info:
            kind = "endpoint"
        if self.is_test_file and node.name.startswith("test_"):
            kind = "test"

        fn_id = self._qualname(node.name, kind=kind)
        signature = _function_signature(node)

        self.result.nodes.append(
            NodeData(
                id=fn_id,
                kind=kind,
                name=node.name,
                file_path=self.file_path,
                line_start=node.lineno,
                line_end=node.end_lineno or node.lineno,
                language="python",
                signature=signature,
                docstring=ast.get_docstring(node),
                file_hash=self.file_hash,
                metadata={
                    "is_async": is_async,
                    "decorators": [ast.unparse(d) for d in node.decorator_list],
                    **({"endpoint": endpoint_info} if endpoint_info else {}),
                },
            )
        )

        if in_class:
            # method -> class wraps
            self.result.edges.append(
                EdgeData(source_id=fn_id, target_id=self.class_stack[-1], relation="wraps")
            )

        self._emit_decorator_edges(fn_id, node.decorator_list)

        self.scope_stack.append(fn_id)
        # Walk body for Call/env_var
        for child in ast.walk(node):
            if child is node:
                continue
            if isinstance(child, ast.Call):
                self._handle_call(fn_id, child)
            elif isinstance(child, ast.Subscript):
                self._maybe_env_var(fn_id, child)
        self.scope_stack.pop()

        # Don't generic_visit — the walk above already handled descendants.

    def _handle_module_level_call(self, call: ast.Call) -> None:
        if isinstance(call.func, ast.Attribute):
            full = ast.unparse(call.func)
            if full in {"os.getenv", "os.environ.get"} and call.args:
                first = call.args[0]
                if isinstance(first, ast.Constant) and isinstance(first.value, str):
                    self._emit_env_var(first.value, call.lineno)

    def _handle_call(self, caller_id: str, call: ast.Call) -> None:
        name = _extract_name(call.func)
        if not name:
            return
        target = make_node_id(self.file_path, "function", name)
        self.result.edges.append(
            EdgeData(source_id=caller_id, target_id=target, relation="calls", confidence=0.5)
        )
        self.result.unresolved.append(target)

        # Detect os.getenv("X") / os.environ.get("X")
        if isinstance(call.func, ast.Attribute):
            full = ast.unparse(call.func)
            if full in {"os.getenv", "os.environ.get"} and call.args:
                first = call.args[0]
                if isinstance(first, ast.Constant) and isinstance(first.value, str):
                    self._emit_env_var(first.value, call.lineno)

    def _maybe_env_var(self, owner_id: str, sub: ast.Subscript) -> None:
        if isinstance(sub.value, ast.Attribute):
            full = ast.unparse(sub.value)
            if full == "os.environ":
                key: Any = sub.slice
                if isinstance(key, ast.Constant) and isinstance(key.value, str):
                    self._emit_env_var(key.value, sub.lineno)

    def _emit_env_var(self, var_name: str, line: int) -> None:
        env_id = make_node_id(self.file_path, "env_var", var_name)
        self.result.nodes.append(
            NodeData(
                id=env_id,
                kind="env_var",
                name=var_name,
                file_path=self.file_path,
                line_start=line,
                line_end=line,
                language="python",
                file_hash=self.file_hash,
            )
        )
        self.result.edges.append(
            EdgeData(source_id=self.file_node_id, target_id=env_id, relation="reads_from")
        )

    def _emit_decorator_edges(self, target_id: str, decorators: list[ast.expr]) -> None:
        for dec in decorators:
            name = _extract_name(dec)
            if not name:
                continue
            dec_id = make_node_id(self.file_path, "decorator", name)
            self.result.edges.append(
                EdgeData(source_id=dec_id, target_id=target_id, relation="decorates", confidence=0.6)
            )
            self.result.unresolved.append(dec_id)

    def _qualname(self, name: str, kind: str) -> str:
        parent = self.scope_stack[-1]
        if parent == self.file_node_id:
            return make_node_id(self.file_path, kind, name)
        return f"{parent}.{name}"


# ======================================================================
# helpers
# ======================================================================


def _module_to_path(module: str) -> str:
    """Turn a dotted module name into a pseudo file path for ID generation."""
    return module.replace(".", "/") + ".py"


def _extract_name(node: ast.expr) -> str | None:
    """Best-effort short name from an AST expression."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Call):
        return _extract_name(node.func)
    return None


def _function_signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    try:
        args = ast.unparse(node.args)
    except Exception:
        args = "..."
    returns = ""
    if node.returns is not None:
        try:
            returns = f" -> {ast.unparse(node.returns)}"
        except Exception:
            returns = ""
    prefix = "async def" if isinstance(node, ast.AsyncFunctionDef) else "def"
    return f"{prefix} {node.name}({args}){returns}"


def _class_signature(node: ast.ClassDef) -> str:
    bases = []
    for base in node.bases:
        try:
            bases.append(ast.unparse(base))
        except Exception:
            pass
    return f"class {node.name}({', '.join(bases)})" if bases else f"class {node.name}"


def _detect_endpoint(decorators: list[ast.expr]) -> dict[str, Any] | None:
    """If a decorator looks like ``@app.get('/path')`` return route info."""
    for dec in decorators:
        call = dec if isinstance(dec, ast.Call) else None
        target = call.func if call else dec
        if isinstance(target, ast.Attribute) and target.attr in ROUTE_DECORATORS:
            path = None
            if call and call.args:
                first = call.args[0]
                if isinstance(first, ast.Constant) and isinstance(first.value, str):
                    path = first.value
            return {"method": target.attr.upper(), "path": path}
    return None


def _is_test_file(path: Path) -> bool:
    name = path.name
    return name.startswith(TEST_FILE_PREFIXES) or name.endswith(TEST_FILE_SUFFIXES)
