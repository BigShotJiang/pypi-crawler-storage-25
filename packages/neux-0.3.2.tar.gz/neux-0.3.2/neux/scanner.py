"""ProjectScanner — walks a project tree, dispatches files to language scanners,
and persists results through :class:`GraphEngine`.

This is the only place that knows about filesystem walking, ignore patterns,
stack detection and module inference. Individual scanners remain pure.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from neux.engine import GraphEngine, compute_file_hash, make_node_id
from neux.scanners.base import BaseScanner, EdgeData, NodeData, ScanResult
from neux.scanners.python_scanner import PythonScanner
from neux.scanners.sql_scanner import SQLScanner, scan_sql_in_source
from neux.scanners.typescript_scanner import TypeScriptScanner

DEFAULT_IGNORE_DIRS: set[str] = {
    ".git", ".neux", "node_modules", "__pycache__", "venv", ".venv",
    "dist", "build", ".next", ".nuxt", "coverage", "target", ".pytest_cache",
    ".mypy_cache", ".ruff_cache", ".tox", "htmlcov", ".idea", ".vscode",
    ".turbo", ".parcel-cache", "out",
}

DEFAULT_IGNORE_GLOB_SUFFIXES = (".min.js", ".min.css", ".map", ".lock")


@dataclass(slots=True)
class ScanStats:
    files_scanned: int = 0
    files_skipped: int = 0
    nodes_added: int = 0
    edges_added: int = 0
    errors: int = 0


class ProjectScanner:
    """Orchestrates all language scanners for a project root."""

    def __init__(
        self,
        engine: GraphEngine,
        scanners: list[BaseScanner] | None = None,
        ignore_dirs: set[str] | None = None,
    ):
        self.engine = engine
        self.scanners: list[BaseScanner] = scanners or [
            PythonScanner(),
            TypeScriptScanner(),
            SQLScanner(),
        ]
        self.ignore_dirs = ignore_dirs or set(DEFAULT_IGNORE_DIRS)
        self._scanner_by_ext: dict[str, BaseScanner] = {}
        for sc in self.scanners:
            for ext in sc.extensions:
                self._scanner_by_ext[ext] = sc

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scan_project(
        self, root: Path | str, progress_cb: Callable[[str], None] | None = None
    ) -> ScanStats:
        """Perform a full scan of a project root.

        Wipes any existing nodes before re-populating, so the graph always
        reflects the current disk state. Runs module coupling computation at
        the end.
        """
        root_path = Path(root).resolve()
        stats = ScanStats()

        self._wipe_graph()

        # Pre-create modules from top-level directories
        for entry in sorted(root_path.iterdir()):
            if entry.is_dir() and entry.name not in self.ignore_dirs and not entry.name.startswith("."):
                self.engine.add_module(
                    name=entry.name,
                    root_path=str(entry.relative_to(root_path)),
                    layer=_guess_layer(entry.name),
                )
        self.engine.add_module(name="root", layer="unknown")

        for path in self._walk(root_path):
            rel = path.relative_to(root_path)
            ext = path.suffix.lower()
            if path.name.endswith(DEFAULT_IGNORE_GLOB_SUFFIXES):
                stats.files_skipped += 1
                continue
            scanner = self._scanner_by_ext.get(ext)
            if scanner is None:
                # still try SQL embedded detection inside python/ts
                if ext in {".py", ".ts", ".tsx", ".js", ".jsx"}:
                    pass  # handled inside _scan_single after primary scan
                else:
                    stats.files_skipped += 1
                    continue

            if progress_cb is not None:
                progress_cb(str(rel))

            try:
                content = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                stats.errors += 1
                continue

            try:
                self._scan_single(rel, content, stats)
            except Exception:
                stats.errors += 1
                continue

            stats.files_scanned += 1

        # Recompute coupling after the full scan
        self.engine.update_module_coupling()

        # Persist project info
        self._store_project_info(root_path, stats)
        return stats

    def scan_changed(self, root: Path | str) -> ScanStats:
        """Rescan only files whose hashes differ from what's in the graph."""
        root_path = Path(root).resolve()
        stats = ScanStats()
        for path in self._walk(root_path):
            rel = path.relative_to(root_path)
            ext = path.suffix.lower()
            scanner = self._scanner_by_ext.get(ext)
            if scanner is None:
                continue
            try:
                content = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                stats.errors += 1
                continue
            current_hash = compute_file_hash(content)
            stored_hash = self.engine.get_file_hash(str(rel))
            if stored_hash == current_hash:
                stats.files_skipped += 1
                continue
            # Wipe this file's nodes then re-scan
            self.engine.delete_nodes_by_file(str(rel))
            self.engine.clear_inconsistencies_for_file(str(rel))
            try:
                self._scan_single(rel, content, stats)
            except Exception:
                stats.errors += 1
                continue
            stats.files_scanned += 1
        self.engine.update_module_coupling()
        return stats

    def detect_stack(self, root: Path | str) -> dict[str, Any]:
        """Inspect manifest files to describe the project stack."""
        root_path = Path(root)
        stack: dict[str, Any] = {
            "languages": [],
            "frameworks": [],
            "has_tests": False,
        }
        if (root_path / "pyproject.toml").exists() or (root_path / "requirements.txt").exists():
            stack["languages"].append("python")
        pkg = root_path / "package.json"
        if pkg.exists():
            stack["languages"].append("javascript")
            try:
                data = json.loads(pkg.read_text(encoding="utf-8", errors="replace"))
                deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
                for name in ("react", "next", "vue", "svelte", "fastapi", "express", "tailwindcss"):
                    if any(name in k.lower() for k in deps):
                        stack["frameworks"].append(name)
            except json.JSONDecodeError:
                pass
        if (root_path / "tsconfig.json").exists():
            stack["languages"].append("typescript")
        if any((root_path / d).exists() for d in ("tests", "test", "__tests__")):
            stack["has_tests"] = True
        stack["languages"] = sorted(set(stack["languages"]))
        return stack

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _walk(self, root: Path):
        stack = [root]
        while stack:
            current = stack.pop()
            try:
                for entry in current.iterdir():
                    if entry.is_dir():
                        if entry.name in self.ignore_dirs:
                            continue
                        if entry.name.startswith(".") and entry.name not in {".github"}:
                            continue
                        stack.append(entry)
                    elif entry.is_file():
                        yield entry
            except (PermissionError, OSError):
                continue

    def _wipe_graph(self) -> None:
        with self.engine.conn:
            self.engine.conn.execute("DELETE FROM edges")
            self.engine.conn.execute("DELETE FROM nodes")

    def _scan_single(self, rel_path: Path, content: str, stats: ScanStats) -> None:
        ext = rel_path.suffix.lower()
        scanner = self._scanner_by_ext.get(ext)
        result = ScanResult()
        if scanner is not None:
            result = scanner.scan_file(rel_path, content)

        # Embedded SQL pass (for python/js/ts containing literal queries)
        if ext in {".py", ".ts", ".tsx", ".js", ".jsx"}:
            file_node_id = make_node_id(str(rel_path), "file", rel_path.stem)
            sql_result = scan_sql_in_source(rel_path, content, file_node_id)
            result.edges.extend(sql_result.edges)
            result.unresolved.extend(sql_result.unresolved)

        module = self.engine.infer_module(str(rel_path))
        self._persist(result, module, stats)

    def _persist(self, result: ScanResult, module: str, stats: ScanStats) -> None:
        # Pre-create placeholder file nodes for any unresolved targets so FK
        # constraints don't drop edges. Placeholders get a 'module_node' kind.
        existing_ids: set[str] = {n.id for n in result.nodes}
        for node in result.nodes:
            self.engine.add_node(
                id=node.id,
                kind=node.kind,
                name=node.name,
                file_path=node.file_path,
                line_start=node.line_start,
                line_end=node.line_end,
                module=node.module or module,
                language=node.language,
                signature=node.signature,
                docstring=node.docstring,
                metadata=node.metadata or None,
                file_hash=node.file_hash,
            )
            stats.nodes_added += 1

        unresolved_unique = {uid for uid in result.unresolved if uid not in existing_ids}
        for uid in unresolved_unique:
            if self.engine.get_node(uid) is None:
                short = uid.rsplit(".", 1)[-1] if "." in uid else uid
                self.engine.add_node(
                    id=uid,
                    kind="module_node",
                    name=short,
                    file_path=None,
                    language=None,
                    module=None,
                )

        for edge in result.edges:
            self.engine.add_edge(
                source_id=edge.source_id,
                target_id=edge.target_id,
                relation=edge.relation,
                confidence=edge.confidence,
                metadata=edge.metadata or None,
                source_type=edge.source_type,
            )
            stats.edges_added += 1

    def _store_project_info(self, root: Path, stats: ScanStats) -> None:
        info = {
            "project_root": str(root),
            "stack": json.dumps(self.detect_stack(root)),
            "last_scan_nodes": str(stats.nodes_added),
            "last_scan_edges": str(stats.edges_added),
        }
        with self.engine.conn:
            for key, value in info.items():
                self.engine.conn.execute(
                    """
                    INSERT INTO project_info (key, value, updated_at)
                    VALUES (?, ?, datetime('now'))
                    ON CONFLICT(key) DO UPDATE SET
                        value=excluded.value,
                        updated_at=datetime('now')
                    """,
                    (key, value),
                )


_LAYER_HINTS: dict[str, str] = {
    "api": "api", "routes": "api", "endpoints": "api", "handlers": "api",
    "services": "service", "service": "service", "core": "service",
    "models": "data", "db": "data", "database": "data", "migrations": "data",
    "components": "ui", "pages": "ui", "views": "ui", "screens": "ui", "ui": "ui",
    "styles": "ui", "theme": "ui",
    "config": "config", "configs": "config",
    "infra": "infrastructure", "infrastructure": "infrastructure", "scripts": "infrastructure",
    "tests": "test", "test": "test", "__tests__": "test", "spec": "test",
    "utils": "utility", "lib": "utility", "helpers": "utility",
}


def _guess_layer(folder_name: str) -> str:
    return _LAYER_HINTS.get(folder_name.lower(), "unknown")
