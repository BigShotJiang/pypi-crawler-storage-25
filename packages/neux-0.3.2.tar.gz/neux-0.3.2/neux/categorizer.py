"""TaskCategorizer — classify a user prompt + file path into a task category.

Returns one of:
``style_change`` | ``logic_change`` | ``new_feature`` | ``bug_fix`` | ``refactor`` |
``test_writing`` | ``api_change`` | ``database_change`` | ``config_change`` | ``general``

The categorization is score-based: count keyword hits in the prompt, add a
path hint (e.g. ``components/`` → ``style_change`` weight bump). No NLP, no LLM.
Kept deliberately simple so the hook entrypoint can run it without any heavy imports.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# Keywords per category — bilingual (Spanish + English) to match how IronDevz
# developers usually phrase requests.
CATEGORY_KEYWORDS: dict[str, list[str]] = {
    "style_change": [
        "color", "colour", "style", "styles", "estilo", "estilos", "css", "scss",
        "sass", "theme", "tema", "font", "fuente", "tailwind", "responsive",
        "padding", "margin", "layout", "design", "diseño", "ui", "visual",
        "dark mode", "tipograf", "hover", "border",
    ],
    "new_feature": [
        "crear", "nuevo", "nueva", "agregar", "añadir", "implementar",
        "construir", "create", "add", "build", "implement", "feature",
        "introduce", "support for", "soporte para",
    ],
    "logic_change": [
        "función", "function", "cambiar", "modificar", "change", "modify",
        "update", "actualizar", "adjust", "ajustar", "transform", "lógica",
        "logic", "algorithm", "algoritmo", "flow", "flujo",
    ],
    "bug_fix": [
        "bug", "error", "errors", "errores", "fix", "arreglar", "crash",
        "falla", "broken", "roto", "issue", "problema", "incorrect",
        "incorrecto", "no funciona", "not working", "regression", "regresión",
    ],
    "refactor": [
        "refactor", "refactoring", "rename", "renombrar", "reorganizar",
        "reorganize", "cleanup", "limpiar", "extract", "extraer", "simplify",
        "simplificar", "dry", "deduplicate",
    ],
    "test_writing": [
        "test", "tests", "prueba", "pruebas", "mock", "fixture", "coverage",
        "spec", "unit test", "integration test", "pytest", "jest", "vitest",
        "assert", "expect",
    ],
    "api_change": [
        "endpoint", "endpoints", "api", "ruta", "rutas", "route", "routes",
        "middleware", "auth", "authorization", "rest", "graphql", "request",
        "response", "http", "get", "post", "put", "delete", "patch",
    ],
    "database_change": [
        "tabla", "table", "migración", "migration", "modelo", "model",
        "schema", "query", "sql", "database", "base de datos", "column",
        "columna", "index", "índice", "foreign key", "constraint",
    ],
    "config_change": [
        "config", "configuration", "configuración", "env", ".env", "docker",
        "deploy", "deployment", "ci", "cd", "workflow", "pipeline",
        "environment variable", "variable de entorno", "pyproject",
        "package.json", "tsconfig", "settings",
    ],
}

# Path hints: substring → category score bonus
PATH_HINTS: dict[str, str] = {
    "/components/": "style_change",
    "/styles/": "style_change",
    "/css/": "style_change",
    "theme": "style_change",
    "tailwind": "style_change",
    "/api/": "api_change",
    "/routes/": "api_change",
    "/endpoints/": "api_change",
    "/migrations/": "database_change",
    ".sql": "database_change",
    "/models/": "database_change",
    "/tests/": "test_writing",
    "test_": "test_writing",
    ".test.": "test_writing",
    ".spec.": "test_writing",
    "dockerfile": "config_change",
    ".env": "config_change",
    "config": "config_change",
}


@dataclass(slots=True)
class Categorization:
    category: str
    score: float
    matched_keywords: list[str] = field(default_factory=list)
    path_hint: str | None = None


class TaskCategorizer:
    """Score-based categorizer. No external dependencies."""

    def __init__(
        self,
        keywords: dict[str, list[str]] | None = None,
        path_hints: dict[str, str] | None = None,
    ):
        self.keywords = keywords or CATEGORY_KEYWORDS
        self.path_hints = path_hints or PATH_HINTS

    def categorize(self, prompt: str, file_path: str | None = None) -> Categorization:
        if not prompt and not file_path:
            return Categorization("general", 0.0)

        lower_prompt = (prompt or "").lower()
        scores: dict[str, float] = {k: 0.0 for k in self.keywords}
        matched: dict[str, list[str]] = {k: [] for k in self.keywords}

        for category, kws in self.keywords.items():
            for kw in kws:
                if kw in lower_prompt:
                    scores[category] += 1.0
                    matched[category].append(kw)

        hint_category: str | None = None
        if file_path:
            lower_path = file_path.lower()
            for substr, cat in self.path_hints.items():
                if substr in lower_path:
                    scores[cat] = scores.get(cat, 0.0) + 0.5
                    hint_category = cat
                    break

        best = max(scores.items(), key=lambda kv: kv[1])
        if best[1] == 0:
            return Categorization("general", 0.0, path_hint=hint_category)
        return Categorization(
            category=best[0],
            score=best[1],
            matched_keywords=matched[best[0]],
            path_hint=hint_category,
        )
