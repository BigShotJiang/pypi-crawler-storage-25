"""Interactive pattern / convention reviewer.

Walks all candidate patterns and conventions and prompts the user to
confirm, discard or edit each. Simple blocking loop — hooks and CLI
call it via ``neux review``.
"""

from __future__ import annotations

from typing import Any

from rich.console import Console
from rich.panel import Panel

from neux.engine import GraphEngine

console = Console()


def review_session(engine: GraphEngine) -> None:
    candidates = [p for p in engine.get_patterns(status="candidate")] + [
        c for c in engine.get_conventions(status="candidate")
    ]
    if not candidates:
        console.print("[green]Nothing to review — no candidates found.[/green]")
        return

    console.print(f"[cyan]{len(candidates)} candidate rule(s) to review.[/cyan]")

    for item in candidates:
        rule_type = "pattern" if "occurrences" in item else "convention"
        title = f"[bold]{rule_type}:{item['name']}[/bold]  •  conf={item.get('confidence', 0):.2f}"
        if rule_type == "convention":
            title += f"  •  compliance={int((item.get('compliance') or 0) * 100)}%"
        body = _format(item)
        console.print(Panel(body, title=title, border_style="cyan"))

        choice = console.input("[yellow]Confirm (y) / Discard (n) / Skip (s) / Quit (q) > [/yellow]").strip().lower()
        if choice in {"q", "quit"}:
            break
        if choice in {"y", "yes"}:
            if rule_type == "pattern":
                engine.confirm_pattern(item["id"])
            else:
                engine.conn.execute(
                    "UPDATE conventions SET status='confirmed', confirmed_at=datetime('now') WHERE id = ?",
                    (item["id"],),
                )
            console.print("[green]Confirmed.[/green]\n")
        elif choice in {"n", "no"}:
            if rule_type == "pattern":
                engine.discard_pattern(item["id"])
            else:
                engine.conn.execute(
                    "UPDATE conventions SET status='discarded' WHERE id = ?", (item["id"],)
                )
            console.print("[red]Discarded.[/red]\n")
        else:
            console.print("[dim]Skipped.[/dim]\n")


def _format(item: dict[str, Any]) -> str:
    lines = [
        item.get("description", ""),
        "",
        f"[white]Rule:[/white] {item.get('rule_text') or '—'}",
    ]
    return "\n".join(lines)
