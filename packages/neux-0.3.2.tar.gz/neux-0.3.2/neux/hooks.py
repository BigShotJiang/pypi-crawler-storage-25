"""Claude Code hook handlers.

This module implements the business logic for the three hook events. It is
called from :mod:`neux.hook_entry` which owns the lightweight stdin parsing
and latency budget. Keeping the heavy imports here (scanners, detectors)
lets ``hook_entry`` stay lean.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from neux.categorizer import TaskCategorizer
from neux.context_builder import ContextBuilder
from neux.engine import GraphEngine
from neux.scanner import DEFAULT_IGNORE_DIRS


def handle_pre_tool_use(project_root: Path, payload: dict[str, Any]) -> str:
    """Produce the context block for a file about to be edited.

    Returns the text to emit on stderr. Empty string means "no context".
    """
    file_path = _extract_file_path(payload)
    if not file_path:
        return ""
    rel = _relativize(project_root, file_path)
    if _is_ignored(rel):
        return ""

    prompt = payload.get("prompt") or payload.get("tool_input", {}).get("prompt") or ""

    engine = GraphEngine(project_root)
    try:
        categorizer = TaskCategorizer()
        cat = categorizer.categorize(prompt, rel)
        builder = ContextBuilder(engine)
        text = builder.build(rel, cat.category)
        return text
    finally:
        engine.close()


def handle_post_tool_use(project_root: Path, payload: dict[str, Any]) -> str:
    """Re-parse a modified file, update the graph, and surface fresh warnings."""
    file_path = _extract_file_path(payload)
    if not file_path:
        return ""
    rel = _relativize(project_root, file_path)
    if _is_ignored(rel):
        return ""

    abs_path = Path(project_root) / rel
    if not abs_path.exists():
        engine = GraphEngine(project_root)
        try:
            engine.delete_nodes_by_file(rel)
            engine.clear_inconsistencies_for_file(rel)
        finally:
            engine.close()
        return ""

    try:
        content = abs_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""

    # Lazy imports — scanners/detectors are expensive to import
    from neux.detectors import DetectionContext, DetectionEngine, all_detectors
    from neux.scanner import ProjectScanner

    engine = GraphEngine(project_root)
    try:
        scanner = ProjectScanner(engine)
        engine.delete_nodes_by_file(rel)
        engine.clear_inconsistencies_for_file(rel)
        try:
            scanner._scan_single(Path(rel), content, _NullStats())  # type: ignore[arg-type]
        except Exception:
            return ""

        # Record action in the active session
        session_id = _current_session_id(project_root)
        if session_id:
            tool_name = payload.get("tool_name", "")
            action_type = "create_file" if tool_name == "Write" else "edit_file"
            engine.record_action(
                session_id=session_id,
                action_type=action_type,
                file_path=rel,
            )

        nodes = engine.get_nodes_by_file(rel)
        if not nodes:
            return ""

        edges: list[dict[str, Any]] = []
        for n in nodes:
            edges.extend(engine.get_edges(n["id"]))

        ctx = DetectionContext(
            nodes=nodes,
            edges=edges,
            files={rel: content},
            project_info={"languages": _languages_from_nodes(nodes)},
            changed_files=[rel],
        )
        det_engine = DetectionEngine(all_detectors())
        results = det_engine.run_all(ctx)
        det_engine.persist(engine, results)

        new_warnings = engine.get_inconsistencies(status="open", file_path=rel)
        if not new_warnings:
            return ""

        lines = [f"[NEUX] {len(new_warnings)} inconsistencia(s) en {rel}:"]
        for w in new_warnings[:5]:
            line = w.get("line_number")
            loc = f":{line}" if line else ""
            lines.append(f"  - {rel}{loc} [{w['severity']}] {w['description']}")
        return "\n".join(lines) + "\n"
    finally:
        engine.close()


def handle_session_start(project_root: Path, payload: dict[str, Any]) -> str:
    """Ensure the DB exists and rescan any files that drifted."""
    root = Path(project_root)
    db_file = root / ".neux" / "graph.db"
    if not db_file.exists():
        return "[NEUX] No .neux/graph.db found — run `neux init` in this project.\n"

    from neux.scanner import ProjectScanner

    engine = GraphEngine(root)
    try:
        scanner = ProjectScanner(engine)
        stats = scanner.scan_changed(root)
        session_id = engine.start_session("exploration")
        (root / ".neux" / "current_session").write_text(session_id)
        gs = engine.get_stats()
        summary = (
            f"[NEUX] Sesión {session_id} iniciada. "
            f"Grafo: {gs['nodes']} nodos, {gs['edges']} edges, "
            f"{gs['inconsistencies_open']} inconsistencias abiertas."
        )
        if stats.files_scanned:
            summary += f" Rescaneados {stats.files_scanned} archivos modificados."
        return summary + "\n"
    finally:
        engine.close()


def handle_stop(project_root: Path, payload: dict[str, Any]) -> str:
    """Close the active session — called when Claude Code ends."""
    root = Path(project_root)
    session_id = _current_session_id(root)
    if not session_id:
        return ""

    engine = GraphEngine(root)
    try:
        engine.end_session(session_id)
        session_file = root / ".neux" / "current_session"
        session_file.unlink(missing_ok=True)
        return f"[NEUX] Sesión {session_id} finalizada.\n"
    finally:
        engine.close()


# ======================================================================
# helpers
# ======================================================================


def _current_session_id(project_root: Path) -> str | None:
    """Read the active session id from .neux/current_session, or None."""
    session_file = project_root / ".neux" / "current_session"
    try:
        sid = session_file.read_text(encoding="utf-8").strip()
        return sid if sid else None
    except OSError:
        return None


def _extract_file_path(payload: dict[str, Any]) -> str | None:
    """Claude Code hooks deliver tool input under ``tool_input.file_path``.

    Also handle ``tool_input.path`` and ``payload.file_path`` for alternative
    hook formats observed in the wild.
    """
    tool_input = payload.get("tool_input") or {}
    for key in ("file_path", "path", "filename"):
        val = tool_input.get(key)
        if isinstance(val, str) and val:
            return val
    for key in ("file_path", "path"):
        val = payload.get(key)
        if isinstance(val, str) and val:
            return val
    return None


def _relativize(project_root: Path, file_path: str) -> str:
    try:
        abs_path = Path(file_path)
        if not abs_path.is_absolute():
            return str(abs_path).lstrip("./")
        return str(abs_path.relative_to(project_root))
    except ValueError:
        return file_path


def _is_ignored(rel_path: str) -> bool:
    parts = Path(rel_path).parts
    for part in parts:
        if part in DEFAULT_IGNORE_DIRS:
            return True
    return False


def _languages_from_nodes(nodes: list[dict[str, Any]]) -> list[str]:
    return sorted({n["language"] for n in nodes if n.get("language")})


class _NullStats:
    """Stub object used when we don't care about scan stats."""
    nodes_added = 0
    edges_added = 0
    files_scanned = 0
    files_skipped = 0
    errors = 0
