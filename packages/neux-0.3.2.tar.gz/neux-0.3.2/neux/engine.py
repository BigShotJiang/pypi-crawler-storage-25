"""GraphEngine — CRUD and graph queries over the NEUX SQLite knowledge graph.

The engine is the single API layer every other component talks to. Scanners and
detectors produce data that the engine writes; hooks, CLI and generator read
through the engine. No other module should execute raw SQL against the graph.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Iterable

from neux.db import get_connection, init_db, migrate


def make_node_id(file_path: str, kind: str, name: str) -> str:
    """Build a deterministic, human-readable node id.

    Example: ``neux/engine.py`` + ``GraphEngine.add_node`` → ``neux.engine.GraphEngine.add_node``.
    Common source prefixes (``src``, ``app``, ``lib``, ``source``) are stripped so that
    refactoring a folder layout does not mass-rename every node.
    """
    skip = {"src", "app", "lib", "source"}
    parts = [p for p in Path(file_path).with_suffix("").parts if p not in skip and p != "."]
    prefix = ".".join(parts) if parts else "root"
    return f"{prefix}.{name}" if name else f"{prefix}:{kind}"


def compute_file_hash(content: str) -> str:
    """SHA1 of raw file contents — used to skip re-parsing unchanged files."""
    return hashlib.sha1(content.encode("utf-8", errors="replace")).hexdigest()


def _row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return {k: row[k] for k in row.keys()}


def _rows_to_dicts(rows: Iterable[sqlite3.Row]) -> list[dict[str, Any]]:
    return [{k: r[k] for k in r.keys()} for r in rows]


class GraphEngine:
    """Stateful wrapper around a `.neux/graph.db` connection.

    Instantiate once per project root and reuse. All writes happen inside
    `with self.conn:` transactions for atomicity. Call :meth:`close` when done.
    """

    def __init__(self, project_path: Path | str):
        self.project_path = Path(project_path)
        self.conn = get_connection(self.project_path)
        migrate(self.conn)

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> GraphEngine:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Nodos
    # ------------------------------------------------------------------

    def add_node(
        self,
        id: str,
        kind: str,
        name: str,
        file_path: str | None = None,
        line_start: int | None = None,
        line_end: int | None = None,
        module: str | None = None,
        language: str | None = None,
        signature: str | None = None,
        docstring: str | None = None,
        metadata: dict[str, Any] | None = None,
        file_hash: str | None = None,
    ) -> None:
        """Insert or replace a node.

        Uses ``INSERT OR REPLACE`` so scanners can re-emit nodes for a changed
        file without first deleting them.
        """
        meta_json = json.dumps(metadata) if metadata else None
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO nodes
                    (id, kind, name, file_path, line_start, line_end, module,
                     language, signature, docstring, metadata, file_hash)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    kind=excluded.kind,
                    name=excluded.name,
                    file_path=excluded.file_path,
                    line_start=excluded.line_start,
                    line_end=excluded.line_end,
                    module=excluded.module,
                    language=excluded.language,
                    signature=excluded.signature,
                    docstring=excluded.docstring,
                    metadata=excluded.metadata,
                    file_hash=excluded.file_hash,
                    updated_at=datetime('now')
                """,
                (id, kind, name, file_path, line_start, line_end, module,
                 language, signature, docstring, meta_json, file_hash),
            )

    def get_node(self, id: str) -> dict[str, Any] | None:
        row = self.conn.execute("SELECT * FROM nodes WHERE id = ?", (id,)).fetchone()
        return _row_to_dict(row)

    def get_nodes_by_file(self, file_path: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM nodes WHERE file_path = ? ORDER BY line_start", (file_path,)
        ).fetchall()
        return _rows_to_dicts(rows)

    def get_nodes_by_module(self, module: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM nodes WHERE module = ? ORDER BY file_path, line_start",
            (module,),
        ).fetchall()
        return _rows_to_dicts(rows)

    def get_nodes_by_kind(self, kind: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM nodes WHERE kind = ? ORDER BY name", (kind,)
        ).fetchall()
        return _rows_to_dicts(rows)

    def delete_nodes_by_file(self, file_path: str) -> int:
        """Delete all nodes attached to a file. Cascades edges via FK."""
        with self.conn:
            cur = self.conn.execute("DELETE FROM nodes WHERE file_path = ?", (file_path,))
            return cur.rowcount

    def search_nodes(self, query: str, limit: int = 50) -> list[dict[str, Any]]:
        """Full-text search across nodes via FTS5.

        The query is passed through as-is; callers wanting prefix search should
        append ``*`` themselves (e.g. ``"graph*"``).
        """
        escaped = query.replace('"', '""')
        rows = self.conn.execute(
            """
            SELECT n.* FROM nodes n
            JOIN nodes_fts f ON f.rowid = n.rowid
            WHERE nodes_fts MATCH ?
            LIMIT ?
            """,
            (escaped, limit),
        ).fetchall()
        return _rows_to_dicts(rows)

    def get_file_hash(self, file_path: str) -> str | None:
        """Return a representative file_hash for a file (first node), if any."""
        row = self.conn.execute(
            "SELECT file_hash FROM nodes WHERE file_path = ? AND file_hash IS NOT NULL LIMIT 1",
            (file_path,),
        ).fetchone()
        return row[0] if row else None

    # ------------------------------------------------------------------
    # Aristas
    # ------------------------------------------------------------------

    def add_edge(
        self,
        source_id: str,
        target_id: str,
        relation: str,
        weight: float = 1.0,
        confidence: float = 1.0,
        metadata: dict[str, Any] | None = None,
        source_type: str = "scan",
    ) -> None:
        """Insert an edge, silently skipping duplicates.

        The ``nodes`` FK is enforced: if either side is missing the insert is
        suppressed. Callers should ensure nodes exist or pre-create placeholder
        ``file`` nodes for external references.
        """
        meta_json = json.dumps(metadata) if metadata else None
        try:
            with self.conn:
                self.conn.execute(
                    """
                    INSERT OR IGNORE INTO edges
                        (source_id, target_id, relation, weight, confidence, metadata, source_type)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (source_id, target_id, relation, weight, confidence, meta_json, source_type),
                )
        except sqlite3.IntegrityError:
            # FK violation — one of the endpoints doesn't exist. Silently skip;
            # detectors will surface unresolved references via the 'imports'
            # relation sitting on a placeholder file node if needed.
            pass

    def get_edges(
        self, node_id: str, direction: str = "both"
    ) -> list[dict[str, Any]]:
        """Return edges touching a node.

        ``direction`` ∈ {``'out'``, ``'in'``, ``'both'``}.
        """
        if direction == "out":
            sql = "SELECT * FROM edges WHERE source_id = ?"
            params: tuple[Any, ...] = (node_id,)
        elif direction == "in":
            sql = "SELECT * FROM edges WHERE target_id = ?"
            params = (node_id,)
        else:
            sql = "SELECT * FROM edges WHERE source_id = ? OR target_id = ?"
            params = (node_id, node_id)
        rows = self.conn.execute(sql, params).fetchall()
        return _rows_to_dicts(rows)

    def get_edges_by_relation(self, relation: str) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM edges WHERE relation = ?", (relation,)
        ).fetchall()
        return _rows_to_dicts(rows)

    def delete_edges_by_node(self, node_id: str) -> int:
        with self.conn:
            cur = self.conn.execute(
                "DELETE FROM edges WHERE source_id = ? OR target_id = ?", (node_id, node_id)
            )
            return cur.rowcount

    # ------------------------------------------------------------------
    # Modulos
    # ------------------------------------------------------------------

    def add_module(
        self,
        name: str,
        description: str | None = None,
        parent: str | None = None,
        root_path: str | None = None,
        language: str | None = None,
        layer: str = "unknown",
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO modules (name, description, parent, root_path, language, layer)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(name) DO UPDATE SET
                    description=COALESCE(excluded.description, modules.description),
                    parent=COALESCE(excluded.parent, modules.parent),
                    root_path=COALESCE(excluded.root_path, modules.root_path),
                    language=COALESCE(excluded.language, modules.language),
                    layer=excluded.layer,
                    updated_at=datetime('now')
                """,
                (name, description, parent, root_path, language, layer),
            )

    def get_modules(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM modules ORDER BY node_count DESC"
        ).fetchall()
        return _rows_to_dicts(rows)

    def infer_module(self, file_path: str) -> str:
        """Return the top-level directory as module name.

        Known source prefixes are skipped to avoid everything landing in ``src``.
        """
        skip = {"src", "app", "lib", "source"}
        parts = Path(file_path).parts
        for part in parts:
            if part in skip or part.startswith("."):
                continue
            return part
        return "root"

    def update_module_coupling(self) -> None:
        """Recompute coupling_score for every module based on cross-module edges.

        Coupling = edges leaving the module / total edges involving the module.
        Values near 1.0 mean the module is highly externally dependent.
        """
        with self.conn:
            modules = [r["name"] for r in self.conn.execute("SELECT name FROM modules")]
            for mod in modules:
                total = self.conn.execute(
                    """
                    SELECT COUNT(*) FROM edges e
                    JOIN nodes ns ON ns.id = e.source_id
                    JOIN nodes nt ON nt.id = e.target_id
                    WHERE ns.module = ? OR nt.module = ?
                    """,
                    (mod, mod),
                ).fetchone()[0]
                cross = self.conn.execute(
                    """
                    SELECT COUNT(*) FROM edges e
                    JOIN nodes ns ON ns.id = e.source_id
                    JOIN nodes nt ON nt.id = e.target_id
                    WHERE ns.module = ? AND nt.module != ?
                    """,
                    (mod, mod),
                ).fetchone()[0]
                score = (cross / total) if total else 0.0
                self.conn.execute(
                    "UPDATE modules SET coupling_score = ?, edge_count = ? WHERE name = ?",
                    (round(score, 3), total, mod),
                )

    # ------------------------------------------------------------------
    # Queries de grafo
    # ------------------------------------------------------------------

    def impact_analysis(self, node_id: str, max_depth: int = 3) -> dict[int, list[dict[str, Any]]]:
        """Return a depth-grouped map of nodes transitively reachable from ``node_id``.

        Uses a recursive CTE with path-tracking to prevent cycles. Node IDs are
        wrapped with ``|...|`` delimiters inside ``path`` so substring matching
        does not produce false positives on hierarchical IDs (e.g.
        ``foo.Class`` vs ``foo.Class.method``). Output::

            {1: [{'node_id': ..., 'relation': ...}, ...], 2: [...], ...}
        """
        seed_path = f"|{node_id}|"
        sql = """
        WITH RECURSIVE impact(node_id, depth, path, relation) AS (
            SELECT ?, 0, ?, 'root'
            UNION ALL
            SELECT e.target_id, i.depth + 1,
                   i.path || e.target_id || '|', e.relation
            FROM impact i
            JOIN edges e ON e.source_id = i.node_id
            WHERE i.depth < ?
              AND i.path NOT LIKE '%|' || e.target_id || '|%'
        )
        SELECT node_id, depth, relation FROM impact WHERE depth > 0
        """
        rows = self.conn.execute(sql, (node_id, seed_path, max_depth)).fetchall()
        levels: dict[int, list[dict[str, Any]]] = {}
        for r in rows:
            levels.setdefault(r["depth"], []).append(
                {"node_id": r["node_id"], "relation": r["relation"]}
            )
        return levels

    def reverse_impact(self, node_id: str, max_depth: int = 3) -> dict[int, list[dict[str, Any]]]:
        """What currently *depends on* ``node_id`` (inverse of impact_analysis)."""
        seed_path = f"|{node_id}|"
        sql = """
        WITH RECURSIVE impact(node_id, depth, path, relation) AS (
            SELECT ?, 0, ?, 'root'
            UNION ALL
            SELECT e.source_id, i.depth + 1,
                   i.path || e.source_id || '|', e.relation
            FROM impact i
            JOIN edges e ON e.target_id = i.node_id
            WHERE i.depth < ?
              AND i.path NOT LIKE '%|' || e.source_id || '|%'
        )
        SELECT node_id, depth, relation FROM impact WHERE depth > 0
        """
        rows = self.conn.execute(sql, (node_id, seed_path, max_depth)).fetchall()
        levels: dict[int, list[dict[str, Any]]] = {}
        for r in rows:
            levels.setdefault(r["depth"], []).append(
                {"node_id": r["node_id"], "relation": r["relation"]}
            )
        return levels

    def get_context(self, file_path: str) -> dict[str, Any]:
        """Return the minimal set of files needed to understand or modify ``file_path``.

        Pulls: the file's own nodes, direct imports (out), direct importers (in),
        and sibling files in the same module.
        """
        own_nodes = self.get_nodes_by_file(file_path)
        module = own_nodes[0]["module"] if own_nodes else self.infer_module(file_path)

        deps: set[str] = set()
        dependents: set[str] = set()
        for node in own_nodes:
            for edge in self.get_edges(node["id"], direction="out"):
                target = self.get_node(edge["target_id"])
                if target and target.get("file_path") and target["file_path"] != file_path:
                    deps.add(target["file_path"])
            for edge in self.get_edges(node["id"], direction="in"):
                source = self.get_node(edge["source_id"])
                if source and source.get("file_path") and source["file_path"] != file_path:
                    dependents.add(source["file_path"])

        siblings = [
            n["file_path"]
            for n in self.get_nodes_by_module(module)
            if n["file_path"] and n["file_path"] != file_path
        ]

        return {
            "file_path": file_path,
            "module": module,
            "own_nodes": own_nodes,
            "dependencies": sorted(deps),
            "dependents": sorted(dependents),
            "siblings": sorted(set(siblings))[:10],
        }

    def get_god_nodes(self, min_connections: int = 10) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM god_nodes WHERE total_connections >= ?",
            (min_connections,),
        ).fetchall()
        return _rows_to_dicts(rows)

    def get_orphan_nodes(self) -> list[dict[str, Any]]:
        """Nodes with zero edges — potentially dead code."""
        rows = self.conn.execute(
            """
            SELECT n.* FROM nodes n
            LEFT JOIN edges e1 ON e1.source_id = n.id
            LEFT JOIN edges e2 ON e2.target_id = n.id
            WHERE e1.id IS NULL AND e2.id IS NULL
              AND n.kind IN ('function', 'class', 'method', 'component', 'endpoint')
            """
        ).fetchall()
        return _rows_to_dicts(rows)

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def get_stats(self) -> dict[str, Any]:
        """Return counts for the graph.

        ``nodes`` and ``by_kind`` exclude placeholder ``module_node`` rows with no
        ``file_path`` — those exist only to satisfy FK constraints on unresolved
        imports and would otherwise drown out real counts. ``nodes_total`` keeps
        the raw figure for anyone who cares.
        """

        def count(sql: str) -> int:
            return int(self.conn.execute(sql).fetchone()[0])

        real_where = "kind != 'module_node' OR file_path IS NOT NULL"
        return {
            "nodes": count(f"SELECT COUNT(*) FROM nodes WHERE {real_where}"),
            "nodes_total": count("SELECT COUNT(*) FROM nodes"),
            "edges": count("SELECT COUNT(*) FROM edges"),
            "modules": count("SELECT COUNT(*) FROM modules"),
            "patterns": count("SELECT COUNT(*) FROM patterns"),
            "patterns_confirmed": count(
                "SELECT COUNT(*) FROM patterns WHERE status = 'confirmed'"
            ),
            "conventions": count("SELECT COUNT(*) FROM conventions"),
            "inconsistencies_open": count(
                "SELECT COUNT(*) FROM inconsistencies WHERE status = 'open'"
            ),
            "sessions": count("SELECT COUNT(*) FROM sessions"),
            "by_kind": {
                r["kind"]: r["c"]
                for r in self.conn.execute(
                    f"""
                    SELECT kind, COUNT(*) AS c FROM nodes
                    WHERE {real_where}
                    GROUP BY kind ORDER BY c DESC
                    """
                )
            },
            "by_language": {
                r["language"]: r["c"]
                for r in self.conn.execute(
                    "SELECT language, COUNT(*) AS c FROM nodes WHERE language IS NOT NULL GROUP BY language"
                )
            },
        }

    # ------------------------------------------------------------------
    # Patrones / Convenciones
    # ------------------------------------------------------------------

    def add_pattern(
        self,
        id: str,
        category: str,
        name: str,
        description: str,
        evidence: list[dict[str, Any]],
        confidence: float,
        rule_text: str | None = None,
        occurrences: int = 0,
        exceptions: list[dict[str, Any]] | None = None,
        status: str = "candidate",
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO patterns
                    (id, category, name, description, evidence, confidence,
                     status, occurrences, exceptions, rule_text)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    evidence=excluded.evidence,
                    confidence=excluded.confidence,
                    occurrences=excluded.occurrences,
                    exceptions=excluded.exceptions,
                    rule_text=COALESCE(excluded.rule_text, patterns.rule_text),
                    updated_at=datetime('now')
                """,
                (id, category, name, description, json.dumps(evidence), confidence,
                 status, occurrences, json.dumps(exceptions or []), rule_text),
            )

    def add_convention(
        self,
        id: str,
        category: str,
        name: str,
        description: str,
        compliance: float,
        total_instances: int,
        compliant_count: int,
        rule_text: str | None = None,
        severity: str = "warning",
        status: str = "candidate",
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO conventions
                    (id, category, name, description, compliance, total_instances,
                     compliant_count, status, rule_text, severity)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    description=excluded.description,
                    compliance=excluded.compliance,
                    total_instances=excluded.total_instances,
                    compliant_count=excluded.compliant_count,
                    rule_text=COALESCE(excluded.rule_text, conventions.rule_text),
                    severity=excluded.severity,
                    updated_at=datetime('now')
                """,
                (id, category, name, description, compliance, total_instances,
                 compliant_count, status, rule_text, severity),
            )

    def add_inconsistency(
        self,
        rule_type: str,
        rule_id: str,
        file_path: str,
        description: str,
        node_id: str | None = None,
        line_number: int | None = None,
        expected: str | None = None,
        actual: str | None = None,
        severity: str = "warning",
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO inconsistencies
                    (rule_type, rule_id, node_id, file_path, line_number,
                     description, expected, actual, severity)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (rule_type, rule_id, node_id, file_path, line_number,
                 description, expected, actual, severity),
            )

    def get_patterns(self, status: str | None = None) -> list[dict[str, Any]]:
        if status:
            rows = self.conn.execute(
                "SELECT * FROM patterns WHERE status = ? ORDER BY confidence DESC", (status,)
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM patterns ORDER BY confidence DESC"
            ).fetchall()
        return _rows_to_dicts(rows)

    def get_conventions(self, status: str | None = None) -> list[dict[str, Any]]:
        if status:
            rows = self.conn.execute(
                "SELECT * FROM conventions WHERE status = ? ORDER BY compliance DESC", (status,)
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM conventions ORDER BY compliance DESC"
            ).fetchall()
        return _rows_to_dicts(rows)

    def get_inconsistencies(
        self, status: str = "open", file_path: str | None = None
    ) -> list[dict[str, Any]]:
        if file_path:
            rows = self.conn.execute(
                "SELECT * FROM inconsistencies WHERE status = ? AND file_path = ? ORDER BY severity DESC",
                (status, file_path),
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM inconsistencies WHERE status = ? ORDER BY detected_at DESC",
                (status,),
            ).fetchall()
        return _rows_to_dicts(rows)

    def clear_inconsistencies_for_file(self, file_path: str) -> int:
        """Remove open inconsistencies for a file before re-running detectors."""
        with self.conn:
            cur = self.conn.execute(
                "DELETE FROM inconsistencies WHERE file_path = ? AND status = 'open'",
                (file_path,),
            )
            return cur.rowcount

    def confirm_pattern(self, pattern_id: str) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE patterns SET status = 'confirmed',
                    confirmed_at = datetime('now'), updated_at = datetime('now')
                WHERE id = ?
                """,
                (pattern_id,),
            )

    def discard_pattern(self, pattern_id: str) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE patterns SET status = 'discarded', updated_at = datetime('now') WHERE id = ?",
                (pattern_id,),
            )

    # ------------------------------------------------------------------
    # Sesiones
    # ------------------------------------------------------------------

    def start_session(self, task_type: str = "unknown") -> str:
        session_id = uuid.uuid4().hex[:16]
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO sessions (id, task_type, modules_touched, files_created,
                                      files_modified, files_deleted)
                VALUES (?, ?, '[]', '[]', '[]', '[]')
                """,
                (session_id, task_type),
            )
        return session_id

    def end_session(self, session_id: str, summary: str | None = None) -> None:
        with self.conn:
            self.conn.execute(
                """
                UPDATE sessions SET
                    ended_at = datetime('now'),
                    duration_seconds = CAST((julianday('now') - julianday(started_at)) * 86400 AS INTEGER),
                    summary = ?
                WHERE id = ?
                """,
                (summary, session_id),
            )

    def record_action(
        self,
        session_id: str,
        action_type: str,
        file_path: str | None = None,
        node_id: str | None = None,
        context_injected: str | None = None,
        context_tokens: int | None = None,
        inconsistencies_detected: int = 0,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO session_actions
                    (session_id, action_type, file_path, node_id,
                     context_injected, context_tokens, inconsistencies_detected)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (session_id, action_type, file_path, node_id,
                 context_injected, context_tokens, inconsistencies_detected),
            )

    # ------------------------------------------------------------------
    # Context profiles
    # ------------------------------------------------------------------

    def get_context_profile(self, file_path: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM context_profiles WHERE file_path = ?", (file_path,)
        ).fetchone()
        return _row_to_dict(row)

    def update_context_profile(
        self,
        file_path: str,
        module: str | None = None,
        node_ids: list[str] | None = None,
        patterns_applicable: list[str] | None = None,
        conventions_applicable: list[str] | None = None,
        dependencies_summary: dict[str, Any] | None = None,
        coupling_score: float | None = None,
        change_risk: float | None = None,
    ) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO context_profiles
                    (file_path, module, node_ids, patterns_applicable,
                     conventions_applicable, dependencies_summary,
                     coupling_score, change_risk, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
                ON CONFLICT(file_path) DO UPDATE SET
                    module=COALESCE(excluded.module, context_profiles.module),
                    node_ids=COALESCE(excluded.node_ids, context_profiles.node_ids),
                    patterns_applicable=COALESCE(excluded.patterns_applicable, context_profiles.patterns_applicable),
                    conventions_applicable=COALESCE(excluded.conventions_applicable, context_profiles.conventions_applicable),
                    dependencies_summary=COALESCE(excluded.dependencies_summary, context_profiles.dependencies_summary),
                    coupling_score=COALESCE(excluded.coupling_score, context_profiles.coupling_score),
                    change_risk=COALESCE(excluded.change_risk, context_profiles.change_risk),
                    updated_at=datetime('now')
                """,
                (
                    file_path,
                    module,
                    json.dumps(node_ids) if node_ids is not None else None,
                    json.dumps(patterns_applicable) if patterns_applicable is not None else None,
                    json.dumps(conventions_applicable) if conventions_applicable is not None else None,
                    json.dumps(dependencies_summary) if dependencies_summary is not None else None,
                    coupling_score,
                    change_risk,
                ),
            )

    def bump_context_profile_modified(self, file_path: str, session_id: str | None = None) -> None:
        with self.conn:
            self.conn.execute(
                """
                INSERT INTO context_profiles (file_path, times_modified, last_modified, last_session, updated_at)
                VALUES (?, 1, datetime('now'), ?, datetime('now'))
                ON CONFLICT(file_path) DO UPDATE SET
                    times_modified = context_profiles.times_modified + 1,
                    last_modified = datetime('now'),
                    last_session = COALESCE(?, context_profiles.last_session),
                    updated_at = datetime('now')
                """,
                (file_path, session_id, session_id),
            )

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_json(self) -> dict[str, Any]:
        """Dump the whole graph plus patterns/conventions as a plain dict."""
        return {
            "nodes": [_row_to_dict(r) for r in self.conn.execute("SELECT * FROM nodes")],
            "edges": [_row_to_dict(r) for r in self.conn.execute("SELECT * FROM edges")],
            "modules": self.get_modules(),
            "patterns": self.get_patterns(),
            "conventions": self.get_conventions(),
            "inconsistencies": self.get_inconsistencies(status="open"),
            "stats": self.get_stats(),
        }
