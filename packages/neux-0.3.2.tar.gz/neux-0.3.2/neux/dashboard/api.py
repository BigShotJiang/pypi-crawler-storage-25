"""JSON endpoint handlers for the NEUX dashboard.

Each function receives an open :class:`GraphEngine`, optional path parameters
and query-string arguments, and returns a JSON-serialisable ``dict`` or
``list``. The HTTP wrapper in :mod:`neux.dashboard.server` maps URL paths to
these handlers and serialises the response.

Design goals:

* Pure functions of the engine (no global state, no side effects beyond the
  DB writes for ``confirm``/``discard``/``add_rule``).
* Shapes are stable so the React client can treat them as a contract.
* Exclude ``module_node`` placeholders (``file_path IS NULL``) from anything
  the UI shows — they exist only to satisfy FK constraints.
"""

from __future__ import annotations

import json
from typing import Any

from neux.engine import GraphEngine

MODULE_PALETTE: list[str] = [
    "#00e5ff",  # cyan
    "#ff00aa",  # magenta
    "#a4ff00",  # neon green
    "#ffae00",  # amber
    "#7b5bff",  # violet
    "#00ffa1",  # mint
    "#ff4b4b",  # red
    "#00b8ff",  # blue
    "#ffdd00",  # yellow
    "#ff6bd6",  # pink
]


def module_color(index: int) -> str:
    return MODULE_PALETTE[index % len(MODULE_PALETTE)]


def _row_to_dict(row: Any) -> dict[str, Any]:
    return {k: row[k] for k in row.keys()}


def _rows_to_dicts(rows: Any) -> list[dict[str, Any]]:
    return [_row_to_dict(r) for r in rows]


def _decode_metadata(raw: Any) -> Any:
    if raw is None:
        return None
    if isinstance(raw, (dict, list)):
        return raw
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None


def _clean_node(raw: dict[str, Any]) -> dict[str, Any]:
    out = dict(raw)
    out["metadata"] = _decode_metadata(out.get("metadata"))
    return out


# ======================================================================
# /api/overview
# ======================================================================


def overview(engine: GraphEngine) -> dict[str, Any]:
    """Return a compact snapshot of the project's current state."""
    stats = engine.get_stats()

    conventions = engine.get_conventions()
    avg_compliance = (
        sum((c.get("compliance") or 0) for c in conventions) / len(conventions)
        if conventions
        else 1.0
    )
    open_incs = stats["inconsistencies_open"]
    # Heuristic health score: start at 1, subtract compliance gap and scaled incidents.
    health_score = max(
        0.0,
        min(1.0, avg_compliance - min(open_incs, 50) / 100),
    )

    god_nodes = engine.get_god_nodes()[:10]
    recent_incs = engine.get_inconsistencies(status="open")[:10]

    recent_sessions_rows = engine.conn.execute(
        """
        SELECT id, started_at, ended_at, duration_seconds, task_type,
               files_created, files_modified, files_deleted, patterns_violated
        FROM sessions
        ORDER BY started_at DESC
        LIMIT 8
        """
    ).fetchall()
    recent_sessions = [_row_to_dict(r) for r in recent_sessions_rows]

    modules = _modules_with_color(engine)

    return {
        "stats": stats,
        "health_score": round(health_score, 3),
        "average_compliance": round(avg_compliance, 3),
        "god_nodes": god_nodes,
        "recent_inconsistencies": recent_incs,
        "recent_sessions": recent_sessions,
        "modules": modules,
    }


# ======================================================================
# /api/graph
# ======================================================================


def graph(engine: GraphEngine, module_filter: str | None = None) -> dict[str, Any]:
    """Return full nodes + edges for D3 rendering.

    Placeholders are excluded. Each node ships with a ``connections`` count so
    the frontend can size it without running its own query.
    """
    where = "(kind != 'module_node' OR file_path IS NOT NULL)"
    params: tuple[Any, ...] = ()
    if module_filter:
        where += " AND module = ?"
        params = (module_filter,)

    node_rows = engine.conn.execute(
        f"""
        SELECT n.*,
               (SELECT COUNT(*) FROM edges e WHERE e.source_id = n.id OR e.target_id = n.id)
                 AS connections
        FROM nodes n
        WHERE {where}
        """,
        params,
    ).fetchall()
    real_ids = {r["id"] for r in node_rows}

    edge_rows = engine.conn.execute(
        "SELECT source_id, target_id, relation, weight, confidence FROM edges"
    ).fetchall()
    edges = [
        {
            "source": r["source_id"],
            "target": r["target_id"],
            "relation": r["relation"],
            "weight": r["weight"],
            "confidence": r["confidence"],
        }
        for r in edge_rows
        if r["source_id"] in real_ids and r["target_id"] in real_ids
    ]

    nodes = []
    for r in node_rows:
        nodes.append(
            {
                "id": r["id"],
                "name": r["name"],
                "kind": r["kind"],
                "module": r["module"],
                "file_path": r["file_path"],
                "language": r["language"],
                "line_start": r["line_start"],
                "line_end": r["line_end"],
                "connections": r["connections"],
            }
        )

    return {
        "nodes": nodes,
        "edges": edges,
        "modules": _modules_with_color(engine),
    }


def graph_impact(
    engine: GraphEngine, node_id: str, depth: int = 3, direction: str = "forward"
) -> dict[str, Any]:
    node = engine.get_node(node_id)
    if node is None:
        return {"error": f"node '{node_id}' not found"}
    walker = engine.reverse_impact if direction == "reverse" else engine.impact_analysis
    levels = walker(node_id, max_depth=depth)
    # Attach names / files for each touched node
    hydrated: dict[str, list[dict[str, Any]]] = {}
    reachable = 0
    for depth_key, items in levels.items():
        out = []
        for item in items:
            target = engine.get_node(item["node_id"])
            out.append(
                {
                    "id": item["node_id"],
                    "relation": item["relation"],
                    "name": (target or {}).get("name"),
                    "kind": (target or {}).get("kind"),
                    "module": (target or {}).get("module"),
                    "file_path": (target or {}).get("file_path"),
                }
            )
            reachable += 1
        hydrated[str(depth_key)] = out
    return {
        "target": {
            "id": node["id"],
            "name": node["name"],
            "kind": node["kind"],
            "module": node.get("module"),
            "file_path": node.get("file_path"),
        },
        "direction": direction,
        "depth": depth,
        "levels": hydrated,
        "reachable_count": reachable,
    }


# ======================================================================
# /api/patterns /api/conventions /api/inconsistencies
# ======================================================================


def patterns(engine: GraphEngine, status: str | None = None) -> dict[str, Any]:
    items = engine.get_patterns(status=status)
    for it in items:
        it["evidence"] = _decode_metadata(it.get("evidence"))
        it["exceptions"] = _decode_metadata(it.get("exceptions"))
    counts = {
        row["status"]: row["c"]
        for row in engine.conn.execute(
            "SELECT status, COUNT(*) AS c FROM patterns GROUP BY status"
        )
    }
    return {"items": items, "counts": counts}


def conventions(engine: GraphEngine, status: str | None = None) -> dict[str, Any]:
    items = engine.get_conventions(status=status)
    counts = {
        row["status"]: row["c"]
        for row in engine.conn.execute(
            "SELECT status, COUNT(*) AS c FROM conventions GROUP BY status"
        )
    }
    return {"items": items, "counts": counts}


def inconsistencies(engine: GraphEngine, status: str = "open") -> dict[str, Any]:
    items = engine.get_inconsistencies(status=status)
    counts = {
        row["status"]: row["c"]
        for row in engine.conn.execute(
            "SELECT status, COUNT(*) AS c FROM inconsistencies GROUP BY status"
        )
    }
    severity_counts = {
        row["severity"]: row["c"]
        for row in engine.conn.execute(
            "SELECT severity, COUNT(*) AS c FROM inconsistencies WHERE status = 'open' GROUP BY severity"
        )
    }
    return {"items": items, "counts": counts, "by_severity": severity_counts}


# ======================================================================
# /api/modules
# ======================================================================


def modules(engine: GraphEngine) -> list[dict[str, Any]]:
    return _modules_with_color(engine)


def module_detail(engine: GraphEngine, name: str) -> dict[str, Any] | None:
    module_row = engine.conn.execute(
        "SELECT * FROM modules WHERE name = ?", (name,)
    ).fetchone()
    if module_row is None:
        return None
    module = _row_to_dict(module_row)

    # Files in this module
    file_rows = engine.conn.execute(
        """
        SELECT file_path, COUNT(*) AS node_count,
               GROUP_CONCAT(DISTINCT kind) AS kinds
        FROM nodes
        WHERE module = ? AND file_path IS NOT NULL
        GROUP BY file_path
        ORDER BY node_count DESC
        LIMIT 50
        """,
        (name,),
    ).fetchall()
    files = [
        {
            "path": r["file_path"],
            "node_count": r["node_count"],
            "kinds": r["kinds"].split(",") if r["kinds"] else [],
        }
        for r in file_rows
    ]

    # Dependencies to other modules
    dep_rows = engine.conn.execute(
        """
        SELECT nt.module AS target_module, COUNT(*) AS edge_count
        FROM edges e
        JOIN nodes ns ON ns.id = e.source_id
        JOIN nodes nt ON nt.id = e.target_id
        WHERE ns.module = ? AND nt.module IS NOT NULL AND nt.module != ?
        GROUP BY nt.module
        ORDER BY edge_count DESC
        """,
        (name, name),
    ).fetchall()
    dependencies = [_row_to_dict(r) for r in dep_rows]

    # Patterns / conventions flagged against this module's files
    module_patterns = []
    for p in engine.get_patterns():
        evidence = _decode_metadata(p.get("evidence")) or []
        if any(_evidence_touches_module(e, name) for e in evidence if isinstance(e, dict)):
            module_patterns.append(p)

    module_inconsistencies = engine.conn.execute(
        """
        SELECT i.* FROM inconsistencies i
        LEFT JOIN nodes n ON i.node_id = n.id
        WHERE i.status = 'open' AND n.module = ?
        ORDER BY i.severity DESC
        LIMIT 50
        """,
        (name,),
    ).fetchall()

    god_nodes = [g for g in engine.get_god_nodes(min_connections=5) if g["module"] == name][:10]

    return {
        "module": module,
        "files": files,
        "dependencies": dependencies,
        "patterns": module_patterns,
        "inconsistencies": _rows_to_dicts(module_inconsistencies),
        "god_nodes": god_nodes,
    }


def _evidence_touches_module(evidence: dict, module: str) -> bool:
    # Evidence blobs vary by detector; look for module-tagged references.
    for val in evidence.values():
        if isinstance(val, str) and module in val:
            return True
        if isinstance(val, list) and any(
            isinstance(x, str) and module in x for x in val
        ):
            return True
    return False


# ======================================================================
# /api/sessions
# ======================================================================


def sessions(engine: GraphEngine, project_root: str | None = None) -> dict[str, Any]:
    rows = engine.conn.execute(
        """
        SELECT * FROM sessions
        ORDER BY started_at DESC
        LIMIT 50
        """
    ).fetchall()
    items = [_row_to_dict(r) for r in rows]

    trend_rows = engine.conn.execute(
        """
        SELECT DATE(started_at) AS day, COUNT(*) AS count
        FROM sessions
        WHERE started_at > datetime('now', '-30 days')
        GROUP BY day
        ORDER BY day
        """
    ).fetchall()
    by_day = [_row_to_dict(r) for r in trend_rows]

    tokens_rows = engine.conn.execute(
        """
        SELECT DATE(started_at) AS day, SUM(tokens_context_injected) AS total
        FROM sessions
        WHERE started_at > datetime('now', '-30 days')
        GROUP BY day
        ORDER BY day
        """
    ).fetchall()
    tokens_saved = [_row_to_dict(r) for r in tokens_rows]

    violations_rows = engine.conn.execute(
        """
        SELECT id, patterns_violated
        FROM sessions
        ORDER BY started_at DESC
        LIMIT 30
        """
    ).fetchall()
    inconsistencies_by_session = [_row_to_dict(r) for r in violations_rows]

    # ANVL integration — enrich with token metrics if available
    from neux.anvl_bridge import get_active_session_metrics, get_project_sessions, is_available
    from pathlib import Path

    anvl_data: dict[str, Any] = {"available": is_available()}
    if is_available():
        cwd = Path(project_root) if project_root else None
        anvl_data["active_session"] = get_active_session_metrics(cwd)
        anvl_data["project_sessions"] = get_project_sessions(cwd)

    return {
        "items": items,
        "trends": {
            "by_day": by_day,
            "tokens_saved": tokens_saved,
            "inconsistencies_by_session": inconsistencies_by_session,
        },
        "anvl": anvl_data,
    }


# ======================================================================
# Mutations
# ======================================================================


def confirm_pattern(engine: GraphEngine, pattern_id: str) -> dict[str, Any]:
    engine.confirm_pattern(pattern_id)
    return {"ok": True, "id": pattern_id, "status": "confirmed"}


def discard_pattern(engine: GraphEngine, pattern_id: str) -> dict[str, Any]:
    engine.discard_pattern(pattern_id)
    return {"ok": True, "id": pattern_id, "status": "discarded"}


def confirm_convention(engine: GraphEngine, convention_id: str) -> dict[str, Any]:
    with engine.conn:
        engine.conn.execute(
            """
            UPDATE conventions SET status = 'confirmed',
                confirmed_at = datetime('now'), updated_at = datetime('now')
            WHERE id = ?
            """,
            (convention_id,),
        )
    return {"ok": True, "id": convention_id, "status": "confirmed"}


def discard_convention(engine: GraphEngine, convention_id: str) -> dict[str, Any]:
    with engine.conn:
        engine.conn.execute(
            "UPDATE conventions SET status = 'discarded' WHERE id = ?",
            (convention_id,),
        )
    return {"ok": True, "id": convention_id, "status": "discarded"}


def add_rule(engine: GraphEngine, body: dict[str, Any]) -> dict[str, Any]:
    import uuid

    description = body.get("description") or body.get("rule_text") or ""
    if not description:
        return {"error": "description is required"}
    category = body.get("category", "architecture")
    rule_text = body.get("rule_text") or description
    rid = f"manual_{uuid.uuid4().hex[:10]}"
    engine.add_pattern(
        id=rid,
        category=category,
        name=rid,
        description=description,
        evidence=[{"source": "manual"}],
        confidence=1.0,
        rule_text=rule_text,
        status="confirmed",
    )
    return {"ok": True, "id": rid}


# ======================================================================
# Helpers
# ======================================================================


def _modules_with_color(engine: GraphEngine) -> list[dict[str, Any]]:
    mods = engine.get_modules()
    for i, m in enumerate(mods):
        m["color"] = module_color(i)
    return mods
