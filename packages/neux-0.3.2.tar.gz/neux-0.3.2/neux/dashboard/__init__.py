"""HTTP dashboard: static React build + JSON API served from stdlib http.server."""
