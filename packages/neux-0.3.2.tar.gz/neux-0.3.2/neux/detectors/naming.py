"""NamingDetector — convention checks per language and node kind.

Rules enforced:

* **Python** functions / methods: ``snake_case``
* **Python** classes: ``PascalCase``
* **TypeScript** React components: ``PascalCase``
* **TypeScript** functions (non-component): ``camelCase``
* **SQL** tables / columns: ``snake_case``

Any node failing its rule becomes an ``inconsistency``. If ≥ ``min_sample_size``
conforming nodes exist the rule is also persisted as a ``convention`` with its
compliance ratio.
"""

from __future__ import annotations

import re
from typing import Any

from neux.detectors.base import (
    BaseDetector,
    DetectionContext,
    DetectionResult,
    InconsistencyRecord,
)

SNAKE_CASE = re.compile(r"^_?[a-z][a-z0-9_]*$")
PASCAL_CASE = re.compile(r"^[A-Z][A-Za-z0-9]*$")
CAMEL_CASE = re.compile(r"^[a-z][A-Za-z0-9]*$")
DUNDER = re.compile(r"^__[a-z_]+__$")

# Names that look like snake_case violations but are required by frameworks.
# ast.NodeVisitor requires visit_<NodeType>, BaseHTTPRequestHandler requires do_<METHOD>.
_FRAMEWORK_METHOD_RE = re.compile(r"^(visit_[A-Z]\w*|do_[A-Z]+)$")

# Private classes with a leading underscore followed by PascalCase are idiomatic
# Python for module-internal helpers (e.g. _PyVisitor, _NullStats).
_PRIVATE_CLASS_RE = re.compile(r"^_[A-Z][A-Za-z0-9]*$")


class NamingDetector(BaseDetector):
    name = "naming"
    languages = ["python", "typescript", "javascript", "sql"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        results: list[DetectionResult] = []

        python_fns, py_fn_bad = _check(
            ctx.nodes,
            match=lambda n: n["language"] == "python"
            and n["kind"] in {"function", "method", "endpoint"},
            is_ok=lambda name: (
                DUNDER.match(name)
                or SNAKE_CASE.match(name)
                or _FRAMEWORK_METHOD_RE.match(name)
            ),
        )
        results.append(
            _make(
                "naming",
                "python_snake_case_functions",
                "Python functions and methods use snake_case",
                rule_text="Python functions and methods MUST use snake_case.",
                total=python_fns,
                bad=py_fn_bad,
                expected="snake_case",
            )
        )

        py_classes, py_cls_bad = _check(
            ctx.nodes,
            match=lambda n: n["language"] == "python" and n["kind"] == "class",
            is_ok=lambda name: PASCAL_CASE.match(name) or _PRIVATE_CLASS_RE.match(name),
        )
        results.append(
            _make(
                "naming",
                "python_pascal_case_classes",
                "Python classes use PascalCase",
                rule_text="Python classes MUST use PascalCase.",
                total=py_classes,
                bad=py_cls_bad,
                expected="PascalCase",
            )
        )

        ts_components, ts_comp_bad = _check(
            ctx.nodes,
            match=lambda n: n["language"] in {"typescript", "javascript"} and n["kind"] == "component",
            is_ok=lambda name: PASCAL_CASE.match(name),
        )
        results.append(
            _make(
                "naming",
                "tsx_pascal_case_components",
                "React components use PascalCase",
                rule_text="React components MUST use PascalCase names.",
                total=ts_components,
                bad=ts_comp_bad,
                expected="PascalCase",
            )
        )

        ts_fns, ts_fn_bad = _check(
            ctx.nodes,
            match=lambda n: n["language"] in {"typescript", "javascript"}
            and n["kind"] in {"function", "method"}
            and not PASCAL_CASE.match(n["name"] or ""),
            is_ok=lambda name: CAMEL_CASE.match(name),
        )
        results.append(
            _make(
                "naming",
                "ts_camel_case_functions",
                "TypeScript functions use camelCase",
                rule_text="TypeScript regular functions MUST use camelCase.",
                total=ts_fns,
                bad=ts_fn_bad,
                expected="camelCase",
            )
        )

        sql_tables, sql_tbl_bad = _check(
            ctx.nodes,
            match=lambda n: n["language"] == "sql" and n["kind"] == "table",
            is_ok=lambda name: SNAKE_CASE.match(name),
        )
        results.append(
            _make(
                "naming",
                "sql_snake_case_tables",
                "SQL table names use snake_case",
                rule_text="SQL table names MUST use snake_case.",
                total=sql_tables,
                bad=sql_tbl_bad,
                expected="snake_case",
            )
        )

        return [r for r in results if r.total_instances >= self.min_sample_size or r.inconsistencies]


def _check(
    nodes: list[dict[str, Any]],
    match,
    is_ok,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    matched = [n for n in nodes if match(n)]
    bad = [n for n in matched if not is_ok(n["name"] or "")]
    return matched, bad


def _make(
    category: str,
    name: str,
    description: str,
    rule_text: str,
    total: list[dict[str, Any]],
    bad: list[dict[str, Any]],
    expected: str,
) -> DetectionResult:
    total_n = len(total)
    good_n = total_n - len(bad)
    compliance = (good_n / total_n) if total_n else 1.0
    incs = [
        InconsistencyRecord(
            file_path=n["file_path"] or "",
            description=f"{n['name']} should be {expected}",
            expected=expected,
            actual=n["name"],
            line_number=n.get("line_start"),
            node_id=n["id"],
            severity="warning",
        )
        for n in bad
    ]
    return DetectionResult(
        type="convention",
        category=category,
        name=name,
        description=description,
        confidence=compliance,
        compliance=round(compliance, 3),
        total_instances=total_n,
        compliant_count=good_n,
        rule_text=rule_text,
        evidence=[{"sample": len(total), "violations": len(bad)}],
        inconsistencies=incs,
    )
