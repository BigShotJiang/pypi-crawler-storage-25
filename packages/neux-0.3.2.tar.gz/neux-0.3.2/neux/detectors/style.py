"""StyleDetector — theme usage, hardcoded colors, CSS methodology."""

from __future__ import annotations

import re
from typing import Any

from neux.detectors.base import (
    BaseDetector,
    DetectionContext,
    DetectionResult,
    InconsistencyRecord,
)

HEX_COLOR_RE = re.compile(r"#[0-9a-fA-F]{3,8}\b")
RGB_COLOR_RE = re.compile(r"\brgba?\(\s*\d")
HSL_COLOR_RE = re.compile(r"\bhsla?\(\s*\d")

THEME_FILE_HINTS: tuple[str, ...] = (
    "theme.ts", "theme.tsx", "theme.js", "colors.js",
    "tailwind.config.js", "tailwind.config.ts", "tailwind.config.cjs", "tailwind.config.mjs",
    "variables.css", "tokens.css", "index.css",
    "_variables.scss", "theme.scss",
)

STYLE_FILE_EXTS: set[str] = {".css", ".scss", ".sass", ".less", ".styl", ".ts", ".tsx", ".js", ".jsx"}


class StyleDetector(BaseDetector):
    name = "style"
    languages = ["*"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        results: list[DetectionResult] = []

        theme_files = [p for p in ctx.files if any(p.endswith(h) for h in THEME_FILE_HINTS)]
        has_tailwind = any("tailwind.config" in p for p in theme_files)

        hardcoded: list[InconsistencyRecord] = []
        total_color_mentions = 0
        for path, content in ctx.files.items():
            ext = "." + path.rsplit(".", 1)[-1] if "." in path else ""
            if ext not in STYLE_FILE_EXTS:
                continue
            if path in theme_files:
                continue
            for line_no, line in enumerate(content.splitlines(), start=1):
                stripped = line.strip()
                if not stripped or stripped.startswith(("//", "/*", "*", "#")):
                    continue
                hits = _count_hits(stripped)
                if not hits:
                    continue
                total_color_mentions += hits
                hardcoded.append(
                    InconsistencyRecord(
                        file_path=path,
                        line_number=line_no,
                        description="Hardcoded color value in source; use theme tokens instead",
                        actual=stripped[:80],
                        expected="theme token / tailwind class",
                        severity="warning",
                    )
                )
                if len(hardcoded) >= 200:
                    break
            if len(hardcoded) >= 200:
                break

        if theme_files or hardcoded:
            compliance = 1.0
            if total_color_mentions:
                compliance = max(0.0, 1 - (len(hardcoded) / max(total_color_mentions, 1)))
            results.append(
                DetectionResult(
                    type="convention",
                    category="ui_style",
                    name="centralized_theme_tokens",
                    description=(
                        "Use centralized theme tokens / Tailwind utilities "
                        "instead of hardcoded color literals"
                    ),
                    confidence=0.9 if theme_files else 0.6,
                    compliance=round(compliance, 3),
                    total_instances=total_color_mentions,
                    compliant_count=max(0, total_color_mentions - len(hardcoded)),
                    rule_text=(
                        "Never hardcode colors in component files. "
                        + ("Use Tailwind utilities and extend the theme config for brand colors."
                           if has_tailwind
                           else "Reference shared design tokens defined in your theme file.")
                    ),
                    evidence=[{"theme_files": theme_files, "hardcoded_count": len(hardcoded)}],
                    inconsistencies=hardcoded,
                    severity="warning",
                )
            )

        if has_tailwind:
            results.append(
                DetectionResult(
                    type="pattern",
                    category="ui_style",
                    name="tailwind_css",
                    description="Project uses Tailwind CSS as primary styling method",
                    confidence=1.0,
                    rule_text="Styling uses Tailwind utility classes. Avoid inline styles and styled-components.",
                    evidence=[{"config": theme_files}],
                )
            )
        return results


def _count_hits(line: str) -> int:
    return (
        len(HEX_COLOR_RE.findall(line))
        + len(RGB_COLOR_RE.findall(line))
        + len(HSL_COLOR_RE.findall(line))
    )
