"""DataAccessDetector — ORM vs raw SQL, transaction patterns."""

from __future__ import annotations

import json
from collections import Counter

from neux.detectors.base import BaseDetector, DetectionContext, DetectionResult

ORM_HINTS: dict[str, list[str]] = {
    "sqlalchemy": ["sqlalchemy", "SQLAlchemy"],
    "django_orm": ["django.db"],
    "prisma": ["@prisma/client", "prisma"],
    "drizzle": ["drizzle-orm"],
    "typeorm": ["typeorm"],
    "sequelize": ["sequelize"],
    "peewee": ["peewee"],
    "tortoise": ["tortoise"],
}


class DataAccessDetector(BaseDetector):
    name = "data_access"
    languages = ["*"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        orm_counts: Counter[str] = Counter()
        for edge in ctx.edges:
            if edge["relation"] != "imports":
                continue
            module = _edge_module(edge).lower()
            for orm, hints in ORM_HINTS.items():
                if any(h.lower() in module for h in hints):
                    orm_counts[orm] += 1
                    break

        raw_sql_count = sum(
            1 for e in ctx.edges
            if e["relation"] in {"reads_from", "writes_to", "mutates"}
        )

        results: list[DetectionResult] = []
        if orm_counts:
            orm, count = orm_counts.most_common(1)[0]
            results.append(
                DetectionResult(
                    type="pattern",
                    category="data_access",
                    name=f"orm_{orm}",
                    description=f"Data access goes through {orm}",
                    confidence=min(1.0, count / 5),
                    rule_text=(
                        f"Use {orm} for data access. Avoid mixing raw SQL with {orm} "
                        f"unless there's a performance reason (document it)."
                    ),
                    evidence=[dict(orm_counts)],
                    occurrences=count,
                )
            )
        elif raw_sql_count >= self.min_sample_size:
            results.append(
                DetectionResult(
                    type="pattern",
                    category="data_access",
                    name="raw_sql",
                    description="Data access uses raw SQL queries",
                    confidence=0.7,
                    rule_text=(
                        "Project uses raw SQL. Always parameterize queries — never interpolate "
                        "user input into SQL strings."
                    ),
                    evidence=[{"raw_sql_edges": raw_sql_count}],
                    occurrences=raw_sql_count,
                )
            )
        return results


def _edge_module(edge: dict) -> str:
    raw = edge.get("metadata")
    if not raw:
        return ""
    try:
        meta = json.loads(raw) if isinstance(raw, str) else raw
        return meta.get("module", "") if isinstance(meta, dict) else ""
    except (json.JSONDecodeError, TypeError):
        return ""
