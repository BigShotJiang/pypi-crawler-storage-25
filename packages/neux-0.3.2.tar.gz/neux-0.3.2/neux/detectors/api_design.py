"""APIDesignDetector — REST style, response shape conventions."""

from __future__ import annotations

import json
import re
from collections import Counter

from neux.detectors.base import BaseDetector, DetectionContext, DetectionResult

PLURAL_RE = re.compile(r"/(\w+?)(?:s|es|ies)(?:/|$)")


class APIDesignDetector(BaseDetector):
    name = "api_design"
    languages = ["python", "typescript", "javascript"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        endpoints = [n for n in ctx.nodes if n["kind"] == "endpoint"]
        if len(endpoints) < self.min_sample_size:
            return []

        methods: Counter[str] = Counter()
        paths: list[str] = []
        for n in endpoints:
            meta = _metadata(n)
            info = meta.get("endpoint", {}) if isinstance(meta, dict) else {}
            if isinstance(info, dict):
                method = info.get("method") or ""
                path = info.get("path") or ""
                if method:
                    methods[method] += 1
                if path:
                    paths.append(path)

        results: list[DetectionResult] = []

        total = len(paths)
        plural_hits = sum(1 for p in paths if _looks_plural(p))
        if total and plural_hits / total >= 0.7:
            results.append(
                DetectionResult(
                    type="convention",
                    category="api_design",
                    name="rest_plural_resources",
                    description="REST routes use plural resource names",
                    confidence=plural_hits / total,
                    compliance=round(plural_hits / total, 3),
                    total_instances=total,
                    compliant_count=plural_hits,
                    rule_text="Name REST resources in plural (/users, /orders) for collection endpoints.",
                    evidence=[{"plural": plural_hits, "total": total}],
                )
            )

        verb_in_path = sum(1 for p in paths if _has_verb(p))
        if verb_in_path / max(total, 1) > 0.3:
            results.append(
                DetectionResult(
                    type="pattern",
                    category="api_design",
                    name="rpc_style_routes",
                    description="Routes embed verbs (RPC-style) rather than pure REST",
                    confidence=0.7,
                    rule_text=(
                        "Project mixes REST and RPC route styles. Stick to HTTP verbs on plural "
                        "resources rather than /createUser, /getOrder paths."
                    ),
                    evidence=[{"with_verbs": verb_in_path, "total": total}],
                )
            )

        return results


def _metadata(node: dict) -> dict:
    raw = node.get("metadata")
    if not raw:
        return {}
    if isinstance(raw, dict):
        return raw
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return {}


def _looks_plural(path: str) -> bool:
    return bool(PLURAL_RE.search(path))


def _has_verb(path: str) -> bool:
    verbs = ("/create", "/get", "/update", "/delete", "/list", "/find")
    return any(v in path.lower() for v in verbs)
