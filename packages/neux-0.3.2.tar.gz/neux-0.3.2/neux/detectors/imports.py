"""ImportDetector — dominant import style + circular import detection."""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from neux.detectors.base import (
    BaseDetector,
    DetectionContext,
    DetectionResult,
    InconsistencyRecord,
)


class ImportDetector(BaseDetector):
    name = "imports"
    languages = ["python", "typescript", "javascript"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        results: list[DetectionResult] = []

        ts_import_edges = [
            e for e in ctx.edges
            if e["relation"] == "imports"
            and _source_is(ctx.nodes, e, lang_in={"typescript", "javascript"})
        ]
        if ts_import_edges:
            alias = 0
            relative = 0
            absolute = 0
            for e in ts_import_edges:
                raw = _edge_module(e)
                if not raw:
                    continue
                if raw.startswith("@") or raw.startswith("~"):
                    alias += 1
                elif raw.startswith("."):
                    relative += 1
                else:
                    absolute += 1
            total = alias + relative + absolute
            if total:
                dominant_count = max(alias, relative, absolute)
                dominant = "alias" if dominant_count == alias else (
                    "relative" if dominant_count == relative else "absolute"
                )
                compliance = dominant_count / total
                results.append(
                    DetectionResult(
                        type="convention",
                        category="imports",
                        name=f"ts_import_style_{dominant}",
                        description=f"TypeScript imports predominantly use {dominant} paths",
                        confidence=compliance,
                        compliance=round(compliance, 3),
                        total_instances=total,
                        compliant_count=dominant_count,
                        rule_text=(
                            f"Prefer {dominant} imports for TypeScript/React code "
                            f"({int(compliance*100)}% of current imports use this style)."
                        ),
                        evidence=[{"alias": alias, "relative": relative, "absolute": absolute}],
                    )
                )

        cycles = _find_cycles(ctx.nodes, ctx.edges)
        if cycles:
            incs = [
                InconsistencyRecord(
                    file_path=_node_file(ctx.nodes, cycle[0]),
                    description=f"Circular import: {' → '.join(cycle + [cycle[0]])}",
                    severity="error",
                )
                for cycle in cycles[:20]
            ]
            results.append(
                DetectionResult(
                    type="pattern",
                    category="imports",
                    name="circular_imports",
                    description=f"{len(cycles)} circular import chains detected",
                    confidence=1.0,
                    rule_text="Avoid circular imports. Extract shared interfaces to a separate module.",
                    evidence=[{"cycles": cycles[:20]}],
                    inconsistencies=incs,
                    occurrences=len(cycles),
                    severity="error",
                )
            )

        return results


def _source_is(nodes: list[dict[str, Any]], edge: dict[str, Any], lang_in: set[str]) -> bool:
    for n in nodes:
        if n["id"] == edge["source_id"]:
            return (n.get("language") or "") in lang_in
    return False


def _edge_module(edge: dict[str, Any]) -> str:
    import json
    raw = edge.get("metadata")
    if not raw:
        return ""
    try:
        meta = json.loads(raw) if isinstance(raw, str) else raw
        return meta.get("module", "") if isinstance(meta, dict) else ""
    except (json.JSONDecodeError, TypeError):
        return ""


def _node_file(nodes: list[dict[str, Any]], node_id: str) -> str:
    for n in nodes:
        if n["id"] == node_id:
            return n["file_path"] or ""
    return ""


def _find_cycles(
    nodes: list[dict[str, Any]], edges: list[dict[str, Any]], max_cycles: int = 50
) -> list[list[str]]:
    """Return up to ``max_cycles`` minimal circular chains in the imports subgraph.

    File-granularity cycles: each node in a cycle is a file path. This is the
    layer that actually hurts at import time in Python and at bundle time in JS.
    """
    file_by_id = {n["id"]: n["file_path"] for n in nodes if n["file_path"]}
    adj: dict[str, set[str]] = defaultdict(set)
    for e in edges:
        if e["relation"] != "imports":
            continue
        src = file_by_id.get(e["source_id"])
        tgt = file_by_id.get(e["target_id"])
        if src and tgt and src != tgt:
            adj[src].add(tgt)

    cycles: list[list[str]] = []
    visiting: set[str] = set()
    visited: set[str] = set()

    def dfs(path: list[str]) -> None:
        if len(cycles) >= max_cycles:
            return
        node = path[-1]
        visiting.add(node)
        for nxt in adj.get(node, ()):
            if nxt in visiting:
                start = path.index(nxt)
                cycles.append(path[start:])
                continue
            if nxt not in visited:
                dfs(path + [nxt])
        visiting.discard(node)
        visited.add(node)

    for root in list(adj.keys()):
        if root not in visited:
            dfs([root])
        if len(cycles) >= max_cycles:
            break
    return cycles
