"""Base classes for pattern / convention / inconsistency detectors."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class DetectionContext:
    """Everything a detector may need — pre-loaded to avoid DB churn.

    * ``nodes``: list of dicts as returned by GraphEngine (not objects).
    * ``edges``: same.
    * ``files``: mapping of relative file path → raw content. Only files the
      detector is likely to inspect are pre-loaded.
    * ``existing_patterns``: patterns already in the DB — detectors can refine
      them instead of re-emitting.
    * ``project_info``: stack description, language list, feature flags.
    """
    nodes: list[dict[str, Any]] = field(default_factory=list)
    edges: list[dict[str, Any]] = field(default_factory=list)
    files: dict[str, str] = field(default_factory=dict)
    existing_patterns: list[dict[str, Any]] = field(default_factory=list)
    project_info: dict[str, Any] = field(default_factory=dict)
    changed_files: list[str] | None = None


@dataclass(slots=True)
class InconsistencyRecord:
    file_path: str
    description: str
    expected: str | None = None
    actual: str | None = None
    line_number: int | None = None
    node_id: str | None = None
    severity: str = "warning"


@dataclass(slots=True)
class DetectionResult:
    """A pattern, convention, or both, optionally accompanied by inconsistencies."""
    type: str  # 'pattern' | 'convention'
    category: str
    name: str
    description: str
    confidence: float
    rule_text: str
    evidence: list[dict[str, Any]] = field(default_factory=list)
    exceptions: list[dict[str, Any]] = field(default_factory=list)
    inconsistencies: list[InconsistencyRecord] = field(default_factory=list)
    severity: str = "warning"
    id: str | None = None
    compliance: float | None = None
    total_instances: int = 0
    compliant_count: int = 0
    occurrences: int = 0


class BaseDetector(ABC):
    """Abstract detector. Subclasses override :meth:`detect`."""

    name: str = ""
    languages: list[str] = ["*"]
    min_sample_size: int = 3

    def applies_to(self, project_info: dict[str, Any]) -> bool:
        if self.languages == ["*"]:
            return True
        langs = set(project_info.get("languages", []))
        return bool(langs.intersection(self.languages))

    @abstractmethod
    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        """Return any patterns/conventions the detector identified in ``ctx``."""


class DetectionEngine:
    """Runs a list of detectors and persists their output through GraphEngine."""

    def __init__(self, detectors: list[BaseDetector]):
        self.detectors = detectors

    def run_all(self, ctx: DetectionContext) -> list[DetectionResult]:
        results: list[DetectionResult] = []
        applicable = [d for d in self.detectors if d.applies_to(ctx.project_info)]
        for detector in applicable:
            try:
                results.extend(detector.detect(ctx))
            except Exception as exc:  # never let one detector break the run
                results.append(
                    DetectionResult(
                        type="pattern",
                        category="architecture",
                        name=f"detector_error:{detector.name}",
                        description=f"Detector {detector.name} raised {type(exc).__name__}: {exc}",
                        confidence=0.0,
                        rule_text="",
                    )
                )
        return results

    def persist(self, engine: Any, results: list[DetectionResult]) -> None:
        """Write pattern/convention/inconsistency rows via the provided engine."""
        from neux.engine import GraphEngine  # local import avoids cycle

        assert isinstance(engine, GraphEngine)
        for r in results:
            rid = r.id or _slug(f"{r.type}:{r.category}:{r.name}")
            if r.type == "pattern":
                engine.add_pattern(
                    id=rid,
                    category=r.category,
                    name=r.name,
                    description=r.description,
                    evidence=r.evidence,
                    confidence=r.confidence,
                    rule_text=r.rule_text,
                    occurrences=r.occurrences,
                    exceptions=r.exceptions,
                )
            elif r.type == "convention":
                engine.add_convention(
                    id=rid,
                    category=r.category,
                    name=r.name,
                    description=r.description,
                    compliance=r.compliance if r.compliance is not None else 0.0,
                    total_instances=r.total_instances,
                    compliant_count=r.compliant_count,
                    rule_text=r.rule_text,
                    severity=r.severity,
                )
            for inc in r.inconsistencies:
                engine.add_inconsistency(
                    rule_type=r.type,
                    rule_id=rid,
                    file_path=inc.file_path,
                    description=inc.description,
                    node_id=inc.node_id,
                    line_number=inc.line_number,
                    expected=inc.expected,
                    actual=inc.actual,
                    severity=inc.severity,
                )


def _slug(raw: str) -> str:
    import re
    return re.sub(r"[^a-z0-9_]+", "_", raw.lower()).strip("_")
