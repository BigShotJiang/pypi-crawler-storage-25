"""Pattern and convention detectors that analyze the graph.

``ALL_DETECTORS`` is the canonical list that :class:`DetectionEngine` consumes
when no explicit list is passed.
"""

from neux.detectors.api_design import APIDesignDetector
from neux.detectors.base import (
    BaseDetector,
    DetectionContext,
    DetectionEngine,
    DetectionResult,
    InconsistencyRecord,
)
from neux.detectors.data_access import DataAccessDetector
from neux.detectors.error_handling import ErrorHandlingDetector
from neux.detectors.file_structure import FileStructureDetector
from neux.detectors.imports import ImportDetector
from neux.detectors.naming import NamingDetector
from neux.detectors.security import SecurityDetector
from neux.detectors.state_management import StateManagementDetector
from neux.detectors.style import StyleDetector
from neux.detectors.testing import TestingDetector
from neux.detectors.ui_component import UIComponentDetector


def all_detectors() -> list[BaseDetector]:
    """Instantiate every detector. Mutation-safe — callers may reorder."""
    return [
        NamingDetector(),
        ImportDetector(),
        SecurityDetector(),
        StyleDetector(),
        UIComponentDetector(),
        APIDesignDetector(),
        DataAccessDetector(),
        StateManagementDetector(),
        ErrorHandlingDetector(),
        FileStructureDetector(),
        TestingDetector(),
    ]


__all__ = [
    "BaseDetector",
    "DetectionContext",
    "DetectionEngine",
    "DetectionResult",
    "InconsistencyRecord",
    "NamingDetector",
    "ImportDetector",
    "SecurityDetector",
    "StyleDetector",
    "UIComponentDetector",
    "APIDesignDetector",
    "DataAccessDetector",
    "StateManagementDetector",
    "ErrorHandlingDetector",
    "FileStructureDetector",
    "TestingDetector",
    "all_detectors",
]
