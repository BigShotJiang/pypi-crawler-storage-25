"""TestingDetector — framework detection and coverage map by module."""

from __future__ import annotations

import json
from collections import Counter, defaultdict

from neux.detectors.base import BaseDetector, DetectionContext, DetectionResult

TEST_FRAMEWORKS: dict[str, list[str]] = {
    "pytest": ["pytest", "_pytest"],
    "unittest": ["unittest"],
    "jest": ["jest", "@types/jest"],
    "vitest": ["vitest"],
    "mocha": ["mocha"],
    "playwright": ["@playwright/test"],
    "cypress": ["cypress"],
}


class TestingDetector(BaseDetector):
    name = "testing"
    languages = ["*"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        framework_hits: Counter[str] = Counter()
        for edge in ctx.edges:
            if edge["relation"] != "imports":
                continue
            module = _edge_module(edge).lower()
            for fw, hints in TEST_FRAMEWORKS.items():
                if any(h.lower() in module for h in hints):
                    framework_hits[fw] += 1
                    break

        test_nodes = [n for n in ctx.nodes if n["kind"] == "test" or (n.get("metadata") or "").find("is_test") >= 0]
        results: list[DetectionResult] = []

        if framework_hits:
            fw, count = framework_hits.most_common(1)[0]
            results.append(
                DetectionResult(
                    type="pattern",
                    category="testing",
                    name=f"test_framework_{fw}",
                    description=f"Tests use {fw}",
                    confidence=min(1.0, count / 3),
                    rule_text=f"Write new tests with {fw}, following existing test file layout.",
                    evidence=[dict(framework_hits)],
                    occurrences=count,
                )
            )

        if test_nodes:
            per_module: dict[str, int] = defaultdict(int)
            for n in test_nodes:
                mod = n.get("module") or "root"
                per_module[mod] += 1
            results.append(
                DetectionResult(
                    type="pattern",
                    category="testing",
                    name="test_coverage_map",
                    description=f"{len(test_nodes)} test files distributed across modules",
                    confidence=0.6,
                    rule_text="Ensure each module has test coverage before shipping significant changes.",
                    evidence=[dict(per_module)],
                    occurrences=len(test_nodes),
                )
            )
        return results


def _edge_module(edge: dict) -> str:
    raw = edge.get("metadata")
    if not raw:
        return ""
    try:
        meta = json.loads(raw) if isinstance(raw, str) else raw
        return meta.get("module", "") if isinstance(meta, dict) else ""
    except (json.JSONDecodeError, TypeError):
        return ""
