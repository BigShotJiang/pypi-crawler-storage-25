"""StateManagementDetector — data fetching / global state library preference."""

from __future__ import annotations

import json
from collections import Counter

from neux.detectors.base import BaseDetector, DetectionContext, DetectionResult

STATE_HINTS: dict[str, list[str]] = {
    "react-query": ["@tanstack/react-query", "react-query"],
    "swr": ["swr"],
    "redux": ["@reduxjs/toolkit", "react-redux", "redux"],
    "zustand": ["zustand"],
    "jotai": ["jotai"],
    "recoil": ["recoil"],
    "mobx": ["mobx", "mobx-react"],
    "context": [],
}


class StateManagementDetector(BaseDetector):
    name = "state_management"
    languages = ["typescript", "javascript"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        counts: Counter[str] = Counter()
        for edge in ctx.edges:
            if edge["relation"] != "imports":
                continue
            module = _edge_module(edge).lower()
            for lib, hints in STATE_HINTS.items():
                if any(h.lower() in module for h in hints):
                    counts[lib] += 1
                    break
        if not counts:
            return []
        lib, count = counts.most_common(1)[0]
        return [
            DetectionResult(
                type="pattern",
                category="state_management",
                name=f"state_library_{lib}",
                description=f"State / fetching handled primarily with {lib}",
                confidence=min(1.0, count / 5),
                rule_text=(
                    f"Use {lib} for data fetching and global state. "
                    f"New components should follow existing {lib} patterns."
                ),
                evidence=[dict(counts)],
                occurrences=count,
            )
        ]


def _edge_module(edge: dict) -> str:
    raw = edge.get("metadata")
    if not raw:
        return ""
    try:
        meta = json.loads(raw) if isinstance(raw, str) else raw
        return meta.get("module", "") if isinstance(meta, dict) else ""
    except (json.JSONDecodeError, TypeError):
        return ""
