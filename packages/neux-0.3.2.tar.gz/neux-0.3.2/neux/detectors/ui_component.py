"""UIComponentDetector — identify UI library + spot duplicated components."""

from __future__ import annotations

import json
from collections import Counter
from typing import Any

from neux.detectors.base import BaseDetector, DetectionContext, DetectionResult

UI_LIBRARIES: dict[str, list[str]] = {
    "shadcn": ["@/components/ui", "shadcn"],
    "mui": ["@mui/material", "@mui/joy", "@material-ui"],
    "chakra": ["@chakra-ui/react"],
    "ant": ["antd", "@ant-design"],
    "radix": ["@radix-ui"],
    "mantine": ["@mantine/core"],
    "headlessui": ["@headlessui/react"],
}


class UIComponentDetector(BaseDetector):
    name = "ui_component"
    languages = ["typescript", "javascript"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        results: list[DetectionResult] = []
        library_counts: Counter[str] = Counter()
        for edge in ctx.edges:
            if edge["relation"] != "imports":
                continue
            module = _edge_module(edge)
            for lib, hints in UI_LIBRARIES.items():
                if any(hint in module for hint in hints):
                    library_counts[lib] += 1
                    break

        if library_counts:
            lib, count = library_counts.most_common(1)[0]
            results.append(
                DetectionResult(
                    type="pattern",
                    category="ui_component",
                    name=f"ui_library_{lib}",
                    description=f"Project uses {lib} as the primary component library",
                    confidence=min(1.0, count / 10),
                    rule_text=(
                        f"Use {lib} components whenever possible before building new ones. "
                        f"Check {lib} docs for existing primitives."
                    ),
                    evidence=[dict(library_counts)],
                    occurrences=count,
                )
            )

        components = [n for n in ctx.nodes if n["kind"] == "component"]
        if len(components) >= self.min_sample_size:
            name_counts = Counter(n["name"] for n in components)
            duplicates = [name for name, c in name_counts.items() if c > 1]
            if duplicates:
                results.append(
                    DetectionResult(
                        type="pattern",
                        category="ui_component",
                        name="duplicate_component_names",
                        description=f"{len(duplicates)} component names are used more than once",
                        confidence=0.8,
                        rule_text=(
                            "Multiple components share the same name — consider extracting "
                            "a shared implementation or renaming to clarify intent."
                        ),
                        evidence=[{"names": duplicates[:20]}],
                        occurrences=len(duplicates),
                    )
                )
        return results


def _edge_module(edge: dict[str, Any]) -> str:
    raw = edge.get("metadata")
    if not raw:
        return ""
    try:
        meta = json.loads(raw) if isinstance(raw, str) else raw
        return meta.get("module", "") if isinstance(meta, dict) else ""
    except (json.JSONDecodeError, TypeError):
        return ""
