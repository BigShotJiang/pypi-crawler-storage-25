"""FileStructureDetector — feature-vs-type organization + test colocation."""

from __future__ import annotations

from collections import Counter
from pathlib import PurePosixPath

from neux.detectors.base import BaseDetector, DetectionContext, DetectionResult

TYPE_FOLDERS: set[str] = {
    "components", "hooks", "utils", "helpers", "services", "models",
    "controllers", "pages", "views", "routes", "handlers",
}


class FileStructureDetector(BaseDetector):
    name = "file_structure"
    languages = ["*"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        paths = [n["file_path"] for n in ctx.nodes if n["file_path"]]
        if len(paths) < self.min_sample_size:
            return []

        type_style = 0
        feature_style = 0
        for p in paths:
            parts = PurePosixPath(p.replace("\\", "/")).parts
            first = parts[0] if parts else ""
            if first in TYPE_FOLDERS:
                type_style += 1
            else:
                feature_style += 1

        total = type_style + feature_style
        if not total:
            return []

        ratio_type = type_style / total
        results: list[DetectionResult] = []

        if ratio_type > 0.6:
            results.append(
                DetectionResult(
                    type="convention",
                    category="file_structure",
                    name="organized_by_type",
                    description="Codebase is organized by type (components/, hooks/, services/)",
                    confidence=ratio_type,
                    compliance=round(ratio_type, 3),
                    total_instances=total,
                    compliant_count=type_style,
                    rule_text=(
                        "Place new code under the top-level folder that matches its type "
                        "(components, hooks, services, utils, etc.)."
                    ),
                    evidence=[{"type": type_style, "feature": feature_style}],
                )
            )
        elif ratio_type < 0.3:
            results.append(
                DetectionResult(
                    type="convention",
                    category="file_structure",
                    name="organized_by_feature",
                    description="Codebase is organized by feature / domain",
                    confidence=1 - ratio_type,
                    compliance=round(1 - ratio_type, 3),
                    total_instances=total,
                    compliant_count=feature_style,
                    rule_text=(
                        "Keep code for a single feature colocated in its feature folder "
                        "(components, hooks, tests, types). Avoid extracting into global folders."
                    ),
                    evidence=[{"type": type_style, "feature": feature_style}],
                )
            )

        test_files = [p for p in paths if "test" in PurePosixPath(p).name.lower()]
        if test_files:
            colocated = sum(1 for tp in test_files if _has_sibling(tp, paths))
            ratio_col = colocated / len(test_files)
            if ratio_col > 0.5:
                results.append(
                    DetectionResult(
                        type="convention",
                        category="file_structure",
                        name="tests_colocated",
                        description="Tests live alongside the code they cover",
                        confidence=ratio_col,
                        compliance=round(ratio_col, 3),
                        total_instances=len(test_files),
                        compliant_count=colocated,
                        rule_text="Place test files next to the source file they cover, not in a global tests/ folder.",
                        evidence=[{"colocated": colocated, "total_tests": len(test_files)}],
                    )
                )
        return results


def _has_sibling(test_path: str, all_paths: list[str]) -> bool:
    parent = str(PurePosixPath(test_path).parent)
    return any(p != test_path and str(PurePosixPath(p).parent) == parent for p in all_paths)
