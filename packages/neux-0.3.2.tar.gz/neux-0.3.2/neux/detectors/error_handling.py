"""ErrorHandlingDetector — try/catch coverage and custom exception hints."""

from __future__ import annotations

import re

from neux.detectors.base import BaseDetector, DetectionContext, DetectionResult

PY_TRY_RE = re.compile(r"^\s*try\s*:")
PY_BARE_EXCEPT_RE = re.compile(r"^\s*except\s*:")
TS_TRY_RE = re.compile(r"\btry\s*\{")
TS_CATCH_RE = re.compile(r"\bcatch\s*\(")


class ErrorHandlingDetector(BaseDetector):
    name = "error_handling"
    languages = ["*"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        py_try = 0
        py_bare = 0
        ts_try = 0
        ts_catch = 0

        for path, content in ctx.files.items():
            if path.endswith(".py"):
                for line in content.splitlines():
                    if PY_TRY_RE.match(line):
                        py_try += 1
                    if PY_BARE_EXCEPT_RE.match(line):
                        py_bare += 1
            elif path.endswith((".ts", ".tsx", ".js", ".jsx")):
                ts_try += len(TS_TRY_RE.findall(content))
                ts_catch += len(TS_CATCH_RE.findall(content))

        results: list[DetectionResult] = []
        if py_try >= self.min_sample_size:
            compliance = max(0.0, 1 - (py_bare / py_try))
            results.append(
                DetectionResult(
                    type="convention",
                    category="error_handling",
                    name="python_typed_excepts",
                    description="Python except clauses should specify an exception type",
                    confidence=compliance,
                    compliance=round(compliance, 3),
                    total_instances=py_try,
                    compliant_count=py_try - py_bare,
                    rule_text=(
                        "Never use bare `except:`. Always catch specific exception types "
                        "to avoid swallowing unexpected errors."
                    ),
                    evidence=[{"try_blocks": py_try, "bare_except": py_bare}],
                )
            )

        if ts_try >= self.min_sample_size:
            results.append(
                DetectionResult(
                    type="pattern",
                    category="error_handling",
                    name="ts_try_catch_usage",
                    description=f"{ts_try} try/catch blocks in TS/JS code",
                    confidence=0.5,
                    rule_text=(
                        "When throwing in TypeScript, prefer custom Error subclasses. "
                        "Wrap async boundaries in try/catch or use a shared error handler."
                    ),
                    evidence=[{"try": ts_try, "catch": ts_catch}],
                    occurrences=ts_try,
                )
            )
        return results
