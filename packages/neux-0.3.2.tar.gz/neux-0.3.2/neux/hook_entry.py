"""Lightweight hook entrypoint invoked by Claude Code.

Claude Code sends a JSON payload on stdin for every hook event. This module is
the single ``python -m neux.hook_entry <action>`` target. It keeps imports
minimal until the very last moment — typer, rich, tree-sitter, jinja2 are
never loaded in the fast path.

The orchestration logic lives in :mod:`neux.hooks`; this file only deals with:

* parsing stdin JSON safely
* finding the project root (walks up until ``.neux/`` is found)
* dispatching to the correct handler
* catching exceptions so a bug in NEUX never blocks Claude Code
* logging latency to ``.neux/hook_latency.log`` when over budget
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Any

LATENCY_BUDGET_MS = 200


def main() -> int:
    start_ns = time.perf_counter_ns()
    action = sys.argv[1] if len(sys.argv) > 1 else ""
    if not action:
        return 0

    payload = _read_stdin_json()
    project_root = _find_project_root(Path.cwd(), payload)
    if project_root is None:
        return 0

    try:
        # Lazy import — the hot path avoids loading heavy modules
        from neux import hooks

        if action == "pre-tool-use":
            text = hooks.handle_pre_tool_use(project_root, payload)
        elif action == "post-tool-use":
            text = hooks.handle_post_tool_use(project_root, payload)
        elif action == "session-start":
            text = hooks.handle_session_start(project_root, payload)
        elif action == "stop":
            text = hooks.handle_stop(project_root, payload)
        else:
            text = ""
        if text:
            sys.stderr.write(text)
            sys.stderr.flush()
    except Exception as exc:
        # Never let a NEUX crash block Claude Code. Log and move on.
        _log_error(project_root, action, exc)
    finally:
        elapsed_ms = (time.perf_counter_ns() - start_ns) / 1_000_000
        if elapsed_ms > LATENCY_BUDGET_MS:
            _log_latency(project_root, action, elapsed_ms)
    return 0


def _read_stdin_json() -> dict[str, Any]:
    """Slurp stdin; return an empty dict on any parse error or empty input."""
    try:
        if sys.stdin.isatty():
            return {}
        raw = sys.stdin.read()
        if not raw.strip():
            return {}
        return json.loads(raw)
    except (json.JSONDecodeError, OSError):
        return {}


def _find_project_root(cwd: Path, payload: dict[str, Any]) -> Path | None:
    """Walk up from ``cwd`` until a ``.neux/`` directory is found.

    Also honours an explicit ``cwd`` field in the payload (Claude Code provides
    this) as a starting point.
    """
    candidates: list[Path] = []
    payload_cwd = payload.get("cwd") or (payload.get("tool_input", {}) or {}).get("cwd")
    if isinstance(payload_cwd, str) and payload_cwd:
        candidates.append(Path(payload_cwd))
    candidates.append(cwd)

    for start in candidates:
        current = start.resolve()
        for ancestor in [current, *current.parents]:
            if (ancestor / ".neux").is_dir():
                return ancestor
    return None


def _log_latency(project_root: Path | None, action: str, elapsed_ms: float) -> None:
    if project_root is None:
        return
    try:
        log = project_root / ".neux" / "hook_latency.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open("a", encoding="utf-8") as f:
            f.write(f"{int(time.time())}\t{action}\t{elapsed_ms:.1f}ms\n")
    except OSError:
        pass


def _log_error(project_root: Path | None, action: str, exc: BaseException) -> None:
    if project_root is None:
        return
    try:
        log = project_root / ".neux" / "hook_errors.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open("a", encoding="utf-8") as f:
            f.write(f"{int(time.time())}\t{action}\t{type(exc).__name__}: {exc}\n")
    except OSError:
        pass


if __name__ == "__main__":
    sys.exit(main())
