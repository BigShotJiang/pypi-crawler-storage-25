"""Bridge module for optional ANVL integration.

When ``anvl-monitor`` is installed, this module exposes ANVL session metrics
(token usage, waste factor, health %) alongside NEUX's own session data.
When ANVL is not installed, every function returns empty/None gracefully.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

_HAS_ANVL = False
try:
    from anvl.analyzer import analyze_session
    from anvl.calibration import get_calibrated_baseline, get_growth_curve
    from anvl.parser import (
        find_active_session,
        find_project_sessions,
        parse_session_file,
    )
    from anvl.sessions import collect_all_sessions

    _HAS_ANVL = True
except ImportError:
    pass


def is_available() -> bool:
    """Return True if anvl-monitor is installed and importable."""
    return _HAS_ANVL


def get_active_session_metrics(cwd: Path | None = None) -> dict[str, Any] | None:
    """Return ANVL metrics for the currently active session, or None."""
    if not _HAS_ANVL:
        return None
    try:
        result = find_active_session(cwd or Path.cwd())
        if result is None:
            return None
        jsonl_path, session_id = result
        session = parse_session_file(jsonl_path)
        baseline = get_calibrated_baseline()
        growth = get_growth_curve()
        metrics = analyze_session(session, calibrated_baseline=baseline, growth_curve=growth)
        return {
            "session_id": metrics.session_id,
            "ai_title": metrics.ai_title,
            "turns": metrics.turn_count,
            "health_pct": metrics.health_pct,
            "waste_factor": round(metrics.waste_factor, 2),
            "semaphore": metrics.semaphore,
            "trend": metrics.trend,
            "total_input_tokens": metrics.total_input_tokens,
            "total_output_tokens": metrics.total_output_tokens,
            "total_cache_read": metrics.total_cache_read,
            "baseline_per_turn": metrics.baseline_per_turn,
            "current_per_turn": metrics.current_per_turn,
        }
    except Exception:
        return None


def get_project_sessions(cwd: Path | None = None, limit: int = 20) -> list[dict[str, Any]]:
    """Return ANVL session summaries for the given project directory."""
    if not _HAS_ANVL:
        return []
    try:
        cwd = cwd or Path.cwd()
        jsonl_files = find_project_sessions(cwd)
        baseline = get_calibrated_baseline()
        growth = get_growth_curve()
        results: list[dict[str, Any]] = []
        for jsonl_path in jsonl_files[:limit]:
            try:
                session = parse_session_file(jsonl_path)
                metrics = analyze_session(session, calibrated_baseline=baseline, growth_curve=growth)
                results.append({
                    "session_id": metrics.session_id,
                    "ai_title": metrics.ai_title,
                    "turns": metrics.turn_count,
                    "health_pct": metrics.health_pct,
                    "waste_factor": round(metrics.waste_factor, 2),
                    "semaphore": metrics.semaphore,
                    "trend": metrics.trend,
                    "total_input_tokens": metrics.total_input_tokens,
                    "total_output_tokens": metrics.total_output_tokens,
                })
            except Exception:
                continue
        return results
    except Exception:
        return []


def get_all_sessions_summary() -> list[dict[str, Any]]:
    """Return lightweight summaries of all ANVL-tracked sessions across projects."""
    if not _HAS_ANVL:
        return []
    try:
        summaries = collect_all_sessions()
        return [
            {
                "session_id": s.session_id,
                "project": s.project,
                "cwd": s.cwd,
                "ai_title": s.ai_title,
                "is_active": s.is_active,
                "turns": s.turns,
                "total_input": s.total_input,
                "total_output": s.total_output,
                "health_pct": s.health_pct,
                "waste_factor": round(s.waste_factor, 2),
                "efficiency": s.efficiency,
            }
            for s in summaries
        ]
    except Exception:
        return []
