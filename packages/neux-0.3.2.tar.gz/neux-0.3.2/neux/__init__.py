"""NEUX — codebase nervous system.

Python CLI that builds a knowledge graph of your codebase in SQLite,
detects patterns automatically, and integrates with Claude Code via hooks.
"""

__version__ = "0.3.2"
__author__ = "IronDevz"
