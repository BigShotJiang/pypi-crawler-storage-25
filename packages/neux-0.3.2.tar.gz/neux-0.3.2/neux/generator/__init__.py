"""CLAUDE.md and sub-manual generation (Jinja2 templates)."""
