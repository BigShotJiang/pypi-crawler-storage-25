"""CLAUDE.md and sub-manual generation via Jinja2 templates."""

from __future__ import annotations

import json
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, select_autoescape

from neux import __version__
from neux.engine import GraphEngine

_TEMPLATE_DIR = Path(__file__).parent / "templates"


def _env() -> Environment:
    return Environment(
        loader=FileSystemLoader(str(_TEMPLATE_DIR)),
        autoescape=select_autoescape(enabled_extensions=()),
        trim_blocks=True,
        lstrip_blocks=True,
    )


def generate_all(project_root: Path | str, engine: GraphEngine) -> dict[str, Path]:
    """Generate ``CLAUDE.md`` plus per-module sub-manuals and rule digests.

    Returns a mapping ``{logical_name: absolute_path}`` of files written.
    """
    root = Path(project_root)
    written: dict[str, Path] = {}

    claude_md_path = root / "CLAUDE.md"
    claude_md_path.write_text(_render_claude_md(root, engine), encoding="utf-8")
    written["CLAUDE.md"] = claude_md_path

    neux_dir = root / ".neux"
    modules_dir = neux_dir / "modules"
    modules_dir.mkdir(parents=True, exist_ok=True)

    for mod in engine.get_modules():
        path = modules_dir / f"{mod['name']}.md"
        path.write_text(_render_module(mod, engine), encoding="utf-8")
        written[f"modules/{mod['name']}"] = path

    rules_dir = neux_dir / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)
    (rules_dir / "patterns.md").write_text(_render_patterns(engine), encoding="utf-8")
    (rules_dir / "conventions.md").write_text(_render_conventions(engine), encoding="utf-8")
    written["rules/patterns"] = rules_dir / "patterns.md"
    written["rules/conventions"] = rules_dir / "conventions.md"

    return written


# ======================================================================
# Renderers
# ======================================================================


def _render_claude_md(root: Path, engine: GraphEngine) -> str:
    template = _env().get_template("claude_md.j2")
    stats = engine.get_stats()
    modules = engine.get_modules()
    god_nodes = engine.get_god_nodes()[:15]

    critical_patterns = [
        p for p in engine.get_patterns() if p["status"] == "confirmed" or p["confidence"] >= 0.8
    ]
    critical_conventions = [
        c for c in engine.get_conventions()
        if (c["status"] == "confirmed" or (c["compliance"] or 0) >= 0.8)
    ]
    critical_rules = [
        {"id": f"pattern:{p['name']}", "rule_text": p["rule_text"], "description": p["description"]}
        for p in critical_patterns[:10]
    ] + [
        {"id": f"convention:{c['name']}", "rule_text": c["rule_text"], "description": c["description"]}
        for c in critical_conventions[:10]
    ]

    stack_raw = engine.conn.execute(
        "SELECT value FROM project_info WHERE key = 'stack'"
    ).fetchone()
    stack: dict[str, Any] = {"languages": [], "frameworks": []}
    if stack_raw:
        try:
            stack = json.loads(stack_raw[0])
        except json.JSONDecodeError:
            pass

    return template.render(
        project_name=root.name,
        stack=stack,
        stats=stats,
        modules=modules,
        critical_rules=critical_rules,
        god_nodes=god_nodes,
        now=datetime.now().strftime("%Y-%m-%d %H:%M"),
        version=__version__,
    )


def _render_module(module: dict[str, Any], engine: GraphEngine) -> str:
    template = _env().get_template("module.j2")
    name = module["name"]
    nodes = engine.get_nodes_by_module(name)

    files: dict[str, Counter[str]] = {}
    for n in nodes:
        if not n["file_path"]:
            continue
        files.setdefault(n["file_path"], Counter())[n["kind"]] += 1
    files_rendered = [
        {
            "path": path,
            "count": sum(kinds.values()),
            "kinds": ", ".join(f"{k}:{v}" for k, v in kinds.most_common()),
        }
        for path, kinds in sorted(files.items())
    ][:30]

    god_nodes = [g for g in engine.get_god_nodes(min_connections=5) if g["module"] == name][:10]

    inconsistencies_rows = engine.conn.execute(
        """
        SELECT i.* FROM inconsistencies i
        LEFT JOIN nodes n ON i.node_id = n.id
        WHERE i.status = 'open' AND n.module = ?
        ORDER BY i.severity DESC
        LIMIT 20
        """,
        (name,),
    ).fetchall()
    inconsistencies = [dict(r) for r in inconsistencies_rows]

    module_rules = []
    for p in engine.get_patterns():
        if p["status"] == "confirmed" or p["confidence"] >= 0.7:
            module_rules.append(
                {"id": f"p:{p['name']}", "rule_text": p["rule_text"], "description": p["description"]}
            )
    for c in engine.get_conventions():
        if c["status"] == "confirmed" or (c["compliance"] or 0) >= 0.7:
            module_rules.append(
                {"id": f"c:{c['name']}", "rule_text": c["rule_text"], "description": c["description"]}
            )
    module_rules = module_rules[:15]

    return template.render(
        module=module,
        files=files_rendered,
        god_nodes=god_nodes,
        inconsistencies=inconsistencies,
        module_rules=module_rules,
    )


def _render_patterns(engine: GraphEngine) -> str:
    template = _env().get_template("patterns.j2")
    return template.render(patterns=engine.get_patterns())


def _render_conventions(engine: GraphEngine) -> str:
    template = _env().get_template("conventions.j2")
    return template.render(conventions=engine.get_conventions())
