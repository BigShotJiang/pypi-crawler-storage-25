"""SQLite schema, connection manager and migrations for NEUX.

The full knowledge graph lives in a single SQLite database under `.neux/graph.db`
at the project root. This module is the only place that owns schema DDL — every
other module opens connections through :func:`get_connection`.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA_VERSION = 1

SCHEMA_SQL = """
-- ============================================================
-- GRAFO BASE
-- ============================================================

CREATE TABLE IF NOT EXISTS nodes (
    id              TEXT PRIMARY KEY,
    kind            TEXT NOT NULL,
    name            TEXT NOT NULL,
    file_path       TEXT,
    line_start      INTEGER,
    line_end        INTEGER,
    module          TEXT,
    language        TEXT,
    signature       TEXT,
    docstring       TEXT,
    metadata        TEXT,
    file_hash       TEXT,
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now')),

    CHECK (kind IN (
        'file', 'function', 'class', 'method', 'component',
        'endpoint', 'route', 'middleware', 'decorator', 'hook',
        'table', 'column', 'migration',
        'env_var', 'config_key',
        'test', 'test_suite',
        'type', 'interface', 'enum', 'schema',
        'package', 'module_node',
        'style', 'theme_token',
        'event', 'signal', 'callback'
    ))
);

CREATE INDEX IF NOT EXISTS idx_nodes_kind ON nodes(kind);
CREATE INDEX IF NOT EXISTS idx_nodes_module ON nodes(module);
CREATE INDEX IF NOT EXISTS idx_nodes_file ON nodes(file_path);
CREATE INDEX IF NOT EXISTS idx_nodes_language ON nodes(language);

CREATE VIRTUAL TABLE IF NOT EXISTS nodes_fts USING fts5(
    id, name, file_path, signature, docstring,
    content='nodes', content_rowid='rowid'
);

CREATE TABLE IF NOT EXISTS edges (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id       TEXT NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
    target_id       TEXT NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
    relation        TEXT NOT NULL,
    weight          REAL DEFAULT 1.0,
    confidence      REAL DEFAULT 1.0,
    metadata        TEXT,
    source_type     TEXT DEFAULT 'scan',
    created_at      TEXT DEFAULT (datetime('now')),

    UNIQUE(source_id, target_id, relation),

    CHECK (relation IN (
        'imports', 'calls', 'renders', 'inherits', 'implements',
        'instantiates', 'decorates', 'wraps',
        'reads_from', 'writes_to', 'mutates', 'validates',
        'depends_on', 'configures', 'injects',
        'routes_to', 'middleware_for', 'responds_with',
        'tests', 'mocks',
        'renders_in', 'styles', 'listens_to', 'emits',
        'triggers', 'subscribes_to',
        'relates_to', 'replaces', 'extends_concept'
    )),

    CHECK (source_type IN ('scan', 'annotation', 'inferred', 'manual'))
);

CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_id);
CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_id);
CREATE INDEX IF NOT EXISTS idx_edges_relation ON edges(relation);

-- ============================================================
-- MODULOS
-- ============================================================

CREATE TABLE IF NOT EXISTS modules (
    name            TEXT PRIMARY KEY,
    description     TEXT,
    parent          TEXT REFERENCES modules(name),
    root_path       TEXT,
    language        TEXT,
    layer           TEXT,
    node_count      INTEGER DEFAULT 0,
    edge_count      INTEGER DEFAULT 0,
    coupling_score  REAL,
    auto_detected   BOOLEAN DEFAULT 1,
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now')),

    CHECK (layer IN (
        'api', 'service', 'data', 'ui', 'config',
        'infrastructure', 'test', 'utility', 'unknown'
    ))
);

CREATE TABLE IF NOT EXISTS module_dependencies (
    source_module   TEXT NOT NULL REFERENCES modules(name) ON DELETE CASCADE,
    target_module   TEXT NOT NULL REFERENCES modules(name) ON DELETE CASCADE,
    edge_count      INTEGER DEFAULT 1,
    relation_types  TEXT,
    strength        REAL,
    PRIMARY KEY (source_module, target_module)
);

-- ============================================================
-- PATRONES Y CONVENCIONES
-- ============================================================

CREATE TABLE IF NOT EXISTS patterns (
    id              TEXT PRIMARY KEY,
    category        TEXT NOT NULL,
    name            TEXT NOT NULL,
    description     TEXT NOT NULL,
    evidence        TEXT NOT NULL,
    confidence      REAL NOT NULL,
    status          TEXT DEFAULT 'candidate',
    occurrences     INTEGER DEFAULT 0,
    exceptions      TEXT,
    rule_text       TEXT,
    created_at      TEXT DEFAULT (datetime('now')),
    confirmed_at    TEXT,
    updated_at      TEXT DEFAULT (datetime('now')),

    CHECK (category IN (
        'ui_component', 'ui_layout', 'ui_style',
        'api_design', 'api_response', 'api_auth',
        'data_access', 'data_validation', 'data_schema',
        'state_management', 'error_handling', 'testing',
        'file_structure', 'naming', 'imports',
        'architecture', 'security', 'performance'
    )),
    CHECK (status IN ('candidate', 'confirmed', 'discarded', 'deprecated'))
);

CREATE TABLE IF NOT EXISTS conventions (
    id              TEXT PRIMARY KEY,
    category        TEXT NOT NULL,
    name            TEXT NOT NULL,
    description     TEXT NOT NULL,
    source_file     TEXT,
    compliance      REAL,
    total_instances INTEGER DEFAULT 0,
    compliant_count INTEGER DEFAULT 0,
    status          TEXT DEFAULT 'candidate',
    rule_text       TEXT,
    severity        TEXT DEFAULT 'warning',
    created_at      TEXT DEFAULT (datetime('now')),
    confirmed_at    TEXT,
    updated_at      TEXT DEFAULT (datetime('now')),

    CHECK (status IN ('candidate', 'confirmed', 'discarded', 'deprecated')),
    CHECK (severity IN ('info', 'warning', 'error'))
);

CREATE TABLE IF NOT EXISTS inconsistencies (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_type       TEXT NOT NULL,
    rule_id         TEXT NOT NULL,
    node_id         TEXT REFERENCES nodes(id) ON DELETE CASCADE,
    file_path       TEXT NOT NULL,
    line_number     INTEGER,
    description     TEXT NOT NULL,
    expected        TEXT,
    actual          TEXT,
    status          TEXT DEFAULT 'open',
    severity        TEXT DEFAULT 'warning',
    detected_at     TEXT DEFAULT (datetime('now')),
    resolved_at     TEXT,
    resolved_by     TEXT,

    CHECK (rule_type IN ('pattern', 'convention')),
    CHECK (status IN ('open', 'resolved', 'ignored', 'exception')),
    CHECK (severity IN ('info', 'warning', 'error'))
);

CREATE INDEX IF NOT EXISTS idx_inconsistencies_status ON inconsistencies(status);
CREATE INDEX IF NOT EXISTS idx_inconsistencies_file ON inconsistencies(file_path);

-- ============================================================
-- HISTORIAL DE SESIONES
-- ============================================================

CREATE TABLE IF NOT EXISTS sessions (
    id              TEXT PRIMARY KEY,
    started_at      TEXT DEFAULT (datetime('now')),
    ended_at        TEXT,
    duration_seconds INTEGER,
    summary         TEXT,
    task_type       TEXT,
    modules_touched TEXT,
    files_created   TEXT,
    files_modified  TEXT,
    files_deleted   TEXT,
    nodes_added     INTEGER DEFAULT 0,
    edges_added     INTEGER DEFAULT 0,
    patterns_violated INTEGER DEFAULT 0,
    tokens_context_injected INTEGER DEFAULT 0,

    CHECK (task_type IN (
        'feature', 'fix', 'refactor', 'style',
        'test', 'docs', 'config', 'migration',
        'exploration', 'unknown'
    ))
);

CREATE TABLE IF NOT EXISTS session_actions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    action_type     TEXT NOT NULL,
    file_path       TEXT,
    node_id         TEXT,
    context_injected TEXT,
    context_tokens  INTEGER,
    inconsistencies_detected INTEGER DEFAULT 0,
    timestamp       TEXT DEFAULT (datetime('now')),

    CHECK (action_type IN (
        'create_file', 'edit_file', 'delete_file',
        'read_file', 'run_command', 'search'
    ))
);

CREATE TABLE IF NOT EXISTS change_incidents (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT REFERENCES sessions(id),
    trigger_file    TEXT NOT NULL,
    trigger_node    TEXT,
    affected_file   TEXT NOT NULL,
    affected_node   TEXT,
    description     TEXT,
    detected_at     TEXT DEFAULT (datetime('now')),
    resolved_at     TEXT
);

-- ============================================================
-- CONTEXTO INTELIGENTE
-- ============================================================

CREATE TABLE IF NOT EXISTS context_profiles (
    file_path       TEXT PRIMARY KEY,
    module          TEXT,
    node_ids        TEXT,
    patterns_applicable TEXT,
    conventions_applicable TEXT,
    dependencies_summary TEXT,
    coupling_score  REAL,
    change_risk     REAL,
    incident_count  INTEGER DEFAULT 0,
    last_modified   TEXT,
    last_session    TEXT,
    times_modified  INTEGER DEFAULT 0,
    context_template TEXT,
    updated_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS injection_rules (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    task_category   TEXT NOT NULL,
    keywords        TEXT NOT NULL,
    inject_patterns BOOLEAN DEFAULT 1,
    inject_conventions BOOLEAN DEFAULT 1,
    inject_dependencies BOOLEAN DEFAULT 1,
    inject_incidents BOOLEAN DEFAULT 1,
    inject_siblings BOOLEAN DEFAULT 0,
    max_depth       INTEGER DEFAULT 2,
    priority_fields TEXT,

    CHECK (task_category IN (
        'style_change', 'logic_change', 'new_feature',
        'bug_fix', 'refactor', 'test_writing',
        'api_change', 'database_change', 'config_change',
        'general'
    ))
);

-- ============================================================
-- METADATA Y SNAPSHOTS
-- ============================================================

CREATE TABLE IF NOT EXISTS project_info (
    key             TEXT PRIMARY KEY,
    value           TEXT NOT NULL,
    updated_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS snapshots (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp       TEXT DEFAULT (datetime('now')),
    trigger         TEXT,
    node_count      INTEGER,
    edge_count      INTEGER,
    pattern_count   INTEGER,
    convention_count INTEGER,
    inconsistency_count INTEGER,
    module_summary  TEXT,
    graph_hash      TEXT
);

CREATE TABLE IF NOT EXISTS schema_version (
    version         INTEGER PRIMARY KEY,
    applied_at      TEXT DEFAULT (datetime('now'))
);

-- ============================================================
-- VISTAS
-- ============================================================

CREATE VIEW IF NOT EXISTS god_nodes AS
SELECT
    n.id, n.name, n.kind, n.module, n.file_path,
    COUNT(DISTINCT e1.id) + COUNT(DISTINCT e2.id) AS total_connections,
    COUNT(DISTINCT e1.id) AS outgoing,
    COUNT(DISTINCT e2.id) AS incoming
FROM nodes n
LEFT JOIN edges e1 ON e1.source_id = n.id
LEFT JOIN edges e2 ON e2.target_id = n.id
GROUP BY n.id
HAVING total_connections >= 10
ORDER BY total_connections DESC;

CREATE VIEW IF NOT EXISTS risky_files AS
SELECT
    cp.file_path, cp.module, cp.coupling_score,
    cp.change_risk, cp.incident_count, cp.times_modified,
    (COALESCE(cp.coupling_score, 0) * 0.3 + COALESCE(cp.change_risk, 0) * 0.4 +
     MIN(COALESCE(cp.incident_count, 0) * 0.1, 0.3)) AS risk_score
FROM context_profiles cp
WHERE cp.coupling_score > 0.5 OR cp.incident_count > 0
ORDER BY risk_score DESC;

CREATE VIEW IF NOT EXISTS active_modules AS
SELECT
    value AS module_name,
    COUNT(*) AS session_count
FROM sessions s, json_each(s.modules_touched)
WHERE s.started_at > datetime('now', '-30 days')
GROUP BY value
ORDER BY session_count DESC;

CREATE VIEW IF NOT EXISTS open_inconsistencies_by_module AS
SELECT
    n.module, COUNT(*) AS count,
    GROUP_CONCAT(i.description, ' | ') AS descriptions
FROM inconsistencies i
LEFT JOIN nodes n ON i.node_id = n.id
WHERE i.status = 'open'
GROUP BY n.module
ORDER BY count DESC;

-- ============================================================
-- TRIGGERS
-- ============================================================

CREATE TRIGGER IF NOT EXISTS nodes_updated_at
AFTER UPDATE ON nodes
BEGIN
    UPDATE nodes SET updated_at = datetime('now') WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS module_node_count_insert
AFTER INSERT ON nodes WHEN NEW.module IS NOT NULL
BEGIN
    UPDATE modules SET
        node_count = (SELECT COUNT(*) FROM nodes WHERE module = NEW.module),
        updated_at = datetime('now')
    WHERE name = NEW.module;
END;

CREATE TRIGGER IF NOT EXISTS module_node_count_delete
AFTER DELETE ON nodes WHEN OLD.module IS NOT NULL
BEGIN
    UPDATE modules SET
        node_count = (SELECT COUNT(*) FROM nodes WHERE module = OLD.module),
        updated_at = datetime('now')
    WHERE name = OLD.module;
END;

CREATE TRIGGER IF NOT EXISTS nodes_fts_insert AFTER INSERT ON nodes BEGIN
    INSERT INTO nodes_fts(rowid, id, name, file_path, signature, docstring)
    VALUES (NEW.rowid, NEW.id, NEW.name, NEW.file_path, NEW.signature, NEW.docstring);
END;

CREATE TRIGGER IF NOT EXISTS nodes_fts_delete AFTER DELETE ON nodes BEGIN
    INSERT INTO nodes_fts(nodes_fts, rowid, id, name, file_path, signature, docstring)
    VALUES ('delete', OLD.rowid, OLD.id, OLD.name, OLD.file_path, OLD.signature, OLD.docstring);
END;

CREATE TRIGGER IF NOT EXISTS nodes_fts_update AFTER UPDATE ON nodes BEGIN
    INSERT INTO nodes_fts(nodes_fts, rowid, id, name, file_path, signature, docstring)
    VALUES ('delete', OLD.rowid, OLD.id, OLD.name, OLD.file_path, OLD.signature, OLD.docstring);
    INSERT INTO nodes_fts(rowid, id, name, file_path, signature, docstring)
    VALUES (NEW.rowid, NEW.id, NEW.name, NEW.file_path, NEW.signature, NEW.docstring);
END;
"""


def get_db_path(project_path: Path | str) -> Path:
    """Return the canonical graph DB path for a project root."""
    return Path(project_path) / ".neux" / "graph.db"


def get_connection(project_path: Path | str) -> sqlite3.Connection:
    """Open a tuned SQLite connection to the project's graph DB.

    Creates the `.neux/` directory if missing. The connection has WAL mode
    enabled for concurrent reads, foreign keys on, and returns rows as `dict`-ish
    :class:`sqlite3.Row` objects.
    """
    db_path = get_db_path(project_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(db_path), isolation_level=None, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA temp_store=MEMORY")
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    """Create all tables, indices, FTS5 virtual table, views, and triggers.

    Idempotent: safe to call multiple times. After creation, stamps the current
    :data:`SCHEMA_VERSION` in ``schema_version``.
    """
    conn.executescript(SCHEMA_SQL)
    conn.execute(
        "INSERT OR IGNORE INTO schema_version (version) VALUES (?)",
        (SCHEMA_VERSION,),
    )
    _seed_default_injection_rules(conn)


def _seed_default_injection_rules(conn: sqlite3.Connection) -> None:
    """Populate injection_rules with sensible defaults for each task category.

    Only inserts if the table is empty — user-edited rules are never overwritten.
    """
    existing = conn.execute("SELECT COUNT(*) FROM injection_rules").fetchone()[0]
    if existing:
        return

    import json

    defaults = [
        ("style_change", ["color", "style", "estilo", "css", "theme", "font", "tailwind", "diseño", "responsive"],
         1, 1, 0, 0, 0, 1),
        ("new_feature", ["crear", "nuevo", "agregar", "implementar", "create", "add", "build", "feature"],
         1, 1, 1, 1, 1, 3),
        ("logic_change", ["función", "function", "cambiar", "modificar", "refactor", "validar"],
         1, 1, 1, 1, 0, 2),
        ("bug_fix", ["bug", "error", "fix", "arreglar", "crash", "falla", "broken"],
         1, 1, 1, 1, 0, 3),
        ("refactor", ["refactor", "rename", "reorganizar", "limpiar", "cleanup"],
         1, 1, 1, 0, 1, 2),
        ("test_writing", ["test", "mock", "fixture", "coverage", "spec", "prueba"],
         1, 1, 0, 0, 1, 1),
        ("api_change", ["endpoint", "api", "ruta", "route", "middleware", "auth"],
         1, 1, 1, 1, 1, 2),
        ("database_change", ["tabla", "migración", "migration", "modelo", "schema", "query", "table"],
         1, 1, 1, 1, 0, 2),
        ("config_change", ["config", "env", "docker", "deploy", "ci", ".env"],
         0, 1, 1, 0, 0, 1),
        ("general", [],
         1, 1, 1, 1, 0, 2),
    ]

    for cat, kw, ip, ic, idp, ii, isb, md in defaults:
        conn.execute(
            """
            INSERT INTO injection_rules
                (task_category, keywords, inject_patterns, inject_conventions,
                 inject_dependencies, inject_incidents, inject_siblings, max_depth)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (cat, json.dumps(kw), ip, ic, idp, ii, isb, md),
        )


def get_schema_version(conn: sqlite3.Connection) -> int:
    """Return the highest schema version recorded in the DB, or 0 if missing."""
    try:
        row = conn.execute(
            "SELECT MAX(version) FROM schema_version"
        ).fetchone()
        return int(row[0]) if row and row[0] else 0
    except sqlite3.OperationalError:
        return 0


def migrate(conn: sqlite3.Connection) -> None:
    """Apply pending schema migrations.

    v0.1 has only a single schema version so this is a no-op beyond the initial
    `init_db` stamp. Future versions will branch here based on `get_schema_version`.
    """
    current = get_schema_version(conn)
    if current < SCHEMA_VERSION:
        init_db(conn)
