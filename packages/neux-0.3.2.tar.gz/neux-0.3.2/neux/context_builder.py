"""ContextBuilder — produce the text block that hooks inject into Claude Code.

Reads from ``context_profiles`` as a cache. If no profile exists for a file,
it computes one on demand and stores it. The output shape is fixed (see module
docstring of ``neux/hooks.py``) so that Claude Code parses it consistently.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from neux.engine import GraphEngine

MAX_PATTERNS = 8
MAX_CONVENTIONS = 8
MAX_SIBLINGS = 3
MAX_DEPS = 5
MAX_INCIDENTS = 3


@dataclass(slots=True)
class InjectionConfig:
    inject_patterns: bool = True
    inject_conventions: bool = True
    inject_dependencies: bool = True
    inject_incidents: bool = True
    inject_siblings: bool = False


class ContextBuilder:
    def __init__(self, engine: GraphEngine):
        self.engine = engine

    # ------------------------------------------------------------------

    def build(
        self,
        file_path: str,
        category: str = "general",
    ) -> str:
        """Return the text block to emit on stderr for Claude Code to read."""
        rule = self._load_injection_rule(category)
        profile = self._ensure_profile(file_path)

        module = profile.get("module") or self.engine.infer_module(file_path)
        coupling = profile.get("coupling_score") or 0.0
        risk = profile.get("change_risk") or 0.0
        times_mod = profile.get("times_modified") or 0

        lines: list[str] = [
            f"[NEUX] Contexto para {file_path}",
            (
                f"Módulo: {module} | "
                f"Acoplamiento: {int(coupling * 100)}% | "
                f"Riesgo: {round(risk, 2)} | "
                f"Modificaciones: {times_mod}"
            ),
            "",
        ]

        if rule.inject_patterns:
            patterns = self._relevant_patterns(profile, category)
            if patterns:
                lines.append("PATRONES ACTIVOS:")
                for p in patterns[:MAX_PATTERNS]:
                    lines.append(f"- {p['id']}: {p.get('rule_text') or p['description']}")
                lines.append("")

        if rule.inject_conventions:
            conventions = self._relevant_conventions(profile, category)
            if conventions:
                lines.append("CONVENCIONES:")
                for c in conventions[:MAX_CONVENTIONS]:
                    lines.append(
                        f"- {c['id']} ({int((c.get('compliance') or 0)*100)}% compliance): "
                        f"{c.get('rule_text') or c['description']}"
                    )
                lines.append("")

        if rule.inject_siblings:
            siblings = self._siblings(file_path, module)
            if siblings:
                lines.append("REFERENCIA (archivos similares):")
                for s in siblings[:MAX_SIBLINGS]:
                    lines.append(f"- {s}")
                lines.append("")

        if rule.inject_dependencies:
            deps = self._dependencies(file_path)
            if deps:
                lines.append("DEPENDENCIAS:")
                for d in deps[:MAX_DEPS]:
                    lines.append(f"- {d}")
                lines.append("")

        if rule.inject_incidents:
            incidents = self._incidents(file_path)
            if incidents:
                lines.append("ADVERTENCIA (inconsistencias abiertas):")
                for inc in incidents[:MAX_INCIDENTS]:
                    line = inc.get("line_number")
                    loc = f":{line}" if line else ""
                    lines.append(f"- {inc['file_path']}{loc} {inc['description']}")
                lines.append("")

        if len(lines) <= 3:
            lines.append("No hay reglas específicas para este archivo aún.")

        return "\n".join(lines).rstrip() + "\n"

    # ------------------------------------------------------------------
    # Profile / injection rule helpers
    # ------------------------------------------------------------------

    def _load_injection_rule(self, category: str) -> InjectionConfig:
        row = self.engine.conn.execute(
            "SELECT * FROM injection_rules WHERE task_category = ?", (category,)
        ).fetchone()
        if row is None:
            row = self.engine.conn.execute(
                "SELECT * FROM injection_rules WHERE task_category = 'general'"
            ).fetchone()
        if row is None:
            return InjectionConfig()
        return InjectionConfig(
            inject_patterns=bool(row["inject_patterns"]),
            inject_conventions=bool(row["inject_conventions"]),
            inject_dependencies=bool(row["inject_dependencies"]),
            inject_incidents=bool(row["inject_incidents"]),
            inject_siblings=bool(row["inject_siblings"]),
        )

    def _ensure_profile(self, file_path: str) -> dict[str, Any]:
        profile = self.engine.get_context_profile(file_path)
        if profile is not None:
            return profile

        module = self.engine.infer_module(file_path)
        nodes = self.engine.get_nodes_by_file(file_path)
        node_ids = [n["id"] for n in nodes]
        coupling = 0.0
        row = self.engine.conn.execute(
            "SELECT coupling_score FROM modules WHERE name = ?", (module,)
        ).fetchone()
        if row and row[0] is not None:
            coupling = float(row[0])

        self.engine.update_context_profile(
            file_path=file_path,
            module=module,
            node_ids=node_ids,
            coupling_score=coupling,
            change_risk=coupling * 0.6,
        )
        return self.engine.get_context_profile(file_path) or {}

    def _relevant_patterns(self, profile: dict[str, Any], category: str) -> list[dict[str, Any]]:
        applicable_raw = profile.get("patterns_applicable")
        if applicable_raw:
            try:
                ids = json.loads(applicable_raw)
            except json.JSONDecodeError:
                ids = []
            if ids:
                rows = self.engine.conn.execute(
                    f"SELECT * FROM patterns WHERE id IN ({','.join(['?']*len(ids))}) AND status IN ('confirmed','candidate')",
                    ids,
                ).fetchall()
                return [dict(r) for r in rows]

        # Fallback: all confirmed + high-confidence candidates
        rows = self.engine.conn.execute(
            """
            SELECT * FROM patterns
            WHERE status IN ('confirmed','candidate') AND confidence >= 0.5
            ORDER BY status DESC, confidence DESC
            """
        ).fetchall()
        return [dict(r) for r in rows]

    def _relevant_conventions(self, profile: dict[str, Any], category: str) -> list[dict[str, Any]]:
        rows = self.engine.conn.execute(
            """
            SELECT * FROM conventions
            WHERE status IN ('confirmed','candidate') AND compliance >= 0.5
            ORDER BY compliance DESC
            """
        ).fetchall()
        return [dict(r) for r in rows]

    def _siblings(self, file_path: str, module: str) -> list[str]:
        rows = self.engine.conn.execute(
            """
            SELECT DISTINCT file_path FROM nodes
            WHERE module = ? AND file_path != ? AND file_path IS NOT NULL
            LIMIT ?
            """,
            (module, file_path, MAX_SIBLINGS),
        ).fetchall()
        return [r["file_path"] for r in rows]

    def _dependencies(self, file_path: str) -> list[str]:
        rows = self.engine.conn.execute(
            """
            SELECT DISTINCT nt.file_path
            FROM nodes ns
            JOIN edges e ON e.source_id = ns.id
            JOIN nodes nt ON nt.id = e.target_id
            WHERE ns.file_path = ?
              AND e.relation IN ('imports','calls','reads_from','writes_to','depends_on')
              AND nt.file_path IS NOT NULL
              AND nt.file_path != ?
            LIMIT ?
            """,
            (file_path, file_path, MAX_DEPS),
        ).fetchall()
        return [r["file_path"] for r in rows]

    def _incidents(self, file_path: str) -> list[dict[str, Any]]:
        return self.engine.get_inconsistencies(status="open", file_path=file_path)[:MAX_INCIDENTS]
