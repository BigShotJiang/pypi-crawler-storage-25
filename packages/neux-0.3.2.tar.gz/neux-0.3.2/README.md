# NEUX

> Codebase nervous system — knowledge graph for AI-assisted development.

NEUX is a Python CLI that builds a relationship graph of your codebase in SQLite,
detects patterns and conventions automatically (no LLM, pure AST), and integrates
with [Claude Code](https://claude.com/claude-code) via hooks to inject precise context
at the moment a tool call is about to modify a file.

Companion of [ANVL](https://github.com/juanlumanmx29/anvl). ANVL monitors tokens per
session. NEUX maps project intelligence.

⚒ forged by **IronDevz**

---

## Features (v0.1)

- SQLite knowledge graph with FTS5 full-text search
- Language scanners: Python (`ast`), React/JS/TS/JSX/TSX (tree-sitter), SQL
- 12 pattern/convention detectors (naming, imports, security, style, UI, API, data, state, errors, file structure, testing)
- Claude Code hooks that inject contextual rules before `Write`/`Edit`
- Auto-generated `CLAUDE.md` with module sub-manuals
- Impact analysis via recursive CTE (no networkx)

## Install

```bash
pip install -e .
```

## Usage

```bash
cd your-project
neux init               # initial scan, generates CLAUDE.md, installs hooks
neux status             # graph stats
neux impact <target>    # what breaks if you change this
neux scan --changed     # incremental rescan
```

## License

MIT © IronDevz
