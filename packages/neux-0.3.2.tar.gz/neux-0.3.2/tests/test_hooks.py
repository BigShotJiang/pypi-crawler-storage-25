"""Hook integration tests — simulate Claude Code stdin payloads."""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path

from neux import hook_entry, hooks
from neux.engine import GraphEngine
from neux.scanner import ProjectScanner


def _bootstrap(root: Path) -> None:
    engine = GraphEngine(root)
    ProjectScanner(engine).scan_project(root)
    engine.close()


def test_pre_tool_use_returns_context_block(python_project: Path) -> None:
    _bootstrap(python_project)
    payload = {
        "tool_name": "Edit",
        "tool_input": {"file_path": "api/main.py"},
        "prompt": "agregar un endpoint nuevo",
        "cwd": str(python_project),
    }
    text = hooks.handle_pre_tool_use(python_project, payload)
    assert "[NEUX] Contexto para api/main.py" in text
    assert "Módulo: api" in text


def test_pre_tool_use_ignores_nodemodules(python_project: Path) -> None:
    _bootstrap(python_project)
    payload = {
        "tool_input": {"file_path": "node_modules/foo.js"},
        "prompt": "",
        "cwd": str(python_project),
    }
    assert hooks.handle_pre_tool_use(python_project, payload) == ""


def test_session_start_returns_summary(python_project: Path) -> None:
    _bootstrap(python_project)
    text = hooks.handle_session_start(python_project, {"cwd": str(python_project)})
    assert "NEUX" in text and "nodos" in text


def test_hook_entry_main_dispatches(monkeypatch, python_project: Path) -> None:
    _bootstrap(python_project)
    payload = {
        "tool_name": "Edit",
        "tool_input": {"file_path": "api/main.py"},
        "prompt": "fix a bug",
        "cwd": str(python_project),
    }
    monkeypatch.setattr(sys, "argv", ["neux", "pre-tool-use"])
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(payload)))
    captured = io.StringIO()
    monkeypatch.setattr(sys, "stderr", captured)

    exit_code = hook_entry.main()
    assert exit_code == 0
    out = captured.getvalue()
    assert "[NEUX] Contexto para api/main.py" in out
