"""Scanner tests for Python, TypeScript, SQL."""

from pathlib import Path

from neux.scanners.python_scanner import PythonScanner
from neux.scanners.sql_scanner import SQLScanner, scan_sql_in_source
from neux.scanners.typescript_scanner import TypeScriptScanner


def test_python_extracts_function_class_method() -> None:
    src = "class Foo:\n    def bar(self):\n        pass\n\ndef top_level():\n    pass\n"
    result = PythonScanner().scan_file(Path("mod.py"), src)
    kinds = {n.kind for n in result.nodes}
    assert "class" in kinds
    assert "method" in kinds
    assert "function" in kinds


def test_python_detects_fastapi_endpoint() -> None:
    src = '''
from fastapi import FastAPI
app = FastAPI()

@app.get("/ping")
async def ping():
    return "pong"
'''
    result = PythonScanner().scan_file(Path("api.py"), src)
    kinds = [n.kind for n in result.nodes]
    assert "endpoint" in kinds


def test_python_detects_env_var_via_getenv() -> None:
    src = 'import os\nAPI_KEY = os.getenv("API_KEY")\n'
    result = PythonScanner().scan_file(Path("cfg.py"), src)
    env_names = [n.name for n in result.nodes if n.kind == "env_var"]
    assert env_names == ["API_KEY"]


def test_typescript_detects_component_and_imports() -> None:
    src = """
import React from 'react';
export function Card({ title }: { title: string }) {
    return <div>{title}</div>;
}
"""
    result = TypeScriptScanner().scan_file(Path("card.tsx"), src)
    kinds = [n.kind for n in result.nodes]
    assert "component" in kinds
    # At least one import edge
    assert any(e.relation == "imports" for e in result.edges)


def test_typescript_detects_arrow_component() -> None:
    src = """
export const Badge = ({ count }: { count: number }) => <span>{count}</span>;
"""
    result = TypeScriptScanner().scan_file(Path("badge.tsx"), src)
    assert any(n.kind == "component" and n.name == "Badge" for n in result.nodes)


def test_sql_scanner_creates_table_and_columns() -> None:
    src = "CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT NOT NULL);"
    result = SQLScanner().scan_file(Path("001.sql"), src)
    assert any(n.kind == "table" and n.name == "users" for n in result.nodes)
    column_names = {n.name for n in result.nodes if n.kind == "column"}
    assert {"id", "email"} == column_names


def test_sql_inline_in_python_emits_edges() -> None:
    src = 'def g(): db.execute("SELECT id FROM users WHERE active = 1")'
    result = scan_sql_in_source(Path("q.py"), src, "q.g")
    assert any(e.relation == "reads_from" for e in result.edges)
