"""GraphEngine CRUD and impact analysis tests."""

from pathlib import Path

from neux.engine import GraphEngine, make_node_id


def test_make_node_id_strips_source_prefixes() -> None:
    # `src`, `app`, `lib`, `source` are all stripped — this is intentional.
    assert make_node_id("src/api/main.py", "function", "run") == "api.main.run"
    assert make_node_id("lib/core/util.ts", "class", "Foo") == "core.util.Foo"
    assert make_node_id("src/app/main.py", "function", "run") == "main.run"


def test_add_node_is_upsert(empty_engine: GraphEngine) -> None:
    empty_engine.add_module("app")
    empty_engine.add_node("app.foo", "function", "foo", "app/foo.py", 1, 10, "app", "python")
    empty_engine.add_node("app.foo", "function", "foo", "app/foo.py", 1, 20, "app", "python")
    node = empty_engine.get_node("app.foo")
    assert node is not None
    assert node["line_end"] == 20


def test_impact_analysis_walks_depth(empty_engine: GraphEngine) -> None:
    for nid in ("root.a", "root.b", "root.c", "root.d"):
        empty_engine.add_node(nid, "function", nid.split(".")[-1], "root.py", 0, 0, "root", "python")
    empty_engine.add_edge("root.a", "root.b", "calls")
    empty_engine.add_edge("root.b", "root.c", "calls")
    empty_engine.add_edge("root.c", "root.d", "calls")
    impact = empty_engine.impact_analysis("root.a", max_depth=5)
    assert [i["node_id"] for i in impact[1]] == ["root.b"]
    assert [i["node_id"] for i in impact[2]] == ["root.c"]
    assert [i["node_id"] for i in impact[3]] == ["root.d"]


def test_impact_analysis_blocks_cycles(empty_engine: GraphEngine) -> None:
    for nid in ("a", "b", "c"):
        empty_engine.add_node(nid, "function", nid, "x.py", 0, 0, "root", "python")
    empty_engine.add_edge("a", "b", "calls")
    empty_engine.add_edge("b", "c", "calls")
    empty_engine.add_edge("c", "a", "calls")  # cycle
    impact = empty_engine.impact_analysis("a", max_depth=10)
    # Must terminate; every node visited at most once
    all_ids = [i["node_id"] for depth in impact.values() for i in depth]
    assert sorted(all_ids) == ["b", "c"]


def test_fts_search_by_substring(empty_engine: GraphEngine) -> None:
    empty_engine.add_node("mod.UserService", "class", "UserService", "mod.py", 0, 0, "m", "python")
    empty_engine.add_node("mod.OrderBook", "class", "OrderBook", "mod.py", 0, 0, "m", "python")
    hits = empty_engine.search_nodes("UserService")
    assert [h["id"] for h in hits] == ["mod.UserService"]


def test_get_context_returns_deps_and_dependents(empty_engine: GraphEngine) -> None:
    empty_engine.add_module("m")
    empty_engine.add_node("m.a", "function", "a", "a.py", 0, 0, "m", "python")
    empty_engine.add_node("m.b", "function", "b", "b.py", 0, 0, "m", "python")
    empty_engine.add_node("m.c", "function", "c", "c.py", 0, 0, "m", "python")
    empty_engine.add_edge("m.a", "m.b", "calls")
    empty_engine.add_edge("m.c", "m.a", "calls")
    ctx = empty_engine.get_context("a.py")
    assert "b.py" in ctx["dependencies"]
    assert "c.py" in ctx["dependents"]


def test_stats_counts_by_kind(empty_engine: GraphEngine) -> None:
    empty_engine.add_node("x.A", "class", "A", "x.py", 0, 0, "x", "python")
    empty_engine.add_node("x.f", "function", "f", "x.py", 0, 0, "x", "python")
    stats = empty_engine.get_stats()
    assert stats["nodes"] == 2
    assert stats["by_kind"]["class"] == 1
    assert stats["by_kind"]["function"] == 1
