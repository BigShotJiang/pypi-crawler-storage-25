"""Schema + migrations + FTS tests."""

from pathlib import Path

from neux.db import get_connection, get_schema_version, init_db


def test_init_db_creates_core_tables(tmp_path: Path) -> None:
    conn = get_connection(tmp_path)
    init_db(conn)
    tables = {
        r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    for expected in (
        "nodes", "edges", "modules", "patterns", "conventions",
        "inconsistencies", "sessions", "context_profiles", "injection_rules",
    ):
        assert expected in tables
    assert get_schema_version(conn) == 1
    conn.close()


def test_init_db_is_idempotent(tmp_path: Path) -> None:
    conn = get_connection(tmp_path)
    init_db(conn)
    init_db(conn)  # should not raise
    count = conn.execute("SELECT COUNT(*) FROM injection_rules").fetchone()[0]
    assert count == 10  # seed size
    conn.close()


def test_fts_trigger_round_trip(tmp_path: Path) -> None:
    conn = get_connection(tmp_path)
    init_db(conn)
    conn.execute(
        "INSERT INTO nodes (id, kind, name, file_path) VALUES ('foo.bar', 'function', 'bar_fn', 'foo.py')"
    )
    hits = conn.execute("SELECT id FROM nodes_fts WHERE nodes_fts MATCH 'bar_fn'").fetchall()
    assert [h[0] for h in hits] == ["foo.bar"]
    conn.close()
