"""Detector tests — each detector against crafted input."""

from __future__ import annotations

from typing import Any

from neux.detectors import (
    DetectionContext,
    NamingDetector,
    ImportDetector,
    SecurityDetector,
    StyleDetector,
    APIDesignDetector,
)


def _node(
    id: str, kind: str, name: str, file_path: str, language: str = "python", **extra: Any
) -> dict:
    row = {
        "id": id,
        "kind": kind,
        "name": name,
        "file_path": file_path,
        "language": language,
        "line_start": 1,
        "line_end": 1,
        "module": "m",
        "metadata": None,
    }
    row.update(extra)
    return row


def test_naming_detects_non_snake_case_python_function() -> None:
    nodes = [
        _node("m.foo", "function", "FooBar", "m.py"),
        _node("m.bar", "function", "snake_fn", "m.py"),
        _node("m.baz", "function", "another_good", "m.py"),
    ]
    ctx = DetectionContext(nodes=nodes, project_info={"languages": ["python"]})
    results = NamingDetector().detect(ctx)
    snake = next(r for r in results if r.name == "python_snake_case_functions")
    assert snake.total_instances == 3
    assert len(snake.inconsistencies) == 1
    assert snake.inconsistencies[0].actual == "FooBar"


def test_import_detector_counts_alias_vs_relative() -> None:
    nodes = [_node("src.index", "file", "index", "src/index.ts", "typescript")]
    edges = [
        {"source_id": "src.index", "target_id": "a", "relation": "imports",
         "metadata": '{"module": "@/utils"}'},
        {"source_id": "src.index", "target_id": "b", "relation": "imports",
         "metadata": '{"module": "@/lib"}'},
        {"source_id": "src.index", "target_id": "c", "relation": "imports",
         "metadata": '{"module": "./local"}'},
    ]
    ctx = DetectionContext(nodes=nodes, edges=edges, project_info={"languages": ["typescript"]})
    results = ImportDetector().detect(ctx)
    assert any("alias" in r.name for r in results)


def test_security_flags_hardcoded_api_key() -> None:
    # Fixture chosen to trigger the ``generic_api_key`` pattern without
    # matching any real-world provider prefix (GitHub's secret scanning blocks
    # pushes containing e.g. ``sk_live_`` even inside test data).
    files = {"cfg.py": 'API_KEY = "fake_test_fixture_0123456789abcdef"\n'}
    ctx = DetectionContext(files=files, project_info={"languages": ["python"]})
    results = SecurityDetector().detect(ctx)
    secrets = next(r for r in results if r.name == "no_hardcoded_secrets")
    assert len(secrets.inconsistencies) == 1
    assert secrets.severity == "error"


def test_style_flags_hardcoded_hex_colors() -> None:
    files = {
        "button.tsx": "const bg = '#ff0000';",
        "tailwind.config.js": "module.exports = {};",
    }
    ctx = DetectionContext(files=files, project_info={"languages": ["typescript"]})
    results = StyleDetector().detect(ctx)
    tokens = next(r for r in results if r.name == "centralized_theme_tokens")
    assert len(tokens.inconsistencies) >= 1


def test_api_design_plural_routes() -> None:
    import json as _json
    nodes = [
        _node("a.list_users", "endpoint", "list_users", "api.py",
              metadata=_json.dumps({"endpoint": {"method": "GET", "path": "/users"}})),
        _node("a.list_orders", "endpoint", "list_orders", "api.py",
              metadata=_json.dumps({"endpoint": {"method": "GET", "path": "/orders"}})),
        _node("a.list_posts", "endpoint", "list_posts", "api.py",
              metadata=_json.dumps({"endpoint": {"method": "GET", "path": "/posts"}})),
    ]
    ctx = DetectionContext(nodes=nodes, project_info={"languages": ["python"]})
    results = APIDesignDetector().detect(ctx)
    assert any(r.name == "rest_plural_resources" for r in results)
