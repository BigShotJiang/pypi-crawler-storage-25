class RCMError(Exception):
    pass