import re
from .exceptions import ValidationError
from .enums import ChannelType


def validate_contact(name: str):
    """
    Validates general contact information.

    Args:
        name (str): The name of the contact.

    Raises:
        ValidationError: If the contact name is missing or empty.
    """
    if not name or not name.strip():
        raise ValidationError("Contact name is required")


def validate_channel(channel_type: int, value: str):
    """
    Validates a contact channel's type and value.

    Args:
        channel_type (int): The type of the channel (Fax, Phone, Email, etc.).
        value (str): The value to validate.

    Raises:
        ValidationError: If the value is missing or formatted incorrectly for its type.
    """
    if not value or not value.strip():
        raise ValidationError("Channel value is required")

    if channel_type == ChannelType.EMAIL:
        if "@" not in value:
            raise ValidationError("Invalid email")

    if channel_type in (ChannelType.FAX, ChannelType.PHONE):
        digits = re.sub(r"\D", "", value)
        if len(digits) < 7:
            raise ValidationError("Invalid phone/fax number")