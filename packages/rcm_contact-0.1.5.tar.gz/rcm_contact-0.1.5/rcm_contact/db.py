import os
from mysql.connector.pooling import MySQLConnectionPool
import mysql.connector

_pool = None


def get_pool():
    """
    Initializes and returns the MySQL connection pool.
    The pool configuration is loaded from environment variables.

    Returns:
        MySQLConnectionPool: The shared database connection pool.

    Raises:
        ValueError: If required database environment variables are missing.
    """
    global _pool

    if _pool is None:
        host = os.getenv("RCM_DB_HOST")
        user = os.getenv("RCM_DB_USER")
        password = os.getenv("RCM_DB_PASSWORD")
        database = os.getenv("RCM_DB_NAME")

        if not all([host, user, database]):
            raise ValueError("Missing required DB env vars: RCM_DB_HOST, RCM_DB_USER, RCM_DB_NAME")

        _pool = MySQLConnectionPool(
            pool_name="rcm_pool",
            pool_size=5,
            host=host,
            user=user,
            password=password,
            database=database,
        )

    return _pool


def get_connection():
    """
    Retrieves a single connection from the database connection pool.

    Returns:
        MySQLConnection: A connection object ready for use.
    """
    return get_pool().get_connection()