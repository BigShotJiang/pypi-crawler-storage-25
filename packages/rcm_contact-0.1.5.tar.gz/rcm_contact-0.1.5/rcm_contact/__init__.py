"""
RCM Contact Connector
---------------------
Package for managing contacts and communication channels in the RCM database.
"""
from .connector import (
    create_contact,
    update_contact,
    delete_contact,
    add_contact_channel,
    update_contact_channel,
    delete_contact_channel,
    search_contact_channels,
    get_contact_channels,
    get_preferred_channel,
    normalize_value,
)

from .models import (
    ContactCreate,
    ContactUpdate,
    ContactChannelCreate,
    ContactChannelUpdate,
)