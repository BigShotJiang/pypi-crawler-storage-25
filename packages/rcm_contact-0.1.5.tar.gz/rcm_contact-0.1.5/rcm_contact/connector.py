import re
from contextlib import closing
from dataclasses import asdict
from typing import Optional, List, Tuple

from .db import get_connection
from .models import (
    ContactCreate,
    ContactUpdate,
    ContactChannelCreate,
    ContactChannelUpdate,
)


# -------------------------
# NORMALIZATION
# -------------------------
def normalize_value(channel_type: int, value: str) -> Tuple[str, Optional[str]]:
    """
    Normalizes a contact channel value based on its type.
    For Fax and Phone types, extra characters are removed and extensions are extracted.
    For other types, values are trimmed and lowercased.

    Args:
        channel_type (int): The type of the channel (e.g., Fax, Phone, Email).
        value (str): The raw channel value to normalize.

    Returns:
        Tuple[str, Optional[str]]: A tuple containing (normalized_value, extension).
    """
    value = (value or "").strip()
    extension = None

    if channel_type in (1, 2):  # Fax / Phone
        ext_match = re.search(r'(?i)(?:ext|x|extension)\s*[:.]?\s*(\d+)', value)
        if ext_match:
            extension = ext_match.group(1)
            value = value[:ext_match.start()]

        normalized = re.sub(r"\D", "", value)
        return normalized, extension

    return value.lower(), None


# -------------------------
# CONTACT
# -------------------------
def create_contact(payload: ContactCreate) -> int:
    """
    Creates a new contact record in the database.

    Args:
        payload (ContactCreate): The contact details to create.

    Returns:
        int: The ID of the newly created contact.
    """
    query = """
        INSERT INTO CONTACT (
            CONTACT_TYPE, NAME, CLINIC_ID, DISPLAY_NAME, ORGANIZATION_NAME,
            DEPARTMENT, EXTERNAL_REF_TYPE, EXTERNAL_REF_ID, TAX_ID, NPI,
            ADDRESS1, ADDRESS2, CITY, STATE, ZIP, COUNTRY, NOTES, CREATED_BY
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """

    with closing(get_connection()) as conn:
        with closing(conn.cursor()) as cursor:
            cursor.execute(query, (
                payload.contact_type,
                payload.name,
                payload.clinic_id,
                payload.display_name,
                payload.organization_name,
                payload.department,
                payload.external_ref_type,
                payload.external_ref_id,
                payload.tax_id,
                payload.npi,
                payload.address1,
                payload.address2,
                payload.city,
                payload.state,
                payload.zip,
                payload.country,
                payload.notes,
                payload.created_by
            ))
            conn.commit()
            return cursor.lastrowid


def update_contact(contact_id: int, payload: ContactUpdate) -> bool:
    """
    Updates an existing contact record.

    Args:
        contact_id (int): The ID of the contact to update.
        payload (ContactUpdate): The fields to update.

    Returns:
        bool: True if the contact was successfully updated, False otherwise.
    """
    updates = []
    params = []

    payload_dict = asdict(payload)

    for field, value in payload_dict.items():
        if value is not None:
            if field == "is_active":
                updates.append("IS_ACTIVE = %s")
                params.append(int(value))
            else:
                updates.append(f"{field.upper()} = %s")
                params.append(value)

    if not updates:
        return False

    query = f"""
        UPDATE CONTACT
        SET {', '.join(updates)}
        WHERE CONTACT_ID = %s
          AND IS_DELETED = 0
    """
    params.append(contact_id)

    with closing(get_connection()) as conn:
        with closing(conn.cursor()) as cursor:
            cursor.execute(query, tuple(params))
            conn.commit()
            return cursor.rowcount > 0


def delete_contact(contact_id: int) -> bool:
    """
    Soft-deletes a contact and all its associated channels.

    Args:
        contact_id (int): The ID of the contact to delete.

    Returns:
        bool: True if the contact was successfully deleted, False otherwise.
    """
    with closing(get_connection()) as conn:
        with closing(conn.cursor()) as cursor:
            cursor.execute("""
                UPDATE CONTACT
                SET IS_DELETED = 1, IS_ACTIVE = 0
                WHERE CONTACT_ID = %s
            """, (contact_id,))
            affected = cursor.rowcount > 0

            cursor.execute("""
                UPDATE CONTACT_CHANNEL
                SET IS_DELETED = 1, IS_ACTIVE = 0
                WHERE CONTACT_ID = %s
            """, (contact_id,))

            conn.commit()
            return affected


# -------------------------
# CHANNEL
# -------------------------
def add_contact_channel(payload: ContactChannelCreate) -> int:
    """
    Adds a new communication channel (Phone, Fax, Email, etc.) for a contact.

    Args:
        payload (ContactChannelCreate): The channel details to add.

    Returns:
        int: The ID of the newly created channel.
    """
    normalized, extracted_ext = normalize_value(payload.channel_type, payload.value_raw)
    final_ext = payload.extension or extracted_ext

    with closing(get_connection()) as conn:
        with closing(conn.cursor(dictionary=True)) as cursor:

            # enforce one primary per contact + channel type
            if payload.is_primary:
                cursor.execute("""
                    UPDATE CONTACT_CHANNEL
                    SET IS_PRIMARY = 0
                    WHERE CONTACT_ID = %s
                      AND CHANNEL_TYPE = %s
                      AND IS_DELETED = 0
                """, (payload.contact_id, payload.channel_type))

            cursor.execute("""
                INSERT INTO CONTACT_CHANNEL (
                    CONTACT_ID, CHANNEL_TYPE, CHANNEL_PURPOSE,
                    VALUE_RAW, VALUE_NORMALIZED,
                    CHANNEL_LABEL, EXTENSION,
                    CONTACT_PERSON_NAME, HOURS_OF_OPERATION,
                    LANGUAGE, NOTES,
                    IS_PRIMARY, IS_VERIFIED, CREATED_BY
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                payload.contact_id,
                payload.channel_type,
                payload.channel_purpose,
                payload.value_raw,
                normalized,
                payload.channel_label,
                final_ext,
                payload.contact_person_name,
                payload.hours_of_operation,
                payload.language,
                payload.notes,
                int(payload.is_primary),
                int(payload.is_verified),
                payload.created_by
            ))

            conn.commit()
            return cursor.lastrowid


def update_contact_channel(channel_id: int, payload: ContactChannelUpdate) -> bool:
    """
    Updates an existing contact channel.

    Args:
        channel_id (int): The ID of the channel to update.
        payload (ContactChannelUpdate): The fields to update.

    Returns:
        bool: True if the channel was successfully updated, False otherwise.
    """
    with closing(get_connection()) as conn:
        with closing(conn.cursor(dictionary=True)) as cursor:
            cursor.execute("""
                SELECT CONTACT_CHANNEL_ID, CONTACT_ID, CHANNEL_TYPE, VALUE_RAW
                FROM CONTACT_CHANNEL
                WHERE CONTACT_CHANNEL_ID = %s
                  AND IS_DELETED = 0
            """, (channel_id,))
            existing = cursor.fetchone()

            if not existing:
                return False

            current_type = existing["CHANNEL_TYPE"]
            current_value = existing["VALUE_RAW"]
            contact_id = existing["CONTACT_ID"]

            new_type = payload.channel_type if payload.channel_type is not None else current_type
            new_value = payload.value_raw if payload.value_raw is not None else current_value

            updates = []
            params = []

            if payload.value_raw is not None or payload.channel_type is not None:
                normalized, extracted_ext = normalize_value(new_type, new_value)

                if payload.value_raw is not None:
                    updates.append("VALUE_RAW = %s")
                    params.append(payload.value_raw)

                if payload.channel_type is not None:
                    updates.append("CHANNEL_TYPE = %s")
                    params.append(payload.channel_type)

                updates.append("VALUE_NORMALIZED = %s")
                params.append(normalized)

                if payload.extension is None and extracted_ext:
                    updates.append("EXTENSION = %s")
                    params.append(extracted_ext)

            payload_dict = asdict(payload)

            for field, value in payload_dict.items():
                if value is None:
                    continue

                if field in ("value_raw", "channel_type", "extension"):
                    continue

                if field in ("is_primary", "is_verified", "is_active"):
                    updates.append(f"{field.upper()} = %s")
                    params.append(int(value))
                else:
                    updates.append(f"{field.upper()} = %s")
                    params.append(value)

            if payload.extension is not None:
                updates.append("EXTENSION = %s")
                params.append(payload.extension)

            if payload.is_primary:
                cursor.execute("""
                    UPDATE CONTACT_CHANNEL
                    SET IS_PRIMARY = 0
                    WHERE CONTACT_ID = %s
                      AND CHANNEL_TYPE = %s
                      AND CONTACT_CHANNEL_ID <> %s
                      AND IS_DELETED = 0
                """, (contact_id, new_type, channel_id))

            if not updates:
                return False

            query = f"""
                UPDATE CONTACT_CHANNEL
                SET {', '.join(updates)}
                WHERE CONTACT_CHANNEL_ID = %s
                  AND IS_DELETED = 0
            """
            params.append(channel_id)

            cursor.execute(query, tuple(params))
            conn.commit()
            return cursor.rowcount > 0


def delete_contact_channel(channel_id: int) -> bool:
    """
    Soft-deletes a contact channel.

    Args:
        channel_id (int): The ID of the channel to delete.

    Returns:
        bool: True if the channel was successfully deleted, False otherwise.
    """
    with closing(get_connection()) as conn:
        with closing(conn.cursor()) as cursor:
            cursor.execute("""
                UPDATE CONTACT_CHANNEL
                SET IS_DELETED = 1, IS_ACTIVE = 0
                WHERE CONTACT_CHANNEL_ID = %s
            """, (channel_id,))
            conn.commit()
            return cursor.rowcount > 0


# -------------------------
# LOOKUPS
# -------------------------
def get_contact_channels(contact_id: int, active_only: bool = True):
    """
    Retrieves all communication channels associated with a specific contact.

    Args:
        contact_id (int): The ID of the contact.
        active_only (bool): If True, only active and non-deleted channels are returned.

    Returns:
        List[dict]: A list of channel records.
    """
    query = """
        SELECT *
        FROM CONTACT_CHANNEL
        WHERE CONTACT_ID = %s
    """

    params = [contact_id]

    if active_only:
        query += " AND IS_ACTIVE = 1 AND IS_DELETED = 0"

    query += " ORDER BY CHANNEL_TYPE, CHANNEL_PURPOSE, CONTACT_CHANNEL_ID"

    with closing(get_connection()) as conn:
        with closing(conn.cursor(dictionary=True)) as cursor:
            cursor.execute(query, tuple(params))
            return cursor.fetchall()


def search_contact_channels(
    search_text: str,
    clinic_id: Optional[int] = None,
    channel_types: Optional[List[int]] = None,
    contact_types: Optional[List[int]] = None,
    purpose: Optional[int] = None,
    limit: int = 25
):
    """
    Searches for contacts and their channels based on text and optional filters.

    Args:
        search_text (str): The text to search for (names, values, etc.).
        clinic_id (Optional[int]): Filter by clinic ID.
        channel_types (Optional[List[int]]): Filter by channel types.
        contact_types (Optional[List[int]]): Filter by contact types.
        purpose (Optional[int]): Filter by channel purpose.
        limit (int): Maximum number of records to return.

    Returns:
        List[dict]: A list of matching contact and channel records.
    """
    search_text = (search_text or "").strip()
    if not search_text:
        return []

    digits_only = re.sub(r"\D", "", search_text)

    query = """
        SELECT
            c.CONTACT_ID,
            c.CONTACT_TYPE,
            c.NAME,
            c.DISPLAY_NAME,
            c.ORGANIZATION_NAME,
            c.DEPARTMENT,
            cc.CONTACT_CHANNEL_ID,
            cc.CHANNEL_TYPE,
            cc.CHANNEL_PURPOSE,
            cc.CHANNEL_LABEL,
            cc.VALUE_RAW,
            cc.VALUE_NORMALIZED,
            cc.EXTENSION,
            cc.IS_PRIMARY,
            cc.IS_VERIFIED
        FROM CONTACT c
        JOIN CONTACT_CHANNEL cc
          ON cc.CONTACT_ID = c.CONTACT_ID
        WHERE c.IS_ACTIVE = 1
          AND c.IS_DELETED = 0
          AND cc.IS_ACTIVE = 1
          AND cc.IS_DELETED = 0
          AND (
                c.NAME LIKE %s
             OR c.DISPLAY_NAME LIKE %s
             OR c.ORGANIZATION_NAME LIKE %s
             OR cc.VALUE_RAW LIKE %s
             OR cc.VALUE_NORMALIZED LIKE %s
          )
    """

    params = [
        f"%{search_text}%",
        f"%{search_text}%",
        f"%{search_text}%",
        f"%{search_text}%",
        f"%{digits_only or search_text.lower()}%"
    ]

    if clinic_id is not None:
        query += " AND (c.CLINIC_ID = %s OR c.CLINIC_ID IS NULL)"
        params.append(clinic_id)

    if channel_types:
        placeholders = ",".join(["%s"] * len(channel_types))
        query += f" AND cc.CHANNEL_TYPE IN ({placeholders})"
        params.extend(channel_types)

    if contact_types:
        placeholders = ",".join(["%s"] * len(contact_types))
        query += f" AND c.CONTACT_TYPE IN ({placeholders})"
        params.extend(contact_types)

    if purpose is not None:
        query += " AND cc.CHANNEL_PURPOSE IN (%s, 0)"
        params.append(purpose)

    query += """
        ORDER BY
            CASE WHEN cc.IS_PRIMARY = 1 THEN 0 ELSE 1 END,
            CASE WHEN cc.CHANNEL_PURPOSE = %s THEN 0 ELSE 1 END,
            c.NAME,
            cc.CHANNEL_LABEL,
            cc.VALUE_RAW
        LIMIT %s
    """
    params.extend([purpose if purpose is not None else -1, limit])

    with closing(get_connection()) as conn:
        with closing(conn.cursor(dictionary=True)) as cursor:
            cursor.execute(query, tuple(params))
            return cursor.fetchall()


def get_preferred_channel(contact_id: int, channel_type: int, purpose: Optional[int] = None):
    """
    Finds the most suitable communication channel for a given type and purpose.

    Args:
        contact_id (int): The ID of the contact.
        channel_type (int): The required channel type.
        purpose (Optional[int]): The specific purpose if any.

    Returns:
        Optional[dict]: The preferred channel record, or None if no match is found.
    """
    query = """
        SELECT cc.*
        FROM CONTACT_CHANNEL cc
        JOIN CONTACT c ON cc.CONTACT_ID = c.CONTACT_ID
        WHERE cc.CONTACT_ID = %s
          AND cc.CHANNEL_TYPE = %s
          AND cc.IS_ACTIVE = 1
          AND cc.IS_DELETED = 0
          AND c.IS_ACTIVE = 1
          AND c.IS_DELETED = 0
        ORDER BY
            CASE
                WHEN %s IS NOT NULL AND cc.CHANNEL_PURPOSE = %s AND cc.IS_PRIMARY = 1 THEN 1
                WHEN %s IS NOT NULL AND cc.CHANNEL_PURPOSE = %s THEN 2
                WHEN cc.CHANNEL_PURPOSE = 0 AND cc.IS_PRIMARY = 1 THEN 3
                WHEN cc.CHANNEL_PURPOSE = 0 THEN 4
                ELSE 5
            END ASC,
            cc.CONTACT_CHANNEL_ID
        LIMIT 1
    """

    with closing(get_connection()) as conn:
        with closing(conn.cursor(dictionary=True)) as cursor:
            cursor.execute(query, (
                contact_id,
                channel_type,
                purpose, purpose,
                purpose, purpose
            ))
            return cursor.fetchone()