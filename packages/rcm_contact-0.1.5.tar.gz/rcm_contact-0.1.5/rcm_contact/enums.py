from enum import IntEnum


class ContactType(IntEnum):
    """
    Standard classifications for different contact entities.
    """
    PAYOR = 1
    HOSPITAL = 2
    MEDICAL_PRACTICE = 3
    LAB = 4
    IMAGING_CENTER = 5
    PHARMACY = 6
    BILLING_VENDOR = 7
    OTHER = 8


class ChannelType(IntEnum):
    """
    The transmission medium or type of communication channel.
    """
    FAX = 1
    PHONE = 2
    EMAIL = 3
    PORTAL_URL = 4
    WEBSITE = 5
    TTY = 6
    OTHER = 7


class ChannelPurpose(IntEnum):
    """
    The intended use or department for a particular communication channel.
    """
    GENERAL = 0
    CLAIMS = 1
    ELIGIBILITY = 2
    PRIOR_AUTH = 3
    MEDICAL_RECORDS = 4
    APPEALS = 5
    BILLING = 6
    REFERRALS = 7
    SCHEDULING = 8
    CUSTOMER_SERVICE = 9
    CLAIM_STATUS = 10