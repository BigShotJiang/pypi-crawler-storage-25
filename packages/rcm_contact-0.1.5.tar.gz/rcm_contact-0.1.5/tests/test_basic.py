from rcm_contact import (
    create_contact,
    update_contact,
    delete_contact,
    add_contact_channel,
    update_contact_channel,
    delete_contact_channel,
    search_contact_channels,
    get_contact_channels,
    get_preferred_channel
)

from rcm_contact.models import (
    ContactCreate, ContactUpdate, 
    ContactChannelCreate, ContactChannelUpdate
)
from rcm_contact.enums import ChannelType, ChannelPurpose


def run_test():
    print("=== START TEST ===")

    # 1. Create contact with more fields
    contact = ContactCreate(
        contact_type=1,   # Payor
        name="Aetna Test",
        organization_name="Aetna Inc",
        display_name="Aetna Health"
    )

    contact_id = create_contact(contact)
    print(f"[OK] Contact created: {contact_id}")

    # 2. Add channels (including fax with extension)
    fax_id = add_contact_channel(ContactChannelCreate(
        contact_id=contact_id,
        channel_type=ChannelType.FAX,
        value_raw="800-555-1111 ext 456",
        channel_purpose=ChannelPurpose.GENERAL,
        is_primary=True
    ))

    # Add email with digits 
    email_id = add_contact_channel(ContactChannelCreate(
        contact_id=contact_id,
        channel_type=ChannelType.EMAIL,
        value_raw="claims123@testaetna.com"
    ))

    print(f"[OK] Channels added: fax={fax_id}, email={email_id}")

    # 3. Search by name
    results = search_contact_channels("Aetna Test")
    print(f"[OK] Search by name → {len(results)} results")

    # 4. Search by fax
    results = search_contact_channels("8005551111")
    print(f"[OK] Search by fax → {len(results)} results")

    # 5. Search by email with digits (testing the regex fix)
    results = search_contact_channels("claims123@testaetna.com")
    print(f"[OK] Search by email with digits → {len(results)} results")
    
    # 6. Update Contact
    update_res = update_contact(contact_id, ContactUpdate(name="Aetna Test Updated"))
    print(f"[OK] Contact updated -> {update_res}")
    
    # 7. Update Channel
    update_chan_res = update_contact_channel(email_id, ContactChannelUpdate(is_primary=True))
    print(f"[OK] Channel updated -> {update_chan_res}")

    # 8. Get preferred channel
    preferred = get_preferred_channel(
        contact_id=contact_id,
        channel_type=ChannelType.FAX,
        purpose=ChannelPurpose.GENERAL
    )

    print(f"[OK] Preferred fax channel → {preferred and preferred.get('VALUE_NORMALIZED')}")
    
    # 9. Get all channels
    all_chans = get_contact_channels(contact_id)
    print(f"[OK] All channels count -> {len(all_chans)}")

    # 10. Delete channel
    del_chan = delete_contact_channel(email_id)
    print(f"[OK] Deleted email channel -> {del_chan}")

    # 11. Delete contact
    del_cont = delete_contact(contact_id)
    print(f"[OK] Deleted contact -> {del_cont}")
    
    # Verify preferred channel on deleted contact returns None
    preferred_after_del = get_preferred_channel(
        contact_id=contact_id,
        channel_type=ChannelType.FAX,
        purpose=ChannelPurpose.GENERAL
    )
    print(f"[OK] Preferred channel after contact delete -> {preferred_after_del}")

    print("=== TEST COMPLETED ===")


if __name__ == "__main__":
    run_test()