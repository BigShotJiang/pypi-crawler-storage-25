import base64
from io import BytesIO

import requests
import logging
from PIL import Image, ImageOps
from .base import BaseVideoProvider
from ..contracts import VideoGenerationRequest, VideoGenerationResponse, VideoMode
from ..artifacts import VideoStatusArtifact

logger = logging.getLogger(__name__)

ASPECT_RATIO_MAP = {
    "16:9": "1280x720",
    "9:16": "720x1280",
    "1:1": "720x720",
}


class OpenAISoraProvider(BaseVideoProvider):
    provider_name = "openai"
    BASE_URL = "https://api.openai.com/v1/videos"

    def _normalize_image_to_size(self, image_reference, size):
        if not size or "x" not in size:
            return image_reference

        if isinstance(image_reference, dict):
            if "file_id" in image_reference:
                return {"file_id": image_reference["file_id"]}
            source_url = image_reference.get("image_url") or image_reference.get("url")
            if not source_url:
                raise ValueError("Unsupported image reference for OpenAI Sora")
        else:
            if not isinstance(image_reference, str) or not image_reference:
                raise ValueError("img2video mode requires a valid image reference")
            if image_reference.startswith("file-"):
                return {"file_id": image_reference}
            source_url = image_reference

        width_str, height_str = size.split("x", 1)
        target_size = (int(width_str), int(height_str))

        if source_url.startswith("data:"):
            header, encoded = source_url.split(",", 1)
            mime_type = header[5:].split(";")[0] or "image/png"
            image_bytes = base64.b64decode(encoded)
        else:
            response = requests.get(source_url, timeout=30)
            response.raise_for_status()
            mime_type = response.headers.get("Content-Type", "").split(";")[0].strip()
            image_bytes = response.content

        with Image.open(BytesIO(image_bytes)) as image:
            image = ImageOps.exif_transpose(image)
            has_alpha = "A" in image.getbands()
            fit_image = ImageOps.fit(
                image,
                target_size,
                method=Image.Resampling.LANCZOS,
                centering=(0.5, 0.5),
            )

            output = BytesIO()
            if has_alpha:
                output_mime_type = "image/png"
                fit_image.save(output, format="PNG")
            else:
                output_mime_type = "image/jpeg"
                fit_image = fit_image.convert("RGB")
                fit_image.save(output, format="JPEG", quality=95)

        encoded_image = base64.b64encode(output.getvalue()).decode("utf-8")
        return {
            "image_url": f"data:{output_mime_type};base64,{encoded_image}",
        }

    def _build_input_reference(self, image_reference):
        if isinstance(image_reference, dict):
            if "file_id" in image_reference:
                return {"file_id": image_reference["file_id"]}
            if "image_url" in image_reference:
                return {"image_url": image_reference["image_url"]}
            if "url" in image_reference:
                return {"image_url": image_reference["url"]}
            raise ValueError("Unsupported image reference for OpenAI Sora")

        if not isinstance(image_reference, str) or not image_reference:
            raise ValueError("img2video mode requires a valid image reference")

        if image_reference.startswith("file-"):
            return {"file_id": image_reference}

        return {"image_url": image_reference}

    def _get_headers(self):
        if not self.api_key:
            raise ValueError("API Key is required for OpenAI Sora")

        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def start_generation(
        self, request: VideoGenerationRequest
    ) -> VideoGenerationResponse:
        request.validate()

        mode = (getattr(request, "mode", VideoMode.TEXT_TO_VIDEO.value) or "").lower()
        if mode == VideoMode.VIDEO_TO_VIDEO.value:
            raise NotImplementedError("video2video is planned but not enabled yet")

        # size = ASPECT_RATIO_MAP.get(request.aspect_ratio, "1280x720")

        is_1080p = request.config and request.config.get("resolution") == "1080p"
        if request.aspect_ratio == "16:9":
            size = "1920x1080" if is_1080p else "1280x720"
        elif request.aspect_ratio == "9:16":
            size = "1080x1920" if is_1080p else "720x1280"
        else:
            size = "1280x720"

        payload = {
            "model": request.model,
            "prompt": request.prompt,
            "size": size,
        }

        if request.config and "duration" in request.config:
            payload["seconds"] = str(request.config["duration"])
        elif request.duration_seconds:
            payload["seconds"] = str(request.duration_seconds)

        if mode == VideoMode.IMG_TO_VIDEO.value:
            if not request.images:
                raise ValueError("img2video mode requires image reference")
            input_reference = self._build_input_reference(request.images[0])
            payload["input_reference"] = self._normalize_image_to_size(
                input_reference, size
            )

        if request.config:
            if "quality" in request.config:
                payload["quality"] = request.config["quality"]
            if "n" in request.config:
                payload["n"] = request.config["n"]

        try:
            response = requests.post(
                self.BASE_URL,
                headers=self._get_headers(),
                json=payload,
                timeout=30,
            )

            response.raise_for_status()
            data = response.json()

            job_id = data.get("id")
            if not job_id:
                raise RuntimeError(f"No job ID returned. Response: {data}")

            return VideoGenerationResponse.now(
                provider=self.provider_name,
                model=request.model,
                job_id=job_id,
                status="queued",
            )

        except requests.exceptions.HTTPError as e:
            try:
                error_detail = e.response.json()

            except Exception:
                error_detail = e.response.text if e.response else str(e)
            raise RuntimeError(f"OpenAI Sora start failed: {error_detail}")
        except Exception as e:
            raise RuntimeError(f"OpenAI Sora Start Failed: {str(e)}")

    def check_status(self, job_id: str) -> VideoStatusArtifact:

        url = f"{self.BASE_URL}/{job_id}"
        try:
            response = requests.get(url, headers=self._get_headers(), timeout=30)

            response.raise_for_status()
            data = response.json()

            status_map = {
                "queued": "pending",
                "in_progress": "processing",
                "processing": "processing",
                "completed": "completed",
                "failed": "failed",
                "expired": "expired",
            }

            standard_status = status_map.get(data.get("status"), "processing")

            result_url = None
            if standard_status == "completed":
                result_url = f"{self.BASE_URL}/{job_id}/content"

            error_msg = None
            if standard_status == "failed":
                error_obj = data.get("error", {})
                if isinstance(error_obj, dict):
                    error_msg = error_obj.get("message", "Unknown failure")
                else:
                    error_msg = str(error_obj)

            return VideoStatusArtifact(
                provider_job_id=job_id,
                status=standard_status,
                result_url=result_url,
                error=error_msg,
            )

        except Exception as e:
            return VideoStatusArtifact(
                provider_job_id=job_id, status="processing", error=str(e)
            )

    def download_video(self, url: str) -> bytes:
        response = requests.get(url, headers=self._get_headers(), timeout=60)
        response.raise_for_status()
        return response.content
