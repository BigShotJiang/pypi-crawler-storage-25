import base64
import mimetypes
import logging

import requests
from google import genai
from google.genai import types

from .base import BaseVideoProvider
from ..contracts import VideoGenerationRequest, VideoGenerationResponse, VideoMode
from ..artifacts import VideoStatusArtifact

logger = logging.getLogger(__name__)


class GoogleVeoProvider(BaseVideoProvider):
    provider_name = "google"
    DOWNLOAD_HOST = "generativelanguage.googleapis.com"

    def _get_client(self):
        if not self.api_key:
            raise ValueError("API Key is required for Google Veo")
        return genai.Client(api_key=self.api_key)

    def _normalize_model_name(self, model_name: str) -> str:
        if not model_name:
            raise ValueError("Google Veo model is required")
        return model_name[7:] if model_name.startswith("models/") else model_name

    def _build_image(self, image_reference):
        if isinstance(image_reference, dict):
            if image_reference.get("gcs_uri"):
                return types.Image(
                    gcs_uri=image_reference["gcs_uri"],
                    mime_type=image_reference.get("mime_type")
                    or image_reference.get("mimeType")
                    or "image/png",
                )
            if image_reference.get("url"):
                image_reference = image_reference["url"]
            elif image_reference.get("inlineData"):
                inline_data = image_reference["inlineData"] or {}
                return types.Image(
                    image_bytes=base64.b64decode(inline_data["data"]),
                    mime_type=inline_data.get("mimeType", "image/png"),
                )
            elif "imageBytes" in image_reference:
                image_bytes = image_reference["imageBytes"]
                if isinstance(image_bytes, str):
                    image_bytes = base64.b64decode(image_bytes)
                return types.Image(
                    image_bytes=image_bytes,
                    mime_type=image_reference.get("mimeType", "image/png"),
                )
            elif "mimeType" in image_reference and "data" in image_reference:
                image_bytes = image_reference["data"]
                if isinstance(image_bytes, str):
                    image_bytes = base64.b64decode(image_bytes)
                return types.Image(
                    image_bytes=image_bytes,
                    mime_type=image_reference["mimeType"],
                )
            else:
                raise ValueError("Unsupported image reference for Google Veo")

        if not isinstance(image_reference, str) or not image_reference:
            raise ValueError("img2video mode requires a valid image reference")

        if image_reference.startswith("gs://"):
            mime_type = mimetypes.guess_type(image_reference)[0] or "image/png"
            return types.Image(gcs_uri=image_reference, mime_type=mime_type)

        if image_reference.startswith("data:"):
            header, encoded_data = image_reference.split(",", 1)
            mime_type = header[5:].split(";")[0] or "application/octet-stream"
            return types.Image(
                image_bytes=base64.b64decode(encoded_data),
                mime_type=mime_type,
            )

        if image_reference.startswith(("http://", "https://")):
            response = requests.get(image_reference, timeout=30)
            response.raise_for_status()

            mime_type = response.headers.get("Content-Type", "").split(";")[0].strip()
            if not mime_type:
                mime_type = (
                    mimetypes.guess_type(image_reference.split("?", 1)[0])[0]
                    or "application/octet-stream"
                )

            if not mime_type.startswith("image/"):
                raise ValueError(
                    f"Google Veo expected an image URL, received '{mime_type}'"
                )

            return types.Image(image_bytes=response.content, mime_type=mime_type)

        raise ValueError("Unsupported image reference for Google Veo")

    def _build_config(self, request: VideoGenerationRequest, is_veo3: bool):
        config_kwargs = {
            "aspect_ratio": request.aspect_ratio,
            "number_of_videos": 1,
        }

        if request.duration_seconds:
            duration = int(request.duration_seconds)
            if is_veo3:
                if duration <= 4:
                    duration = 4
                elif duration <= 6:
                    duration = 6
                else:
                    duration = 8
            else:
                if duration < 5:
                    duration = 5
                elif duration > 8:
                    duration = 8
            config_kwargs["duration_seconds"] = duration

        if request.negative_prompt:
            config_kwargs["negative_prompt"] = request.negative_prompt

        if request.config:
            if "seed" in request.config:
                config_kwargs["seed"] = int(request.config["seed"])
            if "resolution" in request.config:
                config_kwargs["resolution"] = request.config["resolution"]
            if "person_generation" in request.config:
                config_kwargs["person_generation"] = request.config[
                    "person_generation"
                ]

        return types.GenerateVideosConfig(**config_kwargs)

    def _operation_from_name(self, job_id: str):
        return types.GenerateVideosOperation(name=job_id)

    def _extract_result_url(self, operation):
        response = getattr(operation, "response", None) or getattr(operation, "result", None)
        generated_videos = getattr(response, "generated_videos", None) or []
        if not generated_videos:
            return None

        video = getattr(generated_videos[0], "video", None)
        if not video:
            return None

        video_url = getattr(video, "uri", None)
        if not video_url:
            return None

        if self.DOWNLOAD_HOST in video_url:
            sep = "&" if "?" in video_url else "?"
            video_url = f"{video_url}{sep}key={self.api_key}"

        return video_url

    def check_status(self, job_id: str) -> VideoStatusArtifact:
        try:
            client = self._get_client()
            operation = client.operations.get(self._operation_from_name(job_id))
            logger.info(
                "Google Veo poll for job %s returned done=%s",
                job_id,
                getattr(operation, "done", False),
            )

            if not getattr(operation, "done", False):
                return VideoStatusArtifact(provider_job_id=job_id, status="processing")

            error_obj = getattr(operation, "error", None)
            if error_obj:
                if isinstance(error_obj, dict):
                    error_message = error_obj.get("message") or str(error_obj)
                else:
                    error_message = str(error_obj)
                return VideoStatusArtifact(
                    provider_job_id=job_id,
                    status="failed",
                    error=error_message,
                )

            video_url = self._extract_result_url(operation)
            if not video_url:
                return VideoStatusArtifact(
                    provider_job_id=job_id,
                    status="failed",
                    error="No video URL found in response",
                )

            return VideoStatusArtifact(
                provider_job_id=job_id, status="completed", result_url=video_url
            )
        except Exception as e:
            logger.exception("Google Veo check_status failed for job %s", job_id)
            return VideoStatusArtifact(
                provider_job_id=job_id, status="failed", error=str(e)
            )

    def start_generation(
        self, request: VideoGenerationRequest
    ) -> VideoGenerationResponse:
        client = self._get_client()
        request.validate()

        mode = (getattr(request, "mode", VideoMode.TEXT_TO_VIDEO.value) or "").lower()
        if mode == VideoMode.VIDEO_TO_VIDEO.value:
            raise NotImplementedError("video2video is planned but not enabled yet")

        model_name = self._normalize_model_name(request.model)
        is_veo3 = "veo-3" in model_name.lower()
        image = None
        if mode == VideoMode.IMG_TO_VIDEO.value:
            if not request.images:
                raise ValueError("img2video mode requires image reference")
            image = self._build_image(request.images[0])

        video_config = self._build_config(request, is_veo3)

        try:
            operation = client.models.generate_videos(
                model=model_name,
                prompt=request.prompt,
                image=image,
                config=video_config,
            )
            operation_name = getattr(operation, "name", None)

            if not operation_name:
                raise RuntimeError(
                    f"No operation ID returned. Response: {operation}"
                )

            return VideoGenerationResponse.now(
                provider=self.provider_name,
                model=f"models/{model_name}",
                job_id=operation_name,
                status="queued",
            )
        except Exception as e:
            raise RuntimeError(f"Google Veo Start Failed: {str(e)}")
