# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.0.1] — 2026-05-23

### Added

- Initial package name reservation on PyPI. No functional code yet.
