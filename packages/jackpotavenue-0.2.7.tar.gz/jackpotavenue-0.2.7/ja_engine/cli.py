import sys
import time
import random
import shutil
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt, IntPrompt
from rich.live import Live

# --- CLEAN ENGINE IMPORT PROTOCOL ---
try:
    # 1. Local Development (VS Code/WSL)
    from ja_engine.engine import (
        draw_powerball, draw_megamillions, draw_multimatch, draw_gh_lottery
    )
except ImportError:
    try:
        # 2. Production (iPhone/PyPI Environment)
        # # type: ignore silences the yellow 'ReportMissingModuleSource' warning
        from jackpotavenue.engine import ( # type: ignore
            draw_powerball, draw_megamillions, draw_multimatch, draw_gh_lottery
        )
    except ImportError:
        # 3. Emergency Fallback
        from engine import draw_powerball, draw_megamillions, draw_multimatch, draw_gh_lottery

def get_dynamic_console():
    """Forces narrow width for iPhone/mobile terminals."""
    width, _ = shutil.get_terminal_size(fallback=(44, 20))
    return Console(width=min(width, 44), force_terminal=True)

console = get_dynamic_console()

def print_banner():
    """High-visibility banner for small screens."""
    banner = """
  __  __  ____  _   _  ______ __   __
 |  \/  |/ __ \| \ | ||  ____|\ \   / /
 | \  / | |  | |  \| || |__    \ \_/ / 
 | |\/| | |  | | . ` ||  __|    \   /  
 | |  | | |__| | |\  || |____    | |   
 |_|  |_|\____/|_| \_||______|   |_|   
    """
    console.print(f"[bold green]{banner}[/bold green]")
    console.print("[bold white on blue] >>> JACKPOT AVENUE: v0.2.7 <<< [/]", justify="center")

def format_ticket(numbers, bonus=None, theme="blue"):
    """Creates clear, spaced output for lottery numbers."""
    nums_str = " ".join(f"[bold white on {theme}] {n:02} [/]" for n in sorted(numbers))
    if bonus:
        return f"{nums_str}   [bold white]●[/] [bold white on red] {bonus:02} [/]"
    return nums_str

def generate_spinning_content(game_label, theme, has_bonus):
    """Provides visual feedback during 'drawing'."""
    count = 6 if "MULTI" in game_label else 5
    fake_nums = [random.randint(1, 60) for _ in range(count)]
    fake_bonus = random.randint(1, 25) if has_bonus else None
    return format_ticket(fake_nums, fake_bonus, theme)

def main():
    console.clear()
    print_banner()

    games = {
        "1": ("POWERBALL", draw_powerball, "blue", True),
        "2": ("MEGA MILLIONS", draw_megamillions, "magenta", True),
        "3": ("MULTI-MATCH", draw_multimatch, "dark_green", False),
        "4": ("GHANA 5/90", lambda: draw_gh_lottery(5), "red", False)
    }

    while True:
        menu = Table(title="\n[bold white]--- SELECT GAME ---[/]", show_header=False, box=None)
        menu.add_row("[blue]1)[/] Powerball", "[bold red][US][/]")
        menu.add_row("[magenta]2)[/] Mega Millions", "[bold red][US][/]")
        menu.add_row("[green]3)[/] Multi-Match", "[blue][MD][/]")
        menu.add_row("[red]4)[/] GH Lottery", "[white][GH][/]")
        menu.add_row("[bold white]5) EXIT[/]", "")
        
        console.print(menu)
        choice = Prompt.ask("[bold green]Choice[/]", choices=["1", "2", "3", "4", "5"], default="5")

        if choice == "5":
            console.print("\n[bold red]💸 GOOD LUCK! 💸[/]\n")
            break

        num_tickets = IntPrompt.ask("[bold cyan]Tickets[/]", default=1)
        label, func, theme, has_bonus = games[choice]

        console.clear()
        print_banner()

        for i in range(1, num_tickets + 1):
            with Live(console=console, refresh_per_second=20, transient=False) as live:
                for _ in range(12): 
                    live.update(Panel(
                        generate_spinning_content(label, theme, has_bonus),
                        title=f"[bold yellow]DRAWING #{i}[/]",
                        border_style="yellow",
                        expand=False,
                        padding=(0, 1)
                    ))
                    time.sleep(0.05)

                result = func()
                nums, bonus = result if has_bonus else (result, None)
                
                final_panel = Panel(
                    format_ticket(nums, bonus, theme),
                    title=f"[bold white]{label} FINAL[/]",
                    border_style="green",
                    expand=False,
                    padding=(0, 1)
                )
                live.update(final_panel)
                console.print(final_panel)
            
            time.sleep(0.2)
        
        # 3-second auto-pause for mobile readability
        console.print("\n[dim italic]Returning to menu in 3s...[/]")
        time.sleep(3.0) 
        console.clear()
        print_banner()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print("\n[bold red]Terminated.[/]")
        sys.exit(0)