# ja_engine/engine.py
import random

def draw_powerball():
    white_balls = sorted(random.sample(range(1, 70), 5))
    powerball = random.randint(1, 26)
    return white_balls, powerball

def draw_megamillions():
    white_balls = sorted(random.sample(range(1, 71), 5))
    megaball = random.randint(1, 25)
    return white_balls, megaball

def draw_multimatch():
    return sorted(random.sample(range(1, 44), 6))

def draw_gh_lottery(pick_size=5):
    return sorted(random.sample(range(1, 91), pick_size))