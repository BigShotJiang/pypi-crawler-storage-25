from typing import Any, Dict
#Z1
def ZObject(type: str, **properties: Any) -> Dict[str, Any]:
    """
    Constructs a Z1/Object with a specified type and properties.
    
    Args:
        type (str): The ZID representing the object type (Z1K1).
        **properties: Other keys and their corresponding values.

    Returns:
        Dict[str, Any]: A dictionary representing the ZObject.
    """
    zObj = {"Z1K1": type}
    zObj.update(properties)
    return zObj

#Z7
def ZFunctionCall(function: str, *arguments: Any) -> Dict[str, any]:
    """
    Constructs a Z7/Function call with a specified function and arguments.

    Args:
        function (str): The ZID of the function being called (Z7K1).
        *arguments: The list of arguments being applied.
    Returns:
        Dict[str, Any]: A dictionary representing the ZFunctionCall.
    """
    keyId = lambda index: f"{function}K{index + 1}"
    keys = {"Z7K1": function}
    for num, i in enumerate(arguments):
        keys.update({keyId(num): i})
    return ZObject("Z7", **keys)

#Z9
def ZReference(item: str) -> Dict[str, Any]:
    """
    Constructs a Z9/Reference with a specified item.

    Args:
        item (str): The ZID of the item to be referenced to (Z9K1).
    Returns:
        Dict[str, any]: A dictionary representing the ZReference.
    """
    return ZObject("Z9", Z9K1=item)

#Z11
def ZMonolingualText(language: str, content: str) -> Dict[str, Any]:
    """
    Constructs a Z11/Monolingual text with a specified language and content.
    
    Args:
        language (str): the ZID of the language the text is in.
        content (str): the text content of the monolingual text.
    Returns:
        Dict[str, any]: A dictionary representing the ZMonolingualText.
    """
    return ZObject("Z11", Z11K1=ZReference(language), Z11K2=content)

#Z40
def ZBoolean(value: bool) -> Dict[str, Any]:
    """
    Constructs a Z40/Boolean based on a Python boolean.
    
    Args:
        value (bool): whether the boolean is true or false.
    Returns:
        Dict[str, any]: A dictionary representing the ZBoolean.
    """
    return ZObject("Z40", Z40K1=ZReference("Z41" if value else "Z42"))

def ZNaturalNumber(num: int) -> Dict[str, Any]:
    """
    Constructs a Z13518/Natural number based on a non-negative Python integer.

    Args:
        num (int): a non-negative integer corresponding to the number.

    Returns:
        Dict[str, any]: A dictionary representing the ZNaturalNumber.
    """
    return ZObject("Z13518", Z13518K1=str(abs(num)))

def ZHTMLFragment(content: str) -> Dict[str, Any]:
    """
    Constructs a Z89/HTML fragment based on a string containing HTML content.

    Args:
        content (str): a string representing the content of the fragment.

    Returns:
        Dict[str, any]: A dictionary representing the ZHTMLFragment.    
    """
    return ZObject("Z89", Z89K1=content)

def ZSign(num: int) -> Dict[str, Any]:
    """
    Constructs a Z16659/Sign based on an int.
    
    Args:
        num (int): the number from which to get the sign (e.g. -1 = Negative).
    
    Returns:
        Dict[str, any]: A dictionary representing the ZSign.
    """
    sign = "Z16660"
    if num == 0:
        sign = "Z16661"
    elif num < 0:
        sign = "Z16662"
    return ZObject("Z16659", Z16659K1=ZReference(sign))

def ZInteger(num: int) -> Dict[str, Any]:
    """
    Constructs a Z16683/Integer based on an int.
    
    Args:
        num (int): the number to convert to an Integer.
    Returns:
        Dict[str, any]: A dictionary representing the ZInteger.
    """
    return ZObject("Z16683", Z16683K1=ZSign(num), Z16683K2=ZNaturalNumber(num))

def ZWikidataItemReference(id: str) -> Dict[str, Any]:
    """
    Constructs a Z6091/Wikidata Item Reference based on a QID string.
    
    Args:
        id (str): the QID of the item.
    Returns:
        Dict[str, any]: A dictionary representing the ZWikidataItemReference."""
    return ZObject("Z6091", Z6091K1=id)

def ZWikidataPropertyReference(id: str) -> Dict[str, Any]:
    """
    Constructs a Z6092/Wikidata Property Reference based on a PID string.
    
    Args:
        id (str): the PID of the item.
    Returns:
        Dict[str, any]: A dictionary representing the ZWikidataPropertyReference."""
    return ZObject("Z6092", Z6092K1=id)


def ZWikidataLexemeFormReference(id: str) -> Dict[str, Any]:
    """
    Constructs a Z6094/Wikidata Lexeme Form Reference based on an LFID string.
    
    Args:
        id (str): the LFID of the item.
    Returns:
        Dict[str, any]: A dictionary representing the ZWikidataLexemeFormReference."""
    return ZObject("Z6094", Z6094K1=id)


def ZWikidataLexemeReference(id: str) -> Dict[str, Any]:
    """
    Constructs a Z6095/Wikidata Lexeme Reference based on an LID string.
    
    Args:
        id (str): the LID of the item.
    Returns:
        Dict[str, any]: A dictionary representing the ZWikidataLexemeReference."""
    return ZObject("Z6095", Z6095K1=id)

def ZWikidataLexemeSenseReference(id: str) -> Dict[str, Any]:
    """
    Constructs a Z6096/Wikidata Lexeme Sense Reference based on an LSID string.
    
    Args:
        id (str): the LSID of the item.
    Returns:
        Dict[str, any]: A dictionary representing the ZWikidataLexemeSenseReference."""
    return ZObject("Z6096", Z6096K1=id)

def ZRationalNumber(numerator: int, denominator: int) -> Dict[str, Any]:
    """
    Constructs a Z19677/Rational number based on a numerator and denominator.
    
    Args:
        numerator (int): the numerator of the rational.
        denominator (int): the denominator of the rational.
    Returns:
        Dict[str, any]: A dictionary representing the ZRationalNumber."""
    if denominator == 0:
        return ZObject("Z19677", Z19677K1=ZSign(0), Z19677K2=numerator, Z19677K3=0)
    sign = "Z16660"
    if numerator == 0:
        sign = "Z16661"
    elif numerator / denominator < 0:
        sign = "Z16662"
    sign = ZObject("Z16659", Z16659K1=ZReference(sign))
    return ZObject("Z19677", Z19677K1=sign, Z19677K2=ZNaturalNumber(numerator), Z19677K3=ZNaturalNumber(denominator))

def ZKleenean(number: int):
    """
    Constructs a Z22112/Kleenean based on an int.
    
    Args:
        number (int): the numerical representation of the Kleenean, 1 = True, 0 = Maybe, -1 = False.
    Returns:
        Dict[str, any]: A dictionary representing the ZKleenean."""
    id = "Z22113"
    if number == 0:
        id = "Z22114"
    elif number == -1:
        id = "Z22115"
    return ZObject("Z22112", Z22112K1=id)