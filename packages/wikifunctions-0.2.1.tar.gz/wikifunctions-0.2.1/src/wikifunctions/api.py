import json
import requests

def call(zid: str, *args) -> dict:
    """
    Executes a Wikifunction by its ZID
    Args:
        zid (str): The ZID of the function to call (e.g., 'Z801'/Echo).
        *args: Positional arguments to pass to the function (ZNNNKX)

    Returns:
        dict: The JSON response from the Wikifunctions API.
    """
    API_URL = "https://www.wikifunctions.org/w/api.php"
    ZFunctionCall = {
        "Z1K1": "Z7",  # Type
        "Z7K1": zid    # Function being called
    }
    
    # map args to correct keys
    for i, arg in enumerate(args, start=1):
        ZFunctionCall[f"{zid}K{i}"] = arg

    # payload
    payload = {
        "action": "wikifunctions_run", 
        "format": "json",
        "function_call": json.dumps(ZFunctionCall),
        "origin": "*"
    }

    headers = {
        "User-Agent": "wikifunctions (https://pypi.org/project/wikifunctions/) (https://www.wikifunctions.org/wiki/User:Feeglgeef/wikifunctions-pip)"
    }

    #send request
    response = requests.post(API_URL, data=payload, headers=headers)
    response.raise_for_status()
    
    #in JSON format
    jsonResponse = response.json()

    #get the Z22 
    z22 = jsonResponse["wikifunctions_run"]["data"]

    return json.loads(z22)