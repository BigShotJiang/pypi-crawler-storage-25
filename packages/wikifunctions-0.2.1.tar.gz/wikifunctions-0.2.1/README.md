# Wikifunctions python library
This library allows you to interface with the Wikifunctions API in your Python code. Wikifunctions is a project of more than 3,800 community-created and community-maintained functions. You can find a list of these on the [catalogue](https://www.wikifunctions.org/wiki/Wikifunctions:Catalogue).
## Installation

```bash
pip install wikifunctions
```

## Usage examples
```python
import wikifunctions as wf
result = wf.call("Z801", "echo")["Z22K1"]
print(result)
```

This code will print "echo", because [Z801](https://www.wikifunctions.org/view/en/Z801) is the echo function.
### Building ZObjects
Wikifunctions requires strict JSON structures for its arguments. This library includes helper functions to make building these native types much easier in Python:

```python
import wikifunctions as wf

result = wf.call("Z801", wf.ZNaturalNumber(4))["Z22K1"]
print(result["Z13518K1"])
```
This code will print "4." To see a full list of ZObject building functions and their parameters, see below.
## Disclaimers
* **Community-Maintained**: Wikifunctions is completely community-created and maintained. The author of this project does not control the underlying logic of functions. Users should check that the functions work as expected before using them, and be aware that anyone with functioneer rights on the Wiki may modify the underlying logic.
* **External Processing & Privacy**: Using this package means sending content over to servers operated by the Wikimedia Foundation for execution. An internet connection is required to utilize the package, and the author of this project has no control over the reliability of WMF services. Users should not send sensitive data through the wrapper.
## Functions
* call(function: str, *args): uses the api to call the function with the specified arguments.
* ZObject(type: str, **properties): creates an object with the specified type and properties. All of the other object builders rely on this function but add abstraction. Z1.
* ZFunctionCall(function: str, *arguments): works similarly to call, but instead creates the relevant function call without sending it to the Wikifunctions API. This is useful for nesting calls. Z7.
* ZReference(item: str): creates a reference to a specific item by its ZID. Z9.
* ZMonolingualText(language: str, content: str): creates a monolingual text from the ZID of a natural language and string content. Z11.
* ZBoolean(value: bool): creates a WF boolean from a Python boolean. Z40.
* ZNaturalNumber(num: int): creates a natural number. Will take the absolute value if given a negative number. Z13518.
* ZHTMLFragment(content: str): wraps a string in an HTML fragment. Z89.
* ZSign(num: int): given a number, returns the sign of that number (e.g. negative for -1). Z16659.
* ZInteger(num: int): converts a python int to a WF integer. Z16683.
* Wikidata references (ZWikidataItemReference, ZWikidataPropertyReference,
    ZWikidataLexemeFormReference, ZWikidataLexemeReference, 
    ZWikidataLexemeSenseReference): create the relevant reference type given a string representing their ID. Z6091-Z6096.
* ZRationalNumber(numerator: int, denominator: int): creates a WF rational number from a numerator and denominator. Z19677.
* ZKleenean(number: int): creates a Kleenean based on a number. 1 = True, 0 = Maybe, -1 = False. Z22112.
## License
This project is licensed under the [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0).
## Source code and issues
* [Source code](https://www.wikifunctions.org/wiki/User:Feeglgeef/wikifunctions-pip/src)
* [Issues](https://www.wikifunctions.org/wiki/User_talk:Feeglgeef/wikifunctions-pip/issues)