import pytest
import json
from unittest.mock import patch
from wikifunctions.api import call
@patch("wikifunctions.api.requests.post")
def test_call_success(mock_post):
    """Test that call constructs the correct payload and handles a successful response."""

    mock_response = mock_post.return_value
    mock_response.raise_for_status.return_value = None
    
    mock_data_string = json.dumps({
        "Z22K1": "Hello, Wikifunctions!",
        "Z22K2": {} 
    })

    mock_response.json.return_value = {
        "wikifunctions_run": {
            "data": mock_data_string
        }
    }

    result = call("Z801", "Hello, Wikifunctions!")

    assert result["Z22K1"] == "Hello, Wikifunctions!"

    mock_post.assert_called_once()

    _, kwargs = mock_post.call_args
    payload = kwargs["data"]
    
    assert payload["action"] == "wikifunctions_run"
    assert payload["format"] == "json"
    
    zobject = json.loads(payload["function_call"])
    assert zobject["Z1K1"] == "Z7"
    assert zobject["Z7K1"] == "Z801"
    assert zobject["Z801K1"] == "Hello, Wikifunctions!"