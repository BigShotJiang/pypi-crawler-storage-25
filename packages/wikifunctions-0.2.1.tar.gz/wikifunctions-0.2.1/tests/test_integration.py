import pytest
from wikifunctions.api import call
from wikifunctions.object import (
    ZBoolean, 
    ZHTMLFragment, 
    ZKleenean, 
    ZRationalNumber
)

@pytest.mark.integration
def test_if_function_integration():
    condition = ZBoolean(True)
    consequent = ZHTMLFragment("<b>Integration Test Passed</b>")
    alternative = ZKleenean(0)

    # Call Z802
    response = call("Z802", condition, consequent, alternative)
    
    # Extract result
    result = response.get("Z22K1")

    # Condition = true, match consequent
    assert result == consequent
    assert result["Z1K1"] == "Z89"
    assert result["Z89K1"] == "<b>Integration Test Passed</b>"

@pytest.mark.integration
def test_add_rational_numbers_integration():
    rat1 = ZRationalNumber(1, 2)
    rat2 = ZRationalNumber(1, 3)

    # Call Z19679
    response = call("Z19679", rat1, rat2)
    result = response.get("Z22K1")

    # Assert is a rational
    assert result["Z1K1"] == "Z19677"
    
    # Numerator is 5
    assert result["Z19677K2"]["Z13518K1"] == "5"
    
    # Denominator is 6
    assert result["Z19677K3"]["Z13518K1"] == "6"
    
    # Is positive
    assert result["Z19677K1"]["Z16659K1"]== "Z16660"