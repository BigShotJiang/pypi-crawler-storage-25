from wikifunctions.object import (
    ZObject, ZFunctionCall, ZReference, ZMonolingualText, 
    ZBoolean, ZNaturalNumber, ZHTMLFragment, ZSign, 
    ZInteger, ZWikidataItemReference, ZWikidataPropertyReference,
    ZWikidataLexemeFormReference, ZWikidataLexemeReference, 
    ZWikidataLexemeSenseReference, ZRationalNumber, ZKleenean
)

def test_zobject():
    assert ZObject("Z99", Z99K1="Test") == {"Z1K1": "Z99", "Z99K1": "Test"}

def test_zreference():
    assert ZReference("Z41") == {"Z1K1": "Z9", "Z9K1": "Z41"}

def test_zfunctioncall():
    assert ZFunctionCall("Z801", "Echo text") == {
        "Z1K1": "Z7",
        "Z7K1": "Z801",
        "Z801K1": "Echo text"
    }

def test_zmonolingualtext():
    assert ZMonolingualText("Z1002", "Hello") == {
        "Z1K1": "Z11",
        "Z11K1": {"Z1K1": "Z9", "Z9K1": "Z1002"},
        "Z11K2": "Hello"
    }

def test_zboolean():
    assert ZBoolean(True) == {
        "Z1K1": "Z40",
        "Z40K1": {"Z1K1": "Z9", "Z9K1": "Z41"}
    }
    assert ZBoolean(False) == {
        "Z1K1": "Z40",
        "Z40K1": {"Z1K1": "Z9", "Z9K1": "Z42"}
    }

def test_zhtmlfragment():
    assert ZHTMLFragment("<b>test</b>") == {
        "Z1K1": "Z89",
        "Z89K1": "<b>test</b>"
    }

def test_zkleenean():
    assert ZKleenean(1) == {"Z1K1": "Z22112", "Z22112K1": "Z22113"}
    assert ZKleenean(0) == {"Z1K1": "Z22112", "Z22112K1": "Z22114"}
    assert ZKleenean(-1) == {"Z1K1": "Z22112", "Z22112K1": "Z22115"}

def test_znaturalnumber():
    assert ZNaturalNumber(5) == {"Z1K1": "Z13518", "Z13518K1": "5"}
    assert ZNaturalNumber(-5) == {"Z1K1": "Z13518", "Z13518K1": "5"} # should abs()

def test_zsign():
    assert ZSign(5) == {"Z1K1": "Z16659", "Z16659K1": {"Z1K1": "Z9", "Z9K1": "Z16660"}} # Positive
    assert ZSign(0) == {"Z1K1": "Z16659", "Z16659K1": {"Z1K1": "Z9", "Z9K1": "Z16661"}} # Zero
    assert ZSign(-5) == {"Z1K1": "Z16659", "Z16659K1": {"Z1K1": "Z9", "Z9K1": "Z16662"}} # Negative

def test_zinteger():
    assert ZInteger(-42) == {
        "Z1K1": "Z16683",
        "Z16683K1": {"Z1K1": "Z16659", "Z16659K1": {"Z1K1": "Z9", "Z9K1": "Z16662"}}, # Negative
        "Z16683K2": {"Z1K1": "Z13518", "Z13518K1": "42"} # 42
    }

def test_zrationalnumber():
    assert ZRationalNumber(1, 2) == {
        "Z1K1": "Z19677",
        "Z19677K1": {"Z1K1": "Z16659", "Z16659K1": {"Z1K1": "Z9", "Z9K1": "Z16660"}}, # Positive
        "Z19677K2": {"Z1K1": "Z13518", "Z13518K1": "1"}, # Numerator
        "Z19677K3": {"Z1K1": "Z13518", "Z13518K1": "2"}  # Denominator
    }

    # Test negative rational
    assert ZRationalNumber(-1, 2) == {
        "Z1K1": "Z19677",
        "Z19677K1": {"Z1K1": "Z16659", "Z16659K1": {"Z1K1": "Z9", "Z9K1": "Z16662"}}, # Negative
        "Z19677K2": {"Z1K1": "Z13518", "Z13518K1": "1"}, 
        "Z19677K3": {"Z1K1": "Z13518", "Z13518K1": "2"}  
    }

# WD refs

def test_wikidata_references():
    assert ZWikidataItemReference("Q1") == {"Z1K1": "Z6091", "Z6091K1": "Q1"}
    assert ZWikidataPropertyReference("P31") == {"Z1K1": "Z6092", "Z6092K1": "P31"}
    assert ZWikidataLexemeFormReference("L1-F1") == {"Z1K1": "Z6094", "Z6094K1": "L1-F1"}
    assert ZWikidataLexemeReference("L1") == {"Z1K1": "Z6095", "Z6095K1": "L1"}
    assert ZWikidataLexemeSenseReference("L1-S1") == {"Z1K1": "Z6096", "Z6096K1": "L1-S1"}