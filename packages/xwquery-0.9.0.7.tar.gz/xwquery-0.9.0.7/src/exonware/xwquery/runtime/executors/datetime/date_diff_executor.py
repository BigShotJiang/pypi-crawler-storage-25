#!/usr/bin/env python3
"""
DATE_DIFF Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.7
"""

from datetime import datetime, date, timedelta, timezone
from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


def _parse_datetime(val):
    if isinstance(val, datetime):
        return val
    if isinstance(val, date):
        return datetime.combine(val, datetime.min.time())
    if isinstance(val, (int, float)):
        return datetime.fromtimestamp(val)
    if isinstance(val, str):
        for fmt in ('%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%m/%d/%Y'):
            try:
                return datetime.strptime(val, fmt)
            except ValueError:
                continue
    return None


class DateDiffExecutor(AUniversalOperationExecutor):
    OPERATION_NAME = "DATE_DIFF"
    OPERATION_TYPE = OperationType.ADVANCED
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params
        result_data = self._execute_op(context.node, params, context)
        return ExecutionResult(
            success=True,
            data=result_data,
            action_type=self.OPERATION_NAME,
            metadata={"operation": self.OPERATION_NAME},
        )

    def _to_unit(self, delta_seconds: float, unit: str) -> Optional[float]:
        if unit == "seconds":
            return delta_seconds
        if unit == "hours":
            return delta_seconds / 3600
        if unit == "days":
            return delta_seconds / 86400
        return None

    def _execute_op(self, node: Any, params: dict, context: ExecutionContext) -> dict:
        items = extract_items(node)
        field1 = params.get("field1")
        field2 = params.get("field2")
        unit = str(params.get("unit", "days")).lower()
        as_field = params.get("as_field", "_date_diff")

        result_items = []
        for item in items:
            item_copy = item.copy() if isinstance(item, dict) else {"value": item}
            date1 = _parse_datetime(extract_field_value(item, field1))
            date2 = _parse_datetime(extract_field_value(item, field2))

            if date1 is None or date2 is None:
                item_copy[as_field] = None
            else:
                diff_seconds = (date1 - date2).total_seconds()
                item_copy[as_field] = self._to_unit(diff_seconds, unit)

            result_items.append(item_copy)

        return {"items": result_items, "count": len(result_items), "field1": field1, "field2": field2}


__all__ = ["DateDiffExecutor"]
