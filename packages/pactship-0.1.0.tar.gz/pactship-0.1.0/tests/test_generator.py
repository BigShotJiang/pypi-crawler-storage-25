"""Tests for contract generator."""

import pytest

from pactship.generator import (
    generate_crud_contract,
    generate_from_endpoints,
    infer_matchers_from_example,
)
from pactship.models import HttpMethod, MatcherType


class TestGenerateFromEndpoints:
    def test_basic(self):
        endpoints = [
            {
                "method": "GET",
                "path": "/users",
                "response_body": [{"id": 1}],
            }
        ]
        contract = generate_from_endpoints("frontend", "backend", endpoints)
        assert contract.consumer == "frontend"
        assert contract.provider == "backend"
        assert len(contract.interactions) == 1

    def test_with_all_fields(self):
        endpoints = [
            {
                "method": "POST",
                "path": "/users",
                "description": "Create a user",
                "request_body": {"name": "Alice"},
                "request_headers": {"Content-Type": "application/json"},
                "response_status": 201,
                "response_body": {"id": 1, "name": "Alice"},
                "response_headers": {"Location": "/users/1"},
                "provider_states": ["empty db"],
            }
        ]
        contract = generate_from_endpoints("a", "b", endpoints)
        i = contract.interactions[0]
        assert i.description == "Create a user"
        assert i.request.method == HttpMethod.POST
        assert i.request.body == {"name": "Alice"}
        assert len(i.request.headers) == 1
        assert i.response.status == 201
        assert len(i.response.headers) == 1
        assert i.provider_states == ["empty db"]

    def test_default_description(self):
        endpoints = [{"method": "GET", "path": "/health"}]
        contract = generate_from_endpoints("a", "b", endpoints)
        assert contract.interactions[0].description == "GET /health"

    def test_default_status(self):
        endpoints = [{"method": "GET", "path": "/test"}]
        contract = generate_from_endpoints("a", "b", endpoints)
        assert contract.interactions[0].response.status == 200

    def test_multiple_endpoints(self):
        endpoints = [
            {"method": "GET", "path": "/a"},
            {"method": "POST", "path": "/b"},
            {"method": "DELETE", "path": "/c"},
        ]
        contract = generate_from_endpoints("a", "b", endpoints)
        assert len(contract.interactions) == 3

    def test_empty_endpoints(self):
        contract = generate_from_endpoints("a", "b", [])
        assert len(contract.interactions) == 0


class TestGenerateCrudContract:
    def test_generates_5_interactions(self):
        contract = generate_crud_contract(
            "frontend", "backend", "user", "/users",
            {"name": "Alice", "email": "alice@test.com"},
        )
        assert len(contract.interactions) == 5

    def test_list_interaction(self):
        contract = generate_crud_contract(
            "a", "b", "item", "/items", {"name": "Widget"},
        )
        list_int = contract.interactions[0]
        assert list_int.description == "List items"
        assert list_int.request.method == HttpMethod.GET
        assert list_int.request.path == "/items"
        assert list_int.response.status == 200

    def test_get_by_id_interaction(self):
        contract = generate_crud_contract(
            "a", "b", "item", "/items", {"name": "Widget"},
        )
        get_int = contract.interactions[1]
        assert get_int.description == "Get item by id"
        assert get_int.request.path == "/items/{id}"
        assert "item exists" in get_int.provider_states

    def test_create_interaction(self):
        contract = generate_crud_contract(
            "a", "b", "item", "/items", {"name": "Widget"},
        )
        create_int = contract.interactions[2]
        assert create_int.description == "Create item"
        assert create_int.request.method == HttpMethod.POST
        assert create_int.response.status == 201
        assert create_int.request.body == {"name": "Widget"}

    def test_update_interaction(self):
        contract = generate_crud_contract(
            "a", "b", "item", "/items", {"name": "Widget"},
        )
        update_int = contract.interactions[3]
        assert update_int.request.method == HttpMethod.PUT
        assert update_int.response.status == 200

    def test_delete_interaction(self):
        contract = generate_crud_contract(
            "a", "b", "item", "/items", {"name": "Widget"},
        )
        delete_int = contract.interactions[4]
        assert delete_int.request.method == HttpMethod.DELETE
        assert delete_int.response.status == 204

    def test_custom_id_field(self):
        contract = generate_crud_contract(
            "a", "b", "item", "/items", {"name": "Widget"},
            id_field="item_id",
        )
        get_int = contract.interactions[1]
        assert get_int.request.path == "/items/{item_id}"

    def test_response_includes_id(self):
        contract = generate_crud_contract(
            "a", "b", "item", "/items", {"name": "Widget"},
        )
        get_int = contract.interactions[1]
        assert "id" in get_int.response.body


class TestInferMatchers:
    def test_string(self):
        matchers = infer_matchers_from_example({"name": "Alice"})
        assert "body.name" in matchers
        assert matchers["body.name"].type == MatcherType.STRING

    def test_integer(self):
        matchers = infer_matchers_from_example({"age": 25})
        assert matchers["body.age"].type == MatcherType.INTEGER

    def test_float(self):
        matchers = infer_matchers_from_example({"price": 9.99})
        assert matchers["body.price"].type == MatcherType.DECIMAL

    def test_boolean(self):
        matchers = infer_matchers_from_example({"active": True})
        assert matchers["body.active"].type == MatcherType.BOOLEAN

    def test_email(self):
        matchers = infer_matchers_from_example({"email": "test@example.com"})
        assert matchers["body.email"].type == MatcherType.EMAIL

    def test_uuid(self):
        matchers = infer_matchers_from_example(
            {"id": "550e8400-e29b-41d4-a716-446655440000"}
        )
        assert matchers["body.id"].type == MatcherType.UUID

    def test_iso_date(self):
        matchers = infer_matchers_from_example({"date": "2024-01-15"})
        assert matchers["body.date"].type == MatcherType.ISO_DATE

    def test_iso_datetime(self):
        matchers = infer_matchers_from_example(
            {"timestamp": "2024-01-15T10:30:00Z"}
        )
        assert matchers["body.timestamp"].type == MatcherType.ISO_DATETIME

    def test_nested(self):
        matchers = infer_matchers_from_example(
            {"user": {"name": "Alice", "age": 25}}
        )
        assert "body.user.name" in matchers
        assert "body.user.age" in matchers

    def test_array(self):
        matchers = infer_matchers_from_example({"items": [{"id": 1}]})
        assert "body.items" in matchers
        assert matchers["body.items"].type == MatcherType.ARRAY_LIKE
        assert "body.items[0].id" in matchers

    def test_empty_dict(self):
        matchers = infer_matchers_from_example({})
        assert len(matchers) == 0

    def test_complex_body(self):
        body = {
            "id": 1,
            "name": "Alice",
            "email": "alice@test.com",
            "active": True,
            "score": 95.5,
            "created": "2024-01-15",
            "tags": ["admin"],
        }
        matchers = infer_matchers_from_example(body)
        assert len(matchers) >= 6
