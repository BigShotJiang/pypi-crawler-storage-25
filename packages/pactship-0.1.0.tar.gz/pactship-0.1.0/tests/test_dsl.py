"""Tests for the fluent DSL builder."""

import pytest

from pactship.dsl import ContractBuilder, InteractionBuilder
from pactship.matchers import exact, like, regex
from pactship.models import HttpMethod


class TestInteractionBuilder:
    def test_basic(self):
        interaction = (
            InteractionBuilder("Get user")
            .with_request("GET", "/users/1")
            .will_respond_with(200)
            .with_response_body({"id": 1, "name": "Alice"})
            .build()
        )
        assert interaction.description == "Get user"
        assert interaction.request.method == HttpMethod.GET
        assert interaction.request.path == "/users/1"
        assert interaction.response.status == 200
        assert interaction.response.body == {"id": 1, "name": "Alice"}

    def test_with_provider_state(self):
        interaction = (
            InteractionBuilder("Get user")
            .given("user 1 exists")
            .with_request("GET", "/users/1")
            .will_respond_with(200)
            .build()
        )
        assert interaction.provider_states == ["user 1 exists"]

    def test_multiple_states(self):
        interaction = (
            InteractionBuilder("Complex scenario")
            .given("user exists")
            .given("user has orders")
            .with_request("GET", "/users/1/orders")
            .will_respond_with(200)
            .build()
        )
        assert len(interaction.provider_states) == 2

    def test_with_headers(self):
        interaction = (
            InteractionBuilder("With headers")
            .with_request("POST", "/data")
            .with_request_header("Content-Type", "application/json")
            .with_request_header("Authorization", "Bearer token")
            .will_respond_with(200)
            .with_response_header("X-Request-Id", "abc123")
            .build()
        )
        assert len(interaction.request.headers) == 2
        assert len(interaction.response.headers) == 1

    def test_with_query_params(self):
        interaction = (
            InteractionBuilder("With query")
            .with_request("GET", "/items")
            .with_query_param("page", "1")
            .with_query_param("limit", "10")
            .will_respond_with(200)
            .build()
        )
        assert len(interaction.request.query_params) == 2

    def test_with_request_body(self):
        interaction = (
            InteractionBuilder("With body")
            .with_request("POST", "/users")
            .with_request_body({"name": "Alice", "email": "alice@example.com"})
            .will_respond_with(201)
            .build()
        )
        assert interaction.request.body == {
            "name": "Alice",
            "email": "alice@example.com",
        }

    def test_with_matchers(self):
        interaction = (
            InteractionBuilder("With matchers")
            .with_request("GET", "/users/1")
            .will_respond_with(200)
            .with_response_body(
                {"id": 1, "name": "Alice"},
                matchers={"body.id": like("integer"), "body.name": like("string")},
            )
            .build()
        )
        assert len(interaction.response.body_matchers) == 2

    def test_with_tags(self):
        interaction = (
            InteractionBuilder("Tagged")
            .with_request("GET", "/")
            .will_respond_with(200)
            .with_tag("v2")
            .with_tag("public")
            .build()
        )
        assert interaction.tags == ["v2", "public"]

    def test_upon_receiving(self):
        interaction = (
            InteractionBuilder("initial")
            .upon_receiving("updated description")
            .with_request("GET", "/")
            .will_respond_with(200)
            .build()
        )
        assert interaction.description == "updated description"

    def test_http_method_enum(self):
        interaction = (
            InteractionBuilder("test")
            .with_request(HttpMethod.POST, "/data")
            .will_respond_with(201)
            .build()
        )
        assert interaction.request.method == HttpMethod.POST

    def test_with_header_matcher(self):
        m = regex(r"Bearer .+")
        interaction = (
            InteractionBuilder("test")
            .with_request("GET", "/")
            .with_request_header("Authorization", "Bearer token", matcher=m)
            .will_respond_with(200)
            .build()
        )
        assert interaction.request.headers[0].matcher is not None

    def test_with_query_matcher(self):
        m = like("string")
        interaction = (
            InteractionBuilder("test")
            .with_request("GET", "/items")
            .with_query_param("search", "test", matcher=m)
            .will_respond_with(200)
            .build()
        )
        assert interaction.request.query_params[0].matcher is not None


class TestContractBuilder:
    def test_basic(self):
        interaction = (
            InteractionBuilder("Get user")
            .with_request("GET", "/users/1")
            .will_respond_with(200)
            .build()
        )
        contract = (
            ContractBuilder("frontend", "backend")
            .add_interaction(interaction)
            .build()
        )
        assert contract.consumer == "frontend"
        assert contract.provider == "backend"
        assert len(contract.interactions) == 1

    def test_multiple_interactions(self):
        i1 = (
            InteractionBuilder("Get user")
            .with_request("GET", "/users/1")
            .will_respond_with(200)
            .build()
        )
        i2 = (
            InteractionBuilder("Create user")
            .with_request("POST", "/users")
            .will_respond_with(201)
            .build()
        )
        contract = (
            ContractBuilder("frontend", "backend")
            .add_interaction(i1)
            .add_interaction(i2)
            .build()
        )
        assert len(contract.interactions) == 2

    def test_with_metadata(self):
        contract = (
            ContractBuilder("a", "b")
            .with_metadata("version", "1.0")
            .with_metadata("team", "platform")
            .build()
        )
        assert contract.metadata["version"] == "1.0"
        assert contract.metadata["team"] == "platform"

    def test_interaction_factory(self):
        builder = ContractBuilder("a", "b")
        ib = builder.interaction("test")
        assert isinstance(ib, InteractionBuilder)
