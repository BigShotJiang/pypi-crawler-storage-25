"""Tests for contract I/O (serialization/deserialization)."""

import json
import os
import tempfile
from pathlib import Path

import pytest
import yaml

from pactship.contract_io import (
    contract_from_dict,
    contract_to_dict,
    load_contract,
    load_contracts_from_dir,
    merge_contracts,
    save_contract,
)
from pactship.models import (
    Contract,
    HttpMethod,
    Interaction,
    RequestSpec,
    ResponseSpec,
)


@pytest.fixture
def sample_contract():
    return Contract(
        consumer="frontend",
        provider="backend",
        interactions=[
            Interaction(
                description="Get user",
                request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
                response=ResponseSpec(status=200, body={"id": 1, "name": "Alice"}),
            ),
            Interaction(
                description="Create user",
                request=RequestSpec(
                    method=HttpMethod.POST,
                    path="/users",
                    body={"name": "Bob"},
                ),
                response=ResponseSpec(status=201, body={"id": 2, "name": "Bob"}),
            ),
        ],
        metadata={"generated_by": "pactship"},
    )


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


class TestSaveAndLoadYaml:
    def test_roundtrip(self, sample_contract, temp_dir):
        path = temp_dir / "contract.yaml"
        save_contract(sample_contract, path, fmt="yaml")
        loaded = load_contract(path)
        assert loaded.consumer == "frontend"
        assert loaded.provider == "backend"
        assert len(loaded.interactions) == 2

    def test_yaml_content(self, sample_contract, temp_dir):
        path = temp_dir / "contract.yml"
        save_contract(sample_contract, path, fmt="yaml")
        content = path.read_text()
        data = yaml.safe_load(content)
        assert data["consumer"] == "frontend"

    def test_creates_parent_dirs(self, sample_contract, temp_dir):
        path = temp_dir / "sub" / "dir" / "contract.yaml"
        save_contract(sample_contract, path)
        assert path.exists()


class TestSaveAndLoadJson:
    def test_roundtrip(self, sample_contract, temp_dir):
        path = temp_dir / "contract.json"
        save_contract(sample_contract, path, fmt="json")
        loaded = load_contract(path)
        assert loaded.consumer == "frontend"
        assert len(loaded.interactions) == 2

    def test_json_content(self, sample_contract, temp_dir):
        path = temp_dir / "contract.json"
        save_contract(sample_contract, path, fmt="json")
        content = path.read_text()
        data = json.loads(content)
        assert data["provider"] == "backend"


class TestLoadContract:
    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            load_contract("/nonexistent/file.yaml")

    def test_invalid_format(self, temp_dir):
        path = temp_dir / "bad.yaml"
        path.write_text("just a string", encoding="utf-8")
        with pytest.raises(ValueError):
            load_contract(path)

    def test_auto_detect_yaml(self, sample_contract, temp_dir):
        path = temp_dir / "contract.txt"
        save_contract(sample_contract, path, fmt="yaml")
        loaded = load_contract(path)
        assert loaded.consumer == "frontend"


class TestLoadContractsFromDir:
    def test_load_multiple(self, temp_dir):
        c1 = Contract(
            consumer="a",
            provider="b",
            interactions=[
                Interaction(
                    description="test",
                    request=RequestSpec(method=HttpMethod.GET, path="/"),
                    response=ResponseSpec(status=200),
                )
            ],
        )
        c2 = Contract(
            consumer="c",
            provider="d",
            interactions=[
                Interaction(
                    description="test2",
                    request=RequestSpec(method=HttpMethod.POST, path="/data"),
                    response=ResponseSpec(status=201),
                )
            ],
        )
        save_contract(c1, temp_dir / "c1.yaml")
        save_contract(c2, temp_dir / "c2.json", fmt="json")
        contracts = load_contracts_from_dir(temp_dir)
        assert len(contracts) == 2

    def test_empty_dir(self, temp_dir):
        contracts = load_contracts_from_dir(temp_dir)
        assert len(contracts) == 0

    def test_not_a_dir(self):
        with pytest.raises(NotADirectoryError):
            load_contracts_from_dir("/nonexistent/dir")


class TestMergeContracts:
    def test_merge_same_pair(self):
        c1 = Contract(
            consumer="a",
            provider="b",
            interactions=[
                Interaction(
                    description="get",
                    request=RequestSpec(method=HttpMethod.GET, path="/x"),
                    response=ResponseSpec(status=200),
                )
            ],
        )
        c2 = Contract(
            consumer="a",
            provider="b",
            interactions=[
                Interaction(
                    description="post",
                    request=RequestSpec(method=HttpMethod.POST, path="/x"),
                    response=ResponseSpec(status=201),
                )
            ],
        )
        merged = merge_contracts([c1, c2])
        assert len(merged) == 1
        assert len(merged[0].interactions) == 2

    def test_merge_different_pairs(self):
        c1 = Contract(consumer="a", provider="b")
        c2 = Contract(consumer="c", provider="d")
        merged = merge_contracts([c1, c2])
        assert len(merged) == 2

    def test_merge_no_duplicates(self):
        interaction = Interaction(
            description="get",
            request=RequestSpec(method=HttpMethod.GET, path="/x"),
            response=ResponseSpec(status=200),
        )
        c1 = Contract(consumer="a", provider="b", interactions=[interaction])
        c2 = Contract(consumer="a", provider="b", interactions=[interaction])
        merged = merge_contracts([c1, c2])
        assert len(merged[0].interactions) == 1

    def test_merge_empty(self):
        assert merge_contracts([]) == []


class TestHelperFunctions:
    def test_contract_to_dict(self):
        c = Contract(consumer="a", provider="b")
        d = contract_to_dict(c)
        assert d["consumer"] == "a"

    def test_contract_from_dict(self):
        d = {"consumer": "a", "provider": "b", "interactions": []}
        c = contract_from_dict(d)
        assert c.consumer == "a"
