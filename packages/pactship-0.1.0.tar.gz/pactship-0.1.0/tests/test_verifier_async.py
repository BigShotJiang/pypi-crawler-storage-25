"""Async integration tests for provider verifier using respx."""

import pytest
import httpx
import respx

from pactship.models import (
    Contract,
    Header,
    HttpMethod,
    Interaction,
    Matcher,
    MatcherType,
    QueryParam,
    RequestSpec,
    ResponseSpec,
)
from pactship.verifier import ProviderVerifier


@pytest.fixture
def verifier():
    return ProviderVerifier("https://api.test.com")


def _interaction(desc, method="GET", path="/test", status=200, body=None,
                 resp_body=None, provider_states=None, resp_headers=None,
                 query_params=None, req_headers=None):
    req_hdrs = [Header(name=k, value=v) for k, v in (req_headers or {}).items()]
    resp_hdrs = [Header(name=k, value=v) for k, v in (resp_headers or {}).items()]
    qps = [QueryParam(name=k, value=v) for k, v in (query_params or {}).items()]
    return Interaction(
        description=desc,
        request=RequestSpec(
            method=HttpMethod(method),
            path=path,
            headers=req_hdrs,
            query_params=qps,
            body=body,
        ),
        response=ResponseSpec(
            status=status,
            body=resp_body,
            headers=resp_hdrs,
        ),
        provider_states=provider_states or [],
    )


class TestVerifySuccess:
    @respx.mock
    async def test_simple_get(self, verifier):
        respx.get("https://api.test.com/users/1").mock(
            return_value=httpx.Response(200, json={"id": 1, "name": "Alice"})
        )
        contract = Contract(
            consumer="frontend", provider="backend",
            interactions=[
                _interaction("Get user", path="/users/1", status=200,
                             resp_body={"id": 1, "name": "Alice"})
            ],
        )
        report = await verifier.verify_contract(contract)
        assert report.success
        assert report.passed == 1
        assert report.failed == 0

    @respx.mock
    async def test_post_with_body(self, verifier):
        respx.post("https://api.test.com/users").mock(
            return_value=httpx.Response(201, json={"id": 2, "name": "Bob"})
        )
        contract = Contract(
            consumer="frontend", provider="backend",
            interactions=[
                _interaction("Create user", method="POST", path="/users",
                             body={"name": "Bob"}, status=201,
                             resp_body={"id": 2, "name": "Bob"})
            ],
        )
        report = await verifier.verify_contract(contract)
        assert report.success

    @respx.mock
    async def test_multiple_interactions(self, verifier):
        respx.get("https://api.test.com/users/1").mock(
            return_value=httpx.Response(200, json={"id": 1})
        )
        respx.get("https://api.test.com/users/2").mock(
            return_value=httpx.Response(200, json={"id": 2})
        )
        contract = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction("Get user 1", path="/users/1", status=200, resp_body={"id": 1}),
                _interaction("Get user 2", path="/users/2", status=200, resp_body={"id": 2}),
            ],
        )
        report = await verifier.verify_contract(contract)
        assert report.success
        assert report.total == 2

    @respx.mock
    async def test_no_body_check(self, verifier):
        respx.delete("https://api.test.com/users/1").mock(
            return_value=httpx.Response(204)
        )
        contract = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction("Delete user", method="DELETE", path="/users/1", status=204)
            ],
        )
        report = await verifier.verify_contract(contract)
        assert report.success


class TestVerifyFailure:
    @respx.mock
    async def test_status_mismatch(self, verifier):
        respx.get("https://api.test.com/test").mock(
            return_value=httpx.Response(404)
        )
        contract = Contract(
            consumer="a", provider="b",
            interactions=[_interaction("test", status=200)],
        )
        report = await verifier.verify_contract(contract)
        assert not report.success
        assert report.failed == 1
        assert "status" in report.results[0].errors[0].lower()

    @respx.mock
    async def test_body_mismatch(self, verifier):
        respx.get("https://api.test.com/test").mock(
            return_value=httpx.Response(200, json={"id": 1, "name": "Wrong"})
        )
        contract = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction("test", status=200, resp_body={"id": 1, "name": "Alice"})
            ],
        )
        report = await verifier.verify_contract(contract)
        assert not report.success

    @respx.mock
    async def test_missing_body_field(self, verifier):
        respx.get("https://api.test.com/test").mock(
            return_value=httpx.Response(200, json={"id": 1})
        )
        contract = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction("test", status=200, resp_body={"id": 1, "name": "Alice"})
            ],
        )
        report = await verifier.verify_contract(contract)
        assert not report.success

    @respx.mock
    async def test_connection_error(self, verifier):
        respx.get("https://api.test.com/test").mock(side_effect=httpx.ConnectError("refused"))
        contract = Contract(
            consumer="a", provider="b",
            interactions=[_interaction("test")],
        )
        report = await verifier.verify_contract(contract)
        assert not report.success
        assert "HTTP request failed" in report.results[0].errors[0]


class TestVerifyMultipleContracts:
    @respx.mock
    async def test_verify_contracts(self, verifier):
        respx.get("https://api.test.com/a").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        respx.get("https://api.test.com/b").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        contracts = [
            Contract(consumer="x", provider="y",
                     interactions=[_interaction("a", path="/a", resp_body={"ok": True})]),
            Contract(consumer="z", provider="y",
                     interactions=[_interaction("b", path="/b", resp_body={"ok": True})]),
        ]
        reports = await verifier.verify_contracts(contracts)
        assert len(reports) == 2
        assert all(r.success for r in reports)


class TestProviderStates:
    @respx.mock
    async def test_state_handler(self, verifier):
        state_called = []
        verifier.register_state_handler(
            "user exists", lambda: state_called.append(True)
        )
        respx.get("https://api.test.com/users/1").mock(
            return_value=httpx.Response(200, json={"id": 1})
        )
        contract = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction("get user", path="/users/1", status=200,
                             resp_body={"id": 1},
                             provider_states=["user exists"])
            ],
        )
        report = await verifier.verify_contract(contract)
        assert report.success
        assert len(state_called) == 1

    @respx.mock
    async def test_state_handler_error(self, verifier):
        def bad_handler():
            raise RuntimeError("setup failed")

        verifier.register_state_handler("bad state", bad_handler)
        contract = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction("test", provider_states=["bad state"])
            ],
        )
        report = await verifier.verify_contract(contract)
        assert not report.success
        assert "State setup failed" in report.results[0].errors[0]

    @respx.mock
    async def test_setup_url(self):
        v = ProviderVerifier("https://api.test.com", setup_url="/setup")
        respx.post("https://api.test.com/setup").mock(
            return_value=httpx.Response(200)
        )
        respx.get("https://api.test.com/test").mock(
            return_value=httpx.Response(200)
        )
        contract = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction("test", provider_states=["some state"])
            ],
        )
        report = await v.verify_contract(contract)
        assert report.success


class TestVerifyDuration:
    @respx.mock
    async def test_duration_tracked(self, verifier):
        respx.get("https://api.test.com/test").mock(
            return_value=httpx.Response(200)
        )
        contract = Contract(
            consumer="a", provider="b",
            interactions=[_interaction("test")],
        )
        report = await verifier.verify_contract(contract)
        assert report.total_duration_ms >= 0
        assert report.results[0].duration_ms >= 0


class TestVerifyResponseHeaders:
    @respx.mock
    async def test_header_match(self, verifier):
        respx.get("https://api.test.com/test").mock(
            return_value=httpx.Response(200, headers={"x-custom": "value"})
        )
        contract = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction("test", resp_headers={"x-custom": "value"})
            ],
        )
        report = await verifier.verify_contract(contract)
        assert report.success

    @respx.mock
    async def test_missing_header(self, verifier):
        respx.get("https://api.test.com/test").mock(
            return_value=httpx.Response(200)
        )
        contract = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction("test", resp_headers={"x-custom": "value"})
            ],
        )
        report = await verifier.verify_contract(contract)
        assert not report.success
        assert "Missing response header" in report.results[0].errors[0]
