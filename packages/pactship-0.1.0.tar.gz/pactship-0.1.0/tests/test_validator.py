"""Tests for contract validation."""

import pytest

from pactship.models import (
    Contract,
    Header,
    HttpMethod,
    Interaction,
    RequestSpec,
    ResponseSpec,
)
from pactship.validator import (
    ValidationIssue,
    ValidationResult,
    validate_contract,
    validate_contract_dict,
)


def _interaction(desc="test", method="GET", path="/test", status=200, body=None, req_body=None):
    return Interaction(
        description=desc,
        request=RequestSpec(method=HttpMethod(method), path=path, body=req_body),
        response=ResponseSpec(status=status, body=body),
    )


class TestValidateContract:
    def test_valid_contract(self):
        c = Contract(
            consumer="frontend",
            provider="backend",
            interactions=[_interaction()],
        )
        result = validate_contract(c)
        assert result.valid

    def test_empty_consumer(self):
        c = Contract(consumer="", provider="backend")
        result = validate_contract(c)
        assert not result.valid
        assert any("Consumer" in e.message for e in result.errors)

    def test_empty_provider(self):
        c = Contract(consumer="frontend", provider="")
        result = validate_contract(c)
        assert not result.valid

    def test_whitespace_consumer(self):
        c = Contract(consumer="   ", provider="backend")
        result = validate_contract(c)
        assert not result.valid

    def test_same_consumer_provider(self):
        c = Contract(consumer="api", provider="api")
        result = validate_contract(c)
        assert result.valid  # warning, not error
        assert any("same name" in w.message for w in result.warnings)

    def test_no_interactions_warning(self):
        c = Contract(consumer="a", provider="b")
        result = validate_contract(c)
        assert result.valid
        assert any("no interactions" in w.message for w in result.warnings)

    def test_empty_description(self):
        interaction = _interaction(desc="")
        c = Contract(consumer="a", provider="b", interactions=[interaction])
        result = validate_contract(c)
        assert not result.valid

    def test_duplicate_description_warning(self):
        c = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction(desc="same"),
                _interaction(desc="same", path="/other"),
            ],
        )
        result = validate_contract(c)
        assert any("Duplicate description" in w.message for w in result.warnings)

    def test_path_not_starting_with_slash(self):
        interaction = _interaction(path="no-slash")
        c = Contract(consumer="a", provider="b", interactions=[interaction])
        result = validate_contract(c)
        assert not result.valid

    def test_empty_path(self):
        interaction = _interaction(path="")
        c = Contract(consumer="a", provider="b", interactions=[interaction])
        result = validate_contract(c)
        assert not result.valid

    def test_duplicate_route_warning(self):
        c = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction(desc="first", path="/test"),
                _interaction(desc="second", path="/test"),
            ],
        )
        result = validate_contract(c)
        assert any("Duplicate route" in w.message for w in result.warnings)

    def test_invalid_status_code(self):
        interaction = _interaction(status=999)
        c = Contract(consumer="a", provider="b", interactions=[interaction])
        result = validate_contract(c)
        assert not result.valid

    def test_status_below_100(self):
        interaction = _interaction(status=50)
        c = Contract(consumer="a", provider="b", interactions=[interaction])
        result = validate_contract(c)
        assert not result.valid

    def test_get_with_body_warning(self):
        interaction = _interaction(method="GET", req_body={"test": True})
        c = Contract(consumer="a", provider="b", interactions=[interaction])
        result = validate_contract(c)
        assert any("unusual" in w.message for w in result.warnings)

    def test_delete_with_body_warning(self):
        interaction = _interaction(method="DELETE", req_body={"id": 1})
        c = Contract(consumer="a", provider="b", interactions=[interaction])
        result = validate_contract(c)
        assert len(result.warnings) > 0

    def test_post_with_body_no_warning(self):
        interaction = _interaction(method="POST", req_body={"name": "test"})
        c = Contract(consumer="a", provider="b", interactions=[interaction])
        result = validate_contract(c)
        assert not any("unusual" in w.message for w in result.warnings)

    def test_empty_header_name(self):
        interaction = Interaction(
            description="test",
            request=RequestSpec(
                method=HttpMethod.GET, path="/test",
                headers=[Header(name="", value="val")],
            ),
            response=ResponseSpec(status=200),
        )
        c = Contract(consumer="a", provider="b", interactions=[interaction])
        result = validate_contract(c)
        assert not result.valid

    def test_empty_response_header_name(self):
        interaction = Interaction(
            description="test",
            request=RequestSpec(method=HttpMethod.GET, path="/test"),
            response=ResponseSpec(
                status=200,
                headers=[Header(name="", value="val")],
            ),
        )
        c = Contract(consumer="a", provider="b", interactions=[interaction])
        result = validate_contract(c)
        assert not result.valid


class TestValidateContractDict:
    def test_valid(self):
        data = {
            "consumer": "a",
            "provider": "b",
            "interactions": [
                {
                    "description": "test",
                    "request": {"method": "GET", "path": "/test"},
                    "response": {"status": 200},
                }
            ],
        }
        result = validate_contract_dict(data)
        assert result.valid

    def test_missing_consumer(self):
        data = {"provider": "b"}
        result = validate_contract_dict(data)
        assert not result.valid

    def test_missing_provider(self):
        data = {"consumer": "a"}
        result = validate_contract_dict(data)
        assert not result.valid

    def test_not_dict(self):
        result = validate_contract_dict("not a dict")
        assert not result.valid

    def test_interactions_not_list(self):
        data = {"consumer": "a", "provider": "b", "interactions": "bad"}
        result = validate_contract_dict(data)
        assert not result.valid

    def test_interaction_not_dict(self):
        data = {"consumer": "a", "provider": "b", "interactions": ["bad"]}
        result = validate_contract_dict(data)
        assert not result.valid

    def test_missing_description(self):
        data = {
            "consumer": "a", "provider": "b",
            "interactions": [
                {"request": {"method": "GET", "path": "/"}, "response": {"status": 200}}
            ],
        }
        result = validate_contract_dict(data)
        assert not result.valid

    def test_missing_request(self):
        data = {
            "consumer": "a", "provider": "b",
            "interactions": [
                {"description": "test", "response": {"status": 200}}
            ],
        }
        result = validate_contract_dict(data)
        assert not result.valid

    def test_missing_response(self):
        data = {
            "consumer": "a", "provider": "b",
            "interactions": [
                {"description": "test", "request": {"method": "GET", "path": "/"}}
            ],
        }
        result = validate_contract_dict(data)
        assert not result.valid

    def test_missing_method(self):
        data = {
            "consumer": "a", "provider": "b",
            "interactions": [
                {"description": "test", "request": {"path": "/"}, "response": {"status": 200}}
            ],
        }
        result = validate_contract_dict(data)
        assert not result.valid

    def test_invalid_method(self):
        data = {
            "consumer": "a", "provider": "b",
            "interactions": [
                {"description": "test", "request": {"method": "INVALID", "path": "/"}, "response": {"status": 200}}
            ],
        }
        result = validate_contract_dict(data)
        assert not result.valid

    def test_missing_path(self):
        data = {
            "consumer": "a", "provider": "b",
            "interactions": [
                {"description": "test", "request": {"method": "GET"}, "response": {"status": 200}}
            ],
        }
        result = validate_contract_dict(data)
        assert not result.valid

    def test_missing_status(self):
        data = {
            "consumer": "a", "provider": "b",
            "interactions": [
                {"description": "test", "request": {"method": "GET", "path": "/"}, "response": {}}
            ],
        }
        result = validate_contract_dict(data)
        assert not result.valid


class TestValidationResult:
    def test_empty(self):
        r = ValidationResult()
        assert r.valid
        assert r.errors == []
        assert r.warnings == []

    def test_add_error(self):
        r = ValidationResult()
        r.add_error("path", "bad")
        assert not r.valid
        assert len(r.errors) == 1

    def test_add_warning(self):
        r = ValidationResult()
        r.add_warning("path", "caution")
        assert r.valid
        assert len(r.warnings) == 1


class TestValidationIssue:
    def test_str(self):
        i = ValidationIssue(path="test.path", message="bad value")
        s = str(i)
        assert "test.path" in s
        assert "bad value" in s
