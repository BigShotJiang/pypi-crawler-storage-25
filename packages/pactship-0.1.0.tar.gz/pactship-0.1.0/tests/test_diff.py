"""Tests for contract diff engine."""

import pytest

from pactship.diff import (
    ChangeType,
    ContractChange,
    ContractDiff,
    Severity,
    diff_contracts,
)
from pactship.models import (
    Contract,
    HttpMethod,
    Interaction,
    RequestSpec,
    ResponseSpec,
)


def _make_interaction(desc, method="GET", path="/test", status=200, body=None):
    return Interaction(
        description=desc,
        request=RequestSpec(method=HttpMethod(method), path=path),
        response=ResponseSpec(status=status, body=body),
    )


class TestDiffContracts:
    def test_no_changes(self):
        i = _make_interaction("get test")
        old = Contract(consumer="a", provider="b", interactions=[i])
        new = Contract(consumer="a", provider="b", interactions=[i])
        result = diff_contracts(old, new)
        assert not result.has_breaking_changes
        assert len(result.changes) == 0

    def test_added_interaction(self):
        old = Contract(consumer="a", provider="b", interactions=[])
        new = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("new endpoint")],
        )
        result = diff_contracts(old, new)
        assert not result.has_breaking_changes
        assert len(result.changes) == 1
        assert result.changes[0].change_type == ChangeType.ADDED

    def test_removed_interaction(self):
        old = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("old endpoint")],
        )
        new = Contract(consumer="a", provider="b", interactions=[])
        result = diff_contracts(old, new)
        assert result.has_breaking_changes
        assert len(result.changes) == 1
        assert result.changes[0].change_type == ChangeType.REMOVED

    def test_status_code_change(self):
        old = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", status=200)],
        )
        new = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", status=201)],
        )
        result = diff_contracts(old, new)
        assert result.has_breaking_changes
        breaking = result.breaking_changes
        assert any("status" in c.path.lower() for c in breaking)

    def test_body_field_removed(self):
        old = Contract(
            consumer="a",
            provider="b",
            interactions=[
                _make_interaction("test", body={"id": 1, "name": "test"})
            ],
        )
        new = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", body={"id": 1})],
        )
        result = diff_contracts(old, new)
        assert result.has_breaking_changes

    def test_body_field_added(self):
        old = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", body={"id": 1})],
        )
        new = Contract(
            consumer="a",
            provider="b",
            interactions=[
                _make_interaction("test", body={"id": 1, "name": "test"})
            ],
        )
        result = diff_contracts(old, new)
        assert not result.has_breaking_changes
        assert len(result.non_breaking_changes) == 1

    def test_body_type_change(self):
        old = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", body={"id": 1})],
        )
        new = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", body={"id": "one"})],
        )
        result = diff_contracts(old, new)
        assert result.has_breaking_changes

    def test_body_value_change(self):
        old = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", body={"id": 1})],
        )
        new = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", body={"id": 2})],
        )
        result = diff_contracts(old, new)
        # Value changes are INFO severity
        assert not result.has_breaking_changes
        assert len(result.info_changes) == 1

    def test_body_added(self):
        old = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", body=None)],
        )
        new = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", body={"id": 1})],
        )
        result = diff_contracts(old, new)
        assert not result.has_breaking_changes

    def test_body_removed(self):
        old = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", body={"id": 1})],
        )
        new = Contract(
            consumer="a",
            provider="b",
            interactions=[_make_interaction("test", body=None)],
        )
        result = diff_contracts(old, new)
        assert result.has_breaking_changes

    def test_multiple_changes(self):
        old = Contract(
            consumer="a",
            provider="b",
            interactions=[
                _make_interaction("get users", path="/users", body={"items": []}),
                _make_interaction("get item", path="/items/1"),
            ],
        )
        new = Contract(
            consumer="a",
            provider="b",
            interactions=[
                _make_interaction("get users", path="/users", body={"data": []}),
                _make_interaction("create item", method="POST", path="/items"),
            ],
        )
        result = diff_contracts(old, new)
        assert len(result.changes) > 0


class TestContractDiff:
    def test_properties(self):
        old = Contract(consumer="a", provider="b")
        new = Contract(consumer="a", provider="b")
        diff = ContractDiff(old_contract=old, new_contract=new)
        assert diff.has_breaking_changes is False
        assert diff.breaking_changes == []
        assert diff.non_breaking_changes == []
        assert diff.info_changes == []

    def test_to_dict(self):
        old = Contract(consumer="a", provider="b")
        new = Contract(consumer="a", provider="b")
        diff = ContractDiff(
            old_contract=old,
            new_contract=new,
            changes=[
                ContractChange(
                    change_type=ChangeType.ADDED,
                    severity=Severity.NON_BREAKING,
                    path="test",
                    description="test change",
                )
            ],
        )
        d = diff.to_dict()
        assert d["has_breaking_changes"] is False
        assert d["summary"]["total"] == 1


class TestContractChange:
    def test_to_dict(self):
        change = ContractChange(
            change_type=ChangeType.MODIFIED,
            severity=Severity.BREAKING,
            path="response.body.id",
            description="Type changed",
            old_value="int",
            new_value="string",
        )
        d = change.to_dict()
        assert d["change_type"] == "modified"
        assert d["severity"] == "breaking"
        assert d["old_value"] == "int"
        assert d["new_value"] == "string"

    def test_to_dict_minimal(self):
        change = ContractChange(
            change_type=ChangeType.ADDED,
            severity=Severity.INFO,
            path="test",
            description="added",
        )
        d = change.to_dict()
        assert "old_value" not in d
        assert "new_value" not in d
