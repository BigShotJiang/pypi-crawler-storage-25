"""Tests for the provider verifier and mock provider."""

import pytest

from pactship.models import (
    Contract,
    Header,
    HttpMethod,
    Interaction,
    Matcher,
    MatcherType,
    QueryParam,
    RequestSpec,
    ResponseSpec,
)
from pactship.verifier import MockProvider, ProviderVerifier


class TestMockProvider:
    @pytest.fixture
    def provider(self):
        return MockProvider()

    @pytest.fixture
    def interaction(self):
        return Interaction(
            description="Get user",
            request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
            response=ResponseSpec(
                status=200,
                body={"id": 1, "name": "Alice"},
                headers=[Header(name="Content-Type", value="application/json")],
            ),
        )

    def test_add_interaction(self, provider, interaction):
        provider.add_interaction(interaction)
        assert len(provider.interactions) == 1

    def test_find_interaction(self, provider, interaction):
        provider.add_interaction(interaction)
        found = provider.find_interaction("GET", "/users/1")
        assert found is not None
        assert found.description == "Get user"

    def test_find_not_found(self, provider):
        assert provider.find_interaction("GET", "/nowhere") is None

    def test_find_wrong_method(self, provider, interaction):
        provider.add_interaction(interaction)
        assert provider.find_interaction("POST", "/users/1") is None

    def test_get_mock_response(self, provider, interaction):
        provider.add_interaction(interaction)
        result = provider.get_mock_response("GET", "/users/1")
        assert result is not None
        status, headers, body = result
        assert status == 200
        assert body == {"id": 1, "name": "Alice"}
        assert headers["Content-Type"] == "application/json"

    def test_get_mock_response_not_found(self, provider):
        assert provider.get_mock_response("GET", "/nowhere") is None

    def test_clear(self, provider, interaction):
        provider.add_interaction(interaction)
        provider.clear()
        assert len(provider.interactions) == 0

    def test_add_from_contract(self, provider):
        contract = Contract(
            consumer="a",
            provider="b",
            interactions=[
                Interaction(
                    description="get1",
                    request=RequestSpec(method=HttpMethod.GET, path="/a"),
                    response=ResponseSpec(status=200),
                ),
                Interaction(
                    description="get2",
                    request=RequestSpec(method=HttpMethod.GET, path="/b"),
                    response=ResponseSpec(status=200),
                ),
            ],
        )
        provider.add_interactions_from_contract(contract)
        assert len(provider.interactions) == 2

    def test_interactions_returns_copy(self, provider, interaction):
        provider.add_interaction(interaction)
        interactions = provider.interactions
        interactions.clear()
        assert len(provider.interactions) == 1


class TestProviderVerifier:
    def test_init(self):
        v = ProviderVerifier("http://localhost:8080")
        assert v.base_url == "http://localhost:8080"

    def test_init_trailing_slash(self):
        v = ProviderVerifier("http://localhost:8080/")
        assert v.base_url == "http://localhost:8080"

    def test_init_with_headers(self):
        v = ProviderVerifier(
            "http://localhost:8080",
            headers={"Authorization": "Bearer token"},
        )
        assert v.default_headers["Authorization"] == "Bearer token"

    def test_register_state_handler(self):
        v = ProviderVerifier("http://localhost:8080")
        handler = lambda: None
        v.register_state_handler("user exists", handler)
        assert "user exists" in v._state_handlers
