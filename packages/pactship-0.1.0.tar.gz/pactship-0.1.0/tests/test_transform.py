"""Tests for contract transformations."""

import pytest

from pactship.models import Contract, HttpMethod, Interaction, RequestSpec, ResponseSpec
from pactship.transform import (
    add_header_to_all,
    add_tag_to_all,
    prefix_paths,
    remove_tag_from_all,
    rename_service,
    rewrite_paths,
    strip_fields,
    transform_bodies,
    version_api,
)


def _i(desc, method="GET", path="/test", status=200, body=None, tags=None):
    return Interaction(
        description=desc,
        request=RequestSpec(method=HttpMethod(method), path=path),
        response=ResponseSpec(status=status, body=body),
        tags=tags or [],
    )


@pytest.fixture
def contract():
    return Contract(
        consumer="frontend", provider="backend",
        interactions=[
            _i("List users", path="/users", body={"items": [{"id": 1, "secret": "x"}]}),
            _i("Get user", path="/users/1", body={"id": 1, "name": "Alice", "secret": "x"}),
            _i("Create user", "POST", "/users", 201, body={"id": 1}, tags=["write"]),
        ],
    )


class TestAddHeader:
    def test_request_header(self, contract):
        result = add_header_to_all(contract, "Authorization", "Bearer token")
        for i in result.interactions:
            assert any(h.name == "Authorization" for h in i.request.headers)
        # Original unchanged
        assert len(contract.interactions[0].request.headers) == 0

    def test_response_header(self, contract):
        result = add_header_to_all(contract, "X-Version", "2", request=False)
        for i in result.interactions:
            assert any(h.name == "X-Version" for h in i.response.headers)


class TestRewritePaths:
    def test_rewrite(self, contract):
        result = rewrite_paths(contract, r"/users", "/api/v2/users")
        assert result.interactions[0].request.path == "/api/v2/users"
        assert result.interactions[1].request.path == "/api/v2/users/1"

    def test_regex(self, contract):
        result = rewrite_paths(contract, r"/users/(\d+)", r"/people/\1")
        assert result.interactions[1].request.path == "/people/1"


class TestPrefixPaths:
    def test_prefix(self, contract):
        result = prefix_paths(contract, "/api")
        assert result.interactions[0].request.path == "/api/users"
        assert result.interactions[1].request.path == "/api/users/1"

    def test_no_double_prefix(self, contract):
        result = prefix_paths(contract, "/api")
        result2 = prefix_paths(result, "/api")
        assert result2.interactions[0].request.path == "/api/users"


class TestRenameService:
    def test_rename_consumer(self, contract):
        result = rename_service(contract, "frontend", "web-app")
        assert result.consumer == "web-app"
        assert result.provider == "backend"

    def test_rename_provider(self, contract):
        result = rename_service(contract, "backend", "user-api")
        assert result.provider == "user-api"

    def test_no_match(self, contract):
        result = rename_service(contract, "nonexistent", "new")
        assert result.consumer == "frontend"
        assert result.provider == "backend"


class TestTagOperations:
    def test_add_tag(self, contract):
        result = add_tag_to_all(contract, "v2")
        assert all("v2" in i.tags for i in result.interactions)

    def test_add_tag_no_duplicates(self, contract):
        result = add_tag_to_all(contract, "write")
        write_tags = [i for i in result.interactions if i.tags.count("write") > 1]
        assert len(write_tags) == 0

    def test_remove_tag(self, contract):
        result = add_tag_to_all(contract, "v2")
        result2 = remove_tag_from_all(result, "v2")
        assert all("v2" not in i.tags for i in result2.interactions)


class TestTransformBodies:
    def test_transform_response(self, contract):
        def uppercase_keys(body):
            if isinstance(body, dict):
                return {k.upper(): v for k, v in body.items()}
            return body

        result = transform_bodies(contract, uppercase_keys)
        assert "ID" in result.interactions[1].response.body

    def test_original_unchanged(self, contract):
        transform_bodies(contract, lambda b: None)
        assert contract.interactions[1].response.body is not None


class TestVersionApi:
    def test_version(self, contract):
        result = version_api(contract, "v2")
        assert result.interactions[0].request.path == "/v2/users"

    def test_version_with_slash(self, contract):
        result = version_api(contract, "/v3")
        assert result.interactions[0].request.path == "/v3/users"


class TestStripFields:
    def test_strip_from_response(self, contract):
        result = strip_fields(contract, ["secret"])
        body = result.interactions[1].response.body
        assert "secret" not in body
        assert "name" in body

    def test_strip_nested(self, contract):
        result = strip_fields(contract, ["secret"])
        items = result.interactions[0].response.body["items"]
        assert "secret" not in items[0]

    def test_original_unchanged(self, contract):
        strip_fields(contract, ["secret"])
        assert "secret" in contract.interactions[1].response.body
