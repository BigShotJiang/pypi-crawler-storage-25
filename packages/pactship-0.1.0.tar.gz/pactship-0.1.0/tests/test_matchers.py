"""Tests for the matcher engine."""

import pytest

from pactship.matchers import (
    MatchError,
    any_of,
    array_like,
    boolean_match,
    decimal_match,
    each_like,
    email_match,
    exact,
    integer_match,
    iso_date,
    iso_datetime,
    like,
    match_value,
    nullable,
    range_match,
    regex,
    string_match,
    uuid_match,
)
from pactship.models import Matcher, MatcherType


class TestExactMatch:
    def test_match(self):
        errors = match_value("field", None, "hello", {"field": exact("hello")})
        assert len(errors) == 0

    def test_mismatch(self):
        errors = match_value("field", None, "world", {"field": exact("hello")})
        assert len(errors) == 1

    def test_match_number(self):
        errors = match_value("field", None, 42, {"field": exact(42)})
        assert len(errors) == 0


class TestTypeMatch:
    def test_string(self):
        errors = match_value("f", None, "hello", {"f": like("string")})
        assert len(errors) == 0

    def test_string_fail(self):
        errors = match_value("f", None, 42, {"f": like("string")})
        assert len(errors) == 1

    def test_integer(self):
        errors = match_value("f", None, 42, {"f": like("integer")})
        assert len(errors) == 0

    def test_number(self):
        errors = match_value("f", None, 3.14, {"f": like("number")})
        assert len(errors) == 0

    def test_boolean(self):
        errors = match_value("f", None, True, {"f": like("boolean")})
        assert len(errors) == 0

    def test_list(self):
        errors = match_value("f", None, [1, 2], {"f": like("list")})
        assert len(errors) == 0

    def test_dict(self):
        errors = match_value("f", None, {"a": 1}, {"f": like("dict")})
        assert len(errors) == 0

    def test_unknown_type(self):
        errors = match_value("f", None, "hello", {"f": like("unknown")})
        assert len(errors) == 0  # unknown type doesn't fail


class TestRegexMatch:
    def test_match(self):
        errors = match_value("f", None, "abc123", {"f": regex(r"^[a-z]+\d+$")})
        assert len(errors) == 0

    def test_mismatch(self):
        errors = match_value("f", None, "123abc", {"f": regex(r"^[a-z]+\d+$")})
        assert len(errors) == 1

    def test_non_string(self):
        errors = match_value("f", None, 42, {"f": regex(r"\d+")})
        assert len(errors) == 1

    def test_missing_pattern(self):
        m = Matcher(type=MatcherType.REGEX)
        errors = match_value("f", None, "test", {"f": m})
        assert len(errors) == 1


class TestRangeMatch:
    def test_in_range(self):
        errors = match_value("f", None, 50, {"f": range_match(0, 100)})
        assert len(errors) == 0

    def test_below_min(self):
        errors = match_value("f", None, -1, {"f": range_match(0, 100)})
        assert len(errors) == 1

    def test_above_max(self):
        errors = match_value("f", None, 101, {"f": range_match(0, 100)})
        assert len(errors) == 1

    def test_min_only(self):
        errors = match_value("f", None, 5, {"f": range_match(min_val=0)})
        assert len(errors) == 0

    def test_max_only(self):
        errors = match_value("f", None, 5, {"f": range_match(max_val=10)})
        assert len(errors) == 0

    def test_non_number(self):
        errors = match_value("f", None, "five", {"f": range_match(0, 10)})
        assert len(errors) == 1


class TestArrayLikeMatch:
    def test_match(self):
        errors = match_value("f", None, [1, 2, 3], {"f": array_like(1)})
        assert len(errors) == 0

    def test_empty_array_no_min(self):
        errors = match_value("f", None, [], {"f": array_like(0)})
        assert len(errors) == 0

    def test_too_short(self):
        errors = match_value("f", None, [1], {"f": array_like(3)})
        assert len(errors) == 1

    def test_non_array(self):
        errors = match_value("f", None, "not array", {"f": array_like()})
        assert len(errors) == 1


class TestEachLikeMatch:
    def test_match(self):
        errors = match_value(
            "f", None, [{"id": 1}, {"id": 2}],
            {"f": each_like({"id": 0})}
        )
        assert len(errors) == 0

    def test_type_mismatch_in_element(self):
        errors = match_value(
            "f", None, [{"id": "not_int"}],
            {"f": each_like({"id": 0})}
        )
        assert len(errors) == 1

    def test_non_array(self):
        errors = match_value("f", None, "not array", {"f": each_like({"id": 0})})
        assert len(errors) == 1


class TestAnyOfMatch:
    def test_match(self):
        errors = match_value("f", None, "a", {"f": any_of(["a", "b", "c"])})
        assert len(errors) == 0

    def test_mismatch(self):
        errors = match_value("f", None, "d", {"f": any_of(["a", "b", "c"])})
        assert len(errors) == 1


class TestNullableMatch:
    def test_null(self):
        errors = match_value("f", None, None, {"f": nullable("string")})
        assert len(errors) == 0

    def test_correct_type(self):
        errors = match_value("f", None, "hello", {"f": nullable("string")})
        assert len(errors) == 0

    def test_wrong_type(self):
        errors = match_value("f", None, 42, {"f": nullable("string")})
        assert len(errors) == 1

    def test_nullable_no_type(self):
        errors = match_value("f", None, "anything", {"f": nullable()})
        assert len(errors) == 0


class TestIsoDateMatch:
    def test_valid(self):
        errors = match_value("f", None, "2024-01-15", {"f": iso_date()})
        assert len(errors) == 0

    def test_invalid(self):
        errors = match_value("f", None, "not-a-date", {"f": iso_date()})
        assert len(errors) == 1

    def test_non_string(self):
        errors = match_value("f", None, 42, {"f": iso_date()})
        assert len(errors) == 1


class TestIsoDatetimeMatch:
    def test_valid(self):
        errors = match_value(
            "f", None, "2024-01-15T10:30:00", {"f": iso_datetime()}
        )
        assert len(errors) == 0

    def test_invalid(self):
        errors = match_value("f", None, "not-datetime", {"f": iso_datetime()})
        assert len(errors) == 1

    def test_non_string(self):
        errors = match_value("f", None, 42, {"f": iso_datetime()})
        assert len(errors) == 1


class TestUuidMatch:
    def test_valid(self):
        errors = match_value(
            "f", None, "550e8400-e29b-41d4-a716-446655440000", {"f": uuid_match()}
        )
        assert len(errors) == 0

    def test_invalid(self):
        errors = match_value("f", None, "not-a-uuid", {"f": uuid_match()})
        assert len(errors) == 1

    def test_non_string(self):
        errors = match_value("f", None, 42, {"f": uuid_match()})
        assert len(errors) == 1


class TestEmailMatch:
    def test_valid(self):
        errors = match_value("f", None, "test@example.com", {"f": email_match()})
        assert len(errors) == 0

    def test_invalid(self):
        errors = match_value("f", None, "not-email", {"f": email_match()})
        assert len(errors) == 1

    def test_non_string(self):
        errors = match_value("f", None, 42, {"f": email_match()})
        assert len(errors) == 1


class TestIntegerMatch:
    def test_valid(self):
        errors = match_value("f", None, 42, {"f": integer_match()})
        assert len(errors) == 0

    def test_float_fails(self):
        errors = match_value("f", None, 3.14, {"f": integer_match()})
        assert len(errors) == 1

    def test_bool_fails(self):
        errors = match_value("f", None, True, {"f": integer_match()})
        assert len(errors) == 1

    def test_string_fails(self):
        errors = match_value("f", None, "42", {"f": integer_match()})
        assert len(errors) == 1


class TestDecimalMatch:
    def test_float(self):
        errors = match_value("f", None, 3.14, {"f": decimal_match()})
        assert len(errors) == 0

    def test_int(self):
        errors = match_value("f", None, 42, {"f": decimal_match()})
        assert len(errors) == 0

    def test_bool_fails(self):
        errors = match_value("f", None, True, {"f": decimal_match()})
        assert len(errors) == 1

    def test_string_fails(self):
        errors = match_value("f", None, "3.14", {"f": decimal_match()})
        assert len(errors) == 1


class TestBooleanMatch:
    def test_true(self):
        errors = match_value("f", None, True, {"f": boolean_match()})
        assert len(errors) == 0

    def test_false(self):
        errors = match_value("f", None, False, {"f": boolean_match()})
        assert len(errors) == 0

    def test_int_fails(self):
        errors = match_value("f", None, 1, {"f": boolean_match()})
        assert len(errors) == 1


class TestStringMatch:
    def test_valid(self):
        errors = match_value("f", None, "hello", {"f": string_match()})
        assert len(errors) == 0

    def test_int_fails(self):
        errors = match_value("f", None, 42, {"f": string_match()})
        assert len(errors) == 1


class TestDirectValueMatching:
    def test_equal_values(self):
        errors = match_value("root", {"name": "test"}, {"name": "test"})
        assert len(errors) == 0

    def test_mismatched_values(self):
        errors = match_value("root", {"name": "a"}, {"name": "b"})
        assert len(errors) == 1

    def test_missing_key(self):
        errors = match_value("root", {"name": "a", "age": 1}, {"name": "a"})
        assert len(errors) == 1

    def test_extra_key_ok(self):
        errors = match_value("root", {"name": "a"}, {"name": "a", "age": 1})
        assert len(errors) == 0

    def test_type_mismatch(self):
        errors = match_value("root", {"name": "str"}, {"name": 42})
        assert len(errors) == 1

    def test_nested_dict(self):
        expected = {"user": {"name": "test", "age": 25}}
        actual = {"user": {"name": "test", "age": 25}}
        errors = match_value("root", expected, actual)
        assert len(errors) == 0

    def test_nested_dict_mismatch(self):
        expected = {"user": {"name": "test"}}
        actual = {"user": {"name": "other"}}
        errors = match_value("root", expected, actual)
        assert len(errors) == 1

    def test_list_match(self):
        errors = match_value("root", [1, 2, 3], [1, 2, 3])
        assert len(errors) == 0

    def test_list_shorter_actual(self):
        errors = match_value("root", [1, 2, 3], [1, 2])
        assert len(errors) == 1

    def test_list_longer_actual_ok(self):
        errors = match_value("root", [1, 2], [1, 2, 3])
        assert len(errors) == 0

    def test_none_expected(self):
        errors = match_value("root", None, "anything")
        assert len(errors) == 0


class TestMatchError:
    def test_str(self):
        err = MatchError("body.name", "expected string")
        assert "body.name" in str(err)
        assert "expected string" in str(err)
