"""Tests for compatibility matrix."""

import tempfile
from pathlib import Path

import pytest

from pactship.matrix import CompatibilityEntry, CompatibilityMatrix


@pytest.fixture
def matrix():
    return CompatibilityMatrix()


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


class TestCompatibilityEntry:
    def test_to_dict(self):
        entry = CompatibilityEntry(
            consumer="frontend", consumer_version="1.0.0",
            provider="backend", provider_version="2.0.0",
            compatible=True,
        )
        d = entry.to_dict()
        assert d["consumer"] == "frontend"
        assert d["compatible"] is True
        assert d["timestamp"]  # auto-generated

    def test_from_dict(self):
        data = {
            "consumer": "a", "consumer_version": "1.0",
            "provider": "b", "provider_version": "2.0",
            "compatible": False,
            "timestamp": "2024-01-01T00:00:00",
            "details": {"errors": 3},
        }
        entry = CompatibilityEntry.from_dict(data)
        assert entry.consumer == "a"
        assert not entry.compatible
        assert entry.details["errors"] == 3

    def test_roundtrip(self):
        original = CompatibilityEntry(
            consumer="x", consumer_version="1.0",
            provider="y", provider_version="2.0",
            compatible=True,
            details={"passed": 5},
        )
        restored = CompatibilityEntry.from_dict(original.to_dict())
        assert restored.consumer == original.consumer
        assert restored.compatible == original.compatible
        assert restored.details == original.details


class TestCompatibilityMatrix:
    def test_add_and_check(self, matrix):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="2.0",
            compatible=True,
        ))
        assert matrix.is_compatible("a", "1.0", "b", "2.0") is True

    def test_unknown_pair(self, matrix):
        assert matrix.is_compatible("a", "1.0", "b", "2.0") is None

    def test_incompatible(self, matrix):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="3.0",
            compatible=False,
        ))
        assert matrix.is_compatible("a", "1.0", "b", "3.0") is False

    def test_latest_entry_wins(self, matrix):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="2.0",
            compatible=True,
        ))
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="2.0",
            compatible=False,
        ))
        assert matrix.is_compatible("a", "1.0", "b", "2.0") is False

    def test_get_compatible_providers(self, matrix):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="1.0",
            compatible=True,
        ))
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="2.0",
            compatible=True,
        ))
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="3.0",
            compatible=False,
        ))
        versions = matrix.get_compatible_providers("a", "1.0", "b")
        assert "1.0" in versions
        assert "2.0" in versions
        assert "3.0" not in versions

    def test_get_compatible_consumers(self, matrix):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="2.0",
            compatible=True,
        ))
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="2.0",
            provider="b", provider_version="2.0",
            compatible=False,
        ))
        versions = matrix.get_compatible_consumers("b", "2.0", "a")
        assert "1.0" in versions
        assert "2.0" not in versions

    def test_get_entries_all(self, matrix):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="1.0",
            compatible=True,
        ))
        assert len(matrix.get_entries()) == 1

    def test_get_entries_filtered(self, matrix):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="1.0",
            compatible=True,
        ))
        matrix.add(CompatibilityEntry(
            consumer="c", consumer_version="1.0",
            provider="b", provider_version="1.0",
            compatible=True,
        ))
        assert len(matrix.get_entries(consumer="a")) == 1
        assert len(matrix.get_entries(provider="b")) == 2

    def test_to_table(self, matrix):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="2.0",
            compatible=True,
        ))
        table = matrix.to_table()
        assert table["a@1.0"]["b@2.0"] is True

    def test_save_load(self, matrix, temp_dir):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="2.0",
            compatible=True,
        ))
        path = temp_dir / "matrix.json"
        matrix.save(path)

        loaded = CompatibilityMatrix()
        loaded.load(path)
        assert len(loaded) == 1
        assert loaded.is_compatible("a", "1.0", "b", "2.0") is True

    def test_load_nonexistent(self, matrix, temp_dir):
        matrix.load(temp_dir / "nonexistent.json")
        assert len(matrix) == 0

    def test_clear(self, matrix):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="1.0",
            compatible=True,
        ))
        matrix.clear()
        assert len(matrix) == 0

    def test_entries_returns_copy(self, matrix):
        matrix.add(CompatibilityEntry(
            consumer="a", consumer_version="1.0",
            provider="b", provider_version="1.0",
            compatible=True,
        ))
        entries = matrix.entries
        entries.clear()
        assert len(matrix) == 1
