"""Tests for interaction filtering."""

import pytest

from pactship.filters import (
    filter_contract,
    filter_interactions,
    find_interaction,
    group_by_method,
    group_by_path_prefix,
    group_by_tag,
)
from pactship.models import (
    Contract,
    HttpMethod,
    Interaction,
    RequestSpec,
    ResponseSpec,
)


def _i(desc, method="GET", path="/test", status=200, tags=None, states=None):
    return Interaction(
        description=desc,
        request=RequestSpec(method=HttpMethod(method), path=path),
        response=ResponseSpec(status=status),
        tags=tags or [],
        provider_states=states or [],
    )


@pytest.fixture
def contract():
    return Contract(
        consumer="frontend", provider="backend",
        interactions=[
            _i("List users", "GET", "/users", 200, ["v2", "public"]),
            _i("Get user", "GET", "/users/1", 200, ["v2"], ["user exists"]),
            _i("Create user", "POST", "/users", 201, ["v2", "admin"]),
            _i("Delete user", "DELETE", "/users/1", 204, ["admin"], ["user exists"]),
            _i("Health check", "GET", "/health", 200),
        ],
    )


class TestFilterInteractions:
    def test_by_method(self, contract):
        results = filter_interactions(contract, method="GET")
        assert len(results) == 3

    def test_by_method_enum(self, contract):
        results = filter_interactions(contract, method=HttpMethod.POST)
        assert len(results) == 1

    def test_by_path_pattern(self, contract):
        results = filter_interactions(contract, path_pattern=r"/users")
        assert len(results) == 4

    def test_by_path_exact_pattern(self, contract):
        results = filter_interactions(contract, path_pattern=r"^/users/1$")
        assert len(results) == 2

    def test_by_tag(self, contract):
        results = filter_interactions(contract, tag="admin")
        assert len(results) == 2

    def test_by_tags_any(self, contract):
        results = filter_interactions(contract, tags_any=["admin", "public"])
        assert len(results) == 3

    def test_by_tags_all(self, contract):
        results = filter_interactions(contract, tags_all=["v2", "admin"])
        assert len(results) == 1

    def test_by_description(self, contract):
        results = filter_interactions(contract, description_pattern="user")
        assert len(results) == 4

    def test_by_status(self, contract):
        results = filter_interactions(contract, status=200)
        assert len(results) == 3

    def test_by_provider_state(self, contract):
        results = filter_interactions(contract, provider_state="user exists")
        assert len(results) == 2

    def test_by_predicate(self, contract):
        results = filter_interactions(
            contract,
            predicate=lambda i: len(i.tags) > 1,
        )
        assert len(results) == 2

    def test_combined_filters(self, contract):
        results = filter_interactions(contract, method="GET", tag="v2")
        assert len(results) == 2

    def test_no_match(self, contract):
        results = filter_interactions(contract, method="PATCH")
        assert len(results) == 0


class TestFilterContract:
    def test_returns_new_contract(self, contract):
        filtered = filter_contract(contract, method="GET")
        assert filtered.consumer == "frontend"
        assert len(filtered.interactions) == 3
        assert len(contract.interactions) == 5  # original unchanged


class TestGroupByTag:
    def test_groups(self, contract):
        groups = group_by_tag(contract)
        assert "v2" in groups
        assert "admin" in groups
        assert "untagged" in groups
        assert len(groups["v2"]) == 3
        assert len(groups["untagged"]) == 1

    def test_empty(self):
        c = Contract(consumer="a", provider="b")
        assert group_by_tag(c) == {}


class TestGroupByMethod:
    def test_groups(self, contract):
        groups = group_by_method(contract)
        assert len(groups["GET"]) == 3
        assert len(groups["POST"]) == 1
        assert len(groups["DELETE"]) == 1


class TestGroupByPathPrefix:
    def test_depth_1(self, contract):
        groups = group_by_path_prefix(contract, depth=1)
        assert "/users" in groups
        assert "/health" in groups
        assert len(groups["/users"]) == 4

    def test_depth_2(self, contract):
        groups = group_by_path_prefix(contract, depth=2)
        assert "/users/1" in groups


class TestFindInteraction:
    def test_by_description(self, contract):
        result = find_interaction(contract, description="Health check")
        assert result is not None
        assert result.request.path == "/health"

    def test_by_method_and_path(self, contract):
        result = find_interaction(contract, method="POST", path="/users")
        assert result is not None
        assert result.description == "Create user"

    def test_not_found(self, contract):
        result = find_interaction(contract, description="nonexistent")
        assert result is None
