"""Tests for configuration management."""

import json
import os
import tempfile
from pathlib import Path
from unittest import mock

import pytest
import yaml

from pactship.config import PactshipConfig, load_config, save_config


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


class TestPactshipConfig:
    def test_defaults(self):
        config = PactshipConfig()
        assert config.broker_dir == ".pactship"
        assert config.timeout == 30.0
        assert config.report_format == "text"
        assert not config.strict_mode

    def test_to_dict(self):
        config = PactshipConfig(broker_dir="/custom", timeout=60.0)
        d = config.to_dict()
        assert d["broker_dir"] == "/custom"
        assert d["timeout"] == 60.0

    def test_from_dict(self):
        data = {"broker_dir": "/custom", "timeout": 10.0, "strict_mode": True}
        config = PactshipConfig.from_dict(data)
        assert config.broker_dir == "/custom"
        assert config.timeout == 10.0
        assert config.strict_mode is True

    def test_from_dict_defaults(self):
        config = PactshipConfig.from_dict({})
        assert config.broker_dir == ".pactship"

    def test_roundtrip(self):
        original = PactshipConfig(
            broker_dir="/custom",
            timeout=15.0,
            default_headers={"Authorization": "Bearer token"},
            strict_mode=True,
        )
        restored = PactshipConfig.from_dict(original.to_dict())
        assert restored.broker_dir == original.broker_dir
        assert restored.timeout == original.timeout
        assert restored.default_headers == original.default_headers


class TestLoadConfig:
    def test_defaults_no_file(self, temp_dir):
        config = load_config(config_path=temp_dir / "nonexistent.yaml")
        assert config.broker_dir == ".pactship"

    def test_from_yaml(self, temp_dir):
        path = temp_dir / ".pactship.yaml"
        path.write_text(yaml.dump({"broker_dir": "/custom", "timeout": 5.0}))
        config = load_config(config_path=path)
        assert config.broker_dir == "/custom"
        assert config.timeout == 5.0

    def test_from_json(self, temp_dir):
        path = temp_dir / ".pactship.json"
        path.write_text(json.dumps({"report_format": "junit"}))
        config = load_config(config_path=path)
        assert config.report_format == "junit"

    def test_env_override_string(self, temp_dir):
        with mock.patch.dict(os.environ, {"PACTSHIP_BROKER_DIR": "/from-env"}):
            config = load_config(config_path=temp_dir / "nope.yaml")
            assert config.broker_dir == "/from-env"

    def test_env_override_timeout(self):
        with mock.patch.dict(os.environ, {"PACTSHIP_TIMEOUT": "5.0"}):
            config = load_config(config_path=None)
            assert config.timeout == 5.0

    def test_env_override_bool_true(self):
        with mock.patch.dict(os.environ, {"PACTSHIP_STRICT_MODE": "true"}):
            config = load_config(config_path=None)
            assert config.strict_mode is True

    def test_env_override_bool_false(self):
        with mock.patch.dict(os.environ, {"PACTSHIP_STRICT_MODE": "false"}):
            config = load_config(config_path=None)
            assert config.strict_mode is False

    def test_env_override_bool_yes(self):
        with mock.patch.dict(os.environ, {"PACTSHIP_FAIL_ON_WARNING": "yes"}):
            config = load_config(config_path=None)
            assert config.fail_on_warning is True

    def test_env_headers(self):
        with mock.patch.dict(os.environ, {"PACTSHIP_HEADER_AUTHORIZATION": "Bearer xyz"}):
            config = load_config(config_path=None)
            assert config.default_headers.get("AUTHORIZATION") == "Bearer xyz"

    def test_env_overrides_file(self, temp_dir):
        path = temp_dir / "config.yaml"
        path.write_text(yaml.dump({"broker_dir": "/file", "timeout": 10.0}))
        with mock.patch.dict(os.environ, {"PACTSHIP_BROKER_DIR": "/env"}):
            config = load_config(config_path=path)
            assert config.broker_dir == "/env"  # env wins
            assert config.timeout == 10.0  # file value preserved


class TestSaveConfig:
    def test_save_yaml(self, temp_dir):
        config = PactshipConfig(broker_dir="/custom", strict_mode=True)
        path = temp_dir / "config.yaml"
        save_config(config, path)
        data = yaml.safe_load(path.read_text())
        assert data["broker_dir"] == "/custom"
        assert data["strict_mode"] is True

    def test_save_json(self, temp_dir):
        config = PactshipConfig(timeout=15.0)
        path = temp_dir / "config.json"
        save_config(config, path)
        data = json.loads(path.read_text())
        assert data["timeout"] == 15.0

    def test_roundtrip_yaml(self, temp_dir):
        original = PactshipConfig(
            broker_dir="/test",
            provider_base_urls={"api": "http://localhost:8080"},
        )
        path = temp_dir / "config.yaml"
        save_config(original, path)
        loaded = load_config(config_path=path)
        assert loaded.broker_dir == original.broker_dir
        assert loaded.provider_base_urls == original.provider_base_urls
