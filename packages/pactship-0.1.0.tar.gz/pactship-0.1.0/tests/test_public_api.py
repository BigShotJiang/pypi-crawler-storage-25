"""Tests for public API imports."""

import pytest


class TestPublicImports:
    def test_version(self):
        from pactship import __version__
        assert __version__ == "0.1.0"

    def test_models(self):
        from pactship import (
            Contract, Interaction, RequestSpec, ResponseSpec,
            HttpMethod, Header, QueryParam, Matcher, MatcherType,
        )
        c = Contract(consumer="a", provider="b")
        assert c.consumer == "a"

    def test_dsl(self):
        from pactship import ContractBuilder, InteractionBuilder
        builder = ContractBuilder("a", "b")
        assert builder is not None

    def test_matchers(self):
        from pactship import (
            exact, like, regex, range_match, array_like,
            each_like, any_of, nullable, iso_date, iso_datetime,
            uuid_match, email_match, integer_match, decimal_match,
            boolean_match, string_match,
        )
        m = exact("hello")
        assert m.type.value == "exact"

    def test_io(self):
        from pactship import load_contract, save_contract
        assert callable(load_contract)

    def test_verifier(self):
        from pactship import ProviderVerifier, MockProvider
        v = ProviderVerifier("http://localhost:8080")
        assert v.base_url == "http://localhost:8080"

    def test_diff(self):
        from pactship import diff_contracts, Contract
        c = Contract(consumer="a", provider="b")
        result = diff_contracts(c, c)
        assert not result.has_breaking_changes

    def test_broker(self):
        from pactship import ContractBroker
        assert callable(ContractBroker)

    def test_validator(self):
        from pactship import validate_contract, Contract
        c = Contract(consumer="a", provider="b", interactions=[])
        result = validate_contract(c)
        assert result.valid

    def test_generator(self):
        from pactship import generate_crud_contract, generate_from_endpoints
        c = generate_crud_contract("a", "b", "user", "/users", {"name": "x"})
        assert len(c.interactions) == 5

    def test_linter(self):
        from pactship import lint_contract, Contract
        c = Contract(consumer="a", provider="b")
        result = lint_contract(c)
        assert isinstance(result.passed, bool)

    def test_graph(self):
        from pactship import ServiceGraph, Contract
        g = ServiceGraph()
        g.add_contract(Contract(consumer="a", provider="b"))
        assert len(g.nodes) == 2

    def test_all_exports(self):
        import pactship
        assert len(pactship.__all__) > 30
