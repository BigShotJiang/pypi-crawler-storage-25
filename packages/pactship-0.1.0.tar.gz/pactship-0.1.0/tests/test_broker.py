"""Tests for the local contract broker."""

import tempfile
from pathlib import Path

import pytest

from pactship.broker import ContractBroker
from pactship.models import (
    Contract,
    HttpMethod,
    Interaction,
    RequestSpec,
    ResponseSpec,
)


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


@pytest.fixture
def broker(temp_dir):
    return ContractBroker(temp_dir / "broker")


@pytest.fixture
def sample_contract():
    return Contract(
        consumer="frontend",
        provider="backend",
        interactions=[
            Interaction(
                description="Get user",
                request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
                response=ResponseSpec(status=200, body={"id": 1}),
            ),
        ],
    )


class TestPublish:
    def test_publish(self, broker, sample_contract):
        path = broker.publish(sample_contract)
        assert path.exists()

    def test_publish_creates_latest(self, broker, sample_contract):
        broker.publish(sample_contract)
        latest = broker.get_latest("frontend", "backend")
        assert latest is not None
        assert latest.consumer == "frontend"

    def test_publish_creates_version(self, broker, sample_contract):
        broker.publish(sample_contract)
        versions = broker.list_versions("frontend", "backend")
        assert len(versions) == 1

    def test_publish_multiple_versions(self, broker, sample_contract):
        broker.publish(sample_contract)
        # Modify and publish again
        sample_contract.interactions.append(
            Interaction(
                description="Create user",
                request=RequestSpec(method=HttpMethod.POST, path="/users"),
                response=ResponseSpec(status=201),
            )
        )
        broker.publish(sample_contract)
        versions = broker.list_versions("frontend", "backend")
        # Note: if run very fast, timestamps may collide
        assert len(versions) >= 1


class TestGetLatest:
    def test_not_found(self, broker):
        assert broker.get_latest("x", "y") is None

    def test_get_after_publish(self, broker, sample_contract):
        broker.publish(sample_contract)
        latest = broker.get_latest("frontend", "backend")
        assert latest is not None
        assert len(latest.interactions) == 1


class TestListPairs:
    def test_empty(self, broker):
        assert broker.list_pairs() == []

    def test_with_contracts(self, broker):
        c1 = Contract(consumer="a", provider="b")
        c2 = Contract(consumer="c", provider="d")
        broker.publish(c1)
        broker.publish(c2)
        pairs = broker.list_pairs()
        assert len(pairs) == 2
        assert ("a", "b") in pairs
        assert ("c", "d") in pairs


class TestListForProvider:
    def test_empty(self, broker):
        assert broker.list_contracts_for_provider("x") == []

    def test_filter(self, broker):
        c1 = Contract(
            consumer="a",
            provider="api",
            interactions=[
                Interaction(
                    description="test",
                    request=RequestSpec(method=HttpMethod.GET, path="/"),
                    response=ResponseSpec(status=200),
                )
            ],
        )
        c2 = Contract(
            consumer="b",
            provider="api",
            interactions=[
                Interaction(
                    description="test2",
                    request=RequestSpec(method=HttpMethod.GET, path="/health"),
                    response=ResponseSpec(status=200),
                )
            ],
        )
        c3 = Contract(consumer="a", provider="other")
        broker.publish(c1)
        broker.publish(c2)
        broker.publish(c3)
        contracts = broker.list_contracts_for_provider("api")
        assert len(contracts) == 2


class TestListForConsumer:
    def test_filter(self, broker):
        c1 = Contract(consumer="frontend", provider="api1")
        c2 = Contract(consumer="frontend", provider="api2")
        c3 = Contract(consumer="mobile", provider="api1")
        broker.publish(c1)
        broker.publish(c2)
        broker.publish(c3)
        contracts = broker.list_contracts_for_consumer("frontend")
        assert len(contracts) == 2


class TestVerifications:
    def test_save_and_get(self, broker):
        report = {"success": True, "tests": 5}
        broker.save_verification("a", "b", report)
        results = broker.get_verifications("a", "b")
        assert len(results) == 1
        assert results[0]["success"] is True

    def test_empty(self, broker):
        assert broker.get_verifications("x", "y") == []

    def test_limit(self, broker):
        for i in range(5):
            broker.save_verification("a", "b", {"run": i})
        results = broker.get_verifications("a", "b", limit=3)
        assert len(results) == 3


class TestDeletePair:
    def test_delete(self, broker, sample_contract):
        broker.publish(sample_contract)
        broker.save_verification("frontend", "backend", {"ok": True})
        assert broker.delete_pair("frontend", "backend")
        assert broker.get_latest("frontend", "backend") is None
        assert broker.get_verifications("frontend", "backend") == []

    def test_delete_nonexistent(self, broker):
        assert broker.delete_pair("x", "y") is False


class TestClear:
    def test_clear(self, broker, sample_contract):
        broker.publish(sample_contract)
        broker.save_verification("frontend", "backend", {"ok": True})
        broker.clear()
        assert broker.list_pairs() == []
