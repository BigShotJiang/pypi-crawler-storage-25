"""Tests for JSON Schema generation and validation."""

import pytest

from pactship.models import (
    HttpMethod,
    Interaction,
    Matcher,
    MatcherType,
    RequestSpec,
    ResponseSpec,
    Contract,
)
from pactship.schema import (
    contract_to_schemas,
    interaction_to_schema,
    validate_body_against_schema,
)


def _interaction(body=None, matchers=None, method="GET", path="/test"):
    return Interaction(
        description="test",
        request=RequestSpec(method=HttpMethod(method), path=path),
        response=ResponseSpec(status=200, body=body, body_matchers=matchers or {}),
    )


class TestInteractionToSchema:
    def test_null_body(self):
        schema = interaction_to_schema(_interaction(body=None))
        assert schema == {"type": "null"}

    def test_dict_body(self):
        schema = interaction_to_schema(_interaction(body={"id": 1, "name": "Alice"}))
        assert schema["type"] == "object"
        assert "id" in schema["properties"]
        assert "name" in schema["properties"]
        assert schema["properties"]["id"]["type"] == "integer"
        assert schema["properties"]["name"]["type"] == "string"
        assert set(schema["required"]) == {"id", "name"}

    def test_list_body(self):
        schema = interaction_to_schema(_interaction(body=[{"id": 1}]))
        assert schema["type"] == "array"
        assert schema["items"]["type"] == "object"

    def test_nested_body(self):
        schema = interaction_to_schema(
            _interaction(body={"user": {"name": "Alice", "age": 25}})
        )
        user_schema = schema["properties"]["user"]
        assert user_schema["type"] == "object"
        assert "name" in user_schema["properties"]

    def test_string_example(self):
        schema = interaction_to_schema(_interaction(body={"name": "test"}))
        assert schema["properties"]["name"]["example"] == "test"

    def test_boolean_body(self):
        schema = interaction_to_schema(_interaction(body={"active": True}))
        assert schema["properties"]["active"]["type"] == "boolean"

    def test_float_body(self):
        schema = interaction_to_schema(_interaction(body={"price": 9.99}))
        assert schema["properties"]["price"]["type"] == "number"


class TestContractToSchemas:
    def test_basic(self):
        contract = Contract(
            consumer="a", provider="b",
            interactions=[
                _interaction(body={"id": 1}, path="/users"),
                _interaction(body={"ok": True}, path="/health"),
            ],
        )
        schemas = contract_to_schemas(contract)
        assert "GET /users" in schemas
        assert "GET /health" in schemas
        assert schemas["GET /users"]["response"]["status"] == 200

    def test_includes_request_schema(self):
        interaction = Interaction(
            description="Create",
            request=RequestSpec(
                method=HttpMethod.POST, path="/users",
                body={"name": "Alice"},
            ),
            response=ResponseSpec(status=201, body={"id": 1}),
        )
        contract = Contract(consumer="a", provider="b", interactions=[interaction])
        schemas = contract_to_schemas(contract)
        req_schema = schemas["POST /users"]["request"]
        assert "body" in req_schema
        assert req_schema["body"]["properties"]["name"]["type"] == "string"


class TestValidateBodyAgainstSchema:
    def test_valid_object(self):
        schema = {
            "type": "object",
            "properties": {
                "id": {"type": "integer"},
                "name": {"type": "string"},
            },
            "required": ["id", "name"],
        }
        errors = validate_body_against_schema({"id": 1, "name": "Alice"}, schema)
        assert len(errors) == 0

    def test_missing_required(self):
        schema = {
            "type": "object",
            "properties": {"id": {"type": "integer"}},
            "required": ["id"],
        }
        errors = validate_body_against_schema({}, schema)
        assert len(errors) == 1
        assert "required" in errors[0]

    def test_wrong_type(self):
        schema = {"type": "string"}
        errors = validate_body_against_schema(42, schema)
        assert len(errors) == 1

    def test_null_when_not_nullable(self):
        schema = {"type": "string"}
        errors = validate_body_against_schema(None, schema)
        assert len(errors) == 1

    def test_nullable(self):
        schema = {"type": ["string", "null"]}
        errors = validate_body_against_schema(None, schema)
        assert len(errors) == 0

    def test_array_validation(self):
        schema = {
            "type": "array",
            "items": {"type": "integer"},
        }
        errors = validate_body_against_schema([1, 2, 3], schema)
        assert len(errors) == 0

    def test_array_min_items(self):
        schema = {"type": "array", "minItems": 3}
        errors = validate_body_against_schema([1], schema)
        assert len(errors) == 1

    def test_enum(self):
        schema = {"type": "string", "enum": ["a", "b", "c"]}
        errors = validate_body_against_schema("d", schema)
        assert len(errors) == 1

    def test_enum_valid(self):
        schema = {"type": "string", "enum": ["a", "b"]}
        errors = validate_body_against_schema("a", schema)
        assert len(errors) == 0

    def test_pattern(self):
        schema = {"type": "string", "pattern": r"^\d{3}$"}
        errors = validate_body_against_schema("abc", schema)
        assert len(errors) == 1

    def test_pattern_valid(self):
        schema = {"type": "string", "pattern": r"^\d{3}$"}
        errors = validate_body_against_schema("123", schema)
        assert len(errors) == 0

    def test_minimum(self):
        schema = {"type": "integer", "minimum": 0}
        errors = validate_body_against_schema(-1, schema)
        assert len(errors) == 1

    def test_maximum(self):
        schema = {"type": "integer", "maximum": 100}
        errors = validate_body_against_schema(101, schema)
        assert len(errors) == 1

    def test_nested_validation(self):
        schema = {
            "type": "object",
            "properties": {
                "user": {
                    "type": "object",
                    "properties": {"name": {"type": "string"}},
                    "required": ["name"],
                }
            },
            "required": ["user"],
        }
        errors = validate_body_against_schema(
            {"user": {"name": 42}}, schema
        )
        assert len(errors) == 1

    def test_bool_not_integer(self):
        schema = {"type": "integer"}
        errors = validate_body_against_schema(True, schema)
        assert len(errors) == 1
