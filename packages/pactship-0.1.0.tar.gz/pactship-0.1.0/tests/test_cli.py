"""Tests for CLI interface."""

import json
import tempfile
from pathlib import Path

import pytest
from click.testing import CliRunner

from pactship.cli import main
from pactship.contract_io import save_contract
from pactship.models import (
    Contract, HttpMethod, Interaction, RequestSpec, ResponseSpec,
)


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


@pytest.fixture
def sample_contract():
    return Contract(
        consumer="frontend",
        provider="backend",
        interactions=[
            Interaction(
                description="Get user",
                request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
                response=ResponseSpec(status=200, body={"id": 1, "name": "Alice"}),
            ),
        ],
    )


@pytest.fixture
def contract_file(temp_dir, sample_contract):
    path = temp_dir / "contract.yaml"
    save_contract(sample_contract, path)
    return path


class TestVersion:
    def test_version(self, runner):
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "pactship" in result.output


class TestValidate:
    def test_valid(self, runner, contract_file):
        result = runner.invoke(main, ["validate", str(contract_file)])
        assert result.exit_code == 0
        assert "Valid" in result.output
        assert "frontend" in result.output

    def test_invalid_file(self, runner, temp_dir):
        bad_file = temp_dir / "bad.yaml"
        bad_file.write_text("not: a: valid: contract", encoding="utf-8")
        result = runner.invoke(main, ["validate", str(bad_file)])
        assert result.exit_code == 1

    def test_nonexistent(self, runner):
        result = runner.invoke(main, ["validate", "/nonexistent.yaml"])
        assert result.exit_code != 0


class TestDiff:
    def test_no_changes(self, runner, temp_dir, sample_contract):
        old = temp_dir / "old.yaml"
        new = temp_dir / "new.yaml"
        save_contract(sample_contract, old)
        save_contract(sample_contract, new)
        result = runner.invoke(main, ["diff", str(old), str(new)])
        assert result.exit_code == 0
        assert "No changes" in result.output

    def test_breaking_change(self, runner, temp_dir, sample_contract):
        old = temp_dir / "old.yaml"
        save_contract(sample_contract, old)

        modified = Contract(
            consumer="frontend", provider="backend",
            interactions=[],
        )
        new = temp_dir / "new.yaml"
        save_contract(modified, new)

        result = runner.invoke(main, ["diff", str(old), str(new)])
        assert result.exit_code == 1  # breaking changes

    def test_json_output(self, runner, temp_dir, sample_contract):
        old = temp_dir / "old.yaml"
        new = temp_dir / "new.yaml"
        save_contract(sample_contract, old)
        save_contract(sample_contract, new)
        result = runner.invoke(main, ["diff", str(old), str(new), "-j"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "has_breaking_changes" in data


class TestPublish:
    def test_publish(self, runner, temp_dir, contract_file):
        broker_dir = temp_dir / "broker"
        result = runner.invoke(
            main, ["publish", str(contract_file), "-d", str(broker_dir)]
        )
        assert result.exit_code == 0
        assert "Published" in result.output


class TestList:
    def test_empty(self, runner, temp_dir):
        broker_dir = temp_dir / "broker"
        broker_dir.mkdir()
        result = runner.invoke(main, ["list", "-d", str(broker_dir)])
        assert result.exit_code == 0
        assert "No contracts" in result.output

    def test_with_contracts(self, runner, temp_dir, contract_file):
        broker_dir = temp_dir / "broker"
        runner.invoke(main, ["publish", str(contract_file), "-d", str(broker_dir)])
        result = runner.invoke(main, ["list", "-d", str(broker_dir)])
        assert result.exit_code == 0
        assert "frontend" in result.output


class TestConvert:
    def test_yaml_to_json(self, runner, temp_dir, contract_file):
        output = temp_dir / "out.json"
        result = runner.invoke(
            main, ["convert", str(contract_file), str(output), "-f", "json"]
        )
        assert result.exit_code == 0
        data = json.loads(output.read_text())
        assert data["consumer"] == "frontend"

    def test_json_to_yaml(self, runner, temp_dir, sample_contract):
        json_file = temp_dir / "contract.json"
        save_contract(sample_contract, json_file, fmt="json")
        output = temp_dir / "out.yaml"
        result = runner.invoke(
            main, ["convert", str(json_file), str(output), "-f", "yaml"]
        )
        assert result.exit_code == 0
        assert output.exists()
