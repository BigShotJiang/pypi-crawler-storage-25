"""Tests for verification hooks."""

import pytest

from pactship.hooks import HookRegistry
from pactship.models import (
    Contract, HttpMethod, Interaction, RequestSpec, ResponseSpec, VerificationResult,
)


@pytest.fixture
def registry():
    return HookRegistry()


@pytest.fixture
def contract():
    return Contract(consumer="a", provider="b")


@pytest.fixture
def interaction():
    return Interaction(
        description="test",
        request=RequestSpec(method=HttpMethod.GET, path="/test"),
        response=ResponseSpec(status=200),
    )


@pytest.fixture
def result(interaction):
    return VerificationResult(interaction=interaction, success=True)


class TestBeforeAll:
    def test_register(self, registry, contract):
        called = []
        registry.before_all(lambda c: called.append(c.consumer))
        errors = registry.run_before_all(contract)
        assert errors == []
        assert called == ["a"]

    def test_multiple(self, registry, contract):
        calls = []
        registry.before_all(lambda c: calls.append(1))
        registry.before_all(lambda c: calls.append(2))
        registry.run_before_all(contract)
        assert calls == [1, 2]

    def test_error(self, registry, contract):
        registry.before_all(lambda c: (_ for _ in ()).throw(RuntimeError("boom")))
        errors = registry.run_before_all(contract)
        assert len(errors) == 1
        assert "boom" in errors[0]


class TestAfterAll:
    def test_register(self, registry, contract, result):
        called = []
        registry.after_all(lambda c, r: called.append(True))
        registry.run_after_all(contract, [result])
        assert len(called) == 1

    def test_error(self, registry, contract, result):
        registry.after_all(lambda c, r: (_ for _ in ()).throw(RuntimeError("fail")))
        errors = registry.run_after_all(contract, [result])
        assert len(errors) == 1


class TestBeforeEach:
    def test_register(self, registry, interaction):
        called = []
        registry.before_each(lambda i: called.append(i.description))
        errors = registry.run_before_each(interaction)
        assert errors == []
        assert called == ["test"]

    def test_error(self, registry, interaction):
        registry.before_each(lambda i: (_ for _ in ()).throw(ValueError("oops")))
        errors = registry.run_before_each(interaction)
        assert len(errors) == 1


class TestAfterEach:
    def test_register(self, registry, interaction, result):
        called = []
        registry.after_each(lambda i, r: called.append(r.success))
        errors = registry.run_after_each(interaction, result)
        assert errors == []
        assert called == [True]


class TestOnError:
    def test_register(self, registry, interaction):
        called = []
        registry.on_error(lambda i, e: called.append(e))
        registry.run_on_error(interaction, ["error1"])
        assert len(called) == 1

    def test_error_swallowed(self, registry, interaction):
        registry.on_error(lambda i, e: (_ for _ in ()).throw(RuntimeError()))
        # Should not raise
        registry.run_on_error(interaction, [])


class TestStateHandlers:
    def test_register(self, registry):
        @registry.state("user exists")
        def setup_user():
            pass

        handler = registry.get_state_handler("user exists")
        assert handler is not None

    def test_unknown_state(self, registry):
        assert registry.get_state_handler("unknown") is None


class TestHookRegistry:
    def test_clear(self, registry):
        registry.before_all(lambda c: None)
        registry.after_all(lambda c, r: None)
        registry.before_each(lambda i: None)
        assert registry.hook_count == 3
        registry.clear()
        assert registry.hook_count == 0

    def test_decorator_returns_fn(self, registry):
        @registry.before_each
        def my_hook(i):
            pass

        assert callable(my_hook)

    def test_state_decorator_returns_fn(self, registry):
        @registry.state("test state")
        def setup():
            pass

        assert callable(setup)
