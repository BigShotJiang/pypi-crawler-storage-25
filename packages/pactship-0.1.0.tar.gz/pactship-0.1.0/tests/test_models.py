"""Tests for core data models."""

import json

import pytest

from pactship.models import (
    Contract,
    ContractVerificationReport,
    ContractVersion,
    Header,
    HttpMethod,
    Interaction,
    Matcher,
    MatcherType,
    QueryParam,
    RequestSpec,
    ResponseSpec,
    VerificationResult,
)


class TestHttpMethod:
    def test_all_methods(self):
        assert HttpMethod.GET == "GET"
        assert HttpMethod.POST == "POST"
        assert HttpMethod.PUT == "PUT"
        assert HttpMethod.PATCH == "PATCH"
        assert HttpMethod.DELETE == "DELETE"
        assert HttpMethod.HEAD == "HEAD"
        assert HttpMethod.OPTIONS == "OPTIONS"

    def test_from_string(self):
        assert HttpMethod("GET") == HttpMethod.GET
        assert HttpMethod("POST") == HttpMethod.POST


class TestMatcher:
    def test_to_dict_minimal(self):
        m = Matcher(type=MatcherType.EXACT, value="hello")
        d = m.to_dict()
        assert d == {"type": "exact", "value": "hello"}

    def test_to_dict_full(self):
        m = Matcher(
            type=MatcherType.RANGE,
            min_val=0,
            max_val=100,
            pattern=r"\d+",
            example="42",
        )
        d = m.to_dict()
        assert d["type"] == "range"
        assert d["min"] == 0
        assert d["max"] == 100
        assert d["pattern"] == r"\d+"
        assert d["example"] == "42"

    def test_from_dict(self):
        data = {"type": "regex", "pattern": r"\d+", "example": "42"}
        m = Matcher.from_dict(data)
        assert m.type == MatcherType.REGEX
        assert m.pattern == r"\d+"
        assert m.example == "42"

    def test_roundtrip(self):
        original = Matcher(
            type=MatcherType.RANGE, min_val=1, max_val=10, example=5
        )
        restored = Matcher.from_dict(original.to_dict())
        assert restored.type == original.type
        assert restored.min_val == original.min_val
        assert restored.max_val == original.max_val


class TestHeader:
    def test_to_dict(self):
        h = Header(name="Content-Type", value="application/json")
        assert h.to_dict() == {"name": "Content-Type", "value": "application/json"}

    def test_to_dict_with_matcher(self):
        h = Header(
            name="X-Custom",
            value="test",
            matcher=Matcher(type=MatcherType.REGEX, pattern=r"\w+"),
        )
        d = h.to_dict()
        assert "matcher" in d
        assert d["matcher"]["type"] == "regex"

    def test_from_dict(self):
        data = {"name": "Accept", "value": "text/html"}
        h = Header.from_dict(data)
        assert h.name == "Accept"
        assert h.value == "text/html"

    def test_from_dict_with_matcher(self):
        data = {
            "name": "X-Custom",
            "value": "test",
            "matcher": {"type": "exact"},
        }
        h = Header.from_dict(data)
        assert h.matcher is not None
        assert h.matcher.type == MatcherType.EXACT


class TestQueryParam:
    def test_to_dict(self):
        q = QueryParam(name="page", value="1")
        assert q.to_dict() == {"name": "page", "value": "1"}

    def test_from_dict(self):
        q = QueryParam.from_dict({"name": "limit", "value": "10"})
        assert q.name == "limit"
        assert q.value == "10"


class TestRequestSpec:
    def test_minimal(self):
        r = RequestSpec(method=HttpMethod.GET, path="/users")
        d = r.to_dict()
        assert d == {"method": "GET", "path": "/users"}

    def test_full(self):
        r = RequestSpec(
            method=HttpMethod.POST,
            path="/users",
            headers=[Header(name="Content-Type", value="application/json")],
            query_params=[QueryParam(name="page", value="1")],
            body={"name": "test"},
        )
        d = r.to_dict()
        assert d["method"] == "POST"
        assert len(d["headers"]) == 1
        assert len(d["query_params"]) == 1
        assert d["body"] == {"name": "test"}

    def test_from_dict(self):
        data = {
            "method": "DELETE",
            "path": "/users/1",
            "headers": [{"name": "Authorization", "value": "Bearer token"}],
        }
        r = RequestSpec.from_dict(data)
        assert r.method == HttpMethod.DELETE
        assert r.path == "/users/1"
        assert len(r.headers) == 1


class TestResponseSpec:
    def test_minimal(self):
        r = ResponseSpec(status=200)
        assert r.to_dict() == {"status": 200}

    def test_with_body(self):
        r = ResponseSpec(
            status=201,
            body={"id": 1, "name": "test"},
            headers=[Header(name="Location", value="/users/1")],
        )
        d = r.to_dict()
        assert d["status"] == 201
        assert d["body"]["id"] == 1
        assert len(d["headers"]) == 1

    def test_from_dict(self):
        data = {"status": 404, "body": {"error": "not found"}}
        r = ResponseSpec.from_dict(data)
        assert r.status == 404
        assert r.body == {"error": "not found"}


class TestInteraction:
    def test_basic(self):
        interaction = Interaction(
            description="Get user",
            request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
            response=ResponseSpec(status=200, body={"id": 1}),
        )
        d = interaction.to_dict()
        assert d["description"] == "Get user"
        assert d["request"]["method"] == "GET"
        assert d["response"]["status"] == 200

    def test_with_provider_states(self):
        interaction = Interaction(
            description="Get user",
            request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
            response=ResponseSpec(status=200),
            provider_states=["user 1 exists"],
        )
        d = interaction.to_dict()
        assert d["provider_states"] == ["user 1 exists"]

    def test_with_tags(self):
        interaction = Interaction(
            description="Get user",
            request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
            response=ResponseSpec(status=200),
            tags=["v2", "user-api"],
        )
        d = interaction.to_dict()
        assert d["tags"] == ["v2", "user-api"]

    def test_fingerprint(self):
        i1 = Interaction(
            description="Get user",
            request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
            response=ResponseSpec(status=200),
        )
        i2 = Interaction(
            description="Get user",
            request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
            response=ResponseSpec(status=200),
        )
        assert i1.fingerprint == i2.fingerprint

    def test_fingerprint_different(self):
        i1 = Interaction(
            description="Get user",
            request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
            response=ResponseSpec(status=200),
        )
        i2 = Interaction(
            description="Get user",
            request=RequestSpec(method=HttpMethod.GET, path="/users/2"),
            response=ResponseSpec(status=200),
        )
        assert i1.fingerprint != i2.fingerprint

    def test_from_dict(self):
        data = {
            "description": "Create user",
            "request": {"method": "POST", "path": "/users"},
            "response": {"status": 201, "body": {"id": 1}},
            "provider_states": ["empty db"],
            "tags": ["create"],
        }
        i = Interaction.from_dict(data)
        assert i.description == "Create user"
        assert i.request.method == HttpMethod.POST
        assert i.response.status == 201
        assert i.provider_states == ["empty db"]


class TestContract:
    def test_basic(self):
        c = Contract(consumer="frontend", provider="backend")
        d = c.to_dict()
        assert d["consumer"] == "frontend"
        assert d["provider"] == "backend"
        assert d["version"] == "1.0"
        assert d["interactions"] == []

    def test_with_interactions(self):
        c = Contract(
            consumer="frontend",
            provider="backend",
            interactions=[
                Interaction(
                    description="Get user",
                    request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
                    response=ResponseSpec(status=200, body={"id": 1}),
                )
            ],
        )
        d = c.to_dict()
        assert len(d["interactions"]) == 1

    def test_fingerprint(self):
        c = Contract(consumer="frontend", provider="backend")
        assert len(c.fingerprint) == 16

    def test_from_dict(self):
        data = {
            "consumer": "app",
            "provider": "api",
            "interactions": [
                {
                    "description": "health",
                    "request": {"method": "GET", "path": "/health"},
                    "response": {"status": 200},
                }
            ],
        }
        c = Contract.from_dict(data)
        assert c.consumer == "app"
        assert len(c.interactions) == 1

    def test_roundtrip(self):
        original = Contract(
            consumer="svc-a",
            provider="svc-b",
            interactions=[
                Interaction(
                    description="Get items",
                    request=RequestSpec(method=HttpMethod.GET, path="/items"),
                    response=ResponseSpec(
                        status=200, body={"items": [{"id": 1}]}
                    ),
                    provider_states=["items exist"],
                )
            ],
            metadata={"generated_by": "pactship"},
        )
        restored = Contract.from_dict(original.to_dict())
        assert restored.consumer == original.consumer
        assert restored.provider == original.provider
        assert len(restored.interactions) == 1
        assert restored.metadata == original.metadata


class TestVerificationResult:
    def test_success(self):
        interaction = Interaction(
            description="test",
            request=RequestSpec(method=HttpMethod.GET, path="/"),
            response=ResponseSpec(status=200),
        )
        r = VerificationResult(interaction=interaction, success=True)
        d = r.to_dict()
        assert d["success"] is True
        assert d["errors"] == []

    def test_failure(self):
        interaction = Interaction(
            description="test",
            request=RequestSpec(method=HttpMethod.GET, path="/"),
            response=ResponseSpec(status=200),
        )
        r = VerificationResult(
            interaction=interaction,
            success=False,
            errors=["Status mismatch"],
        )
        assert r.to_dict()["success"] is False


class TestContractVerificationReport:
    def test_empty(self):
        c = Contract(consumer="a", provider="b")
        report = ContractVerificationReport(contract=c)
        assert report.passed == 0
        assert report.failed == 0
        assert report.total == 0
        assert report.success is True

    def test_with_results(self):
        c = Contract(consumer="a", provider="b")
        interaction = Interaction(
            description="test",
            request=RequestSpec(method=HttpMethod.GET, path="/"),
            response=ResponseSpec(status=200),
        )
        report = ContractVerificationReport(
            contract=c,
            results=[
                VerificationResult(interaction=interaction, success=True),
                VerificationResult(
                    interaction=interaction,
                    success=False,
                    errors=["err"],
                ),
            ],
        )
        assert report.passed == 1
        assert report.failed == 1
        assert report.total == 2

    def test_to_dict(self):
        c = Contract(consumer="a", provider="b")
        report = ContractVerificationReport(contract=c)
        d = report.to_dict()
        assert d["consumer"] == "a"
        assert d["provider"] == "b"
        assert d["summary"]["total"] == 0
