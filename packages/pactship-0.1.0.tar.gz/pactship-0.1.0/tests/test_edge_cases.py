"""Edge case tests for robustness."""

import json
import tempfile
from pathlib import Path

import pytest

from pactship.models import (
    Contract, Header, HttpMethod, Interaction, Matcher, MatcherType,
    QueryParam, RequestSpec, ResponseSpec,
)
from pactship.matchers import match_value, exact, like, regex, each_like
from pactship.contract_io import load_contract, save_contract
from pactship.diff import diff_contracts
from pactship.dsl import ContractBuilder, InteractionBuilder
from pactship.validator import validate_contract


class TestMatcherEdgeCases:
    def test_deeply_nested_match(self):
        expected = {"a": {"b": {"c": {"d": {"e": "deep"}}}}}
        actual = {"a": {"b": {"c": {"d": {"e": "deep"}}}}}
        errors = match_value("root", expected, actual)
        assert len(errors) == 0

    def test_deeply_nested_mismatch(self):
        expected = {"a": {"b": {"c": "x"}}}
        actual = {"a": {"b": {"c": "y"}}}
        errors = match_value("root", expected, actual)
        assert len(errors) == 1
        assert "c" in errors[0].path

    def test_empty_dict_match(self):
        errors = match_value("root", {}, {})
        assert len(errors) == 0

    def test_empty_list_match(self):
        errors = match_value("root", [], [])
        assert len(errors) == 0

    def test_mixed_types_in_list(self):
        errors = match_value("root", [1, "two", True], [1, "two", True])
        assert len(errors) == 0

    def test_nested_list_in_dict(self):
        expected = {"items": [{"id": 1}, {"id": 2}]}
        actual = {"items": [{"id": 1}, {"id": 2}]}
        errors = match_value("root", expected, actual)
        assert len(errors) == 0

    def test_null_value_in_dict(self):
        expected = {"name": "test", "optional": None}
        actual = {"name": "test", "optional": None}
        errors = match_value("root", expected, actual)
        assert len(errors) == 0

    def test_large_number_range(self):
        from pactship.matchers import range_match
        errors = match_value("f", None, 999999999, {"f": range_match(0, 10**18)})
        assert len(errors) == 0

    def test_regex_special_chars(self):
        errors = match_value(
            "f", None, "test@example.com",
            {"f": regex(r"^[^@]+@[^@]+\.[^@]+$")}
        )
        assert len(errors) == 0

    def test_each_like_empty_array(self):
        errors = match_value("f", None, [], {"f": each_like({"id": 0})})
        assert len(errors) == 0

    def test_exact_none(self):
        errors = match_value("f", None, None, {"f": exact(None)})
        assert len(errors) == 0

    def test_matcher_with_boolean_value(self):
        from pactship.matchers import boolean_match
        errors = match_value("f", None, False, {"f": boolean_match()})
        assert len(errors) == 0


class TestModelEdgeCases:
    def test_contract_empty_metadata(self):
        c = Contract(consumer="a", provider="b")
        d = c.to_dict()
        assert d["metadata"] == {}
        restored = Contract.from_dict(d)
        assert restored.metadata == {}

    def test_interaction_empty_everything(self):
        i = Interaction(
            description="minimal",
            request=RequestSpec(method=HttpMethod.GET, path="/"),
            response=ResponseSpec(status=200),
        )
        d = i.to_dict()
        assert "headers" not in d["request"]
        assert "body" not in d["request"]
        restored = Interaction.from_dict(d)
        assert restored.request.headers == []

    def test_header_no_value(self):
        h = Header(name="X-Custom")
        d = h.to_dict()
        assert "value" not in d

    def test_query_param_no_value(self):
        q = QueryParam(name="sort")
        d = q.to_dict()
        assert "value" not in d

    def test_fingerprint_stability(self):
        i = Interaction(
            description="test",
            request=RequestSpec(method=HttpMethod.GET, path="/api"),
            response=ResponseSpec(status=200),
        )
        fp1 = i.fingerprint
        fp2 = i.fingerprint
        assert fp1 == fp2

    def test_contract_many_interactions(self):
        interactions = [
            Interaction(
                description=f"interaction-{i}",
                request=RequestSpec(method=HttpMethod.GET, path=f"/path-{i}"),
                response=ResponseSpec(status=200),
            )
            for i in range(100)
        ]
        c = Contract(consumer="a", provider="b", interactions=interactions)
        d = c.to_dict()
        assert len(d["interactions"]) == 100
        restored = Contract.from_dict(d)
        assert len(restored.interactions) == 100


class TestDiffEdgeCases:
    def test_diff_empty_contracts(self):
        old = Contract(consumer="a", provider="b")
        new = Contract(consumer="a", provider="b")
        result = diff_contracts(old, new)
        assert len(result.changes) == 0

    def test_diff_same_route_different_description(self):
        old = Contract(consumer="a", provider="b", interactions=[
            Interaction(
                description="old name",
                request=RequestSpec(method=HttpMethod.GET, path="/test"),
                response=ResponseSpec(status=200),
            ),
        ])
        new = Contract(consumer="a", provider="b", interactions=[
            Interaction(
                description="new name",
                request=RequestSpec(method=HttpMethod.GET, path="/test"),
                response=ResponseSpec(status=200),
            ),
        ])
        result = diff_contracts(old, new)
        # Route exists in both, not a breaking change
        assert not result.has_breaking_changes

    def test_diff_nested_body_changes(self):
        old = Contract(consumer="a", provider="b", interactions=[
            Interaction(
                description="test",
                request=RequestSpec(method=HttpMethod.GET, path="/test"),
                response=ResponseSpec(status=200, body={"user": {"name": "Alice", "age": 25}}),
            ),
        ])
        new = Contract(consumer="a", provider="b", interactions=[
            Interaction(
                description="test",
                request=RequestSpec(method=HttpMethod.GET, path="/test"),
                response=ResponseSpec(status=200, body={"user": {"name": "Alice"}}),
            ),
        ])
        result = diff_contracts(old, new)
        assert result.has_breaking_changes  # field removed


class TestIOEdgeCases:
    def test_save_load_unicode(self):
        with tempfile.TemporaryDirectory() as d:
            c = Contract(
                consumer="frontend",
                provider="backend",
                interactions=[
                    Interaction(
                        description="Get user with unicode: ",
                        request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
                        response=ResponseSpec(status=200, body={"name": "Alice"}),
                    ),
                ],
            )
            path = Path(d) / "contract.yaml"
            save_contract(c, path)
            loaded = load_contract(path)
            assert "" in loaded.interactions[0].description

    def test_save_load_special_chars(self):
        with tempfile.TemporaryDirectory() as d:
            c = Contract(
                consumer="my-app",
                provider="api-v2",
                interactions=[
                    Interaction(
                        description="Path with special: /users/{id}/roles",
                        request=RequestSpec(method=HttpMethod.GET, path="/users/{id}/roles"),
                        response=ResponseSpec(status=200, body={"roles": ["admin"]}),
                    ),
                ],
            )
            path = Path(d) / "contract.json"
            save_contract(c, path, fmt="json")
            loaded = load_contract(path)
            assert loaded.interactions[0].request.path == "/users/{id}/roles"


class TestDSLEdgeCases:
    def test_empty_contract(self):
        c = ContractBuilder("a", "b").build()
        assert len(c.interactions) == 0

    def test_interaction_defaults(self):
        i = InteractionBuilder("test").build()
        assert i.request.method == HttpMethod.GET
        assert i.request.path == "/"
        assert i.response.status == 200

    def test_chain_many_headers(self):
        builder = InteractionBuilder("test").with_request("GET", "/")
        for i in range(20):
            builder = builder.with_request_header(f"X-Header-{i}", f"value-{i}")
        interaction = builder.will_respond_with(200).build()
        assert len(interaction.request.headers) == 20


class TestValidatorEdgeCases:
    def test_many_interactions_same_description(self):
        interactions = [
            Interaction(
                description="same",
                request=RequestSpec(method=HttpMethod.GET, path=f"/path-{i}"),
                response=ResponseSpec(status=200),
            )
            for i in range(5)
        ]
        c = Contract(consumer="a", provider="b", interactions=interactions)
        result = validate_contract(c)
        # Should have duplicate description warnings
        warnings = [w for w in result.warnings if "Duplicate" in w.message]
        assert len(warnings) == 4  # first is ok, 4 duplicates
