"""Tests for contract linter."""

import pytest

from pactship.linter import (
    lint_contract,
    lint_missing_content_type,
    lint_naming_conventions,
    lint_path_conventions,
    lint_response_body,
    lint_status_codes,
)
from pactship.models import (
    Contract, Header, HttpMethod, Interaction, RequestSpec, ResponseSpec,
)


def _i(desc="test", method="GET", path="/test", status=200, body=None,
       req_body=None, req_headers=None):
    return Interaction(
        description=desc,
        request=RequestSpec(
            method=HttpMethod(method), path=path,
            body=req_body,
            headers=[Header(name=k, value=v) for k, v in (req_headers or {}).items()],
        ),
        response=ResponseSpec(status=status, body=body),
    )


def _contract(consumer="frontend", provider="backend", interactions=None):
    return Contract(
        consumer=consumer, provider=provider,
        interactions=interactions or [_i()],
    )


class TestNamingConventions:
    def test_valid_names(self):
        issues = lint_naming_conventions(_contract("user-api", "auth-service"))
        assert len(issues) == 0

    def test_uppercase_name(self):
        issues = lint_naming_conventions(_contract("UserAPI", "backend"))
        assert len(issues) == 1
        assert issues[0].rule == "naming-convention"

    def test_space_in_name(self):
        issues = lint_naming_conventions(_contract("my service", "backend"))
        assert len(issues) == 1


class TestPathConventions:
    def test_valid_paths(self):
        issues = lint_path_conventions(_contract(interactions=[_i(path="/users/1")]))
        assert len(issues) == 0

    def test_trailing_slash(self):
        issues = lint_path_conventions(_contract(interactions=[_i(path="/users/")]))
        assert any(i.rule == "no-trailing-slash" for i in issues)

    def test_uppercase_path(self):
        issues = lint_path_conventions(_contract(interactions=[_i(path="/Users")]))
        assert any(i.rule == "lowercase-paths" for i in issues)

    def test_underscore_path(self):
        issues = lint_path_conventions(_contract(interactions=[_i(path="/user_list")]))
        assert any(i.rule == "no-underscores" for i in issues)

    def test_path_params_ok(self):
        issues = lint_path_conventions(_contract(interactions=[_i(path="/users/{userId}")]))
        name_issues = [i for i in issues if i.rule == "lowercase-paths"]
        assert len(name_issues) == 0


class TestStatusCodes:
    def test_post_200_warning(self):
        issues = lint_status_codes(_contract(interactions=[
            _i(method="POST", path="/users", status=200),
        ]))
        assert any(i.rule == "post-201" for i in issues)

    def test_post_201_ok(self):
        issues = lint_status_codes(_contract(interactions=[
            _i(method="POST", path="/users", status=201),
        ]))
        assert not any(i.rule == "post-201" for i in issues)

    def test_delete_200_warning(self):
        issues = lint_status_codes(_contract(interactions=[
            _i(method="DELETE", path="/users/1", status=200),
        ]))
        assert any(i.rule == "delete-204" for i in issues)

    def test_204_with_body(self):
        issues = lint_status_codes(_contract(interactions=[
            _i(status=204, body={"ok": True}),
        ]))
        assert any(i.rule == "204-no-body" for i in issues)

    def test_204_no_body_ok(self):
        issues = lint_status_codes(_contract(interactions=[
            _i(method="DELETE", status=204),
        ]))
        assert not any(i.rule == "204-no-body" for i in issues)


class TestMissingContentType:
    def test_body_without_ct(self):
        issues = lint_missing_content_type(_contract(interactions=[
            _i(method="POST", req_body={"name": "test"}),
        ]))
        assert any(i.rule == "content-type-header" for i in issues)

    def test_body_with_ct(self):
        issues = lint_missing_content_type(_contract(interactions=[
            _i(method="POST", req_body={"name": "test"},
               req_headers={"Content-Type": "application/json"}),
        ]))
        assert not any(i.rule == "content-type-header" for i in issues)

    def test_no_body_ok(self):
        issues = lint_missing_content_type(_contract(interactions=[_i()]))
        assert len(issues) == 0


class TestResponseBody:
    def test_success_no_body(self):
        issues = lint_response_body(_contract(interactions=[
            _i(status=200, body=None),
        ]))
        assert any(i.rule == "response-body-expected" for i in issues)

    def test_204_no_body_ok(self):
        issues = lint_response_body(_contract(interactions=[
            _i(status=204, body=None),
        ]))
        assert not any(i.rule == "response-body-expected" for i in issues)

    def test_success_with_body_ok(self):
        issues = lint_response_body(_contract(interactions=[
            _i(status=200, body={"id": 1}),
        ]))
        assert not any(i.rule == "response-body-expected" for i in issues)


class TestLintContract:
    def test_all_rules(self):
        c = _contract(
            consumer="BadName",
            provider="backend",
            interactions=[
                _i(method="POST", path="/Users/", status=200,
                   req_body={"name": "test"}),
            ],
        )
        result = lint_contract(c)
        assert len(result.issues) > 0
        rules_found = {i.rule for i in result.issues}
        assert "naming-convention" in rules_found

    def test_clean_contract(self):
        c = _contract(
            consumer="frontend",
            provider="user-api",
            interactions=[
                _i(path="/users", body=[{"id": 1}]),
                _i(desc="create", method="POST", path="/users", status=201,
                   body={"id": 1}, req_body={"name": "x"},
                   req_headers={"Content-Type": "application/json"}),
            ],
        )
        result = lint_contract(c)
        assert result.passed

    def test_custom_rules(self):
        c = _contract()
        result = lint_contract(c, rules=[lint_naming_conventions])
        # Only naming rules should run
        for issue in result.issues:
            assert issue.rule == "naming-convention"

    def test_result_counts(self):
        result = lint_contract(_contract(consumer="BadName"))
        assert result.warning_count >= 1
