"""Tests for contract statistics."""

import pytest

from pactship.models import (
    Contract, HttpMethod, Interaction, Matcher, MatcherType,
    RequestSpec, ResponseSpec,
)
from pactship.stats import analyze_contract, analyze_contracts


def _i(desc, method="GET", path="/test", status=200, body=None, req_body=None,
       tags=None, states=None, matchers=None):
    return Interaction(
        description=desc,
        request=RequestSpec(method=HttpMethod(method), path=path, body=req_body),
        response=ResponseSpec(status=status, body=body, body_matchers=matchers or {}),
        tags=tags or [],
        provider_states=states or [],
    )


class TestAnalyzeContract:
    def test_basic(self):
        c = Contract(consumer="a", provider="b", interactions=[_i("test")])
        stats = analyze_contract(c)
        assert stats.total_interactions == 1
        assert stats.consumer == "a"
        assert stats.provider == "b"

    def test_methods(self):
        c = Contract(consumer="a", provider="b", interactions=[
            _i("get", "GET", "/a"),
            _i("post1", "POST", "/b"),
            _i("post2", "POST", "/c"),
        ])
        stats = analyze_contract(c)
        assert stats.methods["GET"] == 1
        assert stats.methods["POST"] == 2

    def test_status_codes(self):
        c = Contract(consumer="a", provider="b", interactions=[
            _i("ok", status=200),
            _i("created", "POST", "/new", status=201),
            _i("not found", path="/missing", status=404),
        ])
        stats = analyze_contract(c)
        assert stats.status_codes[200] == 1
        assert stats.status_codes[201] == 1
        assert stats.status_codes[404] == 1

    def test_unique_paths(self):
        c = Contract(consumer="a", provider="b", interactions=[
            _i("a", path="/users"),
            _i("b", "POST", "/users"),
            _i("c", path="/items"),
        ])
        stats = analyze_contract(c)
        assert stats.unique_paths == 2
        assert "/users" in stats.paths

    def test_tags(self):
        c = Contract(consumer="a", provider="b", interactions=[
            _i("a", tags=["v2", "public"]),
            _i("b", path="/b", tags=["v2"]),
        ])
        stats = analyze_contract(c)
        assert stats.tags["v2"] == 2
        assert stats.tags["public"] == 1

    def test_body_counts(self):
        c = Contract(consumer="a", provider="b", interactions=[
            _i("a", body={"id": 1}),
            _i("b", path="/b", req_body={"name": "x"}),
            _i("c", path="/c"),
        ])
        stats = analyze_contract(c)
        assert stats.has_body_response == 1
        assert stats.has_body_request == 1

    def test_matchers(self):
        c = Contract(consumer="a", provider="b", interactions=[
            _i("a", matchers={"body.id": Matcher(type=MatcherType.INTEGER)}),
            _i("b", path="/b"),
        ])
        stats = analyze_contract(c)
        assert stats.has_matchers == 1

    def test_provider_states(self):
        c = Contract(consumer="a", provider="b", interactions=[
            _i("a", states=["user exists"]),
            _i("b", path="/b"),
        ])
        stats = analyze_contract(c)
        assert stats.has_provider_states == 1

    def test_avg_response_fields(self):
        c = Contract(consumer="a", provider="b", interactions=[
            _i("a", body={"id": 1, "name": "x"}),
            _i("b", path="/b", body={"id": 1, "name": "x", "email": "y", "age": 1}),
        ])
        stats = analyze_contract(c)
        assert stats.avg_response_fields == 3.0  # (2+4)/2

    def test_max_depth(self):
        c = Contract(consumer="a", provider="b", interactions=[
            _i("a", body={"user": {"address": {"city": "Seoul"}}}),
        ])
        stats = analyze_contract(c)
        assert stats.max_response_depth == 4

    def test_to_dict(self):
        c = Contract(consumer="a", provider="b", interactions=[_i("test")])
        stats = analyze_contract(c)
        d = stats.to_dict()
        assert d["consumer"] == "a"
        assert isinstance(d["total_interactions"], int)

    def test_empty_contract(self):
        c = Contract(consumer="a", provider="b")
        stats = analyze_contract(c)
        assert stats.total_interactions == 0
        assert stats.avg_response_fields == 0.0


class TestAnalyzeContracts:
    def test_aggregate(self):
        contracts = [
            Contract(consumer="a", provider="b", interactions=[_i("test1")]),
            Contract(consumer="c", provider="b", interactions=[
                _i("test2"), _i("test3", "POST", "/x"),
            ]),
        ]
        result = analyze_contracts(contracts)
        assert result["total_contracts"] == 2
        assert result["total_interactions"] == 3
        assert result["unique_consumers"] == 2
        assert result["unique_providers"] == 1
        assert "a" in result["consumers"]
        assert "b" in result["providers"]

    def test_empty(self):
        result = analyze_contracts([])
        assert result["total_contracts"] == 0
        assert result["total_interactions"] == 0
