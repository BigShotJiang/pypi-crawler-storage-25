"""Tests for reporting module."""

import json
import xml.etree.ElementTree as ET

import pytest

from pactship.models import (
    Contract,
    ContractVerificationReport,
    HttpMethod,
    Interaction,
    RequestSpec,
    ResponseSpec,
    VerificationResult,
)
from pactship.reporting import to_json, to_junit_xml, to_markdown, to_tap


@pytest.fixture
def interaction():
    return Interaction(
        description="Get user",
        request=RequestSpec(method=HttpMethod.GET, path="/users/1"),
        response=ResponseSpec(status=200),
    )


@pytest.fixture
def passing_report(interaction):
    return ContractVerificationReport(
        contract=Contract(consumer="frontend", provider="backend"),
        results=[
            VerificationResult(interaction=interaction, success=True, duration_ms=10.5)
        ],
        success=True,
        total_duration_ms=10.5,
    )


@pytest.fixture
def failing_report(interaction):
    return ContractVerificationReport(
        contract=Contract(consumer="mobile", provider="api"),
        results=[
            VerificationResult(
                interaction=interaction,
                success=False,
                errors=["Status mismatch: expected 200, got 500"],
                duration_ms=5.0,
            )
        ],
        success=False,
        total_duration_ms=5.0,
    )


class TestToJson:
    def test_valid_json(self, passing_report):
        result = to_json(passing_report)
        data = json.loads(result)
        assert data["success"] is True
        assert data["consumer"] == "frontend"

    def test_failing_report(self, failing_report):
        result = to_json(failing_report)
        data = json.loads(result)
        assert data["success"] is False

    def test_custom_indent(self, passing_report):
        result = to_json(passing_report, indent=4)
        assert "    " in result


class TestToJunitXml:
    def test_valid_xml(self, passing_report):
        xml_str = to_junit_xml([passing_report])
        root = ET.fromstring(xml_str)
        assert root.tag == "testsuites"
        assert root.get("tests") == "1"
        assert root.get("failures") == "0"

    def test_testsuite_name(self, passing_report):
        xml_str = to_junit_xml([passing_report])
        root = ET.fromstring(xml_str)
        suite = root.find("testsuite")
        assert "frontend" in suite.get("name")
        assert "backend" in suite.get("name")

    def test_testcase(self, passing_report):
        xml_str = to_junit_xml([passing_report])
        root = ET.fromstring(xml_str)
        testcase = root.find(".//testcase")
        assert testcase.get("name") == "Get user"

    def test_failure_element(self, failing_report):
        xml_str = to_junit_xml([failing_report])
        root = ET.fromstring(xml_str)
        failure = root.find(".//failure")
        assert failure is not None
        assert "Status mismatch" in failure.get("message")

    def test_multiple_reports(self, passing_report, failing_report):
        xml_str = to_junit_xml([passing_report, failing_report])
        root = ET.fromstring(xml_str)
        assert root.get("tests") == "2"
        assert root.get("failures") == "1"
        suites = root.findall("testsuite")
        assert len(suites) == 2

    def test_custom_suite_name(self, passing_report):
        xml_str = to_junit_xml([passing_report], suite_name="my-tests")
        root = ET.fromstring(xml_str)
        assert root.get("name") == "my-tests"

    def test_empty_reports(self):
        xml_str = to_junit_xml([])
        root = ET.fromstring(xml_str)
        assert root.get("tests") == "0"

    def test_duration(self, passing_report):
        xml_str = to_junit_xml([passing_report])
        root = ET.fromstring(xml_str)
        testcase = root.find(".//testcase")
        assert float(testcase.get("time")) > 0


class TestToMarkdown:
    def test_contains_header(self, passing_report):
        md = to_markdown([passing_report])
        assert "# Contract Verification Report" in md

    def test_summary(self, passing_report):
        md = to_markdown([passing_report])
        assert "PASSED" in md
        assert "Total interactions: 1" in md

    def test_table(self, passing_report):
        md = to_markdown([passing_report])
        assert "| Get user" in md
        assert "PASS" in md

    def test_errors_shown(self, failing_report):
        md = to_markdown([failing_report])
        assert "Status mismatch" in md
        assert "FAIL" in md

    def test_multiple_reports(self, passing_report, failing_report):
        md = to_markdown([passing_report, failing_report])
        assert "frontend" in md
        assert "mobile" in md
        assert "Total interactions: 2" in md

    def test_empty_reports(self):
        md = to_markdown([])
        assert "Total interactions: 0" in md


class TestToTap:
    def test_tap_header(self, passing_report):
        tap = to_tap([passing_report])
        assert tap.startswith("TAP version 13")
        assert "1..1" in tap

    def test_passing(self, passing_report):
        tap = to_tap([passing_report])
        assert "ok 1 -" in tap

    def test_failing(self, failing_report):
        tap = to_tap([failing_report])
        assert "not ok 1 -" in tap
        assert "Status mismatch" in tap

    def test_multiple(self, passing_report, failing_report):
        tap = to_tap([passing_report, failing_report])
        assert "1..2" in tap
        assert "ok 1" in tap
        assert "not ok 2" in tap

    def test_empty(self):
        tap = to_tap([])
        assert "1..0" in tap
