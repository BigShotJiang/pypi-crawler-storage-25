"""Tests for service dependency graph."""

import pytest

from pactship.graph import ServiceGraph
from pactship.models import Contract, HttpMethod, Interaction, RequestSpec, ResponseSpec


def _contract(consumer, provider, paths=None):
    interactions = []
    for path in (paths or ["/test"]):
        interactions.append(Interaction(
            description=f"{consumer} -> {provider} {path}",
            request=RequestSpec(method=HttpMethod.GET, path=path),
            response=ResponseSpec(status=200),
        ))
    return Contract(consumer=consumer, provider=provider, interactions=interactions)


class TestServiceGraph:
    def test_add_contract(self):
        g = ServiceGraph()
        g.add_contract(_contract("frontend", "api"))
        assert len(g.nodes) == 2
        assert len(g.edges) == 1

    def test_node_properties(self):
        g = ServiceGraph()
        g.add_contract(_contract("frontend", "api"))
        frontend = g.get_node("frontend")
        assert frontend.is_consumer
        assert not frontend.is_provider
        api = g.get_node("api")
        assert api.is_provider
        assert not api.is_consumer

    def test_get_providers(self):
        g = ServiceGraph()
        g.add_contract(_contract("frontend", "api"))
        g.add_contract(_contract("frontend", "auth"))
        assert g.get_providers("frontend") == ["api", "auth"]

    def test_get_consumers(self):
        g = ServiceGraph()
        g.add_contract(_contract("frontend", "api"))
        g.add_contract(_contract("mobile", "api"))
        assert g.get_consumers("api") == ["frontend", "mobile"]

    def test_get_edge(self):
        g = ServiceGraph()
        g.add_contract(_contract("a", "b", ["/x", "/y"]))
        edge = g.get_edge("a", "b")
        assert edge is not None
        assert edge.interaction_count == 2
        assert "/x" in edge.paths

    def test_no_edge(self):
        g = ServiceGraph()
        assert g.get_edge("a", "b") is None

    def test_leaf_services(self):
        g = ServiceGraph()
        g.add_contract(_contract("frontend", "api"))
        g.add_contract(_contract("api", "db"))
        assert g.leaf_services() == ["db"]

    def test_root_services(self):
        g = ServiceGraph()
        g.add_contract(_contract("frontend", "api"))
        g.add_contract(_contract("api", "db"))
        assert g.root_services() == ["frontend"]

    def test_find_cycles_none(self):
        g = ServiceGraph()
        g.add_contract(_contract("a", "b"))
        g.add_contract(_contract("b", "c"))
        assert g.find_cycles() == []

    def test_find_cycles_simple(self):
        g = ServiceGraph()
        g.add_contract(_contract("a", "b"))
        g.add_contract(_contract("b", "a"))
        cycles = g.find_cycles()
        assert len(cycles) >= 1

    def test_mermaid(self):
        g = ServiceGraph()
        g.add_contract(_contract("frontend", "api"))
        mermaid = g.to_mermaid()
        assert "graph LR" in mermaid
        assert "frontend" in mermaid
        assert "api" in mermaid

    def test_to_dict(self):
        g = ServiceGraph()
        g.add_contract(_contract("a", "b"))
        d = g.to_dict()
        assert len(d["nodes"]) == 2
        assert len(d["edges"]) == 1

    def test_add_contracts(self):
        g = ServiceGraph()
        g.add_contracts([
            _contract("a", "b"),
            _contract("c", "b"),
        ])
        assert len(g.nodes) == 3
        assert len(g.edges) == 2

    def test_unknown_node(self):
        g = ServiceGraph()
        assert g.get_node("x") is None
        assert g.get_providers("x") == []
        assert g.get_consumers("x") == []

    def test_interaction_count(self):
        g = ServiceGraph()
        g.add_contract(_contract("a", "b", ["/x", "/y", "/z"]))
        node = g.get_node("a")
        assert node.interaction_count == 3
