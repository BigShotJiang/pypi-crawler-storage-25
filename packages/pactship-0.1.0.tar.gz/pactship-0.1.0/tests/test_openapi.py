"""Tests for OpenAPI to contract conversion."""

import pytest

from pactship.models import HttpMethod
from pactship.openapi import from_openapi


@pytest.fixture
def simple_spec():
    return {
        "openapi": "3.0.0",
        "info": {"title": "User API", "version": "1.0.0"},
        "paths": {
            "/users": {
                "get": {
                    "summary": "List users",
                    "responses": {
                        "200": {
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "array",
                                        "items": {
                                            "type": "object",
                                            "properties": {
                                                "id": {"type": "integer"},
                                                "name": {"type": "string"},
                                            },
                                        },
                                    }
                                }
                            }
                        }
                    },
                },
                "post": {
                    "summary": "Create user",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "name": {"type": "string"},
                                        "email": {"type": "string", "format": "email"},
                                    },
                                }
                            }
                        }
                    },
                    "responses": {
                        "201": {
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "id": {"type": "integer"},
                                            "name": {"type": "string"},
                                        },
                                    }
                                }
                            }
                        }
                    },
                },
            },
            "/users/{id}": {
                "get": {
                    "summary": "Get user by ID",
                    "parameters": [
                        {"name": "Authorization", "in": "header", "example": "Bearer token"}
                    ],
                    "responses": {
                        "200": {
                            "content": {
                                "application/json": {
                                    "schema": {
                                        "type": "object",
                                        "properties": {
                                            "id": {"type": "integer"},
                                            "name": {"type": "string"},
                                        },
                                    }
                                }
                            }
                        }
                    },
                },
                "delete": {
                    "summary": "Delete user",
                    "responses": {"204": {}},
                },
            },
        },
    }


class TestFromOpenAPI:
    def test_basic(self, simple_spec):
        contract = from_openapi(simple_spec, "frontend")
        assert contract.consumer == "frontend"
        assert contract.provider == "User API"
        assert len(contract.interactions) == 4

    def test_custom_provider(self, simple_spec):
        contract = from_openapi(simple_spec, "frontend", provider="user-svc")
        assert contract.provider == "user-svc"

    def test_methods(self, simple_spec):
        contract = from_openapi(simple_spec, "a")
        methods = [i.request.method for i in contract.interactions]
        assert HttpMethod.GET in methods
        assert HttpMethod.POST in methods
        assert HttpMethod.DELETE in methods

    def test_paths(self, simple_spec):
        contract = from_openapi(simple_spec, "a")
        paths = [i.request.path for i in contract.interactions]
        assert "/users" in paths
        assert "/users/{id}" in paths

    def test_descriptions(self, simple_spec):
        contract = from_openapi(simple_spec, "a")
        descriptions = [i.description for i in contract.interactions]
        assert "List users" in descriptions
        assert "Create user" in descriptions

    def test_response_body(self, simple_spec):
        contract = from_openapi(simple_spec, "a")
        list_int = next(i for i in contract.interactions if i.description == "List users")
        assert isinstance(list_int.response.body, list)
        assert "id" in list_int.response.body[0]

    def test_request_body(self, simple_spec):
        contract = from_openapi(simple_spec, "a")
        create_int = next(i for i in contract.interactions if i.description == "Create user")
        assert create_int.request.body is not None
        assert "name" in create_int.request.body
        assert create_int.request.body["email"] == "user@example.com"

    def test_status_codes(self, simple_spec):
        contract = from_openapi(simple_spec, "a")
        delete_int = next(i for i in contract.interactions if i.description == "Delete user")
        assert delete_int.response.status == 204

    def test_request_headers(self, simple_spec):
        contract = from_openapi(simple_spec, "a")
        create_int = next(i for i in contract.interactions if i.description == "Create user")
        header_names = [h.name for h in create_int.request.headers]
        assert "Content-Type" in header_names

    def test_parameter_headers(self, simple_spec):
        contract = from_openapi(simple_spec, "a")
        get_int = next(i for i in contract.interactions if i.description == "Get user by ID")
        header_names = [h.name for h in get_int.request.headers]
        assert "Authorization" in header_names

    def test_metadata(self, simple_spec):
        contract = from_openapi(simple_spec, "a")
        assert contract.metadata["source"] == "openapi"

    def test_empty_paths(self):
        spec = {"openapi": "3.0.0", "info": {"title": "Empty"}, "paths": {}}
        contract = from_openapi(spec, "a")
        assert len(contract.interactions) == 0

    def test_ref_resolution(self):
        spec = {
            "openapi": "3.0.0",
            "info": {"title": "Ref Test"},
            "paths": {
                "/items": {
                    "get": {
                        "summary": "List items",
                        "responses": {
                            "200": {
                                "content": {
                                    "application/json": {
                                        "schema": {"$ref": "#/components/schemas/Item"}
                                    }
                                }
                            }
                        },
                    }
                }
            },
            "components": {
                "schemas": {
                    "Item": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "integer"},
                            "title": {"type": "string"},
                        },
                    }
                }
            },
        }
        contract = from_openapi(spec, "a")
        body = contract.interactions[0].response.body
        assert "id" in body
        assert "title" in body

    def test_string_formats(self):
        spec = {
            "openapi": "3.0.0",
            "info": {"title": "Formats"},
            "paths": {
                "/test": {
                    "get": {
                        "summary": "Test formats",
                        "responses": {
                            "200": {
                                "content": {
                                    "application/json": {
                                        "schema": {
                                            "type": "object",
                                            "properties": {
                                                "uuid": {"type": "string", "format": "uuid"},
                                                "date": {"type": "string", "format": "date"},
                                                "dt": {"type": "string", "format": "date-time"},
                                                "uri": {"type": "string", "format": "uri"},
                                            },
                                        }
                                    }
                                }
                            }
                        },
                    }
                }
            },
        }
        contract = from_openapi(spec, "a")
        body = contract.interactions[0].response.body
        assert "550e8400" in body["uuid"]
        assert body["date"] == "2024-01-15"
        assert "T" in body["dt"]

    def test_default_provider_name(self):
        spec = {"openapi": "3.0.0", "info": {}, "paths": {}}
        contract = from_openapi(spec, "a")
        assert contract.provider == "api"

    def test_operation_id_fallback(self):
        spec = {
            "openapi": "3.0.0",
            "info": {"title": "t"},
            "paths": {
                "/x": {
                    "get": {
                        "operationId": "getX",
                        "responses": {"200": {}},
                    }
                }
            },
        }
        contract = from_openapi(spec, "a")
        assert contract.interactions[0].description == "getX"
