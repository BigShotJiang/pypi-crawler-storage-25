"""Integration tests — full workflow scenarios."""

import json
import tempfile
from pathlib import Path

import pytest

from pactship import (
    Contract,
    ContractBroker,
    ContractBuilder,
    InteractionBuilder,
    MockProvider,
    ServiceGraph,
    diff_contracts,
    exact,
    generate_crud_contract,
    integer_match,
    like,
    lint_contract,
    load_contract,
    save_contract,
    validate_contract,
)
from pactship.contract_io import merge_contracts
from pactship.filters import filter_interactions
from pactship.reporting import to_json, to_junit_xml, to_markdown
from pactship.schema import contract_to_schemas
from pactship.stats import analyze_contract
from pactship.transform import prefix_paths, strip_fields


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


class TestFullWorkflow:
    """Test a complete workflow: define -> save -> load -> validate -> diff."""

    def test_define_save_load_validate(self, temp_dir):
        # Define contract using DSL
        i1 = (
            InteractionBuilder("Get user")
            .given("user 1 exists")
            .with_request("GET", "/users/1")
            .will_respond_with(200)
            .with_response_body({"id": 1, "name": "Alice", "email": "a@b.com"})
            .with_tag("v2")
            .build()
        )
        contract = (
            ContractBuilder("web-frontend", "user-api")
            .add_interaction(i1)
            .with_metadata("version", "1.0")
            .build()
        )

        # Save
        path = temp_dir / "contract.yaml"
        save_contract(contract, path)
        assert path.exists()

        # Load
        loaded = load_contract(path)
        assert loaded.consumer == "web-frontend"
        assert loaded.interactions[0].provider_states == ["user 1 exists"]

        # Validate
        result = validate_contract(loaded)
        assert result.valid

        # Lint
        lint_result = lint_contract(loaded)
        assert lint_result.passed

    def test_diff_workflow(self, temp_dir):
        old = generate_crud_contract("a", "b", "user", "/users", {"name": "x"})
        new = generate_crud_contract("a", "b", "user", "/users", {"name": "x", "email": "y"})

        result = diff_contracts(old, new)
        # Adding a field to response body is non-breaking
        assert not result.has_breaking_changes or len(result.non_breaking_changes) > 0

    def test_broker_workflow(self, temp_dir):
        broker = ContractBroker(temp_dir / "broker")

        c1 = generate_crud_contract("web", "user-api", "user", "/users", {"name": "x"})
        c2 = generate_crud_contract("mobile", "user-api", "user", "/users", {"name": "x"})

        broker.publish(c1)
        broker.publish(c2)

        # List all contracts for the provider
        contracts = broker.list_contracts_for_provider("user-api")
        assert len(contracts) == 2

        # Check versions
        pairs = broker.list_pairs()
        assert len(pairs) == 2

    def test_graph_workflow(self):
        contracts = [
            generate_crud_contract("web", "user-api", "user", "/users", {"name": "x"}),
            generate_crud_contract("web", "order-api", "order", "/orders", {"total": 0}),
            generate_crud_contract("mobile", "user-api", "user", "/users", {"name": "x"}),
        ]

        graph = ServiceGraph()
        graph.add_contracts(contracts)

        assert len(graph.nodes) == 4
        assert graph.get_providers("web") == ["order-api", "user-api"]
        assert graph.get_consumers("user-api") == ["mobile", "web"]
        assert "web" in graph.root_services()

    def test_transform_and_stats(self):
        contract = generate_crud_contract(
            "frontend", "api", "item", "/items",
            {"name": "Widget", "price": 9.99, "secret_key": "abc"},
        )

        # Transform
        versioned = prefix_paths(contract, "/v2")
        stripped = strip_fields(versioned, ["secret_key"])

        # Stats
        stats = analyze_contract(stripped)
        assert stats.total_interactions == 5
        assert stats.unique_paths >= 2

    def test_schema_generation(self):
        contract = generate_crud_contract(
            "frontend", "api", "user", "/users",
            {"name": "Alice", "age": 25},
        )
        schemas = contract_to_schemas(contract)
        assert len(schemas) == 5

    def test_merge_and_filter(self):
        c1 = Contract(
            consumer="web", provider="api",
            interactions=[
                InteractionBuilder("Get users")
                .with_request("GET", "/users")
                .will_respond_with(200)
                .with_tag("read")
                .build(),
            ],
        )
        c2 = Contract(
            consumer="web", provider="api",
            interactions=[
                InteractionBuilder("Create user")
                .with_request("POST", "/users")
                .will_respond_with(201)
                .with_tag("write")
                .build(),
            ],
        )

        merged = merge_contracts([c1, c2])
        assert len(merged) == 1
        assert len(merged[0].interactions) == 2

        # Filter
        reads = filter_interactions(merged[0], tag="read")
        assert len(reads) == 1

    def test_mock_provider(self):
        contract = generate_crud_contract(
            "frontend", "api", "user", "/users", {"name": "Alice"},
        )
        mock = MockProvider()
        mock.add_interactions_from_contract(contract)

        # Get mock response
        result = mock.get_mock_response("GET", "/users")
        assert result is not None
        status, headers, body = result
        assert status == 200

    def test_json_roundtrip(self, temp_dir):
        contract = generate_crud_contract(
            "a", "b", "item", "/items", {"name": "Widget"},
        )
        json_path = temp_dir / "contract.json"
        save_contract(contract, json_path, fmt="json")
        loaded = load_contract(json_path)
        assert loaded.consumer == "a"
        assert len(loaded.interactions) == 5

    def test_reporting_formats(self):
        from pactship.models import ContractVerificationReport, VerificationResult

        contract = Contract(consumer="a", provider="b")
        interaction = InteractionBuilder("test").with_request("GET", "/").will_respond_with(200).build()
        report = ContractVerificationReport(
            contract=contract,
            results=[VerificationResult(interaction=interaction, success=True, duration_ms=5.0)],
            success=True,
            total_duration_ms=5.0,
        )

        json_out = to_json(report)
        assert json.loads(json_out)["success"] is True

        junit = to_junit_xml([report])
        assert "testsuites" in junit

        md = to_markdown([report])
        assert "PASSED" in md
