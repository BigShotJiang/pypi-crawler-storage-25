"""Configuration management for pactship."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class PactshipConfig:
    """Configuration for pactship."""

    broker_dir: str = ".pactship"
    contracts_dir: str = "contracts"
    timeout: float = 30.0
    default_headers: dict[str, str] = field(default_factory=dict)
    provider_base_urls: dict[str, str] = field(default_factory=dict)
    setup_urls: dict[str, str] = field(default_factory=dict)
    report_format: str = "text"  # text, json, junit, markdown, tap
    fail_on_warning: bool = False
    strict_mode: bool = False
    tags_filter: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "broker_dir": self.broker_dir,
            "contracts_dir": self.contracts_dir,
            "timeout": self.timeout,
            "default_headers": self.default_headers,
            "provider_base_urls": self.provider_base_urls,
            "setup_urls": self.setup_urls,
            "report_format": self.report_format,
            "fail_on_warning": self.fail_on_warning,
            "strict_mode": self.strict_mode,
            "tags_filter": self.tags_filter,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PactshipConfig:
        return cls(
            broker_dir=data.get("broker_dir", ".pactship"),
            contracts_dir=data.get("contracts_dir", "contracts"),
            timeout=data.get("timeout", 30.0),
            default_headers=data.get("default_headers", {}),
            provider_base_urls=data.get("provider_base_urls", {}),
            setup_urls=data.get("setup_urls", {}),
            report_format=data.get("report_format", "text"),
            fail_on_warning=data.get("fail_on_warning", False),
            strict_mode=data.get("strict_mode", False),
            tags_filter=data.get("tags_filter", []),
        )


def load_config(
    config_path: str | Path | None = None,
    env_prefix: str = "PACTSHIP_",
) -> PactshipConfig:
    """Load configuration from file and environment variables.

    Priority: env vars > config file > defaults
    """
    config = PactshipConfig()

    # Load from file
    if config_path is None:
        for candidate in [".pactship.yaml", ".pactship.yml", ".pactship.json", "pactship.yaml"]:
            if Path(candidate).exists():
                config_path = candidate
                break

    if config_path is not None:
        path = Path(config_path)
        if path.exists():
            config = _load_from_file(path)

    # Override from environment
    config = _apply_env_overrides(config, env_prefix)

    return config


def save_config(config: PactshipConfig, path: str | Path) -> None:
    """Save configuration to a file."""
    path = Path(path)
    data = config.to_dict()

    if path.suffix == ".json":
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    else:
        path.write_text(yaml.dump(data, default_flow_style=False), encoding="utf-8")


def _load_from_file(path: Path) -> PactshipConfig:
    """Load config from a YAML or JSON file."""
    content = path.read_text(encoding="utf-8")

    if path.suffix == ".json":
        data = json.loads(content)
    else:
        data = yaml.safe_load(content)

    if not isinstance(data, dict):
        return PactshipConfig()

    return PactshipConfig.from_dict(data)


def _apply_env_overrides(
    config: PactshipConfig, prefix: str
) -> PactshipConfig:
    """Apply environment variable overrides."""
    env_map = {
        f"{prefix}BROKER_DIR": "broker_dir",
        f"{prefix}CONTRACTS_DIR": "contracts_dir",
        f"{prefix}TIMEOUT": "timeout",
        f"{prefix}REPORT_FORMAT": "report_format",
        f"{prefix}FAIL_ON_WARNING": "fail_on_warning",
        f"{prefix}STRICT_MODE": "strict_mode",
    }

    for env_key, attr in env_map.items():
        value = os.environ.get(env_key)
        if value is not None:
            if attr == "timeout":
                setattr(config, attr, float(value))
            elif attr in ("fail_on_warning", "strict_mode"):
                setattr(config, attr, value.lower() in ("true", "1", "yes"))
            else:
                setattr(config, attr, value)

    # Headers from env: PACTSHIP_HEADER_AUTHORIZATION=Bearer token
    header_prefix = f"{prefix}HEADER_"
    for key, value in os.environ.items():
        if key.startswith(header_prefix):
            header_name = key[len(header_prefix):].replace("_", "-")
            config.default_headers[header_name] = value

    return config
