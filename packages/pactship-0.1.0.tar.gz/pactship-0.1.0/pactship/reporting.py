"""Reporting module — generate verification reports in multiple formats."""

from __future__ import annotations

import json
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from typing import Any

from pactship.models import ContractVerificationReport, VerificationResult


def to_json(report: ContractVerificationReport, indent: int = 2) -> str:
    """Generate a JSON report."""
    return json.dumps(report.to_dict(), indent=indent)


def to_junit_xml(
    reports: list[ContractVerificationReport],
    suite_name: str = "pactship",
) -> str:
    """Generate JUnit XML report for CI integration."""
    testsuites = ET.Element("testsuites")
    testsuites.set("name", suite_name)

    total_tests = 0
    total_failures = 0
    total_time = 0.0

    for report in reports:
        suite = ET.SubElement(testsuites, "testsuite")
        suite_label = f"{report.contract.consumer} -> {report.contract.provider}"
        suite.set("name", suite_label)
        suite.set("tests", str(report.total))
        suite.set("failures", str(report.failed))
        suite.set("time", f"{report.total_duration_ms / 1000:.3f}")
        suite.set("timestamp", datetime.now(timezone.utc).isoformat())

        total_tests += report.total
        total_failures += report.failed
        total_time += report.total_duration_ms

        for result in report.results:
            testcase = ET.SubElement(suite, "testcase")
            testcase.set("name", result.interaction.description)
            testcase.set("classname", suite_label)
            testcase.set("time", f"{result.duration_ms / 1000:.3f}")

            if not result.success:
                for error in result.errors:
                    failure = ET.SubElement(testcase, "failure")
                    failure.set("message", error)
                    failure.text = error

            for warning in result.warnings:
                system_out = ET.SubElement(testcase, "system-out")
                system_out.text = f"WARNING: {warning}"

    testsuites.set("tests", str(total_tests))
    testsuites.set("failures", str(total_failures))
    testsuites.set("time", f"{total_time / 1000:.3f}")

    return ET.tostring(testsuites, encoding="unicode", xml_declaration=True)


def to_markdown(
    reports: list[ContractVerificationReport],
) -> str:
    """Generate a Markdown verification report."""
    lines: list[str] = []
    lines.append("# Contract Verification Report")
    lines.append("")
    lines.append(f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    lines.append("")

    total_passed = sum(r.passed for r in reports)
    total_failed = sum(r.failed for r in reports)
    total = total_passed + total_failed
    overall = "PASSED" if all(r.success for r in reports) else "FAILED"

    lines.append(f"## Summary: {overall}")
    lines.append("")
    lines.append(f"- Total interactions: {total}")
    lines.append(f"- Passed: {total_passed}")
    lines.append(f"- Failed: {total_failed}")
    lines.append("")

    for report in reports:
        status = "PASS" if report.success else "FAIL"
        lines.append(
            f"### {status}: {report.contract.consumer} -> {report.contract.provider}"
        )
        lines.append("")

        lines.append("| Interaction | Status | Duration |")
        lines.append("|---|---|---|")

        for result in report.results:
            icon = "PASS" if result.success else "FAIL"
            lines.append(
                f"| {result.interaction.description} "
                f"| {icon} | {result.duration_ms:.1f}ms |"
            )

        lines.append("")

        # Show errors
        failed_results = [r for r in report.results if not r.success]
        if failed_results:
            lines.append("**Errors:**")
            lines.append("")
            for result in failed_results:
                lines.append(f"- **{result.interaction.description}**")
                for error in result.errors:
                    lines.append(f"  - {error}")
            lines.append("")

    return "\n".join(lines)


def to_tap(reports: list[ContractVerificationReport]) -> str:
    """Generate TAP (Test Anything Protocol) report."""
    lines: list[str] = []
    test_num = 0
    total = sum(r.total for r in reports)

    lines.append(f"TAP version 13")
    lines.append(f"1..{total}")

    for report in reports:
        prefix = f"{report.contract.consumer} -> {report.contract.provider}"
        for result in report.results:
            test_num += 1
            status = "ok" if result.success else "not ok"
            lines.append(f"{status} {test_num} - {prefix}: {result.interaction.description}")

            if not result.success:
                lines.append("  ---")
                for error in result.errors:
                    lines.append(f"  message: {error}")
                lines.append("  ...")

    return "\n".join(lines)
