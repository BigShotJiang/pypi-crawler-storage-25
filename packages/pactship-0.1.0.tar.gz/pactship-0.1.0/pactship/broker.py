"""Local contract broker — stores and retrieves contracts from local filesystem."""

from __future__ import annotations

import json
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pactship.contract_io import load_contract, save_contract
from pactship.models import Contract


class ContractBroker:
    """Local filesystem-based contract broker.

    Directory structure:
      broker_dir/
        contracts/
          {consumer}-{provider}/
            latest.yaml
            versions/
              {timestamp}.yaml
        verifications/
          {consumer}-{provider}/
            {timestamp}.json
    """

    def __init__(self, broker_dir: str | Path) -> None:
        self.broker_dir = Path(broker_dir)
        self.contracts_dir = self.broker_dir / "contracts"
        self.verifications_dir = self.broker_dir / "verifications"
        self._ensure_dirs()

    def _ensure_dirs(self) -> None:
        self.contracts_dir.mkdir(parents=True, exist_ok=True)
        self.verifications_dir.mkdir(parents=True, exist_ok=True)

    def _pair_dir(self, consumer: str, provider: str) -> Path:
        return self.contracts_dir / f"{consumer}-{provider}"

    def _verification_dir(self, consumer: str, provider: str) -> Path:
        return self.verifications_dir / f"{consumer}-{provider}"

    def publish(self, contract: Contract) -> Path:
        """Publish a contract to the broker."""
        pair_dir = self._pair_dir(contract.consumer, contract.provider)
        versions_dir = pair_dir / "versions"
        versions_dir.mkdir(parents=True, exist_ok=True)

        # Save versioned copy (with uuid suffix to avoid timestamp collisions)
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        suffix = uuid.uuid4().hex[:8]
        version_path = versions_dir / f"{timestamp}_{suffix}.yaml"
        save_contract(contract, version_path)

        # Save as latest
        latest_path = pair_dir / "latest.yaml"
        save_contract(contract, latest_path)

        return latest_path

    def get_latest(self, consumer: str, provider: str) -> Contract | None:
        """Get the latest contract for a consumer-provider pair."""
        latest_path = self._pair_dir(consumer, provider) / "latest.yaml"
        if not latest_path.exists():
            return None
        return load_contract(latest_path)

    def get_version(
        self, consumer: str, provider: str, version: str
    ) -> Contract | None:
        """Get a specific version of a contract."""
        version_path = (
            self._pair_dir(consumer, provider) / "versions" / f"{version}.yaml"
        )
        if not version_path.exists():
            return None
        return load_contract(version_path)

    def list_versions(self, consumer: str, provider: str) -> list[str]:
        """List all versions of a contract."""
        versions_dir = self._pair_dir(consumer, provider) / "versions"
        if not versions_dir.exists():
            return []
        return sorted(
            [p.stem for p in versions_dir.glob("*.yaml")],
            reverse=True,
        )

    def list_pairs(self) -> list[tuple[str, str]]:
        """List all consumer-provider pairs."""
        pairs: list[tuple[str, str]] = []
        if not self.contracts_dir.exists():
            return pairs
        for path in sorted(self.contracts_dir.iterdir()):
            if path.is_dir() and "-" in path.name:
                parts = path.name.split("-", 1)
                if len(parts) == 2:
                    pairs.append((parts[0], parts[1]))
        return pairs

    def list_contracts_for_provider(self, provider: str) -> list[Contract]:
        """List all contracts where this service is the provider."""
        contracts: list[Contract] = []
        for consumer, prov in self.list_pairs():
            if prov == provider:
                contract = self.get_latest(consumer, prov)
                if contract:
                    contracts.append(contract)
        return contracts

    def list_contracts_for_consumer(self, consumer: str) -> list[Contract]:
        """List all contracts where this service is the consumer."""
        contracts: list[Contract] = []
        for cons, provider in self.list_pairs():
            if cons == consumer:
                contract = self.get_latest(cons, provider)
                if contract:
                    contracts.append(contract)
        return contracts

    def save_verification(
        self,
        consumer: str,
        provider: str,
        report: dict[str, Any],
    ) -> Path:
        """Save a verification report."""
        ver_dir = self._verification_dir(consumer, provider)
        ver_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        suffix = uuid.uuid4().hex[:8]
        report_path = ver_dir / f"{timestamp}_{suffix}.json"
        report_path.write_text(
            json.dumps(report, indent=2), encoding="utf-8"
        )
        return report_path

    def get_verifications(
        self, consumer: str, provider: str, limit: int = 10
    ) -> list[dict[str, Any]]:
        """Get verification reports for a consumer-provider pair."""
        ver_dir = self._verification_dir(consumer, provider)
        if not ver_dir.exists():
            return []

        reports: list[dict[str, Any]] = []
        paths = sorted(ver_dir.glob("*.json"), reverse=True)[:limit]
        for path in paths:
            data = json.loads(path.read_text(encoding="utf-8"))
            data["_filename"] = path.stem
            reports.append(data)

        return reports

    def delete_pair(self, consumer: str, provider: str) -> bool:
        """Delete all contracts and verifications for a pair."""
        pair_dir = self._pair_dir(consumer, provider)
        ver_dir = self._verification_dir(consumer, provider)

        deleted = False
        if pair_dir.exists():
            shutil.rmtree(pair_dir)
            deleted = True
        if ver_dir.exists():
            shutil.rmtree(ver_dir)
            deleted = True

        return deleted

    def clear(self) -> None:
        """Clear all contracts and verifications."""
        if self.contracts_dir.exists():
            shutil.rmtree(self.contracts_dir)
        if self.verifications_dir.exists():
            shutil.rmtree(self.verifications_dir)
        self._ensure_dirs()
