"""Contract serialization and deserialization (YAML and JSON)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import yaml

from pactship.models import Contract


def load_contract(path: str | Path) -> Contract:
    """Load a contract from a YAML or JSON file."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Contract file not found: {path}")

    content = path.read_text(encoding="utf-8")

    if path.suffix in (".yml", ".yaml"):
        data = yaml.safe_load(content)
    elif path.suffix == ".json":
        data = json.loads(content)
    else:
        # Try YAML first, then JSON
        try:
            data = yaml.safe_load(content)
        except yaml.YAMLError:
            data = json.loads(content)

    if not isinstance(data, dict):
        raise ValueError(f"Invalid contract format in {path}")

    return Contract.from_dict(data)


def save_contract(contract: Contract, path: str | Path, fmt: str = "yaml") -> None:
    """Save a contract to a file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    data = contract.to_dict()

    if fmt == "json":
        content = json.dumps(data, indent=2, sort_keys=False)
    else:
        content = yaml.dump(data, default_flow_style=False, sort_keys=False)

    path.write_text(content, encoding="utf-8")


def load_contracts_from_dir(directory: str | Path) -> list[Contract]:
    """Load all contracts from a directory."""
    directory = Path(directory)
    if not directory.is_dir():
        raise NotADirectoryError(f"Not a directory: {directory}")

    contracts: list[Contract] = []
    for ext in ("*.yml", "*.yaml", "*.json"):
        for path in sorted(directory.glob(ext)):
            try:
                contracts.append(load_contract(path))
            except (ValueError, KeyError) as e:
                raise ValueError(f"Error loading {path}: {e}") from e

    return contracts


def contract_to_dict(contract: Contract) -> dict[str, Any]:
    """Convert contract to dictionary."""
    return contract.to_dict()


def contract_from_dict(data: dict[str, Any]) -> Contract:
    """Create contract from dictionary."""
    return Contract.from_dict(data)


def merge_contracts(contracts: list[Contract]) -> list[Contract]:
    """Merge contracts with same consumer-provider pairs."""
    merged: dict[tuple[str, str], Contract] = {}

    for contract in contracts:
        key = (contract.consumer, contract.provider)
        if key in merged:
            existing = merged[key]
            # Merge interactions avoiding duplicates by fingerprint
            existing_fps = {i.fingerprint for i in existing.interactions}
            for interaction in contract.interactions:
                if interaction.fingerprint not in existing_fps:
                    existing.interactions.append(interaction)
                    existing_fps.add(interaction.fingerprint)
        else:
            merged[key] = Contract(
                consumer=contract.consumer,
                provider=contract.provider,
                interactions=list(contract.interactions),
                version=contract.version,
                metadata={**contract.metadata},
            )

    return list(merged.values())
