"""OpenAPI/Swagger to contract conversion."""

from __future__ import annotations

from typing import Any

from pactship.models import (
    Contract,
    Header,
    HttpMethod,
    Interaction,
    RequestSpec,
    ResponseSpec,
)


OPENAPI_METHODS = {"get", "post", "put", "patch", "delete", "head", "options"}


def from_openapi(
    spec: dict[str, Any],
    consumer: str,
    provider: str | None = None,
) -> Contract:
    """Convert an OpenAPI 3.x spec to a pactship contract.

    Args:
        spec: Parsed OpenAPI spec dictionary
        consumer: Name of the consumer service
        provider: Name of the provider (defaults to spec title)
    """
    if provider is None:
        info = spec.get("info", {})
        provider = info.get("title", "api")

    interactions: list[Interaction] = []

    paths = spec.get("paths", {})
    for path, path_item in paths.items():
        if not isinstance(path_item, dict):
            continue

        for method_str in OPENAPI_METHODS:
            operation = path_item.get(method_str)
            if operation is None:
                continue

            interaction = _operation_to_interaction(
                path, method_str, operation, spec
            )
            if interaction:
                interactions.append(interaction)

    return Contract(
        consumer=consumer,
        provider=provider,
        interactions=interactions,
        metadata={"source": "openapi", "version": spec.get("openapi", "3.0.0")},
    )


def _operation_to_interaction(
    path: str,
    method: str,
    operation: dict[str, Any],
    spec: dict[str, Any],
) -> Interaction | None:
    """Convert a single OpenAPI operation to an interaction."""
    description = operation.get("summary") or operation.get("operationId") or f"{method.upper()} {path}"

    # Build request
    request_body = None
    req_headers: list[Header] = []

    if "requestBody" in operation:
        rb = operation["requestBody"]
        content = rb.get("content", {})
        if "application/json" in content:
            schema = content["application/json"].get("schema", {})
            request_body = _schema_to_example(schema, spec)
            req_headers.append(Header(name="Content-Type", value="application/json"))

    # Parameters
    for param in operation.get("parameters", []):
        if param.get("in") == "header":
            req_headers.append(
                Header(name=param["name"], value=param.get("example", ""))
            )

    # Build response (use first success response)
    resp_status = 200
    resp_body = None
    resp_headers: list[Header] = []

    responses = operation.get("responses", {})
    for status_code in ["200", "201", "204", "202"]:
        if status_code in responses:
            resp_status = int(status_code)
            response_spec = responses[status_code]

            content = response_spec.get("content", {})
            if "application/json" in content:
                schema = content["application/json"].get("schema", {})
                resp_body = _schema_to_example(schema, spec)

            for name, header_spec in response_spec.get("headers", {}).items():
                resp_headers.append(
                    Header(name=name, value=header_spec.get("example", ""))
                )
            break

    return Interaction(
        description=description,
        request=RequestSpec(
            method=HttpMethod(method.upper()),
            path=path,
            headers=req_headers,
            body=request_body,
        ),
        response=ResponseSpec(
            status=resp_status,
            headers=resp_headers,
            body=resp_body,
        ),
    )


def _schema_to_example(schema: dict[str, Any], spec: dict[str, Any]) -> Any:
    """Generate an example value from a JSON Schema."""
    # Handle $ref
    if "$ref" in schema:
        schema = _resolve_ref(schema["$ref"], spec)

    if "example" in schema:
        return schema["example"]

    schema_type = schema.get("type", "object")

    if schema_type == "object":
        result: dict[str, Any] = {}
        for prop_name, prop_schema in schema.get("properties", {}).items():
            result[prop_name] = _schema_to_example(prop_schema, spec)
        return result

    elif schema_type == "array":
        items = schema.get("items", {})
        return [_schema_to_example(items, spec)]

    elif schema_type == "string":
        fmt = schema.get("format", "")
        if fmt == "email":
            return "user@example.com"
        elif fmt == "uuid":
            return "550e8400-e29b-41d4-a716-446655440000"
        elif fmt == "date":
            return "2024-01-15"
        elif fmt == "date-time":
            return "2024-01-15T10:30:00Z"
        elif fmt == "uri":
            return "https://example.com"
        return schema.get("default", "string")

    elif schema_type == "integer":
        return schema.get("default", 0)

    elif schema_type == "number":
        return schema.get("default", 0.0)

    elif schema_type == "boolean":
        return schema.get("default", True)

    return None


def _resolve_ref(ref: str, spec: dict[str, Any]) -> dict[str, Any]:
    """Resolve a $ref pointer in the spec."""
    if not ref.startswith("#/"):
        return {}

    parts = ref[2:].split("/")
    current: Any = spec
    for part in parts:
        if isinstance(current, dict):
            current = current.get(part, {})
        else:
            return {}
    return current if isinstance(current, dict) else {}
