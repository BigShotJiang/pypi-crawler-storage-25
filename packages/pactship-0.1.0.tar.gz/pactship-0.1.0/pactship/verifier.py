"""Provider verification engine - verifies contracts against a running provider."""

from __future__ import annotations

import time
from typing import Any

import httpx

from pactship.matchers import MatchError, match_value
from pactship.models import (
    Contract,
    ContractVerificationReport,
    Header,
    Interaction,
    VerificationResult,
)


class ProviderVerifier:
    """Verifies that a provider satisfies consumer contracts."""

    def __init__(
        self,
        base_url: str,
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
        setup_url: str | None = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.default_headers = headers or {}
        self.setup_url = setup_url
        self._state_handlers: dict[str, Any] = {}

    def register_state_handler(self, state: str, handler: Any) -> None:
        """Register a handler function for a provider state."""
        self._state_handlers[state] = handler

    async def verify_contract(self, contract: Contract) -> ContractVerificationReport:
        """Verify all interactions in a contract."""
        report = ContractVerificationReport(contract=contract)
        start = time.monotonic()

        async with httpx.AsyncClient(
            base_url=self.base_url,
            timeout=self.timeout,
            headers=self.default_headers,
        ) as client:
            for interaction in contract.interactions:
                result = await self._verify_interaction(client, interaction)
                report.results.append(result)
                if not result.success:
                    report.success = False

        report.total_duration_ms = (time.monotonic() - start) * 1000
        return report

    async def verify_contracts(
        self, contracts: list[Contract]
    ) -> list[ContractVerificationReport]:
        """Verify multiple contracts."""
        reports: list[ContractVerificationReport] = []
        for contract in contracts:
            report = await self.verify_contract(contract)
            reports.append(report)
        return reports

    async def _verify_interaction(
        self, client: httpx.AsyncClient, interaction: Interaction
    ) -> VerificationResult:
        """Verify a single interaction against the provider."""
        start = time.monotonic()
        errors: list[str] = []
        warnings: list[str] = []

        # Setup provider states
        for state in interaction.provider_states:
            if state in self._state_handlers:
                handler = self._state_handlers[state]
                try:
                    if callable(handler):
                        handler()
                except Exception as e:
                    errors.append(f"State setup failed for '{state}': {e}")

            elif self.setup_url:
                try:
                    await client.post(
                        self.setup_url,
                        json={"state": state},
                    )
                except Exception as e:
                    errors.append(f"State setup request failed for '{state}': {e}")

        if errors:
            return VerificationResult(
                interaction=interaction,
                success=False,
                errors=errors,
                duration_ms=(time.monotonic() - start) * 1000,
            )

        # Build request
        req_spec = interaction.request
        request_headers = {**self.default_headers}
        for header in req_spec.headers:
            if header.value is not None:
                request_headers[header.name] = header.value

        params: dict[str, str] = {}
        for qp in req_spec.query_params:
            if qp.value is not None:
                params[qp.name] = qp.value

        try:
            response = await client.request(
                method=req_spec.method.value,
                url=req_spec.path,
                headers=request_headers,
                params=params or None,
                json=req_spec.body if req_spec.body is not None else None,
            )
        except httpx.HTTPError as e:
            return VerificationResult(
                interaction=interaction,
                success=False,
                errors=[f"HTTP request failed: {e}"],
                duration_ms=(time.monotonic() - start) * 1000,
            )

        # Verify status code
        resp_spec = interaction.response
        if response.status_code != resp_spec.status:
            errors.append(
                f"Status code mismatch: expected {resp_spec.status}, "
                f"got {response.status_code}"
            )

        # Verify response headers
        for expected_header in resp_spec.headers:
            actual_value = response.headers.get(expected_header.name.lower())
            if actual_value is None:
                errors.append(f"Missing response header: {expected_header.name}")
            elif expected_header.value is not None and actual_value != expected_header.value:
                if expected_header.matcher:
                    match_errors = match_value(
                        f"header.{expected_header.name}",
                        None,
                        actual_value,
                        {f"header.{expected_header.name}": expected_header.matcher},
                    )
                    errors.extend(str(e) for e in match_errors)
                else:
                    errors.append(
                        f"Header '{expected_header.name}' mismatch: "
                        f"expected {expected_header.value!r}, got {actual_value!r}"
                    )

        # Verify response body
        actual_body = None
        if resp_spec.body is not None:
            try:
                actual_body = response.json()
            except Exception:
                errors.append("Failed to parse response body as JSON")
                actual_body = response.text

            if actual_body is not None and isinstance(resp_spec.body, (dict, list)):
                # Convert matchers
                matcher_dict = {}
                for k, v in resp_spec.body_matchers.items():
                    matcher_dict[k] = v

                match_errors = match_value(
                    "body", resp_spec.body, actual_body, matcher_dict or None
                )
                errors.extend(str(e) for e in match_errors)

        duration_ms = (time.monotonic() - start) * 1000

        return VerificationResult(
            interaction=interaction,
            success=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            duration_ms=duration_ms,
            actual_status=response.status_code,
            actual_body=actual_body,
            actual_headers=dict(response.headers),
        )


class MockProvider:
    """In-process mock provider for consumer testing."""

    def __init__(self) -> None:
        self._interactions: list[Interaction] = []

    def add_interaction(self, interaction: Interaction) -> None:
        """Add an expected interaction."""
        self._interactions.append(interaction)

    def add_interactions_from_contract(self, contract: Contract) -> None:
        """Add all interactions from a contract."""
        self._interactions.extend(contract.interactions)

    def find_interaction(
        self, method: str, path: str
    ) -> Interaction | None:
        """Find matching interaction by method and path."""
        for interaction in self._interactions:
            if (
                interaction.request.method.value == method.upper()
                and interaction.request.path == path
            ):
                return interaction
        return None

    def get_mock_response(
        self, method: str, path: str
    ) -> tuple[int, dict[str, str], Any] | None:
        """Get mock response for a request."""
        interaction = self.find_interaction(method, path)
        if interaction is None:
            return None

        headers: dict[str, str] = {}
        for header in interaction.response.headers:
            if header.value is not None:
                headers[header.name] = header.value

        return (
            interaction.response.status,
            headers,
            interaction.response.body,
        )

    def clear(self) -> None:
        """Clear all interactions."""
        self._interactions.clear()

    @property
    def interactions(self) -> list[Interaction]:
        return list(self._interactions)
