"""Contract diff engine — detect breaking vs non-breaking changes."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from pactship.models import Contract, Interaction


class ChangeType(str, Enum):
    """Types of contract changes."""

    ADDED = "added"
    REMOVED = "removed"
    MODIFIED = "modified"


class Severity(str, Enum):
    """Severity of a contract change."""

    BREAKING = "breaking"
    NON_BREAKING = "non_breaking"
    INFO = "info"


@dataclass
class ContractChange:
    """A single change detected between two contract versions."""

    change_type: ChangeType
    severity: Severity
    path: str
    description: str
    old_value: Any = None
    new_value: Any = None

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "change_type": self.change_type.value,
            "severity": self.severity.value,
            "path": self.path,
            "description": self.description,
        }
        if self.old_value is not None:
            result["old_value"] = self.old_value
        if self.new_value is not None:
            result["new_value"] = self.new_value
        return result


@dataclass
class ContractDiff:
    """Result of comparing two contract versions."""

    old_contract: Contract
    new_contract: Contract
    changes: list[ContractChange] = field(default_factory=list)

    @property
    def has_breaking_changes(self) -> bool:
        return any(c.severity == Severity.BREAKING for c in self.changes)

    @property
    def breaking_changes(self) -> list[ContractChange]:
        return [c for c in self.changes if c.severity == Severity.BREAKING]

    @property
    def non_breaking_changes(self) -> list[ContractChange]:
        return [c for c in self.changes if c.severity == Severity.NON_BREAKING]

    @property
    def info_changes(self) -> list[ContractChange]:
        return [c for c in self.changes if c.severity == Severity.INFO]

    def to_dict(self) -> dict[str, Any]:
        return {
            "has_breaking_changes": self.has_breaking_changes,
            "summary": {
                "breaking": len(self.breaking_changes),
                "non_breaking": len(self.non_breaking_changes),
                "info": len(self.info_changes),
                "total": len(self.changes),
            },
            "changes": [c.to_dict() for c in self.changes],
        }


def diff_contracts(old: Contract, new: Contract) -> ContractDiff:
    """Compare two contracts and detect changes."""
    result = ContractDiff(old_contract=old, new_contract=new)

    # Index by (method, path, description) for precise matching
    old_by_key = _index_by_key(old.interactions)
    new_by_key = _index_by_key(new.interactions)

    # Also index by (method, path) for fuzzy matching
    old_by_route = _index_by_route(old.interactions)
    new_by_route = _index_by_route(new.interactions)

    matched_new_keys: set[tuple[str, str, str]] = set()

    # Process old interactions
    for key, interaction in old_by_key.items():
        if key in new_by_key:
            # Same key exists in new — diff them
            matched_new_keys.add(key)
            _diff_interactions(result, interaction, new_by_key[key])
        else:
            route = (interaction.request.method.value, interaction.request.path)
            if route not in new_by_route:
                result.changes.append(
                    ContractChange(
                        change_type=ChangeType.REMOVED,
                        severity=Severity.BREAKING,
                        path=f"interactions[{interaction.description}]",
                        description=f"Interaction removed: {interaction.description}",
                        old_value=interaction.to_dict(),
                    )
                )
            else:
                # Route exists but description changed — it's a modification
                new_int = new_by_route[route]
                new_key = (new_int.request.method.value, new_int.request.path, new_int.description)
                matched_new_keys.add(new_key)
                _diff_interactions(result, interaction, new_int)

    # Detect added interactions
    for key, interaction in new_by_key.items():
        if key not in matched_new_keys:
            route = (interaction.request.method.value, interaction.request.path)
            if route not in old_by_route:
                result.changes.append(
                    ContractChange(
                        change_type=ChangeType.ADDED,
                        severity=Severity.NON_BREAKING,
                        path=f"interactions[{interaction.description}]",
                        description=f"New interaction added: {interaction.description}",
                        new_value=interaction.to_dict(),
                    )
                )

    return result


def _index_by_key(
    interactions: list[Interaction],
) -> dict[tuple[str, str, str], Interaction]:
    """Index interactions by (method, path, description)."""
    result: dict[tuple[str, str, str], Interaction] = {}
    for interaction in interactions:
        key = (interaction.request.method.value, interaction.request.path, interaction.description)
        result[key] = interaction
    return result


def _index_by_route(
    interactions: list[Interaction],
) -> dict[tuple[str, str], Interaction]:
    """Index interactions by (method, path)."""
    result: dict[tuple[str, str], Interaction] = {}
    for interaction in interactions:
        key = (interaction.request.method.value, interaction.request.path)
        result[key] = interaction
    return result


def _diff_interactions(
    result: ContractDiff, old: Interaction, new: Interaction
) -> None:
    """Diff two interactions that share the same route."""
    base_path = f"interactions[{old.description}]"

    # Status code change
    if old.response.status != new.response.status:
        result.changes.append(
            ContractChange(
                change_type=ChangeType.MODIFIED,
                severity=Severity.BREAKING,
                path=f"{base_path}.response.status",
                description="Response status code changed",
                old_value=old.response.status,
                new_value=new.response.status,
            )
        )

    # Request method change
    if old.request.method != new.request.method:
        result.changes.append(
            ContractChange(
                change_type=ChangeType.MODIFIED,
                severity=Severity.BREAKING,
                path=f"{base_path}.request.method",
                description="Request method changed",
                old_value=old.request.method.value,
                new_value=new.request.method.value,
            )
        )

    # Request path change
    if old.request.path != new.request.path:
        result.changes.append(
            ContractChange(
                change_type=ChangeType.MODIFIED,
                severity=Severity.BREAKING,
                path=f"{base_path}.request.path",
                description="Request path changed",
                old_value=old.request.path,
                new_value=new.request.path,
            )
        )

    # Response body changes
    if old.response.body is not None and new.response.body is not None:
        _diff_body(result, base_path + ".response.body", old.response.body, new.response.body)
    elif old.response.body is not None and new.response.body is None:
        result.changes.append(
            ContractChange(
                change_type=ChangeType.REMOVED,
                severity=Severity.BREAKING,
                path=f"{base_path}.response.body",
                description="Response body removed",
                old_value=old.response.body,
            )
        )
    elif old.response.body is None and new.response.body is not None:
        result.changes.append(
            ContractChange(
                change_type=ChangeType.ADDED,
                severity=Severity.NON_BREAKING,
                path=f"{base_path}.response.body",
                description="Response body added",
                new_value=new.response.body,
            )
        )

    # Request body changes
    if old.request.body is not None and new.request.body is not None:
        _diff_body(result, base_path + ".request.body", old.request.body, new.request.body)


def _diff_body(
    result: ContractDiff, base_path: str, old: Any, new: Any
) -> None:
    """Diff response/request bodies."""
    if isinstance(old, dict) and isinstance(new, dict):
        # Check for removed keys (breaking)
        for key in old:
            if key not in new:
                result.changes.append(
                    ContractChange(
                        change_type=ChangeType.REMOVED,
                        severity=Severity.BREAKING,
                        path=f"{base_path}.{key}",
                        description=f"Field '{key}' removed from body",
                        old_value=old[key],
                    )
                )
            else:
                _diff_body(result, f"{base_path}.{key}", old[key], new[key])

        # Check for added keys (non-breaking for responses)
        for key in new:
            if key not in old:
                result.changes.append(
                    ContractChange(
                        change_type=ChangeType.ADDED,
                        severity=Severity.NON_BREAKING,
                        path=f"{base_path}.{key}",
                        description=f"Field '{key}' added to body",
                        new_value=new[key],
                    )
                )

    elif isinstance(old, list) and isinstance(new, list):
        if len(old) != len(new):
            result.changes.append(
                ContractChange(
                    change_type=ChangeType.MODIFIED,
                    severity=Severity.INFO,
                    path=base_path,
                    description=f"Array length changed from {len(old)} to {len(new)}",
                    old_value=len(old),
                    new_value=len(new),
                )
            )

    elif type(old) != type(new):
        result.changes.append(
            ContractChange(
                change_type=ChangeType.MODIFIED,
                severity=Severity.BREAKING,
                path=base_path,
                description=f"Type changed from {type(old).__name__} to {type(new).__name__}",
                old_value=str(old),
                new_value=str(new),
            )
        )

    elif old != new:
        result.changes.append(
            ContractChange(
                change_type=ChangeType.MODIFIED,
                severity=Severity.INFO,
                path=base_path,
                description="Value changed",
                old_value=old,
                new_value=new,
            )
        )
