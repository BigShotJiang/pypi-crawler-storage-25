"""Compatibility matrix — track which consumer/provider versions are compatible."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass
class CompatibilityEntry:
    """A single compatibility check result."""

    consumer: str
    consumer_version: str
    provider: str
    provider_version: str
    compatible: bool
    timestamp: str = ""
    details: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict[str, Any]:
        return {
            "consumer": self.consumer,
            "consumer_version": self.consumer_version,
            "provider": self.provider,
            "provider_version": self.provider_version,
            "compatible": self.compatible,
            "timestamp": self.timestamp,
            "details": self.details,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CompatibilityEntry:
        return cls(
            consumer=data["consumer"],
            consumer_version=data["consumer_version"],
            provider=data["provider"],
            provider_version=data["provider_version"],
            compatible=data["compatible"],
            timestamp=data.get("timestamp", ""),
            details=data.get("details", {}),
        )


class CompatibilityMatrix:
    """Tracks compatibility between consumer and provider versions."""

    def __init__(self) -> None:
        self._entries: list[CompatibilityEntry] = []

    def add(self, entry: CompatibilityEntry) -> None:
        """Add a compatibility entry."""
        self._entries.append(entry)

    def is_compatible(
        self,
        consumer: str,
        consumer_version: str,
        provider: str,
        provider_version: str,
    ) -> bool | None:
        """Check if a specific version pair is compatible. Returns None if unknown."""
        for entry in reversed(self._entries):
            if (
                entry.consumer == consumer
                and entry.consumer_version == consumer_version
                and entry.provider == provider
                and entry.provider_version == provider_version
            ):
                return entry.compatible
        return None

    def get_compatible_providers(
        self, consumer: str, consumer_version: str, provider: str
    ) -> list[str]:
        """Get all compatible provider versions for a consumer version."""
        versions: list[str] = []
        seen: set[str] = set()
        for entry in reversed(self._entries):
            if (
                entry.consumer == consumer
                and entry.consumer_version == consumer_version
                and entry.provider == provider
                and entry.compatible
                and entry.provider_version not in seen
            ):
                versions.append(entry.provider_version)
                seen.add(entry.provider_version)
        return versions

    def get_compatible_consumers(
        self, provider: str, provider_version: str, consumer: str
    ) -> list[str]:
        """Get all compatible consumer versions for a provider version."""
        versions: list[str] = []
        seen: set[str] = set()
        for entry in reversed(self._entries):
            if (
                entry.provider == provider
                and entry.provider_version == provider_version
                and entry.consumer == consumer
                and entry.compatible
                and entry.consumer_version not in seen
            ):
                versions.append(entry.consumer_version)
                seen.add(entry.consumer_version)
        return versions

    def get_entries(
        self,
        consumer: str | None = None,
        provider: str | None = None,
    ) -> list[CompatibilityEntry]:
        """Get filtered entries."""
        result: list[CompatibilityEntry] = []
        for entry in self._entries:
            if consumer and entry.consumer != consumer:
                continue
            if provider and entry.provider != provider:
                continue
            result.append(entry)
        return result

    def to_table(self) -> dict[str, dict[str, bool]]:
        """Generate a compatibility table (consumer_ver -> provider_ver -> bool)."""
        table: dict[str, dict[str, bool]] = {}
        for entry in self._entries:
            row_key = f"{entry.consumer}@{entry.consumer_version}"
            col_key = f"{entry.provider}@{entry.provider_version}"
            if row_key not in table:
                table[row_key] = {}
            table[row_key][col_key] = entry.compatible
        return table

    def save(self, path: str | Path) -> None:
        """Save the matrix to a JSON file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = [e.to_dict() for e in self._entries]
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def load(self, path: str | Path) -> None:
        """Load the matrix from a JSON file."""
        path = Path(path)
        if not path.exists():
            return
        data = json.loads(path.read_text(encoding="utf-8"))
        self._entries = [CompatibilityEntry.from_dict(e) for e in data]

    @property
    def entries(self) -> list[CompatibilityEntry]:
        return list(self._entries)

    def clear(self) -> None:
        self._entries.clear()

    def __len__(self) -> int:
        return len(self._entries)
