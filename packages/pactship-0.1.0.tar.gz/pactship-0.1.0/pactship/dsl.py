"""Fluent DSL for building contracts programmatically."""

from __future__ import annotations

from typing import Any

from pactship.models import (
    Contract,
    Header,
    HttpMethod,
    Interaction,
    Matcher,
    QueryParam,
    RequestSpec,
    ResponseSpec,
)


class InteractionBuilder:
    """Fluent builder for creating interactions."""

    def __init__(self, description: str) -> None:
        self._description = description
        self._method: HttpMethod = HttpMethod.GET
        self._path: str = "/"
        self._request_headers: list[Header] = []
        self._request_query: list[QueryParam] = []
        self._request_body: dict[str, Any] | list[Any] | None = None
        self._request_body_matchers: dict[str, Matcher] = {}
        self._response_status: int = 200
        self._response_headers: list[Header] = []
        self._response_body: dict[str, Any] | list[Any] | None = None
        self._response_body_matchers: dict[str, Matcher] = {}
        self._provider_states: list[str] = []
        self._tags: list[str] = []

    def given(self, state: str) -> InteractionBuilder:
        """Add a provider state prerequisite."""
        self._provider_states.append(state)
        return self

    def upon_receiving(self, description: str) -> InteractionBuilder:
        """Set the interaction description."""
        self._description = description
        return self

    def with_request(
        self, method: str | HttpMethod, path: str
    ) -> InteractionBuilder:
        """Set the request method and path."""
        if isinstance(method, str):
            self._method = HttpMethod(method.upper())
        else:
            self._method = method
        self._path = path
        return self

    def with_request_header(
        self, name: str, value: str, matcher: Matcher | None = None
    ) -> InteractionBuilder:
        """Add a request header."""
        self._request_headers.append(Header(name=name, value=value, matcher=matcher))
        return self

    def with_query_param(
        self, name: str, value: str, matcher: Matcher | None = None
    ) -> InteractionBuilder:
        """Add a query parameter."""
        self._request_query.append(
            QueryParam(name=name, value=value, matcher=matcher)
        )
        return self

    def with_request_body(
        self,
        body: dict[str, Any] | list[Any],
        matchers: dict[str, Matcher] | None = None,
    ) -> InteractionBuilder:
        """Set the request body."""
        self._request_body = body
        if matchers:
            self._request_body_matchers = matchers
        return self

    def will_respond_with(self, status: int) -> InteractionBuilder:
        """Set the expected response status."""
        self._response_status = status
        return self

    def with_response_header(
        self, name: str, value: str, matcher: Matcher | None = None
    ) -> InteractionBuilder:
        """Add an expected response header."""
        self._response_headers.append(Header(name=name, value=value, matcher=matcher))
        return self

    def with_response_body(
        self,
        body: dict[str, Any] | list[Any],
        matchers: dict[str, Matcher] | None = None,
    ) -> InteractionBuilder:
        """Set the expected response body."""
        self._response_body = body
        if matchers:
            self._response_body_matchers = matchers
        return self

    def with_tag(self, tag: str) -> InteractionBuilder:
        """Add a tag to this interaction."""
        self._tags.append(tag)
        return self

    def build(self) -> Interaction:
        """Build the interaction."""
        return Interaction(
            description=self._description,
            request=RequestSpec(
                method=self._method,
                path=self._path,
                headers=self._request_headers,
                query_params=self._request_query,
                body=self._request_body,
                body_matchers=self._request_body_matchers,
            ),
            response=ResponseSpec(
                status=self._response_status,
                headers=self._response_headers,
                body=self._response_body,
                body_matchers=self._response_body_matchers,
            ),
            provider_states=self._provider_states,
            tags=self._tags,
        )


class ContractBuilder:
    """Fluent builder for creating contracts."""

    def __init__(self, consumer: str, provider: str) -> None:
        self._consumer = consumer
        self._provider = provider
        self._interactions: list[Interaction] = []
        self._metadata: dict[str, Any] = {}

    def add_interaction(self, interaction: Interaction) -> ContractBuilder:
        """Add a pre-built interaction."""
        self._interactions.append(interaction)
        return self

    def interaction(self, description: str) -> InteractionBuilder:
        """Start building a new interaction.

        Note: Call .build() on the returned builder and then add it
        with add_interaction().
        """
        return InteractionBuilder(description)

    def with_metadata(self, key: str, value: Any) -> ContractBuilder:
        """Add metadata to the contract."""
        self._metadata[key] = value
        return self

    def build(self) -> Contract:
        """Build the contract."""
        return Contract(
            consumer=self._consumer,
            provider=self._provider,
            interactions=self._interactions,
            metadata=self._metadata,
        )
