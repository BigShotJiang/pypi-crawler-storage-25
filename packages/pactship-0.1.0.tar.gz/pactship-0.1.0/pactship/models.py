"""Core data models for contract definitions."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class HttpMethod(str, Enum):
    """Supported HTTP methods."""

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"


class MatcherType(str, Enum):
    """Types of matchers for flexible contract matching."""

    EXACT = "exact"
    TYPE = "type"
    REGEX = "regex"
    RANGE = "range"
    ARRAY_LIKE = "array_like"
    EACH_LIKE = "each_like"
    ANY_OF = "any_of"
    NULLABLE = "nullable"
    ISO_DATE = "iso_date"
    ISO_DATETIME = "iso_datetime"
    UUID = "uuid"
    EMAIL = "email"
    INTEGER = "integer"
    DECIMAL = "decimal"
    BOOLEAN = "boolean"
    STRING = "string"


@dataclass
class Matcher:
    """A flexible matcher for contract fields."""

    type: MatcherType
    value: Any = None
    min_val: Any = None
    max_val: Any = None
    pattern: str | None = None
    example: Any = None

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {"type": self.type.value}
        if self.value is not None:
            result["value"] = self.value
        if self.min_val is not None:
            result["min"] = self.min_val
        if self.max_val is not None:
            result["max"] = self.max_val
        if self.pattern is not None:
            result["pattern"] = self.pattern
        if self.example is not None:
            result["example"] = self.example
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Matcher:
        return cls(
            type=MatcherType(data["type"]),
            value=data.get("value"),
            min_val=data.get("min"),
            max_val=data.get("max"),
            pattern=data.get("pattern"),
            example=data.get("example"),
        )


@dataclass
class Header:
    """HTTP header with optional matcher."""

    name: str
    value: str | None = None
    matcher: Matcher | None = None

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {"name": self.name}
        if self.value is not None:
            result["value"] = self.value
        if self.matcher is not None:
            result["matcher"] = self.matcher.to_dict()
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Header:
        matcher = None
        if "matcher" in data:
            matcher = Matcher.from_dict(data["matcher"])
        return cls(name=data["name"], value=data.get("value"), matcher=matcher)


@dataclass
class QueryParam:
    """Query parameter with optional matcher."""

    name: str
    value: str | None = None
    matcher: Matcher | None = None

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {"name": self.name}
        if self.value is not None:
            result["value"] = self.value
        if self.matcher is not None:
            result["matcher"] = self.matcher.to_dict()
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> QueryParam:
        matcher = None
        if "matcher" in data:
            matcher = Matcher.from_dict(data["matcher"])
        return cls(name=data["name"], value=data.get("value"), matcher=matcher)


@dataclass
class RequestSpec:
    """Specification for the expected request."""

    method: HttpMethod
    path: str
    headers: list[Header] = field(default_factory=list)
    query_params: list[QueryParam] = field(default_factory=list)
    body: dict[str, Any] | list[Any] | None = None
    body_matchers: dict[str, Matcher] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "method": self.method.value,
            "path": self.path,
        }
        if self.headers:
            result["headers"] = [h.to_dict() for h in self.headers]
        if self.query_params:
            result["query_params"] = [q.to_dict() for q in self.query_params]
        if self.body is not None:
            result["body"] = self.body
        if self.body_matchers:
            result["body_matchers"] = {
                k: v.to_dict() for k, v in self.body_matchers.items()
            }
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RequestSpec:
        headers = [Header.from_dict(h) for h in data.get("headers", [])]
        query_params = [QueryParam.from_dict(q) for q in data.get("query_params", [])]
        body_matchers = {
            k: Matcher.from_dict(v) for k, v in data.get("body_matchers", {}).items()
        }
        return cls(
            method=HttpMethod(data["method"]),
            path=data["path"],
            headers=headers,
            query_params=query_params,
            body=data.get("body"),
            body_matchers=body_matchers,
        )


@dataclass
class ResponseSpec:
    """Specification for the expected response."""

    status: int
    headers: list[Header] = field(default_factory=list)
    body: dict[str, Any] | list[Any] | None = None
    body_matchers: dict[str, Matcher] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {"status": self.status}
        if self.headers:
            result["headers"] = [h.to_dict() for h in self.headers]
        if self.body is not None:
            result["body"] = self.body
        if self.body_matchers:
            result["body_matchers"] = {
                k: v.to_dict() for k, v in self.body_matchers.items()
            }
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResponseSpec:
        headers = [Header.from_dict(h) for h in data.get("headers", [])]
        body_matchers = {
            k: Matcher.from_dict(v) for k, v in data.get("body_matchers", {}).items()
        }
        return cls(
            status=data["status"],
            headers=headers,
            body=data.get("body"),
            body_matchers=body_matchers,
        )


@dataclass
class Interaction:
    """A single consumer-provider interaction (request-response pair)."""

    description: str
    request: RequestSpec
    response: ResponseSpec
    provider_states: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "description": self.description,
            "request": self.request.to_dict(),
            "response": self.response.to_dict(),
        }
        if self.provider_states:
            result["provider_states"] = self.provider_states
        if self.tags:
            result["tags"] = self.tags
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Interaction:
        return cls(
            description=data["description"],
            request=RequestSpec.from_dict(data["request"]),
            response=ResponseSpec.from_dict(data["response"]),
            provider_states=data.get("provider_states", []),
            tags=data.get("tags", []),
        )

    @property
    def fingerprint(self) -> str:
        """Generate a unique fingerprint for this interaction."""
        content = json.dumps(
            {
                "method": self.request.method.value,
                "path": self.request.path,
                "status": self.response.status,
                "description": self.description,
            },
            sort_keys=True,
        )
        return hashlib.sha256(content.encode()).hexdigest()[:16]


class ContractVersion(str, Enum):
    """Contract specification versions."""

    V1 = "1.0"


@dataclass
class Contract:
    """A contract between a consumer and a provider."""

    consumer: str
    provider: str
    interactions: list[Interaction] = field(default_factory=list)
    version: ContractVersion = ContractVersion.V1
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": self.version.value,
            "consumer": self.consumer,
            "provider": self.provider,
            "interactions": [i.to_dict() for i in self.interactions],
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Contract:
        return cls(
            version=ContractVersion(data.get("version", "1.0")),
            consumer=data["consumer"],
            provider=data["provider"],
            interactions=[
                Interaction.from_dict(i) for i in data.get("interactions", [])
            ],
            metadata=data.get("metadata", {}),
        )

    @property
    def fingerprint(self) -> str:
        """Generate a unique fingerprint for the entire contract."""
        content = json.dumps(self.to_dict(), sort_keys=True)
        return hashlib.sha256(content.encode()).hexdigest()[:16]


@dataclass
class VerificationResult:
    """Result of verifying a single interaction."""

    interaction: Interaction
    success: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    duration_ms: float = 0.0
    actual_status: int | None = None
    actual_body: Any = None
    actual_headers: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "interaction": self.interaction.description,
            "success": self.success,
            "errors": self.errors,
            "warnings": self.warnings,
            "duration_ms": self.duration_ms,
        }


@dataclass
class ContractVerificationReport:
    """Full report for verifying a contract."""

    contract: Contract
    results: list[VerificationResult] = field(default_factory=list)
    success: bool = True
    total_duration_ms: float = 0.0

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.success)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.results if not r.success)

    @property
    def total(self) -> int:
        return len(self.results)

    def to_dict(self) -> dict[str, Any]:
        return {
            "consumer": self.contract.consumer,
            "provider": self.contract.provider,
            "success": self.success,
            "summary": {
                "total": self.total,
                "passed": self.passed,
                "failed": self.failed,
            },
            "total_duration_ms": self.total_duration_ms,
            "results": [r.to_dict() for r in self.results],
        }
