"""Service dependency graph from contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pactship.models import Contract


@dataclass
class ServiceNode:
    """A node in the service dependency graph."""

    name: str
    is_consumer: bool = False
    is_provider: bool = False
    consumer_of: set[str] = field(default_factory=set)
    provider_for: set[str] = field(default_factory=set)
    interaction_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "is_consumer": self.is_consumer,
            "is_provider": self.is_provider,
            "consumer_of": sorted(self.consumer_of),
            "provider_for": sorted(self.provider_for),
            "interaction_count": self.interaction_count,
        }


@dataclass
class ServiceEdge:
    """An edge in the service dependency graph."""

    consumer: str
    provider: str
    interaction_count: int = 0
    paths: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "consumer": self.consumer,
            "provider": self.provider,
            "interaction_count": self.interaction_count,
            "paths": self.paths,
        }


class ServiceGraph:
    """Graph of service dependencies derived from contracts."""

    def __init__(self) -> None:
        self._nodes: dict[str, ServiceNode] = {}
        self._edges: dict[tuple[str, str], ServiceEdge] = {}

    def add_contract(self, contract: Contract) -> None:
        """Add a contract to the graph."""
        consumer = contract.consumer
        provider = contract.provider

        # Ensure nodes exist
        if consumer not in self._nodes:
            self._nodes[consumer] = ServiceNode(name=consumer)
        if provider not in self._nodes:
            self._nodes[provider] = ServiceNode(name=provider)

        # Update node properties
        self._nodes[consumer].is_consumer = True
        self._nodes[consumer].consumer_of.add(provider)
        self._nodes[consumer].interaction_count += len(contract.interactions)

        self._nodes[provider].is_provider = True
        self._nodes[provider].provider_for.add(consumer)
        self._nodes[provider].interaction_count += len(contract.interactions)

        # Update edge
        edge_key = (consumer, provider)
        if edge_key not in self._edges:
            self._edges[edge_key] = ServiceEdge(
                consumer=consumer, provider=provider
            )

        edge = self._edges[edge_key]
        edge.interaction_count += len(contract.interactions)

        for interaction in contract.interactions:
            if interaction.request.path not in edge.paths:
                edge.paths.append(interaction.request.path)

    def add_contracts(self, contracts: list[Contract]) -> None:
        """Add multiple contracts."""
        for contract in contracts:
            self.add_contract(contract)

    @property
    def nodes(self) -> list[ServiceNode]:
        return list(self._nodes.values())

    @property
    def edges(self) -> list[ServiceEdge]:
        return list(self._edges.values())

    def get_node(self, name: str) -> ServiceNode | None:
        return self._nodes.get(name)

    def get_providers(self, service: str) -> list[str]:
        """Get all providers for a service."""
        node = self._nodes.get(service)
        return sorted(node.consumer_of) if node else []

    def get_consumers(self, service: str) -> list[str]:
        """Get all consumers of a service."""
        node = self._nodes.get(service)
        return sorted(node.provider_for) if node else []

    def get_edge(self, consumer: str, provider: str) -> ServiceEdge | None:
        return self._edges.get((consumer, provider))

    def find_cycles(self) -> list[list[str]]:
        """Find circular dependencies in the graph."""
        cycles: list[list[str]] = []
        visited: set[str] = set()
        path: list[str] = []
        path_set: set[str] = set()

        def dfs(node: str) -> None:
            if node in path_set:
                cycle_start = path.index(node)
                cycle = path[cycle_start:] + [node]
                cycles.append(cycle)
                return

            if node in visited:
                return

            visited.add(node)
            path.append(node)
            path_set.add(node)

            node_obj = self._nodes.get(node)
            if node_obj:
                for dep in sorted(node_obj.consumer_of):
                    dfs(dep)

            path.pop()
            path_set.discard(node)

        for name in sorted(self._nodes.keys()):
            visited.clear()
            path.clear()
            path_set.clear()
            dfs(name)

        # Deduplicate cycles
        unique: list[list[str]] = []
        seen_sets: list[frozenset[str]] = []
        for cycle in cycles:
            cycle_set = frozenset(cycle)
            if cycle_set not in seen_sets:
                seen_sets.append(cycle_set)
                unique.append(cycle)

        return unique

    def leaf_services(self) -> list[str]:
        """Services that are only providers (no dependencies)."""
        return sorted(
            name for name, node in self._nodes.items()
            if node.is_provider and not node.is_consumer
        )

    def root_services(self) -> list[str]:
        """Services that are only consumers (no one depends on them)."""
        return sorted(
            name for name, node in self._nodes.items()
            if node.is_consumer and not node.is_provider
        )

    def to_mermaid(self) -> str:
        """Generate Mermaid diagram syntax."""
        lines = ["graph LR"]
        for edge in sorted(self._edges.values(), key=lambda e: (e.consumer, e.provider)):
            lines.append(
                f"    {edge.consumer}[{edge.consumer}] --> "
                f"|{edge.interaction_count} interactions| "
                f"{edge.provider}[{edge.provider}]"
            )
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        return {
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
        }
