"""Matcher engine for flexible contract field matching."""

from __future__ import annotations

import re
import uuid as uuid_mod
from datetime import date, datetime
from typing import Any

from pactship.models import Matcher, MatcherType


class MatchError(Exception):
    """Raised when a value doesn't match the expected contract."""

    def __init__(self, path: str, message: str):
        self.path = path
        self.message = message
        super().__init__(f"{path}: {message}")


def match_value(
    path: str, expected: Any, actual: Any, matchers: dict[str, Matcher] | None = None
) -> list[MatchError]:
    """Match an actual value against expected, using matchers if available."""
    errors: list[MatchError] = []

    # Check if there's a specific matcher for this path
    if matchers and path in matchers:
        matcher = matchers[path]
        errors.extend(_apply_matcher(path, matcher, actual))
        return errors

    if expected is None:
        return errors

    if isinstance(expected, dict) and isinstance(actual, dict):
        errors.extend(_match_dict(path, expected, actual, matchers))
    elif isinstance(expected, list) and isinstance(actual, list):
        errors.extend(_match_list(path, expected, actual, matchers))
    elif type(expected) != type(actual):
        errors.append(
            MatchError(
                path,
                f"Type mismatch: expected {type(expected).__name__}, "
                f"got {type(actual).__name__}",
            )
        )
    elif expected != actual:
        errors.append(
            MatchError(
                path, f"Value mismatch: expected {expected!r}, got {actual!r}"
            )
        )

    return errors


def _match_dict(
    path: str,
    expected: dict[str, Any],
    actual: dict[str, Any],
    matchers: dict[str, Matcher] | None = None,
) -> list[MatchError]:
    """Match two dictionaries."""
    errors: list[MatchError] = []

    for key in expected:
        child_path = f"{path}.{key}" if path else key
        if key not in actual:
            errors.append(MatchError(child_path, "Missing key in actual response"))
        else:
            errors.extend(match_value(child_path, expected[key], actual[key], matchers))

    return errors


def _match_list(
    path: str,
    expected: list[Any],
    actual: list[Any],
    matchers: dict[str, Matcher] | None = None,
) -> list[MatchError]:
    """Match two lists."""
    errors: list[MatchError] = []

    if len(expected) > len(actual):
        errors.append(
            MatchError(
                path,
                f"Array length mismatch: expected at least {len(expected)}, "
                f"got {len(actual)}",
            )
        )
        return errors

    for i, exp_item in enumerate(expected):
        child_path = f"{path}[{i}]"
        if i < len(actual):
            errors.extend(
                match_value(child_path, exp_item, actual[i], matchers)
            )

    return errors


def _apply_matcher(path: str, matcher: Matcher, actual: Any) -> list[MatchError]:
    """Apply a specific matcher to a value."""
    errors: list[MatchError] = []

    match matcher.type:
        case MatcherType.EXACT:
            if actual != matcher.value:
                errors.append(
                    MatchError(
                        path,
                        f"Exact match failed: expected {matcher.value!r}, got {actual!r}",
                    )
                )

        case MatcherType.TYPE:
            expected_type = _resolve_type(matcher.value)
            if expected_type and not isinstance(actual, expected_type):
                errors.append(
                    MatchError(
                        path,
                        f"Type match failed: expected {matcher.value}, "
                        f"got {type(actual).__name__}",
                    )
                )

        case MatcherType.REGEX:
            if matcher.pattern is None:
                errors.append(MatchError(path, "Regex matcher missing pattern"))
            elif not isinstance(actual, str):
                errors.append(
                    MatchError(
                        path,
                        f"Regex match requires string, got {type(actual).__name__}",
                    )
                )
            elif not re.match(matcher.pattern, actual):
                errors.append(
                    MatchError(
                        path,
                        f"Regex match failed: {actual!r} does not match "
                        f"pattern {matcher.pattern!r}",
                    )
                )

        case MatcherType.RANGE:
            if not isinstance(actual, (int, float)):
                errors.append(
                    MatchError(
                        path,
                        f"Range match requires number, got {type(actual).__name__}",
                    )
                )
            else:
                if matcher.min_val is not None and actual < matcher.min_val:
                    errors.append(
                        MatchError(
                            path,
                            f"Value {actual} below minimum {matcher.min_val}",
                        )
                    )
                if matcher.max_val is not None and actual > matcher.max_val:
                    errors.append(
                        MatchError(
                            path,
                            f"Value {actual} above maximum {matcher.max_val}",
                        )
                    )

        case MatcherType.ARRAY_LIKE:
            if not isinstance(actual, list):
                errors.append(
                    MatchError(
                        path,
                        f"Array match requires list, got {type(actual).__name__}",
                    )
                )
            else:
                min_len = matcher.min_val if matcher.min_val is not None else 0
                if len(actual) < min_len:
                    errors.append(
                        MatchError(
                            path,
                            f"Array length {len(actual)} below minimum {min_len}",
                        )
                    )

        case MatcherType.EACH_LIKE:
            if not isinstance(actual, list):
                errors.append(
                    MatchError(
                        path,
                        f"Each-like match requires list, got {type(actual).__name__}",
                    )
                )
            elif matcher.example is not None:
                for i, item in enumerate(actual):
                    child_path = f"{path}[{i}]"
                    errors.extend(_match_structure(child_path, matcher.example, item))

        case MatcherType.ANY_OF:
            if not isinstance(matcher.value, list):
                errors.append(MatchError(path, "any_of matcher requires list value"))
            elif actual not in matcher.value:
                errors.append(
                    MatchError(
                        path,
                        f"Value {actual!r} not in allowed values {matcher.value!r}",
                    )
                )

        case MatcherType.NULLABLE:
            if actual is not None:
                if matcher.value is not None:
                    expected_type = _resolve_type(matcher.value)
                    if expected_type and not isinstance(actual, expected_type):
                        errors.append(
                            MatchError(
                                path,
                                f"Nullable type mismatch: expected {matcher.value} or null, "
                                f"got {type(actual).__name__}",
                            )
                        )

        case MatcherType.ISO_DATE:
            if not isinstance(actual, str):
                errors.append(
                    MatchError(path, f"ISO date requires string, got {type(actual).__name__}")
                )
            else:
                try:
                    date.fromisoformat(actual)
                except ValueError:
                    errors.append(
                        MatchError(path, f"Invalid ISO date: {actual!r}")
                    )

        case MatcherType.ISO_DATETIME:
            if not isinstance(actual, str):
                errors.append(
                    MatchError(
                        path,
                        f"ISO datetime requires string, got {type(actual).__name__}",
                    )
                )
            else:
                try:
                    datetime.fromisoformat(actual)
                except ValueError:
                    errors.append(
                        MatchError(path, f"Invalid ISO datetime: {actual!r}")
                    )

        case MatcherType.UUID:
            if not isinstance(actual, str):
                errors.append(
                    MatchError(path, f"UUID requires string, got {type(actual).__name__}")
                )
            else:
                try:
                    uuid_mod.UUID(actual)
                except ValueError:
                    errors.append(MatchError(path, f"Invalid UUID: {actual!r}"))

        case MatcherType.EMAIL:
            if not isinstance(actual, str):
                errors.append(
                    MatchError(path, f"Email requires string, got {type(actual).__name__}")
                )
            elif not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", actual):
                errors.append(MatchError(path, f"Invalid email: {actual!r}"))

        case MatcherType.INTEGER:
            if not isinstance(actual, int) or isinstance(actual, bool):
                errors.append(
                    MatchError(
                        path,
                        f"Integer match failed: got {type(actual).__name__}",
                    )
                )

        case MatcherType.DECIMAL:
            if not isinstance(actual, (int, float)) or isinstance(actual, bool):
                errors.append(
                    MatchError(
                        path,
                        f"Decimal match failed: got {type(actual).__name__}",
                    )
                )

        case MatcherType.BOOLEAN:
            if not isinstance(actual, bool):
                errors.append(
                    MatchError(
                        path,
                        f"Boolean match failed: got {type(actual).__name__}",
                    )
                )

        case MatcherType.STRING:
            if not isinstance(actual, str):
                errors.append(
                    MatchError(
                        path,
                        f"String match failed: got {type(actual).__name__}",
                    )
                )

    return errors


def _match_structure(
    path: str, example: Any, actual: Any
) -> list[MatchError]:
    """Match structure/types of actual against example (not exact values)."""
    errors: list[MatchError] = []

    if isinstance(example, dict):
        if not isinstance(actual, dict):
            errors.append(
                MatchError(path, f"Expected object, got {type(actual).__name__}")
            )
        else:
            for key in example:
                child_path = f"{path}.{key}" if path else key
                if key not in actual:
                    errors.append(MatchError(child_path, "Missing key in actual"))
                else:
                    errors.extend(
                        _match_structure(child_path, example[key], actual[key])
                    )
    elif isinstance(example, list):
        if not isinstance(actual, list):
            errors.append(
                MatchError(path, f"Expected array, got {type(actual).__name__}")
            )
    elif type(example) != type(actual) and not (
        isinstance(example, (int, float)) and isinstance(actual, (int, float))
    ):
        errors.append(
            MatchError(
                path,
                f"Type mismatch: expected {type(example).__name__}, "
                f"got {type(actual).__name__}",
            )
        )

    return errors


def _resolve_type(type_name: Any) -> type | tuple[type, ...] | None:
    """Resolve a type name string to a Python type."""
    if not isinstance(type_name, str):
        return None
    type_map: dict[str, type | tuple[type, ...]] = {
        "string": str,
        "str": str,
        "integer": int,
        "int": int,
        "float": float,
        "number": (int, float),
        "boolean": bool,
        "bool": bool,
        "list": list,
        "array": list,
        "dict": dict,
        "object": dict,
    }
    return type_map.get(type_name.lower())


# Convenience factory functions
def exact(value: Any) -> Matcher:
    """Match exactly this value."""
    return Matcher(type=MatcherType.EXACT, value=value)


def like(type_name: str) -> Matcher:
    """Match by type."""
    return Matcher(type=MatcherType.TYPE, value=type_name)


def regex(pattern: str, example: str | None = None) -> Matcher:
    """Match by regex pattern."""
    return Matcher(type=MatcherType.REGEX, pattern=pattern, example=example)


def range_match(min_val: float | None = None, max_val: float | None = None) -> Matcher:
    """Match a number within a range."""
    return Matcher(type=MatcherType.RANGE, min_val=min_val, max_val=max_val)


def array_like(min_length: int = 0) -> Matcher:
    """Match any array with optional minimum length."""
    return Matcher(type=MatcherType.ARRAY_LIKE, min_val=min_length)


def each_like(example: Any) -> Matcher:
    """Match each element of an array like the example."""
    return Matcher(type=MatcherType.EACH_LIKE, example=example)


def any_of(values: list[Any]) -> Matcher:
    """Match any of the given values."""
    return Matcher(type=MatcherType.ANY_OF, value=values)


def nullable(type_name: str | None = None) -> Matcher:
    """Match null or optionally a specific type."""
    return Matcher(type=MatcherType.NULLABLE, value=type_name)


def iso_date() -> Matcher:
    """Match an ISO 8601 date string."""
    return Matcher(type=MatcherType.ISO_DATE)


def iso_datetime() -> Matcher:
    """Match an ISO 8601 datetime string."""
    return Matcher(type=MatcherType.ISO_DATETIME)


def uuid_match() -> Matcher:
    """Match a UUID string."""
    return Matcher(type=MatcherType.UUID)


def email_match() -> Matcher:
    """Match an email address."""
    return Matcher(type=MatcherType.EMAIL)


def integer_match() -> Matcher:
    """Match an integer."""
    return Matcher(type=MatcherType.INTEGER)


def decimal_match() -> Matcher:
    """Match a decimal/float number."""
    return Matcher(type=MatcherType.DECIMAL)


def boolean_match() -> Matcher:
    """Match a boolean."""
    return Matcher(type=MatcherType.BOOLEAN)


def string_match() -> Matcher:
    """Match a string."""
    return Matcher(type=MatcherType.STRING)
