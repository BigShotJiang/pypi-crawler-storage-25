"""Contract validation — check contracts for structural correctness."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pactship.models import Contract, HttpMethod, Interaction


@dataclass
class ValidationIssue:
    """A single validation issue found in a contract."""

    path: str
    message: str
    severity: str = "error"  # "error" or "warning"

    def __str__(self) -> str:
        return f"[{self.severity}] {self.path}: {self.message}"


@dataclass
class ValidationResult:
    """Result of validating a contract."""

    valid: bool = True
    issues: list[ValidationIssue] = field(default_factory=list)

    def add_error(self, path: str, message: str) -> None:
        self.issues.append(ValidationIssue(path=path, message=message, severity="error"))
        self.valid = False

    def add_warning(self, path: str, message: str) -> None:
        self.issues.append(
            ValidationIssue(path=path, message=message, severity="warning")
        )

    @property
    def errors(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == "warning"]


def validate_contract(contract: Contract) -> ValidationResult:
    """Validate a contract for structural correctness."""
    result = ValidationResult()

    # Check consumer name
    if not contract.consumer or not contract.consumer.strip():
        result.add_error("consumer", "Consumer name is required")

    # Check provider name
    if not contract.provider or not contract.provider.strip():
        result.add_error("provider", "Provider name is required")

    # Check consumer != provider
    if contract.consumer and contract.provider:
        if contract.consumer.strip() == contract.provider.strip():
            result.add_warning(
                "consumer/provider",
                "Consumer and provider have the same name",
            )

    # Check interactions
    if not contract.interactions:
        result.add_warning("interactions", "Contract has no interactions")

    descriptions_seen: set[str] = set()
    routes_seen: set[tuple[str, str]] = set()

    for i, interaction in enumerate(contract.interactions):
        prefix = f"interactions[{i}]"
        _validate_interaction(interaction, prefix, result, descriptions_seen, routes_seen)

    return result


def _validate_interaction(
    interaction: Interaction,
    prefix: str,
    result: ValidationResult,
    descriptions_seen: set[str],
    routes_seen: set[tuple[str, str]],
) -> None:
    """Validate a single interaction."""
    # Description
    if not interaction.description or not interaction.description.strip():
        result.add_error(f"{prefix}.description", "Description is required")
    elif interaction.description in descriptions_seen:
        result.add_warning(
            f"{prefix}.description",
            f"Duplicate description: {interaction.description!r}",
        )
    else:
        descriptions_seen.add(interaction.description)

    # Request
    req = interaction.request

    # Path validation
    if not req.path:
        result.add_error(f"{prefix}.request.path", "Request path is required")
    elif not req.path.startswith("/"):
        result.add_error(
            f"{prefix}.request.path",
            f"Path must start with '/': {req.path!r}",
        )

    # Route duplicate check
    route = (req.method.value, req.path)
    if route in routes_seen:
        result.add_warning(
            f"{prefix}.request",
            f"Duplicate route: {req.method.value} {req.path}",
        )
    else:
        routes_seen.add(route)

    # Response
    resp = interaction.response
    if resp.status < 100 or resp.status > 599:
        result.add_error(
            f"{prefix}.response.status",
            f"Invalid HTTP status code: {resp.status}",
        )

    # Body with GET/HEAD/DELETE warning
    if req.body is not None and req.method in (
        HttpMethod.GET,
        HttpMethod.HEAD,
        HttpMethod.DELETE,
    ):
        result.add_warning(
            f"{prefix}.request.body",
            f"{req.method.value} request with body is unusual",
        )

    # Headers validation
    for j, header in enumerate(req.headers):
        if not header.name or not header.name.strip():
            result.add_error(
                f"{prefix}.request.headers[{j}].name",
                "Header name is required",
            )

    for j, header in enumerate(resp.headers):
        if not header.name or not header.name.strip():
            result.add_error(
                f"{prefix}.response.headers[{j}].name",
                "Header name is required",
            )


def validate_contract_dict(data: dict[str, Any]) -> ValidationResult:
    """Validate a raw contract dictionary before parsing."""
    result = ValidationResult()

    if not isinstance(data, dict):
        result.add_error("root", "Contract must be a JSON/YAML object")
        return result

    if "consumer" not in data:
        result.add_error("consumer", "Missing required field: consumer")

    if "provider" not in data:
        result.add_error("provider", "Missing required field: provider")

    if "interactions" in data:
        if not isinstance(data["interactions"], list):
            result.add_error("interactions", "Interactions must be a list")
        else:
            for i, interaction in enumerate(data["interactions"]):
                prefix = f"interactions[{i}]"
                if not isinstance(interaction, dict):
                    result.add_error(prefix, "Interaction must be an object")
                    continue

                if "description" not in interaction:
                    result.add_error(
                        f"{prefix}.description", "Missing required field"
                    )

                if "request" not in interaction:
                    result.add_error(f"{prefix}.request", "Missing required field")
                elif isinstance(interaction["request"], dict):
                    req = interaction["request"]
                    if "method" not in req:
                        result.add_error(
                            f"{prefix}.request.method", "Missing required field"
                        )
                    elif req["method"] not in [m.value for m in HttpMethod]:
                        result.add_error(
                            f"{prefix}.request.method",
                            f"Invalid HTTP method: {req['method']}",
                        )
                    if "path" not in req:
                        result.add_error(
                            f"{prefix}.request.path", "Missing required field"
                        )

                if "response" not in interaction:
                    result.add_error(f"{prefix}.response", "Missing required field")
                elif isinstance(interaction["response"], dict):
                    resp = interaction["response"]
                    if "status" not in resp:
                        result.add_error(
                            f"{prefix}.response.status", "Missing required field"
                        )

    return result
