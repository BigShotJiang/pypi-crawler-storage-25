"""CLI interface for pactship."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from pactship import __version__
from pactship.broker import ContractBroker
from pactship.contract_io import load_contract, load_contracts_from_dir, save_contract
from pactship.diff import diff_contracts
from pactship.verifier import ProviderVerifier

console = Console()


@click.group()
@click.version_option(version=__version__, prog_name="pactship")
def main() -> None:
    """Pactship - Lightweight consumer-driven contract testing."""
    pass


@main.command()
@click.argument("contract_path", type=click.Path(exists=True))
def validate(contract_path: str) -> None:
    """Validate a contract file."""
    try:
        contract = load_contract(contract_path)
        console.print(f"[green]Valid contract:[/green] {contract.consumer} -> {contract.provider}")
        console.print(f"  Interactions: {len(contract.interactions)}")
        for i, interaction in enumerate(contract.interactions, 1):
            console.print(
                f"  {i}. {interaction.request.method.value} "
                f"{interaction.request.path} -> {interaction.response.status}"
            )
    except Exception as e:
        console.print(f"[red]Invalid contract:[/red] {e}")
        sys.exit(1)


@main.command()
@click.argument("contract_path", type=click.Path(exists=True))
@click.argument("base_url")
@click.option("--timeout", default=30.0, help="Request timeout in seconds")
@click.option("--header", "-H", multiple=True, help="Additional headers (key:value)")
@click.option("--setup-url", help="URL for provider state setup")
@click.option("--output", "-o", type=click.Path(), help="Output report to file")
def verify(
    contract_path: str,
    base_url: str,
    timeout: float,
    header: tuple[str, ...],
    setup_url: str | None,
    output: str | None,
) -> None:
    """Verify a contract against a running provider."""
    headers: dict[str, str] = {}
    for h in header:
        if ":" in h:
            key, value = h.split(":", 1)
            headers[key.strip()] = value.strip()

    path = Path(contract_path)
    if path.is_dir():
        contracts = load_contracts_from_dir(path)
    else:
        contracts = [load_contract(path)]

    verifier = ProviderVerifier(
        base_url=base_url,
        timeout=timeout,
        headers=headers,
        setup_url=setup_url,
    )

    reports = asyncio.run(verifier.verify_contracts(contracts))

    all_passed = True
    for report in reports:
        _print_verification_report(report)
        if not report.success:
            all_passed = False

        if output:
            out_path = Path(output)
            out_path.write_text(
                json.dumps([r.to_dict() for r in reports], indent=2),
                encoding="utf-8",
            )
            console.print(f"\nReport saved to: {output}")

    if not all_passed:
        sys.exit(1)


@main.command()
@click.argument("old_path", type=click.Path(exists=True))
@click.argument("new_path", type=click.Path(exists=True))
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
def diff(old_path: str, new_path: str, json_output: bool) -> None:
    """Compare two contract versions and detect changes."""
    old_contract = load_contract(old_path)
    new_contract = load_contract(new_path)

    result = diff_contracts(old_contract, new_contract)

    if json_output:
        console.print(json.dumps(result.to_dict(), indent=2))
        return

    _print_diff_report(result)

    if result.has_breaking_changes:
        sys.exit(1)


@main.command()
@click.argument("contract_path", type=click.Path(exists=True))
@click.option("--broker-dir", "-d", default=".pactship", help="Broker directory")
def publish(contract_path: str, broker_dir: str) -> None:
    """Publish a contract to the local broker."""
    contract = load_contract(contract_path)
    broker = ContractBroker(broker_dir)
    path = broker.publish(contract)
    console.print(
        f"[green]Published:[/green] {contract.consumer} -> {contract.provider}"
    )
    console.print(f"  Saved to: {path}")


@main.command(name="list")
@click.option("--broker-dir", "-d", default=".pactship", help="Broker directory")
@click.option("--provider", "-p", help="Filter by provider")
@click.option("--consumer", "-c", help="Filter by consumer")
def list_contracts(broker_dir: str, provider: str | None, consumer: str | None) -> None:
    """List contracts in the broker."""
    broker = ContractBroker(broker_dir)
    pairs = broker.list_pairs()

    if not pairs:
        console.print("[yellow]No contracts found in broker.[/yellow]")
        return

    table = Table(title="Contracts")
    table.add_column("Consumer", style="cyan")
    table.add_column("Provider", style="magenta")
    table.add_column("Versions", style="green")
    table.add_column("Interactions", style="yellow")

    for cons, prov in pairs:
        if provider and prov != provider:
            continue
        if consumer and cons != consumer:
            continue

        versions = broker.list_versions(cons, prov)
        contract = broker.get_latest(cons, prov)
        interaction_count = len(contract.interactions) if contract else 0

        table.add_row(cons, prov, str(len(versions)), str(interaction_count))

    console.print(table)


@main.command()
@click.argument("contract_path", type=click.Path(exists=True))
@click.argument("output_path", type=click.Path())
@click.option("--format", "-f", "fmt", type=click.Choice(["yaml", "json"]), default="yaml")
def convert(contract_path: str, output_path: str, fmt: str) -> None:
    """Convert a contract between YAML and JSON formats."""
    contract = load_contract(contract_path)
    save_contract(contract, output_path, fmt=fmt)
    console.print(f"[green]Converted:[/green] {contract_path} -> {output_path} ({fmt})")


def _print_verification_report(report: Any) -> None:
    """Print a verification report to console."""
    status = "[green]PASSED[/green]" if report.success else "[red]FAILED[/red]"
    console.print(
        f"\n{status} {report.contract.consumer} -> {report.contract.provider}"
    )
    console.print(
        f"  {report.passed}/{report.total} interactions passed "
        f"({report.total_duration_ms:.1f}ms)"
    )

    for result in report.results:
        icon = "[green]✓[/green]" if result.success else "[red]✗[/red]"
        console.print(
            f"  {icon} {result.interaction.description} "
            f"({result.duration_ms:.1f}ms)"
        )
        for error in result.errors:
            console.print(f"    [red]→ {error}[/red]")
        for warning in result.warnings:
            console.print(f"    [yellow]→ {warning}[/yellow]")


def _print_diff_report(result: Any) -> None:
    """Print a diff report to console."""
    if not result.changes:
        console.print("[green]No changes detected.[/green]")
        return

    if result.has_breaking_changes:
        console.print("[red bold]⚠ Breaking changes detected![/red bold]")
    else:
        console.print("[green]No breaking changes.[/green]")

    for change in result.changes:
        match change.severity.value:
            case "breaking":
                style = "red"
                icon = "✗"
            case "non_breaking":
                style = "yellow"
                icon = "~"
            case _:
                style = "dim"
                icon = "·"

        console.print(
            f"  [{style}]{icon} [{change.change_type.value}] "
            f"{change.path}: {change.description}[/{style}]"
        )


if __name__ == "__main__":
    main()
