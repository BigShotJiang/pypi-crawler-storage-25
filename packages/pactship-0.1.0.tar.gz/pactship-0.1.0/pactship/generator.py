"""Contract generator — create contracts from endpoint definitions."""

from __future__ import annotations

from typing import Any

from pactship.models import (
    Contract,
    Header,
    HttpMethod,
    Interaction,
    Matcher,
    MatcherType,
    RequestSpec,
    ResponseSpec,
)


def generate_from_endpoints(
    consumer: str,
    provider: str,
    endpoints: list[dict[str, Any]],
) -> Contract:
    """Generate a contract from a list of endpoint definitions.

    Each endpoint dict should have:
        - method: str (e.g., "GET")
        - path: str (e.g., "/users/{id}")
        - description: str (optional)
        - request_body: dict (optional)
        - request_headers: dict[str, str] (optional)
        - response_status: int (default 200)
        - response_body: dict/list (optional)
        - response_headers: dict[str, str] (optional)
        - provider_states: list[str] (optional)
    """
    interactions: list[Interaction] = []

    for endpoint in endpoints:
        method = HttpMethod(endpoint["method"].upper())
        path = endpoint["path"]
        desc = endpoint.get("description", f"{method.value} {path}")

        req_headers = [
            Header(name=k, value=v)
            for k, v in endpoint.get("request_headers", {}).items()
        ]
        resp_headers = [
            Header(name=k, value=v)
            for k, v in endpoint.get("response_headers", {}).items()
        ]

        interaction = Interaction(
            description=desc,
            request=RequestSpec(
                method=method,
                path=path,
                headers=req_headers,
                body=endpoint.get("request_body"),
            ),
            response=ResponseSpec(
                status=endpoint.get("response_status", 200),
                headers=resp_headers,
                body=endpoint.get("response_body"),
            ),
            provider_states=endpoint.get("provider_states", []),
        )
        interactions.append(interaction)

    return Contract(
        consumer=consumer,
        provider=provider,
        interactions=interactions,
    )


def generate_crud_contract(
    consumer: str,
    provider: str,
    resource: str,
    resource_path: str,
    example_body: dict[str, Any],
    id_field: str = "id",
) -> Contract:
    """Generate a standard CRUD contract for a resource.

    Creates GET (list), GET (single), POST, PUT, DELETE interactions.
    """
    single_path = f"{resource_path}/{{{id_field}}}"
    example_with_id = {id_field: 1, **example_body}

    interactions = [
        Interaction(
            description=f"List {resource}s",
            request=RequestSpec(method=HttpMethod.GET, path=resource_path),
            response=ResponseSpec(
                status=200,
                body=[example_with_id],
            ),
        ),
        Interaction(
            description=f"Get {resource} by {id_field}",
            request=RequestSpec(method=HttpMethod.GET, path=single_path),
            response=ResponseSpec(
                status=200,
                body=example_with_id,
            ),
            provider_states=[f"{resource} exists"],
        ),
        Interaction(
            description=f"Create {resource}",
            request=RequestSpec(
                method=HttpMethod.POST,
                path=resource_path,
                body=example_body,
                headers=[Header(name="Content-Type", value="application/json")],
            ),
            response=ResponseSpec(
                status=201,
                body=example_with_id,
            ),
        ),
        Interaction(
            description=f"Update {resource}",
            request=RequestSpec(
                method=HttpMethod.PUT,
                path=single_path,
                body=example_body,
                headers=[Header(name="Content-Type", value="application/json")],
            ),
            response=ResponseSpec(
                status=200,
                body=example_with_id,
            ),
            provider_states=[f"{resource} exists"],
        ),
        Interaction(
            description=f"Delete {resource}",
            request=RequestSpec(
                method=HttpMethod.DELETE,
                path=single_path,
            ),
            response=ResponseSpec(status=204),
            provider_states=[f"{resource} exists"],
        ),
    ]

    return Contract(
        consumer=consumer,
        provider=provider,
        interactions=interactions,
    )


def infer_matchers_from_example(
    body: dict[str, Any], prefix: str = "body"
) -> dict[str, Matcher]:
    """Infer type matchers from an example body."""
    matchers: dict[str, Matcher] = {}
    _infer_recursive(body, prefix, matchers)
    return matchers


def _infer_recursive(
    value: Any, path: str, matchers: dict[str, Matcher]
) -> None:
    """Recursively infer matchers."""
    if isinstance(value, dict):
        for key, val in value.items():
            child_path = f"{path}.{key}"
            _infer_recursive(val, child_path, matchers)
    elif isinstance(value, list):
        if value:
            matchers[path] = Matcher(
                type=MatcherType.ARRAY_LIKE, min_val=0
            )
            _infer_recursive(value[0], f"{path}[0]", matchers)
    elif isinstance(value, bool):
        matchers[path] = Matcher(type=MatcherType.BOOLEAN)
    elif isinstance(value, int):
        matchers[path] = Matcher(type=MatcherType.INTEGER)
    elif isinstance(value, float):
        matchers[path] = Matcher(type=MatcherType.DECIMAL)
    elif isinstance(value, str):
        # Try to detect specific string types
        if _looks_like_email(value):
            matchers[path] = Matcher(type=MatcherType.EMAIL)
        elif _looks_like_uuid(value):
            matchers[path] = Matcher(type=MatcherType.UUID)
        elif _looks_like_iso_datetime(value):
            matchers[path] = Matcher(type=MatcherType.ISO_DATETIME)
        elif _looks_like_iso_date(value):
            matchers[path] = Matcher(type=MatcherType.ISO_DATE)
        else:
            matchers[path] = Matcher(type=MatcherType.STRING)


def _looks_like_email(s: str) -> bool:
    import re
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", s))


def _looks_like_uuid(s: str) -> bool:
    import re
    return bool(re.match(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
        s, re.IGNORECASE,
    ))


def _looks_like_iso_datetime(s: str) -> bool:
    import re
    return bool(re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}", s))


def _looks_like_iso_date(s: str) -> bool:
    import re
    return bool(re.match(r"^\d{4}-\d{2}-\d{2}$", s))
