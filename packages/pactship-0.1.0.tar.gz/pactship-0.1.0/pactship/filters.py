"""Filtering and querying interactions within contracts."""

from __future__ import annotations

import re
from typing import Any, Callable

from pactship.models import Contract, HttpMethod, Interaction


def filter_interactions(
    contract: Contract,
    method: str | HttpMethod | None = None,
    path_pattern: str | None = None,
    tag: str | None = None,
    tags_any: list[str] | None = None,
    tags_all: list[str] | None = None,
    description_pattern: str | None = None,
    status: int | None = None,
    provider_state: str | None = None,
    predicate: Callable[[Interaction], bool] | None = None,
) -> list[Interaction]:
    """Filter interactions from a contract by various criteria."""
    results: list[Interaction] = []

    for interaction in contract.interactions:
        if method is not None:
            m = HttpMethod(method.upper()) if isinstance(method, str) else method
            if interaction.request.method != m:
                continue

        if path_pattern is not None:
            if not re.search(path_pattern, interaction.request.path):
                continue

        if tag is not None:
            if tag not in interaction.tags:
                continue

        if tags_any is not None:
            if not any(t in interaction.tags for t in tags_any):
                continue

        if tags_all is not None:
            if not all(t in interaction.tags for t in tags_all):
                continue

        if description_pattern is not None:
            if not re.search(description_pattern, interaction.description, re.IGNORECASE):
                continue

        if status is not None:
            if interaction.response.status != status:
                continue

        if provider_state is not None:
            if provider_state not in interaction.provider_states:
                continue

        if predicate is not None:
            if not predicate(interaction):
                continue

        results.append(interaction)

    return results


def filter_contract(
    contract: Contract,
    **kwargs: Any,
) -> Contract:
    """Create a new contract with only matching interactions."""
    filtered = filter_interactions(contract, **kwargs)
    return Contract(
        consumer=contract.consumer,
        provider=contract.provider,
        interactions=filtered,
        version=contract.version,
        metadata={**contract.metadata},
    )


def group_by_tag(contract: Contract) -> dict[str, list[Interaction]]:
    """Group interactions by their tags."""
    groups: dict[str, list[Interaction]] = {}
    for interaction in contract.interactions:
        if not interaction.tags:
            groups.setdefault("untagged", []).append(interaction)
        else:
            for tag in interaction.tags:
                groups.setdefault(tag, []).append(interaction)
    return groups


def group_by_method(contract: Contract) -> dict[str, list[Interaction]]:
    """Group interactions by HTTP method."""
    groups: dict[str, list[Interaction]] = {}
    for interaction in contract.interactions:
        key = interaction.request.method.value
        groups.setdefault(key, []).append(interaction)
    return groups


def group_by_path_prefix(
    contract: Contract, depth: int = 1
) -> dict[str, list[Interaction]]:
    """Group interactions by path prefix."""
    groups: dict[str, list[Interaction]] = {}
    for interaction in contract.interactions:
        parts = interaction.request.path.strip("/").split("/")
        prefix = "/" + "/".join(parts[:depth]) if parts[0] else "/"
        groups.setdefault(prefix, []).append(interaction)
    return groups


def find_interaction(
    contract: Contract,
    description: str | None = None,
    method: str | None = None,
    path: str | None = None,
) -> Interaction | None:
    """Find the first interaction matching criteria."""
    for interaction in contract.interactions:
        if description and interaction.description != description:
            continue
        if method and interaction.request.method.value != method.upper():
            continue
        if path and interaction.request.path != path:
            continue
        return interaction
    return None
