"""Pactship - Lightweight consumer-driven contract testing for microservices APIs."""

__version__ = "0.1.0"

from pactship.models import (
    Contract,
    ContractVerificationReport,
    ContractVersion,
    Header,
    HttpMethod,
    Interaction,
    Matcher,
    MatcherType,
    QueryParam,
    RequestSpec,
    ResponseSpec,
    VerificationResult,
)
from pactship.dsl import ContractBuilder, InteractionBuilder
from pactship.matchers import (
    any_of,
    array_like,
    boolean_match,
    decimal_match,
    each_like,
    email_match,
    exact,
    integer_match,
    iso_date,
    iso_datetime,
    like,
    match_value,
    nullable,
    range_match,
    regex,
    string_match,
    uuid_match,
)
from pactship.contract_io import load_contract, save_contract
from pactship.verifier import MockProvider, ProviderVerifier
from pactship.diff import diff_contracts
from pactship.broker import ContractBroker
from pactship.validator import validate_contract
from pactship.generator import generate_crud_contract, generate_from_endpoints
from pactship.linter import lint_contract
from pactship.graph import ServiceGraph

__all__ = [
    # Version
    "__version__",
    # Models
    "Contract",
    "ContractVerificationReport",
    "ContractVersion",
    "Header",
    "HttpMethod",
    "Interaction",
    "Matcher",
    "MatcherType",
    "QueryParam",
    "RequestSpec",
    "ResponseSpec",
    "VerificationResult",
    # DSL
    "ContractBuilder",
    "InteractionBuilder",
    # Matchers
    "any_of",
    "array_like",
    "boolean_match",
    "decimal_match",
    "each_like",
    "email_match",
    "exact",
    "integer_match",
    "iso_date",
    "iso_datetime",
    "like",
    "match_value",
    "nullable",
    "range_match",
    "regex",
    "string_match",
    "uuid_match",
    # I/O
    "load_contract",
    "save_contract",
    # Verification
    "MockProvider",
    "ProviderVerifier",
    # Diff
    "diff_contracts",
    # Broker
    "ContractBroker",
    # Validation
    "validate_contract",
    # Generator
    "generate_crud_contract",
    "generate_from_endpoints",
    # Linter
    "lint_contract",
    # Graph
    "ServiceGraph",
]
