"""Contract transformation — modify contracts programmatically."""

from __future__ import annotations

import copy
import re
from typing import Any, Callable

from pactship.models import (
    Contract,
    Header,
    HttpMethod,
    Interaction,
    Matcher,
    RequestSpec,
    ResponseSpec,
)


def add_header_to_all(
    contract: Contract, name: str, value: str, request: bool = True
) -> Contract:
    """Add a header to all interactions."""
    new_contract = _deep_copy_contract(contract)
    for interaction in new_contract.interactions:
        header = Header(name=name, value=value)
        if request:
            interaction.request.headers.append(header)
        else:
            interaction.response.headers.append(header)
    return new_contract


def rewrite_paths(
    contract: Contract,
    pattern: str,
    replacement: str,
) -> Contract:
    """Rewrite all request paths matching a pattern."""
    new_contract = _deep_copy_contract(contract)
    for interaction in new_contract.interactions:
        interaction.request.path = re.sub(
            pattern, replacement, interaction.request.path
        )
    return new_contract


def prefix_paths(contract: Contract, prefix: str) -> Contract:
    """Add a prefix to all request paths."""
    new_contract = _deep_copy_contract(contract)
    for interaction in new_contract.interactions:
        if not interaction.request.path.startswith(prefix):
            interaction.request.path = prefix + interaction.request.path
    return new_contract


def rename_service(
    contract: Contract,
    old_name: str,
    new_name: str,
) -> Contract:
    """Rename consumer or provider in a contract."""
    new_contract = _deep_copy_contract(contract)
    if new_contract.consumer == old_name:
        new_contract.consumer = new_name
    if new_contract.provider == old_name:
        new_contract.provider = new_name
    return new_contract


def add_tag_to_all(contract: Contract, tag: str) -> Contract:
    """Add a tag to all interactions."""
    new_contract = _deep_copy_contract(contract)
    for interaction in new_contract.interactions:
        if tag not in interaction.tags:
            interaction.tags.append(tag)
    return new_contract


def remove_tag_from_all(contract: Contract, tag: str) -> Contract:
    """Remove a tag from all interactions."""
    new_contract = _deep_copy_contract(contract)
    for interaction in new_contract.interactions:
        interaction.tags = [t for t in interaction.tags if t != tag]
    return new_contract


def transform_bodies(
    contract: Contract,
    transformer: Callable[[dict[str, Any] | list | None], dict[str, Any] | list | None],
    request: bool = False,
    response: bool = True,
) -> Contract:
    """Transform request/response bodies using a custom function."""
    new_contract = _deep_copy_contract(contract)
    for interaction in new_contract.interactions:
        if request and interaction.request.body is not None:
            interaction.request.body = transformer(interaction.request.body)
        if response and interaction.response.body is not None:
            interaction.response.body = transformer(interaction.response.body)
    return new_contract


def version_api(contract: Contract, version: str) -> Contract:
    """Add API versioning to all paths (e.g., /v2/users)."""
    prefix = f"/{version}" if not version.startswith("/") else version
    return prefix_paths(contract, prefix)


def strip_fields(
    contract: Contract, fields: list[str], from_response: bool = True
) -> Contract:
    """Remove specific fields from response/request bodies."""
    def stripper(body: Any) -> Any:
        if isinstance(body, dict):
            return {k: stripper(v) for k, v in body.items() if k not in fields}
        elif isinstance(body, list):
            return [stripper(item) for item in body]
        return body

    return transform_bodies(
        contract, stripper,
        request=not from_response,
        response=from_response,
    )


def _deep_copy_contract(contract: Contract) -> Contract:
    """Create a deep copy of a contract."""
    return Contract.from_dict(contract.to_dict())
