"""Verification hooks — run custom code before/after verification."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from pactship.models import Contract, Interaction, VerificationResult


HookFn = Callable[..., None]


@dataclass
class HookRegistry:
    """Registry for verification lifecycle hooks."""

    _before_all: list[HookFn] = field(default_factory=list)
    _after_all: list[HookFn] = field(default_factory=list)
    _before_each: list[HookFn] = field(default_factory=list)
    _after_each: list[HookFn] = field(default_factory=list)
    _on_error: list[HookFn] = field(default_factory=list)
    _state_handlers: dict[str, HookFn] = field(default_factory=dict)

    def before_all(self, fn: HookFn) -> HookFn:
        """Register a hook to run before all interactions."""
        self._before_all.append(fn)
        return fn

    def after_all(self, fn: HookFn) -> HookFn:
        """Register a hook to run after all interactions."""
        self._after_all.append(fn)
        return fn

    def before_each(self, fn: HookFn) -> HookFn:
        """Register a hook to run before each interaction."""
        self._before_each.append(fn)
        return fn

    def after_each(self, fn: HookFn) -> HookFn:
        """Register a hook to run after each interaction."""
        self._after_each.append(fn)
        return fn

    def on_error(self, fn: HookFn) -> HookFn:
        """Register a hook to run when verification fails."""
        self._on_error.append(fn)
        return fn

    def state(self, state_name: str) -> Callable[[HookFn], HookFn]:
        """Register a provider state handler."""
        def decorator(fn: HookFn) -> HookFn:
            self._state_handlers[state_name] = fn
            return fn
        return decorator

    def run_before_all(self, contract: Contract) -> list[str]:
        """Run all before_all hooks."""
        errors: list[str] = []
        for hook in self._before_all:
            try:
                hook(contract)
            except Exception as e:
                errors.append(f"before_all hook failed: {e}")
        return errors

    def run_after_all(self, contract: Contract, results: list[VerificationResult]) -> list[str]:
        """Run all after_all hooks."""
        errors: list[str] = []
        for hook in self._after_all:
            try:
                hook(contract, results)
            except Exception as e:
                errors.append(f"after_all hook failed: {e}")
        return errors

    def run_before_each(self, interaction: Interaction) -> list[str]:
        """Run all before_each hooks."""
        errors: list[str] = []
        for hook in self._before_each:
            try:
                hook(interaction)
            except Exception as e:
                errors.append(f"before_each hook failed: {e}")
        return errors

    def run_after_each(self, interaction: Interaction, result: VerificationResult) -> list[str]:
        """Run all after_each hooks."""
        errors: list[str] = []
        for hook in self._after_each:
            try:
                hook(interaction, result)
            except Exception as e:
                errors.append(f"after_each hook failed: {e}")
        return errors

    def run_on_error(self, interaction: Interaction, errors_list: list[str]) -> None:
        """Run all on_error hooks."""
        for hook in self._on_error:
            try:
                hook(interaction, errors_list)
            except Exception:
                pass

    def get_state_handler(self, state: str) -> HookFn | None:
        """Get a state handler by name."""
        return self._state_handlers.get(state)

    def clear(self) -> None:
        """Clear all registered hooks."""
        self._before_all.clear()
        self._after_all.clear()
        self._before_each.clear()
        self._after_each.clear()
        self._on_error.clear()
        self._state_handlers.clear()

    @property
    def hook_count(self) -> int:
        return (
            len(self._before_all) + len(self._after_all) +
            len(self._before_each) + len(self._after_each) +
            len(self._on_error) + len(self._state_handlers)
        )
