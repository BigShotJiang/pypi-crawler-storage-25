"""Contract statistics — analyze contracts for metrics and insights."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from pactship.models import Contract, HttpMethod, Interaction


@dataclass
class ContractStats:
    """Statistics about a contract."""

    consumer: str
    provider: str
    total_interactions: int = 0
    methods: dict[str, int] = field(default_factory=dict)
    status_codes: dict[int, int] = field(default_factory=dict)
    unique_paths: int = 0
    paths: list[str] = field(default_factory=list)
    tags: dict[str, int] = field(default_factory=dict)
    has_body_request: int = 0
    has_body_response: int = 0
    has_matchers: int = 0
    has_provider_states: int = 0
    avg_response_fields: float = 0.0
    max_response_depth: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "consumer": self.consumer,
            "provider": self.provider,
            "total_interactions": self.total_interactions,
            "methods": self.methods,
            "status_codes": {str(k): v for k, v in self.status_codes.items()},
            "unique_paths": self.unique_paths,
            "paths": self.paths,
            "tags": self.tags,
            "has_body_request": self.has_body_request,
            "has_body_response": self.has_body_response,
            "has_matchers": self.has_matchers,
            "has_provider_states": self.has_provider_states,
            "avg_response_fields": round(self.avg_response_fields, 2),
            "max_response_depth": self.max_response_depth,
        }


def analyze_contract(contract: Contract) -> ContractStats:
    """Compute statistics for a contract."""
    stats = ContractStats(
        consumer=contract.consumer,
        provider=contract.provider,
        total_interactions=len(contract.interactions),
    )

    method_counter: Counter[str] = Counter()
    status_counter: Counter[int] = Counter()
    tag_counter: Counter[str] = Counter()
    paths_set: set[str] = set()
    total_fields = 0
    bodies_with_fields = 0

    for interaction in contract.interactions:
        method_counter[interaction.request.method.value] += 1
        status_counter[interaction.response.status] += 1
        paths_set.add(interaction.request.path)

        for tag in interaction.tags:
            tag_counter[tag] += 1

        if interaction.request.body is not None:
            stats.has_body_request += 1

        if interaction.response.body is not None:
            stats.has_body_response += 1
            field_count = _count_fields(interaction.response.body)
            total_fields += field_count
            bodies_with_fields += 1
            depth = _measure_depth(interaction.response.body)
            if depth > stats.max_response_depth:
                stats.max_response_depth = depth

        if interaction.response.body_matchers:
            stats.has_matchers += 1

        if interaction.provider_states:
            stats.has_provider_states += 1

    stats.methods = dict(method_counter)
    stats.status_codes = dict(status_counter)
    stats.tags = dict(tag_counter)
    stats.unique_paths = len(paths_set)
    stats.paths = sorted(paths_set)

    if bodies_with_fields > 0:
        stats.avg_response_fields = total_fields / bodies_with_fields

    return stats


def analyze_contracts(contracts: list[Contract]) -> dict[str, Any]:
    """Compute aggregate statistics across multiple contracts."""
    all_stats = [analyze_contract(c) for c in contracts]

    total_interactions = sum(s.total_interactions for s in all_stats)
    all_methods: Counter[str] = Counter()
    all_statuses: Counter[int] = Counter()
    all_consumers: set[str] = set()
    all_providers: set[str] = set()

    for s in all_stats:
        all_methods.update(s.methods)
        all_statuses.update(s.status_codes)
        all_consumers.add(s.consumer)
        all_providers.add(s.provider)

    return {
        "total_contracts": len(contracts),
        "total_interactions": total_interactions,
        "unique_consumers": len(all_consumers),
        "unique_providers": len(all_providers),
        "consumers": sorted(all_consumers),
        "providers": sorted(all_providers),
        "methods": dict(all_methods),
        "status_codes": {str(k): v for k, v in all_statuses.items()},
        "contracts": [s.to_dict() for s in all_stats],
    }


def _count_fields(body: Any) -> int:
    """Count total fields in a body (recursive)."""
    if isinstance(body, dict):
        count = len(body)
        for v in body.values():
            count += _count_fields(v)
        return count
    elif isinstance(body, list) and body:
        return _count_fields(body[0])
    return 0


def _measure_depth(body: Any, current: int = 0) -> int:
    """Measure nesting depth of a body."""
    if isinstance(body, dict):
        if not body:
            return current + 1
        return max(_measure_depth(v, current + 1) for v in body.values())
    elif isinstance(body, list) and body:
        return _measure_depth(body[0], current + 1)
    return current + 1
