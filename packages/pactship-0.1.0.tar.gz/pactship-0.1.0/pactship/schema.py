"""JSON Schema generation from contracts and schema-based validation."""

from __future__ import annotations

from typing import Any

from pactship.models import Contract, Interaction, Matcher, MatcherType


def interaction_to_schema(interaction: Interaction) -> dict[str, Any]:
    """Generate JSON Schema for an interaction's response body."""
    if interaction.response.body is None:
        return {"type": "null"}

    schema = _value_to_schema(interaction.response.body)

    # Apply matchers to refine schema
    if interaction.response.body_matchers:
        _apply_matchers_to_schema(schema, interaction.response.body_matchers)

    return schema


def contract_to_schemas(contract: Contract) -> dict[str, dict[str, Any]]:
    """Generate JSON Schemas for all interactions in a contract."""
    schemas: dict[str, dict[str, Any]] = {}
    for interaction in contract.interactions:
        key = f"{interaction.request.method.value} {interaction.request.path}"
        schemas[key] = {
            "description": interaction.description,
            "request": _request_schema(interaction),
            "response": {
                "status": interaction.response.status,
                "body": interaction_to_schema(interaction),
            },
        }
    return schemas


def _request_schema(interaction: Interaction) -> dict[str, Any]:
    """Generate schema for request."""
    schema: dict[str, Any] = {
        "method": interaction.request.method.value,
        "path": interaction.request.path,
    }
    if interaction.request.body is not None:
        schema["body"] = _value_to_schema(interaction.request.body)
    if interaction.request.headers:
        schema["headers"] = {
            h.name: h.value for h in interaction.request.headers if h.value
        }
    if interaction.request.query_params:
        schema["query"] = {
            q.name: q.value for q in interaction.request.query_params if q.value
        }
    return schema


def _value_to_schema(value: Any) -> dict[str, Any]:
    """Convert a Python value to a JSON Schema."""
    if value is None:
        return {"type": "null"}
    elif isinstance(value, bool):
        return {"type": "boolean", "example": value}
    elif isinstance(value, int):
        return {"type": "integer", "example": value}
    elif isinstance(value, float):
        return {"type": "number", "example": value}
    elif isinstance(value, str):
        return {"type": "string", "example": value}
    elif isinstance(value, list):
        schema: dict[str, Any] = {"type": "array"}
        if value:
            schema["items"] = _value_to_schema(value[0])
        return schema
    elif isinstance(value, dict):
        properties: dict[str, Any] = {}
        required: list[str] = []
        for key, val in value.items():
            properties[key] = _value_to_schema(val)
            required.append(key)
        return {
            "type": "object",
            "properties": properties,
            "required": required,
        }
    return {}


def _apply_matchers_to_schema(
    schema: dict[str, Any], matchers: dict[str, Matcher]
) -> None:
    """Apply matcher constraints to schema."""
    for path, matcher in matchers.items():
        target = _resolve_schema_path(schema, path)
        if target is None:
            continue
        _apply_single_matcher(target, matcher)


def _resolve_schema_path(
    schema: dict[str, Any], path: str
) -> dict[str, Any] | None:
    """Resolve a dotted path in a JSON schema."""
    parts = path.replace("body.", "", 1).split(".") if path.startswith("body.") else path.split(".")
    current = schema

    for part in parts:
        if not part:
            continue
        if current.get("type") == "object" and "properties" in current:
            if part in current["properties"]:
                current = current["properties"][part]
            else:
                return None
        else:
            return None

    return current


def _apply_single_matcher(target: dict[str, Any], matcher: Matcher) -> None:
    """Apply a single matcher to a schema node."""
    match matcher.type:
        case MatcherType.REGEX:
            if matcher.pattern:
                target["pattern"] = matcher.pattern
        case MatcherType.RANGE:
            if matcher.min_val is not None:
                target["minimum"] = matcher.min_val
            if matcher.max_val is not None:
                target["maximum"] = matcher.max_val
        case MatcherType.ARRAY_LIKE:
            target["type"] = "array"
            if matcher.min_val is not None:
                target["minItems"] = matcher.min_val
        case MatcherType.ANY_OF:
            if isinstance(matcher.value, list):
                target["enum"] = matcher.value
        case MatcherType.NULLABLE:
            existing_type = target.get("type", "string")
            target["type"] = [existing_type, "null"]
        case MatcherType.UUID:
            target["type"] = "string"
            target["format"] = "uuid"
        case MatcherType.EMAIL:
            target["type"] = "string"
            target["format"] = "email"
        case MatcherType.ISO_DATE:
            target["type"] = "string"
            target["format"] = "date"
        case MatcherType.ISO_DATETIME:
            target["type"] = "string"
            target["format"] = "date-time"
        case MatcherType.INTEGER:
            target["type"] = "integer"
        case MatcherType.DECIMAL:
            target["type"] = "number"
        case MatcherType.BOOLEAN:
            target["type"] = "boolean"
        case MatcherType.STRING:
            target["type"] = "string"


def validate_body_against_schema(
    body: Any, schema: dict[str, Any]
) -> list[str]:
    """Simple schema validation (without jsonschema dependency for core)."""
    errors: list[str] = []
    _validate_node("root", body, schema, errors)
    return errors


def _validate_node(
    path: str, value: Any, schema: dict[str, Any], errors: list[str]
) -> None:
    """Validate a value against a schema node."""
    schema_type = schema.get("type")

    if schema_type is None:
        return

    # Handle nullable
    if isinstance(schema_type, list):
        if value is None and "null" in schema_type:
            return
        schema_type = [t for t in schema_type if t != "null"]
        if schema_type:
            schema_type = schema_type[0]

    if value is None and schema_type != "null":
        errors.append(f"{path}: expected {schema_type}, got null")
        return

    type_map = {
        "string": str,
        "integer": int,
        "number": (int, float),
        "boolean": bool,
        "array": list,
        "object": dict,
        "null": type(None),
    }

    expected_type = type_map.get(schema_type)
    # bool is subclass of int in Python — reject bools for integer/number types
    if schema_type in ("integer", "number") and isinstance(value, bool):
        errors.append(f"{path}: expected {schema_type}, got boolean")
        return

    if expected_type and not isinstance(value, expected_type):
        errors.append(f"{path}: expected {schema_type}, got {type(value).__name__}")
        return

    if schema_type == "object" and isinstance(value, dict):
        properties = schema.get("properties", {})
        required = schema.get("required", [])
        for key in required:
            if key not in value:
                errors.append(f"{path}.{key}: required field missing")
        for key, prop_schema in properties.items():
            if key in value:
                _validate_node(f"{path}.{key}", value[key], prop_schema, errors)

    elif schema_type == "array" and isinstance(value, list):
        items_schema = schema.get("items")
        min_items = schema.get("minItems", 0)
        if len(value) < min_items:
            errors.append(f"{path}: array too short ({len(value)} < {min_items})")
        if items_schema:
            for i, item in enumerate(value):
                _validate_node(f"{path}[{i}]", item, items_schema, errors)

    if "enum" in schema and value not in schema["enum"]:
        errors.append(f"{path}: value {value!r} not in enum {schema['enum']}")

    if "pattern" in schema and isinstance(value, str):
        import re
        if not re.match(schema["pattern"], value):
            errors.append(f"{path}: does not match pattern {schema['pattern']}")

    if "minimum" in schema and isinstance(value, (int, float)):
        if value < schema["minimum"]:
            errors.append(f"{path}: {value} < minimum {schema['minimum']}")

    if "maximum" in schema and isinstance(value, (int, float)):
        if value > schema["maximum"]:
            errors.append(f"{path}: {value} > maximum {schema['maximum']}")
