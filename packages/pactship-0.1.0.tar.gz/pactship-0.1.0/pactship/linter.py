"""Contract linter — enforce best practices and naming conventions."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from pactship.models import Contract, HttpMethod, Interaction


@dataclass
class LintIssue:
    """A single lint issue."""

    rule: str
    severity: str  # "error", "warning", "info"
    path: str
    message: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule": self.rule,
            "severity": self.severity,
            "path": self.path,
            "message": self.message,
        }


@dataclass
class LintResult:
    """Result of linting a contract."""

    issues: list[LintIssue] = field(default_factory=list)

    @property
    def error_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "error")

    @property
    def warning_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "warning")

    @property
    def passed(self) -> bool:
        return self.error_count == 0


# Lint rules

def lint_naming_conventions(contract: Contract) -> list[LintIssue]:
    """Check naming conventions for services and descriptions."""
    issues: list[LintIssue] = []

    # Service names should be kebab-case
    for name, label in [(contract.consumer, "consumer"), (contract.provider, "provider")]:
        if not re.match(r"^[a-z][a-z0-9-]*$", name):
            issues.append(LintIssue(
                rule="naming-convention",
                severity="warning",
                path=label,
                message=f"Service name '{name}' should be kebab-case (lowercase with hyphens)",
            ))

    return issues


def lint_path_conventions(contract: Contract) -> list[LintIssue]:
    """Check REST path conventions."""
    issues: list[LintIssue] = []

    for i, interaction in enumerate(contract.interactions):
        path = interaction.request.path
        prefix = f"interactions[{i}]"

        # Trailing slash
        if len(path) > 1 and path.endswith("/"):
            issues.append(LintIssue(
                rule="no-trailing-slash",
                severity="warning",
                path=f"{prefix}.request.path",
                message=f"Path '{path}' should not have trailing slash",
            ))

        # Uppercase in path
        path_clean = re.sub(r"\{[^}]+\}", "", path)
        if path_clean != path_clean.lower():
            issues.append(LintIssue(
                rule="lowercase-paths",
                severity="warning",
                path=f"{prefix}.request.path",
                message=f"Path '{path}' should be lowercase",
            ))

        # Underscores in path
        if "_" in path_clean:
            issues.append(LintIssue(
                rule="no-underscores",
                severity="info",
                path=f"{prefix}.request.path",
                message=f"Path '{path}' uses underscores, prefer hyphens",
            ))

    return issues


def lint_status_codes(contract: Contract) -> list[LintIssue]:
    """Check for appropriate status codes."""
    issues: list[LintIssue] = []

    for i, interaction in enumerate(contract.interactions):
        method = interaction.request.method
        status = interaction.response.status
        prefix = f"interactions[{i}]"

        # POST should return 201
        if method == HttpMethod.POST and status == 200:
            issues.append(LintIssue(
                rule="post-201",
                severity="info",
                path=f"{prefix}.response.status",
                message="POST requests typically return 201 Created, not 200",
            ))

        # DELETE should return 204
        if method == HttpMethod.DELETE and status == 200:
            issues.append(LintIssue(
                rule="delete-204",
                severity="info",
                path=f"{prefix}.response.status",
                message="DELETE requests typically return 204 No Content",
            ))

        # 204 with body
        if status == 204 and interaction.response.body is not None:
            issues.append(LintIssue(
                rule="204-no-body",
                severity="warning",
                path=f"{prefix}.response",
                message="204 No Content should not have a response body",
            ))

    return issues


def lint_missing_content_type(contract: Contract) -> list[LintIssue]:
    """Check for missing Content-Type headers on requests with bodies."""
    issues: list[LintIssue] = []

    for i, interaction in enumerate(contract.interactions):
        if interaction.request.body is not None:
            has_ct = any(
                h.name.lower() == "content-type"
                for h in interaction.request.headers
            )
            if not has_ct:
                issues.append(LintIssue(
                    rule="content-type-header",
                    severity="warning",
                    path=f"interactions[{i}].request.headers",
                    message="Request with body should have Content-Type header",
                ))

    return issues


def lint_response_body(contract: Contract) -> list[LintIssue]:
    """Check for empty or minimal response bodies."""
    issues: list[LintIssue] = []

    for i, interaction in enumerate(contract.interactions):
        status = interaction.response.status
        body = interaction.response.body

        # Success response with no body (except 204)
        if 200 <= status < 300 and status != 204 and body is None:
            if interaction.request.method != HttpMethod.DELETE:
                issues.append(LintIssue(
                    rule="response-body-expected",
                    severity="info",
                    path=f"interactions[{i}].response.body",
                    message=f"Success response ({status}) without body",
                ))

    return issues


ALL_RULES = [
    lint_naming_conventions,
    lint_path_conventions,
    lint_status_codes,
    lint_missing_content_type,
    lint_response_body,
]


def lint_contract(
    contract: Contract,
    rules: list[Any] | None = None,
) -> LintResult:
    """Run all lint rules on a contract."""
    result = LintResult()
    active_rules = rules or ALL_RULES

    for rule_fn in active_rules:
        issues = rule_fn(contract)
        result.issues.extend(issues)

    return result
