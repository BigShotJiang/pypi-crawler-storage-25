# Changelog

All notable changes to **genosys** are documented here.

---

## [0.1.0] — 2025-04-13

### Added
- `logger` — colored, account-indexed console logger compatible with `partial(logger, self)` pattern
- `load_data` — read lines from text files (private keys, proxies, wallets)
- `save_json` / `load_token_data` — async-safe JWT token storage
- `is_token_expired` — JWT expiry checker without signature validation
- `sleep` / `random_float` — randomized delay and amount helpers
- `print_banner` — Genoshide ASCII banner printer
- `gen_ua` / `get_or_create_session_ua` — random & persistent User-Agent generator
- `AsyncRequester` — async HTTP client with proxy support, retry, 401/429 handling
- `check_balance` — native coin or ERC-20 balance checker (accepts `wallet_address` or `privateKey`)
- `send_token` — send native coin to a recipient
- `transfer_erc20` — transfer ERC-20 tokens (USDC, USDT, WETH, …) between wallets
- `sign_message` — sign a text message for testnet login/auth flows
- `approve_token` — ERC-20 approve for router/DEX contracts
- `ERC20_ABI` — minimal built-in ABI (balanceOf, decimals, transfer, approve, allowance)
- `async_retry` / `sync_retry` — exponential backoff decorators with full jitter
- `RetryError` — exception raised when all retry attempts are exhausted
- `get_logger` — Python `logging.Logger` with colored console + optional RotatingFileHandler
- `setup_logging` — configure root logger with file rotation at startup
- `disable_console_logging` — strip console handlers (useful for Rich/curses dashboards)
- `info` / `warning` / `error` / `debug` / `critical` — global log shortcuts
- `run_batch_workers` — multi-process batch runner with loop support
