"""
Example 03 — Web3 Utilities
============================
Requires: pip install genosys[web3]

Shows: check_balance, check_balances_bulk, sign_message,
       send_token, transfer_erc20, approve_token
"""

from genosys.web3_utils import (
    check_balance,
    sign_message,
    send_token,
    transfer_erc20,
    approve_token,
    ERC20_ABI,
)

RPC_URL      = "https://rpc.example-testnet.xyz"
EXPLORER_URL = "https://explorer.example.com/tx/"
CHAIN_ID     = 12345
PRIVATE_KEY  = "0xYOUR_PRIVATE_KEY_HERE"
WALLET       = "0xYourWalletAddress"
RECIPIENT    = "0xRecipientAddress"

USDC_ADDRESS = "0xUSDC_CONTRACT_ADDRESS"
USDT_ADDRESS = "0xUSDT_CONTRACT_ADDRESS"


# ── Check balances ────────────────────────────────────────────────────────────

# Native coin balance (no token address needed)
eth_balance = check_balance({
    "provider":       RPC_URL,
    "wallet_address": WALLET,
})
print(f"ETH balance : {eth_balance}")

# ERC-20 balance (pass token contract address)
usdc_balance = check_balance({
    "provider":       RPC_URL,
    "wallet_address": WALLET,
    "address":        USDC_ADDRESS,
})
print(f"USDC balance: {usdc_balance}")


# ── Sign a message (login/auth) ───────────────────────────────────────────────

signature = sign_message(PRIVATE_KEY, "example-testnet")
print(f"Signature: {signature[:20]}...")

# Typical usage in a login flow:
# res = await req.post("/user/login", data={
#     "address":   WALLET,
#     "signature": signature,
# })


# ── Send native coin ──────────────────────────────────────────────────────────

result = send_token({
    "provider":          RPC_URL,
    "private_key":       PRIVATE_KEY,
    "recipient_address": RECIPIENT,
    "amount":            0.001,
    "chain_id":          CHAIN_ID,
    "explorer_url":      EXPLORER_URL,
})
print(result["message"])


# ── Transfer ERC-20 token ─────────────────────────────────────────────────────

result = transfer_erc20({
    "provider":          RPC_URL,
    "private_key":       PRIVATE_KEY,
    "token_address":     USDC_ADDRESS,
    "recipient_address": RECIPIENT,
    "amount":            5.0,          # 5 USDC (human units, not wei)
    "chain_id":          CHAIN_ID,
    "explorer_url":      EXPLORER_URL,
})
print(result["message"])


# ── Approve a router to spend tokens ─────────────────────────────────────────

from web3 import Web3

w3     = Web3(Web3.HTTPProvider(RPC_URL))
router = w3.eth.contract(address="0xROUTER_ADDRESS", abi=ERC20_ABI)

approve_token(
    token_address  = USDC_ADDRESS,
    amount         = 2**256 - 1,   # max approval
    wallet_address = WALLET,
    w3             = w3,
    router         = router,
    private_key    = PRIVATE_KEY,
)
print("Approval sent.")
