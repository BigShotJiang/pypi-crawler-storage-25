"""
Example 01 — Basic utilities
=============================
Shows: print_banner, load_data, sleep, random_float, is_token_expired
"""

from genosys import (
    print_banner,
    load_data,
    sleep,
    random_float,
    is_token_expired,
)

# Print startup banner
print_banner("My Testnet Bot", "Testnet Automation v1.0")

# Load wallet keys and proxies from text files
keys    = load_data("private_key.txt")   # ["0xabc...", "0xdef...", ...]
proxies = load_data("proxies.txt")       # ["http://user:pass@1.2.3.4:8080", ...]

print(f"Loaded {len(keys)} wallets, {len(proxies)} proxies")

# Random delay between actions (avoids detection)
sleep([2, 5])          # random between 2–5 seconds
sleep(3)               # exactly 3 seconds

# Random amount for swaps/sends
amount = random_float(0.01, 0.05, 4)    # e.g. 0.0312
print(f"Will send: {amount} ETH")

# Check if a JWT token is still valid
token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
result = is_token_expired(token)
print(f"Token expired: {result['isExpired']} | Expires: {result['expirationDate']}")
