"""
Example 02 — Complete Testnet Bot Template
==========================================
Shows: logger, AsyncRequester, user_agents, save_json, load_token_data,
       is_token_expired, retry, runner
"""

import asyncio
from functools import partial

from genosys import (
    logger,
    load_data,
    save_json,
    load_token_data,
    is_token_expired,
    print_banner,
    sleep,
    random_float,
    get_or_create_session_ua,
    AsyncRequester,
)
from genosys.retry import async_retry, RetryError


BASE_URL = "https://api.example-testnet.xyz"
RPC_URL  = "https://rpc.example-testnet.xyz"


class TestnetBot:
    def __init__(self, account_data: dict, account_index: int, proxy: str | None = None):
        self.account_index = account_index
        self.address    = account_data["address"]
        self.private_key = account_data["privateKey"]
        self.proxy      = proxy
        self.log        = partial(logger, self)

        # Persistent UA per wallet — same on every restart
        ua = get_or_create_session_ua(self.address)
        self.req = AsyncRequester(
            headers={
                "User-Agent":   ua,
                "Content-Type": "application/json",
                "Accept":       "*/*",
            },
            proxy=proxy,
            use_proxy=bool(proxy),
        )

    # ── Auth ──────────────────────────────────────────────────────────────

    async def get_token(self) -> str | None:
        """Return a valid JWT, refreshing if expired."""
        stored = load_token_data(self.address)
        token  = stored.get("jwt") if isinstance(stored, dict) else None

        if token and not is_token_expired(token)["isExpired"]:
            return token

        self.log("Token expired — logging in...", "warning")

        # Sign the login message with private key
        from genosys.web3_utils import sign_message
        signature = sign_message(self.private_key, "example-testnet")

        res = await self.req.post(
            f"{BASE_URL}/user/login",
            data={"address": self.address, "signature": signature},
            is_auth=True,
        )
        if not res["success"]:
            self.log(f"Login failed: {res['error']}", "error")
            return None

        jwt = res["data"].get("jwt")
        await save_json(self.address, {"jwt": jwt})
        self.req.token = jwt
        self.log("Login successful!", "success")
        return jwt

    # ── Actions ───────────────────────────────────────────────────────────

    @async_retry(max_attempts=3, base_delay=2.0)
    async def checkin(self):
        res = await self.req.get(f"{BASE_URL}/checkin?address={self.address}")
        if res["success"]:
            self.log("Check-in successful!", "success")
        else:
            self.log(f"Check-in failed: {res}", "warning")

    @async_retry(max_attempts=3, base_delay=2.0)
    async def claim_faucet(self):
        res = await self.req.post(f"{BASE_URL}/faucet/claim",
                                  data={"address": self.address})
        if res["success"]:
            self.log("Faucet claimed!", "success")
        else:
            self.log(f"Faucet not available: {res}", "info")

    async def send(self):
        from genosys.web3_utils import check_balance, send_token

        balance = check_balance({"provider": RPC_URL, "wallet_address": self.address})
        self.log(f"Balance: {balance} ETH", "info")

        all_wallets = load_data("wallets.txt")
        recipients  = [w for w in all_wallets if w.lower() != self.address.lower()]
        if not recipients:
            return self.log("No recipients in wallets.txt", "warning")

        import random
        recipient = random.choice(recipients)
        amount    = random_float(0.001, 0.005, 4)

        result = send_token({
            "provider":          RPC_URL,
            "private_key":       self.private_key,
            "recipient_address": recipient,
            "amount":            amount,
            "chain_id":          12345,
            "explorer_url":      "https://explorer.example.com/tx/",
        })
        level = "success" if result["success"] else "error"
        self.log(result["message"], level)

    # ── Main loop ─────────────────────────────────────────────────────────

    async def run(self):
        token = await self.get_token()
        if not token:
            return

        self.req.token = token

        try:
            await self.checkin()
            sleep([1, 3])

            await self.claim_faucet()
            sleep([1, 3])

            await self.send()

        except RetryError as e:
            self.log(f"Action failed after {e.attempts} attempts: {e.last_exception}", "error")

        self.log("All actions complete.", "success")


# ── Entry point ───────────────────────────────────────────────────────────────

async def run_account(account_data: dict, account_index: int, proxy: str | None):
    bot = TestnetBot(account_data, account_index, proxy)
    await bot.run()


async def main():
    print_banner("Example Testnet Bot", "Automation Script")

    private_keys = load_data("private_key.txt")
    proxies      = load_data("proxies.txt")
    use_proxy    = bool(proxies)

    from genosys.runner import run_batch_workers
    await run_batch_workers(
        worker_module       = "__main__",
        worker_name         = "run_account",
        private_keys        = private_keys,
        proxies             = proxies,
        max_workers         = 10,
        loop_interval_minutes = 8,
        use_proxy           = use_proxy,
    )


if __name__ == "__main__":
    asyncio.run(main())
