# genosys

Python toolkit for blockchain testnet & automation bots.

All common utilities — logger, async HTTP requester, Web3 helpers, retry decorators, and a multi-process batch runner — in one installable package.

```bash
pip install genosys
pip install genosys[web3]   # includes web3, eth-account
```

---

## Quick start

```python
from genosys import logger, load_data, sleep, print_banner, AsyncRequester
from genosys import gen_ua, is_token_expired, save_json
from genosys.log import info, warning, error
from genosys.retry import async_retry, RetryError
from genosys.web3_utils import check_balance, sign_message, send_token, transfer_erc20
from genosys.runner import run_batch_workers
```

---

## Modules

### `logger` — colored account logger

```python
from functools import partial
from genosys import logger

class MyBot:
    def __init__(self, account_index):
        self.account_index = account_index
        self.log = partial(logger, self)

bot = MyBot(1)
bot.log("Starting...", "info")
bot.log("Done!", "success")
bot.log("TX failed.", "error")
```

Log types: `info` · `success` · `warn` · `error` · `debug` · `failed` · `critical`

---

### `utils` — file loading, JWT, sleep, banner

```python
from genosys import load_data, save_json, load_token_data
from genosys import is_token_expired, sleep, random_float, print_banner

keys    = load_data("private_key.txt")
proxies = load_data("proxies.txt")

sleep([2, 5])                    # random 2–5 s
amount = random_float(0.01, 0.1, 4)

result = is_token_expired(jwt_token)
# {"isExpired": False, "expirationDate": "2025-12-01 10:00:00"}

await save_json("0xABCD...", {"jwt": token})
data = load_token_data("0xABCD...")

print_banner("My Bot", "Testnet Automation")
```

---

### `user_agents` — random & persistent UA

```python
from genosys import gen_ua, get_or_create_session_ua

ua = gen_ua()                                   # random every call
ua = get_or_create_session_ua("0xABCD...")      # same UA for this wallet across restarts
```

---

### `AsyncRequester` — async HTTP client

```python
from genosys import AsyncRequester

req = AsyncRequester(
    headers={"Content-Type": "application/json"},
    proxy="http://user:pass@1.2.3.4:8080",
    use_proxy=True,
)
req.token = "my-jwt-token"

res = await req.get("https://api.example.com/profile?address=0x...")
res = await req.post("https://api.example.com/checkin", data={"address": "0x..."})
# {"success": bool, "status": int, "data": ..., "error": ...}
```

---

### `retry` — exponential backoff decorators

```python
from genosys.retry import async_retry, sync_retry, RetryError

@async_retry(max_attempts=4, base_delay=1.0, max_delay=30.0)
async def call_api():
    return await req.get("/endpoint")

@sync_retry(max_attempts=3, exceptions=(ConnectionError,))
def check_rpc():
    return web3.is_connected()

try:
    await call_api()
except RetryError as e:
    print(f"Failed after {e.attempts} attempts: {e.last_exception}")
```

---

### `log` — file logger with rotation

```python
from genosys.log import info, warning, error, debug, critical

info("Bot started")
warning("Proxy timeout — retrying...")
error("TX rejected: %s", err_msg)
```

```python
# Per-module logger with file output
from genosys.log import get_logger, setup_logging

setup_logging(log_file="mybot.log")   # once at startup
log = get_logger(__name__)
log.info("Account %s started", address)
```

---

### `web3_utils` — on-chain helpers *(requires `genosys[web3]`)*

```python
from genosys.web3_utils import (
    check_balance, sign_message, send_token, transfer_erc20, approve_token
)

# Check balance (native coin or ERC-20)
bal = check_balance({"provider": rpc, "wallet_address": "0x..."})
bal = check_balance({"provider": rpc, "wallet_address": "0x...", "address": USDC_ADDRESS})

# Sign message for login/auth
sig = sign_message(private_key, "testnet-login")

# Send native coin
result = send_token({
    "provider": rpc, "private_key": pk,
    "recipient_address": "0x...", "amount": 0.001,
    "chain_id": 12345, "explorer_url": "https://explorer.example.com/tx/",
})

# Transfer ERC-20 token
result = transfer_erc20({
    "provider": rpc, "private_key": pk,
    "token_address": USDC_ADDRESS,
    "recipient_address": "0x...", "amount": 5.0,
    "chain_id": 12345,
})
```

---

### `runner` — multi-process batch runner

```python
# mybot/worker.py
async def run_account(account_data, account_index, proxy):
    bot = MyBot(account_data, account_index, proxy)
    await bot.run()
```

```python
# main.py
import asyncio
from genosys import load_data, print_banner
from genosys.runner import run_batch_workers

async def main():
    print_banner("My Bot", "Testnet Automation")
    await run_batch_workers(
        worker_module         = "mybot.worker",
        worker_name           = "run_account",
        private_keys          = load_data("private_key.txt"),
        proxies               = load_data("proxies.txt"),
        max_workers           = 10,
        loop_interval_minutes = 8,
        use_proxy             = True,
    )

asyncio.run(main())
```

---

## Install for development

```bash
git clone https://github.com/genoshide/genosys
cd genosys/pypi
make install       # editable install with all extras
make test          # run tests
make build         # build wheel + sdist
make publish-test  # upload to TestPyPI first
make publish       # upload to PyPI
```

---

## License

MIT © [Brandy Good (genoshide)](https://github.com/genoshide)
