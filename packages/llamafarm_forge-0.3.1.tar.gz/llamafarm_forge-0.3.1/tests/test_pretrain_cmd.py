"""Tests for forge pretrain command — no GPU, no API key required."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml
from click.testing import CliRunner

from forge.cli import main


def _make_project(tmp_path: Path) -> Path:
    """Scaffold a minimal forge project with pretrain config."""
    (tmp_path / "dataset").mkdir()
    (tmp_path / "output").mkdir()
    corpus_dir = tmp_path / "dataset" / "corpus"
    corpus_dir.mkdir()
    (corpus_dir / "doc.txt").write_text("Domain knowledge: X is defined as Y. " * 20)

    cfg = {
        "name": "test-pretrain",
        "model": {"base": "fake/model", "max_seq_len": 128, "load_in_4bit": False},
        "lora": {
            "r": 4, "alpha": 4, "dropout": 0.0,
            "target_modules": ["q_proj", "v_proj"],
        },
        "training": {
            "epochs_min": 1, "epochs_max": 1, "batch_size": 1,
            "gradient_accumulation_steps": 1, "learning_rate": 1e-4,
            "warmup_ratio": 0.05, "weight_decay": 0.0, "seed": 42,
        },
        "eval": {"target_accuracy": 0.95, "scorer": "exact",
                 "max_new_tokens": 16, "forbidden_commands": []},
        "dataset": {"canonical": "dataset/canonical.jsonl",
                    "gold": "dataset/gold.jsonl"},
        "compute": {"device": "cpu"},
        "pretrain": {
            "corpus_dir": "dataset/corpus",
            "epochs": 1,
            "learning_rate": 2e-5,
            "batch_size": 1,
            "gradient_accumulation_steps": 1,
            "max_seq_len": 128,
            "output_adapter": "output/pretrain_adapter",
        },
    }
    (tmp_path / "forge.yaml").write_text(yaml.dump(cfg))
    (tmp_path / "dataset" / "canonical.jsonl").write_text("")
    (tmp_path / "dataset" / "gold.jsonl").write_text("")
    return tmp_path


def _mock_unsloth(model_mock=None, tokenizer_mock=None):
    """Return a context-manager patch for unsloth.FastLanguageModel."""
    if model_mock is None:
        model_mock = MagicMock()
        model_mock.device = "cpu"
        # save_pretrained_merged must not raise
        model_mock.save_pretrained_merged = MagicMock()
        model_mock.save_pretrained = MagicMock()
    if tokenizer_mock is None:
        tokenizer_mock = MagicMock()
        tokenizer_mock.eos_token_id = 0
        tokenizer_mock.encode = lambda text, **kw: list(range(min(len(text.split()), 50)))
        tokenizer_mock.decode = lambda ids, **kw: " ".join(f"w{i}" for i in ids)
        tokenizer_mock.save_pretrained = MagicMock()
    return model_mock, tokenizer_mock


def _patch_pretrain_gpu(model_mock, tok_mock, mock_trainer):
    """
    Patch GPU imports used inside forge.commands.pretrain's Click callback.
    These are imported lazily (inside the function), so we inject them via sys.modules.
    We also patch build_corpus_dataset directly to avoid needing the datasets package.
    """
    import sys

    mock_fl = MagicMock()
    mock_fl.from_pretrained.return_value = (model_mock, tok_mock)
    mock_fl.get_peft_model.return_value = model_mock

    mock_unsloth = MagicMock()
    mock_unsloth.FastLanguageModel = mock_fl

    mock_trl = MagicMock()
    mock_trl.SFTTrainer.return_value = mock_trainer
    mock_trl.SFTConfig.return_value = MagicMock()

    mock_torch = MagicMock()
    mock_torch.cuda.is_available.return_value = False
    mock_torch.cuda.is_bf16_supported.return_value = False

    mock_ds = MagicMock()
    mock_ds.__len__ = lambda self: 5
    mock_corpus_fn = MagicMock(return_value=mock_ds)

    patches = [
        patch.dict(sys.modules, {
            "unsloth": mock_unsloth,
            "trl": mock_trl,
            "torch": mock_torch,
        }),
        patch("forge.commands.pretrain.build_corpus_dataset", mock_corpus_fn),
    ]
    return patches, mock_fl, mock_corpus_fn


def test_pretrain_writes_results_json(tmp_path):
    project = _make_project(tmp_path)
    model_mock, tok_mock = _mock_unsloth()
    mock_trainer = MagicMock()
    mock_trainer.state.log_history = [{"loss": 0.42}]

    patches, mock_fl, _ = _patch_pretrain_gpu(model_mock, tok_mock, mock_trainer)
    with patches[0], patches[1]:
        runner = CliRunner()
        result = runner.invoke(main, ["pretrain", "--project", str(project), "--no-merge"])

    assert result.exit_code == 0, result.output
    results_file = project / "output" / "pretrain_results.json"
    assert results_file.exists(), f"Missing results file. Output:\n{result.output}"
    data = json.loads(results_file.read_text())
    assert data["model"] == "fake/model"
    assert data["epochs"] == 1
    assert "corpus_chunks" in data


def test_pretrain_merge_calls_save_pretrained_merged(tmp_path):
    project = _make_project(tmp_path)
    model_mock, tok_mock = _mock_unsloth()
    mock_trainer = MagicMock()
    mock_trainer.state.log_history = [{"loss": 0.3}]

    patches, _, _ = _patch_pretrain_gpu(model_mock, tok_mock, mock_trainer)
    with patches[0], patches[1]:
        runner = CliRunner()
        result = runner.invoke(main, ["pretrain", "--project", str(project), "--merge"])

    assert result.exit_code == 0, result.output
    model_mock.save_pretrained_merged.assert_called_once()
    assert "merged_16bit" in str(model_mock.save_pretrained_merged.call_args)


def test_pretrain_no_merge_skips_save_merged(tmp_path):
    project = _make_project(tmp_path)
    model_mock, tok_mock = _mock_unsloth()
    mock_trainer = MagicMock()
    mock_trainer.state.log_history = []

    patches, _, _ = _patch_pretrain_gpu(model_mock, tok_mock, mock_trainer)
    with patches[0], patches[1]:
        runner = CliRunner()
        result = runner.invoke(main, ["pretrain", "--project", str(project), "--no-merge"])

    assert result.exit_code == 0, result.output
    model_mock.save_pretrained_merged.assert_not_called()


def test_pretrain_corpus_override(tmp_path):
    """--corpus flag overrides forge.yaml corpus_dir."""
    project = _make_project(tmp_path)
    custom_corpus = tmp_path / "my_corpus"
    custom_corpus.mkdir()
    (custom_corpus / "data.txt").write_text("Custom corpus content " * 10)

    model_mock, tok_mock = _mock_unsloth()
    mock_trainer = MagicMock()
    mock_trainer.state.log_history = []

    patches, _, _ = _patch_pretrain_gpu(model_mock, tok_mock, mock_trainer)
    with patches[0], patches[1]:
        runner = CliRunner()
        result = runner.invoke(main, [
            "pretrain", "--project", str(project),
            "--corpus", str(custom_corpus), "--no-merge",
        ])

    assert result.exit_code == 0, result.output
    data = json.loads((project / "output" / "pretrain_results.json").read_text())
    assert "my_corpus" in data["corpus_dir"]


def test_pretrain_missing_corpus_fails(tmp_path):
    """build_corpus_dataset (real, not mocked) raises FileNotFoundError for missing corpus."""
    project = _make_project(tmp_path)
    model_mock, tok_mock = _mock_unsloth()
    mock_trainer = MagicMock()
    mock_trainer.state.log_history = []

    # Patch GPU deps but NOT build_corpus_dataset — let the real one run so the
    # missing-dir check fires before the model even loads.
    import sys
    mock_fl = MagicMock()
    mock_fl.from_pretrained.return_value = (model_mock, tok_mock)
    mock_fl.get_peft_model.return_value = model_mock
    mock_unsloth = MagicMock()
    mock_unsloth.FastLanguageModel = mock_fl
    mock_trl = MagicMock()
    mock_torch = MagicMock()
    mock_torch.cuda.is_available.return_value = False
    mock_torch.cuda.is_bf16_supported.return_value = False

    with patch.dict(sys.modules, {"unsloth": mock_unsloth, "trl": mock_trl, "torch": mock_torch}):
        runner = CliRunner()
        result = runner.invoke(main, [
            "pretrain", "--project", str(project),
            "--corpus", str(tmp_path / "nonexistent"), "--no-merge",
        ])

    assert result.exit_code != 0 or "not found" in result.output.lower() or "Error" in result.output
