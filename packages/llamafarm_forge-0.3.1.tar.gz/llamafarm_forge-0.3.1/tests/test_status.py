"""Tests for forge.commands.status — renders on empty output/ without crashing."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml
from click.testing import CliRunner

from forge.commands.status import status


def make_project(tmp_path: Path, name: str = "test-proj") -> Path:
    """Create a minimal forge project scaffold."""
    project_dir = tmp_path / name
    project_dir.mkdir()
    (project_dir / "dataset").mkdir()
    (project_dir / "output").mkdir()
    cfg = {
        "name": name,
        "eval": {"target_accuracy": 0.95},
        "model": {"base": "test/model"},
        "dataset": {
            "canonical": "dataset/canonical.jsonl",
            "gold": "dataset/gold.jsonl",
        },
    }
    (project_dir / "forge.yaml").write_text(yaml.dump(cfg))
    return project_dir


def make_task_yaml_project(tmp_path: Path, name: str = "task-proj") -> Path:
    """Create a llamadrone-style project with configs/task.yaml only."""
    project_dir = tmp_path / name
    project_dir.mkdir()
    (project_dir / "configs").mkdir()
    (project_dir / "src" / "dataset").mkdir(parents=True)
    (project_dir / "output").mkdir()
    cfg = {
        "model": {"base": "unsloth/functiongemma-270m-it", "max_seq_len": 2048,
                  "load_in_4bit": True},
        "dataset": {"train": "src/dataset/canonical_v14.jsonl",
                    "eval": "src/dataset/gold_v5.jsonl"},
        "eval": {"accuracy_target": 0.95, "max_new_tokens": 256,
                 "forbidden_commands": [], "safety_threshold": 0},
        "promotion": {"hf_repo": "llama-farm/test-v1"},
        "flywheel": {"max_iterations": 10, "augment_per_failure": 20,
                     "datagen_model": "claude-haiku-4-5-20251001"},
        "gpu": {"device": 0},
    }
    (project_dir / "configs" / "task.yaml").write_text(yaml.dump(cfg))
    return project_dir


class TestStatusCommand:
    def setup_method(self):
        self.runner = CliRunner()

    def test_runs_without_crash_on_empty_output(self, tmp_path):
        """Most important: status should not raise on a brand-new project."""
        project_dir = make_project(tmp_path)
        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0, result.output

    def test_shows_no_eval_message_when_empty(self, tmp_path):
        project_dir = make_project(tmp_path)
        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0
        assert "No eval results" in result.output

    def test_shows_best_score_when_present(self, tmp_path):
        project_dir = make_project(tmp_path)
        best = {
            "accuracy": 0.876,
            "correct": 234,
            "total": 267,
            "safety_violations": 0,
            "timestamp": "20260323_120000",
        }
        (project_dir / "output" / "best_score.json").write_text(json.dumps(best))
        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0, result.output
        assert "87.6%" in result.output

    def test_shows_project_name(self, tmp_path):
        project_dir = make_project(tmp_path, name="drone-router")
        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0, result.output
        assert "drone-router" in result.output

    def test_shows_target_accuracy(self, tmp_path):
        project_dir = make_project(tmp_path)
        best = {"accuracy": 0.876, "correct": 234, "total": 267, "safety_violations": 0}
        (project_dir / "output" / "best_score.json").write_text(json.dumps(best))
        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0, result.output
        assert "95%" in result.output  # target from forge.yaml

    def test_shows_iteration_table_when_manifest_present(self, tmp_path):
        project_dir = make_project(tmp_path)
        rows = [
            {"iteration": 1, "train_file": "dataset/canonical.jsonl",
             "train_examples": 500, "loss": 0.345, "epochs": 2, "train_min": 12},
            {"iteration": 2, "train_file": "dataset/canonical.jsonl",
             "train_examples": 700, "loss": 0.212, "epochs": 3, "train_min": 18},
        ]
        manifest = project_dir / "output" / "flywheel_manifest.jsonl"
        manifest.write_text("\n".join(json.dumps(r) for r in rows))

        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0, result.output
        # Table header should appear
        assert "Iter" in result.output or "iteration" in result.output.lower()

    def test_no_forge_yaml_exits_nonzero(self, tmp_path):
        result = self.runner.invoke(status, ["--project", str(tmp_path)])
        assert result.exit_code != 0

    def test_versioned_adapters_shown(self, tmp_path):
        project_dir = make_project(tmp_path)
        output_dir = project_dir / "output"
        (output_dir / "adapter_iter1_20260323").mkdir()
        (output_dir / "adapter_iter2_20260324").mkdir()
        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0, result.output
        assert "adapter" in result.output.lower() or "Versioned" in result.output

    def test_shows_config_source_forge_yaml(self, tmp_path):
        project_dir = make_project(tmp_path)
        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0, result.output
        assert "forge.yaml" in result.output

    def test_task_yaml_project_runs_without_crash(self, tmp_path):
        """Status should work on a llamadrone-style project with configs/task.yaml."""
        project_dir = make_task_yaml_project(tmp_path)
        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0, result.output

    def test_task_yaml_shows_config_source(self, tmp_path):
        project_dir = make_task_yaml_project(tmp_path)
        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0, result.output
        assert "task.yaml" in result.output

    def test_dataset_example_count_shown(self, tmp_path):
        """Status shows example counts when dataset files exist."""
        project_dir = make_project(tmp_path)
        canon = project_dir / "dataset" / "canonical.jsonl"
        gold = project_dir / "dataset" / "gold.jsonl"
        canon.write_text('{"input": "test"}\n' * 100)
        gold.write_text('{"input": "test"}\n' * 50)
        result = self.runner.invoke(status, ["--project", str(project_dir)])
        assert result.exit_code == 0, result.output
        assert "100" in result.output  # canonical count
        assert "50" in result.output   # gold count
