"""Unit tests for flywheel git-per-iteration, forge.yaml write-back, and background additions."""
from __future__ import annotations

import importlib
import json
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest
import yaml


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_project(tmp_path: Path) -> tuple[Path, dict]:
    """Create a minimal forge project and return (project_dir, cfg)."""
    (tmp_path / "dataset").mkdir()
    (tmp_path / "output").mkdir()

    cfg = {
        "name": "test-git-flywheel",
        "model": {"base": "fake/model", "max_seq_len": 128, "load_in_4bit": False},
        "lora": {"r": 4, "alpha": 4, "dropout": 0.0},
        "training": {
            "epochs_min": 1,
            "epochs_max": 3,
            "batch_size": 1,
            "gradient_accumulation_steps": 1,
            "learning_rate": 5e-5,
            "warmup_ratio": 0.1,
            "weight_decay": 0.0,
            "seed": 42,
        },
        "eval": {"target_accuracy": 0.95, "scorer": "exact", "max_new_tokens": 16,
                 "forbidden_commands": []},
        "dataset": {"canonical": "dataset/canonical.jsonl", "gold": "dataset/gold.jsonl"},
        "compute": {"device": "cpu"},
        "flywheel": {
            "max_iterations": 5,
            "augment_per_failure": 2,
            "datagen_model": "claude-3-5-haiku-20241022",
            "planner_model": "claude-3-5-haiku-20241022",
        },
    }
    (tmp_path / "forge.yaml").write_text(yaml.dump(cfg))
    (tmp_path / "system_prompt.md").write_text("You are a test assistant.")
    (tmp_path / "mission.md").write_text("Answer math questions as JSON.")
    (tmp_path / "BACKGROUND.md").write_text("# Background\n\nTest background content.\n")

    examples = [
        {"messages": [{"role": "user", "content": "1+1?"},
                      {"role": "assistant", "content": '{"answer":2}'}]}
    ]
    (tmp_path / "dataset" / "canonical.jsonl").write_text(
        "\n".join(json.dumps(e) for e in examples)
    )
    (tmp_path / "dataset" / "gold.jsonl").write_text(
        "\n".join(json.dumps(e) for e in examples)
    )
    (tmp_path / "output" / "adapter").mkdir(parents=True, exist_ok=True)

    return tmp_path, cfg


def _fake_train_result(project_dir: Path) -> dict:
    return {
        "adapter_dir": str(project_dir / "output" / "adapter"),
        "final_loss": 0.1,
        "epochs_run": 1,
        "train_examples": 10,
    }


def _fake_eval_result(accuracy: float = 0.60) -> dict:
    failures = [
        {
            "index": 0,
            "category": "arithmetic",
            "input": "What is 2+2?",
            "expected": '{"answer":4}',
            "actual": "4",
            "error": "mismatch",
        }
    ]
    return {
        "accuracy": accuracy,
        "correct": int(accuracy * 10),
        "total": 10,
        "safety_violations": 0,
        "passed": accuracy >= 0.95,
        "per_category": {},
        "failures": failures,
        "elapsed_min": 0.0,
    }


def _default_plan(**kwargs) -> dict:
    base = {
        "hypothesis": "Test hypothesis",
        "rationale": "Test rationale",
        "config_patches": {},
        "forge_yaml_patches": {},
        "background_additions": "",
        "augment_focus": "",
        "augment_n": 2,
        "expected_improvement_pp": 1.0,
    }
    base.update(kwargs)
    return base


# ── Test 1: git commit called after iteration ──────────────────────────────────

def test_git_commit_called_after_iteration(tmp_path):
    """After each flywheel iteration, git commit is called with correct message format."""
    project_dir, cfg = _make_project(tmp_path)

    import forge.commands.flywheel as fw_mod
    importlib.reload(fw_mod)

    # git rev-parse returns 0 (is a repo), then add + commit
    def fake_subprocess_run(cmd, **kwargs):
        result = MagicMock()
        result.returncode = 0
        return result

    with patch("forge.commands.flywheel.subprocess.run", side_effect=fake_subprocess_run) as mock_sub, \
         patch("forge.core.trainer.run", return_value=_fake_train_result(project_dir)), \
         patch("forge.core.eval_runner.run", return_value=_fake_eval_result(0.60)), \
         patch("forge.core.augmentor.run", return_value=1), \
         patch("forge.core.experiment_planner.plan", return_value=_default_plan(
             hypothesis="Test hypothesis for commit"
         )), \
         patch("forge.core.planner.update_plan"), \
         patch("forge.core.context.update"):

        importlib.reload(fw_mod)
        fw_mod._run_flywheel(project_dir, cfg, max_iters=1)

    # Find commit calls
    commit_calls = [
        c for c in mock_sub.call_args_list
        if c.args and len(c.args[0]) > 1 and c.args[0][0] == "git" and "commit" in c.args[0]
    ]
    assert len(commit_calls) >= 1, "Expected at least one git commit call"

    # Check message format: "forge iter N: XX.X% — <hypothesis>"
    commit_cmd = commit_calls[0].args[0]
    msg_idx = commit_cmd.index("-m") + 1
    msg = commit_cmd[msg_idx]
    assert msg.startswith("forge iter 1:"), f"Unexpected commit message: {msg!r}"
    assert "%" in msg, f"Expected accuracy % in message: {msg!r}"


# ── Test 2: forge.yaml patches applied ────────────────────────────────────────

def test_forge_yaml_patches_applied(tmp_path):
    """When plan includes forge_yaml_patches, forge.yaml is updated on disk."""
    project_dir, cfg = _make_project(tmp_path)

    import forge.commands.flywheel as fw_mod
    importlib.reload(fw_mod)

    patches = {"training": {"learning_rate": 1e-5}, "lora": {"r": 64}}

    # Confirm original values
    original = yaml.safe_load((project_dir / "forge.yaml").read_text())
    assert original["lora"]["r"] == 4
    assert original["training"]["learning_rate"] == pytest.approx(5e-5)

    with patch("forge.commands.flywheel.subprocess.run", return_value=MagicMock(returncode=0)), \
         patch("forge.core.trainer.run", return_value=_fake_train_result(project_dir)), \
         patch("forge.core.eval_runner.run", return_value=_fake_eval_result(0.60)), \
         patch("forge.core.augmentor.run", return_value=1), \
         patch("forge.core.experiment_planner.plan", return_value=_default_plan(
             forge_yaml_patches=patches
         )), \
         patch("forge.core.planner.update_plan"), \
         patch("forge.core.context.update"):

        importlib.reload(fw_mod)
        fw_mod._run_flywheel(project_dir, cfg, max_iters=1)

    updated = yaml.safe_load((project_dir / "forge.yaml").read_text())
    assert updated["lora"]["r"] == 64, f"Expected r=64, got {updated['lora']['r']}"
    assert updated["training"]["learning_rate"] == pytest.approx(1e-5), (
        f"Expected lr=1e-5, got {updated['training']['learning_rate']}"
    )
    # Other fields preserved
    assert updated["training"]["epochs_min"] == 1
    assert updated["name"] == "test-git-flywheel"


# ── Test 3: background additions appended ─────────────────────────────────────

def test_background_additions_appended(tmp_path):
    """When plan includes background_additions, BACKGROUND.md gets a new section."""
    project_dir, cfg = _make_project(tmp_path)

    import forge.commands.flywheel as fw_mod
    importlib.reload(fw_mod)

    new_insight = "Model consistently fails on negative numbers — add negative examples."

    with patch("forge.commands.flywheel.subprocess.run", return_value=MagicMock(returncode=0)), \
         patch("forge.core.trainer.run", return_value=_fake_train_result(project_dir)), \
         patch("forge.core.eval_runner.run", return_value=_fake_eval_result(0.60)), \
         patch("forge.core.augmentor.run", return_value=1), \
         patch("forge.core.experiment_planner.plan", return_value=_default_plan(
             background_additions=new_insight
         )), \
         patch("forge.core.planner.update_plan"), \
         patch("forge.core.context.update"):

        importlib.reload(fw_mod)
        fw_mod._run_flywheel(project_dir, cfg, max_iters=1)

    background_text = (project_dir / "BACKGROUND.md").read_text()
    assert new_insight in background_text, (
        f"Expected new insight in BACKGROUND.md.\n"
        f"Looking for: {new_insight!r}\n"
        f"Got: {background_text!r}"
    )
    assert "## Agent-Discovered Patterns" in background_text


# ── Test 4: git commit skipped if not a git repo ──────────────────────────────

def test_git_commit_skipped_if_no_repo(tmp_path):
    """No crash and no git commit when project_dir is not a git repo."""
    project_dir, _ = _make_project(tmp_path)

    import forge.commands.flywheel as fw_mod
    importlib.reload(fw_mod)

    # Simulate: git rev-parse fails (not a repo), but add/commit must NOT be called
    call_log = []

    def fake_subprocess_run(cmd, **kwargs):
        call_log.append(cmd)
        result = MagicMock()
        # git rev-parse returns non-zero (not a repo)
        if "rev-parse" in cmd:
            result.returncode = 128
        else:
            result.returncode = 0
        return result

    with patch("forge.commands.flywheel.subprocess.run", side_effect=fake_subprocess_run):
        # Call _git_commit_iteration directly
        fw_mod._git_commit_iteration(project_dir, 1, 0.75, "test hypothesis")

    # rev-parse should be called, but add/commit should NOT
    git_cmds = [c for c in call_log if c[0] == "git"]
    rev_parse_calls = [c for c in git_cmds if "rev-parse" in c]
    add_calls = [c for c in git_cmds if "add" in c]
    commit_calls = [c for c in git_cmds if "commit" in c]

    assert len(rev_parse_calls) == 1, "Should check git rev-parse once"
    assert len(add_calls) == 0, "Should NOT git add when not a repo"
    assert len(commit_calls) == 0, "Should NOT git commit when not a repo"


# ── Test 5: ExperimentPlan parsing handles new fields ─────────────────────────

def test_experiment_planner_includes_new_fields(tmp_path):
    """_parse_plan correctly handles forge_yaml_patches and background_additions."""
    import forge.core.experiment_planner as planner_mod
    importlib.reload(planner_mod)

    plan_json = {
        "hypothesis": "Lower LR to escape plateau",
        "rationale": "Loss stalled for 3 iterations",
        "config_patches": {},
        "forge_yaml_patches": {"training": {"learning_rate": 2e-5}},
        "background_additions": "## New Insight\nModel struggles with negatives.",
        "augment_focus": "Add negative number examples",
        "augment_n": 20,
        "expected_improvement_pp": 3.0,
    }

    result = planner_mod._parse_plan(json.dumps(plan_json))

    assert result["forge_yaml_patches"] == {"training": {"learning_rate": 2e-5}}
    assert result["background_additions"] == "## New Insight\nModel struggles with negatives."
    assert result["hypothesis"] == "Lower LR to escape plateau"
    assert result["augment_n"] == 20

    # Fallback: missing fields default to empty
    minimal_json = json.dumps({
        "hypothesis": "Minimal plan",
        "rationale": "",
        "augment_focus": "",
        "augment_n": 5,
        "expected_improvement_pp": 0.0,
    })
    minimal = planner_mod._parse_plan(minimal_json)
    assert minimal["forge_yaml_patches"] == {}
    assert minimal["background_additions"] == ""
