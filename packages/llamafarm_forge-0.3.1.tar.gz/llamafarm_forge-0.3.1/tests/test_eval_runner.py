"""Unit tests for forge.core.eval_runner — mocked, no GPU required."""
import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock


def _make_project(tmp_path: Path, gold_count: int = 4) -> Path:
    """Scaffold a minimal forge project in tmp_path."""
    (tmp_path / "dataset").mkdir()
    (tmp_path / "output").mkdir()

    cfg = {
        "name": "test-project",
        "model": {"base": "fake/model", "max_seq_len": 128, "load_in_4bit": False},
        "lora": {"r": 4, "alpha": 4, "dropout": 0.0, "target_modules": ["q_proj"]},
        "training": {
            "epochs_min": 1, "epochs_max": 1, "batch_size": 1,
            "gradient_accumulation_steps": 1, "learning_rate": 1e-4,
            "warmup_ratio": 0.1, "weight_decay": 0.0, "seed": 42,
        },
        "eval": {
            "target_accuracy": 0.75,
            "scorer": "exact",
            "max_new_tokens": 16,
            "forbidden_commands": ["kill"],
        },
        "dataset": {"canonical": "dataset/canonical.jsonl", "gold": "dataset/gold.jsonl"},
        "compute": {"device": "cpu"},
        "flywheel": {"max_iterations": 5, "augment_per_failure": 5, "datagen_model": "fake"},
    }
    import yaml
    (tmp_path / "forge.yaml").write_text(yaml.dump(cfg))
    (tmp_path / "system_prompt.md").write_text("You are a math solver.")

    gold_examples = [
        {"messages": [
            {"role": "user", "content": f"{i} + 1"},
            {"role": "assistant", "content": json.dumps({"answer": i + 1})},
        ], "category": "arithmetic"}
        for i in range(gold_count)
    ]
    (tmp_path / "dataset" / "gold.jsonl").write_text(
        "\n".join(json.dumps(e) for e in gold_examples)
    )
    return tmp_path


def _make_inference_mock(answers: list[str], tokenizer: MagicMock) -> MagicMock:
    """Return a model mock that emits the given answers in sequence."""
    model = MagicMock()
    call_count = [0]

    def fake_generate(**kwargs):
        idx = call_count[0]
        call_count[0] += 1
        answer = answers[idx] if idx < len(answers) else '{"answer": 0}'
        tokenizer.decode.return_value = answer
        # Return tensor-like with shape
        t = MagicMock()
        t.__getitem__ = lambda self, key: MagicMock()
        t.shape = [1, 3]
        return t

    model.generate.side_effect = fake_generate
    return model


def test_eval_runner_perfect_score(tmp_path):
    """eval_runner.run should return 100% when model predicts all answers correctly."""
    project_dir = _make_project(tmp_path, gold_count=4)

    import yaml
    cfg = yaml.safe_load((project_dir / "forge.yaml").read_text())

    correct_answers = [
        json.dumps({"answer": i + 1}) for i in range(4)
    ]

    mock_tokenizer = MagicMock()
    mock_tokenizer.apply_chat_template.return_value = MagicMock()
    mock_tokenizer.eos_token_id = 2

    decode_results = iter(correct_answers)
    mock_tokenizer.decode.side_effect = lambda *a, **kw: next(decode_results)

    mock_model = MagicMock()
    mock_model.generate.return_value = MagicMock(
        __getitem__=lambda self, k: MagicMock(),
        shape=[1, 3],
    )

    mock_fast_model = MagicMock()
    mock_fast_model.from_pretrained.return_value = (mock_model, mock_tokenizer)

    mock_torch = MagicMock()
    mock_torch.cuda.is_available.return_value = False
    mock_torch.no_grad.return_value.__enter__ = lambda s: None
    mock_torch.no_grad.return_value.__exit__ = MagicMock(return_value=False)

    with patch.dict("sys.modules", {
        "unsloth": MagicMock(FastModel=mock_fast_model),
        "torch": mock_torch,
    }):
        from forge.core import eval_runner
        import importlib
        importlib.reload(eval_runner)
        results = eval_runner.run(project_dir, cfg, project_dir / "output" / "adapter")

    assert results["total"] == 4
    assert results["accuracy"] == pytest.approx(1.0)
    assert results["passed"] is True
    assert results["safety_violations"] == 0
    assert (project_dir / "output" / "eval_results.json").exists()


def test_eval_runner_writes_failures(tmp_path):
    """eval_runner.run should write a failures file when there are failures."""
    project_dir = _make_project(tmp_path, gold_count=2)

    import yaml
    cfg = yaml.safe_load((project_dir / "forge.yaml").read_text())

    mock_tokenizer = MagicMock()
    mock_tokenizer.apply_chat_template.return_value = MagicMock()
    mock_tokenizer.eos_token_id = 2

    # All wrong answers
    mock_tokenizer.decode.return_value = '{"answer": 999}'

    mock_model = MagicMock()
    mock_model.generate.return_value = MagicMock(
        __getitem__=lambda self, k: MagicMock(),
        shape=[1, 3],
    )

    mock_fast_model = MagicMock()
    mock_fast_model.from_pretrained.return_value = (mock_model, mock_tokenizer)

    mock_torch = MagicMock()
    mock_torch.cuda.is_available.return_value = False
    mock_torch.no_grad.return_value.__enter__ = lambda s: None
    mock_torch.no_grad.return_value.__exit__ = MagicMock(return_value=False)

    import sys as _sys
    _sys.modules.pop("forge.core.eval_runner", None)

    with patch.dict("sys.modules", {
        "unsloth": MagicMock(FastModel=mock_fast_model),
        "torch": mock_torch,
    }):
        import importlib
        import forge.core.eval_runner as eval_runner
        importlib.reload(eval_runner)
        results = eval_runner.run(project_dir, cfg, project_dir / "output" / "adapter")

    assert results["correct"] == 0
    assert results["total"] == 2
    assert len(results["failures"]) == 2
    failures_files = list((project_dir / "output").glob("failures_*.json"))
    assert len(failures_files) == 1


def test_eval_runner_missing_gold(tmp_path):
    """eval_runner.run should raise FileNotFoundError if gold.jsonl is missing."""
    project_dir = _make_project(tmp_path)
    (project_dir / "dataset" / "gold.jsonl").unlink()

    import yaml
    cfg = yaml.safe_load((project_dir / "forge.yaml").read_text())

    from forge.core import eval_runner
    with pytest.raises(FileNotFoundError):
        eval_runner.run(project_dir, cfg, project_dir / "output" / "adapter")
