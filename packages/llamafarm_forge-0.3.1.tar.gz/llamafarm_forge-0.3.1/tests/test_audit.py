"""Unit tests for forge audit command — all Claude calls mocked."""
from __future__ import annotations

import importlib
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_project(tmp_path: Path) -> tuple[Path, dict]:
    (tmp_path / "dataset").mkdir()

    cfg = {
        "name": "test-audit",
        "flywheel": {
            "datagen_model": "claude-sonnet-4-5-20251001",
            "max_iterations": 5,
            "augment_per_failure": 10,
            "planner_model": "claude-sonnet-4-5-20251001",
        },
        "dataset": {
            "canonical": "dataset/canonical.jsonl",
            "gold": "dataset/gold.jsonl",
        },
    }
    (tmp_path / "forge.yaml").write_text(yaml.dump(cfg))
    (tmp_path / "system_prompt.md").write_text("You are a math assistant.")
    (tmp_path / "BACKGROUND.md").write_text(
        "Output format: {\"answer\": <number>}\n"
        "All arithmetic must be correct.\n"
    )
    return tmp_path, cfg


def _write_canonical(tmp_path: Path, examples: list[dict]) -> Path:
    """Write examples as messages-format JSONL."""
    path = tmp_path / "dataset" / "canonical.jsonl"
    lines = []
    for ex in examples:
        record = {
            "messages": [
                {"role": "user", "content": ex["user"]},
                {"role": "assistant", "content": ex["assistant"]},
            ]
        }
        lines.append(json.dumps(record))
    path.write_text("\n".join(lines) + "\n")
    return path


def _audit_response(results: list[dict]) -> MagicMock:
    mock_resp = MagicMock()
    mock_resp.content = [MagicMock(text=json.dumps(results))]
    return mock_resp


def _make_sync_client(response: MagicMock) -> MagicMock:
    mock_client = MagicMock()
    mock_client.messages = MagicMock()
    mock_client.messages.create = MagicMock(return_value=response)
    return mock_client


# ---------------------------------------------------------------------------
# Test 1: batching — 20 examples → 1 API call
# ---------------------------------------------------------------------------

def test_audit_calls_claude_per_batch(tmp_path):
    """20 examples should trigger exactly 1 Claude API call (batch size = 20)."""
    project_dir, cfg = _make_project(tmp_path)

    examples_data = [
        {"user": f"What is {i}+1?", "assistant": f'{{"answer": {i+1}}}'}
        for i in range(20)
    ]
    file_path = _write_canonical(tmp_path, examples_data)

    audit_results = [
        {
            "index": i,
            "format_ok": True,
            "correct": True,
            "consistent": True,
            "quality": "good",
            "issue": None,
            "severity": "ok",
            "suggested_fix": None,
        }
        for i in range(20)
    ]

    mock_client = _make_sync_client(_audit_response(audit_results))
    mock_anthropic = MagicMock()
    mock_anthropic.Anthropic.return_value = mock_client

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.audit as audit_mod
        importlib.reload(audit_mod)

        report = audit_mod.run_audit(
            project_dir=project_dir,
            cfg=cfg,
            file_path=file_path,
        )

    assert mock_client.messages.create.call_count == 1, (
        f"Expected 1 API call for 20 examples, got {mock_client.messages.create.call_count}"
    )
    assert report["stats"]["total"] == 20


# ---------------------------------------------------------------------------
# Test 2: errors appear in report
# ---------------------------------------------------------------------------

def test_audit_reports_errors(tmp_path):
    """Examples with severity=error should be counted in stats."""
    project_dir, cfg = _make_project(tmp_path)

    examples_data = [
        {"user": "2+2?", "assistant": '{"answer": 5}'},   # wrong
        {"user": "1+1?", "assistant": '{"answer": 2}'},   # correct
    ]
    file_path = _write_canonical(tmp_path, examples_data)

    audit_results = [
        {
            "index": 0,
            "format_ok": True,
            "correct": False,
            "consistent": True,
            "quality": "good",
            "issue": "2+2 should be 4 not 5",
            "severity": "error",
            "suggested_fix": '{"answer": 4}',
        },
        {
            "index": 1,
            "format_ok": True,
            "correct": True,
            "consistent": True,
            "quality": "good",
            "issue": None,
            "severity": "ok",
            "suggested_fix": None,
        },
    ]

    mock_client = _make_sync_client(_audit_response(audit_results))
    mock_anthropic = MagicMock()
    mock_anthropic.Anthropic.return_value = mock_client

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.audit as audit_mod
        importlib.reload(audit_mod)

        report = audit_mod.run_audit(
            project_dir=project_dir,
            cfg=cfg,
            file_path=file_path,
        )

    assert report["stats"]["errors"] == 1
    assert report["stats"]["total"] == 2
    # Find the error in results
    error_results = [r for r in report["results"] if r.get("severity") == "error"]
    assert len(error_results) == 1
    assert "2+2 should be 4" in error_results[0]["issue"]


# ---------------------------------------------------------------------------
# Test 3: --fix replaces error examples
# ---------------------------------------------------------------------------

def test_audit_fix_replaces_example(tmp_path):
    """With fix=True, error examples with suggested_fix are replaced in the file."""
    project_dir, cfg = _make_project(tmp_path)

    examples_data = [
        {"user": "2+2?", "assistant": '{"answer": 5}'},
        {"user": "3+3?", "assistant": '{"answer": 6}'},
    ]
    file_path = _write_canonical(tmp_path, examples_data)

    audit_results = [
        {
            "index": 0,
            "format_ok": True,
            "correct": False,
            "consistent": True,
            "quality": "good",
            "issue": "2+2 should be 4",
            "severity": "error",
            "suggested_fix": '{"answer": 4}',
        },
        {
            "index": 1,
            "format_ok": True,
            "correct": True,
            "consistent": True,
            "quality": "good",
            "issue": None,
            "severity": "ok",
            "suggested_fix": None,
        },
    ]

    mock_client = _make_sync_client(_audit_response(audit_results))
    mock_anthropic = MagicMock()
    mock_anthropic.Anthropic.return_value = mock_client

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.audit as audit_mod
        importlib.reload(audit_mod)

        audit_mod.run_audit(
            project_dir=project_dir,
            cfg=cfg,
            file_path=file_path,
            fix=True,
        )

    # Read back the file and check the fix was applied
    lines = [l for l in file_path.read_text().splitlines() if l.strip()]
    assert len(lines) == 2

    first = json.loads(lines[0])
    msgs = first["messages"]
    assistant_content = next(m["content"] for m in msgs if m["role"] == "assistant")
    assert assistant_content == '{"answer": 4}', (
        f"Expected fixed output, got: {assistant_content}"
    )

    # Second should be unchanged
    second = json.loads(lines[1])
    msgs2 = second["messages"]
    assistant2 = next(m["content"] for m in msgs2 if m["role"] == "assistant")
    assert assistant2 == '{"answer": 6}'


# ---------------------------------------------------------------------------
# Test 4: --output writes valid JSON report
# ---------------------------------------------------------------------------

def test_audit_writes_report_json(tmp_path):
    """--output flag should produce a valid JSON report file."""
    project_dir, cfg = _make_project(tmp_path)

    examples_data = [
        {"user": "1+1?", "assistant": '{"answer": 2}'},
    ]
    file_path = _write_canonical(tmp_path, examples_data)

    audit_results = [
        {
            "index": 0,
            "format_ok": True,
            "correct": True,
            "consistent": True,
            "quality": "good",
            "issue": None,
            "severity": "ok",
            "suggested_fix": None,
        }
    ]

    mock_client = _make_sync_client(_audit_response(audit_results))
    mock_anthropic = MagicMock()
    mock_anthropic.Anthropic.return_value = mock_client

    report_path = tmp_path / "audit_report.json"

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.audit as audit_mod
        importlib.reload(audit_mod)

        audit_mod.run_audit(
            project_dir=project_dir,
            cfg=cfg,
            file_path=file_path,
            output_report=report_path,
        )

    assert report_path.exists(), "audit_report.json should be created"

    report = json.loads(report_path.read_text())
    assert "stats" in report
    assert "results" in report
    assert report["stats"]["total"] == 1
    assert isinstance(report["results"], list)
    assert len(report["results"]) == 1


# ---------------------------------------------------------------------------
# Test 5: missing BACKGROUND.md graceful fallback
# ---------------------------------------------------------------------------

def test_audit_missing_background(tmp_path):
    """When BACKGROUND.md is absent, audit should still run without crashing."""
    project_dir, cfg = _make_project(tmp_path)

    # Remove BACKGROUND.md
    bg = project_dir / "BACKGROUND.md"
    if bg.exists():
        bg.unlink()

    examples_data = [
        {"user": "What is 5+5?", "assistant": '{"answer": 10}'},
    ]
    file_path = _write_canonical(tmp_path, examples_data)

    audit_results = [
        {
            "index": 0,
            "format_ok": True,
            "correct": True,
            "consistent": True,
            "quality": "good",
            "issue": None,
            "severity": "ok",
            "suggested_fix": None,
        }
    ]

    mock_client = _make_sync_client(_audit_response(audit_results))
    mock_anthropic = MagicMock()
    mock_anthropic.Anthropic.return_value = mock_client

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.audit as audit_mod
        importlib.reload(audit_mod)

        # Should not raise
        report = audit_mod.run_audit(
            project_dir=project_dir,
            cfg=cfg,
            file_path=file_path,
        )

    assert report["stats"]["total"] == 1
    # Confirm the fallback text was used (no crash)
    call_kwargs = mock_client.messages.create.call_args
    messages = call_kwargs.kwargs.get("messages") or call_kwargs.args[0]
    prompt_text = " ".join(
        m["content"] for m in messages if isinstance(m.get("content"), str)
    )
    assert "No BACKGROUND.md found" in prompt_text
