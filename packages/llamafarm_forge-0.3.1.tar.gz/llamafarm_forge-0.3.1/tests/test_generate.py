"""Unit tests for forge generate command — all Claude calls mocked."""
from __future__ import annotations

import asyncio
import importlib
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import yaml


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_project(tmp_path: Path) -> tuple[Path, dict]:
    """Minimal forge project."""
    (tmp_path / "dataset").mkdir()

    cfg = {
        "name": "test-generate",
        "flywheel": {
            "datagen_model": "claude-sonnet-4-5-20251001",
            "max_iterations": 5,
            "augment_per_failure": 10,
            "planner_model": "claude-sonnet-4-5-20251001",
        },
        "dataset": {
            "canonical": "dataset/canonical.jsonl",
            "gold": "dataset/gold.jsonl",
        },
    }
    (tmp_path / "forge.yaml").write_text(yaml.dump(cfg))
    (tmp_path / "system_prompt.md").write_text("You are a math assistant.")
    (tmp_path / "mission.md").write_text("Answer arithmetic questions as JSON.")
    (tmp_path / "BACKGROUND.md").write_text(
        "BACKGROUND_UNIQUE_MARKER\n"
        "Output format: {\"answer\": <number>}\n"
        "Difficulty: easy/medium/hard\n"
    )
    (tmp_path / "AGENT_CONTEXT.md").write_text("Previous run accuracy: 0.85")

    # Empty canonical to start
    (tmp_path / "dataset" / "canonical.jsonl").write_text("")

    return tmp_path, cfg


def _make_async_response(examples: list[dict]) -> MagicMock:
    """Build a mock async Claude response."""
    mock_resp = MagicMock()
    mock_resp.content = [MagicMock(text=json.dumps(examples))]
    return mock_resp


def _build_mock_async_client(examples_per_call: list[dict]) -> MagicMock:
    """Create a mock AsyncAnthropic client whose messages.create returns canned examples."""
    mock_client = MagicMock()
    mock_client.messages = MagicMock()
    mock_client.messages.create = AsyncMock(
        return_value=_make_async_response(examples_per_call)
    )
    return mock_client


def _run(coro):
    return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Test 1: correct number of batch API calls
# ---------------------------------------------------------------------------

def test_generate_calls_claude_in_batches(tmp_path):
    """N/batch_size async Claude calls should be made."""
    project_dir, cfg = _make_project(tmp_path)
    n = 100
    batch_size = 25
    expected_batches = n // batch_size  # 4

    # Each call returns a unique set of examples so there are no duplicates
    call_counter = {"n": 0}

    async def unique_create(**kwargs):
        offset = call_counter["n"] * batch_size
        call_counter["n"] += 1
        examples = [
            {"user": f"user_{offset + i}", "assistant": '{"answer": 1}'}
            for i in range(batch_size)
        ]
        mock_resp = MagicMock()
        mock_resp.content = [MagicMock(text=json.dumps(examples))]
        return mock_resp

    mock_client = MagicMock()
    mock_client.messages = MagicMock()
    mock_client.messages.create = unique_create

    mock_anthropic = MagicMock()
    mock_anthropic.AsyncAnthropic.return_value = mock_client

    output_path = project_dir / "dataset" / "canonical.jsonl"

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.generate as gen_mod
        importlib.reload(gen_mod)

        stats = _run(
            gen_mod.run_generate(
                project_dir=project_dir,
                cfg=cfg,
                n=n,
                batch_size=batch_size,
                output_path=output_path,
            )
        )

    assert call_counter["n"] == expected_batches, (
        f"Expected {expected_batches} API calls, got {call_counter['n']}"
    )
    assert stats["n_appended"] == n


# ---------------------------------------------------------------------------
# Test 2: deduplication
# ---------------------------------------------------------------------------

def test_generate_deduplicates(tmp_path):
    """Duplicate user strings across batches should be skipped."""
    project_dir, cfg = _make_project(tmp_path)

    # Two batches both returning the same user string
    dup_examples = [{"user": "same question?", "assistant": '{"answer": 1}'}]

    mock_client = _build_mock_async_client(dup_examples)
    mock_anthropic = MagicMock()
    mock_anthropic.AsyncAnthropic.return_value = mock_client

    output_path = project_dir / "dataset" / "canonical.jsonl"

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.generate as gen_mod
        importlib.reload(gen_mod)

        stats = _run(
            gen_mod.run_generate(
                project_dir=project_dir,
                cfg=cfg,
                n=10,
                batch_size=5,
                output_path=output_path,
            )
        )

    # Only the first occurrence should be appended; rest are dupes
    assert stats["n_appended"] == 1
    assert stats["n_dupes"] >= 1


# ---------------------------------------------------------------------------
# Test 3: invalid assistant JSON is dropped
# ---------------------------------------------------------------------------

def test_generate_validates_json(tmp_path):
    """Examples with invalid assistant JSON should be silently dropped."""
    project_dir, cfg = _make_project(tmp_path)

    examples = [
        {"user": "good question?", "assistant": '{"answer": 42}'},          # valid
        {"user": "bad question?", "assistant": "not valid json {{{{"},       # invalid
        {"user": "another bad?", "assistant": "just a string"},              # invalid (not JSON obj)
    ]

    mock_client = _build_mock_async_client(examples)
    mock_anthropic = MagicMock()
    mock_anthropic.AsyncAnthropic.return_value = mock_client

    output_path = project_dir / "dataset" / "canonical.jsonl"

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.generate as gen_mod
        importlib.reload(gen_mod)

        stats = _run(
            gen_mod.run_generate(
                project_dir=project_dir,
                cfg=cfg,
                n=3,
                batch_size=3,
                output_path=output_path,
            )
        )

    # Only the 1 valid example should be appended
    assert stats["n_valid"] == 1
    assert stats["n_appended"] == 1

    lines = [l for l in output_path.read_text().splitlines() if l.strip()]
    assert len(lines) == 1
    record = json.loads(lines[0])
    assert record["messages"][0]["content"] == "good question?"


# ---------------------------------------------------------------------------
# Test 4: examples appended in messages format
# ---------------------------------------------------------------------------

def test_generate_appends_to_canonical(tmp_path):
    """Valid examples should be appended in {messages: [{role,content}]} format."""
    project_dir, cfg = _make_project(tmp_path)

    # Pre-populate with 1 existing example
    existing = {
        "messages": [
            {"role": "user", "content": "existing question?"},
            {"role": "assistant", "content": '{"answer": 0}'},
        ]
    }
    output_path = project_dir / "dataset" / "canonical.jsonl"
    output_path.write_text(json.dumps(existing) + "\n")

    new_examples = [
        {"user": f"new question {i}?", "assistant": f'{{"answer": {i}}}'}
        for i in range(5)
    ]

    mock_client = _build_mock_async_client(new_examples)
    mock_anthropic = MagicMock()
    mock_anthropic.AsyncAnthropic.return_value = mock_client

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.generate as gen_mod
        importlib.reload(gen_mod)

        stats = _run(
            gen_mod.run_generate(
                project_dir=project_dir,
                cfg=cfg,
                n=5,
                batch_size=5,
                output_path=output_path,
            )
        )

    assert stats["n_appended"] == 5

    lines = [l for l in output_path.read_text().splitlines() if l.strip()]
    assert len(lines) == 6  # 1 existing + 5 new

    for line in lines[1:]:
        record = json.loads(line)
        assert "messages" in record
        assert len(record["messages"]) == 2
        assert record["messages"][0]["role"] == "user"
        assert record["messages"][1]["role"] == "assistant"


# ---------------------------------------------------------------------------
# Test 5: BACKGROUND.md content is in the prompt
# ---------------------------------------------------------------------------

def test_generate_respects_background_md(tmp_path):
    """BACKGROUND.md content must appear in the Claude API prompt."""
    project_dir, cfg = _make_project(tmp_path)
    background_content = "BACKGROUND_UNIQUE_MARKER"

    examples = [{"user": "1+1?", "assistant": '{"answer": 2}'}]
    mock_client = _build_mock_async_client(examples)
    mock_anthropic = MagicMock()
    mock_anthropic.AsyncAnthropic.return_value = mock_client

    output_path = project_dir / "dataset" / "canonical.jsonl"

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.generate as gen_mod
        importlib.reload(gen_mod)

        _run(
            gen_mod.run_generate(
                project_dir=project_dir,
                cfg=cfg,
                n=1,
                batch_size=1,
                output_path=output_path,
            )
        )

    assert mock_client.messages.create.called, "Claude API must have been called"

    call_kwargs = mock_client.messages.create.call_args
    messages = call_kwargs.kwargs.get("messages") or call_kwargs.args[0]
    prompt_text = " ".join(
        m["content"] for m in messages if isinstance(m.get("content"), str)
    )
    assert background_content in prompt_text, (
        f"BACKGROUND_UNIQUE_MARKER not found in prompt.\nGot: {prompt_text[:500]!r}"
    )
