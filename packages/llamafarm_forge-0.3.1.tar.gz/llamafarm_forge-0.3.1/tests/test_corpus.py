"""Tests for forge/core/corpus.py — no GPU, no API key required."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from unittest.mock import patch, MagicMock

from forge.core.corpus import load_corpus, chunk_documents, build_corpus_dataset


# ── load_corpus ───────────────────────────────────────────────────────────────

def test_load_txt(tmp_path):
    (tmp_path / "a.txt").write_text("Hello world")
    docs = load_corpus(tmp_path)
    assert docs == ["Hello world"]


def test_load_md(tmp_path):
    (tmp_path / "b.md").write_text("# Title\n\nContent here.")
    docs = load_corpus(tmp_path)
    assert len(docs) == 1
    assert "Content here" in docs[0]


def test_load_jsonl(tmp_path):
    lines = [
        json.dumps({"text": "First document"}),
        json.dumps({"text": "Second document"}),
    ]
    (tmp_path / "c.jsonl").write_text("\n".join(lines))
    docs = load_corpus(tmp_path)
    assert "First document" in docs
    assert "Second document" in docs


def test_load_mixed(tmp_path):
    (tmp_path / "a.txt").write_text("From txt")
    (tmp_path / "b.md").write_text("From md")
    (tmp_path / "c.jsonl").write_text(json.dumps({"text": "From jsonl"}))
    docs = load_corpus(tmp_path)
    assert len(docs) == 3


def test_load_skips_unknown_extension(tmp_path):
    (tmp_path / "data.csv").write_text("col1,col2\n1,2")
    (tmp_path / "doc.txt").write_text("Keep this")
    docs = load_corpus(tmp_path)
    assert docs == ["Keep this"]


def test_load_skips_empty_files(tmp_path):
    (tmp_path / "empty.txt").write_text("   ")
    (tmp_path / "real.txt").write_text("Real content")
    docs = load_corpus(tmp_path)
    assert docs == ["Real content"]


def test_load_missing_dir_raises():
    with pytest.raises(FileNotFoundError):
        load_corpus(Path("/nonexistent/corpus"))


def test_load_jsonl_missing_text_field_raises(tmp_path):
    (tmp_path / "bad.jsonl").write_text(json.dumps({"content": "oops"}))
    with pytest.raises(ValueError, match="missing 'text' field"):
        load_corpus(tmp_path)


def test_load_jsonl_invalid_json_raises(tmp_path):
    (tmp_path / "bad.jsonl").write_text("{not valid json}")
    with pytest.raises(ValueError, match="invalid JSON"):
        load_corpus(tmp_path)


def test_load_recursive(tmp_path):
    subdir = tmp_path / "sub"
    subdir.mkdir()
    (subdir / "nested.txt").write_text("Nested content")
    (tmp_path / "root.txt").write_text("Root content")
    docs = load_corpus(tmp_path)
    assert len(docs) == 2


# ── chunk_documents ───────────────────────────────────────────────────────────

def _mock_tokenizer(words_per_token: int = 1):
    """Mock tokenizer where encode returns one token per word."""
    tok = MagicMock()

    def encode(text, add_special_tokens=False):
        words = text.split()
        return list(range(len(words)))  # one int per word

    def decode(token_ids, skip_special_tokens=True):
        # Just return a string of that many words from a fixed vocab
        return " ".join(f"word{i}" for i in token_ids)

    tok.encode = encode
    tok.decode = decode
    return tok


def test_chunk_short_doc_unchanged():
    tok = _mock_tokenizer()
    doc = " ".join(f"word{i}" for i in range(10))   # 10 tokens
    chunks = chunk_documents([doc], tok, max_seq_len=100, overlap=0.1)
    assert len(chunks) == 1
    assert chunks[0] == doc


def test_chunk_long_doc_splits():
    tok = _mock_tokenizer()
    doc = " ".join(f"word{i}" for i in range(200))  # 200 tokens
    chunks = chunk_documents([doc], tok, max_seq_len=50, overlap=0.1)
    assert len(chunks) > 1


def test_chunk_tiny_trailing_dropped():
    tok = _mock_tokenizer()
    # 63 tokens → first chunk=50, second chunk would be 13 (<32 → dropped)
    doc = " ".join(f"word{i}" for i in range(63))
    chunks = chunk_documents([doc], tok, max_seq_len=50, overlap=0.0)
    # stride = 50, first chunk is full (50), remaining 13 < 32 → dropped
    assert len(chunks) == 1


def test_chunk_multiple_docs():
    tok = _mock_tokenizer()
    docs = [" ".join(f"w{i}" for i in range(10)) for _ in range(5)]
    chunks = chunk_documents(docs, tok, max_seq_len=100)
    assert len(chunks) == 5


# ── build_corpus_dataset ──────────────────────────────────────────────────────

def _mock_dataset_cls():
    mock_cls = MagicMock()
    mock_ds = MagicMock()
    mock_ds.column_names = ["text"]
    mock_cls.from_dict.return_value = mock_ds
    return mock_cls, mock_ds


def test_build_corpus_dataset_deduplication(tmp_path):
    # Two identical files → should deduplicate to 1 chunk
    content = "Unique content that should appear once"
    (tmp_path / "a.txt").write_text(content)
    (tmp_path / "b.txt").write_text(content)

    tok = _mock_tokenizer()
    mock_cls, _ = _mock_dataset_cls()

    import forge.core.corpus as corpus_mod
    original = corpus_mod.Dataset
    corpus_mod.Dataset = mock_cls
    try:
        build_corpus_dataset(tmp_path, tok, max_seq_len=2048)
    finally:
        corpus_mod.Dataset = original

    call_args = mock_cls.from_dict.call_args
    texts = call_args[0][0]["text"]
    assert len(texts) == 1


def test_build_corpus_dataset_empty_dir_raises(tmp_path):
    tok = _mock_tokenizer()
    mock_cls, _ = _mock_dataset_cls()

    import forge.core.corpus as corpus_mod
    original = corpus_mod.Dataset
    corpus_mod.Dataset = mock_cls
    try:
        with pytest.raises(ValueError, match="No usable documents"):
            build_corpus_dataset(tmp_path, tok)
    finally:
        corpus_mod.Dataset = original


def test_build_corpus_dataset_has_text_column(tmp_path):
    (tmp_path / "doc.txt").write_text("Some text here for the dataset")
    tok = _mock_tokenizer()
    mock_cls, mock_ds = _mock_dataset_cls()

    import forge.core.corpus as corpus_mod
    original = corpus_mod.Dataset
    corpus_mod.Dataset = mock_cls
    try:
        ds = build_corpus_dataset(tmp_path, tok)
    finally:
        corpus_mod.Dataset = original
    assert "text" in ds.column_names
