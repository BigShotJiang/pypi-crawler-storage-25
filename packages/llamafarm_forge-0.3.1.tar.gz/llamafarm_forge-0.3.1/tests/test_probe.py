"""Tests for forge/core/probe.py — no GPU, no API key required."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from forge.core.probe import (
    load_probe_questions,
    judge_answer,
    compare_probes,
    load_probe_results,
)


# ── load_probe_questions ──────────────────────────────────────────────────────

def test_load_probe_questions_valid(tmp_path):
    lines = [
        json.dumps({"question": "What is X?", "ideal": "X is Y."}),
        json.dumps({"question": "How does Z work?", "ideal": "Z works by ..."}),
    ]
    probe_path = tmp_path / "probe.jsonl"
    probe_path.write_text("\n".join(lines))
    qs = load_probe_questions(probe_path)
    assert len(qs) == 2
    assert qs[0]["question"] == "What is X?"
    assert qs[1]["ideal"] == "Z works by ..."


def test_load_probe_questions_skips_blank_lines(tmp_path):
    probe_path = tmp_path / "probe.jsonl"
    probe_path.write_text(
        json.dumps({"question": "Q?", "ideal": "A."}) + "\n\n"
    )
    qs = load_probe_questions(probe_path)
    assert len(qs) == 1


def test_load_probe_questions_missing_file():
    with pytest.raises(FileNotFoundError):
        load_probe_questions(Path("/nonexistent/probe.jsonl"))


def test_load_probe_questions_missing_field_raises(tmp_path):
    probe_path = tmp_path / "probe.jsonl"
    probe_path.write_text(json.dumps({"question": "Q only"}) + "\n")
    with pytest.raises(ValueError, match="'question' and 'ideal'"):
        load_probe_questions(probe_path)


# ── judge_answer ──────────────────────────────────────────────────────────────

def _make_mock_client(score: int, reasoning: str = "looks good"):
    client = MagicMock()
    response_text = json.dumps({"score": score, "reasoning": reasoning})
    client.messages.create.return_value.content = [MagicMock(text=response_text)]
    return client


def test_judge_answer_correct():
    client = _make_mock_client(score=3, reasoning="Correct and complete")
    result = judge_answer(client, "What is X?", "X is Y.", "X is Y.")
    assert result["score"] == 3
    assert "Correct" in result["reasoning"]


def test_judge_answer_wrong():
    client = _make_mock_client(score=0, reasoning="Wrong answer")
    result = judge_answer(client, "What is X?", "X is Y.", "I don't know")
    assert result["score"] == 0


def test_judge_answer_partial():
    client = _make_mock_client(score=1, reasoning="Partially correct")
    result = judge_answer(client, "Q?", "Full answer.", "Part of it.")
    assert result["score"] == 1


def test_judge_answer_strips_markdown_fences():
    client = MagicMock()
    response_text = '```json\n{"score": 2, "reasoning": "Mostly correct"}\n```'
    client.messages.create.return_value.content = [MagicMock(text=response_text)]
    result = judge_answer(client, "Q?", "A.", "Almost A.")
    assert result["score"] == 2


def test_judge_answer_calls_claude_with_question():
    client = _make_mock_client(score=2)
    judge_answer(client, "My unique question", "ideal answer", "model answer")
    # Verify Claude was called and the question text appeared in the prompt
    assert client.messages.create.called
    call_str = str(client.messages.create.call_args)
    assert "My unique question" in call_str


# ── compare_probes ────────────────────────────────────────────────────────────

def _make_probe_results(tag: str, scores: list) -> dict:
    questions = [f"Question {i+1}?" for i in range(len(scores))]
    ideals    = [f"Ideal {i+1}." for i in range(len(scores))]
    results = []
    for q, ideal, score in zip(questions, ideals, scores):
        results.append({
            "question": q,
            "ideal": ideal,
            "model_answer": f"Answer with score {score}",
            "score": score,
            "judge_reasoning": "test",
        })
    n = len(scores)
    mean = sum(scores) / n if n else 0
    pct = sum(1 for s in scores if s == 3) / n if n else 0
    return {
        "tag": tag,
        "total": n,
        "mean_score": mean,
        "pct_correct": pct,
        "results": results,
    }


def test_compare_probes_length():
    pre  = _make_probe_results("pre",  [0, 1, 2, 3])
    post = _make_probe_results("post", [1, 2, 3, 3])
    diffs = compare_probes(pre, post)
    assert len(diffs) == 4


def test_compare_probes_delta_computed():
    pre  = _make_probe_results("pre",  [0, 2])
    post = _make_probe_results("post", [2, 2])
    diffs = compare_probes(pre, post)
    assert diffs[0]["delta"] == 2   # 0 → 2
    assert diffs[1]["delta"] == 0   # 2 → 2


def test_compare_probes_missing_pre_question():
    """If pre has no matching question, delta should be '—'."""
    pre = {"tag": "pre", "total": 1, "mean_score": 0, "pct_correct": 0,
           "results": [{"question": "Other Q?", "ideal": "...", "model_answer": "", "score": 0}]}
    post = _make_probe_results("post", [3])
    diffs = compare_probes(pre, post)
    assert diffs[0]["delta"] == "—"


# ── load_probe_results ────────────────────────────────────────────────────────

def test_load_probe_results_returns_latest(tmp_path):
    output_dir = tmp_path / "output"
    output_dir.mkdir()

    older = {"tag": "pre", "mean_score": 0.5, "results": []}
    newer = {"tag": "pre", "mean_score": 0.8, "results": []}

    (output_dir / "probe_pre_20260101_100000.json").write_text(json.dumps(older))
    import time; time.sleep(0.01)
    (output_dir / "probe_pre_20260101_110000.json").write_text(json.dumps(newer))

    result = load_probe_results(output_dir, "pre")
    assert result["mean_score"] == 0.8


def test_load_probe_results_missing_returns_none(tmp_path):
    output_dir = tmp_path / "output"
    output_dir.mkdir()
    result = load_probe_results(output_dir, "pre")
    assert result is None


# ── scoring aggregation ───────────────────────────────────────────────────────

def test_pct_correct_counts_only_score_3():
    pre = _make_probe_results("pre", [3, 3, 2, 1, 0])
    assert pre["pct_correct"] == 2 / 5


def test_mean_score_correct():
    pre = _make_probe_results("pre", [0, 1, 2, 3])
    assert pre["mean_score"] == 1.5
