"""Tests for forge.core.experiment_planner._parse_plan robustness."""
import pytest
from forge.core.experiment_planner import _parse_plan

# ── Minimal valid plan payload ─────────────────────────────────────────────────
VALID_PLAN = {
    "hypothesis": "Test hypothesis",
    "rationale": "Test rationale",
    "config_patches": {},
    "forge_yaml_patches": {},
    "background_additions": "",
    "augment_focus": "",
    "augment_n": 10,
    "expected_improvement_pp": 2.5,
}

VALID_JSON = (
    '{"hypothesis": "Test hypothesis", "rationale": "Test rationale", '
    '"config_patches": {}, "forge_yaml_patches": {}, '
    '"background_additions": "", "augment_focus": "", '
    '"augment_n": 10, "expected_improvement_pp": 2.5}'
)


def assert_valid_plan(result: dict) -> None:
    """Assert result is a properly parsed plan (not fallback)."""
    assert result["hypothesis"] == "Test hypothesis"
    assert result["rationale"] == "Test rationale"
    assert result["augment_n"] == 10
    assert result["expected_improvement_pp"] == 2.5


def test_parse_clean_json():
    """Plain JSON object → parsed correctly."""
    result = _parse_plan(VALID_JSON)
    assert_valid_plan(result)


def test_parse_json_fenced_with_json_tag():
    """```json\\n{...}\\n``` → parsed correctly."""
    fenced = f"```json\n{VALID_JSON}\n```"
    result = _parse_plan(fenced)
    assert_valid_plan(result)


def test_parse_json_fenced_no_tag():
    """```\\n{...}\\n``` → parsed correctly."""
    fenced = f"```\n{VALID_JSON}\n```"
    result = _parse_plan(fenced)
    assert_valid_plan(result)


def test_parse_json_with_prose_before():
    """Prose before JSON block → parsed correctly via brace extraction."""
    text = f"Here is my plan:\n{VALID_JSON}"
    result = _parse_plan(text)
    assert_valid_plan(result)


def test_parse_json_with_prose_after():
    """{...} followed by prose → parsed correctly via brace extraction."""
    text = f"{VALID_JSON}\n\nLet me explain why this will work..."
    result = _parse_plan(text)
    assert_valid_plan(result)


def test_parse_empty_string():
    """Empty string → returns fallback hypothesis."""
    result = _parse_plan("")
    assert result["hypothesis"].startswith("Augment from failures")
    assert result["config_patches"] == {}
    assert result["augment_n"] == 10


def test_parse_completely_invalid():
    """Completely invalid text → returns fallback hypothesis."""
    result = _parse_plan("This is not JSON at all! No braces here.")
    assert result["hypothesis"].startswith("Augment from failures")


def test_parse_missing_hypothesis_key():
    """JSON without 'hypothesis' key → returns fallback (hypothesis is required)."""
    json_no_hypothesis = '{"rationale": "something", "augment_n": 5}'
    result = _parse_plan(json_no_hypothesis)
    assert result["hypothesis"].startswith("Augment from failures")


def test_parse_type_coercion():
    """augment_n as string → coerced to int; expected_improvement_pp as string → float."""
    text = (
        '{"hypothesis": "Test hypothesis", "rationale": "r", '
        '"augment_n": "7", "expected_improvement_pp": "1.5"}'
    )
    result = _parse_plan(text)
    assert result["hypothesis"] == "Test hypothesis"
    assert result["augment_n"] == 7
    assert result["expected_improvement_pp"] == 1.5


def test_parse_returns_fallback_defaults():
    """Fallback plan has all required keys with sensible defaults."""
    result = _parse_plan("")
    assert "hypothesis" in result
    assert "rationale" in result
    assert "config_patches" in result
    assert "forge_yaml_patches" in result
    assert "background_additions" in result
    assert "augment_focus" in result
    assert "augment_n" in result
    assert "expected_improvement_pp" in result
    assert isinstance(result["config_patches"], dict)
    assert isinstance(result["forge_yaml_patches"], dict)
