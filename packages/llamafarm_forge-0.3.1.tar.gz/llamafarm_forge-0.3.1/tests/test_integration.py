"""Integration-style tests for forge — realistic end-to-end scenarios.

All Claude API calls and GPU operations are mocked.
These tests exercise multi-component flows that unit tests don't cover.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import yaml
from click.testing import CliRunner

from forge.commands.init import init


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _make_project(tmp_path: Path) -> tuple[Path, dict]:
    """Create a minimal forge project (no real model, no real API)."""
    (tmp_path / "dataset").mkdir()
    (tmp_path / "output").mkdir()

    cfg = {
        "name": "integration-test",
        "model": {"base": "fake/model", "max_seq_len": 128, "load_in_4bit": False},
        "lora": {"r": 8, "alpha": 8, "dropout": 0.0},
        "training": {
            "epochs_min": 1,
            "epochs_max": 2,
            "batch_size": 2,
            "gradient_accumulation_steps": 1,
            "learning_rate": 5e-5,
            "warmup_ratio": 0.1,
            "weight_decay": 0.0,
            "seed": 42,
        },
        "eval": {
            "target_accuracy": 0.95,
            "scorer": "exact",
            "max_new_tokens": 32,
            "forbidden_commands": [],
        },
        "dataset": {
            "seed": "dataset/seed.jsonl",
            "gold": "dataset/gold.jsonl",
            "canonical": "dataset/canonical.jsonl",
        },
        "compute": {"device": "cpu"},
        "flywheel": {
            "max_iterations": 3,
            "augment_per_failure": 2,
            "datagen_model": "claude-sonnet-4-6",
            "planner_model": "claude-sonnet-4-6",
        },
    }
    (tmp_path / "forge.yaml").write_text(yaml.dump(cfg))
    (tmp_path / "system_prompt.md").write_text("You are a math assistant. Return JSON.")
    (tmp_path / "mission.md").write_text("Answer arithmetic questions as JSON.")
    (tmp_path / "BACKGROUND.md").write_text(
        "# Background\n\n"
        "## Task\nAnswer arithmetic questions.\n\n"
        "## Output Format\n{\"answer\": <number>}\n\n"
        "## Edge Cases\nNegative numbers are valid.\n\n"
        "## Common Failure Patterns\nDropping the answer key.\n\n"
        "## What Good Examples Look Like\nVaried phrasing, correct answers.\n"
    )

    examples = [
        {
            "messages": [
                {"role": "user", "content": "What is 1+1?"},
                {"role": "assistant", "content": '{"answer": 2}'},
            ]
        }
    ]
    (tmp_path / "dataset" / "canonical.jsonl").write_text(
        "\n".join(json.dumps(e) for e in examples)
    )
    (tmp_path / "dataset" / "gold.jsonl").write_text(
        "\n".join(json.dumps(e) for e in examples)
    )
    (tmp_path / "dataset" / "seed.jsonl").write_text("")
    (tmp_path / "output" / "adapter").mkdir(parents=True, exist_ok=True)

    return tmp_path, cfg


# ---------------------------------------------------------------------------
# Test 1: forge init creates all expected files with correct content
# ---------------------------------------------------------------------------

class TestFullProjectScaffold:
    """forge init creates every expected file with correct substitutions."""

    def setup_method(self):
        self.runner = CliRunner()

    def test_full_project_scaffold(self, tmp_path):
        """All expected files exist and contain the project name."""
        target = tmp_path / "my-integration-proj"
        result = self.runner.invoke(init, ["my-integration-proj", "--dir", str(target)])

        assert result.exit_code == 0, f"forge init failed: {result.output}"

        # All required files must exist
        expected_files = [
            "forge.yaml",
            "BACKGROUND.md",
            "system_prompt.md",
            "mission.md",
            "llm.txt",
            ".gitignore",
            "dataset/seed.jsonl",
            "dataset/gold.jsonl",
            "dataset/canonical.jsonl",
        ]
        for rel_path in expected_files:
            full = target / rel_path
            assert full.exists(), f"Missing expected file: {rel_path}"

        # forge.yaml must be valid YAML and contain the project name
        cfg = yaml.safe_load((target / "forge.yaml").read_text())
        assert cfg["name"] == "my-integration-proj"

        # forge.yaml must have all top-level sections
        for section in ["model", "lora", "training", "eval", "dataset", "flywheel"]:
            assert section in cfg, f"forge.yaml missing section: {section}"

        # BACKGROUND.md must contain project name
        bg = (target / "BACKGROUND.md").read_text()
        assert "my-integration-proj" in bg

        # mission.md must contain project name
        mission = (target / "mission.md").read_text()
        assert "my-integration-proj" in mission

        # output dir must exist
        assert (target / "output").is_dir()
        assert (target / "dataset").is_dir()


# ---------------------------------------------------------------------------
# Test 2: forge generate prompt contains all required sections
# ---------------------------------------------------------------------------

class TestGeneratePromptSections:
    """The generate prompt contains all context sections Claude needs."""

    def test_generate_prompt_contains_all_sections(self, tmp_path):
        """Build prompt includes BACKGROUND, SYSTEM PROMPT, TASK, RECENT HISTORY sections."""
        from forge.commands.generate import _build_prompt

        background = "BACKGROUND_SECTION_MARKER: output format goes here"
        system_prompt = "SYSTEM_PROMPT_SECTION_MARKER: you are a math assistant"
        mission = "TASK_SECTION_MARKER: answer arithmetic questions"
        agent_context = "RECENT_HISTORY_SECTION_MARKER: prev accuracy 0.72"

        prompt = _build_prompt(
            batch_size=10,
            batch_num=1,
            total_batches=5,
            background=background,
            system_prompt=system_prompt,
            mission=mission,
            agent_context_tail=agent_context,
        )

        # All four context sections must appear in the prompt
        assert "BACKGROUND_SECTION_MARKER" in prompt, "BACKGROUND missing from generate prompt"
        assert "SYSTEM_PROMPT_SECTION_MARKER" in prompt, "SYSTEM PROMPT missing from generate prompt"
        assert "TASK_SECTION_MARKER" in prompt, "TASK/MISSION missing from generate prompt"
        assert "RECENT_HISTORY_SECTION_MARKER" in prompt, "RECENT HISTORY missing from generate prompt"

        # Must mention batch info
        assert "10" in prompt  # batch_size
        assert "Batch 1 of 5" in prompt

    def test_generate_prompt_instructs_json_array(self, tmp_path):
        """The generate prompt instructs Claude to return a JSON array."""
        from forge.commands.generate import _build_prompt

        prompt = _build_prompt(
            batch_size=5,
            batch_num=1,
            total_batches=1,
            background="bg",
            system_prompt="sp",
            mission="task",
            agent_context_tail="history",
        )

        # Must request JSON array output
        assert "JSON array" in prompt or "json array" in prompt.lower()
        # Must mention user/assistant keys
        assert '"user"' in prompt or "user" in prompt
        assert '"assistant"' in prompt or "assistant" in prompt


# ---------------------------------------------------------------------------
# Test 3: forge audit detects wrong answer → severity=error
# ---------------------------------------------------------------------------

class TestAuditDetectsWrongAnswer:
    """Audit correctly propagates Claude's correct=False → severity=error."""

    def _make_audit_project(self, tmp_path: Path) -> tuple[Path, dict]:
        (tmp_path / "dataset").mkdir()
        cfg = {
            "name": "audit-test",
            "flywheel": {
                "datagen_model": "claude-sonnet-4-6",
                "planner_model": "claude-sonnet-4-6",
                "max_iterations": 3,
                "augment_per_failure": 5,
            },
            "dataset": {
                "canonical": "dataset/canonical.jsonl",
                "gold": "dataset/gold.jsonl",
            },
        }
        (tmp_path / "forge.yaml").write_text(yaml.dump(cfg))
        (tmp_path / "system_prompt.md").write_text("You are a math assistant.")
        (tmp_path / "BACKGROUND.md").write_text('Output format: {"answer": <number>}')

        # One correct example, one wrong example
        examples = [
            {
                "messages": [
                    {"role": "user", "content": "What is 2+2?"},
                    {"role": "assistant", "content": '{"answer": 4}'},
                ]
            },
            {
                "messages": [
                    {"role": "user", "content": "What is 3+3?"},
                    # Wrong answer intentionally
                    {"role": "assistant", "content": '{"answer": 99}'},
                ]
            },
        ]
        (tmp_path / "dataset" / "canonical.jsonl").write_text(
            "\n".join(json.dumps(e) for e in examples)
        )
        return tmp_path, cfg

    def test_audit_detects_wrong_answer(self, tmp_path):
        """Mock Claude returning correct=False → audit report contains severity=error."""
        from forge.commands.audit import run_audit

        project_dir, cfg = self._make_audit_project(tmp_path)
        canonical_path = project_dir / "dataset" / "canonical.jsonl"

        # Mock Claude audit response: index 1 is wrong (correct=False)
        mock_audit_results = [
            {
                "index": 0,
                "format_ok": True,
                "correct": True,
                "consistent": True,
                "quality": "good",
                "issue": None,
                "severity": "ok",
                "suggested_fix": None,
            },
            {
                "index": 1,
                "format_ok": True,
                "correct": False,
                "consistent": True,
                "quality": "ok",
                "issue": "Wrong answer: 3+3=6, not 99",
                "severity": "error",
                "suggested_fix": '{"answer": 6}',
            },
        ]

        mock_response = MagicMock()
        mock_response.content = [MagicMock(text=json.dumps(mock_audit_results))]

        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_response

        with patch("anthropic.Anthropic", return_value=mock_client):
            report = run_audit(
                project_dir=project_dir,
                cfg=cfg,
                file_path=canonical_path,
                fix=False,
            )

        # Should detect the wrong-answer example as an error
        assert "results" in report or "all_results" in report or isinstance(report, dict)

        # Find errors in the returned results
        results_key = "results" if "results" in report else "all_results"
        if results_key in report:
            error_items = [r for r in report[results_key] if r.get("severity") == "error"]
            assert len(error_items) >= 1, (
                f"Expected at least 1 error in audit report. Got: {report[results_key]}"
            )
            error = error_items[0]
            assert error["index"] == 1
            assert error["correct"] is False


# ---------------------------------------------------------------------------
# Test 4: flywheel git commit message format
# ---------------------------------------------------------------------------

class TestFlywheelGitCommitMessageFormat:
    """Verify commit message is: 'forge iter N: XX.X% — hypothesis text'"""

    def test_git_commit_message_format(self, tmp_path):
        """_git_commit_iteration writes commit message in the correct format."""
        import importlib
        import forge.commands.flywheel as fw_mod
        importlib.reload(fw_mod)

        committed_messages = []

        def fake_subprocess_run(cmd, **kwargs):
            result = MagicMock()
            result.returncode = 0
            if "rev-parse" in cmd:
                pass  # simulate: is a git repo
            elif "commit" in cmd and "-m" in cmd:
                msg_idx = list(cmd).index("-m") + 1
                committed_messages.append(cmd[msg_idx])
            return result

        with patch("forge.commands.flywheel.subprocess.run", side_effect=fake_subprocess_run):
            fw_mod._git_commit_iteration(
                project_dir=tmp_path,
                iteration=3,
                accuracy=0.873,
                hypothesis="Targeting hover/loiter confusion with more examples",
            )

        assert len(committed_messages) == 1, "Expected exactly one git commit"
        msg = committed_messages[0]

        # Format: "forge iter N: XX.X% — <hypothesis>"
        assert msg.startswith("forge iter 3:"), f"Wrong prefix: {msg!r}"
        assert "87.3%" in msg, f"Expected '87.3%' in message: {msg!r}"
        assert "—" in msg or "-" in msg, f"Expected separator in message: {msg!r}"
        assert "Targeting hover/loiter confusion" in msg, f"Hypothesis missing from message: {msg!r}"

    def test_git_commit_truncates_long_hypothesis(self, tmp_path):
        """Long hypothesis text is truncated to 60 chars in commit message."""
        import importlib
        import forge.commands.flywheel as fw_mod
        importlib.reload(fw_mod)

        long_hypothesis = "A" * 200  # 200 chars — well over the 60-char limit

        committed_messages = []

        def fake_subprocess_run(cmd, **kwargs):
            result = MagicMock()
            result.returncode = 0
            if "commit" in cmd and "-m" in cmd:
                msg_idx = list(cmd).index("-m") + 1
                committed_messages.append(cmd[msg_idx])
            return result

        with patch("forge.commands.flywheel.subprocess.run", side_effect=fake_subprocess_run):
            fw_mod._git_commit_iteration(
                project_dir=tmp_path,
                iteration=1,
                accuracy=0.5,
                hypothesis=long_hypothesis,
            )

        if committed_messages:
            msg = committed_messages[0]
            # The hypothesis portion should be truncated (full 200-char string should NOT appear)
            assert long_hypothesis not in msg, "Hypothesis should be truncated in commit message"


# ---------------------------------------------------------------------------
# Test 5: planner applies forge_yaml_patches to disk
# ---------------------------------------------------------------------------

class TestPlannerAppliesForgeYamlPatch:
    """When the planner returns forge_yaml_patches, forge.yaml on disk is updated."""

    def test_planner_applies_forge_yaml_patch_to_disk(self, tmp_path):
        """forge_yaml_patches from ExperimentPlan are deep-merged into forge.yaml."""
        import importlib
        import forge.commands.flywheel as fw_mod
        importlib.reload(fw_mod)

        project_dir, cfg = _make_project(tmp_path)

        # Verify original values
        original = yaml.safe_load((project_dir / "forge.yaml").read_text())
        assert original["lora"]["r"] == 8
        assert original["training"]["learning_rate"] == pytest.approx(5e-5)

        patches = {
            "lora": {"r": 64},
            "training": {"learning_rate": 1e-5},
        }

        fake_train_result = {
            "adapter_dir": str(project_dir / "output" / "adapter"),
            "final_loss": 0.2,
            "epochs_run": 1,
            "train_examples": 1,
        }
        fake_eval_result = {
            "accuracy": 0.50,
            "correct": 5,
            "total": 10,
            "safety_violations": 0,
            "passed": False,
            "per_category": {},
            "failures": [],
            "elapsed_min": 0.0,
        }
        fake_plan = {
            "hypothesis": "Increase LoRA rank for capacity",
            "rationale": "Model underfitting",
            "config_patches": {},
            "forge_yaml_patches": patches,
            "background_additions": "",
            "augment_focus": "",
            "augment_n": 2,
            "expected_improvement_pp": 5.0,
        }

        with patch("forge.commands.flywheel.subprocess.run", return_value=MagicMock(returncode=0)), \
             patch("forge.core.trainer.run", return_value=fake_train_result), \
             patch("forge.core.eval_runner.run", return_value=fake_eval_result), \
             patch("forge.core.augmentor.run", return_value=0), \
             patch("forge.core.experiment_planner.plan", return_value=fake_plan), \
             patch("forge.core.planner.update_plan"), \
             patch("forge.core.context.update"):
            importlib.reload(fw_mod)
            fw_mod._run_flywheel(project_dir, cfg, max_iters=1)

        updated = yaml.safe_load((project_dir / "forge.yaml").read_text())

        assert updated["lora"]["r"] == 64, (
            f"Expected lora.r=64 after patch, got {updated['lora']['r']}"
        )
        assert updated["training"]["learning_rate"] == pytest.approx(1e-5), (
            f"Expected lr=1e-5 after patch, got {updated['training']['learning_rate']}"
        )
        # Unchanged fields must be preserved
        assert updated["name"] == "integration-test"
        assert updated["training"]["epochs_min"] == 1


# ---------------------------------------------------------------------------
# Test 6: background additions appear in next augment prompt
# ---------------------------------------------------------------------------

class TestBackgroundAdditionsInNextAugment:
    """After planner appends to BACKGROUND.md, the augmentor prompt contains the addition."""

    def test_background_additions_appear_in_next_augment(self, tmp_path):
        """Text appended to BACKGROUND.md by planner appears in the augmentor prompt."""
        project_dir, cfg = _make_project(tmp_path)

        new_insight = "UNIQUE_INSIGHT_XYZ: model fails on negative numbers specifically"

        # Simulate planner appending to BACKGROUND.md (as the flywheel does)
        bg_path = project_dir / "BACKGROUND.md"
        original_bg = bg_path.read_text()
        bg_path.write_text(original_bg + "\n\n## Agent-Discovered Patterns\n\n" + new_insight + "\n")

        # Now run the augmentor and capture the prompt it builds
        from forge.core.augmentor import DATAGEN_PROMPT

        # Build what the augmentor would use as prompt context
        background = bg_path.read_text()
        mission = (project_dir / "mission.md").read_text()
        system_prompt = (project_dir / "system_prompt.md").read_text()

        prompt = DATAGEN_PROMPT.format(
            mission=mission,
            system_prompt=system_prompt,
            background=background,
            agent_context="",
            failure_summary="",
            augment_focus="Focus on negative number examples",
            n=5,
        )

        assert new_insight in prompt, (
            f"New background insight not found in augmentor prompt.\n"
            f"Looking for: {new_insight!r}\n"
            f"Prompt (truncated): {prompt[:500]!r}"
        )

    def test_background_additions_not_truncated(self, tmp_path):
        """BACKGROUND.md content is included in full in augmentor prompt (not truncated)."""
        project_dir, cfg = _make_project(tmp_path)

        # Write a large BACKGROUND.md (but still reasonable)
        large_bg_content = "# Background\n\n" + ("Important content. " * 500)
        (project_dir / "BACKGROUND.md").write_text(large_bg_content)

        from forge.core.augmentor import DATAGEN_PROMPT

        background = (project_dir / "BACKGROUND.md").read_text()

        prompt = DATAGEN_PROMPT.format(
            mission="answer questions",
            system_prompt="you are helpful",
            background=background,
            agent_context="",
            failure_summary="",
            augment_focus="",
            n=5,
        )

        # The full background should appear in the prompt
        assert large_bg_content in prompt, "BACKGROUND.md was truncated in augmentor prompt"


# ---------------------------------------------------------------------------
# Test 7: forge init creates llm.txt with project name substituted
# ---------------------------------------------------------------------------

class TestLlmTxtCreatedByInit:
    """forge init creates llm.txt with {project_name} substituted correctly."""

    def setup_method(self):
        self.runner = CliRunner()

    def test_llm_txt_created_by_init(self, tmp_path):
        """forge init creates llm.txt and substitutes the project name."""
        target = tmp_path / "my-llm-proj"
        result = self.runner.invoke(init, ["my-llm-proj", "--dir", str(target)])

        assert result.exit_code == 0, f"forge init failed: {result.output}"

        llm_txt = target / "llm.txt"
        assert llm_txt.exists(), "llm.txt was not created by forge init"

        content = llm_txt.read_text()

        # Project name should appear in the file
        assert "my-llm-proj" in content, (
            f"Project name 'my-llm-proj' not found in llm.txt.\n"
            f"Content (truncated): {content[:300]!r}"
        )

        # Template placeholder should NOT appear in the output
        assert "{project_name}" not in content, (
            "Template placeholder {project_name} was not substituted in llm.txt"
        )

    def test_llm_txt_contains_key_sections(self, tmp_path):
        """llm.txt contains the essential sections an agent needs."""
        target = tmp_path / "section-test-proj"
        result = self.runner.invoke(init, ["section-test-proj", "--dir", str(target)])

        assert result.exit_code == 0, f"forge init failed: {result.output}"

        content = (target / "llm.txt").read_text()

        # Must have key content sections
        assert "forge flywheel" in content, "llm.txt missing flywheel command reference"
        assert "gold.jsonl" in content, "llm.txt missing gold.jsonl warning"
        assert "BACKGROUND.md" in content, "llm.txt missing BACKGROUND.md reference"
        assert "forge.yaml" in content, "llm.txt missing forge.yaml reference"

    def test_llm_txt_warns_about_gold_set(self, tmp_path):
        """llm.txt explicitly warns against editing gold.jsonl."""
        target = tmp_path / "gold-warning-proj"
        result = self.runner.invoke(init, ["gold-warning-proj", "--dir", str(target)])

        assert result.exit_code == 0, f"forge init failed: {result.output}"

        content = (target / "llm.txt").read_text()

        # Must contain a clear warning about the gold set
        assert "NEVER" in content or "never" in content, (
            "llm.txt should warn agents to never edit gold.jsonl"
        )
        assert "gold.jsonl" in content
