"""Tests for forge.core.config — load defaults, deep merge, missing file raises,
task.yaml translation, and .env loading."""
from __future__ import annotations

import os
import pytest
import yaml
from pathlib import Path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def write_forge_yaml(tmp_path: Path, content: dict | str) -> Path:
    p = tmp_path / "forge.yaml"
    if isinstance(content, dict):
        p.write_text(yaml.dump(content))
    else:
        p.write_text(content)
    return tmp_path


def write_task_yaml(tmp_path: Path, content: dict) -> Path:
    configs = tmp_path / "configs"
    configs.mkdir(exist_ok=True)
    p = configs / "task.yaml"
    p.write_text(yaml.dump(content))
    return tmp_path


# ---------------------------------------------------------------------------
# forge.yaml tests
# ---------------------------------------------------------------------------

class TestLoadDefaults:
    def test_loads_default_model_base(self, tmp_path):
        write_forge_yaml(tmp_path, {"name": "test-proj"})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["model"]["base"] == "unsloth/functiongemma-270m-it"

    def test_loads_default_lora_r(self, tmp_path):
        write_forge_yaml(tmp_path, {"name": "test-proj"})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["lora"]["r"] == 32

    def test_loads_default_eval_target(self, tmp_path):
        write_forge_yaml(tmp_path, {"name": "test-proj"})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["eval"]["target_accuracy"] == pytest.approx(0.95)

    def test_project_dir_injected(self, tmp_path):
        write_forge_yaml(tmp_path, {"name": "test-proj"})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["_project_dir"] == str(tmp_path)

    def test_name_preserved(self, tmp_path):
        write_forge_yaml(tmp_path, {"name": "my-router"})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["name"] == "my-router"


class TestDeepMerge:
    def test_user_overrides_model_base(self, tmp_path):
        write_forge_yaml(tmp_path, {"model": {"base": "custom/model"}})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["model"]["base"] == "custom/model"
        # Other model fields still have defaults
        assert cfg["model"]["max_seq_len"] == 2048

    def test_user_overrides_training_lr(self, tmp_path):
        write_forge_yaml(tmp_path, {"training": {"learning_rate": 1e-4}})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["training"]["learning_rate"] == pytest.approx(1e-4)
        # Other training defaults preserved
        assert cfg["training"]["batch_size"] == 4

    def test_user_overrides_eval_target(self, tmp_path):
        write_forge_yaml(tmp_path, {"eval": {"target_accuracy": 0.80}})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["eval"]["target_accuracy"] == pytest.approx(0.80)

    def test_nested_deep_merge(self, tmp_path):
        write_forge_yaml(tmp_path, {
            "lora": {"r": 64},
            "compute": {"device": "cpu"},
        })
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["lora"]["r"] == 64
        assert cfg["lora"]["alpha"] == 32       # default preserved
        assert cfg["compute"]["device"] == "cpu"
        assert cfg["compute"]["remote"] is None  # default preserved

    def test_flywheel_overrides(self, tmp_path):
        write_forge_yaml(tmp_path, {"flywheel": {"max_iterations": 5}})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["flywheel"]["max_iterations"] == 5
        assert cfg["flywheel"]["augment_per_failure"] == 20  # default


class TestMissingFile:
    def test_missing_forge_yaml_raises_file_not_found(self, tmp_path):
        from forge.core.config import load
        with pytest.raises(FileNotFoundError, match="forge.yaml"):
            load(tmp_path)

    def test_none_project_dir_no_yaml_raises(self, tmp_path, monkeypatch):
        """When no forge.yaml exists anywhere in cwd chain, load() raises."""
        monkeypatch.chdir(tmp_path)
        from forge.core.config import load
        with pytest.raises(FileNotFoundError):
            load(None)

    def test_empty_yaml_uses_all_defaults(self, tmp_path):
        """An empty forge.yaml is valid — all defaults apply."""
        (tmp_path / "forge.yaml").write_text("")
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["model"]["base"] == "unsloth/functiongemma-270m-it"


class TestFindProjectRoot:
    def test_finds_root_from_cwd(self, tmp_path, monkeypatch):
        (tmp_path / "forge.yaml").write_text("name: x")
        monkeypatch.chdir(tmp_path)
        from forge.core.config import find_project_root
        assert find_project_root() == tmp_path

    def test_finds_root_from_subdir(self, tmp_path, monkeypatch):
        (tmp_path / "forge.yaml").write_text("name: x")
        subdir = tmp_path / "src"
        subdir.mkdir()
        monkeypatch.chdir(subdir)
        from forge.core.config import find_project_root
        assert find_project_root() == tmp_path

    def test_returns_none_when_not_found(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from forge.core.config import find_project_root
        assert find_project_root() is None

    def test_finds_root_via_task_yaml_fallback(self, tmp_path, monkeypatch):
        """find_project_root() falls back to configs/task.yaml if no forge.yaml."""
        write_task_yaml(tmp_path, {"model": {"base": "x"}})
        monkeypatch.chdir(tmp_path)
        from forge.core.config import find_project_root
        assert find_project_root() == tmp_path

    def test_forge_yaml_takes_priority_over_task_yaml(self, tmp_path, monkeypatch):
        """forge.yaml wins even when configs/task.yaml also exists."""
        write_forge_yaml(tmp_path, {"name": "forge-wins"})
        write_task_yaml(tmp_path, {"name": "task-loses"})
        monkeypatch.chdir(tmp_path)
        from forge.core.config import find_project_root, load
        root = find_project_root()
        assert root == tmp_path
        cfg = load(root)
        assert cfg["name"] == "forge-wins"


# ---------------------------------------------------------------------------
# configs/task.yaml translation tests
# ---------------------------------------------------------------------------

class TestTaskYamlTranslation:
    def test_translates_train_to_canonical(self, tmp_path):
        write_task_yaml(tmp_path, {
            "dataset": {"train": "src/dataset/canonical_v14.jsonl",
                        "eval": "src/dataset/gold_v5.jsonl"},
        })
        from forge.core.config import load
        cfg = load(tmp_path)
        assert "canonical_v14.jsonl" in cfg["dataset"]["canonical"]

    def test_translates_eval_to_gold(self, tmp_path):
        write_task_yaml(tmp_path, {
            "dataset": {"train": "src/dataset/canonical_v14.jsonl",
                        "eval": "src/dataset/gold_v5.jsonl"},
        })
        from forge.core.config import load
        cfg = load(tmp_path)
        assert "gold_v5.jsonl" in cfg["dataset"]["gold"]

    def test_translates_accuracy_target(self, tmp_path):
        write_task_yaml(tmp_path, {
            "eval": {"accuracy_target": 0.92, "max_new_tokens": 256,
                     "forbidden_commands": []},
        })
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["eval"]["target_accuracy"] == pytest.approx(0.92)

    def test_translates_gpu_device(self, tmp_path):
        write_task_yaml(tmp_path, {"gpu": {"device": 0}})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["compute"]["device"] == "cuda:0"

    def test_translates_hf_repo(self, tmp_path):
        write_task_yaml(tmp_path, {
            "promotion": {"hf_repo": "llama-farm/test-v1"},
        })
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["promotion"]["hf_repo"] == "llama-farm/test-v1"

    def test_defaults_applied_on_top_of_task_yaml(self, tmp_path):
        """Task yaml translation still gets all forge defaults merged in."""
        write_task_yaml(tmp_path, {"model": {"base": "custom/model"}})
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["model"]["base"] == "custom/model"
        assert cfg["model"]["max_seq_len"] == 2048  # default
        assert cfg["lora"]["r"] == 32               # default


# ---------------------------------------------------------------------------
# .env loading tests
# ---------------------------------------------------------------------------

class TestDotEnvLoading:
    def test_loads_hf_token_from_env_file(self, tmp_path, monkeypatch):
        write_forge_yaml(tmp_path, {"name": "test"})
        (tmp_path / ".env").write_text("HF_TOKEN=hf_test123\n")
        # Ensure it's not already in env
        monkeypatch.delenv("HF_TOKEN", raising=False)
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["_hf_token"] == "hf_test123"

    def test_does_not_override_existing_env_var(self, tmp_path, monkeypatch):
        write_forge_yaml(tmp_path, {"name": "test"})
        (tmp_path / ".env").write_text("HF_TOKEN=from_file\n")
        monkeypatch.setenv("HF_TOKEN", "from_env")
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["_hf_token"] == "from_env"

    def test_handles_missing_env_file_gracefully(self, tmp_path):
        write_forge_yaml(tmp_path, {"name": "test"})
        # No .env file — should not raise
        from forge.core.config import load
        cfg = load(tmp_path)
        assert "_hf_token" in cfg

    def test_handles_quoted_values(self, tmp_path, monkeypatch):
        write_forge_yaml(tmp_path, {"name": "test"})
        (tmp_path / ".env").write_text('HF_TOKEN="hf_quoted"\n')
        monkeypatch.delenv("HF_TOKEN", raising=False)
        from forge.core.config import load
        cfg = load(tmp_path)
        assert cfg["_hf_token"] == "hf_quoted"
