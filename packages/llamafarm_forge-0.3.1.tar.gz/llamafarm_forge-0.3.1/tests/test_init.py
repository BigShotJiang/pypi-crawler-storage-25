"""Tests for forge.commands.init — scaffold creates correct files."""
from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from forge.commands.init import init


class TestScaffold:
    def setup_method(self):
        self.runner = CliRunner()

    def test_creates_directory(self, tmp_path):
        target = tmp_path / "my-router"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            result = self.runner.invoke(init, ["my-router", "--dir", str(target)])
        assert result.exit_code == 0, result.output
        assert target.is_dir()

    def test_creates_forge_yaml(self, tmp_path):
        target = tmp_path / "my-router"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            result = self.runner.invoke(init, ["my-router", "--dir", str(target)])
        assert result.exit_code == 0, result.output
        assert (target / "forge.yaml").exists()

    def test_forge_yaml_contains_name(self, tmp_path):
        target = tmp_path / "my-router"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["my-router", "--dir", str(target)])
        content = (target / "forge.yaml").read_text()
        assert "my-router" in content

    def test_creates_mission_md(self, tmp_path):
        target = tmp_path / "test-proj"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["test-proj", "--dir", str(target)])
        assert (target / "mission.md").exists()

    def test_creates_system_prompt_md(self, tmp_path):
        target = tmp_path / "test-proj"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["test-proj", "--dir", str(target)])
        assert (target / "system_prompt.md").exists()

    def test_creates_gitignore(self, tmp_path):
        target = tmp_path / "test-proj"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["test-proj", "--dir", str(target)])
        assert (target / ".gitignore").exists()

    def test_creates_dataset_dir(self, tmp_path):
        target = tmp_path / "test-proj"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["test-proj", "--dir", str(target)])
        assert (target / "dataset").is_dir()

    def test_creates_output_dir(self, tmp_path):
        target = tmp_path / "test-proj"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["test-proj", "--dir", str(target)])
        assert (target / "output").is_dir()

    def test_creates_seed_jsonl(self, tmp_path):
        target = tmp_path / "test-proj"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["test-proj", "--dir", str(target)])
        assert (target / "dataset" / "seed.jsonl").exists()

    def test_creates_gold_jsonl(self, tmp_path):
        target = tmp_path / "test-proj"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["test-proj", "--dir", str(target)])
        assert (target / "dataset" / "gold.jsonl").exists()

    def test_creates_canonical_jsonl(self, tmp_path):
        target = tmp_path / "test-proj"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["test-proj", "--dir", str(target)])
        assert (target / "dataset" / "canonical.jsonl").exists()

    def test_fails_if_dir_exists(self, tmp_path):
        target = tmp_path / "existing"
        target.mkdir()
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            result = self.runner.invoke(init, ["existing", "--dir", str(target)])
        assert result.exit_code != 0

    def test_mission_md_contains_name(self, tmp_path):
        target = tmp_path / "drone-nav"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["drone-nav", "--dir", str(target)])
        content = (target / "mission.md").read_text()
        assert "drone-nav" in content

    def test_gitignore_has_output(self, tmp_path):
        target = tmp_path / "test-proj"
        with self.runner.isolated_filesystem(temp_dir=tmp_path):
            self.runner.invoke(init, ["test-proj", "--dir", str(target)])
        content = (target / ".gitignore").read_text()
        assert "output/" in content
