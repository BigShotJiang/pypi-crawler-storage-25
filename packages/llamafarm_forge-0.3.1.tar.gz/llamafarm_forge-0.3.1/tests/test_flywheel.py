"""Unit tests for forge flywheel loop, augmentor, and experiment planner — no GPU, no real Claude."""
from __future__ import annotations

import importlib
import json
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest
import yaml


# ── Shared project scaffold ────────────────────────────────────────────────────

def _make_project(tmp_path: Path) -> tuple[Path, dict]:
    """Create a minimal forge project and return (project_dir, cfg)."""
    (tmp_path / "dataset").mkdir()
    (tmp_path / "output").mkdir()

    cfg = {
        "name": "test-flywheel",
        "model": {"base": "fake/model", "max_seq_len": 128, "load_in_4bit": False},
        "lora": {"r": 4, "alpha": 4, "dropout": 0.0, "target_modules": ["q_proj"]},
        "training": {
            "epochs_min": 1, "epochs_max": 3, "batch_size": 1,
            "gradient_accumulation_steps": 1, "learning_rate": 1e-4,
            "warmup_ratio": 0.1, "weight_decay": 0.0, "seed": 42,
        },
        "eval": {"target_accuracy": 0.95, "scorer": "exact", "max_new_tokens": 16,
                 "forbidden_commands": []},
        "dataset": {"canonical": "dataset/canonical.jsonl", "gold": "dataset/gold.jsonl"},
        "compute": {"device": "cpu"},
        "flywheel": {
            "max_iterations": 5, "augment_per_failure": 2,
            "datagen_model": "claude-3-5-haiku-20241022",
            "planner_model": "claude-3-5-haiku-20241022",
        },
    }
    (tmp_path / "forge.yaml").write_text(yaml.dump(cfg))
    (tmp_path / "system_prompt.md").write_text("You are a test assistant.")
    (tmp_path / "mission.md").write_text("Answer math questions as JSON.")

    # Minimal canonical.jsonl
    examples = [
        {"messages": [{"role": "user", "content": "1+1?"}, {"role": "assistant", "content": '{"answer":2}'}]}
    ]
    (tmp_path / "dataset" / "canonical.jsonl").write_text(
        "\n".join(json.dumps(e) for e in examples)
    )
    (tmp_path / "dataset" / "gold.jsonl").write_text(
        "\n".join(json.dumps(e) for e in examples)
    )

    # Pre-create output/adapter dir so promote copy doesn't fail when skipping train
    (tmp_path / "output" / "adapter").mkdir(parents=True, exist_ok=True)

    return tmp_path, cfg


def _fake_train_result(project_dir: Path) -> dict:
    return {
        "adapter_dir": str(project_dir / "output" / "adapter"),
        "final_loss": 0.1,
        "epochs_run": 2,
        "train_examples": 100,
    }


def _fake_eval_result(accuracy: float, n_failures: int = 1) -> dict:
    failures = [
        {
            "index": i,
            "category": "arithmetic",
            "input": f"What is {i}+1?",
            "expected": json.dumps({"answer": i + 1}),
            "actual": str(i),
            "error": "mismatch",
        }
        for i in range(n_failures)
    ]
    return {
        "accuracy": accuracy,
        "correct": int(accuracy * 10),
        "total": 10,
        "safety_violations": 0,
        "passed": accuracy >= 0.95,
        "per_category": {"arithmetic": {"correct": int(accuracy * 10), "total": 10}},
        "failures": failures,
        "elapsed_min": 0.1,
    }


def _default_plan(n: int = 10) -> dict:
    return {
        "hypothesis": "Augment arithmetic failures",
        "rationale": "Most failures are arithmetic",
        "config_patches": {},
        "augment_focus": "focus on addition errors",
        "augment_n": n,
        "expected_improvement_pp": 5.0,
    }


def _mock_claude_response(examples=None):
    """Return a mock anthropic response containing a JSON array of examples."""
    if examples is None:
        examples = [{"user": "test", "assistant": '{"answer":1}'}]
    mock_resp = MagicMock()
    mock_resp.content = [MagicMock(text=json.dumps(examples))]
    return mock_resp


# ── Flywheel loop tests ────────────────────────────────────────────────────────

def test_flywheel_stops_at_target(tmp_path):
    """Loop exits early when accuracy >= target_accuracy."""
    project_dir, cfg = _make_project(tmp_path)

    eval_side_effects = [
        _fake_eval_result(0.70),
        _fake_eval_result(0.96),
    ]

    with patch("forge.core.trainer.run", return_value=_fake_train_result(project_dir)), \
         patch("forge.core.eval_runner.run", side_effect=eval_side_effects), \
         patch("forge.core.augmentor.run", return_value=1), \
         patch("forge.core.experiment_planner.plan", return_value=_default_plan()), \
         patch("forge.core.planner.update_plan"), \
         patch("forge.core.context.update"):

        import forge.commands.flywheel as fw_mod
        importlib.reload(fw_mod)
        result = fw_mod._run_flywheel(project_dir, cfg, max_iters=5)

    assert result["target_reached"] is True
    assert result["iterations_run"] == 2
    assert result["final_accuracy"] == pytest.approx(0.96)


def test_flywheel_stops_at_max_iters(tmp_path):
    """Loop exits after max_iters when target is never reached."""
    project_dir, cfg = _make_project(tmp_path)

    with patch("forge.core.trainer.run", return_value=_fake_train_result(project_dir)), \
         patch("forge.core.eval_runner.run", return_value=_fake_eval_result(0.50)), \
         patch("forge.core.augmentor.run", return_value=1), \
         patch("forge.core.experiment_planner.plan", return_value=_default_plan()), \
         patch("forge.core.planner.update_plan"), \
         patch("forge.core.context.update"):

        import forge.commands.flywheel as fw_mod
        importlib.reload(fw_mod)
        result = fw_mod._run_flywheel(project_dir, cfg, max_iters=3)

    assert result["target_reached"] is False
    assert result["iterations_run"] == 3


def test_flywheel_snapshots_best_adapter(tmp_path):
    """A new best_adapter_* directory is created when accuracy improves."""
    project_dir, cfg = _make_project(tmp_path)

    eval_side_effects = [
        _fake_eval_result(0.70),
        _fake_eval_result(0.80),
    ]

    with patch("forge.core.trainer.run", return_value=_fake_train_result(project_dir)), \
         patch("forge.core.eval_runner.run", side_effect=eval_side_effects), \
         patch("forge.core.augmentor.run", return_value=1), \
         patch("forge.core.experiment_planner.plan", return_value=_default_plan()), \
         patch("forge.core.planner.update_plan"), \
         patch("forge.core.context.update"):

        import forge.commands.flywheel as fw_mod
        importlib.reload(fw_mod)
        fw_mod._run_flywheel(project_dir, cfg, max_iters=2)

    best_dirs = list((project_dir / "output").glob("best_adapter_*"))
    assert len(best_dirs) >= 1, "Expected at least one best_adapter_* snapshot"


def test_flywheel_writes_experiments_jsonl(tmp_path):
    """experiments.jsonl has one entry per iteration with required fields."""
    project_dir, cfg = _make_project(tmp_path)

    with patch("forge.core.trainer.run", return_value=_fake_train_result(project_dir)), \
         patch("forge.core.eval_runner.run", return_value=_fake_eval_result(0.60)), \
         patch("forge.core.augmentor.run", return_value=1), \
         patch("forge.core.experiment_planner.plan", return_value=_default_plan()), \
         patch("forge.core.planner.update_plan"), \
         patch("forge.core.context.update"):

        import forge.commands.flywheel as fw_mod
        importlib.reload(fw_mod)
        fw_mod._run_flywheel(project_dir, cfg, max_iters=3)

    experiments_file = project_dir / "output" / "experiments.jsonl"
    assert experiments_file.exists(), "experiments.jsonl should be created"

    entries = [json.loads(line) for line in experiments_file.read_text().splitlines() if line.strip()]
    assert len(entries) == 3, f"Expected 3 entries, got {len(entries)}"

    for i, entry in enumerate(entries, start=1):
        assert entry["iteration"] == i
        assert "accuracy" in entry
        assert "loss" in entry
        assert "hypothesis" in entry
        assert "outcome" in entry


# ── Augmentor tests ────────────────────────────────────────────────────────────

def test_augmentor_appends_to_canonical(tmp_path):
    """augmentor.run appends valid examples to canonical.jsonl."""
    project_dir, cfg = _make_project(tmp_path)
    canonical_path = project_dir / "dataset" / "canonical.jsonl"
    initial_count = sum(1 for line in canonical_path.read_text().splitlines() if line.strip())

    failures = [
        {
            "index": 0,
            "category": "arithmetic",
            "input": "What is 5+3?",
            "expected": '{"answer":8}',
            "actual": "8",
            "error": "mismatch",
        }
    ]

    mock_resp = _mock_claude_response([{"user": "test", "assistant": '{"answer":1}'}])
    mock_anthropic = MagicMock()
    mock_client = MagicMock()
    mock_client.messages.create.return_value = mock_resp
    mock_anthropic.Anthropic.return_value = mock_client

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.core.augmentor as aug_mod
        importlib.reload(aug_mod)
        added = aug_mod.run(project_dir, cfg, failures)

    assert added == 1, f"Expected 1 appended example, got {added}"

    final_count = sum(1 for line in canonical_path.read_text().splitlines() if line.strip())
    assert final_count == initial_count + added

    lines = [l for l in canonical_path.read_text().splitlines() if l.strip()]
    last = json.loads(lines[-1])
    assert "messages" in last
    assert last["messages"][0]["role"] == "user"
    assert last["messages"][1]["role"] == "assistant"


def test_augmentor_uses_background_md(tmp_path):
    """When BACKGROUND.md exists, its content appears in the Claude API call prompt."""
    project_dir, cfg = _make_project(tmp_path)

    background_content = "UNIQUE_BACKGROUND_MARKER: always output cmd field as a string"
    (project_dir / "BACKGROUND.md").write_text(background_content)

    failures = [
        {
            "index": 0,
            "category": "routing",
            "input": "go north",
            "expected": '{"cmd":"move_north"}',
            "actual": "north",
            "error": "mismatch",
        }
    ]

    mock_resp = _mock_claude_response([{"user": "go south", "assistant": '{"cmd":"move_south"}'}])
    mock_anthropic = MagicMock()
    mock_client = MagicMock()
    mock_client.messages.create.return_value = mock_resp
    mock_anthropic.Anthropic.return_value = mock_client

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.core.augmentor as aug_mod
        importlib.reload(aug_mod)
        aug_mod.run(project_dir, cfg, failures)

    # Verify the prompt sent to Claude contained the background content
    assert mock_client.messages.create.called, "Claude API should have been called"
    call_kwargs = mock_client.messages.create.call_args
    messages = call_kwargs[1]["messages"] if call_kwargs[1] else call_kwargs[0][0]
    # Flatten all message content for inspection
    prompt_text = " ".join(
        m["content"] for m in (call_kwargs.kwargs.get("messages") or call_kwargs.args[0])
        if isinstance(m.get("content"), str)
    )
    assert background_content in prompt_text, (
        f"BACKGROUND.md content not found in Claude prompt.\n"
        f"Expected: {background_content!r}\n"
        f"Got prompt containing: {prompt_text[:300]!r}"
    )


# ── Experiment planner tests ───────────────────────────────────────────────────

def test_experiment_planner_returns_plan(tmp_path):
    """experiment_planner.plan returns a valid ExperimentPlan dict from Claude response."""
    project_dir, cfg = _make_project(tmp_path)

    plan_response = {
        "hypothesis": "Increase LoRA rank to capture more patterns",
        "rationale": "Low rank may be underfitting the arithmetic domain",
        "config_patches": {"lora": {"r": 64}},
        "augment_focus": "Generate diverse arithmetic addition examples",
        "augment_n": 30,
        "expected_improvement_pp": 5.0,
    }

    mock_resp = MagicMock()
    mock_resp.content = [MagicMock(text=json.dumps(plan_response))]
    mock_anthropic = MagicMock()
    mock_client = MagicMock()
    mock_client.messages.create.return_value = mock_resp
    mock_anthropic.Anthropic.return_value = mock_client

    failures = [_fake_eval_result(0.7)["failures"][0]]
    cfg["_anthropic_key"] = "sk-test-fake-key"

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.core.experiment_planner as planner_mod
        importlib.reload(planner_mod)
        result = planner_mod.plan(
            project_dir=project_dir,
            cfg=cfg,
            current_accuracy=0.7,
            failures=failures,
            experiment_history=[],
        )

    assert "hypothesis" in result
    assert "rationale" in result
    assert "config_patches" in result
    assert "augment_focus" in result
    assert "augment_n" in result
    assert "expected_improvement_pp" in result

    assert result["hypothesis"] == plan_response["hypothesis"]
    assert result["config_patches"] == {"lora": {"r": 64}}
    assert result["augment_n"] == 30
    assert result["expected_improvement_pp"] == pytest.approx(5.0)


def test_flywheel_applies_config_patch(tmp_path):
    """When ExperimentPlan has config_patches, trainer.run receives the patched cfg."""
    project_dir, cfg = _make_project(tmp_path)

    patched_plan = {
        "hypothesis": "Larger LoRA rank",
        "rationale": "test",
        "config_patches": {"lora": {"r": 128}},
        "augment_focus": "",
        "augment_n": 5,
        "expected_improvement_pp": 3.0,
    }

    trainer_calls: list[dict] = []

    def capture_train(project_dir, effective_cfg, epochs_override=None):
        trainer_calls.append(dict(effective_cfg))
        return _fake_train_result(project_dir)

    with patch("forge.core.trainer.run", side_effect=capture_train), \
         patch("forge.core.eval_runner.run", return_value=_fake_eval_result(0.50)), \
         patch("forge.core.augmentor.run", return_value=1), \
         patch("forge.core.experiment_planner.plan", return_value=patched_plan), \
         patch("forge.core.planner.update_plan"), \
         patch("forge.core.context.update"):

        import forge.commands.flywheel as fw_mod
        importlib.reload(fw_mod)
        fw_mod._run_flywheel(project_dir, cfg, max_iters=1)

    assert len(trainer_calls) >= 1, "trainer.run should have been called"
    effective_lora = trainer_calls[0].get("lora", {})
    assert effective_lora.get("r") == 128, (
        f"Expected patched lora.r=128, got {effective_lora.get('r')}"
    )


def test_heartbeat_written_each_iteration(tmp_path):
    """flywheel_heartbeat.json exists after each iteration with correct fields."""
    project_dir, cfg = _make_project(tmp_path)

    with patch("forge.core.trainer.run", return_value=_fake_train_result(project_dir)), \
         patch("forge.core.eval_runner.run", return_value=_fake_eval_result(0.60)), \
         patch("forge.core.augmentor.run", return_value=1), \
         patch("forge.core.experiment_planner.plan", return_value=_default_plan()), \
         patch("forge.core.planner.update_plan"), \
         patch("forge.core.context.update"):

        import forge.commands.flywheel as fw_mod
        importlib.reload(fw_mod)
        fw_mod._run_flywheel(project_dir, cfg, max_iters=2)

    heartbeat_path = project_dir / "output" / "flywheel_heartbeat.json"
    assert heartbeat_path.exists(), "flywheel_heartbeat.json should be created"

    hb = json.loads(heartbeat_path.read_text())
    assert "iteration" in hb
    assert "status" in hb
    assert "timestamp" in hb
    assert "accuracy" in hb
    assert hb["status"] == "completed"
    assert hb["iteration"] == 2  # last iteration written
