import pytest
from pathlib import Path
from forge.core.scorer import exact_scorer, json_cmd_scorer, load_scorer

def test_exact_scorer():
    expected = {"answer": 42}
    # Match
    assert exact_scorer(expected, '{"answer": 42}')["correct"] is True
    # Mismatch
    assert exact_scorer(expected, '{"answer": 43}')["correct"] is False
    # Invalid JSON
    assert exact_scorer(expected, 'not json')["correct"] is False

def test_json_cmd_scorer():
    expected = {"cmd": "goto", "alt": 100}
    # Exact match
    assert json_cmd_scorer(expected, '{"cmd": "goto", "alt": 100}')["correct"] is True
    # Extra field (allowed by scorer logic if cmd matches)
    assert json_cmd_scorer(expected, '{"cmd": "goto", "alt": 100, "speed": 5}')["correct"] is True
    # Missing field
    assert json_cmd_scorer(expected, '{"cmd": "goto"}')["correct"] is False
    # Wrong cmd
    assert json_cmd_scorer(expected, '{"cmd": "rtl", "alt": 100}')["correct"] is False

def test_load_scorer_builtin():
    scorer = load_scorer(Path("."), "exact")
    assert scorer == exact_scorer

def test_load_scorer_plugin(tmp_path):
    # Create a mock project dir with a scorer.py
    scorer_code = """
def score(expected, actual):
    return {"correct": True, "custom": "yes"}
"""
    scorer_file = tmp_path / "scorer.py"
    scorer_file.write_text(scorer_code)
    
    scorer = load_scorer(tmp_path, "custom")
    result = scorer({}, "")
    assert result["correct"] is True
    assert result["custom"] == "yes"


# ── json_cmd robustness tests ──────────────────────────────────────────────────

def test_json_cmd_int_answer():
    """{"answer": 42} (int) scored correctly."""
    expected = {"cmd": "answer", "answer": 42}
    result = json_cmd_scorer(expected, '{"cmd": "answer", "answer": 42}')
    assert result["correct"] is True


def test_json_cmd_string_answer():
    """{"answer": "42"} (string) coerced and scored correctly against int expected."""
    expected = {"cmd": "answer", "answer": 42}
    result = json_cmd_scorer(expected, '{"cmd": "answer", "answer": "42"}')
    assert result["correct"] is True


def test_json_cmd_extra_keys():
    """Extra keys in actual (e.g. reasoning) are ignored."""
    expected = {"cmd": "goto", "alt": 100}
    result = json_cmd_scorer(expected, '{"cmd": "goto", "alt": 100, "reasoning": "because"}')
    assert result["correct"] is True


def test_json_cmd_whitespace():
    """Whitespace around JSON string is stripped before parsing."""
    expected = {"cmd": "goto", "alt": 100}
    result = json_cmd_scorer(expected, '  { "cmd": "goto", "alt": 100 }  ')
    assert result["correct"] is True


# ── exact_scorer robustness tests ─────────────────────────────────────────────

def test_exact_scorer_int_answer():
    """exact_scorer: {"answer": 42} matches when actual has int 42."""
    expected = {"answer": 42}
    assert exact_scorer(expected, '{"answer": 42}')["correct"] is True


def test_exact_scorer_string_int_coercion():
    """exact_scorer: {"answer": "42"} coerced to match int expected 42."""
    expected = {"answer": 42}
    assert exact_scorer(expected, '{"answer": "42"}')["correct"] is True


def test_exact_scorer_extra_keys_ignored():
    """exact_scorer: extra keys in actual are ignored."""
    expected = {"answer": 42}
    assert exact_scorer(expected, '{"answer": 42, "reasoning": "step by step"}')["correct"] is True


def test_exact_scorer_whitespace():
    """exact_scorer: leading/trailing whitespace in actual string is handled."""
    expected = {"answer": 42}
    assert exact_scorer(expected, '  {"answer": 42}  ')["correct"] is True

