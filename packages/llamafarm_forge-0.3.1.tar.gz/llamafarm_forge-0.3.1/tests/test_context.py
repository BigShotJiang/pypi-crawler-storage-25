"""Tests for forge.core.context — update(), load(), truncation."""
from __future__ import annotations

import json
from pathlib import Path

import pytest


class TestLoad:
    def test_returns_empty_when_file_missing(self, tmp_path):
        from forge.core.context import load
        result = load(tmp_path)
        assert result == ""

    def test_returns_content_when_file_exists(self, tmp_path):
        ctx_file = tmp_path / "AGENT_CONTEXT.md"
        ctx_file.write_text("# Agent Context\n\nsome history here")
        from forge.core.context import load
        result = load(tmp_path)
        assert "some history here" in result

    def test_truncates_very_long_content(self, tmp_path):
        from forge.core.context import load, MAX_TOKENS
        # Write content longer than MAX_TOKENS * 4 chars
        long_content = "x" * (MAX_TOKENS * 4 + 1000)
        ctx_file = tmp_path / "AGENT_CONTEXT.md"
        ctx_file.write_text(long_content)
        result = load(tmp_path)
        # Should be truncated
        assert len(result) < len(long_content)
        assert "[truncated]" in result

    def test_short_content_not_truncated(self, tmp_path):
        from forge.core.context import load
        content = "# Short context\n\nOnly a few lines."
        ctx_file = tmp_path / "AGENT_CONTEXT.md"
        ctx_file.write_text(content)
        result = load(tmp_path)
        assert result == content


class TestUpdate:
    def test_creates_file_if_missing(self, tmp_path):
        from forge.core.context import update
        ctx_file = tmp_path / "AGENT_CONTEXT.md"
        assert not ctx_file.exists()

        update(
            project_dir=tmp_path,
            iteration=1,
            accuracy=0.876,
            failures=[{"gold_cmd": "takeoff", "reason": "wrong_cmd"}],
            train_file="dataset/canonical.jsonl",
            loss=0.1234,
        )
        assert ctx_file.exists()

    def test_file_contains_iteration_number(self, tmp_path):
        from forge.core.context import update
        update(
            project_dir=tmp_path,
            iteration=3,
            accuracy=0.912,
            failures=[],
            train_file="canonical.jsonl",
            loss=0.0987,
        )
        text = (tmp_path / "AGENT_CONTEXT.md").read_text()
        assert "Iteration 3" in text

    def test_file_contains_accuracy(self, tmp_path):
        from forge.core.context import update
        update(
            project_dir=tmp_path,
            iteration=2,
            accuracy=0.876,
            failures=[],
            train_file="canonical.jsonl",
            loss=0.15,
        )
        text = (tmp_path / "AGENT_CONTEXT.md").read_text()
        assert "87.6%" in text

    def test_failure_breakdown_included(self, tmp_path):
        from forge.core.context import update
        failures = [
            {"gold_cmd": "takeoff", "reason": "wrong_cmd"},
            {"gold_cmd": "takeoff", "reason": "wrong_cmd"},
            {"gold_cmd": "land", "reason": "wrong_cmd"},
        ]
        update(
            project_dir=tmp_path,
            iteration=1,
            accuracy=0.5,
            failures=failures,
            train_file="canonical.jsonl",
            loss=0.3,
        )
        text = (tmp_path / "AGENT_CONTEXT.md").read_text()
        assert "takeoff" in text

    def test_resolved_failures_detected(self, tmp_path):
        from forge.core.context import update
        prev = [{"gold_cmd": "land", "reason": "wrong_cmd"}]
        curr = []  # land fixed
        update(
            project_dir=tmp_path,
            iteration=2,
            accuracy=1.0,
            failures=curr,
            train_file="canonical.jsonl",
            loss=0.05,
            prev_failures=prev,
        )
        text = (tmp_path / "AGENT_CONTEXT.md").read_text()
        assert "Resolved" in text
        assert "land" in text

    def test_persistent_failures_detected(self, tmp_path):
        from forge.core.context import update
        failures = [{"gold_cmd": "disarm", "reason": "wrong_cmd"}]
        update(
            project_dir=tmp_path,
            iteration=2,
            accuracy=0.8,
            failures=failures,
            train_file="canonical.jsonl",
            loss=0.2,
            prev_failures=failures,  # same failures as before
        )
        text = (tmp_path / "AGENT_CONTEXT.md").read_text()
        assert "Persistent" in text

    def test_appends_on_subsequent_calls(self, tmp_path):
        from forge.core.context import update
        update(tmp_path, 1, 0.7, [], "c.jsonl", 0.3)
        update(tmp_path, 2, 0.8, [], "c.jsonl", 0.2)
        text = (tmp_path / "AGENT_CONTEXT.md").read_text()
        assert "Iteration 1" in text
        assert "Iteration 2" in text
