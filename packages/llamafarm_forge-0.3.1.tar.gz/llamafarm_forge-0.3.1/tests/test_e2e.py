"""End-to-end tests for forge CLI commands (mocked, no GPU)."""
from __future__ import annotations

import asyncio
import importlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, call, patch

import pytest
import yaml
from click.testing import CliRunner


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_project(tmp_path: Path, name: str = "test-e2e") -> tuple[Path, dict]:
    """Create a minimal forge project."""
    (tmp_path / "dataset").mkdir(exist_ok=True)
    (tmp_path / "output").mkdir(exist_ok=True)

    cfg = {
        "name": name,
        "model": {"base": "fake/model", "max_seq_len": 128, "load_in_4bit": False},
        "lora": {"r": 4, "alpha": 4, "dropout": 0.0, "target_modules": ["q_proj"]},
        "training": {
            "epochs_min": 1,
            "epochs_max": 2,
            "batch_size": 1,
            "gradient_accumulation_steps": 1,
            "learning_rate": 1e-4,
            "warmup_ratio": 0.1,
            "weight_decay": 0.0,
            "seed": 42,
        },
        "eval": {
            "target_accuracy": 0.95,
            "scorer": "exact",
            "max_new_tokens": 16,
            "forbidden_commands": [],
        },
        "dataset": {
            "canonical": "dataset/canonical.jsonl",
            "gold": "dataset/gold.jsonl",
        },
        "compute": {"device": "cpu"},
        "flywheel": {
            "max_iterations": 3,
            "augment_per_failure": 5,
            "datagen_model": "claude-3-5-haiku-20241022",
            "planner_model": "claude-3-5-haiku-20241022",
        },
    }
    (tmp_path / "forge.yaml").write_text(yaml.dump(cfg))
    (tmp_path / "system_prompt.md").write_text("You are a test assistant.")
    (tmp_path / "mission.md").write_text("Answer math questions as JSON.")
    (tmp_path / "BACKGROUND.md").write_text(
        "## Task\nAnswer math.\n\n"
        "## Output Format\n{\"answer\": <number>}\n\n"
        "## Edge Cases\nNegative numbers.\n\n"
        "## Common Failure Patterns\nOff-by-one.\n\n"
        "## What Good Examples Look Like\nVaried phrasing.\n"
    )

    examples = [
        {"messages": [{"role": "user", "content": "1+1?"}, {"role": "assistant", "content": '{"answer":2}'}]}
    ]
    (tmp_path / "dataset" / "canonical.jsonl").write_text(
        "\n".join(json.dumps(e) for e in examples) + "\n"
    )
    (tmp_path / "dataset" / "gold.jsonl").write_text(
        "\n".join(json.dumps(e) for e in examples) + "\n"
    )
    return tmp_path, cfg


def _run(coro):
    return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Test 1: forge --version
# ---------------------------------------------------------------------------

def test_forge_version_flag():
    """forge --version should print the version string."""
    from forge.cli import main
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert "0.2.0" in result.output
    assert "forge" in result.output.lower()


# ---------------------------------------------------------------------------
# Test 2: forge init creates llm.txt with project name
# ---------------------------------------------------------------------------

def test_forge_init_creates_llm_txt(tmp_path):
    """forge init should create llm.txt containing the project name."""
    from forge.cli import main
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(main, ["init", "my-e2e-project"])
        assert result.exit_code == 0, f"init failed: {result.output}"
        proj = Path("my-e2e-project")
        assert (proj / "llm.txt").exists(), "llm.txt was not created"
        content = (proj / "llm.txt").read_text()
        assert "my-e2e-project" in content, (
            f"Project name not found in llm.txt.\nContent: {content[:300]}"
        )


# ---------------------------------------------------------------------------
# Test 3: forge init creates BACKGROUND.md with all 5 required sections
# ---------------------------------------------------------------------------

def test_forge_init_creates_background_md(tmp_path):
    """forge init should create BACKGROUND.md with all 5 required sections."""
    from forge.cli import main
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(main, ["init", "bg-test-project"])
        assert result.exit_code == 0, f"init failed: {result.output}"
        bg_path = Path("bg-test-project") / "BACKGROUND.md"
        assert bg_path.exists(), "BACKGROUND.md was not created"
        content = bg_path.read_text()
        required_sections = [
            "Task",
            "Output Format",
            "Edge Cases",
            "Common Failure Patterns",
            "What Good Examples Look Like",
        ]
        for section in required_sections:
            assert section in content, (
                f"Required section '{section}' not found in BACKGROUND.md.\n"
                f"Content:\n{content}"
            )


# ---------------------------------------------------------------------------
# Test 4: forge status on fresh init shows "No eval results yet"
# ---------------------------------------------------------------------------

def test_forge_status_empty_project(tmp_path):
    """forge status on a fresh project (no best_score.json) should say 'No eval results yet'."""
    from forge.cli import main
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        # Init project
        runner.invoke(main, ["init", "status-test"])
        proj = Path("status-test")
        assert (proj / "forge.yaml").exists()

        # Status — no best_score.json yet
        result = runner.invoke(main, ["status", "--project", str(proj)])
        assert result.exit_code == 0, f"status failed: {result.output}"
        assert "No eval results yet" in result.output, (
            f"Expected 'No eval results yet' in output.\nGot:\n{result.output}"
        )


# ---------------------------------------------------------------------------
# Test 5: forge generate drops examples with invalid assistant JSON
# ---------------------------------------------------------------------------

def test_forge_generate_validates_bad_json(tmp_path):
    """generate should drop examples where assistant is not valid JSON."""
    project_dir, cfg = _make_project(tmp_path)

    # Mix of valid and invalid examples
    raw_examples = [
        {"user": "What is 2+2?", "assistant": '{"answer": 4}'},      # valid
        {"user": "What is 3+3?", "assistant": "{invalid json}"},       # invalid
        {"user": "What is 4+4?", "assistant": "just a string"},        # invalid (not JSON)
        {"user": "What is 5+5?", "assistant": '{"answer": 10}'},      # valid
    ]

    async def fake_create(**kwargs):
        mock_resp = MagicMock()
        mock_resp.content = [MagicMock(text=json.dumps(raw_examples))]
        return mock_resp

    mock_client = MagicMock()
    mock_client.messages = MagicMock()
    mock_client.messages.create = fake_create

    mock_anthropic = MagicMock()
    mock_anthropic.AsyncAnthropic.return_value = mock_client

    output_path = project_dir / "dataset" / "canonical.jsonl"
    # Start fresh
    output_path.write_text("")

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.generate as gen_mod
        importlib.reload(gen_mod)
        stats = _run(
            gen_mod.run_generate(
                project_dir=project_dir,
                cfg=cfg,
                n=10,
                batch_size=4,
                output_path=output_path,
            )
        )

    # Only 2 valid examples should be appended (the 2 with valid JSON)
    assert stats["n_valid"] == 2, f"Expected 2 valid, got {stats['n_valid']}"
    assert stats["n_appended"] == 2, f"Expected 2 appended, got {stats['n_appended']}"

    lines = [l for l in output_path.read_text().splitlines() if l.strip()]
    assert len(lines) == 2, f"Expected 2 lines in output, got {len(lines)}"
    for line in lines:
        record = json.loads(line)
        assistant_content = record["messages"][1]["content"]
        # Must be valid JSON
        parsed = json.loads(assistant_content)
        assert "answer" in parsed


# ---------------------------------------------------------------------------
# Test 6: forge audit severity level counting
# ---------------------------------------------------------------------------

def test_forge_audit_severity_levels(tmp_path):
    """run_audit should correctly count errors, warnings, and passed in summary stats."""
    project_dir, cfg = _make_project(tmp_path)

    # Write a dataset with 5 examples
    examples_data = [
        {"user": f"Q{i}?", "assistant": f'{{"answer": {i}}}'}
        for i in range(5)
    ]
    file_path = project_dir / "dataset" / "canonical.jsonl"
    lines = []
    for ex in examples_data:
        record = {
            "messages": [
                {"role": "user", "content": ex["user"]},
                {"role": "assistant", "content": ex["assistant"]},
            ]
        }
        lines.append(json.dumps(record))
    file_path.write_text("\n".join(lines) + "\n")

    # Mock Claude response: 2 errors, 1 warning, 2 ok
    audit_results = [
        {"index": 0, "format_ok": False, "correct": False, "consistent": True,
         "quality": "poor", "issue": "wrong format", "severity": "error", "suggested_fix": None},
        {"index": 1, "format_ok": True, "correct": False, "consistent": True,
         "quality": "ok", "issue": "wrong answer", "severity": "error", "suggested_fix": None},
        {"index": 2, "format_ok": True, "correct": True, "consistent": True,
         "quality": "ok", "issue": "minor phrasing", "severity": "warning", "suggested_fix": None},
        {"index": 3, "format_ok": True, "correct": True, "consistent": True,
         "quality": "good", "issue": None, "severity": "ok", "suggested_fix": None},
        {"index": 4, "format_ok": True, "correct": True, "consistent": True,
         "quality": "good", "issue": None, "severity": "ok", "suggested_fix": None},
    ]

    mock_resp = MagicMock()
    mock_resp.content = [MagicMock(text=json.dumps(audit_results))]
    mock_client = MagicMock()
    mock_client.messages = MagicMock()
    mock_client.messages.create = MagicMock(return_value=mock_resp)

    mock_anthropic = MagicMock()
    mock_anthropic.Anthropic.return_value = mock_client

    with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
        import forge.commands.audit as audit_mod
        importlib.reload(audit_mod)
        report = audit_mod.run_audit(
            project_dir=project_dir,
            cfg=cfg,
            file_path=file_path,
            fix=False,
        )

    stats = report["stats"]
    assert stats["total"] == 5
    assert stats["errors"] == 2, f"Expected 2 errors, got {stats['errors']}"
    assert stats["warnings"] == 1, f"Expected 1 warning, got {stats['warnings']}"
    assert stats["passed"] == 2, f"Expected 2 passed, got {stats['passed']}"
    assert abs(stats["pass_rate"] - 0.4) < 0.01, f"Expected pass_rate ~0.4, got {stats['pass_rate']}"


# ---------------------------------------------------------------------------
# Test 7: forge flywheel git commits after each iteration
# ---------------------------------------------------------------------------

def test_forge_flywheel_git_commits_after_iter(tmp_path):
    """_run_flywheel should call git commit with the correct message format after each iteration."""
    from forge.commands.flywheel import _run_flywheel

    project_dir, cfg = _make_project(tmp_path)
    (project_dir / "output" / "adapter").mkdir(parents=True, exist_ok=True)

    def fake_train(project_dir, cfg, epochs_override=None):
        return {
            "adapter_dir": str(project_dir / "output" / "adapter"),
            "final_loss": 0.1,
            "epochs_run": 1,
            "train_examples": 10,
        }

    def fake_eval(project_dir, cfg, adapter_path):
        return {
            "accuracy": 0.60,
            "correct": 6,
            "total": 10,
            "safety_violations": 0,
            "passed": False,
            "per_category": {},
            "failures": [],
            "elapsed_min": 0.1,
        }

    default_plan = {
        "hypothesis": "Test hypothesis for commit message",
        "rationale": "testing",
        "config_patches": {},
        "forge_yaml_patches": {},
        "background_additions": "",
        "augment_focus": "",
        "augment_n": 2,
        "expected_improvement_pp": 1.0,
    }

    commit_calls: list[list] = []

    def fake_subprocess_run(cmd, **kwargs):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = b"" if isinstance(cmd, list) else ""
        if isinstance(cmd, list) and "commit" in cmd:
            commit_calls.append(cmd)
        return mock_result

    with patch("forge.core.trainer.run", side_effect=fake_train), \
         patch("forge.core.eval_runner.run", side_effect=fake_eval), \
         patch("forge.core.augmentor.run", return_value=0), \
         patch("forge.core.experiment_planner.plan", return_value=default_plan), \
         patch("forge.core.planner.update_plan"), \
         patch("forge.core.context.update"), \
         patch("forge.commands.flywheel.subprocess.run", side_effect=fake_subprocess_run):

        import forge.commands.flywheel as fw_mod
        importlib.reload(fw_mod)
        result = fw_mod._run_flywheel(project_dir, cfg, max_iters=2)

    assert result["iterations_run"] == 2

    # Should have git commit calls (one per iteration)
    commit_msgs = [
        " ".join(cmd) for cmd in commit_calls if "commit" in cmd
    ]
    assert len(commit_msgs) >= 2, (
        f"Expected at least 2 git commits, got {len(commit_msgs)}.\n"
        f"All subprocess calls with commit: {commit_msgs}"
    )

    # Each commit message should follow "forge iter N: X.X% — hypothesis" format
    for msg_cmd in commit_calls:
        if "commit" in msg_cmd:
            # Find the -m argument
            try:
                m_idx = msg_cmd.index("-m")
                commit_msg = msg_cmd[m_idx + 1]
                assert "forge iter" in commit_msg, (
                    f"Commit message should start with 'forge iter': {commit_msg!r}"
                )
                assert "%" in commit_msg, (
                    f"Commit message should include accuracy %: {commit_msg!r}"
                )
            except (ValueError, IndexError):
                # --allow-empty flag; check next index
                pass
