"""Unit tests for forge.core.trainer — mocked, no GPU required."""
import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock


def _make_project(tmp_path: Path, canonical_count: int = 5) -> Path:
    """Scaffold a minimal forge project in tmp_path."""
    (tmp_path / "dataset").mkdir()
    (tmp_path / "output").mkdir()

    # forge.yaml
    cfg = {
        "name": "test-project",
        "model": {"base": "fake/model", "max_seq_len": 128, "load_in_4bit": False},
        "lora": {
            "r": 4, "alpha": 4, "dropout": 0.0,
            "target_modules": ["q_proj", "v_proj"],
        },
        "training": {
            "epochs_min": 1, "epochs_max": 2, "batch_size": 1,
            "gradient_accumulation_steps": 1, "learning_rate": 1e-4,
            "warmup_ratio": 0.1, "weight_decay": 0.0, "seed": 42,
        },
        "eval": {"target_accuracy": 0.95, "scorer": "exact", "max_new_tokens": 16, "forbidden_commands": []},
        "dataset": {"canonical": "dataset/canonical.jsonl", "gold": "dataset/gold.jsonl"},
        "compute": {"device": "cpu"},
        "flywheel": {"max_iterations": 5, "augment_per_failure": 5, "datagen_model": "fake"},
    }
    import yaml
    (tmp_path / "forge.yaml").write_text(yaml.dump(cfg))

    # system_prompt.md
    (tmp_path / "system_prompt.md").write_text("You are a math solver. Output JSON only.")

    # canonical.jsonl
    examples = []
    for i in range(canonical_count):
        ex = {"messages": [
            {"role": "user", "content": f"What is {i} + 1?"},
            {"role": "assistant", "content": json.dumps({"answer": i + 1})},
        ]}
        examples.append(json.dumps(ex))
    (tmp_path / "dataset" / "canonical.jsonl").write_text("\n".join(examples))

    # gold.jsonl
    (tmp_path / "dataset" / "gold.jsonl").write_text("\n".join(examples))

    return tmp_path


def test_trainer_run_calls_model_save(tmp_path):
    """trainer.run should complete and return expected keys."""
    project_dir = _make_project(tmp_path)

    import yaml
    cfg = yaml.safe_load((project_dir / "forge.yaml").read_text())

    mock_model = MagicMock()
    mock_tokenizer = MagicMock()
    mock_tokenizer.apply_chat_template.return_value = "fake text"

    mock_fast_model = MagicMock()
    mock_fast_model.from_pretrained.return_value = (mock_model, mock_tokenizer)
    mock_fast_model.get_peft_model.return_value = mock_model

    mock_trainer = MagicMock()
    mock_trainer_instance = MagicMock()
    mock_trainer.return_value = mock_trainer_instance

    mock_dataset = MagicMock()
    mock_dataset.__len__ = lambda self: 5
    mock_dataset_cls = MagicMock()
    mock_dataset_cls.from_list.return_value = mock_dataset

    with patch.dict("sys.modules", {
        "unsloth": MagicMock(FastModel=mock_fast_model),
        "trl": MagicMock(SFTTrainer=mock_trainer, SFTConfig=MagicMock()),
        "datasets": MagicMock(Dataset=mock_dataset_cls),
        "transformers": MagicMock(TrainerCallback=object),
        "torch": MagicMock(
            cuda=MagicMock(is_available=lambda: False, is_bf16_supported=lambda: False),
            __version__="2.0.0",
        ),
    }):
        from forge.core import trainer
        import importlib
        importlib.reload(trainer)
        result = trainer.run(project_dir, cfg, epochs_override=1)

    assert "adapter_dir" in result
    assert "final_loss" in result
    assert "epochs_run" in result
    assert result["epochs_run"] == 1
    assert result["train_examples"] == 5


def test_trainer_raises_on_missing_dataset(tmp_path):
    """trainer.run should raise FileNotFoundError if canonical.jsonl is missing."""
    project_dir = _make_project(tmp_path)
    (project_dir / "dataset" / "canonical.jsonl").unlink()

    import yaml
    cfg = yaml.safe_load((project_dir / "forge.yaml").read_text())

    with pytest.raises(FileNotFoundError):
        from forge.core import trainer
        trainer.run(project_dir, cfg)
