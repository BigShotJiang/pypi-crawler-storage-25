"""forge cloud-pull — download cloud training run artifacts for local eval.

Pulls predictions, gold set, adapter, and manifest from a GCS run path.
Then runs local eval (Claude-as-judge batch) without any GPU.

Usage:
  forge cloud-pull --run run-0331-2115              # pull latest by run ID
  forge cloud-pull --run run-0331-2115 --eval       # pull + run batch eval
  forge cloud-pull --list                           # list available runs
"""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from forge.core import config

console = Console()


@click.command()
@click.option("--run", default=None, help="Run ID to pull (e.g. run-0331-2115)")
@click.option("--list", "list_runs", is_flag=True, help="List available runs in GCS")
@click.option("--eval", "run_eval", is_flag=True, help="After pull, run batch eval locally")
@click.option("--bucket", default=None, help="GCS bucket (default: from forge.yaml cloud.gcs_bucket)")
@click.option("--out", default=None, help="Local output directory (default: output/cloud-runs/<run_id>)")
@click.option("--project", "-p", default=None, help="Project directory")
def cloud_pull(
    run: str | None,
    list_runs: bool,
    run_eval: bool,
    bucket: str | None,
    out: str | None,
    project: str | None,
):
    """Pull cloud training artifacts and optionally run local eval.

    \b
    Downloads from GCS:
      adapter/           → LoRA weights
      eval/predictions.jsonl → model outputs (generated on GPU VM)
      eval/run_manifest.json → links run ID, gold hash, model info
      eval/*.jsonl       → gold eval set copy

    \b
    Then optionally runs:
      forge eval (Claude-as-judge batch, no GPU, runs locally on pasture1)

    \b
    Examples:
      forge cloud-pull --list                    # see all runs
      forge cloud-pull --run run-0331-2115       # download artifacts
      forge cloud-pull --run run-0331-2115 --eval  # download + evaluate
    """
    project_dir = Path(project) if project else config.find_project_root()
    cfg = config.load(project_dir) if project_dir else {}
    gcs_bucket = bucket or cfg.get("cloud", {}).get("gcs_bucket", "gs://llamafarm-forge")

    if list_runs:
        _list_runs(gcs_bucket)
        return

    if not run:
        console.print("[red]Specify --run <run_id> or use --list to see available runs.[/red]")
        raise SystemExit(1)

    gcs_run = f"{gcs_bucket}/runs/{run}"

    # Check sentinel
    rc, _ = _gsutil(["gsutil", "ls", f"{gcs_run}/artifacts-complete"], capture=True)
    if rc != 0:
        console.print(f"[red]Run '{run}' not found or incomplete at {gcs_run}[/red]")
        raise SystemExit(1)

    # Set up local output dir
    local_dir = Path(out) if out else (project_dir or Path.cwd()) / "output" / "cloud-runs" / run
    local_dir.mkdir(parents=True, exist_ok=True)
    adapter_dir = local_dir / "adapter"
    eval_dir = local_dir / "eval"
    logs_dir = local_dir / "logs"
    adapter_dir.mkdir(exist_ok=True)
    eval_dir.mkdir(exist_ok=True)
    logs_dir.mkdir(exist_ok=True)

    console.print(Panel(
        f"[bold]forge cloud-pull[/bold]\n"
        f"Run:    [cyan]{run}[/cyan]\n"
        f"Source: [dim]{gcs_run}[/dim]\n"
        f"Target: [dim]{local_dir}[/dim]",
        border_style="blue",
    ))

    # Pull adapter
    console.print("  Pulling adapter weights...")
    _gsutil(["gsutil", "-m", "cp", "-r", f"{gcs_run}/adapter/*", str(adapter_dir) + "/"])

    # Pull eval artifacts
    console.print("  Pulling eval artifacts...")
    _gsutil(["gsutil", "-m", "cp", f"{gcs_run}/eval/*", str(eval_dir) + "/"])

    # Pull logs
    console.print("  Pulling logs...")
    _gsutil(["gsutil", "-m", "cp", f"{gcs_run}/logs/*", str(logs_dir) + "/"], ignore_errors=True)

    # Show manifest
    manifest_path = eval_dir / "run_manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        table = Table(title=f"Run Manifest: {run}")
        table.add_column("Key", style="bold")
        table.add_column("Value")
        for k, v in manifest.items():
            table.add_row(k, str(v))
        console.print(table)
    else:
        console.print("[yellow]⚠ No run_manifest.json found[/yellow]")

    # Verify predictions exist
    pred_path = eval_dir / "predictions.jsonl"
    if pred_path.exists():
        pred_count = sum(1 for l in pred_path.read_text().splitlines() if l.strip())
        console.print(f"  [green]✓[/green] Predictions: {pred_count} examples")
    else:
        console.print("[red]✗ predictions.jsonl not found — inference may have failed[/red]")
        if not run_eval:
            raise SystemExit(1)

    # Find gold set
    gold_path = None
    for f in eval_dir.iterdir():
        if f.name.endswith(".jsonl") and "gold" in f.name:
            gold_path = f
            break
    if gold_path:
        gold_count = sum(1 for l in gold_path.read_text().splitlines() if l.strip())
        console.print(f"  [green]✓[/green] Gold set: {gold_count} examples ({gold_path.name})")
    else:
        console.print("[yellow]⚠ No gold set found in eval/ — will need to specify for eval[/yellow]")

    console.print(f"\n  [green]✓ Pull complete[/green] → {local_dir}")

    # Run eval if requested
    if run_eval:
        console.print("\n  Running batch eval (Claude-as-judge, local, no GPU)...")
        if not pred_path.exists():
            console.print("[red]Cannot eval: predictions.jsonl missing[/red]")
            raise SystemExit(1)
        if not gold_path:
            console.print("[red]Cannot eval: gold set not found[/red]")
            raise SystemExit(1)

        # Try to use forge eval, fall back to direct batch judge
        try:
            api_key = os.environ.get("ANTHROPIC_API_KEY", "")
            if not api_key and project_dir:
                for env_path in [project_dir / ".env", Path("/mnt/nvmera/home/robert/llamadrone-mission-router/.env")]:
                    if env_path.exists():
                        for line in env_path.read_text().splitlines():
                            if line.startswith("ANTHROPIC_API_KEY="):
                                api_key = line.split("=", 1)[1].strip()
                                break
                    if api_key:
                        break

            from forge.core.batch_judge import BatchJudge
            judge = BatchJudge(api_key=api_key, model="claude-sonnet-4-6")

            gold = [json.loads(l) for l in gold_path.read_text().splitlines() if l.strip()]
            preds = [json.loads(l) for l in pred_path.read_text().splitlines() if l.strip()]

            # Normalize gold to flat format for judge
            def flatten(ex):
                if "messages" in ex:
                    msgs = ex["messages"]
                    return {
                        "system": next((m["content"] for m in msgs if m["role"] == "system"), ""),
                        "user": next((m["content"] for m in msgs if m["role"] == "user"), ""),
                        "assistant": next((m["content"] for m in msgs if m["role"] == "assistant"), ""),
                    }
                return ex

            gold_flat = [flatten(g) for g in gold]
            scores = judge.score_all(gold_flat, preds)
            summary = judge.summary(scores)

            # Write scores
            scores_path = eval_dir / "scores.jsonl"
            scores_path.write_text("\n".join(json.dumps(s) for s in scores) + "\n")

            summary_path = eval_dir / "eval_summary.json"
            summary_path.write_text(json.dumps(summary, indent=2))

            console.print(Panel(
                f"[bold]Eval Results — {run}[/bold]\n\n"
                f"Passing (≥8/10): [{'green' if summary['pass_rate'] >= 0.9 else 'red'}]"
                f"{summary['passing']}/{summary['total']} ({summary['pass_rate']*100:.1f}%)[/]\n"
                f"Mean score:      {summary['mean_score']:.2f}/10\n\n"
                f"Per dimension:\n"
                + "\n".join(f"  {d}: {v:.2f}/2" for d, v in summary["per_dimension"].items())
                + f"\n\nScores: [dim]{scores_path}[/dim]\n"
                f"Summary: [dim]{summary_path}[/dim]",
                title="forge cloud-pull --eval",
                border_style="green" if summary["pass_rate"] >= 0.9 else "red",
            ))
        except Exception as e:
            console.print(f"[red]Batch eval failed: {e}[/red]")
            console.print("[dim]Run manually: forge eval --model_output eval/predictions.jsonl --gold eval/<gold>.jsonl[/dim]")


def _list_runs(bucket: str):
    """List available runs in GCS bucket."""
    rc, out = _gsutil(["gsutil", "ls", f"{bucket}/runs/"], capture=True)
    if rc != 0 or not out:
        console.print("[yellow]No runs found.[/yellow]")
        return

    runs = []
    for line in out.strip().splitlines():
        line = line.strip().rstrip("/")
        if not line:
            continue
        run_id = line.split("/")[-1]
        # Check for sentinel
        sentinel_rc, _ = _gsutil(
            ["gsutil", "ls", f"{bucket}/runs/{run_id}/artifacts-complete"],
            capture=True,
        )
        status = "✅ complete" if sentinel_rc == 0 else "⚠ incomplete"
        runs.append((run_id, status))

    table = Table(title="Cloud Training Runs")
    table.add_column("Run ID", style="cyan")
    table.add_column("Status")
    for run_id, status in sorted(runs):
        table.add_row(run_id, status)
    console.print(table)


def _gsutil(cmd: list[str], capture: bool = False, ignore_errors: bool = False) -> tuple[int, str]:
    if capture:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        return r.returncode, r.stdout.strip()
    else:
        r = subprocess.run(cmd, timeout=300)
        if r.returncode != 0 and not ignore_errors:
            console.print(f"[yellow]gsutil warning: exit {r.returncode}[/yellow]")
        return r.returncode, ""
