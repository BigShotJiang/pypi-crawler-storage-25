"""forge cloud — GCP provider.

Uses `gcloud` CLI (no Python SDK dependency). Tailscale handles SSH
so we never rely on GCP's ephemeral external IPs or IAP tunnels.

GPU mappings:
  a100  → a2-highgpu-1g  (A100 40GB, us-central1-a)
  l4    → g2-standard-4  (L4 24GB, us-central1-b)
  h100  → a3-highgpu-1g  (H100 80GB, us-central1-a) — expensive, rarely needed
  none  → n1-standard-4  (CPU only, for testing)
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from textwrap import dedent
from typing import Optional

from forge.cloud.providers.base import BaseProvider, VMInfo, VMSpec

# ── GPU → machine type mapping ───────────────────────────────────────────────
GPU_MACHINE_TYPES = {
    "a100": ("a2-highgpu-1g",   "nvidia-tesla-a100", 1, "us-central1-a"),
    "l4":   ("g2-standard-4",   "nvidia-l4",         1, "us-central1-b"),
    "h100": ("a3-highgpu-1g",   "nvidia-h100-80gb",  1, "us-central1-a"),
    "none": ("n1-standard-4",   None,                0, "us-central1-a"),
}

# Deep Learning VM image — has CUDA + PyTorch pre-installed
# NOTE: pytorch-latest-gpu is GONE as of 2026. Use explicit versioned family.
DL_IMAGE_FAMILY = "pytorch-2-7-cu128-ubuntu-2204-nvidia-570"
DL_IMAGE_PROJECT = "deeplearning-platform-release"
MIN_DISK_GB = 100  # DL VM image requires >= 100GB

FORGE_READY_SIGNAL = "/tmp/forge-ready"


def _run(cmd: list[str], capture: bool = True, timeout: int = 300) -> tuple[int, str]:
    """Run a subprocess. Returns (returncode, output)."""
    if capture:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout + r.stderr).strip()
    else:
        r = subprocess.run(cmd, timeout=timeout)
        return r.returncode, ""


class GCPProvider(BaseProvider):
    name = "gcp"

    def __init__(self, cfg: dict):
        super().__init__(cfg)
        self.project   = cfg.get("project", "")
        self.zone      = cfg.get("zone", "us-central1-a")
        self.bucket    = cfg.get("gcs_bucket", "").rstrip("/")
        self.ts_key    = cfg.get("tailscale_auth_key", "")
        self.tags      = cfg.get("tags", ["forge-managed"])

        if not self.project:
            # Fall back to active gcloud project
            rc, out = _run(["gcloud", "config", "get-value", "project"])
            if rc == 0 and out:
                self.project = out.strip()

        if not shutil.which("gcloud"):
            raise RuntimeError("gcloud CLI not found. Install Google Cloud SDK.")

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def create_vm(self, spec: VMSpec) -> VMInfo:
        gpu = spec.gpu.lower()
        if gpu not in GPU_MACHINE_TYPES:
            raise ValueError(f"Unknown GPU type: {gpu}. Valid: {list(GPU_MACHINE_TYPES)}")

        machine_type, accel_type, accel_count, default_zone = GPU_MACHINE_TYPES[gpu]
        zone = spec.region or default_zone

        # Enforce minimum disk size for DL VM image
        disk_gb = max(spec.disk_gb, MIN_DISK_GB)

        startup = self._build_startup_script(spec)

        cmd = [
            "gcloud", "compute", "instances", "create", spec.name,
            f"--project={self.project}",
            f"--zone={zone}",
            f"--machine-type={machine_type}",
            f"--image-family={DL_IMAGE_FAMILY}",
            f"--image-project={DL_IMAGE_PROJECT}",
            f"--boot-disk-size={disk_gb}GB",
            "--boot-disk-type=pd-ssd",
            "--metadata-from-file=startup-script=/dev/stdin",
            "--scopes=cloud-platform",  # needed for gsutil from VM
            f"--labels=forge-managed=true,forge-run={spec.name}",
            "--format=json",
        ]

        if accel_type and accel_count > 0:
            cmd += [
                f"--accelerator=type={accel_type},count={accel_count}",
                "--maintenance-policy=TERMINATE",
            ]

        rc, out = self._run_with_stdin(cmd, startup)
        if rc != 0:
            raise RuntimeError(f"gcloud create failed:\n{out}")

        try:
            data = json.loads(out)[0]
        except Exception:
            data = {}

        return VMInfo(
            name=spec.name,
            provider="gcp",
            status="running",
            region=zone,
            external_ip=self._extract_ip(data),
            metadata={"tags": spec.tags, "zone": zone, "raw": data},
        )

    def wait_ready(self, vm: VMInfo, timeout_seconds: int = 600) -> VMInfo:
        """
        Wait for:
          1. VM to join Tailscale (poll `tailscale status --json`)
          2. Startup script to write /tmp/forge-ready
        """
        deadline = time.time() + timeout_seconds
        hostname = None

        # Phase 1: wait for Tailscale join
        while time.time() < deadline:
            hostname = self._find_tailscale_host(vm.name)
            if hostname:
                break
            time.sleep(10)

        if not hostname:
            raise TimeoutError(
                f"VM '{vm.name}' did not appear on Tailscale within {timeout_seconds}s"
            )

        vm.tailscale_hostname = hostname

        # Phase 2: wait for startup script to complete
        while time.time() < deadline:
            rc, _ = self.run_ssh(vm, f"test -f {FORGE_READY_SIGNAL}", capture=True, timeout=15)
            if rc == 0:
                return vm
            time.sleep(15)

        raise TimeoutError(
            f"VM '{vm.name}' startup script did not complete within {timeout_seconds}s\n"
            f"SSH to {hostname} and check /var/log/syslog for startup errors."
        )

    def delete_vm(self, vm: VMInfo) -> None:
        """Delete VM — ONLY if forge-managed label is present."""
        # Verify label via API before deleting
        zone = vm.metadata.get("zone", self.zone)
        rc, out = _run([
            "gcloud", "compute", "instances", "describe", vm.name,
            f"--project={self.project}",
            f"--zone={zone}",
            "--format=json(labels)",
        ])
        if rc != 0:
            raise RuntimeError(f"Could not describe VM '{vm.name}': {out}")

        try:
            labels = json.loads(out).get("labels", {})
        except Exception:
            labels = {}

        if labels.get("forge-managed") != "true":
            raise RuntimeError(
                f"[SAFETY] Refusing to delete '{vm.name}' — "
                f"forge-managed=true label not found. Labels: {labels}\n"
                f"This VM was not created by forge and will not be touched."
            )

        rc, out = _run([
            "gcloud", "compute", "instances", "delete", vm.name,
            f"--project={self.project}",
            f"--zone={zone}",
            "--quiet",
        ])
        if rc != 0:
            raise RuntimeError(f"Failed to delete VM '{vm.name}': {out}")

    def list_vms(self, tag: str = "forge-managed") -> list[VMInfo]:
        rc, out = _run([
            "gcloud", "compute", "instances", "list",
            f"--project={self.project}",
            f"--filter=labels.{tag}=true",
            "--format=json(name,zone,status,labels,networkInterfaces)",
        ])
        if rc != 0 or not out:
            return []
        try:
            items = json.loads(out)
        except Exception:
            return []
        vms = []
        for item in items:
            zone = item.get("zone", "").split("/")[-1]
            vms.append(VMInfo(
                name=item.get("name", "?"),
                provider="gcp",
                status=item.get("status", "?").lower(),
                region=zone,
                metadata={"tags": [tag], "zone": zone, "labels": item.get("labels", {})},
            ))
        return vms

    # ── Remote execution ──────────────────────────────────────────────────────

    def run_ssh(
        self,
        vm: VMInfo,
        command: str,
        capture: bool = False,
        timeout: int = 3600,
    ) -> tuple[int, str]:
        if not vm.tailscale_hostname:
            raise RuntimeError(f"VM '{vm.name}' has no Tailscale hostname yet. Call wait_ready first.")

        ssh_cmd = [
            "ssh",
            "-o", "StrictHostKeyChecking=no",
            "-o", "ConnectTimeout=15",
            "-o", "ServerAliveInterval=60",
            "-o", "ServerAliveCountMax=5",
            vm.tailscale_hostname,
            command,
        ]

        if capture:
            r = subprocess.run(ssh_cmd, capture_output=True, text=True, timeout=timeout)
            return r.returncode, (r.stdout + r.stderr).strip()
        else:
            r = subprocess.run(ssh_cmd, timeout=timeout)
            return r.returncode, ""

    # ── Artifact store (GCS) ─────────────────────────────────────────────────

    def upload_to_store(self, local_path: str, remote_path: str) -> None:
        """Upload local path to GCS. Handles both files and directories."""
        p = Path(local_path)
        cmd = ["gsutil", "-m", "cp", "-r", str(p), remote_path]
        rc, out = _run(cmd, capture=False, timeout=600)
        if rc != 0:
            raise RuntimeError(f"gsutil upload failed: {out}")

    def download_from_store(self, remote_path: str, local_path: str) -> None:
        Path(local_path).mkdir(parents=True, exist_ok=True)
        cmd = ["gsutil", "-m", "cp", "-r", remote_path, local_path]
        rc, out = _run(cmd, capture=False, timeout=600)
        if rc != 0:
            raise RuntimeError(f"gsutil download failed: {out}")

    def store_exists(self, remote_path: str) -> bool:
        rc, _ = _run(["gsutil", "ls", remote_path])
        return rc == 0

    # ── Startup script ────────────────────────────────────────────────────────

    def _build_startup_script(self, spec: VMSpec) -> str:
        bucket = self.bucket
        ts_key = spec.tailscale_auth_key or self.ts_key
        vm_name = spec.name
        run_id = spec.startup_env.get("FORGE_RUN_ID", "run")
        env_exports = "\n".join(
            f"export {k}=\"{v}\"" for k, v in spec.startup_env.items()
        )

        return dedent(f"""\
            #!/usr/bin/env bash
            set -euo pipefail
            exec > /tmp/forge-startup.log 2>&1

            echo "[forge-startup] Begin $(date -u)"

            # ── System deps ──────────────────────────────────────────────
            apt-get update -qq
            apt-get install -y -qq curl jq

            # ── Tailscale ─────────────────────────────────────────────────
            echo "[forge-startup] Installing Tailscale..."
            curl -fsSL https://tailscale.com/install.sh | sh
            tailscale up --authkey="{ts_key}" --hostname="{vm_name}" --accept-routes
            echo "[forge-startup] Tailscale joined as {vm_name}"

            # ── Python env ────────────────────────────────────────────────
            # DL VM image has Python 3.10+ and CUDA pre-installed.
            # Use $HOME/workspace — /workspace is root-owned on DL images.
            export WS=$HOME/workspace
            mkdir -p $WS/data/canonical $WS/eval $WS/output $WS/outputs/gguf

            echo "[forge-startup] Installing forge + deps..."
            pip install --quiet llamafarm-forge
            pip install --quiet 'jinja2>=3.1'
            pip install --quiet flash-linear-attention
            pip install --quiet unsloth peft trl datasets
            pip install --quiet --no-build-isolation causal_conv1d==1.6.0 || echo "[warn] causal_conv1d failed"
            export PATH=$PATH:$HOME/.local/bin
            echo "export PATH=\\$PATH:$HOME/.local/bin" >> $HOME/.bashrc

            # ── Pull project from GCS ─────────────────────────────────────
            echo "[forge-startup] Pulling project from GCS..."
            gsutil cp "{bucket}/{run_id}/forge.yaml" $WS/forge.yaml || gsutil cp "{bucket}/forge.yaml" $WS/forge.yaml || echo "[warn] no forge.yaml"

            # Pull datasets — handle both flat and nested GCS paths
            for f in $(gsutil ls "{bucket}/{run_id}/datasets/" 2>/dev/null || gsutil ls "{bucket}/datasets/" 2>/dev/null); do
                fname=$(basename $f)
                case $fname in
                    *canonical*) gsutil cp "$f" $WS/data/canonical/$fname ;;
                    *gold*)      gsutil cp "$f" $WS/eval/$fname ;;
                    *)           gsutil cp "$f" $WS/data/$fname ;;
                esac
            done
            echo "[forge-startup] Data pulled"

            # ── Model cache — pull from GCS if available, else download ────
            MODEL_NAME=$(python3 -c "import yaml; print(yaml.safe_load(open('$WS/forge.yaml'))['model']['base'])" 2>/dev/null || echo "")
            SAFE_NAME=$(echo "$MODEL_NAME" | tr '/' '-')
            MODEL_CACHED=$(gsutil ls "{bucket}/model-cache/$SAFE_NAME/" 2>/dev/null | wc -l || echo 0)

            if [ "$MODEL_CACHED" -gt "5" ]; then
                echo "[forge-startup] Pulling cached model from GCS..."
                mkdir -p $WS/model-cache/$SAFE_NAME
                gsutil -m cp -r "{bucket}/model-cache/$SAFE_NAME/*" $WS/model-cache/$SAFE_NAME/
            else
                echo "[forge-startup] Downloading model from HuggingFace..."
                python3 -c "from huggingface_hub import snapshot_download; snapshot_download('$MODEL_NAME', local_dir='$WS/model-cache/$SAFE_NAME')"
                echo "[forge-startup] Caching model to GCS (background)..."
                nohup gsutil -m cp -r $WS/model-cache/$SAFE_NAME/ "{bucket}/model-cache/$SAFE_NAME/" > /tmp/model-cache.log 2>&1 &
            fi

            # Patch forge.yaml with local model path
            python3 -c "
import yaml; from pathlib import Path; import os
ws = Path(os.path.expanduser('~/workspace'))
cfg = yaml.safe_load((ws / 'forge.yaml').read_text())
safe = cfg['model']['base'].replace('/', '-')
cfg['model']['base'] = str(ws / 'model-cache' / safe)
(ws / 'forge.yaml').write_text(yaml.dump(cfg, default_flow_style=False))
print(f'forge.yaml patched: model -> {{cfg[\"model\"][\"base\"]}}')
"

            # ── Extra env vars ────────────────────────────────────────────
            {env_exports}

            # ── Signal ready ──────────────────────────────────────────────
            touch /tmp/forge-ready
            echo "[forge-startup] Ready at $(date -u)"
        """)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _find_tailscale_host(self, vm_name: str) -> Optional[str]:
        """Return Tailscale hostname if vm_name is in `tailscale status`."""
        rc, out = _run(["tailscale", "status", "--json"], timeout=15)
        if rc != 0 or not out:
            return None
        try:
            data = json.loads(out)
            peers = data.get("Peer", {})
            for peer in peers.values():
                hostname = peer.get("HostName", "")
                if hostname == vm_name or hostname.startswith(vm_name):
                    dns = peer.get("DNSName", "").rstrip(".")
                    return dns or hostname
        except Exception:
            pass
        return None

    def _extract_ip(self, data: dict) -> str:
        try:
            return data["networkInterfaces"][0]["accessConfigs"][0]["natIP"]
        except (KeyError, IndexError):
            return ""

    def _run_with_stdin(self, cmd: list[str], stdin_data: str) -> tuple[int, str]:
        """Run command with stdin data piped in."""
        r = subprocess.run(
            cmd,
            input=stdin_data,
            capture_output=True,
            text=True,
            timeout=120,
        )
        return r.returncode, (r.stdout + r.stderr).strip()
