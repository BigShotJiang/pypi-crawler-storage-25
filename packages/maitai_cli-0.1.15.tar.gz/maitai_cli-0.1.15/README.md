# Maitai CLI

Command-line interface for the [Maitai Platform Developer API](https://docs.trymaitai.ai/api-reference) (api/v1).

Resource commands (`applications`, `agents`, etc.) are **generated from the OpenAPI spec**. When the API changes, run `python scripts/generate_openapi.py` from the repo root to regenerate the CLI.

## Install

```bash
# From the maitai-mono repo (cli directory)
pip install .

# Or install in development mode
pip install -e .
```

## Authenticate

Create an API key in the [Portal](https://portal.trymaitai.com) under **Settings → API Keys**, then:

```bash
# Interactive: saves key to ~/.maitai/config
maitai login --api-key YOUR_MAITAI_API_KEY

# Or use environment variable (no login needed)
export MAITAI_API_KEY="YOUR_MAITAI_API_KEY"
```

For a custom base URL (e.g. local dev):

```bash
maitai login --api-key YOUR_KEY --base-url http://localhost:5000/api/v1
```

## Usage

```bash
# Check auth status
maitai whoami

# List resources
maitai applications --list
maitai agents --list
maitai intent-groups --list
maitai sessions --list
maitai sentinels --list
maitai datasets --list
maitai test-sets --list
maitai test-runs --list
maitai models --list
maitai models --available
maitai evaluations --list
maitai finetune-runs --list
maitai conversation-trees --list

# Get by ID
maitai applications --get 42
maitai agents --get 1
maitai intent-groups --get 5

# Create application
maitai applications --create "My App:my-app"

# Delete application
maitai applications --delete 42

# Raw API calls (any endpoint)
maitai api GET /applications
maitai api GET /applications/42
maitai api POST /applications -b '{"application_name":"Test","application_ref_name":"test"}'
maitai api PUT /applications/42 -b '{"application_name":"Updated"}'
maitai api DELETE /applications/42
```

## API Reference

The CLI wraps the Maitai Developer API. Full documentation:

- **External docs**: [docs.trymaitai.ai](https://docs.trymaitai.ai)
- **OpenAPI spec**: `docs/external/openapi.yaml` in this repo
- **Internal docs**: `docs/internal/` in this repo

### Authentication

All requests use the `X-Maitai-Api-Key` header. Create keys at [portal.trymaitai.com](https://portal.trymaitai.com) → Settings → API Keys.

### Base URL

- Production: `https://api.trymaitai.ai/api/v1`
- Override with `MAITAI_BASE_URL` or `maitai login --base-url`

### Response Format

- Success: `{"data": {...}}`
- Paginated: `{"data": [...], "pagination": {"total": N, "offset": 0, "limit": 25}}`
- Error: `{"error": {"status": 401, "message": "..."}}`

<!-- GENERATED_ENDPOINTS_START -->
## Supported API endpoints

The CLI wraps all api/v1 endpoints. Use `maitai api METHOD path` for any endpoint:

| Method | Path | Operation |
|--------|------|-----------|
| GET | `/agents` | listAgents |
| POST | `/agents` | createAgent |
| DELETE | `/agents/actions/{action_id}` | deleteAgentAction |
| GET | `/agents/actions/{action_id}` | getAgentAction |
| PUT | `/agents/actions/{action_id}` | updateAgentAction |
| PUT | `/agents/actions/{action_id}/disable` | disableAction |
| PUT | `/agents/actions/{action_id}/enable` | enableAction |
| POST | `/agents/actions/{action_id}/publish` | publishActionVersion |
| GET | `/agents/actions/{action_id}/versions` | listActionVersions |
| GET | `/agents/tasks/{task_id}/tree` | getAgentTaskTree |
| DELETE | `/agents/{agent_id}` | deleteAgent |
| GET | `/agents/{agent_id}` | getAgent |
| PUT | `/agents/{agent_id}` | updateAgent |
| GET | `/agents/{agent_id}/actions` | listAgentActions |
| POST | `/agents/{agent_id}/actions` | createAgentAction |
| DELETE | `/agents/{agent_id}/form-fields` | deleteFormFields |
| GET | `/agents/{agent_id}/form-fields` | getFormFields |
| PUT | `/agents/{agent_id}/form-fields` | updateFormFields |
| POST | `/agents/{agent_id}/publish` | publishAgentVersion |
| GET | `/agents/{agent_id}/releases` | listAgentReleases |
| DELETE | `/agents/{agent_id}/releases/{name}` | deleteAgentRelease |
| PUT | `/agents/{agent_id}/releases/{name}` | upsertAgentRelease |
| GET | `/agents/{agent_id}/routing/config` | getRoutingConfig |
| PUT | `/agents/{agent_id}/routing/config` | updateRoutingConfig |
| POST | `/agents/{agent_id}/routing/rules` | createRoutingRule |
| DELETE | `/agents/{agent_id}/routing/rules/{rule_id}` | deleteRoutingRule |
| PUT | `/agents/{agent_id}/routing/rules/{rule_id}` | updateRoutingRule |
| GET | `/agents/{agent_id}/sessions` | listAgentSessions |
| GET | `/agents/{agent_id}/sessions/{session_id}` | getAgentSessionDetail |
| GET | `/agents/{agent_id}/sessions/{session_id}/timeline` | getAgentSessionTimeline |
| GET | `/agents/{agent_id}/subagents` | listSubAgents |
| POST | `/agents/{agent_id}/subagents` | addSubAgent |
| DELETE | `/agents/{agent_id}/subagents/{child_agent_id}` | removeSubAgent |
| PUT | `/agents/{agent_id}/subagents/{child_agent_id}/disable` | disableSubAgent |
| PUT | `/agents/{agent_id}/subagents/{child_agent_id}/enable` | enableSubAgent |
| GET | `/agents/{agent_id}/tasks/{task_id}/timeline` | getAgentTaskTimeline |
| GET | `/agents/{agent_id}/versions` | listAgentVersions |
| GET | `/agents/{agent_id}/versions/{version}` | getAgentVersion |
| GET | `/analytics/agents/{agent_id}/requests` | getAgentRequestAnalytics |
| GET | `/analytics/applications/{application_id}/fault-rate` | getApplicationFaultRateAnalytics |
| GET | `/analytics/applications/{application_id}/intents/{action_id}/fault-rate` | getApplicationActionFaultRateAnalytics |
| GET | `/analytics/applications/{application_id}/intents/{action_id}/requests` | getApplicationActionRequestAnalytics |
| GET | `/analytics/applications/{application_id}/requests` | getApplicationRequestAnalytics |
| GET | `/analytics/company/application-activity` | getCompanyApplicationActivityAnalytics |
| GET | `/analytics/company/model-usage` | getCompanyModelUsageAnalytics |
| GET | `/analytics/company/requests` | getCompanyRequestAnalytics |
| GET | `/analytics/intent-groups/{intent_group_id}/fault-rate` | getIntentGroupFaultRateAnalytics |
| GET | `/analytics/intent-groups/{intent_group_id}/requests` | getIntentGroupRequestAnalytics |
| GET | `/applications` | listApplications |
| POST | `/applications` | createApplication |
| DELETE | `/applications/{application_id}` | deleteApplication |
| GET | `/applications/{application_id}` | getApplication |
| PUT | `/applications/{application_id}` | updateApplication |
| GET | `/applications/{application_id}/config` | getApplicationConfig |
| PUT | `/applications/{application_id}/config` | updateApplicationConfig |
| GET | `/applications/{application_id}/intents` | listApplicationIntents |
| POST | `/applications/{application_id}/intents` | createApplicationIntent |
| DELETE | `/applications/{application_id}/intents/{intent_id}` | deleteApplicationIntent |
| GET | `/applications/{application_id}/intents/{intent_id}` | getApplicationIntent |
| GET | `/applications/{application_id}/intents/{intent_id}/config` | getIntentConfig |
| PUT | `/applications/{application_id}/intents/{intent_id}/config` | updateIntentConfig |
| POST | `/applications/{application_id}/intents/{intent_id}/config/reset` | resetIntentConfig |
| PUT | `/applications/{application_id}/intents/{intent_id}/notifications/disable` | disableIntentNotifications |
| PUT | `/applications/{application_id}/intents/{intent_id}/notifications/enable` | enableIntentNotifications |
| GET | `/applications/{application_id}/models` | listApplicationModels |
| GET | `/applications/{application_id}/sessions` | listApplicationSessions |
| GET | `/applications/{application_id}/workflow-runs` | listApplicationWorkflowRuns |
| GET | `/compass` | listCompassSearches |
| POST | `/compass` | createCompassSearch |
| GET | `/compass/{search_id}` | getCompassSearch |
| POST | `/compass/{search_id}/cancel` | cancelCompassSearch |
| GET | `/compass/{search_id}/runs` | listCompassSearchRuns |
| GET | `/continuous-learning/finetune-runs/{run_id}` | getFinetuneRunForContinuousLearning |
| GET | `/continuous-learning/models` | listContinuousLearningModels |
| GET | `/continuous-learning/models/{model_id}` | getContinuousLearningModel |
| GET | `/continuous-learning/runs` | listContinuousLearningRuns |
| GET | `/continuous-learning/runs/accuracy-history` | getContinuousLearningAccuracyHistory |
| DELETE | `/continuous-learning/runs/{run_id}` | deleteContinuousLearningRun |
| GET | `/continuous-learning/runs/{run_id}` | getContinuousLearningRun |
| POST | `/continuous-learning/runs/{run_id}/action` | actOnContinuousLearningRun |
| GET | `/continuous-learning/runs/{run_id}/action-summary` | getContinuousLearningActionSummary |
| POST | `/continuous-learning/runs/{run_id}/create-finetune` | createFinetuneFromContinuousLearningRun |
| POST | `/continuous-learning/runs/{run_id}/dismiss-promotion` | dismissContinuousLearningPromotion |
| POST | `/continuous-learning/runs/{run_id}/promote` | promoteContinuousLearningRun |
| POST | `/continuous-learning/runs/{run_id}/refresh` | refreshContinuousLearningRun |
| POST | `/continuous-learning/runs/{run_id}/rerun` | rerunContinuousLearning |
| POST | `/continuous-learning/trigger` | triggerContinuousLearning |
| GET | `/conversation-trees` | listConversationTrees |
| DELETE | `/conversation-trees/{tree_id}` | deleteConversationTree |
| GET | `/conversation-trees/{tree_id}` | getConversationTree |
| GET | `/conversation-trees/{tree_id}/status` | getConversationTreeStatus |
| GET | `/conversation-trees/{tree_id}/versions` | listConversationTreeVersions |
| GET | `/dashboard/action-items` | getActionItems |
| GET | `/dashboard/alerts` | getAlerts |
| GET | `/datasets` | listDatasets |
| POST | `/datasets` | createDataset |
| GET | `/datasets/applications/{application_id}/intents/{intent_id}` | listDatasetsByIntent |
| GET | `/datasets/by-tags` | listDatasetsByTags |
| GET | `/datasets/estimated-request-count` | getEstimatedDatasetRequestCount |
| POST | `/datasets/generate` | startDatasetGeneration |
| POST | `/datasets/generate/estimate-cost` | estimateDatasetGenerationCost |
| POST | `/datasets/generate/preview` | previewDatasetGeneration |
| GET | `/datasets/intent-groups/{intent_group_id}` | listDatasetsByIntentGroup |
| GET | `/datasets/s3/syncer-info` | getDatasetS3SyncerInfo |
| POST | `/datasets/s3/validate` | validateDatasetS3Source |
| GET | `/datasets/tags/valid` | listValidDatasetTags |
| GET | `/datasets/test-sets/{test_set_id}` | listDatasetsByTestSet |
| DELETE | `/datasets/{dataset_id}` | deleteDataset |
| GET | `/datasets/{dataset_id}` | getDataset |
| PUT | `/datasets/{dataset_id}` | updateDataset |
| POST | `/datasets/{dataset_id}/added-requests/search` | searchAddedDatasetRequests |
| POST | `/datasets/{dataset_id}/clone` | cloneDataset |
| GET | `/datasets/{dataset_id}/delete-impact` | getDatasetDeleteImpact |
| GET | `/datasets/{dataset_id}/eligible-requests` | listEligibleDatasetRequests |
| POST | `/datasets/{dataset_id}/eligible-requests/search` | searchEligibleDatasetRequests |
| POST | `/datasets/{dataset_id}/generate/cancel` | cancelDatasetGeneration |
| POST | `/datasets/{dataset_id}/generate/pause` | pauseDatasetGeneration |
| POST | `/datasets/{dataset_id}/generate/resume` | resumeDatasetGeneration |
| GET | `/datasets/{dataset_id}/prompt` | getDatasetPrompt |
| POST | `/datasets/{dataset_id}/prune/apply` | applyDatasetPrune |
| POST | `/datasets/{dataset_id}/prune/preview` | previewDatasetPrune |
| POST | `/datasets/{dataset_id}/reasoning/augment` | augmentDatasetReasoning |
| POST | `/datasets/{dataset_id}/regex-replacements` | applyDatasetRegexReplacements |
| POST | `/datasets/{dataset_id}/regex-replacements/count` | getDatasetRegexReplacementsApplicableCount |
| GET | `/datasets/{dataset_id}/request-distribution` | getDatasetRequestDistribution |
| GET | `/datasets/{dataset_id}/request-ids` | listDatasetRequestIds |
| DELETE | `/datasets/{dataset_id}/requests` | removeRequestsFromDataset |
| GET | `/datasets/{dataset_id}/requests` | listDatasetRequests |
| POST | `/datasets/{dataset_id}/requests` | addRequestsToDataset |
| PUT | `/datasets/{dataset_id}/requests/add` | addDatasetRequestsBulk |
| PUT | `/datasets/{dataset_id}/requests/remove` | removeDatasetRequestsBulk |
| GET | `/datasets/{dataset_id}/requests/{request_id}/reasoning` | getDatasetRequestReasoning |
| POST | `/datasets/{dataset_id}/s3/cancel` | cancelDatasetS3Import |
| POST | `/datasets/{dataset_id}/s3/reimport` | reimportDatasetS3Source |
| POST | `/datasets/{dataset_id}/sample-clone` | sampleCloneDataset |
| GET | `/datasets/{dataset_id}/status` | getDatasetStatus |
| GET | `/datasets/{dataset_id}/tags` | listDatasetTags |
| POST | `/datasets/{dataset_id}/tags` | addDatasetTag |
| PUT | `/datasets/{dataset_id}/tags` | setDatasetTags |
| DELETE | `/datasets/{dataset_id}/tags/{tag}` | removeDatasetTag |
| GET | `/datasets/{dataset_id}/versions` | listDatasetVersions |
| GET | `/drift/checks/{check_id}` | getDriftCheck |
| GET | `/drift/models` | listDriftModels |
| POST | `/drift/models/{model_id}/check` | triggerModelDriftCheck |
| GET | `/drift/models/{model_id}/checks` | listModelDriftChecks |
| POST | `/drift/run` | runAllDriftChecks |
| GET | `/evaluation-criteria` | listEvaluationCriteria |
| POST | `/evaluation-criteria` | createEvaluationCriteria |
| GET | `/evaluation-criteria/available` | listAvailableEvaluationCriteria |
| DELETE | `/evaluation-criteria/{criteria_id}` | deleteEvaluationCriteria |
| PUT | `/evaluation-criteria/{criteria_id}` | updateEvaluationCriteria |
| GET | `/evaluations` | listEvaluations |
| POST | `/evaluations` | createEvaluation |
| GET | `/evaluations/{evaluation_run_id}` | getEvaluation |
| GET | `/evaluations/{evaluation_run_id}/results` | getEvaluationResults |
| GET | `/finetune-runs` | listFinetuneRuns |
| POST | `/finetune-runs` | createFinetuneRun |
| GET | `/finetune-runs/{run_id}` | getFinetuneRun |
| POST | `/finetune-runs/{run_id}/cancel` | cancelFinetuneRun |
| GET | `/finetune-runs/{run_id}/metrics` | getFinetuneRunMetrics |
| GET | `/intent-groups` | listIntentGroups |
| GET | `/intent-groups/{intent_group_id}` | getIntentGroup |
| GET | `/intent-groups/{intent_group_id}/compositions` | listIntentGroupCompositions |
| GET | `/intent-groups/{intent_group_id}/config` | getIntentGroupConfig |
| PUT | `/intent-groups/{intent_group_id}/config` | updateIntentGroupConfig |
| GET | `/intent-groups/{intent_group_id}/datasets` | listIntentGroupDatasets |
| GET | `/intent-groups/{intent_group_id}/intents` | listIntentsByGroup |
| GET | `/intent-groups/{intent_group_id}/models` | listIntentGroupModels |
| GET | `/intent-groups/{intent_group_id}/requests` | listIntentGroupRequests |
| GET | `/intent-groups/{intent_group_id}/sentinels` | listIntentGroupSentinels |
| GET | `/intent-groups/{intent_group_id}/test-sets` | listIntentGroupTestSets |
| GET | `/models` | listModels |
| GET | `/models/applications/{application_id}` | listModelsByApplication |
| GET | `/models/available` | listAvailableModels |
| POST | `/models/base-model` | createBaseModel |
| GET | `/models/intent-groups/{intent_group_id}` | listModelsByIntentGroup |
| GET | `/models/intents/{intent_id}` | listModelsByIntent |
| GET | `/models/{model_id}` | getModel |
| POST | `/models/{model_id}/disable` | disableModel |
| POST | `/models/{model_id}/enable` | enableModel |
| GET | `/models/{model_id}/inference-pool` | getModelInferencePool |
| POST | `/models/{model_id}/inference-pool/attach` | attachModelInferencePool |
| GET | `/models/{model_id}/inference-pool/attach-candidates` | listModelInferencePoolAttachCandidates |
| GET | `/models/{model_id}/inference-pool/debug` | getModelInferencePoolDebug |
| POST | `/models/{model_id}/inference-pool/detach` | detachModelInferencePool |
| PATCH | `/models/{model_id}/registry` | patchModelRegistry |
| POST | `/models/{model_id}/repoint` | repointModel |
| GET | `/models/{model_id}/repoint-options` | getModelRepointOptions |
| POST | `/models/{model_id}/swap-model-ref/execute` | executeSwapModelRef |
| POST | `/models/{model_id}/swap-model-ref/preview` | previewSwapModelRef |
| GET | `/reports/fallbacks` | listFallbacks |
| GET | `/reports/faults` | listFaults |
| GET | `/reports/intents/{intent_id}/fallbacks` | listFallbacksByIntent |
| GET | `/reports/intents/{intent_id}/faults` | listFaultsByIntent |
| GET | `/requests` | listRequests |
| GET | `/requests/{request_id}` | getRequest |
| PUT | `/requests/{request_id}/response` | updateRequestResponse |
| GET | `/routing/agents/{agent_id}/config` | getAgentRoutingConfig |
| PUT | `/routing/agents/{agent_id}/config` | saveAgentRoutingConfig |
| GET | `/routing/agents/{agent_id}/results/{routing_result_id}` | getAgentRoutingResultDetail |
| POST | `/routing/agents/{agent_id}/rules` | createAgentRoutingRule |
| DELETE | `/routing/agents/{agent_id}/rules/{rule_id}` | deleteAgentRoutingRule |
| PUT | `/routing/agents/{agent_id}/rules/{rule_id}` | updateAgentRoutingRule |
| PUT | `/routing/agents/{agent_id}/rules/{rule_id}/reorder` | reorderAgentRoutingRule |
| POST | `/routing/agents/{agent_id}/rules/{rule_id}/test` | testAgentRoutingRule |
| GET | `/sentinels` | listSentinels |
| POST | `/sentinels` | createSentinel |
| GET | `/sentinels/applications/{application_id}` | listSentinelsByApplication |
| GET | `/sentinels/applications/{application_id}/human-needs` | listSentinelsByApplicationHumanNeeds |
| POST | `/sentinels/generate` | generateSentinels |
| POST | `/sentinels/generate/new` | generateNewSentinel |
| GET | `/sentinels/intent-groups/by-name/{intent_name}` | listSentinelsByIntentName |
| GET | `/sentinels/intent-groups/{intent_group_id}` | listSentinelsByIntentGroup |
| POST | `/sentinels/regenerate` | regenerateSentinels |
| GET | `/sentinels/simple` | listSimpleSentinels |
| DELETE | `/sentinels/{sentinel_id}` | deleteSentinel |
| GET | `/sentinels/{sentinel_id}` | getSentinel |
| PUT | `/sentinels/{sentinel_id}` | updateSentinel |
| PUT | `/sentinels/{sentinel_id}/directive` | updateSentinelDirective |
| POST | `/sentinels/{sentinel_id}/regenerate` | regenerateSentinel |
| POST | `/sentinels/{sentinel_id}/regenerate/correction` | regenerateSentinelCorrection |
| POST | `/sentinels/{sentinel_id}/regenerate/evaluation` | regenerateSentinelEvaluation |
| POST | `/sentinels/{sentinel_id}/regenerate/qualification` | regenerateSentinelQualification |
| GET | `/sessions` | listSessions |
| GET | `/sessions/{session_id}` | getSession |
| POST | `/sessions/{session_id}/feedback` | setSessionFeedback |
| GET | `/sessions/{session_id}/timeline` | getSessionTimeline |
| GET | `/tags` | listTags |
| POST | `/tags` | createTag |
| GET | `/tags/assignments` | listTagAssignments |
| POST | `/tags/preview` | previewTagRule |
| GET | `/tags/runs/{run_id}` | getTagRun |
| DELETE | `/tags/{tag_id}` | deleteTag |
| GET | `/tags/{tag_id}` | getTag |
| PUT | `/tags/{tag_id}` | updateTag |
| POST | `/tags/{tag_id}/run` | triggerTagRun |
| GET | `/tags/{tag_id}/runs` | listTagRuns |
| GET | `/test-runs` | listTestRuns |
| POST | `/test-runs` | createTestRun |
| POST | `/test-runs/compare` | compareTestRuns |
| GET | `/test-runs/intent-groups/{intent_group_id}` | listTestRunsByIntentGroup |
| GET | `/test-runs/requests/compare/{base_request_id}/{compare_request_id}` | getTestRunRequestComparison |
| GET | `/test-runs/test-sets/{test_set_id}` | listTestRunsByTestSet |
| GET | `/test-runs/test-sets/{test_set_id}/progress` | getTestRunProgressByTestSet |
| DELETE | `/test-runs/{test_run_id}` | deleteTestRun |
| GET | `/test-runs/{test_run_id}` | getTestRun |
| POST | `/test-runs/{test_run_id}/evaluate` | evaluateTestRun |
| GET | `/test-runs/{test_run_id}/progress` | getTestRunProgress |
| GET | `/test-runs/{test_run_id}/requests` | listTestRunRequests |
| POST | `/test-runs/{test_run_id}/requests/{offset}/{limit}` | listTestRunRequestsWithFilters |
| POST | `/test-runs/{test_run_id}/requests/{test_run_request_id}/evaluate` | evaluateTestRunRequest |
| GET | `/test-runs/{test_run_id}/results` | getTestRunResults |
| POST | `/test-runs/{test_run_id}/retry` | retryTestRun |
| PUT | `/test-runs/{test_run_id}/status/{status}` | updateTestRunStatus |
| POST | `/test-runs/{test_run_id}/stop` | stopTestRun |
| GET | `/test-sets` | listTestSets |
| POST | `/test-sets` | createTestSet |
| GET | `/test-sets/applications/{application_id}/intents/{intent_id}` | listTestSetsByApplicationIntent |
| POST | `/test-sets/convert-to-workflow` | convertTestSetToWorkflow |
| GET | `/test-sets/datasets/{dataset_id}` | listTestSetsByDataset |
| GET | `/test-sets/datasets/{dataset_id}/source` | listTestSetsCreatedFromDataset |
| GET | `/test-sets/eligible-requests/{intent_group_id}/{test_set_id}` | listEligibleTestSetRequests |
| POST | `/test-sets/eligible-requests/{intent_group_id}/{test_set_id}/search` | searchEligibleTestSetRequests |
| GET | `/test-sets/intent-groups/by-name/{intent_group_name}` | listTestSetsByIntentGroupName |
| GET | `/test-sets/intent-groups/{intent_group_id}` | listTestSetsByIntentGroup |
| PUT | `/test-sets/request/add` | addSingleRequestToTestSet |
| DELETE | `/test-sets/request/remove` | removeSingleRequestFromTestSet |
| PUT | `/test-sets/requests/add` | addTestSetRequestsBulk |
| PUT | `/test-sets/requests/remove` | removeTestSetRequestsBulk |
| POST | `/test-sets/sample-clone` | sampleCloneTestSet |
| DELETE | `/test-sets/{test_set_id}` | deleteTestSet |
| GET | `/test-sets/{test_set_id}` | getTestSet |
| PUT | `/test-sets/{test_set_id}` | updateTestSet |
| GET | `/test-sets/{test_set_id}/prompt-template` | getTestSetPromptTemplate |
| GET | `/test-sets/{test_set_id}/request-distribution` | getTestSetRequestDistribution |
| DELETE | `/test-sets/{test_set_id}/requests` | removeRequestsFromTestSet |
| GET | `/test-sets/{test_set_id}/requests` | listTestSetRequests |
| POST | `/test-sets/{test_set_id}/requests` | addRequestsToTestSet |
| PUT | `/test-sets/{test_set_id}/requests/{request_id}/response` | updateTestSetRequestResponse |
| PUT | `/test-sets/{test_set_id}/requests/{request_id}/tags` | updateTestSetRequestTags |
| GET | `/test-sets/{test_set_id}/sessions` | listTestSetSessionFacets |
| GET | `/workflow-test-runs` | listWorkflowTestRuns |
| POST | `/workflow-test-runs` | createWorkflowTestRun |
| POST | `/workflow-test-runs/compare` | compareWorkflowTestRuns |
| DELETE | `/workflow-test-runs/{test_run_id}` | deleteWorkflowTestRun |
| GET | `/workflow-test-runs/{test_run_id}` | getWorkflowTestRun |
| GET | `/workflow-test-runs/{test_run_id}/items` | listWorkflowTestRunItems |
| PUT | `/workflow-test-runs/{test_run_id}/items/{item_id}` | updateWorkflowTestRunItem |
| GET | `/workflow-test-runs/{test_run_id}/progress` | getWorkflowTestRunProgress |
| POST | `/workflow-test-runs/{test_run_id}/resume` | resumeWorkflowTestRun |
| POST | `/workflow-test-runs/{test_run_id}/retry` | retryWorkflowTestRun |
| GET | `/workflow-test-runs/{test_run_id}/review-segments` | listWorkflowTestRunReviewSegments |
| POST | `/workflow-test-runs/{test_run_id}/stop` | stopWorkflowTestRun |
| GET | `/workflow-test-sets` | listWorkflowTestSets |
| POST | `/workflow-test-sets` | createWorkflowTestSet |
| DELETE | `/workflow-test-sets/{test_set_id}` | deleteWorkflowTestSet |
| GET | `/workflow-test-sets/{test_set_id}` | getWorkflowTestSet |
| PUT | `/workflow-test-sets/{test_set_id}` | updateWorkflowTestSet |
| POST | `/workflow-test-sets/{test_set_id}/clone` | cloneWorkflowTestSet |
| GET | `/workflow-test-sets/{test_set_id}/imported-session-ids` | listWorkflowTestSetImportedSessionIds |
| POST | `/workflow-test-sets/{test_set_id}/items` | addWorkflowTestSetItems |
| DELETE | `/workflow-test-sets/{test_set_id}/items/{item_id}` | deleteWorkflowTestSetItem |
| DELETE | `/workflow-test-sets/{test_set_id}/items/{item_id}/response-sub` | deleteWorkflowTestSetItemResponseSub |
| GET | `/workflow-test-sets/{test_set_id}/items/{item_id}/response-sub` | getWorkflowTestSetItemResponseSub |
| PUT | `/workflow-test-sets/{test_set_id}/items/{item_id}/response-sub` | upsertWorkflowTestSetItemResponseSub |
| POST | `/workflow-test-sets/{test_set_id}/sample-clone` | sampleCloneWorkflowTestSet |
| GET | `/workflow-test-sets/{test_set_id}/test-runs` | listWorkflowTestSetRuns |
| GET | `/workflows` | listWorkflows |
| POST | `/workflows` | createWorkflow |
| POST | `/workflows/chat/completions` | createWorkflowChatCompletion |
| GET | `/workflows/default-script` | getDefaultWorkflowScript |
| GET | `/workflows/runs` | listWorkflowRuns |
| GET | `/workflows/runs/{session_id}` | getWorkflowRun |
| POST | `/workflows/validate` | validateWorkflowScript |
| DELETE | `/workflows/{workflow_id}` | deleteWorkflow |
| GET | `/workflows/{workflow_id}` | getWorkflow |
| PUT | `/workflows/{workflow_id}` | updateWorkflow |
| DELETE | `/workflows/{workflow_id}/accessories` | deleteWorkflowAccessory |
| POST | `/workflows/{workflow_id}/accessories` | uploadWorkflowAccessory |
| GET | `/workflows/{workflow_id}/artifact-files` | getWorkflowArtifactFiles |
| DELETE | `/workflows/{workflow_id}/datastore/{name}` | deleteWorkflowDatastore |
| POST | `/workflows/{workflow_id}/datastore/{name}` | upsertWorkflowDatastore |
| POST | `/workflows/{workflow_id}/datastore/{name}/upload` | uploadWorkflowDatastore |
| GET | `/workflows/{workflow_id}/has-transforms` | checkWorkflowTransforms |
| GET | `/workflows/{workflow_id}/releases` | listWorkflowReleases |
| POST | `/workflows/{workflow_id}/releases` | createWorkflowRelease |
| POST | `/workflows/{workflow_id}/releases/clear-default` | clearWorkflowDefaultRelease |
| DELETE | `/workflows/{workflow_id}/releases/{name}` | deleteWorkflowRelease |
| PUT | `/workflows/{workflow_id}/releases/{name}` | updateWorkflowRelease |
| GET | `/workflows/{workflow_id}/schema` | getWorkflowSchema |
| GET | `/workflows/{workflow_id}/script` | getWorkflowScript |
| GET | `/workflows/{workflow_id}/transform-info` | getWorkflowTransformInfo |
| POST | `/workflows/{workflow_id}/transform-preview` | previewWorkflowTransform |
| GET | `/workflows/{workflow_id}/versions` | listWorkflowVersions |
| POST | `/workflows/{workflow_id}/versions` | publishWorkflowVersion |
| GET | `/workflows/{workflow_id}/versions/{version_number}/artifact-files` | getWorkflowVersionArtifactFiles |

<!-- GENERATED_ENDPOINTS_END -->

