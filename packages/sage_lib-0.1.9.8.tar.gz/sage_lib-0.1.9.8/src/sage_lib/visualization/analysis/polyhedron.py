from __future__ import annotations
import numpy as np
from scipy.spatial import ConvexHull
from .neighbor_engine import NeighborEngine
from .bond_graph import BondGraph

def compute_single_polyhedron(index: int, pos: np.ndarray, lat: np.ndarray, pbc: bool = True):
    """
    Background worker: Calculates the coordination polyhedron for one atom.
    
    Args:
        index: Central atom index
        pos: Full positions array
        lat: Lattice matrix
        pbc: Periodic boundary conditions flag
        
    Returns:
        dict: { 'vertices': np.ndarray, 'faces': np.ndarray, 'metrics': dict }
    """
    # 1. Identify neighbors (using a generous default coordination cutoff)
    # In a real scenario, this might use the current viewer's bond_factor.
    # For now, we use a robust covalent search logic.
    # Note: We need elements for BondGraph, but they aren't passed in kwargs yet?
    # Actually, we can just use a fixed 3.5A cutoff for 'coordination shell'
    i_idx, j_idx, dists = NeighborEngine.get_neighbors(pos, lat, cutoff=3.5, pbc=pbc)
    
    # Filter for the central atom
    mask = (i_idx == index)
    neighbors = j_idx[mask]
    
    if len(neighbors) < 4:
        # Not enough points for a polyhedron (needs 4 for a tetrahedron)
        return None
        
    # 2. Unwrap neighbors relative to central atom to handle PBC
    # neighbors includes self if cutoff is 0, but NeighborEngine filters it
    indices = np.concatenate([[index], neighbors])
    unwrapped_pos = NeighborEngine.unwrap_selection(indices, index, pos, lat)
    
    # Central pos is at index 0 in the unwrapped array
    central_pos = unwrapped_pos[0]
    ligand_pos = unwrapped_pos[1:]
    
    try:
        # 3. Construct Convex Hull
        hull = ConvexHull(ligand_pos)
        
        # 4. Distortion Metrics (bridge to renderer logic)
        from ..renderer.polyhedron_renderer import PolyhedronRenderer
        metrics = PolyhedronRenderer.calculate_distortion_metrics(central_pos, ligand_pos)
        
        return {
            'vertices': ligand_pos.astype(np.float32),
            'faces': hull.simplices.astype(np.uint32),
            'metrics': metrics,
            'center_index': index
        }
    except Exception as e:
        print(f"[PolyhedronWorker] Hull construction failed for atom {index}: {e}")
        return None
