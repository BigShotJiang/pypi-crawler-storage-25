# ============================
# protein_geometry.py — Protein Structure Analysis
# ============================
from __future__ import annotations
import numpy as np
from typing import List, Tuple, Dict, Any, Optional

AA_MAP = {
    'ALA': 'A', 'ARG': 'R', 'ASN': 'N', 'ASP': 'D', 'CYS': 'C',
    'GLN': 'Q', 'GLU': 'E', 'GLY': 'G', 'HIS': 'H', 'ILE': 'I',
    'LEU': 'L', 'LYS': 'K', 'MET': 'M', 'PHE': 'F', 'PRO': 'P',
    'SER': 'S', 'THR': 'T', 'TRP': 'W', 'TYR': 'Y', 'VAL': 'V',
    'ASX': 'B', 'GLX': 'Z', 'XAA': 'X'
}

# Professional Amino Acid Palette (Residue-specific colors)
AA_COLORS_RGB = {
    'A': (0.8, 0.8, 0.8), 'V': (0.6, 1.0, 0.6), 'L': (0.4, 0.8, 0.4), 'I': (0.2, 0.6, 0.2), 
    'M': (1.0, 1.0, 0.4), 'F': (1.0, 0.6, 0.2), 'W': (1.0, 1.0, 0.6), 'P': (0.8, 0.6, 0.4), 
    'S': (1.0, 0.7, 0.7), 'T': (0.8, 0.4, 0.2), 'C': (1.0, 1.0, 0.0), 'Y': (0.6, 0.6, 1.0), 
    'N': (0.0, 0.8, 0.8), 'Q': (1.0, 0.0, 1.0), 'D': (0.9, 0.2, 0.2), 'E': (0.7, 0.2, 0.2), 
    'K': (0.2, 0.2, 0.9), 'R': (0.2, 0.2, 0.7), 'H': (0.5, 0.5, 1.0), 'G': (0.9, 0.9, 0.9)
}

BACKBONE_ATOMS = {
    "N", "CA", "C", "O", "OXT",                 # Heavy Main Chain
    "H", "H1", "H2", "H3", "HN", "HT1", "HT2", "HT3", # Amide/Termini Hydrogens
    "HA", "HA1", "HA2", "HA3", "1HA", "2HA", "3HA", # Alpha Hydrogens
    "O1", "O2", "OT1", "OT2", "ON", "OXT",      # C-Term Oxygen Variants
    "HB", "HB1", "HB2", "HB3", "1HB", "2HB", "3HB"  # Beta Hydrogens (sometimes considered part of core in some schemas, but usually sidechain)
}
# Note: HB is technically sidechain, but CA-HB overlap is significant. 
# However, usually backbone = N, CA, C, O, H, HA.
BACKBONE_ATOMS = {
    "N", "CA", "C", "O", "OXT",
    "H", "H1", "H2", "H3", "HN", "HT1", "HT2", "HT3",
    "HA", "HA1", "HA2", "HA3", "1HA", "2HA", "3HA",
    "O1", "O2", "OT1", "OT2", "ON"
}

def get_dihedral(p0: np.ndarray, p1: np.ndarray, p2: np.ndarray, p3: np.ndarray) -> float:
    """Calculate dihedral angle between four points in degrees."""
    b0 = -1.0 * (p1 - p0)
    b1 = p2 - p1
    b2 = p3 - p2
    
    b1 /= np.linalg.norm(b1) + 1e-12
    v = b0 - np.dot(b0, b1) * b1
    w = b2 - np.dot(b2, b1) * b1
    
    x = np.dot(v, w)
    y = np.dot(np.cross(b1, v), w)
    return np.degrees(np.arctan2(y, x))

def assign_secondary_structure(ca_positions: np.ndarray) -> List[str]:
    """
    Enhanced heuristic assignment based on CA-CA distances and dihedrals.
    Uses CA(i) to CA(i+3) distance as a primary differentiator.
    H: Helix, E: Sheet, C: Coil
    """
    n = len(ca_positions)
    ss = ['C'] * n
    if n < 4:
        return ss

    # 1. Broad initial assignment
    for i in range(n - 3):
        # 4 consecutive points: i, i+1, i+2, i+3
        p0, p1, p2, p3 = ca_positions[i], ca_positions[i+1], ca_positions[i+2], ca_positions[i+3]
        d03 = np.linalg.norm(p0 - p3)
        dihed = get_dihedral(p0, p1, p2, p3)
        
        # Alpha-Helix: compact (d03 ~5A), right-handed dihedral (~50 deg)
        if 4.5 < d03 < 6.5 and 20.0 < dihed < 90.0:
            for j in range(i, i+4): ss[j] = 'H'
            
        # Beta-Sheet: extended (d03 ~10A), trans-like dihedral (~180 deg)
        elif d03 > 8.0 and (dihed > 130 or dihed < -130):
            for j in range(i, i+4): ss[j] = 'E'

    # 2. Smoothing pass: Remove isolated/short segments and Fill tiny gaps
    smoothed = list(ss)
    for _ in range(2): # Apply twice for better stability
        # Remove singletons
        for i in range(1, n - 1):
            if ss[i] != ss[i-1] and ss[i] != ss[i+1]:
                smoothed[i] = 'C'
        ss = list(smoothed)
                
        # Fill single gaps in long stretches
        for i in range(1, n - 1):
            if ss[i] == 'C' and ss[i-1] == ss[i+1] and ss[i-1] != 'C':
                smoothed[i] = ss[i-1]
        ss = list(smoothed)

    return ss

def extract_protein_chains(positions: np.ndarray, info: Optional[Dict[str, List[Any]]]) -> List[Dict]:
    """
    Extracts chains of residues (with N, CA, C backbone atoms) from the scene data.
    Hardened to handle supercells (positions > metadata) and varying key names.
    """
    chains = []
    if not info:
        return chains

    # Support both 'atom_name' (PDB reader) and 'name' (other readers)
    atom_names = info.get('atom_name', info.get('name'))
    chain_ids = info.get('chain')
    res_names = info.get('res_name', [])
    res_seqs = info.get('res_id', info.get('res_seq', []))

    if atom_names is None or chain_ids is None:
        return chains

    # Group atoms by (chain, res_id)
    backbone_map = {} # (chain, res_id) -> {'N': pos, 'CA': pos, 'C': pos, 'idx': int}
    
    # Loop ONLY up to the available metadata length to avoid index errors in supercells
    num_meta = len(atom_names)
    num_iter = min(len(positions), num_meta)
    
    for i in range(num_iter):
        name = str(atom_names[i]).strip().upper()
        if name not in {"N", "CA", "C"}: continue
        
        c_id = str(chain_ids[i])
        r_id = int(res_seqs[i]) if (i < len(res_seqs) and res_seqs[i] is not None) else -1
        
        key = (c_id, r_id)
        if key not in backbone_map:
            res_label = str(res_names[i]) if i < len(res_names) else 'UNK'
            backbone_map[key] = {'name': res_label, 'chain': c_id, 'res_id': r_id}
        
        backbone_map[key][name] = positions[i]
        if name == "CA": backbone_map[key]['idx'] = i

    # Sort and split into chains based on chain_id and res_id continuity
    sorted_keys = sorted(backbone_map.keys(), key=lambda x: (str(x[0]), int(x[1])))
    
    current_chain_id = None
    current_chain_data = []

    for key in sorted_keys:
        data = backbone_map[key]
        if 'CA' not in data: continue # Require CA for it to be a valid residue in our ribbon
        
        if key[0] != current_chain_id:
            if len(current_chain_data) >= 3:
                chains.append(current_chain_data)
            current_chain_id = key[0]
            current_chain_data = []
        
        # Distance gap check for missing residues (e.g. missing loops)
        if current_chain_data:
            dist = np.linalg.norm(data['CA'] - current_chain_data[-1]['CA'])
            # If distance > 6.0A, the residues are likely not connected (peptide bond is ~3.8A)
            if dist > 6.0:
                if len(current_chain_data) >= 3:
                    chains.append(current_chain_data)
                current_chain_data = []
        
        current_chain_data.append(data)

    if len(current_chain_data) >= 3:
        chains.append(current_chain_data)

    if not chains and backbone_map:
        print(f"SAGE Protein: Found residues but no valid chains (min length 3).")

    return chains

def calculate_rgyr(positions: np.ndarray) -> float:
    """Computes Radius of Gyration for a set of points."""
    if positions.shape[0] < 2: return 0.0
    center = np.mean(positions, axis=0)
    dists_sq = np.sum((positions - center)**2, axis=1)
    return float(np.sqrt(np.mean(dists_sq)))

def calculate_contact_map(positions: np.ndarray) -> np.ndarray:
    """Computes a square distance matrix between points."""
    diff = positions[:, np.newaxis, :] - positions[np.newaxis, :, :]
    return np.sqrt(np.sum(diff**2, axis=-1))

def calculate_dihedrals(chain_data: List[Dict]) -> Tuple[np.ndarray, np.ndarray]:
    """
    Computes Phi and Psi angles for a chain. 
    Phi: C(i-1) - N(i) - CA(i) - C(i)
    Psi: N(i) - CA(i) - C(i) - N(i+1)
    """
    n = len(chain_data)
    phi = np.zeros(n)
    psi = np.zeros(n)
    
    for i in range(n):
        res = chain_data[i]
        if not all(k in res for k in ['N', 'CA', 'C']): continue
        
        # Phi (needs C from previous)
        if i > 0 and 'C' in chain_data[i-1]:
            phi[i] = get_dihedral(chain_data[i-1]['C'], res['N'], res['CA'], res['C'])
        else:
            phi[i] = np.nan
            
        # Psi (needs N from next)
        if i < n - 1 and 'N' in chain_data[i+1]:
            psi[i] = get_dihedral(res['N'], res['CA'], res['C'], chain_data[i+1]['N'])
        else:
            psi[i] = np.nan
            
    return phi, psi

def get_sequence(chains: List[List[Dict[str, Any]]]) -> List[str]:
    """Converts extracted chain data into FASTA sequence strings."""
    seqs = []
    for chain in chains:
        s = "".join([AA_MAP.get(res.get('name', 'UNK').upper(), 'X') for res in chain])
        seqs.append(s)
    return seqs

def get_protein_colors(scene, mode: int, bb_alpha: float, sc_alpha: float):
    """
    Generates an N x 4 RGBA color array for the protein structure.
    Modes: 0: Element (CPK), 1: Residue Type, 2: Chain, 3: Backbone focused.
    """
    n = scene.N
    colors = np.zeros((n, 4), dtype=np.float32)
    info = scene.info
    
    if not info or 'res_id' not in info:
        # Fallback to standard CPK if no protein info
        from ..constants import CPK_COLORS, DEFAULT_COLOR
        for i in range(n):
            el = scene.elements[i]
            colors[i, :3] = CPK_COLORS.get(el, DEFAULT_COLOR)
            colors[i, 3] = 1.0
        return colors

    # Pre-calculated chain colors
    chain_palette = [
        (0.4, 0.7, 1.0), (1.0, 0.4, 0.4), (0.4, 1.0, 0.4), 
        (1.0, 0.8, 0.2), (0.8, 0.4, 1.0), (0.2, 0.8, 0.4)
    ]

    for i in range(n):
        atom_name = str(info.get('atom_name', info.get('name', ["X"]*n))[i]).strip().upper()
        res_name = str(info.get('res_name', ["UNK"]*n)[i]).strip().upper()
        is_protein = res_name in AA_MAP
        is_bb = atom_name in BACKBONE_ATOMS and is_protein
        is_sc = is_protein and not is_bb
        
        # Ensure ligands, water, and non-protein atoms remain fully opaque.
        a = bb_alpha if is_bb else (sc_alpha if is_sc else 1.0)
        
        if mode == 1: # By Residue Type
            one_letter = AA_MAP.get(res_name, 'X')
            rgb = AA_COLORS_RGB.get(one_letter, (0.5, 0.5, 0.5))
            colors[i] = [*rgb, a]
        elif mode == 2: # By Chain
            ch_idx = int(info.get('chain_index', [0]*n)[i]) % len(chain_palette)
            rgb = chain_palette[ch_idx]
            colors[i] = [*rgb, a]
        elif mode == 3: # Backbone Focused
            if is_bb:
                colors[i] = [1.0, 1.0, 1.0, bb_alpha]
            else:
                one_letter = AA_MAP.get(res_name, 'X')
                rgb = AA_COLORS_RGB.get(one_letter, (0.5, 0.5, 0.5))
                colors[i] = [*rgb, sc_alpha]
        else: # Default CPK
            from ..constants import CPK_COLORS, DEFAULT_COLOR
            el = scene.elements[i]
            rgb = CPK_COLORS.get(el, DEFAULT_COLOR)
            colors[i] = [*rgb, a]
            
    return colors

def generate_catmull_rom_spline(pts: np.ndarray, segments: int = 10) -> Tuple[np.ndarray, np.ndarray]:
    """Generates a Catmull-Rom spline with tangents."""
    n_pts = len(pts)
    if n_pts < 2:
        return pts, np.zeros_like(pts)
        
    pts_ext = np.vstack([pts[0] * 2 - pts[1], pts, pts[-1] * 2 - pts[-2]])
    result_pts = []
    result_tans = []

    for i in range(1, len(pts_ext) - 2):
        p0, p1, p2, p3 = pts_ext[i-1], pts_ext[i], pts_ext[i+1], pts_ext[i+2]
        for t in np.linspace(0, 1, segments, endpoint=(i == len(pts_ext)-3)):
            t2 = t * t
            t3 = t2 * t
            
            # Catmull-Rom basis
            pos = 0.5 * ((2 * p1) +
                        (-p0 + p2) * t +
                        (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 +
                        (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
                        
            # Tangent
            tan = 0.5 * ((-p0 + p2) +
                        2 * (2 * p0 - 5 * p1 + 4 * p2 - p3) * t +
                        3 * (-p0 + 3 * p1 - 3 * p2 + p3) * t2)
            
            if np.linalg.norm(tan) > 1e-6:
                tan = tan / np.linalg.norm(tan)
            else:
                tan = np.array([0, 1, 0])
                
            result_pts.append(pos)
            result_tans.append(tan)

    return np.array(result_pts), np.array(result_tans)

def generate_ribbon_mesh(chain_data: List[Dict], 
                         segments: int = 10, thickness: float = 0.3, width: float = 1.6,
                         color_helix: List[float] = [0.8, 0.2, 0.2],
                         color_sheet: List[float] = [0.9, 0.8, 0.2],
                         color_coil: List[float] = [0.6, 0.6, 0.6]) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Extrudes a profile along the spline based on secondary structure.
    Returns: verts, norms, colors, indices
    """
    verts = []
    norms = []
    colors = []
    indices = []
    
    ca_pts = np.array([res['CA'] for res in chain_data if 'CA' in res])
    if len(ca_pts) < 4: return np.array([]), np.array([]), np.array([]), np.array([])
    
    # Heuristic for secondary structure assignment
    ss = assign_secondary_structure(ca_pts)
    spline_pts, tangents = generate_catmull_rom_spline(ca_pts, segments=segments)
    
    # Establish a stable up vector
    up = np.array([0, 1.0, 0])
    if len(tangents) > 0 and np.abs(np.dot(tangents[0], up)) > 0.95:
        up = np.array([1.0, 0, 0])
        
    normals = []
    binormals = []
    for i in range(len(tangents)):
        tan = tangents[i]
        binorm = np.cross(tan, up)
        
        # Robust binormal check to avoid degenerate frames
        if np.linalg.norm(binorm) < 1e-4:
            alt_up = np.array([1, 0, 0]) if np.abs(tan[0]) < 0.9 else np.array([0, 1, 0])
            binorm = np.cross(tan, alt_up)
            
        binorm_len = np.linalg.norm(binorm)
        if binorm_len > 1e-8:
            binorm /= binorm_len
        else:
            binorm = np.array([1, 0, 0]) # Last resort fallback
            
        up = np.cross(binorm, tan)
        up_len = np.linalg.norm(up)
        if up_len > 1e-8:
            up /= up_len
        else:
            up = np.array([0, 1, 0])
            
        normals.append(up)
        binormals.append(binorm)

    # Pad SS settings with smoothing to match spline points
    num_spline = len(spline_pts)
    target_widths = []
    target_thicks = []
    
    for s in ss:
        w, t = width, thickness
        # Calibrated multipliers for more realistic protein proportions
        if s == 'H': w, t = width * 1.8, thickness * 1.5  # Helical tube
        elif s == 'E': w, t = width * 2.8, thickness * 0.3 # Flat sheet ribbon
        else: w, t = width * 0.8, thickness * 0.8          # Thin coil
        target_widths.extend([w] * segments)
        target_thicks.extend([t] * segments)
        
    # Smooth width/thick arrays with a simple sliding window or linear interpolation
    # Here we just make sure they match the spline count
    target_widths = np.array(target_widths[:num_spline], dtype=np.float32)
    target_thicks = np.array(target_thicks[:num_spline], dtype=np.float32)
    
    # Kernel smoothing for transitions (simple 5-point average)
    if num_spline > 10:
        kernel = np.ones(8) / 8
        target_widths = np.convolve(target_widths, kernel, mode='same')
        target_thicks = np.convolve(target_thicks, kernel, mode='same')

    num_sides = 16 # Rounder profile
    angles = np.linspace(0, 2 * np.pi, num_sides, endpoint=False)
    circle_pts = np.column_stack([np.cos(angles), np.sin(angles)])
    
    for i in range(num_spline):
        p = spline_pts[i]
        n_base = normals[i]
        b_base = binormals[i]
        
        mode = ss[i // segments] if (i // segments) < len(ss) else 'C'
        c = color_helix if mode == 'H' else color_sheet if mode == 'E' else color_coil
        
        w, t = target_widths[i], target_thicks[i]
            
        for cx, cy in circle_pts:
            vert = p + cx * w * 0.5 * b_base + cy * t * 0.5 * n_base
            norm = cx * b_base + cy * n_base
            
            norm_len = np.linalg.norm(norm)
            if norm_len > 1e-6: norm /= norm_len
            
            verts.append(vert)
            norms.append(norm)
            colors.append(c)

    verts = np.array(verts, dtype=np.float32)
    norms = np.array(norms, dtype=np.float32)
    colors = np.array(colors, dtype=np.float32)

    # Generate Indices for triangles (Fixing Winding Order)
    for i in range(num_spline - 1):
        for j in range(num_sides):
            j1 = (j + 1) % num_sides
            v0 = i * num_sides + j
            v1 = i * num_sides + j1
            v2 = (i + 1) * num_sides + j
            v3 = (i + 1) * num_sides + j1
            
            # Winding: CCW (consistent)
            # v0, v1, v2
            indices.extend([v0, v1, v2])
            # v1, v3, v2
            indices.extend([v1, v3, v2])

    return verts, norms, colors, np.array(indices, dtype=np.uint32)

def calculate_rmsf(provider: Any, ca_indices: np.ndarray) -> np.ndarray:
    """
    Computes RMSF (Root Mean Square Fluctuation) for CA atoms across the trajectory.
    Returns: Å values per residue.
    """
    n_frames = len(provider)
    if n_frames < 2 or ca_indices.size == 0:
        return np.zeros(ca_indices.size)
    
    n_atoms = ca_indices.size
    all_pos = np.zeros((n_frames, n_atoms, 3))
    
    for i in range(n_frames):
        p_any, _, _, _, _, _ = provider.get(i)
        p = np.asarray(p_any, dtype=np.float32).reshape(-1, 3)
        all_pos[i] = p[ca_indices]
        
    avg_pos = np.mean(all_pos, axis=0)
    fluct = all_pos - avg_pos
    msf = np.mean(np.sum(fluct**2, axis=2), axis=0) # Mean square fluctuation
    return np.sqrt(msf)
