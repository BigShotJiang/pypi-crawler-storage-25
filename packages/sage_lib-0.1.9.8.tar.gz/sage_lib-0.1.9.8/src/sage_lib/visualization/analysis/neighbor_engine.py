from __future__ import annotations
import numpy as np
from typing import Tuple, List, Optional
try:
    from scipy.spatial import cKDTree
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False

class NeighborEngine:
    """
    Standardized neighbor search engine for SAGE.
    Handles cell lists, triclinic Minimum Image Convention (MIC), 
    and selection unwrapping for periodic structures.
    """
    
    @staticmethod
    def get_neighbors(pos: np.ndarray, 
                      lattice: np.ndarray, 
                      cutoff: float, 
                      pbc: bool = True) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Calculates all pair indices and scalar distances."""
        i, j, _, d = NeighborEngine.get_pair_displacements(pos, lattice, cutoff, pbc)
        # Filter self-interaction
        mask = d > 1e-5
        return i[mask], j[mask], d[mask]

    @staticmethod
    def get_pair_displacements(pos_a: np.ndarray, 
                               lattice: np.ndarray, 
                               cutoff: float, 
                               pbc: bool = True,
                               pos_b: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Extended periodic search that finds ALL images within 'cutoff'.
        If pos_b is provided, searches pairs (a in pos_a, b in pos_b).
        Otherwise searches self-pairs (a, b in pos_a).
        """
        if pos_b is None or pos_b is pos_a:
            pos_b = pos_a
            self_search = True
        else:
            self_search = False

        N_a = len(pos_a)
        N_b = len(pos_b)
        
        if N_a == 0 or N_b == 0:
            return np.array([], dtype=np.int32), np.array([], dtype=np.int32), \
                   np.zeros((0, 3), dtype=np.float32), np.array([], dtype=np.float32)

        if not pbc or lattice is None or np.allclose(lattice, 0):
            # Non-periodic search
            if HAS_SCIPY:
                tree_b = cKDTree(pos_b)
                res = tree_b.query_ball_point(pos_a, cutoff)
                i_l, j_l, v_l, d_l = [], [], [], []
                for i, neighbors in enumerate(res):
                    for j in neighbors:
                        if self_search and i == j: continue
                        vec = pos_b[j] - pos_a[i]
                        dist = np.linalg.norm(vec)
                        i_l.append(i); j_l.append(j); v_l.append(vec); d_l.append(dist)
                return np.array(i_l, dtype=np.int32), np.array(j_l, dtype=np.int32), \
                       np.array(v_l, dtype=np.float32), np.array(d_l, dtype=np.float32)
            else:
                i_l, j_l, v_l, d_l = [], [], [], []
                for i in range(N_a):
                    for j in range(N_b):
                        if self_search and i == j: continue
                        v = pos_b[j] - pos_a[i]
                        d = np.linalg.norm(v)
                        if d <= cutoff:
                            i_l.append(i); j_l.append(j); v_l.append(v); d_l.append(d)
                return np.array(i_l, dtype=np.int32), np.array(j_l, dtype=np.int32), \
                       np.array(v_l, dtype=np.float32), np.array(d_l, dtype=np.float32)

        # Periodic Search (Extended Supercell / MIC aware)
        try:
            h_inv = np.linalg.inv(lattice.T)
            cell_widths = 1.0 / np.linalg.norm(h_inv, axis=1)
            reps = np.ceil(cutoff / cell_widths).astype(int)
        except:
            reps = np.array([1, 1, 1], dtype=int)
            
        ranges = [np.arange(-r, r+1) for r in reps]
        grid = np.meshgrid(*ranges, indexing='ij')
        shifts_frac = np.stack(grid, axis=-1).reshape(-1, 3)
        latt_shifts = shifts_frac @ lattice
        
        i_list, j_list, v_list, d_list = [], [], [], []
        
        if HAS_SCIPY:
            # We tile pos_b and query pos_a against it
            super_pos_b = (pos_b[None, :, :] + latt_shifts[:, None, :]).reshape(-1, 3)
            super_indices_b = np.tile(np.arange(N_b), len(latt_shifts))
            
            tree = cKDTree(super_pos_b)
            res = tree.query_ball_point(pos_a, cutoff)
            
            for i, neighbors in enumerate(res):
                for neigh_idx in neighbors:
                    vec = super_pos_b[neigh_idx] - pos_a[i]
                    dist = np.linalg.norm(vec)
                    # Self-interaction filter only if we are searching same set AND same image (shift=0)
                    if self_search and dist < 1e-10: continue 
                    
                    i_list.append(i)
                    j_list.append(super_indices_b[neigh_idx])
                    v_list.append(vec)
                    d_list.append(dist)
        else:
            for shift_vec in latt_shifts:
                shifted_pos_b = pos_b + shift_vec
                for i in range(N_a):
                    for j in range(N_b):
                        vec = shifted_pos_b[j] - pos_a[i]
                        dist = np.linalg.norm(vec)
                        if self_search and dist < 1e-10: continue
                        if dist <= cutoff:
                            i_list.append(i); j_list.append(j); v_list.append(vec); d_list.append(dist)
                            
        return np.array(i_list, dtype=np.int32), np.array(j_list, dtype=np.int32), \
               np.array(v_list, dtype=np.float32), np.array(d_list, dtype=np.float32)

    @staticmethod
    def compute_mic_distances(pos_a: np.ndarray, pos_b: np.ndarray, lattice: np.ndarray) -> np.ndarray:
        """Calculates MIC distances for pairs of points in a triclinic cell."""
        diff = pos_b - pos_a
        inv_lat = np.linalg.inv(lattice)
        frac_diff = diff @ inv_lat
        frac_diff -= np.round(frac_diff)
        mic_diff = frac_diff @ lattice
        return np.linalg.norm(mic_diff, axis=1)

    @staticmethod
    def unwrap_selection(indices: np.ndarray, 
                        ref_index: int, 
                        pos: np.ndarray, 
                        lattice: np.ndarray) -> np.ndarray:
        """Unwraps a set of atoms relative to a reference atom index."""
        if len(indices) == 0: return np.zeros((0, 3))
        ref_pos = pos[ref_index]
        subset_pos = pos[indices]
        
        # Safety check for non-periodic or singular lattice
        if lattice is None or np.linalg.det(lattice) < 1e-6:
            return subset_pos
            
        try:
            inv_lat = np.linalg.inv(lattice)
            diff = subset_pos - ref_pos
            frac_diff = diff @ inv_lat
            frac_diff -= np.round(frac_diff)
            unwrapped = ref_pos + (frac_diff @ lattice)
            return unwrapped
        except np.linalg.LinAlgError:
            return subset_pos
