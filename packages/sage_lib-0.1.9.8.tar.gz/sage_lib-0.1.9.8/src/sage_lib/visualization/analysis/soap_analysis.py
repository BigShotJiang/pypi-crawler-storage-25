from __future__ import annotations
import numpy as np
import time
from typing import Dict, Any, Tuple, List, Optional
from ...miscellaneous.SOAP import SOAP
from .neighbor_engine import NeighborEngine

def calculate_soap_correlation(
    pos: np.ndarray,
    labels: List[str],
    lattice: np.ndarray,
    pbc: bool,
    center_symbol: str,
    species: List[str],
    r_cut: float,
    n_max: int,
    l_max: int,
    sigma: float,
    dr: float,
    fit_min: float,
    fit_max: float,
    search_cutoff: float = 20.0,
    dr_2d: float = 0.5,
    n_min: int = 5,
    plateau_r_range: Optional[Tuple[float, float]] = None,
    progress_callback: Optional[callable] = None
) -> Dict[str, Any]:
    """
    Worker function: Computes both 1D radial and 2D lateral SOAP structural correlation.
    """
    start_time = time.time()
    
    # --- 1. Filter Centers ---
    center_indices = np.where(np.array(labels) == center_symbol)[0]
    if len(center_indices) == 0:
        raise ValueError(f"No atoms found for center species: {center_symbol}")
    
    if progress_callback: progress_callback(0.05, f"Filtering {len(center_indices)} centers...")

    # --- 2. Compute SOAP Descriptors ---
    # We use a MockAtoms that already handles PBC neighbors internally for descriptors
    class MockAtoms:
        def __init__(self, full_pos, full_labels, lat, pbc):
            self.full_pos = full_pos
            self.full_labels = full_labels
            self.lat = lat
            self.pbc = pbc
            
            class MockManager:
                def __init__(self, parent):
                    self._parent = parent
                    self._atomPositions = parent.full_pos
                    self._atomLabelsList = parent.full_labels
                    self._uniqueAtomLabels = sorted(list(set(parent.full_labels)))
                    self._latticeVectors = parent.lat
                
                def find_all_neighbors_radius(self, center_pos, radius, p=2., eps=0):
                    # Use the new NeighborEngine displacements for consistency 
                    _, _, _, d = NeighborEngine.get_pair_displacements(
                        self._parent.full_pos, self._parent.lat, radius, self._parent.pbc
                    )
                    # This helper is for local envs, so center is always pos[i]
                    # Direct coordinate check for centers
                    r_vecs = self._parent.full_pos - center_pos
                    if self._parent.pbc and self._parent.lat is not None:
                        try:
                            inv_cell = np.linalg.inv(self._parent.lat)
                            frac = r_vecs @ inv_cell
                            r_vecs -= np.round(frac) @ self._parent.lat
                        except: pass
                    dists = np.linalg.norm(r_vecs, axis=1)
                    return np.where(dists < radius)[0].tolist()

            self.AtomPositionManager = MockManager(self)

    mock_atoms = MockAtoms(pos, labels, lattice, pbc)
    
    soap_engine = SOAP(
        species=species, periodic=pbc, r_cut=r_cut, n_max=n_max, l_max=l_max, sigma=sigma, verbose=False
    )
    descriptors = soap_engine.create(mock_atoms)
    if descriptors.shape[0] == len(labels):
        descriptors = descriptors[center_indices]
    
    # Normalization
    nan_mask = np.any(np.isnan(descriptors), axis=1)
    if np.any(nan_mask): descriptors[nan_mask] = 0.0
    norms = np.linalg.norm(descriptors, axis=1, keepdims=True)
    norms[norms < 1e-12] = 1.0
    descriptors = descriptors / norms
    
    # Diagnostics
    feat_std = np.nanmean(np.std(descriptors, axis=0))
    K_total = descriptors @ descriptors.T
    
    if progress_callback: progress_callback(0.4, "Querying pair displacements...")
    
    # --- 3. Pair Displacements (MIC-aware) ---
    center_pos = pos[center_indices]
    i_idx, j_idx, vectors, dists = NeighborEngine.get_pair_displacements(
        center_pos, lattice, search_cutoff, pbc=pbc
    )
    
    # Calculate similarities for all pairs
    similarities = np.sum(descriptors[i_idx] * descriptors[j_idx], axis=1)
    
    # --- 4. 1D Radial Correlation ---
    if progress_callback: progress_callback(0.6, "Computing radial profile...")
    bins_r = np.arange(0, search_cutoff + dr, dr)
    r_centers = bins_r[:-1] + dr/2
    sum_sim_r = np.zeros(len(bins_r)-1)
    counts_r = np.zeros(len(bins_r)-1)
    
    idx_r = np.digitize(dists, bins_r) - 1
    valid_r = (idx_r >= 0) & (idx_r < len(counts_r))
    np.add.at(sum_sim_r, idx_r[valid_r], similarities[valid_r])
    np.add.at(counts_r, idx_r[valid_r], 1)
    
    c_r = np.full(len(counts_r), np.nan)
    mask_r = counts_r > 0
    c_r[mask_r] = sum_sim_r[mask_r] / counts_r[mask_r]
    
    # Fitting plateau-aware model
    fit_lambda, fit_A, c_inf, fit_success = 0.0, 0.0, 0.0, False
    fit_r, fit_y = np.array([]), np.array([])
    try:
        from scipy.optimize import curve_fit
        valid_idx = np.where(np.isfinite(c_r))[0]
        if len(valid_idx) > 5:
            if plateau_r_range:
                p_mask = (r_centers >= plateau_r_range[0]) & (r_centers <= plateau_r_range[1]) & np.isfinite(c_r)
                c_inf = np.nanmean(c_r[p_mask]) if np.any(p_mask) else np.nanmean(c_r[valid_idx[-3:]])
            else:
                c_inf = np.nanmean(c_r[valid_idx[-max(3, int(0.1*len(valid_idx))):]])
            
            y_excess = c_r - c_inf
            f_mask = (r_centers >= fit_min) & (r_centers <= fit_max) & (y_excess > 0.01) & np.isfinite(y_excess)
            x_fit, y_fit = r_centers[f_mask], y_excess[f_mask]
            
            if len(x_fit) > 3:
                p0 = [max(y_fit[0], 0.1), 5.0]
                popt, _ = curve_fit(lambda r, A, L: A * np.exp(-r/L), x_fit, y_fit, p0=p0)
                fit_A, fit_lambda = popt
                fit_success = True
                fit_r = np.linspace(fit_min, r_centers[-1], 200)
                fit_y = c_inf + fit_A * np.exp(-fit_r / fit_lambda)
    except: pass

    # --- 5. 2D Lateral Correlation (dx, dy) ---
    if progress_callback: progress_callback(0.8, "Computing lateral map...")
    extent = search_cutoff
    bins_xy = np.arange(-extent, extent + dr_2d, dr_2d)
    grid_centers = bins_xy[:-1] + dr_2d/2
    
    # Symmetric binning: Add both (dx, dy) and (-dx, -dy) if not self
    dx = vectors[:, 0]; dy = vectors[:, 1]
    dx_full = np.concatenate([dx, -dx])
    dy_full = np.concatenate([dy, -dy])
    sim_full = np.concatenate([similarities, similarities])
    
    h_sum, _, _ = np.histogram2d(dx_full, dy_full, bins=[bins_xy, bins_xy], weights=sim_full)
    h_count, _, _ = np.histogram2d(dx_full, dy_full, bins=[bins_xy, bins_xy])
    
    c_xy = np.full(h_count.shape, np.nan)
    mask_xy = h_count >= n_min
    c_xy[mask_xy] = h_sum[mask_xy] / h_count[mask_xy]
    c_xy_excess = c_xy - c_inf
    
    # --- 6. Directional Cuts (Strip Averaged) ---
    strip_w = dr_2d * 1.5
    # X-cut: average over small dy strip
    x_strip_mask = (np.abs(dy_full) < strip_w)
    x_prof_bins = bins_xy
    x_axis_sum, _ = np.histogram(dx_full[x_strip_mask], bins=x_prof_bins, weights=sim_full[x_strip_mask])
    x_axis_cnt, _ = np.histogram(dx_full[x_strip_mask], bins=x_prof_bins)
    c_x = np.full(len(x_axis_cnt), np.nan)
    m_x = x_axis_cnt >= n_min
    c_x[m_x] = x_axis_sum[m_x] / x_axis_cnt[m_x]
    
    # Y-cut: average over small dx strip
    y_strip_mask = (np.abs(dx_full) < strip_w)
    y_prof_bins = bins_xy
    y_axis_sum, _ = np.histogram(dy_full[y_strip_mask], bins=y_prof_bins, weights=sim_full[y_strip_mask])
    y_axis_cnt, _ = np.histogram(dy_full[y_strip_mask], bins=y_prof_bins)
    c_y = np.full(len(y_axis_cnt), np.nan)
    m_y = y_axis_cnt >= n_min
    c_y[m_y] = y_axis_sum[m_y] / y_axis_cnt[m_y]

    # --- 7. Diagnostics & Result Packaging ---
    duration = time.time() - start_time
    # Masking stats
    total_bins = c_xy.size
    masked_bins = np.sum(~mask_xy)
    fraction_masked = masked_bins / total_bins
    
    return {
        "radial": {
            "r": r_centers.tolist(), "c_r": c_r.tolist(), "counts_r": counts_r.tolist(),
            "fit_r": fit_r.tolist(), "fit_y": fit_y.tolist(),
            "lambda": float(fit_lambda), "c_inf": float(c_inf), "fit_A": float(fit_A),
            "fit_success": fit_success
        },
        "lateral_2d": {
            "x": grid_centers.tolist(), "y": grid_centers.tolist(),
            "c_xy": c_xy.tolist(), "c_xy_excess": c_xy_excess.tolist(), "counts_xy": h_count.tolist(),
            "dr_2d": float(dr_2d), "n_min": int(n_min)
        },
        "directional": {
            "x_prof": (x_prof_bins[:-1] + dr_2d/2).tolist(), "c_x": c_x.tolist(),
            "y_prof": (y_prof_bins[:-1] + dr_2d/2).tolist(), "c_y": c_y.tolist()
        },
        "diagnostics": {
            "feat_std": float(feat_std), "duration": duration, "fraction_masked": float(fraction_masked),
            "n_centers": int(len(center_indices)), "n_pairs": int(len(dists))
        },
        "params": {
            "center_symbol": center_symbol, "search_cutoff": float(search_cutoff)
        }
    }
