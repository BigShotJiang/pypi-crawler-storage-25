from __future__ import annotations
import numpy as np
from typing import Dict, List, Any, Tuple, Optional
from collections import Counter
from .neighbor_engine import NeighborEngine
from ..constants import ATOMIC_MASSES, DEFAULT_MASS

class ClusterLocator:
    """
    Identifies connected components (clusters/molecules) in a structural graph.
    Computes geometric and chemical statistics for each cluster.
    """
    
    @staticmethod
    def find_clusters(N: int, i_idx: np.ndarray, j_idx: np.ndarray) -> np.ndarray:
        """
        Union-Find algorithm to label clusters.
        Returns: labels: np.ndarray (N,) where labels[i] is the cluster ID.
        """
        parent = np.arange(N)
        
        def find(i):
            if parent[i] == i:
                return i
            parent[i] = find(parent[i]) # Path compression
            return parent[i]

        def union(i, j):
            root_i = find(i)
            root_j = find(j)
            if root_i != root_j:
                parent[root_i] = root_j

        for i, j in zip(i_idx, j_idx):
            union(i, j)
            
        # Standardize labels
        labels = np.array([find(i) for i in range(N)], dtype=np.int32)
        
        # Re-map to 0..num_clusters-1
        unique_labels = np.unique(labels)
        label_map = {old: new for new, old in enumerate(unique_labels)}
        return np.array([label_map[l] for l in labels], dtype=np.int32)

    @staticmethod
    def get_cluster_stats(pos: np.ndarray, 
                         elements: List[str], 
                         labels: np.ndarray, 
                         lattice: Optional[np.ndarray] = None) -> List[Dict[str, Any]]:
        """
        Computes statistics for each cluster.
        Handles MIC unwrapping for geometric precision.
        """
        num_clusters = np.max(labels) + 1
        stats = []
        
        # Sort indices by label to process clusters efficiently
        indices = np.argsort(labels)
        sorted_labels = labels[indices]
        
        # Split indices into groups by label
        diff = np.diff(sorted_labels)
        boundaries = np.where(diff > 0)[0] + 1
        split_indices = np.split(indices, boundaries)
        
        for cluster_id, cluster_indices in enumerate(split_indices):
            if len(cluster_indices) == 0: continue
            
            c_pos_raw = pos[cluster_indices]
            c_elements = [elements[i] for i in cluster_indices]
            c_masses = np.array([ATOMIC_MASSES.get(e, DEFAULT_MASS) for e in c_elements])
            
            # 1. Unwrap cluster relative to lead atom
            if lattice is not None and not np.allclose(lattice, 0):
                c_pos = NeighborEngine.unwrap_selection(cluster_indices, cluster_indices[0], pos, lattice)
            else:
                c_pos = c_pos_raw
            
            # 2. Geometric Statistics
            centroid = np.mean(c_pos, axis=0)
            com = np.average(c_pos, axis=0, weights=c_masses)
            
            # Radius of Gyration
            # Rg^2 = 1/N * sum((r_i - centroid)^2)
            d2 = np.sum((c_pos - centroid)**2, axis=1)
            rg_geom = np.sqrt(np.mean(d2))
            
            # Mass-weighted Rg
            # Rg_mass^2 = sum(m_i * (r_i - com)^2) / sum(m_i)
            d2_m = np.sum((c_pos - com)**2, axis=1)
            rg_mass = np.sqrt(np.sum(c_masses * d2_m) / np.sum(c_masses))
            
            # 3. Chemical Statistics
            composition = dict(Counter(c_elements))
            
            stats.append({
                'id': cluster_id,
                'size': len(cluster_indices),
                'indices': cluster_indices,
                'centroid': centroid,
                'com': com,
                'rg_geometric': rg_geom,
                'rg_mass': rg_mass,
                'composition': composition
            })
            
        return stats
