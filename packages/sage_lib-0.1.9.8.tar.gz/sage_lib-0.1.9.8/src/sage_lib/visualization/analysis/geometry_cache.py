from __future__ import annotations
from OpenGL.GL import *
from typing import Dict, Any, Optional, Tuple
import time

class GeometryCache:
    """
    Manages GPU resources for derived geometries (Polyhedra, Voronoi, Hbonds).
    Handles version-based invalidation and LRU (Least Recently Used) eviction
    to keep the GPU memory footprint manageable.
    """
    def __init__(self, max_entries: int = 50):
        # Maps key -> { 'vao', 'vbos': [], 'ebo', 'version', 'last_used', 'count' }
        self._entries: Dict[str, Dict[str, Any]] = {}
        self.max_entries = max_entries

    def get(self, key: str, version: int) -> Optional[Dict[str, Any]]:
        """Retrieves entry from cache if version matches, updating last_used."""
        entry = self._entries.get(key)
        if entry:
            if entry['version'] == version:
                entry['last_used'] = time.time()
                return entry
            else:
                # Version mismatch: caller should probably invalidate it
                pass
        return None

    def put(self, key: str, version: int, count: int, vao: int, vbos: list[int], ebo: Optional[int] = None):
        """Stores a new GPU-side geometry entry, enforcing max_entries via LRU."""
        # If key already exists, clean up the old one first
        if key in self._entries:
            self.remove(key)
            
        # Evict if full
        if len(self._entries) >= self.max_entries:
            self._evict_lru()
            
        self._entries[key] = {
            'vao': vao,
            'vbos': vbos,
            'ebo': ebo,
            'version': version,
            'last_used': time.time(),
            'count': count
        }

    def remove(self, key: str):
        """Deletes GPU resources for a specific entry."""
        entry = self._entries.pop(key, None)
        if entry:
            self._delete_gpu_resources(entry)

    def _evict_lru(self):
        """Finds and removes the least recently used entry."""
        if not self._entries: return
        
        lru_key = min(self._entries, key=lambda k: self._entries[k]['last_used'])
        self.remove(lru_key)

    def _delete_gpu_resources(self, entry: Dict[str, Any]):
        """Explicitly calls OpenGL to free buffers."""
        try:
            if glIsVertexArray(entry['vao']):
                glDeleteVertexArrays(1, [entry['vao']])
            if entry['vbos'] is not None and len(entry['vbos']) > 0:
                glDeleteBuffers(len(entry['vbos']), entry['vbos'])
            if entry['ebo'] and glIsBuffer(entry['ebo']):
                glDeleteBuffers(1, [entry['ebo']])
        except Exception as e:
            print(f"[GeometryCache] Cleanup error for {entry}: {e}")

    def clear(self):
        """Clears all entries and releases all GPU resources."""
        keys = list(self._entries.keys())
        for k in keys:
            self.remove(k)

    def invalidate_by_type(self, type_prefix: str):
        """Invalidates all entries whose key starts with a specific prefix."""
        keys_to_remove = [k for k in self._entries.keys() if k.startswith(type_prefix)]
        for k in keys_to_remove:
            self.remove(k)

    def has_any_for_version(self, version: int) -> bool:
        """Returns True if any cached geometry entry matches the given version."""
        for entry in self._entries.values():
            if entry['version'] == version:
                return True
        return False
