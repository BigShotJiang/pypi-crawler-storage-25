from __future__ import annotations
import numpy as np
import time
from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple, Optional, Union
from .protein_geometry import BACKBONE_ATOMS
from .rotamer_templates import TEMPLATES, build_sidechain
from .clash_detection import compute_clash_report

@dataclass
class MutationRecord:
    """Atomic record of a structural modification for Undo/Redo tracking."""
    chain_index: Union[int, str]
    res_id: Union[int, str]
    old_resname: str
    target_resname: str
    
    # State Diffs
    deleted_indices: np.ndarray 
    deleted_data: Dict[str, Any] 
    
    insert_pos: int 
    added_count: int 
    
    timestamp: float = field(default_factory=time.time)
    
class MutationEngine:
    """
    Handles structural design modifications, clash validation, 
    and maintains an Undo/Redo stack for the design session.
    """
    def __init__(self, scene):
        self.scene = scene
        self.history: List[MutationRecord] = []
        self.redo_stack: List[MutationRecord] = []
        self.gly_atoms = BACKBONE_ATOMS

    def get_residue_atoms(self, chain_id: Union[int, str], res_id: Union[int, str]) -> np.ndarray:
        """Finds all global indices for a specific residue."""
        info = self.scene.info
        if not info or 'res_id' not in info: return np.array([], dtype=int)
        
        c_vals = info.get('chain_index', info.get('chain', ['-1']*self.scene.N))
        r_vals = info['res_id']
        
        c_str = np.array([str(x).strip() for x in c_vals])
        r_str = np.array([str(x).strip() for x in r_vals])
        
        target_c = str(chain_id).strip()
        target_r = str(res_id).strip()
        
        mask = (c_str == target_c) & (r_str == target_r)
        return np.where(mask)[0]

    def preview_mutation(self, chain_id: Union[int, str], res_id: Union[int, str], target: str) -> Dict[str, Any]:
        """Analyzes a proposed mutation without modifying the scene."""
        target = str(target).strip().upper()
        
        indices = self.get_residue_atoms(chain_id, res_id)
        if len(indices) == 0:
            return {"valid": False, "msg": f"Residue {res_id} (Chain {chain_id}) not found."}
            
        info = self.scene.info
        old_resname = str(info.get('res_name', ["UNK"]*self.scene.N)[indices[0]]).strip().upper()
        
        # PDB stores as 'atom_name', others might use 'name'
        raw_names = info.get('atom_name', info.get('name', ["X"]*self.scene.N))
        atom_names = [str(raw_names[i]).strip().upper() for i in indices]
        
        # Policy: Preserve only backbone, rebuild sidechain from template
        preserved = self.gly_atoms # N, CA, C, O
        
        added_atoms_dict = {}
        req = {"N": None, "CA": None, "C": None}
        for i, idx in enumerate(indices):
            name = atom_names[i]
            if name in req: req[name] = self.scene.pos[idx]
        
        if all(v is not None for v in req.values()):
            if target in TEMPLATES:
                added_atoms_dict = build_sidechain(target, req["N"], req["CA"], req["C"])
        elif target not in ["GLY"]:
            return {"valid": False, "msg": "Missing backbone atoms (N, CA, C) needed to orient mutation."}
            
        to_delete = [atom_names[i] for i, idx in enumerate(indices) if atom_names[i] not in preserved]
        to_hide_global = [indices[i] for i, name in enumerate(atom_names) if name not in preserved]
        
        clash_report = compute_clash_report(self.scene, indices.tolist(), added_atoms_dict)
        
        preview_points = []
        if added_atoms_dict:
            elements = TEMPLATES.get(target, {}).get("elements", ["C"]*len(added_atoms_dict))
            for i, (name, pos) in enumerate(added_atoms_dict.items()):
                preview_points.append({
                    "pos": pos,
                    "name": name,
                    "element": elements[i] if i < len(elements) else "C"
                })

        return {
            "valid": True, "chain": chain_id, "res_id": res_id, "old_res": old_resname, "target": target,
            "delete_count": len(to_delete), "add_count": len(added_atoms_dict),
            "atoms_deleted": to_delete, "indices_to_hide": to_hide_global,
            "clashes": clash_report, "ghost_points": preview_points,
            "msg": f"Mutation to {target} ready."
        }

    def apply_mutation(self, chain_id: Union[int, str], res_id: Union[int, str], target: str) -> bool:
        """Commits the mutation and pushes it to the Undo stack."""
        target = str(target).strip().upper()
        preview = self.preview_mutation(chain_id, res_id, target)
        if not preview["valid"]: return False
        
        indices = self.get_residue_atoms(chain_id, res_id)
        info = self.scene.info
        
        raw_names = info.get('atom_name', info.get('name', ["X"]*self.scene.N))
        atom_names = [str(raw_names[i]).strip().upper() for i in indices]
        
        preserved = self.gly_atoms
        print(f"[Mutation] {preview['old_res']} -> {target} (Res {res_id}, Chain {chain_id})")
        
        del_global_idx = np.sort([indices[i] for i, name in enumerate(atom_names) if name not in preserved])
        keep_global = sorted(list(set(indices) - set(del_global_idx)))
        insert_after = max(keep_global) if keep_global else max(indices)
        
        old_N = self.scene.N
        
        # 1. Backup state for Undo
        backup = {
            "pos": self.scene.pos[del_global_idx].copy() if len(del_global_idx) > 0 else np.array([]),
            "radii": self.scene.radii[del_global_idx].copy() if len(del_global_idx) > 0 else np.array([]),
            "colors": self.scene.colors[del_global_idx].copy() if len(del_global_idx) > 0 else np.array([]),
            "elements": [self.scene.elements[i] for i in del_global_idx],
            "info": {}
        }
        for k, v in self.scene.info.items():
            if isinstance(v, (list, np.ndarray)) and len(v) == old_N:
                backup["info"][k] = [v[i] for i in del_global_idx]
                
        # 2. Rename kept atoms (Update metadata)
        for idx in keep_global:
            if 'res_name' in self.scene.info: self.scene.info['res_name'][idx] = target

        # 3. Purge Deleted Atoms
        if len(del_global_idx) > 0:
            print(f"  - Deleting {len(del_global_idx)} atoms: {preview['atoms_deleted']}")
            mask = np.ones(self.scene.N, dtype=bool)
            mask[del_global_idx] = False
            self._apply_mask(mask)
            shift = np.sum(del_global_idx < insert_after)
            insert_after -= shift
            old_N -= len(del_global_idx)

        # 4. Insert New Atoms
        n_add = len(preview["ghost_points"])
        if n_add > 0:
            print(f"  - Adding {n_add} atoms for {target} sidechain.")
            new_pos = np.vstack([p["pos"] for p in preview["ghost_points"]])
            
            # Find CA radius to match sizing exactly
            ca_matches = [i for i, name in enumerate(atom_names) if name == "CA"]
            ca_ref_idx = indices[ca_matches[0]] if ca_matches else indices[0]
            ref_rad = self.scene.radii[ca_ref_idx] if len(self.scene.radii) > ca_ref_idx else 1.0
            new_radii = np.array([ref_rad for _ in range(n_add)], dtype=np.float32) 
            
            n_cols = self.scene.colors.shape[1] if len(self.scene.colors.shape) > 1 else 3
            new_colors = np.zeros((n_add, n_cols), dtype=np.float32)
            if n_cols > 3:
                new_colors[:, 3] = 1.0 
                
            from ..constants import CPK_COLORS
            for i, p in enumerate(preview["ghost_points"]): 
                color_val = CPK_COLORS.get(p["element"], [0.5, 0.5, 0.5])
                new_colors[i, :3] = color_val[:3] if len(color_val) > 2 else [0.5, 0.5, 0.5]
            
            ins = insert_after + 1
            self.scene.pos = np.insert(self.scene.pos, ins, new_pos, axis=0)
            self.scene.radii = np.insert(self.scene.radii, ins, new_radii)
            self.scene.colors = np.insert(self.scene.colors, ins, new_colors, axis=0)
            
            for i, p in enumerate(preview["ghost_points"]):
                self.scene.elements.insert(ins + i, p["element"])
            
            if self.scene.info:
                ca_matches = [i for i, name in enumerate(atom_names) if name == "CA"]
                ca_ref_idx = indices[ca_matches[0]] if ca_matches else indices[0]
                if len(del_global_idx) > 0:
                    ca_ref_idx -= np.sum(del_global_idx < ca_ref_idx)

                for k, v in self.scene.info.items():
                    if isinstance(v, (list, np.ndarray)) and len(v) == old_N:
                        vals_to_add = []
                        if k in ["name", "atom_name"]: vals_to_add = [p["name"] for p in preview["ghost_points"]]
                        elif k == "res_name": vals_to_add = [target] * n_add
                        else: vals_to_add = [v[ca_ref_idx]] * n_add 
                        
                        if isinstance(v, list):
                            for i, val in enumerate(vals_to_add): v.insert(ins + i, val)
                        else:
                            self.scene.info[k] = np.insert(v, ins, vals_to_add, axis=0)
            
            record_insert_pos = ins
        else:
            record_insert_pos = -1

        # Post-process
        self.scene.N = len(self.scene.pos)
        from collections import Counter
        counts = Counter(self.scene.elements)
        self.scene.composition_str = " ".join([f"{k}{v}" for k, v in sorted(counts.items())])
        self.scene.bonds = []
        self.scene.bond_count = 0
        
        record = MutationRecord(
            chain_index=chain_id, res_id=res_id, 
            old_resname=preview["old_res"], target_resname=target,
            deleted_indices=del_global_idx, deleted_data=backup,
            insert_pos=record_insert_pos, added_count=n_add
        )
        self.history.append(record)
        self.redo_stack.clear()
        
        print(f"  - Mutation successful. Atoms: {self.scene.N}")
        return True

    def undo(self) -> bool:
        """Reverts state using backups."""
        if not self.history: return False
        record = self.history.pop()
        
        if record.added_count > 0:
            mask = np.ones(self.scene.N, dtype=bool)
            mask[record.insert_pos : record.insert_pos + record.added_count] = False
            self._apply_mask(mask)
            
        if len(record.deleted_indices) > 0:
            for i, old_idx in enumerate(record.deleted_indices):
                self.scene.pos = np.insert(self.scene.pos, old_idx, record.deleted_data["pos"][i], axis=0)
                self.scene.radii = np.insert(self.scene.radii, old_idx, record.deleted_data["radii"][i])
                self.scene.colors = np.insert(self.scene.colors, old_idx, record.deleted_data["colors"][i], axis=0)
                self.scene.elements.insert(old_idx, record.deleted_data["elements"][i])
                for k, v in self.scene.info.items():
                    val = record.deleted_data["info"][k][i]
                    if isinstance(v, list): v.insert(old_idx, val)
                    else: self.scene.info[k] = np.insert(v, old_idx, val, axis=0)
            self.scene.N = len(self.scene.pos)
        
        new_indices = self.get_residue_atoms(record.chain_index, record.res_id)
        for idx in new_indices:
            if 'res_name' in self.scene.info: self.scene.info['res_name'][idx] = record.old_resname

        self.scene.clear_selection()
        self.scene.bonds = []
        self.scene.bond_count = 0
        self.redo_stack.append(record)
        return True

    def redo(self) -> bool:
        if not self.redo_stack: return False
        record = self.redo_stack.pop()
        return self.apply_mutation(record.chain_index, record.res_id, record.target_resname)

    def _apply_mask(self, mask: np.ndarray):
        self.scene.pos = self.scene.pos[mask]
        self.scene.radii = self.scene.radii[mask]
        self.scene.colors = self.scene.colors[mask]
        self.scene.elements = [e for i, e in enumerate(self.scene.elements) if mask[i]]
        if self.scene.info:
            for k in list(self.scene.info.keys()):
                v = self.scene.info[k]
                if isinstance(v, np.ndarray): self.scene.info[k] = v[mask]
                elif isinstance(v, list): self.scene.info[k] = [v_i for i, v_i in enumerate(v) if mask[i]]
        self.scene.N = self.scene.pos.shape[0]
        self.scene.clear_selection()
        self.scene.bonds = []
        self.scene.bond_count = 0
