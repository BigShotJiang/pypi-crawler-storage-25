from __future__ import annotations
import threading
import queue
import time
from typing import Dict, Any, Optional, Callable, List
import numpy as np
from .property_registry import PropertyRegistry

class AnalysisJob:
    """Represents a discrete unit of work for the background consumer."""
    def __init__(self, name: str, job_type: str, func: Callable, args: tuple = (), kwargs: dict = None, callback: Callable = None):
        self.name = name
        self.job_type = job_type
        self.func = func
        self.args = args
        self.kwargs = kwargs or {}
        self.callback = callback
        self.result = None
        self.error = None
        self.status = "pending" # pending, running, completed, failed

class AnalysisManager:
    """
    Orchestrates structural analysis for SAGE.
    Manages versioning, invalidation, and background job execution.
    """
    def __init__(self):
        # Versioning
        self.structure_version = 0
        self.selection_version = 0
        self.params_version = 0
        self.style_version = 0
        
        # Core Components
        self.property_registry = PropertyRegistry()
        self.cache: Dict[str, Any] = {}
        
        # Concurrency
        self._job_queue = queue.Queue()
        self._results_queue = queue.Queue()
        self._stop_event = threading.Event()
        self._worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self._worker_thread.start()
        
        # Active Jobs tracking
        self.active_jobs: Dict[str, AnalysisJob] = {}

    @property
    def registry(self) -> PropertyRegistry:
        """Alias for property_registry."""
        return self.property_registry

    def invalidate_structure(self):
        self.structure_version += 1
        self.cache.clear()
        self.property_registry.clear()

    def invalidate_selection(self):
        self.selection_version += 1

    def invalidate_params(self):
        self.params_version += 1

    def submit_job(self, task_name: str, kwargs: dict, callback: Optional[Callable] = None):
        """
        High-level dispatcher for analysis tasks.
        Maps job names to their respective calculation functions.
        """
        if task_name == "polyhedron":
            from .polyhedron import compute_single_polyhedron
            self.request_job(
                name=f"poly_{kwargs.get('index')}",
                job_type="polyhedron",
                func=compute_single_polyhedron,
                kwargs=kwargs,
                callback=callback
            )
        elif task_name == "batch_polyhedra":
            from .polyhedron_analyzer import PolyhedronAnalyzer
            def run_batch(scene, settings):
                analyzer = PolyhedronAnalyzer()
                return analyzer.build_polyhedra(scene, settings)

            self.request_job(
                name="batch_polyhedra",
                job_type="batch_polyhedra",
                func=run_batch,
                kwargs=kwargs,
                callback=callback
            )
        elif task_name == "soap_correlation":
            from .soap_analysis import calculate_soap_correlation
            self.request_job(
                name="soap_correlation",
                job_type="soap_correlation",
                func=calculate_soap_correlation,
                kwargs=kwargs,
                callback=callback
            )
        else:
            print(f"[AnalysisManager] Unknown task type: {task_name}")

    def request_job(self, name: str, job_type: str, func: Callable, args: tuple = (), kwargs: dict = None, callback: Callable = None):
        """Adds a job to the background queue."""
        if name in self.active_jobs and self.active_jobs[name].status == "running":
            return # Don't duplicate running jobs
            
        job = AnalysisJob(name, job_type, func, args, kwargs, callback)
        self.active_jobs[name] = job
        self._job_queue.put(job)

    def update(self):
        """Processes completed job results (called from main render thread)."""
        while not self._results_queue.empty():
            job = self._results_queue.get()
            if job.status == "completed":
                if job.callback:
                    job.callback(job.result)
            self.active_jobs.pop(job.name, None)

    def _worker_loop(self):
        """Background thread loop for CPU-bound analysis."""
        while not self._stop_event.is_set():
            try:
                job = self._job_queue.get(timeout=0.1)
                job.status = "running"
                try:
                    job.result = job.func(*job.args, **job.kwargs)
                    job.status = "completed"
                except Exception as e:
                    job.error = e
                    job.status = "failed"
                    print(f"[AnalysisManager] Job '{job.name}' failed: {e}")
                
                self._results_queue.put(job)
                self._job_queue.task_done()
            except queue.Empty:
                continue

    def stop(self):
        """Shuts down the worker thread."""
        self._stop_event.set()
        self._worker_thread.join(timeout=1.0)
        
    def get_cached(self, key: str, current_version: int) -> Optional[Any]:
        """Retrieves an item from cache if it matches the current version."""
        entry = self.cache.get(key)
        if entry and entry['version'] == current_version:
            return entry['data']
        return None

    def put_cache(self, key: str, data: Any, version: int):
        """Stores an item in cache with a version tag."""
        self.cache[key] = {'data': data, 'version': version}
