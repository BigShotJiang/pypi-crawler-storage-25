from __future__ import annotations
import numpy as np
from .neighbor_engine import NeighborEngine
from .geometry import compute_angle, compute_dihedral

class MeasurementTools:
    """
    MIC-aware measurement tools for distance, angle, and dihedral calculations.
    """
    def __init__(self, lattice: Optional[np.ndarray] = None):
        self.lattice = lattice
        self.is_periodic = lattice is not None and not np.allclose(lattice, 0)

    def distance(self, p1: np.ndarray, p2: np.ndarray) -> float:
        """Calculates MIC distance between two points."""
        if not self.is_periodic:
            return float(np.linalg.norm(p2 - p1))
            
        # Use MIC shift
        diff = p2 - p1
        inv_lat = np.linalg.inv(self.lattice)
        frac_diff = diff @ inv_lat
        frac_diff -= np.round(frac_diff)
        cart_diff = frac_diff @ self.lattice
        return float(np.linalg.norm(cart_diff))

    def angle(self, p1: np.ndarray, p2: np.ndarray, p3: np.ndarray) -> float:
        """Calculates MIC angle between three points (p2 is center)."""
        if not self.is_periodic:
            return compute_angle(p1, p2, p3)
        
        # Shift p1 and p3 relative to p2
        inv_lat = np.linalg.inv(self.lattice)
        
        d12 = p1 - p2
        f12 = d12 @ inv_lat
        f12 -= np.round(f12)
        p1_u = p2 + f12 @ self.lattice
        
        d32 = p3 - p2
        f32 = d32 @ inv_lat
        f32 -= np.round(f32)
        p3_u = p2 + f32 @ self.lattice
        
        return compute_angle(p1_u, p2, p3_u)

    def dihedral(self, p1: np.ndarray, p2: np.ndarray, p3: np.ndarray, p4: np.ndarray) -> float:
        """Calculates MIC dihedral between four points (1-2-3-4)."""
        if not self.is_periodic:
            return compute_dihedral(p1, p2, p3, p4)
            
        # Unwrap relative to neighbors
        inv_lat = np.linalg.inv(self.lattice)
        
        # p2 is fixed, unwrap others around the chain
        d12 = p1 - p2
        p1_u = p2 + (d12 @ inv_lat - np.round(d12 @ inv_lat)) @ self.lattice
        
        d32 = p3 - p2
        p3_u = p2 + (d32 @ inv_lat - np.round(d32 @ inv_lat)) @ self.lattice
        
        d43 = p4 - p3_u
        p4_u = p3_u + (d43 @ inv_lat - np.round(d43 @ inv_lat)) @ self.lattice
        
        return compute_dihedral(p1_u, p2, p3_u, p4_u)
