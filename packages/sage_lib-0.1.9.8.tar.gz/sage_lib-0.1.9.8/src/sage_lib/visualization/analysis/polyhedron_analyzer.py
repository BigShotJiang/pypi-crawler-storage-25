from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Any
import numpy as np
from scipy.spatial import ConvexHull
from .neighbor_engine import NeighborEngine
from .bond_graph import BondGraph
from ..constants import ATOMIC_RADII

@dataclass
class PolyhedronSettings:
    center_species: List[str] = field(default_factory=lambda: ["Ni", "Fe", "V"])
    ligand_species: List[str] = field(default_factory=lambda: ["O"])
    neighbor_mode: str = "bond_graph"  # bond_graph, covalent, manual, voronoi
    cutoff_factor: float = 1.25
    manual_cutoff: float = 2.6
    min_cn: int = 2
    max_cn: int = 12
    enabled_cn: Dict[int, bool] = field(default_factory=lambda: {i: True for i in range(2, 13)})
    enabled_species: Dict[str, bool] = field(default_factory=dict)
    max_distortion: float = 1e9
    center_radii_scale: float = 1.0
    corner_radii_scale: float = 1.0
    center_mode: str = "all" # all, selection, species
    show_wireframe: bool = False
    scale: float = 1.01

@dataclass
class Polyhedron:
    center_idx: int
    ligand_indices: List[int]
    center_element: str
    ligand_elements: List[str]
    cn: int
    geometry: str
    distortion: float
    angle_variance: float
    oct_score: float
    vertices: np.ndarray
    faces: np.ndarray

class PolyhedronAnalyzer:
    def build_polyhedra(self, scene: Any, settings: PolyhedronSettings) -> List[Polyhedron]:
        polyhedra = []
        
        if settings.center_mode == "all":
            centers = range(scene.N)
        elif settings.center_mode == "selection":
            centers = list(scene.selected_atoms)
        else: # species
            centers = [
                i for i, el in enumerate(scene.elements)
                if el in settings.center_species
            ]
        
        for i in centers:
            ligands = self._find_ligands(scene, i, settings)
            
            cn = len(ligands)
            if cn < settings.min_cn or cn > settings.max_cn:
                continue
            
            # Unwrap ligands to handle PBC
            # We need indices including center for unwrapping
            indices = np.concatenate([[i], ligands])
            unwrapped_pos = NeighborEngine.unwrap_selection(indices, i, scene.pos, scene.lat)
            
            # Central pos is at 0, ligands are the rest
            central_pos = unwrapped_pos[0]
            ligand_pos = unwrapped_pos[1:]
            
            faces = self._build_faces(ligand_pos)
            if len(faces) == 0 and cn >= 4:
                continue # Hull failed
            
            distortion, angle_var, oct_score = self._distortion_metrics(
                central_pos, ligand_pos, cn
            )
            
            geometry = self._classify_geometry(cn, oct_score, angle_var)
            
            if distortion > settings.max_distortion:
                continue
                
            polyhedra.append(
                Polyhedron(
                    center_idx=i,
                    ligand_indices=list(ligands),
                    center_element=scene.elements[i],
                    ligand_elements=[scene.elements[j] for j in ligands],
                    cn=cn,
                    geometry=geometry,
                    distortion=distortion,
                    angle_variance=angle_var,
                    oct_score=oct_score,
                    vertices=ligand_pos.astype(np.float32),
                    faces=faces.astype(np.int32),
                )
            )
            
        if polyhedra:
            from collections import Counter
            cns = [p.cn for p in polyhedra]
            print(f"[PolyhedronAnalyzer] Found {len(polyhedra)} polyhedra. CN distribution: {dict(Counter(cns))}")

        return polyhedra

    def _find_ligands(self, scene: Any, center_idx: int, settings: PolyhedronSettings) -> List[int]:
        if settings.neighbor_mode == "bond_graph":
            ligands = self._neighbors_from_bonds(scene, center_idx, settings)
            if ligands:
                return ligands
        
        if settings.neighbor_mode in ["covalent", "bond_graph"]:
            return self._neighbors_from_covalent(scene, center_idx, settings)
            
        if settings.neighbor_mode == "manual":
            return self._neighbors_from_cutoff(scene, center_idx, settings)
            
        if settings.neighbor_mode == "voronoi":
            return self._neighbors_from_voronoi(scene, center_idx, settings)
            
        return []

    def _neighbors_from_bonds(self, scene: Any, center_idx: int, settings: PolyhedronSettings) -> List[int]:
        """Finds ligands using the existing bond graph in the scene."""
        if not hasattr(scene, "bonds") or scene.bonds is None or len(scene.bonds) == 0:
            return []
            
        ligands = []
        for b in scene.bonds:
            i, j = b[0], b[1]
            if i == center_idx:
                if scene.elements[j] in settings.ligand_species:
                    ligands.append(j)
            elif j == center_idx:
                if scene.elements[i] in settings.ligand_species:
                    ligands.append(i)
        return ligands

    def _neighbors_from_covalent(self, scene: Any, center_idx: int, settings: PolyhedronSettings) -> List[int]:
        """Finds ligands using covalent radii factor."""
        r_center = ATOMIC_RADII.get(scene.elements[center_idx], 1.5)
        ligand_indices = [idx for idx, el in enumerate(scene.elements) if el in settings.ligand_species]
        if not ligand_indices:
            return []
            
        ligand_pos = scene.pos[ligand_indices]
        center_pos = scene.pos[center_idx]
        center_pos_expanded = np.tile(center_pos, (len(ligand_indices), 1))
        dists = NeighborEngine.compute_mic_distances(center_pos_expanded, ligand_pos, scene.lat)
        
        found = []
        for i, idx in enumerate(ligand_indices):
            if idx == center_idx: continue
            r_ligand = ATOMIC_RADII.get(scene.elements[idx], 1.5)
            cutoff = (r_center + r_ligand) * settings.cutoff_factor
            if dists[i] <= cutoff:
                found.append(idx)
        return found

    def _neighbors_from_cutoff(self, scene: Any, center_idx: int, settings: PolyhedronSettings) -> List[int]:
        """Finds ligands using manual cutoff."""
        ligand_indices = [idx for idx, el in enumerate(scene.elements) if el in settings.ligand_species]
        if not ligand_indices:
            return []
            
        ligand_pos = scene.pos[ligand_indices]
        center_pos = scene.pos[center_idx]
        center_pos_expanded = np.tile(center_pos, (len(ligand_indices), 1))
        dists = NeighborEngine.compute_mic_distances(center_pos_expanded, ligand_pos, scene.lat)
        
        found = []
        for i, idx in enumerate(ligand_indices):
            if idx == center_idx: continue
            if dists[i] <= settings.manual_cutoff:
                found.append(idx)
        return found

    def _neighbors_from_voronoi(self, scene: Any, center_idx: int, settings: PolyhedronSettings) -> List[int]:
        """Finds ligands using Voronoi neighbors."""
        from scipy.spatial import Voronoi
        # 1. Get candidates within a safety cutoff
        i_idx, j_idx, _ = NeighborEngine.get_neighbors(scene.pos, scene.lat, cutoff=6.0, pbc=scene.is_periodic)
        mask = (i_idx == center_idx)
        cand_indices = j_idx[mask]
        
        if len(cand_indices) < 4: return []
        
        # 2. Unwrap relative to center
        indices = np.concatenate([[center_idx], cand_indices])
        unwrapped_pos = NeighborEngine.unwrap_selection(indices, center_idx, scene.pos, scene.lat)
        
        # 3. Local Voronoi
        try:
            vor = Voronoi(unwrapped_pos)
            ligands = []
            for ridge_points in vor.ridge_points:
                if 0 in ridge_points:
                    other = ridge_points[0] if ridge_points[1] == 0 else ridge_points[1]
                    if other > 0:
                        orig_idx = cand_indices[other - 1]
                        if scene.elements[orig_idx] in settings.ligand_species:
                            ligands.append(orig_idx)
            return ligands
        except:
            return []

    def _build_faces(self, vertices: np.ndarray) -> np.ndarray:
        if len(vertices) < 3:
            # Cannot form a face with less than 3 points
            return np.zeros((0, 3), dtype=np.int32)
            
        # Ensure no NaN/Inf vertices enter face construction
        if not np.all(np.isfinite(vertices)):
            return np.zeros((0, 3), dtype=np.int32)

        if len(vertices) == 3:
            # Planar triangle
            return np.array([[0, 1, 2]], dtype=np.int32)
            
        try:
            hull = ConvexHull(vertices)
            return hull.simplices.astype(np.int32)
        except Exception:
            # Fallback for co-planar CN > 3: 
            # Only return the first triangle if we have enough vertices to be safe
            if len(vertices) >= 3:
                return np.array([[0, 1, 2]], dtype=np.int32)
            return np.zeros((0, 3), dtype=np.int32)

    def _distortion_metrics(self, center: np.ndarray, ligands: np.ndarray, cn: int) -> Tuple[float, float, float]:
        """Calculates distortion, angle variance, and oct score."""
        if len(ligands) == 0:
            return 0.0, 0.0, 0.0
            
        # 1. Bond length distortion (MAD / Mean)
        dists = np.linalg.norm(ligands - center, axis=1)
        mean_d = np.mean(dists)
        distortion = np.mean(np.abs(dists - mean_d)) / mean_d if mean_d > 0 else 0.0
        
        # 2. Angular metrics
        angle_var = 0.0
        oct_score = 0.0
        
        if cn >= 2:
            angles = []
            for i in range(len(ligands)):
                for j in range(i + 1, len(ligands)):
                    v1 = ligands[i] - center
                    v2 = ligands[j] - center
                    v1_norm = np.linalg.norm(v1)
                    v2_norm = np.linalg.norm(v2)
                    if v1_norm < 1e-6 or v2_norm < 1e-6: continue
                    v1 /= v1_norm
                    v2 /= v2_norm
                    dot = np.clip(np.dot(v1, v2), -1.0, 1.0)
                    angles.append(np.degrees(np.arccos(dot)))
            
            if angles:
                angles = np.array(angles)
                angle_var = np.var(angles)
                
                if cn == 6:
                    # Deviation from closest ideal octahedral angle (90 or 180)
                    diffs = np.minimum(np.abs(angles - 90), np.abs(angles - 180))
                    rms_dev = np.sqrt(np.mean(diffs**2))
                    oct_score = np.clip(1.0 - (rms_dev / 45.0), 0.0, 1.0)
                elif cn == 4:
                    # deviation from 109.5
                    diffs = np.abs(angles - 109.47)
                    rms_dev = np.sqrt(np.mean(diffs**2))
                    oct_score = np.clip(1.0 - (rms_dev / 45.0), 0.0, 1.0) # tetrahedral score
                
        return float(distortion), float(angle_var), float(oct_score)

    def _classify_geometry(self, cn: int, oct_score: float, angle_var: float) -> str:
        """Classifies geometry based on CN and metrics."""
        if cn == 2: return "Linear / Bent"
        if cn == 3: return "Trigonal Planar"
        if cn == 4: 
            if oct_score > 0.85: return "Tetrahedral"
            return "Distorted Tetrahedral"
        if cn == 5: return "Square Pyramidal"
        if cn == 6:
            if oct_score > 0.92: return "Octahedral"
            return "Distorted Octahedral"
        return "Unknown"
