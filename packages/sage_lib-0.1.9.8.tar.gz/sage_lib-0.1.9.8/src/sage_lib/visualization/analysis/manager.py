from __future__ import annotations
from typing import Any, Optional, List
import numpy as np

def _normalize_result_array(scene: Any, indices: np.ndarray, values: np.ndarray) -> np.ndarray:
    """
    Ensures analysis results adhere to the global atom index contract:
    - Shape: (scene.N,)
    - Uncomputed atoms: NaN
    """
    full_array = np.full(scene.N, np.nan, dtype=np.float32)
    # Ensure values are float32 for consistent mapping
    full_array[indices] = values.astype(np.float32)
    return full_array

def calc_bonds_simple(viewer: Any, scene: Optional[Any] = None):
    if scene is None: scene = viewer.scene
    s_idx = viewer.index1 if scene is viewer.scene else viewer.index2
    
    from .coordination import compute_coordination_sphere
    key = (id(scene), s_idx, viewer.bond_factor)
    if key in viewer._bond_cache:
        scene.bonds = viewer._bond_cache[key]
        scene.bond_count = len(scene.bonds)
        return

    _, _, _, bonds = compute_coordination_sphere(scene.pos, scene.elements, scene.lat, factor=viewer.bond_factor)
    
    scene.bonds = np.array(bonds, dtype=np.int32)
    scene.bond_count = len(scene.bonds)
    viewer._bond_cache[key] = scene.bonds

def get_clipped_indices(viewer: Any, scene: Any):
    """Returns indices of atoms that pass the current clipping filter."""
    if not viewer.display.clipping_enabled:
        return np.arange(scene.N)
        
    if viewer.clipping_fractional:
        inv_lat = np.linalg.inv(scene.lat)
        frac = scene.pos @ inv_lat
        vals = frac[:, viewer.clipping_axis]
    else:
        vals = scene.pos[:, viewer.clipping_axis]
        
    mask = (vals >= viewer.display.clipping_range[0]) & (vals <= viewer.display.clipping_range[1])
    if viewer.display.clipping_invert: mask = ~mask
    return np.where(mask)[0]

def calc_rdf(viewer: Any):
    """Computes all-species-pairs RDF and automatically shows the plot."""
    if not viewer.scene.N: 
        viewer.rdf_results.clear()
        return
        
    viewer.show_rdf = True 
    from .rdf import compute_rdf
    viewer.rdf_results.clear()
    
    indices = get_clipped_indices(viewer, viewer.scene)
    if not len(indices): return
    
    pos_clipped = viewer.scene.pos[indices]
    r, g = compute_rdf(pos_clipped, pos_clipped, viewer.scene.lat, 
                       r_max=viewer.rdf_rmax, bins=viewer.rdf_bins, mode=viewer.rdf_mode)
    viewer.rdf_results["Global"] = (r, g)
    
    species = viewer.scene.unique_elements
    if len(species) > 1:
        for i, sa in enumerate(species):
            idx_a = [k for k in indices if viewer.scene.elements[k] == sa]
            if not idx_a: continue
            for j in range(i, len(species)):
                sb = species[j]
                idx_b = [k for k in indices if viewer.scene.elements[k] == sb]
                if not idx_a or not idx_b: continue
                
                r_p, g_p = compute_rdf(viewer.scene.pos[idx_a], viewer.scene.pos[idx_b], viewer.scene.lat,
                                       r_max=viewer.rdf_rmax, bins=viewer.rdf_bins, mode=viewer.rdf_mode)
                lbl = f"{sa}-{sb}"
                viewer.rdf_results[lbl] = (r_p, g_p)
                if lbl not in viewer.rdf_visibility: viewer.rdf_visibility[lbl] = True
    
    if "Global" not in viewer.rdf_visibility: viewer.rdf_visibility["Global"] = True

def calc_z_profile(viewer: Any):
    """Computes Z-density profile for the current system."""
    if not viewer.scene.N: return
    from .rdf import compute_z_profile
    indices = get_clipped_indices(viewer, viewer.scene)
    if not len(indices): return
    x, y = compute_z_profile(viewer.scene.pos[indices])
    viewer.z_profile_x, viewer.z_profile_y = x, y

def calc_voronoi(viewer: Any):
    """Computes Voronoi tessellation and updates scene state with global normalization."""
    from .voronoi import VoronoiAnalyzer
    scene = viewer.scene
    indices = get_clipped_indices(viewer, scene)
    
    if len(indices) > 0:
        print(f"[Analysis] Calculating Voronoi for {len(indices)}/{scene.N} atoms...")
        res = VoronoiAnalyzer.compute_voronoi(scene.pos[indices], scene.lat)
        viewer.voro_results = res
        
        # Enforce (N,) Global Contract
        voro_full = _normalize_result_array(scene, indices, res["volumes"])
        scene.voro_volumes = voro_full
        
        if hasattr(viewer, 'analysis'):
            viewer.analysis.registry.register_property("voronoi_volume", voro_full)
            print(f"[Registry] Registered 'voronoi_volume' (finite={len(indices)}, nan={scene.N - len(indices)})")
            
        if hasattr(viewer, "_update_coloring"):
            viewer._update_coloring()

def calc_cn_distribution(viewer: Any):
    """Computes coordination distribution with global normalization."""
    from .coordination import compute_cn
    scene = viewer.scene
    indices = get_clipped_indices(viewer, scene)
    
    if len(indices) > 0:
        print(f"[Analysis] Calculating Coordination for {len(indices)}/{scene.N} atoms...")
        _, cnts = compute_cn(scene.pos[indices], scene.lat, r_cut=viewer.cn_cutoff)
        viewer.cn_results = cnts
        
        # Enforce (N,) Global Contract
        cn_full = _normalize_result_array(scene, indices, cnts)
        scene.cn = cn_full
        
        if hasattr(viewer, 'analysis'):
            viewer.analysis.registry.register_property("coordination", cn_full)
            print(f"[Registry] Registered 'coordination' (finite={len(indices)}, nan={scene.N - len(indices)})")
            
        if hasattr(viewer, "_update_coloring"):
            viewer._update_coloring()

def compute_selection_analytics(viewer: Any):
    """Lazy-compute pairwise / chain analytics for the current selection."""
    sel = viewer.scene.selected_atoms
    pos = viewer.scene.pos
    lat = viewer.scene.lat
    is_periodic = viewer.scene.is_periodic
    
    def get_diff(pa, pb):
        d = pb - pa
        if is_periodic:
            d = d - np.round(d @ np.linalg.inv(lat)) @ lat
        return d
        
    dists_seq = []
    angles_seq = []
    dihedrals_seq = []
    
    for i in range(len(sel)-1):
        dists_seq.append(np.linalg.norm(get_diff(pos[sel[i]], pos[sel[i+1]])))
        
    for i in range(len(sel)-2):
        d1, d2 = get_diff(pos[sel[i+1]], pos[sel[i]]), get_diff(pos[sel[i+1]], pos[sel[i+2]])
        cos_a = np.dot(d1, d2) / (np.linalg.norm(d1) * np.linalg.norm(d2) + 1e-9)
        angles_seq.append(np.degrees(np.arccos(np.clip(cos_a, -1.0, 1.0))))
        
    # (Dihedrals omitted for brevity/speed)
    
    return {
        "dists_seq": np.array(dists_seq),
        "angles_seq": np.array(angles_seq),
        "dihedrals_seq": np.array(dihedrals_seq)
    }
