from __future__ import annotations
import numpy as np
from typing import Dict, Any, List

def compute_clash_report(
    scene,
    exclude_indices: List[int],
    new_atom_positions: Dict[str, np.ndarray],
    severe_thresh: float = 2.0,
    mild_thresh: float = 2.5
) -> Dict[str, Any]:
    """
    Computes a vectorized clash array between a set of new atoms 
    and the rest of the protein, ignoring specified exclude_indices.
    """
    if not new_atom_positions or scene.N == 0:
        return {
            "severe_count": 0,
            "mild_count": 0,
            "min_distance": float('inf'),
            "worst_contacts": []
        }
        
    mask = np.ones(scene.N, dtype=bool)
    mask[exclude_indices] = False
    
    # We also ignore waters or unspecified solvent
    # For now, we only look at protein atoms if needed, but checking all non-excluded is safer
    
    env_pos = scene.pos[mask]
    if len(env_pos) == 0:
        return {
            "severe_count": 0,
            "mild_count": 0,
            "min_distance": float('inf'),
            "worst_contacts": []
        }
        
    # Get global indices of environment
    env_indices = np.where(mask)[0]
    
    # Names for reporting
    info = scene.info
    env_res_names = info.get('res_name', ["UNK"]*scene.N) if info else ["UNK"]*scene.N
    env_atom_names = info.get('name', ["X"]*scene.N) if info else ["X"]*scene.N
    env_res_ids = info.get('res_id', [-1]*scene.N) if info else [-1]*scene.N
    
    severe_count = 0
    mild_count = 0
    min_dist = float('inf')
    contacts = []
    
    for atm_name, pos in new_atom_positions.items():
        diff = env_pos - pos
        dists = np.linalg.norm(diff, axis=-1)
        
        # Min dist update
        current_min = np.min(dists)
        if current_min < min_dist:
            min_dist = current_min
            
        # Severes
        severe_idx = np.where(dists < severe_thresh)[0]
        severe_count += len(severe_idx)
        for idx in severe_idx:
            g_idx = env_indices[idx]
            rname = env_res_names[g_idx]
            rid = env_res_ids[g_idx]
            aname = env_atom_names[g_idx]
            contacts.append((atm_name, f"{rname}{rid}:{aname}", float(dists[idx])))
            
        # Milds
        mild_idx = np.where((dists >= severe_thresh) & (dists < mild_thresh))[0]
        mild_count += len(mild_idx)
        for idx in mild_idx:
            g_idx = env_indices[idx]
            rname = env_res_names[g_idx]
            rid = env_res_ids[g_idx]
            aname = env_atom_names[g_idx]
            contacts.append((atm_name, f"{rname}{rid}:{aname}", float(dists[idx])))
            
    # Sort contacts by distance
    contacts.sort(key=lambda x: x[2])
    
    return {
        "severe_count": severe_count,
        "mild_count": mild_count,
        "min_distance": float(min_dist),
        "worst_contacts": contacts[:5]  # Top 5 offending
    }
