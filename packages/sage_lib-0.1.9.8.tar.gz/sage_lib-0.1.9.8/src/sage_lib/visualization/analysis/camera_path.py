from __future__ import annotations
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.spatial.transform import Rotation, Slerp
from typing import List, Dict, Any, Optional

class CameraPath:
    """
    Handles smooth, deterministic interpolation across multiple camera keyframes.
    Uses Cubic Splines for positions and SLERP for orientations.
    """
    def __init__(self, keyframes: List[Dict[str, Any]]):
        self.keyframes = keyframes
        self.num_keys = len(keyframes)
        
        if self.num_keys < 2:
            return

        # Normalized time for each keyframe [0, 1, 2, ..., N-1]
        self.times = np.arange(self.num_keys)
        
        # 1. Position Spline (Center)
        centers = np.array([k['center'] for k in keyframes])
        self.center_spline = CubicSpline(self.times, centers, bc_type='clamped')
        
        # 2. Distance Spline (Lnorm of Offset)
        offsets = np.array([k['offset'] for k in keyframes])
        distances = np.linalg.norm(offsets, axis=1)
        self.dist_spline = CubicSpline(self.times, distances, bc_type='clamped')
        
        # 3. Orientation SLERP
        # We need a Rotation object for each keyframe.
        # We'll construct it from the offset direction and UP vector.
        rots = []
        for k in keyframes:
            # Look At logic to get rotation
            eye = k['offset'] # Relative eye
            forward = -eye / (np.linalg.norm(eye) + 1e-12)
            up = k.get('up', np.array([0, 0, 1]))
            right = np.cross(forward, up)
            right /= (np.linalg.norm(right) + 1e-12)
            actual_up = np.cross(right, forward)
            
            # Rotation matrix: [right, actual_up, -forward]
            mat = np.eye(3)
            mat[:, 0] = right
            mat[:, 1] = actual_up
            mat[:, 2] = -forward
            rots.append(Rotation.from_matrix(mat))
            
        self.orientation_slerp = Slerp(self.times, Rotation.from_quat([r.as_quat() for r in rots]))
        
        # 4. Misc Splines (FOV, Pan, OrthoScale)
        fovs = np.array([k.get('fov', 45.0) for k in keyframes])
        self.fov_spline = CubicSpline(self.times, fovs, bc_type='clamped')
        
        pans = np.array([k.get('pan', [0.0, 0.0]) for k in keyframes])
        self.pan_spline = CubicSpline(self.times, pans, bc_type='clamped')
        
        scales = np.array([k.get('ortho_scale', 20.0) for k in keyframes])
        self.scale_spline = CubicSpline(self.times, scales, bc_type='clamped')

        # 5. Structural Index (Linear interpolation for trajectories)
        self.struct_indices = np.array([k.get('structure_index', 0) for k in keyframes])

    def sample(self, u: float, easing_func: Optional[callable] = None) -> Dict[str, Any]:
        """
        Samples the camera state at normalized time u in [0, 1].
        
        Args:
            u: Normalized progress (0.0 to 1.0)
            easing_func: Optional function to remap u
        """
        if self.num_keys == 0: return {}
        if self.num_keys == 1: 
            res = self.keyframes[0].copy()
            res['structure_index'] = self.keyframes[0].get('structure_index', 0)
            return res
        
        # Apply easing to u
        t_global = u * (self.num_keys - 1)
        
        # 1. Sample Splines
        center = self.center_spline(t_global)
        dist = float(self.dist_spline(t_global))
        fov = float(self.fov_spline(t_global))
        pan = self.pan_spline(t_global)
        scale = float(self.scale_spline(t_global))
        
        # 2. Sample Orientation
        rot = self.orientation_slerp(t_global)
        mat = rot.as_matrix()
        
        # Reconstruct offset and up from rotation matrix
        # mat = [right, up, -forward]
        right = mat[:, 0]
        up = mat[:, 1]
        forward = -mat[:, 2]
        
        offset = -forward * dist

        # 3. Sample Structure Index (Linear)
        # We find the interval and interpolate linearly
        idx_low = int(np.floor(t_global))
        idx_high = min(self.num_keys - 1, idx_low + 1)
        frac = t_global - idx_low
        if idx_low == idx_high:
            struct_idx = float(self.struct_indices[idx_low])
        else:
            struct_idx = float(self.struct_indices[idx_low] + (self.struct_indices[idx_high] - self.struct_indices[idx_low]) * frac)
        
        return {
            "center": center,
            "offset": offset,
            "up": up,
            "fov": fov,
            "pan": pan,
            "ortho_scale": scale,
            "is_ortho": self.keyframes[0].get('is_ortho', False),
            "structure_index": struct_idx
        }
