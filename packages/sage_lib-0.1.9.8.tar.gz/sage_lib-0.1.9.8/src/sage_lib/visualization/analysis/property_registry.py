from __future__ import annotations
import numpy as np
from typing import Dict, Any, Optional, List

class PropertyRegistry:
    """
    Centralized storage for atomic and geometric properties (scalar and vector).
    Allows different modules (Query Engine, Inspector, Renderers) to share data
    without direct coupling.
    """
    def __init__(self):
        # Maps name -> { 'data': np.ndarray, 'version': int, 'type': str }
        self._properties: Dict[str, Dict[str, Any]] = {}

    def __iter__(self):
        """Allows iteration over registered property names."""
        return iter(self._properties)

    def __getitem__(self, name: str) -> np.ndarray:
        """Allows dict-like access: registry['cn'] -> data array."""
        return self.get(name)

    def __bool__(self) -> bool:
        """Returns True if any properties are registered."""
        return bool(self._properties)
    
    def __len__(self) -> int:
        """Returns the number of registered properties."""
        return len(self._properties)

    def __contains__(self, name: str) -> bool:
        """Allows 'name in registry' checks."""
        return name in self._properties

    def register(self, name: str, data: np.ndarray, version: int, prop_type: str = "scalar"):
        """
        Registers or updates a property.
        
        Args:
            name: Unique identifier for the property (e.g., 'cn', 'voro_volume')
            data: NumPy array of shape (N,) or (N, K)
            version: The version of the analysis that produced this data
            prop_type: 'scalar', 'vector', or 'string'
        """
        self._properties[name] = {
            'data': np.asarray(data),
            'version': version,
            'type': prop_type
        }

    def get(self, name: str) -> Optional[np.ndarray]:
        """Returns the data for a given property name if it exists."""
        entry = self._properties.get(name)
        return entry['data'] if entry else None

    def get_property(self, name: str) -> Optional[np.ndarray]:
        """Alias for get()."""
        return self.get(name)

    def get_version(self, name: str) -> int:
        """Returns the version of a given property name, or -1 if not found."""
        entry = self._properties.get(name)
        return entry['version'] if entry else -1

    def list_properties(self) -> List[str]:
        """Returns a list of all registered property names."""
        return list(self._properties.keys())

    def get_all_properties(self) -> Dict[str, np.ndarray]:
        """Returns a dictionary mapping all property names to their data arrays."""
        return {name: entry['data'] for name, entry in self._properties.items()}

    def clear(self):
        """Clears all registered properties."""
        self._properties.clear()

    def clear_property(self, name: str):
        """Removes a specific property from the registry."""
        self._properties.pop(name, None)

    def register_property(self, name: str, data: np.ndarray, version: int = 0, prop_type: str = "scalar"):
        """Alias for register() with optional version."""
        self.register(name, data, version, prop_type)

    def has_property(self, name: str) -> bool:
        """Checks if a property exists."""
        return name in self._properties

    def get_all_for_index(self, idx: int) -> Dict[str, Any]:
        """Returns a dictionary of all properties for a specific atom index."""
        res = {}
        for name, entry in self._properties.items():
            data = entry['data']
            if data.ndim == 0:
                # Global / scalar property
                res[name] = data.item()
            elif idx < len(data):
                val = data[idx]
                # Convert numpy types to python native for easier rendering
                if hasattr(val, 'item'):
                    res[name] = val.item()
                else:
                    res[name] = val
        return res

    def log_warning(self, message: str):
        """Logs a warning message related to property registration or access."""
        # For now, we just print to console. 
        # Future: Hook into a GUI notification system.
        print(f"[PropertyRegistry] WARNING: {message}")
