from __future__ import annotations
# sage_lib.visualization.analysis package
