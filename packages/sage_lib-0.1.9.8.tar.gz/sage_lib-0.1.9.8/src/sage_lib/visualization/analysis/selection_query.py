from __future__ import annotations
import ast
import operator
import numpy as np
from typing import Dict, Any, List, Optional, Set

class SelectionQueryEvaluator:
    """
    Safe AST-based evaluator for atomic selection queries.
    Converts a string query into a NumPy boolean mask.
    """
    
    # Supported operators mapped to NumPy/Python equivalents
    OPERATORS = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.Pow: operator.pow,
        ast.BitAnd: operator.and_,
        ast.BitOr: operator.or_,
        ast.Eq: operator.eq,
        ast.NotEq: operator.ne,
        ast.Lt: operator.lt,
        ast.LtE: operator.le,
        ast.Gt: operator.gt,
        ast.GtE: operator.ge,
        ast.And: np.logical_and,
        ast.Or: np.logical_or,
        ast.Not: np.logical_not,
        ast.In: lambda a, b: np.isin(a, b),
        ast.NotIn: lambda a, b: ~np.isin(a, b),
    }

    # Aliases for convenience
    ALIASES = {
        "elem": "element",
        "el": "element",
        "sel": "selected",
        "cn": "coordination_number",
        "voro": "voro_volume",
        "res": "residue",
    }

    def __init__(self, property_registry_data: Dict[str, np.ndarray]):
        """
        Args:
            property_registry_data: Dictionary mapping internal property names to NumPy arrays.
        """
        # Store as lowercase for case-insensitive lookup
        self.data = {k.lower(): v for k, v in property_registry_data.items()}
        self.N = 0
        if self.data:
            # Assume all arrays have the same first dimension N
            first_key = next(iter(self.data))
            self.N = len(self.data[first_key])

    def evaluate(self, query: str) -> np.ndarray:
        """
        Parses and evaluates the query string.
        Returns a boolean mask of shape (N,).
        """
        if not query or query.strip() == "":
            return np.ones(self.N, dtype=bool)

        try:
            tree = ast.parse(query, mode='eval')
            result = self._eval_node(tree.body)
            
            # Ensure we return a boolean mask of the right length
            if isinstance(result, bool):
                return np.full(self.N, result, dtype=bool)
            if isinstance(result, np.ndarray):
                if result.dtype != bool:
                    result = result.astype(bool)
                return result
            
            raise ValueError(f"Query returned unexpected type: {type(result)}")
            
        except SyntaxError as se:
            raise ValueError(f"Selection syntax error: {se.msg} at line {se.lineno}")
        except Exception as e:
            raise ValueError(f"Selection evaluation error: {str(e)}")

    def _eval_node(self, node: ast.AST) -> Any:
        if isinstance(node, ast.Num):  # ast.Num is deprecated in 3.8+ but kept for compat
            return node.n
        elif isinstance(node, ast.Constant): # Python 3.8+
            return node.value
        elif isinstance(node, ast.Str): # Deprecated but kept
            return node.s
        elif isinstance(node, ast.Name):
            name = node.id.lower()
            # Handle aliases
            real_name = self.ALIASES.get(name, name)
            if real_name in self.data:
                return self.data[real_name]
            raise ValueError(f"Unknown property: '{name}' (Available: {', '.join(self.data.keys())})")
            
        elif isinstance(node, ast.BinOp):
            left = self._eval_node(node.left)
            right = self._eval_node(node.right)
            op_func = self.OPERATORS.get(type(node.op))
            if not op_func:
                raise ValueError(f"Unsupported binary operator: {type(node.op)}")
            return op_func(left, right)
            
        elif isinstance(node, ast.Compare):
            left = self._eval_node(node.left)
            result = np.ones(self.N, dtype=bool) if isinstance(left, np.ndarray) else True
            
            for op, comparator in zip(node.ops, node.comparators):
                right = self._eval_node(comparator)
                op_func = self.OPERATORS.get(type(op))
                if not op_func:
                    raise ValueError(f"Unsupported comparison operator: {type(op)}")
                
                # result &= op_func(left, right)
                # For NumPy:
                step_result = op_func(left, right)
                result = np.logical_and(result, step_result)
                left = right # Chain support (e.g. 5 < x < 10)
            return result

        elif isinstance(node, ast.BoolOp):
            op_func = self.OPERATORS.get(type(node.op))
            if not op_func:
                 raise ValueError(f"Unsupported boolean operator: {type(node.op)}")
            
            values = [self._eval_node(v) for v in node.values]
            res = values[0]
            for v in values[1:]:
                res = op_func(res, v)
            return res

        elif isinstance(node, ast.UnaryOp):
            op_func = self.OPERATORS.get(type(node.op))
            if not op_func:
                raise ValueError(f"Unsupported unary operator: {type(node.op)}")
            operand = self._eval_node(node.operand)
            return op_func(operand)

        elif isinstance(node, ast.List):
            return [self._eval_node(elt) for elt in node.elts]

        elif isinstance(node, ast.Attribute):
            # Could be used for pos.x, but we use flat x, y, z as requested
            raise ValueError("Attribute access (e.g., node.attribute) is not supported. Use 'x', 'y', 'z' directly.")

        else:
            raise ValueError(f"Unsupported syntax tree element: {type(node)}")
