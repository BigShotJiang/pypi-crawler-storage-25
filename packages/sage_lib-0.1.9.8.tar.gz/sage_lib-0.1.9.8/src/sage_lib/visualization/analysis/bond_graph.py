from __future__ import annotations
import numpy as np
from typing import Tuple, List, Optional, Dict
from .neighbor_engine import NeighborEngine
from ..constants import ATOMIC_RADII

class BondGraph:
    """
    Standardized interface for connectivity graphs.
    Separates purely geometric contacts from chemical bonds and coordination shells.
    """
    
    @staticmethod
    def get_geom_graph(pos: np.ndarray, 
                       lattice: np.ndarray, 
                       cutoff: float, 
                       pbc: bool = True) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Pure distance-based contact graph."""
        return NeighborEngine.get_neighbors(pos, lattice, cutoff, pbc)

    @staticmethod
    def get_bond_graph(pos: np.ndarray, 
                       elements: List[str], 
                       lattice: np.ndarray, 
                       factor: float = 1.2, 
                       pbc: bool = True) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Chemical/Covalent connectivity graph.
        Criterion: dist(i, j) < factor * (radii[i] + radii[j])
        """
        if not elements or len(elements) != len(pos):
            empty_i = np.array([], dtype=np.int32)
            return empty_i, empty_i, np.array([], dtype=np.float32)

        radii = np.array([ATOMIC_RADII.get(e, 1.5) for e in elements], dtype=np.float32)
        max_r = np.max(radii)
        max_cutoff = factor * (max_r + max_r)
        
        # 1. Get candidate pairs using a generous max cutoff
        i_cand, j_cand, dist_cand = NeighborEngine.get_neighbors(pos, lattice, max_cutoff, pbc)
        
        if len(i_cand) == 0:
            return i_cand, j_cand, dist_cand

        # 2. Filter by per-atom covalent radii
        actual_cutoffs = factor * (radii[i_cand] + radii[j_cand])
        mask = dist_cand <= actual_cutoffs
        
        return i_cand[mask], j_cand[mask], dist_cand[mask]

    @staticmethod
    def get_coord_graph(pos: np.ndarray, 
                        lattice: np.ndarray, 
                        cutoff: float = 3.5, 
                        pbc: bool = True) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Coordination shell graph (typically for polyhedra).
        Often uses a larger or fixed cutoff to capture distorted shells.
        """
        return NeighborEngine.get_neighbors(pos, lattice, cutoff, pbc)

    @staticmethod
    def build_adjacency_list(i_idx: np.ndarray, j_idx: np.ndarray, N: int) -> List[List[int]]:
        """Converts pair indices to a standard adjacency list."""
        adj = [[] for _ in range(N)]
        for i, j in zip(i_idx, j_idx):
            adj[i].append(int(j))
            adj[j].append(int(i))
        return adj
