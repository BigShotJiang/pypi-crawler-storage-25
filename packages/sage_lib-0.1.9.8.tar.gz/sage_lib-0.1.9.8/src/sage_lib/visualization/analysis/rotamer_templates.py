from __future__ import annotations
import numpy as np

# Approximate internal coordinates relative to the canonical N-CA-C local frame
# Frame definition:
# Origin = CA
# X-axis = direction of CA -> N
# Z-axis = Cross(N-CA, C-CA) (normal to backbone plane)
# Y-axis = Cross(Z, X)

# Atoms defined as lists of [x, y, z] in Angstroms
TEMPLATES = {
    "SER": {
        "atoms": ["CB", "OG"],
        "elements": ["C", "O"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "OG": [-0.20, -1.20, 2.30]}]
    },
    "VAL": {
        "atoms": ["CB", "CG1", "CG2"],
        "elements": ["C", "C", "C"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG1": [0.20, -2.10, 1.30], "CG2": [-1.80, -1.50, 0.30]}]
    },
    "PHE": {
        "atoms": ["CB", "CG", "CD1", "CD2", "CE1", "CE2", "CZ"],
        "elements": ["C", "C", "C", "C", "C", "C", "C"],
        "rotamers": [{
            "CB": [-0.53, -1.06, 0.94], "CG": [-0.80, -1.60, 2.30],
            "CD1": [-0.10, -2.70, 2.70], "CD2": [-1.90, -1.00, 3.10],
            "CE1": [-0.50, -3.20, 3.90], "CE2": [-2.30, -1.50, 4.30], "CZ": [-1.60, -2.60, 4.70]
        }]
    },
    "ASP": {
        "atoms": ["CB", "CG", "OD1", "OD2"],
        "elements": ["C", "C", "O", "O"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG": [-0.60, -1.80, 2.20], "OD1": [0.40, -2.30, 2.60], "OD2": [-1.70, -1.90, 2.80]}]
    },
    "GLU": {
        "atoms": ["CB", "CG", "CD", "OE1", "OE2"],
        "elements": ["C", "C", "C", "O", "O"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG": [-0.60, -1.80, 2.20], "CD": [-0.50, -2.80, 3.20], "OE1": [0.60, -3.20, 3.50], "OE2": [-1.60, -3.20, 3.70]}]
    },
    "LYS": {
        "atoms": ["CB", "CG", "CD", "CE", "NZ"],
        "elements": ["C", "C", "C", "C", "N"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG": [-0.60, -1.80, 2.20], "CD": [-0.50, -2.80, 3.20], "CE": [-0.60, -3.60, 4.30], "NZ": [-0.20, -4.60, 5.00]}]
    },
    "ARG": {
        "atoms": ["CB", "CG", "CD", "NE", "CZ", "NH1", "NH2"],
        "elements": ["C", "C", "C", "N", "C", "N", "N"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG": [-0.60, -1.80, 2.20], "CD": [-0.50, -2.80, 3.20], "NE": [-1.20, -3.60, 4.10], "CZ": [-1.00, -4.40, 5.00], "NH1": [0.10, -4.80, 5.40], "NH2": [-2.10, -4.80, 5.50]}]
    },
    "HIS": {
        "atoms": ["CB", "CG", "ND1", "CD2", "CE1", "NE2"],
        "elements": ["C", "C", "N", "C", "C", "N"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG": [-0.80, -1.60, 2.20], "ND1": [-0.10, -2.20, 3.20], "CD2": [-2.10, -1.60, 2.70], "CE1": [-0.10, -2.60, 4.30], "NE2": [-1.30, -2.20, 4.00]}]
    },
    "ASN": {
        "atoms": ["CB", "CG", "OD1", "ND2"],
        "elements": ["C", "C", "O", "N"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG": [-0.60, -1.80, 2.20], "OD1": [0.40, -2.20, 2.70], "ND2": [-1.70, -2.00, 2.80]}]
    },
    "GLN": {
        "atoms": ["CB", "CG", "CD", "OE1", "NE2"],
        "elements": ["C", "C", "C", "O", "N"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG": [-0.60, -1.80, 2.20], "CD": [-0.50, -2.80, 3.20], "OE1": [0.60, -3.20, 3.60], "NE2": [-1.60, -3.20, 3.80]}]
    },
    "TYR": {
        "atoms": ["CB", "CG", "CD1", "CD2", "CE1", "CE2", "CZ", "OH"],
        "elements": ["C", "C", "C", "C", "C", "C", "C", "O"],
        "rotamers": [{
            "CB": [-0.53, -1.06, 0.94], "CG": [-0.80, -1.60, 2.30],
            "CD1": [-0.10, -2.70, 2.70], "CD2": [-1.90, -1.00, 3.10],
            "CE1": [-0.50, -3.20, 3.90], "CE2": [-2.30, -1.50, 4.30], "CZ": [-1.60, -2.60, 4.70], "OH": [-2.10, -3.00, 5.80]
        }]
    },
    "TRP": {
        "atoms": ["CB", "CG", "CD1", "CD2", "NE1", "CE2", "CE3", "CZ2", "CZ3", "CH2"],
        "elements": ["C", "C", "C", "C", "N", "C", "C", "C", "C", "C"],
        "rotamers": [{
            "CB": [-0.53, -1.06, 0.94], "CG": [-0.80, -1.60, 2.30], "CD1": [-0.20, -2.40, 3.30], "CD2": [-2.10, -1.40, 2.80],
            "NE1": [-1.10, -2.70, 4.30], "CE2": [-2.30, -2.10, 4.00], "CE3": [-3.20, -0.70, 2.40],
            "CZ2": [-3.50, -2.10, 4.80], "CZ3": [-4.40, -0.70, 3.20], "CH2": [-4.50, -1.40, 4.40]
        }]
    },
    "MET": {
        "atoms": ["CB", "CG", "SD", "CE"],
        "elements": ["C", "C", "S", "C"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG": [-0.60, -1.80, 2.20], "SD": [-1.20, -2.40, 3.50], "CE": [-0.40, -3.20, 4.50]}]
    },
    "CYS": {
        "atoms": ["CB", "SG"],
        "elements": ["C", "S"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "SG": [-0.20, -1.20, 2.40]}]
    },
    "ALA": {
        "atoms": ["CB"],
        "elements": ["C"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94]}]
    },
    "ILE": {
        "atoms": ["CB", "CG1", "CG2", "CD1"],
        "elements": ["C", "C", "C", "C"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG1": [0.20, -2.10, 1.30], "CG2": [-1.80, -1.50, 0.30], "CD1": [0.50, -3.00, 2.10]}]
    },
    "LEU": {
        "atoms": ["CB", "CG", "CD1", "CD2"],
        "elements": ["C", "C", "C", "C"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG": [-0.60, -1.80, 2.20], "CD1": [0.20, -2.80, 1.80], "CD2": [-1.70, -2.20, 3.00]}]
    },
    "THR": {
        "atoms": ["CB", "OG1", "CG2"],
        "elements": ["C", "O", "C"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "OG1": [0.20, -1.80, 1.40], "CG2": [-1.80, -1.50, 0.30]}]
    },
    "PRO": {
        "atoms": ["CB", "CG", "CD"],
        "elements": ["C", "C", "C"],
        "rotamers": [{"CB": [-0.53, -1.06, 0.94], "CG": [-0.60, -1.80, 2.20], "CD": [0.40, -1.50, 2.50]}]
    }
}

def get_backbone_frame(n_pos: np.ndarray, ca_pos: np.ndarray, c_pos: np.ndarray) -> np.ndarray:
    """Computes the 3x3 rotation matrix for the local N-CA-C frame."""
    v1 = n_pos - ca_pos
    v2 = c_pos - ca_pos
    
    n1 = np.linalg.norm(v1)
    n2 = np.linalg.norm(v2)
    if n1 > 1e-6 and n2 > 1e-6:
        v1 /= n1
        v2 /= n2
    else:
        return np.eye(3)
        
    z = np.cross(v1, v2)
    nz = np.linalg.norm(z)
    if nz > 1e-6:
        z /= nz
    else:
        z = np.array([0., 0., 1.])
        
    x = v1
    y = np.cross(z, x)
    
    return np.column_stack((x, y, z))

def build_sidechain(target_res: str, n_pos: np.ndarray, ca_pos: np.ndarray, c_pos: np.ndarray, rotamer_idx: int = 0) -> dict:
    """Builds sidechain atom positions in global space based on the local CA frame."""
    if target_res not in TEMPLATES:
        return {}
        
    template = TEMPLATES[target_res]
    if rotamer_idx >= len(template["rotamers"]):
        rotamer_idx = 0
        
    rot = template["rotamers"][rotamer_idx]
    
    R = get_backbone_frame(n_pos, ca_pos, c_pos)
    
    result = {}
    for atm in template["atoms"]:
        local_pos = np.array(rot[atm], dtype=np.float32)
        global_pos = ca_pos + R @ local_pos
        result[atm] = global_pos
        
    return result
