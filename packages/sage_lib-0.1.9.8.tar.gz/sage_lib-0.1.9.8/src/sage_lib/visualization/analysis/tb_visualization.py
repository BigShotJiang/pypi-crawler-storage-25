from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional, Any
from .tight_binding import OrbitalType, DB, TBResults, TBParameters

@dataclass
class GridSpec:
    origin: np.ndarray        # (3,)
    shape:  Tuple[int, int, int]
    spacing: float
    
    @property
    def rmin(self): return self.origin
    @property
    def rmax(self): return self.origin + np.array(self.shape) * self.spacing

@dataclass
class ScalarField3D:
    grid: GridSpec
    values: np.ndarray        # shape (nx, ny, nz)
    name: str = ""
    is_signed: bool = False

@dataclass
class IsosurfaceMesh:
    vertices: np.ndarray      # (V, 3)
    faces: np.ndarray         # (F, 3)
    normals: Optional[np.ndarray] = None
    iso_value: float = 0.0
    name: str = ""

# ─────────────────────────────────────────────────────────────────────────────
# 1. Utilities
# ─────────────────────────────────────────────────────────────────────────────

def make_grid_from_atoms(pos: np.ndarray, params: TBParameters) -> GridSpec:
    """Creates a GridSpec based on atomic extent plus padding."""
    pad = params.grid_padding
    spacing = params.grid_spacing
    
    rmin = np.min(pos, axis=0) - pad
    rmax = np.max(pos, axis=0) + pad
    
    shape = tuple(np.ceil((rmax - rmin) / spacing).astype(int) + 1)
    return GridSpec(origin=rmin, shape=shape, spacing=spacing)

def normalize_field(field: ScalarField3D, target: float = 1.0):
    """Scales field values so that max absolute amplitude is target."""
    mx = np.max(np.abs(field.values))
    if mx > 1e-12:
        field.values *= (target / mx)
    return field

# ─────────────────────────────────────────────────────────────────────────────
# 2. Real-Space Basis Evaluator
# ─────────────────────────────────────────────────────────────────────────────

def eval_basis_functions_vec(orb: OrbitalType, dx: np.ndarray, dy: np.ndarray, dz: np.ndarray, alpha: float) -> np.ndarray:
    """Vectorized version of basis evaluation over grid slices."""
    r2 = dx**2 + dy**2 + dz**2
    n_s = (2.0 * alpha / np.pi)**0.75
    g = n_s * np.exp(-alpha * r2)
    
    if orb == OrbitalType.S: return g
    
    n_p = n_s * np.sqrt(4.0 * alpha)
    if orb == OrbitalType.PX: return n_p * dx * g
    elif orb == OrbitalType.PY: return n_p * dy * g
    elif orb == OrbitalType.PZ: return n_p * dz * g
    
    n_d = n_s * (4.0 * alpha) / np.sqrt(3.0) 
    if orb == OrbitalType.DXY: return n_d * dx * dy * g
    elif orb == OrbitalType.DYZ: return n_d * dy * dz * g
    elif orb == OrbitalType.DZX: return n_d * dz * dx * g
    elif orb == OrbitalType.DX2Y2: return 0.5 * n_d * (dx*dx - dy*dy) * g
    elif orb == OrbitalType.DZ2:   return (1.0/np.sqrt(12.0)) * n_d * (2.0*dz*dz - dx*dx - dy*dy) * g
    
    return np.zeros_like(r2)

# ─────────────────────────────────────────────────────────────────────────────
# 3. Field Builders
# ─────────────────────────────────────────────────────────────────────────────

def build_state_field(pos: np.ndarray, elements: List[str], orb_info: List[Tuple[int, OrbitalType]], 
                      evecs: np.ndarray, state_idx: int, grid: GridSpec, params: TBParameters) -> ScalarField3D:
    """Computes signed orbital amplitude psi_n(r) on the grid (Vectorized)."""
    field_vals = np.zeros(grid.shape, dtype=np.float32)
    
    x = grid.origin[0] + np.arange(grid.shape[0]) * grid.spacing
    y = grid.origin[1] + np.arange(grid.shape[1]) * grid.spacing
    z = grid.origin[2] + np.arange(grid.shape[2]) * grid.spacing
    
    cutoff_val = getattr(params, "orbital_cutoff_log", 10.0)
    
    for mu, (ai, ot) in enumerate(orb_info):
        coeff = evecs[mu, state_idx]
        if abs(coeff) < 1e-5: continue
        
        ap = pos[ai]
        alpha = DB.get_alpha(elements[ai], ot)
        r_cut = np.sqrt(cutoff_val / alpha)
        
        ix0 = max(0, int((ap[0] - r_cut - grid.origin[0]) / grid.spacing))
        ix1 = min(grid.shape[0], int((ap[0] + r_cut - grid.origin[0]) / grid.spacing) + 1)
        iy0 = max(0, int((ap[1] - r_cut - grid.origin[1]) / grid.spacing))
        iy1 = min(grid.shape[1], int((ap[1] + r_cut - grid.origin[1]) / grid.spacing) + 1)
        iz0 = max(0, int((ap[2] - r_cut - grid.origin[2]) / grid.spacing))
        iz1 = min(grid.shape[2], int((ap[2] + r_cut - grid.origin[2]) / grid.spacing) + 1)
        
        if ix0 >= ix1 or iy0 >= iy1 or iz0 >= iz1: continue
        
        dx = (x[ix0:ix1] - ap[0])[:, None, None]
        dy = (y[iy0:iy1] - ap[1])[None, :, None]
        dz = (z[iz0:iz1] - ap[2])[None, None, :]
        
        field_vals[ix0:ix1, iy0:iy1, iz0:iz1] += coeff * eval_basis_functions_vec(ot, dx, dy, dz, alpha)
    
    return ScalarField3D(grid, field_vals, name=f"State {state_idx}", is_signed=True)

def build_state_density_field(pos: np.ndarray, elements: List[str], orb_info: List[Tuple[int, OrbitalType]], 
                             evecs: np.ndarray, state_idx: int, grid: GridSpec, params: TBParameters) -> ScalarField3D:
    """Computes $|\psi_n(r)|^2$ density field."""
    psi = build_state_field(pos, elements, orb_info, evecs, state_idx, grid, params)
    return ScalarField3D(grid, psi.values**2, name=f"Density {state_idx}", is_signed=False)

def build_total_density_field_exact(pos: np.ndarray, elements: List[str], orb_info: List[Tuple[int, OrbitalType]],
                                 evecs: np.ndarray, occupations: np.ndarray, grid: GridSpec, params: TBParameters) -> ScalarField3D:
    """Computes true total density rho(r) = sum_n f_n |psi_n(r)|^2 (Slow but accurate)."""
    density = np.zeros(grid.shape, dtype=np.float32)
    for n in range(len(occupations)):
        occ = occupations[n]
        if occ < 1e-4: continue
        psi = build_state_field(pos, elements, orb_info, evecs, n, grid, params)
        density += occ * (psi.values**2)
    return ScalarField3D(grid, density, name="Total Density (Exact)", is_signed=False)

def build_total_density_field_diagonal(pos: np.ndarray, elements: List[str], orb_info: List[Tuple[int, OrbitalType]], 
                                     evecs: np.ndarray, occs: np.ndarray, grid: GridSpec, params: TBParameters) -> ScalarField3D:
    """Computes approximate total density rho(r) = sum_mu n_mu |chi_mu(r)|^2 (Fast)."""
    field_vals = np.zeros(grid.shape, dtype=np.float32)
    orb_occ = np.sum((evecs**2) * occs, axis=1)
    
    x = grid.origin[0] + np.arange(grid.shape[0]) * grid.spacing
    y = grid.origin[1] + np.arange(grid.shape[1]) * grid.spacing
    z = grid.origin[2] + np.arange(grid.shape[2]) * grid.spacing
    
    cutoff_val = getattr(params, "orbital_cutoff_log", 10.0)
    
    for mu, (ai, ot) in enumerate(orb_info):
        q = orb_occ[mu]
        if q < 1e-6: continue
        
        ap = pos[ai]
        alpha = DB.get_alpha(elements[ai], ot)
        r_cut = np.sqrt(cutoff_val / alpha)
        
        ix0 = max(0, int((ap[0] - r_cut - grid.origin[0]) / grid.spacing))
        ix1 = min(grid.shape[0], int((ap[0] + r_cut - grid.origin[0]) / grid.spacing) + 1)
        iy0 = max(0, int((ap[1] - r_cut - grid.origin[1]) / grid.spacing))
        iy1 = min(grid.shape[1], int((ap[1] + r_cut - grid.origin[1]) / grid.spacing) + 1)
        iz0 = max(0, int((ap[2] - r_cut - grid.origin[2]) / grid.spacing))
        iz1 = min(grid.shape[2], int((ap[2] + r_cut - grid.origin[2]) / grid.spacing) + 1)
        
        if ix0 >= ix1 or iy0 >= iy1 or iz0 >= iz1: continue
        
        dx = (x[ix0:ix1] - ap[0])[:, None, None]
        dy = (y[iy0:iy1] - ap[1])[None, :, None]
        dz = (z[iz0:iz1] - ap[2])[None, None, :]
        
        chi = eval_basis_functions_vec(ot, dx, dy, dz, alpha)
        field_vals[ix0:ix1, iy0:iy1, iz0:iz1] += q * (chi**2)
    
    return ScalarField3D(grid, field_vals, name="Total Density (Cheap)", is_signed=False)

def build_species_projected_field(pos: np.ndarray, elements: List[str], orb_info: List[Tuple[int, OrbitalType]], 
                                 evecs: np.ndarray, state_idx: int, target_species: str, grid: GridSpec, params: TBParameters) -> ScalarField3D:
    """Computes signed orbital amplitude $\psi_n(r)$ using ONLY orbitals from a specific element."""
    field_vals = np.zeros(grid.shape, dtype=np.float32)
    
    x = grid.origin[0] + np.arange(grid.shape[0]) * grid.spacing
    y = grid.origin[1] + np.arange(grid.shape[1]) * grid.spacing
    z = grid.origin[2] + np.arange(grid.shape[2]) * grid.spacing
    
    cutoff_val = getattr(params, "orbital_cutoff_log", 10.0)
    
    for mu, (ai, ot) in enumerate(orb_info):
        if elements[ai] != target_species: continue
        coeff = evecs[mu, state_idx]
        if abs(coeff) < 1e-5: continue
        
        ap = pos[ai]
        alpha = DB.get_alpha(elements[ai], ot)
        r_cut = np.sqrt(cutoff_val / alpha)
        
        ix0 = max(0, int((ap[0] - r_cut - grid.origin[0]) / grid.spacing))
        ix1 = min(grid.shape[0], int((ap[0] + r_cut - grid.origin[0]) / grid.spacing) + 1)
        iy0 = max(0, int((ap[1] - r_cut - grid.origin[1]) / grid.spacing))
        iy1 = min(grid.shape[1], int((ap[1] + r_cut - grid.origin[1]) / grid.spacing) + 1)
        iz0 = max(0, int((ap[2] - r_cut - grid.origin[2]) / grid.spacing))
        iz1 = min(grid.shape[2], int((ap[2] + r_cut - grid.origin[2]) / grid.spacing) + 1)
        
        if ix0 >= ix1 or iy0 >= iy1 or iz0 >= iz1: continue
        
        dx = (x[ix0:ix1] - ap[0])[:, None, None]
        dy = (y[iy0:iy1] - ap[1])[None, :, None]
        dz = (z[iz0:iz1] - ap[2])[None, None, :]
        
        field_vals[ix0:ix1, iy0:iy1, iz0:iz1] += coeff * eval_basis_functions_vec(ot, dx, dy, dz, alpha)
    
    return ScalarField3D(grid, field_vals, name=f"{target_species} Project {state_idx}", is_signed=True)

def build_window_ldos(pos: np.ndarray, elements: List[str], orb_info: List[Tuple[int, OrbitalType]],
                      evals: np.ndarray, evecs: np.ndarray, e_min: float, e_max: float, grid: GridSpec, params: TBParameters) -> ScalarField3D:
    """Computes local density of states (LDOS) in an energy window [e_min, e_max]."""
    ldos = np.zeros(grid.shape, dtype=np.float32)
    for n, e in enumerate(evals):
        if e_min <= e <= e_max:
            psi = build_state_field(pos, elements, orb_info, evecs, n, grid, params)
            ldos += (psi.values**2)
    return ScalarField3D(grid, ldos, name=f"LDOS [{e_min:.2f}, {e_max:.2f}]", is_signed=False)

# ─────────────────────────────────────────────────────────────────────────────
# 4. Surface Extraction
# ─────────────────────────────────────────────────────────────────────────────

def extract_isosurface(field: ScalarField3D, iso_val: float) -> Optional[IsosurfaceMesh]:
    try:
        from skimage import measure
    except ImportError:
        return None
        
    vals = field.values
    v_min, v_max = vals.min(), vals.max()
    
    if iso_val < v_min or iso_val > v_max:
        return None
        
    try:
        verts, faces, normals, _ = measure.marching_cubes(
            vals, level=iso_val, spacing=(field.grid.spacing,)*3
        )
        verts += field.grid.origin
        return IsosurfaceMesh(vertices=verts.astype(np.float32), 
                              faces=faces.astype(np.int32), 
                              normals=normals.astype(np.float32),
                              iso_value=iso_val,
                              name=field.name)
    except Exception as e:
        print(f"Marching Cubes Error: {e}")
        return None

def extract_dual_isosurface(field: ScalarField3D, iso_val: float) -> Tuple[Optional[IsosurfaceMesh], Optional[IsosurfaceMesh]]:
    """
    Extracts two separate meshes for signed fields (positive and negative lobes).
    If field is not signed, returns (mesh, None).
    """
    if not field.is_signed:
        return extract_isosurface(field, iso_val), None
        
    pos_mesh = extract_isosurface(field, iso_val)
    if pos_mesh: pos_mesh.name = field.name + " (+)"
    
    neg_mesh = extract_isosurface(field, -iso_val)
    if neg_mesh: neg_mesh.name = field.name + " (-)"
    
    return pos_mesh, neg_mesh
