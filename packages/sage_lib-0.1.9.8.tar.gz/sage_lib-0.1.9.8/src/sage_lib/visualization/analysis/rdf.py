# ============================
# rdf.py — Advanced Radial Distribution Function
# ============================
from __future__ import annotations
import numpy as np
from typing import Tuple, Optional, List, Union

try:
    from scipy.spatial import cKDTree
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False

def compute_rdf(pos_ref: np.ndarray, 
                pos_target: np.ndarray, 
                lattice: Optional[np.ndarray] = None, 
                r_max: float = 10.0, 
                bins: int = 200, 
                pbc: bool = False,
                same_set: bool = False,
                exclude_mirrors: bool = True,
                normalize: str = "rdf",
                batch_size: int = 512) -> Tuple[np.ndarray, np.ndarray]:
    """
    High-performance RDF computation with O(N) cKDTree acceleration.
    """
    if pos_ref.size == 0 or pos_target.size == 0:
        return np.linspace(0, r_max, bins + 1)[:-1] + (r_max/bins/2), np.zeros(bins)

    pos_ref = np.asarray(pos_ref, dtype=np.float64)
    pos_target = np.asarray(pos_target, dtype=np.float64)
    
    edges = np.linspace(0.0, r_max, bins + 1)
    radii = (edges[:-1] + edges[1:]) / 2.0
    
    use_pbc = pbc and lattice is not None and np.linalg.norm(lattice) > 1e-3
    vol = 1.0
    is_ortho = False
    box_diag = None
    w_min = 1e10
    
    if use_pbc:
        vol = np.abs(np.linalg.det(lattice))
        off_diag = np.sum(np.abs(lattice - np.diag(np.diag(lattice))))
        if off_diag < 1e-6:
            is_ortho = True
            box_diag = np.diag(lattice)
            w_min = np.min(np.abs(box_diag))
        else:
            inv_lat = np.linalg.inv(lattice)
            w_min = np.min(1.0 / np.linalg.norm(inv_lat, axis=0))

    # Trigger long-range supercell search if r_max > MIC limit (0.5 * cell_width)
    if use_pbc and r_max > 0.5 * w_min:
        from .neighbor_engine import NeighborEngine
        # Normalize same_set behavior: NeighborEngine handles i!=j if self_search (pos_ref is pos_target)
        # Note: we pass pos_ref as pos_a and pos_target as pos_b
        i_idx, j_idx, _, dists = NeighborEngine.get_pair_displacements(
            pos_ref, lattice, r_max, pbc=True, pos_b=pos_target
        )
        # Filter self-interaction if same set
        if same_set:
            if exclude_mirrors:
                # Standard behavior: ignore particle with its own periodic images
                mask = (i_idx != j_idx)
            else:
                # Include lattice self-images, but filter self at r=0
                mask = (i_idx != j_idx) | (dists > 1e-5)
            dists = dists[mask]
            
        hist, _ = np.histogram(dists, bins=bins, range=(0, r_max))
        
    elif HAS_SCIPY and use_pbc and is_ortho:
        # 1. Accelerated O(N) Path (Orthorhombic cKDTree - MIC only)
        tree_target = cKDTree(pos_target, boxsize=box_diag)
        tree_ref = cKDTree(pos_ref, boxsize=box_diag)
        counts = tree_target.count_neighbors(tree_ref, edges)
        if same_set:
            counts -= len(pos_ref)
        hist = np.diff(counts).astype(np.float64)
        
    else:
        # 2. Optimized Batched Path (Triclinic or Non-periodic)
        hist = np.zeros(bins, dtype=np.float64)
        r_max_sq = r_max**2
        inv_dr = bins / r_max
        n_ref = len(pos_ref)
        
        if use_pbc and not is_ortho:
            inv_lat = np.linalg.inv(lattice)
            f_target = pos_target @ inv_lat
            f_ref_all = pos_ref @ inv_lat
        
        for i in range(0, n_ref, batch_size):
            i_end = min(i + batch_size, n_ref)
            
            if use_pbc and not is_ortho:
                df = f_target[None, :, :] - f_ref_all[i:i_end, None, :]
                df -= np.round(df)
                dr_batch = df @ lattice
                dist_sq = np.sum(dr_batch**2, axis=-1)
            elif use_pbc and is_ortho: 
                diff = pos_target[None, :, :] - pos_ref[i:i_end, None, :]
                diff -= box_diag * np.round(diff / box_diag)
                dist_sq = np.sum(diff**2, axis=-1)
            else:
                diff = pos_target[None, :, :] - pos_ref[i:i_end, None, :]
                dist_sq = np.sum(diff**2, axis=-1)
                
            mask = dist_sq < r_max_sq
            if same_set:
                row_idx = np.arange(i, i_end)[:, None]
                col_idx = np.arange(len(pos_target))[None, :]
                mask &= (row_idx != col_idx)
                
            dists = np.sqrt(dist_sq[mask])
            bin_idx = (dists * inv_dr).astype(np.intp)
            bin_idx = bin_idx[bin_idx < bins]
            hist += np.bincount(bin_idx, minlength=bins)

    if normalize == "hist":
        return radii, hist

    # 3. Normalization (g(r))
    shell_vol = (4.0/3.0) * np.pi * (edges[1:]**3 - edges[:-1]**3)
    n_target = len(pos_target)
    
    if same_set:
        # standard g_AA normalization: counts (N*(N-1)) pairs
        rho_target = (n_target - 1) / vol if use_pbc else 1.0
    else:
        # cross g_AB normalization: counts (Na * Nb) pairs
        rho_target = n_target / vol if use_pbc else 1.0
        
    g_r = hist / (len(pos_ref) * rho_target * shell_vol + 1e-18)
    return radii, np.nan_to_num(g_r)

def compute_z_profile(positions: np.ndarray, bins: int = 100, z_range: Optional[Tuple[float, float]] = None) -> Tuple[np.ndarray, np.ndarray]:
    """Calculates density profile along Z axis."""
    z_coords = positions[:, 2]
    if z_range is None:
        z_range = (z_coords.min() - 0.5, z_coords.max() + 0.5)
    
    hist, edges = np.histogram(z_coords, bins=bins, range=z_range)
    centers = (edges[:-1] + edges[1:]) / 2
    # Normalize density (count / dz)
    dz = edges[1] - edges[0]
    return centers, hist / (dz + 1e-12)

def compute_layer_rdf(positions: np.ndarray, elements: List[str], lattice: np.ndarray, 
                      z_center: float, thickness: float, r_max: float = 10.0) -> Tuple[np.ndarray, np.ndarray]:
    """
    Calculates RDF for a specific layer.
    Filters atoms within z_center +/- thickness/2.
    Useful for interface and layered material analysis.
    """
    z_min = z_center - thickness/2
    z_max = z_center + thickness/2
    
    mask = (positions[:, 2] >= z_min) & (positions[:, 2] <= z_max)
    layer_pos = positions[mask]
    
    if layer_pos.size == 0:
        return np.linspace(0, r_max, 50), np.zeros(50)
        
    # Layer-resolved RDFs are treated as non-periodic pair histograms 
    # unless a better 2D mode is later implemented.
    return compute_rdf(layer_pos, layer_pos, lattice, r_max=r_max, normalize="hist")

def _compute_rdf_simple(pos_ref: np.ndarray, pos_target: np.ndarray, r_max: float, bins: int):
    """Fallback O(N*M) calculation when Scipy is missing."""
    all_dists = []
    for p in pos_ref:
        d = np.linalg.norm(pos_target - p, axis=1)
        # Filter self
        d = d[d > 1e-3]
        all_dists.extend(d[d <= r_max])
    
    distances = np.array(all_dists)
    hist, edges = np.histogram(distances, bins=bins, range=(0, r_max))
    radii = (edges[:-1] + edges[1:]) / 2
    
    return radii, hist
