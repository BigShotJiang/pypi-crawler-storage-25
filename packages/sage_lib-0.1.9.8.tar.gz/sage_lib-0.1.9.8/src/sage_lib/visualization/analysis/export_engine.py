from __future__ import annotations
import json
import numpy as np
from typing import List, Dict, Any, Tuple, Optional

class ExportEngine:
    """
    Handles exporting analytical results and derived geometry 
    to standard scientific and exchange formats.
    """
    
    @staticmethod
    def export_as_obj(filename: str, 
                      vertices_list: List[np.ndarray], 
                      faces_list: List[np.ndarray]):
        """
        Exports a collection of meshes (e.g., multiple polyhedra) to a single OBJ file.
        Each mesh is named by its index.
        """
        v_offset = 1
        with open(filename, 'w') as f:
            f.write("# SAGE Exported Geometry\n")
            for i, (verts, faces) in enumerate(zip(vertices_list, faces_list)):
                if verts is None or faces is None: continue
                f.write(f"o Mesh_{i}\n")
                for v in verts:
                    f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
                for face in faces:
                    # OBJ is 1-indexed
                    f.write(f"f {face[0]+v_offset} {face[1]+v_offset} {face[2]+v_offset}\n")
                v_offset += len(verts)

    @staticmethod
    def export_as_ply(filename: str, 
                      vertices: np.ndarray, 
                      faces: np.ndarray):
        """Exports a single mesh to PLY format (Binary or ASCII)."""
        # Simplest ASCII version for now
        num_verts = len(vertices)
        num_faces = len(faces)
        
        with open(filename, 'w') as f:
            f.write("ply\n")
            f.write("format ascii 1.0\n")
            f.write(f"element vertex {num_verts}\n")
            f.write("property float x\n")
            f.write("property float y\n")
            f.write("property float z\n")
            f.write(f"element face {num_faces}\n")
            f.write("property list uchar int vertex_indices\n")
            f.write("end_header\n")
            
            for v in vertices:
                f.write(f"{v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
            for face in faces:
                f.write(f"3 {face[0]} {face[1]} {face[2]}\n")

    @staticmethod
    def export_metadata_json(filename: str, data: Dict[str, Any]):
        """Exports analysis stats, cluster info, etc., to a pretty JSON file."""
        def default_serializer(obj):
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            if isinstance(obj, np.integer):
                return int(obj)
            if isinstance(obj, np.floating):
                return float(obj)
            raise TypeError(f"Type {type(obj)} not serializable")

        with open(filename, 'w') as f:
            json.dump(data, f, indent=4, default=default_serializer)
            
    @staticmethod
    def export_cluster_report(filename: str, clusters: List[Dict[str, Any]]):
        """Specific helper for cluster statistics."""
        report_data = {
            "summary": {
                "num_clusters": len(clusters),
                "total_atoms": sum(c['size'] for c in clusters)
            },
            "clusters": clusters
        }
        ExportEngine.export_metadata_json(filename, report_data)
