# ============================
# providers.py — Data Source Protocols
# ============================
from __future__ import annotations
from typing import Protocol, Tuple, Optional, Sequence
import numpy as np

class StructureProvider(Protocol):
    """Protocol for classes that provide atomic structure data to the Viewer."""
    def __len__(self) -> int: ...
    def get(self, idx: int) -> Tuple[
        np.ndarray,          # positions
        np.ndarray,          # lattice
        float,               # energy
        Optional[Sequence[str]], # elements
        Optional[np.ndarray], # colors
        Optional[np.ndarray], # radii
        Optional[dict]        # metadata/info
    ]: ...
    def get_all_Ef(self) -> np.ndarray: ...
    def get_all_E(self) -> np.ndarray: ...
