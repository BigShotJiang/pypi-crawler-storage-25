from __future__ import annotations
from typing import Any
import imgui
import numpy as np
import time
from .plots import draw_rdf_plot, draw_z_profile, draw_dos_plot
from .display_scientific_geometry import draw_scientific_geometry_panel

def draw_analysis_hub(viewer: Any):
    """Unified analysis entry point (Graph, Volume, Clipping)."""
    if imgui.tree_node("Structure Clipping"):
        _, viewer.display.clipping_enabled = imgui.checkbox("Active", viewer.display.clipping_enabled)
        imgui.same_line()
        _, viewer.display.clipping_invert = imgui.checkbox("Invert", viewer.display.clipping_invert)
        
        _, viewer.clipping_fractional = imgui.checkbox("Fractional Mode", viewer.clipping_fractional)
        
        # Determine mapping range
        if viewer.clipping_fractional:
            c_min, c_max = 0.0, 1.0
        else:
            mn, mx = viewer.scene.get_full_bounds()
            axis = viewer.clipping_axis
            c_min, c_max = mn[axis], mx[axis]
        
        _, viewer.display.clipping_range = imgui.drag_float2("Range (A)", *viewer.display.clipping_range, 0.1, c_min, c_max)
        imgui.tree_pop()
        
    if imgui.tree_node("Density & Volumes"):
        _, viewer.vol_enabled = imgui.checkbox("Volume Overlay", viewer.vol_enabled)
        _, viewer.vol_iso_level = imgui.slider_float("Isovalue", viewer.vol_iso_level, 0.0, 1.0)
        imgui.tree_pop()
        
    if imgui.tree_node("Electronics (TB)"):
        _, viewer.tb_show_dos = imgui.checkbox("Show Density of States", viewer.tb_show_dos)
        if viewer.tb_show_dos and viewer.tb_results is not None:
            res = viewer.tb_results
            draw_dos_plot(res.dos_x, res.dos_y, res.fermi_level,
                          pdos_y=res.pdos_y, homo=res.homo, 
                          lumo=res.lumo, gap=res.gap)
        imgui.tree_pop()

    # --- 2. Scientific Geometry (Unified Hub) ---
    draw_scientific_geometry_panel(viewer)
