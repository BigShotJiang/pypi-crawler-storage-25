from __future__ import annotations
from typing import Any
import imgui

def draw_status_bar(viewer: Any):
    """Top-level overlay for critical frame metadata (e.g. current frame index and FPS)."""
    imgui.set_next_window_position(10, 10)
    imgui.begin("Status", False, imgui.WINDOW_NO_TITLE_BAR | imgui.WINDOW_ALWAYS_AUTO_RESIZE | imgui.WINDOW_NO_BACKGROUND)
    imgui.text_colored(f"SAGE Visualizer | Frame {viewer.index1} | {viewer.quality.current_fps:.1f} FPS", 0.7, 0.9, 1.0)
    imgui.end()
