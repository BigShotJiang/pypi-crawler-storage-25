from __future__ import annotations
import imgui
import numpy as np
import time
from typing import Any
from .plots import draw_rdf_plot, draw_z_profile

def draw_scientific_geometry_panel(viewer: Any):
    """Unified Scientific Geometry panel for SAGE."""
    # Ensure all required attributes exist (for live-updates on old sessions)
    if not hasattr(viewer, "show_polyhedra"): viewer.show_polyhedra = False
    if not hasattr(viewer, "poly_settings"): 
        from .analysis.polyhedron_analyzer import PolyhedronSettings
        viewer.poly_settings = PolyhedronSettings()
    if not hasattr(viewer, "poly_opacity"): viewer.poly_opacity = 0.5
    if not hasattr(viewer, "polyhedra"): viewer.polyhedra = []
    if not hasattr(viewer, "cn_cutoff"): viewer.cn_cutoff = 3.0
    if not hasattr(viewer, "bad_cutoff"): viewer.bad_cutoff = 3.0
    if not hasattr(viewer, "hb_d_ha_cut"): viewer.hb_d_ha_cut = 2.5
    if not hasattr(viewer, "hb_angle_cut"): viewer.hb_angle_cut = 120.0

    if imgui.collapsing_header("Scientific Geometry")[0]:
        
        # 1. Polyhedra Construction (Modern Redesign)
        if imgui.tree_node("Polyhedra Construction"):
            changed_e, viewer.show_polyhedra = imgui.checkbox("Enable Rendering", viewer.show_polyhedra)
            if changed_e:
                if viewer.show_polyhedra:
                    viewer.poly_settings.center_radii_scale = 0.2
                    viewer.poly_settings.corner_radii_scale = 0.2
                else:
                    viewer.poly_settings.center_radii_scale = 1.0
                    viewer.poly_settings.corner_radii_scale = 1.0
                viewer.poly_dirty = True
                if viewer.show_polyhedra and not viewer.polyhedra: viewer._calc_all_polyhedra()
                viewer._sync_polyhedra(viewer.scene)
                viewer._mark_dirty(pos=True); viewer._sync_gpu()

            imgui.columns(2, border=False)
            
            # --- COLUMN 1: DETECTION & FILTERS ---
            imgui.text_colored("Detection", 0.4, 0.7, 1.0)
            
            def trigger_recalc(): viewer._calc_all_polyhedra()
            def trigger_sync():
                viewer.poly_dirty = True
                viewer._sync_polyhedra(viewer.scene)
                viewer._mark_dirty(pos=True); viewer._sync_gpu()

            # Center Mode
            modes_c = ["all", "species", "selection"]
            labels_c = ["All Atoms", "By Species", "Selected"]
            try: cur_c = modes_c.index(viewer.poly_settings.center_mode)
            except: cur_c = 0
            imgui.push_item_width(-1)
            changed_c, new_c = imgui.combo("##c_mode", cur_c, labels_c)
            if changed_c:
                viewer.poly_settings.center_mode = modes_c[new_c]
                trigger_recalc()
            imgui.pop_item_width()
            if imgui.is_item_hovered(): imgui.set_tooltip("Center Mode: Which atoms are used as possible polyhedron centers.")

            # Neighbor Mode
            modes = ["bond_graph", "covalent", "manual", "voronoi"]
            mode_labels = ["Bond Graph", "Covalent", "Manual", "Voronoi"]
            try: current_idx = modes.index(viewer.poly_settings.neighbor_mode)
            except: current_idx = 0
            imgui.push_item_width(-1)
            changed_m, new_idx = imgui.combo("##n_mode", current_idx, mode_labels)
            if changed_m:
                viewer.poly_settings.neighbor_mode = modes[new_idx]
                trigger_recalc()
            imgui.pop_item_width()
            if imgui.is_item_hovered(): imgui.set_tooltip("Neighbor Mode: Method used to determine ligand atoms.")

            if viewer.poly_settings.neighbor_mode == "covalent":
                imgui.push_item_width(-1)
                changed_f, viewer.poly_settings.cutoff_factor = imgui.slider_float("##f", viewer.poly_settings.cutoff_factor, 0.5, 3.0, "Factor: %.2f")
                if changed_f: trigger_recalc()
                imgui.pop_item_width()
            elif viewer.poly_settings.neighbor_mode == "manual":
                imgui.push_item_width(-1)
                changed_c, viewer.poly_settings.manual_cutoff = imgui.slider_float("##m", viewer.poly_settings.manual_cutoff, 1.0, 6.0, "Cutoff: %.2f A")
                if changed_c: trigger_recalc()
                imgui.pop_item_width()

            imgui.spacing()
            available_elements = sorted(list(set(viewer.scene.elements)))
            
            # Species Chips (Ligands)
            imgui.text("Ligands")
            for el in available_elements:
                active = el in viewer.poly_settings.ligand_species
                if active: imgui.push_style_color(imgui.COLOR_BUTTON, 0.2, 0.5, 0.8, 1.0)
                if imgui.button(f"{el}##l"):
                    if active: viewer.poly_settings.ligand_species.remove(el)
                    else: viewer.poly_settings.ligand_species.append(el)
                    trigger_recalc(); viewer._mark_dirty(pos=True); viewer._sync_gpu()
                if active: imgui.pop_style_color()
                imgui.same_line()
            imgui.new_line()

            # Species Chips (Centers)
            if viewer.poly_settings.center_mode == "species":
                imgui.text("Centers")
                for el in available_elements:
                    active = el in viewer.poly_settings.center_species
                    if active: imgui.push_style_color(imgui.COLOR_BUTTON, 0.8, 0.4, 0.2, 1.0)
                    if imgui.button(f"{el}##c"):
                        if active: viewer.poly_settings.center_species.remove(el)
                        else: viewer.poly_settings.center_species.append(el)
                        trigger_recalc(); viewer._mark_dirty(pos=True); viewer._sync_gpu()
                    if active: imgui.pop_style_color()
                    imgui.same_line()
                imgui.new_line()

            imgui.spacing()
            imgui.text_colored("Coordination", 0.4, 0.7, 1.0)
            from collections import Counter
            cn_counts = Counter(p.cn for p in viewer.polyhedra)
            active_cns = sorted(cn_counts.keys())
            for i, cn in enumerate(active_cns):
                is_cn = viewer.poly_settings.enabled_cn.get(cn, True)
                changed_cn, checked = imgui.checkbox(f"CN {cn} ({cn_counts[cn]})", is_cn)
                if changed_cn:
                    viewer.poly_settings.enabled_cn[cn] = checked
                    trigger_sync()
                if (i+1)%2 != 0 and i < len(active_cns)-1: imgui.same_line()
            
            if imgui.button("Select All"):
                for cn in active_cns: viewer.poly_settings.enabled_cn[cn] = True
                trigger_sync()
            imgui.same_line()
            if imgui.button("Clear"):
                for cn in active_cns: viewer.poly_settings.enabled_cn[cn] = False
                trigger_sync()

            imgui.spacing()
            imgui.text_colored("Center Elements", 0.4, 0.7, 1.0)
            el_counts = Counter(p.center_element for p in viewer.polyhedra)
            active_els = sorted(el_counts.keys())
            if not hasattr(viewer.poly_settings, "enabled_species"):
                viewer.poly_settings.enabled_species = {el: True for el in available_elements}
            
            for i, el in enumerate(active_els):
                is_el = viewer.poly_settings.enabled_species.get(el, True)
                count = el_counts[el]
                if is_el: imgui.push_style_color(imgui.COLOR_BUTTON, 0.3, 0.6, 0.3, 1.0)
                if imgui.button(f"{el} ({count})##f_el"):
                    viewer.poly_settings.enabled_species[el] = not is_el
                    trigger_sync()
                if is_el: imgui.pop_style_color()
                imgui.same_line()
            imgui.new_line()
            
            imgui.next_column()

            # --- COLUMN 2: APPEARANCE & ACTIONS ---
            imgui.text_colored("Appearance", 0.4, 1.0, 0.7)
            
            def draw_labeled_slider(label, val, min_v, max_v):
                imgui.text(label)
                imgui.same_line(100)
                imgui.push_item_width(-40)
                changed, new_val = imgui.slider_float(f"##{label}", val, min_v, max_v, "")
                imgui.pop_item_width()
                imgui.same_line()
                imgui.text(f"{new_val:.2f}")
                return changed, new_val

            co, viewer.poly_opacity = draw_labeled_slider("Opacity", viewer.poly_opacity, 0.0, 1.0)
            if co: viewer.poly_dirty = True
            
            cs, viewer.poly_settings.scale = draw_labeled_slider("Poly Scale", viewer.poly_settings.scale, 0.5, 1.5)
            if cs: viewer.poly_dirty = True
            
            cr, viewer.poly_settings.center_radii_scale = draw_labeled_slider("Center Rad", viewer.poly_settings.center_radii_scale, 0.0, 2.0)
            if cr: viewer._mark_dirty(pos=True); viewer._sync_gpu()
            
            lr, viewer.poly_settings.corner_radii_scale = draw_labeled_slider("Corner Rad", viewer.poly_settings.corner_radii_scale, 0.0, 2.0)
            if lr: viewer._mark_dirty(pos=True); viewer._sync_gpu()

            cw, viewer.poly_settings.show_wireframe = imgui.checkbox("Wireframe Overlay", viewer.poly_settings.show_wireframe)
            if cw: viewer.poly_dirty = True

            imgui.spacing()
            imgui.text_colored("Actions", 1.0, 0.8, 0.4)
            if imgui.button(" Recalculate Polyhedra ", width=-1): trigger_recalc()
            if imgui.button(" Recompile Shaders ", width=-1):
                if hasattr(viewer, 'rnd_poly'): viewer.rnd_poly.recompile()
                viewer.poly_dirty = True

            # --- STATISTICS DASHBOARD ---
            imgui.spacing()
            imgui.separator()
            imgui.text_colored("Statistics", 0.4, 0.7, 1.0)
            
            if not hasattr(viewer, "poly_stats_tab"): viewer.poly_stats_tab = 0
            
            # Tab Selector
            imgui.push_style_var(imgui.STYLE_FRAME_PADDING, (2, 2))
            if imgui.button("Coordination", width=75): viewer.poly_stats_tab = 0
            imgui.same_line()
            if imgui.button("Centers", width=75): viewer.poly_stats_tab = 1
            imgui.pop_style_var()

            imgui.begin_child("poly_stats", height=120, border=True)
            if viewer.polyhedra:
                if viewer.poly_stats_tab == 0:
                    # CN Histogram
                    cn_counts = Counter(p.cn for p in viewer.polyhedra if viewer.poly_settings.enabled_cn.get(p.cn, True) and viewer.poly_settings.enabled_species.get(p.center_element, True))
                    if cn_counts:
                        max_c = max(cn_counts.values())
                        for cn in sorted(cn_counts.keys()):
                            count = cn_counts[cn]
                            imgui.text(f"CN {cn:1d}")
                            imgui.same_line(45)
                            # Progress bar as a simple bar chart
                            imgui.push_style_color(imgui.COLOR_PLOT_HISTOGRAM, 0.2, 0.5, 0.8, 1.0)
                            imgui.progress_bar(count/max_c, size=(-1, 12), overlay=str(count))
                            imgui.pop_style_color()
                            if imgui.is_item_hovered():
                                imgui.set_tooltip(f"CN {cn}: {count} polyhedra\n(Click to toggle filter)")
                                if imgui.is_mouse_clicked(0):
                                    viewer.poly_settings.enabled_cn[cn] = not viewer.poly_settings.enabled_cn.get(cn, True)
                                    trigger_sync()
                else:
                    # Centers Histogram
                    el_counts = Counter(p.center_element for p in viewer.polyhedra if viewer.poly_settings.enabled_cn.get(p.cn, True) and viewer.poly_settings.enabled_species.get(p.center_element, True))
                    if el_counts:
                        max_e = max(el_counts.values())
                        for el in sorted(el_counts.keys()):
                            count = el_counts[el]
                            imgui.text(f"{el:2s}")
                            imgui.same_line(45)
                            imgui.push_style_color(imgui.COLOR_PLOT_HISTOGRAM, 0.8, 0.4, 0.2, 1.0)
                            imgui.progress_bar(count/max_e, size=(-1, 12), overlay=str(count))
                            imgui.pop_style_color()
                            if imgui.is_item_hovered():
                                imgui.set_tooltip(f"Element {el}: {count} centers\n(Click to toggle filter)")
                                if imgui.is_mouse_clicked(0):
                                    viewer.poly_settings.enabled_species[el] = not viewer.poly_settings.enabled_species.get(el, True)
                                    trigger_sync()
            else:
                imgui.text_disabled("No data to plot.")
            imgui.end_child()

            # Summary Text
            if viewer.polyhedra:
                visible_polys = [p for p in viewer.polyhedra if viewer.poly_settings.enabled_cn.get(p.cn, True) and viewer.poly_settings.enabled_species.get(p.center_element, True)]
                if visible_polys:
                    total = len(visible_polys)
                    avg_cn = sum(p.cn for p in visible_polys) / total
                    imgui.text_disabled(f"Total: {total} | Avg CN: {avg_cn:.1f}")

            imgui.columns(1)
            imgui.separator()
            
            # --- STATUS BAR (Consolidated) ---
            if viewer.polyhedra:
                imgui.text_colored(f"Status: {len(viewer.polyhedra)} detected.", 0.4, 1.0, 0.4)
                c_spec = ", ".join(viewer.poly_settings.center_species) if viewer.poly_settings.center_mode == "species" else "All"
                l_spec = ", ".join(viewer.poly_settings.ligand_species)
                imgui.same_line()
                imgui.text_disabled(f"C: {c_spec} | L: {l_spec}")
            else:
                imgui.text_disabled("Ready for detection.")
            
            if "batch_polyhedra" in viewer.analysis.active_jobs:
                imgui.same_line()
                imgui.text_colored("  Processing...", 1.0, 0.8, 0.2)
                imgui.same_line()
                imgui.text(["|", "/", "-", "\\"][int(time.time()*4)%4])
            
            imgui.tree_pop()

        # 2. Radial Distribution (RDF)
        if imgui.tree_node("Radial Distribution (RDF)"):
            imgui.text("Analysis Parameters (Live):")
            m_list = ["Bulk g(r)", "Partial (A-B)", "2D (In-plane)"]
            changed_m, viewer.rdf_mode_idx = imgui.combo("##rdf_m", viewer.rdf_mode_idx, m_list)
            viewer.rdf_mode = ["bulk", "cluster", "2d"][viewer.rdf_mode_idx]
            
            changed_r, viewer.rdf_rmax = imgui.slider_float("r_max", viewer.rdf_rmax, 1.0, 20.0)
            changed_b, viewer.rdf_bins = imgui.slider_int("bins", viewer.rdf_bins, 10, 1000)
            
            _, viewer.rdf_normalize = imgui.checkbox("Normalize Peak (Max=1.0)", viewer.rdf_normalize)
            
            if changed_m or changed_r or changed_b:
                viewer._calc_rdf()

            imgui.text("Visualization:")
            if imgui.button("  Calculate  "): viewer._calc_rdf()
            
            if viewer.show_rdf:
                draw_rdf_plot(viewer.rdf_results, viewer.rdf_visibility, viewer.rdf_normalize)
            imgui.tree_pop()

        # 3. Voronoi
        if imgui.tree_node("Voronoi Analysis"):
            if imgui.button("Compute Voronoi"): viewer._calc_voronoi()
            if hasattr(viewer, "voro_results"):
                vols = viewer.voro_results.volumes
                imgui.text(f"Mean Volume: {np.mean(vols):.2f} A^3")
                imgui.text(f"Std Dev: {np.std(vols):.2f} A^3")
            imgui.tree_pop()

        # 4. Coordination & Angles
        if imgui.tree_node("Coordination & Bond Angles"):
            imgui.text("Coordination Number:")
            _, viewer.cn_cutoff = imgui.slider_float("Cutoff (A)##cn", viewer.cn_cutoff, 1.0, 10.0)
            if imgui.button("  Calculate CN  "): viewer._calc_cn_distribution()
            
            if viewer.cn_results is not None:
                imgui.text(f"Mean CN: {np.mean(viewer.cn_results):.2f}")
                if imgui.button(" Export CN (CSV) "):
                    ts = int(time.time())
                    hist, bins = np.histogram(viewer.cn_results, bins=np.arange(np.max(viewer.cn_results)+2))
                    np.savetxt(f"cn_dist_{ts}.csv", np.column_stack((bins[:-1], hist)), header="CN, count", delimiter=",")
                    viewer.export_status = f"CN exported to cn_dist_{ts}.csv"
            
            imgui.separator()
            imgui.text("Bond Angle Distribution (BAD):")
            _, viewer.bad_cutoff = imgui.slider_float("Cutoff (A)##bad", viewer.bad_cutoff, 1.0, 5.0)
            if imgui.button("  Calculate BAD  "): viewer._calc_bad()
            
            if hasattr(viewer, "bad_results") and viewer.bad_results[0].size > 0:
                from .plots import draw_bad_plot
                draw_bad_plot(*viewer.bad_results)
            
            imgui.tree_pop()

        # 5. Hydrogen Bonds
        if imgui.tree_node("Hydrogen Bonds (H-Bonds)"):
            _, viewer.hb_d_ha_cut = imgui.slider_float("H...A Cutoff (A)", viewer.hb_d_ha_cut, 1.5, 3.5)
            _, viewer.hb_angle_cut = imgui.slider_float("D-H...A Angle Min", viewer.hb_angle_cut, 90.0, 180.0)
            if imgui.button("  Calculate H-Bonds  "): viewer._calc_hbonds()
            if viewer.hb_results is not None:
                imgui.text_colored(f"Found {len(viewer.hb_results[0])} H-bonds.", 0.4, 1.0, 0.4)
            imgui.tree_pop()

        # 6. Density Profiles
        if imgui.tree_node("Z-Density Profiles"):
            _, viewer.show_z_profile = imgui.checkbox("Enable Plot", viewer.show_z_profile)
            if imgui.button("Compute Z-Profile"): viewer._calc_z_profile()
            if viewer.show_z_profile:
                draw_z_profile(viewer.z_profile_x, viewer.z_profile_y)
            imgui.tree_pop()

        # 6. Measurements & Tools
        if imgui.tree_node("Measurements & Tools"):
            if len(viewer.scene.selected_atoms) == 2:
                i1, i2 = viewer.scene.selected_atoms
                d = np.linalg.norm(viewer.scene.pos[i1] - viewer.scene.pos[i2])
                imgui.text_colored(f"Distance ({i1}-{i2}): {d:.4f} A", 1.0, 0.8, 0.4)
                if imgui.button(" Export Distance (CSV) "):
                    ts = int(time.time())
                    with open(f"measurement_{ts}.csv", "w") as f:
                        f.write(f"Atom1,Atom2,Distance(A)\n{i1},{i2},{d:.6f}")
                    viewer.export_status = "Distance exported."
            elif len(viewer.scene.selected_atoms) == 1:
                imgui.text_disabled("Select 2 atoms to measure distance.")
            imgui.tree_pop()

        # 7. Structural Dynamics (RMSD)
        if imgui.tree_node("Structural Dynamics"):
            imgui.text("Reference Frame:")
            _, viewer.displacement_ref_index = imgui.slider_int("##ref_idx", viewer.displacement_ref_index, 0, len(viewer.provider)-1)
            
            if imgui.button("Compute Displacement"):
                p0_any, _, _, _, _, _ = viewer.provider.get(viewer.displacement_ref_index)
                p0 = np.asarray(p0_any, dtype=np.float32).reshape(-1, 3)
                p1 = viewer.scene.pos
                
                if p0.shape != p1.shape:
                    viewer._rmsd_err = f"Error: Atom count mismatch ({p0.shape[0]} vs {p1.shape[0]})"
                    if hasattr(viewer, "_rmsd"): del viewer._rmsd
                else:
                    dist_sq = np.sum((p1 - p0)**2, axis=1)
                    viewer._rmsd = np.sqrt(np.mean(dist_sq))
                    if hasattr(viewer, "_rmsd_err"): del viewer._rmsd_err
                    print(f"RMSD vs Frame {viewer.displacement_ref_index}: {viewer._rmsd:.4f} A")
            
            if hasattr(viewer, "_rmsd"):
                imgui.text_colored(f"RMSD vs Ref: {viewer._rmsd:.4f} A", 0.3, 1.0, 0.3)
            if hasattr(viewer, "_rmsd_err"):
                imgui.text_colored(viewer._rmsd_err, 1.0, 0.3, 0.3)
            imgui.tree_pop()
