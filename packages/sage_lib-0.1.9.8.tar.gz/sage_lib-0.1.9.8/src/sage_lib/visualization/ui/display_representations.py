from __future__ import annotations
import imgui
from typing import Any, Dict, List
from ..display.controller import DisplayController
from ..display.representation_registry import REPRESENTATION_REGISTRY
from ..display.representations import RepresentationStyle

def draw_representation_panel(viewer: Any, controller: DisplayController):
    """
    Renders the modular UI for editing visual representations (Biomolecules, Materials, etc.)
    Agnostic to domain, works with any system using RepresentationInstance.
    """
    if controller.representation_set is None:
        imgui.text("No active representations for this scene.")
        return

    # 1. Global Scale Overrides
    changed_as, controller.display_state.atom_scale = imgui.slider_float("Global Atom Scale", controller.display_state.atom_scale, 0.05, 4.0)
    changed_bs, controller.display_state.bond_scale = imgui.slider_float("Global Bond Scale", controller.display_state.bond_scale, 0.05, 1.0)
    changed_bb, controller.display_state.show_bonds = imgui.checkbox("Enable Bonds Rendering", controller.display_state.show_bonds)
    
    dirty = any([changed_as, changed_bs, changed_bb])
    imgui.separator()
    imgui.text("Visual Components")
    
    # 2. Iterate through all active components (Backbone, Framework, Ligands, etc.)
    for rep in controller.representation_set.sorted_items():
        imgui.push_id(rep.id)
        
        # Checkbox + Visibility Toggle
        changed_v, rep.visible = imgui.checkbox(f"##v_{rep.id}", rep.visible)
        imgui.same_line()
        
        # Header / Collapsing Block for settings
        if imgui.collapsing_header(f"{rep.label} ({rep.style.kind})", imgui.TREE_NODE_DEFAULT_OPEN):
            imgui.indent()
            
            # Representation Style Combo
            current_kind = rep.style.kind
            kinds = list(REPRESENTATION_REGISTRY.keys())
            try:
                kind_idx = kinds.index(current_kind)
            except ValueError:
                kind_idx = 0
                
            changed_k, kind_idx = imgui.combo("Style", kind_idx, [REPRESENTATION_REGISTRY[k]["label"] for k in kinds])
            if changed_k:
                new_kind = kinds[kind_idx]
                rep.style.kind = new_kind
                # Reset params to defaults for new kind
                registry_params = REPRESENTATION_REGISTRY[new_kind]["params"]
                rep.style.params = {k: v["default"] for k, v in registry_params.items()}
                dirty = True
            
            # General attributes (Opacity / Color)
            changed_o, rep.opacity = imgui.slider_float("Opacity", rep.opacity, 0.0, 1.0)
            if any([changed_v, changed_o]): dirty = True
            
            # Registry-driven Parameters (Width, Thickness, Bond Radius, etc.)
            registry_params = REPRESENTATION_REGISTRY[rep.style.kind]["params"]
            for param_name, param_meta in registry_params.items():
                val = rep.style.params.get(param_name, param_meta["default"])
                
                if param_meta["type"] == "float":
                    changed_p, val = imgui.slider_float(param_name.replace("_", " ").title(), val, 
                                                       param_meta["min"], param_meta["max"])
                elif param_meta["type"] == "int":
                    changed_p, val = imgui.slider_int(param_name.replace("_", " ").title(), val, 
                                                     param_meta["min"], param_meta["max"])
                else:
                    changed_p = False
                    
                if changed_p:
                    rep.style.params[param_name] = val
                    dirty = True
                    # Ribbon-specific dirty flag needs special handling for now
                    if rep.style.kind == "ribbon":
                        controller.display_state.protein_ribbon_dirty = True

            imgui.unindent()
        
        imgui.pop_id()
        
    if dirty:
        viewer._mark_dirty(pos=True)
