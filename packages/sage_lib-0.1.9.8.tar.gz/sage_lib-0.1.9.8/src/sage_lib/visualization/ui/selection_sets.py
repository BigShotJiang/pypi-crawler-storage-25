from __future__ import annotations
import numpy as np
from typing import Dict, List, Set, Optional

class SelectionSetManager:
    """
    Manages persistent, named sets of atomic indices.
    Supports boolean operations to combine or refine selections.
    """
    def __init__(self):
        # Maps set_name -> set of indices
        self.sets: Dict[str, Set[int]] = {}

    def save_set(self, name: str, indices: List[int] | Set[int]):
        """Persists the given indices as a named set."""
        self.sets[name] = set(indices)

    def load_set(self, name: str) -> Optional[Set[int]]:
        """Retrieves a named selection set."""
        return self.sets.get(name)

    def delete_set(self, name: str):
        """Removes a named selection set."""
        self.sets.pop(name, None)

    def list_sets(self) -> List[str]:
        """Returns all named selection sets."""
        return list(self.sets.keys())

    # --- Boolean Operations ---

    def union(self, set_a: str, set_b: str, new_name: Optional[str] = None) -> Set[int]:
        res = self.sets.get(set_a, set()).union(self.sets.get(set_b, set()))
        if new_name: self.sets[new_name] = res
        return res

    def intersect(self, set_a: str, set_b: str, new_name: Optional[str] = None) -> Set[int]:
        res = self.sets.get(set_a, set()).intersection(self.sets.get(set_b, set()))
        if new_name: self.sets[new_name] = res
        return res

    def subtract(self, set_a: str, set_b: str, new_name: Optional[str] = None) -> Set[int]:
        """Elements in A that are NOT in B."""
        res = self.sets.get(set_a, set()).difference(self.sets.get(set_b, set()))
        if new_name: self.sets[new_name] = res
        return res

    def clear(self):
        self.sets.clear()
