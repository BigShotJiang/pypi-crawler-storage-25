from __future__ import annotations
import imgui
import os
from typing import Any
from ..display.controller import DisplayController
from ..display.serialization import build_scene_preset, save_scene_preset_json, load_scene_preset_json, apply_scene_preset

def draw_preset_browser(viewer: Any, controller: DisplayController):
    """
    UI for managing, saving, and loading complete visual presets.
    """
    dirty = False
    presets_dir = ".sage_presets"
    if not os.path.exists(presets_dir):
        os.makedirs(presets_dir)
        
    imgui.text_colored("Scene Presets", 0.7, 1.0, 0.4)
    
    # 1. Save Current
    if not hasattr(viewer, "_new_preset_name"): viewer._new_preset_name = "new_preset"
    _, viewer._new_preset_name = imgui.input_text("Save Name", viewer._new_preset_name, 32)
    imgui.same_line()
    if imgui.button("Save"):
        p = build_scene_preset(viewer, controller, name=viewer._new_preset_name)
        save_scene_preset_json(os.path.join(presets_dir, f"{viewer._new_preset_name}.json"), p)
        # Refresh the list if needed or just let it auto-refresh
        
    imgui.separator()
    
    # 2. Browse & Load
    presets = []
    try:
        presets = [f for f in os.listdir(presets_dir) if f.endswith(".json")]
    except:
        pass
        
    if not presets:
        imgui.text_disabled(" (No presets found in .sage_presets) ")
    else:
        for f in presets:
            base_name = f.replace(".json", "")
            imgui.push_id(f"preset_{f}")
            
            if imgui.button("Load"):
                try:
                    p = load_scene_preset_json(os.path.join(presets_dir, f))
                    apply_scene_preset(viewer, controller, p)
                    dirty = True
                except:
                     pass # Log error
            
            imgui.same_line()
            imgui.text_colored(base_name, 0.8, 0.8, 0.8)
            
            if imgui.is_item_hovered():
                 imgui.set_tooltip(f"Filename: {f}")
            
            imgui.pop_id()

    if dirty:
        viewer._mark_dirty(pos=True)
