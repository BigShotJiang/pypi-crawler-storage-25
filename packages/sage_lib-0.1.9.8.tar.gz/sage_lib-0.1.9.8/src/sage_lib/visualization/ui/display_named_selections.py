from __future__ import annotations
import imgui
from typing import Any
from ..display.controller import DisplayController
from ..display.selectors import DisplaySelector
from ..display.named_selections import NamedSelection

def draw_named_selection_manager(viewer: Any, controller: DisplayController):
    """
    UI Panel for managing persistent atomic selections.
    """
    ns_set = controller.named_selection_set
    dirty = False

    imgui.text_colored("Active Selections", 0.4, 0.7, 1.0)
    
    if not ns_set.items:
        imgui.text_disabled(" (No named selections defined) ")
    
    to_delete = []
    for ns in ns_set.items:
        imgui.push_id(f"ns_row_{ns.id}")
        
        # Action: Remove
        if imgui.button("X"):
            to_delete.append(ns.id)
            dirty = True
        
        imgui.same_line()
        # Rename
        changed, ns.name = imgui.input_text("##name", ns.name, 32)
        if changed: dirty = True
        
        imgui.same_line()
        imgui.text_disabled(f"({ns.selector.kind})")
        
        if imgui.is_item_hovered():
             imgui.set_tooltip(f"Selector: {ns.selector.value}")
             
        imgui.pop_id()

    for ns_id in to_delete:
        ns_set.remove(ns_id)

    imgui.separator()
    
    if imgui.button("+ Define from Selected Atoms"):
        if hasattr(viewer.scene, 'selected_atoms') and viewer.scene.selected_atoms:
            new_id = f"sel_{len(ns_set.items)}"
            new_name = f"Selection {len(ns_set.items) + 1}"
            # Create a selector that captures the CURRENT indices
            indices = list(viewer.scene.selected_atoms)
            ns_set.add(NamedSelection(new_id, new_name, DisplaySelector("atom_indices", indices)))
            dirty = True
        else:
            # Fallback to current semantic group if none selected? Or just message
            imgui.open_popup("no_selection_warning")

    if imgui.begin_popup("no_selection_warning"):
        imgui.text("No atoms are currently selected.")
        imgui.text("Please select atoms in the viewport first.")
        if imgui.button("OK"): imgui.close_current_popup()
        imgui.end_popup()

    if dirty:
        viewer._mark_dirty(pos=True)
