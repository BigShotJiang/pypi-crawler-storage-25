from __future__ import annotations
import imgui
import numpy as np
import time
from typing import Dict, Tuple, List, Any

try:
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

def draw_rdf_plot(rdf_results: Dict[str, Tuple[np.ndarray, np.ndarray]], 
                  rdf_visibility: Dict[str, bool] = None,
                  normalize: bool = False):
    """Renders a unified scientific RDF plot with overlays, axis labels, and tick numbers. Supporting peak normalization."""
    imgui.set_next_window_bg_alpha(0.7)
    if not imgui.begin("Radial Distribution Explorer (g(r))"):
        imgui.end()
        return

    if not rdf_results:
        imgui.text("No data to plot. Use 'Compute RDF' in the analysis panel.")
        imgui.end()
        return

    if rdf_visibility is None: rdf_visibility = {k: True for k in rdf_results}

    imgui.text("Visible Species Pairs:")
    imgui.columns(3, border=False)
    for lbl in sorted(rdf_results.keys()):
        _, rdf_visibility[lbl] = imgui.checkbox(f"{lbl}", rdf_visibility.get(lbl, True))
        imgui.next_column()
    imgui.columns(1)
    
    imgui.spacing()
    if imgui.button(" Export Data (CSV) "):
        ts = int(time.time())
        active_lbls = [l for l in rdf_results if rdf_visibility.get(l, True)]
        for lbl in active_lbls:
            r, g = rdf_results[lbl]
            np.savetxt(f"rdf_{lbl}_{ts}.csv", np.column_stack((r, g)), header="r(A), g(r)", delimiter=",")
        print("RDF Data (Raw) exported to CSV.")
    
    imgui.same_line()
    if imgui.button(" Export Plot (PNG) "):
        if HAS_MATPLOTLIB:
            plt.figure(figsize=(10, 6))
            for lbl, (r, g) in rdf_results.items():
                if rdf_visibility.get(lbl, True):
                    g_plot = g / np.max(g) if normalize else g
                    plt.plot(r, g_plot, label=lbl + (" (Norm)" if normalize else ""), linewidth=2)
            plt.title("Radial Distribution Function" + (" (Normalized)" if normalize else ""))
            plt.xlabel("Distance r (Å)"); plt.ylabel("g(r) / max(g)" if normalize else "g(r)")
            plt.grid(True, alpha=0.3); plt.legend()
            plt.savefig(f"rdf_plot_{int(time.time())}.png", dpi=200)
            plt.close()
            print("Scientific plot saved.")

    imgui.separator(); imgui.spacing()

    p_orig = imgui.get_cursor_screen_pos()
    avail_w = imgui.get_content_region_available_width()
    plot_h = 320
    imgui.dummy(avail_w, plot_h)
    
    draw_list = imgui.get_window_draw_list()
    
    margin_l, margin_r, margin_t, margin_b = 70, 80, 20, 60
    p0 = (p_orig[0] + margin_l, p_orig[1] + margin_t)
    p1 = (p_orig[0] + avail_w - margin_r, p_orig[1] + plot_h - margin_b)
    cw, ch = (p1[0] - p0[0]), (p1[1] - p0[1])

    draw_list.add_rect_filled(p0[0], p0[1], p1[0], p1[1], 0x44000000)
    draw_list.add_rect(p0[0], p0[1], p1[0], p1[1], 0xFFAAAAAA)
    
    max_g_all = 1e-9; max_r = 1e-9
    processed_results = {}
    for lbl, (r, g) in rdf_results.items():
        if not rdf_visibility.get(lbl, True) or r.size == 0: continue
        g_eff = g / np.max(g) if normalize else g
        processed_results[lbl] = (r, g_eff)
        max_g_all = max(max_g_all, np.max(g_eff))
        max_r = max(max_r, np.max(r))
    
    draw_list.add_text(p0[0]-65, p0[1]+ch/2-10, 0xFF88CCFF, "Norm.g(r)" if normalize else "g(r)")
    draw_list.add_text(p0[0]-45, p0[1], 0xFFFFFFFF, f"{max_g_all:.1f}")
    draw_list.add_text(p0[0]-35, p1[1]-15, 0xFFFFFFFF, "0.0")

    num_ticks = 6
    for t_idx in range(num_ticks):
        frac = t_idx / (num_ticks - 1)
        tx = p0[0] + frac * cw
        val = frac * max_r
        draw_list.add_line(tx, p1[1], tx, p1[1]+5, 0xFFAAAAAA)
        draw_list.add_text(tx-15, p1[1]+10, 0xFFFFFFFF, f"{val:.1f}")
    draw_list.add_text(p0[0] + cw/2 - 50, p1[1]+35, 0xFF88CCFF, "Distance r (Angstrom)")

    palette = [0xFF8888FF, 0xFF88FF88, 0xFFFFFF88, 0xFFFF88FF, 0xFF88FFFF, 0xFFCCCCCC]
    for i, (label, (r, g_eff)) in enumerate(processed_results.items()):
        color = palette[i % len(palette)]
        points = []
        for x_val, y_val in zip(r, g_eff):
            px = p0[0] + (x_val / max_r) * cw
            py = p1[1] - (y_val / max_g_all) * ch
            points.append((px, py))
        
        for p_idx in range(len(points) - 1):
             draw_list.add_line(points[p_idx][0], points[p_idx][1], points[p_idx+1][0], points[p_idx+1][1], color, 2.0)
             
        draw_list.add_text(p1[0] + 5, p0[1] + i*20, color, f"- {label}")

    imgui.end()

def draw_bad_plot(x: np.ndarray, y: np.ndarray):
    """Renders Bond Angle Distribution plot."""
    if not imgui.begin("Bond Angle Distribution"):
        imgui.end()
        return

    if x.size > 0:
        imgui.plot_histogram(
            "P(theta)",
            y.astype(np.float32),
            graph_size=(0, 150),
            scale_min=0.0
        )
        imgui.text("Angle (Degrees) 0 -> 180")
        
    imgui.end()

def draw_z_profile(x: np.ndarray, y: np.ndarray):
    """Renders Z-Density profile plot."""
    imgui.set_next_window_bg_alpha(0.7)
    if not imgui.begin("Z-Density Profile"):
        imgui.end()
        return

    if x.size > 0:
        imgui.plot_lines(
            "Density(z)",
            y.astype(np.float32),
            graph_size=(0, 150),
            scale_min=0.0
        )
        imgui.text(f"Z range: {x[0]:.2f} -> {x[-1]:.2f} A, bins: {len(x)}")
        
    imgui.end()
def draw_energy_plots(viewer: Any) -> int:
    """
    Renders high-quality, interactive energy analytics.
    Supports Formation Energy, Chemical Potentials, Sensitivity analysis, and dynamic sorting.
    Returns the new index if the user clicked on the trace, otherwise returns -1.
    """
    new_idx = -1
    imgui.set_next_window_bg_alpha(0.85)
    imgui.set_next_window_size(550, 750, imgui.FIRST_USE_EVER)
    if not imgui.begin("Energy Analytics Explorer", True):
        imgui.end()
        return new_idx

    if not hasattr(viewer, "active_energies") or viewer.active_energies.size == 0:
        imgui.text_disabled("Waiting for structural data...")
        imgui.end()
        return new_idx

    energies = viewer.active_energies
    raw_energies = viewer.all_energies
    current_idx = viewer.index1
    view_indices = viewer.energy_view_indices

    # --- 1. Top Controls (Mode & Sort) ---
    imgui.text_colored("Energy Mode:", 0.4, 0.7, 1.0)
    imgui.same_line(120)
    modes = ["Raw energy", "Formation energy", "Relative energy", "E_form / atom", "Z-score"]
    changed_m, viewer.energy_mode = imgui.combo("##e_mode", viewer.energy_mode, modes)
    
    imgui.text_colored("Sort By:", 0.4, 0.7, 1.0)
    imgui.same_line(120)
    sort_modes = ["Original Order", "Energy Ascending", "Energy Descending", "Most improved (Rank Shift)"]
    changed_s, viewer.energy_sort_mode = imgui.combo("##sort_m", viewer.energy_sort_mode, sort_modes)
    
    if changed_m or changed_s:
        viewer._update_energy_analytics()

    imgui.spacing()
    
    # --- 2. Chemical Potentials (Sliders) ---
    if viewer.energy_mode in [1, 3]: # Formation or E/atom
        if imgui.tree_node("Chemical Potentials (mu)", imgui.TREE_NODE_DEFAULT_OPEN):
            changed_mu = False
            imgui.columns(3, border=False)
            for el in viewer.comp_species:
                val = viewer.mu.get(el, 0.0)
                imgui.text(f"{el}:")
                imgui.same_line(30)
                imgui.push_item_width(-1)
                changed_el, new_val = imgui.drag_float(f"##mu_{el}", val, 0.01, -20.0, 5.0, "%.3f eV")
                imgui.pop_item_width()
                if changed_el:
                    viewer.mu[el] = new_val
                    changed_mu = True
                imgui.next_column()
            imgui.columns(1)
            
            # Presets
            imgui.text("Presets:")
            imgui.same_line()
            if "O" in viewer.comp_species:
                if imgui.button("O-rich"):
                    viewer.mu["O"] = -4.0; changed_mu = True
                imgui.same_line()
                if imgui.button("O-poor"):
                    viewer.mu["O"] = -6.0; changed_mu = True
                imgui.same_line()
            
            if "H" in viewer.comp_species:
                if imgui.button("H-rich"):
                    viewer.mu["H"] = -2.0; changed_mu = True
                imgui.same_line()
            if imgui.button("Reset Defaults"):
                viewer.mu = {"Ni": -5.43, "Fe": -6.21, "V": -7.10, "K": -1.02, "H": -3.39, "O": -4.92}
                changed_mu = True
            
            if changed_mu:
                viewer._update_energy_analytics()
            imgui.tree_pop()

    # --- 2.5 Statistics Summary ---
    valid_vals = energies[np.isfinite(energies)]
    if valid_vals.size > 0:
        imgui.spacing()
        imgui.text_colored("Statistics:", 0.6, 1.0, 0.8)
        imgui.columns(4, border=False)
        imgui.text(f"Best: {np.min(valid_vals):.4f}"); imgui.next_column()
        imgui.text(f"Mean: {np.mean(valid_vals):.4f}"); imgui.next_column()
        imgui.text(f"Median: {np.median(valid_vals):.4f}"); imgui.next_column()
        imgui.text(f"Std: {np.std(valid_vals):.4f}"); imgui.next_column()
        imgui.columns(1)
        
        # Selection Threshold
        imgui.push_item_width(100)
        _, viewer.energy_threshold = imgui.drag_float("Threshold (eV/atom)", viewer.energy_threshold, 0.001, 0.0, 1.0, "%.3f")
        imgui.pop_item_width()
        imgui.same_line()
        if imgui.button("Select candidates below threshold"):
            # Select structures with E < E_min + threshold
            e_min = np.min(valid_vals)
            target_indices = np.where(energies <= e_min + viewer.energy_threshold)[0]
            # Actually, we need to communicate this back to the viewer's selection system
            # For now just print or set a flag
            print(f"Selecting {len(target_indices)} candidates...")
    
    imgui.separator()
    imgui.spacing()

    # --- 3. Main Plot: Energy Trajectory ---
    draw_list = imgui.get_window_draw_list()
    avail_w = imgui.get_content_region_available_width()
    p_orig = imgui.get_cursor_screen_pos()
    
    imgui.text_colored(f"{modes[viewer.energy_mode]} Landscape", 0.6, 0.8, 1.0)
    plot_h = 180
    margin_l, margin_r, margin_t, margin_b = 65, 25, 10, 35
    p0 = (p_orig[0] + margin_l, p_orig[1] + margin_t)
    p1 = (p0[0] + avail_w - margin_l - margin_r, p0[1] + plot_h - margin_t - margin_b)
    cw, ch = (p1[0] - p0[0]), (p1[1] - p0[1])

    # We plot in the order specified by view_indices? 
    # Actually, for trajectory it makes more sense to plot in original order but maybe color by active energy.
    # But usually "view_indices" is for the ranking table.
    # The plot should probably show the energy sequence in original order but use active values.
    
    imgui.invisible_button("##trace_zone", avail_w, plot_h)
    is_hovered = imgui.is_item_hovered()
    
    draw_list.add_rect_filled(p0[0], p0[1], p1[0], p1[1], 0x55111111, rounding=4)
    draw_list.add_rect(p0[0], p0[1], p1[0], p1[1], 0xAA666666, rounding=4)

    valid_mask = np.isfinite(energies)
    if not np.any(valid_mask):
        imgui.text_colored("No valid data for this mode.", 1.0, 0.4, 0.4)
    else:
        e_min, e_max = np.nanmin(energies), np.nanmax(energies)
        e_range = e_max - e_min if e_max > e_min else 1.0
        
    # Plot trace
        # Plot trace
        num_pts = min(len(view_indices), int(cw))
        if num_pts > 1:
            step = len(view_indices) / num_pts
            pts = []
            for i in range(num_pts):
                # Map rank i to original index via view_indices
                rank_idx = int(i * step)
                rank_idx = min(rank_idx, len(view_indices) - 1)
                orig_idx = view_indices[rank_idx]
                val = energies[orig_idx]
                if not np.isfinite(val): continue
                px = p0[0] + (i / (num_pts - 1)) * cw
                py = p1[1] - ((val - e_min) / e_range) * ch
                pts.append((px, py))
            
            for i in range(len(pts)-1):
                draw_list.add_line(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1], 0xFFAABBFF, 1.5)

        # Highlight current structure in the sorted sequence
        if 0 <= current_idx < len(energies) and len(view_indices) > 0:
            # Find the rank of the current_idx
            try:
                curr_rank = np.where(view_indices == current_idx)[0][0]
                val_curr = energies[current_idx]
                if np.isfinite(val_curr):
                    cx = p0[0] + (curr_rank / max(1, len(view_indices)-1)) * cw if len(view_indices)>1 else p0[0] + cw/2
                    cy = p1[1] - ((val_curr - e_min) / e_range) * ch
                    draw_list.add_line(cx, p0[1], cx, p1[1], 0x44FF00FF, 1.0)
                    draw_list.add_circle_filled(cx, cy, 5.0, 0xFFFF00FF)
            except IndexError:
                pass

        if is_hovered and len(view_indices) > 0:
            m_pos = imgui.get_mouse_pos()
            if p0[0] <= m_pos[0] <= p1[0]:
                h_rank = int(((m_pos[0] - p0[0]) / cw) * (len(view_indices)-1))
                h_rank = np.clip(h_rank, 0, len(view_indices)-1)
                h_idx = view_indices[h_rank]
                imgui.set_tooltip(f"Rank: {h_rank+1}\nID: {h_idx}\nE: {energies[h_idx]:.5f}\nRaw: {raw_energies[h_idx]:.3f}")
                if imgui.is_mouse_clicked(0):
                    new_idx = h_idx

    imgui.set_cursor_screen_pos((p_orig[0], p_orig[1] + plot_h + 10))

    # --- 4. Distribution Histogram ---
    imgui.text_colored("Distribution", 0.6, 1.0, 0.8)
    hist_h = 100
    p_hist = imgui.get_cursor_screen_pos()
    imgui.dummy(avail_w, hist_h)
    
    h_p0 = (p_hist[0] + margin_l, p_hist[1])
    h_p1 = (h_p0[0] + cw, h_p0[1] + hist_h - 20)
    
    valid_vals = energies[np.isfinite(energies)]
    if valid_vals.size > 0:
        # Determine appropriate number of bins defensively
        v_min, v_max = valid_vals.min(), valid_vals.max()
        if v_max - v_min < 1e-7:
            counts = np.array([valid_vals.size])
            bins = np.array([v_min - 0.5, v_max + 0.5])
        else:
            try:
                counts, bins = np.histogram(valid_vals, bins=30)
            except ValueError:
                counts = np.array([valid_vals.size])
                bins = np.array([v_min - 0.5, v_max + 0.5])
                
        c_max = np.max(counts) if counts.size > 0 else 1
        bin_w = cw / len(counts)
        for i, c in enumerate(counts):
            bx0 = h_p0[0] + i * bin_w
            bx1 = bx0 + bin_w - 1
            by0 = h_p1[1] - (c / c_max) * (h_p1[1] - h_p0[1])
            draw_list.add_rect_filled(bx0, by0, bx1, h_p1[1], 0xFF88FF88)
    
    imgui.set_cursor_screen_pos((p_hist[0], p_hist[1] + hist_h))

    # --- 5. Selected Structure Details & Sensitivity ---
    imgui.separator()
    if imgui.tree_node("Selected Structure Breakdown", imgui.TREE_NODE_DEFAULT_OPEN):
        if 0 <= current_idx < len(energies):
            E_tot = raw_energies[current_idx]
            E_act = energies[current_idx]
            imgui.columns(2, border=True)
            imgui.text("Property"); imgui.next_column(); imgui.text("Value"); imgui.next_column(); imgui.separator()
            
            imgui.text("Total Energy (Raw)"); imgui.next_column(); imgui.text(f"{E_tot:.4f} eV"); imgui.next_column()
            imgui.text(f"{modes[viewer.energy_mode]}"); imgui.next_column(); imgui.text(f"{E_act:.4f}"); imgui.next_column()
            
            if viewer.energy_mode in [1, 3]:
                # Contribution breakdown
                imgui.separator()
                imgui.text_colored("Component", 0.4, 0.7, 1.0); imgui.next_column(); imgui.text_colored("Value", 0.4, 0.7, 1.0); imgui.next_column(); imgui.separator()
                
                imgui.text("E_raw"); imgui.next_column(); imgui.text(f"{E_tot:+.2f}"); imgui.next_column()
                
                # Check composition matrix
                if viewer.comp_matrix is not None and current_idx < viewer.comp_matrix.shape[0]:
                    row = viewer.comp_matrix[current_idx]
                    for i, sp in enumerate(viewer.comp_species):
                        n_i = row[i]
                        if n_i > 0:
                            mu_i = viewer.mu.get(sp, 0.0)
                            term = -n_i * mu_i
                            imgui.text(f"-n_{sp} * mu_{sp}"); imgui.next_column(); imgui.text(f"{term:+.2f} (n={int(n_i)})"); imgui.next_column()
                
            imgui.columns(1)
            
            # Sensitivity Chart
            if viewer.energy_mode in [1, 3] and viewer.comp_matrix is not None:
                imgui.spacing()
                imgui.text_colored("Chemical Sensitivity (dE/dmu = -n_i)", 0.4, 0.7, 1.0)
                row = viewer.comp_matrix[current_idx]
                max_n = np.max(row) if row.size > 0 else 1
                for i, sp in enumerate(viewer.comp_species):
                    if row[i] > 0:
                        imgui.text(f"{str(sp):2s}")
                        imgui.same_line(40)
                        imgui.progress_bar(row[i]/max_n, size=(-1, 15), overlay=f"n={int(row[i])}")
        else:
            imgui.text_disabled("No structure selected.")
        imgui.tree_pop()

    # --- 6. Stability Plots (E vs mu) ---
    if viewer.energy_mode in [1, 3] and viewer.comp_matrix is not None and len(viewer.comp_species) > 0:
        imgui.separator()
        if imgui.tree_node("Stability: E_form vs Chemical Potential"):
            imgui.text("Scan Element mu:")
            imgui.same_line()
            
            # Ensure the selected element is valid
            if viewer.formation_mu_element not in viewer.comp_species:
                viewer.formation_mu_element = viewer.comp_species[0]
            
            curr_idx_mu = viewer.comp_species.index(viewer.formation_mu_element)
            changed_mu_el, _idx = imgui.combo("##mu_scan", curr_idx_mu, viewer.comp_species)
            if changed_mu_el:
                viewer.formation_mu_element = viewer.comp_species[_idx]
            
            # Advanced Line Plot (One line per structure)
            plot_h2 = 180
            p_mu_orig = imgui.get_cursor_screen_pos()
            imgui.dummy(avail_w, plot_h2)
            
            m0 = (p_mu_orig[0] + margin_l, p_mu_orig[1] + 10)
            m1 = (m0[0] + cw, m0[1] + plot_h2 - 35)
            draw_list.add_rect_filled(m0[0], m0[1], m1[0], m1[1], 0x55111111, rounding=4)
            draw_list.add_rect(m0[0], m0[1], m1[0], m1[1], 0xAA666666, rounding=4)

            mu_min, mu_max = -12.0, 2.0
            target_sp_idx = viewer.comp_species.index(viewer.formation_mu_element)
            
            # Vectorized calculation for all structures
            target_counts = viewer.comp_matrix[:, target_sp_idx]
            
            # Calculate base correction (sum of n_i * mu_i for all i except target)
            total_mu_correction = np.zeros(len(raw_energies))
            for i, sp in enumerate(viewer.comp_species):
                total_mu_correction += viewer.comp_matrix[:, i] * viewer.mu.get(sp, 0.0)
            
            mu_target_curr = viewer.mu.get(viewer.formation_mu_element, 0.0)
            base_corr = total_mu_correction - target_counts * mu_target_curr
            
            slopes = -target_counts
            intercepts = raw_energies - base_corr
            if viewer.energy_mode == 3: # Normalize per atom
                slopes /= np.where(viewer.all_natoms > 0, viewer.all_natoms, 1.0)
                intercepts /= np.where(viewer.all_natoms > 0, viewer.all_natoms, 1.0)
            
            y0_all = slopes * mu_min + intercepts
            y1_all = slopes * mu_max + intercepts
            
            # Determine Y-axis scale based on a reasonable range (e.g. around current best)
            # We filter out outliers for scaling
            visible_indices = view_indices[:min(200, len(view_indices))]
            y_min = np.nanmin([y0_all[visible_indices].min(), y1_all[visible_indices].min()])
            y_max = np.nanmax([y0_all[visible_indices].max(), y1_all[visible_indices].max()])
            yr = y_max - y_min if y_max > y_min else 1.0
            
            def map_mu(mu): return m0[0] + (mu - mu_min) / (mu_max - mu_min) * cw
            def map_e(e): return m1[1] - (e - y_min) / yr * (m1[1] - m0[1])

            # Draw axes labels
            draw_list.add_text(m0[0] - 50, m0[1], 0xFFAAAAAA, f"{y_max:.2f}")
            draw_list.add_text(m0[0] - 50, m1[1] - 10, 0xFFAAAAAA, f"{y_min:.2f}")
            draw_list.add_text(m0[0], m1[1] + 5, 0xFFAAAAAA, f"mu_{viewer.formation_mu_element}={mu_min}")
            draw_list.add_text(m1[0] - 60, m1[1] + 5, 0xFFAAAAAA, f"{mu_max}")

            # Interactivity: Hover detection
            m_pos = imgui.get_mouse_pos()
            hover_idx = -1
            min_dist = 5.0 # pixels
            
            in_plot = (m0[0] <= m_pos[0] <= m1[0] and m0[1] <= m_pos[1] <= m1[1])
            
            # Batch draw lines (Top 200 for performance, or all if small)
            draw_count = min(300, len(view_indices))
            for i in range(draw_count - 1, -1, -1): # Reverse to draw best on top
                idx = view_indices[i]
                p0 = (map_mu(mu_min), map_e(y0_all[idx]))
                p1 = (map_mu(mu_max), map_e(y1_all[idx]))
                
                is_curr = (idx == current_idx)
                col = 0xAA888888 # Default background
                thickness = 1.0
                
                if is_curr:
                    col = 0xFFFF00FF # Purple highlight
                    thickness = 2.0
                
                # Point-to-segment distance for hover
                if in_plot and hover_idx == -1:
                    # Simple segment distance
                    v = (p1[0] - p0[0], p1[1] - p0[1])
                    w = (m_pos[0] - p0[0], m_pos[1] - p0[1])
                    c1 = w[0]*v[0] + w[1]*v[1]
                    c2 = v[0]*v[0] + v[1]*v[1]
                    if c1 > 0 and c1 < c2:
                        b = c1 / c2
                        pb = (p0[0] + b*v[0], p0[1] + b*v[1])
                        d = ((m_pos[0]-pb[0])**2 + (m_pos[1]-pb[1])**2)**0.5
                        if d < min_dist:
                            hover_idx = idx
                            col = 0xFFFFFFFF
                            thickness = 2.5

                draw_list.add_line(p0[0], p0[1], p1[0], p1[1], col, thickness)

            if hover_idx != -1:
                imgui.set_tooltip(f"Structure ID: {hover_idx}\nSlope (-n_i): {slopes[hover_idx]:.2f}")
                if imgui.is_mouse_clicked(0):
                    new_idx = hover_idx

            # Vertical line for current mu
            curr_mu_x = map_mu(mu_target_curr)
            draw_list.add_line(curr_mu_x, m0[1], curr_mu_x, m1[1], 0x88FFFFFF, 1.0)
            draw_list.add_text(curr_mu_x + 3, m0[1] + 5, 0x88FFFFFF, f"Current mu")

            imgui.tree_pop()

    # --- 6.5. 2D Phase Stability Diagram (E_form vs mu_A and mu_B) ---
    if viewer.energy_mode in [1, 3] and viewer.comp_matrix is not None and len(viewer.comp_species) >= 2:
        imgui.separator()
        if imgui.tree_node("2D Phase Stability: E_form vs mu_A & mu_B"):
            # Ensure elements are valid
            if not hasattr(viewer, "mu_2d_element_a") or viewer.mu_2d_element_a not in viewer.comp_species:
                viewer.mu_2d_element_a = viewer.comp_species[0]
            if not hasattr(viewer, "mu_2d_element_b") or viewer.mu_2d_element_b not in viewer.comp_species:
                viewer.mu_2d_element_b = viewer.comp_species[min(1, len(viewer.comp_species)-1)]
                
            imgui.text("Element A (X):")
            imgui.same_line(120)
            imgui.push_item_width(150)
            curr_idx_a = viewer.comp_species.index(viewer.mu_2d_element_a)
            changed_a, idx_a_new = imgui.combo("##mu_2d_a", curr_idx_a, viewer.comp_species)
            if changed_a:
                viewer.mu_2d_element_a = viewer.comp_species[idx_a_new]
            imgui.pop_item_width()
                
            imgui.text("Element B (Y):")
            imgui.same_line(120)
            imgui.push_item_width(150)
            curr_idx_b = viewer.comp_species.index(viewer.mu_2d_element_b)
            changed_b, idx_b_new = imgui.combo("##mu_2d_b", curr_idx_b, viewer.comp_species)
            if changed_b:
                viewer.mu_2d_element_b = viewer.comp_species[idx_b_new]
            imgui.pop_item_width()
                
            # Render grid
            if len(view_indices) > 0:
                def get_distinct_color(idx: int, alpha: int = 0xBB) -> int:
                    import colorsys
                    golden_ratio_conjugate = 0.618033988749895
                    h = (idx * golden_ratio_conjugate) % 1.0
                    s = 0.8
                    v = 0.85
                    r, g, b = colorsys.hsv_to_rgb(h, s, v)
                    ir = int(r * 255)
                    ig = int(g * 255)
                    ib = int(b * 255)
                    return (alpha << 24) | (ib << 16) | (ig << 8) | ir
                
                mu_min, mu_max = -12.0, 2.0
                idx_a = viewer.comp_species.index(viewer.mu_2d_element_a)
                idx_b = viewer.comp_species.index(viewer.mu_2d_element_b)
                
                # Check cache on viewer
                if not hasattr(viewer, "_phase_diagram_cache"):
                    viewer._phase_diagram_cache = {}
                
                current_key = (
                    viewer.mu_2d_element_a,
                    viewer.mu_2d_element_b,
                    viewer.energy_mode,
                    tuple(sorted(viewer.mu.items())),
                    hash(view_indices.tobytes()) if hasattr(view_indices, "tobytes") else len(view_indices)
                )
                
                if current_key in viewer._phase_diagram_cache:
                    cached_data = viewer._phase_diagram_cache[current_key]
                    stable_ids = cached_data["stable_ids"]
                    unique_stable_ids = cached_data["unique_stable_ids"]
                    intercepts = cached_data["intercepts"]
                    slopes_A = cached_data["slopes_A"]
                    slopes_B = cached_data["slopes_B"]
                    mu_A_vals = cached_data["mu_A_vals"]
                    mu_B_vals = cached_data["mu_B_vals"]
                else:
                    n_A = viewer.comp_matrix[:, idx_a]
                    n_B = viewer.comp_matrix[:, idx_b]
                    
                    # Sum of n_i * mu_i for all i
                    total_mu_correction = np.zeros(len(raw_energies))
                    for i, sp in enumerate(viewer.comp_species):
                        total_mu_correction += viewer.comp_matrix[:, i] * viewer.mu.get(sp, 0.0)
                        
                    # Base correction excluding target A and target B
                    mu_A_curr = viewer.mu.get(viewer.mu_2d_element_a, 0.0)
                    mu_B_curr = viewer.mu.get(viewer.mu_2d_element_b, 0.0)
                    base_corr = total_mu_correction - n_A * mu_A_curr - n_B * mu_B_curr
                    
                    intercepts = raw_energies - base_corr
                    slopes_A = -n_A
                    slopes_B = -n_B
                    
                    if viewer.energy_mode == 3: # Normalize per atom
                        nat = np.where(viewer.all_natoms > 0, viewer.all_natoms, 1.0)
                        intercepts = intercepts / nat
                        slopes_A = slopes_A / nat
                        slopes_B = slopes_B / nat
                        
                    # Grid dimensions
                    C, R = 30, 30
                    mu_A_vals = np.linspace(mu_min, mu_max, C)
                    mu_B_vals = np.linspace(mu_min, mu_max, R)
                    
                    # E_all: (N_active, C, R)
                    E_all = (intercepts[view_indices, None, None] 
                             + slopes_A[view_indices, None, None] * mu_A_vals[None, :, None] 
                             + slopes_B[view_indices, None, None] * mu_B_vals[None, None, :])
                    
                    min_idx_v = np.argmin(E_all, axis=0) # (C, R)
                    stable_ids = view_indices[min_idx_v] # (C, R)
                    unique_stable_ids = np.unique(stable_ids)
                    
                    viewer._phase_diagram_cache = {
                        current_key: {
                            "stable_ids": stable_ids,
                            "unique_stable_ids": unique_stable_ids,
                            "intercepts": intercepts,
                            "slopes_A": slopes_A,
                            "slopes_B": slopes_B,
                            "mu_A_vals": mu_A_vals,
                            "mu_B_vals": mu_B_vals
                        }
                    }
                
                C, R = 30, 30
                mu_A_curr = viewer.mu.get(viewer.mu_2d_element_a, 0.0)
                mu_B_curr = viewer.mu.get(viewer.mu_2d_element_b, 0.0)
                
                # Drawing setup
                plot_h2d = 180
                p_mu2d_orig = imgui.get_cursor_screen_pos()
                imgui.dummy(avail_w, plot_h2d)
                
                m0_2d = (p_mu2d_orig[0] + margin_l, p_mu2d_orig[1] + 10)
                cw_2d = 180
                ch_2d = 140
                m1_2d = (m0_2d[0] + cw_2d, m0_2d[1] + ch_2d)
                
                # Draw black background card with grey border
                draw_list.add_rect_filled(m0_2d[0], m0_2d[1], m1_2d[0], m1_2d[1], 0x55111111, rounding=4)
                draw_list.add_rect(m0_2d[0], m0_2d[1], m1_2d[0], m1_2d[1], 0xAA666666, rounding=4)
                
                # Draw Y-axis (mu_B) labels
                draw_list.add_text(m0_2d[0] - 50, m0_2d[1], 0xFFAAAAAA, f"{mu_max:.1f}")
                draw_list.add_text(m0_2d[0] - 50, m1_2d[1] - 10, 0xFFAAAAAA, f"{mu_min:.1f}")
                draw_list.add_text(m0_2d[0] - 50, (m0_2d[1] + m1_2d[1])/2 - 5, 0xFFAAAAAA, f"mu_B")
                
                # Draw X-axis (mu_A) labels
                draw_list.add_text(m0_2d[0], m1_2d[1] + 5, 0xFFAAAAAA, f"mu_A={mu_min:.1f}")
                draw_list.add_text(m1_2d[0] - 40, m1_2d[1] + 5, 0xFFAAAAAA, f"{mu_max:.1f}")
                
                # 2D Grid Cells Rendering
                for c in range(C):
                    for r in range(R):
                        sid = stable_ids[c, r]
                        color = get_distinct_color(sid)
                        
                        x0 = m0_2d[0] + (c / C) * cw_2d
                        x1 = m0_2d[0] + ((c + 1) / C) * cw_2d
                        y0 = m1_2d[1] - ((r + 1) / R) * ch_2d
                        y1 = m1_2d[1] - (r / R) * ch_2d
                        
                        draw_list.add_rect_filled(x0, y0, x1, y1, color)
                        
                # Interactive hover detection
                m_pos = imgui.get_mouse_pos()
                in_plot = (m0_2d[0] <= m_pos[0] <= m1_2d[0] and m0_2d[1] <= m_pos[1] <= m1_2d[1])
                
                if in_plot:
                    col_idx = int((m_pos[0] - m0_2d[0]) / cw_2d * C)
                    row_idx = int((m_pos[1] - m0_2d[1]) / ch_2d * R)
                    row_idx = (R - 1) - row_idx # Flip because screen y increases downwards
                    
                    col_idx = max(0, min(C - 1, col_idx))
                    row_idx = max(0, min(R - 1, row_idx))
                    
                    sid = stable_ids[col_idx, row_idx]
                    mu_A_hover = mu_A_vals[col_idx]
                    mu_B_hover = mu_B_vals[row_idx]
                    
                    e_val = intercepts[sid] + slopes_A[sid] * mu_A_hover + slopes_B[sid] * mu_B_hover
                    
                    comp_str = ""
                    if sid < len(viewer.provider):
                        row_comp = viewer.comp_matrix[sid]
                        comp_str = " ".join([f"{viewer.comp_species[i]}{int(row_comp[i])}" for i in range(len(viewer.comp_species)) if row_comp[i] > 0])
                    
                    e_unit = "eV/atom" if viewer.energy_mode == 3 else "eV"
                    imgui.set_tooltip(
                        f"Coordinates:\n"
                        f"  mu_{viewer.mu_2d_element_a}: {mu_A_hover:.2f} eV\n"
                        f"  mu_{viewer.mu_2d_element_b}: {mu_B_hover:.2f} eV\n\n"
                        f"Stable Phase:\n"
                        f"  Structure ID: {sid}\n"
                        f"  Formula: {comp_str}\n"
                        f"  E_form: {e_val:.3f} {e_unit}"
                    )
                    
                    if imgui.is_mouse_clicked(0):
                        new_idx = sid
                        
                # Draw active reticle
                reticle_x = m0_2d[0] + (mu_A_curr - mu_min) / (mu_max - mu_min) * cw_2d
                reticle_y = m1_2d[1] - (mu_B_curr - mu_min) / (mu_max - mu_min) * ch_2d
                
                reticle_x = max(m0_2d[0], min(m1_2d[0], reticle_x))
                reticle_y = max(m0_2d[1], min(m1_2d[1], reticle_y))
                
                draw_list.add_circle_filled(reticle_x, reticle_y, 4.0, 0xFF000000)
                draw_list.add_circle_filled(reticle_x, reticle_y, 3.0, 0xFFFFFFFF)
                
                # Legend of stable phases
                imgui.spacing()
                imgui.text_colored("Stable Phases Legend (Click to Select):", 0.4, 0.7, 1.0)
                unique_stable_ids = np.unique(stable_ids)
                
                imgui.columns(2)
                for sid in unique_stable_ids:
                    color_abgr = get_distinct_color(sid, alpha=0xFF)
                    r = (color_abgr & 0xFF) / 255.0
                    g = ((color_abgr >> 8) & 0xFF) / 255.0
                    b = ((color_abgr >> 16) & 0xFF) / 255.0
                    a = 1.0
                    
                    imgui.color_button(f"##col_leg_{sid}", r, g, b, a)
                    imgui.same_line()
                    
                    comp_str = ""
                    if sid < len(viewer.provider):
                        row_comp = viewer.comp_matrix[sid]
                        comp_str = " ".join([f"{viewer.comp_species[i]}{int(row_comp[i])}" for i in range(len(viewer.comp_species)) if row_comp[i] > 0])
                    
                    label = f"ID {sid} ({comp_str})"
                    opened, selected = imgui.selectable(label, sid == current_idx)
                    if opened:
                        new_idx = sid
                    imgui.next_column()
                    
                imgui.columns(1)
            imgui.tree_pop()

    # --- 7. Ranking Table (Dynamic) ---
    imgui.separator()
    imgui.text_colored("Ranking Table", 0.4, 0.7, 1.0)
    imgui.begin_child("rank_table", 0, 150, border=True)
    imgui.columns(4, border=True)
    imgui.text("Rank"); imgui.next_column(); imgui.text("ID"); imgui.next_column(); imgui.text("Energy"); imgui.next_column(); imgui.text("Shift"); imgui.next_column(); imgui.separator()
    
    # Calculate ranks for shift
    raw_ranks = np.argsort(np.argsort(raw_energies))
    
    for i in range(min(50, len(view_indices))):
        idx = view_indices[i]
        is_sel = (idx == current_idx)
        if is_sel: imgui.push_style_color(imgui.COLOR_TEXT, 1.0, 1.0, 0.0, 1.0)
        
        imgui.text(f"{i+1}"); imgui.next_column()
        if imgui.selectable(f"{idx}##rank_{i}", is_sel)[0]:
            new_idx = idx
        imgui.next_column()
        imgui.text(f"{energies[idx]:.3f}"); imgui.next_column()
        
        # Shift
        curr_rank = i
        old_rank = raw_ranks[idx]
        shift = old_rank - curr_rank
        col = (0.4, 1.0, 0.4) if shift > 0 else (1.0, 0.4, 0.4) if shift < 0 else (0.7, 0.7, 0.7)
        imgui.text_colored(f"{shift:+d}", *col); imgui.next_column()
        
        if is_sel: imgui.pop_style_color()
    
    imgui.end_child()

    imgui.end()
    return new_idx


# ────────────────────────────────────────────────
# Tight-Binding DOS / PDOS Plot
# ────────────────────────────────────────────────
_SPECIES_COLORS = [
    0xFF4488FF, 0xFFFF6644, 0xFF44CC77, 0xFFCC44EE,
    0xFFFFCC33, 0xFF33CCFF, 0xFFFF4477, 0xFF77FF44,
]

def draw_dos_plot(dos_x: np.ndarray, dos_y: np.ndarray, fermi: float,
                  pdos_y: dict = None, homo: float = 0.0, lumo: float = 0.0,
                  gap: float = 0.0, pdos_orb: dict = None,
                  pdos_visibility: dict = None, pdos_orb_visibility: dict = None) -> float:
    """Renders an interactive DOS / PDOS plot."""
    clicked_e = None
    imgui.set_next_window_bg_alpha(0.85)
    imgui.set_next_window_size(480, 500, imgui.FIRST_USE_EVER)
    if not imgui.begin("Density of States (Tight-Binding)"):
        imgui.end()
        return clicked_e

    if dos_x is None or len(dos_x) == 0:
        imgui.text_disabled("Run TB calculation to see DOS.")
        imgui.end()
        return clicked_e

    draw_list = imgui.get_window_draw_list()
    avail_w = imgui.get_content_region_available_width()
    plot_h = 240
    p0 = imgui.get_cursor_screen_pos()
    p1 = (p0[0] + avail_w, p0[1] + plot_h)

    draw_list.add_rect_filled(p0[0], p0[1], p1[0], p1[1], 0xFF1A1A2A)
    draw_list.add_rect(p0[0], p0[1], p1[0], p1[1], 0xFF555577)

    e_min, e_max = float(dos_x[0]), float(dos_x[-1])
    d_max = float(dos_y.max()) * 1.05 if dos_y.max() > 0 else 1.0
    w = p1[0] - p0[0]
    h = p1[1] - p0[1]

    def ex(e): return p0[0] + (e - e_min) / (e_max - e_min) * w
    def ey(d): return p1[1] - (d / d_max) * h

    pts = [(ex(dos_x[0]), p1[1])]
    for i in range(len(dos_x)):
        pts.append((ex(dos_x[i]), ey(dos_y[i])))
    pts.append((ex(dos_x[-1]), p1[1]))
    
    poly_pts = [imgui.Vec2(px, py) for px, py in pts]
    draw_list.add_polyline(poly_pts, 0x9944AAFF, 0, 1.5)

    if pdos_y:
        for ci, (sp, py) in enumerate(pdos_y.items()):
            if pdos_visibility and not pdos_visibility.get(sp, True): continue
            col = _SPECIES_COLORS[ci % len(_SPECIES_COLORS)]
            pts_sp = [imgui.Vec2(ex(dos_x[i]), ey(float(py[i]))) for i in range(len(dos_x))]
            draw_list.add_polyline(pts_sp, col, 0, 1.5)

    if pdos_orb:
        orb_colors = {"s": 0xFFFFFFFF, "p": 0xFF88CCFF, "d": 0xFFFF8888}
        for orb, py in pdos_orb.items():
            if pdos_orb_visibility and not pdos_orb_visibility.get(orb, True): continue
            col = orb_colors.get(orb.lower(), 0xFFCCCCCC)
            pts_orb = [imgui.Vec2(ex(dos_x[i]), ey(float(py[i]))) for i in range(len(dos_x))]
            draw_list.add_polyline(pts_orb, col, 0, 1.2)

    fx = ex(fermi)
    if p0[0] <= fx <= p1[0]:
        for yy in range(int(p0[1]), int(p1[1]), 8):
            draw_list.add_line(fx, yy, fx, min(yy+4, p1[1]), 0xAAFFDD44, 1.5)
        draw_list.add_text(fx + 3, p0[1] + 4, 0xFFFFDD44, "Ef")

    imgui.set_cursor_screen_pos(p0)
    imgui.invisible_button("##dos_ints", avail_w, plot_h)
    if imgui.is_item_hovered():
        mx = imgui.get_mouse_pos().x
        e_hover = e_min + (mx - p0[0]) / w * (e_max - e_min)
        draw_list.add_line(mx, p0[1], mx, p1[1], 0x88FFFFFF, 1.0)
        imgui.set_tooltip(f"E: {e_hover:+.4f} eV")
        if imgui.is_mouse_clicked(0):
            clicked_e = e_hover

    imgui.set_cursor_screen_pos((p0[0], p1[1] + 10))
    imgui.text_colored(f"Gap: {gap:.3f} eV", 1.0, 1.0, 0.4)
    imgui.same_line()
    imgui.text_disabled("| Click peak to center energy window")

    if pdos_y or pdos_orb:
        imgui.separator()
        if pdos_y:
            imgui.text("Project by Species:")
            imgui.columns(min(3, len(pdos_y)))
            for ci, sp in enumerate(pdos_y):
                if pdos_visibility is not None:
                    col = _SPECIES_COLORS[ci % len(_SPECIES_COLORS)]
                    r = ((col >> 0) & 0xFF)/255.0; g = ((col >> 8) & 0xFF)/255.0; b = ((col >> 16) & 0xFF)/255.0
                    imgui.push_style_color(imgui.COLOR_CHECK_MARK, r, g, b)
                    _, pdos_visibility[sp] = imgui.checkbox(f"{sp}##pdos", pdos_visibility.get(sp, True))
                    imgui.pop_style_color(1)
                    imgui.next_column()
            imgui.columns(1)
            
        if pdos_orb:
            imgui.text("Project by Shell:")
            orb_colors_imgui = {"s": (1,1,1,1), "p": (0.5,0.8,1,1), "d": (1,0.5,0.5,1)}
            for orb in sorted(pdos_orb.keys()):
                if pdos_orb_visibility is not None:
                    col = orb_colors_imgui.get(orb.lower(), (0.8, 0.8, 0.8, 1))
                    imgui.push_style_color(imgui.COLOR_CHECK_MARK, *col)
                    _, pdos_orb_visibility[orb] = imgui.checkbox(f"{orb}-shell", pdos_orb_visibility.get(orb, True))
                    imgui.pop_style_color(1)
                    imgui.same_line()
            imgui.new_line()

    imgui.end()
    return clicked_e


# ────────────────────────────────────────────────
# Eigenvalue Ladder Plot
# ────────────────────────────────────────────────
def draw_eigenvalue_ladder(eigenvalues: np.ndarray, n_occ: int,
                           ipr: np.ndarray = None, fermi: float = 0.0,
                           selected_idx: int = -1) -> int:
    """Renders an energy level diagram. Occupied states (green), unoccupied (red)."""
    new_sel = -1
    imgui.set_next_window_bg_alpha(0.85)
    imgui.set_next_window_size(240, 420, imgui.FIRST_USE_EVER)
    if not imgui.begin("Energy Levels (Tight-Binding)"):
        imgui.end()
        return new_sel

    if eigenvalues is None or len(eigenvalues) == 0:
        imgui.text_disabled("No eigenvalues.")
        imgui.end()
        return new_sel

    draw_list = imgui.get_window_draw_list()
    avail_w = imgui.get_content_region_available_width()
    plot_h = 320
    p0 = imgui.get_cursor_screen_pos()

    draw_list.add_rect_filled(p0[0], p0[1], p0[0] + avail_w, p0[1] + plot_h, 0xFF1A1A2A)

    center = n_occ; half = 40
    lo = max(0, center - half); hi = min(len(eigenvalues), center + half)
    ev_show = eigenvalues[lo:hi]

    e_min = float(ev_show.min()) - 0.2
    e_max = float(ev_show.max()) + 0.2
    h = float(plot_h)

    def ey(e): return p0[1] + (1 - (e - e_min) / (e_max - e_min)) * h

    line_w = avail_w - 60; lx0 = p0[0] + 30
    
    for idx, e in enumerate(ev_show):
        g_idx = lo + idx
        y = ey(float(e))
        occ = g_idx < n_occ
        
        imgui.set_cursor_screen_pos((lx0, y - 3))
        imgui.invisible_button(f"##ev_{g_idx}", line_w, 6)
        
        is_hovered = imgui.is_item_hovered()
        if is_hovered:
            imgui.set_tooltip(f"State {g_idx}\nEnergy: {e:+.4f} eV\n{'Occupied' if occ else 'Virtual'}")
            if imgui.is_mouse_clicked(0): new_sel = g_idx

        if g_idx == selected_idx: col = 0xFFFFFFFF; thickness = 3.0
        elif is_hovered: col = 0xFFFFFF00; thickness = 2.0
        elif ipr is not None and len(ipr) > g_idx:
            loc = min(1.0, float(ipr[g_idx]) * len(eigenvalues))
            col = (0xFF2266FF if loc < 0.3 else 0xFFFF8822 if loc > 0.7 else 0xFF44CC44) if occ else 0xFF446688
            thickness = 1.5
        else:
            col = 0xFF44CC44 if occ else 0xFF446688; thickness = 1.5

        draw_list.add_line(lx0, y, lx0 + line_w, y, col, thickness)

    fy = ey(fermi)
    if p0[1] <= fy <= p0[1] + plot_h:
        draw_list.add_line(p0[0], fy, p0[0] + avail_w, fy, 0x99FFDD44, 1.0)
        draw_list.add_text(p0[0] + 5, fy - 15, 0xFFFFDD44, "Ef")

    imgui.set_cursor_screen_pos((p0[0], p0[1] + plot_h + 10))
    imgui.text_disabled(f"Showing {lo}–{hi-1} of {len(eigenvalues)}")
    imgui.text_disabled("Click a level to visualize orbital.")
    
    imgui.end()
    return new_sel


def draw_ramachandran_plot(phi: np.ndarray, psi: np.ndarray, res_info: List[Dict], selected_idx: int = -1) -> int:
    """Renders an interactive Ramachandran plot (Phi vs Psi)."""
    new_center_idx = -1
    imgui.set_next_window_size(400, 450, imgui.FIRST_USE_EVER)
    if not imgui.begin("Ramachandran Explorer (Phi/Psi)"):
        imgui.end()
        return -1

    draw_list = imgui.get_window_draw_list()
    avail_w = imgui.get_content_region_available_width()
    plot_dim = min(avail_w, 350)
    p0 = imgui.get_cursor_screen_pos()
    p1 = (p0[0] + plot_dim, p0[1] + plot_dim)

    draw_list.add_rect_filled(p0[0], p0[1], p1[0], p1[1], 0xFF111111)
    
    def to_plot(angle_phi, angle_psi):
        px = p0[0] + ((angle_phi + 180) / 360.0) * plot_dim
        py = p1[1] - ((angle_psi + 180) / 360.0) * plot_dim
        return px, py

    h_min = to_plot(-150, -100); h_max = to_plot(-30, 30)
    draw_list.add_rect_filled(h_min[0], h_max[1], h_max[0], h_min[1], 0x3344CC44)
    s_min = to_plot(-180, 90); s_max = to_plot(-40, 180)
    draw_list.add_rect_filled(s_min[0], s_max[1], s_max[0], s_min[1], 0x3344CC44)

    mid_x, mid_y = to_plot(0, 0)
    draw_list.add_line(p0[0], mid_y, p1[0], mid_y, 0x44FFFFFF)
    draw_list.add_line(mid_x, p0[1], mid_x, p1[1], 0x44FFFFFF)

    for i in range(len(phi)):
        if np.isnan(phi[i]) or np.isnan(psi[i]): continue
        px, py = to_plot(phi[i], psi[i])
        col = 0xFFFFFFFF if i != selected_idx else 0xFFFF00FF
        radius = 3.0 if i != selected_idx else 5.0
        draw_list.add_circle_filled(px, py, radius, col)
        
    imgui.set_cursor_screen_pos(p0)
    imgui.invisible_button("##rama_zone", plot_dim, plot_dim)
    if imgui.is_item_hovered():
        mx, my = imgui.get_mouse_pos()
        best_d = 20.0
        for i in range(len(phi)):
            if np.isnan(phi[i]): continue
            px, py = to_plot(phi[i], psi[i])
            d = np.sqrt((mx-px)**2 + (my-py)**2)
            if d < best_d:
                best_d = d
                new_center_idx = i
        
        if new_center_idx != -1:
            res = res_info[new_center_idx]
            imgui.set_tooltip(f"Res: {res.get('res_id', '?')} {res.get('name', 'UNK')}\nPhi: {phi[new_center_idx]:.1f}\nPsi: {psi[new_center_idx]:.1f}")
            if imgui.is_mouse_clicked(0):
                new_center_idx = res.get('idx', -1)
            else:
                new_center_idx = -1
        
    imgui.set_cursor_screen_pos((p0[0], p1[1]+5))
    imgui.text_disabled("Click a point to center camera on residue.")
    imgui.end()
    return new_center_idx

def draw_contact_map(matrix: np.ndarray, res_info: List[Dict], texture_id: int = None) -> Tuple[int, int]:
    """Renders a distance heatmap using an OpenGL texture. Returns (i, j) atom indices if clicked."""
    pair = (-1, -1)
    imgui.set_next_window_size(450, 500, imgui.FIRST_USE_EVER)
    if not imgui.begin("Contact Map Explorer"):
        imgui.end()
        return pair

    if matrix is None or matrix.size == 0 or texture_id is None:
        imgui.text("No data. Run analysis first.")
        imgui.end()
        return pair

    avail_w, avail_h = imgui.get_content_region_available()
    plot_dim = min(avail_w, avail_h) - 20
    
    p0 = imgui.get_cursor_screen_pos()
    imgui.image(texture_id, plot_dim, plot_dim)
    
    if imgui.is_item_hovered():
        mx, my = imgui.get_mouse_pos()
        rel_x = (mx - p0[0]) / plot_dim
        rel_y = (my - p0[1]) / plot_dim
        
        n = matrix.shape[0]
        ix = int(np.clip(rel_x * n, 0, n - 1))
        jx = int(np.clip(rel_y * n, 0, n - 1))
        
        if 0 <= ix < n and 0 <= jx < n:
            r1 = res_info[ix]; r2 = res_info[jx]
            imgui.set_tooltip(f"Pair: {r1['res_id']} - {r2['res_id']}\nDistance: {matrix[ix, jx]:.2f} A")
            if imgui.is_mouse_clicked(0):
                pair = (r1['idx'], r2['idx'])

    imgui.end()
    return pair

def draw_sequence_viewer(sequences: List[str], chains_info: List[List[Dict]], selected_atoms: List[int] = None) -> int:
    """Renders an interactive sequence browser. Returns atom index to select if clicked."""
    target_atom_idx = -1
    imgui.set_next_window_size(600, 400, imgui.FIRST_USE_EVER)
    if not imgui.begin("Sequence & FASTA Explorer"):
        imgui.end()
        return -1

    if not sequences:
        imgui.text("No sequence data available.")
        imgui.end()
        return -1

    AA_COLORS = {
        'A': (0.7, 0.7, 0.7), 'V': (0.7, 0.7, 0.7), 'L': (0.7, 0.7, 0.7), 'I': (0.7, 0.7, 0.7), 'P': (0.7, 0.7, 0.7), 'F': (0.7, 0.7, 0.7), 'W': (0.7, 0.7, 0.7), 'M': (0.7, 0.7, 0.7),
        'S': (0.3, 0.8, 0.3), 'T': (0.3, 0.8, 0.3), 'Y': (0.3, 0.8, 0.3), 'N': (0.3, 0.8, 0.3), 'Q': (0.3, 0.8, 0.3), 'C': (0.3, 0.8, 0.3),
        'D': (0.9, 0.2, 0.2), 'E': (0.9, 0.2, 0.2),
        'K': (0.2, 0.2, 0.9), 'R': (0.2, 0.2, 0.9), 'H': (0.2, 0.2, 0.9),
        'G': (0.6, 0.6, 0.6)
    }

    sel_set = set(selected_atoms) if selected_atoms else set()

    for i, seq in enumerate(sequences):
        if imgui.tree_node(f"Chain {i} ({len(seq)} residues)"):
            chain_data = chains_info[i]
            res_list = chain_data.get('res_info', [])
            wrap = 50
            for start in range(0, len(seq), wrap):
                line_end = min(start + wrap, len(seq))
                chunk = seq[start:line_end]
                
                imgui.text(f"{start+1:4d} ")
                imgui.same_line()
                
                for j in range(len(chunk)):
                    aa = chunk[j]
                    abs_idx = start + j
                    res = res_list[abs_idx]
                    ridx = res.get('idx', -1)
                    is_selected = ridx in sel_set
                    
                    if is_selected:
                        p_curr = imgui.get_cursor_screen_pos()
                        draw_list = imgui.get_window_draw_list()
                        draw_list.add_rect_filled(p_curr[0]-1, p_curr[1]-1, p_curr[0]+12, p_curr[1]+15, 0x66FFFFFF, rounding=2.0)
                    
                    col = AA_COLORS.get(aa, (1, 1, 1))
                    imgui.text_colored(aa, *col, 1.0)
                    
                    if imgui.is_item_hovered():
                        imgui.set_tooltip(f"Res: {res.get('res_id', '?')} {res.get('name', 'UNK')}\nChain: {i}\nIndex: {abs_idx+1}")
                        if imgui.is_mouse_clicked(0):
                            target_atom_idx = ridx
                    
                    if j < len(chunk) - 1:
                        imgui.same_line(spacing=2)
                
            imgui.tree_pop()
            imgui.spacing()

    imgui.end()
    return target_atom_idx

def draw_rmsf_plot(rmsf: np.ndarray, res_info: List[Dict]) -> int:
    """Renders RMSF per residue."""
    target_idx = -1
    imgui.set_next_window_size(400, 200, imgui.FIRST_USE_EVER)
    if not imgui.begin("Fluctuation Analysis (RMSF)"):
        imgui.end()
        return -1
    
    if rmsf is not None and rmsf.size > 0:
        imgui.plot_lines("RMSF (A)", rmsf.astype(np.float32), graph_size=(0, 150))
    
    imgui.end()
    return target_idx


# ────────────────────────────────────────────────
# SOAP Structural Correlation Plots
# Supports 1D Radial, 2D Cartesian Heatmap, and Directional Cuts
# ────────────────────────────────────────────────
def draw_soap_correlation_plot(soap_results: Dict[str, Any], state: Dict[str, Any] = None):
    """
    Renders the SOAP structural correlation analysis results.
    Supports 1D Radial, 2D Cartesian Heatmap, and Directional Cuts.
    """
    if not soap_results:
        imgui.text("No SOAP analysis results available.")
        return

    # Ensure persistence object exists
    if not hasattr(draw_soap_correlation_plot, "ui_state"):
        draw_soap_correlation_plot.ui_state = {
            'view_mode': 0,    # 0: 1D, 1: 2D, 2: Both
            'heatmap_type': 0, # 0: Raw, 1: Excess, 2: Counts
            'fill_gaps': True,
            'smoothing': 0.5
        }

    if state is None:
        state = draw_soap_correlation_plot.ui_state
    elif state is not draw_soap_correlation_plot.ui_state:
        # Merge external state into persistent state
        for k, v in state.items():
            draw_soap_correlation_plot.ui_state[k] = v
        state = draw_soap_correlation_plot.ui_state

    symbol = soap_results.get('params', {}).get('center_symbol', 'X')
    imgui.set_next_window_size(550, 720, imgui.FIRST_USE_EVER)
    if not imgui.begin(f"SOAP Structural Correlation ({symbol})"):
        imgui.end()
        return

    # Mode Selector
    imgui.text("View Mode:")
    imgui.same_line()
    _, state['view_mode'] = imgui.combo("##soap_mode", state['view_mode'], ["1D Radial", "2D Lateral", "Both"])
    imgui.separator()

    if state['view_mode'] in [0, 2]:
        _draw_1d_radial_plot(soap_results)
        imgui.spacing()
        imgui.separator()

    if state['view_mode'] in [1, 2]:
        _draw_2d_lateral_section(soap_results, state)
        imgui.separator()

    _draw_soap_diagnostics(soap_results)

    imgui.separator()
    if imgui.button(" Export 1D Profile (CSV) "):
        _export_soap_csv(soap_results)
    
    imgui.end()


def _draw_1d_radial_plot(soap_results):
    """Renders the 1D radial C(r) profile with fit overlay."""
    res_1d = soap_results.get('radial', {})
    if not res_1d:
        return
    
    imgui.text_colored("1D Radial Correlation C(r)", 0.6, 0.8, 1.0)
    avail_w, _ = imgui.get_content_region_available()
    plot_h = 220
    p_orig = imgui.get_cursor_screen_pos()
    imgui.dummy(avail_w, plot_h)
    
    draw_list = imgui.get_window_draw_list()
    margin_l, margin_r, margin_t, margin_b = 50, 20, 20, 30
    p0 = (p_orig[0] + margin_l, p_orig[1] + margin_t)
    p1 = (p_orig[0] + avail_w - margin_r, p_orig[1] + plot_h - margin_b)
    cw, ch = (p1[0] - p0[0]), (p1[1] - p0[1])

    draw_list.add_rect_filled(p0[0], p0[1], p1[0], p1[1], 0x44000000)
    draw_list.add_rect(p0[0], p0[1], p1[0], p1[1], 0xFFAAAAAA)

    r = np.array(res_1d['r']); c_r = np.array(res_1d['c_r'])
    fit_r = np.array(res_1d['fit_r']); fit_y = np.array(res_1d['fit_y'])
    c_inf = res_1d.get('c_inf', 0.0)
    
    if r.size > 0:
        max_r = float(np.max(r)) if np.max(r) > 0 else 1.0
        
        # Plateau dashed line
        py_inf = p1[1] - c_inf * ch
        if p0[1] < py_inf < p1[1]:
            for dx in range(0, int(cw), 10):
                draw_list.add_line(p0[0] + dx, py_inf, p0[0] + dx + 5, py_inf, 0xFFAAAAAA, 1.0)
            draw_list.add_text(p1[0] + 4, py_inf - 7, 0xFFAAAAAA, f"C_inf={c_inf:.2f}")
        
        # Correlation curve (blue)
        pts = [(p0[0] + (r[i]/max_r)*cw, p1[1] - np.clip(c_r[i], 0, 1.0)*ch)
               for i in range(len(r)) if np.isfinite(c_r[i])]
        for i in range(len(pts)-1):
            draw_list.add_line(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1], 0xFF88CCFF, 2.0)
        
        # Fit curve (orange dashed)
        if fit_r.size > 0:
            fpts = [(p0[0] + (fit_r[i]/max_r)*cw, p1[1] - np.clip(fit_y[i], 0, 1.0)*ch)
                    for i in range(len(fit_r)) if np.isfinite(fit_y[i])]
            for i in range(len(fpts)-1):
                if i % 2 == 0:
                    draw_list.add_line(fpts[i][0], fpts[i][1], fpts[i+1][0], fpts[i+1][1], 0xFF88AAFF, 2.0)
        
        draw_list.add_text(p0[0]-40, p0[1], 0xFFFFFFFF, "1.0")
        draw_list.add_text(p0[0]-40, p1[1]-15, 0xFFFFFFFF, "0.0")

        # Decorrelation info
        lam = res_1d.get('lambda', 0)
        fit_ok = res_1d.get('fit_success', False)
        fit_col = 0xFF44FF44 if (fit_ok and lam < 50) else 0xFF4444FF
        draw_list.add_text(p0[0]+5, p0[1]+5, fit_col, f"λ={lam:.2f} A")
        
        imgui.set_cursor_screen_pos((p0[0], p1[1]+5))
        imgui.text_disabled(f"Distance r (A) [0 to {max_r:.1f}]")
    
    imgui.set_cursor_screen_pos((p_orig[0], p_orig[1] + plot_h + 5))


def _draw_2d_lateral_section(soap_results, state):
    """Renders the 2D lateral correlation heatmap and directional cuts.
    
    Expensive upsampling (scipy.ndimage.zoom) and colormap computation are
    cached in state['_heatmap_cache'] and only rebuilt when data/mode/smoothing changes.
    """
    res_2d = soap_results.get('lateral_2d', {})
    if not res_2d:
        imgui.text_colored("No 2D data available.", 1.0, 0.5, 0.5)
        return
    
    imgui.text_colored("2D Lateral Correlation Map C(dx, dy)", 0.8, 0.9, 0.6)

    # Heatmap type selection
    imgui.text("Display:"); imgui.same_line()
    _, state['heatmap_type'] = imgui.combo("##hmt", state['heatmap_type'], ["Raw C(dx,dy)", "Excess C-C_inf", "Counts"])
    
    avail_w, _ = imgui.get_content_region_available()
    map_dim = int(min(avail_w - 80, 300))
    p_orig = imgui.get_cursor_screen_pos()
    imgui.dummy(avail_w, map_dim + 50)
    draw_list = imgui.get_window_draw_list()
    
    p0 = (p_orig[0] + 40, p_orig[1] + 10)
    p1 = (p0[0] + map_dim, p0[1] + map_dim)
    draw_list.add_rect_filled(p0[0], p0[1], p1[0], p1[1], 0xFF0A0A12)
    draw_list.add_rect(p0[0], p0[1], p1[0], p1[1], 0xFF666666)

    # ── Cache key: include display mode, map size, but also NEW smoothing/fill parameters ──
    cache_key = (id(res_2d), state['heatmap_type'], map_dim, state.get('fill_gaps', True), state.get('smoothing', 0.5))
    cache = state.setdefault('_heatmap_cache', {})

    if cache.get('key') != cache_key:
        try:
            if state['heatmap_type'] == 0:
                grid_raw = np.array(res_2d['c_xy'])
            elif state['heatmap_type'] == 1:
                grid_raw = np.array(res_2d['c_xy_excess'])
            else:
                counts_raw = np.array(res_2d['counts_xy'])
                grid_raw = counts_raw / (np.nanmax(counts_raw) + 1e-9)
        except:
            grid_raw = np.zeros((10, 10))

        nan_mask = ~np.isfinite(grid_raw)
        nx, ny = grid_raw.shape

        # ── Bilinear Upsampling & Smoothing ────────────────────────────────────
        scale_x = max(1, map_dim // max(nx, 1))
        scale_y = max(1, map_dim // max(ny, 1))
        
        try:
            from scipy.ndimage import zoom, distance_transform_edt, gaussian_filter
            grid_filled = grid_raw.copy()
            if np.any(nan_mask):
                _, idx = distance_transform_edt(nan_mask, return_indices=True)
                grid_filled = grid_filled[idx[0], idx[1]]
                
            grid_up = zoom(grid_filled, (scale_x, scale_y), order=1)
            
            # Apply Smoothing if requested
            sigma = state.get('smoothing', 0.0)
            if sigma > 0.01:
                # Scale sigma to upsampled resolution
                grid_up = gaussian_filter(grid_up, sigma=sigma * min(scale_x, scale_y))
            
            mask_up = zoom(nan_mask.astype(np.float32), (scale_x, scale_y), order=0) > 0.5
        except ImportError:
            grid_up = np.repeat(np.repeat(np.nan_to_num(grid_raw), scale_x, axis=0), scale_y, axis=1)
            mask_up = np.repeat(np.repeat(nan_mask, scale_x, axis=0), scale_y, axis=1)

        ux, uy = grid_up.shape
        # Adjust clamping to handle potentially slightly blurred edges
        vals = grid_up[~mask_up] if np.any(~mask_up) else np.array([0.0, 1.0])
        vmin = float(np.nanmin(vals)) if vals.size else 0.0
        vmax = float(np.nanmax(vals)) if vals.size else 1.0
        vrange = vmax - vmin if vmax > vmin else 1.0

        # VECTORIZED COLORMAP
        _sr = np.array([68,  59,  33,  94,  253], dtype=np.float32)
        _sg = np.array([1,   82,  145, 201, 231], dtype=np.float32)
        _sb = np.array([84,  139, 140, 98,  37],  dtype=np.float32)
        _st = np.array([0.0, 0.25, 0.5, 0.75, 1.0], dtype=np.float32)

        t_flat = np.clip((grid_up - vmin) / vrange, 0.0, 1.0)
        seg = np.searchsorted(_st, t_flat, side='right').clip(1, 4) - 1
        s   = (t_flat - _st[seg]) / (_st[seg + 1] - _st[seg] + 1e-9)

        r_arr = np.clip(_sr[seg] + s * (_sr[seg+1] - _sr[seg]), 0, 255).astype(np.uint32)
        g_arr = np.clip(_sg[seg] + s * (_sg[seg+1] - _sg[seg]), 0, 255).astype(np.uint32)
        b_arr = np.clip(_sb[seg] + s * (_sb[seg+1] - _sb[seg]), 0, 255).astype(np.uint32)

        color_grid = (0xFF000000 | (b_arr << 16) | (g_arr << 8) | r_arr).astype(np.uint32)
        
        # Gap Filling Logic: mask only if fill_gaps is False
        if not state.get('fill_gaps', True):
            color_grid[mask_up] = 0

        pw = map_dim / max(ux, 1)
        ph = map_dim / max(uy, 1)

        # Build DRAW TUPLES
        draw_tuples = []
        for ix in range(ux):
            bx0_rel = ix * pw
            for iy in range(uy):
                col = int(color_grid[ix, iy])
                if col == 0: continue
                
                # Visual hint for filled gaps: lower alpha if in gap
                final_col = col
                if state.get('fill_gaps', True) and mask_up[ix, iy]:
                    # De-saturate or lower alpha for interpolated regions (optional)
                    # For now just render normally but maybe slightly darker
                    pass
                
                draw_tuples.append((bx0_rel, iy * ph, final_col))

        cb_colors = []
        for ci in range(64):
            t_c = ci / 63.0
            seg_c = min(int(t_c / 0.25), 3)
            s_c = (t_c - seg_c * 0.25) / 0.25
            rc = int(np.clip(_sr[seg_c] + s_c * (_sr[seg_c+1] - _sr[seg_c]), 0, 255))
            gc = int(np.clip(_sg[seg_c] + s_c * (_sg[seg_c+1] - _sg[seg_c]), 0, 255))
            bc = int(np.clip(_sb[seg_c] + s_c * (_sb[seg_c+1] - _sb[seg_c]), 0, 255))
            cb_colors.append(0xFF000000 | (bc << 16) | (gc << 8) | rc)

        cache.update(dict(key=cache_key, draw_tuples=draw_tuples, pw=pw, ph=ph,
                          vmin=vmin, vmax=vmax, cb_colors=cb_colors,
                          nx=nx, ny=ny, grid_raw=grid_raw, mask_up=mask_up))

    pw   = cache['pw'];    ph   = cache['ph']
    vmin = cache['vmin'];  vmax = cache['vmax']
    nx   = cache['nx'];    ny   = cache['ny']
    grid_raw = cache['grid_raw']
    mask_up  = cache['mask_up']
    x_arr = res_2d.get('x', [-1, 1]); y_arr = res_2d.get('y', [-1, 1])

    p0x = p0[0]; p1y = p1[1]
    for bx0_rel, by0_rel, col in cache['draw_tuples']:
        bx0 = p0x + bx0_rel
        by0 = p1y - by0_rel - ph
        draw_list.add_rect_filled(bx0, by0, bx0 + pw + 0.5, by0 + ph + 0.5, col)

    # Crosshair
    mx_c = p0[0] + map_dim / 2; my_c = p0[1] + map_dim / 2
    draw_list.add_line(mx_c, p0[1], mx_c, p1[1], 0x55FFFFFF, 1.0)
    draw_list.add_line(p0[0], my_c, p1[0], my_c, 0x55FFFFFF, 1.0)
    draw_list.add_text(p0[0] + 3, my_c - 14, 0x88FFFFFF, "dy")
    draw_list.add_text(mx_c + 3, p1[1] + 2,  0x88FFFFFF, "dx")

    # Colorbar
    cb_x0 = p1[0] + 6; cb_x1 = cb_x0 + 10; bar_h = map_dim / 64
    for ci, col_bar in enumerate(cache['cb_colors']):
        by = p1[1] - (ci + 1) * bar_h
        draw_list.add_rect_filled(cb_x0, by, cb_x1, by + bar_h + 0.5, col_bar)
    draw_list.add_text(cb_x0 - 2, p0[1] - 14, 0xFFAAAAAA, f"{vmax:.2f}")
    draw_list.add_text(cb_x0 - 2, p1[1] + 2,  0xFFAAAAAA, f"{vmin:.2f}")
    draw_list.add_rect(cb_x0, p0[1], cb_x1, p1[1], 0xFF666666)

    # Axis labels
    if len(x_arr) >= 2:
        draw_list.add_text(p0[0] - 34, p0[1] + 2,  0xFFAAAAAA, f"{y_arr[-1]:.0f}A")
        draw_list.add_text(p0[0] - 34, p1[1] - 14, 0xFFAAAAAA, f"{y_arr[0]:.0f}A")
        draw_list.add_text(p0[0] + 2,  p1[1] + 3,  0xFFAAAAAA, f"{x_arr[0]:.0f}A")
        draw_list.add_text(p1[0] - 30, p1[1] + 3,  0xFFAAAAAA, f"{x_arr[-1]:.0f}A")

    # Hover tooltip
    if imgui.is_mouse_hovering_rect(p0[0], p0[1], p1[0], p1[1]):
        mx, my = imgui.get_mouse_pos()
        ix_raw = int(((mx - p0[0]) / map_dim) * nx)
        iy_raw = int(((p1[1] - my) / map_dim) * ny)
        if 0 <= ix_raw < nx and 0 <= iy_raw < ny:
            val = grid_raw[ix_raw, iy_raw]
            dx_v = x_arr[ix_raw] if ix_raw < len(x_arr) else 0
            dy_v = y_arr[iy_raw] if iy_raw < len(y_arr) else 0
            if np.isfinite(val):
                imgui.set_tooltip(f"dx: {dx_v:.2f} A,  dy: {dy_v:.2f} A\nValue: {val:.4f}")
            elif state.get('fill_gaps', True):
                imgui.set_tooltip(f"dx: {dx_v:.2f} A,  dy: {dy_v:.2f} A\nValue: [Interpolated]")

    imgui.set_cursor_screen_pos((p_orig[0], p_orig[1] + map_dim + 60))


    # Warning if high masking
    diag = soap_results.get('diagnostics', {})
    frac_masked = diag.get('fraction_masked', 0)
    if frac_masked > 0.3:
        imgui.text_colored(f"! {frac_masked*100:.0f}% of bins masked (low occupancy). Increase max distance or reduce dr_2d.", 1.0, 0.6, 0.2)

    # Directional cuts
    if imgui.tree_node("Directional Profiles (X/Y Strip Averages)"):
        _draw_directional_cuts(soap_results.get('directional', {}))
        imgui.tree_pop()


def _draw_directional_cuts(dir_res):
    """Renders strip-averaged C(dx,0) and C(0,dy) profiles."""
    if not dir_res:
        imgui.text_disabled("No directional data.")
        return

    avail_w, _ = imgui.get_content_region_available()
    draw_list = imgui.get_window_draw_list()
    cut_h = 80

    for axis_label, prof_key, c_key, color in [
        ("C(dx, 0) — X-cut", "x_prof", "c_x", 0xFFFFCC88),
        ("C(0, dy) — Y-cut", "y_prof", "c_y", 0xFF88FFCC)
    ]:
        if prof_key not in dir_res or c_key not in dir_res:
            continue
        x_ax = dir_res[prof_key]; c_arr = dir_res[c_key]
        imgui.text_disabled(axis_label)
        p0 = imgui.get_cursor_screen_pos()
        p0 = (p0[0] + 40, p0[1]); p1 = (p0[0] + avail_w - 60, p0[1] + cut_h)
        imgui.dummy(avail_w, cut_h + 5)

        draw_list.add_rect_filled(p0[0], p0[1], p1[0], p1[1], 0x33000000)
        draw_list.add_rect(p0[0], p0[1], p1[0], p1[1], 0x44AAAAAA)

        max_x = max(abs(x_ax[0]), abs(x_ax[-1])) if len(x_ax) >= 2 else 1.0
        cw = p1[0] - p0[0]; ch = p1[1] - p0[1]
        pts = []
        for i in range(len(x_ax)):
            if not np.isfinite(c_arr[i]): continue
            px = p0[0] + ((x_ax[i] + max_x) / (2 * max_x)) * cw
            py = p1[1] - np.clip(c_arr[i], 0, 1.0) * ch
            pts.append((px, py))
        for i in range(len(pts)-1):
            draw_list.add_line(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1], color, 1.5)

        # Zero-axis
        zero_x = p0[0] + 0.5 * cw
        draw_list.add_line(zero_x, p0[1], zero_x, p1[1], 0x33FFFFFF, 1.0)
        imgui.spacing()


def _draw_soap_diagnostics(res):
    """Renders status metrics: decorrelation length, masking stats, etc."""
    res_1d = res.get('radial', {})
    diag = res.get('diagnostics', {})
    
    imgui.begin_group()
    lam = res_1d.get('lambda', 0)
    fit_ok = res_1d.get('fit_success', False)
    imgui.text_colored("DECORRELATION LENGTH:", 1.0, 1.0, 0.4)
    imgui.same_line()
    val_col = (0.4, 1.0, 0.4) if (fit_ok and 0 < lam < 100) else (1.0, 0.4, 0.4)
    imgui.text_colored(f"{lam:.3f} A", *val_col)
    
    c_inf = res_1d.get('c_inf', 0.0)
    fit_A = res_1d.get('fit_A', 0.0)
    imgui.text_disabled(f"Plateau C_inf: {c_inf:.4f}  |  Fit excess A: {fit_A:.3f}")
    
    if diag:
        n_c = diag.get('n_centers', 0); n_p = diag.get('n_pairs', 0)
        fmt = diag.get('fraction_masked', 0) * 100
        imgui.text_disabled(f"Centers: {n_c}  |  Pairs: {n_p}  |  Masked bins: {fmt:.1f}%")
    imgui.end_group()


def _export_soap_csv(res):
    """Exports the 1D radial correlation profile to CSV."""
    res_1d = res.get('radial', {})
    if not res_1d: return
    r = res_1d['r']; c_r = res_1d['c_r']
    ts = int(time.time()); symbol = res.get('params', {}).get('center_symbol', 'X')
    np.savetxt(f"soap_1d_{symbol}_{ts}.csv", np.column_stack((r, c_r)), header="r(A), C(r)", delimiter=",")
    print(f"Exported 1D SOAP profile → soap_1d_{symbol}_{ts}.csv")
