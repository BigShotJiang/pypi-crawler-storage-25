from __future__ import annotations
from typing import Any
import imgui

def draw_playback_controls(viewer: Any):
    """Navigation and time-series management."""
    from .plots import draw_energy_plots
    
    imgui.text(f"Global Time Index:")
    c, viewer.index1 = imgui.drag_int("##idx", viewer.index1, 1, 0, len(viewer.provider)-1)
    if c: viewer._load_frame1(viewer.index1)
    
    btns = [("|<", 0), ("<", viewer.index1-1), (">", viewer.index1+1), (">|", len(viewer.provider)-1)]
    for lbl, val in btns:
        if imgui.button(lbl):
            viewer.index1 = max(0, min(val, len(viewer.provider)-1))
            viewer._load_frame1(viewer.index1)
        imgui.same_line()
        
    play_lbl = "Pause" if viewer.playback_playing else " Play "
    if imgui.button(play_lbl):
        viewer.playback_playing = not viewer.playback_playing
    
    imgui.separator()
    if hasattr(viewer, "all_energies") and viewer.all_energies.size > 0:
         draw_energy_plots(viewer.all_energies, viewer.index1)
