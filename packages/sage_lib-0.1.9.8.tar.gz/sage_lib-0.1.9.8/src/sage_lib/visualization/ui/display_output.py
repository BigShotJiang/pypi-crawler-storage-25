from __future__ import annotations
from typing import Any
import imgui
import time

def draw_output_export_panel(viewer: Any):
    """UI for capturing screenshots and exporting structural data."""
    if imgui.collapsing_header("Output & Export", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
        imgui.text("Capture System:")
        if imgui.button("  Take Screenshot (PNG)  "):
            viewer.save_screenshot()
        
        imgui.separator(); imgui.text("Structure Export:")
        _, viewer.export_prefix = imgui.input_text("Filename Prefix", viewer.export_prefix, 255)
        changed_fmt, viewer.export_fmt_idx = imgui.combo("Format", viewer.export_fmt_idx, viewer.export_formats)
        _, viewer.export_all_frames = imgui.checkbox("Export All Frames", viewer.export_all_frames)
        
        btn_txt = "  Export All Frames  " if viewer.export_all_frames else "  Export Current Structure  "
        imgui.separator(); imgui.text("GIF Trajectory Export:")
        _, viewer.gif_frame_count = imgui.slider_int("Frames", viewer.gif_frame_count, 2, 100)
        _, viewer.gif_random_selection = imgui.checkbox("Random Frame Selection", viewer.gif_random_selection)
        
        if imgui.button("  Export GIF Animation  "):
            viewer.export_gif()
        
        imgui.separator(); imgui.text("Structure Export:")
        imgui.text("Export Path:")
        _, viewer._export_path = imgui.input_text("##fout", viewer._export_path, 256)
        _, viewer.export_selected_only = imgui.checkbox("Selected Atoms Only", viewer.export_selected_only)
        
        if imgui.button("  Export Structure  "):
            viewer.export_current_structure()
        
        if viewer.export_status:
            imgui.text_colored(viewer.export_status, 0.5, 1.0, 0.5)
