from __future__ import annotations
from typing import Any
import imgui

def draw_mutant_engine(viewer: Any):
    """Contextual residue selection grid for protein engineering."""
    imgui.set_next_window_size(260, 350, imgui.FIRST_USE_EVER)
    imgui.begin("Mutation Engine", True)
    
    imgui.text("Selection: Proteomic Context")
    imgui.separator()
    
    # 20 standard amino acids buttons grid
    amino_acids = ["ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE",
                   "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL"]
    
    imgui.columns(4, "aa_grid", False)
    for aa in amino_acids:
        if imgui.button(f"{aa}##btn"):
            viewer._mutate_selection(aa)
        if imgui.is_item_hovered():
            viewer._preview_mutation(aa)
        imgui.next_column()
    imgui.columns(1)
    
    imgui.separator()
    if imgui.button("  Clear Selection / Preview  "):
        viewer.scene.clear_selection()
        viewer._mutation_preview = None
            
    imgui.end()
