from __future__ import annotations
import imgui
import numpy as np
from typing import Any, Dict, List
from ..display.controller import DisplayController
from ..display.layers import DisplayLayer, RepresentationStyle
from ..display.selectors import DisplaySelector, SelectorKind
from ..display.representation_registry import REPRESENTATION_REGISTRY
from .display_named_selections import draw_named_selection_manager
from .display_preset_browser import draw_preset_browser

def draw_layer_editor(viewer: Any, controller: DisplayController):
    """
    Phase 5 Unified Scene Editor: Manages layers, selections, and presets.
    """
    if controller.layer_set is None:
        if imgui.button("Initialize Display System"):
            viewer._mark_dirty(pos=True)
        return

    dirty = False
    
    # --- 1. Scene Presets & IO ---
    if imgui.tree_node("Scene Presets", imgui.TREE_NODE_DEFAULT_OPEN):
        draw_preset_browser(viewer, controller)
        imgui.tree_pop()

    imgui.separator()

    # --- 2. Named Selections ---
    if imgui.tree_node("Selection Manager", imgui.TREE_NODE_DEFAULT_OPEN):
        draw_named_selection_manager(viewer, controller)
        imgui.tree_pop()

    imgui.separator()

    # --- 3. Display Layers ---
    if imgui.tree_node("Display Layers", imgui.TREE_NODE_DEFAULT_OPEN):
        # Filter Bar
        if not hasattr(viewer, "_layer_filter"): viewer._layer_filter = ""
        _, viewer._layer_filter = imgui.input_text("Search", viewer._layer_filter, 32)
        
        imgui.same_line()
        if imgui.button("+ Layer"):
            imgui.open_popup("add_layer_menu")
            
        if imgui.begin_popup("add_layer_menu"):
            if imgui.menu_item("Empty Layer")[0]:
                 new_id = f"layer_{np.random.randint(1000, 9999)}"
                 controller.layer_set.add(DisplayLayer(new_id, "New Layer", DisplaySelector("all_atoms"), RepresentationStyle("ball_and_stick")))
                 dirty = True
            
            if imgui.begin_menu("From Template..."):
                 from ..display.layer_templates import get_builtin_layer_templates, instantiate_template
                 templates = get_builtin_layer_templates()
                 # Optional: filter by system_type
                 for t in templates:
                      if imgui.menu_item(t.label)[0]:
                           controller.layer_set.add(instantiate_template(t.id, viewer.scene, {}))
                           dirty = True
                 imgui.end_menu()
            imgui.end_popup()

        imgui.separator()
        
        layers = controller.layer_set.sorted_items()[::-1]
        filter_q = viewer._layer_filter.lower()
        
        for i, layer in enumerate(layers):
            if filter_q and filter_q not in layer.label.lower(): continue
            
            imgui.push_id(layer.id)
            
            # Row Start
            c_vis, layer.visible = imgui.checkbox(f"##v_{layer.id}", layer.visible)
            imgui.same_line()
            
            if imgui.button("S"): # Solo
                 for l in controller.layer_set.items: l.visible = (l.id == layer.id)
                 dirty = True
            if imgui.is_item_hovered(): imgui.set_tooltip("Solo / Isolate Layer")
            
            imgui.same_line()
            header_label = f"{layer.label} [{layer.style.kind}]"
            expanded, _ = imgui.collapsing_header(header_label, imgui.TREE_NODE_DEFAULT_OPEN if i==0 else 0)
            
            if expanded:
                imgui.indent()
                
                # Label
                _, layer.label = imgui.input_text("Name", layer.label, 64)
                
                # Selector Editor
                imgui.text_colored("Selector", 0.4, 0.7, 1.0)
                kinds: List[SelectorKind] = ["all_atoms", "semantic_group", "named_selection", "expression", "residue_ids", "chain_ids", "element_symbols", "selected_atoms"]
                try: kind_idx = kinds.index(layer.selector.kind)
                except: kind_idx = 0
                
                c_sk, kind_idx = imgui.combo("Target", kind_idx, [k.replace("_", " ").title() for k in kinds])
                if c_sk: 
                    layer.selector.kind = kinds[kind_idx]
                    dirty = True
                
                # Selector Values
                if layer.selector.kind == "semantic_group":
                    groups = ["protein_backbone", "protein_sidechains", "ligands", "solvent", "ions", "framework", "interlayer", "surface_top", "surface_bottom"]
                    try: g_idx = groups.index(str(layer.selector.value))
                    except: g_idx = 0
                    c_g, g_idx = imgui.combo("Group", g_idx, groups)
                    if c_g: layer.selector.value = groups[g_idx]; dirty = True
                elif layer.selector.kind == "named_selection":
                    ns_names = [ns.name for ns in controller.named_selection_set.items]
                    if ns_names:
                        try: n_idx = ns_names.index(str(layer.selector.value))
                        except: n_idx = 0
                        c_n, n_idx = imgui.combo("Selection", n_idx, ns_names)
                        if c_n: 
                             layer.selector.value = controller.named_selection_set.items[n_idx].name
                             dirty = True
                    else:
                        imgui.text_disabled("No named selections defined.")
                elif layer.selector.kind in ["residue_ids", "chain_ids", "element_symbols", "expression"]:
                    c_v, layer.selector.value = imgui.input_text("Query", str(layer.selector.value or ""), 128)
                    if c_v: dirty = True

                # Style Editor
                imgui.separator()
                imgui.text_colored("Style", 0.4, 1.0, 0.7)
                style_kinds = list(REPRESENTATION_REGISTRY.keys())
                try: s_idx = style_kinds.index(layer.style.kind)
                except: s_idx = 0
                c_rk, s_idx = imgui.combo("Mode", s_idx, [REPRESENTATION_REGISTRY[k]["label"] for k in style_kinds])
                if c_rk:
                    layer.style.kind = style_kinds[s_idx]
                    layer.style.params = {k: v["default"] for k, v in REPRESENTATION_REGISTRY[layer.style.kind]["params"].items()}
                    if layer.style.kind == "ribbon": controller.display_state.protein_ribbon_dirty = True
                    dirty = True
                    
                # Style Params (Automated from Registry)
                reg_params = REPRESENTATION_REGISTRY[layer.style.kind]["params"]
                for p_name, p_meta in reg_params.items():
                    val = layer.style.params.get(p_name, p_meta["default"])
                    p_label = p_name.replace("_", " ").title()
                    if p_meta["type"] == "float":
                        cp, val = imgui.slider_float(p_label, val, p_meta["min"], p_meta["max"])
                    elif p_meta["type"] == "int":
                        cp, val = imgui.slider_int(p_label, val, p_meta["min"], p_meta["max"])
                    elif p_meta["type"] == "list":
                        try: l_idx = p_meta["options"].index(val)
                        except: l_idx = 0
                        cp, l_idx = imgui.combo(p_label, l_idx, p_meta["options"])
                        if cp: val = p_meta["options"][l_idx]
                    elif p_meta["type"] == "color":
                        cp, val = imgui.color_edit4(p_label, *val)
                    if cp: 
                        layer.style.params[p_name] = val; dirty = True
                        if layer.style.kind == "ribbon": controller.display_state.protein_ribbon_dirty = True

                c_op, layer.opacity = imgui.slider_float("Opacity", layer.opacity, 0.0, 1.0)
                if c_op: dirty = True
                
                # Actions Footer
                if imgui.button("Duplicate"): controller.layer_set.duplicate(layer.id); dirty = True
                imgui.same_line(); 
                if imgui.button("Delete"): controller.layer_set.remove(layer.id); dirty = True
                imgui.same_line();
                if imgui.button("Move Up"): controller.layer_set.move_down(layer.id); dirty = True
                imgui.same_line();
                if imgui.button("Move Down"): controller.layer_set.move_up(layer.id); dirty = True
                
                imgui.unindent()
            imgui.pop_id()
        imgui.tree_pop()

    imgui.separator()

    # --- 4. Global Display Settings ---
    if imgui.tree_node("Global View Settings"):
        c_as, controller.display_state.atom_scale = imgui.slider_float("Atom Scale", controller.display_state.atom_scale, 0.05, 4.0)
        c_bs, controller.display_state.bond_scale = imgui.slider_float("Bond Scale", controller.display_state.bond_scale, 0.05, 1.0)
        if any([c_as, c_bs]): dirty = True
        imgui.tree_pop()

    if dirty:
        viewer._mark_dirty(pos=True)
