from __future__ import annotations
import imgui
import numpy as np
import time
from typing import Optional

class BuilderPanel:
    """
    ImGui dashboard for the Structural Workshop.
    """
    def __init__(self, visualizer, editor, session):
        self.viz = visualizer
        self.editor = editor
        self.session = session
        
        # UI Caching
        self._frag_cats = []
        self._frag_names = {} # cat -> names
        self._refresh_caches()
        
        # Search & Filter Queries
        self._search_query = ""
        self._atom_search_query = "C"
        
    def _refresh_caches(self):
        self._frag_cats = self.editor.fragments.list_categories()
        self._frag_names = {}
        for c in self._frag_cats:
            self._frag_names[c] = self.editor.fragments.list_fragments(c)

    def draw_contents(self):
        # --- 1. Mode & Global State ---
        imgui.text_disabled("BUILDING MODE:")
        for mode in self.session.MODES:
            if imgui.radio_button(mode, self.session.active_mode == mode):
                self.session.set_mode(mode)
            imgui.same_line()
        imgui.new_line()
        
        if self.session.active_mode == "Molecular":
            imgui.text_disabled("(Bond-centric: Fragments attach to single atoms)")
        elif self.session.active_mode == "Materials":
            imgui.text_disabled("(Site-centric: Fragments attach to 1, 2, or 3-atom sites)")
            
        imgui.spacing()
        imgui.push_style_color(imgui.COLOR_BUTTON, 0.6, 0.15, 0.15, 0.9)
        imgui.push_style_color(imgui.COLOR_BUTTON_HOVERED, 0.8, 0.2, 0.2, 1.0)
        if imgui.button("  CLEAR ALL ATOMS (Start from Scratch)  ", width=-1):
            self.editor.clear_all_atoms()
            self.viz._mark_dirty(pos=True, sel=True)
        imgui.pop_style_color(2)
        
        imgui.separator()
        
        # --- 2. Toolset ---
        imgui.text_disabled("TOOLS:")
        # Render tools as a grid of buttons or a list
        for i, tool in enumerate(self.session.TOOLS):
            is_active = (self.session.active_tool == tool)
            if is_active:
                imgui.push_style_color(imgui.COLOR_BUTTON, 0.3, 0.6, 0.3, 1.0)
            
            if imgui.button(tool, width=100):
                self.session.set_tool(tool)
            
            if is_active: imgui.pop_style_color(1)
            
            # Hover tooltips for tools
            if imgui.is_item_hovered():
                if tool == "Move": imgui.set_tooltip("Grab and translate selected atoms directly with the mouse.")
                elif tool == "Rotate": imgui.set_tooltip("Rotate fragment around anchor (R)")
                elif tool == "Measure": imgui.set_tooltip("Measure distances, angles, and dihedrals by picking atoms.")
                elif tool == "Rotate": imgui.set_tooltip("Rotate fragment around anchor (R)")
                elif tool == "Add Atom": imgui.set_tooltip("Place single atoms (A)")
                elif tool == "Add Group": imgui.set_tooltip("Place molecular fragments (Shift+A)")

            if (i+1) % 4 != 0: imgui.same_line()
            else: imgui.new_line()
        imgui.new_line()
        imgui.separator()
        
        # --- 3. Contextual Tool Settings ---
        self._draw_tool_settings()
        
        # --- 4. Selection Hub ---
        if self.viz.scene.selected_atoms:
            imgui.spacing()
            imgui.text_colored(f"Selection: {len(self.viz.scene.selected_atoms)} atoms", 0.4, 0.8, 1.0)
            if imgui.button("  Delete (Del)  "):
                self.editor.delete_selection()
                self.viz._mark_dirty(pos=True, sel=True)
            imgui.same_line()
            if imgui.button("  Clear (Esc)  "):
                self.viz.scene.clear_selection()
        else:
            imgui.text_disabled("Select atoms to enable edit tools.")
            
        imgui.separator()
        
        # --- 5. Geometric Stabilization ---
        if imgui.collapsing_header("Geometric Optimization", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
            _, self.session.auto_relax = imgui.checkbox("Auto-Relax on Commit", self.session.auto_relax)
            
            imgui.text("Relaxation Mode:")
            for m in ["Rigid", "Flexible"]:
                if imgui.radio_button(m, self.session.relaxation_mode == m):
                    self.session.relaxation_mode = m
                imgui.same_line()
            imgui.new_line()
            
            imgui.text("Relaxation Scope:")
            for s in ["New Group Only", "Local Environment"]:
                is_selected = (self.session.relax_substrate if s == "Local Environment" else not self.session.relax_substrate)
                if imgui.radio_button(s, is_selected):
                    self.session.relax_substrate = (s == "Local Environment")
                imgui.same_line()
            imgui.new_line()
            
            _, self.session.relaxation_steps = imgui.slider_int("Optimizer Steps", self.session.relaxation_steps, 10, 200)
            
            if imgui.button("      RELAX SELECTION NOW      ", width=-1):
                if self.viz.scene.selected_atoms:
                    self.editor.start_progressive_relaxation(
                        self.viz.scene.selected_atoms, 
                        mode=self.session.relaxation_mode, 
                        steps=self.session.relaxation_steps,
                        relax_substrate=self.session.relax_substrate
                    )
            
        imgui.separator()
        
        # --- 6. Validation & History ---
        self._draw_validation_and_history()
        
        # --- 7. Status & Help Bar (Fixed Bottom) ---
        imgui.new_line()
        imgui.separator()
        self._draw_status_bar()
        
        # Contextual Help Overlay (Dynamic) - KEEPING this as overlay for now
        self._draw_contextual_help()

    def _draw_tool_settings(self):
        tool = self.session.active_tool
        
        if tool == "Add Atom":
            imgui.text_colored("Add Single Atom Settings", 0.4, 0.7, 1.0)
            imgui.spacing()
            
            # Quick-Click elements grid
            imgui.text("Quick Select Element:")
            quick_elements = [
                ("H", (0.9, 0.9, 0.9)),
                ("C", (0.5, 0.5, 0.5)),
                ("O", (1.0, 0.3, 0.3)),
                ("N", (0.3, 0.5, 1.0)),
                ("S", (0.9, 0.8, 0.2)),
                ("P", (1.0, 0.6, 0.2)),
                ("Cu", (0.9, 0.6, 0.4)),
                ("Fe", (0.8, 0.5, 0.2)),
                ("Au", (1.0, 0.8, 0.2)),
                ("Si", (0.5, 0.6, 0.7))
            ]
            
            cur_species = getattr(self.session, "selected_atom_species", "C")
            
            for idx, (el, col) in enumerate(quick_elements):
                is_selected = (cur_species == el)
                if is_selected:
                    imgui.push_style_color(imgui.COLOR_BUTTON, *col, 1.0)
                    imgui.push_style_color(imgui.COLOR_TEXT, 0.0, 0.0, 0.0, 1.0)
                else:
                    imgui.push_style_color(imgui.COLOR_BUTTON, col[0]*0.4, col[1]*0.4, col[2]*0.4, 0.7)
                    imgui.push_style_color(imgui.COLOR_TEXT, 1.0, 1.0, 1.0, 1.0)
                
                if imgui.button(f" {el} ", width=45, height=25):
                    self.session.selected_atom_species = el
                    cur_species = el
                    self.viz._mark_dirty(pos=True) # Update preview
                        
                imgui.pop_style_color(2)
                if (idx + 1) % 5 != 0:
                    imgui.same_line()
            imgui.new_line()
            imgui.spacing()
            
            # Search & Custom Species Input Box
            imgui.text("Search / Custom Species:")
            changed_el, new_el = imgui.input_text("##custom_species_in", cur_species, 4)
            if changed_el:
                new_el_clean = new_el.strip()
                if new_el_clean:
                    self.session.selected_atom_species = new_el_clean
                    self.viz._mark_dirty(pos=True)
            
            imgui.spacing()
            imgui.text_disabled("Placement Settings:")
            _, self.session.use_manual_distance = imgui.checkbox("Override Bond Length", self.session.use_manual_distance)
            if self.session.use_manual_distance:
                _, self.session.manual_distance = imgui.slider_float("Distance (A)", self.session.manual_distance, 0.5, 5.0)
                
            imgui.spacing()
            if imgui.button("     COMMIT ATOM (Enter)     ", width=-1):
                self.viz._commit_ghost()

        elif tool == "Add Group":
            # Fragment Browser
            imgui.text_colored("Add Molecular Group / Motif", 0.4, 0.7, 1.0)
            imgui.spacing()
            
            cats = self._frag_cats
            if not cats: return
            
            if not self.session.selected_fragment_category:
                self.session.selected_fragment_category = cats[0]
            
            # 1. Search / Filter bar
            imgui.text("Search Motif:")
            changed_s, self._search_query = imgui.input_text("##motif_search_input", self._search_query, 32)
            
            # 2. Filter elements based on query
            query = self._search_query.strip().lower()
            filtered_frags = []
            
            # If search query is empty, let them use categories
            if not query:
                changed_c, c_idx = imgui.combo("Category", cats.index(self.session.selected_fragment_category), cats)
                if changed_c: 
                    self.session.selected_fragment_category = cats[c_idx]
                    self.session.selected_fragment_name = "" # Reset name for new cat
                
                frags = self._frag_names.get(self.session.selected_fragment_category, [])
                if frags:
                    if not self.session.selected_fragment_name: 
                        self.session.selected_fragment_name = frags[0]
                    changed_f, f_idx = imgui.combo("Fragment Group", frags.index(self.session.selected_fragment_name), frags)
                    if changed_f: 
                        self.session.selected_fragment_name = frags[f_idx]
                        self.viz._mark_dirty(pos=True)
            else:
                # Search across all categories
                for c in cats:
                    for name in self._frag_names.get(c, []):
                        if query in name.lower() or query in c.lower():
                            filtered_frags.append((c, name))
                
                if filtered_frags:
                    # Show matching results as a clean list combo
                    display_names = [f"[{c}] {n}" for c, n in filtered_frags]
                    # Find active index if matches
                    active_match_idx = 0
                    for idx, (c, n) in enumerate(filtered_frags):
                        if c == self.session.selected_fragment_category and n == self.session.selected_fragment_name:
                            active_match_idx = idx
                            break
                            
                    changed_match, match_idx = imgui.combo("Search Results", active_match_idx, display_names)
                    if changed_match or not self.session.selected_fragment_name:
                        c_match, n_match = filtered_frags[match_idx]
                        self.session.selected_fragment_category = c_match
                        self.session.selected_fragment_name = n_match
                        self.viz._mark_dirty(pos=True)
                else:
                    imgui.text_colored("No matching motifs found.", 1.0, 0.4, 0.4)
            
            # --- Draw Premium 2D Structural Miniature Thumbnail ---
            if self.session.selected_fragment_name:
                imgui.spacing()
                imgui.text("Structure Preview:")
                
                # Get canvas screen coordinates
                cursor_pos = imgui.get_cursor_screen_pos()
                canvas_width = 160.0
                canvas_height = 160.0
                
                draw_list = imgui.get_window_draw_list()
                bg_col = imgui.get_color_u32_rgba(0.1, 0.1, 0.13, 1.0)
                border_col = imgui.get_color_u32_rgba(0.4, 0.7, 1.0, 0.4)
                
                # Draw background & border
                draw_list.add_rect_filled(
                    cursor_pos[0], cursor_pos[1], 
                    cursor_pos[0] + canvas_width, cursor_pos[1] + canvas_height, 
                    bg_col, 6.0
                )
                draw_list.add_rect(
                    cursor_pos[0], cursor_pos[1], 
                    cursor_pos[0] + canvas_width, cursor_pos[1] + canvas_height, 
                    border_col, 6.0, 15, 1.5
                )
                
                # Retrieve fragment atomic representation
                frag_data = self.editor.fragments.get_fragment(self.session.selected_fragment_category, self.session.selected_fragment_name)
                if frag_data:
                    elements = frag_data["elements"]
                    pos = np.array(frag_data["pos"], dtype=np.float32)
                    anchor_idx = frag_data.get("anchor_idx", 0)
                    anchor_vector = np.array(frag_data.get("anchor_vector", [1, 0, 0]), dtype=np.float32)
                    
                    # Project atoms centered around the mass center
                    center = np.mean(pos, axis=0) if len(pos) > 1 else pos[0]
                    shifted_pos = pos - center
                    
                    max_val = np.max(np.abs(shifted_pos))
                    scale = (canvas_width * 0.35) / max(0.1, max_val)
                    
                    center_x = cursor_pos[0] + canvas_width / 2.0
                    center_y = cursor_pos[1] + canvas_height / 2.0
                    
                    # 1. Render chemical bonds
                    for i in range(len(pos)):
                        for j in range(i + 1, len(pos)):
                            dist = np.linalg.norm(pos[i] - pos[j])
                            if dist < 1.85:
                                x1 = center_x + shifted_pos[i, 0] * scale
                                y1 = center_y - shifted_pos[i, 1] * scale
                                x2 = center_x + shifted_pos[j, 0] * scale
                                y2 = center_y - shifted_pos[j, 1] * scale
                                draw_list.add_line(x1, y1, x2, y2, imgui.get_color_u32_rgba(0.4, 0.4, 0.4, 0.8), 2.0)
                    
                    # 2. Draw attachment vector line
                    ax = center_x + shifted_pos[anchor_idx, 0] * scale
                    ay = center_y - shifted_pos[anchor_idx, 1] * scale
                    vx = ax + anchor_vector[0] * (canvas_width * 0.2)
                    vy = ay - anchor_vector[1] * (canvas_width * 0.2)
                    draw_list.add_line(ax, ay, vx, vy, imgui.get_color_u32_rgba(1.0, 0.8, 0.2, 0.7), 2.0)
                    draw_list.add_circle_filled(vx, vy, 3.5, imgui.get_color_u32_rgba(1.0, 0.8, 0.2, 1.0))
                    
                    # 3. Draw atom nodes
                    for idx, (el, p) in enumerate(zip(elements, shifted_pos)):
                        px = center_x + p[0] * scale
                        py = center_y - p[1] * scale
                        
                        if el == "H":
                            c_rgb = (0.85, 0.85, 0.85)
                            r = 5.5
                        elif el == "C":
                            c_rgb = (0.3, 0.3, 0.3)
                            r = 8.5
                        elif el == "O":
                            c_rgb = (0.95, 0.25, 0.25)
                            r = 8.0
                        elif el == "N":
                            c_rgb = (0.25, 0.45, 0.95)
                            r = 8.0
                        elif el == "S":
                            c_rgb = (0.85, 0.75, 0.15)
                            r = 9.5
                        else:
                            c_rgb = (0.2, 0.75, 0.35)
                            r = 9.0
                            
                        # Stroke outline
                        draw_list.add_circle_filled(px, py, r + 1.0, imgui.get_color_u32_rgba(0.0, 0.0, 0.0, 0.95))
                        # Core node
                        draw_list.add_circle_filled(px, py, r, imgui.get_color_u32_rgba(*c_rgb, 1.0))
                        
                        # Glowing ring for anchor
                        if idx == anchor_idx:
                            draw_list.add_circle(px, py, r + 2.5, imgui.get_color_u32_rgba(1.0, 0.8, 0.2, 1.0), 0, 1.8)
                
                # Advance cursor past the canvas
                imgui.dummy(canvas_width, canvas_height)
            
            imgui.spacing()
            imgui.text_disabled("Placement Settings:")
            _, self.session.use_manual_distance = imgui.checkbox("Override Bond Length", self.session.use_manual_distance)
            if self.session.use_manual_distance:
                _, self.session.manual_distance = imgui.slider_float("Distance (A)", self.session.manual_distance, 0.5, 5.0)
            
            _, self.session.roll_angle = imgui.slider_float("Roll Angle (deg)", self.session.roll_angle, -180.0, 180.0)
            
            # Quick rotation increment buttons
            imgui.text("Rotate Quick Steps:")
            rotations = [("-90", -90.0), ("-45", -45.0), ("-15", -15.0), ("+15", 15.0), ("+45", 45.0), ("+90", 90.0)]
            for r_idx, (r_name, r_val) in enumerate(rotations):
                if imgui.button(r_name, width=45):
                    new_angle = self.session.roll_angle + r_val
                    if new_angle > 180.0: new_angle -= 360.0
                    if new_angle < -180.0: new_angle += 360.0
                    self.session.roll_angle = float(new_angle)
                    self.viz._mark_dirty(pos=True)
                if r_idx < len(rotations) - 1:
                    imgui.same_line()
            imgui.new_line()
            
            imgui.spacing()
            if imgui.button("     COMMIT FRAGMENT (Enter)     ", width=-1):
                self.viz._commit_ghost()

        elif tool == "Change Type":
            imgui.text("Change Element:")
            if not hasattr(self, "_edit_el"): self._edit_el = "C"
            _, self._edit_el = imgui.input_text("New Species", self._edit_el, 3)
            if imgui.button("Apply Transformation"):
                self.editor.change_selection_species(self._edit_el.strip())
                self.viz._mark_dirty(pos=True)

        elif tool == "Measure":
            imgui.text("Geometric Analysis:")
            imgui.text_disabled("Click atoms in the viewport to measure.")
            imgui.spacing()
            if imgui.button("Reset Measurement List", width=-1):
                self.viz.measured_indices = []
            
            if self.viz.measured_indices:
                imgui.text_colored(f"Selected: {len(self.viz.measured_indices)} atoms", 0.4, 0.8, 1.0)

    def _draw_validation_and_history(self):
        # Validation Reports (Uses debounced report from editor)
        report = self.editor.last_report
        if report["errors"]:
            imgui.push_style_color(imgui.COLOR_TEXT, 1.0, 0.3, 0.3, 1.0)
            imgui.text(f"!!! CRITICAL: {len(report['errors'])} Clashes Detected")
            imgui.pop_style_color(1)
            if imgui.is_item_hovered():
                imgui.set_tooltip("\n".join(report["errors"][:5]))
        elif report["warnings"]:
            imgui.text_colored(f"Warning: {len(report['warnings'])} structural anomalies", 0.9, 0.9, 0.3)
        else:
            imgui.text_colored("Structure Valid", 0.3, 1.0, 0.3)
            
        imgui.separator()
        
        # History
        if imgui.button("  Undo (Ctrl+Z)  "):
            self.editor.undo()
            self.viz._mark_dirty(pos=True, sel=True)
        imgui.same_line()
        if imgui.button("  Redo (Ctrl+Y)  "):
            self.editor.redo()
            self.viz._mark_dirty(pos=True, sel=True)
        
        imgui.text_disabled(f"History: {len(self.editor.history)} commands | Redo: {len(self.editor.redo_stack)}")

    def _draw_status_bar(self):
        S = self.session
        from ..builder.session import InteractionState
        
        # 1. Tool Status
        imgui.text_colored(f"Tool: {S.active_tool}", 1.0, 1.0, 1.0)
        imgui.same_line(spacing=20)
        
        # 2. Safety Status
        if S.ghost_pos is not None:
            if S.ghost_clash:
                imgui.text_colored("CLASH DETECTED", 1.0, 0.3, 0.3)
            else:
                imgui.text_colored("SAFETY: OK", 0.3, 1.0, 0.3)
        else:
            imgui.text_disabled("IDLE")

    def _draw_contextual_help(self):
        from ..builder.session import InteractionState
        S = self.session
        
        if S.ghost_pos is None and not self.viz.scene.selected_atoms:
            return
            
        # Draw a small semi-transparent overlay in the corner of the view
        imgui.set_next_window_position(20, 20, imgui.ALWAYS)
        imgui.begin("Workshop Controls", False, imgui.WINDOW_NO_TITLE_BAR | imgui.WINDOW_NO_RESIZE | imgui.WINDOW_ALWAYS_AUTO_RESIZE | imgui.WINDOW_NO_MOVE)
        imgui.set_window_font_scale(0.9)
        
        imgui.text_colored("CONTROLS:", 0.4, 0.8, 1.0)
        
        if S.ghost_pos is not None:
            imgui.text("- LMB Drag: Translate Fragment")
            imgui.text("- Shift + LMB: Adjust Depth")
            imgui.text("- RMB Drag: Rotate Around Anchor")
            imgui.text("- Enter: Commit Change")
        elif self.viz.scene.selected_atoms:
            imgui.text("- M + LMB Drag: Move selection")
            imgui.text("- R + LMB Drag: Rotate selection (COM)")
            imgui.text("- G: Center Camera on Selection")
        elif S.active_tool == "Measure":
            imgui.text("- LMB: Pick 2, 3, or 4 atoms to measure")
            imgui.text("- Distance (2), Angle (3), Dihedral (4)")
        else:
            imgui.text("- M: Hold to Move selection")
            imgui.text("- R: Hold to Rotate selection")
            imgui.text("- A / Shift+A: Add Atom / Group")
            imgui.text("- Del: Delete Selection")
            imgui.text("- Ctrl+Z / Y: Undo / Redo")
            
        imgui.text("- Esc: Clear Selection / Measurements")
            
        imgui.end()
