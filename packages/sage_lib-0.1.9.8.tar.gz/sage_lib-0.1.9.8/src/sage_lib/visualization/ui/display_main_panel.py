from __future__ import annotations
from typing import Any
import imgui
import numpy as np
from .display_playback import draw_playback_controls
from .display_analysis_hub import draw_analysis_hub

def draw_main_control_panel(viewer: Any):
    """Primary sidebar for structural overview and global settings."""
    imgui.set_next_window_size(320, 700, imgui.FIRST_USE_EVER)
    imgui.begin("SAGE Controller", True)
    
    if imgui.collapsing_header("Structural Overview", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
         imgui.text(f"Atoms: {viewer.scene.N} | Replicas: {np.prod(viewer.scene.replicas)}")
         imgui.text(f"Composition: {viewer.scene.composition_str}")
    
    if imgui.collapsing_header("Interactive Playback", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
         draw_playback_controls(viewer)
         
    if imgui.collapsing_header("Global Visual Constants", imgui.TREE_NODE_DEFAULT_OPEN)[0]:
         _, viewer.display.atom_scale = imgui.slider_float("Global Scale", viewer.display.atom_scale, 0.1, 5.0)
         changed_c, viewer.bg_color = imgui.color_edit3("Background Color", *viewer.bg_color)
         imgui.separator()
         
         _, viewer.quality.pretty_render = imgui.checkbox("Pretty View (SSAO/Shadows)", viewer.quality.pretty_render)
         if viewer.quality.pretty_render:
             imgui.indent()
             _, viewer.materials['exposure']  = imgui.slider_float("Exposure",  viewer.materials.get('exposure', 1.5), 0.1, 4.0)
             _, viewer.materials['headlight'] = imgui.slider_float("Headlight", viewer.materials.get('headlight', 0.8), 0.0, 2.0)
             _, viewer.materials['shadow_intensity'] = imgui.slider_float("Shadows", viewer.materials.get('shadow_intensity', 0.6), 0.0, 1.0)
             imgui.unindent()
             
         imgui.same_line()
         _, viewer.display.show_shadows = imgui.checkbox("Bonds Shadows", viewer.display.show_shadows)
         
    if imgui.collapsing_header("Analysis & Electronics")[0]:
         draw_analysis_hub(viewer)
         
    imgui.end()
