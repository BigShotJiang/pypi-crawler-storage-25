from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import numpy as np

from .selectors import DisplaySelector

@dataclass
class NamedSelection:
    id: str
    name: str
    selector: DisplaySelector
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "selector": self.selector.to_dict(),
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, d: dict) -> NamedSelection:
        return cls(
            id=d["id"],
            name=d["name"],
            selector=DisplaySelector.from_dict(d["selector"]),
            metadata=d.get("metadata", {})
        )

@dataclass
class NamedSelectionSet:
    items: List[NamedSelection] = field(default_factory=list)

    def get(self, selection_id: str) -> Optional[NamedSelection]:
        for item in self.items:
            if item.id == selection_id:
                return item
        return None

    def get_by_name(self, name: str) -> Optional[NamedSelection]:
        for item in self.items:
            if item.name == name:
                return item
        return None

    def add(self, selection: NamedSelection):
        self.items.append(selection)

    def remove(self, selection_id: str):
        self.items = [x for x in self.items if x.id != selection_id]

    def rename(self, selection_id: str, new_name: str):
        item = self.get(selection_id)
        if item is not None:
            item.name = new_name

    def to_dict(self) -> dict:
        return {"items": [i.to_dict() for i in self.items]}

    @classmethod
    def from_dict(cls, d: dict) -> NamedSelectionSet:
        return cls(items=[NamedSelection.from_dict(i) for i in d.get("items", [])])
