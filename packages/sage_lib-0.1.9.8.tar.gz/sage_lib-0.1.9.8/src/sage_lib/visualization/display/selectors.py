from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, Literal, List, Optional
import numpy as np

SelectorKind = Literal[
    "all_atoms",
    "semantic_group",
    "selected_atoms",
    "atom_indices",
    "residue_ids",
    "chain_ids",
    "element_symbols",
    "named_selection",
    "expression",
    "custom_mask",
]

@dataclass
class DisplaySelector:
    kind: SelectorKind
    value: Any = None
    params: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"kind": self.kind, "value": self.value, "params": self.params}

    @classmethod
    def from_dict(cls, d: dict) -> DisplaySelector:
        return cls(kind=d["kind"], value=d.get("value"), params=d.get("params", {}))

def resolve_selector(scene, semantic_groups: Dict[str, np.ndarray], selector: DisplaySelector, named_selection_set: Any = None) -> np.ndarray:
    """Resolves a DisplaySelector into an array of atomic indices for the given scene."""
    
    # --- 1. Basic Selections ---
    if selector.kind == "all_atoms":
        return np.arange(scene.N, dtype=np.uint32)
    
    elif selector.kind == "selected_atoms":
        if hasattr(scene, 'selected_atoms') and scene.selected_atoms:
            return np.array(list(scene.selected_atoms), dtype=np.uint32)
        return np.zeros(0, dtype=np.uint32)
    
    elif selector.kind == "atom_indices":
        if isinstance(selector.value, (list, np.ndarray)):
            return np.array(selector.value, dtype=np.uint32)
        return np.zeros(0, dtype=np.uint32)

    # --- 2. Semantic Groups (Phases 1-4) ---
    elif selector.kind == "semantic_group":
        group_name = str(selector.value)
        # Use .get with empty array default if semantic_groups is a dict or SemanticGroups object
        if hasattr(semantic_groups, "get"):
            return semantic_groups.get(group_name, np.zeros(0, dtype=np.uint32)).astype(np.uint32)
        return semantic_groups.get(group_name, np.zeros(0, dtype=np.uint32)).astype(np.uint32)

    # --- 3. Named Selections (Sprint 5.1) ---
    elif selector.kind == "named_selection":
        if named_selection_set is None: return np.zeros(0, dtype=np.uint32)
        # Search by id or name
        sel = named_selection_set.get(str(selector.value))
        if not sel: sel = named_selection_set.get_by_name(str(selector.value))
        if not sel: return np.zeros(0, dtype=np.uint32)
        # Recursive resolution (careful with cycles!)
        # We limit recursion or just hope for no cycles for now
        return resolve_selector(scene, semantic_groups, sel.selector, named_selection_set)

    # --- 4. Biomolecular & Chemical Metadata (Sprint 5.2) ---
    def parse_values(v):
        if v is None: return []
        if isinstance(v, (list, np.ndarray)): return v
        if isinstance(v, (int, float)): return [v]
        if isinstance(v, str):
            if "," in v: return [s.strip() for s in v.split(",")]
            return [v.strip()]
        return []

    if selector.kind == "element_symbols":
        symbols = [str(s).upper() for s in parse_values(selector.value)]
        if not symbols or not hasattr(scene, 'elements'): return np.zeros(0, dtype=np.uint32)
        elements = np.array([str(e).upper() for e in scene.elements])
        indices = []
        for sym in symbols:
            indices.append(np.where(elements == sym)[0])
        if not indices: return np.zeros(0, dtype=np.uint32)
        return np.unique(np.concatenate(indices)).astype(np.uint32)
    
    elif selector.kind == "residue_ids":
        res_ids = [int(r) for r in parse_values(selector.value) if str(r).isdigit()]
        if not res_ids or not hasattr(scene, 'info') or 'res_id' not in scene.info: 
            return np.zeros(0, dtype=np.uint32)
        scene_res_ids = np.array(scene.info['res_id'], dtype=np.int32)
        indices = []
        for rid in res_ids:
            indices.append(np.where(scene_res_ids == rid)[0])
        if not indices: return np.zeros(0, dtype=np.uint32)
        return np.unique(np.concatenate(indices)).astype(np.uint32)
        
    elif selector.kind == "chain_ids":
        chain_ids = [str(c).strip().upper() for c in parse_values(selector.value)]
        if not chain_ids or not hasattr(scene, 'info'):
             return np.zeros(0, dtype=np.uint32)
        # Check both 'chain' (string) and 'chain_index' (int converted to string for comparison)
        indices = []
        if 'chain' in scene.info:
            scene_chains = np.array([str(c).strip().upper() for c in scene.info['chain']])
            for cid in chain_ids:
                indices.append(np.where(scene_chains == cid)[0])
        if 'chain_index' in scene.info:
            scene_chain_indices = np.array(scene.info['chain_index'])
            for cid in chain_ids:
                if cid.isdigit():
                    indices.append(np.where(scene_chain_indices == int(cid))[0])
        if not indices: return np.zeros(0, dtype=np.uint32)
        return np.unique(np.concatenate(indices)).astype(np.uint32)
    
    # --- 5. Expression Language (Sprint 5.3) ---
    elif selector.kind == "expression":
        from .selector_language import resolve_expression_selector
        return resolve_expression_selector(scene, semantic_groups, str(selector.value), named_selection_set)

    return np.zeros(0, dtype=np.uint32)
