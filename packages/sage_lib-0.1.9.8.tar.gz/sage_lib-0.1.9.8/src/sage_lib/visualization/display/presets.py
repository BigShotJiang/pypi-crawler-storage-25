from __future__ import annotations
from typing import Dict, List, Any
import numpy as np
from .representations import RepresentationInstance, RepresentationStyle
from .representation_set import RepresentationSet
from .semantic_groups import SemanticGroups
from .system_classification import classify_system

def build_default_representations(
    scene: Any, 
    semantic_groups: SemanticGroups, 
    context: Dict[str, Any]
) -> RepresentationSet:
    """
    Constructs a default set of visual representations based on the detected system kind.
    Replaces the legacy component-rules with explicit representation instances.
    """
    kind = classify_system(scene)
    reps = []
    
    # Context bridge for legacy UI flags
    protein_atom_mode = context.get("protein_atom_mode", 0)
    protein_alpha = context.get("protein_alpha", 1.0)
    
    if kind == "protein":
        # 1. Backbone (Ribbon by default)
        rep_bb = RepresentationInstance(
            id="backbone", label="Backbone", group_name="protein_backbone",
            order=10, style=RepresentationStyle("ribbon", {"width": 1.6, "thickness": 0.3})
        )
        if protein_atom_mode in [1, 2, 3]: # Hide Backbone modes 
            rep_bb.visible = False
        reps.append(rep_bb)
        
        # 2. Sidechains (Sticks by default)
        rep_sc = RepresentationInstance(
            id="sidechains", label="Side Chains", group_name="protein_sidechains",
            order=20, opacity=protein_alpha, 
            style=RepresentationStyle("sticks", {"bond_radius": 0.18, "atom_radius_scale": 0.22})
        )
        if protein_atom_mode == 2: # Hide Sidechains as well
            rep_sc.visible = False
        reps.append(rep_sc)
        
        # 3. Active site focus
        if semantic_groups.has("active_site"):
            reps.append(RepresentationInstance(
                id="active_site", label="Active Site", group_name="active_site",
                order=50, opacity=protein_alpha, 
                style=RepresentationStyle("ball_and_stick", {"bond_radius": 0.22, "atom_radius_scale": 0.35})
            ))
            
    elif kind == "layered_material" or kind == "periodic_material":
        # 1. Structural Framework
        reps.append(RepresentationInstance(
            id="framework", label="Framework", group_name="framework",
            order=10, style=RepresentationStyle("sticks", {"bond_radius": 0.16, "atom_radius_scale": 0.18})
        ))
        
        # 2. Interlayer guests
        if semantic_groups.has("interlayer"):
            reps.append(RepresentationInstance(
                id="interlayer", label="Interlayer", group_name="interlayer",
                order=20, style=RepresentationStyle("spheres", {"radius_scale": 1.0})
            ))
            
        # 3. Dopants / Defects
        if semantic_groups.has("dopants"):
            reps.append(RepresentationInstance(
                id="dopants", label="Dopants", group_name="dopants",
                order=30, style=RepresentationStyle("ball_and_stick", {"bond_radius": 0.2, "atom_radius_scale": 0.3})
            ))
            
    elif kind == "molecule":
        reps.append(RepresentationInstance(
            id="main_mol", label="Molecule", group_name="all_atoms",
            order=10, style=RepresentationStyle("ball_and_stick", {"bond_radius": 0.18, "atom_radius_scale": 0.25})
        ))
        
    else: # Generic system
        reps.append(RepresentationInstance(
            id="all_atoms", label="All Atoms", group_name="all_atoms",
            order=10, style=RepresentationStyle("spheres", {"radius_scale": 1.0})
        ))
        
    # Extra common subsets
    if semantic_groups.has("ligands") and kind != "molecule":
        reps.append(RepresentationInstance(
            id="ligands", label="Ligands", group_name="ligands",
            order=40, style=RepresentationStyle("ball_and_stick", {"bond_radius": 0.18, "atom_radius_scale": 0.3})
        ))
        
    if semantic_groups.has("solvent"):
        reps.append(RepresentationInstance(
            id="solvent", label="Solvent", group_name="solvent",
            order=100, visible=False, style=RepresentationStyle("spheres", {"radius_scale": 0.8})
        ))

    return RepresentationSet(items=reps)
