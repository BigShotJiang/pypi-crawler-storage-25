from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import json
import os

from .layer_set import DisplayLayerSet
from .named_selections import NamedSelectionSet

def camera_to_dict(cam: Any) -> dict:
    """Serializes OrbitCamera state."""
    return {
        "center": cam.center.tolist(),
        "offset": cam.offset.tolist(),
        "pan": cam.pan.tolist(),
        "up": cam.up.tolist(),
        "fov": cam.fov,
        "ortho_scale": cam.ortho_scale,
        "near": cam.near,
        "far": cam.far,
    }

def camera_from_dict(cam: Any, d: dict):
    """Restores OrbitCamera state."""
    if not d: return
    cam.center = np.array(d["center"], dtype=np.float32)
    cam.offset = np.array(d["offset"], dtype=np.float32)
    cam.pan = np.array(d["pan"], dtype=np.float32)
    cam.up = np.array(d.get("up", [0, 0, 1]), dtype=np.float32)
    cam.fov = d.get("fov", 45.0)
    cam.ortho_scale = d.get("ortho_scale", 20.0)
    cam.near = d.get("near", 0.1)
    cam.far = d.get("far", 5000.0)

@dataclass
class DisplayScenePreset:
    name: str = "Default Scene"
    system_type: str = "generic"
    display_state: Dict[str, Any] = field(default_factory=dict)
    named_selections: Dict[str, Any] = field(default_factory=dict)
    layers: Dict[str, Any] = field(default_factory=dict)
    viewport1: Dict[str, Any] = field(default_factory=dict)
    viewport2: Dict[str, Any] = field(default_factory=dict)
    layout: str = "single"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "system_type": self.system_type,
            "display_state": self.display_state,
            "named_selections": self.named_selections,
            "layers": self.layers,
            "viewport1": self.viewport1,
            "viewport2": self.viewport2,
            "layout": self.layout,
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, d: dict) -> DisplayScenePreset:
        return cls(
            name=d.get("name", "Untitled"),
            system_type=d.get("system_type", "generic"),
            display_state=d.get("display_state", {}),
            named_selections=d.get("named_selections", {}),
            layers=d.get("layers", {}),
            viewport1=d.get("viewport1", {}),
            viewport2=d.get("viewport2", {}),
            layout=d.get("layout", "single"),
            metadata=d.get("metadata", {})
        )

def build_scene_preset(viewer: Any, controller, name: str = "") -> DisplayScenePreset:
    """Extracts the entire visual context including layers and cameras (Phase 5)."""
    ds_dict = {
        "atom_scale": controller.display_state.atom_scale,
        "bond_scale": controller.display_state.bond_scale,
        "show_bonds": controller.display_state.show_bonds,
        "bg_color": list(controller.display_state.bg_color),
    }
    
    vp1 = camera_to_dict(viewer.cam1) if hasattr(viewer, "cam1") else {}
    vp2 = camera_to_dict(viewer.cam2) if hasattr(viewer, "cam2") else {}
    
    return DisplayScenePreset(
        name=name or f"Preset_{controller.system_type}",
        system_type=controller.system_type,
        display_state=ds_dict,
        named_selections=controller.named_selection_set.to_dict(),
        layers=controller.layer_set.to_dict(),
        viewport1=vp1,
        viewport2=vp2,
        layout=getattr(viewer, "view_layout", "single")
    )

def apply_scene_preset(viewer: Any, controller, preset: DisplayScenePreset):
    """Restores a preset into the viewer and controller."""
    # 1. Base display state
    ds = preset.display_state
    if "atom_scale" in ds: controller.display_state.atom_scale = ds["atom_scale"]
    if "bond_scale" in ds: controller.display_state.bond_scale = ds["bond_scale"]
    if "show_bonds" in ds: controller.display_state.show_bonds = ds["show_bonds"]
    if "bg_color" in ds: controller.display_state.bg_color = tuple(ds["bg_color"])
    
    # 2. Selections & Layers
    controller.named_selection_set = NamedSelectionSet.from_dict(preset.named_selections)
    controller.layer_set = DisplayLayerSet.from_dict(preset.layers)
    controller.system_type = preset.system_type
    
    # 3. Viewport & Layout
    if hasattr(viewer, "cam1"): camera_from_dict(viewer.cam1, preset.viewport1)
    if hasattr(viewer, "cam2"): camera_from_dict(viewer.cam2, preset.viewport2)
    if hasattr(viewer, "view_layout"): viewer.view_layout = preset.layout

def save_scene_preset_json(path: str, preset: DisplayScenePreset):
    with open(path, "w") as f:
        json.dump(preset.to_dict(), f, indent=2)

def load_scene_preset_json(path: str) -> DisplayScenePreset:
    if not os.path.exists(path):
        raise FileNotFoundError(f"No preset at {path}")
    with open(path, "r") as f:
        return DisplayScenePreset.from_dict(json.load(f))
