from __future__ import annotations
import numpy as np
from typing import Set, Dict, Any, Optional
from ..display.state import DisplayState

# Professional protein definitions including common variants and modified AAs
AMINO_ACIDS: Set[str] = {
    "ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE", "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL", "SEC", "PYL",
    "HSD", "HSE", "HSP", "MSE", "CYX", "CYS2", "HID", "HIE", "HIP", "GLUP", "ASPP", "LYSN"
}

def apply_protein_visibility(
    scene_info: Dict[str, Any], 
    colors: np.ndarray, 
    radii: np.ndarray, 
    display: DisplayState,
    mutation_preview: Optional[Dict[str, Any]] = None
) -> None:
    """Modifies colors and radii in-place based on protein visibility rules."""
    if not scene_info or 'name' not in scene_info:
        return

    from ..analysis.protein_geometry import BACKBONE_ATOMS
    
    atom_names = scene_info['name']
    res_names = scene_info.get('res_name', [])
    res_seqs = scene_info.get('res_id', [])
    
    # Parse Active Site IDs
    active_ids = set()
    if display.protein_atom_mode == 3: # Active Site Focus
        for x in display.active_site_str.split(','):
            x = x.strip()
            if x.isdigit(): active_ids.add(int(x))
    
    for i, name in enumerate(atom_names):
        res = str(res_names[i]).strip().upper() if i < len(res_names) else ""
        if res not in AMINO_ACIDS:
            continue
            
        seq = int(res_seqs[i]) if i < len(res_seqs) else -1
        is_backbone = str(name).strip().upper() in BACKBONE_ATOMS
        
        if display.protein_atom_mode == 0: # Show All
            if colors.shape[1] > 3:
                colors[i, 3] *= display.protein_alpha # Master Alpha synergy
        elif display.protein_atom_mode == 1: # Hide Backbone (Radii=0)
            if is_backbone: 
                radii[i] = 0.0
                if colors.shape[1] > 3: colors[i, 3] = 0.0
            else:
                if colors.shape[1] > 3: colors[i, 3] *= display.protein_alpha
        elif display.protein_atom_mode == 2: # Hide All Protein
            radii[i] = 0.0
            if colors.shape[1] > 3: colors[i, 3] = 0.0
        elif display.protein_atom_mode == 3: # Active Site Focus
            if seq not in active_ids: 
                radii[i] = 0.0
                if colors.shape[1] > 3: colors[i, 3] = 0.0
            else:
                if colors.shape[1] > 3: colors[i, 3] *= display.protein_alpha
        elif display.protein_atom_mode == 4: # Ball and Stick
            radii[i] = radii[i] * 0.25 # Shrink spheres
            if colors.shape[1] > 3: colors[i, 3] *= display.protein_alpha

    # Hide original sidechain during preview
    if mutation_preview and mutation_preview.get("indices_to_hide"):
        for idx in mutation_preview["indices_to_hide"]:
            if idx < len(radii):
                radii[idx] = 0.0
                if colors.shape[1] > 3: colors[idx, 3] = 0.0
