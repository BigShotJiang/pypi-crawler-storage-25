from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, List
from .layers import DisplayLayer, RepresentationStyle
from .selectors import DisplaySelector

@dataclass
class LayerTemplate:
    id: str
    label: str
    description: str
    system_types: List[str]
    layer_factory_params: Dict[str, Any] = field(default_factory=dict)

def get_builtin_layer_templates() -> List[LayerTemplate]:
    return [
        # --- Proteins ---
        LayerTemplate("prot_ribbon", "Protein: Ribbon (Backbone)", "Ribbon for protein backbone", ["protein"]),
        LayerTemplate("prot_sticks", "Protein: Sidechains (Sticks)", "Sticks for protein sidechains", ["protein"]),
        LayerTemplate("prot_ligand", "Protein: Ligand (B&S)", "Ball & Stick for non-protein ligands", ["protein"]),
        LayerTemplate("prot_active", "Protein: Active Site (Spheres)", "Large spheres for the active site", ["protein"]),
        LayerTemplate("prot_solv_hide", "Protein: Hide Solvent", "Hide all solvent molecules", ["protein"]),
        
        # --- Materials ---
        LayerTemplate("mat_framework", "Material: Framework (Sticks)", "Lattice structure sticks", ["material", "layered_material"]),
        LayerTemplate("mat_interlayer", "Material: Interlayer (Spheres)", "Spheres for interlayer ions/solvent", ["layered_material"]),
        LayerTemplate("mat_dopant", "Material: Dopants (Spheres)", "Highlight dopant species", ["material"]),
        LayerTemplate("mat_adsorb", "Material: Adsorbates (B&S)", "Molecules on the surface", ["material"]),
        
        # --- Generic Molecules ---
        LayerTemplate("mol_all", "Molecule: All Atoms (B&S)", "Standard Ball & Stick", ["molecule", "generic"]),
        LayerTemplate("mol_hydro_hide", "Molecule: Hide Hydrogens", "Remove hydrogens from view", ["molecule"]),
        LayerTemplate("mol_hetero", "Molecule: Heteroatoms (Spheres)", "Large spheres for non-carbon atoms", ["molecule"]),
        LayerTemplate("mol_selected", "Molecule: Highlight Selection", "Sticks for current selection", ["molecule", "generic"]),
    ]

def instantiate_template(template_id: str, scene: Any, semantic_groups: Any) -> DisplayLayer:
    """Factory to turn a template into a living layer for the current system."""
    
    # 1. PROTEINS
    if template_id == "prot_ribbon":
        return DisplayLayer("backbone", "Backbone Ribbon", DisplaySelector("semantic_group", "protein_backbone"), 
                           RepresentationStyle("ribbon"), order=10)
    elif template_id == "prot_sticks":
        return DisplayLayer("sidechains", "Sidechains Sticks", DisplaySelector("semantic_group", "protein_sidechains"), 
                           RepresentationStyle("sticks", {"bond_radius": 0.15, "atom_radii_scale": 0.2}), order=20)
    elif template_id == "prot_ligand":
        return DisplayLayer("ligands", "Ligand Ball-Stick", DisplaySelector("semantic_group", "ligands"), 
                           RepresentationStyle("ball_and_stick"), order=30)
    elif template_id == "prot_active":
        return DisplayLayer("active_site", "Active Site spheres", DisplaySelector("semantic_group", "active_site"), 
                           RepresentationStyle("spheres", {"radius_scale": 0.4}), color_override=[1, 0, 0, 1], order=40)
    elif template_id == "prot_solv_hide":
        return DisplayLayer("solvent_hidden", "Hide Solvent", DisplaySelector("semantic_group", "solvent"), 
                           RepresentationStyle("hidden"), order=50)

    # 2. MATERIALS
    elif template_id == "mat_framework":
        return DisplayLayer("framework", "Framework Sticks", DisplaySelector("semantic_group", "framework"), 
                           RepresentationStyle("sticks"), order=10)
    elif template_id == "mat_interlayer":
        return DisplayLayer("interlayer", "Interlayer Spheres", DisplaySelector("semantic_group", "interlayer"), 
                           RepresentationStyle("spheres", {"radius_scale": 0.45}), order=20)
    elif template_id == "mat_dopant":
        return DisplayLayer("dopants", "Dopants Highlight", DisplaySelector("semantic_group", "dopants"), 
                           RepresentationStyle("spheres", {"radius_scale": 0.5}), color_override=[1, 0, 1, 1], order=30)
    
    # 3. MOLECULES
    elif template_id == "mol_all":
        return DisplayLayer("all_atoms", "Main Structure", DisplaySelector("all_atoms"), 
                           RepresentationStyle("ball_and_stick"), order=100)
    elif template_id == "mol_hydro_hide":
        return DisplayLayer("hydrogens_hidden", "Hide Hydrogens", DisplaySelector("element_symbols", "H"), 
                           RepresentationStyle("hidden"), order=5)
    elif template_id == "mol_selected":
        return DisplayLayer("selection_highlight", "Highlight Selection", DisplaySelector("selected_atoms"), 
                           RepresentationStyle("sticks", {"bond_radius": 0.22}), color_override=[1, 1, 0, 1], order=200)

    # Generic Fallback
    return DisplayLayer(f"layer_{template_id}", "Template Layer", DisplaySelector("all_atoms"), 
                       RepresentationStyle("ball_and_stick"), order=50)
