from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, Literal, List

RepresentationKind = Literal[
    "hidden",
    "spheres",
    "sticks",
    "ball_and_stick",
    "ribbon",
    "lines",
]

@dataclass
class RepresentationStyle:
    """Defines the visual technique and its specific parameters."""
    kind: RepresentationKind
    params: Dict[str, Any] = field(default_factory=dict)

@dataclass
class RepresentationInstance:
    """A specific instance of a representation applied to a semantic group."""
    id: str
    label: str
    group_name: str
    visible: bool = True
    style: RepresentationStyle = field(default_factory=lambda: RepresentationStyle("spheres"))
    opacity: float = 1.0
    color_override: Optional[List[float]] = None # [R, G, B] or [R, G, B, A]
    order: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_param(self, name: str, default: Any = None) -> Any:
        return self.style.params.get(name, default)
