from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any, Optional
import numpy as np

@dataclass
class RenderQualityState:
    target_fps: float = 60.0
    current_fps: float = 60.0
    skip_px: float = 0.4
    point_px: float = 2.0
    impostor_px: float = 8.0
    bond_mode: str = "cylinder" # cylinder, line, off
    max_visible_replicas: int = 125
    playback_low_quality: bool = True
    pretty_render: bool = False
    
    def adjust(self, fps: float):
        self.current_fps = fps
        if fps < self.target_fps * 0.7:
             # Reduce quality
             self.skip_px = min(self.skip_px + 0.1, 2.0)
             self.point_px = min(self.point_px + 0.5, 12.0)
             if self.bond_mode == "cylinder": self.bond_mode = "line"
        elif fps > self.target_fps * 1.2:
             # Increase quality
             self.skip_px = max(self.skip_px - 0.05, 0.4)
             self.point_px = max(self.point_px - 0.2, 3.0)
             if self.bond_mode == "line": self.bond_mode = "cylinder"

@dataclass
class ColoringState:
    mode: str = "Element" # Element, Z Position, Displacement, Neighbors, Coordination, Voronoi Volume, Selection, Index
    palette: str = "BlueRed" # BlueRed, Viridis, Magma, Hot, Grayscale
    invert: bool = False
    range_auto: bool = True
    range: List[float] = field(default_factory=lambda: [0.0, 10.0])
    z_fractional: bool = False
    highlight_selection: bool = True
    nb_cutoff: float = 3.0
    displacement_ref_index: int = 0
    displacement_ref_pos: Optional[np.ndarray] = None

    @property
    def signature(self) -> str:
        """Returns a stable hashable signature of the coloring settings."""
        return f"{self.mode}_{self.palette}_{self.invert}_{self.range_auto}_{self.range[0]}_{self.range[1]}"

@dataclass
class ClippingState:
    enabled: bool = False
    axis: int = 2 # 0:X, 1:Y, 2:Z
    range: List[float] = field(default_factory=lambda: [0.0, 1.0])
    fractional: bool = False
    invert: bool = False
    alpha: float = 0.0 # 0.0 means hidden, >0 means transparent

@dataclass
class DisplayState:
    # Sub-states
    coloring: ColoringState = field(default_factory=ColoringState)
    quality: RenderQualityState = field(default_factory=RenderQualityState)
    
    # 1. Basic Geometry Controls
    atom_scale: float = 1.45
    bond_scale: float = 0.08
    show_bonds: bool = True
    show_cell: bool = True
    show_shadows: bool = True
    shadow_intensity: float = 0.5
    bg_color: List[float] = field(default_factory=lambda: [0.08, 0.08, 0.1])

    # 2. Global Clipping Plane
    clipping_enabled: bool = False
    clipping_axis: int = 2
    clipping_range: List[float] = field(default_factory=lambda: [0.0, 1.0])
    clipping_fractional: bool = False
    clipping_invert: bool = False
    clipping_alpha: float = 0.0

    # 3. Global UI Toggles
    show_axes: bool = True
    show_origin_axes: bool = False
    show_com: bool = False
    is_ortho: bool = False

    # 4. Compatibility bridge for old UI / transition
    protein_ribbon_dirty: bool = True
