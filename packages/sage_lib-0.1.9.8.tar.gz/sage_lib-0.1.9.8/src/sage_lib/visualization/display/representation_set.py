from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from .representations import RepresentationInstance

@dataclass
class RepresentationSet:
    """A collection of active representations for a scene."""
    items: List[RepresentationInstance] = field(default_factory=list)

    def sorted_items(self) -> List[RepresentationInstance]:
        """Returns items in increasing order priority."""
        return sorted(self.items, key=lambda x: x.order)

    def get(self, rep_id: str) -> Optional[RepresentationInstance]:
        for item in self.items:
            if item.id == rep_id:
                return item
        return None
    
    def add(self, item: RepresentationInstance):
        # Ensure no duplicates for now
        self.items = [i for i in self.items if i.id != item.id]
        self.items.append(item)
