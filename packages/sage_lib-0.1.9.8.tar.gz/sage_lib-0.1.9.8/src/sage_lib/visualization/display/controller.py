from __future__ import annotations
import numpy as np
from typing import Optional, Dict, Any, List, Callable

from .visual_state import VisualState
from .semantic_groups import build_semantic_groups
from .layer_set import DisplayLayerSet
from .named_selections import NamedSelectionSet
from .caching import DisplayCache
from .layer_factory import build_default_layer_set
from .system_classification import compute_structure_signature, classify_system
from .state import DisplayState
from .compositor import compose_visual_state
from .representation_set import RepresentationSet
from .presets import build_default_representations

class DisplayController:
    """Orchestrates persistent visual layers and resolves them into GPU-ready states."""
    
    def __init__(self, display_state: DisplayState, get_base_colors: Callable[[Any], np.ndarray]):
        self.display_state = display_state
        self.get_base_colors = get_base_colors
        self.layer_set: Optional[DisplayLayerSet] = None
        self.representation_set = RepresentationSet()
        self.named_selection_set = NamedSelectionSet()
        self.cache = DisplayCache()
        self.validation_issues: List[Any] = []
        self._layer_signature: Any = None
        self._rep_signature: Any = None
        self.system_type: str = "generic"

    def ensure_layer_set(self, scene: Any, semantic_groups: Dict[str, np.ndarray]):
        """Initializes or restores visual layers based on current structure classification."""
        current_sig = compute_structure_signature(scene)
        
        # If structure changed significantly, rebuild defaults
        if self.layer_set is None or current_sig != self._layer_signature:
            self.system_type = classify_system(scene)
            self.layer_set = build_default_layer_set(scene, semantic_groups, self.system_type)
            self._layer_signature = current_sig

    def ensure_representation_set(self, scene: Any, semantic_groups: Any, context: Optional[Dict[str, Any]] = None):
        """Initializes default visual representations if they haven't been set or if the system changed."""
        current_sig = compute_structure_signature(scene)
        if not self.representation_set.items or current_sig != self._rep_signature:
            self.representation_set = build_default_representations(scene, semantic_groups, context or {})
            self._rep_signature = current_sig

    def build_visual_state(
        self,
        scene: Any,
        context: Optional[Dict[str, Any]] = None,
        highlight_selection: Optional[bool] = None
    ) -> VisualState:
        """
        Resolves the final visual attributes of the scene through the layer compositor.
        """
        if highlight_selection is None:
            highlight_selection = self.display_state.coloring.highlight_selection if hasattr(self.display_state, 'coloring') else True
        
        current_sig = compute_structure_signature(scene)
        coloring_sig = self.display_state.coloring.signature if hasattr(self.display_state, 'coloring') else ""
        
        # Combined Cache Invalidation
        if not hasattr(self, '_prev_coloring_sig'): self._prev_coloring_sig = coloring_sig
        if coloring_sig != self._prev_coloring_sig:
            self.cache.clear()
            self._prev_coloring_sig = coloring_sig
            
        self.cache.check_invalid(current_sig)

        # 1. Classify Semantics (O(N) search)
        semantic_groups = build_semantic_groups(
            scene, active_site_str=context.get("active_site_str", "") if context else "",
        )

        # 2. Maintain Persistent Visual State (The "Layers" & "Representations")
        self.ensure_layer_set(scene, semantic_groups)
        self.ensure_representation_set(scene, semantic_groups, context)

        # 3. Structural Base data (Step A)
        base_colors = self.get_base_colors(scene)
        base_radii = np.array(scene.radii, dtype=np.float32, copy=True)
        
        # 4. Perform Validation (Sprint 5.9)
        from .validation import validate_layer_set
        self.validation_issues = validate_layer_set(scene, semantic_groups, self.layer_set, self.named_selection_set)

        # 5. Resolve Composition (Step B - Composite)
        visual_state = compose_visual_state(
            scene=scene,
            base_colors=base_colors,
            base_radii=base_radii,
            semantic_groups=semantic_groups,
            layer_set=self.layer_set,
            display_state=self.display_state,
            named_selection_set=self.named_selection_set,
            cache=self.cache,
            highlight_selection=highlight_selection
        )

        return visual_state
