from __future__ import annotations
import numpy as np
from typing import Optional, Dict, Any, Tuple, List
from .state import DisplayState, ColoringState, ClippingState
from .component_rules import VisualComponentRule
from .semantic_groups import SemanticGroups

def build_atom_visuals(
    scene: Any, 
    base_colors: np.ndarray, 
    base_radii: np.ndarray,
    semantic_groups: SemanticGroups,
    component_rules: List[VisualComponentRule],
    display_state: DisplayState,
    highlight_selection: bool = True,
    # mutation_preview: Optional[Dict[str, Any]] = None # Transferred to SemanticGroups / ComponentRules logic
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Constructs the final (RGBA, Radii) buffers for GPU synchronization.
    This replaces the legacy hardcoded logic with a data-driven pipeline.
    """
    # 1. Start with base structural data and computed colors (Step A)
    positions = scene.pos
    radii = np.copy(base_radii) * display_state.atom_scale
    
    # Ensure RGBA
    if base_colors.shape[1] == 3:
        colors_rgba = np.ones((len(base_colors), 4), dtype=np.float32)
        colors_rgba[:, :3] = base_colors
    else:
        colors_rgba = np.copy(base_colors)
        
    hidden_mask = np.zeros(scene.N, dtype=bool)

    # 2. Apply Component Overrides (Step B - Semantic)
    # Sort by priority - higher overrides lower (priority 0 -> 100)
    for rule in sorted(component_rules, key=lambda r: r.priority):
        if not semantic_groups.has(rule.group_name):
            continue

        idx = semantic_groups.get(rule.group_name)
        
        if rule.hide_atoms or not rule.visible:
            radii[idx] = 0.0
            colors_rgba[idx, 3] = 0.0
            hidden_mask[idx] = True
            continue

        # Overrides visibility / opacity
        colors_rgba[idx, 3] *= rule.opacity
        radii[idx] *= rule.radius_scale

        if rule.color_override is not None:
            colors_rgba[idx, :3] = np.array(rule.color_override[:3], dtype=np.float32)
            if len(rule.color_override) > 3:
                colors_rgba[idx, 3] = rule.color_override[3]

    # 3. Apply Global Clipping Mask (Ghosting)
    clipped_mask = np.zeros(scene.N, dtype=bool)
    if display_state.clipping_enabled:
        clipped_mask = apply_clipping_mask(positions, scene.lat, colors_rgba, display_state)
        
    # 4. Apply Selection Highlight (Topmost Visual State)
    if highlight_selection and scene.selected_atoms:
        for idx in scene.selected_atoms:
            if idx < scene.N:
                colors_rgba[idx, :3] = [1.0, 0.9, 0.1]
                colors_rgba[idx, 3] = 1.0 # Ensure visible
                
    return (colors_rgba, radii, clipped_mask, hidden_mask)

def apply_clipping_mask(
    pos: np.ndarray, 
    lat: Optional[np.ndarray], 
    colors: np.ndarray, 
    clipping: DisplayState # Now contains it directly
) -> np.ndarray:
    """Updates the alpha channel of atom colors based on clipping range and ghosting alpha."""
    # 1. Calculate scalars along the clipping axis
    if clipping.clipping_fractional and lat is not None:
        inv_lat = np.linalg.inv(lat)
        pos_frac = pos @ inv_lat
        vals = pos_frac[:, clipping.clipping_axis]
    else:
        vals = pos[:, clipping.clipping_axis]
    
    # 2. Determine ghosting mask
    mask_in_range = (vals >= clipping.clipping_range[0]) & (vals <= clipping.clipping_range[1])
    
    # If invert=False: In-range is visible (alpha=1), out-of-range is ghosted
    # If invert=True: Out-of-range is visible, in-range is ghosted
    if clipping.clipping_invert:
        mask_ghost = mask_in_range
    else:
        mask_ghost = ~mask_in_range
        
    # 3. Apply ghosting alpha (multiply existing alpha for synergy)
    colors[mask_ghost, 3] *= clipping.clipping_alpha
    
    return mask_ghost
