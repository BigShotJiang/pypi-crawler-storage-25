from __future__ import annotations
from dataclasses import dataclass
from typing import List, Any, Dict
import numpy as np

@dataclass
class ValidationIssue:
    severity: str   # 'info', 'warning', 'error'
    code: str
    message: str
    layer_id: str | None = None

def validate_layer_set(scene, semantic_groups, layer_set, named_selection_set) -> List[ValidationIssue]:
    """
    Performs diagnostic checks on the current visual stack.
    - Checks for empty selectors.
    - Checks for missing named selections.
    - Checks for ribbon compatibility.
    """
    issues = []
    from .selectors import resolve_selector
    
    for layer in layer_set.items:
        # 1. Resolve selector
        indices = resolve_selector(scene, semantic_groups, layer.selector, named_selection_set)
        
        if indices.size == 0:
            issues.append(ValidationIssue(
                severity="warning",
                code="EMPTY_SELECTOR",
                message=f"Layer '{layer.label}' resolves to 0 atoms.",
                layer_id=layer.id
            ))
            
        # 2. Named Selection existence
        if layer.selector.kind == "named_selection":
             name = str(layer.selector.value)
             if not named_selection_set.get(name) and not named_selection_set.get_by_name(name):
                  issues.append(ValidationIssue(
                      severity="error",
                      code="MISSING_NAMED_SELECTION",
                      message=f"Named selection '{name}' not found.",
                      layer_id=layer.id
                  ))

        # 3. Ribbon Compatibility
        if layer.style.kind == "ribbon":
             # Check if any backbone atoms exist in selection
             atom_names = np.array(scene.info.get('name', []))
             sel_names = atom_names[indices]
             has_bb = any(n in ["CA", "C", "N", "O"] for n in sel_names)
             if not has_bb:
                  issues.append(ValidationIssue(
                      severity="info",
                      code="NO_BACKBONE_FOR_RIBBON",
                      message=f"Layer '{layer.label}' (Ribbon) contains no backbone atoms. Ribbon will be invisible.",
                      layer_id=layer.id
                  ))
                  
    return issues
