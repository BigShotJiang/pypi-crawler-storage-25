from __future__ import annotations
import numpy as np
from typing import Any, Dict, List, Optional
from .selectors import DisplaySelector, resolve_selector

def parse_selector_expression(expr: str) -> DisplaySelector:
    """
    Parses a simple string expression into a DisplaySelector.
    Sintaxis:
    - 'all' -> all_atoms
    - 'selected' -> selected_atoms
    - 'group:NAME' -> semantic_group
    - 'element:EL1,EL2' -> element_symbols
    - 'resid:ID1,ID2' -> residue_ids
    - 'chain:ID' -> chain_ids
    - 'named:ID' -> named_selection
    """
    expr = expr.strip().lower()
    
    if expr == "all":
        return DisplaySelector("all_atoms")
    if expr == "selected":
        return DisplaySelector("selected_atoms")
        
    if ":" in expr:
        prefix, value = expr.split(":", 1)
        prefix = prefix.strip()
        value = value.strip()
        
        if prefix == "group":
            return DisplaySelector("semantic_group", value)
        if prefix == "element":
            return DisplaySelector("element_symbols", value)
        if prefix == "resid":
            return DisplaySelector("residue_ids", value)
        if prefix == "chain":
            return DisplaySelector("chain_ids", value)
        if prefix == "named":
            return DisplaySelector("named_selection", value)
            
    # Fallback: try element or semantic group directly?
    # Better to return all_atoms or empty if not understood
    return DisplaySelector("all_atoms")

def resolve_expression_selector(scene, semantic_groups: Dict[str, np.ndarray], expression: str, named_selection_set: Any = None) -> np.ndarray:
    """
    Resolves a string expression into atom indices.
    Supports a single 'not ' prefix for basic boolean logic as per Sprint 5.3.
    """
    expr = expression.strip()
    is_negated = False
    
    if expr.lower().startswith("not "):
        is_negated = True
        expr = expr[4:].strip()
        
    # Standard parsing
    selector = parse_selector_expression(expr)
    indices = resolve_selector(scene, semantic_groups, selector, named_selection_set)
    
    if is_negated:
        # Return all atoms NOT in indices
        mask = np.ones(scene.N, dtype=bool)
        mask[indices.astype(np.int32)] = False
        return np.where(mask)[0].astype(np.uint32)
        
    return indices
