from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Set, Any, Optional

@dataclass
class VisualComponentRule:
    """A rule-based override for a specific atom group."""
    id: str                 # Unique ID for the rule (e.g. "backbone_hidden")
    label: str              # User-friendly label (e.g. "Protein Backbone")
    group_name: str         # Target group defined in SemanticGroups
    visible: bool = True
    opacity: float = 1.0
    radius_scale: float = 1.0
    hide_atoms: bool = False # If True, radii=0 regardless of state.atom_scale
    color_override: Optional[List[float]] = None
    priority: int = 0       # Z-order / precedence (larger = more specific/applied later)
    metadata: Dict[str, Any] = field(default_factory=dict)
