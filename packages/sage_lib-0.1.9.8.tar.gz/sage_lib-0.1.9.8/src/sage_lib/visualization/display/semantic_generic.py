from __future__ import annotations
import numpy as np
from typing import Dict, Any

def classify_generic_groups(scene: Any, groups: Dict[str, np.ndarray]):
    """Initial catch-all chemical classification (Heavy vs Light)."""
    if not scene.N:
        return

    elements = np.array(scene.elements)
    def mask_to_idx(mask): return np.where(mask)[0].astype(np.int32)

    # All Atoms
    groups["all_atoms"] = np.arange(scene.N, dtype=np.int32)

    # Chemical Classification (Hydrogen vs Heavy)
    is_h = (elements == "H") | (elements == "D") | (elements == "T")
    groups["hydrogens"] = mask_to_idx(is_h)
    groups["heavy_atoms"] = mask_to_idx(~is_h)

    # Elements-based grouping
    unique_elements = np.unique(elements)
    for el in unique_elements:
        groups[f"element_{el}"] = mask_to_idx(elements == el)
