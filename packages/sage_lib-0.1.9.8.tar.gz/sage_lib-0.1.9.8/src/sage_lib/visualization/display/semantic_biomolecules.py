from __future__ import annotations
import numpy as np
from typing import Dict, Any

AMINO_ACIDS = {
    "ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE", "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL", "SEC", "PYL",
    "HSD", "HSE", "HSP", "MSE", "CYX", "CYS2", "HID", "IHE", "HIP", "GLUP", "ASPP", "LYSN"
}
BACKBONE_ATOMS = {"N", "CA", "C", "O", "OXT", "H", "HA", "HA1", "HA2"}
SOLVENT_RES = {"HOH", "WAT", "H2O", "SOL"}
ION_RES = {"NA", "K", "LI", "CL", "CA", "MG", "ZN", "FE", "CU", "MN", "CD", "HG", "PB", "CS"}

def classify_biomolecule_groups(scene: Any, groups: Dict[str, np.ndarray], active_site_str: str = ""):
    """Refines semantic groups with protein and ligand heuristics."""
    if not (scene.info and 'name' in scene.info):
        return

    atom_names = np.array([str(n).strip().upper() for n in scene.info['name']])
    res_names = np.array([str(r).strip().upper() for r in scene.info.get('res_name', [])])
    res_ids = np.array(scene.info.get('res_id', []))
    
    def mask_to_idx(mask): return np.where(mask)[0].astype(np.int32)

    is_prot = np.array([rn in AMINO_ACIDS for rn in res_names])
    is_bb = np.zeros(scene.N, dtype=bool)
    for i, name in enumerate(atom_names):
        if is_prot[i] and name in BACKBONE_ATOMS:
            is_bb[i] = True

    groups["protein_backbone"] = mask_to_idx(is_bb)
    groups["protein_sidechains"] = mask_to_idx(is_prot & ~is_bb)
    
    is_sol = np.array([rn in SOLVENT_RES for rn in res_names])
    groups["solvent"] = mask_to_idx(is_sol)
    
    is_ion = np.array([rn in ION_RES for rn in res_names])
    groups["ions"] = mask_to_idx(is_ion)
    
    # Ligands are residues that aren't protein, solvent or ion
    is_lig = ~(is_prot | is_sol | is_ion)
    groups["ligands"] = mask_to_idx(is_lig)

    # Active Site ID set
    if active_site_str:
        try:
            active_ids = {int(x.strip()) for x in active_site_str.split(',') if x.strip().isdigit()}
            is_active = np.zeros(scene.N, dtype=bool)
            for i, rid in enumerate(res_ids):
                if rid in active_ids: is_active[i] = True
            groups["active_site"] = mask_to_idx(is_active)
        except:
            pass
