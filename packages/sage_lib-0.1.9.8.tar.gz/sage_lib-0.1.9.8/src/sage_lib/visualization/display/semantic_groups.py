from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Set, Any, Optional

from .semantic_biomolecules import classify_biomolecule_groups
from .semantic_materials import classify_material_groups
from .semantic_generic import classify_generic_groups

@dataclass
class SemanticGroups:
    """Classifies a structure into semantic subsets for visualization rules."""
    groups: Dict[str, np.ndarray] = field(default_factory=dict)

    def get(self, name: str, default: Any = None) -> np.ndarray:
        if default is None: default = np.zeros(0, dtype=np.int32)
        return self.groups.get(name, default)

    def has(self, name: str) -> bool:
        return name in self.groups and len(self.groups[name]) > 0
        
    def keys(self):
        return self.groups.keys()
        
    def __getitem__(self, key: str) -> np.ndarray:
        return self.groups[key]
        
    def __iter__(self):
        return iter(self.groups)

def build_semantic_groups(scene: Any, active_site_str: str = "") -> SemanticGroups:
    """
    Orchestrates specialized semantic classification engines (Generic, Biomolecules, Materials)
    to build a finalized set of architectural groups for the scene.
    """
    if not scene.N:
        return SemanticGroups()

    groups: Dict[str, np.ndarray] = {}

    # 1. Broad Chemical (Generic)
    classify_generic_groups(scene, groups)

    # 2. Heuristics-based (Biomolecular & Materials)
    # Order matters: biomolecules can set ligand/solvent info used by materials
    classify_biomolecule_groups(scene, groups, active_site_str=active_site_str)
    
    # 3. Structural Classification (Materials)
    classify_material_groups(scene, groups)

    return SemanticGroups(groups=groups)
