from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from .layers import DisplayLayer

@dataclass
class DisplayLayerSet:
    items: List[DisplayLayer] = field(default_factory=list)

    def sorted_items(self) -> List[DisplayLayer]:
        """Returns layers sorted by their drawing order (lower numbers first)."""
        return sorted(self.items, key=lambda x: x.order)

    def get(self, layer_id: str) -> Optional[DisplayLayer]:
        for item in self.items:
            if item.id == layer_id:
                return item
        return None

    def to_dict(self) -> dict:
        """Serializes the layer set to a JSON-stable dictionary."""
        return {
            "items": [item.to_dict() for item in self.items]
        }

    @classmethod
    def from_dict(cls, data: dict) -> DisplayLayerSet:
        """Restores a layer set from a dictionary."""
        from .layers import DisplayLayer
        ls = cls()
        ls.items = [DisplayLayer.from_dict(d) for d in data.get("items", [])]
        ls.normalize_orders()
        return ls

    def add(self, layer: DisplayLayer):
        self.items.append(layer)
        self.normalize_orders()

    def remove(self, layer_id: str):
        self.items = [x for x in self.items if x.id != layer_id]
        self.normalize_orders()

    def duplicate(self, layer_id: str):
        """Clones a layer and adds it to the set."""
        layer = self.get(layer_id)
        if not layer: return
        import copy
        new_layer = copy.deepcopy(layer)
        new_layer.id = f"{layer.id}_copy_{np.random.randint(1000, 9999)}"
        new_layer.label = f"{layer.label} Copy"
        new_layer.order += 1 # Insert slightly above
        self.items.append(new_layer)
        self.normalize_orders()

    def normalize_orders(self):
        """Re-indexes orders with a consistent step size (10) for easier manual insertion later."""
        items = self.sorted_items()
        for i, item in enumerate(items):
            item.order = (i + 1) * 10

    def move_up(self, layer_id: str):
        """Moves a layer earlier in the drawing order (one position lower)."""
        items = self.sorted_items()
        idx = next((i for i, x in enumerate(items) if x.id == layer_id), None)
        if idx is None or idx == 0:
            return
        items[idx - 1].order, items[idx].order = items[idx].order, items[idx - 1].order
        self.normalize_orders()

    def move_down(self, layer_id: str):
        """Moves a layer further in the drawing order (one position higher)."""
        items = self.sorted_items()
        idx = next((i for i, x in enumerate(items) if x.id == layer_id), None)
        if idx is None or idx == len(items) - 1:
            return
        items[idx + 1].order, items[idx].order = items[idx].order, items[idx + 1].order
        self.normalize_orders()
