from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from .selectors import DisplaySelector

@dataclass
class RepresentationStyle:
    kind: str  # "spheres", "sticks", "ball_and_stick", "ribbon", "hidden", "lines"
    params: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"kind": self.kind, "params": self.params}
    
    @classmethod
    def from_dict(cls, d: dict) -> RepresentationStyle:
        return cls(kind=d["kind"], params=d.get("params", {}))

@dataclass
class DisplayLayer:
    id: str
    label: str
    selector: DisplaySelector
    style: RepresentationStyle

    visible: bool = True
    opacity: float = 1.0
    color_override: Optional[List[float]] = None
    order: int = 0

    enabled: bool = True
    locked: bool = False

    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_param(self, name: str, default: Any = None) -> Any:
        # Check metadata, then style params, then default
        if name in self.metadata: return self.metadata[name]
        return self.style.params.get(name, default)

    def to_dict(self) -> dict:
        return {
            "id": self.id, "label": self.label,
            "visible": self.visible, "opacity": self.opacity,
            "color_override": self.color_override, "order": self.order,
            "selector": self.selector.to_dict(),
            "style": self.style.to_dict(),
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, d: dict) -> DisplayLayer:
        return cls(
            id=d["id"], label=d["label"],
            visible=d.get("visible", True),
            opacity=d.get("opacity", 1.0),
            color_override=d.get("color_override"),
            order=d.get("order", 0),
            selector=DisplaySelector.from_dict(d["selector"]),
            style=RepresentationStyle.from_dict(d["style"]),
            metadata=d.get("metadata", {})
        )
