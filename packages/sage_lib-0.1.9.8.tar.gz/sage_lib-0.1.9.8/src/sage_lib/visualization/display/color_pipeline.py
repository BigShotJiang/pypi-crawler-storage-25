from __future__ import annotations
import numpy as np
from typing import Optional, Dict, Any, Tuple
from .state import ColoringState

def compute_atom_colors(
    scene: Any, 
    color_state: ColoringState, 
    element_materials: Dict[str, Dict[str, Any]],
    force_refresh: bool = False
) -> np.ndarray:
    """
    Computes base atomic colors based on the current coloring mode.
    This replaces the core logic of _update_coloring.
    """
    if not scene.N:
        return np.zeros((0, 3), dtype=np.float32)

    # 1. Dispatch based on mode
    if color_state.mode == "Element":
        return get_element_colors(scene, element_materials, force_refresh)
        
    scalars = np.zeros(scene.N, dtype=np.float32)
    
    if color_state.mode == "Z Position":
        if color_state.z_fractional and scene.lat is not None:
            inv_lat = np.linalg.inv(scene.lat)
            frac = scene.pos @ inv_lat
            scalars = frac[:, 2]
        else:
            scalars = scene.pos[:, 2]

    elif color_state.mode == "Displacement":
        if color_state.displacement_ref_pos is not None and len(color_state.displacement_ref_pos) == scene.N:
            scalars = np.linalg.norm(scene.pos - color_state.displacement_ref_pos, axis=1)

    elif color_state.mode == "Neighbors":
        from ..analysis.coordination import compute_cn
        lat = scene.lat if scene.is_periodic else None
        # Registry First
        registry = getattr(scene, 'registry', None)
        scalars = registry.get_property("neighbor_count") if registry else None
        
        if scalars is None or len(scalars) != scene.N:
            _, nb_counts = compute_cn(scene.pos, lat, r_cut=color_state.nb_cutoff)
            scalars = nb_counts.astype(np.float32)

    elif color_state.mode == "Coordination":
        # Registry First (Standardized Key)
        registry = getattr(scene, 'registry', None)
        scalars = registry.get_property("coordination") if registry else None
        
        if scalars is None or len(scalars) != scene.N:
            # Fallback to legacy scene attribute
            scalars = getattr(scene, "cn", None)
            
        if scalars is None or len(scalars) != scene.N:
            # Final Fallback: Recompute (PBC aware)
            from ..analysis.coordination import compute_coordination_sphere
            lat = scene.lat if scene.is_periodic else None
            _, cnts, _, _ = compute_coordination_sphere(scene.pos, scene.elements, lat, factor=getattr(scene, 'bond_factor', 1.2))
            scalars = cnts.astype(np.float32)

    elif color_state.mode == "Voronoi Volume":
        # Registry First (Standardized Key)
        registry = getattr(scene, 'registry', None)
        scalars = registry.get_property("voronoi_volume") if registry else None
        
        if scalars is None or len(scalars) != scene.N:
            # Fallback to legacy scene attribute
            scalars = getattr(scene, "voro_volumes", None)
            
        if scalars is None or len(scalars) != scene.N:
            # Final Fallback: Recompute
            from ..analysis.voronoi import VoronoiAnalyzer
            lat = scene.lat if scene.is_periodic else None
            v_res = VoronoiAnalyzer.compute_voronoi(scene.pos, lat)
            scalars = v_res['volumes'].astype(np.float32)

    elif color_state.mode == "Selection":
        for idx in scene.selected_atoms:
            if idx < scene.N: scalars[idx] = 1.0

    elif color_state.mode == "Index":
        scalars = np.arange(scene.N, dtype=np.float32)

    return map_scalars_to_palette(scalars, color_state)

def get_element_colors(
    scene: Any, 
    element_materials: Dict[str, Dict[str, Any]], 
    force_refresh: bool = False
) -> np.ndarray:
    """Returns colors based on element definitions."""
    from ..constants import CPK_COLORS
    colors = np.tile([0.5, 0.5, 0.5], (scene.N, 1)).astype(np.float32)
    for i in range(scene.N):
        el = scene.elements[i] if (scene.elements and i < len(scene.elements)) else "X"
        # Accessing element_materials from either dict or defaults
        m = element_materials.get(el, {'col': CPK_COLORS.get(el, [0.5, 0.5, 0.5])})
        colors[i] = m['col']
    return colors

def map_scalars_to_palette(scalars: np.ndarray, state: ColoringState) -> np.ndarray:
    """Turns a vector of scalars into RGB colors using linear maps."""
    if scalars.size == 0: return np.zeros((0, 3), dtype=np.float32)
    
    valid_mask = np.isfinite(scalars)
    if not np.any(valid_mask):
        return np.ones((len(scalars), 3), dtype=np.float32) * 0.5 # Neutral Gray
        
    # Range calculation (excluding NaNs) using contract-compliant nanmin/nanmax
    if state.range_auto:
        v_min, v_max = np.nanmin(scalars[valid_mask]), np.nanmax(scalars[valid_mask])
    else:
        v_min, v_max = state.range
    
    if v_max == v_min: 
        v_max += 1e-7
        t = np.full_like(scalars, 0.5, dtype=np.float32)
    else:
        t = np.zeros_like(scalars, dtype=np.float32)
        # Use np.nan_to_num as a secondary safety layer, though valid_mask is primary
        t[valid_mask] = np.clip((scalars[valid_mask] - v_min) / (v_max - v_min), 0.0, 1.0)
        
    if state.invert: t[valid_mask] = 1.0 - t[valid_mask]
    
    colors = np.zeros((len(t), 3), dtype=np.float32)
    # Default everything to neutral Gray; only the palette-mapped atoms will be updated below
    colors[:] = 0.5
    
    if state.palette == "BlueRed":
        # Blue -> White -> Red
        m_lo = valid_mask & (t < 0.5)
        t_lo = t[m_lo] * 2.0
        colors[m_lo] = np.column_stack((t_lo, t_lo, np.ones_like(t_lo)))
        
        m_hi = valid_mask & (t >= 0.5)
        t_hi = 1.0 - (t[m_hi] - 0.5) * 2.0
        colors[m_hi] = np.column_stack((np.ones_like(t_hi), t_hi, t_hi))
        
    elif state.palette == "Viridis":
        v_t = t[valid_mask]
        colors[valid_mask, 0] = v_t**2
        colors[valid_mask, 1] = v_t
        colors[valid_mask, 2] = 1.0 - v_t
        
    elif state.palette == "Magma":
        v_t = t[valid_mask]
        colors[valid_mask, 0] = np.clip(v_t * 1.2, 0, 1)
        colors[valid_mask, 1] = v_t**3
        colors[valid_mask, 2] = 0.2 + 0.3 * v_t
        
    elif state.palette == "Hot":
        v_t = t[valid_mask]
        colors[valid_mask, 0] = np.clip(v_t * 3.0, 0, 1)
        colors[valid_mask, 1] = np.clip(v_t * 3.0 - 1.0, 0, 1)
        colors[valid_mask, 2] = np.clip(v_t * 3.0 - 2.0, 0, 1)
        
    elif state.palette == "Grayscale":
        v_t = t[valid_mask]
        colors[valid_mask, 0] = v_t
        colors[valid_mask, 1] = v_t
        colors[valid_mask, 2] = v_t
        
    return colors
