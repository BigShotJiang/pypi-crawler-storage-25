from __future__ import annotations
from typing import Dict, Any, List
import numpy as np
from .layers import DisplayLayer, RepresentationStyle
from .selectors import DisplaySelector
from .layer_set import DisplayLayerSet

def build_default_layer_set(scene, semantic_groups: Dict[str, np.ndarray], system_type: str) -> DisplayLayerSet:
    """Factory to create a starter set of layers based on the detected system type."""
    layers = DisplayLayerSet()
    
    if system_type == "protein":
        # Protein specific defaults
        layers.add(DisplayLayer(
            id="protein_backbone", label="Backbone (Ribbon)", 
            selector=DisplaySelector("semantic_group", "protein_backbone"),
            style=RepresentationStyle("ribbon", {"width": 1.6, "thickness": 0.3})
        ))
        layers.add(DisplayLayer(
            id="protein_sidechains", label="Side Chains", 
            selector=DisplaySelector("semantic_group", "protein_sidechains"),
            style=RepresentationStyle("sticks", {"bond_radius": 0.08, "atom_radius_scale": 0.2})
        ))
        if "ligands" in semantic_groups:
            layers.add(DisplayLayer(
                id="ligands", label="Ligands", 
                selector=DisplaySelector("semantic_group", "ligands"),
                style=RepresentationStyle("ball_and_stick", {"bond_radius": 0.08, "atom_radius_scale": 0.25})
            ))
        if "solvent" in semantic_groups:
            layers.add(DisplayLayer(
                id="solvent", label="Solvent", 
                selector=DisplaySelector("semantic_group", "solvent"),
                style=RepresentationStyle("hidden"), visible=False
            ))
            
    elif system_type == "layered_material":
        # Materials defaults
        layers.add(DisplayLayer(
            id="framework", label="Framework", 
            selector=DisplaySelector("semantic_group", "framework"),
            style=RepresentationStyle("sticks", {"bond_radius": 0.08})
        ))
        if "interlayer" in semantic_groups:
            layers.add(DisplayLayer(
                id="interlayer", label="Interlayer", 
                selector=DisplaySelector("semantic_group", "interlayer"),
                style=RepresentationStyle("spheres", {"radius_scale": 0.4})
            ))
        if "adsorbates" in semantic_groups:
            layers.add(DisplayLayer(
                id="adsorbates", label="Adsorbates", 
                selector=DisplaySelector("semantic_group", "adsorbates"),
                style=RepresentationStyle("ball_and_stick", {"bond_radius": 0.08})
            ))

    elif system_type == "molecule":
        # Small molecule defaults
        layers.add(DisplayLayer(
            id="all_atoms", label="Main structure", 
            selector=DisplaySelector("all_atoms"),
            style=RepresentationStyle("ball_and_stick", {"bond_radius": 0.08, "atom_radius_scale": 0.2})
        ))
        if "hydrogens" in semantic_groups:
            layers.add(DisplayLayer(
                id="hydrogens", label="Hydrogens", 
                selector=DisplaySelector("semantic_group", "hydrogens"),
                style=RepresentationStyle("ball_and_stick", {"bond_radius": 0.06, "atom_radius_scale": 0.15})
            ))
        
    else:
        # Default fallback
        layers.add(DisplayLayer(
            id="all_atoms", label="All Atoms", 
            selector=DisplaySelector("all_atoms"),
            style=RepresentationStyle("ball_and_stick", {"bond_radius": 0.08, "atom_radius_scale": 0.2})
        ))

    # Always add a hidden 'Selected' layer for highlight debugging/editing
    layers.add(DisplayLayer(
        id="selected_atoms", label="Selected Atoms", 
        selector=DisplaySelector("selected_atoms"),
        style=RepresentationStyle("spheres", {"radius_scale": 0.45}),
        visible=False, color_override=[0.0, 1.0, 1.0, 0.4]
    ))
    
    return layers
