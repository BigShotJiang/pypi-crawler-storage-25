from __future__ import annotations
from typing import Dict, Any

REPRESENTATION_REGISTRY = {
    "hidden": {
        "label": "Hidden",
        "params": {}
    },
    "spheres": {
        "label": "Spheres",
        "params": {
            "radius_scale": {"type": "float", "default": 1.0, "min": 0.05, "max": 3.0},
            "radius_source": {"type": "list", "default": "vdw", "options": ["vdw", "covalent", "scene_default", "custom"]},
            "color_mode": {"type": "list", "default": "element", "options": ["element", "uniform", "chain", "residue", "scalar", "inherit"]},
            "uniform_color": {"type": "color", "default": [0.7, 0.7, 0.7, 1.0]}
        }
    },
    "sticks": {
        "label": "Sticks",
        "params": {
            "bond_radius": {"type": "float", "default": 0.18, "min": 0.01, "max": 1.0},
            "atom_radius_scale": {"type": "float", "default": 0.20, "min": 0.0, "max": 1.0},
            "color_mode": {"type": "list", "default": "element", "options": ["element", "uniform", "chain", "residue", "inherit"]},
            "uniform_color": {"type": "color", "default": [0.8, 0.8, 0.8, 1.0]},
            "bond_color_mode": {"type": "list", "default": "element", "options": ["element", "uniform", "mix"]}
        }
    },
    "ball_and_stick": {
        "label": "Ball & Stick",
        "params": {
            "bond_radius": {"type": "float", "default": 0.18, "min": 0.01, "max": 1.0},
            "atom_radius_scale": {"type": "float", "default": 0.25, "min": 0.05, "max": 1.5},
            "color_mode": {"type": "list", "default": "element", "options": ["element", "uniform", "inherit"]},
            "uniform_color": {"type": "color", "default": [0.9, 0.9, 0.9, 1.0]}
        }
    },
    "ribbon": {
        "label": "Ribbon",
        "params": {
            "width": {"type": "float", "default": 1.6, "min": 0.2, "max": 5.0},
            "thickness": {"type": "float", "default": 0.3, "min": 0.05, "max": 2.0},
            "color_mode": {"type": "list", "default": "secondary_structure", "options": ["secondary_structure", "chain", "residue", "uniform", "inherit"]},
            "uniform_color": {"type": "color", "default": [0.2, 0.6, 1.0, 1.0]},
            "smoothness": {"type": "int", "default": 5, "min": 1, "max": 12},
            "hide_atoms": {"type": "bool", "default": True}
        }
    },
    "lines": {
        "label": "Lines",
        "params": {
            "line_width": {"type": "float", "default": 1.0, "min": 1.0, "max": 10.0},
            "color_mode": {"type": "list", "default": "element", "options": ["element", "uniform", "inherit"]}
        }
    },
}
