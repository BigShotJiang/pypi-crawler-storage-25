from __future__ import annotations
from typing import Any, Literal
import numpy as np

SystemKind = Literal[
    "protein",
    "biomolecule",
    "layered_material",
    "periodic_material",
    "molecule",
    "generic",
]

def classify_system(scene: Any) -> SystemKind:
    """Heuristically determines the type of structural system to select appropriate view presets."""
    if not hasattr(scene, "N") or scene.N == 0:
        return "generic"
        
    has_residues = scene.info and "res_name" in scene.info
    is_periodic = getattr(scene, "is_periodic", False)
    
    if has_residues:
        res_names = [str(r).strip().upper() for r in scene.info["res_name"]]
        AMINO_ACIDS = {"ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE", "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL"}
        protein_frac = sum(1 for r in res_names if r in AMINO_ACIDS) / len(res_names)
        if protein_frac > 0.4:
            return "protein"
        if len(res_names) > 0:
            return "biomolecule"
            
    if is_periodic:
        # Check for generic layered material (e.g. Slab, 2D)
        if hasattr(scene, "lat") and scene.lat is not None:
            # Heuristic: Large vacuum gaps or high aspect ratio
            abc = np.linalg.norm(scene.lat, axis=1)
            if max(abc) > 3.0 * min(abc):
                return "layered_material"
        return "periodic_material"
        
    if scene.N < 500:
        return "molecule"
        
    return "generic"

def compute_structure_signature(scene: Any) -> Any:
    """Computes a lightweight signature to detect structural changes and invalidation."""
    return (
        scene.N,
        getattr(scene, "is_periodic", False),
        len(getattr(scene, "elements", [])),
        bool(scene.info and "res_name" in scene.info),
    )
