from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Dict, Any
import numpy as np

@dataclass
class VisualState:
    """Resolved visual attributes ready for GPU synchronization."""
    pos: np.ndarray
    radii: np.ndarray
    colors: np.ndarray

    bonds: Optional[np.ndarray] = None
    bond_count: int = 0
    lattice: Optional[np.ndarray] = None

    clipped_mask: Optional[np.ndarray] = None
    hidden_mask: Optional[np.ndarray] = None

    metadata: Optional[Dict[str, Any]] = None
