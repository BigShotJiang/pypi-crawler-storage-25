from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional

from .visual_state import VisualState
from .selectors import resolve_selector
from .layer_set import DisplayLayerSet
from .state import DisplayState

from .caching import get_selector_hash, get_layer_hash

def apply_radius_policy(scene: Any, indices: np.ndarray, layer: Any, display_state: DisplayState, base_radii: np.ndarray) -> np.ndarray:
    """Calculates atomic radii based on layer policy (VDW, covalent, etc)."""
    r_scale = layer.get_param("radius_scale", layer.get_param("atom_radius_scale", 1.0))
    r_src = layer.get_param("radius_source", "vdw")
    
    radii = np.zeros(indices.size, dtype=np.float32)
    if r_src == "vdw" and hasattr(scene, "vdw_radii"):
        radii = scene.vdw_radii[indices] * r_scale * display_state.atom_scale
    elif r_src == "covalent" and hasattr(scene, "covalent_radii"):
        radii = scene.covalent_radii[indices] * r_scale * display_state.atom_scale
    else:
        radii = base_radii[indices] * r_scale * display_state.atom_scale
    return radii

def apply_color_policy(scene: Any, indices: np.ndarray, layer: Any, base_colors: np.ndarray) -> np.ndarray:
    """Calculates atomic colors (RGBA) based on layer policy."""
    c_mode = layer.get_param("color_mode", "inherit")
    colors = np.zeros((indices.size, 4), dtype=np.float32)
    
    if c_mode == "uniform":
        col = np.array(layer.get_param("uniform_color", [0.7, 0.7, 0.7, 1.0]), dtype=np.float32)
        colors[:] = col
    elif c_mode == "element":
        src_colors = base_colors[indices]
        if src_colors.shape[1] == 3:
            colors[:, :3] = src_colors
            colors[:, 3] = 1.0
        else:
            colors[:] = src_colors
    elif c_mode == "secondary_structure" and hasattr(scene, 'secondary_structure'):
        # Just a heuristic for now: alpha=red, beta=yellow, other=white/grey
        for i, idx in enumerate(indices):
             ss = scene.secondary_structure[idx] if idx < len(scene.secondary_structure) else 'C'
             if ss == 'H': colors[i] = [1.0, 0.3, 0.3, 1.0]
             elif ss == 'E': colors[i] = [1.0, 1.0, 0.2, 1.0]
             else: colors[i] = [0.8, 0.8, 0.8, 1.0]
    else:
        src_colors = base_colors[indices]
        if src_colors.shape[1] == 3:
            colors[:, :3] = src_colors
            colors[:, 3] = 1.0
        else:
            colors[:] = src_colors

    # Global overrides
    colors[:, 3] *= layer.opacity
    if layer.color_override:
        co = np.array(layer.color_override, dtype=np.float32)
        colors[:, :3] = co[:3]
        if co.size > 3: colors[:, 3] = co[3]
        
    return colors

def compose_visual_state(
    scene: Any, 
    base_colors: np.ndarray, 
    base_radii: np.ndarray,
    semantic_groups: Dict[str, np.ndarray],
    layer_set: DisplayLayerSet,
    display_state: DisplayState,
    named_selection_set: Any = None,
    cache: Any = None,
    highlight_selection: bool = True
) -> VisualState:
    """
    Tier-2 Optimized Layer Compositor (Phase 5).
    """
    atom_colors = np.ones((scene.N, 4), dtype=np.float32)
    if base_colors.shape[1] == 3:
        atom_colors[:, :3] = base_colors
    else:
        atom_colors[:] = base_colors
    
    atom_radii = np.zeros(scene.N, dtype=np.float32)
    bond_vis = np.zeros(getattr(scene, "bond_count", 0), dtype=bool)
    hidden_mask = np.ones(scene.N, dtype=bool)
    bondable_atoms = np.zeros(scene.N, dtype=bool)
    ribbon_requests = []
    
    for layer in layer_set.sorted_items():
        if not (layer.visible and layer.enabled): continue
            
        # 1. Resolve Selector (Tier-1 Cache)
        s_hash = get_selector_hash(layer.selector)
        indices = cache.get_selector(s_hash) if cache else None
        if indices is None:
             indices = resolve_selector(scene, semantic_groups, layer.selector, named_selection_set)
             if cache: cache.set_selector(s_hash, indices)

        if indices.size == 0: continue
            
        # 2. Apply Contribution (Tier-2 Cache)
        l_hash = get_layer_hash(layer)
        contrib = cache.get_contribution(l_hash) if cache else None
        
        if contrib is None:
            # Recompute layer visual contribution
            kind = layer.style.kind
            if kind == "hidden":
                l_radii = np.zeros(indices.size)
                l_colors = atom_colors[indices] # keep current but we'll mask it
                l_bondable = False
                l_hidden = True
            elif kind == "ribbon":
                l_radii = np.zeros(indices.size)
                l_colors = apply_color_policy(scene, indices, layer, base_colors)
                l_bondable = False
                l_hidden = layer.get_param("hide_atoms", True)
            else:
                l_radii = apply_radius_policy(scene, indices, layer, display_state, base_radii)
                l_colors = apply_color_policy(scene, indices, layer, base_colors)
                l_bondable = True
                l_hidden = False
            
            contrib = {"radii": l_radii, "colors": l_colors, "bondable": l_bondable, "hidden": l_hidden}
            if cache: cache.set_contribution(l_hash, contrib)

        # 3. Splat Contribution into Global Arrays
        atom_radii[indices] = contrib["radii"]
        atom_colors[indices] = contrib["colors"]
        hidden_mask[indices] = contrib["hidden"]
        if contrib["bondable"]: bondable_atoms[indices] = True
        
        if layer.style.kind == "ribbon":
            ribbon_requests.append({"layer_id": layer.id, "indices": indices, "params": layer.style.params})

    # ... Remaining (Bonds, Clipping, Highlighter) ...
    if bondable_atoms.any() and hasattr(scene, "bonds") and scene.bonds is not None:
        bonds = np.array(scene.bonds)
        if bonds.ndim == 2 and bonds.shape[0] > 0:
            b_idx1, b_idx2 = bonds[:, 0].astype(np.int32), bonds[:, 1].astype(np.int32)
            
            # Filter out-of-bounds indices to prevent IndexError during frame transitions
            valid = (b_idx1 < scene.N) & (b_idx2 < scene.N)
            bond_vis = np.zeros(bonds.shape[0], dtype=bool)
            bond_vis[valid] = bondable_atoms[b_idx1[valid]] & bondable_atoms[b_idx2[valid]]

    # Clipping & Highlighter
    from .atom_visuals import apply_clipping_mask
    clipped_mask = apply_clipping_mask(scene.pos, scene.lat, atom_colors, display_state) if display_state.clipping_enabled else np.zeros(scene.N, dtype=bool)
    
    if highlight_selection and hasattr(scene, "selected_atoms") and scene.selected_atoms:
        for idx in scene.selected_atoms:
            if 0 <= idx < scene.N:
                atom_colors[idx] = [1.0, 0.9, 0.1, 1.0] ; hidden_mask[idx] = False
                if atom_radii[idx] == 0: atom_radii[idx] = 0.2 * display_state.atom_scale

    return VisualState(scene.pos, atom_radii, atom_colors, 
                       bonds=getattr(scene, "bonds", None), 
                       bond_count=getattr(scene, "bond_count", 0),
                       lattice=getattr(scene, "lat", None),
                       clipped_mask=clipped_mask, 
                       hidden_mask=hidden_mask, 
                       metadata={"bond_visibility_mask": bond_vis, "ribbon_requests": ribbon_requests, "layer_set": layer_set})
