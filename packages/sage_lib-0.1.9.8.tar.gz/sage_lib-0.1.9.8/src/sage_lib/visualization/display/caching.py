from __future__ import annotations
import numpy as np
import hashlib
from typing import Any, Dict, Optional

class DisplayCache:
    """
    Multi-tier Performance Cache for SAGE (Sprint 5.8).
    - Tier 1: Selection Cache (resolved atomic indices)
    - Tier 2: Contribution Cache (full color/radius arrays per layer)
    - Tier 3: Geometry Cache (ribbon/mesh metadata)
    """
    def __init__(self):
        self._selectors: Dict[str, np.ndarray] = {}
        self._contributions: Dict[str, Any] = {}
        self._ribbons: Dict[str, Any] = {}
        self._current_sig: Any = None

    def clear(self):
        self._selectors.clear()
        self._contributions.clear()
        self._ribbons.clear()

    def check_invalid(self, structure_signature: Any):
        """Standard cache invalidation on structure change."""
        if structure_signature != self._current_sig:
            self.clear()
            self._current_sig = structure_signature

    def get_selector(self, key: str) -> Optional[np.ndarray]:
        return self._selectors.get(key)

    def set_selector(self, key: str, indices: np.ndarray):
        self._selectors[key] = indices

    def get_contribution(self, key: str) -> Optional[Any]:
        return self._contributions.get(key)

    def set_contribution(self, key: str, value: Any):
        self._contributions[key] = value
        
    def get_ribbon(self, key: str) -> Optional[Any]:
        return self._ribbons.get(key)
        
    def set_ribbon(self, key: str, value: Any):
        self._ribbons[key] = value

def get_selector_hash(selector: Any, named_sel_hash: str = "") -> str:
    """Stable key for selection queries."""
    s = f"{selector.kind}_{selector.value}_{selector.params}_{named_sel_hash}"
    return hashlib.md5(s.encode()).hexdigest()

def get_layer_hash(layer: Any) -> str:
    """Stable key for a layer's style and visual parameters."""
    s = f"{layer.id}_{layer.style.kind}_{layer.style.params}_{layer.opacity}_{layer.color_override}"
    return hashlib.md5(s.encode()).hexdigest()

def get_ribbon_hash(indices: np.ndarray, params: Dict[str, Any]) -> str:
    """Stable key for ribbon geometry generation."""
    idx_hash = hashlib.md5(indices.tobytes()).hexdigest()
    param_str = json.dumps(params, sort_keys=True)
    return hashlib.md5(f"{idx_hash}_{param_str}".encode()).hexdigest()
