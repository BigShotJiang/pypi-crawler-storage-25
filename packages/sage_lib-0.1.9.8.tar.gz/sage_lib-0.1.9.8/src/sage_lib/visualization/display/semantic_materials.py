from __future__ import annotations
import numpy as np
from typing import Dict, Any

def classify_material_groups(scene: Any, groups: Dict[str, np.ndarray]):
    """Refines semantic groups for periodic materials and layered structures."""
    if not scene.is_periodic:
        return

    elements = np.array(scene.elements)
    def mask_to_idx(mask): return np.where(mask)[0].astype(np.int32)
    
    is_sol = np.zeros(scene.N, dtype=bool)
    is_lig = np.zeros(scene.N, dtype=bool)
    # Materials context for ligand/solvent detection via heuristics
    if "solvent" in groups:
        is_sol[groups["solvent"]] = True
    if "ligands" in groups:
        is_lig[groups["ligands"]] = True

    # High-level Materials Framework
    # Framework = Not solvent, not ligand heavy atoms
    is_framework = ~(is_sol | is_lig)
    groups["framework"] = mask_to_idx(is_framework)
    
    # Layered material specialization
    # Interlayer = solvent, ions, adsorbed molecules
    groups["interlayer"] = mask_to_idx(is_sol | is_lig)

    # Surface Heuristics (Top/Bottom)
    pos = scene.pos
    if scene.lat is not None:
        # Check Z dimension for surface separation
        z_vals = pos[:, 2]
        z_min, z_max = np.min(z_vals), np.max(z_vals)
        z_thick = z_max - z_min
        if z_thick > 2.0:
            top_mask = z_vals > (z_max - 3.0) # Atoms in top 3A
            bot_mask = z_vals < (z_min + 3.0) # Atoms in bot 3A
            groups["surface_top"] = mask_to_idx(top_mask)
            groups["surface_bottom"] = mask_to_idx(bot_mask)

    # Dopants: Minority species in the framework 
    if groups["framework"].size > 10:
        fw_elements = elements[groups["framework"]]
        unique, counts = np.unique(fw_elements, return_counts=True)
        if len(unique) > 1:
            minor_elements = unique[counts < (len(fw_elements) * 0.1)]
            is_dopant = np.zeros(scene.N, dtype=bool)
            for el in minor_elements:
                is_dopant |= (elements == el)
            groups["dopants"] = mask_to_idx(is_dopant)
