from __future__ import annotations
import numpy as np
import time
from typing import List, Dict, Any, Optional

from .id_manager import IdManager
from .edit_commands import EditCommand, MoveAtomsCommand, AddAtomsCommand, DeleteAtomsCommand, ChangeSpeciesCommand
from .chemistry_rules import ChemistryRules
from .placement_engine import PlacementEngine
from .validation import ValidationEngine
from .fragments import FragmentLibrary
from .relaxation_engine import RelaxationEngine
import scipy.spatial as spatial

class StructureEditor:
    """
    Main coordinator for structural modifications.
    Maintains the undo/redo stack and delegates work to specialized engines.
    """
    def __init__(self, scene):
        self.scene = scene
        self.id_mgr = IdManager(scene)
        self.rules = ChemistryRules()
        self.placement = PlacementEngine(scene, self.rules)
        self.validation = ValidationEngine(scene, self.rules)
        self.fragments = FragmentLibrary()
        self.relaxation = RelaxationEngine(scene, self.rules)
        
        # Performance Caching
        self.spatial_index: Optional[spatial.KDTree] = None
        self.last_report: Dict[str, Any] = {"valid": True, "errors": [], "warnings": []}
        self._validation_scheduled = False
        self._last_mod_time = 0.0
        self._debounce_time = 0.15 # 150ms
        
        self.rebuild_spatial_index()
        
        self.history: List[EditCommand] = []
        self.redo_stack: List[EditCommand] = []
        
        # Progressive Real-Time Relaxation Solver State
        self.relax_active = False
        self.relax_indices: List[int] = []
        self.relax_mode = "rigid"
        self.relax_steps_remaining = 0
        self.relax_state = None

    def commit_command(self, cmd: EditCommand, auto_relax: bool = False, relax_settings: Optional[dict] = None) -> bool:
        """Executes a command and pushes to history."""
        if cmd.execute(self.scene):
            # Auto-Relax Logic
            if auto_relax and isinstance(cmd, AddAtomsCommand):
                self.start_progressive_relaxation(cmd.ids, **(relax_settings or {}))
                
            self.history.append(cmd)
            self.redo_stack.clear()
            
            # Update caches
            self.rebuild_spatial_index()
            self.schedule_validation()
            return True
        return False

    def undo(self) -> bool:
        if not self.history: return False
        cmd = self.history.pop()
        if cmd.undo(self.scene):
            self.redo_stack.append(cmd)
            self.rebuild_spatial_index()
            self.schedule_validation()
            return True
        return False

    def redo(self) -> bool:
        if not self.redo_stack: return False
        cmd = self.redo_stack.pop()
        if cmd.execute(self.scene):
            self.history.append(cmd)
            self.rebuild_spatial_index()
            self.schedule_validation()
            return True
        return False

    def delete_selection(self) -> bool:
        """Helper to delete currently selected atoms via IDs."""
        if not self.scene.selected_atoms: return False
        
        # Capture IDs and exact state for backup
        target_ids = np.array(self.scene.selected_atoms, dtype=np.int64)
        indices = self.id_mgr.get_indices(target_ids)
        
        backup = {
            "pos": self.scene.pos[indices].copy(),
            "elements": [self.scene.elements[i] for i in indices],
            "radii": self.scene.radii[indices].copy(),
            "colors": self.scene.colors[indices].copy()
        }
        
        cmd = DeleteAtomsCommand(target_ids, backup)
        return self.commit_command(cmd)

    def clear_all_atoms(self) -> bool:
        """Deletes ALL atoms in the active structure to allow starting from scratch."""
        if self.scene.N == 0: return False
        
        all_ids = self.id_mgr.active_ids.copy()
        indices = np.arange(self.scene.N)
        
        backup = {
            "pos": self.scene.pos.copy(),
            "elements": list(self.scene.elements),
            "radii": self.scene.radii.copy(),
            "colors": self.scene.colors.copy()
        }
        
        cmd = DeleteAtomsCommand(all_ids, backup)
        success = self.commit_command(cmd)
        if success:
            self.scene.clear_selection()
        return success

    def change_selection_species(self, new_element: str) -> bool:
        if not self.scene.selected_atoms: return False
        target_ids = np.array(self.scene.selected_atoms, dtype=np.int64)
        indices = self.id_mgr.get_indices(target_ids)
        
        old_elements = [self.scene.elements[i] for i in indices]
        cmd = ChangeSpeciesCommand(target_ids, new_element, old_elements)
        return self.commit_command(cmd)

    def get_fragment_preview(self, category: str, name: str, target_ids: List[int], mode: str, manual_d: Optional[float] = None, roll: float = 0.0) -> Dict[str, Any]:
        """Calculates where a fragment would land."""
        frag = self.fragments.get_fragment(category, name)
        if not frag: return {"valid": False}
        
        # 1. Determine site
        if mode == "Molecular" and len(target_ids) == 1:
            indices = self.id_mgr.get_indices([target_ids[0]])
            if len(indices) == 0: return {"valid": False}
            idx = indices[0]
            pos, vec = self.placement.get_molecular_placement(idx, frag["elements"][frag["anchor_idx"]], manual_d)
        elif mode == "Materials" and len(target_ids) > 0:
            indices = self.id_mgr.get_indices(target_ids)
            pos, vec = self.placement.get_materials_placement(list(indices), frag["elements"][frag["anchor_idx"]], manual_d)
        else:
            # Free placement or fallback
            pos = np.array([0, 0, 0])
            vec = np.array([0, 0, 1])
            
        # 2. Align fragment coordinates
        f_pos = np.array(frag["pos"])
        aligned_pos = self.placement.align_fragment(f_pos, frag["anchor_idx"], frag["anchor_vector"], pos, vec, roll)
        
        return {
            "valid": True,
            "pos": aligned_pos,
            "elements": frag["elements"],
            "target_pos": pos,
            "target_vec": vec
        }

    def relax_atoms(self, atom_ids: List[int], mode: str = "rigid", steps: int = 50, relax_substrate: bool = False) -> bool:
        """Orchestrates the relaxation of specified atoms."""
        indices = self.id_mgr.get_indices(atom_ids)
        if len(indices) == 0: return False
        
        # Determine full set of indices to relax (including substrate shell if requested)
        relax_indices = list(indices)
        if relax_substrate:
            # Find neighbors of 'indices' within 4A
            from ..analysis.neighbor_engine import NeighborEngine
            i_env, j_env, _, _ = NeighborEngine.get_pair_displacements(
                self.scene.pos[indices], self.scene.lat, 4.0, self.scene.is_periodic, self.scene.pos
            )
            # j_env are neighbors in the full scene. Filter out original 'indices'
            orig_set = set(indices)
            neigh_set = set(j_env) - orig_set
            relax_indices.extend(list(neigh_set))
            
        print(f"[Editor] Relaxing {len(indices)} atoms (mode={mode}, shell={relax_substrate})...")
        success = self.relaxation.relax(relax_indices, mode.lower(), steps)
        
        if success:
            self.rebuild_spatial_index()
            self.schedule_validation()
        return success

    # --- Performance & Validation Orchestration ---

    def rebuild_spatial_index(self):
        """Rebuilds the KDTree for fast proximity checks."""
        if self.scene.N == 0:
            self.spatial_index = None
            return
        # Note: We use absolute positions for the index. 
        # For PBC, NeighborEngine handles it, but for ghost-clash, we use MIC manually if needed.
        self.spatial_index = spatial.KDTree(self.scene.pos)

    def schedule_validation(self):
        """Marks that the scene needs an expensive validation pass."""
        self._validation_scheduled = True
        self._last_mod_time = time.time()

    def run_validation_if_due(self):
        """Runs the validation engine if the debounce period has passed."""
        if not self._validation_scheduled:
            return
            
        if (time.time() - self._last_mod_time) > self._debounce_time:
            self.last_report = self.validation.validate_scene()
            self._validation_scheduled = False

    def check_proximity(self, test_pos: np.ndarray, test_radii: np.ndarray, tolerance: float = 0.7) -> bool:
        """
        Fast interaction-time check for severe clashes.
        Returns True if a severe clash exists.
        """
        if self.spatial_index is None:
            return False
            
        # Search for any scene atoms within a conservative ball of the test atoms
        # test_pos can be a fragment (M x 3)
        for i, p in enumerate(test_pos):
            # Find neighbors within 2.0A (conservative)
            indices = self.spatial_index.query_ball_point(p, 2.0)
            if not indices: continue
            
            # Strict distance check (sum of radii * tolerance)
            dists = np.linalg.norm(self.scene.pos[indices] - p, axis=1)
            min_allowed = (self.scene.radii[indices] + test_radii[i]) * tolerance
            if np.any(dists < min_allowed):
                return True
        return False

    def start_progressive_relaxation(self, atom_ids: List[int], mode: str = "rigid", steps: int = 150, relax_substrate: bool = False):
        """Prepares and activates the real-time progressive relaxation loop."""
        indices = self.id_mgr.get_indices(atom_ids)
        if len(indices) == 0:
            self.relax_active = False
            return
        
        relax_indices = list(indices)
        if relax_substrate:
            from ..analysis.neighbor_engine import NeighborEngine
            i_env, j_env, _, _ = NeighborEngine.get_pair_displacements(
                self.scene.pos[indices], self.scene.lat, 4.0, self.scene.is_periodic, self.scene.pos
            )
            orig_set = set(indices)
            neigh_set = set(j_env) - orig_set
            relax_indices.extend(list(neigh_set))
            
        self.relax_indices = relax_indices
        self.relax_mode = mode
        self.relax_steps_remaining = steps
        self.relax_state = None
        self.relax_active = True
        print(f"[Editor] Initialized progressive relaxation for {len(relax_indices)} atoms (mode={mode}).")

    def step_progressive_relaxation(self) -> bool:
        """
        Executes a single step of active progressive relaxation.
        To maintain absolute fluid UI, we only run 1 optimization step.
        Returns True if still active, False if finished/converged.
        """
        if not self.relax_active or self.relax_steps_remaining <= 0 or not self.relax_indices:
            self.relax_active = False
            return False
            
        # Run 1 step of optimization
        converged, self.relax_state = self.relaxation.relax_step(
            self.relax_indices, mode=self.relax_mode, state=self.relax_state
        )
        
        self.relax_steps_remaining -= 1
        
        # When completed or converged
        if converged or self.relax_steps_remaining <= 0:
            self.relax_active = False
            self.rebuild_spatial_index()
            self.schedule_validation()
            print(f"[Editor] Progressive relaxation finished (converged={converged}, remaining_steps={self.relax_steps_remaining}).")
            return False
            
        return True
