from __future__ import annotations
import numpy as np
from typing import List, Dict, Any, Tuple, Optional
from ..scene import Scene
from .chemistry_rules import ChemistryRules
from ..analysis.neighbor_engine import NeighborEngine

class RelaxationEngine:
    """
    Lightweight geometric stabilizer using the FIRE (Fast Inertial Relaxation Engine) 
    optimizer and a simplified Universal Force Field (UFF) potential.
    """
    def __init__(self, scene: Scene, rules: ChemistryRules):
        self.scene = scene
        self.rules = rules
        
        # Hyperparameters
        self.k_bond = 35.0    # eV/A^2 (Gentle covalent guidance)
        self.epsilon = 0.15   # eV (Smooth, gentle repulsion to prevent explosive flinging)
        self.r_cut = 4.0      # A
        self.r_in = 3.2       # A (Start smoothing)
        
        # FIRE Optimizer Settings
        self.dt_max = 0.1
        self.dt_min = 0.01
        self.N_min = 5
        self.f_inc = 1.1
        self.f_dec = 0.5
        self.alpha_start = 0.1
        self.f_alpha = 0.99
        
    def _get_smoothing(self, r: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Returns quintic spline smoothing factor and its derivative."""
        val = np.ones_like(r)
        der = np.zeros_like(r)
        
        mask = (r > self.r_in) & (r < self.r_cut)
        if not np.any(mask):
            return val, der
            
        x = (r[mask] - self.r_in) / (self.r_cut - self.r_in)
        # Quintic spline: 1 - (10x^3 - 15x^4 + 6x^5)
        # Smoothly goes from 1 to 0 with 0 first/second derivatives at ends
        s = 1.0 - (10*x**3 - 15*x**4 + 6*x**5)
        ds_dx = -(30*x**2 - 60*x**3 + 30*x**4)
        dx_dr = 1.0 / (self.r_cut - self.r_in)
        
        val[mask] = s
        der[mask] = ds_dx * dx_dr
        
        val[r >= self.r_cut] = 0.0
        der[r >= self.r_cut] = 0.0
        return val, der

    def compute_forces(self, 
                      indices: List[int], 
                      pos: np.ndarray, 
                      is_flexible: bool = True,
                      relax_substrate: bool = False) -> np.ndarray:
        """
        Calculates total forces on the specified atoms.
        If flexible=False, torque and CM-force will be derived later for rigid-body motion.
        """
        forces = np.zeros_like(pos)
        N_relax = len(indices)
        
        # 1. Repulsion from Environment (MIC aware)
        # We search neighbors for the relaxing atoms in the full scene
        i_env, j_env, vecs, dists = NeighborEngine.get_pair_displacements(
            pos, self.scene.lat, self.r_cut, self.scene.is_periodic, self.scene.pos
        )
        
        # Filter: j_env must not be in the 'indices' list to avoid double counting internal forces
        relax_set = set(indices)
        is_env = np.array([j not in relax_set for j in j_env], dtype=bool)
        
        i_f = i_env[is_env]
        j_f = j_env[is_env]
        v_f = vecs[is_env]
        d_f = dists[is_env]
        
        if len(i_f) > 0:
            # Species-aware sigma
            # sig = (r_i + r_j)
            elements_i = [self.scene.elements[indices[k]] for k in i_f]
            elements_j = [self.scene.elements[k] for k in j_f]
            
            sigmas = np.array([self.rules.get_bond_length(ei, ej) for ei, ej in zip(elements_i, elements_j)])
            
            # Repulsion Potential: (sig/r)^12
            # Force: -dV/dr * (vec/r) = 12 * eps * (sig^12 / r^13) * (vec/r)
            s_r = sigmas / d_f
            rep_mag = 12.0 * self.epsilon * (s_r**12) / d_f
            
            # Smoothing
            s_val, s_der = self._get_smoothing(d_f)
            # V_total = V_rep * S
            # F_total = -(dV_rep/dr * S + V_rep * dS/dr)
            v_rep = self.epsilon * (s_r**12)
            f_mag_smoothed = rep_mag * s_val - v_rep * s_der
            
            # Accumulate on 'i' (the relaxing atoms)
            for k in range(len(i_f)):
                forces[i_f[k]] -= (v_f[k] / d_f[k]) * f_mag_smoothed[k]

        # 2. Intra-fragment Bonds (Only if flexible)
        if is_flexible and N_relax > 1:
            # For now, we assume a simple 'all-pairs' bond network within fragment 
            # for small groups, or a more curated one if we had a bond graph.
            # Simplified: Use standard covalent distances for closely placed internal pairs
            for a in range(N_relax):
                for b in range(a + 1, N_relax):
                    v = pos[b] - pos[a]
                    d = np.linalg.norm(v)
                    r0 = self.rules.get_bond_length(self.scene.elements[indices[a]], self.scene.elements[indices[b]])
                    
                    if d < r0 * 1.3: # Only bonded or near-bonded pairs
                        f_mag = self.k_bond * (d - r0)
                        f_vec = (v / d) * f_mag
                        forces[a] += f_vec
                        forces[b] -= f_vec
                        
        return forces

    def relax(self, 
              indices: List[int], 
              mode: str = "rigid", 
              steps: int = 50,
              f_tol: float = 0.01) -> bool:
        """
        Runs the FIRE optimization loop.
        """
        if not indices: return False
        indices = list(indices)
        pos = self.scene.pos[indices].copy()
        vel = np.zeros_like(pos)
        
        # FIRE state vars
        dt = self.dt_min
        N_pos = 0
        alpha = self.alpha_start
        
        is_rigid = (mode == "rigid")
        cm = np.mean(pos, axis=0)
        rel_pos = pos - cm
        
        best_energy = float('inf')
        best_pos = pos.copy()
        
        max_dr = 0.04 # Gentle displacement damping to guarantee ultra-stable, smooth updates
        
        for step in range(steps):
            f = self.compute_forces(indices, pos, is_flexible=(not is_rigid))
            
            if is_rigid:
                # 1. Total Force on CM
                f_cm = np.sum(f, axis=0)
                # 2. Torque
                torque = np.sum(np.cross(rel_pos, f), axis=0)
                
                # Apply Rigid Body Dynamics
                # Simplified: update translation of all, and rotation of all
                # In building mode, we can just treat it as a constrained point set
                mass_total = len(pos)
                accel_cm = f_cm / mass_total
                
                # Update velocity and position (Semi-implicit Euler or MD step)
                vel_cm = np.mean(vel, axis=0)
                vel_cm += 0.5 * accel_cm * dt
                
                dr = vel_cm * dt
                # Clamp dr
                dr_mag = np.linalg.norm(dr)
                if dr_mag > max_dr: dr *= (max_dr / dr_mag)
                
                pos += dr
                cm += dr
                
                # Simple rotation integration (approximate)
                if np.linalg.norm(torque) > 1e-6:
                    omega = torque * 0.1 * dt # Moment of inertia approx
                    # Clamp rotation
                    om_mag = np.linalg.norm(omega)
                    if om_mag > 0.05: omega *= (0.05 / om_mag) # Max 0.05 rad/step
                    
                    from scipy.spatial.transform import Rotation
                    rot = Rotation.from_rotvec(omega)
                    rel_pos = rot.apply(rel_pos)
                    pos = cm + rel_pos
                    
                # Synchronize rigid velocities for FIRE power calculation
                # (Simple CM velocity for FIRE logic)
                vel = np.tile(vel_cm, (len(pos), 1))
            else:
                # Flexible / Standard FIRE
                # Power P = F . V
                f_flat = f.flatten()
                v_flat = vel.flatten()
                P = np.dot(f_flat, v_flat)
                
                if P > 0:
                    # Accelerate
                    vel = (1.0 - alpha) * vel + alpha * (f / (np.linalg.norm(f) + 1e-8)) * np.linalg.norm(vel)
                    if N_pos > self.N_min:
                        dt = min(dt * self. f_inc, self.dt_max)
                        alpha *= self.f_alpha
                    N_pos += 1
                else:
                    # Decelerate / Freeze
                    vel[:] = 0.0
                    dt = max(dt * self.f_dec, self.dt_min)
                    alpha = self.alpha_start
                    N_pos = 0
                
                # Standard MD integration
                vel += 0.5 * f * dt
                dr = vel * dt
                # Clamp
                for i in range(len(dr)):
                    dm = np.linalg.norm(dr[i])
                    if dm > max_dr: dr[i] *= (max_dr / dm)
                    
                pos += dr
                
            # Convergence check
            f_max = np.max(np.linalg.norm(f, axis=1))
            if f_max < f_tol:
                break
                
        # Commit result
        self.scene.pos[indices] = pos
        return True

    def relax_step(self, 
                 indices: List[int], 
                 mode: str = "rigid", 
                 state: Optional[Dict[str, Any]] = None) -> Tuple[bool, Dict[str, Any]]:
        """
        Executes a SINGLE STEP of the FIRE optimization loop.
        Returns (converged, updated_state).
        """
        if not indices: return True, {}
        indices = list(indices)
        pos = self.scene.pos[indices].copy()
        
        # Initialize state if not present
        if state is None or 'vel' not in state or len(state['vel']) != len(pos):
            state = {
                'vel': np.zeros_like(pos),
                'dt': self.dt_min,
                'N_pos': 0,
                'alpha': self.alpha_start,
                'cm': np.mean(pos, axis=0),
                'rel_pos': pos - np.mean(pos, axis=0),
            }
        
        vel = state['vel']
        dt = state['dt']
        N_pos = state['N_pos']
        alpha = state['alpha']
        cm = state['cm']
        rel_pos = state['rel_pos']
        
        is_rigid = (mode.lower() == "rigid")
        max_dr = 0.04 # Match gentle damping
        
        f = self.compute_forces(indices, pos, is_flexible=(not is_rigid))
        
        if is_rigid:
            # CM force
            f_cm = np.sum(f, axis=0)
            # Torque
            torque = np.sum(np.cross(rel_pos, f), axis=0)
            
            mass_total = len(pos)
            accel_cm = f_cm / mass_total
            
            vel_cm = np.mean(vel, axis=0)
            vel_cm += 0.5 * accel_cm * dt
            
            dr = vel_cm * dt
            dr_mag = np.linalg.norm(dr)
            if dr_mag > max_dr: dr *= (max_dr / dr_mag)
            
            pos += dr
            cm += dr
            
            if np.linalg.norm(torque) > 1e-6:
                omega = torque * 0.1 * dt
                om_mag = np.linalg.norm(omega)
                if om_mag > 0.05: omega *= (0.05 / om_mag)
                
                from scipy.spatial.transform import Rotation
                rot = Rotation.from_rotvec(omega)
                rel_pos = rot.apply(rel_pos)
                pos = cm + rel_pos
                
            vel = np.tile(vel_cm, (len(pos), 1))
        else:
            # Flexible / Standard FIRE
            f_flat = f.flatten()
            v_flat = vel.flatten()
            P = np.dot(f_flat, v_flat)
            
            if P > 0:
                vel = (1.0 - alpha) * vel + alpha * (f / (np.linalg.norm(f) + 1e-8)) * np.linalg.norm(vel)
                if N_pos > self.N_min:
                    dt = min(dt * self.f_inc, self.dt_max)
                    alpha *= self.f_alpha
                N_pos += 1
            else:
                vel[:] = 0.0
                dt = max(dt * self.f_dec, self.dt_min)
                alpha = self.alpha_start
                N_pos = 0
            
            vel += 0.5 * f * dt
            dr = vel * dt
            for i in range(len(dr)):
                dm = np.linalg.norm(dr[i])
                if dm > max_dr: dr[i] *= (max_dr / dm)
                
            pos += dr
            
        # Update scene position
        self.scene.pos[indices] = pos
        
        # Check convergence
        f_max = np.max(np.linalg.norm(f, axis=1))
        converged = (f_max < 0.01)
        
        # Save updated state
        new_state = {
            'vel': vel,
            'dt': dt,
            'N_pos': N_pos,
            'alpha': alpha,
            'cm': cm,
            'rel_pos': rel_pos
        }
        return converged, new_state
