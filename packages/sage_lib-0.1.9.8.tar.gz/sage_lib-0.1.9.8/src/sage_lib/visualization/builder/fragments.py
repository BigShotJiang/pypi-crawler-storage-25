from __future__ import annotations
import numpy as np
from typing import Dict, List, Any, Tuple

class FragmentLibrary:
    """
    Registry of smart structural fragments for both molecular and materials science.
    All fragments are centered on their anchor atom at [0, 0, 0].
    'anchor_vector' is the unit vector of the prospective bond pointing OUT of the fragment.
    """
    def __init__(self):
        # Coordinates in Angstroms
        self.LIBRARY = {
            "Metales / Atoms": {
                "H": {"elements": ["H"], "pos": [[0,0,0]], "anchor_idx": 0, "anchor_vector": [1,0,0]},
                "O": {"elements": ["O"], "pos": [[0,0,0]], "anchor_idx": 0, "anchor_vector": [1,0,0]},
                "C": {"elements": ["C"], "pos": [[0,0,0]], "anchor_idx": 0, "anchor_vector": [1,0,0]},
                "Cu": {"elements": ["Cu"], "pos": [[0,0,0]], "anchor_idx": 0, "anchor_vector": [1,0,0]},
            },
            "Organic Groups": {
                "Methyl (-CH3)": {
                    "elements": ["C", "H", "H", "H"],
                    "pos": [[0.00,  0.00,  0.00], [0.63,  0.89,  0.00], [0.63, -0.45,  0.77], [0.63, -0.45, -0.77]],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 0.0, 0.0]
                },
                "Ethyl (-C2H5)": {
                    "elements": ["C", "C", "H", "H", "H", "H", "H"],
                    "pos": [
                        [0.00, 0.00, 0.00], [1.54, 0.00, 0.00],
                        [-0.51, 0.89, 0.00], [-0.51, -0.45, 0.77],
                        [2.05, 0.89, 0.00], [2.05, -0.45, 0.77], [2.05, -0.45, -0.77]
                    ], # Simplified centers
                    "anchor_idx": 0, "anchor_vector": [-0.5, 0.0, 0.86]
                },
                "Phenyl (-C6H5)": {
                    "elements": ["C"]*6 + ["H"]*5,
                    "pos": [
                        [0.00, 0.00, 0.00], [0.69, 1.20, 0.0], [2.09, 1.20, 0.0],
                        [2.79, 0.0, 0.0], [2.09, -1.20, 0.0], [0.69, -1.20, 0.0],
                        [0.15, 2.15, 0.0], [2.63, 2.15, 0.0], [3.88, 0.0, 0.0],
                        [2.63, -2.15, 0.0], [0.15, -2.15, 0.0]
                    ],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 0.0, 0.0]
                },
                "Hydroxyl (-OH)": {
                    "elements": ["O", "H"],
                    "pos": [[0.00, 0.00, 0.00], [0.81, 0.52, 0.00]],
                    "anchor_idx": 0, "anchor_vector": [-0.85, 0.0, 0.0]
                },
                "Nitro (-NO2)": {
                    "elements": ["N", "O", "O"],
                    "pos": [[0.00, 0.00, 0.00], [0.62, 1.08, 0.00], [0.62, -1.08, 0.00]],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 0.0, 0.0]
                },
                "Cyano (-CN)": {
                    "elements": ["C", "N"],
                    "pos": [[0.00, 0.00, 0.00], [1.16, 0.00, 0.00]],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 0.0, 0.0]
                },
                "Thiol (-SH)": {
                    "elements": ["S", "H"],
                    "pos": [[0.00, 0.00, 0.00], [1.1, 0.77, 0.00]],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 0.0, 0.0]
                },
                "Amine (-NH2)": {
                    "elements": ["N", "H", "H"],
                    "pos": [[0.00, 0.00, 0.00], [0.81, 0.52, 0.28], [0.81, -0.52, 0.28]],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 0.0, 0.0]
                },
                "Carboxyl (-COOH)": {
                    "elements": ["C", "O", "O", "H"],
                    "pos": [[0.00, 0.00, 0.00], [1.15, 0.45, 0.00], [-0.30, -1.20, 0.00], [-1.25, -1.30, 0.00]],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 1.0, 0.0]
                },
                "Carbonyl (-CO-)": {
                    "elements": ["C", "O"],
                    "pos": [[0.0, 0.0, 0.0], [0.0, 1.22, 0.0]],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 0.0, 0.0]
                },
                "Ether (-O-)": {
                    "elements": ["O"],
                    "pos": [[0.0, 0.0, 0.0]],
                    "anchor_idx": 0, "anchor_vector": [1.0, 0.0, 0.0]
                },
                "Trifluoromethyl (-CF3)": {
                    "elements": ["C", "F", "F", "F"],
                    "pos": [[0.0,0.0,0.0], [0.67,0.95,0.0], [0.67,-0.47,0.82], [0.67,-0.47,-0.82]],
                    "anchor_idx": 0, "anchor_vector": [-1.0,0.0,0.0]
                },
                "t-Butyl (-C(CH3)3)": {
                    "elements": ["C", "C", "C", "C", "H", "H", "H", "H", "H", "H", "H", "H", "H"],
                    "pos": [[0,0,0], [1.53,0,0], [-0.51,1.44,0], [-0.51,-0.72,1.25], [2.05,0.89,0], [2.05,-0.45,0.77], [2.05,-0.45,-0.77], [-0.15,2.02,0.77], [-1.6,1.44,0], [-0.15,2.02,-0.77], [-0.15,-1.31,0.77], [-0.15,-1.31,-0.77], [-1.6,-0.72,1.25]],
                    "anchor_idx": 0, "anchor_vector": [-1.0,0.0,0.0]
                }
            },
            "Molecules / Adsorbates": {
                "Water (H2O)": {
                    "elements": ["O", "H", "H"],
                    "pos": [[0.00, 0.00, 0.00], [0.81, 0.52, 0.00], [-0.81, 0.52, 0.00]],
                    "anchor_idx": 0, "anchor_vector": [0.0, -1.0, 0.0]
                },
                "Methane (CH4)": {
                    "elements": ["C", "H", "H", "H", "H"],
                    "pos": [[0,0,0], [0.63,0.63,0.63], [0.63,-0.63,-0.63], [-0.63,0.63,-0.63], [-0.63,-0.63,0.63]],
                    "anchor_idx": 0, "anchor_vector": [1, 0, 0]
                },
                "Ammonia (NH3)": {
                    "elements": ["N", "H", "H", "H"],
                    "pos": [[0,0,0], [0.94,0,0.34], [-0.47,0.81,0.34], [-0.47,-0.81,0.34]],
                    "anchor_idx": 0, "anchor_vector": [0, 0, -1.0]
                },
                "Carbon Monoxide (CO)": {
                    "elements": ["C", "O"],
                    "pos": [[0,0,0], [0,0,1.13]],
                    "anchor_idx": 0, "anchor_vector": [0, 0, -1.0]
                },
                "Benzene": {
                    "elements": ["C"]*6 + ["H"]*6,
                    "pos": [
                        [1.39, 0.0, 0.0], [0.69, 1.20, 0.0], [-0.69, 1.20, 0.0],
                        [-1.39, 0.0, 0.0], [-0.69, -1.20, 0.0], [0.69, -1.20, 0.0],
                        [2.48, 0.0, 0.0], [1.24, 2.15, 0.0], [-1.24, 2.15, 0.0],
                        [-2.48, 0.0, 0.0], [-1.24, -2.15, 0.0], [1.24, -2.15, 0.0]
                    ],
                    "anchor_idx": 0, "anchor_vector": [1.0, 0.0, 0.0]
                },
                "Carbon Dioxide (CO2)": {
                    "elements": ["C", "O", "O"],
                    "pos": [[0,0,0], [0,0,1.16], [0,0,-1.16]],
                    "anchor_idx": 0, "anchor_vector": [1.0, 0.0, 0.0]
                },
                "Methanol (CH3OH)": {
                    "elements": ["C", "O", "H", "H", "H", "H"],
                    "pos": [[0,0,0], [1.42,0,0], [-0.37,0.89,0.51], [-0.37,-0.89,0.51], [-0.37,0,-1.02], [1.8,0.8,0.2]],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 0.0, 0.0]
                },
                "Ethanol (C2H5OH)": {
                    "elements": ["C", "C", "O", "H", "H", "H", "H", "H", "H"],
                    "pos": [[0,0,0], [1.53,0,0], [2.1,1.38,0], [3.06,1.38,0], [-0.38,0.89,0.5], [-0.38,-0.89,0.5], [-0.38,0,-1.0], [1.9,-0.5,0.8], [1.9,-0.5,-0.8]],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 0.0, 0.0]
                }
            },
            "Nanostructures & Clusters": {
                "Pt Cluster (Pt3)": {
                    "elements": ["Pt", "Pt", "Pt"],
                    "pos": [[0,0,0], [2.77,0,0], [1.38,2.4,0]],
                    "anchor_idx": 0, "anchor_vector": [0.0, -1.0, 0.0]
                },
                "Graphene sheet unit": {
                    "elements": ["C", "C", "C", "C", "C", "C"],
                    "pos": [[0,0,0], [1.42,0,0], [2.13,1.23,0], [1.42,2.46,0], [0,2.46,0], [-0.71,1.23,0]],
                    "anchor_idx": 0, "anchor_vector": [-1.0, 0.0, 0.0]
                }
            }
        }

    def get_fragment(self, category: str, name: str) -> Optional[Dict[str, Any]]:
        return self.LIBRARY.get(category, {}).get(name)

    def list_categories(self) -> List[str]:
        return list(self.LIBRARY.keys())

    def list_fragments(self, category: str) -> List[str]:
        return list(self.LIBRARY.get(category, {}).keys())
