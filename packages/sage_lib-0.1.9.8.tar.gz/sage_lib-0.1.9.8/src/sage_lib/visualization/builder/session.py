from __future__ import annotations
from enum import Enum

class InteractionState(Enum):
    IDLE = 0
    GRABBING = 1      # Translating in view plane
    ROTATING = 2      # Rotating around anchor
    DEPTH_ADJUST = 3  # Moving along view ray
    PLACED = 4        # Static preview ready to commit

class StructureSession:
    """
    Manages the transient interactive state of the Structural Workshop.
    Does NOT modify the scene directly; only prepares ghost data.
    """
    MODES = ["Molecular", "Materials", "Free"]
    TOOLS = ["Select", "Move", "Rotate", "Add Atom", "Add Group", "Change Type", "Measure"]
    
    def __init__(self):
        # Global Settings
        self.active_mode = "Molecular"
        self.active_tool = "Select"
        self.collision_policy = "Warn" # Block, Warn, Ignore
        
        # Interaction State Machine
        self.interaction_state = InteractionState.IDLE
        self.ghost_clash = False # Result of fast proximity check
        
        # Site Parameters
        self.manual_distance = 1.8
        self.use_manual_distance = True
        self.roll_angle = 0.0
        
        # Relaxation Settings
        self.auto_relax = False
        self.relaxation_mode = "Rigid" 
        self.relax_substrate = False
        self.relaxation_steps = 50
        
        # Ghost State (Pre-commit)
        self.ghost_id = -1
        self.ghost_pos: Optional[np.ndarray] = None
        self.ghost_elements: List[str] = []
        self.ghost_anchor_idx = 0
        self.target_atom_ids: List[int] = [] # Persistent IDs
        
        # Hover info
        self.hovered_atom_id = -1
        
        # Add-group state
        self.selected_fragment_category = ""
        self.selected_fragment_name = ""
        self.selected_atom_species = "C"

    def reset_ghost(self):
        self.ghost_pos = None
        self.ghost_elements = []
        self.target_atom_ids = []
        self.roll_angle = 0.0

    def set_tool(self, tool_name: str):
        if tool_name in self.TOOLS:
            self.active_tool = tool_name
            self.reset_ghost()

    def set_mode(self, mode_name: str):
        if mode_name in self.MODES:
            self.active_mode = mode_name
            self.reset_ghost()
