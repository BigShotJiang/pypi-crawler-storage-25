from __future__ import annotations
import numpy as np
from typing import Dict, Tuple, Optional
from ..constants import ATOMIC_RADII

class ChemistryRules:
    """
    Database of standard bond lengths and radii used for smart placement.
    """
    def __init__(self):
        # Specific overrides for common pairs (Single Bonds, in Angstroms)
        self.BOND_LENGTHS: Dict[Tuple[str, str], float] = {
            ("C", "C"): 1.54,
            ("C", "H"): 1.09,
            ("C", "O"): 1.43,
            ("C", "N"): 1.47,
            ("N", "H"): 1.01,
            ("O", "H"): 0.96,
            ("S", "H"): 1.34,
            ("P", "O"): 1.63,
            ("Si", "O"): 1.63,
            ("Si", "Si"): 2.33,
            ("Cu", "O"): 1.95,
            ("Ni", "O"): 1.90,
        }
        
        # Standard Coordination Radii (Covalent)
        # Using SAGE's existing ATOMIC_RADII as a fallback if not explicitly defined
        self.COVALENT_RADII = ATOMIC_RADII.copy()

    def get_bond_length(self, element_a: str, element_b: str) -> float:
        """Returns the standard bond length for two elements."""
        # 1. Check explicit table (Sorted to handle both orders)
        pair = tuple(sorted([element_a, element_b]))
        if pair in self.BOND_LENGTHS:
            return self.BOND_LENGTHS[pair]
            
        # 2. Fallback to Covalent Radii Sum
        ra = self.COVALENT_RADII.get(element_a, 1.0)
        rb = self.COVALENT_RADII.get(element_b, 1.0)
        
        # Many datasets use VdW radii in ATOMIC_RADII. 
        # Covalent bonds are typically ~70-80% of VdW sum if not specialized.
        # But for SAGE, let's assume radii are already close to covalent for building
        # OR apply a slight scaling factor if we suspect they are VdW.
        return (ra + rb) * 0.9 # Conservative estimate for bond length

    def get_clash_distance(self, element_a: str, element_b: str) -> float:
        """Minimum distance to consider a 'clash' (collision)."""
        # Typically ~60% of the sum of radii or bond length
        return self.get_bond_length(element_a, element_b) * 0.6
