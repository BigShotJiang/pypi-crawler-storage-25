from __future__ import annotations
import numpy as np
from typing import List, Dict, Any, Optional, Sequence

class EditCommand:
    """Base class for all structural mutations."""
    def execute(self, scene) -> bool: raise NotImplementedError
    def undo(self, scene) -> bool: raise NotImplementedError

class MoveAtomsCommand(EditCommand):
    """Moves atoms by a vector. Reversible."""
    def __init__(self, atom_ids: Sequence[int], delta: np.ndarray):
        self.ids = np.array(atom_ids, dtype=np.int64)
        self.delta = np.array(delta, dtype=np.float32)

    def execute(self, scene) -> bool:
        from .id_manager import IdManager
        mgr = IdManager(scene)
        indices = mgr.get_indices(self.ids)
        if len(indices) == 0: return False
        scene.translate_atoms(indices, self.delta)
        return True

    def undo(self, scene) -> bool:
        from .id_manager import IdManager
        mgr = IdManager(scene)
        indices = mgr.get_indices(self.ids)
        if len(indices) == 0: return False
        scene.translate_atoms(indices, -self.delta)
        return True

class ChangeSpeciesCommand(EditCommand):
    """Changes elements of atoms. Reversible."""
    def __init__(self, atom_ids: Sequence[int], new_element: str, old_elements: List[str]):
        self.ids = np.array(atom_ids, dtype=np.int64)
        self.new_element = new_element
        self.old_elements = old_elements

    def execute(self, scene) -> bool:
        from .id_manager import IdManager
        mgr = IdManager(scene)
        indices = mgr.get_indices(self.ids)
        if len(indices) == 0: return False
        scene.set_elements(indices, self.new_element)
        return True

    def undo(self, scene) -> bool:
        from .id_manager import IdManager
        mgr = IdManager(scene)
        indices = mgr.get_indices(self.ids)
        if len(indices) == 0: return False
        # Since set_elements applies same to all, we must restore individually
        for i, idx in enumerate(indices):
            scene.set_elements([idx], self.old_elements[i])
        return True

class AddAtomsCommand(EditCommand):
    """Inserts new atoms into the scene. Reversible."""
    def __init__(self, ids: np.ndarray, pos: np.ndarray, elements: List[str]):
        self.ids = ids
        self.pos = pos
        self.elements = elements

    def execute(self, scene) -> bool:
        # Append to scene arrays
        scene.pos = np.vstack([scene.pos, self.pos])
        scene.ids = np.concatenate([scene.ids, self.ids])
        scene.elements.extend(self.elements)
        
        # New radii / colors
        from ..constants import ATOMIC_RADII, CPK_COLORS, DEFAULT_RADIUS, DEFAULT_COLOR
        new_radii = np.array([ATOMIC_RADII.get(e, DEFAULT_RADIUS) for e in self.elements], dtype=np.float32)
        scene.radii = np.concatenate([scene.radii, new_radii])
        
        new_colors = np.array([CPK_COLORS.get(e, DEFAULT_COLOR) for e in self.elements], dtype=np.float32)
        # 1. Ensure new colors are RGBA
        if len(new_colors.shape) == 1: new_colors = new_colors.reshape(-1, 3)
        if new_colors.shape[1] == 3:
            alphas = np.ones((len(new_colors), 1), dtype=np.float32)
            new_colors = np.hstack([new_colors, alphas])
            
        # 2. Ensure existing scene colors are RGBA before vstack
        if len(scene.colors) > 0 and scene.colors.shape[1] == 3:
            # Upscale existing scene colors to RGBA
            scene_alphas = np.ones((len(scene.colors), 1), dtype=np.float32)
            scene.colors = np.hstack([scene.colors, scene_alphas])
            
        scene.colors = np.vstack([scene.colors, new_colors])
        
        # Update metadata
        scene.N = len(scene.pos)
        from collections import Counter
        counts = Counter(scene.elements)
        scene.composition_str = " ".join([f"{k}{v}" for k, v in sorted(counts.items())])
        return True

    def undo(self, scene) -> bool:
        from .id_manager import IdManager
        mgr = IdManager(scene)
        indices = mgr.get_indices(self.ids)
        if len(indices) == 0: return False
        scene.remove_atoms(indices)
        return True

class DeleteAtomsCommand(EditCommand):
    """Removes atoms. Reversible by storing full state."""
    def __init__(self, atom_ids: Sequence[int], scene_state: Dict[str, Any]):
        self.ids = np.array(atom_ids, dtype=np.int64)
        self.backup = scene_state # Contains pos, elements, radii, colors, ids

    def execute(self, scene) -> bool:
        from .id_manager import IdManager
        mgr = IdManager(scene)
        indices = mgr.get_indices(self.ids)
        if len(indices) == 0: return False
        scene.remove_atoms(indices)
        return True

    def undo(self, scene) -> bool:
        # Restore from backup
        scene.pos = np.vstack([scene.pos, self.backup["pos"]])
        scene.ids = np.concatenate([scene.ids, self.ids])
        scene.elements.extend(self.backup["elements"])
        scene.radii = np.concatenate([scene.radii, self.backup["radii"]])
        back_colors = self.backup["colors"]
        if len(back_colors) > 0 and len(back_colors.shape) == 2 and back_colors.shape[1] == 3:
            back_alphas = np.ones((len(back_colors), 1), dtype=np.float32)
            back_colors = np.hstack([back_colors, back_alphas])
            
        scene.colors = np.vstack([scene.colors, back_colors])
        
        scene.N = len(scene.pos)
        from collections import Counter
        counts = Counter(scene.elements)
        scene.composition_str = " ".join([f"{k}{v}" for k, v in sorted(counts.items())])
        return True

class RotateAtomsCommand(EditCommand):
    """Rotates atoms around a pivot point. Reversible."""
    def __init__(self, atom_ids: Sequence[int], pivot: np.ndarray, axis: np.ndarray, angle_deg: float):
        self.ids = np.array(atom_ids, dtype=np.int64)
        self.pivot = np.array(pivot, dtype=np.float32)
        self.axis = np.array(axis, dtype=np.float32)
        self.angle = angle_deg

    def execute(self, scene) -> bool:
        from .id_manager import IdManager
        mgr = IdManager(scene)
        indices = mgr.get_indices(self.ids)
        if len(indices) == 0: return False
        
        # Manually apply rotation using the same logic as scene.rotate_atoms 
        # but with the specific pivot and axis provided.
        subset = scene.pos[indices]
        axis = self.axis / (np.linalg.norm(self.axis) + 1e-9)
        theta = np.radians(self.angle)
        cos_t, sin_t = np.cos(theta), np.sin(theta)
        ux, uy, uz = axis
        K = np.array([[0, -uz, uy], [uz, 0, -ux], [-uy, ux, 0]])
        R = np.eye(3) + sin_t * K + (1 - cos_t) * (K @ K)
        scene.pos[indices] = self.pivot + (subset - self.pivot) @ R.T
        return True

    def undo(self, scene) -> bool:
        from .id_manager import IdManager
        mgr = IdManager(scene)
        indices = mgr.get_indices(self.ids)
        if len(indices) == 0: return False
        
        # Rotate back by negative angle
        subset = scene.pos[indices]
        axis = self.axis / (np.linalg.norm(self.axis) + 1e-9)
        theta = np.radians(-self.angle)
        cos_t, sin_t = np.cos(theta), np.sin(theta)
        ux, uy, uz = axis
        K = np.array([[0, -uz, uy], [uz, 0, -ux], [-uy, ux, 0]])
        R = np.eye(3) + sin_t * K + (1 - cos_t) * (K @ K)
        scene.pos[indices] = self.pivot + (subset - self.pivot) @ R.T
        return True
