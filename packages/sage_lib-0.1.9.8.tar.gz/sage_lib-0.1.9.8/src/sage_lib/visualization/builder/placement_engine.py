from __future__ import annotations
import numpy as np
from typing import List, Tuple, Optional, Dict
from ..analysis.neighbor_engine import NeighborEngine

class PlacementEngine:
    """
    Calculates optimal 3D positions and orientations for new atoms or fragments.
    """
    def __init__(self, scene, rules):
        self.scene = scene
        self.rules = rules

    def get_molecular_placement(self, target_idx: int, element: str, distance: Optional[float] = None) -> Tuple[np.ndarray, np.ndarray]:
        """Finds the most open valency direction around target atom."""
        if distance is None:
            distance = self.rules.get_bond_length(self.scene.elements[target_idx], element)
            
        # 1. Get neighbors
        i, j, d = NeighborEngine.get_neighbors(self.scene.pos, self.scene.lat, cutoff=3.0, pbc=self.scene.is_periodic)
        mask = (i == target_idx)
        adj_indices = j[mask]
        
        target_pos = self.scene.pos[target_idx]
        if len(adj_indices) == 0:
            # Point along Z by default if solitary
            direction = np.array([0, 0, 1], dtype=np.float32)
        else:
            # Unwrap neighbors relative to target
            adj_pos = NeighborEngine.unwrap_selection(adj_indices, target_idx, self.scene.pos, self.scene.lat)
            vectors = adj_pos - target_pos
            vectors /= np.linalg.norm(vectors, axis=1)[:, None]
            
            # Heuristic: Direction opposite to average neighbor vector
            avg_v = np.mean(vectors, axis=0)
            if np.linalg.norm(avg_v) < 1e-4:
                # Neighbors are symmetric (e.g. linear), pick orthogonal
                direction = np.array([1, 0, 0], dtype=np.float32)
            else:
                direction = -avg_v / np.linalg.norm(avg_v)
                
        return target_pos + direction * distance, direction

    def get_materials_placement(self, target_indices: List[int], element: str, distance: Optional[float] = None) -> Tuple[np.ndarray, np.ndarray]:
        """Calculates Top, Bridge, or Hollow sites based on selection size."""
        # Unwrap all selected relative to first
        pos_uw = NeighborEngine.unwrap_selection(np.array(target_indices), target_indices[0], self.scene.pos, self.scene.lat)
        
        # 1. Centroid Site
        centroid = np.mean(pos_uw, axis=0)
        
        # 2. Normal estimation
        if len(target_indices) == 1:
            # Top site - need to guess normal from neighbors
            i, j, d = NeighborEngine.get_neighbors(self.scene.pos, self.scene.lat, cutoff=3.0, pbc=self.scene.is_periodic)
            mask = (i == target_indices[0])
            if np.any(mask):
                neigh_pos = NeighborEngine.unwrap_selection(j[mask], target_indices[0], self.scene.pos, self.scene.lat)
                # Fit plane to neighbors
                vectors = neigh_pos - pos_uw[0]
                _, _, vh = np.linalg.svd(vectors)
                normal = vh[2, :] # Smallest singular value is normal
            else:
                normal = np.array([0, 0, 1], dtype=np.float32)
        elif len(target_indices) == 2:
            # Bridge site - normal to mid-point and nearby 'up' direction
            normal = np.array([0, 0, 1], dtype=np.float32) # Simplification for v1
        else:
            # Hollow site - triangle/polygon normal
            v1 = pos_uw[1] - pos_uw[0]
            v2 = pos_uw[2] - pos_uw[0]
            normal = np.cross(v1, v2)
            norm = np.linalg.norm(normal)
            if norm > 1e-6: normal /= norm
            else: normal = np.array([0, 0, 1])
            
        # Ensure normal points 'up' (positive Z in global frame)
        if normal[2] < 0: normal = -normal
            
        if distance is None:
            # Find closest atom in selection to centroid (to use its element)
            ref_el = self.scene.elements[target_indices[0]]
            distance = self.rules.get_bond_length(ref_el, element)
            
        return centroid + normal * distance, normal

    @staticmethod
    def align_fragment(pos: np.ndarray, anchor_idx: int, anchor_vec: np.ndarray, target_pos: np.ndarray, target_vec: np.ndarray, roll_angle_deg: float = 0.0) -> np.ndarray:
        """
        Transforms fragment coordinates to align anchor_vec with target_vec.
        1. Translate anchor to origin.
        2. Rotate anchor_vec to target_vec.
        3. Apply roll rotation.
        4. Translate to target_pos.
        """
        # Ensure unit vectors
        v_from = np.array(anchor_vec) / np.linalg.norm(anchor_vec)
        v_to = np.array(target_vec) / np.linalg.norm(target_vec)
        
        # 1. Rotation between vectors
        dot = np.dot(v_from, v_to)
        if dot > 0.9999:
            R = np.eye(3)
        elif dot < -0.9999:
            # 180 flip around arbitrary perp axis
            R = -np.eye(3)
        else:
            axis = np.cross(v_from, v_to)
            axis /= np.linalg.norm(axis)
            angle = np.arccos(np.clip(dot, -1.0, 1.0))
            # Rodrigues formula
            K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
            R = np.eye(3) + np.sin(angle) * K + (1 - np.cos(angle)) * (K @ K)
            
        # 2. Roll Rotation
        if roll_angle_deg != 0:
            phi = np.radians(roll_angle_deg)
            # Rotate around v_to
            ax = v_to
            K = np.array([[0, -ax[2], ax[1]], [ax[2], 0, -ax[0]], [-ax[1], ax[0], 0]])
            R_roll = np.eye(3) + np.sin(phi) * K + (1 - np.cos(phi)) * (K @ K)
            R = R_roll @ R
            
        # 3. Apply
        new_pos = (pos - pos[anchor_idx]) @ R.T + target_pos
        return new_pos
