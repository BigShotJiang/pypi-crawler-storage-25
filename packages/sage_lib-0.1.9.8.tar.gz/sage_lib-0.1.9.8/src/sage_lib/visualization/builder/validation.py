from __future__ import annotations
import numpy as np
from typing import List, Dict, Any, Tuple
from ..analysis.neighbor_engine import NeighborEngine

class ValidationEngine:
    """
    Performs structural sanity checks on the scene.
    """
    def __init__(self, scene, rules):
        self.scene = scene
        self.rules = rules

    def validate_scene(self) -> Dict[str, Any]:
        """Runs all checks and returns a report."""
        if self.scene.N == 0: return {"valid": True, "errors": [], "warnings": []}
        
        errors = []
        warnings = []
        
        # 1. Severe Clashes (<0.8A or % of bond length)
        # Using a fixed 0.8A as most covalent radii are 0.4A+
        i, j, d = NeighborEngine.get_neighbors(self.scene.pos, self.scene.lat, cutoff=1.5, pbc=self.scene.is_periodic)
        for idx_i, idx_j, dist in zip(i, j, d):
            if dist < 0.6:
                errors.append(f"Severe overlap between {self.scene.elements[idx_i]}({idx_i}) and {self.scene.elements[idx_j]}({idx_j}): {dist:.3f}A")
            elif dist < 0.9:
                warnings.append(f"Close contact between {self.scene.elements[idx_i]}({idx_i}) and {self.scene.elements[idx_j]}({idx_j}): {dist:.3f}A")

        # 2. Coordination Checking
        # Count neighbors within cutoff
        counts = np.bincount(i, minlength=self.scene.N)
        for idx, count in enumerate(counts):
            element = self.scene.elements[idx]
            if element == "H" and count > 1:
                warnings.append(f"Hypervalent Hydrogen at index {idx} (coord: {count})")
            elif element == "C" and count > 4:
                warnings.append(f"Hypervalent Carbon at index {idx} (coord: {count})")
            elif element == "O" and count > 2:
                # Basic check, O can be 3 in some complexes but unusual for simple builder
                warnings.append(f"Unusual coordination for Oxygen at index {idx} (coord: {count})")

        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings,
            "clash_indices": list(set(i[d < 0.9]))
        }
