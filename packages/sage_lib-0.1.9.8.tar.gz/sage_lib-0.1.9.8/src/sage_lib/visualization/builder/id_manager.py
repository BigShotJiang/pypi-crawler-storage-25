from __future__ import annotations
import numpy as np
from typing import Dict, List, Optional, Sequence, Union

class IdManager:
    """
    Handles translation between persistent atom IDs and current array indices.
    """
    def __init__(self, scene):
        self.scene = scene

    def get_indices(self, ids: Sequence[int]) -> np.ndarray:
        """Translates a list of IDs to their current indices in the scene."""
        if len(ids) == 0 or self.scene.N == 0:
            return np.array([], dtype=np.int32)
        
        # O(N) lookup. For very large systems, this could be cached or use a dictionary.
        # However, for most molecular systems (<1M atoms), np.isin or searchsorted is fast enough.
        sorter = np.argsort(self.scene.ids)
        indices = np.searchsorted(self.scene.ids, ids, sorter=sorter)
        
        # Handle cases where IDs might not be found (return valid indices only)
        # This can happen if an ID was deleted but still exists in a command/selection.
        valid_mask = (indices < len(self.scene.ids))
        found_indices = sorter[indices[valid_mask]]
        
        # Double check sanity (must match exactly)
        actual_ids = self.scene.ids[found_indices]
        matched_mask = (actual_ids == np.array(ids)[valid_mask])
        
        return found_indices[matched_mask]

    def get_ids(self, indices: Sequence[int]) -> np.ndarray:
        """Translates a list of indices to their persistent IDs."""
        if len(indices) == 0 or self.scene.N == 0:
            return np.array([], dtype=np.int64)
        return self.scene.ids[indices]

    def generate_new_ids(self, count: int) -> np.ndarray:
        """Assigns new monotonic IDs and updates the scene's counter."""
        start = self.scene.id_counter
        new_ids = np.arange(start, start + count, dtype=np.int64)
        self.scene.id_counter += count
        return new_ids
